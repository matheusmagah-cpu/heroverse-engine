# EMENDA V4 — RECURSOS LOCAIS NÃO PODEM PARAR A MISSÃO

## RAIZ ÚNICA VINCULANTE
Recuperação, retenção e limpeza preservam `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube` como única fonte de verdade. Somente temporários transitórios podem existir fora dela; todo artefato necessário deve ser consolidado na raiz antes de ser válido.

Esta emenda complementa o COMANDO MESTRE V2 e a EMENDA V3 e prevalece em matéria de RAM, disco, CPU, temporários e capacidade local.

## REGRA VINCULANTE
`RESOURCE_WAIT` causado por RAM, disco, CPU, temporários, caches ou concorrência local NÃO é `TRUE_EXTERNAL_BLOCKER_ALL_FRONTS` enquanto existir recuperação local segura possível.
Não encerre a interação apenas relatando falta de recurso. Recupere capacidade, remeça e continue automaticamente.

O proprietário já autorizou higiene ativa do computador para esta operação, inclusive remoção de arquivos/mídias descartáveis e programas comprovadamente desnecessários, desde que não haja perda de dados necessários, segurança, credenciais ou evidências.

## CICLO OBRIGATÓRIO DE RECUPERAÇÃO
1. Medir RAM livre/commit/pagefile, CPU, disco do projeto e TEMP, processos e working sets.
2. Identificar a causa real e o maior consumidor antes de agir.
3. Encerrar primeiro subprocessos órfãos/concluídos pertencentes ao projeto (Python/FFmpeg/ASR/render/testes) que não tenham consumidor ativo.
4. Liberar handles/capturas temporárias e caches descartáveis já consolidados.
5. Limpar temporários, downloads intermediários e mídia já processada/publicada sem consumidor futuro, preservando evidências necessárias.
6. Para RAM, preferir trim/redução de working set de aplicativos não críticos antes de fechá-los.
7. Serializar regressão/render/ASR/modelos quando a concorrência estiver pressionando RAM/CPU.
8. Remeça após cada camada e retome assim que o gate for satisfeito.
9. Se ainda insuficiente, aguarde/reavalie por mecanismo LOCAL e barato; não faça polling frequente pelo modelo.
10. Enquanto espera um recurso, avance qualquer frente independente segura.
## PROTEÇÕES QUE NÃO PODEM SER SACRIFICADAS
Nunca remova/encerre por conveniência: Windows e componentes de segurança; Remote Desktop Commander; Codex/ChatGPT que conduz a missão; credenciais/OAuth; PAUSE/locks/leases sem o protocolo correto; bancos protegidos; evidências ainda exigidas; mídia/artefatos com consumidor futuro; processo ativo da tarefa corrente.
OneDrive só pode ser interrompido se for comprovado que não está sincronizando/fornecendo o projeto naquele momento e isso não prejudicar consistência; caso contrário preserve-o.
Não apague arquivo de valor incerto. Não use limpeza para enfraquecer gate, hash, integridade ou qualidade.

## LIMPEZA DE DISCO PERMANENTE
Mantenha política de retenção: resultado consolidado substitui intermediário descartável; vídeo já publicado e validado pode ser removido localmente quando não houver consumidor/rollback que o exija; downloads de análise sem uso futuro podem sair; caches recompiláveis podem sair sob pressão.
Preserve apenas o necessário para operação, auditoria, aprendizado, rollback válido e produção futura.
Antes de tarefa pesada, execute preflight de recursos e recuperação automática; não espere falhar para descobrir falta de capacidade.

## ESTADO ATUAL
T32 teve correção causal de `CANCEL_WORK_DATABASE_SET_CHANGED` e 64 testes focais aprovados.
A T33 anterior NÃO abriu a suíte por gate de RAM; isso não é regressão integral já executada.
Nesta intervenção externa segura, working sets de Chrome/Edge foram apenas aparados, sem fechar aplicativos: RAM livre passou de aproximadamente 1.143,6 MiB para 2.234,5 MiB, liberando ~1.090,9 MiB. O gate exigia 512 MiB. REMEÇA; a medição atual, não este número histórico, decide.

## CONTINUAÇÃO AGORA
Retome imediatamente a T33. Reutilize a tentativa parcial somente se o contrato real permitir; caso contrário crie UMA execução limpa com a candidata atual e capturas `before` novas. A suíte anterior não iniciou, portanto não trate a nova execução como repetição de uma integral concluída.
Quando T33 passar: leitor real -> aplicação controlada -> retomada -> D-116 -> próximos gates do V2/V3, sem resposta terminal intermediária.
Se surgir outro `RESOURCE_WAIT`, execute este ciclo de recuperação e continue; NÃO devolva o controle ao proprietário por capacidade local recuperável.

Só pare em `PROJECT_COMPLETE` ou `TRUE_EXTERNAL_BLOCKER_ALL_FRONTS` após provar que todas as camadas seguras de recuperação e todas as frentes independentes foram esgotadas.
