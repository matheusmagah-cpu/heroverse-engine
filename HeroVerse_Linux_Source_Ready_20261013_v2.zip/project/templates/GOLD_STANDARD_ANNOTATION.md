# Anotação de padrão-ouro

## Identificação

- Vídeo:
- Canal:
- Plataforma:
- Arquivo/hash:
- Duração:
- Formato:
- Direitos/status:
- Revisor:
- Data:

## Embalagem

- Título:
- Thumbnail:
- Promessa conjunta:
- Informação revelada:
- Informação omitida:
- Expectativa criada:
- Entrega real:

## Hook 0–1 s

- Primeiro frame:
- Fala:
- Texto:
- Ação:
- Áudio:
- Promessa percebida:
- Curiosidade:
- Função de retenção:
- Evidências:

## Hook 1–3 s

- Frames/takes:
- Fala:
- Texto:
- Mudança visual:
- Escalada/confirmação:
- Curiosidade:
- Função de retenção:
- Evidências:

## Continuação 3–8 s

- Contexto mínimo:
- Direção narrativa:
- Razão para continuar:
- Evidências:

## Continuação 8–30 s, se aplicável

- Confirmação da promessa:
- Desenvolvimento:
- Primeira prova/payoff:
- Evidências:

## Takes

Repita para cada take:

- ID:
- Início/fim/duração:
- Keyframes:
- Cena/ação:
- Enquadramento/movimento:
- Texto:
- Fala:
- Áudio:
- Transição:
- Função narrativa:
- Função de retenção:
- Evidência:

## Blocos narrativos

Repita para cada bloco:

- Papel:
- Início/fim:
- Objetivo:
- Informação entregue:
- Pergunta aberta:
- Emoção:
- Prova:
- Micro-payoff:
- Transição:
- Takes relacionados:

## Diagnóstico final

- Tema:
- Ângulo:
- Tese:
- Público:
- Mecanismo do hook:
- Mecanismo de retenção:
- Payoff:
- CTA:
- Regras candidatas:
- Elementos específicos que não devem ser copiados:
- Incertezas:
- Aprovação:

