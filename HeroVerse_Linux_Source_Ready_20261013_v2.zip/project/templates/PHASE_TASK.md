# PhaseTask

## Controle

- `phase_id`:
- `task_id`:
- `status`: `READY`
- `authorized_by`:
- `authorized_at`:

## Objetivo único

Descreva um resultado verificável.

## Contexto obrigatório

- documentos:
- componentes existentes:
- decisões relacionadas:

## Entradas

| Entrada | Local | Obrigatória | Validação | Direitos/credencial |
|---|---|---:|---|---|
| | | | | |

## Saídas

| Saída | Caminho | Formato/schema | Consumidor |
|---|---|---|---|
| | | | |

## Fora de escopo

- 

## Passos permitidos

1. 

## Ações proibidas nesta fase

- iniciar a fase seguinte;
- publicar;
- gerar custos não autorizados;
- remover requisitos;
- substituir dado real por mock sem rótulo.

## Critérios de aceitação

- [ ] 

## Testes obrigatórios

- [ ] unitários;
- [ ] integração aplicável;
- [ ] schema;
- [ ] fixture/padrão-ouro;
- [ ] exemplo real autorizado;
- [ ] revisão do diff.

## Evidências esperadas

- 

## Condição de parada

Ao concluir ou bloquear os critérios desta tarefa, atualizar `docs/STATE.md`, apresentar relatório e parar.

