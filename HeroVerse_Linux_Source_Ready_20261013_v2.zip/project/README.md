# HERO Engine

> Estado operacional vigente: consulte `docs/STATE.md`, `PLANS.md` e `docs/RELATORIO_ESTAGIO_ATUAL_2026-09-06.md`. O conteúdo abaixo preserva o bootstrap histórico; referências a dry-run, consentimento, credenciais na raiz, cadência e cálculos antigos não são instruções vigentes. O piloto já foi publicado e as regras permanentes atuais prevalecem.

Motor local e auditável para mineração de canais, controle de licenças, seleção de takes, planejamento editorial, renderização e preparação de uploads do canal inglês `@heroverse74`.

## Estado atual

- Canal-modelo principal: `Grace, Grit & Love`, catalogado em 24 vídeos, 5,795 milhões de views públicas e mediana de 134 mil views.
- Ranking corrigido por idade do vídeo: views/dia, não views brutas. A amostra compara seis aberturas do quartil superior com seis do inferior.
- Formato modelado: 16:9, alvo de 230 s, títulos declarativos curtos, voz de autoridade, takes cinematográficos e arco de sete funções narrativas.
- O primeiro vídeo longo modelado tem 230 s, cinco takes licenciados, 19,57% de material-fonte e 80,43% de narrativa original.
- A shot list contém 50 planos (ASL 4,6 s), busca visual, composição, overlay, cue de áudio e estado de licença por plano; o render fica bloqueado até cada asset de stock ter URL e evidência salvas.
- O Short de 39,4 s permanece como protótipo técnico e não é a peça-mãe do sistema.
- Upload preparado como privado, em `dry-run`, com atribuição e aprovação humana pendente.
- O SQLite agora cataloga o modelo, os 24 vídeos e os 12 hooks analisados, além das fontes e produções.

## Meta matemática de 30 dias

Com 265 inscritos, zero horas válidas informadas e vídeos-alvo de 230 s, a conta de 4.000 horas é:

- 40% de retenção (AVD 92 s): 156.522 views longas;
- 55% de retenção (AVD 126,5 s): 113.834 views longas;
- 70% de retenção (AVD 161 s): 89.441 views longas;
- com 30 longos, o caso central exige 3.795 views por vídeo;
- se a escala condicional produzir 53 longos, o caso central exige 2.148 por vídeo;
- o gap de inscritos é 735, ou 24,5 por dia.

Essas metas são contas exatas **dadas as taxas de retenção**. Probabilidades ficam ocultas em `prior_only`; o motor não exibe percentuais até existir amostra própria suficiente do HeroVerse.

## Instalação e validação

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\setup.ps1
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Rotina diária

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\daily.ps1
```

A rotina atualiza banco, forecast, exportação JSON e workbook. Ela não publica enquanto o modo de segurança estiver em `dry-run`.

## Fluxo de uma produção

```powershell
# Ver o catálogo de fontes e licenças
.\scripts\run.ps1 catalog sources

# Auditar novamente a licença antes do uso
.\scripts\run.ps1 audit 5-zdruoQKlM

# Minerar os melhores takes no transcript armazenado
.\scripts\run.ps1 mine-clips 5-zdruoQKlM --limit 15

# Extrair a mecânica da abertura vencedora sem copiar sua redação
.\scripts\run.ps1 mine-hook 5-zdruoQKlM --window-seconds 18

# Construir a ficha-mãe empírica e catalogar os 24 vídeos do canal-modelo
.\scripts\run.ps1 build-model

# Criar o primeiro longo de 230 s e executar o preflight do modelo
.\scripts\run.ps1 modeled-long
.\scripts\run.ps1 model-check output\edl\protect-your-identity-long-01.json
.\scripts\run.ps1 shotlist output\edl\protect-your-identity-long-01.json

# Baixar somente depois que a fonte estiver liberada pelo gate
.\scripts\run.ps1 download 5-zdruoQKlM

# Criar e renderizar o protótipo técnico de Short
.\scripts\run.ps1 pilot
.\scripts\run.ps1 render output\edl\identity-attack-before-calling-short-01.json

# Executar os gates objetivos; a fila recusa qualquer render reprovado
.\scripts\run.ps1 quality output\edl\identity-attack-before-calling-short-01.json

# Preparar upload privado somente depois da aprovação técnica
.\scripts\run.ps1 queue identity-attack-before-calling-short-01
```

O preflight modelado mede 11 itens antes do render: formato, duração, hook original em primeiro lugar, tese até 3,2 s, semântica do hook, fórmula de título, quantidade e duração dos takes, participação do material-fonte, participação original e arco narrativo completo. O gate técnico mede resolução específica do formato, 30 fps, codec, áudio 48 kHz, loudness, true peak, silêncio, bitrate, licenças e atribuição. O upload não é preparado se um gate crítico falhar.

Depois da revisão visual:

```powershell
.\scripts\run.ps1 approve identity-attack-before-calling-short-01
.\scripts\run.ps1 queue identity-attack-before-calling-short-01
```

## Ativação da API do YouTube

1. Crie um cliente OAuth do tipo Desktop no Google Cloud para a YouTube Data API v3.
2. Salve o arquivo localmente como `credentials.json` na raiz deste projeto. Não envie o conteúdo pelo chat e não o versione.
3. Mude `safety.publish_mode` em `config/engine.json` de `dry-run` para `live` somente após revisar o processo.
4. Execute o primeiro upload aprovado; uma janela local fará a autorização e salvará `token.json`.

```powershell
.\scripts\run.ps1 publish output\queue\identity-attack-before-calling-short-01.upload.json --live
```

O publicador recusa produções não aprovadas e uploads sem a combinação explícita de modo `live` + `--live`.

## Calibração com dados do Studio

Registre snapshots comparáveis em 24 h, 72 h e 7 dias. Exemplo:

```powershell
.\scripts\run.ps1 record VIDEO_ID --format short --age-hours 24 --views 1200 --engaged-views 700 --subscribers 14 --viewed-rate 0.64 --apv 0.91
.\scripts\run.ps1 decide VIDEO_ID
```

O decisor retorna somente `SCALE`, `ITERATE`, `STOP` ou `INSUFFICIENT_DATA`. Shorts usam viewed rate, média percentual assistida e inscritos por mil views. Longos usam CTR, retenção aos 30 segundos e duração média. Métricas ausentes ou snapshots com menos de 24 horas nunca geram palpite.

Para longos, priorize impressões, CTR, retenção aos 30 segundos, duração média, horas e inscritos. O motor muda o estado para `calibrated` apenas quando houver 10 IDs distintos de cada formato.

## Regras editoriais e de licença

- Vídeo público não significa automaticamente reutilizável.
- O pipeline automático aceita apenas fontes com evidência `verified_cc`; fontes sem licença ficam bloqueadas ou indeterminadas.
- Atribuição é obrigatória e já entra no pacote de upload.
- O limite interno de 30% de material-fonte não é uma regra jurídica nem garantia de monetização; é um gate editorial para assegurar que comentário, tese, estrutura e valor sejam predominantemente novos.
- Não usar voz clonada ou apresentação que sugira endosso de pregadores ou figuras conhecidas.
- Canais de referência servem para modelar assunto, ritmo, duração e embalagem — não para copiar identidade, roteiro ou material sem licença.
- O hook é modelado por função (tensão, reversão, curiosidade, timing, prova e payoff), nunca por cópia literal. Views da referência são evidência de desempenho do vídeo, não prova causal de que uma única frase gerou o resultado; a validação do HeroVerse acontece com retenção real em 24 h, 72 h e 7 dias.

## Fontes oficiais de política

- [Elegibilidade e revisão do YPP](https://support.google.com/youtube/answer/72851?hl=en)
- [Conteúdo reutilizado e conteúdo não autêntico](https://support.google.com/youtube/answer/1311392?hl=en-EN)
- [Licenças Creative Commons no YouTube](https://support.google.com/youtube/answer/2797468?hl=en)
- [Divulgação de conteúdo alterado/sintético](https://support.google.com/youtube/answer/14328491?hl=en)

## Estrutura

- `hero_engine/`: banco, forecast, auditoria, mineração, render e publicação.
- `config/engine.json`: cadência, cenários, gates e modo de segurança.
- `data/`: catálogo, transcripts e downloads locais ignorados pelo Git.
- `output/`: relatórios, EDLs, renders e pacotes de upload.
- `outputs/`: workbook executivo entregue.
- `tests/`: testes reproduzíveis do núcleo.
