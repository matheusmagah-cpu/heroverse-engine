# V6 — GUARDAS DURÁVEIS: RECURSOS + PROGRESSO

Esta emenda é vinculante a V2/V3/V4/V5. Ela não é apenas orientação: existem guardas locais executáveis na raiz original.

## 1. RESOURCE GUARD
Existe `output/runtime/gestor-central/guards/resource_guard.ps1` e a tarefa Windows `HeroVerse-ResourceGuard`, executada a cada 1 minuto.
Antes de QUALQUER estágio pesado (regressão, aplicação, render, ASR/modelo, publicação em lote), execute também:
`powershell.exe -NoProfile -ExecutionPolicy Bypass -File output/runtime/gestor-central/guards/resource_guard.ps1 -MinFreeRamMiB 1536 -MinFreeDiskGiB 12 -Preflight`
Exit 0 = admitido. Exit 42 = NÃO iniciar o estágio; recuperar recurso e reexecutar somente o preflight.
Não desligar nem contornar `HeroVerse-ResourceGuard` durante a missão.

## 2. PROGRESS GUARD
Existe `output/runtime/gestor-central/guards/progress_guard.ps1`.
Após falha material: chamar `-Mode failure -Stage <gate> -Fingerprint <causa-normalizada> -Evidence <identidade-da-candidata/entrada>`.
Antes de repetir: chamar `-Mode check` com os mesmos Stage/Fingerprint/Evidence. Exit 43 proíbe repetição equivalente.
Após mudança de gate comprovada: chamar `-Mode progress -Stage <novo-gate> -Evidence <prova>` para zerar a sequência anterior.
Não falsificar Evidence para zerar contador; só muda quando a entrada/causa/abordagem mudou materialmente.

## 3. DEFINIÇÃO DE PROGRESSO
CPU, logs, polling, novo número Txx ou tempo gasto NÃO são progresso.
Progresso exige evidência de mudança de estado: gate fechado, consumidor real validado e próximo gate elegível iniciado/concluído.
Se 2 falhas iguais ocorrerem, a terceira tentativa equivalente é proibida. Mude a causa/abordagem/recurso/modelo ou avance frente independente segura.

## 4. RECURSOS
RAM: alvo automático >=1536 MiB antes de estágio pesado; nunca enfraquecer gate interno de segurança.
Disco C: manter >=12 GiB livres; abaixo disso, limpeza automática só de temporários comprovadamente descartáveis. Não apagar evidências, bancos, modelos necessários, credenciais, mídia com consumidor futuro, Windows/segurança ou dados pessoais de valor incerto.
Mídia já publicada/validada e intermediários sem consumidor futuro entram na política normal de retenção do projeto e podem ser removidos conforme V2/V4.

## 5. RUMO FINAL
Prioridade invariável: aplicação -> retomada -> D-116 -> TECHNICAL_CORE_READY -> piloto real -> pesquisa -> produção -> publicação -> métricas -> aprendizagem viva -> repetibilidade/generalização -> produto.
Não declarar PROJECT_COMPLETE antes dos critérios verificáveis do V2. Não transformar manutenção em objetivo permanente.