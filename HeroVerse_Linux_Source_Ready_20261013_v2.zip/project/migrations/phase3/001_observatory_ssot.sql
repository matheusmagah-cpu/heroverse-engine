PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL,
    content_sha256 TEXT NOT NULL CHECK(length(content_sha256) = 64)
);

CREATE TABLE IF NOT EXISTS observatory_operations (
    operation_id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    objective TEXT NOT NULL,
    authorized_phase INTEGER NOT NULL CHECK(authorized_phase = 3),
    status TEXT NOT NULL CHECK(status IN ('RUNNING', 'AWAITING_REVIEW', 'COMPLETE', 'FAILED')),
    scope_sha256 TEXT NOT NULL CHECK(length(scope_sha256) = 64),
    external_api_cost_usd REAL NOT NULL DEFAULT 0 CHECK(external_api_cost_usd >= 0),
    started_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS observatory_channels (
    operation_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    handle TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('OWNED', 'FORMAT_REFERENCE', 'MARKET_REFERENCE', 'SPEED_REFERENCE', 'LICENSED_SOURCE')),
    identity_version TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('READY', 'DEGRADED', 'BLOCKED')),
    source_uri TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (operation_id, channel_id),
    UNIQUE (operation_id, handle),
    FOREIGN KEY (operation_id) REFERENCES observatory_operations(operation_id)
);

CREATE TABLE IF NOT EXISTS observatory_ledger_events (
    event_id TEXT PRIMARY KEY,
    operation_id TEXT NOT NULL,
    channel_id TEXT,
    event_type TEXT NOT NULL,
    evidence_class TEXT NOT NULL CHECK(evidence_class IN ('OBSERVED', 'CALCULATED', 'INFERRED', 'PRIVATE', 'UNKNOWN')),
    trace_id TEXT NOT NULL,
    source_uri TEXT,
    occurred_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
    payload_sha256 TEXT NOT NULL CHECK(length(payload_sha256) = 64),
    FOREIGN KEY (operation_id) REFERENCES observatory_operations(operation_id),
    FOREIGN KEY (operation_id, channel_id) REFERENCES observatory_channels(operation_id, channel_id)
);

CREATE TRIGGER IF NOT EXISTS observatory_ledger_no_update
BEFORE UPDATE ON observatory_ledger_events
BEGIN
    SELECT RAISE(ABORT, 'observatory ledger is append-only');
END;

CREATE TRIGGER IF NOT EXISTS observatory_ledger_no_delete
BEFORE DELETE ON observatory_ledger_events
BEGIN
    SELECT RAISE(ABORT, 'observatory ledger is append-only');
END;

CREATE TABLE IF NOT EXISTS observatory_public_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    operation_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    entity_type TEXT NOT NULL CHECK(entity_type IN ('CHANNEL', 'VIDEO', 'POLICY')),
    entity_id TEXT NOT NULL,
    collection_status TEXT NOT NULL CHECK(collection_status IN ('COMPLETE', 'PARTIAL', 'FAILED')),
    captured_at TEXT NOT NULL,
    source_uri TEXT NOT NULL,
    collector TEXT NOT NULL,
    payload_json TEXT CHECK(payload_json IS NULL OR json_valid(payload_json)),
    payload_sha256 TEXT CHECK(payload_sha256 IS NULL OR length(payload_sha256) = 64),
    error_code TEXT,
    error_message TEXT,
    UNIQUE (operation_id, channel_id, entity_type, entity_id, captured_at),
    FOREIGN KEY (operation_id, channel_id) REFERENCES observatory_channels(operation_id, channel_id)
);

CREATE TRIGGER IF NOT EXISTS observatory_snapshots_no_update
BEFORE UPDATE ON observatory_public_snapshots
BEGIN
    SELECT RAISE(ABORT, 'observatory snapshots are append-only');
END;

CREATE TRIGGER IF NOT EXISTS observatory_snapshots_no_delete
BEFORE DELETE ON observatory_public_snapshots
BEGIN
    SELECT RAISE(ABORT, 'observatory snapshots are append-only');
END;

CREATE TABLE IF NOT EXISTS observatory_coverage (
    operation_id TEXT NOT NULL,
    video_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    coverage_level TEXT NOT NULL CHECK(coverage_level IN ('FULL_VALIDATED', 'OPENING_ONLY', 'METADATA_ONLY')),
    fields_json TEXT NOT NULL CHECK(json_valid(fields_json)),
    artifact_uri TEXT,
    artifact_sha256 TEXT,
    rights_status TEXT NOT NULL,
    holdout_from_phase2 INTEGER NOT NULL CHECK(holdout_from_phase2 IN (0, 1)),
    limitations_json TEXT NOT NULL CHECK(json_valid(limitations_json)),
    recorded_at TEXT NOT NULL,
    PRIMARY KEY (operation_id, video_id, coverage_level),
    FOREIGN KEY (operation_id, channel_id) REFERENCES observatory_channels(operation_id, channel_id)
);

CREATE TABLE IF NOT EXISTS observatory_cohorts (
    operation_id TEXT NOT NULL,
    cohort_id TEXT NOT NULL,
    channel_id TEXT,
    kind TEXT NOT NULL CHECK(kind IN ('WINNER', 'MEDIAN', 'WEAK', 'CROSS_CHANNEL', 'PERIOD', 'CUSTOM')),
    selection_rule TEXT NOT NULL,
    cutoff_at TEXT NOT NULL,
    ranking_metric TEXT NOT NULL,
    limitations_json TEXT NOT NULL CHECK(json_valid(limitations_json)),
    PRIMARY KEY (operation_id, cohort_id),
    FOREIGN KEY (operation_id) REFERENCES observatory_operations(operation_id),
    FOREIGN KEY (operation_id, channel_id) REFERENCES observatory_channels(operation_id, channel_id)
);

CREATE TABLE IF NOT EXISTS observatory_cohort_members (
    operation_id TEXT NOT NULL,
    cohort_id TEXT NOT NULL,
    video_id TEXT NOT NULL,
    rank_value REAL,
    rank_position INTEGER,
    evidence_snapshot_id TEXT NOT NULL,
    PRIMARY KEY (operation_id, cohort_id, video_id),
    FOREIGN KEY (operation_id, cohort_id) REFERENCES observatory_cohorts(operation_id, cohort_id),
    FOREIGN KEY (evidence_snapshot_id) REFERENCES observatory_public_snapshots(snapshot_id)
);

CREATE TABLE IF NOT EXISTS observatory_typed_memory (
    memory_id TEXT PRIMARY KEY,
    operation_id TEXT NOT NULL,
    channel_id TEXT,
    memory_type TEXT NOT NULL CHECK(memory_type IN ('FACT', 'METRIC', 'HYPOTHESIS', 'LIMITATION', 'POLICY', 'ERROR')),
    knowledge_status TEXT NOT NULL CHECK(knowledge_status IN ('OBSERVED', 'CALCULATED', 'CANDIDATE', 'SUPPORTED_LOCAL', 'INCONCLUSIVE', 'REJECTED', 'UNAVAILABLE')),
    version INTEGER NOT NULL CHECK(version >= 1),
    payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
    evidence_ids_json TEXT NOT NULL CHECK(json_valid(evidence_ids_json)),
    valid_from TEXT NOT NULL,
    supersedes_memory_id TEXT,
    FOREIGN KEY (operation_id) REFERENCES observatory_operations(operation_id),
    FOREIGN KEY (operation_id, channel_id) REFERENCES observatory_channels(operation_id, channel_id),
    FOREIGN KEY (supersedes_memory_id) REFERENCES observatory_typed_memory(memory_id)
);

CREATE TABLE IF NOT EXISTS observatory_errors (
    error_id TEXT PRIMARY KEY,
    operation_id TEXT NOT NULL,
    channel_id TEXT,
    stage TEXT NOT NULL,
    retryable INTEGER NOT NULL CHECK(retryable IN (0, 1)),
    attempt INTEGER NOT NULL CHECK(attempt >= 1),
    error_type TEXT NOT NULL,
    message TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    resolved_at TEXT,
    FOREIGN KEY (operation_id) REFERENCES observatory_operations(operation_id)
);

CREATE INDEX IF NOT EXISTS idx_observatory_snapshots_entity
ON observatory_public_snapshots(operation_id, channel_id, entity_type, entity_id, captured_at);

CREATE INDEX IF NOT EXISTS idx_observatory_ledger_trace
ON observatory_ledger_events(operation_id, trace_id, recorded_at);

CREATE INDEX IF NOT EXISTS idx_observatory_coverage_channel
ON observatory_coverage(operation_id, channel_id, coverage_level);
