# HeroVerse — Handoff operacional 2026-09-16

## Missão e autoridade
Este arquivo é a fonte de contexto para uma NOVA conversa Codex, criada para eliminar o peso/loop da thread antiga sem perder decisões válidas.
Raiz lógica ÚNICA: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`.
Alias ASCII de execução Windows: `C:\Users\mathe\OneDrive\READET~1\MODELA~1` — é a MESMA pasta, nunca uma cópia.
Thread histórica: `01a05e82-e950-78c2-aba4-a88e62bf6a82` (`Analyze YouTube channel`). Não carregar/reler a thread inteira; consultar apenas se este handoff e os artefatos locais não responderem algo específico.

## Resultado final exigido pelo usuário
Construir e finalizar o HeroVerse como operação YouTube realmente autônoma, orientada a resultado e não a manutenção infinita.
O sistema deve: pesquisar nicho/mercado/demanda antes de publicar; definir estratégia; configurar canal, identidade, títulos, thumbnails/capas/metadados quando aplicável; produzir vídeo longo/short e formatos/nichos diversos; fazer QA forte; publicar; medir analytics; aprender com dados reais; alterar decisões futuras; acelerar crescimento com inteligência viva.
A arquitetura final deve permitir escolher o nicho e, dali em diante, operar autonomamente, com intervenção humana mínima/zero dentro do que as APIs e plataformas permitirem.
Ferramentas: priorizar caminhos gratuitos, integráveis, rápidos e profissionais. Modelos devem variar por complexidade/custo: modelo mais barato quando suficiente; modelo avançado somente quando materialmente necessário.
Qualidade e velocidade são simultâneas: não reduzir gate para “passar”; resolver causa real e avançar.

## Regra anti-loop vinculante
CPU, logs, heartbeat, novo número Txx, tempo gasto ou repetir teste NÃO são progresso.
Progresso = mudança material de estado comprovada: causa removida, gate fechado e próximo gate iniciado/concluído.
Duas falhas equivalentes com mesma causa/entrada proíbem uma terceira tentativa equivalente. Mudar abordagem causal ou avançar frente independente segura.
Não reexecutar regressão integral já válida sem mudança material da candidata.
Não criar “resolução da resolução”; toda manutenção deve ter caminho explícito para operação real.
