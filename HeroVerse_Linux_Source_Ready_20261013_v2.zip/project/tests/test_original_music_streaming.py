"""Bounded-memory peak verification of the existing native music producer."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import soundfile as sf
from hero_engine import render_creative_v3_phase5 as renderer


class OriginalMusicStreamingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'music.wav'

    def build(self, duration=4125):
        return renderer._build_original_music(duration, self.path, created_at='2026-10-06T00:00:00Z')

    def test_native_producer_never_loads_entire_wav_for_peak(self):
        with patch.object(renderer.sf, 'read', side_effect=AssertionError('whole-file PCM allocation forbidden')):
            result = self.build(12250)
        self.assertFalse(result['clipping'])
        self.assertEqual(result['duration_ms'], 12250)

    def test_peak_matches_independent_decoded_pcm_and_exact_sample_count(self):
        result = self.build()
        samples, rate = sf.read(self.path, dtype='float32', always_2d=True)
        self.assertEqual(rate, 48000)
        self.assertEqual(samples.shape, (198000, 2))
        self.assertEqual(result['peak_linear'], round(float(np.max(np.abs(samples))), 6))
        self.assertEqual(sf.info(self.path).subtype, 'PCM_16')

    def test_measurement_blocks_are_bounded_and_cover_tail(self):
        native = sf.blocks
        sizes = []
        def observed(*args, **kwargs):
            for block in native(*args, **kwargs):
                sizes.append(len(block))
                yield block
        with patch.object(renderer.sf, 'blocks', side_effect=observed):
            self.build(12250)
        self.assertEqual(sizes, [192000, 192000, 192000, 12000])
        self.assertEqual(sum(sizes), 588000)

    def test_clipped_decoded_block_is_rejected(self):
        with patch.object(renderer.sf, 'blocks', return_value=iter([np.ones((8, 2), dtype=np.float32)])):
            with self.assertRaisesRegex(RuntimeError, 'procedural music clipped'):
                self.build(250)

    def test_same_recipe_produces_same_pcm_bytes(self):
        self.build(1000)
        original = self.path.read_bytes()
        other = Path(self.temp.name) / 'second.wav'
        renderer._build_original_music(1000, other, created_at='2026-10-07T00:00:00Z')
        self.assertEqual(original, other.read_bytes())


if __name__ == '__main__':
    unittest.main()
