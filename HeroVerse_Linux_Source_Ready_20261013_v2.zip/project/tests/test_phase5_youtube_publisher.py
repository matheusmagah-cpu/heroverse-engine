from __future__ import annotations

import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch

from hero_engine.phase5_youtube_publisher import _validate_release, execute_publication_pipeline
from hero_engine.phase5_release_gate import build_release_gate


ROOT = Path(__file__).resolve().parents[1]


class Phase5YouTubePublisherTests(unittest.TestCase):
    def test_real_ready_release_has_complete_immutable_artifact_chain(self) -> None:
        path=ROOT / "output/production/phase5/pilot-001/creative-v3/release_gate.json"
        historical=path.read_bytes()
        # OAuth readiness is a current input, not an immutable historical alias.
        # Exercise its existing producer and reject a stale frozen release; never
        # overwrite the historical receipt to make its old live binding pass.
        release = build_release_gate(ROOT, created_at="2026-09-04T00:30:00Z")
        _validate_release(ROOT, release)
        self.assertEqual("READY_FOR_PUBLICATION_PIPELINE", release["decision"])
        self.assertIsNotNone(release["artifacts"]["autonomous_review"])
        self.assertIsNone(release["artifacts"]["human_review"])
        old=json.loads(historical)
        if old['artifacts']['oauth_readiness'] != release['artifacts']['oauth_readiness']:
            with self.assertRaises(PermissionError):_validate_release(ROOT,old)
        self.assertEqual(path.read_bytes(),historical)

    def test_pipeline_stages_private_then_verifies_and_promotes_public(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            v3 = root / "output/production/phase5/pilot-001/creative-v3"
            v3.mkdir(parents=True)
            (root / "schemas").mkdir()
            (root / "schemas/youtube_publication_receipt.schema.json").write_text(
                (ROOT / "schemas/youtube_publication_receipt.schema.json").read_text(encoding="utf-8"), encoding="utf-8"
            )
            for name, content in (("video.mp4", b"video"), ("thumb.jpg", b"thumb"), ("captions.srt", b"captions")):
                (v3 / name).write_bytes(content)
            release = {
                "schema_version": "1.1.0",
                "release_id": "release-test", "idempotency_key": "a" * 64, "selected_thumbnail": "B",
                "artifacts": {
                    "video": {"path": str(v3 / "video.mp4"), "sha256": "1" * 64},
                    "thumbnail": {"path": str(v3 / "thumb.jpg"), "sha256": "2" * 64},
                    "captions": {"path": str(v3 / "captions.srt"), "sha256": "3" * 64},
                },
            }
            package = {
                "video": {"path": str(v3 / "video.mp4")},
                "captions": {"path": str(v3 / "captions.srt"), "language": "en-US"},
                "metadata": {"title": "Title", "description": "Description", "tags": ["tag"], "category_id": "27", "default_language": "en", "default_audio_language": "en", "made_for_kids": False},
                "disclosure": {"contains_synthetic_media": True},
            }
            (v3 / "release_gate.json").write_text(json.dumps(release), encoding="utf-8")
            (v3 / "publication_package.json").write_text(json.dumps(package), encoding="utf-8")

            class Request:
                def __init__(self, response): self.response = response
                def execute(self): return self.response
                def next_chunk(self): return None, self.response

            class Videos:
                def __init__(self): self.list_count = 0; self.updated = None
                def insert(self, **kwargs): return Request({"id": "video-123"})
                def list(self, **kwargs):
                    self.list_count += 1
                    privacy = "private" if self.list_count == 1 else "public"
                    return Request({"items": [{"id": "video-123", "snippet": {"channelId": "UCuMF6pJQkyMzaVoAxFL86yA"}, "status": {"privacyStatus": privacy, "uploadStatus": "processed"}}]})
                def update(self, **kwargs): self.updated = kwargs; return Request({"id": "video-123"})

            class Provider:
                def __init__(self): self.video_api = Videos()
                def channels(self): return type("Channels", (), {"list": lambda self, **kwargs: Request({"items": [{"id": "UCuMF6pJQkyMzaVoAxFL86yA"}]})})()
                def videos(self): return self.video_api
                def thumbnails(self): return type("Thumbs", (), {"set": lambda self, **kwargs: Request({"items": [{}]})})()
                def captions(self): return type("Captions", (), {"insert": lambda self, **kwargs: Request({"id": "caption-456"})})()

            provider = Provider()
            with patch("hero_engine.phase5_youtube_publisher._validate_release", return_value=None):
                receipt = execute_publication_pipeline(provider, lambda *args, **kwargs: object(), root, created_at="2026-09-04T02:00:00Z")
            self.assertEqual("COMPLETE_PUBLIC", receipt["status"])
            self.assertEqual("public", receipt["privacy_status"])
            self.assertEqual("caption-456", receipt["caption_id"])
            self.assertEqual("public", provider.video_api.updated["body"]["status"]["privacyStatus"])
            self.assertTrue(receipt["public_visibility_authorized"])


if __name__ == "__main__":
    unittest.main()
