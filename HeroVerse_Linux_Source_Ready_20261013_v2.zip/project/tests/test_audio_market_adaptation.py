import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import cli, forecast
from hero_engine.observatory import format_cohorts as cohorts
from tests.test_observatory_format_cohorts import _channel, _video, OPERATION, CUTOFF


class AudioMarketAdaptationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "public.json"
        self.labels = self.root / "classifications.json"
        snapshots = [_channel("market", "UCmarket", "MARKET_REFERENCE")]
        for index, views in enumerate((100, 200, 300, 10000)):
            video = _video("market", "UCmarket", "MARKET_REFERENCE", f"v{index}", view_count=views)
            video["payload"]["duration_seconds"] = 300
            snapshots.append(video)
        self.bundle = dict(schema_version="1.0.0", operation_id=OPERATION,
                           captured_at=CUTOFF, snapshots=snapshots)
        self.source.write_text(json.dumps(self.bundle), encoding="utf-8")
        self.annotations = {"source_sha256": hashlib.sha256(self.source.read_bytes()).hexdigest(),
                            "classifications": []}
        for video in snapshots[1:]:
            self.annotations["classifications"].append(dict(
                snapshot_id=video["snapshot_id"],
                snapshot_sha256=hashlib.sha256(cohorts._canonical(video).encode()).hexdigest(),
                evidence_uri=video["source_uri"], target_country="US", language="en",
                subject="reflection", audio_format="original-narration",
                classification_basis="Test fixture only; not market evidence"))
        self.save()

    def save(self):
        self.labels.write_text(json.dumps(self.annotations), encoding="utf-8")

    def compile(self):
        return cohorts.compile_audio_market_cohorts(self.source, self.labels)

    def test_winner_median_weak_without_outlier_as_typical_or_private_rpm(self):
        result = self.compile()
        group = result["groups"][0]
        self.assertEqual(group["baseline_views_per_day"], 25)
        self.assertEqual([item["kind"] for item in group["members"]],
                         ["WINNER", "MEDIAN", "MEDIAN", "WEAK"])
        self.assertEqual(group["duration_seconds_median"], 300)
        self.assertIsNone(group["uploads_per_week_in_observed_span"])
        self.assertFalse(result["audience_country_observed"])
        self.assertFalse(result["competitor_rpm_observed"])
        self.assertFalse(result["production_authorized"])

    def test_country_language_subject_and_audio_format_never_mix(self):
        for field, other in (("target_country", "CA"), ("language", "fr"),
                             ("subject", "sleep"), ("audio_format", "soundscape")):
            with self.subTest(field=field):
                original = copy.deepcopy(self.annotations)
                self.annotations["classifications"][0][field] = other
                self.save()
                self.assertEqual(len(self.compile()["groups"]), 2)
                self.assertTrue(all(group["status"] == "INSUFFICIENT_SAMPLE"
                                    for group in self.compile()["groups"]))
                self.annotations = original

    def test_public_source_and_snapshot_tamper_rejected(self):
        original = self.source.read_bytes()
        self.source.write_bytes(original + b" ")
        with self.assertRaisesRegex(cohorts.FormatCohortError, "source bytes"):
            self.compile()
        self.source.write_bytes(original)
        self.annotations["classifications"][0]["snapshot_sha256"] = "0" * 64
        self.save()
        with self.assertRaisesRegex(cohorts.FormatCohortError, "snapshot diverged"):
            self.compile()

    def test_unknown_duplicate_and_missing_classification(self):
        original = copy.deepcopy(self.annotations)
        self.annotations["classifications"].append(self.annotations["classifications"][0])
        self.save()
        with self.assertRaisesRegex(cohorts.FormatCohortError, "duplicate"):
            self.compile()
        self.annotations = original
        self.annotations["classifications"].pop()
        self.save()
        result = self.compile()
        self.assertEqual(len(result["exclusions"]), 1)
        self.assertEqual(result["groups"][0]["status"], "INSUFFICIENT_SAMPLE")

    def test_changed_evidence_uri_rejected(self):
        self.annotations["classifications"][0]["evidence_uri"] = "https://example.org"
        self.save()
        with self.assertRaisesRegex(cohorts.FormatCohortError, "evidence source"):
            self.compile()

    def test_global_video_identity_cannot_alias_another_channel(self):
        self.bundle["snapshots"].extend([
            _channel("other", "UCother", "MARKET_REFERENCE"),
            _video("other", "UCother", "MARKET_REFERENCE", "v0")])
        self.source.write_text(json.dumps(self.bundle), encoding="utf-8")
        self.annotations["source_sha256"] = hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.save()
        with self.assertRaisesRegex(cohorts.FormatCohortError, "multiple channels"):
            self.compile()

    def test_actual_cli_consumes_current_buffers_without_network_or_media(self):
        args = cli.build_parser().parse_args(["audio-market", str(self.source), str(self.labels)])
        with patch.object(cli, "_print_json") as output:
            args.func(args)
        self.assertEqual(output.call_args.args[0], self.compile())
        self.assertEqual(sorted(path.name for path in self.root.iterdir()),
                         ["classifications.json", "public.json"])

    def test_economics_separates_conditional_revenue_from_unmonetized_profit(self):
        scenarios = [dict(name="illustrative", assumed_rpm_usd=2, cost_usd=10,
                          assumption_basis="Synthetic scenario, not competitor RPM")]
        result = forecast.audio_revenue_scenarios(views=10000, scenarios=scenarios, monetized=False)
        row = result["scenarios"][0]
        self.assertEqual(row["conditional_monetized_revenue_usd"], 20)
        self.assertEqual(row["modeled_revenue_usd"], 0)
        self.assertEqual(row["modeled_profit_usd"], -10)
        self.assertEqual(row["break_even_views_if_monetized"], 5000)
        self.assertIsNone(result["observed_revenue_usd"])

    def test_no_assumed_rpm_default_and_invalid_financial_input_rejected(self):
        result = forecast.audio_revenue_scenarios(views=100, scenarios=[], monetized=False)
        self.assertEqual(result["scenarios"], [])
        for bad in (float("nan"), float("inf"), -1, True):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                forecast.audio_revenue_scenarios(views=100, monetized=True, scenarios=[
                    dict(name="bad", assumed_rpm_usd=bad, cost_usd=0, assumption_basis="fixture")])
