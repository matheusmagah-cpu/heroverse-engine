from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError

from hero_engine import operation_fallbacks as fallbacks
from hero_engine import phase6_reporting as reporting
from tests import test_phase6_reporting as reporting_harness

ROOT = Path(__file__).resolve().parents[1]


class OperationFallbackCoverageTests(unittest.TestCase):
    def test_all_curated_handlers_exist_without_claiming_test_or_runtime_success(self):
        value = fallbacks.build_coverage(ROOT)
        self.assertEqual(20, value["route_count"])
        self.assertEqual(17, value["domain_count"])
        self.assertEqual(20, value["source_bound_count"])
        self.assertEqual(len(value["routes"]), len({r["route_id"] for r in value["routes"]}))
        self.assertEqual(0, value["validated_provider_switch_count"])
        self.assertEqual({"NOT_ATTESTED_BY_THIS_VIEW"}, {r["validation_state"] for r in value["routes"]})
        self.assertFalse(value["publication_authorized"])
        self.assertEqual("COVERAGE_GAPS", value["status"])

    def test_missing_repository_sources_are_not_advertised_as_implemented(self):
        with tempfile.TemporaryDirectory() as folder:
            value = fallbacks.build_coverage(Path(folder))
            self.assertEqual(0, value["source_bound_count"])
            self.assertEqual({"UNAVAILABLE"}, {r["implementation_state"] for r in value["routes"]})
            self.assertEqual([], list(Path(folder).iterdir()))

    def test_read_only_no_network_subprocess_credentials_or_writes(self):
        with (
            patch("subprocess.Popen", side_effect=AssertionError("NO_PROCESS")),
            patch("socket.socket", side_effect=AssertionError("NO_NETWORK")),
            patch.object(Path, "write_bytes", side_effect=AssertionError("NO_WRITE")),
            patch.object(Path, "write_text", side_effect=AssertionError("NO_WRITE")),
        ):
            value = fallbacks.build_coverage(ROOT)
        self.assertEqual(20, value["source_bound_count"])
        self.assertTrue(all(r["source"]["path"].startswith(("hero_engine/", "scripts/")) for r in value["routes"]))

    def test_counts_do_not_count_defer_or_blocked_as_provider_recovery(self):
        value = fallbacks.build_coverage(ROOT)
        counts = value["kind_counts"]
        self.assertEqual(20, sum(counts.values()))
        self.assertEqual(0, counts["PROVIDER_SWITCH"])
        self.assertGreater(counts["DEFER"], 0)
        self.assertGreater(counts["BLOCKED"], 0)
        self.assertTrue(all(r["limit"] and r["gap"] and r["trigger"] for r in value["routes"]))

    def test_source_hash_change_changes_coverage_identity_without_promoting_capacity(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            file = root / "hero_engine/atomic_io.py"
            file.parent.mkdir()
            file.write_text("def atomic_write_utf8():\n    pass\n", encoding="utf-8")
            before = fallbacks.build_coverage(root)
            file.write_text("def atomic_write_utf8():\n    raise RuntimeError()\n", encoding="utf-8")
            after = fallbacks.build_coverage(root)
            self.assertNotEqual(before["coverage_sha256"], after["coverage_sha256"])
            self.assertEqual(before["source_bound_count"], after["source_bound_count"])
            self.assertEqual(0, after["validated_provider_switch_count"])
            # Even deliberately nonfunctional code is only source evidence.
            self.assertEqual("NOT_ATTESTED_BY_THIS_VIEW", after["routes"][0]["validation_state"])

    def test_syntax_error_or_missing_top_level_symbol_is_explicit(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            file = root / "hero_engine/atomic_io.py"
            file.parent.mkdir()
            file.write_text("def another():\n    pass\n", encoding="utf-8")
            self.assertEqual("HANDLER_NOT_FOUND", fallbacks._source(root, "hero_engine/atomic_io.py:atomic_write_utf8")["status"])
            file.write_text("not python (", encoding="utf-8")
            self.assertEqual("UNAVAILABLE", fallbacks._source(root, "hero_engine/atomic_io.py:atomic_write_utf8")["status"])

    def test_oversized_source_and_outside_path_are_never_read(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            file = root / "too-big.py"
            file.write_bytes(b"#" * 2_000_001)
            with patch.object(Path, "read_bytes", side_effect=AssertionError("DO_NOT_READ")):
                self.assertEqual("UNAVAILABLE", fallbacks._source(root, "too-big.py:handler")["status"])
                self.assertEqual("UNAVAILABLE", fallbacks._source(root, "../outside.py:handler")["status"])

    def test_future_phase_does_not_gain_active_execution_status(self):
        value = fallbacks.build_coverage(ROOT, active_phase=5)
        self.assertEqual(0, value["source_bound_count"])
        self.assertEqual({"OUT_OF_ACTIVE_PHASE"}, {r["implementation_state"] for r in value["routes"]})
        for invalid in (True, None, 4, 9, 6.0):
            with self.assertRaises(ValueError):
                fallbacks.build_coverage(ROOT, active_phase=invalid)

    def test_canonical_identity_is_deterministic_and_binds_every_field(self):
        value = fallbacks.build_coverage(ROOT)
        self.assertEqual(value, fallbacks.build_coverage(ROOT))
        material = deepcopy(value)
        digest = material.pop("coverage_sha256")
        expected = hashlib.sha256(json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        self.assertEqual(expected, digest)

    def test_schema_rejects_claimed_production_cost_test_pass_or_provider_validation(self):
        schema = json.loads((ROOT / "schemas/phase6_executive_status.schema.json").read_text(encoding="utf-8-sig"))["properties"]["fallbacks"]
        validator = Draft202012Validator(schema)
        value = fallbacks.build_coverage(ROOT)
        validator.validate(value)
        for field, changed in (("publication_authorized", True), ("technical_cost_brl", 1), ("validated_provider_switch_count", 1)):
            broken = deepcopy(value)
            broken[field] = changed
            with self.assertRaises(ValidationError):
                validator.validate(broken)
        broken = deepcopy(value)
        broken["routes"][0]["validation_state"] = "PASS"
        with self.assertRaises(ValidationError):
            validator.validate(broken)

    def test_reporting_integration_keeps_authority_closed_and_legacy_schema_valid(self):
        with tempfile.TemporaryDirectory() as folder:
            harness = reporting_harness.Phase6ReportingTests()
            root = harness._root(folder)
            value = reporting.build_status(root, captured_at="2026-09-05T18:46:00Z")
            self.assertEqual("1.5.0", value["schema_version"])
            self.assertIn("fallbacks", value)
            self.assertFalse(value["release_control"]["publication_authorized"])
            json_path, md_path = reporting.materialize(root, captured_at=value["captured_at"])
            self.assertEqual(value, json.loads(json_path.read_text(encoding="utf-8")))
            self.assertIn("Fallbacks por toda a operação", md_path.read_text(encoding="utf-8"))
            schema = json.loads((root / "schemas/phase6_executive_status.schema.json").read_text(encoding="utf-8-sig"))
            legacy = deepcopy(value)
            legacy["schema_version"] = "1.4.0"
            del legacy["fallbacks"]
            Draft202012Validator(schema).validate(legacy)
            with self.assertRaises(ValidationError):
                missing = deepcopy(value)
                del missing["fallbacks"]
                Draft202012Validator(schema).validate(missing)


if __name__ == "__main__":
    unittest.main()
