"""Native eight-unit voice→QA→package→canary→release→publisher chain.

Codec, ASR, eSpeak runtime and provider are test-frontier simulations. No real
production authority; no reader/gate is patched to return PASS.
"""
import copy
import json
import shutil
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from tests import test_audio_static_control_reader as controls
from tests import test_phase6_media as voice_fixture
from tests import test_audio_static_voice_reuse as reuse_fixture
from hero_engine.publication_package_phase5 import prepare_audio_static_packaging, materialize as package_materialize
from hero_engine.phase5_release_gate import build_release_gate, stage_audio_static_canary, materialize as release_materialize
from hero_engine.phase5_youtube_publisher import execute_publication_pipeline, CHANNEL_ID

ROOT=Path(__file__).resolve().parents[1]


class AudioStaticReadyChainTests(unittest.TestCase):
    def setUp(self):
        script=controls.read(ROOT/'output/production/audio-reflection-static-v2/narrative_script.json')
        openings=['Pause.','Name this pressure.','Choose one faithful response.']
        bodies=['Name one pressure.','Ask for wisdom.','Distinguish evidence from assumption.',
                'Choose one bounded response.','Practice one faithful step.']
        script['script_id']='complete-native-fixture';script['version']='1.0.0'
        for row,text in zip(script['hook_windows'][:3],openings):row['narration']=text
        script['hook_windows'][3]['narration']=' '.join(bodies)
        # The real narrative has seven sections (two repeated mechanism/action
        # roles). This bounded synthetic fixture has five, plus three hooks.
        # Select the five templates explicitly; never leave historical tail
        # sections beside the newly measured fixture's full_text.
        roles=['TITLE_ALIGNED_STAKE','PERSONAL_STAKES','MECHANISM_AND_PROOF',
               'REVERSAL_AND_ACTION','PROMISE_RESOLUTION']
        script['sections']=[copy.deepcopy(next(row for row in script['sections'] if row['role']==role))
                            for role in roles]
        for row,text in zip(script['sections'],bodies):row['text']=text
        script['full_text']=' '.join(openings+bodies)
        script['word_count']=len(script['full_text'].split());script['estimated_duration_ms']=13000
        self.script=script
        clock=[0,1000,3000,8000,9000,10000,11000,12000,13000]
        native=voice_fixture.Phase6MediaTests._prepare_voice_inputs
        def complete_inputs(owner,root):
            native(owner,root)
            path=root/'output/production/phase6/video-002/production/take_plan.json'
            plan=controls.read(path)
            plan['takes']=[{'take_id':f'take-{i+1:03}','start_ms':clock[i],'end_ms':clock[i+1],
                           'narration':text} for i,text in enumerate(openings+bodies)]
            controls.write(path,plan)
            controls.write(root/'output/production/phase6/video-002/preproduction/narrative_script.json',script)
        self.owner=controls.AudioStaticControlReaderTests('test_valid_anchored_reader_returns_limits_not_authority')
        self.addCleanup(self.owner.doCleanups)
        with patch.object(voice_fixture.Phase6MediaTests,'_prepare_voice_inputs',complete_inputs), \
             patch.object(reuse_fixture.AudioStaticVoiceReuseTests,'channel_id',CHANNEL_ID,create=True):
            self.owner.setUp()
        self.helper=self.owner.helper;self.root=self.owner.root;self.package=self.owner.package
        self.relative=self.helper.relative
        template=copy.deepcopy(self.helper.plan['takes'][0])
        self.helper.plan['takes']=[{**template,**row} for row in self.helper.plan['takes']]
        creative=controls.read(ROOT/'output/production/audio-reflection-static-v2/creative_direction_decision.json')
        creative['decision_id']='complete-native-creative';creative['brief_id']=script['brief_id']
        bible=controls.read(self.package/'channel_style_bible.json')
        creative['channel_id']=bible['channel_id'];creative['channel_dna_version']=bible['channel_dna_version']
        self.helper.plan['creative_direction_decision_id']=creative['decision_id']
        controls.write(self.package/'take_plan.json',self.helper.plan)
        original=self.root/'output/production/phase6/video-002/preproduction/narrative_script.json'
        shutil.copyfile(original,self.package/'narrative_script.json')
        controls.write(self.package/'editorial_brief.json',{'brief_id':script['brief_id'],
                       'channel_id':bible['channel_id'],'niche_fit':{'status':'PASS'}})
        controls.write(self.package/'creative_direction_decision.json',creative)
        if getattr(self,'cycle_schema_fixture',False):
            # The older compact fixture exercises only the native audio
            # reader's fields. Cycle tests additionally validate the full
            # existing TakePlan schema, using canonical documentary metadata
            # plus these fixture-owned clocks, narration, assets and rights.
            canonical=controls.read(ROOT/'output/production/audio-reflection-static-v2/take_plan.json')
            rows=[{**copy.deepcopy(canonical['takes'][0]),**row} for row in self.helper.plan['takes']]
            self.helper.plan={**canonical,**self.helper.plan,'takes':rows}
            self.helper.plan['total_cost']={**canonical['total_cost'],**self.helper.plan['total_cost']}
            controls.write(self.package/'take_plan.json',self.helper.plan)
        self.helper.prepared_editorial=True
        self.helper.codec_control_binding=self.owner.binding
        self.helper.execution_builder=self.owner.execution_fixture
        self.helper.complete_cycle_manifest_fixture=getattr(self,'cycle_schema_fixture',False)
        self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        self.report,self.measured=self.helper.last_result
        for schema in ('publication_package','phase5_release_gate','youtube_publication_receipt'):
            shutil.copy2(ROOT/f'schemas/{schema}.schema.json',self.root/'schemas')
        path=self.root/'config/format_packs';path.mkdir(parents=True)
        shutil.copy2(ROOT/'config/format_packs/fp-narrated-reflection-static-v1.json',path)
        policies={
            'output/integrations/youtube/heroverse/connection-receipt.json':{'status':'CONNECTED','identity_verified':True,
                'expected_channel':{'channel_id':CHANNEL_ID},'observed_channel':{'channel_id':CHANNEL_ID,'custom_url':'@heroverse74'}},
            'output/integrations/youtube/heroverse/operational-readiness.json':{'continuous_operation_ready':True,
                'durability_status':'PRODUCTION_READY','publication_guard':{'upload_permitted':True}},
            'output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json':{'status':'PASS','missing_scopes':[]},
            'output/audits/channel/heroverse/channel-readiness-audit.json':{'overall_status':'PASS','publication_gate':{'critical_open_gates':[]}},
            'output/operations/zero-cost/phase5-publication-pipeline-preflight.json':{'technical_cost_brl':0,'execution_permitted':True}}
        for name,value in policies.items():controls.write(self.root/name,value)
        prepare_audio_static_packaging(self.root,package_relative=self.relative)
        self.bindings={'quality_report':self.binding(self.package/'qa/creative_quality_gate_report.json'),
            'measurements':self.binding(self.package/'qa/technical_measurements.json'),
            'visual_controls':self.owner.binding,
            'render_execution':self.measured['static_observed_execution']['binding'],
            'asr_receipt':self.measured['intelligibility']['receipt']}
        # Reader contract uses exactly path/hash; no computed/manual PASS.
        self.bindings['asr_receipt']={k:self.bindings['asr_receipt'][k] for k in ('path','sha256')}
        package=package_materialize(self.root,package_relative=self.relative,
            quality_report_binding=self.bindings['quality_report'],measurement_binding=self.bindings['measurements'])
        self.bindings['publication_package']=self.binding(package)

    def binding(self,path):return {'path':str(path),'sha256':controls.sha(path)}
    def build(self):return build_release_gate(self.root,package_relative=self.relative,current_bindings=self.bindings)
    def canary(self):
        path=stage_audio_static_canary(self.root,package_relative=self.relative,current_bindings=self.bindings)
        self.bindings['format_transition']=self.binding(path)
        return path

    def test_native_complete_chain_reaches_ready_without_global_pack_promotion(self):
        failures=[row for row in self.report['gates'] if row['gate']!='PUBLICATION' and row['status'] not in ('PASS','NOT_APPLICABLE')]
        self.assertEqual(failures,[],self.measured['static_editorial'])
        self.assertEqual(self.build()['blockers'],['FORMAT_CAPABILITY'])
        pack=self.root/'config/format_packs/fp-narrated-reflection-static-v1.json';before=pack.read_bytes()
        path=self.canary();receipt=path.read_bytes()
        self.assertEqual(self.build()['decision'],'READY_FOR_PUBLICATION_PIPELINE')
        self.assertEqual(self.canary(),path);self.assertEqual(path.read_bytes(),receipt)
        self.assertEqual(pack.read_bytes(),before)
        self.assertFalse(controls.read(pack)['production_allowed'])

    def test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider(self):
        self.canary();release=release_materialize(self.root,package_relative=self.relative,current_bindings=self.bindings)
        provider=Mock();media=Mock(return_value=object())
        provider.channels.return_value.list.return_value.execute.return_value={'items':[{'id':CHANNEL_ID}]}
        provider.videos.return_value.insert.return_value.next_chunk.return_value=(None,{'id':'owned-video'})
        provider.captions.return_value.insert.return_value.execute.return_value={'id':'owned-caption'}
        def observation(privacy):return {'items':[{'id':'owned-video','snippet':{'channelId':CHANNEL_ID},
                                                  'status':{'privacyStatus':privacy,'uploadStatus':'processed'}}]}
        provider.videos.return_value.list.return_value.execute.side_effect=[observation('private'),observation('public')]
        result=execute_publication_pipeline(provider,media,self.root,package_relative=self.relative,
            current_bindings=self.bindings,expected_release_hash=controls.sha(release))
        self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        provider.reset_mock()
        self.assertEqual(execute_publication_pipeline(provider,media,self.root,package_relative=self.relative,
            current_bindings=self.bindings,expected_release_hash=controls.sha(release)),result)
        self.assertEqual(provider.mock_calls,[])

    def test_canary_cannot_transfer_to_changed_current_media(self):
        path=self.canary();before=path.read_bytes()
        Path(self.measured['render_path']).write_bytes(b'changed after canary')
        with self.assertRaises(PermissionError):self.build()
        self.assertEqual(path.read_bytes(),before)

    def test_post_canary_oauth_loss_blocks_native_publication_before_provider(self):
        self.canary();release=release_materialize(self.root,package_relative=self.relative,current_bindings=self.bindings)
        controls.write(self.root/'output/integrations/youtube/heroverse/operational-readiness.json',
                       {'continuous_operation_ready':False,'publication_guard':{'upload_permitted':False}})
        provider=Mock()
        with self.assertRaises(PermissionError):execute_publication_pipeline(provider,Mock(),self.root,
            package_relative=self.relative,current_bindings=self.bindings,expected_release_hash=controls.sha(release))
        self.assertEqual(provider.mock_calls,[])
