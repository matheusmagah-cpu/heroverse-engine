from __future__ import annotations

import copy
import hashlib
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from hero_engine.phase6_av_context import (
    Phase6AVContextError,
    _open_read_snapshot,
    resolve_phase6_av_context,
)
from hero_engine.queue_phase6 import (
    MEDIA_JOB_SUPERSESSION_RECEIPTS,
    QueueConflict,
    TransactionalQueue,
)
from tests import test_phase6_queue_post_effect as post_effect_tests


ROOT = Path(__file__).resolve().parents[1]


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class Phase6AVContextTests(unittest.TestCase):
    def _terminal_chain(
        self,
        folder: str,
        *,
        checkpoint: dict | None = None,
    ):
        helper = post_effect_tests.Phase6PostEffectQueueTests()
        root = Path(folder)
        queue = helper._queue(folder)
        receipt = helper._valid_post_effect_receipt(root, queue)
        root_id = receipt["root_job"]["job_id"]
        tail_id = receipt["authoritative_job"]["job_id"]
        now = datetime(2026, 9, 6, 3, 31, tzinfo=timezone.utc)
        claimed = queue.claim_job(
            tail_id,
            worker_id="fixture-terminal-worker",
            expected_task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
            now=now,
        )
        queue.succeed(
            tail_id,
            worker_id=claimed["lease_owner"],
            checkpoint=(
                {"render_manifest": "sha256:" + "9" * 64}
                if checkpoint is None
                else checkpoint
            ),
            now=now + timedelta(seconds=1),
        )
        return helper, root, queue, receipt, root_id, tail_id

    def _mixed_terminal_chain(self, folder: str):
        # Use both real constructors: the legacy identity-only supersession,
        # followed by the post-effect local visual successor.
        from tests.test_phase6_queue import Phase6QueueTests

        legacy = Phase6QueueTests()
        post_effect = post_effect_tests.Phase6PostEffectQueueTests()
        root = Path(folder)
        queue = legacy._queue(folder)
        post_effect_schema = "phase6_post_effect_media_job_supersession_receipt.schema.json"
        (root / "schemas" / post_effect_schema).write_bytes(
            (ROOT / "schemas" / post_effect_schema).read_bytes()
        )
        now = datetime(2026, 9, 6, 3, 30, tzinfo=timezone.utc)
        references, jobs, identity_result = legacy._committed_media_pair(
            root,
            queue,
            old_token="4",
            new_token="5",
            now=now,
        )
        predecessor = queue.claim_job(
            jobs[1]["job_id"],
            worker_id="mixed-predecessor-worker",
            expected_task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
            now=now + timedelta(seconds=2),
        )
        queue.succeed(
            jobs[1]["job_id"],
            worker_id=predecessor["lease_owner"],
            checkpoint={"render_manifest": "sha256:" + "8" * 64},
            now=now + timedelta(seconds=3),
        )
        eligibility_reference, eligibility_document = post_effect._eligibility_receipt(
            root, "f"
        )
        post_effect_result = queue.create_post_effect_visual_contract_successor(
            jobs[0]["job_id"],
            predecessor_job_id=jobs[1]["job_id"],
            media_unit=legacy._media_unit(),
            input_receipt=references[1],
            eligibility_receipt=eligibility_reference,
            eligibility_verifier=post_effect._verifier(eligibility_document),
            now=now + timedelta(seconds=4),
        )
        tail_id = post_effect_result["receipt"]["authoritative_job"]["job_id"]
        claimed_tail = queue.claim_job(
            tail_id,
            worker_id="mixed-terminal-worker",
            expected_task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
            now=now + timedelta(seconds=5),
        )
        queue.succeed(
            tail_id,
            worker_id=claimed_tail["lease_owner"],
            checkpoint={"render_manifest": "sha256:" + "9" * 64},
            now=now + timedelta(seconds=6),
        )
        return (
            post_effect,
            root,
            queue,
            references,
            identity_result,
            post_effect_result,
            jobs[0]["job_id"],
            tail_id,
        )

    @staticmethod
    def _assert_connection_closed(test: unittest.TestCase, connection) -> None:
        with test.assertRaisesRegex(sqlite3.ProgrammingError, "closed"):
            connection.execute("SELECT 1")

    def test_reconstructs_exact_terminal_context_read_only_with_real_resolver(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, receipt, root_id, tail_id = self._terminal_chain(folder)
            before_rows = helper._rows(queue)
            before_files = sorted(
                path.relative_to(root).as_posix()
                for path in root.rglob("*")
                if path.is_file()
            )
            with closing(sqlite3.connect(queue.path)) as connection:
                root_raw = connection.execute(
                    "SELECT payload_json,checkpoint_json FROM jobs WHERE job_id=?",
                    (root_id,),
                ).fetchone()
                tail_raw = connection.execute(
                    "SELECT payload_json,checkpoint_json FROM jobs WHERE job_id=?",
                    (tail_id,),
                ).fetchone()

            with patch.object(
                TransactionalQueue,
                "__init__",
                side_effect=AssertionError("read-only context must not initialize/migrate"),
            ):
                observed = resolve_phase6_av_context(
                    root, expected_root_job_id=root_id
                )

            self.assertEqual(
                "OBSERVED_TERMINAL_CONTEXT_NOT_TRANSACTION_AUTHORITY",
                observed["status"],
            )
            self.assertEqual(
                "SQLITE_URI_MODE_RO_QUERY_ONLY_SNAPSHOT",
                observed["database"]["open_mode"],
            )
            self.assertEqual(tail_id, observed["context"]["predecessor_job_id"])
            self.assertEqual(tail_id, observed["context"]["tail_job_id"])
            self.assertEqual(
                _sha(root_raw[0].encode("utf-8")),
                observed["context"]["authority_root_payload_sha256"],
            )
            self.assertEqual(
                _sha(root_raw[1].encode("utf-8")),
                observed["context"]["authority_root_checkpoint_sha256"],
            )
            self.assertEqual(
                _sha(tail_raw[0].encode("utf-8")),
                observed["context"]["predecessor_payload_sha256"],
            )
            self.assertEqual(
                _sha(tail_raw[1].encode("utf-8")),
                observed["context"]["predecessor_checkpoint_sha256"],
            )
            self.assertEqual(
                receipt["authoritative_input_receipt"]["sha256"],
                observed["context"]["input_receipt_sha256"],
            )
            self.assertTrue(all(value is False for value in observed["authority"].values()))
            self.assertFalse(observed["transaction_fencing_verified"])
            self.assertFalse(observed["external_publication_lock_verified"])
            self.assertFalse(observed["checkpoint_publication_absence_is_lock"])
            self.assertEqual(before_rows, helper._rows(queue))
            after_files = sorted(
                path.relative_to(root).as_posix()
                for path in root.rglob("*")
                if path.is_file()
            )
            # SQLite may create/remove its own WAL coordination sidecars while
            # opening a read-only WAL snapshot.  No domain/output artifact may
            # be added by this observation.
            self.assertEqual(
                [p for p in before_files if not p.endswith(("-wal", "-shm"))],
                [p for p in after_files if not p.endswith(("-wal", "-shm"))],
            )

    def test_reconstructs_real_mixed_chain_from_canonical_root(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            (
                helper,
                root,
                queue,
                references,
                _,
                _,
                root_id,
                tail_id,
            ) = self._mixed_terminal_chain(folder)
            before = helper._rows(queue)

            observed = resolve_phase6_av_context(
                root, expected_root_job_id=root_id
            )

            self.assertEqual(tail_id, observed["context"]["tail_job_id"])
            self.assertEqual(references[1]["receipt_id"], observed["context"]["input_receipt_id"])
            self.assertEqual(
                ["IDENTITY_ONLY", "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"],
                [edge["supersession_class"] for edge in observed["chain"]],
            )
            self.assertEqual(2, len(observed["chain"]))
            self.assertEqual(before, helper._rows(queue))

    def test_mixed_chain_intermediate_receipt_adulteration_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, _, _, _, root_id, _ = self._mixed_terminal_chain(folder)
            before = helper._rows(queue)
            with closing(sqlite3.connect(queue.path)) as connection:
                first_receipt_id = connection.execute(
                    "SELECT supersession_id FROM media_job_supersessions "
                    "ORDER BY recorded_at,supersession_id LIMIT 1"
                ).fetchone()[0]
            receipt_path = (
                root
                / MEDIA_JOB_SUPERSESSION_RECEIPTS
                / f"{first_receipt_id}.json"
            )
            receipt_path.write_bytes(receipt_path.read_bytes() + b" ")

            with self.assertRaisesRegex(PermissionError, "receipt hash/bytes diverged"):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)
            self.assertEqual(before, helper._rows(queue))

    def test_source_connect_failure_closes_in_memory_destination(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            opened = []
            real_connect = sqlite3.connect

            def failing_source_connect(database, *args, **kwargs):
                if database == ":memory:":
                    connection = real_connect(database, *args, **kwargs)
                    opened.append(connection)
                    return connection
                raise sqlite3.OperationalError("fixture source connect failure")

            with patch(
                "hero_engine.phase6_av_context.sqlite3.connect",
                new=failing_source_connect,
            ):
                with self.assertRaisesRegex(
                    sqlite3.OperationalError, "fixture source connect failure"
                ):
                    _open_read_snapshot(Path(folder).resolve() / "queue.sqlite3")

            self.assertEqual(1, len(opened))
            self._assert_connection_closed(self, opened[0])

    def test_backup_failure_closes_source_and_in_memory_destination(self) -> None:
        class BackupFailureConnection:
            def __init__(self, connection):
                self.connection = connection

            @property
            def in_transaction(self):
                return self.connection.in_transaction

            def execute(self, *args, **kwargs):
                return self.connection.execute(*args, **kwargs)

            def rollback(self):
                return self.connection.rollback()

            def backup(self, _destination):
                raise sqlite3.OperationalError("fixture backup failure")

            def close(self):
                return self.connection.close()

        with tempfile.TemporaryDirectory() as folder:
            helper = post_effect_tests.Phase6PostEffectQueueTests()
            queue = helper._queue(folder)
            real_connect = sqlite3.connect
            memory_connections = []
            source_connections = []

            def failing_backup_connect(database, *args, **kwargs):
                connection = real_connect(database, *args, **kwargs)
                if database == ":memory:":
                    memory_connections.append(connection)
                    return connection
                source_connections.append(connection)
                return BackupFailureConnection(connection)

            with patch(
                "hero_engine.phase6_av_context.sqlite3.connect",
                new=failing_backup_connect,
            ):
                with self.assertRaisesRegex(
                    sqlite3.OperationalError, "fixture backup failure"
                ):
                    _open_read_snapshot(queue.path)

            self.assertEqual(1, len(memory_connections))
            self.assertEqual(1, len(source_connections))
            self._assert_connection_closed(self, memory_connections[0])
            self._assert_connection_closed(self, source_connections[0])

    def test_noncanonical_tail_selector_is_rejected_by_real_resolver(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            _, root, _, _, _, tail_id = self._terminal_chain(folder)
            with self.assertRaisesRegex(QueueConflict, "canonical authority root"):
                resolve_phase6_av_context(root, expected_root_job_id=tail_id)

    def test_pending_tail_is_observed_but_never_admitted(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper = post_effect_tests.Phase6PostEffectQueueTests()
            root = Path(folder)
            queue = helper._queue(folder)
            receipt = helper._valid_post_effect_receipt(root, queue)
            with self.assertRaisesRegex(
                Phase6AVContextError, "terminal SUCCEEDED and non-executable"
            ):
                resolve_phase6_av_context(
                    root, expected_root_job_id=receipt["root_job"]["job_id"]
                )

    def test_succeeded_tail_without_checkpoint_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            _, root, _, _, root_id, _ = self._terminal_chain(folder, checkpoint={})
            with self.assertRaisesRegex(Phase6AVContextError, "checkpointed"):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)

    def test_input_receipt_tamper_is_rejected_without_queue_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, receipt, root_id, _ = self._terminal_chain(folder)
            before = helper._rows(queue)
            path = root / receipt["authoritative_input_receipt"]["path"]
            path.write_bytes(path.read_bytes() + b" ")
            with self.assertRaisesRegex(
                Phase6AVContextError, "committed reference"
            ):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)
            self.assertEqual(before, helper._rows(queue))

    def test_noncanonical_database_payload_is_not_normalized_into_success(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, _, root_id, tail_id = self._terminal_chain(folder)
            with closing(sqlite3.connect(queue.path)) as connection:
                raw = connection.execute(
                    "SELECT payload_json FROM jobs WHERE job_id=?", (tail_id,)
                ).fetchone()[0]
                value = json.loads(raw)
                connection.execute(
                    "UPDATE jobs SET payload_json=? WHERE job_id=?",
                    (json.dumps(value, sort_keys=True, indent=1), tail_id),
                )
                connection.commit()
            before = helper._rows(queue)
            with self.assertRaisesRegex(Phase6AVContextError, "canonical JSON"):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)
            self.assertEqual(before, helper._rows(queue))

    def test_wrong_operation_is_rejected_before_any_receipt_claim(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, _, root_id, _, = self._terminal_chain(folder)
            with closing(sqlite3.connect(queue.path)) as connection:
                connection.execute(
                    "UPDATE jobs SET operation_id='other-operation' WHERE job_id=?",
                    (root_id,),
                )
                connection.commit()
            before = helper._rows(queue)
            with self.assertRaisesRegex(QueueConflict, "requested authority contract"):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)
            self.assertEqual(before, helper._rows(queue))

    def test_semantically_wrong_media_unit_is_rejected_even_with_valid_receipt(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            _, root, _, _, root_id, _ = self._terminal_chain(folder)
            real_resolver = (
                TransactionalQueue._resolve_media_job_authority_in_connection
            )

            def divergent_resolver(instance, connection, *args, **kwargs):
                resolved = copy.deepcopy(
                    real_resolver(instance, connection, *args, **kwargs)
                )
                unit = resolved["media_unit"]
                unit["target_id"] = "another-prepublication-target"
                semantic = dict(unit)
                semantic.pop("media_unit_key")
                unit["media_unit_key"] = "phase6-media-unit-" + hashlib.sha256(
                    json.dumps(
                        semantic,
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                ).hexdigest()[:24]
                resolved["media_unit_key"] = unit["media_unit_key"]
                return resolved

            # Negative-only fault injection: the wrapper first executes the real
            # resolver and then proves the context boundary does not trust even
            # a self-consistent but out-of-contract unit returned by it.
            with patch.object(
                TransactionalQueue,
                "_resolve_media_job_authority_in_connection",
                new=divergent_resolver,
            ):
                with self.assertRaisesRegex(
                    Phase6AVContextError, "exact Phase-6 Video-2 contract"
                ):
                    resolve_phase6_av_context(root, expected_root_job_id=root_id)

    def test_succeeded_tail_with_impossible_lease_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            helper, root, queue, _, root_id, tail_id = self._terminal_chain(folder)
            with closing(sqlite3.connect(queue.path)) as connection:
                connection.execute(
                    "UPDATE jobs SET lease_owner=?,lease_until=? WHERE job_id=?",
                    ("unexpected-owner", "2026-09-06T04:00:00Z", tail_id),
                )
                connection.commit()
            before = helper._rows(queue)
            with self.assertRaisesRegex(Phase6AVContextError, "unleased"):
                resolve_phase6_av_context(root, expected_root_job_id=root_id)
            self.assertEqual(before, helper._rows(queue))


if __name__ == "__main__":
    unittest.main()
