"""New scope lifecycle tests only; no inherited legacy suite or real observer."""
from copy import deepcopy
from datetime import timedelta
import inspect
from pathlib import Path
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_publicity_replay as R
from tests import test_phase6_av_publicity_v2 as fixture_support


class ReplayScopeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # One explicit fixture pair for this new suite. No real model/media or
        # inherited old test methods are executed; fake PPMs have no authority.
        cls.harness = fixture_support.PublicityV2Tests(methodName="runTest")
        cls.harness.setUp()
        try:
            cls.harness.run_scan()
            cls.proof = cls.harness.verify()
            cls.root = cls.harness.root
            cls.base = {
                "counterproof_binding": R.P.binding(cls.root / "output/verification/verification.json"),
                "expected_source_receipt": R.P.binding(cls.root / "output/scan/receipt.json"),
                "expected_counter_receipt": R.P.binding(cls.root / "output/verification/receipt.json"),
                "expected_timeline": R.P.binding(cls.harness.timeline),
                "expected_library": R.P.binding(cls.harness.library),
                "expected_policy": R.P.binding(cls.harness.policy_path), "require_live": False,
            }
        except BaseException:
            cls.harness.doCleanups()
            raise

    @classmethod
    def tearDownClass(cls):
        cls.harness.doCleanups()

    def setUp(self):
        for name in ("execute", "verify", "owned", "save", "atomic", "LiveBackend", "derive_assets", "_sample_journal"):
            self.enterContext(patch.object(R.P, name, side_effect=AssertionError("SCOPE_EFFECT_FORBIDDEN")))

    def scope(self, **changes):
        return R.verified_counterproof_integrity(self.root, **deepcopy({**self.base, **changes}))

    def files(self):
        return {str(p.relative_to(self.root)): (p.stat().st_size, p.stat().st_mtime_ns)
                for p in self.root.rglob("*") if p.is_file()}

    def clock(self, seconds=1):
        return R.P.utc(self.proof["verified_at"]) + timedelta(seconds=seconds)

    def test_scope_prepares_once_and_rechecks_never_repeat_population_or_scans(self):
        before = self.files()
        with patch.object(R, "_prepare_replay", wraps=R._prepare_replay) as prepare, \
             patch.object(R, "_assets", wraps=R._assets) as assets, \
             patch.object(R, "_scan", wraps=R._scan) as scans:
            with self.scope() as view:
                self.assertEqual((prepare.call_count, assets.call_count, scans.call_count), (1, 1, 2))
                first = view.result
                view.recheck(); view.recheck()
                self.assertEqual((prepare.call_count, assets.call_count, scans.call_count), (1, 1, 2))
                self.assertEqual(first["valid_until"], view.result["valid_until"])
            self.assertEqual((prepare.call_count, assets.call_count, scans.call_count), (1, 1, 2))
        self.assertEqual(before, self.files())

    def test_view_returns_deep_copies_and_expires_after_normal_exit(self):
        with self.scope() as view:
            result = view.result
            result["authority"]["publication_authorized"] = True
            result["limitations"].clear()
            result["counterproof"]["sha256"] = "sha256:" + "0" * 64
            self.assertFalse(any(view.result["authority"].values()))
            self.assertEqual(view.result["limitations"], list(R.LIMITATIONS))
            self.assertEqual(view.result["counterproof"], self.base["counterproof_binding"])
        for action in (lambda: view.result, view.recheck):
            with self.subTest(action=action), self.assertRaisesRegex(R.P.PublicityError, "scope is closed"):
                action()

    def test_legacy_api_retains_shape_and_one_final_recheck(self):
        instant = self.clock()
        calls = []
        original = R._Reader.recheck
        def count(reader):
            calls.append(reader)
            return original(reader)
        with patch.object(R, "_clock", return_value=instant), \
             patch.object(R._Reader, "recheck", count), \
             patch.object(R, "_prepare_replay", wraps=R._prepare_replay) as prepare:
            result = R.replay_counterproof(self.root, **self.base, now=instant)
            self.assertEqual(prepare.call_count, 1)
            self.assertEqual(len(calls), 1)
            self.assertEqual(result["replayed_at"], instant.isoformat())
        with patch.object(R, "_clock", return_value=instant):
            with self.scope(now=instant) as view:
                snapshot = view.result
        self.assertEqual(result, snapshot)
        self.assertEqual(set(result), {"version", "status", "evidence_mode", "counterproof", "replayed_at",
            "valid_until", "sample_pairs", "reopened_files", "decode_calls", "inference_calls", "files_written",
            "provider_switch", "technical_cost_brl", "authority", "limitations"})

    def test_final_clock_runs_after_final_byte_recheck(self):
        events = []
        original = R._Reader.recheck
        instant = self.clock()
        def observe_clock():
            events.append("clock")
            return instant
        def recheck(reader):
            result = original(reader)
            events.append("recheck_done")
            return result
        with patch.object(R, "_clock", side_effect=observe_clock), patch.object(R._Reader, "recheck", recheck):
            with self.scope(now=instant) as view:
                self.assertEqual(events, ["recheck_done", "clock"])
                self.assertEqual(view.result["replayed_at"], instant.isoformat())
        self.assertEqual(events, ["recheck_done", "clock", "recheck_done", "clock"])

    def test_expiry_at_closing_equality_rejects_and_expires_view(self):
        entered = self.clock()
        expires = R.P.utc(self.proof["valid_until"])
        with patch.object(R, "_clock", side_effect=[entered, expires]), \
             self.assertRaisesRegex(R.P.PublicityError, "clock rolled back or evidence expired"):
            with self.scope(now=entered) as view:
                self.assertEqual(view.result["replayed_at"], entered.isoformat())
        with self.assertRaisesRegex(R.P.PublicityError, "scope is closed"): _ = view.result

    def test_closing_clock_cannot_roll_back_before_latest_explicit_recheck(self):
        first, second = self.clock(), self.clock(2)
        with patch.object(R, "_clock", side_effect=[first, second, second - timedelta(microseconds=1)]), \
             self.assertRaisesRegex(R.P.PublicityError, "clock rolled back"):
            with self.scope(now=first) as view:
                checked = view.recheck()
                self.assertEqual(checked["replayed_at"], second.isoformat())

    def test_initial_clock_failure_is_not_masked_by_second_close(self):
        entered = self.clock()
        with patch.object(R, "_clock", return_value=R.P.utc(self.proof["valid_until"])) as clock, \
             self.assertRaisesRegex(R.P.PublicityError, "clock rolled back or evidence expired"):
            with self.scope(now=entered): self.fail("expired replay cannot yield")
        self.assertEqual(clock.call_count, 1)

    def test_source_drift_during_open_scope_is_detected_at_close(self):
        original = self.harness.media.read_bytes()
        self.addCleanup(self.harness.media.write_bytes, original)
        with self.assertRaises(R.P.PublicityError):
            with self.scope():
                self.harness.media.write_bytes(b"DECLARED_FIXTURE_CHANGE_AFTER_PREPARATION")

    def test_caught_recheck_failure_poisoning_prevents_later_success(self):
        original = self.harness.media.read_bytes()
        self.addCleanup(self.harness.media.write_bytes, original)
        with self.assertRaisesRegex(R.P.PublicityError, "previously failed"):
            with self.scope() as view:
                self.harness.media.write_bytes(b"DECLARED_FIXTURE_TRANSIENT_CORRUPTION")
                with self.assertRaises(R.P.PublicityError): view.recheck()
                self.harness.media.write_bytes(original)
                with self.assertRaisesRegex(R.P.PublicityError, "previously failed"): _ = view.result

    def test_consumer_exception_propagates_but_still_closes_its_reader(self):
        calls = []
        original = R._Reader.recheck
        def count(reader):
            calls.append(reader)
            return original(reader)
        with patch.object(R._Reader, "recheck", count), self.assertRaisesRegex(RuntimeError, "CONSUMER_INTERRUPTED"):
            with self.scope() as view:
                raise RuntimeError("CONSUMER_INTERRUPTED")
        self.assertEqual(len(calls), 2)
        self.assertIs(calls[0], calls[1])
        with self.assertRaisesRegex(R.P.PublicityError, "scope is closed"): view.recheck()

    def test_external_binding_mutation_cannot_change_retained_scope(self):
        arguments = deepcopy(self.base)
        with R.verified_counterproof_integrity(self.root, **arguments) as view:
            arguments["counterproof_binding"]["sha256"] = "sha256:" + "0" * 64
            arguments["expected_policy"]["path"] = "UNTRUSTED_MUTATED_CALLER_VALUE"
            self.assertEqual(view.recheck()["counterproof"], self.base["counterproof_binding"])

    def test_scope_final_recheck_authenticates_the_actual_returned_buffer(self):
        original = R.P.reopen
        substitute = {"active": False}
        def reopen(root, item, **kwargs):
            raw = original(root, item, **kwargs)
            if substitute["active"] and item == self.base["expected_timeline"]: return b'{"render_spans":[]}'
            return raw
        with patch.object(R.P, "reopen", side_effect=reopen), \
             self.assertRaisesRegex(R.P.PublicityError, "returned replay buffer"):
            with self.scope(): substitute["active"] = True

    def test_new_entry_keeps_default_live_guard_and_rejects_prepared_arguments(self):
        expected = {"root", "counterproof_binding", "expected_source_receipt", "expected_counter_receipt",
                    "expected_timeline", "expected_library", "expected_policy", "require_live", "now"}
        for function in (R.verified_counterproof_integrity, R.replay_counterproof):
            self.assertEqual(set(inspect.signature(function).parameters), expected)
            self.assertIs(inspect.signature(function).parameters["require_live"].default, True)
        arguments = {k: v for k, v in self.base.items() if k != "require_live"}
        with self.assertRaisesRegex(R.P.PublicityError, "LIVE counterproof required"):
            with R.verified_counterproof_integrity(self.root, **arguments): pass
        with self.assertRaises(TypeError): self.scope(prepared={"status": "PASS_LIVE"})
        with self.assertRaisesRegex(R.P.PublicityError, "explicit boolean"):
            with self.scope(require_live=1): pass


if __name__ == "__main__":
    unittest.main()
