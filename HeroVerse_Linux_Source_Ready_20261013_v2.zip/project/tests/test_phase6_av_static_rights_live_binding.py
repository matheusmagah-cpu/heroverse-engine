"""Real D171 still-rights -> B row binding, NOT a complete admission test.

No synthetic words, output timings, production timeline, public claim or effects.
The scope is the exact eleven externally reviewed stills. Stage A and every
remaining audiovisual gate must still pass separately before a video can run.
"""
import json
from pathlib import Path
import socket
import subprocess
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_admission as admission
from hero_engine import phase6_av_static_sources as sources
from hero_engine.phase6_narration_units import canonical_sha

ROOT = Path(__file__).absolute().parents[1]
REGISTRATION = "output/operations/phase6/av-admission/evidence/static-rights-registrations/d171-static-rights-registration-03fbe1403d7f7252019f42ec.json"
REGISTRATION_SHA = "36857c5ba11f8b6d37530a77b694adc46167706ebb3c6e5946a9b69a60d01fab"


def relative_pin(pin):
    return {"path": Path(pin["path"]).relative_to(ROOT).as_posix(), "sha256": "sha256:" + pin["sha256"]}


class RealStaticRightsConsumerTests(unittest.TestCase):
    def test_eleven_real_registered_stills_bind_the_live_rights_consumer_without_admitting_video(self):
        raw = (ROOT / REGISTRATION).read_bytes()
        self.assertEqual(sources._sha(raw), REGISTRATION_SHA)
        registration = json.loads(raw)
        self.assertEqual(registration["state_count"], 11)
        self.assertEqual(registration["lineage_count"], 2)
        self.assertEqual(registration["status"], "REGISTERED_RIGHTS_ONLY_NOT_ADMITTED")
        self.assertTrue(all(value is False for value in registration["authority"].values()))
        entries = registration["request"]["states"]
        self.assertEqual(len(entries), 11)
        self.assertEqual(len(registration["rights_proofs"]), 11)
        requests = [{name: entry["arguments"][name] for name in ("template_id", "state_id", "receipt_binding")}
                    for entry in entries]
        # Independent exact source inspection, not a hash borrowed from the
        # rights candidate. This uses A's actual compact canonical serializer.
        with patch.object(subprocess, "run", side_effect=AssertionError("no process")), \
             patch.object(subprocess, "Popen", side_effect=AssertionError("no process")), \
             patch.object(socket, "socket", side_effect=AssertionError("no network")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("no writes")), \
             patch.object(Path, "write_text", side_effect=AssertionError("no writes")):
            observed = sources.inspect_static_sources(ROOT, requests=requests)
            reopened = []
            for entry, saved, source in zip(entries, registration["rights_proofs"], observed):
                with self.subTest(state=entry["asset_id"]):
                    self.assertEqual(saved["asset_id"], entry["asset_id"])
                    self.assertEqual(saved["status"], "PASS")
                    self.assertEqual(saved["evidence_mode"], "LIVE")
                    self.assertEqual(saved["source_proof"]["timeline_canonical_sha256"], canonical_sha(source))
                    self.assertNotEqual(canonical_sha(source), "sha256:" + saved["source_proof"]["sha256"])
                    source_binding = relative_pin(source["asset_binding"])
                    static_source = {"template_id": source["template_id"], "state_id": source["state_id"],
                                     "receipt_binding": relative_pin(entry["arguments"]["receipt_binding"])}
                    row = {"asset_id": entry["asset_id"], **source_binding, "status": "PASS", "rights_status": "OWNED",
                           "media_kind": "STATIC_IMAGE", "static_rights": {
                               "provenance_binding": relative_pin(entry["arguments"]["provenance_binding"]),
                               "decision_binding": relative_pin(entry["arguments"]["decision_binding"]),
                               "inspection_id": saved["inspection_id"], "inspection_sha256": canonical_sha(saved)}}
                    required = {**source_binding, "media_kind": "STATIC_IMAGE", "static_source": static_source,
                                "static_inspection": {"inspection_id": source["inspection_id"],
                                                      "inspection_sha256": canonical_sha(source)}}
                    proof = admission._validate_static_rights_row(ROOT, row, required)
                    self.assertEqual(proof, saved)
                    self.assertEqual(proof["scope"], "RIGHTS_BINDING_ONLY")
                    self.assertFalse(proof["source_ready"])
                    self.assertTrue(all(value is False for value in proof["authority"].values()))
                    reopened.append(proof)
            admission._recheck_static_rights_dependencies(ROOT, reopened)
        self.assertEqual((ROOT / REGISTRATION).read_bytes(), raw)
        self.assertEqual(len(reopened), 11)


if __name__ == "__main__":
    unittest.main()
