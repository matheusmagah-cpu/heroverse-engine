"""A7 metadata integration fixtures, NOT a real A build or PCM verification.

The original A6 metadata and frozen cap71 bytes are reused. Upstream source/PCM
verification is explicitly mocked in the bounded build harness; no media decode,
new audio, timestamp inference, publication or production evidence is created.
"""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError

from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_caption_intent as captions
from hero_engine.phase6_narration_audio_inventory import Reader
from tests import test_phase6_av_caption_intent as caption_inputs

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = "output/operations/phase6/av-admission/arguments/phase6-av-arguments-909f7dbda35486e03726cf1a.json"
BUNDLE_SHA = "sha256:d1e4c73ebb8423163c0c87b4fedc68a6d188a1191e342c4302102891f2a8d42b"


def frozen(binding):
    raw = (ROOT / binding["path"]).read_bytes()
    if av.bytes_sha(raw) != binding["sha256"]:
        raise AssertionError("frozen metadata changed")
    return raw


class CaptionIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = json.loads(frozen(caption_inputs.TIMELINE))
        cls.bundle = json.loads(frozen({"path": BUNDLE, "sha256": BUNDLE_SHA}))
        cls.source_bindings = {key: value for key, value in cls.bundle["arguments"]["source_bindings"].items() if key in av.CORE}
        cls.data = {key: json.loads(frozen(binding)) for key, binding in cls.source_bindings.items()}
        cls.metadata = {binding["path"]: frozen(binding) for binding in (
            captions.PLAN_BINDING, captions.SOURCE, captions.PRIMITIVE,
            {key: captions.IMPLEMENTATION[key] for key in ("path", "sha256")})}
        cls.visual = json.loads(frozen(cls.bundle["arguments"]["source_bindings"]["visual_intent"]))
        cls.schema = json.loads((ROOT / av.SCHEMA).read_bytes())

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="av-caption-integration-fixture-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        for name, raw in self.metadata.items():
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        self.units = copy.deepcopy(self.original["units"])
        self.proof = captions.read_caption_intent(Reader(self.root), captions.PLAN_BINDING, self.units)

    def args(self):
        return {"source_bindings": {**copy.deepcopy(self.source_bindings), "caption_intent": copy.deepcopy(captions.PLAN_BINDING)},
                "pause_decisions": [], "render_spans": [], "visual_events": [], "caption_cues": [],
                "temporal_evidence_bindings": {}, "temporal_policy_binding": None}

    def metadata_build(self, args=None):
        # Explicit test seam: A's upstream source/PCM verification is NOT being
        # claimed here. All new caption/scope/scheduling/schema code is real.
        with mock.patch.object(av, "_sources", return_value=copy.deepcopy(self.data)), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(self.units), copy.deepcopy(self.original["narration_fragment_map"]))), \
             mock.patch.object(av, "inspect_pcm", side_effect=AssertionError("no decode")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no effects")):
            return av.build(self.root, **(args or self.args()))

    def actual(self, index):
        row = self.proof["cues"][index]
        unit = next(unit for unit in self.units if unit["unit_id"] == row["unit_id"])
        whole = row["timing_state"] == captions.WHOLE
        return {**{key: copy.deepcopy(row[key]) for key in ("cue_id", "unit_id", "char_start", "char_end", "text", "lines")},
            "start_sample": unit["pcm_start_sample"] if whole else None,
            "end_sample": unit["pcm_end_sample_exclusive"] if whole else None,
            "timing_basis": "WHOLE_UNIT_PCM_BOUNDS" if whole else "CALIBRATED_TEXT_RANGE",
            "alignment_id": None, "maximum_uncertainty_samples": None}

    def test_real_plan_metadata_declares_17_but_visual_scope_and_holdout_stay_blocked(self):
        args = self.args()
        forbidden = {"path": "temporal-must-not-be-read.json", "sha256": "sha256:" + "0" * 64}
        args["temporal_policy_binding"] = forbidden
        args["temporal_evidence_bindings"] = {"unavailable": forbidden}
        result = self.metadata_build(args)
        assessment = result["temporal_evidence_assessment"]
        self.assertEqual((result["schema_version"], result["timeline_version"]), ("1.11.0", "phase6-av-timeline-v12"))
        self.assertEqual(assessment["declared_target_unit_ids"], self.proof["lexical_unit_ids"])
        self.assertEqual(len(assessment["conservative_exclusion_unit_ids"]), 51)
        self.assertFalse(assessment["scope_complete"])
        self.assertFalse(assessment["all_required_evidence_live"])
        self.assertEqual(result["status"], "BLOCKED_INCOMPLETE")
        self.assertIn("TEMPORAL_CAPTION_SCHEDULE_INCOMPLETE", result["blockers"])
        self.assertEqual(result["caption_cues"], [])
        self.assertIsNone(result["derived_take_plan"])
        self.assertTrue(all(flag is False for flag in result["authority"].values()))
        self.assertEqual(result["caption_intent_evidence"]["inspection_sha256"], av.canonical_sha(self.proof))
        self.assertEqual(result["caption_intent_evidence"]["cue_count"], 71)
        self.assertEqual(len(result["implementation_dependencies"]), 40)
        self.assertIn(av.CAPTION_TEXTWRAP_BINDING, result["implementation_dependencies"])
        self.assertTrue(any(row["path"] == "hero_engine/phase6_av_caption_intent.py" for row in result["implementation_dependencies"]))
        self.assertFalse(any(row["path"] == forbidden["path"] for row in result["source_file_bindings"]))

    def test_partial_static_and_caption_targets_union_is_21_not_global_26_or_51(self):
        data = {"visual_intent": self.visual}
        declared = av._temporal_target_units(data, [], {unit["unit_id"] for unit in self.units},
            units=self.units, render_spans=[], visual_events=[])
        declared = sorted(set(declared) | set(self.proof["lexical_unit_ids"]))
        scope = av._temporal_scope(data, [], self.units, declared, [], [], self.original["duration"]["planned_total_samples"], caption_intent=self.proof)
        self.assertEqual(len(scope["declared_target_unit_ids"]), 21)
        self.assertEqual(len(scope["conservative_exclusion_unit_ids"]), 51)
        self.assertFalse(scope["scope_complete"])
        # D169 minimum 26 remains additional unresolved editorial intent, not
        # replaced by this partial bundle's 21 known declarations.

    def test_caption_scope_uses_literal_ranges_not_complete_flag_or_timestamps(self):
        total = self.original["duration"]["planned_total_samples"]
        intent = {"span_contracts": [{"span_id": "fixture-hold", "fragment_ids": [tid for unit in self.units for tid in unit["take_ids"]]}],
                  "event_requirements": [{"event_id": "fixture-event", "span_id": "fixture-hold"}]}
        spans = [{"span_id": "fixture-hold", "start_frame": 0, "end_frame": total // 800}]
        events = [{"event_id": "fixture-event"}]
        # Scope-only structural fixture, NOT a valid visual contract or a claim
        # that its synthetic HOLD could pass _visual/production.
        scope = av._temporal_scope({"visual_intent": intent}, [], self.units, self.proof["lexical_unit_ids"], spans, events, total, caption_intent=self.proof)
        self.assertTrue(scope["scope_complete"])
        bad = copy.deepcopy(self.proof)
        bad["cues"].pop()
        self.assertTrue(bad["literal_caption_coverage_complete"])
        changed = av._temporal_scope({"visual_intent": intent}, [], self.units, self.proof["lexical_unit_ids"], spans, events, total, caption_intent=bad)
        self.assertFalse(changed["scope_complete"])
        self.assertIn("narration-unit-051", changed["unknown_scope_unit_ids"])

    def test_actual_cues_must_be_exact_ordered_subset_and_keep_timing_class(self):
        first, second, internal = self.actual(0), self.actual(1), self.actual(2)
        av._validate_caption_intent_subset([first, second, internal], self.proof)
        for mutate in (
            lambda row: row.update(text="Pause!"), lambda row: row.update(lines=["Pau", "se."]),
            lambda row: row.update(char_end=5), lambda row: row.update(char_start=0.0),
            lambda row: row.update(unit_id="narration-unit-002"),
            lambda row: row.update(cue_id="not-in-plan"),
            lambda row: row.update(timing_basis="CALIBRATED_TEXT_RANGE"),
        ):
            altered = copy.deepcopy(first)
            mutate(altered)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                av._validate_caption_intent_subset([altered], self.proof)
        internal["timing_basis"] = "WHOLE_UNIT_PCM_BOUNDS"
        for values in ([internal], [first, first], [second, first]):
            with self.assertRaises(ValueError):
                av._validate_caption_intent_subset(values, self.proof)

    def test_actual_whole_cue_is_not_auto_created_and_internal_null_times_cannot_schedule(self):
        args = self.args()
        args["caption_cues"] = [self.actual(0)]
        result = self.metadata_build(args)
        self.assertEqual(result["caption_cues"], args["caption_cues"])
        self.assertIn("CAPTION_COVERAGE_INCOMPLETE:narration-unit-003", result["blockers"])
        self.assertFalse(result["temporal_evidence_assessment"]["all_required_evidence_live"])
        args["caption_cues"] = [self.actual(2)]  # Literal range is valid, timing remains null.
        with self.assertRaisesRegex(ValueError, "start_sample.*integer"):
            self.metadata_build(args)

    def test_source_dispatch_keeps_core_and_rejects_rebound_or_copied_plan_before_pcm(self):
        class EnteredSourceRead(Exception):
            pass
        reader = mock.Mock()
        reader.load.side_effect = EnteredSourceRead
        for optional in ({}, {"caption_intent": captions.PLAN_BINDING}, {"visual_intent": {"fixture": True}},
                         {"caption_intent": captions.PLAN_BINDING, "visual_intent": {"fixture": True}}):
            with self.assertRaises(EnteredSourceRead):
                av._sources(reader, {**self.source_bindings, **optional})
        for binding in ({**captions.PLAN_BINDING, "sha256": "sha256:" + "0" * 64},
                        {**captions.PLAN_BINDING, "path": "copied-plan.json"}):
            with self.assertRaisesRegex(ValueError, "exact frozen v2"):
                av._sources(reader, {**self.source_bindings, "caption_intent": binding})
        missing = copy.deepcopy(self.source_bindings)
        missing.pop("inventory")
        for candidate in (missing, {**self.source_bindings, "other_source": captions.PLAN_BINDING}):
            with self.assertRaisesRegex(ValueError, "complete caller-pinned"):
                av._sources(reader, candidate)

    def test_final_recheck_detects_caption_drift_and_textwrap_pin_never_allows_arbitrary_code(self):
        original_captions = av._captions
        path = self.root / captions.PLAN_BINDING["path"]

        def mutate_after_inspection(*args, **kwargs):
            result = original_captions(*args, **kwargs)
            path.write_bytes(path.read_bytes() + b"\n")  # Isolated fixture only.
            return result

        with mock.patch.object(av, "_captions", side_effect=mutate_after_inspection), self.assertRaises(ValueError):
            self.metadata_build()
        with mock.patch.object(av.textwrap, "__file__", str(self.root / "fake.py")), self.assertRaisesRegex(ValueError, "path differs"):
            av._caption_textwrap_pin()
        with mock.patch.object(av, "CAPTION_TEXTWRAP_BINDING", {**av.CAPTION_TEXTWRAP_BINDING, "sha256": "sha256:" + "0" * 64}), \
             self.assertRaisesRegex(ValueError, "bytes differ"):
            av._caption_textwrap_pin()

    def test_schema_preserves_real_a6_and_requires_new_evidence_only_for_a7(self):
        validator = Draft202012Validator(self.schema)
        validator.validate(self.original)  # Exact old receipt, no rebuilding it.
        current = self.metadata_build()
        validator.validate(current)
        for mutate in (
            lambda row: row.update(caption_intent_evidence=None),
            lambda row: row["caption_intent_evidence"].update(cue_count=70),
            lambda row: row["caption_intent_evidence"].update(global_schedule_created=True),
            lambda row: row["caption_intent_evidence"].update(calibrated_timing_available=True),
            lambda row: row.update(schema_version="1.5.0", timeline_version="phase6-av-timeline-v6"),
        ):
            candidate = copy.deepcopy(current)
            mutate(candidate)
            with self.subTest(mutate=mutate), self.assertRaises(ValidationError):
                validator.validate(candidate)
        legacy = copy.deepcopy(self.original)
        legacy["inputs"]["source_bindings"]["caption_intent"] = captions.PLAN_BINDING
        with self.assertRaises(ValidationError):
            validator.validate(legacy)


if __name__ == "__main__":
    unittest.main()
