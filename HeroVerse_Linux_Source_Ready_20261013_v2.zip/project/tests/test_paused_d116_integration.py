"""T23 real composed D-116 consumer; only temporary roots and synthetic runtime.

T20 fixture runs a tiny real regression and real in-process paused application.
OS/process-exit observation of that application and the later runtime are
explicit synthetic witnesses, never proof of a production restart.
"""
from __future__ import annotations
import copy
import io
import json
import subprocess
import sys
import time
import unittest
from contextlib import redirect_stdout
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from hero_engine import maintenance_paused_application as a
from hero_engine import maintenance_protocol as p
from hero_engine import phase6_maintenance_verification as d
from hero_engine.phase6_control_cycle import STAGES, materialize as cycle_materialize
import tests.test_paused_maintenance_application as application_tests

ROOT = Path(__file__).resolve().parents[1]


def bind_fixture_projection(root, cycle, *, real_executive=False):
    """Seal synthetic runtime witnesses using the real current-chain projector.

    This changes only temporary fixture outputs, never authentication or the
    tests' subsequent tampering. Publication/runtime checks remain independent.
    """
    from hero_engine.phase6_control_cycle import completed_projection_binding
    stage = next(item for item in cycle['stages'] if item['stage'] == 'GOAL_TRAJECTORY')
    goal = p._read(root / stage['snapshot_path'])
    executive = p._read(root / d.EXECUTIVE_PATH)
    binding = completed_projection_binding(
        cycle, p.file_hash(root / d.CYCLE_PATH), goal, p.file_hash(root / stage['snapshot_path']))
    if real_executive:
        # Reporting integration must validate its actual producer output,
        # never repair the very binding under test with fixture assignments.
        if (executive.get('producer_binding') != binding
                or executive['goal_trajectory']['trajectory_id'] != goal['trajectory_id']):
            raise AssertionError('real reporter did not bind its completed trajectory')
    else:
        executive['goal_trajectory']['trajectory_id'] = goal['trajectory_id']
        executive['producer_binding'] = binding
        d._write(root / d.EXECUTIVE_PATH, executive)
    acceptance = p._read(root / d.ACCEPTANCE_PATH)
    acceptance['executive_evidence'] = {
        **executive['producer_binding'], 'executive_sha256': p.file_hash(root / d.EXECUTIVE_PATH)}
    acceptance['generated_at'] = max(acceptance['generated_at'], executive['captured_at'])
    d._write(root / d.ACCEPTANCE_PATH, acceptance)


class PausedD116IntegrationTests(unittest.TestCase):
    _json = staticmethod(application_tests.PausedMaintenanceApplicationTests._json)
    _write = application_tests.PausedMaintenanceApplicationTests._write
    _seal = application_tests.PausedMaintenanceApplicationTests._seal
    _protected_bytes = application_tests.PausedMaintenanceApplicationTests._protected_bytes

    def _make_proof(self):
        # D-116's new consumer schemas must be part of the fixture candidate
        # BEFORE its regression/application, not added after the pinned proof.
        for name in ('phase6_paused_application_reference.schema.json',
                     'phase6_post_maintenance_verification.schema.json',
                     'central_manager_autostart_verification.schema.json',
                     'phase6_acceptance_report.schema.json'):
            (self.root/'schemas'/name).write_bytes((ROOT/'schemas'/name).read_bytes())
        application_tests.PausedMaintenanceApplicationTests._make_proof(self)
        if getattr(getattr(self, self._testMethodName), 'fixture_scenario', None) == 'proof_alias':
            canonical = self.envelope
            self.envelope = canonical.with_name('application-envelope-recovery-20261002.json')
            self.envelope.write_bytes(canonical.read_bytes())
            self.assertEqual(self.anchor, p.file_hash(self.envelope))

    def setUp(self):
        application_tests.PausedMaintenanceApplicationTests.setUp(self)
        started = datetime.now(timezone.utc)
        clock = time.monotonic()
        self.commit = application_tests.PausedMaintenanceApplicationTests._invoke(self)
        finished = datetime.now(timezone.utc)
        self.run = next((self.root / a.RUNS).glob('maintenance-request-*'))
        self.process_dir = self.root / a.RUNS / 'synthetic-application-process'
        self.process_dir.mkdir()
        self.process = dict(command=[str(self.root/'.venv/Scripts/python.exe'),'-B','-m','hero_engine.maintenance_protocol',
            '--root',str(self.root),'apply-paused','--proof-envelope',self.envelope.relative_to(self.root).as_posix(),
            '--expected-proof-hash',self.anchor,'--expected-candidate-hash',self.candidate],
            pid=123456,started_at=started.isoformat(),finished_at=finished.isoformat(),wall_seconds=time.monotonic()-clock,
            exit_code=0,automatic_retry=False,supervisor_restart_authorized=False)
        self._json(self.process_dir/'process-result.json',self.process)
        self._json(self.process_dir/'application.stdout.log',self.commit)
        (self.process_dir/'application.stderr.log').write_bytes(b'')
        self.reference_path = self.process_dir/'paused-application-reference.json'
        self.reference = dict(schema_version='1.0.0',commit_path=(self.run/'committed.json').relative_to(self.root).as_posix(),
            commit_sha256=p.file_hash(self.run/'committed.json'),proof_path=self.envelope.relative_to(self.root).as_posix(),
            proof_sha256=self.anchor,candidate_sha256=self.candidate,
            process_path=(self.process_dir/'process-result.json').relative_to(self.root).as_posix(),
            process_sha256=p.file_hash(self.process_dir/'process-result.json'),
            stdout_sha256=p.file_hash(self.process_dir/'application.stdout.log'),stderr_sha256=p.file_hash(self.process_dir/'application.stderr.log'))
        self._reference()
        self.at = finished
        self.verified = (finished+timedelta(seconds=40)).isoformat()
        # Real cycle producer on explicit synthetic stage records; no run_cycle.
        for stage in STAGES:
            value = p._read(self.root/stage['path'])
            value[stage['time_field']] = (finished+timedelta(seconds=12)).isoformat()
            self._json(self.root/stage['path'],value)
        self.cycle = cycle_materialize(self.root,cycle_started_at=finished+timedelta(seconds=10),
                                      cycle_completed_at=finished+timedelta(seconds=20))
        runtime = p._read(ROOT/d.AUTOSTART_PATH)
        runtime.update(schema_version='1.1.0',manager_pid=4242,manager_alive=True,task_state='Running',
            lock_state='HELD',lock_holder_pid=4242,lock_heartbeat_at=(finished+timedelta(seconds=25)).isoformat(),
            lease_expires_at=(finished+timedelta(seconds=120)).isoformat(),review_console_status='LISTENING',review_process_id=4242,
            same_process_chain=True,duplicate_probe_exit_code=73,duplicate_probe_blocked=True,active_stderr_bytes=0,
            power_continuity_status='PASS',continuous_awake=True,operational_ready=True,verified_at=(finished+timedelta(seconds=30)).isoformat(),
            process_identity=dict(pid=4242,parent_pid=4241,started_at=(finished+timedelta(seconds=1)).isoformat(),
                executable_path_sha256='sha256:'+'a'*64,command_sha256='sha256:'+'b'*64,stable_across_probe=True))
        self._json(self.root/d.AUTOSTART_PATH,runtime)
        acceptance = p._read(ROOT/d.ACCEPTANCE_PATH)
        for check in acceptance['checks']:
            check['status'] = 'WAITING_REAL_EVIDENCE' if check['check_id'] in {'GC-01','GC-11','GC-19'} else 'PASS_LIVE'
        acceptance.update(generated_at=(finished+timedelta(seconds=31)).isoformat(),phase_decision='IN_PROGRESS',
                          current_phase_ready=False,blocking_check_ids=['GC-01','GC-11','GC-19'],
                          schema_version='1.1.0',control_cycle_evidence={'cycle_id':self.cycle['cycle_id'],
                          'content_hash':p.file_hash(self.root/d.CYCLE_PATH)})
        self._json(self.root/d.ACCEPTANCE_PATH,acceptance)
        executive = p._read(self.root/d.EXECUTIVE_PATH)
        executive.update(status='ACTIVE_OBSERVING',attention_items=[],captured_at=(finished+timedelta(seconds=32)).isoformat(),
                         control_cycle={key:self.cycle[key] for key in ('cycle_id','decision','change_class','stage_count','all_schemas_valid',
                             'all_stages_executed_in_cycle','blockers','cycle_completed_at','substantive_signature')})
        self._json(self.root/d.EXECUTIVE_PATH,executive)
        bind_fixture_projection(self.root, self.cycle)
        self.assertEqual(self.candidate,a.candidate_identity(self.root)['source_set_sha256'])

    def _reference(self):
        self._json(self.reference_path,self.reference)
        self.reference_anchor=p.file_hash(self.reference_path)

    def _direct_reference(self):
        """Select the real forward direct-protocol family, never copied stdout."""
        self.reference_path = a.write_direct_paused_application_reference(
            self.root, run=self.run, binding=self.commit["binding"]
        )
        self.reference = p._read(self.reference_path)
        self.reference_anchor = p.file_hash(self.reference_path)

    def _build(self):
        return d.build(self.root,verified_at=self.verified,paused_application_reference=self.reference_path.relative_to(self.root),
                       expected_reference_hash=self.reference_anchor)

    def _reject(self,pattern='.'):
        with self.assertRaisesRegex((PermissionError,ValueError,KeyError),pattern): self._build()
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_public_build_and_materialization_archive_five_exact_snapshots(self):
        result=self._build()
        self.assertEqual('1.1.0',result['schema_version'])
        self.assertEqual('PASS',result['status'])
        self.assertEqual(self.process['finished_at'],result['maintenance']['completed_at'].replace('Z','+00:00'))
        self.assertEqual('APPLIED_WHILE_PAUSED',result['maintenance']['application_status'])
        output=io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(0,d.main(['--root',str(self.root),'--paused-application-reference',self.reference_path.relative_to(self.root).as_posix(),
                 '--expected-reference-hash',self.reference_anchor,'--verified-at',self.verified]))
        receipt=p._read(self.root/d.BASE/'latest.json')
        self.assertEqual(result,receipt)
        for section in ('maintenance','runtime','control_cycle','acceptance','executive'):
            evidence=receipt[section]
            self.assertEqual((self.root/evidence['path']).read_bytes(),(self.root/evidence['snapshot_path']).read_bytes())
            self.assertEqual(p.file_hash(self.root/evidence['snapshot_path']),evidence['content_hash'])
        self.assertEqual(self.pause.read_bytes(),self.originals[str(p.RUNTIME/'PAUSE')])

    def test_direct_protocol_reference_uses_transaction_records_not_synthetic_stdout(self):
        self._direct_reference()
        self.assertEqual("1.1.0", self.reference["schema_version"])
        self.assertEqual("DIRECT_PROTOCOL", self.reference["reference_kind"])
        # The direct branch must not rely on or manufacture the legacy parent
        # witness; removal of this synthetic fixture leaves the real records
        # and D-116 history reader sufficient.
        import shutil
        shutil.rmtree(self.process_dir)
        result = self._build()
        self.assertEqual("PASS", result["status"])
        self.assertNotIn("process_path", result["maintenance"])

    def test_direct_protocol_reference_rejects_transaction_journal_tamper(self):
        self._direct_reference()
        (self.run/'local-runtime-migration-journal.json').write_bytes(b'{}')
        self._reject('PAUSED_APPLICATION_REPEAT_EVIDENCE_DIVERGED')

    @application_tests.scenario('proof_alias')
    def test_direct_reference_alias_composed_commit_reader_and_materialization(self):
        self._direct_reference()
        self.assertEqual(self.envelope.relative_to(self.root).as_posix(), self.reference['proof_path'])
        self.assertEqual(self.commit['binding']['proof_path'], self.reference['proof_path'])
        before = self.reference_path.read_bytes()
        self._direct_reference()
        self.assertEqual(before, self.reference_path.read_bytes())
        self.assertEqual('PASS', self._build()['status'])
        with redirect_stdout(io.StringIO()):
            self.assertEqual(0, d.main(['--root', str(self.root), '--paused-application-reference',
                self.reference_path.relative_to(self.root).as_posix(), '--expected-reference-hash',
                self.reference_anchor, '--verified-at', self.verified]))
        receipt = p._read(self.root/d.BASE/'latest.json')
        for name in ('maintenance', 'runtime', 'control_cycle', 'acceptance', 'executive'):
            evidence = receipt[name]
            self.assertEqual((self.root/evidence['path']).read_bytes(),
                             (self.root/evidence['snapshot_path']).read_bytes())
            self.assertEqual(p.file_hash(self.root/evidence['snapshot_path']), evidence['content_hash'])
        self.assertEqual(self.originals[str(p.RUNTIME/'PAUSE')], self.pause.read_bytes())

    @application_tests.scenario('proof_alias')
    def test_legacy_reference_keeps_canonical_envelope_name_requirement(self):
        # The legacy OS process witness remains its original schema contract.
        from jsonschema import ValidationError
        with self.assertRaises(ValidationError):
            p.validate(self.root, 'phase6_paused_application_reference.schema.json', self.reference)

    @application_tests.scenario('proof_alias')
    def test_direct_reference_alias_rejects_path_identity_and_proof_tamper(self):
        self._direct_reference()
        original = copy.deepcopy(self.reference)
        for key, value in (('proof_path', self.envelope.with_name('application-envelope.json').relative_to(self.root).as_posix()),
                           ('candidate_sha256', '0'*64), ('proof_sha256', 'sha256:'+'0'*64)):
            with self.subTest(key=key):
                self.reference = {**original, key: value}
                self._reference()
                self._reject('BINDING_DIVERGED')
        self.reference = original
        self._reference()
        self.envelope.write_bytes(self.envelope.read_bytes()+b'\n')
        self._reject('^proof envelope hash differs$')

    def test_mutable_live_state_can_advance_without_rewriting_archives(self):
        self.assertNotEqual((self.root/d.EXECUTIVE_PATH).read_bytes(),(self.run/'views-before'/d.EXECUTIVE_PATH).read_bytes())
        self._json(self.root/'output/operations/synthetic-after-restart.json',{'new_cycle':True})
        self.assertEqual('PASS',self._build()['status'])

    def test_current_candidate_changed_is_rejected(self):
        with (self.root/'tests/test_contract.py').open('a') as f:f.write('\n# changed after application\n')
        self._reject('CANDIDATE_DIVERGED')

    def test_swapped_candidate_binding_is_rejected(self):
        self.reference['candidate_sha256']='0'*64;self._reference();self._reject('BINDING_DIVERGED')

    def test_commit_tampered_is_rejected(self):
        (self.run/'committed.json').write_bytes(b'{}');self._reject('EVIDENCE_CHANGED')

    def test_archived_commit_evidence_tampered_is_rejected(self):
        (self.run/'after.json').write_bytes(b'{}');self._reject('EVIDENCE_DIVERGED')

    def test_regression_log_tampered_is_rejected(self):
        (self.proof_dir/'unittest.stderr.log').write_bytes(b'OK');self._reject('PROOF_FILE_DIVERGED')

    def test_missing_proof_blocks_without_legacy_fallback(self):
        missing=self.proof_dir/'dependencies-before.json'
        missing.unlink()
        # The native protected reader fails closed before an ordinary open;
        # require this exact missing proof, not a failure of a legacy fallback.
        with self.assertRaisesRegex(PermissionError,'^CANCEL_FILE_EXCLUSIVITY_UNAVAILABLE: dependencies-before.json$'):
            self._build()
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_new_live_error_is_not_ignored_by_historical_archive_scope(self):
        self._json(self.root/'output/operations/phase6/control-cycle-error.json',{'error':'synthetic later error'})
        self._reject('error files remain')

    def test_process_exit_and_chronology_are_rejected(self):
        for change in ({'exit_code':1},{'finished_at':self.process['started_at']},
                       {'command':self.process['command']+['--force']}):
            with self.subTest(change=list(change)):
                self._json(self.process_dir/'process-result.json',{**self.process,**change})
                self.reference['process_sha256']=p.file_hash(self.process_dir/'process-result.json');self._reference()
                self._reject('PROCESS|APPLICATION_TIME')

    def test_runtime_identity_or_restart_before_application_blocks(self):
        path=self.root/d.AUTOSTART_PATH; original=p._read(path)
        for value in (dict(original,lock_holder_pid=99),dict(original,process_identity={**original['process_identity'],
                            'started_at':self.process['started_at']})):
            with self.subTest(identity=value['lock_holder_pid']):
                self._json(path,value);self._reject('identity|chronology')

    def test_stale_cycle_cannot_use_date_embedded_in_application_id(self):
        value=p._read(self.root/d.CYCLE_PATH)
        value['cycle_started_at']=self.process['started_at']
        self._json(self.root/d.CYCLE_PATH,value);self._reject('predates maintenance')

    def test_tampered_cycle_snapshot_is_rejected(self):
        (self.root/self.cycle['stages'][0]['snapshot_path']).write_bytes(b'{}')
        self._reject('snapshot hash mismatch')

    def test_anchor_or_origin_missing_never_selects_legacy(self):
        with self.assertRaisesRegex(PermissionError,'ambiguous'):
            d.build(self.root,expected_reference_hash=self.reference_anchor)
        with self.assertRaisesRegex(PermissionError,'ambiguous'):
            d.build(self.root,paused_application_reference=self.reference_path.relative_to(self.root))

    def test_materializer_detects_source_race_before_writing(self):
        original=d._evaluate_observed
        def raced(*args,**kwargs):
            value=original(*args,**kwargs)
            (self.root/d.EXECUTIVE_PATH).write_bytes(b'{}')
            return value
        with patch.object(d,'_evaluate_observed',side_effect=raced):
            from jsonschema import ValidationError
            with self.assertRaises(ValidationError):
                d.materialize(self.root,verified_at=self.verified,paused_application_reference=self.reference_path.relative_to(self.root),expected_reference_hash=self.reference_anchor)
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_reference_read_before_authentication_must_have_exact_anchored_bytes(self):
        import hashlib
        # Equivalent JSON is not equivalent evidence. First source read sees A;
        # the real protected reader then sees externally anchored B, same data.
        second=self.reference_path.read_bytes()+b'\n'
        self.reference_anchor='sha256:'+hashlib.sha256(second).hexdigest()
        # T29 authenticates BEFORE capture; the mismatching initial bytes must
        # now fail immediately, not be replaced to match an untrusted snapshot.
        self._reject('D116_EVIDENCE_CHANGED')


class RuntimeIdentityProducerTests(unittest.TestCase):
    def test_existing_powershell_function_validates_generation_without_running_script(self):
        import tempfile
        shell=Path('C:/Users/mathe/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
        source=ROOT/'scripts/verify_phase5_manager_autostart.ps1'
        body="""$ErrorActionPreference='Stop'
$tokens=$null; $errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile($args[0],[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'parse error'}
$fn=@($ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Get-VerifiedManagerIdentity'},$true))
if($fn.Count -ne 1){throw 'ambiguous function'}
Invoke-Expression $fn[0].Extent.Text
$a=[pscustomobject]@{ProcessId=42;ParentProcessId=41;CreationDate=[DateTime]'2026-09-10T10:00:00Z';ExecutablePath='C:/fixture/python.exe';CommandLine='python.exe -m hero_engine.central_manager_phase5 --loop'}
$good=Get-VerifiedManagerIdentity -Before $a -After $a -ExpectedPid 42
$bad=$a.PSObject.Copy();$bad.CreationDate=$a.CreationDate.AddSeconds(1)
$blocked=$false;try {Get-VerifiedManagerIdentity -Before $a -After $bad -ExpectedPid 42 | Out-Null}catch{$blocked=$true}
$unknown=$false;try {Get-VerifiedManagerIdentity -Before $null -After $a -ExpectedPid 42 | Out-Null}catch{$unknown=$true}
@{good=$good;reused_blocked=$blocked;unknown_blocked=$unknown}|ConvertTo-Json -Depth 4 -Compress
"""
        with tempfile.TemporaryDirectory(prefix='hero-t23-identity-') as folder:
            script=Path(folder)/'identity.ps1';script.write_text(body,encoding='utf-8')
            proc=subprocess.run([str(shell),'-NoLogo','-NoProfile','-NonInteractive','-File',str(script),str(source)],
                                cwd=folder,capture_output=True,timeout=20)
            self.assertEqual(0,proc.returncode,proc.stderr.decode(errors='replace'))
            value=json.loads(proc.stdout.decode('utf-8-sig'))
            self.assertTrue(value['reused_blocked']);self.assertTrue(value['unknown_blocked'])
            self.assertEqual(42,value['good']['pid']);self.assertTrue(value['good']['stable_across_probe'])
