"""Explicit synthetic V4/V6 joins; no source/rights inspector or media claim."""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_asset_use_binding_v3 as joiner
from hero_engine import phase6_av_static_asset_uses_v4 as uses
from hero_engine import phase6_av_static_uses_v3_replay as previous
from hero_engine import phase6_av_body_sources_replay as body
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]


class AssetUseBindingV3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        reader = uses.sources._Reader(ROOT)
        projection = uses._json(reader, uses._raw(uses.case.PROJECTION_BINDING))
        v5 = uses._json(reader, uses.case.SOURCE_BINDINGS["v5"])
        old = uses._json(reader, previous.INSPECTION)
        registry = uses._json(reader, body.REGISTRATION)
        prior = {"fixture_only": True, "adapter_version": "phase6-av-question-case-amendment-v1", "rows": v5["effective_rows"],
            "prior_amendment_inspection": {"fixture_only": True, "source_binding": v5["base_projection"]}}
        cls.literal = {"fixture_only": True, "adapter_version": "phase6-av-body-case-amendment-v1",
            "rows": projection["effective_rows"], "prior_case_inspection": prior}
        states = {state["state_id"]: (row, state) for row in cls.literal["rows"] for state in row["states"]}
        cls.fixture = copy.deepcopy(old)
        cls.fixture.update(version=uses.VERSION, fixture_only=True, source_count=39, use_count=41, unique_png_content_count=37, lineage_count=3)
        for entry, proof in zip(registry["request"]["states"], registry["source_proofs"], strict=True):
            row, state = states[entry["state_id"]]
            cls.fixture["sources"].append({"source_id": entry["asset_id"], "asset_binding": proof["asset_binding"],
                "lineage_id": proof["lineage_id"], "original_unit_id": proof["unit_id"], "fixture_only": True})
            cls.fixture["uses"].append({"use_id": "static-use-" + entry["state_id"], "visual_state_id": entry["state_id"],
                "unit_id": row["unit_id"], "source_id": entry["asset_id"], "literal_copy": state["visual_content"]["literal_copy"],
                "entry": state["entry"], "source_provenance_unit_id": proof["unit_id"],
                "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
        cls.fixture["remaining_unbound_visual_state_ids"] = sorted(set(states) - set(joiner.COVERED))
        cls.fixture["visual_amendment_evidence"] = {"adapter_version": "phase6-av-body-case-amendment-v1",
            "inspection_sha256": joiner.canonical_sha(cls.literal), "effective_rows_sha256": joiner.canonical_sha(cls.literal["rows"]),
            "changed_state_count": 21, "changed_string_count": 24, "unmodified_state_count": 79,
            "prior_case_inspection_sha256": joiner.canonical_sha(prior), "source_ready": False, "global_schedule_created": False}
        cls.fixture["prior_visual_amendment_evidence"] = {"adapter_version": "phase6-av-question-case-amendment-v1",
            "inspection_sha256": joiner.canonical_sha(prior), "effective_rows_sha256": joiner.canonical_sha(prior["rows"]),
            "changed_state_count": 2, "unmodified_state_count": 98,
            "prior_amendment_inspection_sha256": joiner.canonical_sha(prior["prior_amendment_inspection"]),
            "source_ready": False, "global_schedule_created": False}

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="joiner-v3-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.assertFalse(self.root.is_relative_to(ROOT))
        path = self.root / "fixture-input.json"
        raw = uses.sources._canonical({"fixture_only": True, "not_an_operational_manifest": True})
        path.write_bytes(raw)
        self.binding = {"path": path.relative_to(self.root).as_posix(), "sha256": "sha256:" + uses.sources._sha(raw)}
        self.proof = copy.deepcopy(self.fixture)
        self.proof["input_binding"] = {"path": self.binding["path"], "sha256": self.binding["sha256"][7:]}
        self.proof["dependency_bindings"] = [{"path": str(path), "sha256": self.binding["sha256"][7:], "size_bytes": len(raw)}]

    def test_pure_join_exact41_59_and_three_lineages_without_authority(self):
        before = copy.deepcopy(self.proof)
        result = joiner.join(self.proof, self.binding, self.literal)
        self.assertEqual((result["source_count"], result["use_count"], result["unique_png_content_count"], result["lineage_count"]), (39, 41, 37, 3))
        self.assertEqual(result["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(result["remaining_unbound_visual_state_ids"]), 59)
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertFalse(result["source_ready"])
        self.assertFalse(result["global_schedule_created"])
        self.assertFalse(result["calibrated_timing_available"])
        self.assertEqual(self.proof, before)

    def test_old_adapters_and_history_cannot_be_relabelled_as_current_v6(self):
        for literal in (None, {**self.literal, "adapter_version": "phase6-av-question-case-amendment-v1"}):
            with self.assertRaises(ValueError): joiner.join(self.proof, self.binding, literal)
        for kind in ("version", "current", "prior", "count", "swap"):
            proof = copy.deepcopy(self.proof)
            if kind == "version": proof["version"] = "phase6-av-static-asset-uses-v3"
            elif kind == "current": proof["visual_amendment_evidence"]["prior_case_inspection_sha256"] = "sha256:" + "0"*64
            elif kind == "prior": proof["prior_visual_amendment_evidence"]["inspection_sha256"] = "sha256:" + "0"*64
            elif kind == "count": proof["visual_amendment_evidence"]["changed_string_count"] = 24.0
            else: proof["visual_amendment_evidence"], proof["prior_visual_amendment_evidence"] = proof["prior_visual_amendment_evidence"], proof["visual_amendment_evidence"]
            with self.subTest(kind=kind), self.assertRaises(ValueError): joiner.join(proof, self.binding, self.literal)

    def test_numeric_readiness_and_publicity_promotions_fail(self):
        for key, value in (("source_count", 39.0), ("use_count", 100), ("lineage_count", 4), ("unique_png_content_count", 38),
            ("source_ready", True), ("global_schedule_created", True), ("calibrated_timing_available", True),
            ("technical_cost_brl", False), ("authority", {**joiner.AUTHORITY, "publicity": True})):
            proof = copy.deepcopy(self.proof)
            proof[key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "scope or authority"):
                joiner.join(proof, self.binding, self.literal)

    def test_new_lexical_cross_fragment_and_old_hold_are_exact_literal_not_times(self):
        for kind in ("copy", "entry", "float", "unit", "old_hold", "provenance"):
            proof = copy.deepcopy(self.proof)
            sid = "visual-u016-s01" if kind == "old_hold" else "visual-u038-s02"
            target = next(row for row in proof["uses"] if row["visual_state_id"] == sid)
            if kind == "copy": target["literal_copy"] = ["Stories definitely exhausted you"]
            elif kind == "entry": target["entry"]["kind"] = "UNIT_ENTRY"
            elif kind == "float": target["entry"]["char_start"] = 72.0
            elif kind == "unit": target["unit_id"] = "narration-unit-037"
            elif kind == "old_hold": target["entry"]["previous_state_id"] = "visual-u017-s00"
            else: target["source_provenance_unit_id"] = "narration-unit-001"
            with self.subTest(kind=kind), self.assertRaises(ValueError): joiner.join(proof, self.binding, self.literal)

    def test_actual_source_content_and_coverage_population_cannot_disappear(self):
        for kind in ("remaining", "missing_use", "duplicate_use", "new_use", "missing_source", "duplicate_source", "content", "lineage", "orphan"):
            proof = copy.deepcopy(self.proof)
            if kind == "remaining": proof["remaining_unbound_visual_state_ids"].pop()
            elif kind == "missing_use": proof["uses"].pop()
            elif kind == "duplicate_use": proof["uses"].append(copy.deepcopy(proof["uses"][-1]))
            elif kind == "new_use": proof["uses"][-1]["visual_state_id"] = "visual-u051-s00"
            elif kind == "missing_source": proof["sources"].pop()
            elif kind == "duplicate_source": proof["sources"][-1] = copy.deepcopy(proof["sources"][-2])
            elif kind == "content": proof["sources"][-1]["asset_binding"]["sha256"] = proof["sources"][-2]["asset_binding"]["sha256"]
            elif kind == "lineage": proof["sources"][-1]["lineage_id"] = "fictional-fourth-lineage"
            else: proof["uses"][-1]["source_id"] = "unbound-fixture-source"
            with self.subTest(kind=kind), self.assertRaises(ValueError): joiner.join(proof, self.binding, self.literal)

    def test_bad_binding_or_reused_sink_fails_before_inspector(self):
        invalid = [{**self.binding, "sha256": self.binding["sha256"][7:]}, {**self.binding, "path": "../input.json"},
            {**self.binding, "path": "C:/Windows/input.json"}, {**self.binding, "path": "relative\\input.json"},
            {**self.binding, "path": "relative//input.json"}, {**self.binding, "extra": True}]
        with patch.object(uses, "inspect_static_asset_uses", side_effect=AssertionError("preflight before inspector")) as inspect:
            for bound in invalid:
                with self.assertRaises(ValueError): joiner.read_asset_use_binding(Reader(self.root), bound, self.literal, proof_sink=[])
            for sink in (None, {}, [self.proof]):
                with self.assertRaises(ValueError): joiner.read_asset_use_binding(Reader(self.root), self.binding, self.literal, proof_sink=sink)
        inspect.assert_not_called()

    def test_orchestration_uses_v4_once_then_same_call_sink_recheck(self):
        reader, sink = Reader(self.root), []
        with patch.object(uses, "inspect_static_asset_uses", return_value=self.proof) as inspect, \
             patch.object(uses, "recheck_asset_use_dependencies") as recheck, \
             patch.object(uses.sources, "recheck_static_dependencies", side_effect=AssertionError("legacy16MiB sink forbidden")):
            result = joiner.read_asset_use_binding(reader, self.binding, self.literal, proof_sink=sink)
        inspect.assert_called_once_with(self.root, binding=self.proof["input_binding"])
        recheck.assert_called_once_with(self.root, [self.proof])
        self.assertEqual(sink, [self.proof])
        self.assertEqual(result["use_count"], 41)

    def test_final_dependency_failure_leaves_empty_sink_without_retry(self):
        sink = []
        with patch.object(uses, "inspect_static_asset_uses", return_value=self.proof) as inspect, \
             patch.object(uses, "recheck_asset_use_dependencies", side_effect=ValueError("synthetic source/model drift")):
            with self.assertRaisesRegex(ValueError, "source/model drift"):
                joiner.read_asset_use_binding(Reader(self.root), self.binding, self.literal, proof_sink=sink)
        self.assertEqual(inspect.call_count, 1)
        self.assertEqual(sink, [])


if __name__ == "__main__":
    unittest.main()
