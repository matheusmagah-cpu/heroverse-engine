"""A12 evolution of the A11 consumer FIXTURES; never productive admission.

The unamended Stage-A fixture is built with the real builder/schema. Amendment
branch fixtures isolate C's defensive rejection, explicitly bypassing schema
only for that branch: they are not valid amendments or independently replayed A.
All files created by the fixture remain inside a TemporaryDirectory. No model,
decode, renderer, OCR, registry, queue or external service is run.
"""
from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError

from hero_engine import phase6_av_admission as admission
from hero_engine import phase6_av_render_recipe as recipe
from hero_engine import phase6_av_timeline as timeline_module
from hero_engine import phase6_av_two_column_adapter as adapter
from tests import test_phase6_av_timeline as stage_a_fixture
from tests import test_phase6_av_two_column_adapter as adapter_fixture


ROOT = Path(__file__).resolve().parents[1]


def boundary_fixture(take_id="take-012"):
    """Synthetic adapter boundary; not a schema-valid or LIVE A document."""
    value = adapter_fixture.fixture_unit_boundary_timeline()
    value["timeline_version"] = "phase6-av-timeline-v12"
    fragment = next(row for row in value["narration_fragment_map"] if row["take_id"] == take_id)
    event = next(row for row in value["visual_events"]
                 if row["event_id"] == "fixture-event-" + take_id)
    state = {"take_id": take_id, "fragment_binding": fragment,
             "narrative_rationale": event["narrative_function"]}
    return (value, state, {row["unit_id"]: row for row in value["units"]},
            {row["span_id"]: row for row in value["render_spans"]})


def static_shape_fixture():
    """Shape only: the text path and labels do not assert any real source."""
    return {"schema_version": "1.11.0", "render_spans": [{
        "span_id": "fixture-static-span", "media_kind": "STATIC_IMAGE",
        "asset_binding": {"path": "fixture-not-a-media-file.png", "sha256": "sha256:" + "1" * 64},
        "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
        "static_source": {"fixture_scope": "SHAPE_ONLY_NOT_SOURCE_OR_RIGHTS"},
    }], "static_source_evidence": [{"span_id": "fixture-static-span",
        "inspection_id": "fixture-not-verified", "inspection_sha256": "sha256:" + "2" * 64}]}


class A11AdapterConsumerTests(unittest.TestCase):
    def test_c_body_schema_requires_current_adapter_and_rejects_other_versions(self):
        schema = json.loads((ROOT / "schemas/phase6_av_render_recipe.schema.json").read_bytes())
        body = schema["properties"]["inputs"]["properties"]["two_column_visual_preparation"]
        self.assertEqual([{"type": "null"}, {"$ref": "#/$defs/twoColumnPreparation"}], body["oneOf"])
        contract = schema["$defs"]["twoColumnPreparation"]
        self.assertIn("adapter_version", contract["required"])
        validator = Draft202012Validator(contract["properties"]["adapter_version"])
        validator.validate(adapter.ADAPTER_VERSION)
        self.assertEqual("phase6-av-two-column-adapter-v11", adapter.ADAPTER_VERSION)
        for invalid in ("phase6-av-two-column-adapter-v9", "phase6-av-two-column-adapter-v10", "phase6-av-two-column-adapter-v12", None, 11):
            with self.subTest(invalid=invalid), self.assertRaises(ValidationError):
                validator.validate(invalid)

    def test_versions_and_external_a_pins_match_exact_bytes(self):
        self.assertEqual("phase6-av-two-column-adapter-v11", adapter.ADAPTER_VERSION)
        self.assertEqual("phase6-av-render-recipe-v15", recipe.RECIPE_VERSION)
        self.assertEqual("1.14.0", recipe.SCHEMA_VERSION)
        schema = json.loads((ROOT / "schemas/phase6_av_render_recipe.schema.json").read_bytes())
        self.assertEqual(recipe.SCHEMA_VERSION, schema["properties"]["schema_version"]["const"])
        self.assertEqual(recipe.RECIPE_VERSION, schema["properties"]["recipe_version"]["const"])
        for role in ("timeline_implementation", "timeline_schema"):
            relative, expected = adapter._IMPLEMENTATION[role]
            self.assertEqual(expected, hashlib.sha256((ROOT / relative).read_bytes()).hexdigest(), role)

    def test_either_amendment_blocks_old_compositor_before_source_loading(self):
        for field in ("visual_amendment_evidence", "question_case_amendment_evidence", "body_case_amendment_evidence"):
            for proof in ({}, {"fixture": "NOT_AN_APPROVED_AMENDMENT"}):
                with self.subTest(field=field, proof=proof), \
                     patch.object(adapter, "_load_sources", side_effect=AssertionError("must not load")), \
                     patch.object(adapter, "_workspace_root", side_effect=AssertionError("must not resolve")):
                    with self.assertRaisesRegex(adapter.AVTwoColumnAdapterError, "historical"):
                        adapter.compile_two_column_av_spec(ROOT, timeline={field: proof}, bindings={})

    def test_a11_exact_unit_boundary_remains_structural_only(self):
        value, state, units, spans = boundary_fixture()
        blockers = []
        event = adapter._event_for_state(state, value, units, spans, blockers)
        self.assertEqual([], blockers)
        self.assertEqual("UNIT_BOUNDARY", event["kind"])
        self.assertEqual("WHOLE_UNIT_PCM_START", event["trigger"])
        self.assertTrue(all(event[key] is None for key in (
            "char_start", "char_end", "alignment_id", "maximum_uncertainty_samples")))
        self.assertFalse(any(adapter._AUTHORITY.values()))

    def test_old_version_and_nonexact_or_lexical_boundary_are_rejected(self):
        mutations = [
            lambda value, event: value.update(timeline_version="phase6-av-timeline-v10"),
            lambda value, event: event.update(frame=float(event["frame"])),
            lambda value, event: event.update(frame=True),
            lambda value, event: event.update(frame=event["frame"] + 1),
            lambda value, event: event.update(char_start=0),
            lambda value, event: event.update(alignment_id="fixture-fabricated-word-onset"),
        ]
        for index, mutate in enumerate(mutations):
            with self.subTest(index=index):
                value, state, units, spans = boundary_fixture()
                event = next(row for row in value["visual_events"]
                             if row["event_id"] == "fixture-event-take-012")
                mutate(value, event)
                blockers = []
                self.assertIsNone(adapter._event_for_state(state, value, units, spans, blockers))
                self.assertEqual(["STATE_UNIT_BOUNDARY_CONTRACT_DIFFERS:take-012"], blockers)

    def test_two_internal_reveals_cannot_be_promoted_to_unit_boundaries(self):
        for take_id in ("take-014", "take-016"):
            with self.subTest(take_id=take_id):
                value, state, units, spans = boundary_fixture(take_id)
                event = next(row for row in value["visual_events"]
                             if row["event_id"] == "fixture-event-" + take_id)
                event.update(kind="UNIT_BOUNDARY", trigger="WHOLE_UNIT_PCM_START",
                             char_start=None, char_end=None, alignment_id=None,
                             maximum_uncertainty_samples=None,
                             frame=units[state["fragment_binding"]["unit_id"]]["pcm_start_sample"] // 800)
                blockers = []
                self.assertIsNone(adapter._event_for_state(state, value, units, spans, blockers))
                self.assertIn("STATE_UNIT_BOUNDARY_CONTRACT_DIFFERS:" + take_id, blockers)

    def test_lexical_reveal_still_requires_complete_live_temporal_evidence(self):
        for field, bad in (("scope_complete", False), ("all_required_evidence_live", False),
                           ("fixture_evidence_present", True), ("validated_alignment_ids", [])):
            with self.subTest(field=field):
                value, state, units, spans = boundary_fixture("take-014")
                value["temporal_evidence_assessment"][field] = bad
                blockers = []
                self.assertIsNone(adapter._event_for_state(state, value, units, spans, blockers))
                self.assertEqual(["STATE_TEMPORAL_EVIDENCE_NOT_LIVE_VALIDATED:take-014"], blockers)


class A11RecipeConsumerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name).resolve()
        bindings = stage_a_fixture.fixture(cls.root)
        cls.timeline = timeline_module.build(cls.root, source_bindings=bindings, pause_decisions=[],
            render_spans=[], visual_events=[], caption_cues=[], temporal_evidence_bindings={},
            temporal_policy_binding=None)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_real_a11_fixture_schema_validation_does_not_admit_or_compile(self):
        self.assertEqual("phase6-av-timeline-v12", self.timeline["timeline_version"])
        self.assertEqual("1.11.0", self.timeline["schema_version"])
        ref, blockers = recipe._validate_timeline(self.root, self.timeline, None)
        self.assertEqual("SCHEMA_IDENTITY_SOURCE_REHASH_NOT_STAGE_A_RECOMPOSITION", ref["verification_scope"])
        self.assertIn("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED", blockers)
        self.assertIn("STAGE_A_TIMELINE_INCOMPLETE", blockers)
        self.assertIn("STAGE_A_LIVE_TEMPORAL_EVIDENCE_MISSING", blockers)
        self.assertFalse(any(self.timeline["authority"].values()))
        self.assertFalse(any(recipe.FALSE_AUTHORITY.values()))

    def test_old_version_and_canonical_tampering_fail_before_consumption(self):
        for change in ({"timeline_version": "phase6-av-timeline-v10"}, {"timeline_version": "phase6-av-timeline-v11"},
                       {"timeline_id": "phase6-av-timeline-" + "0" * 24}):
            with self.subTest(change=change):
                candidate = copy.deepcopy(self.timeline)
                candidate.update(change)
                with self.assertRaises(recipe.AVRenderRecipeError):
                    recipe._validate_timeline(self.root, candidate, None)

    def test_c_defensive_amendment_branches_keep_independent_blockers(self):
        # Deliberately isolate the defensive policy after A/schema validation.
        # These marker objects are NOT valid case evidence or a LIVE timeline.
        for field in ("visual_amendment_evidence", "question_case_amendment_evidence", "body_case_amendment_evidence"):
            with self.subTest(field=field):
                candidate = copy.deepcopy(self.timeline)
                candidate[field] = {"fixture": "BRANCH_ONLY_NOT_VALID_AMENDMENT"}
                candidate["timeline_id"] = recipe._identity(candidate, "timeline_id", "phase6-av-timeline-")
                with patch.object(recipe, "Draft202012Validator") as validator:
                    validator.return_value.iter_errors.return_value = []
                    _, blockers = recipe._validate_timeline(self.root, candidate, None)
                self.assertIn("AMENDED_VISUAL_COMPOSITOR_NOT_IMPLEMENTED", blockers)
                self.assertIn("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED", blockers)
                self.assertIn("STAGE_A_TIMELINE_INCOMPLETE", blockers)


class A11AdmissionConsumerTests(unittest.TestCase):
    def test_static_schema_support_is_shape_only_and_preserves_old_version(self):
        for version in ("1.9.0", "1.10.0", "1.11.0"):
            with self.subTest(version=version):
                candidate = static_shape_fixture()
                candidate["schema_version"] = version
                assets = admission._span_assets(candidate)
                self.assertEqual(1, len(assets))
                self.assertEqual("STATIC_IMAGE", assets[0]["media_kind"])
                self.assertEqual([{ "span_id": "fixture-static-span", "source_start_frame": 0,
                                    "source_end_frame": 1}], assets[0]["spans"])
                self.assertNotIn("authority", assets[0])
                self.assertNotIn("source_ready", assets[0])
                self.assertNotIn("rights_status", assets[0])

    def test_static_scope_cannot_gain_duration_or_unknown_version(self):
        for field, bad in (("source_frame_count", 2), ("source_frame_count", True),
                           ("source_start_frame", 0.0), ("source_end_frame", 1.0),
                           ("source_end_frame", 30)):
            with self.subTest(field=field, bad=bad):
                candidate = static_shape_fixture()
                candidate["render_spans"][0][field] = bad
                with self.assertRaisesRegex(admission.AdmissionError, "exactly one frame"):
                    admission._span_assets(candidate)
        for version in ("1.3.0", "1.12.0"):
            with self.subTest(version=version):
                candidate = static_shape_fixture()
                candidate["schema_version"] = version
                with self.assertRaisesRegex(admission.AdmissionError, "legacy timeline"):
                    admission._span_assets(candidate)

    def test_static_inspection_absence_duplicates_and_video_relabel_are_rejected(self):
        for mutation in (
            lambda value: value.update(static_source_evidence=[]),
            lambda value: value["static_source_evidence"].append(copy.deepcopy(value["static_source_evidence"][0])),
            lambda value: value["render_spans"][0].update(media_kind="VIDEO_CFR"),
            lambda value: value["render_spans"][0].update(static_source=None),
        ):
            candidate = static_shape_fixture()
            mutation(candidate)
            with self.assertRaises(admission.AdmissionError):
                admission._span_assets(candidate)

    def test_b_still_requires_real_recomposition_complete_live_and_no_authority(self):
        # Isolated B caller-boundary fixtures; mocked verifier is never LIVE proof.
        arguments = {key: {} if key in ("source_bindings", "temporal_evidence_bindings") else
                     None if key == "temporal_policy_binding" else [] for key in (
            "source_bindings", "pause_decisions", "render_spans", "visual_events",
            "caption_cues", "temporal_evidence_bindings", "temporal_policy_binding")}
        verified = {"status": "TIMELINE_VALIDATED_NOT_ADMITTED", "derived_take_plan": {},
            "blockers": [], "units": [{}] * 51, "narration_fragment_map": [{}] * 90,
            "temporal_evidence_assessment": {"fixture_evidence_present": False,
                                              "all_required_evidence_live": True},
            "authority": {"publication_authorized": False}}
        with patch.object(admission, "verify_phase6_av_timeline", return_value=verified) as verifier:
            with self.assertRaisesRegex(admission.AdmissionError, "FIXTURE evidence"):
                admission.validate_timeline_for_admission(ROOT, {}, arguments, evidence_mode="FIXTURE")
            self.assertTrue(verifier.call_args.kwargs["require_complete"])
        for mutate in (
            lambda value: value["blockers"].append("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING"),
            lambda value: value.update(derived_take_plan=None),
            lambda value: value["temporal_evidence_assessment"].update(all_required_evidence_live=False),
            lambda value: value["authority"].update(publication_authorized=True),
        ):
            candidate = copy.deepcopy(verified)
            mutate(candidate)
            with patch.object(admission, "verify_phase6_av_timeline", return_value=candidate):
                with self.assertRaisesRegex(admission.AdmissionError, "LIVE Stage-A invariants"):
                    admission.validate_timeline_for_admission(ROOT, {}, arguments, evidence_mode="LIVE")
        with patch.object(admission, "verify_phase6_av_timeline", side_effect=ValueError("fixture corruption")):
            with self.assertRaisesRegex(admission.AdmissionError, "Stage-A recomposition failed"):
                admission.validate_timeline_for_admission(ROOT, {}, arguments, evidence_mode="LIVE")


if __name__ == "__main__":
    unittest.main()
