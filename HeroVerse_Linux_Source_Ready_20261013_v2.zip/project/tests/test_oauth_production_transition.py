from __future__ import annotations

import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]


class OAuthProductionTransitionTests(unittest.TestCase):
    def test_transition_is_exact_ordered_and_fail_closed(self) -> None:
        plan = json.loads((ROOT / "output/integrations/youtube/heroverse/oauth-production-transition-plan.json").read_text(encoding="utf-8"))
        schema = json.loads((ROOT / "schemas/oauth_production_transition_plan.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(schema).validate(plan)
        self.assertTrue(plan["protected_actions_authorized_now"])
        self.assertEqual("PERSONAL_USE_SINGLE_OWNER", plan["operational_scope"])
        self.assertTrue(plan["current_state"]["continuous_operation_ready"])
        self.assertTrue(plan["target_state"]["continuous_operation_ready"])
        self.assertEqual(list(range(1, 10)), [step["order"] for step in plan["steps"]])
        by_id = {step["step_id"]: step for step in plan["steps"]}
        self.assertEqual("PASS", by_id["align-data-access-scopes"]["status"])
        self.assertIn("exactly youtube.readonly", by_id["align-data-access-scopes"]["action"])
        self.assertTrue(by_id["align-data-access-scopes"]["protected_action"])
        self.assertEqual("PASS_WITH_LIMITATION", by_id["provide-and-verify-domain"]["status"])
        self.assertEqual("PASS_WITH_LIMITATION", by_id["submit-required-verification"]["status"])
        self.assertEqual("PASS", by_id["reauthorize-pinned-owner"]["status"])
        self.assertEqual("PASS", by_id["prove-durable-reuse"]["status"])
        self.assertEqual(4, plan["current_state"]["runtime_scope_count"])
        self.assertEqual(4, plan["current_state"]["declared_scope_count"])
        self.assertFalse(plan["current_state"]["oauth_dns_domain_verified"])


if __name__ == "__main__":
    unittest.main()
