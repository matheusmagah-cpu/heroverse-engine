from __future__ import annotations

import json
import hashlib
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]


class Phase5ManagerAutostartTests(unittest.TestCase):
    def test_runner_keeps_token_outside_workspace_and_uses_singleton_manager(self) -> None:
        runner = (ROOT / "scripts/start_phase5_manager.ps1").read_text(encoding="utf-8")
        self.assertIn("HERO_YT_TOKEN_PATH", runner)
        self.assertIn("HERO_YT_RECONSENT_SOURCE_PATH", runner)
        self.assertIn("LOCALAPPDATA", runner)
        self.assertIn("HeroEngine\\secrets\\youtube-heroverse-token.json", runner)
        self.assertIn("hero_engine.central_manager_phase5", runner)
        self.assertIn("ensure_power_continuity.ps1", runner)
        self.assertIn("Start-Process", runner)
        self.assertIn("-Wait", runner)
        self.assertNotIn("refresh_token", runner)
        self.assertNotIn("client_secret", runner)

    def test_installer_is_logon_scoped_zero_cost_and_ignores_duplicate_instances(self) -> None:
        installer = (ROOT / "scripts/install_phase5_manager_autostart.ps1").read_text(encoding="utf-8")
        self.assertIn("New-ScheduledTaskTrigger -AtLogOn", installer)
        self.assertIn("[Text.Encoding]::Unicode.GetBytes", installer)
        self.assertIn("-EncodedCommand", installer)
        self.assertIn("manager-task-bootstrap.log", installer)
        self.assertIn("-MultipleInstances IgnoreNew", installer)
        self.assertIn("-RestartCount 3", installer)
        self.assertIn("technical_cost_brl = 0", installer)
        self.assertIn("Credential path must remain outside the project workspace", installer)
        self.assertIn("oauth-reconsent-watcher.json", installer)
        self.assertIn("destination_path", installer)
        schema = json.loads((ROOT / "schemas/central_manager_autostart_receipt.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)

    def test_autostart_verifier_is_fail_closed_and_schema_versioned(self) -> None:
        verifier = (ROOT / "scripts/verify_phase5_manager_autostart.ps1").read_text(encoding="utf-8")
        self.assertIn("duplicate_probe_exit_code", verifier)
        self.assertIn("operational_ready", verifier)
        self.assertIn("exit 1", verifier)
        schema = json.loads((ROOT / "schemas/central_manager_autostart_verification.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)

    def test_oauth_source_watcher_reconciles_after_boot_without_racing_health_probe(self) -> None:
        manager = (ROOT / "hero_engine/central_manager_phase5.py").read_text(encoding="utf-8")
        loop = manager[manager.index("def loop("):manager.index("def main()")]
        self.assertIn("oauth_watcher: threading.Thread | None = None", loop)
        self.assertIn("if oauth_watcher is None or not oauth_watcher.is_alive():", loop)
        self.assertIn("oauth_watcher = _start_oauth_reconsent_watcher(root)", loop)
        self.assertIn("oauth_watcher.join(timeout=1.0)", loop)
        watcher_transaction = loop[
            loop.index("oauth_watcher.join(timeout=1.0)"):
            loop.index("token_value = os.environ.get")
        ]
        self.assertIn("if oauth_watcher is not None and oauth_watcher.is_alive():", watcher_transaction)
        self.assertIn("manager_lock.heartbeat()", watcher_transaction)
        self.assertIn("continue", watcher_transaction)
        health_call = loop.index("ensure_oauth_session_health(")
        watcher_alive_gate = loop.rindex(
            "if oauth_watcher is None or not oauth_watcher.is_alive():",
            0,
            health_call,
        )
        effect_lock = loop.rindex("with _OAUTH_EFFECT_LOCK:", 0, health_call)
        self.assertLess(watcher_alive_gate, effect_lock)
        self.assertLess(effect_lock, health_call)

    def test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime(self) -> None:
        daily = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8")
        manager_source = (ROOT / "hero_engine/central_manager_phase5.py").read_text(encoding="utf-8")
        protocol_source = (ROOT / "hero_engine/maintenance_protocol.py").read_text(encoding="utf-8")
        self.assertIn("Stop-VerifiedProcess", daily)
        self.assertIn("Assert-ProcessRole", daily)
        self.assertIn("ensure_power_continuity.ps1", daily)
        self.assertIn("-VerifyOnly", daily)
        self.assertIn("hero_engine.maintenance_protocol request", daily)
        self.assertIn("READY_TO_STOP", daily)
        self.assertIn("external_effect_boundary_closed", daily)
        self.assertIn("scripts\\build_phase5_integrity.py", daily)
        self.assertIn("compileall", daily)
        self.assertIn("test-inventory.json", protocol_source)
        # The gate is the inventory-bound verifier, not its historical wording.
        self.assertIn("hero_engine.maintenance_unittest_result", daily)
        self.assertIn("--exit-code ([string]$tests.exit_code)", daily)
        self.assertIn("--inventory $testInventoryPath", daily)
        self.assertIn("$testVerification.process_exit_code_verified -eq $true", daily)
        self.assertIn("Regression result verification failed", daily)
        self.assertIn("daily-maintenance-regression-receipt.json", daily)
        self.assertIn("daily-maintenance-receipt.json", daily)
        self.assertLess(
            daily.index("hero_engine.maintenance_protocol request"),
            daily.index("Stop-ScheduledTask"),
        )
        self.assertIn("finally", daily)
        self.assertIn("Start-ScheduledTask -TaskName $taskName", daily)
        self.assertIn("verify_phase5_manager_autostart.ps1", daily)
        self.assertIn("[DateTimeOffset]::UtcNow", daily)
        self.assertIn("$lockStartedAt.ToUniversalTime()", daily)
        self.assertIn("Stop-VerifiedProcess -ProcessId $managerShimPid", daily)
        self.assertIn("Stop-VerifiedProcess -ProcessId $launcherPid", daily)
        self.assertLess(
            daily.index("Stop-VerifiedProcess -ProcessId $managerPid"),
            daily.index("Stop-VerifiedProcess -ProcessId $managerShimPid"),
        )
        self.assertLess(
            daily.index("Stop-VerifiedProcess -ProcessId $managerShimPid"),
            daily.index("Stop-VerifiedProcess -ProcessId $launcherPid"),
        )
        self.assertIn("-m hero_engine.phase6_acceptance", daily)
        self.assertIn("run_phase6_transition", manager_source)
        self.assertIn("No fresh integral Phase 6", daily)
        self.assertIn("-m hero_engine.phase6_maintenance_verification", daily)
        self.assertLess(
            daily.index("-m hero_engine.phase6_maintenance_verification"),
            daily.index("$finalReceipt ="),
        )
        for forbidden in (
            "-m hero_engine.phase6_prediction_runtime",
            "-m hero_engine.phase6_package_treatment",
            "-m hero_engine.phase6_learning_runtime",
            "-m hero_engine.phase6_asset_residency",
            "-m hero_engine.phase6_publication",
            "-m hero_engine.phase6_media",
            "-m hero_engine.phase6_quality",
            "run.ps1",
        ):
            self.assertNotIn(forbidden, daily)
        self.assertNotIn("Stop-Process -Name python", daily)
        for schema_name in (
            "central_manager_maintenance_request.schema.json",
            "central_manager_maintenance_ack.schema.json",
            "daily_maintenance_regression_receipt.schema.json",
            "daily_maintenance_receipt.schema.json",
        ):
            schema = json.loads((ROOT / "schemas" / schema_name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)

    def test_power_continuity_is_enforced_for_ac_and_battery_and_schema_versioned(self) -> None:
        script = (ROOT / "scripts/ensure_power_continuity.ps1").read_text(encoding="utf-8")
        for setting in ("monitor-timeout", "standby-timeout", "hibernate-timeout"):
            self.assertIn(setting, script)
        self.assertIn('"$($item.change)-ac"', script)
        self.assertIn('"$($item.change)-dc"', script)
        self.assertIn("APPLY_AND_VERIFY", script)
        self.assertIn("VERIFY_ONLY", script)
        schema = json.loads((ROOT / "schemas/power_continuity.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)

    def test_materialized_receipts_validate_and_prove_singleton_runtime(self) -> None:
        pairs = (
            ("central_manager_autostart_receipt.schema.json", "autostart-receipt.json"),
            ("central_manager_autostart_verification.schema.json", "autostart-verification.json"),
            ("power_continuity.schema.json", "power-continuity.json"),
        )
        values = {}
        for schema_name, artifact_name in pairs:
            schema = json.loads((ROOT / "schemas" / schema_name).read_text(encoding="utf-8"))
            value = json.loads((ROOT / "output/runtime/gestor-central" / artifact_name).read_text(encoding="utf-8-sig"))
            Draft202012Validator(schema).validate(value)
            values[artifact_name] = value
        installation = values["autostart-receipt.json"]
        verification = values["autostart-verification.json"]
        power = values["power-continuity.json"]
        runner = ROOT / "scripts/start_phase5_manager.ps1"
        self.assertEqual(hashlib.sha256(runner.read_bytes()).hexdigest(), installation["runner_sha256"])
        self.assertTrue(installation["token_path_outside_workspace"])
        self.assertTrue(verification["operational_ready"])
        self.assertTrue(verification["same_process_chain"])
        self.assertEqual("PASS", verification["power_continuity_status"])
        self.assertTrue(verification["continuous_awake"])
        self.assertTrue(power["continuous_awake"])
        self.assertTrue(verification["duplicate_probe_blocked"])
        self.assertEqual(73, verification["duplicate_probe_exit_code"])
        self.assertEqual(0, verification["active_stderr_bytes"])


if __name__ == "__main__":
    unittest.main()
