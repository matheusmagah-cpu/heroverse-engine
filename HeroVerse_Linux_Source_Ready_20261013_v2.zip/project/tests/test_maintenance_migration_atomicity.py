from __future__ import annotations

import json
import hashlib
import tempfile
import unittest
from copy import deepcopy
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError

import hero_engine.maintenance_protocol as protocol


ROOT = Path(__file__).resolve().parents[1]
REQUEST_ID = "maintenance-request-20260905T1400000000000Z-bbbbbbbb"
OBSERVED = datetime(2026, 9, 5, 14, 0, tzinfo=timezone.utc)


class LocalRuntimeMigrationAtomicityTests(unittest.TestCase):
    @contextmanager
    def _resource_hold_fixture(self):
        from hero_engine import phase6_current_production_inputs as inputs
        from hero_engine import phase6_media as media_module
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder)
            (root / 'schemas').mkdir()
            schema = 'phase6_media_executor_runtime.schema.json'
            (root / 'schemas' / schema).write_bytes((ROOT / 'schemas' / schema).read_bytes())
            receipt = 'phase6-production-inputs-' + 'a' * 20
            key = receipt + ':synthesize-render-standard-v2'
            job = dict(job_id='job-' + hashlib.sha256(key.encode()).hexdigest()[:24],
                idempotency_key=key, task_type='EXECUTE_PHASE6_VIDEO2_MEDIA',
                payload={'input_receipt_id': receipt, 'action': 'SYNTHESIZE_AND_RENDER_VIDEO_2'},
                state='RETRY_WAIT', attempt_count=1, lease_owner=None, lease_until=None,
                checkpoint={}, last_error=protocol._EXACT_MEDIA_RESERVE_WAIT_ERROR)
            source = {**self._completed_cycle_error(), 'schema_version': '1.2.0',
                'status': 'RETRY_WAIT', 'job_id': job['job_id'], 'job_state': 'RETRY_WAIT',
                'input_receipt_id': receipt, 'action': 'SYNTHESIZE_AND_RENDER_VIDEO_2',
                'error': job['last_error'], 'capacity_status': 'PASS',
                'capacity_preflight_receipt': 'output/operations/phase6/capacity/fixture.json',
                'capacity_preflight_sha256': 'sha256:' + 'a' * 64,
                'capacity_observed_free_bytes': 100, 'capacity_required_free_bytes': 90,
                'capacity_headroom_bytes': 10,
                'visual_preflight': {'audit_id': 'visual-preflight-' + 'a' * 24,
                    'path': 'output/operations/phase6/visual-preflight/audits/visual-preflight-' + 'a' * 24 + '.json',
                    'sha256': 'sha256:' + 'b' * 64, 'status': 'PASS'}}
            path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            path.write_text(json.dumps(source), encoding='utf-8')
            initial[path] = (True, path.read_bytes())
            witness = root / 'output/production/phase6/video-002/resource-preparation/resident-witness.json'
            witness.parent.mkdir(parents=True, exist_ok=True)
            witness.write_text('{"completed_mux":true}', encoding='utf-8')
            contract = {'receipt_id': receipt, 'authority': {k: False for k in
                ('queue', 'voice', 'render', 'quality', 'publication')}}
            snapshot = {'jobs': [job], 'jobs_hash': protocol.canonical_hash([job]),
                        'active_lease_job_ids': []}
            with patch.object(inputs, 'current_production_input_contract', return_value=contract), \
                 patch.object(protocol, 'queue_snapshot', return_value=snapshot), \
                 patch.object(media_module, '_strict_output_path', return_value=witness), \
                 patch.object(media_module, '_resident_mux_witness', return_value={'path': witness}):
                candidate, evidence = protocol._resource_reserve_media_wait_candidate(
                    root, current=source, source_path=path, observed=OBSERVED)
                yield root, initial, candidate, evidence, snapshot

    def test_resource_hold_transaction_commit_and_official_reader(self):
        from hero_engine.phase6_maintenance_verification import verify_local_migration_evidence
        with self._resource_hold_fixture() as (root, initial, media, evidence, snapshot):
            values = self._candidate_evidence()
            values[3].update(media_runtime_candidate=media, media_wait_evidence=evidence)
            with self._dependencies(root), patch.object(protocol, 'queue_snapshot', return_value=snapshot), \
                 patch.object(protocol, '_local_runtime_migration_candidates', return_value=values):
                result = self._run(root)
            self.assertEqual('EXACT_RESOURCE_RESERVE_RESTART_HOLD', result['media_runtime_migration']['kind'])
            schema = json.loads((ROOT / 'schemas/daily_maintenance_regression_receipt.schema.json').read_bytes())
            Draft202012Validator(schema['properties']['local_runtime_migration']).validate(result)
            verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)
            self.assertFalse(result['media_runtime_migration']['production_authorized'])
            self.assertFalse(result['media_runtime_migration']['publication_authorized'])
            for path, (existed, payload) in initial.items():
                if path == root / protocol.MEDIA_EXECUTOR_STATUS_PATH:
                    continue
                # Existing prediction targets legitimately change in this fixture.
                if path == root / protocol.REQUEST_PATH:
                    self.assertEqual(payload, path.read_bytes())
            reference = evidence['resident_mux_witness']
            (root / reference['path']).write_bytes(b'tampered')
            with self.assertRaises(PermissionError):
                verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)

    def test_resource_hold_recheck_rejects_changed_source_before_writes(self):
        with self._resource_hold_fixture() as (root, initial, media, evidence, snapshot):
            values = self._candidate_evidence()
            values[3].update(media_runtime_candidate=media, media_wait_evidence=evidence)
            path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            changed = json.loads(path.read_bytes())
            changed['error'] = 'unknown failure'
            path.write_text(json.dumps(changed), encoding='utf-8')
            initial[path] = (True, path.read_bytes())
            with self._dependencies(root), patch.object(protocol, 'queue_snapshot', return_value=snapshot), \
                 patch.object(protocol, '_local_runtime_migration_candidates', return_value=values):
                with self.assertRaisesRegex(PermissionError, 'resource reserve hold changed before staging'):
                    self._run(root)
            self._assert_preimages(self, initial)

    def test_resource_hold_write_failure_rolls_back_all_targets(self):
        with self._resource_hold_fixture() as (root, initial, media, evidence, snapshot):
            values = self._candidate_evidence()
            values[3].update(media_runtime_candidate=media, media_wait_evidence=evidence)
            original = protocol._commit_migration_replacement
            def fail_media(target, payload):
                if target == root / protocol.MEDIA_EXECUTOR_STATUS_PATH:
                    raise OSError('injected reserve view commit failure')
                return original(target, payload)
            with self._dependencies(root), patch.object(protocol, 'queue_snapshot', return_value=snapshot), \
                 patch.object(protocol, '_local_runtime_migration_candidates', return_value=values), \
                 patch.object(protocol, '_commit_migration_replacement', side_effect=fail_media):
                with self.assertRaises(PermissionError):
                    self._run(root)
            self._assert_preimages(self, initial)

    def test_resource_hold_repeated_projection_and_restart_observation(self):
        from hero_engine.phase6_maintenance_verification import _exact_media_restart_observation
        with self._resource_hold_fixture() as (root, initial, media, evidence, snapshot):
            path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media['updated_at'] = '2026-09-05T13:59:59Z'
            path.write_text(json.dumps(media), encoding='utf-8')
            held, held_evidence = protocol._resource_reserve_media_wait_candidate(
                root, current=media, source_path=path, observed=OBSERVED)
            self.assertEqual('WAITING', held_evidence['source_status'])
            values = self._candidate_evidence()
            values[3].update(media_runtime_candidate=held, media_wait_evidence=held_evidence)
            with self._dependencies(root), patch.object(protocol, 'queue_snapshot', return_value=snapshot), \
                 patch.object(protocol, '_local_runtime_migration_candidates', return_value=values):
                result = self._run(root)
            cycle = {'cycle_id': 'resource-fixture-cycle', 'stages': []}
            snap = root / 'output/operations/phase6/control-cycle/source-snapshots/resource-fixture-cycle/media.json'
            snap.parent.mkdir(parents=True)
            snap.write_bytes(path.read_bytes())
            cycle['stages'].append({'stage': 'MEDIA', 'snapshot_path': snap.relative_to(root).as_posix(),
                                   'content_hash': protocol.file_hash(snap)})
            executive = {'status': 'ACTIVE_OBSERVING', 'attention_items': [],
                         'release_control': {'publication_authorized': False}}
            executive['media_execution'] = {key: held[key] for key in (
                'input_receipt_id', 'action', 'job_state', 'voice_manifest', 'render_manifest',
                'capacity_preflight_receipt', 'capacity_status', 'capacity_observed_free_bytes',
                'capacity_required_free_bytes', 'capacity_headroom_bytes', 'next_action', 'publication_authorized')}
            executive['media_execution']['executor_status'] = held['status']
            self.assertTrue(_exact_media_restart_observation(root, result, cycle, executive))
            changed = json.loads(snap.read_bytes())
            changed['job_state'] = 'SUCCEEDED'
            snap.write_text(json.dumps(changed), encoding='utf-8')
            cycle['stages'][0]['content_hash'] = protocol.file_hash(snap)
            self.assertFalse(_exact_media_restart_observation(root, result, cycle, executive))

    def test_owner_pause_missing_media_wait_is_not_a_completed_render_retry(self):
        with tempfile.TemporaryDirectory() as folder:
            root, _ = self._root(folder)
            (root / 'schemas').mkdir()
            for name in ('phase6_media_executor_runtime.schema.json', 'phase6_quality_executor_runtime.schema.json'):
                (root / 'schemas' / name).write_bytes((ROOT / 'schemas' / name).read_bytes())
            media = self._completed_cycle_error()
            media['error'] = 'ResourceWait: RESOURCE_WAIT: OWNER_PAUSE'
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.write_text(json.dumps(media), encoding='utf-8')
            quality = {'schema_version': '1.0.0', 'executor_id': 'heroverse-phase6-quality-executor-v1',
                'phase': 6, 'status': 'WAITING', 'media_render_id': None, 'job_id': None,
                'job_state': 'NOT_CREATED', 'evaluation': None, 'decision': 'WAIT', 'publication_eligible': False,
                'next_action': 'Media executor is ERROR/NOT_CREATED.', 'error': None, 'technical_cost_brl': 0,
                'updated_at': protocol._stamp(OBSERVED)}
            quality_path = root / protocol.QUALITY_EXECUTOR_STATUS_PATH
            quality_path.write_text(json.dumps(quality), encoding='utf-8')
            originals = {path: path.read_bytes() for path in (media_path, quality_path)}
            candidate, evidence = protocol._exact_owner_pause_media_wait_candidate(
                root, current=media, source_path=media_path, observed=OBSERVED)
            self.assertEqual('EXACT_OWNER_PAUSE_NO_EFFECT', evidence['reason'])
            self.assertEqual(('WAITING', 'NOT_CREATED', None),
                             (candidate['status'], candidate['job_state'], candidate['render_manifest']))
            with patch.object(protocol, 'queue_snapshot', side_effect=AssertionError('no quality retry lookup')):
                self.assertEqual((None, None), protocol._quality_retry_wait_candidate(
                    root, observed=OBSERVED, media_override=candidate))
            self.assertEqual(originals, {path: path.read_bytes() for path in originals})
            # A claim of completed media still requires its immutable manifest;
            # an absent file must not fall through as an ordinary owner wait.
            with self.assertRaisesRegex(PermissionError, 'immutable render manifest'):
                protocol._quality_retry_wait_candidate(root, observed=OBSERVED,
                    media_override={**candidate, 'status': 'COMPLETED'})

    @staticmethod
    def _completed_cycle_error():
        return {"schema_version": "1.1.0", "executor_id": "heroverse-phase6-media-executor-v1",
            "phase": 6, "status": "ERROR", "input_receipt_id": None, "action": "WAIT",
            "job_id": None, "job_state": "NOT_CREATED", "voice_manifest": None, "render_manifest": None,
            "capacity_preflight_receipt": None, "capacity_preflight_sha256": None, "capacity_status": "UNAVAILABLE",
            "capacity_observed_free_bytes": None, "capacity_required_free_bytes": None, "capacity_headroom_bytes": None,
            "next_action": "Preserve evidence and retry without relaxing media or release gates.",
            "error": protocol.COMPLETED_MEDIA_CYCLE_ERROR, "publication_authorized": False,
            "technical_cost_brl": 0, "updated_at": protocol._stamp(OBSERVED)}

    @contextmanager
    def _completed_cycle_fixture(self):
        from tests.test_phase6_media_authority import Phase6MediaAuthorityTests
        with Phase6MediaAuthorityTests()._completed_executor_fixture(predecessor=True) as (root, queue, now, receipt, original, cp, _):
            self._root(str(root))
            for name in ("phase6_quality_executor_runtime.schema.json",):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            manifest = {"render_id": cp["render_id"], "output": {"content_hash": "sha256:" + "b" * 64}}
            manifest_path = root / cp["render_manifest"]
            manifest_path.parent.mkdir(parents=True)
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            cp["render_manifest_sha256"] = protocol.file_hash(manifest_path)
            # Test setup only: extend the already-completed fixture's checkpoint
            # with the immutable manifest binding used by the real retry reader.
            with queue._connection() as connection:
                connection.execute("UPDATE jobs SET checkpoint_json=? WHERE job_id=?", (json.dumps(cp), original["job_id"]))
            key = f"{cp['render_id']}:{manifest['output']['content_hash']}:independent-quality-v2"
            qjob = queue.enqueue(idempotency_key=key, operation_id=original["operation_id"],
                channel_id=original["channel_id"], task_type="EVALUATE_PHASE6_VIDEO2_QUALITY",
                payload={"render_id": cp["render_id"], "render_hash": manifest["output"]["content_hash"]}, now=now)
            queue.claim_job(qjob["job_id"], worker_id="quality", now=now)
            queue.fail(qjob["job_id"], worker_id="quality", error=protocol.QUALITY_RECOMPUTATION_ERROR, now=now)
            media_source = self._completed_cycle_error()
            (root / protocol.MEDIA_EXECUTOR_STATUS_PATH).write_text(json.dumps(media_source), encoding="utf-8")
            quality_source = {"schema_version": "1.0.0", "executor_id": "heroverse-phase6-quality-executor-v1",
                "phase": 6, "status": "WAITING", "media_render_id": None, "job_id": None,
                "job_state": "NOT_CREATED", "evaluation": None, "decision": "WAIT", "publication_eligible": False,
                "next_action": "Media executor is ERROR/NOT_CREATED.", "error": None, "technical_cost_brl": 0,
                "updated_at": protocol._stamp(OBSERVED)}
            (root / protocol.QUALITY_EXECUTOR_STATUS_PATH).write_text(json.dumps(quality_source), encoding="utf-8")
            yield root, queue, media_source, quality_source

    def _completed_migration_dependencies(self, root, queue, media_source):
        media, media_evidence = protocol._completed_media_cycle_recovery_candidate(root, current=media_source, observed=OBSERVED)
        quality, quality_evidence = protocol._quality_retry_wait_candidate(root, observed=OBSERVED, media_override=media)
        snapshot = protocol.queue_snapshot(root, now=OBSERVED)
        stack = self._dependencies(root)
        stack.enter_context(patch.object(protocol, "queue_snapshot", return_value=snapshot))
        value = self._candidate_evidence()
        value[3].update(media_runtime_candidate=media, media_wait_evidence=media_evidence,
                        quality_runtime_candidate=quality, quality_retry_evidence=quality_evidence)
        stack.enter_context(patch.object(protocol, "_local_runtime_migration_candidates", return_value=value))
        return stack

    def test_completed_cycle_recovery_commit_real_reader_and_no_quality_before_d116(self):
        from hero_engine.phase6_maintenance_verification import verify_local_migration_evidence
        from hero_engine.phase6_quality import run_phase6_quality_executor
        from hero_engine.phase6_media import run_phase6_media_executor
        from hero_engine import phase6_quality as quality
        with self._completed_cycle_fixture() as (root, queue, source, quality_source):
            jobs = queue.snapshot(captured_at=OBSERVED)["jobs"]
            with self._completed_migration_dependencies(root, queue, source):
                result = self._run(root)
            verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)
            schema = json.loads((ROOT / "schemas/daily_maintenance_regression_receipt.schema.json").read_text())
            Draft202012Validator(schema["properties"]["local_runtime_migration"]).validate(result)
            self.assertEqual("COMPLETED", json.loads((root / protocol.MEDIA_EXECUTOR_STATUS_PATH).read_bytes())["status"])
            # Exercise the real next MEDIA -> QUALITY calls together. A valid
            # migration alone did not expose the original caller lifecycle bug.
            completed = run_phase6_media_executor(root, now=OBSERVED)
            self.assertEqual("COMPLETED", completed["status"])
            with patch.object(quality, "_verified_media", side_effect=AssertionError("must hold before QA")):
                held = run_phase6_quality_executor(root, now=OBSERVED)
            self.assertEqual(protocol.QUALITY_RETRY_HOLD, held["next_action"])
            self.assertFalse(held["publication_eligible"])
            self.assertEqual(jobs, queue.snapshot(captured_at=OBSERVED)["jobs"])
            # Historical verification must not demand a future mutable view stay frozen.
            # Runtime may legitimately refresh after the transaction. Current
            # maintenance requires frozen targets; archival validation does not.
            (root / protocol.MEDIA_EXECUTOR_STATUS_PATH).write_text('{}')
            with self.assertRaises(PermissionError):
                verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)
            verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result, scope="PAUSED_APPLICATION_ARCHIVE")

    def test_completed_cycle_recovery_rolls_back_both_views_on_commit_failure(self):
        with self._completed_cycle_fixture() as (root, queue, source, quality_source):
            before = {p: p.read_bytes() for p in (root / protocol.MEDIA_EXECUTOR_STATUS_PATH,
                      root / protocol.QUALITY_EXECUTOR_STATUS_PATH)}
            real = protocol._commit_migration_replacement
            def fail_quality(path, payload):
                if path == root / protocol.QUALITY_EXECUTOR_STATUS_PATH:
                    raise OSError("injected quality view commit failure")
                return real(path, payload)
            with self._completed_migration_dependencies(root, queue, source), patch.object(
                    protocol, "_commit_migration_replacement", side_effect=fail_quality):
                with self.assertRaisesRegex(PermissionError, "all targets were restored byte-for-byte") as caught:
                    self._run(root)
                self.assertIsInstance(caught.exception.__cause__, OSError)
                self.assertEqual("injected quality view commit failure", str(caught.exception.__cause__))
            for path, raw in before.items():
                self.assertEqual(raw, path.read_bytes())

    def test_completed_migration_through_fresh_cycle_and_public_d116_evaluator(self):
        from tests.test_phase6_maintenance_verification import Phase6PostMaintenanceVerificationTests
        from hero_engine.phase6_control_cycle import materialize as cycle_materialize
        from hero_engine import phase6_maintenance_verification as d
        from hero_engine.phase6_media import run_phase6_media_executor
        fixture = Phase6PostMaintenanceVerificationTests()
        with self._completed_cycle_fixture() as (root, queue, source, _):
            jobs_before = queue.snapshot(captured_at=OBSERVED)["jobs"]
            with self._completed_migration_dependencies(root, queue, source):
                migration = self._run(root)
            d.verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=migration)
            # Use the real completed executor and real immutable cycle producer.
            # Host and media inputs are synthetic; this is not PASS_LIVE evidence.
            values = list(fixture._fixtures())
            fixture._material_cycle(root, values[2])
            live = run_phase6_media_executor(root, now=datetime(2026, 9, 5, 12, 0, 12, tzinfo=timezone.utc))
            self.assertEqual("COMPLETED", live["status"])

            cycle_index = 0

            def cycle_for(value):
                nonlocal cycle_index
                cycle_index += 1
                (root / protocol.MEDIA_EXECUTOR_STATUS_PATH).write_text(json.dumps(value), encoding="utf-8")
                return cycle_materialize(root,
                    cycle_started_at=datetime(2026, 9, 5, 12, 0, 11, tzinfo=timezone.utc),
                    cycle_completed_at=datetime(2026, 9, 5, 12, 0, 20, cycle_index, tzinfo=timezone.utc))

            def align(current, media):
                projection = {key: media[key] for key in (
                    "input_receipt_id", "action", "job_state", "voice_manifest", "render_manifest",
                    "capacity_preflight_receipt", "capacity_status", "capacity_observed_free_bytes",
                    "capacity_required_free_bytes", "capacity_headroom_bytes", "next_action", "publication_authorized")}
                projection["executor_status"] = media["status"]
                current[4].update(media_execution=projection,
                    release_control={"publication_authorized": False, "next_video_authorized": True},
                    control_cycle={"cycle_id": current[2]["cycle_id"], "decision": current[2]["decision"]})

            values[2] = cycle_for(live)
            values[0]["local_runtime_migration"] = migration
            align(values, live)
            for relative in (d.MAINTENANCE_PATH, d.AUTOSTART_PATH, d.ACCEPTANCE_PATH):
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.write_text("{}", encoding="utf-8")
            result = fixture._evaluate(root, tuple(values))
            self.assertEqual("PASS", result["status"])
            Draft202012Validator(json.loads((ROOT / "schemas/phase6_post_maintenance_verification.schema.json").read_bytes())).validate(result)

            # A freshly authenticated cycle cannot silently replace the exact
            # committed media candidate, even with a matching executive view.
            for key, changed in (("job_id", "job-" + "0" * 24), ("input_receipt_id", "other"),
                                 ("voice_manifest", "other"), ("render_manifest", "other"),
                                 ("next_action", "retry now")):
                with self.subTest(live_field=key):
                    altered = {**live, key: changed}
                    divergent = deepcopy(values)
                    divergent[2] = cycle_for(altered)
                    align(divergent, altered)
                    with self.assertRaises(PermissionError):
                        fixture._evaluate(root, tuple(divergent))

            # The real stage producer rejects this authority even earlier, at
            # its schema. Do not manufacture an admissible cycle for the test.
            with self.assertRaises(ValidationError):
                cycle_for({**live, "publication_authorized": True})

            for key, changed in (("kind", "UNKNOWN_KIND"), ("status", "WAITING"),
                                 ("production_authorized", True), ("publication_authorized", True)):
                with self.subTest(migration_field=key):
                    divergent = deepcopy(values)
                    divergent[0]["local_runtime_migration"]["media_runtime_migration"][key] = changed
                    with self.assertRaises(PermissionError):
                        fixture._evaluate(root, tuple(divergent))
            for key, changed in (("render_manifest", "other"), ("job_state", "RETRY_WAIT"),
                                 ("next_action", "retry now"), ("publication_authorized", True)):
                with self.subTest(executive_field=key):
                    divergent = deepcopy(values)
                    divergent[4]["media_execution"][key] = changed
                    with self.assertRaises(PermissionError):
                        fixture._evaluate(root, tuple(divergent))

            journal_path = root / migration["transaction_journal_path"]
            target = next(row for row in json.loads(journal_path.read_bytes())["targets"]
                          if row["path"] == protocol.MEDIA_EXECUTOR_STATUS_PATH.as_posix())
            media_stage = next(row for row in values[2]["stages"] if row["stage"] == "MEDIA")
            for path in (journal_path, root / target["candidate_path"], root / media_stage["snapshot_path"]):
                with self.subTest(tampered=path.name):
                    raw = path.read_bytes()
                    try:
                        path.write_bytes(raw + b"\n")
                        with self.assertRaises(PermissionError):
                            fixture._evaluate(root, tuple(values))
                    finally:
                        path.write_bytes(raw)
            self.assertEqual("PASS", fixture._evaluate(root, tuple(values))["status"])
            self.assertEqual(jobs_before, queue.snapshot(captured_at=OBSERVED)["jobs"])

    def test_completed_cycle_recovery_rejects_other_error_and_quality_queue_change(self):
        with self._completed_cycle_fixture() as (root, queue, source, quality_source):
            media, evidence = protocol._completed_media_cycle_recovery_candidate(root, current=source, observed=OBSERVED)
            with self.assertRaises(PermissionError):
                protocol._completed_media_recovery_projection({**source, "job_id": "foreign"},
                    evidence["job"], evidence["capacity"], observed=OBSERVED)
            with queue._connection() as connection:
                connection.execute("UPDATE jobs SET last_error='other failure' WHERE task_type='EVALUATE_PHASE6_VIDEO2_QUALITY'")
            with self.assertRaisesRegex(PermissionError, "queue/render binding"):
                protocol._quality_retry_wait_candidate(root, observed=OBSERVED, media_override=media)

    def _quality_fixture(self, root):
        render_id = "render-phase6-" + "a" * 20
        manifest = {"render_id": render_id, "output": {"content_hash": "sha256:" + "b" * 64}}
        manifest_path = Path("output/production/phase6/video-002/renders/manifests") / (render_id + ".json")
        (root / manifest_path).parent.mkdir(parents=True)
        (root / manifest_path).write_text(json.dumps(manifest), encoding="utf-8")
        media = {"status": "COMPLETED", "job_state": "SUCCEEDED", "job_id": "job-media",
                 "render_manifest": manifest_path.as_posix(), "error": None, "publication_authorized": False}
        (root / protocol.MEDIA_EXECUTOR_STATUS_PATH).write_text(json.dumps(media), encoding="utf-8")
        current = {"schema_version": "1.0.0", "executor_id": "heroverse-phase6-quality-executor-v1",
                   "phase": 6, "status": "RETRY_WAIT", "media_render_id": render_id, "job_id": "job-quality",
                   "job_state": "RETRY_WAIT", "evaluation": None, "decision": "BLOCKED",
                   "publication_eligible": False, "next_action": "Repair the measured error.",
                   "error": protocol.QUALITY_RECOMPUTATION_ERROR, "technical_cost_brl": 0,
                   "updated_at": protocol._stamp(OBSERVED)}
        (root / protocol.QUALITY_EXECUTOR_STATUS_PATH).write_text(json.dumps(current), encoding="utf-8")
        jobs = [{"job_id": "job-quality", "idempotency_key": f"{render_id}:{manifest['output']['content_hash']}:independent-quality-v2",
                 "operation_id": "heroverse-phase6-controlled-longform-v1", "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                 "task_type": "EVALUATE_PHASE6_VIDEO2_QUALITY", "state": "RETRY_WAIT", "checkpoint": {},
                 "lease_owner": None, "lease_until": None, "last_error": protocol.QUALITY_RECOMPUTATION_ERROR,
                 "attempt_count": 1, "max_attempts": 3,
                 "payload": {"render_id": render_id, "render_hash": manifest["output"]["content_hash"]}},
                {"job_id": "job-media", "task_type": "EXECUTE_PHASE6_VIDEO2_MEDIA", "state": "SUCCEEDED",
                 "lease_owner": None, "lease_until": None, "checkpoint": {"render_id": render_id,
                 "render_manifest": manifest_path.as_posix(), "render_manifest_sha256": protocol.file_hash(root / manifest_path)}}]
        (root / "schemas").mkdir(exist_ok=True)
        schema_path = Path("schemas/phase6_quality_executor_runtime.schema.json")
        (root / schema_path).write_bytes((ROOT / schema_path).read_bytes())
        return current, jobs, media, manifest

    def _quality_dependencies(self, root, jobs):
        stack = self._dependencies(root)
        stack.enter_context(patch.object(protocol, "queue_snapshot", return_value={
            "jobs": jobs, "jobs_hash": protocol.canonical_hash(jobs)}))
        value = self._candidate_evidence()
        quality, evidence = protocol._quality_retry_wait_candidate(root, observed=OBSERVED)
        value[3].update(quality_runtime_candidate=quality, quality_retry_evidence=evidence)
        stack.enter_context(patch.object(protocol, "_local_runtime_migration_candidates", return_value=value))
        return stack

    def test_quality_retry_projection_preserves_error_and_does_not_touch_queue_or_media(self):
        with tempfile.TemporaryDirectory() as folder:
            root, _ = self._root(folder)
            current, jobs, media, manifest = self._quality_fixture(root)
            before = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
            with patch.object(protocol, "queue_snapshot", return_value={"jobs": jobs, "jobs_hash": protocol.canonical_hash(jobs)}):
                candidate, evidence = protocol._quality_retry_wait_candidate(root, observed=OBSERVED)
            self.assertEqual("WAITING", candidate["status"])
            self.assertEqual("RETRY_WAIT", candidate["job_state"])
            self.assertFalse(candidate["publication_eligible"])
            self.assertIsNone(candidate["evaluation"])
            self.assertEqual(protocol.QUALITY_RECOMPUTATION_ERROR, evidence["queue_jobs"][0]["last_error"])
            self.assertEqual(before, {p: p.read_bytes() for p in root.rglob("*") if p.is_file()})

    def test_quality_retry_projection_rejects_different_failures_leases_identity_and_authority(self):
        import copy
        with tempfile.TemporaryDirectory() as folder:
            root, _ = self._root(folder)
            source, jobs, media, manifest = self._quality_fixture(root)
            for field, bad in (("last_error", "other failure"), ("state", "SUCCEEDED"),
                               ("lease_owner", "writer"), ("lease_until", "2099-01-01T00:00:00Z"),
                               ("checkpoint", {"evaluation": "anything"}), ("attempt_count", 3),
                               ("payload", {}), ("task_type", "PUBLISH"), ("idempotency_key", "different")):
                changed = copy.deepcopy(jobs); changed[0][field] = bad
                with self.subTest(field=field), self.assertRaises(PermissionError):
                    protocol._quality_retry_projection(source, changed, media, manifest,
                        jobs[1]["checkpoint"]["render_manifest_sha256"], observed=OBSERVED)
            for field, bad in (("error", "another failure"), ("media_render_id", "other"),
                               ("evaluation", "evaluation.json"), ("publication_eligible", True),
                               ("job_id", "different"), ("decision", "PASS_LIMITED_RELEASE")):
                with self.subTest(field=field), self.assertRaises(PermissionError):
                    protocol._quality_retry_projection({**source, field: bad}, jobs, media, manifest,
                        jobs[1]["checkpoint"]["render_manifest_sha256"], observed=OBSERVED)
            with self.assertRaises(PermissionError):
                protocol._quality_retry_projection(source, jobs + [jobs[0]], media, manifest,
                    jobs[1]["checkpoint"]["render_manifest_sha256"], observed=OBSERVED)

    def test_quality_retry_transaction_commit_real_reader_and_immutable_history(self):
        from hero_engine.phase6_maintenance_verification import verify_local_migration_evidence
        with tempfile.TemporaryDirectory() as folder:
            root, _ = self._root(folder)
            current, jobs, media, manifest = self._quality_fixture(root)
            source = (root / protocol.QUALITY_EXECUTOR_STATUS_PATH).read_bytes()
            with self._quality_dependencies(root, jobs):
                result = self._run(root)
            verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)
            schema = json.loads((ROOT / "schemas/daily_maintenance_regression_receipt.schema.json").read_text())
            Draft202012Validator(schema["properties"]["local_runtime_migration"]).validate(result)
            journal = json.loads((root / result["transaction_journal_path"]).read_bytes())
            target = next(t for t in journal["targets"] if t["path"] == protocol.QUALITY_EXECUTOR_STATUS_PATH.as_posix())
            self.assertEqual(source, (root / target["before_path"]).read_bytes())
            self.assertEqual(protocol.canonical_hash(jobs), result["queue_jobs_hash_after"])
            self.assertEqual(media, json.loads((root / protocol.MEDIA_EXECUTOR_STATUS_PATH).read_bytes()))
            (root / protocol.QUALITY_EXECUTOR_STATUS_PATH).write_text('{"status":"new live state"}')
            with self.assertRaises(PermissionError):
                verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result)
            verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result, scope="PAUSED_APPLICATION_ARCHIVE")
            (root / target["candidate_path"]).write_bytes(b"tampered")
            with self.assertRaises(PermissionError):
                verify_local_migration_evidence(root, request_id=REQUEST_ID, migration=result, scope="PAUSED_APPLICATION_ARCHIVE")

    def test_quality_retry_transaction_rolls_back_own_targets_on_commit_or_later_failure(self):
        for failed_target in (protocol.QUALITY_EXECUTOR_STATUS_PATH, protocol.EXECUTIVE_STATUS_PATH):
            with self.subTest(target=failed_target), tempfile.TemporaryDirectory() as folder:
                root, initial = self._root(folder)
                _, jobs, _, _ = self._quality_fixture(root)
                quality_path = root / protocol.QUALITY_EXECUTOR_STATUS_PATH
                initial[quality_path] = (True, quality_path.read_bytes())
                commit = protocol._commit_migration_replacement
                def fail(path, payload):
                    if path == root / failed_target:
                        raise OSError("controlled replace failure")
                    commit(path, payload)
                with self._quality_dependencies(root, jobs), patch.object(protocol, "_commit_migration_replacement", side_effect=fail):
                    with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                        self._run(root)
                self._assert_preimages(self, initial)

    def test_quality_retry_transaction_rechecks_source_before_staging(self):
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder)
            _, jobs, _, _ = self._quality_fixture(root)
            with self._quality_dependencies(root, jobs):
                # A foreign edit after derivation is rejected, never overwritten.
                quality = root / protocol.QUALITY_EXECUTOR_STATUS_PATH
                foreign = json.loads(quality.read_bytes()); foreign["job_id"] = "foreign"
                quality.write_text(json.dumps(foreign))
                with self.assertRaises(PermissionError):
                    self._run(root)
                self.assertEqual(foreign, json.loads(quality.read_bytes()))
            self._assert_preimages(self, initial)

    def test_replace_bytes_retries_a_transient_windows_sharing_lock_without_changing_payload(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "derived.json"
            target.write_bytes(b"before\n")
            real_replace = protocol.os.replace
            calls = 0

            def transient_replace(source: str | Path, destination: str | Path) -> None:
                nonlocal calls
                calls += 1
                if calls <= 3:
                    raise PermissionError(5, "simulated transient Windows sharing lock")
                real_replace(source, destination)

            with patch.object(protocol.os, "replace", side_effect=transient_replace), patch.object(
                protocol.time, "sleep"
            ) as sleep:
                protocol._replace_bytes(target, b"after\n")

            self.assertEqual(4, calls)
            self.assertEqual(b"after\n", target.read_bytes())
            self.assertEqual(
                [(0.05,), (0.10,), (0.25,)],
                [call.args for call in sleep.call_args_list],
            )

    def test_replace_bytes_keeps_target_unchanged_when_sharing_lock_persists(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "derived.json"
            target.write_bytes(b"before\n")
            with patch.object(protocol.os, "replace", side_effect=PermissionError(5, "persistent lock")), patch.object(
                protocol.time, "sleep"
            ) as sleep:
                with self.assertRaisesRegex(PermissionError, "persistent lock"):
                    protocol._replace_bytes(target, b"after\n")
            self.assertEqual(b"before\n", target.read_bytes())
            self.assertEqual(
                len(protocol._MIGRATION_REPLACE_RETRY_DELAYS_SECONDS) - 1,
                sleep.call_count,
            )

    def _root(self, folder: str, *, with_cycle_error: bool = False) -> tuple[Path, dict[Path, tuple[bool, bytes]]]:
        root = Path(folder)
        request_path = root / protocol.REQUEST_PATH
        request_path.parent.mkdir(parents=True)
        request_path.write_text(
            json.dumps(
                {
                    "request_id": REQUEST_ID,
                    "external_effects_permitted": False,
                    "protected_due_guard_seconds": 1800,
                }
            ),
            encoding="utf-8",
        )
        runtime = root / protocol.PREDICTION_RUNTIME_PATH
        executive = root / protocol.EXECUTIVE_STATUS_PATH
        markdown = root / protocol.EXECUTIVE_STATUS_MARKDOWN_PATH
        runtime.parent.mkdir(parents=True)
        executive.parent.mkdir(parents=True, exist_ok=True)
        legacy = {
            "schema_version": "1.0.0",
            "observer_id": "heroverse-phase6-prediction-outcome-v1",
            "phase": 6,
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
            "status": "WAITING_FOR_HORIZON",
        }
        runtime.write_bytes(json.dumps(legacy).encode("utf-8") + b"\n")
        # Absence and an existing empty file must remain distinguishable.
        markdown.write_bytes(b"")
        initial = {
            runtime: (True, runtime.read_bytes()),
            executive: (False, b""),
            markdown: (True, b""),
        }
        if with_cycle_error:
            error = root / protocol.CONTROL_CYCLE_ERROR_PATH
            error.parent.mkdir(parents=True, exist_ok=True)
            error.write_text(
                json.dumps(
                    {
                        "schema_version": "1.0.0",
                        "phase": 6,
                        "status": "ERROR",
                        "error": (
                            "ValidationError in phase6_prediction_runtime.schema.json: "
                            "'outcome_snapshot_hash' is a required property; "
                            "prediction-iK_5edYQtx8-71b56a81a8345cd6; "
                            "job-21d66f6c4d850aae9fdb364b"
                        ),
                        "technical_cost_brl": 0,
                        "updated_at": "2026-09-05T13:59:00Z",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            initial[error] = (True, error.read_bytes())
        return root, initial

    @staticmethod
    def _candidate_evidence() -> tuple[dict, dict, str, dict]:
        runtime = {"schema_version": "1.1.0", "status": "WAITING_FOR_HORIZON"}
        executive = {"schema_version": "1.0.0", "status": "ACTIVE_OBSERVING"}
        source = {
            "prediction_path": "output/operations/phase6/intelligence/predictions/latest.json",
            "prediction_hash": "sha256:" + "a" * 64,
            "prediction_id": "prediction-iK_5edYQtx8-71b56a81a8345cd6",
            "queue_job_id": "job-21d66f6c4d850aae9fdb364b",
            "queue_job_state": "PENDING",
        }
        return runtime, executive, "# Executive\n", {
            "action": "MIGRATED_LEGACY_PREDICTION_RUNTIME",
            "source": source,
            "control_sources": {},
        }

    @staticmethod
    def _candidate_evidence_with_media() -> tuple[dict, dict, str, dict]:
        runtime, executive, markdown, evidence = (
            LocalRuntimeMigrationAtomicityTests._candidate_evidence()
        )
        proof = {
            "schema_version": "1.0.0",
            "proof_id": "phase6-post-effect-visual-wait-" + "a" * 24,
            "request_id": REQUEST_ID,
            "historical_artifacts": {
                "historical_renderer": "phase6-standard-v1",
                "required_renderer": "phase6-standard-v2",
            },
            "blocked_visual_preflight": {
                "audit_id": "visual-preflight-" + "b" * 24,
                "path": "output/operations/phase6/visual-preflight/audits/visual-preflight-"
                + "b" * 24
                + ".json",
                "sha256": "sha256:" + "c" * 64,
                "status": "BLOCKED",
            },
        }
        proof_payload = json.dumps(proof, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
        proof_sha = "sha256:" + hashlib.sha256(proof_payload).hexdigest()
        proof_path = (
            protocol.RUNTIME
            / "maintenance-runs"
            / REQUEST_ID
            / f"{proof['proof_id']}.json"
        ).as_posix()
        binding = {
            "proof_id": proof["proof_id"],
            "path": proof_path,
            "sha256": proof_sha,
            "status": "ELIGIBLE_FOR_WAITING_STATE",
            "reason": "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED",
            "request_id": REQUEST_ID,
            "authority_root_job_id": "job-ddc7d6b9605b194c44fd4f78",
            "authority_tail_job_id": "job-c516db5685acbbb423199bc1",
            "input_receipt_id": "phase6-production-inputs-79b3e183dd5df410fb3a",
            "chain_sha256": "sha256:" + "d" * 64,
            "checkpoint_sha256": "sha256:" + "e" * 64,
            "runtime_identity_sha256": "sha256:" + "f" * 64,
        }
        media = {
            "schema_version": "1.3.0",
            "executor_id": "heroverse-phase6-media-executor-v1",
            "phase": 6,
            "status": "WAITING",
            "input_receipt_id": "phase6-production-inputs-79b3e183dd5df410fb3a",
            "action": "WAIT",
            "job_id": "job-c516db5685acbbb423199bc1",
            "job_state": "SUCCEEDED",
            "voice_manifest": None,
            "render_manifest": None,
            "visual_preflight": {
                "audit_id": "visual-preflight-394d5a2f84d56d4a3570519f",
                "path": (
                    "output/operations/phase6/visual-preflight/audits/"
                    "visual-preflight-394d5a2f84d56d4a3570519f.json"
                ),
                "sha256": (
                    "sha256:a35f3479d434e4521dade63739372de1d7e28f2b6327466084d351e5a362c645"
                ),
                "status": "BLOCKED",
            },
            "capacity_preflight_receipt": None,
            "capacity_preflight_sha256": None,
            "capacity_status": "UNAVAILABLE",
            "capacity_observed_free_bytes": None,
            "capacity_required_free_bytes": None,
            "capacity_headroom_bytes": None,
            "next_action": "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED",
            "error": None,
            "publication_authorized": False,
            "technical_cost_brl": 0,
            "remediation_wait": binding,
            "updated_at": "2026-09-06T05:00:00Z",
        }
        identity = {
            key: value
            for key, value in media.items()
            if key not in {"updated_at", "remediation_wait"}
        }
        binding["runtime_identity_sha256"] = protocol.canonical_hash(identity)
        evidence.update(
            {
                "media_runtime_candidate": media,
                "media_wait_evidence": {
                    "proof": proof,
                    "proof_path": proof_path,
                    "proof_replayed": False,
                },
            }
        )
        return runtime, executive, markdown, evidence

    def _dependencies(self, root: Path) -> ExitStack:
        stack = ExitStack()
        stack.enter_context(patch.object(protocol, "validate", return_value=None))
        stack.enter_context(patch.object(protocol, "_process_alive", return_value=False))
        stack.enter_context(
            patch.object(protocol, "inspect_quiescence", return_value={"blockers": []})
        )
        stack.enter_context(
            patch.object(
                protocol,
                "queue_snapshot",
                return_value={"jobs_hash": "sha256:" + "1" * 64},
            )
        )
        stack.enter_context(
            patch.object(
                protocol,
                "ledger_state_snapshot",
                return_value={"state_hash": "sha256:" + "2" * 64},
            )
        )
        stack.enter_context(
            patch.object(
                protocol,
                "operational_effect_snapshot",
                return_value={"receipts_hash": "sha256:" + "3" * 64},
            )
        )
        stack.enter_context(
            patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=self._candidate_evidence(),
            )
        )
        stack.enter_context(
            patch.object(
                protocol,
                "_control_source_preview",
                return_value={"stage_count": 12, "all_schemas_valid": True, "blockers": []},
            )
        )
        return stack

    @staticmethod
    def _assert_preimages(test: unittest.TestCase, initial: dict[Path, tuple[bool, bytes]]) -> None:
        for path, (existed, payload) in initial.items():
            test.assertEqual(existed, path.is_file(), str(path))
            if existed:
                test.assertEqual(payload, path.read_bytes(), str(path))

    def _run(self, root: Path) -> dict:
        return protocol.migrate_local_runtime_views(
            root,
            request_id=REQUEST_ID,
            former_manager_pid=41001,
            former_launcher_pid=41002,
            evidence_dir=protocol.RUNTIME / "maintenance-runs" / REQUEST_ID,
            now=OBSERVED,
        )

    def test_every_sequential_replace_failure_restores_all_bytes_and_absence(self) -> None:
        for fail_at in (1, 2, 3):
            with self.subTest(fail_at=fail_at), tempfile.TemporaryDirectory() as folder:
                root, initial = self._root(folder)
                real_commit = protocol._commit_migration_replacement
                calls = 0

                def fail_one(path: Path, payload: bytes) -> None:
                    nonlocal calls
                    calls += 1
                    if calls == fail_at:
                        raise OSError(f"injected replace {fail_at}")
                    real_commit(path, payload)

                with self._dependencies(root), patch.object(
                    protocol, "_commit_migration_replacement", side_effect=fail_one
                ):
                    with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                        self._run(root)
                self._assert_preimages(self, initial)
                errors = list(
                    (root / protocol.RUNTIME / "maintenance-runs" / REQUEST_ID).glob(
                        "local-runtime-migration-error-*.json"
                    )
                )
                self.assertEqual(1, len(errors))
                receipt = json.loads(errors[0].read_text(encoding="utf-8"))
                self.assertEqual("ROLLED_BACK", receipt["record_type"])
                self.assertTrue(receipt["rollback"]["verified"])

    def test_media_wait_fourth_target_failure_restores_every_live_preimage(self) -> None:
        for fail_at in (1, 2, 3, 4):
            with self.subTest(fail_at=fail_at), tempfile.TemporaryDirectory() as folder:
                root, initial = self._root(folder)
                media = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
                media.parent.mkdir(parents=True, exist_ok=True)
                media.write_bytes(b'{"schema_version":"1.1.0","status":"ERROR"}\n')
                initial[media] = (True, media.read_bytes())
                real_commit = protocol._commit_migration_replacement
                calls = 0

                def fail_one(path: Path, payload: bytes) -> None:
                    nonlocal calls
                    calls += 1
                    if calls == fail_at:
                        raise OSError(f"injected media migration replace {fail_at}")
                    real_commit(path, payload)

                with self._dependencies(root), patch.object(
                    protocol,
                    "_local_runtime_migration_candidates",
                    return_value=self._candidate_evidence_with_media(),
                ), patch.object(
                    protocol, "_commit_migration_replacement", side_effect=fail_one
                ):
                    with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                        self._run(root)
                self._assert_preimages(self, initial)
                self.assertFalse((root / protocol.QUEUE_PATH).exists())

    def test_media_wait_commits_as_zero_effect_derived_target_with_bound_proof(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_bytes(b'{"schema_version":"1.1.0","status":"ERROR"}\n')
            candidate = self._candidate_evidence_with_media()
            with self._dependencies(root), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ):
                result = self._run(root)

            self.assertEqual("PASS", result["status"])
            self.assertEqual(candidate[0], json.loads((root / protocol.PREDICTION_RUNTIME_PATH).read_text(encoding="utf-8")))
            self.assertEqual(candidate[1], json.loads((root / protocol.EXECUTIVE_STATUS_PATH).read_text(encoding="utf-8")))
            self.assertEqual(candidate[3]["media_runtime_candidate"], json.loads(media_path.read_text(encoding="utf-8")))
            media_migration = result["media_runtime_migration"]
            self.assertEqual("WAITING", media_migration["status"])
            self.assertEqual(
                "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED",
                media_migration["reason"],
            )
            self.assertFalse(media_migration["production_authorized"])
            self.assertFalse(media_migration["publication_authorized"])
            proof_path = root / media_migration["proof_path"]
            self.assertTrue(proof_path.is_file())
            self.assertEqual(media_migration["proof_sha256"], protocol.file_hash(proof_path))
            journal = json.loads(
                (root / result["transaction_journal_path"]).read_text(encoding="utf-8")
            )
            outcome = json.loads(
                (root / result["transaction_outcome_path"]).read_text(encoding="utf-8")
            )
            self.assertEqual(media_migration, journal["media_runtime_migration"])
            self.assertEqual(media_migration, outcome["media_runtime_migration"])
            self.assertEqual(0, journal["external_api_calls"])
            self.assertEqual(0, journal["operational_queue_mutations"])
            self.assertEqual(0, outcome["publication_effects"])
            self.assertIn(media_migration["proof_path"], result["allowed_write_paths"])
            self.assertFalse((root / protocol.QUEUE_PATH).exists())

    def test_exact_owner_pause_media_recovery_commits_without_post_effect_proof(self) -> None:
        """The no-effect owner-pause recovery is not a post-effect lineage."""
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_bytes(b'{"schema_version":"1.1.0","status":"ERROR"}\n')
            candidate = self._candidate_evidence_with_media()
            media = candidate[3]["media_runtime_candidate"]
            media.pop("remediation_wait")
            media["next_action"] = (
                "OWNER_PAUSE_RELEASE_REQUIRED: no media command, voice, render, or "
                "publication effect occurred; resume only through the verified control cycle."
            )
            candidate[3]["media_wait_evidence"] = {
                "reason": "EXACT_OWNER_PAUSE_NO_EFFECT",
                "source_path": protocol.MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "source_sha256": "sha256:" + "4" * 64,
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "external_api_calls": 0,
                "production_effects": 0,
                "publication_effects": 0,
            }
            with self._dependencies(root), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ):
                result = self._run(root)

            migration = result["media_runtime_migration"]
            self.assertEqual("EXACT_OWNER_PAUSE_NO_EFFECT_RECOVERY", migration["kind"])
            self.assertEqual("WAITING", migration["status"])
            self.assertNotIn("proof_path", migration)
            self.assertFalse(migration["production_authorized"])
            self.assertFalse(migration["publication_authorized"])

    def test_prestart_identity_recovery_commits_as_zero_effect_current_wait(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_bytes(b'{"schema_version":"1.1.0","status":"ERROR"}\n')
            candidate = self._candidate_evidence_with_media()
            media = candidate[3]["media_runtime_candidate"]
            media.pop("remediation_wait")
            current_receipt = "phase6-production-inputs-" + "2" * 20
            current_contract = {
                "receipt_id": current_receipt,
                "authority": {
                    "queue": False, "voice": False, "render": False,
                    "quality": False, "publication": False,
                },
            }
            media.update(
                schema_version="1.2.0",
                status="WAITING",
                input_receipt_id=current_receipt,
                action="SYNTHESIZE_AND_RENDER_VIDEO_2",
                job_id=None,
                job_state="NOT_CREATED",
                visual_preflight=None,
                next_action=(
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
            )
            candidate[3]["media_wait_evidence"] = {
                "reason": "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT",
                "source_path": protocol.MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "source_sha256": protocol.file_hash(media_path),
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "input_receipt_id": current_receipt,
                "current_contract_sha256": protocol.canonical_hash(current_contract),
                "external_api_calls": 0,
                "production_effects": 0,
                "publication_effects": 0,
            }
            with self._dependencies(root), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ):
                result = self._run(root)

            migration = result["media_runtime_migration"]
            self.assertEqual(
                "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT_RECOVERY", migration["kind"]
            )
            self.assertEqual("WAITING", migration["status"])
            self.assertEqual(current_receipt, migration["input_receipt_id"])
            self.assertNotIn("proof_path", migration)
            self.assertEqual(0, migration["external_api_calls"])
            self.assertEqual(0, migration["operational_queue_mutations"])
            self.assertEqual(0, migration["publication_effects"])
            from hero_engine.phase6_maintenance_verification import (
                verify_local_migration_evidence,
            )
            with patch(
                "hero_engine.phase6_current_production_inputs.current_production_input_contract",
                return_value=current_contract,
            ):
                verify_local_migration_evidence(
                    root, request_id=REQUEST_ID, migration=result
                )

    def test_forward_current_wait_successor_commits_without_rebinding_historical_proof(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            candidate = self._candidate_evidence_with_media()
            evidence = candidate[3]
            historical = evidence["media_runtime_candidate"]
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_bytes(
                json.dumps(historical, ensure_ascii=False).encode("utf-8") + b"\n"
            )
            proof = evidence["media_wait_evidence"]["proof"]
            proof_path = root / evidence["media_wait_evidence"]["proof_path"]
            proof_path.parent.mkdir(parents=True, exist_ok=True)
            proof_path.write_bytes(
                json.dumps(proof, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
            )
            current_receipt = "phase6-production-inputs-" + "2" * 20
            current = {
                **historical,
                "schema_version": "1.2.0",
                "input_receipt_id": current_receipt,
                "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
                "job_id": None,
                "job_state": "NOT_CREATED",
                "visual_preflight": None,
                "next_action": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
            }
            current.pop("remediation_wait")
            authority = {
                "queue": False, "voice": False, "render": False,
                "quality": False, "publication": False,
            }
            evidence["media_runtime_candidate"] = current
            evidence["media_wait_evidence"] = {
                "proof": proof,
                "proof_path": proof_path.relative_to(root).as_posix(),
                "proof_replayed": True,
                "forward_successor": {
                    "receipt_id": current_receipt,
                    "authority": authority,
                },
                "historical_receipt_id": historical["input_receipt_id"],
            }
            with self._dependencies(root), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ):
                result = self._run(root)

            migration = result["media_runtime_migration"]
            self.assertEqual("FORWARD_CURRENT_INPUT_WAIT_SUCCESSOR", migration["kind"])
            self.assertEqual(current_receipt, migration["current_input_receipt_id"])
            self.assertEqual(
                historical["input_receipt_id"], migration["historical_receipt_id"]
            )
            self.assertEqual(
                protocol.canonical_hash(evidence["media_wait_evidence"]["forward_successor"]),
                migration["forward_contract_sha256"],
            )
            self.assertNotIn(proof_path.relative_to(root).as_posix(), result["allowed_write_paths"])
            self.assertFalse(migration["production_authorized"])
            self.assertFalse(migration["publication_authorized"])

    def test_forward_current_wait_heartbeat_commits_as_zero_authority_refresh(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            candidate = self._candidate_evidence_with_media()
            evidence = candidate[3]
            media = evidence["media_runtime_candidate"]
            media.pop("remediation_wait")
            media.update(
                schema_version="1.2.0",
                input_receipt_id="phase6-production-inputs-" + "2" * 20,
                action="SYNTHESIZE_AND_RENDER_VIDEO_2",
                job_id=None,
                job_state="NOT_CREATED",
                visual_preflight=None,
                next_action=(
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
            )
            media_path = root / protocol.MEDIA_EXECUTOR_STATUS_PATH
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_bytes(
                json.dumps(media, ensure_ascii=False).encode("utf-8") + b"\n"
            )
            evidence["media_runtime_candidate"] = {
                **media, "updated_at": "2026-09-17T12:40:00Z"
            }
            evidence["media_wait_evidence"] = {
                "reason": "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT",
                "source_path": protocol.MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "source_sha256": protocol.file_hash(media_path),
                "source_status": "WAITING",
                "candidate_status": "WAITING",
                "input_receipt_id": media["input_receipt_id"],
                "current_contract_sha256": "sha256:" + "7" * 64,
                "external_api_calls": 0,
                "production_effects": 0,
                "publication_effects": 0,
            }
            with self._dependencies(root), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ):
                result = self._run(root)

            migration = result["media_runtime_migration"]
            self.assertEqual("EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT", migration["kind"])
            self.assertEqual(media["input_receipt_id"], migration["input_receipt_id"])
            self.assertEqual(
                evidence["media_wait_evidence"]["current_contract_sha256"],
                migration["current_contract_sha256"],
            )
            self.assertFalse(migration["production_authorized"])
            self.assertFalse(migration["publication_authorized"])

    def test_final_source_validation_failure_restores_all_bytes_and_absence(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder)
            with self._dependencies(root):
                with patch.object(
                    protocol,
                    "_control_source_preview",
                    return_value={
                        "stage_count": 12,
                        "all_schemas_valid": False,
                        "blockers": ["PREDICTION_OUTCOME:INVALID"],
                    },
                ):
                    with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                        self._run(root)
            self._assert_preimages(self, initial)

    def test_correlated_legacy_error_is_archived_in_same_committed_transaction(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder, with_cycle_error=True)
            error_path = root / protocol.CONTROL_CYCLE_ERROR_PATH
            error_bytes = initial[error_path][1]
            with self._dependencies(root):
                result = self._run(root)
            self.assertEqual("PASS", result["status"])
            self.assertEqual(
                "ARCHIVED_CORRELATED_LEGACY_RUNTIME",
                result["control_cycle_error"]["action"],
            )
            self.assertFalse(error_path.exists())
            archive = root / result["control_cycle_error"]["archive_path"]
            self.assertEqual(error_bytes, archive.read_bytes())
            self.assertEqual(
                result["control_cycle_error"]["source_hash"],
                result["control_cycle_error"]["archive_hash"],
            )

    def test_unrelated_current_error_fails_closed_before_any_target_commit(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder, with_cycle_error=True)
            error_path = root / protocol.CONTROL_CYCLE_ERROR_PATH
            value = json.loads(error_path.read_text(encoding="utf-8"))
            value["error"] = "unrelated render failure"
            error_path.write_text(json.dumps(value) + "\n", encoding="utf-8")
            initial[error_path] = (True, error_path.read_bytes())
            with self._dependencies(root):
                with self.assertRaisesRegex(PermissionError, "not proven"):
                    self._run(root)
            self._assert_preimages(self, initial)
            self.assertFalse(
                (root / protocol.CONTROL_CYCLE_ERROR_ARCHIVE / REQUEST_ID).exists()
            )

    def test_existing_divergent_error_archive_is_never_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder, with_cycle_error=True)
            error_path = root / protocol.CONTROL_CYCLE_ERROR_PATH
            digest = protocol._hash_bytes(error_path.read_bytes()).split(":", 1)[1]
            archive = (
                root
                / protocol.CONTROL_CYCLE_ERROR_ARCHIVE
                / REQUEST_ID
                / f"control-cycle-error-{digest[:16]}.json"
            )
            archive.parent.mkdir(parents=True)
            archive.write_bytes(b"pre-existing divergent immutable evidence\n")
            initial[archive] = (True, archive.read_bytes())
            with self._dependencies(root):
                with self.assertRaisesRegex(PermissionError, "immutable.*collision"):
                    self._run(root)
            self._assert_preimages(self, initial)

    def test_error_archive_or_source_removal_failure_rolls_back_all_five_targets(self) -> None:
        for failed_boundary in ("archive", "removal"):
            with self.subTest(boundary=failed_boundary), tempfile.TemporaryDirectory() as folder:
                root, initial = self._root(folder, with_cycle_error=True)
                stack = self._dependencies(root)
                if failed_boundary == "archive":
                    real_commit = protocol._commit_migration_replacement

                    def fail_archive(path: Path, payload: bytes) -> None:
                        if (root / protocol.CONTROL_CYCLE_ERROR_ARCHIVE) in path.parents:
                            raise OSError("injected archive replace")
                        real_commit(path, payload)

                    stack.enter_context(
                        patch.object(
                            protocol,
                            "_commit_migration_replacement",
                            side_effect=fail_archive,
                        )
                    )
                else:
                    stack.enter_context(
                        patch.object(
                            protocol,
                            "_commit_migration_removal",
                            side_effect=OSError("injected source removal"),
                        )
                    )
                with stack:
                    with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                        self._run(root)
                self._assert_preimages(self, initial)
                self.assertEqual(
                    [],
                    list(
                        (root / protocol.CONTROL_CYCLE_ERROR_ARCHIVE / REQUEST_ID).glob(
                            "control-cycle-error-*.json"
                        )
                    ),
                )

    def test_transaction_schema_extension_is_valid_draft_202012(self) -> None:
        schema = json.loads(
            (ROOT / "schemas/daily_maintenance_regression_receipt.schema.json").read_text(
                encoding="utf-8"
            )
        )
        Draft202012Validator.check_schema(schema)

    def test_preview_without_request_is_non_authoritative_and_writes_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            sentinel = root / "sentinel.bin"
            sentinel.write_bytes(b"unchanged")
            before = {
                path.relative_to(root).as_posix(): path.read_bytes()
                for path in root.rglob("*")
                if path.is_file()
            }
            observed_request_ids: list[str] = []

            def candidates(
                _root: Path,
                *,
                observed: datetime,
                request_id: str | None = None,
            ) -> tuple[dict, dict, str, dict]:
                self.assertEqual(OBSERVED, observed)
                self.assertIsNotNone(request_id)
                assert request_id is not None
                self.assertRegex(
                    request_id,
                    r"^maintenance-request-[0-9]{8}T[0-9]{13}Z-[0-9a-f]{8}$",
                )
                observed_request_ids.append(request_id)
                runtime, executive, markdown, evidence = self._candidate_evidence_with_media()
                evidence["control_sources"] = {
                    "stage_count": 12,
                    "all_schemas_valid": True,
                    "blockers": [],
                }
                return runtime, executive, markdown, evidence

            with patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                side_effect=candidates,
            ):
                preview = protocol.preview_local_runtime_migration(
                    root,
                    now=OBSERVED,
                )

            after = {
                path.relative_to(root).as_posix(): path.read_bytes()
                for path in root.rglob("*")
                if path.is_file()
            }
            self.assertEqual(before, after)
            self.assertEqual(1, len(observed_request_ids))
            self.assertEqual(
                "PREVIEW_NOT_AN_EXECUTION_REQUEST",
                preview["request_authority"],
            )
            self.assertIsNone(preview["active_request_id"])
            self.assertRegex(
                preview["diagnostic_id"],
                r"^local-runtime-preview-[0-9a-f]{24}$",
            )
            self.assertEqual(12, preview["control_sources"]["stage_count"])
            self.assertTrue(preview["control_sources"]["all_schemas_valid"])
            self.assertEqual([], preview["control_sources"]["blockers"])
            self.assertEqual(0, preview["proofs_persisted"])
            self.assertEqual(0, preview["runtime_views_persisted"])
            self.assertFalse(preview["receipt_committed"])

    def test_preview_with_active_request_preserves_authoritative_identity(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, initial = self._root(folder)
            request_path = root / protocol.REQUEST_PATH
            request_bytes = request_path.read_bytes()
            captured: list[str | None] = []

            def candidates(
                _root: Path,
                *,
                observed: datetime,
                request_id: str | None = None,
            ) -> tuple[dict, dict, str, dict]:
                captured.append(request_id)
                runtime, executive, markdown, evidence = self._candidate_evidence()
                evidence["media_runtime_candidate"] = None
                evidence["media_wait_evidence"] = None
                evidence["control_sources"] = {
                    "stage_count": 12,
                    "all_schemas_valid": True,
                    "blockers": [],
                }
                return runtime, executive, markdown, evidence

            with patch.object(protocol, "validate", return_value=None), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                side_effect=candidates,
            ):
                preview = protocol.preview_local_runtime_migration(root, now=OBSERVED)

            self.assertEqual([REQUEST_ID], captured)
            self.assertEqual("ACTIVE_MAINTENANCE_REQUEST", preview["request_authority"])
            self.assertEqual(REQUEST_ID, preview["active_request_id"])
            self.assertEqual(request_bytes, request_path.read_bytes())
            self._assert_preimages(self, initial)

    @staticmethod
    def _write_exact_executive_replace_error(root: Path) -> bytes:
        executive_path = root / protocol.EXECUTIVE_STATUS_PATH
        markdown_path = root / protocol.EXECUTIVE_STATUS_MARKDOWN_PATH
        executive_path.parent.mkdir(parents=True, exist_ok=True)
        executive = {
            "captured_at": "2026-09-06T03:00:00Z",
            "media_execution": {
                "executor_status": "BLOCKED",
                "input_receipt_id": "phase6-production-inputs-79b3e183dd5df410fb3a",
                "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
                "job_state": "NOT_CREATED",
                "voice_manifest": None,
                "render_manifest": None,
                "capacity_preflight_receipt": None,
                "capacity_status": "UNAVAILABLE",
                "next_action": protocol.EXACT_VISUAL_BLOCKED_NEXT_ACTION,
                "publication_authorized": False,
            },
        }
        executive_path.write_text(json.dumps(executive), encoding="utf-8")
        markdown_path.write_text("# coherent\n", encoding="utf-8")
        fixed_tmp = Path(str(executive_path) + ".tmp")
        expected_target = str(executive_path.resolve()).replace("\\", "\\\\")
        expected_tmp = str(fixed_tmp.resolve()).replace("\\", "\\\\")
        error_path = root / protocol.CONTROL_CYCLE_ERROR_PATH
        error_path.parent.mkdir(parents=True, exist_ok=True)
        value = {
            "schema_version": "1.0.0",
            "phase": 6,
            "status": "ERROR",
            "error": (
                "PermissionError: [WinError 5] Acesso negado: "
                f"'{expected_tmp}' -> '{expected_target}'"
            ),
            "technical_cost_brl": 0,
            "updated_at": protocol.LEGACY_EXECUTIVE_REPLACE_ERROR_UPDATED_AT,
        }
        error_path.write_bytes(
            json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
        )
        return error_path.read_bytes()

    def test_preview_proves_exact_historical_executive_replace_before_stop(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            payload = self._write_exact_executive_replace_error(root)
            def candidates(
                _root: Path,
                *,
                observed: datetime,
                request_id: str | None = None,
            ) -> tuple[dict, dict, str, dict]:
                self.assertIsNotNone(request_id)
                assert request_id is not None
                candidate = self._candidate_evidence_with_media()
                candidate[3]["action"] = "NO_CHANGE"
                candidate[3]["source"] = {
                    "prediction_path": None,
                    "prediction_hash": None,
                    "prediction_id": None,
                    "queue_job_id": None,
                    "queue_job_state": None,
                }
                binding = candidate[3]["media_runtime_candidate"]["remediation_wait"]
                binding["request_id"] = request_id
                binding["path"] = (
                    protocol.RUNTIME
                    / "maintenance-runs"
                    / request_id
                    / f"{binding['proof_id']}.json"
                ).as_posix()
                return candidate
            before = {
                path.relative_to(root).as_posix(): path.read_bytes()
                for path in root.rglob("*")
                if path.is_file()
            }
            digest = protocol._hash_bytes(payload)
            with patch.object(protocol, "validate", return_value=None), patch.object(
                protocol,
                "LEGACY_EXECUTIVE_REPLACE_ERROR_SHA256",
                digest,
            ), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                side_effect=candidates,
            ), patch(
                "hero_engine.phase6_reporting._markdown",
                return_value="# coherent\n",
            ):
                preview = protocol.preview_local_runtime_migration(root, now=OBSERVED)
            after = {
                path.relative_to(root).as_posix(): path.read_bytes()
                for path in root.rglob("*")
                if path.is_file()
            }
            self.assertEqual(before, after)
            error = preview["control_cycle_error"]
            self.assertEqual(
                "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE", error["action"]
            )
            self.assertEqual(digest, error["source_hash"])
            self.assertEqual(digest, error["archive_hash"])
            self.assertEqual(12, len(error["correlation_checks"]))
            self.assertFalse(preview["receipt_committed"])
            self.assertEqual(0, preview["runtime_views_persisted"])

    def test_executive_replace_correlation_rejects_tamper_and_unresolved_writer(self) -> None:
        cases = ("hash", "markdown", "media", "tmp", "writer")
        for case in cases:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as folder:
                root = Path(folder)
                payload = self._write_exact_executive_replace_error(root)
                candidate = self._candidate_evidence_with_media()[3][
                    "media_runtime_candidate"
                ]
                assert candidate is not None
                digest = protocol._hash_bytes(payload)
                if case == "markdown":
                    (root / protocol.EXECUTIVE_STATUS_MARKDOWN_PATH).write_text(
                        "diverged\n", encoding="utf-8"
                    )
                elif case == "media":
                    candidate["job_id"] = "job-" + "9" * 24
                elif case == "tmp":
                    Path(str(root / protocol.EXECUTIVE_STATUS_PATH) + ".tmp").write_text(
                        "stale", encoding="utf-8"
                    )
                expected_hash = (
                    "sha256:" + "0" * 64 if case == "hash" else digest
                )
                marker = (
                    "phase6-executive-atomic-writer-v1"
                    if case == "writer"
                    else protocol.EXECUTIVE_ATOMIC_WRITER_REQUIRED
                )
                with patch.object(protocol, "validate", return_value=None), patch.object(
                    protocol,
                    "LEGACY_EXECUTIVE_REPLACE_ERROR_SHA256",
                    expected_hash,
                ), patch(
                    "hero_engine.phase6_reporting._markdown",
                    return_value="# coherent\n",
                ), patch(
                    "hero_engine.phase6_reporting.EXECUTIVE_ATOMIC_WRITER_VERSION",
                    marker,
                ):
                    with self.assertRaisesRegex(PermissionError, "not proven historical"):
                        protocol._correlated_legacy_control_cycle_error(
                            root,
                            request_id=REQUEST_ID,
                            migration_action="NO_CHANGE",
                            legacy_runtime_bytes=b"{}",
                            migration_source={
                                "prediction_path": None,
                                "prediction_hash": None,
                                "prediction_id": None,
                                "queue_job_id": None,
                                "queue_job_state": None,
                            },
                            media_candidate=candidate,
                        )

    def test_exact_executive_replace_error_archives_inside_media_wait_transaction(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root, _initial = self._root(folder)
            payload = self._write_exact_executive_replace_error(root)
            candidate = self._candidate_evidence_with_media()
            candidate[3]["action"] = "NO_CHANGE"
            candidate[3]["source"] = {
                "prediction_path": None,
                "prediction_hash": None,
                "prediction_id": None,
                "queue_job_id": None,
                "queue_job_state": None,
            }
            digest = protocol._hash_bytes(payload)
            with self._dependencies(root), patch.object(
                protocol,
                "LEGACY_EXECUTIVE_REPLACE_ERROR_SHA256",
                digest,
            ), patch.object(
                protocol,
                "_local_runtime_migration_candidates",
                return_value=candidate,
            ), patch(
                "hero_engine.phase6_reporting._markdown",
                return_value="# coherent\n",
            ):
                result = self._run(root)
            error = result["control_cycle_error"]
            self.assertEqual(
                "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE", error["action"]
            )
            self.assertEqual(digest, error["source_hash"])
            self.assertFalse((root / error["source_path"]).exists())
            self.assertEqual(payload, (root / error["archive_path"]).read_bytes())
            journal = json.loads(
                (root / result["transaction_journal_path"]).read_text(encoding="utf-8")
            )
            outcome = json.loads(
                (root / result["transaction_outcome_path"]).read_text(encoding="utf-8")
            )
            self.assertEqual(error["action"], journal["control_cycle_error_action"])
            self.assertEqual(error["action"], outcome["control_cycle_error_action"])
            self.assertEqual(0, result["operational_queue_mutations"])
            self.assertEqual(0, result["publication_effects"])


class RecoveryWindowBindingTests(unittest.TestCase):
    def test_valid_marker_for_different_active_request_is_inert(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "schemas").mkdir()
            for name in (
                "central_manager_maintenance_request.schema.json",
                "central_manager_maintenance_recovery_window.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            request_a = "maintenance-request-20260905T1400000000000Z-aaaaaaaa"
            request_b = "maintenance-request-20260905T1400010000000Z-bbbbbbbb"
            protocol.create_request(
                root,
                request_id=request_a,
                requester_pid=99,
                guard_seconds=1800,
                requested_at=OBSERVED,
            )
            protocol.arm_recovery_window(
                root,
                request_id=request_a,
                manager_pid=4242,
                duration_seconds=120,
                armed_at=OBSERVED,
            )
            request_path = root / protocol.REQUEST_PATH
            request = json.loads(request_path.read_text(encoding="utf-8"))
            request["request_id"] = request_b
            request_path.write_text(json.dumps(request) + "\n", encoding="utf-8")
            self.assertIsNone(
                protocol.recovery_window_state(
                    root,
                    manager_pid=4242,
                    now=datetime(2026, 9, 5, 14, 0, 30, tzinfo=timezone.utc),
                )
            )
            self.assertTrue(protocol.maintenance_barrier(root, manager_pid=4242))


if __name__ == "__main__":
    unittest.main()
