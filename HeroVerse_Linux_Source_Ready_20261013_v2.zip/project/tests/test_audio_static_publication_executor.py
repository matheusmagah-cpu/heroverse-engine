"""Native current release rejection + real checkpoint engine; provider is simulated."""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from jsonschema.exceptions import ValidationError
from tests import test_audio_static_release_gate as current
from hero_engine import phase5_youtube_publisher as publisher
from hero_engine.phase5_release_gate import materialize
from hero_engine.phase6_publication import PublicationLock, PublicationAlreadyRunning

ROOT = Path(__file__).resolve().parents[1]
RECORD = ROOT/'output/runtime/gestor-central/maintenance-runs/audio-static-publication-executor-20261005'


class ContainedPrivateThumbnailTests(unittest.TestCase):
    """Real package/release/receipt/hash/OS-lock consumers in temporary roots.

    Codec/neural measurements and the YouTube transport are fixture boundaries;
    this proves local incident custody, NEVER real media quality or API success.
    """

    def setUp(self):
        from tests.test_rest_music_final_qualification import RestMusicFinalQualificationTests
        from tests.test_rest_music_native_inputs import write, pin
        if (self._testMethodName == 'test_narrated_captions_and_mutable_readiness_have_separate_scopes'
                or self._testMethodName.startswith('test_observed_public_custody_')):
            from tests.test_rest_editorial_final_consumers import RestEditorialFinalConsumerTests
            self.owner = RestEditorialFinalConsumerTests('test_explicit_profile_v4_composed_native_final_consumers')
        else:
            self.owner = RestMusicFinalQualificationTests(
                'test_current_report_authenticates_instrumental_producers_without_voice_fallback')
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        self.root, self.package, self.relative = self.owner.root, self.owner.package, self.owner.relative
        write(Path(self.owner.control_binding['path']), self.owner.controls)
        self.owner.control_binding = pin(Path(self.owner.control_binding['path']))
        self.bindings, self.release_pin, self.release = self.owner.ready_release()
        self.calls = []
        calls = self.calls
        class Request:
            def __init__(self, service, method): self.service, self.method = service, method
            def next_chunk(self): return None, self.execute()
            def execute(self):
                calls.append((self.service, self.method))
                if self.service == 'channels': return {'items': [{'id': publisher.CHANNEL_ID}]}
                if self.service == 'thumbnails':
                    raise ConnectionAbortedError(10053, 'controlled lost response')
                return {'id': 'OWNED_PRIVATE_FIXTURE'}
        class Service:
            def __init__(self, name): self.name = name
            def __getattr__(self, method): return lambda **kwargs: Request(self.name, method)
        class Provider:
            def __getattr__(self, name): return lambda: Service(name)
        with self.assertRaisesRegex(RuntimeError, '10053'):
            publisher.execute_publication_pipeline(Provider(), lambda *_a, **_k: object(),
                self.root, package_relative=self.relative, current_bindings=self.bindings,
                expected_release_hash=self.release_pin['sha256'])
        self.receipt = self.package/'youtube-publication-receipt.json'
        self.original = self.receipt.read_bytes()
        self.pause = self.root/'output/runtime/gestor-central/PAUSE'
        self.pause.parent.mkdir(parents=True, exist_ok=True)
        self.pause.write_bytes(b'OWNER_PAUSE_FIXTURE')
        # Every negative starts from a genuinely accepted custody baseline;
        # an unrelated fixture refusal cannot count as a passing contraproof.
        baseline = publisher.read_contained_thumbnail_checkpoint(self.root, self.receipt)
        self.assertEqual(baseline['remote_thumbnail_outcome'], 'UNKNOWN')
        self.assertIs(baseline['publication_authorized'], False)

    def snapshot(self, contained=True):
        from hero_engine.maintenance_protocol import operational_effect_snapshot
        return operational_effect_snapshot(self.root, contain_private_thumbnail=contained)

    def observed_checkpoint(self):
        """Real observation/archive writer; only the provider transport is simulated."""
        provider = Mock()
        provider.channels.return_value.list.return_value.execute.return_value = {
            'items': [{'id': publisher.CHANNEL_ID}]}
        before = json.loads(self.original)
        provider.videos.return_value.list.return_value.execute.return_value = {'items': [{
            'id': before['video_id'], 'snippet': {'channelId': publisher.CHANNEL_ID,
            'thumbnails': {'high': {'url': 'https://i.ytimg.com/owned.jpg'}}},
            'status': {'privacyStatus': 'public', 'uploadStatus': 'processed'}}]}
        payload = Path(self.release['artifacts']['thumbnail']['path']).read_bytes()
        with patch('hero_engine.phase6_publication._fetch_public_thumbnail', return_value=payload):
            publisher.reconcile_private_thumbnail(provider, self.root, package_relative=self.relative,
                current_bindings=self.bindings, expected_release_hash=self.release_pin['sha256'],
                expected_receipt_hash='sha256:' + publisher._hash(self.receipt), observed_public=True)
        provider.thumbnails.assert_not_called(); provider.captions.assert_not_called()
        provider.videos.return_value.insert.assert_not_called()
        provider.videos.return_value.update.assert_not_called()
        self.original = self.receipt.read_bytes()
        return provider

    def test_observed_public_custody_preserves_pending_receipt_and_has_no_effect_authority(self):
        provider = self.observed_checkpoint(); provider.reset_mock()
        self.assertTrue(self.snapshot(False)['open_receipt_paths'])
        result = self.snapshot()
        self.assertEqual(result['open_receipt_paths'], [])
        item = result['receipts'][0]
        self.assertEqual(item['status'], 'PUBLIC_AWAITING_VERIFICATION')
        custody = item['contained_for_maintenance']
        self.assertEqual(custody['purpose'], 'CONTAINED_OBSERVED_PUBLIC_FOR_LOCAL_MAINTENANCE_ONLY')
        for field in ('remote_recovery_authorized', 'upload_authorized', 'publication_authorized'):
            self.assertIs(custody[field], False)
        self.assertEqual(self.receipt.read_bytes(), self.original)
        with self.assertRaisesRegex(PermissionError, 'paused'):
            publisher.execute_publication_pipeline(provider, Mock(), self.root,
                package_relative=self.relative, current_bindings=self.bindings,
                expected_release_hash=self.release_pin['sha256'])
        provider.assert_not_called(); self.assertEqual(provider.mock_calls, [])

    def test_observed_public_custody_unknown_mutation_is_still_blocked(self):
        self.observed_checkpoint()
        for name in ('CAPTIONS_INSERT', 'PROMOTE_PUBLIC', 'VIDEO_PRIVATE_UPLOAD', 'THUMBNAIL_RECOVERY'):
            with self.subTest(effect=name):
                self.alter_receipt(lambda row: row['steps'].append({
                    'step': name + '_BEFORE', 'status': 'NOT_RUN', 'evidence': 'unknown response'}))
                self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.receipt.write_bytes(self.original)

    def test_observed_public_custody_archive_and_frozen_artifact_tamper_are_blocked(self):
        self.observed_checkpoint()
        observation = next((self.package/'publication-reconciliation').glob('*/observation.json'))
        paths = [observation, observation.parent/'receipt-before.json', observation.parent/'remote-thumbnail.bin']
        paths += [Path(self.release['artifacts'][name]['path']) for name in ('video', 'thumbnail', 'captions')]
        for path in paths:
            with self.subTest(path=path.name):
                raw = path.read_bytes()
                try:
                    path.write_bytes(raw + b'TAMPER')
                    self.assertTrue(self.snapshot()['open_receipt_paths'])
                finally:
                    path.write_bytes(raw)

    def test_observed_public_custody_foreign_identity_no_archive_and_active_writer_are_blocked(self):
        self.observed_checkpoint()
        for field, value in (('video_id', 'FOREIGN'), ('channel_id', 'FOREIGN'), ('idempotency_key', 'f'*64)):
            with self.subTest(field=field):
                self.alter_receipt(lambda row: row.update({field: value}))
                self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.receipt.write_bytes(self.original)
        with PublicationLock(self.root):
            self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.pause.unlink()
        self.assertTrue(self.snapshot()['open_receipt_paths'])

    def test_observed_public_custody_archive_changes_during_capture_are_rejected(self):
        self.observed_checkpoint()
        observation = next((self.package/'publication-reconciliation').glob('*/observation.json'))
        real_hash = publisher._hash
        changed = []
        def change(path):
            result = real_hash(path)
            if path == Path(self.release['artifacts']['video']['path']) and not changed:
                observation.write_bytes(observation.read_bytes() + b'TAMPER'); changed.append(True)
            return result
        with patch.object(publisher, '_hash', side_effect=change), self.assertRaises(PermissionError):
            publisher.read_contained_thumbnail_checkpoint(self.root, self.receipt)
        self.assertTrue(changed)

    def test_observed_public_custody_native_transaction_boundary_accepts_only_stopped_scope(self):
        import sqlite3
        from contextlib import closing
        from hero_engine import maintenance_protocol as protocol
        from tests.test_paused_maintenance_cancellation import fixtures, QUOTA_TABLES
        self.observed_checkpoint()
        fixtures.DailyMaintenanceProtocolTests._queue(self.root, state='SUCCEEDED',
            task_type='SYNTHETIC_COMPLETED_TASK', available_at='2020-01-01T00:00:00Z')
        ledger = self.root/protocol.QUOTA_LEDGER_PATH; ledger.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(ledger)) as connection, connection:
            for table, key in QUOTA_TABLES:
                connection.execute(f'CREATE TABLE {table} ({key} TEXT PRIMARY KEY,state TEXT)')
                connection.execute(f'INSERT INTO {table} VALUES (?,?)', (table, 'CONSUMED'))
        with self.assertRaisesRegex(PermissionError, 'CANCEL_OPEN_OR_UNKNOWN_EFFECT'):
            protocol._paused_cancel_boundary(self.root, database_root=self.root)
        boundary = protocol._paused_cancel_boundary(self.root, database_root=self.root, contain_private_thumbnail=True)
        self.assertEqual(boundary['effects']['open_receipt_paths'], [])
        self.assertEqual(boundary['effects']['receipts'][0]['status'], 'PUBLIC_AWAITING_VERIFICATION')
        self.assertEqual(self.receipt.read_bytes(), self.original)
        with PublicationLock(self.root), self.assertRaisesRegex(PermissionError, 'CANCEL_OPEN_OR_UNKNOWN_EFFECT'):
            protocol._paused_cancel_boundary(self.root, database_root=self.root, contain_private_thumbnail=True)

    def alter_receipt(self, change):
        value = json.loads(self.original)
        change(value)
        self.receipt.write_text(json.dumps(value), encoding='utf-8')

    def test_strict_default_preserved_and_custody_has_no_remote_authority(self):
        strict = self.snapshot(False)
        self.assertEqual(strict['open_receipt_paths'], [self.receipt.relative_to(self.root).as_posix()])
        count = len(self.calls)
        result = self.snapshot()
        self.assertEqual(result['open_receipt_paths'], [])
        item = result['receipts'][0]
        self.assertEqual(item['status'], 'PARTIAL_PRIVATE_VIDEO')
        self.assertEqual(item['open_reasons'], ['PARTIAL_PRIVATE_VIDEO'])
        custody = item['contained_for_maintenance']
        self.assertEqual(custody['remote_thumbnail_outcome'], 'UNKNOWN')
        for field in ('remote_recovery_authorized', 'upload_authorized', 'publication_authorized'):
            self.assertIs(custody[field], False)
        self.assertEqual(self.receipt.read_bytes(), self.original)
        self.assertEqual(len(self.calls), count)
        self.assertEqual(self.calls.count(('videos', 'insert')), 1)

    def test_each_frozen_artifact_tamper_keeps_incident_blocked(self):
        for name in ('video', 'thumbnail'):
            with self.subTest(name=name):
                target = Path(self.release['artifacts'][name]['path'])
                raw = target.read_bytes()
                try:
                    target.write_bytes(raw + b'TAMPER')
                    self.assertTrue(self.snapshot()['open_receipt_paths'])
                finally:
                    target.write_bytes(raw)

    def test_provenance_tamper_is_not_custody(self):
        package = json.loads((self.package/'publication_package.json').read_bytes())
        for ref in list(package['music_bindings'].values()) + list(package['music_qualification_bindings'].values()):
            with self.subTest(path=ref['path']):
                target = Path(ref['path']); raw = target.read_bytes()
                try:
                    target.write_bytes(raw + b'TAMPER')
                    self.assertTrue(self.snapshot()['open_receipt_paths'])
                finally:
                    target.write_bytes(raw)

    def test_identity_substitution_never_hides_open_checkpoint(self):
        for field, value in (('video_id', 'FOREIGN_VIDEO'), ('idempotency_key', 'f'*64),
                             ('release_id', 'phase5-release-'+'f'*20)):
            with self.subTest(field=field):
                self.alter_receipt(lambda row: row.update({field: value}))
                self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.receipt.write_bytes(self.original)

    def test_other_pending_effect_or_used_recovery_remains_blocked(self):
        for step in ('CAPTIONS_INSERT_BEFORE', 'PROMOTE_PUBLIC_BEFORE', 'THUMBNAIL_RECOVERY_BEFORE'):
            with self.subTest(step=step):
                self.alter_receipt(lambda row: row['steps'].append(
                    {'step': step, 'status': 'NOT_RUN', 'evidence': 'controlled pending effect'}))
                self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.receipt.write_bytes(self.original)

    def test_expired_recovery_window_is_not_extended_by_maintenance(self):
        self.alter_receipt(lambda row: row.update(updated_at='2020-01-01T00:00:00Z'))
        before = self.receipt.read_bytes(); count = len(self.calls)
        self.assertFalse(self.snapshot()['open_receipt_paths'])
        self.assertFalse(publisher._thumbnail_recovery_eligible(json.loads(before), explicit_current=True))
        self.assertEqual(self.receipt.read_bytes(), before)
        self.assertEqual(len(self.calls), count)

    def test_change_after_capture_is_rejected_before_custody_use(self):
        package = self.package/'publication_package.json'
        raw = package.read_bytes()
        real_hash = publisher._hash
        changed = []
        def concurrent_change(path):
            result = real_hash(path)
            if path == Path(self.release['artifacts']['video']['path']) and not changed:
                value = json.loads(raw); value['metadata']['title'] += ' changed during capture'
                package.write_text(json.dumps(value), encoding='utf-8'); changed.append(True)
            return result
        try:
            with patch.object(publisher, '_hash', side_effect=concurrent_change):
                with self.assertRaisesRegex(PermissionError, 'changed during capture'):
                    publisher.read_contained_thumbnail_checkpoint(self.root, self.receipt)
            self.assertTrue(changed)
        finally:
            package.write_bytes(raw)

    def test_active_native_publication_handle_blocks_custody(self):
        with PublicationLock(self.root):
            self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.assertFalse(self.snapshot()['open_receipt_paths'])

    def test_missing_pause_and_missing_live_request_blocks_custody(self):
        self.pause.unlink()
        self.assertTrue(self.snapshot()['open_receipt_paths'])
        self.assertEqual(self.receipt.read_bytes(), self.original)

    def test_release_or_package_identity_tamper_blocks_custody(self):
        for name in ('release_gate.json', 'publication_package.json'):
            with self.subTest(name=name):
                path = self.package/name; raw = path.read_bytes(); value = json.loads(raw)
                value['package_id'] = 'instrumental-publication-'+'f'*24
                try:
                    path.write_text(json.dumps(value), encoding='utf-8')
                    self.assertTrue(self.snapshot()['open_receipt_paths'])
                finally:
                    path.write_bytes(raw)

    def test_paused_executor_remains_closed_even_with_accepted_custody(self):
        self.assertFalse(self.snapshot()['open_receipt_paths'])
        provider = Mock()
        with self.assertRaisesRegex(PermissionError, 'paused'):
            publisher.execute_publication_pipeline(provider, Mock(), self.root,
                package_relative=self.relative, current_bindings=self.bindings,
                expected_release_hash=self.release_pin['sha256'])
        self.assertEqual(provider.mock_calls, [])
        self.assertEqual(self.receipt.read_bytes(), self.original)

    def test_narrated_captions_and_mutable_readiness_have_separate_scopes(self):
        self.assertEqual(self.release['schema_version'], '1.3.0')
        self.assertFalse(self.snapshot()['open_receipt_paths'])
        captions = Path(self.release['artifacts']['captions']['path'])
        raw = captions.read_bytes()
        captions.write_bytes(raw+b'TAMPER')
        self.assertTrue(self.snapshot()['open_receipt_paths'])
        captions.write_bytes(raw)
        readiness = self.root/'output/integrations/youtube/heroverse/operational-readiness.json'
        value = json.loads(readiness.read_bytes()); value['continuous_operation_ready'] = False
        readiness.write_text(json.dumps(value), encoding='utf-8')
        # Historical private-upload custody does not certify current OAuth.
        self.assertFalse(self.snapshot()['open_receipt_paths'])
        with self.assertRaises(PermissionError):
            publisher._validate_current_release(self.root, self.relative, self.bindings, self.release_pin['sha256'])
        self.assertEqual(self.receipt.read_bytes(), self.original)

    def test_native_paused_boundary_and_quiescence_consume_custody_not_terminal_pass(self):
        import sqlite3
        from contextlib import closing
        from datetime import datetime, timedelta, timezone
        from hero_engine import maintenance_protocol as protocol
        from tests.test_paused_maintenance_cancellation import fixtures, QUOTA_TABLES
        fixtures.DailyMaintenanceProtocolTests._queue(self.root, state='SUCCEEDED',
            task_type='SYNTHETIC_COMPLETED_TASK', available_at='2020-01-01T00:00:00Z')
        ledger = self.root/protocol.QUOTA_LEDGER_PATH
        ledger.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(ledger)) as connection, connection:
            for table, key in QUOTA_TABLES:
                connection.execute(f'CREATE TABLE {table} ({key} TEXT PRIMARY KEY,state TEXT)')
                connection.execute(f'INSERT INTO {table} VALUES (?,?)', (table+'-fixture', 'CONSUMED'))
        with self.assertRaisesRegex(PermissionError, 'CANCEL_OPEN_OR_UNKNOWN_EFFECT'):
            protocol._paused_cancel_boundary(self.root, database_root=self.root)
        boundary = protocol._paused_cancel_boundary(self.root, database_root=self.root,
            contain_private_thumbnail=True)
        self.assertEqual(boundary['effects']['open_receipt_paths'], [])
        self.assertEqual(boundary['effects']['receipts'][0]['status'], 'PARTIAL_PRIVATE_VIDEO')
        # The actual quiescence consumer reads real SQL, schemas and receipts.
        # PID/lease metadata are synthetic, not a claim of a live production leader.
        shutil.copy2(ROOT/'schemas/central_manager_lock.schema.json', self.root/'schemas')
        now = datetime.now(timezone.utc)
        lock = {'schema_version':'1.0.0', 'lock_id':'gestor-central-heroverse-phase5-singleton-v1',
            'state':'HELD', 'holder_pid':4242, 'holder_started_at':now.isoformat(),
            'heartbeat_at':now.isoformat(), 'lease_seconds':60,
            'lease_expires_at':(now+timedelta(seconds=60)).isoformat(), 'released_at':None,
            'mechanism':'windows_byte_range_lock', 'lock_file':'output/runtime/gestor-central/manager.lock',
            'technical_cost_brl':0}
        runtime = self.pause.parent
        (runtime/'manager.pid').write_text('4242', encoding='utf-8')
        (runtime/'manager-lock.json').write_text(json.dumps(lock), encoding='utf-8')
        inspection = protocol.inspect_quiescence(self.root, manager_pid=4242, guard_seconds=1, now=now)
        self.assertNotIn('INCOMPLETE_OPERATIONAL_EFFECT_JOURNAL', inspection['blockers'])
        self.assertEqual(self.receipt.read_bytes(), self.original)
        with PublicationLock(self.root):
            with self.assertRaisesRegex(PermissionError, 'CANCEL_OPEN_OR_UNKNOWN_EFFECT'):
                protocol._paused_cancel_boundary(self.root, database_root=self.root, contain_private_thumbnail=True)


class AudioStaticPublicationExecutorTests(unittest.TestCase):
    def setUp(self):
        self.owner = current.AudioStaticReleaseGateTests('test_real_public_reader_blocks_unmeasured_quality_and_capability')
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        self.root, self.package, self.relative = self.owner.root, self.owner.package, self.owner.relative
        shutil.copy2(ROOT/'schemas/youtube_publication_receipt.schema.json',self.root/'schemas')
        self.release = materialize(self.root,package_relative=self.relative,current_bindings=self.owner.bindings)
        self.anchor = current.fixture.fixture.voice_fixture.sha(self.release)
        self.provider = Mock()
        self.media = Mock()

    def execute(self, **kwargs):
        args = dict(package_relative=self.relative,current_bindings=self.owner.bindings,
                    expected_release_hash=self.anchor)
        args.update(kwargs)
        return publisher.execute_publication_pipeline(self.provider,self.media,self.root,**args)

    def test_real_blocked_reader_stops_every_provider_effect(self):
        with self.assertRaisesRegex(PermissionError,'not READY'):
            self.execute()
        self.assertEqual(self.provider.mock_calls,[])
        self.assertEqual(self.media.mock_calls,[])
        self.assertFalse((self.package/'youtube-publication-receipt.json').exists())

    def test_mutated_release_is_not_authority_even_with_new_fixture_anchor(self):
        value=json.loads(self.release.read_bytes());value['publication_pipeline_permitted']=True
        self.release.write_text(json.dumps(value),encoding='utf-8')
        with self.assertRaisesRegex(PermissionError,'native inputs'):
            self.execute(expected_release_hash=current.fixture.fixture.voice_fixture.sha(self.release))
        self.assertEqual(self.provider.mock_calls,[])

    def test_pause_blocks_before_lock_or_provider(self):
        pause=self.root/'output/runtime/gestor-central/PAUSE'
        pause.parent.mkdir(parents=True);pause.write_bytes(b'preserve owner pause')
        with self.assertRaisesRegex(PermissionError,'paused'):
            self.execute()
        self.assertEqual(pause.read_bytes(),b'preserve owner pause')
        self.assertFalse((self.root/'output/production/phase6/video-002/publication/publication-transaction.lock').exists())
        self.assertEqual(self.provider.mock_calls,[])

    def test_foreign_package_and_implicit_current_binding_are_refused(self):
        for relative in (Path('../foreign'),self.package):
            with self.subTest(relative=relative),self.assertRaises(PermissionError):
                self.execute(package_relative=relative)
        with self.assertRaises(PermissionError):self.execute(package_relative=None)
        self.assertEqual(self.provider.mock_calls,[])

    def test_concurrent_current_publication_refused_before_provider(self):
        with PublicationLock(self.root),self.assertRaises(PublicationAlreadyRunning):
            self.execute()
        self.assertEqual(self.provider.mock_calls,[])

    def test_cli_valid_binding_runs_native_reader_before_live_service(self):
        binding=self.root/'bindings.json';binding.write_text(json.dumps(self.owner.bindings),encoding='utf-8')
        with patch.object(publisher,'_build_live_service',side_effect=AssertionError('no live provider')) as service:
            with self.assertRaisesRegex(PermissionError,'not READY'):
                publisher.main(['--execute','--root',str(self.root),'--package-relative',str(self.relative),
                    '--current-bindings',str(binding),'--expected-bindings-hash',current.fixture.fixture.voice_fixture.sha(binding),
                    '--expected-release-hash',self.anchor])
        service.assert_not_called()

    def test_cli_bad_binding_anchor_has_no_credential_or_provider_access(self):
        binding=self.root/'bindings.json';binding.write_text(json.dumps(self.owner.bindings),encoding='utf-8')
        with patch.object(publisher,'_build_live_service') as service,self.assertRaisesRegex(PermissionError,'anchor'):
            publisher.main(['--execute','--root',str(self.root),'--package-relative',str(self.relative),
                '--current-bindings',str(binding),'--expected-bindings-hash','sha256:'+'0'*64,
                '--expected-release-hash',self.anchor])
        service.assert_not_called()


class PublicationCheckpointTests(unittest.TestCase):
    def _observation_fixture(self):
        import io
        from PIL import Image
        self._interrupted_thumbnail()
        row = json.loads(self.receipt.read_bytes()); row['updated_at'] = '2000-01-01T00:00:00Z'
        self.receipt.write_text(json.dumps(row), encoding='utf-8')
        image = Image.new('RGB', (128, 72), 'navy'); buffer = io.BytesIO(); image.save(buffer, format='PNG')
        self.image_bytes = buffer.getvalue()
        Path(self.release['artifacts']['thumbnail']['path']).write_bytes(self.image_bytes)
        self.original_observation = self.receipt.read_bytes()
        self.receipt_anchor = 'sha256:' + publisher._hash(self.receipt)
        observation = self.observation('private')
        observation['items'][0]['snippet']['thumbnails'] = {'high': {'url':'https://i.ytimg.com/owned.jpg'}}
        self.provider.videos.return_value.list.return_value.execute.side_effect = None
        self.provider.videos.return_value.list.return_value.execute.return_value = observation
        self.provider.reset_mock()

    def _reconcile_observation(self, fetch=None, anchor=None, observed_public=False):
        with patch.object(publisher, '_validate_current_release', return_value=self.release), \
                patch('hero_engine.phase6_publication._fetch_public_thumbnail',
                      side_effect=fetch, return_value=self.image_bytes):
            return publisher.reconcile_private_thumbnail(self.provider, self.root,
                package_relative=publisher.V3, current_bindings={'fixture':'admission simulated'},
                expected_release_hash='sha256:'+'0'*64,
                expected_receipt_hash=anchor or self.receipt_anchor,
                observed_public=observed_public)

    def _observed_public_checkpoint(self):
        self._observation_fixture()
        self.provider.videos.return_value.list.return_value.execute.return_value['items'][0]['status']['privacyStatus']='public'
        return self._reconcile_observation(observed_public=True)

    def test_public_observation_is_explicit_and_never_claims_promotion(self):
        self._observation_fixture()
        self.provider.videos.return_value.list.return_value.execute.return_value['items'][0]['status']['privacyStatus']='public'
        with self.assertRaisesRegex(PermissionError, 'exact processed private'):
            self._reconcile_observation()
        self.assertEqual(self.receipt.read_bytes(),self.original_observation)
        result=self._reconcile_observation(observed_public=True)
        self.assertEqual(result['status'],'PUBLIC_AWAITING_VERIFICATION')
        self.assertEqual(result['privacy_status'],'public')
        self.assertNotIn('PROMOTE_PUBLIC',{s['step'] for s in result['steps']})
        self.assertIsNone(result['caption_id'])
        self.assertTrue(publisher._verified_observed_public(self.package,result,self.release))
        self.provider.thumbnails.assert_not_called();self.provider.captions.assert_not_called()
        self.provider.videos.return_value.insert.assert_not_called();self.provider.videos.return_value.update.assert_not_called()

    def test_observed_public_resume_finishes_only_remaining_captions(self):
        self._observed_public_checkpoint();self.provider.reset_mock()
        result=self._execute_current_checkpoint()
        self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        self.assertEqual(result['caption_id'],'caption-owned')
        steps={s['step'] for s in result['steps'] if s['status']=='PASS'}
        self.assertIn('PUBLIC_VISIBILITY_OBSERVED',steps)
        self.assertIn('POST_UPLOAD_IDENTITY_VERIFY',steps)
        self.assertNotIn('PRIVATE_POST_UPLOAD_VERIFY',steps);self.assertNotIn('PROMOTE_PUBLIC',steps)
        self.provider.captions.return_value.insert.assert_called_once()
        self.provider.thumbnails.assert_not_called();self.provider.videos.return_value.insert.assert_not_called()
        self.provider.videos.return_value.update.assert_not_called()

    def test_observed_public_archive_tamper_blocks_before_provider(self):
        self._observed_public_checkpoint()
        archive=self.package/'publication-reconciliation'/self.receipt_anchor.removeprefix('sha256:')
        for name in ('observation.json','receipt-before.json','remote-thumbnail.bin'):
            with self.subTest(name=name):
                path=archive/name;original=path.read_bytes();before=self.receipt.read_bytes()
                path.write_bytes(original+b' ');self.provider.reset_mock()
                with self.assertRaisesRegex(PermissionError,'Observed public evidence'):
                    self._execute_current_checkpoint()
                self.assertEqual(self.provider.mock_calls,[]);self.assertEqual(self.receipt.read_bytes(),before)
                path.write_bytes(original)

    def test_observed_public_changed_live_state_has_no_caption_mutation(self):
        self._observed_public_checkpoint();self.provider.reset_mock()
        self.provider.videos.return_value.list.return_value.execute.return_value=self.observation('private')
        with self.assertRaisesRegex(RuntimeError,'live identity changed'):
            self._execute_current_checkpoint()
        self.provider.captions.assert_not_called();self.provider.thumbnails.assert_not_called()
        self.provider.videos.return_value.insert.assert_not_called();self.provider.videos.return_value.update.assert_not_called()
        self.assertNotIn('CAPTIONS_INSERT_BEFORE',{s['step'] for s in json.loads(self.receipt.read_bytes())['steps']})

    def test_observed_public_terminal_is_reused_but_archive_remains_required(self):
        self._observed_public_checkpoint();result=self._execute_current_checkpoint();self.provider.reset_mock()
        self.assertEqual(self._execute_current_checkpoint(),result)
        self.assertEqual(self.provider.mock_calls,[])
        archive=self.package/'publication-reconciliation'/self.receipt_anchor.removeprefix('sha256:')
        (archive/'observation.json').write_bytes(b'{}')
        with self.assertRaisesRegex(PermissionError,'Observed public evidence'):
            self._execute_current_checkpoint()
        self.assertEqual(self.provider.mock_calls,[])

    def test_public_observation_rejects_wrong_identity_processing_and_implicit_use(self):
        self._observation_fixture()
        for privacy,identity,processing in (('private','video-owned','processed'),('public','foreign','processed'),('public','video-owned','uploaded')):
            with self.subTest(privacy=privacy,identity=identity,processing=processing):
                row=self.observation(privacy,identity);row['items'][0]['status']['uploadStatus']=processing
                self.provider.videos.return_value.list.return_value.execute.return_value=row
                with self.assertRaisesRegex(PermissionError,'exact processed public'):
                    self._reconcile_observation(observed_public=True)
                self.assertEqual(self.receipt.read_bytes(),self.original_observation)
        self.provider.videos.return_value.list.return_value.execute.return_value=self.observation('public')
        self.provider.videos.return_value.list.return_value.execute.return_value['items'][0]['snippet']['thumbnails']={'high':{'url':'https://i.ytimg.com/owned.jpg'}}
        self._reconcile_observation(observed_public=True);self.provider.reset_mock()
        with self.assertRaisesRegex(PermissionError,'explicit current bindings'):
            self.execute()
        self.assertEqual(self.provider.mock_calls,[])
        with patch.object(publisher,'_build_live_service') as service,self.assertRaisesRegex(PermissionError,'only qualifies'):
            publisher.main(['--execute','--observe-public'])
        service.assert_not_called()

    def test_expired_observation_confirms_without_provider_mutation_and_preserves_original(self):
        self._observation_fixture()
        result = self._reconcile_observation()
        self.assertEqual(result['status'], 'PARTIAL_PRIVATE_VIDEO')
        self.assertEqual(result['privacy_status'], 'private')
        self.assertEqual(result['steps'][:-1], json.loads(self.original_observation)['steps'])
        self.assertEqual(result['steps'][-1]['step'], 'THUMBNAIL_SET')
        archive = self.package/'publication-reconciliation'/self.receipt_anchor.removeprefix('sha256:')
        self.assertEqual((archive/'receipt-before.json').read_bytes(), self.original_observation)
        self.assertEqual((archive/'remote-thumbnail.bin').read_bytes(), self.image_bytes)
        self.assertEqual(json.loads((archive/'observation.json').read_bytes())['provider_mutations'], 0)
        self.provider.thumbnails.assert_not_called(); self.provider.captions.assert_not_called()
        self.provider.videos.return_value.insert.assert_not_called()
        self.provider.videos.return_value.update.assert_not_called()

    def test_observation_owner_private_cdn_confirms_only_read_result(self):
        self._observation_fixture()
        row = self.provider.videos.return_value.list.return_value.execute.return_value
        row['items'][0]['snippet']['thumbnails'] = {
            'high': {'url': 'https://i9.ytimg.com/vi/video-owned/hqdefault.jpg'}}
        result = self._reconcile_observation()
        self.assertEqual(result['steps'][-1]['step'], 'THUMBNAIL_SET')
        self.assertEqual(result['steps'][-1]['status'], 'PASS')
        self.assertEqual(result['status'], 'PARTIAL_PRIVATE_VIDEO')
        self.assertEqual(result['privacy_status'], 'private')
        self.provider.thumbnails.assert_not_called()
        self.provider.captions.assert_not_called()
        self.provider.videos.return_value.insert.assert_not_called()
        self.provider.videos.return_value.update.assert_not_called()

    def test_observation_private_cdn_lookalikes_missing_and_http_stay_closed(self):
        self._observation_fixture()
        row = self.provider.videos.return_value.list.return_value.execute.return_value
        before = self.receipt.read_bytes()
        for url in (None, 'http://i9.ytimg.com/owned.jpg',
                    'https://i9.ytimg.com.evil.invalid/owned.jpg',
                    'https://evil.invalid/i9.ytimg.com/owned.jpg'):
            with self.subTest(url=url):
                row['items'][0]['snippet']['thumbnails'] = (
                    {'high': {'url': url}} if url is not None else {})
                with self.assertRaisesRegex(PermissionError, 'trusted provider image URL'):
                    self._reconcile_observation(fetch=AssertionError('Untrusted image must not be fetched'))
                self.assertEqual(self.receipt.read_bytes(), before)
        self.provider.thumbnails.assert_not_called()
        self.provider.captions.assert_not_called()
        self.provider.videos.return_value.insert.assert_not_called()
        self.provider.videos.return_value.update.assert_not_called()

    def test_observation_bad_anchor_has_zero_provider_calls(self):
        self._observation_fixture()
        with self.assertRaisesRegex(PermissionError, 'external anchor'):
            self._reconcile_observation(anchor='sha256:'+'0'*64)
        self.assertEqual(self.provider.mock_calls, [])
        self.assertEqual(self.receipt.read_bytes(), self.original_observation)

    def test_observation_other_pending_effect_and_repeated_observation_are_closed(self):
        self._observation_fixture()
        base = self.original_observation
        for step in ('CAPTIONS_INSERT_BEFORE', 'PROMOTE_PUBLIC_BEFORE', 'THUMBNAIL_RECOVERY_BEFORE'):
            with self.subTest(step=step):
                row = json.loads(base); row['steps'].append({'step':step,'status':'NOT_RUN','evidence':'uncertain'})
                self.receipt.write_text(json.dumps(row),encoding='utf-8')
                self.receipt_anchor = 'sha256:' + publisher._hash(self.receipt)
                with self.assertRaisesRegex(PermissionError,'No exact unresolved'):
                    self._reconcile_observation()
                self.assertEqual(self.provider.mock_calls,[])
        self.receipt.write_bytes(base); self.receipt_anchor = 'sha256:' + publisher._hash(self.receipt)
        self._reconcile_observation(); self.provider.reset_mock()
        self.receipt_anchor = 'sha256:' + publisher._hash(self.receipt)
        with self.assertRaisesRegex(PermissionError,'No exact unresolved'):
            self._reconcile_observation()
        self.assertEqual(self.provider.mock_calls,[])

    def test_observation_atomic_failure_preserves_pending_receipt_and_evidence(self):
        self._observation_fixture()
        with patch.object(publisher,'atomic_write_utf8',side_effect=PermissionError('controlled atomic failure')):
            with self.assertRaisesRegex(PermissionError,'controlled atomic failure'):
                self._reconcile_observation()
        self.assertEqual(self.receipt.read_bytes(),self.original_observation)
        archive=self.package/'publication-reconciliation'/self.receipt_anchor.removeprefix('sha256:')
        self.assertEqual((archive/'receipt-before.json').read_bytes(),self.original_observation)
        self.assertTrue((archive/'observation.json').is_file())

    def test_observation_cli_cannot_combine_with_publication_or_omit_anchor(self):
        with patch.object(publisher,'_build_live_service') as service:
            for args in (['--execute','--reconcile-thumbnail'], ['--reconcile-thumbnail']):
                with self.subTest(args=args),self.assertRaises(PermissionError):
                    publisher.main(args)
            service.assert_not_called()

    def test_observation_foreign_or_public_video_preserves_pending_receipt(self):
        self._observation_fixture()
        for privacy, identity in (('public','video-owned'), ('private','foreign')):
            with self.subTest(privacy=privacy, identity=identity):
                self.provider.videos.return_value.list.return_value.execute.return_value = self.observation(privacy,identity)
                with self.assertRaisesRegex(PermissionError, 'exact processed private'):
                    self._reconcile_observation()
                self.assertEqual(self.receipt.read_bytes(), self.original_observation)
                self.provider.thumbnails.assert_not_called()

    def test_observation_mismatched_image_never_closes_effect(self):
        import io
        from PIL import Image
        self._observation_fixture()
        buffer=io.BytesIO(); Image.new('RGB',(128,72),'white').save(buffer,format='PNG')
        with self.assertRaisesRegex(PermissionError, 'does not match'):
            self._reconcile_observation(fetch=lambda _: buffer.getvalue())
        self.assertEqual(self.receipt.read_bytes(), self.original_observation)

    def test_observation_receipt_race_and_history_collision_fail_closed(self):
        self._observation_fixture()
        def racing_fetch(_):
            self.receipt.write_bytes(self.original_observation + b' ')
            return self.image_bytes
        with self.assertRaisesRegex(PermissionError, 'changed before reconciliation'):
            self._reconcile_observation(fetch=racing_fetch)
        self.receipt.write_bytes(self.original_observation)
        archive = self.package/'publication-reconciliation'/self.receipt_anchor.removeprefix('sha256:')
        archive.mkdir(parents=True); (archive/'receipt-before.json').write_bytes(b'foreign historical bytes')
        with self.assertRaisesRegex(PermissionError,'archive collision'):
            self._reconcile_observation()
        self.assertEqual(self.receipt.read_bytes(), self.original_observation)

    def _interrupted_thumbnail(self):
        self.provider.thumbnails.return_value.set.return_value.execute.side_effect = ConnectionAbortedError(10053, 'controlled transport loss')
        with self.assertRaisesRegex(RuntimeError, '10053'):
            self.execute()
        self.provider.reset_mock()
        self.provider.thumbnails.return_value.set.return_value.execute.side_effect = None
        self.provider.thumbnails.return_value.set.return_value.execute.return_value = {'items':[{'high':{'url':'https://i.ytimg.com/confirmed.jpg'}}]}
        self.provider.videos.return_value.list.return_value.execute.side_effect = [self.observation('private'),self.observation('private'),self.observation('public')]

    def _execute_current_checkpoint(self):
        # Isolate effect persistence; the native current admission is exercised
        # independently by AudioStaticPublicationExecutorTests above.
        with patch.object(publisher, '_validate_current_release', return_value=self.release):
            return publisher.execute_publication_pipeline(self.provider,self.media,self.root,
                package_relative=publisher.V3,current_bindings={'test_boundary':'isolated transaction'},
                expected_release_hash='sha256:'+'0'*64)

    def test_current_thumbnail_transport_recovery_preserves_upload_and_history(self):
        self._interrupted_thumbnail()
        original=json.loads(self.receipt.read_bytes())['steps']
        result=self._execute_current_checkpoint()
        self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        self.assertEqual(result['video_id'],'video-owned')
        self.assertEqual(result['steps'][:len(original)],original)
        self.provider.videos.return_value.insert.assert_not_called()
        self.provider.thumbnails.return_value.set.assert_called_once()
        self.provider.thumbnails.return_value.set.assert_called_with(videoId='video-owned',media_body=self.media.return_value)
        self.media.assert_any_call(self.release['artifacts']['thumbnail']['path'],mimetype='image/png',resumable=False)
        before=self.receipt.read_bytes();self.provider.reset_mock()
        self.assertEqual(self._execute_current_checkpoint(),result)
        self.assertEqual(self.provider.mock_calls,[])
        self.assertEqual(self.receipt.read_bytes(),before)

    def test_current_thumbnail_recovery_second_loss_blocks_all_dispatch(self):
        self._interrupted_thumbnail()
        self.provider.thumbnails.return_value.set.return_value.execute.side_effect=ConnectionAbortedError(10053,'second controlled loss')
        with self.assertRaisesRegex(RuntimeError,'10053'):self._execute_current_checkpoint()
        before=self.receipt.read_bytes();self.provider.reset_mock()
        with self.assertRaisesRegex(PermissionError,'Unresolved publication effect'):self._execute_current_checkpoint()
        self.assertEqual(self.provider.mock_calls,[]);self.assertEqual(self.receipt.read_bytes(),before)

    def test_current_thumbnail_recovery_empty_response_never_approves(self):
        self._interrupted_thumbnail()
        self.provider.thumbnails.return_value.set.return_value.execute.return_value={}
        with self.assertRaisesRegex(RuntimeError,'no confirmed thumbnail'):self._execute_current_checkpoint()
        self.assertNotEqual(json.loads(self.receipt.read_bytes())['status'],'COMPLETE_PUBLIC')
        self.provider.reset_mock()
        with self.assertRaises(PermissionError):self._execute_current_checkpoint()
        self.assertEqual(self.provider.mock_calls,[])

    def test_current_thumbnail_recovery_foreign_or_public_video_has_no_mutation(self):
        for privacy,identity in (('public','video-owned'),('private','foreign')):
            with self.subTest(privacy=privacy,identity=identity):
                if not self.receipt.exists():self._interrupted_thumbnail()
                raw=self.receipt.read_bytes()
                self.provider.videos.return_value.list.return_value.execute.side_effect=[self.observation(privacy,identity)]
                self.provider.thumbnails.return_value.set.reset_mock()
                with self.assertRaisesRegex(RuntimeError,'exact processed private'):self._execute_current_checkpoint()
                self.provider.thumbnails.return_value.set.assert_not_called()
                self.receipt.write_bytes(raw)

    def test_current_thumbnail_recovery_stale_or_unsupported_failure_is_closed(self):
        self._interrupted_thumbnail();base=json.loads(self.receipt.read_bytes())
        for key,value in (('updated_at','2000-01-01T00:00:00Z'),('error','TimeoutError: ambiguous outcome'),('channel_id','foreign')):
            with self.subTest(key=key):
                changed=copy.deepcopy(base);changed[key]=value
                self.receipt.write_text(json.dumps(changed),encoding='utf-8');self.provider.reset_mock()
                with self.assertRaises(ValidationError if key=='channel_id' else PermissionError):self._execute_current_checkpoint()
                self.assertEqual(self.provider.mock_calls,[])

    def test_legacy_thumbnail_checkpoint_is_not_implicitly_recovered(self):
        self._interrupted_thumbnail();before=self.receipt.read_bytes()
        with self.assertRaisesRegex(PermissionError,'Unresolved publication effect'):self.execute()
        self.assertEqual(self.provider.mock_calls,[]);self.assertEqual(self.receipt.read_bytes(),before)

    def setUp(self):
        temporary=tempfile.TemporaryDirectory(dir=RECORD,prefix='checkpoint-')
        self.addCleanup(temporary.cleanup);self.root=Path(temporary.name)
        self.package=self.root/publisher.V3;self.package.mkdir(parents=True)
        (self.root/'schemas').mkdir()
        shutil.copy2(ROOT/'schemas/youtube_publication_receipt.schema.json',self.root/'schemas')
        self.release={'schema_version':'1.1.0','release_id':'release-test','idempotency_key':'a'*64,'selected_thumbnail':'owned-static',
                      'artifacts':{name:{'path':str(self.package/filename),'sha256':str(n)*64}
                         for n,(name,filename) in enumerate((('video','video.mp4'),('thumbnail','thumb.jpg'),('captions','captions.srt')),1)}}
        package={'video':{'path':str(self.package/'video.mp4')},
            'captions':{'path':str(self.package/'captions.srt'),'language':'en-US'},
            'metadata':{'title':'Original bounded reflection','description':'Own voice and visual','tags':['reflection'],
                        'category_id':'27','default_language':'en','default_audio_language':'en','made_for_kids':False},
            'disclosure':{'contains_synthetic_media':True}}
        (self.package/'release_gate.json').write_text(json.dumps(self.release),encoding='utf-8')
        (self.package/'publication_package.json').write_text(json.dumps(package),encoding='utf-8')
        # This fixture exercises transaction persistence, not QA/release approval.
        validation=patch.object(publisher,'_validate_release',return_value=None)
        validation.start();self.addCleanup(validation.stop)
        self.receipt=self.package/'youtube-publication-receipt.json'
        self.provider=Mock();self.media=Mock(return_value=object())
        self.provider.channels.return_value.list.return_value.execute.return_value={'items':[{'id':publisher.CHANNEL_ID}]}
        self.provider.videos.return_value.insert.return_value.next_chunk.return_value=(None,{'id':'video-owned'})
        self.provider.captions.return_value.insert.return_value.execute.return_value={'id':'caption-owned'}
        self.provider.videos.return_value.list.return_value.execute.side_effect=[self.observation('private'),self.observation('public')]

    def observation(self,privacy,video_id='video-owned'):
        return {'items':[{'id':video_id,'snippet':{'channelId':publisher.CHANNEL_ID},
                          'status':{'privacyStatus':privacy,'uploadStatus':'processed'}}]}

    def execute(self):
        return publisher.execute_publication_pipeline(self.provider,self.media,self.root)

    def test_every_effect_has_durable_before_and_upload_id_survives(self):
        def thumbnail(**kwargs):
            persisted=json.loads(self.receipt.read_bytes())
            self.assertEqual(persisted['video_id'],'video-owned')
            self.assertEqual(persisted['steps'][-1]['step'],'THUMBNAIL_SET_BEFORE')
            self.assertEqual(persisted['steps'][-1]['status'],'NOT_RUN')
            return Mock(execute=Mock(return_value={}))
        self.provider.thumbnails.return_value.set.side_effect=thumbnail
        result=self.execute();self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        before=self.receipt.read_bytes();self.provider.reset_mock()
        self.assertEqual(self.execute(),result)
        self.assertEqual(self.provider.mock_calls,[]);self.assertEqual(self.receipt.read_bytes(),before)
        for name in ('VIDEO_PRIVATE_UPLOAD','THUMBNAIL_SET','CAPTIONS_INSERT','PROMOTE_PUBLIC'):
            steps=[row['step'] for row in result['steps']]
            self.assertLess(steps.index(name+'_BEFORE'),steps.index(name))

    def test_uncertain_upload_response_blocks_duplicate_dispatch(self):
        self.provider.videos.return_value.insert.return_value.next_chunk.side_effect=TimeoutError('response lost')
        with self.assertRaisesRegex(RuntimeError,'response lost'):self.execute()
        before=self.receipt.read_bytes();self.provider.reset_mock()
        with self.assertRaisesRegex(PermissionError,'Unresolved publication effect'):self.execute()
        self.assertEqual(self.provider.mock_calls,[]);self.assertEqual(self.receipt.read_bytes(),before)

    def test_public_update_not_repeated_when_final_read_fails(self):
        api=self.provider.videos.return_value
        api.list.return_value.execute.side_effect=[self.observation('private'),TimeoutError('final read failed')]
        with self.assertRaisesRegex(RuntimeError,'final read failed'):self.execute()
        self.assertEqual(json.loads(self.receipt.read_bytes())['status'],'PUBLIC_AWAITING_VERIFICATION')
        api.reset_mock();api.list.return_value.execute.side_effect=[self.observation('public'),self.observation('public')]
        result=self.execute();self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        api.insert.assert_not_called();api.update.assert_not_called()
        self.provider.captions.return_value.insert.assert_called_once()

    def test_foreign_video_id_is_not_accepted_as_final_verification(self):
        self.provider.videos.return_value.list.return_value.execute.side_effect=[self.observation('private'),self.observation('public','foreign')]
        with self.assertRaisesRegex(RuntimeError,'Final public state'):self.execute()
        self.assertNotEqual(json.loads(self.receipt.read_bytes())['status'],'COMPLETE_PUBLIC')

    def test_receipt_artifact_drift_blocks_even_completed_dispatch(self):
        self.execute();value=json.loads(self.receipt.read_bytes());value['artifact_hashes']['video']='0'*64
        self.receipt.write_text(json.dumps(value),encoding='utf-8');self.provider.reset_mock()
        with self.assertRaisesRegex(PermissionError,'exact release'):self.execute()
        self.assertEqual(self.provider.mock_calls,[])

    def test_terminal_label_without_effect_chain_is_not_reused_as_pass(self):
        self.execute();value=json.loads(self.receipt.read_bytes())
        value['steps']=[row for row in value['steps'] if row['step']!='PUBLIC_POST_UPLOAD_VERIFY']
        self.receipt.write_text(json.dumps(value),encoding='utf-8');self.provider.reset_mock()
        with self.assertRaisesRegex(PermissionError,'confirmed effect chain'):self.execute()
        self.assertEqual(self.provider.mock_calls,[])

    def test_explicit_audio_routing_uses_png_and_same_checkpoint_engine(self):
        # Gate-positive boundary simulation is confined to this routing test.
        # Native rejection/tamper cases above exercise the real gate separately.
        with patch.object(publisher,'_validate_current_release',return_value=self.release):
            result=publisher.execute_publication_pipeline(self.provider,self.media,self.root,
                package_relative=publisher.V3,current_bindings={'test_boundary':'gate isolated'},
                expected_release_hash='sha256:'+'0'*64)
        self.assertEqual(result['status'],'COMPLETE_PUBLIC')
        calls=[c for c in self.media.call_args_list if c.kwargs.get('mimetype')=='image/png']
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0].args[0],self.release['artifacts']['thumbnail']['path'])

    def test_persistence_failure_prevents_upload(self):
        with patch.object(publisher,'atomic_write_utf8',side_effect=OSError('checkpoint storage denied')):
            with self.assertRaisesRegex(OSError,'checkpoint storage denied'):self.execute()
        self.provider.videos.return_value.insert.assert_not_called()
        self.provider.thumbnails.return_value.set.assert_not_called()

    def test_new_pause_after_identity_stops_before_audio_upload(self):
        def validation(*args):
            if (self.root/'output/runtime/gestor-central/PAUSE').exists():
                raise PermissionError('Publication paused before effect')
            return self.release
        def observed():
            path=self.root/'output/runtime/gestor-central/PAUSE';path.parent.mkdir(parents=True)
            path.write_bytes(b'owner pause')
            return {'items':[{'id':publisher.CHANNEL_ID}]}
        self.provider.channels.return_value.list.return_value.execute.side_effect=observed
        with patch.object(publisher,'_validate_current_release',side_effect=validation):
            with self.assertRaisesRegex(RuntimeError,'paused before effect'):
                publisher.execute_publication_pipeline(self.provider,self.media,self.root,
                    package_relative=publisher.V3,current_bindings={'test_boundary':'gate isolated'},
                    expected_release_hash='sha256:'+'0'*64)
        self.provider.videos.return_value.insert.assert_not_called()
