"""Frozen raw-input preservation tests; no Stage A build or media effects."""
import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
PATH = ROOT / "output/qa/phase6/diagnostics/av-static-integration-v1/build_bound_caption_timeline.py"
spec = importlib.util.spec_from_file_location("caption_input_binding_tests", PATH)
binding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(binding)


class CaptionBundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        reader = binding.Reader(ROOT)
        cls.base = binding._json(reader.read(binding.BASE, "sha256:" + binding.PINS[binding.BASE]))
        cls.candidate = binding._json(reader.read(binding.INPUT, "sha256:" + binding.PINS[binding.INPUT]))

    def test_exact_frozen_addition_never_builds_or_writes(self):
        with patch("hero_engine.phase6_av_timeline.build", side_effect=AssertionError("no build")), \
             patch("pathlib.Path.write_bytes", side_effect=AssertionError("no write")), \
             patch("subprocess.Popen", side_effect=AssertionError("no native effects")):
            binding.validate_bundle(self.base, self.candidate)

    def test_old_inputs_and_authority_cannot_change_under_new_binding(self):
        for mutate in (
            lambda row: row["arguments"]["pause_decisions"].append({"invented": True}),
            lambda row: row["arguments"]["caption_cues"].append({"invented": True}),
            lambda row: row["arguments"]["source_bindings"].pop("visual_intent"),
            lambda row: row["arguments"]["source_bindings"]["voice_manifest"].update(sha256="sha256:" + "0" * 64),
            lambda row: row["authority"].update(render_authorized=True),
            lambda row: row.update(technical_cost_brl=0.0),
        ):
            candidate = copy.deepcopy(self.candidate)
            mutate(candidate)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                binding.validate_bundle(self.base, candidate)

    def test_plan_copy_repin_and_wrong_bundle_identity_reject(self):
        for mutate in (
            lambda row: row["arguments"]["source_bindings"]["caption_intent"].update(path="copied.json"),
            lambda row: row["arguments"]["source_bindings"]["caption_intent"].update(sha256="sha256:" + "0" * 64),
            lambda row: row.update(arguments_id="phase6-av-arguments-" + "0" * 24),
        ):
            candidate = copy.deepcopy(self.candidate)
            mutate(candidate)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                binding.validate_bundle(self.base, candidate)


if __name__ == "__main__":
    unittest.main()
