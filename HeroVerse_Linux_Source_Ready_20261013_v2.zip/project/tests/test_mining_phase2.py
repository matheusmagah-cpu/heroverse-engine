import copy
import hashlib
import inspect
import json
import unittest
from pathlib import Path
from unittest.mock import PropertyMock, patch

from hero_engine.contracts.analysis import canonical_hash, validate_analysis, validate_benchmark
from jsonschema import Draft202012Validator

from hero_engine.mining.adapters import AdapterError, OcrAdapter, TranscriptAdapter, normalize_ocr_text
from hero_engine.mining.narrative import select_change_points
from hero_engine.mining.pipeline import (
    FIXTURE_IDS,
    OUTPUT_ROOT,
    MinerConfig,
    MiningPipeline,
    _cache_valid,
    fixture_catalog,
    job_key_for,
    merge_ocr_scans,
)


ROOT = Path(__file__).resolve().parents[1]
GOLD = ROOT / "data" / "gold_standard"


class MiningContractUnitTests(unittest.TestCase):
    def test_frozen_preregistration_and_baseline_artifacts_are_immutable(self):
        prereg_path = ROOT / "output/mining/phase2/learning/cycle-001/preregistration.json"
        schema = json.loads((ROOT / "schemas/miner_improvement_cycle.schema.json").read_text(encoding="utf-8"))
        prereg = json.loads(prereg_path.read_text(encoding="utf-8"))
        self.assertEqual(list(Draft202012Validator(schema).iter_errors(prereg)), [])
        expected = {
            "output/mining/phase2/active_run.json": "de663a547903c92c63f8452abc0dbb54d9c3ca09f9bf853e9481c779244a4e23",
            "output/mining/phase2/benchmarks/summary.json": "a936af814876685224746499dd39e8a50931d45136e3e2c92ae37b0d08cf4b74",
            "output/mining/phase2/integrity_manifest.json": "ddfc85ee75b1016ba65109d1cae6315d099663f42259b337223ae9f3ab30b157",
        }
        for artifact, digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT / artifact).read_bytes()).hexdigest(), digest)

    def test_ocr_normalization_is_conservative_and_auditable(self):
        self.assertEqual(normalize_ocr_text("GRACE"), ("GRACE", None))
        self.assertEqual(normalize_ocr_text("WWW.GRACEGRITLOVE.ME"), ("WWW.GRACEGRITLOVE.ME", None))
        self.assertIsNotNone(normalize_ocr_text("字字字")[1])
        self.assertIsNotNone(normalize_ocr_text("A7B")[1])
        self.assertIsNotNone(normalize_ocr_text("x")[1])

    def test_multiframe_ocr_merge_retains_frame_provenance(self):
        base = {
            "provider": "rapidocr", "provider_version": "test", "minimum_confidence": 0.7,
            "rejected_lines": [],
        }
        scans = [
            ("start", {**base, "image": "start.jpg", "lines": [{"raw_text": "GRACE", "text": "GRACE", "confidence": 0.8, "box": [], "relative_position": {}}]}),
            ("mid", {**base, "image": "mid.jpg", "lines": [{"raw_text": "GRACE", "text": "GRACE", "confidence": 0.9, "box": [], "relative_position": {}}]}),
        ]
        merged = merge_ocr_scans(scans)
        self.assertEqual(merged["scan_count"], 2)
        self.assertEqual(merged["lines"][0]["confidence"], 0.9)
        self.assertEqual(
            {item["frame_label"] for item in merged["lines"][0]["frame_provenance"]},
            {"start", "mid"},
        )

    def test_narrative_selector_is_gold_independent_by_construction(self):
        source = inspect.getsource(select_change_points)
        module_source = inspect.getsource(__import__("hero_engine.mining.narrative", fromlist=["*"]))
        self.assertNotIn("gold_standard", module_source)
        self.assertNotIn("GOLD_ROOT", module_source)
        self.assertIn("dynamic", source)

    def test_job_key_is_deterministic_and_parameter_sensitive(self):
        source_hash = fixture_catalog()[FIXTURE_IDS[0]]["content_sha256"]
        first = job_key_for(source_hash, MinerConfig())
        second = job_key_for(source_hash, MinerConfig())
        changed = job_key_for(source_hash, MinerConfig(scene_threshold=0.30))
        self.assertEqual(first, second)
        self.assertNotEqual(first, changed)

    def test_contract_rejects_unresolved_claim_evidence(self):
        document = json.loads((GOLD / FIXTURE_IDS[0] / "video_mining.json").read_text(encoding="utf-8"))
        broken = copy.deepcopy(document)
        broken["packaging"]["title_analysis"]["evidence_refs"] = ["DOES-NOT-EXIST"]
        result = validate_analysis(broken, root=ROOT)
        self.assertFalse(result.passed)
        self.assertTrue(any("claim_evidence_refs_missing" in error for error in result.errors))

    def test_contract_rejects_missing_artifact(self):
        document = json.loads((GOLD / FIXTURE_IDS[0] / "video_mining.json").read_text(encoding="utf-8"))
        broken = copy.deepcopy(document)
        broken["hooks"][0]["evidence"][0]["artifact"] = "output/never-created.xyz"
        result = validate_analysis(broken, root=ROOT)
        self.assertFalse(result.evidence_resolvable)

    def test_unknown_fixture_fails_closed(self):
        with self.assertRaisesRegex(ValueError, "approved fixtures"):
            MiningPipeline(progress=lambda _: None).mine("not-approved")

    def test_ocr_and_asr_provider_failures_propagate_without_fallback(self):
        image = ROOT / "data" / "modeling" / "grace-grit-love" / "full" / f"{FIXTURE_IDS[0]}.jpg"
        with patch.object(OcrAdapter, "engine", new_callable=PropertyMock) as engine:
            engine.side_effect = AdapterError("OCR unavailable")
            with self.assertRaisesRegex(AdapterError, "OCR unavailable"):
                OcrAdapter().scan(image)
        with patch.object(TranscriptAdapter, "model", new_callable=PropertyMock) as model:
            model.side_effect = AdapterError("ASR unavailable")
            with self.assertRaisesRegex(AdapterError, "ASR unavailable"):
                TranscriptAdapter("base.en").transcribe(image, FIXTURE_IDS[0], beam_size=5, vad_filter=True)


class MiningPhase2IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = fixture_catalog()
        cls.jobs = {}
        # Historical evidence is selected by frozen bytes, not today's code hash.
        # This suite must never call the miner to recreate an earlier experiment.
        run_path = OUTPUT_ROOT / "runs/miner-local-0.2.0/active_run.json"
        if hashlib.sha256(run_path.read_bytes()).hexdigest() != "efec49733f37076bb92eb3dc3c4f25de71f58b1641a335f331cacf27ce5d4016":
            raise AssertionError("historical Phase 2 run binding changed")
        run = json.loads(run_path.read_text(encoding="utf-8"))
        manifest_pins = {
            "hkf6nDyUfAM": "69cd9fa6b9a8e3528762358f8743cefeafe9365038e22475da1ca4b33f643d1f",
            "_sOy7htXJi8": "c74f58a23f111f3067c785d11753657b8ad5d677b4315c333e516105eafb546e",
            "Pkede5acSFw": "1c51ae10fd9ad408b119f1499a9be1fda90724e38dbebb7cd057a71bcc06482f",
            "huvUy3pJSp8": "b602139e452f4ed6eed1e4fe7880e984a00ee7f5ed6b94df2002c01cc716a968",
        }
        if len(run["jobs"]) != len(FIXTURE_IDS) or {row["video_id"] for row in run["jobs"]} != set(FIXTURE_IDS):
            raise AssertionError("historical fixture set changed")
        for row in run["jobs"]:
            video_id = row["video_id"]
            job = OUTPUT_ROOT / video_id / row["job_key"]
            manifest_path = job / "run_manifest.json"
            if (row["manifest"] != manifest_path.relative_to(ROOT).as_posix()
                    or hashlib.sha256(manifest_path.read_bytes()).hexdigest() != manifest_pins[video_id]):
                raise AssertionError("historical fixture manifest binding changed")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            expected_key = canonical_hash({key: manifest[key] for key in (
                "source_hash", "pipeline_version", "implementation_hash", "parameters",
            )})
            if (manifest["job_key"] != expected_key or row["job_key"] != expected_key
                    or manifest["source_hash"] != cls.catalog[video_id]["content_sha256"]
                    or manifest["parameters"] != MinerConfig().normalized()
                    or manifest["semantic_hash"] != row["semantic_hash"]):
                raise AssertionError("historical fixture source/config/semantic identity changed")
            cls.jobs[video_id] = job

    def test_every_fixture_is_complete_and_contract_valid(self):
        for video_id, job in self.jobs.items():
            with self.subTest(video_id=video_id):
                manifest = json.loads((job / "run_manifest.json").read_text(encoding="utf-8"))
                analysis = json.loads((job / "video_mining.json").read_text(encoding="utf-8"))
                self.assertEqual(manifest["status"], "COMPLETE")
                self.assertTrue(validate_analysis(analysis, root=ROOT).passed)
                self.assertTrue(analysis["quality"]["schema_valid"])
                self.assertTrue(analysis["quality"]["evidence_resolvable"])

    def test_hooks_are_exact_and_every_take_has_three_real_keyframes(self):
        expected = [("0_1S", 0, 1000), ("1_3S", 1000, 3000), ("3_8S", 3000, 8000), ("8_30S", 8000, 30000)]
        for video_id, job in self.jobs.items():
            analysis = json.loads((job / "video_mining.json").read_text(encoding="utf-8"))
            observed = [(item["window"], item["start_ms"], item["end_ms"]) for item in analysis["hooks"]]
            self.assertEqual(observed, expected)
            for take in analysis["takes"]:
                self.assertEqual(len(take["keyframes"]), 3)
                self.assertTrue(all((ROOT / artifact).is_file() for artifact in take["keyframes"]))

    def test_automatic_semantics_are_unreviewed_and_rights_remain_blocked(self):
        for video_id, job in self.jobs.items():
            analysis = json.loads((job / "video_mining.json").read_text(encoding="utf-8"))
            self.assertIsNone(analysis["transcript"]["reviewed_artifact"])
            self.assertEqual(analysis["quality"]["manual_review_status"], "NOT_REVIEWED")
            self.assertEqual(analysis["rights"]["status"], "EDITORIAL_REVIEW_REQUIRED")
            self.assertFalse(analysis["rights"]["production_eligible"])
            self.assertFalse(analysis["public_performance"]["private_metrics_claimed"])

    def test_resources_prove_local_zero_external_api_cost(self):
        for video_id, job in self.jobs.items():
            resource = json.loads((job / "resource_usage.json").read_text(encoding="utf-8"))
            self.assertEqual(resource["external_api_cost_usd"], 0.0)
            self.assertGreater(resource["wall_seconds"], 0)
            self.assertGreater(resource["take_count"], 0)
            self.assertEqual(resource["keyframe_count"], resource["take_count"] * 3)
            self.assertGreater(resource["ocr_image_count"], resource["take_count"] + 1)

    def test_cache_replay_is_a_semantically_identical_hit(self):
        for video_id, job in self.jobs.items():
            before = (job / "run_manifest.json").read_bytes()
            self.assertTrue(_cache_valid(job, source_hash=self.catalog[video_id]["content_sha256"]))
            manifest = json.loads(before)
            analysis = json.loads((job / "video_mining.json").read_text(encoding="utf-8"))
            self.assertEqual(canonical_hash(analysis), manifest["semantic_hash"])
            self.assertEqual((job / "run_manifest.json").read_bytes(), before)

    def test_benchmarks_are_schema_valid_and_never_auto_promote(self):
        for video_id in FIXTURE_IDS:
            path = OUTPUT_ROOT / "benchmarks" / "miner-local-0.2.0" / f"{video_id}.json"
            benchmark = json.loads(path.read_text(encoding="utf-8"))
            self.assertTrue(validate_benchmark(benchmark).passed)
            self.assertEqual(benchmark["review_status"], "AWAITING_REVIEW")
            self.assertNotEqual(benchmark["decision"], "PROMOTE_CHALLENGER")
        summary = json.loads((OUTPUT_ROOT / "benchmarks" / "miner-local-0.2.0" / "summary.json").read_text(encoding="utf-8"))
        self.assertFalse(summary["automatic_promotion_permitted"])
        self.assertEqual(summary["status"], "AWAITING_REVIEW")
        self.assertIn("baseline_comparison", summary)

    def test_narrative_segments_are_contiguous_and_use_change_point_evidence(self):
        for video_id, job in self.jobs.items():
            analysis = json.loads((job / "video_mining.json").read_text(encoding="utf-8"))
            segments = analysis["narrative_segments"]
            self.assertEqual(segments[0]["start_ms"], 0)
            self.assertEqual(segments[-1]["end_ms"], analysis["source"]["duration_ms"])
            self.assertTrue(all(left["end_ms"] == right["start_ms"] for left, right in zip(segments, segments[1:])))
            self.assertTrue(all(segment["take_refs"] for segment in segments))
            self.assertIn("gold-independent", segments[0]["objective"])

    def test_integrity_manifest_matches_active_challenger_artifacts(self):
        from tests.shared_source_evolution import load_retention_evolution

        path = OUTPUT_ROOT / "integrity" / "miner-local-0.2.0.json"
        manifest = json.loads(path.read_text(encoding="utf-8"))
        evolution_paths = [
            ROOT / "output/modeling/phase4/channel-model-v1/shared_source_evolution_receipt.json",
            ROOT / "output/production/phase5/pilot-001/shared_source_evolution_receipt.json",
            ROOT / "output/operations/phase6/shared_source_evolution_receipt.json",
        ]
        evolutions = [json.loads(item.read_text(encoding="utf-8")) for item in evolution_paths]
        evolutions.append(load_retention_evolution(ROOT))
        self.assertEqual(manifest["algorithm"], "SHA-256")
        self.assertGreater(manifest["item_count"], 1000)
        for item in manifest["entries"]:
            artifact = ROOT / item["artifact"]
            self.assertTrue(artifact.is_file(), item["artifact"])
            actual = hashlib.sha256(artifact.read_bytes()).hexdigest()
            if actual == item["sha256"]:
                continue
            matching = []
            for evolution in evolutions:
                self.assertEqual(evolution["status"], "AUTHORIZED_SHARED_SOURCE_EVOLUTION")
                phase_hash_field = f"phase{evolution['phase']}_sha256"
                matching.extend(
                    entry for entry in evolution["exceptions"]
                    if entry["artifact"] == item["artifact"]
                    and entry["historical_phase2_sha256"] == item["sha256"]
                    and entry.get(phase_hash_field) == actual
                )
            self.assertEqual(len(matching), 1, f"unregistered Phase 2 integrity drift: {item['artifact']}")


if __name__ == "__main__":
    unittest.main()
