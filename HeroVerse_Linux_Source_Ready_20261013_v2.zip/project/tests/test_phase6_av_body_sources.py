"""Closed body-source seams: real pinned metadata, explicitly synthetic replays.

No fixture below claims that it measured pixels. Production replay is replaced
only at its pinned-module boundary for orchestration tests; no PNG/OCR/render
is repeated. One real metadata preflight exercises the complete read-only chain.
"""
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from hero_engine import phase6_av_body_sources as body
from tests.static_input_isolation import archived_historical_production_inputs

ROOT = Path(__file__).absolute().parents[1]
P = body.primitives
REPLAY_AUTHORITY = dict.fromkeys(("timing", "source_admitted", "rights", "publicity", "quality_final_video", "render", "queue", "publication"), False)


def request(template=body.THREE, state=None):
    config = body.CONFIGS[template]
    return {"template_id": template, "state_id": state or config["state_ids"][0],
        "receipt_binding": {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]}}


def all_requests():
    return [request(template, sid) for template, config in body.CONFIGS.items() for sid in config["state_ids"]]


def identify(proof, template):
    proof.pop("inspection_id", None)
    proof["inspection_id"] = body.REPLAYS[template]["inspection_prefix"] + P._sha(P._canonical(proof))[:24]


class BodySourcesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._historical_inputs = archived_historical_production_inputs(P)
        cls._historical_inputs.__enter__()
        reader = P._Reader(ROOT)
        cls.projection = body._read_document(reader, body.PROJECTION)
        cls.bible = body._read_document(reader, body.DOCUMENTS["style_bible"])
        cls.plan = body._read_document(reader, body.DOCUMENTS["take_plan"])
        cls.takes = {take["take_id"]: take for take in cls.plan["takes"]}
        cls.states = {state["state_id"]: (row, state) for row in cls.projection["effective_rows"] for state in row["states"]}
        cls.receipts = {template: body._read_document(reader, request(template)["receipt_binding"]) for template in body.CONFIGS}
        cls.originals = {item["state_id"]: item for receipt in cls.receipts.values() for item in receipt["contract"]["design"]["states"]}

    @classmethod
    def tearDownClass(cls):
        cls._historical_inputs.__exit__(None, None, None)

    def contract_args(self, template, sid):
        return copy.deepcopy((template, *self.states[sid], self.originals[sid], self.takes))

    def fixture(self, requests=None):
        """Explicit synthetic batch envelopes; no scanner/image reader is used."""
        requests = all_requests() if requests is None else requests
        templates = body._requests(ROOT, requests)
        # Common facade guards are synthetic here and identical for every
        # request shape. Metadata belonging to the other template must not leak
        # into a state's proof or change its identity.
        reader = SimpleNamespace(root=ROOT, bindings={str(ROOT / path):
            {"path": str(ROOT / path), "sha256": "a" * 64, "size_bytes": 1} for path in (body.IMPLEMENTATION, body.TEST)})
        for template in templates:
            path = str(ROOT / template / "EXPLICIT_SYNTHETIC_METADATA_NOT_EVIDENCE.json")
            reader.bindings[path] = {"path": path, "sha256": "b" * 64, "size_bytes": 1}
        context = body._Context(reader, requests, templates)
        context.bible = copy.deepcopy(self.bible)
        batches = {}
        for template in templates:
            config, fixed = body.CONFIGS[template], body.REPLAYS[template]
            contracts = {sid: body._contract(*self.contract_args(template, sid)) for sid in config["state_ids"]}
            context.contracts[template] = contracts
            arguments = {"code_pins": {"EXPLICIT_SYNTHETIC_IMPLEMENTATION_BOUNDARY": "b" * 64},
                "report_binding": copy.deepcopy(fixed["report"]), "source_receipt": request(template)["receipt_binding"],
                "projection_binding": copy.deepcopy(body.PROJECTION)}
            # Raw hashes belong to the pinned metadata; size=1 is deliberately
            # synthetic. Actual-dependency readers are patched in these tests.
            sink = [{"path": str(ROOT / config["directory"] / (sid + ".png")),
                "sha256": self.receipts[template]["artifact_sha256"][sid + ".png"], "size_bytes": 1}
                for sid in config["state_ids"]]
            sources = []
            for asset, sid in zip(sink, config["state_ids"], strict=True):
                contract, original = contracts[sid], self.originals[sid]
                proof = {"version": fixed["version"], "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", "template_id": template,
                    "channel_id": P.CHANNEL, "state_id": sid, "unit_id": contract["unit_id"], "lineage_id": config["lineage_id"],
                    "asset_binding": asset, "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
                    "media_kind": "STATIC_IMAGE", "source_video_fps": None, "source_video_duration": None,
                    "source_technically_verified": True, "source_ready": False, "entry": contract["entry"], "literal_copy": contract["literal_copy"],
                    "source_receipt": copy.deepcopy(arguments["source_receipt"]), "qa_report_binding": copy.deepcopy(fixed["report"]),
                    "projection_binding": copy.deepcopy(body.PROJECTION), "authority": dict(REPLAY_AUTHORITY), "technical_cost_brl": 0,
                    "dependency_bindings": copy.deepcopy(sink)}
                if template == body.THREE:
                    proof["take_id"] = original["take_id"]
                else:
                    proof["take_ids"] = original["take_ids"]
                    proof["composition_id"] = original["composition_id"]
                identify(proof, template)
                sources.append(copy.deepcopy(proof))
            batch = {"version": fixed["version"], "status": "PASS_STATIC_SOURCE_REPLAY_ONLY", "source_technically_verified": True,
                "source_receipt": copy.deepcopy(arguments["source_receipt"]), "qa_report_binding": copy.deepcopy(fixed["report"]),
                "projection_binding": copy.deepcopy(body.PROJECTION), "implementation_pins": arguments["code_pins"],
                "state_ids": config["state_ids"], "source_count": 6, "sources": sources, "lineage_id": config["lineage_id"],
                "new_independent_lineage_claimed": False, "source_frame_interval": [0, 1], "source_video_fps": None,
                "source_video_duration": None, "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
                "png_decodes_this_call": fixed["unique_count"], "ocr_inferences_this_call": 0, "source_renders_this_call": 0,
                "dependency_bindings": sink, "authority": dict(REPLAY_AUTHORITY), "technical_cost_brl": 0}
            batches[template] = batch
            def verify(*, _dependency_sink, _context_sink=None, _template=template, **kwargs):
                result = copy.deepcopy(batches[_template])
                _dependency_sink.extend(copy.deepcopy(result["dependency_bindings"]))
                if _context_sink is not None:
                    _context_sink.append({"EXPLICIT_SYNTHETIC_CONTEXT": _template})
                return result
            module = SimpleNamespace(verify=Mock(side_effect=verify), recheck=Mock(), AUTHORITY=dict(REPLAY_AUTHORITY))
            context.replays[template] = {"module": module, "arguments": arguments,
                "context": {"EXPLICIT_SYNTHETIC_PREFLIGHT": template}, "receipt": copy.deepcopy(self.receipts[template])}
        return context, batches

    def inspect_fixture(self, context, *, candidate=None, context_sink=None, execution_sink=None):
        with patch.object(body, "preflight_body_sources", return_value=context), \
             patch.object(body, "recheck_body_context"), patch.object(body, "recheck_body_dependencies"), \
             patch("PIL.Image.open", side_effect=AssertionError("NO DECODE IN FIXTURE")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO OCR/RENDER")), \
             patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")):
            if candidate is not None:
                return body.verify_body_source(candidate, ROOT, **context.requests[0])
            return body.inspect_body_sources(ROOT, context.requests, _context_sink=context_sink, _execution_sink=execution_sink)

    def test_real_preflight_all_twelve_metadata_only(self):
        with patch("PIL.Image.open", side_effect=AssertionError("NO PNG DECODE")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO OCR/RENDER")), \
             patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")):
            context = body.preflight_body_sources(ROOT, all_requests())
            body.recheck_body_context(context)
        self.assertEqual(context.templates, [body.THREE, body.RECORD])
        self.assertEqual(sum(len(rows) for rows in context.contracts.values()), 12)
        for template, replay in context.replays.items():
            self.assertEqual(replay["context"]["code_pins"], replay["arguments"]["code_pins"])
            self.assertEqual(replay["context"]["report"]["status"], "PASS_STATIC_SCOPE_ONLY")
        self.assertEqual(len(context.replays[body.THREE]["context"]["scans"]), 6)
        self.assertEqual(len(context.replays[body.RECORD]["context"]["scans"]), 5)

    def test_invalid_requests_fail_before_replay_loading(self):
        bad = [None, [], all_requests() + [request()], [request(), request()]]
        for field, value in (("template_id", []), ("template_id", "future-v1"), ("state_id", True), ("state_id", "visual-u001-s00"), ("fps", 30)):
            row = request(); row[field] = value; bad.append([row])
        for field, value in (("path", "../receipt.json"), ("sha256", "0" * 64), ("size_bytes", 1)):
            row = request(); row["receipt_binding"][field] = value; bad.append([row])
        with patch.object(body, "_load_replay", side_effect=AssertionError("NO REPLAY LOAD")):
            for rows in bad:
                with self.subTest(rows=rows), self.assertRaises(ValueError):
                    body.inspect_body_sources(ROOT, rows)

    def test_twelve_sources_one_replay_per_template_and_one_existing_lineage(self):
        context, _ = self.fixture()
        contexts, executions = [], []
        proofs = self.inspect_fixture(context, context_sink=contexts, execution_sink=executions)
        self.assertEqual(len(proofs), 12)
        self.assertEqual(len({row["content_sha256"] for row in proofs}), 11)
        self.assertEqual(len({row["lineage_id"] for row in proofs}), 1)
        for replay in context.replays.values():
            replay["module"].verify.assert_called_once()
        self.assertEqual(contexts, [context])
        self.assertTrue(context.operation_complete)
        self.assertEqual(context.operation_counts, {"template_replay_calls": 2, "image_decode_calls": 11,
            "ocr_inference_calls": 0, "render_calls": 0, "technical_cost_brl": 0})
        self.assertEqual(len(executions), 1)
        execution = executions[0]
        self.assertEqual(execution["templates"], [body.THREE, body.RECORD])
        self.assertEqual([execution[key] for key in ("replay_count", "image_decode_calls", "ocr_inference_calls", "render_calls", "technical_cost_brl")], [2, 11, 0, 0, 0])
        self.assertEqual([item["image_decode_calls"] for item in execution["template_executions"]], [6, 5])
        self.assertEqual(execution["authority"], body.AUTHORITY)
        self.assertEqual({item["path"] for item in context.operation_dependencies}, set(context.reader.bindings) |
            {item["path"] for proof in proofs for item in proof["dependency_bindings"]})
        for proof in proofs:
            self.assertEqual(proof["image_decode_calls"], body.REPLAYS[proof["template_id"]]["unique_count"])
            self.assertEqual(proof["counter_scope"], "ONE_FULL_TEMPLATE_REPLAY_NOT_PER_STATE_OR_MIXED_OPERATION")
            self.assertEqual([proof[key] for key in ("ocr_inference_calls", "render_calls", "technical_cost_brl")], [0, 0, 0])
            self.assertEqual(proof["authority"], body.AUTHORITY)
            self.assertFalse(proof["source_ready"])
            self.assertEqual([proof[key] for key in ("source_frame_count", "source_start_frame", "source_end_frame")], [1, 0, 1])
            self.assertIsNone(proof["observed_sample"])
            self.assertIsNone(proof["video_frame"])
            payload = {key: value for key, value in proof.items() if key != "inspection_id"}
            self.assertEqual(proof["inspection_id"], "body-source-" + P._sha(P._canonical(payload))[:24])
        aliases = [row for row in proofs if row["state_id"] in ("visual-u036-s00", "visual-u037-s00")]
        self.assertEqual(aliases[0]["content_sha256"], aliases[1]["content_sha256"])
        self.assertNotEqual(aliases[0]["inspection_id"], aliases[1]["inspection_id"])
        self.assertNotEqual(aliases[0]["visual_content"]["composition_id"], aliases[1]["visual_content"]["composition_id"])
        self.assertEqual(aliases[0]["equivalent_state_ids"], ["visual-u036-s00", "visual-u037-s00"])

    def test_subset_replays_full_template_once_preserving_request_order(self):
        rows = [request(body.RECORD, "visual-u038-s02"), request(body.RECORD, "visual-u036-s00")]
        context, _ = self.fixture(rows)
        proofs = self.inspect_fixture(context)
        self.assertEqual([row["state_id"] for row in proofs], [row["state_id"] for row in rows])
        context.replays[body.RECORD]["module"].verify.assert_called_once()
        self.assertTrue(all(proof["image_decode_calls"] == 5 for proof in proofs))
        self.assertEqual(context.replays[body.RECORD]["context"], {"EXPLICIT_SYNTHETIC_CONTEXT": body.RECORD})

    def test_mixed_batch_proofs_verify_individually_with_identical_bytes_and_ids(self):
        mixed, _ = self.fixture(list(reversed(all_requests())))
        proofs = self.inspect_fixture(mixed)
        for proof in proofs:
            template, sid = proof["template_id"], proof["state_id"]
            single, _ = self.fixture([request(template, sid)])
            with self.subTest(template=template, sid=sid):
                verified = self.inspect_fixture(single, candidate=proof)
                self.assertEqual(P._canonical(verified), P._canonical(proof))
                self.assertEqual(single.operation_counts["template_replay_calls"], 1)
                self.assertEqual(single.operation_counts["image_decode_calls"], body.REPLAYS[template]["unique_count"])
                single.replays[template]["module"].verify.assert_called_once()
                other_template = body.RECORD if template == body.THREE else body.THREE
                other_directory = ROOT / body.CONFIGS[other_template]["directory"]
                self.assertFalse(any(Path(item["path"]).is_relative_to(other_directory) for item in proof["dependency_bindings"]))
        self.assertEqual(mixed.operation_counts["image_decode_calls"], 11)

    def test_template_subset_and_complete_template_proofs_are_identical(self):
        for template, config in body.CONFIGS.items():
            whole, _ = self.fixture([request(template, sid) for sid in config["state_ids"]])
            complete = {row["state_id"]: row for row in self.inspect_fixture(whole)}
            subset, _ = self.fixture([request(template, sid) for sid in reversed(config["state_ids"][::2])])
            for proof in self.inspect_fixture(subset):
                self.assertEqual(P._canonical(proof), P._canonical(complete[proof["state_id"]]))

    def test_three_lexical_ranges_include_cross_fragment_phrase_without_timestamp(self):
        rows = [body._contract(*self.contract_args(body.RECORD, sid)) for sid in body.CONFIGS[body.RECORD]["state_ids"]]
        lexical = [row for row in rows if row["lexical_target"] is not None]
        self.assertEqual(len(lexical), 3)
        last = lexical[-1]
        self.assertEqual(last["entry"], {"kind": "LEXICAL_START", "char_start": 72, "char_end": 98,
            "text": "stories only exhausted you", "previous_state_id": "visual-u038-s01"})
        self.assertEqual(last["lexical_target"]["fragment_ids"], ["take-059", "take-060"])
        self.assertEqual([span["text"] for span in last["lexical_target"]["fragment_spans"]], ["stories", "only exhausted you"])
        self.assertNotIn("fragment_id", last["lexical_target"])
        self.assertEqual(last["unit_fragment_ids"], ["take-059", "take-060"])
        self.assertTrue(all(row["continuation_of_state_id"] is None for row in rows))

    def test_literal_mutations_and_timing_fields_fail(self):
        for mutation in ("copy", "float_entry", "time", "narration", "fragment", "visual"):
            args = self.contract_args(body.RECORD, "visual-u038-s02")
            _, row, state, original, takes = args
            if mutation == "copy": state["visual_content"]["literal_copy"] = ["The warning was correct"]
            elif mutation == "float_entry": state["entry"]["char_start"] = 72.0
            elif mutation == "time": state["entry"]["observed_sample"] = 100
            elif mutation == "narration": takes["take-060"]["narration"] = "exhausted you."
            elif mutation == "fragment": original["take_ids"] = ["take-060"]
            else: state["visual_content"]["composition_id"] = "unapproved-reframe"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                body._contract(*args)

    def test_replay_false_authority_or_counters_are_not_accepted_as_flags(self):
        for field, value in (("source_ready", True), ("global_schedule_created", True), ("png_decodes_this_call", 6.0),
                ("ocr_inferences_this_call", 1), ("source_video_fps", 30), ("new_independent_lineage_claimed", True)):
            context, batches = self.fixture([request()])
            batches[body.THREE][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.inspect_fixture(context)

    def test_source_identity_copy_pin_or_source_authority_tampering_fails(self):
        for mutation in ("identity", "copy", "path", "asset_sha", "authority", "duration", "entry"):
            context, batches = self.fixture([request()])
            proof = batches[body.THREE]["sources"][0]
            if mutation == "identity": proof["inspection_id"] = "fake-self-approved"
            else:
                if mutation == "copy": proof["literal_copy"] = ["Invented claim"]
                elif mutation == "path": proof["asset_binding"] = {**proof["asset_binding"], "path": "../evil.png"}
                elif mutation == "asset_sha": proof["asset_binding"] = {**proof["asset_binding"], "sha256": "0" * 64}
                elif mutation == "authority": proof["authority"]["publication"] = True
                elif mutation == "duration": proof["source_video_duration"] = 1
                else: proof["entry"]["observed_sample"] = 99
                identify(proof, body.THREE)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.inspect_fixture(context)

    def test_late_dependency_or_second_template_failure_returns_no_partial_proofs(self):
        context, _ = self.fixture()
        context.replays[body.RECORD]["module"].verify.side_effect = ValueError("EXPLICIT SECOND TEMPLATE FAIL")
        with self.assertRaisesRegex(ValueError, "SECOND TEMPLATE"):
            self.inspect_fixture(context)
        context.replays[body.THREE]["module"].verify.assert_called_once()
        context, _ = self.fixture()
        contexts, executions = [], []
        with patch.object(body, "preflight_body_sources", return_value=context), patch.object(body, "recheck_body_context"), \
             patch.object(body, "recheck_body_dependencies", side_effect=ValueError("EXPLICIT FINAL DRIFT")):
            with self.assertRaisesRegex(ValueError, "FINAL DRIFT"):
                body.inspect_body_sources(ROOT, context.requests, _context_sink=contexts, _execution_sink=executions)
        self.assertEqual(contexts, [])
        self.assertEqual(executions, [])
        self.assertFalse(context.operation_complete)

    def test_execution_sink_is_fresh_output_only_never_cache_or_input(self):
        context, _ = self.fixture()
        executions = []
        self.inspect_fixture(context, execution_sink=executions)
        self.assertEqual(len(executions), 1)
        with patch.object(body, "preflight_body_sources", side_effect=AssertionError("NO PREFLIGHT OR REPLAY")):
            for candidate in (executions, [{}], {}, True):
                with self.subTest(candidate=type(candidate)), self.assertRaisesRegex(ValueError, "fresh empty list"):
                    body.inspect_body_sources(ROOT, all_requests(), _execution_sink=candidate)
            alias = []
            with self.assertRaisesRegex(ValueError, "must be distinct"):
                body.inspect_body_sources(ROOT, all_requests(), _context_sink=alias, _execution_sink=alias)

    def test_private_context_rejects_serialized_candidate(self):
        with self.assertRaisesRegex(ValueError, "private same-call"):
            body.recheck_body_context({"source_technically_verified": True})
        with patch.object(body, "preflight_body_sources", side_effect=AssertionError("NO PREFLIGHT")):
            with self.assertRaisesRegex(ValueError, "context sink"):
                body.inspect_body_sources(ROOT, [request()], _context_sink={})
        reader = SimpleNamespace(bindings={}, root=ROOT)
        context = body._Context(reader, [request()], [body.THREE])
        module = SimpleNamespace(recheck=Mock(side_effect=ValueError("EXPLICIT INVENTORY DRIFT")))
        context.replays[body.THREE] = {"module": module, "context": object()}
        with self.assertRaisesRegex(ValueError, "INVENTORY DRIFT"):
            body.recheck_body_context(context)

    def test_dependency_conflict_duplicate_size_and_21mb_allowlist(self):
        item = {"path": str(ROOT / "fixture.json"), "sha256": "a" * 64, "size_bytes": 1}
        for items in ([item, item], [{**item, "size_bytes": True}], [{**item, "extra": 1}]):
            with self.assertRaises(ValueError): body._merge({}, items)
        with self.assertRaises(ValueError): body._merge({item["path"]: item}, [{**item, "sha256": "b" * 64}])
        class Sized:
            def __init__(self, size): self.size = size
            def __len__(self): return self.size
        model, (digest, size) = next((path, data) for path, data in body.MODEL_PINS.items() if data[1] > 16 * 1024**2)
        def read(path, sha, *, limit):
            if size > limit: raise ValueError("EXPLICIT SYNTHETIC OVERSIZE")
            return Sized(size)
        reader = SimpleNamespace(root=ROOT, read_path=Mock(side_effect=read))
        bound = {"path": str(ROOT / model), "sha256": digest, "size_bytes": size}
        body._read_dependency(reader, bound)
        self.assertEqual(reader.read_path.call_args.kwargs["limit"], 32 * 1024**2)
        for change in ({"path": str(ROOT / "unknown-model.onnx")}, {"sha256": "0" * 64},
                {"size_bytes": size + 1}, {"path": str(ROOT.parent / "escape.bin")}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                body._read_dependency(reader, {**bound, **change})

    def test_external_replay_pin_drift_blocks_before_import(self):
        actual = Path.read_bytes
        target = ROOT / body.BASE / body.THREE / "verify_sources.py"
        def drift(path):
            raw = actual(path)
            return raw[:-1] + bytes([raw[-1] ^ 1]) if path == target else raw
        with patch.object(Path, "read_bytes", drift), patch.object(body.importlib.util, "spec_from_file_location", side_effect=AssertionError("NO UNPINNED IMPORT")):
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                body._load_replay(P._Reader(ROOT), body.THREE)

    def test_recheck_requires_source_inventory_and_every_saved_scan(self):
        # A synthetic dependency list built from externally pinned historical
        # metadata is used only to test omission guards, never as replay proof.
        template = body.RECORD
        reader = P._Reader(ROOT)
        report = body._read_document(reader, body.REPLAYS[template]["report"])
        deps = {item["path"]: copy.deepcopy(item) for item in report["dependency_bindings"]}
        for relative in (body.IMPLEMENTATION, body.TEST, body.BASE + template + "/verify_sources.py", body.BASE + template + "/test_verify_sources.py"):
            raw = (ROOT / relative).read_bytes()
            deps[str(ROOT / relative)] = {"path": str(ROOT / relative), "sha256": P._sha(raw), "size_bytes": len(raw)}
        bound = body.REPLAYS[template]["report"]
        raw = (ROOT / bound["path"]).read_bytes()
        deps[str(ROOT / bound["path"])] = {"path": str(ROOT / bound["path"]), "sha256": bound["sha256"], "size_bytes": len(raw)}
        body._required_evidence(reader, template, deps)
        del deps[str(ROOT / report["ocr_scans"][0]["path"])]
        with self.assertRaisesRegex(ValueError, "mandatory evidence omitted"):
            body._required_evidence(reader, template, deps)
        with patch.object(Path, "iterdir", return_value=iter([])):
            with self.assertRaisesRegex(ValueError, "inventory drift"):
                body._required_evidence(reader, template, deps)

    def test_candidate_proof_is_recomposed_not_trusted(self):
        expected = {"source_ready": False, "authority": dict(body.AUTHORITY)}
        with patch.object(body, "inspect_body_source", return_value=expected) as inspector:
            with self.assertRaises(ValueError):
                body.verify_body_source({"source_ready": True}, ROOT, **request())
        inspector.assert_called_once()


if __name__ == "__main__":
    unittest.main()
