import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from unittest.mock import patch
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.db import ROOT, initialize
from hero_engine.observatory.collectors import PRIVATE_UNAVAILABLE, _snapshot
from hero_engine.observatory.openings import analyze_openings
from hero_engine.observatory.phase3 import Phase3Config, _catalog, build_cohorts, run_phase3
from hero_engine.observatory.store import (
    ChannelRegistration,
    ObservatoryStore,
    apply_migration,
    create_verified_backup,
    stable_id,
)
from tests.phase3_isolation_fixture import Phase3IsolatedFixture


class Phase3ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = Phase3IsolatedFixture(ROOT)
        cls.addClassCleanup(cls.fixture.__exit__, None, None, None)
        cls.fixture.__enter__()
        cls.openings = analyze_openings()

    def test_all_new_schemas_parse_and_reject_ambiguous_snapshot(self):
        names = (
            "observatory_snapshot.schema.json", "observatory_coverage.schema.json",
            "observatory_cohorts.schema.json", "observatory_ledger_event.schema.json",
        )
        for name in names:
            schema = json.loads((self.fixture.root / "schemas" / name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
        valid = _snapshot(
            "op-test", "chn-test", "VIDEO", "video-1", "2026-09-02T12:00:00+00:00",
            "https://www.youtube.com/watch?v=video-1", "COMPLETE", {"view_count": 10},
        )
        schema = json.loads((self.fixture.root / "schemas/observatory_snapshot.schema.json").read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema, format_checker=FormatChecker())
        self.assertEqual(list(validator.iter_errors(valid)), [])
        invalid = dict(valid)
        invalid["collection_status"] = "FAILED"
        self.assertTrue(list(validator.iter_errors(invalid)))

    def test_opening_windows_and_real_holdout_are_exact(self):
        self.assertEqual(self.openings["counts"], {
            "opening_records": 16,
            "phase2_intersection": 3,
            "holdout_from_phase2": 13,
        })
        expected = [("0_1S", 0, 1000), ("1_3S", 1000, 3000), ("3_8S", 3000, 8000), ("8_30S", 8000, 30000)]
        for record in self.openings["records"]:
            self.assertEqual(
                [(item["window"], item["start_ms"], item["end_ms"]) for item in record["windows"]],
                expected,
            )
            self.assertEqual(record["coverage_level"], "OPENING_ONLY")
            self.assertEqual(record["scene_detection"]["status"], "COMPLETE")
            self.assertEqual(len(record["evidence"]["video_sha256"]), 64)

    def test_private_metrics_are_explicitly_unavailable(self):
        self.assertEqual(
            set(PRIVATE_UNAVAILABLE),
            {"IMPRESSIONS", "CTR", "INTRO_RETENTION", "AVERAGE_VIEW_DURATION", "WATCH_HOURS", "SUBSCRIBERS_GAINED", "REVENUE", "RPM"},
        )
        self.assertNotIn("RPM", {"view_count", "like_count", "comment_count"})


class ObservatoryStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / "engine.db"
        initialize(self.db)

    def tearDown(self):
        self.temp.cleanup()

    def _store(self):
        receipt = apply_migration(self.db)
        self.assertEqual(len(receipt["content_sha256"]), 64)
        store = ObservatoryStore(self.db)
        scope = {"phase": 3, "channels": ["@example"]}
        store.create_operation("op-test", "owner", "test", scope, "2026-09-02T12:00:00+00:00")
        channel = ChannelRegistration("chn-test", "@example", "OWNED", "https://www.youtube.com/@example")
        store.register_channel("op-test", channel, "2026-09-02T12:00:00+00:00")
        return store

    def test_backup_and_migration_are_verified_and_idempotent(self):
        backup = create_verified_backup(self.db, self.root / "backup")
        self.assertTrue(backup["verified"])
        first = apply_migration(self.db)
        second = apply_migration(self.db)
        self.assertFalse(first["already_applied"])
        self.assertTrue(second["already_applied"])
        self.assertEqual(first["content_sha256"], second["content_sha256"])
        with closing(sqlite3.connect(self.db)) as conn:
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")

    def test_ledger_and_snapshots_are_append_only_and_reingest_is_idempotent(self):
        store = self._store()
        event = store.append_event(
            "op-test", "OBSERVED", "OBSERVED", "trace-1", {"value": 1},
            "2026-09-02T12:00:00+00:00", "chn-test", "https://www.youtube.com/@example",
        )
        replay = store.append_event(
            "op-test", "OBSERVED", "OBSERVED", "trace-1", {"value": 1},
            "2026-09-02T12:00:00+00:00", "chn-test", "https://www.youtube.com/@example",
        )
        self.assertEqual(event["event_id"], replay["event_id"])
        snapshot = _snapshot(
            "op-test", "chn-test", "VIDEO", "video-1", "2026-09-02T12:00:00+00:00",
            "https://www.youtube.com/watch?v=video-1", "COMPLETE", {"view_count": 10},
        )
        store.add_snapshot(snapshot)
        store.add_snapshot(snapshot)
        with closing(sqlite3.connect(self.db)) as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM observatory_ledger_events").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM observatory_public_snapshots").fetchone()[0], 1)
            with self.assertRaisesRegex(sqlite3.IntegrityError, "append-only"):
                conn.execute("UPDATE observatory_ledger_events SET event_type='MUTATED'")
            with self.assertRaisesRegex(sqlite3.IntegrityError, "append-only"):
                conn.execute("DELETE FROM observatory_public_snapshots")

    def test_channel_isolation_fails_closed(self):
        store = self._store()
        with self.assertRaises(sqlite3.IntegrityError):
            store.append_event(
                "op-test", "OBSERVED", "OBSERVED", "trace-bad", {"value": 1},
                "2026-09-02T12:00:00+00:00", "chn-other", None,
            )


class CohortTests(unittest.TestCase):
    def _snapshots(self):
        operation = "op-cohort"
        cutoff = "2026-09-02T12:00:00+00:00"
        format_id = "chn-format"
        snapshots = []
        for index in range(16):
            upload = f"20260{(index % 8) + 1}01"
            payload = {
                "view_count": (index + 1) * 1000,
                "upload_date": upload,
                "catalog_role": "FORMAT_REFERENCE",
            }
            snapshots.append(_snapshot(operation, format_id, "VIDEO", f"grace-{index:02d}", cutoff,
                                       f"https://www.youtube.com/watch?v=grace-{index:02d}", "COMPLETE", payload))
        for index, role in enumerate(("MARKET_REFERENCE", "SPEED_REFERENCE", "SPEED_REFERENCE")):
            channel_id = f"chn-cross-{index}"
            payload = {"view_count": 5000 + index * 1000, "upload_date": "20260801", "catalog_role": role}
            snapshots.append(_snapshot(operation, channel_id, "VIDEO", f"cross-{index}", cutoff,
                                       f"https://www.youtube.com/watch?v=cross-{index}", "COMPLETE", payload))
        return operation, cutoff, format_id, snapshots

    def test_cohorts_are_deterministic_and_include_winner_median_weak_period_cross(self):
        operation, cutoff, format_id, snapshots = self._snapshots()
        first = build_cohorts(operation, cutoff, format_id, snapshots)
        second = build_cohorts(operation, cutoff, format_id, list(reversed(snapshots)))
        self.assertEqual(first, second)
        self.assertEqual({item["kind"] for item in first["cohorts"]}, {"WINNER", "MEDIAN", "WEAK", "PERIOD", "CROSS_CHANNEL"})
        self.assertFalse(first["causal_claims_permitted"])
        schema = json.loads((ROOT / "schemas/observatory_cohorts.schema.json").read_text(encoding="utf-8"))
        self.assertEqual(list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(first)), [])

    def test_catalog_roles_are_isolated_and_complete(self):
        catalog = _catalog()
        self.assertEqual(len(catalog), 7)
        self.assertEqual(sum(item["role"] == "OWNED" for item in catalog), 1)
        self.assertEqual(sum(item["role"] == "FORMAT_REFERENCE" for item in catalog), 1)
        self.assertEqual(sum(item["role"] == "LICENSED_SOURCE" for item in catalog), 1)


class Phase3RealArtifactTests(unittest.TestCase):
    RUN_ID = "phase3-2026-09-02-catalog-v2"

    @classmethod
    def setUpClass(cls):
        cls.fixture = Phase3IsolatedFixture(ROOT)
        cls.addClassCleanup(cls.fixture.__exit__, None, None, None)
        cls.fixture.__enter__()
        cls.RUN_DIR = cls.fixture.run_dir
        # Populate a new SQLite database through the real cache-only runner.
        # No operational database, prepared result or stored PASS is copied.
        cls.first_run = run_phase3(cls.fixture.config)

    def test_real_run_reconciles_owned_long_and_shorts_without_private_imputation(self):
        bundle = json.loads((self.RUN_DIR / "public_snapshots.json").read_text(encoding="utf-8"))
        channels = {
            item["channel_id"]: item["payload"]["handle_requested"]
            for item in bundle["snapshots"] if item["entity_type"] == "CHANNEL"
        }
        owned = [
            item for item in bundle["snapshots"]
            if item["entity_type"] == "VIDEO" and channels[item["channel_id"]] == "@heroverse74"
        ]
        self.assertEqual(sum(item["payload"]["content_format"] == "LONG" for item in owned), 1)
        self.assertEqual(sum(item["payload"]["content_format"] == "SHORT" for item in owned), 20)
        self.assertTrue(all(set(item["unavailable_metrics"]) == set(PRIVATE_UNAVAILABLE) for item in owned))
        baseline = json.loads((self.RUN_DIR / "acquisition_baseline.json").read_text(encoding="utf-8"))
        self.assertIsNone(baseline["economics"]["rpm"])
        self.assertIsNone(baseline["forecast"]["probability_of_ypp_by_30_days"])
        self.assertFalse(baseline["ads_activation_permitted"])

    def test_real_coverage_keeps_opening_holdouts_out_of_full_video_claims(self):
        coverage = json.loads((self.RUN_DIR / "coverage.json").read_text(encoding="utf-8"))
        full_ids = {item["video_id"] for item in coverage["records"] if item["coverage_level"] == "FULL_VALIDATED"}
        opening_holdouts = {
            item["video_id"] for item in coverage["records"]
            if item["coverage_level"] == "OPENING_ONLY" and item["holdout_from_phase2"]
        }
        self.assertEqual(len(full_ids), 4)
        self.assertEqual(len(opening_holdouts), 13)
        self.assertTrue(opening_holdouts.isdisjoint(full_ids))

    def test_real_run_replay_is_cache_only_idempotent_and_integrity_manifest_matches(self):
        self.assertTrue(self.first_run["snapshot_cache_hit"])
        self.assertEqual("AWAITING_REVIEW", self.first_run["status"])
        self.assertTrue(all(self.first_run["gates"].values()), self.first_run)
        with closing(sqlite3.connect(self.fixture.db_path)) as conn:
            before = {
                table: conn.execute(f"SELECT COUNT(*) FROM {table} WHERE operation_id=?", (self.RUN_ID,)).fetchone()[0]
                for table in ("observatory_public_snapshots", "observatory_ledger_events", "observatory_coverage", "observatory_cohorts")
            }
        with patch("hero_engine.observatory.phase3.collect_channel", side_effect=AssertionError("network collection must not run")):
            replay = run_phase3(self.fixture.config)
        self.assertTrue(replay["snapshot_cache_hit"])
        self.assertEqual(replay["status"], "AWAITING_REVIEW")
        self.assertTrue(all(replay["gates"].values()))
        with closing(sqlite3.connect(self.fixture.db_path)) as conn:
            after = {
                table: conn.execute(f"SELECT COUNT(*) FROM {table} WHERE operation_id=?", (self.RUN_ID,)).fetchone()[0]
                for table in before
            }
        self.assertEqual(before, after)
        manifest = json.loads((self.RUN_DIR / "integrity_manifest.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(manifest["item_count"], 15)
        for item in manifest["entries"]:
            artifact = self.fixture.confined(self.fixture.root / item["artifact"])
            self.assertEqual(artifact.stat().st_size, item["size_bytes"])
            import hashlib
            self.assertEqual(hashlib.sha256(artifact.read_bytes()).hexdigest(), item["sha256"])
        self.assertTrue(self.fixture.sqlite_paths)
        self.assertTrue(all(path.is_relative_to(self.fixture.root) for path in self.fixture.sqlite_paths))
        self.assertTrue(self.fixture.written_paths)
        self.assertTrue(all(path.is_relative_to(self.fixture.root) for path in self.fixture.written_paths))


if __name__ == "__main__":
    unittest.main()
