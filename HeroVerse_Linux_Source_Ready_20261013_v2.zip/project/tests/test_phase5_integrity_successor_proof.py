import unittest

from hero_engine import phase5_integrity_successor_proof as proof


class IntegritySuccessorProofContractTests(unittest.TestCase):
    def test_proof_has_a_distinct_narrow_purpose_and_cannot_be_an_application_proof(self):
        self.assertEqual("EXACT_CURRENT_INTEGRITY_SUCCESSOR_MAINTENANCE", proof.PURPOSE)
        self.assertNotIn("application-envelope.json", proof.FILES)
        self.assertIn("integrity_manifest_successor.json", proof.FILES)

    def test_inventory_selects_only_the_transactional_integrity_maintenance_tests(self):
        full = {"schema_version":"1.1.0", "files":[
            {"path":"tests/test_phase5_integrity_maintenance.py", "content_hash":"sha256:" + "a" * 64,
             "test_ids":["tests.test_phase5_integrity_maintenance.IntegrityMaintenanceTests.test_stage"]},
            {"path":"tests/test_other.py", "content_hash":"sha256:" + "b" * 64,
             "test_ids":["tests.test_other.OtherTests.test_other"]},
        ]}
        current = proof.build_test_inventory(full)
        self.assertEqual(1, current["test_count"])
        self.assertEqual("tests/test_phase5_integrity_maintenance.py", current["files"][0]["path"])
        self.assertEqual(0, current["alias_count"])

    def test_inventory_includes_the_proof_reader_contract_tests(self):
        full = {"schema_version":"1.1.0", "files":[
            {"path":"tests/test_phase5_integrity_successor_proof.py", "content_hash":"sha256:" + "c" * 64,
             "test_ids":["tests.test_phase5_integrity_successor_proof.IntegritySuccessorProofContractTests.test_contract"]},
        ]}
        self.assertEqual(1, proof.build_test_inventory(full)["test_count"])

    def test_empty_or_ambiguous_inventory_is_rejected(self):
        with self.assertRaises(proof.IntegritySuccessorProofError):
            proof.build_test_inventory({"schema_version":"1.1.0", "files":[]})

    def test_absolute_proof_paths_are_normalized_only_when_they_resolve_under_root(self):
        # The public reader uses this boundary before its existing path guard;
        # this regression prevents an absolute command-line path from being
        # rejected as a malformed relative path.
        root = self._root_for_path_normalization()
        offered = root / "output/runtime/gestor-central/maintenance-runs/run/envelope.json"
        offered.parent.mkdir(parents=True); offered.write_text("{}", encoding="utf-8")
        self.assertEqual("output/runtime/gestor-central/maintenance-runs/run/envelope.json",
                         proof._proof_relative_path(root, offered))
        outside = root.parent / "outside-envelope.json"; outside.write_text("{}", encoding="utf-8")
        with self.assertRaises(proof.IntegritySuccessorProofError):
            proof._proof_relative_path(root, outside)

    def _root_for_path_normalization(self):
        import tempfile
        from pathlib import Path
        directory = tempfile.TemporaryDirectory(); self.addCleanup(directory.cleanup)
        return Path(directory.name)
