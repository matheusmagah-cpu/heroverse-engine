from __future__ import annotations

import builtins
import io
import json
import hashlib
import os
import socket
import sqlite3
import subprocess
import tempfile
import unittest
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

from jsonschema import Draft202012Validator

from hero_engine.phase6_acceptance import (
    VIDEO2_PUBLICATION,
    _complete_live_learning_cycle,
    _gc21_recovery_test_evidence,
    _test_evidence,
    build_phase6_acceptance,
)
from hero_engine.phase6_intelligence import build_prediction, evaluate_prediction
from hero_engine.phase6_control_cycle import STAGES
from hero_engine.queue_phase6 import TransactionalQueue


ROOT = Path(__file__).resolve().parents[1]


class Phase6AcceptanceTests(unittest.TestCase):
    @staticmethod
    def _copy_schemas(root: Path, *names: str) -> None:
        (root / "schemas").mkdir(parents=True, exist_ok=True)
        for name in names:
            (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())

    @contextmanager
    def _isolated_report_root(self):
        """Documentary fixture plus a new empty queue; no operational DB is read.

        PASS_LIVE in the returned report refers to the copied receipt's contract,
        never to a process, deployment or learning outcome observed by this test.
        """
        with tempfile.TemporaryDirectory(prefix="phase6-acceptance-isolated-") as folder:
            root = Path(folder).resolve()
            documents = {
                "output/runtime/gestor-central/autostart-verification.json": "central_manager_autostart_verification.schema.json",
                "output/operations/phase6/control-cycle/latest.json": "phase6_control_cycle_receipt.schema.json",
                "output/operations/phase6/executive-status.json": "phase6_executive_status.schema.json",
                "output/operations/phase6/intelligence/predictions/latest.json": "prediction_record.schema.json",
                "output/operations/phase6/metrics/iK_5edYQtx8/own-performance-iK_5edYQtx8-20260904T191201Z.json": "own_channel_performance_snapshot.schema.json",
                "output/mining/phase2/benchmarks/summary.json": None,
            }
            self._copy_schemas(
                root,
                "phase6_acceptance_report.schema.json",
                "phase6_queue_snapshot.schema.json",
                "prediction_evaluation.schema.json",
                "phase6_prediction_outcome_binding.schema.json",
                *(schema for schema in documents.values() if schema is not None),
            )
            for relative, schema in documents.items():
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / relative).read_bytes())
                if schema is not None:
                    Draft202012Validator(json.loads((root / "schemas" / schema).read_text(encoding="utf-8-sig"))).validate(
                        json.loads(target.read_text(encoding="utf-8-sig"))
                    )

            # A report is not its own evidence: the current consumer reopens
            # all twelve sealed stage buffers. Copy that exact dependency
            # closure, not only the mutable latest/report aliases. Nothing is
            # regenerated or substituted for a missing historical snapshot.
            cycle = json.loads(
                (root / "output/operations/phase6/control-cycle/latest.json").read_bytes()
            )
            snapshot_parent = Path("output/operations/phase6/control-cycle/source-snapshots") / cycle["cycle_id"]
            for ordinal, (contract, stage) in enumerate(zip(STAGES, cycle["stages"], strict=True), 1):
                relative = snapshot_parent / f"{ordinal:02d}-{contract['stage'].lower().replace('_', '-')}.json"
                self.assertEqual(relative.as_posix(), stage["snapshot_path"])
                raw = (ROOT / relative).read_bytes()
                self.assertEqual(stage["content_hash"], "sha256:" + hashlib.sha256(raw).hexdigest())
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
                self._copy_schemas(root, contract["schema"])

            violations = []
            sqlite_calls = []
            opened = []
            original_connect = sqlite3.connect

            def check_path(file):
                path = Path(os.fsdecode(file)).resolve()
                if not path.is_relative_to(root):
                    violations.append(str(path))
                    raise AssertionError("Acceptance test attempted non-fixture IO")
                return path

            def checked_open(original):
                def open_local(file, *args, **kwargs):
                    check_path(file)
                    return original(file, *args, **kwargs)
                return open_local

            def connect_local(database, *args, **kwargs):
                value = os.fsdecode(database)
                filename = unquote(value[5:].split("?", 1)[0]) if value.startswith("file:") else value
                path = check_path(filename)
                sqlite_calls.append((path, kwargs.get("uri", False), value))
                connection = original_connect(database, *args, **kwargs)
                opened.append(connection)
                return connection

            with ExitStack() as guards:
                for module, name in ((builtins, "open"), (io, "open"), (os, "open")):
                    guards.enter_context(patch.object(module, name, checked_open(getattr(module, name))))
                guards.enter_context(patch.object(sqlite3, "connect", side_effect=connect_local))
                for module, name in ((socket, "socket"), (socket, "create_connection"), (subprocess, "Popen"), (os, "system")):
                    guards.enter_context(patch.object(module, name, side_effect=AssertionError("External action forbidden in acceptance test")))
                try:
                    queue = TransactionalQueue(root)
                    snapshot = queue.snapshot(captured_at=datetime(2026, 9, 5, 1, 30, tzinfo=timezone.utc))
                    snapshot_path = root / "output/operations/phase6/runtime/queue-snapshot.json"
                    snapshot_path.write_text(json.dumps(snapshot), encoding="utf-8")
                    self.assertEqual([], snapshot["jobs"])
                    self.assertEqual(root / snapshot["database_path"], queue.path)
                    sqlite_calls.clear()
                    yield root
                finally:
                    for connection in opened:
                        connection.close()
            self.assertEqual([], violations)
            # Prove the actual acceptance integrity query used only the new DB.
            self.assertEqual(
                [(queue.path, True, f"file:{queue.path.as_posix()}?mode=ro")],
                sqlite_calls,
            )

    def test_structured_maintenance_evidence_never_promotes_an_allowed_skip_as_test_pass(self) -> None:
        passing_id = "tests.test_phase6_queue.Phase6QueueTests.test_channel_isolation_and_schema_valid_snapshot"
        skipped_id = (
            "tests.test_scheduled_voice_probe.ScheduledVoiceProbeTests."
            "test_preexisting_sample_symlink_is_never_reused"
        )
        ids = [passing_id, skipped_id]
        raw = json.dumps(
            ids, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            evidence = root / "evidence"
            evidence.mkdir()
            inventory = {
                "schema_version": "1.0.0",
                "discovery_pattern": "tests/test_*.py",
                "file_count": 2,
                "test_count": 2,
                "tests_hash": "sha256:" + hashlib.sha256(raw).hexdigest(),
                "files": [
                    {
                        "path": "tests/test_phase6_queue.py",
                        "content_hash": "sha256:" + "a" * 64,
                        "test_ids": [passing_id],
                    },
                    {
                        "path": "tests/test_scheduled_voice_probe.py",
                        "content_hash": "sha256:" + "b" * 64,
                        "test_ids": [skipped_id],
                    },
                ],
            }
            inventory_path = evidence / "test-inventory.json"
            stdout_path = evidence / "stdout.log"
            stderr_path = evidence / "stderr.log"
            inventory_path.write_text(json.dumps(inventory), encoding="utf-8")
            stdout_path.write_text("", encoding="utf-8")
            stderr_path.write_text(
                "test_channel_isolation_and_schema_valid_snapshot "
                "(test_phase6_queue.Phase6QueueTests.test_channel_isolation_and_schema_valid_snapshot) ... ok\n"
                "test_preexisting_sample_symlink_is_never_reused "
                "(test_scheduled_voice_probe.ScheduledVoiceProbeTests."
                "test_preexisting_sample_symlink_is_never_reused) ... "
                "skipped \"file symlink unavailable: [WinError 1314] localized\"\n"
                "Ran 2 tests in 0.002s\n\nOK (skipped=1)\n",
                encoding="utf-8",
            )

            def digest(path: Path) -> str:
                return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()

            receipt = {
                "status": "PASS",
                "tests": {
                    "test_count": 2,
                    "inventory_path": inventory_path.relative_to(root).as_posix(),
                    "inventory_hash": digest(inventory_path),
                    "stdout_log": stdout_path.relative_to(root).as_posix(),
                    "stdout_hash": digest(stdout_path),
                    "stderr_log": stderr_path.relative_to(root).as_posix(),
                    "stderr_hash": digest(stderr_path),
                },
            }
            self.assertTrue(
                _test_evidence(root, receipt, "test_channel_isolation_and_schema_valid_snapshot")
            )
            self.assertFalse(
                _test_evidence(root, receipt, "test_preexisting_sample_symlink_is_never_reused")
            )
            legacy_receipt = {
                "regression_status": "PASS",
                "stdout_log": stdout_path.relative_to(root).as_posix(),
                "stderr_log": stderr_path.relative_to(root).as_posix(),
            }
            self.assertTrue(
                _test_evidence(
                    root,
                    legacy_receipt,
                    "test_channel_isolation_and_schema_valid_snapshot",
                )
            )
            self.assertFalse(
                _test_evidence(
                    root,
                    legacy_receipt,
                    "test_preexisting_sample_symlink_is_never_reused",
                )
            )

    def test_gc21_binds_both_qualified_recovery_tests_and_rejects_ambiguous_suffix(self) -> None:
        method = "test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime"
        protocol_id = (
            "tests.test_daily_maintenance_protocol.DailyMaintenanceProtocolTests." + method
        )
        autostart_id = (
            "tests.test_phase5_manager_autostart.Phase5ManagerAutostartTests." + method
        )
        ids = [protocol_id, autostart_id]
        raw = json.dumps(
            ids, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            evidence = root / "evidence"
            evidence.mkdir()
            inventory = {
                "schema_version": "1.0.0",
                "discovery_pattern": "tests/test_*.py",
                "file_count": 2,
                "test_count": 2,
                "tests_hash": "sha256:" + hashlib.sha256(raw).hexdigest(),
                "files": [
                    {
                        "path": "tests/test_daily_maintenance_protocol.py",
                        "content_hash": "sha256:" + "a" * 64,
                        "test_ids": [protocol_id],
                    },
                    {
                        "path": "tests/test_phase5_manager_autostart.py",
                        "content_hash": "sha256:" + "b" * 64,
                        "test_ids": [autostart_id],
                    },
                ],
            }
            inventory_path = evidence / "test-inventory.json"
            stdout_path = evidence / "stdout.log"
            stderr_path = evidence / "stderr.log"
            inventory_path.write_text(json.dumps(inventory), encoding="utf-8")
            stdout_path.write_text("", encoding="utf-8")
            stderr_path.write_text(
                f"{method} (test_daily_maintenance_protocol.DailyMaintenanceProtocolTests.{method}) ... ok\n"
                f"{method} (test_phase5_manager_autostart.Phase5ManagerAutostartTests.{method}) ... ok\n"
                "Ran 2 tests in 0.002s\n\nOK\n",
                encoding="utf-8",
            )

            def digest(path: Path) -> str:
                return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()

            receipt = {
                "status": "PASS",
                "tests": {
                    "test_count": 2,
                    "inventory_path": inventory_path.relative_to(root).as_posix(),
                    "inventory_hash": digest(inventory_path),
                    "stdout_log": stdout_path.relative_to(root).as_posix(),
                    "stdout_hash": digest(stdout_path),
                    "stderr_log": stderr_path.relative_to(root).as_posix(),
                    "stderr_hash": digest(stderr_path),
                },
            }
            self.assertFalse(_test_evidence(root, receipt, method))
            self.assertTrue(_test_evidence(root, receipt, protocol_id))
            self.assertTrue(_test_evidence(root, receipt, autostart_id))
            self.assertTrue(_gc21_recovery_test_evidence(root, receipt))

            incomplete_inventory = dict(inventory)
            incomplete_inventory["files"] = inventory["files"][:1]
            incomplete_inventory["file_count"] = 1
            incomplete_inventory["test_count"] = 1
            incomplete_ids = [protocol_id]
            incomplete_inventory["tests_hash"] = "sha256:" + hashlib.sha256(
                json.dumps(
                    incomplete_ids,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest()
            inventory_path.write_text(json.dumps(incomplete_inventory), encoding="utf-8")
            stderr_path.write_text(
                f"{method} (test_daily_maintenance_protocol.DailyMaintenanceProtocolTests.{method}) ... ok\n"
                "Ran 1 test in 0.001s\n\nOK\n",
                encoding="utf-8",
            )
            receipt["tests"]["inventory_hash"] = digest(inventory_path)
            receipt["tests"]["stderr_hash"] = digest(stderr_path)
            self.assertFalse(_gc21_recovery_test_evidence(root, receipt))

            receipt["tests"]["inventory_hash"] = "sha256:" + "0" * 64
            self.assertFalse(_gc21_recovery_test_evidence(root, receipt))

    def test_report_has_every_gc_check_and_never_closes_before_real_learning(self) -> None:
        with self._isolated_report_root() as root:
            report = build_phase6_acceptance(root, generated_at="2026-09-05T01:30:00Z")
            schema = json.loads((root / "schemas/phase6_acceptance_report.schema.json").read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(report)
        self.assertEqual([f"GC-{number:02d}" for number in range(1, 23)], [item["check_id"] for item in report["checks"]])
        self.assertFalse(report["current_phase_ready"])
        self.assertEqual("IN_PROGRESS", report["phase_decision"])
        self.assertIn("GC-01", report["blocking_check_ids"])
        self.assertNotIn("GC-14", report["blocking_check_ids"])

    def test_live_report_does_not_mislabel_later_phase_rule_work(self) -> None:
        with self._isolated_report_root() as root:
            report = build_phase6_acceptance(root, generated_at="2026-09-05T01:30:00Z")
            cycle = json.loads(
                (root / "output/operations/phase6/control-cycle/latest.json").read_text(encoding="utf-8-sig")
            )
            runtime = json.loads(
                (root / "output/runtime/gestor-central/autostart-verification.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            executive = json.loads(
                (root / "output/operations/phase6/executive-status.json").read_bytes()
            )
            goal_stage = next(item for item in cycle["stages"] if item["stage"] == "GOAL_TRAJECTORY")
            goal_raw = (root / goal_stage["snapshot_path"]).read_bytes()
            goal = json.loads(goal_raw)
            cycle_raw = (root / "output/operations/phase6/control-cycle/latest.json").read_bytes()
        by_id = {item["check_id"]: item for item in report["checks"]}
        for check_id in ("GC-13", "GC-14", "GC-15", "GC-17"):
            self.assertEqual("NOT_APPLICABLE_CURRENT_PHASE", by_id[check_id]["status"])
            self.assertFalse(by_id[check_id]["required_for_phase6"])
        cycle_is_integral = bool(
            cycle.get("schema_version") == "1.1.0"
            and cycle.get("stage_count") == 12
            and cycle.get("expected_stage_count") == 12
            and cycle.get("all_schemas_valid") is True
            and cycle.get("all_stages_executed_in_cycle") is True
            and cycle.get("decision") in {"PASS_WAITING", "PASS_ADVANCED"}
            and cycle.get("blockers") == []
        )
        runtime_is_live = bool(
            runtime.get("operational_ready") is True
            and runtime.get("manager_alive") is True
            and runtime.get("same_process_chain") is True
            and runtime.get("duplicate_probe_blocked") is True
            and runtime.get("active_stderr_bytes") == 0
        )
        expected = "PASS_LIVE" if cycle_is_integral and runtime_is_live else "MISSING_EVIDENCE"
        for check_id in ("GC-07", "GC-22"):
            self.assertEqual(expected, by_id[check_id]["status"])
            self.assertIn("output/operations/phase6/control-cycle/latest.json", by_id[check_id]["evidence"])
        # A healthy cycle/runtime does not certify a report from another cycle.
        # Derive the expected binding independently from the copied sealed bytes;
        # do not manufacture a PASS or rewrite the operational report.
        binding = {
            "cycle_id": cycle["cycle_id"],
            "cycle_sha256": "sha256:" + hashlib.sha256(cycle_raw).hexdigest(),
            "trajectory_id": goal["trajectory_id"],
            "trajectory_sha256": "sha256:" + hashlib.sha256(goal_raw).hexdigest(),
        }
        summary = executive.get("control_cycle") or {}
        executive_is_current = bool(
            cycle_is_integral
            and executive.get("producer_binding") == binding
            and summary.get("cycle_id") == cycle["cycle_id"]
            and summary.get("substantive_signature") == cycle["substantive_signature"]
            and (executive.get("goal_trajectory") or {}).get("trajectory_id") == goal["trajectory_id"]
            and datetime.fromisoformat(executive["captured_at"].replace("Z", "+00:00"))
                >= datetime.fromisoformat(cycle["cycle_completed_at"].replace("Z", "+00:00"))
        )
        self.assertEqual("PASS_LIVE" if executive_is_current else "MISSING_EVIDENCE", by_id["GC-20"]["status"])
        self.assertIn("output/operations/phase6/control-cycle/latest.json", by_id["GC-20"]["evidence"])

    def test_missing_data_proof_survives_without_a_current_executive_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "own_channel_performance_snapshot.schema.json",
                "phase6_acceptance_report.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            target = root / (
                "output/operations/phase6/metrics/iK_5edYQtx8/"
                "own-performance-iK_5edYQtx8-20260904T191201Z.json"
            )
            target.parent.mkdir(parents=True)
            target.write_bytes(
                (
                    ROOT
                    / "output/operations/phase6/metrics/iK_5edYQtx8/"
                    "own-performance-iK_5edYQtx8-20260904T191201Z.json"
                ).read_bytes()
            )
            report = build_phase6_acceptance(root, generated_at="2026-09-06T12:00:00Z")
            by_id = {item["check_id"]: item for item in report["checks"]}
            self.assertEqual("PASS_LIVE", by_id["GC-08"]["status"])
            self.assertEqual("MISSING_EVIDENCE", by_id["GC-07"]["status"])
            self.assertEqual("MISSING_EVIDENCE", by_id["GC-20"]["status"])

    def test_unrelated_prediction_evaluation_cannot_satisfy_gc19(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._copy_schemas(
                root,
                "phase6_acceptance_report.schema.json",
                "prediction_record.schema.json",
                "prediction_evaluation.schema.json",
            )
            prediction = json.loads(
                (ROOT / "output/operations/phase6/intelligence/predictions/latest.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            prediction_path = root / "output/operations/phase6/intelligence/predictions/latest.json"
            prediction_path.parent.mkdir(parents=True)
            prediction_path.write_text(json.dumps(prediction), encoding="utf-8")
            unrelated = evaluate_prediction(
                prediction,
                outcome_value=999,
                observed_at=prediction["horizon"]["ends_at"],
                outcome_source_id="unrelated-snapshot",
            )
            unrelated_path = (
                root
                / "output/operations/phase6/intelligence/prediction-evaluations/evaluation-unrelated.json"
            )
            unrelated_path.parent.mkdir(parents=True)
            unrelated_path.write_text(json.dumps(unrelated), encoding="utf-8")

            report = build_phase6_acceptance(root, generated_at="2026-09-06T12:00:00Z")
            by_id = {item["check_id"]: item for item in report["checks"]}
            self.assertEqual("WAITING_REAL_EVIDENCE", by_id["GC-19"]["status"])

    def test_gc19_preserves_completed_chain_when_latest_advances_and_rejects_tampering(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._copy_schemas(
                root,
                "phase6_acceptance_report.schema.json",
                "prediction_record.schema.json",
                "prediction_evaluation.schema.json",
                "phase6_prediction_runtime.schema.json",
                "phase6_prediction_outcome_binding.schema.json",
                "own_channel_performance_snapshot.schema.json",
                "phase6_queue_snapshot.schema.json",
            )
            prediction = json.loads(
                (ROOT / "output/operations/phase6/intelligence/predictions/latest.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            prediction_path = root / "output/operations/phase6/intelligence/predictions/latest.json"
            prediction_path.parent.mkdir(parents=True)
            prediction_path.write_text(json.dumps(prediction), encoding="utf-8")
            immutable_prediction_path = (
                prediction_path.parent / f"{prediction['prediction_id']}.json"
            )
            immutable_prediction_path.write_text(json.dumps(prediction), encoding="utf-8")
            horizon = datetime.fromisoformat(
                prediction["horizon"]["ends_at"].replace("Z", "+00:00")
            ).astimezone(timezone.utc)
            observed_at = horizon.isoformat().replace("+00:00", "Z")
            source = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/own-performance-iK_5edYQtx8-20260904T191201Z.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            source["snapshot_id"] = "prediction-outcome-fixture"
            source["captured_at"] = observed_at
            source["age_hours"] = 24.5
            source["public_metrics"]["viewCount"] = 17
            job_id = "job-1234567890abcdef12345678"
            snapshot_ref = f"output/operations/phase6/intelligence/prediction-outcomes/{job_id}/snapshot.json"
            snapshot_path = root / snapshot_ref
            snapshot_path.parent.mkdir(parents=True)
            snapshot_path.write_text(json.dumps(source), encoding="utf-8")
            digest = "sha256:" + hashlib.sha256(snapshot_path.read_bytes()).hexdigest()
            binding = {
                "schema_version": "1.0.0",
                "operation": "phase6_prediction_outcome_checkpoint",
                "job_id": job_id,
                "prediction_id": prediction["prediction_id"],
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "video_id": "iK_5edYQtx8",
                "horizon_ends_at": prediction["horizon"]["ends_at"],
                "snapshot": {
                    "path": snapshot_ref,
                    "sha256": digest,
                    "schema": "own_channel_performance_snapshot.schema.json",
                    "schema_version": source["schema_version"],
                    "snapshot_id": source["snapshot_id"],
                    "captured_at": source["captured_at"],
                },
            }
            evaluation = evaluate_prediction(
                prediction,
                outcome_value=17,
                observed_at=observed_at,
                outcome_source_id=source["snapshot_id"],
            )
            horizon_key = horizon.strftime("%Y%m%dT%H%M%SZ")
            evaluation_ref = (
                "output/operations/phase6/intelligence/prediction-evaluations/"
                f"evaluation-{prediction['prediction_id']}-{horizon_key}.json"
            )
            evaluation_path = root / evaluation_ref
            evaluation_path.parent.mkdir(parents=True)
            evaluation_path.write_text(json.dumps(evaluation), encoding="utf-8")
            checkpoint = {
                "outcome_snapshot": snapshot_ref,
                "outcome_snapshot_hash": digest,
                "outcome_snapshot_schema": "own_channel_performance_snapshot.schema.json",
                "outcome_binding": binding,
                "evaluation": evaluation_ref,
            }
            queue = {
                "schema_version": "1.0.0",
                "queue_id": "heroverse-phase6-transactional-queue-v1",
                "phase": 6,
                "status": "HEALTHY",
                "database_path": "output/operations/phase6/runtime/phase6-queue.sqlite3",
                "counts": {"PENDING": 0, "LEASED": 0, "RETRY_WAIT": 0, "SUCCEEDED": 1, "DEAD_LETTER": 0},
                "executable_counts": {"PENDING": 0, "LEASED": 0, "RETRY_WAIT": 0, "SUCCEEDED": 1, "DEAD_LETTER": 0},
                "jobs": [{
                    "job_id": job_id,
                    "idempotency_key": (
                        f"phase6-prediction-outcome:{prediction['prediction_id']}:"
                        f"{prediction['horizon']['ends_at']}"
                    ),
                    "operation_id": "heroverse-phase6-controlled-longform-v1",
                    "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                    "task_type": "PREDICTION_OUTCOME_CHECKPOINT",
                    "payload": {
                        "prediction_id": prediction["prediction_id"],
                        "video_id": "iK_5edYQtx8",
                        "horizon_ends_at": prediction["horizon"]["ends_at"],
                    },
                    "state": "SUCCEEDED",
                    "attempt_count": 1,
                    "max_attempts": 3,
                    "available_at": observed_at,
                    "lease_owner": None,
                    "lease_until": None,
                    "checkpoint": checkpoint,
                    "last_error": None,
                    "created_at": prediction["created_at"],
                    "updated_at": observed_at,
                }],
                "media_job_supersessions": [],
                "incidents": [],
                "technical_cost_brl": 0,
                "captured_at": observed_at,
            }
            queue_path = root / "output/operations/phase6/runtime/queue-snapshot.json"
            queue_path.parent.mkdir(parents=True)
            queue_path.write_text(json.dumps(queue), encoding="utf-8")
            runtime = {
                "schema_version": "1.1.0",
                "observer_id": "heroverse-phase6-prediction-outcome-v1",
                "phase": 6,
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "status": evaluation["status"],
                "prediction_id": prediction["prediction_id"],
                "prediction_status": prediction["status"],
                "horizon_ends_at": prediction["horizon"]["ends_at"],
                "next_observation_at": None,
                "job_id": job_id,
                "job_state": "SUCCEEDED",
                "outcome_snapshot": snapshot_ref,
                "outcome_snapshot_hash": digest,
                "outcome_snapshot_schema": "own_channel_performance_snapshot.schema.json",
                "evaluation": evaluation_ref,
                "error": None,
                "technical_cost_brl": 0,
                "updated_at": observed_at,
            }
            runtime_path = root / "output/operations/phase6/intelligence/prediction-runtime.json"
            runtime_path.parent.mkdir(parents=True, exist_ok=True)
            runtime_path.write_text(json.dumps(runtime), encoding="utf-8")

            report = build_phase6_acceptance(root, generated_at="2026-09-06T12:00:00Z")
            self.assertEqual(
                "PASS_LIVE",
                {item["check_id"]: item for item in report["checks"]}["GC-19"]["status"],
            )

            # A second prediction legitimately replaces both mutable current
            # views before its horizon.  The completed first chain remains a
            # cumulative acceptance proof.
            next_feature = json.loads(json.dumps(source))
            next_feature["snapshot_id"] = "prediction-next-feature"
            next_feature["captured_at"] = "2026-09-06T18:00:00Z"
            next_prediction = build_prediction(
                next_feature,
                created_at="2026-09-06T18:01:00Z",
            )
            prediction_path.write_text(json.dumps(next_prediction), encoding="utf-8")
            (prediction_path.parent / f"{next_prediction['prediction_id']}.json").write_text(
                json.dumps(next_prediction), encoding="utf-8"
            )
            next_job_id = "job-abcdef1234567890abcdef12"
            runtime.update(
                {
                    "status": "WAITING_FOR_HORIZON",
                    "prediction_id": next_prediction["prediction_id"],
                    "prediction_status": next_prediction["status"],
                    "horizon_ends_at": next_prediction["horizon"]["ends_at"],
                    "next_observation_at": next_prediction["horizon"]["ends_at"],
                    "job_id": next_job_id,
                    "job_state": "PENDING",
                    "outcome_snapshot": None,
                    "outcome_snapshot_hash": None,
                    "outcome_snapshot_schema": None,
                    "evaluation": None,
                    "updated_at": "2026-09-06T18:01:00Z",
                }
            )
            runtime_path.write_text(json.dumps(runtime), encoding="utf-8")
            queue["jobs"].append(
                {
                    "job_id": next_job_id,
                    "idempotency_key": (
                        f"phase6-prediction-outcome:{next_prediction['prediction_id']}:"
                        f"{next_prediction['horizon']['ends_at']}"
                    ),
                    "operation_id": "heroverse-phase6-controlled-longform-v1",
                    "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                    "task_type": "PREDICTION_OUTCOME_CHECKPOINT",
                    "payload": {
                        "prediction_id": next_prediction["prediction_id"],
                        "video_id": "iK_5edYQtx8",
                        "horizon_ends_at": next_prediction["horizon"]["ends_at"],
                    },
                    "state": "PENDING",
                    "attempt_count": 0,
                    "max_attempts": 3,
                    "available_at": next_prediction["horizon"]["ends_at"],
                    "lease_owner": None,
                    "lease_until": None,
                    "checkpoint": {},
                    "last_error": None,
                    "created_at": "2026-09-06T18:01:00Z",
                    "updated_at": "2026-09-06T18:01:00Z",
                }
            )
            queue["counts"]["PENDING"] = 1
            queue_path.write_text(json.dumps(queue), encoding="utf-8")
            advanced = build_phase6_acceptance(
                root, generated_at="2026-09-06T18:02:00Z"
            )
            advanced_gc19 = {
                item["check_id"]: item for item in advanced["checks"]
            }["GC-19"]
            self.assertEqual("PASS_LIVE", advanced_gc19["status"])
            self.assertIn(
                immutable_prediction_path.relative_to(root).as_posix(),
                advanced_gc19["evidence"],
            )
            self.assertNotIn(
                "output/operations/phase6/intelligence/predictions/latest.json",
                advanced_gc19["evidence"],
            )

            source["public_metrics"]["viewCount"] = 999
            snapshot_path.write_text(json.dumps(source), encoding="utf-8")
            tampered = build_phase6_acceptance(root, generated_at="2026-09-06T12:01:00Z")
            self.assertEqual(
                "WAITING_REAL_EVIDENCE",
                {item["check_id"]: item for item in tampered["checks"]}["GC-19"]["status"],
            )

    def test_shallow_learning_runtime_cannot_satisfy_gc01(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._copy_schemas(
                root,
                "phase6_acceptance_report.schema.json",
                "phase6_learning_runtime.schema.json",
            )
            runtime = {
                "schema_version": "1.0.0",
                "observer_id": "heroverse-phase6-treatment-learning-v1",
                "phase": 6,
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "status": "EVALUATED",
                "protocol_id": "unbound-protocol",
                "treatment_variable": "TOPIC_ANGLE",
                "target_video_id": "unbound-video",
                "publication_receipt": "unbound-publication.json",
                "baseline_snapshot": "unbound-baseline.json",
                "latest_treatment_snapshot": "unbound-treatment.json",
                "scheduled_window_at": "2026-09-06T10:00:00Z",
                "next_observation_at": None,
                "job_id": "job-000000000000000000000000",
                "job_state": "SUCCEEDED",
                "evaluation": "unbound-evaluation.json",
                "classification": "SUPPORTED",
                "next_action": "Preserve evidence.",
                "error": None,
                "technical_cost_brl": 0,
                "updated_at": "2026-09-06T12:00:00Z",
            }
            runtime_path = root / "output/operations/phase6/intelligence/learning-runtime.json"
            runtime_path.parent.mkdir(parents=True)
            runtime_path.write_text(json.dumps(runtime), encoding="utf-8")

            report = build_phase6_acceptance(root, generated_at="2026-09-06T12:00:00Z")
            by_id = {item["check_id"]: item for item in report["checks"]}
            self.assertEqual("WAITING_REAL_EVIDENCE", by_id["GC-01"]["status"])

    def test_schema_valid_legacy_complete_receipt_cannot_satisfy_learning_acceptance(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._copy_schemas(root, "youtube_publication_receipt.schema.json")
            receipt = {
                "schema_version": "1.0.0",
                "receipt_id": "forged-schema-only-complete",
                "release_id": "forged-release",
                "idempotency_key": "a" * 64,
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "status": "COMPLETE_PUBLIC",
                "privacy_status": "public",
                "video_id": "forged-treatment-video",
                "caption_id": "forged-caption",
                "steps": [{"step": "forged", "status": "PASS", "evidence": "schema-only"}],
                "artifact_hashes": {"video": "1" * 64, "thumbnail": "2" * 64, "captions": "3" * 64},
                "external_cost_brl": 0,
                "public_visibility_authorized": True,
                "error": None,
                "created_at": "2026-09-05T20:00:00Z",
                "updated_at": "2026-09-05T20:01:00Z",
            }
            receipt_path = root / VIDEO2_PUBLICATION
            receipt_path.parent.mkdir(parents=True, exist_ok=True)
            receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
            protocol = {
                "protocol_id": "protocol-exact",
                "status": "PREREGISTERED",
                "created_at": "2026-09-05T19:00:00Z",
                "primary_metric": "views",
                "baseline": {"snapshot_id": "baseline-exact"},
                "treatment": {"variable": "TOPIC_ANGLE", "video_id": "phase6-video-2-prepublication"},
            }
            learning = {
                "status": "EVALUATED", "job_state": "SUCCEEDED", "error": None,
                "protocol_id": "protocol-exact", "treatment_variable": "TOPIC_ANGLE",
                "baseline_snapshot": "output/operations/phase6/metrics/iK_5edYQtx8/baseline-exact.json",
                "classification": "SUPPORTED", "publication_receipt": VIDEO2_PUBLICATION,
                "latest_treatment_snapshot": "output/operations/phase6/intelligence/learning-external/job-exact/snapshot.json",
                "evaluation": "output/operations/phase6/intelligence/learning-evidence/evaluation-exact.json",
                "target_video_id": "forged-treatment-video", "job_id": "job-exact",
                "scheduled_window_at": "2026-09-06T20:00:00Z",
            }
            fake_paths = [
                (root / "baseline.json", {"snapshot_id": "baseline-exact"}),
                (root / "output/operations/phase6/intelligence/learning-external/job-exact/snapshot.json", {}),
                (root / "output/operations/phase6/intelligence/learning-evidence/evaluation-exact.json", {}),
            ]
            with patch("hero_engine.phase6_acceptance._live_preregistration", return_value=True), patch(
                "hero_engine.phase6_acceptance._confined_valid", side_effect=fake_paths
            ), patch("hero_engine.phase6_acceptance._valid", return_value=receipt):
                self.assertFalse(_complete_live_learning_cycle(root, protocol, learning))


if __name__ == "__main__":
    unittest.main()
