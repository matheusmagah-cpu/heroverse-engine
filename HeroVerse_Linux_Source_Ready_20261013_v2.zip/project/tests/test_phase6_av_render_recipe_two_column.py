"""Real A -> C -> body preparation, without admission, media or publication.

The populated-span serializer case is explicitly a synthetic boundary fixture;
only the real argument-bundle cases below independently recompose Stage A.
"""
from __future__ import annotations

import copy
import json
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_render_recipe as recipe_module
from hero_engine.phase6_av_timeline import build
from hero_engine.phase6_av_two_column_adapter import compile_two_column_av_spec
from tests.test_phase6_av_render_recipe_real_visual import ROOT, ARGUMENTS, MASTER, pin
from tests.test_phase6_av_visual_recipe_adapter import real_bindings as hook_bindings
from tests.test_phase6_av_two_column_adapter import real_bindings, fixture_timeline, fixture_unit_boundary_timeline

CLEAN_PLATE_RECEIPT = "output/qa/phase6/diagnostics/two-column-clean-plate-v1-ef0d956239c512d0/receipt.json"


class TwoColumnRenderIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.body_bindings = real_bindings()
        cls.kwargs = {
            "master_receipt_binding": pin(MASTER), "render_blueprint_binding": None,
            "timeline_arguments_binding": pin(ARGUMENTS),
            "editorial_visual_bindings": hook_bindings(),
            "two_column_visual_bindings": cls.body_bindings,
        }
        cls.clean_body_bindings = {
            **cls.body_bindings, "clean_plate_receipt": pin(CLEAN_PLATE_RECEIPT),
        }
        cls.clean_kwargs = {**cls.kwargs, "two_column_visual_bindings": cls.clean_body_bindings}
        arguments = json.loads((ROOT / ARGUMENTS).read_bytes())["arguments"]
        with patch("subprocess.run", side_effect=AssertionError("no native effect")), \
                patch("subprocess.Popen", side_effect=AssertionError("no native effect")):
            cls.timeline = build(ROOT, **arguments)
            cls.recipe = recipe_module.compile_phase6_av_render_recipe(
                ROOT, cls.timeline, **cls.kwargs)
            cls.clean_recipe = recipe_module.compile_phase6_av_render_recipe(
                ROOT, cls.timeline, **cls.clean_kwargs)

    def test_real_recomposed_a_preserves_twelve_states_and_blocks_missing_events(self):
        value = self.recipe
        body = value["inputs"]["two_column_visual_preparation"]
        self.assertEqual("RECOMPOSED_INCOMPLETE", value["timeline"]["independent_arguments"]["status"])
        self.assertEqual("PREPARED_TWO_COLUMN_SPEC_BLOCKED", body["status"])
        self.assertEqual([f"take-{n:03d}" for n in range(12, 24)], [s["take_id"] for s in body["states"]])
        self.assertEqual(12, body["coverage"]["state_count"])
        self.assertEqual(0, body["coverage"]["resolved_state_count"])
        self.assertEqual(64, len(body["generated_files"]))
        self.assertEqual([], body["render_spans"])
        self.assertTrue(all(s["interval"] is None for s in body["states"]))
        self.assertTrue(all(s["event_binding_sha256"] is None for s in body["states"]))
        self.assertIn("STATE_SEMANTIC_EVENT_MISSING_OR_AMBIGUOUS:take-014", body["blockers"])
        self.assertIn("STATE_SEMANTIC_EVENT_MISSING_OR_AMBIGUOUS:take-016", body["blockers"])
        self.assertIn("TWO_COLUMN_CLEAN_PLATE_NOT_BOUND", body["blockers"])
        self.assertIn("MASTER_AUDIO_SAMPLE_COUNT_DIFFERS_FROM_TIMELINE", value["blockers"])
        self.assertIn("STAGE_A_TEMPORAL_TARGET_SCOPE_INCOMPLETE", value["blockers"])
        self.assertFalse(body["source_ready"])
        self.assertFalse(body["coverage"]["full_timeline_covered"])
        self.assertIsNone(value["command_graph"])
        self.assertEqual("BLOCKED_INCOMPLETE", value["status"])
        self.assertFalse(any(value["authority"].values()))
        self.assertFalse(any(body["authority"].values()))
        # Both adapters coexist without erasing the existing real hook fragment.
        self.assertEqual(150, value["inputs"]["visual_preparation"]["covered_frame_count"])
        self.assertEqual(9, len(value["implementation_bindings"]))
        self.assertEqual([
            "hero_engine/phase6_av_static_timeline.py",
            "hero_engine/phase6_av_static_sources.py",
        ], [binding["path"] for binding in value["implementation_bindings"][5:7]])
        for generated in body["generated_files"]:
            self.assertFalse((ROOT / generated["relative_path"]).exists())
        evidence = {
            "scope": "REAL_A_TO_C_TO_TWELVE_BODY_STATES_NO_RENDER",
            "recipe_id": value["recipe_id"],
            "recipe_canonical_sha256": recipe_module._canonical_sha(value),
            "recipe_version": value["recipe_version"], "schema_version": value["schema_version"],
            "arguments_binding": self.kwargs["timeline_arguments_binding"],
            "master_binding": self.kwargs["master_receipt_binding"],
            "body_external_bindings": self.body_bindings,
            "body_spec_id": body["visual_spec_id"],
            "body_spec_canonical_sha256": body["spec_canonical_sha256"],
            "timeline_contract_sha256": body["timeline_contract_sha256"],
            "body_coverage": body["coverage"], "generated_file_spec_count": len(body["generated_files"]),
            "body_dependency_bindings": body["dependency_bindings"],
            "body_blockers": body["blockers"], "recipe_blockers": value["blockers"],
            "implementation_bindings": value["implementation_bindings"],
            "native_call_count": 0, "generated_files_materialized": False,
            "authority": value["authority"], "technical_cost_brl": 0,
        }
        print("REAL_AV_BODY_INTEGRATION_EVIDENCE=" + json.dumps(evidence, sort_keys=True, ensure_ascii=False))

    def test_body_adapter_cannot_run_before_real_a_recomposition(self):
        kwargs = {**self.kwargs, "timeline_arguments_binding": None,
                  "editorial_visual_bindings": None}
        with patch("hero_engine.phase6_av_two_column_adapter.compile_two_column_av_spec") as adapter:
            with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "independent Stage-A recomposition first"):
                recipe_module.compile_phase6_av_render_recipe(ROOT, self.timeline, **kwargs)
            adapter.assert_not_called()

    def test_real_replay_rejects_changed_body_copy_without_effect(self):
        candidate = copy.deepcopy(self.recipe)
        candidate["inputs"]["two_column_visual_preparation"]["states"][0]["left_text"] = "UNSUPPORTED COPY"
        with patch("subprocess.run", side_effect=AssertionError("no native effect")), \
                patch("subprocess.Popen", side_effect=AssertionError("no native effect")):
            with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "independent recompilation"):
                recipe_module.verify_phase6_av_render_recipe(ROOT, candidate, self.timeline, **self.kwargs)

    def test_real_incomplete_a_reopens_clean_plate_without_effect_or_authority(self):
        with patch("subprocess.run", side_effect=AssertionError("no native effect")), \
                patch("subprocess.Popen", side_effect=AssertionError("no native effect")):
            replay = recipe_module.verify_phase6_av_render_recipe(
                ROOT, self.clean_recipe, self.timeline, **self.clean_kwargs)
        value = self.clean_recipe
        body = value["inputs"]["two_column_visual_preparation"]
        proof = body["clean_plate"]
        self.assertEqual("phase6-av-render-recipe-v15", value["recipe_version"])
        self.assertEqual("1.14.0", value["schema_version"])
        self.assertEqual("phase6-av-clean-plate-verifier-v1", proof["verifier_version"])
        self.assertEqual("SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED", proof["status"])
        self.assertEqual(1800, proof["capacity"]["frame_count"])
        self.assertEqual(60, proof["capacity"]["duration_seconds"])
        self.assertFalse(any(proof["authority"].values()))
        self.assertFalse(body["source_ready"])
        self.assertEqual([], body["render_spans"])
        self.assertIsNone(value["command_graph"])
        self.assertEqual("BLOCKED_INCOMPLETE", value["status"])
        self.assertIn("TWO_COLUMN_CLEAN_PLATE_BOUND_NOT_ADMITTED", value["blockers"])
        self.assertEqual(10, len(value["implementation_bindings"]))
        self.assertEqual([
            "hero_engine/phase6_av_static_timeline.py",
            "hero_engine/phase6_av_static_sources.py",
        ], [binding["path"] for binding in value["implementation_bindings"][5:7]])
        self.assertEqual("hero_engine/phase6_av_clean_plate.py", value["implementation_bindings"][-1]["path"])
        self.assertEqual(value, replay)
        print("REAL_AV_CLEAN_PLATE_INTEGRATION=" + json.dumps({
            "recipe_id": value["recipe_id"], "recipe_sha256": recipe_module._canonical_sha(value),
            "recipe_version": value["recipe_version"], "schema_version": value["schema_version"],
            "status": value["status"], "timeline": value["timeline"],
            "source_proof": {key: proof[key] for key in (
                "verifier_version", "status", "receipt_binding", "asset_binding", "lineage_id", "capacity")},
            "source_dependency_count": len(proof["dependency_bindings"]),
            "body_spec_id": body["visual_spec_id"], "coverage": body["coverage"],
            "body_source_ready": body["source_ready"], "blockers": value["blockers"],
            "command_graph": value["command_graph"], "authority": value["authority"],
            "implementation_bindings": value["implementation_bindings"],
            "technical_cost_brl": 0, "native_call_count": 0,
        }, ensure_ascii=False, sort_keys=True))

    def test_clean_plate_candidate_and_provider_tamper_fail_closed(self):
        for mutate in (
            lambda candidate: candidate["inputs"]["two_column_visual_preparation"]["clean_plate"]["asset_binding"].update(sha256="sha256:" + "0" * 64),
            lambda candidate: candidate["inputs"]["two_column_visual_preparation"]["clean_plate"]["authority"].update(render_authorized=True),
        ):
            candidate = copy.deepcopy(self.clean_recipe)
            mutate(candidate)
            with patch.object(recipe_module, "compile_phase6_av_render_recipe",
                              return_value=copy.deepcopy(self.clean_recipe)):
                with self.assertRaises((recipe_module.AVRenderRecipeError, ValueError)):
                    recipe_module.verify_phase6_av_render_recipe(
                        ROOT, candidate, self.timeline, **self.clean_kwargs)
        proof = copy.deepcopy(self.clean_recipe["inputs"]["two_column_visual_preparation"]["clean_plate"])
        proof["capacity"]["frame_count"] = 1800.0
        with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "identity, capacity"):
            recipe_module._clean_plate_proof(ROOT, proof, self.timeline)
        proof = copy.deepcopy(self.clean_recipe["inputs"]["two_column_visual_preparation"]["clean_plate"])
        proof["asset_binding"] = copy.deepcopy(proof["receipt_binding"])
        with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "receipt, asset, source or verifier"):
            recipe_module._clean_plate_proof(ROOT, proof, self.timeline)
        with patch.object(recipe_module, "_resident_binding", side_effect=ValueError("OFFLINE")):
            with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "linked or nonresident"):
                recipe_module._clean_plate_binding(
                    ROOT, pin(CLEAN_PLATE_RECEIPT), "clean-plate receipt")

    def test_fixture_populated_span_only_validates_c_serializer_not_real_a(self):
        fixture = fixture_unit_boundary_timeline()
        # Deliberately test the private conversion boundary, NOT public A verification.
        prepared = recipe_module._two_column_visual_preparation(
            ROOT, fixture, {"independent_arguments": {"status": "FIXTURE_BOUNDARY_ONLY"}}, self.body_bindings)
        value = copy.deepcopy(self.recipe)
        value["inputs"]["two_column_visual_preparation"] = prepared
        recipe_module._validate_output(value)
        self.assertEqual(1, len(prepared["render_spans"]))
        self.assertFalse(prepared["render_spans"][0]["source_ready"])
        self.assertFalse(prepared["render_spans"][0]["render_authorized"])
        self.assertFalse(prepared["render_spans"][0]["source_technically_verified"])
        self.assertIsNone(prepared["render_spans"][0]["source_evidence_binding"])
        self.assertIsNone(prepared["clean_plate"])
        self.assertIsNone(value["command_graph"])
        prepared["render_spans"][0]["source_ready"] = True
        with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "schema failed"):
            recipe_module._validate_output(value)

    def test_provider_flags_cannot_claim_source_or_render_authority(self):
        fixture = fixture_timeline(temporal_events=True)
        spec = compile_two_column_av_spec(ROOT, timeline=fixture, bindings=self.body_bindings)
        for section, key in (("authority", "render_authorized"), ("span", "source_ready")):
            forged = copy.deepcopy(spec)
            target = forged["authority"] if section == "authority" else forged["render_spans"][0]
            target[key] = True
            with patch("hero_engine.phase6_av_two_column_adapter.compile_two_column_av_spec", return_value=forged):
                with self.assertRaisesRegex(recipe_module.AVRenderRecipeError, "unsupported source or authority"):
                    recipe_module._two_column_visual_preparation(
                        ROOT, fixture, {"independent_arguments": {"status": "FIXTURE_BOUNDARY_ONLY"}}, self.body_bindings)


if __name__ == "__main__":
    unittest.main()
