"""Synthetic cache integrity tests: no inference, decoding, network or production."""

import copy
import json
import os
import stat
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from hero_engine.mining import pipeline as mining


class MiningCacheIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.output = self.root / "output/mining/phase2"
        self.source = self.root / "source"
        self.source.mkdir()
        self.video_id = mining.FIXTURE_IDS[0]
        for suffix in (".mp4", ".info.json", ".jpg"):
            (self.source / (self.video_id + suffix)).write_bytes(b"synthetic input, never decoded")
        self.source_hash = mining.file_sha256(self.source / (self.video_id + ".mp4"))
        self.job = self.output / self.video_id / ("a" * 64)
        self.job.mkdir(parents=True)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        for key, value in (("ROOT", self.root), ("OUTPUT_ROOT", self.output), ("SOURCE_ROOT", self.source)):
            self.stack.enter_context(patch.object(mining, key, value))
        self.manifest = self.make_fixture()

    def write(self, name, data):
        path = self.job / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data), encoding="utf-8")

    def make_fixture(self, version="miner-local-0.2.0"):
        takes = []
        duration = 40000
        ocr_count = 1
        for index, (start, end) in enumerate(((0, 10000), (10000, 30000), (30000, 40000)), 1):
            take_id = f"take-{index:03d}"
            frames = [f"keyframes/{take_id}-{label}.jpg" for label in ("start", "mid", "end")]
            for name in frames:
                self.write(name, {"synthetic": "no real image"})
            if version == "miner-local-0.1.0":
                scans = [f"ocr/{take_id}.json"]
            else:
                labels = ("start", "mid", "end") if start < 8000 or end > duration - 8000 else ("mid",)
                scans = [f"ocr/{take_id}-{label}.json" for label in labels]
            for name in scans:
                self.write(name, {"synthetic": "no OCR"})
            ocr_count += len(scans)
            takes.append({"take_id": take_id, "start_ms": start, "end_ms": end,
                          "duration_ms": end - start,
                          "keyframes": [(self.job / name).relative_to(self.root).as_posix() for name in frames]})
        self.write("take_candidates.json", {"duration_ms": duration, "takes": takes, "take_count": len(takes)})
        resources = {"take_count": len(takes), "keyframe_count": 3 * len(takes),
                     "ocr_image_count": ocr_count, "prior_failed_attempt_count": 0}
        self.write("resource_usage.json", resources)
        analysis = {"source": {"video_id": self.video_id, "content_hash": self.source_hash, "duration_ms": duration}}
        self.write("video_mining.json", analysis)
        self.write("scene_boundaries.json", {"source_hash": self.source_hash})
        self.write("transcript.raw.json", {"video_id": self.video_id})
        for name in ("events.jsonl", "ocr_manifest.json", "ocr/thumbnail.json"):
            self.write(name, {"synthetic": True})
        manifest = {"status": "COMPLETE", "video_id": self.video_id, "job_key": self.job.name,
                    "source_hash": self.source_hash, "pipeline_version": version,
                    "parameters": mining.MinerConfig(pipeline_version=version).normalized(),
                    "semantic_hash": mining.canonical_hash(analysis), "resources": resources}
        self.reinventory(manifest)
        return manifest

    def reinventory(self, manifest=None):
        manifest = manifest if manifest is not None else self.manifest
        manifest["artifacts"] = mining._artifact_inventory(self.job)
        manifest["artifact_count"] = len(manifest["artifacts"])
        manifest["artifact_bytes"] = sum(item["bytes"] for item in manifest["artifacts"])
        self.write("run_manifest.json", manifest)

    def store(self):
        self.write("run_manifest.json", self.manifest)

    def snapshot(self):
        return {p.relative_to(self.job).as_posix(): p.read_bytes() for p in self.job.rglob("*") if p.is_file()}

    def guarded_miner(self):
        # All real providers are forbidden even if the entry-point guard regresses.
        for adapter in ("MediaProbeAdapter", "SceneDetectionAdapter", "FrameExtractionAdapter", "TranscriptAdapter", "OcrAdapter"):
            stub = self.stack.enter_context(patch.object(mining, adapter))
            for method in ("inspect", "detect", "extract", "transcribe", "scan"):
                getattr(stub.return_value, method).side_effect = AssertionError("provider must not run")
        self.stack.enter_context(patch.object(mining, "fixture_catalog", return_value={self.video_id: {"content_sha256": self.source_hash}}))
        self.stack.enter_context(patch.object(mining, "job_key_for", return_value=self.job.name))
        self.stack.enter_context(patch.object(mining, "implementation_hash", return_value="b" * 64))
        self.stack.enter_context(patch.object(mining, "write_json", side_effect=AssertionError("writer must not run")))
        self.stack.enter_context(patch.object(mining, "tool_versions", side_effect=AssertionError("tools must not run")))
        return mining.MiningPipeline(progress=lambda _: None)

    def test_complete_cache_and_mine_hit_are_read_only_without_providers(self):
        before = self.snapshot()
        self.assertTrue(mining._cache_valid(self.job, source_hash=self.source_hash))
        result = self.guarded_miner().mine(self.video_id)
        self.assertTrue(result["cache_hit"])
        self.assertEqual(result["semantic_hash"], self.manifest["semantic_hash"])
        self.assertEqual(before, self.snapshot())

    def test_missing_empty_or_wrong_inventory_is_not_complete(self):
        original = copy.deepcopy(self.manifest)
        for value in (None, [], {}, "", [{"path": "x"}]):
            with self.subTest(value=value):
                self.manifest = copy.deepcopy(original)
                if value is None:
                    self.manifest.pop("artifacts")
                else:
                    self.manifest["artifacts"] = value
                self.store()
                self.assertFalse(mining._cache_valid(self.job))

    def test_invalid_existing_job_is_preserved_before_any_write_or_provider(self):
        self.manifest["artifacts"] = []
        self.store()
        before = self.snapshot()
        with self.assertRaisesRegex(mining.CacheIntegrityError, "CACHE_INTEGRITY_BLOCKED"):
            self.guarded_miner().mine(self.video_id)
        self.assertEqual(before, self.snapshot())

    def test_donor_reuse_requires_complete_valid_inventory(self):
        pipeline = self.guarded_miner()
        new_job = self.output / self.video_id / ("c" * 64)
        before = self.snapshot()
        self.assertEqual(pipeline._compatible_donor(self.video_id, self.source_hash, new_job), self.job)
        self.assertIsNone(pipeline._compatible_donor(self.video_id, "f" * 64, new_job))
        self.assertEqual(before, self.snapshot())
        self.manifest["artifacts"] = []
        self.store()
        before = self.snapshot()
        self.assertIsNone(pipeline._compatible_donor(self.video_id, self.source_hash, new_job))
        self.assertEqual(before, self.snapshot())
        self.assertFalse(new_job.exists())

    def test_failed_or_running_jobs_are_preserved_not_implicitly_resumed(self):
        pipeline = self.guarded_miner()
        for status in ("FAILED", "RUNNING"):
            with self.subTest(status=status):
                self.manifest["status"] = status
                self.store()
                before = self.snapshot()
                with self.assertRaisesRegex(mining.CacheRecoveryProofRequired, "CACHE_RECOVERY_PROOF_REQUIRED"):
                    pipeline.mine(self.video_id)
                self.assertEqual(before, self.snapshot())

    def test_missing_or_malformed_manifest_preserves_existing_job(self):
        pipeline = self.guarded_miner()
        for payload in (None, b'{"status": "COMPLETE",', b'{"status":"COMPLETE","status":"COMPLETE"}', b'{"x":NaN}'):
            with self.subTest(payload=payload):
                path = self.job / "run_manifest.json"
                if payload is None:
                    path.unlink()
                else:
                    path.write_bytes(payload)
                before = self.snapshot()
                self.assertFalse(mining._cache_valid(self.job))
                with self.assertRaises(mining.CacheIntegrityError) as raised:
                    pipeline.mine(self.video_id)
                expected = "CACHE_RECOVERY_PROOF_REQUIRED" if payload is None else "CACHE_INTEGRITY_BLOCKED"
                self.assertEqual(raised.exception.code, expected)
                self.assertEqual(before, self.snapshot())

    def test_duplicate_extra_metadata_and_aggregate_mismatches_fail(self):
        original = copy.deepcopy(self.manifest)
        mutations = (
            lambda m: m["artifacts"].append(copy.deepcopy(m["artifacts"][0])),
            lambda m: m["artifacts"][0].update(extra="forbidden"),
            lambda m: m.update(artifact_count=m["artifact_count"] - 1),
            lambda m: m.update(artifact_count=True),
            lambda m: m.update(artifact_bytes=m["artifact_bytes"] + 1),
            lambda m: m["artifacts"][0].update(bytes=True),
            lambda m: m["artifacts"][0].update(bytes=0),
            lambda m: m["artifacts"][0].update(bytes=m["artifacts"][0]["bytes"] + 1),
            lambda m: m["artifacts"][0].update(sha256="f" * 64),
        )
        for index, mutate in enumerate(mutations):
            with self.subTest(case=index):
                self.manifest = copy.deepcopy(original)
                mutate(self.manifest)
                self.store()
                self.assertFalse(mining._cache_valid(self.job))

    def test_traversal_outside_absolute_alias_and_self_inventory_fail(self):
        original = copy.deepcopy(self.manifest)
        prefix = self.job.relative_to(self.root).as_posix() + "/"
        for name in ("source/outside.json", str(self.source / "outside.json"), prefix + "../outside.json",
                     prefix + "keyframes//take-001-mid.jpg", prefix + "./events.jsonl",
                     prefix + "KEYFRAMES/take-001-mid.jpg", prefix + "keyframes\\take-001-mid.jpg",
                     prefix + "run_manifest.json", prefix + "events.jsonl:stream"):
            with self.subTest(path=name):
                self.manifest = copy.deepcopy(original)
                self.manifest["artifacts"][0]["path"] = name
                self.store()
                self.assertFalse(mining._cache_valid(self.job))

    def test_unlisted_file_and_listed_unexpected_file_fail(self):
        self.write("extra.json", {"unexpected": True})
        self.assertFalse(mining._cache_valid(self.job))
        self.reinventory()
        self.assertFalse(mining._cache_valid(self.job))

    def test_every_required_artifact_is_required_even_after_reinventory(self):
        original = copy.deepcopy(self.manifest)
        for item in original["artifacts"]:
            path = self.root / item["path"]
            with self.subTest(name=path.name):
                contents = path.read_bytes()
                path.unlink()
                self.reinventory()
                self.assertFalse(mining._cache_valid(self.job))
                path.write_bytes(contents)
        self.manifest = original
        self.store()
        self.assertTrue(mining._cache_valid(self.job))

    def test_same_size_hash_tampering_fails(self):
        path = self.job / "keyframes/take-001-mid.jpg"
        contents = path.read_bytes()
        path.write_bytes(b"X" + contents[1:])
        self.assertFalse(mining._cache_valid(self.job))

    def test_hardlinked_artifact_fails_without_following_or_altering_link(self):
        path = self.job / "keyframes/take-001-mid.jpg"
        contents = path.read_bytes()
        outside = self.root / "outside.jpg"
        outside.write_bytes(contents)
        path.unlink()
        os.link(outside, path)
        self.assertFalse(mining._cache_valid(self.job))
        self.assertEqual(outside.read_bytes(), contents)

    def test_reparse_offline_and_directory_symlink_are_rejected_by_stat_guard(self):
        for attributes, mode, directory in ((0x400, stat.S_IFREG, False), (0x1000, stat.S_IFREG, False),
                                             (0x40000, stat.S_IFREG, False), (0x400000, stat.S_IFREG, False),
                                             (0x400, stat.S_IFDIR, True), (0, stat.S_IFLNK, True)):
            with self.subTest(attributes=attributes, mode=mode):
                info = SimpleNamespace(st_mode=mode, st_nlink=1, st_file_attributes=attributes)
                with patch.object(Path, "lstat", return_value=info):
                    with self.assertRaises(ValueError):
                        mining._cache_unlinked(self.job, directory=directory)

    def test_recovery_classifier_does_not_read_nonresident_or_linked_manifest(self):
        for flag in (0x400, 0x1000, 0x40000, 0x400000):
            with self.subTest(flag=flag):
                info = SimpleNamespace(st_mode=stat.S_IFREG, st_nlink=1, st_file_attributes=flag)
                original = Path.lstat
                def flagged_manifest(path):
                    return info if path == self.job / "run_manifest.json" else original(path)
                with patch.object(Path, "lstat", flagged_manifest):
                    with patch.object(mining, "_cache_json", side_effect=AssertionError("must not read")):
                        self.assertEqual(mining._existing_cache_error(self.job).code, "CACHE_INTEGRITY_BLOCKED")

    def test_altered_source_and_job_identity_fail(self):
        self.assertFalse(mining._cache_valid(self.job, source_hash="f" * 64))
        original = copy.deepcopy(self.manifest)
        for key, value in (("video_id", mining.FIXTURE_IDS[1]), ("job_key", "b" * 64),
                           ("source_hash", "f" * 64), ("pipeline_version", "unknown"), ("semantic_hash", "f" * 64)):
            with self.subTest(key=key):
                self.manifest = copy.deepcopy(original)
                self.manifest[key] = value
                self.store()
                self.assertFalse(mining._cache_valid(self.job))

    def test_take_count_gap_frame_binding_and_resource_forgery_fail(self):
        path = self.job / "take_candidates.json"
        original = json.loads(path.read_text(encoding="utf-8"))
        for mutate in (lambda t: t.update(take_count=2), lambda t: t["takes"][1].update(start_ms=10001),
                       lambda t: t["takes"][0].update(keyframes=[]), lambda t: t.update(duration_ms=40001)):
            candidate = copy.deepcopy(original)
            mutate(candidate)
            self.write("take_candidates.json", candidate)
            self.reinventory()
            self.assertFalse(mining._cache_valid(self.job))
        self.write("take_candidates.json", original)
        resources = copy.deepcopy(self.manifest["resources"])
        resources["keyframe_count"] = 3
        self.manifest["resources"] = resources
        self.write("resource_usage.json", resources)
        self.reinventory()
        self.assertFalse(mining._cache_valid(self.job))

    def test_legacy_midframe_recipe_is_valid_without_rewriting_history(self):
        # Replace synthetic v0.2 OCR files only; no historical project file changes.
        for path in (self.job / "ocr").iterdir():
            path.unlink()
        self.manifest = self.make_fixture("miner-local-0.1.0")
        before = self.snapshot()
        self.assertTrue(mining._cache_valid(self.job))
        self.assertEqual(before, self.snapshot())

    def test_failed_attempt_history_requires_exact_identity_and_count(self):
        failure = {key: self.manifest[key] for key in ("video_id", "job_key", "source_hash", "pipeline_version")}
        failure.update(status="FAILED", failed_at="2026-09-02T16:02:37+00:00")
        name = "attempts/failure-2026-09-02T16-02-37+00-00.json"
        self.write(name, failure)
        self.manifest["resources"]["prior_failed_attempt_count"] = 1
        self.write("resource_usage.json", self.manifest["resources"])
        self.reinventory()
        self.assertTrue(mining._cache_valid(self.job))
        failure["job_key"] = "f" * 64
        self.write(name, failure)
        self.reinventory()
        self.assertFalse(mining._cache_valid(self.job))


if __name__ == "__main__":
    unittest.main()
