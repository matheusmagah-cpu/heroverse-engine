import json
import tempfile
import unittest
from pathlib import Path

from hero_engine import phase5_integrity_maintenance as maintenance
from hero_engine import phase5_integrity_successor_consumer as consumer


class IntegritySuccessorConsumerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); self.package = self.root / maintenance.PACKAGE
        self.package.mkdir(parents=True)
        (self.package / "asset_manifest.json").write_text('{"current":true}\n', encoding="utf-8")
        (self.package / maintenance.HISTORICAL_NAME).write_text(json.dumps({"algorithm":"SHA-256", "entries":[{"artifact":"asset_manifest.json","sha256":"0" * 64,"bytes":1}]}), encoding="utf-8")
        stage = self.root / "stage"; staged = maintenance.stage_successor(self.root, stage=stage)
        (self.package / consumer.SUCCESSOR_NAME).write_bytes((stage / consumer.SUCCESSOR_NAME).read_bytes())
        self.staged = staged

    def test_current_consumer_reads_only_committed_successor_and_has_no_operational_authority(self):
        result = consumer.read_current_integrity_successor(self.root)
        self.assertEqual(self.staged["successor_sha256"], result["successor_sha256"])
        self.assertFalse(any(result["authority"].values()))

    def test_tampered_history_or_resident_bytes_are_rejected_without_fallback_to_historical_manifest(self):
        (self.package / "asset_manifest.json").write_text('{"current":false}\n', encoding="utf-8")
        with self.assertRaises(consumer.IntegritySuccessorConsumerError):
            consumer.read_current_integrity_successor(self.root)
        self.assertTrue((self.package / maintenance.HISTORICAL_NAME).is_file())
