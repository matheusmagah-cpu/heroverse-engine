"""Pure V3-to-A11 joins using explicit synthetic composition of pinned metadata.

No source inspection is claimed by these fixtures; real V3 integration is in
test_phase6_av_static_asset_uses_v3. No media/rights evaluator runs here.
"""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_asset_use_binding_v2 as joiner
from hero_engine import phase6_av_static_asset_uses_v3 as uses
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]


class AssetUseBindingV2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        reader = uses.sources._Reader(ROOT)
        projection = uses._json(reader, {"path": uses.case.PROJECTION_BINDING["path"], "sha256": uses.case.PROJECTION_BINDING["sha256"][7:]})
        old = uses._json(reader, uses.previous.INSPECTION)
        registry = uses._json(reader, uses.REGISTRATION)
        cls.literal = {"fixture_only": True, "adapter_version": uses.case.VERSION, "rows": projection["effective_rows"],
            "prior_amendment_inspection": {"fixture_only": True, "projection_binding": copy.deepcopy(uses.case.legacy.PROJECTION_BINDING)}}
        states = {state["state_id"]: (row, state) for row in cls.literal["rows"] for state in row["states"]}
        cls.fixture = copy.deepcopy(old)
        cls.fixture.update(version=uses.VERSION, fixture_only=True, source_count=27, use_count=29,
                           unique_png_content_count=26, lineage_count=3)
        for item in registry["request"]["states"]:
            row, state = states[item["state_id"]]
            cls.fixture["uses"].append({"use_id": "static-use-" + item["state_id"], "visual_state_id": item["state_id"],
                "unit_id": row["unit_id"], "source_id": item["asset_id"], "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"]),
                "entry": copy.deepcopy(state["entry"]), "source_provenance_unit_id": row["unit_id"],
                "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
        cls.fixture["remaining_unbound_visual_state_ids"] = sorted(set(states) - set(joiner.COVERED))
        cls.fixture["visual_amendment_evidence"] = {"adapter_version": uses.case.VERSION,
            "inspection_sha256": joiner.canonical_sha(cls.literal), "effective_rows_sha256": joiner.canonical_sha(cls.literal["rows"]),
            "changed_state_count": 2, "unmodified_state_count": 98,
            "prior_amendment_inspection_sha256": joiner.canonical_sha(cls.literal["prior_amendment_inspection"]),
            "source_ready": False, "global_schedule_created": False}

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="joiner-v2-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.assertFalse(self.root.is_relative_to(ROOT))
        path = self.root / "fixture-input.json"
        raw = uses.sources._canonical({"fixture_only": True, "not_an_operational_manifest": True})
        path.write_bytes(raw)
        self.binding = {"path": path.relative_to(self.root).as_posix(), "sha256": "sha256:" + uses.sources._sha(raw)}
        self.proof = copy.deepcopy(self.fixture)
        self.proof["input_binding"] = {"path": self.binding["path"], "sha256": self.binding["sha256"][7:]}
        self.proof["dependency_bindings"] = [{"path": str(path), "sha256": self.binding["sha256"][7:], "size_bytes": len(raw)}]

    def test_pure_join_has_29_covered_71_pending_three_lineages_and_false_authority(self):
        before = copy.deepcopy(self.proof)
        result = joiner.join(self.proof, self.binding, self.literal)
        self.assertEqual((result["source_count"], result["use_count"], result["unique_png_content_count"], result["lineage_count"]), (27, 29, 26, 3))
        self.assertEqual(result["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(result["remaining_unbound_visual_state_ids"]), 71)
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertFalse(result["source_ready"])
        self.assertFalse(result["global_schedule_created"])
        self.assertFalse(result["calibrated_timing_available"])
        self.assertEqual(self.proof, before)

    def test_old_adapter_old_proof_or_case_evidence_cannot_enter_new_joiner(self):
        for literal in (None, {**self.literal, "adapter_version": "phase6-av-visual-amendment-v1"}):
            with self.assertRaisesRegex(ValueError, "independently amended"):
                joiner.join(self.proof, self.binding, literal)
        for mutate in (lambda p: p.update(version="phase6-av-static-asset-uses-v2"),
                       lambda p: p["visual_amendment_evidence"].update(changed_state_count=12),
                       lambda p: p["visual_amendment_evidence"].update(prior_amendment_inspection_sha256="sha256:" + "0" * 64)):
            proof = copy.deepcopy(self.proof)
            mutate(proof)
            with self.assertRaises(ValueError):
                joiner.join(proof, self.binding, self.literal)

    def test_numeric_types_and_rights_or_schedule_authority_cannot_be_promoted(self):
        for key, value in (("source_count", 27.0), ("use_count", 100), ("lineage_count", 4),
                           ("source_ready", True), ("global_schedule_created", True),
                           ("calibrated_timing_available", True), ("technical_cost_brl", False),
                           ("authority", {**joiner.AUTHORITY, "publication": True})):
            proof = copy.deepcopy(self.proof)
            proof[key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "scope or authority"):
                joiner.join(proof, self.binding, self.literal)

    def test_question_lexical_range_unit_entry_case_and_old_hold_are_preserved(self):
        for kind in ("question_copy", "question_onset", "question_float", "unit", "old_hold"):
            proof = copy.deepcopy(self.proof)
            target = next(row for row in proof["uses"] if row["visual_state_id"] == ("visual-u016-s01" if kind == "old_hold" else "visual-u020-s01"))
            if kind == "question_copy": target["literal_copy"] = ["Fully false?"]
            elif kind == "question_onset": target["entry"]["kind"] = "UNIT_ENTRY"
            elif kind == "question_float": target["entry"]["char_start"] = 18.0
            elif kind == "unit": target["unit_id"] = "narration-unit-021"
            else: target["entry"]["previous_state_id"] = "visual-u017-s00"
            with self.subTest(kind=kind), self.assertRaisesRegex(ValueError, "entry, copy or unit"):
                joiner.join(proof, self.binding, self.literal)

    def test_coverage_cannot_lose_unbound_states_duplicate_or_add_unknown_use(self):
        for mutate in (lambda p: p["remaining_unbound_visual_state_ids"].pop(),
                       lambda p: p["uses"].pop(), lambda p: p["uses"].append(copy.deepcopy(p["uses"][-1])),
                       lambda p: p["uses"][-1].update(visual_state_id="visual-u051-s00")):
            proof = copy.deepcopy(self.proof)
            mutate(proof)
            with self.assertRaises(ValueError):
                joiner.join(proof, self.binding, self.literal)

    def test_pinned_binding_and_fresh_sink_fail_before_inspector(self):
        invalid = [{**self.binding, "sha256": self.binding["sha256"][7:]}, {**self.binding, "path": "../input.json"},
                   {**self.binding, "path": "C:/Windows/input.json"}, {**self.binding, "extra": True}]
        with patch.object(uses, "inspect_static_asset_uses", side_effect=AssertionError("preflight before inspector")) as inspect:
            for binding in invalid:
                with self.assertRaises(ValueError):
                    joiner.read_asset_use_binding(Reader(self.root), binding, self.literal, proof_sink=[])
            for sink in (None, {}, [self.proof]):
                with self.assertRaises(ValueError):
                    joiner.read_asset_use_binding(Reader(self.root), self.binding, self.literal, proof_sink=sink)
        inspect.assert_not_called()

    def test_read_orchestration_uses_v3_inspector_and_v3_model_safe_sink(self):
        reader, sink = Reader(self.root), []
        with patch.object(uses, "inspect_static_asset_uses", return_value=self.proof) as inspect, \
             patch.object(uses, "recheck_asset_use_dependencies") as recheck, \
             patch.object(uses.sources, "recheck_static_dependencies", side_effect=AssertionError("legacy 16MiB sink forbidden")):
            result = joiner.read_asset_use_binding(reader, self.binding, self.literal, proof_sink=sink)
        inspect.assert_called_once_with(self.root, binding=self.proof["input_binding"])
        recheck.assert_called_once_with(self.root, [self.proof])
        self.assertEqual(sink, [self.proof])
        self.assertEqual(result["use_count"], 29)

    def test_final_dependency_failure_leaves_empty_sink_without_retry(self):
        sink = []
        with patch.object(uses, "inspect_static_asset_uses", return_value=self.proof) as inspect, \
             patch.object(uses, "recheck_asset_use_dependencies", side_effect=ValueError("fixture model or old-cache drift")):
            with self.assertRaisesRegex(ValueError, "old-cache drift"):
                joiner.read_asset_use_binding(Reader(self.root), self.binding, self.literal, proof_sink=sink)
        self.assertEqual(inspect.call_count, 1)
        self.assertEqual(sink, [])


if __name__ == "__main__":
    unittest.main()
