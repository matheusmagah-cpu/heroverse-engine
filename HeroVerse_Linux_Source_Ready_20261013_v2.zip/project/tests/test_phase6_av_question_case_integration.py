"""Legacy A11 case compatibility in A12; one positive metadata build.

CORE and PCM seams reuse the externally pinned real A10 units/fragment map.
The V5 case reader and V3 joiner/final dependency sinks are real. The V3
inspector alone returns the externally pinned completed inspection as an
explicit fixture. This does not claim a new source batch or audio approval.
The new body-case trio remains absent; the 29-use V5 contract stays unchanged.
"""
import copy
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_asset_use_binding_v2 as joiner
from hero_engine import phase6_av_static_asset_uses_v3 as uses
from hero_engine import phase6_av_question_case_amendment as case
from hero_engine import phase6_av_question_sources as question
from hero_engine import phase6_av_static_sources as sources
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]
A10 = "output/operations/phase6/av-admission/timelines/phase6-av-timeline-f4be1a123a552503913cf306.json"
A10_SHA = "42eaa6f7e1b5b74f62693cbee25df4d6c95831a9e77eae384163b4ca23de488c"
BASE = "output/operations/phase6/av-admission/static-asset-uses-v3"
USE_BINDING = {"path": BASE + "/input.json", "sha256": "sha256:3e74c984f2f76fb8d74071b0879f34fa71cd1aaa59f2ff3f84b1cf5b8e792ef9"}
OUTPUT_PINS = {
    "input.json": USE_BINDING["sha256"][7:],
    "inspection.json": "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30",
    "receipt.json": "984b972d3454e8a14c8fbfc218564cda2a1eaf7478da1ea9cf89e6b2da1e0ddd",
    "claim.json": "30da0cda71407f3e6afc5e16a6f26127d6e6d2b697b75da47a5d27b1b03333f7",
}
OLD_SCHEMA = "output/qa/phase6/diagnostics/test-questions-v1/before-A11-integration/schemas/phase6_av_timeline.schema.json"
PINS = {
    "hero_engine/phase6_av_timeline.py": "a113489a43a26d50f266808fb3bb06d6fa1de6092364c7d7aaedbbcb8bc5f5dd",
    "schemas/phase6_av_timeline.schema.json": "3095b5f5b0daa68341ed565c6457d3eb96fb1cb356459ae3af1ebfaec624decb",
    "hero_engine/phase6_av_question_case_amendment.py": "2da7b523f2a3ad6b8c70727791649177c77aa4f2dd4434393d98bf62103b1509",
    "schemas/phase6_av_question_case_amendment.schema.json": "2fc8f9aefdcd8d30ddb6e6e0b90919e3199268c67931b791cfd6497dad8f8004",
    "hero_engine/phase6_av_asset_use_binding_v2.py": "80c7892fa7cde1492f1955a3691c99a202ecbffe8334a061a805d60b3221da1e",
    "hero_engine/phase6_av_static_asset_uses_v3.py": "4914222e71089357d557d6e1a64cb3f834d33b5971b6d4cb6bee8a72bfea7886",
    "schemas/phase6_av_static_asset_uses_v3.schema.json": "125478ba83bc9a8df6f75c932af4893563ddf5f5c9c23ae3b44deb0cb1a21bab",
    "hero_engine/phase6_av_question_sources.py": "3ed0553ab253e81458f786aa9ba15862ef5a191157bcf9bfc6ebcc0922953ad2",
    OLD_SCHEMA: "8a68d0b80430e637cc1f4b6d76fb3fedb05ed483a59f3fb2a2820c1ab678d866",
    A10: A10_SHA,
    **{BASE + "/" + name: digest for name, digest in OUTPUT_PINS.items()},
}


class QuestionCaseA11IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = {**PINS, Path(__file__).relative_to(ROOT).as_posix(): sources._sha(Path(__file__).read_bytes())}
        cls.assert_sources_unchanged()
        reader = Reader(ROOT)
        cls.old = sources._json(reader.read(A10, "sha256:" + A10_SHA))
        outputs = {name: sources._json(reader.read(BASE + "/" + name, "sha256:" + digest)) for name, digest in OUTPUT_PINS.items()}
        cls.source_proof, cls.registration = outputs["inspection.json"], outputs["receipt.json"]
        expected_receipt = {"kind": "PHASE6_STATIC_ASSET_USES_V3_MATERIALIZATION",
            "version": "phase6-static-asset-uses-v3-materialization-v1",
            "status": "VERIFIED_PARTIAL_UNTIMED_BINDINGS_NOT_PRODUCTION_READY",
            "source_count": 27, "use_count": 29, "unique_png_content_count": 26, "lineage_count": 3,
            "remaining_unbound_visual_state_count": 71, "authority": uses.AUTHORITY, "technical_cost_brl": 0}
        sources._same({key: cls.registration[key] for key in expected_receipt}, expected_receipt, "completed V3 fixture scope differs")
        for field, name in (("input_binding", "input.json"), ("inspection_binding", "inspection.json"), ("claim_binding", "claim.json")):
            sources._same(cls.registration[field], {"path": BASE + "/" + name, "sha256": OUTPUT_PINS[name]}, "external V3 fixture chain differs")
        sources._same(cls.source_proof["input_binding"], {"path": USE_BINDING["path"], "sha256": USE_BINDING["sha256"][7:]}, "fixture input differs")
        cls.arguments = copy.deepcopy(cls.old["inputs"])
        cls.arguments["source_bindings"]["question_case_amendment"] = copy.deepcopy(case.PROJECTION_BINDING)
        cls.arguments["source_bindings"]["literal_asset_uses"] = copy.deepcopy(USE_BINDING)
        cls.data = {key: reader.load(bound) for key, bound in cls.old["inputs"]["source_bindings"].items() if key in av.CORE}
        cls.schema = sources._json(reader.read(av.SCHEMA, "sha256:" + PINS[av.SCHEMA]))
        cls.current = cls.build_fixture()  # Exactly one positive A12 metadata snapshot for every assertion below.

    @classmethod
    def assert_sources_unchanged(cls):
        for name, digest in cls.snapshot.items():
            if sources._sha((ROOT / name).read_bytes()) != digest:
                raise AssertionError("frozen A12 compatibility focal input changed: " + name)

    @classmethod
    def tearDownClass(cls):
        cls.assert_sources_unchanged()

    @classmethod
    def build_fixture(cls, *, case_fixture=None, sources_callback=None):
        real_case = case.read_amended_visual_intent
        def capture(*args, **kwargs):
            if case_fixture is not None:
                return copy.deepcopy(case_fixture)  # Explicit negative-only cached seam.
            result = real_case(*args, **kwargs)
            cls.literal = copy.deepcopy(result)
            return result
        with mock.patch.object(av, "_sources", side_effect=sources_callback or (lambda *_: copy.deepcopy(cls.data))), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(cls.old["units"]), copy.deepcopy(cls.old["narration_fragment_map"]))), \
             mock.patch.object(case, "read_amended_visual_intent", side_effect=capture) as case_reader, \
             mock.patch.object(uses, "inspect_static_asset_uses", return_value=copy.deepcopy(cls.source_proof)) as inspector, \
             mock.patch.object(uses, "recheck_asset_use_dependencies", wraps=uses.recheck_asset_use_dependencies) as sink, \
             mock.patch.object(case, "recheck_question_replay", wraps=case.recheck_question_replay) as case_sink, \
             mock.patch.object(question, "inspect_question_sources", side_effect=AssertionError("no repeated question source batch")), \
             mock.patch.object(uses.previous.previous, "inspect_static_asset_uses", side_effect=AssertionError("no old inspector/PNG decode")), \
             mock.patch.object(av, "inspect_pcm", side_effect=AssertionError("no PCM/ASR inspection")), \
             mock.patch.object(sources, "_png", side_effect=AssertionError("no PNG decode")), \
             mock.patch.object(sources.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no PNG decoder")), \
             mock.patch("PIL.Image.open", side_effect=AssertionError("no image decoding")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no process/inference")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("no network")), \
             mock.patch.object(Path, "write_bytes", side_effect=AssertionError("no artifact write")):
            result = av.build(ROOT, **copy.deepcopy(cls.arguments))
            if case_fixture is None:
                cls.case_read_calls, cls.inspector_fixture_calls = case_reader.call_count, inspector.call_count
                cls.v3_sink_calls, cls.case_sink_calls = sink.call_count, case_sink.call_count
            return result

    def test_real_case_reader_preserves_historical_v2_v3_and_only_two_states_three_strings(self):
        self.assertEqual(self.case_read_calls, 1)
        self.assertEqual(self.inspector_fixture_calls, 1)
        self.assertEqual(self.v3_sink_calls, 2)  # Actual joiner and final A12 sink, no 16MiB legacy replacement.
        self.assertEqual(self.case_sink_calls, 2)  # Actual case reader and final A12 sink.
        before, after = self.old, self.current
        self.assertEqual(after["untimed_visual_intent_evidence"], before["untimed_visual_intent_evidence"])
        self.assertEqual(after["visual_amendment_evidence"], before["visual_amendment_evidence"])
        evidence = after["question_case_amendment_evidence"]
        self.assertEqual((evidence["changed_state_count"], evidence["changed_string_count"], evidence["unmodified_state_count"]), (2, 3, 98))
        self.assertEqual(evidence["inspection_sha256"], av.canonical_sha(self.literal))
        self.assertEqual(evidence["prior_amendment_inspection_sha256"], before["visual_amendment_evidence"]["inspection_sha256"])
        self.assertEqual(evidence["projection_binding"], case.PROJECTION_BINDING)
        old_states = {state["state_id"]: state for row in self.literal["prior_amendment_inspection"]["rows"] for state in row["states"]}
        new_states = {state["state_id"]: state for row in self.literal["rows"] for state in row["states"]}
        changed = [sid for sid in old_states if old_states[sid] != new_states[sid]]
        self.assertEqual(changed, ["visual-u019-s00", "visual-u021-s00"])
        self.assertEqual(len(old_states) - len(changed), 98)
        for sid in changed:
            restored = copy.deepcopy(new_states[sid])
            restored["visual_content"]["literal_copy"] = old_states[sid]["visual_content"]["literal_copy"]
            self.assertEqual(restored, old_states[sid])
        self.assertEqual(new_states["visual-u020-s01"]["entry"], {"kind": "LEXICAL_START", "char_start": 18,
            "char_end": 35, "text": "or only possible?", "previous_state_id": "visual-u020-s00"})

    def test_real_join_records_29_uses_71_pending_without_promoting_source_or_time(self):
        proof, evidence = self.source_proof, self.current["literal_asset_use_evidence"]
        self.assertEqual(evidence["adapter_version"], joiner.VERSION)
        self.assertEqual(evidence["scope"], "UNTIMED_ASSET_USE_METADATA_ONLY")
        self.assertEqual(evidence["source_binding"], USE_BINDING)
        self.assertEqual(evidence["inspection_sha256"], av.canonical_sha(proof))
        self.assertEqual(evidence["use_rows_sha256"], av.canonical_sha(proof["uses"]))
        self.assertEqual(evidence["effective_rows_sha256"], self.current["question_case_amendment_evidence"]["effective_rows_sha256"])
        self.assertEqual((evidence["source_count"], evidence["use_count"], evidence["unique_png_content_count"], evidence["lineage_count"]), (27, 29, 26, 3))
        self.assertEqual(evidence["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(evidence["remaining_unbound_visual_state_ids"]), 71)
        for surface in (evidence, self.current["question_case_amendment_evidence"]):
            for field in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
                self.assertIs(surface[field], False)
        self.assertTrue(all(flag is False for flag in evidence["authority"].values()))
        old_proof = sources._json(Reader(ROOT).read(uses.previous.INSPECTION["path"], "sha256:" + uses.previous.INSPECTION["sha256"]))
        self.assertEqual(proof["sources"][:23], old_proof["sources"])
        self.assertEqual(proof["uses"][:25], old_proof["uses"])

    def test_clock_pause_narration_union_and_blockers_remain_conservative(self):
        before, after = self.old, self.current
        for key in ("clock", "duration", "units", "narration_fragment_map", "pause_measurements", "caption_cues",
                    "render_spans", "visual_events", "status", "authority", "temporal_evidence_assessment", "caption_intent_evidence"):
            self.assertEqual(after[key], before[key], key)
        self.assertEqual((after["schema_version"], after["timeline_version"]), ("1.11.0", "phase6-av-timeline-v12"))
        self.assertIsNone(after["body_case_amendment_evidence"])
        self.assertFalse({"body_case_amendment", "body_case_evidence", "body_case_staging"} & set(after["inputs"]["source_bindings"]))
        # The deliberate CORE-only seam excludes the optional timed static
        # inspector. Its four graph blockers are replaced by absent intent;
        # this fixture never claims the 11 historical source proofs were replayed.
        excluded = {"RENDER_SPAN_COVERAGE_INCOMPLETE", "VISUAL_FRAGMENT_COVERAGE_INCOMPLETE",
                    "VISUAL_EVENTS_INCOMPLETE", "TEMPORAL_STATIC_EVENTS_INCOMPLETE"}
        self.assertEqual(after["blockers"], sorted((set(before["blockers"]) - excluded) | {"VISUAL_INTENT_NOT_BOUND"}))
        self.assertEqual(after["static_source_evidence"], [])
        self.assertEqual([after[key] for key in ("render_spans", "visual_events", "caption_cues")], [[], [], []])
        self.assertEqual(len(after["temporal_evidence_assessment"]["declared_target_unit_ids"]), 26)
        self.assertTrue(after["temporal_evidence_assessment"]["scope_complete"])
        self.assertFalse(after["temporal_evidence_assessment"]["all_required_evidence_live"])
        self.assertIn("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING", after["blockers"])
        self.assertEqual(after["status"], "BLOCKED_INCOMPLETE")
        self.assertIsNone(after["derived_take_plan"])
        silence = copy.deepcopy(before["permitted_silence_spans"])
        for item in silence:
            if item["reason"] in ("LOCKED_HOOK_PAD", "MECHANICAL_GRID_PAD"):
                self.assertEqual(item["evidence_ref"], av.canonical_sha(before["inputs"]))
                item["evidence_ref"] = av.canonical_sha(after["inputs"])
        self.assertEqual(after["permitted_silence_spans"], silence)

    def test_exact_forty_current_implementation_dependencies_and_fixed_model_bytes_are_attached(self):
        dependencies = self.current["implementation_dependencies"]
        expected = [{"path": name, "sha256": av.bytes_sha((ROOT / name).read_bytes())} for name in av.IMPLEMENTATION_PATHS]
        expected.append(av.CAPTION_TEXTWRAP_BINDING)
        self.assertEqual(dependencies, expected)
        self.assertEqual(len(dependencies), 40)
        self.assertEqual(len({row["path"] for row in dependencies}), 40)
        files = {item["path"]: item for item in self.current["source_file_bindings"]}
        self.assertIn(USE_BINDING["path"], files)
        for path, (digest, size) in question.MODEL_PINS.items():
            self.assertEqual(files[path], {"path": path, "sha256": "sha256:" + digest, "size_bytes": size})
        self.assertGreater(question.MODEL_PINS[".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_rec_small.onnx"][1], 16 * 1024**2)

    def test_missing_case_ancestry_or_malformed_bindings_fail_before_core_reads(self):
        for kind in ("v3", "v2", "caption", "wrong_case_pin", "raw_case_pin", "raw_use_pin", "path", "extra"):
            bindings = copy.deepcopy(self.arguments["source_bindings"])
            if kind == "v3": bindings.pop("visual_amendment")
            elif kind == "v2": bindings.pop("untimed_visual_intent")
            elif kind == "caption": bindings.pop("caption_intent")
            elif kind == "wrong_case_pin": bindings["question_case_amendment"]["sha256"] = "sha256:" + "0" * 64
            elif kind == "raw_case_pin": bindings["question_case_amendment"]["sha256"] = case.PROJECTION_BINDING["sha256"][7:]
            elif kind == "raw_use_pin": bindings["literal_asset_uses"]["sha256"] = USE_BINDING["sha256"][7:]
            elif kind == "path": bindings["literal_asset_uses"]["path"] = "../input.json"
            else: bindings["question_case_amendment"]["approved"] = True
            reader = mock.Mock()
            reader.load.side_effect = AssertionError("CORE cannot be read before valid case ancestry")
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                av._sources(reader, bindings)
            reader.load.assert_not_called()

    def test_current_and_frozen_schemas_preserve_a10_and_refuse_case_authority_or_relabel(self):
        old = Draft202012Validator(sources._json((ROOT / OLD_SCHEMA).read_bytes()))
        current = Draft202012Validator(self.schema)
        old.validate(self.old)
        current.validate(self.old)
        current.validate(self.current)
        with self.assertRaises(ValidationError): old.validate(self.current)
        for kind in ("missing_case", "missing_ancestry", "missing_evidence", "schema", "changed_count", "use_count", "ready", "derived", "complete"):
            candidate = copy.deepcopy(self.current)
            if kind == "missing_case": candidate["inputs"]["source_bindings"].pop("question_case_amendment")
            elif kind == "missing_ancestry": candidate["inputs"]["source_bindings"].pop("visual_amendment")
            elif kind == "missing_evidence": candidate.pop("question_case_amendment_evidence")
            elif kind == "schema": candidate.update(schema_version="1.9.0", timeline_version="phase6-av-timeline-v10")
            elif kind == "changed_count": candidate["question_case_amendment_evidence"]["changed_state_count"] = 12
            elif kind == "use_count": candidate["literal_asset_use_evidence"]["use_count"] = 25
            elif kind == "ready": candidate["question_case_amendment_evidence"]["source_ready"] = True
            elif kind == "derived": candidate["derived_take_plan"] = {"fixture_only": True}
            else: candidate["temporal_evidence_assessment"]["all_required_evidence_live"] = True
            with self.subTest(kind=kind), self.assertRaises(ValidationError): current.validate(candidate)

    def test_actual_join_rejects_wrong_copy_question_range_hold_or_case_proof_without_new_replay(self):
        for kind in ("copy", "lexical", "float", "hold", "case_hash", "old_version"):
            proof = copy.deepcopy(self.source_proof)
            row = next(row for row in proof["uses"] if row["visual_state_id"] == ("visual-u016-s01" if kind == "hold" else "visual-u020-s01"))
            if kind == "copy": row["literal_copy"] = ["Fully false?"]
            elif kind == "lexical": row["entry"]["kind"] = "UNIT_ENTRY"
            elif kind == "float": row["entry"]["char_start"] = 18.0
            elif kind == "hold": row["entry"]["previous_state_id"] = "visual-u017-s00"
            elif kind == "case_hash": proof["visual_amendment_evidence"]["inspection_sha256"] = "sha256:" + "0" * 64
            else: proof["version"] = "phase6-av-static-asset-uses-v2"
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                joiner.join(proof, USE_BINDING, self.literal)

    def test_core_rejects_case_reader_claiming_another_historical_v3_before_join(self):
        # Negative-only injection reuses the one real case observation; it does
        # not mutate a file or invoke source/QA readers again.
        literal = copy.deepcopy(self.literal)
        literal["prior_amendment_inspection"]["source_binding"]["sha256"] = "sha256:" + "0" * 64
        with mock.patch.object(joiner, "read_asset_use_binding", side_effect=AssertionError("history must fail before source join")), \
             self.assertRaisesRegex(ValueError, "historical V3 differs"):
            self.build_fixture(case_fixture=literal)

    def test_core_early_code_snapshot_rejects_virtual_drift_without_editing_any_file(self):
        original = Path.read_bytes
        changed = {"after_source": False}
        target = ROOT / "hero_engine/phase6_av_timeline.py"
        def core_seam(*_args):
            changed["after_source"] = True
            return copy.deepcopy(self.data)
        def virtual_drift(path):
            raw = original(path)
            return raw + b"\n# SYNTHETIC VIRTUAL DRIFT; REAL FILE UNCHANGED\n" if path == target and changed["after_source"] else raw
        with mock.patch.object(Path, "read_bytes", virtual_drift), \
             self.assertRaisesRegex(ValueError, "implementation dependency changed during build"):
            self.build_fixture(case_fixture=self.literal, sources_callback=core_seam)


if __name__ == "__main__":
    unittest.main()
