"""Native PCM observation and public evaluator entry; no live project effects."""
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import soundfile as sf
from hero_engine import phase5_autonomous_quality as quality


class MusicSampleQualityTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.media = Path(temporary.name) / 'own.wav'
        t = np.arange(48_000) / 48_000
        sf.write(self.media, np.column_stack([np.sin(2*np.pi*220*t)*.1]*2), 48_000, subtype='PCM_16')
        self.hash = 'sha256:' + hashlib.sha256(self.media.read_bytes()).hexdigest()

    def observe(self):
        return quality.measure_music_sample(self.media, expected_media_hash=self.hash, expected_duration_ms=1000)

    def response(self, **values):
        data = {'input_i':'-16', 'input_tp':'-2', 'input_lra':'3', **values}
        return subprocess.CompletedProcess([], 0, '', json.dumps(data))

    def test_real_pcm_and_existing_limits_do_not_grant_music_authority(self):
        with patch('subprocess.run', return_value=self.response()) as run:
            result = self.observe()
        pcm, _ = sf.read(self.media, always_2d=True)
        self.assertAlmostEqual(result['measurements']['rms_linear'], float(np.sqrt(np.mean(pcm*pcm))))
        self.assertEqual(result['observed_frames'], 48000)
        self.assertEqual(result['existing_narrated_mix_gate']['status'], 'PASS')
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual(run.call_args.kwargs['timeout'], 60)

    def test_tampered_hash_blocked_before_codec(self):
        self.media.write_bytes(self.media.read_bytes()+b'tamper')
        with patch('subprocess.run') as run, self.assertRaises(PermissionError): self.observe()
        run.assert_not_called()

    def test_duration_divergence_blocked(self):
        with self.assertRaises(PermissionError):
            quality.measure_music_sample(self.media, expected_media_hash=self.hash, expected_duration_ms=999)

    def test_codec_failure_or_partial_result_not_pass(self):
        for result in (subprocess.CompletedProcess([],1,'','failure'), subprocess.CompletedProcess([],0,'','')):
            with self.subTest(code=result.returncode), patch('subprocess.run',return_value=result), self.assertRaises(RuntimeError): self.observe()

    def test_change_during_codec_observation_rejected(self):
        def changed(*args, **kwargs):
            self.media.write_bytes(self.media.read_bytes()+b'changed')
            return self.response()
        with patch('subprocess.run',side_effect=changed), self.assertRaises(PermissionError): self.observe()

    def test_silence_and_nonfinite_loudness_cannot_pass(self):
        with patch('subprocess.run',return_value=self.response(input_i='-inf',input_tp='-inf',input_lra='0')):
            result=self.observe()
        self.assertEqual(result['existing_narrated_mix_gate']['status'],'FAIL')
        self.assertIsNone(result['measurements']['loudness']['integrated_lufs'])
        json.dumps(result, allow_nan=False)

    def test_continuity_observes_jump_across_streaming_boundary(self):
        pcm=np.zeros((96000,2)); pcm[48000:]=.8
        sf.write(self.media,pcm,48000,subtype='PCM_16')
        binding='sha256:'+hashlib.sha256(self.media.read_bytes()).hexdigest()
        with patch('subprocess.run',return_value=self.response()):
            result=quality.measure_music_sample(self.media,expected_media_hash=binding,expected_duration_ms=2000)
        self.assertGreater(result['measurements']['maximum_block_boundary_delta'],.79)
        self.assertEqual(result['measurements']['maximum_adjacent_sample_delta'],result['measurements']['maximum_block_boundary_delta'])
        self.assertFalse(result['quality_authorized'])

    def test_public_entry_is_read_only_and_cannot_apply_transition(self):
        argv=['evaluator','--music-sample',str(self.media),'--expected-music-hash',self.hash,'--music-duration-ms','1000']
        with patch.object(sys,'argv',argv), patch('subprocess.run',return_value=self.response()), patch('builtins.print') as output, patch.object(quality,'materialize',side_effect=AssertionError('no legacy materialization')):
            quality.main()
        self.assertEqual(json.loads(output.call_args.args[0])['status'],'MEASURED_SHORT_SAMPLE')
        with patch.object(sys,'argv',argv+['--apply-limited']), self.assertRaises(SystemExit): quality.main()
