"""One real metadata-only chain; adversarial literal fixtures, no media work.

A10 units below are frozen metadata, not newly verified PCM. This suite does
not synthesize, decode, infer, inspect PNG CRCs, write a proposal or rebuild A.
"""
import copy
import json
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError

from hero_engine import phase6_av_caption_intent as captions
from hero_engine import phase6_av_question_case_amendment as case
from hero_engine import phase6_av_visual_amendment as legacy
from hero_engine.phase6_narration_audio_inventory import Reader
from hero_engine.phase6_narration_units import bytes_sha, canonical_sha

ROOT = Path(__file__).absolute().parents[1]
TIMELINE = {"path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-f4be1a123a552503913cf306.json",
    "sha256": "sha256:42eaa6f7e1b5b74f62693cbee25df4d6c95831a9e77eae384163b4ca23de488c"}
ERRORS = (ValueError, PermissionError, ValidationError, FileNotFoundError)


class QuestionCaseAmendmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pins = {path: bytes_sha((ROOT / path).read_bytes()) for path in
            ("hero_engine/phase6_av_question_case_amendment.py", case.SCHEMA, "tests/test_phase6_av_question_case_amendment.py")}
        reader = Reader(ROOT)
        cls.units = json.loads(reader.read(TIMELINE["path"], TIMELINE["sha256"]))["units"]
        cls.caption = captions.read_caption_intent(reader, captions.PLAN_BINDING, cls.units)
        cls.projection = json.loads(reader.read(case.PROJECTION_BINDING["path"], case.PROJECTION_BINDING["sha256"]))
        cls.amendment = json.loads(reader.read(case.AMENDMENT_BINDING["path"], case.AMENDMENT_BINDING["sha256"]))
        cls.schema = json.loads((ROOT / case.SCHEMA).read_bytes())
        with mock.patch.object(legacy, "read_amended_visual_intent", wraps=legacy.read_amended_visual_intent) as old_read, \
             mock.patch.object(case.question, "_preflight", wraps=case.question._preflight) as preflight, \
             mock.patch.object(case.question, "inspect_question_sources", side_effect=AssertionError("NO SOURCE INSPECTION")), \
             mock.patch.object(case.question, "_png_container", side_effect=AssertionError("NO CRC REPEAT")), \
             mock.patch("PIL.Image.open", side_effect=AssertionError("NO IMAGE DECODE")), \
             mock.patch("hero_engine.phase6_narration_audio_inventory.inspect_pcm", side_effect=AssertionError("NO PCM")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("NO INFERENCE/RENDER")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")), \
             mock.patch.object(Path, "write_bytes", side_effect=AssertionError("NO WRITES")):
            cls.real = case.read_amended_visual_intent(reader, case.PROJECTION_BINDING, cls.units, cls.caption)
            cls.calls = old_read.call_count, preflight.call_count

    @classmethod
    def tearDownClass(cls):
        for path, digest in cls.pins.items():
            if bytes_sha((ROOT / path).read_bytes()) != digest:
                raise AssertionError("new adapter/schema/test changed during focal")

    def test_real_chain_keeps_v2_v3_history_and_three_case_strings_only(self):
        result, prior = self.real, self.real["prior_amendment_inspection"]
        self.assertEqual(self.calls, (1, 1))
        self.assertEqual(result["source_binding"], case.PROJECTION_BINDING)
        self.assertEqual(prior["source_binding"], legacy.PROJECTION_BINDING)
        self.assertEqual(result["base_inspection"], prior["base_inspection"])
        self.assertEqual(result["prior_amendment_inspection_sha256"], canonical_sha(prior))
        self.assertEqual(result["base_inspection_sha256"], canonical_sha(prior["base_inspection"]))
        self.assertEqual(result["effective_rows_sha256"], canonical_sha(result["rows"]))
        self.assertEqual([result[key] for key in ("unit_count", "fragment_count", "state_count", "changed_state_count", "changed_string_count", "unmodified_state_count")], [51, 90, 100, 2, 3, 98])
        changes, strings = [], 0
        for actual, old in zip(result["rows"], prior["rows"], strict=True):
            self.assertEqual({k: v for k, v in actual.items() if k != "states"}, {k: v for k, v in old.items() if k != "states"})
            for state, before in zip(actual["states"], old["states"], strict=True):
                if canonical_sha(state) != canonical_sha(before):
                    changes.append(state["state_id"])
                    strings += sum(left != right for left, right in zip(state["visual_content"]["literal_copy"], before["visual_content"]["literal_copy"], strict=True))
                    restored = copy.deepcopy(state)
                    restored["visual_content"]["literal_copy"] = before["visual_content"]["literal_copy"]
                    self.assertEqual(restored, before)
        self.assertEqual(changes, ["visual-u019-s00", "visual-u021-s00"])
        self.assertEqual(strings, 3)
        self.assertEqual(len(result["implementation_dependencies"]), 10)
        self.assertEqual(len({row["path"] for row in result["implementation_dependencies"]}), 10)

    def test_literal_union_revelation_hold_d169_and_nonproductive_flags_preserved(self):
        result, prior = self.real, self.real["prior_amendment_inspection"]
        for key in ("visual_lexical_ranges", "visual_lexical_unit_ids", "caption_lexical_unit_ids", "temporal_target_unit_ids", "d169_negative_unit_ids"):
            self.assertEqual(result[key], prior[key])
        self.assertEqual(len(result["temporal_target_unit_ids"]), 26)
        self.assertEqual(len(result["d169_negative_unit_ids"]), 25)
        self.assertEqual(result["rows"][19]["states"][1]["entry"], {"kind": "LEXICAL_START", "char_start": 18, "char_end": 35, "text": "or only possible?", "previous_state_id": "visual-u020-s00"})
        self.assertEqual(result["rows"][15]["states"][0]["visual_content"], result["rows"][15]["states"][1]["visual_content"])
        for key in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
            self.assertIs(result[key], False)
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertEqual(result["technical_cost_brl"], 0)
        for row in result["rows"]:
            self.assertEqual(row["source_status"], "SOURCE_PENDING")
            self.assertIs(row["quality_approved"], False)

    def test_bad_external_binding_never_reaches_base_or_question_replay(self):
        candidates = [None, {}, {**case.PROJECTION_BINDING, "sha256": "sha256:" + "0" * 64},
            {**case.PROJECTION_BINDING, "path": "../outside.json"}, {**case.PROJECTION_BINDING, "path": "C:/outside.json"},
            {**case.PROJECTION_BINDING, "ready": True}, legacy.PROJECTION_BINDING]
        with mock.patch.object(legacy, "read_amended_visual_intent", side_effect=AssertionError("NO BASE")), \
             mock.patch.object(case.question, "_preflight", side_effect=AssertionError("NO QUESTION REPLAY")):
            for binding in candidates:
                with self.subTest(binding=binding), self.assertRaises(ERRORS):
                    case.read_amended_visual_intent(Reader(ROOT), binding, self.units, self.caption)

    def test_independent_copy_mapping_cannot_change_narration_entry_hold_or_other_states(self):
        for mutation in ("copy", "unit", "order", "missing", "thirdstate", "narration", "lexical", "hold", "negative", "reference", "source", "description"):
            projection, body = copy.deepcopy(self.projection), copy.deepcopy(self.amendment)
            if mutation == "copy": body["changes"][0]["after_copy"][0] = "Tests"
            elif mutation == "unit": body["changes"][0]["unit_id"] = "narration-unit-020"
            elif mutation == "order": body["changes"].reverse()
            elif mutation == "missing": body["changes"].pop()
            elif mutation == "thirdstate": projection["effective_rows"][0]["states"][0]["visual_content"]["literal_copy"] = ["NEW"]
            elif mutation == "narration": projection["effective_rows"][18]["text"] += " different"
            elif mutation == "lexical": projection["effective_rows"][19]["states"][1]["entry"]["char_start"] = 18.0
            elif mutation == "hold": projection["effective_rows"][15]["states"][1]["entry"]["kind"] = "UNIT_ENTRY"
            elif mutation == "negative": projection["effective_rows"][18]["states"].append(copy.deepcopy(projection["effective_rows"][19]["states"][1]))
            elif mutation == "reference": projection["effective_rows"][18]["decision_reference"]["selector"] = "/rows/20"
            elif mutation == "source": projection["effective_rows"][18]["source_status"] = "READY"
            else: projection["effective_rows"][18]["states"][0]["visual_content"]["description"] = "Silently rewritten"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                case._apply_case(self.real["prior_amendment_inspection"], projection, body)

    def test_closed_schema_identity_flags_cost_and_no_timestamps(self):
        Draft202012Validator.check_schema(self.schema)
        for document in (self.projection, self.amendment):
            Draft202012Validator(self.schema).validate(document)
        old_schema = json.loads((ROOT / legacy.SCHEMA).read_bytes())
        self.assertFalse(Draft202012Validator(old_schema).is_valid(self.projection))
        for mutation in ("authority", "time", "cost", "floatcount", "identity", "oldfail", "extra"):
            projection, body = copy.deepcopy(self.projection), copy.deepcopy(self.amendment)
            if mutation == "authority": projection["authority"]["publication"] = True
            elif mutation == "time": projection["effective_rows"][19]["states"][1]["start_sample"] = 800
            elif mutation == "cost": body["technical_cost_brl"] = 0.0
            elif mutation == "floatcount": body["changed_state_count"] = 2.0
            elif mutation == "identity": body["amendment_id"] = "question-case-amendment-v2-" + "0" * 24
            elif mutation == "oldfail": body["original_qa_status"] = "PASS_STATIC_SCOPE_ONLY"
            else: body["approved_now"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ERRORS): case._documents(projection, body, self.schema)

    def test_wrong_unit_pcm_or_caption_proof_fails_before_question_replay(self):
        with mock.patch.object(case.question, "_preflight", side_effect=AssertionError("NO QUESTION REPLAY")):
            for mutation in ("text", "pcm", "caption"):
                units, caption = copy.deepcopy(self.units), copy.deepcopy(self.caption)
                if mutation == "text": units[18]["text"] += " changed"
                elif mutation == "pcm": units[18]["pcm_sha256"] = "sha256:" + "0" * 64
                else: caption["temporal_target_unit_ids"] = []
                with self.subTest(mutation=mutation), self.assertRaises(ERRORS):
                    case.read_amended_visual_intent(Reader(ROOT), case.PROJECTION_BINDING, units, caption)

    def test_dependencies_keep_models_out_of_bounded_metadata_and_pin_implementations(self):
        result = self.real
        self.assertTrue(all(row["size_bytes"] <= 2_000_000 and not Path(row["path"]).is_absolute() for row in result["dependency_bindings"]))
        raw = {row["path"]: row for row in result["question_replay_dependencies"]}
        model_path = str(ROOT / ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_rec_small.onnx")
        self.assertEqual(raw[model_path]["size_bytes"], 21234383)
        self.assertEqual(raw[model_path]["sha256"], "6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884")
        self.assertEqual(raw[str(case.source.FONT)]["sha256"], case.source.FONT_SHA)
        self.assertTrue(set(case.source.EXTERNAL_DEPENDENCY_PINS) <= set(raw))
        for name, digest in case.FIXED_IMPLEMENTATIONS.items():
            self.assertEqual(raw[str(ROOT / name)]["sha256"], digest)
        self.assertEqual(len(raw), len(result["question_replay_dependencies"]))

    def test_same_call_recheck_rejects_authority_omission_model_repin_and_late_drift(self):
        for mutation in ("authority", "ready", "scope", "model", "missing"):
            result = copy.deepcopy(self.real)
            if mutation == "authority": result["authority"]["publication"] = True
            elif mutation == "ready": result["source_ready"] = True
            elif mutation == "scope": result["static_proof_scope"] = "PRODUCTION_APPROVED"
            elif mutation == "model":
                next(row for row in result["question_replay_dependencies"] if row["path"].endswith("PP-OCRv6_rec_small.onnx"))["sha256"] = "0" * 64
            else: result["question_replay_dependencies"] = []
            with self.subTest(mutation=mutation), self.assertRaises(ERRORS): case.recheck_question_replay(ROOT, result)
        original = case.source._Reader.read_path
        def late_drift(instance, path, *args, **kwargs):
            if Path(path) == ROOT / case.RECONCILIATION_BINDING["path"]:
                raise ValueError("EXPLICIT FIXTURE LATE RECONCILIATION DRIFT")
            return original(instance, path, *args, **kwargs)
        with mock.patch.object(case.source._Reader, "read_path", new=late_drift), self.assertRaisesRegex(ValueError, "LATE RECONCILIATION DRIFT"):
            case.recheck_question_replay(ROOT, self.real)


if __name__ == "__main__":
    unittest.main(verbosity=2)
