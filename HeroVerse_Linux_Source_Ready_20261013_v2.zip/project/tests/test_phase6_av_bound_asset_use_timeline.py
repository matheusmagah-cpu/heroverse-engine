"""A10 wrapper transactions in temporary roots; build is an explicit fixture.

These cases validate persistence/error boundaries, not PCM, sources or media.
The pre-existing A9/result pins are read only to exercise exact preservation.
"""
import copy
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_asset_use_binding as joiner
from hero_engine import phase6_av_static_sources as sources
from tests import test_phase6_av_amendment_integration as a9_harness
from tests import test_phase6_compact_rights_registration as writer_harness

ROOT = Path(__file__).absolute().parents[1]
RUNNER = ROOT / "output/qa/phase6/diagnostics/two-column-compact-v1/build_bound_asset_use_timeline.py"
spec = importlib.util.spec_from_file_location("bound_asset_use_wrapper_fixture", RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class BoundAssetUseTimelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        reader = sources._Reader(ROOT)
        cls.base = sources._json(reader.read(runner.BASE, runner.PINS[runner.BASE]))
        cls.old = sources._json(reader.read(runner.PREVIOUS, runner.PINS[runner.PREVIOUS]))

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="bound-A10-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "workspace"
        self.root.mkdir()
        self.pins = {}
        self.code_pins = {}
        for name in {**runner.PINS, **dict.fromkeys(runner.CODE_PATHS, "unused")}:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            if name == runner.BASE: raw = sources._canonical(self.base)
            elif name == runner.PREVIOUS: raw = sources._canonical(self.old)
            else: raw = ("EXPLICIT TRANSACTION FIXTURE " + name).encode()
            path.write_bytes(raw)
            target = self.code_pins if name in runner.CODE_PATHS else self.pins
            target[name] = sources._sha(raw)
        self.bundle = runner.make_bundle(self.base)
        self.argument_path = self.root / Path(runner.BASE).parent / (self.bundle["arguments_id"] + ".json")
        self.receipt_path = self.root / runner.RECEIPT
        self.current = copy.deepcopy(self.old)
        self.current.update(schema_version="1.9.0", timeline_version="phase6-av-timeline-v10",
                            timeline_id="phase6-av-timeline-EXPLICIT-FIXTURE", inputs=copy.deepcopy(self.bundle["arguments"]))
        for row in self.current["permitted_silence_spans"]:
            if row["reason"] in ("LOCKED_HOOK_PAD", "MECHANICAL_GRID_PAD"):
                row["evidence_ref"] = av.canonical_sha(self.current["inputs"])
        # Only transaction seam; the independent A10 integration tests check
        # real literal population and inspector bindings, not this placeholder.
        self.current["literal_asset_use_evidence"] = {
            "adapter_version": joiner.VERSION, "scope": "UNTIMED_ASSET_USE_METADATA_ONLY",
            "source_binding": copy.deepcopy(runner.USE_BINDING), "source_count": 23,
            "use_count": 25, "unique_png_content_count": 22, "lineage_count": 3,
            "visual_state_count": 100, "bound_visual_state_ids": list(joiner.COVERED),
            "remaining_unbound_visual_state_ids": [f"FIXTURE-unbound-{i}" for i in range(75)],
            "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
            "authority": dict(joiner.AUTHORITY), "technical_cost_brl": 0}
        self.dependency = self.root / "fixture-source.txt"
        self.dependency.write_bytes(b"EXPLICIT BYTE RECHECK FIXTURE")
        self.current["source_file_bindings"] = [{"path": "fixture-source.txt",
            "sha256": av.bytes_sha(self.dependency.read_bytes()), "size_bytes": self.dependency.stat().st_size}]
        self.implementation = self.root / "fixture-implementation.py"
        self.implementation.write_bytes(b"EXPLICIT IMPLEMENTATION PIN FIXTURE")
        self.external = self.root.parent / "fixture-allowed-decoder.bin"
        self.external.write_bytes(b"EXPLICIT EXTERNAL DEPENDENCY FIXTURE")
        self.textwrap = self.root.parent / "fixture-textwrap.py"
        self.textwrap.write_bytes(b"EXPLICIT TEXTWRAP DEPENDENCY FIXTURE")
        self.textwrap_pin = {"path": str(self.textwrap), "sha256": av.bytes_sha(self.textwrap.read_bytes())}
        self.external_pins = {str(self.external): sources._sha(self.external.read_bytes())}
        self.current["implementation"] = {"path": runner.CODE_PATHS[0], "sha256": "sha256:" + self.code_pins[runner.CODE_PATHS[0]]}
        self.current["implementation_dependencies"] = [{"path": "fixture-implementation.py",
            "sha256": av.bytes_sha(self.implementation.read_bytes())}, copy.deepcopy(self.textwrap_pin)]
        self.timeline_path = self.root / Path(runner.PREVIOUS).parent / (self.current["timeline_id"] + ".json")

    def execute(self, *, build=None, writer=None, **kwargs):
        def module(path, _name):
            if path == runner.HELPER: return a9_harness.runner
            if path == runner.WRITER:
                return SimpleNamespace(immutable=writer or writer_harness.registration.immutable)
            raise AssertionError("unexpected module")
        with mock.patch.object(runner, "ROOT", self.root), mock.patch.object(runner, "PINS", self.pins), \
             mock.patch.object(writer_harness.registration, "ROOT", self.root), \
             mock.patch.object(sources, "EXTERNAL_DEPENDENCY_PINS", self.external_pins), \
             mock.patch.object(av, "CAPTION_TEXTWRAP_BINDING", self.textwrap_pin), \
             mock.patch.object(runner, "_module", side_effect=module), \
             mock.patch.object(av, "build", side_effect=build or (lambda *_a, **_k: copy.deepcopy(self.current))), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no media/process effects")):
            return runner.execute(self.code_pins, **kwargs)

    def test_only_binding_is_added_and_clock_or_authority_changes_fail(self):
        runner.validate_bundle(self.base, self.bundle)
        runner.validate_result(self.old, self.current, self.bundle, a9_harness.runner.validate_silence)
        for mutation in (lambda row: row["duration"].update(planned_duration_ms=999),
                         lambda row: row.update(blockers=[]),
                         lambda row: row["literal_asset_use_evidence"].update(authority={}),
                         lambda row: row["literal_asset_use_evidence"].update(use_count=25.0),
                         lambda row: row["literal_asset_use_evidence"].update(source_ready=True),
                         lambda row: row["literal_asset_use_evidence"].update(bound_visual_state_ids=[]),
                         lambda row: row.update(extra="not allowed"),
                         lambda row: row["permitted_silence_spans"][0].update(end_sample=1)):
            candidate = copy.deepcopy(self.current)
            mutation(candidate)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                runner.validate_result(self.old, candidate, self.bundle, a9_harness.runner.validate_silence)

    def test_preflight_is_read_only_and_never_builds(self):
        before = sorted(str(p) for p in self.root.rglob("*"))
        def forbidden(*_a, **_k): raise AssertionError("preflight must not build")
        result = self.execute(build=forbidden)
        self.assertEqual(result["mode"], "PREFLIGHT_ONLY_NO_WRITE")
        self.assertEqual(result["arguments_sha256"], sources._sha(sources._canonical(self.bundle)))
        self.assertEqual(before, sorted(str(p) for p in self.root.rglob("*")))

    def test_malformed_code_pin_and_commit_reject_before_modules(self):
        for pins, commit in (({}, True), (self.code_pins, 1),
                             ({**self.code_pins, runner.CODE_PATHS[0]: "0" * 64}, True)):
            with mock.patch.object(runner, "ROOT", self.root), mock.patch.object(runner, "PINS", self.pins), \
                 mock.patch.object(runner, "_module", side_effect=AssertionError("pins before module")), self.assertRaises(ValueError):
                runner.execute(pins, commit=commit)

    def test_build_failure_keeps_arguments_and_requires_external_pin_to_resume(self):
        def fail(*_a, **_k): raise ValueError("FIXTURE build rejection")
        with self.assertRaisesRegex(ValueError, "build rejection"): self.execute(commit=True, build=fail)
        original = self.argument_path.read_bytes()
        self.assertFalse(self.timeline_path.exists())
        with self.assertRaises(ValueError): self.execute(commit=True)
        result = self.execute(commit=True, arguments_sha=sources._sha(original))
        self.assertEqual(result["status"], "BLOCKED_INCOMPLETE")
        self.assertEqual(original, self.argument_path.read_bytes())
        self.assertTrue(self.receipt_path.exists())

    def test_late_argument_or_dependency_drift_blocks_persistence(self):
        for target in (self.argument_path, self.dependency):
            # Restore only isolated fixture bytes between these two subcases.
            if self.argument_path.exists():
                arguments_sha = sources._sha(self.argument_path.read_bytes())
            else: arguments_sha = None
            original = target.read_bytes() if target.exists() else sources._canonical(self.bundle)
            def drift(*_a, **_k):
                target.write_bytes(original + b"\n")
                return copy.deepcopy(self.current)
            with self.subTest(target=target.name), self.assertRaises(ValueError):
                self.execute(commit=True, arguments_sha=arguments_sha, build=drift)
            self.assertFalse(self.timeline_path.exists())
            self.assertFalse(self.receipt_path.exists())
            target.write_bytes(original)  # restore isolated fixture only

    def test_completed_receipt_or_unreceipted_timeline_never_rebuilds(self):
        self.execute(commit=True)
        original = self.timeline_path.read_bytes()
        def forbidden(*_a, **_k): raise AssertionError("must not rebuild existing timeline")
        with self.assertRaisesRegex(ValueError, "completed A10 receipt"):
            self.execute(commit=True, build=forbidden)
        self.receipt_path.unlink()  # explicit interrupted-write fixture, not production
        with self.assertRaisesRegex(ValueError, "timeline checkpoint exists"):
            self.execute(commit=True, arguments_sha=sources._sha(self.argument_path.read_bytes()), build=forbidden)
        self.assertEqual(original, self.timeline_path.read_bytes())

    def test_corrupt_partial_arguments_cannot_be_overwritten_even_with_matching_hash(self):
        self.argument_path.write_bytes(b"{}\n")
        before = self.argument_path.read_bytes()
        with self.assertRaisesRegex(ValueError, "partial A10 arguments differ"):
            self.execute(commit=True, arguments_sha=sources._sha(before))
        self.assertEqual(before, self.argument_path.read_bytes())

    def test_dependency_drift_during_timeline_write_blocks_final_receipt(self):
        def writer(path, raw):
            result = writer_harness.registration.immutable(path, raw)
            if path == self.timeline_path:
                self.dependency.write_bytes(self.dependency.read_bytes() + b"\n")
            return result
        with self.assertRaises(ValueError): self.execute(commit=True, writer=writer)
        self.assertTrue(self.timeline_path.exists())
        self.assertFalse(self.receipt_path.exists())

    def test_implementation_textwrap_and_fixed_external_drift_rejects_after_build(self):
        for target in (self.implementation, self.textwrap, self.external):
            original = target.read_bytes()
            def drift(*_a, **_k):
                target.write_bytes(original + b"\n")
                return copy.deepcopy(self.current)
            pin = sources._sha(self.argument_path.read_bytes()) if self.argument_path.exists() else None
            with self.subTest(target=target.name), self.assertRaises(ValueError):
                self.execute(commit=True, arguments_sha=pin, build=drift)
            self.assertFalse(self.timeline_path.exists())
            self.assertFalse(self.receipt_path.exists())
            target.write_bytes(original)

    def test_external_candidate_cannot_expand_allowlist(self):
        unexpected = self.root.parent / "fixture-unlisted.py"
        unexpected.write_bytes(b"EXPLICIT UNLISTED EXTERNAL FIXTURE")
        self.current["implementation_dependencies"].append({"path": str(unexpected), "sha256": av.bytes_sha(unexpected.read_bytes())})
        with self.assertRaises(ValueError): self.execute(commit=True)
        self.assertFalse(self.timeline_path.exists())

    def test_implementation_drift_during_timeline_write_blocks_receipt(self):
        def writer(path, raw):
            result = writer_harness.registration.immutable(path, raw)
            if path == self.timeline_path:
                self.implementation.write_bytes(self.implementation.read_bytes() + b"\n")
            return result
        with self.assertRaises(ValueError): self.execute(commit=True, writer=writer)
        self.assertTrue(self.timeline_path.exists())
        self.assertFalse(self.receipt_path.exists())


if __name__ == "__main__":
    unittest.main()
