from __future__ import annotations

import unittest
import json
import hashlib
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from hero_engine.central_manager_phase5 import (
    ManagerAlreadyRunning,
    ManagerLock,
    _quota_usage,
    _validate_owned_quota_debit_chain,
    _commit_owned_observer_transaction,
    _recover_committed_protocol_activation,
    _oauth_reconsent_worker,
    _existing_oauth_chain_is_current,
    _publication_retry_due,
    run_phase6_observer_if_due,
    _write,
    _start_review_console,
    ensure_oauth_session_health,
    input_fingerprint,
    run_cycle,
)


ROOT = Path(__file__).resolve().parents[1]


class CentralManagerPhase5Tests(unittest.TestCase):
    @staticmethod
    def _write_publication_receipt(root: Path, **changes):
        schema = root / "schemas/youtube_publication_receipt.schema.json"
        schema.parent.mkdir(parents=True, exist_ok=True)
        schema.write_bytes((ROOT / "schemas/youtube_publication_receipt.schema.json").read_bytes())
        value = json.loads(
            (ROOT / "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
            .read_text(encoding="utf-8-sig")
        )
        value.update(changes)
        publication = root / "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
        publication.parent.mkdir(parents=True, exist_ok=True)
        publication.write_text(json.dumps(value), encoding="utf-8")
        return publication

    def test_atomic_receipt_write_recovers_from_transient_onedrive_lock(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "receipt.json"
            real_replace = __import__("os").replace
            calls = []

            def flaky(source, destination):
                calls.append((source, destination))
                if len(calls) == 1:
                    raise PermissionError("simulated transient sync lock")
                return real_replace(source, destination)

            with (
                patch("hero_engine.central_manager_phase5.os.replace", side_effect=flaky),
                patch("hero_engine.central_manager_phase5.time.sleep"),
            ):
                _write(target, {"status": "PASS"})
            self.assertEqual({"status": "PASS"}, json.loads(target.read_text(encoding="utf-8")))
            self.assertEqual(2, len(calls))

    def test_phase6_observer_is_not_due_before_preregistered_window(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/phase6_observer_runtime.schema.json").write_bytes((ROOT / "schemas/phase6_observer_runtime.schema.json").read_bytes())
            (root / "schemas/phase6_queue_snapshot.schema.json").write_bytes((ROOT / "schemas/phase6_queue_snapshot.schema.json").read_bytes())
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest.parent.mkdir(parents=True)
            latest.write_text(json.dumps({"next_observation_at": "2026-09-05T18:00:00Z"}), encoding="utf-8")
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            value = run_phase6_observer_if_due(root, token, now=datetime(2026, 9, 5, 17, 0, tzinfo=timezone.utc))
            self.assertEqual("NOT_DUE", value["status"])
            self.assertEqual("2026-09-05T18:00:00Z", value["next_observation_at"])

    def test_wrong_channel_receipt_blocks_before_queue_or_reporting(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/phase6_observer_runtime.schema.json").write_bytes(
                (ROOT / "schemas/phase6_observer_runtime.schema.json").read_bytes()
            )
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root, channel_id="WRONG_CHANNEL")
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            with patch("hero_engine.youtube_reporting_phase6.materialize_live") as reporting:
                value = run_phase6_observer_if_due(
                    root, token,
                    now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc),
                )
            reporting.assert_not_called()
            self.assertEqual("BLOCKED", value["status"])
            self.assertIn("PUBLICATION_RECEIPT_INVALID", value["error"])
            self.assertFalse(
                (root / "output/operations/phase6/runtime/phase6-queue.sqlite3").exists()
            )

    def test_checkpointed_metrics_without_consumed_ledger_chain_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            job = {
                "job_id": "job-forged",
                "checkpoint": {
                    "quota_preflight": "some-preflight.json",
                    "metrics_snapshot": "some-snapshot.json",
                },
            }
            snapshot = {"captured_at": "2026-09-05T19:00:00Z"}
            with self.assertRaisesRegex(PermissionError, "ledger 1.1"):
                _validate_owned_quota_debit_chain(root, job=job, snapshot=snapshot)

    def test_due_phase6_observation_refreshes_reporting_before_owned_metrics(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json", "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json", "youtube_reporting_job_registry.schema.json",
                "own_channel_performance_snapshot.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes((ROOT / "config/zero-cost-policy.json").read_bytes())
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            snapshot = root / "output/operations/phase6/metrics/iK_5edYQtx8/snapshot.json"
            snapshot.parent.mkdir(parents=True)
            snapshot_value = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            snapshot_value["next_observation_at"] = "2026-09-07T18:00:00Z"
            snapshot.write_text(json.dumps(snapshot_value), encoding="utf-8")
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            order = []

            def reporting(*args, **kwargs):
                kwargs["progress"]()
                order.append("reporting")
                path = root / "job-registry.json"
                path.write_text("{}", encoding="utf-8")
                return path

            def metrics(*args, **kwargs):
                kwargs["progress"]()
                order.append("metrics")
                latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
                latest.write_bytes(snapshot.read_bytes())
                return snapshot

            def intelligence(*args, **kwargs):
                order.append("intelligence")
                paths = (root / "prediction.json", root / "diagnosis.json", root / "experiment.json")
                for path in paths:
                    path.write_text("{}", encoding="utf-8")
                return paths

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value={"youtube-general-units-daily": 5, "youtube-videos-insert-daily": 0}),
                patch("hero_engine.youtube_reporting_phase6.materialize_live", side_effect=reporting),
                patch("hero_engine.phase6_pilot.materialize_live", side_effect=metrics),
                patch("hero_engine.phase6_intelligence.materialize_current", side_effect=intelligence),
            ):
                value = run_phase6_observer_if_due(root, token, now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc))
            self.assertEqual(["reporting", "metrics", "intelligence"], order, value)
            self.assertEqual("COLLECTED", value["status"])

    def test_reporting_registry_written_before_crash_is_reconciled_without_repeating_stage(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json", "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json", "youtube_reporting_job_registry.schema.json",
                "own_channel_performance_snapshot.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes(
                (ROOT / "config/zero-cost-policy.json").read_bytes()
            )
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            registry_path = root / "output/operations/phase6/reporting/job-registry.json"

            def crash_after_registry(*args, **kwargs):
                value = json.loads(
                    (ROOT / "output/operations/phase6/reporting/job-registry.json")
                    .read_text(encoding="utf-8-sig")
                )
                value["observed_at"] = kwargs["captured_at"]
                registry_path.parent.mkdir(parents=True)
                registry_path.write_text(json.dumps(value), encoding="utf-8")
                raise RuntimeError("simulated crash after registry commit")

            usage = {"youtube-general-units-daily": 5, "youtube-videos-insert-daily": 0}
            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value=usage),
                patch(
                    "hero_engine.youtube_reporting_phase6.materialize_live",
                    side_effect=crash_after_registry,
                ),
            ):
                failed = run_phase6_observer_if_due(
                    root, token,
                    now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc),
                )
            self.assertEqual("ERROR", failed["status"])

            source = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json")
                .read_text(encoding="utf-8-sig")
            )
            source["snapshot_id"] = "own-performance-iK_5edYQtx8-20260905T190031Z"
            source["captured_at"] = "2026-09-05T19:00:31Z"
            source["next_observation_at"] = "2026-09-07T18:45:51Z"
            source_path = root / "collected.json"
            source_path.write_text(json.dumps(source), encoding="utf-8")

            def metrics(*args, **kwargs):
                destination = kwargs["immutable_destination"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                payload = json.dumps(source, ensure_ascii=False, indent=2) + "\n"
                destination.write_bytes(payload.encode("utf-8"))
                latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
                latest.parent.mkdir(parents=True)
                latest.write_bytes(payload.encode("utf-8"))
                return destination

            def intelligence(*args, **kwargs):
                paths = (root / "prediction.json", root / "diagnosis.json", root / "experiment.json")
                for path in paths:
                    path.write_text("{}", encoding="utf-8")
                return paths

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value=usage),
                patch("hero_engine.youtube_reporting_phase6.materialize_live") as reporting_again,
                patch("hero_engine.phase6_pilot.materialize_live", side_effect=metrics),
                patch("hero_engine.phase6_intelligence.materialize_current", side_effect=intelligence),
            ):
                recovered = run_phase6_observer_if_due(
                    root, token,
                    now=datetime(2026, 9, 5, 19, 0, 31, tzinfo=timezone.utc),
                )
            reporting_again.assert_not_called()
            self.assertEqual("COLLECTED", recovered["status"], recovered)

    def test_phase6_observer_blocks_before_api_when_free_quota_guard_fails(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json", "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes((ROOT / "config/zero-cost-policy.json").read_bytes())
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value={"youtube-general-units-daily": 9988, "youtube-videos-insert-daily": 0}),
                patch("hero_engine.youtube_reporting_phase6.materialize_live") as reporting,
                patch("hero_engine.phase6_pilot.materialize_live") as metrics,
            ):
                value = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc)
                )
            self.assertEqual("BLOCKED", value["status"])
            self.assertEqual("PHASE6_OWNED_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED", value["error"])
            reporting.assert_not_called()
            metrics.assert_not_called()
            saved = json.loads((root / "output/operations/zero-cost/phase6-owned-metrics-preflight.json").read_text(encoding="utf-8"))
            self.assertFalse(saved["execution_permitted"])
            from hero_engine.queue_phase6 import TransactionalQueue

            job = TransactionalQueue(root).snapshot(captured_at=datetime(2026, 9, 5, 19, tzinfo=timezone.utc))["jobs"][0]
            self.assertEqual("RETRY_WAIT", job["state"])
            self.assertEqual(0, job["attempt_count"])
            self.assertEqual("2026-09-05T19:05:00Z", job["available_at"])

    def test_atomic_quota_race_defers_without_data_api_or_attempt_consumption(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json",
                "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json",
                "youtube_reporting_job_registry.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes(
                (ROOT / "config/zero-cost-policy.json").read_bytes()
            )
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            registry = root / "job-registry.json"
            registry.write_bytes(
                (ROOT / "output/operations/phase6/reporting/job-registry.json").read_bytes()
            )
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            with (
                patch(
                    "hero_engine.central_manager_phase5._quota_usage",
                    side_effect=[
                        {"youtube-general-units-daily": 5, "youtube-videos-insert-daily": 0},
                        {"youtube-general-units-daily": 9987, "youtube-videos-insert-daily": 0},
                    ],
                ),
                patch("hero_engine.youtube_reporting_phase6.materialize_live", return_value=registry) as reporting,
                patch("hero_engine.phase6_pilot.materialize_live") as metrics,
            ):
                value = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc),
                )
            self.assertEqual("BLOCKED", value["status"], value)
            self.assertIn("ATOMIC_QUOTA_RESERVATION_BLOCKED", value["error"])
            reporting.assert_called_once()
            metrics.assert_not_called()
            from hero_engine.queue_phase6 import TransactionalQueue

            job = TransactionalQueue(root).snapshot()["jobs"][0]
            self.assertEqual("RETRY_WAIT", job["state"])
            self.assertEqual(0, job["attempt_count"])
            self.assertEqual("2026-09-05T19:05:00Z", job["available_at"])

    def test_owned_observer_retry_reuses_hash_bound_external_reads(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json", "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json", "youtube_reporting_job_registry.schema.json",
                "own_channel_performance_snapshot.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes((ROOT / "config/zero-cost-policy.json").read_bytes())
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            source_metrics = ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest.parent.mkdir(parents=True)
            initial_value = json.loads(source_metrics.read_text(encoding="utf-8-sig"))
            initial_value["next_observation_at"] = "2026-09-05T18:45:51Z"
            latest.write_text(json.dumps(initial_value), encoding="utf-8")
            snapshot = latest.parent / "collected.json"
            collected_value = json.loads(source_metrics.read_text(encoding="utf-8-sig"))
            collected_value["snapshot_id"] = "own-performance-iK_5edYQtx8-20260905T190000Z"
            collected_value["captured_at"] = "2026-09-05T19:00:00Z"
            collected_value["next_observation_at"] = "2026-09-07T18:45:51Z"
            snapshot.write_text(json.dumps(collected_value), encoding="utf-8")
            registry = root / "job-registry.json"
            registry.write_bytes((ROOT / "output/operations/phase6/reporting/job-registry.json").read_bytes())
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")
            usage = {"youtube-general-units-daily": 5, "youtube-videos-insert-daily": 0}

            def collected_metrics(*args, **kwargs):
                latest.write_bytes(snapshot.read_bytes())
                return snapshot

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value=usage),
                patch("hero_engine.youtube_reporting_phase6.materialize_live", return_value=registry),
                patch("hero_engine.phase6_pilot.materialize_live", side_effect=collected_metrics),
                patch("hero_engine.phase6_intelligence.materialize_current", side_effect=RuntimeError("intelligence fault")),
            ):
                failed = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc)
                )
            self.assertEqual("ERROR", failed["status"])

            def recovered_intelligence(*args, **kwargs):
                paths = (root / "prediction.json", root / "diagnosis.json", root / "experiment.json")
                for path in paths:
                    path.write_text("{}", encoding="utf-8")
                return paths

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value=None),
                patch("hero_engine.youtube_reporting_phase6.materialize_live") as reporting_again,
                patch("hero_engine.phase6_pilot.materialize_live") as metrics_again,
                patch("hero_engine.phase6_intelligence.materialize_current", side_effect=recovered_intelligence),
            ):
                recovered = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, 31, tzinfo=timezone.utc)
                )
            reporting_again.assert_not_called()
            metrics_again.assert_not_called()
            self.assertEqual("COLLECTED", recovered["status"], recovered)
            from hero_engine.queue_phase6 import TransactionalQueue

            job = TransactionalQueue(root).snapshot(
                captured_at=datetime(2026, 9, 5, 19, 0, 31, tzinfo=timezone.utc)
            )["jobs"][0]
            self.assertEqual("SUCCEEDED", job["state"])
            self.assertTrue(job["checkpoint"]["quota_preflight_hash"].startswith("sha256:"))
            self.assertTrue(job["checkpoint"]["reporting_registry_hash"].startswith("sha256:"))
            self.assertTrue(job["checkpoint"]["metrics_snapshot_hash"].startswith("sha256:"))
            self.assertEqual(1, len(job["checkpoint"]["quota_debit_ids"]))
            self.assertEqual("CONSUMED", job["checkpoint"]["quota_debit"]["state"])

    def test_committed_observer_protocol_activation_is_crash_recoverable(self) -> None:
        with tempfile.TemporaryDirectory() as workspace:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "prediction_record.schema.json",
                "phase6_diagnostic_decision.schema.json",
                "phase6_experiment_protocol.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/engine.json").write_bytes((ROOT / "config/engine.json").read_bytes())
            source = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            source["snapshot_id"] = "owned-d1-committed-before-activation"
            source["captured_at"] = "2026-09-05T13:00:00Z"
            source["age_hours"] = 24.25
            source["public_metrics"]["viewCount"] = 2
            source["sources"]["youtube_data_api"]["status"] = "PASS"
            latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest.parent.mkdir(parents=True)
            latest.write_text(json.dumps(source), encoding="utf-8")

            from hero_engine.phase6_intelligence import materialize_current
            from hero_engine.queue_phase6 import TransactionalQueue

            prediction, diagnosis, staged = materialize_current(root)
            active = root / "output/operations/phase6/intelligence/experiments/active.json"
            self.assertFalse(active.exists())
            now = datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc)
            queue = TransactionalQueue(root)
            job = queue.enqueue(
                idempotency_key="phase6-owned-metrics:2026-09-05T18:45:51Z",
                operation_id="heroverse-phase6-controlled-longform-v1",
                channel_id="UCuMF6pJQkyMzaVoAxFL86yA",
                task_type="OWNED_METRICS_CHECKPOINT",
                payload={"video_id": "iK_5edYQtx8", "scheduled_window": "2026-09-05T18:45:51Z"},
                now=now,
            )
            leased = queue.claim_job(
                job["job_id"], worker_id="fixture-worker",
                expected_task_type="OWNED_METRICS_CHECKPOINT", now=now,
            )
            checkpoint = {
                "observer_transaction_version": "phase6-owned-observer-transaction-v2",
                "baseline_snapshot_id": source["snapshot_id"],
                "prediction_record": prediction.relative_to(root).as_posix(),
                "prediction_record_hash": "sha256:" + hashlib.sha256(prediction.read_bytes()).hexdigest(),
                "diagnostic_decision": diagnosis.relative_to(root).as_posix(),
                "diagnostic_decision_hash": "sha256:" + hashlib.sha256(diagnosis.read_bytes()).hexdigest(),
                "experiment_protocol": staged.relative_to(root).as_posix(),
                "experiment_protocol_stage": staged.relative_to(root).as_posix(),
                "experiment_protocol_stage_hash": "sha256:" + hashlib.sha256(staged.read_bytes()).hexdigest(),
            }
            real_succeed = queue.succeed

            def ambiguous_commit(*args, **kwargs):
                real_succeed(*args, **kwargs)
                raise OSError("simulated lost acknowledgement after SQLite commit")

            with (
                patch.object(queue, "succeed", side_effect=ambiguous_commit),
                self.assertRaisesRegex(OSError, "lost acknowledgement"),
            ):
                _commit_owned_observer_transaction(
                    root,
                    queue=queue,
                    claimed=leased,
                    completion_checkpoint=checkpoint,
                    experiment_path=staged,
                    now=now,
                )
            committed = queue.get_by_idempotency_key(
                "phase6-owned-metrics:2026-09-05T18:45:51Z"
            )
            self.assertEqual("SUCCEEDED", committed["state"])
            self.assertFalse(active.exists())

            self.assertTrue(_recover_committed_protocol_activation(root, queue))
            self.assertEqual(staged.read_bytes(), active.read_bytes())
            self.assertEqual(
                active.read_bytes(),
                (active.parent / "latest.json").read_bytes(),
            )

            protocol = json.loads(active.read_text(encoding="utf-8"))
            pinned_diagnosis = root / protocol["diagnosis"]["path"]
            diagnosis_bytes = pinned_diagnosis.read_bytes()
            pinned_diagnosis.write_bytes(diagnosis_bytes + b" ")
            with self.assertRaisesRegex(PermissionError, "diagnosis hash"):
                _recover_committed_protocol_activation(root, queue)
            pinned_diagnosis.write_bytes(diagnosis_bytes)

            staged_bytes = staged.read_bytes()
            staged.write_bytes(staged_bytes + b" ")
            with self.assertRaises(PermissionError):
                _recover_committed_protocol_activation(root, queue)
            staged.write_bytes(staged_bytes)
            self.assertFalse(_recover_committed_protocol_activation(root, queue))

    def test_observer_prevalidates_before_success_and_reentry_only_revalidates(self) -> None:
        with tempfile.TemporaryDirectory() as workspace:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "prediction_record.schema.json",
                "phase6_diagnostic_decision.schema.json",
                "phase6_experiment_protocol.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/engine.json").write_bytes((ROOT / "config/engine.json").read_bytes())
            source = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json")
                .read_text(encoding="utf-8-sig")
            )
            source["snapshot_id"] = "owned-d1-activate-before-success"
            source["captured_at"] = "2026-09-05T13:00:00Z"
            source["age_hours"] = 24.25
            source["public_metrics"]["viewCount"] = 2
            source["sources"]["youtube_data_api"]["status"] = "PASS"
            latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest.parent.mkdir(parents=True)
            latest.write_text(json.dumps(source), encoding="utf-8")

            from hero_engine.phase6_intelligence import materialize_current

            prediction, diagnosis, staged = materialize_current(root)
            active = root / "output/operations/phase6/intelligence/experiments/active.json"
            claimed = {
                "job_id": "job-observer-activation-order",
                "state": "LEASED",
                "lease_owner": "observer-worker",
                "task_type": "OWNED_METRICS_CHECKPOINT",
                "operation_id": "heroverse-phase6-controlled-longform-v1",
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "payload": {"video_id": "iK_5edYQtx8"},
                "checkpoint": {},
            }
            events = []

            class RecordingQueue:
                def checkpoint(self, job_id, *, worker_id, value, now):
                    events.append(("checkpoint", value.get("experiment_protocol_state")))
                    return {**claimed, "checkpoint": dict(value)}

                def succeed(self, job_id, *, worker_id, checkpoint, now):
                    if checkpoint.get("experiment_protocol_state") == "ACTIVATION_VALIDATED":
                        self_test.assertFalse(active.exists())
                    else:
                        self_test.assertTrue(active.is_file())
                    events.append(("succeed", checkpoint.get("experiment_protocol_state")))
                    return {**claimed, "state": "SUCCEEDED", "lease_owner": None, "checkpoint": dict(checkpoint)}

            self_test = self
            base_checkpoint = {
                "observer_transaction_version": "phase6-owned-observer-transaction-v2",
                "baseline_snapshot_id": source["snapshot_id"],
                "prediction_record": prediction.relative_to(root).as_posix(),
                "prediction_record_hash": "sha256:" + hashlib.sha256(prediction.read_bytes()).hexdigest(),
                "diagnostic_decision": diagnosis.relative_to(root).as_posix(),
                "diagnostic_decision_hash": "sha256:" + hashlib.sha256(diagnosis.read_bytes()).hexdigest(),
                "experiment_protocol": staged.relative_to(root).as_posix(),
                "experiment_protocol_stage": staged.relative_to(root).as_posix(),
                "experiment_protocol_stage_hash": "sha256:" + hashlib.sha256(staged.read_bytes()).hexdigest(),
            }

            class FailedBeforeCommitQueue(RecordingQueue):
                def succeed(self, job_id, *, worker_id, checkpoint, now):
                    self_test.assertFalse(active.exists())
                    events.append(("succeed-failed", checkpoint.get("experiment_protocol_state")))
                    raise OSError("simulated SQLite failure before commit")

            with self.assertRaisesRegex(OSError, "before commit"):
                _commit_owned_observer_transaction(
                    root,
                    queue=FailedBeforeCommitQueue(),
                    claimed=claimed,
                    completion_checkpoint=base_checkpoint,
                    experiment_path=staged,
                    now=datetime(2026, 9, 5, 18, 58, tzinfo=timezone.utc),
                )
            self.assertFalse(active.exists())
            self.assertEqual(
                [("checkpoint", "ACTIVATION_VALIDATED"), ("succeed-failed", "ACTIVATION_VALIDATED")],
                events,
            )

            events.clear()
            with patch(
                "hero_engine.phase6_intelligence.activate_preregistered_protocol",
                side_effect=OSError("simulated activation write fault"),
            ):
                _, durable_job, write_error = _commit_owned_observer_transaction(
                    root,
                    queue=RecordingQueue(),
                    claimed=claimed,
                    completion_checkpoint=base_checkpoint,
                    experiment_path=staged,
                    now=datetime(2026, 9, 5, 18, 59, tzinfo=timezone.utc),
                )
            self.assertEqual("SUCCEEDED", durable_job["state"])
            self.assertIsInstance(write_error, OSError)
            self.assertFalse(active.exists())
            self.assertEqual(
                [("checkpoint", "ACTIVATION_VALIDATED"), ("succeed", "ACTIVATION_VALIDATED")],
                events,
            )

            events.clear()
            _, first_completed, activation_error = _commit_owned_observer_transaction(
                root,
                queue=RecordingQueue(),
                claimed=claimed,
                completion_checkpoint=base_checkpoint,
                experiment_path=staged,
                now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc),
            )
            self.assertIsNone(activation_error)
            self.assertEqual(
                [("checkpoint", "ACTIVATION_VALIDATED"), ("succeed", "ACTIVATION_VALIDATED")],
                events,
            )
            self.assertEqual("SUCCEEDED", first_completed["state"])

            events.clear()
            later = dict(source)
            later["snapshot_id"] = "owned-d1-lag-retry-with-active"
            later["captured_at"] = "2026-09-05T21:12:52Z"
            latest.write_text(json.dumps(later), encoding="utf-8")
            _, later_diagnosis, active_result = materialize_current(root)
            self.assertEqual(active.resolve(), active_result.resolve())
            later_checkpoint = {
                **base_checkpoint,
                "baseline_snapshot_id": later["snapshot_id"],
                "diagnostic_decision": later_diagnosis.relative_to(root).as_posix(),
                "diagnostic_decision_hash": "sha256:" + hashlib.sha256(later_diagnosis.read_bytes()).hexdigest(),
                "experiment_protocol": active.relative_to(root).as_posix(),
                "experiment_protocol_stage": active.relative_to(root).as_posix(),
                "experiment_protocol_stage_hash": "sha256:" + hashlib.sha256(active.read_bytes()).hexdigest(),
            }
            with patch("hero_engine.phase6_intelligence.activate_preregistered_protocol") as activate:
                _, replay_completed, replay_error = _commit_owned_observer_transaction(
                    root,
                    queue=RecordingQueue(),
                    claimed=claimed,
                    completion_checkpoint=later_checkpoint,
                    experiment_path=active,
                    now=datetime(2026, 9, 5, 21, 13, tzinfo=timezone.utc),
                )
            self.assertIsNone(replay_error)
            activate.assert_not_called()
            self.assertEqual(
                [("checkpoint", "ALREADY_ACTIVE_VERIFIED"), ("succeed", "ALREADY_ACTIVE_VERIFIED")],
                events,
            )
            self.assertNotIn("experiment_protocol_stage", replay_completed["checkpoint"])
            self.assertEqual(active.read_bytes(), (active.parent / "latest.json").read_bytes())

    def test_owned_metrics_raw_journal_survives_crash_without_second_api_or_debit(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "phase6_observer_runtime.schema.json",
                "phase6_queue_snapshot.schema.json",
                "zero_cost_guard.schema.json",
                "youtube_reporting_job_registry.schema.json",
                "own_channel_performance_snapshot.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            (root / "config").mkdir(parents=True)
            (root / "config/zero-cost-policy.json").write_bytes(
                (ROOT / "config/zero-cost-policy.json").read_bytes()
            )
            plan = root / "output/operations/phase6/pilot-plan.json"
            plan.parent.mkdir(parents=True)
            plan.write_text("{}", encoding="utf-8")
            self._write_publication_receipt(root)
            source = json.loads(
                (ROOT / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json").read_text(
                    encoding="utf-8-sig"
                )
            )
            source["snapshot_id"] = "owned-d1-crash-journal"
            source["captured_at"] = "2026-09-05T19:00:00Z"
            source["next_observation_at"] = "2026-09-07T18:45:51Z"
            latest = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
            latest.parent.mkdir(parents=True)
            initial = dict(source)
            initial["captured_at"] = "2026-09-04T19:00:00Z"
            initial["next_observation_at"] = "2026-09-05T18:45:51Z"
            latest.write_text(json.dumps(initial), encoding="utf-8")
            registry = root / "job-registry.json"
            registry.write_bytes(
                (ROOT / "output/operations/phase6/reporting/job-registry.json").read_bytes()
            )
            token = Path(secrets) / "token.json"
            token.write_text("{}", encoding="utf-8")

            def crash_after_raw(*args, **kwargs):
                destination = kwargs["immutable_destination"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(
                    json.dumps(source, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                    newline="\n",
                )
                raise RuntimeError("simulated crash after immutable raw snapshot")

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value={"youtube-general-units-daily": 5, "youtube-videos-insert-daily": 0}),
                patch("hero_engine.youtube_reporting_phase6.materialize_live", return_value=registry),
                patch("hero_engine.phase6_pilot.materialize_live", side_effect=crash_after_raw) as first_metrics,
            ):
                failed = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, tzinfo=timezone.utc),
                )
            self.assertEqual("ERROR", failed["status"])
            first_metrics.assert_called_once()

            def recovered_intelligence(*args, **kwargs):
                paths = (root / "prediction.json", root / "diagnosis.json", root / "experiment.json")
                for path in paths:
                    path.write_text("{}", encoding="utf-8")
                return paths

            with (
                patch("hero_engine.central_manager_phase5._quota_usage", return_value={"youtube-general-units-daily": 7, "youtube-videos-insert-daily": 0}),
                patch("hero_engine.youtube_reporting_phase6.materialize_live") as reporting_again,
                patch("hero_engine.phase6_pilot.materialize_live") as metrics_again,
                patch("hero_engine.phase6_intelligence.materialize_current", side_effect=recovered_intelligence),
            ):
                recovered = run_phase6_observer_if_due(
                    root, token, now=datetime(2026, 9, 5, 19, 0, 31, tzinfo=timezone.utc),
                )
            self.assertEqual("COLLECTED", recovered["status"], recovered)
            reporting_again.assert_not_called()
            metrics_again.assert_not_called()

            from hero_engine.phase6_quota import get_general_quota_debit
            from hero_engine.queue_phase6 import TransactionalQueue

            job = TransactionalQueue(root).snapshot()["jobs"][0]
            self.assertEqual(2, job["attempt_count"])
            self.assertEqual(1, len(job["checkpoint"]["quota_debit_ids"]))
            debit = get_general_quota_debit(
                root,
                idempotency_key=job["checkpoint"]["quota_debit"]["idempotency_key"],
            )
            self.assertEqual("CONSUMED", debit["state"])
            self.assertEqual(1, debit["attempt_count"])

    def test_private_staging_forces_processing_retry_without_input_drift(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            status = root / "output/runtime/gestor-central/status.json"
            status.parent.mkdir(parents=True)
            status.write_text(json.dumps({"publication_status": "STAGED_PRIVATE_AWAITING_PROCESSING"}), encoding="utf-8")
            self.assertTrue(_publication_retry_due(root))
            status.write_text(json.dumps({"publication_status": "COMPLETE_PUBLIC"}), encoding="utf-8")
            self.assertFalse(_publication_retry_due(root))

    def test_real_cycle_is_active_zero_cost_and_executes_only_ready_release(self) -> None:
        # Exercise real orchestration/gates against synthetic, temporary inputs.
        # This is not a perceptual qualification or permission to publish a video.
        import builtins
        import io
        import os
        import sqlite3
        from contextlib import ExitStack
        from hero_engine import central_manager_phase5 as manager
        # Resolve packaged timezone data before forbidding non-fixture file IO.
        # Importing this module does not initialize an operational database.
        from hero_engine import phase6_quota  # noqa: F401
        from hero_engine.youtube_integration import INTEGRATION_SCOPES

        with tempfile.TemporaryDirectory(prefix="phase5-cycle-fixture-") as temporary:
            root = Path(temporary).resolve()
            v3 = root / "output/production/phase5/pilot-001/creative-v3"
            runtime = root / "output/runtime/gestor-central"

            def write_json(path, value):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(value), encoding="utf-8")

            def artifact(path, payload):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(payload)
                return hashlib.sha256(payload).hexdigest()

            for name in (
                "central_manager_runtime.schema.json", "phase5_release_gate.schema.json",
                "phase5_autonomous_quality_evaluation.schema.json", "zero_cost_guard.schema.json",
                "oauth_runtime_scope_requirement.schema.json", "youtube_quota_observation.schema.json",
                "phase6_quota_accounting.schema.json",
            ):
                artifact(root / "schemas" / name, (ROOT / "schemas" / name).read_bytes())

            video = v3 / "standard-qualification/candidate.fixture"
            video_hash = artifact(video, b"synthetic-frozen-candidate-not-a-video")
            words = ["TRUTH", "RESPONSIBILITY", "TODAY"] + ["faith"] * 537
            full_text = " ".join(words)
            chunks, offset = [], 0
            for number in range(72):
                length = 8 if number < 36 else 7
                chunks.append(" ".join(words[offset:offset + length]))
                offset += length
            captions = v3 / "captions/en-US.srt"
            caption_hash = artifact(captions, "\n\n".join(
                f"{number + 1}\n00:00:00,000 --> 00:00:01,000\n{text}"
                for number, text in enumerate(chunks)
            ).encode("utf-8"))
            thumb = v3 / "thumbnail/selected.fixture"
            thumb_hash = artifact(thumb, b"synthetic-thumbnail-not-an-image")
            takes, assets = [], []
            for number in range(72):
                evidence = v3 / f"rights/fixture-source-{number:03d}.txt"
                artifact(evidence, f"synthetic rights evidence {number}".encode())
                takes.append({
                    "narrative_function": f"fixture-function-{number % 9}",
                    "information": chunks[number], "action": "illustrate fixture",
                    "semantic_alignment": "fixture alignment", "retention_job": "fixture promise",
                    "asset_origin": f"procedural://fixture/{number}", "rights": {"status": "OWNED"},
                    "format_pack_id": "fp-broll-cinematic-narration", "on_screen_text": None,
                })
                assets.append({"used_ranges": [[0, 1]], "production_eligible": True,
                               "rights_status": "OWNED", "rights_evidence_uri": str(evidence),
                               "source": f"procedural://fixture/{number}"})
            write_json(v3 / "take_plan.json", {"takes": takes})
            write_json(v3 / "asset_manifest.allocated.json", {"assets": assets})
            write_json(v3 / "narrative_script.json", {
                "full_text": full_text, "word_count": len(words), "hook_windows": [{"fixture": n} for n in range(4)],
                "sections": [{"fixture": n} for n in range(9)],
            })
            write_json(v3 / "standard-qualification/standard_qualification_report.json", {
                "qualification_id": "qualification-cycle-fixture", "candidate": {
                    "path": str(video), "content_hash": "sha256:" + video_hash, "duration_ms": 238700,
                },
            })
            write_json(v3 / "qa/creative_quality_gate_report.json", {"gates": [{"status": "PASS"}]})
            write_json(v3 / "qa/creative_revision_metrics.json", {"automatic_status": "PASS", "checks": []})
            write_json(v3 / "qa/technical_measurements.json", {
                "captions": {"cue_count": 72, "coverage_ratio": 1.0, "maximum_words_per_cue": 8, "manifest_hash_matches": True},
                "signalstats": {"sample_count": 480, "within_take_luminance_delta_p95": 2,
                                "flicker_threshold_p95": 15, "hard_transition_count": 0},
                "black_freeze": {"black_event_count": 0, "freeze_event_count": 0},
                "timeline": {"contiguous": True, "no_adjacent_source_repeat": True, "absolute_duration_error_ms": 0,
                             "maximum_take_duration_error_ms": 0, "maximum_cumulative_drift_ms": 0},
                "visual_repetition": {"passed": True, "maximum_single_asset": {"share": 1 / 72}, "top_six_runtime_share": 6 / 72},
                "originality": {"maximum_target_trigram_overlap": 0.01, "threshold": 0.1},
                "hook": {"timing_status": "PASS", "distinct_sources": ["a", "b", "c"], "visual_event_count": 7,
                         "voice_durations_ms": [900, 1800]},
                "landscape": {"passed": True, "share": 0},
                "loudness": {"integrated_lufs": -16, "true_peak_dbtp": -1.5, "lra_lu": 4},
            })
            write_json(v3 / "thumbnail/thumbnail_set_manifest.json", {
                "automatic_recommendation": "B", "automatic_recommendation_basis": "synthetic fixture rubric",
                "candidates": [{"candidate_id": "B", "path": str(thumb), "content_hash": "sha256:" + thumb_hash,
                                "automated_status": "PASS"}],
            })
            write_json(v3 / "publication_package.json", {
                "package_id": "publication-package-cycle-fixture",
                "video": {"path": str(video), "sha256": video_hash},
                "captions": {"path": str(captions), "sha256": caption_hash, "cue_count": 72},
                "metadata": {"title": "A 24-hour fixture", "privacy_status": "private"},
                "rights": {"status": "PASS_AUTOMATIC", "manifest": str(v3 / "asset_manifest.allocated.json"),
                           "attribution": "Synthetic test inputs only"},
                "quality_gate": {"automatic_status": "PASS", "report": str(v3 / "qa/creative_quality_gate_report.json")},
                "disclosure": {"contains_synthetic_media": True},
            })
            write_json(root / "output/production/phase5/pilot-001/creative-v2/qa/market_readiness_review.json",
                       {"verdict": "REJECTED_FOR_PUBLICATION", "gates": [{"status": "FAIL"}]})
            write_json(root / "data/gold_standard/validation_report.json", {"passed": True, "totals": {"videos": 4}})
            write_json(root / "config/format_packs/fp-broll-cinematic-narration-v1.json",
                       {"capability_status": "LIMITED", "production_allowed": True})
            write_json(v3 / "autonomous-review/format_pack_transition_receipt.json",
                       {"basis": "AUTONOMOUS_QUALITY_PASS_WITH_HUMAN_GOLD_STANDARD_AND_CANARY_LIMIT"})
            # Supply perception observations as fixture input, not a mocked gate result.
            asr_fixture = {"provider": "fixture", "language": "en", "text": full_text}
            integration = root / "output/integrations/youtube/heroverse"
            write_json(root / "config/integrations/youtube-heroverse-v1.json",
                       {"integration_id": "youtube-heroverse-v1", "oauth": {"scopes": INTEGRATION_SCOPES}})
            write_json(integration / "connection-receipt.json", {"authorization": {"granted_scopes": INTEGRATION_SCOPES}})
            write_json(integration / "google-auth-platform-observation.json", {"declared_scopes": {
                "non_sensitive_count": 0, "sensitive_count": 4, "restricted_count": 0, "configuration_matches_runtime": True,
            }})
            write_json(integration / "operational-readiness.json",
                       {"continuous_operation_ready": True, "publication_guard": {"upload_permitted": True}})
            write_json(integration / "quota-observation.json", {
                "schema_version": "1.0.0", "observation_id": "quota-observation-cycle-fixture",
                "project_id": json.loads((root / "schemas/youtube_quota_observation.schema.json").read_text(encoding="utf-8"))["properties"]["project_id"]["const"],
                "status": "PASS", "billing_enabled": False,
                "observed_usage": {"youtube-videos-insert-daily": 0, "youtube-general-units-daily": 0},
                "limits": {"youtube-videos-insert-daily": 100, "youtube-general-units-daily": 10000},
                "renewal": "MIDNIGHT_PACIFIC_TIME", "evidence_method": "synthetic isolated fixture",
                "observed_at": "2026-09-03T21:00:00Z",
            })
            write_json(root / "config/zero-cost-policy.json", {
                "policy_id": "zero-cost-operation-v1", "technical_cost_brl": 0,
                "resources": [{"resource_id": name, "cost_brl": 0, "billing_required": False,
                               "quota_limit": limit, "renewal": "MIDNIGHT_PACIFIC_TIME", "fallback": "defer",
                               "quality_status": "PASS", "evidence": ["synthetic test fixture"]}
                              for name, limit in (("youtube-general-units-daily", 10000), ("youtube-videos-insert-daily", 100))],
            })
            channel_audit = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
            write_json(channel_audit, {"overall_status": "PASS", "publication_gate": {"critical_open_gates": []}})
            pause_path = runtime / "PAUSE"
            pause_bytes = b"isolated owner pause; never the operational marker"
            artifact(pause_path, pause_bytes)
            token = root / "synthetic-token.fixture"
            artifact(token, b"not-an-oauth-credential")

            real_builtin_open, real_io_open = builtins.open, io.open
            real_replace, real_unlink, real_os_open, real_mkdir = os.replace, os.unlink, os.open, os.mkdir
            real_connect = sqlite3.connect
            observed_writes = []

            def confined(path):
                if isinstance(path, int):
                    raise AssertionError("Unattributed descriptor is forbidden in this cycle test")
                resolved = Path(path).resolve()
                self.assertTrue(resolved.is_relative_to(root), f"Cycle escaped temporary root: {resolved}")
                return resolved

            def guarded_open(original):
                def checked(path, mode="r", *args, **kwargs):
                    target = confined(path)
                    if any(character in mode for character in "wax+"):
                        observed_writes.append(target)
                    return original(path, mode, *args, **kwargs)
                return checked

            def guarded_replace(source, destination, *args, **kwargs):
                confined(source)
                observed_writes.append(confined(destination))
                return real_replace(source, destination, *args, **kwargs)

            def guarded_unlink(path, *args, **kwargs):
                observed_writes.append(confined(path))
                return real_unlink(path, *args, **kwargs)

            def guarded_os_open(path, *args, **kwargs):
                confined(path)
                return real_os_open(path, *args, **kwargs)

            def guarded_mkdir(path, *args, **kwargs):
                observed_writes.append(confined(path))
                return real_mkdir(path, *args, **kwargs)

            def guarded_connect(database, *args, **kwargs):
                from urllib.parse import unquote, urlsplit
                value = str(database)
                candidate = unquote(urlsplit(value).path) if value.startswith("file:") else value
                confined(candidate)
                return real_connect(database, *args, **kwargs)

            youtube, media_factory = object(), object()
            with ExitStack() as isolation:
                isolation.enter_context(patch.dict(os.environ, {"HERO_YT_TOKEN_PATH": str(token)}, clear=True))
                for target, replacement in (
                    ("builtins.open", guarded_open(real_builtin_open)), ("io.open", guarded_open(real_io_open)),
                    ("os.replace", guarded_replace), ("os.unlink", guarded_unlink), ("os.open", guarded_os_open),
                    ("os.mkdir", guarded_mkdir), ("sqlite3.connect", guarded_connect),
                ):
                    isolation.enter_context(patch(target, side_effect=replacement))
                for target in ("socket.socket.connect", "socket.socket.connect_ex", "socket.create_connection",
                               "subprocess.Popen", "os.system", "threading.Thread.start"):
                    isolation.enter_context(patch(target, side_effect=AssertionError("External effect forbidden in isolated cycle")))
                asr = isolation.enter_context(patch("hero_engine.phase5_autonomous_quality._asr", return_value=asr_fixture))
                readiness = isolation.enter_context(patch("hero_engine.central_manager_phase5.materialize_oauth_readiness"))
                probe = isolation.enter_context(patch("hero_engine.oauth_scope_requirements._subtitle_stream_count", return_value=0))
                service = isolation.enter_context(patch("hero_engine.central_manager_phase5._build_live_service",
                                                       return_value=(youtube, media_factory)))
                publish = isolation.enter_context(patch("hero_engine.central_manager_phase5.execute_publication_pipeline",
                                                       return_value={"status": "COMPLETE_PUBLIC"}))
                quality = isolation.enter_context(patch("hero_engine.central_manager_phase5.materialize_autonomous_quality",
                                                       wraps=manager.materialize_autonomous_quality))
                paused = run_cycle(root)
                self.assertEqual("PAUSED", paused["mode"])
                self.assertEqual(["OPERATOR_PAUSE_FILE_PRESENT"], paused["blockers"])
                self.assertEqual(pause_bytes, pause_path.read_bytes())
                quality.assert_not_called()
                asr.assert_not_called()
                readiness.assert_not_called()
                service.assert_not_called()
                publish.assert_not_called()

                pause_path.unlink()  # Only the explicitly confined simulated pause.
                status = run_cycle(root)
                self.assertEqual("ACTIVE", status["mode"])
                self.assertEqual(0, status["technical_cost_brl"])
                self.assertEqual("READY_FOR_PUBLICATION_PIPELINE", status["release_decision"], status)
                self.assertEqual("COMPLETE_PUBLIC", status["publication_status"])
                self.assertEqual([], status["blockers"])
                publish.assert_called_once_with(youtube, media_factory, root)
                service.assert_called_once_with(token)
                readiness.assert_called_once_with(root, token_file=token)
                probe.assert_called_once_with(video)
                asr.assert_called_once_with(video)
                report = json.loads((v3 / "autonomous-review/autonomous_quality_evaluation.json").read_text(encoding="utf-8"))
                self.assertEqual(12, len(report["gates"]))
                self.assertTrue(all(item["status"] == "PASS" for item in report["gates"]))
                release = json.loads((v3 / "release_gate.json").read_text(encoding="utf-8"))
                self.assertEqual(13, len(release["gates"]))
                self.assertTrue(all(item["status"] == "PASS" for item in release["gates"]))
                manifest = json.loads((v3.parent / "integrity_manifest.json").read_text(encoding="utf-8"))
                self.assertGreater(manifest["item_count"], 70)
                self.assertEqual(len(manifest["entries"]), manifest["item_count"])
                for item in manifest["entries"]:
                    path = confined(v3.parent / item["artifact"])
                    self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), item["sha256"])

                write_json(channel_audit, {"overall_status": "BLOCKED", "publication_gate": {"critical_open_gates": ["FIXTURE_GATE"]}})
                blocked = run_cycle(root)
                self.assertEqual("ACTIVE", blocked["mode"])
                self.assertEqual("BLOCKED", blocked["release_decision"])
                self.assertEqual("BLOCKED", blocked["publication_status"])
                self.assertIn("CHANNEL_READINESS", blocked["blockers"])
                publish.assert_called_once_with(youtube, media_factory, root)
                service.assert_called_once_with(token)
                artifact(pause_path, pause_bytes)
                last_quality_count = quality.call_count
                paused_again = run_cycle(root)
                self.assertEqual("PAUSED", paused_again["mode"])
                self.assertEqual(0, paused_again["technical_cost_brl"])
                self.assertEqual(pause_bytes, pause_path.read_bytes())
                self.assertEqual(last_quality_count, quality.call_count)
                asr.assert_called_once_with(video)
                publish.assert_called_once_with(youtube, media_factory, root)
                self.assertTrue(observed_writes)
                self.assertTrue(all(path.is_relative_to(root) for path in observed_writes))

    def test_quota_observation_is_schema_checked_before_use(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "youtube_quota_observation.schema.json",
                "phase6_quota_accounting.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            target = root / "output/integrations/youtube/heroverse/quota-observation.json"
            target.parent.mkdir(parents=True)
            target.write_text(json.dumps({
                "schema_version": "1.0.0",
                "observation_id": "quota-observation-test",
                "project_id": "graphic-tide-490010-u9",
                "status": "PASS",
                "billing_enabled": False,
                "observed_usage": {
                    "youtube-videos-insert-daily": 0,
                    "youtube-general-units-daily": 250
                },
                "limits": {
                    "youtube-videos-insert-daily": 100,
                    "youtube-general-units-daily": 10000
                },
                "renewal": "MIDNIGHT_PACIFIC_TIME",
                "evidence_method": "authenticated console read-only observation",
                "observed_at": "2026-09-03T21:00:00Z"
            }), encoding="utf-8")
            self.assertEqual({
                "youtube-videos-insert-daily": 0,
                "youtube-general-units-daily": 2000
            }, _quota_usage(root))

    def test_input_fingerprint_is_stable_without_input_change(self) -> None:
        self.assertEqual(input_fingerprint(ROOT), input_fingerprint(ROOT))

    def test_real_quota_usage_includes_vidiq_free_bucket_without_faking_youtube_usage(self) -> None:
        import socket
        import sqlite3
        import subprocess
        from contextlib import ExitStack
        from hero_engine.phase6_quota import ACCOUNTING, LEDGER, OBSERVATION

        with tempfile.TemporaryDirectory(prefix="central-quota-test-") as folder, ExitStack() as guards:
            root = Path(folder).resolve()
            for name in ("youtube_quota_observation.schema.json", "phase6_quota_accounting.schema.json",
                         "vidiq_plugin_observation.schema.json"):
                destination = root / "schemas" / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes((ROOT / "schemas" / name).read_bytes())
            vidiq_relative = Path("output/market/vidiq/heroverse/2026-09-03/plugin-observation.json")
            vidiq_path = root / vidiq_relative
            vidiq_path.parent.mkdir(parents=True)
            vidiq_path.write_bytes((ROOT / vidiq_relative).read_bytes())
            observation = root / OBSERVATION
            observation.parent.mkdir(parents=True)
            observation.write_text(json.dumps({
                "schema_version": "1.0.0", "observation_id": "quota-observation-isolated-vidiq",
                "project_id": json.loads((root / "schemas/youtube_quota_observation.schema.json").read_text())["properties"]["project_id"]["const"],
                "status": "PASS", "billing_enabled": False,
                "observed_usage": {"youtube-videos-insert-daily": 2, "youtube-general-units-daily": 123},
                "limits": {"youtube-videos-insert-daily": 100, "youtube-general-units-daily": 10000},
                "renewal": "MIDNIGHT_PACIFIC_TIME", "evidence_method": "synthetic isolated quota fixture",
                "observed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            }), encoding="utf-8")
            original_open, original_connect = Path.open, sqlite3.connect

            def fixture_open(path, *args, **kwargs):
                self.assertTrue(path.resolve().is_relative_to(root), "quota file escaped fixture")
                return original_open(path, *args, **kwargs)

            def fixture_connect(database, *args, **kwargs):
                self.assertEqual((root / LEDGER).resolve(), Path(database).resolve())
                return original_connect(database, *args, **kwargs)

            guards.enter_context(patch.object(Path, "open", fixture_open))
            guards.enter_context(patch.object(sqlite3, "connect", fixture_connect))
            guards.enter_context(patch.object(subprocess, "Popen", side_effect=AssertionError("quota subprocess forbidden")))
            for method in ("connect", "connect_ex"):
                guards.enter_context(patch.object(socket.socket, method, side_effect=AssertionError("quota network forbidden")))
            usage = _quota_usage(root)
            self.assertIsNotNone(usage)
            self.assertEqual(55, usage["vidiq-renewable-free-credits"])
            self.assertEqual(2, usage["youtube-videos-insert-daily"])
            self.assertEqual(2123, usage["youtube-general-units-daily"])
            accounting = json.loads((root / ACCOUNTING).read_text(encoding="utf-8"))
            self.assertEqual({key: usage[key] for key in ("youtube-videos-insert-daily", "youtube-general-units-daily")},
                             accounting["effective_consumption_for_gate"])
            self.assertTrue((root / LEDGER).is_file())

    def test_manager_lock_is_os_exclusive_versioned_and_recoverable(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/central_manager_lock.schema.json").write_bytes(
                (ROOT / "schemas/central_manager_lock.schema.json").read_bytes()
            )
            with ManagerLock(root, lease_seconds=90) as first:
                held = json.loads((root / "output/runtime/gestor-central/manager-lock.json").read_text(encoding="utf-8"))
                self.assertEqual("HELD", held["state"])
                self.assertEqual(90, held["lease_seconds"])
                self.assertEqual(0, held["technical_cost_brl"])
                self.assertIsNotNone(first._heartbeat_thread)
                self.assertTrue(first._heartbeat_thread.is_alive())
                with self.assertRaises(ManagerAlreadyRunning):
                    ManagerLock(root, lease_seconds=90).acquire()
                first.heartbeat()
            self.assertIsNone(first._heartbeat_thread)
            released = json.loads((root / "output/runtime/gestor-central/manager-lock.json").read_text(encoding="utf-8"))
            self.assertEqual("RELEASED", released["state"])
            with ManagerLock(root, lease_seconds=90):
                reacquired = json.loads((root / "output/runtime/gestor-central/manager-lock.json").read_text(encoding="utf-8"))
                self.assertEqual("HELD", reacquired["state"])

    def test_media_exception_still_reaches_daily_channel_observer_in_same_loop(self) -> None:
        from contextlib import ExitStack

        from hero_engine import central_manager_phase5 as manager
        from hero_engine import maintenance_protocol
        from hero_engine import phase6_acceptance
        from hero_engine import phase6_channel_goal_observer
        from hero_engine import phase6_control_cycle
        from hero_engine import phase6_goal_trajectory
        from hero_engine import phase6_learning_runtime
        from hero_engine import phase6_media
        from hero_engine import phase6_package_treatment
        from hero_engine import phase6_prediction_runtime
        from hero_engine import phase6_publication
        from hero_engine import phase6_quality
        from hero_engine import phase6_release
        from hero_engine import phase6_reporting
        from hero_engine import phase6_transition

        events: list[str] = []

        class EndAfterOneLoop(BaseException):
            pass

        class OneLoopLock:
            acquired_at = "2026-09-06T00:00:00Z"

            def __init__(self, *args, **kwargs) -> None:
                self.heartbeat_count = 0

            def __enter__(self):
                return self

            def __exit__(self, *args) -> None:
                return None

            def heartbeat(self) -> dict:
                self.heartbeat_count += 1
                if self.heartbeat_count == 2:
                    raise EndAfterOneLoop()
                return {}

        def fail_media(*args, **kwargs) -> None:
            events.append("MEDIA")
            raise RuntimeError("fixture media failure")

        def observe_daily_channel(*args, **kwargs) -> dict:
            events.append("DAILY_OBSERVER")
            return {}

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with ExitStack() as stack:
                stack.enter_context(patch.object(manager, "ManagerLock", OneLoopLock))
                stack.enter_context(patch.object(manager, "_start_review_console", return_value=None))
                stack.enter_context(patch.object(manager, "_start_oauth_reconsent_watcher", return_value=None))
                stack.enter_context(patch.object(manager, "ensure_oauth_session_health", return_value={}))
                stack.enter_context(patch.object(manager, "input_fingerprint", return_value="0" * 64))
                stack.enter_context(patch.object(manager, "run_cycle", return_value={}))
                stack.enter_context(patch.object(manager, "run_phase6_observer_if_due", return_value={}))
                stack.enter_context(patch.object(manager, "run_phase6_treatment_executor", return_value={}))
                stack.enter_context(patch.object(manager, "_quota_usage", return_value={}))
                stack.enter_context(patch.object(maintenance_protocol, "publish_capability", return_value={}))
                stack.enter_context(patch.object(maintenance_protocol, "refresh_capability_token_binding", return_value={}))
                stack.enter_context(patch.object(maintenance_protocol, "maintenance_barrier", return_value=False))
                stack.enter_context(patch.object(phase6_prediction_runtime, "run_prediction_observer", return_value={}))
                stack.enter_context(patch.object(phase6_release, "run_phase6_release_preparer", return_value={}))
                stack.enter_context(patch.object(phase6_package_treatment, "run_phase6_package_treatment_executor", return_value={}))
                stack.enter_context(patch.object(phase6_media, "run_phase6_media_executor", side_effect=fail_media))
                stack.enter_context(patch.object(phase6_quality, "run_phase6_quality_executor", return_value={}))
                stack.enter_context(patch.object(phase6_publication, "run_phase6_publication_controller", return_value={}))
                stack.enter_context(patch.object(phase6_learning_runtime, "run_phase6_learning_observer", return_value={}))
                stack.enter_context(patch.object(phase6_channel_goal_observer, "run_daily_channel_goal_observer", side_effect=observe_daily_channel))
                stack.enter_context(patch.object(phase6_goal_trajectory, "materialize", return_value={}))
                stack.enter_context(patch.object(phase6_reporting, "materialize", return_value={}))
                stack.enter_context(patch.object(phase6_acceptance, "materialize", return_value={}))
                stack.enter_context(patch.object(phase6_transition, "run_phase6_transition", return_value={}))
                stack.enter_context(patch.object(phase6_control_cycle, "materialize", return_value={}))

                with self.assertRaises(EndAfterOneLoop):
                    manager.loop(root, interval_seconds=10)

            self.assertEqual(["MEDIA", "DAILY_OBSERVER"], events)
            media_status = json.loads(
                (root / "output/operations/phase6/media-executor-status.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual("ERROR", media_status["status"])
            self.assertEqual("WAIT", media_status["action"])
            self.assertEqual("NOT_CREATED", media_status["job_state"])
            self.assertFalse(media_status["publication_authorized"])
            self.assertIn("RuntimeError: fixture media failure", media_status["error"])

    def test_review_console_startup_fails_if_thread_dies_before_receipt(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with patch("hero_engine.central_manager_phase5.serve_review_console", return_value=None):
                with self.assertRaisesRegex(RuntimeError, "terminated before becoming ready"):
                    _start_review_console(Path(temporary), timeout_seconds=0.5)

    def test_review_console_default_startup_budget_covers_real_cold_start(self) -> None:
        import inspect

        timeout = inspect.signature(_start_review_console).parameters["timeout_seconds"].default
        self.assertEqual(30.0, timeout)

    def test_embedded_oauth_watcher_chains_proofs_under_manager_runtime(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/oauth_reconsent_watcher_runtime.schema.json").write_bytes(
                (ROOT / "schemas/oauth_reconsent_watcher_runtime.schema.json").read_bytes()
            )
            source = Path(secrets) / "source.json"
            destination = Path(secrets) / "runtime.json"
            token = {
                "token": "synthetic-access", "refresh_token": "synthetic-new-grant",
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": "synthetic-client", "client_secret": "synthetic-secret",
                "scopes": [
                    "https://www.googleapis.com/auth/youtube.readonly",
                    "https://www.googleapis.com/auth/yt-analytics.readonly",
                    "https://www.googleapis.com/auth/youtube.upload",
                    "https://www.googleapis.com/auth/youtube.force-ssl",
                ],
            }
            source.write_text(json.dumps(token), encoding="utf-8")
            destination.write_text(
                json.dumps({**token, "refresh_token": "synthetic-old-grant"}),
                encoding="utf-8",
            )
            refresh = {
                "status": "PASS",
                "identity_verified_after_refresh": True,
                "failure_code": None,
            }
            with (
                patch("hero_engine.central_manager_phase5.mirror_authorized_user_token") as mirror,
                patch("hero_engine.central_manager_phase5.prove_noninteractive_refresh", return_value=refresh) as prove,
                patch("hero_engine.central_manager_phase5.materialize_oauth_readiness") as readiness,
            ):
                _oauth_reconsent_worker(root, source, destination)
            mirror.assert_called_once()
            prove.assert_called_once()
            readiness.assert_called_once()
            status = json.loads((root / "output/runtime/gestor-central/oauth-reconsent-watcher.json").read_text(encoding="utf-8"))
            self.assertEqual("MIRRORED_AND_REFRESHED", status["status"])
            self.assertEqual("PASS", status["refresh_status"])
            self.assertTrue(status["identity_verified_after_refresh"])
            self.assertEqual(0, status["technical_cost_brl"])

    def test_existing_proven_chain_survives_source_sandbox_boundary(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in (
                "oauth_token_mirror_receipt.schema.json",
                "oauth_noninteractive_refresh_receipt.schema.json",
                "youtube_connection_receipt.schema.json",
            ):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            source = Path(secrets) / "source-unavailable.json"
            destination = Path(secrets) / "runtime.json"
            token = {
                "token": "access", "refresh_token": "refresh",
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": "client", "client_secret": "secret",
                "scopes": [
                    "https://www.googleapis.com/auth/youtube.readonly",
                    "https://www.googleapis.com/auth/yt-analytics.readonly",
                    "https://www.googleapis.com/auth/youtube.upload",
                    "https://www.googleapis.com/auth/youtube.force-ssl",
                ],
            }
            destination.write_text(json.dumps(token), encoding="utf-8")
            token_hash = hashlib.sha256(destination.read_bytes()).hexdigest()
            base = root / "output/integrations/youtube/heroverse"
            base.mkdir(parents=True)
            mirror = {
                "schema_version": "1.0.0", "receipt_id": "oauth-token-mirror-" + "a" * 20,
                "integration_id": "youtube-heroverse-v1", "status": "MIRRORED",
                "source_class": "OAUTH_LOCAL_SECRET_OUTSIDE_WORKSPACE",
                "destination_class": "WINDOWS_TASK_SECRET_OUTSIDE_WORKSPACE",
                "source_outside_workspace": True, "destination_outside_workspace": True,
                "source_sha256": "b" * 64, "destination_sha256": "b" * 64,
                "size_bytes": 100, "required_scopes": token["scopes"], "granted_scopes": token["scopes"],
                "refresh_token_present": True, "atomic_replace": True, "secret_logged": False,
                "technical_cost_brl": 0, "mirrored_at": "2026-09-04T14:00:00Z",
            }
            refresh = {
                "schema_version": "1.0.0", "receipt_id": "oauth-refresh-" + "c" * 20,
                "integration_id": "youtube-heroverse-v1", "status": "PASS",
                "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA", "observed_channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                "token_sha256": token_hash, "required_scopes": token["scopes"], "granted_scopes": token["scopes"],
                "refresh_success": True, "noninteractive": True, "identity_verified_after_refresh": True,
                "token_persisted": True, "atomic_replace": True, "failure_code": None,
                "secret_logged": False, "technical_cost_brl": 0, "tested_at": "2026-09-04T14:01:00Z",
            }
            connection = json.loads((ROOT / "output/integrations/youtube/heroverse/connection-receipt.json").read_text(encoding="utf-8"))
            connection["authorization"]["requested_scopes"] = token["scopes"]
            connection["authorization"]["granted_scopes"] = token["scopes"]
            # The immutable configuration receipt may predate a later token
            # mirror; the refresh receipt below is the exact-channel proof for
            # the current mirrored token.
            connection["created_at"] = "2026-09-04T13:59:00Z"
            for name, value in (
                ("oauth-token-mirror-receipt.json", mirror),
                ("oauth-noninteractive-refresh-receipt.json", refresh),
                ("connection-receipt.json", connection),
            ):
                (base / name).write_text(json.dumps(value), encoding="utf-8")
            self.assertFalse(source.exists())
            self.assertTrue(_existing_oauth_chain_is_current(root, source, destination))

    def test_recent_oauth_proof_stays_healthy_without_browser_or_remote_refresh(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in ("oauth_session_health.schema.json", "oauth_noninteractive_refresh_receipt.schema.json"):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            token = Path(secrets) / "runtime.json"
            token.write_text(json.dumps({
                "token": "access", "refresh_token": "refresh",
                "expiry": "2026-09-04T14:00:00Z",
                "scopes": [
                    "https://www.googleapis.com/auth/youtube.readonly",
                    "https://www.googleapis.com/auth/yt-analytics.readonly",
                    "https://www.googleapis.com/auth/youtube.upload",
                    "https://www.googleapis.com/auth/youtube.force-ssl",
                ],
            }), encoding="utf-8")
            receipt_path = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
            receipt_path.parent.mkdir(parents=True)
            receipt = json.loads((ROOT / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json").read_text(encoding="utf-8"))
            receipt["tested_at"] = "2026-09-04T12:00:00Z"
            receipt["token_sha256"] = hashlib.sha256(token.read_bytes()).hexdigest()
            receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
            with patch("hero_engine.central_manager_phase5.prove_noninteractive_refresh") as refresh:
                health = ensure_oauth_session_health(
                    root,
                    token,
                    now=datetime(2026, 9, 4, 13, 0, tzinfo=timezone.utc),
                )
            refresh.assert_not_called()
            self.assertEqual("HEALTHY", health["status"])
            self.assertFalse(health["user_intervention_required"])
            self.assertEqual(1, health["maximum_scheduled_probe_units_per_day"])

    def test_recent_identity_proof_refreshes_when_access_token_is_expired(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in ("oauth_session_health.schema.json", "oauth_noninteractive_refresh_receipt.schema.json"):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            token = Path(secrets) / "runtime.json"
            token.write_text(json.dumps({
                "token": "expired-access", "refresh_token": "refresh",
                "expiry": "2026-09-04T12:30:00Z",
                "scopes": [
                    "https://www.googleapis.com/auth/youtube.readonly",
                    "https://www.googleapis.com/auth/yt-analytics.readonly",
                    "https://www.googleapis.com/auth/youtube.upload",
                    "https://www.googleapis.com/auth/youtube.force-ssl",
                ],
            }), encoding="utf-8")
            receipt_path = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
            receipt_path.parent.mkdir(parents=True)
            receipt = json.loads((ROOT / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json").read_text(encoding="utf-8"))
            receipt["tested_at"] = "2026-09-04T12:00:00Z"
            receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
            refreshed = dict(receipt)
            refreshed["tested_at"] = "2026-09-04T13:00:00Z"
            with (
                patch("hero_engine.central_manager_phase5.prove_noninteractive_refresh", return_value=refreshed) as refresh,
                patch("hero_engine.central_manager_phase5.materialize_oauth_readiness") as readiness,
            ):
                health = ensure_oauth_session_health(root, token, now=datetime(2026, 9, 4, 13, 0, tzinfo=timezone.utc))
            refresh.assert_called_once()
            readiness.assert_called_once()
            self.assertEqual("REFRESHED", health["status"])
            self.assertTrue(health["identity_verified"])

    def test_stale_oauth_proof_refreshes_and_repins_identity_without_browser(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            for name in ("oauth_session_health.schema.json", "oauth_noninteractive_refresh_receipt.schema.json"):
                (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
            token = Path(secrets) / "runtime.json"
            token.write_text("{}", encoding="utf-8")
            receipt_path = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
            receipt_path.parent.mkdir(parents=True)
            receipt = json.loads((ROOT / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json").read_text(encoding="utf-8"))
            receipt["tested_at"] = "2026-09-01T12:00:00Z"
            receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
            refreshed = dict(receipt)
            refreshed["tested_at"] = "2026-09-04T13:00:00Z"
            with (
                patch("hero_engine.central_manager_phase5.prove_noninteractive_refresh", return_value=refreshed) as refresh,
                patch("hero_engine.central_manager_phase5.materialize_oauth_readiness") as readiness,
            ):
                health = ensure_oauth_session_health(
                    root,
                    token,
                    now=datetime(2026, 9, 4, 13, 0, tzinfo=timezone.utc),
                )
            refresh.assert_called_once()
            readiness.assert_called_once()
            self.assertEqual("REFRESHED", health["status"])
            self.assertTrue(health["identity_verified"])
            self.assertFalse(health["user_intervention_required"])


if __name__ == "__main__":
    unittest.main()
