"""Native word/error/receipt readers; ASR inference only is simulated."""
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from hero_engine import phase5_autonomous_quality as quality
from hero_engine.atomic_io import atomic_write_utf8

ROOT=Path(__file__).resolve().parents[1]
RECORD=ROOT/'output/runtime/gestor-central/maintenance-runs/audio-static-intelligibility-20261005'


def digest(path):
    return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()


class AudioStaticIntelligibilityTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory(dir=RECORD,prefix='owned-asr-')
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name).resolve()
        self.package=self.root/'output/production/owned-pilot'
        self.package.mkdir(parents=True)
        self.plan=self.package/'take_plan.json'
        atomic_write_utf8(self.plan,json.dumps({'format_pack_id':'fp-narrated-reflection-static',
            'takes':[{'narration':'Name the pressure test its story choose one faithful step today'}]}))
        self.media=self.package/'simulated-observer-input.mp4'
        self.media.write_bytes(b'Isolated ASR backend frontier; not a decoded production video')
        self.model=self.root/'existing-offline-model'
        self.model.mkdir()
        for name in ('model.bin','config.json','tokenizer.json'):
            (self.model/name).write_bytes(b'isolated-model-frontier-'+name.encode())
        self.result={'provider':'faster-whisper-base.en-cpu-int8','language':'en',
            'text':'Name the pressure test its story choose one faithful step today',
            'local_files_only':True,'cpu_threads':1,
            'model_bindings':[{'path':str(p),'sha256':digest(p).removeprefix('sha256:')}
                              for p in sorted(self.model.iterdir())]}

    def measure(self, binding=None):
        return quality.measure_audio_static_intelligibility(self.root,self.package,self.media,
            expected_media_hash=digest(self.media),receipt_binding=binding)

    def test_native_measurement_and_anchored_reuse_without_second_inference(self):
        with patch.object(quality,'_asr',return_value=self.result) as backend:
            value=self.measure()
            self.assertTrue(value['passed'])
            self.assertFalse(value['publication_authorized'])
            self.assertEqual(value['word_error_rate'],0)
            self.assertEqual(self.measure(value['receipt']),value)
            backend.assert_called_once_with(self.media,local_only=True)

    def test_existing_result_without_anchor_does_not_repeat_backend(self):
        with patch.object(quality,'_asr',return_value=self.result) as backend:
            self.measure()
            with self.assertRaises(FileExistsError): self.measure()
            self.assertEqual(backend.call_count,1)

    def test_unintelligible_transcript_cannot_claim_pass(self):
        bad=copy.deepcopy(self.result);bad['text']='unrelated irrelevant words'
        with patch.object(quality,'_asr',return_value=bad):
            value=self.measure()
        self.assertFalse(value['passed'])
        self.assertGreater(value['word_error_rate'],0.08)

    def test_wrong_language_cannot_pass_matching_copy(self):
        bad=copy.deepcopy(self.result);bad['language']='pt'
        with patch.object(quality,'_asr',return_value=bad):
            self.assertFalse(self.measure()['passed'])

    def test_modified_reference_rejects_previous_receipt_before_inference(self):
        with patch.object(quality,'_asr',return_value=self.result):
            value=self.measure()
        self.plan.write_bytes(self.plan.read_bytes()+b' ')
        with patch.object(quality,'_asr',side_effect=AssertionError('no silent fallback')):
            with self.assertRaises(PermissionError): self.measure(value['receipt'])

    def test_tampered_measurement_even_reanchored_is_recomputed(self):
        with patch.object(quality,'_asr',return_value=self.result): value=self.measure()
        path=Path(value['receipt']['path']);receipt=json.loads(path.read_bytes())
        receipt['transcript']['text']='wrong words'
        atomic_write_utf8(path,json.dumps(receipt))
        with self.assertRaises(PermissionError):
            self.measure({'path':str(path),'sha256':digest(path)})

    def test_media_change_during_observation_blocks_receipt(self):
        def observe(*args,**kwargs):
            self.media.write_bytes(self.media.read_bytes()+b'changed')
            return self.result
        with patch.object(quality,'_asr',side_effect=observe):
            with self.assertRaises(PermissionError): self.measure()
        self.assertFalse((self.package/'qa').exists())

    def test_existing_backend_offline_single_thread_model_is_bound(self):
        loader=SimpleNamespace()
        loader.transcribe=lambda *a,**k: ([SimpleNamespace(text='Faithful step')],
            SimpleNamespace(language='en',language_probability=1.0,duration=1.0))
        constructor=unittest.mock.Mock(return_value=loader)
        resolver=unittest.mock.Mock(return_value=str(self.model))
        with patch.dict('sys.modules',{'faster_whisper':SimpleNamespace(WhisperModel=constructor),
                    'faster_whisper.utils':SimpleNamespace(download_model=resolver)}):
            result=quality._asr(self.media,local_only=True)
        resolver.assert_called_once_with('base.en',local_files_only=True)
        self.assertEqual(constructor.call_args.kwargs['cpu_threads'],1)
        self.assertTrue(constructor.call_args.kwargs['local_files_only'])
        self.assertEqual(len(result['model_bindings']),3)

    def test_autonomous_audio_limits_not_replaced_by_looser_legacy_limits(self):
        good={'integrated_lufs':-16,'true_peak_dbtp':-1.5,'lra_lu':3}
        self.assertTrue(quality.audio_static_technical_pass(good))
        for key,value in [('integrated_lufs',-17.5),('true_peak_dbtp',-0.5),('lra_lu',0.5),('lra_lu',9)]:
            with self.subTest(key=key,value=value):
                changed={**good,key:value}
                self.assertFalse(quality.audio_static_technical_pass(changed))
