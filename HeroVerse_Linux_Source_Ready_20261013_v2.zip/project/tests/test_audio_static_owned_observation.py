"""Current publication -> existing owned collector; provider/host simulated."""
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from hero_engine.google_api_runtime import GoogleOperationDeadline

from hero_engine import phase6_pilot as pilot
from tests import test_audio_static_ready_chain as ready
from tests import test_phase6_pilot as provider_fixture


class AudioStaticOwnedObservationTests(unittest.TestCase):
    def test_local_admission_does_not_consume_google_request_budget(self):
        """Real local readers; only provider and elapsed clock are simulated."""
        from hero_engine import phase5_youtube_publisher as publisher
        owner = ready.AudioStaticReadyChainTests('test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider')
        self.addCleanup(owner.doCleanups); owner.setUp()
        owner.test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider()
        shutil.copy2(ready.ROOT / 'schemas/own_channel_performance_snapshot.schema.json', owner.root / 'schemas')
        receipt = owner.package / 'youtube-publication-receipt.json'
        before = receipt.read_bytes(); target = json.loads(before)['video_id']
        clock = [0.0]; original = publisher._validate_current_release
        def delayed_admission(*args, **kwargs):
            value = original(*args, **kwargs)
            clock[0] += 180.0
            return value
        class CurrentYouTube(provider_fixture.YouTube):
            def list(self, **kwargs):
                request = super().list(**kwargs)
                if self.resource == 'videos': request.response['items'][0]['id'] = target
                return request
        def deadline(seconds, *, progress=None):
            return GoogleOperationDeadline(seconds, progress=progress, clock=lambda: clock[0])
        with patch.object(publisher, '_validate_current_release', side_effect=delayed_admission), \
             patch.object(pilot.time, 'monotonic', side_effect=lambda: clock[0]), \
             patch.object(pilot, 'GoogleOperationDeadline', side_effect=deadline), \
             patch('hero_engine.central_manager_phase5.ensure_oauth_session_health', return_value={'status':'HEALTHY'}) as health, \
             patch.object(pilot, '_build_services', return_value=(CurrentYouTube(), provider_fixture.Analytics())) as services:
            path = pilot.materialize_video_live(owner.root, token_path=owner.root/'synthetic-token',
                video_id=target, publication_receipt=receipt, captured_at='2026-10-05T18:00:00Z',
                package_relative=owner.relative, current_bindings=owner.bindings,
                expected_release_hash=owner.binding(owner.package/'release_gate.json')['sha256'])
        observed = json.loads(path.read_bytes())
        self.assertEqual(observed['video_id'], target)
        self.assertEqual(observed['captured_at'], '2026-10-05T18:06:00Z')
        self.assertGreaterEqual(clock[0], 360.0)
        self.assertEqual(health.call_count, 1); self.assertEqual(services.call_count, 1)
        self.assertEqual(receipt.read_bytes(), before)

    def test_current_native_publication_is_observed_without_republishing(self):
        owner = ready.AudioStaticReadyChainTests('test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider')
        self.addCleanup(owner.doCleanups)
        owner.setUp()
        owner.test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider()
        shutil.copy2(ready.ROOT / 'schemas/own_channel_performance_snapshot.schema.json', owner.root / 'schemas')
        receipt = owner.package / 'youtube-publication-receipt.json'
        before = receipt.read_bytes()
        target = json.loads(before)['video_id']
        selection = {'package_relative': owner.relative, 'current_bindings': owner.bindings,
                     'expected_release_hash': owner.binding(owner.package / 'release_gate.json')['sha256']}

        class CurrentYouTube(provider_fixture.YouTube):
            def list(self, **kwargs):
                request = super().list(**kwargs)
                if self.resource == 'videos':
                    self_test.assertEqual(kwargs['id'], target)
                    request.response['items'][0]['id'] = target
                return request
        self_test = self
        youtube = CurrentYouTube()
        with patch('hero_engine.central_manager_phase5.ensure_oauth_session_health', return_value={'status': 'HEALTHY'}), \
             patch.object(pilot, '_build_services', return_value=(youtube, provider_fixture.Analytics())) as services:
            path = pilot.materialize_video_live(owner.root, token_path=owner.root/'synthetic-token',
                video_id=target, publication_receipt=receipt, captured_at='2026-10-05T18:00:00Z', **selection)
            observed = json.loads(path.read_bytes())
            self.assertEqual(observed['video_id'], target)
            self.assertNotEqual(observed['video_id'], pilot.VIDEO_ID)
            self.assertEqual(observed['channel_id'], pilot.CHANNEL_ID)
            self.assertEqual(observed['technical_cost_brl'], 0)
            self.assertEqual(observed['public_metrics']['viewCount'], 100)
            self.assertEqual(receipt.read_bytes(), before)
            self.assertEqual(services.call_count, 1)
            # A corrupted effect-chain receipt must fail before another query;
            # a COMPLETE_PUBLIC label alone is not accepted as provenance.
            damaged = json.loads(before); damaged['video_id'] = 'foreign-id'
            receipt.write_text(json.dumps(damaged), encoding='utf-8')
            services.reset_mock()
            with self.assertRaises(PermissionError):
                pilot.materialize_video_live(owner.root, token_path=owner.root/'synthetic-token',
                    video_id=target, publication_receipt=receipt, **selection)
            services.assert_not_called()

    def test_partial_or_foreign_selection_fails_before_oauth(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve(); package = root/'output/production/current'
            package.mkdir(parents=True); receipt=package/'youtube-publication-receipt.json'
            receipt.write_text('{}',encoding='utf-8')
            with patch('hero_engine.central_manager_phase5.ensure_oauth_session_health') as health:
                for kwargs in ({'current_bindings':{}}, {'package_relative':Path('output/production/current')},
                               {'package_relative':Path('../foreign'),'current_bindings':{},'expected_release_hash':'sha256:'+'0'*64}):
                    with self.subTest(selection=kwargs), self.assertRaises(PermissionError):
                        pilot.materialize_video_live(root,token_path=root/'synthetic-token',video_id='owned-video',publication_receipt=receipt,**kwargs)
                health.assert_not_called()

    def test_discovery_does_not_import_previous_test_cases(self):
        import sys
        suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
        self.assertEqual(suite.countTestCases(),4)

