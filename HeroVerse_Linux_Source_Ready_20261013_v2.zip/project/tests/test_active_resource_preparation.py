from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from hero_engine import phase6_media as media
from hero_engine.production_capacity import (
    BASE, GIB, Phase6ResourcePreparation, ResourceWait,
)


def sample(**changes):
    return {
        "available_ram_bytes": 2 * GIB, "total_ram_bytes": 8 * GIB,
        "output_free_bytes": 20 * GIB, "temp_free_bytes": 20 * GIB,
        "cpu_load_percent": 90.0, "logical_cpus": 4, **changes,
    }


class ActiveResourcePreparationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="task16-unit-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        plan = self.root / BASE / "production/take_plan.json"
        plan.parent.mkdir(parents=True)
        plan.write_text(json.dumps({"takes": [{"take_id": "t1", "start_ms": 0, "end_ms": 1000}]}), encoding="utf-8")
        for name in ("kokoro-v1.0.fp16.onnx", "voices-v1.0.bin"):
            path = self.root / "models/kokoro" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"test weights")

    def test_sufficient_and_high_cpu_use_serial_admission_not_arbitrary_cutoff(self):
        probe = Mock(return_value=sample(cpu_load_percent=100))
        with Phase6ResourcePreparation(self.root, probe=probe) as resources:
            result = resources.prepare("voice:model")
            self.assertEqual("ADMITTED", result["status"])
            self.assertEqual(0, result["recovery_passes"])
            self.assertEqual(1, result["requirements"]["own_concurrency"])
            self.assertEqual(512 * 1024**2 + len(b"test weights") * 5, result["requirements"]["required_ram_bytes"])
            self.assertEqual(1, probe.call_count)

    def test_recoverable_shortage_closes_only_own_completed_capture_and_rechecks(self):
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as resources:
            def completed(command, **kwargs):
                kwargs["stderr"].write(b"disposable successful child diagnostics")
                return SimpleNamespace(returncode=0)
            with patch("hero_engine.production_capacity.subprocess.run", side_effect=completed):
                resources.run_ffmpeg(["ffmpeg", "output.mp4"])
            owned = resources._idle_captures[0]
            self.assertFalse(owned.closed)
            # Only the OS measurement boundary is simulated. Reclamation is the
            # real implementation, acting on the real handle it created itself.
            def measured(_):
                return sample(output_free_bytes=20 * GIB if owned.closed else 0)
            resources.probe = Mock(side_effect=measured)
            result = resources.prepare("ffmpeg")
            self.assertTrue(owned.closed)
            self.assertEqual("ADMITTED", result["status"])
            self.assertEqual(1, result["recovery_passes"])
            self.assertEqual(1, result["released_idle_handles"])
            self.assertEqual(2, resources.probe.call_count)
            self.assertEqual(0, resources.release_idle())
            self.assertEqual(0, resources.prepare("ffmpeg")["released_idle_handles"])

    def test_persistent_insufficiency_is_one_pass_two_samples_no_loop(self):
        probe = Mock(return_value=sample(available_ram_bytes=0))
        with Phase6ResourcePreparation(self.root, probe=probe) as resources:
            with self.assertRaises(ResourceWait) as caught:
                resources.prepare("voice:model")
            self.assertEqual(2, probe.call_count)
            self.assertEqual(["RAM_BELOW_STAGE_REQUIREMENT"], caught.exception.observation["causes"])
            self.assertEqual(60, caught.exception.observation["next_check_seconds"])
            self.assertEqual(1, caught.exception.observation["recovery_passes"])

    def test_probe_error_or_missing_fields_block_before_reclamation(self):
        for value in (OSError("probe unavailable"), {}, sample(cpu_load_percent=float("nan")), sample(logical_cpus=None)):
            with self.subTest(value=repr(value)):
                probe = Mock(side_effect=value) if isinstance(value, Exception) else Mock(return_value=value)
                with Phase6ResourcePreparation(self.root, probe=probe) as resources:
                    with patch.object(resources, "release_idle", wraps=resources.release_idle) as release:
                        with self.assertRaisesRegex(ResourceWait, "RESOURCE_STATE_UNAVAILABLE"):
                            resources.prepare("ffmpeg")
                        release.assert_not_called()
                        self.assertEqual(1, probe.call_count)

    def test_recheck_error_never_admits(self):
        probe = Mock(side_effect=[sample(temp_free_bytes=0), OSError("second sample failed")])
        with Phase6ResourcePreparation(self.root, probe=probe) as resources:
            with self.assertRaisesRegex(ResourceWait, "RESOURCE_STATE_UNAVAILABLE"):
                resources.prepare("ffmpeg")
            self.assertEqual(2, probe.call_count)

    def test_foreign_files_and_protected_names_are_never_scanned_or_removed(self):
        paths = [self.root / name for name in ("old.tmp", "cache.bin", "receipt.json", "model.onnx", "queue.sqlite3", "queue.sqlite3-wal", "queue.sqlite3-shm", "manager.lock")]
        for path in paths:
            path.write_bytes(b"foreign or evidence: preserve")
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample(output_free_bytes=0)) as resources:
            with patch("pathlib.Path.unlink", side_effect=AssertionError("no deletion by path")), self.assertRaises(ResourceWait):
                resources.prepare("ffmpeg")
        for path in paths:
            self.assertEqual(b"foreign or evidence: preserve", path.read_bytes())

    def test_pause_blocks_actual_voice_render_and_executor_entries_without_writes(self):
        pause = self.root / "output/runtime/gestor-central/PAUSE"
        pause.parent.mkdir(parents=True)
        pause.write_bytes(b"owner pause")
        before = {p.relative_to(self.root): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        with patch("hero_engine.production_capacity.measure_local_resources", side_effect=AssertionError("pause first")):
            for entry in (media.synthesize_video2_voice, media.render_video2, media.run_phase6_media_executor):
                with self.subTest(entry=entry.__name__), self.assertRaisesRegex(ResourceWait, "OWNER_PAUSE"):
                    entry(self.root)
        self.assertEqual(before, {p.relative_to(self.root): p.read_bytes() for p in self.root.rglob("*") if p.is_file()})

    def test_pause_created_during_recovery_blocks_and_is_preserved(self):
        pause = self.root / "output/runtime/gestor-central/PAUSE"
        def first_sample(_):
            pause.parent.mkdir(parents=True)
            pause.write_bytes(b"new owner pause")
            return sample(output_free_bytes=0)
        with Phase6ResourcePreparation(self.root, probe=Mock(side_effect=first_sample)) as resources:
            with self.assertRaisesRegex(ResourceWait, "OWNER_PAUSE"):
                resources.prepare("ffmpeg")
            self.assertEqual(1, resources.probe.call_count)
            self.assertEqual(b"new owner pause", pause.read_bytes())

    def test_concurrent_own_task_blocks_without_wait_or_changing_first_owner(self):
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as first:
            with self.assertRaisesRegex(ResourceWait, "OWN_HEAVY_TASK_ALREADY_ACTIVE"):
                with Phase6ResourcePreparation(self.root):
                    self.fail("second admission")
            self.assertEqual("ADMITTED", first.prepare("ffmpeg")["status"])
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as following:
            self.assertEqual("ADMITTED", following.prepare("ffmpeg")["status"])

    def test_active_capture_not_reclaimed_and_command_quality_arguments_unchanged(self):
        command = ["ffmpeg", "-i", "test", "-crf", "18", "-preset", "slow", "output.mp4"]
        captures = []
        real_temporary = tempfile.TemporaryFile
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as resources:
            def running(actual, **kwargs):
                self.assertEqual(command, actual)
                self.assertEqual(0, resources.release_idle())
                self.assertFalse(kwargs["stderr"].closed)
                captures.append(kwargs["stderr"])
                return SimpleNamespace(returncode=0)
            with patch("hero_engine.production_capacity.subprocess.run", side_effect=running), patch(
                "hero_engine.production_capacity.tempfile.TemporaryFile", wraps=real_temporary,
            ) as temporary:
                resources.run_ffmpeg(command)
            self.assertEqual(2, temporary.call_count)
            self.assertTrue(all(call.kwargs["dir"] == self.root for call in temporary.call_args_list))
            self.assertFalse(captures[0].closed)
        self.assertTrue(captures[0].closed)

    def test_child_failure_restores_scope_and_does_not_swallow_diagnostic(self):
        def fail(command, **kwargs):
            kwargs["stderr"].write(b"synthetic encoder failure")
            return SimpleNamespace(returncode=7)
        with patch("hero_engine.production_capacity.subprocess.run", side_effect=fail):
            with self.assertRaisesRegex(RuntimeError, "synthetic encoder failure"):
                with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as resources:
                    resources.run_ffmpeg(["ffmpeg", "output.mp4"])
        self.assertEqual([], resources._idle_captures)
        with Phase6ResourcePreparation(self.root, probe=lambda _: sample()) as next_scope:
            self.assertEqual("ADMITTED", next_scope.prepare("ffmpeg")["status"])

    def test_every_new_task_rechecks_and_observes_completion(self):
        probe = Mock(return_value=sample())
        with Phase6ResourcePreparation(self.root, probe=probe) as resources:
            for stage in ("audio:sfx", "audio:music", "ffprobe"):
                with resources.task(stage):
                    pass
            self.assertEqual(6, probe.call_count)
            self.assertEqual(3, len(resources.observations))
            self.assertTrue(all("after_task" in row and "elapsed_seconds" in row for row in resources.observations))

    def test_real_voice_entry_blocks_before_model_load_then_restores_context(self):
        # Reuse the existing isolated voice contract fixture; don't fake the
        # admission decision, and don't load a real model or real credential.
        from tests.test_phase6_media import Phase6MediaTests
        fixture = Phase6MediaTests()
        fixture._prepare_voice_inputs(self.root)
        binding = fixture._espeak_binding(self.root)
        self.addCleanup(binding.close)
        capacity = {"schema_version": "1.1.0", "receipt_id": "capacity-phase6-" + "a" * 24,
                    "status": "PASS", "espeak": binding.capacity_evidence()}
        builder = Mock(side_effect=AssertionError("no model load under shortage"))
        with patch("hero_engine.phase6_media.verify_phase6_capacity_receipt", return_value=capacity), patch(
            "hero_engine.production_capacity.measure_local_resources", return_value=sample(available_ram_bytes=0)
        ):
            with self.assertRaisesRegex(ResourceWait, "RAM_BELOW_STAGE_REQUIREMENT"):
                media.synthesize_video2_voice(
                    self.root, capacity_receipt_path=self.root / "capacity.json",
                    expected_capacity_receipt_id=capacity["receipt_id"],
                    expected_capacity_receipt_sha256="sha256:" + "b" * 64,
                    voice_builder=builder,
                )
        builder.assert_not_called()
        self.assertIsNone(media._RESOURCE_SCOPE.get())
        self.assertFalse((self.root / BASE / "audio").exists())
        records = list((self.root / BASE / "resource-preparation").glob("*.json"))
        self.assertEqual(1, len(records))
        record = json.loads(records[0].read_text(encoding="utf-8"))
        self.assertFalse(record["quality_approval"])
        self.assertEqual("RESOURCE_WAIT", record["observations"][0]["status"])


if __name__ == "__main__":
    unittest.main()
