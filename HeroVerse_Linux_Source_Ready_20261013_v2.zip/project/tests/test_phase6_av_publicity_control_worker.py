"""Boundary-double tests. No OpenCV, NumPy, detector, codec or network is run."""
from contextlib import ExitStack
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import Mock, patch, call

from hero_engine import phase6_av_publicity_control_worker as C
from hero_engine import phase6_av_publicity_runtime as R
from hero_engine import phase6_av_publicity_worker_probe as W
from hero_engine import phase6_av_detector_semantics as S


def encode(value):
    return W._canonical(value)


def write(path, value, *, raw=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = value if raw else encode(value)
    path.write_bytes(data)
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}


def prefixed(binding):
    return {**binding, "sha256": "sha256:" + binding["sha256"]}


def raw_face(*, negative=False, retval=1):
    return {"settings": deepcopy(S.SETTINGS), "input_size": [1280, 720] if negative else [512, 512],
            "opencv_version": "5.0.0", "retval": retval,
            "detections": None if negative else [[190, 75, 100, 100, *([100] * 10), 0.99]]}


def controls():
    return [{"control_id": row["control_id"], "width": row["width"], "height": row["height"],
             "source_binding": {"path": str(row["source_path"]), "sha256": row["source_sha256"], "size_bytes": 1},
             "ppm_binding": {"path": "fixture.ppm", "sha256": "a" * 64, "size_bytes": 1}} for row in C.CONTROLS]


class DecodeFixture:
    """Tiny real files and synthetic process receipts, not LIVE decoder evidence."""
    def __init__(self, root, stack):
        self.root, self.decode = root, root / "decode"
        self.decode.mkdir()
        self.support = root / "support.txt"
        support = write(self.support, b"fixture implementation", raw=True)
        self.control_rows, sources = [], []
        for index, source in enumerate(C.CONTROLS):
            path = root / (source["decode_id"] + ".png")
            binding = write(path, b"synthetic source " + bytes([index]), raw=True)
            sources.append(binding)
            self.control_rows.append({**source, "source_path": path, "source_sha256": binding["sha256"], "width": 2, "height": 1})
        dependencies = [support, *sources]
        request = {"dependency_bindings": dependencies, "controls": []}
        reports, bindings = [], []
        for control, source in zip(self.control_rows, sources):
            folder = self.decode / control["decode_id"]
            stdout = write(folder / "stdout.log", b"P6\n2 1\n255\n" + b"abcdef", raw=True)
            stderr = write(folder / "stderr.log", b"", raw=True)
            process = {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
                       "assigned_before_resume": True, "kill_on_close": True,
                       "committed_memory_limit_bytes": 2 * 1024**3, "timeout_seconds": 30.0,
                       "release_authority": False, "audio_approved": False,
                       "logs": [{"path": row["path"], "sha256": row["sha256"], "size": row["size_bytes"]}
                                for row in (stdout, stderr)]}
            process_binding = write(folder / "process-receipt.json", process)
            report = {"control_id": control["decode_id"], "source_binding": source, "ppm_binding": stdout,
                      "process_receipt_binding": process_binding, "status": "DECODED_CONTROL_NOT_DETECTOR_EVALUATED",
                      "authority": C.DECODE_AUTHORITY, "command": ["FIXTURE_ONLY_NO_DECODER"], "process": process,
                      "ppm": {"width": 2, "height": 1, "pixel_order": "RGB24", "pixel_bytes": 6,
                              "pixel_sha256": hashlib.sha256(b"abcdef").hexdigest(), "source_frame_index": 0,
                              "resize_performed": False, "detector_called": False}}
            reports.append(report)
            bindings.extend([stdout, stderr, process_binding, write(folder / "decode-report.json", report)])
            request["controls"].append({"source_binding": source, "command": report["command"]})
        request_binding = write(self.decode / "request.json", request)
        self.terminal = {"version": "publicity-two-control-decode-v1", "kind": "PUBLICITY_CONTROL_DECODE_TERMINAL",
                         "status": "CONTROLS_DECODED_NOT_EVALUATED", "error": None, "completed_decode_count": 2,
                         "decode_calls_reserved": ["positive", "negative"], "authority": C.DECODE_AUTHORITY,
                         "automatic_retries": 0, "cv_calls": 0, "ocr_calls": 0, "inference_calls": 0,
                         "network_calls": 0, "technical_cost_brl": 0, "controls": reports,
                         "dependency_bindings": dependencies, "output_bindings": [request_binding, *bindings]}
        terminal = write(self.decode / "terminal.json", self.terminal)
        model = write(root / "model.onnx", b"fixture model not executable", raw=True)
        for key, value in {"ROOT": root, "DECODE_ROOT": self.decode, "DECODE_TERMINAL": self.decode / "terminal.json",
                           "DECODE_TERMINAL_SHA": terminal["sha256"], "CONTROLS": tuple(self.control_rows),
                           "DECODE_DEPENDENCY_PATHS": tuple(Path(row["path"]) for row in dependencies),
                           "MODEL_PINS": {"model.onnx": model["sha256"]}}.items():
            stack.enter_context(patch.object(C, key, value))


class ControlWorkerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)

    def measure(self, raw_results, *, recheck=None):
        self.rows = controls()
        model = b"boundary model buffer"
        context = {"controls": self.rows, "pixels": {row["control_id"]: b"boundary double" for row in self.rows},
                   "model_bytes": model, "model_bindings": [{"path": "Área/model.onnx",
                       "sha256": "sha256:" + W._sha(model), "size_bytes": len(model)}]}
        cv = types.SimpleNamespace(setNumThreads=Mock(), getNumThreads=Mock(return_value=1),
             ocl=types.SimpleNamespace(setUseOpenCL=Mock(), useOpenCL=Mock(return_value=False)),
             FaceDetectorYN=types.SimpleNamespace(create=Mock(return_value=object())), __version__="5.0.0")
        infer = self.stack.enter_context(patch.object(C, "_infer_raw", side_effect=raw_results))
        self.model_view, self.configuration_view = object(), object()
        numpy = types.SimpleNamespace(uint8=object(), frombuffer=Mock(side_effect=[self.model_view, self.configuration_view]))
        self.infer, self.cv, self.numpy = infer, cv, numpy
        result = C._measure_controls(W, S, cv, numpy, context, self.root, recheck or Mock())
        return result

    def test_pair_reuses_buffers_persists_four_outputs_with_no_authority(self):
        observations, evaluation, bindings = self.measure([raw_face(), raw_face(negative=True)])
        self.assertEqual(self.infer.call_count, 2)
        self.assertEqual(evaluation["status"], "PASS_OPERATIONAL_CONTROLS_ONLY")
        self.assertEqual(len(bindings), 4)
        self.assertFalse(any(evaluation["authority"].values()))
        C._reopen_outputs(W, R, self.root, {"output_bindings": bindings, "observations": observations}, self.rows)
        self.cv.FaceDetectorYN.create.assert_called_once_with("onnx", self.model_view, self.configuration_view,
                                                              (320, 320), .80, .30, 5000)
        self.assertEqual(self.numpy.frombuffer.call_args_list,
                         [call(b"boundary model buffer", self.numpy.uint8), call(b"", self.numpy.uint8)])

    def test_positive_zero_return_preserved_and_second_not_started(self):
        with self.assertRaises(S.DetectorSemanticsError):
            self.measure([raw_face(retval=0), raw_face(negative=True)])
        self.assertEqual(self.infer.call_count, 1)
        self.assertTrue((self.root / "frontal-astronaut-raw.json").is_file())
        self.assertFalse((self.root / "project-procedural-no-face-started.json").exists())

    def test_wrong_positive_region_stops_before_second_inference(self):
        bad = raw_face()
        bad["detections"][0][0] = 0
        with self.assertRaisesRegex(ValueError, "no second inference"):
            self.measure([bad, raw_face(negative=True)])
        self.assertEqual(self.infer.call_count, 1)

    def test_native_exception_preserves_reservation_without_retry(self):
        with self.assertRaisesRegex(RuntimeError, "native error"):
            self.measure([RuntimeError("native error")])
        self.assertEqual(self.infer.call_count, 1)
        self.assertEqual([path.name for path in self.root.iterdir()], ["frontal-astronaut-started.json"])

    def test_nonfinite_raw_is_preserved_as_invalid_text_without_second_inference(self):
        bad = raw_face()
        bad["detections"][0][0] = float("nan")
        with self.assertRaises(ValueError):
            self.measure([bad, raw_face(negative=True)])
        self.assertEqual(self.infer.call_count, 1)
        self.assertIn(b"NaN", (self.root / "frontal-astronaut-invalid-raw.txt").read_bytes())
        self.assertFalse((self.root / "frontal-astronaut-raw.json").exists())

    def test_negative_face_is_failed_operational_control_not_success(self):
        bad = raw_face(negative=True)
        bad["detections"] = raw_face()["detections"]
        _, result, bindings = self.measure([raw_face(), bad])
        self.assertEqual(result["status"], "FAIL_OPERATIONAL_CONTROLS")
        self.assertEqual(len(bindings), 4)

    def test_recheck_failure_after_positive_preserves_raw_and_stops_pair(self):
        with self.assertRaisesRegex(ValueError, "drift"):
            self.measure([raw_face(), raw_face(negative=True)], recheck=Mock(side_effect=[None, None, ValueError("drift")]))
        self.assertEqual(self.infer.call_count, 1)
        self.assertTrue((self.root / "frontal-astronaut-raw.json").exists())
        self.assertFalse((self.root / "project-procedural-no-face-started.json").exists())

    def test_collision_never_overwrites_equal_reservation_or_starts_inference(self):
        (self.root / "frontal-astronaut-started.json").write_bytes(b"preserve")
        with self.assertRaisesRegex(ValueError, "collision"):
            self.measure([raw_face(), raw_face(negative=True)])
        self.infer.assert_not_called()
        self.assertEqual((self.root / "frontal-astronaut-started.json").read_bytes(), b"preserve")

    def test_raw_reopen_rejects_rehashed_disagreement_missing_duplicate_and_foreign_output(self):
        observations, _, bindings = self.measure([raw_face(), raw_face(negative=True)])
        report = {"observations": observations, "output_bindings": bindings}
        for mutate in (lambda rows: rows.pop(), lambda rows: rows.__setitem__(1, rows[0]),
                       lambda rows: rows[1].update(path=str(self.root / "foreign.json"))):
            altered = deepcopy(report)
            mutate(altered["output_bindings"])
            with self.assertRaises(ValueError):
                C._reopen_outputs(W, R, self.root, altered, self.rows)
        mismatch = deepcopy(report)
        mismatch["observations"][0]["raw"]["detections"][0][0] = 200
        with self.assertRaisesRegex(ValueError, "differs from actual"):
            C._reopen_outputs(W, R, self.root, mismatch, self.rows)

    def test_binding_population_rejects_bool_size_bad_hash_and_duplicate(self):
        good = {"path": str(self.root / "f"), "sha256": "a" * 64, "size_bytes": 1}
        for rows in ([{**good, "size_bytes": True}], [{**good, "sha256": "g" * 64}], [good, good]):
            with self.assertRaises(ValueError):
                C._binding_map(rows, [self.root / "f"])

    def test_preprocessing_rgb_reversal_copy_and_width_cap_use_exact_recipe(self):
        operations = []
        class Array:
            def __init__(self, shape=None):
                self.shape = shape
            def reshape(self, *shape):
                operations.append(("reshape", shape))
                self.shape = shape
                return self
            def __getitem__(self, key):
                operations.append(("channels", key))
                return self
            def copy(self):
                operations.append(("copy",))
                return self
        for width in (2, 1281):
            with self.subTest(width=width):
                operations.clear()
                buffer = b"RGB" * width
                array = Array()
                numpy = types.SimpleNamespace(uint8=object(), frombuffer=Mock(return_value=array))
                resize = Mock(side_effect=lambda image, size, **kw: Array((size[1], size[0], 3)))
                cv = types.SimpleNamespace(resize=resize, INTER_LINEAR=1, __version__="5.0.0")
                detector = types.SimpleNamespace(setInputSize=Mock(), detect=Mock(return_value=(1, None)))
                result = C._infer_raw(S, cv, numpy, detector, {"width": width, "height": 1}, buffer)
                numpy.frombuffer.assert_called_once_with(buffer, numpy.uint8)
                self.assertEqual(operations, [("reshape", (1, width, 3)),
                    ("channels", (slice(None), slice(None), slice(None, None, -1))), ("copy",)])
                expected = min(width, 1280)
                detector.setInputSize.assert_called_once_with((expected, 1))
                self.assertEqual(result["input_size"], [expected, 1])
                if width > 1280:
                    resize.assert_called_once_with(array, (1280, 1), interpolation=1)
                else:
                    resize.assert_not_called()

    def test_bad_pixel_length_fails_before_numpy_or_detector(self):
        numpy, detector = Mock(), Mock()
        with self.assertRaisesRegex(ValueError, "buffer length"):
            C._infer_raw(S, Mock(), numpy, detector, {"width": 2, "height": 1}, b"RGB")
        self.assertEqual(numpy.mock_calls, [])
        self.assertEqual(detector.mock_calls, [])

    def test_reopen_decoded_pair_authenticates_tiny_pixels_without_decoder(self):
        DecodeFixture(self.root, self.stack)
        result = C._control_inputs(W, R, capture_pixels=True)
        self.assertEqual(list(result["pixels"].values()), [b"abcdef", b"abcdef"])
        self.assertEqual(len(result["model_bindings"]), 1)
        self.assertEqual(result["model_bytes"], b"fixture model not executable")
        self.assertIsNone(C._control_inputs(W, R)["model_bytes"])
        result["files"].recheck()

    def test_model_buffer_transport_uses_original_bytes_not_path_and_rejects_drift(self):
        model = b"synthetic onnx bytes"
        context = {"model_bytes": model, "model_bindings": [{"path": "Área/original.onnx",
            "sha256": "sha256:" + W._sha(model), "size_bytes": len(model)}]}
        views = [object(), object()]
        numpy = types.SimpleNamespace(uint8=object(), frombuffer=Mock(side_effect=views))
        cv = types.SimpleNamespace(FaceDetectorYN=types.SimpleNamespace(create=Mock(return_value=object())))
        C._detector_from_buffer(W, cv, numpy, context)
        cv.FaceDetectorYN.create.assert_called_once_with("onnx", views[0], views[1], (320, 320), .80, .30, 5000)
        self.assertEqual(numpy.frombuffer.call_args_list, [call(model, numpy.uint8), call(b"", numpy.uint8)])
        self.assertEqual(C.MODEL_LOADING, {"api": "cv2.FaceDetectorYN.create.buffer", "framework": "onnx",
            "model_dtype": "uint8", "configuration_dtype": "uint8", "configuration_size_bytes": 0,
            "source": "EXACT_PINNED_MODEL_BYTE_BUFFER", "path_copy": False, "path_retry": False})
        context["model_bytes"] = model[:-1] + b"X"
        numpy.frombuffer.reset_mock()
        cv.FaceDetectorYN.create.reset_mock()
        with self.assertRaisesRegex(ValueError, "model bytes differ"):
            C._detector_from_buffer(W, cv, numpy, context)
        numpy.frombuffer.assert_not_called()
        cv.FaceDetectorYN.create.assert_not_called()

    def test_decode_failure_marker_overrules_preserved_success_terminal(self):
        fixture = DecodeFixture(self.root, self.stack)
        (fixture.decode / "final-problem.json").write_bytes(b"{}")
        with self.assertRaisesRegex(ValueError, "failure artifacts"):
            C._control_inputs(W, R)

    def test_decode_pixel_and_model_drift_rejected_without_effects(self):
        fixture = DecodeFixture(self.root, self.stack)
        path = fixture.decode / "positive/stdout.log"
        prior = path.read_bytes()
        path.write_bytes(prior[:-1] + b"z")
        with self.assertRaises(ValueError):
            C._control_inputs(W, R)
        self.assertEqual(path.read_bytes()[-1:], b"z")
        path.write_bytes(prior)
        (self.root / "model.onnx").write_bytes(b"wrong model")
        with self.assertRaises(ValueError):
            C._control_inputs(W, R)

    def test_input_context_detects_dependency_change_on_final_recheck(self):
        fixture = DecodeFixture(self.root, self.stack)
        context = C._control_inputs(W, R)
        fixture.support.write_bytes(b"drift")
        with self.assertRaises(ValueError):
            context["files"].recheck()

    def test_inventory_rejects_failure_marker_after_success(self):
        for name in ["request.json", "controls.json", "process/stdout.log", "process/stderr.log",
                     *(path.name for path in C._output_paths(self.root))]:
            write(self.root / name, b"{}", raw=True)
        C._success_inventory(R, self.root)
        write(self.root / "final-problem.json", {})
        with self.assertRaisesRegex(ValueError, "failure artifacts"):
            C._success_inventory(R, self.root)

    def test_origin_support_is_reopened_and_unprofiled_support_is_rejected(self):
        module = prefixed(write(self.root / "module.py", b"fixture", raw=True))
        support = prefixed(write(self.root / "namespace/__init__.pyi", b"fixture namespace", raw=True))
        profile = {"file_bindings": [module, support], "population": {"directories": [str(self.root / "namespace")]},
                   "site_packages": str(self.root)}
        origins = {"modules": [{"module": name, "file_binding": module, "cache_binding": None,
                    "support_bindings": []} for name in ("cv2", "numpy", "numpy._core._multiarray_umath")],
                   "absent_cache_paths": []}
        origins["modules"].append({"module": "cv2.Error", "file_binding": None, "cache_binding": None,
            "support_bindings": [support], "namespace_paths": [str(self.root / "namespace")]})
        files = C._reopen_origins(W, R, profile, {"code_bindings": {}}, origins)
        self.assertIn(support["path"], files.items)
        (self.root / "namespace/__init__.pyi").write_bytes(b"drift")
        with self.assertRaises(ValueError):
            files.recheck()
        profile["file_bindings"].pop()
        with self.assertRaisesRegex(ValueError, "outside fixed profile"):
            C._reopen_origins(W, R, profile, {"code_bindings": {}}, origins)

    def transaction(self, *, process_error=None, close_error=None):
        directory = self.root / "new-run"
        request = {"run_directory": str(directory)}
        prepared = {"request": request, "request_sha256": W._sha(encode(request)), "process_calls": 0}
        supervisor = types.SimpleNamespace(run_bounded=Mock(side_effect=process_error, return_value={"status": "FIXTURE"}))
        w = types.SimpleNamespace(_runtime=lambda: types.SimpleNamespace(BASE_PYTHON=self.root),
            _supervisor=lambda: supervisor, _exclusive=W._exclusive, _canonical=W._canonical, _sha=W._sha,
            _binding=W._binding, _pin=W._pin, MEMORY_BYTES=2 * 1024**3, TIMEOUT_SECONDS=300)
        self.stack.enter_context(patch.object(C, "_probe", return_value=w))
        self.stack.enter_context(patch.object(C, "prepare_controls", return_value=prepared))
        close = Mock(side_effect=close_error)
        complete = self.stack.enter_context(patch.object(C, "_completed", return_value=(
            {"status": "PASS_OPERATIONAL_CONTROLS_ONLY"}, {"path": "fixture-only"}, close)))
        args = dict(root=self.root, profile_binding={}, expected_worker_sha="a" * 64,
                    expected_test_sha="b" * 64, run_directory=directory)
        return directory, args, supervisor, complete, close

    def test_preflight_never_launches_or_writes_and_requires_boolean_commit(self):
        directory, args, supervisor, _, _ = self.transaction()
        C.run_controls(**args)
        self.assertFalse(directory.exists())
        supervisor.run_bounded.assert_not_called()
        with self.assertRaises(ValueError):
            C.run_controls(**args, commit=1)

    def test_supervisor_exception_has_persistent_failure_terminal_without_retry(self):
        directory, args, supervisor, complete, _ = self.transaction(process_error=RuntimeError("supervisor failed"))
        result = C.run_controls(**args, commit=True)
        self.assertEqual(result["status"], "CONTROL_WORKER_FAILED_NOT_ADMITTED")
        self.assertEqual(json.loads((directory / "terminal.json").read_bytes()), result)
        self.assertTrue((directory / "problem.json").is_file())
        self.assertEqual(supervisor.run_bounded.call_count, 1)
        complete.assert_not_called()

    def test_post_terminal_drift_retains_history_and_writes_final_problem(self):
        directory, args, supervisor, _, _ = self.transaction(close_error=ValueError("late drift"))
        result = C.run_controls(**args, commit=True)
        self.assertEqual(result["status"], "CONTROL_WORKER_FAILED_NOT_ADMITTED")
        historical = json.loads((directory / "terminal.json").read_bytes())
        self.assertEqual(historical["status"], "PASS_OPERATIONAL_CONTROLS_ONLY")
        self.assertEqual(json.loads((directory / "final-problem.json").read_bytes()), result)
        with self.assertRaises(FileExistsError):
            C.run_controls(**args, commit=True)
        self.assertEqual(supervisor.run_bounded.call_count, 1)

    def test_completed_process_rejects_false_numeric_success_before_reading_output(self):
        process = {"status": "SUCCEEDED", "exit_code": False, "remaining_processes_verified": 0,
                   "assigned_before_resume": True, "kill_on_close": True, "committed_memory_limit_bytes": W.MEMORY_BYTES,
                   "timeout_seconds": float(W.TIMEOUT_SECONDS), "error": None, "release_authority": False,
                   "audio_approved": False}
        with self.assertRaisesRegex(ValueError, "exact process bounds"):
            C._completed(W, R, {}, self.root / "request.json", "a" * 64, process)


if __name__ == "__main__":
    unittest.main()
