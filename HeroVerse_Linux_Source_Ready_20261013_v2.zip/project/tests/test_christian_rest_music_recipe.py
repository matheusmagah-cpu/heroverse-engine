"""Native recipe/producer tests in disposable roots; no channel or queue effects."""
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import soundfile as sf
from hero_engine.creative_direction import build_christian_rest_music_recipe, verify_christian_rest_music_recipe
from hero_engine.render_creative_v3_phase5 import _build_original_music

def binding(value):
    return 'sha256:'+hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


class ChristianRestMusicRecipeTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.path=Path(temporary.name)/'rest.wav'
        self.recipe=build_christian_rest_music_recipe(duration_ms=10800000,
            channel_model_hash='sha256:'+'a'*64,style_bible_hash='sha256:'+'b'*64)

    def build(self,path=None):
        return _build_original_music(30000,path or self.path,created_at='2026-10-06T00:00:00Z',
            music_recipe=self.recipe,expected_recipe_hash=binding(self.recipe))

    def test_recipe_preserves_identity_and_no_authority(self):
        self.assertEqual(self.recipe['channel_handle'],'@heroverse74')
        self.assertEqual(self.recipe['target_country'],'US')
        self.assertEqual(self.recipe['language'],'en')
        self.assertFalse(self.recipe['publication_authorized'])
        self.assertFalse(self.recipe['narration_looped'])
        self.assertIn('Christian',self.recipe['purpose'])

    def test_stable_identity_changes_with_source_binding_or_duration(self):
        again=build_christian_rest_music_recipe(duration_ms=10800000,
            channel_model_hash='sha256:'+'a'*64,style_bible_hash='sha256:'+'b'*64)
        self.assertEqual(again,self.recipe)
        different=build_christian_rest_music_recipe(duration_ms=14400000,
            channel_model_hash='sha256:'+'a'*64,style_bible_hash='sha256:'+'b'*64)
        self.assertNotEqual(different['recipe_id'],self.recipe['recipe_id'])

    def test_scope_or_design_tamper_rejected_even_with_recomputed_hash(self):
        for name in ('scope','design'):
            changed=copy.deepcopy(self.recipe)
            if name=='scope': changed['publication_authorized']=True
            else: changed['sound_design']['crossfade_seconds']=0
            with self.subTest(name=name), self.assertRaises(PermissionError):
                verify_christian_rest_music_recipe(changed,expected_hash=binding(changed))

    def test_wrong_pin_rejected_before_creation(self):
        with self.assertRaises(PermissionError):
            _build_original_music(1000,self.path,created_at='now',music_recipe=self.recipe,
                expected_recipe_hash='sha256:'+'0'*64)
        self.assertFalse(self.path.exists())

    def test_duration_and_missing_binding_rejected(self):
        for value in (0,-1,True,14400001):
            with self.subTest(value=value),self.assertRaises(ValueError):
                build_christian_rest_music_recipe(duration_ms=value,
                    channel_model_hash='sha256:'+'a'*64,style_bible_hash='sha256:'+'b'*64)
        with self.assertRaises(ValueError):
            build_christian_rest_music_recipe(duration_ms=1000,channel_model_hash='',style_bible_hash='')

    def test_native_sample_is_exact_pcm_and_not_full_recipe_completion(self):
        result=self.build()
        info=sf.info(self.path)
        self.assertEqual(info.frames,1440000)
        self.assertEqual(info.channels,2)
        self.assertEqual(result['scope'],'SHORT_SAMPLE')
        self.assertFalse(result['quality_authorized'])

    def test_crossfade_removes_the_old_chord_boundary_fade_gap(self):
        self.build()
        old=self.path.with_name('old.wav')
        _build_original_music(30000,old,created_at='now')
        with sf.SoundFile(self.path) as stream:
            stream.seek(48000*12); new=stream.read(4800)
        with sf.SoundFile(old) as stream:
            stream.seek(48000*12); previous=stream.read(4800)
        # Comparative observation, not a universal perceptual/music PASS floor.
        self.assertGreater(float(np.mean(new*new)),float(np.mean(previous*previous)))

    def test_same_recipe_sample_deterministic(self):
        self.build(); self.build(self.path.with_name('second.wav'))
        self.assertEqual(self.path.read_bytes(),self.path.with_name('second.wav').read_bytes())

    def test_melodic_successor_explicit_and_legacy_recipe_unchanged(self):
        successor=build_christian_rest_music_recipe(duration_ms=10800000,
            channel_model_hash=self.recipe['channel_model_hash'],style_bible_hash=self.recipe['style_bible_hash'],
            recipe_version='heroverse-christian-rest-instrumental-v2')
        self.assertNotEqual(successor['recipe_id'],self.recipe['recipe_id'])
        self.assertNotIn('melodic_voice',self.recipe['sound_design'])
        verify_christian_rest_music_recipe(successor,expected_hash=binding(successor))
        first=self.path.with_name('v2.wav');second=self.path.with_name('v2-repeat.wav')
        for path in (first,second):
            result=_build_original_music(13000,path,created_at='now',music_recipe=successor,
                expected_recipe_hash=binding(successor))
            self.assertEqual(result['generator'],'HeroVerseProceduralPad@rest-v2')
            self.assertFalse(result['quality_authorized'])
        self.assertEqual(first.read_bytes(),second.read_bytes())
        self.assertEqual(sf.info(first).frames,624000)

    def test_unknown_recipe_version_cannot_select_unreviewed_design(self):
        with self.assertRaises(ValueError):
            build_christian_rest_music_recipe(duration_ms=1000,
                channel_model_hash=self.recipe['channel_model_hash'],style_bible_hash=self.recipe['style_bible_hash'],
                recipe_version='heroverse-christian-rest-instrumental-v9')


class EditorialOverlapSuccessorTests(unittest.TestCase):
    def setUp(self):
        path=Path(__file__).resolve().parents[1]/'output/production/audio-christian-rest-editorial-v3/music_recipe.json'
        self.assertEqual('sha256:'+hashlib.sha256(path.read_bytes()).hexdigest(),
            'sha256:197003e848da3dd43968daf2b913bbfb29182f2f81b3e6b75ffbcd91ad5ef5ca')
        self.legacy=json.loads(path.read_bytes())

    def recipe(self,version):
        return build_christian_rest_music_recipe(duration_ms=self.legacy['duration_ms'],
            channel_model_hash=self.legacy['channel_model_hash'],
            style_bible_hash=self.legacy['style_bible_hash'],recipe_version=version)

    def test_historical_v3_recomposition_remains_byte_semantically_identical(self):
        self.assertEqual(self.recipe('heroverse-christian-rest-editorial-v3'),self.legacy)

    def test_explicit_successor_changes_only_version_identity_cadence_and_overlap(self):
        new=self.recipe('heroverse-christian-rest-editorial-v4')
        expected=copy.deepcopy(self.legacy)
        expected.update(recipe_version=new['recipe_version'],recipe_id=new['recipe_id'])
        expected['sound_design']['melodic_voice'].update(note_seconds=3.0,tail_seconds=6.0)
        self.assertEqual(new,expected);self.assertNotEqual(new['recipe_id'],self.legacy['recipe_id'])
        verify_christian_rest_music_recipe(new,expected_hash=binding(new))
        self.assertTrue(all(new[key] is False for key in
            ('quality_authorized','render_authorized','publication_authorized')))
        from jsonschema import Draft202012Validator
        root=Path(__file__).resolve().parents[1]
        Draft202012Validator(json.loads((root/'schemas/rest_music_cycle_source.schema.json').read_bytes())).validate(new)

    def test_successor_cannot_accept_arbitrary_tail_by_rehashing(self):
        new=self.recipe('heroverse-christian-rest-editorial-v4')
        new['sound_design']['melodic_voice']['tail_seconds']=5.0
        with self.assertRaises(PermissionError):
            verify_christian_rest_music_recipe(new,expected_hash=binding(new))
