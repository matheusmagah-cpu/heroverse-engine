"""Pure raw-value fixtures; no image/model/worker or fabricated real controls."""
from copy import deepcopy
import unittest
from hero_engine import phase6_av_detector_semantics as S


def raw(detections=None, width=512, height=512):
    return {"settings": deepcopy(S.SETTINGS), "input_size": [width, height],
            "opencv_version": "5.0.0", "retval": 1, "detections": detections}


class DetectorSemanticsTests(unittest.TestCase):
    def check(self, value, **changes):
        return S.validate_raw(value, **{"source_width": 512, "source_height": 512,
                                       "observed_opencv_version": "5.0.0", **changes})

    def pair(self):
        return [
            {"control_id": "frontal-astronaut", "source_sha256": S.POSITIVE_SHA,
             "width": 512, "height": 512, "raw": raw([[180, 70, 100, 110, *([100] * 10), 0.95]]),
             "observed_opencv_version": "5.0.0"},
            {"control_id": "project-procedural-no-face", "source_sha256": S.NEGATIVE_SHA,
             "width": 1920, "height": 1080, "raw": raw(width=1280, height=720),
             "observed_opencv_version": "5.0.0"},
        ]

    def test_empty_outputs_only_valid_after_exact_success_return(self):
        for rows in (None, []):
            self.assertEqual(self.check(raw(rows))["face_count"], 0)
        for result in (0, -1, 2, True, False, 1.0, None, "1"):
            value = raw(); value["retval"] = result
            with self.subTest(result=result), self.assertRaises(S.DetectorSemanticsError): self.check(value)

    def test_dimensions_resize_and_runtime_are_exact(self):
        self.assertEqual(self.check(raw(width=1280, height=720), source_width=1920, source_height=1080)["input_size"], [1280, 720])
        for kwargs in ({"source_width": True}, {"source_height": 0}, {"source_width": 32769},
                       {"source_width": 8000, "source_height": 8000}, {"observed_opencv_version": "4.13.0"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(S.DetectorSemanticsError): self.check(raw(), **kwargs)
        for key, value in (("input_size", [True, 512]), ("opencv_version", "5.0.0.93"), ("extra", 1)):
            r = raw(); r[key] = value
            with self.subTest(key=key), self.assertRaises(S.DetectorSemanticsError): self.check(r)

    def test_settings_are_not_relaxed_or_bool_coerced(self):
        for key, value in (("score_threshold", 0.5), ("threads", True), ("opencl", 0), ("top_k", 4999)):
            r = raw(); r["settings"][key] = value
            with self.subTest(key=key), self.assertRaises(S.DetectorSemanticsError): self.check(r)

    def test_rows_require_finite_geometry_and_confidence(self):
        good = [5, 5, 10, 10, *([5] * 10), 0.9]
        self.assertEqual(self.check(raw([good]))["face_count"], 1)
        for index, value in ((0, float("nan")), (1, float("inf")), (2, 0), (3, -1), (4, True), (14, 0.79), (14, 1.01)):
            row = good.copy(); row[index] = value
            with self.subTest(index=index, value=value), self.assertRaises(S.DetectorSemanticsError): self.check(raw([row]))
        for rows in ((good,), [good[:-1]], [good] * 5001, {}):
            with self.subTest(kind=type(rows).__name__), self.assertRaises(S.DetectorSemanticsError): self.check(raw(rows))

    def test_control_pass_has_no_calibration_or_publication_authority(self):
        pair = self.pair(); before = deepcopy(pair)
        result = S.evaluate_controls(pair)
        self.assertEqual(pair, before)
        self.assertEqual(result["status"], "PASS_OPERATIONAL_CONTROLS_ONLY")
        self.assertFalse(any(result["authority"].values()))

    def test_missing_or_mislocalized_positive_fails_without_refitting(self):
        for rows in (None, [], [[0, 0, 10, 10, *([0] * 10), 0.99]]):
            pair = self.pair(); pair[0]["raw"]["detections"] = rows
            with self.subTest(rows=rows):
                self.assertEqual(S.evaluate_controls(pair)["status"], "FAIL_OPERATIONAL_CONTROLS")

    def test_false_positive_on_negative_fails_and_error_return_is_never_negative(self):
        pair = self.pair(); pair[1]["raw"]["detections"] = [[1, 1, 20, 20, *([1] * 10), 0.99]]
        self.assertEqual(S.evaluate_controls(pair)["status"], "FAIL_OPERATIONAL_CONTROLS")
        pair = self.pair(); pair[1]["raw"]["retval"] = 0
        with self.assertRaises(S.DetectorSemanticsError): S.evaluate_controls(pair)

    def test_population_identity_version_and_order_cannot_be_substituted(self):
        pair = self.pair()
        for invalid in ([], pair[:1], pair + pair[:1], list(reversed(pair))):
            with self.assertRaises(S.DetectorSemanticsError): S.evaluate_controls(invalid)
        for key, value in (("source_sha256", S.NEGATIVE_SHA), ("width", True), ("extra", False)):
            invalid = self.pair(); invalid[0][key] = value
            with self.subTest(key=key), self.assertRaises(S.DetectorSemanticsError): S.evaluate_controls(invalid)
        invalid = self.pair()
        invalid[1]["observed_opencv_version"] = invalid[1]["raw"]["opencv_version"] = "5.0.0.93"
        with self.assertRaises(S.DetectorSemanticsError): S.evaluate_controls(invalid)

    def test_python_equality_objects_and_tuple_coercion_are_rejected(self):
        class EqualToAnything:
            def __eq__(self, _): return True
        value = EqualToAnything()
        with self.assertRaises(S.DetectorSemanticsError): self.check(raw(), observed_opencv_version=value)
        for key, item in (("opencv_version", value), ("input_size", (512, 512))):
            r = raw(); r[key] = item
            with self.subTest(key=key), self.assertRaises(S.DetectorSemanticsError): self.check(r)
        r = raw(); r["settings"]["initial_size"] = (320, 320)
        with self.assertRaises(S.DetectorSemanticsError): self.check(r)
        for key in ("control_id", "source_sha256"):
            pair = self.pair(); pair[0][key] = value
            with self.subTest(key=key), self.assertRaises(S.DetectorSemanticsError): S.evaluate_controls(pair)

    def test_malformed_structures_and_huge_numbers_use_the_domain_error(self):
        for bad in ({}, None, object(), {"initial_size": set()}):
            r = raw(); r["settings"] = bad
            with self.subTest(kind=type(bad).__name__), self.assertRaises(S.DetectorSemanticsError): self.check(r)
        for bad in (10 ** 1000, float("nan"), float("inf")):
            row = [bad, 1, 10, 10, *([1] * 10), 0.99]
            with self.subTest(kind=type(bad).__name__), self.assertRaises(S.DetectorSemanticsError): self.check(raw([row]))


if __name__ == "__main__":
    unittest.main()
