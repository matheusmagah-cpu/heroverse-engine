from __future__ import annotations

import unittest
import contextlib
import io
import json
import copy
import socket
import tempfile
from pathlib import Path
from http.client import HTTPResponse
from types import SimpleNamespace

from unittest.mock import patch

from hero_engine.phase5_human_review import _write_json_atomic
from hero_engine.phase5_review_console import _range, _startup_notice, _vtt_from_srt, make_handler, render_console_html, review_context
from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]


class Phase5ReviewConsoleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.context = review_context(ROOT)
        cls.html = render_console_html(cls.context, "test-token").decode("utf-8")

    def test_console_is_pinned_to_frozen_standard_artifact(self) -> None:
        self.assertIn("33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c", self.html)
        self.assertIn("The 24-Hour Test: What To Do After You Pray", self.html)
        self.assertEqual(9, len(self.context["draft"]["windows"]))

    def test_dynamic_media_source_forces_resource_selection_and_exposes_status(self) -> None:
        self.assertIn("video.load()", self.html)
        self.assertIn('id="mediaStatus"', self.html)
        self.assertIn("loadedmetadata", self.html)

    def test_runtime_writer_recovers_from_transient_onedrive_destination_lock(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "review-console-status.json"
            real_replace = __import__("os").replace
            attempts = []

            def flaky(source, destination):
                attempts.append((source, destination))
                if len(attempts) == 1:
                    raise PermissionError("simulated transient OneDrive lock")
                return real_replace(source, destination)

            with patch("hero_engine.phase5_human_review.os.replace", side_effect=flaky):
                _write_json_atomic(target, {"status": "LISTENING"})
            self.assertEqual({"status": "LISTENING"}, json.loads(target.read_text(encoding="utf-8")))
            self.assertEqual(2, len(attempts))
        self.assertIn("video.addEventListener('error'", self.html)
        self.assertEqual(12, len(self.context["draft"]["human_gates"]))

    def test_console_has_all_blind_thumbnail_candidates_without_preselection(self) -> None:
        self.assertEqual({"A", "B", "C"}, set(self.context["candidates"]))
        self.assertIn("crypto.getRandomValues", self.html)
        self.assertIn('name="thumb"', self.html)
        self.assertNotIn('name="thumb" value="A" checked', self.html)

    def test_console_enforces_playback_caption_mobile_and_attestation_signals(self) -> None:
        for text in ("coverage<.95", "rateOk", "captionSeen", "mobileSeen", "endedSeen", "sequentialOk", "audio", "attest"):
            self.assertIn(text, self.html)
        self.assertIn("Every window and gate needs a status and an evidence note", self.html)

    def test_srt_is_converted_to_browser_vtt_without_changing_words(self) -> None:
        value = _vtt_from_srt("1\n00:00:01,250 --> 00:00:02,500\nTruth first.\n").decode("utf-8")
        self.assertTrue(value.startswith("WEBVTT\n\n"))
        self.assertIn("00:00:01.250 --> 00:00:02.500", value)
        self.assertIn("Truth first.", value)

    def test_range_parser_is_bounded(self) -> None:
        self.assertEqual((0, 99), _range("bytes=0-99", 1000))
        self.assertEqual((900, 999), _range("bytes=-100", 1000))
        self.assertEqual((500, 999), _range("bytes=500-", 1000))
        with self.assertRaises(ValueError):
            _range("bytes=2000-", 1000)

    def test_runtime_status_schema_is_valid(self) -> None:
        for name in ("phase5_review_console_runtime.schema.json", "phase5_review_console_access.schema.json"):
            schema = json.loads((ROOT / "schemas" / name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)

    def test_startup_log_exposes_hash_but_never_the_access_token(self) -> None:
        status = {
            "status": "LISTENING",
            "host": "127.0.0.1",
            "port": 8765,
            "video_sha256": "a" * 64,
            "token_sha256": "b" * 64,
        }
        notice = _startup_notice(status, ROOT / "output/runtime/gestor-central/review-console-access.json")
        encoded = json.dumps(notice)
        self.assertNotIn("secret-token", encoded)
        self.assertNotIn("?token=", encoded)
        self.assertEqual("b" * 64, notice["token_sha256"])

    def test_http_surface_is_local_token_guarded_and_range_capable(self) -> None:
        # Real HTTP parsing, dispatch, token/range guards and response framing;
        # only the socket transport is in-memory. This does not test a TCP bind.
        class Transport:
            def __init__(self, request, *, disconnect=False):
                self.request = io.BytesIO(request)
                self.output = bytearray()
                self.disconnect = disconnect
                self.disconnected = False

            def makefile(self, mode, *args):
                if mode != "rb":
                    raise AssertionError("unexpected socket stream")
                return self.request

            def sendall(self, data):
                if self.disconnect and b"\r\n\r\n" in self.output:
                    self.output.extend(data[:1024])
                    self.disconnected = True
                    raise ConnectionResetError("synthetic client disconnected after 1024 body bytes")
                self.output.extend(data)

        with tempfile.TemporaryDirectory(prefix="review-http-fixture-") as folder:
            root = Path(folder)
            video = root / "synthetic-range-payload.bin"
            payload = bytes(range(256)) * 8192
            video.write_bytes(payload)
            captions = root / "synthetic.srt"
            captions.write_text("1\n00:00:00,000 --> 00:00:01,000\nSynthetic test only.\n", encoding="utf-8")
            context = copy.deepcopy(self.context)
            context.update(video=video, captions=captions)
            for candidate in context["candidates"].values():
                candidate["path"] = video
            token = "integration-test-token"
            handler = make_handler(root, token, context)
            real_open = Path.open

            def confined_open(path, *args, **kwargs):
                self.assertTrue(path.resolve().is_relative_to(root))
                return real_open(path, *args, **kwargs)

            def request(target, *, headers="", disconnect=False):
                wire = f"GET {target} HTTP/1.0\r\nHost: 127.0.0.1\r\n{headers}\r\n".encode("ascii")
                transport = Transport(wire, disconnect=disconnect)
                handler(transport, ("127.0.0.1", 12345), SimpleNamespace(server_name="fixture", server_port=0))
                return transport

            def response(transport):
                parsed = HTTPResponse(Transport(bytes(transport.output)))
                parsed.begin()
                return parsed

            with patch.object(socket, "socket", side_effect=AssertionError("no network in HTTP fixture")), \
                 patch.object(socket, "create_connection", side_effect=AssertionError("no network in HTTP fixture")), \
                 patch.object(Path, "open", confined_open):
                with response(request("/")) as denied:
                    self.assertEqual(403, denied.status)
                with response(request(f"/?token={token}")) as allowed:
                    self.assertEqual(200, allowed.status)
                    self.assertIn(b"HeroVerse", allowed.read())
                with response(request(f"/media/video?token={token}", headers="Range: bytes=0-1023\r\n")) as partial:
                    self.assertEqual(206, partial.status)
                    self.assertEqual("bytes", partial.headers["Accept-Ranges"])
                    self.assertEqual(f"bytes 0-1023/{len(payload)}", partial.headers["Content-Range"])
                    self.assertEqual(payload[:1024], partial.read())
                expected_disconnect_log = io.StringIO()
                with contextlib.redirect_stderr(expected_disconnect_log):
                    disconnected = request(f"/media/video?token={token}", disconnect=True)
                self.assertTrue(disconnected.disconnected)
                with response(disconnected) as interrupted:
                    self.assertEqual(200, interrupted.status)
                    self.assertEqual(payload[:1024], interrupted.read(1024))
                self.assertEqual("", expected_disconnect_log.getvalue())
                with response(request(f"/media/captions?token={token}")) as caption_response:
                    self.assertEqual(200, caption_response.status)
                    self.assertTrue(caption_response.read().startswith(b"WEBVTT\n\n"))


if __name__ == "__main__":
    unittest.main()
