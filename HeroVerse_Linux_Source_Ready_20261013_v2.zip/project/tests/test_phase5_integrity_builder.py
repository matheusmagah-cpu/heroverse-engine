import json
import tempfile
import unittest
from pathlib import Path

from scripts.build_phase5_integrity import build


class Phase5IntegrityBuilderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.package = self.root / "output/production/phase5/pilot-001"
        self.package.mkdir(parents=True)
        (self.package / "asset.json").write_text('{"v":1}\n', encoding="utf-8")

    def test_initial_build_materializes_manifest(self):
        result = build(self.root, "2026-09-17T00:00:00+00:00")
        self.assertEqual(result["item_count"], 1)
        self.assertTrue((self.package / "integrity_manifest.json").is_file())

    def test_committed_successor_makes_historical_manifest_immutable(self):
        build(self.root, "2026-09-17T00:00:00+00:00")
        historical = (self.package / "integrity_manifest.json").read_bytes()
        (self.package / "integrity_manifest_successor.json").write_text("{}\n", encoding="utf-8")
        (self.package / "asset.json").write_text('{"v":2}\n', encoding="utf-8")
        result = build(self.root, "2026-09-18T00:00:00+00:00")
        self.assertEqual(result["status"], "PRESERVED_IMMUTABLE_HISTORY")
        self.assertEqual((self.package / "integrity_manifest.json").read_bytes(), historical)


if __name__ == "__main__":
    unittest.main()
