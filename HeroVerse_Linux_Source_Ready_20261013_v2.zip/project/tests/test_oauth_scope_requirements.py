from __future__ import annotations

import builtins
import io
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator

from hero_engine.oauth_scope_requirements import build_scope_requirement
from hero_engine.youtube_integration import INTEGRATION_SCOPES, YOUTUBE_FORCE_SSL_SCOPE


ROOT = Path(__file__).resolve().parents[1]


class OAuthScopeRequirementTests(unittest.TestCase):
    def test_caption_scope_and_console_alignment_are_explicit_and_fail_closed(self) -> None:
        # Scope decisions are real; the grant documents and media are test-only.
        with tempfile.TemporaryDirectory(prefix="oauth-scope-isolated-") as folder:
            root = Path(folder).resolve()
            for relative in (
                "config/integrations/youtube-heroverse-v1.json",
                "schemas/oauth_runtime_scope_requirement.schema.json",
            ):
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / relative).read_bytes())
            video = root / "synthetic.mp4"
            caption_path = root / "synthetic.srt"
            caption_path.write_text("1\n00:00:00,000 --> 00:00:01,000\nSynthetic scope fixture.\n", encoding="utf-8")
            receipt_path = root / "output/integrations/youtube/heroverse/connection-receipt.json"
            observation_path = root / "output/integrations/youtube/heroverse/google-auth-platform-observation.json"
            package_path = root / "output/production/phase5/pilot-001/creative-v3/publication_package.json"
            receipt = {"authorization": {"granted_scopes": list(INTEGRATION_SCOPES)}}
            observation = {"declared_scopes": {
                "non_sensitive_count": 0, "sensitive_count": 4, "restricted_count": 0,
                "configuration_matches_runtime": True,
            }}
            for path, value in (
                (receipt_path, receipt),
                (observation_path, observation),
                (package_path, {"video": {"path": str(video)}, "captions": {"path": str(caption_path)}}),
            ):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(value), encoding="utf-8")
            executables = {name: shutil.which(name) for name in ("ffmpeg", "ffprobe")}
            self.assertTrue(all(executables.values()), "The installed free FFmpeg/FFprobe must be available")
            executables = {name: str(Path(path).resolve()) for name, path in executables.items()}
            render_command = [
                executables["ffmpeg"], "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
                "-f", "lavfi", "-i", "color=c=black:s=32x32:r=1:d=1", "-an",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", str(video),
            ]
            probe_command = [
                executables["ffprobe"], "-v", "error", "-select_streams", "s",
                "-show_entries", "stream=index", "-of", "json", str(video),
            ]
            original_run = subprocess.run
            original_popen = subprocess.Popen
            launching = False
            violations = []
            processes = []
            child_environment = {
                key: os.environ[key]
                for key in ("SystemRoot", "WINDIR") if key in os.environ
            }
            child_environment.update({"TEMP": str(root), "TMP": str(root)})

            def checked_open(original):
                def open_local(file, *args, **kwargs):
                    # CPython creates anonymous subprocess pipes inside Popen.
                    if isinstance(file, int) and launching:
                        return original(file, *args, **kwargs)
                    path = Path(os.fsdecode(file)).resolve()
                    if not path.is_relative_to(root):
                        violations.append(str(path))
                        raise AssertionError("Scope test attempted non-fixture IO")
                    return original(file, *args, **kwargs)
                return open_local

            def run_local(command, *args, **kwargs):
                nonlocal launching
                if args or not isinstance(command, (tuple, list)) or not command:
                    raise AssertionError("Unexpected scope-test subprocess contract")
                actual = list(command)
                if actual[0] == "ffprobe":
                    actual[0] = executables["ffprobe"]
                if actual not in (render_command, probe_command) or kwargs.get("shell"):
                    violations.append("unapproved subprocess")
                    raise AssertionError("Only the fixed synthetic render and probe are permitted")
                if set(kwargs) - {"check", "capture_output", "text", "timeout"}:
                    raise AssertionError("Unexpected subprocess options")
                timeout = min(float(kwargs.pop("timeout", 30)), 30)
                if timeout <= 0:
                    raise AssertionError("A positive bounded timeout is required")
                launching = True
                try:
                    completed = original_run(
                        actual, **kwargs, timeout=timeout, cwd=root, env=child_environment,
                    )
                finally:
                    launching = False
                processes.append({
                    "tool": Path(actual[0]).name, "returncode": completed.returncode,
                    "timeout_seconds": timeout, "stdout": completed.stdout, "stderr": completed.stderr,
                })
                return completed

            def popen_local(command, *args, **kwargs):
                if not launching or list(command) not in (render_command, probe_command):
                    raise AssertionError("Direct subprocess launch is forbidden")
                return original_popen(command, *args, **kwargs)

            with ExitStack() as guards:
                for module, name in ((builtins, "open"), (io, "open"), (os, "open")):
                    guards.enter_context(patch.object(module, name, checked_open(getattr(module, name))))
                guards.enter_context(patch.object(subprocess, "run", side_effect=run_local))
                guards.enter_context(patch.object(subprocess, "Popen", side_effect=popen_local))
                for module, name in ((socket, "socket"), (socket, "create_connection"), (sqlite3, "connect"), (os, "system")):
                    guards.enter_context(patch.object(module, name, side_effect=AssertionError("External action forbidden in scope test")))
                subprocess.run(render_command, check=True, capture_output=True, text=True)
                self.assertTrue(video.is_file())
                self.assertGreater(video.stat().st_size, 0)
                report = build_scope_requirement(root, created_at="2026-09-03T23:59:00Z")
                schema = json.loads((root / "schemas/oauth_runtime_scope_requirement.schema.json").read_text(encoding="utf-8"))
                # A second grant fixture exercises the fail-closed branch, not a retry.
                receipt["authorization"]["granted_scopes"].remove(YOUTUBE_FORCE_SSL_SCOPE)
                observation["declared_scopes"]["sensitive_count"] = 3
                observation["declared_scopes"]["configuration_matches_runtime"] = False
                receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
                observation_path.write_text(json.dumps(observation), encoding="utf-8")
                missing_report = build_scope_requirement(root, created_at="2026-09-03T23:59:00Z")
                Draft202012Validator(schema).validate(missing_report)
            self.assertEqual([], violations)
            self.assertEqual(["ffmpeg.exe", "ffprobe.exe", "ffprobe.exe"], [item["tool"] for item in processes])
            self.assertTrue(all(item["returncode"] == 0 and item["timeout_seconds"] == 30 for item in processes))
            self.assertTrue(all(json.loads(item["stdout"]).get("streams") == [] for item in processes[1:]))
            self.assertEqual("BLOCKED_MISSING_GRANT_AND_CONSOLE_MISMATCH", missing_report["status"])
            self.assertIn(YOUTUBE_FORCE_SSL_SCOPE, missing_report["missing_scopes"])
            self.assertFalse(missing_report["console_alignment"]["configuration_matches_runtime"])
            for capability in ("CAPTION_TRACK_UPLOAD", "CANARY_PACKAGE_TREATMENT", "PUBLIC_VISIBILITY_FINALIZATION"):
                self.assertFalse(next(item for item in missing_report["capabilities"] if item["capability"] == capability)["granted_now"])
            print("SYNTHETIC_SCOPE_PROCESSES=" + json.dumps(processes, sort_keys=True))
        Draft202012Validator(schema).validate(report)
        self.assertEqual(4, len(INTEGRATION_SCOPES))
        self.assertIn(YOUTUBE_FORCE_SSL_SCOPE, report["required_scopes"])
        self.assertEqual(0, report["caption_delivery"]["embedded_subtitle_stream_count"])
        self.assertTrue(report["caption_delivery"]["sidecar_exists"])
        caption = next(item for item in report["capabilities"] if item["capability"] == "CAPTION_TRACK_UPLOAD")
        if YOUTUBE_FORCE_SSL_SCOPE in report["current_granted_scopes"]:
            self.assertEqual([], report["missing_scopes"])
            self.assertTrue(caption["granted_now"])
            self.assertTrue(report["console_alignment"]["configuration_matches_runtime"])
            self.assertEqual("PASS", report["status"])
        else:
            self.assertIn(YOUTUBE_FORCE_SSL_SCOPE, report["missing_scopes"])
            self.assertFalse(caption["granted_now"])
            self.assertEqual("BLOCKED_MISSING_GRANT_AND_CONSOLE_MISMATCH", report["status"])
        self.assertEqual("captions.insert", caption["api_method"])
        self.assertIn("no caption update/delete", caption["least_use_boundary"])
        visibility = next(item for item in report["capabilities"] if item["capability"] == "PUBLIC_VISIBILITY_FINALIZATION")
        self.assertEqual("videos.update", visibility["api_method"])
        self.assertIn("private to public", visibility["least_use_boundary"])
        package = next(item for item in report["capabilities"] if item["capability"] == "CANARY_PACKAGE_TREATMENT")
        self.assertEqual("videos.update(snippet)/thumbnails.set", package["api_method"])
        self.assertIn("rolls both fields back", package["least_use_boundary"])
        self.assertTrue(package["granted_now"])
        self.assertTrue(report["protected_action_required"])


if __name__ == "__main__":
    unittest.main()
