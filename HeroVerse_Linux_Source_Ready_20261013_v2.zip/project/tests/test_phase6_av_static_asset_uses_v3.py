"""New V3 contract/integration tests; no old decoder, OCR or registration.

One current question-source batch is used by the real integration test. Other
source callbacks are explicit fixtures, not media/rights approvals. Temporary
input manifests never enter the operational V3 namespace.
"""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_static_asset_uses_v3 as uses
from hero_engine import phase6_av_asset_use_binding_v2 as joiner
from tests.static_input_isolation import historical_input, install_schema, fixture_reader

ROOT = Path(__file__).absolute().parents[1]
SOURCES = uses.sources
HISTORICAL_INPUT = {"path": "output/operations/phase6/av-admission/static-asset-uses-v3/input.json",
                    "sha256": "3e74c984f2f76fb8d74071b0879f34fa71cd1aaa59f2ff3f84b1cf5b8e792ef9"}


class StaticAssetUsesV3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch.object(uses.previous.previous, "inspect_static_asset_uses", side_effect=AssertionError("no v2 redecode")), \
             patch.object(uses.question, "inspect_question_sources", side_effect=AssertionError("metadata only")), \
             patch.object(SOURCES, "_png", side_effect=AssertionError("no old PNG")), \
             patch.object(SOURCES.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no PNG decode")):
            cls.metadata = uses._envelope(ROOT)
        cls.proposal = uses._expected(cls.metadata[1], cls.metadata[2]["input"], cls.metadata[3])

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="uses-v3-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = self.directory = Path(temporary.name).resolve()
        self.schema_sha = install_schema(self, SOURCES, ROOT, self.root, uses.SCHEMA)

    def binding(self, document=None, name="input.json", *, historical=False):
        if historical:
            self.assertIsNone(document)
            return historical_input(self, SOURCES, ROOT, HISTORICAL_INPUT, self.proposal)
        path = self.directory / name
        raw = SOURCES._canonical(self.proposal if document is None else document)
        path.write_bytes(raw)
        return {"path": path.relative_to(self.root).as_posix(), "sha256": SOURCES._sha(raw)}

    def metadata_fixture(self, _root):
        self.assertIn(_root, (ROOT, self.root))
        reader = fixture_reader(SOURCES, self.root, uses.SCHEMA, self.schema_sha)
        if _root == ROOT:
            reader = SOURCES._Reader(ROOT)
            reader.bindings = copy.deepcopy(self.metadata[0].bindings)
        return (reader, *self.metadata[1:])

    def test_schema_and_proposal_preserve_25_uses_and_add_four_without_time(self):
        schema = SOURCES._json((ROOT / uses.SCHEMA).read_bytes())
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(self.proposal)
        old_schema = SOURCES._json((ROOT / uses.previous.previous.SCHEMA).read_bytes())
        self.assertFalse(Draft202012Validator(old_schema).is_valid(self.proposal))
        self.assertEqual(self.proposal["sources"][:23], self.metadata[2]["input"]["sources"])
        self.assertEqual(self.proposal["uses"][:25], self.metadata[2]["input"]["uses"])
        self.assertEqual((len(self.proposal["sources"]), len(self.proposal["uses"])), (27, 29))
        self.assertEqual([row["visual_state_id"] for row in self.proposal["uses"][25:]], uses.question.CONFIG["state_ids"])
        self.assertEqual([row["literal_copy"] for row in self.proposal["uses"][25:]],
            [["Test", "Loud is not true"], ["Fully true?"], ["Fully true?", "Or only possible?"], ["Character", "Is this how I should act?"]])
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
             patch.object(uses.question, "inspect_question_sources", side_effect=AssertionError("proposal not source inspection")):
            self.assertEqual(uses.proposed_static_asset_uses(ROOT), self.proposal)

    def test_wrong_copy_mapping_order_counts_time_cost_authority_and_history_block_before_batch(self):
        for kind in ("old_copy", "new_copy", "source_map", "order", "duplicate", "missing", "time", "cost", "float", "authority", "old_anchor", "question_claim"):
            document = copy.deepcopy(self.proposal)
            if kind == "old_copy": document["uses"][0]["literal_copy"] = ["unsupported"]
            elif kind == "new_copy": document["uses"][25]["literal_copy"] = ["TEST", "LOUD IS NOT TRUE"]
            elif kind == "source_map": document["uses"][25]["source_id"] = document["sources"][0]["source_id"]
            elif kind == "order": document["uses"][25], document["uses"][26] = document["uses"][26], document["uses"][25]
            elif kind == "duplicate": document["uses"][-1] = copy.deepcopy(document["uses"][-2])
            elif kind == "missing": document["sources"].pop()
            elif kind == "time": document["uses"][25]["start_frame"] = 0
            elif kind == "cost": document["technical_cost_brl"] = 1
            elif kind == "float": document["technical_cost_brl"] = 0.0
            elif kind == "authority": document["publication_authorized"] = True
            elif kind == "old_anchor": document["source_bindings"]["v2_execution"]["sha256"] = "0" * 64
            else: document["source_bindings"]["question_rights_claim"]["sha256"] = "0" * 64
            binding = self.binding(document, kind + ".json")
            with self.subTest(kind=kind), patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
                 patch.object(uses.question, "inspect_question_sources", side_effect=AssertionError("invalid input before source batch")) as batch:
                with self.assertRaises((ValueError, ValidationError)):
                    uses.inspect_static_asset_uses(self.root, binding=binding)
                batch.assert_not_called()

    def test_binding_pin_canonical_json_and_namespace_are_not_candidate_labels(self):
        binding = self.binding()
        path = self.root / binding["path"]
        path.write_bytes(path.read_bytes() + b"\n")
        given = {**binding, "sha256": SOURCES._sha(path.read_bytes())}
        variants = [given, {**binding, "sha256": "0" * 64}, {**binding, "path": "../input.json"}, {**binding, "extra": True}]
        for candidate in variants:
            with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
                 patch.object(uses.question, "inspect_question_sources", side_effect=AssertionError("binding before batch")), self.assertRaises(ValueError):
                uses.inspect_static_asset_uses(self.root, binding=candidate)

    def test_question_request_receipt_or_claim_corruption_is_rejected_by_external_pin(self):
        read_bytes = Path.read_bytes
        for bound in (uses.REQUEST, uses.REGISTRATION, uses.CLAIM):
            target = ROOT / bound["path"]
            def corrupt(path):
                data = read_bytes(path)
                return data + b"fixture-only-instrumented-drift" if path == target else data
            with self.subTest(target=target.name), patch.object(Path, "read_bytes", corrupt), \
                 patch.object(uses.question, "inspect_question_sources", side_effect=AssertionError("metadata only")), self.assertRaisesRegex(ValueError, "hash mismatch"):
                uses._registry(SOURCES._Reader(ROOT))

    def test_source_batch_hash_must_equal_independently_registered_source(self):
        binding = self.binding()
        wrong = {"inspection_id": "fixture-wrong-source", "dependency_bindings":
            sorted(self.metadata[3]["request"]["source_preflight_dependencies"], key=lambda item: item["path"])}
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
             patch.object(uses.question, "inspect_question_sources", return_value=[wrong] * 4), \
             patch.object(uses.rights, "_validate", side_effect=AssertionError("no rights replay before source matches")):
            with self.assertRaisesRegex(ValueError, "externally registered rights source"):
                uses.inspect_static_asset_uses(self.root, binding=binding)

    def test_model_limit_is_32_mib_only_for_exact_fixed_hash_and_size(self):
        model_path, (digest, size) = next((path, pin) for path, pin in uses.question.MODEL_PINS.items() if pin[1] > 16 * 1024**2)
        class SizeOnly:
            def __len__(self): return size
        class ReaderFixture:
            root = ROOT
            def __init__(self): self.calls = []
            def read_path(self, path, sha, *, limit):
                self.calls.append((path, sha, limit))
                if size > limit: raise ValueError("fixture file exceeds bounded reader")
                return SizeOnly()
        reader = ReaderFixture()
        bound = {"path": str(ROOT / model_path), "sha256": digest, "size_bytes": size}
        uses._dependencies(reader, [bound])
        self.assertEqual(reader.calls[0][2], 32 * 1024**2)
        for mutation in ({**bound, "sha256": "0" * 64}, {**bound, "size_bytes": float(size)},
                         {**bound, "path": str(ROOT / "fixture-unlisted-model.onnx")}):
            with self.assertRaises(ValueError):
                uses._dependencies(ReaderFixture(), [mutation])
        with self.assertRaises(ValueError):
            uses._dependencies(ReaderFixture(), [bound, bound])

    def test_case_change_to_already_bound_copy_is_rejected_by_pure_compiler(self):
        literal = copy.deepcopy(self.metadata[1])
        indexed = {state["state_id"]: state for row in literal["rows"] for state in row["states"]}
        indexed[self.proposal["uses"][0]["visual_state_id"]]["visual_content"]["literal_copy"] = ["changed"]
        with self.assertRaisesRegex(ValueError, "existing use"):
            uses._expected(literal, self.metadata[2]["input"], self.metadata[3])

    def test_real_integration_replays25_and_one_question_batch_then_joins_the_same_v5(self):
        binding = self.binding(historical=True)
        real_batch = uses.question.inspect_question_sources
        with patch.object(uses.previous.previous, "inspect_static_asset_uses", side_effect=AssertionError("no old source inspector")), \
             patch.object(uses.previous.previous.compact, "inspect_compact_sources", side_effect=AssertionError("no compact decode")), \
             patch.object(SOURCES, "_png", side_effect=AssertionError("no PNG decode")), \
             patch.object(SOURCES.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no new PNG decode")), \
             patch.object(uses.question, "inspect_question_sources", wraps=real_batch) as batch, \
             patch.object(uses.rights, "inspect_question_asset_rights_batch", side_effect=AssertionError("no new registry/batch review")), \
             patch("subprocess.Popen", side_effect=AssertionError("no process")), \
             patch("socket.create_connection", side_effect=AssertionError("no network")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("no writes during inspection")):
            proof = uses.inspect_static_asset_uses(ROOT, binding=binding)
        batch.assert_called_once()
        self.assertEqual((proof["source_count"], proof["use_count"], proof["unique_png_content_count"], proof["lineage_count"]), (27, 29, 26, 3))
        self.assertEqual(len(proof["remaining_unbound_visual_state_ids"]), 71)
        self.assertEqual(proof["sources"][:23], self.metadata[2]["inspection"]["sources"])
        self.assertEqual(proof["uses"][:25], self.metadata[2]["inspection"]["uses"])
        self.assertTrue(all(value is False for value in proof["authority"].values()))
        self.assertFalse(proof["source_ready"])
        self.assertFalse(proof["global_schedule_created"])
        self.assertFalse(proof["calibrated_timing_available"])
        mapped = {row["visual_state_id"]: row for row in proof["uses"]}
        lexical = mapped["visual-u020-s01"]["entry"]
        self.assertEqual((lexical["kind"], lexical["char_start"], lexical["char_end"], lexical["text"]),
                         ("LEXICAL_START", 18, 35, "or only possible?"))
        self.assertEqual(mapped["visual-u016-s01"]["entry"]["kind"], "CONTINUE_STATE")
        self.assertEqual(mapped["visual-u011-s01"]["entry"]["text"], "write")
        self.assertEqual(proof["v2_replay_evidence"]["rights_evaluation_calls"], 0)
        self.assertEqual(proof["question_rights_replay_evidence"]["new_lineage_count"], 0)
        self.assertEqual(proof["image_decode_calls"], 0)
        self.assertEqual(proof["ocr_inference_calls"], 0)
        bound = {"path": binding["path"], "sha256": "sha256:" + binding["sha256"]}
        joined = joiner.join(proof, bound, self.metadata[1])
        self.assertEqual(joined["use_count"], 29)
        self.assertEqual(len(joined["remaining_unbound_visual_state_ids"]), 71)
        dependencies = {item["path"]: item for item in proof["dependency_bindings"]}
        for item in self.metadata[2]["dependency_bindings"]:
            self.assertEqual(dependencies[item["path"]], item)
        for item in (uses.REQUEST, uses.REGISTRATION, uses.CLAIM):
            self.assertEqual(dependencies[str(ROOT / item["path"])]["sha256"], item["sha256"])

    def test_verifier_reopens_source_and_rejects_numeric_or_authority_relabel(self):
        expected = {"version": uses.VERSION, "source_count": 27, "source_ready": False, "authority": dict(uses.AUTHORITY)}
        binding = self.binding()
        with patch.object(uses, "inspect_static_asset_uses", return_value=expected) as inspect:
            self.assertEqual(uses.verify_static_asset_uses(copy.deepcopy(expected), self.root, binding=binding), expected)
            inspect.assert_called_once_with(self.root, binding=binding)
            for field, value in (("source_count", 27.0), ("source_ready", True), ("duration_ms", 1000)):
                candidate = copy.deepcopy(expected)
                candidate[field] = value
                with self.assertRaises(ValueError):
                    uses.verify_static_asset_uses(candidate, self.root, binding=binding)


if __name__ == "__main__":
    unittest.main()
