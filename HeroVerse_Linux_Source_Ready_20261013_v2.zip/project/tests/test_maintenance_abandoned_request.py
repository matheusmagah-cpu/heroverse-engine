"""Characterization only: abandoned maintenance, using production functions.

No manager loop, daily entry point, real recovery, live queue, credentials or
network are executed. Existing fixture builders and selected tests are reused.
PowerShell runs extracted functions only, against TemporaryDirectory paths.
Passing means the observed behavior is reproduced, not that recovery is fixed.
"""

from __future__ import annotations

import importlib.util
import json
import socket
import subprocess
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from jsonschema import ValidationError

import hero_engine.maintenance_protocol as protocol
import hero_engine.central_manager_phase5 as manager


PROJECT = Path(__file__).resolve().parents[1]
REQUEST_ID = "maintenance-request-20260908T1258124421621Z-0e1dac1f"
OTHER_ID = "maintenance-request-20260908T1258124421621Z-bbbbbbbb"
REQUESTED = datetime(2026, 9, 8, 12, 58, 19, 82903, tzinfo=timezone.utc)
PAUSE_BYTES = b"OWNER_PAUSE_MUST_SURVIVE\n"


def _existing_module(filename):
    """Import definitions, never execute the source file as a test/script."""
    spec = importlib.util.spec_from_file_location(
        "_abandonment_" + Path(filename).stem, PROJECT / "tests" / filename
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


existing = _existing_module("test_daily_maintenance_protocol.py")
boundary_fixtures = _existing_module("test_maintenance_boundary_snapshot.py")


class AbandonedMaintenanceRequestTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="hero-abandoned-request-")
        self.addCleanup(self.directory.cleanup)
        self.root = existing.DailyMaintenanceProtocolTests._base(self.directory.name)
        self.pause = self.root / protocol.RUNTIME / "PAUSE"
        self.pause.write_bytes(PAUSE_BYTES)
        for name in ("connect", "connect_ex"):
            blocker = patch.object(
                socket.socket, name, side_effect=AssertionError("network forbidden")
            )
            blocker.start()
            self.addCleanup(blocker.stop)

    def _request(self, request_id=REQUEST_ID, requester_pid=18748):
        return protocol.create_request(
            self.root, request_id=request_id, requester_pid=requester_pid,
            requested_at=REQUESTED, guard_seconds=1800,
        )

    def _ack(self):
        return json.loads((self.root / protocol.ACK_PATH).read_text("utf-8"))

    def _ps(self, functions, body):
        source = "\n".join(
            existing.DailyMaintenanceProtocolTests._powershell_function(name)
            for name in functions
        )
        harness = self.root / "isolated-functions.ps1"
        harness.write_text(
            "$ErrorActionPreference='Stop'\n"
            + source + "\n" + body + "\n",
            encoding="utf-8",
        )
        # The full daily.ps1 is never dot-sourced or executed.
        return subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-File", str(harness)],
            capture_output=True, text=True, timeout=8, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            cwd=str(self.root),
        )

    @staticmethod
    def _quote(path):
        return "'" + str(path).replace("'", "''") + "'"

    def test_requester_disappears_before_finalization_barrier_never_self_releases(self):
        request = self._request()
        original = (self.root / protocol.REQUEST_PATH).read_bytes()
        # Simulated owner identity changes. The production barrier does not
        # consult this probe at all: absence cannot currently trigger cleanup.
        with patch.object(protocol, "_process_alive", return_value=True) as probe:
            for state, alive in (("ALIVE", True), ("ABSENT", False),
                                 ("PID_REUSED_FOREIGN", True)):
                with self.subTest(owner_state=state):
                    probe.return_value = alive
                    self.assertTrue(protocol.maintenance_barrier(self.root, manager_pid=4242))
                    self.assertEqual("READY_TO_STOP", self._ack()["status"])
                    self.assertEqual(REQUEST_ID, self._ack()["request_id"])
                    self.assertEqual(original, (self.root / protocol.REQUEST_PATH).read_bytes())
                    self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())
            probe.assert_not_called()
        self.assertEqual(18748, request["requester_pid"])
        self.assertFalse(any("generation" in key or "creation" in key for key in request))
        self.assertFalse((self.root / protocol.RECOVERY_WINDOW_PATH).exists())

    def test_invalid_ack_is_rejected_then_regenerated_without_opening_barrier(self):
        self._request()
        bad = {"request_id": REQUEST_ID, "manager_pid": 4242,
               "status": "READY_TO_STOP", "external_effect_boundary_closed": True}
        (self.root / protocol.ACK_PATH).write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(ValidationError):
            protocol.validate(self.root, "central_manager_maintenance_ack.schema.json", bad)
        self.assertTrue(protocol.maintenance_barrier(self.root, manager_pid=4242))
        protocol.validate(self.root, "central_manager_maintenance_ack.schema.json", self._ack())
        self.assertTrue((self.root / protocol.REQUEST_PATH).exists())
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_substituted_request_invalidates_old_recovery_window_and_cleanup(self):
        self._request()
        protocol.arm_recovery_window(
            self.root, request_id=REQUEST_ID, manager_pid=4242,
            duration_seconds=60, armed_at=REQUESTED,
        )
        self._request(OTHER_ID)
        replaced = (self.root / protocol.REQUEST_PATH).read_bytes()
        self.assertIsNone(protocol.recovery_window_state(
            self.root, manager_pid=4242, now=REQUESTED,
        ))
        result = self._ps(
            ["Remove-OwnedBarrierFileBounded"],
            "Remove-OwnedBarrierFileBounded -Path "
            + self._quote(self.root / protocol.REQUEST_PATH)
            + f" -ExpectedRequestId '{REQUEST_ID}' -TimeoutSeconds 1",
        )
        self.assertNotEqual(0, result.returncode)
        self.assertIn("Refusing to remove a foreign", result.stderr)
        self.assertEqual(replaced, (self.root / protocol.REQUEST_PATH).read_bytes())
        self.assertTrue(protocol.maintenance_barrier(self.root, manager_pid=4242))
        self.assertEqual(OTHER_ID, self._ack()["request_id"])
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_wrong_manager_pid_cannot_consume_recovery_window(self):
        self._request()
        protocol.arm_recovery_window(
            self.root, request_id=REQUEST_ID, manager_pid=4242,
            duration_seconds=60, armed_at=REQUESTED,
        )
        with self.assertRaisesRegex(PermissionError, "PID mismatch"):
            protocol.recovery_window_state(self.root, manager_pid=7777, now=REQUESTED)
        self.assertTrue(protocol.maintenance_barrier(self.root, manager_pid=4242))
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_real_frozen_identity_function_distinguishes_alive_absent_reuse_unknown(self):
        # Only OS identity acquisition is doubled; comparisons are the actual
        # Get-FrozenProcessDisposition implementation. No host PID is queried.
        body = r"""
function Get-CimInstance { param($ClassName,$Filter,$ErrorAction)
    if ($script:caseName -eq 'UNKNOWN') { throw 'simulated unavailable query' }
    if ($script:caseName -eq 'ABSENT') { return $null }
    return [pscustomobject]@{ProcessId=99}
}
function Get-FrozenProcessIdentity { param($Process,$Role)
    $identity = $expected | Select-Object *
    if ($script:caseName -eq 'REUSED') {
        $identity.creation_utc_ticks=2
        $identity.handle_creation_utc_ticks=2
    }
    return $identity
}
$expected=[pscustomobject]@{
    role='MANAGER'; process_id=99; parent_process_id=88
    creation_utc_ticks=1; handle_creation_utc_ticks=1
    executable_path='C:\fixture\python.exe'; command_line_hash='fixture'
}
$values=@(foreach ($script:caseName in @('ALIVE','ABSENT','REUSED','UNKNOWN')) {
    Get-FrozenProcessDisposition -ExpectedIdentity $expected
})
ConvertTo-Json -InputObject $values -Compress
"""
        result = self._ps(["Get-FrozenProcessDisposition"], body)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual(
            ["EXACT_ALIVE", "ABSENT", "PID_REUSED_FOREIGN", "IDENTITY_UNCERTAIN"],
            json.loads(result.stdout),
        )
        # This utility protects the manager process chain; the historic request
        # lacks the requester generation needed to use it for owner recovery.
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_cleanup_primitive_checks_id_but_not_request_bytes_or_ack(self):
        self._request()
        original = (self.root / protocol.REQUEST_PATH).read_bytes()
        self._request(requester_pid=7777)  # Same ID, changed owner/payload.
        self.assertNotEqual(original, (self.root / protocol.REQUEST_PATH).read_bytes())
        invalid_ack = b'{"invalid":true}\n'
        (self.root / protocol.ACK_PATH).write_bytes(invalid_ack)
        result = self._ps(
            ["Remove-OwnedBarrierFileBounded"],
            "Remove-OwnedBarrierFileBounded -Path "
            + self._quote(self.root / protocol.REQUEST_PATH)
            + f" -ExpectedRequestId '{REQUEST_ID}' -TimeoutSeconds 1",
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertFalse((self.root / protocol.REQUEST_PATH).exists())
        self.assertEqual(invalid_ack, (self.root / protocol.ACK_PATH).read_bytes())
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())
        # Characterizes a LOW-LEVEL primitive, not an authorization to invoke
        # it directly in production. The complete caller supplies other gates.

    def test_owned_cleanup_preserves_pause_and_paused_cycle_has_no_release(self):
        self._request()
        protocol.maintenance_barrier(self.root, manager_pid=4242)
        lock_path = self.root / protocol.RUNTIME / "manager-lock.json"
        before_lock = lock_path.read_bytes()
        request_path = self.root / protocol.REQUEST_PATH
        ack_path = self.root / protocol.ACK_PATH
        recovery_path = self.root / protocol.RECOVERY_WINDOW_PATH
        body = (
            "$requestPath=" + self._quote(request_path) + "\n"
            "$ackPath=" + self._quote(ack_path) + "\n"
            "$recoveryWindowPath=" + self._quote(recovery_path) + "\n"
            "foreach ($path in @($recoveryWindowPath,$ackPath,$requestPath)) {\n"
            f" Remove-OwnedBarrierFileBounded -Path $path -ExpectedRequestId '{REQUEST_ID}'\n"
            "}\n"
            f"Wait-BarrierReleaseSettled -ExpectedRequestId '{REQUEST_ID}' "
            "-TimeoutSeconds 2 -QuietMilliseconds 100\n"
        )
        result = self._ps(
            ["Remove-OwnedBarrierFileBounded", "Wait-BarrierReleaseSettled"], body
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertFalse(protocol.maintenance_barrier(self.root, manager_pid=4242))
        with patch.object(
            manager, "materialize_autonomous_quality",
            side_effect=AssertionError("production QA forbidden"),
        ) as production:
            # Unit call only, never manager.loop(), process, thread or server.
            status = manager.run_cycle(self.root)
            production.assert_not_called()
        self.assertEqual("PAUSED", status["mode"])
        self.assertEqual("BLOCKED", status["publication_status"])
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())
        self.assertEqual(before_lock, lock_path.read_bytes())

    def test_normal_recovery_boundary_remains_blocked_by_owner_pause(self):
        # Reuse the existing isolated external-surface fixture. The actual
        # boundary code and strict lock/boundary schemas are not mocked.
        case = boundary_fixtures.MaintenanceBoundarySnapshotTests()
        case.setUp()
        try:
            pause = case.root / protocol.RUNTIME / "PAUSE"
            pause.write_bytes(PAUSE_BYTES)
            result = case._capture()
            self.assertEqual(["PHASE5_MANAGER_PAUSE_TRIGGER_PRESENT"], result["blockers"])
            self.assertFalse(result["external_effect_boundary_closed"])
            self.assertEqual(PAUSE_BYTES, pause.read_bytes())
        finally:
            case.doCleanups()


def load_tests(loader, tests, pattern):
    """One explicit focal suite: no inherited/discovered unrelated test cases."""
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(AbandonedMaintenanceRequestTests))
    for name in (
        "test_zero_api_ready_ack_is_read_only_for_operational_state",
        "test_any_active_lease_blocks_manager_stop",
        "test_incomplete_quota_reservation_blocks_external_effect_boundary",
        "test_consumed_quota_with_open_before_journal_still_blocks",
        "test_malformed_request_holds_fail_closed_without_ack",
        "test_expired_revalidation_window_never_releases_the_request_barrier",
        "test_restart_fault_injection_never_starts_task_when_exact_chain_absence_is_uncertain",
    ):
        suite.addTest(existing.DailyMaintenanceProtocolTests(name))
    return suite
