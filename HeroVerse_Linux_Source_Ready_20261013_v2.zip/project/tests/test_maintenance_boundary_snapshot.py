"""Focused lock-snapshot tests; external operation surfaces are explicit fixtures.

These cases run the real boundary function, lock/boundary schemas, deadline
predicates and liveness wrapper. They do not read the live runtime, credentials,
queue or network, and do not claim an operational maintenance approval.
"""

from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from contextlib import ExitStack
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator, FormatChecker

import hero_engine.maintenance_protocol as protocol


PROJECT = Path(__file__).resolve().parents[1]
STAMP = datetime(2026, 9, 7, 21, 14, 34, 488250, tzinfo=timezone.utc)
PID = 32123  # Fixture identity, never queried against the host OS.
HASH = "sha256:" + "a" * 64
PUBLICATION = "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
PACKAGE = "output/operations/phase6/package-treatment-executor-status.json"
CONTROLLER = "output/operations/phase6/publication-controller-status.json"


def _stamp(value):
    return value.isoformat().replace("+00:00", "Z")


def _raw(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode("utf-8")


def _hash(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class MaintenanceBoundarySnapshotTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="heroverse-boundary-snapshot-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name).resolve()
        self.lock_path = self.root / protocol.RUNTIME / "manager-lock.json"
        self.lock_path.parent.mkdir(parents=True)
        self.clock_value = STAMP
        self.events = []
        self.inspection_times = []
        self.oauth_deadlines = []
        self.read_count = 0
        self.on_read = None
        self.on_inspect = None
        self.read_error = None
        self.alive = True
        self.liveness_error = None
        self.jobs = []
        self.package = {"status": "WAITING_FOR_PREREGISTRATION"}
        self.lock = {
            "schema_version": "1.0.0",
            "lock_id": "gestor-central-heroverse-phase5-singleton-v1",
            "state": "HELD", "holder_pid": PID,
            "holder_started_at": _stamp(STAMP - timedelta(hours=1)),
            "heartbeat_at": _stamp(STAMP - timedelta(seconds=2)),
            "lease_seconds": 120,
            "lease_expires_at": _stamp(STAMP + timedelta(seconds=118)),
            "released_at": None, "mechanism": "windows_byte_range_lock",
            "lock_file": "output/runtime/gestor-central/manager.lock",
            "technical_cost_brl": 0,
        }
        self.lock_path.write_bytes(_raw(self.lock))
        self.validators = {
            name: Draft202012Validator(
                json.loads((PROJECT / "schemas" / name).read_text(encoding="utf-8-sig")),
                format_checker=FormatChecker(),
            )
            for name in ("central_manager_lock.schema.json", "central_manager_maintenance_boundary.schema.json")
        }

    def _inspection(self, root, *, manager_pid, guard_seconds, now):
        self.assertEqual((self.root, PID), (root, manager_pid))
        self.events.append("inspect")
        self.inspection_times.append(now)
        if self.on_inspect:
            self.on_inspect()
        queue = {"database_present": True, "jobs_hash": HASH,
                 "jobs": copy.deepcopy(self.jobs), "superseded_job_ids": []}
        deadline = now + timedelta(seconds=guard_seconds)
        protected = protocol._protected_due_jobs(queue, deadline=deadline)
        operational = protocol._operational_due_jobs(queue, deadline=deadline)
        blockers = []
        if protected:
            blockers.append("PROTECTED_JOB_DUE_DURING_MAINTENANCE")
        if operational:
            blockers.append("OPERATIONAL_JOB_DUE_DURING_MAINTENANCE")
        return {
            "blockers": blockers, "queue": queue,
            "quota_ledger": {"ledger_present": True, "state_hash": HASH,
                             "tables": [{"table": value} for value in (
                                 "general_quota_debits", "upload_quota_debits", "composed_quota_reservations")]},
            "quota": {"reserved_ids": []},
            "operational_effects": {"receipts": [{"path": PUBLICATION}],
                                    "receipts_hash": HASH, "open_receipt_paths": []},
            "active_lease_job_ids": [], "operational_due_job_ids": operational,
            "protected_due_job_ids": protected,
        }

    def _external_read(self, path):
        relative = path.relative_to(self.root).as_posix()
        values = {
            PACKAGE: self.package,
            CONTROLLER: {"status": "WAITING", "quality_evaluation_id": None,
                         "release_decision": "WAIT", "publication_receipt": None},
            PUBLICATION: {"status": "COMPLETE_PUBLIC"},
            (protocol.RUNTIME / "fingerprint.json").as_posix(): {"input_fingerprint": "fixture-fingerprint"},
        }
        if relative not in values:
            raise AssertionError("Unexpected fixture read: " + relative)
        return copy.deepcopy(values[relative])

    def _validate(self, root, name, value):
        if name in self.validators:
            self.validators[name].validate(value)
        elif name not in {"phase6_package_executor_runtime.schema.json",
                           "phase6_publication_controller_runtime.schema.json", "youtube_publication_receipt.schema.json"}:
            raise AssertionError("Unexpected schema outside this focused harness: " + name)
        # Only these three external surface schemas are fixture-stubbed. The
        # changed lock path and returned boundary use the real strict schemas.

    def _oauth(self, root, *, deadline, manager_pid):
        self.assertEqual((self.root, PID), (root, manager_pid))
        self.oauth_deadlines.append(deadline)
        next_check = _stamp(STAMP + timedelta(days=1))
        result = {
            "health_status": "HEALTHY", "next_check_at": next_check,
            "refresh_receipt_id": "fixture-refresh", "refresh_tested_at": _stamp(STAMP),
            "watcher_status": "MIRRORED_AND_REFRESHED", "runtime_token_hash": "b" * 64,
            "access_token_expires_at": next_check, "source_change_pending": False,
            "manager_refresh_due_at": next_check, "blockers": [],
        }
        for role, path in (
            ("health", protocol.OAUTH_HEALTH_PATH), ("refresh", protocol.OAUTH_REFRESH_PATH),
            ("watcher", protocol.OAUTH_WATCHER_PATH), ("mirror", protocol.OAUTH_MIRROR_PATH),
            ("connection", protocol.OAUTH_CONNECTION_PATH), ("capability", protocol.CAPABILITY_PATH),
        ):
            result[role + "_path"] = path.as_posix()
            result[role + "_hash"] = HASH
        return result

    def _capture(self, *, now=None):
        original_read_bytes = Path.read_bytes
        original_file_hash = protocol.file_hash
        case = self

        class FixtureClock(datetime):
            @classmethod
            def now(cls, tz=None):
                case.events.append("clock")
                case.assertEqual(timezone.utc, tz)
                return case.clock_value

        def read_bytes(path):
            if path == self.lock_path:
                self.events.append("read")
                self.read_count += 1
                if self.read_error:
                    raise self.read_error
                if self.on_read:
                    return self.on_read(original_read_bytes)
            return original_read_bytes(path)

        def file_hash(path):
            if path == self.lock_path:
                raise AssertionError("Lock JSON and hash must not reopen independent generations")
            return original_file_hash(path)

        def process_alive(process_id):
            self.assertEqual(PID, process_id)
            if self.liveness_error:
                raise self.liveness_error
            return self.alive

        with ExitStack() as stack:
            stack.enter_context(patch.object(Path, "read_bytes", read_bytes))
            stack.enter_context(patch.object(protocol, "datetime", FixtureClock))
            stack.enter_context(patch.object(protocol, "_read", side_effect=self._external_read))
            stack.enter_context(patch.object(protocol, "file_hash", side_effect=file_hash))
            stack.enter_context(patch.object(protocol, "validate", side_effect=self._validate))
            stack.enter_context(patch.object(protocol, "inspect_quiescence", side_effect=self._inspection))
            stack.enter_context(patch.object(protocol, "oauth_health_snapshot", side_effect=self._oauth))
            stack.enter_context(patch.object(protocol, "_process_alive", side_effect=process_alive))
            stack.enter_context(patch("hero_engine.central_manager_phase5.input_fingerprint", return_value="fixture-fingerprint"))
            result = protocol.capture_operational_boundary(
                self.root, manager_pid=PID,
                request_id="maintenance-request-20260907T2114344882500Z-1234abcd",
                guard_seconds=840, role="POST_CYCLE", require_barrier=False, now=now,
            )
        self.assertEqual(1, self.read_count)
        return result

    def _assert_closed(self, result):
        self.assertEqual([], result["blockers"])
        self.assertTrue(result["external_effect_boundary_closed"])
        self.assertTrue(result["runtime_pid_alive"])
        self.assertTrue(result["runtime_lock_held"])
        self.assertTrue(result["runtime_lease_valid"])

    def _assert_blocked(self, result, blocker):
        self.assertIn(blocker, result["blockers"])
        self.assertFalse(result["external_effect_boundary_closed"])

    def test_read_finishes_before_clock_including_heartbeat_during_io(self):
        def delayed_io(read):
            self.clock_value = STAMP + timedelta(seconds=3)
            self.lock["heartbeat_at"] = _stamp(self.clock_value)
            self.lock["lease_expires_at"] = _stamp(self.clock_value + timedelta(seconds=120))
            self.lock_path.write_bytes(_raw(self.lock))
            return read(self.lock_path)
        self.on_read = delayed_io
        result = self._capture()
        self._assert_closed(result)
        self.assertEqual(["read", "clock", "inspect"], self.events)
        self.assertEqual(_stamp(self.clock_value), result["observed_at"])
        self.assertEqual([self.clock_value], self.inspection_times)
        self.assertEqual(_hash(_raw(self.lock)), result["runtime_lock_hash"])

    def test_heartbeat_during_inspection_keeps_original_json_and_hash_snapshot(self):
        original = self.lock_path.read_bytes()
        def heartbeat():
            self.clock_value = STAMP + timedelta(seconds=5)
            self.lock["heartbeat_at"] = _stamp(self.clock_value)
            self.lock["lease_expires_at"] = _stamp(self.clock_value + timedelta(seconds=120))
            self.lock_path.write_bytes(_raw(self.lock))
        self.on_inspect = heartbeat
        result = self._capture()
        self._assert_closed(result)
        self.assertEqual(["read", "clock", "inspect"], self.events)
        self.assertEqual(_stamp(STAMP), result["observed_at"])
        self.assertEqual(_hash(original), result["runtime_lock_hash"])
        self.assertNotEqual(_hash(self.lock_path.read_bytes()), result["runtime_lock_hash"])

    def test_explicit_now_is_preserved_without_reading_host_clock(self):
        self.clock_value = STAMP + timedelta(days=300)
        result = self._capture(now=STAMP)
        self._assert_closed(result)
        self.assertEqual(["read", "inspect"], self.events)
        self.assertEqual([STAMP], self.inspection_times)
        self.assertEqual(_stamp(STAMP), result["observed_at"])

    def test_future_heartbeat_one_microsecond_is_rejected_without_tolerance(self):
        self.lock["heartbeat_at"] = _stamp(STAMP + timedelta(microseconds=1))
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_LEASE_NOT_VALID")
        self.assertFalse(result["runtime_lease_valid"])

    def test_lease_expiring_exactly_at_observation_is_rejected(self):
        self.lock["lease_expires_at"] = _stamp(STAMP)
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_LEASE_NOT_VALID")

    def test_lease_already_expired_is_rejected(self):
        self.lock["lease_expires_at"] = _stamp(STAMP - timedelta(microseconds=1))
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_LEASE_NOT_VALID")

    def test_holder_mismatch_still_blocks_with_valid_lease(self):
        self.lock["holder_pid"] = PID + 1
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_NOT_HELD")
        self.assertFalse(result["runtime_lock_held"])

    def test_released_lock_still_blocks_with_valid_lease(self):
        self.lock.update(state="RELEASED", released_at=_stamp(STAMP))
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_NOT_HELD")

    def test_real_lock_schema_rejects_wrong_lease_type(self):
        self.lock["lease_seconds"] = "120"
        self.lock_path.write_bytes(_raw(self.lock))
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_NOT_HELD")
        self.assertFalse(result["runtime_lease_valid"])

    def test_read_failure_is_not_converted_to_valid_metadata(self):
        self.read_error = PermissionError("fixture lock read denied")
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_NOT_HELD")
        self.assertFalse(result["runtime_lease_valid"])
        self.assertIsNone(result["runtime_lock_hash"])

    def test_invalid_json_is_not_converted_to_valid_lock(self):
        self.lock_path.write_bytes(b'{"state": "HELD",')
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_LOCK_NOT_HELD")
        self.assertFalse(result["runtime_lease_valid"])

    def test_dead_process_remains_blocked_despite_held_unexpired_metadata(self):
        self.alive = False
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_PROCESS_NOT_ALIVE")
        self.assertFalse(result["runtime_pid_alive"])
        self.assertTrue(result["runtime_lease_valid"])

    def test_unavailable_process_probe_does_not_become_a_live_process(self):
        self.liveness_error = protocol.ProcessLivenessProbeError("fixture query unavailable")
        result = self._capture(now=STAMP)
        self._assert_blocked(result, "MANAGER_PROCESS_LIVENESS_PROBE_UNAVAILABLE")
        self.assertFalse(result["runtime_pid_alive"])

    def test_inspection_jobs_package_and_oauth_share_snapshot_guard_deadline(self):
        def delayed_io(read):
            self.clock_value = STAMP + timedelta(seconds=3)
            return read(self.lock_path)
        self.on_read = delayed_io
        # Due after the obsolete pre-read deadline, but within the true window.
        due = STAMP + timedelta(seconds=842)
        self.jobs = [{"job_id": "fixture-protected", "task_type": "OWNED_METRICS_CHECKPOINT",
                      "state": "PENDING", "available_at": _stamp(due)}]
        self.package = {"status": "NOT_DUE", "scheduled_for": _stamp(STAMP + timedelta(seconds=843))}
        result = self._capture()
        deadline = STAMP + timedelta(seconds=843)
        self.assertEqual([STAMP + timedelta(seconds=3)], self.inspection_times)
        self.assertEqual([deadline], self.oauth_deadlines)
        self.assertEqual(_stamp(deadline), result["guard_deadline"])
        self.assertEqual(["fixture-protected"], result["operational_due_job_ids"])
        for blocker in ("PROTECTED_JOB_DUE_DURING_MAINTENANCE",
                        "OPERATIONAL_JOB_DUE_DURING_MAINTENANCE",
                        "PACKAGE_EFFECT_MAY_BECOME_DUE_DURING_RECOVERY"):
            self._assert_blocked(result, blocker)

    def test_unverified_or_authorized_media_due_job_remains_a_blocker(self):
        due = STAMP + timedelta(seconds=1)
        queue = {"jobs": [{"job_id": "media", "task_type": "EXECUTE_PHASE6_VIDEO2_MEDIA",
                 "state": "PENDING", "available_at": _stamp(due), "attempt_count": 0,
                 "lease_owner": None, "lease_until": None, "last_error": None, "checkpoint": {},
                 "idempotency_key": "unexpected", "payload": {}}], "superseded_job_ids": []}
        due_ids = protocol._operational_due_jobs(queue, deadline=STAMP + timedelta(seconds=2))
        self.assertEqual(["media"], due_ids)
        # A contract reader failure must fail closed; no media job becomes inert
        # merely because its type looks familiar.
        with patch("hero_engine.phase6_current_production_inputs.current_production_input_contract",
                   side_effect=RuntimeError("unavailable")):
            self.assertEqual([], protocol._inert_current_media_due_jobs(self.root, queue, due_ids))

    def test_exact_no_authority_current_media_job_is_inert_only_with_bound_contract(self):
        receipt = "phase6-production-inputs-fixture"
        due = STAMP + timedelta(seconds=1)
        queue = {"jobs": [{"job_id": "media", "task_type": "EXECUTE_PHASE6_VIDEO2_MEDIA",
                 "state": "PENDING", "available_at": _stamp(due), "attempt_count": 0,
                 "lease_owner": None, "lease_until": None, "last_error": None, "checkpoint": {},
                 "idempotency_key": receipt + ":synthesize-render-standard-v2",
                 "payload": {"action": "SYNTHESIZE_AND_RENDER_VIDEO_2", "input_receipt_id": receipt}}],
                 "superseded_job_ids": []}
        contract = {"receipt_id": receipt, "authority": {"queue": False, "voice": False,
                    "render": False, "quality": False, "publication": False}}
        due_ids = protocol._operational_due_jobs(queue, deadline=STAMP + timedelta(seconds=2))
        with patch("hero_engine.phase6_current_production_inputs.current_production_input_contract",
                   return_value=contract):
            self.assertEqual(["media"], protocol._inert_current_media_due_jobs(self.root, queue, due_ids))
        queue["jobs"][0]["attempt_count"] = 1
        with patch("hero_engine.phase6_current_production_inputs.current_production_input_contract",
                   return_value=contract):
            self.assertEqual([], protocol._inert_current_media_due_jobs(self.root, queue, due_ids))

    def test_authenticated_reserve_hold_matches_exact_queue_row_and_keeps_other_due_jobs(self):
        receipt = "phase6-production-inputs-fixture"
        job = {"job_id": "held-media", "task_type": "EXECUTE_PHASE6_VIDEO2_MEDIA",
               "state": "RETRY_WAIT", "available_at": _stamp(STAMP), "attempt_count": 1,
               "payload": {"input_receipt_id": receipt}, "checkpoint": {}}
        other = {"job_id": "due-observer", "task_type": "GOAL_CHANNEL_CHECKPOINT",
                 "state": "PENDING", "available_at": _stamp(STAMP), "payload": {}}
        queue = {"jobs": [job, other], "superseded_job_ids": []}
        contract = {"receipt_id": receipt, "authority": {"queue": False, "voice": False,
                    "render": False, "quality": False, "publication": False}}
        path = self.root / protocol.MEDIA_EXECUTOR_STATUS_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        hold = {"status": "WAITING", "error": None,
                "next_action": "OWNER_PAUSE_RELEASE_REQUIRED: " + protocol._EXACT_MEDIA_RESERVE_WAIT_ERROR}
        path.write_bytes(_raw(hold))
        evidence = {"reason": "EXACT_RESOURCE_RESERVE_RESTART_HOLD",
                    "source_sha256": protocol.file_hash(path), "input_receipt_id": receipt,
                    "job_sha256": protocol.canonical_hash(job)}
        due = protocol._operational_due_jobs(queue, deadline=STAMP)
        with patch("hero_engine.phase6_current_production_inputs.current_production_input_contract", return_value=contract), \
             patch.object(protocol, "_resource_reserve_media_wait_candidate", return_value=(hold, evidence)):
            self.assertEqual(["held-media"], protocol._inert_current_media_due_jobs(self.root, queue, due))
            self.assertEqual(["due-observer"], protocol._protected_due_jobs(queue, deadline=STAMP))
            job["checkpoint"] = {"external": "changed"}
            self.assertEqual([], protocol._inert_current_media_due_jobs(self.root, queue, due))

    def test_reserve_hold_validation_error_or_changed_runtime_remains_due(self):
        receipt = "phase6-production-inputs-fixture"
        job = {"job_id": "held", "payload": {"input_receipt_id": receipt}, "attempt_count": 1}
        contract = {"receipt_id": receipt, "authority": {"queue": False, "voice": False,
                    "render": False, "quality": False, "publication": False}}
        path = self.root / protocol.MEDIA_EXECUTOR_STATUS_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        hold = {"status": "WAITING", "error": None,
                "next_action": "OWNER_PAUSE_RELEASE_REQUIRED: " + protocol._EXACT_MEDIA_RESERVE_WAIT_ERROR}
        path.write_bytes(_raw(hold))
        evidence = {"reason": "EXACT_RESOURCE_RESERVE_RESTART_HOLD", "input_receipt_id": receipt,
                    "job_sha256": protocol.canonical_hash(job), "source_sha256": protocol.file_hash(path)}
        def altered(*args, **kwargs):
            path.write_bytes(b"changed")
            return hold, evidence
        with patch("hero_engine.phase6_current_production_inputs.current_production_input_contract", return_value=contract):
            for effect in (PermissionError("tampered witness"), altered):
                with self.subTest(effect=effect), patch.object(protocol, "_resource_reserve_media_wait_candidate", side_effect=effect):
                    path.write_bytes(_raw(hold))
                    self.assertEqual([], protocol._inert_current_media_due_jobs(self.root, {"jobs": [job]}, ["held"]))


if __name__ == "__main__":
    unittest.main()
