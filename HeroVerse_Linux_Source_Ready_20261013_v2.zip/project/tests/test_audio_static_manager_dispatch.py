from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import sys
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from hero_engine import central_manager_phase5 as manager
from tests import test_audio_static_ready_chain as ready_fixture

ROOT = ready_fixture.ROOT


class AudioStaticInstalledRunnerTests(unittest.TestCase):
    def test_installed_runner_transports_explicit_selection_to_real_cli(self):
        """Execute the installed argv block, not the operational bootstrap.

        Power/task/token/process-start policy is outside this focused test.
        An owned child records real Windows argv; the real Python CLI consumes
        the result, with only the persistent manager loop replaced at boundary.
        """
        with tempfile.TemporaryDirectory(prefix='audio runner ',dir=ROOT/'output/runtime') as temporary:
            root=Path(temporary)
            package=Path('output/production/current audio')
            bindings=root/'current bindings.json';bindings.write_text('{}',encoding='utf-8')
            anchor='sha256:'+hashlib.sha256(bindings.read_bytes()).hexdigest()
            driver=root/'argv driver.py';driver.write_text('import json,sys\nprint(json.dumps(sys.argv[1:]))\n',encoding='utf-8')
            script=root/'selection.ps1'
            script.write_text(r'''
param([string]$Source,[string]$Python,[string]$Driver,[string]$PackageRelative,
      [string]$CurrentBindings,[string]$ExpectedBindingsHash,[string]$Out,[string]$Err)
$ErrorActionPreference='Stop'; $IntervalSeconds=60
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile($Source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'installed runner syntax invalid'}
$blocks=$ast.FindAll({param($node)
  ($node -is [System.Management.Automation.Language.AssignmentStatementAst] -and
    $node.Extent.Text -match '^\$(managerArguments|selection|selectedCount) =') -or
  ($node -is [System.Management.Automation.Language.IfStatementAst] -and
    $node.Extent.Text.StartsWith('if ($selectedCount -ne 0)'))
},$true)
if($blocks.Count -ne 4){throw 'installed selection block changed: review extraction'}
foreach($node in $blocks){. ([scriptblock]::Create($node.Extent.Text))}
if($managerArguments[2] -ne 'hero_engine.central_manager_phase5'){throw 'wrong entry'}
$arguments=@('-B',('"'+$Driver+'"')) + $managerArguments[6..($managerArguments.Count-1)]
$child=Start-Process -FilePath $Python -ArgumentList $arguments -WorkingDirectory (Split-Path $Driver) -WindowStyle Hidden -RedirectStandardOutput $Out -RedirectStandardError $Err -PassThru
if(-not $child.WaitForExit(30000)){$child.Kill();$child.WaitForExit();throw 'owned argv child timed out'}
$child.WaitForExit();exit $child.ExitCode
''',encoding='utf-8')
            shell=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
            out=root/'argv.stdout';err=root/'argv.stderr'
            arguments=[str(shell),'-NoProfile','-NonInteractive','-File',str(script),
                '-Source',str(ROOT/'scripts/start_phase5_manager.ps1'),'-Python',sys.executable,
                '-Driver',str(driver),'-PackageRelative',str(package),'-CurrentBindings',str(bindings.relative_to(root)),
                '-ExpectedBindingsHash',anchor,'-Out',str(out),'-Err',str(err)]
            result=subprocess.run(arguments,cwd=root,capture_output=True,timeout=45)
            self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))
            transported=json.loads(out.read_bytes())
            with patch.object(manager,'loop') as loop:
                manager.main(['--root',str(root),'--loop',*transported])
            loop.assert_called_once_with(root.resolve(),60,package_relative=package,current_bindings={})
            bindings.write_bytes(b'{"changed":true}')
            with patch.object(manager,'loop') as loop,self.assertRaises(PermissionError):
                manager.main(['--root',str(root),'--loop',*transported])
            loop.assert_not_called()


class AudioStaticManagerDispatchTests(unittest.TestCase):
    def setUp(self):
        self.owner = ready_fixture.AudioStaticReadyChainTests('test_native_complete_chain_reaches_ready_without_global_pack_promotion')
        self.owner.cycle_schema_fixture=self._testMethodName=='test_selected_real_loop_never_enters_legacy_phase6_lane'
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        self.root = self.owner.root
        for name in ('central_manager_runtime', 'central_manager_lock', 'phase6_executive_status', 'phase6_acceptance_report', 'phase6_control_cycle_receipt',
                     'narrative_script','take_plan','voice_render_manifest','format_pack','creative_direction_decision','render_manifest','creative_quality_gate_report'):
            shutil.copy2(ROOT / f'schemas/{name}.schema.json', self.root / 'schemas')
        self.selection = {'package_relative': self.owner.relative, 'current_bindings': self.owner.bindings}

    def cinema_barriers(self):
        # These are NOT the functions under test. They are forbidden legacy
        # lanes; any accidental fallback must fail rather than silently PASS.
        return (
            patch.object(manager, 'materialize_autonomous_quality', side_effect=AssertionError('cinema QA dispatched')),
            patch.object(manager, 'build_phase5_integrity', side_effect=AssertionError('legacy fingerprint rewritten')),
        )

    def test_native_blocked_audio_does_not_fall_back_to_cinema(self):
        first, second = self.cinema_barriers()
        with first, second, patch.object(manager, '_build_live_service') as service:
            result = manager.run_cycle(self.root, **self.selection)
        self.assertEqual(result['release_decision'], 'BLOCKED')
        self.assertEqual(result['blockers'], ['FORMAT_CAPABILITY'])
        service.assert_not_called()
        self.assertFalse((self.root / manager.V3 / 'release_gate.json').exists())
        self.assertFalse((self.root / manager.RUNTIME / 'fingerprint.json').exists())

    def test_native_ready_publication_and_repeat_use_exact_current_receipt(self):
        self.owner.canary()
        provider = Mock()
        provider.channels.return_value.list.return_value.execute.return_value = {'items': [{'id': manager._read(
            self.root / 'output/integrations/youtube/heroverse/connection-receipt.json')['observed_channel']['channel_id']}]}
        provider.videos.return_value.insert.return_value.next_chunk.return_value = (None, {'id': 'audio-current-video'})
        provider.captions.return_value.insert.return_value.execute.return_value = {'id': 'audio-current-captions'}
        channel = manager._read(self.root / 'output/integrations/youtube/heroverse/connection-receipt.json')['observed_channel']['channel_id']
        provider.videos.return_value.list.return_value.execute.side_effect = [
            {'items': [{'id': 'audio-current-video', 'snippet': {'channelId': channel},
                        'status': {'privacyStatus': visibility, 'uploadStatus': 'processed'}}]}
            for visibility in ('private', 'public')]
        first, second = self.cinema_barriers()
        with first, second, patch.dict(os.environ, {'HERO_YT_TOKEN_PATH': 'synthetic-secret-frontier'}), \
                patch.object(manager, '_build_live_service', return_value=(provider, Mock(return_value=object()))) as service:
            result = manager.run_cycle(self.root, **self.selection)
            self.assertEqual(result['publication_status'], 'COMPLETE_PUBLIC')
            release_bytes = (self.owner.package / 'release_gate.json').read_bytes()
            provider.reset_mock(); service.reset_mock()
            again = manager.run_cycle(self.root, **self.selection)
            self.assertEqual(again['publication_status'], 'COMPLETE_PUBLIC')
            self.assertEqual((self.owner.package / 'release_gate.json').read_bytes(), release_bytes)
            self.assertEqual(provider.mock_calls, [])
            service.assert_not_called()

    def test_public_cli_selects_audio_and_rejects_changed_bindings(self):
        path = self.root / 'current-bindings.json'
        path.write_text(json.dumps(self.owner.bindings), encoding='utf-8')
        anchor = 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()
        args = ['--root', str(self.root), '--package-relative', str(self.owner.relative),
                '--current-bindings', str(path), '--expected-bindings-hash', anchor]
        with patch('sys.stdout', new_callable=io.StringIO) as console:
            manager.main(args)
            self.assertEqual(json.loads(console.getvalue())['blockers'], ['FORMAT_CAPABILITY'])
        path.write_text('{}', encoding='utf-8')
        with patch.object(manager, 'run_cycle') as cycle, self.assertRaisesRegex(PermissionError, 'external anchor'):
            manager.main(args)
        cycle.assert_not_called()

    def test_selected_real_loop_never_enters_legacy_phase6_lane(self):
        class FinishedFixtureLoop(Exception):
            pass
        with patch('hero_engine.maintenance_protocol.publish_capability'), \
             patch('hero_engine.maintenance_protocol.refresh_capability_token_binding'), \
             patch('hero_engine.maintenance_protocol.maintenance_barrier', return_value=False), \
             patch.object(manager, '_start_review_console'), \
             patch.object(manager, '_start_oauth_reconsent_watcher', return_value=None), \
             patch.object(manager, 'ensure_oauth_session_health'), \
             patch.object(manager, 'run_phase6_treatment_executor') as cinema, \
             patch('hero_engine.phase6_media.run_phase6_media_executor') as media, \
             patch('hero_engine.phase6_publication.run_phase6_publication_controller') as publication, \
             patch.object(manager.time, 'sleep', side_effect=FinishedFixtureLoop), \
             self.assertRaises(FinishedFixtureLoop):
            manager.loop(self.root, 60, **self.selection)
        cinema.assert_not_called(); media.assert_not_called(); publication.assert_not_called()
        status = manager._read(self.root / manager.RUNTIME / 'status.json')
        self.assertEqual(status['blockers'], ['FORMAT_CAPABILITY'])
        executive = manager._read(self.owner.package/'intelligence/executive-status.json')
        self.assertEqual(executive['schema_version'],'2.0.0')
        self.assertEqual(executive['current_delivery']['package_relative'],self.owner.relative.as_posix())
        self.assertEqual(executive['attention_items'],['FORMAT_CAPABILITY'])
        self.assertFalse((self.root/'output/operations/phase6/executive-status.json').exists())
        self.assertFalse((self.root / manager.RUNTIME / 'manager.pid').exists())
        self.assertEqual(manager._read(self.root / manager.RUNTIME / 'manager-lock.json')['state'], 'RELEASED')


class AudioStaticManagerEntryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='audio-manager-entry-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def test_pause_contains_selected_cycle_before_any_current_gate(self):
        pause = self.root / manager.RUNTIME / 'PAUSE'
        pause.parent.mkdir(parents=True); pause.write_bytes(b'fixture owner pause')
        with patch.object(manager, '_run_audio_static_cycle') as current:
            result = manager.run_cycle(self.root, package_relative=Path('output/production/current'), current_bindings={})
        self.assertEqual(result['cycle_status'], 'PAUSED'); current.assert_not_called()
        self.assertEqual(pause.read_bytes(), b'fixture owner pause')

    def test_partial_selection_is_not_legacy_fallback(self):
        with self.assertRaisesRegex(PermissionError, 'authenticated current bindings'):
            manager.run_cycle(self.root, package_relative=Path('output/production/current'))
        with self.assertRaisesRegex(PermissionError, 'explicit audio package'):
            manager.run_cycle(self.root, current_bindings={})
        with self.assertRaisesRegex(PermissionError, 'explicit package'):
            manager.main(['--root', str(self.root), '--expected-bindings-hash', 'sha256:' + '0' * 64])

    def test_root_escape_rejected_before_gate(self):
        with patch.object(manager, 'build_release_gate') as gate, self.assertRaisesRegex(PermissionError, 'confined'):
            manager.run_cycle(self.root, package_relative=Path('../outside'), current_bindings={})
        gate.assert_not_called()

    def test_module_population_excludes_reused_fixture_cases(self):
        def identifiers(suite):
            for item in suite:
                if isinstance(item, unittest.TestSuite):
                    yield from identifiers(item)
                else:
                    yield item.id()
        # Standard discovery inspects imported TestCase objects too. Reuse the
        # module, not an exposed class, so it cannot redispatch old fixtures.
        cases = list(identifiers(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])))
        self.assertEqual(len(cases), 9)
        self.assertEqual(len(set(cases)), 9)
        self.assertTrue(all(case.startswith(__name__ + '.') for case in cases), cases)
