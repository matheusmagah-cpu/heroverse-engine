"""Legacy A10 asset-use compatibility in A12, with no new media.

Caption/amendment readers, asset-use join, schemas, consumers and final byte
rechecks are real. The operational source-use proof is an externally pinned
fixture, not a fresh source evaluation or audiovisual approval.
The body-case source trio is absent: A12 must retain the original 25-use join.
"""
import copy
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_asset_use_binding as joiner
from hero_engine import phase6_av_static_asset_uses_v2 as uses
from hero_engine import phase6_av_static_sources as sources
from hero_engine import phase6_av_render_recipe as recipe
from hero_engine import phase6_av_two_column_adapter as columns
from hero_engine import phase6_av_admission as admission
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]
A9 = "output/operations/phase6/av-admission/timelines/phase6-av-timeline-08c58eb7551e72f958fa3f09.json"
A9_SHA = "5105f3a4c09cc632667088b7a8d50cdd49d46006b33af2f98c21fb843f37f6c0"
USES_BASE = "output/operations/phase6/av-admission/static-asset-uses-v2/"
USE_BINDING = {"path": USES_BASE + "input.json", "sha256": "sha256:65be03122e4ad1c17e74e7bff99324f0177e0a541735ecbdc85a9883fd828376"}
INSPECTION_SHA = "14641e1282f3e0fa2b6540ac04abbac6e01629d476c9dffc1101af2165a5330e"
RECEIPT_SHA = "9e14abf9d38b3e8c01b621f4fad9f4c9e11c7ddd6df9dd239e4fa0d658842243"
OLD_SCHEMA = "output/qa/phase6/diagnostics/two-column-compact-v1/before-literal-uses-a10-integration/phase6_av_timeline.schema.json"
PINS = {
    "hero_engine/phase6_av_timeline.py": "a113489a43a26d50f266808fb3bb06d6fa1de6092364c7d7aaedbbcb8bc5f5dd",
    "hero_engine/phase6_av_asset_use_binding.py": "f3cd3a30fb8a2d6ad26647d5c6143bd3ac93a7cdb433b44d02a5cc6278ad6cf6",
    "hero_engine/phase6_av_static_asset_uses_v2.py": "2c2b74a57f42f6e2fe58bf43152ed7f4be623ab257c2594ffed6791991353703",
    "hero_engine/phase6_av_render_recipe.py": "919eff35e1cf9df6d91d756aaf4aa9271158c520cf9e1b0aa3b9812423b6d3c7",
    "hero_engine/phase6_av_two_column_adapter.py": "4f14f103c023e2e4d94dd7f18bc260225d3d9a43bfb88969ab95746f4a01c3a6",
    "hero_engine/phase6_av_admission.py": "615f897ebf8143fc252a9bdd4aa78904fe9cf92d6e315dbe13d747bce08027ce",
    "schemas/phase6_av_timeline.schema.json": "3095b5f5b0daa68341ed565c6457d3eb96fb1cb356459ae3af1ebfaec624decb",
    "schemas/phase6_av_render_recipe.schema.json": "f8cd8fb4f0c6f8edbeef7f5d19cda22a483f635c4702e6163ea881e37b203614",
    OLD_SCHEMA: "e19823afeca8fd345f5669957082ea661fe8e88f742d5ed20e55baf11942a1be",
}


class AssetUseA10IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = {**PINS, Path(__file__).relative_to(ROOT).as_posix(): sources._sha(Path(__file__).read_bytes())}
        cls.assert_sources_unchanged()
        reader = Reader(ROOT)
        cls.old = sources._json(reader.read(A9, "sha256:" + A9_SHA))
        cls.source_proof = sources._json(reader.read(USES_BASE + "inspection.json", "sha256:" + INSPECTION_SHA))
        receipt = sources._json(reader.read(USES_BASE + "receipt.json", "sha256:" + RECEIPT_SHA))
        if receipt["inspection_binding"] != {"path": USES_BASE + "inspection.json", "sha256": INSPECTION_SHA}:
            raise AssertionError("independent source-use fixture binding differs")
        cls.arguments = copy.deepcopy(cls.old["inputs"])
        cls.data = {key: reader.load(bound) for key, bound in cls.arguments["source_bindings"].items() if key in av.CORE}
        cls.baseline = cls.build_fixture(cls.arguments)
        cls.bound_arguments = copy.deepcopy(cls.arguments)
        cls.bound_arguments["source_bindings"]["literal_asset_uses"] = copy.deepcopy(USE_BINDING)
        cls.current = cls.build_fixture(cls.bound_arguments)
        cls.schema = sources._json((ROOT / av.SCHEMA).read_bytes())

    @classmethod
    def assert_sources_unchanged(cls):
        for name, digest in cls.snapshot.items():
            if sources._sha((ROOT / name).read_bytes()) != digest:
                raise AssertionError("frozen integration source changed: " + name)

    @classmethod
    def tearDownClass(cls):
        cls.assert_sources_unchanged()

    @classmethod
    def build_fixture(cls, arguments, *, source_proof=None):
        # No import/export of another TestCase; only the two upstream seams.
        supplied = copy.deepcopy(cls.source_proof if source_proof is None else source_proof)
        with mock.patch.object(av, "_sources", return_value=copy.deepcopy(cls.data)), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(cls.old["units"]), copy.deepcopy(cls.old["narration_fragment_map"]))), \
             mock.patch.object(uses, "inspect_static_asset_uses", return_value=supplied), \
             mock.patch.object(av, "inspect_pcm", side_effect=AssertionError("no PCM inspection")), \
             mock.patch.object(sources, "_png", side_effect=AssertionError("no PNG decode")), \
             mock.patch("PIL.Image.open", side_effect=AssertionError("no image decoding")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no process")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("no network")):
            return av.build(ROOT, **copy.deepcopy(arguments))

    def test_metadata_addition_preserves_clock_blockers_union_and_never_creates_spans(self):
        before, after = self.baseline, self.current
        self.assertEqual((after["schema_version"], after["timeline_version"]), ("1.11.0", "phase6-av-timeline-v12"))
        self.assertIsNone(after["body_case_amendment_evidence"])
        self.assertFalse({"body_case_amendment", "body_case_evidence", "body_case_staging"} & set(after["inputs"]["source_bindings"]))
        for key in ("clock", "duration", "units", "narration_fragment_map", "pause_measurements", "caption_cues",
                    "render_spans", "visual_events", "static_source_evidence", "blockers", "status", "authority",
                    "temporal_evidence_assessment", "caption_intent_evidence", "untimed_visual_intent_evidence", "visual_amendment_evidence"):
            self.assertEqual(after[key], before[key], key)
        # CORE-only fixture deliberately has no optional timed static source.
        self.assertEqual(after["static_source_evidence"], [])
        self.assertEqual([after[key] for key in ("render_spans", "visual_events", "caption_cues")], [[], [], []])
        self.assertEqual(len(after["temporal_evidence_assessment"]["declared_target_unit_ids"]), 26)
        self.assertTrue(after["temporal_evidence_assessment"]["scope_complete"])
        self.assertFalse(after["temporal_evidence_assessment"]["all_required_evidence_live"])
        self.assertIn("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING", after["blockers"])
        self.assertEqual(after["status"], "BLOCKED_INCOMPLETE")
        self.assertIsNone(after["derived_take_plan"])
        expected_silence = copy.deepcopy(before["permitted_silence_spans"])
        for item in expected_silence:
            if item["reason"] in ("LOCKED_HOOK_PAD", "MECHANICAL_GRID_PAD"):
                self.assertEqual(item["evidence_ref"], av.canonical_sha(before["inputs"]))
                item["evidence_ref"] = av.canonical_sha(after["inputs"])
        self.assertEqual(after["permitted_silence_spans"], expected_silence)

    def test_real_join_hashes_twenty_five_seventy_five_and_forty_current_dependencies(self):
        evidence = self.current["literal_asset_use_evidence"]
        self.assertIsNone(self.baseline["literal_asset_use_evidence"])
        self.assertEqual(evidence["adapter_version"], joiner.VERSION)
        self.assertEqual(evidence["source_binding"], USE_BINDING)
        self.assertEqual(evidence["inspection_sha256"], av.canonical_sha(self.source_proof))
        self.assertEqual(evidence["use_rows_sha256"], av.canonical_sha(self.source_proof["uses"]))
        self.assertEqual(evidence["effective_rows_sha256"], self.current["visual_amendment_evidence"]["effective_rows_sha256"])
        self.assertEqual((evidence["source_count"], evidence["use_count"], evidence["unique_png_content_count"], evidence["lineage_count"]), (23, 25, 22, 3))
        self.assertEqual(evidence["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(evidence["remaining_unbound_visual_state_ids"]), 75)
        self.assertTrue(all(value is False for value in evidence["authority"].values()))
        self.assertFalse(evidence["source_ready"])
        self.assertFalse(evidence["global_schedule_created"])
        dependencies = self.current["implementation_dependencies"]
        self.assertEqual(len(dependencies), 40)
        self.assertEqual(len({row["path"] for row in dependencies}), 40)
        for name in (joiner.PATH, "hero_engine/phase6_av_static_asset_uses_v2.py", uses.SCHEMA):
            self.assertIn({"path": name, "sha256": av.bytes_sha((ROOT / name).read_bytes())}, dependencies)
        self.assertIn(USE_BINDING["path"], {row["path"] for row in self.current["source_file_bindings"]})

    def test_missing_required_amendment_or_malformed_pin_rejects_before_core_reads(self):
        for mutation in ("amendment", "caption", "base", "raw_pin", "extra", "path"):
            bindings = copy.deepcopy(self.bound_arguments["source_bindings"])
            if mutation == "amendment": bindings.pop("visual_amendment")
            elif mutation == "caption": bindings.pop("caption_intent")
            elif mutation == "base": bindings.pop("untimed_visual_intent")
            elif mutation == "raw_pin": bindings["literal_asset_uses"]["sha256"] = USE_BINDING["sha256"][7:]
            elif mutation == "extra": bindings["literal_asset_uses"]["approved"] = True
            else: bindings["literal_asset_uses"]["path"] = "../input.json"
            reader = mock.Mock()
            reader.load.side_effect = AssertionError("CORE must not be read")
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                av._sources(reader, bindings)
            reader.load.assert_not_called()

    def test_wrong_copy_hold_entry_or_amendment_fixture_is_rejected_by_actual_a_join(self):
        for mutation in ("copy", "hold", "amendment"):
            proof = copy.deepcopy(self.source_proof)
            if mutation == "copy": proof["uses"][0]["literal_copy"] = ["Unrelated interpretation"]
            elif mutation == "hold":
                row = next(row for row in proof["uses"] if row["visual_state_id"] == "visual-u016-s01")
                row["entry"]["kind"] = "UNIT_ENTRY"
            else: proof["visual_amendment_evidence"]["effective_rows_sha256"] = "sha256:" + "0" * 64
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, "literal use"):
                self.build_fixture(self.bound_arguments, source_proof=proof)

    def test_old_frozen_schema_accepts_real_a9_but_cannot_gain_new_metadata(self):
        old_validator = Draft202012Validator(sources._json((ROOT / OLD_SCHEMA).read_bytes()))
        old_validator.validate(self.old)
        current_validator = Draft202012Validator(self.schema)
        current_validator.validate(self.old)
        current_validator.validate(self.current)
        old_with_evidence = copy.deepcopy(self.old)
        old_with_evidence["literal_asset_use_evidence"] = copy.deepcopy(self.current["literal_asset_use_evidence"])
        with self.assertRaises(ValidationError): old_validator.validate(old_with_evidence)
        with self.assertRaises(ValidationError): old_validator.validate(self.current)
        for mutation in ("schema_version", "authority", "count", "missing_binding"):
            candidate = copy.deepcopy(self.current)
            if mutation == "schema_version": candidate.update(schema_version="1.8.0", timeline_version="phase6-av-timeline-v9")
            elif mutation == "authority": candidate["literal_asset_use_evidence"]["source_ready"] = True
            elif mutation == "count": candidate["literal_asset_use_evidence"]["use_count"] = 100
            else: candidate["inputs"]["source_bindings"].pop("literal_asset_uses")
            with self.subTest(mutation=mutation), self.assertRaises(ValidationError):
                current_validator.validate(candidate)

    def test_consumers_remain_blocked_and_do_not_treat_metadata_as_render_assets(self):
        compiled = recipe.compile_phase6_av_render_recipe(ROOT, self.current, master_receipt_binding=None, render_blueprint_binding=None)
        self.assertEqual((compiled["schema_version"], compiled["recipe_version"]), ("1.14.0", "phase6-av-render-recipe-v15"))
        self.assertIn("AMENDED_VISUAL_COMPOSITOR_NOT_IMPLEMENTED", compiled["blockers"])
        self.assertIsNone(compiled["command_graph"])
        self.assertTrue(all(flag is False for flag in compiled["authority"].values()))
        with self.assertRaisesRegex(admission.AdmissionError, "timeline has no visual assets"):
            admission._span_assets(self.current)
        with mock.patch.object(columns, "_load_sources", side_effect=AssertionError("cannot load obsolete compositor")), \
             self.assertRaisesRegex(columns.AVTwoColumnAdapterError, "cannot use the historical"):
            columns.compile_two_column_av_spec(ROOT, timeline=self.current, bindings={})
        fixture = {"schema_version": "1.9.0", "render_spans": [{"span_id": "FIXTURE-one-image",
            "asset_binding": {"path": "fixture.png", "sha256": "sha256:" + "0" * 64}, "media_kind": "STATIC_IMAGE",
            "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
            "static_source": {"template_id": "fear-examples-v1", "state_id": "door-0",
                "receipt_binding": {"path": "fixture.json", "sha256": "sha256:" + "1" * 64}}}],
            "static_source_evidence": [{"span_id": "FIXTURE-one-image", "inspection_id": "fixture-only", "inspection_sha256": "sha256:" + "2" * 64}]}
        inventory = admission._span_assets(fixture)
        self.assertEqual(inventory[0]["media_kind"], "STATIC_IMAGE")
        self.assertNotIn("production_eligible", inventory[0])

    def test_late_dependency_change_after_join_blocks_a_return(self):
        original_read, original_captions = Reader.read, av._captions
        late = {"value": False}
        def captions(*args, **kwargs):
            result = original_captions(*args, **kwargs)
            late["value"] = True
            return result
        def drift(reader, path, expected=None, **kwargs):
            if late["value"] and path == USE_BINDING["path"]:
                raise ValueError("FIXTURE post-join input drift; source bytes unchanged")
            return original_read(reader, path, expected, **kwargs)
        with mock.patch.object(av, "_captions", side_effect=captions), mock.patch.object(Reader, "read", drift), \
             self.assertRaisesRegex(ValueError, "post-join input drift"):
            self.build_fixture(self.bound_arguments)


if __name__ == "__main__":
    unittest.main()
