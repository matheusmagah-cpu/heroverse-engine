"""Stage A→C integration uses the real verifier; all synthetic media is FIXTURE."""
from __future__ import annotations

import copy
import unittest

from hero_engine.phase6_av_render_recipe import (
    ARGUMENTS_PARENT, AVRenderRecipeError, FALSE_AUTHORITY,
    compile_phase6_av_render_recipe, verify_phase6_av_render_recipe,
)
from tests.test_phase6_av_render_recipe import (
    bind, identify, raw_json, write_json,
)
from tests import test_phase6_av_render_recipe as recipe_fixtures


class ArgumentsIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Reuse the existing 51-unit fixture, without rerunning its test suite.
        cls.harness = recipe_fixtures.Phase6AVRenderRecipeTests
        cls.harness.setUpClass()
        cls.root = cls.harness.root
        cls.timeline = cls.harness.timeline
        cls.arguments = cls.harness.arguments

    @classmethod
    def tearDownClass(cls):
        cls.harness.tearDownClass()

    def test_module_exports_only_its_own_test_case(self):
        # Importing the reusable TestCase itself makes unittest discover its
        # seven tests a second time under a different module identity.
        cases = {name for name, value in globals().items()
                 if isinstance(value, type) and issubclass(value, unittest.TestCase)}
        self.assertEqual({"ArgumentsIntegrationTests"}, cases)

    def argument_document(self, *, mode="FIXTURE", arguments=None, protocol_id=None):
        value = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_RAW_ARGUMENTS",
            "evidence_mode": mode, "channel_id": self.timeline["channel_id"],
            "video_id": self.timeline["video_id"],
            "protocol_id": protocol_id or self.timeline["protocol_id"],
            "arguments": copy.deepcopy(self.arguments if arguments is None else arguments),
            "authority": copy.deepcopy(FALSE_AUTHORITY), "technical_cost_brl": 0,
        }
        identify(value, "arguments_id", "phase6-av-arguments-")
        pin = write_json(self.root, f"{ARGUMENTS_PARENT}/{value['arguments_id']}.json", value)
        return value, pin

    def compile(self, pin, timeline=None):
        return compile_phase6_av_render_recipe(
            self.root, self.timeline if timeline is None else timeline,
            master_receipt_binding=self.harness.master_binding,
            render_blueprint_binding=self.harness.blueprint_binding,
            timeline_arguments_binding=pin)

    def test_independent_arguments_recompose_real_stage_a_but_fixture_has_no_authority(self):
        document, pin = self.argument_document()
        result = self.compile(pin)
        proof = result["timeline"]["independent_arguments"]
        self.assertEqual("RECOMPOSED_COMPLETE_NOT_ADMITTED", proof["status"])
        self.assertEqual(document["arguments_id"], proof["arguments_id"])
        self.assertEqual(pin, proof["binding"])
        self.assertEqual("SOURCE_RECOMPOSITION_FROM_PINNED_ARGUMENTS", result["timeline"]["verification_scope"])
        self.assertNotIn("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED", result["blockers"])
        self.assertIn("FIXTURE_ARGUMENTS_NOT_PRODUCTION_EVIDENCE", result["blockers"])
        self.assertEqual("COMPILED_FIXTURE_NOT_EXECUTABLE", result["status"])
        self.assertFalse(any(result["authority"].values()))
        replay = verify_phase6_av_render_recipe(
            self.root, result, self.timeline,
            master_receipt_binding=self.harness.master_binding,
            render_blueprint_binding=self.harness.blueprint_binding,
            timeline_arguments_binding=pin)
        self.assertEqual(result, replay)

    def test_reidentified_candidate_cannot_replace_original_arguments(self):
        _, pin = self.argument_document()
        forged = copy.deepcopy(self.timeline)
        forged["inputs"]["pause_decisions"][0]["target_low_energy_samples"] += 2400
        identify(forged, "timeline_id", "phase6-av-timeline-")
        with self.assertRaisesRegex(AVRenderRecipeError, "independent recomposition failed"):
            self.compile(pin, forged)
        changed_args = copy.deepcopy(self.arguments)
        changed_args["pause_decisions"][0]["target_low_energy_samples"] += 2400
        _, other_pin = self.argument_document(arguments=changed_args)
        with self.assertRaisesRegex(AVRenderRecipeError, "independent recomposition failed"):
            self.compile(other_pin)

    def test_argument_binding_path_identity_protocol_and_bytes_are_checked(self):
        document, pin = self.argument_document()
        misplaced = write_json(self.root, "misplaced-arguments.json", document)
        with self.assertRaisesRegex(AVRenderRecipeError, "immutable path"):
            self.compile(misplaced)
        _, wrong_protocol = self.argument_document(protocol_id="another-experiment")
        with self.assertRaisesRegex(AVRenderRecipeError, "protocol_id"):
            self.compile(wrong_protocol)
        path = self.root / pin["path"]
        original = path.read_bytes()
        try:
            path.write_bytes(original + b" ")
            with self.assertRaisesRegex(AVRenderRecipeError, "bytes differ"):
                self.compile(pin)
            changed = copy.deepcopy(document)
            changed["arguments_id"] = "phase6-av-arguments-" + "0" * 24
            path.write_bytes(raw_json(changed))
            with self.assertRaisesRegex(AVRenderRecipeError, "identity"):
                self.compile(bind(self.root, path))
        finally:
            path.write_bytes(original)

    def test_wrapper_mode_cannot_grant_render_or_publication(self):
        _, pin = self.argument_document(mode="LIVE")
        result = self.compile(pin)
        self.assertEqual("RECOMPOSED_COMPLETE_NOT_ADMITTED", result["timeline"]["independent_arguments"]["status"])
        # This fixture uses whole-unit cues, not calibrated word timestamps.
        # Recomposition is not provenance/admission; a wrapper's mode grants
        # no authority and cannot promote the fixture command graph.
        self.assertIn("FIXTURE_BLUEPRINT_NOT_PRODUCTION_EVIDENCE", result["blockers"])
        self.assertFalse(any(result["authority"].values()))
        self.assertFalse(result["publication_authorized"])


if __name__ == "__main__":
    unittest.main()
