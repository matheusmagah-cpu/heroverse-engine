"""Real harmless-process containment; real immutable cache replay, no inference."""
import ctypes
from pathlib import Path
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

from hero_engine import audio_perception_supervisor as supervisor

ROOT = Path(__file__).resolve().parent.parent
REAL_RECEIPT = ROOT / "output/qa/phase6/diagnostics/audio-perception-v1/master-receipt.json"
REAL_SHA = "ca77105222422f51de76b01c7e41a91399f76fd104555cc6f6b51263707011d2"
SOURCE_SHA = "8e8909fef9835f92aee8521db9c7e0153216fa5a48a0bd0f2177444fdeac49b6"


class AudioPerceptionSupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="heroverse-audio-supervisor-")
        self.addCleanup(self.temporary.cleanup)
        self.folder = Path(self.temporary.name)

    def run_child(self, script, **options):
        return supervisor.run_bounded([sys.executable, "-I", "-S", "-c", script],
                                      cwd=self.folder, logs=self.folder / "process", **options)

    def test_real_child_success_and_log_integrity(self):
        result = self.run_child("print('harmless child')", timeout_seconds=5)
        self.assertEqual(result["status"], "SUCCEEDED")
        self.assertEqual(result["remaining_processes_verified"], 0)
        self.assertTrue(result["assigned_before_resume"])
        self.assertTrue(result["kill_on_close"])
        self.assertGreater(result["peak_job_commit_bytes"], 0)
        # A configured Python launcher may itself spawn the real interpreter.
        self.assertGreaterEqual(result["process_count_observed"], 1)
        self.assertEqual((self.folder / "process/stdout.log").read_bytes().strip(), b"harmless child")
        self.assertFalse(result["audio_approved"])
        self.assertFalse(result["release_authority"])
        for entry in result["logs"]:
            self.assertEqual(supervisor._adapter().sha(Path(entry["path"]).read_bytes()), entry["sha256"])

    def test_real_child_failure_is_explicit(self):
        result = self.run_child("import sys; print('intentional failure', file=sys.stderr); sys.exit(23)", timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertEqual(result["exit_code"], 23)
        self.assertEqual(result["remaining_processes_verified"], 0)

    def test_real_native_tree_timeout_and_grandchild_dead(self):
        script = ("import subprocess,sys,time; "
                  "p=subprocess.Popen([sys.executable,'-I','-S','-c','import time; time.sleep(30)']); "
                  "print(p.pid, flush=True); time.sleep(30)")
        result = self.run_child(script, timeout_seconds=1)
        self.assertEqual(result["status"], "TIMED_OUT")
        self.assertGreaterEqual(result["process_count_observed"], 2)
        self.assertEqual(result["remaining_processes_verified"], 0)
        self.assertLess(result["duration_seconds"], 6)
        grandchild = int((self.folder / "process/stdout.log").read_text().strip())
        # Read-only process query; never os.kill(pid, 0) on Windows.
        k = supervisor._kernel()
        k.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        k.OpenProcess.restype = ctypes.c_void_p
        handle = k.OpenProcess(0x1000, False, grandchild)
        if handle:
            code = ctypes.c_uint32()
            try:
                self.assertTrue(k.GetExitCodeProcess(handle, ctypes.byref(code)))
                self.assertNotEqual(code.value, 259)
            finally:
                self.assertTrue(k.CloseHandle(handle))
        else:
            self.assertEqual(ctypes.get_last_error(), 87)  # PID no longer exists.

    def test_real_committed_memory_ceiling_prevents_large_allocation(self):
        script = ("import sys\ntry:\n x=bytearray(256*1024*1024)\n"
                  "except MemoryError:\n print('MEMORY_LIMIT_OBSERVED', flush=True); sys.exit(24)\n"
                  "sys.exit(0)\n")
        result = self.run_child(script, timeout_seconds=5, memory_bytes=64 * 1024 ** 2)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertEqual(result["exit_code"], 24)
        self.assertIn(b"MEMORY_LIMIT_OBSERVED", (self.folder / "process/stdout.log").read_bytes())
        self.assertLessEqual(result["peak_job_commit_bytes"], 64 * 1024 ** 2)

    def test_real_log_overflow_terminates_child(self):
        result = self.run_child("import sys,time; print('x'*65536,flush=True); time.sleep(30)",
                                timeout_seconds=5, max_log_bytes=1024)
        self.assertEqual(result["status"], "OUTPUT_LIMIT_EXCEEDED")
        self.assertEqual(result["remaining_processes_verified"], 0)

    def test_real_worker_containment_guard_accepts_exact_ceiling(self):
        script = (f"import sys; sys.path.insert(0,{str(ROOT)!r}); "
                  "from hero_engine.audio_perception_supervisor import _require_worker_containment; "
                  "_require_worker_containment(2*1024**3); print('CONTAINMENT_VERIFIED')")
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "SUCCEEDED")
        self.assertIn(b"CONTAINMENT_VERIFIED", (self.folder / "process/stdout.log").read_bytes())

    def test_real_worker_containment_guard_rejects_wrong_ceiling(self):
        script = (f"import sys; sys.path.insert(0,{str(ROOT)!r}); "
                  "from hero_engine.audio_perception_supervisor import _require_worker_containment; "
                  "_require_worker_containment(1024**3)")
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertIn(b"ceiling differs", (self.folder / "process/stderr.log").read_bytes())

    def test_real_venv_nested_job_uses_explicit_supervisor_membership_and_limits(self):
        script = (f"import sys; sys.path.insert(0,{str(ROOT)!r}); "
                  "import ctypes,json; "
                  "from hero_engine.audio_perception_supervisor import _kernel,_ExtendedLimits,_require_worker_containment; "
                  "k=_kernel(); x=_ExtendedLimits(); "
                  "assert k.QueryInformationJobObject(None,9,ctypes.byref(x),ctypes.sizeof(x),None); "
                  "print(json.dumps({'implicit_flags':x.BasicLimitInformation.LimitFlags,"
                  "'explicit':_require_worker_containment(2*1024**3)}))")
        result = supervisor.run_bounded(
            [str(ROOT / ".venv/Scripts/python.exe"), "-I", "-S", "-c", script],
            cwd=self.folder, logs=self.folder / "process", timeout_seconds=5,
        )
        self.assertEqual(result["status"], "SUCCEEDED")
        evidence = json.loads((self.folder / "process/stdout.log").read_bytes())
        self.assertEqual(evidence["implicit_flags"], 0x3000)  # Installed launcher, not our guard target.
        self.assertEqual(evidence["explicit"]["flags"], 0x2300)
        self.assertTrue(evidence["explicit"]["membership_verified"])
        self.assertEqual(evidence["explicit"]["job_name"], result["containment_job_name"])
        self.assertEqual(evidence["explicit"]["job_memory_limit_bytes"], 2 * 1024 ** 3)
        self.assertEqual(evidence["explicit"]["process_memory_limit_bytes"], 2 * 1024 ** 3)
        self.assertEqual(result["remaining_processes_verified"], 0)
        # No worker/owner query handle keeps this job alive after completion.
        k = supervisor._kernel()
        handle = k.OpenJobObjectW(0x0004, False, result["containment_job_name"])
        if handle:
            k.CloseHandle(handle)
            self.fail("completed job remains open")
        self.assertEqual(ctypes.get_last_error(), 2)

    def test_missing_job_identity_cannot_use_implicit_launcher_job(self):
        script = (f"import sys,os; sys.path.insert(0,{str(ROOT)!r}); "
                  "from hero_engine.audio_perception_supervisor import _require_worker_containment,CONTAINMENT_JOB_ENV; "
                  "os.environ.pop(CONTAINMENT_JOB_ENV,None); _require_worker_containment(2*1024**3)")
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertIn(b"explicit supervisor Job Object identity", (self.folder / "process/stderr.log").read_bytes())

    def test_foreign_named_job_cannot_fake_membership(self):
        script = (
            f"import sys; sys.path.insert(0,{str(ROOT)!r})\n"
            "import os,uuid,ctypes\n"
            "from hero_engine.audio_perception_supervisor import _kernel,_ExtendedLimits,_require_worker_containment,CONTAINMENT_JOB_ENV,CONTAINMENT_JOB_PREFIX\n"
            "k=_kernel(); name=CONTAINMENT_JOB_PREFIX+uuid.uuid4().hex; job=k.CreateJobObjectW(None,name)\n"
            "assert job\n"
            "try:\n"
            " x=_ExtendedLimits(); x.BasicLimitInformation.LimitFlags=0x2300; x.ProcessMemoryLimit=x.JobMemoryLimit=2*1024**3\n"
            " assert k.SetInformationJobObject(job,9,ctypes.byref(x),ctypes.sizeof(x))\n"
            " os.environ[CONTAINMENT_JOB_ENV]=name\n"
            " _require_worker_containment(2*1024**3)\n"
            "finally:\n"
            " assert k.CloseHandle(job)\n"
        )
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertIn(b"not a member", (self.folder / "process/stderr.log").read_bytes())

    def test_explicit_membership_does_not_approve_missing_limit_flags(self):
        script = (
            f"import sys; sys.path.insert(0,{str(ROOT)!r})\n"
            "import os,uuid\n"
            "from hero_engine.audio_perception_supervisor import _kernel,_require_worker_containment,CONTAINMENT_JOB_ENV,CONTAINMENT_JOB_PREFIX\n"
            "k=_kernel(); name=CONTAINMENT_JOB_PREFIX+uuid.uuid4().hex; job=k.CreateJobObjectW(None,name)\n"
            "assert job\n"
            "try:\n"
            " assert k.AssignProcessToJobObject(job,k.GetCurrentProcess())\n"
            " os.environ[CONTAINMENT_JOB_ENV]=name\n"
            " _require_worker_containment(2*1024**3)\n"
            "finally:\n"
            " assert k.CloseHandle(job)\n"
        )
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertIn(b"requires kill-on-close, memory ceilings and no breakaway", (self.folder / "process/stderr.log").read_bytes())

    def test_unknown_explicit_job_fails_without_implicit_fallback(self):
        script = (f"import sys,os,uuid; sys.path.insert(0,{str(ROOT)!r}); "
                  "from hero_engine.audio_perception_supervisor import _require_worker_containment,CONTAINMENT_JOB_ENV,CONTAINMENT_JOB_PREFIX; "
                  "os.environ[CONTAINMENT_JOB_ENV]=CONTAINMENT_JOB_PREFIX+uuid.uuid4().hex; "
                  "_require_worker_containment(2*1024**3)")
        result = self.run_child(script, timeout_seconds=5)
        self.assertEqual(result["status"], "CHILD_FAILED")
        self.assertIn(b"WinError 2", (self.folder / "process/stderr.log").read_bytes())

    def test_job_identity_is_child_local_and_parent_marker_cannot_rebind_it(self):
        script = ("import os; "
                  f"print(os.environ[{supervisor.CONTAINMENT_JOB_ENV!r}])")
        with mock.patch.dict(os.environ, {supervisor.CONTAINMENT_JOB_ENV: "foreign-parent-value"}):
            result = self.run_child(script, timeout_seconds=5)
            self.assertEqual(os.environ[supervisor.CONTAINMENT_JOB_ENV], "foreign-parent-value")
        self.assertEqual(result["status"], "SUCCEEDED")
        self.assertEqual((self.folder / "process/stdout.log").read_text().strip(), result["containment_job_name"])
        self.assertTrue(result["containment_job_created_new"])

    def test_preexisting_named_job_is_not_reconfigured_or_used(self):
        identity = "1" * 32
        name = supervisor.CONTAINMENT_JOB_PREFIX + identity
        k = supervisor._kernel()
        job = k.CreateJobObjectW(None, name)
        self.assertTrue(job)
        try:
            with mock.patch.object(supervisor.uuid, "uuid4", return_value=mock.Mock(hex=identity)):
                result = self.run_child("print('must not run')", timeout_seconds=5)
            self.assertEqual(result["status"], "SUPERVISOR_ERROR")
            self.assertIsNone(result["child_pid"])
            self.assertFalse(result["containment_job_created_new"])
            self.assertFalse(result["kill_on_close"])
            self.assertFalse(result["assigned_before_resume"])
            limits = supervisor._ExtendedLimits()
            self.assertTrue(k.QueryInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits), None))
            self.assertEqual(limits.BasicLimitInformation.LimitFlags, 0)
        finally:
            self.assertTrue(k.CloseHandle(job))

    def _instrumented_worker(self, close_succeeds):
        """Control-flow fixture only: no native process, model or audio measure."""
        events = []
        request_path = self.folder / "request.json"
        request = {
            "version": supervisor.VERSION, "runner_sha256": supervisor.FROZEN_RUNNER_SHA,
            "supervisor_sha256": "fixture-supervisor", "source": "fixture-source",
            "source_sha256": "fixture-source-hash", "bundle": "fixture-bundle",
            "ffmpeg": "fixture-ffmpeg", "ffmpeg_sha256": "fixture-ffmpeg-hash",
            "memory_bytes": 2 * 1024 ** 3, "output": str(self.folder / "measurement.json"),
        }
        canonical = lambda value: json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        adapter = mock.Mock()
        adapter.read_pinned.return_value = canonical(request)
        adapter.canonical.side_effect = canonical
        adapter.measure.side_effect = lambda *_: events.append("measure") or {"fixture": True}
        k = mock.Mock()
        k.OpenJobObjectW.return_value = 42

        def membership(process, job, pointer):
            ctypes.cast(pointer, ctypes.POINTER(supervisor.w.BOOL)).contents.value = True
            return True

        def limits(job, kind, pointer, size, returned):
            value = ctypes.cast(pointer, ctypes.POINTER(supervisor._ExtendedLimits)).contents
            value.BasicLimitInformation.LimitFlags = 0x2300
            value.ProcessMemoryLimit = value.JobMemoryLimit = 2 * 1024 ** 3
            return True

        k.IsProcessInJob.side_effect = membership
        k.QueryInformationJobObject.side_effect = limits
        k.CloseHandle.side_effect = lambda handle: events.append("close_query_handle") or close_succeeds
        self.enterContext(mock.patch.object(supervisor, "_adapter", return_value=adapter))
        self.enterContext(mock.patch.object(supervisor, "_kernel", return_value=k))
        self.enterContext(mock.patch.dict(os.environ, {
            supervisor.CONTAINMENT_JOB_ENV: supervisor.CONTAINMENT_JOB_PREFIX + "2" * 32,
        }))
        return request_path, adapter, k, events

    def test_worker_query_handle_closes_before_measurement(self):
        request_path, adapter, k, events = self._instrumented_worker(True)
        supervisor._worker(request_path, "fixture-request-hash")
        self.assertEqual(events, ["close_query_handle", "measure"])
        k.OpenJobObjectW.assert_called_once_with(0x0004, False, supervisor.CONTAINMENT_JOB_PREFIX + "2" * 32)
        k.CloseHandle.assert_called_once_with(42)
        adapter.measure.assert_called_once()

    def test_worker_query_handle_close_failure_prevents_measurement(self):
        request_path, adapter, k, events = self._instrumented_worker(False)
        with self.assertRaises(OSError):
            supervisor._worker(request_path, "fixture-request-hash")
        self.assertEqual(events, ["close_query_handle"])
        k.CloseHandle.assert_called_once_with(42)
        adapter.measure.assert_not_called()
        adapter.immutable_write.assert_not_called()

    def test_invalid_limits_fail_before_start(self):
        for value in (0, -1, True, float("nan"), float("inf"), 601):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.run_child("print('must not run')", timeout_seconds=value)
        self.assertFalse((self.folder / "process").exists())

    def test_existing_logs_never_overwritten(self):
        first = self.run_child("print('kept')", timeout_seconds=5)
        before = (self.folder / "process/process-receipt.json").read_bytes()
        with self.assertRaises(FileExistsError):
            self.run_child("print('replace')", timeout_seconds=5)
        self.assertEqual((self.folder / "process/process-receipt.json").read_bytes(), before)
        self.assertEqual(first["status"], "SUCCEEDED")

    def test_real_cached_receipt_no_worker_inference_or_network(self):
        adapter = supervisor._adapter()
        before = REAL_RECEIPT.read_bytes()
        with mock.patch.object(supervisor, "run_bounded", side_effect=AssertionError("no worker")), \
             mock.patch.object(adapter, "measure", side_effect=AssertionError("no inference")), \
             mock.patch.object(adapter.subprocess, "run", side_effect=AssertionError("no subprocess")), \
             mock.patch.object(adapter.urllib.request, "urlopen", side_effect=AssertionError("no network")):
            observed = json.loads(before)
            result = supervisor.supervise_measurement(
                source=Path(observed["source"]["path"]), source_sha=SOURCE_SHA,
                bundle=Path(observed["artifacts"][0]["path"]).parent,
                ffmpeg=Path(observed["ffmpeg"]["path"]), ffmpeg_sha=observed["ffmpeg"]["sha256"],
                receipt=REAL_RECEIPT, receipt_sha=REAL_SHA, attempts=self.folder / "never_created")
        self.assertEqual(result["status"], "CACHED_MEASUREMENT_VERIFIED")
        self.assertEqual(result["replay"]["windows"], 195)
        self.assertEqual(result["new_inference_calls"], 0)
        self.assertFalse((self.folder / "never_created").exists())
        self.assertEqual(REAL_RECEIPT.read_bytes(), before)

    def test_corrupted_cache_rejected_without_fallback(self):
        corrupt = self.folder / "receipt.json"
        corrupt.write_bytes(REAL_RECEIPT.read_bytes() + b" ")
        with mock.patch.object(supervisor, "run_bounded", side_effect=AssertionError("no worker")), \
             self.assertRaisesRegex(ValueError, "hash mismatch"):
            supervisor.verify_cached(corrupt, REAL_SHA, SOURCE_SHA)
        self.assertTrue(corrupt.read_bytes().endswith(b" "))

    def test_cache_missing_external_pin_rejected(self):
        with self.assertRaisesRegex(ValueError, "external SHA"):
            supervisor.supervise_measurement(source=self.folder, source_sha=SOURCE_SHA,
                bundle=self.folder, ffmpeg=self.folder, ffmpeg_sha="0" * 64,
                receipt=REAL_RECEIPT, attempts=self.folder / "not-created")
        self.assertFalse((self.folder / "not-created").exists())

    def test_schema_tamper_even_with_new_receipt_hash_rejected(self):
        value = json.loads(REAL_RECEIPT.read_bytes())
        value["release_authority"] = True
        adapter = supervisor._adapter()
        raw = adapter.canonical(value)
        corrupt = self.folder / "receipt.json"
        corrupt.write_bytes(raw)
        import jsonschema
        with self.assertRaises(jsonschema.ValidationError):
            supervisor.verify_cached(corrupt, adapter.sha(raw), SOURCE_SHA)

    def test_complete_recovery_no_inference_preserves_original(self):
        value = json.loads(REAL_RECEIPT.read_bytes())
        target = self.folder / "recovered.json"
        with mock.patch.object(supervisor, "run_bounded", side_effect=AssertionError("no worker")):
            result = supervisor.supervise_measurement(
                source=Path(value["source"]["path"]), source_sha=SOURCE_SHA,
                bundle=Path(value["artifacts"][0]["path"]).parent,
                ffmpeg=Path(value["ffmpeg"]["path"]), ffmpeg_sha=value["ffmpeg"]["sha256"],
                receipt=target, attempts=self.folder / "not-created",
                recovery_receipt=REAL_RECEIPT, recovery_sha=REAL_SHA)
        self.assertEqual(result["status"], "COMPLETED_MEASUREMENT_RECOVERED")
        self.assertEqual(target.read_bytes(), REAL_RECEIPT.read_bytes())
        self.assertFalse((self.folder / "not-created").exists())

    def test_atomic_commit_does_not_replace_existing(self):
        source, target = self.folder / "source", self.folder / "target"
        source.write_bytes(b"new")
        target.write_bytes(b"valid old evidence")
        with self.assertRaisesRegex(ValueError, "already exists"):
            supervisor._commit_new(source, target)
        self.assertEqual(target.read_bytes(), b"valid old evidence")

    def test_interrupted_promotion_preserves_complete_temporary_and_source(self):
        source, target = self.folder / "complete", self.folder / "target"
        source.write_bytes(b"complete preserved bytes")
        with mock.patch.object(supervisor.os, "rename", side_effect=PermissionError("injected lock")), \
             self.assertRaises(PermissionError):
            supervisor._commit_new(source, target)
        self.assertFalse(target.exists())
        temporaries = list(self.folder.glob(".target.*.complete"))
        self.assertEqual(len(temporaries), 1)
        self.assertEqual(temporaries[0].read_bytes(), source.read_bytes())

    def test_missing_pinned_receipt_does_not_start_worker(self):
        with mock.patch.object(supervisor, "run_bounded", side_effect=AssertionError("must not start")), \
             self.assertRaises(ValueError):
            supervisor.supervise_measurement(source=self.folder, source_sha=SOURCE_SHA,
                bundle=self.folder, ffmpeg=self.folder, ffmpeg_sha="0" * 64,
                receipt=self.folder / "missing.json", receipt_sha=REAL_SHA,
                attempts=self.folder / "never-created")
        self.assertFalse((self.folder / "never-created").exists())


if __name__ == "__main__":
    unittest.main()
