"""Real synthetic children; no operational maintenance is launched."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from hero_engine import maintenance_application_launcher as launcher
from hero_engine import maintenance_protocol as protocol


class ApplicationLauncherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='hero-launch-witness-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve() / 'ação com espaços'
        self.runs = self.root / 'output/runtime/gestor-central/maintenance-runs'
        self.runs.mkdir(parents=True)
        (self.runs.parent / 'PAUSE').write_bytes(b'owner-pause')
        self.proof = self.runs / 'proof' / 'application-envelope.json'
        self.proof.parent.mkdir()
        self.proof.write_bytes(b'{}')
        self.args = dict(root=self.root, record=self.runs / 'dispatch', proof_envelope=self.proof,
                         expected_proof_hash='sha256:'+'a'*64, expected_candidate_hash='b'*64)

    def test_real_exit_stderr_and_unicode_argument_preserved(self):
        child = self.root / 'filho com acento ação.py'
        child.write_text("import sys; print(sys.argv[1]); sys.stderr.write('diagnostic'); sys.exit(7)", encoding='utf-8')
        result = launcher._record_once(self.root, self.args['record'], [sys.executable, '-B', str(child), 'two words'])
        self.assertEqual(7, result['exit_code'])
        self.assertIn(b'two words', (self.args['record']/'application.stdout.log').read_bytes())
        self.assertEqual(b'diagnostic', (self.args['record']/'application.stderr.log').read_bytes())
        self.assertEqual(result, json.loads((self.args['record']/'process-result.json').read_bytes()))
        self.assertGreater(result['wall_seconds'], 0)

    def test_public_entry_uses_exact_cli_and_never_splits_root(self):
        # The subprocess boundary is simulated only here; command construction
        # and public main execute the actual implementation.
        with patch.object(launcher, '_record_once', return_value={'exit_code': 0}) as record, \
             patch.object(launcher, '_write_paused_application_reference', return_value=None) as reference:
            result = launcher.launch(**self.args)
        self.assertEqual(0, result['exit_code'])
        command = record.call_args.args[2]
        self.assertEqual(13, len(command))
        self.assertEqual(str(self.root), command[5])
        self.assertEqual('apply-paused', command[6])
        self.assertEqual(self.args['expected_proof_hash'], command[10])
        self.assertEqual(self.args['record'], reference.call_args.kwargs['record'])

    def test_duplicate_dispatch_is_rejected_without_new_child(self):
        launcher._record_once(self.root, self.args['record'], [sys.executable, '-B', '-c', 'pass'])
        with patch.object(launcher.subprocess, 'Popen') as child:
            with self.assertRaises(FileExistsError):
                launcher.launch(**self.args)
            child.assert_not_called()

    def test_missing_executable_has_no_fabricated_exit(self):
        with self.assertRaises(OSError):
            launcher._record_once(self.root, self.args['record'], [str(self.root/'missing.exe')])
        self.assertFalse((self.args['record']/'process-result.json').exists())
        self.assertFalse(json.loads((self.args['record']/'launch-failure.json').read_bytes())['child_started'])

    def test_pause_anchor_and_record_confinement_fail_before_child(self):
        for change in ({'expected_proof_hash': ''}, {'record': self.root/'outside'}, {'record': self.proof.parent}):
            with self.subTest(change=change), patch.object(launcher.subprocess, 'Popen') as child:
                with self.assertRaises(ValueError):
                    launcher.launch(**{**self.args, **change})
                child.assert_not_called()
        (self.runs.parent/'PAUSE').unlink()
        with self.assertRaises(PermissionError):
            launcher.launch(**self.args)

    def test_success_reference_binds_exact_commit_stdout_and_process(self):
        record = self.args['record']
        record.mkdir()
        command = ['python', '-B', '-m', 'hero_engine.maintenance_protocol', '--root', str(self.root),
                   'apply-paused', '--proof-envelope', 'proof/application-envelope.json',
                   '--expected-proof-hash', self.args['expected_proof_hash'],
                   '--expected-candidate-hash', self.args['expected_candidate_hash']]
        result = {'command': command, 'pid': 77, 'started_at': '2026-09-19T00:00:00+00:00',
                  'finished_at': '2026-09-19T00:00:01+00:00', 'wall_seconds': 1.0,
                  'exit_code': 0, 'automatic_retry': False, 'supervisor_restart_authorized': False}
        (record/'process-result.json').write_text(json.dumps(result), encoding='utf-8')
        (record/'application.stderr.log').write_bytes(b'')
        binding = {'root': str(self.root), 'proof_path': 'proof/application-envelope.json',
                   'proof_hash': self.args['expected_proof_hash'], 'candidate_sha256': self.args['expected_candidate_hash']}
        run = self.runs/'maintenance-request-20260919T0000010000000Z-aaaaaaaa'
        run.mkdir()
        commit = {'status': 'APPLIED_WHILE_PAUSED', 'binding': binding}
        raw = json.dumps(commit, sort_keys=True).encode('utf-8')
        (run/'committed.json').write_bytes(raw)
        (record/'application.stdout.log').write_bytes(raw)
        with patch('hero_engine.maintenance_paused_application._anchored_application_run', return_value=(run, binding)), \
             patch('hero_engine.maintenance_protocol.validate') as validate:
            reference = launcher._write_paused_application_reference(
                self.root, record=record, proof_envelope=self.proof,
                expected_proof_hash=self.args['expected_proof_hash'],
                expected_candidate_hash=self.args['expected_candidate_hash'], result=result)
        self.assertEqual(record/'paused-application-reference.json', reference)
        value = json.loads(reference.read_bytes())
        self.assertEqual('phase6_paused_application_reference.schema.json', validate.call_args.args[1])
        self.assertEqual('maintenance-request-20260919T0000010000000Z-aaaaaaaa/committed.json',
                         value['commit_path'].split('maintenance-runs/', 1)[1])
        tampered = self.runs/'different-record'
        tampered.mkdir()
        (tampered/'process-result.json').write_text(json.dumps(result), encoding='utf-8')
        (tampered/'application.stderr.log').write_bytes(b'')
        (record/'application.stdout.log').write_bytes(b'not the receipt')
        (tampered/'application.stdout.log').write_bytes(b'not the receipt')
        with patch('hero_engine.maintenance_paused_application._anchored_application_run', return_value=(run, binding)):
            with self.assertRaises(RuntimeError):
                launcher._write_paused_application_reference(
                    self.root, record=tampered, proof_envelope=self.proof,
                    expected_proof_hash=self.args['expected_proof_hash'],
                    expected_candidate_hash=self.args['expected_candidate_hash'], result=result)

    def test_apply_cli_uses_committed_bytes_not_a_reserialized_mapping(self):
        app_id = 'maintenance-request-20260919T0000010000000Z-aaaaaaaa'
        committed = self.runs / app_id / 'committed.json'
        committed.parent.mkdir()
        raw = b'{"application_id":"' + app_id.encode('ascii') + b'","status":"APPLIED_WHILE_PAUSED"}\n'
        committed.write_bytes(raw)
        receipt = json.loads(raw)
        self.assertEqual(raw, protocol.committed_application_stdout(self.root, receipt))
        with self.assertRaises(PermissionError):
            protocol.committed_application_stdout(self.root, {**receipt, 'status': 'tampered'})
