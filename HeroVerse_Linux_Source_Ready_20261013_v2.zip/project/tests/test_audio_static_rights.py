import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from PIL import Image
from jsonschema.exceptions import ValidationError
from hero_engine.continuity import build_visual_continuity_bible
from hero_engine.procedural_infographics_phase5 import (
    compile_audio_static_composition, build_audio_static_source, read_audio_static_source)
from hero_engine.phase6_asset_residency import validate_phase6_rights_evidence

ROOT = Path(__file__).resolve().parents[1]
RECORD = ROOT / 'output/runtime/gestor-central/maintenance-runs/audio-static-rights-20261005'


def sha(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


class AudioStaticRightsTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=RECORD, prefix='own-test-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        (self.root / 'schemas').mkdir()
        shutil.copy2(ROOT / 'schemas/phase6_rights_evidence.schema.json', self.root / 'schemas')
        pack = json.loads((ROOT / 'config/format_packs/fp-narrated-reflection-static-v1.json').read_text())
        model = json.loads((ROOT / 'output/modeling/phase4/channel-model-v1/channel_model.json').read_text())
        bible = build_visual_continuity_bible(channel_model=model, format_pack=pack,
            asset_manifest={'assets': []}, created_at='2026-10-05T00:00:00Z')
        self.layout = compile_audio_static_composition(title='One Faithful Step Under Pressure',
            bible=bible, format_pack=pack, font=Path(r'C:\Windows\Fonts\arialbd.ttf'))
        self.directory = self.root / 'output/source'
        self.evidence = build_audio_static_source(self.root, self.directory,
            layout=self.layout, verified_at='2026-10-05T00:00:00Z')
        self.asset = {'asset_id': self.layout['composition_id'], 'rights_status': 'OWNED',
            'rights_decision': self.evidence['decision'], 'commercial_use': True,
            'production_eligible': False, 'content_quality_gate': 'BLOCKED',
            'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False,
            'content_hash': self.evidence['raster_hash']}

    def verify(self):
        return validate_phase6_rights_evidence(self.root, self.asset, self.evidence,
            media_path=Path(self.evidence['raster']))

    def test_native_producer_to_real_rights_reader_held_no_fake_review(self):
        value = self.verify()
        self.assertEqual(value['status'], 'PASS')
        self.assertEqual(value['evidence_class'], 'PROJECT_OWNED_PROCEDURAL_STATIC')
        self.assertEqual(self.evidence['decision'], 'AUTO_VERIFIED_PROCEDURAL_SOURCE')
        self.assertFalse(self.asset['production_eligible'])
        self.assertFalse(self.asset['publication_authorized'])
        with self.assertRaises(PermissionError):
            build_audio_static_source(self.root, self.directory, layout=self.layout,
                                      verified_at='2026-10-05T00:00:00Z')

    def test_tampered_raster_even_rehashed_is_not_provenance(self):
        path = Path(self.evidence['raster'])
        Image.new('RGB', (1920,1080), '#101820').save(path)
        self.evidence['raster_hash'] = self.asset['content_hash'] = sha(path)
        with self.assertRaises(PermissionError): self.verify()

    def test_manifest_layout_or_generator_tamper_rejected(self):
        path = Path(self.evidence['composition_manifest']['path'])
        original = json.loads(path.read_text(encoding='utf-8'))
        for kind in ('layout','generator'):
            with self.subTest(kind=kind):
                value = copy.deepcopy(original)
                if kind == 'layout': value['layout']['texts'][0]['render_text'] = 'Changed'
                else: value['generator']['sha256'] = 'sha256:' + '0'*64
                path.write_text(json.dumps(value), encoding='utf-8')
                self.evidence['composition_manifest']['sha256'] = sha(path)
                with self.assertRaises(PermissionError): self.verify()

    def test_svg_altered_or_manifest_absent_rejected(self):
        path = Path(self.evidence['source_svg'])
        path.write_bytes(path.read_bytes().replace(b'One Faithful',b'False Text'))
        self.evidence['source_svg_hash'] = sha(path)
        with self.assertRaises(PermissionError): self.verify()
        self.evidence.pop('composition_manifest')
        with self.assertRaises(ValidationError): self.verify()

    def test_asset_identity_and_partial_authority_rejected(self):
        self.asset['asset_id'] = 'foreign'
        with self.assertRaises(ValueError): self.verify()
        self.asset['asset_id'] = self.layout['composition_id']
        self.asset['render_authorized'] = True
        with self.assertRaises(ValueError): self.verify()

    def test_root_escape_does_not_write_or_validate(self):
        with self.assertRaises(PermissionError):
            build_audio_static_source(self.root, self.root.parent / 'forbidden-static',
                                     layout=self.layout, verified_at='2026-10-05T00:00:00Z')
        ref = self.evidence['composition_manifest']
        with self.assertRaises(PermissionError):
            read_audio_static_source(self.root / 'output', Path(ref['path']).parent.parent,
                                     expected_sha256=ref['sha256'])

    def native_renderer_fixture(self):
        from tests.test_audio_static_producer import AudioStaticProducerTests, write
        owner = AudioStaticProducerTests('test_public_native_entry_compiles_static_video_and_reuses_voice')
        self.addCleanup(owner.doCleanups)
        owner.setUp()
        evidence = build_audio_static_source(owner.root, owner.package / 'auto-source',
            layout=self.layout, verified_at='2026-10-05T00:00:00Z')
        owner.image, owner.vector = Path(evidence['raster']), Path(evidence['source_svg'])
        owner.rights, owner.evidence = owner.image.parent / 'rights-evidence.json', evidence
        owner.asset.update(asset_id=evidence['asset_id'], uri=str(owner.image),
            content_hash=evidence['raster_hash'], rights_evidence_uri=str(owner.rights),
            rights_decision=evidence['decision'], source=str(owner.vector))
        from hero_engine.asset_quality_phase5 import admit_audio_static_source
        held = copy.deepcopy(owner.asset)
        held.update(production_eligible=False, content_quality_gate='BLOCKED',
            quality_authorized=False, render_authorized=False, publication_authorized=False)
        held_path = owner.package / 'held-auto-source.json'
        write(held_path, held)
        admitted = admit_audio_static_source(owner.root, asset_path=held_path,
            expected_asset_hash=sha(held_path), destination=owner.package / 'source-admission.json',
            created_at='2026-10-05T00:00:00Z')
        owner.asset.clear()
        owner.asset.update(admitted)
        owner.plan, owner.updated = owner.plan_inputs()
        for voice, take in zip(owner.voice['takes'], owner.plan['takes']):
            voice['take_id'] = take['take_id']
        write(owner.package / 'take_plan.json', owner.plan)
        write(owner.package / 'asset_manifest.json', owner.updated)
        write(owner.package / 'audio/voice_render_manifest.json', owner.voice)
        return owner

    def test_public_renderer_consumes_automatic_provenance_and_reopens_it(self):
        owner = self.native_renderer_fixture()
        result = owner.render()
        self.assertEqual(result['status'], 'COMPLETE')
        self.assertFalse(result['publication_approved'])
        bindings = json.loads((owner.package / 'render-input-bindings.json').read_text(encoding='utf-8'))
        self.assertIn('source-manifest.json', json.dumps(bindings))

    def test_source_manifest_changed_during_render_blocks_next_command(self):
        owner = self.native_renderer_fixture()
        original = owner.fake_process
        def codec(command, **kwargs):
            result = original(command, **kwargs)
            if len(owner.commands) == 1:
                path = Path(owner.evidence['composition_manifest']['path'])
                path.write_bytes(path.read_bytes() + b' ')
            return result
        owner.fake_process = codec
        with self.assertRaises(PermissionError): owner.render()
        self.assertEqual(len(owner.commands), 1)
        self.assertFalse((owner.package / 'render_manifest.json').exists())
