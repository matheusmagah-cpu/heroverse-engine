"""Real package/QA readers; only codec, ASR and host boundaries are simulated."""
import copy
import shutil
import unittest
from pathlib import Path
from unittest.mock import patch
from tests import test_audio_static_qa as fixture
from tests import test_phase6_media as voice_fixture
from hero_engine.publication_package_phase5 import build_publication_package, prepare_audio_static_packaging

class AudioStaticPublicationPackageTests(unittest.TestCase):
    def setUp(self):
        self.owner = fixture.AudioStaticQaTests('test_final_technical_static_hold_not_wrongly_rejected_as_freeze')
        self.addCleanup(self.owner.doCleanups)
        original_write = voice_fixture.Phase6MediaTests._write
        def enriched_voice_script(root, relative, value):
            value = copy.deepcopy(value)
            if relative.endswith('/narrative_script.json'):
                value.update(title='Current owned reflection', full_text='A verified local voice.',
                    original_thesis='An original bounded faithful response.', source_basis=[{'source_ref':'James 1:5'}])
            original_write(root, relative, value)
        with patch.object(voice_fixture.Phase6MediaTests, '_write', staticmethod(enriched_voice_script)), \
             patch.object(fixture.voice_fixture.AudioStaticVoiceReuseTests, 'channel_id',
                          'UCuMF6pJQkyMzaVoAxFL86yA', create=True):
            self.owner.setUp()
        self.root, self.package = self.owner.root, self.owner.package
        for schema in ('publication_package',):
            shutil.copy2(fixture.ROOT/f'schemas/{schema}.schema.json', self.root/'schemas')
        pack_dir=self.root/'config/format_packs';pack_dir.mkdir(parents=True)
        shutil.copy2(fixture.ROOT/'config/format_packs/fp-narrated-reflection-static-v1.json',pack_dir)
        original = self.root/self.owner.helper.voice['narrative_script']['path']
        native_write = fixture.write
        def keep_measured_script(path, value):
            if path == self.package/'narrative_script.json':
                shutil.copyfile(original, path)
                return
            native_write(path, value)
        with patch.object(fixture, 'write', keep_measured_script):
            self.owner.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        prepare_audio_static_packaging(self.root,package_relative=self.owner.relative)
        self.report=self.package/'qa/creative_quality_gate_report.json'
        self.measured=self.package/'qa/technical_measurements.json'
        self.report_binding={'path':str(self.report),'sha256':fixture.voice_fixture.sha(self.report)}
        self.measured_binding={'path':str(self.measured),'sha256':fixture.voice_fixture.sha(self.measured)}

    def build(self, **kwargs):
        args={'package_relative':self.owner.relative, 'quality_report_binding':self.report_binding,
              'measurement_binding':self.measured_binding}
        args.update(kwargs)
        return build_publication_package(self.root, **args)

    def test_current_public_producer_uses_current_script_and_owned_media_only(self):
        result=self.build()
        self.assertEqual(result['metadata']['title'],'Current owned reflection')
        self.assertIn('James 1:5',result['metadata']['description'])
        self.assertNotIn('FreeSwissVideo',result['metadata']['description'])
        self.assertNotIn('photorealistic',result['disclosure']['reason'])
        self.assertEqual(result['captions']['cue_count'],1)
        self.assertEqual(result['quality_gate']['automatic_status'],'FAIL')
        self.assertFalse(result['publication_policy']['upload_permitted'])
        self.assertFalse(result['quality_gate']['publication_eligible'])
        self.assertEqual(self.build()['package_id'],result['package_id'])

    def test_unbound_latest_qa_cannot_be_consumed(self):
        with self.assertRaises(PermissionError):self.build(quality_report_binding=None)

    def test_qa_or_measurement_tamper_is_rejected(self):
        self.report.write_bytes(b'tampered')
        with self.assertRaises(PermissionError):self.build()

    def test_measurements_from_another_render_rejected_even_with_fixture_anchor(self):
        value=fixture.read(self.measured);value['render_hash']='sha256:'+'0'*64;fixture.write(self.measured,value)
        self.measured_binding['sha256']=fixture.voice_fixture.sha(self.measured)
        with self.assertRaises(PermissionError):self.build()

    def test_duplicate_gate_cannot_replace_missing_gate(self):
        value=fixture.read(self.report);value['gates'][-1]=copy.deepcopy(value['gates'][0]);fixture.write(self.report,value)
        self.report_binding['sha256']=fixture.voice_fixture.sha(self.report)
        with self.assertRaises(PermissionError):self.build()

    def test_changed_native_caption_blocks_assembly(self):
        (self.package/'captions/en-US.srt').write_bytes(b'not the measured narration')
        with self.assertRaises(PermissionError):self.build()

    def test_no_implicit_static_binding_in_legacy_path(self):
        with self.assertRaises(PermissionError):
            build_publication_package(self.root, quality_report_binding=self.report_binding)

    def test_post_read_tamper_does_not_complete_assembly(self):
        from hero_engine import publication_package_phase5 as module
        native=module._read
        def change_after_read(path):
            result=native(path)
            if path.name=='render_manifest.json':
                (self.package/'thumbnail/owned-static.png').write_bytes(b'changed after reader')
            return result
        with patch.object(module,'_read',side_effect=change_after_read):
            with self.assertRaises(PermissionError):self.build()

    def test_incomplete_source_population_cannot_be_minted_with_fixture_anchor(self):
        value=fixture.read(self.measured);value['static_source_inputs']['inputs'].pop();fixture.write(self.measured,value)
        self.measured_binding['sha256']=fixture.voice_fixture.sha(self.measured)
        with self.assertRaises(PermissionError):self.build()

    def test_public_materializer_recovers_exact_bytes_and_rejects_overwrite(self):
        from hero_engine.publication_package_phase5 import materialize
        args={'package_relative':self.owner.relative,'quality_report_binding':self.report_binding,
              'measurement_binding':self.measured_binding}
        path=materialize(self.root,**args);before=path.read_bytes()
        self.assertEqual(path,materialize(self.root,**args));self.assertEqual(path.read_bytes(),before)
        value=fixture.read(path);value['publication_policy']['upload_permitted']=True;fixture.write(path,value)
        tampered=path.read_bytes()
        with self.assertRaises(PermissionError):materialize(self.root,**args)
        self.assertEqual(path.read_bytes(),tampered)

    def test_render_absent_cannot_be_replaced_by_old_report(self):
        Path(fixture.read(self.measured)['render_path']).unlink()
        with self.assertRaises(FileNotFoundError):self.build()
