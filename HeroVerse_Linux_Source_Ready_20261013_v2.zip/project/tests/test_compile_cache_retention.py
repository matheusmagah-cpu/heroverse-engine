"""T25: real file/handle disposal; synthetic completion and OS PID boundary.

No production roots, network, upload, audiovisual generation or revived manager.
"""
import json
import os
from pathlib import Path
import py_compile
import tempfile
import unittest
from unittest.mock import patch
from contextlib import ExitStack

from hero_engine import compile_cache_retention as retention
from hero_engine import maintenance_protocol as protocol


class CompileCacheRetentionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='t25-retention-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run = self.root / retention.RUNS / 'synthetic-completed-validation'
        self.cache = self.run / 'compile-cache'
        self.cache.mkdir(parents=True)
        source = self.root / 'own-test-source.py'
        source.write_text('answer = 42\n', encoding='utf-8')
        self.binary = self.cache / 'own.pyc'
        py_compile.compile(str(source), cfile=str(self.binary), doraise=True)
        self.process = dict(exit_code=0, timed_out=False, pid=os.getpid(),
                            command='compileall hero_engine tests; private compile-cache')
        retention.record_completed_cache(self.root, self.run, self.process)
        (self.run / 'full-process-result.json').write_text(json.dumps(dict(exit_code=0, timed_out=False, test_pid=os.getpid())), encoding='utf-8')
        self.seal()
        self.pid = patch.object(protocol, '_paused_cancel_absent', return_value={})
        self.pid.start()
        self.addCleanup(self.pid.stop)

    def seal(self, extra=None):
        files=[]
        for name in (retention.NAME, 'full-process-result.json'):
            raw=(self.run/name).read_bytes()
            files.append(dict(path=name,bytes=len(raw),sha256=retention._hash(raw)))
        if extra:files.append(extra)
        (self.run/'evidence-bindings.json').write_text(json.dumps(dict(
            excluded='compile-cache (owned reproducible bytecode, retained)',files=files)),encoding='utf-8')

    def collect(self):
        return retention.collect_completed_caches(self.root)

    def test_eligible_real_binary_removed_with_exact_manifest_and_intentional_absence(self):
        preserved={name:(self.run/name).read_bytes() for name in (retention.NAME,'evidence-bindings.json','full-process-result.json')}
        result=self.collect()
        self.assertEqual(1,result['deleted_files'])
        self.assertFalse(self.binary.exists())
        self.assertEqual('DISCARDED',result['runs'][0]['status'])
        terminal=json.loads((self.run/'compile-cache-discarded.json').read_bytes())
        self.assertEqual('INTENTIONALLY_ABSENT_COMPILE_CACHE',terminal['state'])
        self.assertFalse(terminal['media_deleted'])
        self.assertTrue(all((self.run/name).read_bytes()==raw for name,raw in preserved.items()))
        self.assertIsInstance(result['after_free_bytes'],int)

    def test_repeat_does_not_remove_replacement_or_recompile(self):
        self.collect()
        self.assertEqual('ALREADY_DISCARDED',self.collect()['runs'][0]['status'])
        self.binary.write_bytes(b'foreign replacement')
        result=self.collect()
        self.assertEqual(0,result['deleted_files'])
        self.assertEqual(b'foreign replacement',self.binary.read_bytes())

    def test_incomplete_unsealed_compilation_and_failed_regression_are_retained(self):
        for change in ('unsealed','compile_failed','regression_failed'):
            with self.subTest(change=change):
                original=(self.run/retention.NAME).read_bytes()
                process_raw=(self.run/'full-process-result.json').read_bytes()
                if change=='unsealed':
                    (self.run/retention.NAME).write_bytes(original+b' ')
                elif change=='compile_failed':
                    value=json.loads(original);value['process']['exit_code']=1
                    (self.run/retention.NAME).write_text(json.dumps(value),encoding='utf-8');self.seal()
                else:
                    (self.run/'full-process-result.json').write_text(json.dumps(dict(exit_code=1,timed_out=False,test_pid=os.getpid())),encoding='utf-8');self.seal()
                self.assertEqual(0,self.collect()['deleted_files'])
                self.assertTrue(self.binary.exists())
                (self.run/retention.NAME).write_bytes(original)
                (self.run/'full-process-result.json').write_bytes(process_raw);self.seal()

    def test_active_reference_blocks_even_when_owner_completed(self):
        self.seal(dict(path='compile-cache/own.pyc',bytes=self.binary.stat().st_size,sha256=retention._hash(self.binary.read_bytes())))
        self.assertIn('ACTIVE_BYTE_DEPENDENCY',self.collect()['runs'][0]['reason'])
        self.assertTrue(self.binary.exists())

    def test_live_or_uncertain_owner_blocks(self):
        self.pid.stop()
        self.assertIn('NOT_PROVEN_ABSENT',self.collect()['runs'][0]['reason'])
        with patch.object(protocol,'_process_alive',side_effect=OSError('identity unavailable')):
            self.assertIn('IDENTITY_UNCERTAIN',self.collect()['runs'][0]['reason'])
        self.assertTrue(self.binary.exists())

    def test_boolean_exit_or_pid_cannot_impersonate_a_completed_process(self):
        for key in ('pid','exit_code'):
            with self.subTest(key=key):
                value=json.loads((self.run/retention.NAME).read_bytes())
                original=json.loads(json.dumps(value))
                value['process'][key]=False
                (self.run/retention.NAME).write_text(json.dumps(value),encoding='utf-8');self.seal()
                self.assertEqual(0,self.collect()['deleted_files'])
                (self.run/retention.NAME).write_text(json.dumps(original),encoding='utf-8');self.seal()

    def test_probe_failure_does_not_raise_over_a_persisted_completion(self):
        with patch.object(retention.shutil,'disk_usage',side_effect=OSError('probe failed')):
            result=self.collect()
        self.assertEqual('BLOCKED_OR_PARTIAL',result['status'])
        self.assertEqual(0,result['deleted_files'])
        self.assertTrue(self.binary.exists())

    def test_open_file_blocks_and_partial_plan_is_not_blindly_retried(self):
        with self.binary.open('rb'):
            result=self.collect()
        self.assertEqual(0,result['deleted_files'])
        self.assertTrue(self.binary.exists())
        self.assertIn('INTERRUPTED',self.collect()['runs'][0]['reason'])

    def test_reader_allowing_delete_still_blocks_disposal(self):
        ct,kernel=protocol._paused_cancel_kernel()
        handle=kernel.CreateFileW(str(self.binary),0x80000000,7,None,3,0x200000,None)
        self.assertNotEqual(ct.c_void_p(-1).value,handle)
        try:
            result=self.collect()
            self.assertEqual(0,result['deleted_files'])
            self.assertIn('IN_USE_OR_EXCLUSIVITY',result['runs'][0]['reason'])
            self.assertTrue(self.binary.exists())
        finally:
            self.assertTrue(kernel.CloseHandle(handle))

    def test_replaced_after_selection_preserved(self):
        actual=retention._delete_exact
        def replace(root,path,row):
            path.unlink();path.write_bytes(b'replacement must survive')
            return actual(root,path,row)
        with patch.object(retention,'_delete_exact',side_effect=replace):
            self.assertEqual(0,self.collect()['deleted_files'])
        self.assertEqual(b'replacement must survive',self.binary.read_bytes())

    def test_foreign_file_or_external_path_never_deleted(self):
        foreign=self.cache/'unknown.bin';foreign.write_bytes(b'keep')
        self.assertEqual(0,self.collect()['deleted_files'])
        self.assertEqual(b'keep',foreign.read_bytes())
        with self.assertRaises(PermissionError):
            retention._delete_exact(self.root, self.root.parent/'foreign.pyc', {})

    def test_removal_failure_and_absence_alone_do_not_authorize_success(self):
        with patch.object(protocol._PausedCancelPin,'remove',side_effect=OSError('controlled removal failure')):
            result=self.collect()
        self.assertEqual(0,result['deleted_files'])
        self.assertFalse((self.run/'compile-cache-discarded.json').exists())
        self.binary.unlink()
        self.assertIn('INTERRUPTED',self.collect()['runs'][0]['reason'])

    def test_pause_before_or_immediately_before_effect_preserves_everything(self):
        pause=self.root/'output/runtime/gestor-central/PAUSE'
        pause.write_bytes(b'owner')
        self.assertEqual('OWNER_PAUSE',self.collect()['status'])
        pause.unlink()  # only this test's own marker
        actual=retention._delete_exact
        def pause_now(root,path,row):
            pause.write_bytes(b'owner')
            return actual(root,path,row)
        with patch.object(retention,'_delete_exact',side_effect=pause_now):
            self.assertEqual(0,self.collect()['deleted_files'])
        self.assertEqual(b'owner',pause.read_bytes())
        self.assertTrue(self.binary.exists())

    def test_failure_after_deletion_never_fabricates_terminal_success(self):
        save=retention._save
        def fail_terminal(path,value):
            if path.name=='compile-cache-discarded.json':raise OSError('terminal unavailable')
            return save(path,value)
        with patch.object(retention,'_save',side_effect=fail_terminal):
            result=self.collect()
        self.assertEqual(1,result['deleted_files'])
        self.assertEqual('BLOCKED_OR_PARTIAL',result['status'])
        self.assertIn('INTERRUPTED',self.collect()['runs'][0]['reason'])

    def test_real_heavy_entry_reclaims_once_then_remeasures(self):
        from hero_engine.production_capacity import Phase6ResourcePreparation, BASE, ResourceWait
        from tests.test_active_resource_preparation import sample
        plan=self.root/BASE/'production/take_plan.json';plan.parent.mkdir(parents=True)
        plan.write_text(json.dumps({'takes':[{'start_ms':0,'end_ms':1000}]}))
        seen=[]
        def measure(_):
            seen.append(self.binary.exists())
            return sample(output_free_bytes=0 if self.binary.exists() else 20*1024**3)
        with Phase6ResourcePreparation(self.root,probe=measure) as resources:
            value=resources.prepare('ffmpeg')
            self.assertEqual('ADMITTED',value['status'])
            self.assertEqual([True,False],seen)
            self.assertEqual(1,value['disposable_cache_retention']['deleted_files'])
            resources.probe=lambda _:sample(available_ram_bytes=0)
            with self.assertRaises(ResourceWait):resources.prepare('ffmpeg')

    def test_completed_real_miner_replay_triggers_retention_without_touching_sources(self):
        import tests.test_mining_cache_integrity as fixtures
        fixture=fixtures.MiningCacheIntegrityTests()
        self.addCleanup(fixture.doCleanups)  # also runs if setUp itself fails
        fixture.setUp()
        try:
            # Move ONLY the retention fixture record into that isolated root.
            import shutil
            target=fixture.root/retention.RUNS/self.run.name
            self.assertTrue(self.run.resolve().is_relative_to(self.root.resolve()))
            self.assertTrue(target.resolve().is_relative_to(fixture.root.resolve()))
            target.parent.mkdir(parents=True)
            shutil.move(str(self.run),str(target))
            # Move changed file identity? Same volume preserves it; re-record
            # via the actual producer if the fixture filesystem did copy it.
            before=fixture.snapshot()
            result=fixture.guarded_miner().mine(fixture.video_id)
            self.assertTrue(result['cache_hit'])
            self.assertEqual(before,fixture.snapshot())
            self.assertTrue((fixture.source/(fixture.video_id+'.mp4')).is_file())
            self.assertFalse((target/'compile-cache/own.pyc').exists())
        finally:
            fixture.doCleanups()

    def test_publication_controller_retention_only_after_persisted_complete(self):
        from hero_engine import phase6_publication as pub
        import tests.test_phase6_publication as fixtures
        fixtures.Phase6PublicationTests._copy(self.root,'phase6_publication_controller_runtime.schema.json')
        token=self.root/'synthetic-token';token.write_bytes(b'not a credential')
        release=self.root/'release.json';release.write_text(json.dumps(dict(decision='READY_FOR_PUBLICATION_PIPELINE',blockers=[])))
        actual_write=pub._write
        seen=[]
        actual_collect=retention.collect_completed_caches
        def collect(root):
            seen.append(json.loads((root/pub.CONTROLLER).read_bytes())['status'])
            return actual_collect(root)
        with ExitStack() as stack:
            # Publication/network/quality are the external boundary here; this
            # test does not claim a real upload or revalidate synthetic media.
            for name,value in (
                ('_quality_ready',({'evaluation':{'evaluation_id':'synthetic-quality'}},None)),
                ('refresh_channel_readiness',None),('materialize_phase6_quota_preflight',None),
                ('materialize_phase6_publication_package',self.root/'package.json'),
                ('materialize_phase6_release_gate',release),('_build_live_service',(None,None)),
                ('_record_public_lot',None)):
                stack.enter_context(patch.object(pub,name,return_value=value))
            execute=stack.enter_context(patch.object(pub,'execute_phase6_publication_pipeline'))
            stack.enter_context(patch.object(retention,'collect_completed_caches',side_effect=collect))
            execute.return_value=dict(status='STAGED_PRIVATE',video_id='synthetic-video',privacy_status='private')
            pub.run_phase6_publication_controller(self.root,token_path=token)
            self.assertTrue(self.binary.exists());self.assertEqual([],seen)
            execute.return_value=dict(status='COMPLETE_PUBLIC',video_id='synthetic-video',privacy_status='public')
            value=pub.run_phase6_publication_controller(self.root,token_path=token)
            self.assertEqual('COMPLETE_PUBLIC',value['status'])
            self.assertEqual(['COMPLETE_PUBLIC'],seen)
            self.assertFalse(self.binary.exists())


if __name__=='__main__':
    unittest.main()
