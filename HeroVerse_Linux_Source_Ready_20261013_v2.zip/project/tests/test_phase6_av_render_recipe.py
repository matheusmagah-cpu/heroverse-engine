from __future__ import annotations

import copy
import hashlib
import io
import json
import tempfile
import unittest
import wave
from pathlib import Path

from hero_engine import phase6_av_timeline as av
from hero_engine.phase6_av_render_recipe import (
    AVRenderRecipeError,
    FALSE_AUTHORITY,
    LIVE_TOOLS,
    MIX_POLICY,
    BLUEPRINT_VERSION,
    compile_phase6_av_render_recipe,
    verify_phase6_av_render_recipe,
)
from tests import test_phase6_av_timeline as stage_a


def raw_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def identify(value, field, prefix):
    value.pop(field, None)
    value[field] = prefix + sha(raw_json(value)).split(":", 1)[1][:24]
    return value


def bind(root: Path, path: Path):
    raw = path.read_bytes()
    return {"path": path.relative_to(root).as_posix(), "sha256": sha(raw), "size_bytes": len(raw)}


def write_json(root: Path, relative: str, value):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw_json(value))
    return bind(root, path)


def write_wav(path: Path, *, channels: int, rate: int, frames: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    block = b"\0" * (channels * 2 * min(frames, 65536))
    remaining = frames
    with wave.open(str(path), "wb") as stream:
        stream.setparams((channels, 2, rate, 0, "NONE", "not compressed"))
        while remaining:
            count = min(remaining, 65536)
            stream.writeframesraw(block[: count * channels * 2])
            remaining -= count


class Phase6AVRenderRecipeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name).resolve()
        cls.bindings = stage_a.fixture(cls.root)
        helper = stage_a.StageATests(methodName="test_complete_fixture_uses_51_whole_unit_cues_and_two_spans")
        helper.root, helper.bindings = cls.root, cls.bindings
        cls.arguments = helper.complete()
        cls.timeline = av.build(cls.root, **cls.arguments)
        cls.samples = cls.timeline["duration"]["planned_total_samples"]

        tools = cls.root / "tools"
        tools.mkdir()
        (tools / "ffmpeg.exe").write_bytes(b"fixture ffmpeg")
        (tools / "ffprobe.exe").write_bytes(b"fixture ffprobe")
        for name in ("intent", "normalize-terminal", "measure-intent", "measure-terminal"):
            (cls.root / f"master/{name}.json").parent.mkdir(parents=True, exist_ok=True)
            (cls.root / f"master/{name}.json").write_bytes(raw_json({"fixture": name}))
        master = cls.root / "master/narration.wav"
        write_wav(master, channels=1, rate=24000, frames=cls.samples)
        nested = {}
        for key, name in (("intent", "intent"), ("normalize_terminal", "normalize-terminal"),
                          ("measure_intent", "measure-intent"), ("measure_terminal", "measure-terminal")):
            pin = bind(cls.root, cls.root / f"master/{name}.json")
            nested[key] = {"path": str((cls.root / pin["path"]).resolve()), "sha256": pin["sha256"], "bytes": pin["size_bytes"]}
        master_pin = bind(cls.root, master)
        output = {"path": str(master.resolve()), "sha256": master_pin["sha256"], "bytes": master_pin["size_bytes"]}
        receipt = {
            "status": "NORMALIZATION_PASS_NOT_COMPLETE_AUDIO_APPROVAL",
            "output": output, "raw_output": copy.deepcopy(output),
            "assessment": {"status": "PASS", "checks": {"exact_sample_count": True,
                "no_pcm_extremes": True, "integrated_loudness": True, "true_peak": True},
                "frames": cls.samples, "clipping_samples": 0,
                "scope": "DURATION_LEVELS_PCM_EXTREMES_ONLY_NOT_PERCEPTUAL_OR_RELEASE_QA"},
            "tail": {"removed_zero_samples": 0, "retained_samples": cls.samples},
            "authority": {"queue_authorized": False, "render_authorized": False,
                "publication_authorized": False, "quality_approved": False},
            "technical_cost_brl": 0, **nested,
        }
        cls.master_binding = write_json(cls.root, "output/qa/master/receipt.json", receipt)

        bed_frames = cls.samples * 2
        sfx, music = cls.root / "beds/sfx.wav", cls.root / "beds/music.wav"
        write_wav(sfx, channels=2, rate=48000, frames=bed_frames)
        write_wav(music, channels=2, rate=48000, frames=bed_frames)
        blueprint = {
            "schema_version": "1.0.0", "blueprint_version": BLUEPRINT_VERSION,
            "blueprint_id": "pending", "evidence_mode": "FIXTURE",
            "timeline_id": cls.timeline["timeline_id"],
            "tools": {
                "ffmpeg": {**bind(cls.root, tools / "ffmpeg.exe"), "version": "fixture-1"},
                "ffprobe": {**bind(cls.root, tools / "ffprobe.exe"), "version": "fixture-1"},
            },
            "visual_spans": [{"span_id": row["span_id"], "renderer_version": "fixture-renderer-1",
                              "filtergraph": "scale=1920:1080:flags=lanczos", "dependency_bindings": []}
                             for row in cls.timeline["render_spans"]],
            "audio_beds": {
                "sfx": {"role": "SFX", "binding": bind(cls.root, sfx), "sample_rate": 48000,
                        "channels": 2, "sample_width_bytes": 2, "frame_count": bed_frames},
                "music": {"role": "MUSIC", "binding": bind(cls.root, music), "sample_rate": 48000,
                          "channels": 2, "sample_width_bytes": 2, "frame_count": bed_frames},
            },
            "mix_policy": copy.deepcopy(MIX_POLICY), "authority": copy.deepcopy(FALSE_AUTHORITY),
            "technical_cost_brl": 0,
        }
        identify(blueprint, "blueprint_id", "phase6-av-render-blueprint-")
        cls.blueprint = blueprint
        cls.blueprint_binding = write_json(cls.root, "blueprints/render.json", blueprint)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def compile(self, **changes):
        return compile_phase6_av_render_recipe(
            self.root, changes.get("timeline", self.timeline),
            master_receipt_binding=changes.get("master", self.master_binding),
            render_blueprint_binding=changes.get("blueprint", self.blueprint_binding),
        )

    def test_fixture_compiles_exact_four_stage_graph_without_effect_or_authority(self):
        before = (self.root / "output/production").exists()
        value = self.compile()
        self.assertEqual("COMPILED_FIXTURE_NOT_EXECUTABLE", value["status"])
        self.assertEqual(["SPAN_RENDER", "CONTINUOUS_AUDIO", "MIX", "MUX"],
                         value["command_graph"]["stage_order"])
        self.assertEqual([2, 1, 1, 2], [len(row["commands"]) for row in value["command_graph"]["stages"]])
        self.assertEqual((self.timeline["duration"]["planned_total_frames"], self.samples),
                         (value["command_graph"]["expected_total_frames"],
                          value["command_graph"]["expected_total_samples_24k"]))
        continuous = value["command_graph"]["stages"][1]["commands"][0]["argv"]
        self.assertFalse(any(token in " ".join(continuous) for token in ("atrim", "apad", "acompressor", "atempo")))
        self.assertTrue(all(not Path(row["relative_path"]).is_absolute() and ".." not in Path(row["relative_path"]).parts
                            for row in value["command_graph"]["artifacts"]))
        self.assertFalse(any(value["authority"].values()))
        self.assertIn("FIXTURE_BLUEPRINT_NOT_PRODUCTION_EVIDENCE", value["blockers"])
        self.assertIn("MASTER_AUDIO_NOT_COMPLETE_AUDIO_APPROVAL", value["blockers"])
        self.assertIn("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED", value["blockers"])
        self.assertEqual("SCHEMA_IDENTITY_SOURCE_REHASH_NOT_STAGE_A_RECOMPOSITION",
                         value["timeline"]["verification_scope"])
        self.assertEqual("NORMALIZATION_LEVELS_AND_SAMPLE_COUNT_ONLY",
                         value["inputs"]["master"]["verification_scope"])
        self.assertEqual("VERSIONED_COMPLETE_AUDIO_APPROVAL_REOPENED_BY_STAGE_B",
                         value["inputs"]["master"]["future_integration_requirement"])
        self.assertEqual(before, (self.root / "output/production").exists())

    def test_exact_external_live_tools_are_bound_but_opaque_live_graph_stays_blocked(self):
        changed = copy.deepcopy(self.blueprint)
        changed["evidence_mode"] = "LIVE"
        for role in ("ffmpeg", "ffprobe"):
            expected = LIVE_TOOLS[role]
            path = Path(expected["path"])
            self.assertTrue(path.is_file())
            changed["tools"][role] = {
                "path": expected["path"], "sha256": expected["sha256"],
                "size_bytes": path.stat().st_size, "version": "externally-pinned-local-binary",
            }
        identify(changed, "blueprint_id", "phase6-av-render-blueprint-")
        live = write_json(self.root, "blueprints/live-opaque.json", changed)
        value = self.compile(blueprint=live)
        self.assertEqual("BLOCKED_INCOMPLETE", value["status"])
        self.assertIsNone(value["command_graph"])
        self.assertIn("LIVE_VISUAL_FILTER_COMPILER_RECEIPT_NOT_SUPPORTED", value["blockers"])
        self.assertIn("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED", value["blockers"])
        self.assertFalse(any(value["authority"].values()))
        self.assertFalse(value["publication_authorized"])

        changed["tools"]["ffmpeg"]["sha256"] = "sha256:" + "0" * 64
        identify(changed, "blueprint_id", "phase6-av-render-blueprint-")
        tampered = write_json(self.root, "blueprints/live-tool-tampered.json", changed)
        with self.assertRaisesRegex(AVRenderRecipeError, "authorized external local tool"):
            self.compile(blueprint=tampered)

    def test_replay_recompiles_and_rejects_command_or_dependency_tamper(self):
        value = self.compile()
        replay = verify_phase6_av_render_recipe(
            self.root, value, self.timeline, master_receipt_binding=self.master_binding,
            render_blueprint_binding=self.blueprint_binding, require_command_graph=True)
        self.assertEqual(value, replay)
        changed = copy.deepcopy(value)
        changed["command_graph"]["stages"][0]["commands"][0]["argv"][-1] = "escape.mp4"
        with self.assertRaises(AVRenderRecipeError):
            verify_phase6_av_render_recipe(self.root, changed, self.timeline,
                master_receipt_binding=self.master_binding, render_blueprint_binding=self.blueprint_binding)
        source = self.root / self.timeline["render_spans"][0]["asset_binding"]["path"]
        original = source.read_bytes()
        try:
            source.write_bytes(original + b"tamper")
            with self.assertRaisesRegex(AVRenderRecipeError, "source binding"):
                self.compile()
        finally:
            source.write_bytes(original)

    def test_missing_blueprint_or_master_is_explicitly_blocked(self):
        for key, expected in (("blueprint", "RENDER_BLUEPRINT_BINDING_MISSING"),
                              ("master", "MASTER_RECEIPT_BINDING_MISSING")):
            args = {key: None}
            value = self.compile(**args)
            self.assertEqual("BLOCKED_INCOMPLETE", value["status"])
            self.assertIsNone(value["command_graph"])
            self.assertIn(expected, value["blockers"])
            self.assertIn("COMMAND_GRAPH_NOT_COMPILED", value["blockers"])

    def test_timeline_drift_omission_and_master_tail_fail_closed(self):
        for mutation in (
            lambda value: value["duration"].update(planned_total_samples=value["duration"]["planned_total_samples"] + 1),
            lambda value: value["narration_fragment_map"].pop(),
        ):
            changed = copy.deepcopy(self.timeline)
            mutation(changed)
            with self.assertRaises(AVRenderRecipeError):
                self.compile(timeline=changed)
        receipt_path = self.root / self.master_binding["path"]
        original = receipt_path.read_bytes()
        changed = json.loads(original)
        changed["tail"]["retained_samples"] -= 1
        receipt_path.write_bytes(raw_json(changed))
        rebound = bind(self.root, receipt_path)
        try:
            with self.assertRaisesRegex(AVRenderRecipeError, "sample accounting"):
                self.compile(master=rebound)
        finally:
            receipt_path.write_bytes(original)

    def test_blueprint_mutation_duplicate_span_and_path_escape_fail(self):
        changed = copy.deepcopy(self.blueprint)
        changed["visual_spans"][0]["filtergraph"] = "scale=1280:720"
        bad = write_json(self.root, "blueprints/mutated.json", changed)
        with self.assertRaisesRegex(AVRenderRecipeError, "identity"):
            self.compile(blueprint=bad)
        changed = copy.deepcopy(self.blueprint)
        changed["visual_spans"][1]["span_id"] = changed["visual_spans"][0]["span_id"]
        identify(changed, "blueprint_id", "phase6-av-render-blueprint-")
        duplicate = write_json(self.root, "blueprints/duplicate.json", changed)
        with self.assertRaisesRegex(AVRenderRecipeError, "duplicated"):
            self.compile(blueprint=duplicate)
        outside = self.root.parent / (self.root.name + "-outside.json")
        outside.write_bytes(b"x")
        escaped = {"path": str(outside.resolve()), "sha256": sha(b"x"), "size_bytes": 1}
        try:
            with self.assertRaisesRegex(AVRenderRecipeError, "escaped"):
                self.compile(blueprint=escaped)
        finally:
            outside.unlink(missing_ok=True)

    def test_strict_json_rejects_duplicate_keys_and_nan(self):
        path = self.root / "blueprints/noncanonical.json"
        for raw in (b'{"schema_version":"1.0.0","schema_version":"1.0.0"}', b'{"x":NaN}'):
            path.write_bytes(raw)
            binding = bind(self.root, path)
            with self.assertRaises(AVRenderRecipeError):
                self.compile(blueprint=binding)


if __name__ == "__main__":
    unittest.main()
