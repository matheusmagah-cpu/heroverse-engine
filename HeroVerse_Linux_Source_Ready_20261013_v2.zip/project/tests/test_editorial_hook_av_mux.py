"""Synthetic FIXTURE logic only. No FFmpeg, FFprobe, ASR, or media execution."""
from __future__ import annotations

import copy
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
import wave

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "output/qa/phase6/diagnostics/mux_editorial_hook_av_v1.py"
spec = importlib.util.spec_from_file_location("hook_av_mux_under_test", SOURCE)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def probe(output=False):
    streams = [{"index": 0, "codec_type": "video", "codec_name": "ffv1", "width": 1920,
                "height": 1080, "r_frame_rate": "30/1", "avg_frame_rate": "30/1", "time_base": "1/1000"}]
    if output:
        streams.append({"index": 1, "codec_type": "audio", "codec_name": "pcm_s16le",
                        "sample_rate": "24000", "channels": 1, "sample_fmt": "s16", "time_base": "1/1000"})
    packets = [{"stream_index": 0, "pts": (i*1000+15)//30, "dts": (i*1000+15)//30,
                "duration": 33, "size": str(100+i), "data_hash": "SHA256:"+f"{i:064x}"} for i in range(150)]
    if output:
        packets.append({"stream_index": 1, "pts": 0, "dts": 0, "duration": 5000,
                        "size": "240000", "data_hash": "SHA256:"+"f"*64})
    return {"streams": streams, "packets": packets}


class EditorialHookMuxTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hook-av-fixture-")
        self.folder = Path(self.temp.name)
        self.h = m.helper()
        self.recipe = {"evidence_mode": "FIXTURE", "policy": m.resources()}
        self.h.save(self.folder/"recipe.json", self.recipe)
        self.source = self.folder/"origem-ação.bin"
        self.source.write_bytes(b"FIXTURE ONLY")
        self.deps = [self.h.bind(self.source)]
        self.calls = []

    def tearDown(self):
        self.temp.cleanup()

    def effect(self, argv, timeout):
        self.calls.append((argv, timeout))
        return b"fixture stdout", {"pid": 12345, "returncode": 0, "timeout": False, "stderr": ""}

    def stage(self, **kwargs):
        return m.native_stage(self.h, self.folder, self.recipe, "source-probe", ["FIXTURE_ONLY"], self.deps,
                              fixture_native=self.effect, fixture_capacity=lambda *a: {"status": "PASS_FIXTURE"}, **kwargs)

    def test_fixed_commands_use_stream_copy_whole_hook_trim_and_no_hidden_transform(self):
        commands = m.commands(self.folder)
        self.assertEqual(list(m.STAGES), list(commands))
        mux = commands["mux"]
        self.assertEqual("copy", mux[mux.index("-c:v")+1])
        self.assertEqual("pcm_s16le", mux[mux.index("-c:a")+1])
        self.assertIn("[1:a:0]atrim=start_sample=72000:end_sample=192000,asetpts=PTS-STARTPTS[a]", mux)
        self.assertTrue(all(x not in " ".join(mux) for x in ("-shortest", "loudnorm", "atempo", "apad", "aresample")))
        self.assertTrue(all(command[command.index("-threads")+1] == "1" for command in commands.values()))
        for name in ("source-probe", "output-probe"):
            self.assertIn("-show_data_hash", commands[name])
            self.assertIn("-show_packets", commands[name])
        self.assertNotIn("-ar", commands["output-pcm"])
        self.assertNotIn("-ac", commands["output-pcm"])

    def test_disk_budget_depends_on_full_visual_not_asr_budget(self):
        r = m.resources()["resources"]
        self.assertEqual(512*1024**2, r["minimum_available_ram_bytes"])
        self.assertEqual(5*1024**3, r["disk_reserve_bytes"])
        self.assertGreater(r["new_disk_budget_bytes"], 2*m.VIDEO_BYTES)
        self.assertEqual(2, m.resources(m.VIDEO_BYTES+1)["resources"]["new_disk_budget_bytes"]-r["new_disk_budget_bytes"])
        with self.assertRaises(ValueError):
            m.resources(True)

    def test_packet_clock_and_payload_normalization(self):
        self.assertEqual(m.video_packets(probe(), output=False), m.video_packets(probe(True), output=True))
        altered = probe(True)
        altered["packets"][74]["data_hash"] = "SHA256:"+"a"*64
        self.assertNotEqual(m.video_packets(probe(), output=False), m.video_packets(altered, output=True))

    def test_packet_negatives_missing_hash_pts_count_format_and_audio(self):
        edits = [lambda p:p["packets"].pop(), lambda p:p["packets"][0].pop("data_hash"),
                 lambda p:p["packets"][1].update(pts=0), lambda p:p["packets"][0].update(dts=None),
                 lambda p:p["packets"][0].update(duration=0), lambda p:p["packets"][0].update(size="0"),
                 lambda p:p["streams"][0].update(width=1080), lambda p:p["streams"][0].update(avg_frame_rate="25/1")]
        for edit in edits:
            p = probe(); edit(p)
            with self.subTest(edit=edit), self.assertRaises((ValueError, KeyError)):
                m.video_packets(p, output=False)
        p = probe(True); p["streams"][1]["channels"] = 2
        with self.assertRaises(ValueError):
            m.video_packets(p, output=True)

    def test_audio_pcm_identity_cannot_hide_packet_delay_or_wrong_endpoint(self):
        for changes in ({"pts": 100, "dts": 100}, {"dts": 1}, {"duration": 4990}, {"size": "239998"}):
            p = probe(True); p["packets"][-1].update(changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                m.video_packets(p, output=True)
        p = probe(True)
        p["packets"][-1:] = [
            {"stream_index": 1, "pts": 0, "dts": 0, "duration": 42, "size": "2048"},
            {"stream_index": 1, "pts": 43, "dts": 43, "duration": 4957, "size": "237952"},
        ]
        self.assertEqual(120000, m.audio_clock(p)["sample_count_from_packet_bytes"])

    def test_pcm_format_and_length_are_exact(self):
        b = io.BytesIO()
        with wave.open(b, "wb") as w:
            w.setparams((1, 2, 24000, 4, "NONE", "not compressed")); w.writeframes(b"\x01\x00"*4)
        self.assertEqual(b"\x01\x00"*4, m.pcm(b.getvalue(), 4))
        for raw, frames in ((b.getvalue(), 3), (b.getvalue()[:-2], 4)):
            with self.assertRaises(ValueError):
                m.pcm(raw, frames)

    def test_completed_stage_replays_without_repeating_effect(self):
        first = self.stage()
        self.assertEqual(1, len(self.calls))
        self.assertEqual(first, self.stage(replay=True))
        self.assertEqual(1, len(self.calls))

    def test_input_and_capture_tampering_block_before_recollection(self):
        self.stage()
        self.source.write_bytes(b"altered")
        with self.assertRaises(ValueError):
            self.stage()
        self.assertEqual(1, len(self.calls))
        self.source.write_bytes(b"FIXTURE ONLY")
        (self.folder/"source-probe-stdout.bin").write_bytes(b"forged")
        with self.assertRaises(ValueError):
            self.stage(replay=True)
        self.assertEqual(1, len(self.calls))

    def test_intent_without_terminal_blocks_no_retry(self):
        self.h.save(self.folder/"source-probe-intent.json", {"FIXTURE": "crash after intent"})
        with self.assertRaisesRegex(ValueError, "orphan/uncertain"):
            self.stage()
        self.assertEqual([], self.calls)

    def test_orphan_artifact_and_replay_missing_stage_block(self):
        orphan = self.folder/"orphan.mkv"; orphan.write_bytes(b"FIXTURE")
        with self.assertRaisesRegex(ValueError, "orphan/uncertain"):
            self.stage(artifact=orphan)
        with self.assertRaisesRegex(ValueError, "orphan/uncertain"):
            self.stage(replay=True)
        self.assertEqual([], self.calls)

    def test_captured_artifact_checkpoint_reused_and_tamper_rejected(self):
        target = self.folder/"fixture.mkv"
        def effect(argv, timeout):
            target.write_bytes(b"FIXTURE_VIDEO"); return self.effect(argv, timeout)
        kwargs = dict(artifact=target, fixture_native=effect, fixture_capacity=lambda *a:{"status":"PASS_FIXTURE"})
        run = lambda: m.native_stage(self.h, self.folder, self.recipe, "mux", ["FIXTURE"], self.deps, **kwargs)
        first = run(); self.assertEqual(first, run()); self.assertEqual(1, len(self.calls))
        target.write_bytes(b"WRONG")
        with self.assertRaises(ValueError):
            run()
        self.assertEqual(1, len(self.calls))

    def test_timeout_captured_and_never_repeated(self):
        def timeout(argv, seconds):
            self.calls.append(argv)
            return b"", {"pid": 99, "returncode": -1, "timeout": True, "stderr": "FIXTURE timeout"}
        for i in range(2):
            with self.assertRaisesRegex(ValueError, "stage failed"):
                m.native_stage(self.h, self.folder, self.recipe, "source-probe", ["FIXTURE"], self.deps,
                    fixture_native=timeout, fixture_capacity=lambda *a:{"status":"PASS_FIXTURE"})
        self.assertEqual(1, len(self.calls))
        self.assertTrue((self.folder/"source-probe-terminal.json").is_file())

    def test_fixture_callback_cannot_create_live_qa(self):
        self.recipe["evidence_mode"] = "LIVE_QA"
        with self.assertRaisesRegex(ValueError, "cannot produce LIVE_QA"):
            self.stage()
        self.assertEqual([], self.calls)

    def test_owned_helper_timeout_terminates_only_its_child_no_shell_hidden(self):
        calls = []
        class Child:
            pid = 54321
            returncode = None
            def communicate(self, timeout):
                calls.append(("communicate", timeout))
                if self.returncode is None:
                    raise subprocess.TimeoutExpired("FIXTURE", timeout)
                return b"", b""
            def terminate(self):
                calls.append(("terminate", self.pid)); self.returncode = -1
            def kill(self):
                calls.append(("kill", self.pid)); self.returncode = -9
            def poll(self): return self.returncode
        def popen(argv, **kwargs):
            self.assertFalse(kwargs["shell"])
            self.assertEqual(getattr(subprocess, "CREATE_NO_WINDOW", 0), kwargs["creationflags"])
            return Child()
        _, terminal = self.h.owned(["FIXTURE"], 45, popen=popen)
        self.assertTrue(terminal["timeout"])
        self.assertIn(("terminate", 54321), calls)

    def test_binary_owned_lock_excludes_parallel_and_preserves_foreign(self):
        with m.lock(self.folder, self.h):
            raw = (self.folder/"execution.lock").read_bytes()
            self.assertNotIn(b"\r\n", raw)
            with self.assertRaises(FileExistsError):
                with m.lock(self.folder, self.h):
                    self.fail("second lock acquired")
        self.assertFalse((self.folder/"execution.lock").exists())
        with self.assertRaisesRegex(ValueError, "changed; preserved"):
            with m.lock(self.folder, self.h):
                (self.folder/"execution.lock").write_bytes(b"foreign")
        self.assertEqual(b"foreign", (self.folder/"execution.lock").read_bytes())


if __name__ == "__main__":
    unittest.main()
