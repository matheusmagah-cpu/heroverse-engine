"""Isolated byte-profile fixtures: no real runtime imports or executable launches."""
from __future__ import annotations

import base64
import builtins
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_publicity_runtime as R


class RuntimeFileProfileTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="publicity-runtime-FIXTURE-")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name) / "project"
        self.base = Path(temp.name) / "base-python"
        self.ffmpeg = Path(temp.name) / "ffmpeg"
        self.site = self.root / ".venv/Lib/site-packages"
        self.module = self.root / "runtime-module.fixture.py"
        self.write(self.module, b"# DECLARED FILE IDENTITY FIXTURE, NOT A WORKER\n")
        self.patch = patch.multiple(R, CODE_ROOT=self.root, BASE_PYTHON=self.base,
                                    FFMPEG_DIRECTORY=self.ffmpeg, MODULE_PATH=self.module)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        for name in R.BASE_FILES:
            self.write(self.base / name, b"FIXTURE_NOT_EXECUTABLE_" + name.encode())
        self.write(self.base / "Lib/os.py", b"# FIXTURE STDLIB\n")
        self.write(self.base / "Lib/site-packages/not_selected.py", b"EXCLUDED_BASE_SITE_FIXTURE")
        self.write(self.base / "DLLs/example.pyd", b"FIXTURE_NOT_NATIVE")
        self.write(self.ffmpeg / "bin/ffmpeg.exe", b"FIXTURE_NOT_FFMPEG")
        self.write(self.ffmpeg / "bin/ffprobe.exe", b"FIXTURE_NOT_FFPROBE")
        self.write(self.ffmpeg / "LICENSE.txt", b"FIXTURE_LICENSE_TEXT_NOT_LEGAL_PROOF")
        self.write(self.root / ".venv/pyvenv.cfg",
                   f"home = {self.base}\nexecutable = {self.base / 'python.exe'}\ninclude-system-site-packages = false\nversion = FIXTURE\n".encode())
        for name in ("python.exe", *R.NUMPY_SCRIPTS):
            self.write(self.root / ".venv/Scripts" / name, b"FIXTURE_NOT_LAUNCHABLE")
        for name, content in {
            "cv2/__init__.py": b"# NOT IMPORTED CV2 FIXTURE\n",
            "cv2/cv2.pyd": b"FAKE_NATIVE_NEVER_LOAD",
            "cv2/__pycache__/__init__.cpython-312.pyc": b"FAKE_CACHE_NEVER_LOAD",
            "numpy/__init__.py": b"",  # Real empty regular modules are permitted in a byte inventory.
            "numpy/_core/_multiarray_umath.pyd": b"FAKE_NUMPY_NATIVE",
            "numpy.libs/example.dll": b"FAKE_DLL",
        }.items():
            self.write(self.site / name, content)
        for dist, (name, version, _) in R.DISTRIBUTIONS.items():
            directory = self.site / dist
            self.write(directory / "METADATA", f"Metadata-Version: 2.4\nName: {name}\nVersion: {version}\nLicense-File: LICENSE.txt\n\n".encode())
            self.write(directory / "LICENSE.txt", b"FIXTURE_LICENSE_ONLY")
            self.write(directory / "WHEEL", b"Wheel-Version: 1.0\n")
            self.write(directory / "INSTALLER", b"FIXTURE\n")
        self.records()
        original_import = builtins.__import__
        def reject_media(name, *args, **kwargs):
            if name.split(".")[0] in {"cv2", "numpy", "PIL"}:
                raise AssertionError("MEDIA_RUNTIME_IMPORT_FORBIDDEN")
            return original_import(name, *args, **kwargs)
        for context in (patch("builtins.__import__", side_effect=reject_media),
                        patch.object(subprocess, "Popen", side_effect=AssertionError("PROCESS_FORBIDDEN")),
                        patch.object(subprocess, "run", side_effect=AssertionError("PROCESS_FORBIDDEN"))):
            context.start()
            self.addCleanup(context.stop)

    @staticmethod
    def write(path, raw):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def records(self):
        for dist, (name, _, packages) in R.DISTRIBUTIONS.items():
            directory = self.site / dist
            paths = [path for prefix in (*packages, dist) for path in (self.site / prefix).rglob("*")
                     if path.is_file() and path.name != "RECORD"]
            rows = []
            for path in sorted(paths):
                relative = path.relative_to(self.site).as_posix()
                raw = path.read_bytes()
                if path.suffix == ".pyc":
                    rows.append(f"{relative},,")
                else:
                    digest = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip("=")
                    rows.append(f"{relative},sha256={digest},{len(raw)}")
            if name == "numpy":
                for script in R.NUMPY_SCRIPTS:
                    raw = (self.root / ".venv/Scripts" / script).read_bytes()
                    digest = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip("=")
                    rows.append(f"../../Scripts/{script},sha256={digest},{len(raw)}")
            rows.append(f"{dist}/RECORD,,")
            self.write(directory / "RECORD", ("\n".join(rows) + "\n").encode())

    def saved(self, profile):
        raw = R._canonical(profile)
        path = self.root / "output/profile.fixture.json"
        self.write(path, raw)
        return {"path": str(path), "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}

    def profile(self):
        return R.build_profile(self.root)["profile"]

    def test_deterministic_capture_validation_and_no_effects(self):
        first = R.build_profile(self.root)
        self.assertEqual(R._canonical(first["profile"]), R._canonical(self.profile()))
        binding = self.saved(first["profile"])
        before = {str(path): (path.read_bytes(), path.stat().st_mtime_ns)
                  for path in Path(self.root.parent).rglob("*") if path.is_file()}
        report = R.validate_profile(self.root, profile_binding=binding)
        after = {str(path): (path.read_bytes(), path.stat().st_mtime_ns)
                 for path in Path(self.root.parent).rglob("*") if path.is_file()}
        self.assertEqual(before, after)
        self.assertEqual(report["status"], "FILE_PROFILE_VALIDATED_NOT_ADMITTED")
        self.assertFalse(any(report["authority"].values()))
        self.assertEqual([report[key] for key in ("decode_calls", "inference_calls", "process_calls", "files_written")], [0] * 4)
        self.assertGreater(report["measurement"]["streamed_bytes_including_rechecks"], 0)
        rows = first["profile"]["file_bindings"]
        self.assertTrue(any("__pycache__" in row["path"] for row in rows))
        self.assertTrue(any(row["size_bytes"] == 0 for row in rows))
        self.assertEqual(len(first["profile"]["distribution_records"]), 2)

    def test_arbitrary_paths_authority_cost_and_extra_keys_rejected_before_hashing_runtime(self):
        base = self.profile()
        for key, value in (("base_python", str(self.root)), ("site_packages", "C:/foreign"),
                           ("ffmpeg_directory", "C:/foreign"), ("authority", {}),
                           ("technical_cost_brl", False), ("new_field", "not allowed")):
            with self.subTest(key=key):
                candidate = deepcopy(base)
                candidate[key] = value
                bound = self.saved(candidate)
                with patch.object(R, "_compose", side_effect=AssertionError("RUNTIME_READ_FORBIDDEN")), self.assertRaises(R.RuntimeProfileError):
                    R.validate_profile(self.root, profile_binding=bound)

    def test_duplicate_missing_extra_reordered_candidate_population_rejected_early(self):
        base = self.profile()
        for operation in ("duplicate", "missing", "extra", "reordered"):
            candidate = deepcopy(base)
            rows = candidate["population"]["files"]
            if operation == "duplicate": rows.append(rows[0])
            elif operation == "missing": rows.pop()
            elif operation == "extra": rows.append(["C:/foreign/not-read", 128])
            else: rows.reverse()
            with self.subTest(operation=operation), patch.object(R, "_compose", side_effect=AssertionError("RUNTIME_READ_FORBIDDEN")), self.assertRaises(R.RuntimeProfileError):
                R.validate_profile(self.root, profile_binding=self.saved(candidate))

    def test_external_profile_hash_types_duplicates_and_nonfinite_rejected(self):
        bound = self.saved(self.profile())
        for mutation in ({"sha256": "sha256:" + "0" * 64}, {"size_bytes": True}, {"extra": False}):
            with self.subTest(mutation=mutation), self.assertRaises(R.RuntimeProfileError):
                R.validate_profile(self.root, profile_binding={**bound, **mutation})
        for raw in (b'{"kind":1,"kind":2}', b'{"x":NaN}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                R._json(raw)

    def test_missing_license_and_version_mismatch_fail(self):
        directory = self.site / "numpy-2.5.2.dist-info"
        license_path = directory / "LICENSE.txt"
        original = license_path.read_bytes()
        license_path.unlink()
        with self.assertRaises(R.RuntimeProfileError):
            self.profile()
        self.write(license_path, original)
        metadata = directory / "METADATA"
        self.write(metadata, metadata.read_bytes().replace(b"2.5.2", b"9.9.9"))
        self.records()  # A self-consistent altered RECORD is not the fixed distribution version.
        with self.assertRaisesRegex(R.RuntimeProfileError, "identity/version"):
            self.profile()

    def test_optional_import_path_or_extra_distribution_cannot_be_captured(self):
        for path in (self.site / "numpy/_distributor_init_local.py", self.base / "python312.zip",
                     self.root / ".venv/Lib/x64/vc17/bin", self.site / "opencv_python-9.0.dist-info"):
            with self.subTest(path=path):
                self.write(path, b"UNAPPROVED_OPTIONAL_FILE")
                with self.assertRaises(R.RuntimeProfileError):
                    self.profile()
                path.unlink()

    def test_record_duplicate_escape_wrong_hash_and_missing_file_block(self):
        path = self.site / "opencv_python-5.0.0.93.dist-info/RECORD"
        original = path.read_bytes()
        for tail in (original.splitlines()[0] + b"\n", b"../foreign.py,,\n", b"cv2/missing.py,,\n", b"cv2/./alias.py,,\n"):
            with self.subTest(tail=tail):
                self.write(path, original + tail)
                with self.assertRaises(R.RuntimeProfileError):
                    self.profile()
        self.write(path, original)
        self.write(self.site / "cv2/cv2.pyd", b"ALTERED_NATIVE_BYTES")
        with self.assertRaisesRegex(R.RuntimeProfileError, "contradicts RECORD"):
            self.profile()

    def test_unrecorded_code_rejected_but_observed_cache_is_explicit(self):
        self.write(self.site / "cv2/extra.py", b"UNRECORDED_CODE")
        with self.assertRaisesRegex(R.RuntimeProfileError, "unrecorded non-cache"):
            self.profile()
        (self.site / "cv2/extra.py").unlink()
        cache = self.site / "cv2/__pycache__/new.cpython-312.pyc"
        self.write(cache, b"OBSERVED_LOCAL_CACHE_NOT_EXECUTED_OR_UPSTREAM_AUTHENTICATED")
        profile = self.profile()
        cv_record = next(row for row in profile["distribution_records"] if row["name"] == "opencv-python")
        self.assertEqual(cv_record["locally_observed_unrecorded_caches"], [str(cache)])

    def test_final_inventory_or_bytes_drift_blocks(self):
        original = R._Files.recheck
        target = self.site / "cv2/__init__.py"
        for kind in ("bytes", "inventory"):
            old = target.read_bytes()
            added = self.site / "cv2/added.txt"
            def drift(reader):
                if kind == "bytes": target.write_bytes(b"CHANGED_AFTER_PROFILE")
                else: added.write_bytes(b"NEW_AFTER_INVENTORY")
                original(reader)
            with self.subTest(kind=kind), patch.object(R._Files, "recheck", drift), self.assertRaises(R.RuntimeProfileError):
                self.profile()
            target.write_bytes(old)
            if added.exists(): added.unlink()

    def test_stream_is_bounded_and_returned_buffer_is_the_authenticated_buffer(self):
        path = self.root / "read.fixture"
        self.write(path, b"123456")
        with self.assertRaises(R.RuntimeProfileError):
            R._Files().read(path, cap=5)
        files = R._Files()
        raw = files.read(path, cap=20, capture=True)
        self.assertEqual(files.items[str(path)][0]["sha256"], "sha256:" + hashlib.sha256(raw).hexdigest())
        self.write(path, b"654321")
        with self.assertRaises(R.RuntimeProfileError):
            files.recheck()

    def test_traversal_hardlink_and_nonresident_paths_fail(self):
        with self.assertRaises(R.RuntimeProfileError):
            R._resident(self.root / ".." / "project")
        path = self.root / "hardlink-source.fixture"
        alias = self.root / "hardlink-alias.fixture"
        self.write(path, b"EXPLICIT_FIXTURE")
        os.link(path, alias)
        with self.assertRaises(R.RuntimeProfileError):
            R._Files().read(path, cap=100)
        real_lstat = Path.lstat
        def offline(candidate, *args, **kwargs):
            observed = real_lstat(candidate, *args, **kwargs)
            if candidate == self.module:
                class StatFixture:
                    st_mode = observed.st_mode
                    st_file_attributes = 0x1000
                return StatFixture()
            return observed
        with patch.object(Path, "lstat", offline), self.assertRaises(R.RuntimeProfileError):
            R._resident(self.module)

    def test_base_site_packages_are_explicitly_excluded_not_declared_authenticated(self):
        profile = self.profile()
        self.assertNotIn(str(self.base / "Lib/site-packages/not_selected.py"), [row["path"] for row in profile["file_bindings"]])
        self.assertFalse(profile["future_worker_constraints"]["base_site_packages_allowed"])
        self.assertFalse(profile["future_worker_constraints"]["actual_module_origins_observed"])
        self.assertIn("-S", profile["future_worker_constraints"]["required_flags"])


if __name__ == "__main__":
    unittest.main()
