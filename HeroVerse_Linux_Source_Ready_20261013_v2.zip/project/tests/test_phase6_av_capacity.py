"""Focal tests for the projected continuous-AV capacity contract.

Stage C has no executable recipe yet, so every receipt is BLOCKED.  Fake
executables and caller-controlled observations never acquire LIVE status, media
authority, or queue access.
"""
from __future__ import annotations

import copy
import inspect
import json
import os
import shutil
import tempfile
import unittest
from unittest import mock
from collections import namedtuple
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

from hero_engine import phase6_av_timeline as av
from hero_engine.phase6_av_capacity import (
    AVCapacityError,
    FALSE_AUTHORITY,
    MINIMUM_POST_RENDER_HEADROOM_BYTES,
    RECEIPTS,
    _effective_evidence,
    _strict_writable_check,
    _validate,
    build_phase6_av_capacity_recipe,
    run_phase6_av_capacity_preflight,
    verify_phase6_av_capacity_receipt,
)
from hero_engine.phase6_narration_units import bytes_sha, canonical_sha
from hero_engine.render_creative_v2_phase5 import _font
from tests import test_phase6_av_timeline as stage_a


ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 9, 6, 16, 0, tzinfo=timezone.utc)
Disk = namedtuple("Disk", "total used free")


def identify(value, field, prefix):
    value.pop(field, None)
    value[field] = prefix + canonical_sha(value).split(":", 1)[1][:24]
    return value


def dump(root: Path, relative: str, value: dict) -> dict:
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    path.write_bytes(raw)
    return {"path": relative, "sha256": bytes_sha(raw), "size_bytes": len(raw)}


class FakeTools:
    def __init__(self, *, codecs=True, encoder_output=None):
        self.calls = []
        self.codecs = codecs
        self.encoder_output = encoder_output

    def __call__(self, command, **_kwargs):
        self.calls.append(list(command))
        name = Path(command[0]).name
        if command[-1] == "-version":
            return SimpleNamespace(returncode=0, stdout=f"{name} version fixture-1\n", stderr="")
        if command[-2:] == ["-hide_banner", "-encoders"]:
            output = self.encoder_output
            if output is None:
                output = " V..... libx264 H.264\n A..... aac AAC\n A..... pcm_s16le PCM\n" if self.codecs else " V..... rawvideo raw\n"
            return SimpleNamespace(returncode=0, stdout=output, stderr="")
        raise AssertionError(f"unexpected tool command: {command}")


def abundant(_path):
    return Disk(100 * 1024**3, 50 * 1024**3, 50 * 1024**3)


class ContinuousAVCapacityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name).resolve()
        cls.bindings = stage_a.fixture(cls.root)
        helper = stage_a.StageATests(methodName="test_complete_fixture_uses_51_whole_unit_cues_and_two_spans")
        helper.root, helper.bindings = cls.root, cls.bindings
        cls.arguments = helper.complete()
        cls.timeline = av.build(cls.root, **cls.arguments)

        raw = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_RAW_ARGUMENTS",
            "evidence_mode": "FIXTURE", "channel_id": cls.timeline["channel_id"],
            "video_id": cls.timeline["video_id"], "protocol_id": cls.timeline["protocol_id"],
            "arguments": copy.deepcopy(cls.arguments), "authority": copy.deepcopy(FALSE_AUTHORITY),
            "technical_cost_brl": 0,
        }
        identify(raw, "arguments_id", "phase6-av-arguments-")
        cls.arguments_binding = dump(
            cls.root,
            f"output/operations/phase6/av-admission/arguments/{raw['arguments_id']}.json",
            raw,
        )
        cls.timeline_binding = dump(
            cls.root,
            f"output/operations/phase6/av-admission/timelines/{cls.timeline['timeline_id']}.json",
            cls.timeline,
        )

        # Independent copies retain the exact model bytes without giving the
        # fixture a writable alias to the operational model's filesystem object.
        for relative in ("models/kokoro/kokoro-v1.0.fp16.onnx", "models/kokoro/voices-v1.0.bin"):
            target = cls.root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, target)
        for relative in (
            "schemas/phase6_av_capacity.schema.json", "hero_engine/phase6_av_capacity.py",
            "hero_engine/production_capacity.py", "hero_engine/atomic_io.py",
        ):
            target = cls.root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, target)
        cls.ffmpeg = cls.root / "tools/ffmpeg-fixture.exe"
        cls.ffprobe = cls.root / "tools/ffprobe-fixture.exe"
        cls.ffmpeg.parent.mkdir(parents=True, exist_ok=True)
        cls.ffmpeg.write_bytes(b"fixture-ffmpeg-not-executable-outside-injected-runner")
        cls.ffprobe.write_bytes(b"fixture-ffprobe-not-executable-outside-injected-runner")

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_fixture(self, *, runner=None, disk=abundant, at=NOW):
        return run_phase6_av_capacity_preflight(
            self.root, timeline_binding=self.timeline_binding,
            arguments_binding=self.arguments_binding, now=at,
            disk_usage_provider=disk, command_runner=runner or FakeTools(),
            ffmpeg_path=self.ffmpeg, ffprobe_path=self.ffprobe,
            font_provider=_font,
        )

    def receipt_path(self, value):
        return self.root / RECEIPTS / f"{value['receipt_id']}.json"

    def test_recipe_is_integer_recomposition_not_caller_estimate(self):
        recipe = build_phase6_av_capacity_recipe(self.timeline)
        self.assertNotIn("estimated_peak_new_bytes", inspect.signature(build_phase6_av_capacity_recipe).parameters)
        self.assertEqual(51, len(self.timeline["units"]))
        self.assertEqual(90, len(self.timeline["narration_fragment_map"]))
        self.assertEqual(
            recipe["estimated_peak_new_bytes"] + MINIMUM_POST_RENDER_HEADROOM_BYTES,
            recipe["required_free_bytes"],
        )
        self.assertEqual(
            recipe["retained_component_bytes"] + recipe["atomic_duplicate_bytes"] + recipe["contingency_bytes"],
            recipe["estimated_peak_new_bytes"],
        )
        self.assertEqual(
            ["visual_span_intermediates", "silent_concatenated_video", "continuous_narration_pcm",
             "sfx_pcm_bed", "music_pcm_bed", "final_muxed_output", "captions_manifests_and_checkpoints"],
            [row["component"] for row in recipe["storage_components"]],
        )
        self.assertEqual("PROJECTED_UNBOUND_TO_EXECUTOR", recipe["classification"])
        self.assertNotIn("working_bitrate_ceiling_bps", recipe["video"])
        self.assertIn("working_bitrate_accounting_assumption_bps", recipe["video"])

    def test_fixture_executes_tools_and_replays_but_remains_recipe_blocked(self):
        runner = FakeTools()
        value = self.run_fixture(runner=runner)
        self.assertEqual("BLOCKED", value["status"])
        self.assertEqual("FIXTURE", value["evidence_mode"])
        self.assertIn("AVC-EXECUTABLE-RECIPE", value["blocking_reasons"])
        self.assertEqual("PROJECTED_UNBOUND_TO_EXECUTOR", value["execution_readiness"]["status"])
        self.assertFalse(value["execution_readiness"]["command_recipe_bound"])
        self.assertFalse(value["execution_readiness"]["visual_source_decode_and_frame_count_verified"])
        self.assertEqual(FALSE_AUTHORITY, value["authority"])
        self.assertEqual(3, len(runner.calls))
        path = self.receipt_path(value)
        result = verify_phase6_av_capacity_receipt(
            self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
            expected_sha256=bytes_sha(path.read_bytes()), now=NOW + timedelta(seconds=1),
            require_live=False, reobserve=True, disk_usage_provider=abundant,
            command_runner=FakeTools(),
        )
        self.assertTrue(result["reobservation"]["performed"])
        with self.assertRaisesRegex(AVCapacityError, "requires full reobservation"):
            verify_phase6_av_capacity_receipt(
                self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
                expected_sha256=bytes_sha(path.read_bytes()), now=NOW + timedelta(seconds=1),
                require_live=True, reobserve=False,
            )

    def test_stage_a_mode_ignores_raw_claim_and_probe_overrides_force_fixture(self):
        live_stage_a = {"temporal_evidence_assessment": {
            "all_required_evidence_live": True,
            "fixture_evidence_present": False,
            "evidence_classes": ["LIVE"],
        }}
        mode, basis = _effective_evidence(live_stage_a, {"evidence_mode": "FIXTURE"}, [])
        self.assertEqual("LIVE", mode)
        self.assertEqual("FIXTURE", basis["raw_arguments_claim_ignored"])
        mode, basis = _effective_evidence(
            live_stage_a, {"evidence_mode": "LIVE"}, ["COMMAND_RUNNER"]
        )
        self.assertEqual("FIXTURE", mode)
        self.assertEqual("CALLER_OVERRIDES_FIXTURE_ONLY", basis["probe_mode"])

        raw = json.loads((self.root / self.arguments_binding["path"]).read_text(encoding="utf-8"))
        raw["evidence_mode"] = "LIVE"
        identify(raw, "arguments_id", "phase6-av-arguments-")
        live_claim = dump(
            self.root,
            f"output/operations/phase6/av-admission/arguments/{raw['arguments_id']}.json",
            raw,
        )
        value = run_phase6_av_capacity_preflight(
            self.root, timeline_binding=self.timeline_binding, arguments_binding=live_claim,
            now=NOW + timedelta(seconds=2), disk_usage_provider=abundant,
            command_runner=FakeTools(), ffmpeg_path=self.ffmpeg,
            ffprobe_path=self.ffprobe, font_provider=_font,
        )
        self.assertEqual("LIVE", value["evidence_basis"]["raw_arguments_claim_ignored"])
        self.assertEqual("FIXTURE", value["evidence_basis"]["stage_a_verified_mode"])
        self.assertEqual("FIXTURE", value["evidence_mode"])
        self.assertEqual("BLOCKED", value["status"])
        self.assertIn("AVC-EXECUTABLE-RECIPE", value["blocking_reasons"])

    def test_observation_clock_is_sampled_after_tool_probes(self):
        runner = FakeTools()

        def finish_clock():
            self.assertEqual(3, len(runner.calls))
            return NOW + timedelta(seconds=3)

        with mock.patch("hero_engine.phase6_av_capacity._utc_now", side_effect=finish_clock):
            value = self.run_fixture(runner=runner, at=None)
        self.assertEqual("2026-09-06T16:00:03Z", value["observed_at"])
        self.assertEqual("2026-09-06T16:05:03Z", value["valid_until"])

    def test_writable_probe_cleanup_failure_is_not_hidden_as_pass(self):
        target = self.root / "cleanup-probe-failure"
        with mock.patch.object(Path, "unlink", side_effect=PermissionError("fixture lock")):
            result = _strict_writable_check("LOCAL_TEMP", target)
        self.assertEqual("FAIL", result["status"])
        self.assertIn("cleanup failed", result["error"])
        for item in target.glob(".capacity-probe-*.tmp"):
            item.unlink()

    def test_patterned_fields_reject_non_strings(self):
        value = self.run_fixture(at=NOW + timedelta(seconds=4))
        mutations = [
            lambda row, bad: row.__setitem__("receipt_id", bad),
            lambda row, bad: row["timeline"].__setitem__("path", bad),
            lambda row, bad: row["timeline"].__setitem__("timeline_id", bad),
            lambda row, bad: row["raw_arguments"].__setitem__("path", bad),
            lambda row, bad: row["raw_arguments"].__setitem__("arguments_id", bad),
        ]
        for mutate in mutations:
            for invalid in (None, 7, [], {}):
                candidate = copy.deepcopy(value)
                mutate(candidate, invalid)
                with self.subTest(mutate=mutations.index(mutate), invalid=type(invalid).__name__):
                    with self.assertRaisesRegex(AVCapacityError, "schema rejected"):
                        _validate(candidate)

    def test_missing_encoder_and_low_disk_are_blocked_not_fixture_success(self):
        missing = self.run_fixture(runner=FakeTools(codecs=False), at=NOW + timedelta(seconds=10))
        self.assertEqual("BLOCKED", missing["status"])
        self.assertIn("AVC-TOOLS", missing["blocking_reasons"])

        def low(_path):
            return Disk(8 * 1024**3, 7 * 1024**3, 1 * 1024**3)

        constrained = self.run_fixture(disk=low, at=NOW + timedelta(seconds=20))
        self.assertEqual("BLOCKED", constrained["status"])
        self.assertIn("AVC-DISK", constrained["blocking_reasons"])
        self.assertTrue(all(row["projected_post_peak_free_bytes"] < MINIMUM_POST_RENDER_HEADROOM_BYTES
                            for row in constrained["volumes"]))

        near_collision = self.run_fixture(
            runner=FakeTools(encoder_output=(
                " V..... libx264rgb not-the-required-encoder\n"
                " A..... libfdk_aac not-the-required-encoder\n"
                " A..... pcm_s16le_planar not-the-required-encoder\n"
            )),
            at=NOW + timedelta(seconds=21),
        )
        self.assertEqual("BLOCKED", near_collision["status"])
        self.assertIn("AVC-TOOLS", near_collision["blocking_reasons"])

    def test_missing_font_keeps_complete_inventory_and_materializes_blocked(self):
        def missing_font():
            raise FileNotFoundError("fixture font unavailable")

        value = run_phase6_av_capacity_preflight(
            self.root, timeline_binding=self.timeline_binding,
            arguments_binding=self.arguments_binding, now=NOW + timedelta(seconds=25),
            disk_usage_provider=abundant, command_runner=FakeTools(),
            ffmpeg_path=self.ffmpeg, ffprobe_path=self.ffprobe,
            font_provider=missing_font,
        )
        self.assertEqual("BLOCKED", value["status"])
        self.assertIn("AVC-FILES", value["blocking_reasons"])
        self.assertGreaterEqual(len(value["required_files"]), 55)
        self.assertEqual(51, sum(row["role"] == "NARRATION_PCM" for row in value["required_files"]))
        font_rows = [row for row in value["required_files"] if row["role"] == "FONT"]
        self.assertEqual(1, len(font_rows))
        self.assertEqual("FAIL", font_rows[0]["status"])
        self.assertIn("FileNotFoundError", font_rows[0]["error"])

    def test_ttl_hash_and_reobserved_disk_fail_closed(self):
        value = self.run_fixture(at=NOW + timedelta(seconds=30))
        path = self.receipt_path(value)
        digest = bytes_sha(path.read_bytes())
        with self.assertRaisesRegex(AVCapacityError, "stale"):
            verify_phase6_av_capacity_receipt(
                self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
                expected_sha256=digest, now=NOW + timedelta(seconds=331),
                require_live=False, reobserve=False,
            )
        with self.assertRaisesRegex(AVCapacityError, "hash differs"):
            verify_phase6_av_capacity_receipt(
                self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
                expected_sha256="sha256:" + "0" * 64, now=NOW + timedelta(seconds=31),
                require_live=False, reobserve=False,
            )

        def low(_path):
            return Disk(8 * 1024**3, 7 * 1024**3, 1 * 1024**3)

        with self.assertRaisesRegex(AVCapacityError, "no longer preserves"):
            verify_phase6_av_capacity_receipt(
                self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
                expected_sha256=digest, now=NOW + timedelta(seconds=31),
                require_live=False, reobserve=True, disk_usage_provider=low,
                command_runner=FakeTools(),
            )

    def test_file_change_invalidates_replay_without_media_effect(self):
        value = self.run_fixture(at=NOW + timedelta(seconds=40))
        path = self.receipt_path(value)
        digest = bytes_sha(path.read_bytes())
        visual = self.root / self.timeline["render_spans"][0]["asset_binding"]["path"]
        original = visual.read_bytes()
        try:
            visual.write_bytes(original + b"tamper")
            with self.assertRaisesRegex(AVCapacityError, "Stage-A|file reobservation"):
                verify_phase6_av_capacity_receipt(
                    self.root, receipt_path=path, expected_receipt_id=value["receipt_id"],
                    expected_sha256=digest, now=NOW + timedelta(seconds=41),
                    require_live=False, reobserve=True, disk_usage_provider=abundant,
                    command_runner=FakeTools(),
                )
        finally:
            visual.write_bytes(original)

    def test_incomplete_stage_a_stops_before_tool_or_directory_probe(self):
        incomplete_args = {
            "source_bindings": copy.deepcopy(self.bindings), "pause_decisions": [],
            "render_spans": [], "visual_events": [], "caption_cues": [],
            "temporal_evidence_bindings": {}, "temporal_policy_binding": None,
        }
        timeline = av.build(self.root, **incomplete_args)
        raw = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_RAW_ARGUMENTS",
            "evidence_mode": "FIXTURE", "channel_id": timeline["channel_id"],
            "video_id": timeline["video_id"], "protocol_id": timeline["protocol_id"],
            "arguments": incomplete_args, "authority": copy.deepcopy(FALSE_AUTHORITY),
            "technical_cost_brl": 0,
        }
        identify(raw, "arguments_id", "phase6-av-arguments-")
        args_binding = dump(self.root, f"output/operations/phase6/av-admission/arguments/{raw['arguments_id']}.json", raw)
        timeline_binding = dump(self.root, f"output/operations/phase6/av-admission/timelines/{timeline['timeline_id']}.json", timeline)

        def forbidden(*_args, **_kwargs):
            raise AssertionError("tool/disk probe must not run before complete Stage A")

        before = set((self.root / RECEIPTS).glob("*.json"))
        with self.assertRaisesRegex(AVCapacityError, "before capacity probes"):
            run_phase6_av_capacity_preflight(
                self.root, timeline_binding=timeline_binding, arguments_binding=args_binding,
                now=NOW + timedelta(seconds=50), command_runner=forbidden,
                disk_usage_provider=forbidden, ffmpeg_path=self.ffmpeg,
                ffprobe_path=self.ffprobe, font_provider=forbidden,
            )
        self.assertEqual(before, set((self.root / RECEIPTS).glob("*.json")))


if __name__ == "__main__":
    unittest.main()
