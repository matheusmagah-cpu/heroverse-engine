"""One real source/rights inspection; adversarial metadata and fixture replay.

The sole real inspection reopens a pinned historical manifest read-only
and the unchanged existing PNGs/LIVE rights documents. It is NOT admission or
a new operational manifest. Adversarial JSON inputs use a temporary root and
the real product reader. Later downstream tests explicitly mock transport
with copies from that observation; no cached observation is presented as a
fresh source/rights verification, and no second real image decode is performed.
"""
from __future__ import annotations

import copy
import hashlib
import json
import socket
import subprocess
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

from jsonschema.exceptions import ValidationError

from hero_engine import phase6_av_static_asset_uses as uses
from tests.static_input_isolation import historical_input


ROOT = Path(__file__).resolve().parents[1]
HISTORICAL_INPUT = {
    "path": "output/operations/phase6/av-admission/static-asset-uses/static-asset-uses-input-5411282bfe21702376cfbc5f.json",
    "sha256": "5411282bfe21702376cfbc5f3cc532fa386f3e584e750290bee51e0415b94516",
}
ERRORS = (ValueError, OSError, ValidationError)
EXPECTED_MAP = (
    ("visual-u005-s00", "narration-unit-005", "fear-examples-v1", "door-0"),
    ("visual-u005-s01", "narration-unit-005", "fear-examples-v1", "door-1"),
    ("visual-u006-s00", "narration-unit-006", "fear-examples-v1", "reply-0"),
    ("visual-u006-s01", "narration-unit-006", "fear-examples-v1", "reply-1"),
    ("visual-u007-s00", "narration-unit-007", "fear-examples-v1", "morning-0"),
    ("visual-u007-s01", "narration-unit-007", "fear-examples-v1", "morning-1"),
    ("visual-u034-s00", "narration-unit-034", "four-criteria-v1", "state-0"),
    ("visual-u034-s01", "narration-unit-034", "four-criteria-v1", "state-1"),
    ("visual-u034-s02", "narration-unit-034", "four-criteria-v1", "state-2"),
    ("visual-u034-s03", "narration-unit-034", "four-criteria-v1", "state-3"),
    ("visual-u034-s04", "narration-unit-034", "four-criteria-v1", "state-4"),
    ("visual-u044-s00", "narration-unit-044", "fear-examples-v1", "door-0"),
    ("visual-u045-s00", "narration-unit-045", "fear-examples-v1", "reply-0"),
)


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _canonical(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


class StaticAssetUsesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory(prefix="static-asset-uses-fixture-")
        cls.addClassCleanup(cls.directory.cleanup)
        cls.fixture_root = Path(cls.directory.name).resolve()
        if cls.fixture_root.is_relative_to(ROOT):
            raise AssertionError("test root must be outside the operation")
        cls.fixture_manifest = cls.fixture_root / "input.json"
        cls.manifest = ROOT / HISTORICAL_INPUT["path"]
        # Only the actual envelope reader's inputs are copied. These unchanged
        # historical documents do not authorize the fixture to inspect rights;
        # its malformed JSON is rejected before that boundary.
        paths = set(uses.DEPENDENCY_PINS) | {
            "hero_engine/phase6_av_static_asset_uses.py", uses.SCHEMA,
            uses.PLAN["path"], uses.BIBLE["path"], uses.REGISTRATION["path"],
        }
        for relative in sorted(paths):
            target = cls.fixture_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / relative).read_bytes())
        cls.document = uses.proposed_static_asset_uses(ROOT)
        cls.original = _canonical(cls.document)
        cls.result = None
        cls.source_proofs = None
        cls.rights_proofs = {}
        cls.real_inspection_count = 0

    def setUp(self):
        self.binding = historical_input(self, uses.sources, ROOT, HISTORICAL_INPUT, self.document)

    def _save(self, raw):
        self.fixture_manifest.write_bytes(raw)
        return {"path": self.fixture_manifest.relative_to(self.fixture_root).as_posix(), "sha256": _sha(raw)}

    @contextmanager
    def _no_effects(self):
        with mock.patch.object(Path, "write_bytes", side_effect=AssertionError("inspection must not write")), \
             mock.patch.object(Path, "write_text", side_effect=AssertionError("inspection must not write")), \
             mock.patch.object(subprocess, "Popen", side_effect=AssertionError("no subprocess")), \
             mock.patch.object(subprocess, "run", side_effect=AssertionError("no subprocess")), \
             mock.patch.object(socket, "socket", side_effect=AssertionError("no network")):
            yield

    @contextmanager
    def _reject_before_decode(self):
        with self._no_effects(), \
             mock.patch.object(uses.sources, "inspect_static_sources", side_effect=AssertionError("invalid input reached image inspection")), \
             mock.patch.object(uses.rights, "inspect_static_asset_rights", side_effect=AssertionError("invalid input reached rights inspection")), \
             mock.patch.object(uses.sources.PngImagePlugin, "PngImageFile", side_effect=AssertionError("invalid input reached PNG decode")):
            yield

    def _real_once(self):
        cls = type(self)
        if cls.result is None:
            self.binding = historical_input(self, uses.sources, ROOT, HISTORICAL_INPUT, self.document)
            inspect_sources = uses.sources.inspect_static_sources
            inspect_rights = uses.rights.inspect_static_asset_rights

            def observed_sources(root, *, requests):
                result = inspect_sources(root, requests=requests)
                if len(requests) == 11:
                    if cls.source_proofs is not None:
                        raise AssertionError("the independent batch was repeated")
                    cls.source_proofs = copy.deepcopy(result)
                return result

            def observed_rights(root, **arguments):
                result = inspect_rights(root, **arguments)
                key = (arguments["template_id"], arguments["state_id"])
                if key in cls.rights_proofs:
                    raise AssertionError("one rights source was repeated by the use loop")
                cls.rights_proofs[key] = copy.deepcopy(result)
                return result

            with self._no_effects(), \
                 mock.patch.object(uses.sources, "inspect_static_sources", side_effect=observed_sources), \
                 mock.patch.object(uses.rights, "inspect_static_asset_rights", side_effect=observed_rights):
                cls.result = uses.inspect_static_asset_uses(ROOT, binding=self.binding)
            cls.real_inspection_count += 1
        return copy.deepcopy(cls.result)

    @contextmanager
    def _fixture_transport(self, *, altered_rights=None):
        """Copies are test-only transport fixtures, not fresh LIVE evidence."""
        self._real_once()
        source_proofs = copy.deepcopy(type(self).source_proofs)
        rights_proofs = copy.deepcopy(type(self).rights_proofs)
        if altered_rights:
            altered_rights(rights_proofs)

        def fixture_sources(root, *, requests):
            self.assertEqual(ROOT, root)
            self.assertEqual([row["static_source"] for row in self.document["sources"]], requests)
            return copy.deepcopy(source_proofs)

        def fixture_rights(root, **arguments):
            self.assertEqual(ROOT, root)
            self.assertEqual("LIVE", arguments["expected_evidence_mode"])
            return copy.deepcopy(rights_proofs[(arguments["template_id"], arguments["state_id"])])

        with self._no_effects(), \
             mock.patch.object(uses.sources, "inspect_static_sources", side_effect=fixture_sources), \
             mock.patch.object(uses.rights, "inspect_static_asset_rights", side_effect=fixture_rights), \
             mock.patch.object(uses.sources.PngImagePlugin, "PngImageFile", side_effect=AssertionError("fixture transport must not decode")):
            yield

    def _invalid(self, mutation):
        document = copy.deepcopy(self.document)
        mutation(document)
        binding = self._save(_canonical(document))
        with self._reject_before_decode(), self.assertRaises(ERRORS):
            uses.inspect_static_asset_uses(self.fixture_root, binding=binding)

    def test_00_real_13_uses_11_sources_two_lineages_without_new_media_or_authority(self):
        result = self._real_once()
        self.assertEqual(type(self).real_inspection_count, 1)
        self.assertEqual([result[key] for key in ("use_count", "source_count", "lineage_count")], [13, 11, 2])
        self.assertEqual(len(result["remaining_unbound_visual_state_ids"]), 87)
        self.assertEqual(result["status"], "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY")
        self.assertFalse(result["source_ready"])
        self.assertFalse(result["global_schedule_created"])
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertEqual(result["technical_cost_brl"], 0)
        self.assertNotIn("render_spans", result)
        self.assertNotIn("duration", result)
        self.assertEqual(self.manifest.read_bytes(), self.original)
        by_source = {row["source_id"]: row for row in result["sources"]}
        actual = [(row["visual_state_id"], row["unit_id"], by_source[row["source_id"]]["template_id"],
                   by_source[row["source_id"]]["state_id"]) for row in result["uses"]]
        self.assertEqual(list(EXPECTED_MAP), actual)
        self.assertEqual(len(type(self).rights_proofs), 11)
        self.assertTrue(all(proof["status"] == "PASS" and proof["scope"] == "RIGHTS_BINDING_ONLY"
                            for proof in type(self).rights_proofs.values()))
        for proof in type(self).source_proofs:
            self.assertEqual(proof["source_frame_count"], 1)
            self.assertTrue(all(flag is False for flag in proof["authority"].values()))
        dependencies = {row["path"]: row for row in result["dependency_bindings"]}
        for row in result["sources"]:
            self.assertEqual(dependencies[row["asset_binding"]["path"]], row["asset_binding"])
        for entry in self.document["sources"]:
            for binding in entry["rights_evidence"].values():
                path = Path(binding["path"])
                self.assertEqual(dependencies[str(path)]["sha256"], binding["sha256"])
        self.assertTrue(set(uses.sources.EXTERNAL_DEPENDENCY_PINS).issubset(dependencies))

    def test_original_lexical_provenance_and_observation_only_callbacks_remain_distinct(self):
        result = self._real_once()
        by_source = {row["source_id"]: row for row in result["sources"]}
        by_use = {row["visual_state_id"]: row for row in result["uses"]}
        for callback, original, unit, copy_lines in (
            ("visual-u044-s00", "visual-u005-s00", "narration-unit-005", ["A closed door"]),
            ("visual-u045-s00", "visual-u006-s00", "narration-unit-006", ["A delayed reply"]),
        ):
            value = by_use[callback]
            self.assertEqual(value["source_id"], by_use[original]["source_id"])
            self.assertNotEqual(value["use_id"], by_use[original]["use_id"])
            self.assertEqual(value["source_provenance_unit_id"], unit)
            self.assertEqual(value["literal_copy"], copy_lines)
            self.assertEqual(value["entry"], {"kind": "UNIT_ENTRY", "char_start": None,
                "char_end": None, "text": None, "previous_state_id": None})
            self.assertEqual(by_source[value["source_id"]]["original_unit_id"], unit)
        expected = {"door-1": (41, 50, "forgotten"), "reply-1": (35, 44, "rejection"),
                    "morning-1": (34, 46, "God has left"), "state-1": (25, 30, "truth"),
                    "state-2": (32, 41, "character"), "state-3": (43, 55, "consequences"),
                    "state-4": (61, 73, "wise counsel")}
        for source in result["sources"]:
            target = source["original_lexical_target"]
            if source["state_id"] in expected:
                self.assertEqual(tuple(target[key] for key in ("char_start", "char_end", "text")), expected[source["state_id"]])
                use = next(row for row in result["uses"] if row["source_id"] == source["source_id"])
                self.assertEqual(use["entry"]["kind"], "LEXICAL_START")
            else:
                self.assertIsNone(target)

    def test_mapping_copy_unit_and_source_identity_tampering_block_before_decode(self):
        for mutation in (
            lambda doc: doc["uses"][11].update(source_id=doc["uses"][1]["source_id"]),
            lambda doc: doc["uses"][12].update(source_id=doc["uses"][11]["source_id"]),
            lambda doc: doc["uses"][11].update(literal_copy=["Fear says: forgotten"]),
            lambda doc: doc["uses"][12].update(unit_id="narration-unit-044"),
            lambda doc: doc["sources"][0]["static_source"].update(state_id="door-1"),
            lambda doc: doc["sources"][0].update(source_id="new-source-identity"),
        ):
            with self.subTest(mutation=mutation):
                self._invalid(mutation)

    def test_original_sequence_omission_reorder_and_duplicates_block_before_decode(self):
        for mutation in (
            lambda doc: doc["uses"].pop(1),
            lambda doc: doc["uses"].reverse(),
            lambda doc: doc["uses"].__setitem__(1, copy.deepcopy(doc["uses"][0])),
            lambda doc: doc["uses"][7].update(visual_state_id="visual-u034-s04"),
            lambda doc: doc["sources"].reverse(),
            lambda doc: doc["sources"].__setitem__(1, copy.deepcopy(doc["sources"][0])),
            lambda doc: doc["uses"].append(copy.deepcopy(doc["uses"][12])),
        ):
            with self.subTest(mutation=mutation):
                self._invalid(mutation)

    def test_missing_or_altered_rights_fields_block_before_decode(self):
        for mutation in (
            lambda doc: doc["sources"][0].pop("rights_evidence"),
            lambda doc: doc["sources"][0]["rights_evidence"].pop("decision_binding"),
            lambda doc: doc["sources"][0]["rights_evidence"]["provenance_binding"].update(sha256="0" * 64),
            lambda doc: doc["sources"][0]["rights_evidence"].update(decision_binding=doc["sources"][1]["rights_evidence"]["decision_binding"]),
            lambda doc: doc["source_bindings"]["rights_registration"].update(sha256="0" * 64),
            lambda doc: doc["source_bindings"]["style_bible"].update(sha256="0" * 64),
        ):
            with self.subTest(mutation=mutation):
                self._invalid(mutation)

    def test_times_cost_and_authority_fields_cannot_enter_untimed_input(self):
        for mutation in (
            lambda doc: doc["uses"][11].update(start_sample=0),
            lambda doc: doc["uses"][11].update(frame=0),
            lambda doc: doc["sources"][0]["static_source"].update(duration_seconds=2),
            lambda doc: doc["sources"][0]["static_source"].update(fps=30),
            lambda doc: doc.update(technical_cost_brl=1),
            lambda doc: doc.update(technical_cost_brl=0.0),
            lambda doc: doc.update(authority={"publication": True}),
            lambda doc: doc.update(authority={"publication": False}),
            lambda doc: doc["uses"][0].update(quality_approved=True),
        ):
            with self.subTest(mutation=mutation):
                self._invalid(mutation)

    def test_missing_physical_rights_bytes_block_before_any_image_inspection(self):
        original_read = Path.read_bytes
        targets = (
            self.document["sources"][0]["rights_evidence"]["provenance_binding"],
            self.document["sources"][-1]["rights_evidence"]["decision_binding"],
        )
        for binding in targets:
            target = Path(binding["path"])
            def absent(path):
                if path == target:
                    raise FileNotFoundError("fixture missing rights bytes; actual file unchanged")
                return original_read(path)
            with self.subTest(target=target.name), self._reject_before_decode(), \
                 mock.patch.object(Path, "read_bytes", absent), self.assertRaises(FileNotFoundError):
                uses.inspect_static_asset_uses(ROOT, binding=self.binding)

    def test_external_pin_and_confined_path_required_before_decode(self):
        fixture_binding = self._save(self.original)
        for binding in (
            {**fixture_binding, "sha256": "0" * 64},
            {**fixture_binding, "path": str(self.fixture_manifest)},
            {**fixture_binding, "path": "../outside.json"},
            {"path": fixture_binding["path"]},
            {**fixture_binding, "approved": True},
        ):
            with self.subTest(binding=binding), self._reject_before_decode(), self.assertRaises(ERRORS):
                uses.inspect_static_asset_uses(self.fixture_root, binding=binding)

    def test_canonical_json_duplicate_nonfinite_and_truncation_block_before_decode(self):
        for raw in (
            self.original + b"\n", self.original[:-5],
            self.original.replace(b'"technical_cost_brl": 0', b'"technical_cost_brl": 0, "technical_cost_brl": 0', 1),
            self.original.replace(b'"technical_cost_brl": 0', b'"technical_cost_brl": NaN', 1),
        ):
            binding = self._save(raw)
            with self.subTest(raw_sha=_sha(raw)), self._reject_before_decode(), self.assertRaises(ERRORS):
                uses.inspect_static_asset_uses(self.fixture_root, binding=binding)

    def test_fixture_failed_rights_status_blocks_despite_existing_source_bytes(self):
        def failed(proofs):
            proofs[("fear-examples-v1", "door-0")]["status"] = "BLOCKED"
        with self._fixture_transport(altered_rights=failed), self.assertRaisesRegex(ValueError, "rights did not pass"):
            uses.inspect_static_asset_uses(ROOT, binding=self.binding)

    def test_fixture_final_manifest_dependency_drift_fails_without_writing_source(self):
        original_read = Path.read_bytes
        count = 0
        def drift(path):
            nonlocal count
            raw = original_read(path)
            if path == self.manifest:
                count += 1
                if count == 2:
                    return raw[:-1] + b" "  # Same-size mock transport corruption, not a file mutation.
            return raw
        with self._fixture_transport(), mock.patch.object(Path, "read_bytes", drift), \
             self.assertRaisesRegex(ValueError, "source hash mismatch"):
            uses.inspect_static_asset_uses(ROOT, binding=self.binding)
        self.assertEqual(count, 2)
        self.assertEqual(self.manifest.read_bytes(), self.original)

    def test_fixture_replay_rejects_mutated_output_without_repeating_real_inspection(self):
        result = self._real_once()
        with mock.patch.object(uses, "inspect_static_asset_uses", return_value=copy.deepcopy(result)) as inspect, \
             mock.patch.object(uses.sources.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no replay decode")):
            self.assertEqual(uses.verify_static_asset_uses(copy.deepcopy(result), ROOT, binding=self.binding), result)
            mutations = (
                lambda value: value.update(use_count=13.0),
                lambda value: value.update(lineage_count=13),
                lambda value: value["authority"].update(publication=True),
                lambda value: value.update(global_schedule_created=True),
                lambda value: value["uses"][11].update(source_provenance_unit_id="narration-unit-044"),
                lambda value: value["uses"][11]["entry"].update(char_start=0),
            )
            for mutation in mutations:
                candidate = copy.deepcopy(result)
                mutation(candidate)
                with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, "replay differs"):
                    uses.verify_static_asset_uses(candidate, ROOT, binding=self.binding)
            self.assertEqual(inspect.call_count, 1 + len(mutations))
        self.assertEqual(type(self).real_inspection_count, 1)


if __name__ == "__main__":
    unittest.main()
