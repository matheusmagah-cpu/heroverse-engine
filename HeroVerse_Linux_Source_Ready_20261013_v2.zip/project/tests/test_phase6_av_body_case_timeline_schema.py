"""A12 schema-only fixtures, never a timeline build or media measurement.

Historical timelines and the A11 schema are independently pinned. New A12
documents are explicit structural fixtures: no PCM/frame/clock/pauses change,
no source reader executes, and no fixture can confer production authority.
"""
import copy
import hashlib
import json
from pathlib import Path
import unittest

from jsonschema import Draft202012Validator

ROOT = Path(__file__).absolute().parents[1]
SCHEMA = "schemas/phase6_av_timeline.schema.json"
OLD_SCHEMA = "output/qa/phase6/diagnostics/body-static-registration-v1/before-A12-grouped-integration-v1/phase6_av_timeline.schema.json"
OLD_SHA = "651d39974e1c808b14147127d67173f7146a8ec6f46af8c7b44671e515b8a3eb"
TIMELINES = {
    "1.5.0": ("0708475611669eb490509573", "a9f90a8700967c2c98793e1b507f7dd6f22696d9015aa773870b3c0c8a3b1630"),
    "1.6.0": ("05a4cc9cb0cd9f23a99a4130", "582bf6dc3180ceeb8a5921c53e86a01970cd2a009a5ca52bc336233c7ccc6899"),
    "1.7.0": ("9542021baa38804f39705dbf", "faf4251ea0c5162821dc97f911cb5b73d7c49f04ad28dba9a37f6b888d172f76"),
    "1.8.0": ("08c58eb7551e72f958fa3f09", "5105f3a4c09cc632667088b7a8d50cdd49d46006b33af2f98c21fb843f37f6c0"),
    "1.9.0": ("f4be1a123a552503913cf306", "42eaa6f7e1b5b74f62693cbee25df4d6c95831a9e77eae384163b4ca23de488c"),
    "1.10.0": ("06198f553f7dd8184307c7b8", "10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb"),
}
HERE = "output/qa/phase6/diagnostics/body-case-v1/staged/body-case-amendment-v1-ac645f2d8cb2fae3414b56c7/"
PINS = {
    "projection_binding": {"path": HERE + "staged-visual-v6-ba7dabb1ed63c35a19021648.json",
        "sha256": "sha256:ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4"},
    "amendment_binding": {"path": HERE + "body-case-amendment-v1-ac645f2d8cb2fae3414b56c7.json",
        "sha256": "sha256:72c8c8eac653d690fd2afe5f2430d527541fd27d0cbd25e2c39da9753b2dcdcf"},
    "staging_binding": {"path": HERE + "receipt.json", "sha256": "sha256:e56a4135141ded3cbff19bebfb6fb33ed2e6f4526c20e50fa2c67ab98572d3e0"},
    "claim_binding": {"path": HERE + "claim.json", "sha256": "sha256:18b3f41fb734702e2fd4289c6b1dfa280afeb3580a137093f1ed4803eb476ffd"},
}
TRIO = {"body_case_amendment": "projection_binding", "body_case_evidence": "amendment_binding", "body_case_staging": "staging_binding"}
NEW_STATES = ["visual-u032-s00", "visual-u033-s00", "visual-u035-s00", "visual-u036-s00",
    "visual-u037-s00", "visual-u037-s01", "visual-u038-s00", "visual-u038-s01", "visual-u038-s02",
    "visual-u047-s00", "visual-u048-s00", "visual-u049-s00"]


def pinned(path, digest):
    raw = (ROOT / path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise AssertionError("historical fixture pin differs: " + path)
    return json.loads(raw)


class BodyCaseTimelineSchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema_raw = (ROOT / SCHEMA).read_bytes()
        cls.test_raw = Path(__file__).read_bytes()
        cls.schema = json.loads(cls.schema_raw)
        cls.old_schema = pinned(OLD_SCHEMA, OLD_SHA)
        Draft202012Validator.check_schema(cls.schema)
        cls.validator = Draft202012Validator(cls.schema)
        cls.old_validator = Draft202012Validator(cls.old_schema)
        cls.historical = {version: pinned("output/operations/phase6/av-admission/timelines/phase6-av-timeline-" + name + ".json", digest)
                          for version, (name, digest) in TIMELINES.items()}

    @classmethod
    def tearDownClass(cls):
        if (ROOT / SCHEMA).read_bytes() != cls.schema_raw or Path(__file__).read_bytes() != cls.test_raw:
            raise AssertionError("schema or test changed during focal")
        pinned(OLD_SCHEMA, OLD_SHA)
        for name, digest in TIMELINES.values():
            pinned("output/operations/phase6/av-admission/timelines/phase6-av-timeline-" + name + ".json", digest)

    def fixture(self, *, body=True, question=True, uses=True):
        """Complete structural A12 fixture; source bindings are not executed."""
        value = copy.deepcopy(self.historical["1.10.0"])
        value["schema_version"] = "1.11.0"
        value["timeline_version"] = "phase6-av-timeline-v12"
        value["implementation_dependencies"].extend({"path": "fixture-only/A12-dependency-" + str(i) + ".py",
            "sha256": "sha256:" + hashlib.sha256(str(i).encode()).hexdigest()} for i in range(20))
        value["body_case_amendment_evidence"] = None
        if not question:
            value["inputs"]["source_bindings"].pop("question_case_amendment")
            value["question_case_amendment_evidence"] = None
            value["literal_asset_use_evidence"] = copy.deepcopy(self.historical["1.9.0"]["literal_asset_use_evidence"])
            value["inputs"]["source_bindings"]["literal_asset_uses"] = copy.deepcopy(value["literal_asset_use_evidence"]["source_binding"])
        if not uses:
            value["inputs"]["source_bindings"].pop("literal_asset_uses")
            value["literal_asset_use_evidence"] = None
        if body:
            for key, field in TRIO.items():
                value["inputs"]["source_bindings"][key] = copy.deepcopy(PINS[field])
            value["body_case_amendment_evidence"] = {"adapter_version": "phase6-av-body-case-amendment-v1",
                **copy.deepcopy(PINS), "inspection_sha256": "sha256:" + "1" * 64,
                "effective_rows_sha256": "sha256:" + "2" * 64,
                "prior_case_inspection_sha256": value["question_case_amendment_evidence"]["inspection_sha256"] if question else "sha256:" + "3" * 64,
                "changed_state_count": 21, "changed_string_count": 24, "unmodified_state_count": 79,
                "preserved_bound_state_count": 29, "source_ready": False,
                "global_schedule_created": False, "calibrated_timing_available": False}
            if uses:
                use = value["literal_asset_use_evidence"]
                use.update(adapter_version="phase6-av-asset-use-binding-v3", source_count=39, use_count=41, unique_png_content_count=37)
                use["effective_rows_sha256"] = value["body_case_amendment_evidence"]["effective_rows_sha256"]
                use["bound_visual_state_ids"] = sorted(use["bound_visual_state_ids"] + NEW_STATES)
                use["remaining_unbound_visual_state_ids"] = [sid for sid in use["remaining_unbound_visual_state_ids"] if sid not in NEW_STATES]
                use["source_binding"] = {"path": "fixture-only/v4-asset-use-input.json", "sha256": "sha256:" + "4" * 64}
                value["inputs"]["source_bindings"]["literal_asset_uses"] = copy.deepcopy(use["source_binding"])
        return value

    def rejects(self, value):
        self.assertTrue(list(self.validator.iter_errors(value)), "invalid structural fixture was accepted")

    def test_all_historical_dispatches_remain_valid_without_new_fields_or_trio(self):
        self.assertEqual(self.schema["allOf"][-1]["else"]["properties"]["implementation_dependencies"], {"maxItems": 20})
        legacy = copy.deepcopy(self.historical)
        for minor in range(1, 5):
            value = copy.deepcopy(self.historical["1.5.0"])
            value["schema_version"], value["timeline_version"] = f"1.{minor}.0", f"phase6-av-timeline-v{minor + 1}"
            assessment = value["temporal_evidence_assessment"]
            for key in ("scope_complete", "scope_basis", "declared_target_unit_ids", "conservative_exclusion_unit_ids", "unknown_scope_unit_ids"):
                assessment.pop(key)
            assessment["holdout_population_scope"] = "CURRENT_RECONCILED_NARRATION_UNITS_EXCLUDING_FULL_TEMPORAL_TARGET_UNION"
            if minor < 4:
                value.pop("static_source_evidence")
                value["implementation_dependencies"] = value["implementation_dependencies"][:3]
            legacy[value["schema_version"]] = value
        for version, value in legacy.items():
            with self.subTest(version=version):
                self.old_validator.validate(value)
                self.validator.validate(value)
            bad = copy.deepcopy(value); bad["body_case_amendment_evidence"] = None
            self.rejects(bad)
            for key, field in TRIO.items():
                bad = copy.deepcopy(value); bad["inputs"]["source_bindings"][key] = copy.deepcopy(PINS[field])
                with self.subTest(version=version, key=key): self.rejects(bad)
            for count in (21, 40):
                bad = copy.deepcopy(value)
                existing = len(bad["implementation_dependencies"])
                bad["implementation_dependencies"].extend({"path": "fixture-only/forbidden-legacy-dependency-" + str(i) + ".py",
                    "sha256": "sha256:" + hashlib.sha256(str(i).encode()).hexdigest()} for i in range(count - existing))
                with self.subTest(version=version, forbidden_dependencies=count):
                    self.assertTrue(list(self.old_validator.iter_errors(bad)))
                    self.rejects(bad)

    def test_a12_optional_envelopes_keep_old_dispatch_and_new_use_counts(self):
        for body, question in ((False, False), (False, True), (True, True)):
            for uses in (False, True):
                value = self.fixture(body=body, question=question, uses=uses)
                with self.subTest(body=body, question=question, uses=uses):
                    self.validator.validate(value)
                    self.assertTrue(list(self.old_validator.iter_errors(value)))
                    self.assertEqual(len(value["implementation_dependencies"]), 40)
                    for key in ("clock", "units", "permitted_silence_spans", "pause_measurements", "render_spans", "visual_events", "caption_cues", "static_source_evidence"):
                        self.assertEqual(value[key], self.historical["1.10.0"][key])
                    self.assertEqual(value["status"], "BLOCKED_INCOMPLETE")
                    self.assertIsNone(value["derived_take_plan"])
                    self.assertFalse(value["temporal_evidence_assessment"]["all_required_evidence_live"])
                    self.assertEqual(len(value["temporal_evidence_assessment"]["temporal_target_unit_ids"]), 26)
                    if uses: self.assertEqual(value["literal_asset_use_evidence"]["use_count"], 41 if body else (29 if question else 25))
                    if body: self.assertEqual(value["question_case_amendment_evidence"], self.historical["1.10.0"]["question_case_amendment_evidence"])

    def test_trio_requires_all_seven_sources_and_nonnull_body_evidence(self):
        for missing in (*TRIO, "question_case_amendment", "visual_amendment", "untimed_visual_intent", "caption_intent"):
            value = self.fixture(); value["inputs"]["source_bindings"].pop(missing)
            with self.subTest(missing=missing): self.rejects(value)
        for one in TRIO:
            value = self.fixture(body=False)
            value["inputs"]["source_bindings"][one] = copy.deepcopy(PINS[TRIO[one]])
            with self.subTest(only=one): self.rejects(value)
        for fault in ("missing", "null", "empty", "unbound_evidence"):
            value = self.fixture()
            if fault == "missing": value.pop("body_case_amendment_evidence")
            elif fault == "null": value["body_case_amendment_evidence"] = None
            elif fault == "empty": value["body_case_amendment_evidence"] = {}
            else:
                for key in TRIO: value["inputs"]["source_bindings"].pop(key)
            with self.subTest(fault=fault): self.rejects(value)

    def test_exact_external_pins_and_closed_summary_reject_path_hash_time_or_missing_field(self):
        for key, field in TRIO.items():
            for component in ("path", "sha256"):
                value = self.fixture(); value["inputs"]["source_bindings"][key][component] += "wrong"
                with self.subTest(input=key, component=component): self.rejects(value)
        for field in PINS:
            for component in ("path", "sha256"):
                value = self.fixture(); value["body_case_amendment_evidence"][field][component] += "wrong"
                with self.subTest(field=field, component=component): self.rejects(value)
        for field in self.fixture()["body_case_amendment_evidence"]:
            value = self.fixture(); value["body_case_amendment_evidence"].pop(field)
            with self.subTest(missing=field): self.rejects(value)
        for field, extra in (("start_sample", 0), ("source_frame_count", 1), ("quality_approved", True), ("authority", {})):
            value = self.fixture(); value["body_case_amendment_evidence"][field] = extra
            with self.subTest(extra=field): self.rejects(value)

    def test_uses_variant_cannot_cross_case_generations_or_omit_bound_evidence(self):
        for fault in ("body_old29", "body_old25", "no_body_new41", "no_question_old29", "body_null", "no_input", "legacy_new41"):
            value = self.fixture()
            if fault in ("body_old29", "body_old25"):
                version = "1.10.0" if fault == "body_old29" else "1.9.0"
                value["literal_asset_use_evidence"] = copy.deepcopy(self.historical[version]["literal_asset_use_evidence"])
            elif fault == "no_body_new41":
                for key in TRIO: value["inputs"]["source_bindings"].pop(key)
                value["body_case_amendment_evidence"] = None
            elif fault == "no_question_old29":
                value = self.fixture(body=False)
                value["inputs"]["source_bindings"].pop("question_case_amendment")
                value["question_case_amendment_evidence"] = None
            elif fault == "body_null": value["literal_asset_use_evidence"] = None
            elif fault == "no_input": value["inputs"]["source_bindings"].pop("literal_asset_uses")
            else:
                old = copy.deepcopy(self.historical["1.10.0"])
                old["literal_asset_use_evidence"] = value["literal_asset_use_evidence"]
                value = old
            with self.subTest(fault=fault): self.rejects(value)

    def test_exact_counts_state_order_remaining_population_and_dependency_cardinality(self):
        for field in ("changed_state_count", "changed_string_count", "unmodified_state_count", "preserved_bound_state_count"):
            for number in (0, 21.5, True):
                value = self.fixture(); value["body_case_amendment_evidence"][field] = number
                with self.subTest(field=field, number=number): self.rejects(value)
        for fault in ("source", "use", "content", "lineage", "duplicate", "reorder", "missing", "remaining", "deps"):
            value = self.fixture(); use = value["literal_asset_use_evidence"]
            if fault == "source": use["source_count"] = 41
            elif fault == "use": use["use_count"] = 29
            elif fault == "content": use["unique_png_content_count"] = 39
            elif fault == "lineage": use["lineage_count"] = 4
            elif fault == "duplicate": use["bound_visual_state_ids"][-1] = use["bound_visual_state_ids"][0]
            elif fault == "reorder": use["bound_visual_state_ids"].reverse()
            elif fault == "missing": use["bound_visual_state_ids"].pop()
            elif fault == "remaining": use["remaining_unbound_visual_state_ids"].pop()
            else: value["implementation_dependencies"].pop()
            with self.subTest(fault=fault): self.rejects(value)

    def test_flags_cost_and_existing_global_blockers_cannot_gain_authority(self):
        for scope in ("body_case_amendment_evidence", "literal_asset_use_evidence"):
            for flag in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
                value = self.fixture(); value[scope][flag] = True
                with self.subTest(scope=scope, flag=flag): self.rejects(value)
        for fault in ("cost", "authority", "status", "all_live", "blocker", "derived", "version"):
            value = self.fixture()
            if fault == "cost": value["literal_asset_use_evidence"]["technical_cost_brl"] = 1
            elif fault == "authority": value["literal_asset_use_evidence"]["authority"]["publication"] = True
            elif fault == "status": value["status"] = "TIMELINE_VALIDATED_NOT_ADMITTED"
            elif fault == "all_live": value["temporal_evidence_assessment"]["all_required_evidence_live"] = True
            elif fault == "blocker": value["blockers"].remove("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING")
            elif fault == "derived": value["derived_take_plan"] = {}
            else: value["timeline_version"] = "phase6-av-timeline-v11"
            with self.subTest(fault=fault): self.rejects(value)

    def test_json_numeric_lexemes_remain_canonical_verifier_responsibility(self):
        # JSON Schema regards 21 and 21.0 as the same integer. Do not claim that
        # structural validation replaces the engine's exact canonical replay.
        definition = self.schema["$defs"]["body_case_amendment_evidence"]["properties"]["changed_state_count"]
        Draft202012Validator(definition).validate(21.0)
        self.assertNotEqual(json.dumps({"count": 21}), json.dumps({"count": 21.0}))
        self.assertTrue(list(Draft202012Validator(definition).iter_errors(21.5)))
        self.assertTrue(list(Draft202012Validator(definition).iter_errors(True)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
