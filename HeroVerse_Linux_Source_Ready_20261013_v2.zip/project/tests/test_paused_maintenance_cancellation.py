"""Task 2: actual cancellation protocol, isolated files and process identities.

No production mutex, request, ACK, PAUSE, queue or credential is accessed.
Native sharing/deletion/exclusivity is exercised on Windows temporary roots;
only process existence is simulated. Other mocks inject explicit failures.
"""

from __future__ import annotations

import importlib.util
import json
import os
import socket
import sqlite3
import tempfile
import threading
import time
import unittest
import uuid
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import hero_engine.maintenance_protocol as protocol


PROJECT = Path(__file__).resolve().parents[1]
REQUEST_ID = "maintenance-request-20260908T1258124421621Z-aaaaaaaa"
OTHER_ID = "maintenance-request-20260908T1258124421621Z-bbbbbbbb"
REQUESTED = datetime(2026, 9, 8, 12, 58, 19, tzinfo=timezone.utc)
PAUSE_BYTES = b"SYNTHETIC_OWNER_PAUSE_MUST_SURVIVE\n"
PUBLICATION_PATH = Path(
    "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
)
QUOTA_TABLES = (
    ("general_quota_debits", "debit_id"),
    ("upload_quota_debits", "debit_id"),
    ("composed_quota_reservations", "reservation_id"),
)


def _existing_fixtures():
    spec = importlib.util.spec_from_file_location(
        "_paused_cancel_existing", PROJECT / "tests/test_daily_maintenance_protocol.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fixtures = _existing_fixtures()


@contextmanager
def _fixture_database(path):
    # sqlite Connection.__exit__ commits/rolls back but does NOT close it.
    with closing(sqlite3.connect(path)) as connection, connection:
        yield connection


@unittest.skipUnless(os.name == "nt", "Windows sharing and named mutex contract")
class PausedMaintenanceCancellationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="hero-paused-cancel-")
        self.addCleanup(self.directory.cleanup)
        self.root = fixtures.DailyMaintenanceProtocolTests._base(self.directory.name)
        self.runtime = self.root / protocol.RUNTIME
        self.pause = self.runtime / "PAUSE"
        self.pause.write_bytes(PAUSE_BYTES)
        (self.runtime / "manager.lock").write_bytes(b"SYNTHETIC_BYTE_RANGE_LOCK_FILE\x00")
        self.request_path = self.root / protocol.REQUEST_PATH
        self.ack_path = self.root / protocol.ACK_PATH
        self.queue = fixtures.DailyMaintenanceProtocolTests._queue(
            self.root, state="SUCCEEDED", task_type="SYNTHETIC_COMPLETED_TASK",
            available_at="2026-09-08T11:00:00Z",
        )
        self.ledger = self.root / protocol.QUOTA_LEDGER_PATH
        self.ledger.parent.mkdir(parents=True, exist_ok=True)
        with _fixture_database(self.ledger) as connection:
            for table, key in QUOTA_TABLES:
                connection.execute(f"CREATE TABLE {table} ({key} TEXT PRIMARY KEY,state TEXT)")
                connection.execute(
                    f"INSERT INTO {table} VALUES (?,?)", (table + "-fixture", "CONSUMED")
                )
        for name in (
            "youtube_publication_receipt.schema.json",
            "youtube_package_update_receipt.schema.json",
            "central_manager_lock.schema.json",
        ):
            (self.root / "schemas" / name).write_bytes((PROJECT / "schemas" / name).read_bytes())
        self._json(self.runtime / "manager-lock.json", {
            "schema_version": "1.0.0", "lock_id": "gestor-central-heroverse-phase5-singleton-v1",
            "state": "RELEASED", "holder_pid": 4242,
            "holder_started_at": "2026-09-08T10:00:00Z", "heartbeat_at": "2026-09-08T11:00:00Z",
            "lease_seconds": 60, "lease_expires_at": "2026-09-08T11:01:00Z",
            "released_at": "2026-09-08T11:00:01Z", "mechanism": "windows_byte_range_lock",
            "lock_file": "output/runtime/gestor-central/manager.lock", "technical_cost_brl": 0,
        })
        self.receipt = self.root / PUBLICATION_PATH
        self.receipt.parent.mkdir(parents=True)
        # Constant channel_id comes from the production schema, not live data.
        self.publication = {
            "schema_version": "1.0.0", "receipt_id": "synthetic-publication",
            "release_id": "synthetic-release", "idempotency_key": "a" * 64,
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA", "status": "COMPLETE_PUBLIC",
            "privacy_status": "public", "video_id": "synthetic-video",
            "caption_id": "synthetic-caption",
            "steps": [{"step": "FIXTURE_ONLY", "status": "PASS", "evidence": "synthetic"}],
            "artifact_hashes": {key: "b" * 64 for key in ("video", "thumbnail", "captions")},
            "external_cost_brl": 0, "public_visibility_authorized": True, "error": None,
            "created_at": "2026-09-08T10:00:00Z", "updated_at": "2026-09-08T10:00:01Z",
        }
        self._json(self.receipt, self.publication)
        protocol.validate(self.root, "youtube_publication_receipt.schema.json", self.publication)
        protocol.create_request(
            self.root, request_id=REQUEST_ID, requester_pid=99,
            guard_seconds=1800, requested_at=REQUESTED,
        )
        ack = protocol.acknowledge_request(
            self.root, manager_pid=4242,
            now=datetime(2026, 9, 8, 12, 58, 20, tzinfo=timezone.utc),
        )
        self.assertEqual("READY_TO_STOP", ack["status"])
        self.request_hash = protocol.file_hash(self.request_path)
        self.ack_hash = protocol.file_hash(self.ack_path)
        self.mutex_patch = patch.object(
            protocol, "_PAUSED_CANCEL_MUTEX_NAME", "Local\\HeroEngine.Test.Cancel." + uuid.uuid4().hex
        )
        self.mutex_patch.start()
        self.addCleanup(self.mutex_patch.stop)
        self.process_patch = patch.object(protocol, "_process_alive", return_value=False)
        self.process = self.process_patch.start()
        self.addCleanup(self.process_patch.stop)
        for name in ("connect", "connect_ex"):
            blocker = patch.object(socket.socket, name, side_effect=AssertionError("network forbidden"))
            blocker.start()
            self.addCleanup(blocker.stop)

    @staticmethod
    def _json(path, value):
        path.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")

    def _invoke(self):
        return protocol.cancel_orphaned_maintenance_paused(
            self.root, request_id=REQUEST_ID,
            expected_request_hash=self.request_hash, expected_ack_hash=self.ack_hash,
        )

    def _archive(self):
        binding = {"request_id": REQUEST_ID, "request_hash": self.request_hash,
                   "ack_hash": self.ack_hash}
        suffix = protocol.canonical_hash(binding).split(":", 1)[1][:24]
        return self.runtime / "maintenance-cancellations" / suffix

    def _protected(self):
        paths = (
            self.request_path, self.ack_path, self.pause, self.runtime / "manager.pid",
            self.runtime / "manager-lock.json", self.runtime / "manager.lock",
            self.queue, self.ledger, self.receipt,
            self.root / protocol.RECOVERY_WINDOW_PATH,
        )
        return {str(path.relative_to(self.root)): path.read_bytes() if path.exists() else None
                for path in paths}

    def _assert_blocked_unchanged(self):
        before = self._protected()
        with self.assertRaises((PermissionError, OSError, ValueError)):
            self._invoke()
        self.assertEqual(before, self._protected())
        self.assertFalse((self._archive() / "committed.json").exists())

    def _update_ack(self, **changes):
        value = json.loads(self.ack_path.read_text("utf-8"))
        value.update(changes)
        self._json(self.ack_path, value)
        self.ack_hash = protocol.file_hash(self.ack_path)

    def test_allowed_cancel_archives_before_exact_ack_then_request_removal(self):
        before = self._protected()
        removed = []
        original = protocol._PausedCancelPin.remove

        def inspect_before_remove(pin):
            archive = self._archive()
            self.assertTrue((archive / "prepared.json").is_file())
            prepared = json.loads((archive / "prepared.json").read_text("utf-8"))
            self.assertIs(prepared["exclusive_acquired"], True)
            self.assertEqual(protocol._PAUSED_CANCEL_MUTEX_NAME, prepared["exclusive_mutex"])
            self._assert_recorded_absence(prepared["absence_checks"])
            self.assertEqual(before[str(protocol.REQUEST_PATH)], (archive / "request.json").read_bytes())
            self.assertEqual(before[str(protocol.ACK_PATH)], (archive / "ack.json").read_bytes())
            self.assertEqual(PAUSE_BYTES, (archive / "PAUSE").read_bytes())
            self.assertTrue((archive / "boundary.json").is_file())
            self.assertFalse((archive / "committed.json").exists())
            removed.append(pin.path.name)
            return original(pin)

        with patch.object(protocol._PausedCancelPin, "remove", inspect_before_remove):
            result = self._invoke()
        self.assertEqual("CANCELLED_WHILE_PAUSED", result["status"])
        self.assertEqual(["maintenance-ack.json", "maintenance-request.json"], removed)
        self.assertFalse(self.request_path.exists())
        self.assertFalse(self.ack_path.exists())
        self.assertTrue((self._archive() / "committed.json").is_file())
        committed = json.loads((self._archive() / "committed.json").read_text("utf-8"))
        self._assert_recorded_absence(committed["final_absence_checks"])
        self.assertIs(committed["restart_permitted"], False)
        after = self._protected()
        for name, contents in before.items():
            if name not in {str(protocol.REQUEST_PATH), str(protocol.ACK_PATH)}:
                self.assertEqual(contents, after[name], name)
        self.assertTrue({99, 4242}.issubset({call.args[0] for call in self.process.call_args_list}))

    def test_deferred_only_for_exact_idle_due_job_can_cancel_after_manager_absence(self):
        """A stale defer must not permanently strand an owner-paused root.

        The cancellation remains narrower than READY_TO_STOP: only the exact
        recorded due-job queue snapshot, with no lease, reservation, or effect,
        can be archived after both requester and manager are absent.
        """
        ack = json.loads(self.ack_path.read_text("utf-8"))
        ack.update({
            "status": "DEFERRED",
            "external_effect_boundary_closed": False,
            "blockers": ["OPERATIONAL_JOB_DUE_DURING_MAINTENANCE"],
            "operational_due_job_ids": ["job-idle-due"],
        })
        self._json(self.ack_path, ack)
        self.ack_hash = protocol.file_hash(self.ack_path)
        with patch.object(
            protocol, "_operational_due_jobs", return_value=["job-idle-due"]
        ), patch.object(protocol, "_inert_current_media_due_jobs", return_value=[]):
            result = self._invoke()
        self.assertEqual("CANCELLED_WHILE_PAUSED", result["status"])

    def test_deferred_ack_with_any_other_blocker_remains_rejected(self):
        self._update_ack(
            status="DEFERRED", external_effect_boundary_closed=False,
            blockers=["OPERATIONAL_JOB_DUE_DURING_MAINTENANCE", "OPEN_EFFECT"],
            operational_due_job_ids=["job-idle-due"],
        )
        self._assert_blocked_unchanged()

    def _assert_recorded_absence(self, observations):
        self.assertEqual({(99, "REQUESTER"), (4242, "MANAGER")},
                         {(item["pid"], item["role"]) for item in observations})
        self.assertEqual(2, len(observations))
        for item in observations:
            self.assertEqual("ABSENT", item["disposition"])
            self.assertEqual("OS_PID_ABSENCE_NO_GENERATION_ASSERTED", item["scope"])
            observed = datetime.fromisoformat(item["observed_at"].replace("Z", "+00:00"))
            self.assertIsNotNone(observed.tzinfo)
            self.assertLessEqual(observed, datetime.now(timezone.utc))

    def test_completed_repeat_has_no_second_deletion(self):
        first = self._invoke()
        archive_before = {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                          for path in self._archive().rglob("*") if path.is_file()}
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("repeat delete")):
            repeat = self._invoke()
        self.assertEqual("ALREADY_CANCELLED", repeat["status"])
        self.assertEqual(first["receipt_hash"], repeat["receipt_hash"])
        self.assertEqual(archive_before, {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                                        for path in self._archive().rglob("*") if path.is_file()})
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_verified_capture_only_interruption_uses_distinct_recovery_archive(self):
        original_boundary = protocol._paused_cancel_boundary
        with patch.object(protocol, "_paused_cancel_boundary", side_effect=RuntimeError("injected after capture")):
            with self.assertRaisesRegex(RuntimeError, "injected after capture"):
                self._invoke()
        self.assertTrue((self._archive() / "databases/manifest.json").is_file())
        original_capture = {
            path.relative_to(self._archive()).as_posix(): path.read_bytes()
            for path in self._archive().rglob("*") if path.is_file()
        }
        with patch.object(protocol, "_paused_cancel_boundary", original_boundary):
            result = self._invoke()
        recovery = self._archive().with_name(self._archive().name + "-recovery")
        self.assertEqual("CANCELLED_WHILE_PAUSED", result["status"])
        self.assertEqual(str(recovery), result["archive_path"])
        self.assertEqual(original_capture, {
            path.relative_to(self._archive()).as_posix(): path.read_bytes()
            for path in self._archive().rglob("*") if path.is_file()
        })
        self.assertTrue((recovery / "committed.json").is_file())

    def test_completed_repeat_preserves_foreign_future_request_and_ack(self):
        self._invoke()
        protocol.create_request(
            self.root, request_id=OTHER_ID, requester_pid=7777,
            guard_seconds=1800, requested_at=REQUESTED,
        )
        self.ack_path.write_bytes(b'{"request_id":"foreign-synthetic"}')
        before = self._protected()
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("foreign delete")):
            self.assertEqual("ALREADY_CANCELLED", self._invoke()["status"])
        self.assertEqual(before, self._protected())

    def test_absent_files_without_committed_receipt_are_not_prior_success(self):
        self.request_path.unlink()
        self.ack_path.unlink()
        self._assert_blocked_unchanged()

    def test_completed_receipt_tampering_cannot_authorize_replay(self):
        self._invoke()
        path = self._archive() / "request.json"
        path.write_bytes(b"corrupt archive")
        before = self._protected()
        with self.assertRaises((PermissionError, OSError, ValueError)):
            self._invoke()
        self.assertEqual(before, self._protected())

    def test_completed_receipt_without_final_absence_proof_blocks_replay(self):
        self._invoke()
        path = self._archive() / "committed.json"
        value = json.loads(path.read_text("utf-8"))
        value["final_absence_checks"] = None
        self._json(path, value)
        before = self._protected()
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("repeat delete")):
            with self.assertRaises(PermissionError):
                self._invoke()
        self.assertEqual(before, self._protected())

    def test_replay_holds_archive_bytes_against_concurrent_replacement(self):
        self._invoke()
        original = protocol._paused_cancel_read_archive
        replacement = self.runtime / "synthetic-archive-replacement.json"
        replacement.write_bytes(b"corrupt archive")

        def inspect_pinned(archive, binding):
            with self.assertRaises(OSError):
                os.replace(replacement, archive / "prepared.json")
            with self.assertRaises(OSError):
                (archive / "committed.json").write_bytes(b"corrupt commit")
            return original(archive, binding)

        with patch.object(protocol, "_paused_cancel_read_archive", inspect_pinned):
            self.assertEqual("ALREADY_CANCELLED", self._invoke()["status"])

    def test_expired_manager_lease_and_absent_pids_allow_paused_cancel(self):
        path = self.runtime / "manager-lock.json"
        value = json.loads(path.read_text("utf-8"))
        value.update(state="HELD", released_at=None)
        self._json(path, value)
        self._update_ack(lock_content_hash=protocol.file_hash(path))
        lock_before = path.read_bytes()
        self.assertEqual("CANCELLED_WHILE_PAUSED", self._invoke()["status"])
        self.assertEqual(lock_before, path.read_bytes())
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())

    def test_expired_same_holder_heartbeat_drift_can_cancel_without_repinning_ack(self):
        path = self.runtime / "manager-lock.json"
        value = json.loads(path.read_text("utf-8"))
        value.update({
            "state": "HELD", "released_at": None,
            "heartbeat_at": "2026-09-08T13:01:00Z",
            "lease_expires_at": "2026-09-08T13:02:00Z",
        })
        self._json(path, value)
        self.assertNotEqual(self.ack_hash, protocol.file_hash(path))
        self.assertEqual("CANCELLED_WHILE_PAUSED", self._invoke()["status"])

    def test_reappearance_of_original_markers_after_commit_blocks_without_cleanup(self):
        request = self.request_path.read_bytes()
        ack = self.ack_path.read_bytes()
        self._invoke()
        self.request_path.write_bytes(request)
        self.ack_path.write_bytes(ack)
        before = self._protected()
        with self.assertRaises((PermissionError, OSError, ValueError)):
            self._invoke()
        self.assertEqual(before, self._protected())

    def test_live_requester_blocks(self):
        self.process.side_effect = lambda pid: pid == 99
        self._assert_blocked_unchanged()

    def test_reused_requester_pid_blocks_without_inventing_generation(self):
        request = json.loads(self.request_path.read_text("utf-8"))
        self.assertFalse(any("generation" in key or "creation" in key for key in request))
        # Historical request has only a PID. A different live process at that
        # number is intentionally indistinguishable and must still block.
        self.process.side_effect = lambda pid: pid == 99
        self._assert_blocked_unchanged()

    def test_unknown_requester_probe_return_blocks(self):
        self.process.side_effect = lambda pid: None if pid == 99 else False
        self._assert_blocked_unchanged()

    def test_uncertain_requester_probe_exception_blocks(self):
        def uncertain(pid):
            if pid == 99:
                raise protocol.ProcessLivenessProbeError("simulated access denied")
            return False
        self.process.side_effect = uncertain
        self._assert_blocked_unchanged()

    def test_live_manager_blocks_even_when_owner_pause_exists(self):
        self.process.side_effect = lambda pid: pid == 4242
        self._assert_blocked_unchanged()

    def test_same_request_id_with_different_bytes_is_not_owned(self):
        value = json.loads(self.request_path.read_text("utf-8"))
        value["requester_pid"] = 7777
        self._json(self.request_path, value)
        self._assert_blocked_unchanged()

    def test_same_semantic_request_with_changed_serialization_is_not_owned(self):
        value = json.loads(self.request_path.read_text("utf-8"))
        self.request_path.write_text(json.dumps(value, indent=7), encoding="utf-8")
        self._assert_blocked_unchanged()

    def test_substitute_request_is_preserved(self):
        value = json.loads(self.request_path.read_text("utf-8"))
        value["request_id"] = OTHER_ID
        self._json(self.request_path, value)
        self._assert_blocked_unchanged()

    def test_ack_schema_invalid_even_when_supplied_hash_matches(self):
        self.ack_path.write_bytes(b'{"request_id":"synthetic-incomplete"}')
        self.ack_hash = protocol.file_hash(self.ack_path)
        self._assert_blocked_unchanged()

    def test_ack_changed_bytes_blocks(self):
        self.ack_path.write_bytes(self.ack_path.read_bytes() + b"\n")
        self._assert_blocked_unchanged()

    def test_ack_bound_to_another_request_blocks(self):
        self._update_ack(request_id=OTHER_ID)
        self._assert_blocked_unchanged()

    def test_ack_before_request_blocks(self):
        self._update_ack(observed_at="2026-09-08T12:58:18Z")
        self._assert_blocked_unchanged()

    def test_ack_lock_hash_drift_blocks(self):
        (self.runtime / "manager-lock.json").write_bytes(b'{"state":"HELD","holder_pid":4242}\n')
        self._assert_blocked_unchanged()

    def test_manager_lease_still_open_blocks_despite_absent_process(self):
        path = self.runtime / "manager-lock.json"
        value = json.loads(path.read_text("utf-8"))
        value.update(state="HELD", released_at=None, lease_expires_at="2100-01-01T00:00:00Z")
        self._json(path, value)
        self._update_ack(lock_content_hash=protocol.file_hash(path))
        self._assert_blocked_unchanged()

    def test_open_queue_lease_blocks_after_ready_ack(self):
        with _fixture_database(self.queue) as connection:
            connection.execute("UPDATE jobs SET state='LEASED',lease_owner='synthetic',lease_until='2026-09-08T13:00:00Z'")
        self._update_ack(queue_jobs_hash=protocol.queue_snapshot(self.root)["jobs_hash"])
        self._assert_blocked_unchanged()

    def test_open_reservation_blocks_after_ready_ack(self):
        with _fixture_database(self.ledger) as connection:
            connection.execute("UPDATE general_quota_debits SET state='RESERVED'")
        self._assert_blocked_unchanged()

    def test_open_effect_journal_blocks_even_with_terminal_status(self):
        self.publication["effect_journal"] = [{
            "sequence": 1, "effect_id": "SYNTHETIC_UPLOAD", "api_method": "videos.insert",
            "kind": "MUTATION", "checkpoint": "BEFORE", "attempt": 1,
            "request_fingerprint": "c" * 64, "outcome": "PENDING", "evidence": "synthetic",
            "remote_resource_id": None, "checkpointed_at": "2026-09-08T12:59:00Z",
        }]
        protocol.validate(self.root, "youtube_publication_receipt.schema.json", self.publication)
        self._json(self.receipt, self.publication)
        self._assert_blocked_unchanged()

    def test_missing_queue_blocks_unknown_state(self):
        self.queue.unlink()
        self._assert_blocked_unchanged()

    def test_missing_quota_table_blocks_unknown_state(self):
        with _fixture_database(self.ledger) as connection:
            connection.execute("DROP TABLE upload_quota_debits")
        self._assert_blocked_unchanged()

    def test_unknown_quota_state_blocks(self):
        with _fixture_database(self.ledger) as connection:
            connection.execute("UPDATE composed_quota_reservations SET state='UNAVAILABLE'")
        self._assert_blocked_unchanged()

    def test_unknown_queue_state_blocks(self):
        with _fixture_database(self.queue) as connection:
            connection.execute("UPDATE jobs SET state='UNAVAILABLE'")
        self._update_ack(queue_jobs_hash=protocol.queue_snapshot(self.root)["jobs_hash"])
        self._assert_blocked_unchanged()

    def test_missing_effect_inventory_anchor_blocks(self):
        self.receipt.unlink()
        self._assert_blocked_unchanged()

    def test_empty_effect_receipt_is_unknown_not_safe(self):
        self.receipt.write_bytes(b"{}")
        self._assert_blocked_unchanged()

    def test_sqlite_pending_sidecar_blocks(self):
        sidecar = Path(str(self.queue) + "-journal")
        sidecar.write_bytes(b"synthetic pending journal")
        self._assert_blocked_unchanged()
        self.assertEqual(b"synthetic pending journal", sidecar.read_bytes())

    def test_recovery_window_is_not_cleaned_by_this_narrow_entry(self):
        protocol.arm_recovery_window(
            self.root, request_id=REQUEST_ID, manager_pid=4242,
            duration_seconds=60, armed_at=REQUESTED,
        )
        self._assert_blocked_unchanged()

    def test_owner_pause_required(self):
        self.pause.unlink()
        self._assert_blocked_unchanged()

    def test_native_exclusivity_busy_blocks_immediately_without_retry(self):
        entered = threading.Event()
        release = threading.Event()
        errors = []

        def holder():
            try:
                with protocol._paused_cancel_exclusive():
                    entered.set()
                    if not release.wait(5):
                        raise AssertionError("fixture mutex release timeout")
            except BaseException as error:
                errors.append(error)
                entered.set()

        thread = threading.Thread(target=holder, daemon=True)
        thread.start()
        try:
            self.assertTrue(entered.wait(3), "test mutex was not acquired")
            self.assertFalse(errors, errors)
            start = time.monotonic()
            self._assert_blocked_unchanged()
            self.assertLess(time.monotonic() - start, 2)
            self.assertFalse(self._archive().exists())
        finally:
            release.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertFalse(errors, errors)

    def test_native_marker_pin_denies_replacement_and_pause_deletion(self):
        replacement = self.runtime / "synthetic-replacement.json"
        replacement.write_bytes(b"foreign replacement")
        with closing(protocol._PausedCancelPin(self.request_path, deletable=True)) as pin:
            with self.assertRaises(OSError):
                os.replace(replacement, self.request_path)
            with self.assertRaises(OSError):
                self.request_path.write_bytes(b"changed bytes")
            pin.revalidate()
        with closing(protocol._PausedCancelPin(self.pause)) as pin:
            with self.assertRaises((PermissionError, OSError, ValueError)):
                pin.remove()
        self.assertEqual(PAUSE_BYTES, self.pause.read_bytes())
        self.assertEqual(self.request_hash, protocol.file_hash(self.request_path))

    def test_archive_write_failure_prevents_all_marker_removal(self):
        original = protocol._write_immutable_bytes

        def fail_archive(path, payload):
            if path.name == "prepared.json":
                raise OSError("simulated archive persistence failure")
            return original(path, payload)

        with patch.object(protocol, "_write_immutable_bytes", fail_archive):
            self._assert_blocked_unchanged()
        self._assert_blocked_unchanged()  # Incomplete archive is not a fresh authorization.

    def test_partial_ack_removal_is_not_success_and_retry_preserves_request(self):
        before_request = self.request_path.read_bytes()
        original = protocol._PausedCancelPin.remove

        def interrupt_after_ack(pin):
            original(pin)
            if pin.path.name == "maintenance-ack.json":
                raise OSError("simulated interruption after ACK removal")

        with patch.object(protocol._PausedCancelPin, "remove", interrupt_after_ack):
            with self.assertRaises(OSError):
                self._invoke()
        self.assertFalse(self.ack_path.exists())
        self.assertEqual(before_request, self.request_path.read_bytes())
        self.assertTrue((self._archive() / "prepared.json").exists())
        self.assertFalse((self._archive() / "committed.json").exists())
        self._assert_blocked_unchanged()

    def test_partial_interruption_then_foreign_replacement_never_cleans_foreign_markers(self):
        original = protocol._PausedCancelPin.remove

        def interrupt_before_request(pin):
            if pin.path.name == "maintenance-request.json":
                raise OSError("simulated interruption before request removal")
            return original(pin)

        with patch.object(protocol._PausedCancelPin, "remove", interrupt_before_request):
            with self.assertRaises(OSError):
                self._invoke()
        protocol.create_request(
            self.root, request_id=OTHER_ID, requester_pid=7777,
            guard_seconds=1800, requested_at=REQUESTED,
        )
        self.ack_path.write_bytes(b'{"synthetic_foreign_ack":true}')
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("foreign cleanup")):
            self._assert_blocked_unchanged()

    def test_failure_after_both_removals_before_commit_does_not_fabricate_success(self):
        original = protocol._write_immutable_bytes

        def fail_commit(path, payload):
            if path.name == "committed.json":
                raise OSError("simulated interruption before commit receipt")
            return original(path, payload)

        with patch.object(protocol, "_write_immutable_bytes", fail_commit):
            with self.assertRaises(OSError):
                self._invoke()
        self.assertFalse(self.request_path.exists())
        self.assertFalse(self.ack_path.exists())
        self.assertTrue((self._archive() / "prepared.json").exists())
        self.assertFalse((self._archive() / "committed.json").exists())
        self._assert_blocked_unchanged()


if __name__ == "__main__":
    unittest.main()
