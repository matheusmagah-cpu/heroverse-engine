"""Public qualifier uses current native QA; codec/ASR frontiers simulated."""
import unittest
from pathlib import Path
from unittest.mock import patch

from tests import test_audio_static_control_reader as controls
from tests import test_audio_static_qa as qa_fixture
from hero_engine.standard_qualification_phase5 import build_standard_qualification


class AudioStaticQualificationDispatchTests(unittest.TestCase):
    def setUp(self):
        self.owner = controls.AudioStaticControlReaderTests('test_valid_anchored_reader_returns_limits_not_authority')
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        self.root = self.owner.root
        self.helper = self.owner.helper

    def qualify(self, **kwargs):
        return build_standard_qualification(self.root, package_relative=self.helper.relative, **kwargs)

    def exercise_public_entry(self, *, damaged=False):
        self.helper.codec_control_binding = self.owner.binding
        self.helper.execution_builder = self.owner.execution_fixture
        if damaged:
            def damage(image):
                image[390:630,180:1740] = image[0,0]
                return image
            self.helper.decoded_transform = damage
        # Redirect only the fixture's entry call. Production qualifier invokes
        # the unpatched native QA, readers, metrics and report schema.
        from hero_engine.qa_phase5 import run_phase5_quality_gates as native_qa
        def selected(root, **kwargs):
            report = build_standard_qualification(root, **kwargs)
            return report, qa_fixture.read(self.helper.package/'qa/technical_measurements.json')
        self.assertIsNotNone(native_qa)
        with patch.object(qa_fixture, 'run_phase5_quality_gates', side_effect=selected):
            self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        return self.helper.last_result[0]

    def test_current_package_uses_native_report_not_old_cinematic_media(self):
        report = self.exercise_public_entry()
        gates = {row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['LEGIBILITY'], 'PASS')
        self.assertEqual(gates['STYLE'], 'PASS')
        self.assertEqual(gates['AUDIO'], 'PASS')
        self.assertEqual(report['format_pack_id'], 'fp-narrated-reflection-static')
        self.assertFalse(report['publication_eligible'])
        self.assertFalse((self.root/'output/production/phase5/pilot-001/creative-v3').exists())

    def test_actual_failed_measurement_remains_failed(self):
        report = self.exercise_public_entry(damaged=True)
        self.assertEqual(next(row['status'] for row in report['gates'] if row['gate']=='LEGIBILITY'), 'FAIL')
        self.assertFalse(report['publication_eligible'])

    def test_missing_witness_blocks_before_media_processing(self):
        with self.assertRaises(PermissionError):
            self.qualify(visual_controls_binding=self.owner.binding)
        self.assertFalse((self.helper.package/'qa').exists())

    def test_no_legacy_replay_or_unselected_bindings(self):
        with self.assertRaises(PermissionError):
            self.qualify(reuse_existing_encodes=True)
        with self.assertRaises(PermissionError):
            build_standard_qualification(self.root, visual_controls_binding=self.owner.binding)

    def test_package_cannot_escape_root(self):
        for path in (Path('../foreign'), self.helper.package):
            with self.assertRaises(PermissionError):
                build_standard_qualification(self.root, package_relative=path)

    def test_default_still_selects_legacy_contract(self):
        observed=[]
        def capture(path):
            observed.append(path)
            raise FileNotFoundError('Absent isolated legacy media, never fall back to static')
        with patch('hero_engine.standard_qualification_phase5._read',side_effect=capture):
            with self.assertRaises(FileNotFoundError):
                build_standard_qualification(self.root)
        self.assertEqual(observed,[self.root/'output/production/phase5/pilot-001/creative-v3/render_manifest.json'])
