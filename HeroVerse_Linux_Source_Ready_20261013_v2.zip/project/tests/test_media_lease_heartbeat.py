from __future__ import annotations

import inspect
import json
import threading
import time
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from hero_engine import phase6_media
from hero_engine.media_lease_heartbeat import (
    MediaLeaseHeartbeat,
    MediaLeaseHeartbeatError,
)
from hero_engine.queue_phase6 import TransactionalQueue


class _SteppingClock:
    def __init__(self, value: datetime, *, step: timedelta = timedelta(0)) -> None:
        self._value = value
        self._step = step
        self._lock = threading.Lock()

    def __call__(self) -> datetime:
        with self._lock:
            value = self._value
            self._value += self._step
            return value


class _RecordingQueue:
    def __init__(
        self,
        *,
        divergent_owner: str | None = None,
        fail_on_call: int | None = None,
        expired_deadline: bool = False,
        signal_on_call: int = 2,
    ) -> None:
        self.divergent_owner = divergent_owner
        self.fail_on_call = fail_on_call
        self.expired_deadline = expired_deadline
        self.signal_on_call = signal_on_call
        self.calls: list[dict] = []
        self.signal = threading.Event()
        self._lock = threading.Lock()

    def renew_lease(
        self,
        job_id: str,
        *,
        worker_id: str,
        lease_seconds: int,
        now: datetime | None = None,
    ) -> dict:
        assert now is not None
        with self._lock:
            call_number = len(self.calls) + 1
            self.calls.append({
                "job_id": job_id,
                "worker_id": worker_id,
                "lease_seconds": lease_seconds,
                "now": now,
            })
        if call_number >= self.signal_on_call:
            self.signal.set()
        if self.fail_on_call == call_number:
            raise RuntimeError("simulated lease storage failure")
        deadline = now if self.expired_deadline else now + timedelta(seconds=lease_seconds)
        return {
            "job_id": job_id,
            "state": "LEASED",
            "lease_owner": self.divergent_owner or worker_id,
            "lease_until": deadline.isoformat().replace("+00:00", "Z"),
        }


class MediaLeaseHeartbeatTests(unittest.TestCase):
    def setUp(self) -> None:
        self.t0 = datetime(2026, 9, 6, 1, 30, tzinfo=timezone.utc)

    def test_start_renews_exact_job_owner_and_future_deadline(self) -> None:
        queue = _RecordingQueue(signal_on_call=99)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-exact",
            worker_id="worker-media-a",
            lease_seconds=120,
            interval_seconds=60,
            clock=_SteppingClock(self.t0),
        )
        try:
            heartbeat.start()
            self.assertTrue(heartbeat.running)
            self.assertTrue(heartbeat.daemon)
            self.assertEqual(1, len(queue.calls))
            self.assertEqual("job-media-exact", queue.calls[0]["job_id"])
            self.assertEqual("worker-media-a", queue.calls[0]["worker_id"])
            self.assertEqual(self.t0 + timedelta(seconds=120), heartbeat.last_deadline)
        finally:
            heartbeat.stop()
        self.assertFalse(heartbeat.running)
        with self.assertRaisesRegex(MediaLeaseHeartbeatError, "already stopped"):
            heartbeat.renew_now()

    def test_daemon_renews_periodically_and_finally_stops_all_future_calls(self) -> None:
        queue = _RecordingQueue(signal_on_call=2)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-periodic",
            worker_id="worker-media-a",
            lease_seconds=2,
            interval_seconds=0.01,
            clock=_SteppingClock(self.t0, step=timedelta(milliseconds=100)),
        )
        try:
            heartbeat.start()
            self.assertTrue(queue.signal.wait(1.0), "periodic renewal did not execute")
        finally:
            heartbeat.stop()
        call_count = len(queue.calls)
        time.sleep(0.04)
        self.assertGreaterEqual(call_count, 2)
        self.assertEqual(call_count, len(queue.calls))
        self.assertFalse(heartbeat.running)

    def test_divergent_owner_fails_before_daemon_or_success_boundary(self) -> None:
        queue = _RecordingQueue(divergent_owner="worker-intruder", signal_on_call=99)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-owner",
            worker_id="worker-media-a",
            lease_seconds=30,
            interval_seconds=10,
            clock=_SteppingClock(self.t0),
        )
        with self.assertRaisesRegex(MediaLeaseHeartbeatError, "could not renew exact"):
            heartbeat.start()
        self.assertTrue(heartbeat.failed)
        self.assertFalse(heartbeat.running)
        self.assertEqual("worker-media-a", queue.calls[0]["worker_id"])

    def test_expired_renewal_deadline_fails_closed(self) -> None:
        queue = _RecordingQueue(expired_deadline=True, signal_on_call=99)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-deadline",
            worker_id="worker-media-a",
            lease_seconds=30,
            interval_seconds=10,
            clock=_SteppingClock(self.t0),
        )
        with self.assertRaisesRegex(MediaLeaseHeartbeatError, "could not renew exact"):
            heartbeat.start()
        self.assertTrue(heartbeat.failed)
        self.assertIsNone(heartbeat.last_deadline)

    def test_background_storage_failure_is_retained_for_foreground_gate(self) -> None:
        queue = _RecordingQueue(fail_on_call=2, signal_on_call=2)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-storage",
            worker_id="worker-media-a",
            lease_seconds=2,
            interval_seconds=0.01,
            clock=_SteppingClock(self.t0, step=timedelta(milliseconds=100)),
        )
        try:
            heartbeat.start()
            self.assertTrue(queue.signal.wait(1.0), "background renewal did not execute")
            deadline = time.monotonic() + 1.0
            while not heartbeat.failed and time.monotonic() < deadline:
                time.sleep(0.005)
            self.assertTrue(heartbeat.failed)
            with self.assertRaisesRegex(
                MediaLeaseHeartbeatError, "simulated lease storage failure"
            ):
                heartbeat.assert_healthy()
        finally:
            heartbeat.stop()
        self.assertFalse(heartbeat.running)

    def test_context_cleanup_is_finally_safe(self) -> None:
        queue = _RecordingQueue(signal_on_call=99)
        heartbeat = MediaLeaseHeartbeat(
            queue,
            job_id="job-media-finally",
            worker_id="worker-media-a",
            lease_seconds=30,
            interval_seconds=10,
            clock=_SteppingClock(self.t0),
        )
        with self.assertRaisesRegex(RuntimeError, "render failed"):
            with heartbeat:
                raise RuntimeError("render failed")
        self.assertFalse(heartbeat.running)
        self.assertEqual(1, len(queue.calls))

    def test_real_queue_contract_preserves_attempt_checkpoint_and_exact_owner(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            queue = TransactionalQueue(Path(folder))
            job = queue.enqueue(
                idempotency_key="phase6:media-heartbeat-contract",
                operation_id="heroverse-phase6-controlled-longform-v1",
                channel_id="UCuMF6pJQkyMzaVoAxFL86yA",
                task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                payload={"action": "test"},
                now=self.t0,
            )
            queue.claim_job(
                job["job_id"], worker_id="worker-media-a",
                lease_seconds=10, now=self.t0,
            )
            heartbeat = MediaLeaseHeartbeat(
                queue,
                job_id=job["job_id"],
                worker_id="worker-media-a",
                lease_seconds=20,
                interval_seconds=10,
                clock=_SteppingClock(self.t0 + timedelta(seconds=5)),
            )
            heartbeat.start()
            heartbeat.stop()
            stored = queue.get_by_idempotency_key(job["idempotency_key"])
            self.assertEqual("LEASED", stored["state"])
            self.assertEqual("worker-media-a", stored["lease_owner"])
            self.assertEqual("2026-09-06T01:30:25Z", stored["lease_until"])
            self.assertEqual(1, stored["attempt_count"])
            self.assertEqual({}, stored["checkpoint"])

            intruder = MediaLeaseHeartbeat(
                queue,
                job_id=job["job_id"],
                worker_id="worker-media-b",
                lease_seconds=20,
                interval_seconds=10,
                clock=_SteppingClock(self.t0 + timedelta(seconds=6)),
            )
            with self.assertRaises(MediaLeaseHeartbeatError):
                intruder.start()
            unchanged = queue.get_by_idempotency_key(job["idempotency_key"])
            self.assertEqual("worker-media-a", unchanged["lease_owner"])
            self.assertEqual(1, unchanged["attempt_count"])

    def test_media_executor_orders_health_and_cleanup_before_success(self) -> None:
        source = inspect.getsource(phase6_media.run_phase6_media_executor)
        self.assertIn("claim_moment = lease_clock()", source)
        self.assertLess(
            source.index("claim_moment = lease_clock()"),
            source.index("claimed = queue.claim_job("),
        )
        final_renewal = source.index("heartbeat.renew_now()")
        final_stop = source.index("heartbeat.stop()", final_renewal)
        success = source.index("finished = queue.succeed(")
        self.assertLess(final_renewal, final_stop)
        self.assertLess(final_stop, success)
        self.assertIn("finally:\n                        heartbeat.stop()", source)
        self.assertIn("except LeaseConflict as lease_exc", source)
        self.assertNotIn("os.kill", source)

    def test_executor_heartbeat_failure_never_calls_succeed_and_always_stops(self) -> None:
        class FakeQueue:
            def __init__(self, due_at: datetime) -> None:
                self.job = {
                    "job_id": "job-media-integration",
                    "idempotency_key": "inputs-heartbeat:synthesize-render-standard-v2",
                    "state": "PENDING",
                    "available_at": due_at.isoformat().replace("+00:00", "Z"),
                    "lease_owner": None,
                    "checkpoint": {},
                }
                self.claim_times: list[datetime] = []
                self.fail_calls = 0
                self.succeed_calls = 0

            def get_by_idempotency_key(self, _key: str) -> dict:
                return dict(self.job)

            def get_verified_recovered_media_job(self, **_kwargs: object) -> dict:
                return dict(self.job)

            def claim_job(self, _job_id: str, **kwargs: object) -> dict:
                self.claim_times.append(kwargs["now"])
                self.job.update({
                    "state": "LEASED",
                    "lease_owner": kwargs["worker_id"],
                })
                return dict(self.job)

            def fail(self, _job_id: str, **_kwargs: object) -> dict:
                self.fail_calls += 1
                self.job.update({"state": "RETRY_WAIT", "lease_owner": None})
                return dict(self.job)

            def succeed(self, _job_id: str, **_kwargs: object) -> dict:
                self.succeed_calls += 1
                raise AssertionError("heartbeat failure must prevent queue success")

            def materialize_snapshot(self, **_kwargs: object) -> None:
                return None

        class FailingHeartbeat:
            def __init__(self) -> None:
                self.stop_calls = 0
                self.render_returned = False

            def start(self) -> None:
                return None

            def assert_healthy(self) -> None:
                if self.render_returned:
                    raise MediaLeaseHeartbeatError("simulated ownership loss")

            def renew_now(self) -> None:
                raise AssertionError("failed heartbeat cannot reach final renewal")

            def stop(self) -> None:
                self.stop_calls += 1

        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            schema = root / "schemas/phase6_media_executor_runtime.schema.json"
            schema.parent.mkdir(parents=True, exist_ok=True)
            schema.write_bytes(
                (
                    Path(__file__).resolve().parents[1]
                    / "schemas/phase6_media_executor_runtime.schema.json"
                ).read_bytes()
            )
            capacity = {
                "receipt_id": "capacity-phase6-" + "a" * 24,
                "status": "PASS",
                "required_free_bytes": 5_000,
                "blocking_reasons": [],
                "volumes": [{
                    "role": "production_output",
                    "free_bytes": 10_000,
                    "headroom_bytes": 5_000,
                }],
            }
            capacity_path = (
                root / "output/operations/phase6/capacity/receipts"
                / f"{capacity['receipt_id']}.json"
            )
            capacity_path.parent.mkdir(parents=True, exist_ok=True)
            capacity_path.write_text(json.dumps(capacity), encoding="utf-8")
            receipt = {"receipt_id": "inputs-heartbeat"}
            queue = FakeQueue(self.t0 - timedelta(seconds=1))
            heartbeat = FailingHeartbeat()

            def synthesize(*_args: object, **_kwargs: object) -> dict:
                value = {"voice_render_id": "voice-heartbeat"}
                audio = root / "output/production/phase6/video-002/audio"
                immutable = audio / "manifests/voice-heartbeat.json"
                immutable.parent.mkdir(parents=True, exist_ok=True)
                payload = json.dumps(value).encode("utf-8")
                immutable.write_bytes(payload)
                (audio / "voice_render_manifest.json").write_bytes(payload)
                return value

            def render(*_args: object, **_kwargs: object) -> dict:
                heartbeat.render_returned = True
                return {"render_id": "render-must-remain-uncommitted"}

            with patch(
                "hero_engine.phase6_media._verified_inputs",
                return_value=(receipt, None),
            ), patch(
                "hero_engine.phase6_media.run_phase6_capacity_preflight",
                return_value=capacity,
            ), patch(
                "hero_engine.phase6_media.verify_phase6_capacity_receipt",
                return_value=capacity,
            ), patch(
                "hero_engine.phase6_media.TransactionalQueue",
                return_value=queue,
            ), patch(
                "hero_engine.phase6_media.reconcile_phase6_media_authority",
                return_value={"executable_media_jobs": 1},
            ), patch(
                "hero_engine.phase6_media._reverify_same_inputs",
                return_value=receipt,
            ), patch(
                "hero_engine.phase6_media.synthesize_video2_voice",
                side_effect=synthesize,
            ), patch(
                "hero_engine.phase6_media._verify_bound_assets",
                return_value={"audit_id": "audit-1", "sha256": "sha256:" + "b" * 64},
            ), patch(
                "hero_engine.phase6_media.render_video2",
                side_effect=render,
            ), patch(
                "hero_engine.phase6_media.MediaLeaseHeartbeat",
                return_value=heartbeat,
            ), patch(
                "hero_engine.phase6_media.require_current_visual_preflight",
                return_value={"audit_id": "visual-preflight-" + "a" * 24, "path": "isolated-visual-prerequisite.json", "sha256": "sha256:" + "a" * 64, "status": "PASS"},
            ), patch(
                "hero_engine.phase6_media.verify_visual_preflight", return_value={},
            ):
                result = phase6_media.run_phase6_media_executor(root, now=self.t0)

            self.assertEqual([self.t0], queue.claim_times)
            self.assertEqual(0, queue.succeed_calls)
            self.assertEqual(1, queue.fail_calls)
            self.assertGreaterEqual(heartbeat.stop_calls, 2)
            self.assertEqual("RETRY_WAIT", result["status"])
            self.assertIn("simulated ownership loss", result["error"])


if __name__ == "__main__":
    unittest.main()
