"""One real compact-source batch; all legacy work is byte-checked replay.

Temporary manifests and instrumented negative cases are explicitly fixtures.
No old decoder/rights evaluation, media generation, network or operation write.
"""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_static_asset_uses_v2 as uses
from tests.static_input_isolation import historical_input, install_schema, fixture_reader

ROOT = Path(__file__).absolute().parents[1]
SOURCES = uses.sources
HISTORICAL_INPUT = {"path": "output/operations/phase6/av-admission/static-asset-uses-v2/input.json",
                    "sha256": "65be03122e4ad1c17e74e7bff99324f0177e0a541735ecbdc85a9883fd828376"}


class StaticAssetUsesV2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Real metadata-only preflight. It is reused only for input-rejection
        # seams below; the real integration test independently reopens it all.
        with patch.object(uses.compact, "inspect_compact_sources", side_effect=AssertionError("no decode in metadata")), \
             patch.object(SOURCES, "_png", side_effect=AssertionError("no old decode")):
            cls.metadata = uses._envelope(ROOT)
        _, literal, old_document, _, registry, _ = cls.metadata
        cls.proposal = uses._expected(literal, old_document, registry)

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="uses-v2-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = self.directory = Path(temporary.name).resolve()
        self.schema_sha = install_schema(self, SOURCES, ROOT, self.root, uses.SCHEMA)

    def binding(self, document=None, *, name="input.json", historical=False):
        if historical:
            self.assertIsNone(document)
            return historical_input(self, SOURCES, ROOT, HISTORICAL_INPUT, self.proposal)
        path = self.directory / name
        raw = SOURCES._canonical(self.proposal if document is None else document)
        path.write_bytes(raw)  # Explicit temporary test input, never an operational manifest.
        return {"path": path.relative_to(self.root).as_posix(), "sha256": SOURCES._sha(raw)}

    def metadata_fixture(self, _root):
        self.assertIn(_root, (ROOT, self.root))
        reader = fixture_reader(SOURCES, self.root, uses.SCHEMA, self.schema_sha)
        if _root == ROOT:
            reader = SOURCES._Reader(ROOT)
            reader.bindings = copy.deepcopy(self.metadata[0].bindings)
        return (reader, *self.metadata[1:])

    def test_schema_and_proposal_preserve_thirteen_uses_without_a_clock(self):
        schema = SOURCES._json((ROOT / uses.SCHEMA).read_bytes())
        Draft202012Validator(schema).validate(self.proposal)
        old_schema = SOURCES._json((ROOT / uses.legacy.SCHEMA).read_bytes())
        self.assertFalse(Draft202012Validator(old_schema).is_valid(self.proposal))
        self.assertEqual(self.proposal["sources"][:11], self.metadata[2]["sources"])
        self.assertEqual(self.proposal["uses"][:13], self.metadata[2]["uses"])
        self.assertEqual((len(self.proposal["sources"]), len(self.proposal["uses"])), (23, 25))
        callbacks = self.proposal["uses"][11:13]
        self.assertEqual([row["literal_copy"] for row in callbacks], [["A closed door"], ["A delayed reply"]])
        self.assertEqual([row["source_id"] for row in callbacks],
                         [self.proposal["sources"][0]["source_id"], self.proposal["sources"][2]["source_id"]])
        self.assertEqual(self.proposal["schema_version"], "2.0.0")
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
             patch.object(uses.compact, "inspect_compact_sources", side_effect=AssertionError("proposal is not inspection")):
            self.assertEqual(uses.proposed_static_asset_uses(ROOT), self.proposal)

    def test_invalid_manifest_copy_mapping_order_counts_time_cost_or_authority_block_before_decode(self):
        for mutation in ("copy", "mapping", "order", "duplicate", "missing", "time", "cost", "float", "authority", "anchor"):
            document = copy.deepcopy(self.proposal)
            if mutation == "copy": document["uses"][11]["literal_copy"] = ["Fear says: forgotten"]
            elif mutation == "mapping": document["uses"][13]["source_id"] = document["sources"][0]["source_id"]
            elif mutation == "order": document["uses"][13:15] = document["uses"][14:12:-1]
            elif mutation == "duplicate": document["uses"][-1] = copy.deepcopy(document["uses"][-2])
            elif mutation == "missing": document["sources"].pop()
            elif mutation == "time": document["uses"][13]["start_frame"] = 0
            elif mutation == "cost": document["technical_cost_brl"] = 1
            elif mutation == "float": document["technical_cost_brl"] = 0.0
            elif mutation == "authority": document["publication_authorized"] = True
            else: document["source_bindings"]["legacy_execution"]["sha256"] = "0" * 64
            binding = self.binding(document, name=mutation + ".json")
            with self.subTest(mutation=mutation), patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
                 patch.object(uses.compact, "inspect_compact_sources", side_effect=AssertionError("invalid input before decode")) as inspect:
                with self.assertRaises((ValueError, ValidationError)) as failure:
                    uses.inspect_static_asset_uses(self.root, binding=binding)
                if not isinstance(failure.exception, ValidationError):
                    self.assertIn("exact twenty-five-use envelope differs", str(failure.exception))
                self.assertEqual(inspect.call_count, 0)

    def test_binding_and_json_identity_cannot_be_self_relabelled(self):
        binding = self.binding()
        path = self.root / binding["path"]
        variants = [(binding, path.read_bytes() + b"\n"),
                    ({**binding, "sha256": "0" * 64}, path.read_bytes()),
                    ({"path": "../not-confined.json", "sha256": "0" * 64}, path.read_bytes()),
                    ({**binding, "source_ready": True}, path.read_bytes())]
        for index, (given, raw) in enumerate(variants):
            path.write_bytes(raw)
            if index == 0: given = {**given, "sha256": SOURCES._sha(raw)}
            with self.subTest(index=index), patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
                 patch.object(uses.compact, "inspect_compact_sources", side_effect=AssertionError("binding before decode")):
                with self.assertRaises(ValueError):
                    uses.inspect_static_asset_uses(self.root, binding=given)

    def test_historical_dependencies_drift_before_any_current_batch(self):
        old_source = self.metadata[3]["sources"][0]["asset_binding"]["path"]
        decision = self.metadata[4]["request"]["states"][0]["arguments"]["decision_binding"]["path"]
        targets = [ROOT / uses.ANCHOR["path"], ROOT / uses.LEGACY_INSPECTION["path"], Path(old_source), Path(decision)]
        original_read = Path.read_bytes
        for target in targets:
            def changed(path):
                raw = original_read(path)
                return bytes([raw[0] ^ 1]) + raw[1:] if path == target else raw
            with self.subTest(target=target.name), patch.object(Path, "read_bytes", changed), \
                 patch.object(uses.compact, "inspect_compact_sources", side_effect=AssertionError("cache integrity before decode")):
                with self.assertRaisesRegex(ValueError, "hash mismatch"):
                    uses._envelope(ROOT)

    def test_extra_legacy_artifact_invalidates_exact_cache_inventory(self):
        config = SOURCES.TEMPLATES["fear-examples-v1"]
        directory = ROOT / config["directory"]
        original_listing = Path.iterdir
        def extra(path):
            values = list(original_listing(path))
            return iter([*values, path / "unexpected.png"] if path == directory else values)
        with patch.object(Path, "iterdir", extra), \
             patch.object(SOURCES, "_png", side_effect=AssertionError("no legacy decode")):
            with self.assertRaisesRegex(ValueError, "inventory"):
                uses._legacy_replay(SOURCES._Reader(ROOT), self.metadata[1])

    def test_current_source_proof_must_match_frozen_rights_source(self):
        binding = self.binding()
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
             patch.object(uses.compact, "inspect_compact_sources", return_value=[{"inspection_id": "fixture-wrong"}] * 12):
            with self.assertRaisesRegex(ValueError, "independently anchored rights source"):
                uses.inspect_static_asset_uses(self.root, binding=binding)

    def test_real_integration_uses_exact_cache_and_one_compact_batch(self):
        binding = self.binding(historical=True)
        actual_batch = uses.compact.inspect_compact_sources
        actual_png = SOURCES._png
        with patch.object(uses.legacy, "inspect_static_asset_uses", side_effect=AssertionError("no legacy evaluator")), \
             patch.object(SOURCES, "inspect_static_sources", side_effect=AssertionError("no legacy PNG batch")), \
             patch.object(uses.legacy.rights, "inspect_static_asset_rights", side_effect=AssertionError("no legacy rights reevaluation")), \
             patch.object(uses.compact_rights, "inspect_compact_asset_rights_batch", side_effect=AssertionError("anchored rights replay only")), \
             patch.object(uses.compact, "inspect_compact_sources", wraps=actual_batch) as batch, \
             patch.object(SOURCES, "_png", wraps=actual_png) as png, \
             patch("subprocess.Popen", side_effect=AssertionError("no process")), \
             patch("socket.create_connection", side_effect=AssertionError("no network")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("no writes during inspection")):
            result = uses.inspect_static_asset_uses(ROOT, binding=binding)
        self.assertEqual((batch.call_count, png.call_count), (1, 11))
        self.assertEqual((result["source_count"], result["use_count"], result["unique_png_content_count"], result["lineage_count"]), (23, 25, 22, 3))
        self.assertEqual(len(result["remaining_unbound_visual_state_ids"]), 75)
        self.assertEqual(result["sources"][:11], self.metadata[3]["sources"])
        self.assertEqual(result["uses"][:13], self.metadata[3]["uses"])
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertFalse(result["source_ready"])
        self.assertFalse(result["global_schedule_created"])
        self.assertFalse(result["calibrated_timing_available"])
        self.assertEqual(result["technical_cost_brl"], 0)
        selected = {row["visual_state_id"]: row for row in result["uses"]}
        for sid, start, end in (("visual-u011-s01", 14, 19), ("visual-u012-s01", 15, 20)):
            entry = selected[sid]["entry"]
            self.assertEqual((entry["kind"], entry["text"], entry["char_start"], entry["char_end"]), ("LEXICAL_START", "write", start, end))
        self.assertEqual(selected["visual-u016-s01"]["entry"]["kind"], "CONTINUE_STATE")
        self.assertEqual(selected["visual-u016-s01"]["entry"]["previous_state_id"], "visual-u016-s00")
        self.assertEqual(result["legacy_replay_evidence"]["mode"], "EXACT_CACHE_REPLAY")
        self.assertEqual(result["compact_rights_replay_evidence"]["new_rights_evaluation_count"], 0)
        self.assertEqual(result["visual_amendment_evidence"]["effective_rows_sha256"], uses.canonical_sha(self.metadata[1]["rows"]))
        self.assertEqual(result["visual_amendment_evidence"]["inspection_sha256"], uses.canonical_sha(self.metadata[1]))
        dependencies = {item["path"]: item for item in result["dependency_bindings"]}
        for item in self.metadata[3]["dependency_bindings"]:
            self.assertEqual(dependencies[item["path"]], item)
        self.assertIn(str(ROOT / uses.COMPACT_REQUEST["path"]), dependencies)

    def test_late_legacy_drift_blocks_after_instrumented_current_batch(self):
        # Explicit decoded-measurement fixture avoids repeating the real batch.
        binding = self.binding(historical=True)
        measurement = {"width": 1920, "height": 1080, "mode": "RGB", "opacity": "OPAQUE", "source_frame_count": 1}
        armed = {"value": False}
        actual_batch, actual_read = uses.compact.inspect_compact_sources, Path.read_bytes
        target = ROOT / uses.ANCHOR["path"]
        def batch(*args, **kwargs):
            result = actual_batch(*args, **kwargs)
            armed["value"] = True
            return result
        def changed(path):
            raw = actual_read(path)
            return bytes([raw[0] ^ 1]) + raw[1:] if armed["value"] and path == target else raw
        with patch.object(SOURCES, "_png", return_value=measurement), patch.object(uses.compact, "inspect_compact_sources", side_effect=batch), \
             patch.object(Path, "read_bytes", changed):
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                uses.inspect_static_asset_uses(ROOT, binding=binding)

    def test_verifier_reopens_and_rejects_relabelled_candidate(self):
        expected = {"version": uses.VERSION, "source_count": 23, "source_ready": False, "authority": dict(uses.AUTHORITY)}
        binding = self.binding()
        with patch.object(uses, "inspect_static_asset_uses", return_value=expected) as inspect:
            self.assertEqual(uses.verify_static_asset_uses(copy.deepcopy(expected), self.root, binding=binding), expected)
            inspect.assert_called_once_with(self.root, binding=binding)
            for key, value in (("source_count", 23.0), ("source_ready", True), ("duration_ms", 1000)):
                candidate = copy.deepcopy(expected); candidate[key] = value
                with self.assertRaises(ValueError):
                    uses.verify_static_asset_uses(candidate, self.root, binding=binding)


if __name__ == "__main__":
    unittest.main()
