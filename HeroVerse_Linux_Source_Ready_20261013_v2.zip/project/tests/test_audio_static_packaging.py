"""Real native captions, PNG and provenance; no encoder or network."""
import shutil
import unittest
from unittest.mock import patch
from tests import test_audio_static_qa as fixture
from hero_engine.publication_package_phase5 import prepare_audio_static_packaging,read_audio_static_packaging

class AudioStaticPackagingTests(unittest.TestCase):
    def setUp(self):
        self.owner=fixture.AudioStaticQaTests('test_final_technical_static_hold_not_wrongly_rejected_as_freeze')
        self.addCleanup(self.owner.doCleanups);self.owner.setUp()
        self.root,self.package=self.owner.root,self.owner.package
        voice=fixture.read(self.package/'audio/voice_render_manifest.json')
        shutil.copy2(self.root/voice['narrative_script']['path'],self.package/'narrative_script.json')

    def prepare(self):return prepare_audio_static_packaging(self.root,package_relative=self.owner.relative)
    def read(self):return read_audio_static_packaging(self.root,package_relative=self.owner.relative)

    def test_public_producer_reader_and_idempotence(self):
        result=self.prepare()
        before={path:path.read_bytes() for path in self.package.rglob('*') if path.is_file()}
        self.assertEqual(result,self.prepare())
        self.assertEqual(result['cue_count'],len(self.owner.plan['takes']))
        self.assertFalse(result['publication_authorized'])
        self.assertFalse(result['quality_authorized'])
        for path,raw in before.items():self.assertEqual(path.read_bytes(),raw)

    def test_caption_tamper_rejected(self):
        self.prepare();(self.package/'captions/en-US.srt').write_bytes(b'wrong words')
        with self.assertRaises(PermissionError):self.read()

    def test_thumbnail_tamper_rejected(self):
        self.prepare();(self.package/'thumbnail/owned-static.png').write_bytes(b'wrong composition')
        with self.assertRaises(PermissionError):self.read()

    def test_stale_receipt_or_minted_authority_rejected(self):
        self.prepare();path=self.package/'packaging/static_packaging_receipt.json'
        value=fixture.read(path);value['authority']['publication']=True;fixture.write(path,value)
        with self.assertRaises(PermissionError):self.read()

    def test_changed_script_blocks_before_artifacts(self):
        (self.package/'narrative_script.json').write_bytes(b'changed script')
        with self.assertRaises(PermissionError):self.prepare()
        self.assertFalse((self.package/'captions').exists())

    def test_partial_packaging_never_overwritten(self):
        path=self.package/'captions/en-US.srt';path.parent.mkdir();path.write_bytes(b'partial evidence')
        with self.assertRaises(PermissionError):self.prepare()
        self.assertEqual(path.read_bytes(),b'partial evidence')

    def test_existing_result_recovered_without_caption_producer(self):
        first=self.prepare()
        with patch('hero_engine.render_creative_v3_phase5._build_captions',side_effect=AssertionError('duplicate producer')):
            self.assertEqual(self.prepare(),first)

    def test_public_qa_rejects_tampered_packaging_before_media_processing(self):
        from hero_engine.qa_phase5 import run_phase5_quality_gates
        self.prepare();(self.package/'captions/en-US.srt').write_bytes(b'tampered captions')
        with patch('hero_engine.qa_phase5._probe',side_effect=AssertionError('Do not probe invalid package')):
            with self.assertRaises(PermissionError):
                run_phase5_quality_gates(self.root,package_relative=self.owner.relative,inputs_only=True)
