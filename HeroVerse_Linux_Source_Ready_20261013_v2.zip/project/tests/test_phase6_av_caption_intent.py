"""Literal caption metadata tests; no timing inference, decode or LIVE approval.

The real test reuses the frozen A6 unit metadata as a caller-input projection,
not as a new independent PCM verification. Mutations use isolated fixture copies.
"""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import textwrap
import unittest
from unittest import mock

from hero_engine import phase6_av_caption_intent as captions
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).resolve().parent.parent
PLAN = {
    "path": "output/qa/phase6/diagnostics/narration-caption-chunks-v2/3ddd6d1db0f753c02ea2fdf8.json",
    "sha256": "sha256:3ddd6d1db0f753c02ea2fdf8611c15962a01dc6bfa1cdb6287f5e2dd14f588f4",
}
TIMELINE = {
    "path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-0708475611669eb490509573.json",
    "sha256": "sha256:a9f90a8700967c2c98793e1b507f7dd6f22696d9015aa773870b3c0c8a3b1630",
}


def sha(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class CaptionIntentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raws = {}
        for binding in (PLAN, captions.SOURCE, captions.PRIMITIVE,
                        {key: captions.IMPLEMENTATION[key] for key in ("path", "sha256")}, TIMELINE):
            raw = (ROOT / binding["path"]).read_bytes()
            if sha(raw) != binding["sha256"]:
                raise AssertionError("frozen input hash changed")
            cls.raws[binding["path"]] = raw
        cls.plan = json.loads(cls.raws[PLAN["path"]])
        cls.units = json.loads(cls.raws[TIMELINE["path"]])["units"]

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="caption-intent-fixture-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.fixture_bindings = []
        for name, raw in self.raws.items():
            if name == TIMELINE["path"]:
                continue
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)

    def altered(self, mutate=None, *, raw=None):
        plan = copy.deepcopy(self.plan)
        if mutate:
            mutate(plan)
        if raw is None:
            raw = (json.dumps(plan, ensure_ascii=True, sort_keys=True, indent=2) + "\n").encode()
        (self.root / PLAN["path"]).write_bytes(raw)
        # A fixture's intentionally rebound hash exercises structural validation;
        # it does not claim this modified plan is the reviewed LIVE editorial plan.
        binding = {"path": PLAN["path"], "sha256": sha(raw)}
        self.fixture_bindings.append(binding)
        return binding

    def read(self, binding=None, units=None):
        bound = binding or PLAN
        # Deliberately scoped fixture-only policy patch exercises lower-level
        # structural guards after admission; production accepts only PLAN.
        allowed = bound if bound in self.fixture_bindings else PLAN
        with mock.patch.object(captions, "PLAN_BINDING", allowed):
            return captions.read_caption_intent(Reader(self.root), bound,
                                               self.units if units is None else units)

    def test_real_metadata_only_recomposes_51_71_17_37_34_without_decode_or_effect(self):
        reader = Reader(ROOT)
        original_units = copy.deepcopy(self.units)
        with mock.patch("hero_engine.phase6_narration_audio_inventory.inspect_pcm", side_effect=AssertionError("no PCM decode")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no subprocess")), \
             mock.patch("importlib.util.spec_from_file_location", side_effect=AssertionError("no planner import")), \
             mock.patch.object(Path, "write_bytes", side_effect=AssertionError("no artifact write")):
            result = captions.read_caption_intent(reader, PLAN, self.units)
        self.assertEqual([result[key] for key in ("unit_count", "cue_count", "chunked_unit_count",
                         "internal_alignment_cue_count", "whole_unit_cue_count")], [51, 71, 17, 37, 34])
        self.assertEqual(result["lexical_unit_ids"], [f"narration-unit-{n:03d}" for n in
            (3, 8, 9, 16, 22, 23, 27, 28, 29, 31, 37, 38, 39, 40, 42, 46, 51)])
        self.assertEqual(result["cues"], self.plan["cues"])
        self.assertTrue(result["literal_caption_coverage_complete"])
        self.assertNotIn("scope_complete", result)
        self.assertFalse(result["global_schedule_created"])
        self.assertFalse(result["calibrated_timing_available"])
        self.assertTrue(all(flag is False for flag in result["authority"].values()))
        self.assertEqual(result["source_binding"], PLAN)
        expected_paths = {PLAN["path"], captions.SOURCE["path"], captions.IMPLEMENTATION["path"], captions.PRIMITIVE["path"]}
        self.assertEqual(set(reader.bindings), expected_paths)
        self.assertEqual({row["path"] for row in result["dependency_bindings"]}, expected_paths)
        self.assertEqual(self.units, original_units)
        for row in result["lexical_ranges"]:
            self.assertEqual([row[key] for key in ("global_start_sample", "global_end_sample",
                             "unit_relative_start_sample", "unit_relative_end_sample")], [None] * 4)
        self.assertEqual((ROOT / PLAN["path"]).read_bytes(), self.raws[PLAN["path"]])

    def test_replay_is_read_only_and_independent_results_preserve_original_copy(self):
        first = self.read()
        first["cues"][0]["text"] = "not the source"
        second = self.read()
        self.assertEqual(second["cues"][0]["text"], "Pause.")
        self.assertEqual(second["whole_unit_cues"][0]["text"], "Pause.")
        self.assertEqual(self.plan["cues"][0]["text"], "Pause.")

    def test_valid_resegmentation_cannot_claim_frozen_v2_editorial_provenance(self):
        def condense_hook(plan):
            row = copy.deepcopy(plan["cues"][2])
            text = self.units[2]["text"]
            row.update(char_start=0, char_end=len(text), text=text,
                lines=textwrap.wrap(text, width=42, break_long_words=False, break_on_hyphens=False),
                timing_state=captions.WHOLE, unit_relative_start_sample=0,
                unit_relative_end_sample=self.units[2]["frame_count"],
                reason="Whole utterance fits textual precheck.")
            plan["cues"][2:5] = [row]
            plan.update(cue_count=69, chunked_unit_count=16, internal_alignment_cue_count=34)

        def detach_fear_attribution(plan):
            rows = [row for row in plan["cues"] if row["unit_id"] == "narration-unit-016"]
            cursor = 0
            for row, text in zip(rows, ["I will always be abandoned", "is a sentence fear wrote about your identity."], strict=True):
                row.update(char_start=cursor, char_end=cursor + len(text), text=text,
                    lines=textwrap.wrap(text, width=42, break_long_words=False, break_on_hyphens=False))
                cursor += len(text) + 1

        for mutation in (condense_hook, detach_fear_attribution):
            binding = self.altered(mutation)
            # Counterproof: these meet generic literal/container/count checks
            # under an explicitly patched fixture policy, but not the real one.
            projected = self.read(binding)
            self.assertTrue(projected["literal_caption_coverage_complete"])
            reader = Reader(self.root)
            with mock.patch.object(reader, "read", side_effect=AssertionError("unapproved plan must not open")), \
                 self.assertRaisesRegex(ValueError, "exact frozen v2"):
                captions.read_caption_intent(reader, binding, self.units)

    def test_truncation_missing_unit_duplication_and_reordering_block(self):
        mutations = [
            lambda p: p["cues"].pop(),
            lambda p: p["cues"].pop(0),
            lambda p: p["cues"].insert(0, copy.deepcopy(p["cues"][0])),
            lambda p: p["cues"].reverse(),
            lambda p: p["cues"][2].update(cue_id=p["cues"][1]["cue_id"]),
            lambda p: p["cues"][2].update(unit_id="narration-unit-999"),
        ]
        for mutate in mutations:
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                self.read(self.altered(mutate))

    def test_char_gap_overlap_literal_and_lines_block(self):
        for mutate in (
            lambda p: p["cues"][3].update(char_start=20),
            lambda p: p["cues"][3].update(char_start=18),
            lambda p: p["cues"][3].update(char_end=33),
            lambda p: p["cues"][3].update(text="test their story,"),
            lambda p: p["cues"][3].update(lines=["test", "its story,"]),
            lambda p: p["cues"][3].update(char_start=19.0),
            lambda p: p["cues"][0].update(char_start=False),
        ):
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                self.read(self.altered(mutate))

    def test_pcm_wav_population_and_container_counts_cannot_be_swapped(self):
        for key, value in (("pcm_sha256", self.units[1]["pcm_sha256"]),
                           ("wav_sha256", self.units[1]["wav_sha256"]),
                           ("sha256", self.units[1]["sha256"]),
                           ("path", self.units[1]["path"]), ("frame_count", 15017),
                           ("frame_count", True), ("text", "Pause!")):
            candidate = copy.deepcopy(self.units)
            candidate[0][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.read(units=candidate)
        for candidate in (self.units[:-1], [self.units[0], *self.units[:-1]], self.units[::-1]):
            with self.assertRaises(ValueError):
                self.read(units=candidate)
        for key in ("pcm_sha256", "wav_sha256"):
            with self.subTest(cue_key=key), self.assertRaises(ValueError):
                self.read(self.altered(lambda p: p["cues"][0].update({key: self.units[1][key]})))

    def test_invented_times_and_lexical_container_reclassification_block(self):
        for mutate in (
            lambda p: p["cues"][2].update(unit_relative_start_sample=0),
            lambda p: p["cues"][2].update(unit_relative_end_sample=1600),
            lambda p: p["cues"][2].update(global_start_sample=72000),
            lambda p: p["cues"][0].update(global_end_sample=15016),
            lambda p: p["cues"][2].update(timing_state=captions.WHOLE,
                unit_relative_start_sample=0, unit_relative_end_sample=self.units[2]["frame_count"]),
            lambda p: p["cues"][0].update(timing_state=captions.LEXICAL,
                unit_relative_start_sample=None, unit_relative_end_sample=None),
            lambda p: p["cues"][0].update(unit_relative_end_sample=15017),
        ):
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                self.read(self.altered(mutate))

    def test_forged_counts_and_authority_never_become_evidence(self):
        for key in ("unit_count", "cue_count", "chunked_unit_count", "internal_alignment_cue_count"):
            for value in (self.plan[key] + 1, float(self.plan[key]), True):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    self.read(self.altered(lambda p: p.update({key: value})))
        for mutate in (
            lambda p: p.update(scope_complete=True),
            lambda p: p.update(schema_version="1.0.0"),
            lambda p: p.update(technical_cost_brl=1),
            lambda p: p.update(model_calls=1),
            lambda p: p["cues"][0].update(rendered_legibility_approved=True),
            lambda p: p["authority"].update(render=0),
            lambda p: p["authority"].update(publication=True),
        ):
            with self.subTest(mutate=mutate), self.assertRaises((ValueError, PermissionError)):
                self.read(self.altered(mutate))

    def test_json_duplicate_nonfinite_truncated_and_extra_fields_block(self):
        original = self.raws[PLAN["path"]]
        for raw in (original[:-8], original.replace(b'"model_calls": 0', b'"model_calls": 0, "model_calls": 0'),
                    original.replace(b'"global_start_sample": null', b'"global_start_sample": NaN', 1),
                    original.replace(b'"char_start": 0', b'"char_start": 1e999', 1)):
            with self.subTest(raw_end=raw[-30:]), self.assertRaises(ValueError):
                self.read(self.altered(raw=raw))
        with self.assertRaises(ValueError):
            self.read(self.altered(lambda p: p["cues"][0].update(frame=0)))

    def test_external_pin_provenance_planner_and_primitive_bytes_are_mandatory(self):
        with self.assertRaises(ValueError):
            self.read({**PLAN, "sha256": "sha256:" + "0" * 64})
        for dependency in (captions.SOURCE, captions.IMPLEMENTATION, captions.PRIMITIVE):
            path = self.root / dependency["path"]
            original = path.read_bytes()
            path.write_bytes(original + b"\n")
            with self.subTest(dependency=path.name), self.assertRaises(ValueError):
                self.read()
            path.write_bytes(original)
        for key in ("source", "implementation"):
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.read(self.altered(lambda p: p[key].update(sha256="sha256:" + "0" * 64)))

    def test_dependency_recheck_detects_same_call_mutation_before_return(self):
        for target in (PLAN, captions.SOURCE, captions.PRIMITIVE):
            path = self.root / target["path"]
            original = path.read_bytes()
            reader = Reader(self.root)
            real_read = reader.read
            seen = {}

            def changing_read(name, expected=None, **kwargs):
                seen[name] = seen.get(name, 0) + 1
                if name == target["path"] and seen[name] == 2:
                    path.write_bytes(original + b"\n")  # Explicit isolated fixture mutation.
                return real_read(name, expected, **kwargs)

            with self.subTest(dependency=path.name), mock.patch.object(reader, "read", side_effect=changing_read), \
                 self.assertRaises(ValueError):
                captions.read_caption_intent(reader, PLAN, self.units)
            path.write_bytes(original)

    def test_unbound_external_and_traversal_paths_block_before_read(self):
        reader = Reader(self.root)
        with mock.patch.object(reader, "read", side_effect=AssertionError("invalid binding must not read")):
            for bad in ({"path": PLAN["path"]}, {**PLAN, "sha256": PLAN["sha256"][7:]},
                        {**PLAN, "path": "../other.json"}, {**PLAN, "path": str(ROOT / PLAN["path"])},
                        {**PLAN, "path": "a/./b.json"}):
                with self.subTest(binding=bad), self.assertRaises((ValueError, PermissionError)):
                    captions.read_caption_intent(reader, bad, self.units)


if __name__ == "__main__":
    unittest.main()
