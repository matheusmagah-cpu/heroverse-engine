from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[1]


def _read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


class Phase6AssetExpansionTests(unittest.TestCase):
    def test_real_expansion_is_rights_bound_quality_scanned_and_hash_verified(self) -> None:
        receipt_path = ROOT / "output/production/phase6/shared-assets/asset_library_expansion.json"
        manifest_path = ROOT / "output/production/phase6/shared-assets/asset_manifest.json"
        receipt, manifest = _read(receipt_path), _read(manifest_path)
        Draft202012Validator(
            _read(ROOT / "schemas/phase6_asset_library_expansion.schema.json"),
            format_checker=FormatChecker(),
        ).validate(receipt)
        self.assertEqual("COMPLETE", receipt["status"])
        self.assertGreaterEqual(receipt["eligible_new_asset_count"], 6)
        self.assertEqual(receipt["manifest"]["sha256"], _hash(manifest_path))
        assets = {item["asset_id"]: item for item in manifest["assets"]}
        for record in receipt["assets"]:
            asset = assets[record["asset_id"]]
            media = Path(asset["uri"])
            rights = Path(asset["rights_evidence_uri"])
            self.assertTrue(media.is_file())
            self.assertTrue(rights.is_file())
            self.assertEqual(record["content_hash"], _hash(media))
            self.assertEqual("PASS", asset["content_quality_gate"])
            self.assertTrue(asset["production_eligible"])
            self.assertTrue(asset["commercial_use"])
            self.assertGreaterEqual(sum(item["end_ms"] - item["start_ms"] for item in asset["safe_ranges"]), 8_000)
        self.assertEqual(0, receipt["technical_cost_brl"])
        self.assertFalse(receipt["publication_authorized"])


if __name__ == "__main__":
    unittest.main()
