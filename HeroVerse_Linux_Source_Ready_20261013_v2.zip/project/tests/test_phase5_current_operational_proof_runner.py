import tempfile
import unittest
from pathlib import Path
from unittest import mock

from hero_engine import current_operational_proof_runner as runner


class CurrentOperationalProofRunnerTests(unittest.TestCase):
    def test_capture_reopens_full_sorted_population_and_reports_progress(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "b.json").write_bytes(b"b")
            (root / "a.json").write_bytes(b"a")
            events = []
            with mock.patch.object(runner.paused, "_host_observation", return_value={
                    "task_enabled": False, "automation_paused": True}), \
                 mock.patch.object(runner, "protected_paths", return_value=[Path("b.json"), Path("a.json")]):
                result = runner.capture_preservation(root, progress=events.append, progress_every=1)
            self.assertEqual(["a.json", "b.json"], list(result["files"]))
            self.assertEqual("STARTED", events[0]["state"])
            self.assertEqual("COMPLETED", events[-1]["state"])
            self.assertEqual(2, events[-1]["total_files"])

    def test_population_is_union_of_existing_protection_boundaries(self):
        root = Path("C:/proof-root")
        with mock.patch.object(runner.paused, "_operational_paths", return_value=[Path("x.json"), Path("a.json")]), \
             mock.patch.object(runner.protocol, "_paused_cancel_database_files", return_value=[Path("a.json"), Path("z.sqlite3")]):
            self.assertEqual([Path("a.json"), Path("x.json"), Path("z.sqlite3")], runner.protected_paths(root))

    def test_non_authoritative_progress_failure_does_not_abort_capture(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "a.json").write_bytes(b"a")
            with mock.patch.object(runner.paused, "_host_observation", return_value={
                    "task_enabled": False, "automation_paused": True}), \
                 mock.patch.object(runner, "protected_paths", return_value=[Path("a.json")]):
                result = runner.capture_preservation(root, progress=lambda _: (_ for _ in ()).throw(PermissionError()))
            self.assertIn("a.json", result["files"])
