from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.phase5_autonomous_quality import (
    PACK,
    REGISTRY,
    REPORT,
    apply_limited_transition,
    build_evaluation,
)


ROOT = Path(__file__).resolve().parents[1]
FIXED_TIME = "2026-09-04T17:00:00Z"


class Phase5AutonomousQualityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.real_report = json.loads((ROOT / REPORT).read_text(encoding="utf-8"))
        cls.cached_asr = cls.real_report["measurements"]["asr"]

    def test_real_frozen_candidate_passes_twelve_autonomous_gates(self) -> None:
        report = build_evaluation(ROOT, asr_result=self.cached_asr, created_at=FIXED_TIME)
        schema = json.loads((ROOT / "schemas/phase5_autonomous_quality_evaluation.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(schema).validate(report)
        self.assertEqual("PASS_LIMITED_CANARY", report["decision"])
        self.assertTrue(report["publication_eligible"])
        self.assertEqual(12, len(report["gates"]))
        self.assertTrue(all(item["status"] == "PASS" for item in report["gates"]))
        self.assertLess(report["measurements"]["asr"]["word_error_rate"], 0.02)
        self.assertFalse(report["evaluator"]["human_reviewer_claimed"])
        self.assertFalse(report["audit_policy"]["per_release_human_review"])

    def test_unintelligible_audio_fails_closed(self) -> None:
        bad_asr = dict(self.cached_asr)
        bad_asr["text"] = "unrelated words " * 20
        report = build_evaluation(ROOT, asr_result=bad_asr, created_at=FIXED_TIME)
        self.assertEqual("FAIL", report["decision"])
        self.assertFalse(report["publication_eligible"])
        self.assertIn("AUDIO", report["blockers"])

    def test_transition_promotes_only_to_limited_and_is_reversible(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for schema_name in (
                "phase5_autonomous_quality_evaluation.schema.json",
                "format_pack_autonomous_transition_receipt.schema.json",
                "format_pack.schema.json",
            ):
                target = root / "schemas" / schema_name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / "schemas" / schema_name).read_bytes())
            for relative in (PACK, REGISTRY, REPORT):
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / relative).read_bytes())
            pack_fixture = json.loads((root / PACK).read_text(encoding="utf-8"))
            pack_fixture["capability_status"] = "PROTOTYPED"
            pack_fixture["production_allowed"] = False
            pack_fixture["limitation_contract"] = None
            (root / PACK).write_text(json.dumps(pack_fixture), encoding="utf-8")
            registry_fixture = json.loads((root / REGISTRY).read_text(encoding="utf-8"))
            registry_fixture["format_pack_overrides"][0]["capability_status"] = "PROTOTYPED"
            registry_fixture["capability_counts"]["PROTOTYPED"] = 1
            registry_fixture["capability_counts"]["LIMITED"] = 0
            (root / REGISTRY).write_text(json.dumps(registry_fixture), encoding="utf-8")

            receipt_path = apply_limited_transition(
                root, created_at=FIXED_TIME, refresh_package=False
            )
            pack = json.loads((root / PACK).read_text(encoding="utf-8"))
            registry = json.loads((root / REGISTRY).read_text(encoding="utf-8"))
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
            schema = json.loads((root / "schemas/format_pack_autonomous_transition_receipt.schema.json").read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(receipt)
            self.assertEqual("LIMITED", pack["capability_status"])
            self.assertTrue(pack["production_allowed"])
            self.assertEqual(1, registry["capability_counts"]["LIMITED"])
            self.assertEqual(0, registry["capability_counts"]["PROTOTYPED"])
            self.assertEqual("LIMITED", receipt["to_status"])
            self.assertTrue((root / receipt["rollback"]["archive_path"]).is_file())


if __name__ == "__main__":
    unittest.main()
