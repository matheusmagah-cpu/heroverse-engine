"""D-151 fixtures; invented observations here never represent live performance."""
from __future__ import annotations

import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine.observatory import format_paths as subject

ROOT = Path(__file__).resolve().parents[1]
AT = "2026-09-06T12:00:00+00:00"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class FormatPathsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        for name in (*subject.DEPENDENCIES, "config/market-format-policy-v1.json",
                     "config/format_packs/fp-broll-cinematic-narration-v1.json",
                     "config/macro_pipelines/pipeline-clips-longform-v1.json"):
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
        self.config = json.loads((self.root / "config/market-format-policy-v1.json").read_text(encoding="utf-8"))
        self.config["source_contract"] = {"evidence_mode": "FIXTURE", "operation_id": "fixture-format-paths",
                                          "collector": {"name": "fixture", "version": "1.0", "mode": "PUBLIC_METADATA_NO_MEDIA"},
                                          "integrity_manifest": None}
        self.records = []
        for channel in ("one", "two"):
            self.add_channel(channel)
            for fmt, values in (("LONG", (10, 20, 30, 400)), ("SHORT", (10, 20, 30, 50))):
                for index, views in enumerate(values):
                    self.add_video(channel, fmt, index, views)

    def snapshot(self, channel, entity_type, entity, payload):
        identity = hashlib.sha256(f"{channel}/{entity_type}/{entity}".encode()).hexdigest()[:24]
        return {"schema_version": "1.0.0", "snapshot_id": "snap-" + identity,
                "operation_id": "fixture-format-paths", "channel_id": channel,
                "entity_type": entity_type, "entity_id": entity, "collection_status": "COMPLETE",
                "captured_at": AT, "source_uri": (f"https://www.youtube.com/watch?v={entity}" if entity_type == "VIDEO"
                                                  else f"https://www.youtube.com/channel/public-{entity}"),
                "collector": {"name": "fixture", "version": "1.0", "mode": "PUBLIC_METADATA_NO_MEDIA"},
                "evidence_class": "OBSERVED", "payload": payload,
                "unavailable_metrics": ["RPM", "REVENUE", "CTR"], "error": None}

    def add_channel(self, name, role="MARKET_REFERENCE"):
        self.records.append(self.snapshot(name, "CHANNEL", name, {"channel_id_public": "public-" + name, "catalog_role": role}))

    def add_video(self, channel, fmt, index, views, role="MARKET_REFERENCE", date="20260901"):
        video = f"{channel}-{fmt}-{index}"
        self.records.append(self.snapshot(channel, "VIDEO", video,
            {"video_id": video, "channel_id_public": "public-" + channel, "catalog_role": role,
             "webpage_url": f"https://www.youtube.com/watch?v={video}",
             "content_format": fmt, "upload_date": date, "timestamp": None,
             "availability": "public", "public_fields_only": True,
             "title": "FIXTURE", "view_count": views, "like_count": None, "comment_count": 0}))

    def write_inputs(self):
        source = self.root / "fixture-source.json"
        source.write_text(json.dumps({"schema_version": "1.0.0", "operation_id": "fixture-format-paths",
                                     "captured_at": AT, "snapshots": self.records}), encoding="utf-8")
        policy = self.root / "config/market-format-policy-v1.json"
        policy.write_text(json.dumps(self.config), encoding="utf-8")
        return {"source": {"path": source.name, "sha256": sha(source)},
                "policy": {"path": policy.relative_to(self.root).as_posix(), "sha256": sha(policy)}}

    def compile(self, at=AT):
        return subject.compile_format_path_decision(self.root, **self.write_inputs(), evaluated_at=at)

    def enable_short_fixture(self):
        """Explicitly hypothetical validated pack; never written to live config."""
        long_route = self.config["capability_candidates"][0]
        pack = json.loads((self.root / long_route["pack"]["path"]).read_text(encoding="utf-8"))
        pack["limitation_contract"]["allowed_scope"][1] = "English Christian-motivation Shorts only"
        pack["limitation_contract"]["forbidden_scope"] = ["other channels or spend"]
        path = self.root / "config/format_packs/fixture-short.json"
        path.write_text(json.dumps(pack), encoding="utf-8")
        route = copy.deepcopy(long_route)
        route.update(content_format="SHORT", format_scope_clause="English Christian-motivation Shorts only")
        route["pack"] = {"path": path.relative_to(self.root).as_posix(), "sha256": sha(path)}
        self.config["capability_candidates"].append(route)

    def test_matched_channel_age_comparison_selects_research_not_profit(self):
        result = self.compile()
        self.assertEqual("LONG", result["recommended_research_format"])
        self.assertEqual(2, result["comparison"]["matched_channel_count"])
        self.assertEqual({"LONG": 16.0, "SHORT": 2.0}, result["comparison"]["scores"])
        self.assertIsNone(result["financial_comparison"]["more_profitable_format"])
        self.assertFalse(result["production_authorized"])
        self.assertFalse(result["publication_authorized"])
        subject.replay_format_path_decision(self.root, result)
        with self.assertRaisesRegex(ValueError, "fixture"):
            subject.validate_format_path_decision(self.root, result, now=AT)

    def test_stale_source_cannot_recommend(self):
        result = self.compile("2026-09-07T12:00:00Z")
        self.assertEqual("STALE", result["freshness"]["status"])
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])
        self.assertIn("MARKET_SOURCE_EXPIRED", result["reasons"])

    def test_refresh_due_is_not_expired_or_a_scheduled_job(self):
        result = self.compile("2026-09-06T18:00:00Z")
        self.assertEqual("CURRENT", result["freshness"]["status"])
        self.assertTrue(result["freshness"]["refresh_due"])
        self.assertFalse(result["freshness"]["scheduler_integrated"])
        self.assertFalse(result["freshness"]["collection_executed"])

    def test_replay_at_use_time_refuses_expiration(self):
        result = self.compile()
        with self.assertRaisesRegex(ValueError, "use time"):
            subject.validate_format_path_decision(self.root, result, now="2026-09-07T12:00:00Z")

    def test_no_cross_age_fallback(self):
        for item in self.records:
            if item["payload"].get("content_format") == "SHORT":
                item["payload"]["upload_date"] = "20260101"
        result = self.compile()
        self.assertEqual(0, result["comparison"]["matched_channel_count"])
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])

    def test_one_channel_is_not_enough(self):
        self.records = [x for x in self.records if x["channel_id"] == "one"]
        result = self.compile()
        self.assertEqual(1, result["comparison"]["matched_channel_count"])
        self.assertIn("INSUFFICIENT_MATCHED_SAMPLE", result["reasons"])

    def test_owned_and_speed_do_not_change_market_scores(self):
        before = self.compile()["comparison"]["scores"]
        for channel, role in (("owned", "OWNED"), ("speed", "SPEED_REFERENCE")):
            self.add_channel(channel, role)
            for fmt in subject.FORMATS:
                for i in range(8):
                    self.add_video(channel, fmt, i, 999999999, role)
        result = self.compile()
        self.assertEqual(before, result["comparison"]["scores"])
        self.assertEqual(8, result["comparison"]["counts"]["LONG"]["market_videos"])

    def test_signal_winner_without_capability_is_not_replaced_by_weaker_route(self):
        for record in self.records:
            if record["payload"].get("content_format") == "SHORT" and record["payload"]["view_count"] == 50:
                record["payload"]["view_count"] = 4000
        result = self.compile()
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])
        self.assertIn("SIGNAL_WINNER_CAPABILITY_UNAVAILABLE", result["reasons"])

    def test_hybrid_needs_both_capabilities_and_explicit_research_policy(self):
        for record in self.records:
            if record["payload"].get("view_count") == 400:
                record["payload"]["view_count"] = 50
        self.config["allow_hybrid_research"] = True
        self.assertEqual("UNDETERMINED", self.compile()["recommended_research_format"])
        self.enable_short_fixture()
        result = self.compile()
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])
        self.assertIn("NO_VERIFIED_FORMAT_RECIPE_ADAPTER", result["capabilities"]["SHORT"]["reasons"])
        # Test the generic rule independently of an unavailable real SHORT recipe.
        hypothetical = {f: {"research_eligible": True} for f in subject.FORMATS}
        self.assertEqual("HYBRID", subject._recommend(result["comparison"], hypothetical, self.config, result["freshness"])[0])
        self.assertFalse(result["production_authorized"])

    def test_relabelling_long_pack_does_not_create_short_capability(self):
        self.enable_short_fixture()
        for record in self.records:
            if record["payload"].get("content_format") == "SHORT" and record["payload"]["view_count"] == 50:
                record["payload"]["view_count"] = 4000
        result = self.compile()
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])
        self.assertFalse(result["capabilities"]["SHORT"]["research_eligible"])
        hypothetical = {f: {"research_eligible": True} for f in subject.FORMATS}
        self.assertEqual("SHORT", subject._recommend(result["comparison"], hypothetical, self.config, result["freshness"])[0])

    def test_changed_source_or_policy_blocks_before_archive(self):
        inputs = self.write_inputs()
        for kind in ("source", "policy"):
            path = self.root / inputs[kind]["path"]
            old = path.read_bytes()
            path.write_bytes(old + b" ")
            with self.assertRaisesRegex(ValueError, "binding changed"):
                subject.compile_format_path_decision(self.root, **inputs, evaluated_at=AT)
            path.write_bytes(old)
        self.assertFalse((self.root / "output").exists())

    def test_tampered_result_does_not_validate_even_with_new_id(self):
        result = self.compile()
        result["comparison"]["scores"]["LONG"] = 999
        body = {k: v for k, v in result.items() if k != "decision_id"}
        result["decision_id"] = "format-path-" + subject._sha(subject._bytes(body))[:24]
        with self.assertRaisesRegex(ValueError, "does not reproduce"):
            subject.replay_format_path_decision(self.root, result)

    def test_dependency_change_invalidates_prior_result(self):
        result = self.compile()
        path = self.root / "hero_engine/atomic_io.py"
        path.write_bytes(path.read_bytes() + b"\n")
        with self.assertRaisesRegex(ValueError, "does not reproduce"):
            subject.replay_format_path_decision(self.root, result)

    def test_future_or_naive_clock_and_unbounded_policy_fail(self):
        for at in ("2026-09-06T11:59:59Z", "2026-09-06T12:00:00"):
            with self.assertRaises(ValueError):
                self.compile(at)
        self.config["refresh_interval_seconds"] = 86401
        with self.assertRaisesRegex(ValueError, "cadence"):
            self.compile()

    def test_confined_path_and_duplicate_json_keys(self):
        inputs = self.write_inputs()
        inputs["source"]["path"] = "../outside.json"
        with self.assertRaisesRegex(ValueError, "confined"):
            subject.compile_format_path_decision(self.root, **inputs, evaluated_at=AT)
        with self.assertRaisesRegex(ValueError, "duplicate"):
            subject._json(b'{"a":1,"a":2}')
        with self.assertRaisesRegex(ValueError, "non-finite"):
            subject._json(b'{"a":NaN}')
        with self.assertRaisesRegex(ValueError, "non-finite"):
            subject._json(b'{"a":1e999}')

    def test_idempotent_archive_and_conflict_preservation(self):
        result = self.compile()
        path = subject.materialize(self.root, result)
        previous = path.read_bytes()
        self.assertEqual(path, subject.materialize(self.root, result))
        self.assertEqual(previous, path.read_bytes())
        path.write_bytes(b"tampered")
        with self.assertRaisesRegex(ValueError, "conflicting"):
            subject.materialize(self.root, result)
        self.assertEqual(b"tampered", path.read_bytes())

    def test_incomplete_archive_cannot_be_overwritten(self):
        result = self.compile()
        folder = self.root / "output/observatory/format-paths" / result["decision_id"]
        folder.mkdir(parents=True)
        with self.assertRaisesRegex(ValueError, "incomplete"):
            subject.materialize(self.root, result)

    def test_transient_archive_failure_can_retry_without_erasing_evidence(self):
        result = self.compile()
        with patch.object(subject, "atomic_write_utf8", side_effect=PermissionError("fixture lock")):
            with self.assertRaises(PermissionError):
                subject.materialize(self.root, result)
        path = subject.materialize(self.root, result)
        self.assertTrue(path.is_file())

    def test_policy_changed_during_compilation_is_rejected(self):
        inputs = self.write_inputs()
        original = subject._capabilities
        def mutate(root, config):
            result = original(root, config)
            path = root / inputs["policy"]["path"]
            path.write_bytes(path.read_bytes() + b" ")
            return result
        with patch.object(subject, "_capabilities", side_effect=mutate):
            with self.assertRaisesRegex(ValueError, "binding changed"):
                subject.compile_format_path_decision(self.root, **inputs, evaluated_at=AT)

    def test_real_historical_catalog_is_stale_and_preserved(self):
        source = ROOT / "output/observatory/phase3/phase3-2026-09-02-catalog-v2/public_snapshots.json"
        original = source.read_bytes()
        (self.root / "fixture-source.json").write_bytes(original)
        policy_path = self.root / "config/market-format-policy-v1.json"
        self.config["source_contract"].update(operation_id="phase3-2026-09-02-catalog-v2",
            collector={"name": "yt-dlp", "version": "2026.08.19", "mode": "PUBLIC_METADATA_NO_MEDIA"})
        policy_path.write_text(json.dumps(self.config), encoding="utf-8")
        result = subject.compile_format_path_decision(self.root,
            source={"path": "fixture-source.json", "sha256": sha(source)},
            policy={"path": "config/market-format-policy-v1.json", "sha256": sha(policy_path)}, evaluated_at=AT)
        self.assertEqual("STALE", result["freshness"]["status"])
        self.assertEqual("UNDETERMINED", result["recommended_research_format"])
        self.assertEqual(92, result["comparison"]["counts"]["LONG"]["all_videos"])
        self.assertEqual(31, result["comparison"]["counts"]["SHORT"]["all_videos"])
        self.assertEqual(original, source.read_bytes())


if __name__ == "__main__":
    unittest.main()
