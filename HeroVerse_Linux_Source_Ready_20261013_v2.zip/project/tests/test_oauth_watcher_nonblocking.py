"""Isolated watcher contracts; synthetic credentials and network forbidden."""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from hero_engine import central_manager_phase5 as manager
from hero_engine.oauth_token_mirror import mirror_authorized_user_token


ROOT = Path(__file__).resolve().parents[1]


class OAuthWatcherNonblockingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        secrets = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.source = secrets / "synthetic-source.json"
        self.destination = secrets / "synthetic-runtime.json"
        (self.root / "schemas").mkdir()
        for name in (
            "oauth_reconsent_watcher_runtime.schema.json",
            "oauth_token_mirror_receipt.schema.json",
        ):
            (self.root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
        self.effect_lock = threading.Lock()
        self.stack.enter_context(patch.object(manager, "_OAUTH_EFFECT_LOCK", self.effect_lock))
        self.sleep = self.stack.enter_context(patch.object(
            manager.time, "sleep", side_effect=AssertionError("Watcher must not sleep")
        ))
        self.network = self.stack.enter_context(patch(
            "socket.socket.connect", side_effect=AssertionError("Network forbidden in watcher tests")
        ))
        self.network_ex = self.stack.enter_context(patch(
            "socket.socket.connect_ex", side_effect=AssertionError("Network forbidden in watcher tests")
        ))
        self.mirror = self.stack.enter_context(patch.object(manager, "mirror_authorized_user_token"))
        self.prove = self.stack.enter_context(patch.object(
            manager, "prove_noninteractive_refresh", return_value={
                "status": "PASS", "identity_verified_after_refresh": True, "failure_code": None,
            }
        ))
        self.readiness = self.stack.enter_context(patch.object(manager, "materialize_oauth_readiness"))

    def tearDown(self) -> None:
        self.sleep.assert_not_called()
        self.network.assert_not_called()
        self.network_ex.assert_not_called()
        self.assertFalse(self.effect_lock.locked(), "OAuth mutex leaked")

    @staticmethod
    def token(grant: str = "synthetic-new-grant", **changes) -> dict:
        return {
            "token": "synthetic-access", "refresh_token": grant,
            "token_uri": "https://oauth2.googleapis.com/token",
            "client_id": "synthetic-client", "client_secret": "synthetic-secret",
            "scopes": list(manager.INTEGRATION_SCOPES), **changes,
        }

    def put(self, path: Path, value: dict) -> None:
        path.write_text(json.dumps(value), encoding="utf-8")

    def run_worker(self) -> dict:
        manager._oauth_reconsent_worker(self.root, self.source, self.destination)
        return json.loads((self.root / manager.RUNTIME / "oauth-reconsent-watcher.json").read_bytes())

    def no_effects(self) -> None:
        self.mirror.assert_not_called()
        self.prove.assert_not_called()
        self.readiness.assert_not_called()

    def test_missing_source_returns_wait_without_sleep_or_network(self) -> None:
        status = self.run_worker()
        self.assertEqual("WAITING_FOR_FOUR_SCOPE_TOKEN", status["status"])
        self.assertEqual("SOURCE_NOT_READY_FileNotFoundError", status["failure_code"])
        self.no_effects()

    def test_partial_source_returns_wait_without_sleep_or_network(self) -> None:
        self.source.write_text('{"token":', encoding="utf-8")
        status = self.run_worker()
        self.assertEqual("SOURCE_NOT_READY_JSONDecodeError", status["failure_code"])
        self.assertEqual("WAITING_FOR_FOUR_SCOPE_TOKEN", status["status"])
        self.no_effects()

    def test_missing_required_scope_returns_wait_without_mutating_destination(self) -> None:
        self.put(self.source, self.token(scopes=list(manager.INTEGRATION_SCOPES)[:-1]))
        self.put(self.destination, self.token("synthetic-existing-grant"))
        before = self.destination.read_bytes()
        status = self.run_worker()
        self.assertEqual("SOURCE_NOT_READY_PermissionError", status["failure_code"])
        self.assertEqual(before, self.destination.read_bytes())
        self.no_effects()

    def test_source_arriving_next_pass_transacts_once_without_restart(self) -> None:
        self.assertEqual("WAITING_FOR_FOUR_SCOPE_TOKEN", self.run_worker()["status"])
        self.no_effects()
        self.put(self.source, self.token())
        self.put(self.destination, self.token("synthetic-existing-grant"))
        # Exercise the real local atomic mirror; only the external refresh is mocked.
        self.mirror.side_effect = mirror_authorized_user_token
        status = self.run_worker()
        self.assertEqual("MIRRORED_AND_REFRESHED", status["status"])
        self.assertTrue(status["identity_verified_after_refresh"])
        self.assertEqual(self.source.read_bytes(), self.destination.read_bytes())
        self.mirror.assert_called_once()
        self.prove.assert_called_once()
        self.readiness.assert_called_once()

    def test_unchanged_grant_preserves_fresh_access_token_and_failed_receipt(self) -> None:
        self.put(self.source, self.token(token="synthetic-stale-access", expiry="2026-09-01T00:00:00Z"))
        self.put(self.destination, self.token(token="synthetic-fresh-access", expiry="2026-09-09T00:00:00Z"))
        base = self.root / "output/integrations/youtube/heroverse"
        base.mkdir(parents=True)
        receipt = base / "oauth-noninteractive-refresh-receipt.json"
        failure = b'{"status":"FAIL","failure_code":"REFRESH_FAILED"}\n'
        receipt.write_bytes(failure)
        before = self.destination.read_bytes()
        status = self.run_worker()
        self.assertEqual("RUNTIME_GRANT_UNCHANGED_HEALTH_MONITOR_OWNS_RETRY", status["failure_code"])
        self.assertEqual("PENDING", status["refresh_status"])
        self.assertFalse(status["identity_verified_after_refresh"])
        self.assertEqual(before, self.destination.read_bytes())
        self.assertEqual(failure, receipt.read_bytes())
        self.no_effects()

    def test_current_verified_chain_is_reused_without_effects(self) -> None:
        with patch.object(manager, "_existing_oauth_chain_is_current", return_value=True):
            status = self.run_worker()
        self.assertEqual("MIRRORED_AND_REFRESHED", status["status"])
        self.assertEqual("PASS", status["refresh_status"])
        self.no_effects()

    def test_maintenance_request_prevents_inspection_and_all_token_effects(self) -> None:
        runtime = self.root / manager.RUNTIME
        runtime.mkdir(parents=True)
        (runtime / "maintenance-request.json").write_text("{}", encoding="utf-8")
        self.put(self.source, self.token())
        with patch.object(manager, "inspect_authorized_user_token") as inspect_token:
            status = self.run_worker()
        self.assertEqual("WAITING_FOR_FOUR_SCOPE_TOKEN", status["status"])
        inspect_token.assert_not_called()
        self.no_effects()

    def test_mirror_refresh_and_readiness_hold_same_mutex_in_order(self) -> None:
        self.put(self.source, self.token())
        events = []

        def held(name, result=None):
            def invoke(*args, **kwargs):
                acquired = self.effect_lock.acquire(blocking=False)
                if acquired:
                    self.effect_lock.release()
                self.assertFalse(acquired, f"{name} escaped OAuth transaction mutex")
                events.append(name)
                return result
            return invoke

        self.mirror.side_effect = held("mirror")
        self.prove.side_effect = held("refresh", {"status": "PASS", "failure_code": None})
        self.readiness.side_effect = held("readiness")
        status = self.run_worker()
        self.assertEqual(["mirror", "refresh", "readiness"], events)
        self.assertEqual("MIRRORED_AND_REFRESHED", status["status"])

    def test_failed_refresh_is_not_promoted_to_identity_or_pass(self) -> None:
        self.put(self.source, self.token())
        self.prove.return_value = {"status": "FAIL", "failure_code": "REFRESH_FAILED"}
        status = self.run_worker()
        self.assertEqual("FAILED", status["status"])
        self.assertEqual("FAIL", status["refresh_status"])
        self.assertFalse(status["identity_verified_after_refresh"])
        self.assertEqual("REFRESH_FAILED", status["failure_code"])
        self.prove.assert_called_once()

    def test_mirror_exception_stops_transaction_releases_lock_and_redacts_message(self) -> None:
        self.put(self.source, self.token())
        self.mirror.side_effect = OSError("synthetic-sensitive-value-must-not-be-logged")
        status = self.run_worker()
        self.assertEqual("FAILED", status["status"])
        self.assertEqual("OSError", status["failure_code"])
        self.assertNotIn("synthetic-sensitive-value", json.dumps(status))
        self.prove.assert_not_called()
        self.readiness.assert_not_called()


if __name__ == "__main__":
    unittest.main()
