"""Real public package/release readers; no live channel or fabricated QA PASS."""
import copy
import shutil
import unittest
from pathlib import Path
from tests import test_audio_static_publication_package as fixture
from hero_engine.publication_package_phase5 import materialize as materialize_package
from hero_engine.phase5_release_gate import build_release_gate, materialize, stage_audio_static_canary

class AudioStaticReleaseGateTests(unittest.TestCase):
    def setUp(self):
        self.owner=fixture.AudioStaticPublicationPackageTests('test_current_public_producer_uses_current_script_and_owned_media_only')
        self.addCleanup(self.owner.doCleanups);self.owner.setUp()
        self.root,self.package=self.owner.root,self.owner.package
        self.relative=self.owner.owner.relative
        shutil.copy2(fixture.fixture.ROOT/'schemas/phase5_release_gate.schema.json',self.root/'schemas')
        paths={
            'output/integrations/youtube/heroverse/operational-readiness.json':
                {'continuous_operation_ready':False,'publication_guard':{'upload_permitted':False}},
            'output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json':
                {'status':'PASS','missing_scopes':[]},
            'output/audits/channel/heroverse/channel-readiness-audit.json':
                {'overall_status':'PASS','publication_gate':{'critical_open_gates':[]}},
            'output/operations/zero-cost/phase5-publication-pipeline-preflight.json':
                {'technical_cost_brl':0,'execution_permitted':True}}
        for relative,value in paths.items():
            path=self.root/relative;path.parent.mkdir(parents=True,exist_ok=True);fixture.fixture.write(path,value)
        path=materialize_package(self.root,package_relative=self.relative,
            quality_report_binding=self.owner.report_binding,measurement_binding=self.owner.measured_binding)
        self.bindings={'quality_report':self.owner.report_binding,'measurements':self.owner.measured_binding,
                      'publication_package':{'path':str(path),'sha256':fixture.fixture.voice_fixture.sha(path)}}

    def build(self, **kwargs):
        args={'package_relative':self.relative,'current_bindings':self.bindings}
        args.update(kwargs);return build_release_gate(self.root,**args)

    def test_real_public_reader_blocks_unmeasured_quality_and_capability(self):
        result=self.build()
        self.assertEqual(result['decision'],'BLOCKED')
        self.assertFalse(result['publication_pipeline_permitted'])
        self.assertEqual(result['authorized_api_methods'],[])
        self.assertIn('AUTOMATIC_QUALITY',result['blockers'])
        self.assertIn('INDEPENDENT_CODEC_CALIBRATION',result['blockers'])
        self.assertIn('FORMAT_CAPABILITY',result['blockers'])
        self.assertNotIn('HUMAN_GOLD_STANDARD_POLICY',result['blockers'])
        self.assertEqual(len(result['gates']),13)

    def test_no_unbound_or_unknown_proof_population(self):
        for value in ({},{**self.bindings,'manual_pass':True}):
            with self.subTest(value=tuple(value)),self.assertRaises(PermissionError):
                self.build(current_bindings=value)

    def test_old_directory_cannot_replace_current_qa(self):
        bindings=copy.deepcopy(self.bindings)
        bindings['quality_report']['path']=str(self.root/'output/production/legacy/qa/report.json')
        with self.assertRaises(PermissionError):self.build(current_bindings=bindings)

    def test_tampered_package_cannot_mint_upload_even_with_new_fixture_anchor(self):
        path=Path(self.bindings['publication_package']['path']);value=fixture.fixture.read(path)
        value['publication_policy']['upload_permitted']=True;fixture.fixture.write(path,value)
        self.bindings['publication_package']['sha256']=fixture.fixture.voice_fixture.sha(path)
        with self.assertRaises(PermissionError):self.build()

    def test_canary_cannot_be_issued_while_quality_is_blocked(self):
        before=(self.root/'config/format_packs/fp-narrated-reflection-static-v1.json').read_bytes()
        with self.assertRaises(PermissionError):
            stage_audio_static_canary(self.root,package_relative=self.relative,current_bindings=self.bindings)
        self.assertFalse((self.package/'autonomous-review/format_pack_transition_receipt.json').exists())
        self.assertEqual((self.root/'config/format_packs/fp-narrated-reflection-static-v1.json').read_bytes(),before)

    def test_public_materializer_is_idempotent_and_preserves_existing_decision(self):
        args={'package_relative':self.relative,'current_bindings':self.bindings}
        path=materialize(self.root,**args);before=path.read_bytes()
        self.assertEqual(path,materialize(self.root,**args));self.assertEqual(path.read_bytes(),before)
        value=fixture.fixture.read(path);value['publication_pipeline_permitted']=True;fixture.fixture.write(path,value)
        tampered=path.read_bytes()
        with self.assertRaises(PermissionError):materialize(self.root,**args)
        self.assertEqual(path.read_bytes(),tampered)

    def test_legacy_entry_cannot_receive_current_bindings_implicitly(self):
        with self.assertRaises(PermissionError):build_release_gate(self.root,current_bindings=self.bindings)

    def test_rejected_legacy_transition_has_no_fallback(self):
        path=self.package/'autonomous-review/format_pack_transition_receipt.json';path.parent.mkdir()
        fixture.fixture.write(path,{'basis':'AUTONOMOUS_QUALITY_PASS_WITH_HUMAN_GOLD_STANDARD_AND_CANARY_LIMIT'})
        self.bindings['format_transition']={'path':str(path),'sha256':fixture.fixture.voice_fixture.sha(path)}
        result=self.build();self.assertIn('FORMAT_CAPABILITY',result['blockers'])
        before=path.read_bytes()
        with self.assertRaises(PermissionError):
            stage_audio_static_canary(self.root,package_relative=self.relative,current_bindings=self.bindings)
        self.assertEqual(path.read_bytes(),before)

    def test_existing_module_cli_consumes_real_reader_and_returns_blocked_exit(self):
        from hero_engine.phase5_release_gate import main
        path=self.root/'current-bindings.json';fixture.fixture.write(path,self.bindings)
        result=main(['--root',str(self.root),'--package-relative',str(self.relative),
                     '--current-bindings',str(path),'--expected-bindings-hash',fixture.fixture.voice_fixture.sha(path)])
        self.assertEqual(result,2)
        decision=fixture.fixture.read(self.package/'release_gate.json')
        self.assertEqual(decision['authorized_api_methods'],[])
        self.assertFalse(decision['publication_pipeline_permitted'])

    def test_cli_bad_binding_anchor_stops_before_persistence(self):
        from hero_engine.phase5_release_gate import main
        path=self.root/'current-bindings.json';fixture.fixture.write(path,self.bindings)
        with self.assertRaises(PermissionError):
            main(['--root',str(self.root),'--package-relative',str(self.relative),
                  '--current-bindings',str(path),'--expected-bindings-hash','sha256:'+'0'*64])
        self.assertFalse((self.package/'release_gate.json').exists())

    def test_policy_changed_after_capture_blocks_decision(self):
        from unittest.mock import patch
        from hero_engine import phase5_release_gate as module
        native=module._artifact
        cost=self.root/'output/operations/zero-cost/phase5-publication-pipeline-preflight.json'
        def mutate(root,path):
            if Path(path).name=='publication_package.json':
                fixture.fixture.write(cost,{'technical_cost_brl':1,'execution_permitted':False})
            return native(root,path)
        with patch.object(module,'_artifact',side_effect=mutate):
            with self.assertRaises(PermissionError):self.build()
