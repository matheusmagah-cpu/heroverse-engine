"""Complete synthetic metadata transaction: no native, decoder or network calls."""
from contextlib import ExitStack
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from hero_engine import phase6_av_publicity_control_recovery as Q
from hero_engine import phase6_av_publicity_control_worker as C
from hero_engine import phase6_av_publicity_runtime as R
from hero_engine import phase6_av_publicity_worker_probe as W
from hero_engine import phase6_av_detector_semantics as S


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = data if isinstance(data, bytes) else W._canonical(data)
    path.write_bytes(raw)
    return {"path": str(path), "sha256": "sha256:" + W._sha(raw), "size_bytes": len(raw)}


def plain(binding):
    return {**binding, "sha256": binding["sha256"][7:]}


class CompleteFixture:
    """Actual tiny source/runtime files and full decoded PPM buffers; no mocks of
    _prepare, _completed, _control_inputs, origin reopener or either closure.
    Only fixed roots/pins, module loading and runtime-population discovery are
    redirected to the explicitly synthetic dataset.
    """
    def __init__(self, root, stack):
        self.root = root
        self.source = root / "output/qa/phase6/diagnostics/source-failed"
        self.source.mkdir(parents=True)
        self.output = self.source.parent / "recovery"
        self.decode = root / "decode"
        self.base = root / "base"
        self.profile_path = root / "profile.json"
        self.controls, dependencies = [], []
        support = put(root / "support.txt", b"synthetic decode recipe")
        dependencies.append(plain(support))
        for original in C.CONTROLS:
            source = plain(put(root / (original["decode_id"] + ".png"), b"synthetic source " + original["decode_id"].encode()))
            dependencies.append(source)
            self.controls.append({**original, "source_path": Path(source["path"]), "source_sha256": source["sha256"]})
        decode_request = {"dependency_bindings": dependencies, "controls": []}
        decode_outputs, decode_rows = [], []
        for control, source in zip(self.controls, dependencies[1:]):
            folder = self.decode / control["decode_id"]
            width, height = control["width"], control["height"]
            pixels = b"RGB" * (width * height)
            stdout = plain(put(folder / "stdout.log", f"P6\n{width} {height}\n255\n".encode() + pixels))
            stderr = plain(put(folder / "stderr.log", b""))
            process = {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
                "assigned_before_resume": True, "kill_on_close": True, "committed_memory_limit_bytes": W.MEMORY_BYTES,
                "timeout_seconds": 30.0, "release_authority": False, "audio_approved": False,
                "logs": [{"path": x["path"], "sha256": x["sha256"], "size": x["size_bytes"]} for x in (stdout, stderr)]}
            process_binding = plain(put(folder / "process-receipt.json", process))
            row = {"control_id": control["decode_id"], "source_binding": source, "ppm_binding": stdout,
                "process_receipt_binding": process_binding, "status": "DECODED_CONTROL_NOT_DETECTOR_EVALUATED",
                "authority": C.DECODE_AUTHORITY, "command": ["SYNTHETIC_NO_CODEC"], "process": process,
                "ppm": {"width": width, "height": height, "pixel_order": "RGB24", "pixel_bytes": len(pixels),
                    "pixel_sha256": W._sha(pixels), "source_frame_index": 0, "resize_performed": False, "detector_called": False}}
            decode_rows.append(row)
            decode_outputs.extend([stdout, stderr, process_binding, plain(put(folder / "decode-report.json", row))])
            decode_request["controls"].append({"source_binding": source, "command": row["command"]})
        requested = plain(put(self.decode / "request.json", decode_request))
        decoded = {"version": "publicity-two-control-decode-v1", "kind": "PUBLICITY_CONTROL_DECODE_TERMINAL",
            "status": "CONTROLS_DECODED_NOT_EVALUATED", "error": None, "completed_decode_count": 2,
            "decode_calls_reserved": ["positive", "negative"], "authority": C.DECODE_AUTHORITY,
            "automatic_retries": 0, "cv_calls": 0, "ocr_calls": 0, "inference_calls": 0, "network_calls": 0,
            "technical_cost_brl": 0, "controls": decode_rows, "dependency_bindings": dependencies,
            "output_bindings": [requested, *decode_outputs]}
        terminal_binding = put(self.decode / "terminal.json", decoded)
        model = put(root / "model.onnx", b"synthetic model never loaded")
        for module, changes in (
            (Q, {"ROOT": root, "SOURCE": self.source}),
            (C, {"ROOT": root, "CONTROLS": tuple(self.controls), "DECODE_ROOT": self.decode,
                "DECODE_TERMINAL": self.decode / "terminal.json", "DECODE_TERMINAL_SHA": terminal_binding["sha256"][7:],
                "DECODE_DEPENDENCY_PATHS": tuple(Path(x["path"]) for x in dependencies), "MODEL_PINS": {"model.onnx": model["sha256"][7:]}}),
            (R, {"CODE_ROOT": root, "BASE_PYTHON": self.base}),
            (W, {"ROOT": root, "PROFILE_PATH": self.profile_path}),
            (S, {"POSITIVE_SHA": "sha256:" + self.controls[0]["source_sha256"],
                 "NEGATIVE_SHA": "sha256:" + self.controls[1]["source_sha256"]}),
        ):
            for key, value in changes.items():
                stack.enter_context(patch.object(module, key, value))
        self.empty = put(self.base / "Lib/urllib/__init__.py", b"")
        self.module_binding = put(self.base / "module.py", b"# synthetic origin, never executed\n")
        self.profile = {"kind": R.PROFILE_KIND, "version": R.VERSION, "project_root": str(root),
            "base_python": str(self.base), "site_packages": str(root / ".venv/Lib/site-packages"),
            "ffmpeg_directory": str(R.FFMPEG_DIRECTORY), "authority": R.AUTHORITY, "technical_cost_brl": 0,
            "file_bindings": [self.empty, self.module_binding], "population": {"directories": [str(self.base)]}}
        profile_binding = put(self.profile_path, self.profile)
        stack.enter_context(patch.object(W, "PROFILE_SHA", profile_binding["sha256"][7:]))
        stack.enter_context(patch.object(W, "PROFILE_SIZE", profile_binding["size_bytes"]))
        stack.enter_context(patch.object(R, "_population", return_value=self.profile["population"]))
        stack.enter_context(patch.object(Q, "_dependencies", return_value=(C, W, R)))
        stack.enter_context(patch.object(W, "_load", side_effect=lambda path, digest, name: S if path == C.SEMANTICS and digest == C.SEMANTICS_SHA else (_ for _ in ()).throw(AssertionError("unexpected helper import"))))
        context = C._control_inputs(W, R)
        self.request = {"version": C.VERSION, "root": str(root), "profile_binding": profile_binding,
            "code_bindings": C._codes(W, Q.LEGACY_SHA, Q.LEGACY_TEST_SHA), "run_directory": str(self.source),
            "memory_bytes": W.MEMORY_BYTES, "timeout_seconds": W.TIMEOUT_SECONDS, "authority": C.AUTHORITY,
            "technical_cost_brl": 0, **{k: context[k] for k in ("controls", "decode_terminal_binding", "model_bindings")},
            "model_loading": C.MODEL_LOADING, "settings": S.SETTINGS}
        request_binding = put(self.source / "request.json", self.request)
        observations, outputs = [], []
        for index, control in enumerate(context["controls"]):
            raw = {"settings": S.SETTINGS, "input_size": [512, 512] if index == 0 else [1280, 720],
                "opencv_version": "5.0.0", "retval": 1,
                "detections": [[190, 75, 100, 100, *([100] * 10), .99]] if index == 0 else None}
            started = {"version": C.VERSION, "control": control, "settings": S.SETTINGS,
                "inference_reserved": True, "authority": C.AUTHORITY}
            outputs.extend([put(self.source / (control["control_id"] + "-started.json"), started),
                            put(self.source / (control["control_id"] + "-raw.json"), raw)])
            observations.append({"control_id": control["control_id"], "source_sha256": "sha256:" + control["source_binding"]["sha256"],
                "width": control["width"], "height": control["height"], "raw": raw, "observed_opencv_version": "5.0.0"})
        self.origins = {"modules": [{"module": name, "file_binding": self.module_binding, "cache_binding": None,
            "support_bindings": []} for name in ("cv2", "numpy", "numpy._core._multiarray_umath")], "absent_cache_paths": []}
        self.origins["modules"].append({"module": "urllib", "file_binding": self.empty, "cache_binding": None, "support_bindings": []})
        evaluation = S.evaluate_controls(observations)
        self.report = {"version": C.VERSION, "status": evaluation["status"], "request_binding": request_binding,
            **{k: self.request[k] for k in ("profile_binding", "code_bindings", "decode_terminal_binding", "model_bindings", "model_loading")},
            "startup": {"fixture": True}, "containment": {"fixture": True},
            "native_observation": {"opencv_native_version": "5.0.0", "numpy_version": "2.5.2"}, "origins": self.origins,
            "file_validation": {"status": "FILE_PROFILE_VALIDATED_NOT_ADMITTED", "authority": R.AUTHORITY},
            "profile_validation_calls": 1, "observations": observations, "evaluation": evaluation, "output_bindings": outputs,
            "inference_calls": 2, "decode_calls": 0, "network_calls": 0, "technical_cost_brl": 0, "authority": C.AUTHORITY,
            "elapsed_seconds": .01, "limitations": C.LIMITATIONS}
        report_binding = put(self.source / "controls.json", self.report)
        stdout = put(self.source / "process/stdout.log", W._canonical({"controls_sha256": report_binding["sha256"][7:]}) + b"\n")
        stderr = put(self.source / "process/stderr.log", b"[WARN] synthetic logged warning, preserved exactly\n")
        process = {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
            "assigned_before_resume": True, "kill_on_close": True, "committed_memory_limit_bytes": W.MEMORY_BYTES,
            "timeout_seconds": float(W.TIMEOUT_SECONDS), "error": None, "release_authority": False, "audio_approved": False,
            "version": "audio-perception-supervisor-windows-v2", "child_pid": 1234,
            "containment_job_created_new": True, "containment_job_name": "Local\\SyntheticFixtureOnly-NoNativeProcess",
            "duration_seconds": 1.0, "log_size_polling_cap_bytes": 1048576,
            "memory_limit_kind": "WINDOWS_JOB_COMMITTED_MEMORY", "peak_job_commit_bytes": 4096,
            "process_count_observed": 1, "worker_job_binding": "EXPLICIT_NAMED_JOB_MEMBERSHIP_AND_LIMITS",
            "started_at": "2000-01-01T00:00:00+00:00", "finished_at": "2000-01-01T00:00:01+00:00",
            "logs": [{"path": x["path"], "sha256": x["sha256"][7:], "size": x["size_bytes"]} for x in (stdout, stderr)]}
        put(self.source / "process/process-receipt.json", process)
        self.terminal = {"version": C.VERSION, "status": "CONTROL_WORKER_FAILED_NOT_ADMITTED", "process": process,
            "request_binding": request_binding, "controls_binding": None, "authority": C.AUTHORITY,
            "technical_cost_brl": 0, "error": Q.EXPECTED_ERROR, "automatic_retries": 0}
        put(self.source / "terminal.json", self.terminal)
        put(self.source / "problem.json", self.terminal)
        self.pins = {name: W._sha((self.source / name).read_bytes()) for name in Q.SOURCE_PINS}
        stack.enter_context(patch.object(Q, "SOURCE_PINS", self.pins))
        self.original_bytes = {p.relative_to(self.source).as_posix(): p.read_bytes() for p in self.source.rglob("*") if p.is_file()}
        self.guards = []
        for module, name in ((R, "validate_profile"), (R, "build_profile"), (C, "_infer_raw"), (C, "_worker"), (W, "_supervisor")):
            self.guards.append(stack.enter_context(patch.object(module, name, side_effect=AssertionError("native/profile operation forbidden"))))


class ControlRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.fixture = CompleteFixture(Path(self.tmp.name), self.stack)
        self.args = {"root": self.fixture.root, "expected_module_sha": W._sha(Q.MODULE.read_bytes()),
            "expected_test_sha": W._sha(Q.TEST.read_bytes()), "run_directory": self.fixture.output}

    def test_full_transaction_empty_stdlib_source_warning_and_replay_preserve_original_failure(self):
        result = Q.recover(**self.args, commit=True)
        self.assertEqual(result["status"], "PASS_OPERATIONAL_CONTROLS_ONLY")
        self.assertEqual(result["recovery_kind"], "CHECKPOINT_RECOVERY")
        self.assertFalse(any(result["authority"].values()))
        self.assertEqual(result["empty_source_exception"], self.fixture.empty)
        self.assertEqual(result["original_terminal_status"], "CONTROL_WORKER_FAILED_NOT_ADMITTED")
        self.assertEqual(result["original_inference_calls"], 2)
        self.assertEqual(result["recovery_inference_calls"], 0)
        process_path = self.fixture.source / "process/process-receipt.json"
        self.assertEqual(R._json(process_path.read_bytes()), result["original_process"])
        self.assertIn(W._binding(process_path, W._sha(process_path.read_bytes())), result["source_bindings"])
        binding = W._binding(self.fixture.output / "receipt.json", W._sha((self.fixture.output / "receipt.json").read_bytes()))
        replayed = Q.verify_recovery(self.fixture.root, receipt_binding=binding,
            expected_module_sha=self.args["expected_module_sha"], expected_test_sha=self.args["expected_test_sha"])
        self.assertEqual(result, replayed)
        self.assertEqual((self.fixture.source / "process/stderr.log").read_bytes(), b"[WARN] synthetic logged warning, preserved exactly\n")
        after = {p.relative_to(self.fixture.source).as_posix(): p.read_bytes() for p in self.fixture.source.rglob("*") if p.is_file()}
        self.assertEqual(after, self.fixture.original_bytes)
        for guard in self.fixture.guards:
            guard.assert_not_called()

    def test_preflight_writes_nothing_and_duplicate_commit_does_not_overwrite(self):
        self.assertEqual(Q.recover(**self.args)["files_written"], 0)
        self.assertFalse(self.fixture.output.exists())
        Q.recover(**self.args, commit=True)
        original = (self.fixture.output / "receipt.json").read_bytes()
        with self.assertRaisesRegex(ValueError, "collision"):
            Q.recover(**self.args, commit=True)
        self.assertEqual((self.fixture.output / "receipt.json").read_bytes(), original)

    def test_extra_failure_or_output_blocks_without_new_receipt(self):
        for name in ("failure.json", "final-problem.json", "unrecognized.json", "process/unexpected-receipt.json"):
            path = self.fixture.source / name
            put(path, b"{}")
            with self.assertRaisesRegex(ValueError, "inventory differs"):
                Q.recover(**self.args, commit=True)
            self.assertFalse(self.fixture.output.exists())
            path.unlink()

    def test_missing_supervisor_receipt_is_rejected_before_recovery_output(self):
        (self.fixture.source / "process/process-receipt.json").unlink()
        with self.assertRaisesRegex(ValueError, "inventory differs"):
            Q.recover(**self.args, commit=True)
        self.assertFalse(self.fixture.output.exists())

    def test_tampered_supervisor_receipt_is_rejected_by_external_pin(self):
        path = self.fixture.source / "process/process-receipt.json"
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "evidence pin differs: process/process-receipt.json"):
            Q.recover(**self.args, commit=True)
        self.assertFalse(self.fixture.output.exists())

    def test_repinned_supervisor_receipt_must_equal_every_original_process_field(self):
        name = "process/process-receipt.json"
        changed = deepcopy(self.fixture.terminal["process"])
        changed["child_pid"] += 1
        self.fixture.pins[name] = put(self.fixture.source / name, changed)["sha256"][7:]
        with self.assertRaisesRegex(ValueError, "complete original process"):
            Q.recover(**self.args, commit=True)
        self.assertFalse(self.fixture.output.exists())

    def test_supervisor_receipt_drift_is_rejected_by_final_closure(self):
        _, _, _, _, close = Q._prepare(self.fixture.root, self.args["expected_module_sha"], self.args["expected_test_sha"])
        path = self.fixture.source / "process/process-receipt.json"
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaises(ValueError):
            close()

    def test_wrong_error_even_when_both_failure_documents_repin_is_rejected(self):
        bad = deepcopy(self.fixture.terminal)
        bad["error"] = {"type": "RuntimeError", "message": "unrelated failure"}
        for name in ("terminal.json", "problem.json"):
            self.fixture.pins[name] = put(self.fixture.source / name, bad)["sha256"][7:]
        with self.assertRaisesRegex(ValueError, "exact parent-close failure"):
            Q.recover(**self.args, commit=True)

    def test_report_pin_and_implementation_pin_fail_closed(self):
        with self.assertRaises(ValueError):
            Q.recover(**{**self.args, "expected_module_sha": "0" * 64}, commit=True)
        path = self.fixture.source / "controls.json"
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "evidence pin"):
            Q.recover(**self.args, commit=True)
        self.assertFalse(self.fixture.output.exists())

    def test_raw_or_reservation_drift_is_not_hidden_by_successful_report(self):
        for suffix in ("-raw.json", "-started.json"):
            path = self.fixture.source / ("frontal-astronaut" + suffix)
            before = path.read_bytes()
            path.write_bytes(before + b" ")
            with self.assertRaises(ValueError):
                Q.recover(**self.args, commit=True)
            self.assertFalse(self.fixture.output.exists())
            path.write_bytes(before)

    def test_empty_exception_rejects_cache_support_other_module_path_bool_and_binary(self):
        original = deepcopy(self.fixture.origins)
        altered = []
        for field in ("cache_binding", "support_bindings"):
            rows = deepcopy(original)
            row = rows["modules"][-1]
            row["file_binding"] = None
            row[field] = [self.fixture.empty] if field == "support_bindings" else self.fixture.empty
            altered.append(rows)
        rows = deepcopy(original); rows["modules"][-1]["module"] = "urllib.fake"; altered.append(rows)
        rows = deepcopy(original); rows["modules"][-1]["file_binding"]["path"] += ".fake.py"; altered.append(rows)
        rows = deepcopy(original); rows["modules"][-1]["file_binding"]["size_bytes"] = False; altered.append(rows)
        rows = deepcopy(original); rows["modules"][-1]["file_binding"]["path"] = str(self.fixture.base / "empty.dll"); altered.append(rows)
        for origins in altered:
            with self.subTest(origins=origins["modules"][-1]), self.assertRaises(ValueError):
                Q._reopen_origins(W, R, self.fixture.profile, self.fixture.request, origins)

    def test_empty_source_must_be_present_in_profile_and_remain_empty(self):
        profile = deepcopy(self.fixture.profile)
        profile["file_bindings"] = [self.fixture.module_binding]
        with self.assertRaisesRegex(ValueError, "authenticated by profile"):
            Q._reopen_origins(W, R, profile, self.fixture.request, self.fixture.origins)
        files, _ = Q._reopen_origins(W, R, self.fixture.profile, self.fixture.request, self.fixture.origins)
        Path(self.fixture.empty["path"]).write_bytes(b"drift")
        with self.assertRaises(ValueError):
            files.recheck()

    def test_late_close_failure_writes_separate_problem_and_replay_rejects_it(self):
        with patch.object(Q, "_receipt_inventory", side_effect=ValueError("late receipt boundary failure")):
            with self.assertRaisesRegex(ValueError, "late receipt boundary"):
                Q.recover(**self.args, commit=True)
        receipt_path = self.fixture.output / "receipt.json"
        self.assertTrue((self.fixture.output / "problem.json").is_file())
        with self.assertRaisesRegex(ValueError, "failure marker"):
            Q.verify_recovery(self.fixture.root, receipt_binding=W._binding(receipt_path, W._sha(receipt_path.read_bytes())),
                expected_module_sha=self.args["expected_module_sha"], expected_test_sha=self.args["expected_test_sha"])
        self.assertEqual((self.fixture.source / "terminal.json").read_bytes(), self.fixture.original_bytes["terminal.json"])

    def test_stderr_drift_or_decode_failure_marker_blocks_recovery(self):
        stderr = self.fixture.source / "process/stderr.log"
        before = stderr.read_bytes()
        stderr.write_bytes(b"suppressed warning")
        with self.assertRaises(ValueError):
            Q.recover(**self.args, commit=True)
        stderr.write_bytes(before)
        put(self.fixture.decode / "problem.json", b"{}")
        with self.assertRaisesRegex(ValueError, "failure artifacts"):
            Q.recover(**self.args, commit=True)


if __name__ == "__main__":
    unittest.main()
