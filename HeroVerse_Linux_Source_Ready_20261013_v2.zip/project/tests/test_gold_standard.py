import hashlib
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[1]
GOLD = ROOT / "data" / "gold_standard"
IDS = ("hkf6nDyUfAM", "_sOy7htXJi8", "Pkede5acSFw", "huvUy3pJSp8")
ROLES = ("winner_primary", "winner_recent", "median", "weak")


def load(video_id: str):
    return json.loads((GOLD / video_id / "video_mining.json").read_text(encoding="utf-8"))


class GoldStandardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema = json.loads((ROOT / "schemas" / "video_mining.schema.json").read_text(encoding="utf-8"))

    def test_exact_approved_sample_and_roles(self):
        manifest = json.loads((GOLD / "gold_standard_manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(tuple(item["video_id"] for item in manifest["items"]), IDS)
        self.assertEqual(tuple(item["role"] for item in manifest["items"]), ROLES)

    def test_every_fixture_validates_against_draft_2020_12(self):
        validator = Draft202012Validator(self.schema, format_checker=FormatChecker())
        for video_id in IDS:
            with self.subTest(video_id=video_id):
                errors = list(validator.iter_errors(load(video_id)))
                self.assertEqual(errors, [])

    def test_hooks_and_take_evidence_are_complete(self):
        expected_windows = ["0_1S", "1_3S", "3_8S", "8_30S"]
        total_takes = 0
        for video_id in IDS:
            fixture = load(video_id)
            candidates = json.loads((GOLD / video_id / "take_candidates.json").read_text(encoding="utf-8"))
            self.assertEqual([hook["window"] for hook in fixture["hooks"]], expected_windows)
            self.assertEqual(len(fixture["takes"]), candidates["candidate_count"])
            total_takes += len(fixture["takes"])
            for take in fixture["takes"]:
                self.assertGreater(take["duration_ms"], 0)
                self.assertTrue(take["objective_description"].startswith("Quadro central revisado"))
                for artifact in take["keyframes"]:
                    self.assertTrue((ROOT / artifact).is_file(), artifact)
        self.assertEqual(total_takes, 256)

    def test_source_hashes_and_rights_gate(self):
        for video_id in IDS:
            fixture = load(video_id)
            source = ROOT / fixture["collection"]["input_artifact"]
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            self.assertEqual(digest, fixture["source"]["content_hash"])
            self.assertEqual(fixture["rights"]["status"], "EDITORIAL_REVIEW_REQUIRED")
            self.assertFalse(fixture["rights"]["production_eligible"])
            self.assertFalse(fixture["public_performance"]["private_metrics_claimed"])

    def test_declared_winner_and_weak_openings_are_not_flattened(self):
        winner = load("hkf6nDyUfAM")
        weak = load("huvUy3pJSp8")
        self.assertIn("ALTO", winner["packaging"]["opening_alignment"]["value"])
        self.assertIn("BAIXO", weak["packaging"]["opening_alignment"]["value"])
        self.assertIn("41 s", weak["hooks"][3]["promise_break_risk"])
        self.assertNotEqual(winner["content_analysis"]["angle"]["value"], weak["content_analysis"]["angle"]["value"])

    def test_independent_validation_report_passes(self):
        report = json.loads((GOLD / "validation_report.json").read_text(encoding="utf-8"))
        self.assertTrue(report["passed"])
        self.assertEqual(report["totals"]["videos"], 4)
        self.assertEqual(report["totals"]["takes"], 256)
        self.assertEqual(report["totals"]["schema_failures"], 0)
        self.assertEqual(report["totals"]["unresolved_evidence"], 0)
        self.assertEqual(report["totals"]["rights_blocked"], 4)

    def test_integrity_manifest_covers_and_matches_all_evidence_files(self):
        manifest = json.loads((GOLD / "integrity_manifest.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(manifest["item_count"], 280)
        entries = {item["artifact"]: item for item in manifest["entries"]}
        for video_id in IDS:
            required = [
                f"data/modeling/grace-grit-love/full/{video_id}.mp4",
                f"data/modeling/grace-grit-love/full/{video_id}.jpg",
                f"data/gold_standard/{video_id}/transcript.raw.json",
                f"data/gold_standard/{video_id}/transcript.reviewed.json",
                f"data/gold_standard/{video_id}/video_mining.json",
            ]
            for artifact in required:
                self.assertIn(artifact, entries)
                path = ROOT / artifact
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), entries[artifact]["sha256"])


if __name__ == "__main__":
    unittest.main()
