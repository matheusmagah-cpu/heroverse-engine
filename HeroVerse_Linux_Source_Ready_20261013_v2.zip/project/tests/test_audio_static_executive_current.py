"""Existing observer -> current executive; native readers, simulated provider."""
import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_reporting as reporting, central_manager_phase5 as manager
from hero_engine import phase6_acceptance as acceptance
from hero_engine import phase6_control_cycle as cycles
from hero_engine.phase6_maintenance_verification import verify_control_cycle_sources
from hero_engine import phase6_maintenance_verification as d116
from tests import test_audio_static_observer_queue as observer


class AudioStaticExecutiveCurrentTests(unittest.TestCase):
    def test_public_report_uses_completed_current_producers_not_historical_aliases(self):
        owner=observer.AudioStaticObserverQueueTests('test_unknown_collection_result_cannot_retry_the_same_query')
        owner.cycle_schema_fixture=True
        self.addCleanup(owner.doCleanups);owner.setUp()
        shutil.copy2(observer.ready.ROOT/'schemas/phase6_executive_status.schema.json',owner.root/'schemas')
        shutil.copy2(observer.ready.ROOT/'schemas/phase6_acceptance_report.schema.json',owner.root/'schemas')
        for name in ('phase6_control_cycle_receipt','narrative_script','take_plan','voice_render_manifest',
                     'format_pack','creative_direction_decision','render_manifest','creative_quality_gate_report',
                     'phase6_post_maintenance_verification'):
            shutil.copy2(observer.ready.ROOT/f'schemas/{name}.schema.json',owner.root/'schemas')
        old=owner.root/'output/operations/phase6/executive-status.json'
        old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(b'{"historical":"preserve"}')
        before_old=old.read_bytes();target=owner.video
        class CurrentYouTube(observer.provider.YouTube):
            def list(self,**kwargs):
                response=super().list(**kwargs)
                if self.resource=='videos':response.response['items'][0]['id']=target
                return response
        with patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(manager,'ensure_oauth_session_health',return_value={'status':'HEALTHY'}), \
             patch.object(observer.pilot,'_build_services',return_value=(CurrentYouTube(),observer.provider.Analytics())) as provider:
            collected=owner.call();self.assertEqual(collected['status'],'COLLECTED',collected)
            calls=provider.call_count
            paths=reporting.materialize(owner.root,**owner.selection)
            self.assertEqual(provider.call_count,calls)
        self.assertEqual(paths[0],owner.package/'intelligence/executive-status.json')
        value=json.loads(paths[0].read_bytes())
        self.assertEqual(value['current_delivery']['video_id'],target)
        self.assertEqual(value['current_delivery']['publication_status'],'COMPLETE_PUBLIC')
        self.assertEqual(value['current_delivery']['prediction_status'],'WITHHELD_INSUFFICIENT_CALIBRATION')
        self.assertNotEqual(value['current_delivery']['experiment_status'],'PREREGISTERED')
        self.assertNotIn('canary',value);self.assertNotIn('producer_binding',value)
        self.assertNotIn('control_cycle',value)
        self.assertEqual(old.read_bytes(),before_old)
        self.assertTrue(paths[1].is_file())
        started=datetime.fromisoformat(value['captured_at'].replace('Z','+00:00'))
        current_cycle=cycles.materialize(owner.root,cycle_started_at=started,cycle_completed_at=None,**owner.selection)
        verify_control_cycle_sources(owner.root,current_cycle)
        self.assertEqual(current_cycle['stage_count'],12)
        self.assertEqual(current_cycle['decision'],'PASS_WAITING')
        self.assertEqual(current_cycle['source_candidate_sha256'],value['source_candidate_sha256'])
        accepted_paths=acceptance.materialize(owner.root,**owner.selection)
        accepted=json.loads(accepted_paths[0].read_bytes())
        self.assertEqual(accepted_paths[0],owner.package/'intelligence/acceptance-report.json')
        self.assertEqual(accepted['current_delivery'],value['current_delivery'])
        self.assertEqual(accepted['source_candidate_sha256'],value['source_candidate_sha256'])
        self.assertEqual(accepted['current_executive_evidence']['sha256'],
            'sha256:'+hashlib.sha256(paths[0].read_bytes()).hexdigest())
        self.assertEqual(len(accepted['checks']),22)
        self.assertFalse(accepted['current_phase_ready'])
        self.assertEqual(accepted['checks'][4]['status'],'PASS_LIVE')
        self.assertEqual(accepted['checks'][19]['status'],'PASS_LIVE')
        self.assertEqual(accepted['control_cycle_evidence']['cycle_id'],current_cycle['cycle_id'])
        for index in (0,10,18):self.assertEqual(accepted['checks'][index]['status'],'WAITING_REAL_EVIDENCE')
        self.assertFalse((owner.root/acceptance.OUTPUT).exists())
        Draft202012Validator(json.loads((owner.root/'schemas/phase6_acceptance_report.schema.json').read_bytes())).validate(accepted)
        self._check_selected_d116_evaluator(owner, value, current_cycle, accepted)
        # The public D116 source reader authenticates exact immutable bytes;
        # later latest/report mutation cannot turn an old cycle into current.
        snapshot=owner.root/current_cycle['stages'][-1]['snapshot_path'];raw=snapshot.read_bytes()
        snapshot.write_bytes(raw+b' ')
        with self.assertRaises(PermissionError):verify_control_cycle_sources(owner.root,current_cycle)
        snapshot.write_bytes(raw)
        changed_cycle=copy.deepcopy(current_cycle);changed_cycle['source_candidate_sha256']='0'*64
        with self.assertRaises(PermissionError):cycles.verify_audio_cycle_sources(owner.root,changed_cycle,value)
        for item in value['producer_receipts'].values():
            self.assertEqual(item['sha256'],'sha256:'+hashlib.sha256((owner.root/item['path']).read_bytes()).hexdigest())
        schema=json.loads((owner.root/'schemas/phase6_executive_status.schema.json').read_bytes())
        for mutation in ('old_version','canary','producer_binding'):
            mixed=copy.deepcopy(value)
            if mutation=='old_version':mixed['schema_version']='1.0.0'
            else:mixed[mutation]=None
            with self.subTest(mutation=mutation),self.assertRaises(ValidationError):
                Draft202012Validator(schema).validate(mixed)
        # A stale/wrong producer prevents the public writer replacing the view.
        observed=owner.package/'observer-status.json';saved=observed.read_bytes()
        wrong=json.loads(saved);wrong['video_id']='iK_5edYQtx8';observed.write_text(json.dumps(wrong))
        report_before=paths[0].read_bytes()
        with self.assertRaises(PermissionError):reporting.materialize(owner.root,**owner.selection)
        self.assertEqual(paths[0].read_bytes(),report_before);observed.write_bytes(saved)
        changed=json.loads(report_before);changed['current_delivery']['video_id']='historical-video'
        paths[0].write_text(json.dumps(changed))
        before_accept=accepted_paths[0].read_bytes()
        with self.assertRaises(PermissionError):acceptance.materialize(owner.root,**owner.selection)
        self.assertEqual(accepted_paths[0].read_bytes(),before_accept);paths[0].write_bytes(report_before)
        # A changed externally anchored gate also cannot generate a new report.
        release=owner.package/'release_gate.json';saved=release.read_bytes();release.write_bytes(saved+b' ')
        with self.assertRaises(PermissionError):reporting.materialize(owner.root,**owner.selection)
        self.assertEqual(paths[0].read_bytes(),report_before);release.write_bytes(saved)
        self.assertEqual(old.read_bytes(),before_old)

    def _check_selected_d116_evaluator(self, owner, executive, cycle, acceptance_value):
        """Core post-authentication consumer, NOT a live application/restart.

        Application/runtime and acceptance engineering witnesses are synthetic.
        The report, release and twelve stage snapshots above are native outputs;
        separate paused integration tests exercise historical authentication.
        No public caller may supply this internal application attestation.
        """
        begin=datetime.fromisoformat(cycle['cycle_started_at'].replace('Z','+00:00'))
        end=datetime.fromisoformat(cycle['cycle_completed_at'].replace('Z','+00:00'))
        reference=Path('output/runtime/gestor-central/maintenance-runs/direct-application-reference-fixture/paused-application-reference.json')
        paths=d116._delivery_paths(owner.root,owner.selection['package_relative'])
        receipt=copy.deepcopy(acceptance_value)
        for check in receipt['checks']:
            check['status']='WAITING_REAL_EVIDENCE' if check['check_id'] in d116.EXPECTED_PENDING_CHECKS else 'PASS_LIVE'
        receipt.update(blocking_check_ids=sorted(d116.EXPECTED_PENDING_CHECKS),phase_decision='IN_PROGRESS',current_phase_ready=False)
        observed=end+timedelta(seconds=1)
        runtime=dict(schema_version='1.1.0',manager_pid=4242,manager_alive=True,task_state='Running',
            lock_state='HELD',lock_holder_pid=4242,review_process_id=4242,review_console_status='LISTENING',
            same_process_chain=True,duplicate_probe_exit_code=73,duplicate_probe_blocked=True,
            active_stderr_bytes=0,power_continuity_status='PASS',continuous_awake=True,operational_ready=True,
            verified_at=observed.isoformat(),lock_heartbeat_at=end.isoformat(),lease_expires_at=(observed+timedelta(seconds=60)).isoformat(),
            process_identity=dict(pid=4242,parent_pid=4241,started_at=(begin-timedelta(seconds=1)).isoformat(),
                executable_path_sha256='sha256:'+'a'*64,command_sha256='sha256:'+'b'*64,stable_across_probe=True))
        app=dict(application_id='fixture-app',completed_at=(begin-timedelta(seconds=2)).isoformat(),
            regression_completed_at=(begin-timedelta(seconds=3)).isoformat(),regression=dict(status='PASS',test_count=2),
            receipt=dict(migration={}),reference=dict(reference_kind='DIRECT_PROTOCOL',
                commit_path='output/runtime/gestor-central/maintenance-runs/maintenance-request-20261005T1800000000000Z-12345678/committed.json',
                commit_sha256='sha256:'+'a'*64,proof_path='output/runtime/gestor-central/maintenance-runs/fixture/application-envelope.json',
                proof_sha256='sha256:'+'b'*64,candidate_sha256=executive['source_candidate_sha256']))
        hashes={reference:'sha256:'+'c'*64,d116.AUTOSTART_PATH:'sha256:'+'d'*64,
                paths[0]:'sha256:'+hashlib.sha256((owner.root/paths[0]).read_bytes()).hexdigest(),
                paths[1]:'sha256:'+hashlib.sha256(json.dumps(receipt).encode()).hexdigest(),
                paths[2]:'sha256:'+hashlib.sha256((owner.root/paths[2]).read_bytes()).hexdigest()}
        arguments=dict(maintenance={},autostart=runtime,cycle=cycle,acceptance=receipt,executive=executive,
            verified_at=observed+timedelta(seconds=1),source_hashes=hashes,paused_application_reference=reference,
            expected_reference_hash=hashes[reference],application=app,package_relative=owner.selection['package_relative'])
        result=d116._evaluate_observed(owner.root,**arguments)
        self.assertEqual(result['schema_version'],'1.3.0')
        self.assertEqual(result['control_cycle']['path'],paths[0].as_posix())
        schema=json.loads((owner.root/'schemas/phase6_post_maintenance_verification.schema.json').read_bytes())
        Draft202012Validator(schema).validate(result)
        mixed=copy.deepcopy(result);mixed['schema_version']='1.2.0'
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(mixed)
        for field in ('source_candidate_sha256','current_delivery','current_executive_evidence'):
            wrong=copy.deepcopy(receipt)
            wrong[field]='0'*64 if field=='source_candidate_sha256' else {}
            with self.subTest(field=field),self.assertRaises(PermissionError):
                d116._evaluate_observed(owner.root,**{**arguments,'acceptance':wrong})
        with self.assertRaises(PermissionError):
            d116.build(owner.root,package_relative=owner.selection['package_relative'])
        with self.assertRaises(PermissionError):
            d116.build(owner.root,package_relative=Path('output/production/../operations'),
                        paused_application_reference=reference,expected_reference_hash=hashes[reference])

    def test_partial_selection_and_overrides_fail_before_any_report_write(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with self.assertRaises(PermissionError):reporting.materialize(root,package_relative=Path('output/production/current'))
            with self.assertRaises(PermissionError):
                reporting.build_status(root,package_relative=Path('output/production/current'),
                    current_bindings={},expected_release_hash='sha256:'+'0'*64,
                    goal_trajectory_override={'status':'PASS'})
            self.assertEqual(list(root.iterdir()),[])
