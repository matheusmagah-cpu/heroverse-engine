"""Temporary physical JSON inputs; preserved historical inputs are read-only.

This helper supplies test transport only. Product readers, canonical-byte/hash
validation, schemas, source inspectors and dependency rechecks remain real.
"""
import copy
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch


HISTORICAL_PRODUCTION_ARCHIVE = (
    "output/operations/phase6/release/production-artifact-archives/"
    "phase6-production-inputs-79b3e183dd5df410fb3a"
)
HISTORICAL_PRODUCTION_INPUTS = {
    "output/production/phase6/video-002/production/take_plan.json": (
        HISTORICAL_PRODUCTION_ARCHIVE + "/take_plan.json",
        "547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5",
    ),
    "output/production/phase6/video-002/production/channel_style_bible.json": (
        HISTORICAL_PRODUCTION_ARCHIVE + "/channel_style_bible.json",
        "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049",
    ),
    "output/production/phase6/video-002/production/creative_treatment_plan.json": (
        HISTORICAL_PRODUCTION_ARCHIVE + "/creative_treatment_plan.json",
        "3ae77eb015cd2364f1741b016a3520b0d51e5c68c41c3a5f5bfea890da1120db",
    ),
    "output/production/phase6/video-002/production/asset_allocation.json": (
        HISTORICAL_PRODUCTION_ARCHIVE + "/asset_allocation.json",
        "9c8fc78db5fe9ea93430e9cfaacb2a497b85ee4e68f161a78974880770b0cbef",
    ),
}


@contextmanager
def archived_historical_production_inputs(sources):
    """Read only explicit old pins from the release archive in a test.

    Historical receipts retain their old logical paths; this transport helper
    never accepts a new digest and never changes production readers.
    """
    original = sources._Reader.read
    original_read_path = sources._Reader.read_path

    def record_logical(reader, relative, expected_sha, raw):
        archived_key = str(reader.path(HISTORICAL_PRODUCTION_INPUTS[relative][0]))
        reader.bindings.pop(archived_key, None)
        logical_key = str(reader.path(relative))
        binding = {"path": logical_key, "sha256": expected_sha, "size_bytes": len(raw)}
        old = reader.bindings.setdefault(logical_key, binding)
        sources._same(old, binding, "dependency identity differs")

    def read(reader, relative, expected_sha, *, limit=16 * 1024**2):
        relocation = HISTORICAL_PRODUCTION_INPUTS.get(relative)
        if relocation is not None and expected_sha == relocation[1]:
            raw = original(reader, relocation[0], expected_sha, limit=limit)
            # The replay's provenance is deliberately still the historical
            # logical location.  Replace only test-local reader bookkeeping;
            # source bytes are the archived digest and no receipt is edited.
            record_logical(reader, relative, expected_sha, raw)
            return raw
        return original(reader, relative, expected_sha, limit=limit)

    def read_path(reader, path, expected_sha, *, limit=16 * 1024**2):
        candidate = Path(path).resolve()
        for relative, (archived, digest) in HISTORICAL_PRODUCTION_INPUTS.items():
            if candidate == reader.path(relative) and expected_sha == digest:
                raw = original_read_path(reader, reader.path(archived), expected_sha, limit=limit)
                record_logical(reader, relative, expected_sha, raw)
                return raw
        return original_read_path(reader, path, expected_sha, limit=limit)

    with patch.object(sources._Reader, "read", read), patch.object(sources._Reader, "read_path", read_path):
        yield


@contextmanager
def archived_historical_inventory_inputs(inventory):
    """Test-only transport for the PCM inventory's frozen logical inputs.

    The production inventory reader remains strict: it never relocates a
    current path.  A historical replay can opt in here only with the exact
    archived digest already recorded in its immutable receipt.
    """
    original = inventory.Reader.read

    def read(reader, value, expected=None, *, within=None):
        relocation = HISTORICAL_PRODUCTION_INPUTS.get(value)
        if relocation is None or expected != "sha256:" + relocation[1]:
            return original(reader, value, expected, within=within)
        archive, digest = relocation
        raw = original(reader, archive, "sha256:" + digest, within=within)
        archive_key = (reader.root / archive).resolve().relative_to(reader.root).as_posix()
        reader.bindings.pop(archive_key, None)
        logical = (reader.root / value).resolve().relative_to(reader.root).as_posix()
        binding = {"path": logical, "sha256": "sha256:" + digest, "size_bytes": len(raw)}
        prior = reader.bindings.setdefault(logical, binding)
        if prior != binding:
            raise ValueError("historical inventory source changed during replay")
        return raw

    with patch.object(inventory.Reader, "read", read):
        yield


def historical_input(test, sources, root, binding, expected_document):
    raw = sources._Reader(root).read(binding["path"], binding["sha256"])
    test.assertEqual(raw, sources._canonical(expected_document))
    return copy.deepcopy(binding)


def install_schema(test, sources, source_root, fixture_root, relative):
    test.assertFalse(fixture_root.is_relative_to(source_root))
    original = source_root / relative
    target = fixture_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = original.read_bytes()
    target.write_bytes(raw)
    test.assertEqual(target.read_bytes(), raw)
    return sources._sha(raw)


def fixture_reader(sources, root, schema, schema_sha):
    reader = sources._Reader(root)
    reader.read(schema, schema_sha)
    return reader
