"""Pinned metadata/container integration; no OCR, pixel decode or media rerender.

Synthetic PNG envelopes below deliberately contain non-decodable IDAT bytes.
They exercise only the typed container contract and are never media evidence.
"""
import copy
import json
from pathlib import Path
import struct
import unittest
from unittest.mock import patch
import zlib

from hero_engine import phase6_av_question_sources as question
from tests.static_input_isolation import archived_historical_production_inputs

ROOT = Path(__file__).absolute().parents[1]
P = question.primitives


def request(sid="visual-u020-s01"):
    return {"template_id": question.TEMPLATE_ID, "state_id": sid,
        "receipt_binding": {"path": question.CONFIG["directory"] + "/receipt.json", "sha256": question.CONFIG["receipt_sha256"]}}


def chunk(kind, payload):
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xffffffff)


def envelope(*, header=(1920, 1080, 8, 2, 0, 0, 0), extra=b"", idat=b"EXPLICIT_NONDECODABLE_CONTAINER_FIXTURE", end=True):
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", *header)) + extra
        + chunk(b"IDAT", idat) + (chunk(b"IEND", b"") if end else b""))


class QuestionSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = ROOT / question.CONFIG["directory"]
        cls.receipt = json.loads((cls.directory / "receipt.json").read_bytes())
        cls.projection = json.loads((ROOT / question.CONFIG["source_bindings"]["visual_projection"]["path"]).read_bytes())
        cls.originals = {row["state_id"]: row for row in cls.receipt["contract"]["design"]["states"]}

    def contract(self, sid):
        row = next(row for row in self.projection["effective_rows"] if any(state["state_id"] == sid for state in row["states"]))
        state = next(state for state in row["states"] if state["state_id"] == sid)
        return copy.deepcopy((row, state, self.originals[sid]))

    def test_invalid_or_duplicate_requests_fail_before_metadata(self):
        invalid = [None, [], [request()] * 2, [request()] * 5]
        for key, value in (("state_id", True), ("state_id", "visual-u034-s00"), ("template_id", "two-column-compact-v1"), ("fps", 30)):
            candidate = request(); candidate[key] = value; invalid.append([candidate])
        for key, value in (("path", "../receipt.json"), ("sha256", "0" * 64), ("sha256", True), ("size_bytes", 1)):
            candidate = request(); candidate["receipt_binding"][key] = value; invalid.append([candidate])
        with patch.object(question, "_preflight", side_effect=AssertionError("NO METADATA")):
            for candidate in invalid:
                with self.subTest(candidate=candidate), self.assertRaises(ValueError):
                    question.inspect_question_sources(ROOT, candidate)

    def test_container_contract_is_not_a_decoder_or_media_approval(self):
        result = question._png_container(envelope())
        self.assertEqual(result["chunks"], ["IHDR", "IDAT", "IEND"])
        self.assertFalse(result["decompressed"])
        self.assertNotIn("pixels_approved", result)
        self.assertEqual(result["color_type"], 2)

    def test_corrupt_transparent_animated_nonrgb_truncated_extra_container_fails(self):
        raw = envelope()
        cases = [None, b"", raw[1:], raw[:-1], raw + b"TRAILING", raw[:-4] + b"BAD!", envelope(end=False), envelope(idat=b"")]
        cases += [envelope(extra=chunk(kind, b"EXPLICIT_FIXTURE")) for kind in (b"tRNS", b"acTL", b"fcTL", b"fdAT", b"tEXt", b"iTXt")]
        cases += [envelope(header=header) for header in ((1080,1920,8,2,0,0,0),(1920,1080,16,2,0,0,0),(1920,1080,8,6,0,0,0),(1920,1080,8,2,0,0,1))]
        cases += [raw[:8] + chunk(b"IDAT", b"NO IHDR") + chunk(b"IEND", b""), raw[:8] + chunk(b"IHDR", b"BAD LENGTH") + raw[33:]]
        for candidate in cases:
            with self.subTest(candidate=str(candidate)[:45]), self.assertRaises(ValueError):
                question._png_container(candidate)

    def test_literal_contract_preserves_one_lexical_reveal_and_no_invented_unit_time(self):
        contracts = [question._contract(*self.contract(sid)) for sid in question.CONFIG["state_ids"]]
        self.assertEqual([row["timing_kind"] for row in contracts], ["UNIT_ENTRY_NOT_BOUND", "UNIT_ENTRY_NOT_BOUND", "CALIBRATED_LEXICAL_REQUIRED", "UNIT_ENTRY_NOT_BOUND"])
        self.assertEqual(contracts[2]["lexical_target"], {"unit_id":"narration-unit-020", "fragment_id":"take-026", "text":"or only possible?", "char_start":18, "char_end":35})
        self.assertTrue(all(row["continuation_of_state_id"] is None for row in contracts))
        self.assertEqual(contracts[1]["literal_copy"][0], contracts[2]["literal_copy"][0])

    def test_copy_take_lexical_case_controls_and_extra_entry_fields_fail(self):
        for mutation in ("copy", "take", "rowunit", "entrytime", "entryfloat", "meaning", "range", "style"):
            row, state, original = self.contract("visual-u020-s01")
            if mutation == "copy": state["visual_content"]["literal_copy"][1] = "Definitely true"
            elif mutation == "take": original["take_id"] = "take-051"
            elif mutation == "rowunit": row["unit_id"] = "narration-unit-034"
            elif mutation == "entrytime": state["entry"]["observed_sample"] = 100
            elif mutation == "entryfloat": state["entry"]["char_start"] = 18.0
            elif mutation == "meaning": original["copy"] = ["Harmful claim"]
            elif mutation == "range": row["text"] = row["text"].replace("or only possible?", "definitely true!!")
            else: state["visual_content"]["composition_id"] = "unapproved-counter"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                question._contract(row, state, original)

    def test_real_four_source_replay_and_container_checks_no_decode_no_authority(self):
        before = {path.name: P._sha(path.read_bytes()) for path in self.directory.iterdir()}
        with patch("PIL.Image.open", side_effect=AssertionError("NO PIXEL DECODE")), \
             patch.object(P, "_png", side_effect=AssertionError("NO LEGACY DECODE")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO OCR OR RENDER")), \
             patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")), \
             archived_historical_production_inputs(P):
            proofs = question.inspect_question_sources(ROOT, [request(sid) for sid in question.CONFIG["state_ids"]])
        self.assertEqual(len(proofs), 4)
        self.assertEqual(len({proof["content_sha256"] for proof in proofs}), 4)
        self.assertEqual(len({proof["lineage_id"] for proof in proofs}), 1)
        for proof in proofs:
            self.assertEqual(proof["status"], "STATIC_SOURCE_VERIFIED_NOT_ADMITTED")
            self.assertEqual([proof[key] for key in ("source_frame_count", "source_start_frame", "source_end_frame")], [1,0,1])
            self.assertTrue(proof["source_technically_verified"])
            self.assertFalse(proof["source_ready"])
            self.assertTrue(all(value is False for value in proof["authority"].values()))
            self.assertIsNone(proof["observed_sample"])
            self.assertIsNone(proof["video_frame"])
            self.assertEqual([proof[key] for key in ("image_decode_calls", "ocr_inference_calls", "render_calls", "technical_cost_brl")], [0,0,0,0])
            self.assertNotIn("fps", proof)
            self.assertNotIn("duration", proof)
            self.assertEqual(proof["historical_static_qa"]["ocr"]["status"], "PASS")
            self.assertFalse(proof["container_check"]["decompressed"])
            self.assertIn("STAGED_CASE_V5", proof["literal_reference_scope"])
            model = next(item for item in proof["dependency_bindings"] if item["path"].endswith("PP-OCRv6_rec_small.onnx"))
            self.assertEqual(model["size_bytes"], 21234383)
        self.assertEqual(before, {path.name: P._sha(path.read_bytes()) for path in self.directory.iterdir()})

    def test_wrong_staging_pin_fails_before_any_container_check(self):
        with patch.object(question, "STAGING_BINDING", {**question.STAGING_BINDING, "sha256":"0"*64}), \
             patch.object(question, "_png_container", side_effect=AssertionError("NO UNVERIFIED SOURCE")):
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                question.inspect_question_sources(ROOT, [request()])

    def test_executing_source_change_during_stager_replay_is_not_a_new_valid_pin(self):
        actual = Path.read_bytes
        target = Path(question.__file__).absolute()
        touched = {"target_reads": 0}
        def changing(path):
            raw = actual(path)
            if path == target:
                touched["target_reads"] += 1
                # Initial capture+reader verification remain original. The
                # subsequent recheck must reject, not adopt these later bytes.
                if touched["target_reads"] > 2:
                    return raw + b"\n# EXPLICIT READ-ONLY DRIFT FIXTURE\n"
            return raw
        with patch.object(Path, "read_bytes", changing), patch("PIL.Image.open", side_effect=AssertionError("NO DECODE")), \
             patch.object(question, "_png_container", side_effect=AssertionError("NO CONTAINER AFTER DRIFT")):
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                question.inspect_question_sources(ROOT, [request()])

    def test_late_inventory_and_source_drift_block_whole_batch(self):
        real_read, real_container = Path.read_bytes, question._png_container
        for mutation in ("source", "inventory"):
            armed = {"value": False}
            target = self.directory / "visual-u019-s00.png"
            real_iter = Path.iterdir
            def check(raw):
                answer = real_container(raw)
                armed["value"] = True
                return answer
            def read(path):
                raw = real_read(path)
                return raw[:-1] + bytes([raw[-1] ^ 1]) if armed["value"] and mutation == "source" and path == target else raw
            def inventory(path):
                rows = list(real_iter(path))
                return iter([*rows, path / "EXPLICIT_EXTRA_FIXTURE.txt"] if armed["value"] and mutation == "inventory" and path == self.directory else rows)
            with self.subTest(mutation=mutation), patch.object(question, "_png_container", side_effect=check), \
                 patch.object(Path, "read_bytes", read), patch.object(Path, "iterdir", inventory):
                with self.assertRaises(ValueError): question.inspect_question_sources(ROOT, [request()])

    def test_verifier_recomposes_not_authorizes_caller_flags(self):
        expected = {"source_frame_count":1, "source_ready":False, "authority":dict(question.AUTHORITY)}
        with patch.object(question, "inspect_question_source", return_value=expected) as inspector:
            self.assertEqual(question.verify_question_source(copy.deepcopy(expected), ROOT, **request()), expected)
            inspector.assert_called_once_with(ROOT, **request())
            for key, value in (("source_frame_count",1.0),("source_ready",True),("fps",30)):
                candidate = copy.deepcopy(expected); candidate[key] = value
                with self.subTest(key=key), self.assertRaises(ValueError): question.verify_question_source(candidate, ROOT, **request())


if __name__ == "__main__":
    unittest.main(verbosity=2)
