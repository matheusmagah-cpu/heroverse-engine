from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from hero_engine import central_manager_phase5 as manager
from hero_engine import maintenance_protocol as protocol
from hero_engine.oauth_operational_readiness import build_operational_readiness
from hero_engine.phase6_maintenance_verification import verify_local_migration_evidence
from tests import test_maintenance_migration_atomicity as atomic
from tests import test_oauth_refresh_and_readiness as oauth_fixture

ROOT = Path(__file__).resolve().parents[1]
STAMP = protocol._stamp(atomic.OBSERVED)


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


class PausedFingerprintTests(unittest.TestCase):
    def setUp(self):
        # Cleanup is attached to the actually executed unittest instance.
        self.space = tempfile.TemporaryDirectory(prefix="phase5-fingerprint-")
        self.addCleanup(self.space.cleanup)
        self.root = Path(self.space.name) / "project"
        self.atomic = atomic.LocalRuntimeMigrationAtomicityTests()
        self.atomic._root(str(self.root))
        oauth_fixture.install_schemas(self.root)
        for name in ("oauth_reconsent_watcher_runtime", "phase5_release_gate", "youtube_publication_receipt"):
            (self.root / "schemas" / (name + ".schema.json")).write_bytes(
                (ROOT / "schemas" / (name + ".schema.json")).read_bytes())
        extras = [manager.V3 / "thumbnail/thumbnail_set_manifest.json",
                  manager.V3 / "youtube-publication-receipt.json",
                  Path("output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"),
                  Path("output/operations/zero-cost/phase5-publication-pipeline-preflight.json")]
        for relative in manager.INPUTS + extras:
            source = ROOT / relative
            if source.is_file():
                destination = self.root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(source.read_bytes())
        self.token = Path(self.space.name) / "synthetic-token.json"
        self.token.write_bytes(b"synthetic token, no credential")
        oauth_fixture.OAuthRefreshAndReadinessTests()._ready_fixture(self.root, self.token)
        readiness = build_operational_readiness(self.root, token_file=self.token,
                                                observed_at="2026-09-04T12:04:00Z")
        self.assertTrue(readiness["continuous_operation_ready"])
        self.readiness_path = self.root / "output/integrations/youtube/heroverse/operational-readiness.json"
        write(self.readiness_path, readiness)
        watcher = read(ROOT / manager.RUNTIME / "oauth-reconsent-watcher.json")
        watcher.update(destination_path=str(self.token), source_path=str(self.token.with_name("missing-token.json")),
                       destination_path_sha256=hashlib.sha256(str(self.token).encode()).hexdigest())
        write(self.root / manager.RUNTIME / "oauth-reconsent-watcher.json", watcher)
        self.package_path = self.root / manager.V3 / "publication_package.json"
        package = read(self.package_path)
        for key in ("video", "captions"):
            path = self.root / "fixture" / key
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(("synthetic " + key).encode())
            package[key].update(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        write(self.package_path, package)
        review_path = self.root / manager.AUTONOMOUS_REVIEW_REPORT
        review = read(review_path)
        review["artifact"].update(path=package["video"]["path"], sha256=package["video"]["sha256"])
        write(review_path, review)
        thumb_path = self.root / manager.V3 / "thumbnail/thumbnail_set_manifest.json"
        thumbs = read(thumb_path)
        for index, item in enumerate(thumbs["candidates"]):
            path = self.root / "fixture" / f"thumbnail-{index}"
            path.write_bytes(f"synthetic thumbnail {index}".encode())
            item.update(path=str(path), content_hash=protocol.file_hash(path))
        write(thumb_path, thumbs)
        release = manager.build_release_gate(self.root, created_at=STAMP)
        self.assertEqual("READY_FOR_PUBLICATION_PIPELINE", release["decision"])
        self.publication_path = self.root / manager.V3 / "youtube-publication-receipt.json"
        publication = read(self.publication_path)
        publication.update(release_id=release["release_id"], idempotency_key=release["idempotency_key"],
                           artifact_hashes={key: release["artifacts"][key]["sha256"]
                                            for key in ("video", "thumbnail", "captions")})
        write(self.publication_path, publication)
        self.pause = self.root / manager.RUNTIME / "PAUSE"
        self.pause.write_bytes(b"synthetic owner pause")
        self.checkpoint = self.root / manager.RUNTIME / "fingerprint.json"
        write(self.checkpoint, {"input_fingerprint": "a" * 64, "updated_at": "2026-09-03T00:00:00Z"})
        self.original = self.checkpoint.read_bytes()
        self.network = ExitStack()
        self.addCleanup(self.network.close)
        for name in ("_build_live_service", "execute_publication_pipeline", "prove_noninteractive_refresh"):
            self.network.enter_context(patch.object(manager, name, side_effect=AssertionError("no external effect")))
        self.network.enter_context(patch("socket.create_connection", side_effect=AssertionError("no network")))

    def build(self):
        return manager.build_paused_fingerprint_reconciliation(self.root, observed_at=STAMP)

    def migrate(self):
        with self.atomic._dependencies(self.root):
            return self.atomic._run(self.root)

    def verify(self, result, **kwargs):
        return verify_local_migration_evidence(self.root, request_id=atomic.REQUEST_ID, migration=result, **kwargs)

    def test_native_producer_replays_current_readiness_without_mutation_or_effects(self):
        before = {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        value, evidence = self.build()
        self.assertEqual(manager.input_fingerprint(self.root), value["input_fingerprint"])
        self.assertEqual(13, len(evidence["release"]["gates"]))
        self.assertEqual(0, evidence["external_api_calls"])
        self.assertEqual(0, evidence["publication_effects"])
        self.assertNotIn("synthetic token, no credential", json.dumps(evidence))
        self.assertEqual(before, {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()})

    def test_existing_current_fingerprint_is_a_no_op(self):
        write(self.checkpoint, {"input_fingerprint": manager.input_fingerprint(self.root), "updated_at": STAMP})
        self.assertIsNone(self.build())
        self.assertEqual([], manager.paused_fingerprint_source_paths(self.root))

    def test_renewable_observations_do_not_invalidate_stable_identity(self):
        stable = manager.input_fingerprint(self.root)
        write(self.checkpoint, {"input_fingerprint": stable, "updated_at": STAMP})
        original = self.checkpoint.read_bytes()
        self.assertEqual(8, len(manager.VOLATILE_INPUTS))
        for relative in sorted(manager.VOLATILE_INPUTS):
            with self.subTest(observation=relative.as_posix()):
                before_observation = manager.observation_fingerprint(self.root)
                path = self.root / relative
                old = path.read_bytes() if path.is_file() else None
                write(path, {"observed_at": "2030-01-01T00:00:00Z", "receipt_id": "synthetic-successor"})
                self.assertEqual(stable, manager.input_fingerprint(self.root))
                self.assertNotEqual(before_observation, manager.observation_fingerprint(self.root))
                self.assertIsNone(self.build())
                self.assertEqual(original, self.checkpoint.read_bytes())
                if old is None:
                    path.unlink()
                else:
                    path.write_bytes(old)

    def test_stable_configuration_channel_and_content_changes_still_invalidate(self):
        stable = manager.input_fingerprint(self.root)
        for relative in (Path("config/integrations/youtube-heroverse-v1.json"),
                         Path("config/zero-cost-policy.json"), manager.V3 / "publication_package.json",
                         manager.AUTONOMOUS_REVIEW_REPORT):
            with self.subTest(stable_source=relative.as_posix()):
                path = self.root / relative
                old = path.read_bytes()
                path.write_bytes(old + b"\n")
                self.assertNotEqual(stable, manager.input_fingerprint(self.root))
                path.write_bytes(old)

    def test_runtime_markers_queue_schedule_resources_are_not_stable_sources(self):
        stable = manager.input_fingerprint(self.root)
        observation = manager.observation_fingerprint(self.root)
        for relative in (manager.RUNTIME / "maintenance-ack.json", manager.RUNTIME / "PAUSE",
                         manager.RUNTIME / "manager-lock.json", protocol.QUEUE_PATH,
                         Path("output/runtime/gestor-central/guards/resource-sample.json")):
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            old = path.read_bytes() if path.exists() else None
            path.write_bytes(b"synthetic volatile observation")
            self.assertEqual(stable, manager.input_fingerprint(self.root))
            self.assertEqual(observation, manager.observation_fingerprint(self.root))
            if old is None:
                path.unlink()
            else:
                path.write_bytes(old)

    def test_captured_version_and_population_are_fail_closed(self):
        rows = manager._capture_fingerprint_inputs(self.root)
        with self.assertRaisesRegex(PermissionError, "VERSION_UNKNOWN"):
            manager._captured_fingerprint(rows, version="unreviewed-v3")
        for altered in (rows[:-1], list(reversed(rows)), rows + [rows[0]]):
            with self.assertRaisesRegex(PermissionError, "POPULATION_CHANGED"):
                manager._captured_fingerprint(altered, version=manager.FINGERPRINT_VERSION)

    def test_v1_hash_is_exact_and_v2_does_not_relabel_historical_pass(self):
        rows = manager._capture_fingerprint_inputs(self.root)
        expected = hashlib.sha256()
        for name, raw in rows:
            expected.update(name.encode())
            expected.update(bytes.fromhex(raw) if raw is not None else b"<MISSING>")
        self.assertEqual(expected.hexdigest(), manager._captured_fingerprint(rows, version="phase5-inputs-v1"))
        self.assertNotEqual(expected.hexdigest(), manager.input_fingerprint(self.root))

    def test_official_reader_preserves_v1_archive_contract(self):
        # Synthetic historical transaction, not an assertion about live evidence.
        _, old_evidence = self.build()
        legacy_hash = manager._captured_fingerprint(old_evidence["input_bytes"], version="phase5-inputs-v1")
        old_evidence.update(kind="PAUSED_COMPLETED_PHASE5_LOCAL_RECONCILIATION_V1",
                            current_fingerprint=legacy_hash)
        old_value = {"input_fingerprint": legacy_hash, "updated_at": STAMP}
        with patch.object(manager, "input_fingerprint", return_value=legacy_hash), patch.object(
                manager, "build_paused_fingerprint_reconciliation", return_value=(old_value, old_evidence)):
            result = self.migrate()
        self.verify(result, scope="PAUSED_APPLICATION_ARCHIVE")
        self.verify(result)
        write(self.checkpoint, {"input_fingerprint": "c" * 64, "updated_at": STAMP})
        with self.assertRaisesRegex(PermissionError, "live target diverged"):
            self.verify(result)
        self.verify(result, scope="PAUSED_APPLICATION_ARCHIVE")

    def test_v2_native_transaction_records_stable_and_observation_identities(self):
        result = self.migrate()
        self.verify(result)
        current = read(self.checkpoint)
        self.assertEqual(manager.FINGERPRINT_VERSION, current["fingerprint_version"])
        self.assertEqual(manager.observation_fingerprint(self.root), current["observation_fingerprint"])
        self.assertEqual(manager.input_fingerprint(self.root), current["input_fingerprint"])
        journal = read(self.root / result["transaction_journal_path"])
        self.assertEqual("PAUSED_COMPLETED_PHASE5_LOCAL_RECONCILIATION_V2",
                         journal["phase5_fingerprint_reconciliation"]["kind"])
        # An OAuth successor requests re-evaluation, not reinstallation. All
        # authorization checks remain the responsibility of the actual gates.
        write(self.readiness_path, {"observed_at": "2031-01-01T00:00:00Z"})
        self.assertEqual(current["input_fingerprint"], manager.input_fingerprint(self.root))
        self.assertNotEqual(current["observation_fingerprint"], manager.observation_fingerprint(self.root))
        self.verify(result, scope="PAUSED_APPLICATION_ARCHIVE")

    def test_missing_pause_blocks(self):
        self.pause.unlink()
        with self.assertRaisesRegex(PermissionError, "OWNER_PAUSE_REQUIRED"):
            self.build()

    def test_unknown_fingerprint_preimage_blocks(self):
        write(self.checkpoint, {"input_fingerprint": "unknown"})
        with self.assertRaisesRegex(PermissionError, "PREIMAGE_INVALID"):
            self.build()

    def test_new_publication_identity_is_not_acknowledged(self):
        value = read(self.publication_path)
        value["idempotency_key"] = "b" * 64
        write(self.publication_path, value)
        with self.assertRaisesRegex(PermissionError, "NOT_EXACT_COMPLETED_PUBLICATION"):
            self.build()

    def test_changed_artifact_blocks_native_release(self):
        Path(read(self.package_path)["video"]["path"]).write_bytes(b"foreign video")
        with self.assertRaises(PermissionError):
            self.build()

    def test_changed_token_blocks_readiness_replay(self):
        self.token.write_bytes(b"different synthetic token")
        with self.assertRaisesRegex(PermissionError, "READINESS_NOT_REPRODUCIBLE"):
            self.build()

    def test_input_change_during_reconciliation_blocks(self):
        real = manager.build_release_gate
        def race(*args, **kwargs):
            result = real(*args, **kwargs)
            path = self.root / "config/visual_style_registry.json"
            path.write_bytes(path.read_bytes() + b"\n")
            return result
        with patch.object(manager, "build_release_gate", side_effect=race):
            with self.assertRaisesRegex(PermissionError, "INPUTS_CHANGED_DURING_RECONCILIATION"):
                self.build()

    def test_native_transaction_commit_and_official_reader(self):
        result = self.migrate()
        self.verify(result)
        self.assertEqual(manager.input_fingerprint(self.root), read(self.checkpoint)["input_fingerprint"])
        self.assertIn(self.checkpoint.relative_to(self.root).as_posix(), result["allowed_write_paths"])
        self.assertEqual(b"synthetic owner pause", self.pause.read_bytes())
        # Immutable transaction evidence remains readable after a legitimate later observation.
        original = self.checkpoint.read_bytes()
        for label, payload in (
                ("fingerprint", json.dumps({"input_fingerprint": "c" * 64, "updated_at": STAMP}).encode()),
                ("exact_bytes", original + b"\n"), ("malformed", b"not JSON"), ("missing", None)):
            with self.subTest(live_target=label):
                if payload is None:
                    self.checkpoint.unlink()
                else:
                    self.checkpoint.write_bytes(payload)
                with self.assertRaisesRegex(PermissionError, "fingerprint reconciliation live target diverged"):
                    self.verify(result)
                self.verify(result, scope="PAUSED_APPLICATION_ARCHIVE")
        self.checkpoint.write_bytes(original)
        self.verify(result)

    def test_commit_failure_rolls_back_fingerprint_and_preserves_pause(self):
        real = protocol._commit_migration_replacement
        def fail(path, payload):
            if path == self.root / protocol.EXECUTIVE_STATUS_PATH:
                raise OSError("injected after fingerprint commit")
            return real(path, payload)
        with patch.object(protocol, "_commit_migration_replacement", side_effect=fail):
            with self.assertRaisesRegex(PermissionError, "restored byte-for-byte"):
                self.migrate()
        self.assertEqual(self.original, self.checkpoint.read_bytes())
        self.assertEqual(b"synthetic owner pause", self.pause.read_bytes())

    def test_source_race_after_prepare_rolls_back_without_acceptance(self):
        real = protocol._commit_migration_replacement
        def race(path, payload):
            real(path, payload)
            if path == self.root / protocol.PREDICTION_RUNTIME_PATH:
                self.token.write_bytes(b"foreign change after prepare")
        with patch.object(protocol, "_commit_migration_replacement", side_effect=race):
            with self.assertRaisesRegex(PermissionError, "restored byte-for-byte") as caught:
                self.migrate()
        self.assertIn("SOURCE_CHANGED_BEFORE_COMMIT", str(caught.exception.__cause__))
        self.assertEqual(self.original, self.checkpoint.read_bytes())

    def test_reader_rejects_changed_journal(self):
        result = self.migrate()
        path = self.root / result["transaction_journal_path"]
        value = read(path)
        value["phase5_fingerprint_reconciliation"]["current_fingerprint"] = "b" * 64
        write(path, value)
        with self.assertRaises(PermissionError):
            self.verify(result)

    def test_reader_rejects_semantic_tamper_even_with_rebound_test_envelope(self):
        result = self.migrate()
        path = self.root / result["transaction_journal_path"]
        value = read(path)
        value["phase5_fingerprint_reconciliation"]["publication"]["idempotency_key"] = "b" * 64
        write(path, value)
        # Simulate a dishonest producer in this temporary fixture; no real anchor is changed.
        result["transaction_journal_hash"] = protocol.file_hash(path)
        outcome_path = self.root / result["transaction_outcome_path"]
        outcome = read(outcome_path)
        outcome["journal_hash"] = result["transaction_journal_hash"]
        write(outcome_path, outcome)
        result["transaction_outcome_hash"] = protocol.file_hash(outcome_path)
        with self.assertRaisesRegex(PermissionError, "fingerprint reconciliation decision"):
            self.verify(result)

