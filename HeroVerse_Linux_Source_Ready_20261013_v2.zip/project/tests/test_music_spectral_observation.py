"""Independent signal controls for native spectral observations; no quality PASS."""
import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import soundfile as sf
from hero_engine.phase5_autonomous_quality import measure_music_sample


class MusicSpectralObservationTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        self.path=Path(tmp.name)/'control.wav'

    def measure(self, channels):
        sf.write(self.path,channels,48000,subtype='PCM_16')
        pin='sha256:'+hashlib.sha256(self.path.read_bytes()).hexdigest()
        native_codec=subprocess.CompletedProcess([],0,'',json.dumps({'input_i':'-16','input_tp':'-2','input_lra':'3'}))
        with patch('subprocess.run',return_value=native_codec):
            return measure_music_sample(self.path,expected_media_hash=pin,
                expected_duration_ms=round(len(channels)*1000/48000))

    def tone(self,hz,seconds=1):
        signal=np.sin(2*np.pi*hz*np.arange(seconds*48000)/48000)*.1
        return np.column_stack([signal,signal])

    def test_known_frequency_observed_with_fft_bin_resolution(self):
        result=self.measure(self.tone(440))
        row=result['music_attributes']['windows'][0]
        self.assertAlmostEqual(row['peak_frequency_hz'],440,delta=1)
        self.assertAlmostEqual(row['spectral_centroid_hz'],440,delta=1)

    def test_high_and_low_timbre_distinguished(self):
        low=self.measure(self.tone(220)); high=self.measure(self.tone(4400))
        self.assertLess(low['music_attributes']['windows'][0]['spectral_centroid_hz'],
                        high['music_attributes']['windows'][0]['spectral_centroid_hz'])

    def test_opposed_stereo_channels_not_mistaken_for_silence(self):
        stereo=self.tone(440); stereo[:,1]*=-1
        result=self.measure(stereo)
        self.assertEqual(result['music_attributes']['windows'][0]['peak_frequency_hz'],440)

    def test_identical_vs_changed_spectral_content(self):
        repeated=self.measure(self.tone(440,2))
        changed=self.measure(np.concatenate([self.tone(440),self.tone(880)]))
        self.assertGreater(repeated['music_attributes']['windows'][1]['previous_window_spectral_cosine'],
                           changed['music_attributes']['windows'][1]['previous_window_spectral_cosine'])

    def test_silence_has_no_minted_timbre_or_similarity(self):
        result=self.measure(np.zeros((96000,2)))
        for row in result['music_attributes']['windows']:
            self.assertIsNone(row['spectral_centroid_hz'])
            self.assertIsNone(row['previous_window_spectral_cosine'])
        self.assertFalse(result['quality_authorized'])
        json.dumps(result,allow_nan=False)

    def test_frame_windows_exactly_cover_partial_tail(self):
        signal=self.tone(440,2)[:72000]
        result=self.measure(signal)
        windows=result['music_attributes']['windows']
        self.assertEqual([(r['start_frame'],r['end_frame']) for r in windows],[(0,48000),(48000,72000)])

    def test_measured_attributes_cannot_claim_long_comfort_or_release(self):
        result=self.measure(self.tone(440))
        self.assertEqual(result['music_attributes']['fatigue']['status'],'NOT_ESTABLISHED')
        self.assertEqual(result['music_attributes']['timbre']['status'],'MEASURED_NOT_QUALIFIED')
        self.assertFalse(result['render_authorized'])
        self.assertFalse(result['publication_authorized'])
