"""A9 literal metadata integration; upstream PCM seam is explicitly mocked.

The live A runner is separate. These fixtures do not produce media or timing.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_visual_amendment as amendment
from hero_engine import phase6_av_render_recipe as recipe
from hero_engine import phase6_av_two_column_adapter as columns
from hero_engine import phase6_av_admission as admission
from hero_engine import phase6_narration_audio_inventory as inventory
from hero_engine.phase6_narration_audio_inventory import Reader
from tests.static_input_isolation import archived_historical_inventory_inputs

ROOT = Path(__file__).resolve().parents[1]
HISTORICAL_PRODUCTION = ROOT / (
    "output/operations/phase6/release/production-artifact-archives/"
    "phase6-production-inputs-79b3e183dd5df410fb3a"
)
_HISTORICAL_REPLAY_INPUTS = {
    "output/production/phase6/video-002/production/take_plan.json": "take_plan.json",
    "output/production/phase6/video-002/production/channel_style_bible.json": "channel_style_bible.json",
}
RUNNER = ROOT / "output/qa/phase6/diagnostics/two-column-compact-v1/build_bound_visual_amendment_timeline.py"
spec = importlib.util.spec_from_file_location("a9_amendment_input_runner_test", RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class AmendmentIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This class replays a frozen A9 input graph.  Its v2 render compiler
        # reads two bindings directly instead of through Reader, so map only
        # those exact old hashes to the immutable release archive.  Active
        # consumers must not inherit this transport.
        original_rooted = recipe._rooted
        def historical_rooted(root, relative):
            path = original_rooted(root, relative)
            archived_name = _HISTORICAL_REPLAY_INPUTS.get(str(relative).replace("\\", "/"))
            if archived_name is not None:
                archived = HISTORICAL_PRODUCTION / archived_name
                if not archived.is_file():
                    raise AssertionError("frozen replay archive missing")
                return archived
            return path
        cls._recipe_rooted = mock.patch.object(recipe, "_rooted", side_effect=historical_rooted)
        cls._recipe_rooted.start()
        cls._inventory_transport = archived_historical_inventory_inputs(inventory)
        cls._inventory_transport.__enter__()
        reader = Reader(ROOT)
        cls.base = json.loads(reader.read(runner.BASE, "sha256:" + runner.PINS[runner.BASE]))
        cls.old = json.loads(reader.read(runner.PREVIOUS, "sha256:" + runner.PINS[runner.PREVIOUS]))
        cls.bundle = runner.make_bundle(cls.base)
        cls.schema = json.loads((ROOT / av.SCHEMA).read_bytes())
        cls.data = {key: reader.load(value) for key, value in cls.base["arguments"]["source_bindings"].items() if key in av.CORE}
        # Only upstream source/PCM evidence is mocked. All literal readers,
        # amendment verification, target recomposition and schema are real.
        with mock.patch.object(av, "_sources", return_value=copy.deepcopy(cls.data)), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(cls.old["units"]), copy.deepcopy(cls.old["narration_fragment_map"]))), \
             mock.patch.object(av, "inspect_pcm", side_effect=AssertionError("no new PCM inspection")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no effects")):
            cls.value = av.build(ROOT, **cls.bundle["arguments"])

    @classmethod
    def tearDownClass(cls):
        cls._inventory_transport.__exit__(None, None, None)
        cls._recipe_rooted.stop()

    def test_effective_and_historical_proofs_are_separate_and_full_scope_stays_blocked(self):
        value = self.value
        self.assertEqual((value["schema_version"], value["timeline_version"]), ("1.11.0", "phase6-av-timeline-v12"))
        self.assertEqual(value["untimed_visual_intent_evidence"], self.old["untimed_visual_intent_evidence"])
        changed = value["visual_amendment_evidence"]
        self.assertEqual(changed["projection_binding"], amendment.PROJECTION_BINDING)
        self.assertEqual(changed["amendment_binding"], amendment.AMENDMENT_BINDING)
        self.assertEqual((changed["changed_state_count"], changed["unmodified_state_count"]), (12, 88))
        self.assertEqual(changed["base_inspection_sha256"], value["untimed_visual_intent_evidence"]["inspection_sha256"])
        self.assertNotEqual(changed["inspection_sha256"], changed["base_inspection_sha256"])
        projection = json.loads(Reader(ROOT).read(amendment.PROJECTION_BINDING["path"], amendment.PROJECTION_BINDING["sha256"]))
        self.assertEqual(changed["effective_rows_sha256"], av.canonical_sha(projection["effective_rows"]))
        self.assertEqual(len(value["temporal_evidence_assessment"]["declared_target_unit_ids"]), 26)
        self.assertTrue(value["temporal_evidence_assessment"]["scope_complete"])
        self.assertFalse(value["temporal_evidence_assessment"]["all_required_evidence_live"])
        self.assertEqual(value["status"], "BLOCKED_INCOMPLETE")
        self.assertIsNone(value["derived_take_plan"])
        self.assertIn("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING", value["blockers"])
        self.assertEqual([value[key] for key in ("render_spans", "visual_events", "caption_cues")], [[], [], []])
        self.assertTrue(all(flag is False for flag in value["authority"].values()))

    def test_only_amendment_binding_is_added_to_arguments(self):
        runner.validate_bundle(self.base, self.bundle)
        result = copy.deepcopy(self.bundle)
        result["arguments"]["source_bindings"].pop("visual_amendment")
        result["arguments_id"] = self.base["arguments_id"]
        self.assertEqual(av.canonical_sha(result), av.canonical_sha(self.base))
        for mutate in (lambda row: row["arguments"]["pause_decisions"].append({"invented": True}),
                       lambda row: row["authority"].update(render_authorized=True),
                       lambda row: row["arguments"]["source_bindings"].pop("untimed_visual_intent"),
                       lambda row: row.update(technical_cost_brl=0.0)):
            candidate = copy.deepcopy(self.bundle)
            mutate(candidate)
            with self.subTest(mutation=mutate), self.assertRaises(ValueError):
                runner.validate_bundle(self.base, candidate)

    def test_missing_base_caption_or_wrong_amendment_pin_block_before_source_or_pcm(self):
        for mutate in (lambda binds: binds.pop("untimed_visual_intent"),
                       lambda binds: binds.pop("caption_intent"),
                       lambda binds: binds["visual_amendment"].update(sha256="sha256:" + "0" * 64),
                       lambda binds: binds["visual_amendment"].update(path="copied.json")):
            bindings = copy.deepcopy(self.bundle["arguments"]["source_bindings"])
            mutate(bindings)
            reader = mock.Mock()
            reader.load.side_effect = AssertionError("cannot read an invalid bundle")
            with self.subTest(mutation=mutate), self.assertRaises(ValueError):
                av._sources(reader, bindings)
            reader.load.assert_not_called()

    def test_old_a8_schema_valid_but_new_capability_cannot_be_relabelled_as_old(self):
        validator = Draft202012Validator(self.schema)
        Draft202012Validator.check_schema(self.schema)
        validator.validate(self.old)
        validator.validate(self.value)
        for mutate in (lambda row: row.update(schema_version="1.7.0", timeline_version="phase6-av-timeline-v8"),
                       lambda row: row.update(visual_amendment_evidence=None),
                       lambda row: row["visual_amendment_evidence"].update(source_ready=True),
                       lambda row: row["visual_amendment_evidence"].update(global_schedule_created=True),
                       lambda row: row["visual_amendment_evidence"].update(changed_state_count=13),
                       lambda row: row["inputs"]["source_bindings"].pop("untimed_visual_intent"),
                       lambda row: row["inputs"]["source_bindings"].pop("visual_amendment")):
            candidate = copy.deepcopy(self.value)
            mutate(candidate)
            with self.subTest(mutation=mutate), self.assertRaises(ValidationError):
                validator.validate(candidate)
        old = copy.deepcopy(self.old)
        old["inputs"]["source_bindings"]["visual_amendment"] = copy.deepcopy(amendment.PROJECTION_BINDING)
        with self.assertRaises(ValidationError):
            validator.validate(old)

    def test_implementation_dependencies_and_evidence_bytes_are_bound(self):
        dependencies = self.value["implementation_dependencies"]
        self.assertEqual(len(dependencies), 40)
        self.assertEqual(len({row["path"] for row in dependencies}), 40)
        for name in ("hero_engine/phase6_av_visual_amendment.py", amendment.SCHEMA):
            matches = [pin for pin in dependencies if pin["path"] == name]
            self.assertEqual(matches, [{"path": name, "sha256": av.bytes_sha((ROOT / name).read_bytes())}])
        bound = {row["path"] for row in self.value["source_file_bindings"]}
        self.assertIn(amendment.PROJECTION_BINDING["path"], bound)
        self.assertIn(amendment.AMENDMENT_BINDING["path"], bound)
        self.assertIn("output/qa/phase6/diagnostics/two-column-compact-v1/static-5d42a585eacde074510f8f61/visual-u016-s01.png", bound)

    def test_late_projection_drift_after_reader_pass_blocks_a_final_return(self):
        original_read, captions = Reader.read, av._captions
        state = {"late": False}
        def late_captions(*args, **kwargs):
            result = captions(*args, **kwargs)
            state["late"] = True
            return result
        def drift(reader, path, expected=None, **kwargs):
            if state["late"] and path == amendment.PROJECTION_BINDING["path"]:
                raise ValueError("FIXTURE late projection drift; no real mutation")
            return original_read(reader, path, expected, **kwargs)
        with mock.patch.object(av, "_sources", return_value=copy.deepcopy(self.data)), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(self.old["units"]), copy.deepcopy(self.old["narration_fragment_map"]))), \
             mock.patch.object(av, "_captions", side_effect=late_captions), \
             mock.patch.object(Reader, "read", drift), self.assertRaisesRegex(ValueError, "late projection drift"):
            av.build(ROOT, **self.bundle["arguments"])

    def test_old_two_column_renderer_rejects_amended_plan_before_sources_or_layout(self):
        with mock.patch.object(columns, "_load_sources", side_effect=AssertionError("cannot load legacy graphics")), \
             self.assertRaisesRegex(columns.AVTwoColumnAdapterError, "cannot use the historical"):
            columns.compile_two_column_av_spec(ROOT, timeline=self.value, bindings={})

    def test_c12_keeps_amended_graph_blocked_without_effect_or_master_approval(self):
        with mock.patch("subprocess.Popen", side_effect=AssertionError("no render")):
            compiled = recipe.compile_phase6_av_render_recipe(ROOT, self.value,
                master_receipt_binding=None, render_blueprint_binding=None)
        self.assertEqual((compiled["schema_version"], compiled["recipe_version"]), ("1.14.0", "phase6-av-render-recipe-v15"))
        self.assertEqual(compiled["status"], "BLOCKED_INCOMPLETE")
        self.assertIsNone(compiled["command_graph"])
        self.assertIn("AMENDED_VISUAL_COMPOSITOR_NOT_IMPLEMENTED", compiled["blockers"])
        self.assertTrue(all(flag is False for flag in compiled["authority"].values()))

    def test_b18_static_inventory_remains_one_source_frame_not_admission(self):
        fixture = {"schema_version": "1.9.0", "render_spans": [{
            "span_id": "explicit-fixture", "asset_binding": {"path": "fixture.png", "sha256": "sha256:" + "0" * 64},
            "media_kind": "STATIC_IMAGE", "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
            "static_source": {"template_id": "fear-examples-v1", "state_id": "door-0", "receipt_binding": {"path": "fixture.json", "sha256": "sha256:" + "1" * 64}}}],
            "static_source_evidence": [{"span_id": "explicit-fixture", "inspection_id": "fixture-only", "inspection_sha256": "sha256:" + "2" * 64}]}
        items = admission._span_assets(fixture)
        self.assertEqual(items[0]["media_kind"], "STATIC_IMAGE")
        self.assertEqual(items[0]["spans"][0]["source_end_frame"], 1)
        self.assertNotIn("production_eligible", items[0])
        fixture["render_spans"][0]["source_end_frame"] = 90
        with self.assertRaises(admission.AdmissionError):
            admission._span_assets(fixture)

    def test_runner_result_requires_all_a8_audio_clock_and_gate_surfaces_unchanged(self):
        # The frozen A9 runner is checked against its actual pinned A9 output.
        # A10 metadata must not be relabelled as an old capability or re-render
        # the previous experiment merely to keep a historical test alive.
        current = json.loads(Reader(ROOT).read(
            "output/operations/phase6/av-admission/timelines/phase6-av-timeline-08c58eb7551e72f958fa3f09.json",
            "sha256:5105f3a4c09cc632667088b7a8d50cdd49d46006b33af2f98c21fb843f37f6c0"))
        runner.validate_result(self.old, current, self.bundle)
        for mutate in (lambda row: row["duration"].update(planned_duration_ms=207800),
                       lambda row: row["units"][0].update(pcm_start_sample=800),
                       lambda row: row["blockers"].pop(),
                       lambda row: row["temporal_evidence_assessment"].update(all_required_evidence_live=True),
                       lambda row: row["visual_amendment_evidence"].update(source_ready=True)):
            bad = copy.deepcopy(current)
            mutate(bad)
            with self.subTest(mutation=mutate), self.assertRaises(ValueError):
                runner.validate_result(self.old, bad, self.bundle)

    def test_frozen_a9_runner_does_not_accept_current_a10_as_its_own_result(self):
        with self.assertRaisesRegex(ValueError, "Current version or exact arguments differ"):
            runner.validate_result(self.old, self.value, self.bundle)

    def test_silence_input_rebinding_preserves_exact_clocks_reasons_and_editorial_proof(self):
        runner.validate_silence(self.old, self.value)
        for mutate in (
            lambda row: row["permitted_silence_spans"][0].update(start_sample=15017),
            lambda row: row["permitted_silence_spans"][0].update(end_sample_exclusive=24000.0),
            lambda row: row["permitted_silence_spans"][0].update(reason="EDITORIAL_PAUSE"),
            lambda row: row["permitted_silence_spans"][0].update(evidence_ref=self.old["permitted_silence_spans"][0]["evidence_ref"]),
            lambda row: row["permitted_silence_spans"].reverse(),
            lambda row: row["permitted_silence_spans"].pop(),
        ):
            bad = copy.deepcopy(self.value)
            mutate(bad)
            with self.subTest(mutation=mutate), self.assertRaises(ValueError):
                runner.validate_silence(self.old, bad)
        before, after = copy.deepcopy(self.old), copy.deepcopy(self.value)
        gap = {"start_sample": 10, "end_sample_exclusive": 20, "reason": "EDITORIAL_PAUSE", "evidence_ref": "sha256:" + "e" * 64}
        before["permitted_silence_spans"].append(copy.deepcopy(gap))
        after["permitted_silence_spans"].append(copy.deepcopy(gap))
        runner.validate_silence(before, after)
        after["permitted_silence_spans"][-1]["evidence_ref"] = av.canonical_sha(after["inputs"])
        with self.assertRaises(ValueError):
            runner.validate_silence(before, after)

    def test_exact_partial_recovery_reads_only_and_rejects_unbound_or_corrupt_input(self):
        raw = (ROOT / runner.RECOVERY_PATH).read_bytes()
        binding = {"path": runner.RECOVERY_PATH, "sha256": av.bytes_sha(raw)}
        failure = json.loads(raw)
        path = Path(failure["partial_arguments"]["path"])
        arguments = (ROOT / path).read_bytes()
        with mock.patch("subprocess.Popen", side_effect=AssertionError("no effects")):
            self.assertEqual(runner.read_partial_recovery(Reader(ROOT), binding, path, arguments), failure["partial_arguments"])
        self.assertEqual((ROOT / path).read_bytes(), arguments)
        for invalid in (None, {}, {**binding, "path": "another.json"}, {**binding, "sha256": "sha256:" + "0" * 64}):
            with self.subTest(binding=invalid), self.assertRaises((ValueError, PermissionError)):
                runner.read_partial_recovery(Reader(ROOT), invalid, path, arguments)
        for digest in (None, "", 0, True, "sha256:" + "A" * 64, "sha256:" + "1" * 64 + "\n"):
            with mock.patch.object(Reader, "read", side_effect=AssertionError("invalid pin must fail before reading")), self.assertRaises(ValueError):
                runner.read_partial_recovery(Reader(ROOT), {**binding, "sha256": digest}, path, arguments)
        for altered in (arguments + b"\n", arguments[:-1]):
            with self.assertRaises(ValueError):
                runner.read_partial_recovery(Reader(ROOT), binding, path, altered)
        for field in ("timeline_written", "completion_receipt_written", "render_executed", "publication_authorized"):
            altered = copy.deepcopy(failure)
            altered[field] = True
            with mock.patch.object(Reader, "read", return_value=json.dumps(altered).encode()), self.assertRaises(ValueError):
                runner.read_partial_recovery(Reader(ROOT), binding, path, arguments)

    def test_recovery_rejects_existing_timeline_even_without_completion_receipt(self):
        reader = mock.Mock()
        reader.read.return_value = json.dumps({"inputs": self.base["arguments"]}).encode()
        runner.reject_persisted_timeline(reader, ["prior.json"], self.bundle["arguments"])
        for value in ({"inputs": self.bundle["arguments"]}, {}, {"inputs": None}):
            reader.read.return_value = json.dumps(value).encode()
            with self.subTest(value=value), self.assertRaises(ValueError):
                runner.reject_persisted_timeline(reader, ["checkpoint.json"], self.bundle["arguments"])


if __name__ == "__main__":
    unittest.main()
