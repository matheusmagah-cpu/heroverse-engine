"""Typed B consumer contracts with synthetic proofs, never production approval.

The independent still-rights verifier is tested separately against real bytes.
These tests isolate dispatch and proof binding; positive mocks have no authority.
"""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_admission as admission
from hero_engine import phase6_static_asset_rights as rights
from hero_engine.phase6_narration_units import bytes_sha, canonical_sha


class StaticAdmissionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="av-static-admission-fixture-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.reference = {"timeline_id": "phase6-av-timeline-" + "a" * 24,
                          "sha256": "sha256:" + "b" * 64, "planned_total_samples": 48000}
        self.source = {"template_id": "fear-examples-v1", "state_id": "door-0",
                       "receipt_binding": {"path": "output/fixture-receipt.json", "sha256": "sha256:" + "c" * 64}}
        self.span = {"span_id": "fixture-still", "asset_binding": {"path": "output/fixture.png", "sha256": "sha256:" + "d" * 64},
                     "media_kind": "STATIC_IMAGE", "static_source": self.source,
                     "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1}
        self.timeline = {"schema_version": "1.4.0", "render_spans": [self.span], "static_source_evidence": [
            {"span_id": self.span["span_id"], "inspection_id": "fixture-source-proof", "inspection_sha256": "sha256:" + "e" * 64}]}
        self.required = admission._span_assets(self.timeline)
        pins = {}
        for name, kind, char in (("provenance_binding", "provenance", "1"), ("decision_binding", "decision", "2")):
            path = admission.STATIC_RIGHTS_DOCUMENTS / (f"static-owned-{kind}-" + char * 24 + ".json")
            full = self.root / path
            full.parent.mkdir(parents=True, exist_ok=True)
            full.write_bytes(b"{}")  # Intentionally NOT a real rights document.
            pins[name] = {"path": path.as_posix(), "sha256": bytes_sha(b"{}")}
        self.proof = {"status": "PASS", "evidence_mode": "LIVE", "scope": "RIGHTS_BINDING_ONLY",
                      "rights_status": "OWNED", "commercial_use": True, "source_ready": False,
                      "asset_id": "fixture-still", "channel_id": admission.CHANNEL_ID,
                      "authority": dict(rights.AUTHORITY), "inspection_id": "static-rights-" + "f" * 24,
                      "provenance_id": "static-owned-provenance-" + "1" * 24,
                      "decision_id": "static-owned-decision-" + "2" * 24,
                      "source_proof": {"inspection_id": "fixture-source-proof", "sha256": "8" * 64,
                                       "timeline_canonical_sha256": "sha256:" + "e" * 64},
                      "artifacts": {"png_binding": {"path": str(self.root / "output/fixture.png"), "sha256": "d" * 64}}}
        self.row = {"asset_id": "fixture-still", **self.span["asset_binding"], "status": "PASS", "rights_status": "OWNED",
                    "media_kind": "STATIC_IMAGE", "static_rights": {**pins, "inspection_id": self.proof["inspection_id"],
                    "inspection_sha256": canonical_sha(self.proof)}}
        self.video = {"asset_id": "fixture-video", "path": "output/fixture.mp4", "sha256": "sha256:" + "9" * 64,
                      "status": "PASS", "rights_status": "OWNED", "media_kind": "VIDEO_CFR", "static_rights": None}
        residency_id = "asset-residency-phase6-" + "3" * 24
        residency_path = Path("output/operations/phase6/capacity/asset-library-residency-receipts") / (residency_id + ".json")
        raw = json.dumps({"assets": [{"asset_id": self.video["asset_id"], "path": self.video["path"],
            "observed_content_hash": self.video["sha256"], "status": "PASS", "rights_status": "OWNED"}]}).encode()
        full = self.root / residency_path
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_bytes(raw)
        self.value = {"schema_version": "1.1.0", "document_type": "PHASE6_AV_RIGHTS_EVIDENCE", "evidence_mode": "LIVE",
                      "status": "PASS", "channel_id": admission.CHANNEL_ID, "video_id": admission.VIDEO_ID,
                      "timeline": self.reference, "asset_residency": {"audit_id": residency_id, "receipt_path": residency_path.as_posix(),
                          "sha256": bytes_sha(raw), "size_bytes": len(raw), "manifest_content_hash": "sha256:" + "4" * 64},
                      "assets": [self.row, self.video], "publication_authorized": False, "technical_cost_brl": 0}
        self.required += [{"path": self.video["path"], "sha256": self.video["sha256"], "media_kind": "VIDEO_CFR", "spans": []}]

    def identified(self, value=None):
        value = copy.deepcopy(self.value if value is None else value)
        value.pop("evidence_id", None)
        value["evidence_id"] = "phase6-av-rights-" + canonical_sha(value).split(":")[1][:24]
        return value, self.root / (value["evidence_id"] + ".json")

    def validate(self, value=None, required=None):
        value, path = self.identified(value)
        return admission._validate_rights(self.root, value, path, self.reference,
                                          self.required if required is None else required)

    def test_typed_still_keeps_one_source_frame_and_stage_a_proof(self):
        result = self.required[0]
        self.assertEqual(result["static_source"], self.source)
        self.assertEqual(result["static_inspection"]["inspection_id"], "fixture-source-proof")
        self.assertEqual(result["spans"][0]["source_end_frame"], 1)
        self.assertNotIn("duration_ms", result)

    def test_new_scope_schema_preserves_static_dispatch_without_granting_admission(self):
        for version in ("1.5.0", "1.6.0", "1.7.0"):
            with self.subTest(version=version):
                candidate = copy.deepcopy(self.timeline)
                candidate["schema_version"] = version
                self.assertEqual(admission._span_assets(self.timeline), admission._span_assets(candidate))
                # This helper only inventories sources; it does not validate Stage A.
                self.assertNotIn("production_eligible", admission._span_assets(candidate)[0])

    def test_legacy_unknown_partial_and_disguised_static_sources_reject(self):
        mutations = [lambda t: t.update(schema_version="1.3.0"),
                     lambda t: t["render_spans"][0].update(source_frame_count=30),
                     lambda t: t["render_spans"][0].update(source_frame_count=True),
                     lambda t: t["render_spans"][0].update(source_start_frame=0.0),
                     lambda t: t["render_spans"][0].update(media_kind="VIDEO_CFR"),
                     lambda t: t["render_spans"][0].update(media_kind="UNKNOWN"),
                     lambda t: t.update(static_source_evidence=[])]
        for mutation in mutations:
            candidate = copy.deepcopy(self.timeline)
            mutation(candidate)
            with self.subTest(mutation=mutation), self.assertRaises(admission.AdmissionError):
                admission._span_assets(candidate)

    def test_same_bytes_cannot_claim_different_static_scope(self):
        candidate = copy.deepcopy(self.timeline)
        span = copy.deepcopy(candidate["render_spans"][0])
        span["span_id"] = "second"
        span["static_source"]["state_id"] = "door-1"
        candidate["render_spans"].append(span)
        candidate["static_source_evidence"].append({**candidate["static_source_evidence"][0], "span_id": "second"})
        with self.assertRaisesRegex(admission.AdmissionError, "repeated source"):
            admission._span_assets(candidate)

    def test_mixed_contract_dispatches_video_pool_and_still_verifier_separately(self):
        with patch.object(rights, "inspect_static_asset_rights", return_value=self.proof) as still, \
             patch.object(admission, "verify_phase6_asset_residency", return_value={"manifest_content_hash": "sha256:" + "4" * 64}) as pool:
            result = self.validate()
        self.assertEqual(result["asset_count"], 2)
        self.assertEqual(still.call_args.kwargs["expected_evidence_mode"], "LIVE")
        self.assertEqual(pool.call_args.kwargs["required_asset_ids"], ["fixture-video"])
        self.assertFalse(pool.call_args.kwargs["recheck_decode"])
        self.assertNotIn("publication_authorized", result)

    def test_static_only_contract_still_requires_legacy_library_audit(self):
        candidate = copy.deepcopy(self.value)
        candidate["assets"] = [candidate["assets"][0]]
        with patch.object(rights, "inspect_static_asset_rights", return_value=self.proof), \
             patch.object(admission, "verify_phase6_asset_residency", side_effect=PermissionError("pool gate failed")) as pool:
            with self.assertRaisesRegex(admission.AdmissionError, "pool gate failed"):
                self.validate(candidate, self.required[:1])
        self.assertEqual(pool.call_args.kwargs["required_asset_ids"], [])

    def test_legacy_rights_cannot_borrow_static_capacity(self):
        candidate = copy.deepcopy(self.value)
        candidate["schema_version"] = "1.0.0"
        for row in candidate["assets"]:
            row.pop("media_kind")
            row.pop("static_rights")
        with self.assertRaisesRegex(admission.AdmissionError, "legacy rights"):
            self.validate(candidate)

    def test_real_verifier_rejects_synthetic_documents_without_any_mock(self):
        # The positive dispatch fixtures above must not become real evidence.
        with self.assertRaisesRegex(admission.AdmissionError, "static rights"):
            self.validate()

    def test_fixture_approval_asset_drift_and_publication_claim_all_block(self):
        mutations = [lambda p: p.update(status="PASS_FIXTURE_NOT_LIVE", evidence_mode="FIXTURE"),
                     lambda p: p.update(asset_id="other"), lambda p: p.update(source_ready=True),
                     lambda p: p["authority"].update(publication_authorized=True),
                     lambda p: p["artifacts"]["png_binding"].update(sha256="0" * 64),
                     lambda p: p["source_proof"].update(timeline_canonical_sha256="sha256:" + "0" * 64)]
        for mutation in mutations:
            proof = copy.deepcopy(self.proof)
            mutation(proof)
            candidate = copy.deepcopy(self.value)
            candidate["assets"][0]["static_rights"]["inspection_sha256"] = canonical_sha(proof)
            with patch.object(rights, "inspect_static_asset_rights", return_value=proof), \
                 self.assertRaises(admission.AdmissionError):
                self.validate(candidate)

    def test_typed_schema_rejects_duration_wrong_kind_missing_rights_and_font_authority(self):
        for mutation in (lambda v: v["assets"][0].update(duration_ms=1000),
                         lambda v: v["assets"][0].update(media_kind="VIDEO_CFR"),
                         lambda v: v["assets"][0].update(static_rights=None),
                         lambda v: v["assets"][0].update(rights_status="CC_COMMERCIAL"),
                         lambda v: v.update(publication_authorized=True)):
            value = copy.deepcopy(self.value)
            mutation(value)
            with self.assertRaises(admission.AdmissionError):
                admission._validate_schema(self.identified(value)[0])

    def test_both_typed_and_legacy_video_paths_keep_residency_binding(self):
        candidate = copy.deepcopy(self.value)
        candidate["assets"] = [candidate["assets"][1]]
        for version in ("1.1.0", "1.0.0"):
            candidate["schema_version"] = version
            if version == "1.0.0":
                candidate["assets"][0].pop("media_kind")
                candidate["assets"][0].pop("static_rights")
            with patch.object(admission, "verify_phase6_asset_residency", return_value={"manifest_content_hash": "sha256:" + "4" * 64}):
                self.assertEqual(self.validate(candidate, self.required[1:])["asset_count"], 1)
            with patch.object(admission, "verify_phase6_asset_residency", return_value={"manifest_content_hash": "sha256:" + "0" * 64}), \
                 self.assertRaisesRegex(admission.AdmissionError, "manifest"):
                self.validate(candidate, self.required[1:])


if __name__ == "__main__":
    unittest.main()
