from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from hero_engine import maintenance_protocol as protocol
from hero_engine import maintenance_unittest_result as verifier
from tests import test_daily_maintenance_protocol as daily_fixture
from tests import test_maintenance_inventory_aliases as alias_fixture
from tests import test_maintenance_unittest_result as log_fixture


ROOT = Path(__file__).resolve().parents[1]


def _quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def _bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _digest(payload):
    return "sha256:" + hashlib.sha256(payload).hexdigest()


class DailyRegressionConsumerTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="daily-result-consumer-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "raiz ação"
        self.root.mkdir()
        (self.root / "tests").mkdir()
        # Exact authenticated donors, parsed statically by the real producer;
        # their tests/load_tests are not executed and their pins are unchanged.
        for relative in (alias_fixture.LOADER, alias_fixture.SOURCE):
            (self.root / relative).write_bytes((ROOT / relative).read_bytes())
        manifest = protocol.build_validation_manifests(self.root, output_dir=Path("inventory"))
        self.inventory = json.loads((self.root / manifest["test_inventory_path"]).read_bytes())
        self.assertEqual(7, self.inventory["alias_count"])
        self.case = 0
        self.function = daily_fixture.DailyMaintenanceProtocolTests._powershell_function("Confirm-RegressionResult")

    def _run(self, *, inventory=None, result_mutation=None, inventory_mutation=None,
             log_mutation=None, stdout=b"", process_exit="0", expected_count=None,
             pin_mutation=None, raw_result=None, shell=None, skip=False):
        original = copy.deepcopy(inventory or self.inventory)
        log = alias_fixture._log(original)
        if skip:
            test_id = log_fixture.SKIP_ID
            log = (f"{test_id.rsplit('.', 1)[-1]} ({test_id}) ... skipped "
                   "\"file symlink unavailable: [WinError 1314] ação permitida\"\n"
                   "Ran 1 test in 0.125s\n\nOK (skipped=1)\n")
        produced = verifier.verify_unittest_result(
            inventory=original, stdout_bytes=b"", stderr_bytes=log.encode(), process_exit_code=0,
        )
        result = {key:value for key,value in produced.items() if key != "outcomes"}
        if result_mutation:
            result_mutation(result)
        pin = _digest(_bytes(original))
        count = original["test_count"] if expected_count is None else expected_count
        if inventory_mutation:
            inventory_mutation(original)
        if log_mutation:
            log = log_mutation(log)
        if pin_mutation:
            pin = pin_mutation(pin, original)
        self.case += 1
        case = self.root / f"case-{self.case}"
        case.mkdir()
        for name, payload in {
            "inventory.json":_bytes(original), "stdout.log":stdout, "stderr.log":log.encode(),
            "response.json":(raw_result if raw_result is not None else json.dumps(result, ensure_ascii=True)).encode(),
            "PAUSE":b"OWNED_FIXTURE_PAUSED\n", "manager.lock":b"OWNED_FIXTURE_LOCK\n",
        }.items():
            (case / name).write_bytes(payload)
        harness = case / "consumer.ps1"
        harness.write_text(
            "$ErrorActionPreference = 'Stop'\n"
            "[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)\n"
            + self.function + "\ntry {\n"
            + f"$raw = [IO.File]::ReadAllText({_quote(case / 'response.json')}, [Text.Encoding]::UTF8)\n"
            + f"$answer = Confirm-RegressionResult -PythonPath {_quote(sys.executable)} "
            + f"-InventoryPath {_quote(case / 'inventory.json')} -InventoryHash {_quote(pin)} "
            + f"-ExpectedTestCount {count} -ProcessExitCode {process_exit} "
            + f"-StdoutPath {_quote(case / 'stdout.log')} -StderrPath {_quote(case / 'stderr.log')} -ResultJson $raw\n"
            + "@{accepted=$true; result=$answer; ps_major=$PSVersionTable.PSVersion.Major} | ConvertTo-Json -Depth 20 -Compress\n"
            + "} catch { @{accepted=$false; error=$_.Exception.Message} | ConvertTo-Json -Compress }\n",
            encoding="utf-8-sig",
        )
        before = {p.name:p.read_bytes() for p in case.iterdir()}
        environment = os.environ.copy()
        environment.update(PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
        for key in list(environment):
            if key.casefold() == "psmodulepath":
                environment.pop(key)  # existing native PS5/7 fixture isolation
        shell = shell or shutil.which("pwsh.exe")
        self.assertIsNotNone(shell, "The current PS7 test host must exist")
        completed = subprocess.run(
            [shell, "-NoLogo", "-NoProfile", "-NonInteractive", "-File", str(harness)],
            cwd=self.root, env=environment, capture_output=True, timeout=20, check=False,
        )
        self.assertEqual(0, completed.returncode, completed.stderr.decode(errors="replace"))
        self.assertEqual(before, {p.name:p.read_bytes() for p in case.iterdir()}, "Consumer wrote to its inputs/protected fixture")
        return json.loads(completed.stdout.decode("utf-8-sig"))

    def test_actual_daily_call_consumes_raw_response_and_frozen_manifest(self):
        # Wiring assertion supplements the extracted real-function executions.
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        call = script[script.index("$testVerification = Confirm-RegressionResult"):]
        call = call[:call.index("$executedTestCount")]
        for fragment in ("$inventory.test_inventory_hash", "$inventory.test_count", "$tests.exit_code",
                         "$testInventoryPath", "$testOut", "$testErr", '$testVerificationRaw -join "`n"'):
            self.assertIn(fragment, call)
        self.assertIn("if ($testVerificationExitCode -ne 0)", script)

    def test_v11_authenticated_aliases_pass_in_ps7(self):
        answer = self._run()
        self.assertTrue(answer["accepted"], answer)
        self.assertEqual(7, answer["ps_major"])
        result = answer["result"]
        self.assertEqual("1.1.0", result["schema_version"])
        self.assertEqual(7, result["alias_count"])
        self.assertEqual(result["method_count"] + 7, result["test_count"])
        self.assertEqual(protocol.canonical_hash(self.inventory), result["inventory_identity_hash"])

    def test_v11_and_rejection_run_in_native_ps5(self):
        shell = shutil.which("powershell.exe")
        self.assertIsNotNone(shell, "Existing native PS5 is required")
        answer = self._run(shell=shell)
        self.assertTrue(answer["accepted"], answer)
        self.assertEqual(5, answer["ps_major"])
        bad = self._run(shell=shell, result_mutation=lambda r:r.pop("inventory_identity_hash"))
        self.assertFalse(bad["accepted"], bad)

    def test_v10_compatible_result_is_not_upgraded(self):
        old = log_fixture._inventory(log_fixture.PASS_ID)
        answer = self._run(inventory=old)
        self.assertTrue(answer["accepted"], answer)
        self.assertEqual("1.0.0", answer["result"]["schema_version"])
        for field in ("method_count", "alias_count", "inventory_identity_hash"):
            self.assertNotIn(field, answer["result"])
        for mutation in (lambda r:r.update(alias_count=0), lambda r:r.update(schema_version="1.1.0")):
            with self.subTest(mutation=mutation):
                self.assertFalse(self._run(inventory=old, result_mutation=mutation)["accepted"])

    def test_unknown_versions_and_legacy_alias_smuggling_block(self):
        self.assertFalse(self._run(result_mutation=lambda r:r.update(schema_version="9.0.0"))["accepted"])
        for version in ("9.0.0", "1.0.0"):
            with self.subTest(version=version):
                answer = self._run(inventory_mutation=lambda i:i.update(schema_version=version),
                                   pin_mutation=lambda _,i:_digest(_bytes(i)))
                self.assertFalse(answer["accepted"], answer)

    def test_result_identity_counts_status_and_types_are_execution_bound(self):
        mutations = {"inventory_identity_hash":"sha256:"+"0"*64, "method_count":1,
                     "alias_count":0, "test_count":1, "status":"FAIL",
                     "process_exit_code_verified":1, "skipped_count":True, "duration_seconds":1}
        for field, value in mutations.items():
            with self.subTest(field=field):
                answer = self._run(result_mutation=lambda r:r.update({field:value}))
                self.assertFalse(answer["accepted"], answer)

    def test_frozen_inventory_bytes_and_external_count_cannot_be_rebased(self):
        changed = self._run(inventory_mutation=lambda i:i.update(discovery_pattern="forged"))
        self.assertFalse(changed["accepted"], changed)
        wrong_count = self._run(expected_count=self.inventory["test_count"]+1)
        self.assertFalse(wrong_count["accepted"], wrong_count)
        missing_pin = self._run(pin_mutation=lambda _,i:"")
        self.assertFalse(missing_pin["accepted"], missing_pin)

    def test_inventory_aliases_cannot_be_forged_even_with_consistent_count_claims(self):
        def tamper(inventory):
            inventory["load_tests_aliases"][0]["source_hash"] = "sha256:"+"0"*64
            inventory["aliases_hash"] = protocol.canonical_hash(inventory["load_tests_aliases"])
        answer = self._run(inventory_mutation=tamper, pin_mutation=lambda _,i:_digest(_bytes(i)))
        self.assertFalse(answer["accepted"], answer)

    def test_nonzero_absent_or_coerced_exit_code_cannot_use_pass_response(self):
        for value in ("7", "$null", "$false", "'0'"):
            with self.subTest(value=value):
                answer = self._run(process_exit=value)
                self.assertFalse(answer["accepted"], answer)

    def test_allowed_skip_keeps_identity_reason_and_unicode_in_ps5(self):
        old = log_fixture._inventory(log_fixture.SKIP_ID)
        shell = shutil.which("powershell.exe")
        self.assertIsNotNone(shell)
        answer = self._run(inventory=old, skip=True, shell=shell)
        self.assertTrue(answer["accepted"], answer)
        self.assertEqual(1, answer["result"]["skipped_count"])
        skips = answer["result"]["allowed_skips"]
        self.assertIsInstance(skips, list)
        self.assertEqual(log_fixture.SKIP_ID, skips[0]["test_id"])
        self.assertIn("ação permitida", skips[0]["reason"])

    def test_unapproved_or_falsified_skip_and_log_process_error_block(self):
        old = log_fixture._inventory(log_fixture.PASS_ID)
        for transform in (
            lambda log:f'test_ok ({log_fixture.PASS_ID}) ... skipped "not available"\nRan 1 test in 0.125s\n\nOK (skipped=1)\n',
            lambda log:f'test_ok ({log_fixture.PASS_ID}) ... ERROR\nRan 1 test in 0.125s\n\nFAILED (errors=1)\n',
        ):
            with self.subTest(transform=transform):
                self.assertFalse(self._run(inventory=old, log_mutation=transform)["accepted"])
        allowed = log_fixture._inventory(log_fixture.SKIP_ID)
        answer = self._run(inventory=allowed, skip=True,
                           result_mutation=lambda r:r["allowed_skips"][0].update(reason="invented"))
        self.assertFalse(answer["accepted"], answer)

    def test_incomplete_result_and_truncated_logs_never_pass(self):
        for field in ("schema_version", "status", "test_count", "process_exit_code_verified",
                      "inventory_identity_hash", "method_count", "alias_count", "allowed_skips", "skipped_count", "duration_seconds"):
            with self.subTest(field=field):
                self.assertFalse(self._run(result_mutation=lambda r:r.pop(field))["accepted"])
        self.assertFalse(self._run(raw_result="{}")["accepted"])
        self.assertFalse(self._run(raw_result="not json")["accepted"])
        self.assertFalse(self._run(log_mutation=lambda log:log[:log.index("Ran ")])["accepted"])
        self.assertFalse(self._run(stdout=b"Ran 1 test in 0.001s\nOK\n")["accepted"])

    def test_historical_unverified_exit_remains_historical_only(self):
        old = log_fixture._inventory(log_fixture.PASS_ID)
        raw = _bytes(old)
        log = alias_fixture._log(old).encode()
        historic = verifier.verify_unittest_result(inventory=old, stdout_bytes=b"", stderr_bytes=log, process_exit_code=None)
        self.assertIs(historic["process_exit_code_verified"], False)
        public = {k:v for k,v in historic.items() if k!="outcomes"}
        for exit_code in (None, 0):
            with self.subTest(exit_code=exit_code):
                with self.assertRaises(verifier.UnittestResultError):
                    verifier.consume_execution_result(result=public, inventory_bytes=raw,
                        expected_inventory_hash=_digest(raw), expected_test_count=old["test_count"],
                        stdout_bytes=b"", stderr_bytes=log, process_exit_code=exit_code)

    def test_default_verifier_cli_keeps_legacy_and_current_public_contracts(self):
        for inventory in (log_fixture._inventory(log_fixture.PASS_ID), self.inventory):
            with self.subTest(version=inventory["schema_version"]):
                folder = self.root / ("cli-" + inventory["schema_version"])
                folder.mkdir()
                (folder / "inventory.json").write_bytes(_bytes(inventory))
                (folder / "stdout.log").write_bytes(b"")
                log = alias_fixture._log(inventory).encode()
                (folder / "stderr.log").write_bytes(log)
                expected = verifier.verify_unittest_result(inventory=inventory, stdout_bytes=b"", stderr_bytes=log, process_exit_code=0)
                expected.pop("outcomes")
                before = {p.name:p.read_bytes() for p in folder.iterdir()}
                completed = subprocess.run(
                    [sys.executable, "-B", "-X", "utf8", "-m", "hero_engine.maintenance_unittest_result",
                     "--inventory", str(folder / "inventory.json"), "--stdout", str(folder / "stdout.log"),
                     "--stderr", str(folder / "stderr.log"), "--exit-code", "0"],
                    cwd=self.root, env=dict(os.environ, PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE="1"),
                    capture_output=True, timeout=20, check=False,
                )
                self.assertEqual(0, completed.returncode, completed.stderr.decode(errors="replace"))
                self.assertEqual(expected, json.loads(completed.stdout))
                self.assertEqual(before, {p.name:p.read_bytes() for p in folder.iterdir()})


if __name__ == "__main__":
    unittest.main()
