"""Stage-A join tests using an externally pinned real result as a fixture.

The inspector seam does NOT claim a fresh source evaluation. Actual metadata
and dependency bytes are reopened; no PNG/PCM/ASR/OCR/render is repeated.
"""
import copy
from pathlib import Path
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_asset_use_binding as joiner
from hero_engine import phase6_av_compact_sources as compact
from hero_engine import phase6_av_static_asset_uses_v2 as uses
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]
BASE = "output/operations/phase6/av-admission/static-asset-uses-v2/"
INPUT = {"path": BASE + "input.json", "sha256": "sha256:65be03122e4ad1c17e74e7bff99324f0177e0a541735ecbdc85a9883fd828376"}
INSPECTION_SHA = "14641e1282f3e0fa2b6540ac04abbac6e01629d476c9dffc1101af2165a5330e"
RECEIPT_SHA = "9e14abf9d38b3e8c01b621f4fad9f4c9e11c7ddd6df9dd239e4fa0d658842243"
HELPER_SHA = "f3cd3a30fb8a2d6ad26647d5c6143bd3ac93a7cdb433b44d02a5cc6278ad6cf6"


class AssetUseBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assert_pin(ROOT / joiner.PATH, HELPER_SHA)
        cls.assert_pin(ROOT / (BASE + "input.json"), INPUT["sha256"][7:])
        cls.assert_pin(ROOT / (BASE + "inspection.json"), INSPECTION_SHA)
        cls.assert_pin(ROOT / (BASE + "receipt.json"), RECEIPT_SHA)
        cls.fixture_proof = compact.primitives._json((ROOT / (BASE + "inspection.json")).read_bytes())
        receipt = compact.primitives._json((ROOT / (BASE + "receipt.json")).read_bytes())
        if receipt["inspection_binding"] != {"path": BASE + "inspection.json", "sha256": INSPECTION_SHA}:
            raise AssertionError("independent fixture receipt does not bind this inspection")
        with patch.object(compact.primitives, "_png", side_effect=AssertionError("metadata only")):
            _, cls.literal, _, _, _ = compact._preflight(ROOT)

    @staticmethod
    def assert_pin(path, expected):
        if compact.primitives._sha(path.read_bytes()) != expected:
            raise AssertionError("frozen test source/fixture pin drift: " + path.name)

    def proof(self):
        return copy.deepcopy(self.fixture_proof)

    def test_join_exact_real_metadata_preserves_twenty_five_uses_and_seventy_five_unbound(self):
        proof = self.proof()
        original = copy.deepcopy(proof)
        result = joiner.join(proof, INPUT, self.literal)
        self.assertEqual((result["source_count"], result["use_count"], result["unique_png_content_count"], result["lineage_count"]), (23, 25, 22, 3))
        self.assertEqual(result["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(result["remaining_unbound_visual_state_ids"]), 75)
        self.assertEqual(result["scope"], "UNTIMED_ASSET_USE_METADATA_ONLY")
        self.assertEqual(result["inspection_sha256"], joiner.canonical_sha(proof))
        self.assertEqual(result["effective_rows_sha256"], joiner.canonical_sha(self.literal["rows"]))
        self.assertEqual(result["use_rows_sha256"], joiner.canonical_sha(proof["uses"]))
        self.assertTrue(all(value is False for value in result["authority"].values()))
        for key in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
            self.assertIs(result[key], False)
        self.assertEqual(result["technical_cost_brl"], 0)
        self.assertEqual(proof, original)
        result["source_binding"]["sha256"] = "changed locally"
        self.assertEqual(INPUT["sha256"], "sha256:65be03122e4ad1c17e74e7bff99324f0177e0a541735ecbdc85a9883fd828376")

    def test_binding_shape_namespace_and_pin_requirements_fail_before_inspector(self):
        invalid = [None, [], {}, {**INPUT, "sha256": INPUT["sha256"][7:]},
                   {**INPUT, "sha256": "sha256:" + "A" * 64}, {**INPUT, "size_bytes": 1},
                   {**INPUT, "path": "../input.json"}, {**INPUT, "path": "C:/Windows/input.json"},
                   {**INPUT, "path": "/absolute/input.json"}, {**INPUT, "path": ""}, {**INPUT, "path": 3}]
        with patch.object(uses, "inspect_static_asset_uses", side_effect=AssertionError("binding preflight must run first")) as inspector:
            for binding in invalid:
                with self.subTest(binding=binding), self.assertRaises(ValueError):
                    joiner.read_asset_use_binding(Reader(ROOT), binding, self.literal, proof_sink=[])
            with self.assertRaisesRegex(ValueError, "source hash mismatch"):
                joiner.read_asset_use_binding(Reader(ROOT), {**INPUT, "sha256": "sha256:" + "0" * 64}, self.literal, proof_sink=[])
        self.assertEqual(inspector.call_count, 0)

    def test_scope_authority_and_exact_numeric_types_cannot_be_promoted(self):
        mutations = [("version", "phase6-av-static-asset-uses-v1"), ("status", "PRODUCTION_READY"),
                     ("source_count", 23.0), ("use_count", 100), ("unique_png_content_count", 23),
                     ("lineage_count", 23), ("source_ready", True), ("global_schedule_created", True),
                     ("calibrated_timing_available", True), ("technical_cost_brl", False),
                     ("authority", {**joiner.AUTHORITY, "publication": True}),
                     ("channel_id", "different-channel"), ("video_id", "video-001")]
        for field, value in mutations:
            proof = self.proof(); proof[field] = value
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "scope or authority"):
                joiner.join(proof, INPUT, self.literal)
        proof = self.proof(); proof["input_binding"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "input differs"):
            joiner.join(proof, INPUT, self.literal)

    def test_different_amendment_or_changed_copy_unit_entry_and_hold_are_rejected(self):
        for literal in (None, {**self.literal, "adapter_version": "phase6-av-visual-intent-v1"}):
            with self.assertRaisesRegex(ValueError, "independently amended"):
                joiner.join(self.proof(), INPUT, literal)
        proof = self.proof(); proof["visual_amendment_evidence"]["inspection_sha256"] = "sha256:" + "0" * 64
        with self.assertRaisesRegex(ValueError, "another visual amendment"):
            joiner.join(proof, INPUT, self.literal)
        for kind in ("copy", "unit", "write_as_boundary", "write_float", "hold_new_reveal", "hold_wrong_previous"):
            proof = self.proof()
            target = next(row for row in proof["uses"] if row["visual_state_id"] == (
                "visual-u016-s01" if kind.startswith("hold") else "visual-u011-s01"))
            if kind == "copy": target["literal_copy"] = ["Already ruined"]
            elif kind == "unit": target["unit_id"] = "narration-unit-012"
            elif kind == "write_as_boundary": target["entry"] = {"kind": "UNIT_ENTRY", "char_start": None, "char_end": None, "text": None, "previous_state_id": None}
            elif kind == "write_float": target["entry"]["char_start"] = 14.0
            elif kind == "hold_new_reveal": target["entry"]["kind"] = "LEXICAL_START"
            else: target["entry"]["previous_state_id"] = "visual-u017-s00"
            with self.subTest(kind=kind), self.assertRaisesRegex(ValueError, "entry, copy or unit"):
                joiner.join(proof, INPUT, self.literal)

    def test_coverage_duplicates_missing_states_and_unbound_omission_fail_closed(self):
        for kind in ("duplicate_use", "missing_use", "remaining_omitted", "remaining_extra", "uses_type"):
            proof = self.proof()
            if kind == "duplicate_use": proof["uses"][-1] = copy.deepcopy(proof["uses"][-2])
            elif kind == "missing_use": proof["uses"].pop()
            elif kind == "remaining_omitted": proof["remaining_unbound_visual_state_ids"].pop()
            elif kind == "remaining_extra": proof["remaining_unbound_visual_state_ids"].append("visual-u011-s01")
            else: proof["uses"] = tuple(proof["uses"])
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                joiner.join(proof, INPUT, self.literal)
        literal = copy.deepcopy(self.literal)
        literal["rows"][0]["states"].append(copy.deepcopy(literal["rows"][0]["states"][0]))
        proof = self.proof()
        proof["visual_amendment_evidence"]["inspection_sha256"] = joiner.canonical_sha(literal)
        proof["visual_amendment_evidence"]["effective_rows_sha256"] = joiner.canonical_sha(literal["rows"])
        with self.assertRaisesRegex(ValueError, "duplicate states"):
            joiner.join(proof, INPUT, literal)

    def test_read_orchestration_reopens_real_dependencies_with_explicit_inspector_fixture(self):
        proof, reader, sink = self.proof(), Reader(ROOT), []
        with patch.object(uses, "inspect_static_asset_uses", return_value=proof) as inspector, \
             patch.object(compact.primitives, "_png", side_effect=AssertionError("no decode in binding test")), \
             patch("subprocess.Popen", side_effect=AssertionError("no process")), \
             patch("socket.create_connection", side_effect=AssertionError("no network")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("no file write")):
            result = joiner.read_asset_use_binding(reader, INPUT, self.literal, proof_sink=sink)
        inspector.assert_called_once_with(ROOT, binding={"path": INPUT["path"], "sha256": INPUT["sha256"][7:]})
        self.assertEqual(len(sink), 1)
        self.assertIs(sink[0], proof)
        self.assertEqual(result, joiner.join(proof, INPUT, self.literal))
        for item in proof["dependency_bindings"]:
            path = Path(item["path"])
            if path.is_relative_to(ROOT):
                actual = reader.bindings[path.relative_to(ROOT).as_posix()]
                self.assertEqual((actual["sha256"], actual["size_bytes"]), ("sha256:" + item["sha256"], item["size_bytes"]))

    def test_fresh_sink_and_mutated_dependency_pins_cannot_be_accepted(self):
        for sink in (None, {}, [self.proof()]):
            with patch.object(uses, "inspect_static_asset_uses", side_effect=AssertionError("fresh sink required")), self.assertRaisesRegex(ValueError, "fresh same-call"):
                joiner.read_asset_use_binding(Reader(ROOT), INPUT, self.literal, proof_sink=sink)
        for kind in ("font", "foreign", "missing_external", "float_size"):
            proof, sink = self.proof(), []
            font = next(item for item in proof["dependency_bindings"] if item["path"] == str(compact.primitives.FONT))
            if kind == "font": font["sha256"] = "0" * 64
            elif kind == "foreign": font["path"] = "C:/Windows/win.ini"
            elif kind == "missing_external": proof["dependency_bindings"].remove(font)
            else: proof["dependency_bindings"][0]["size_bytes"] = float(proof["dependency_bindings"][0]["size_bytes"])
            with self.subTest(kind=kind), patch.object(uses, "inspect_static_asset_uses", return_value=proof), self.assertRaises(ValueError):
                joiner.read_asset_use_binding(Reader(ROOT), INPUT, self.literal, proof_sink=sink)
            self.assertEqual(sink, [])

    def test_final_dependency_mutation_leaves_sink_empty_and_does_not_retry(self):
        proof, sink = self.proof(), []
        target = Path(proof["sources"][0]["asset_binding"]["path"])
        actual_read, actual_recheck = Path.read_bytes, compact.primitives.recheck_static_dependencies
        armed = {"value": False}
        def changed(path):
            raw = actual_read(path)
            return bytes([raw[0] ^ 1]) + raw[1:] if armed["value"] and path == target else raw
        def late_recheck(root, proofs):
            armed["value"] = True
            return actual_recheck(root, proofs)
        with patch.object(uses, "inspect_static_asset_uses", return_value=proof) as inspector, \
             patch.object(compact.primitives, "recheck_static_dependencies", side_effect=late_recheck), \
             patch.object(Path, "read_bytes", changed), self.assertRaisesRegex(ValueError, "hash mismatch"):
            joiner.read_asset_use_binding(Reader(ROOT), INPUT, self.literal, proof_sink=sink)
        self.assertEqual(inspector.call_count, 1)
        self.assertEqual(sink, [])


if __name__ == "__main__":
    unittest.main()
