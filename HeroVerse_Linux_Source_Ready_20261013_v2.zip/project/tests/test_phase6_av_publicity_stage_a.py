"""Isolated adapter tests: synthetic full flow, real A12 metadata rejection.

The synthetic family deliberately replaces A/context/schema/dependency-domain
boundaries; it checks orchestration, never a LIVE timeline or decoder. Actual
schema/path/hash rejection and the actual A12 BLOCKED case are separate tests.
No test invokes real A.verify, queue resolution, source replay, WAV measurement,
image decoding, OCR, rendering or PUBLICITY observation.
"""
from __future__ import annotations

import copy
import inspect
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import Mock, patch

from hero_engine import phase6_av_publicity_stage_a as M

ROOT = Path(__file__).absolute().parents[1]
ROOT_JOB = "job-" + "1" * 24
REAL_TIMELINE = M.TIMELINES + "/phase6-av-timeline-cc5a42e083848fe0a7c6e843.json"
REAL_TIMELINE_SHA = "sha256:c38a12e6e7c5c2b5a131282ba22d674e0f3c789542ec74d9d58e467c574bedf6"
REAL_ARGUMENTS = M.ARGUMENTS + "/phase6-av-arguments-dad851b21ac0f18afd7c55e5.json"
REAL_ARGUMENTS_SHA = "sha256:b671e551e9560385ae7c4a18ed21a9b6c52386a68f772a03856fad077bee926e"


def bound(root, path):
    raw = (root / path).read_bytes()
    return {"path": path, "sha256": M._sha(raw), "size_bytes": len(raw)}


def persist(root, path, value):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(M._canonical(value))
    return bound(root, path)


def addressed(root, parent, field, prefix, value):
    value.pop(field, None)
    value[field] = prefix + M._sha(M._canonical(value))[7:31]
    return persist(root, parent + "/" + value[field] + ".json", value)


class SyntheticOrchestrationTests(unittest.TestCase):
    """Explicit boundary doubles. Success proves orchestration ONLY."""
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.asset = self.root / "source.fixture"
        self.asset.write_bytes(b"NOT_AN_IMAGE_OR_MEDIA_DECLARED_FIXTURE")
        self.take = self.root / "take_plan.json"
        self.take.write_bytes(b'{"kind":"DECLARED_FIXTURE_NOT_A_TAKE_PLAN"}')
        take_binding = {"path": "take_plan.json", "sha256": M._sha(self.take.read_bytes())}
        self.args = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_RAW_ARGUMENTS", "evidence_mode": "LIVE",
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA", "video_id": "phase6-video-002-prepublication", "protocol_id": "EXPLICIT_FIXTURE",
            "arguments": {"source_bindings": {"take_plan": take_binding,
                **{k: {"path": "fixture-only", "sha256": "sha256:" + "0" * 64} for k in
                   ("body_case_amendment", "body_case_evidence", "body_case_staging", "literal_asset_uses")}},
                "pause_decisions": [], "render_spans": [], "visual_events": [], "caption_cues": [],
                "temporal_evidence_bindings": {}, "temporal_policy_binding": None},
            "authority": {}, "technical_cost_brl": 0,
        }
        span = {"span_id": "fixture-static", "asset_binding": {"path": "source.fixture", "sha256": M._sha(self.asset.read_bytes())},
                "media_kind": "STATIC_IMAGE", "source_start_frame": 0, "source_end_frame": 1, "source_frame_count": 1,
                "start_frame": 0, "end_frame": 60}
        self.args["arguments"]["render_spans"] = [{k: span[k] for k in
            ("span_id", "start_frame", "end_frame", "source_start_frame", "source_end_frame")}]
        self.timeline = {
            "schema_version": "1.11.0", "timeline_version": "phase6-av-timeline-v12",
            "status": "TIMELINE_VALIDATED_NOT_ADMITTED", "blockers": [], "derived_take_plan": {"declared_fixture": True},
            **{k: self.args[k] for k in ("channel_id", "video_id", "protocol_id")},
            "inputs": copy.deepcopy(self.args["arguments"]), "render_spans": [span],
            "units": [{"unit_id": f"narration-unit-{n:03d}"} for n in range(1, 52)],
            "narration_fragment_map": [{"take_id": f"take-{n:03d}"} for n in range(1, 91)],
            "temporal_evidence_assessment": {"scope_complete": True, "fixture_evidence_present": False, "all_required_evidence_live": True},
            "authority": {k: False for k in ("synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized", "quality_approved")},
            "technical_cost_brl": 0, "source_file_bindings": [bound(self.root, "source.fixture")],
            "implementation": {"path": M.A_MODULE, "sha256": M.A_PINS[M.A_MODULE]},
            "implementation_dependencies": [{"path": k, "sha256": v} for k, v in M.A_PINS.items() if k != M.A_MODULE],
        }
        self.input_doc = {"receipt_id": "phase6-production-inputs-DECLARED-FIXTURE", "channel_id": self.args["channel_id"],
            "action": "PREPARE_VIDEO_2_INPUTS", "publication_authorized": False, "technical_cost_brl": 0,
            "artifacts": [bound(self.root, "take_plan.json")]}
        self.observation = {"context_version": "phase6-av-observational-context-v1",
            "status": "OBSERVED_TERMINAL_CONTEXT_NOT_TRANSACTION_AUTHORITY",
            "authority": {k: False for k in ("admission", "successor_creation", "queue_claim", "render", "publication")},
            "transaction_fencing_verified": False, "external_publication_lock_verified": False,
            "context": {"authority_root_job_id": ROOT_JOB, "predecessor_job_id": "fixture-tail",
                "tail_job_id": "fixture-tail", "predecessor_state": "SUCCEEDED", "predecessor_lease_owner": None},
        }
        self.resave()
        self.schema = self.enterContext(patch.object(M, "_schema", name="EXPLICIT_SYNTHETIC_SCHEMA_BOUNDARY"))
        self.resolver = self.enterContext(patch.object(M, "_resolve_context", side_effect=lambda *a: copy.deepcopy(self.observation)))
        self.verifier = self.enterContext(patch.object(M, "_verify_timeline", side_effect=self.fixture_verifier))
        self.dependency_rechecks = 0
        self.closure = self.enterContext(patch.object(M, "_dependency_closure", side_effect=self.fixture_closure))

    def resave(self):
        self.argument_binding = addressed(self.root, M.ARGUMENTS, "arguments_id", "phase6-av-arguments-", self.args)
        self.timeline_binding = addressed(self.root, M.TIMELINES, "timeline_id", "phase6-av-timeline-", self.timeline)
        self.expected = copy.deepcopy(self.timeline)
        input_pin = persist(self.root, M.INPUTS + "/" + self.input_doc["receipt_id"] + ".json", self.input_doc)
        self.observation["input_receipt"] = {"receipt_id": self.input_doc["receipt_id"], **input_pin}
        self.observation["context"].update(input_receipt_id=self.input_doc["receipt_id"], input_receipt_sha256=input_pin["sha256"])

    def fixture_verifier(self, root, candidate, arguments):
        self.assertEqual(root, self.root)
        M._same(candidate, self.expected, "DECLARED_FIXTURE_CANONICAL_MISMATCH")
        M._same(arguments, self.expected["inputs"], "DECLARED_FIXTURE_ARGUMENT_MISMATCH")
        return copy.deepcopy(self.expected)

    def fixture_closure(self, root, result):
        self.assertEqual(result, self.expected)
        files = M._Files()
        files.read(self.asset, M._sha(self.asset.read_bytes()))
        def recheck():
            self.dependency_rechecks += 1
            files.recheck()
        return recheck

    def prepared(self, **changes):
        args = {"timeline_binding": self.timeline_binding, "arguments_binding": self.argument_binding,
                "expected_root_job_id": ROOT_JOB, **changes}
        return M.verified_stage_a(self.root, **args)

    def assert_early_failure(self):
        with self.assertRaises(M.StageAError), self.prepared(): self.fail("unexpected yielded authority")
        self.verifier.assert_not_called()
        self.resolver.assert_not_called()
        self.closure.assert_not_called()

    def test_one_verifier_per_scope_and_static_source_interval_preserved(self):
        with self.prepared() as view:
            self.assertEqual(self.verifier.call_count, 1)
            self.assertEqual([view.timeline["render_spans"][0][k] for k in
                ("source_start_frame", "source_end_frame", "source_frame_count")], [0, 1, 1])
            self.assertNotIn("fps", view.timeline["render_spans"][0])
            self.assertEqual(view.evidence["stage_a_verifier_calls"], 1)
            self.assertFalse(any(view.evidence["authority"].values()))
            self.assertEqual(view.evidence["status"], "CANONICAL_STAGE_A_SCOPE_NOT_ADMITTED")
            view.recheck()
        self.assertEqual(self.verifier.call_count, 1)
        self.assertEqual(self.dependency_rechecks, 3)
        self.assertEqual(self.resolver.call_count, 4)

    def test_returned_data_cannot_mutate_private_evidence_and_view_expires(self):
        with self.prepared() as view:
            altered = view.timeline
            altered["render_spans"].clear()
            self.assertEqual(len(view.timeline["render_spans"]), 1)
            evidence = view.evidence
            evidence["authority"]["publication_authorized"] = True
            self.assertFalse(view.evidence["authority"]["publication_authorized"])
        with self.assertRaises(M.StageAError): view.recheck()
        with self.assertRaises(M.StageAError): _ = view.timeline

    def test_incomplete_rejected_before_verifier_context_or_dependency_work(self):
        for field, value in (("status", "BLOCKED_INCOMPLETE"), ("derived_take_plan", None),
                             ("render_spans", []), ("blockers", ["TEMPORAL_PENDING"])):
            with self.subTest(field=field):
                original = self.timeline[field]
                self.timeline[field] = value; self.resave(); self.assert_early_failure()
                self.timeline[field] = original

    def test_missing_external_arguments_mismatched_mode_identity_and_population(self):
        for mutate in (
            lambda: self.args.update(evidence_mode="FIXTURE"),
            lambda: self.args.update(protocol_id="alien"),
            lambda: self.args["arguments"].update(caption_cues=[{"fabricated": True}]),
            lambda: self.timeline["implementation_dependencies"].pop(),
        ):
            with self.subTest(mutation=mutate):
                old_args, old_timeline = copy.deepcopy(self.args), copy.deepcopy(self.timeline)
                mutate(); self.resave(); self.assert_early_failure()
                self.args, self.timeline = old_args, old_timeline

    def test_alien_complete_candidate_is_not_accepted_from_its_own_inputs(self):
        self.timeline["render_spans"][0]["source_start_frame"] = 7
        self.timeline_binding = addressed(self.root, M.TIMELINES, "timeline_id", "phase6-av-timeline-", self.timeline)
        with self.assertRaisesRegex(M.StageAError, "FIXTURE_CANONICAL_MISMATCH"), self.prepared(): pass
        self.assertEqual(self.verifier.call_count, 1)
        self.closure.assert_not_called()

    def test_forged_verifier_return_cannot_be_used_as_a_new_timeline(self):
        result = copy.deepcopy(self.expected); result["render_spans"] = []
        self.verifier.side_effect = None; self.verifier.return_value = result
        with self.assertRaisesRegex(M.StageAError, "verifier result differs"), self.prepared(): pass
        self.closure.assert_not_called()

    def test_discovered_take_plan_mismatch_or_duplicate_blocks_before_A(self):
        for artifacts in ([{**self.input_doc["artifacts"][0], "sha256": "sha256:" + "a" * 64}],
                          self.input_doc["artifacts"] * 2):
            with self.subTest(artifacts=artifacts):
                self.input_doc["artifacts"] = artifacts; self.resave()
                with self.assertRaisesRegex(M.StageAError, "TakePlan differs"), self.prepared(): pass
                self.verifier.assert_not_called()

    def test_noncanonical_queue_context_or_authority_rejected(self):
        for key, value in (("tail_job_id", "other-tail"), ("predecessor_lease_owner", "active-worker"),
                           ("authority_root_job_id", "job-" + "2" * 24)):
            with self.subTest(key=key):
                old = self.observation["context"][key]
                self.observation["context"][key] = value
                with self.assertRaisesRegex(M.StageAError, "queue tail differs"), self.prepared(): pass
                self.verifier.assert_not_called()
                self.observation["context"][key] = old

    def test_queue_tail_drift_is_detected_at_scope_exit(self):
        with self.assertRaisesRegex(M.StageAError, "root/tail/input changed"):
            with self.prepared(): self.observation["context"]["tail_job_id"] = "new-tail"
        self.assertEqual(self.verifier.call_count, 1)

    def test_source_drift_is_detected_without_second_A(self):
        with self.assertRaisesRegex(M.StageAError, "hash or size differs"):
            with self.prepared(): self.asset.write_bytes(b"changed fixture source")
        self.assertEqual(self.verifier.call_count, 1)

    def test_argument_bytes_drift_is_detected_without_second_A(self):
        with self.assertRaisesRegex(M.StageAError, "hash or size differs"):
            with self.prepared(): (self.root / self.argument_binding["path"]).write_bytes(b"{}")
        self.assertEqual(self.verifier.call_count, 1)

    def test_dependency_inventory_failure_is_not_swallowed(self):
        final = Mock(side_effect=[None, M.StageAError("DECLARED_FIXTURE_INVENTORY_DRIFT")])
        self.closure.side_effect = None; self.closure.return_value = final
        with self.assertRaisesRegex(M.StageAError, "INVENTORY_DRIFT"), self.prepared(): pass
        self.assertEqual(self.verifier.call_count, 1)

    def test_consumer_error_propagates_and_scope_still_rechecks(self):
        with self.assertRaisesRegex(RuntimeError, "consumer interrupted"):
            with self.prepared(): raise RuntimeError("consumer interrupted")
        self.assertEqual(self.dependency_rechecks, 2)
        self.assertEqual(self.verifier.call_count, 1)

    def test_no_public_prepared_or_candidate_dependency_parameter(self):
        self.assertEqual(set(inspect.signature(M.verified_stage_a).parameters),
            {"root", "timeline_binding", "arguments_binding", "expected_root_job_id"})
        with self.assertRaises(TypeError): self.prepared(prepared={"verified": True})
        self.assert_early_failure_for_binding({**self.timeline_binding, "verified": True})

    def assert_early_failure_for_binding(self, binding):
        with self.assertRaises(M.StageAError), self.prepared(timeline_binding=binding): pass
        self.verifier.assert_not_called()

    def test_binding_size_bool_path_alias_or_extra_authority_rejected(self):
        for bad in ({**self.timeline_binding, "size_bytes": True},
                    {**self.timeline_binding, "path": str(self.root / self.timeline_binding["path"])},
                    {**self.timeline_binding, "path": M.TIMELINES + "/../alien.json"},
                    {**self.timeline_binding, "publication_authorized": True}):
            with self.subTest(binding=bad): self.assert_early_failure_for_binding(bad)


class ActualMetadataBoundaryTests(unittest.TestCase):
    def test_real_A12_rejected_without_replay_queue_PCM_backend_or_write(self):
        timeline = bound(ROOT, REAL_TIMELINE); arguments = bound(ROOT, REAL_ARGUMENTS)
        self.assertEqual(timeline["sha256"], REAL_TIMELINE_SHA)
        self.assertEqual(arguments["sha256"], REAL_ARGUMENTS_SHA)
        with self.assertRaisesRegex(M.StageAError, "STAGE_A_INCOMPLETE_NOT_SCREENABLE"):
            M._complete(M._json((ROOT / REAL_TIMELINE).read_bytes()))
        with patch.object(M, "_verify_timeline", side_effect=AssertionError("NO REAL A REPLAY")) as verifier, \
             patch.object(M, "_resolve_context", side_effect=AssertionError("NO QUEUE")) as context, \
             patch.object(M, "_dependency_closure", side_effect=AssertionError("NO SOURCES")) as dependencies, \
             patch.object(Path, "write_bytes", side_effect=AssertionError("NO WRITES")), \
             patch.object(Path, "mkdir", side_effect=AssertionError("NO DIRECTORY CREATION")):
            with self.assertRaisesRegex(M.StageAError, "Stage-A implementation population differs"):
                with M.verified_stage_a(ROOT, timeline_binding=timeline, arguments_binding=arguments,
                                       expected_root_job_id=ROOT_JOB): self.fail("A12 cannot be consumed")
            verifier.assert_not_called(); context.assert_not_called(); dependencies.assert_not_called()

    def test_installed_pin_population_matches_immutable_A12_metadata(self):
        raw = (ROOT / REAL_TIMELINE).read_bytes()
        self.assertEqual(M._sha(raw), REAL_TIMELINE_SHA)
        historical = M._json(raw)
        self.assertEqual(historical["implementation"], {"path": M.A_MODULE, "sha256": M.HISTORICAL_A12_PINS[M.A_MODULE]})
        self.assertEqual(historical["implementation_dependencies"],
            [{"path": k, "sha256": v} for k, v in M.HISTORICAL_A12_PINS.items() if k != M.A_MODULE])
        with self.assertRaisesRegex(M.StageAError, "population differs"):
            M._implementation_population(historical)
        # Exactly the reviewed three current source references, never all A12 pins.
        self.assertEqual({name for name in M.A_PINS if M.A_PINS[name] != M.HISTORICAL_A12_PINS[name]},
            {"hero_engine/phase6_av_static_uses_v3_replay.py", "tests/test_phase6_av_static_uses_v3_replay.py",
             "hero_engine/phase6_av_static_asset_uses_v4.py"})
        self.assertEqual(len(M.A_PINS), 41)
        for name, digest in {**dict(M.A_PINS), **dict(M.CONTEXT_PINS)}.items():
            with self.subTest(path=name):
                self.assertEqual(M._sha((Path(name) if name == M.TEXTWRAP else ROOT / name).read_bytes()), digest)

    def test_real_schema_rejects_subset_only_document(self):
        with self.assertRaisesRegex(M.StageAError, "schema rejected"):
            M._schema(M._Files(), {"render_spans": []}, M.A_SCHEMA)

    def test_content_addressed_identity_cannot_be_replaced_by_raw_hash(self):
        value = {"x": "DECLARED_FIXTURE"}
        value["timeline_id"] = "phase6-av-timeline-" + "0" * 24
        with self.assertRaisesRegex(M.StageAError, "content-addressed"):
            M._identity(value, "timeline_id", "phase6-av-timeline-", {"path": value["timeline_id"] + ".json"})

    def test_duplicate_json_keys_and_nonfinite_numbers_are_rejected(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'[]'):
            with self.subTest(raw=raw), self.assertRaises(M.StageAError): M._json(raw)

    def test_oversized_metadata_is_rejected_before_reading(self):
        files = Mock()
        with self.assertRaises(M.StageAError):
            M._binding_document(ROOT, files, {"path": REAL_TIMELINE, "sha256": REAL_TIMELINE_SHA,
                                             "size_bytes": M.METADATA_LIMIT + 1}, M.TIMELINES)
        files.read.assert_not_called()

    def test_verifier_wrapper_requires_complete_and_invokes_once(self):
        domain = SimpleNamespace(verify=Mock(return_value={"DECLARED_FIXTURE": True}))
        with patch.object(M, "_module", return_value=domain):
            result = M._verify_timeline(Path("fixture"), {"candidate": True}, {"source_bindings": {}})
        domain.verify.assert_called_once_with(Path("fixture"), {"candidate": True}, source_bindings={}, require_complete=True)
        self.assertEqual(result, {"DECLARED_FIXTURE": True})

    def test_private_closure_normalizes_genuine_bindings_and_owns_reader(self):
        root = Path("C:/DECLARED-FIXTURE-NOT-AN-OPERATIONAL-ROOT")
        reader = SimpleNamespace(read=Mock(), root=root)
        modules = {
            "hero_engine.phase6_av_static_sources": SimpleNamespace(_Reader=Mock(return_value=reader)),
            "hero_engine.phase6_av_static_asset_uses_v4": SimpleNamespace(_dependencies=Mock()),
            "hero_engine.phase6_av_static_uses_v3_replay": SimpleNamespace(recheck=Mock(), replay=Mock(side_effect=AssertionError("NO REPLAY"))),
            "hero_engine.phase6_av_body_sources_replay": SimpleNamespace(recheck=Mock(), replay=Mock(side_effect=AssertionError("NO REPLAY"))),
            "hero_engine.phase6_av_body_case_amendment": SimpleNamespace(_inventory=Mock()),
        }
        value = {"source_file_bindings": [{"path": "source.fixture", "sha256": "sha256:" + "a" * 64, "size_bytes": 7}],
                 "dependency_bindings": [{"path": "UNTRUSTED_IGNORED_LIST"}]}
        with patch.object(M, "_module", side_effect=lambda name: modules[name]), \
             patch.object(M, "_verify_timeline", side_effect=AssertionError("NO SECOND A")):
            recheck = M._dependency_closure(root, value)
            modules["hero_engine.phase6_av_static_asset_uses_v4"]._dependencies.assert_called_once_with(reader,
                [{"path": str(root / "source.fixture"), "sha256": "a" * 64, "size_bytes": 7}])
            modules["hero_engine.phase6_av_static_uses_v3_replay"].recheck.assert_not_called()
            self.assertEqual(reader.read.call_count, 40)  # A + deps, except separately pinned textwrap.
            recheck()
            modules["hero_engine.phase6_av_static_uses_v3_replay"].recheck.assert_called_once_with(reader)
            modules["hero_engine.phase6_av_body_sources_replay"].recheck.assert_called_once_with(reader)
            modules["hero_engine.phase6_av_body_case_amendment"]._inventory.assert_called_once_with(root)
            modules["hero_engine.phase6_av_static_uses_v3_replay"].replay.assert_not_called()
            modules["hero_engine.phase6_av_body_sources_replay"].replay.assert_not_called()

    def test_private_closure_rejects_duplicate_or_unpinned_dependency(self):
        reader = SimpleNamespace(read=Mock())
        primitives = SimpleNamespace(_Reader=Mock(return_value=reader))
        other = SimpleNamespace(_dependencies=Mock())
        item = {"path": "source.fixture", "sha256": "sha256:" + "a" * 64, "size_bytes": 7}
        for population in ([item, item], [{**item, "sha256": "SELF_ASSERTED"}]):
            with self.subTest(population=population), \
                 patch.object(M, "_module", side_effect=lambda name: primitives if name.endswith("static_sources") else other), \
                 self.assertRaises(M.StageAError):
                M._dependency_closure(Path("C:/DECLARED-FIXTURE"), {"source_file_bindings": population})
            other._dependencies.assert_not_called()
            reader.read.assert_not_called()

    def test_read_closure_detects_changes_and_rejects_hardlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "fixture.json"; path.write_bytes(b'{}')
            files = M._Files(); files.read(path, M._sha(b'{}'))
            path.write_bytes(b'{"changed":true}')
            with self.assertRaises(M.StageAError): files.recheck()
            info = path.stat()
            linked = SimpleNamespace(**{k: getattr(info, k) for k in ("st_mode", "st_size", "st_dev", "st_ino", "st_mtime_ns")}, st_nlink=2)
            with patch.object(M, "_resident", side_effect=lambda value: value), \
                 patch.object(Path, "stat", return_value=linked), self.assertRaisesRegex(M.StageAError, "linked"):
                M._Files().read(path)


if __name__ == "__main__":
    unittest.main()
