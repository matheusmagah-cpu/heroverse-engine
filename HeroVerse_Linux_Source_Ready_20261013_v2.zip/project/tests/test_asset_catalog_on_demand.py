"""Remote discovery must not turn mining into a local video library."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import asset_library_phase5 as library


class AssetCatalogOnDemandTests(unittest.TestCase):
    def _candidate(self, *, page_id: int) -> dict:
        return {
            "page_id": page_id, "title": "File:calm.webm",
            "download_url": "https://upload.wikimedia.org/calm.webm",
            "description_url": "https://commons.wikimedia.org/wiki/File:calm.webm",
            "creator": "Example creator", "rights_status": "CC_COMMERCIAL",
            "license_short": "CC BY 4.0", "license_version": "CC BY 4.0",
            "attribution_required": True, "restrictions": None,
            "duration_seconds": 12.0, "width": 1920, "height": 1080,
            "size_bytes": 1234, "commons_sha1": "abc",
        }

    def test_catalog_records_remote_candidate_without_download_or_media_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            package = Path(temporary)
            with patch.object(library, "search_commons_videos", return_value=[self._candidate(page_id=73)]), \
                 patch.object(library, "_download_commons_file", side_effect=AssertionError("download forbidden")), \
                 patch.object(library.time, "sleep"):
                result = library.build_asset_catalog(package, queries=[("calm", "calm water")])
            self.assertFalse(result["media_downloaded"])
            self.assertEqual("REMOTE_CATALOGED", result["candidates"][0]["residency"])
            self.assertFalse(result["candidates"][0]["production_eligible"])
            self.assertFalse((package / "assets").exists())
            evidence = Path(result["candidates"][0]["rights_evidence_uri"])
            self.assertTrue(evidence.is_file())
            self.assertEqual("CATALOGED_REMOTE_RIGHTS_ELIGIBLE", json.loads(evidence.read_text())["decision"])

    def test_catalogued_candidate_cannot_be_mistaken_for_local_render_asset(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            package = Path(temporary)
            with patch.object(library, "search_commons_videos", return_value=[self._candidate(page_id=74)]), \
                 patch.object(library.time, "sleep"):
                result = library.build_asset_catalog(package, queries=[("road", "road")])
            row = result["candidates"][0]
            self.assertNotIn("uri", row)
            self.assertNotIn("content_hash", row)
            self.assertEqual("TAKE_ALLOCATION_AND_LOCAL_ACQUISITION_REQUIRED", row["production_blocker"])


if __name__ == "__main__":
    unittest.main()
