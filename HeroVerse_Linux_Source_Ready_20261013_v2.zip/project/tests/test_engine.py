import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine.db import import_seed_data, rows
from hero_engine.forecast import deterministic_target, simulate
from hero_engine.db import load_config
from hero_engine.planner import analyze_hook, ngram_overlap, parse_transcript, pilot_short_edl, score_text
from hero_engine.youtube import video_id_from_url
from hero_engine.cli import _forecast_context
from hero_engine.decision import evaluate_snapshot
from hero_engine.modeling import build_master_model, evaluate_edl_against_model, evaluate_opening_line
from hero_engine.planner import modeled_long_edl
from hero_engine.shotlist import SHOT_BANK


class HeroEngineTests(unittest.TestCase):
    def test_video_id_parsing(self):
        self.assertEqual(video_id_from_url("https://www.youtube.com/watch?v=5-zdruoQKlM"), "5-zdruoQKlM")
        self.assertEqual(video_id_from_url("https://youtu.be/5-zdruoQKlM"), "5-zdruoQKlM")

    def test_seed_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "test.db"
            result = import_seed_data(db_path)
            self.assertGreaterEqual(result["channels"], 7)
            sources = rows("SELECT * FROM videos WHERE license_status='verified_cc'", path=db_path)
            self.assertGreaterEqual(len(sources), 9)

    def test_deterministic_math(self):
        config = load_config()
        base = next(item for item in config["forecast"]["scenarios"] if item["name"] == "base")
        target = deterministic_target(config, base, 21)
        self.assertEqual(target.subscriber_gap, 735)
        self.assertIsNone(target.watch_hour_gap)
        self.assertIsNone(target.required_long_views)
        self.assertIsNone(target.long_videos)
        self.assertIsNone(target.required_long_views_per_video)
        self.assertEqual(target.required_total_views_for_subscribers, 61250)

    def test_operational_config_does_not_impute_ypp_progress_or_cadence(self):
        config = load_config()
        self.assertIsNone(config["channel"]["current_valid_watch_hours"])
        self.assertEqual("UNAVAILABLE", config["channel"]["current_valid_watch_hours_status"])
        self.assertEqual("CONTROLLED_SEQUENTIAL_LOT", config["publishing"]["mode"])
        self.assertIsNone(config["publishing"]["long_videos_per_day"])
        self.assertIsNone(config["publishing"]["shorts_per_day"])
        self.assertEqual(30, config["channel"]["deadline_days"])
        self.assertEqual(config["channel"]["deadline_days"], config["channel"]["control_day"])
        self.assertEqual(3, config["publishing"]["controlled_lot_maximum"])
        base = next(item for item in config["forecast"]["scenarios"] if item["name"] == "base")
        result = simulate(config, base, 21, simulations=200, seed=74)
        self.assertEqual("withheld_missing_operational_inputs", result["probability_status"])
        self.assertIsNone(result["probability"]["reach_both"])

    def test_forecast_is_reproducible(self):
        config = load_config()
        base = next(item for item in config["forecast"]["scenarios"] if item["name"] == "base")
        first = simulate(config, base, 21, simulations=200, seed=74)
        second = simulate(config, base, 21, simulations=200, seed=74)
        self.assertEqual(first, second)

    def test_channel_samples_recalibrate_forecast_assumptions(self):
        samples = []
        for index in range(10):
            samples.append(
                {
                    "youtube_video_id": f"long-{index}", "format": "long",
                    "views": 1000 + index * 100, "subscribers_gained": 12,
                    "average_view_duration_seconds": 300, "age_hours": 168,
                }
            )
            samples.append(
                {
                    "youtube_video_id": f"short-{index}", "format": "short",
                    "views": 500 + index * 50, "subscribers_gained": 6,
                    "average_view_duration_seconds": None, "age_hours": 168,
                }
            )
        with patch("hero_engine.cli.rows", return_value=samples):
            calibrated_config, calibration = _forecast_context()
        base = next(
            item for item in calibrated_config["forecast"]["scenarios"]
            if item["name"] == "base"
        )
        self.assertEqual(calibration["status"], "calibrated")
        self.assertEqual(base["median_views_per_long"], 1450)
        self.assertEqual(base["median_views_per_short"], 725)
        self.assertEqual(base["average_view_duration_minutes"], 5.0)

    def test_short_scale_decision_is_metric_based(self):
        config = load_config()
        result = evaluate_snapshot(
            {
                "youtube_video_id": "short-winner", "format": "short", "age_hours": 24,
                "views": 2000, "subscribers_gained": 24, "viewed_rate": 0.64,
                "average_percentage_viewed": 0.91,
            },
            config,
        )
        self.assertEqual(result["decision"], "SCALE")

    def test_missing_metrics_never_produce_a_guess(self):
        config = load_config()
        result = evaluate_snapshot(
            {"youtube_video_id": "long-unknown", "format": "long", "age_hours": 24},
            config,
        )
        self.assertEqual(result["decision"], "INSUFFICIENT_DATA")

    def test_transcript_and_scoring(self):
        transcript = "[0:00] This attack is not random\n[0:05] Your identity is the foundation of your calling"
        lines = parse_transcript(transcript)
        self.assertEqual(len(lines), 2)
        hook, clarity, emotion, total = score_text(lines[1].text)
        self.assertGreater(total, 1)

    def test_pilot_source_share(self):
        edl = pilot_short_edl()
        source_seconds = sum(
            segment["end_seconds"] - segment["start_seconds"]
            for segment in edl["segments"]
            if segment["type"] == "source_clip"
        )
        self.assertLessEqual(source_seconds / edl["target_duration_seconds"], 0.30)

    def test_pilot_hook_is_fast_structured_and_original(self):
        edl = pilot_short_edl()
        first = edl["segments"][0]
        analysis = analyze_hook(first["text"])
        self.assertLessEqual(first["target_seconds"], 4.0)
        self.assertGreaterEqual(analysis["score"], 7.5)
        self.assertLessEqual(
            ngram_overlap(first["text"], edl["hook_blueprint"]["source_hook_text"]),
            edl["hook_blueprint"]["maximum_trigram_overlap"],
        )
        self.assertEqual(edl["segments"][-1]["type"], "voiceover")

    def test_pilot_metadata_is_release_shaped(self):
        edl = pilot_short_edl()
        metadata = edl["metadata"]
        self.assertIn(metadata["primary_title"], edl["title_variants"])
        self.assertEqual(metadata["description"].count("#"), 3)
        self.assertIn("?", metadata["pinned_comment"])

    def test_empirical_opening_gate_separates_clear_from_fragmented(self):
        winner = evaluate_opening_line(
            "The power of the Holy Spirit can change your life.",
            "REMEMBER YOUR POWER | Christian Motivation",
        )
        loser = evaluate_opening_line(
            "The thing is, if you just do stuff and nothing happens, what should all mean?",
            "BROKEN WITH PURPOSE | Christian Motivation",
        )
        self.assertTrue(winner["passed"])
        self.assertFalse(loser["passed"])
        self.assertGreaterEqual(winner["score"] - loser["score"], 4.0)

    def test_modeled_long_passes_master_preflight(self):
        import json
        import socket
        import sqlite3
        import subprocess
        from contextlib import ExitStack
        from hero_engine import db, modeling

        # Documentary inputs only. The real builder also persists three SQL
        # tables, so an isolated output directory alone would be insufficient.
        sources = {
            modeling.DEFAULT_ANALYSIS: modeling.DEFAULT_ANALYSIS.read_bytes(),
            db.DEFAULT_CONFIG: db.DEFAULT_CONFIG.read_bytes(),
        }
        with tempfile.TemporaryDirectory(prefix="hero-master-model-fixture-") as folder:
            root = Path(folder).resolve()
            analysis = root / "model-analysis.json"
            configuration = root / "engine.json"
            analysis.write_bytes(sources[modeling.DEFAULT_ANALYSIS])
            configuration.write_bytes(sources[db.DEFAULT_CONFIG])
            database = root / "data/hero_engine.db"
            output = root / "model-output"
            real_open, real_mkdir = Path.open, Path.mkdir
            real_connect = sqlite3.connect
            opened_databases = []

            def confined_open(path, *args, **kwargs):
                self.assertTrue(path.resolve().is_relative_to(root), str(path))
                return real_open(path, *args, **kwargs)

            def confined_mkdir(path, *args, **kwargs):
                self.assertTrue(path.resolve().is_relative_to(root), str(path))
                return real_mkdir(path, *args, **kwargs)

            def confined_connect(path, *args, **kwargs):
                self.assertEqual(database, Path(path).resolve())
                opened_databases.append(database)
                return real_connect(path, *args, **kwargs)

            with ExitStack() as scope:
                for module, name, value in (
                    (db, "ROOT", root),
                    (db, "DEFAULT_DB", database),
                    (db, "DEFAULT_CONFIG", configuration),
                    (modeling, "ROOT", root),
                    (modeling, "DEFAULT_ANALYSIS", analysis),
                    (modeling, "DEFAULT_MODEL_DIR", output),
                ):
                    scope.enter_context(patch.object(module, name, value))
                scope.enter_context(patch.object(Path, "open", confined_open))
                scope.enter_context(patch.object(Path, "mkdir", confined_mkdir))
                scope.enter_context(patch.object(sqlite3, "connect", confined_connect))
                scope.enter_context(patch.object(subprocess, "Popen", side_effect=AssertionError("process forbidden")))
                for name in ("connect", "connect_ex"):
                    scope.enter_context(patch.object(socket.socket, name, side_effect=AssertionError("network forbidden")))

                # Defaults captured by the function signature are overridden
                # explicitly; persistence itself is real, not a mocked PASS.
                result = build_master_model(analysis_path=analysis, output_dir=output)
                preflight = evaluate_edl_against_model(modeled_long_edl(), result["model"])
                self.assertTrue(preflight["passed"])
                self.assertEqual(preflight["measurements"]["planned_seconds"], 230.0)
                self.assertGreaterEqual(preflight["measurements"]["source_share"], 0.10)
                self.assertLessEqual(preflight["measurements"]["source_share"], 0.25)
                self.assertEqual(output / "master-model.json", Path(result["json_path"]))
                self.assertEqual(output / "master-model.md", Path(result["markdown_path"]))
                self.assertEqual(result["model"], json.loads(Path(result["json_path"]).read_text(encoding="utf-8")))
                self.assertGreater(Path(result["markdown_path"]).stat().st_size, 0)
                stored = db.rows("SELECT model_id, model_json FROM channel_models")
                self.assertEqual(1, len(stored))
                self.assertEqual(result["model"]["model_id"], stored[0]["model_id"])
                self.assertEqual(result["model"], json.loads(stored[0]["model_json"]))
                self.assertEqual(len(result["model"]["video_catalog"]), len(db.rows("SELECT * FROM model_videos")))
                self.assertEqual(len(result["model"]["scored_openings"]), len(db.rows("SELECT * FROM model_openings")))
                self.assertGreaterEqual(len(opened_databases), 5)
                self.assertEqual(sources[next(path for path in sources if path.name == "model-analysis.json")], analysis.read_bytes())
                self.assertEqual(sources[next(path for path in sources if path.name == "engine.json")], configuration.read_bytes())
        for source, before in sources.items():
            self.assertEqual(before, source.read_bytes())

    def test_modeled_long_has_complete_visual_concept_bank(self):
        edl = modeled_long_edl()
        roles = {
            segment["narrative_role"]
            for segment in edl["segments"]
            if segment["type"] == "voiceover"
        }
        self.assertEqual(roles, set(SHOT_BANK))
        authored_stock_shots = sum(len(SHOT_BANK[role]) for role in roles)
        source_shots = sum(segment["type"] == "source_clip" for segment in edl["segments"])
        self.assertEqual(authored_stock_shots + source_shots, 50)


if __name__ == "__main__":
    unittest.main()
