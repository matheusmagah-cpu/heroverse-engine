from __future__ import annotations

import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]


class GoogleAuthPlatformObservationTests(unittest.TestCase):
    def test_authenticated_observation_proves_specific_production_blockers(self) -> None:
        observation = json.loads((ROOT / "output/integrations/youtube/heroverse/google-auth-platform-observation.json").read_text(encoding="utf-8"))
        schema = json.loads((ROOT / "schemas/google_auth_platform_observation.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(schema).validate(observation)
        self.assertEqual("graphic-tide-490010-u9", observation["project_id"])
        self.assertEqual("HeroVerse Channel Operations", observation["branding"]["app_name"])
        self.assertEqual(1, observation["branding"]["authorized_domain_count"])
        self.assertEqual("EXTERNAL", observation["audience"]["user_type"])
        self.assertEqual("IN_PRODUCTION", observation["audience"]["publishing_status"])
        self.assertEqual(1, observation["audience"]["total_oauth_user_count"])
        self.assertFalse(observation["audience"]["publish_action_enabled"])
        self.assertTrue(observation["declared_scopes"]["configuration_matches_runtime"])
        self.assertEqual(4, len(observation["declared_scopes"]["runtime_requested_scopes"]))
        self.assertFalse(observation["continuous_operation_ready"])
        self.assertEqual("NOT_REQUIRED_EXEMPT", observation["verification"]["status"])
        self.assertEqual("PERSONAL_USE", observation["verification"]["exemption"])

        readiness = json.loads((ROOT / "output/integrations/youtube/heroverse/operational-readiness.json").read_text(encoding="utf-8"))
        self.assertTrue(readiness["continuous_operation_ready"])
        self.assertFalse(any("declares zero" in item for item in readiness["blockers"]))
        self.assertEqual([], readiness["blockers"])


if __name__ == "__main__":
    unittest.main()
