import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import phase5_integrity_maintenance as maintenance


class IntegrityMaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.package = self.root / maintenance.PACKAGE
        self.package.mkdir(parents=True)
        (self.package / "asset_manifest.json").write_text('{"changed":true}\n', encoding="utf-8")
        historical = {"algorithm":"SHA-256","entries":[{"artifact":"asset_manifest.json","sha256":"0" * 64,"bytes":1}],"item_count":1,"total_bytes":1}
        (self.package / maintenance.HISTORICAL_NAME).write_text(json.dumps(historical), encoding="utf-8")

    def test_stage_is_successor_only_and_binds_historical_preimage_and_current_resident_bytes(self):
        value = maintenance.stage_successor(self.root, stage=self.root / "stage")
        self.assertEqual("STAGED_NOT_COMMITTED", value["status"])
        self.assertEqual(["asset_manifest.json"], value["drifted_artifacts"])
        self.assertFalse(any(value["authority"].values()))
        self.assertTrue((self.root / "stage/integrity_manifest_successor.json").is_file())
        self.assertEqual(value, maintenance.verify_staged_successor(self.root, value))

    def test_tamper_or_resident_change_blocks_and_never_rewrites_historical_manifest(self):
        before = (self.package / maintenance.HISTORICAL_NAME).read_bytes()
        value = maintenance.stage_successor(self.root, stage=self.root / "stage")
        bad = copy.deepcopy(value); bad["authority"]["commit"] = True
        with self.assertRaises(maintenance.IntegrityMaintenanceError):
            maintenance.verify_staged_successor(self.root, bad)
        (self.package / "asset_manifest.json").write_text('{"changed":"again"}\n', encoding="utf-8")
        with self.assertRaises(maintenance.IntegrityMaintenanceError):
            maintenance.verify_staged_successor(self.root, value)
        self.assertEqual(before, (self.package / maintenance.HISTORICAL_NAME).read_bytes())

    def test_commit_requires_explicit_paused_authorization_and_rollback_owns_only_successor_view(self):
        before = (self.package / maintenance.HISTORICAL_NAME).read_bytes()
        stage = self.root / "stage"
        value = maintenance.stage_successor(self.root, stage=stage)
        with self.assertRaises(maintenance.IntegrityMaintenanceError):
            maintenance.commit_staged_successor(self.root, stage=stage, expected_successor_hash=value["successor_sha256"],
                proof_envelope=Path("missing.json"), expected_proof_hash="sha256:" + "2" * 64, expected_candidate_hash="1" * 64)
        proof = {"candidate":{"source_set_sha256":"1" * 64}, "pins":[], "authority":{"integrity_successor_commit":True}}
        with patch("hero_engine.maintenance_paused_application._check_host"), patch("hero_engine.phase5_integrity_successor_proof.read_integrity_successor_proof", return_value=proof) as reader:
            (self.root / "output/runtime/gestor-central").mkdir(parents=True)
            (self.root / "output/runtime/gestor-central/PAUSE").write_text("owner pause\n", encoding="utf-8")
            committed = maintenance.commit_staged_successor(self.root, stage=stage, expected_successor_hash=value["successor_sha256"],
                proof_envelope=Path("proof.json"), expected_proof_hash="sha256:" + "2" * 64, expected_candidate_hash="1" * 64)
        reader.assert_called_once()
        self.assertTrue((self.root / committed["target"]).is_file())
        self.assertEqual(before, (self.package / maintenance.HISTORICAL_NAME).read_bytes())
        maintenance.rollback_committed_successor(self.root, stage=stage, expected_successor_hash=value["successor_sha256"])
        self.assertFalse((self.root / committed["target"]).exists())
