"""Real-source integration: frozen hook + actual Stage A; no render or admission."""
from __future__ import annotations

import copy
import hashlib
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine.phase6_av_timeline import build
from hero_engine.phase6_av_render_recipe import (
    AVRenderRecipeError, _canonical_sha,
    compile_phase6_av_render_recipe, verify_phase6_av_render_recipe,
)
from hero_engine import phase6_av_render_recipe as render
from hero_engine import phase6_av_visual_recipe_adapter as adapter
from tests.test_phase6_av_visual_recipe_adapter import (
    HISTORICAL_PRODUCTION, _LEGACY_ARCHIVED_NAMES, _legacy_expected_path, historical_bindings,
)

ROOT = Path(__file__).resolve().parents[1]
ARGUMENTS = "output/operations/phase6/av-admission/arguments/phase6-av-arguments-e8e6abb5af903eca90021d3f.json"
MASTER = "output/qa/phase6/diagnostics/editorial-narration-master-v1-14c3d700a155554bc006af41/refinement-v1/receipt.json"


def pin(relative):
    raw = (ROOT / relative).read_bytes()
    return {"path": relative, "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


class RealVisualIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.args_pin, cls.master_pin = pin(ARGUMENTS), pin(MASTER)
        cls.adapter_patch = patch.object(adapter, "_expected_path", side_effect=_legacy_expected_path)
        original_rooted = render._rooted

        def historical_rooted(root, value, *, must_exist=True):
            archived = _LEGACY_ARCHIVED_NAMES.get(value)
            if archived:
                return (HISTORICAL_PRODUCTION / archived).resolve(strict=True)
            return original_rooted(root, value, must_exist=must_exist)

        cls.rooted_patch = patch.object(render, "_rooted", side_effect=historical_rooted)
        cls.adapter_patch.start(); cls.rooted_patch.start()
        cls.visual_bindings = historical_bindings()
        args = json.loads((ROOT / ARGUMENTS).read_bytes())["arguments"]
        # Prohibit media effects through either subprocess entry point.
        with patch("subprocess.run", side_effect=AssertionError("unexpected subprocess")), \
                patch("subprocess.Popen", side_effect=AssertionError("unexpected subprocess")):
            cls.timeline = build(ROOT, **args)
            cls.recipe = compile_phase6_av_render_recipe(
                ROOT, cls.timeline, master_receipt_binding=cls.master_pin,
                render_blueprint_binding=None, timeline_arguments_binding=cls.args_pin,
                editorial_visual_bindings=cls.visual_bindings)

    @classmethod
    def tearDownClass(cls):
        cls.rooted_patch.stop(); cls.adapter_patch.stop()

    def test_real_visual_fragment_flows_through_recomposed_stage_a_without_full_graph(self):
        result = self.recipe
        visual = result["inputs"]["visual_preparation"]
        self.assertEqual("RECOMPOSED_INCOMPLETE", result["timeline"]["independent_arguments"]["status"])
        self.assertEqual((90, 240, 150), (visual["global_start_frame"], visual["global_end_frame_exclusive"], visual["covered_frame_count"]))
        self.assertEqual(22, len(visual["dependency_bindings"]))
        self.assertEqual(2, len(visual["generated_files"]))
        self.assertIn("textfile='meta/visual/take-003/mechanism.txt'", visual["filtergraph"])
        self.assertIn("VISUAL_RECIPE_COVERAGE_INCOMPLETE", result["blockers"])
        self.assertIn("MASTER_AUDIO_SAMPLE_COUNT_DIFFERS_FROM_TIMELINE", result["blockers"])
        self.assertFalse(visual["full_timeline_covered"])
        self.assertFalse(any(visual["authority"].values()))
        self.assertFalse(any(result["authority"].values()))
        self.assertEqual("BLOCKED_INCOMPLETE", result["status"])
        self.assertIsNone(result["command_graph"])
        for generated in visual["generated_files"]:
            self.assertFalse((ROOT / generated["relative_path"]).exists())
        report = {"scope": "REAL_A_TO_C_TO_EDITORIAL_FRAGMENT_NOT_FULL_RENDER", "recipe_id": result["recipe_id"],
                  "recipe_canonical_sha256": _canonical_sha(result), "arguments": self.args_pin,
                  "master": self.master_pin, "visual_preparation": visual,
                  "implementation_bindings": result["implementation_bindings"], "blockers": result["blockers"],
                  "status": result["status"], "authority": result["authority"], "technical_cost_brl": 0}
        print("REAL_AV_VISUAL_INTEGRATION_EVIDENCE=" + json.dumps(report, sort_keys=True, ensure_ascii=False))

    def test_visual_preparation_cannot_run_before_independent_a_recomposition(self):
        with patch("hero_engine.phase6_av_visual_recipe_adapter.compile_take003_editorial_visual_spec") as visual:
            with self.assertRaisesRegex(AVRenderRecipeError, "independent Stage-A recomposition first"):
                compile_phase6_av_render_recipe(
                    ROOT, self.timeline, master_receipt_binding=self.master_pin,
                    render_blueprint_binding=None, editorial_visual_bindings=self.visual_bindings)
            visual.assert_not_called()

    def test_replay_reopens_visual_inputs_and_rejects_changed_filter(self):
        candidate = copy.deepcopy(self.recipe)
        kwargs = {"master_receipt_binding": self.master_pin, "render_blueprint_binding": None,
                  "timeline_arguments_binding": self.args_pin, "editorial_visual_bindings": self.visual_bindings}
        self.assertEqual(candidate, verify_phase6_av_render_recipe(ROOT, candidate, self.timeline, **kwargs))
        candidate["inputs"]["visual_preparation"]["filtergraph"] += ",null"
        with self.assertRaisesRegex(AVRenderRecipeError, "independent recompilation"):
            verify_phase6_av_render_recipe(ROOT, candidate, self.timeline, **kwargs)
        numeric_tamper = copy.deepcopy(self.recipe)
        numeric_tamper["inputs"]["visual_preparation"]["covered_frame_count"] = 150.0
        with self.assertRaisesRegex(AVRenderRecipeError, "independent recompilation"):
            verify_phase6_av_render_recipe(ROOT, numeric_tamper, self.timeline, **kwargs)


if __name__ == "__main__":
    unittest.main()
