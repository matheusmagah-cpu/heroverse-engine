import unittest
from unittest.mock import patch

from hero_engine import current_operational_application_proof as proof


class CurrentOperationalApplicationProofTests(unittest.TestCase):
    def test_compact_command_resolves_the_same_real_population_without_running_it(self):
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(type(self))
        names = [test.id() for test in suite]
        inventory = {"files": [{"test_ids": names}]}
        command = proof.test_command(inventory, executable="python.exe")
        self.assertEqual([__name__], command[8:])
        self.assertLess(len(" ".join(command)), 32767)

    def test_compact_command_rejects_population_drift_and_unknown_methods(self):
        for names in ([self.id()], ["tests.missing_case.X.test_missing"]):
            with self.subTest(names=names), self.assertRaises(proof.CurrentOperationalProofError):
                proof.test_command({"files": [{"test_ids": names}]}, executable="python.exe")

    def test_partial_module_retains_exact_ids_and_excess_command_fails_before_launch(self):
        with patch.object(proof, "TEST_PREFIXES", ()):
            inventory = {"files": [{"test_ids": [self.id()]}]}
            self.assertEqual(self.id(), proof.test_command(inventory, executable="python.exe")[-1])
            with self.assertRaisesRegex(proof.CurrentOperationalProofError, "CreateProcess"):
                proof.test_command(inventory, executable="x" * 32767)

    def test_contract_is_distinct_from_legacy_and_binds_current_consumers(self):
        self.assertEqual("EXACT_CURRENT_OPERATIONAL_PROOF_FOR_CONTROLLED_APPLICATION", proof.PURPOSE)
        self.assertIn("operational-bindings.json", proof.FILES)
        self.assertNotIn("A9", proof.PURPOSE)
        for method in (
            "test_read_only_reference_and_comment_are_not_invocations",
            "test_operational_dynamic_and_uncertain_commands_remain_blocked",
        ):
            self.assertIn("tests.test_paused_maintenance_application.HostObserverClassificationTests." + method,
                          proof.EXACT_TEST_IDS)
        from pathlib import Path
        audio_modules = {path.stem for path in Path(__file__).parent.glob('test_audio_static_*.py')}
        self.assertTrue(audio_modules)
        self.assertTrue(all(f'tests.{name}.' in proof.TEST_PREFIXES for name in audio_modules))
        for module in ("test_procedural_typography_successor", "test_phase6_visual_typography",
                       "test_phase6_production", "test_phase6_asset_residency"):
            self.assertIn(f"tests.{module}.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_caption_intent_v3.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_visual_preflight.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_media_remediation_wait.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_historical_preproduction.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_media_authority.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_queue_post_effect.", proof.TEST_PREFIXES)
        self.assertIn("tests.test_phase6_forward_post_effect_eligibility.", proof.TEST_PREFIXES)
        self.assertIn(
            "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_valid_composed_preparation_commit_and_idempotent_repeat",
            proof.EXACT_TEST_IDS,
        )
        self.assertIn(
            "tests.test_phase6_queue.Phase6QueueTests.test_read_only_snapshot_never_initializes_or_creates_wal_sidecars",
            proof.EXACT_TEST_IDS,
        )
        for method in (
            "test_committed_forward_replay_preserves_complete_database_sets",
            "test_committed_forward_replay_rejects_outcome_mismatch_and_rolls_back",
            "test_committed_forward_replay_lost_protection_blocks_finalization",
        ):
            self.assertIn("tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests." + method,
                          proof.EXACT_TEST_IDS)

    def test_inventory_selects_producer_and_consumers_without_aliases(self):
        full = {"schema_version": "1.1.0", "files": [
            {"path": "tests/test_phase5_current_operational_application_proof.py", "content_hash": "sha256:" + "a" * 64,
             "test_ids": ["tests.test_phase5_current_operational_application_proof.CurrentOperationalApplicationProofTests.test_contract"]},
            {"path": "tests/test_other.py", "content_hash": "sha256:" + "b" * 64,
             "test_ids": ["tests.test_other.OtherTests.test_ignored"]},
            {"path": "tests/test_paused_maintenance_application.py", "content_hash": "sha256:" + "c" * 64,
             "test_ids": [
                 "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_valid_composed_preparation_commit_and_idempotent_repeat",
                 "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_unselected",
             ]},
        ]}
        selected = proof.build_test_inventory(full)
        self.assertEqual(2, selected["test_count"])
        self.assertEqual(0, selected["alias_count"])
        self.assertEqual("tests/test_phase5_current_operational_application_proof.py", selected["files"][0]["path"])
        self.assertEqual(["tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_valid_composed_preparation_commit_and_idempotent_repeat"],
                         selected["files"][1]["test_ids"])

    def test_current_instrumental_producers_and_final_consumers_cannot_be_omitted(self):
        modules=('test_christian_rest_music_recipe','test_rest_music_native_inputs',
            'test_rest_music_render','test_music_spectral_observation',
            'test_music_aesthetic_assessment','test_rest_music_final_qualification',
            'test_rest_static_capacity','test_rest_packaging_successor')
        rows=[{'path':f'tests/{name}.py','content_hash':'sha256:'+'1'*64,
               'test_ids':[f'tests.{name}.Fixture.test_bound_consumer']} for name in modules]
        selected=proof.build_test_inventory({'schema_version':'1.1.0','files':rows})
        self.assertEqual(selected['file_count'],len(modules))
        self.assertEqual(selected['method_count'],len(modules))
        self.assertEqual(selected['alias_count'],0)
        self.assertEqual([row['path'] for row in selected['files']],[row['path'] for row in rows])

    def test_empty_inventory_fails_closed(self):
        with self.assertRaises(proof.CurrentOperationalProofError):
            proof.build_test_inventory({"schema_version": "1.1.0", "files": []})

    def test_goal_observer_terminal_consumer_is_in_authenticated_population(self):
        names = [
            "tests.test_phase6_channel_goal_observer.Phase6ChannelGoalObserverTests.test_expired_window_preserves_actual_attempt_and_replays_without_api",
            "tests.test_phase6_channel_goal_observer.Phase6ChannelGoalObserverTests.test_legacy_exhausted_checkpoint_replays_without_fabricated_attempts",
        ]
        selected = proof.build_test_inventory({"schema_version": "1.1.0", "files": [
            {"path": "tests/test_phase6_channel_goal_observer.py", "content_hash": "sha256:" + "a" * 64,
             "test_ids": names},
        ]})
        self.assertEqual(names, selected["files"][0]["test_ids"])
        self.assertEqual(2, selected["method_count"])
        self.assertEqual(0, selected["alias_count"])

    def test_current_typography_chain_cannot_be_omitted_from_inventory(self):
        modules = ("test_procedural_typography_successor", "test_phase6_visual_typography",
                   "test_phase6_production", "test_phase6_asset_residency")
        rows = [{"path": f"tests/{module}.py", "content_hash": "sha256:" + "d" * 64,
                 "test_ids": [f"tests.{module}.CurrentTests.test_contract"]} for module in modules]
        selected = proof.build_test_inventory({"schema_version": "1.1.0", "files": rows})
        self.assertEqual(rows, selected["files"])
        self.assertEqual(4, selected["method_count"])
        self.assertEqual(4, selected["test_count"])
        self.assertEqual(0, selected["alias_count"])

    def test_public_receipt_never_carries_internal_outcomes(self):
        receipt = proof.public_verifier_receipt({"status": "PASS", "outcomes": {"test": "ok"}})
        self.assertEqual({"status": "PASS"}, receipt)
        with self.assertRaises(proof.CurrentOperationalProofError):
            proof.public_verifier_receipt({"status": "PASS"})
