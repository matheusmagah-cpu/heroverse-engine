"""Anchored reader in isolated roots; codec/process observations are simulated."""
import copy
import hashlib
import json
import shutil
import unittest
from pathlib import Path
from tests import test_audio_static_qa as fixture
from tests import test_audio_static_rights as renderer_fixture
from hero_engine.maintenance_paused_application import candidate_identity
from hero_engine.phase6_render_contract import PALETTE_QP1_SEGMENT_RENDERER, segment_encoder_arguments
from hero_engine.phase6_visual_metrics import calibrate_error_limit
from hero_engine.procedural_infographics_phase5 import compile_audio_static_composition, _audio_static_pixels
from hero_engine.standard_qualification_phase5 import read_audio_static_codec_controls, verify_audio_static_execution

ROOT=Path(__file__).resolve().parents[1]
FILTERS='scale=1920:1080:force_original_aspect_ratio=decrease:out_color_matrix=bt709:out_range=tv,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p,setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709'
def sha(path):return fixture.voice_fixture.sha(path)
def write(path,value):fixture.write(path,value)
def read(path):return fixture.read(path)
def file_binding(path):return {'path':str(path),'size_bytes':path.stat().st_size,'sha256':sha(path)}


class AudioStaticControlReaderTests(unittest.TestCase):
    def setUp(self):
        self.helper=fixture.AudioStaticQaTests('test_final_technical_static_hold_not_wrongly_rejected_as_freeze')
        self.addCleanup(self.helper.doCleanups)
        self.helper.setUp()
        self.root,self.package=self.helper.root,self.helper.package
        self.record=self.root/'output/runtime/gestor-central/maintenance-runs/controls'
        self.record.mkdir(parents=True)
        for name in ('phase6_visual_metrics','phase5_autonomous_quality','procedural_infographics_phase5','phase6_render_contract'):
            target=self.root/f'hero_engine/{name}.py'
            target.parent.mkdir(exist_ok=True)
            shutil.copy2(ROOT/f'hero_engine/{name}.py',target)
        asset=read(self.package/'asset_manifest.json')['assets'][0]
        rights=read(Path(asset['rights_evidence_uri']))
        self.layout=read(Path(rights['composition_manifest']['path']))['layout']
        self.rows=[]
        groups=['positive']*3+['negative']*2+['holdout_positive']+['holdout_negative']*2
        values=[.001,.0015,.001,.5,.8,.0009,.6,.9]
        for index,group in enumerate(groups):
            directory=self.record/f'control-{index}'
            directory.mkdir()
            layout=compile_audio_static_composition(title=f'Independent Control Title Number {index}',
                bible=self.layout['style_bible'],format_pack=self.layout['format_pack'],font=Path(self.layout['font']['path']))
            image,_=_audio_static_pixels(layout)
            image.save(directory/'reference.png')
            image.save(directory/'input.png')
            (directory/'control.mp4').write_bytes(f'SIMULATED_CODEC_BOUNDARY_{index}'.encode())
            argv=['ffmpeg-test.exe','-i',str(directory/'input.png'),'-vf',FILTERS,
                  *segment_encoder_arguments(PALETTE_QP1_SEGMENT_RENDERER),str(directory/'control.mp4')]
            write(directory/'command.json',{'argv':argv,'layout':layout,'reference_sha256':sha(directory/'reference.png').removeprefix('sha256:')})
            write(directory/'process-result.json',{'exit_code':0})
            row={'group':group,'control_directory':str(directory),'observed_frames':30,
                 'source_sha256':sha(directory/'control.mp4').removeprefix('sha256:'),
                 'reference_sha256':sha(directory/'reference.png').removeprefix('sha256:'),
                 'measurements':{'text_error':values[index],'colour_error':values[index]*100}}
            write(directory/'measurement.json',row)
            self.rows.append(row)
        calibration={}
        for metric in ('text_error','colour_error'):
            grouped={group:[{'source_sha256':row['source_sha256'],'value':row['measurements'][metric]}
                            for row in self.rows if row['group']==group]
                     for group in ('positive','negative','holdout_positive','holdout_negative')}
            calibration[metric]=calibrate_error_limit(candidate_hash=asset['content_hash'].removeprefix('sha256:'),**grouped)
        write(self.record/'control-result.json',{'status':'CONTROL_SEPARATION_PASSED','selected_controls':self.rows,'calibration':calibration})
        self.seal()

    def seal(self):
        path=self.record/'control-bindings.json'
        artifacts=[file_binding(item) for item in self.record.rglob('*') if item.is_file() and item!=path]
        write(path,{'status':'COMPLETED_CODEC_CONTROLS_AUTHENTICATED_NOT_RELEASE','candidate':candidate_identity(self.root),
                    'authority':{'application':False,'render_production':False,'publication':False},'artifacts':artifacts})
        self.binding={'path':str(path),'sha256':sha(path)}

    def consume(self):return read_audio_static_codec_controls(self.root,self.package,binding=self.binding)

    def test_valid_anchored_reader_returns_limits_not_authority(self):
        result=self.consume()
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])

    def test_artifact_or_anchor_tamper_rejected(self):
        (self.record/'control-0/control.mp4').write_bytes(b'tampered')
        with self.assertRaises(PermissionError):self.consume()

    def test_incomplete_population_rejected_even_with_new_fixture_anchor(self):
        path=self.record/'control-result.json'
        value=read(path);value['selected_controls'].pop();write(path,value);self.seal()
        with self.assertRaises(PermissionError):self.consume()

    def test_forged_numeric_limit_rejected_even_with_new_fixture_anchor(self):
        path=self.record/'control-result.json'
        value=read(path);value['calibration']['text_error']['maximum_error']=1;write(path,value);self.seal()
        with self.assertRaises(PermissionError):self.consume()

    def test_control_font_domain_mismatch_rejected(self):
        path=self.record/'control-0/command.json'
        value=read(path);value['layout']['texts'][0]['font_size']=54;write(path,value);self.seal()
        with self.assertRaises(PermissionError):self.consume()

    def test_unknown_or_changed_encoder_rejected(self):
        path=self.record/'control-0/command.json'
        value=read(path);value['argv'][value['argv'].index('-qp')+1]='20';write(path,value);self.seal()
        with self.assertRaises(PermissionError):self.consume()

    def test_changed_measurement_implementation_rejected(self):
        (self.root/'hero_engine/phase6_visual_metrics.py').write_bytes(b'changed implementation')
        with self.assertRaises(PermissionError):self.consume()

    def historical_timing_binding(self, historical_hash):
        path=self.record/'control-bindings.json'
        bundle=read(path)
        for item in bundle['candidate']['files']:
            if item['path']=='hero_engine/phase5_autonomous_quality.py':
                item['sha256']=historical_hash
        write(path,bundle)
        self.binding={'path':str(path),'sha256':sha(path)}

    def test_exact_timing_successor_preserves_controls_and_reports_current_bytes(self):
        self.historical_timing_binding('c3e1197cbd2187c85be6e649b2a4e4c73a03ab272b843a057174e2b30ed6f4b0')
        before=(self.record/'control-bindings.json').read_bytes()
        result=self.consume()
        observed={row['path']:row['sha256'] for row in result['authenticated_inputs']}
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        self.assertEqual(observed[str(target)],sha(target))
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)

    def test_unknown_historical_hash_cannot_borrow_timing_successor(self):
        self.historical_timing_binding('0'*64)
        with self.assertRaises(PermissionError):self.consume()

    def test_exact_music_observation_extension_preserves_historical_controls(self):
        self.historical_timing_binding('ca54c3c277b8046afc784fcfdd3203b2d32220982cd7af834c8afa4a19062578')
        before=(self.record/'control-bindings.json').read_bytes()
        result=self.consume()
        self.assertEqual(result['status'],'AUTHENTICATED_STATIC_CODEC_LIMITS')
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)

    def test_music_observation_extension_rejects_unreviewed_current_bytes(self):
        self.historical_timing_binding('ca54c3c277b8046afc784fcfdd3203b2d32220982cd7af834c8afa4a19062578')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed music change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_editorial_successor_preserves_music_aesthetic_controls(self):
        self.historical_timing_binding('4b9a9c8fd5b65adceb723b4d4ee4a3cc98aee64ea6c9cc563cd1256273b0bf79')
        before=(self.record/'control-bindings.json').read_bytes()
        result=self.consume()
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        observed={row['path']:row['sha256'] for row in result['authenticated_inputs']}
        self.assertEqual(observed[str(target)],sha(target))
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)

    def test_editorial_successor_rejects_changed_current_bytes_from_aesthetic_history(self):
        self.historical_timing_binding('4b9a9c8fd5b65adceb723b4d4ee4a3cc98aee64ea6c9cc563cd1256273b0bf79')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed editorial change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_long_decode_successor_preserves_exact_history_and_limits(self):
        self.historical_timing_binding('684d06bb4af06418b873c58b4221ed9d4cf37991bb3a0d8837850b608e6e417e')
        before=(self.record/'control-bindings.json').read_bytes()
        result=self.consume()
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        observed={row['path']:row['sha256'] for row in result['authenticated_inputs']}
        self.assertEqual(observed[str(target)],sha(target))
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)

    def test_unreviewed_bytes_cannot_borrow_long_decode_successor(self):
        self.historical_timing_binding('684d06bb4af06418b873c58b4221ed9d4cf37991bb3a0d8837850b608e6e417e')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed decode change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_caption_boundary_successor_preserves_static_control_history(self):
        self.historical_timing_binding('ae17d7a18b93f9ae150e87ae4b59a358190ef3f110fe439b6127eb0a1665ca21')
        before=(self.record/'control-bindings.json').read_bytes()
        result=self.consume()
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)

    def test_caption_boundary_successor_rejects_unreviewed_current_bytes(self):
        self.historical_timing_binding('ae17d7a18b93f9ae150e87ae4b59a358190ef3f110fe439b6127eb0a1665ca21')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed caption change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_exact_musical_tail_successor_preserves_static_history_not_music_authority(self):
        self.historical_timing_binding('15a8cca7e501e21b76f72096128e37df4ed53e8a0eef1f9184569f774c2e4176')
        before=(self.record/'control-bindings.json').read_bytes()
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        self.assertEqual(sha(target),'sha256:ec10ea9a0acdb28f148928c864b4819d2abb2ca47cb75871cd3acc6ce6be265e')
        result=self.consume()
        self.assertEqual(result['status'],'AUTHENTICATED_STATIC_CODEC_LIMITS')
        self.assertEqual(result['limits']['text_error'],.0015)
        self.assertFalse(result['quality_authorized'])
        self.assertFalse(result['publication_authorized'])
        self.assertEqual((self.record/'control-bindings.json').read_bytes(),before)
        self.assertIn({'path':str(target),'sha256':sha(target)},result['authenticated_inputs'])

    def test_musical_tail_successor_rejects_other_current_bytes(self):
        self.historical_timing_binding('15a8cca7e501e21b76f72096128e37df4ed53e8a0eef1f9184569f774c2e4176')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed tail change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_changed_current_bytes_cannot_borrow_timing_successor(self):
        self.historical_timing_binding('c3e1197cbd2187c85be6e649b2a4e4c73a03ab272b843a057174e2b30ed6f4b0')
        target=self.root/'hero_engine/phase5_autonomous_quality.py'
        target.write_bytes(target.read_bytes()+b'\n# unreviewed change\n')
        with self.assertRaises(PermissionError):self.consume()

    def test_public_qa_controls_without_execution_cannot_approve_visual_gates(self):
        self.helper.codec_control_binding=self.binding
        self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        report,measured=self.helper.last_result
        gates={row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['LEGIBILITY'],'NEEDS_REVIEW')
        self.assertIsNotNone(measured['static_codec_controls'])
        self.assertFalse(report['publication_eligible'])

    def execution_fixture(self, media):
        # Simulated process frontier. Actual bytes/bindings and reader are real.
        exe=self.root/'bin/isolated-codec.exe';exe.parent.mkdir();exe.write_bytes(b'SIMULATED_EXECUTABLE')
        source=Path(read(self.package/'asset_manifest.json')['assets'][0]['uri'])
        def execution(argv,inputs,output):
            return {'version':'phase6-observed-ffmpeg-execution-v1','status':'COMPLETED','exit_code':0,
                    'quality_approval':False,'argv':argv,'executable':file_binding(exe),
                    'inputs':[file_binding(path) for path in inputs],'output':file_binding(output)}
        observations=[];segments=[]
        for take in self.helper.plan['takes']:
            segment=self.package/'render_work/video_segments'/ (take['take_id']+'.mp4')
            segment.parent.mkdir(parents=True,exist_ok=True);segment.write_bytes(b'SIMULATED_SEGMENT')
            segments.append(segment)
            first=[str(exe),'-loop','1','-i',str(source),'-vf',FILTERS,'-frames:v',
                   str(round((take['end_ms']-take['start_ms'])*30/1000)),
                   *segment_encoder_arguments(PALETTE_QP1_SEGMENT_RENDERER),str(segment)]
            observations.append({'execution':execution(first,[source],segment)})
        final=[str(exe),'-i',str(segments[0]),'-c:v','copy',str(media)]
        observations.append({'execution':execution(final,segments,media)})
        path=self.package/'resource-observation.json'
        write(path,{'quality_approval':False,'observations':observations})
        return {'path':str(path),'sha256':sha(path)}

    def test_public_qa_current_controls_and_execution_allow_measured_visual_gates(self):
        self.helper.codec_control_binding=self.binding
        self.helper.execution_builder=self.execution_fixture
        self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        report,measured=self.helper.last_result
        gates={row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['LEGIBILITY'],'PASS')
        self.assertEqual(gates['STYLE'],'PASS')
        self.assertFalse(report['publication_eligible'])

    def test_public_qa_damaged_text_cannot_borrow_control_pass(self):
        self.helper.codec_control_binding=self.binding
        self.helper.execution_builder=self.execution_fixture
        def damage(image):
            image[390:630,180:1740]=image[0,0]
            return image
        self.helper.decoded_transform=damage
        self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        report,_=self.helper.last_result
        gates={row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['LEGIBILITY'],'FAIL')
        self.assertEqual(gates['STYLE'],'FAIL')
        self.assertFalse(report['publication_eligible'])

    def test_control_changed_after_initial_read_blocks_final_qa_publication(self):
        self.helper.codec_control_binding=self.binding
        self.helper.execution_builder=self.execution_fixture
        def mutate(image):
            (self.record/'control-0/control.mp4').write_bytes(b'changed after control authentication')
            return image
        self.helper.decoded_transform=mutate
        with self.assertRaises(PermissionError):
            self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        self.assertFalse((self.package/'qa/creative_quality_gate_report.json').exists())

    def test_native_producer_records_observed_codec_and_reader_rejects_tamper(self):
        source=renderer_fixture.AudioStaticRightsTests('test_public_renderer_consumes_automatic_provenance_and_reopens_it')
        self.addCleanup(source.doCleanups);source.setUp()
        owner=source.native_renderer_fixture()
        result=owner.render()
        path=owner.package/'resource-observation.json'
        binding={'path':str(path),'sha256':sha(path)}
        observed=verify_audio_static_execution(owner.root,owner.package,Path(result['output']['path']),binding=binding)
        self.assertEqual(observed['observed_segments'],len(owner.plan['takes']))
        self.assertFalse(observed['quality_authorized'])
        value=read(path)
        next(row['execution'] for row in value['observations'] if 'execution' in row)['argv'][0]='foreign.exe'
        write(path,value)
        with self.assertRaises(PermissionError):
            verify_audio_static_execution(owner.root,owner.package,Path(result['output']['path']),binding=binding)
