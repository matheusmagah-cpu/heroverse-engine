from __future__ import annotations

import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.publication_package_phase5 import build_publication_package


ROOT = Path(__file__).resolve().parents[1]


def read_json(path: str) -> dict:
    return json.loads((ROOT / path).read_text(encoding="utf-8-sig"))


def validate(schema_path: str, instance: dict) -> None:
    validator = Draft202012Validator(read_json(schema_path), format_checker=FormatChecker())
    errors = list(validator.iter_errors(instance))
    if errors:
        raise AssertionError("; ".join(error.message for error in errors))


class ChannelReadinessPhase5Tests(unittest.TestCase):
    def test_authenticated_observation_and_audit_validate(self) -> None:
        observation = read_json("output/audits/channel/heroverse/studio-observation.json")
        audit = read_json("output/audits/channel/heroverse/channel-readiness-audit.json")
        validate("schemas/channel_studio_observation.schema.json", observation)
        validate("schemas/channel_readiness_audit.schema.json", audit)
        self.assertTrue(observation["home_tab"]["enabled"])
        self.assertEqual("PASS", audit["overall_status"])
        self.assertTrue(audit["publication_gate"]["auto_publish_permitted"])
        self.assertEqual("BLOCKED", audit["ypp_application_gate"]["status"])
        self.assertEqual("NONE", audit["ypp_application_gate"]["eligible_tier"])

    def test_live_profile_corrections_are_api_verified_and_honest(self) -> None:
        snapshot = read_json("output/audits/channel/heroverse/channel-snapshot.json")
        receipt = read_json("output/audits/channel/heroverse/live-change-receipt.json")
        validate("schemas/channel_live_change_receipt.schema.json", receipt)
        description = snapshot["profile"]["description"].lower()
        keywords = snapshot["profile"]["keywords"].lower()
        self.assertIn("practical faith", description)
        self.assertNotIn("every day", description)
        self.assertNotIn("daily inspiration", description)
        self.assertIn("christian motivation", keywords)
        self.assertNotIn("marvel", keywords)
        self.assertTrue(any(item["change_id"] == "english-localization-conflict-v1" for item in receipt["changes"]))
        self.assertEqual("NO_VIDEO_UPLOAD_OR_PUBLICATION", receipt["publication_impact"])

    def test_target_math_is_calculated_not_presented_as_forecast(self) -> None:
        audit = read_json("output/audits/channel/heroverse/channel-readiness-audit.json")
        math = audit["measurements"]["thirty_day_target_math"]
        self.assertEqual(24.5, math["required_net_subscribers_per_day"])
        self.assertEqual(44.1, math["subscriber_acceleration_multiple_required_ads"])
        self.assertEqual(333293.3333, math["required_qualified_shorts_views_per_day_ads"])
        self.assertEqual(24997.0, math["shorts_acceleration_multiple_required_ads"])
        self.assertFalse(math["guarantee"])
        self.assertEqual("UNAVAILABLE_INSUFFICIENT_ACTIVE_BASELINE", math["forecast_status"])

    def test_legacy_catalog_is_complete_but_not_autoapproved(self) -> None:
        audit = read_json("output/audits/channel/heroverse/legacy-catalog-audit.json")
        validate("schemas/legacy_catalog_audit.schema.json", audit)
        self.assertEqual(21, audit["summary"]["public_videos"])
        self.assertEqual(0, audit["summary"]["videos_approved"])
        self.assertEqual(21, audit["summary"]["videos_blocked_pending_review"])
        self.assertGreaterEqual(audit["summary"]["duplicate_packaging_count"], 4)
        self.assertTrue(all(item["rights_evidence"] == "UNAVAILABLE" for item in audit["records"]))

    def test_brand_assets_are_owner_approved_applied_and_publicly_verified(self) -> None:
        pack = read_json("output/brand/channel/heroverse-v2/brand-asset-pack.json")
        validate("schemas/channel_brand_asset_pack.schema.json", pack)
        self.assertEqual("VALIDATED", pack["status"])
        self.assertTrue(pack["production_applied"])
        self.assertEqual("OWNER_APPROVED_EXACT_PREVIEW_D046", pack["human_review"])
        self.assertTrue(all(value == "PASS" for value in pack["automatic_tests"].values()))

    def test_oauth_token_is_durable_after_post_configuration_reauthorization(self) -> None:
        readiness = read_json("output/integrations/youtube/heroverse/operational-readiness.json")
        validate("schemas/youtube_operational_readiness.schema.json", readiness)
        self.assertEqual("CONNECTED", readiness["connection_status"])
        self.assertTrue(readiness["token_valid_now"])
        self.assertTrue(readiness["refresh_token_present"])
        self.assertTrue(readiness["continuous_operation_ready"])
        self.assertEqual("DURABLE_POLICY_CONFIGURED", readiness["durability_status"])
        self.assertEqual("IN_PRODUCTION", readiness["oauth_publishing_status"])
        self.assertFalse(any(item.startswith("OAUTH_APP_NOT_IN_PRODUCTION") for item in readiness["blockers"]))
        self.assertFalse(any(item.startswith("OAUTH_SCOPE_CONFIGURATION_MISMATCH") for item in readiness["blockers"]))
        self.assertEqual([], readiness["blockers"])
        self.assertFalse(any(item.startswith("OAUTH_VERIFICATION_BASIS_UNPROVEN") for item in readiness["blockers"]))
        self.assertTrue(readiness["publication_guard"]["upload_permitted"])

    def test_codex_capacity_snapshot_is_valid_and_reset_not_consumed(self) -> None:
        usage = read_json("output/operations/codex-usage-snapshot.json")
        validate("schemas/codex_usage_snapshot.schema.json", usage)
        self.assertEqual(98, usage["assessment"]["weekly_headroom_percent"])
        self.assertFalse(usage["assessment"]["current_rate_limit_blocker"])
        self.assertFalse(usage["reset_credit"]["consumed"])
        self.assertEqual(0, usage["cost"]["external_api_spend_initiated_usd"])

    def test_publication_package_consumes_channel_gate_and_fails_closed(self) -> None:
        package = build_publication_package(ROOT)
        validate("schemas/publication_package.schema.json", package)
        self.assertTrue(package["channel_readiness"]["pass"])
        self.assertEqual("PASS", package["channel_readiness"]["overall_status"])
        self.assertTrue(package["integration"]["continuous_operation_ready"])
        self.assertFalse(package["publication_policy"]["upload_permitted"])
        self.assertEqual("CHANNEL_REMEDIATION_AND_NEW_VIDEO_CANDIDATE", package["publication_policy"]["next_allowed_action"])


if __name__ == "__main__":
    unittest.main()
