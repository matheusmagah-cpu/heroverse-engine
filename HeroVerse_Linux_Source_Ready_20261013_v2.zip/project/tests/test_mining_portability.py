import os
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine.mining import adapters


class MiningAdapterPortabilityTests(unittest.TestCase):
    def test_runtime_binaries_are_resolved_to_real_files(self):
        self.assertTrue(adapters.FFMPEG.is_file(), adapters.FFMPEG)
        self.assertTrue(adapters.FFPROBE.is_file(), adapters.FFPROBE)

    def test_scene_detector_uses_platform_null_device(self):
        captured = {}

        def fake_run(command, *, timeout=1800):
            captured["command"] = command
            return type("Result", (), {"stderr": ""})()

        with patch.object(adapters, "run_command", side_effect=fake_run):
            result = adapters.SceneDetectionAdapter().detect(Path("fixture.mp4"), 10.0, 0.25)
        self.assertEqual(result, [0.0, 10.0])
        self.assertEqual(captured["command"][-1], os.devnull)


if __name__ == "__main__":
    unittest.main()
