"""Strict source-evolution input for the existing Phase 2 integrity assertion.

This authenticates reviewed source bytes, not historical PASS on new code.
No producer, regeneration, operational write or automatic pin refresh exists.
"""
import base64
import hashlib
import json
from pathlib import Path

RECEIPT = Path("tests/fixtures/shared_source_evolution/t25-retention-v1.json")
RECEIPT_SHA256 = "32fdc811e683414b4d7bd57dcd1e2f3c740ab160e61d92b9a091adac43221ecf"
PREIMAGES = Path("tests/fixtures/shared_source_evolution/preimages-v1.json")
PREIMAGES_SHA256 = "260aa88d57f6868ed753cbee57047cc2043096c5890e59b95d250d6442f1df00"


def _read(root, relative, expected):
    root = Path(root).resolve()
    path = root / relative
    if (Path(relative).is_absolute() or not path.resolve().is_relative_to(root)
            or path.is_symlink() or not path.is_file() or path.stat().st_size > 1048576):
        raise ValueError(f"SOURCE_EVOLUTION_PATH: {relative}")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError(f"SOURCE_EVOLUTION_BYTES: {relative}")
    return raw


def load_retention_evolution(root):
    raw = _read(root, RECEIPT, RECEIPT_SHA256)
    document = json.loads(raw)
    if (document['schema_version'] != '1.0.0' or document['phase'] != 6
            or document['status'] != 'AUTHORIZED_SHARED_SOURCE_EVOLUTION'
            or document['scope'] != 'SOURCE_EVOLUTION_ONLY_NOT_TEST_OR_DEPLOYMENT_PASS'):
        raise ValueError('SOURCE_EVOLUTION_CONTRACT')
    pins = document['bindings']
    payloads = {name: _read(root, pin['path'], pin['sha256']) for name, pin in pins.items()}
    # The proof's source manifest includes this JSON, so prior bytes remain
    # authenticated by the candidate even outside the maintenance directory.
    preimages = json.loads(_read(root, PREIMAGES, PREIMAGES_SHA256))
    for family in ('pipeline', 'test'):
        pin = pins[family + '_before']
        rows = [row for row in preimages['files'] if row['path'] == pin['path']]
        if (len(rows) != 1 or rows[0]['sha256'] != pin['sha256']
                or base64.b64decode(rows[0]['content_base64'], validate=True) != payloads[family + '_before']):
            raise ValueError('SOURCE_EVOLUTION_PREIMAGE')
    predecessor = json.loads(payloads['predecessor'])
    manifest = json.loads(payloads['frozen_manifest'])
    for family in ('pipeline', 'test'):
        after = pins[family + '_after']
        before = pins[family + '_before']
        entries = [row for row in document['exceptions'] if row['artifact'] == after['path']]
        if len(entries) != 1:
            raise ValueError('SOURCE_EVOLUTION_POPULATION')
        entry = entries[0]
        historical = [row for row in manifest['entries'] if row['artifact'] == entry['artifact']]
        previous = [row for row in predecessor['exceptions'] if row['artifact'] == entry['artifact']]
        if (len(historical) != 1 or len(previous) != 1
                or historical[0]['sha256'] != entry['historical_phase2_sha256']
                or previous[0]['historical_phase2_sha256'] != entry['historical_phase2_sha256']
                or previous[0]['phase6_sha256'] != before['sha256']
                or entry['phase6_sha256'] != after['sha256']):
            raise ValueError('SOURCE_EVOLUTION_CHAIN')
    # Reopen all bytes at closure; the caller still checks every manifest entry.
    for name, pin in pins.items():
        if _read(root, pin['path'], pin['sha256']) != payloads[name]:
            raise ValueError('SOURCE_EVOLUTION_RACE')
    _read(root, RECEIPT, RECEIPT_SHA256)
    _read(root, PREIMAGES, PREIMAGES_SHA256)
    return document
