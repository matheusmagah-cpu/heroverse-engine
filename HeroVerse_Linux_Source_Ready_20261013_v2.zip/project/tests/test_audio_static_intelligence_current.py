"""Selected observer -> real queue/quota -> current native intelligence.

Provider, OAuth, codec and host frontiers are fixture simulations, not live
audience evidence. Native publication, snapshot, ledger and decision readers run.
"""
import copy
import json
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch
from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_intelligence as intelligence, central_manager_phase5 as manager
from hero_engine.queue_phase6 import TransactionalQueue
from tests import test_audio_static_observer_queue as observer
from tests import test_phase6_intelligence as legacy


class AudioStaticIntelligenceCurrentTests(unittest.TestCase):
    def test_selected_observer_materializes_exact_delivery_and_reuses_without_query(self):
        owner=observer.AudioStaticObserverQueueTests('test_unknown_collection_result_cannot_retry_the_same_query')
        self.addCleanup(owner.doCleanups);owner.setUp()
        old=owner.root/intelligence.BASE/'experiments/active.json'
        old.parent.mkdir(parents=True);old.write_bytes(b'{"historical":"keep byte exact"}')
        saved_old=old.read_bytes();target=owner.video
        class CurrentYouTube(observer.provider.YouTube):
            def list(self,**kwargs):
                response=super().list(**kwargs)
                if self.resource=='videos':response.response['items'][0]['id']=target
                return response
        with patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(manager,'ensure_oauth_session_health',return_value={'status':'HEALTHY'}), \
             patch.object(observer.pilot,'_build_services',return_value=(CurrentYouTube(),observer.provider.Analytics())) as network:
            result=owner.call();self.assertEqual(result['status'],'COLLECTED',result)
            directory=owner.package/'intelligence'
            paths=[directory/part/'latest.json' for part in ('predictions','diagnoses','experiments')]
            before={p:p.read_bytes() for p in paths}
            prediction,diagnosis,protocol=[json.loads(before[p]) for p in paths]
            self.assertEqual(prediction['video_id'],target)
            self.assertEqual(prediction['cohort']['format_pack_id'],'fp-narrated-reflection-static')
            self.assertIsNone(prediction['forecast'])
            self.assertEqual(diagnosis['baseline']['video_id'],target)
            self.assertEqual(diagnosis['evidence_refs'][0],result['latest_snapshot'])
            self.assertEqual(protocol['baseline']['snapshot_id'],diagnosis['baseline']['snapshot_id'])
            self.assertFalse(protocol['treatment']['preregistered_before_production'])
            self.assertNotEqual(protocol['status'],'PREREGISTERED')
            again=owner.call(owner.now+timedelta(minutes=1))
            self.assertEqual(again['status'],'NOT_DUE',again)
            self.assertEqual(network.call_count,1)
        self.assertEqual({p:p.read_bytes() for p in paths},before)
        self.assertEqual(old.read_bytes(),saved_old)
        self.assertFalse((old.parent/'latest.json').exists())
        job=TransactionalQueue(owner.root).snapshot()['jobs'][0]
        snapshot=owner.root/job['checkpoint']['metrics_snapshot']
        selection={**owner.selection,'snapshot_reference':job['checkpoint']['metrics_snapshot']}
        # Real reader rejects changes; none may replace valid decisions/query API.
        for path in (snapshot,owner.package/'youtube-publication-receipt.json'):
            with self.subTest(tamper=path.name):
                saved=path.read_bytes();path.write_bytes(saved+b' ')
                try:
                    with self.assertRaises((PermissionError,ValueError)):
                        intelligence.materialize_current(owner.root,**selection)
                finally:path.write_bytes(saved)
                self.assertEqual({p:p.read_bytes() for p in paths},before)
        bad={**selection,'snapshot_reference':'output/operations/phase6/metrics/iK_5edYQtx8/latest.json'}
        with self.assertRaises(PermissionError):intelligence.materialize_current(owner.root,**bad)
        self.assertEqual(old.read_bytes(),saved_old)
        self.assertEqual(TransactionalQueue(owner.root).snapshot()['jobs'][0]['state'],'SUCCEEDED')

    def test_identity_and_legacy_schema_do_not_accept_current_sources_silently(self):
        snapshot=legacy.Phase6IntelligenceTests._snapshot()
        current=copy.deepcopy(snapshot);current['video_id']='new-audio-id'
        for builder in (intelligence.build_prediction,intelligence.build_diagnostic_decision,intelligence.build_experiment_protocol):
            args=(current,{}) if builder is intelligence.build_diagnostic_decision else (current,)
            with self.subTest(builder=builder.__name__):
                with self.assertRaises(PermissionError):builder(*args)
        prediction=intelligence.build_prediction(snapshot)
        prediction['video_id']='new-audio-id'
        schema=json.loads((legacy.ROOT/'schemas/prediction_record.schema.json').read_bytes())
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(prediction)
        protocol=intelligence.build_experiment_protocol(snapshot);protocol['baseline']['video_id']='new-audio-id'
        schema=json.loads((legacy.ROOT/'schemas/phase6_experiment_protocol.schema.json').read_bytes())
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(protocol)

    def test_partial_selection_cannot_fall_back_to_historical_latest(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with self.assertRaises(PermissionError):
                intelligence.materialize_current(root,package_relative=Path('output/production/current'))
            self.assertEqual(list(root.iterdir()),[])
