from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.publication_package_creative_v3_phase5 import (
    build_creative_v3_publication_package,
)


ROOT = Path(__file__).resolve().parents[1]
V3 = ROOT / "output/production/phase5/pilot-001/creative-v3"


def read_json(path: Path | str) -> dict:
    target = path if isinstance(path, Path) else ROOT / path
    return json.loads(target.read_text(encoding="utf-8-sig"))


def validate(schema: str, instance: dict) -> None:
    Draft202012Validator(read_json(f"schemas/{schema}")).validate(instance)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class CreativeV3Phase5Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.render = read_json(V3 / "render_manifest.json")
        cls.metrics = read_json(V3 / "qa/creative_revision_metrics.json")
        cls.technical = read_json(V3 / "qa/technical_measurements.json")
        cls.qa = read_json(V3 / "qa/creative_quality_gate_report.json")
        cls.market = read_json(V3 / "qa/market_readiness_review.json")
        cls.treatment = read_json(V3 / "creative_treatment_plan.json")
        cls.takes = read_json(V3 / "take_plan.json")
        cls.thumbnails = read_json(V3 / "thumbnail/thumbnail_set_manifest.json")
        cls.brief = read_json(V3 / "editorial_brief.json")
        cls.script = read_json(V3 / "narrative_script.json")

    def test_v3_structured_artifacts_validate(self) -> None:
        validate("render_manifest.schema.json", self.render)
        validate("creative_revision_metrics.schema.json", self.metrics)
        validate("creative_quality_gate_report.schema.json", self.qa)
        validate("market_readiness_review.schema.json", self.market)
        validate("creative_treatment_plan.schema.json", self.treatment)
        validate("take_plan.schema.json", self.takes)

    def test_exact_render_hash_and_frame_lock_are_preserved(self) -> None:
        render_path = Path(self.render["output"]["path"])
        self.assertEqual(
            self.render["output"]["content_hash"].removeprefix("sha256:"),
            sha256(render_path),
        )
        self.assertEqual(238700, self.render["output"]["duration_ms"])
        self.assertEqual(7161, self.render["measurements"]["expected_total_frames"])
        self.assertEqual(0.0, self.render["measurements"]["maximum_take_duration_error_ms"])
        self.assertEqual(0.0, self.render["measurements"]["maximum_cumulative_drift_ms"])

    def test_v3_2_expanded_rigor_passes_after_visual_repetition_remediation(self) -> None:
        self.assertEqual("3.2.0", self.treatment["version"])
        self.assertEqual("creative-v3.2", self.metrics["revision"])
        self.assertEqual("PASS", self.metrics["automatic_status"])
        checks = {item["check"]: item for item in self.metrics["checks"]}
        for name in (
            "maximum_single_asset_runtime_share",
            "top_six_asset_runtime_concentration",
            "maximum_asset_reuse_count",
            "maximum_rolling_60s_same_asset_count",
        ):
            self.assertEqual("PASS", checks[name]["status"])
        self.assertTrue(self.metrics["human_review_required"])
        self.assertFalse(self.metrics["publication_eligible"])
        self.assertFalse(self.qa["publication_eligible"])
        self.assertNotIn("STYLE", self.qa["critical_gate_failures"])
        self.assertNotIn("TECHNICAL", self.qa["critical_gate_failures"])
        self.assertIn("PUBLICATION", self.qa["critical_gate_failures"])
        self.assertEqual("PENDING", self.qa["human_review"]["status"])

    def test_visual_motion_audio_and_caption_measurements_pass(self) -> None:
        self.assertEqual(0, self.technical["black_freeze"]["black_event_count"])
        self.assertEqual(0, self.technical["black_freeze"]["freeze_event_count"])
        self.assertLessEqual(self.technical["signalstats"]["within_take_luminance_delta_p95"], 15.0)
        self.assertEqual(0, self.technical["signalstats"]["hard_transition_count"])
        self.assertLessEqual(self.technical["loudness"]["integrated_lufs"], -14.0)
        self.assertGreaterEqual(self.technical["loudness"]["integrated_lufs"], -18.0)
        self.assertLessEqual(self.technical["loudness"]["true_peak_dbtp"], -1.0)
        self.assertEqual(59, self.technical["captions"]["cue_count"])
        self.assertEqual(1.0, self.technical["captions"]["coverage_ratio"])
        self.assertLessEqual(self.technical["captions"]["maximum_words_per_cue"], 12)

    def test_hook_and_asset_diversity_meet_measured_contract(self) -> None:
        checks = {item["check"]: item for item in self.metrics["checks"]}
        self.assertEqual(3, len(self.technical["hook"]["distinct_sources"]))
        self.assertGreaterEqual(self.technical["hook"]["visual_event_count"], 4)
        self.assertLessEqual(checks["maximum_pattern_interrupt_gap_ms"]["observed"], 25000)
        self.assertGreaterEqual(self.metrics["asset_runtime"]["unique_asset_count"], 22)
        self.assertLessEqual(self.metrics["asset_runtime"]["maximum_third_party_share"], 0.2)
        self.assertLessEqual(checks["landscape_dominant_runtime_share"]["observed"]["share"], 0.25)
        self.assertFalse(checks["forbidden_generic_cloud_fallback"]["observed"])
        self.assertFalse(checks["rejected_context_asset_absent"]["observed"])
        repetition = self.metrics["visual_repetition"]
        self.assertLessEqual(repetition["maximum_single_asset"]["share"], 0.10)
        self.assertLessEqual(repetition["top_six_runtime_share"], 0.55)
        self.assertLessEqual(repetition["maximum_asset_reuse_count"], 5)
        self.assertLessEqual(repetition["maximum_rolling_60s_same_asset_count"], 3)
        self.assertTrue(repetition["passed"])
        self.assertEqual(3, len(repetition["sample_evidence"]))
        self.assertTrue(all((V3 / ref.split("creative-v3/", 1)[1]).is_file() for ref in repetition["sample_evidence"]))

    def test_local_procedural_infographics_are_versioned_and_zero_cost(self) -> None:
        manifest = read_json(V3 / "assets/procedural/manifest.json")
        self.assertEqual("HeroVerseLocalVectorMotion@1.0.1", manifest["generator"])
        self.assertEqual(25, len(manifest["assets"]))
        by_role = {}
        for item in manifest["assets"]:
            by_role.setdefault(item["semantic_role"], []).append(item)
        expected_capacity = {
            "truth_test_infographic": 4,
            "scriptural_mechanism": 4,
            "safe_boundaries": 5,
            "decision_cards": 4,
            "decision": 2,
            "renewal": 2,
            "tension": 1,
        }
        for role, minimum in expected_capacity.items():
            self.assertGreaterEqual(len(by_role.get(role, [])), minimum, role)
            self.assertEqual(
                len(by_role[role]), len({item["video_hash"] for item in by_role[role]}), role
            )
        self.assertEqual(0, manifest["external_cost_brl"])
        for item in manifest["assets"]:
            self.assertTrue(Path(item["svg_path"]).is_file())
            self.assertTrue(Path(item["raster_path"]).is_file())
            self.assertTrue(Path(item["video_path"]).is_file())
            self.assertEqual(0, item["external_cost_brl"])

    def test_ai_review_is_useful_but_never_impersonates_independent_human_review(self) -> None:
        review = read_json(V3 / "human-review/ai_supplemental_review.json")
        validate("phase5_ai_supplemental_review.schema.json", review)
        self.assertEqual("SUPPLEMENTAL_PASS_HUMAN_GATES_REMAIN", review["decision"])
        self.assertFalse(review["independent_human_gate_satisfied"])
        self.assertFalse(review["publication_gate_satisfied"])
        self.assertFalse(review["thumbnail_assessment"]["selection_applied"])

    def test_thumbnail_set_is_three_way_and_not_self_selected(self) -> None:
        self.assertEqual(3, len(self.thumbnails["candidates"]))
        self.assertTrue(all(item["automated_status"] == "PASS" for item in self.thumbnails["candidates"]))
        self.assertIsNone(self.thumbnails["selected_candidate"])
        self.assertEqual("BLOCKED_PENDING_INDEPENDENT_HUMAN_REVIEW", self.thumbnails["selection_status"])

    def test_market_boundary_is_explicit(self) -> None:
        self.assertEqual("READY_FOR_INDEPENDENT_HUMAN_REVIEW", self.market["verdict"])
        self.assertFalse(self.market["independent_human_review_satisfied"])
        self.assertEqual("UNAVAILABLE_BEFORE_PUBLICATION", self.market["claim_boundary"]["viral_result"])
        self.assertEqual("UNAVAILABLE", self.market["claim_boundary"]["ctr"])
        self.assertEqual("UNAVAILABLE", self.market["claim_boundary"]["retention"])
        self.assertEqual("UNAVAILABLE", self.market["claim_boundary"]["rpm"])

    def test_title_packaging_decision_is_versioned_and_fail_closed(self) -> None:
        working = "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation"
        selected = "The 24-Hour Test: What To Do After You Pray"
        package = build_creative_v3_publication_package(ROOT)
        decision = read_json("output/production/phase5/pilot-001/creative-v3/metadata_packaging_decision.json")
        validate("metadata_packaging_decision.schema.json", decision)
        self.assertEqual(working, self.brief["package"]["title_concept"])
        self.assertEqual(working, self.script["title"])
        self.assertEqual(working, self.thumbnails["title"])
        self.assertEqual(selected, decision["selected_title"])
        self.assertEqual(selected, package["metadata"]["title"])
        self.assertEqual(91, package["metadata_decision"]["provider_score"])
        self.assertFalse(package["metadata_decision"]["provider_score_is_causal"])
        self.assertEqual("SELECTED_BY_AUTONOMOUS_EDITORIAL_RUBRIC", package["metadata_decision"]["selection_status"])
        self.assertNotIn("DON'T DO NOTHING", json.dumps(self.brief))

    def test_format_pack_is_limited_by_autonomous_canary_contract(self) -> None:
        pack = read_json("config/format_packs/fp-broll-cinematic-narration-v1.json")
        validate("format_pack.schema.json", pack)
        self.assertEqual("LIMITED", pack["capability_status"])
        self.assertTrue(pack["production_allowed"])
        self.assertEqual([], pack["evidence"]["human_review_ids"])
        self.assertEqual("TESTING", pack["learning_history"][-1]["status"])
        self.assertIn("autonomous-quality", pack["learning_history"][-1]["learning_id"])

    def test_v3_publication_package_is_complete_and_autonomously_ready(self) -> None:
        package = build_creative_v3_publication_package(ROOT)
        validate("publication_package.schema.json", package)
        self.assertEqual("READY_AUTONOMOUS_LIMITED", package["status"])
        self.assertEqual("CONNECTED", package["integration"]["connection_status"])
        self.assertTrue(package["integration"]["identity_verified"])
        self.assertTrue(package["integration"]["continuous_operation_ready"])
        self.assertTrue(package["publication_policy"]["upload_permitted"])
        self.assertEqual("AUTONOMOUS_PRIVATE_FIRST_UPLOAD", package["publication_policy"]["next_allowed_action"])
        self.assertEqual("PASS", package["quality_gate"]["automatic_status"])
        self.assertTrue(package["format_capability"]["production_allowed"])
        self.assertEqual("NOT_REQUIRED_PER_RELEASE", package["quality_gate"]["human_review"])
        self.assertEqual("standard-qualification-9c1d64c6b5f1cfeb3e59", package["quality_gate"]["standard_qualification_id"])
        self.assertEqual("33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c", package["video"]["sha256"])
        self.assertIn("standard-qualification", package["video"]["path"])
        self.assertEqual("SELECTED_BY_AUTONOMOUS_EDITORIAL_RUBRIC", package["thumbnail"]["selection_status"])
        self.assertIn("Mount Bromo", package["metadata"]["description"])

    def test_vidiq_adapter_is_schema_valid_and_not_falsely_connected(self) -> None:
        plugin = read_json("config/tool_adapters/adapter-vidiq-plugin-v1.json")
        web = read_json("config/tool_adapters/adapter-vidiq-web-v1.json")
        validate("tool_adapter_profile.schema.json", plugin)
        validate("tool_adapter_profile.schema.json", web)
        self.assertEqual("MARKET_RESEARCH", plugin["category"])
        self.assertEqual("LIMITED", plugin["status"])
        self.assertEqual("PARTIAL", plugin["observed_quality"]["status"])
        self.assertEqual(0, plugin["cost"]["per_unit"])
        self.assertEqual("LIMITED", web["status"])
        self.assertEqual("PARTIAL", web["observed_quality"]["status"])
        self.assertEqual(0, web["cost"]["per_unit"])

    def test_vidiq_web_observation_is_real_auxiliary_evidence(self) -> None:
        observation = read_json("output/market/vidiq/heroverse/2026-09-03/research-observation.json")
        validate("vidiq_research_observation.schema.json", observation)
        queries = {item["term"]: item for item in observation["query_observations"]}
        self.assertEqual(72, queries["christian motivation"]["overall_score"])
        self.assertEqual(197334, queries["christian motivation"]["search_volume"]["value"])
        self.assertEqual(0, queries["what to do after prayer"]["overall_score"])
        self.assertEqual(12, len(observation["video_sample"]["results"]))
        self.assertEqual("NOT_CONNECTED", observation["channel_connection"])
        self.assertFalse(observation["cost"]["paid_upgrade_accepted"])
        self.assertIn("24-Hour Test", build_creative_v3_publication_package(ROOT)["metadata"]["title"])

    def test_vidiq_plugin_observation_tracks_free_quota_and_does_not_fake_owned_analytics(self) -> None:
        observation = read_json("output/market/vidiq/heroverse/2026-09-03/plugin-observation.json")
        validate("vidiq_plugin_observation.schema.json", observation)
        self.assertEqual(150, observation["quota"]["max_renewable_credits"])
        self.assertEqual(95, observation["quota"]["remaining_renewable_credits"])
        self.assertEqual(55, observation["quota"]["consumed_credits"])
        self.assertEqual(0, observation["quota"]["technical_cost_brl"])
        self.assertEqual(0, observation["account_connection"]["authorized_owned_channel_count"])
        self.assertFalse(observation["account_connection"]["owned_channel_analytics_available"])
        self.assertEqual("The 24-Hour Test: What To Do After You Pray", observation["title_packaging"]["selected_title"])
        self.assertFalse(observation["title_packaging"]["score_is_causal"])

    def test_standard_qualification_is_measured_and_fail_closed(self) -> None:
        report_path = V3 / "standard-qualification/standard_qualification_report.json"
        if not report_path.is_file():
            self.skipTest("STANDARD qualification evidence has not been materialized yet")
        report = read_json(report_path)
        validate("standard_qualification_report.schema.json", report)
        self.assertEqual("PASS", report["automatic_profile_status"])
        self.assertEqual("BLOCKED_PENDING_HUMAN_AND_EXTERNAL_GATES", report["overall_status"])
        self.assertFalse(report["production_approved"])
        self.assertFalse(report["publication_eligible"])
        self.assertGreaterEqual(report["candidate"]["video_bitrate_kbps"], 8000)
        self.assertEqual(7161, report["candidate"]["frame_count"])
        self.assertTrue(report["replay"]["equivalence_pass"])
        self.assertGreaterEqual(report["replay"]["perceptual_ssim"], 0.995)
        self.assertFalse(report["replay"]["container_exact_match"])
        self.assertEqual("MULTITHREADED_H264_NON_BIT_EXACT", report["variance_observations"][0]["type"])
        self.assertTrue(all(item["status"] == "PASS" for item in report["technical_checks"]))
        unresolved = {item["check"]: item["status"] for item in report["unresolved_gates"]}
        self.assertEqual("NEEDS_REVIEW", unresolved["independent_human_full_render_review"])
        self.assertEqual("BLOCKED", unresolved["format_pack_production_capability"])
        self.assertEqual("BLOCKED", unresolved["oauth_continuous_operation"])

    def test_standard_replay_is_equivalent_without_inventing_an_incident(self) -> None:
        receipt_path = V3 / "standard-qualification/replay_variance_incident.json"
        report = read_json(V3 / "standard-qualification/standard_qualification_report.json")
        if not receipt_path.is_file():
            self.assertTrue(report["replay"]["equivalence_pass"])
            self.assertGreaterEqual(report["replay"]["perceptual_ssim"], 0.995)
            return
        receipt = read_json(receipt_path)
        validate("production_recovery_receipt.schema.json", receipt)
        self.assertEqual("RESOLVED", receipt["status"])
        self.assertEqual("FAIL", receipt["failure"]["status"])
        self.assertEqual("PASS", receipt["retest"]["status"])
        self.assertTrue(receipt["correction"]["quality_floor_preserved"])
        self.assertFalse(receipt["correction"]["canonical_master_modified"])
        self.assertEqual(
            receipt["preservation"]["canonical_master_hash_before"],
            receipt["preservation"]["canonical_master_hash_after"],
        )
        self.assertEqual(report["candidate"]["content_hash"], receipt["failure"]["observed"]["candidate_container_hash"])
        self.assertEqual(report["replay"]["content_hash"], receipt["failure"]["observed"]["replay_container_hash"])
        self.assertFalse(receipt["publication_guard"]["upload_permitted"])

    def test_rejected_v3_1_baseline_is_preserved_outside_the_canonical_path(self) -> None:
        archive = ROOT / "output/production/phase5/pilot-001/creative-history/creative-v3.1-rejected-visual-repetition"
        self.assertTrue((archive / "ARCHIVE_NOTE.md").is_file())
        self.assertTrue((archive / "qa/creative_revision_metrics.json").is_file())
        rejected = read_json(archive / "qa/creative_revision_metrics.json")
        self.assertEqual("FAIL", rejected["automatic_status"])


if __name__ == "__main__":
    unittest.main()
