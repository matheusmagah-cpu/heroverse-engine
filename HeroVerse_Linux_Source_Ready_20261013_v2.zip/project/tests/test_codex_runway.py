import copy
import hashlib
import json
from pathlib import Path
import unittest
import tempfile
from unittest.mock import patch
from hero_engine.codex_runway import calculate_runway
from hero_engine.codex_usage_governance import evaluate_usage, validate_decision, materialize_observation

ROOT = Path(__file__).resolve().parents[1]


def frozen_runway_fixture():
    """Historical replay inputs, never the account's mutable post-reset policy.

    The complete pre-reset policy and native observation are pinned separately;
    every caller receives new dictionaries. Synthetic mutations stay test-local.
    """
    pins = (
        ('output/operations/codex-usage/policy-history/before-reset-d7479865.json',
         '8cb45f4d531229b7745ce7bdfb68be1fe927deee966a980f577b7f7290c25ce8'),
        ('output/operations/codex-usage/observations/account-20260906T151017Z.json',
         '676c142c941b27d080638505ecd003ee13f08164ca0864ef4caf3f4838d71516'),
    )
    inputs = []
    for relative, expected in pins:
        payload = (ROOT / relative).read_bytes()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise AssertionError(f'frozen runway fixture hash differs: {relative}')
        inputs.append(json.loads(payload))
    return tuple(inputs)


class RunwayTests(unittest.TestCase):
    def setUp(self):
        self.policy,self.observation=frozen_runway_fixture()
        self.plan=self.policy['workload_plan']

    def calculate(self,**kwargs):
        args=dict(observed_at='2026-09-06T15:10:17Z',resets_at='2026-09-13T02:15:36Z',
                  used_percent=62,reserve_percent=10,known_project_ids={p['project_id'] for p in self.policy['coordination']['projects']})
        args.update(kwargs);return calculate_runway(self.plan,**args)

    def test_exact_seconds_and_ceiling(self):
        result=self.calculate()
        self.assertEqual(result['remaining_seconds'],558319)
        self.assertEqual(result['spendable_percentage_points'],28)
        self.assertAlmostEqual(result['percentage_points_per_day'],28*86400/558319)
        self.assertEqual(result['status'],'ON_PLAN')
        self.assertFalse(result['continuous_codex_guaranteed'])

    def test_observation_before_frozen_anchor_still_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'invalid workload plan timeline'):
            self.calculate(observed_at='2026-09-06T15:10:16Z')

    def test_mutable_policy_rebase_cannot_change_frozen_fixture(self):
        before=self.calculate()
        rebased=copy.deepcopy(self.policy)
        rebased['workload_plan'].update(
            recorded_at='2026-09-07T14:15:03.310080Z',
            anchor_observed_at='2026-09-07T14:15:03.310080Z',
            anchor_used_percent=3,anchor_resets_at='2026-09-14T13:11:15Z')
        original_read_bytes=Path.read_bytes
        mutable_reads=[]
        def simulated_live_rebase(path):
            if path == ROOT/'config/codex-usage-policy.json':
                mutable_reads.append(path)
                return json.dumps(rebased).encode('utf-8')
            return original_read_bytes(path)
        with patch.object(Path,'read_bytes',simulated_live_rebase):
            policy,observation=frozen_runway_fixture()
        self.assertEqual(mutable_reads,[])
        self.assertEqual(policy,self.policy)
        self.assertEqual(observation,self.observation)
        self.assertEqual(policy['workload_plan']['anchor_used_percent'],62)
        self.assertEqual(self.calculate(),before)
        # A separate rebase remains valid at its own timestamp, never retroactive.
        known={p['project_id'] for p in policy['coordination']['projects']}
        result=calculate_runway(rebased['workload_plan'],
            observed_at='2026-09-07T14:15:03.310080Z',resets_at='2026-09-14T13:11:15Z',
            used_percent=3,reserve_percent=10,known_project_ids=known)
        self.assertEqual(result['status'],'ON_PLAN')
        with self.assertRaisesRegex(ValueError,'invalid workload plan timeline'):
            calculate_runway(rebased['workload_plan'],observed_at='2026-09-06T15:10:17Z',
                resets_at='2026-09-13T02:15:36Z',used_percent=62,reserve_percent=10,
                known_project_ids=known)
        policy['workload_plan']['anchor_used_percent']=3
        self.assertEqual(frozen_runway_fixture()[0]['workload_plan']['anchor_used_percent'],62)

    def test_single_active_is_not_two_balances(self):
        result=self.calculate();self.assertEqual(len(result['active_project_ids']),1)
        self.assertEqual(len(result['paused_project_ids']),1)
        self.assertFalse(result['credit_balance_converted_to_weekly_percent'])

    def test_fast_consumption_detected_against_frozen_anchor(self):
        result=self.calculate(observed_at='2026-09-06T16:10:17Z',used_percent=64)
        self.assertEqual(result['status'],'AHEAD_OF_PLAN')
        self.assertGreater(result['ahead_of_plan_percentage_points'],1.8)

    def test_unknown_expired_and_changed_reset_never_guarantee(self):
        for arguments,status in [({'resets_at':None},'UNAVAILABLE'),
            ({'observed_at':'2026-09-13T02:15:36Z'},'REBASE_REQUIRED'),
            ({'resets_at':'2026-09-14T02:15:36Z'},'REBASE_REQUIRED'),
            ({'used_percent':2},'REBASE_REQUIRED')]:
            self.assertEqual(self.calculate(**arguments)['status'],status)

    def test_reserve_floor_and_invalid_numbers(self):
        self.assertEqual(self.calculate(used_percent=90)['status'],'RESERVE_ONLY')
        for value in (True,float('nan'),float('inf'),-1,101):
            with self.assertRaises(ValueError):self.calculate(used_percent=value)

    def test_overlap_missing_or_fake_project_rejected(self):
        for active in ([self.plan['paused_project_ids'][0]],[],['fake']):
            before=copy.deepcopy(self.plan)
            self.plan['active_project_ids']=active
            with self.assertRaises(ValueError):self.calculate()
            self.plan=before

    def test_decision_v12_and_history_unchanged(self):
        result=evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T15:10:17Z')
        validate_decision(result);self.assertEqual(result['schema_version'],'1.2.0')
        old=evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T13:37:00Z')
        validate_decision(old);self.assertEqual(old['schema_version'],'1.1.0')
        self.assertNotIn('renewal_runway',old)

    def test_pacing_ahead_blocks_heavy_work_without_downgrade(self):
        self.observation['rateLimitsByLimitId']['codex']['primary']['usedPercent']=64
        result=evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T16:10:17Z')
        validate_decision(result)
        self.assertFalse(result['capacity_decision']['high_consumption_work_allowed'])
        self.assertTrue(result['continuity']['codex_discretionary_work_may_wait'])
        self.assertEqual(result['capacity_decision']['action'],'FULL_QUALITY_CRITICAL_PATH_ONLY')
        self.assertEqual(result['quality_policy']['reasoning_effort'],'ultra')
        self.assertFalse(result['reset_credits']['consumed_now'])

    def test_native_invalid_percentage_cannot_be_clamped_into_admission(self):
        for value in (True,float('nan'),float('inf'),-1,101,'62'):
            self.observation['rateLimitsByLimitId']['codex']['primary']['usedPercent']=value
            with self.assertRaises(ValueError):
                evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T15:10:17Z')

    def test_pacing_does_not_relax_critical_reserve_action(self):
        self.observation['rateLimitsByLimitId']['codex']['primary']['usedPercent']=95
        result=evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T16:10:17Z')
        validate_decision(result)
        self.assertEqual(result['capacity_decision']['action'],'PRESERVE_RESERVE_AND_WAIT_FOR_RESET')
        self.assertTrue(result['continuity']['codex_discretionary_work_may_wait'])

    def test_fractional_band_boundaries_are_covered(self):
        for remaining, expected in ((9.999999,'CRITICAL_RESERVE'),(10,'RED'),
            (24.999999,'RED'),(25,'AMBER'),(49.999999,'AMBER'),(50,'GREEN'),(100,'GREEN')):
            self.observation['rateLimitsByLimitId']['codex']['primary']['usedPercent']=100-remaining
            result=evaluate_usage(self.observation,self.policy,observed_at='2026-09-06T15:10:17Z')
            validate_decision(result)
            self.assertEqual(result['capacity_decision']['status'],expected)

    def test_all_real_history_remains_schema_valid(self):
        history=list((ROOT/'output/operations/codex-usage/history').glob('*.json'))
        self.assertTrue(history)
        for path in history:validate_decision(json.loads(path.read_text(encoding='utf-8')))

    def test_atomic_history_replay_and_failed_view_preserve_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            policy_path=root/'config/codex-usage-policy.json'
            policy_path.parent.mkdir(parents=True,exist_ok=True)
            policy_path.write_text(json.dumps(self.policy),encoding='utf-8')
            relative='schemas/codex_usage_governance.schema.json'
            target=root/relative;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes((ROOT/relative).read_bytes())
            latest=materialize_observation(self.observation,root,observed_at='2026-09-06T15:10:17Z')
            original=latest.read_bytes()
            first=json.loads(original)
            self.assertEqual(first['schema_version'],'1.2.0')
            self.assertEqual(first['workload_plan'],self.plan)
            self.assertEqual(first['renewal_runway']['status'],'ON_PLAN')
            self.assertEqual(first['renewal_runway']['remaining_seconds'],558319)
            materialize_observation(self.observation,root,observed_at='2026-09-06T15:10:17Z')
            self.assertEqual(latest.read_bytes(),original)
            self.observation['rateLimitsByLimitId']['codex']['primary']['usedPercent']=64
            with patch('hero_engine.codex_usage_governance.atomic_write_utf8',side_effect=PermissionError('lock')):
                with self.assertRaises(PermissionError):
                    materialize_observation(self.observation,root,observed_at='2026-09-06T16:10:17Z')
            self.assertEqual(latest.read_bytes(),original)
            materialize_observation(self.observation,root,observed_at='2026-09-06T16:10:17Z')
            value=json.loads(latest.read_text())
            self.assertEqual(value['schema_version'],'1.2.0')
            self.assertEqual(value['renewal_runway']['status'],'AHEAD_OF_PLAN')
            self.assertEqual(latest.read_bytes(),(latest.parent/'history'/(value['decision_id']+'.json')).read_bytes())
            self.assertEqual(list(latest.parent.rglob('*.tmp')),[])


if __name__=='__main__':unittest.main()
