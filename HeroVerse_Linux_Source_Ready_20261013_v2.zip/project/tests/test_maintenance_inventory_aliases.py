from __future__ import annotations

import ast
import copy
import hashlib
import importlib.machinery
import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from hero_engine import maintenance_protocol as protocol
from hero_engine.maintenance_unittest_result import UnittestResultError, verify_unittest_result
from hero_engine.phase6_maintenance_verification import verify_regression_evidence
from hero_engine.phase6_acceptance import _test_evidence
from tests import test_phase6_maintenance_verification_v12 as regression_fixtures


ROOT = Path(__file__).resolve().parents[1]
LOADER = "tests/test_maintenance_abandoned_request.py"
SOURCE = "tests/test_daily_maintenance_protocol.py"


def _write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return protocol.file_hash(path)


def _ids(inventory):
    return [test_id for file in inventory["files"] for test_id in file["test_ids"]] + [
        alias["execution_id"] for alias in inventory.get("load_tests_aliases", [])
    ]


def _log(inventory):
    rows = []
    for index, test_id in enumerate(_ids(inventory)):
        method = test_id.rsplit(".", 1)[-1]
        # Both unittest discovery spellings, multiline descriptions, and a
        # diagnostic that separates the identity from its terminal outcome.
        runtime_id = test_id.removeprefix("tests.") if index % 2 else test_id
        suffix = "\nDescription ... [ WARN:0] diagnostic\nok\n" if index == 0 else " ... ok\n"
        rows.append(f"{method} ({runtime_id})" + suffix)
    return "".join(rows) + f"Ran {inventory['test_count']} tests in 0.125s\n\nOK\n[native] diagnostic\n"


def _verify(inventory, log):
    return verify_unittest_result(
        inventory=inventory, stdout_bytes=b"", stderr_bytes=log.encode(), process_exit_code=0,
    )


@contextmanager
def _fixture():
    # Reuse the existing complete receipt fixture and its confined synthetic
    # state. No donor test cases or load_tests hooks are executed here.
    with regression_fixtures._fixture() as (root, receipt):
        for relative in (LOADER, SOURCE):
            (root / relative).write_bytes((ROOT / relative).read_bytes())
        run_rel = Path(receipt["tests"]["inventory_path"]).parent
        manifests = protocol.build_validation_manifests(root, output_dir=run_rel)
        inventory_path = root / manifests["test_inventory_path"]
        inventory = json.loads(inventory_path.read_bytes())
        tests = receipt["tests"]
        tests.update({
            "inventory_hash": manifests["test_inventory_hash"],
            "file_count": manifests["test_file_count"], "test_count": manifests["test_count"],
        })
        receipt["schemas"]["inventory_hash"] = manifests["schema_inventory_hash"]
        log = _log(inventory)
        (root / tests["stderr_log"]).write_bytes(log.encode())
        tests["stderr_hash"] = protocol.file_hash(root / tests["stderr_log"])
        yield root, receipt, inventory, log


class MaintenanceInventoryAliasTests(unittest.TestCase):
    def test_producer_verifier_receipt_and_acceptance_keep_both_executions(self):
        with _fixture() as (root, receipt, inventory, log):
            self.assertEqual("1.1.0", inventory["schema_version"])
            tree = ast.parse((root / LOADER).read_bytes())
            hook = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "load_tests")
            selected = ast.literal_eval(hook.body[3].iter)
            aliases = inventory["load_tests_aliases"]
            self.assertEqual(list(selected), [row["execution_id"].rsplit(".", 1)[1] for row in aliases])
            self.assertEqual(7, len(aliases))
            self.assertEqual(inventory["method_count"] + len(selected), inventory["test_count"])
            result = _verify(inventory, log)
            for alias in aliases:
                self.assertEqual("ok", result["outcomes"][alias["execution_id"]])
                self.assertEqual("ok", result["outcomes"][alias["source_test_id"]])
                declaration = alias["loading_declaration"]
                payload = (root / declaration["path"]).read_bytes()
                lines = payload.splitlines(keepends=True)[declaration["first_line"] - 1:declaration["last_line"]]
                self.assertEqual(declaration["declaration_hash"], "sha256:" + hashlib.sha256(b"".join(lines)).hexdigest())
                self.assertEqual(alias["source_hash"], protocol.file_hash(root / alias["source_path"]))
            verify_regression_evidence(root, receipt)
            self.assertTrue(_test_evidence(root, receipt, aliases[0]["source_test_id"]))

    def test_missing_foreign_and_duplicated_aliases_reject_even_with_rehashed_claims(self):
        with _fixture() as (root, receipt, inventory, log):
            for mode in ("missing", "foreign", "duplicate", "ordinary_collision"):
                with self.subTest(mode=mode):
                    bad = copy.deepcopy(inventory)
                    aliases = bad["load_tests_aliases"]
                    if mode == "missing":
                        aliases.pop()
                    elif mode == "foreign":
                        aliases[0]["execution_id"] = "_untrusted.Arbitrary.test_anything"
                    elif mode == "duplicate":
                        aliases.append(copy.deepcopy(aliases[0]))
                    else:
                        aliases[0]["execution_id"] = aliases[0]["source_test_id"]
                    bad["alias_count"] = len(aliases)
                    bad["aliases_hash"] = protocol.canonical_hash(aliases)
                    bad["test_count"] = len(_ids(bad))
                    bad["tests_hash"] = protocol.canonical_hash(_ids(bad))
                    receipt["tests"]["inventory_hash"] = _write(root / receipt["tests"]["inventory_path"], bad)
                    receipt["tests"]["test_count"] = bad["test_count"]
                    with self.assertRaisesRegex(UnittestResultError, "alias identity"):
                        _verify(bad, log)
                    with self.assertRaisesRegex(PermissionError, "alias identity"):
                        verify_regression_evidence(root, receipt)

    def test_alias_and_declaration_hashes_are_authenticated_not_self_asserted(self):
        with _fixture() as (_, _, inventory, log):
            for field in ("source_hash", "declaration_hash", "content_hash", "first_line", "aliases_hash"):
                with self.subTest(field=field):
                    bad = copy.deepcopy(inventory)
                    alias = bad["load_tests_aliases"][0]
                    if field == "aliases_hash":
                        bad[field] = "sha256:" + "0" * 64
                    else:
                        target = alias if field == "source_hash" else alias["loading_declaration"]
                        target[field] = float(target[field]) if field == "first_line" else "sha256:" + "0" * 64
                        bad["aliases_hash"] = protocol.canonical_hash(bad["load_tests_aliases"])
                    with self.assertRaisesRegex(UnittestResultError, "alias identity"):
                        _verify(bad, log)

    def test_missing_source_method_and_duplicate_file_are_rejected(self):
        with _fixture() as (_, _, inventory, log):
            bad = copy.deepcopy(inventory)
            source = next(row for row in bad["files"] if row["path"] == SOURCE)
            source["test_ids"].remove(bad["load_tests_aliases"][0]["source_test_id"])
            with self.assertRaisesRegex(UnittestResultError, "source test is absent"):
                _verify(bad, log)
            bad = copy.deepcopy(inventory)
            bad["files"].append(copy.deepcopy(bad["files"][0]))
            bad["file_count"] += 1
            with self.assertRaisesRegex(UnittestResultError, "invalid test file"):
                _verify(bad, log)

    def test_new_source_bytes_cannot_inherit_old_inventory_or_pinned_alias_authority(self):
        with _fixture() as (root, receipt, inventory, log):
            source = root / SOURCE
            source.write_bytes(source.read_bytes() + b"\n# different candidate\n")
            with self.assertRaisesRegex(PermissionError, "test source changed"):
                verify_regression_evidence(root, receipt)
            bad = copy.deepcopy(inventory)
            next(row for row in bad["files"] if row["path"] == SOURCE)["content_hash"] = protocol.file_hash(source)
            with self.assertRaisesRegex(UnittestResultError, "source is incompatible"):
                _verify(bad, log)
            destination = Path("rejected-new-source")
            with self.assertRaisesRegex(UnittestResultError, "source is incompatible"):
                protocol.build_validation_manifests(root, output_dir=destination)
            self.assertFalse((root / destination).exists())

    def test_inventory_does_not_import_sources_and_rejects_unknown_or_changed_loader(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "tests").mkdir()
            (root / "tests/test_never_execute.py").write_text(
                "raise RuntimeError('source must never execute')\nclass Local:\n    def test_static(self): pass\n",
                encoding="utf-8",
            )
            with patch.object(importlib.machinery.SourceFileLoader, "exec_module", side_effect=AssertionError("import forbidden")):
                manifest = protocol.build_validation_manifests(root, output_dir=Path("static"))
            self.assertEqual(1, manifest["test_count"])
            (root / "tests/test_unknown.py").write_text(
                "def load_tests(loader, tests, pattern):\n    raise RuntimeError('do not run')\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(UnittestResultError, "unsupported or changed load_tests"):
                protocol.build_validation_manifests(root, output_dir=Path("unknown"))
            self.assertFalse((root / "unknown").exists())
        with _fixture() as (root, _, _, _):
            path = root / LOADER
            path.write_bytes(path.read_bytes() + b"\n# changed loader\n")
            with self.assertRaisesRegex(UnittestResultError, "unsupported or changed load_tests"):
                protocol.build_validation_manifests(root, output_dir=Path("changed"))
            self.assertFalse((root / "changed").exists())

    def test_summary_receipt_and_inventory_counts_cannot_diverge(self):
        with _fixture() as (root, receipt, inventory, log):
            with self.assertRaisesRegex(UnittestResultError, "summary count"):
                _verify(inventory, log.replace(f"Ran {inventory['test_count']}", "Ran 1"))
            receipt["tests"]["test_count"] += 1
            with self.assertRaisesRegex(PermissionError, "count/identity"):
                verify_regression_evidence(root, receipt)
            for field in ("test_count", "method_count", "alias_count", "file_count"):
                bad = copy.deepcopy(inventory)
                bad[field] = float(bad[field])
                with self.subTest(field=field), self.assertRaises(UnittestResultError):
                    _verify(bad, log)

    def test_alias_missing_from_log_or_duplicated_is_not_a_pass(self):
        with _fixture() as (_, _, inventory, log):
            alias = inventory["load_tests_aliases"][0]["execution_id"]
            row = f"{alias.rsplit('.', 1)[1]} ({alias}) ... ok\n"
            self.assertIn(row, log)
            with self.assertRaisesRegex(UnittestResultError, "0 occurrences"):
                _verify(inventory, log.replace(row, ""))
            with self.assertRaisesRegex(UnittestResultError, "2 occurrences"):
                _verify(inventory, row + log)

    def test_foreign_execution_before_or_after_summary_cannot_hide_in_diagnostics(self):
        with _fixture() as (_, _, inventory, log):
            for outcome in ("ok", "FAIL", "ERROR"):
                extra = f"test_rogue (_abandonment_other.Class.test_rogue) ... {outcome}\n"
                for transcript in (extra + log, log + extra):
                    with self.subTest(outcome=outcome), self.assertRaisesRegex(UnittestResultError, "unlisted"):
                        _verify(inventory, transcript)

    def test_forged_ok_cannot_omit_failed_alias_subtest_or_error_header(self):
        with _fixture() as (root, receipt, inventory, log):
            alias = inventory["load_tests_aliases"][0]["execution_id"]
            row = f"{alias.rsplit('.', 1)[1]} ({alias}) ... ok\n"
            for outcome in ("FAIL", "ERROR"):
                for bad in (
                    log.replace(row, row.replace("... ok", "... " + outcome)),
                    log + f"{outcome}: {alias}\n",
                    log.replace(row, row + f"  {alias.rsplit('.', 1)[1]} ({alias}) (case=1) ... {outcome}\n"),
                ):
                    with self.subTest(outcome=outcome), self.assertRaises(UnittestResultError):
                        _verify(inventory, bad)
                    (root / receipt["tests"]["stderr_log"]).write_bytes(bad.encode())
                    receipt["tests"]["stderr_hash"] = protocol.file_hash(root / receipt["tests"]["stderr_log"])
                    with self.assertRaises(PermissionError):
                        verify_regression_evidence(root, receipt)

    def test_alias_skip_cannot_be_approved_by_ok_summary(self):
        with _fixture() as (root, receipt, inventory, log):
            alias = inventory["load_tests_aliases"][0]["execution_id"]
            bad = log.replace(f"({alias}) ... ok", f"({alias}) ... skipped 'not available'").replace("\nOK\n", "\nOK (skipped=1)\n")
            with self.assertRaisesRegex(UnittestResultError, "skip is not permitted"):
                _verify(inventory, bad)
            (root / receipt["tests"]["stderr_log"]).write_bytes(bad.encode())
            receipt["tests"]["stderr_hash"] = protocol.file_hash(root / receipt["tests"]["stderr_log"])
            with self.assertRaisesRegex(PermissionError, "skip is not permitted"):
                verify_regression_evidence(root, receipt)

    def test_legacy_version_keeps_its_original_scope_and_never_adopts_aliases(self):
        with _fixture() as (root, receipt, inventory, log):
            legacy = copy.deepcopy(inventory)
            legacy["schema_version"] = "1.0.0"
            with self.assertRaisesRegex(UnittestResultError, "legacy .* alias evidence"):
                _verify(legacy, log)
            for field in ("load_tests_aliases", "aliases_hash", "method_count", "alias_count"):
                legacy.pop(field)
            legacy["test_count"] = inventory["method_count"]
            legacy["tests_hash"] = protocol.canonical_hash(_ids(legacy))
            with self.assertRaisesRegex(UnittestResultError, "summary count"):
                _verify(legacy, log)
            legacy_log = _log(legacy)
            self.assertEqual("1.0.0", _verify(legacy, legacy_log)["schema_version"])
            receipt["tests"]["inventory_hash"] = _write(root / receipt["tests"]["inventory_path"], legacy)
            receipt["tests"]["test_count"] = legacy["test_count"]
            (root / receipt["tests"]["stderr_log"]).write_bytes(legacy_log.encode())
            receipt["tests"]["stderr_hash"] = protocol.file_hash(root / receipt["tests"]["stderr_log"])
            verify_regression_evidence(root, receipt)
            (root / SOURCE).write_bytes((root / SOURCE).read_bytes() + b"\n# future source\n")
            with self.assertRaisesRegex(PermissionError, "test source changed"):
                verify_regression_evidence(root, receipt)


if __name__ == "__main__":
    unittest.main()
