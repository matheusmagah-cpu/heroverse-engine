"""Current script/voice/identity contract; no codec, voice or network dispatch."""
import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from tests import test_audio_static_qa as qa_fixture
from hero_engine.qa_phase5 import _audio_static_editorial

ROOT=Path(__file__).resolve().parents[1]
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value):path.write_text(json.dumps(value),encoding='utf-8')
def sha(path):return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()

class AudioStaticEditorialTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory(prefix='audio-editorial-')
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.package=self.root/'output/production/current';self.package.mkdir(parents=True)
        (self.root/'schemas').mkdir()
        shutil.copy2(ROOT/'schemas/narrative_script.schema.json',self.root/'schemas')
        original=ROOT/'output/production/audio-reflection-static-v1'
        for name in ('take_plan.json','narrative_script.json','editorial_brief.json',
                     'channel_style_bible.json','creative_direction_decision.json'):
            shutil.copy2(original/name,self.package/name)
        (self.package/'audio').mkdir()
        # Fixture's externally-bound measured-script identity. No fabricated
        # actual voice receipt: production QA separately verifies native PCM.
        write(self.package/'audio/voice_render_manifest.json',{'narrative_script':{
            'sha256':sha(self.package/'narrative_script.json')}})
        decision=read(self.package/'creative_direction_decision.json')
        decision['brief_id']=read(self.package/'editorial_brief.json')['brief_id']
        write(self.package/'creative_direction_decision.json',decision)

    def evaluate(self):return _audio_static_editorial(self.root,self.package)
    def mutate(self,name,change):
        path=self.package/name;value=read(path);change(value);write(path,value)

    def test_real_narrative_and_timing_contract(self):
        result=self.evaluate()
        self.assertTrue(result['hook_pass'])
        self.assertEqual(result['opening_expansion']['measured_end_ms'],38200)
        self.assertEqual(result['opening_expansion']['declared_end_ms'],30000)
        self.assertTrue(result['narrative_pass'])
        self.assertTrue(result['semantic_pass'])
        self.assertTrue(result['identity_pass'])
        self.assertFalse(result['publication_authorized'])

    def test_historical_creative_brief_cannot_approve_current_identity(self):
        self.mutate('creative_direction_decision.json',lambda v:v.update(brief_id='old-brief'))
        self.assertFalse(self.evaluate()['identity_pass'])

    def test_script_changed_without_measured_voice_binding_fails(self):
        self.mutate('narrative_script.json',lambda v:v.update(full_text='borrowed or different narrative'))
        result=self.evaluate()
        self.assertFalse(result['script_matches_measured_voice'])
        self.assertFalse(result['narrative_pass'])

    def test_reordered_spoken_units_fails_coherence(self):
        def change(value):value['takes'][5],value['takes'][6]=value['takes'][6],value['takes'][5]
        self.mutate('take_plan.json',change)
        self.assertFalse(self.evaluate()['semantic_pass'])

    def test_missing_payoff_not_accepted_even_with_fresh_fixture_voice_binding(self):
        self.mutate('narrative_script.json',lambda v:v['sections'].pop())
        self.mutate('audio/voice_render_manifest.json',lambda v:v['narrative_script'].update(
            sha256=sha(self.package/'narrative_script.json')))
        self.assertFalse(self.evaluate()['narrative_pass'])

    def test_changed_hook_clock_fails(self):
        self.mutate('take_plan.json',lambda v:v['takes'][0].update(end_ms=1100))
        self.assertFalse(self.evaluate()['hook_pass'])

    def test_public_qa_refuses_incomplete_editorial_fixture_without_affecting_measured_audio(self):
        owner=qa_fixture.AudioStaticQaTests('test_final_technical_static_hold_not_wrongly_rejected_as_freeze')
        self.addCleanup(owner.doCleanups);owner.setUp()
        owner.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        report,measured=owner.last_result
        gates={row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['NARRATIVE'],'FAIL')
        self.assertEqual(gates['AUDIO'],'PASS')
        self.assertFalse(report['publication_eligible'])
        self.assertIn('static_editorial',measured)
