from __future__ import annotations

import copy
import hashlib
import json
import unittest

from hero_engine.maintenance_unittest_result import (
    UnittestResultError,
    verify_unittest_result,
)


PASS_ID = "tests.test_alpha.AlphaTests.test_ok"
SKIP_ID = (
    "tests.test_scheduled_voice_probe.ScheduledVoiceProbeTests."
    "test_preexisting_sample_symlink_is_never_reused"
)


def _canonical_hash(value: object) -> str:
    raw = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _inventory(*test_ids: str) -> dict:
    grouped: dict[str, list[str]] = {}
    for test_id in test_ids:
        module = ".".join(test_id.split(".")[:2])
        grouped.setdefault(module, []).append(test_id)
    files = [
        {
            "path": module.replace(".", "/") + ".py",
            "content_hash": "sha256:" + "a" * 64,
            "test_ids": ids,
        }
        for module, ids in grouped.items()
    ]
    flat = [test_id for item in files for test_id in item["test_ids"]]
    return {
        "schema_version": "1.0.0",
        "discovery_pattern": "tests/test_*.py",
        "file_count": len(files),
        "test_count": len(flat),
        "tests_hash": _canonical_hash(flat),
        "files": files,
    }


def _runtime_id(test_id: str) -> str:
    return test_id.removeprefix("tests.")


def _verify(inventory: dict, stderr: str, *, stdout: str = "", exit_code: int | None = 0) -> dict:
    return verify_unittest_result(
        inventory=inventory,
        stdout_bytes=stdout.encode("utf-8"),
        stderr_bytes=stderr.encode("utf-8"),
        process_exit_code=exit_code,
    )


class MaintenanceUnittestResultTests(unittest.TestCase):
    def test_complete_verbose_result_reconciles_multiline_description_and_warnings(self) -> None:
        inventory = _inventory(PASS_ID, SKIP_ID)
        stderr = (
            f"test_ok ({_runtime_id(PASS_ID)})\n"
            "A multiline description mentioning subTest behavior. ... [ WARN:0] diagnostic\n"
            "ok\n"
            f"test_preexisting_sample_symlink_is_never_reused ({_runtime_id(SKIP_ID)}) ... "
            "skipped \"file symlink unavailable: [WinError 1314] localized detail\"\n"
            "----------------------------------------------------------------------\n"
            "Ran 2 tests in 1.250s\n\n"
            "OK (skipped=1)\n"
            "[matroska] diagnostic emitted after the unittest terminal\n"
        )
        result = _verify(inventory, stderr)
        self.assertEqual("PASS", result["status"])
        self.assertEqual(1, result["skipped_count"])
        self.assertEqual("ok", result["outcomes"][PASS_ID])
        self.assertEqual("skipped", result["outcomes"][SKIP_ID])
        self.assertTrue(result["process_exit_code_verified"])

    def test_documented_skip_is_optional_when_platform_can_create_symlink(self) -> None:
        inventory = _inventory(SKIP_ID)
        stderr = (
            f"test_preexisting_sample_symlink_is_never_reused ({_runtime_id(SKIP_ID)}) ... ok\n"
            "Ran 1 test in 0.001s\n\nOK\n"
        )
        self.assertEqual("ok", _verify(inventory, stderr)["outcomes"][SKIP_ID])

    def test_nonallowlisted_skip_is_rejected(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = (
            f"test_ok ({_runtime_id(PASS_ID)}) ... skipped \"not available\"\n"
            "Ran 1 test in 0.001s\n\nOK (skipped=1)\n"
        )
        with self.assertRaisesRegex(UnittestResultError, "skip is not permitted"):
            _verify(inventory, stderr)

    def test_documented_test_with_wrong_skip_reason_is_rejected(self) -> None:
        inventory = _inventory(SKIP_ID)
        stderr = (
            f"test_preexisting_sample_symlink_is_never_reused ({_runtime_id(SKIP_ID)}) ... "
            "skipped \"dependency unavailable\"\n"
            "Ran 1 test in 0.001s\n\nOK (skipped=1)\n"
        )
        with self.assertRaisesRegex(UnittestResultError, "skip is not permitted"):
            _verify(inventory, stderr)

    def test_terminal_skip_count_must_match_allowed_results(self) -> None:
        inventory = _inventory(SKIP_ID)
        stderr = (
            f"test_preexisting_sample_symlink_is_never_reused ({_runtime_id(SKIP_ID)}) ... "
            "skipped \"file symlink unavailable: [WinError 1314] detail\"\n"
            "Ran 1 test in 0.001s\n\nOK\n"
        )
        with self.assertRaisesRegex(UnittestResultError, "skip count"):
            _verify(inventory, stderr)

    def test_nonzero_process_exit_cannot_be_overridden_by_canonical_ok(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = f"test_ok ({_runtime_id(PASS_ID)}) ... ok\nRan 1 test in 0.001s\n\nOK\n"
        with self.assertRaisesRegex(UnittestResultError, "exit code"):
            _verify(inventory, stderr, exit_code=7)

    def test_expected_failure_is_not_an_approved_pass(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = (
            f"test_ok ({_runtime_id(PASS_ID)}) ... expected failure\n"
            "Ran 1 test in 0.001s\n\nOK (expected failures=1)\n"
        )
        with self.assertRaisesRegex(UnittestResultError, "terminal result"):
            _verify(inventory, stderr)

    def test_unexpected_success_is_rejected(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = (
            f"test_ok ({_runtime_id(PASS_ID)}) ... unexpected success\n"
            "Ran 1 test in 0.001s\n\nFAILED (unexpected successes=1)\n"
        )
        with self.assertRaisesRegex(UnittestResultError, "terminal result"):
            _verify(inventory, stderr, exit_code=None)

    def test_truncated_transcript_is_rejected(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = f"test_ok ({_runtime_id(PASS_ID)}) ... ok\nRan 1 test in 0.001s\n"
        with self.assertRaisesRegex(UnittestResultError, "terminal result"):
            _verify(inventory, stderr)

    def test_duplicate_summary_or_terminal_is_rejected(self) -> None:
        inventory = _inventory(PASS_ID)
        base = f"test_ok ({_runtime_id(PASS_ID)}) ... ok\nRan 1 test in 0.001s\n\nOK\n"
        with self.assertRaisesRegex(UnittestResultError, "exactly one summary"):
            _verify(inventory, base + "Ran 1 test in 0.001s\n")
        with self.assertRaisesRegex(UnittestResultError, "exactly one terminal"):
            _verify(inventory, base + "OK\n")

    def test_stdout_cannot_supply_or_duplicate_canonical_result_markers(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = f"test_ok ({_runtime_id(PASS_ID)}) ... ok\nRan 1 test in 0.001s\n\nOK\n"
        with self.assertRaisesRegex(UnittestResultError, "appeared on stdout"):
            _verify(inventory, stderr, stdout="Ran 1 test in 0.001s\nOK\n")

    def test_inventory_identity_tamper_and_missing_result_are_rejected(self) -> None:
        inventory = _inventory(PASS_ID)
        stderr = f"test_ok ({_runtime_id(PASS_ID)}) ... ok\nRan 1 test in 0.001s\n\nOK\n"
        tampered = copy.deepcopy(inventory)
        tampered["tests_hash"] = "sha256:" + "0" * 64
        with self.assertRaisesRegex(UnittestResultError, "identity is inconsistent"):
            _verify(tampered, stderr)
        with self.assertRaisesRegex(UnittestResultError, "occurrences"):
            _verify(inventory, "test_other (test_alpha.AlphaTests.test_other) ... ok\nRan 1 test in 0.001s\n\nOK\n")


if __name__ == "__main__":
    unittest.main()
