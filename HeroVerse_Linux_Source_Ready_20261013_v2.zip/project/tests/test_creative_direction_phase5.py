from __future__ import annotations

import json
import hashlib
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.asset_quality_phase5 import _safe_ranges
from hero_engine.continuity import build_visual_continuity_bible
from hero_engine.creative_direction import choose_format_pack, load_format_packs
from hero_engine.policy_phase5 import evaluate_phase5_command
from hero_engine.phase5_integrity_successor_consumer import read_current_integrity_successor
from hero_engine.publication_package_phase5 import build_publication_package
from hero_engine.publisher import build_youtube_video_body
from hero_engine.qa_phase5 import _actual_take_windows
from hero_engine.render_phase5 import _frame_count_for_duration_ms
from hero_engine.take_planner import build_take_plan
from hero_engine.youtube_integration import INTEGRATION_SCOPES, probe_owned_channel


ROOT = Path(__file__).resolve().parents[1]
FIXED_TIME = "2026-09-02T20:00:00+00:00"


def read_json(path: str) -> dict:
    return json.loads((ROOT / path).read_text(encoding="utf-8-sig"))


def validate(schema_path: str, instance: dict) -> None:
    Draft202012Validator(read_json(schema_path)).validate(instance)


class CreativeDirectionPhase5Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.command = read_json("output/production/phase5/pilot-001/central_command.creative_direction.json")
        cls.envelope = read_json("config/operational_envelopes/phase5-zero-cost-v1.json")
        cls.channel_model = read_json("output/modeling/phase4/channel-model-v1/channel_model.json")
        cls.brief = read_json("output/production/phase5/pilot-001/editorial_brief.json")
        cls.manifest = read_json("output/production/phase5/pilot-001/asset_manifest.json")
        cls.packs = load_format_packs(ROOT / "config/format_packs", ROOT / "schemas/format_pack.schema.json")
        cls.pack = cls.packs[0]

    def test_registry_has_exact_materialized_counts(self) -> None:
        registry = read_json("config/visual_style_registry.json")
        validate("schemas/visual_style_registry.schema.json", registry)
        enumerated = sum(len(values) for values in registry["categories"].values())
        self.assertEqual(291, enumerated)
        self.assertEqual(enumerated, registry["total_formats"])
        self.assertEqual(enumerated, sum(registry["capability_counts"].values()))
        self.assertEqual(0, registry["capability_counts"]["SPECIFIED"])
        self.assertEqual(0, registry["capability_counts"]["PROTOTYPED"])
        self.assertEqual(1, registry["capability_counts"]["LIMITED"])
        self.assertEqual(0, registry["capability_counts"]["PRODUCTION_READY"])

    def test_phase5_contract_instances_validate(self) -> None:
        validate("schemas/central_command.schema.json", self.command)
        validate("schemas/operational_envelope.schema.json", self.envelope)
        for name in ("draft", "standard", "premium", "cinematic"):
            validate("schemas/production_quality_profile.schema.json", read_json(f"config/production_quality_profiles/{name}-v1.json"))

    def test_policy_allows_only_zero_cost_local_creative_command(self) -> None:
        result = evaluate_phase5_command(self.command, self.envelope, created_at=FIXED_TIME)
        validate("schemas/phase5_policy_decision.schema.json", result)
        self.assertEqual("AUTOMATIC", result["classification"])
        self.assertEqual("ALLOW", result["decision"])
        self.assertTrue(all(item["status"] == "PASS" for item in result["checks"]))

    def test_policy_blocks_cost_and_protects_publication(self) -> None:
        costly = json.loads(json.dumps(self.command))
        costly["command_id"] = "cmd-costly"
        costly["input"]["external_cost"] = 0.01
        self.assertEqual("BLOCK", evaluate_phase5_command(costly, self.envelope, created_at=FIXED_TIME)["decision"])
        publish = json.loads(json.dumps(self.command))
        publish["command_id"] = "cmd-publish"
        publish["action"] = "PUBLISH_VIDEO"
        publish["input"]["publication_requested"] = True
        result = evaluate_phase5_command(publish, self.envelope, created_at=FIXED_TIME)
        self.assertEqual("PROTECTED", result["classification"])
        self.assertEqual("AWAITING_APPROVAL", result["decision"])

    def test_youtube_connection_is_identity_bound_and_cannot_unlock_publication(self) -> None:
        class Call:
            def __init__(self, value):
                self.value = value

            def execute(self):
                return self.value

        class Channels:
            def list(self, **kwargs):
                if kwargs.get("mine"):
                    return Call({"items": [{
                        "id": "UC-HEROVERSE-TEST",
                        "snippet": {"title": "HeroVerse", "customUrl": "@heroverse74"},
                        "statistics": {"subscriberCount": "265", "videoCount": "21", "viewCount": "2625"},
                    }]})
                self_handle = kwargs.get("forHandle")
                return Call({"items": [{"id": "UC-HEROVERSE-TEST"}]} if self_handle == "heroverse74" else {"items": []})

        class YouTube:
            def channels(self):
                return Channels()

        class Reports:
            def query(self, **kwargs):
                self.query_args = kwargs
                return Call({"rows": [["2026-08-31", 10, 20, 120, 40.0, 1, 0]]})

        class Analytics:
            def reports(self):
                return Reports()

        receipt = probe_owned_channel(
            YouTube(), Analytics(), granted_scopes=INTEGRATION_SCOPES
        )
        validate("schemas/youtube_connection_receipt.schema.json", receipt)
        self.assertEqual("CONNECTED", receipt["status"])
        self.assertTrue(receipt["identity_verified"])
        self.assertEqual("CONFIGURED_BLOCKED", next(
            item for item in receipt["capabilities"] if item["capability"] == "UPLOAD"
        )["status"])
        self.assertFalse(receipt["publication_guard"]["upload_permitted"])
        self.assertFalse(receipt["authorization"]["secret_logged"])

    def test_youtube_connection_fails_closed_on_channel_mismatch(self) -> None:
        class Call:
            def __init__(self, value):
                self.value = value

            def execute(self):
                return self.value

        class Channels:
            def list(self, **kwargs):
                if kwargs.get("mine"):
                    return Call({"items": [{
                        "id": "UC-WRONG",
                        "snippet": {"title": "Wrong Channel", "customUrl": "@wrong"},
                        "statistics": {},
                    }]})
                return Call({"items": [{"id": "UC-HEROVERSE-TEST"}]})

        class YouTube:
            def channels(self):
                return Channels()

        class Analytics:
            def reports(self):
                raise AssertionError("Analytics must not run for a mismatched channel")

        receipt = probe_owned_channel(
            YouTube(), Analytics(), granted_scopes=INTEGRATION_SCOPES
        )
        validate("schemas/youtube_connection_receipt.schema.json", receipt)
        self.assertEqual("IDENTITY_MISMATCH", receipt["status"])
        self.assertFalse(receipt["identity_verified"])
        self.assertEqual("NOT_RUN", receipt["analytics_probe"]["status"])

    def test_publication_package_is_complete_but_fail_closed(self) -> None:
        package = build_publication_package(ROOT)
        validate("schemas/publication_package.schema.json", package)
        self.assertEqual("BLOCKED_PENDING_HUMAN_REVIEW", package["status"])
        self.assertEqual("UCuMF6pJQkyMzaVoAxFL86yA", package["channel"]["channel_id"])
        self.assertEqual("CONNECTED", package["integration"]["connection_status"])
        self.assertTrue(package["integration"]["identity_verified"])
        self.assertFalse(package["publication_policy"]["upload_permitted"])
        self.assertFalse(package["quality_gate"]["publication_eligible"])
        self.assertTrue(package["disclosure"]["contains_synthetic_media"])
        self.assertIn("James 1:22", package["metadata"]["description"])
        self.assertLessEqual(package["thumbnail"]["size_bytes"], 2 * 1024 * 1024)

    def test_real_youtube_receipt_is_connected_and_identity_pinned(self) -> None:
        receipt = read_json("output/integrations/youtube/heroverse/connection-receipt.json")
        validate("schemas/youtube_connection_receipt.schema.json", receipt)
        expected = "UCuMF6pJQkyMzaVoAxFL86yA"
        self.assertEqual("CONNECTED", receipt["status"])
        self.assertTrue(receipt["identity_verified"])
        self.assertEqual(expected, receipt["expected_channel"]["channel_id"])
        self.assertEqual(expected, receipt["observed_channel"]["channel_id"])
        self.assertEqual("@heroverse74", receipt["observed_channel"]["custom_url"].lower())
        self.assertEqual("PASS", receipt["analytics_probe"]["status"])
        self.assertGreater(receipt["analytics_probe"]["row_count"], 0)
        self.assertFalse(receipt["analytics_probe"]["private_values_persisted"])
        self.assertFalse(receipt["authorization"]["secret_logged"])
        self.assertFalse(receipt["publication_guard"]["upload_permitted"])

    def test_youtube_api_body_preserves_disclosure_language_and_audience(self) -> None:
        package = build_publication_package(ROOT)
        metadata = package["metadata"]
        body = build_youtube_video_body({
            "title": metadata["title"],
            "description": metadata["description"],
            "tags": metadata["tags"],
            "category_id": metadata["category_id"],
            "language": metadata["default_language"],
            "audio_language": metadata["default_audio_language"],
            "privacy_status": metadata["privacy_status"],
            "made_for_kids": metadata["made_for_kids"],
            "contains_synthetic_media": package["disclosure"]["contains_synthetic_media"],
        })
        self.assertEqual("private", body["status"]["privacyStatus"])
        self.assertFalse(body["status"]["selfDeclaredMadeForKids"])
        self.assertTrue(body["status"]["containsSyntheticMedia"])
        self.assertEqual("en", body["snippet"]["defaultLanguage"])
        self.assertEqual("en", body["snippet"]["defaultAudioLanguage"])

    def test_limited_pack_is_eligible_for_prototype_and_scoped_production(self) -> None:
        policy = evaluate_phase5_command(self.command, self.envelope, created_at=FIXED_TIME)
        prototype = choose_format_pack(
            command=self.command,
            policy_decision=policy,
            channel_model=self.channel_model,
            brief=self.brief,
            packs=self.packs,
            purpose="PROTOTYPE",
            budget_envelope_id=self.envelope["envelope_id"],
            quality_profile="DRAFT",
            created_at=FIXED_TIME,
        )
        validate("schemas/creative_direction_decision.schema.json", prototype)
        self.assertEqual("SELECT", prototype["decision"])
        self.assertEqual("LIMITED", prototype["candidate_assessments"][0]["capability_status"])
        self.assertGreaterEqual(prototype["candidate_assessments"][0]["selection_score"], 0.75)

        production = choose_format_pack(
            command=self.command,
            policy_decision=policy,
            channel_model=self.channel_model,
            brief=self.brief,
            packs=self.packs,
            purpose="PRODUCTION",
            budget_envelope_id=self.envelope["envelope_id"],
            quality_profile="STANDARD",
            created_at=FIXED_TIME,
        )
        validate("schemas/creative_direction_decision.schema.json", production)
        self.assertEqual("SELECT", production["decision"])
        self.assertEqual("fp-broll-cinematic-narration", production["selected_format_pack"]["format_pack_id"])

    def test_style_bible_and_take_plan_are_schema_valid_and_contiguous(self) -> None:
        policy = evaluate_phase5_command(self.command, self.envelope, created_at=FIXED_TIME)
        decision = choose_format_pack(
            command=self.command,
            policy_decision=policy,
            channel_model=self.channel_model,
            brief=self.brief,
            packs=self.packs,
            purpose="PROTOTYPE",
            budget_envelope_id=self.envelope["envelope_id"],
            quality_profile="DRAFT",
            created_at=FIXED_TIME,
        )
        bible = build_visual_continuity_bible(
            channel_model=self.channel_model,
            format_pack=self.pack,
            asset_manifest=self.manifest,
            created_at=FIXED_TIME,
        )
        validate("schemas/visual_continuity_bible.schema.json", bible)
        beats = [
            {"beat_id": "b01", "start_ms": 0, "end_ms": 1000, "narrative_function": "contradiction", "information": "Prayer is preparation, not an endpoint.", "intended_emotion": "surprise", "semantic_role": "urgency", "action": "storm movement interrupts stillness", "on_screen_text": "AMEN ISN'T THE END", "narration": "Amen isn't the end.", "retention_job": "stop the scroll and confirm contradiction"},
            {"beat_id": "b02", "start_ms": 1000, "end_ms": 3000, "narrative_function": "personal consequence", "information": "The next faithful action reveals the response.", "intended_emotion": "tension", "semantic_role": "decision", "action": "a leading line moves forward", "on_screen_text": "YOUR MOVE REVEALS IT", "narration": "Your next move reveals it.", "retention_job": "make the promise personal"},
            {"beat_id": "b03", "start_ms": 3000, "end_ms": 8000, "narrative_function": "mechanism", "information": "Confidence often follows the first faithful step.", "intended_emotion": "resolve", "semantic_role": "progress", "action": "water or path advances", "on_screen_text": None, "narration": "Do not wait for confidence. It often arrives after the first faithful step.", "retention_job": "deliver first micro-payoff"},
            {"beat_id": "b04", "start_ms": 8000, "end_ms": 12000, "narrative_function": "proof direction", "information": "Prayer changes posture before circumstances.", "intended_emotion": "clarity", "semantic_role": "clarity", "action": "weather opens to a readable horizon", "on_screen_text": None, "narration": "Prayer changes your posture before it changes your circumstances.", "retention_job": "prove the title direction"},
        ]
        windows = [
            {"window": "0_1S", "start_ms": 0, "end_ms": 1000, "promise_function": "contradiction", "evidence_refs": ["brief:0_1S"]},
            {"window": "1_3S", "start_ms": 1000, "end_ms": 3000, "promise_function": "personal consequence", "evidence_refs": ["brief:1_3S"]},
            {"window": "3_8S", "start_ms": 3000, "end_ms": 8000, "promise_function": "mechanism", "evidence_refs": ["brief:3_8S"]},
            {"window": "8_30S", "start_ms": 8000, "end_ms": 12000, "promise_function": "proof direction", "evidence_refs": ["brief:8_30S"]},
        ]
        plan, updated_manifest = build_take_plan(
            channel_id="heroverse74",
            video_id="phase5-test-prototype",
            creative_decision=decision,
            style_bible=bible,
            format_pack=self.pack,
            asset_manifest=self.manifest,
            narrative_beats=beats,
            hook_windows=windows,
            created_at=FIXED_TIME,
        )
        validate("schemas/take_plan.schema.json", plan)
        self.assertEqual([0, 1000, 3000, 8000], [take["start_ms"] for take in plan["takes"]])
        self.assertEqual([1000, 3000, 8000, 12000], [take["end_ms"] for take in plan["takes"]])
        self.assertEqual(4, len(plan["hook_window_coverage"]))
        self.assertTrue(any(asset["used_ranges"] for asset in updated_manifest["assets"]))
        consecutive_origins = [take["asset_origin"].split("#", 1)[0] for take in plan["takes"]]
        self.assertTrue(all(left != right for left, right in zip(consecutive_origins, consecutive_origins[1:])))

        production_decision = {**decision, "purpose": "PRODUCTION", "quality_profile": "STANDARD"}
        production_plan, _ = build_take_plan(
            channel_id="heroverse74",
            video_id="phase6-production-planner-contract",
            creative_decision=production_decision,
            style_bible=bible,
            format_pack=self.pack,
            asset_manifest=self.manifest,
            narrative_beats=beats,
            hook_windows=windows,
            created_at=FIXED_TIME,
        )
        self.assertEqual("STANDARD", production_plan["quality_profile"])
        validate("schemas/take_plan.schema.json", production_plan)

    def test_asset_safe_ranges_do_not_cross_detected_source_edits(self) -> None:
        ranges = _safe_ranges(
            30.0,
            {
                "black_intervals_seconds": [],
                "freeze_intervals_seconds": [],
                "scene_boundary_seconds": [12.0, 23.333],
            },
        )
        self.assertEqual(
            [
                {"start_ms": 2000, "end_ms": 11750},
                {"start_ms": 12250, "end_ms": 23083},
                {"start_ms": 23583, "end_ms": 29500},
            ],
            ranges,
        )
        self.assertFalse(any(item["start_ms"] < 12_000 < item["end_ms"] for item in ranges))
        self.assertFalse(any(item["start_ms"] < 23_333 < item["end_ms"] for item in ranges))

    def test_frame_lock_rejects_unrepresentable_duration_and_maps_actual_boundaries(self) -> None:
        self.assertEqual(195, _frame_count_for_duration_ms(6500))
        with self.assertRaises(ValueError):
            _frame_count_for_duration_ms(6510)
        plan = {"takes": [{"take_id": "t1"}, {"take_id": "t2"}]}
        manifest = {
            "segment_timeline": [
                {"take_id": "t1", "actual_start_ms": 0.0, "actual_end_ms": 1000.0},
                {"take_id": "t2", "actual_start_ms": 1000.0, "actual_end_ms": 3000.0},
            ]
        }
        self.assertEqual(
            [
                {"take_id": "t1", "start_ms": 0.0, "end_ms": 1000.0},
                {"take_id": "t2", "start_ms": 1000.0, "end_ms": 3000.0},
            ],
            _actual_take_windows(plan, manifest),
        )

    def test_materialized_baseline_remains_blocked_while_pack_and_pipeline_are_limited(self) -> None:
        pack = read_json("config/format_packs/fp-broll-cinematic-narration-v1.json")
        pipeline = read_json("config/macro_pipelines/pipeline-clips-longform-v1.json")
        render = read_json("output/production/phase5/pilot-001/render_manifest.json")
        qa = read_json("output/production/phase5/pilot-001/qa/creative_quality_gate_report.json")
        validate("schemas/format_pack.schema.json", pack)
        validate("schemas/macro_pipeline.schema.json", pipeline)
        validate("schemas/render_manifest.schema.json", render)
        validate("schemas/creative_quality_gate_report.schema.json", qa)
        self.assertEqual("LIMITED", pack["capability_status"])
        self.assertTrue(pack["production_allowed"])
        self.assertEqual("LIMITED", pipeline["status"])
        self.assertEqual(4056, render["measurements"]["expected_total_frames"])
        self.assertEqual(0.0, render["measurements"]["maximum_cumulative_drift_ms"])
        self.assertEqual([], [gate for gate in qa["gates"] if gate["status"] == "FAIL"])
        self.assertIn("PUBLICATION", qa["critical_gate_failures"])
        self.assertFalse(qa["publication_eligible"])

    def test_creative_v2_1_contract_is_measured_and_not_subjective(self) -> None:
        treatment = read_json("output/production/phase5/pilot-001/creative-v2/creative_treatment_plan.json")
        metrics = read_json("output/production/phase5/pilot-001/creative-v2/qa/creative_revision_metrics.json")
        validate("schemas/creative_treatment_plan.schema.json", treatment)
        validate("schemas/creative_revision_metrics.schema.json", metrics)
        self.assertEqual("2.1.0", treatment["version"])
        self.assertEqual("PASS", metrics["automatic_status"])
        self.assertTrue(all(item["status"] == "PASS" for item in metrics["checks"]))
        self.assertEqual(13, metrics["asset_runtime"]["unique_asset_count"])
        self.assertLessEqual(metrics["asset_runtime"]["maximum_third_party_share"], 0.2)
        self.assertTrue(metrics["human_review_required"])
        self.assertFalse(metrics["publication_eligible"])

    def test_market_readiness_review_rejects_false_viral_readiness(self) -> None:
        review = read_json("output/production/phase5/pilot-001/creative-v2/qa/market_readiness_review.json")
        validate("schemas/market_readiness_review.schema.json", review)
        self.assertEqual("REJECTED_FOR_PUBLICATION", review["verdict"])
        self.assertFalse(review["independent_human_review_satisfied"])
        self.assertEqual("UNAVAILABLE_BEFORE_PUBLICATION", review["claim_boundary"]["viral_result"])
        self.assertEqual(0, review["measurements"]["caption_track_count"])
        self.assertFalse(review["measurements"]["production_allowed"])
        critical_failures = {
            item["gate"]
            for item in review["gates"]
            if item["critical"] and item["status"] in {"FAIL", "BLOCKED"}
        }
        self.assertTrue({"HOOK_H1_0_1S", "HOOK_H2_1_3S", "PUBLICATION"}.issubset(critical_failures))

    def test_concrete_claims_and_hook_windows_have_exact_evidence(self) -> None:
        metrics = read_json("output/production/phase5/pilot-001/creative-v2/qa/creative_revision_metrics.json")
        checks = {item["check"]: item for item in metrics["checks"]}
        concrete = checks["concrete_claim_visual_coverage"]["observed"]
        self.assertEqual(1.0, concrete["ratio"])
        self.assertEqual(5, concrete["matched"])
        self.assertEqual(5, checks["hook_visual_events_0_8"]["observed"])
        self.assertEqual(8, checks["visual_events_8_30"]["observed"])
        self.assertLessEqual(checks["maximum_pattern_interrupt_gap_ms"]["observed"], 25_000)
        self.assertEqual([], checks["no_adjacent_asset_repeat_outside_hook"]["observed"])

    def test_final_render_has_zero_automatic_technical_failure(self) -> None:
        render = read_json("output/production/phase5/pilot-001/render_manifest.json")
        technical = read_json("output/production/phase5/pilot-001/qa/technical_measurements.json")
        qa = read_json("output/production/phase5/pilot-001/qa/creative_quality_gate_report.json")
        self.assertEqual(render["output"]["content_hash"], technical["render_hash"])
        self.assertEqual(0.0, technical["black_freeze"]["maximum_freeze_seconds"])
        self.assertEqual(0.0, technical["black_freeze"]["maximum_black_seconds"])
        self.assertTrue(technical["rights"]["passed"])
        self.assertEqual("PASS", next(item for item in qa["gates"] if item["gate"] == "TECHNICAL")["status"])
        self.assertEqual("PASS", next(item for item in qa["gates"] if item["gate"] == "RIGHTS")["status"])
        self.assertEqual("BLOCKED", next(item for item in qa["gates"] if item["gate"] == "PUBLICATION")["status"])

    def test_all_final_take_allocations_fit_one_safe_source_range(self) -> None:
        plan = read_json("output/production/phase5/pilot-001/take_plan.json")
        manifest = read_json("output/production/phase5/pilot-001/asset_manifest.json")
        assets = {item["asset_id"]: item for item in manifest["assets"]}
        for take in plan["takes"]:
            origin_path, source_range = take["asset_origin"].rsplit("#t=", 1)
            source_start, source_end = [float(value) * 1000 for value in source_range.split(",", 1)]
            asset_id = Path(origin_path).stem
            self.assertIn(asset_id, assets)
            self.assertTrue(
                any(
                    source_start >= safe["start_ms"] and source_end <= safe["end_ms"]
                    for safe in assets[asset_id]["safe_ranges"]
                ),
                f"{take['take_id']} crosses a blocked source interval",
            )

    def test_phase5_integrity_manifest_matches_every_final_evidence_file(self) -> None:
        package = ROOT / "output" / "production" / "phase5" / "pilot-001"
        manifest = read_json("output/production/phase5/pilot-001/integrity_manifest.json")
        self.assertEqual("SHA-256", manifest["algorithm"])
        self.assertEqual(len(manifest["entries"]), manifest["item_count"])
        self.assertEqual(sum(item["bytes"] for item in manifest["entries"]), manifest["total_bytes"])
        self.assertGreater(manifest["item_count"], 70)
        successor_path = package / "integrity_manifest_successor.json"
        successor = None
        entries = manifest["entries"]
        if successor_path.is_file():
            # The original manifest is historical evidence.  A controlled,
            # authenticated successor may advance only the recorded artifacts;
            # every other historical entry remains byte-identical.
            successor = read_current_integrity_successor(ROOT)
            self.assertFalse(any(successor["authority"].values()))
            successor_raw = json.loads(successor_path.read_text(encoding="utf-8-sig"))
            historical = successor_raw["historical_manifest"]
            historical_raw = (package / "integrity_manifest.json").read_bytes()
            self.assertEqual("sha256:" + hashlib.sha256(historical_raw).hexdigest(), historical["sha256"])
            self.assertEqual(len(historical_raw), historical["size_bytes"])
            # The resident package is forward-only after a successor exists.
            # It is therefore validated exclusively by the current consumer;
            # comparing every mutable alias to the historical receipt would
            # incorrectly reject an already authenticated evolution.
            entries = successor["entries"]

        for entry in entries:
            path = package / entry["artifact"]
            self.assertTrue(path.is_file(), entry["artifact"])
            self.assertEqual(path.stat().st_size, entry["bytes"])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), entry["sha256"])

        if successor is not None:
            # The successor, not a mutable alias of the historical receipt,
            # is authoritative for active Phase 6 input selection.
            self.assertIn("asset_manifest.json", {entry["artifact"] for entry in entries})


if __name__ == "__main__":
    unittest.main()
