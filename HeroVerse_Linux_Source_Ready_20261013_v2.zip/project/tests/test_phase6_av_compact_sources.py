"""Bounded source-inspection tests: one real batch, no render/ASR/OCR.

The explicitly instrumented cases exercise guards, not new media evidence.
No fixture is returned to the operation and no test depends on another test.
"""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_compact_sources as compact


ROOT = Path(__file__).absolute().parents[1]
PRIMITIVES = compact.primitives


def request(state_id="visual-u011-s01"):
    return {"template_id": compact.TEMPLATE_ID, "state_id": state_id,
            "receipt_binding": {"path": compact.CONFIG["directory"] + "/receipt.json",
                                "sha256": compact.CONFIG["receipt_sha256"]}}


class CompactSourcesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Metadata only; this is not a source-inspection result or decoded cache.
        cls.directory = ROOT / compact.CONFIG["directory"]
        cls.receipt = json.loads((cls.directory / "receipt.json").read_bytes())
        cls.layouts = json.loads((cls.directory / "layouts.json").read_bytes())
        projection = json.loads((ROOT / compact.amendment.PROJECTION_BINDING["path"]).read_bytes())
        cls.rows = projection["effective_rows"]
        cls.originals = {item["state_id"]: item for item in cls.receipt["design"]["states"]}

    def source_contract(self, sid):
        row = next(row for row in self.rows if any(state["state_id"] == sid for state in row["states"]))
        state = next(state for state in row["states"] if state["state_id"] == sid)
        return copy.deepcopy((row, state, self.originals[sid]))

    def test_invalid_requests_fail_before_metadata_or_decoder(self):
        variants = [[], {}, [request()] * 257]
        for key, value in (("template_id", "fear-examples-v1"), ("state_id", "visual-u099-s00"),
                           ("state_id", None), ("source_fps", 30)):
            item = request(); item[key] = value; variants.append([item])
        for key, value in (("path", "../receipt.json"), ("sha256", "0" * 64),
                           ("sha256", "sha256:" + compact.CONFIG["receipt_sha256"]), ("size_bytes", 1)):
            item = request(); item["receipt_binding"][key] = value; variants.append([item])
        with patch.object(compact, "_preflight", side_effect=AssertionError("metadata touched")) as metadata:
            with patch.object(PRIMITIVES, "_verify_decoder", side_effect=AssertionError("decoder touched")) as decoder:
                for value in variants:
                    with self.subTest(value=value), self.assertRaises(ValueError):
                        compact.inspect_compact_sources(ROOT, value)
            self.assertEqual(decoder.call_count, 0)
        self.assertEqual(metadata.call_count, 0)

    def test_contract_preserves_two_lexical_anchors_and_hold(self):
        results = {sid: compact._contract(*self.source_contract(sid)) for sid in compact.CONFIG["state_ids"]}
        self.assertEqual(sum(row["timing_kind"] == "UNIT_ENTRY_NOT_BOUND" for row in results.values()), 9)
        self.assertEqual([(sid, row["lexical_target"]["char_start"], row["lexical_target"]["char_end"])
                          for sid, row in results.items() if row["lexical_target"]],
                         [("visual-u011-s01", 14, 19), ("visual-u012-s01", 15, 20)])
        hold = results["visual-u016-s01"]
        self.assertEqual(hold["timing_kind"], "HOLD_CONTINUATION_NOT_TIMED")
        self.assertEqual(hold["continuation_of_state_id"], "visual-u016-s00")
        self.assertEqual(hold["fragment_ids"], ["take-021"])
        self.assertEqual(hold["unit_fragment_ids"], ["take-020", "take-021"])
        self.assertIsNone(hold["lexical_target"])
        self.assertEqual(hold["visual_content"], results["visual-u016-s00"]["visual_content"])

    def test_contract_rejects_copy_origin_reclassification_and_invented_time(self):
        for mutation in ("copy", "narration", "take", "state", "float", "previous", "time", "misclass"):
            row, state, original = self.source_contract("visual-u011-s01")
            if mutation == "copy": state["visual_content"]["literal_copy"][-1] = "Future ruined"
            elif mutation == "narration": row["text"] += " silently"
            elif mutation == "take": original["take_id"] = "take-090"
            elif mutation == "state": original["state_id"] = "visual-u012-s01"
            elif mutation == "float": state["entry"]["char_start"] = 14.0
            elif mutation == "previous": state["entry"]["previous_state_id"] = "visual-u012-s00"
            elif mutation == "time": state["entry"]["observed_sample"] = 100
            else: state["entry"]["kind"] = "UNIT_ENTRY"
            if mutation in {"float", "previous", "time", "misclass"}:
                original["entry"] = copy.deepcopy(state["entry"])
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                compact._contract(row, state, original)
        for sid in ("visual-u010-s00", "visual-u016-s01"):
            row, state, original = self.source_contract(sid)
            state["entry"]["char_start"] = 0; original["entry"] = copy.deepcopy(state["entry"])
            with self.subTest(sid=sid), self.assertRaises(ValueError):
                compact._contract(row, state, original)

    def test_svg_and_column_major_layout_reject_foreign_content(self):
        sid = "visual-u011-s01"
        raw = (self.directory / (sid + ".svg")).read_bytes()
        layout = self.layouts[sid]
        compact._svg(raw, layout)
        compact.amendment._validate_layout(layout, "What happened", "")
        variants = [raw.replace(b"<rect ", b'<rect onclick="run()" ', 1),
                    raw.replace(b'width="774"', b'width="1774"', 1),
                    raw.replace(b">What happened<", b">Already ruined<"),
                    raw.replace(b'font-size="64"', b'font-size="40"', 1),
                    raw.replace(b"</svg>", b"<image href='https://invalid.example/a'/></svg>"),
                    b"<!DOCTYPE svg>" + raw]
        for value in variants:
            with self.subTest(value=value[:70]), self.assertRaises((ValueError, compact.ElementTree.ParseError)):
                compact._svg(value, layout)
        for mutation in ("reverse", "position", "caption_lane", "words", "float"):
            values = copy.deepcopy(layout)
            if mutation == "reverse": values.reverse()
            elif mutation == "position": values[1]["bounds"][0] = 1028
            elif mutation == "caption_lane": values[1]["bounds"][3] = 900
            elif mutation == "words": values[1]["words"] = 9
            else: values[1]["baseline_y"] = 612.0
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                compact.amendment._validate_layout(values, "What happened", "")

    def test_inventory_missing_extra_hash_drift_and_hold_are_blocked(self):
        actual = list(self.directory.iterdir())
        path_iterdir = Path.iterdir
        for entries in (actual[:-1], [*actual, self.directory / "extra.json"]):
            with self.subTest(entries=len(entries)):
                def listing(path):
                    return iter(entries) if path == self.directory else path_iterdir(path)
                with patch.object(Path, "iterdir", listing), self.assertRaisesRegex(ValueError, "inventory"):
                    compact._inventory(PRIMITIVES._Reader(ROOT), self.receipt)
        receipt = copy.deepcopy(self.receipt)
        receipt["artifact_sha256"]["visual-u010-s00.svg"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            compact._inventory(PRIMITIVES._Reader(ROOT), receipt)
        reader = PRIMITIVES._Reader(ROOT)
        real_read = reader.read
        def changed_hold(name, expected):
            value = real_read(name, expected)
            # Explicit post-read instrumentation; no source bytes are written.
            return value + b"different" if name.endswith("visual-u016-s01.png") else value
        with patch.object(reader, "read", changed_hold), self.assertRaisesRegex(ValueError, "HOLD"):
            compact._inventory(reader, self.receipt)

    def test_strict_json_and_external_metadata_pin(self):
        for raw in (b'{"n":1,"n":2}', b'{"n":NaN}', b'{"n":1e999}'):
            class FixtureReader:
                def read(self, _path, _sha): return raw
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                compact._read_json(FixtureReader(), {"path": "fixture.json", "sha256": "0" * 64})
        with patch.object(PRIMITIVES, "_verify_decoder", side_effect=AssertionError("decode too soon")) as decoder:
            with patch.object(compact, "REFERENCE", {**compact.REFERENCE, "sha256": "0" * 64}):
                with self.assertRaisesRegex(ValueError, "hash mismatch"):
                    compact.inspect_compact_sources(ROOT, [request()])
        self.assertEqual(decoder.call_count, 0)

    def test_real_batch_twelve_files_eleven_decodes_no_authority_or_effect(self):
        before = {path.name: PRIMITIVES._sha(path.read_bytes()) for path in self.directory.iterdir()}
        real_png = PRIMITIVES._png
        with patch("subprocess.Popen", side_effect=AssertionError("no subprocess allowed")):
            with patch("socket.create_connection", side_effect=AssertionError("no network allowed")):
                with patch.object(PRIMITIVES, "_png", wraps=real_png) as decode:
                    proofs = compact.inspect_compact_sources(ROOT, [request(sid) for sid in compact.CONFIG["state_ids"]])
        self.assertEqual(decode.call_count, 11)
        self.assertEqual(len(proofs), 12)
        self.assertEqual(len({proof["asset_binding"]["path"] for proof in proofs}), 12)
        self.assertEqual(len({proof["content_sha256"] for proof in proofs}), 11)
        for proof in proofs:
            self.assertEqual((proof["media_kind"], proof["width"], proof["height"], proof["mode"],
                              proof["opacity"], proof["source_frame_count"]),
                             ("STATIC_IMAGE", 1920, 1080, "RGB", "OPAQUE", 1))
            self.assertEqual((proof["source_start_frame"], proof["source_end_frame"]), (0, 1))
            self.assertEqual((proof["state_count"], proof["unique_content_count"], proof["lineage_count"]), (12, 11, 1))
            self.assertEqual(proof["lineage_id"], compact.CONFIG["lineage_id"])
            self.assertEqual(proof["authority"], compact.AUTHORITY)
            self.assertTrue(all(value is False for value in proof["authority"].values()))
            self.assertTrue(proof["source_technically_verified"])
            self.assertFalse(proof["source_ready"])
            self.assertFalse(proof["global_schedule_created"])
            self.assertFalse(proof["calibrated_timing_available"])
            self.assertEqual(proof["technical_cost_brl"], 0)
            self.assertIsNone(proof["observed_sample"])
            self.assertIsNone(proof["video_frame"])
            for key in ("fps", "source_fps", "duration", "source_duration_ms", "safe_ranges_ms"):
                self.assertNotIn(key, proof)
            dependencies = {item["path"]: item for item in proof["dependency_bindings"]}
            for name, digest in compact.EXTERNAL_DEPENDENCY_PINS.items():
                self.assertEqual(dependencies[name]["sha256"], digest)
                self.assertGreater(dependencies[name]["size_bytes"], 0)
            for name, digest in compact.IMPLEMENTATION_PINS.items():
                self.assertEqual(dependencies[str(ROOT / name)]["sha256"], digest)
            self.assertEqual(dependencies[str(ROOT / compact.REFERENCE["path"])]["sha256"], compact.REFERENCE["sha256"])
            self.assertFalse(any(item["path"].endswith((".wav", ".mp4")) for item in dependencies.values()))
            self.assertEqual(set(proof["asset_binding"]), {"path", "sha256", "size_bytes"})
        hold = next(proof for proof in proofs if proof["state_id"] == "visual-u016-s01")
        self.assertEqual(hold["equivalent_state_ids"], ["visual-u016-s00", "visual-u016-s01"])
        self.assertEqual(hold["canonical_content_state_id"], "visual-u016-s00")
        self.assertEqual(before, {path.name: PRIMITIVES._sha(path.read_bytes()) for path in self.directory.iterdir()})

    def test_final_dependency_drift_blocks_without_another_decode(self):
        # Measurement fixture only. The real decoder is exercised once above.
        measurement = {"width": 1920, "height": 1080, "mode": "RGB", "opacity": "OPAQUE", "source_frame_count": 1}
        changed = {"armed": False}
        original_read = Path.read_bytes
        target = self.directory / "visual-u010-s00.png"
        def read(path):
            raw = original_read(path)
            if changed["armed"] and path == target:
                return bytes([raw[0] ^ 1]) + raw[1:]
            return raw
        def fixture_measure(_raw, _dimensions):
            changed["armed"] = True
            return copy.deepcopy(measurement)
        with patch.object(Path, "read_bytes", read), patch.object(PRIMITIVES, "_png", fixture_measure):
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                compact.inspect_compact_sources(ROOT, [request()])

    def test_decoder_rejection_is_not_reported_as_source_success(self):
        # Explicit decoder-failure seam, not a synthesized APNG or rerender.
        with patch.object(PRIMITIVES, "_png", side_effect=ValueError("fixture: APNG/alpha/dimensions rejected")) as decoder:
            with patch.object(PRIMITIVES, "recheck_static_dependencies", side_effect=AssertionError("no proof yet")) as final:
                with self.assertRaisesRegex(ValueError, "fixture: APNG"):
                    compact.inspect_compact_sources(ROOT, [request()])
        self.assertEqual(decoder.call_count, 1)
        self.assertEqual(final.call_count, 0)

    def test_verifier_reinspects_and_rejects_candidate_drift(self):
        # Verifier orchestration fixture; never passed to the live operation.
        expected = {"state_id": "visual-u011-s01", "source_frame_count": 1,
                    "authority": {"publication_authorized": False}, "technical_cost_brl": 0}
        arguments = request()
        with patch.object(compact, "inspect_compact_source", return_value=expected) as inspect:
            self.assertEqual(compact.verify_compact_source(copy.deepcopy(expected), ROOT, **arguments), expected)
            inspect.assert_called_once_with(ROOT, **arguments)
            for key, value in (("source_frame_count", 1.0), ("technical_cost_brl", 1),
                               ("authority", {"publication_authorized": True}), ("source_fps", 30)):
                candidate = copy.deepcopy(expected); candidate[key] = value
                with self.subTest(key=key), self.assertRaises(ValueError):
                    compact.verify_compact_source(candidate, ROOT, **arguments)


if __name__ == "__main__":
    unittest.main()
