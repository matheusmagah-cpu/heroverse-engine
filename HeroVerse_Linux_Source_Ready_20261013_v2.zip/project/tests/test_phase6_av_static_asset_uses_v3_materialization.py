"""Bounded transaction fixtures only: no real V3, source, OCR or rights batch.

All commits in this suite occur in isolated synthetic temporary roots. These
prove orchestration/immutability, not media, rights or production admission.
"""
import copy
from contextlib import contextmanager
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from hero_engine import phase6_av_static_sources as sources

ROOT = Path(__file__).absolute().parents[1]
RUNNER = ROOT / "output/qa/phase6/diagnostics/test-questions-v1/build_static_asset_uses_v3.py"
spec = importlib.util.spec_from_file_location("static_uses_v3_materialization_fixture_harness", RUNNER)
materialize = importlib.util.module_from_spec(spec)
spec.loader.exec_module(materialize)


class StaticAssetUsesV3MaterializationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="uses-v3-materialization-SYNTHETIC-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.pins = {}
        for name in materialize.CODE_PATHS:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            raw = ("SYNTHETIC NONEXECUTABLE CODE PIN FIXTURE " + name).encode()
            path.write_bytes(raw)
            self.pins[name] = sources._sha(raw)
        self.fixed = {name: self.pins[name] for name in materialize.FIXED_PINS}
        self.directory = self.root / materialize.BASE
        self.input = self.directory / "input.json"
        self.inspection = self.directory / "inspection.json"
        self.receipt = self.directory / "receipt.json"
        self.claim = self.directory / "claim.json"
        self.dependency = self.root / "synthetic-source-dependency.json"
        self.dependency.write_bytes(sources._canonical({"fixture_only": True, "not_media": True}))
        self.document = {"fixture_only": True, "kind": "NOT_AN_OPERATIONAL_USE_MANIFEST",
                         "source_bindings": {"synthetic_source": "explicit fixture only"}}

    def _bound(self, path):
        raw = path.read_bytes()
        return {"path": str(path), "sha256": sources._sha(raw), "size_bytes": len(raw)}

    def _proof(self, binding):
        value = {"fixture_only": True, "version": "phase6-av-static-asset-uses-v3",
            "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
            "channel_id": sources.CHANNEL, "video_id": "video-002", "input_binding": copy.deepcopy(binding),
            "source_bindings": copy.deepcopy(self.document["source_bindings"]),
            "source_count": 27, "use_count": 29, "unique_png_content_count": 26, "lineage_count": 3,
            "sources": [{"source_id": "fixture-source-" + str(i), "asset_binding": {"sha256": f"{i % 26:064x}"},
                         "lineage_id": "fixture-lineage-" + str(i % 3)} for i in range(27)],
            "uses": [{"visual_state_id": "fixture-state-" + str(i)} for i in range(29)],
            "remaining_unbound_visual_state_ids": ["fixture-state-" + str(i) for i in range(29, 100)],
            "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
            "authority": dict(materialize.AUTHORITY), "technical_cost_brl": 0,
            "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
            "v2_replay_evidence": {"image_decode_calls": 0, "rights_evaluation_calls": 0},
            "question_rights_replay_evidence": {"current_source_batch_count": 1, "new_editorial_decision_count": 0},
            "dependency_bindings": [self._bound(self.dependency), self._bound(self.input)]}
        value["inspection_id"] = "static-asset-uses-v3-" + sources._sha(sources._canonical(value))[:24]
        return value

    def _inspect(self, root, *, binding):
        self.assertEqual(root, self.root)
        self.assertTrue(self.claim.exists())
        self.assertEqual(self.input.read_bytes(), sources._canonical(self.document))
        self.assertFalse(self.inspection.exists())
        self.assertFalse(self.receipt.exists())
        return self._proof(binding)

    def _source_recheck(self, root, proofs):
        self.assertEqual(root, self.root)
        self.assertEqual(len(proofs), 1)
        self.assertTrue(proofs[0]["fixture_only"])
        reader = sources._Reader(root)
        for item in proofs[0]["dependency_bindings"]:
            self.assertEqual(len(reader.read_path(Path(item["path"]), item["sha256"])), item["size_bytes"])

    @contextmanager
    def environment(self, *, inspect=None, proposed=None, recheck=None):
        fake = SimpleNamespace(
            proposed_static_asset_uses=Mock(side_effect=proposed or (lambda _root: copy.deepcopy(self.document))),
            inspect_static_asset_uses=Mock(side_effect=inspect or self._inspect),
            recheck_asset_use_dependencies=Mock(side_effect=recheck or self._source_recheck))
        with patch.object(materialize, "ROOT", self.root), patch.object(materialize, "FIXED_PINS", self.fixed), \
             patch.object(materialize, "_load_uses", return_value=fake), \
             patch.object(sources, "recheck_static_dependencies", side_effect=AssertionError("old 16MiB sink forbidden")):
            yield fake

    def test_preflight_and_pure_bundle_have_no_effect_and_no_source_inspection(self):
        before = sorted(str(path) for path in self.root.rglob("*"))
        with self.environment() as fake:
            result = materialize.preflight(code_pins=self.pins)
        fake.proposed_static_asset_uses.assert_called_once_with(self.root)
        fake.inspect_static_asset_uses.assert_not_called()
        fake.recheck_asset_use_dependencies.assert_not_called()
        self.assertEqual(result["mode"], "PREFLIGHT_ONLY_NO_WRITE")
        self.assertEqual(result["input_binding"], {"path": materialize.BASE + "/input.json",
            "sha256": sources._sha(sources._canonical(self.document))})
        self.assertEqual(result["bundle_binding"], materialize.bundle_binding(self.document))
        self.assertEqual(result["bundle_binding"]["sha256"], "sha256:" + result["input_binding"]["sha256"])
        self.assertEqual(before, sorted(str(path) for path in self.root.rglob("*")))

    def test_external_code_pins_and_commit_types_fail_before_proposal_or_effects(self):
        variants = [({}, True), ({**self.pins, "unexpected": "0" * 64}, True),
            ({**self.pins, materialize.RUNNER: "0" * 64}, True),
            ({**self.pins, materialize.USES: "0" * 64}, True), (self.pins, 1), (self.pins, None)]
        for pins, commit in variants:
            with self.subTest(pins=list(pins), commit=commit), self.environment() as fake:
                with self.assertRaises(ValueError):
                    materialize.run(code_pins=pins, commit=commit)
                fake.proposed_static_asset_uses.assert_not_called()
                fake.inspect_static_asset_uses.assert_not_called()
            self.assertFalse(self.directory.exists())

    def test_existing_empty_partial_complete_or_corrupt_namespace_blocks_before_proposal(self):
        self.directory.mkdir(parents=True)
        for name in (None, "claim.json", "input.json", "inspection.json", "receipt.json"):
            if name:
                (self.directory / name).write_bytes(b"explicit corrupted synthetic checkpoint")
            before = {path.name: path.read_bytes() for path in self.directory.iterdir()}
            for commit in (False, True):
                with self.environment() as fake, self.assertRaisesRegex(ValueError, "namespace exists"):
                    materialize.run(code_pins=self.pins, commit=commit)
                fake.proposed_static_asset_uses.assert_not_called()
                fake.inspect_static_asset_uses.assert_not_called()
            self.assertEqual(before, {path.name: path.read_bytes() for path in self.directory.iterdir()})

    def test_fixture_commit_inspects_once_after_input_and_closes_complete_dependency_receipt(self):
        check_snapshots = []
        def recheck(root, proofs):
            check_snapshots.append({path.name for path in self.directory.iterdir()})
            self._source_recheck(root, proofs)
        with self.environment(recheck=recheck) as fake:
            result = materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_called_once()
        fake.proposed_static_asset_uses.assert_called_once()
        self.assertEqual({path.name for path in self.directory.iterdir()}, {"claim.json", "input.json", "inspection.json", "receipt.json"})
        self.assertTrue(any("receipt.json" not in names for names in check_snapshots))
        self.assertIn("receipt.json", check_snapshots[-1])
        receipt = sources._json(self.receipt.read_bytes())
        self.assertEqual((receipt["kind"], receipt["version"], receipt["status"]),
                         (materialize.KIND, materialize.VERSION, materialize.STATUS))
        self.assertEqual({key: receipt[key] for key in materialize.COUNTS}, materialize.COUNTS)
        self.assertEqual(receipt["implementation_pins"], self.pins)
        self.assertEqual(receipt["inspection_calls"], 1)
        self.assertEqual(receipt["question_source_batch_count"], 1)
        self.assertTrue(all(value is False for value in receipt["authority"].values()))
        self.assertEqual(receipt["technical_cost_brl"], 0)
        self.assertFalse(result["publication_authorized"])
        self.assertEqual(result["sha256"], sources._sha(self.receipt.read_bytes()))
        self.assertGreaterEqual(receipt["duration_seconds"], 0)
        self.assertLessEqual(receipt["started_at"], receipt["completed_at"])
        dependencies = {item["path"]: item for item in receipt["dependency_bindings"]}
        self.assertNotIn(str(self.receipt), dependencies)
        for path in (self.input, self.claim, self.inspection, self.dependency, *(self.root / name for name in materialize.CODE_PATHS)):
            self.assertEqual(dependencies[str(path)], self._bound(path))
        for key, path in (("input_binding", self.input), ("inspection_binding", self.inspection), ("claim_binding", self.claim)):
            self.assertEqual(receipt[key], {"path": path.relative_to(self.root).as_posix(), "sha256": sources._sha(path.read_bytes())})

    def test_inspection_failure_preserves_claim_input_and_blocks_every_retry(self):
        def failure(*_args, **_kwargs): raise ValueError("synthetic inspection rejection")
        with self.environment(inspect=failure) as fake, self.assertRaisesRegex(ValueError, "inspection rejection"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_called_once()
        self.assertEqual({path.name for path in self.directory.iterdir()}, {"claim.json", "input.json"})
        original = self.input.read_bytes()
        with self.environment() as fake, self.assertRaisesRegex(ValueError, "BLOCKED"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.proposed_static_asset_uses.assert_not_called()
        self.assertEqual(self.input.read_bytes(), original)

    def test_claim_race_loses_before_input_or_source_work(self):
        original = Path.mkdir
        def racing_mkdir(path, *args, **kwargs):
            if path == self.directory:
                original(path)
                raise FileExistsError("synthetic competing exclusive claim")
            return original(path, *args, **kwargs)
        with self.environment() as fake, patch.object(Path, "mkdir", racing_mkdir), self.assertRaises(FileExistsError):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_not_called()
        self.assertEqual(list(self.directory.iterdir()), [])

    def test_late_code_drift_after_proposal_fails_before_claim(self):
        def proposed(_root):
            path = self.root / materialize.RUNNER
            path.write_bytes(path.read_bytes() + b"synthetic late code change")
            return copy.deepcopy(self.document)
        with self.environment(proposed=proposed) as fake, self.assertRaisesRegex(ValueError, "hash mismatch"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_not_called()
        self.assertFalse(self.directory.exists())

    def test_changed_input_or_claim_after_inspection_cannot_persist_a_proof(self):
        for target_name in ("input.json", "claim.json"):
            with self.subTest(target=target_name):
                # Each instrumented failure gets its own fresh version namespace.
                with tempfile.TemporaryDirectory(prefix="synthetic-subroot-", dir=self.root) as sub:
                    target_base = Path(sub).relative_to(self.root).as_posix() + "/transaction"
                    original_base = materialize.BASE
                    with patch.object(materialize, "BASE", target_base):
                        self.directory = self.root / target_base
                        self.input, self.claim = self.directory / "input.json", self.directory / "claim.json"
                        self.inspection, self.receipt = self.directory / "inspection.json", self.directory / "receipt.json"
                        def drift(root, *, binding):
                            proof = self._inspect(root, binding=binding)
                            path = self.directory / target_name
                            path.write_bytes(path.read_bytes() + b"synthetic late drift")
                            return proof
                        with self.environment(inspect=drift) as fake, self.assertRaisesRegex(ValueError, "hash mismatch"):
                            materialize.run(code_pins=self.pins, commit=True)
                        self.assertFalse(self.inspection.exists())
                        self.assertFalse(self.receipt.exists())
                    self.assertEqual(materialize.BASE, original_base)

    def test_scope_rejects_numeric_authority_population_identity_and_extra_batch_claims(self):
        self.directory.mkdir(parents=True)
        self.input.write_bytes(sources._canonical(self.document))
        binding = {"path": materialize.BASE + "/input.json", "sha256": sources._sha(self.input.read_bytes())}
        context = {"input_binding": binding, "document": self.document}
        original = self._proof(binding)
        mutations = [lambda p: p.update(use_count=29.0), lambda p: p.update(source_ready=True),
            lambda p: p.update(calibrated_timing_available=True), lambda p: p.update(technical_cost_brl=False),
            lambda p: p["authority"].update(publication=True), lambda p: p["sources"].pop(),
            lambda p: p["remaining_unbound_visual_state_ids"].pop(),
            lambda p: p["remaining_unbound_visual_state_ids"].__setitem__(0, p["uses"][0]["visual_state_id"]),
            lambda p: p.update(inspection_id="forged"),
            lambda p: p["question_rights_replay_evidence"].update(current_source_batch_count=2),
            lambda p: p["v2_replay_evidence"].update(rights_evaluation_calls=1)]
        for mutate in mutations:
            value = copy.deepcopy(original)
            mutate(value)
            with self.assertRaises(ValueError):
                materialize._scope(value, context)

    def test_failure_publishing_receipt_keeps_inspection_without_reinspection_or_overwrite(self):
        immutable = materialize._immutable
        def failure(path, raw):
            if path.name == "receipt.json": raise OSError("synthetic receipt persistence failure")
            return immutable(path, raw)
        with self.environment() as fake, patch.object(materialize, "_immutable", side_effect=failure), self.assertRaises(OSError):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_called_once()
        self.assertTrue(self.inspection.exists())
        original = self.inspection.read_bytes()
        with self.environment() as fake, self.assertRaisesRegex(ValueError, "BLOCKED"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_not_called()
        self.assertEqual(original, self.inspection.read_bytes())
        self.assertFalse(self.receipt.exists())

    def test_post_receipt_source_or_inventory_drift_prevents_success_return(self):
        def drift(root, proofs):
            if self.receipt.exists():
                self.dependency.write_bytes(self.dependency.read_bytes() + b"synthetic final drift")
            self._source_recheck(root, proofs)
        with self.environment(recheck=drift) as fake, self.assertRaisesRegex(ValueError, "hash mismatch"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_called_once()
        self.assertTrue(self.receipt.exists())  # Preserved unreturned checkpoint, not an externally authorized success.
        with self.environment() as fake, self.assertRaisesRegex(ValueError, "BLOCKED"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.proposed_static_asset_uses.assert_not_called()

    def test_unknown_file_after_receipt_and_receipt_byte_drift_fail_final_close(self):
        immutable = materialize._immutable
        def extra(path, raw):
            immutable(path, raw)
            if path.name == "receipt.json":
                (self.directory / "unrecognized-partial.json").write_bytes(b"synthetic intruder")
        with self.environment() as fake, patch.object(materialize, "_immutable", side_effect=extra), self.assertRaisesRegex(ValueError, "inventory"):
            materialize.run(code_pins=self.pins, commit=True)
        fake.inspect_static_asset_uses.assert_called_once()
        self.assertTrue((self.directory / "unrecognized-partial.json").exists())

    def test_immutable_refuses_identical_existing_output_and_preserves_failed_partial(self):
        self.directory.mkdir(parents=True)
        self.input.write_bytes(b"same synthetic bytes")
        with self.environment(), self.assertRaisesRegex(ValueError, "already exists"):
            materialize._immutable(self.input, b"same synthetic bytes")
        self.assertEqual(self.input.read_bytes(), b"same synthetic bytes")
        with self.environment(), patch.object(materialize.os, "link", side_effect=FileExistsError("synthetic publication race")), self.assertRaises(FileExistsError):
            materialize._immutable(self.claim, b"new synthetic bytes")
        self.assertFalse(self.claim.exists())
        partials = list(self.directory.glob(".claim.json.partial-*"))
        self.assertEqual(len(partials), 1)
        self.assertEqual(partials[0].read_bytes(), b"new synthetic bytes")


if __name__ == "__main__":
    unittest.main()
