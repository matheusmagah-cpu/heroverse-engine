"""T20 composed paused entry; synthetic roots, real proof parser and migration.

Only host/scheduler/process/resource observation is simulated. Native mutex and
file protection, SQL on captured copies, schema validation, derivation, staging,
commit, rollback and proof authentication execute their production functions.
"""
from __future__ import annotations

import copy
import io
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import closing, redirect_stdout
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

import hero_engine.maintenance_protocol as p
import hero_engine.maintenance_paused_application as a
import hero_engine.maintenance_unittest_result as v
import tests.test_paused_maintenance_cancellation as cancellation
import tests.test_phase6_control_cycle as cycle
import tests.test_phase6_reporting as reporting
import tests.test_paused_maintenance_capture_cancellation as capture_tests

ROOT = Path(__file__).resolve().parents[1]
HOST = {"task_name": a.TASK, "task_state": "Disabled", "task_enabled": False,
        "automation_paused": True, "automation_hash": "sha256:" + "a" * 64, "executors": []}
RESOURCES = {"available_ram_bytes": 8 * 1024**3, "output_free_bytes": 30 * 1024**3,
             "temp_free_bytes": 30 * 1024**3, "cpu_load_percent": 70.0}


def scenario(name):
    def mark(method):
        method.fixture_scenario = name
        return method
    return mark


class HostObserverClassificationTests(unittest.TestCase):
    """Execute the production PowerShell classifier, without OS mutations."""

    def _classify(self, commands):
        completed = type("Completed", (), {"stdout": json.dumps({
            "task_name": a.TASK, "task_state": "Disabled", "task_enabled": False,
            "executors": []}).encode("utf-8")})()
        with tempfile.TemporaryDirectory(dir=ROOT / "output/runtime/gestor-central/maintenance-runs") as directory:
            home = Path(directory)
            automation = home / ".codex/automations/hero-engine-rotina-di-ria/automation.toml"
            automation.parent.mkdir(parents=True)
            automation.write_text('status = "PAUSED"\n', encoding="utf-8")
            with patch.object(a.subprocess, "run", return_value=completed) as observed, \
                    patch.object(a.Path, "home", return_value=home):
                a._host_observation(home)
            script = observed.call_args.args[0][-1]
        function = script.split("$all=@", 1)[0]
        payload = json.dumps(commands).replace("'", "''")
        probe = function + "\n$rows=ConvertFrom-Json '" + payload + "'; " + \
            "@($rows | ForEach-Object { Test-ProvenReadOnlyObserver $_ }) | ConvertTo-Json -Compress"
        result = subprocess.run([str(Path(os.environ["SystemRoot"]) /
            "System32/WindowsPowerShell/v1.0/powershell.exe"),
            "-NoProfile", "-NonInteractive", "-Command", probe],
            capture_output=True, timeout=20, check=True)
        self.assertEqual(b"", result.stderr)
        return json.loads(result.stdout)

    def test_read_only_reference_and_comment_are_not_invocations(self):
        commands = [
            'pwsh.exe -NoProfile -Command "Get-Content hero_engine/central_manager_phase5.py"',
            'pwsh.exe -NoProfile -Command "Start-Sleep -Seconds 1 # central_manager_phase5"',
            'pwsh.exe -NoProfile -Command "$label = \'central_manager_phase5\'; Write-Output $label"',
        ]
        self.assertEqual([True] * len(commands), self._classify([
            {"Name": "pwsh.exe", "CommandLine": command} for command in commands]))

    def test_operational_dynamic_and_uncertain_commands_remain_blocked(self):
        commands = [
            'pwsh.exe -Command "Get-Content hero_engine/central_manager_phase5.py"',
            'pwsh.exe -NoProfile -Command "& scripts/daily.ps1"',
            'pwsh.exe -NoProfile -Command "python -m hero_engine.central_manager_phase5"',
            'pwsh.exe -NoProfile -Command "Start-Process python -ArgumentList central_manager_phase5"',
            'pwsh.exe -NoProfile -Command "& $command # central_manager_phase5"',
            'pwsh.exe -NoProfile -Command "Get-Content central_manager_phase5 > changed.json"',
            'pwsh.exe -NoProfile -Command "[IO.File]::Delete(\'central_manager_phase5\')"',
            'pwsh.exe -NoProfile -File scripts/daily.ps1',
            'pwsh.exe -NoProfile -File scripts/daily.ps1 -Command "Get-Content central_manager_phase5"',
            'pwsh.exe -NoProfile -f scripts/daily.ps1 -Command "Get-Content central_manager_phase5"',
            'pwsh.exe -NoProfile -EncodedCommand not_a_read_only_attestation',
            'pwsh.exe -NoProfile -Command "function Get-Content { Start-Process python }; Get-Content central_manager_phase5"',
        ]
        self.assertEqual([False] * len(commands), self._classify([
            {"Name": "pwsh.exe", "CommandLine": command} for command in commands]))


class StoppedManagerIdentityTests(unittest.TestCase):
    """Canonical PID cleanup, with only host/process observation simulated."""
    def setUp(self):
        owner=tempfile.TemporaryDirectory(dir=ROOT/'output/runtime/gestor-central/maintenance-runs',prefix='stopped-manager-')
        self.addCleanup(owner.cleanup);self.root=Path(owner.name)
        self.runtime=self.root/p.RUNTIME;self.runtime.mkdir(parents=True)
        self.pid=self.runtime/'manager.pid'
        (self.root/'schemas').mkdir()
        shutil.copy2(ROOT/'schemas/central_manager_lock.schema.json',self.root/'schemas')
        self.lock={'schema_version':'1.0.0','lock_id':'gestor-central-heroverse-phase5-singleton-v1',
            'state':'RELEASED','holder_pid':4242,'holder_started_at':'2026-09-08T10:00:00Z',
            'heartbeat_at':'2026-09-08T11:00:00Z','lease_seconds':60,'lease_expires_at':'2026-09-08T11:01:00Z',
            'released_at':'2026-09-08T11:00:01Z','mechanism':'windows_byte_range_lock',
            'lock_file':'output/runtime/gestor-central/manager.lock','technical_cost_brl':0}
        self.write_lock()
        host=patch.object(a,'_host_observation',return_value=copy.deepcopy(HOST))
        self.host=host.start();self.addCleanup(host.stop)
        absent=patch.object(p,'_paused_cancel_absent',return_value=None)
        self.absent=absent.start();self.addCleanup(absent.stop)
        for relative in (p.RUNTIME/'PAUSE',p.RUNTIME/'manager.lock',Path('data/hero_engine.db'),
                         Path('output/production/phase5/pilot-001/integrity_manifest.json'),
                         Path('output/production/phase6/shared-assets/asset_manifest.json')):
            path=self.root/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'protected fixture')

    def write_lock(self):
        (self.runtime/'manager-lock.json').write_text(json.dumps(self.lock),encoding='utf-8')

    def test_absent_pid_requires_released_expired_lock_and_dead_holder(self):
        host=a._check_host(self.root)
        self.assertTrue(host['manager_pid_file_absent'])
        self.absent.assert_called_with(4242,'MANAGER')
        paths=a._operational_paths(self.root)
        self.assertNotIn(p.RUNTIME/'manager.pid',paths)
        self.assertIn(p.RUNTIME/'manager-lock.json',paths)
        self.assertIn(p.RUNTIME/'manager.lock',paths)
        self.assertFalse(self.pid.exists())

    def test_existing_pid_remains_protected_and_identity_strict(self):
        self.pid.write_text('4242',encoding='utf-8')
        self.assertEqual(HOST,a._check_host(self.root))
        self.assertIn(p.RUNTIME/'manager.pid',a._operational_paths(self.root))
        self.pid.write_text('4243',encoding='utf-8')
        with self.assertRaisesRegex(PermissionError,'MANAGER_IDENTITY_UNCERTAIN'):a._check_host(self.root)

    def test_absent_pid_held_lock_is_not_stopped(self):
        self.lock['state']='HELD';self.lock['released_at']=None;self.write_lock()
        with self.assertRaisesRegex(PermissionError,'MANAGER_IDENTITY_UNCERTAIN'):a._check_host(self.root)

    def test_absent_pid_open_lease_is_not_stopped(self):
        self.lock['lease_expires_at']=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat();self.write_lock()
        with self.assertRaisesRegex(PermissionError,'MANAGER_LEASE_OPEN'):a._check_host(self.root)

    def test_absent_pid_live_or_reused_holder_is_rejected(self):
        self.absent.side_effect=PermissionError('MANAGER_LIVE_OR_UNCERTAIN')
        with self.assertRaisesRegex(PermissionError,'MANAGER_LIVE_OR_UNCERTAIN'):a._check_host(self.root)

    def test_absent_pid_executor_observation_blocks(self):
        self.host.return_value={**HOST,'executors':[{'pid':4242,'identity_known':True}]}
        with self.assertRaisesRegex(PermissionError,'EXECUTOR_OR_SCHEDULE'):a._check_host(self.root)

    def test_pid_appearing_after_capture_changes_host_and_protected_population(self):
        before=a._check_host(self.root);population=set(a._operational_paths(self.root))
        self.pid.write_text('4242',encoding='utf-8')
        self.assertNotEqual(before,a._check_host(self.root))
        self.assertEqual(population|{p.RUNTIME/'manager.pid'},set(a._operational_paths(self.root)))


class PausedMaintenanceApplicationTests(unittest.TestCase):
    _json = staticmethod(cancellation.PausedMaintenanceCancellationTests._json)

    def setUp(self):
        # Existing lifecycle uses addCleanup, on this actually executed case.
        cancellation.PausedMaintenanceCancellationTests.setUp(self)
        self.request_path.unlink()
        self.ack_path.unlink()
        # Build existing documentary/synthetic fixtures ONLY in owned temp roots.
        with tempfile.TemporaryDirectory(prefix="hero-t20-reporting-") as seed:
            reporting.Phase6ReportingTests()._root(seed)
            shutil.copytree(seed, self.root, dirs_exist_ok=True)
        cycle.Phase6ControlCycleTests()._root(str(self.root), "2026-09-05T06:00:01Z")
        # Reporting uses the exact canary ID; this remains a synthetic receipt.
        self.publication["video_id"] = "iK_5edYQtx8"
        self._json(self.receipt, self.publication)
        transition = self.root / "output/operations/phase6/phase-transition-runtime.json"
        value = p._read(transition)
        value.update(status="WAITING_FOR_PHASE6_GATE", error=None)
        self._json(transition, value)
        # Recompute the documentary goal against this synthetic WAIT media, not
        # the production media identity inherited by the generic cycle fixture.
        from hero_engine.phase6_goal_trajectory import build_goal_trajectory
        self._json(self.root / "output/operations/phase6/goal-trajectory/latest.json",
                   build_goal_trajectory(self.root))
        self.assertEqual([], reporting.build_status(self.root)["attention_items"])
        for name in ("data/hero_engine.db", "output/production/phase5/pilot-001/integrity_manifest.json",
                     "output/production/phase6/shared-assets/asset_manifest.json"):
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(b"synthetic-protected-data\n")
        for name in ("maintenance_protocol", "maintenance_paused_application", "maintenance_unittest_result",
                     "maintenance_snapshot", "phase6_media_remediation_wait", "phase6_forward_post_effect_eligibility",
                     "production_capacity", "phase6_maintenance_verification"):
            target = self.root / "hero_engine" / (name + ".py")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / "hero_engine" / target.name).read_bytes())
        # Direct paused applications now emit a separate, forward-only D-116
        # reference.  The isolated root must carry the same schema the real
        # producer validates; absence is a fixture defect, never a production
        # fallback to an unvalidated reference.
        (self.root / "schemas").mkdir(exist_ok=True)
        (self.root / "schemas/phase6_paused_application_reference.schema.json").write_bytes(
            (ROOT / "schemas/phase6_paused_application_reference.schema.json").read_bytes()
        )
        (self.root / "tests").mkdir()
        (self.root / "tests/__init__.py").write_bytes(b"")
        (self.root / "tests/test_contract.py").write_text(
            "import unittest\nclass Contract(unittest.TestCase):\n"
            "    def test_one(self): self.assertEqual(2 + 2, 4)\n"
            "    def test_two(self): self.assertTrue(True)\n", encoding="utf-8")
        self.proof_dir = self.root / a.RUNS / "synthetic-local-regression"
        self.proof_dir.mkdir(parents=True)
        self.envelope = self.proof_dir / "application-envelope.json"
        host_patch = patch.object(a, "_host_observation", return_value=copy.deepcopy(HOST))
        self.host_patch = host_patch
        self.host = host_patch.start()
        self.addCleanup(host_patch.stop)
        resource_patch = patch.object(a, "measure_local_resources", return_value=copy.deepcopy(RESOURCES))
        self.resource = resource_patch.start()
        self.addCleanup(resource_patch.stop)
        variant = getattr(getattr(self, self._testMethodName), "fixture_scenario", None)
        if variant == "lease":
            with closing(sqlite3.connect(self.queue)) as connection, connection:
                connection.execute("UPDATE jobs SET lease_owner='synthetic-live-owner'")
        elif variant == "reservation":
            with closing(sqlite3.connect(self.ledger)) as connection, connection:
                connection.execute("UPDATE general_quota_debits SET state='RESERVED'")
        elif variant == "effect":
            self.publication["status"] = "IN_PROGRESS"
            self._json(self.receipt, self.publication)
        elif variant == "wal":
            capture_tests.PausedMaintenanceCaptureCancellationTests._wal_fixture(self, self.queue)
            capture_tests.PausedMaintenanceCaptureCancellationTests._wal_fixture(self, self.ledger)
        elif variant == "nested_commit_name":
            target = self.root / "output/operations/phase6/synthetic-history/committed.json"
            target.parent.mkdir(parents=True)
            target.write_bytes(b'{"synthetic_protected_evidence":true}')
        elif variant == "committed_forward_replay":
            self._seed_committed_forward_replay()
        elif variant == "owner_pause_goal":
            source = ROOT / ('output/runtime/gestor-central/maintenance-runs/'
                'maintenance-request-20261002T2310112750830Z-3eeaa73e/02-media-executor-status.json.before')
            self.assertEqual('sha256:e5e456f4c6d0c5ec44233c2d232c0ae39d91c3853750cd1c606079defad3794c', p.file_hash(source))
            (self.root / p.MEDIA_EXECUTOR_STATUS_PATH).write_bytes(source.read_bytes())
            self._json(self.root / p.GOAL_TRAJECTORY_LEGACY_PATH, build_goal_trajectory(self.root))
        self._make_proof()
        self.originals = self._protected_bytes()
        self.connections = []
        self.connection_uris = []
        original_connect = sqlite3.connect

        def isolated_connect(database, *args, **kwargs):
            text = str(database)
            if text.startswith("file:"):
                text = unquote(text[5:].split("?", 1)[0])
            path = Path(text).resolve()
            self.assertFalse(path.is_relative_to(ROOT), "SQLite opened operational root")
            self.assertFalse(path.is_relative_to(self.root), "SQLite opened original fixture/evidence")
            self.assertTrue(any(part.startswith("hero-paused-cancel-db-") for part in path.parts))
            self.connections.append(str(path))
            self.connection_uris.append(str(database))
            return original_connect(database, *args, **kwargs)
        sql_patch = patch.object(sqlite3, "connect", side_effect=isolated_connect)
        sql_patch.start()
        self.addCleanup(sql_patch.stop)

    def _seed_committed_forward_replay(self):
        # Reuse the real queue/receipt fixture, not a Queue test double. Its
        # eligibility oracle is synthetic; SQL and the immutable edge reader
        # are production implementations. This runs before source pinning.
        from tests.test_phase6_queue_post_effect import Phase6PostEffectQueueTests, CHANNEL_ID
        fixture = Phase6PostEffectQueueTests()
        with tempfile.TemporaryDirectory(prefix="hero-forward-seed-") as folder:
            seed = Path(folder)
            queue = fixture._queue(folder)
            now = datetime(2026, 9, 6, 3, 30, tzinfo=timezone.utc)
            historical = fixture._input_receipt(seed, "1")
            current = fixture._input_receipt(seed, "2")
            latest = seed / "output/operations/phase6/release/latest-production-inputs-receipt.json"
            latest.write_bytes((seed / current["path"]).read_bytes())
            reference, document = fixture._eligibility_receipt(seed, "f")
            predecessor = fixture._succeeded_job(queue, historical, now)
            successor = queue.enqueue(
                idempotency_key=current["receipt_id"] + ":media-current",
                operation_id="heroverse-phase6-controlled-longform-v1", channel_id=CHANNEL_ID,
                task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                payload={"input_receipt_id": current["receipt_id"], "action": "SYNTHESIZE_AND_RENDER_VIDEO_2"},
                now=now + timedelta(seconds=2))
            self.replay_edge = queue.adopt_forward_post_effect_current_input(
                predecessor["job_id"], predecessor_job_id=predecessor["job_id"],
                successor_job_id=successor["job_id"], media_unit=fixture._media_unit(),
                historical_input_receipt=historical, current_input_receipt=current,
                eligibility_receipt=reference, eligibility_verifier=fixture._forward_verifier(document),
                now=now + timedelta(seconds=3))
            self.replay_journal = {
                "record_type": "PREPARED", "predecessor_job_id": predecessor["job_id"],
                "successor_job_id": successor["job_id"], "current_input_receipt": current,
                "eligibility_receipt_expected": reference,
                "eligibility_receipt_preimage": {"exists": True, "sha256": reference["sha256"]},
                "committed_successor_observation": {
                    "job_sha256": p.canonical_hash(next(job for job in queue.snapshot()["jobs"]
                                                        if job["job_id"] == successor["job_id"])),
                    "edge_path": self.replay_edge["receipt_path"],
                    "edge_sha256": self.replay_edge["receipt_sha256"],
                },
            }
            # The enclosing migration retains its own documentary input view.
            latest.unlink()
            shutil.copytree(seed, self.root, dirs_exist_ok=True)
        capture_tests.PausedMaintenanceCaptureCancellationTests._wal_fixture(self, self.queue)
        capture_tests.PausedMaintenanceCaptureCancellationTests._wal_fixture(self, self.ledger)

    def _invoke_committed_forward_replay(self, *, tamper_outcome=False, lose_protection=False):
        original = a._load_proof

        def current(*args, **kwargs):
            value = original(*args, **kwargs)
            value["proof_family"] = "CURRENT_OPERATIONAL"
            return value

        def stage(root, run):
            journal = copy.deepcopy(self.replay_journal)
            (run / "forward-post-effect-journal.json").write_bytes(p._canonical_bytes(journal))
            return journal

        def commit(root, run):
            # This boundary represents an already-authenticated no-effect
            # replay. The finalizer must itself reopen the genuine SQL edge.
            capture = p._PROTECTED_DATABASE_VIEW.get()[1]
            self.assertFalse(getattr(capture, "_queue_sources_released", False))
            self.assertTrue(all(pin.handle is not None for pin in capture.source_pins.values()))
            if lose_protection:
                capture.source_pins[p.QUEUE_PATH].close()
            value = {"status": "COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT",
                     "eligibility_receipt": self.replay_journal["eligibility_receipt_expected"],
                     "queue_outcome": {**copy.deepcopy(self.replay_edge), "replayed_committed_edge": True}}
            if tamper_outcome:
                value["queue_outcome"]["receipt"]["authoritative_job"]["job_id"] = "job-foreign"
            (run / "forward-post-effect-committed.json").write_bytes(p._canonical_bytes(value))
            return value

        with patch.object(a, "_load_proof", side_effect=current), \
             patch.object(a, "prepare_forward_post_effect_journal", side_effect=stage), \
             patch.object(a, "commit_prepared_forward_post_effect_journal", side_effect=commit):
            return self._invoke()

    @scenario("committed_forward_replay")
    def test_committed_forward_replay_preserves_complete_database_sets(self):
        result = self._invoke_committed_forward_replay()
        self.assertEqual("APPLIED_WHILE_PAUSED", result["status"])
        self.assertTrue(result["forward_post_effect"]["queue_outcome"]["replayed_committed_edge"])
        self.assertFalse(result["restart_permitted"])
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertTrue(self.connections)  # native SQL ran only on protected work copies
        self.assertTrue(any("mode=ro" in uri and "immutable=1" in uri for uri in self.connection_uris))
        self.assertTrue((self._runs()[0] / "committed.json").is_file())

    @scenario("committed_forward_replay")
    def test_committed_forward_replay_rejects_outcome_mismatch_and_rolls_back(self):
        views = {name: (self.root / name).read_bytes() if (self.root / name).is_file() else None
                 for name in a.VIEWS}
        with self.assertRaisesRegex(PermissionError, "PAUSED_APPLICATION_FINALIZATION_FAILED") as raised:
            self._invoke_committed_forward_replay(tamper_outcome=True)
        self.assertIn("FORWARD_QUEUE_COMMIT_DIVERGED", str(raised.exception.__cause__))
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertFalse((self._runs()[0] / "committed.json").exists())
        # The immutable migration outcome precedes finalization. Its separate
        # failure receipt, not rewriting that historical outcome, attests rollback.
        self.assertEqual("ROLLED_BACK", p._read(self._runs()[0] / "paused-finalization-failure.json")["status"])
        for name, payload in views.items():
            self.assertEqual(payload, (self.root / name).read_bytes() if (self.root / name).is_file() else None)

    @scenario("committed_forward_replay")
    def test_committed_forward_replay_lost_protection_blocks_finalization(self):
        with self.assertRaisesRegex(PermissionError, "PAUSED_APPLICATION_FINALIZATION_FAILED") as raised:
            self._invoke_committed_forward_replay(lose_protection=True)
        self.assertIn("PROTECTION_LOST", str(raised.exception.__cause__))
        self.assertFalse((self._runs()[0] / "committed.json").exists())
        self.assertEqual(self.originals, self._protected_bytes())

    def _protected_bytes(self):
        paths = set(a._operational_paths(self.root)) | set(p._paused_cancel_database_files(self.root))
        return {str(name): (self.root / name).read_bytes() for name in paths}

    def _write(self, name, value):
        target = self.proof_dir / name
        target.write_bytes(p._canonical_bytes(value))

    def _make_proof(self):
        candidate = a.candidate_identity(self.root)
        self.candidate = candidate["source_set_sha256"]
        dependencies = a.dependency_identity()
        for side in ("before", "after"):
            self._write(f"candidate-{side}.json", {**candidate, "observed_at": datetime.now(timezone.utc).isoformat()})
            self._write(f"dependencies-{side}.json", dependencies)
        p.build_validation_manifests(self.root, output_dir=self.proof_dir)
        start = datetime.now(timezone.utc).isoformat()
        wall = time.monotonic()
        # Real tiny isolated unittest process provides the offered proof's exit.
        process = subprocess.Popen([sys.executable, "-B", "-u", "-X", "utf8", "-m", "unittest", "discover", "-s", "tests", "-v"],
                                   cwd=self.root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(self.root)))
        try:
            stdout, stderr = process.communicate(timeout=15)
        except BaseException:
            process.kill()  # only the child just created by this fixture
            process.communicate(timeout=5)
            raise
        self.assertEqual(0, process.returncode, stderr.decode(errors="replace"))
        finished = datetime.now(timezone.utc).isoformat()
        self._write("candidate-after.json", {**candidate, "observed_at": datetime.now(timezone.utc).isoformat()})
        (self.proof_dir / "unittest.stdout.log").write_bytes(stdout)
        (self.proof_dir / "unittest.stderr.log").write_bytes(stderr)
        self._write("full-process-result.json", {"started_at": start,
            "finished_at": finished, "test_pid": process.pid,
            "exit_code": process.returncode, "timed_out": False,
            "wall_seconds": time.monotonic() - wall, "command": a.COMMAND})
        result = v.verify_unittest_result(inventory=p._read(self.proof_dir / "test-inventory.json"),
                stdout_bytes=stdout, stderr_bytes=stderr, process_exit_code=process.returncode)
        result.pop("outcomes")
        self._write("verifier-result.json", result)
        names = set(a._operational_paths(self.root)) | set(p._paused_cancel_database_files(self.root))
        preservation = {"operation": "PAUSED", "task_enabled": False, "automation_paused": True,
                        "files": {name.as_posix(): p.file_hash(self.root / name) for name in names}}
        self._write("preservation-before.json", preservation)
        self._write("preservation-after.json", preservation)
        self._seal()

    def _seal(self):
        self._write("application-envelope.json", {"schema_version": "1.0.0",
                    "purpose": "EXACT_LOCAL_REGRESSION_FOR_PAUSED_APPLICATION", "root": str(self.root),
                    "proof_run": self.proof_dir.relative_to(self.root).as_posix(),
                    "candidate_sha256": self.candidate,
                    "files": {name: p.file_hash(self.proof_dir / name) for name in a.PROOF_FILES}})
        self.anchor = p.file_hash(self.envelope)

    def _invoke(self):
        return a.apply_paused(self.root, proof_envelope=self.envelope.relative_to(self.root),
                              expected_proof_hash=self.anchor, expected_candidate_hash=self.candidate)

    def _runs(self):
        return list((self.root / a.RUNS).glob("maintenance-request-*"))

    def _blocked(self, pattern="."):
        with self.assertRaisesRegex((PermissionError, OSError, ValueError, RuntimeError), pattern):
            self._invoke()
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertIsNone(p._PROTECTED_DATABASE_VIEW.get())
        for run in self._runs():
            self.assertFalse((run / "committed.json").exists())

    def test_valid_composed_preparation_commit_and_idempotent_repeat(self):
        before = (self.root / p.EXECUTIVE_STATUS_PATH).read_bytes()
        result = self._invoke()
        self.assertEqual("APPLIED_WHILE_PAUSED", result["status"])
        self.assertEqual("PASS", result["migration"]["status"])
        self.assertEqual(12, result["migration"]["stage_count"])
        self.assertFalse(result["restart_permitted"])
        self.assertEqual("NOT_EXECUTED", result["D116"])
        self.assertNotEqual(before, (self.root / p.EXECUTIVE_STATUS_PATH).read_bytes())
        self.assertTrue(self.connections)
        files = {str(path): path.read_bytes() for path in self._runs()[0].rglob("*") if path.is_file()}
        self.assertEqual(result, self._invoke())
        self.assertEqual(files, {str(path): path.read_bytes() for path in self._runs()[0].rglob("*") if path.is_file()})
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertFalse(self.request_path.exists())
        self.assertFalse(self.ack_path.exists())
        self.assertIsNone(p._PROTECTED_DATABASE_VIEW.get())

    def _existing_owned_goal(self):
        current = self.root / p.GOAL_TRAJECTORY_PATH
        value = p._read(self.root / p.GOAL_TRAJECTORY_LEGACY_PATH)
        value["decision"]["production_block"] = {
            "status": "VALIDATED_WAIT", "reason": "HISTORICAL_SYNTHETIC_BLOCK",
            "runtime_identity_sha256": "sha256:" + "0" * 64,
            "proof_path": "output/operations/phase6/synthetic-proof.json",
            "proof_sha256": "sha256:" + "1" * 64,
        }
        self._json(current, value)
        self._make_proof()
        self.originals = self._protected_bytes()
        self.assertIn(p.GOAL_TRAJECTORY_PATH, a._operational_paths(self.root))
        return current

    def test_goal_ownership_native_windows_sharing_conflict(self):
        """Actual Windows sharing protection, not a mocked PermissionError."""
        self.assertEqual("nt", os.name)
        current = self._existing_owned_goal()
        before = current.read_bytes()
        replacement = current.with_name("owned-test-replacement.tmp")
        replacement.write_bytes(b"replacement")
        with closing(p._PausedCancelPin(current)):
            with self.assertRaises(PermissionError) as caught:
                os.replace(replacement, current)
            self.assertEqual(5, caught.exception.winerror)
            self.assertEqual(before, current.read_bytes())
        replacement.unlink()

    def test_goal_ownership_existing_target_commit(self):
        current = self._existing_owned_goal()
        before = current.read_bytes()
        result = self._invoke()
        self.assertEqual("APPLIED_WHILE_PAUSED", result["status"])
        self.assertNotEqual(before, current.read_bytes())
        run = self._runs()[0]
        journal = p._read(run / "local-runtime-migration-journal.json")
        entry = next(item for item in journal["targets"] if item["path"] == p.GOAL_TRAJECTORY_PATH.as_posix())
        self.assertTrue(entry["existed_before"])
        self.assertEqual(before, (self.root / entry["before_path"]).read_bytes())
        self.assertEqual(entry["before_hash"], a._digest(before))
        self.assertEqual(entry["candidate_hash"], p.file_hash(current))
        self.assertEqual(before, (run / "protected-before" / p.GOAL_TRAJECTORY_PATH).read_bytes())
        a.verify_local_migration_evidence(self.root, request_id=run.name, migration=result["migration"])
        a.verify_archived_commit(self.root, run, result["binding"])
        final_bytes = current.read_bytes()
        try:
            current.write_bytes(final_bytes + b"\n")
            with self.assertRaisesRegex(PermissionError, "goal trajectory live target diverged"):
                a.verify_local_migration_evidence(self.root, request_id=run.name, migration=result["migration"])
            a.verify_local_migration_evidence(self.root, request_id=run.name, migration=result["migration"],
                                             scope="PAUSED_APPLICATION_ARCHIVE")
        finally:
            current.write_bytes(final_bytes)
        preimage = self.root / entry["before_path"]
        try:
            preimage.write_bytes(before + b"\n")
            with self.assertRaises(PermissionError):
                a.verify_local_migration_evidence(self.root, request_id=run.name, migration=result["migration"],
                                                 scope="PAUSED_APPLICATION_ARCHIVE")
        finally:
            preimage.write_bytes(before)
        after = self._protected_bytes()
        self.assertEqual({key: value for key, value in self.originals.items() if key != str(p.GOAL_TRAJECTORY_PATH)},
                         {key: value for key, value in after.items() if key != str(p.GOAL_TRAJECTORY_PATH)})
        self.assertIn(p.GOAL_TRAJECTORY_PATH, a._operational_paths(self.root))

    def test_goal_ownership_commit_failure_restores_every_target(self):
        current = self._existing_owned_goal()
        paths = set(a.VIEWS) | {p.GOAL_TRAJECTORY_PATH}
        before = {name: (self.root / name).read_bytes() if (self.root / name).is_file() else None
                  for name in paths}
        original = p._commit_migration_replacement
        replaced = []
        def fail_after_goal(target, payload):
            if target == self.root / p.EXECUTIVE_STATUS_PATH:
                self.assertNotEqual(before[p.GOAL_TRAJECTORY_PATH], current.read_bytes())
                replaced.append(target)
                raise OSError("controlled post-goal failure")
            return original(target, payload)
        with patch.object(p, "_commit_migration_replacement", side_effect=fail_after_goal):
            self._blocked("restored byte-for-byte")
        self.assertEqual(1, len(replaced))
        self.assertEqual(before, {name: (self.root / name).read_bytes() if (self.root / name).is_file() else None
                                  for name in paths})
        error = p._read(next(self._runs()[0].glob("local-runtime-migration-error-*.json")))
        self.assertTrue(error["rollback"]["verified"])
        self.assertEqual("ROLLED_BACK", error["record_type"])

    def test_goal_ownership_finalization_failure_restores_every_target(self):
        current = self._existing_owned_goal()
        before = current.read_bytes()
        original = a._publish
        injected = []
        def fail_final(path, payload):
            if path.name == "committed.json":
                self.assertNotEqual(before, current.read_bytes())
                injected.append(path)
                raise OSError("controlled receipt write failure")
            return original(path, payload)
        with patch.object(a, "_publish", side_effect=fail_final):
            self._blocked("FINALIZATION_FAILED")
        self.assertEqual(1, len(injected))
        self.assertEqual(before, current.read_bytes())
        error = p._read(self._runs()[0] / "paused-finalization-failure.json")
        self.assertEqual("ROLLED_BACK", error["status"])
        self.assertTrue(error["rollback"]["verified"])

    def test_goal_ownership_foreign_writes_denied_before_and_after_handoff(self):
        current = self._existing_owned_goal()
        original = a._publish
        checked = []
        def inspect(path, payload):
            if path.name in ("prepared.json", "migration.json"):
                for target in (current, self.root / p.RUNTIME / "PAUSE",
                               self.root / p.GOAL_TRAJECTORY_LEGACY_PATH):
                    raw = target.read_bytes()
                    with self.assertRaises(PermissionError):
                        with target.open("ab") as stream:
                            stream.write(b"foreign")
                    self.assertEqual(raw, target.read_bytes())
                checked.append(path.name)
            return original(path, payload)
        with patch.object(a, "_publish", side_effect=inspect):
            result = self._invoke()
        self.assertEqual(["prepared.json", "migration.json"], checked)
        self.assertEqual("APPLIED_WHILE_PAUSED", result["status"])

    def test_goal_ownership_foreign_handoff_bytes_never_become_preimage(self):
        current = self._existing_owned_goal()
        original = p._replace_bytes
        injected = []
        def interfere(path, payload, **kwargs):
            if path == current and kwargs.get("recheck") is not None and not injected:
                path.write_bytes(b"foreign handoff edit")
                injected.append(path)
            return original(path, payload, **kwargs)
        with patch.object(p, "_replace_bytes", side_effect=interfere):
            with self.assertRaisesRegex(RuntimeError, "rollback could not be proven"):
                self._invoke()
        self.assertEqual(1, len(injected))
        self.assertEqual(b"foreign handoff edit", current.read_bytes())
        run = self._runs()[0]
        self.assertFalse((run / "committed.json").exists())
        error = p._read(next(run.glob("local-runtime-migration-error-*.json")))
        self.assertEqual("ROLLBACK_FAILED", error["record_type"])
        self.assertIn(p.GOAL_TRAJECTORY_PATH.as_posix(), error["rollback"]["foreign_targets_preserved"])
        after = self._protected_bytes()
        self.assertEqual({key: value for key, value in self.originals.items() if key != str(p.GOAL_TRAJECTORY_PATH)},
                         {key: value for key, value in after.items() if key != str(p.GOAL_TRAJECTORY_PATH)})

    def test_goal_ownership_non_target_remains_globally_pinned(self):
        current = self.root / p.GOAL_TRAJECTORY_PATH
        current.write_bytes((self.root / p.GOAL_TRAJECTORY_LEGACY_PATH).read_bytes())
        self._make_proof()
        self.originals = self._protected_bytes()
        original = a._publish
        checked = []
        def inspect(path, payload):
            if path.name == "migration.json":
                journal = p._read(path.parent / "local-runtime-migration-journal.json")
                self.assertNotIn(p.GOAL_TRAJECTORY_PATH.as_posix(), [item["path"] for item in journal["targets"]])
                with self.assertRaises(PermissionError):
                    current.write_bytes(b"foreign")
                checked.append(path)
            return original(path, payload)
        with patch.object(a, "_publish", side_effect=inspect):
            self._invoke()
        self.assertEqual(1, len(checked))
        self.assertEqual(self.originals, self._protected_bytes())

    @scenario("owner_pause_goal")
    def test_transaction_commits_media_and_goal_from_same_proposed_state(self):
        legacy = (self.root / p.GOAL_TRAJECTORY_LEGACY_PATH).read_bytes()
        old_media = (self.root / p.MEDIA_EXECUTOR_STATUS_PATH).read_bytes()
        self.assertEqual('MEDIA_PRODUCTION_ERROR', json.loads(legacy)['decision']['production_block']['reason'])
        result = self._invoke()
        self.assertEqual('APPLIED_WHILE_PAUSED', result['status'])
        self.assertEqual('WAITING', p._read(self.root / p.MEDIA_EXECUTOR_STATUS_PATH)['status'])
        self.assertIsNone(p._read(self.root / p.GOAL_TRAJECTORY_PATH)['decision']['production_block'])
        self.assertEqual([], reporting.build_status(self.root)['attention_items'])
        self.assertEqual(legacy, (self.root / p.GOAL_TRAJECTORY_LEGACY_PATH).read_bytes())
        run = self._runs()[0]
        journal = p._read(run / 'local-runtime-migration-journal.json')
        media_target = next(item for item in journal['targets'] if item['path'] == p.MEDIA_EXECUTOR_STATUS_PATH.as_posix())
        self.assertEqual(old_media, (self.root / media_target['before_path']).read_bytes())
        a.verify_local_migration_evidence(self.root, request_id=run.name, migration=result['migration'])

    def test_owned_forward_goal_trajectory_is_accepted_at_final_recheck(self):
        """A reviewed absent-before current view is not foreign drift.

        This reproduces the real T195 shape: the legacy trajectory is the
        source, the paused migration derives ``current.json``, and finalization
        must bind that exact journaled addition rather than doing a naked
        operational-file-set comparison.
        """
        # Keep every other derived target resident.  The production incident
        # had exactly one absent-before operational addition (current.json),
        # so this fixture must not accidentally exercise a broadened allowlist.
        runtime, executive, markdown, _evidence = p._local_runtime_migration_candidates(
            self.root, observed=datetime.now(timezone.utc), request_id="synthetic-preseed"
        )
        for path, payload in (
            (p.PREDICTION_RUNTIME_PATH, p._canonical_bytes(runtime)),
            (p.EXECUTIVE_STATUS_PATH, p._canonical_bytes(executive)),
            (p.EXECUTIVE_STATUS_MARKDOWN_PATH, markdown.encode("utf-8")),
        ):
            target = self.root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        # The legacy view records a stale but structurally complete media
        # identity.  The live synthetic media state has no matching block, so
        # the production derivation must create the absent forward successor.
        legacy = self.root / p.GOAL_TRAJECTORY_LEGACY_PATH
        value = p._read(legacy)
        value["decision"]["production_block"] = {
            "status": "VALIDATED_WAIT",
            "reason": "HISTORICAL_SYNTHETIC_BLOCK",
            "runtime_identity_sha256": "sha256:" + "0" * 64,
            "proof_path": "output/operations/phase6/synthetic-proof.json",
            "proof_sha256": "sha256:" + "1" * 64,
        }
        self._json(legacy, value)
        self._make_proof()
        self.originals = self._protected_bytes()
        original_preview = p._control_source_preview
        def final_stage_preview(*args, **kwargs):
            preview = original_preview(*args, **kwargs)
            # The candidate path uses the production preview with explicit
            # overrides.  Only the final post-commit source observation is
            # isolated here: the fixture deliberately retains an old legacy
            # goal, whereas production has the successor resident by then.
            if kwargs.get("overrides") is None:
                preview = dict(preview)
                preview.update(stage_count=12, all_schemas_valid=True, blockers=[])
            return preview
        with patch.object(p, "_control_source_preview", side_effect=final_stage_preview):
            result = self._invoke()
        current = self.root / p.GOAL_TRAJECTORY_PATH
        self.assertEqual("APPLIED_WHILE_PAUSED", result["status"])
        self.assertTrue(current.is_file())
        outcome = p._read(self._runs()[0] / "local-runtime-migration-outcome.json")
        self.assertTrue(any(item["path"] == p.GOAL_TRAJECTORY_PATH.as_posix()
                            and item["exists"] for item in outcome["target_hashes"]))
        protected = self._protected_bytes()
        self.assertEqual({name: protected[name] for name in self.originals}, self.originals)

    def _forward_new_eligibility_case(self, variant=None):
        """Exercise the real finalizer with both outputs of the forward writer.

        Only the upstream queue/eligibility issuer is simulated here. The
        protocol entry, snapshots, native file protection, immutable journal,
        final population check and rollback are the real implementations.
        """
        from hero_engine.queue_phase6 import MEDIA_JOB_SUPERSESSION_RECEIPTS, POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS
        original = a._load_proof
        prepared, committed, receipt_hashes = [], [], {}
        eligibility_id = 'phase6-post-effect-visual-eligibility-' + 'a' * 24
        eligibility_path = POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS / (eligibility_id + '.json')
        if variant == 'foreign_path':
            eligibility_path = Path('output/operations/phase6/foreign-eligibility.json')
        eligibility_raw = p._canonical_bytes({'receipt_id': eligibility_id, 'synthetic': True})
        eligibility = {'receipt_id': eligibility_id, 'path': eligibility_path.as_posix(),
                       'sha256': a._digest(eligibility_raw)}
        preexisting = variant == 'preexisting'
        if preexisting:
            target = self.root / eligibility_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(eligibility_raw)
            self._make_proof()
            self.originals = self._protected_bytes()
        def current(*args, **kwargs):
            value = original(*args, **kwargs)
            value["proof_family"] = "CURRENT_OPERATIONAL"
            return value
        def stage(root, run):
            prepared.append((root, run))
            journal = {"record_type": "PREPARED", "predecessor_job_id": "job-synthetic",
                       "successor_job_id": "job-synthetic-successor",
                       "current_input_receipt": {"receipt_id": "phase6-production-inputs-synthetic"},
                       "eligibility_receipt_expected": copy.deepcopy(eligibility),
                       "eligibility_receipt_preimage": {'exists': preexisting,
                           'sha256': eligibility['sha256'] if preexisting else None}}
            (run / "forward-post-effect-journal.json").write_bytes(p._canonical_bytes(journal))
            return journal
        def commit(root, run):
            capture = p._PROTECTED_DATABASE_VIEW.get()[1]
            queue_relatives = [relative for relative in capture.source_pins
                               if relative == p.QUEUE_PATH or str(relative).startswith(str(p.QUEUE_PATH) + "-")]
            self.assertTrue(queue_relatives)
            self.assertTrue(all(capture.source_pins[relative].handle is None for relative in queue_relatives))
            self.assertTrue(all(pin.handle is not None for relative, pin in capture.source_pins.items()
                                if relative not in queue_relatives))
            target = root / eligibility_path
            if not preexisting:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(eligibility_raw if variant != 'tamper' else b'{"tampered":true}')
            if variant == 'missing':
                target.unlink()  # only this test's own disposable output
            if variant == 'foreign_addition':
                (root / 'output/operations/phase6/foreign.json').write_bytes(b'{}')
            receipt_path = root / MEDIA_JOB_SUPERSESSION_RECEIPTS / "phase6-media-supersession-synthetic.json"
            receipt_path.parent.mkdir(parents=True, exist_ok=True)
            receipt_path.write_bytes(p._canonical_bytes({"synthetic": True}))
            receipt_hashes["value"] = p.file_hash(receipt_path)
            committed.append((root, run)); receipt = {
                "status": "COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT",
                "eligibility_receipt": copy.deepcopy(eligibility),
                "queue_outcome": {"receipt": {"synthetic": True},
                                  "receipt_path": receipt_path.relative_to(root).as_posix(),
                                  "receipt_sha256": receipt_hashes["value"]},
            }
            if variant == 'binding_mismatch':
                receipt['eligibility_receipt']['sha256'] = 'sha256:' + '0' * 64
            (run / "forward-post-effect-committed.json").write_bytes(p._canonical_bytes(receipt))
            return receipt
        class Queue:
            def __init__(self, _root): pass
            def get_media_job_supersession(self, _job_id):
                return {"state": "COMMITTED", "receipt": {"synthetic": True},
                        "receipt_sha256": receipt_hashes["value"]}
            def snapshot(self):
                return {"jobs": [{"job_id": "job-synthetic-successor", "state": "PENDING",
                                  "attempt_count": 0, "lease_owner": None, "lease_until": None,
                                  "checkpoint": {}, "payload": {"input_receipt_id": "phase6-production-inputs-synthetic"}}]}
        with patch.object(a, "_load_proof", side_effect=current), \
               patch.object(a, "prepare_forward_post_effect_journal", side_effect=stage), \
               patch.object(a, "commit_prepared_forward_post_effect_journal", side_effect=commit), \
               patch("hero_engine.queue_phase6.TransactionalQueue", Queue):
              if variant not in (None, 'preexisting'):
                  with self.assertRaisesRegex(PermissionError, 'PAUSED_APPLICATION_FINALIZATION_FAILED') as caught:
                      self._invoke()
                  reason = 'OPERATIONAL_FILE_SET_CHANGED' if variant == 'foreign_addition' else 'FORWARD_ELIGIBILITY_RECEIPT_INVALID'
                  self.assertIn(reason, str(caught.exception.__cause__))
                  run = self._runs()[0]
                  self.assertFalse((run / 'committed.json').exists())
                  self.assertTrue((run / 'failed.json').exists())
                  self.assertTrue(p._read(run / 'paused-finalization-failure.json')['rollback']['verified'])
                  actual = self._protected_bytes()
                  self.assertEqual(self.originals, {name: actual[name] for name in self.originals})
                  return
              result = self._invoke()
              repeated = self._invoke()
        self.assertEqual(1, len(prepared))
        self.assertEqual(1, len(committed))
        self.assertEqual(result, repeated)
        self.assertEqual("COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT", result["forward_post_effect"]["status"])
        run = self._runs()[0]
        document = p._read(run / "prepared.json")
        self.assertEqual((run / "forward-post-effect-journal.json").relative_to(self.root).as_posix(),
                         document["forward_post_effect_journal"]["path"])
        self.assertEqual(p.file_hash(run / "forward-post-effect-journal.json"),
                         document["forward_post_effect_journal"]["sha256"])
        self.assertTrue(a._path(self.root, document["forward_post_effect_journal"]["path"]).is_file())
        self.assertTrue((run / "forward-post-effect-committed.json").is_file())
        self.assertEqual(result, a.verify_archived_commit(self.root, run, result["binding"]))
        (run / "committed.json").unlink()  # disposable crash-after-edge fixture
        with patch("hero_engine.queue_phase6.TransactionalQueue", Queue):
            recovered = a.recover_forward_paused_finalization(self.root, application_id=run.name)
        self.assertEqual("RECOVERED_FORWARD_FINALIZATION_WHILE_PAUSED", recovered["status"])
        self.assertTrue((self.root / a.RUNS / ("recovery-forward-finalization-" + run.name) / "committed.json").is_file())

    def test_current_operational_proof_wires_forward_journal_once(self):
        self._forward_new_eligibility_case()

    def test_forward_preexisting_eligibility_receipt_remains_pinned(self):
        self._forward_new_eligibility_case('preexisting')

    def test_forward_new_eligibility_tamper_blocks_finalization(self):
        self._forward_new_eligibility_case('tamper')

    def test_forward_new_eligibility_missing_blocks_finalization(self):
        self._forward_new_eligibility_case('missing')

    def test_forward_new_eligibility_binding_mismatch_blocks_finalization(self):
        self._forward_new_eligibility_case('binding_mismatch')

    def test_forward_new_eligibility_foreign_path_blocks_finalization(self):
        self._forward_new_eligibility_case('foreign_path')

    def test_forward_new_eligibility_does_not_admit_foreign_addition(self):
        self._forward_new_eligibility_case('foreign_addition')

    def test_current_operational_forward_receipt_hash_tamper_rolls_back_views(self):
        from hero_engine.queue_phase6 import MEDIA_JOB_SUPERSESSION_RECEIPTS
        original = a._load_proof

        def current(*args, **kwargs):
            value = original(*args, **kwargs)
            value["proof_family"] = "CURRENT_OPERATIONAL"
            return value

        def stage(root, run):
            journal = {"record_type": "PREPARED", "predecessor_job_id": "job-synthetic",
                       "successor_job_id": "job-synthetic-successor",
                       "current_input_receipt": {"receipt_id": "phase6-production-inputs-synthetic"}}
            (run / "forward-post-effect-journal.json").write_bytes(p._canonical_bytes(journal))
            return journal

        def commit(root, run):
            receipt_path = root / MEDIA_JOB_SUPERSESSION_RECEIPTS / "phase6-media-supersession-tamper.json"
            receipt_path.parent.mkdir(parents=True, exist_ok=True)
            receipt_path.write_bytes(p._canonical_bytes({"synthetic": True}))
            value = {"status": "COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT",
                     "queue_outcome": {"receipt": {"synthetic": True},
                                       "receipt_path": receipt_path.relative_to(root).as_posix(),
                                       "receipt_sha256": "sha256:" + "0" * 64}}
            (run / "forward-post-effect-committed.json").write_bytes(p._canonical_bytes(value))
            return value

        class Queue:
            def __init__(self, _root): pass
            def get_media_job_supersession(self, _job_id):
                return {"state": "COMMITTED", "receipt": {"synthetic": True},
                        "receipt_sha256": "sha256:" + "0" * 64}

        with patch.object(a, "_load_proof", side_effect=current), \
             patch.object(a, "prepare_forward_post_effect_journal", side_effect=stage), \
             patch.object(a, "commit_prepared_forward_post_effect_journal", side_effect=commit), \
             patch("hero_engine.queue_phase6.TransactionalQueue", Queue):
            with self.assertRaisesRegex(PermissionError, "PAUSED_APPLICATION_FINALIZATION_FAILED"):
                self._invoke()
        actual = self._protected_bytes()
        additions = set(actual) - set(self.originals)
        self.assertEqual({str(MEDIA_JOB_SUPERSESSION_RECEIPTS /
                              "phase6-media-supersession-tamper.json")}, additions)
        self.assertEqual({name: actual[name] for name in self.originals}, self.originals)

    @scenario("wal")
    def test_cli_composed_entry_with_empty_wal_keeps_sources_intact(self):
        # The real CLI emits its authenticated receipt through the binary
        # stdout boundary.  Keep the fixture on that same boundary instead of
        # replacing it with StringIO (which has no ``buffer`` attribute).
        output = io.BytesIO()
        stdout = io.TextIOWrapper(output, encoding="utf-8")
        arguments = ["maintenance_protocol", "--root", str(self.root), "apply-paused",
                     "--proof-envelope", self.envelope.relative_to(self.root).as_posix(),
                     "--expected-proof-hash", self.anchor, "--expected-candidate-hash", self.candidate]
        with patch.object(sys, "argv", arguments), patch.object(sys, "stdout", stdout):
            self.assertEqual(0, p._cli())
            stdout.flush()
        self.assertEqual("APPLIED_WHILE_PAUSED", json.loads(output.getvalue().decode("utf-8"))["status"])
        self.assertEqual(self.originals, self._protected_bytes())

    def test_composed_namespace_matches_existing_media_schema_without_request_marker(self):
        from jsonschema import Draft202012Validator
        self._invoke()
        schema = p._read(ROOT / "schemas/phase6_post_effect_visual_wait_proof.schema.json")
        Draft202012Validator(schema["properties"]["request_id"]).validate(self._runs()[0].name)
        self.assertFalse(self.request_path.exists())
        self.assertFalse(self.ack_path.exists())

    @scenario("lease")
    def test_open_lease_blocks_composed_entry(self):
        self._blocked("ACTIVE_LEASE")

    @scenario("reservation")
    def test_open_reservation_blocks_composed_entry(self):
        self._blocked("RESERVATION_OR_UNKNOWN_QUOTA_STATE")

    @scenario("effect")
    def test_open_effect_blocks_composed_entry(self):
        self._blocked("OPEN_OR_UNKNOWN_EFFECT")

    def test_old_candidate_rejected_without_repinning(self):
        self.candidate = "0" * 64
        self._blocked("ENVELOPE_CONTRACT_DIVERGED")

    def test_source_changed_after_regression(self):
        (self.root / "hero_engine/maintenance_protocol.py").write_bytes(b"changed source")
        self._blocked("CANDIDATE_DIVERGED")

    def test_tampered_proof_anchor_rejected(self):
        (self.proof_dir / "unittest.stderr.log").write_bytes(b"OK\n")
        self._blocked("PROOF_FILE_DIVERGED")

    def test_other_root_proof_rejected(self):
        value = p._read(self.envelope)
        value["root"] = str(self.root / "another-root")
        self._write("application-envelope.json", value)
        self.anchor = p.file_hash(self.envelope)
        self._blocked("ENVELOPE_CONTRACT_DIVERGED")

    def test_copied_proof_path_cannot_inherit_original_anchor(self):
        copied = self.proof_dir.with_name("different-regression-run")
        shutil.copytree(self.proof_dir, copied)
        self.envelope = copied / self.envelope.name
        self._blocked("ENVELOPE_CONTRACT_DIVERGED")

    def test_reference_contract_rejects_unsupported_name_before_preparation(self):
        original = self.envelope
        for name in ("arbitrary.json", "application-envelope-.json", "application-envelope-A.json"):
            with self.subTest(name=name):
                self.envelope = original.with_name(name)
                self.envelope.write_bytes(original.read_bytes())
                self._blocked("REFERENCE_PROOF_PATH_INVALID")
                self.assertEqual([], self._runs())

    def test_reference_contract_alias_preserves_external_envelope_anchor(self):
        original = self.envelope
        self.envelope = original.with_name("application-envelope-recovery-20261002.json")
        self.envelope.write_bytes(original.read_bytes() + b"\n")
        self._blocked("ENVELOPE_HASH_DIVERGED")
        self.assertEqual([], self._runs())

    def test_dependency_before_after_drift_rejected(self):
        value = p._read(self.proof_dir / "dependencies-after.json")
        value["python_version"] = "other version"
        self._write("dependencies-after.json", value)
        self._seal()
        self._blocked("DEPENDENCIES_DIVERGED")

    def test_incomplete_preservation_rejected(self):
        value = p._read(self.proof_dir / "preservation-before.json")
        value["files"].pop(p.QUEUE_PATH.as_posix())
        for side in ("before", "after"):
            self._write(f"preservation-{side}.json", value)
        self._seal()
        self._blocked("PRESERVATION_INCOMPLETE")

    def test_anchored_incomplete_log_still_fails_real_verifier(self):
        (self.proof_dir / "unittest.stderr.log").write_bytes(b"Ran 2 tests in 0.001s\nOK\n")
        self._seal()
        self._blocked()

    def test_nonzero_real_exit_cannot_be_overridden_by_pass(self):
        record = p._read(self.proof_dir / "full-process-result.json")
        record["exit_code"] = 1
        self._write("full-process-result.json", record)
        self._seal()
        self._blocked("PROCESS_PROOF_INVALID")

    def test_process_uncertain_or_alive_blocks(self):
        for answer in (True, None):
            with self.subTest(answer=answer):
                self.process.return_value = answer
                self._blocked("NOT_PROVEN_ABSENT")

    def test_executor_or_task_active_blocks(self):
        for change in ({"task_enabled": True}, {"executors": [{"pid": 10, "identity_known": False}]}, {"automation_paused": False}):
            with self.subTest(change=change):
                self.host.return_value = {**HOST, **change}
                self._blocked("EXECUTOR_OR_SCHEDULE")

    def test_host_probe_scopes_apply_signature_to_python_executor(self):
        """A launcher shell mentioning apply-paused is not an operational executor."""
        self.host_patch.stop()
        completed = type("Completed", (), {"stdout": json.dumps({
            "task_name": a.TASK, "task_state": "Disabled", "task_enabled": False,
            "executors": []}).encode("utf-8")})()
        with patch.object(a.subprocess, "run", return_value=completed) as observed:
            value = a._host_observation(self.root)
        self.assertEqual([], value["executors"])
        probe = observed.call_args.args[0][-1]
        application_line = next(line for line in probe.splitlines()
                                if "maintenance_protocol.*apply-paused" in line)
        self.assertTrue(application_line.lstrip().startswith("($_.Name -match '^pythonw?"))
        self.assertNotIn("daily\\\\.ps1|maintenance_protocol.*apply-paused", probe)

    def test_pause_required_and_not_synthesized(self):
        self.pause.unlink()
        with self.assertRaisesRegex(PermissionError, "OWNER_PAUSE_REQUIRED"):
            self._invoke()
        self.assertFalse(self.pause.exists())

    def test_race_after_preflight_blocks_before_commit(self):
        original = p.preview_local_runtime_migration
        def race(*args, **kwargs):
            result = original(*args, **kwargs)
            self.host.return_value = {**HOST, "executors": [{"pid": 777, "identity_known": True}]}
            return result
        with patch.object(p, "preview_local_runtime_migration", side_effect=race):
            self._blocked("EXECUTOR_OR_SCHEDULE")

    def test_source_pin_denies_concurrent_write(self):
        original = p.preview_local_runtime_migration
        def race(*args, **kwargs):
            with self.assertRaises(PermissionError):
                (self.root / "hero_engine/maintenance_protocol.py").write_bytes(b"foreign")
            return original(*args, **kwargs)
        with patch.object(p, "preview_local_runtime_migration", side_effect=race):
            self.assertEqual("APPLIED_WHILE_PAUSED", self._invoke()["status"])

    def test_second_commit_failure_restores_exact_views(self):
        before = {name: (self.root / name).read_bytes() if (self.root / name).exists() else None for name in a.VIEWS}
        original = p._commit_migration_replacement
        count = 0
        def fail(path, payload):
            nonlocal count
            count += 1
            if count == 2:
                raise OSError("injected second commit")
            original(path, payload)
        with patch.object(p, "_commit_migration_replacement", side_effect=fail):
            self._blocked("restored byte-for-byte")
        for name, raw in before.items():
            self.assertEqual(raw, (self.root / name).read_bytes() if (self.root / name).exists() else None)
        self._blocked("PARTIAL_ATTEMPT_REQUIRES_REVIEW")

    def test_final_receipt_failure_rolls_back_without_false_success(self):
        before = (self.root / p.EXECUTIVE_STATUS_PATH).read_bytes()
        original = a._publish
        def fail(path, raw):
            if path.name == "committed.json":
                raise OSError("injected receipt persistence")
            return original(path, raw)
        with patch.object(a, "_publish", side_effect=fail):
            self._blocked("FINALIZATION_FAILED")
        self.assertEqual(before, (self.root / p.EXECUTIVE_STATUS_PATH).read_bytes())
        self.assertTrue((self._runs()[0] / "paused-finalization-failure.json").is_file())

    def test_prepared_write_failure_never_commits(self):
        original = a._publish
        def fail(path, raw):
            if path.name == "prepared.json":
                raise OSError("injected prepared persistence")
            return original(path, raw)
        with patch.object(a, "_publish", side_effect=fail):
            self._blocked("injected prepared")

    def test_lost_capture_protection_blocks(self):
        original = p.preview_local_runtime_migration
        def lose(*args, **kwargs):
            result = original(*args, **kwargs)
            p._PROTECTED_DATABASE_VIEW.get()[1].source_pins[p.QUEUE_PATH].close()
            return result
        with patch.object(p, "preview_local_runtime_migration", side_effect=lose):
            self._blocked("PROTECTION_LOST")

    def test_resource_wait_blocks_without_cleanup_or_retry(self):
        self.resource.return_value = {**RESOURCES, "available_ram_bytes": 0}
        self._blocked("RESOURCE_WAIT")
        self.assertEqual(1, self.resource.call_count)

    def test_failed_receipt_never_serializes_arbitrary_permission_message(self):
        self.assertEqual("RESOURCE_WAIT", a._failure_code(PermissionError("PAUSED_APPLICATION_RESOURCE_WAIT")))
        self.assertEqual("PAUSED_CANCEL_CAPTURE_DIVERGED",
                         a._failure_code(PermissionError("PAUSED_CANCEL_CAPTURE_DIVERGED: database/queue")))
        self.assertEqual("UNCLASSIFIED_PERMISSION_ERROR", a._failure_code(PermissionError(r"C:\\secret\\host-detail")))
        self.assertEqual("UNCLASSIFIED_RUNTIMEERROR", a._failure_code(RuntimeError("untrusted detail")))

    def test_unknown_resource_probe_blocks(self):
        self.resource.return_value = {**RESOURCES, "cpu_load_percent": None}
        self._blocked("RESOURCE_LOAD_UNKNOWN")

    def test_foreign_view_is_not_overwritten_during_rollback(self):
        original = p._commit_migration_replacement
        count = 0
        target = self.root / p.EXECUTIVE_STATUS_PATH
        def interfere(path, payload):
            nonlocal count
            count += 1
            original(path, payload)
            if path == target:
                target.write_bytes(b"foreign-after-own-write")
                raise OSError("foreign race")
        with patch.object(p, "_commit_migration_replacement", side_effect=interfere):
            self._blocked("rollback could not be proven")
        self.assertEqual(b"foreign-after-own-write", target.read_bytes())

    def test_interruption_after_commit_keeps_pause_and_blocks_blind_repeat(self):
        original = p._commit_migration_replacement
        def interrupt(path, payload):
            original(path, payload)
            raise SystemExit("controlled interruption after an actual own write")
        with patch.object(p, "_commit_migration_replacement", side_effect=interrupt):
            with self.assertRaisesRegex(SystemExit, "controlled interruption"):
                self._invoke()
        run = self._runs()[0]
        self.assertTrue((run / "failed.json").is_file())
        self.assertTrue((run / "local-runtime-migration-journal.json").is_file())
        self.assertFalse((run / "committed.json").exists())
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertIsNone(p._PROTECTED_DATABASE_VIEW.get())
        self._blocked("PARTIAL_ATTEMPT_REQUIRES_REVIEW")

    def test_crash_recovery_rolls_back_only_exact_incomplete_targets(self):
        self._invoke()
        run = self._runs()[0]
        (run / "committed.json").unlink()  # disposable interrupted-finalization fixture
        journal = json.loads((run / "local-runtime-migration-journal.json").read_text(encoding="utf-8"))
        before = {
            item["path"]: (self.root / item["before_path"]).read_bytes()
            if item["existed_before"] else None
            for item in journal["targets"]
        }
        result = a.recover_incomplete_paused_application(self.root, application_id=run.name)
        self.assertEqual("ROLLED_BACK_INCOMPLETE_PAUSED_APPLICATION", result["status"])
        self.assertFalse((run / "committed.json").exists())
        recovery = self.root / a.RUNS / ("recovery-" + run.name)
        self.assertTrue((recovery / "prepared.json").is_file())
        self.assertTrue((recovery / "committed.json").is_file())
        for name, payload in before.items():
            target = self.root / name
            if payload is None:
                self.assertFalse(target.exists())
            else:
                self.assertEqual(payload, target.read_bytes())
        self.assertEqual(self.originals, self._protected_bytes())

    def test_crash_recovery_rejects_foreign_target_without_writing_recovery(self):
        self._invoke()
        run = self._runs()[0]
        (run / "committed.json").unlink()  # disposable interrupted-finalization fixture
        journal = json.loads((run / "local-runtime-migration-journal.json").read_text(encoding="utf-8"))
        changed = next(item for item in journal["targets"] if item["changed"])
        target = self.root / changed["path"]
        target.write_bytes(b"foreign-derived-view")
        with self.assertRaisesRegex(PermissionError, "RECOVERY_TARGET_FOREIGN_OR_INCOMPLETE"):
            a.recover_incomplete_paused_application(self.root, application_id=run.name)
        self.assertEqual(b"foreign-derived-view", target.read_bytes())
        self.assertFalse((self.root / a.RUNS / ("recovery-" + run.name)).exists())

    def _abandoned_preprepare_run(self):
        run = self.root / a.RUNS / "maintenance-request-20260918T0000000000000Z-a1b2c3d4"
        views = run / "views-before"
        for name in a.VIEWS:
            target = self.root / name
            if target.is_file():
                copy = views / name
                copy.parent.mkdir(parents=True, exist_ok=True)
                copy.write_bytes(target.read_bytes())
        return run

    def test_no_effect_preprepare_recovery_attests_only_unchanged_views(self):
        run = self._abandoned_preprepare_run()
        result = a.attest_no_effect_preprepare_application(self.root, application_id=run.name)
        self.assertEqual("ABANDONED_BEFORE_PREPARE_NO_EFFECT", result["status"])
        self.assertFalse((run / "prepared.json").exists())
        recovery = self.root / a.RUNS / ("recovery-no-effect-" + run.name)
        self.assertTrue((recovery / "prepared.json").is_file())
        self.assertTrue((recovery / "committed.json").is_file())
        self.assertEqual(self.originals, self._protected_bytes())

    def test_no_effect_preprepare_recovery_rejects_changed_view(self):
        run = self._abandoned_preprepare_run()
        target = next(self.root / name for name in a.VIEWS if (self.root / name).is_file())
        target.write_bytes(b"foreign-view-after-interrupted-preparation")
        with self.assertRaisesRegex(PermissionError, "NO_EFFECT_VIEW_CHANGED"):
            a.attest_no_effect_preprepare_application(self.root, application_id=run.name)
        recovery = self.root / a.RUNS / ("recovery-no-effect-" + run.name)
        self.assertFalse(recovery.exists())
        self.assertEqual(b"foreign-view-after-interrupted-preparation", target.read_bytes())

    def test_repeat_rejects_unknown_receipt_version_without_removing_evidence(self):
        self._invoke()
        committed = self._runs()[0] / "committed.json"
        result = p._read(committed)
        result["schema_version"] = "future-unrecognized"
        self._json(committed, result)
        with self.assertRaisesRegex(PermissionError, "REPEAT_BINDING_INVALID"):
            self._invoke()
        self.assertEqual(result, p._read(committed))
        self.assertEqual(self.originals, self._protected_bytes())

    def test_missing_completion_alone_never_proves_applied(self):
        self._invoke()
        committed = self._runs()[0] / "committed.json"
        committed.unlink()  # our disposable fixture only
        self._blocked("PARTIAL_ATTEMPT_REQUIRES_REVIEW")

    @scenario("nested_commit_name")
    def test_nested_commit_named_evidence_is_preserved_in_repeat_manifest(self):
        first = self._invoke()
        self.assertEqual(first, self._invoke())
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertTrue(any(name.endswith("synthetic-history/committed.json") for name in first["evidence"]))

    def test_media_authority_reader_uses_current_capture_inside_composed_entry(self):
        from hero_engine.phase6_media_remediation_wait import _readonly_queue_connection
        original = p.preview_local_runtime_migration
        def inspect(*args, **kwargs):
            with closing(_readonly_queue_connection(self.queue)) as connection:
                self.assertEqual(1, connection.execute("SELECT count(*) FROM jobs").fetchone()[0])
            return original(*args, **kwargs)
        with patch.object(p, "preview_local_runtime_migration", side_effect=inspect):
            self.assertEqual("APPLIED_WHILE_PAUSED", self._invoke()["status"])
        self.assertTrue(self.connections)
        self.assertEqual(self.originals, self._protected_bytes())

    def test_protected_change_between_proof_and_pinning_is_rejected(self):
        original = a._load_proof
        target = self.root / "data/hero_engine.db"
        def race(*args, **kwargs):
            proof = original(*args, **kwargs)
            target.write_bytes(b"foreign-change-after-proof")
            self.originals = self._protected_bytes()
            return proof
        with patch.object(a, "_load_proof", side_effect=race):
            self._blocked("PROTECTED_CHANGED_BEFORE_PIN")
        self.assertEqual(b"foreign-change-after-proof", target.read_bytes())

    def test_view_change_during_derivation_is_not_adopted_as_own_preimage(self):
        original = p._local_runtime_migration_candidates
        target = self.root / p.EXECUTIVE_STATUS_PATH
        count = 0
        def race(*args, **kwargs):
            nonlocal count
            result = original(*args, **kwargs)
            count += 1
            if count == 2:  # actual transaction derivation, after preview
                target.write_bytes(b"foreign-view-during-derivation")
            return result
        with patch.object(p, "_local_runtime_migration_candidates", side_effect=race):
            with self.assertRaisesRegex(PermissionError, "PAUSED_APPLICATION_FINALIZATION_FAILED") as rejected:
                self._invoke()
        self.assertIsInstance(rejected.exception.__cause__, PermissionError)
        self.assertEqual("PAUSED_APPLICATION_VIEW_CHANGED_DURING_PREPARATION", str(rejected.exception.__cause__))
        self.assertEqual(self.originals, self._protected_bytes())
        self.assertIsNone(p._PROTECTED_DATABASE_VIEW.get())
        runs = self._runs()
        self.assertEqual(1, len(runs))
        self.assertFalse((runs[0] / "committed.json").exists())
        rollback = p._read(runs[0] / "paused-finalization-failure.json")
        self.assertEqual("ROLLED_BACK", rollback["status"])
        self.assertTrue(rollback["rollback"]["verified"])
        self.assertEqual(b"foreign-view-during-derivation", target.read_bytes())
