"""Native selected manager -> queue/quota -> collector; network simulated."""
import json
import hashlib
import sqlite3
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from jsonschema import Draft202012Validator, ValidationError
from hero_engine import central_manager_phase5 as manager, phase6_pilot as pilot
from hero_engine.queue_phase6 import TransactionalQueue
from hero_engine.google_api_runtime import GoogleOperationDeadline
from hero_engine.phase6_quota import consume_general_quota
from tests import test_audio_static_ready_chain as ready
from tests import test_phase6_pilot as provider


class AudioStaticObserverQueueTests(unittest.TestCase):
    def setUp(self):
        self.owner=ready.AudioStaticReadyChainTests('test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider')
        self.owner.cycle_schema_fixture=getattr(self,'cycle_schema_fixture',False)
        self.addCleanup(self.owner.doCleanups);self.owner.setUp()
        self.owner.test_native_ready_reaches_existing_publication_pipeline_with_simulated_provider()
        self.root=self.owner.root;self.package=self.owner.package
        for name in ('phase6_observer_runtime','phase6_queue_snapshot','zero_cost_guard','own_channel_performance_snapshot',
                     'prediction_record','phase6_diagnostic_decision','phase6_experiment_protocol'):
            shutil.copy2(ready.ROOT/f'schemas/{name}.schema.json',self.root/'schemas')
        shutil.copy2(ready.ROOT/'config/zero-cost-policy.json',self.root/'config')
        shutil.copy2(ready.ROOT/'config/engine.json',self.root/'config')
        secrets=tempfile.TemporaryDirectory(dir=self.root.parent,prefix='owned-token-frontier-')
        self.addCleanup(secrets.cleanup);self.token=Path(secrets.name)/'token.json';self.token.write_text('{}')
        # A fixture observation must precede the actual intelligence clock.
        # Keep the production cutoff guard intact rather than accepting future data.
        self.now=datetime(2026,10,4,18,tzinfo=timezone.utc)
        self.video=json.loads((self.package/'youtube-publication-receipt.json').read_bytes())['video_id']
        self.selection={'package_relative':self.owner.relative,'current_bindings':self.owner.bindings,
            'expected_release_hash':self.owner.binding(self.package/'release_gate.json')['sha256']}

    def call(self, now=None):
        return manager.run_phase6_observer_if_due(self.root,self.token,now=now or self.now,**self.selection)

    def _make_pre_oauth_custody(self):
        from hero_engine.google_api_runtime import GoogleOperationDeadlineExceeded
        from hero_engine import maintenance_protocol as protocol
        def before_oauth(*args, **kwargs):
            kwargs['progress']()
            raise GoogleOperationDeadlineExceeded('Google operation deadline exhausted at oauth.phase6-pilot:before')
        with patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(pilot,'materialize_video_live',side_effect=before_oauth):
            failed=self.call()
        self.assertEqual(failed['status'],'ERROR')
        job=protocol.queue_snapshot(self.root)['jobs'][0]
        return protocol, job

    def test_pre_oauth_maintenance_custody_preserves_queue_and_reserved_quota(self):
        protocol,job=self._make_pre_oauth_custody()
        paths=[self.root/protocol.QUEUE_PATH,self.root/protocol.QUOTA_LEDGER_PATH]
        before=[hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
        queue=protocol.queue_snapshot(self.root)
        custody=protocol._pre_oauth_observer_custody(self.root,database_root=self.root,queue=queue)
        self.assertEqual(set(custody),{job['job_id']})
        self.assertEqual(custody[job['job_id']]['debit_id'],job['checkpoint']['quota_debit']['debit_id'])
        inspection=protocol.inspect_quiescence(self.root,manager_pid=4242,guard_seconds=1800)
        self.assertNotIn('INCOMPLETE_QUOTA_OR_EXTERNAL_EFFECT',inspection['blockers'])
        self.assertNotIn('PROTECTED_JOB_DUE_DURING_MAINTENANCE',inspection['blockers'])
        self.assertNotIn('OPERATIONAL_JOB_DUE_DURING_MAINTENANCE',inspection['blockers'])
        boundary=protocol._paused_cancel_boundary(self.root,database_root=self.root)
        self.assertEqual(boundary['queue_jobs_hash'],queue['jobs_hash'])
        self.assertEqual(inspection['quota']['reserved_count'],1)  # Not falsely consumed.
        self.assertEqual(protocol.queue_snapshot(self.root)['jobs'][0],job)
        self.assertEqual(before,[hashlib.sha256(path.read_bytes()).hexdigest() for path in paths])

    def test_pre_oauth_custody_rejects_unknown_error_lease_and_checkpoint_tamper(self):
        protocol,job=self._make_pre_oauth_custody()
        base=protocol.queue_snapshot(self.root)
        import copy
        variants=[]
        for field,value in [('last_error','ConnectionError:Unknown read outcome'),('lease_owner','active-worker'),
                            ('attempt_count',2),('operation_id','foreign-operation')]:
            changed=copy.deepcopy(base);changed['jobs'][0][field]=value;variants.append(changed)
        changed=copy.deepcopy(base);changed['jobs'][0]['checkpoint']['quota_debit']['units']=1;variants.append(changed)
        changed=copy.deepcopy(base);changed['jobs'][0]['payload']['video_id']='foreign';variants.append(changed)
        for changed in variants:
            with self.subTest(job=changed['jobs'][0]):
                self.assertEqual(protocol._pre_oauth_observer_custody(self.root,database_root=self.root,queue=changed),{})
        with sqlite3.connect(self.root/protocol.QUEUE_PATH) as connection:
            connection.execute('UPDATE jobs SET last_error=? WHERE job_id=?',('ConnectionError:Unknown read outcome',job['job_id']))
        with self.assertRaisesRegex(PermissionError,'CANCEL_RESERVATION'):
            protocol._paused_cancel_boundary(self.root,database_root=self.root)

    def test_pre_oauth_custody_rejects_source_preflight_and_ledger_tamper(self):
        protocol,job=self._make_pre_oauth_custody()
        queue=protocol.queue_snapshot(self.root)
        def custody():
            return protocol._pre_oauth_observer_custody(self.root,database_root=self.root,queue=queue)
        source=self.root/'output/operations/phase6/intelligence/external-read-checkpoints'/job['job_id']/'owned-metrics-source.json'
        source.parent.mkdir(parents=True,exist_ok=True);source.write_text('{}')
        self.assertEqual(custody(),{});source.unlink()
        preflight=self.root/job['checkpoint']['quota_preflight'];raw=preflight.read_bytes()
        preflight.write_bytes(raw+b' ');self.assertEqual(custody(),{});preflight.write_bytes(raw)
        receipt=self.package/'youtube-publication-receipt.json';raw=receipt.read_bytes()
        receipt.write_bytes(raw+b' ');self.assertEqual(custody(),{});receipt.write_bytes(raw)
        with sqlite3.connect(self.root/protocol.QUOTA_LEDGER_PATH) as connection:
            connection.execute('UPDATE general_quota_debits SET units=3 WHERE debit_id=?',(job['checkpoint']['quota_debit']['debit_id'],))
        self.assertEqual(custody(),{})

    def test_native_custody_keeps_incidents_but_rejects_unconfirmed_effect(self):
        from hero_engine import phase5_youtube_publisher as publisher
        receipt=self.package/'youtube-publication-receipt.json'
        value=json.loads(receipt.read_bytes())
        value['steps'].insert(0,{'step':'FAILURE','status':'FAIL','evidence':'Historical transport failure; later chain confirmed'})
        receipt.write_text(json.dumps(value),encoding='utf-8')
        protocol,job=self._make_pre_oauth_custody()
        queue=protocol.queue_snapshot(self.root)
        self.assertIn(job['job_id'],protocol._pre_oauth_observer_custody(self.root,database_root=self.root,queue=queue))
        before=receipt.read_bytes()
        release=json.loads((self.package/'release_gate.json').read_bytes())
        self.assertEqual(publisher._verify_completed_publication_receipt(self.root,self.package,value,release),value)
        self.assertEqual(receipt.read_bytes(),before)
        value['steps'].append({'step':'CAPTIONS_INSERT_BEFORE','status':'NOT_RUN','evidence':'Unconfirmed new intent'})
        with self.assertRaisesRegex(PermissionError,'unresolved effects'):
            publisher._verify_completed_publication_receipt(self.root,self.package,value,release)

    def test_slow_local_admission_precedes_fresh_native_lease(self):
        from hero_engine import phase5_youtube_publisher as publisher
        clock=[0.0]; admissions=[]; original=publisher._validate_current_release
        def slow(*args,**kwargs):
            path=self.root/'output/operations/phase6/runtime/phase6-queue.sqlite3'
            active=[] if not path.is_file() else [j['job_id'] for j in TransactionalQueue(self.root,read_only=True).snapshot()['jobs'] if j['lease_owner']]
            admissions.append(active)
            value=original(*args,**kwargs);clock[0]+=180.0;return value
        target=self.video
        class CurrentYouTube(provider.YouTube):
            def list(self,**kwargs):
                request=super().list(**kwargs)
                if self.resource=='videos':request.response['items'][0]['id']=target
                return request
        def deadline(seconds,*,progress=None):
            return GoogleOperationDeadline(seconds,progress=progress,clock=lambda:clock[0])
        with patch.object(manager.time,'monotonic',side_effect=lambda:clock[0]), \
             patch.object(publisher,'_validate_current_release',side_effect=slow), \
             patch.object(pilot,'GoogleOperationDeadline',side_effect=deadline), \
             patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(manager,'ensure_oauth_session_health',return_value={'status':'HEALTHY'}), \
             patch.object(pilot,'_build_services',return_value=(CurrentYouTube(),provider.Analytics())) as network:
            result=self.call()
        self.assertEqual(result['status'],'COLLECTED',result)
        self.assertEqual(admissions[:4],[[],[],[],[]])
        job=TransactionalQueue(self.root).snapshot()['jobs'][0]
        self.assertEqual(job['state'],'SUCCEEDED');self.assertEqual(job['attempt_count'],1)
        self.assertGreaterEqual(datetime.fromisoformat(job['created_at'].replace('Z','+00:00')),self.now+timedelta(seconds=360))
        self.assertEqual(network.call_count,1)

    def _timeout_before_oauth_then_recover(self, *, consume_before_retry=False):
        clock=[0.0]; calls=[0]; original=manager._materialize_owned_preflight
        def slow(*args,**kwargs):
            value=original(*args,**kwargs);calls[0]+=1
            if calls[0]==1:clock[0]+=300.0
            return value
        target=self.video
        class CurrentYouTube(provider.YouTube):
            def list(self,**kwargs):
                request=super().list(**kwargs)
                if self.resource=='videos':request.response['items'][0]['id']=target
                return request
        def deadline(seconds,*,progress=None):
            return GoogleOperationDeadline(seconds,progress=progress,clock=lambda:clock[0])
        with patch.object(manager.time,'monotonic',side_effect=lambda:clock[0]), \
             patch.object(manager,'_materialize_owned_preflight',side_effect=slow), \
             patch.object(pilot,'GoogleOperationDeadline',side_effect=deadline), \
             patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(manager,'ensure_oauth_session_health',return_value={'status':'HEALTHY'}), \
             patch.object(pilot,'_build_services',return_value=(CurrentYouTube(),provider.Analytics())) as network:
            failed=self.call()
            self.assertEqual(failed['error'],'GoogleOperationDeadlineExceeded:Google operation deadline exhausted at oauth.phase6-pilot:before')
            network.assert_not_called()
            job=TransactionalQueue(self.root).snapshot()['jobs'][0]
            debit=job['checkpoint']['quota_debit']
            if consume_before_retry:
                consume_general_quota(self.root,idempotency_key=debit['idempotency_key'],now=self.now+timedelta(minutes=6))
            recovered=self.call(self.now+timedelta(minutes=15))
            if consume_before_retry:
                self.assertEqual(recovered['status'],'ERROR')
                self.assertIn('exact unused quota reservation',recovered['error']);network.assert_not_called()
            else:
                self.assertEqual(recovered['status'],'COLLECTED',recovered)
                self.assertEqual(network.call_count,1)
                final=TransactionalQueue(self.root).snapshot()['jobs'][0]
                self.assertEqual(final['attempt_count'],2);self.assertEqual(final['state'],'SUCCEEDED')
                self.assertEqual(final['checkpoint']['quota_debit_ids'],[debit['debit_id']])

    def test_exact_pre_oauth_failure_reuses_only_unused_reservation(self):
        self._timeout_before_oauth_then_recover()

    def test_pre_oauth_error_cannot_reuse_consumed_reservation(self):
        self._timeout_before_oauth_then_recover(consume_before_retry=True)

    def test_committed_external_read_is_recovered_without_duplicate_query_or_debit(self):
        target=self.video
        class CurrentYouTube(provider.YouTube):
            def list(self,**kwargs):
                response=super().list(**kwargs)
                if self.resource=='videos':response.response['items'][0]['id']=target
                return response
        with patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(manager,'ensure_oauth_session_health',return_value={'status':'HEALTHY'}), \
             patch.object(pilot,'_build_services',return_value=(CurrentYouTube(),provider.Analytics())) as network:
            with patch.object(manager,'_restore_owned_metrics_views',side_effect=OSError('Injected closure failure after raw source committed')):
                failed=self.call()
            self.assertEqual(failed['status'],'ERROR',failed)
            self.assertIn('Injected closure',failed['error'])
            recovered=self.call(self.now+timedelta(minutes=15))
            self.assertEqual(recovered['status'],'COLLECTED',recovered)
            again=self.call(self.now+timedelta(minutes=16))
            self.assertEqual(again['status'],'NOT_DUE',again)
            self.assertEqual(network.call_count,1)
        jobs=TransactionalQueue(self.root).snapshot()['jobs']
        self.assertEqual(len(jobs),1)
        self.assertEqual(jobs[0]['state'],'SUCCEEDED')
        self.assertEqual(jobs[0]['checkpoint']['quota_debit']['state'],'CONSUMED')
        self.assertEqual(len(jobs[0]['checkpoint']['quota_debit_ids']),1)
        self.assertEqual(jobs[0]['payload']['video_id'],self.video)
        self.assertFalse((self.root/'output/operations/phase6/observer-status.json').exists())
        # A mutated completed snapshot cannot cause a replacement query.
        source=self.root/jobs[0]['checkpoint']['metrics_snapshot'];source.write_bytes(source.read_bytes()+b' ')
        with patch.object(pilot,'materialize_video_live') as collection:
            rejected=self.call(self.now+timedelta(minutes=17))
        collection.assert_not_called();self.assertEqual(rejected['status'],'ERROR')

    def test_unknown_collection_result_cannot_retry_the_same_query(self):
        def unknown(*args, **kwargs):
            kwargs['progress']()
            raise ConnectionError('Unknown read outcome')
        with patch.object(manager,'_quota_usage',return_value={'youtube-general-units-daily':5,'youtube-videos-insert-daily':0}), \
             patch.object(pilot,'materialize_video_live',side_effect=unknown) as collector:
            first=self.call();second=self.call(self.now+timedelta(minutes=15))
        self.assertEqual(first['status'],'ERROR');self.assertEqual(second['status'],'ERROR')
        self.assertIn('outcome unknown',second['error']);self.assertEqual(collector.call_count,1)


class AudioStaticObserverEntryTests(unittest.TestCase):
    def test_partial_selection_and_legacy_schema_remain_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with self.assertRaises(PermissionError):manager.run_phase6_observer_if_due(root,None,current_bindings={})
            with self.assertRaises(PermissionError):manager.run_phase6_observer_if_due(root,None,package_relative=Path('output/production/current'))
        schema=json.loads((ready.ROOT/'schemas/phase6_observer_runtime.schema.json').read_bytes())
        value={'schema_version':'1.0.0','observer_id':'heroverse-own-channel-observer-v1','phase':6,'status':'NOT_DUE',
            'video_id':'different-current','latest_snapshot':None,'next_observation_at':None,'error':None,
            'technical_cost_brl':0,'updated_at':'2026-10-05T18:00:00Z'}
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(value)
        value['schema_version']='1.1.0';Draft202012Validator(schema).validate(value)
