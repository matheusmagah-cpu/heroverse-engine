import copy
import hashlib
import json
import socket
import sqlite3
import subprocess
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.db import ROOT
import hero_engine.modeling_phase4 as modeling
from hero_engine.modeling_phase4 import (
    GOLD_IDS,
    build_channel_model,
    evidence_ref_errors,
    materialize_channel_model,
)


class Phase4ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        resources = ExitStack()
        cls.addClassCleanup(resources.close)
        cls.root = Path(resources.enter_context(tempfile.TemporaryDirectory(prefix="phase4-model-test-"))).resolve()
        phase3_relative = Path("output/observatory/phase3/phase3-2026-09-02-catalog-v2")
        output_relative = Path("output/modeling/phase4/channel-model-v1")
        cls.output_dir = cls.root / output_relative
        inputs = [phase3_relative / name for name in (
            "public_snapshots.json", "cohorts.json", "opening_observations.json",
            "coverage.json", "phase3_summary.json",
        )]
        inputs.extend(Path("data/gold_standard") / video_id / "video_mining.json" for video_id in GOLD_IDS)
        inputs.append(Path("schemas/channel_model.schema.json"))
        # This existing documentary receipt is the fourth integrity-manifest
        # member. Do not seed generated model/results or alter the four-member
        # assertion just because the fixture now has a clean temporary root.
        inputs.append(output_relative / "shared_source_evolution_receipt.json")
        source_bytes = {relative: (ROOT / relative).read_bytes() for relative in inputs}
        original_outputs = {path.name: path.read_bytes()
                            for path in (ROOT / output_relative).iterdir() if path.is_file()}
        for relative, payload in source_bytes.items():
            destination = cls.root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(payload)

        def verify_preserved_sources():
            for relative, expected in source_bytes.items():
                if (ROOT / relative).read_bytes() != expected or (cls.root / relative).read_bytes() != expected:
                    raise AssertionError(f"Phase4 fixture input changed: {relative}")
            current = {path.name: path.read_bytes()
                       for path in (ROOT / output_relative).iterdir() if path.is_file()}
            if current != original_outputs:
                raise AssertionError("Phase4 test changed original output artifacts")

        # LIFO cleanup restores IO patches, proves source preservation, and only
        # then removes this TemporaryDirectory, even if setUpClass/tests fail.
        resources.callback(verify_preserved_sources)
        original_open = Path.open
        original_mkdir = Path.mkdir

        def fixture_open(path, *args, **kwargs):
            if not path.resolve().is_relative_to(cls.root):
                raise AssertionError(f"Phase4 file access outside isolated fixture: {path}")
            return original_open(path, *args, **kwargs)

        def fixture_mkdir(path, *args, **kwargs):
            if not path.resolve().is_relative_to(cls.root):
                raise AssertionError(f"Phase4 directory creation outside isolated fixture: {path}")
            return original_mkdir(path, *args, **kwargs)

        resources.enter_context(patch.object(Path, "open", fixture_open))
        resources.enter_context(patch.object(Path, "mkdir", fixture_mkdir))
        resources.enter_context(patch.object(modeling, "ROOT", cls.root))
        resources.enter_context(patch.object(modeling, "PHASE3_RUN", cls.root / phase3_relative))
        resources.enter_context(patch.object(modeling, "OUTPUT_DIR", cls.output_dir))
        resources.enter_context(patch.object(sqlite3, "connect", side_effect=AssertionError("Phase4 SQLite forbidden")))
        resources.enter_context(patch.object(subprocess, "Popen", side_effect=AssertionError("Phase4 subprocess forbidden")))
        for method in ("connect", "connect_ex"):
            resources.enter_context(patch.object(socket.socket, method, side_effect=AssertionError("Phase4 network forbidden")))
        # Pass explicitly: the production function's default was bound at import
        # and patching OUTPUT_DIR alone would still write into the original root.
        cls.result = materialize_channel_model(cls.output_dir)
        cls.model = json.loads((cls.output_dir / "channel_model.json").read_text(encoding="utf-8"))
        cls.schema = json.loads((cls.root / "schemas/channel_model.schema.json").read_text(encoding="utf-8"))

    def test_model_validates_and_is_not_self_approved(self):
        errors = list(Draft202012Validator(self.schema, format_checker=FormatChecker()).iter_errors(self.model))
        self.assertEqual(errors, [])
        self.assertEqual(self.model["review_status"], "NOT_REVIEWED")
        self.assertEqual(self.result["status"], "AWAITING_REVIEW")
        self.assertEqual(self.result["protected_actions_executed"], [])

    def test_model_is_deterministic_and_replay_preserves_semantic_output(self):
        first = build_channel_model()
        second = build_channel_model()
        self.assertEqual(first, second)
        before = hashlib.sha256((self.output_dir / "channel_model.json").read_bytes()).hexdigest()
        replay = materialize_channel_model(self.output_dir)
        after = hashlib.sha256((self.output_dir / "channel_model.json").read_bytes()).hexdigest()
        self.assertEqual(before, after)
        self.assertEqual(replay["reference_errors"], [])

    def test_exactly_one_evidence_sufficient_long_archetype_and_no_invented_shorts_archetype(self):
        archetypes = self.model["format_archetypes"]
        self.assertEqual([item["archetype_id"] for item in archetypes], ["A-LONG-DIRECT-SPIRITUAL-STAKES-V1"])
        self.assertEqual(self.model["generation_specs"][0]["archetype_id"], archetypes[0]["archetype_id"])
        self.assertTrue(any("Shorts" in item for item in self.model["limitations"]))
        self.assertNotIn("SHORT", archetypes[0]["archetype_id"])

    def test_model_explains_winners_median_and_weak_with_contrary_factors(self):
        cases = self.model["retrospective_validation"]["case_explanations"]
        self.assertEqual({item["video_id"] for item in cases}, set(GOLD_IDS))
        self.assertEqual({item["cohort_kind"] for item in cases}, {"WINNER", "MEDIAN", "WEAK"})
        self.assertTrue(all(item["supporting_factors"] and item["contrary_factors"] for item in cases))
        self.assertEqual(self.model["retrospective_validation"]["metrics"]["opening_holdout_count"], 13)
        self.assertFalse(self.model["retrospective_validation"]["causal_claims_permitted"])

    def test_hook_claim_preserves_counterevidence_and_rejects_superficial_timing_causes(self):
        claims = {item["claim_id"]: item for item in self.model["evidence_matrix"]}
        self.assertTrue(claims["C-HOOK-SEMANTIC"]["contradicting_evidence"])
        self.assertEqual(claims["C-HOOK-SEMANTIC"]["knowledge_status"], "CANDIDATE")
        metrics = self.model["retrospective_validation"]["metrics"]
        self.assertAlmostEqual(metrics["winner_first_speech_median_seconds"], 6.655, places=3)
        self.assertAlmostEqual(metrics["weak_first_speech_median_seconds"], 6.69, places=2)
        self.assertIn("not success invariants", self.model["format_archetypes"][0]["hook_rules"][-1]["description"])

    def test_scores_are_reproducible_indices_not_subjective_probabilities(self):
        scores = self.model["scores"]
        expected_repeatability = 0.35 * 1.0 + 0.25 * ((1 / 6 + 4 / 6) / 2) + 0.25 * 1.0 + 0.15 * (13 / 24)
        expected_coverage = (4 * 1.0 + 13 * 0.55 + 7 * 0.25) / 24
        self.assertAlmostEqual(scores["format_repeatability_score"]["value"], expected_repeatability, places=6)
        self.assertAlmostEqual(scores["evidence_confidence_score"]["value"], expected_coverage, places=6)
        self.assertEqual(scores["cross_channel_validation_score"]["value"], 0.0)
        self.assertEqual(scores["rpm_evidence_score"]["value"], 0.0)
        self.assertIn("not a performance probability", " ".join(scores["format_repeatability_score"]["limitations"]))

    def test_every_hypothesis_is_falsifiable_candidate_with_support_and_contradiction(self):
        for hypothesis in self.model["hypotheses"]:
            self.assertEqual(hypothesis["status"], "CANDIDATE")
            self.assertTrue(hypothesis["falsification_condition"])
            self.assertTrue(hypothesis["supporting_evidence"])
            self.assertTrue(hypothesis["contradicting_evidence"])
            self.assertTrue(hypothesis["test_design"])

    def test_rpm_and_revenue_cannot_be_imputed_by_schema(self):
        self.assertIsNone(self.model["economics"]["actual_rpm"])
        self.assertIsNone(self.model["economics"]["actual_revenue"])
        self.assertFalse(self.model["economics"]["decision_use_permitted"])
        broken = copy.deepcopy(self.model)
        broken["economics"]["actual_rpm"] = 9.99
        self.assertTrue(list(Draft202012Validator(self.schema).iter_errors(broken)))

    def test_generation_spec_enforces_rights_originality_and_protected_actions(self):
        spec = self.model["generation_specs"][0]
        self.assertEqual(spec["clip_policy"]["percentage_rule"], "NONE; no modification percentage guarantees originality or rights.")
        self.assertIn("Ads", spec["excluded_actions"])
        self.assertIn("spend", spec["excluded_actions"])
        self.assertTrue(any("rights" in item.lower() for item in spec["quality_gates"]))
        prohibited = " ".join(item["description"] for item in self.model["format_archetypes"][0]["prohibited"])
        self.assertIn("exact title suffix", prohibited)
        self.assertIn("Content ID", prohibited)

    def test_all_evidence_references_resolve(self):
        self.assertEqual(evidence_ref_errors(self.model), [])
        matrix = json.loads((self.output_dir / "evidence_matrix.json").read_text(encoding="utf-8"))
        self.assertEqual(matrix["reference_errors"], [])
        self.assertEqual(matrix["input_hashes"]["phase3_summary"], hashlib.sha256((self.root / "output/observatory/phase3/phase3-2026-09-02-catalog-v2/phase3_summary.json").read_bytes()).hexdigest())

    def test_integrity_manifest_matches_every_phase4_artifact(self):
        manifest = json.loads((self.output_dir / "integrity_manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["item_count"], 4)
        for item in manifest["entries"]:
            path = self.root / item["artifact"]
            self.assertTrue(path.resolve().is_relative_to(self.root))
            self.assertEqual(path.stat().st_size, item["size_bytes"])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), item["sha256"])


if __name__ == "__main__":
    unittest.main()
