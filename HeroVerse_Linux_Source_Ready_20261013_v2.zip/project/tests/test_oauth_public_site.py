from __future__ import annotations

import builtins
import io
import json
import os
import socket
import sqlite3
import subprocess
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator

from hero_engine.oauth_public_site import audit_oauth_public_site


ROOT = Path(__file__).resolve().parents[1]


class OAuthPublicSiteTests(unittest.TestCase):
    def test_site_package_is_complete_truthful_public_and_verified(self) -> None:
        # This audits the copied public package, not today's deployment or OAuth grant.
        with tempfile.TemporaryDirectory(prefix="oauth-public-site-isolated-") as folder:
            root = Path(folder).resolve()
            sources = [
                "deployment/oauth-compliance/" + page
                for page in ("index.html", "privacy.html", "terms.html", "styles.css")
            ] + [
                "schemas/oauth_public_site_readiness.schema.json",
                "schemas/oauth_public_site_deployment_receipt.schema.json",
                "output/integrations/youtube/heroverse/oauth-public-site-deployment-receipt.json",
            ]
            for relative in sources:
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / relative).read_bytes())
            violations = []
            written = []

            def checked_open(original):
                def open_local(file, mode="r", *args, **kwargs):
                    path = Path(os.fsdecode(file)).resolve()
                    if not path.is_relative_to(root):
                        violations.append(str(path))
                        raise AssertionError("OAuth package test attempted non-fixture IO")
                    if isinstance(mode, int):
                        writable = bool(mode & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
                    else:
                        writable = any(flag in mode for flag in "wax+")
                    if writable:
                        written.append(path.relative_to(root).as_posix())
                    return original(file, mode, *args, **kwargs)
                return open_local

            with ExitStack() as guards:
                for module, name in ((builtins, "open"), (io, "open"), (os, "open")):
                    guards.enter_context(patch.object(module, name, checked_open(getattr(module, name))))
                for module, name in ((socket, "socket"), (socket, "create_connection"), (subprocess, "Popen"), (os, "system"), (sqlite3, "connect")):
                    guards.enter_context(patch.object(module, name, side_effect=AssertionError("External action forbidden in package test")))
                report = audit_oauth_public_site(root, observed_at="2026-09-03T22:30:00Z")
                report_relative = "output/integrations/youtube/heroverse/oauth-public-site-readiness.json"
                self.assertEqual(report, json.loads((root / report_relative).read_text(encoding="utf-8")))
                schema = json.loads((root / "schemas/oauth_public_site_readiness.schema.json").read_text(encoding="utf-8"))
            self.assertEqual([], violations)
            self.assertEqual([report_relative], written)
        Draft202012Validator(schema).validate(report)
        self.assertEqual("BLOCKED", report["status"])
        self.assertTrue(report["deployment_permitted"])
        self.assertTrue(report["site_deployment_ready"])
        self.assertFalse(report["oauth_brand_verification_ready"])
        statuses = {item["check"]: item["status"] for item in report["automatic_checks"]}
        self.assertEqual("PASS", statuses["homepage_describes_functionality"])
        self.assertEqual("PASS", statuses["privacy_discloses_google_data"])
        self.assertEqual("PASS", statuses["required_scopes_disclosed"])
        self.assertEqual("PASS", statuses["public_identity_values_resolved"])
        self.assertEqual("PASS", statuses["search_console_property_ownership"])
        self.assertEqual("BLOCKED", statuses["oauth_dns_domain_property_ownership"])
        self.assertEqual("PASS", statuses["public_https_deployment"])
        self.assertEqual(4, len(report["files"]))
        self.assertEqual(4, len(report["source_urls"]))


if __name__ == "__main__":
    unittest.main()
