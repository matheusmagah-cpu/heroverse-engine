"""Offline incident-flow checks; all credentials and responses are synthetic."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs

from hero_engine import oauth_refresh_diagnostic as m
from hero_engine.youtube_integration import INTEGRATION_SCOPES


class DiagnosticFlowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='oauth-diagnostic-test-')
        self.addCleanup(self.temporary.cleanup)
        parent = Path(self.temporary.name)
        self.root = parent / 'project'
        self.area = self.root / 'output/integrations/youtube/heroverse'
        self.area.mkdir(parents=True)
        self.token_path = parent / 'synthetic-token.json'
        self.token_bytes = json.dumps({
            'token_uri': m.ENDPOINT,
            'token': 'synthetic-old-access-private',
            'refresh_token': 'synthetic-refresh-private',
            'client_id': 'synthetic-client-private',
            'client_secret': 'synthetic-client-secret-private',
            'rapt_token': 'synthetic-rapt-private',
            'scopes': list(INTEGRATION_SCOPES),
        }).encode()
        self.token_path.write_bytes(self.token_bytes)
        self.token_sha = hashlib.sha256(self.token_bytes).hexdigest()
        self.failure_path = self.area / 'oauth-noninteractive-refresh-receipt.json'
        self.failure_bytes = json.dumps({
            'token_sha256': self.token_sha,
            'status': 'FAIL',
            'failure_code': 'REFRESH_FAILED',
        }).encode()
        self.failure_path.write_bytes(self.failure_bytes)
        self.failure_sha = hashlib.sha256(self.failure_bytes).hexdigest()

    def run_diagnostic(self, output_name, **overrides):
        options = {
            'expected_token_sha256': self.token_sha,
            'expected_failure_sha256': self.failure_sha,
            'output_name': output_name,
        }
        options.update(overrides)
        return m.diagnose(self.root, self.token_path, **options)

    def assert_sources_and_authority(self, report, name):
        self.assertEqual(self.token_bytes, self.token_path.read_bytes())
        self.assertEqual(self.failure_bytes, self.failure_path.read_bytes())
        self.assertTrue(report['source_unchanged_at_end'])
        self.assertEqual(1, report['request_attempts'])
        self.assertEqual(0, report['youtube_api_calls'])
        for field in ('token_written', 'monitor_state_changed',
                      'channel_identity_verified', 'publication_authorized'):
            self.assertIs(False, report[field])
        output = self.area / name
        self.assertEqual({'started.json', 'report.json'}, {p.name for p in output.iterdir()})
        self.assertEqual(report, json.loads((output / 'report.json').read_bytes()))
        persisted = b''.join(p.read_bytes() for p in output.iterdir())
        for secret in ('synthetic-old-access-private', 'synthetic-new-access-private',
                       'synthetic-refresh-private', 'synthetic-client-private',
                       'synthetic-client-secret-private', 'synthetic-provider-text-private',
                       'synthetic-rapt-private'):
            self.assertNotIn(secret.encode(), persisted)

    def test_success_is_in_memory_only_and_reentry_or_bad_pin_stops_before_post(self):
        response = SimpleNamespace(status=200, data=json.dumps({
            'access_token': 'synthetic-new-access-private',
            'expires_in': 3600, 'token_type': 'Bearer',
        }).encode())
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(m, '_post_without_sdk_logging', return_value=response) as post, \
                patch('socket.create_connection', side_effect=AssertionError('network forbidden')), \
                contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            report = self.run_diagnostic('success-fixture')
            post.assert_called_once()
            request = post.call_args.kwargs
            self.assertEqual(m.ENDPOINT, request['url'])
            self.assertEqual('POST', request['method'])
            self.assertEqual(30, request['timeout'])
            self.assertIs(False, request['allow_redirects'])
            self.assertEqual(['synthetic-rapt-private'],
                parse_qs(request['body'].decode('ascii'))['rapt'])
            with self.assertRaises(FileExistsError):
                self.run_diagnostic('success-fixture')
            with self.assertRaises(m.DiagnosticBoundaryError):
                self.run_diagnostic('bad-pin-fixture', expected_token_sha256='0' * 64)
            post.assert_called_once()
        self.assertEqual('', stdout.getvalue())
        self.assertEqual('', stderr.getvalue())
        self.assertFalse((self.area / 'bad-pin-fixture').exists())
        self.assertEqual('TOKEN_REFRESH_SUCCEEDED_IN_MEMORY_ONLY', report['status'])
        self.assertEqual(200, report['http_status'])
        self.assert_sources_and_authority(report, 'success-fixture')

    def test_transient_provider_error_keeps_first_cause_without_retry_or_recovery(self):
        response = SimpleNamespace(status=503, data=json.dumps({
            'error': 'temporarily_unavailable',
            'error_description': 'synthetic-provider-text-private',
            'access_token': 'synthetic-new-access-private',
        }).encode())
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(m, '_post_without_sdk_logging', return_value=response) as post, \
                patch('socket.create_connection', side_effect=AssertionError('network forbidden')), \
                contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            report = self.run_diagnostic('transient-fixture')
            post.assert_called_once()
        self.assertEqual('', stdout.getvalue())
        self.assertEqual('', stderr.getvalue())
        self.assertEqual('REFRESH_DIAGNOSED_NOT_RECOVERED', report['status'])
        self.assertEqual(503, report['http_status'])
        self.assertEqual('temporarily_unavailable', report['diagnosis']['oauth_error_code'])
        self.assertIs(True, report['diagnosis']['provider_retryable'])
        self.assertIs(False, report['diagnosis']['revocation_confirmed'])
        self.assert_sources_and_authority(report, 'transient-fixture')


if __name__ == '__main__':
    unittest.main()
