"""A11 exclusive transaction fixtures; never run a real timeline or source QA.

Pinned A10/V3 JSON provides historical shapes. Every mutated byte and every
commit lives in a TemporaryDirectory; build and source-replay are identified
seams. The real writer, silence verifier, hash reader and dependency guards run.
"""
import copy
from contextlib import contextmanager, redirect_stdout
import importlib.util
import io
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_static_sources as sources
from tests import test_phase6_av_bound_asset_use_timeline as a10_harness

ROOT = Path(__file__).absolute().parents[1]
RUNNER = ROOT / "output/qa/phase6/diagnostics/test-questions-v1/build_bound_question_timeline.py"
spec = importlib.util.spec_from_file_location("bound_question_timeline_transaction_fixture", RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
V3_PINS = {
    runner.INPUT_PATH: "3e74c984f2f76fb8d74071b0879f34fa71cd1aaa59f2ff3f84b1cf5b8e792ef9",
    runner.INSPECTION_PATH: "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30",
    runner.USE_RECEIPT: "984b972d3454e8a14c8fbfc218564cda2a1eaf7478da1ea9cf89e6b2da1e0ddd",
}
silence = a10_harness.a9_harness.runner
writer_module = a10_harness.writer_harness.registration


class TransactionFixture:
    """Not a TestCase and never a source/rights/admission proof."""
    def __init__(self, base, previous, input_value, inspection, receipt):
        self.temp = tempfile.TemporaryDirectory(prefix="A11-TRANSACTION-FIXTURE-")
        self.root = Path(self.temp.name) / "workspace"
        self.root.mkdir()
        self.base, self.previous = copy.deepcopy(base), copy.deepcopy(previous)
        self.pins, self.code_pins, self.materializer_pins = {}, {}, {}
        for name in sorted(set(runner.PINS) | set(runner.CODE_PATHS) | set(runner.USE_MATERIALIZER_CODE_PATHS)):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            raw = sources._canonical(self.base if name == runner.BASE else self.previous) if name in (runner.BASE, runner.PREVIOUS) else ("NONEXECUTABLE FIXTURE CODE " + name).encode()
            path.write_bytes(raw)
            digest = sources._sha(raw)
            if name in runner.PINS: self.pins[name] = digest
            if name in runner.CODE_PATHS: self.code_pins[name] = digest
            if name in runner.USE_MATERIALIZER_CODE_PATHS: self.materializer_pins[name] = digest
        self.dependency = self.root / "fixture-source.txt"
        self.dependency.write_bytes(b"EXPLICIT LOCAL BYTE RECHECK FIXTURE")
        self.external = self.root.parent / "allowed-fixture-decoder.bin"
        self.external.write_bytes(b"EXPLICIT EXTERNAL DEPENDENCY FIXTURE")
        self.external_pins = {str(self.external): sources._sha(self.external.read_bytes())}
        self.textwrap = self.root.parent / "fixture-textwrap.py"
        self.textwrap.write_bytes(b"EXPLICIT TEXTWRAP DEPENDENCY FIXTURE")
        self.textwrap_pin = {"path": str(self.textwrap), "sha256": av.bytes_sha(self.textwrap.read_bytes())}
        self.model_pins = {}
        self.directory = self.root / runner.USES_BASE
        self.directory.mkdir(parents=True)
        self.input_value = copy.deepcopy(input_value)
        self.input_sha = self.persist(runner.INPUT_PATH, self.input_value)
        self.proof = copy.deepcopy(inspection)
        self.proof["input_binding"] = {"path": runner.INPUT_PATH, "sha256": self.input_sha}
        self.proof["dependency_bindings"] = [self.dependency_binding(self.dependency), self.dependency_binding(self.external)]
        inspection_sha = self.persist(runner.INSPECTION_PATH, self.proof)
        self.use_receipt = copy.deepcopy(receipt)
        self.use_receipt.update(input_binding=copy.deepcopy(self.proof["input_binding"]),
            inspection_binding={"path": runner.INSPECTION_PATH, "sha256": inspection_sha},
            implementation_pins=copy.deepcopy(self.materializer_pins),
            dependency_bindings=[self.dependency_binding(self.dependency), self.dependency_binding(self.external)])
        identity = {key: self.use_receipt[key] for key in ("version", "input_binding", "implementation_pins")}
        self.use_receipt["materialization_id"] = "static-asset-uses-v3-materialization-" + sources._sha(sources._canonical(identity))[:24]
        self.use_claim = {key: copy.deepcopy(self.use_receipt[key]) for key in
            ("kind", "version", "materialization_id", "started_at", "input_binding", "implementation_pins", "authority", "technical_cost_brl")}
        self.use_claim["status"] = "CLAIMED_NOT_MATERIALIZED"
        self.use_receipt["claim_binding"] = {"path": runner.USES_BASE + "/claim.json", "sha256": self.persist(runner.USES_BASE + "/claim.json", self.use_claim)}
        self.receipt_sha = self.persist(runner.USE_RECEIPT, self.use_receipt)
        self.bundle = runner.make_bundle(self.base, {"path": runner.INPUT_PATH, "sha256": "sha256:" + self.input_sha})
        self.argument = self.root / Path(runner.BASE).parent / (self.bundle["arguments_id"] + ".json")
        self.claim_directory = self.root / runner.CLAIM_DIRECTORY
        self.receipt = self.root / runner.RECEIPT
        self.current = copy.deepcopy(previous)
        self.current.update(schema_version="1.10.0", timeline_version="phase6-av-timeline-v11",
            timeline_id="phase6-av-timeline-" + "f" * 24, inputs=copy.deepcopy(self.bundle["arguments"]))
        for row in self.current["permitted_silence_spans"]:
            if row["reason"] in ("LOCKED_HOOK_PAD", "MECHANICAL_GRID_PAD"):
                row["evidence_ref"] = av.canonical_sha(self.current["inputs"])
        self.refresh_use_evidence()
        self.current["implementation"] = {"path": runner.CODE_PATHS[0], "sha256": "sha256:" + self.code_pins[runner.CODE_PATHS[0]]}
        self.current["implementation_dependencies"] = []
        for ordinal in range(19):
            path = self.root / "fixture-code" / (str(ordinal) + ".py")
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(("NONEXECUTABLE FIXTURE DEPENDENCY " + str(ordinal)).encode())
            self.current["implementation_dependencies"].append({"path": path.relative_to(self.root).as_posix(), "sha256": av.bytes_sha(path.read_bytes())})
        self.implementation = self.root / "fixture-code/0.py"
        self.current["implementation_dependencies"].append(copy.deepcopy(self.textwrap_pin))
        self.current["source_file_bindings"] = [{"path": self.dependency.relative_to(self.root).as_posix(),
            "sha256": av.bytes_sha(self.dependency.read_bytes()), "size_bytes": self.dependency.stat().st_size}]
        self.timeline = self.root / Path(runner.PREVIOUS).parent / (self.current["timeline_id"] + ".json")
        self.build_calls = 0
        self.rechecks = []

    def __enter__(self): return self
    def __exit__(self, *_args): self.temp.cleanup()

    def persist(self, name, value):
        raw = sources._canonical(value)
        (self.root / name).write_bytes(raw)
        return sources._sha(raw)

    @staticmethod
    def dependency_binding(path):
        raw = path.read_bytes()
        return {"path": str(path), "sha256": sources._sha(raw), "size_bytes": len(raw)}

    def refresh_use_evidence(self):
        proof = self.proof
        self.current["literal_asset_use_evidence"] = {
            "adapter_version": runner.joiner.VERSION, "scope": "UNTIMED_ASSET_USE_METADATA_ONLY",
            "source_binding": {"path": runner.INPUT_PATH, "sha256": "sha256:" + self.input_sha},
            "inspection_sha256": av.canonical_sha(proof), "use_rows_sha256": av.canonical_sha(proof["uses"]),
            "effective_rows_sha256": proof["visual_amendment_evidence"]["effective_rows_sha256"],
            "source_count": 27, "use_count": 29, "unique_png_content_count": 26, "lineage_count": 3, "visual_state_count": 100,
            "bound_visual_state_ids": list(runner.joiner.COVERED),
            "remaining_unbound_visual_state_ids": copy.deepcopy(proof["remaining_unbound_visual_state_ids"]),
            "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
            "authority": dict(runner.joiner.AUTHORITY), "technical_cost_brl": 0}
        self.current["question_case_amendment_evidence"] = {
            "projection_binding": copy.deepcopy(runner.case.PROJECTION_BINDING),
            "prior_projection_binding": copy.deepcopy(runner.case.legacy.PROJECTION_BINDING),
            "inspection_sha256": proof["visual_amendment_evidence"]["inspection_sha256"],
            "effective_rows_sha256": proof["visual_amendment_evidence"]["effective_rows_sha256"],
            "changed_state_count": 2, "changed_string_count": 3, "unmodified_state_count": 98,
            "adapter_version": runner.case.VERSION, "amendment_binding": copy.deepcopy(runner.case.AMENDMENT_BINDING),
            "case_staging_binding": copy.deepcopy(runner.case.STAGING_BINDING),
            "case_reconciliation_binding": copy.deepcopy(runner.case.RECONCILIATION_BINDING),
            "prior_amendment_inspection_sha256": self.previous["visual_amendment_evidence"]["inspection_sha256"],
            "decision_reference_scope": runner.case.DECISION_REFERENCE_SCOPE, "static_proof_scope": runner.case.REPLAY_SCOPE,
            "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False}

    def build(self, *_args, **_kwargs):
        self.build_calls += 1
        return copy.deepcopy(self.current)

    def source_recheck(self, root, proofs):
        # Explicit transaction seam: real byte guard, no source inspector/model.
        if root != self.root or len(proofs) != 1 or av.canonical_sha(proofs[0]) != av.canonical_sha(self.proof):
            raise AssertionError("fixture replay must be independently correlated with pinned proof")
        reader = sources._Reader(root)
        runner.uses._dependencies(reader, proofs[0]["dependency_bindings"])
        self.rechecks.append((self.timeline.exists(), self.receipt.exists()))

    @contextmanager
    def environment(self, *, build=None, writer=None):
        def module(path, _name):
            if path == runner.HELPER: return silence
            if path == runner.WRITER: return SimpleNamespace(immutable=writer or writer_module.immutable)
            raise AssertionError("unexpected module")
        with mock.patch.object(runner, "ROOT", self.root), mock.patch.object(runner, "PINS", self.pins), \
             mock.patch.object(writer_module, "ROOT", self.root), mock.patch.object(runner, "_module", side_effect=module), \
             mock.patch.object(av, "build", side_effect=build or self.build), \
             mock.patch.object(av, "CAPTION_TEXTWRAP_BINDING", self.textwrap_pin), \
             mock.patch.object(sources, "EXTERNAL_DEPENDENCY_PINS", self.external_pins), \
             mock.patch.object(runner.uses.question, "MODEL_PINS", self.model_pins), \
             mock.patch.object(runner.uses, "recheck_asset_use_dependencies", side_effect=self.source_recheck), \
             mock.patch.object(runner.uses, "inspect_static_asset_uses", side_effect=AssertionError("no source inspection")), \
             mock.patch.object(sources, "_png", side_effect=AssertionError("no image decode")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no process/inference/render")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("no network")), redirect_stdout(io.StringIO()):
            yield

    def execute(self, *, build=None, writer=None, commit=False, **overrides):
        with self.environment(build=build, writer=writer):
            return runner.execute(overrides.get("code_pins", self.code_pins), input_sha=overrides.get("input_sha", self.input_sha),
                receipt_sha=overrides.get("receipt_sha", self.receipt_sha), commit=commit)


class BoundQuestionTimelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = {RUNNER: RUNNER.read_bytes(), Path(__file__): Path(__file__).read_bytes()}
        reader = sources._Reader(ROOT)
        cls.base = sources._json(reader.read(runner.BASE, runner.PINS[runner.BASE]))
        cls.previous = sources._json(reader.read(runner.PREVIOUS, runner.PINS[runner.PREVIOUS]))
        cls.v3 = {name: sources._json(reader.read(name, digest)) for name, digest in V3_PINS.items()}

    @classmethod
    def tearDownClass(cls):
        for path, raw in cls.snapshot.items():
            if path.read_bytes() != raw: raise AssertionError("focal source drift: " + str(path))
        reader = sources._Reader(ROOT)
        for name, digest in {runner.BASE: runner.PINS[runner.BASE], runner.PREVIOUS: runner.PINS[runner.PREVIOUS], **V3_PINS}.items():
            reader.read(name, digest)

    def fixture(self):
        return TransactionFixture(self.base, self.previous, self.v3[runner.INPUT_PATH],
            self.v3[runner.INSPECTION_PATH], self.v3[runner.USE_RECEIPT])

    def test_preflight_reads_real_shape_without_build_or_writes(self):
        with self.fixture() as f:
            before = {str(p): p.read_bytes() for p in f.root.rglob("*") if p.is_file()}
            result = f.execute(build=mock.Mock(side_effect=AssertionError("preflight cannot build")))
            self.assertEqual(result["mode"], "PREFLIGHT_ONLY_NO_WRITE")
            self.assertFalse(result["publication_authorized"])
            self.assertEqual(result["arguments_sha256"], sources._sha(sources._canonical(f.bundle)))
            self.assertEqual(before, {str(p): p.read_bytes() for p in f.root.rglob("*") if p.is_file()})

    def test_preservation_silence_and_independent_inspection_hashes(self):
        with self.fixture() as f:
            runner.validate_result(f.previous, f.current, f.bundle, f.proof, silence.validate_silence)
            for mutation in ("clock", "pause", "union", "silence_ref", "use_sha", "case_sha", "coupled_rows_sha", "case_count", "remaining", "authority"):
                bad = copy.deepcopy(f.current)
                if mutation == "clock": bad["clock"]["sample_rate"] = 1
                elif mutation == "pause": bad["pause_measurements"] = [{"fixture_only": "invented pause"}]
                elif mutation == "union": bad["temporal_evidence_assessment"]["temporal_target_unit_ids"].pop()
                elif mutation == "silence_ref": bad["permitted_silence_spans"][0]["evidence_ref"] = "wrong"
                elif mutation == "use_sha": bad["literal_asset_use_evidence"]["inspection_sha256"] = "sha256:" + "0" * 64
                elif mutation == "case_sha": bad["question_case_amendment_evidence"]["inspection_sha256"] = "sha256:" + "0" * 64
                elif mutation == "coupled_rows_sha":
                    for key in ("literal_asset_use_evidence", "question_case_amendment_evidence"):
                        bad[key]["effective_rows_sha256"] = "sha256:" + "0" * 64
                elif mutation == "case_count": bad["question_case_amendment_evidence"]["changed_string_count"] = 2
                elif mutation == "remaining": bad["literal_asset_use_evidence"]["remaining_unbound_visual_state_ids"].pop()
                else: bad["literal_asset_use_evidence"]["authority"]["publication"] = True
                with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                    runner.validate_result(f.previous, bad, f.bundle, f.proof, silence.validate_silence)

    def test_commit_once_tracks_every_write_and_preserves_historical_bytes(self):
        with self.fixture() as f:
            before = {(f.root / name): (f.root / name).read_bytes() for name in (runner.BASE, runner.PREVIOUS, *V3_PINS)}
            result = f.execute(commit=True)
            self.assertEqual(f.build_calls, 1)
            self.assertEqual(result["status"], "BLOCKED_INCOMPLETE")
            self.assertEqual(result["sha256"], sources._sha(f.receipt.read_bytes()))
            report = sources._json(f.receipt.read_bytes())
            self.assertEqual((report["literal_asset_use_evidence"]["use_count"], len(report["literal_asset_use_evidence"]["remaining_unbound_visual_state_ids"])), (29, 71))
            self.assertTrue(all(value is False for value in report["authority"].values()))
            self.assertIn((False, False), f.rechecks)
            self.assertIn((True, False), f.rechecks)
            self.assertEqual(f.rechecks[-1], (True, True))
            self.assertEqual(before, {path: path.read_bytes() for path in before})
            self.assertEqual({p.name for p in f.claim_directory.iterdir()}, {"claim.json"})
            with self.assertRaisesRegex(ValueError, "checkpoint already exists"):
                f.execute(commit=True, build=mock.Mock(side_effect=AssertionError("no second build")))
            self.assertEqual(f.build_calls, 1)

    def test_failed_build_and_empty_or_corrupt_claim_are_not_retry_permission(self):
        with self.fixture() as f:
            rejected = mock.Mock(side_effect=ValueError("fixture build rejected"))
            with self.assertRaisesRegex(ValueError, "fixture build rejected"): f.execute(commit=True, build=rejected)
            rejected.assert_called_once()
            original = f.argument.read_bytes()
            self.assertFalse(f.timeline.exists())
            self.assertFalse(f.receipt.exists())
            with self.assertRaisesRegex(ValueError, "checkpoint already exists"): f.execute(commit=True)
            self.assertEqual(f.argument.read_bytes(), original)
        for content in (None, b"corrupt fixture claim"):
            with self.subTest(content=content), self.fixture() as f:
                f.claim_directory.mkdir()
                if content is not None: (f.claim_directory / "claim.json").write_bytes(content)
                with self.assertRaisesRegex(ValueError, "checkpoint already exists"): f.execute(commit=True)
                self.assertEqual(f.build_calls, 0)
                self.assertFalse(f.argument.exists())

    def test_partial_argument_and_persisted_timeline_never_rebuild(self):
        for kind in ("arguments", "timeline"):
            with self.subTest(kind=kind), self.fixture() as f:
                target = f.argument if kind == "arguments" else f.timeline
                original = sources._canonical(f.bundle if kind == "arguments" else f.current)
                target.write_bytes(original)
                with self.assertRaisesRegex(ValueError, "checkpoint"):
                    f.execute(commit=True, build=mock.Mock(side_effect=AssertionError("no rebuild")))
                self.assertEqual(target.read_bytes(), original)
                self.assertFalse(f.claim_directory.exists())

    def test_racing_claimant_wins_without_a_second_effect(self):
        with self.fixture() as f:
            original = runner._recheck
            def claimant(reader):
                original(reader)
                if not f.claim_directory.exists():
                    f.claim_directory.mkdir()
                    (f.claim_directory / "claim.json").write_bytes(b"OTHER EXPLICIT FIXTURE CLAIMANT")
            with mock.patch.object(runner, "_recheck", side_effect=claimant), self.assertRaises(FileExistsError):
                f.execute(commit=True)
            self.assertEqual((f.claim_directory / "claim.json").read_bytes(), b"OTHER EXPLICIT FIXTURE CLAIMANT")
            self.assertFalse(f.argument.exists())
            self.assertEqual(f.build_calls, 0)

    def test_external_pin_types_and_receipt_tamper_fail_before_claim(self):
        with self.fixture() as f:
            for override in ({"code_pins": {}}, {"input_sha": "0" * 64}, {"receipt_sha": "0" * 64}, {"input_sha": "sha256:" + f.input_sha}):
                with self.subTest(override=override), self.assertRaises(ValueError): f.execute(commit=True, **override)
                self.assertFalse(f.claim_directory.exists())
            for value in (1, None):
                with self.subTest(commit=value), self.assertRaises(ValueError): f.execute(commit=value)
            (f.root / runner.USE_RECEIPT).write_bytes((f.root / runner.USE_RECEIPT).read_bytes() + b"\n")
            with self.assertRaises(ValueError): f.execute(commit=True)
            self.assertFalse(f.claim_directory.exists())

    def test_repinned_malformed_receipt_or_claim_cannot_skip_correlations(self):
        for mutation in ("empty_pins", "missing_pin", "materialization_id", "claim_status", "claim_input", "claim_authority", "claim_started", "claim_extra"):
            with self.subTest(mutation=mutation), self.fixture() as f:
                if mutation == "empty_pins": f.use_receipt["implementation_pins"] = {}
                elif mutation == "missing_pin": f.use_receipt["implementation_pins"].pop(next(iter(f.materializer_pins)))
                elif mutation == "materialization_id": f.use_receipt["materialization_id"] = "wrong"
                else:
                    if mutation == "claim_status": f.use_claim["status"] = "APPROVED"
                    elif mutation == "claim_input": f.use_claim["input_binding"]["sha256"] = "0" * 64
                    elif mutation == "claim_authority": f.use_claim["authority"]["render"] = True
                    elif mutation == "claim_started": f.use_claim["started_at"] = "2026-01-01T00:00:00Z"
                    else: f.use_claim["new_permission"] = True
                    f.use_receipt["claim_binding"]["sha256"] = f.persist(runner.USES_BASE + "/claim.json", f.use_claim)
                f.receipt_sha = f.persist(runner.USE_RECEIPT, f.use_receipt)
                with self.assertRaises(ValueError): f.execute(commit=True)
                self.assertFalse(f.claim_directory.exists())
                self.assertEqual(f.build_calls, 0)

    def test_dependency_drift_during_claim_stops_before_arguments(self):
        with self.fixture() as f:
            def writer(path, raw):
                result = writer_module.immutable(path, raw)
                if path == f.claim_directory / "claim.json": f.dependency.write_bytes(b"changed fixture")
                return result
            with self.assertRaises(ValueError): f.execute(commit=True, writer=writer)
            self.assertTrue((f.claim_directory / "claim.json").exists())
            self.assertFalse(f.argument.exists())
            self.assertEqual(f.build_calls, 0)

    def test_postbuild_implementation_textwrap_external_and_source_drift(self):
        for name in ("implementation", "textwrap", "external", "dependency"):
            with self.subTest(name=name), self.fixture() as f:
                def build(*args, **kwargs):
                    path = getattr(f, name)
                    path.write_bytes(path.read_bytes() + b"\n")
                    return f.build(*args, **kwargs)
                with self.assertRaises(ValueError): f.execute(commit=True, build=build)
                self.assertEqual(f.build_calls, 1)
                self.assertFalse(f.timeline.exists())
                self.assertFalse(f.receipt.exists())

    def test_drift_at_timeline_or_receipt_write_is_reported_and_blocks_reexecution(self):
        for stage in ("timeline", "receipt", "receipt_bytes", "claim_inventory", "uses_inventory"):
            with self.subTest(stage=stage), self.fixture() as f:
                def writer(path, raw):
                    result = writer_module.immutable(path, raw)
                    if stage == "timeline" and path == f.timeline: f.implementation.write_bytes(b"changed code fixture")
                    elif stage == "receipt" and path == f.receipt: f.dependency.write_bytes(b"changed source fixture")
                    elif stage == "receipt_bytes" and path == f.receipt: path.write_bytes(raw + b"\n")
                    elif stage == "claim_inventory" and path == f.timeline: (f.claim_directory / "unrecognized").write_bytes(b"fixture")
                    elif stage == "uses_inventory" and path == f.timeline: (f.directory / "unrecognized").write_bytes(b"fixture")
                    return result
                with self.assertRaises(ValueError): f.execute(commit=True, writer=writer)
                self.assertTrue(f.timeline.exists())
                with self.assertRaisesRegex(ValueError, "checkpoint already exists"): f.execute(commit=True)
                self.assertEqual(f.build_calls, 1)

    def test_twenty_one_mib_model_uses_exact_allowlist_and_late_recheck(self):
        # Synthetic 21MiB bytes, not a model installation, decode or inference.
        with self.fixture() as f:
            path = f.root / ".venv/Lib/site-packages/rapidocr/models/FIXTURE-rec.onnx"
            path.parent.mkdir(parents=True)
            path.write_bytes(b"M" * (21 * 1024**2))
            rel = path.relative_to(f.root).as_posix()
            model = f.dependency_binding(path)
            f.model_pins[rel] = (model["sha256"], model["size_bytes"])
            f.current["source_file_bindings"].append({"path": rel, "sha256": "sha256:" + model["sha256"], "size_bytes": model["size_bytes"]})
            with f.environment():
                reader = sources._Reader(f.root)
                runner._track_current(reader, f.current)
                runner._recheck(reader)
                self.assertEqual(reader.bindings[str(path)], model)
                bad = copy.deepcopy(f.current)
                bad["source_file_bindings"][-1]["sha256"] = "sha256:" + "0" * 64
                with self.assertRaisesRegex(ValueError, "model cannot be repinned"): runner._track_current(sources._Reader(f.root), bad)
                path.write_bytes(b"N" * model["size_bytes"])
                with self.assertRaisesRegex(ValueError, "hash mismatch"): runner._recheck(reader)
            # Identical size at an unlisted path retains the ordinary 16MiB cap.
            unlisted = f.root / "unlisted-21MiB.bin"
            path.rename(unlisted)  # Isolated synthetic file only.
            bad = copy.deepcopy(f.current)
            bad["source_file_bindings"][-1] = {"path": unlisted.name, "sha256": av.bytes_sha(unlisted.read_bytes()), "size_bytes": model["size_bytes"]}
            with f.environment(), self.assertRaisesRegex(ValueError, "oversized"):
                runner._track_current(sources._Reader(f.root), bad)


if __name__ == "__main__":
    unittest.main()
