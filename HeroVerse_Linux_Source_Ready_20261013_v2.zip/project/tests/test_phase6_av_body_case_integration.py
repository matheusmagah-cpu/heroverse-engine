"""One bounded A12 integration snapshot; explicitly synthetic V4 inspector.

The CORE/PCM seams reuse externally pinned A11 units and narration. V6's case
reader and the V4 joiner are real. The inspector fixture purely combines the
already pinned V3 and body registration documents; it is NOT a materialized V4
proof, new QA, or rights replay. Its transport is the historical V3 input, read
unchanged. No future V4 receipt/hash is invented and no media is decoded.
"""
import copy
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_av_body_case_amendment as case
from hero_engine import phase6_av_asset_use_binding_v3 as joiner
from hero_engine import phase6_av_static_asset_uses_v4 as uses
from hero_engine import phase6_av_body_sources as body
from hero_engine import phase6_av_body_sources_replay as body_replay
from hero_engine import phase6_av_static_uses_v3_replay as previous_replay
from hero_engine import phase6_av_question_sources as question
from hero_engine import phase6_av_static_sources as sources
from hero_engine.phase6_narration_audio_inventory import Reader

ROOT = Path(__file__).absolute().parents[1]
A11 = "output/operations/phase6/av-admission/timelines/phase6-av-timeline-06198f553f7dd8184307c7b8.json"
A11_SHA = "10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb"
V3 = "output/operations/phase6/av-admission/static-asset-uses-v3"
REGISTRATION = "output/operations/phase6/av-admission/evidence/body-rights-registrations/v1/receipt.json"
REQUEST = "output/operations/phase6/av-admission/evidence/body-rights-registrations/v1/request.json"
INPUT_SHA = "3e74c984f2f76fb8d74071b0879f34fa71cd1aaa59f2ff3f84b1cf5b8e792ef9"
FIXTURE_BINDING = {"path": V3 + "/input.json", "sha256": "sha256:" + INPUT_SHA}
PINS = {
    A11: A11_SHA, V3 + "/input.json": INPUT_SHA,
    V3 + "/inspection.json": "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30",
    REGISTRATION: "e2b0beb856af6d8919b50d5d8b6cc1f3ae99d2d47b2104362ec002f561c756d9",
    REQUEST: "a858dcf333febee3181e4771bc8d4b62528434c90c272f1c69d9905610bd2753",
    case.MODULE: "a175510b5d9326661069431d6b2ddf3d1bd04e59f45c6b6f66fe89bc6c3e001c",
}


class BodyCaseA12IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = {**PINS, **{name: sources._sha((ROOT / name).read_bytes()) for name in
            ("hero_engine/phase6_av_timeline.py", *av.IMPLEMENTATION_PATHS,
             Path(__file__).relative_to(ROOT).as_posix())}}
        cls.assert_frozen()
        reader = sources._Reader(ROOT)
        docs = {path: sources._json(reader.read(path, sha)) for path, sha in PINS.items() if path.endswith(".json")}
        cls.old, cls.old_document, cls.old_proof = docs[A11], docs[V3 + "/input.json"], docs[V3 + "/inspection.json"]
        cls.registered, cls.request = docs[REGISTRATION], docs[REQUEST]
        sources._same(cls.registered["request"], cls.request, "historical body request differs")
        cls.arguments = copy.deepcopy(cls.old["inputs"])
        cls.arguments["source_bindings"].update(copy.deepcopy(av.BODY_BINDINGS))
        cls.arguments["source_bindings"]["literal_asset_uses"] = copy.deepcopy(FIXTURE_BINDING)
        metadata = Reader(ROOT)
        cls.data = {key: metadata.load(bound) for key, bound in cls.old["inputs"]["source_bindings"].items() if key in av.CORE}
        cls.schema = sources._json((ROOT / av.SCHEMA).read_bytes())
        # Minimal, explicitly synthetic inspector dependency boundary. The
        # authentic metadata graphs are covered by their separate replay tests.
        cls.fixture_dependencies = []
        for path in (V3 + "/input.json", uses.MODULE, uses.SCHEMA, joiner.PATH, *question.MODEL_PINS):
            raw = (ROOT / path).read_bytes()
            if path in question.MODEL_PINS:
                sources._same([sources._sha(raw), len(raw)], list(question.MODEL_PINS[path]), "fixture model bytes differ")
            cls.fixture_dependencies.append({"path": str(ROOT / path), "sha256": sources._sha(raw), "size_bytes": len(raw)})
        cls.current = cls.build_fixture()  # One positive build, shared by all assertions.

    @classmethod
    def assert_frozen(cls):
        for path, digest in cls.snapshot.items():
            if sources._sha((ROOT / path).read_bytes()) != digest:
                raise AssertionError("A12 focal frozen source changed: " + path)

    @classmethod
    def tearDownClass(cls):
        cls.assert_frozen()

    @classmethod
    def inspector_fixture(cls, root, *, binding):
        sources._same([str(root), binding], [str(ROOT), {"path": FIXTURE_BINDING["path"], "sha256": INPUT_SHA}], "fixture transport differs")
        current = {"sources": cls.registered["source_proofs"], "rights": cls.registered["rights_proofs"]}
        document = uses._expected(cls.literal, cls.old_document, cls.request["states"], {})
        source_rows, use_rows, remaining = uses._append_body_results(document, cls.literal, {"inspection": cls.old_proof}, current)
        proof = {"version": uses.VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
            "channel_id": sources.CHANNEL, "video_id": "video-002", "input_binding": copy.deepcopy(binding),
            "source_count": 39, "use_count": 41, "unique_png_content_count": 37, "lineage_count": 3,
            "sources": source_rows, "uses": use_rows, "remaining_unbound_visual_state_ids": remaining,
            "visual_amendment_evidence": joiner.amendment_evidence(cls.literal),
            "prior_visual_amendment_evidence": joiner.prior_amendment_evidence(cls.literal),
            "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
            "authority": dict(uses.AUTHORITY), "technical_cost_brl": 0,
            "dependency_bindings": copy.deepcopy(cls.fixture_dependencies),
            "fixture_scope": "SYNTHETIC_INSPECTOR_NOT_MATERIALIZED_V4_OR_NEW_SOURCE_QA"}
        cls.proof = copy.deepcopy(proof)
        return proof

    @classmethod
    def fixture_recheck(cls, root, proofs):
        sources._same([str(root), proofs], [str(ROOT), [cls.proof]], "same-call explicit fixture sink differs")
        uses._dependencies(sources._Reader(ROOT), cls.fixture_dependencies)

    @classmethod
    def build_fixture(cls, *, literal_fixture=None, sources_callback=None):
        real_case = case.read_amended_visual_intent
        def capture(*args, **kwargs):
            if literal_fixture is not None:
                return copy.deepcopy(literal_fixture)  # Negative-only prior observation, no repeat reader.
            cls.literal = copy.deepcopy(real_case(*args, **kwargs))
            return copy.deepcopy(cls.literal)
        with mock.patch.object(av, "_sources", side_effect=sources_callback or (lambda *_: copy.deepcopy(cls.data))), \
             mock.patch.object(av, "_literal_pcm", return_value=(copy.deepcopy(cls.old["units"]), copy.deepcopy(cls.old["narration_fragment_map"]))), \
             mock.patch.object(case, "read_amended_visual_intent", side_effect=capture) as case_reader, \
             mock.patch.object(uses, "inspect_static_asset_uses", side_effect=cls.inspector_fixture) as inspector, \
             mock.patch.object(uses, "recheck_asset_use_dependencies", side_effect=cls.fixture_recheck) as sink, \
             mock.patch.object(case, "recheck_body_case_replay", wraps=case.recheck_body_case_replay) as case_sink, \
             mock.patch.object(body, "inspect_body_sources", side_effect=AssertionError("no new body source decode")), \
             mock.patch.object(body_replay, "replay", side_effect=AssertionError("no body replay in integration fixture")), \
             mock.patch.object(previous_replay, "replay", side_effect=AssertionError("no V3 replay in integration fixture")), \
             mock.patch.object(question, "inspect_question_sources", side_effect=AssertionError("no question source batch")), \
             mock.patch.object(av, "inspect_pcm", side_effect=AssertionError("no PCM/ASR inspection")), \
             mock.patch.object(sources, "_png", side_effect=AssertionError("no PNG decode")), \
             mock.patch.object(sources.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no PNG decoder")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("no subprocess/render/OCR")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("no network")), \
             mock.patch.object(Path, "write_bytes", side_effect=AssertionError("no artifact write")):
            result = av.build(ROOT, **copy.deepcopy(cls.arguments))
            if literal_fixture is None:
                cls.calls = (case_reader.call_count, inspector.call_count, sink.call_count, case_sink.call_count)
            return result

    def test_one_real_case_and_join_preserve_v2_v3_v5_history_and_29_old_uses(self):
        self.assertEqual(self.calls, (1, 1, 2, 2))
        for key in ("untimed_visual_intent_evidence", "visual_amendment_evidence", "question_case_amendment_evidence"):
            self.assertEqual(self.current[key], self.old[key], key)
        self.assertEqual(self.proof["sources"][:27], self.old_proof["sources"])
        self.assertEqual(self.proof["uses"][:29], self.old_proof["uses"])
        self.assertEqual(self.current["body_case_amendment_evidence"]["prior_case_inspection_sha256"],
                         self.old["question_case_amendment_evidence"]["inspection_sha256"])

    def test_case_changes_21_states_24_strings_only_and_preserves_79_states(self):
        before = {state["state_id"]: state for row in self.literal["prior_case_inspection"]["rows"] for state in row["states"]}
        after = {state["state_id"]: state for row in self.literal["rows"] for state in row["states"]}
        changed = [sid for sid in before if before[sid] != after[sid]]
        strings = 0
        self.assertEqual(len(changed), 21)
        for sid in changed:
            strings += sum(a != b for a, b in zip(before[sid]["visual_content"]["literal_copy"], after[sid]["visual_content"]["literal_copy"], strict=True))
            restored = copy.deepcopy(after[sid])
            restored["visual_content"]["literal_copy"] = copy.deepcopy(before[sid]["visual_content"]["literal_copy"])
            self.assertEqual(restored, before[sid])
        self.assertEqual((strings, len(before) - len(changed)), (24, 79))
        self.assertFalse(set(changed) & {row["visual_state_id"] for row in self.old_proof["uses"]})
        evidence = self.current["body_case_amendment_evidence"]
        self.assertEqual([evidence[key] for key in ("changed_state_count", "changed_string_count", "unmodified_state_count", "preserved_bound_state_count")], [21, 24, 79, 29])
        self.assertEqual(evidence["inspection_sha256"], av.canonical_sha(self.literal))

    def test_41_uses_39_assets_37_png_3_lineages_and_59_pending_do_not_create_time(self):
        evidence = self.current["literal_asset_use_evidence"]
        self.assertEqual([evidence[key] for key in ("source_count", "use_count", "unique_png_content_count", "lineage_count")], [39, 41, 37, 3])
        self.assertEqual(evidence["bound_visual_state_ids"], list(joiner.COVERED))
        self.assertEqual(len(evidence["remaining_unbound_visual_state_ids"]), 59)
        self.assertEqual(evidence["inspection_sha256"], av.canonical_sha(self.proof))
        self.assertEqual(evidence["effective_rows_sha256"], self.current["body_case_amendment_evidence"]["effective_rows_sha256"])
        for surface in (evidence, self.current["body_case_amendment_evidence"]):
            for field in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
                self.assertIs(surface[field], False)
        self.assertTrue(all(flag is False for flag in evidence["authority"].values()))

    def test_clock_narration_pauses_union_and_pending_gates_survive(self):
        before, after = self.old, self.current
        for key in ("clock", "duration", "units", "narration_fragment_map", "pause_measurements", "caption_cues",
                    "render_spans", "visual_events", "status", "authority", "temporal_evidence_assessment", "caption_intent_evidence"):
            self.assertEqual(after[key], before[key], key)
        excluded = {"RENDER_SPAN_COVERAGE_INCOMPLETE", "VISUAL_FRAGMENT_COVERAGE_INCOMPLETE", "VISUAL_EVENTS_INCOMPLETE", "TEMPORAL_STATIC_EVENTS_INCOMPLETE"}
        self.assertEqual(after["blockers"], sorted((set(before["blockers"]) - excluded) | {"VISUAL_INTENT_NOT_BOUND"}))
        self.assertEqual(after["static_source_evidence"], [])  # CORE-only seam, not historical static replay.
        self.assertEqual(len(after["temporal_evidence_assessment"]["declared_target_unit_ids"]), 26)
        self.assertFalse(after["temporal_evidence_assessment"]["all_required_evidence_live"])
        self.assertEqual(after["status"], "BLOCKED_INCOMPLETE")
        self.assertIsNone(after["derived_take_plan"])
        silence = copy.deepcopy(before["permitted_silence_spans"])
        for row in silence:
            if row["reason"] in ("LOCKED_HOOK_PAD", "MECHANICAL_GRID_PAD"):
                self.assertEqual(row["evidence_ref"], av.canonical_sha(before["inputs"]))
                row["evidence_ref"] = av.canonical_sha(after["inputs"])
        self.assertEqual(after["permitted_silence_spans"], silence)

    def test_forty_dependencies_and_exact_large_model_bytes(self):
        expected = [{"path": path, "sha256": av.bytes_sha((ROOT / path).read_bytes())} for path in av.IMPLEMENTATION_PATHS]
        expected.append(av.CAPTION_TEXTWRAP_BINDING)
        self.assertEqual(self.current["implementation_dependencies"], expected)
        self.assertEqual(len(expected), 40)
        self.assertEqual(len({item["path"] for item in expected}), 40)
        files = {item["path"]: item for item in self.current["source_file_bindings"]}
        for path, (sha, size) in question.MODEL_PINS.items():
            self.assertEqual(files[path], {"path": path, "sha256": "sha256:" + sha, "size_bytes": size})

    def test_missing_trio_ancestry_raw_pins_and_path_rejected_before_core_reads(self):
        for field in (*av.BODY_BINDINGS, "question_case_amendment", "visual_amendment", "untimed_visual_intent", "caption_intent"):
            bindings = copy.deepcopy(self.arguments["source_bindings"])
            bindings.pop(field)
            reader = mock.Mock()
            reader.load.side_effect = AssertionError("invalid ancestry must precede core reads")
            with self.subTest(field=field), self.assertRaises(ValueError): av._sources(reader, bindings)
            reader.load.assert_not_called()
        for field in av.BODY_BINDINGS:
            bindings = copy.deepcopy(self.arguments["source_bindings"])
            bindings[field]["sha256"] = bindings[field]["sha256"][7:]
            with self.subTest(field=field), self.assertRaises(ValueError): av._sources(mock.Mock(), bindings)

    def test_schema_preserves_a11_and_rejects_downgrade_or_false_readiness(self):
        validator = Draft202012Validator(self.schema)
        validator.validate(self.old)
        validator.validate(self.current)
        for kind in ("missing_trio", "missing_evidence", "downgrade", "count", "pending", "ready", "derived", "authority"):
            candidate = copy.deepcopy(self.current)
            if kind == "missing_trio": candidate["inputs"]["source_bindings"].pop("body_case_staging")
            elif kind == "missing_evidence": candidate.pop("body_case_amendment_evidence")
            elif kind == "downgrade": candidate.update(schema_version="1.10.0", timeline_version="phase6-av-timeline-v11")
            elif kind == "count": candidate["body_case_amendment_evidence"]["changed_string_count"] = 21
            elif kind == "pending": candidate["literal_asset_use_evidence"]["remaining_unbound_visual_state_ids"].pop()
            elif kind == "ready": candidate["body_case_amendment_evidence"]["source_ready"] = True
            elif kind == "derived": candidate["derived_take_plan"] = {"fixture_only": True}
            else: candidate["authority"]["render_authorized"] = True
            with self.subTest(kind=kind), self.assertRaises(ValidationError): validator.validate(candidate)

    def test_real_join_rejects_copy_lexical_float_hold_and_both_case_hashes(self):
        for kind in ("copy", "lexical", "float", "hold", "case", "prior", "version"):
            proof = copy.deepcopy(self.proof)
            use = next(row for row in proof["uses"] if row["visual_state_id"] == ("visual-u016-s01" if kind == "hold" else "visual-u037-s01"))
            if kind == "copy": use["literal_copy"] = ["MUTATED SYNTHETIC COPY"]
            elif kind == "lexical": use["entry"]["kind"] = "UNIT_ENTRY"
            elif kind == "float": use["entry"]["char_start"] = float(use["entry"]["char_start"])
            elif kind == "hold": use["entry"]["previous_state_id"] = "visual-u017-s00"
            elif kind in ("case", "prior"):
                proof["visual_amendment_evidence" if kind == "case" else "prior_visual_amendment_evidence"]["inspection_sha256"] = "sha256:" + "0" * 64
            else: proof["version"] = "phase6-av-static-asset-uses-v3"
            with self.subTest(kind=kind), self.assertRaises(ValueError): joiner.join(proof, FIXTURE_BINDING, self.literal)

    def test_core_rejects_swapped_v5_before_join_without_repeating_reader(self):
        literal = copy.deepcopy(self.literal)
        literal["prior_case_inspection"]["source_binding"]["sha256"] = "sha256:" + "0" * 64
        with mock.patch.object(joiner, "read_asset_use_binding", side_effect=AssertionError("history must fail first")), \
             self.assertRaisesRegex(ValueError, "historical chain differs"):
            self.build_fixture(literal_fixture=literal)

    def test_early_code_snapshot_catches_virtual_drift_without_file_edits(self):
        original, changed = Path.read_bytes, {"after_source": False}
        target = ROOT / "hero_engine/phase6_av_timeline.py"
        def core_seam(*_):
            changed["after_source"] = True
            return copy.deepcopy(self.data)
        def virtual(path):
            raw = original(path)
            return raw + b"\n# EXPLICIT SYNTHETIC DRIFT, NOT A FILE EDIT\n" if path == target and changed["after_source"] else raw
        with mock.patch.object(Path, "read_bytes", virtual), self.assertRaisesRegex(ValueError, "implementation dependency changed"):
            self.build_fixture(literal_fixture=self.literal, sources_callback=core_seam)


if __name__ == "__main__":
    unittest.main()
