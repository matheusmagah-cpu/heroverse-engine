import io
import json
from pathlib import Path
import unittest
import wave
from hero_engine.continuous_audio_master import assess, exact_source_duration, normalization_command, parse_loudnorm

MEASURED = dict(input_i=-25.71, input_tp=-2.01, input_lra=5.5, input_thresh=-36.34, target_offset=1.96)
PROFILE = {"technical_minimums": {"loudness_lufs": {"target": -16, "tolerance": 1}, "true_peak_dbtp": -1}}


def wav(samples):
    result = io.BytesIO()
    with wave.open(result, "wb") as f:
        f.setparams((1, 2, 24000, len(samples), "NONE", "not compressed"))
        f.writeframes(b"".join(int(v).to_bytes(2, "little", signed=True) for v in samples))
    return result.getvalue()


class ContinuousAudioMasterTests(unittest.TestCase):
    def test_measured_second_pass_no_tempo_trim_or_overwrite(self):
        command = normalization_command("ffmpeg", Path("in.wav"), Path("out.wav"), MEASURED)
        self.assertIn("-n", command)
        self.assertIn("offset=1.96000000", command[command.index("-af") + 1])
        for prohibited in ("atempo", "atrim", "apad", "volume="):
            self.assertNotIn(prohibited, " ".join(command))
        self.assertNotIn("-t", command)

    def test_same_source_rejected(self):
        with self.assertRaises(ValueError):
            normalization_command("ffmpeg", Path("in.wav"), Path("in.wav"), MEASURED)

    def test_nonfinite_and_filter_injection_rejected(self):
        for value in ("NaN", "inf", "-2,atempo=2"):
            with self.assertRaises(ValueError):
                parse_loudnorm(json.dumps({**MEASURED, "input_tp": value}))

    def test_multiple_or_missing_measurements_rejected(self):
        for value in ("no result", json.dumps(MEASURED) * 2):
            with self.assertRaises(ValueError): parse_loudnorm(value)

    def test_no_tail_preserves_bytes(self):
        raw = wav([1, 4, -3, 0])
        result, proof = exact_source_duration(raw, 4)
        self.assertEqual(result, raw)
        self.assertEqual(proof["removed_zero_samples"], 0)

    def test_only_additional_zero_tail_removed(self):
        result, proof = exact_source_duration(wav([1, -4, 3, 0, 0]), 3)
        self.assertEqual(result, wav([1, -4, 3]))
        self.assertEqual(proof["removed_zero_samples"], 2)

    def test_nonzero_tail_or_short_audio_rejected(self):
        for samples, length in (([1, 0, 2], 2), ([1, 2], 3), ([1] + [0] * 2401, 1)):
            with self.assertRaises(ValueError): exact_source_duration(wav(samples), length)

    def test_independent_quality_checks(self):
        raw = wav([1, -3, 0])
        self.assertEqual(assess(raw, {"input_i": -16, "input_tp": -1.5}, 3, PROFILE)["status"], "PASS")
        for levels, length in (({"input_i": -25.71, "input_tp": -2.01}, 3),
                               ({"input_i": -16, "input_tp": 0}, 3),
                               ({"input_i": -16, "input_tp": -1.5}, 4)):
            self.assertEqual(assess(raw, levels, length, PROFILE)["status"], "FAIL")
        self.assertEqual(assess(wav([32767]), {"input_i": -16, "input_tp": -1.5}, 1, PROFILE)["status"], "FAIL")


if __name__ == "__main__": unittest.main()
