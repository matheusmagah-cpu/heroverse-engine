"""Concurrent filesystem writers, real D116/proof readers, temporary roots only."""
import copy
import io
import json
import threading
import time
import unittest
from contextlib import contextmanager, redirect_stdout
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from hero_engine import maintenance_paused_application as a
from hero_engine import maintenance_protocol as p
from hero_engine import phase6_maintenance_verification as d
from hero_engine.phase6_control_cycle import STAGES, materialize as cycle_materialize
from tests import test_paused_d116_integration as prior


class ConsistentD116CaptureTests(unittest.TestCase):
    # Reuse the existing real isolated regression/application fixture; do not
    # inherit its tests/aliases or patch authentication into a precomputed PASS.
    setUp = prior.PausedD116IntegrationTests.setUp
    _json = staticmethod(prior.PausedD116IntegrationTests._json)
    _write = prior.PausedD116IntegrationTests._write
    _seal = prior.PausedD116IntegrationTests._seal
    _protected_bytes = prior.PausedD116IntegrationTests._protected_bytes
    _make_proof = prior.PausedD116IntegrationTests._make_proof
    _reference = prior.PausedD116IntegrationTests._reference

    def _publish_cycle(self):
        started=datetime.now(timezone.utc)
        for stage in STAGES:
            value=p._read(self.root/stage['path'])
            value[stage['time_field']]=datetime.now(timezone.utc).isoformat()
            d._write(self.root/stage['path'],value)
        self.cycle=cycle_materialize(self.root,cycle_started_at=started,cycle_completed_at=datetime.now(timezone.utc))
        runtime=p._read(self.root/d.AUTOSTART_PATH)
        stamp=datetime.now(timezone.utc)
        runtime.update(verified_at=stamp.isoformat(),lock_heartbeat_at=stamp.isoformat(),lease_expires_at=(stamp+timedelta(seconds=120)).isoformat())
        runtime['process_identity']['started_at']=(self.at+timedelta(microseconds=1)).isoformat()
        d._write(self.root/d.AUTOSTART_PATH,runtime)
        acceptance=p._read(self.root/d.ACCEPTANCE_PATH)
        acceptance['generated_at']=datetime.now(timezone.utc).isoformat()
        if acceptance['schema_version']=='1.1.0':
            acceptance['control_cycle_evidence']={'cycle_id':self.cycle['cycle_id'],'content_hash':p.file_hash(self.root/d.CYCLE_PATH)}
        d._write(self.root/d.ACCEPTANCE_PATH,acceptance)
        executive=p._read(self.root/d.EXECUTIVE_PATH)
        executive.update(captured_at=datetime.now(timezone.utc).isoformat(),control_cycle={key:self.cycle[key] for key in ('cycle_id','decision','change_class','stage_count','all_schemas_valid','all_stages_executed_in_cycle','blockers','cycle_completed_at','substantive_signature')})
        d._write(self.root/d.EXECUTIVE_PATH,executive)
        prior.bind_fixture_projection(self.root, self.cycle)

    @contextmanager
    def _writer_at(self, owner, name, action, *, after=False, repeats=1, when=None, with_result=False):
        request=threading.Event(); done=threading.Event(); stop=threading.Event(); failures=[]; calls=[]; observed=[]
        original=getattr(owner,name)
        def writer():
            for _ in range(repeats):
                if not request.wait(15) or stop.is_set(): return
                request.clear()
                try: action(observed[-1]) if with_result else action()
                except BaseException as exc: failures.append(exc)
                finally: done.set()
        thread=threading.Thread(target=writer,name='D116-owned-fixture-writer')
        thread.start()
        def boundary(*args,**kwargs):
            t=time.perf_counter()
            value=original(*args,**kwargs) if after else None
            if len(calls)<repeats and (when is None or when(*args,**kwargs)):
                observed.append(value)
                request.set()
                if not done.wait(15): raise AssertionError('bounded fixture writer did not finish')
                done.clear()
                if failures: raise failures[0]
                calls.append(time.perf_counter()-t)
            if not after: value=original(*args,**kwargs)
            return value
        try:
            with patch.object(owner,name,side_effect=boundary): yield calls
        finally:
            stop.set();request.set();thread.join(15)
            self.assertFalse(thread.is_alive(),'owned writer must finish before fixture cleanup')

    def _invoke(self, entry='materialize'):
        kwargs=dict(paused_application_reference=self.reference_path.relative_to(self.root),expected_reference_hash=self.reference_anchor)
        if entry=='main':
            with redirect_stdout(io.StringIO()):
                self.assertEqual(0,d.main(['--root',str(self.root),'--paused-application-reference',kwargs['paused_application_reference'].as_posix(),'--expected-reference-hash',self.reference_anchor]))
            return p._read(self.root/d.BASE/'latest.json')
        result=getattr(d,entry)(self.root,**kwargs)
        return result if entry=='build' else p._read(result)

    def test_writer_advances_during_history_authentication(self):
        self._publish_cycle()
        old=self.cycle['cycle_id']
        start=time.perf_counter()
        with self._writer_at(a,'verify_archived_commit',self._publish_cycle) as calls:
            result=self._invoke()
        self.assertNotEqual(old,result['control_cycle']['cycle_id'])
        self.assertEqual(self.cycle['cycle_id'],result['control_cycle']['cycle_id'])
        self.assertEqual(1,len(calls),'authenticate history once, not per read/retry')
        for section in ('maintenance','runtime','control_cycle','acceptance','executive'):
            evidence=result[section]
            self.assertEqual(p.file_hash(self.root/evidence['snapshot_path']),evidence['content_hash'])
            self.assertEqual((self.root/evidence['snapshot_path']).read_bytes(),(self.root/evidence['path']).read_bytes())
        print(json.dumps({'scenario':'advance_during_authentication','history_seconds':calls[0],'total_seconds':time.perf_counter()-start}))

    def test_all_public_entries_allow_later_valid_cycle_and_archive_selected_bytes(self):
        for entry in ('build','materialize','main','evaluate'):
            with self.subTest(entry=entry):
                self._publish_cycle(); selected=self.cycle['cycle_id']
                specs=d._source_specs(self.root,self.reference_path.relative_to(self.root),self.reference_anchor)
                raw={label:(self.root/path).read_bytes() for label,path,_ in specs}
                def invoke():
                    if entry!='evaluate': return self._invoke(entry)
                    data={label:json.loads(value) for label,value in raw.items()}
                    return d.evaluate(self.root,maintenance=data['maintenance'],autostart=data['runtime'],cycle=data['control-cycle'],
                        acceptance=data['acceptance'],executive=data['executive'],verified_at=datetime.now(timezone.utc),
                        source_hashes={path:'sha256:'+__import__('hashlib').sha256(raw[label]).hexdigest() for label,path,_ in specs},
                        paused_application_reference=self.reference_path.relative_to(self.root),expected_reference_hash=self.reference_anchor)
                with self._writer_at(d,'_evaluate_observed',self._publish_cycle,after=True):
                    result=invoke()
                self.assertEqual(selected,result['control_cycle']['cycle_id'])
                self.assertNotEqual(selected,self.cycle['cycle_id'])
                if entry in ('main','materialize'):
                    for section,label in [('maintenance','maintenance'),('runtime','runtime'),('control_cycle','control-cycle'),('acceptance','acceptance'),('executive','executive')]:
                        self.assertEqual(raw[label],(self.root/result[section]['snapshot_path']).read_bytes())

    def test_swap_between_reads_recaptures_once_without_reauthentication(self):
        self._publish_cycle()
        with patch.object(a,'verify_archived_commit',wraps=a.verify_archived_commit) as auth:
            with self._writer_at(d,'_read_validated',self._publish_cycle,after=True,
                                 when=lambda root,relative,schema:relative==d.CYCLE_PATH) as calls:
                result=self._invoke()
        self.assertEqual(1,len(calls));self.assertEqual(1,auth.call_count)
        self.assertEqual(self.cycle['cycle_id'],result['control_cycle']['cycle_id'])

    def test_continuous_swaps_exhaust_three_captures_without_false_pass(self):
        self._publish_cycle()
        with patch.object(a,'verify_archived_commit',wraps=a.verify_archived_commit) as auth:
            with self._writer_at(d,'_read_validated',self._publish_cycle,after=True,repeats=3,
                                 when=lambda root,relative,schema:relative==d.CYCLE_PATH) as calls:
                with self.assertRaisesRegex(PermissionError,'all 3 bounded attempts'): self._invoke()
        self.assertEqual(3,len(calls));self.assertEqual(1,auth.call_count)
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_mixed_cycle_identity_binding_and_invalid_lease_are_rejected(self):
        self._publish_cycle()
        cases=[(d.ACCEPTANCE_PATH,lambda v:v['control_cycle_evidence'].update(cycle_id='phase6-control-cycle-'+'0'*24),'binding'),
               (d.ACCEPTANCE_PATH,lambda v:v['control_cycle_evidence'].update(content_hash='sha256:'+'0'*64),'binding'),
               (d.EXECUTIVE_PATH,lambda v:v['control_cycle'].update(cycle_id='phase6-control-cycle-'+'0'*24),'CURRENT_CHAIN_EXECUTIVE_DIVERGED'),
               (d.AUTOSTART_PATH,lambda v:v.update(lease_expires_at=v['lock_heartbeat_at']),'chronology')]
        for path,mutate,reason in cases:
            with self.subTest(path=str(path),reason=reason):
                raw=(self.root/path).read_bytes();value=json.loads(raw);mutate(value);d._write(self.root/path,value)
                try:
                    with self.assertRaisesRegex(PermissionError,reason): self._invoke('build')
                finally:(self.root/path).write_bytes(raw)
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_history_sources_and_stage_snapshots_remain_write_protected_until_use(self):
        self._publish_cycle(); denied=[]
        targets=[self.reference_path,self.run/'committed.json',self.run/'after.json',
                 self.proof_dir/'unittest.stderr.log',self.root/'tests/test_contract.py',
                 self.root/self.cycle['stages'][0]['snapshot_path']]
        before={str(path):path.read_bytes() for path in targets}
        def corrupt():
            for path in targets:
                try: path.write_bytes(b'foreign bytes')
                except PermissionError: denied.append(str(path))
        with self._writer_at(d,'_evaluate_observed',corrupt,after=True): result=self._invoke()
        self.assertEqual('PASS',result['status']);self.assertEqual(set(before),set(denied))
        self.assertEqual(before,{str(path):path.read_bytes() for path in targets})

    def test_added_historical_failure_is_rejected_before_any_receipt(self):
        self._publish_cycle()
        with self._writer_at(d,'_evaluate_observed',lambda:(self.run/'failed.json').write_bytes(b'{}'),after=True):
            with self.assertRaisesRegex(PermissionError,'ARCHIVE_POPULATION_CHANGED'): self._invoke()
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_live_error_after_capture_still_blocks(self):
        self._publish_cycle()
        with self._writer_at(d,'_evaluate_observed',lambda:self._json(self.root/'output/operations/phase6/control-cycle-error.json',{'error':'owned test error'}),after=True):
            with self.assertRaisesRegex(PermissionError,'error files remain'): self._invoke()
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_output_collision_is_not_overwritten(self):
        self._publish_cycle()
        for kind in ('snapshot','history'):
            with self.subTest(kind=kind):
                foreign=[]
                def collide(value):
                    path=self.root/(d._snapshot_path(value['verification_id'],'runtime') if kind=='snapshot'
                                    else d.BASE/'history'/(value['verification_id']+'.json'))
                    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'{"foreign":true}');foreign.append(path)
                with self._writer_at(d,'_evaluate_observed',collide,after=True,with_result=True):
                    with self.assertRaisesRegex(PermissionError,'collision'):self._invoke()
                self.assertEqual(b'{"foreign":true}',foreign[0].read_bytes())
                self.assertFalse((self.root/d.BASE/'latest.json').exists())
                self._publish_cycle()

    def test_snapshot_changed_between_publish_and_pin_cannot_create_receipt(self):
        from hero_engine import maintenance_snapshot
        self._publish_cycle()
        def corrupt_published(_):
            found=list((self.root/d.BASE/'source-snapshots').glob('*/*.json'))
            self.assertEqual(1,len(found));found[0].write_bytes(b'{}')
        with self._writer_at(maintenance_snapshot,'_publish',corrupt_published,after=True,with_result=True):
            with self.assertRaisesRegex(PermissionError,'archived post-maintenance source hash mismatch'):self._invoke()
        self.assertFalse((self.root/d.BASE/'latest.json').exists())

    def test_current_acceptance_producer_binds_the_consumed_buffer(self):
        from hero_engine.phase6_acceptance import build_phase6_acceptance
        self._publish_cycle()
        before=p.file_hash(self.root/d.CYCLE_PATH)
        report=build_phase6_acceptance(self.root)
        self.assertEqual('1.1.0',report['schema_version'])
        self.assertEqual({'cycle_id':self.cycle['cycle_id'],'content_hash':before},report['control_cycle_evidence'])
        self._publish_cycle()
        self.assertNotEqual(p.file_hash(self.root/d.CYCLE_PATH),report['control_cycle_evidence']['content_hash'])

    def test_direct_evaluate_rejects_unbound_offered_values(self):
        self._publish_cycle()
        paths=[self.reference_path.relative_to(self.root),d.AUTOSTART_PATH,d.CYCLE_PATH,d.ACCEPTANCE_PATH,d.EXECUTIVE_PATH]
        offered=[p._read(self.root/path) for path in paths]
        offered[2]['cycle_id']='phase6-control-cycle-'+'0'*24
        with self.assertRaisesRegex(PermissionError,'offered live snapshot/source diverged'):
            d.evaluate(self.root,maintenance=offered[0],autostart=offered[1],cycle=offered[2],acceptance=offered[3],
                executive=offered[4],verified_at=datetime.now(timezone.utc),paused_application_reference=paths[0],expected_reference_hash=self.reference_anchor)

    def test_authentication_capture_durations_and_observed_clock(self):
        self._publish_cycle(); metrics={}
        original_history=d._paused_application_scope; original_capture=d._capture_live_sources
        @contextmanager
        def history(*args,**kwargs):
            started=time.perf_counter()
            with original_history(*args,**kwargs) as value:
                metrics['history_authentication_seconds']=time.perf_counter()-started
                yield value
        @contextmanager
        def capture(*args,**kwargs):
            started=time.perf_counter(); began=datetime.now(timezone.utc)
            with original_capture(*args,**kwargs) as value:
                metrics['capture_seconds']=time.perf_counter()-started
                metrics['observed_at']=value[3].isoformat()
                self.assertLessEqual(began,value[3]);self.assertLessEqual(value[3],datetime.now(timezone.utc))
                yield value
        with patch.object(d,'_paused_application_scope',side_effect=history), patch.object(d,'_capture_live_sources',side_effect=capture):
            with self._writer_at(a,'verify_archived_commit',self._publish_cycle):
                with self._writer_at(d,'_evaluate_observed',self._publish_cycle,after=True):
                    result=self._invoke()
        self.assertEqual(d._parse(metrics['observed_at']),d._parse(result['verified_at']))
        self.assertNotEqual(self.cycle['cycle_id'],result['control_cycle']['cycle_id'])
        self.assertGreater(metrics['history_authentication_seconds'],0)
        self.assertGreater(metrics['capture_seconds'],0)
        print(json.dumps({'scenario':'timed_real_readers_with_two_writer_advances',**metrics}))

    def test_legacy_receipt_stays_pinned_through_real_authentication(self):
        from tests.test_phase6_maintenance_verification_v12 import _fixture
        with _fixture() as (root,receipt):
            d._write(root/d.MAINTENANCE_PATH,receipt)
            raw=(root/d.MAINTENANCE_PATH).read_bytes(); denied=[]
            def replace_receipt():
                try:(root/d.MAINTENANCE_PATH).write_bytes(b'{}')
                except PermissionError:denied.append(True)
            with self._writer_at(d,'verify_regression_evidence',replace_receipt,after=True) as calls:
                # This existing legacy archive fixture deliberately has no live
                # runtime. Authenticate it for real, then fail at that boundary;
                # do not manufacture runtime or claim this is a legacy restart.
                with self.assertRaisesRegex(FileNotFoundError,'autostart-verification.json'):
                    d.build(root)
            self.assertEqual(1,len(calls));self.assertEqual([True],denied)
            self.assertEqual(raw,(root/d.MAINTENANCE_PATH).read_bytes())
