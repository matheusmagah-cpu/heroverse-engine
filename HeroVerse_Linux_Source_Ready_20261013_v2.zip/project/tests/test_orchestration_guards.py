"""Focused host-orchestration guards; product paths remain the logical root."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]
ASCII_ROOT = r"C:\Users\mathe\OneDrive\READET~1\MODELA~1"


class OrchestrationGuardTests(unittest.TestCase):
    def _powershell(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            # PowerShell 7 preserves the script's Unicode logical-root default;
            # Windows PowerShell v1 command-line decoding can corrupt it before
            # the guard has a chance to reject the bad host path.
            ["pwsh", "-NoProfile", "-ExecutionPolicy", "Bypass", *args],
            cwd=ASCII_ROOT,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
        )

    def test_ascii_alias_resolves_to_the_single_logical_root_and_corrupt_path_fails_closed(self):
        guard = ROOT / "scripts" / "assert_orchestration_root.ps1"
        passed = self._powershell("-File", str(guard))
        self.assertEqual(0, passed.returncode, passed.stderr)
        record = json.loads(passed.stdout)
        self.assertEqual("PASS", record["status"])
        self.assertEqual(ASCII_ROOT.casefold(), record["physical_root"].casefold())
        self.assertTrue(record["host_orchestration_only"])
        failed = self._powershell("-File", str(guard), "-PhysicalRoot", "C:\\Users\\mathe\\OneDrive\\\ufffdrea de Trabalho\\Modelagem Youtube")
        self.assertNotEqual(0, failed.returncode)
        self.assertIn("ORCHESTRATION_ROOT_CORRUPTED", failed.stderr)

    def test_resource_guard_requires_two_post_recovery_samples(self):
        guard = ROOT / "output/runtime/gestor-central/guards/resource_guard.ps1"
        passed = self._powershell("-File", str(guard), "-MinFreeRamMiB", "1", "-MinFreeDiskGiB", "1", "-Preflight")
        self.assertEqual(0, passed.returncode, passed.stderr)
        record = json.loads(passed.stdout)
        self.assertTrue(record["ram_ok"])
        self.assertTrue(record["disk_ok"])
        self.assertEqual(2, len(record["stability_samples"]))
        blocked = self._powershell("-File", str(guard), "-MinFreeRamMiB", "999999", "-MinFreeDiskGiB", "1", "-Preflight")
        self.assertEqual(42, blocked.returncode)
        self.assertFalse(json.loads(blocked.stdout)["ram_ok"])


if __name__ == "__main__":
    unittest.main()
