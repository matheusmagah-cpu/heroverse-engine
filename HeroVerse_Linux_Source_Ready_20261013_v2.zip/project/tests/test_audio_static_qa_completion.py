"""Actual public QA and calibrated raster readers; codec/host boundaries simulated."""
import copy
import json
import unittest
from jsonschema import Draft202012Validator, ValidationError
from tests import test_audio_static_control_reader as fixture
from tests import test_audio_static_publication_package as publication_fixture

class AudioStaticQaCompletionTests(unittest.TestCase):
    def setUp(self):
        self.owner=fixture.AudioStaticControlReaderTests('test_valid_anchored_reader_returns_limits_not_authority')
        self.addCleanup(self.owner.doCleanups);self.owner.setUp()
        self.helper=self.owner.helper

    def evaluate(self, *, controls=True, execution=True):
        if controls:self.helper.codec_control_binding=self.owner.binding
        if execution:self.helper.execution_builder=self.owner.execution_fixture
        self.helper.test_final_technical_static_hold_not_wrongly_rejected_as_freeze()
        report,measured=self.helper.last_result
        defects={row['defect']:row for row in report['defect_evaluations']}
        return report,measured,defects

    def test_static_qa_uses_current_contract_without_human_pass(self):
        report,measured,defects=self.evaluate()
        self.assertEqual(report['schema_version'],'1.1.0')
        self.assertFalse(report['human_review']['required'])
        self.assertEqual(report['human_review']['status'],'NOT_REQUIRED')
        self.assertIsNone(report['human_review']['reviewer_id'])
        self.assertEqual(defects['BACKGROUND_PULSING']['status'],'PASS')
        self.assertEqual(defects['GHOSTING']['status'],'PASS')
        self.assertEqual(measured['static_decoded_visual']['expected_frames'],measured['static_decoded_visual']['observed_frames'])
        self.assertFalse(report['publication_eligible'])

    def test_no_calibration_leaves_real_defects_unresolved(self):
        _,_,defects=self.evaluate(controls=False,execution=False)
        for name in ('BACKGROUND_PULSING','GHOSTING','COMPRESSION_ARTIFACT'):
            self.assertEqual(defects[name]['status'],'NEEDS_REVIEW')

    def test_calibration_without_observed_execution_cannot_pass(self):
        _,_,defects=self.evaluate(execution=False)
        self.assertEqual(defects['GHOSTING']['status'],'NEEDS_REVIEW')
        self.assertEqual(defects['BACKGROUND_PULSING']['status'],'NEEDS_REVIEW')

    def test_actual_erased_text_fails_static_defects(self):
        def damage(image):
            image[390:630,180:1740]=image[0,0]
            return image
        self.helper.decoded_transform=damage
        _,_,defects=self.evaluate()
        self.assertEqual(defects['GHOSTING']['status'],'FAIL')
        self.assertEqual(defects['BACKGROUND_PULSING']['status'],'FAIL')

    def test_colour_damage_is_measured_not_declared_pass(self):
        def damage(image):
            image[:100,:100]=[255,255,255]
            return image
        self.helper.decoded_transform=damage
        _,_,defects=self.evaluate()
        self.assertEqual(defects['BACKGROUND_PULSING']['status'],'FAIL')
        self.assertEqual(defects['GHOSTING']['status'],'FAIL')

    def test_temporal_failure_is_not_hidden_by_intact_static_frames(self):
        self.helper.signal_observation={'status':'MEASURED','within_take_luminance_delta_p95':99,
                                       'flicker_threshold_p95':15,'hard_transition_count':0}
        _,_,defects=self.evaluate()
        self.assertEqual(defects['GHOSTING']['status'],'PASS')
        self.assertEqual(defects['BACKGROUND_PULSING']['status'],'FAIL')
        self.assertEqual(defects['FLICKER']['status'],'FAIL')

    def test_legacy_schema_still_requires_human_review(self):
        schema=fixture.read(fixture.ROOT/'schemas/creative_quality_gate_report.schema.json')
        historical=fixture.read(fixture.ROOT/'output/production/phase5/pilot-001/creative-v3/qa/creative_quality_gate_report.json')
        Draft202012Validator(schema).validate(historical)
        invalid=copy.deepcopy(historical);invalid['human_review']['required']=False
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(invalid)

    def test_current_schema_cannot_remove_review_for_a_cinematic_pack(self):
        report,_,_=self.evaluate()
        schema=fixture.read(fixture.ROOT/'schemas/creative_quality_gate_report.schema.json')
        report['format_pack_id']='fp-broll-cinematic-narration'
        with self.assertRaises(ValidationError):Draft202012Validator(schema).validate(report)

    def test_current_publication_consumer_requires_explicit_new_qa_version(self):
        owner=publication_fixture.AudioStaticPublicationPackageTests('test_current_public_producer_uses_current_script_and_owned_media_only')
        self.addCleanup(owner.doCleanups);owner.setUp()
        result=owner.build()
        self.assertEqual(result['quality_gate']['human_review'],'NOT_REQUIRED_PER_RELEASE')
        value=fixture.read(owner.report);value['schema_version']='1.0.0'
        value['human_review'].update(required=True,status='PENDING')
        fixture.write(owner.report,value);owner.report_binding['sha256']=fixture.sha(owner.report)
        with self.assertRaises(PermissionError):owner.build()
