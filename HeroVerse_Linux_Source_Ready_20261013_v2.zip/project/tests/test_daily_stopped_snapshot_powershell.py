"""Native PS5 regressions for the stopped-state producer; synthetic files only.

The real daily.ps1 functions are extracted without executing the maintenance
entrypoint. Only the read-only inspection command is a fixture; the PID is a
nonexistent synthetic ID. Byte capture, projection, UTF-8 and canonical hashing run
the actual producer. No scheduled task, OAuth call or real token is accessed.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from hero_engine.maintenance_protocol import canonical_hash


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/daily.ps1"
FUNCTIONS = (
    "Get-Sha256", "Get-StringSha256", "Get-FileByteEvidence",
    "Read-StoppedRuntimeTokenMetadata", "Assert-StoppedRuntimeTokenProjection",
    "Write-StoppedOperationalSnapshot", "Write-JsonAtomic",
)
TOKEN_BYTES = b"SYNTHETIC-TEST-ONLY-NOT-A-CREDENTIAL\n"


def _quote(value: Path | str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _functions() -> str:
    source = SCRIPT.read_text(encoding="utf-8-sig")
    selected = []
    for name in FUNCTIONS:
        match = re.search(r"(?ms)^function " + re.escape(name) + r" \{.*?(?=^function |\Z)", source)
        if match is None:
            raise AssertionError(f"Missing actual PowerShell function: {name}")
        selected.append(match.group())
    return "\n".join(selected)


@unittest.skipUnless(os.name == "nt", "Native Windows PowerShell 5 is required")
class DailyStoppedSnapshotPowerShellTests(unittest.TestCase):
    def _run(self, body: str, *, token_present: bool = True, effect_count: int = 1, shell: str = "powershell.exe") -> dict:
        with tempfile.TemporaryDirectory(prefix="daily-ps5-fixture-") as folder:
            base = Path(folder)
            project = base / "projeto"
            runtime = project / "output/runtime/gestor-central"
            runtime.mkdir(parents=True)
            external = base / "credencial-sintética-área"
            external.mkdir()
            token = external / "token-sintético.json"
            if token_present:
                token.write_bytes(TOKEN_BYTES)
            watcher = {
                "destination_path": str(token.resolve()),
                "destination_path_sha256": hashlib.sha256(str(token.resolve()).lower().encode("utf-8")).hexdigest(),
                "destination_exists": True,
                "destination_outside_workspace": True,
            }
            watcher_path = runtime / "oauth-reconsent-watcher.json"
            watcher_path.write_text(json.dumps(watcher, ensure_ascii=False), encoding="utf-8")
            receipts = []
            for index in range(effect_count):
                relative = f"output/fixture-effects/ação-{index}.json"
                path = project / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('{"fixture":true}', encoding="utf-8")
                receipts.append({"path": relative, "label": "ação sintética"})
            inspection_path = base / "fixture-inspection.json"
            jobs = [{"label": "ação íntegra", "created_at": "2026-09-05T23:14:35.284910Z",
                     "checkpoint": {"next_observation_at": "2026-09-06T01:14:35.284910Z"},
                     "fractions": [{"z": f'2026-09-06T09:00:00.{"1" + "0" * (n - 1)}Z',
                                    "offset": f'2026-09-06T09:00:00.{"1" + "0" * (n - 1)}+02:30'} for n in range(1, 8)],
                     "types": [None, True, False, [], {}, [None], 1.25, 9007199254740993, 18446744073709551615]}]
            inspection = {
                "blockers": [], "manager_pid": 2147483647,
                "observed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "active_lease_job_ids": [],
                "quota": {"reserved_ids": []},
                "queue": {"jobs_hash": canonical_hash(jobs), "jobs": jobs},
                "quota_ledger": {"state_hash": canonical_hash([]), "tables": []},
                "operational_effects": {"open_receipt_paths": [], "receipts": receipts, "receipts_hash": canonical_hash(receipts)},
            }
            inspection_path.write_text(json.dumps(inspection, ensure_ascii=False), encoding="utf-8")
            harness = base / "actual-functions.ps1"
            harness.write_text(
                "$ErrorActionPreference = 'Stop'\n"
                "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)\n"
                "if ($PSVersionTable.PSVersion.Major -notin @(5, 7)) { throw 'PS5 or PS7 required' }\n"
                + _functions()
                + f"\n$projectRoot = {_quote(project)}\n$runtimeDir = {_quote(runtime)}\n"
                + f"$fixtureInspection = {_quote(inspection_path)}\n$fixtureToken = {_quote(token)}\n"
                + f"$fixtureWatcherPath = {_quote(watcher_path)}\n$realPython = {_quote(sys.executable)}\n"
                + "$requestId = 'maintenance-request-fixture'\n$runRelative = 'output/runtime/gestor-central/maintenance-runs/' + $requestId\n"
                + "$maintenanceRequestedAt = [DateTimeOffset]::UtcNow.AddMinutes(-1)\n$inspectionCalls = 0\n"
                + "$testPython = 'Invoke-SnapshotFixturePython'\n"
                + "function Invoke-SnapshotFixturePython {\n"
                + "  if ($args[0] -eq '-m' -and $args[1] -eq 'hero_engine.maintenance_snapshot') { $input | & $realPython @args }\n"
                + "  elseif ($args[0] -eq '-m') {\n"
                + "    if ($args[1] -ne 'hero_engine.maintenance_protocol' -or $args[2] -ne 'inspect') { throw 'Unexpected fixture command' }\n"
                + "    $script:inspectionCalls++\n"
                + "    $target = Join-Path $projectRoot $args[-1]\n"
                + "    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null\n"
                + "    Copy-Item -LiteralPath $fixtureInspection -Destination $target\n"
                + "    $global:LASTEXITCODE = 0\n"
                + "  } elseif ($args[0] -eq '-c') { & $realPython @args }\n"
                + "  else { throw 'Unexpected fixture command' }\n}\n"
                + "$outputPath = Join-Path $projectRoot ($runRelative + '/stopped-operational-state-before-regression.json')\n"
                + body
                + "\n$result | ConvertTo-Json -Depth 30 -Compress\n",
                encoding="utf-8-sig",
            )
            native_environment = os.environ.copy()
            # Python can inherit the PowerShell 7 module path from the tool
            # host. Let Windows PowerShell rebuild its native PS5 module path;
            # otherwise its built-in Get-FileHash function cannot autoload.
            for key in list(native_environment):
                if key.casefold() == "psmodulepath":
                    native_environment.pop(key)
            completed = subprocess.run(
                [shell, "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(harness)],
                cwd=ROOT, env=native_environment, capture_output=True, timeout=20, check=False,
            )
            stderr = completed.stderr.decode("utf-8", errors="replace")
            self.assertEqual(0, completed.returncode, stderr)
            stdout = completed.stdout.decode("utf-8-sig")
            self.assertNotIn(TOKEN_BYTES.decode().strip(), stdout + stderr)
            self.assertNotIn(str(token), stdout + stderr)
            self.assertNotIn(str(external), stdout + stderr)
            result = json.loads(stdout)
            # Read the produced files in Python, not another lossy PS7 parse.
            # Every opaque value and type must equal the pinned inspection.
            for path in project.rglob("stopped-operational-state-*-regression.json"):
                snapshot = json.loads(path.read_text(encoding="utf-8-sig"))
                state = snapshot["state"]
                for key, group, field in (("queue_jobs", "queue", "jobs"), ("quota_ledger_tables", "quota_ledger", "tables"), ("operational_effect_receipts", "operational_effects", "receipts")):
                    self.assertEqual(canonical_hash(inspection[group][field]), canonical_hash(state[key]))
                canonical = json.loads((project / snapshot["canonical_state_path"]).read_text(encoding="utf-8-sig"))
                self.assertEqual(canonical_hash(state), canonical_hash(canonical))
                self.assertEqual(canonical_hash(state), snapshot["state_hash"])
                side = "before" if snapshot["role"] == "PRE_REGRESSION" else "after"
                queue = json.loads((path.parent / f"queue-{side}.json").read_text(encoding="utf-8-sig"))
                self.assertEqual(canonical_hash(inspection["queue"]), canonical_hash(queue))
            # All retained project artifacts must remain free of token bytes.
            for path in project.rglob("*"):
                if path.is_file():
                    self.assertNotIn(TOKEN_BYTES.strip(), path.read_bytes(), path.name)
            return result

    def test_native_ps5_snapshot_preserves_singleton_object_unicode_and_null(self) -> None:
        result = self._run(r"""
$snapshot = Write-StoppedOperationalSnapshot -Role PRE_REGRESSION -OutputPath $outputPath -FormerManagerPid 2147483647 -BoundaryStartedAt $maintenanceRequestedAt
$disk = Get-Content -LiteralPath $outputPath -Raw -Encoding UTF8 | ConvertFrom-Json
$result = [ordered]@{
    ps_major = $PSVersionTable.PSVersion.Major
    projected_token = $disk.state.oauth_runtime_token
    byte_token = $disk.byte_evidence.oauth_runtime_token
    canonical_hash = $disk.state_hash
    effect_count = @($disk.state.operational_effect_receipt_files).Count
    effect_type = $disk.state.operational_effect_receipt_files.GetType().Name
    queue_label = $disk.state.queue_jobs[0].label
    effect_label = $disk.state.operational_effect_receipts[0].label
    inspection_calls = $inspectionCalls
}
""")
        self.assertEqual(5, result["ps_major"])
        projection = result["projected_token"]
        evidence = result["byte_token"]
        self.assertIsInstance(projection, dict)
        self.assertEqual({key: evidence[key] for key in projection}, projection)
        self.assertEqual(6, len(projection))
        self.assertEqual("OAUTH_RUNTIME_TOKEN_EXTERNAL", projection["identity"])
        self.assertIsNone(projection["path"])
        self.assertIsNone(evidence["snapshot_path"])
        self.assertIsNone(evidence["snapshot_hash"])
        self.assertIs(projection["present"], True)
        self.assertEqual(len(TOKEN_BYTES), projection["byte_count"])
        self.assertEqual("sha256:" + hashlib.sha256(TOKEN_BYTES).hexdigest(), projection["content_hash"])
        self.assertRegex(result["canonical_hash"], r"^sha256:[0-9a-f]{64}$")
        self.assertEqual(1, result["effect_count"])
        self.assertEqual("Object[]", result["effect_type"])
        self.assertEqual("ação íntegra", result["queue_label"])
        self.assertEqual("ação sintética", result["effect_label"])
        self.assertEqual(1, result["inspection_calls"])

    def test_zero_and_multiple_effect_projections_keep_array_cardinality(self) -> None:
        for count in (0, 2):
            with self.subTest(count=count):
                result = self._run(r"""
$outputPath = Join-Path $projectRoot ($runRelative + '/stopped-operational-state-after-regression.json')
$snapshot = Write-StoppedOperationalSnapshot -Role POST_REGRESSION -OutputPath $outputPath -FormerManagerPid 2147483647 -BoundaryStartedAt $maintenanceRequestedAt
$disk = Get-Content -LiteralPath $outputPath -Raw -Encoding UTF8 | ConvertFrom-Json
$result = @{ count = @($disk.state.operational_effect_receipt_files).Count; type = $disk.state.operational_effect_receipt_files.GetType().Name }
""", effect_count=count)
                self.assertEqual(count, result["count"])
                self.assertEqual("Object[]", result["type"])

    def test_current_ps7_also_preserves_entire_opaque_inspection(self) -> None:
        import shutil
        shell = shutil.which("pwsh.exe")
        self.assertIsNotNone(shell, "The deployed PS7 shell must be available for this regression")
        result = self._run(r"""
$summary = Write-StoppedOperationalSnapshot -Role PRE_REGRESSION -OutputPath $outputPath -FormerManagerPid 2147483647 -BoundaryStartedAt $maintenanceRequestedAt
$result = @{ status = $summary.status; ps_major = $PSVersionTable.PSVersion.Major; opaque_state_returned = ($null -ne $summary.state); queue_jobs_returned = ($null -ne $summary.queue_jobs) }
""", shell=shell)
        self.assertEqual(7, result["ps_major"])
        self.assertEqual("PASS", result["status"])
        self.assertFalse(result["opaque_state_returned"])
        self.assertFalse(result["queue_jobs_returned"])

    def test_absent_token_fails_before_inspection_byte_capture_or_snapshot(self) -> None:
        result = self._run(r"""
$message = $null
try { Write-StoppedOperationalSnapshot -Role PRE_REGRESSION -OutputPath $outputPath -FormerManagerPid 2147483647 -BoundaryStartedAt $maintenanceRequestedAt | Out-Null }
catch { $message = $_.Exception.Message }
$result = @{ message = $message; inspection_calls = $inspectionCalls; snapshot_exists = Test-Path -LiteralPath $outputPath; byte_directory_exists = Test-Path -LiteralPath (Join-Path $projectRoot ($runRelative + '/stopped-state-bytes')) }
""", token_present=False)
        self.assertIn("metadata diverged", result["message"])
        self.assertEqual(0, result["inspection_calls"])
        self.assertFalse(result["snapshot_exists"])
        self.assertFalse(result["byte_directory_exists"])

    def test_metadata_preflight_rejects_bad_hash_flags_relative_and_internal_path(self) -> None:
        result = self._run(r"""
$original = [IO.File]::ReadAllText($fixtureWatcherPath, [Text.Encoding]::UTF8)
$outcomes = [ordered]@{}
foreach ($mode in @('hash', 'string_presence', 'false_presence', 'outside_flag', 'relative', 'internal', 'empty', 'bad_json', 'absent_watcher')) {
    $watcher = $original | ConvertFrom-Json
    switch ($mode) {
        'hash' { $watcher.destination_path_sha256 = '0' * 64 }
        'string_presence' { $watcher.destination_exists = 'true' }
        'false_presence' { $watcher.destination_exists = $false }
        'outside_flag' { $watcher.destination_outside_workspace = $false }
        'relative' { $watcher.destination_path = 'relative.json' }
        'internal' {
            $watcher.destination_path = Join-Path $projectRoot 'inside.json'
            [IO.File]::WriteAllText($watcher.destination_path, 'synthetic-safe-data')
            $watcher.destination_path_sha256 = (Get-StringSha256 -Value $watcher.destination_path.ToLowerInvariant()).Substring(7)
        }
        'empty' {
            $watcher.destination_path = Join-Path (Split-Path -Parent $fixtureToken) 'empty.json'
            [IO.File]::WriteAllBytes($watcher.destination_path, [byte[]]@())
            $watcher.destination_path_sha256 = (Get-StringSha256 -Value $watcher.destination_path.ToLowerInvariant()).Substring(7)
        }
    }
    [IO.File]::WriteAllText($fixtureWatcherPath, ($watcher | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    if ($mode -eq 'bad_json') { [IO.File]::WriteAllText($fixtureWatcherPath, '{') }
    if ($mode -eq 'absent_watcher') { Remove-Item -LiteralPath $fixtureWatcherPath }
    try { Read-StoppedRuntimeTokenMetadata -WatcherPath $fixtureWatcherPath | Out-Null; $outcomes[$mode] = 'UNEXPECTED_PASS' }
    catch { $outcomes[$mode] = $_.Exception.Message }
}
$result = $outcomes
""")
        self.assertEqual(9, len(result))
        for mode, message in result.items():
            self.assertTrue(message.startswith("Stopped-state OAuth"), (mode, message))

    def test_projection_preflight_rejects_scalar_null_redaction_and_metadata_tampering(self) -> None:
        result = self._run(r"""
$watcher = Read-StoppedRuntimeTokenMetadata -WatcherPath $fixtureWatcherPath
$outcomes = [ordered]@{}
foreach ($mode in @('scalar', 'snapshot_empty', 'snapshot_hash', 'path', 'false_presence', 'content_hash', 'path_hash', 'string_size', 'extra_key', 'projection_size')) {
    $evidence = Get-FileByteEvidence -Path $fixtureToken -Identity 'OAUTH_RUNTIME_TOKEN_EXTERNAL' -RedactPath
    switch ($mode) {
        'snapshot_empty' { $evidence.snapshot_path = '' }
        'snapshot_hash' { $evidence.snapshot_hash = 'sha256:' + ('0' * 64) }
        'path' { $evidence.path = 'not-redacted' }
        'false_presence' { $evidence.present = $false }
        'content_hash' { $evidence.content_hash = 'bad' }
        'path_hash' { $evidence.path_identity_hash = 'sha256:' + ('0' * 64) }
        'string_size' { $evidence.byte_count = [string]$evidence.byte_count }
    }
    $projection = [ordered]@{}
    foreach ($key in @('identity', 'path', 'path_identity_hash', 'present', 'byte_count', 'content_hash')) { $projection[$key] = $evidence[$key] }
    if ($mode -eq 'scalar') { $projection = 'OAUTH_RUNTIME_TOKEN_EXTERNAL' }
    if ($mode -eq 'extra_key') { $projection['unexpected'] = 1 }
    if ($mode -eq 'projection_size') { $projection.byte_count = [int64]999 }
    try { Assert-StoppedRuntimeTokenProjection -Evidence $evidence -Projection $projection -Watcher $watcher; $outcomes[$mode] = 'UNEXPECTED_PASS' }
    catch { $outcomes[$mode] = $_.Exception.Message }
}
$result = $outcomes
""")
        self.assertEqual(10, len(result))
        for mode, message in result.items():
            self.assertTrue(message.startswith("Stopped-state OAuth"), (mode, message))

    def test_redacted_snapshot_destination_is_rejected_before_hash_or_copy(self) -> None:
        result = self._run(r"""
function Get-Sha256 { param($Path) throw 'UNEXPECTED_HASH_READ' }
$message = $null
try { Get-FileByteEvidence -Path $fixtureToken -Identity 'OAUTH_RUNTIME_TOKEN_EXTERNAL' -RedactPath -SnapshotRelative 'output/must-not-exist.json' | Out-Null }
catch { $message = $_.Exception.Message }
$result = @{ message = $message; copied = Test-Path -LiteralPath (Join-Path $projectRoot 'output/must-not-exist.json') }
""")
        self.assertEqual("Redacted byte evidence cannot have a snapshot destination.", result["message"])
        self.assertFalse(result["copied"])

    def test_optional_nulls_and_absent_files_are_serialized_as_null_not_empty(self) -> None:
        result = self._run(r"""
$absent = Get-FileByteEvidence -Path (Join-Path $projectRoot 'absent.json') -Identity 'ABSENT' -DisplayPath 'absent.json' -SnapshotRelative 'output/no-copy.json'
$plain = Get-FileByteEvidence -Path $fixtureInspection -Identity 'PLAIN'
$redacted = Get-FileByteEvidence -Path $fixtureToken -Identity 'OAUTH_RUNTIME_TOKEN_EXTERNAL' -RedactPath -SnapshotRelative $null
$result = @{ absent = $absent; plain_has_default_path = ($plain.path -ceq $fixtureInspection); plain_snapshot_path = $plain.snapshot_path; redacted_snapshot_path = $redacted.snapshot_path; redacted_path = $redacted.path }
""")
        self.assertFalse(result["absent"]["present"])
        for key in ("content_hash", "byte_count", "snapshot_path", "snapshot_hash"):
            self.assertIsNone(result["absent"][key])
        self.assertTrue(result["plain_has_default_path"])
        for key in ("plain_snapshot_path", "redacted_snapshot_path", "redacted_path"):
            self.assertIsNone(result[key])

    def test_existing_inspection_is_not_overwritten_or_recollected(self) -> None:
        result = self._run(r"""
$target = Join-Path $projectRoot ($runRelative + '/stopped-state-pre-regression-inspection.json')
New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
[IO.File]::WriteAllText($target, 'immutable-old-inspection')
$beforeHash = Get-Sha256 -Path $target
$message = $null
try { Write-StoppedOperationalSnapshot -Role PRE_REGRESSION -OutputPath $outputPath -FormerManagerPid 2147483647 -BoundaryStartedAt $maintenanceRequestedAt | Out-Null }
catch { $message = $_.Exception.Message }
$result = @{ message = $message; unchanged = ($beforeHash -ceq (Get-Sha256 -Path $target)); inspection_calls = $inspectionCalls; final_exists = Test-Path -LiteralPath $outputPath }
""")
        self.assertIn("historical evidence is preserved", result["message"])
        self.assertTrue(result["unchanged"])
        self.assertEqual(0, result["inspection_calls"])
        self.assertFalse(result["final_exists"])

    def test_existing_divergent_byte_copy_is_not_overwritten(self) -> None:
        result = self._run(r"""
$relative = 'output/existing-byte-copy.json'
$target = Join-Path $projectRoot $relative
[IO.File]::WriteAllText($target, 'immutable-byte-history')
$beforeHash = Get-Sha256 -Path $target
$message = $null
try { Get-FileByteEvidence -Path $fixtureInspection -Identity 'FIXTURE' -SnapshotRelative $relative | Out-Null }
catch { $message = $_.Exception.Message }
$result = @{ message = $message; unchanged = ($beforeHash -ceq (Get-Sha256 -Path $target)) }
""")
        self.assertEqual("Byte snapshot destination already contains different evidence.", result["message"])
        self.assertTrue(result["unchanged"])

    def test_all_json_consumers_use_explicit_utf8_and_fail_fast_precedes_regression(self) -> None:
        source = SCRIPT.read_text(encoding="utf-8-sig")
        consumers = [line for line in source.splitlines() if "Get-Content" in line and "ConvertFrom-Json" in line]
        self.assertGreaterEqual(len(consumers), 31)
        self.assertTrue(all("-Encoding UTF8" in line for line in consumers))
        function = re.search(r"(?ms)^function Write-StoppedOperationalSnapshot \{.*?(?=^function )", source).group()
        self.assertLess(function.index("Read-StoppedRuntimeTokenMetadata"), function.index("maintenance_protocol inspect"))
        self.assertLess(function.index("Assert-StoppedRuntimeTokenProjection"), function.index("hero_engine.maintenance_snapshot"))
        self.assertNotIn("Write-JsonAtomic -Value $stateProjection", source)
        self.assertNotIn("Write-JsonAtomic -Value $queueBefore", source)
        self.assertNotIn("Write-JsonAtomic -Value $queueAfter", source)
        self.assertLess(source.index("-Role PRE_REGRESSION"), source.index("$compile = Invoke-HiddenProcess"))


if __name__ == "__main__":
    unittest.main()
