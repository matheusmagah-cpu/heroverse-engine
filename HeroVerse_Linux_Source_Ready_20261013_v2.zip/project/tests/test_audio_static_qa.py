"""Public QA entry in isolated roots; codecs simulated, provenance readers real."""
import copy
import json
import shutil
import unittest
from pathlib import Path
from unittest.mock import patch
from tests import test_audio_static_voice_reuse as voice_fixture
from hero_engine.qa_phase5 import run_phase5_quality_gates, _timeline_scan
from hero_engine.continuity import build_visual_continuity_bible
from hero_engine.procedural_infographics_phase5 import compile_audio_static_composition, build_audio_static_source
from hero_engine.asset_quality_phase5 import admit_audio_static_source
from hero_engine.atomic_io import atomic_write_utf8

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    atomic_write_utf8(path, json.dumps(value, ensure_ascii=False, indent=2))


class AudioStaticQaTests(unittest.TestCase):
    def setUp(self):
        self.helper = voice_fixture.AudioStaticVoiceReuseTests('test_current_native_reader_reuses_pcm_despite_visual_change')
        self.addCleanup(self.helper.doCleanups)
        self.helper.setUp()
        self.root = self.helper.root
        shutil.copy2(ROOT/'schemas/phase6_rights_evidence.schema.json', self.root/'schemas')
        self.relative = Path('output/production/own-static-qa')
        self.package = self.root / self.relative
        pack = read(ROOT / 'config/format_packs/fp-narrated-reflection-static-v1.json')
        model = read(ROOT / 'output/modeling/phase4/channel-model-v1/channel_model.json')
        bible = build_visual_continuity_bible(channel_model=model,format_pack=pack,
            asset_manifest={'assets':[]},created_at='2026-10-05T00:00:00Z')
        layout = compile_audio_static_composition(title='One Faithful Step Under Pressure',
            bible=bible, format_pack=pack, font=Path(r'C:\Windows\Fonts\arialbd.ttf'))
        source = self.root / 'output/source'
        evidence = build_audio_static_source(self.root,source,layout=layout,verified_at='2026-10-05T00:00:00Z')
        self.base = source / 'held.json'
        write(self.base,{'asset_id':evidence['asset_id'],'uri':evidence['raster'],
            'content_hash':evidence['raster_hash'],'rights_status':'OWNED',
            'rights_evidence_uri':str(source/'rights.json'),'rights_decision':evidence['decision'],
            'commercial_use':True,'media_type':'GENERATED_IMAGE','semantic_role':'identity','used_ranges':[],
            'production_eligible':False,'content_quality_gate':'BLOCKED',
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False})
        write(source/'rights.json',evidence)
        asset = admit_audio_static_source(self.root,asset_path=self.base,
            expected_asset_hash=voice_fixture.sha(self.base),destination=source/'admission.json',
            created_at='2026-10-05T00:00:00Z')
        self.plan = copy.deepcopy(self.helper.target)
        self.plan.update(style_bible_id=bible['style_bible_id'], video_id='own-audio-qa',
            format_pack_version=pack['version'], quality_profile='DRAFT', total_cost={'external':0},
            render_profile='phase6-standard-palette-qp1-v1')
        self.plan['takes'][0].update(asset_origin=asset['uri']+'#still='+asset['content_hash'],
            media_type='GENERATED_IMAGE',rights={'status':'OWNED','evidence_ref':asset['rights_evidence_uri']},
            on_screen_text=None, transition_in=None, transition_out=None)
        write(self.package/'take_plan.json',self.plan)
        write(self.package/'channel_style_bible.json',bible)
        write(self.package/'asset_manifest.json',{'assets':[asset]})
        path=self.package/'audio/voice_render_manifest.json'
        path.parent.mkdir()
        path.write_bytes(self.helper.voice_path.read_bytes())

    def run_inputs(self):
        with patch('hero_engine.qa_phase5._run',side_effect=AssertionError('no codec for input inspection')):
            return run_phase5_quality_gates(self.root,package_relative=self.relative,inputs_only=True)

    def test_public_inputs_reopens_real_source_and_voice_without_release(self):
        report, measurement = self.run_inputs()
        self.assertEqual(report['status'],'PASS_SOURCE_INPUT_SCOPE')
        self.assertTrue(measurement['intentional_static_hold'])
        self.assertEqual(measurement['rights']['status'],'PASS')
        self.assertFalse(report['publication_eligible'])
        self.assertFalse(report['final_video_quality_authorized'])
        self.assertFalse((self.package/'qa').exists())

    def test_render_missing_cannot_become_final_pass(self):
        with self.assertRaises(FileNotFoundError):
            run_phase5_quality_gates(self.root,package_relative=self.relative)

    def test_overlays_source_clock_or_mixed_take_rejected(self):
        path = self.package/'take_plan.json'
        for kind in ('overlay','source','clock'):
            value = copy.deepcopy(self.plan)
            if kind == 'overlay': value['takes'][0]['on_screen_text']='invented overlay'
            elif kind == 'source': value['takes'][0]['asset_origin']='another.png#still='+ 'sha256:'+'0'*64
            else: value['takes'][0]['start_ms']=1
            write(path,value)
            with self.subTest(kind=kind), self.assertRaises(PermissionError): self.run_inputs()

    def test_voice_copy_divergence_rejected(self):
        self.plan['takes'][0]['narration']='unrelated original audio'
        write(self.package/'take_plan.json',self.plan)
        with self.assertRaises(PermissionError): self.run_inputs()

    def test_minted_admission_or_changed_rights_rejected(self):
        value=read(self.package/'asset_manifest.json')
        value['assets'][0]['render_authorized']=True
        write(self.package/'asset_manifest.json',value)
        with self.assertRaises(PermissionError): self.run_inputs()

    def test_package_escape_blocked_before_io_or_codec(self):
        for path in (Path('../external'), self.package, Path('data/not-production')):
            with self.subTest(path=path), self.assertRaises(PermissionError):
                run_phase5_quality_gates(self.root,package_relative=path,inputs_only=True)

    def test_legacy_timeline_still_reports_repeated_source(self):
        plan={'takes':[{'start_ms':0,'end_ms':1000,'asset_origin':'same.mp4#t=0,1'},
                       {'start_ms':1000,'end_ms':2000,'asset_origin':'same.mp4#t=1,2'}]}
        result=_timeline_scan(plan,{'measurements':{'output_fps':30,
            'maximum_take_duration_error_ms':0,'maximum_cumulative_drift_ms':0}},2000)
        self.assertFalse(result['no_adjacent_source_repeat'])
        self.assertTrue(result['frame_locked'])

    def test_stale_render_rejected_before_measurement(self):
        write(self.package/'render_manifest.json',{'take_plan_id':'stale',
              'output':{'path':str(self.package/'not-current.mp4')}})
        with patch('hero_engine.qa_phase5._probe',side_effect=AssertionError('stale media must not be processed')):
            with self.assertRaises(PermissionError):
                run_phase5_quality_gates(self.root,package_relative=self.relative)

    def test_final_technical_static_hold_not_wrongly_rejected_as_freeze(self):
        from contextlib import ExitStack
        import shutil
        for schema in ('creative_quality_gate_report','narrative_script'):
            shutil.copy2(ROOT/f'schemas/{schema}.schema.json',self.root/'schemas')
        if not getattr(self,'prepared_editorial',False):
            write(self.package/'narrative_script.json',{'full_text':self.plan['takes'][0]['narration']})
            write(self.package/'editorial_brief.json',{'brief_id':'isolated-brief'})
            write(self.package/'creative_direction_decision.json',{'decision_id':'isolated-decision'})
        final=self.package/'synthetic-observation.mp4'
        final.write_bytes(b'codec observation simulated at boundary, never production media')
        duration=self.plan['takes'][-1]['end_ms']
        manifest={'render_id':'isolated-render','pipeline_version':'1.0.0','output':{'path':str(final)},
            'source_asset_ids':[read(self.base)['asset_id']],'external_cost_usd':0,
            'measurements':{'output_fps':30,'maximum_take_duration_error_ms':0,'maximum_cumulative_drift_ms':0}}
        manifest.update({key:self.plan[key] for key in
            ('take_plan_id','style_bible_id','format_pack_id','format_pack_version','video_id')})
        manifest['voice_render_id']=self.helper.voice['voice_render_id']
        manifest['output']['content_hash']=voice_fixture.sha(final)
        if getattr(self,'complete_cycle_manifest_fixture',False):
            # Full documentary receipt for tests whose subject is cycle/report
            # consumption. Codec/probe/ASR remain the explicit simulated
            # boundaries below; this fixture is never live render evidence.
            manifest.update(schema_version='1.0.0',status='COMPLETE',quality_profile=self.plan['quality_profile'],
                pipeline_id='pipeline-audio-static-longform-v1',
                adapter_versions=['isolated-codec-frontier','isolated-voice-frontier'],
                segment_count=len(self.plan['takes']),segment_timeline=[{
                    'take_id':row['take_id'],'planned_start_ms':row['start_ms'],'planned_end_ms':row['end_ms'],
                    'actual_start_ms':row['start_ms'],'actual_end_ms':row['end_ms'],
                    'planned_duration_ms':row['end_ms']-row['start_ms'],
                    'actual_duration_ms':row['end_ms']-row['start_ms'],
                    'frame_count':round((row['end_ms']-row['start_ms'])*30/1000)} for row in self.plan['takes']],
                attribution_path=str(self.package/'asset_manifest.json'),publication_approved=False,
                limitations=['Simulated codec/probe fixture; not a real production or timing observation.'],
                created_at='2026-10-05T00:00:00Z')
            manifest['output'].update(container='mp4',video_codec='h264',audio_codec='aac',width=1920,height=1080,
                fps=30,duration_ms=duration,size_bytes=final.stat().st_size)
            manifest['measurements'].update(total_wall_seconds=0,video_segment_render_seconds=0,
                audio_assembly_seconds=0,final_mux_seconds=0,real_time_factor=0,
                peak_working_set_mb=None,peak_working_set_status='UNAVAILABLE',expected_total_frames=round(duration*30/1000))
            # Fail preparation before expensive QA if any documentary source
            # is incomplete. Existing compact consumers keep their own scope.
            from jsonschema import Draft202012Validator, FormatChecker
            for name,doc in [('take_plan',self.plan),('render_manifest',manifest),
                ('narrative_script',read(self.package/'narrative_script.json')),
                ('creative_direction_decision',read(self.package/'creative_direction_decision.json')),
                ('voice_render_manifest',read(self.package/'audio/voice_render_manifest.json'))]:
                Draft202012Validator(read(ROOT/f'schemas/{name}.schema.json'),format_checker=FormatChecker()).validate(doc)
        write(self.package/'render_manifest.json',manifest)
        additional={}
        if getattr(self,'codec_control_binding',None):
            additional['visual_controls_binding']=self.codec_control_binding
        if getattr(self,'execution_builder',None):
            additional['render_execution_binding']=self.execution_builder(final)
        probe={'format':{'duration':str(duration/1000),'bit_rate':'1000'},
            'streams':[{'codec_type':'video','codec_name':'h264','width':1920,'height':1080,'r_frame_rate':'30/1'},
                       {'codec_type':'audio','codec_name':'aac'}]}
        with ExitStack() as stack:
            import numpy as np
            from PIL import Image
            asset=read(self.package/'asset_manifest.json')['assets'][0]
            with Image.open(asset['uri']) as still:
                decoded=np.asarray(still.convert('RGB')).copy()
            if getattr(self,'decoded_transform',None):
                decoded=self.decoded_transform(decoded)
            def decoded_frames(media, *, expected_frames):
                for _ in range(expected_frames):
                    yield decoded
            stack.enter_context(patch('hero_engine.phase5_autonomous_quality._decoded_static_frames',
                side_effect=decoded_frames))
            model=self.root/'models/kokoro/kokoro-v1.0.fp16.onnx'
            stack.enter_context(patch('hero_engine.phase5_autonomous_quality._asr',return_value={
                'provider':'faster-whisper-base.en-cpu-int8','language':'en',
                'text':' '.join(take['narration'] for take in self.plan['takes']),'local_files_only':True,'cpu_threads':1,
                'model_bindings':[{'path':str(model),'sha256':voice_fixture.sha(model).removeprefix('sha256:')}]}))
            for name,result in {'_probe':probe,'_loudness':{'integrated_lufs':-16,'true_peak_dbtp':-1.5,'lra_lu':3},
                '_black_freeze_scan':{'maximum_black_seconds':0,'maximum_freeze_seconds':duration/1000},
                '_signal_scan':getattr(self,'signal_observation',{'status':'MEASURED','within_take_luminance_delta_p95':0,
                    'flicker_threshold_p95':15,'hard_transition_count':0}),
                '_originality_scan':{'comparison_count':4,'maximum_target_trigram_overlap':0,'threshold':0.02},
                '_create_visual_evidence':{'hook_frames':['own-a','own-b','own-c'],'contact_sheet':'own-sheet'}}.items():
                stack.enter_context(patch('hero_engine.qa_phase5.'+name,return_value=result))
            report, measured=run_phase5_quality_gates(self.root,package_relative=self.relative,**additional)
        gates={row['gate']:row['status'] for row in report['gates']}
        self.assertEqual(gates['TECHNICAL'],'PASS')
        self.assertEqual(gates['MOVEMENT'],'NOT_APPLICABLE')
        self.assertEqual(gates['RIGHTS'],'PASS')
        self.assertEqual(gates['AUDIO'],'PASS')
        self.assertEqual(gates['PUBLICATION'],'BLOCKED')
        self.assertFalse(report['publication_eligible'])
        self.assertIn('static_source_inputs',measured)
        self.assertEqual(measured['static_decoded_visual']['observed_frames'], round(duration*30/1000))
        self.assertFalse(measured['static_decoded_visual']['quality_authorized'])
        self.last_result=(report,measured)
