"""Task 6: exercise the actual composed cancellation with protected DB copies.

All database, marker, receipt, mutex and process identities belong to temporary
fixtures. SQLite connections after fixture setup must target private work copies.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sqlite3
import unittest
from contextlib import ExitStack, closing
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

import hero_engine.maintenance_protocol as protocol


def _load_existing():
    source = Path(__file__).with_name("test_paused_maintenance_cancellation.py")
    spec = importlib.util.spec_from_file_location("_task6_existing_cancellation", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


existing = _load_existing()


@unittest.skipUnless(os.name == "nt", "Windows protected capture contract")
class PausedMaintenanceCaptureCancellationTests(unittest.TestCase):
    # Borrow fixture/support methods, not its TestCase inheritance/discovery.
    _json = staticmethod(existing.PausedMaintenanceCancellationTests._json)
    _archive = existing.PausedMaintenanceCancellationTests._archive
    _update_ack = existing.PausedMaintenanceCancellationTests._update_ack
    _assert_recorded_absence = existing.PausedMaintenanceCancellationTests._assert_recorded_absence
    _assert_blocked_unchanged = existing.PausedMaintenanceCancellationTests._assert_blocked_unchanged

    def setUp(self):
        existing.PausedMaintenanceCancellationTests.setUp(self)
        self._wal_fixture(self.queue)
        self._wal_fixture(self.ledger)
        Path(str(self.ledger) + ".lock").write_bytes(b"SYNTHETIC_QUOTA_LOCK_NOT_TO_REMOVE\x00")

    def _wal_fixture(self, path, *, omit=()):
        """Build genuine, fully checkpointed WAL-mode fixture bytes, never real DBs."""
        with closing(sqlite3.connect(path)) as connection:
            self.assertEqual("wal", connection.execute("PRAGMA journal_mode=WAL").fetchone()[0])
            connection.execute("SELECT count(*) FROM sqlite_master").fetchall()
            self.assertEqual((0, 0, 0), connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone())
            sidecars = {
                suffix: Path(str(path) + suffix).read_bytes() for suffix in ("-wal", "-shm")
            }
            self.assertEqual(b"", sidecars["-wal"])
            self.assertEqual(32768, len(sidecars["-shm"]))
        # Native close owns its cleanup. Restore saved *fixture* sidecar bytes so
        # the composed entry receives the state demonstrated by Task 4.
        for suffix, payload in sidecars.items():
            if suffix not in omit:
                Path(str(path) + suffix).write_bytes(payload)

    def _invoke(self):
        return existing.PausedMaintenanceCancellationTests._invoke(self)

    def _source_set(self):
        paths = []
        for database in (self.queue, self.ledger):
            paths.extend(path for path in database.parent.iterdir()
                         if path.is_file() and path.name.startswith(database.name))
        return {path.relative_to(self.root).as_posix(): path.read_bytes() for path in paths}

    def _protected(self):
        return {**existing.PausedMaintenanceCancellationTests._protected(self),
                **{"database-set:" + name: payload for name, payload in self._source_set().items()}}

    def _capture_manifest(self):
        path = self._archive() / "databases" / "manifest.json"
        return path, json.loads(path.read_text("utf-8"))

    @staticmethod
    def _db_path(argument):
        value = str(argument)
        if value.startswith("file:"):
            value = unquote(value[5:].split("?", 1)[0])
        return Path(value).resolve()

    def _assert_markers_present_without_commit(self, before):
        self.assertEqual(before[0], self.request_path.read_bytes())
        self.assertEqual(before[1], self.ack_path.read_bytes())
        self.assertEqual(existing.PAUSE_BYTES, self.pause.read_bytes())
        self.assertFalse((self._archive() / "committed.json").exists())

    def test_eligible_wal_capture_full_entry_preserves_every_source_byte(self):
        source_before = self._source_set()
        protected_before = self._protected()
        connections = []
        copies = []
        original_connect = sqlite3.connect
        original_capture_init = protocol._PausedCancelDatabaseCapture.__init__

        def capture_init(capture, *args, **kwargs):
            original_capture_init(capture, *args, **kwargs)
            copies.append(capture.work_root.resolve())

        def copy_connection(database, *args, **kwargs):
            candidate = self._db_path(database)
            self.assertFalse(candidate.is_relative_to(self.root), "SQLite opened source/evidence")
            # Constructor may validate SQLite before returning the capture object.
            connections.append(candidate)
            return original_connect(database, *args, **kwargs)

        with patch.object(protocol._PausedCancelDatabaseCapture, "__init__", capture_init), \
                patch.object(protocol.sqlite3, "connect", copy_connection):
            result = self._invoke()
        self.assertEqual("CANCELLED_WHILE_PAUSED", result["status"])
        self.assertTrue(connections)
        self.assertEqual(1, len(copies))
        self.assertTrue(all(path.is_relative_to(copies[0]) for path in connections))
        self.assertFalse(copies[0].exists(), "private work copy was not closed/cleaned")
        self.assertEqual(source_before, self._source_set())
        self.assertFalse(self.request_path.exists())
        self.assertFalse(self.ack_path.exists())
        for key, value in protected_before.items():
            if key not in {str(protocol.REQUEST_PATH), str(protocol.ACK_PATH)}:
                self.assertEqual(value, self._protected()[key], key)
        _, manifest = self._capture_manifest()
        self.assertEqual(existing.REQUEST_ID, manifest["binding"]["request_id"])
        self.assertEqual(self.request_hash, manifest["binding"]["request_hash"])
        self.assertEqual(self.ack_hash, manifest["binding"]["ack_hash"])
        self.assertEqual(set(source_before), {item["relative"] for item in manifest["files"]})
        for item in manifest["files"]:
            data = source_before[item["relative"]]
            self.assertEqual(len(data), item["size_bytes"])
            self.assertEqual(protocol._hash_bytes(data), item["sha256"])
            evidence = self._archive() / "databases" / "evidence" / item["relative"]
            self.assertEqual(data, evidence.read_bytes())
        prepared = json.loads((self._archive() / "prepared.json").read_text("utf-8"))
        self.assertIn("database_capture", prepared)

    def test_private_readonly_wal_sidecars_are_allowed_but_unknown_work_file_blocks(self):
        """SQLite-owned work sidecars are safe; arbitrary work drift is not."""
        source_before = self._source_set()
        binding = {"request_id": existing.REQUEST_ID, "request_hash": self.request_hash,
                   "ack_hash": self.ack_hash}
        with ExitStack() as stack:
            capture = protocol._PausedCancelDatabaseCapture(
                self.root, self._archive(), binding, stack
            )
            for database in (self.queue, self.ledger):
                # The exact work directory is intentionally asserted directly:
                # a read-only SQLite open has created only the native pair.
                names = {path.name for path in capture.work_root.joinpath(
                    database.relative_to(self.root)
                ).parent.glob(database.name + "*")}
                expected = {database.name, database.name + "-wal", database.name + "-shm"}
                if database == self.ledger:
                    expected.add(database.name + ".lock")
                self.assertEqual(expected, names)
            capture.revalidate()
            foreign = capture.work_root / protocol.QUEUE_PATH.parent / (self.queue.name + "-foreign")
            foreign.write_bytes(b"synthetic foreign work companion")
            with self.assertRaisesRegex(PermissionError, "CANCEL_WORK_DATABASE_SET_CHANGED"):
                capture.revalidate()
        self.assertEqual(source_before, self._source_set())

    def test_source_files_remain_write_denied_at_both_marker_removals(self):
        before = self._source_set()
        original_remove = protocol._PausedCancelPin.remove
        observed = []

        def inspect_protection(pin):
            observed.append(pin.path.name)
            for relative in before:
                with self.assertRaises(OSError, msg=relative):
                    with (self.root / relative).open("r+b") as handle:
                        handle.write(b"forbidden concurrent write")
            return original_remove(pin)

        with patch.object(protocol._PausedCancelPin, "remove", inspect_protection):
            self.assertEqual("CANCELLED_WHILE_PAUSED", self._invoke()["status"])
        self.assertEqual(["maintenance-ack.json", "maintenance-request.json"], observed)
        self.assertEqual(before, self._source_set())

    def test_existing_database_writer_blocks_capture_before_removal(self):
        with self.queue.open("r+b"):
            self._assert_blocked_unchanged()

    def test_existing_wal_writer_blocks_capture_before_removal(self):
        with Path(str(self.queue) + "-wal").open("r+b"):
            self._assert_blocked_unchanged()

    def test_lost_source_handle_blocks_even_when_source_bytes_match(self):
        original = protocol._PausedCancelDatabaseCapture.revalidate
        injected = []

        def lose_handle(capture):
            if not injected:
                pin = next(pin for pin in capture.source_pins.values() if pin.path == self.queue)
                pin.close()
                injected.append(True)
            return original(capture)

        with patch.object(protocol._PausedCancelDatabaseCapture, "revalidate", lose_handle):
            self._assert_blocked_unchanged()
        self.assertEqual([True], injected)

    def test_source_byte_divergence_after_forced_loss_blocks_before_removal(self):
        before = (self.request_path.read_bytes(), self.ack_path.read_bytes())
        original = protocol._PausedCancelDatabaseCapture.revalidate
        injected = []

        def diverge(capture):
            if not injected:
                pin = next(pin for pin in capture.source_pins.values() if pin.path == self.queue)
                pin.close()
                self.queue.write_bytes(self.queue.read_bytes() + b"SYNTHETIC_DIVERGENCE")
                injected.append(True)
            return original(capture)

        with patch.object(protocol._PausedCancelDatabaseCapture, "revalidate", diverge):
            with self.assertRaises((PermissionError, OSError, ValueError)):
                self._invoke()
        self.assertEqual([True], injected)
        self._assert_markers_present_without_commit(before)

    def test_manifest_bytes_corrupted_during_capture_do_not_authorize_removal(self):
        original = protocol._write_immutable_bytes
        injected = []

        def corrupt(path, payload):
            if path.name == self.queue.name and "evidence" in path.parts and not injected:
                injected.append(True)
                return original(path, payload + b"SYNTHETIC_COPY_CORRUPTION")
            return original(path, payload)

        with patch.object(protocol, "_write_immutable_bytes", corrupt):
            self._assert_blocked_unchanged()
        self.assertEqual([True], injected)

    def test_capture_persistence_failure_leaves_both_markers_and_incomplete_archive(self):
        original = protocol._write_immutable_bytes
        injected = []

        def fail_copy(path, payload):
            if "databases" in path.parts and "evidence" in path.parts:
                injected.append(True)
                raise OSError("simulated protected capture persistence failure")
            return original(path, payload)

        with patch.object(protocol, "_write_immutable_bytes", fail_copy):
            self._assert_blocked_unchanged()
        self.assertTrue(injected)
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("retry delete")):
            self._assert_blocked_unchanged()

    def test_nonempty_wal_blocks_instead_of_recovering_or_ignoring_it(self):
        Path(str(self.queue) + "-wal").write_bytes(b"SYNTHETIC_NONEMPTY_WAL")
        self._assert_blocked_unchanged()

    def test_incomplete_sidecar_pair_blocks(self):
        # SQLite owns native close/cleanup; fixture restoration omits SHM.
        self._wal_fixture(self.ledger, omit=("-shm",))
        self._assert_blocked_unchanged()

    def test_unexpected_database_companion_blocks(self):
        Path(str(self.queue) + "-unknown").write_bytes(b"SYNTHETIC_UNKNOWN_COMPANION")
        self._assert_blocked_unchanged()

    def test_invalid_shm_size_blocks(self):
        Path(str(self.ledger) + "-shm").write_bytes(b"SYNTHETIC_TRUNCATED_SHM")
        self._assert_blocked_unchanged()

    def test_open_lease_in_capture_blocks_after_matching_ack(self):
        with existing._fixture_database(self.queue) as connection:
            connection.execute("UPDATE jobs SET state='LEASED',lease_owner='synthetic',lease_until='2100-01-01T00:00:00Z'")
        self._update_ack(queue_jobs_hash=protocol.queue_snapshot(self.root)["jobs_hash"])
        self._wal_fixture(self.queue)
        self._assert_blocked_unchanged()

    def test_reserved_quota_in_capture_blocks(self):
        with existing._fixture_database(self.ledger) as connection:
            connection.execute("UPDATE composed_quota_reservations SET state='RESERVED'")
        self._wal_fixture(self.ledger)
        self._assert_blocked_unchanged()

    def test_external_effect_journal_still_blocks_despite_safe_database_copies(self):
        self.publication["effect_journal"] = [{
            "sequence": 1, "effect_id": "SYNTHETIC_UPLOAD", "api_method": "videos.insert",
            "kind": "MUTATION", "checkpoint": "BEFORE", "attempt": 1,
            "request_fingerprint": "c" * 64, "outcome": "PENDING", "evidence": "synthetic",
            "remote_resource_id": None, "checkpointed_at": "2026-09-08T12:59:00Z",
        }]
        protocol.validate(self.root, "youtube_publication_receipt.schema.json", self.publication)
        self._json(self.receipt, self.publication)
        self._assert_blocked_unchanged()

    def test_corrupt_database_copy_is_not_accepted_as_empty_safe_state(self):
        self.queue.write_bytes(b"SYNTHETIC_NOT_A_SQLITE_DATABASE")
        before = self._protected()
        with self.assertRaisesRegex(sqlite3.DatabaseError, "not a database"):
            self._invoke()
        self.assertEqual(before, self._protected())
        self.assertFalse((self._archive() / "committed.json").exists())

    def test_completed_repeat_reuses_bound_evidence_without_new_capture_or_removal(self):
        source_before = self._source_set()
        first = self._invoke()
        archive_before = {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                          for path in self._archive().rglob("*") if path.is_file()}
        with patch.object(protocol._PausedCancelDatabaseCapture, "__init__", side_effect=AssertionError("repeat capture")), \
                patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("repeat removal")), \
                patch.object(protocol.sqlite3, "connect", side_effect=AssertionError("repeat SQLite")):
            repeat = self._invoke()
        self.assertEqual("ALREADY_CANCELLED", repeat["status"])
        self.assertEqual(first["receipt_hash"], repeat["receipt_hash"])
        self.assertEqual(archive_before, {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                                        for path in self._archive().rglob("*") if path.is_file()})
        self.assertEqual(source_before, self._source_set())

    def test_replay_with_tampered_capture_evidence_blocks_without_foreign_removal(self):
        self._invoke()
        evidence = self._archive() / "databases" / "evidence" / protocol.QUEUE_PATH
        evidence.write_bytes(evidence.read_bytes() + b"SYNTHETIC_ARCHIVE_TAMPER")
        protocol.create_request(self.root, request_id=existing.OTHER_ID, requester_pid=7777,
                                guard_seconds=1800, requested_at=existing.REQUESTED)
        self.ack_path.write_bytes(b'{"request_id":"synthetic-foreign"}')
        protected = self._protected()
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("foreign removal")):
            with self.assertRaises((PermissionError, OSError, ValueError)):
                self._invoke()
        self.assertEqual(protected, self._protected())

    def test_partial_ack_removal_preserves_source_capture_and_blocks_blind_retry(self):
        source_before = self._source_set()
        request_before = self.request_path.read_bytes()
        original = protocol._PausedCancelPin.remove

        def interrupt(pin):
            original(pin)
            if pin.path == self.ack_path:
                raise OSError("simulated interruption after ACK removal")

        with patch.object(protocol._PausedCancelPin, "remove", interrupt):
            with self.assertRaises(OSError):
                self._invoke()
        self.assertFalse(self.ack_path.exists())
        self.assertEqual(request_before, self.request_path.read_bytes())
        self.assertEqual(source_before, self._source_set())
        self.assertTrue((self._archive() / "databases" / "manifest.json").is_file())
        self.assertFalse((self._archive() / "committed.json").exists())
        protocol.create_request(self.root, request_id=existing.OTHER_ID, requester_pid=7777,
                                guard_seconds=1800, requested_at=existing.REQUESTED)
        self.ack_path.write_bytes(b'{"synthetic_foreign_ack":true}')
        with patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("foreign cleanup")):
            self._assert_blocked_unchanged()

    def test_source_protection_lost_after_ack_removal_blocks_request_removal(self):
        original_init = protocol._PausedCancelDatabaseCapture.__init__
        original_remove = protocol._PausedCancelPin.remove
        captures = []

        def remember(capture, *args, **kwargs):
            original_init(capture, *args, **kwargs)
            captures.append(capture)

        def lose_after_ack(pin):
            original_remove(pin)
            if pin.path == self.ack_path:
                next(p for p in captures[0].source_pins.values() if p.path == self.queue).close()

        before = self._source_set()
        request_before = self.request_path.read_bytes()
        with patch.object(protocol._PausedCancelDatabaseCapture, "__init__", remember), \
                patch.object(protocol._PausedCancelPin, "remove", lose_after_ack):
            with self.assertRaises((PermissionError, OSError, ValueError)):
                self._invoke()
        self.assertFalse(self.ack_path.exists())
        self.assertEqual(request_before, self.request_path.read_bytes())
        self.assertEqual(before, self._source_set())
        self.assertFalse((self._archive() / "committed.json").exists())

    def test_legacy_1_0_completed_archive_replays_without_capture_sqlite_or_removal(self):
        self.assertEqual("CANCELLED_WHILE_PAUSED", self._invoke()["status"])
        prepared_path = self._archive() / "prepared.json"
        committed_path = self._archive() / "committed.json"
        prepared = json.loads(prepared_path.read_text("utf-8"))
        committed = json.loads(committed_path.read_text("utf-8"))
        # Synthetic compatibility fixture, not a claim of historic execution.
        # Preserve all six legacy evidence files and their original hashes.
        self.assertEqual({"request.json", "ack.json", "PAUSE", "manager.pid",
                          "manager-lock.json", "boundary.json"},
                         set(prepared["evidence_hashes"]))
        prepared.pop("database_capture")
        prepared["schema_version"] = "1.0.0"
        self._json(prepared_path, prepared)
        committed["schema_version"] = "1.0.0"
        committed["prepared_hash"] = protocol.file_hash(prepared_path)
        self._json(committed_path, committed)
        expected_receipt = protocol.file_hash(committed_path)
        before = self._protected()
        archive_before = {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                          for path in self._archive().rglob("*") if path.is_file()}
        with patch.object(protocol._PausedCancelDatabaseCapture, "__init__", side_effect=AssertionError("legacy recapture")), \
                patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("legacy removal")), \
                patch.object(protocol.sqlite3, "connect", side_effect=AssertionError("legacy SQLite")):
            result = self._invoke()
        self.assertEqual("ALREADY_CANCELLED", result["status"])
        self.assertEqual(expected_receipt, result["receipt_hash"])
        self.assertEqual(before, self._protected())
        self.assertEqual(archive_before, {path.relative_to(self._archive()).as_posix(): path.read_bytes()
                                        for path in self._archive().rglob("*") if path.is_file()})

    def test_manual_or_old_capture_pass_without_commit_cannot_authorize_cancellation(self):
        manifest_path = self._archive() / "databases" / "manifest.json"
        manifest_path.parent.mkdir(parents=True)
        self._json(manifest_path, {
            "schema_version": "1.0.0", "status": "PASS", "manual_approval": True,
            "captured_at": "2026-09-01T00:00:00Z", "capture_id": "synthetic-old-capture",
            "binding": {"request_id": existing.REQUEST_ID, "request_hash": self.request_hash,
                        "ack_hash": self.ack_hash},
            "files": [],
        })
        before = self._protected()
        manifest_before = manifest_path.read_bytes()
        with patch.object(protocol._PausedCancelDatabaseCapture, "__init__", side_effect=AssertionError("prior PASS recapture")), \
                patch.object(protocol._PausedCancelPin, "remove", side_effect=AssertionError("prior PASS removal")), \
                patch.object(protocol.sqlite3, "connect", side_effect=AssertionError("prior PASS SQLite")):
            with self.assertRaisesRegex(PermissionError, "CANCEL_INCOMPLETE_PRIOR_ATTEMPT"):
                self._invoke()
        self.assertEqual(before, self._protected())
        self.assertEqual(manifest_before, manifest_path.read_bytes())
        self.assertFalse((self._archive() / "committed.json").exists())


if __name__ == "__main__":
    unittest.main()
