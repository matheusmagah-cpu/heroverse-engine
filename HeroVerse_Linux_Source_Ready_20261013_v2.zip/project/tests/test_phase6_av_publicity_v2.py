"""Declared deterministic FIXTURE observers; no decoder, CV, model or API runs."""
from __future__ import annotations
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch

from hero_engine import phase6_av_publicity_v2 as M

ROOT = Path(__file__).resolve().parents[1]


class FixtureBackend:
    def __init__(self, *, faces=False, pixel_offset=0, decode_error=False, interrupt_after_raw=False):
        self.decodes = []; self.detects = 0; self.faces = faces; self.pixel_offset = pixel_offset
        self.decode_error = decode_error; self.interrupt_after_raw = interrupt_after_raw

    def decode(self, source, index):
        self.decodes.append(index)
        if self.decode_error: raise ValueError("DECLARED_FIXTURE_DECODE_ERROR")
        return b"P6\n2 2\n255\n" + bytes([(index + self.pixel_offset) % 256] * 12)

    def detect(self, frame_path, output_path):
        self.detects += 1
        raw = {"settings": M.SETTINGS, "input_size": [2, 2], "opencv_version": "DECLARED_FIXTURE_NO_OPENCV",
               "retval": 1, "detections": [[0.0] * 14 + [0.9]] if self.faces else None}
        if self.interrupt_after_raw:
            M.save(output_path, raw)
            raise KeyboardInterrupt("DECLARED_FIXTURE_INTERRUPT_AFTER_CAPTURE")
        return raw


class PublicityV2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); self.output = self.root / "output"; self.output.mkdir()
        self.media = self.root / "asset.mp4"; self.media.write_bytes(b"DECLARED_SOURCE_FIXTURE_NOT_REAL_MEDIA")
        self.library = self.root / "library.json"; self.timeline = self.root / "timeline.json"
        self.model = self.root / "yunet.onnx"; self.model.write_bytes((ROOT / M.MODEL).read_bytes())
        self.license = self.root / "LICENSE"; self.license.write_bytes((ROOT / "models/yunet/LICENSE").read_bytes())
        self.stub = self.root / "dependency.fixture"; self.stub.write_bytes(b"DECLARED_FIXTURE_NOT_EXECUTABLE")
        self.policy = {"version": M.VERSION, "settings": copy.deepcopy(M.SETTINGS), "limits": copy.deepcopy(M.LIMITS),
            "sampling": "EVERY_SPAN_START_MIDDLE_END_FRAME_INDEX_NO_CAP", "decoder": "FFMPEG_SELECT_N_RGB24_PPM_NO_SEEK_V1",
            "module": M.binding(Path(M.__file__)), "schema": M.binding(ROOT / M.SCHEMA),
            "legacy_metadata_implementation": M.binding(ROOT / "hero_engine/phase6_publicity.py"),
            "model": M.binding(self.model), "license": M.binding(self.license), "model_card": M.binding(ROOT / "models/yunet/MODEL_CARD.md"),
            "ffmpeg": M.binding(self.stub), "python": M.binding(self.stub), "site_packages": str(self.root / "fake-site"),
            "runtime_files": [M.binding(self.stub)], "authority": M.AUTHORITY, "technical_cost_brl": 0}
        self.policy["runtime_scope"] = "EXECUTABLE_PACKAGES_EXCLUDING_TESTS_PLUS_DISTRIBUTION_RECORDS"
        self.policy_path = self.root / "policy.json"; M.save(self.policy_path, self.policy)
        self.set_sources(4)

    def set_sources(self, count, *, source="https://example.test/independent-nature"):
        M.atomic(self.library, M.canonical({"assets": [{"asset_id": "asset-fixture", "uri": str(self.media),
            "content_hash": M.binding(self.media)["sha256"], "source": source, "creator_or_holder": "Independent creator"}]}))
        spans = [{"span_id": f"span-{i:03d}", "asset_binding": M.binding(self.media),
                  "source_start_frame": i * 10, "source_end_frame": i * 10 + 10} for i in range(count)]
        M.save(self.timeline, {"render_spans": spans})

    def run_scan(self, observer=None, name="scan"):
        observer = observer or FixtureBackend()
        value = M.execute(self.root, run_dir=self.output / name, timeline_binding=M.binding(self.timeline),
            library_binding=M.binding(self.library), policy_binding=M.binding(self.policy_path), evidence_mode="FIXTURE", backend=observer)
        return value, observer

    def verify(self, observer=None, name="verification", now=None, require_live=False):
        return M.verify(self.root, receipt_binding=M.binding(self.output / "scan/receipt.json"), expected_timeline=M.binding(self.timeline),
            expected_library=M.binding(self.library), expected_policy=M.binding(self.policy_path), verification_dir=self.output / name,
            backend=observer or FixtureBackend(), now=now, require_live=require_live)

    def test_every_span_including_more_than_nine_samples(self):
        value, observer = self.run_scan()
        self.assertEqual(value["status"], "PASS"); self.assertEqual(value["evidence_mode"], "FIXTURE")
        self.assertEqual(value["sample_count"], 12)
        self.assertEqual(observer.decodes, [0, 4, 9, 10, 14, 19, 20, 24, 29, 30, 34, 39])
        self.assertEqual(observer.detects, 12); self.assertFalse(any(value["authority"].values()))

    def test_v1_and_v2_domain_dispatch_are_explicitly_incompatible(self):
        from jsonschema import Draft202012Validator, ValidationError
        from hero_engine import phase6_av_publicity as legacy
        value, _observer = self.run_scan()
        old_schema = M.document((ROOT / legacy.SCHEMA).read_bytes())
        new_schema = M.document((ROOT / M.SCHEMA).read_bytes())
        self.assertEqual(new_schema["$id"], "phase6_av_publicity_v2.schema.json")
        self.assertEqual(M.VERSION, "phase6-av-publicity-v2")
        self.assertEqual(legacy.VERSION, "phase6-av-publicity-v1")
        Draft202012Validator(new_schema).validate(value)
        with self.assertRaises(ValidationError): Draft202012Validator(old_schema).validate(value)
        historical = copy.deepcopy(value)
        historical["version"] = legacy.VERSION
        Draft202012Validator(old_schema).validate(historical)
        with self.assertRaises(ValidationError): M._schema(historical)
        old_policy = copy.deepcopy(self.policy)
        old_policy["version"] = legacy.VERSION
        with self.assertRaises(M.PublicityError): M.validate_policy(self.root, old_policy)
        with self.assertRaises(legacy.PublicityError): legacy.validate_policy(self.root, self.policy)

    def test_single_frame_span_and_invalid_span(self):
        self.assertEqual(M.samples(8, 9), [8])
        for start, end in ((1, 1), (2, 1), (-1, 3), (False, 3), (0, 3.0)):
            with self.assertRaises(M.PublicityError): M.samples(start, end)

    def test_deterministic_decoder_command_uses_frame_index_not_seek(self):
        command = M.decode_command(self.policy, M.binding(self.media), 73)
        self.assertIn("select=eq(n\\,73),format=rgb24", command)
        for forbidden in ("-ss", "-t", "-r"):
            self.assertNotIn(forbidden, command)
        self.assertEqual(command[-1], "-")

    def test_completed_execution_replay_has_zero_effects(self):
        first, _ = self.run_scan(); observer = FixtureBackend()
        second, _ = self.run_scan(observer)
        self.assertEqual(first, second); self.assertEqual(observer.decodes, []); self.assertEqual(observer.detects, 0)

    def test_interrupt_after_raw_capture_resumes_without_repeating_captured_effect(self):
        observer = FixtureBackend(interrupt_after_raw=True)
        with self.assertRaises(KeyboardInterrupt): self.run_scan(observer)
        self.assertEqual(observer.decodes, [0]); self.assertEqual(observer.detects, 1)
        resumed = FixtureBackend(); value, _ = self.run_scan(resumed)
        self.assertEqual(value["status"], "PASS"); self.assertNotIn(0, resumed.decodes)
        self.assertEqual(resumed.detects, 11)

    def test_uncertain_effect_does_not_repeat(self):
        class Uncertain(FixtureBackend):
            def detect(self, *args): raise KeyboardInterrupt("uncaptured fixture effect")
        with self.assertRaises(KeyboardInterrupt): self.run_scan(Uncertain())
        resumed = FixtureBackend(); value, _ = self.run_scan(resumed)
        self.assertEqual(value["status"], "FAIL"); self.assertNotIn(0, resumed.decodes)
        self.assertEqual(resumed.detects, 11)

    def test_independent_verification_reobserves_and_never_claims_live_from_fixture(self):
        self.run_scan(); observer = FixtureBackend(); value = self.verify(observer)
        self.assertEqual(value["status"], "PASS_FIXTURE"); self.assertEqual(observer.detects, 12)
        self.assertFalse(any(value["authority"].values()))

    def test_live_rejects_injected_backend_before_any_effect(self):
        observer = FixtureBackend()
        with self.assertRaises(M.PublicityError):
            M.execute(self.root, run_dir=self.output / "blocked", timeline_binding=M.binding(self.timeline),
                library_binding=M.binding(self.library), policy_binding=M.binding(self.policy_path), evidence_mode="LIVE", backend=observer)
        self.assertEqual(observer.decodes, [])

    def test_require_live_rejects_fixture_and_false_never_bypasses_counterproof(self):
        self.run_scan(); observer = FixtureBackend()
        with self.assertRaisesRegex(M.PublicityError, "LIVE source"): self.verify(observer, require_live=True)
        self.assertEqual(observer.decodes, [])
        self.assertEqual(self.verify(observer, require_live=False)["status"], "PASS_FIXTURE")
        self.assertEqual(len(observer.decodes), 12)

    def test_require_live_false_does_not_allow_injected_live_counter_observer(self):
        self.run_scan(); target = self.output / "scan/receipt.json"
        value = M.document(target.read_bytes()); value["evidence_mode"] = "LIVE"
        target.write_bytes(M.canonical(value)); observer = FixtureBackend()
        with self.assertRaisesRegex(M.PublicityError, "injected counter-observer"):
            self.verify(observer, require_live=False)
        self.assertEqual(observer.decodes, []); self.assertEqual(observer.detects, 0)

    def test_false_zero_even_self_consistent_hashes_is_refuted_by_new_detection(self):
        self.run_scan(FixtureBackend(faces=False))
        with self.assertRaisesRegex(M.PublicityError, "contradicts"):
            self.verify(FixtureBackend(faces=True))

    def test_alien_frame_with_self_consistent_hashes_is_refuted_by_source_decode(self):
        self.run_scan(FixtureBackend(pixel_offset=1))
        with self.assertRaisesRegex(M.PublicityError, "contradicts"):
            self.verify(FixtureBackend(pixel_offset=0))

    def test_known_face_or_decode_error_never_passes(self):
        face, _ = self.run_scan(FixtureBackend(faces=True), "face")
        broken, _ = self.run_scan(FixtureBackend(decode_error=True), "broken")
        self.assertEqual(face["status"], "FAIL"); self.assertEqual(face["detected_face_count"], 12)
        self.assertEqual(broken["status"], "FAIL")

    def test_raw_tamper_rejected_without_recollecting(self):
        value, _ = self.run_scan(); row = M.document(M.reopen(self.root, value["samples"][0]))
        Path(row["raw"]["path"]).write_bytes(b"{}"); observer = FixtureBackend()
        with self.assertRaises(M.PublicityError): self.run_scan(observer)
        self.assertEqual(observer.decodes, []); self.assertEqual(observer.detects, 0)

    def test_source_mutation_blocks_before_decoder(self):
        self.media.write_bytes(b"changed source"); observer = FixtureBackend()
        with self.assertRaises(M.PublicityError): self.run_scan(observer)
        self.assertEqual(observer.decodes, [])

    def test_missing_model_and_license_block_before_decoder(self):
        for filename in (self.model, self.license):
            raw = filename.read_bytes(); filename.unlink(); observer = FixtureBackend()
            with self.assertRaises(M.PublicityError): self.run_scan(observer)
            filename.write_bytes(raw); self.assertEqual(observer.decodes, [])

    def test_dependency_tamper_and_threshold_changes_block(self):
        self.stub.write_bytes(b"tampered")
        with self.assertRaises(M.PublicityError): self.run_scan()
        self.stub.write_bytes(b"DECLARED_FIXTURE_NOT_EXECUTABLE")
        changed = copy.deepcopy(self.policy); changed["settings"]["score_threshold"] = .99
        with self.assertRaises(M.PublicityError): M.validate_policy(self.root, changed)

    def test_metadata_risk_is_separate_from_face_detection(self):
        data = M.document(self.library.read_bytes()); data["assets"][0]["source"] = "https://example.test/NASA"
        self.library.write_bytes(M.canonical(data)); value, _ = self.run_scan()
        self.assertEqual(value["status"], "FAIL"); self.assertIn("nasa", value["assets"][0]["metadata_risk_terms"])

    def test_missing_span_and_forged_ttl_block_without_verification_effect(self):
        self.run_scan(); target = self.output / "scan/receipt.json"; original = target.read_bytes()
        for change in ("samples", "valid_until"):
            row = M.document(original)
            if change == "samples": row[change] = row[change][:-1]; row["sample_count"] -= 1
            else: row[change] = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
            target.write_bytes(M.canonical(row)); observer = FixtureBackend()
            with self.assertRaises(M.PublicityError): self.verify(observer)
            self.assertEqual(observer.decodes, [])

    def test_expiry_does_not_refresh_when_replaying(self):
        value, _ = self.run_scan(); expired = M.utc(value["valid_until"]) + timedelta(seconds=1)
        with self.assertRaisesRegex(M.PublicityError, "stale"): self.verify(now=expired)
        second, _ = self.run_scan(); self.assertEqual(value["valid_until"], second["valid_until"])

    def fixed_clock_scan(self):
        """Local fixture only; no real observation time or elapsed-day claim."""
        base = datetime(2026, 9, 8, 0, 0, 0, tzinfo=timezone.utc)
        with patch.object(M, "stamp", return_value=base.isoformat()), \
             patch.object(M, "_clock", return_value=base + timedelta(seconds=1)):
            value, _ = self.run_scan()
        return base, value

    def test_producer_final_clock_is_strict_before_equal_and_after_expiry(self):
        base = datetime(2026, 9, 8, 0, 0, 0, tzinfo=timezone.utc)
        deadline = base + timedelta(seconds=M.LIMITS["ttl_seconds"])
        for microseconds in (-1, 0, 1):
            directory = f"producer-boundary-{microseconds}"
            final_time = deadline + timedelta(microseconds=microseconds)
            with self.subTest(microseconds=microseconds), patch.object(M, "stamp", return_value=base.isoformat()), \
                 patch.object(M, "_clock", return_value=final_time) as clock:
                if microseconds < 0:
                    value, _ = self.run_scan(name=directory)
                    self.assertEqual(value["status"], "PASS")
                    self.assertEqual(M.utc(value["observed_at"]), base)
                    self.assertEqual(M.utc(value["valid_until"]), deadline)
                    self.assertFalse(any(value["authority"].values()))
                else:
                    with self.assertRaisesRegex(M.PublicityError, "expired at producer completion"):
                        self.run_scan(name=directory)
                    self.assertFalse((self.output / directory / "receipt.json").exists())
                    self.assertTrue(list((self.output / directory).glob("asset-*/sample.json")))
                clock.assert_called_once_with()

    def test_producer_rejects_clock_rollback_without_claiming_completion(self):
        base = datetime(2026, 9, 8, 0, 0, 0, tzinfo=timezone.utc)
        with patch.object(M, "stamp", return_value=base.isoformat()), \
             patch.object(M, "_clock", return_value=base - timedelta(microseconds=1)) as clock:
            with self.assertRaisesRegex(M.PublicityError, "future publicity observation"):
                self.run_scan()
        clock.assert_called_once_with()
        self.assertFalse((self.output / "scan/receipt.json").exists())
        self.assertFalse((self.output / "scan/execution.lock").exists())

    def test_producer_invalid_final_instant_never_creates_aggregate_receipt(self):
        base = datetime(2026, 9, 8, 0, 0, 0, tzinfo=timezone.utc)
        for index, invalid in enumerate((None, False, 0, base.isoformat(), base.replace(tzinfo=None))):
            name = f"invalid-clock-{index}"
            with self.subTest(value=invalid), patch.object(M, "stamp", return_value=base.isoformat()), \
                 patch.object(M, "_clock", return_value=invalid):
                with self.assertRaisesRegex(M.PublicityError, "timezone-aware datetime"):
                    self.run_scan(name=name)
            self.assertFalse((self.output / name / "receipt.json").exists())

    def test_completed_cache_expiring_at_final_clock_is_not_refreshed_or_reobserved(self):
        _base, value = self.fixed_clock_scan()
        receipt = self.output / "scan/receipt.json"
        original = receipt.read_bytes()
        observer = FixtureBackend()
        with patch.object(M, "_clock", return_value=M.utc(value["valid_until"])) as clock:
            with self.assertRaisesRegex(M.PublicityError, "expired at producer completion"):
                self.run_scan(observer)
        clock.assert_called_once_with()
        self.assertEqual(observer.decodes, [])
        self.assertEqual(observer.detects, 0)
        self.assertEqual(receipt.read_bytes(), original)

    def test_verifier_initial_expiry_equality_rejects_before_counterproof(self):
        _base, value = self.fixed_clock_scan()
        observer = FixtureBackend()
        with patch.object(M, "_clock", side_effect=AssertionError("NO FINAL CLOCK BEFORE VALID INPUT")) as clock:
            with self.assertRaisesRegex(M.PublicityError, "future/stale"):
                self.verify(observer, now=M.utc(value["valid_until"]))
        clock.assert_not_called()
        self.assertEqual(observer.decodes, [])
        self.assertEqual(observer.detects, 0)
        self.assertFalse((self.output / "verification").exists())

    def test_verifier_final_instant_is_strict_and_exactly_the_verified_at(self):
        base, value = self.fixed_clock_scan()
        deadline = M.utc(value["valid_until"])
        for microseconds in (-1, 0, 1):
            name = f"verification-boundary-{microseconds}"
            observer = FixtureBackend()
            final_time = deadline + timedelta(microseconds=microseconds)
            # Two completions: fresh FIXTURE producer, then independent verifier.
            with self.subTest(microseconds=microseconds), \
                 patch.object(M, "stamp", return_value=(base + timedelta(seconds=3)).isoformat()), \
                 patch.object(M, "_clock", side_effect=[base + timedelta(seconds=4), final_time]) as clock:
                if microseconds < 0:
                    proof = self.verify(observer, name=name, now=base + timedelta(seconds=2))
                    self.assertEqual(proof["status"], "PASS_FIXTURE")
                    self.assertEqual(proof["verified_at"], final_time.isoformat().replace("+00:00", "Z"))
                    self.assertLess(M.utc(proof["verified_at"]), M.utc(proof["valid_until"]))
                    self.assertFalse(any(proof["authority"].values()))
                else:
                    with self.assertRaisesRegex(M.PublicityError, "expired during independent verification"):
                        self.verify(observer, name=name, now=base + timedelta(seconds=2))
                    self.assertFalse((self.output / name / "verification.json").exists())
                    self.assertTrue((self.output / name / "receipt.json").exists())
                self.assertEqual(clock.call_count, 2)
            self.assertEqual(observer.detects, 12)

    def test_verifier_invalid_explicit_now_cannot_fall_back_to_real_clock_or_advance(self):
        base, _value = self.fixed_clock_scan()
        for invalid in (False, 0, "", base.isoformat(), float("nan"), base.replace(tzinfo=None)):
            observer = FixtureBackend()
            with self.subTest(value=invalid), patch.object(M, "_clock", side_effect=AssertionError("NO CLOCK FOR INVALID NOW")) as clock:
                with self.assertRaisesRegex(M.PublicityError, "timezone-aware datetime"):
                    self.verify(observer, now=invalid)
            clock.assert_not_called()
            self.assertEqual(observer.decodes, [])
            self.assertEqual(observer.detects, 0)
            self.assertFalse((self.output / "verification").exists())

    def test_verifier_final_clock_rollback_or_invalid_instant_cannot_write_counterproof(self):
        base, _value = self.fixed_clock_scan()
        for index, invalid in enumerate((base + timedelta(seconds=1), None, False, base.replace(tzinfo=None))):
            name = f"verification-invalid-final-{index}"
            with self.subTest(value=invalid), \
                 patch.object(M, "stamp", return_value=(base + timedelta(seconds=3)).isoformat()), \
                 patch.object(M, "_clock", side_effect=[base + timedelta(seconds=4), invalid]) as clock:
                with self.assertRaises(M.PublicityError):
                    self.verify(name=name, now=base + timedelta(seconds=2))
                self.assertEqual(clock.call_count, 2)
            self.assertFalse((self.output / name / "verification.json").exists())
            self.assertTrue((self.output / name / "receipt.json").exists())

    def test_decode_ppm_and_detector_rows_are_strict(self):
        for raw in (b"", b"P6\n2 2\n255\nwrong", b"P5\n1 1\n255\n\0"):
            with self.assertRaises(M.PublicityError): M.ppm(raw)
        raw = FixtureBackend(faces=True).detect(None, None); raw["detections"][0][-1] = float("nan")
        with self.assertRaises(M.PublicityError): M.face_count(raw, 2, 2)

    def test_absent_detections_is_not_equivalent_to_observed_no_faces(self):
        raw = FixtureBackend().detect(None, None); del raw["detections"]
        with self.assertRaises(M.PublicityError): M.face_count(raw, 2, 2)

    def test_boolean_settings_cannot_impersonate_numeric_recipe(self):
        changed = copy.deepcopy(self.policy); changed["settings"]["threads"] = True
        with self.assertRaises(M.PublicityError): M.validate_policy(self.root, changed)

    def test_real_policy_metadata_only_handles_utf8_venv_configuration(self):
        with patch.object(M, "owned") as effect:
            policy = M.create_policy(ROOT)
        self.assertEqual(policy["model"]["sha256"], "sha256:" + M.YUNET_SHA256)
        self.assertEqual(policy["license"]["sha256"], "sha256:" + M.LICENSE_SHA)
        self.assertGreater(len(policy["runtime_files"]), 2)
        effect.assert_not_called()

    def test_owned_timeout_terminates_only_direct_handle(self):
        child = Mock(returncode=-1); child.poll.return_value=-1
        child.communicate.side_effect = [subprocess.TimeoutExpired([], 1), (b"", b"")]
        with patch.object(M.subprocess, "Popen", return_value=child):
            with self.assertRaisesRegex(M.PublicityError, "timeout"): M.owned(["declared-base-fixture"], 1)
        child.terminate.assert_called_once(); child.kill.assert_not_called()


if __name__ == "__main__": unittest.main(verbosity=2)
