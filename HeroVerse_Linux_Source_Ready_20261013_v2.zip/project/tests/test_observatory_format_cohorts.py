import copy
import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from hero_engine.db import ROOT
from hero_engine.observatory.collectors import _snapshot
from hero_engine.observatory.format_cohorts import (
    FormatCohortError,
    compile_format_cohorts,
    validate_format_cohorts,
)


OPERATION = "format-cohort-test"
CUTOFF = "2026-09-02T12:00:00+00:00"


def _channel(channel_id: str, public_id: str, role: str) -> dict:
    return _snapshot(
        OPERATION,
        channel_id,
        "CHANNEL",
        channel_id,
        CUTOFF,
        f"https://www.youtube.com/channel/{public_id}",
        "COMPLETE",
        {
            "channel_id_public": public_id,
            "catalog_role": role,
        },
    )


def _video(
    channel_id: str,
    public_id: str,
    role: str,
    video_id: str,
    *,
    content_format: object = "LONG",
    age_days: int = 10,
    view_count: object = 100,
    like_count: object = None,
    comment_count: object = None,
    timestamp: object = "AUTO",
    upload_date: object = None,
    collection_status: str = "COMPLETE",
    availability: object = "public",
    public_fields_only: object = True,
    webpage_url: object = "AUTO",
    source_uri: object = "AUTO",
) -> dict:
    published = datetime.fromisoformat(CUTOFF) - timedelta(days=age_days, hours=1)
    observed_timestamp = published.timestamp() if timestamp == "AUTO" else timestamp
    observed_webpage_url = (
        f"https://www.youtube.com/watch?v={video_id}" if webpage_url == "AUTO" else webpage_url
    )
    observed_source_uri = (
        f"https://www.youtube.com/watch?v={video_id}" if source_uri == "AUTO" else source_uri
    )
    return _snapshot(
        OPERATION,
        channel_id,
        "VIDEO",
        video_id,
        CUTOFF,
        observed_source_uri,
        collection_status,
        {
            "video_id": video_id,
            "webpage_url": observed_webpage_url,
            "channel_id_public": public_id,
            "catalog_role": role,
            "content_format": content_format,
            "timestamp": observed_timestamp,
            "upload_date": upload_date,
            "view_count": view_count,
            "like_count": like_count,
            "comment_count": comment_count,
            "availability": availability,
            "public_fields_only": public_fields_only,
        },
    )


class FormatCohortTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def _write(self, snapshots: list[dict], *, captured_at: str = CUTOFF) -> Path:
        path = self.root / "public_snapshots.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": "1.0.0",
                    "operation_id": OPERATION,
                    "captured_at": captured_at,
                    "snapshots": snapshots,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def test_groups_never_mix_channel_format_age_or_owned_market(self) -> None:
        snapshots = [
            _channel("chn-market", "UCMARKET", "MARKET_REFERENCE"),
            _channel("chn-owned", "UCOWNED", "OWNED"),
        ]
        for index, views in enumerate((100, 200, 300, 400), 1):
            snapshots.append(_video("chn-market", "UCMARKET", "MARKET_REFERENCE", f"long-{index}", view_count=views))
            snapshots.append(_video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", f"short-{index}",
                content_format="SHORT", view_count=views * 2,
            ))
            snapshots.append(_video(
                "chn-owned", "UCOWNED", "OWNED", f"owned-{index}",
                content_format="SHORT", age_days=40, view_count=views,
            ))
        path = self._write(snapshots)
        first = compile_format_cohorts(path)
        second = compile_format_cohorts(path)
        self.assertEqual(first, second)
        self.assertEqual(first["schema_version"], "1.1.0")
        self.assertEqual(first["rule_version"], "observatory-format-cohorts-v1.1")
        validate_format_cohorts(first)
        self.assertEqual(len(first["groups"]), 3)
        keys = {
            (item["channel_id"], item["catalog_role"], item["population_scope"], item["content_format"], item["age_band"])
            for item in first["groups"]
        }
        self.assertEqual(keys, {
            ("chn-market", "MARKET_REFERENCE", "MARKET", "LONG", "8_30D"),
            ("chn-market", "MARKET_REFERENCE", "MARKET", "SHORT", "8_30D"),
            ("chn-owned", "OWNED", "OWNED", "SHORT", "31_90D"),
        })
        long_group = next(item for item in first["groups"] if item["content_format"] == "LONG")
        self.assertEqual(long_group["status"], "SUFFICIENT")
        self.assertEqual([item["kind"] for item in long_group["members"]], ["WINNER", "MEDIAN", "MEDIAN", "WEAK"])
        self.assertEqual(long_group["members"][0]["video_id"], "long-4")
        self.assertEqual(long_group["cohorts"]["winner"], [long_group["members"][0]["snapshot_id"]])

    def test_insufficient_group_is_explicit_and_has_no_cohort_labels(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "FORMAT_REFERENCE")]
        snapshots.extend(
            _video("chn-market", "UCMARKET", "FORMAT_REFERENCE", f"video-{index}", view_count=index)
            for index in range(1, 4)
        )
        result = compile_format_cohorts(self._write(snapshots))
        group = result["groups"][0]
        self.assertEqual(group["status"], "INSUFFICIENT_SAMPLE")
        self.assertEqual(group["sample_count"], 3)
        self.assertTrue(all(item["kind"] is None for item in group["members"]))
        self.assertEqual(group["cohorts"], {"winner": [], "median": [], "weak": []})

    def test_missing_metrics_are_not_zero_and_zero_baseline_is_not_a_ratio(self) -> None:
        snapshots = [_channel("chn-owned", "UCOWNED", "OWNED")]
        snapshots.extend(
            _video("chn-owned", "UCOWNED", "OWNED", f"zero-{index}", view_count=0)
            for index in range(4)
        )
        snapshots.append(_video("chn-owned", "UCOWNED", "OWNED", "missing", view_count=None))
        result = compile_format_cohorts(self._write(snapshots))
        group = result["groups"][0]
        self.assertEqual(group["baseline_views_per_day"], 0)
        self.assertEqual(group["relative_velocity_status"], "UNAVAILABLE_ZERO_BASELINE")
        self.assertTrue(all(item["relative_velocity"] is None for item in group["members"]))
        self.assertTrue(all(item["like_count"] is None and item["comment_count"] is None for item in group["members"]))
        self.assertEqual([item["reason"] for item in result["exclusions"]], ["MISSING_VIEW_COUNT"])

    def test_unknown_format_and_invalid_age_are_excluded_without_fallback(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "SPEED_REFERENCE")]
        snapshots.extend([
            _video("chn-market", "UCMARKET", "SPEED_REFERENCE", "unknown", content_format="CLIP"),
            _video("chn-market", "UCMARKET", "SPEED_REFERENCE", "missing-time", timestamp=None),
            _video("chn-market", "UCMARKET", "SPEED_REFERENCE", "future", age_days=-2),
            _video("chn-market", "UCMARKET", "SPEED_REFERENCE", "too-young", age_days=0),
        ])
        result = compile_format_cohorts(self._write(snapshots))
        self.assertEqual(result["groups"], [])
        self.assertEqual({item["reason"] for item in result["exclusions"]}, {
            "UNKNOWN_CONTENT_FORMAT", "INVALID_OR_MISSING_PUBLICATION_TIME", "PUBLICATION_AFTER_CUTOFF",
            "AGE_BELOW_COMPLETE_DAY",
        })

    def test_only_complete_literal_public_watch_pages_enter_public_velocity(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "MARKET_REFERENCE")]
        snapshots.extend([
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "partial",
                collection_status="PARTIAL",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "private",
                availability="private",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "unlisted",
                availability="unlisted",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "missing-availability",
                availability=None,
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "missing-public-flag",
                public_fields_only=None,
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "false-public-flag",
                public_fields_only=False,
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "wrong-id",
                webpage_url="https://www.youtube.com/watch?v=another-id",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "wrong-host",
                source_uri="https://youtube.com/watch?v=wrong-host",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "userinfo",
                source_uri="https://user@www.youtube.com/watch?v=userinfo",
            ),
            _video(
                "chn-market", "UCMARKET", "MARKET_REFERENCE", "http",
                source_uri="http://www.youtube.com/watch?v=http",
            ),
        ])
        result = compile_format_cohorts(self._write(snapshots))
        self.assertEqual(result["groups"], [])
        reasons = [item["reason"] for item in result["exclusions"]]
        self.assertEqual(reasons.count("SNAPSHOT_NOT_COMPLETE"), 1)
        self.assertEqual(reasons.count("AVAILABILITY_NOT_PUBLIC"), 3)
        self.assertEqual(reasons.count("PUBLIC_FIELDS_FLAG_NOT_TRUE"), 2)
        self.assertEqual(reasons.count("INVALID_OR_DIVERGENT_WATCH_URL"), 4)

    def test_invalid_present_timestamp_never_falls_back_to_upload_date(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "FORMAT_REFERENCE")]
        snapshots.append(_video(
            "chn-market", "UCMARKET", "FORMAT_REFERENCE", "invalid-timestamp",
            timestamp="not-a-timestamp", upload_date="20260820",
        ))
        result = compile_format_cohorts(self._write(snapshots))
        self.assertEqual(result["groups"], [])
        self.assertEqual(result["exclusions"][0]["reason"], "INVALID_OR_MISSING_PUBLICATION_TIME")

    def test_date_only_source_declares_date_precision(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "FORMAT_REFERENCE")]
        snapshots.append(_video(
            "chn-market", "UCMARKET", "FORMAT_REFERENCE", "date-only",
            timestamp=None, upload_date="20260820",
        ))
        result = compile_format_cohorts(self._write(snapshots))
        member = result["groups"][0]["members"][0]
        self.assertEqual(member["published_at_precision"], "DATE")
        self.assertEqual(member["published_at"], "2026-08-20T00:00:00+00:00")

    def test_exact_duplicate_is_counted_but_conflicting_duplicate_fails_closed(self) -> None:
        channel = _channel("chn-market", "UCMARKET", "MARKET_REFERENCE")
        video = _video("chn-market", "UCMARKET", "MARKET_REFERENCE", "same")
        result = compile_format_cohorts(self._write([channel, video, copy.deepcopy(video)]))
        self.assertEqual(result["exact_duplicate_count"], 1)
        self.assertEqual(result["source"]["exact_duplicate_video_count"], 1)
        conflicting = copy.deepcopy(video)
        conflicting["snapshot_id"] = "snap-" + hashlib.sha256(b"other").hexdigest()[:24]
        conflicting["payload"]["view_count"] = 999
        with self.assertRaisesRegex(FormatCohortError, "conflicting duplicate entity"):
            compile_format_cohorts(self._write([channel, video, conflicting]))

    def test_identity_naive_time_and_invalid_counts_fail_closed(self) -> None:
        channel = _channel("chn-market", "UCMARKET", "MARKET_REFERENCE")
        mismatch = _video("chn-market", "UCOTHER", "MARKET_REFERENCE", "mismatch")
        with self.assertRaisesRegex(FormatCohortError, "public channel identity diverges"):
            compile_format_cohorts(self._write([channel, mismatch]))
        with self.assertRaisesRegex(FormatCohortError, "explicit UTC offset"):
            compile_format_cohorts(self._write([], captured_at="2026-09-02T12:00:00"))
        invalid_bool = _video("chn-market", "UCMARKET", "MARKET_REFERENCE", "bool", view_count=True)
        with self.assertRaisesRegex(FormatCohortError, "non-negative integer"):
            compile_format_cohorts(self._write([channel, invalid_bool]))
        invalid_nan = _video("chn-market", "UCMARKET", "MARKET_REFERENCE", "nan", like_count=float("nan"))
        with self.assertRaisesRegex(FormatCohortError, "non-finite JSON number"):
            compile_format_cohorts(self._write([channel, invalid_nan]))

    def test_public_channel_alias_and_global_video_alias_fail_closed(self) -> None:
        first = _channel("chn-first", "UCSAME", "MARKET_REFERENCE")
        second = _channel("chn-second", "UCSAME", "FORMAT_REFERENCE")
        with self.assertRaisesRegex(FormatCohortError, "aliased by multiple internal IDs"):
            compile_format_cohorts(self._write([first, second]))

        first = _channel("chn-first", "UCFIRST", "MARKET_REFERENCE")
        second = _channel("chn-second", "UCSECOND", "FORMAT_REFERENCE")
        first_video = _video("chn-first", "UCFIRST", "MARKET_REFERENCE", "global-video")
        second_video = _video("chn-second", "UCSECOND", "FORMAT_REFERENCE", "global-video")
        with self.assertRaisesRegex(FormatCohortError, "global video_id appears under multiple channels"):
            compile_format_cohorts(self._write([first, second, first_video, second_video]))

    def test_duplicate_json_keys_fail_before_any_cohort_is_built(self) -> None:
        path = self.root / "duplicate-keys.json"
        path.write_text(
            '{"schema_version":"1.0.0","operation_id":"one","operation_id":"two",'
            '"captured_at":"2026-09-02T12:00:00+00:00","snapshots":[]}',
            encoding="utf-8",
        )
        with self.assertRaisesRegex(FormatCohortError, "duplicate JSON object key"):
            compile_format_cohorts(path)

    def test_semantic_validator_rejects_tampered_baseline_group_and_rank(self) -> None:
        snapshots = [_channel("chn-market", "UCMARKET", "MARKET_REFERENCE")]
        snapshots.extend(
            _video("chn-market", "UCMARKET", "MARKET_REFERENCE", f"video-{index}", view_count=index * 10)
            for index in range(1, 5)
        )
        valid = compile_format_cohorts(self._write(snapshots))
        for mutate, message in (
            (lambda item: item["groups"][0].__setitem__("baseline_views_per_day", 999), "baseline mismatch"),
            (lambda item: item["groups"][0]["members"][0].__setitem__("rank_position", 2), "rank position mismatch"),
            (lambda item: item["groups"][0]["members"][0].__setitem__("content_format", "SHORT"), "crosses its exact group"),
            (lambda item: item["groups"][0]["members"][0].__setitem__("views_per_complete_day", 999), "views-per-day mismatch"),
            (lambda item: item["groups"][0].__setitem__("population_scope", "OWNED"), "population scope conflicts"),
        ):
            tampered = copy.deepcopy(valid)
            mutate(tampered)
            with self.assertRaisesRegex(FormatCohortError, message):
                validate_format_cohorts(tampered)

    def test_real_frozen_source_compiles_without_writing_legacy_outputs(self) -> None:
        source = ROOT / "output/observatory/phase3/phase3-2026-09-02-catalog-v2/public_snapshots.json"
        before = source.read_bytes()
        result = compile_format_cohorts(source)
        self.assertEqual(source.read_bytes(), before)
        validate_format_cohorts(result)
        self.assertEqual(result["source"]["snapshot_count"], 130)
        self.assertEqual(result["source"]["video_snapshot_count"], 123)
        formats = {group["content_format"] for group in result["groups"]}
        self.assertEqual(formats, {"LONG", "SHORT"})
        self.assertFalse(result["production_authorized"])
        self.assertFalse(result["publication_authorized"])


if __name__ == "__main__":
    unittest.main()
