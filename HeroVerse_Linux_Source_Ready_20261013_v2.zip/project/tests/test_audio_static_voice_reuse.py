import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from hero_engine import phase6_media as media
from hero_engine.render_phase5 import verify_static_voice_reuse
from tests import test_phase6_media as media_fixtures

ROOT = Path(__file__).resolve().parents[1]
RECORD = ROOT / 'output/runtime/gestor-central/maintenance-runs/audio-static-voice-reuse-20261005'


def sha(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


class AudioStaticVoiceReuseTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=RECORD, prefix='own-voice-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        helper = media_fixtures.Phase6MediaTests()
        helper._prepare_voice_inputs(self.root)
        plan_path = self.root / media.BASE / 'production/take_plan.json'
        plan = json.loads(plan_path.read_bytes())
        plan['channel_id'] = getattr(self, 'channel_id', 'owned-test-channel')
        plan_path.write_text(json.dumps(plan), encoding='utf-8')
        binding = helper._espeak_binding(self.root)
        self.addCleanup(binding.close)
        capacity_id = 'capacity-phase6-'+'a'*24
        capacity_path = self.root / 'output/operations/phase6/capacity/receipts' / (capacity_id+'.json')
        capacity = {'schema_version':'1.1.0','receipt_id':capacity_id,'status':'PASS',
                    'espeak':binding.capacity_evidence()}
        with patch.object(media, 'verify_phase6_capacity_receipt', return_value=capacity):
            self.voice = media.synthesize_video2_voice(self.root, created_at='2026-10-05T00:00:00Z',
                capacity_receipt_path=capacity_path, expected_capacity_receipt_id=capacity_id,
                expected_capacity_receipt_sha256='sha256:'+'b'*64,
                voice_builder=lambda *_a,**_k: SimpleNamespace(_heroverse_espeak_binding=binding),
                sample_synthesizer=lambda _engine,output_path,**_k:
                    helper._fake_voice_wav(output_path,duration_ms=500,marker='synthetic-original-test'))
        self.voice_path = self.root / media.BASE / 'audio/voice_render_manifest.json'
        self.expected = sha(self.voice_path)
        self.target = copy.deepcopy(plan)
        self.target.update(format_pack_id='fp-narrated-reflection-static',take_plan_id='static-current-plan')
        self.target['takes'][0].update(asset_origin='owned.png#still=hash',media_type='GENERATED_IMAGE')

    def verify(self):
        with patch.object(media, 'build_local_voice', side_effect=AssertionError('no new synthesis')):
            return verify_static_voice_reuse(self.root,self.target,self.voice_path,
                                            expected_voice_hash=self.expected)

    def test_current_native_reader_reuses_pcm_despite_visual_change(self):
        before = self.voice_path.read_bytes()
        wav = Path(self.voice['takes'][0]['path'])
        pcm = wav.read_bytes()
        bindings = self.verify()
        self.assertEqual(bindings[wav], self.voice['takes'][0]['content_hash'])
        self.assertIn((self.root / media.BASE / 'production/take_plan.json').resolve(), bindings)
        self.assertEqual(self.voice_path.read_bytes(), before)
        self.assertEqual(wav.read_bytes(), pcm)

    def test_copy_timing_order_and_channel_divergence_rejected(self):
        before = copy.deepcopy(self.target)
        for kind in ('copy','time','id','channel'):
            with self.subTest(kind=kind):
                self.target = copy.deepcopy(before)
                if kind == 'copy': self.target['takes'][0]['narration']='different'
                elif kind == 'time': self.target['takes'][0]['end_ms']+=1
                elif kind == 'id': self.target['takes'][0]['take_id']='foreign'
                else: self.target['channel_id']='another-channel'
                with self.assertRaises(PermissionError): self.verify()

    def test_parent_and_wav_tamper_rejected(self):
        parent = self.root / media.BASE / 'audio/manifests' / (self.voice['voice_render_id']+'.json')
        original = parent.read_bytes()
        parent.write_bytes(original+b' ')
        with self.assertRaises(PermissionError): self.verify()
        parent.write_bytes(original)
        wav = Path(self.voice['takes'][0]['path'])
        wav.write_bytes(wav.read_bytes()+b'tamper')
        with self.assertRaises(PermissionError): self.verify()

    def test_caller_hash_or_incomplete_manifest_cannot_authorize_reuse(self):
        self.expected='sha256:'+'0'*64
        with self.assertRaises(PermissionError): self.verify()
        self.expected=sha(self.voice_path)
        self.target['takes']=[]
        with self.assertRaises(PermissionError): self.verify()

    def test_public_static_renderer_uses_native_voice_reader(self):
        from tests.test_audio_static_producer import AudioStaticProducerTests, write
        owner = AudioStaticProducerTests('test_public_native_entry_compiles_static_video_and_reuses_voice')
        self.addCleanup(owner.doCleanups)
        owner.setUp()
        helper = media_fixtures.Phase6MediaTests()
        helper._prepare_voice_inputs(owner.root)
        write(owner.root / media.BASE / 'production/take_plan.json',
              {'take_plan_id':'immutable-original-audio-plan','channel_id':owner.plan['channel_id'],
               'takes':copy.deepcopy(owner.plan['takes'])})
        binding = helper._espeak_binding(owner.root)
        self.addCleanup(binding.close)
        capacity_id='capacity-phase6-'+'c'*24
        capacity_path=owner.root / 'output/operations/phase6/capacity/receipts' / (capacity_id+'.json')
        with patch.object(media,'verify_phase6_capacity_receipt',return_value={
                'schema_version':'1.1.0','receipt_id':capacity_id,'status':'PASS',
                'espeak':binding.capacity_evidence()}):
            voice = media.synthesize_video2_voice(owner.root,created_at='2026-10-05T00:00:00Z',
                capacity_receipt_path=capacity_path, expected_capacity_receipt_id=capacity_id,
                expected_capacity_receipt_sha256='sha256:'+'d'*64,
                voice_builder=lambda *_a,**_k:SimpleNamespace(_heroverse_espeak_binding=binding),
                sample_synthesizer=lambda _engine,output_path,**_k:
                    helper._fake_voice_wav(output_path,duration_ms=500,marker='controlled-original-test'))
        owner.voice = voice
        # Reuse exact serialized immutable bytes, not a JSON reserialization.
        (owner.package / 'audio/voice_render_manifest.json').write_bytes(
            (owner.root / media.BASE / 'audio/voice_render_manifest.json').read_bytes())
        original_probe = owner.fake_probe
        def probe(path):
            if Path(path).suffix == '.wav':
                return {'format':{'duration':'0.5'},'streams':[{'codec_type':'audio'}]}
            return original_probe(path)
        owner.fake_probe = probe
        with patch.object(media,'build_local_voice',side_effect=AssertionError('new synthesis forbidden')):
            result=owner.render()
        self.assertEqual(result['status'],'COMPLETE')
        self.assertFalse(result['publication_approved'])
        bindings=json.loads((owner.package / 'render-input-bindings.json').read_text(encoding='utf-8'))
        self.assertIn('voices-v1.0.bin',json.dumps(bindings))
        self.assertIn('immutable-original-audio-plan',
            (owner.root / media.BASE / 'production/take_plan.json').read_text(encoding='utf-8'))
