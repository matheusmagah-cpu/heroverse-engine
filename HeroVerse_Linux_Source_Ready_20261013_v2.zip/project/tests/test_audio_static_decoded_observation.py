"""Actual raster/metrics/readers; only video decoding is a simulated frontier."""
import json
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image
from tests import test_audio_static_qa as fixture
from hero_engine.phase5_autonomous_quality import measure_audio_static_visual


class StaticDecodeBudgetTests(unittest.TestCase):
    """Exercise the real generator; only the codec and monotonic clock are fake."""
    def decode(self, reads, *, read_seconds=0, conversion_seconds=0, fps=30, expected_frames=2):
        from contextlib import ExitStack
        from unittest.mock import Mock
        from pathlib import Path
        from hero_engine.phase5_autonomous_quality import _decoded_static_frames
        self.clock = 0.0
        self.capture = Mock()
        self.capture.get.return_value = fps
        self.capture.isOpened.return_value = True
        population = iter(reads)
        def read():
            self.clock += read_seconds
            return next(population)
        def convert(frame, mode):
            self.clock += conversion_seconds
            return frame
        stack = ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch('cv2.VideoCapture', return_value=self.capture))
        stack.enter_context(patch('time.monotonic', side_effect=lambda: self.clock))
        stack.enter_context(patch('cv2.cvtColor', side_effect=convert))
        self.capture.read.side_effect = read
        return _decoded_static_frames(Path('isolated.mp4'), expected_frames=expected_frames)

    def test_long_form_complete_decode_may_exceed_short_clip_budget(self):
        # 6000 measured 30 FPS frames = 200s media. Active decode takes 126s:
        # the historical fixed 120s cap rejects an otherwise complete stream.
        frames = self.decode([(True, 'frame')]*6000+[(False, None)],
                             read_seconds=0.021, expected_frames=6000)
        self.assertEqual(len(list(frames)), 6000)
        self.assertGreater(self.clock, 120)
        self.assertLess(self.clock, 200)
        self.assertEqual(self.capture.read.call_count, 6001)
        self.capture.release.assert_called_once()

    def test_long_form_cumulative_decode_remains_bounded_by_media_time(self):
        frames = self.decode([(True, 'frame')]*6000+[(False, None)],
                             read_seconds=0.04, expected_frames=6000)
        with self.assertRaises(TimeoutError): list(frames)
        self.assertLess(self.capture.read.call_count, 6000)
        self.capture.release.assert_called_once()

    def test_long_form_stalled_first_read_remains_blocked(self):
        frames = self.decode([(True, 'frame')], read_seconds=121, expected_frames=324000)
        with self.assertRaises(TimeoutError): next(frames)
        self.capture.release.assert_called_once()

    def test_long_form_missing_and_extra_frames_remain_rejected(self):
        for reads in ([(True, 'frame')]*5999+[(False, None)],
                      [(True, 'frame')]*6001):
            with self.subTest(count=len(reads)):
                with self.assertRaises(PermissionError):
                    list(self.decode(reads, expected_frames=6000))
                self.capture.release.assert_called_once()

    def test_consumer_time_does_not_consume_decoder_budget(self):
        frames = self.decode([(True, 'first'), (True, 'second'), (False, None)], read_seconds=1)
        self.assertEqual(next(frames), 'first')
        self.clock += 121  # work done by the consumer while the generator is suspended
        self.assertEqual(next(frames), 'second')
        self.assertEqual(list(frames), [])
        self.assertEqual(self.capture.read.call_count, 3)
        self.capture.release.assert_called_once()

    def test_slow_first_decode_blocked_before_yield(self):
        frames = self.decode([(True, 'first')], read_seconds=121)
        with self.assertRaises(TimeoutError): next(frames)
        self.capture.release.assert_called_once()

    def test_cumulative_decode_time_still_bounded(self):
        frames = self.decode([(True, 'first'), (True, 'second')], read_seconds=61)
        self.assertEqual(next(frames), 'first')
        with self.assertRaises(TimeoutError): next(frames)
        self.capture.release.assert_called_once()

    def test_conversion_time_included_in_decoder_budget(self):
        frames = self.decode([(True, 'first')], conversion_seconds=121)
        with self.assertRaises(TimeoutError): next(frames)
        self.capture.release.assert_called_once()

    def test_final_population_probe_is_bounded(self):
        frames = self.decode([(True, 'first'), (True, 'second'), (False, None)], read_seconds=41)
        self.assertEqual(next(frames), 'first')
        self.assertEqual(next(frames), 'second')
        with self.assertRaises(TimeoutError): next(frames)
        self.capture.release.assert_called_once()

    def test_missing_extra_and_invalid_fps_remain_rejected(self):
        for reads, fps in (([(False, None)], 30),
                           ([(True, 1), (True, 2), (True, 3)], 30),
                           ([], 29)):
            with self.subTest(fps=fps, reads=reads):
                with self.assertRaises(PermissionError): list(self.decode(reads, fps=fps))
                self.capture.release.assert_called_once()

    def test_early_consumer_close_releases_only_own_capture(self):
        frames = self.decode([(True, 'first')])
        self.assertEqual(next(frames), 'first')
        frames.close()
        self.capture.release.assert_called_once()


class AudioStaticDecodedObservationTests(unittest.TestCase):
    def setUp(self):
        self.helper=fixture.AudioStaticQaTests('test_public_inputs_reopens_real_source_and_voice_without_release')
        self.addCleanup(self.helper.doCleanups)
        self.helper.setUp()
        self.root,self.package=self.helper.root,self.helper.package
        self.media=self.package/'simulated-decoder-input.mp4'
        self.media.write_bytes(b'isolated decoder frontier, not production video')
        self.anchor=fixture.voice_fixture.sha(self.media)
        asset=fixture.read(self.package/'asset_manifest.json')['assets'][0]
        with Image.open(asset['uri']) as image:
            self.reference=np.asarray(image.convert('RGB')).copy()
        self.expected=round(self.helper.plan['takes'][-1]['end_ms']*30/1000)

    def measure(self, frames):
        with patch('hero_engine.phase5_autonomous_quality._decoded_static_frames',return_value=iter(frames)):
            return measure_audio_static_visual(self.root,self.package,self.media,expected_media_hash=self.anchor)

    def test_all_frames_observed_no_semantic_pass_and_repeated_bytes_reuse(self):
        observed=self.measure([self.reference]*self.expected)
        self.assertEqual(observed['observed_frames'],self.expected)
        self.assertEqual(observed['distinct_decoded_frames'],1)
        self.assertAlmostEqual(observed['minimum_text_local_ssim'],1)
        self.assertFalse(observed['acceptance_limits_calibrated'])
        self.assertFalse(observed['quality_authorized'])
        self.assertFalse(observed['publication_authorized'])

    def test_title_damage_in_middle_not_hidden_by_static_first_last_frames(self):
        damaged=self.reference.copy()
        damaged[390:630,180:1740]=self.reference[0,0]
        frames=[self.reference]*self.expected
        frames[len(frames)//2]=damaged
        observed=self.measure(frames)
        self.assertEqual(observed['distinct_decoded_frames'],2)
        self.assertLess(observed['minimum_text_local_ssim'],0.1)
        self.assertGreater(observed['maximum_colour_delta_e'],0)

    def test_incomplete_or_extra_population_rejected(self):
        for count in (self.expected-1,self.expected+1):
            with self.subTest(count=count),self.assertRaises(PermissionError):
                self.measure([self.reference]*count)

    def test_reference_tamper_rejected_before_decode(self):
        asset=fixture.read(self.package/'asset_manifest.json')['assets'][0]
        from pathlib import Path
        Path(asset['uri']).write_bytes(b'changed still')
        with patch('hero_engine.phase5_autonomous_quality._decoded_static_frames',
                   side_effect=AssertionError('must fail before decoding')):
            with self.assertRaises(PermissionError):
                measure_audio_static_visual(self.root,self.package,self.media,expected_media_hash=self.anchor)

    def test_media_change_during_decode_rejected(self):
        def frames(media,*,expected_frames):
            for index in range(expected_frames):
                if index==1: self.media.write_bytes(b'changed media during read')
                yield self.reference
        with patch('hero_engine.phase5_autonomous_quality._decoded_static_frames',side_effect=frames):
            with self.assertRaises(PermissionError):
                measure_audio_static_visual(self.root,self.package,self.media,expected_media_hash=self.anchor)

    def test_wrong_dimensions_or_type_rejected(self):
        for bad in (self.reference[::2,::2],self.reference.astype(np.float32)):
            with self.subTest(shape=str(bad.shape)),self.assertRaises(PermissionError):
                self.measure([bad]*self.expected)

    def test_nonrepresentable_frame_clock_rejected_before_decode(self):
        path=self.package/'take_plan.json'
        plan=fixture.read(path)
        plan['takes'][-1]['end_ms']+=1
        fixture.write(path,plan)
        with patch('hero_engine.phase5_autonomous_quality._decoded_static_frames',
                   side_effect=AssertionError('not a renderer-representable clock')):
            with self.assertRaises(ValueError):
                measure_audio_static_visual(self.root,self.package,self.media,expected_media_hash=self.anchor)

    def test_invalid_decoder_clock_releases_own_capture(self):
        from unittest.mock import Mock
        from hero_engine.phase5_autonomous_quality import _decoded_static_frames
        capture=Mock()
        capture.isOpened.return_value=True
        capture.get.return_value=float('nan')
        with patch('cv2.VideoCapture',return_value=capture):
            with self.assertRaises(PermissionError):
                list(_decoded_static_frames(self.media,expected_frames=1))
        capture.release.assert_called_once()
        capture.read.assert_not_called()
