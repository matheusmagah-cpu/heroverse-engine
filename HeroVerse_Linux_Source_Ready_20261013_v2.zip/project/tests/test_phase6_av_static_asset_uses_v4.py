"""V4 metadata replay once; adversarial fixtures never generate source media."""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jsonschema import Draft202012Validator, ValidationError
from hero_engine import phase6_av_static_asset_uses_v4 as uses
from hero_engine import phase6_av_static_asset_uses_v3 as old_uses
from hero_engine import phase6_av_body_sources as body_sources
from tests.static_input_isolation import historical_input, install_schema, fixture_reader

ROOT = Path(__file__).absolute().parents[1]
SOURCES = uses.sources
HISTORICAL_INPUT = {"path": "output/operations/phase6/av-admission/static-asset-uses-v4/input.json",
                    "sha256": "2c836180912c106d839f4872b3af4bce6fcd2e1340129c677c2db0be76eae6a4"}


class StaticAssetUsesV4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch.object(old_uses, "inspect_static_asset_uses", side_effect=AssertionError("NO V3 REINSPECTION")), \
             patch.object(old_uses.question, "inspect_question_sources", side_effect=AssertionError("NO QUESTION SOURCE INSPECTOR")), \
             patch.object(body_sources, "inspect_body_sources", side_effect=AssertionError("NO BODY SOURCE INSPECTOR")), \
             patch("PIL.Image.open", side_effect=AssertionError("NO PNG DECODE")), \
             patch.object(SOURCES, "_png", side_effect=AssertionError("NO STATIC DECODER")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO OCR/RENDER")), \
             patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")):
            cls.metadata = uses._envelope(ROOT)
        cls.anchors = uses._anchors(*cls.metadata[4:])
        cls.proposal = uses._expected(cls.metadata[1], cls.metadata[2]["input"], cls.metadata[3]["registry"], cls.anchors)
        cls.snapshot = {item["path"]: item["sha256"] for item in cls.metadata[0].bindings.values()}

    @classmethod
    def tearDownClass(cls):
        for path, digest in cls.snapshot.items():
            if SOURCES._sha(Path(path).read_bytes()) != digest:
                raise AssertionError("frozen dependency changed during V4 focal: " + path)

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="uses-v4-FIXTURE-")
        self.addCleanup(temporary.cleanup)
        self.root = self.directory = Path(temporary.name).resolve()
        self.schema_sha = install_schema(self, SOURCES, ROOT, self.root, uses.SCHEMA)

    def binding(self, document=None, name="input.json", *, historical=False):
        if historical:
            self.assertIsNone(document)
            return historical_input(self, SOURCES, ROOT, HISTORICAL_INPUT, self.proposal)
        path = self.directory / name
        raw = SOURCES._canonical(self.proposal if document is None else document)
        path.write_bytes(raw)
        return {"path": path.relative_to(self.root).as_posix(), "sha256": SOURCES._sha(raw)}

    def metadata_fixture(self, _root):
        self.assertIn(_root, (ROOT, self.root))
        reader = fixture_reader(SOURCES, self.root, uses.SCHEMA, self.schema_sha)
        if _root == ROOT:
            reader = SOURCES._Reader(ROOT)
            reader.bindings = copy.deepcopy(self.metadata[0].bindings)
        return reader, *self.metadata[1:]

    def test_schema_and_proposal_preserve29_add12_without_timing_or_new_lineage(self):
        schema = SOURCES._json((ROOT / uses.SCHEMA).read_bytes())
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(self.proposal)
        old_schema = SOURCES._json((ROOT / old_uses.SCHEMA).read_bytes())
        self.assertFalse(Draft202012Validator(old_schema).is_valid(self.proposal))
        self.assertEqual(self.proposal["sources"][:27], self.metadata[2]["input"]["sources"])
        self.assertEqual(self.proposal["uses"][:29], self.metadata[2]["input"]["uses"])
        self.assertEqual((len(self.proposal["sources"]), len(self.proposal["uses"]), len(self.proposal["source_bindings"])), (39, 41, 29))
        self.assertEqual([row["visual_state_id"] for row in self.proposal["uses"][29:]], list(uses.BODY_STATES))
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), patch.object(uses, "_recheck") as checked:
            self.assertEqual(uses.proposed_static_asset_uses(ROOT), self.proposal)
        checked.assert_called_once()

    def test_input_copy_mapping_version_count_cost_and_temporal_mutations_fail(self):
        for kind in ("old_copy", "new_copy", "map", "order", "duplicate", "missing", "time", "cost", "float", "authority", "v3_anchor", "body_claim", "old_version", "extra_binding"):
            document = copy.deepcopy(self.proposal)
            if kind == "old_copy": document["uses"][0]["literal_copy"] = ["unsupported"]
            elif kind == "new_copy": document["uses"][29]["literal_copy"] = ["NAME / TEST / CHOOSE"]
            elif kind == "map": document["uses"][29]["source_id"] = document["sources"][0]["source_id"]
            elif kind == "order": document["uses"][29], document["uses"][30] = document["uses"][30], document["uses"][29]
            elif kind == "duplicate": document["sources"][-1] = copy.deepcopy(document["sources"][-2])
            elif kind == "missing": document["sources"].pop()
            elif kind == "time": document["uses"][-1]["start_frame"] = 0
            elif kind == "cost": document["technical_cost_brl"] = 1
            elif kind == "float": document["technical_cost_brl"] = 0.0
            elif kind == "authority": document["publication_authorized"] = True
            elif kind == "v3_anchor": document["source_bindings"]["v3_execution"]["sha256"] = "0"*64
            elif kind == "body_claim": document["source_bindings"]["body_rights_claim"]["sha256"] = "0"*64
            elif kind == "old_version": document["schema_version"] = "3.0.0"
            else: document["source_bindings"]["arbitrary_future_source"] = document["source_bindings"]["body_case_claim"]
            with self.subTest(kind=kind), patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
                 patch.object(uses, "_append_body_results", side_effect=AssertionError("invalid document cannot bind results")), self.assertRaises((ValueError, ValidationError)):
                uses.inspect_static_asset_uses(self.root, binding=self.binding(document, kind + ".json"))

    def test_binding_hash_namespace_and_noncanonical_json_are_rejected(self):
        binding = self.binding()
        path = self.root / binding["path"]
        path.write_bytes(path.read_bytes() + b"\n")
        invalid = [{**binding, "sha256": SOURCES._sha(path.read_bytes())}, {**binding, "sha256": "0"*64},
                   {**binding, "path": "../input.json"}, {**binding, "extra": True}]
        for item in invalid:
            with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), self.assertRaises(ValueError):
                uses.inspect_static_asset_uses(self.root, binding=item)

    def test_body_source_proof_must_equal_registered_right_before_association(self):
        current = copy.deepcopy(self.metadata[3])
        current["sources"][0]["inspection_id"] = "synthetic-different-source"
        with self.assertRaisesRegex(ValueError, "registered right"):
            uses._append_body_results(self.proposal, self.metadata[1], self.metadata[2], current)

    def test_source_right_literal_association_still_blocks_coherently_rehashed_fixture(self):
        for kind in ("copy", "entry", "fragments", "state", "description", "frame", "sample", "ready", "authority", "projection", "lineage"):
            current = copy.deepcopy(self.metadata[3])
            proof, right = current["sources"][-1], current["rights"][-1]
            if kind == "copy": proof["literal_copy"] = ["Unsupported claim"]
            elif kind == "entry": proof["entry"]["kind"] = "UNIT_ENTRY"
            elif kind == "fragments": proof["unit_fragment_ids"] = ["take-060"]
            elif kind == "state": proof["state_id"] = "visual-u038-s01"
            elif kind == "description": proof["visual_content"]["description"] = "New visual meaning"
            elif kind == "frame": proof["source_frame_count"] = 2
            elif kind == "sample": proof["observed_sample"] = 800
            elif kind == "ready": proof["source_ready"] = True
            elif kind == "authority": proof["authority"]["quality_approved"] = True
            elif kind == "projection": proof["source_bindings"]["visual_projection"]["sha256"] = "0"*64
            else: proof["lineage_id"] = "SYNTHETIC_FOURTH_LINEAGE"
            # An explicitly synthetic coherent hash is not a new registry.
            right["source_proof"]["sha256"] = SOURCES._sha(SOURCES._canonical(proof))
            right["source_proof"]["timeline_canonical_sha256"] = uses.canonical_sha(proof)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                uses._append_body_results(self.proposal, self.metadata[1], self.metadata[2], current)

    def test_right_scope_publicity_and_document_substitution_never_promote(self):
        for kind in ("mode", "owned", "publicity", "provenance", "decision"):
            current = copy.deepcopy(self.metadata[3])
            right = current["rights"][0]
            if kind == "mode": right["evidence_mode"] = "FIXTURE"
            elif kind == "owned": right["rights_status"] = "UNKNOWN"
            elif kind == "publicity": right["authority"]["publicity_approved"] = True
            elif kind == "provenance": right["provenance_binding"]["sha256"] = "0"*64
            else: right["decision_binding"]["sha256"] = "0"*64
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                uses._append_body_results(self.proposal, self.metadata[1], self.metadata[2], current)

    def test_case_cannot_change_existing_use_or_hide_pending_states(self):
        literal = copy.deepcopy(self.metadata[1])
        indexed = {state["state_id"]: state for row in literal["rows"] for state in row["states"]}
        indexed[self.proposal["uses"][0]["visual_state_id"]]["visual_content"]["literal_copy"] = ["changed"]
        with self.assertRaisesRegex(ValueError, "existing use"):
            uses._expected(literal, self.metadata[2]["input"], self.metadata[3]["registry"], self.anchors)

    def test_current_integration_reuses_metadata_and_preserves_v5_v6_separation(self):
        bound = self.binding(historical=True)
        with patch.object(uses, "_envelope", side_effect=self.metadata_fixture), \
             patch.object(old_uses, "inspect_static_asset_uses", side_effect=AssertionError("NO OLD INSPECTOR")), \
             patch.object(body_sources, "inspect_body_sources", side_effect=AssertionError("NO BODY DECODE")), \
             patch("PIL.Image.open", side_effect=AssertionError("NO IMAGE")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO PROCESS")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("NO WRITES")):
            proof = uses.inspect_static_asset_uses(ROOT, binding=bound)
        self.assertEqual((proof["source_count"], proof["use_count"], proof["unique_png_content_count"], proof["lineage_count"]), (39, 41, 37, 3))
        self.assertEqual(len(proof["remaining_unbound_visual_state_ids"]), 59)
        self.assertEqual(proof["sources"][:27], self.metadata[2]["inspection"]["sources"])
        self.assertEqual(proof["uses"][:29], self.metadata[2]["inspection"]["uses"])
        self.assertEqual(proof["prior_visual_amendment_evidence"], self.metadata[2]["inspection"]["visual_amendment_evidence"])
        self.assertEqual(proof["visual_amendment_evidence"]["prior_case_inspection_sha256"], uses.canonical_sha(self.metadata[2]["literal"]))
        self.assertEqual((proof["image_decode_calls"], proof["ocr_inference_calls"], proof["render_calls"]), (0, 0, 0))
        self.assertTrue(all(value is False for value in proof["authority"].values()))
        joined = uses.joiner.join(proof, {"path": bound["path"], "sha256": "sha256:" + bound["sha256"]}, self.metadata[1])
        self.assertEqual(joined["use_count"], 41)
        mapped = {row["state_id"]: row for row in proof["sources"]}
        self.assertEqual(mapped["visual-u036-s00"]["asset_binding"]["sha256"], mapped["visual-u037-s00"]["asset_binding"]["sha256"])
        self.assertNotEqual(mapped["visual-u036-s00"]["source_id"], mapped["visual-u037-s00"]["source_id"])
        self.assertEqual(mapped["visual-u038-s02"]["original_lexical_target"]["fragment_ids"], ["take-059", "take-060"])

    def test_allowlist_model_limit_stays_exact32_and_other_files16(self):
        path, (digest, size) = next((p, pin) for p, pin in body_sources.MODEL_PINS.items() if pin[1] > 16*1024**2)
        class SizeOnly:
            def __len__(self): return size
        class FixtureReader:
            root = ROOT
            def __init__(self): self.calls = []
            def read_path(self, path, sha, *, limit):
                self.calls.append(limit)
                if size > limit: raise ValueError("fixture exceeds bound")
                return SizeOnly()
        binding = dict(path=str(ROOT / path), sha256=digest, size_bytes=size)
        reader = FixtureReader()
        uses._dependencies(reader, [binding])
        self.assertEqual(reader.calls, [32*1024**2])
        for item in ({**binding, "sha256": "0"*64}, {**binding, "size_bytes": float(size)}, {**binding, "path": str(ROOT / "unlisted.onnx")}):
            with self.assertRaises(ValueError): uses._dependencies(FixtureReader(), [item])

    def test_verifier_reopens_then_rejects_numeric_and_authority_changes(self):
        expected = dict(version=uses.VERSION, source_count=39, source_ready=False, authority=uses.AUTHORITY)
        binding = self.binding()
        with patch.object(uses, "inspect_static_asset_uses", return_value=expected) as inspect:
            self.assertEqual(uses.verify_static_asset_uses(copy.deepcopy(expected), self.root, binding=binding), expected)
            inspect.assert_called_once_with(self.root, binding=binding)
            for key, value in (("source_count", 39.0), ("source_ready", True), ("start_sample", 0)):
                changed = copy.deepcopy(expected)
                changed[key] = value
                with self.assertRaises(ValueError): uses.verify_static_asset_uses(changed, self.root, binding=binding)


if __name__ == "__main__":
    unittest.main()
