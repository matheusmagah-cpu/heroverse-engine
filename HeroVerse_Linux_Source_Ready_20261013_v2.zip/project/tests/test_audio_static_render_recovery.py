"""Native producer -> anchored resident recovery; codec/host boundary simulated."""
import copy
import hashlib
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import cli, render_phase5 as render
from hero_engine.production_capacity import ResourceWait
from tests import test_audio_static_producer as fixture


class AudioStaticRenderRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.owner = fixture.AudioStaticProducerTests('test_public_native_entry_compiles_static_video_and_reuses_voice')
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        self.first = self.owner.render()
        self.bindings = {name: {'path': str(self.owner.package / filename),
                               'sha256': fixture.digest(self.owner.package / filename)}
                         for name, filename in (
                             ('render_manifest', 'render_manifest.json'),
                             ('render_inputs', 'render-input-bindings.json'),
                             ('render_execution', 'resource-observation.json'))}

    def recover(self):
        with patch('hero_engine.production_capacity.subprocess.run', side_effect=AssertionError('Resident recovery dispatched a process')):
            return render.render_phase5_pilot(self.owner.root, package_relative=self.owner.relative,
                                              recovery_bindings=self.bindings)

    def test_native_resident_recovery_returns_exact_manifest_without_codec(self):
        commands = copy.deepcopy(self.owner.commands)
        before = {name: Path(row['path']).read_bytes() for name, row in self.bindings.items()}
        self.assertEqual(self.recover(), self.first)
        self.assertEqual(self.recover(), self.first)
        self.assertEqual(self.owner.commands, commands)
        self.assertEqual({name: Path(row['path']).read_bytes() for name, row in self.bindings.items()}, before)

    def test_each_external_anchor_tamper_blocks_without_process(self):
        for name, row in self.bindings.items():
            with self.subTest(anchor=name):
                path = Path(row['path']); before = path.read_bytes()
                try:
                    path.write_bytes(before + b' ')
                    with self.assertRaisesRegex(PermissionError, 'anchor differs'):
                        self.recover()
                finally:
                    path.write_bytes(before)

    def test_current_source_change_does_not_reuse_historical_render(self):
        self.owner.vector.write_bytes(self.owner.vector.read_bytes() + b' ')
        with self.assertRaisesRegex(PermissionError, 'input changed'):
            self.recover()

    def test_missing_or_partial_operation_never_dispatches_replacement(self):
        path = self.owner.package / 'render_manifest.json'
        before = path.read_bytes(); path.unlink()
        try:
            with self.assertRaises(FileNotFoundError):
                self.recover()
        finally:
            path.write_bytes(before)

    def test_pause_contains_resident_recovery(self):
        marker = self.owner.root / 'output/runtime/gestor-central/PAUSE'
        marker.parent.mkdir(parents=True, exist_ok=True); marker.write_bytes(b'fixture owner pause')
        with self.assertRaises(ResourceWait):
            self.recover()
        self.assertEqual(marker.read_bytes(), b'fixture owner pause')

    def test_changed_manifest_identity_rejected_even_with_declared_anchor(self):
        path = self.owner.package / 'render_manifest.json'
        value = fixture.read(path); value['take_plan_id'] = 'foreign-plan'
        fixture.write(path, value)
        # Explicit negative: even a caller declaring the changed hash cannot
        # make a foreign operation agree with the authenticated input witness.
        self.bindings['render_manifest']['sha256'] = fixture.digest(path)
        with self.assertRaisesRegex(PermissionError, 'identity/authority'):
            self.recover()

    def test_existing_cli_recovers_and_rejects_unanchored_bindings(self):
        path = self.owner.package / 'recovery-bindings.json'
        fixture.write(path, self.bindings)
        anchor = fixture.digest(path)
        args = cli.build_parser().parse_args(['render', '--pilot-package', str(self.owner.relative),
            '--render-recovery-bindings', str(path), '--expected-recovery-hash', anchor])
        with patch.object(cli, 'ROOT', self.owner.root), patch.object(cli, '_print_json') as output, \
             patch('hero_engine.production_capacity.subprocess.run', side_effect=AssertionError('CLI recovery dispatched a process')):
            args.func(args)
            self.assertEqual(output.call_args.args[0], self.first)
            path.write_bytes(b'{}')
            with self.assertRaisesRegex(PermissionError, 'external anchor'):
                args.func(args)

    def test_manager_recovers_native_operation_before_current_quality_gate(self):
        from hero_engine import central_manager_phase5 as manager
        selection = {'render_recovery': copy.deepcopy(self.bindings)}
        before = copy.deepcopy(selection)
        class GateBoundaryReached(Exception):
            pass
        # This test ends at the subsequent quality gate, not a fabricated PASS.
        # Recovery readers, resource witness and the manager entry are real.
        with patch('hero_engine.production_capacity.subprocess.run', side_effect=AssertionError('Manager dispatched codec')), \
             patch.object(render, 'render_phase5_pilot', wraps=render.render_phase5_pilot) as native, \
             patch.object(manager, 'build_release_gate', side_effect=GateBoundaryReached) as gate, \
             patch.object(manager, '_build_live_service') as provider, self.assertRaises(GateBoundaryReached):
            manager.run_cycle(self.owner.root, package_relative=self.owner.relative, current_bindings=selection)
        native.assert_called_once()
        self.assertEqual(gate.call_args.kwargs['current_bindings'], {})
        provider.assert_not_called()
        self.assertEqual(selection, before)

    def test_manager_damaged_recovery_cannot_reach_quality_or_provider(self):
        from hero_engine import central_manager_phase5 as manager
        row = self.bindings['render_inputs']
        Path(row['path']).write_bytes(Path(row['path']).read_bytes() + b' ')
        with patch.object(manager, 'build_release_gate') as gate, \
             patch.object(manager, '_build_live_service') as provider, \
             self.assertRaisesRegex(PermissionError, 'anchor differs'):
            manager.run_cycle(self.owner.root, package_relative=self.owner.relative,
                              current_bindings={'render_recovery': self.bindings})
        gate.assert_not_called(); provider.assert_not_called()

    def test_manager_pause_prevents_even_completed_recovery(self):
        from hero_engine import central_manager_phase5 as manager
        marker = self.owner.root / manager.RUNTIME / 'PAUSE'
        marker.parent.mkdir(parents=True, exist_ok=True); marker.write_bytes(b'fixture owner pause')
        with patch.object(render, 'render_phase5_pilot') as producer:
            result = manager.run_cycle(self.owner.root, package_relative=self.owner.relative,
                                      current_bindings={'render_recovery': self.bindings})
        producer.assert_not_called()
        self.assertEqual(result['mode'], 'PAUSED')
        self.assertEqual(marker.read_bytes(), b'fixture owner pause')


class AudioStaticRenderRecoveryPopulationTests(unittest.TestCase):
    def test_reused_fixture_class_is_not_exposed_to_discovery(self):
        import sys
        def identifiers(suite):
            for item in suite:
                if isinstance(item, unittest.TestSuite):yield from identifiers(item)
                else:yield item.id()
        rows = list(identifiers(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])))
        self.assertEqual(len(rows), 16)
        self.assertTrue(all(row.startswith(__name__ + '.') for row in rows), rows)


class AudioStaticPendingReceiptTests(unittest.TestCase):
    def setUp(self):
        self.owner = fixture.AudioStaticProducerTests('test_public_native_entry_compiles_static_video_and_reuses_voice')
        self.addCleanup(self.owner.doCleanups)
        self.owner.setUp()
        operation = self.owner.root / 'output/runtime/gestor-central/maintenance-runs/own-render/operation.json'
        names = ('take_plan.json', 'audio/voice_render_manifest.json',
                 'asset_manifest.json', 'channel_style_bible.json')
        fixture.write(operation, {'operation': 'RENDER', 'inputs': {
            name: {'path': (self.owner.package / name).relative_to(self.owner.root).as_posix(),
                   'sha256': fixture.digest(self.owner.package / name)} for name in names},
            'result': {'expected': {'publication_effects': 0}}})
        original_writer = render.atomic_write_utf8
        def fail_receipt(path, value):
            if Path(path).name == 'render-input-bindings.json':
                raise OSError('controlled post-codec receipt failure')
            return original_writer(path, value)
        with patch.object(render, 'atomic_write_utf8', side_effect=fail_receipt):
            with self.assertRaisesRegex(OSError, 'controlled post-codec'):
                self.owner.render()
        self.bindings = {'render_operation': {'path': str(operation), 'sha256': fixture.digest(operation)},
            'render_execution': {'path': str(self.owner.package / 'resource-observation.json'),
                                 'sha256': fixture.digest(self.owner.package / 'resource-observation.json')}}

    def recover(self):
        with patch('hero_engine.production_capacity.subprocess.run', side_effect=AssertionError('Recovery dispatched codec')), \
             patch.object(render, '_probe', side_effect=self.owner.fake_probe):
            return render.render_phase5_pilot(self.owner.root, package_relative=self.owner.relative,
                                            recovery_bindings=self.bindings)

    def test_post_codec_receipt_closes_without_codec_or_output_change(self):
        media = self.owner.package / 'renders/move-after-amen.phase5-draft.mp4'
        before = media.read_bytes()
        commands = copy.deepcopy(self.owner.commands)
        result = self.recover()
        self.assertEqual(result['status'], 'COMPLETE')
        self.assertFalse(result['publication_approved'])
        self.assertEqual(media.read_bytes(), before)
        self.assertEqual(self.owner.commands, commands)
        self.assertIn('not retroactively captured', result['limitations'][-1])

    def test_original_input_drift_blocks_without_receipt(self):
        path = self.owner.package / 'take_plan.json'
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaisesRegex(PermissionError, 'Original render input changed'):
            self.recover()
        self.assertFalse((self.owner.package / 'render_manifest.json').exists())

    def test_observed_audio_command_change_blocks_even_with_new_declared_anchor(self):
        path = Path(self.bindings['render_execution']['path'])
        record = fixture.read(path)
        rows = [row['execution'] for row in record['observations'] if 'execution' in row]
        command = next(row['argv'] for row in rows if '-af' in row['argv'])
        command[command.index('-af') + 1] = 'anull'
        fixture.write(path, record)
        self.bindings['render_execution']['sha256'] = fixture.digest(path)
        with self.assertRaisesRegex(PermissionError, 'Observed command differs'):
            self.recover()
        self.assertFalse((self.owner.package / 'render_manifest.json').exists())

    def test_missing_or_changed_execution_cannot_close_receipt(self):
        path = Path(self.bindings['render_execution']['path'])
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaisesRegex(PermissionError, 'anchor differs'):
            self.recover()

    def test_pending_receipt_respects_pause(self):
        marker = self.owner.root / 'output/runtime/gestor-central/PAUSE'
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_bytes(b'fixture owner pause')
        with self.assertRaises(ResourceWait):
            self.recover()
        self.assertEqual(marker.read_bytes(), b'fixture owner pause')
