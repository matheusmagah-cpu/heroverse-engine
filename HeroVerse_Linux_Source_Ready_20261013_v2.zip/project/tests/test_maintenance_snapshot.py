from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from hero_engine import maintenance_snapshot as module
from hero_engine.maintenance_protocol import canonical_hash


def digest(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


@contextmanager
def fixture():
    with tempfile.TemporaryDirectory(prefix="snapshot-composer-test-") as folder:
        base = Path(folder)
        root = base / "workspace-área"
        root.mkdir()
        request = "maintenance-request-composer-fixture"
        run = root / "output/runtime/gestor-central/maintenance-runs" / request
        scope = run / "stopped-state-bytes/pre-regression"
        scope.mkdir(parents=True)
        token = base / "external-synthetic-only.json"
        token.write_bytes(b"SYNTHETIC-NOT-A-CREDENTIAL")
        token_hash = digest(str(token.resolve()).lower().encode())
        watcher_relative = "output/runtime/gestor-central/oauth-reconsent-watcher.json"
        watcher = {"destination_path": str(token), "destination_exists": True, "destination_outside_workspace": True, "destination_path_sha256": token_hash[7:]}
        source = root / watcher_relative
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_text(json.dumps(watcher), encoding="utf-8")
        groups = {key: [] for key in module.GROUPS}
        expected = {
            "queue_store_files": [("output/operations/phase6/runtime/phase6-queue.sqlite3" + suffix, "QUEUE_" + tag) for suffix, tag in (("", "MAIN"), ("-wal", "WAL"), ("-shm", "SHM"))],
            "quota_store_files": [("output/operations/zero-cost/phase6-quota-ledger.sqlite3" + suffix, "QUOTA_" + tag) for suffix, tag in (("", "MAIN"), ("-wal", "WAL"), ("-shm", "SHM"))],
            "operational_effect_receipt_files": [],
            "operational_effect_surface_files": [(p, "EFFECT_SURFACE:" + p) for p in ("output/operations/phase6/package-treatment-executor-status.json", "output/operations/phase6/publication-controller-status.json")],
            "oauth_proof_files": [(p, "OAUTH_PROOF:" + p) for p in (
                "output/runtime/gestor-central/oauth-session-health.json", "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
                watcher_relative, "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json", "output/integrations/youtube/heroverse/connection-receipt.json", "output/runtime/gestor-central/maintenance-capability.json")],
        }
        for group, entries in expected.items():
            for relative, identity in entries:
                path = root / relative
                present = path.is_file()
                raw = path.read_bytes() if present else None
                snap = scope / (hashlib.sha256(relative.encode()).hexdigest()[:16] + ".json")
                if present:
                    snap.write_bytes(raw)
                groups[group].append({"identity": identity, "path": relative, "path_identity_hash": digest(str(path.resolve()).lower().encode()), "present": present, "byte_count": len(raw) if raw is not None else None, "content_hash": digest(raw) if raw is not None else None, "snapshot_path": snap.relative_to(root).as_posix() if present else None, "snapshot_hash": digest(raw) if raw is not None else None})
        groups["oauth_runtime_token"] = {"identity": "OAUTH_RUNTIME_TOKEN_EXTERNAL", "path": None, "path_identity_hash": token_hash, "present": True, "byte_count": token.stat().st_size, "content_hash": digest(token.read_bytes()), "snapshot_path": None, "snapshot_hash": None}
        jobs = [{"created_at": "2026-09-05T23:14:35.284910Z", "checkpoint": {"quota_debit": {"consumed_at": "2026-09-05T23:15:57.284910Z"}}, "cases": [None, True, False, [], {}, [None], 1.25, 9007199254740993, 18446744073709551615, "ação 日本語"], "times": [f'2026-09-06T09:00:00.{"1" + "0" * (n - 1)}{offset}' for n in range(1, 8) for offset in ("Z", "+02:30")]}]
        inspection = {"manager_pid": 2147483647, "blockers": [], "observed_at": "2026-09-06T09:00:01Z", "active_lease_job_ids": [], "quota": {"reserved_ids": []}, "queue": {"jobs": jobs, "jobs_hash": canonical_hash(jobs)}, "quota_ledger": {"tables": [], "state_hash": canonical_hash([])}, "operational_effects": {"receipts": [], "receipts_hash": canonical_hash([]), "open_receipt_paths": []}}
        inspection_path = run / "stopped-state-pre-regression-inspection.json"
        inspection_path.write_bytes(module._bytes(inspection))
        envelope = {"schema_version": "1.0.0", "request_id": request, "role": "PRE_REGRESSION", "requested_at": "2026-09-06T09:00:00Z", "zero_effect_boundary_started_at": "2026-09-06T09:00:00Z", "observed_at": "2026-09-06T09:00:02Z", "former_manager_pid": 2147483647, "inspection_path": inspection_path.relative_to(root).as_posix(), "inspection_hash": digest(inspection_path.read_bytes()), "byte_evidence": groups}
        yield root, envelope, inspection, run


class MaintenanceSnapshotTests(unittest.TestCase):
    def test_lossless_types_and_timestamps_canonical_bundle_and_summary(self):
        with fixture() as (root, envelope, inspection, run):
            summary = module.compose(root, envelope)
            snapshot = json.loads((root / summary["snapshot_path"]).read_bytes())
            canonical = json.loads((root / summary["canonical_state_path"]).read_bytes())
            queue = json.loads((root / summary["queue_path"]).read_bytes())
            module.verify_projection(snapshot, canonical, inspection)
            self.assertEqual(canonical_hash(inspection["queue"]), canonical_hash(queue))
            self.assertEqual(inspection["queue"]["jobs"][0]["created_at"], snapshot["state"]["queue_jobs"][0]["created_at"])
            self.assertNotIn("state", summary)
            self.assertNotIn("byte_evidence", summary)
            self.assertNotIn("queue_jobs", summary)
            self.assertEqual("PASS", summary["status"])
            for path in run.rglob("*"):
                if path.is_file():
                    self.assertNotIn(b"SYNTHETIC-NOT-A-CREDENTIAL", path.read_bytes())

    def test_replay_identical_preserves_bytes_and_mtime(self):
        with fixture() as (root, envelope, _, run):
            first = module.compose(root, envelope)
            files = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in run.rglob("*") if p.is_file()}
            self.assertEqual(first, module.compose(root, envelope))
            self.assertEqual(files, {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in files})

    def test_concurrent_identical_composition_has_one_intact_result(self):
        with fixture() as (root, envelope, _, __):
            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = [executor.submit(module.compose, root, copy.deepcopy(envelope)) for _ in range(2)]
                results = [future.result() for future in futures]
            self.assertEqual(results[0], results[1])

    def test_divergent_existing_evidence_is_never_overwritten(self):
        with fixture() as (root, envelope, _, run):
            path = run / "queue-before.json"
            path.write_bytes(b"historic-divergent-evidence")
            with self.assertRaisesRegex(PermissionError, "different evidence"):
                module.compose(root, envelope)
            self.assertEqual(b"historic-divergent-evidence", path.read_bytes())
            self.assertFalse((run / "stopped-operational-state-before-regression.json").exists())

    def test_interrupted_dependency_publish_has_no_partial_final_and_resumes(self):
        with fixture() as (root, envelope, _, run):
            original = module._publish
            def fail_queue(path, payload):
                if path.name == "queue-before.json":
                    raise OSError("injected before final commit")
                original(path, payload)
            with patch.object(module, "_publish", side_effect=fail_queue):
                with self.assertRaises(OSError):
                    module.compose(root, envelope)
            self.assertFalse((run / "stopped-operational-state-before-regression.json").exists())
            self.assertEqual("PASS", module.compose(root, envelope)["status"])
            self.assertEqual([], list(run.rglob(".snapshot-*.tmp")))

    def test_all_six_binding_changes_fail_even_when_state_hash_is_recomputed(self):
        with fixture() as (root, envelope, inspection, _):
            summary = module.compose(root, envelope)
            original = json.loads((root / summary["snapshot_path"]).read_bytes())
            for key in module.BINDINGS:
                with self.subTest(field=key):
                    snapshot = copy.deepcopy(original)
                    snapshot["state"][key] = [] if key.endswith("hash") else False
                    snapshot["state_hash"] = canonical_hash(snapshot["state"])
                    with self.assertRaises(PermissionError):
                        module.verify_projection(snapshot, snapshot["state"], inspection)

    def test_invalid_metadata_types_scope_redaction_and_membership_fail_before_final(self):
        mutations = {
            "wrong_hash": lambda e: e.__setitem__("inspection_hash", "sha256:" + "0" * 64),
            "escaped_request": lambda e: e.__setitem__("request_id", "../escape"),
            "escaped_inspection": lambda e: e.__setitem__("inspection_path", "../inspection.json"),
            "bool_pid": lambda e: e.__setitem__("former_manager_pid", True),
            "wrong_role": lambda e: e.__setitem__("role", "POST_REGRESSION"),
            "early_observation": lambda e: e.__setitem__("observed_at", "2026-09-06T08:00:00Z"),
            "scalar_group": lambda e: e["byte_evidence"].__setitem__("queue_store_files", {}),
            "missing_group_member": lambda e: e["byte_evidence"]["queue_store_files"].pop(),
            "duplicate_source": lambda e: e["byte_evidence"]["queue_store_files"].__setitem__(1, copy.deepcopy(e["byte_evidence"]["queue_store_files"][0])),
            "token_empty_path": lambda e: e["byte_evidence"]["oauth_runtime_token"].__setitem__("path", ""),
            "token_empty_snapshot": lambda e: e["byte_evidence"]["oauth_runtime_token"].__setitem__("snapshot_path", ""),
            "token_bool_size": lambda e: e["byte_evidence"]["oauth_runtime_token"].__setitem__("byte_count", True),
            "token_hash_binding": lambda e: e["byte_evidence"]["oauth_runtime_token"].__setitem__("path_identity_hash", "sha256:" + "0" * 64),
        }
        for name, mutate in mutations.items():
            with self.subTest(case=name), fixture() as (root, envelope, _, run):
                mutate(envelope)
                with self.assertRaises(PermissionError):
                    module.compose(root, envelope)
                self.assertFalse((run / "stopped-operational-state-before-regression.json").exists())

    def test_tampered_copy_and_outside_copy_path_fail_before_final(self):
        for mode in ("bytes", "path"):
            with self.subTest(mode=mode), fixture() as (root, envelope, _, run):
                item = next(item for item in envelope["byte_evidence"]["oauth_proof_files"] if item["present"])
                if mode == "bytes":
                    (root / item["snapshot_path"]).write_bytes(b"tampered")
                else:
                    item["snapshot_path"] = "../external-synthetic-only.json"
                with self.assertRaises(PermissionError):
                    module.compose(root, envelope)
                self.assertFalse((run / "stopped-operational-state-before-regression.json").exists())

    def test_duplicate_json_keys_and_nonfinite_numbers_fail(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.subTest(raw=raw), self.assertRaises(PermissionError):
                module._json(raw)


if __name__ == "__main__":
    unittest.main()
