from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, ValidationError

from hero_engine.oauth_operational_readiness import build_operational_readiness
from hero_engine.oauth_refresh_proof import prove_noninteractive_refresh
from hero_engine.google_api_runtime import GoogleOperationDeadline
from hero_engine.youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def write(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def install_schemas(root: Path) -> None:
    names = [
        "youtube_connection_receipt.schema.json",
        "google_auth_platform_observation.schema.json",
        "oauth_token_mirror_receipt.schema.json",
        "oauth_noninteractive_refresh_receipt.schema.json",
        "youtube_operational_readiness.schema.json",
    ]
    (root / "schemas").mkdir(parents=True)
    for name in names:
        (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())


class FakeCredentials:
    def __init__(self) -> None:
        self.valid = False
        self.granted_scopes = list(INTEGRATION_SCOPES)
        self.scopes = list(INTEGRATION_SCOPES)

    def refresh(self, request: object) -> None:
        self.valid = True

    def to_json(self) -> str:
        return json.dumps({
            "token": "new-access-secret",
            "refresh_token": "refresh-secret",
            "token_uri": "https://oauth2.googleapis.com/token",
            "client_id": "client-id",
            "client_secret": "client-secret",
            "scopes": list(INTEGRATION_SCOPES),
        })


class FakeExecute:
    def execute(self) -> dict:
        return {"items": [{"id": CHANNEL_ID}]}


class FakeChannels:
    def list(self, **kwargs: object) -> FakeExecute:
        return FakeExecute()


class FakeYouTube:
    def channels(self) -> FakeChannels:
        return FakeChannels()


class OAuthRefreshAndReadinessTests(unittest.TestCase):
    def test_refresh_and_identity_probe_share_the_remaining_operation_deadline(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "token.json"
            write(token, {
                "token": "old-access-secret",
                "refresh_token": "refresh-secret",
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": "client-id",
                "client_secret": "client-secret",
                "scopes": list(INTEGRATION_SCOPES),
            })
            observed: dict[str, float] = {}

            class CallingCredentials(FakeCredentials):
                def refresh(self, request: object) -> None:
                    request(method="POST", url="https://oauth.invalid/token", timeout=120)
                    self.valid = True

            def request_factory():
                def request(*args: object, **kwargs: object) -> object:
                    observed["timeout"] = float(kwargs["timeout"])
                    return object()
                return request

            receipt = prove_noninteractive_refresh(
                token,
                root / "output/receipt.json",
                root=root,
                credential_loader=lambda path, scopes: CallingCredentials(),
                request_factory=request_factory,
                youtube_builder=lambda credentials: FakeYouTube(),
                deadline=GoogleOperationDeadline(0.5),
            )
            self.assertEqual("PASS", receipt["status"])
            self.assertGreater(observed["timeout"], 0)
            self.assertLessEqual(observed["timeout"], 0.5)

    def test_noninteractive_refresh_is_atomic_secret_free_and_identity_pinned(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "token.json"
            write(token, {
                "token": "old-access-secret",
                "refresh_token": "refresh-secret",
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": "client-id",
                "client_secret": "client-secret",
                "scopes": list(INTEGRATION_SCOPES),
            })
            receipt_path = root / "output/receipt.json"
            receipt = prove_noninteractive_refresh(
                token,
                receipt_path,
                root=root,
                tested_at="2026-09-04T12:03:00Z",
                credential_loader=lambda path, scopes: FakeCredentials(),
                request_factory=lambda: object(),
                youtube_builder=lambda credentials: FakeYouTube(),
            )
            self.assertEqual("PASS", receipt["status"])
            self.assertTrue(receipt["refresh_success"])
            self.assertTrue(receipt["identity_verified_after_refresh"])
            self.assertEqual(hashlib.sha256(token.read_bytes()).hexdigest(), receipt["token_sha256"])
            serialized = receipt_path.read_text(encoding="utf-8")
            self.assertNotIn("access-secret", serialized)
            self.assertNotIn("refresh-secret", serialized)
            Draft202012Validator(json.loads((root / "schemas/oauth_noninteractive_refresh_receipt.schema.json").read_text())).validate(receipt)

    def test_missing_scope_fails_without_mutating_token(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "token.json"
            write(token, {"refresh_token": "secret", "scopes": list(INTEGRATION_SCOPES[:3])})
            before = token.read_bytes()
            receipt = prove_noninteractive_refresh(token, root / "output/receipt.json", root=root)
            self.assertEqual("FAIL", receipt["status"])
            self.assertEqual("REQUIRED_SCOPE_MISSING", receipt["failure_code"])
            self.assertFalse(receipt["token_persisted"])
            self.assertEqual(before, token.read_bytes())

    def _ready_fixture(self, root: Path, token: Path) -> None:
        base = root / "output/integrations/youtube/heroverse"
        connection = json.loads((ROOT / "output/integrations/youtube/heroverse/connection-receipt.json").read_text(encoding="utf-8"))
        connection["authorization"]["requested_scopes"] = list(INTEGRATION_SCOPES)
        connection["authorization"]["granted_scopes"] = list(INTEGRATION_SCOPES)
        connection["created_at"] = "2026-09-04T12:02:00Z"
        write(base / "connection-receipt.json", connection)

        platform = json.loads((ROOT / "output/integrations/youtube/heroverse/google-auth-platform-observation.json").read_text(encoding="utf-8"))
        platform["audience"].update({"publishing_status": "IN_PRODUCTION", "configuration_complete": True, "publish_action_enabled": False})
        platform["declared_scopes"].update({
            "non_sensitive_count": 1,
            "sensitive_count": 3,
            "restricted_count": 0,
            "runtime_requested_scopes": list(INTEGRATION_SCOPES),
            "configuration_matches_runtime": True,
        })
        platform["verification"].update({
            "currently_required": False,
            "status": "NOT_REQUIRED_EXEMPT",
            "exemption": "PERSONAL_USE",
            "reason": "Console-confirmed personal-use exemption for the single-owner pilot.",
        })
        platform["continuous_operation_ready"] = True
        platform["observed_at"] = "2026-09-04T12:00:00Z"
        write(base / "google-auth-platform-observation.json", platform)

        token_hash = hashlib.sha256(token.read_bytes()).hexdigest()
        mirror = {
            "schema_version": "1.0.0", "receipt_id": "oauth-token-mirror-" + "a" * 20,
            "integration_id": "youtube-heroverse-v1", "status": "MIRRORED",
            "source_class": "OAUTH_LOCAL_SECRET_OUTSIDE_WORKSPACE", "destination_class": "WINDOWS_TASK_SECRET_OUTSIDE_WORKSPACE",
            "source_outside_workspace": True, "destination_outside_workspace": True,
            "source_sha256": "b" * 64, "destination_sha256": "b" * 64, "size_bytes": 500,
            "required_scopes": list(INTEGRATION_SCOPES), "granted_scopes": list(INTEGRATION_SCOPES),
            "refresh_token_present": True, "atomic_replace": True, "secret_logged": False,
            "technical_cost_brl": 0, "mirrored_at": "2026-09-04T12:01:00Z",
        }
        write(base / "oauth-token-mirror-receipt.json", mirror)
        refresh = {
            "schema_version": "1.0.0", "receipt_id": "oauth-refresh-" + "c" * 20,
            "integration_id": "youtube-heroverse-v1", "status": "PASS", "channel_id": CHANNEL_ID,
            "observed_channel_id": CHANNEL_ID, "token_sha256": token_hash,
            "required_scopes": list(INTEGRATION_SCOPES), "granted_scopes": list(INTEGRATION_SCOPES),
            "refresh_success": True, "noninteractive": True, "identity_verified_after_refresh": True,
            "token_persisted": True, "atomic_replace": True, "failure_code": None,
            "secret_logged": False, "technical_cost_brl": 0, "tested_at": "2026-09-04T12:03:00Z",
        }
        write(base / "oauth-noninteractive-refresh-receipt.json", refresh)

    def test_readiness_promotes_only_with_complete_chronological_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "runtime-token.json"
            token.write_text("current-token", encoding="utf-8")
            self._ready_fixture(root, token)
            result = build_operational_readiness(root, token_file=token, observed_at="2026-09-04T12:04:00Z")
            self.assertTrue(result["continuous_operation_ready"])
            self.assertEqual([], result["blockers"])
            self.assertTrue(result["publication_guard"]["upload_permitted"])
            self.assertEqual("active-private-first", result["publication_guard"]["publish_mode"])

    def test_post_mirror_refresh_reproves_identity_without_rewriting_connection_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "runtime-token.json"
            token.write_text("current-token", encoding="utf-8")
            self._ready_fixture(root, token)
            connection_path = root / "output/integrations/youtube/heroverse/connection-receipt.json"
            connection = json.loads(connection_path.read_text())
            connection["created_at"] = "2026-09-04T12:00:30Z"
            write(connection_path, connection)

            result = build_operational_readiness(
                root,
                token_file=token,
                observed_at="2026-09-04T12:04:00Z",
            )
            self.assertTrue(result["continuous_operation_ready"])
            self.assertEqual([], result["blockers"])
            self.assertFalse(
                any(
                    item.startswith("OAUTH_IDENTITY_PROBE_PREDATES_TOKEN_MIRROR")
                    for item in result["blockers"]
                )
            )

    def test_connection_and_refresh_both_predating_mirror_remain_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "runtime-token.json"
            token.write_text("current-token", encoding="utf-8")
            self._ready_fixture(root, token)
            base = root / "output/integrations/youtube/heroverse"
            connection_path = base / "connection-receipt.json"
            connection = json.loads(connection_path.read_text())
            connection["created_at"] = "2026-09-04T12:00:00Z"
            write(connection_path, connection)
            refresh_path = base / "oauth-noninteractive-refresh-receipt.json"
            refresh = json.loads(refresh_path.read_text())
            refresh["tested_at"] = "2026-09-04T12:00:30Z"
            write(refresh_path, refresh)

            result = build_operational_readiness(
                root,
                token_file=token,
                observed_at="2026-09-04T12:04:00Z",
            )
            self.assertFalse(result["continuous_operation_ready"])
            self.assertTrue(
                any(
                    item.startswith("OAUTH_IDENTITY_PROBE_PREDATES_TOKEN_MIRROR")
                    for item in result["blockers"]
                )
            )
            self.assertTrue(
                any(
                    item.startswith("OAUTH_REFRESH_PREDATES_TOKEN_MIRROR")
                    for item in result["blockers"]
                )
            )

    def test_readiness_rejects_stale_consent_and_schema_rejects_impossible_ready(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secret_dir:
            root = Path(workspace)
            install_schemas(root)
            token = Path(secret_dir) / "runtime-token.json"
            token.write_text("current-token", encoding="utf-8")
            self._ready_fixture(root, token)
            platform_path = root / "output/integrations/youtube/heroverse/google-auth-platform-observation.json"
            platform = json.loads(platform_path.read_text())
            platform["observed_at"] = "2026-09-04T12:05:00Z"
            write(platform_path, platform)
            result = build_operational_readiness(root, token_file=token, observed_at="2026-09-04T12:06:00Z")
            self.assertFalse(result["continuous_operation_ready"])
            self.assertTrue(any(item.startswith("OAUTH_TOKEN_PREDATES_PLATFORM_CONFIGURATION") for item in result["blockers"]))

            impossible = copy.deepcopy(result)
            impossible["continuous_operation_ready"] = True
            schema = json.loads((root / "schemas/youtube_operational_readiness.schema.json").read_text())
            with self.assertRaises(ValidationError):
                Draft202012Validator(schema).validate(impossible)

    def test_real_state_uses_post_configuration_refresh_and_is_durable(self) -> None:
        import socket
        import sqlite3
        import subprocess
        from contextlib import ExitStack
        from unittest.mock import patch

        with tempfile.TemporaryDirectory(prefix="readiness-test-") as workspace, \
                tempfile.TemporaryDirectory(prefix="readiness-synthetic-token-") as token_dir, ExitStack() as guards:
            root, external = Path(workspace).resolve(), Path(token_dir).resolve()
            install_schemas(root)
            token = external / "synthetic-runtime-token.txt"
            token.write_text("SYNTHETIC-NOT-AN-OAUTH-CREDENTIAL", encoding="utf-8")
            self._ready_fixture(root, token)
            original_open = Path.open

            def fixture_open(path, *args, **kwargs):
                self.assertTrue(path.resolve().is_relative_to(root) or path.resolve() == token,
                                "readiness attempted to access a real path/credential")
                return original_open(path, *args, **kwargs)

            guards.enter_context(patch.object(Path, "open", fixture_open))
            guards.enter_context(patch.object(sqlite3, "connect", side_effect=AssertionError("readiness SQLite forbidden")))
            guards.enter_context(patch.object(subprocess, "Popen", side_effect=AssertionError("readiness subprocess forbidden")))
            for method in ("connect", "connect_ex"):
                guards.enter_context(patch.object(socket.socket, method, side_effect=AssertionError("readiness network forbidden")))
            result = build_operational_readiness(root, token_file=token, observed_at="2026-09-04T15:00:00Z")
            self.assertTrue(result["token_valid_now"])
            self.assertTrue(result["refresh_token_present"])
            self.assertTrue(result["continuous_operation_ready"])
            self.assertFalse(any("declares zero" in item for item in result["blockers"]))
            self.assertEqual([], result["blockers"])
            self.assertFalse(any(item.startswith("OAUTH_NONINTERACTIVE_REFRESH_UNPROVEN") for item in result["blockers"]))
            self.assertEqual("DURABLE_POLICY_CONFIGURED", result["durability_status"])
            self.assertEqual("SYNTHETIC-NOT-AN-OAUTH-CREDENTIAL", token.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
