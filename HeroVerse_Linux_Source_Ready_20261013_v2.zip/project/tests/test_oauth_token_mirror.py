from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.oauth_token_mirror import mirror_authorized_user_token
from hero_engine.youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]


def token(scopes: list[str]) -> bytes:
    return json.dumps(
        {
            "token": "access-value",
            "refresh_token": "refresh-value",
            "token_uri": "https://oauth2.googleapis.com/token",
            "client_id": "client-value",
            "client_secret": "secret-value",
            "scopes": scopes,
        },
        separators=(",", ":"),
    ).encode("utf-8")


class OAuthTokenMirrorTests(unittest.TestCase):
    def test_four_scope_token_is_mirrored_atomically_without_secret_in_receipt(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            root = base / "workspace"
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/oauth_token_mirror_receipt.schema.json").write_bytes(
                (ROOT / "schemas/oauth_token_mirror_receipt.schema.json").read_bytes()
            )
            source = base / "oauth" / "token.json"
            destination = base / "task" / "token.json"
            receipt_path = root / "output/receipt.json"
            source.parent.mkdir(parents=True)
            source.write_bytes(token(INTEGRATION_SCOPES))

            receipt = mirror_authorized_user_token(
                source,
                destination,
                receipt_path,
                root=root,
                created_at="2026-09-04T13:00:00Z",
            )

            self.assertEqual(source.read_bytes(), destination.read_bytes())
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), receipt["source_sha256"])
            self.assertEqual(receipt["source_sha256"], receipt["destination_sha256"])
            self.assertEqual(0, receipt["technical_cost_brl"])
            persisted = receipt_path.read_text(encoding="utf-8")
            self.assertNotIn("access-value", persisted)
            self.assertNotIn("refresh-value", persisted)
            self.assertNotIn("secret-value", persisted)
            schema = json.loads((root / "schemas/oauth_token_mirror_receipt.schema.json").read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(receipt)

    def test_missing_scope_fails_closed_and_preserves_existing_runtime_token(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            root = base / "workspace"
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/oauth_token_mirror_receipt.schema.json").write_bytes(
                (ROOT / "schemas/oauth_token_mirror_receipt.schema.json").read_bytes()
            )
            source = base / "oauth" / "token.json"
            destination = base / "task" / "token.json"
            receipt_path = root / "output/receipt.json"
            source.parent.mkdir(parents=True)
            destination.parent.mkdir(parents=True)
            source.write_bytes(token(INTEGRATION_SCOPES[:-1]))
            prior = b"previous-authorized-token"
            destination.write_bytes(prior)

            with self.assertRaises(PermissionError):
                mirror_authorized_user_token(source, destination, receipt_path, root=root)

            self.assertEqual(prior, destination.read_bytes())
            self.assertFalse(receipt_path.exists())

    def test_connect_command_exposes_future_safe_mirror_path(self) -> None:
        script = (ROOT / "scripts/connect_youtube.py").read_text(encoding="utf-8")
        self.assertIn("--token-mirror", script)
        self.assertIn("--token-mirror-receipt", script)
        self.assertIn("token_mirror_file", script)

    def test_reconsent_watcher_chains_mirror_refresh_and_readiness(self) -> None:
        script = (ROOT / "scripts/watch_youtube_reconsent.py").read_text(encoding="utf-8")
        self.assertIn("prove_noninteractive_refresh", script)
        self.assertIn("materialize_readiness", script)
        self.assertIn("--refresh-receipt", script)


if __name__ == "__main__":
    unittest.main()
