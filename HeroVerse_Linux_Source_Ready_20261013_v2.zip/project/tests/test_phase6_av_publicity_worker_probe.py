"""Boundary doubles only. These tests never launch or import the actual CV runtime."""
from contextlib import redirect_stdout
from copy import deepcopy
import hashlib
import importlib.machinery
import io
import os
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_publicity_runtime as R
from hero_engine import phase6_av_publicity_worker_probe as W


class WorkerProbeTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="publicity-origin-BOUNDARY-FIXTURE-")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.base = self.root / "base"
        self.site = self.root / ".venv/Lib/site-packages"
        self.namespace = self.root / "output/qa/phase6/diagnostics"
        self.namespace.mkdir(parents=True)
        self.directory = self.namespace / "new-probe"
        self.code = {name: self.root / (name + ".fixture.py")
                     for name in ("worker", "test", "runtime", "supervisor", "support")}
        for path in self.code.values():
            self.write(path, b"# EXPLICIT FIXTURE IDENTITY; NOT EXECUTABLE WORKER EVIDENCE\n")
        self.bindings = []
        for name in R.BASE_FILES:
            path = self.base / name
            self.write(path, b"EXPLICIT_NOT_EXECUTABLE_BASE_FIXTURE")
            self.bindings.append(self.bound(path))
        self.write(self.base / "Lib/example.py", b"# FILE ORIGIN FIXTURE\n")
        self.write(self.base / "DLLs/example.pyd", b"NOT_NATIVE_FIXTURE")
        self.bindings.append(self.bound(self.base / "Lib/example.py"))
        self.bindings.append(self.bound(self.base / "DLLs/example.pyd"))
        self.profile = {"kind": R.PROFILE_KIND, "version": R.VERSION, "project_root": str(self.root),
                        "base_python": str(self.base), "site_packages": str(self.site),
                        "ffmpeg_directory": str(self.root / "ffmpeg"), "authority": deepcopy(R.AUTHORITY),
                        "technical_cost_brl": 0, "population": {"FIXTURE": "NOT_REAL_INVENTORY"},
                        "file_bindings": self.bindings}
        self.profile_path = self.root / "profile.fixture.json"
        self.write(self.profile_path, W._canonical(self.profile))
        self.profile_binding = self.bound(self.profile_path)
        self.runtime = SimpleNamespace(BASE_PYTHON=self.base, BASE_FILES=R.BASE_FILES,
            FILE_CAP=R.FILE_CAP, FFMPEG_DIRECTORY=self.root / "ffmpeg", AUTHORITY=R.AUTHORITY,
            PROFILE_KIND=R.PROFILE_KIND, VERSION=R.VERSION, _Files=R._Files,
            _resident=R._resident, _json=R._json, _root=lambda value: Path(value),
            _population=lambda value: deepcopy(self.profile["population"]))
        self.patches = [patch.multiple(W, ROOT=self.root, MODULE=self.code["worker"], TEST=self.code["test"],
            RUNTIME=self.code["runtime"], RUNTIME_SHA=self.digest(self.code["runtime"]),
            SUPERVISOR=self.code["supervisor"], SUPERVISOR_SHA=self.digest(self.code["supervisor"]),
            AUDIO_SUPPORT=self.code["support"], AUDIO_SUPPORT_SHA=self.digest(self.code["support"]),
            PROFILE_PATH=self.profile_path, PROFILE_SHA=self.digest(self.profile_path),
            PROFILE_SIZE=self.profile_path.stat().st_size), patch.object(W, "_runtime", return_value=self.runtime)]
        for context in self.patches:
            context.start()
            self.addCleanup(context.stop)
        self.arguments = {"profile_binding": self.profile_binding, "expected_worker_sha": self.digest(self.code["worker"]),
                          "expected_test_sha": self.digest(self.code["test"]), "run_directory": self.directory}

    @staticmethod
    def write(path, raw):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    @staticmethod
    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    @classmethod
    def bound(cls, path):
        return {"path": str(path), "sha256": "sha256:" + cls.digest(path), "size_bytes": path.stat().st_size}

    def startup_arguments(self):
        flags = SimpleNamespace(**dict.fromkeys(("isolated", "no_site", "dont_write_bytecode", "ignore_environment", "no_user_site", "safe_path"), 1))
        return {"flags": flags, "path_entries": [str(self.base / "python312.zip"), str(self.base / "DLLs"), str(self.base / "Lib"), str(self.base)],
                "executable": str(self.base / "python.exe"), "prefix": str(self.base), "base_prefix": str(self.base), "loaded": {}}

    def module(self, name, path, cache=None):
        result = ModuleType(name)
        result.__file__ = str(path)
        result.__spec__ = SimpleNamespace(origin=str(path))
        if cache is not None:
            result.__cached__ = str(cache)
        return result

    def test_preflight_has_no_process_effects_or_full_profile_validation(self):
        before = sorted(str(path) for path in self.root.rglob("*"))
        with patch.object(W, "_supervisor", side_effect=AssertionError("NO_PROCESS")):
            result = W.run_probe(self.root, **self.arguments)
        self.assertEqual(result["status"], "PREFLIGHT_ONLY_NO_PROCESS")
        self.assertEqual(before, sorted(str(path) for path in self.root.rglob("*")))
        self.assertEqual(result["request"]["memory_bytes"], 2 * 1024**3)
        self.assertEqual(result["request"]["timeout_seconds"], 300)
        self.assertFalse(any(result["request"]["authority"].values()))

    def test_profile_code_pins_and_commit_type_reject_before_supervisor(self):
        for changes in ({"expected_worker_sha": "0" * 64}, {"expected_test_sha": "0" * 64},
                        {"profile_binding": {**self.profile_binding, "path": str(self.root / "foreign.json")}},
                        {"commit": 1}):
            with self.subTest(changes=changes), patch.object(W, "_supervisor", side_effect=AssertionError("NO_PROCESS")), self.assertRaises(ValueError):
                W.run_probe(self.root, **{**self.arguments, **changes})
        self.assertFalse(self.directory.exists())

    def test_existing_namespace_and_traversal_preserve_files(self):
        self.directory.mkdir()
        keep = self.directory / "keep"
        self.write(keep, b"KEEP_BYTES")
        for path in (self.directory, self.namespace, self.root / "elsewhere", self.namespace / ".." / "escape"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                W.prepare_probe(self.root, **{**self.arguments, "run_directory": path})
        self.assertEqual(keep.read_bytes(), b"KEEP_BYTES")

    def test_startup_requires_actual_flags_base_and_closed_paths(self):
        good = self.startup_arguments()
        observed = W._startup(self.runtime, **good)
        self.assertFalse(observed["site_inserted_at_startup"])
        self.assertEqual(observed["interpreter"], {"version": sys.version,
            "version_info": list(sys.version_info), "implementation": sys.implementation.name,
            "cache_tag": sys.implementation.cache_tag})
        for key in vars(good["flags"]):
            bad = deepcopy(good)
            setattr(bad["flags"], key, 0)
            with self.subTest(flag=key), self.assertRaises(ValueError):
                W._startup(self.runtime, **bad)
        for change in ({"path_entries": [*good["path_entries"], str(self.site)]}, {"executable": str(self.code["worker"])},
                       {"loaded": {"numpy": object()}}, {"loaded": {"site": object()}}, {"path_entries": [""]}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                W._startup(self.runtime, **{**good, **change})

    def test_real_fixture_file_and_cache_origins_are_hashed_once_per_path(self):
        path = self.base / "Lib/example.py"
        cache = self.base / "Lib/__pycache__/example.cpython-312.pyc"
        self.write(cache, b"NOT_EXECUTED_CACHE_FIXTURE")
        profile = deepcopy(self.profile)
        profile["file_bindings"].append(self.bound(cache))
        module = self.module("example", path, cache)
        proof, files = W._origins(self.runtime, profile, modules={"example": module, "alias": module, "sys": sys}, extra_bindings=[])
        self.assertEqual(len(files.items), 2)
        self.assertEqual(len(proof["modules"]), 3)
        self.assertEqual(proof["modules"][-1]["origin_kind"], "INTERPRETER_BUILTIN_OR_FROZEN")

    def test_foreign_file_spec_cache_and_unattributed_modules_block(self):
        path = self.base / "Lib/example.py"
        foreign = self.root / "foreign.py"
        self.write(foreign, b"FOREIGN_FIXTURE")
        wrong_spec = self.module("example", path)
        wrong_spec.__spec__.origin = str(foreign)
        for module in (self.module("foreign", foreign), self.module("example", path, foreign), wrong_spec, ModuleType("unknown_virtual")):
            with self.subTest(module=module), self.assertRaises(ValueError):
                W._origins(self.runtime, self.profile, modules={module.__name__: module}, extra_bindings=[])

    def test_native_fileless_export_requires_exact_object_identity(self):
        virtual = ModuleType("cv2.fixture")
        proof, _ = W._origins(self.runtime, self.profile, modules={"cv2.fixture": virtual}, extra_bindings=[], native_exports=[virtual])
        self.assertEqual(proof["modules"][0]["origin_kind"], "VERIFIED_NATIVE_MODULE_EXPORT_WITHOUT_FILE")
        with self.assertRaises(ValueError):
            W._origins(self.runtime, self.profile, modules={"cv2.fixture": virtual}, extra_bindings=[], native_exports=[ModuleType("cv2.fixture")])

    def test_namespace_requires_profiled_stub_paths_loader_and_native_identity(self):
        directory = self.site / "cv2/Error"
        stub = directory / "__init__.pyi"
        self.write(stub, b"# NAMESPACE STUB FIXTURE, NOT NATIVE\n")
        profile = deepcopy(self.profile)
        profile["population"]["directories"] = [str(directory)]
        profile["file_bindings"].append(self.bound(stub))
        native = ModuleType("cv2.Error")
        def candidate():
            module = ModuleType("cv2.Error")
            module.__path__, module._native = [str(directory)], native
            parent = ModuleType("cv2")
            parent.__path__ = [str(directory.parent)]
            with patch.dict(sys.modules, {"cv2": parent}):
                loader = importlib.machinery.NamespaceLoader("cv2.Error", [str(directory)], lambda *a: None)
            module.__spec__ = SimpleNamespace(name="cv2.Error", origin=None,
                loader=loader,
                submodule_search_locations=[str(directory)])
            return module
        def inspect(module, selected=profile):
            return W._origins(self.runtime, selected, modules={"cv2.Error": module},
                              extra_bindings=[], native_exports=[native])
        proof, files = inspect(candidate())
        row = proof["modules"][0]
        self.assertEqual(row["origin_kind"], "PROFILED_NAMESPACE_WITH_VERIFIED_NATIVE_ATTACHMENT")
        self.assertIsNone(row["file_binding"])
        self.assertEqual(row["support_bindings"], [self.bound(stub)])
        for field, bad in (("__path__", [str(directory), str(self.root)]),
                           ("_native", ModuleType("cv2.Error"))):
            module = candidate()
            setattr(module, field, bad)
            with self.subTest(field=field), self.assertRaises(ValueError): inspect(module)
        for field, bad in (("loader", SimpleNamespace()), ("origin", "foreign"),
                           ("name", "cv2.other"), ("submodule_search_locations", [str(self.root)])):
            module = candidate()
            setattr(module.__spec__, field, bad)
            with self.subTest(field=field), self.assertRaises(ValueError): inspect(module)
        missing = deepcopy(profile)
        missing["population"]["directories"] = []
        with self.assertRaises(ValueError): inspect(candidate(), missing)
        self.write(directory / "__init__.py", b"# FORBIDDEN NEW CODE\n")
        with self.assertRaises(ValueError): inspect(candidate())
        self.write(stub, b"# DRIFTED STUB\n")
        with self.assertRaises(ValueError): files.recheck()

    def test_typing_pseudo_modules_require_exact_profiled_owner_and_exports(self):
        source = self.base / "Lib/typing.py"
        self.write(source, b"# STDLIB OWNER FIXTURE, NEVER EXECUTED\n")
        profile = deepcopy(self.profile)
        profile["file_bindings"].append(self.bound(source))
        owner = self.module("typing", source)
        owner.io, owner.re = (type(name, (), {"__module__": "typing"}) for name in ("io", "re"))
        modules = {"typing": owner, "typing.io": owner.io, "typing.re": owner.re}
        proof, files = W._origins(self.runtime, profile, modules=modules, extra_bindings=[])
        self.assertEqual(len(files.items), 1)
        for row in proof["modules"][1:]:
            self.assertEqual(row["origin_kind"], "PROFILED_STDLIB_EXACT_PSEUDO_MODULE_EXPORT")
            self.assertEqual(row["support_bindings"], [self.bound(source)])
        for changes in ({"typing.io": type("io", (), {"__module__": "typing"})},
                        {"typing": self.module("typing", self.base / "Lib/example.py")},
                        {"typing": None}, {"typing.other": owner.io}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                W._origins(self.runtime, profile, modules={**modules, **changes}, extra_bindings=[])

    def test_native_transitive_exports_cycles_and_unreachable_prefix_are_distinct(self):
        native, utils, nested = [ModuleType(name) for name in ("cv2", "cv2.utils", "cv2.utils.nested")]
        native.__file__ = str(self.base / "DLLs/example.pyd")
        native.utils, utils.nested, nested.back_to_root = utils, nested, native
        native.duplicate = utils
        exports = W._native_module_exports(native)
        self.assertEqual({id(item) for item in exports}, {id(utils), id(nested)})
        self.assertEqual(len(exports), 2)
        proof, _ = W._origins(self.runtime, self.profile,
            modules={"cv2.utils": utils, "cv2.utils.nested": nested}, extra_bindings=[], native_exports=exports)
        self.assertTrue(all(row["origin_kind"] == "VERIFIED_NATIVE_MODULE_EXPORT_WITHOUT_FILE" for row in proof["modules"]))
        with self.assertRaises(ValueError):
            W._origins(self.runtime, self.profile, modules={"cv2.utils.nested": ModuleType("cv2.utils.nested")},
                extra_bindings=[], native_exports=exports)
        wrapper = self.module("filed_wrapper", self.base / "Lib/example.py")
        wrapper.foreign_virtual = ModuleType("cv2.not_a_native_export")
        native.wrapper = wrapper
        self.assertNotIn(wrapper.foreign_virtual, W._native_module_exports(native))

    def test_native_export_graph_has_fixed_capacity_and_rejects_nonmodule_root(self):
        native, first, second = [ModuleType(name) for name in ("native", "first", "second")]
        native.first, first.second = first, second
        with patch.object(W, "NATIVE_EXPORT_LIMIT", 2), self.assertRaises(ValueError):
            W._native_module_exports(native)
        with self.assertRaises(ValueError):
            W._native_module_exports(SimpleNamespace(first=first))

    def test_native_top_level_and_extension_origins_versions_are_distinct(self):
        paths = [self.site / path for path in ("cv2/__init__.py", "cv2/cv2.pyd", "numpy/__init__.py", "numpy/_core/_multiarray_umath.cp312-win_amd64.pyd")]
        for path in paths: self.write(path, b"NOT_IMPORTED_NATIVE_FIXTURE")
        cv2, native, numpy, array = [self.module(str(i), path) for i, path in enumerate(paths)]
        cv2._native, cv2.__version__, numpy.__version__ = native, "5.0.0", "2.5.2"
        with patch.dict(sys.modules, {"numpy._core._multiarray_umath": array}):
            observed, _ = W._native_observation(self.runtime, cv2, numpy)
            self.assertNotEqual(observed["opencv_native_version"], observed["opencv_distribution_version"])
            native.__file__ = str(paths[0])
            with self.assertRaises(ValueError): W._native_observation(self.runtime, cv2, numpy)

    def test_worker_validates_once_before_import_and_never_calls_detector(self):
        prepared = W.prepare_probe(self.root, **self.arguments)
        self.directory.mkdir()
        request_path = self.directory / "request.json"
        self.write(request_path, W._canonical(prepared["request"]))
        order = []
        def validate(*args, **kwargs):
            order.append("VALIDATE_PROFILE")
            return {"status": "FILE_PROFILE_VALIDATED_NOT_ADMITTED", "FIXTURE": True}
        self.runtime.validate_profile = validate
        import builtins
        original_import = builtins.__import__
        def controlled(name, *args, **kwargs):
            if name in ("cv2", "numpy"):
                self.assertEqual(order[0], "VALIDATE_PROFILE")
                order.append("IMPORT_" + name)
                return SimpleNamespace()
            return original_import(name, *args, **kwargs)
        old_path = list(sys.path)
        supervisor = SimpleNamespace(_require_worker_containment=lambda memory: {"FIXTURE": True})
        try:
            with patch.object(W, "_startup", return_value={"FIXTURE": True}), patch.object(W, "_supervisor", return_value=supervisor), \
                    patch.object(W, "_native_observation", return_value=({"FIXTURE": True}, [])), \
                    patch.object(W, "_origins", return_value=({"modules": [], "absent_cache_paths": []}, R._Files())), \
                    patch.object(W, "_recheck"), patch("builtins.__import__", side_effect=controlled), patch.dict(os.environ), redirect_stdout(io.StringIO()) as stdout:
                report = W._worker(request_path, prepared["request_sha256"], self.arguments["expected_worker_sha"], self.arguments["expected_test_sha"])
            self.assertEqual(order, ["VALIDATE_PROFILE", "IMPORT_cv2", "IMPORT_numpy"])
            self.assertEqual(report["profile_validation_calls"], 1)
            self.assertEqual(report["detector_calls"], 0)
            self.assertEqual(R._json(stdout.getvalue())["probe_sha256"], self.digest(self.directory / "probe.json"))
        finally:
            sys.path[:] = old_path

    def test_worker_invalid_request_fails_before_profile_validation_and_import(self):
        prepared = W.prepare_probe(self.root, **self.arguments)
        prepared["request"]["memory_bytes"] = 1
        self.directory.mkdir()
        path = self.directory / "request.json"
        self.write(path, W._canonical(prepared["request"]))
        self.runtime.validate_profile = lambda *args, **kwargs: self.fail("NO_VALIDATION_OR_IMPORT_FOR_INVALID_REQUEST")
        with patch.object(W, "_startup", return_value={"FIXTURE": True}), self.assertRaises(ValueError):
            W._worker(path, self.digest(path), self.arguments["expected_worker_sha"], self.arguments["expected_test_sha"])
        self.assertFalse((self.directory / "probe.json").exists())

    def test_failed_bounded_probe_preserves_request_without_promoting_partial_output(self):
        calls = []
        def bounded(argv, **kwargs):
            calls.append((argv, kwargs))
            return {"status": "TIMED_OUT", "exit_code": None}
        with patch.object(W, "_supervisor", return_value=SimpleNamespace(run_bounded=bounded)):
            report = W.run_probe(self.root, **self.arguments, commit=True)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][0][:4], [str(self.base / "python.exe"), "-I", "-S", "-B"])
        self.assertEqual(report["status"], "PROBE_FAILED_NOT_ADMITTED")
        self.assertIsNone(report["probe_binding"])
        self.assertFalse(any(report["authority"].values()))
        self.assertTrue((self.directory / "request.json").exists())

    def test_final_recheck_rejects_file_or_inventory_drift(self):
        prepared = W.prepare_probe(self.root, **self.arguments)
        self.directory.mkdir()
        request_path = self.directory / "request.json"
        self.write(request_path, W._canonical(prepared["request"]))
        source = self.base / "Lib/example.py"
        files = R._Files()
        files.read(source, cap=R.FILE_CAP, expected=self.bound(source))
        original = source.read_bytes()
        self.write(source, b"ALTERED_FIXTURE")
        with self.assertRaises(ValueError):
            W._recheck(self.runtime, self.profile, files, prepared["request"], request_path, prepared["request_sha256"])
        self.write(source, original)
        files = R._Files()
        with patch.object(self.runtime, "_population", return_value={"FOREIGN": True}), self.assertRaises(ValueError):
            W._recheck(self.runtime, self.profile, files, prepared["request"], request_path, prepared["request_sha256"])

    def test_parent_accepts_only_completed_output_pin_and_profiled_origins(self):
        # This is a supervisor boundary double, never an origin observation.
        for mode in ("valid_fixture", "tampered_output", "foreign_origin", "foreign_support"):
            with self.subTest(mode=mode):
                directory = self.namespace / mode
                def bounded(argv, **kwargs):
                    request_path = directory / "request.json"
                    request = R._json(request_path.read_bytes())
                    file = self.bound(self.base / "Lib/example.py")
                    if mode == "foreign_origin":
                        file = {**file, "path": str(self.root / "NOT_PROFILED_NEVER_READ.py")}
                    support = ([{**file, "path": str(self.root / "UNPROFILED_STUB.pyi")}]
                               if mode == "foreign_support" else [])
                    report = {"version": W.VERSION, "status": "ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION",
                        "request_binding": self.bound(request_path), "profile_binding": self.profile_binding,
                        "code_bindings": request["code_bindings"], "startup": {"FIXTURE_NOT_OBSERVED": True},
                        "inserted_site": str(self.site), "native_observation": {"FIXTURE_NOT_OBSERVED": True},
                        "origins": {"modules": [{"module": "fixture", "file_binding": file, "cache_binding": None, "support_bindings": support}], "absent_cache_paths": []},
                        "file_validation": {"FIXTURE_NOT_REAL_VALIDATION": True}, "containment": {"FIXTURE": True},
                        "module_count": 1, "profile_validation_calls": 1, "elapsed_seconds": 0.001,
                        "authority": deepcopy(W.AUTHORITY), "technical_cost_brl": 0,
                        "detector_calls": 0, "decode_calls": 0, "network_calls": 0, "limitations": list(W.LIMITATIONS)}
                    raw = W._canonical(report)
                    self.write(directory / "probe.json", raw if mode != "tampered_output" else b"TAMPERED")
                    stdout_path = directory / "process/stdout.log"
                    self.write(stdout_path, W._canonical({"probe_sha256": W._sha(raw)}) + b"\n")
                    return {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
                        "assigned_before_resume": True, "kill_on_close": True, "committed_memory_limit_bytes": W.MEMORY_BYTES,
                        "logs": [{"path": str(stdout_path), "sha256": self.digest(stdout_path), "size": stdout_path.stat().st_size}]}
                with patch.object(W, "_supervisor", return_value=SimpleNamespace(run_bounded=bounded)):
                    if mode == "valid_fixture":
                        result = W.run_probe(self.root, **{**self.arguments, "run_directory": directory}, commit=True)
                        self.assertEqual(result["status"], "ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION")
                        self.assertFalse(any(result["authority"].values()))
                    else:
                        with self.assertRaises(ValueError):
                            W.run_probe(self.root, **{**self.arguments, "run_directory": directory}, commit=True)
                        self.assertFalse((directory / "terminal.json").exists())
                    self.assertTrue((directory / "request.json").exists())

    def test_exclusive_equal_collision_and_fsync_failure_preserve_effect_boundary(self):
        self.directory.mkdir()
        path = self.directory / "fixture.json"
        W._exclusive(path, b"SAME")
        with self.assertRaises(ValueError): W._exclusive(path, b"SAME")
        self.assertEqual(path.read_bytes(), b"SAME")
        failed = self.directory / "failed.json"
        with patch.object(os, "fsync", side_effect=PermissionError("FIXTURE")), self.assertRaises(PermissionError):
            W._exclusive(failed, b"NEVER_COMMITTED")
        self.assertFalse(failed.exists())
        self.assertEqual(sorted(item.name for item in self.directory.iterdir()), ["fixture.json"])


if __name__ == "__main__":
    unittest.main()
