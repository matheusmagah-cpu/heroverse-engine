from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from hero_engine.codex_usage_governance import evaluate_usage, materialize_observation, validate_decision


ROOT = Path(__file__).resolve().parents[1]


class CodexUsageGovernanceTests(unittest.TestCase):
    @staticmethod
    def _observation(used: int, *, reached: str | None = None) -> dict:
        return {
            "rateLimitsByLimitId": {
                "codex": {
                    "limitId": "codex", "planType": "pro",
                    "primary": {"usedPercent": used, "windowDurationMins": 10080, "resetsAt": 1789034167},
                    "credits": {"hasCredits": False, "unlimited": False, "balance": "0"},
                    "spendControlReached": False, "rateLimitReachedType": reached,
                }
            },
            "rateLimitResetCredits": {
                "availableCount": 1,
                "credits": [{"expiresAt": 1789944195}],
            },
        }

    @staticmethod
    def _policy() -> dict:
        return json.loads((ROOT / "config/codex-usage-policy.json").read_text(encoding="utf-8"))

    def test_capacity_bands_never_reduce_model_quality(self) -> None:
        cases = [(36, "GREEN", True), (51, "AMBER", True), (80, "RED", False), (95, "CRITICAL_RESERVE", False)]
        for used, expected, heavy_allowed in cases:
            result = evaluate_usage(self._observation(used), self._policy(), observed_at="2026-09-05T12:33:47Z")
            self.assertEqual(expected, result["capacity_decision"]["status"])
            self.assertEqual(heavy_allowed, result["capacity_decision"]["high_consumption_work_allowed"])
            self.assertEqual("BEST_AVAILABLE_SUPPORTED", result["quality_policy"]["model_selection"])
            self.assertEqual("ultra", result["quality_policy"]["reasoning_effort"])
            self.assertFalse(result["quality_policy"]["quality_reduction_allowed"])
            self.assertFalse(result["cost"]["credit_purchase_authorized"])

    def test_live_shape_materializes_schema_valid_immutable_decision(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for relative in (
                "config/codex-usage-policy.json",
                "schemas/codex_usage_governance.schema.json",
            ):
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / relative).read_bytes())
            latest = materialize_observation(
                self._observation(36), root, observed_at="2026-09-05T12:33:47Z",
            )
            value = json.loads(latest.read_text(encoding="utf-8"))
            self.assertEqual(64, value["limits"]["remaining_percent"])
            self.assertEqual("GREEN", value["capacity_decision"]["status"])
            history = list((latest.parent / "history").glob("*.json"))
            self.assertEqual(1, len(history))
            self.assertEqual(latest.read_bytes(), history[0].read_bytes())

    def test_paid_fallback_or_quality_downgrade_is_rejected(self) -> None:
        for key, value in (("purchase_credits", True), ("automatic_top_up", True)):
            policy = self._policy()
            policy["capacity_policy"][key] = value
            with self.assertRaises(ValueError):
                evaluate_usage(self._observation(95), policy, observed_at="2026-09-05T12:33:47Z")
        policy = self._policy()
        policy["quality_policy"]["quality_reduction_allowed"] = True
        with self.assertRaises(ValueError):
            evaluate_usage(self._observation(95), policy, observed_at="2026-09-05T12:33:47Z")

    def test_two_projects_share_one_reserve_without_invented_credit_origin(self) -> None:
        observation = self._observation(98)
        observation["rateLimitsByLimitId"]["codex"]["credits"] = {
            "hasCredits": True, "unlimited": False, "balance": "2500.0000000000",
        }
        result = evaluate_usage(observation, self._policy(), observed_at="2026-09-06T01:46:15Z")
        validate_decision(result)
        self.assertEqual(2, result["limits"]["remaining_percent"])
        self.assertEqual("CRITICAL_RESERVE", result["capacity_decision"]["status"])
        self.assertFalse(result["capacity_decision"]["high_consumption_work_allowed"])
        self.assertEqual(1, result["coordination"]["pool_count"])
        self.assertEqual({"Modelagem Youtube", "QR Dolar"}, {p["name"] for p in result["coordination"]["projects"]})
        self.assertEqual("UNAVAILABLE", result["coordination"]["per_project_usage"])
        self.assertTrue(result["credits"]["has_credits"])
        self.assertNotIn("has_purchased_credits", result["credits"])
        self.assertFalse(result["reset_credits"]["consumed_now"])

    def test_duplicate_project_and_fake_attribution_are_rejected(self) -> None:
        for defect in ("duplicate", "attribution", "double_pool", "unequal"):
            policy = self._policy()
            if defect == "duplicate":
                policy["coordination"]["projects"][1] = policy["coordination"]["projects"][0]
            elif defect == "attribution":
                policy["coordination"]["per_project_usage"] = "50_PERCENT_EACH"
            elif defect == "double_pool":
                policy["coordination"]["pool_count"] = 2
            else:
                policy["coordination"]["projects"][1]["importance"] = "LOW"
            with self.assertRaises(ValueError):
                evaluate_usage(self._observation(98), policy, observed_at="2026-09-06T01:46:15Z")

    def test_historical_v1_decisions_remain_schema_valid(self) -> None:
        result = evaluate_usage(self._observation(36), self._policy(), observed_at="2026-09-05T12:33:47Z")
        result["schema_version"] = "1.0.0"
        result.pop("coordination")
        result["credits"]["has_purchased_credits"] = result["credits"].pop("has_credits")
        validate_decision(result)


if __name__ == "__main__":
    unittest.main()
