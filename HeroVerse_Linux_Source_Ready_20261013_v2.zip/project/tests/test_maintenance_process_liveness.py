from __future__ import annotations

import ctypes
import errno
import inspect
import unittest
from ctypes import wintypes
from unittest.mock import patch

import hero_engine.maintenance_protocol as protocol


class _WindowsProcessApi:
    def __init__(
        self,
        *,
        handle: int = 41,
        exit_code: int = protocol._WINDOWS_STILL_ACTIVE,
        query_ok: bool = True,
        close_ok: bool = True,
    ) -> None:
        self.handle = handle
        self.exit_code = exit_code
        self.query_ok = query_ok
        self.close_ok = close_ok
        self.open_calls: list[tuple[int, bool, int]] = []
        self.query_calls: list[int] = []
        self.close_calls: list[int] = []

    def OpenProcess(self, access: int, inherit: bool, process_id: int) -> int:
        self.open_calls.append((access, inherit, process_id))
        return self.handle

    def GetExitCodeProcess(self, handle: int, output: object) -> int:
        self.query_calls.append(handle)
        if self.query_ok:
            ctypes.cast(output, ctypes.POINTER(wintypes.DWORD)).contents.value = self.exit_code
            return 1
        return 0

    def CloseHandle(self, handle: int) -> int:
        self.close_calls.append(handle)
        return int(self.close_ok)


class MaintenanceProcessLivenessTests(unittest.TestCase):
    def test_windows_live_probe_is_read_only_and_uses_the_exact_pid(self) -> None:
        api = _WindowsProcessApi()

        self.assertTrue(protocol._windows_process_alive(
            18288,
            api=api,
            get_last_error=lambda: 0,
        ))

        self.assertEqual(
            [(protocol._WINDOWS_PROCESS_QUERY_LIMITED_INFORMATION, False, 18288)],
            api.open_calls,
        )
        self.assertEqual([41], api.query_calls)
        self.assertEqual([41], api.close_calls)

    def test_windows_terminated_handle_is_definitively_dead(self) -> None:
        api = _WindowsProcessApi(exit_code=0)
        self.assertFalse(protocol._windows_process_alive(
            18288,
            api=api,
            get_last_error=lambda: 0,
        ))
        self.assertEqual([41], api.close_calls)

    def test_windows_missing_pid_is_definitively_dead(self) -> None:
        api = _WindowsProcessApi(handle=0)
        self.assertFalse(protocol._windows_process_alive(
            999_999_999,
            api=api,
            get_last_error=lambda: protocol._WINDOWS_ERROR_INVALID_PARAMETER,
        ))
        self.assertEqual([], api.query_calls)
        self.assertEqual([], api.close_calls)

    def test_windows_access_denied_is_unavailable_not_dead(self) -> None:
        api = _WindowsProcessApi(handle=0)
        with self.assertRaisesRegex(
            protocol.ProcessLivenessProbeError,
            r"OpenProcess.*winerror=5",
        ):
            protocol._windows_process_alive(
                18288,
                api=api,
                get_last_error=lambda: 5,
            )

    def test_windows_query_error_fails_closed_and_closes_the_handle(self) -> None:
        api = _WindowsProcessApi(query_ok=False)
        with self.assertRaisesRegex(
            protocol.ProcessLivenessProbeError,
            r"GetExitCodeProcess.*winerror=6",
        ):
            protocol._windows_process_alive(
                18288,
                api=api,
                get_last_error=lambda: 6,
            )
        self.assertEqual([41], api.close_calls)

    def test_windows_close_error_is_not_silently_accepted(self) -> None:
        api = _WindowsProcessApi(close_ok=False)
        with self.assertRaisesRegex(
            protocol.ProcessLivenessProbeError,
            r"CloseHandle.*winerror=6",
        ):
            protocol._windows_process_alive(
                18288,
                api=api,
                get_last_error=lambda: 6,
            )

    def test_process_alive_dispatches_to_windows_without_os_kill(self) -> None:
        with (
            patch.object(protocol.os, "name", "nt"),
            patch.object(protocol, "_windows_process_alive", return_value=True) as query,
            patch.object(protocol.os, "kill", side_effect=AssertionError("os.kill called")),
        ):
            self.assertTrue(protocol._process_alive(18288))
        query.assert_called_once_with(18288)

    def test_posix_probe_preserves_esrch_and_eperm_semantics(self) -> None:
        with patch.object(protocol.os, "name", "posix"):
            with patch.object(protocol.os, "kill", side_effect=ProcessLookupError()):
                self.assertFalse(protocol._process_alive(321))
            with patch.object(protocol.os, "kill", side_effect=PermissionError()):
                self.assertTrue(protocol._process_alive(321))
            with patch.object(protocol.os, "kill", side_effect=OSError(errno.EIO, "I/O")):
                with self.assertRaises(protocol.ProcessLivenessProbeError):
                    protocol._process_alive(321)

    def test_migration_guard_never_converts_unavailable_to_stopped(self) -> None:
        with patch.object(
            protocol,
            "_process_alive",
            side_effect=protocol.ProcessLivenessProbeError("probe unavailable"),
        ):
            with self.assertRaisesRegex(PermissionError, "cannot prove former manager"):
                protocol._require_process_stopped(18288, role="former manager")

        with patch.object(protocol, "_process_alive", return_value=True):
            with self.assertRaisesRegex(PermissionError, "requires former manager"):
                protocol._require_process_stopped(18288, role="former manager")

        with patch.object(protocol, "_process_alive", return_value=False):
            protocol._require_process_stopped(18288, role="former manager")

    def test_boundary_distinguishes_dead_from_probe_unavailable(self) -> None:
        with patch.object(protocol, "_process_alive", return_value=False):
            self.assertEqual(
                (False, ["MANAGER_PROCESS_NOT_ALIVE"]),
                protocol._boundary_process_liveness(18288),
            )
        with patch.object(
            protocol,
            "_process_alive",
            side_effect=protocol.ProcessLivenessProbeError("access denied"),
        ):
            self.assertEqual(
                (False, ["MANAGER_PROCESS_LIVENESS_PROBE_UNAVAILABLE"]),
                protocol._boundary_process_liveness(18288),
            )

    def test_both_maintenance_callers_share_the_same_liveness_primitive(self) -> None:
        boundary_source = inspect.getsource(protocol.capture_operational_boundary)
        boundary_probe_source = inspect.getsource(protocol._boundary_process_liveness)
        migration_source = inspect.getsource(protocol.migrate_local_runtime_views)
        self.assertIn("_boundary_process_liveness(manager_pid)", boundary_source)
        self.assertNotIn("os.kill", boundary_source)
        self.assertIn("_process_alive(process_id)", boundary_probe_source)
        self.assertEqual(2, migration_source.count("_require_process_stopped("))
        self.assertNotIn("os.kill", migration_source)


if __name__ == "__main__":
    unittest.main()
