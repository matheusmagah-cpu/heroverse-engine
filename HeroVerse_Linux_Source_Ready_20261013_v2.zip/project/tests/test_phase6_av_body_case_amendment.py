"""V6 metadata chain and adversarial fixtures; no media generation or decode.

Frozen A11 units are fixture metadata, not newly verified PCM. Existing V5 QA
receipts are replayed once; synthetic mutations never overwrite source files.
"""
import copy
from pathlib import Path
import unittest
from unittest import mock

from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError

from hero_engine import phase6_av_body_case_amendment as case
from hero_engine import phase6_av_caption_intent as captions
from hero_engine.phase6_narration_audio_inventory import Reader, _json
from hero_engine.phase6_narration_units import bytes_sha, canonical_sha

ROOT = Path(__file__).absolute().parents[1]
ERRORS = (ValueError, PermissionError, ValidationError, FileNotFoundError)


class BodyCaseAmendmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pins = {path: bytes_sha((ROOT / path).read_bytes()) for path in
            (*case.FIXED_IMPLEMENTATIONS, case.MODULE, case.TEST)}
        reader = Reader(ROOT)
        a11 = case.SOURCE_BINDINGS["a11"]
        cls.a11 = _json(reader.read(a11["path"], "sha256:" + a11["sha256"]))
        cls.units = cls.a11["units"]
        cls.caption = captions.read_caption_intent(reader, captions.PLAN_BINDING, cls.units)
        cls.arguments = dict(amendment_binding=case.AMENDMENT_BINDING, staging_binding=case.STAGING_BINDING)
        cls.projection, cls.amendment, cls.receipt, cls.claim = (
            _json(reader.read(bound["path"], bound["sha256"])) for bound in
            (case.PROJECTION_BINDING, case.AMENDMENT_BINDING, case.STAGING_BINDING, case.CLAIM_BINDING))
        with mock.patch.object(case.prior, "read_amended_visual_intent", wraps=case.prior.read_amended_visual_intent) as old_read, \
             mock.patch.object(case, "_stage_replay", wraps=case._stage_replay) as stage_read, \
             mock.patch.object(case.prior.question, "inspect_question_sources", side_effect=AssertionError("NO SOURCE INSPECTION")), \
             mock.patch.object(case.prior.question, "_png_container", side_effect=AssertionError("NO CRC")), \
             mock.patch("PIL.Image.open", side_effect=AssertionError("NO PNG DECODE")), \
             mock.patch("hero_engine.phase6_narration_audio_inventory.inspect_pcm", side_effect=AssertionError("NO PCM")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("NO INFERENCE/RENDER")), \
             mock.patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")), \
             mock.patch.object(Path, "write_bytes", side_effect=AssertionError("NO WRITES")):
            cls.real = case.read_amended_visual_intent(reader, case.PROJECTION_BINDING, cls.units, cls.caption, **cls.arguments)
            cls.calls = old_read.call_count, stage_read.call_count
        # Reconstruct the thirteen historical staging reads from fixed inputs,
        # not from the receipt's dependency list. No compiler or stage executes.
        cls.historical = case.source._Reader(ROOT)
        for path, digest in case.STAGING_CODE.items():
            cls.historical.read(path, digest)
        for bound in case.SOURCE_BINDINGS.values():
            cls.historical.read(bound["path"], bound["sha256"])
        for bound in (case.CLAIM_BINDING, case.AMENDMENT_BINDING, case.PROJECTION_BINDING):
            cls.historical.read(bound["path"], bound["sha256"][7:])

    @classmethod
    def tearDownClass(cls):
        for path, digest in cls.pins.items():
            if bytes_sha((ROOT / path).read_bytes()) != digest:
                raise AssertionError("adapter or fixed implementation changed during focal")

    def test_real_chain_preserves_v2_v3_v5_and_exact_21_24_79_delta(self):
        result, prior = self.real, self.real["prior_case_inspection"]
        self.assertEqual(self.calls, (1, 1))
        self.assertEqual(prior["adapter_version"], case.prior.VERSION)
        self.assertEqual(result["source_binding"], case.PROJECTION_BINDING)
        self.assertEqual(prior["source_binding"], case.prior.PROJECTION_BINDING)
        self.assertEqual(result["prior_case_inspection_sha256"], canonical_sha(prior))
        for key in ("base_inspection", "base_inspection_sha256", "prior_amendment_inspection", "prior_amendment_inspection_sha256",
                    "amendment_binding", "case_staging_binding", "case_reconciliation_binding", "question_replay_dependencies"):
            self.assertEqual(result[key], prior[key])
        self.assertEqual(result["body_case_amendment_binding"], case.AMENDMENT_BINDING)
        self.assertEqual(result["body_case_staging_binding"], case.STAGING_BINDING)
        self.assertEqual(result["body_case_claim_binding"], case.CLAIM_BINDING)
        self.assertEqual([result[k] for k in ("unit_count", "fragment_count", "state_count", "changed_state_count", "changed_string_count", "unmodified_state_count")], [51, 90, 100, 21, 24, 79])
        changed, strings = [], 0
        for row, old in zip(result["rows"], prior["rows"], strict=True):
            self.assertEqual({k: v for k, v in row.items() if k != "states"}, {k: v for k, v in old.items() if k != "states"})
            for state, before in zip(row["states"], old["states"], strict=True):
                if canonical_sha(state) != canonical_sha(before):
                    changed.append(state["state_id"])
                    strings += sum(a != b for a, b in zip(state["visual_content"]["literal_copy"], before["visual_content"]["literal_copy"], strict=True))
                    restored = copy.deepcopy(state)
                    restored["visual_content"]["literal_copy"] = before["visual_content"]["literal_copy"]
                    self.assertEqual(restored, before)
        self.assertEqual(changed, sorted({item[0] for item in case.EXPECTED_CHANGES}))
        self.assertEqual(strings, 24)
        self.assertEqual(result["effective_rows_sha256"], canonical_sha(result["rows"]))
        self.assertEqual(len(result["implementation_dependencies"]), len(case.FIXED_IMPLEMENTATIONS) + 2)

    def test_all_29_bound_states_hooks_narration_and_26_targets_are_preserved(self):
        result, prior = self.real, self.real["prior_case_inspection"]
        old, current = case._index(prior["rows"]), case._index(result["rows"])
        protected = result["preserved_body_case_constraints"]
        self.assertEqual(len(protected["bound_state_ids"]), 29)
        self.assertEqual(protected["bound_state_ids"], self.a11["literal_asset_use_evidence"]["bound_visual_state_ids"])
        self.assertEqual(len(protected["pending_state_ids"]), 71)
        for sid in protected["bound_state_ids"] + protected["hook_state_ids"]:
            self.assertEqual(current[sid], old[sid])
        for key in ("visual_lexical_ranges", "visual_lexical_unit_ids", "caption_lexical_unit_ids", "temporal_target_unit_ids", "d169_negative_unit_ids"):
            self.assertEqual(result[key], prior[key])
        self.assertEqual(len(result["temporal_target_unit_ids"]), 26)
        self.assertEqual(len(result["d169_negative_unit_ids"]), 25)
        self.assertEqual(current["visual-u038-s02"][1]["entry"], old["visual-u038-s02"][1]["entry"])
        self.assertEqual(current["visual-u020-s01"][1]["entry"]["char_start"], 18)
        self.assertEqual(current["visual-u016-s01"][1]["entry"]["kind"], "CONTINUE_STATE")
        self.assertEqual(result["description_precedence"]["moving_context_still_required_state_ids"], ["visual-u004-s00", "visual-u043-s00"])

    def test_new_adapter_keeps_staged_documents_and_all_authority_false(self):
        self.assertEqual(self.projection["status"], "STAGED_NOT_ACCEPTED_BY_A11")
        self.assertEqual(self.amendment["required_consumer"], "VERSIONED_BODY_CASE_PROPOSAL_READER_NOT_IMPLEMENTED")
        for key in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
            self.assertIs(self.real[key], False)
        self.assertTrue(all(value is False for value in self.real["authority"].values()))
        self.assertEqual(self.real["technical_cost_brl"], 0)
        self.assertIs(type(self.real["technical_cost_brl"]), int)
        for row in self.real["rows"]:
            self.assertEqual(row["source_status"], "SOURCE_PENDING")
            self.assertIs(row["quality_approved"], False)
        schema = _json((ROOT / case.prior.SCHEMA).read_bytes())
        self.assertFalse(Draft202012Validator(schema).is_valid(self.projection))

    def test_wrong_external_v6_amendment_or_stage_never_reaches_prior_reader(self):
        with mock.patch.object(case.prior, "read_amended_visual_intent", side_effect=AssertionError("NO V5 REPLAY")), \
             mock.patch.object(case, "_stage_replay", side_effect=AssertionError("NO STAGE REPLAY")):
            for role in ("projection", "amendment_binding", "staging_binding"):
                for bad in ({}, {"path": "../outside", "sha256": "sha256:" + "0"*64}, case.prior.PROJECTION_BINDING):
                    projection, args = copy.deepcopy(case.PROJECTION_BINDING), copy.deepcopy(self.arguments)
                    if role == "projection": projection = bad
                    else: args[role] = bad
                    with self.subTest(role=role, bad=bad), self.assertRaises(ERRORS):
                        case.read_amended_visual_intent(Reader(ROOT), projection, self.units, self.caption, **args)
        with self.assertRaises(TypeError):
            case.read_amended_visual_intent(Reader(ROOT), case.PROJECTION_BINDING, self.units, self.caption)

    def test_closed_case_map_blocks_words_spacing_punctuation_order_and_extra_strings(self):
        for mutation in ("word", "space", "punctuation", "order", "missing", "extra", "float", "protected"):
            body = copy.deepcopy(self.amendment)
            if mutation == "word": body["changes"][0]["after"] = "Pressure is never the verdict"
            elif mutation == "space": body["changes"][0]["after"] += " "
            elif mutation == "punctuation": body["changes"][0]["after"] += "."
            elif mutation == "order": body["changes"].reverse()
            elif mutation == "missing": body["changes"].pop()
            elif mutation == "extra": body["changes"].append(copy.deepcopy(body["changes"][0]))
            elif mutation == "float": body["changed_state_count"] = 21.0
            else: body["preserved"]["bound_state_ids"][0] = "visual-u032-s00"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                case._apply_case(self.real["prior_case_inspection"], self.projection, body)

    def test_projection_cannot_mutate_timing_hook_protected_identity_or_descriptions(self):
        for mutation in ("narration", "take", "hook", "protected", "time", "lexical", "hold", "description", "reference", "source", "order", "population"):
            projection = copy.deepcopy(self.projection)
            rows = projection["effective_rows"]
            if mutation == "narration": rows[35]["text"] += " changed"
            elif mutation == "take": rows[37]["fragment_ids"] = ["take-060"]
            elif mutation == "hook": rows[0]["states"][0]["visual_content"]["literal_copy"] = ["NEW HOOK"]
            elif mutation == "protected": rows[18]["states"][0]["visual_content"]["literal_copy"] = ["Test changed"]
            elif mutation == "time": rows[37]["states"][2]["start_sample"] = 800
            elif mutation == "lexical": rows[37]["states"][2]["entry"]["char_start"] = 72.0
            elif mutation == "hold": rows[15]["states"][1]["entry"]["kind"] = "UNIT_ENTRY"
            elif mutation == "description": rows[35]["states"][0]["visual_content"]["description"] = "Changed silently"
            elif mutation == "reference": rows[35]["decision_reference"]["selector"] = "/rows/0"
            elif mutation == "source": rows[35]["source_status"] = "READY"
            elif mutation == "order": rows.reverse()
            else: rows[35]["states"].append(copy.deepcopy(rows[35]["states"][0]))
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                case._apply_case(self.real["prior_case_inspection"], projection, self.amendment)

    def test_staging_reconstructs_thirteen_dependencies_not_receipt_assertions(self):
        compiled = dict(amendment=self.amendment, projection=self.projection)
        case._validate_stage_documents(ROOT, None, self.historical, compiled, self.claim, self.receipt)
        self.assertEqual(len(self.historical.bindings), 13)
        for mutation in ("omit", "reverse", "extra", "hash", "size", "authority", "count", "time", "cost", "claim", "scope", "extra_field"):
            receipt, claim = copy.deepcopy(self.receipt), copy.deepcopy(self.claim)
            if mutation == "omit": receipt["dependency_bindings"].pop()
            elif mutation == "reverse": receipt["dependency_bindings"].reverse()
            elif mutation == "extra": receipt["dependency_bindings"].append({"path": "candidate-must-not-read", "sha256": "0"*64, "size_bytes": 1})
            elif mutation == "hash": receipt["dependency_bindings"][0]["sha256"] = "0"*64
            elif mutation == "size": receipt["dependency_bindings"][0]["size_bytes"] += 1
            elif mutation == "authority": receipt["authority"]["source_admission"] = True
            elif mutation == "count": receipt["changed_string_count"] = 24.0
            elif mutation == "time": receipt["staging_duration_seconds"] = float("inf")
            elif mutation == "cost": receipt["technical_cost_brl"] = 0.0
            elif mutation == "claim": claim["started_at"] = "2026-09-08T00:00:00Z"
            elif mutation == "scope": receipt["qa_status"] = "PASS"
            else: receipt["approved_now"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                case._validate_stage_documents(ROOT, None, self.historical, compiled, claim, receipt)

    def test_wrong_unit_pcm_and_caption_fail_before_body_stage_replay(self):
        with mock.patch.object(case, "_stage_replay", side_effect=AssertionError("NO BODY STAGE REPLAY")):
            for mutation in ("text", "pcm", "caption"):
                units, caption = copy.deepcopy(self.units), copy.deepcopy(self.caption)
                if mutation == "text": units[35]["text"] += " changed"
                elif mutation == "pcm": units[35]["pcm_sha256"] = "sha256:" + "0"*64
                else: caption["lexical_unit_ids"] = []
                with self.subTest(mutation=mutation), self.assertRaises(ERRORS):
                    case.read_amended_visual_intent(Reader(ROOT), case.PROJECTION_BINDING, units, caption, **self.arguments)

    def test_dependencies_keep_21mb_ocr_model_in_previous_guard_only(self):
        result = self.real
        self.assertTrue(all(row["size_bytes"] <= 2_000_000 and not Path(row["path"]).is_absolute() for row in result["dependency_bindings"]))
        metadata_paths = {row["path"] for row in result["dependency_bindings"]}
        self.assertTrue({case.CLAIM_BINDING["path"], case.STAGING_BINDING["path"], case.COMPILER, case.SOURCE_BINDINGS["a11"]["path"]} <= metadata_paths)
        models = [row for row in result["question_replay_dependencies"] if row["path"].endswith("PP-OCRv6_rec_small.onnx")]
        self.assertEqual(len(models), 1)
        self.assertEqual(models[0]["size_bytes"], 21234383)
        self.assertFalse(any(".onnx" in path for path in metadata_paths))
        for path, digest in case.FIXED_IMPLEMENTATIONS.items():
            self.assertEqual(next(row["sha256"] for row in result["implementation_dependencies"] if row["path"] == path), "sha256:" + digest)

    def test_late_dependency_drift_blocks_and_never_reexecutes_stager(self):
        original = case.source._Reader.read_path
        def drift(instance, path, *args, **kwargs):
            if Path(path) == ROOT / case.CLAIM_BINDING["path"]:
                raise ValueError("SYNTHETIC LATE CLAIM DRIFT")
            return original(instance, path, *args, **kwargs)
        with mock.patch.object(case.source._Reader, "read_path", new=drift), self.assertRaisesRegex(ValueError, "LATE CLAIM DRIFT"):
            case.recheck_body_case_replay(ROOT, self.real)
        with mock.patch.object(case, "_stage_replay", side_effect=AssertionError("NO RESTAGING")), \
             mock.patch("PIL.Image.open", side_effect=AssertionError("NO DECODE")), \
             mock.patch("subprocess.Popen", side_effect=AssertionError("NO MEDIA")):
            case.recheck_body_case_replay(ROOT, self.real)

    def test_recheck_cannot_gain_authority_or_replace_prior_inspection(self):
        for mutation in ("authority", "ready", "scope", "projection", "stage", "prior", "model", "cost"):
            result = copy.deepcopy(self.real)
            if mutation == "authority": result["authority"]["publication"] = True
            elif mutation == "ready": result["source_ready"] = True
            elif mutation == "scope": result["static_proof_scope"] = "APPROVED"
            elif mutation == "projection": result["source_binding"] = case.prior.PROJECTION_BINDING
            elif mutation == "stage": result["body_case_staging_binding"]["sha256"] = "sha256:" + "0"*64
            elif mutation == "prior": result["prior_case_inspection"]["rows"][0]["text"] += " changed"
            elif mutation == "model": result["question_replay_dependencies"] = []
            else: result["technical_cost_brl"] = 0.0
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                case.recheck_body_case_replay(ROOT, result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
