"""Actual frozen PNGs, hostile replay/input fixtures; no rasterization/effects."""
import copy
from contextlib import ExitStack
import io
import json
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import unittest
from unittest import mock

from PIL import Image

from hero_engine import phase6_av_static_sources as static

ROOT = Path(__file__).absolute().parent.parent
HISTORICAL_PRODUCTION = (
    "output/operations/phase6/release/production-artifact-archives/"
    "phase6-production-inputs-79b3e183dd5df410fb3a"
)


def binding(template_id, root=ROOT):
    item = static.TEMPLATES[template_id]
    return {"path": str(root / item["directory"] / "receipt.json"),
            "sha256": item["receipt_sha256"]}


class StaticSourcesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This is an immutable A11 replay.  Its receipts name the former
        # logical production location; use the archived byte-identical inputs
        # rather than silently treating today's mutable release as history.
        original_read = static._Reader.read

        def read_historical_inputs(reader, relative, expected_sha, *, limit=16 * 1024**2):
            relocation = {
                static.PLAN: HISTORICAL_PRODUCTION + "/take_plan.json",
                static.BIBLE: HISTORICAL_PRODUCTION + "/channel_style_bible.json",
            }.get(relative)
            if relocation is not None and expected_sha == static.INPUT_PINS[relative]:
                return original_read(reader, relocation, expected_sha, limit=limit)
            return original_read(reader, relative, expected_sha, limit=limit)

        cls._archive_patches = [mock.patch.object(static._Reader, "read", read_historical_inputs)]
        for item in cls._archive_patches:
            item.start()
        cls.results = {}
        with ExitStack() as guards:
            for target in ((subprocess, "run"), (subprocess, "Popen"), (socket, "socket"),
                           (Image, "new"), (Image.Image, "save"),
                           (Path, "write_bytes"), (Path, "write_text")):
                guards.enter_context(mock.patch.object(*target, side_effect=AssertionError("read-only inspector")))
            requests = [{"template_id": tid, "state_id": sid, "receipt_binding": binding(tid)}
                        for tid, config in static.TEMPLATES.items() for sid in config["state_ids"]]
            requests.extend([dict(requests[0]), dict(requests[0])])
            with mock.patch.object(static, "_png", wraps=static._png) as pixels:
                values = static.inspect_static_sources(ROOT, requests=requests)
                cls.pixel_decode_calls = pixels.call_count
            cls.batch_values = values
            cls.results = {(value["template_id"], value["state_id"]): value for value in values}

    @classmethod
    def tearDownClass(cls):
        for item in reversed(cls._archive_patches):
            item.stop()

    def fixture_root(self):
        temporary = tempfile.TemporaryDirectory(prefix="heroverse-static-inspector-")
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        files = {entry["path"] for result in self.results.values() for entry in result["dependency_bindings"]}
        for item in sorted(files):
            original = Path(item)
            if str(original) in static.EXTERNAL_DEPENDENCY_PINS:
                continue  # Exact external dependencies; never rewritten.
            target = root / original.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
        # `dependency_bindings` expose the archived physical bytes while the
        # frozen receipt retains the old logical source locations.
        for logical, archived in ((static.PLAN, HISTORICAL_PRODUCTION + "/take_plan.json"),
                                  (static.BIBLE, HISTORICAL_PRODUCTION + "/channel_style_bible.json")):
            source = root / archived
            target = root / logical
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
        return root

    def inspect(self, root=ROOT, template="fear-examples-v1", state="door-0", **kwargs):
        return static.inspect_static_source(root, template_id=template, state_id=state,
            receipt_binding=kwargs.get("receipt_binding", binding(template, root)))

    def test_all_eleven_real_states_are_single_opaque_images_without_source_clock(self):
        self.assertEqual(len(self.results), 11)
        for result in self.results.values():
            self.assertEqual((result["width"], result["height"], result["mode"]), (1920, 1080, "RGB"))
            self.assertEqual(result["opacity"], "OPAQUE")
            self.assertEqual(result["media_kind"], "STATIC_IMAGE")
            self.assertEqual(result["source_frame_count"], 1)
            self.assertEqual((result["source_start_frame"], result["source_end_frame"]), (0, 1))
            self.assertNotIn("fps", result)
            self.assertNotIn("duration", result)
            self.assertIsNone(result["observed_sample"])
            self.assertIsNone(result["video_frame"])
            self.assertTrue(all(value is False for value in result["authority"].values()))
            self.assertFalse(result["source_ready"])
            self.assertEqual(result["technical_cost_brl"], 0)

    def test_eleven_states_remain_two_lineages_not_eleven_variety_sources(self):
        self.assertEqual({x["lineage_id"] for x in self.results.values()}, {
            "owned-fear-example-triptych-v1", "owned-four-criteria-panel-v1"})
        for template, config in static.TEMPLATES.items():
            self.assertEqual({value["lineage_id"] for key, value in self.results.items() if key[0] == template},
                             {config["lineage_id"]})

    def test_batch_decodes_once_per_template_and_duplicate_results_do_not_alias(self):
        # Eleven actual states plus two contact sheets, despite repeated spans.
        self.assertEqual(self.pixel_decode_calls, 13)
        self.assertEqual(len(self.batch_values), 13)
        self.assertEqual(self.batch_values[0], self.batch_values[-1])
        self.assertIsNot(self.batch_values[0], self.batch_values[-1])
        self.assertIsNot(self.batch_values[0]["authority"], self.batch_values[-1]["authority"])

    def test_final_rehash_rejects_source_change_after_successful_pixel_decode(self):
        root = self.fixture_root()
        actual = static._inspect_template
        target = root / static.TEMPLATES["fear-examples-v1"]["directory"] / "reply-1.png"

        def change_after_inspection(*args, **kwargs):
            result = actual(*args, **kwargs)
            target.write_bytes(target.read_bytes() + b"changed-after-decode")
            return result

        with mock.patch.object(static, "_inspect_template", side_effect=change_after_inspection), \
             self.assertRaisesRegex(ValueError, "hash mismatch"):
            self.inspect(root)

    def test_lexical_contracts_are_recomposed_not_timestamps(self):
        targets = []
        for (template, sid), result in self.results.items():
            target = result["lexical_target"]
            if target is None:
                continue
            targets.append(target["text"])
            self.assertEqual(result["literal_narration"][target["char_start"]:target["char_end"]], target["text"])
            self.assertEqual(target["fragment_id"], result["fragment_ids"][0])
            self.assertEqual(result["timing_kind"], "CALIBRATED_LEXICAL_REQUIRED")
        self.assertEqual(targets, ["forgotten", "rejection", "God has left", "truth", "character", "consequences", "wise counsel"])
        thought = self.results[("fear-examples-v1", "morning-1")]["text_lines"]
        self.assertEqual(thought, ["A hard morning", "Fear says: God has left"])

    def test_complete_dependencies_are_recheckable_and_selected_asset_occurs_once(self):
        for result in self.results.values():
            entries = result["dependency_bindings"]
            self.assertEqual(len(entries), len({item["path"] for item in entries}))
            self.assertEqual(entries.count(result["asset_binding"]), 1)
            self.assertIn(str(ROOT / "hero_engine/phase6_av_static_sources.py"), {x["path"] for x in entries})
            for entry in entries:
                self.assertGreater(entry["size_bytes"], 0)
                self.assertEqual(len(entry["sha256"]), 64)

    def test_read_only_replay_is_exact_and_candidate_tampering_rejected(self):
        original = self.results[("fear-examples-v1", "door-0")]
        with mock.patch.object(subprocess, "run", side_effect=AssertionError("no process")), \
             mock.patch.object(Image.Image, "save", side_effect=AssertionError("no raster")):
            self.assertEqual(static.verify_static_source(original, ROOT, template_id="fear-examples-v1",
                state_id="door-0", receipt_binding=binding("fear-examples-v1")), original)
        for key, value in (("source_frame_count", 1.0), ("source_ready", True),
                           ("lineage_id", "fake-independent-source"), ("mode", "RGBA")):
            tampered = copy.deepcopy(original)
            tampered[key] = value
            with self.subTest(key=key), mock.patch.object(static, "inspect_static_source", return_value=original), \
                 self.assertRaisesRegex(ValueError, "replay differs"):
                static.verify_static_source(tampered, ROOT, template_id="fear-examples-v1",
                    state_id="door-0", receipt_binding=binding("fear-examples-v1"))

    def test_unknown_template_state_type_and_external_pin_fail_closed(self):
        for template, state in (("new-generator", "door-0"), ("fear-examples-v1", "state-0"),
                                ("four-criteria-v1", True), (None, "door-0")):
            with self.subTest(template=template, state=state), self.assertRaises(ValueError):
                static.inspect_static_source(ROOT, template_id=template, state_id=state, receipt_binding={})
        for value in ({"path": binding("fear-examples-v1")["path"], "sha256": "0" * 64},
                      {**binding("fear-examples-v1"), "approved": True},
                      {"path": "../receipt.json", "sha256": binding("fear-examples-v1")["sha256"]}):
            with self.subTest(binding=value), self.assertRaises(ValueError):
                self.inspect(receipt_binding=value)

    def test_entire_receipt_and_inventory_mutations_are_rejected(self):
        root = self.fixture_root()
        folder = root / static.TEMPLATES["fear-examples-v1"]["directory"]
        target = folder / "receipt.json"
        original = target.read_bytes()
        variants = [original + b" ", original.replace(b'"artifact_sha256": {', b'"artifact_sha256": {}, "old_inventory": {', 1)]
        for raw in variants:
            target.write_bytes(raw)
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                self.inspect(root)
        target.write_bytes(original)
        extra = folder / "unexpected.txt"
        extra.write_bytes(b"fixture-extra")
        with self.assertRaisesRegex(ValueError, "directory inventory"):
            self.inspect(root)

    def test_unselected_png_mutation_is_not_hidden_by_selected_good_state(self):
        root = self.fixture_root()
        target = root / static.TEMPLATES["fear-examples-v1"]["directory"] / "reply-1.png"
        target.write_bytes(target.read_bytes() + b"changed")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            self.inspect(root)

    def test_runner_source_and_historical_reuse_are_reopened(self):
        root = self.fixture_root()
        names = [static.TEMPLATES["fear-examples-v1"]["runner"], static.PLAN,
                 static.BASE + "fear-examples-design-v1/static-705212615d14f157bf415ab2/door-0.png"]
        for name in names:
            target = root / {
                static.PLAN: HISTORICAL_PRODUCTION + "/take_plan.json",
                static.BIBLE: HISTORICAL_PRODUCTION + "/channel_style_bible.json",
            }.get(name, name)
            original = target.read_bytes()
            target.write_bytes(original + b" ")
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, "hash mismatch"):
                self.inspect(root)
            target.write_bytes(original)

    def test_missing_unselected_source_blocks_without_generation(self):
        root = self.fixture_root()
        target = root / static.TEMPLATES["four-criteria-v1"]["directory"] / "state-4.svg"
        target.rename(target.with_suffix(".missing"))
        with mock.patch.object(Image.Image, "save", side_effect=AssertionError("no regeneration")), \
             self.assertRaisesRegex(ValueError, "directory inventory"):
            self.inspect(root, "four-criteria-v1", "state-0")

    def test_strict_json_rejects_duplicates_nonfinite_and_types(self):
        for raw in (b'{"state":1,"state":2}', b'{"value":NaN}', b'{"value":Infinity}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                static._json(raw)
        with self.assertRaises(ValueError):
            static._same({"state": 1}, {"state": True}, "type differs")
        with self.assertRaises(ValueError):
            static._same({"state": 1}, {"state": 1.0}, "type differs")

    def test_svg_copy_and_topology_rejection_does_not_trust_receipt_label(self):
        result = self.results[("fear-examples-v1", "door-1")]
        raw = Path(result["asset_binding"]["path"]).with_suffix(".svg").read_bytes()
        for bad in (raw.replace(b"Fear says: forgotten", b"You are forgotten"),
                    b'<!DOCTYPE svg [<!ENTITY a "bad">]>' + raw,
                    raw.replace(b"<rect ", b"<image ", 1)):
            with self.subTest(raw=bad[:50]), self.assertRaises(ValueError):
                static._svg(bad, result["text_lines"])

    def test_png_decode_rejects_wrong_size_and_corruption(self):
        raw = Path(self.results[("four-criteria-v1", "state-0")]["asset_binding"]["path"]).read_bytes()
        with self.assertRaisesRegex(ValueError, "dimensions"):
            static._png(raw, [1280, 720])
        with self.assertRaises(Exception):
            static._png(raw[:100], [1920, 1080])

    def test_png_type_animated_and_alpha_guards_are_explicit(self):
        # Metadata/control-flow fixtures; no fabricated visual evidence or raster.
        probe = mock.MagicMock(format="PNG", size=(1920, 1080), n_frames=2, is_animated=True)
        probe.__enter__.return_value = probe
        with mock.patch.object(static.PngImagePlugin, "PngImageFile", return_value=probe), self.assertRaisesRegex(ValueError, "animated"):
            static._png(b"fixture", [1920, 1080])
        probe.n_frames, probe.is_animated = 1, False
        decoded = mock.MagicMock(mode="RGBA", width=1920, height=1080, info={})
        decoded.__enter__.return_value = decoded
        decoded.getchannel.return_value.getextrema.return_value = (255, 255)
        with mock.patch.object(static.PngImagePlugin, "PngImageFile", side_effect=[probe, decoded]):
            self.assertEqual(static._png(b"fixture", [1920, 1080])["mode"], "RGBA")
        decoded.getchannel.return_value.getextrema.return_value = (0, 255)
        with mock.patch.object(static.PngImagePlugin, "PngImageFile", side_effect=[probe, decoded]), self.assertRaisesRegex(ValueError, "transparent"):
            static._png(b"fixture", [1920, 1080])

    def test_hardlinked_input_and_offline_flags_fail_closed(self):
        root = self.fixture_root()
        relative = static.TEMPLATES["four-criteria-v1"]["directory"] + "/state-0.png"
        original = root / relative
        link = root / "hardlink.png"
        import os
        os.link(original, link)
        with self.assertRaisesRegex(ValueError, "linked"):
            static._Reader(root).read(relative, static._sha(original.read_bytes()))
        normal_lstat = Path.lstat

        def offline(path):
            value = normal_lstat(path)
            if path == ROOT:
                return mock.Mock(st_mode=value.st_mode, st_file_attributes=0x1000)
            return value

        with mock.patch.object(Path, "lstat", offline), self.assertRaisesRegex(ValueError, "offline"):
            static._resident(ROOT)


class StaticDecoderPinsTests(unittest.TestCase):
    """New v2 focals; no inheritance/discovery of the historical test class."""

    @classmethod
    def setUpClass(cls):
        with mock.patch.object(subprocess, "run", side_effect=AssertionError("no process")), \
             mock.patch.object(socket, "socket", side_effect=AssertionError("no network")), \
             mock.patch.object(Image.Image, "save", side_effect=AssertionError("no media writes")), \
             mock.patch.object(Image, "open", side_effect=AssertionError("PNG-specific reader required")):
            cls.proof = static.inspect_static_source(ROOT, template_id="fear-examples-v1",
                state_id="door-0", receipt_binding=binding("fear-examples-v1"))

    def test_real_png_uses_exact_project_decoder_and_native_extension_pins(self):
        decoder = self.proof["decoder"]
        self.assertEqual(self.proof["version"], "phase6-av-static-sources-v2")
        self.assertEqual((self.proof["width"], self.proof["height"], self.proof["mode"]), (1920, 1080, "RGB"))
        self.assertEqual(decoder["version"], "12.3.0")
        self.assertEqual(decoder["entrypoint"], "PIL.PngImagePlugin.PngImageFile")
        self.assertEqual(len(decoder["dependencies"]), 19)
        self.assertEqual({Path(item["path"]).name for item in decoder["dependencies"]},
                         {row[0] for row in static.DECODER_MODULE_PINS.values()})
        native = [row for row in decoder["dependencies"] if row["path"].endswith(".pyd")]
        self.assertEqual(len(native), 1)
        self.assertEqual(native[0]["sha256"], "c8c519ec72bf75b2945b4fc4afa854af2fca8b970a403134f9ddda3e164d85e9")
        for row in decoder["dependencies"]:
            self.assertIn(row, self.proof["dependency_bindings"])
            self.assertEqual(static.EXTERNAL_DEPENDENCY_PINS[row["path"]], row["sha256"])

    def test_same_version_python_or_native_byte_drift_fails_before_decode(self):
        read = Path.read_bytes
        for filename in ("Image.py", "PngImagePlugin.py", "_imaging.cp312-win_amd64.pyd"):
            target = static.DECODER_DIRECTORY / filename

            def changed(path):
                raw = read(path)
                return bytes([raw[0] ^ 1]) + raw[1:] if path == target else raw

            with self.subTest(filename=filename), mock.patch.object(Path, "read_bytes", changed), \
                 mock.patch.object(static, "_png", side_effect=AssertionError("no decode after drift")), \
                 self.assertRaisesRegex(ValueError, "hash mismatch"):
                static.inspect_static_source(ROOT, template_id="fear-examples-v1", state_id="door-0",
                    receipt_binding=binding("fear-examples-v1"))

    def test_decoder_version_or_loaded_installation_mismatch_is_not_a_fallback(self):
        with mock.patch.object(static, "PILLOW_VERSION", "12.3.1"), \
             self.assertRaisesRegex(ValueError, "decoder version"):
            static._verify_decoder(static._Reader(ROOT))
        with mock.patch.object(static.PngImagePlugin, "__file__", str(static.FONT)), \
             self.assertRaisesRegex(ValueError, "another installation"):
            static._verify_decoder(static._Reader(ROOT))
        with mock.patch.object(static.Image, "core", object()), \
             self.assertRaisesRegex(ValueError, "native decoder identity"):
            static._verify_decoder(static._Reader(ROOT))

    def test_external_allowlist_is_exact_and_read_only(self):
        self.assertEqual(len(static.EXTERNAL_DEPENDENCY_PINS), 20)
        with self.assertRaises(TypeError):
            static.EXTERNAL_DEPENDENCY_PINS["C:/arbitrary"] = "0" * 64
        proof = copy.deepcopy(self.proof)
        proof["dependency_bindings"].append({"path": "C:/Windows/win.ini", "sha256": "0" * 64, "size_bytes": 1})
        with self.assertRaisesRegex(ValueError, "exact external allowlist"):
            static.recheck_static_dependencies(ROOT, [proof])

    def test_recheck_same_build_dependencies_never_decodes_or_executes(self):
        with mock.patch.object(static, "_png", side_effect=AssertionError("no decode")), \
             mock.patch.object(static.PngImagePlugin, "PngImageFile", side_effect=AssertionError("no decode")), \
             mock.patch.object(subprocess, "run", side_effect=AssertionError("no process")), \
             mock.patch.object(socket, "socket", side_effect=AssertionError("no network")):
            count = static.recheck_static_dependencies(ROOT, [self.proof, self.proof])
        self.assertEqual(count, len(self.proof["dependency_bindings"]))
        self.assertFalse(self.proof["source_ready"])

    def test_recheck_rejects_drift_missing_external_pins_and_conflicting_bindings(self):
        target = static.DECODER_DIRECTORY / "Image.py"
        read = Path.read_bytes

        def changed(path):
            raw = read(path)
            return bytes([raw[0] ^ 1]) + raw[1:] if path == target else raw

        with mock.patch.object(Path, "read_bytes", changed), self.assertRaisesRegex(ValueError, "hash mismatch"):
            static.recheck_static_dependencies(ROOT, [self.proof])
        proof = copy.deepcopy(self.proof)
        proof["dependency_bindings"] = [row for row in proof["dependency_bindings"] if row["path"] != str(target)]
        with self.assertRaisesRegex(ValueError, "dependency pins missing"):
            static.recheck_static_dependencies(ROOT, [proof])
        proof = copy.deepcopy(self.proof)
        next(row for row in proof["dependency_bindings"] if row["path"] == str(target))["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "external dependency pin"):
            static.recheck_static_dependencies(ROOT, [proof])
        with self.assertRaisesRegex(ValueError, "conflicting"):
            static.recheck_static_dependencies(ROOT, [self.proof, proof])

    def test_recheck_rejects_size_bool_empty_and_duplicate_input(self):
        for proofs in ([], [{}]):
            with self.subTest(proofs=proofs), self.assertRaises(ValueError):
                static.recheck_static_dependencies(ROOT, proofs)
        for mutate in (lambda rows: rows.append(dict(rows[0])),
                       lambda rows: rows[0].update(size_bytes=True),
                       lambda rows: rows[0].update(size_bytes=1)):
            proof = copy.deepcopy(self.proof)
            mutate(proof["dependency_bindings"])
            with self.assertRaises(ValueError):
                static.recheck_static_dependencies(ROOT, [proof])


if __name__ == "__main__":
    unittest.main()
