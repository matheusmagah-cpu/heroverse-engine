import copy
import json
import unittest
from pathlib import Path
from tests import test_audio_static_rights as fixtures
from hero_engine.asset_quality_phase5 import admit_audio_static_source, verify_audio_static_asset_admission
from hero_engine.phase6_asset_residency import validate_phase6_rights_evidence


class AudioStaticSourceAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.helper = fixtures.AudioStaticRightsTests('test_native_producer_to_real_rights_reader_held_no_fake_review')
        self.addCleanup(self.helper.doCleanups)
        self.helper.setUp()
        self.root = self.helper.root
        self.base = copy.deepcopy(self.helper.asset)
        self.base.update(uri=self.helper.evidence['raster'],
            rights_evidence_uri=str(self.helper.directory / 'rights-evidence.json'))
        self.asset_path = self.root / 'held-asset.json'
        self.asset_path.write_text(json.dumps(self.base), encoding='utf-8')
        self.destination = self.root / 'source-admission.json'

    def admit(self):
        return admit_audio_static_source(self.root, asset_path=self.asset_path,
            expected_asset_hash=fixtures.sha(self.asset_path), destination=self.destination,
            created_at='2026-10-05T00:00:00Z')

    def test_real_source_admitted_without_final_release_authority(self):
        source = Path(self.base['uri']).read_bytes()
        before = self.asset_path.read_bytes()
        asset = self.admit()
        self.assertTrue(asset['production_eligible'])
        self.assertFalse(asset['render_authorized'])
        self.assertFalse(asset['publication_authorized'])
        self.assertEqual(verify_audio_static_asset_admission(self.root,asset)['status'],'PASS_SOURCE_ALLOCATION_SCOPE')
        self.assertEqual(validate_phase6_rights_evidence(self.root,asset,self.helper.evidence,
            media_path=Path(self.base['uri']))['status'],'PASS')
        self.assertEqual(Path(self.base['uri']).read_bytes(), source)
        self.assertEqual(self.asset_path.read_bytes(), before)

    def test_changed_report_even_rehashed_is_rejected(self):
        asset = self.admit()
        report = json.loads(self.destination.read_bytes())
        report['observation']['minimum_font_size'] = 30
        self.destination.write_text(json.dumps(report), encoding='utf-8')
        asset['static_content_admission']['sha256'] = fixtures.sha(self.destination)
        with self.assertRaises(PermissionError): verify_audio_static_asset_admission(self.root,asset)

    def test_source_and_base_tamper_block(self):
        asset = self.admit()
        self.asset_path.write_bytes(self.asset_path.read_bytes()+b' ')
        with self.assertRaises(PermissionError): verify_audio_static_asset_admission(self.root,asset)

    def test_minted_flags_without_admission_or_collision_block(self):
        asset = copy.deepcopy(self.base)
        asset['production_eligible'] = True
        with self.assertRaises((PermissionError,IsADirectoryError)):
            validate_phase6_rights_evidence(self.root,asset,self.helper.evidence,media_path=Path(self.base['uri']))
        self.admit()
        with self.assertRaises(PermissionError): self.admit()

    def test_admitted_asset_or_scope_mutation_block(self):
        asset = self.admit()
        asset['render_authorized'] = True
        with self.assertRaises(PermissionError): verify_audio_static_asset_admission(self.root,asset)
