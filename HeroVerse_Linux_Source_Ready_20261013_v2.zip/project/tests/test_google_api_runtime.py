from __future__ import annotations

import unittest
from unittest.mock import patch

from hero_engine.google_api_runtime import (
    GoogleOperationDeadline,
    GoogleOperationDeadlineExceeded,
    build_authorized_service,
    execute_google_request,
)


class _Clock:
    def __init__(self) -> None:
        self.value = 0.0

    def __call__(self) -> float:
        return self.value


class _Request:
    def __init__(self, clock: _Clock, *, elapsed: float, response=None) -> None:
        self.clock = clock
        self.elapsed = elapsed
        self.response = response if response is not None else {"items": []}
        self.calls = 0

    def execute(self):
        self.calls += 1
        self.clock.value += self.elapsed
        return self.response


class GoogleApiRuntimeTests(unittest.TestCase):
    def test_operation_deadline_fails_after_a_slow_request_and_pulses_lease(self) -> None:
        clock = _Clock()
        pulses = []
        deadline = GoogleOperationDeadline(
            5, progress=lambda: pulses.append(clock.value), clock=clock,
        )
        request = _Request(clock, elapsed=6)
        with self.assertRaisesRegex(GoogleOperationDeadlineExceeded, "deadline exhausted"):
            execute_google_request(request, deadline=deadline, stage="fixture.list")
        self.assertEqual(1, request.calls)
        self.assertEqual([0.0], pulses)

    def test_shared_deadline_stops_before_a_later_request(self) -> None:
        clock = _Clock()
        deadline = GoogleOperationDeadline(5, clock=clock)
        first = _Request(clock, elapsed=4, response={"page": 1})
        self.assertEqual(
            {"page": 1},
            execute_google_request(first, deadline=deadline, stage="first"),
        )
        clock.value = 5
        second = _Request(clock, elapsed=0)
        with self.assertRaises(GoogleOperationDeadlineExceeded):
            execute_google_request(second, deadline=deadline, stage="second")
        self.assertEqual(0, second.calls)

    def test_lease_progress_time_is_charged_to_the_same_deadline(self) -> None:
        clock = _Clock()

        def slow_progress() -> None:
            clock.value += 6

        deadline = GoogleOperationDeadline(5, progress=slow_progress, clock=clock)
        with self.assertRaises(GoogleOperationDeadlineExceeded):
            deadline.pulse("lease-renewal")

    def test_request_transport_is_bounded_by_subsecond_remaining_budget(self) -> None:
        clock = _Clock()
        deadline = GoogleOperationDeadline(0.25, clock=clock)
        request = _Request(clock, elapsed=0, response={"items": []})
        request.http = type("Transport", (), {"timeout": 30.0})()
        execute_google_request(request, deadline=deadline, stage="bounded")
        self.assertEqual(0.25, request.http.timeout)
        clock.value = 0.20
        self.assertAlmostEqual(0.05, deadline.request_timeout("remaining"), places=6)

    def test_service_uses_explicit_authorized_http_timeout(self) -> None:
        credentials = object()
        transport = object()
        authorized = object()
        service = object()
        with (
            patch("httplib2.Http", return_value=transport) as http,
            patch("google_auth_httplib2.AuthorizedHttp", return_value=authorized) as auth,
            patch("googleapiclient.discovery.build", return_value=service) as build,
        ):
            self.assertIs(
                service,
                build_authorized_service(
                    "youtube", "v3", credentials=credentials,
                    request_timeout_seconds=17,
                ),
            )
        http.assert_called_once_with(timeout=17.0)
        auth.assert_called_once_with(credentials, http=transport)
        build.assert_called_once_with(
            "youtube", "v3", http=authorized, cache_discovery=False,
        )


if __name__ == "__main__":
    unittest.main()
