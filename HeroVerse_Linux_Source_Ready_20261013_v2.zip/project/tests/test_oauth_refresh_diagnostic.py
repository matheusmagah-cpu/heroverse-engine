import json
import unittest
from types import SimpleNamespace

from hero_engine import oauth_refresh_diagnostic as m


class DiagnosticTests(unittest.TestCase):
    def test_structured_code_only_and_no_specific_revocation_claim(self):
        error = ValueError('SECRET', {'error': 'invalid_grant', 'error_description': 'SECRET', 'token': 'SECRET'})
        result = m.classify_failure(error)
        self.assertEqual('invalid_grant', result['oauth_error_code'])
        self.assertFalse(result['revocation_confirmed'])
        self.assertNotIn('SECRET', json.dumps(result))

    def test_unknown_code_or_string_is_redacted(self):
        for error in (ValueError('invalid_grant SECRET'), ValueError({'error': 'SECRET'}),
                      ValueError({'error': ['SECRET']})):
            self.assertIsNone(m.classify_failure(error)['oauth_error_code'])
            self.assertNotIn('SECRET', json.dumps(m.classify_failure(error)))

    def test_conflicting_codes_not_selected(self):
        self.assertIsNone(m.classify_failure(ValueError({'error': 'invalid_grant'},
            {'error': 'server_error'}))['oauth_error_code'])

    def test_exception_text_and_arbitrary_class_name_never_logged(self):
        class SECRET(Exception):
            def __str__(self):
                raise AssertionError('must not stringify')
        self.assertEqual('OTHER_REDACTED', m.classify_failure(SECRET())['exception_category'])

    def test_transport_exact_one_post_timeout_and_no_redirect(self):
        seen, report = [], {'request_attempts': 0}
        def send(**kw):
            seen.append(kw)
            return SimpleNamespace(status=400)
        send_bounded = m.bounded_request(send, report)
        send_bounded(m.ENDPOINT, method='POST', body=b'SECRET', timeout=120)
        self.assertEqual(30, seen[0]['timeout'])
        self.assertFalse(seen[0]['allow_redirects'])
        self.assertEqual(400, report['http_status'])
        self.assertNotIn('SECRET', json.dumps(report))
        with self.assertRaises(m.DiagnosticBoundaryError):
            send_bounded(m.ENDPOINT, method='POST')
        self.assertEqual(1, len(seen))

    def test_wrong_endpoint_method_or_redirect_rejected_before_transport(self):
        def forbidden(**kw): raise AssertionError('network forbidden')
        for url, method, kw in [('https://example.invalid', 'POST', {}),
                (m.ENDPOINT, 'GET', {}), (m.ENDPOINT, 'POST', {'allow_redirects': True})]:
            report = {'request_attempts': 0}
            with self.assertRaises(m.DiagnosticBoundaryError):
                m.bounded_request(forbidden, report)(url, method=method, **kw)
            self.assertEqual(0, report['request_attempts'])

    def test_response_redirect_never_followed(self):
        report = {'request_attempts': 0}
        with self.assertRaises(m.DiagnosticBoundaryError):
            m.bounded_request(lambda **kw: SimpleNamespace(status=302), report)(m.ENDPOINT, method='POST')
        self.assertEqual(302, report['http_status'])

    def test_response_bool_not_accepted_as_status(self):
        report = {'request_attempts': 0}
        with self.assertRaises(m.DiagnosticBoundaryError):
            m.bounded_request(lambda **kw: SimpleNamespace(status=True), report)(m.ENDPOINT, method='POST')
        self.assertIsNone(report['http_status'])

    def test_success_requires_nonempty_string_token_bearer_and_finite_lifetime(self):
        good = dict(access_token='SECRET', expires_in=3600, token_type='Bearer')
        result = m.evaluate_response(SimpleNamespace(status=200, data=json.dumps(good).encode()))
        self.assertEqual('TOKEN_REFRESH_SUCCEEDED_IN_MEMORY_ONLY', result['status'])
        self.assertNotIn('SECRET', json.dumps(result))
        for key, value in [('access_token', ''), ('access_token', None), ('access_token', 42),
                ('expires_in', None), ('expires_in', True), ('expires_in', 0),
                ('expires_in', '3600'), ('expires_in', 100000), ('token_type', 'MAC')]:
            with self.subTest(key=key, value=value):
                with self.assertRaises(m.DiagnosticBoundaryError):
                    m.evaluate_response(SimpleNamespace(status=200, data=json.dumps(good | {key: value}).encode()))

    def test_retryable_first_response_cause_is_preserved_without_retry(self):
        response = SimpleNamespace(status=503, data=b'{"error":"temporarily_unavailable","error_description":"SECRET"}')
        result = m.evaluate_response(response)
        self.assertTrue(result['diagnosis']['provider_retryable'])
        self.assertEqual('temporarily_unavailable', result['diagnosis']['oauth_error_code'])
        self.assertNotIn('SECRET', json.dumps(result))

    def test_nonobject_response_rejected(self):
        with self.assertRaises(m.DiagnosticBoundaryError):
            m.evaluate_response(SimpleNamespace(status=200, data=b'[]'))


if __name__ == '__main__':
    unittest.main()
