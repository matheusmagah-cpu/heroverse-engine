"""A11 schema-only migration counterproofs; no timeline build or media work.

Historical JSON is externally hash-pinned. A11 documents are explicitly
synthetic structural fixtures, not current source/rights/timing evidence.
The real reader/joiner remains responsible for byte and semantic correlation.
"""
import copy
import hashlib
import json
from pathlib import Path
import unittest

from jsonschema import Draft202012Validator


ROOT = Path(__file__).absolute().parents[1]
SCHEMA = "schemas/phase6_av_timeline.schema.json"
OLD_SCHEMA = "output/qa/phase6/diagnostics/test-questions-v1/before-A11-integration/schemas/phase6_av_timeline.schema.json"
OLD_SHA = "8a68d0b80430e637cc1f4b6d76fb3fedb05ed483a59f3fb2a2820c1ab678d866"
TIMELINES = {
    "1.5.0": ("0708475611669eb490509573", "a9f90a8700967c2c98793e1b507f7dd6f22696d9015aa773870b3c0c8a3b1630"),
    "1.6.0": ("05a4cc9cb0cd9f23a99a4130", "582bf6dc3180ceeb8a5921c53e86a01970cd2a009a5ca52bc336233c7ccc6899"),
    "1.7.0": ("9542021baa38804f39705dbf", "faf4251ea0c5162821dc97f911cb5b73d7c49f04ad28dba9a37f6b888d172f76"),
    "1.8.0": ("08c58eb7551e72f958fa3f09", "5105f3a4c09cc632667088b7a8d50cdd49d46006b33af2f98c21fb843f37f6c0"),
    "1.9.0": ("f4be1a123a552503913cf306", "42eaa6f7e1b5b74f62693cbee25df4d6c95831a9e77eae384163b4ca23de488c"),
}
HERE = "output/qa/phase6/diagnostics/test-questions-v1/"


def bound(path, digest):
    return {"path": path, "sha256": "sha256:" + digest}


PROJECTION = bound(HERE + "staged-visual-v5-7fd136fe0bc4557433b24e46.json",
    "7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92")
AMENDMENT = bound(HERE + "question-case-amendment-v2-1e60348b0c51a9116c8177f9.json",
    "b07bca4c9adc736ffe0abdfca49c341c2e114d9fa12cc269f6dc1aed8fbbadbf")
STAGING = bound(HERE + "question-case-amendment-v2-1e60348b0c51a9116c8177f9-receipt.json",
    "3e22ff3998f04596ebbb22d8c0d1d0f69db0d5f8c2c01c5ab06c056cc7579761")
RECONCILIATION = bound(HERE + "reconciliation-f3904b4f063f15c87e2bfd9b/report.json",
    "0ac7a3fbfbf14da0d0bb6bc15993a303fb03510d76cafcddcbf6369620770aff")
NEW_STATES = ["visual-u019-s00", "visual-u020-s00", "visual-u020-s01", "visual-u021-s00"]


def read_pinned(path, digest):
    raw = (ROOT / path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise AssertionError("historical fixture pin differs: " + path)
    return json.loads(raw)


class QuestionCaseTimelineSchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema_raw = (ROOT / SCHEMA).read_bytes()
        cls.test_raw = Path(__file__).read_bytes()
        cls.schema = json.loads(cls.schema_raw)
        cls.old_schema = read_pinned(OLD_SCHEMA, OLD_SHA)
        Draft202012Validator.check_schema(cls.schema)
        cls.validator = Draft202012Validator(cls.schema)
        cls.old_validator = Draft202012Validator(cls.old_schema)
        cls.historical = {
            version: read_pinned("output/operations/phase6/av-admission/timelines/phase6-av-timeline-" + name + ".json", digest)
            for version, (name, digest) in TIMELINES.items()
        }

    @classmethod
    def tearDownClass(cls):
        if (ROOT / SCHEMA).read_bytes() != cls.schema_raw or Path(__file__).read_bytes() != cls.test_raw:
            raise AssertionError("schema/test changed during focal")
        read_pinned(OLD_SCHEMA, OLD_SHA)
        for name, digest in TIMELINES.values():
            read_pinned("output/operations/phase6/av-admission/timelines/phase6-av-timeline-" + name + ".json", digest)

    def fixture(self, *, case=True, uses=True):
        """Structural fixture only; deliberately no execution of source readers."""
        value = copy.deepcopy(self.historical["1.9.0"])
        value["schema_version"] = "1.10.0"
        value["timeline_version"] = "phase6-av-timeline-v11"
        value["implementation_dependencies"].extend(
            bound("fixture-only/A11-dependency-" + str(i) + ".py", hashlib.sha256(str(i).encode()).hexdigest())
            for i in range(6)
        )
        value["question_case_amendment_evidence"] = None
        if not uses:
            value["inputs"]["source_bindings"].pop("literal_asset_uses")
            value["literal_asset_use_evidence"] = None
        if case:
            value["inputs"]["source_bindings"]["question_case_amendment"] = copy.deepcopy(PROJECTION)
            value["question_case_amendment_evidence"] = {
                "projection_binding": copy.deepcopy(PROJECTION),
                "prior_projection_binding": copy.deepcopy(value["visual_amendment_evidence"]["projection_binding"]),
                "inspection_sha256": "sha256:" + "1" * 64,
                "effective_rows_sha256": "sha256:" + "2" * 64,
                "changed_state_count": 2, "changed_string_count": 3, "unmodified_state_count": 98,
                "adapter_version": "phase6-av-question-case-amendment-v1",
                "amendment_binding": copy.deepcopy(AMENDMENT),
                "case_staging_binding": copy.deepcopy(STAGING),
                "case_reconciliation_binding": copy.deepcopy(RECONCILIATION),
                "prior_amendment_inspection_sha256": value["visual_amendment_evidence"]["inspection_sha256"],
                "decision_reference_scope": "HISTORICAL_V2_AND_V3_USE_EXPLICIT_CASE_AMENDMENT_FOR_V5",
                "static_proof_scope": "EXTERNAL_PINNED_STAGING_PIXEL_OCR_INK_REPLAY_NOT_REMEASURED",
                "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
            }
            if uses:
                use = value["literal_asset_use_evidence"]
                use.update(adapter_version="phase6-av-asset-use-binding-v2", source_count=27,
                    use_count=29, unique_png_content_count=26)
                use["effective_rows_sha256"] = value["question_case_amendment_evidence"]["effective_rows_sha256"]
                use["bound_visual_state_ids"] = sorted(use["bound_visual_state_ids"] + NEW_STATES)
                use["remaining_unbound_visual_state_ids"] = [sid for sid in use["remaining_unbound_visual_state_ids"] if sid not in NEW_STATES]
                use["source_binding"] = bound("fixture-only/v3-asset-use-input.json", "3" * 64)
                value["inputs"]["source_bindings"]["literal_asset_uses"] = copy.deepcopy(use["source_binding"])
        return value

    def rejects(self, value):
        self.assertTrue(list(self.validator.iter_errors(value)), "invalid schema fixture was accepted")

    def test_five_historical_versions_remain_valid_and_gain_no_new_case_fields(self):
        for version, document in self.historical.items():
            with self.subTest(version=version):
                self.old_validator.validate(document)
                self.validator.validate(document)
            for mutation in ("field_null", "input"):
                bad = copy.deepcopy(document)
                if mutation == "field_null":
                    bad["question_case_amendment_evidence"] = None
                else:
                    bad["inputs"]["source_bindings"]["question_case_amendment"] = copy.deepcopy(PROJECTION)
                with self.subTest(version=version, mutation=mutation):
                    self.rejects(bad)

    def test_earliest_version_dispatch_fixtures_remain_structurally_compatible(self):
        for minor in range(1, 5):
            value = copy.deepcopy(self.historical["1.5.0"])
            value["schema_version"] = "1." + str(minor) + ".0"
            value["timeline_version"] = "phase6-av-timeline-v" + str(minor + 1)
            assessment = value["temporal_evidence_assessment"]
            for name in ("scope_complete", "scope_basis", "declared_target_unit_ids", "conservative_exclusion_unit_ids", "unknown_scope_unit_ids"):
                assessment.pop(name)
            assessment["holdout_population_scope"] = "CURRENT_RECONCILED_NARRATION_UNITS_EXCLUDING_FULL_TEMPORAL_TARGET_UNION"
            if minor < 4:
                value.pop("static_source_evidence")
                value["implementation_dependencies"] = value["implementation_dependencies"][:3]
            with self.subTest(version=value["schema_version"]):
                # The frozen old validator first proves this is a legacy fixture,
                # not a newly invented path accepted only by the new schema.
                self.old_validator.validate(value)
                self.validator.validate(value)
                value["question_case_amendment_evidence"] = None
                self.rejects(value)

    def test_a11_four_optional_source_combinations_remain_blocked(self):
        for case in (False, True):
            for uses in (False, True):
                value = self.fixture(case=case, uses=uses)
                with self.subTest(case=case, uses=uses):
                    self.validator.validate(value)
                    self.assertTrue(list(self.old_validator.iter_errors(value)))
                    self.assertEqual(len(value["implementation_dependencies"]), 20)
                    self.assertEqual(value["status"], "BLOCKED_INCOMPLETE")
                    self.assertIsNone(value["derived_take_plan"])
                    self.assertFalse(value["temporal_evidence_assessment"]["all_required_evidence_live"])
                    self.assertEqual(len(value["temporal_evidence_assessment"]["temporal_target_unit_ids"]), 26)
                    self.assertEqual(value["static_source_evidence"], self.historical["1.9.0"]["static_source_evidence"])

    def test_case_and_use_adapter_dispatch_cannot_be_crossed_or_backported(self):
        a11 = self.fixture()
        for mutation in ("case_with_v1", "no_case_with_v2", "a10_with_v2", "case_missing_uses_proof", "case_proof_without_source"):
            if mutation == "a10_with_v2":
                bad = copy.deepcopy(self.historical["1.9.0"])
                bad["literal_asset_use_evidence"] = copy.deepcopy(a11["literal_asset_use_evidence"])
            else:
                bad = copy.deepcopy(a11)
                if mutation == "case_with_v1": bad["literal_asset_use_evidence"] = copy.deepcopy(self.historical["1.9.0"]["literal_asset_use_evidence"])
                elif mutation == "no_case_with_v2":
                    bad["inputs"]["source_bindings"].pop("question_case_amendment")
                    bad["question_case_amendment_evidence"] = None
                elif mutation == "case_missing_uses_proof": bad["literal_asset_use_evidence"] = None
                else: bad["inputs"]["source_bindings"].pop("question_case_amendment")
            with self.subTest(mutation=mutation): self.rejects(bad)

    def test_exact_case_pins_prerequisites_and_closed_fields(self):
        value = self.fixture()
        for name in ("visual_amendment", "untimed_visual_intent", "caption_intent"):
            bad = copy.deepcopy(value)
            bad["inputs"]["source_bindings"].pop(name)
            with self.subTest(missing=name): self.rejects(bad)
        for name in ("projection_binding", "prior_projection_binding", "amendment_binding", "case_staging_binding", "case_reconciliation_binding"):
            for component in ("path", "sha256"):
                bad = copy.deepcopy(value)
                bad["question_case_amendment_evidence"][name][component] += "wrong"
                with self.subTest(binding=name, component=component): self.rejects(bad)
        for mutation in ("case_input_pin", "extra_time", "missing_evidence", "new_field", "null_evidence"):
            bad = copy.deepcopy(value)
            if mutation == "case_input_pin": bad["inputs"]["source_bindings"]["question_case_amendment"]["sha256"] = "sha256:" + "0" * 64
            elif mutation == "extra_time": bad["question_case_amendment_evidence"]["start_sample"] = 0
            elif mutation == "missing_evidence": bad.pop("question_case_amendment_evidence")
            elif mutation == "new_field": bad["question_case_amendment_evidence"]["quality_approved"] = True
            else: bad["question_case_amendment_evidence"] = None
            with self.subTest(mutation=mutation): self.rejects(bad)

    def test_counts_and_case_history_cannot_impersonate_the_prior_projection(self):
        value = self.fixture()
        for name in ("changed_state_count", "changed_string_count", "unmodified_state_count"):
            bad = copy.deepcopy(value)
            bad["question_case_amendment_evidence"][name] += 1
            with self.subTest(name=name): self.rejects(bad)
        for mutation in ("prior_projection", "source_count", "use_count", "content_count", "duplicate", "missing", "wrong_state", "remaining_count", "deps"):
            bad = copy.deepcopy(value)
            use = bad["literal_asset_use_evidence"]
            if mutation == "prior_projection": bad["visual_amendment_evidence"]["projection_binding"] = copy.deepcopy(PROJECTION)
            elif mutation == "source_count": use["source_count"] = 29
            elif mutation == "use_count": use["use_count"] = 25
            elif mutation == "content_count": use["unique_png_content_count"] = 27
            elif mutation == "duplicate": use["bound_visual_state_ids"][-1] = use["bound_visual_state_ids"][0]
            elif mutation == "missing": use["bound_visual_state_ids"].pop()
            elif mutation == "wrong_state": use["bound_visual_state_ids"][-1] = "visual-u099-s00"
            elif mutation == "remaining_count": use["remaining_unbound_visual_state_ids"].pop()
            else: bad["implementation_dependencies"].pop()
            with self.subTest(mutation=mutation): self.rejects(bad)

    def test_flags_cost_and_aggregate_gates_never_gain_authority(self):
        value = self.fixture()
        for field in ("source_ready", "global_schedule_created", "calibrated_timing_available"):
            for scope in ("question_case_amendment_evidence", "literal_asset_use_evidence"):
                bad = copy.deepcopy(value)
                bad[scope][field] = True
                with self.subTest(scope=scope, field=field): self.rejects(bad)
        for mutation in ("authority", "cost", "all_live", "missing_blocker", "derived", "status", "scope"):
            bad = copy.deepcopy(value)
            if mutation == "authority": bad["literal_asset_use_evidence"]["authority"]["publication"] = True
            elif mutation == "cost": bad["literal_asset_use_evidence"]["technical_cost_brl"] = 1
            elif mutation == "all_live": bad["temporal_evidence_assessment"]["all_required_evidence_live"] = True
            elif mutation == "missing_blocker": bad["blockers"].remove("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING")
            elif mutation == "derived": bad["derived_take_plan"] = {}
            elif mutation == "status": bad["status"] = "TIMELINE_VALIDATED_NOT_ADMITTED"
            else: bad["question_case_amendment_evidence"]["static_proof_scope"] = "CURRENT_PIXEL_QA_APPROVED"
            with self.subTest(mutation=mutation): self.rejects(bad)


if __name__ == "__main__":
    unittest.main()
