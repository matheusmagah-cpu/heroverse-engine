"""One metadata-only cache replay plus bounded graph/tamper negative fixtures.

No real source inspector/decoder/OCR/render is permitted. Historical proofs
are externally pinned test inputs, not a fabricated approval or a live cache
shortcut. Synthetic Reader maps below exercise omission guards only.
"""
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_body_sources_replay as replay
from hero_engine import phase6_body_asset_rights as rights

ROOT = Path(__file__).absolute().parents[1]
P, BODY = replay.primitives, replay.body


class BodySourceCacheReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        reader = P._Reader(ROOT)
        cls.receipt = replay._document(reader, replay.REGISTRATION)
        cls.request = replay._document(reader, replay.REQUEST)
        cls.claim = replay._document(reader, replay.CLAIM)
        cls.registration = SimpleNamespace(VERSION=cls.receipt["version"])

    def validate_graph(self, receipt=None, claim=None):
        replay._receipt(self.registration, rights, SimpleNamespace(root=ROOT),
            self.receipt if receipt is None else receipt, self.request,
            self.claim if claim is None else claim, self.receipt["source_proofs"],
            self.receipt["rights_proofs"], self.receipt["source_replay_execution"])

    def fixture_reader(self):
        """EXPLICIT SYNTHETIC map, never used as positive source replay evidence."""
        reader = P._Reader(ROOT)
        for relative, digest in {**replay.CODE_PINS, **replay.NOTE_PINS,
                **{item["path"]: item["sha256"] for item in (replay.REGISTRATION, replay.REQUEST, replay.CLAIM)}}.items():
            reader.read(relative, digest, limit=replay.LIMIT)
        for relative in (replay.IMPLEMENTATION, replay.TEST):
            path = ROOT / relative
            reader.read(relative, P._sha(path.read_bytes()), limit=replay.LIMIT)
        # Deliberately bypass media reads in a test-only data fixture. A real
        # replay may populate this set only from freshly rebuilt Reader sinks.
        for proof in self.receipt["rights_proofs"]:
            BODY._merge(reader.bindings, copy.deepcopy(proof["dependency_bindings"]))
        return reader

    def test_real_exact_replay_once_has_zero_current_media_calls(self):
        with patch.object(BODY, "inspect_body_sources", side_effect=AssertionError("NO SOURCE INSPECTOR")), \
             patch.object(BODY, "inspect_body_source", side_effect=AssertionError("NO SOURCE INSPECTOR")), \
             patch.object(BODY, "verify_body_source", side_effect=AssertionError("NO SOURCE VERIFIER")), \
             patch.object(rights, "inspect_body_asset_rights_batch", side_effect=AssertionError("NO NEW RIGHTS BATCH")), \
             patch.object(rights, "inspect_body_asset_rights", side_effect=AssertionError("NO NEW RIGHTS INSPECTION")), \
             patch("PIL.Image.open", side_effect=AssertionError("NO PNG DECODE")), \
             patch("subprocess.Popen", side_effect=AssertionError("NO OCR/RENDER")), \
             patch("socket.create_connection", side_effect=AssertionError("NO NETWORK")), \
             patch("os.link", side_effect=AssertionError("NO PUBLICATION")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("NO FILE WRITES")), \
             patch.object(Path, "mkdir", side_effect=AssertionError("NO NEW NAMESPACE")):
            result = replay.replay(ROOT)
        self.assertEqual(result["status"], "EXACT_CACHE_REPLAY")
        self.assertEqual([result[key] for key in ("image_decode_calls", "ocr_inference_calls", "render_calls", "rights_decisions_created", "technical_cost_brl")], [0, 0, 0, 0, 0])
        self.assertEqual(result["historical_source_replay_execution"], self.receipt["source_replay_execution"])
        self.assertEqual(result["historical_source_replay_execution"]["image_decode_calls"], 11)
        self.assertEqual(P._canonical(result["sources"]), P._canonical(self.receipt["source_proofs"]))
        self.assertEqual(P._canonical(result["rights"]), P._canonical(self.receipt["rights_proofs"]))
        self.assertEqual(result["registry"], self.request["states"])
        self.assertEqual(len(result["sources"]), 12)
        self.assertEqual(len({row["content_sha256"] for row in result["sources"]}), 11)
        self.assertEqual(len({row["lineage_id"] for row in result["sources"]}), 1)
        self.assertEqual(result["authority"], BODY.AUTHORITY)
        self.assertFalse(result["source_ready"])
        self.assertFalse(result["global_schedule_created"])
        self.assertFalse(result["calibrated_timing_available"])
        self.assertEqual(len(result["dependency_bindings"]), len({row["path"] for row in result["dependency_bindings"]}))
        payload = {key: value for key, value in result.items() if key != "inspection_id"}
        self.assertEqual(result["inspection_id"], "body-sources-exact-cache-" + P._sha(P._canonical(payload))[:24])

    def test_anchored_graph_and_source_rights_dual_hashes(self):
        self.validate_graph()
        for source, proof in zip(self.receipt["source_proofs"], self.receipt["rights_proofs"], strict=True):
            self.assertEqual(proof["source_proof"], {"inspection_id": source["inspection_id"],
                "sha256": P._sha(P._canonical(source)), "timeline_canonical_sha256": rights.canonical_sha(source)})
            self.assertEqual(proof["artifacts"]["png_binding"], source["asset_binding"])
            self.assertEqual([source[key] for key in ("source_frame_count", "source_start_frame", "source_end_frame")], [1, 0, 1])
            self.assertIsNone(source["observed_sample"])
            self.assertIsNone(source["video_frame"])
        lexical = [row for row in self.receipt["source_proofs"] if row["lexical_target"]]
        self.assertEqual(len(lexical), 3)
        self.assertEqual(lexical[-1]["lexical_target"]["fragment_ids"], ["take-059", "take-060"])
        self.assertEqual([lexical[-1]["entry"][key] for key in ("char_start", "char_end", "text")], [72, 98, "stories only exhausted you"])

    def test_cached_source_authority_copy_alias_dependencies_and_clock_mutations_fail(self):
        for mutation in ("copy", "authority", "alias", "dependency", "float", "time", "identity"):
            changed = copy.deepcopy(self.receipt)
            source = changed["source_proofs"][0]
            if mutation == "copy": source["literal_copy"] = ["Invented approval"]
            elif mutation == "authority": source["authority"]["publication_authorized"] = True
            elif mutation == "alias": source["equivalent_state_ids"] += ["visual-u001-s00"]
            elif mutation == "dependency": source["dependency_bindings"].pop()
            elif mutation == "float": source["source_frame_count"] = 1.0
            elif mutation == "time": source["observed_sample"] = 100
            else: source["inspection_id"] = "self-approved"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.validate_graph(receipt=changed)

    def test_rights_source_association_missing_state_decision_and_extra_fields_fail(self):
        for mutation in ("proof_pin", "decision", "count", "state", "scope", "extra"):
            changed = copy.deepcopy(self.receipt)
            proof = changed["rights_proofs"][0]
            if mutation == "proof_pin": proof["source_proof"]["timeline_canonical_sha256"] = "sha256:" + "0" * 64
            elif mutation == "decision": proof["decision_binding"] = changed["rights_proofs"][1]["decision_binding"]
            elif mutation == "count": changed["rights_proofs"].pop()
            elif mutation == "state": proof["state_id"] = "visual-u001-s00"
            elif mutation == "scope": proof["scope"] = "SOURCE_ADMITTED"
            else: changed["extra_approval"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.validate_graph(receipt=changed)

    def test_historical_execution_and_claim_cannot_be_relabelled_as_current(self):
        for mutation in ("decodes", "ocr", "template", "float", "claim", "elapsed", "future"):
            changed, claim = copy.deepcopy(self.receipt), copy.deepcopy(self.claim)
            if mutation == "decodes": changed["source_replay_execution"]["image_decode_calls"] = 0
            elif mutation == "ocr": changed["source_replay_execution"]["ocr_inference_calls"] = 1
            elif mutation == "template": changed["source_replay_execution"]["templates"].reverse()
            elif mutation == "float": changed["state_count"] = 12.0
            elif mutation == "claim": claim["request_sha256"] = "0" * 64
            elif mutation == "elapsed": changed["duration_seconds"] = True
            else: changed["created_at"] = "2099-01-01T00:00:00Z"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.validate_graph(receipt=changed, claim=claim)

    def test_external_code_or_anchor_bytes_fail_before_cached_module_execution(self):
        actual = Path.read_bytes
        for relative in (replay.REGISTRAR, replay.REGISTRATION["path"], replay.REQUEST["path"], replay.CLAIM["path"]):
            target = ROOT / relative
            def changed(path):
                raw = actual(path)
                return raw[:-1] + bytes([raw[-1] ^ 1]) if path == target else raw
            with self.subTest(relative=relative), patch.object(Path, "read_bytes", changed), \
                 patch.object(replay.importlib.util, "spec_from_file_location", side_effect=AssertionError("NO UNPINNED MODULE")):
                with self.assertRaisesRegex(ValueError, "hash mismatch"):
                    replay._load(P._Reader(ROOT))

    def test_recheck_accepts_internal_superset_but_not_missing_anchors_notes_or_model(self):
        reader = self.fixture_reader()
        # A real extra code file, not another source proof or candidate cache.
        reader.read("hero_engine/phase6_av_static_uses_v2_replay.py", "68221c67b940ee2a8d65fda3d30d5d2756bb5561c6d0cda5d7bd3b40745e5144")
        with patch.object(BODY, "_read_dependency") as bounded_read:
            replay.recheck(reader)
        self.assertEqual(bounded_read.call_count, len(reader.bindings))
        for relative in (replay.REGISTRATION["path"], replay.CLAIM["path"], next(iter(replay.NOTE_PINS)),
                ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_rec_small.onnx"):
            altered = P._Reader(ROOT)
            altered.bindings = copy.deepcopy(reader.bindings)
            del altered.bindings[str(ROOT / relative)]
            with self.subTest(relative=relative), patch.object(BODY, "_read_dependency"):
                with self.assertRaisesRegex(ValueError, "mandatory"):
                    replay.recheck(altered)

    def test_inventory_extra_partial_and_final_dependency_drift_fail_closed(self):
        reader = self.fixture_reader()
        actual = Path.iterdir
        for relative in (replay.BASE, replay.DIRECTORY):
            target = ROOT / relative
            def extra(path):
                values = list(actual(path))
                return iter([*values, path / ".new-INCOMPLETE.json"] if path == target else values)
            with self.subTest(relative=relative), patch.object(Path, "iterdir", extra), patch.object(BODY, "_read_dependency"):
                with self.assertRaisesRegex(ValueError, "inventory drift"):
                    replay.recheck(reader)
        with patch.object(BODY, "_read_dependency", side_effect=ValueError("EXPLICIT FINAL MODEL/BYTE DRIFT")):
            with self.assertRaisesRegex(ValueError, "FINAL MODEL/BYTE DRIFT"):
                replay.recheck(reader)
        with self.assertRaisesRegex(ValueError, "actual same-call Reader"):
            replay.recheck({"status": "PASS", "dependency_bindings": []})


if __name__ == "__main__":
    unittest.main()
