"""One real read-only replay; adversarial mutations are in-memory FIXTURE only."""
from __future__ import annotations

import builtins
import copy
import hashlib
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_clean_plate as plate


def caller_binding():
    return {"path": plate.RECEIPT, "sha256": "sha256:" + plate.RECEIPT_SHA,
            "size_bytes": plate.RECEIPT_SIZE}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


class CleanPlateVerificationTests(unittest.TestCase):
    def test_real_receipt_replays_with_native_processes_and_writes_forbidden(self):
        original_open, original_io_open, original_os_open = builtins.open, io.open, os.open
        def read_only_open(original):
            def opened(file, mode="r", *args, **kwargs):
                if isinstance(mode, str) and any(flag in mode for flag in "wax+"):
                    raise AssertionError("write attempted during real read-only replay")
                return original(file, mode, *args, **kwargs)
            return opened
        def os_read_only(path, flags, *args, **kwargs):
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
                raise AssertionError("os write attempted during real read-only replay")
            return original_os_open(path, flags, *args, **kwargs)
        with patch("subprocess.Popen", side_effect=AssertionError("native effect forbidden")) as popen, \
                patch("builtins.open", side_effect=read_only_open(original_open)), \
                patch("io.open", side_effect=read_only_open(original_io_open)), \
                patch("os.open", side_effect=os_read_only), \
                patch("os.mkdir", side_effect=AssertionError("mkdir forbidden")), \
                patch("os.unlink", side_effect=AssertionError("unlink forbidden")), \
                patch("os.replace", side_effect=AssertionError("replace forbidden")):
            result = plate.verify_clean_plate(plate.ROOT, caller_binding())
        popen.assert_not_called()
        self.assertEqual(set(result), {"verifier_version", "status", "channel_id", "style_bible_id",
            "receipt_binding", "asset_binding", "lineage_id", "capacity", "source_take_plan_binding",
            "dependency_bindings", "dependency_roles", "authority", "technical_cost_brl"})
        self.assertEqual(result["status"], plate.STATUS)
        self.assertEqual(result["capacity"], plate.CAPACITY)
        self.assertEqual(result["asset_binding"], {"path": plate.FOLDER + "/clean-plate.mkv",
            "sha256": "sha256:" + plate.ASSET_SHA, "size_bytes": plate.ASSET_SIZE})
        self.assertEqual(result["channel_id"], "UCuMF6pJQkyMzaVoAxFL86yA")
        self.assertEqual(result["lineage_id"], plate.LINEAGE)
        self.assertEqual(result["authority"], plate.AUTHORITY)
        self.assertTrue(all(value is False for value in result["authority"].values()))
        self.assertEqual(result["technical_cost_brl"], 0)
        self.assertEqual(len(result["dependency_bindings"]), len(result["dependency_roles"]))
        self.assertEqual(len(result["dependency_roles"]), 25)
        for pin, role in zip(result["dependency_bindings"], result["dependency_roles"]):
            self.assertEqual(set(pin), {"path", "sha256", "size_bytes"})
            self.assertEqual({key: role[key] for key in ("path", "sha256")},
                             {key: pin[key] for key in ("path", "sha256")})
            if Path(pin["path"]).is_absolute():
                self.assertIn(pin["path"], plate._EXTERNAL)
        roles = {row["role"] for row in result["dependency_roles"]}
        self.assertTrue({"clean_plate_verifier", "resident_source_helpers", "render_terminal",
            "probe_stdout", "framehash_stdout", "clean_plate_recipe", "clean_plate_receipt"} <= roles)

    def test_receipt_hash_size_field_path_and_workspace_fail_before_loading_code(self):
        cases = [dict(caller_binding(), sha256="0" * 64),
            dict(caller_binding(), size_bytes=plate.RECEIPT_SIZE + 1),
            dict(caller_binding(), size_bytes=True),
            dict(caller_binding(), path=plate.RUNNER),
            dict(caller_binding(), path="../outside.json"),
            dict(caller_binding(), extra=True)]
        with patch.object(plate, "_load_bytes", side_effect=AssertionError("must reject before load")):
            for item in cases:
                with self.subTest(item=item), self.assertRaises(ValueError):
                    plate.verify_clean_plate(plate.ROOT, item)
            with self.assertRaises(ValueError):
                plate.verify_clean_plate(plate.ROOT.parent, caller_binding())

    def test_runner_hash_and_residency_reject_before_exec_of_code(self):
        # FIXTURE read metadata only; the actual runner is never changed.
        original = plate._resident_binding
        def altered(path):
            value = original(path)
            if Path(path) == plate.ROOT / plate.RUNNER:
                value["sha256"] = "sha256:" + "0" * 64
            return value
        with patch.object(plate, "_resident_binding", side_effect=altered), \
                patch("builtins.exec", side_effect=AssertionError("must not execute unpinned bytes")):
            with self.assertRaises(plate.CleanPlateError):
                plate._load_bytes(plate.ROOT, plate.RUNNER, plate.RUNNER_SHA, "fixture_unreachable")
        with patch.object(plate, "_resident_binding", side_effect=ValueError("FIXTURE nonresident")):
            with self.assertRaises(ValueError):
                plate._open(plate.ROOT, plate.RUNNER, plate.RUNNER, plate.RUNNER_SHA)

    def test_code_loader_executes_verified_bytes_not_a_second_read_or_pyc(self):
        # Explicit synthetic executable FIXTURE, not a LIVE receipt verification.
        raw = b"marker = 'approved fixture bytes'\n"
        pin = {"path": "fixture.py", "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}
        with patch.object(plate, "_open", return_value=(pin, raw)):
            module, observed = plate._load_bytes(plate.ROOT, "fixture.py", pin["sha256"], "fixture_module")
        self.assertEqual(module.marker, "approved fixture bytes")
        self.assertEqual(observed, pin)

    def test_asset_hash_size_path_and_external_alias_are_rejected(self):
        for path, expected, digest, size in [
            (plate.FOLDER + "/clean-plate.mkv", plate.FOLDER + "/clean-plate.mkv", "0" * 64, plate.ASSET_SIZE),
            (plate.FOLDER + "/clean-plate.mkv", plate.FOLDER + "/clean-plate.mkv", plate.ASSET_SHA, plate.ASSET_SIZE + 1),
            (plate.RECEIPT, plate.FOLDER + "/clean-plate.mkv", plate.ASSET_SHA, plate.ASSET_SIZE),
            ("C:/ffmpeg/bin/other.exe", "C:/ffmpeg/bin/other.exe", plate.ASSET_SHA, 1)]:
            with self.subTest(path=path, digest=digest, size=size), self.assertRaises(ValueError):
                plate._open(plate.ROOT, path, expected, digest, size)

    def test_changed_bytes_between_metadata_and_read_are_rejected(self):
        original_read = Path.read_bytes
        target = plate.ROOT / plate.RECEIPT
        calls = 0
        def read(path):
            nonlocal calls
            raw = original_read(path)
            if path == target:
                calls += 1
                if calls == 2:
                    return raw + b" "  # In-memory FIXTURE; no source modification.
            return raw
        with patch.object(Path, "read_bytes", read), self.assertRaises(plate.CleanPlateError):
            plate._open(plate.ROOT, plate.RECEIPT, plate.RECEIPT, plate.RECEIPT_SHA, plate.RECEIPT_SIZE)

    def test_recomposed_lineage_capacity_authority_and_asset_cannot_replace_receipt(self):
        receipt = json.loads((plate.ROOT / plate.RECEIPT).read_bytes())
        contract = json.loads((plate.ROOT / plate.FOLDER / "recipe.json").read_bytes())["contract"]
        h = SimpleNamespace(canonical=canonical)
        mutations = [("lineage_id", "fake-variety"), ("capacity_frame_count", 1801),
            ("capacity_frame_count", 1800.0), ("evidence_mode", "FIXTURE"),
            ("technical_cost_brl", False), ("narrative_timing_approved", True),
            ("asset", {**receipt["asset"], "sha256": "sha256:" + "0" * 64}),
            ("authority", {**receipt["authority"], "render_authorized": True})]
        for key, value in mutations:
            result = copy.deepcopy(receipt)
            result[key] = value
            with self.subTest(field=key), self.assertRaises(plate.CleanPlateError):
                plate._checked_result(h, result, contract, receipt)
        changed_contract = copy.deepcopy(contract)
        changed_contract["lineage_id"] = "fake-variety"
        with self.assertRaises(plate.CleanPlateError):
            plate._checked_result(h, receipt, changed_contract, receipt)

    def test_no_effect_facade_is_unconditionally_closed(self):
        with self.assertRaisesRegex(plate.CleanPlateError, "read-only"):
            plate._deny_effect("command or output path")


if __name__ == "__main__":
    unittest.main()
