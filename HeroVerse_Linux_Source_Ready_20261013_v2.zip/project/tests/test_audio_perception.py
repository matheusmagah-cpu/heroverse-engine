"""Focused component tests; synthetic signals are not perceptual gold."""
import copy
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import wave

import numpy as np
from hero_engine import audio_perception as ap


class AudioPerceptionTests(unittest.TestCase):
    def test_full_master_coverage_includes_tail(self):
        count = 3244480
        starts = ap.window_starts(count)
        self.assertEqual(len(starts), 195)
        self.assertEqual(starts[0], 0)
        self.assertEqual(starts[-1] + ap.WINDOW, count)
        self.assertTrue(all(0 < b - a <= ap.HOP for a, b in zip(starts, starts[1:])))

    def test_exact_window_is_not_duplicated(self):
        self.assertEqual(ap.window_starts(ap.WINDOW), [0])
        self.assertEqual(ap.window_starts(ap.WINDOW + ap.HOP), [0, ap.HOP])

    def test_invalid_duration_and_noninteger_fail(self):
        for count in (True, 144160.0, 0, ap.WINDOW - 1, ap.RATE * 601):
            with self.subTest(count=count), self.assertRaises(ValueError):
                ap.window_starts(count)

    def test_polynomials_match_regular_official_calibration(self):
        values = ap.calibrated([4., 3., 2.])
        # BAK: -.13166888*9 + 1.60915514*3 - .39604546 = 3.24640004.
        np.testing.assert_allclose(values, [3.54503754, 3.24640004, 2.00630339], atol=1e-8, rtol=0)

    def test_nonfinite_wrong_shape_outside_envelope_rejected(self):
        for values in ([float("nan"), 3, 4], [3, float("inf"), 4], [3, 4], [[3, 4, 5]], [7, 3, 4]):
            with self.subTest(values=values), self.assertRaises(ValueError):
                ap.calibrated(values)

    def test_silence_clipping_and_float_validation(self):
        self.assertTrue(ap.quality_samples(np.zeros(10, np.float32))["all_zero"])
        self.assertEqual(ap.quality_samples(np.array([1, -1, .1], np.float32))["samples_at_or_above_full_scale"], 2)
        for signal in (np.zeros(10), np.zeros((1, 10), np.float32), np.array([np.nan], np.float32), np.array([], np.float32)):
            with self.assertRaises(ValueError):
                ap.quality_samples(signal)

    def test_measurements_recompose_and_reject_coverage_or_calibration_tampering(self):
        signal = np.ones(ap.WINDOW + ap.HOP + 500, np.float32) * .01
        rows, summary = ap.evaluate_windows(signal, lambda _: [4., 4., 4.])
        self.assertEqual(summary["uncovered_samples"], 0)
        self.assertEqual(len(rows), 3)
        with self.assertRaises(ValueError): ap.summarize(rows[:-1], len(signal))
        for field, value in (("start_sample", 1), ("start_sample", 0.), ("p835_estimate", [5., 5., 5.])):
            altered = copy.deepcopy(rows)
            altered[0][field] = value
            with self.assertRaises(ValueError): ap.summarize(altered, len(signal))

    def test_predictor_failure_is_not_a_score(self):
        def broken(_): raise RuntimeError("provider unavailable")
        with self.assertRaisesRegex(RuntimeError, "provider unavailable"):
            ap.evaluate_windows(np.zeros(ap.WINDOW, np.float32), broken)

    def test_negative_controls_cannot_pass_with_constant_predictor(self):
        source = np.sin(np.arange(ap.WINDOW, dtype=np.float32) * .1) * .2
        result = ap.control_measurements(source, lambda _: [4., 4., 4.])
        self.assertEqual(result["status"], "FAIL_DIAGNOSTIC_CONTROLS")
        self.assertTrue(result["checks"]["silence_blocked_by_signal_not_mos"])
        self.assertTrue(result["checks"]["clipping_blocked_by_pcm_not_mos"])
        self.assertFalse(result["checks"]["noise_overall_estimate_lower"])

    def test_silent_control_base_blocked(self):
        with self.assertRaisesRegex(ValueError, "no usable signal"):
            ap.control_measurements(np.zeros(ap.WINDOW, np.float32), lambda _: [4., 4., 4.])

    def test_immutable_writer_and_hash_binding(self):
        with tempfile.TemporaryDirectory() as root:
            target = Path(root) / "receipt.json"
            ap.immutable_write(target, b"one")
            ap.immutable_write(target, b"one")
            with self.assertRaises(ValueError): ap.immutable_write(target, b"two")
            self.assertEqual(ap.read_pinned(target, ap.sha(b"one")), b"one")
            with self.assertRaises(ValueError): ap.read_pinned(target, "0" * 64)

    def test_nonfinite_json_refused(self):
        with self.assertRaises(ValueError): ap.canonical({"score": float("nan")})

    def test_offline_bundle_never_downloads(self):
        with tempfile.TemporaryDirectory() as root, patch.object(ap.urllib.request, "urlopen", side_effect=AssertionError("network forbidden")):
            with self.assertRaisesRegex(ValueError, "incomplete"):
                ap.model_bundle(Path(root))

    def test_invalid_download_never_written(self):
        class Response:
            def __enter__(self): return self
            def __exit__(self, *_): pass
            def geturl(self): return ap.BASE + "LICENSE"
            def read(self, _): return b"wrong bytes"
        with tempfile.TemporaryDirectory() as root, patch.object(ap.urllib.request, "urlopen", return_value=Response()):
            with self.assertRaisesRegex(ValueError, "identity mismatch"):
                ap.model_bundle(Path(root), download=True)
            self.assertEqual(list(Path(root).iterdir()), [])

    def test_decode_rejects_wrong_format_before_process(self):
        raw = io.BytesIO()
        with wave.open(raw, "wb") as writer:
            writer.setparams((2, 2, 24000, 100, "NONE", "not compressed"))
            writer.writeframes(b"\0" * 400)
        with patch.object(ap.subprocess, "run", side_effect=AssertionError("process forbidden")):
            with self.assertRaisesRegex(ValueError, "mono24kPCM16"):
                ap.decode(raw.getvalue(), Path("ffmpeg.exe"))

    def test_replay_requires_external_receipt_identity_before_any_execution(self):
        with tempfile.TemporaryDirectory() as root, patch.object(ap.subprocess, "run", side_effect=AssertionError("process forbidden")), patch.object(ap, "measure", side_effect=AssertionError("inference forbidden")):
            target = Path(root) / "bad.json"
            ap.immutable_write(target, ap.canonical({"release_authority": True}))
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                ap.replay(target, "0" * 64, "1" * 64, "2" * 64)


if __name__ == "__main__":
    unittest.main()
