"""Native assessment lifecycle/coverage; learned model has a separate real probe."""
import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import soundfile as sf
from hero_engine.phase5_autonomous_quality import measure_music_aesthetics, _music_aesthetic_predictor
from hero_engine.production_capacity import ResourceWait, _HEAVY_TASK_SLOT

class MusicAestheticAssessmentTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);self.root=Path(temp.name)
        self.media=self.root/'source.wav'
        t=np.arange(48000*12)/48000
        sf.write(self.media,np.column_stack([.1*np.sin(t*2*np.pi*440)]*2),48000,subtype='PCM_16')
        self.pin='sha256:'+hashlib.sha256(self.media.read_bytes()).hexdigest()
        self.weights=self.root/'weights';self.weights.write_bytes(b'fixture-model')
        self.config=self.root/'config';self.config.write_bytes(b'fixture-config')
        self.model={'weights':str(self.weights),'weights_sha256':self.hash(self.weights),
            'config':str(self.config),'config_sha256':self.hash(self.config)}
        self.observed=[]
        def predict(audio,rate):
            self.observed.append((len(audio),rate))
            return {'CE':4.,'CU':6.,'PC':2.,'PQ':7.}
        self.predict=predict
        resources={'available_ram_bytes':2*1024**3,'output_free_bytes':30*1024**3}
        for patcher in (patch('hero_engine.production_capacity.measure_local_resources',return_value=resources),
            patch('hero_engine.phase5_autonomous_quality._music_aesthetic_predictor',return_value=(predict,self.model))):
            patcher.start();self.addCleanup(patcher.stop)

    def hash(self,path):return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()
    def assess(self,**kwargs):
        return measure_music_aesthetics(self.root,self.media,expected_media_hash=self.pin,
            expected_duration_ms=12000,**kwargs)

    def test_same_buffer_windows_cover_full_clock_without_authority(self):
        result=self.assess()
        # Two seconds of unique final coverage use ten REAL seconds of musical
        # context, not two seconds padded with silence. Context is not coverage.
        self.assertEqual(self.observed,[(480000,48000),(480000,48000)])
        self.assertEqual(result['window_context_policy'],'REAL_MUSICAL_TAIL_CONTEXT_UNIQUE_COVERAGE_V1')
        self.assertEqual([(row['start_frame'],row['end_frame']) for row in result['windows']],
                         [(0,480000),(480000,576000)])
        self.assertEqual([(row['context_start_frame'],row['context_end_frame']) for row in result['windows']],
                         [(0,480000),(96000,576000)])
        self.assertEqual(result['observed_frames'],576000)
        self.assertTrue(result['full_duration_observed'])
        self.assertEqual(result['axis_mean']['PQ'],7.)
        for key in ('quality_authorized','render_authorized','publication_authorized','fatigue_or_medical_claim'):
            self.assertFalse(result[key])

    def test_partial_observation_cannot_claim_full_duration(self):
        result=self.assess(window_starts_ms=(2000,))
        self.assertFalse(result['full_duration_observed'])
        self.assertFalse(result['quality_authorized'])

    def test_overlapping_or_invalid_windows_rejected_before_model(self):
        for starts in ((0,1000),(10000,0),(True,),(12000,),(),[0]):
            with self.subTest(starts=starts),self.assertRaises(ValueError):
                self.assess(window_starts_ms=starts)
        self.assertEqual(self.observed,[])

    def test_media_tamper_rejected_before_model(self):
        self.media.write_bytes(self.media.read_bytes()+b'x')
        with self.assertRaises(PermissionError):self.assess()
        self.assertEqual(self.observed,[])

    def test_duration_divergence_rejected(self):
        with self.assertRaises(PermissionError):
            measure_music_aesthetics(self.root,self.media,expected_media_hash=self.pin,expected_duration_ms=11999)

    def test_foreign_media_cannot_enter_assessment(self):
        with self.assertRaises(ValueError):
            measure_music_aesthetics(self.root/'other',self.media,expected_media_hash=self.pin,expected_duration_ms=12000)

    def test_second_capacity_sample_blocks_and_releases_slot(self):
        good={'available_ram_bytes':2*1024**3,'output_free_bytes':30*1024**3}
        with patch('hero_engine.production_capacity.measure_local_resources',side_effect=[good,{**good,'available_ram_bytes':1024**3}]):
            with self.assertRaises(ResourceWait):self.assess()
        self.assertEqual(self.observed,[])
        self.assertTrue(_HEAVY_TASK_SLOT.acquire(blocking=False));_HEAVY_TASK_SLOT.release()

    def test_active_stage_does_not_load_model(self):
        self.assertTrue(_HEAVY_TASK_SLOT.acquire(blocking=False))
        try:
            with self.assertRaises(ResourceWait):self.assess()
        finally:_HEAVY_TASK_SLOT.release()
        self.assertEqual(self.observed,[])

    def test_model_change_during_inference_rejects_result(self):
        def corrupt(audio,rate):
            self.weights.write_bytes(b'changed')
            return self.predict(audio,rate)
        with patch('hero_engine.phase5_autonomous_quality._music_aesthetic_predictor',return_value=(corrupt,self.model)):
            with self.assertRaises(PermissionError):self.assess()

    def test_incomplete_or_nonfinite_predictions_reject_and_restore_threads(self):
        import torch
        threads=torch.get_num_threads()
        for scores in ({'PQ':8.},{'CE':1.,'CU':2.,'PC':3.,'PQ':float('nan')}):
            with self.subTest(scores=scores),patch('hero_engine.phase5_autonomous_quality._music_aesthetic_predictor',
                return_value=(lambda *_:scores,self.model)):
                with self.assertRaises(PermissionError):self.assess()
            self.assertEqual(torch.get_num_threads(),threads)

    def test_unknown_weights_rejected_by_real_local_loader(self):
        with patch('hero_engine.phase5_autonomous_quality.MUSIC_MODEL_REVISION','fixture'):
            directory=self.root/'models/audiobox-aesthetics/fixture';directory.mkdir(parents=True)
            (directory/'model.safetensors').write_bytes(b'untrusted')
            with self.assertRaises(PermissionError):_music_aesthetic_predictor(self.root)
