"""Phase 6 expansion must catalog remotely before an approved take exists."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import phase6_assets


ROOT = Path(__file__).resolve().parents[1]


class Phase6AssetDiscoveryOnDemandTests(unittest.TestCase):
    def test_insufficient_pool_catalogs_candidates_without_invoking_media_download(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "schemas").mkdir()
            (root / "schemas" / "phase6_asset_library_expansion.schema.json").write_bytes(
                (ROOT / "schemas" / "phase6_asset_library_expansion.schema.json").read_bytes()
            )
            baseline_path = root / phase6_assets.BASELINE
            baseline_path.parent.mkdir(parents=True)
            baseline_path.write_text(json.dumps({"assets": [{"asset_id": "baseline-only"}]}), encoding="utf-8")
            catalog = {"candidate_count": 1, "media_downloaded": False}
            with patch.object(phase6_assets, "build_asset_catalog", return_value=catalog) as build:
                result = phase6_assets.materialize_phase6_asset_expansion(
                    root, created_at="2026-09-21T00:00:00Z",
                )
            build.assert_called_once()
            self.assertEqual("BLOCKED", result["status"])
            self.assertIn("LOCAL_ACQUISITION_DEFERRED_UNTIL_APPROVED_TAKE", result["errors"][-1]["error"])
            self.assertFalse((root / "output" / "production" / "phase6" / "shared-assets" / "assets").exists())


if __name__ == "__main__":
    unittest.main()
