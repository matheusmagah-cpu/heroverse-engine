"""Focused tests for the non-authoritative Stage-B admission boundary.

Synthetic Stage-A media is explicitly FIXTURE.  These tests never create a
queue job, generation, render, publication or production admission receipt.
"""
from __future__ import annotations

import copy
import json
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from hero_engine import phase6_av_timeline as av
from hero_engine import phase6_narration_audio_inventory as inventory
from hero_engine.phase6_av_admission import (
    AdmissionError,
    FALSE_AUTHORITY,
    GENERATION_PARENT,
    MINIMUM_POST_RENDER_FREE_BYTES,
    _asset_map,
    _validate_capacity,
    _validate_namespace,
    _validate_publicity,
    _validate_schema,
    validate_timeline_for_admission,
    verify_phase6_av_admission,
)
from hero_engine.phase6_narration_units import bytes_sha, canonical_sha
from tests import test_phase6_av_timeline as stage_a
from tests.static_input_isolation import archived_historical_inventory_inputs


ROOT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 9, 6, 15, 0, tzinfo=timezone.utc)


def identify(value, field, prefix):
    value.pop(field, None)
    value[field] = prefix + canonical_sha(value).split(":", 1)[1][:24]
    return value


def dump(root: Path, relative: str, value: dict) -> dict:
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    path.write_bytes(raw)
    return {"path": relative, "sha256": bytes_sha(raw), "size_bytes": len(raw)}


def namespace():
    return {
        "policy_id": "phase6-av-generation-namespace-v1",
        "generation_parent": GENERATION_PARENT,
        "assignment": "QUEUE_COMMIT_ONLY",
        "generation_id": None,
        "render_path": None,
        "requires_fresh_child_directory": True,
        "baseline_overwrite_allowed": False,
    }


def context(input_id="phase6-production-inputs-fixture"):
    return {
        "authority_root_job_id": "root-job-fixture",
        "authority_root_payload_sha256": "sha256:" + "1" * 64,
        "authority_root_checkpoint_sha256": "sha256:" + "2" * 64,
        "predecessor_job_id": "predecessor-job-fixture",
        "predecessor_payload_sha256": "sha256:" + "3" * 64,
        "predecessor_checkpoint_sha256": "sha256:" + "4" * 64,
        "predecessor_state": "SUCCEEDED",
        "predecessor_lease_owner": None,
        "tail_job_id": "predecessor-job-fixture",
        "media_unit_key": "phase6-video-002",
        "input_receipt_id": input_id,
        "input_receipt_sha256": "sha256:" + "5" * 64,
    }


class TimelineAdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name).resolve()
        cls.bindings = stage_a.fixture(cls.root)
        helper = stage_a.StageATests(methodName="test_complete_fixture_uses_51_whole_unit_cues_and_two_spans")
        helper.root, helper.bindings = cls.root, cls.bindings
        cls.complete_args = helper.complete()
        cls.complete_timeline = av.build(cls.root, **cls.complete_args)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def raw(self, mode="FIXTURE", args=None):
        value = {
            "schema_version": "1.0.0",
            "document_type": "PHASE6_AV_RAW_ARGUMENTS",
            "evidence_mode": mode,
            "channel_id": self.complete_timeline["channel_id"],
            "video_id": self.complete_timeline["video_id"],
            "protocol_id": self.complete_timeline["protocol_id"],
            "arguments": copy.deepcopy(args or self.complete_args),
            "authority": copy.deepcopy(FALSE_AUTHORITY),
            "technical_cost_brl": 0,
        }
        return identify(value, "arguments_id", "phase6-av-arguments-")

    def test_current_real_timeline_is_recomposed_and_refused_as_incomplete(self):
        bindings = stage_a.real_bindings()
        args = {
            "source_bindings": bindings,
            "pause_decisions": [], "render_spans": [], "visual_events": [],
            "caption_cues": [], "temporal_evidence_bindings": {},
            "temporal_policy_binding": None,
        }
        # The real historical argument bundle retains old logical paths.  Its
        # archive transport is test-local; the production Reader remains
        # strict and cannot silently relocate an active input.
        with archived_historical_inventory_inputs(inventory):
            current = av.build(ROOT, **args)
            self.assertEqual("BLOCKED_INCOMPLETE", current["status"])
            self.assertEqual(190800, current["duration"]["planned_duration_ms"])
            with self.assertRaisesRegex(AdmissionError, "incomplete"):
                validate_timeline_for_admission(ROOT, current, args, evidence_mode="LIVE")

    def test_complete_fixture_runs_real_verifier_but_never_becomes_admissible(self):
        self.assertEqual("TIMELINE_VALIDATED_NOT_ADMITTED", self.complete_timeline["status"])
        with self.assertRaisesRegex(AdmissionError, "FIXTURE"):
            validate_timeline_for_admission(
                self.root, self.complete_timeline, self.raw(), evidence_mode="FIXTURE"
            )

    def test_candidate_authority_and_raw_argument_tamper_fail_recomposition(self):
        forged = copy.deepcopy(self.complete_timeline)
        forged["authority"]["render_authorized"] = True
        with self.assertRaisesRegex(AdmissionError, "recomposition failed"):
            validate_timeline_for_admission(self.root, forged, self.raw(), evidence_mode="FIXTURE")
        changed = self.raw()
        changed["arguments"]["pause_decisions"][0]["target_low_energy_samples"] += 2400
        with self.assertRaisesRegex(AdmissionError, "recomposition failed"):
            validate_timeline_for_admission(
                self.root, self.complete_timeline, changed, evidence_mode="FIXTURE"
            )

    def test_fixture_request_and_independent_context_never_reach_controls(self):
        raw = self.raw()
        args_binding = dump(self.root, "output/operations/phase6/av-admission/arguments/" + raw["arguments_id"] + ".json", raw)
        timeline_binding = dump(self.root, "output/operations/phase6/av-admission/timelines/" + self.complete_timeline["timeline_id"] + ".json", self.complete_timeline)
        ctx = context()
        input_pin = {"path": "output/operations/phase6/release/production-input-receipts/phase6-production-inputs-fixture.json",
                     "sha256": ctx["input_receipt_sha256"], "size_bytes": 1,
                     "document_id": ctx["input_receipt_id"]}
        missing = {"path": "output/operations/phase6/av-admission/evidence/capacity/missing.json",
                   "sha256": "sha256:" + "6" * 64, "size_bytes": 1}
        request = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_ADMISSION_REQUEST",
            "evidence_mode": "FIXTURE", "channel_id": self.complete_timeline["channel_id"],
            "video_id": self.complete_timeline["video_id"], "protocol_id": self.complete_timeline["protocol_id"],
            "context": ctx, "raw_arguments": args_binding, "timeline": timeline_binding,
            "input_receipt": input_pin, "capacity_evidence": missing,
            "rights_evidence": {**missing, "path": missing["path"].replace("capacity", "rights")},
            "publicity_evidence": {**missing, "path": missing["path"].replace("capacity", "publicity")},
            "namespace_policy": namespace(), "transaction_state": "NOT_STARTED",
            "authority": copy.deepcopy(FALSE_AUTHORITY), "technical_cost_brl": 0,
            "publication_authorized": False,
        }
        identify(request, "request_id", "phase6-av-admission-request-")
        request_binding = dump(self.root, "output/operations/phase6/av-admission/requests/" + request["request_id"] + ".json", request)
        with self.assertRaisesRegex(AdmissionError, "FIXTURE request"):
            verify_phase6_av_admission(self.root, request_binding, expected_context=ctx,
                                       input_receipt={}, now=NOW)
        bad_binding = {**request_binding, "sha256": "sha256:" + "0" * 64}
        with self.assertRaisesRegex(AdmissionError, "hash or size"):
            verify_phase6_av_admission(self.root, bad_binding, expected_context=ctx,
                                       input_receipt={}, now=NOW)
        live = copy.deepcopy(request)
        live["evidence_mode"] = "LIVE"
        live["context"]["tail_job_id"] = "different-tail"
        identify(live, "request_id", "phase6-av-admission-request-")
        live_binding = dump(self.root, "output/operations/phase6/av-admission/requests/" + live["request_id"] + ".json", live)
        with self.assertRaisesRegex(AdmissionError, "not transaction-safe"):
            verify_phase6_av_admission(self.root, live_binding,
                                       expected_context=live["context"], input_receipt={}, now=NOW)
        safe_live = copy.deepcopy(live)
        safe_live["context"] = copy.deepcopy(ctx)
        identify(safe_live, "request_id", "phase6-av-admission-request-")
        safe_binding = dump(self.root, "output/operations/phase6/av-admission/requests/" + safe_live["request_id"] + ".json", safe_live)
        wrong_caller = copy.deepcopy(ctx)
        wrong_caller["authority_root_job_id"] = "other-root"
        with self.assertRaisesRegex(AdmissionError, "caller-supplied"):
            verify_phase6_av_admission(self.root, safe_binding,
                                       expected_context=wrong_caller, input_receipt={}, now=NOW)


class IndependentControlTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.timeline_ref = {
            "timeline_id": "phase6-av-timeline-" + "a" * 24,
            "sha256": "sha256:" + "b" * 64,
            "planned_total_samples": 5_000_000,
        }

    def tearDown(self):
        self.temp.cleanup()

    def capacity(self):
        tools = []
        for role, name in (("FFMPEG", "ffmpeg.fixture"), ("FFPROBE", "ffprobe.fixture")):
            path = self.root / name
            path.write_bytes(role.encode("ascii"))
            tools.append({"role": role, "path": name, "sha256": bytes_sha(path.read_bytes()), "version": "fixture-1"})
        peak = 1000
        observed = MINIMUM_POST_RENDER_FREE_BYTES + peak + 4096
        value = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_CAPACITY_EVIDENCE",
            "evidence_mode": "LIVE", "status": "PASS",
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA", "video_id": "phase6-video-002-prepublication",
            "timeline": copy.deepcopy(self.timeline_ref),
            "recipe_id": "phase6-av-continuous-render-capacity-v1",
            "planned_total_samples": self.timeline_ref["planned_total_samples"],
            "estimated_peak_new_bytes": peak, "observed_free_bytes": observed,
            "required_free_bytes": peak + MINIMUM_POST_RENDER_FREE_BYTES,
            "projected_post_render_free_bytes": observed - peak,
            "minimum_post_render_free_bytes": MINIMUM_POST_RENDER_FREE_BYTES,
            "tools": tools, "measured_at": (NOW - timedelta(minutes=1)).isoformat(),
            "valid_until": (NOW + timedelta(minutes=10)).isoformat(),
            "publication_authorized": False, "technical_cost_brl": 0,
        }
        identify(value, "evidence_id", "phase6-av-capacity-")
        path = self.root / (value["evidence_id"] + ".json")
        return value, path

    def test_capacity_contract_checks_tools_ttl_and_exact_five_gib_reserve(self):
        value, path = self.capacity()
        self.assertEqual("PASS", _validate_capacity(self.root, value, path, self.timeline_ref, NOW)["status"])
        for mutation, message in (
            (lambda item: item.update(required_free_bytes=item["required_free_bytes"] - 1), "arithmetic"),
            (lambda item: item.update(valid_until=(NOW - timedelta(seconds=1)).isoformat()), "stale"),
            (lambda item: item["tools"].__setitem__(1, copy.deepcopy(item["tools"][0])), "exactly FFmpeg"),
        ):
            bad = copy.deepcopy(value)
            mutation(bad)
            identify(bad, "evidence_id", "phase6-av-capacity-")
            bad_path = self.root / (bad["evidence_id"] + ".json")
            with self.assertRaisesRegex(AdmissionError, message):
                _validate_capacity(self.root, bad, bad_path, self.timeline_ref, NOW)

    def test_publicity_and_rights_asset_sets_reject_missing_duplicate_or_risk(self):
        required = [{"path": "asset-a.mp4", "sha256": "sha256:" + "a" * 64,
                     "spans": [{"span_id": "span-a", "source_start_frame": 0,
                                "source_end_frame": 30}]}]
        duplicate = [
            {"asset_id": "a", **required[0]},
            {"asset_id": "b", **required[0]},
        ]
        with self.assertRaisesRegex(AdmissionError, "duplicate"):
            _asset_map(duplicate, "fixture")
        value = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_PUBLICITY_EVIDENCE",
            "evidence_mode": "LIVE", "status": "PASS",
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA", "video_id": "phase6-video-002-prepublication",
            "timeline": copy.deepcopy(self.timeline_ref),
            "detector": {
                "implementation_path": "hero_engine/phase6_publicity.py",
                "implementation_sha256": bytes_sha((ROOT / "hero_engine/phase6_publicity.py").read_bytes()),
                "model_path": "models/yunet/face_detection_yunet_2026may.onnx",
                "model_sha256": "sha256:ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0",
                "method": "METADATA_DENYLIST_PLUS_LOCAL_YUNET_SAMPLED_RANGES",
            },
            "assets": [{"asset_id": "a", "path": required[0]["path"], "sha256": required[0]["sha256"],
                        "status": "PASS", "sample_frame_count": 3,
                        "detected_face_count": 1, "metadata_risk_terms": [], "decode_errors": [],
                        "screened_spans": [{"span_id": "span-a", "source_start_frame": 0,
                                            "source_end_frame": 30,
                                            "sampled_source_frames": [0, 14, 29]}]}],
            "claim_boundary": "Fixture unit test; no production authority.",
            "publication_authorized": False, "technical_cost_brl": 0,
        }
        identify(value, "evidence_id", "phase6-av-publicity-")
        with self.assertRaisesRegex(AdmissionError, "ambiguity, a person"):
            _validate_publicity(ROOT, value, ROOT / (value["evidence_id"] + ".json"),
                                self.timeline_ref, required)
        missing_middle = copy.deepcopy(value)
        missing_middle["assets"][0]["detected_face_count"] = 0
        missing_middle["assets"][0]["screened_spans"][0]["sampled_source_frames"] = [0, 29]
        missing_middle["assets"][0]["sample_frame_count"] = 2
        identify(missing_middle, "evidence_id", "phase6-av-publicity-")
        with self.assertRaisesRegex(AdmissionError, "start/middle/end"):
            _validate_publicity(ROOT, missing_middle,
                                ROOT / (missing_middle["evidence_id"] + ".json"),
                                self.timeline_ref, required)

    def test_namespace_and_schema_cannot_represent_commit_or_authority(self):
        _validate_namespace(namespace())
        for mutation in (
            lambda item: item.update(generation_id="gen-forged"),
            lambda item: item.update(baseline_overwrite_allowed=True),
        ):
            bad = namespace()
            mutation(bad)
            with self.assertRaises(AdmissionError):
                _validate_namespace(bad)
        proof = {
            "schema_version": "1.0.0", "document_type": "PHASE6_AV_ADMISSION_PROOF",
            "proof_id": "phase6-av-admission-proof-" + "0" * 24,
            "status": "ELIGIBLE_FOR_TRANSACTION",
            "request": {"path": "request.json", "sha256": "sha256:" + "1" * 64,
                        "size_bytes": 1, "request_id": "phase6-av-admission-request-" + "2" * 24},
            "context": context(), "timeline": copy.deepcopy(self.timeline_ref),
            "input_receipt_id": "phase6-production-inputs-fixture",
            "controls": {
                "capacity": {"evidence_id": "capacity", "status": "PASS", "valid_until": NOW.isoformat()},
                "rights": {"evidence_id": "rights", "status": "PASS", "asset_count": 1},
                "publicity": {"evidence_id": "publicity", "status": "PASS", "asset_count": 1,
                              "claim_boundary": "risk screen only"},
            },
            "namespace_policy": namespace(),
            "checks": ["RAW_ARGUMENTS_REOPENED", "TIMELINE_RECOMPOSED_REQUIRE_COMPLETE", "INPUT_RECEIPT_REOPENED",
                       "CAPACITY_SEPARATELY_VERIFIED", "RIGHTS_SEPARATELY_VERIFIED",
                       "PUBLICITY_SEPARATELY_VERIFIED", "NAMESPACE_UNASSIGNED_UNTIL_TRANSACTION"],
            "transaction": {"state": "NOT_STARTED", "prepared": False, "committed": False,
                            "generation_namespace_assigned": False},
            "authority": copy.deepcopy(FALSE_AUTHORITY), "technical_cost_brl": 0,
            "publication_authorized": False, "created_at": NOW.isoformat(),
        }
        _validate_schema(proof)
        for mutation in (
            lambda item: item["transaction"].update(state="COMMITTED", committed=True),
            lambda item: item["authority"].update(queue_authorized=True),
        ):
            bad = copy.deepcopy(proof)
            mutation(bad)
            with self.assertRaises(AdmissionError):
                _validate_schema(bad)


if __name__ == "__main__":
    unittest.main()
