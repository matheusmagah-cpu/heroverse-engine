from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class Phase6CatalogWorkbookTests(unittest.TestCase):
    def test_workbook_uses_live_phase6_control_instead_of_legacy_cadence(self) -> None:
        builder = (ROOT / "tools/build_catalog.mjs").read_text(encoding="utf-8")
        self.assertIn("output\", \"operations\", \"phase6\", \"executive-status.json", builder)
        self.assertIn("Current YPP-valid watch hours", builder)
        self.assertIn('forecast.getRange("B14").values = [["UNAVAILABLE"]]', builder)
        self.assertIn("Controlled pilot maximum", builder)
        self.assertIn("Number.isFinite(currentValidWatchHours)", builder)
        self.assertIn("currentSubscribersObserved", builder)
        self.assertIn('const currentSubscriberValue = currentSubscribersObserved ? currentSubscribers : "UNAVAILABLE"', builder)
        self.assertIn("Historical baseline — context only, never current", builder)
        self.assertIn("this is not the current count", builder)
        self.assertIn("channelBaselineSnapshot?.observed_at", builder)
        self.assertIn("yyyy-mm-dd hh:mm", builder)
        self.assertIn('forecast.getRange("B13").values = [["UNAVAILABLE"]]', builder)
        self.assertNotIn("observed_subscribers ?? catalog.config.channel.current_subscribers", builder)
        self.assertIn('kpiValue(dashboard, "G5:J8", "YPP WATCH-HOUR GAP", "UNAVAILABLE")', builder)
        self.assertIn('kpiValue(dashboard, "A5:C8", "CURRENT SUBSCRIBERS", "UNAVAILABLE")', builder)
        self.assertIn('kpiValue(dashboard, "D5:F8", "SUBSCRIBER GAP", "UNAVAILABLE")', builder)
        self.assertIn("Requirement math and chart remain blank", builder)
        self.assertIn("No release precommitted", builder)
        self.assertIn("Daily observation is not a promised post", builder)
        self.assertIn('day === 0\n    ? "Public canary start"', builder)
        self.assertIn('[30, "720h D30 close"]', builder)
        self.assertIn('"Official daily channel metrics"', builder)
        self.assertIn('const status = day === 0 ? "Published" : "Scheduled"', builder)
        self.assertIn('for (let day = 0; day <= 30; day += 1)', builder)
        self.assertIn('planRows.push([`D${day}`', builder)
        self.assertNotIn("No scheduled checkpoint", builder)
        self.assertNotIn("generated 2026-09-01", builder)
        self.assertNotIn("1 long + 2 Shorts/day", builder)
        self.assertNotIn("2 longs/day only if gate passes", builder)

    def test_workbook_merge_writes_each_forecast_note_to_its_own_row(self) -> None:
        builder = (ROOT / "tools/build_catalog.mjs").read_text(encoding="utf-8")
        self.assertIn("for (let index = 0; index < forecastNotes.length; index += 1)", builder)
        self.assertIn("forecast.getRange(`A${row}:H${row}`).merge()", builder)
        self.assertNotIn('forecast.getRange("A29:H31").merge(true)', builder)


if __name__ == "__main__":
    unittest.main()
