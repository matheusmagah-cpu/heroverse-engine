"""Contract-only negative controls; no inference or production admission."""
import json
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def patterned(node, path=()):
    if isinstance(node, dict):
        if 'pattern' in node:
            yield path, node
        for key, value in node.items():
            yield from patterned(value, (*path, key))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            yield from patterned(value, (*path, index))


class AdmissionSchemaTests(unittest.TestCase):
    def test_every_pattern_requires_strings_and_rejects_other_json_types(self):
        schema=json.loads((ROOT/'schemas/phase6_av_admission.schema.json').read_text())
        Draft202012Validator.check_schema(schema)
        rows=list(patterned(schema))
        # Rights 1.1 adds the static document path, inspection ID and its
        # versioned evidence ID. All fourteen rules retain exact string types.
        self.assertEqual(len(rows),14)
        for path, rule in rows:
            with self.subTest(path=path):
                self.assertEqual(rule.get('type'),'string')
                validator=Draft202012Validator(rule)
                for bad in (None, True, 1, 1.5, [], {}):
                    self.assertFalse(validator.is_valid(bad),repr((path,bad)))

    def test_schema_never_grants_commit_or_external_authority(self):
        schema=json.loads((ROOT/'schemas/phase6_av_admission.schema.json').read_text())
        for rule in schema['$defs']['authority']['properties'].values():
            self.assertIs(rule['const'],False)
        fields=schema['$defs']['proof']['properties']['transaction']['properties']
        self.assertEqual(fields['state']['const'],'NOT_STARTED')
        for field in ('prepared','committed','generation_namespace_assigned'):
            self.assertIs(fields[field]['const'],False)


if __name__=='__main__': unittest.main()
