"""Temporary Phase 3 contract/replay fixture; never an operational initializer.

Only cached JSON, schemas, CSV and migration SQL are copied from the repository.
The opening clip is newly generated from lavfi and is not real channel media.
The production opening analyzer, FFmpeg scene parser, stores and runner remain real.
"""
from __future__ import annotations

import builtins
import functools
import io
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote, urlsplit

from hero_engine import db
from hero_engine.mining.pipeline import FIXTURE_IDS
from hero_engine.observatory import openings, phase3, store


class Phase3IsolatedFixture:
    RUN_ID = "phase3-2026-09-02-catalog-v2"

    def __init__(self, source_root: Path):
        self.source_root = source_root.resolve()
        self._stack = ExitStack()
        self.sqlite_paths = []
        self.written_paths = []
        self.process_commands = []
        self._opening_process_pipes = False

    def __enter__(self):
        try:
            self.root = Path(self._stack.enter_context(tempfile.TemporaryDirectory(prefix="phase3-isolation-"))).resolve()
            self.db_path = self.root / "data/hero_engine.db"
            self.output_root = self.root / "output/observatory/phase3"
            self.run_dir = self.output_root / self.RUN_ID
            self.model_root = self.root / "data/modeling/grace-grit-love"
            self.run_dir.mkdir(parents=True)

            def copy(relative):
                if relative.suffix not in {".json", ".csv", ".sql"}:
                    raise AssertionError("Only documentary fixture inputs may be copied")
                source = self.source_root / relative
                target = self.root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())

            for name in ("observatory_snapshot.schema.json", "observatory_coverage.schema.json",
                         "observatory_cohorts.schema.json", "observatory_ledger_event.schema.json"):
                copy(Path("schemas") / name)
            copy(Path("data/seed_channels.csv"))
            copy(Path("migrations/phase3/001_observatory_ssot.sql"))
            copy(Path("data/modeling/grace-grit-love/intro-transcripts.json"))
            for video_id in FIXTURE_IDS:
                copy(Path("data/gold_standard") / video_id / "video_mining.json")
            relative_run = self.run_dir.relative_to(self.root)
            for name in ("run_context.json", "public_snapshots.json"):
                copy(relative_run / name)
            for source in sorted((self.source_root / relative_run / "snapshots").glob("*.json")):
                copy(source.relative_to(self.source_root))

            self.ffmpeg = shutil.which("ffmpeg")
            if not self.ffmpeg:
                raise AssertionError("Existing FFmpeg is required for the isolated opening fixture")
            self.ffmpeg = str(Path(self.ffmpeg).resolve())
            self._guard_io()
            for module in (phase3, openings, store, db):
                self._stack.enter_context(patch.object(module, "ROOT", self.root))
            self._stack.enter_context(patch.object(openings, "MODEL_ROOT", self.model_root))
            # apply_migration's default Path was frozen at import; pass the copied SQL explicitly.
            self._stack.enter_context(patch.object(
                phase3, "apply_migration",
                functools.partial(store.apply_migration, migration=self.root / "migrations/phase3/001_observatory_ssot.sql"),
            ))
            self._stack.enter_context(patch.object(
                phase3, "collect_channel", side_effect=AssertionError("Cache replay must not collect from the network"),
            ))
            self.config = phase3.Phase3Config(
                run_id=self.RUN_ID, db_path=self.db_path, output_root=self.output_root,
                collect_public_metadata=False,
            )
            self.synthetic = self.model_root / "intros/synthetic-source.mp4"
            self.synthetic.parent.mkdir(parents=True)
            subprocess.run([
                self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
                "-f", "lavfi", "-i", "color=c=black:s=32x32:r=1:d=40",
                "-an", "-c:v", "mpeg4", "-q:v", "10", str(self.synthetic),
            ], check=True, capture_output=True, timeout=15)
            raw = self.synthetic.read_bytes()
            transcripts = json.loads((self.model_root / "intro-transcripts.json").read_text(encoding="utf-8"))
            self.opening_paths = set()
            for transcript in transcripts:
                target = self.model_root / "intros" / (transcript["video_id"] + ".mp4")
                self.opening_paths.add(target.resolve())
                target.write_bytes(raw)
            if self.db_path.exists():
                raise AssertionError("Fixture must start without an existing database")
            return self
        except BaseException:
            self._stack.close()
            raise

    def __exit__(self, *exc):
        return self._stack.__exit__(*exc)

    def confined(self, path):
        if isinstance(path, int):
            raise AssertionError("Unattributed descriptor forbidden in Phase 3 fixture")
        result = Path(path).resolve()
        if not result.is_relative_to(self.root):
            raise AssertionError("Phase 3 escaped its temporary root: " + str(result))
        return result

    def _guard_io(self):
        builtin_open, io_open = builtins.open, io.open
        sqlite_connect, native_run, native_popen = sqlite3.connect, subprocess.run, subprocess.Popen
        process_environment = {
            key: value for key, value in os.environ.items()
            if key.upper() in {"PATH", "SYSTEMROOT", "WINDIR"}
        }
        process_environment.update({"TEMP": str(self.root), "TMP": str(self.root)})

        def opening(original):
            def call(path, mode="r", *args, **kwargs):
                # subprocess creates anonymous pipes from descriptors inside its
                # already allowlisted Popen call; these are not filesystem paths.
                if isinstance(path, int) and self._opening_process_pipes:
                    return original(path, mode, *args, **kwargs)
                target = self.confined(path)
                if any(flag in mode for flag in "wax+"):
                    self.written_paths.append(target)
                return original(path, mode, *args, **kwargs)
            return call

        def filesystem(original, two_paths=False):
            def call(path, *args, **kwargs):
                self.written_paths.append(self.confined(path))
                if two_paths:
                    self.written_paths.append(self.confined(args[0]))
                return original(path, *args, **kwargs)
            return call

        def connection(database, *args, **kwargs):
            value = str(database)
            path = unquote(urlsplit(value).path) if value.startswith("file:") else value
            self.sqlite_paths.append(self.confined(path))
            return sqlite_connect(database, *args, **kwargs)

        def command_is_confined(command):
            if not isinstance(command, list) or str(Path(command[0]).resolve()) != self.ffmpeg:
                raise AssertionError("Only the existing FFmpeg may execute in this fixture")
            if "lavfi" in command:
                if command[command.index("-i") + 1] != "color=c=black:s=32x32:r=1:d=40":
                    raise AssertionError("Synthetic generation input changed")
                if self.confined(command[-1]) != self.synthetic:
                    raise AssertionError("Unexpected synthetic output")
            else:
                source = self.confined(command[command.index("-i") + 1])
                if source not in self.opening_paths or command[-2:] != ["null", "-"]:
                    raise AssertionError("Scene analysis must read only temporary synthetic media and emit null output")

        def popen(command, *args, **kwargs):
            command_is_confined(command)
            if kwargs.get("shell"):
                raise AssertionError("Shell invocation forbidden")
            kwargs.update(cwd=self.root, env=process_environment, stdin=subprocess.PIPE)
            self.process_commands.append(list(command))
            self._opening_process_pipes = True
            try:
                return native_popen(command, *args, **kwargs)
            finally:
                self._opening_process_pipes = False

        def run(command, *args, **kwargs):
            command_is_confined(command)
            kwargs["timeout"] = min(float(kwargs.get("timeout", 15)), 15)
            return native_run(command, *args, **kwargs)

        for target, side_effect in (("builtins.open", opening(builtin_open)), ("io.open", opening(io_open)),
                                    ("sqlite3.connect", connection), ("subprocess.run", run), ("subprocess.Popen", popen)):
            self._stack.enter_context(patch(target, side_effect=side_effect))
        for name in ("mkdir", "unlink", "remove", "open", "rename", "replace"):
            original = getattr(os, name)
            self._stack.enter_context(patch.object(os, name, side_effect=filesystem(original, name in {"rename", "replace"})))
        for target in ("socket.socket.connect", "socket.socket.connect_ex", "socket.create_connection", "os.system"):
            self._stack.enter_context(patch(target, side_effect=AssertionError("External effect forbidden in Phase 3 fixture")))
