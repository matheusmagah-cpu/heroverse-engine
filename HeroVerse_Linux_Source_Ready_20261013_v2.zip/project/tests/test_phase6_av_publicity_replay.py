"""Counterproof integrity fixtures, never a real detector or source approval."""
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
import unittest
from unittest.mock import patch

from hero_engine import phase6_av_publicity_replay as R
from tests import test_phase6_av_publicity_v2 as fixture_support


class ReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Prepare one explicit fixture transaction for the whole focused batch.
        # No inherited test methods are run, and no fixture becomes LIVE.
        cls.harness = fixture_support.PublicityV2Tests(methodName="runTest")
        cls.harness.setUp()
        cls.harness.run_scan()
        cls.proof = cls.harness.verify()
        cls.root = cls.harness.root
        cls.proof_path = cls.root / "output/verification/verification.json"
        cls.base = {
            "counterproof_binding": R.P.binding(cls.proof_path),
            "expected_source_receipt": R.P.binding(cls.root / "output/scan/receipt.json"),
            "expected_counter_receipt": R.P.binding(cls.root / "output/verification/receipt.json"),
            "expected_timeline": R.P.binding(cls.harness.timeline),
            "expected_library": R.P.binding(cls.harness.library),
            "expected_policy": R.P.binding(cls.harness.policy_path), "require_live": False,
        }

    @classmethod
    def tearDownClass(cls):
        cls.harness.doCleanups()

    def setUp(self):
        # Any accidental execution, observation or mutation by replay is a test failure.
        self.patches = [patch.object(R.P, name, side_effect=AssertionError("REPLAY_SIDE_EFFECT_FORBIDDEN"))
                        for name in ("execute", "verify", "owned", "save", "atomic", "LiveBackend", "derive_assets", "_sample_journal")]
        for context in self.patches:
            context.start()
            self.addCleanup(context.stop)

    def replay(self, **changes):
        return R.replay_counterproof(self.root, **{**self.base, **changes})

    def corrupt(self, path, value):
        original = path.read_bytes()
        self.addCleanup(path.write_bytes, original)
        path.write_bytes(R.P.canonical(value))
        return R.P.binding(path)

    def test_exact_replay_has_no_effects_preserves_ttl_and_population(self):
        before = {str(p.relative_to(self.root)): (p.stat().st_size, p.stat().st_mtime_ns)
                  for p in self.root.rglob("*") if p.is_file()}
        result = self.replay()
        after = {str(p.relative_to(self.root)): (p.stat().st_size, p.stat().st_mtime_ns)
                 for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)
        self.assertEqual(result["status"], "EXACT_CACHE_REPLAY_INTEGRITY_ONLY_NOT_ADMITTED")
        self.assertEqual(result["evidence_mode"], "FIXTURE")
        self.assertEqual(result["sample_pairs"], 12)
        self.assertEqual((result["decode_calls"], result["inference_calls"], result["files_written"]), (0, 0, 0))
        self.assertEqual(R.P.utc(result["valid_until"]), R.P.utc(self.proof["valid_until"]))
        self.assertFalse(any(result["authority"].values()))
        self.assertFalse(result["provider_switch"])

    def test_default_live_and_nonboolean_mode_cannot_accept_fixture(self):
        with self.assertRaisesRegex(R.P.PublicityError, "LIVE"):
            self.replay(require_live=True)
        for value in (1, 0, "false", None):
            with self.subTest(value=value), self.assertRaises(R.P.PublicityError):
                self.replay(require_live=value)

    def test_tampered_raw_fails_without_new_detector(self):
        receipt = R.P.document((self.root / "output/scan/receipt.json").read_bytes())
        sample = R.P.document(R.P.reopen(self.root, receipt["samples"][0]))
        self.corrupt(Path(sample["raw"]["path"]), {})
        with self.assertRaises(R.P.PublicityError):
            self.replay()

    def test_counterproof_cannot_change_external_receipt_or_count(self):
        value = deepcopy(self.proof)
        value["sample_count"] += 1
        changed = self.corrupt(self.proof_path, value)
        with self.assertRaisesRegex(R.P.PublicityError, "sample count"):
            self.replay(counterproof_binding=changed)

    def test_source_and_counter_receipt_alias_rejected(self):
        value = deepcopy(self.proof)
        value["counterproof_receipt"] = self.base["expected_source_receipt"]
        changed = self.corrupt(self.proof_path, value)
        with self.assertRaisesRegex(R.P.PublicityError, "separate journals"):
            self.replay(counterproof_binding=changed, expected_counter_receipt=value["counterproof_receipt"])

    def test_expiry_equality_and_future_proof_rejected(self):
        for instant in (R.P.utc(self.proof["valid_until"]), R.P.utc(self.proof["verified_at"]) - timedelta(seconds=1)):
            with self.subTest(instant=instant), self.assertRaises(R.P.PublicityError):
                self.replay(now=instant)

    def test_final_clock_expiry_or_rollback_rejected(self):
        current = R.P.utc(self.proof["verified_at"]) + timedelta(seconds=1)
        for final in (R.P.utc(self.proof["valid_until"]), current - timedelta(microseconds=1)):
            with self.subTest(final=final), patch.object(R, "_clock", return_value=final), self.assertRaisesRegex(R.P.PublicityError, "clock"):
                self.replay(now=current)

    def test_changed_source_and_invalid_now_rejected(self):
        for instant in (False, 0, "2026-09-08", R.P._clock().replace(tzinfo=None)):
            with self.subTest(instant=instant), self.assertRaises(R.P.PublicityError):
                self.replay(now=instant)
        self.corrupt(self.harness.media, {"not": "original fixture"})
        with self.assertRaises(R.P.PublicityError):
            self.replay()

    def test_v1_counterproof_not_promoted(self):
        value = deepcopy(self.proof)
        value["version"] = "phase6-av-publicity-v1"
        changed = self.corrupt(self.proof_path, value)
        from jsonschema import ValidationError
        with self.assertRaises(ValidationError):
            self.replay(counterproof_binding=changed)

    def test_rehashed_missing_or_reordered_samples_do_not_pass(self):
        target = self.root / "output/scan/receipt.json"
        original = R.P.document(target.read_bytes())
        for operation in ("missing", "reordered"):
            with self.subTest(operation=operation):
                receipt = deepcopy(original)
                if operation == "missing":
                    receipt["samples"].pop()
                    receipt["sample_count"] -= 1
                else:
                    receipt["samples"] = list(reversed(receipt["samples"]))
                receipt_pin = self.corrupt(target, receipt)
                proof = deepcopy(self.proof)
                proof["source_receipt"] = receipt_pin
                proof_pin = self.corrupt(self.proof_path, proof)
                with self.assertRaisesRegex(R.P.PublicityError, "sample coverage"):
                    self.replay(counterproof_binding=proof_pin, expected_source_receipt=receipt_pin)

    def test_final_source_drift_is_detected(self):
        original = R._Reader.recheck
        source_bytes = self.harness.media.read_bytes()
        self.addCleanup(self.harness.media.write_bytes, source_bytes)
        def drift(reader):
            self.harness.media.write_bytes(b"EXPLICIT_FIXTURE_SOURCE_CHANGED_DURING_REPLAY")
            return original(reader)
        with patch.object(R._Reader, "recheck", drift), self.assertRaises(R.P.PublicityError):
            self.replay()

    def test_returned_timeline_buffer_must_match_the_external_pin(self):
        original = R.P.reopen
        def substitute(root, item, **kwargs):
            raw = original(root, item, **kwargs)
            return b'{"render_spans":[]}' if item == self.base["expected_timeline"] else raw
        with patch.object(R.P, "reopen", substitute), self.assertRaisesRegex(R.P.PublicityError, "returned replay buffer"):
            self.replay()

    def test_journal_semantics_use_authenticated_returned_buffer(self):
        original = R.P.reopen
        def substitute(root, item, **kwargs):
            raw = original(root, item, **kwargs)
            return b'{}' if Path(item["path"]).name == "decode-intent.json" else raw
        with patch.object(R.P, "reopen", substitute), self.assertRaisesRegex(R.P.PublicityError, "returned replay buffer"):
            self.replay()

    def test_final_recheck_authenticates_returned_bytes_too(self):
        reader = R._Reader(self.root)
        reader.doc(self.base["expected_timeline"])
        with patch.object(R.P, "reopen", return_value=b'{"render_spans":[]}'), self.assertRaisesRegex(R.P.PublicityError, "returned replay buffer"):
            reader.recheck()


if __name__ == "__main__":
    unittest.main()
