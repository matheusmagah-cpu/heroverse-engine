from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from hero_engine.observatory.format_path_provenance import validate_market_source


ROOT = Path(__file__).resolve().parents[1]
REAL_RUN = ROOT / "output/observatory/phase3/phase3-2026-09-02-catalog-v2"
COLLECTOR = {"name": "yt-dlp", "version": "2026.08.19", "mode": "PUBLIC_METADATA_NO_MEDIA"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class FormatPathProvenanceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.operation = "fixture-market-run"
        self.cutoff = "2026-09-02T15:06:24-03:00"
        self.channel_id = "chn-fixture"
        self.channel_uri = "https://www.youtube.com/@fixture"
        self.video_id = "video123"
        self.scope = {
            "phase": 3,
            "run_id": self.operation,
            "channels": [{
                "channel_id": self.channel_id,
                "handle": "@fixture",
                "name": "Fixture",
                "role": "MARKET_REFERENCE",
                "source_uri": self.channel_uri,
                "max_videos": 4,
            }],
            "public_tabs": ["videos", "shorts"],
            "limits_apply_per_tab": True,
            "media_download": False,
            "external_spend": False,
            "final_model": False,
        }
        instant = "2026-09-02T18:06:24+00:00"
        common = {
            "schema_version": "1.0.0",
            "operation_id": self.operation,
            "collection_status": "COMPLETE",
            "captured_at": instant,
            "collector": dict(COLLECTOR),
            "evidence_class": "OBSERVED",
            "unavailable_metrics": ["RPM"],
            "error": None,
        }
        channel = {
            **common,
            "snapshot_id": "snap-" + "1" * 24,
            "channel_id": self.channel_id,
            "entity_type": "CHANNEL",
            "entity_id": self.channel_id,
            "source_uri": self.channel_uri,
            "payload": {
                "handle_requested": "@fixture",
                "channel_id_public": "UCfixture",
                "catalog_role": "MARKET_REFERENCE",
            },
        }
        video = {
            **common,
            "snapshot_id": "snap-" + "2" * 24,
            "channel_id": self.channel_id,
            "entity_type": "VIDEO",
            "entity_id": self.video_id,
            "source_uri": f"https://www.youtube.com/watch?v={self.video_id}",
            "payload": {
                "video_id": self.video_id,
                "webpage_url": f"https://www.youtube.com/watch?v={self.video_id}",
                "channel_id_public": "UCfixture",
                "catalog_role": "MARKET_REFERENCE",
            },
        }
        self.bundle = {
            "schema_version": "1.0.0",
            "operation_id": self.operation,
            "captured_at": self.cutoff,
            "snapshots": [channel, video],
        }

    def write_run(self) -> tuple[dict, dict]:
        folder = self.root / "output/observatory/phase3" / self.operation
        folder.mkdir(parents=True, exist_ok=True)
        source = folder / "public_snapshots.json"
        scope = folder / "scope.json"
        source.write_text(json.dumps(self.bundle, ensure_ascii=False), encoding="utf-8")
        scope.write_text(json.dumps(self.scope, ensure_ascii=False), encoding="utf-8")
        entries = []
        for path in (source, scope):
            entries.append({
                "artifact": path.relative_to(self.root).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha(path),
            })
        manifest = folder / "integrity_manifest.json"
        manifest.write_text(json.dumps({
            "schema_version": "1.0.0",
            "algorithm": "SHA-256",
            "item_count": len(entries),
            "total_size_bytes": sum(item["size_bytes"] for item in entries),
            "entries": entries,
        }), encoding="utf-8")
        source_binding = {"path": source.relative_to(self.root).as_posix(), "sha256": sha(source)}
        contract = {
            "evidence_mode": "LIVE",
            "operation_id": self.operation,
            "collector": dict(COLLECTOR),
            "integrity_manifest": {
                "path": manifest.relative_to(self.root).as_posix(),
                "sha256": sha(manifest),
            },
        }
        return source_binding, contract

    def validate(self) -> dict:
        source, contract = self.write_run()
        return validate_market_source(self.root, source, self.bundle, contract)

    def test_real_frozen_manifest_source_scope_and_collector_pass(self) -> None:
        source_path = REAL_RUN / "public_snapshots.json"
        manifest_path = REAL_RUN / "integrity_manifest.json"
        bundle = json.loads(source_path.read_text(encoding="utf-8"))
        result = validate_market_source(
            ROOT,
            {"path": source_path.relative_to(ROOT).as_posix(), "sha256": sha(source_path)},
            bundle,
            {
                "evidence_mode": "LIVE",
                "operation_id": "phase3-2026-09-02-catalog-v2",
                "collector": dict(COLLECTOR),
                "integrity_manifest": {
                    "path": manifest_path.relative_to(ROOT).as_posix(),
                    "sha256": "ceaa961d5e81191bf3f72aaf1a5bef758dd7f76c41bc11898cdc04182823e23c",
                },
            },
        )
        self.assertEqual("VERIFIED_LIVE", result["status"])
        self.assertEqual(7, result["channel_count"])
        self.assertEqual(123, result["video_count"])
        self.assertEqual("e4902fe5d88f5a991f0edec73031812a9ef0fa2de042bc83dfc3e17f97d2e231", result["source"]["sha256"])
        self.assertEqual("e4a54b80ebbc6e20d7794f813a8f3192ffc8a321b98708ed18aaa1e90afa2a19", result["scope"]["sha256"])

    def test_fixture_is_explicitly_not_live(self) -> None:
        source, _ = self.write_run()
        result = validate_market_source(self.root, source, self.bundle, {
            "evidence_mode": "FIXTURE",
            "operation_id": self.operation,
            "collector": dict(COLLECTOR),
            "integrity_manifest": None,
        })
        self.assertEqual("FIXTURE_NOT_LIVE", result["status"])
        self.assertIsNone(result["manifest"])
        self.assertIsNone(result["scope"])

    def test_argument_cannot_diverge_from_bound_source(self) -> None:
        source, contract = self.write_run()
        supplied = copy.deepcopy(self.bundle)
        supplied["snapshots"][1]["entity_id"] = "other"
        with self.assertRaisesRegex(ValueError, "supplied snapshots diverge"):
            validate_market_source(self.root, source, supplied, contract)

    def test_manifest_entry_size_or_hash_tamper_blocks(self) -> None:
        source, contract = self.write_run()
        manifest = self.root / contract["integrity_manifest"]["path"]
        document = json.loads(manifest.read_text(encoding="utf-8"))
        source_entry = next(item for item in document["entries"] if item["artifact"] == source["path"])
        source_entry["size_bytes"] += 1
        document["total_size_bytes"] += 1
        manifest.write_text(json.dumps(document), encoding="utf-8")
        contract["integrity_manifest"]["sha256"] = sha(manifest)
        with self.assertRaisesRegex(ValueError, "source entry does not match"):
            validate_market_source(self.root, source, self.bundle, contract)

    def test_duplicate_manifest_artifact_blocks(self) -> None:
        source, contract = self.write_run()
        manifest = self.root / contract["integrity_manifest"]["path"]
        document = json.loads(manifest.read_text(encoding="utf-8"))
        document["entries"].append(copy.deepcopy(document["entries"][0]))
        document["item_count"] += 1
        document["total_size_bytes"] += document["entries"][0]["size_bytes"]
        manifest.write_text(json.dumps(document), encoding="utf-8")
        contract["integrity_manifest"]["sha256"] = sha(manifest)
        with self.assertRaisesRegex(ValueError, "duplicate artifact"):
            validate_market_source(self.root, source, self.bundle, contract)

    def test_collector_tamper_blocks_even_when_rehashed(self) -> None:
        self.bundle["snapshots"][1]["collector"]["version"] = "other"
        source, contract = self.write_run()
        with self.assertRaisesRegex(ValueError, "collector diverges"):
            validate_market_source(self.root, source, self.bundle, contract)

    def test_scope_role_tamper_blocks_even_when_manifest_is_rebuilt(self) -> None:
        self.scope["channels"][0]["role"] = "FORMAT_REFERENCE"
        source, contract = self.write_run()
        with self.assertRaisesRegex(ValueError, "CHANNEL role diverges"):
            validate_market_source(self.root, source, self.bundle, contract)

    def test_channel_uri_or_internal_identity_tamper_blocks(self) -> None:
        for field, value, message in (
            ("source_uri", "https://www.youtube.com/@other", "source URI diverges"),
            ("entity_id", "chn-other", "internal channel identity diverges"),
        ):
            with self.subTest(field=field):
                original = self.bundle["snapshots"][0][field]
                self.bundle["snapshots"][0][field] = value
                source, contract = self.write_run()
                with self.assertRaisesRegex(ValueError, message):
                    validate_market_source(self.root, source, self.bundle, contract)
                self.bundle["snapshots"][0][field] = original

    def test_video_watch_uri_and_payload_id_tamper_block(self) -> None:
        for target, field, value, message in (
            (self.bundle["snapshots"][1], "source_uri", "https://www.youtube.com/watch?v=other", "watch URI/video identity diverges"),
            (self.bundle["snapshots"][1]["payload"], "video_id", "other", "payload video identity diverges"),
            (self.bundle["snapshots"][1]["payload"], "webpage_url", "https://example.com/watch?v=video123", "HTTPS YouTube host"),
        ):
            with self.subTest(field=field):
                original = target[field]
                target[field] = value
                source, contract = self.write_run()
                with self.assertRaisesRegex(ValueError, message):
                    validate_market_source(self.root, source, self.bundle, contract)
                target[field] = original

    def test_operation_and_cutoff_tamper_block(self) -> None:
        for field, value, message in (
            ("operation_id", "other", "operation_id diverges"),
            ("captured_at", "2026-09-02T18:06:25Z", "cutoff diverges"),
        ):
            with self.subTest(field=field):
                original = self.bundle["snapshots"][1][field]
                self.bundle["snapshots"][1][field] = value
                source, contract = self.write_run()
                with self.assertRaisesRegex(ValueError, message):
                    validate_market_source(self.root, source, self.bundle, contract)
                self.bundle["snapshots"][1][field] = original

    def test_live_requires_same_run_manifest_and_fixture_rejects_one(self) -> None:
        source, contract = self.write_run()
        contract["evidence_mode"] = "FIXTURE"
        with self.assertRaisesRegex(ValueError, "must not carry"):
            validate_market_source(self.root, source, self.bundle, contract)
        contract["evidence_mode"] = "LIVE"
        contract["integrity_manifest"] = None
        with self.assertRaisesRegex(ValueError, "requires"):
            validate_market_source(self.root, source, self.bundle, contract)

    def test_source_path_escape_and_hash_change_block(self) -> None:
        source, contract = self.write_run()
        escaped = dict(source, path="../public_snapshots.json")
        with self.assertRaisesRegex(ValueError, "confined"):
            validate_market_source(self.root, escaped, self.bundle, contract)
        path = self.root / source["path"]
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "binding changed"):
            validate_market_source(self.root, source, self.bundle, contract)


if __name__ == "__main__":
    unittest.main()
