from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from hero_engine.phase6_asset_residency import (
    run_phase6_asset_residency_audit,
    validate_phase6_rights_evidence,
    verify_phase6_asset_residency,
)


ROOT = Path(__file__).resolve().parents[1]


class Phase6AssetResidencyTests(unittest.TestCase):
    @staticmethod
    def _root(folder: str, *, corrupt: bool = False) -> Path:
        root = Path(folder)
        schema = root / "schemas/phase6_asset_residency_audit.schema.json"
        schema.parent.mkdir(parents=True)
        schema.write_bytes((ROOT / "schemas/phase6_asset_residency_audit.schema.json").read_bytes())
        (root / "schemas/phase6_rights_evidence.schema.json").write_bytes(
            (ROOT / "schemas/phase6_rights_evidence.schema.json").read_bytes()
        )
        assets = []
        for index in range(12):
            asset_id = f"asset-test-{index:02d}"
            media = root / "assets" / f"{asset_id}.webm"
            media.parent.mkdir(parents=True, exist_ok=True)
            content = f"media-{index}".encode()
            media.write_bytes(content)
            evidence = root / "rights" / f"{asset_id}.json"
            evidence.parent.mkdir(parents=True, exist_ok=True)
            source_page = f"https://commons.wikimedia.org/wiki/File:{asset_id}.webm"
            evidence.write_text(json.dumps({
                "schema_version": "1.0.0", "asset_id": asset_id,
                "semantic_role": "fixture", "search_query": "fixture video filetype:video",
                "verified_at": "2026-09-05T12:00:00Z",
                "source_api": "https://commons.wikimedia.org/w/api.php",
                "source_page": source_page,
                "raw_selected_metadata": {
                    "page_id": index + 1, "title": f"File:{asset_id}.webm",
                    "download_url": f"https://upload.wikimedia.org/wikipedia/commons/{asset_id}.webm",
                    "description_url": source_page, "width": 1920, "height": 1080,
                    "duration_seconds": 8, "size_bytes": len(content), "mime": "video/webm",
                    "commons_sha1": hashlib.sha1(content).hexdigest(), "description": "fixture",
                    "creator": "fixture", "credit": "fixture", "license_short": "CC BY 4.0",
                    "license_version": "CC BY 4.0", "license_url": "https://creativecommons.org/licenses/by/4.0",
                    "usage_terms": "Creative Commons Attribution 4.0", "attribution_required": True,
                    "rights_status": "CC_COMMERCIAL", "restrictions": None,
                },
                "decision": "AUTO_ELIGIBLE_BY_VERIFIED_LICENSE",
                "decision_basis": "Fixture reproduces the complete commercial Commons evidence contract.",
            }), encoding="utf-8")
            expected = hashlib.sha256(content).hexdigest()
            if corrupt and index == 0:
                expected = "0" * 64
            assets.append({
                "asset_id": asset_id, "uri": str(media), "content_hash": f"sha256:{expected}",
                "source": source_page, "license": "CC BY 4.0", "license_version": "CC BY 4.0",
                "rights_status": "CC_COMMERCIAL", "rights_evidence_uri": str(evidence),
                "rights_decision": "AUTO_ELIGIBLE_BY_VERIFIED_LICENSE",
                "production_eligible": True, "commercial_use": True, "content_quality_gate": "PASS",
                "safe_ranges": [{"start_ms": 0, "end_ms": 8000}],
            })
        manifest = root / "output/production/phase6/shared-assets/asset_manifest.json"
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text(json.dumps({"library_id": "phase6-heroverse-rights-library-v1", "assets": assets}), encoding="utf-8")
        return root

    @staticmethod
    def _probe(*_args, **_kwargs):
        return SimpleNamespace(returncode=0, stdout=json.dumps({"format": {"duration": "8.000"}}))

    def test_complete_local_pool_is_hash_rights_and_decode_verified(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            self.assertEqual("PASS", result["status"])
            self.assertEqual(12, result["verified_asset_count"])
            self.assertEqual([], result["blocked_asset_ids"])
            self.assertTrue(result["selection_authorized"])
            latest = root / "output/operations/phase6/capacity/asset-library-residency.json"
            immutable = root / "output/operations/phase6/capacity/asset-library-residency-receipts" / f"{result['audit_id']}.json"
            self.assertEqual("1.2.0", result["schema_version"])
            first_binding = result["assets"][0]["rights_byte_binding"]
            self.assertEqual("COMMONS_PERMANENT", first_binding["evidence_class"])
            self.assertEqual("PASS", first_binding["sha1_status"])
            self.assertEqual("PASS", first_binding["size_status"])
            self.assertEqual("PASS", first_binding["duration_status"])
            self.assertEqual(50, first_binding["duration_tolerance_ms"])
            self.assertEqual(0, first_binding["duration_delta_ms"])
            self.assertEqual(latest.read_bytes(), immutable.read_bytes())
            identity = verify_phase6_asset_residency(root, recheck_media=True)
            self.assertEqual(result["audit_id"], identity["audit_id"])
            self.assertEqual(12, len(identity["verified_asset_ids"]))

    def test_hash_mismatch_blocks_pool_selection(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder, corrupt=True)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            self.assertEqual("BLOCKED", result["status"])
            self.assertEqual(11, result["verified_asset_count"])
            self.assertEqual(["asset-test-00"], result["blocked_asset_ids"])
            self.assertFalse(result["selection_authorized"])

    def test_bound_receipt_rejects_asset_changed_after_audit(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            receipt = root / "output/operations/phase6/capacity/asset-library-residency-receipts" / f"{result['audit_id']}.json"
            identity = verify_phase6_asset_residency(root, receipt_path=receipt, expected_audit_id=result["audit_id"])
            Path(result["assets"][0]["path"]).write_bytes(b"changed-after-audit")
            with self.assertRaisesRegex(PermissionError, "changed after residency audit"):
                verify_phase6_asset_residency(
                    root,
                    receipt_path=identity["receipt_path"],
                    expected_sha256=identity["sha256"],
                    expected_audit_id=identity["audit_id"],
                    required_asset_ids=[result["assets"][0]["asset_id"]],
                )

    @staticmethod
    def _mutate_first_commons_metadata(root: Path, field: str, value: object) -> None:
        manifest = json.loads((root / "output/production/phase6/shared-assets/asset_manifest.json").read_text(encoding="utf-8"))
        evidence_path = Path(manifest["assets"][0]["rights_evidence_uri"])
        evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
        evidence["raw_selected_metadata"][field] = value
        evidence_path.write_text(json.dumps(evidence), encoding="utf-8")

    def test_commons_sha1_mismatch_fails_rights_and_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder)
            self._mutate_first_commons_metadata(root, "commons_sha1", "0" * 40)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            blocked = next(item for item in result["assets"] if item["asset_id"] == "asset-test-00")
            self.assertEqual("FAIL", blocked["rights_evidence_status"])
            self.assertEqual("FAIL", blocked["rights_byte_binding"]["sha1_status"])
            self.assertEqual("BLOCKED", result["status"])
            self.assertFalse(result["selection_authorized"])

    def test_commons_size_mismatch_fails_rights_and_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder)
            self._mutate_first_commons_metadata(root, "size_bytes", 999_999)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            blocked = next(item for item in result["assets"] if item["asset_id"] == "asset-test-00")
            self.assertEqual("FAIL", blocked["rights_evidence_status"])
            self.assertEqual("FAIL", blocked["rights_byte_binding"]["size_status"])
            self.assertEqual("BLOCKED", result["status"])
            self.assertFalse(result["selection_authorized"])

    def test_commons_duration_mismatch_fails_rights_and_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._root(folder)
            self._mutate_first_commons_metadata(root, "duration_seconds", 8.2)
            result = run_phase6_asset_residency_audit(root, command_runner=self._probe)
            blocked = next(item for item in result["assets"] if item["asset_id"] == "asset-test-00")
            binding = blocked["rights_byte_binding"]
            self.assertEqual("FAIL", blocked["rights_evidence_status"])
            self.assertEqual("FAIL", binding["duration_status"])
            self.assertEqual(200, binding["duration_delta_ms"])
            self.assertEqual(50, binding["duration_tolerance_ms"])
            self.assertEqual("BLOCKED", result["status"])
            self.assertFalse(result["selection_authorized"])

    def test_temporary_permission_is_schema_bound_and_expiry_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            schema = root / "schemas/phase6_rights_evidence.schema.json"
            schema.parent.mkdir(parents=True)
            schema.write_bytes((ROOT / "schemas/phase6_rights_evidence.schema.json").read_bytes())
            media = root / "asset.webm"
            media.write_bytes(b"temporarily-licensed-media")
            digest = "sha256:" + hashlib.sha256(media.read_bytes()).hexdigest()
            asset = {
                "asset_id": "asset-temporary", "source": "https://example.test/licence/123",
                "content_hash": digest, "rights_status": "LICENSED_COMMERCIAL",
                "rights_decision": "TEMPORARY_PERMISSION_APPROVED",
                "commercial_use": True, "production_eligible": True,
            }
            evidence = {
                "schema_version": "1.0.0", "asset_id": "asset-temporary",
                "evidence_class": "TEMPORARY_PERMISSION",
                "source_url": "https://example.test/licence/123", "media_hash": digest,
                "commercial_use": True, "rights_status": "LICENSED_COMMERCIAL",
                "grantor": "Fixture rights holder", "granted_at": "2025-01-01T00:00:00Z",
                "expires_at": "2025-02-01T00:00:00Z", "terms": "Commercial reuse during the stated term.",
                "decision": "TEMPORARY_PERMISSION_APPROVED", "verified_at": "2025-01-01T00:00:00Z",
            }
            with self.assertRaisesRegex(ValueError, "expired"):
                validate_phase6_rights_evidence(root, asset, evidence, media_path=media)
            del evidence["expires_at"]
            with self.assertRaises(Exception):
                validate_phase6_rights_evidence(root, asset, evidence, media_path=media)


if __name__ == "__main__":
    unittest.main()
