import copy
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageChops
from hero_engine.continuity import build_visual_continuity_bible
from hero_engine.procedural_infographics_phase5 import (
    compile_audio_static_composition, rasterize_audio_static_composition, _svg, SPECS)

ROOT = Path(__file__).resolve().parents[1]


class AudioStaticCompositionTests(unittest.TestCase):
    def setUp(self):
        self.pack = json.loads((ROOT / 'config/format_packs/fp-narrated-reflection-static-v1.json').read_text())
        model = json.loads((ROOT / 'output/modeling/phase4/channel-model-v1/channel_model.json').read_text())
        self.bible = build_visual_continuity_bible(channel_model=model, format_pack=self.pack,
            asset_manifest={'assets': []}, created_at='2026-10-05T00:00:00Z')
        self.font = Path(r'C:\Windows\Fonts\arialbd.ttf')
        base = ROOT / 'output/runtime/gestor-central/maintenance-runs/audio-static-composition-20261005'
        self.temp = tempfile.TemporaryDirectory(dir=base)
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name) / 'still.png'

    def compile(self, title='One Faithful Step Under Pressure'):
        return compile_audio_static_composition(title=title, bible=self.bible,
            format_pack=self.pack, font=self.font)

    def test_real_raster_measured_copy_palette_and_bounds(self):
        layout = self.compile()
        result = rasterize_audio_static_composition(layout, self.output)
        row = layout['texts'][0]
        self.assertTrue(row['copy_preserved'])
        self.assertGreaterEqual(row['font_size'], 54)
        self.assertTrue(row['safe_area_pass'])
        left, top, right, bottom = result['raster_bounds']
        self.assertGreaterEqual(left, row['bounds']['left'])
        self.assertGreaterEqual(top, row['bounds']['top'])
        self.assertLessEqual(right, row['bounds']['right'])
        self.assertLessEqual(bottom, row['bounds']['bottom'])
        with Image.open(self.output) as image:
            self.assertEqual(image.size, (1920, 1080))
            self.assertEqual(image.getpixel((0, 0)), (16, 24, 32))
            self.assertEqual(image.getpixel((180, 334)), (228, 199, 122))
            crop = image.crop((180, 390, 1740, 630))
            ink = ImageChops.difference(crop, Image.new('RGB', crop.size, (16, 24, 32))).getbbox()
            self.assertIsNotNone(ink)
            self.assertEqual([ink[0] + 180, ink[1] + 390, ink[2] + 180, ink[3] + 390],
                             result['raster_bounds'])
        self.assertFalse(result['publication_authorized'])

    def test_deterministic_and_no_input_mutation(self):
        before = copy.deepcopy((self.pack, self.bible))
        self.assertEqual(self.compile(), self.compile())
        self.assertEqual(before, (self.pack, self.bible))

    def test_tampered_layout_rejected_before_output(self):
        layout = self.compile()
        layout['texts'][0]['render_text'] = 'false replacement'
        with self.assertRaises(PermissionError):
            rasterize_audio_static_composition(layout, self.output)
        self.assertFalse(self.output.exists())

    def test_wrong_palette_and_minimum_blocked(self):
        for change in ('palette', 'minimum'):
            with self.subTest(change=change):
                original = copy.deepcopy(self.bible)
                if change == 'palette': self.bible['palette']['role_map']['text'] = '#FFFFFF'
                else: self.bible['typography']['minimum_sizes']['1920x1080'] = 30
                with self.assertRaises(ValueError): self.compile()
                self.bible = original

    def test_unfit_copy_is_not_shrunk_or_truncated(self):
        with self.assertRaises(ValueError): self.compile('W' * 80)
        self.assertFalse(self.output.exists())

    def test_exclusive_output_and_legacy_template_unchanged(self):
        legacy = _svg(SPECS[0])
        layout = self.compile()
        rasterize_audio_static_composition(layout, self.output)
        raw = self.output.read_bytes()
        with self.assertRaises(FileExistsError):
            rasterize_audio_static_composition(layout, self.output)
        self.assertEqual(self.output.read_bytes(), raw)
        self.assertEqual(_svg(SPECS[0]), legacy)


if __name__ == '__main__':
    unittest.main()
