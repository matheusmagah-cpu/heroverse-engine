import copy
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator
from hero_engine.creative_direction import choose_format_pack, load_format_packs
from hero_engine.continuity import build_visual_continuity_bible

ROOT = Path(__file__).resolve().parents[1]


def read(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8-sig"))


class AudioFormatSelectionTests(unittest.TestCase):
    def setUp(self):
        self.packs = load_format_packs(ROOT / "config/format_packs", ROOT / "schemas/format_pack.schema.json")
        self.audio = next(p for p in self.packs if p["format_pack_id"] == "fp-narrated-reflection-static")
        self.model = read("output/modeling/phase4/channel-model-v1/channel_model.json")
        self.command = read("output/production/phase5/pilot-001/central_command.creative_direction.json")
        self.brief = copy.deepcopy(read("output/production/phase5/pilot-001/editorial_brief.json"))
        self.brief["package"]["topic"] = "Christian reflection under everyday pressure"

    def choose(self, purpose="PROTOTYPE", packs=None):
        return choose_format_pack(command=self.command, policy_decision={"decision": "ALLOW"},
            channel_model=self.model, brief=self.brief, packs=packs or [self.audio],
            purpose=purpose, budget_envelope_id="isolated-audio-test",
            quality_profile="DRAFT" if purpose == "PROTOTYPE" else "STANDARD",
            created_at="2026-10-05T00:00:00Z")

    def test_versioned_pack_and_pipeline_validate_without_production_authority(self):
        pipeline = read("config/macro_pipelines/pipeline-audio-static-longform-v1.json")
        Draft202012Validator(read("schemas/macro_pipeline.schema.json")).validate(pipeline)
        self.assertEqual(self.audio["specification"]["primary_pipeline_id"], pipeline["pipeline_id"])
        self.assertEqual(pipeline["supported_format_pack_ids"], [self.audio["format_pack_id"]])
        self.assertEqual(self.audio["capability_status"], "SPECIFIED")
        self.assertFalse(self.audio["production_allowed"])
        self.assertFalse(pipeline["parameters"]["publication_allowed"])
        self.assertEqual(self.audio["specification"]["estimated_cost"]["external_max"], 0)

    def test_actual_selector_uses_audio_hypothesis_not_cinematic_fallback(self):
        value = self.choose()
        self.assertEqual(value["decision"], "SELECT")
        self.assertEqual(value["selected_format_pack"]["format_pack_id"], self.audio["format_pack_id"])
        self.assertEqual(value["hypothesis"]["statement"], self.audio["specification"]["description"])
        self.assertNotIn("cinematic B-roll sequence", value["hypothesis"]["statement"])
        Draft202012Validator(read("schemas/creative_direction_decision.schema.json")).validate(value)

    def test_specification_cannot_be_consumed_as_production_pass(self):
        result = self.choose("PRODUCTION")
        self.assertEqual(result["decision"], "BLOCK_NO_ELIGIBLE_PACK")
        self.assertIsNone(result["selected_format_pack"])

    def test_legacy_pack_selection_and_hypothesis_unchanged(self):
        legacy = next(p for p in self.packs if p["format_pack_id"] == "fp-broll-cinematic-narration")
        result = self.choose(packs=[legacy])
        self.assertEqual(result["selected_format_pack"]["format_pack_id"], legacy["format_pack_id"])
        self.assertEqual(result["hypothesis"]["statement"],
            "A function-assigned cinematic B-roll sequence will communicate the prayer-to-obedience mechanism without inheriting a reference work's identity.")

    def test_policy_block_precedes_selection(self):
        with self.assertRaises(PermissionError):
            choose_format_pack(command=self.command, policy_decision={"decision": "BLOCK"},
                channel_model=self.model, brief=self.brief, packs=[self.audio], purpose="PROTOTYPE",
                budget_envelope_id="isolated-audio-test", quality_profile="DRAFT")

    def test_real_continuity_consumer_respects_static_contract_and_rights(self):
        assets = {"assets": [
            {"asset_id": name, "uri": uri, "content_hash": "sha256:" + "a" * 64,
             "rights_evidence_uri": "isolated-rights.json", "semantic_role": "identity",
             "production_eligible": eligible, "rights_status": rights}
            for name, uri, eligible, rights in [
                ("owned", "owned.png", True, "OWNED"),
                ("clip", "legacy.webm", True, "OWNED"),
                ("foreign", "foreign.png", True, "CC_COMMERCIAL"),
                ("pending", "pending.png", False, "OWNED")]]}
        bible = build_visual_continuity_bible(channel_model=self.model,
            format_pack=self.audio, asset_manifest=assets, created_at="2026-10-05T00:00:00Z")
        Draft202012Validator(read("schemas/visual_continuity_bible.schema.json")).validate(bible)
        self.assertEqual([r["reference_id"] for r in bible["reference_assets"]], ["owned"])
        self.assertEqual(bible["palette"]["role_map"]["text"], "#F3EDE0")
        self.assertFalse(bible["environments"])
        self.assertFalse(bible["characters"])
        self.assertNotIn("maximum_duplicate_frame_ratio", bible["divergence_policy"]["thresholds"])
        self.assertEqual(bible["divergence_policy"]["failure_action"], "BLOCK_RENDER_OR_PUBLICATION")
        self.assertEqual(bible["typography"]["minimum_sizes"]["1920x1080"], 54)

    def test_legacy_continuity_keeps_cinematic_checks(self):
        pack = next(p for p in self.packs if p["format_pack_id"] == "fp-broll-cinematic-narration")
        bible = build_visual_continuity_bible(channel_model=self.model, format_pack=pack,
            asset_manifest={"assets": []}, created_at="2026-10-05T00:00:00Z")
        self.assertEqual(len(bible["environments"]), 2)
        self.assertEqual(bible["palette"]["role_map"]["text"], "#E8EDF2")
        self.assertEqual(bible["divergence_policy"]["thresholds"]["maximum_duplicate_frame_ratio"], 0.01)
