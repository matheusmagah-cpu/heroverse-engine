"""Native planning/render entry; codec and OS observations simulated at boundaries."""
import copy
import hashlib
import json
import shutil
import tempfile
import unittest
import wave
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image
from jsonschema import Draft202012Validator
from hero_engine.atomic_io import atomic_write_utf8
from hero_engine.continuity import build_visual_continuity_bible
from hero_engine.creative_direction import choose_format_pack, load_format_packs
from hero_engine.render_phase5 import render_phase5_pilot
from hero_engine.take_planner import build_take_plan
from hero_engine.production_capacity import ResourceWait
from hero_engine.cli import build_parser

ROOT = Path(__file__).resolve().parents[1]
RECORD = ROOT / "output/runtime/gestor-central/maintenance-runs/audio-static-producer-20261005"
TIME = "2026-10-05T13:00:00Z"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    atomic_write_utf8(path, json.dumps(value, ensure_ascii=False, indent=2))


def digest(path):
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


class AudioStaticProducerTests(unittest.TestCase):
    def setUp(self):
        RECORD.mkdir(parents=True, exist_ok=True)
        temporary = tempfile.TemporaryDirectory(dir=RECORD, prefix="owned-test-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.relative = Path("output/production/audio-pilot")
        self.package = self.root / self.relative
        self.package.mkdir(parents=True)
        (self.root / "schemas").mkdir()
        for name in ["render_manifest", "phase6_rights_evidence"]:
            shutil.copy2(ROOT / f"schemas/{name}.schema.json", self.root / f"schemas/{name}.schema.json")
        pipeline = "config/macro_pipelines/pipeline-audio-static-longform-v1.json"
        (self.root / pipeline).parent.mkdir(parents=True)
        shutil.copy2(ROOT / pipeline, self.root / pipeline)
        self.image = self.package / "original.png"
        Image.new("RGB", (1920, 1080), "#101820").save(self.image)
        self.vector = self.package / "original.svg"
        atomic_write_utf8(self.vector, '<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080"><rect width="1920" height="1080" fill="#101820"/></svg>')
        self.rights = self.package / "rights.json"
        self.evidence = {"schema_version": "1.0.0", "asset_id": "owned-static-test",
            "asset_type": "PROJECT_OWNED_PROCEDURAL_STATIC", "source_svg": str(self.vector),
            "source_svg_hash": digest(self.vector), "raster": str(self.image), "raster_hash": digest(self.image),
            "provider": "isolated-test-original-shapes", "ownership_basis": "Original test-owned procedural shapes; no third-party image or voice.",
            "platform_disclosure": {"required": False, "reason": "Synthetic fixture only, never a publication approval."},
            "decision": "RESPONSIBLE_REVIEW_APPROVED", "limitations": ["Synthetic rights fixture only"], "verified_at": TIME}
        write(self.rights, self.evidence)
        self.asset = {"asset_id": "owned-static-test", "uri": str(self.image), "content_hash": digest(self.image),
            "media_type": "GENERATED_IMAGE", "semantic_role": "identity", "rights_status": "OWNED",
            "rights_evidence_uri": str(self.rights), "production_eligible": True, "commercial_use": True,
            "rights_decision": "RESPONSIBLE_REVIEW_APPROVED", "source": str(self.vector),
            "creator_or_holder": "isolated test", "license": "owned", "used_ranges": []}
        self.manifest = {"assets": [self.asset]}
        self.pack = next(p for p in load_format_packs(ROOT / "config/format_packs", ROOT / "schemas/format_pack.schema.json")
                         if p["format_pack_id"] == "fp-narrated-reflection-static")
        model = read(ROOT / "output/modeling/phase4/channel-model-v1/channel_model.json")
        command = read(ROOT / "output/production/phase5/pilot-001/central_command.creative_direction.json")
        brief = read(ROOT / "output/production/phase5/pilot-001/editorial_brief.json")
        self.decision = choose_format_pack(command=command, policy_decision={"decision": "ALLOW"},
            channel_model=model, brief=brief, packs=[self.pack], purpose="PROTOTYPE", budget_envelope_id="isolated-test",
            quality_profile="DRAFT", created_at=TIME)
        self.bible = build_visual_continuity_bible(channel_model=model, format_pack=self.pack,
            asset_manifest=self.manifest, created_at=TIME)
        self.beats = [{"beat_id": f"b{i}", "start_ms": start, "end_ms": end,
            "narrative_function": "reflect", "information": "Choose a concrete response", "intended_emotion": "clarity",
            "semantic_role": "identity", "action": "audible narrative progresses", "narration": "test original narration",
            "retention_job": "explain the audible promise"} for i, (start, end) in enumerate([(0, 1000), (1000, 3000), (3000, 8000)])]
        self.windows = [{"window": name, "start_ms": start, "end_ms": end, "promise_function": "audible promise",
            "evidence_refs": ["isolated-narrative-test"]} for name, start, end in [("0_1S", 0, 1000), ("1_3S", 1000, 3000), ("3_8S", 3000, 8000)]]
        self.plan, self.updated = self.plan_inputs()
        write(self.package / "take_plan.json", self.plan)
        write(self.package / "channel_style_bible.json", self.bible)
        write(self.package / "asset_manifest.json", self.updated)
        self.wav = self.package / "original.wav"
        with wave.open(str(self.wav), "wb") as wav:
            wav.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
            wav.writeframes(b"\x00\x00" * 24000)
        self.voice = {"voice_render_id": "isolated-voice", "status": "COMPLETE", "hook_timing_gate": "PASS",
            "takes": [{"take_id": row["take_id"], "path": str(self.wav), "content_hash": digest(self.wav),
                       "text": row["narration"], "duration_ms": 1000, "fits_timeline_slot": True, "clipping": False}
                      for row in self.plan["takes"]]}
        write(self.package / "audio/voice_render_manifest.json", self.voice)
        self.commands = []
        self.mutate_after_first = False

    def plan_inputs(self):
        return build_take_plan(channel_id="heroverse74", video_id="isolated-audio-pilot",
            creative_decision=self.decision, style_bible=self.bible, format_pack=self.pack,
            asset_manifest=self.manifest, narrative_beats=self.beats, hook_windows=self.windows, created_at=TIME)

    def fake_process(self, command, **kwargs):
        self.commands.append(command)
        Path(command[-1]).write_bytes(b"SIMULATED_CODEC_OUTPUT_NOT_MEDIA_APPROVAL")
        if self.mutate_after_first and len(self.commands) == 1:
            self.vector.write_bytes(self.vector.read_bytes() + b" ")
        return SimpleNamespace(returncode=0)

    def fake_probe(self, path):
        duration = 1.0 if Path(path).suffix == ".wav" else 8.0
        if Path(path).parent.name == "video_segments":
            row = next(t for t in self.plan["takes"] if t["take_id"] == Path(path).stem)
            duration = (row["end_ms"] - row["start_ms"]) / 1000
        return {"format": {"duration": str(duration)}, "streams": [
            {"codec_type": "video", "codec_name": "h264", "width": 1920, "height": 1080, "r_frame_rate": "30/1"},
            {"codec_type": "audio", "codec_name": "aac"}]}

    def render(self):
        sample = {"available_ram_bytes": 8 * 1024**3, "total_ram_bytes": 16 * 1024**3,
                  "output_free_bytes": 30 * 1024**3, "temp_free_bytes": 30 * 1024**3,
                  "logical_cpus": 4, "cpu_load_percent": 10.0}
        with patch("hero_engine.production_capacity.measure_local_resources", return_value=sample), \
             patch("hero_engine.production_capacity.subprocess.run", side_effect=self.fake_process), \
             patch("hero_engine.render_phase5._probe", side_effect=self.fake_probe):
            return render_phase5_pilot(self.root, package_relative=self.relative, created_at=TIME)

    def test_native_plan_is_static_and_does_not_invent_source_time(self):
        Draft202012Validator(read(ROOT / "schemas/take_plan.schema.json")).validate(self.plan)
        self.assertEqual(self.manifest, self.updated)
        self.assertEqual(len({t["asset_origin"] for t in self.plan["takes"]}), 1)
        self.assertTrue(all("#still=sha256:" in t["asset_origin"] and "#t=" not in t["asset_origin"] for t in self.plan["takes"]))
        self.assertTrue(all(t["transition_out"] is None and t["environment"] is None for t in self.plan["takes"]))

    def test_measured_audio_unit_is_not_cut_to_satisfy_legacy_scene_ceiling(self):
        self.beats[-1]["end_ms"] = 16000
        plan, _ = self.plan_inputs()
        self.assertEqual(plan["takes"][-1]["end_ms"], 16000)
        self.assertIn("#still=", plan["takes"][-1]["asset_origin"])
        from hero_engine.take_planner import _validate_beats
        with self.assertRaises(ValueError): _validate_beats(self.beats)

    def test_public_native_entry_compiles_static_video_and_reuses_voice(self):
        result = self.render()
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(result["publication_approved"])
        video = [cmd for cmd in self.commands if "-loop" in cmd]
        self.assertEqual(len(video), 3)
        self.assertTrue(all("-ss" not in cmd and "-qp" in cmd and cmd[cmd.index("-qp") + 1] == "1" for cmd in video))
        self.assertNotIn("anoisesrc", " ".join(self.commands[-1]))
        self.assertEqual(digest(self.wav), self.voice["takes"][0]["content_hash"])
        self.assertTrue((self.package / "render-input-bindings.json").is_file())
        self.assertTrue((self.package / "resource-observation.json").is_file())

    def test_source_tamper_blocks_before_any_codec(self):
        self.image.write_bytes(b"tampered")
        with self.assertRaises(PermissionError): self.render()
        self.assertFalse(self.commands)

    def test_current_owned_asset_without_legacy_attribution_fields_closes_native_receipt(self):
        # The current owned-static producer supplies authenticated uri/rights,
        # not the borrowed-footage source/creator/license fields of the pilot.
        current = copy.deepcopy(self.updated)
        for asset in current['assets']:
            for name in ('source', 'creator_or_holder', 'license', 'attribution'):
                asset.pop(name, None)
        write(self.package / 'asset_manifest.json', current)
        result = self.render()
        self.assertEqual(result['status'], 'COMPLETE')
        self.assertFalse(result['publication_approved'])
        attribution = (self.package / 'attribution.txt').read_text(encoding='utf-8')
        self.assertIn(str(self.image), attribution)
        self.assertIn(str(self.rights), attribution)
        self.assertIn('Rights status: OWNED', attribution)

    def test_vector_provenance_tamper_blocks_before_any_codec(self):
        self.vector.write_bytes(b"tampered")
        with self.assertRaises(ValueError): self.render()
        self.assertFalse(self.commands)

    def test_invalid_voice_binding_blocks_before_any_codec(self):
        self.voice["takes"][0]["text"] = "different spoken promise"
        write(self.package / "audio/voice_render_manifest.json", self.voice)
        with self.assertRaises(PermissionError): self.render()
        self.assertFalse(self.commands)

    def test_input_changed_after_first_command_blocks_receipt_and_next_command(self):
        self.mutate_after_first = True
        with self.assertRaises(PermissionError): self.render()
        self.assertEqual(len(self.commands), 1)
        self.assertFalse((self.package / "render_manifest.json").exists())

    def test_pause_blocks_public_entry_before_codec(self):
        atomic_write_utf8(self.root / "output/runtime/gestor-central/PAUSE", "owner pause")
        with self.assertRaises(ResourceWait): self.render()
        self.assertFalse(self.commands)
        self.assertFalse((self.package / "render_work").exists())

    def test_existing_work_is_not_overwritten(self):
        (self.package / "render_work").mkdir()
        with self.assertRaises(FileExistsError): self.render()
        self.assertFalse(self.commands)

    def test_foreign_rights_or_two_compositions_cannot_enter_static_plan(self):
        self.manifest["assets"][0]["rights_status"] = "CC_COMMERCIAL"
        with self.assertRaises(ValueError): self.plan_inputs()
        self.manifest["assets"][0]["rights_status"] = "OWNED"
        self.manifest["assets"].append(copy.deepcopy(self.asset))
        with self.assertRaises(ValueError): self.plan_inputs()

    def test_per_beat_overlay_or_cut_cannot_hide_a_static_hold(self):
        self.beats[0]["on_screen_text"] = "changing overlay"
        with self.assertRaises(ValueError): self.plan_inputs()

    def test_external_content_in_owned_source_is_rejected(self):
        atomic_write_utf8(self.vector, '<svg xmlns="http://www.w3.org/2000/svg"><image href="https://foreign/image.png"/></svg>')
        self.evidence["source_svg_hash"] = digest(self.vector)
        write(self.rights, self.evidence)
        with self.assertRaises(ValueError): self.render()
        self.assertFalse(self.commands)

    def test_existing_cli_dispatches_native_static_producer_not_another_renderer(self):
        args = build_parser().parse_args(["render", "--pilot-package", self.relative.as_posix()])
        sample = {"available_ram_bytes": 8 * 1024**3, "total_ram_bytes": 16 * 1024**3,
                  "output_free_bytes": 30 * 1024**3, "temp_free_bytes": 30 * 1024**3,
                  "logical_cpus": 4, "cpu_load_percent": 10.0}
        with patch("hero_engine.cli.ROOT", self.root), \
             patch("hero_engine.cli._print_json") as output, \
             patch("hero_engine.production_capacity.measure_local_resources", return_value=sample), \
             patch("hero_engine.production_capacity.subprocess.run", side_effect=self.fake_process), \
             patch("hero_engine.render_phase5._probe", side_effect=self.fake_probe):
            args.func(args)
        self.assertEqual(output.call_args.args[0]["status"], "COMPLETE")
        self.assertFalse(output.call_args.args[0]["publication_approved"])
        self.assertTrue(any("-loop" in command for command in self.commands))

    def test_cli_keeps_legacy_edl_dispatch_and_rejects_mixed_inputs(self):
        args = build_parser().parse_args(["render", "legacy-edl.json"])
        with patch("hero_engine.cli.render_edl", return_value="legacy.mp4") as render, patch("builtins.print"):
            args.func(args)
        render.assert_called_once_with(Path("legacy-edl.json"), {})
        args = build_parser().parse_args(["render", "legacy-edl.json", "--pilot-package", self.relative.as_posix()])
        with self.assertRaises(ValueError): args.func(args)
