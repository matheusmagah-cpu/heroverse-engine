"""Real cohort/model/recipe/queue/PCM readers; network and voice engine simulated.

No fixture establishes audience demand, vocal quality, copyright clearance,
release authority or operational adoption. Temporary native preparation proves
the connection, not a public production.
"""
import copy
import hashlib
import json
import shutil
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from hero_engine import phase6_audio_production as production
from hero_engine.creative_direction import build_christian_rest_music_recipe, read_christian_rest_music_inputs
from hero_engine.queue_phase6 import TransactionalQueue
from tests import test_rest_editorial_native_inputs as native
from tests import test_observatory_format_cohorts as cohort
from tests import test_audio_static_manager_dispatch as dispatch


def sha(path): return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value),encoding='utf-8')


class CurrentAudioResearchProductionTests(unittest.TestCase):
    def setUp(self):
        self.owner=native.RestEditorialNativeInputTests('test_native_producer_public_reader_and_source_qa_are_composed')
        self.addCleanup(self.owner.doCleanups);self.owner.setUp()
        self.root=self.owner.root
        self.source=self.root/'output/market/fixture/snapshots.json'
        self.rows=[]
        for channel in range(3):
            cid=['UCTdc_zl40D9wa0_LH9yaGZA','UCsDKqJJISkMyvjFowNT_Sdg','UC0JWi59lgJMCapfqr6_P15g'][channel]
            self.rows.append(cohort._channel(cid,cid,'FORMAT_REFERENCE'))
            for number in range(4):
                row=cohort._video(cid,cid,'FORMAT_REFERENCE',f'fixture{channel}{number:03}',
                    age_days=10,view_count=(1000 if number==0 else 100-number))
                row['payload']['title']='Quiet prayer and worry' if number in (0,3) else 'Other original music'
                self.rows.append(row)
        self.bundle={'schema_version':'1.0.0','operation_id':cohort.OPERATION,
                     'captured_at':cohort.CUTOFF,'snapshots':self.rows}
        write(self.source,self.bundle)
        self.baseline={'video_id':'owned-current','publication_receipt_hash':'sha256:'+'a'*64,
                       'topic':None,'editorial_angle':'Rest without avoidance'}
        self.diagnosis=self.owner.package/'intelligence/diagnoses/exact.json'
        self.protocol=self.owner.package/'intelligence/experiments/exact.json'
        write(self.diagnosis,{'status':'DIAGNOSED'})
        write(self.protocol,{'status':'READY_TO_PREREGISTER','treatment':{'variable':'TOPIC_ANGLE'}})
        write(self.owner.package/'youtube-publication-receipt.json',
              {'video_id':'owned-current','channel_id':production.CHANNEL_ID,'status':'COMPLETE_PUBLIC'})
        shutil.copy2(native.ROOT/'config/current_audio_research.json',self._config())
        self.selection={'package_relative':self.owner.relative,
            'current_bindings':{'music_inputs':{'recipe':self.owner.recipe_binding}},
            'expected_release_hash':'sha256:'+'b'*64,'snapshot_reference':'fixture-owned-snapshot'}
        auth=patch('hero_engine.phase6_intelligence.materialize_current',
                   return_value=(self.source,self.diagnosis,self.protocol))
        self.auth=auth.start();self.addCleanup(auth.stop)
        def collect(operation,channel,captured):
            index=['UCTdc_zl40D9wa0_LH9yaGZA','UCsDKqJJISkMyvjFowNT_Sdg','UC0JWi59lgJMCapfqr6_P15g'].index(channel.channel_id)
            rows=copy.deepcopy(self.rows[index*5:(index+1)*5])
            for row in rows:
                row['operation_id']=operation;row['captured_at']=captured
                # Preserve a ten-day comparable window in synthetic network data.
                from datetime import datetime,timedelta
                if row['entity_type']=='VIDEO':
                    row['payload']['timestamp']=(datetime.fromisoformat(captured)-timedelta(days=10,hours=1)).timestamp()
            return rows
        collector=patch('hero_engine.observatory.collectors.collect_channel',side_effect=collect)
        self.collector=collector.start();self.addCleanup(collector.stop)

    def _config(self):
        p=self.root/'config/current_audio_research.json';p.parent.mkdir(parents=True,exist_ok=True);return p
    def model(self): return production.build_current_audio_research(self.root,self.source,baseline=self.baseline)
    def call(self): return production.run_current_audio_research_production(self.root,**self.selection)
    def model_binding(self):
        p=self.source.parent/'model.json';write(p,self.model());return {'path':p.relative_to(self.root).as_posix(),'sha256':sha(p)}

    def test_model_keeps_comparable_support_counterevidence_and_unknowns(self):
        value=self.model()
        self.assertEqual(value['topic'],'PRAYER_AND_CONTROL')
        self.assertEqual(len(value['supporting_channels']),3)
        self.assertEqual(len(value['favorable']),3);self.assertEqual(len(value['contrary']),3)
        self.assertTrue(all(not a for a in value['authority'].values()))
        self.assertIn('RPM',' '.join(value['limitations']))

    def test_two_channels_do_not_become_a_pattern(self):
        self.bundle['snapshots']=self.rows[:10];write(self.source,self.bundle)
        with self.assertRaisesRegex(PermissionError,'INSUFFICIENT'):self.model()

    def test_redirected_or_foreign_channel_blocks_modeling(self):
        self.rows[0]['payload']['channel_id_public']='foreign'
        write(self.source,self.bundle)
        with self.assertRaisesRegex(PermissionError,'requested identity'):self.model()

    def test_recent_or_wrong_format_cannot_inflate_cohort(self):
        for row in self.rows:
            if row['entity_type']=='VIDEO':row['payload']['content_format']='SHORT'
        write(self.source,self.bundle)
        with self.assertRaises(PermissionError):self.model()

    def test_same_topic_cannot_be_a_new_treatment(self):
        self.baseline['topic']='PRAYER_AND_CONTROL'
        with self.assertRaisesRegex(PermissionError,'NO_NEW'):self.model()

    def test_reader_rejects_tampered_source_without_network(self):
        binding=self.model_binding();self.source.write_bytes(self.source.read_bytes()+b' ')
        with self.assertRaises(PermissionError):production.read_current_audio_research(self.root,binding)
        self.collector.assert_not_called()

    def test_rehashing_a_false_model_does_not_accept_it(self):
        binding=self.model_binding();p=self.root/binding['path'];value=json.loads(p.read_bytes())
        value['authority']['publication']=True;write(p,value);binding['sha256']=sha(p)
        with self.assertRaises(PermissionError):production.read_current_audio_research(self.root,binding)

    def test_research_anchor_must_be_confined(self):
        binding=self.model_binding();binding['path']='../foreign.json'
        with self.assertRaises(PermissionError):production.read_current_audio_research(self.root,binding)

    def test_recipe_native_reader_binds_original_text_and_research_bytes(self):
        binding=self.model_binding();model=production.read_current_audio_research(self.root,binding)
        recipe=build_christian_rest_music_recipe(duration_ms=180000,
            channel_model_hash=self.owner.recipe['channel_model_hash'],style_bible_hash=self.owner.recipe['style_bible_hash'],
            recipe_version='heroverse-christian-rest-editorial-v5',research={'binding':binding,'model':model})
        write(self.owner.recipe_path,recipe);pin={'path':str(self.owner.recipe_path),'sha256':sha(self.owner.recipe_path)}
        write((self.root/binding['path']).parent/'preregistration.json',{'research':binding,'recipe':pin,
            'variable':'TOPIC_ANGLE','protocol':self.protocol.relative_to(self.root).as_posix(),
            'protocol_hash':sha(self.protocol),'created_at':datetime.now(timezone.utc).isoformat()})
        result=read_christian_rest_music_inputs(self.root,package_relative=self.owner.relative,recipe_binding=pin)
        self.assertIn('Prayer is not a way',result['recipe']['editorial']['full_text'])
        recipe['editorial']['full_text']='copied';write(self.owner.recipe_path,recipe);pin['sha256']=sha(self.owner.recipe_path)
        with self.assertRaises(PermissionError):read_christian_rest_music_inputs(self.root,package_relative=self.owner.relative,recipe_binding=pin)

    def test_real_queue_model_recipe_and_native_audio_prepare_repeat_without_effect(self):
        first=self.call();self.assertEqual(first['status'],'PREPARED_AWAITING_NATIVE_QUALITY_AND_RIGHTS',first)
        self.assertEqual(self.collector.call_count,3);self.assertEqual(len(self.owner.engine.calls),1)
        package=self.root/first['package_relative']
        self.assertTrue((package/'audio/original-rest-music.wav').is_file())
        self.assertFalse((package/'video.mp4').exists());self.assertFalse((package/'youtube-publication-receipt.json').exists())
        self.assertFalse(first['render_authorized']);self.assertFalse(first['publication_authorized'])
        original=self.owner.recipe_path.read_bytes()
        self.collector.reset_mock()
        with patch('hero_engine.render_creative_v3_phase5.prepare_christian_rest_music',side_effect=AssertionError('duplicate')):
            again=self.call()
        self.assertEqual(again['source_binding'],first['source_binding']);self.collector.assert_not_called()
        self.assertEqual(self.owner.recipe_path.read_bytes(),original)
        jobs=TransactionalQueue(self.root).snapshot()['jobs'];self.assertEqual(len(jobs),1)
        self.assertEqual(jobs[0]['state'],'SUCCEEDED');self.assertEqual(jobs[0]['attempt_count'],1)

    def test_pause_blocks_before_owned_auth_network_or_queue(self):
        p=self.root/'output/runtime/gestor-central/PAUSE';p.parent.mkdir(parents=True);p.touch()
        self.assertEqual(self.call()['status'],'PAUSED');self.auth.assert_not_called();self.collector.assert_not_called()
        self.assertFalse((p.parent/'work_queue.db').exists())

    def test_missing_owned_observation_cannot_be_replaced_by_market(self):
        self.selection['snapshot_reference']=None
        self.assertEqual(self.call()['status'],'WAITING_FOR_CURRENT_OWNED_OBSERVATION');self.auth.assert_not_called()

    def test_unknown_baseline_and_other_variables_do_not_start_production(self):
        write(self.diagnosis,{'status':'WAITING'})
        self.assertEqual(self.call()['status'],'WAITING_FOR_ELIGIBLE_BASELINE')
        write(self.diagnosis,{'status':'DIAGNOSED'})
        write(self.protocol,{'status':'READY_TO_PREREGISTER','treatment':{'variable':'TITLE_THUMBNAIL_PROMISE'}})
        self.assertEqual(self.call()['status'],'WAITING_FOR_JUSTIFIED_TOPIC_CHANGE');self.collector.assert_not_called()

    def test_resource_wait_does_not_consume_attempt_or_query(self):
        with patch('hero_engine.production_capacity.measure_local_resources',return_value={'available_ram_bytes':1,'output_free_bytes':1}):
            self.assertEqual(self.call()['status'],'RESOURCE_WAIT')
        self.collector.assert_not_called()
        self.assertFalse((self.root/'output/runtime/gestor-central/work_queue.db').exists())

    def test_failed_research_cannot_loop_or_approve(self):
        self.collector.side_effect=ConnectionError('fixture network failure')
        first=self.call();self.assertEqual(first['status'],'BLOCKED_RESEARCHED_PREPARATION')
        self.assertIn('ConnectionError',first['cause']);self.assertEqual(self.collector.call_count,1)
        self.assertEqual(self.call()['status'],'BLOCKED_EXISTING_PREPARATION')
        self.assertEqual(self.collector.call_count,1);self.owner.voice_factory.assert_not_called()

    def test_active_exact_job_cannot_be_claimed_or_spawned_again(self):
        self.collector.side_effect=ConnectionError('preserve')
        self.call();queue=TransactionalQueue(self.root);job=queue.snapshot()['jobs'][0]
        # State changes are not simulated: claim a native pending sibling and
        # prove its live lease causes the next exact claim to return None.
        sibling=queue.enqueue(idempotency_key='fixture-concurrent',operation_id=job['operation_id'],
            channel_id=job['channel_id'],task_type=job['task_type'],payload=job['payload'],max_attempts=1)
        self.assertIsNotNone(queue.claim_job(sibling['job_id'],worker_id='fixture'))
        self.assertIsNone(queue.claim_job(sibling['job_id'],worker_id='second'))

    def test_native_recipe_keeps_old_versions_byte_identical(self):
        for version in ('heroverse-christian-rest-instrumental-v1','heroverse-christian-rest-editorial-v4'):
            before=build_christian_rest_music_recipe(duration_ms=180000,
                channel_model_hash=self.owner.recipe['channel_model_hash'],style_bible_hash=self.owner.recipe['style_bible_hash'],recipe_version=version)
            self.assertNotIn('research',before)
            with self.assertRaises(ValueError):build_christian_rest_music_recipe(duration_ms=180000,
                channel_model_hash=before['channel_model_hash'],style_bible_hash=before['style_bible_hash'],recipe_version=version,research={})

    def test_preregistration_tamper_blocks_before_voice(self):
        binding=self.model_binding()
        p=(self.root/binding['path']).parent/'preregistration.json'
        write(p,{'research':binding,'recipe':self.owner.recipe_binding,'variable':'NONE'})
        with self.assertRaises(PermissionError):
            production.read_audio_preregistration(self.root,binding,self.owner.recipe_binding)
        self.owner.voice_factory.assert_not_called()

    def test_current_proof_population_requires_the_new_consumer(self):
        from hero_engine.current_operational_application_proof import TEST_PREFIXES
        self.assertIn('tests.test_current_audio_research_production.',TEST_PREFIXES)

    def test_operational_proof_binds_exact_catalog_not_only_source_code(self):
        from hero_engine import current_operational_application_proof as proof
        from contextlib import ExitStack
        commit='output/runtime/gestor-central/maintenance-runs/task62-integrity-successor-proof-pathfix-20260916/commit-result.json'
        rollback='output/runtime/gestor-central/maintenance-runs/task58-forward-caption-and-integrity-20260916/integrity-successor-stage/rollback-preimage.json'
        write(self.root/commit,{'status':'COMMITTED_SUCCESSOR_VIEW_WHILE_PAUSED',
            'successor_sha256':'fixture-successor','historical_manifest_unchanged':True})
        write(self.root/rollback,{'fixture':'preimage'})
        write(self.root/proof.PACKAGE/proof.HISTORICAL_NAME,{'fixture':'immutable legacy'})
        with ExitStack() as scope:
            scope.enter_context(patch.object(proof,'read_current_integrity_successor',return_value={'successor_sha256':'fixture-successor'}))
            for name in ('active_bindings','compile_current_caption_intent','_visual_binding','current_production_input_contract'):
                scope.enter_context(patch.object(proof,name,return_value={'fixture':'outside tested catalog boundary'}))
            first=proof.current_operational_bindings(self.root)
            raw=self._config().read_bytes();self._config().write_bytes(raw+b' ')
            second=proof.current_operational_bindings(self.root)
        self.assertEqual(first['candidate'],second['candidate'])
        self.assertNotEqual(first['current_audio_research'],second['current_audio_research'])
        self.assertTrue(all(not v for v in first['authority'].values()))


class CurrentAudioManagerResearchDispatchTests(unittest.TestCase):
    def test_real_selected_loop_dispatches_research_only_after_authentic_owned_observer(self):
        from hero_engine import central_manager_phase5 as manager
        from contextlib import ExitStack
        class StopFixture(Exception):pass
        owner=dispatch.AudioStaticManagerDispatchTests('test_selected_real_loop_never_enters_legacy_phase6_lane')
        self.addCleanup(owner.doCleanups);owner.setUp()
        root=owner.root
        with ExitStack() as scope:
            for target in ('hero_engine.maintenance_protocol.publish_capability',
                           'hero_engine.maintenance_protocol.refresh_capability_token_binding',
                           'hero_engine.central_manager_phase5._start_review_console',
                           'hero_engine.central_manager_phase5._start_oauth_reconsent_watcher',
                           'hero_engine.central_manager_phase5.ensure_oauth_session_health',
                           'hero_engine.phase6_reporting.materialize',
                           'hero_engine.phase6_control_cycle.materialize',
                           'hero_engine.phase6_acceptance.materialize'):
                scope.enter_context(patch(target))
            # A default Mock reports a live watcher; that is a real containment
            # boundary, not the selected research lane under test.
            scope.enter_context(patch.object(manager,'_start_oauth_reconsent_watcher',return_value=None))
            scope.enter_context(patch('hero_engine.maintenance_protocol.maintenance_barrier',return_value=False))
            scope.enter_context(patch.object(manager,'run_cycle',return_value={'publication_status':'COMPLETE_PUBLIC'}))
            scope.enter_context(patch.object(manager,'run_phase6_observer_if_due',
                return_value={'status':'NOT_DUE','latest_snapshot':'immutable-owned-snapshot'}))
            research=scope.enter_context(patch.object(production,'run_current_audio_research_production',
                return_value={'status':'WAITING_FOR_ELIGIBLE_BASELINE'}))
            cinema=scope.enter_context(patch.object(manager,'run_phase6_treatment_executor',side_effect=AssertionError('legacy lane')))
            scope.enter_context(patch.object(manager.time,'sleep',side_effect=StopFixture))
            write(root/owner.owner.relative/'release_gate.json',{'fixture':'not a live release'})
            with self.assertRaises(StopFixture):manager.loop(root,60,**owner.selection)
            research.assert_called_once()
            self.assertEqual(research.call_args.kwargs['snapshot_reference'],'immutable-owned-snapshot')
            self.assertEqual(research.call_args.kwargs['package_relative'],owner.owner.relative)
            cinema.assert_not_called()
        status=json.loads((root/owner.owner.relative/'intelligence/next-production-status.json').read_bytes())
        self.assertEqual(status['status'],'WAITING_FOR_ELIGIBLE_BASELINE')


if __name__=='__main__':unittest.main()
