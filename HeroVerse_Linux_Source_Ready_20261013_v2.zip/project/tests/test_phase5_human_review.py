from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.phase5_human_review import (
    ATTESTATION,
    AUTOMATIC_QA,
    HUMAN_REVIEW_DIR,
    OAUTH_READINESS,
    PACK_PATH,
    PUBLICATION_PACKAGE,
    QUALIFICATION,
    REGISTRY_PATH,
    THUMBNAILS,
    apply_limited_transition,
    build_review_draft,
    evaluate_submission,
    prepare_review,
)


ROOT = Path(__file__).resolve().parents[1]
FIXED_TIME = "2026-09-04T00:00:00Z"


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


class Phase5HumanReviewTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for schema_name in (
            "phase5_human_review_submission.schema.json",
            "phase5_human_review_evaluation.schema.json",
            "format_pack_transition_receipt.schema.json",
            "format_pack.schema.json",
        ):
            target = self.root / "schemas" / schema_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / "schemas" / schema_name).read_bytes())

        candidate = self.root / "candidate.mp4"
        candidate.write_bytes(b"frozen-standard-candidate-fixture")
        candidate_hash = hashlib.sha256(candidate.read_bytes()).hexdigest()
        qualification = {
            "qualification_id": "qualification-fixture",
            "video_id": "phase5-pilot-001-creative-v3",
            "automatic_profile_status": "PASS",
            "candidate": {
                "path": str(candidate),
                "content_hash": f"sha256:{candidate_hash}",
                "size_bytes": candidate.stat().st_size,
                "duration_ms": 238700,
            },
            "replay": {"equivalence_pass": True},
            "technical_checks": [{"status": "PASS"} for _ in range(11)],
            "created_at": "2026-09-03T23:00:00Z",
        }
        write_json(self.root / QUALIFICATION, qualification)
        write_json(self.root / AUTOMATIC_QA, {"gates": [{"status": "PASS"}]})
        write_json(self.root / PUBLICATION_PACKAGE, {"video": {"sha256": candidate_hash}})
        write_json(self.root / THUMBNAILS, {"candidates": [
            {"candidate_id": item, "automated_status": "PASS"} for item in ("A", "B", "C")
        ]})
        write_json(self.root / OAUTH_READINESS, {"continuous_operation_ready": False})
        (self.root / PACK_PATH).parent.mkdir(parents=True, exist_ok=True)
        (self.root / PACK_PATH).write_bytes((ROOT / PACK_PATH).read_bytes())
        (self.root / REGISTRY_PATH).parent.mkdir(parents=True, exist_ok=True)
        (self.root / REGISTRY_PATH).write_bytes((ROOT / REGISTRY_PATH).read_bytes())
        pack = json.loads((self.root / PACK_PATH).read_text(encoding="utf-8"))
        pack["capability_status"] = "PROTOTYPED"
        pack["production_allowed"] = False
        pack["limitation_contract"] = None
        write_json(self.root / PACK_PATH, pack)
        registry = json.loads((self.root / REGISTRY_PATH).read_text(encoding="utf-8"))
        registry["format_pack_overrides"][0]["capability_status"] = "PROTOTYPED"
        registry["capability_counts"]["PROTOTYPED"] = 1
        registry["capability_counts"]["LIMITED"] = 0
        write_json(self.root / REGISTRY_PATH, registry)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def final_submission(self) -> dict:
        submission = build_review_draft(self.root, created_at=FIXED_TIME)
        submission["submission_status"] = "FINAL"
        submission["reviewer"] = {
            "reviewer_id": "owner-matheus-fixture",
            "reviewer_name": "Matheus",
            "reviewer_role": "OWNER_HUMAN",
            "independent_from_generator": True,
            "conflict_disclosure": "Owner review; not the automatic generator.",
            "reviewed_at": FIXED_TIME,
        }
        submission["review_protocol"] = {
            "full_duration_reviewed": True,
            "sequential_review": True,
            "playback_speed": 1.0,
            "audio_monitoring": True,
            "caption_track_checked": True,
            "small_screen_legibility_checked": True,
            "thumbnail_review_blinded": True,
        }
        for item in submission["windows"] + submission["human_gates"]:
            item["status"] = "PASS"
            item["evidence_note"] = "Reviewed on the frozen fixture; no defect observed."
        submission["thumbnail_selection"] = "B"
        submission["overall_verdict"] = "PASS"
        submission["attestation"] = {"attested": True, "statement": ATTESTATION}
        submission["submitted_at"] = FIXED_TIME
        return submission

    def test_prepare_is_hash_pinned_and_does_not_overwrite_final(self) -> None:
        result = prepare_review(self.root, created_at=FIXED_TIME)
        self.assertEqual("PREPARED", result["status"])
        draft = json.loads((self.root / result["draft"]).read_text(encoding="utf-8"))
        schema = json.loads((self.root / "schemas/phase5_human_review_submission.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(schema).validate(draft)
        self.assertEqual("DRAFT", draft["submission_status"])
        self.assertEqual(9, len(draft["windows"]))
        self.assertEqual(12, len(draft["human_gates"]))
        (self.root / HUMAN_REVIEW_DIR / "review_submission.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(FileExistsError):
            prepare_review(self.root, created_at=FIXED_TIME)

    def test_draft_is_fail_closed_and_cannot_promote(self) -> None:
        draft = build_review_draft(self.root, created_at=FIXED_TIME)
        before = (self.root / PACK_PATH).read_bytes()
        evaluation = evaluate_submission(draft, self.root, created_at=FIXED_TIME)
        self.assertEqual("PENDING_HUMAN_INPUT", evaluation["decision"])
        self.assertFalse(evaluation["publication_guard"]["upload_permitted"])
        self.assertIn("FINAL_INDEPENDENT_HUMAN_REVIEW_SUBMISSION_MISSING", evaluation["publication_guard"]["blockers"])
        with self.assertRaises(PermissionError):
            apply_limited_transition(draft, self.root, created_at=FIXED_TIME)
        self.assertEqual(before, (self.root / PACK_PATH).read_bytes())

    def test_final_pass_must_match_exact_artifact_and_protocol(self) -> None:
        submission = self.final_submission()
        submission["artifact"]["sha256"] = "0" * 64
        evaluation = evaluate_submission(submission, self.root, created_at=FIXED_TIME)
        self.assertEqual("NEEDS_REVIEW", evaluation["decision"])
        self.assertFalse(evaluation["artifact_verification"]["all_pass"])
        self.assertFalse(evaluation["format_pack_transition"]["eligible"])

    def test_a_human_failure_is_preserved_and_blocks_transition(self) -> None:
        submission = self.final_submission()
        submission["human_gates"][0]["status"] = "FAIL"
        submission["human_gates"][0]["defects"] = [{
            "start_ms": 0,
            "end_ms": 1000,
            "defect": "The opening claim is not clear.",
            "expected_correction": "Replace the first spoken and visual beat.",
        }]
        submission["overall_verdict"] = "FAIL"
        evaluation = evaluate_submission(submission, self.root, created_at=FIXED_TIME)
        self.assertEqual("REJECTED_BY_HUMAN_REVIEW", evaluation["decision"])
        self.assertEqual(1, evaluation["review_summary"]["defect_count"])
        with self.assertRaises(PermissionError):
            apply_limited_transition(submission, self.root, created_at=FIXED_TIME)

    def test_complete_pass_promotes_only_to_limited_and_keeps_upload_blocked(self) -> None:
        submission = self.final_submission()
        final_path = self.root / HUMAN_REVIEW_DIR / "review_submission.json"
        write_json(final_path, submission)
        preflight = evaluate_submission(submission, self.root, created_at=FIXED_TIME)
        self.assertEqual("READY_FOR_LIMITED_PROMOTION", preflight["decision"])
        self.assertTrue(preflight["artifact_verification"]["all_pass"])
        self.assertTrue(preflight["protocol_verification"]["all_pass"])

        evaluation = apply_limited_transition(submission, self.root, created_at=FIXED_TIME)
        self.assertEqual("HUMAN_GATE_PASS_FORMAT_PACK_LIMITED", evaluation["decision"])
        self.assertTrue(evaluation["format_pack_transition"]["applied"])
        self.assertFalse(evaluation["publication_guard"]["upload_permitted"])
        self.assertIn("OAUTH_NOT_DURABLE_FOR_CONTINUOUS_OPERATION", evaluation["publication_guard"]["blockers"])

        pack = json.loads((self.root / PACK_PATH).read_text(encoding="utf-8"))
        registry = json.loads((self.root / REGISTRY_PATH).read_text(encoding="utf-8"))
        self.assertEqual("LIMITED", pack["capability_status"])
        self.assertTrue(pack["production_allowed"])
        self.assertIn(submission["submission_id"], pack["evidence"]["human_review_ids"])
        self.assertEqual(1, registry["capability_counts"]["LIMITED"])
        self.assertEqual(0, registry["capability_counts"]["PROTOTYPED"])
        self.assertEqual(291, sum(registry["capability_counts"].values()))
        receipt_path = self.root / evaluation["format_pack_transition"]["transition_receipt"]
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        receipt_schema = json.loads((self.root / "schemas/format_pack_transition_receipt.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(receipt_schema).validate(receipt)
        self.assertEqual(hashlib.sha256(final_path.read_bytes()).hexdigest(), receipt["human_review"]["sha256"])
        archive_path = self.root / receipt["rollback"]["archive_path"]
        self.assertEqual(receipt["rollback"]["archive_sha256"], hashlib.sha256(archive_path.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
