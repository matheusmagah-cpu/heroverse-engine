"""Network-free Commons retry/defer tests; payload bytes are synthetic, not media."""
import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import requests

from hero_engine import asset_library_phase5 as library


NOW = datetime(2026, 9, 7, 16, 0, 0, tzinfo=timezone.utc)


class FrozenClock(datetime):
    @classmethod
    def now(cls, tz=None):
        return NOW if tz else NOW.replace(tzinfo=None)


class Response:
    def __init__(self, status=200, headers=None, *, payload=None, chunks=None):
        self.status_code = status
        self.headers = headers or {}
        self.payload = payload or {"query": {"pages": []}}
        self.chunks = [b"synthetic"] if chunks is None else chunks
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.closed = True

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)

    def json(self):
        return self.payload

    def iter_content(self, chunk_size):
        for chunk in self.chunks:
            if isinstance(chunk, BaseException):
                raise chunk
            yield chunk


class CommonsRetryTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.seen = []
        self.get = self.enterContext(patch.object(library.requests, "get", side_effect=AssertionError("NETWORK_FORBIDDEN")))
        self.sleep = self.enterContext(patch.object(library.time, "sleep", side_effect=self.assert_closed_before_wait))
        self.enterContext(patch.object(library, "datetime", FrozenClock))

    def assert_closed_before_wait(self, seconds):
        self.assertTrue(all(response.closed for response in self.seen))
        self.assertLessEqual(seconds, library.COMMONS_LOCAL_WAIT_BUDGET_SECONDS)

    def queue(self, *responses):
        iterator = iter(responses)

        def get(*args, **kwargs):
            value = next(iterator)
            if isinstance(value, BaseException):
                raise value
            self.seen.append(value)
            return value

        self.get.side_effect = get

    def invoke(self, route):
        if route == "SEARCH":
            return library.search_commons_videos("synthetic query")
        return library._download_commons_file(
            {"download_url": "https://upload.wikimedia.org/synthetic.webm", "size_bytes": 9},
            self.root / "synthetic.webm",
        )

    def reset_route(self):
        self.seen.clear()
        self.get.reset_mock()
        self.sleep.reset_mock()

    def test_retry_after_seconds_and_missing(self):
        self.assertEqual(library._commons_retry_after_seconds(" 120 ", None, NOW), 120)
        self.assertEqual(library._commons_retry_after_seconds("0", None, NOW), 0)
        self.assertIsNone(library._commons_retry_after_seconds(None, None, NOW))

    def test_retry_after_http_date_and_past(self):
        self.assertEqual(library._commons_retry_after_seconds("Mon, 07 Sep 2026 16:00:12 GMT", None, NOW), 12)
        self.assertEqual(library._commons_retry_after_seconds("Mon, 07 Sep 2026 15:59:00 GMT", None, NOW), 0)

    def test_server_date_prevents_ahead_local_clock_from_shortening_delay(self):
        self.assertEqual(library._commons_retry_after_seconds(
            "Mon, 07 Sep 2026 15:59:30 GMT", "Mon, 07 Sep 2026 15:59:00 GMT", NOW,
        ), 30)

    def test_malformed_optional_date_does_not_replace_local_clock(self):
        self.assertEqual(library._commons_retry_after_seconds(
            "Mon, 07 Sep 2026 16:00:12 GMT", "not a date", NOW,
        ), 12)

    def test_429_waits_at_least_server_seconds_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(429, {"Retry-After": "7"}), Response())
                self.invoke(route)
                self.assertEqual(self.get.call_count, 2)
                self.sleep.assert_called_once_with(7)
                self.assertTrue(all(item.closed for item in self.seen))

    def test_503_accepts_http_date_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(503, {"Retry-After": "Mon, 07 Sep 2026 16:00:12 GMT"}), Response())
                self.invoke(route)
                self.sleep.assert_called_once_with(12)
                self.assertEqual(self.get.call_count, 2)

    def test_long_server_delay_defers_without_early_retry_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(429, {"Retry-After": "120"}))
                with self.assertRaises(library.CommonsProviderDeferred) as caught:
                    self.invoke(route)
                self.assertEqual(caught.exception.details["reason"], "LOCAL_WAIT_BUDGET_EXCEEDED")
                self.assertEqual(caught.exception.details["retry_after_seconds"], 120)
                self.assertEqual(caught.exception.details["scope"], "CURRENT_BUILD_ONLY")
                self.assertFalse(caught.exception.details["provider_switched"])
                self.assertEqual(self.get.call_count, 1)
                self.sleep.assert_not_called()
                self.assertTrue(self.seen[0].closed)

    def test_long_date_defers_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(503, {"Retry-After": "Mon, 07 Sep 2026 16:01:00 GMT"}))
                with self.assertRaises(library.CommonsProviderDeferred) as caught:
                    self.invoke(route)
                self.assertEqual(caught.exception.details["retry_after_seconds"], 60)
                self.sleep.assert_not_called()

    def test_invalid_retry_after_fails_closed_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            for value in ("nonsense", "-1", "1.5", ""):
                with self.subTest(route=route, value=value):
                    self.reset_route()
                    self.queue(Response(429, {"Retry-After": value}))
                    with self.assertRaises(library.CommonsProviderDeferred) as caught:
                        self.invoke(route)
                    self.assertEqual(caught.exception.details["reason"], "INVALID_RETRY_AFTER")
                    self.assertEqual(self.get.call_count, 1)
                    self.sleep.assert_not_called()

    def test_exhausted_429_does_not_sleep_after_last_attempt_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(*(Response(429) for _ in range(4)))
                with self.assertRaises(library.CommonsProviderDeferred) as caught:
                    self.invoke(route)
                self.assertEqual(caught.exception.details["reason"], "ATTEMPTS_EXHAUSTED")
                self.assertEqual(self.get.call_count, 4)
                self.assertEqual([call.args[0] for call in self.sleep.call_args_list], [5, 10, 15])

    def test_cumulative_wait_budget_defers_before_third_wait_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(*(Response(503, {"Retry-After": "12"}) for _ in range(3)))
                with self.assertRaises(library.CommonsProviderDeferred) as caught:
                    self.invoke(route)
                self.assertEqual(caught.exception.details["local_waited_seconds"], 24)
                self.assertEqual(self.get.call_count, 3)
                self.assertEqual([call.args[0] for call in self.sleep.call_args_list], [12, 12])

    def test_transport_retries_are_bounded_without_terminal_sleep(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(*(requests.Timeout("synthetic") for _ in range(4)))
                with self.assertRaises(library.CommonsProviderDeferred):
                    self.invoke(route)
                self.assertEqual(self.get.call_count, 4)
                self.assertEqual([call.args[0] for call in self.sleep.call_args_list], [2, 4, 6])

    def test_400_is_not_retried_both_routes(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(400))
                with self.assertRaises(requests.HTTPError):
                    self.invoke(route)
                self.assertEqual(self.get.call_count, 1)
                self.assertTrue(self.seen[0].closed)
                self.sleep.assert_not_called()

    def test_request_cancellation_aborts_without_retry(self):
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(KeyboardInterrupt())
                with self.assertRaises(KeyboardInterrupt):
                    self.invoke(route)
                self.assertEqual(self.get.call_count, 1)
                self.sleep.assert_not_called()

    def test_wait_cancellation_aborts_with_response_already_closed(self):
        def cancel(seconds):
            self.assert_closed_before_wait(seconds)
            raise KeyboardInterrupt()

        self.sleep.side_effect = cancel
        for route in ("SEARCH", "DOWNLOAD"):
            with self.subTest(route=route):
                self.reset_route()
                self.queue(Response(429))
                with self.assertRaises(KeyboardInterrupt):
                    self.invoke(route)
                self.assertEqual(self.get.call_count, 1)

    def test_ordinary_wait_error_becomes_defer_not_next_query(self):
        self.sleep.side_effect = InterruptedError("synthetic interruption")
        self.queue(Response(429))
        manifest = library.build_and_download_asset_library(
            self.root, queries=[("one", "query one"), ("two", "query two")],
        )
        self.assertEqual(self.get.call_count, 1)
        details = json.loads(manifest["errors"][-1]["error"].split(":", 1)[1])
        self.assertEqual(details["reason"], "WAIT_INTERRUPTED")

    def test_stream_cancellation_closes_response_and_preserves_completed_file(self):
        destination = self.root / "synthetic.webm"
        destination.write_bytes(b"previous-completed")
        self.queue(Response(chunks=[b"partial", KeyboardInterrupt()]))
        with self.assertRaises(KeyboardInterrupt):
            self.invoke("DOWNLOAD")
        self.assertTrue(self.seen[0].closed)
        self.assertEqual(destination.read_bytes(), b"previous-completed")
        self.sleep.assert_not_called()

    def test_size_mismatch_is_bounded_and_does_not_replace_completed_file(self):
        destination = self.root / "synthetic.webm"
        destination.write_bytes(b"previous-completed")
        self.queue(*(Response(chunks=[b"x"]) for _ in range(4)))
        with self.assertRaises(library.CommonsProviderDeferred) as caught:
            self.invoke("DOWNLOAD")
        self.assertEqual(caught.exception.details["failure"], "SIZE_MISMATCH")
        self.assertEqual(destination.read_bytes(), b"previous-completed")
        self.assertEqual([call.args[0] for call in self.sleep.call_args_list], [2, 4, 6])

    def test_chunk_failure_recovers_without_promoting_partial_download(self):
        self.queue(Response(chunks=[b"part", requests.exceptions.ChunkedEncodingError("synthetic")]), Response())
        self.invoke("DOWNLOAD")
        self.assertEqual((self.root / "synthetic.webm").read_bytes(), b"synthetic")
        self.assertEqual(self.get.call_count, 2)
        self.sleep.assert_called_once_with(2)

    def previous_asset(self):
        media = self.root / "ready.webm"
        media.write_bytes(b"previous-completed-synthetic")
        evidence = self.root / "ready-evidence.json"
        evidence.write_bytes(b'{"fixture": "rights evidence retained, not a legal grant"}\n')
        asset = {
            "asset_id": "fixture-ready", "source": "https://commons.wikimedia.org/wiki/File:ready",
            "uri": str(media), "content_hash": "sha256:" + hashlib.sha256(media.read_bytes()).hexdigest(),
            "rights_evidence_uri": str(evidence), "rights_status": "FIXTURE_ONLY",
        }
        manifest = library._manifest_record([asset], [], 3)
        (self.root / "asset_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        return asset, media.read_bytes(), evidence.read_bytes()

    def test_search_defer_stops_whole_build_preserving_ready_asset_and_evidence(self):
        asset, media_before, evidence_before = self.previous_asset()
        self.queue(Response(429, {"Retry-After": "120"}))
        manifest = library.build_and_download_asset_library(
            self.root, max_assets=3, queries=[("one", "query one"), ("two", "query two")],
        )
        self.assertEqual(self.get.call_count, 1)
        self.assertEqual(manifest["assets"], [asset])
        self.assertEqual(manifest["status"], "PARTIAL")
        self.assertIn("PROVIDER_DEFERRED:", manifest["errors"][-1]["error"])
        self.assertEqual(Path(asset["uri"]).read_bytes(), media_before)
        self.assertEqual(Path(asset["rights_evidence_uri"]).read_bytes(), evidence_before)
        self.assertEqual(json.loads((self.root / "asset_manifest.json").read_text())["assets"], [asset])

    def test_download_defer_stops_next_query_and_asset(self):
        asset, media_before, evidence_before = self.previous_asset()
        candidate = {"page_id": 42, "title": "File:Synthetic.webm", "description_url": "https://commons.wikimedia.org/wiki/File:Synthetic.webm",
                     "download_url": "https://upload.wikimedia.org/Synthetic.webm", "size_bytes": 9}
        self.queue(Response(503, {"Retry-After": "60"}))
        with patch.object(library, "search_commons_videos", return_value=[candidate]) as search:
            manifest = library.build_and_download_asset_library(
                self.root, max_assets=3, queries=[("one", "query one"), ("two", "query two")],
            )
        search.assert_called_once_with("query one")
        self.assertEqual(self.get.call_count, 1)
        self.assertEqual(manifest["assets"], [asset])
        details = json.loads(manifest["errors"][-1]["error"].split(":", 1)[1])
        self.assertEqual(details["route"], "DOWNLOAD")
        self.assertEqual(Path(asset["uri"]).read_bytes(), media_before)
        self.assertEqual(Path(asset["rights_evidence_uri"]).read_bytes(), evidence_before)

    def test_non_retryable_search_error_can_continue_other_query(self):
        self.queue(Response(400), Response())
        manifest = library.build_and_download_asset_library(
            self.root, queries=[("one", "query one"), ("two", "query two")],
        )
        self.assertEqual(self.get.call_count, 2)
        self.assertIn("HTTPError", manifest["errors"][0]["error"])
        self.assertEqual(manifest["errors"][1]["error"], "NO_ELIGIBLE_RESULT")

    def test_defer_has_no_false_cross_process_or_cross_build_persistence(self):
        self.queue(Response(429, {"Retry-After": "120"}), Response())
        with self.assertRaises(library.CommonsProviderDeferred):
            self.invoke("SEARCH")
        self.assertEqual(self.invoke("SEARCH"), [])
        self.assertEqual(self.get.call_count, 2)


if __name__ == "__main__":
    unittest.main()
