from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
import copy
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from jsonschema import Draft202012Validator

from hero_engine.maintenance_protocol import (
    ACK_PATH,
    QUEUE_PATH,
    REQUEST_PATH,
    acknowledge_request,
    arm_recovery_window,
    build_validation_manifests,
    create_request,
    maintenance_barrier,
    oauth_refresh_due_at,
    oauth_source_change_pending,
    publish_capability,
    refresh_capability_token_binding,
    recovery_window_state,
    canonical_hash,
)
from hero_engine.phase6_maintenance_verification import verify_regression_evidence


ROOT = Path(__file__).resolve().parents[1]
REQUEST_ID = "maintenance-request-20260905T1200000000000Z-aaaaaaaa"


class DailyMaintenanceProtocolTests(unittest.TestCase):
    @staticmethod
    def _powershell_function(name: str) -> str:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        start = script.index(f"function {name} ")
        opening = script.index("{", start)
        depth = 0
        quote: str | None = None
        for index in range(opening, len(script)):
            char = script[index]
            if quote:
                if char == quote and script[index - 1] != "`":
                    quote = None
                continue
            if char in {"'", '"'}:
                quote = char
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return script[start:index + 1]
        raise AssertionError(f"PowerShell function {name} is unterminated")

    @staticmethod
    def _base(folder: str) -> Path:
        root = Path(folder)
        (root / "schemas").mkdir(parents=True)
        for name in (
            "central_manager_maintenance_request.schema.json",
            "central_manager_maintenance_ack.schema.json",
            "central_manager_maintenance_recovery_window.schema.json",
        ):
            (root / "schemas" / name).write_bytes((ROOT / "schemas" / name).read_bytes())
        runtime = root / "output/runtime/gestor-central"
        runtime.mkdir(parents=True)
        (runtime / "manager.pid").write_text("4242\n", encoding="utf-8")
        (runtime / "manager-lock.json").write_text(
            json.dumps({"state": "HELD", "holder_pid": 4242}), encoding="utf-8"
        )
        return root

    @staticmethod
    def _queue(root: Path, *, state: str, task_type: str, available_at: str) -> Path:
        path = root / QUEUE_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(path)
        try:
            connection.execute(
                """CREATE TABLE jobs (
                    job_id TEXT PRIMARY KEY,idempotency_key TEXT,operation_id TEXT,channel_id TEXT,
                    task_type TEXT,payload_json TEXT,state TEXT,attempt_count INTEGER,max_attempts INTEGER,
                    available_at TEXT,lease_owner TEXT,lease_until TEXT,checkpoint_json TEXT,last_error TEXT,
                    created_at TEXT,updated_at TEXT
                )"""
            )
            leased = state == "LEASED"
            connection.execute(
                "INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    "job-fixture", "key", "operation", "channel", task_type, "{}", state, 1, 3,
                    available_at, "worker" if leased else None, "2026-09-05T12:05:00Z" if leased else None,
                    "{}", None, "2026-09-05T11:00:00Z", "2026-09-05T11:00:00Z",
                ),
            )
            connection.commit()
        finally:
            connection.close()
        return path

    @staticmethod
    def _request(root: Path) -> None:
        create_request(
            root,
            request_id=REQUEST_ID,
            requester_pid=99,
            guard_seconds=1800,
            requested_at=datetime(2026, 9, 5, 12, 0, tzinfo=timezone.utc),
        )

    def test_zero_api_ready_ack_is_read_only_for_operational_state(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            queue = self._queue(
                root,
                state="PENDING",
                task_type="EVALUATE_PHASE6_VIDEO2_QUALITY",
                available_at="2026-09-06T12:00:00Z",
            )
            before = hashlib.sha256(queue.read_bytes()).hexdigest()
            self._request(root)
            ack = acknowledge_request(
                root,
                manager_pid=4242,
                now=datetime(2026, 9, 5, 12, 0, 1, tzinfo=timezone.utc),
            )
            self.assertIsNotNone(ack)
            self.assertEqual("READY_TO_STOP", ack["status"])
            self.assertTrue(ack["external_effect_boundary_closed"])
            self.assertEqual(before, hashlib.sha256(queue.read_bytes()).hexdigest())
            self.assertFalse((root / "output/operations/zero-cost/phase6-quota-ledger.sqlite3").exists())

    def test_any_active_lease_blocks_manager_stop(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            self._queue(
                root,
                state="LEASED",
                task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                available_at="2026-09-05T11:59:00Z",
            )
            self._request(root)
            ack = acknowledge_request(
                root,
                manager_pid=4242,
                now=datetime(2026, 9, 5, 12, 0, 1, tzinfo=timezone.utc),
            )
            self.assertEqual("DEFERRED", ack["status"])
            self.assertIn("ACTIVE_QUEUE_LEASE", ack["blockers"])
            self.assertEqual(["job-fixture"], ack["active_lease_job_ids"])

    def test_due_d1_protected_job_blocks_without_changing_due_time(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            queue = self._queue(
                root,
                state="RETRY_WAIT",
                task_type="OWNED_METRICS_CHECKPOINT",
                available_at="2026-09-05T12:15:00Z",
            )
            connection = sqlite3.connect(queue)
            try:
                before = connection.execute("SELECT state,attempt_count,available_at FROM jobs").fetchone()
            finally:
                connection.close()
            self._request(root)
            ack = acknowledge_request(
                root,
                manager_pid=4242,
                now=datetime(2026, 9, 5, 12, 0, 1, tzinfo=timezone.utc),
            )
            self.assertEqual("DEFERRED", ack["status"])
            self.assertIn("PROTECTED_JOB_DUE_DURING_MAINTENANCE", ack["blockers"])
            connection = sqlite3.connect(queue)
            try:
                after = connection.execute("SELECT state,attempt_count,available_at FROM jobs").fetchone()
            finally:
                connection.close()
            self.assertEqual(before, after)

    def test_incomplete_quota_reservation_blocks_external_effect_boundary(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            ledger = root / "output/operations/zero-cost/phase6-quota-ledger.sqlite3"
            ledger.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(ledger)
            try:
                connection.execute(
                    "CREATE TABLE general_quota_debits (debit_id TEXT PRIMARY KEY,state TEXT)"
                )
                connection.execute(
                    "INSERT INTO general_quota_debits VALUES (?,?)",
                    ("debit-incomplete", "RESERVED"),
                )
                connection.commit()
            finally:
                connection.close()
            before = hashlib.sha256(ledger.read_bytes()).hexdigest()
            self._request(root)
            ack = acknowledge_request(
                root,
                manager_pid=4242,
                now=datetime(2026, 9, 5, 12, 0, 1, tzinfo=timezone.utc),
            )
            self.assertEqual("DEFERRED", ack["status"])
            self.assertIn("INCOMPLETE_QUOTA_OR_EXTERNAL_EFFECT", ack["blockers"])
            self.assertEqual(["debit-incomplete"], ack["active_quota_reservation_ids"])
            self.assertEqual(before, hashlib.sha256(ledger.read_bytes()).hexdigest())

    def test_consumed_quota_with_open_before_journal_still_blocks(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            ledger = root / "output/operations/zero-cost/phase6-quota-ledger.sqlite3"
            ledger.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(ledger)
            try:
                connection.execute(
                    "CREATE TABLE general_quota_debits (debit_id TEXT PRIMARY KEY,state TEXT)"
                )
                connection.execute(
                    "INSERT INTO general_quota_debits VALUES (?,?)", ("debit-done", "CONSUMED")
                )
                connection.commit()
            finally:
                connection.close()
            receipt_path = root / "output/production/phase6/video-002/publication/youtube-publication-receipt.json"
            receipt_path.parent.mkdir(parents=True)
            receipt_path.write_text(
                json.dumps({
                    "status": "IN_PROGRESS",
                    "effect_journal": [{
                        "effect_id": "VIDEO_PRIVATE_UPLOAD", "attempt": 1,
                        "request_fingerprint": "a" * 64, "checkpoint": "BEFORE",
                        "outcome": "PENDING",
                    }],
                }),
                encoding="utf-8",
            )
            self._request(root)
            ack = acknowledge_request(
                root,
                manager_pid=4242,
                now=datetime(2026, 9, 5, 12, 0, 1, tzinfo=timezone.utc),
            )
            self.assertEqual([], ack["active_quota_reservation_ids"])
            self.assertEqual("DEFERRED", ack["status"])
            self.assertIn("INCOMPLETE_OPERATIONAL_EFFECT_JOURNAL", ack["blockers"])
            self.assertEqual(
                ["output/production/phase6/video-002/publication/youtube-publication-receipt.json"],
                ack["open_effect_receipt_paths"],
            )

    def test_malformed_request_holds_fail_closed_without_ack(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            request = root / REQUEST_PATH
            request.write_text('{"schema_version":"bad"}\n', encoding="utf-8")
            self.assertTrue(maintenance_barrier(root, manager_pid=4242))
            self.assertFalse((root / ACK_PATH).exists())

    def test_expired_revalidation_window_never_releases_the_request_barrier(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            self._request(root)
            arm_recovery_window(
                root,
                request_id=REQUEST_ID,
                manager_pid=4242,
                duration_seconds=60,
                armed_at=datetime(2026, 9, 5, 12, 0, tzinfo=timezone.utc),
            )
            self.assertIsNone(
                recovery_window_state(
                    root,
                    manager_pid=4242,
                    now=datetime(2026, 9, 5, 12, 2, tzinfo=timezone.utc),
                )
            )
            self.assertTrue(maintenance_barrier(root, manager_pid=4242))

    def test_invalid_recovery_marker_is_rejected_while_manager_branch_stays_inert(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = self._base(folder)
            self._request(root)
            marker = root / "output/runtime/gestor-central/maintenance-recovery-window.json"
            marker.write_text('{"schema_version":"truncated"', encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError):
                recovery_window_state(root, manager_pid=4242)
            manager = (ROOT / "hero_engine/central_manager_phase5.py").read_text(encoding="utf-8")
            branch = manager[manager.index("if maintenance_requested:"):manager.index("token_value = os.environ.get")]
            self.assertIn("except Exception:", branch)
            self.assertIn("recovery_state = None", branch)
            self.assertIn("continue", branch)

    def test_oauth_clock_and_recovery_budget_are_fail_closed(self) -> None:
        tested = "2026-09-05T12:00:00Z"
        self.assertEqual(
            datetime(2026, 9, 6, 12, 0, tzinfo=timezone.utc),
            oauth_refresh_due_at(tested, interval_seconds=24 * 60 * 60),
        )
        protocol = (ROOT / "hero_engine/maintenance_protocol.py").read_text(encoding="utf-8")
        self.assertIn("OAUTH_HEALTH_REFRESH_CLOCK_DIVERGED", protocol)
        self.assertNotIn("OAUTH_ACCESS_TOKEN_NOT_READY_THROUGH_RELEASE", protocol)
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("[System.Diagnostics.Stopwatch]::StartNew()", script)
        self.assertIn("Assert-RecoveryWindowRemaining", script)
        self.assertIn("$postCycleValidationBudgetSeconds", script)
        self.assertIn("$recoverySafetyMarginSeconds", script)

    def test_oauth_source_rotation_compares_durable_grant_not_access_token(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            source = base / "source.json"
            destination = base / "destination.json"
            durable = {
                "refresh_token": "same-refresh-secret",
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": "same-client",
                "client_secret": "same-client-secret",
                "scopes": ["scope-b", "scope-a"],
            }
            source.write_text(
                json.dumps({**durable, "token": "old-access", "expiry": "2026-09-05T18:00:00Z"}),
                encoding="utf-8",
            )
            mirrored_hash = hashlib.sha256(source.read_bytes()).hexdigest()
            destination.write_text(
                json.dumps({**durable, "token": "new-access", "expiry": "2026-09-05T19:00:00Z"}),
                encoding="utf-8",
            )
            source.write_text(
                json.dumps({**durable, "token": "rotated-source-access", "expiry": "2026-09-05T20:00:00Z"}),
                encoding="utf-8",
            )
            self.assertFalse(
                oauth_source_change_pending(
                    source,
                    destination,
                    mirrored_source_sha256=mirrored_hash,
                )
            )
            changed = dict(durable)
            changed["refresh_token"] = "genuinely-new-grant"
            source.write_text(
                json.dumps({**changed, "token": "new-consent-access", "expiry": "2026-09-05T20:00:00Z"}),
                encoding="utf-8",
            )
            self.assertTrue(
                oauth_source_change_pending(
                    source,
                    destination,
                    mirrored_source_sha256=mirrored_hash,
                )
            )

    def test_live_capability_repins_only_token_binding_after_refresh(self) -> None:
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as secrets:
            root = Path(workspace)
            (root / "schemas").mkdir(parents=True)
            (root / "schemas/central_manager_maintenance_capability.schema.json").write_bytes(
                (ROOT / "schemas/central_manager_maintenance_capability.schema.json").read_bytes()
            )
            (root / "hero_engine").mkdir()
            (root / "hero_engine/central_manager_phase5.py").write_text("boot manager\n", encoding="utf-8")
            (root / "hero_engine/maintenance_protocol.py").write_text("boot protocol\n", encoding="utf-8")
            token = Path(secrets) / "runtime-token.json"
            token.write_text(
                json.dumps(
                    {
                        "token": "access-before",
                        "refresh_token": "refresh-secret",
                        "expiry": "2026-09-06T12:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            holder = "2026-09-05T12:00:00Z"
            with patch.dict(os.environ, {"HERO_YT_TOKEN_PATH": str(token)}):
                initial = publish_capability(root, manager_pid=4242, holder_started_at=holder)
                token.write_text(
                    json.dumps(
                        {
                            "token": "access-after",
                            "refresh_token": "refresh-secret",
                            "expiry": "2026-09-06T13:00:00Z",
                        }
                    ),
                    encoding="utf-8",
                )
                refreshed = refresh_capability_token_binding(
                    root,
                    manager_pid=4242,
                    holder_started_at=holder,
                    now=datetime(2026, 9, 5, 13, 0, tzinfo=timezone.utc),
                )
                stable = refresh_capability_token_binding(
                    root,
                    manager_pid=4242,
                    holder_started_at=holder,
                    now=datetime(2026, 9, 5, 14, 0, tzinfo=timezone.utc),
                )

            self.assertNotEqual(initial["runtime_token_hash"], refreshed["runtime_token_hash"])
            self.assertEqual("2026-09-06T13:00:00Z", refreshed["runtime_token_expires_at"])
            self.assertEqual(initial["manager_source_hash"], refreshed["manager_source_hash"])
            self.assertEqual(initial["protocol_source_hash"], refreshed["protocol_source_hash"])
            self.assertEqual(refreshed, stable)
            serialized = json.dumps(refreshed)
            self.assertNotIn("access-after", serialized)
            self.assertNotIn("refresh-secret", serialized)
            Draft202012Validator(
                json.loads(
                    (root / "schemas/central_manager_maintenance_capability.schema.json").read_text(
                        encoding="utf-8-sig"
                    )
                )
            ).validate(refreshed)

            manager = (ROOT / "hero_engine/central_manager_phase5.py").read_text(encoding="utf-8")
            loop_branch = manager[manager.index("while True:"):manager.index("if maintenance_requested:")]
            self.assertLess(
                loop_branch.index("refresh_capability_token_binding("),
                loop_branch.index("maintenance_barrier("),
            )

    def test_revalidation_branch_cannot_reach_operational_executors(self) -> None:
        manager = (ROOT / "hero_engine/central_manager_phase5.py").read_text(encoding="utf-8")
        branch = manager[manager.index("if maintenance_requested:"):manager.index("token_value = os.environ.get")]
        self.assertIn("maintenance_revalidation=True", branch)
        self.assertIn("continue", branch)
        self.assertNotIn("run_phase6_treatment_executor", branch)
        self.assertNotIn("run_phase6_publication_controller", branch)
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        guarded = script[script.index("arm-recovery"):script.index("$finalReceipt =")]
        self.assertNotIn("Remove-Item -LiteralPath $requestPath", guarded)
        self.assertIn("barrier_held_through_validation = $true", script)

    def test_manifest_hashes_exact_test_ids_and_every_schema(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            tests = root / "tests"
            schemas = root / "schemas"
            tests.mkdir()
            schemas.mkdir()
            (tests / "test_one.py").write_text(
                "import unittest\nclass One(unittest.TestCase):\n    def test_exact(self):\n        pass\n",
                encoding="utf-8",
            )
            (schemas / "one.schema.json").write_text(
                json.dumps({"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object"}),
                encoding="utf-8",
            )
            result = build_validation_manifests(
                root, output_dir=Path("output/runtime/gestor-central/maintenance-runs/fixture")
            )
            inventory_path = root / result["test_inventory_path"]
            inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
            self.assertEqual(["tests.test_one.One.test_exact"], inventory["files"][0]["test_ids"])
            self.assertEqual(
                result["test_inventory_hash"],
                "sha256:" + hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
            )
            self.assertEqual(1, result["schema_count"])

    def test_regression_manifest_tamper_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "tests").mkdir()
            (root / "schemas").mkdir()
            (root / "tests/test_one.py").write_text(
                "import unittest\nclass One(unittest.TestCase):\n    def test_exact(self): pass\n",
                encoding="utf-8",
            )
            (root / "schemas/one.schema.json").write_text(
                json.dumps({"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object"}),
                encoding="utf-8",
            )
            request_id = REQUEST_ID
            run_rel = Path("output/runtime/gestor-central/maintenance-runs") / request_id
            inventory = build_validation_manifests(root, output_dir=run_rel)
            run = root / run_rel
            stdout = run / "unittest.stdout.log"
            stderr = run / "unittest.stderr.log"
            compile_stdout = run / "compileall.stdout.log"
            compile_stderr = run / "compileall.stderr.log"
            stdout.write_text("", encoding="utf-8")
            passing_transcript = (
                "test_exact (tests.test_one.One.test_exact) ... ok\n\n"
                "Ran 1 test in 0.001s\n\nOK\n"
            )
            stderr.write_text(passing_transcript, encoding="utf-8")
            compile_stdout.write_text("", encoding="utf-8")
            compile_stderr.write_text("", encoding="utf-8")
            jobs_hash = canonical_hash([])
            queue_value = {
                "schema_version": "1.0.0", "database_path": QUEUE_PATH.as_posix(),
                "database_present": False, "observed_at": "2026-09-05T12:00:00Z",
                "job_count": 0, "active_lease_job_ids": [], "jobs_hash": jobs_hash, "jobs": [],
            }
            before = run / "queue-before.json"
            after = run / "queue-after.json"
            before.write_text(json.dumps(queue_value), encoding="utf-8")
            after.write_text(json.dumps(queue_value), encoding="utf-8")
            integrity = root / "output/production/phase5/pilot-001/integrity_manifest.json"
            integrity.parent.mkdir(parents=True)
            integrity.write_text(json.dumps({"item_count": 1, "total_bytes": 1}), encoding="utf-8")

            def digest(path: Path) -> str:
                return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()

            receipt = {
                "schema_version": "1.0.0", "receipt_id": "daily-regression-fixture",
                "request_id": request_id, "status": "PASS", "mode": "LOCAL_VALIDATION_ONLY",
                "external_effects_permitted": False, "external_api_calls": 0,
                "publication_effects": 0, "operational_queue_mutations": 0,
                "tests": {
                    "test_count": 1, "file_count": 1,
                    "inventory_path": inventory["test_inventory_path"],
                    "inventory_hash": inventory["test_inventory_hash"],
                    "stdout_log": (run_rel / stdout.name).as_posix(), "stdout_hash": digest(stdout),
                    "stderr_log": (run_rel / stderr.name).as_posix(), "stderr_hash": digest(stderr),
                },
                "compileall": {
                    "stdout_log": (run_rel / compile_stdout.name).as_posix(), "stdout_hash": digest(compile_stdout),
                    "stderr_log": (run_rel / compile_stderr.name).as_posix(), "stderr_hash": digest(compile_stderr),
                },
                "schemas": {
                    "schema_count": 1, "inventory_path": inventory["schema_inventory_path"],
                    "inventory_hash": inventory["schema_inventory_hash"],
                },
                "queue": {
                    "before_path": (run_rel / before.name).as_posix(), "before_hash": digest(before),
                    "before_jobs_hash": jobs_hash,
                    "after_path": (run_rel / after.name).as_posix(), "after_hash": digest(after),
                    "after_jobs_hash": jobs_hash, "unchanged": True,
                },
                "integrity": {
                    "manifest_path": "output/production/phase5/pilot-001/integrity_manifest.json",
                    "content_hash": digest(integrity), "item_count": 1, "total_bytes": 1,
                },
            }
            verify_regression_evidence(root, receipt)
            receipt_v11 = copy.deepcopy(receipt)
            receipt_v11["schema_version"] = "1.1.0"
            stable_hash = canonical_hash({"stable": True})
            receipt_v11["local_runtime_migration"] = {
                "status": "PASS",
                "mode": "LOCAL_DERIVED_VIEWS_ONLY",
                "action": "NO_CHANGE",
                "stage_count": 12,
                "all_stage_schemas_valid": True,
                "stage_blockers": [],
                "queue_jobs_hash_before": stable_hash,
                "queue_jobs_hash_after": stable_hash,
                "quota_ledger_hash_before": stable_hash,
                "quota_ledger_hash_after": stable_hash,
                "operational_effects_hash_before": stable_hash,
                "operational_effects_hash_after": stable_hash,
                "allowed_write_paths": [],
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
            verify_regression_evidence(root, receipt_v11)
            changed_ledger = copy.deepcopy(receipt_v11)
            changed_ledger["local_runtime_migration"]["quota_ledger_hash_after"] = canonical_hash(
                {"stable": False}
            )
            with self.assertRaisesRegex(PermissionError, "changed the quota ledger"):
                verify_regression_evidence(root, changed_ledger)
            invalid_write = copy.deepcopy(receipt_v11)
            invalid_write["local_runtime_migration"]["allowed_write_paths"] = [
                "output/production/phase6/video-002/publication/youtube-publication-receipt.json"
            ]
            with self.assertRaisesRegex(PermissionError, "unauthorized path"):
                verify_regression_evidence(root, invalid_write)
            stderr.write_text(
                "test_exact (tests.test_one.One.test_exact) ... skipped \"not available\"\n\n"
                "Ran 1 test in 0.001s\n\nOK (skipped=1)\n",
                encoding="utf-8",
            )
            nonallowlisted_skip = copy.deepcopy(receipt)
            nonallowlisted_skip["tests"]["stderr_hash"] = digest(stderr)
            with self.assertRaisesRegex(PermissionError, "skip is not permitted"):
                verify_regression_evidence(root, nonallowlisted_skip)
            stderr.write_text(passing_transcript, encoding="utf-8")
            (root / inventory["test_inventory_path"]).write_text("{}\n", encoding="utf-8")
            with self.assertRaisesRegex(PermissionError, "evidence hash mismatch"):
                verify_regression_evidence(root, receipt)

    @unittest.skipUnless(os.name == "nt", "PowerShell integration requires Windows")
    def test_daily_result_parser_accepts_only_documented_skip_through_powershell(self) -> None:
        skip_id = (
            "tests.test_scheduled_voice_probe.ScheduledVoiceProbeTests."
            "test_preexisting_sample_symlink_is_never_reused"
        )
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inventory_path = root / "test-inventory.json"
            stdout_path = root / "unittest.stdout.log"
            stderr_path = root / "unittest.stderr.log"
            ids = [skip_id]
            inventory = {
                "schema_version": "1.0.0",
                "discovery_pattern": "tests/test_*.py",
                "file_count": 1,
                "test_count": 1,
                "tests_hash": canonical_hash(ids),
                "files": [{
                    "path": "tests/test_scheduled_voice_probe.py",
                    "content_hash": "sha256:" + "a" * 64,
                    "test_ids": ids,
                }],
            }
            inventory_path.write_text(json.dumps(inventory), encoding="utf-8")
            stdout_path.write_text("", encoding="utf-8")
            stderr_path.write_text(
                "test_preexisting_sample_symlink_is_never_reused "
                "(test_scheduled_voice_probe.ScheduledVoiceProbeTests."
                "test_preexisting_sample_symlink_is_never_reused) ... "
                "skipped \"file symlink unavailable: [WinError 1314] localized\"\n"
                "Ran 1 test in 0.001s\n\nOK (skipped=1)\n",
                encoding="utf-8",
            )

            def quoted(value: str) -> str:
                return "'" + value.replace("'", "''") + "'"

            command = (
                "$raw = & " + quoted(sys.executable)
                + " -m hero_engine.maintenance_unittest_result"
                + " --inventory " + quoted(str(inventory_path))
                + " --stdout " + quoted(str(stdout_path))
                + " --stderr " + quoted(str(stderr_path))
                + " --exit-code 0\n"
                "$code = $LASTEXITCODE\n"
                "if ($code -ne 0) { exit $code }\n"
                "$value = (($raw -join \"`n\") | ConvertFrom-Json)\n"
                "if ($value.status -ne 'PASS' -or $value.skipped_count -ne 1 "
                "-or $value.process_exit_code_verified -ne $true) { exit 41 }\n"
            )
            accepted = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command", command],
                cwd=ROOT,
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
            self.assertEqual(0, accepted.returncode, accepted.stderr)

            stderr_path.write_text(
                "test_preexisting_sample_symlink_is_never_reused "
                "(test_scheduled_voice_probe.ScheduledVoiceProbeTests."
                "test_preexisting_sample_symlink_is_never_reused) ... expected failure\n"
                "Ran 1 test in 0.001s\n\nOK (expected failures=1)\n",
                encoding="utf-8",
            )
            rejected = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command", command],
                cwd=ROOT,
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
            self.assertNotEqual(0, rejected.returncode)

    def test_daily_uses_strict_result_parser_instead_of_summary_regex(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        regression = script[
            script.index("$tests = Invoke-HiddenProcess"):
            script.index("& $testPython 'scripts\\build_phase5_integrity.py'")
        ]
        self.assertIn("-m hero_engine.maintenance_unittest_result", regression)
        self.assertIn("--exit-code ([string]$tests.exit_code)", regression)
        self.assertIn("process_exit_code_verified -eq $true", regression)
        self.assertNotIn("[regex]::Match", regression)
        self.assertNotIn("[regex]::IsMatch", regression)

    def test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        request_at = script.index("hero_engine.maintenance_protocol request")
        capability_at = script.index("$capabilityMatches = $false")
        legacy_suspend_at = script.index(
            "Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true"
        )
        conditional_ack_at = script.index("if ($capabilityMatches)")
        ack_deadline_at = script.index("$ackDeadline =")
        stop_at = script.index("Stop-ScheduledTask")
        restart_at = script.index("Start-ScheduledTask")
        post_at = script.index("hero_engine.phase6_maintenance_verification")
        final_at = script.index("$finalReceipt =")
        self.assertLess(capability_at, legacy_suspend_at)
        self.assertLess(legacy_suspend_at, request_at)
        self.assertLess(request_at, conditional_ack_at)
        self.assertLess(conditional_ack_at, ack_deadline_at)
        self.assertLess(request_at, stop_at)
        self.assertLess(stop_at, restart_at)
        self.assertLess(restart_at, post_at)
        self.assertLess(post_at, final_at)
        self.assertIn("finally {", script)
        self.assertNotIn("-m hero_engine.phase6_publication", script)
        self.assertNotIn("-m hero_engine.phase6_asset_residency", script)
        self.assertNotIn("-m hero_engine.phase6_media", script)
        self.assertNotIn("-m hero_engine.phase6_quality", script)
        self.assertNotIn("run.ps1", script)

    def test_mutex_precedes_every_request_run_and_mutation_and_releases_last(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        acquired_at = script.index("$maintenanceMutex.WaitOne(0)")
        administrative_start_at = script.index("$maintenanceInvocationStartedAt")
        first_directory_mutation_at = script.index("New-Item -ItemType Directory -Path $runtimeDir")
        request_at = script.index("hero_engine.maintenance_protocol request")
        self.assertLess(acquired_at, administrative_start_at)
        self.assertLess(acquired_at, first_directory_mutation_at)
        self.assertLess(acquired_at, request_at)
        self.assertIn("no request, run or barrier was touched", script)
        self.assertGreater(script.rindex("$maintenanceMutex.ReleaseMutex()"), script.rindex("Write-Output $finalLatest"))
        cleanup = script[script.index("if ($requestCreated)"):]
        self.assertIn("-ExpectedRequestId $requestId", cleanup)
        self.assertIn("Refusing to remove a foreign maintenance barrier", script)

    def test_zero_effect_clock_begins_only_at_ack_or_verified_legacy_suspend(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("$maintenanceRequestedAt = ([DateTimeOffset]$requestDocument.requested_at).ToUniversalTime()", script)
        self.assertIn("$zeroEffectBoundaryStartedAt = ([DateTimeOffset]$ack.observed_at).ToUniversalTime()", script)
        self.assertIn("$zeroEffectBoundaryStartedAt = $bootstrapSuspendedAt.ToUniversalTime()", script)
        self.assertIn("requested_at = $maintenanceRequestedAt.ToString('o')", script)
        self.assertIn("zero_effect_boundary_started_at = $zeroEffectBoundaryStartedAt.ToString('o')", script)
        self.assertIn("started_at = $zeroEffectBoundaryStartedAt.ToString('o')", script)
        self.assertNotIn("$maintenanceStartedAt", script)

    def test_stopped_regression_snapshots_cover_and_compare_every_effect_surface(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        snapshot = script[
            script.index("function Write-StoppedOperationalSnapshot"):
            script.index("function Assert-RecoveryWindowRemaining")
        ]
        for token in (
            "output\\operations\\phase6\\runtime\\phase6-queue.sqlite3",
            "QUEUE_WAL", "QUEUE_SHM", "quota_ledger_tables", "QUOTA_WAL", "QUOTA_SHM",
            "operational_effect_receipts", "operational_effect_surface_files",
            "oauth_proof_files", "OAUTH_RUNTIME_TOKEN_EXTERNAL", "-RedactPath", "state_hash",
        ):
            self.assertIn(token, snapshot)
        before_at = script.index("-Role PRE_REGRESSION")
        compile_at = script.index("$compile = Invoke-HiddenProcess")
        integrity_at = script.index("& $testPython 'scripts\\build_phase5_integrity.py'")
        after_at = script.index("-Role POST_REGRESSION")
        equality_at = script.index("$stoppedBefore.state_hash -ne [string]$stoppedAfter.state_hash")
        receipt_at = script.index("$regressionReceipt =")
        self.assertLess(before_at, compile_at)
        self.assertLess(integrity_at, after_at)
        self.assertLess(after_at, equality_at)
        self.assertLess(equality_at, receipt_at)

    @unittest.skipUnless(os.name == "nt", "Windows file-sharing semantics required")
    def test_barrier_cleanup_retries_transient_lock_and_never_deletes_foreign_request(self) -> None:
        function_source = self._powershell_function("Remove-OwnedBarrierFileBounded")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            owned = root / "owned.json"
            owned.write_text(json.dumps({"request_id": REQUEST_ID}), encoding="utf-8")
            holder_code = (
                "$s=[IO.File]::Open($args[0],[IO.FileMode]::Open,[IO.FileAccess]::Read,"
                "[IO.FileShare]::Read); Start-Sleep -Milliseconds 700; $s.Dispose()"
            )
            holder = subprocess.Popen(
                ["powershell.exe", "-NoProfile", "-Command", holder_code, str(owned)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                time.sleep(0.2)
                harness = root / "remove-owned.ps1"
                escaped = str(owned).replace("'", "''")
                harness.write_text(
                    "$ErrorActionPreference='Stop'\n"
                    + function_source
                    + f"\nRemove-OwnedBarrierFileBounded -Path '{escaped}' -ExpectedRequestId '{REQUEST_ID}' -TimeoutSeconds 3\n",
                    encoding="utf-8",
                )
                completed = subprocess.run(
                    ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(harness)],
                    capture_output=True,
                    text=True,
                    timeout=8,
                    check=False,
                )
                self.assertEqual(0, completed.returncode, completed.stderr)
                self.assertFalse(owned.exists())
            finally:
                holder.wait(timeout=5)

            foreign = root / "foreign.json"
            foreign.write_text(json.dumps({"request_id": "maintenance-request-foreign"}), encoding="utf-8")
            harness = root / "reject-foreign.ps1"
            escaped = str(foreign).replace("'", "''")
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                + function_source
                + f"\nRemove-OwnedBarrierFileBounded -Path '{escaped}' -ExpectedRequestId '{REQUEST_ID}' -TimeoutSeconds 1\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(harness)],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            self.assertNotEqual(0, completed.returncode)
            self.assertTrue(foreign.exists())

    def test_barrier_release_is_bounded_owned_ordered_and_gates_latest_pass(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        cleanup_start = script.index("# The request is the fail-closed barrier")
        cleanup_end = script.index("if ($null -eq $failure", cleanup_start)
        cleanup = script[cleanup_start:cleanup_end]
        recovery_at = cleanup.index("-Path $recoveryWindowPath")
        ack_at = cleanup.index("-Path $ackPath")
        request_at = cleanup.index("-Path $requestPath")
        self.assertLess(recovery_at, ack_at)
        self.assertLess(ack_at, request_at)
        self.assertIn("[DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)", script)
        self.assertIn("BARRIER_RELEASE_FAILED", cleanup)
        self.assertIn("operational_ready = $false", cleanup)
        final_candidate_at = script.index("$finalCandidatePath = $finalRunPath")
        latest_copy_at = script.index("Copy-Item -LiteralPath $finalCandidatePath -Destination $finalLatest")
        self.assertLess(final_candidate_at, cleanup_start)
        self.assertLess(cleanup_start, latest_copy_at)

    def test_process_chain_is_bound_to_exact_scheduled_task_action(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        for token in (
            "ValidateSet('MANAGER', 'VENV_SHIM', 'LAUNCHER')",
            "$managerShimPid = [int]$managerProcess.ParentProcessId",
            "$launcherPid = [int]$managerShim.ParentProcessId",
            "manager -> venv shim -> ScheduledTask launcher chain is not exact",
            "$verifiedTaskAction.Execute",
            "$verifiedTaskAction.Arguments",
            "-EncodedCommand",
            "start_phase5_manager.ps1",
            "$verifiedTaskAction.WorkingDirectory",
            "Stop-VerifiedProcess -ProcessId $managerShimPid -Role VENV_SHIM",
        ):
            self.assertIn(token, script)
        manager_stop = script.index("Stop-VerifiedProcess -ProcessId $managerPid -Role MANAGER")
        shim_stop = script.index("Stop-VerifiedProcess -ProcessId $managerShimPid -Role VENV_SHIM")
        launcher_stop = script.index("Stop-VerifiedProcess -ProcessId $launcherPid -Role LAUNCHER")
        self.assertLess(manager_stop, shim_stop)
        self.assertLess(shim_stop, launcher_stop)
        self.assertIn("function Test-FrozenProcessAlive", script)
        self.assertIn("PID_REUSED_FOREIGN", script)
        self.assertIn("creation_utc_ticks", script)
        self.assertIn("handle_creation_utc_ticks", script)
        self.assertIn("-not (Test-FrozenProcessAlive -ProcessId $managerPid -Role MANAGER -ExpectedIdentity $managerIdentity)", script)

    def test_process_chain_discovery_is_bounded_coherent_and_has_no_stop_side_effect(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        source = self._powershell_function("Get-CoherentManagerProcessChainSnapshot")
        for token in (
            "$managerPidBefore = [int](Get-Content -LiteralPath $PidPath -Raw)",
            "$managerPidAfter = [int](Get-Content -LiteralPath $PidPath -Raw)",
            "$lockStartedBefore",
            "$resampledManager = Assert-ProcessRole -ProcessId $managerPid -Role MANAGER",
            "$resampledGenerationTicks",
            "$managerPidFinal = [int](Get-Content -LiteralPath $PidPath -Raw)",
            "changed during the pre-freeze re-sample",
            "Get-FrozenProcessDisposition -ExpectedIdentity $identity",
            "duplicate or incomplete Python process chain",
            "bounded observations",
        ):
            self.assertIn(token, source)
        self.assertNotIn("Stop-Process", source)
        self.assertNotIn("Stop-ScheduledTask", source)
        self.assertGreaterEqual(
            script.count("Get-CoherentManagerProcessChainSnapshot `"),
            2,
        )
        first_snapshot = script.index("$initialChain = Get-CoherentManagerProcessChainSnapshot")
        request = script.index("hero_engine.maintenance_protocol request")
        second_snapshot = script.index("$currentChain = Get-CoherentManagerProcessChainSnapshot")
        self.assertLess(first_snapshot, request)
        self.assertLess(request, second_snapshot)

        stop_source = self._powershell_function("Stop-VerifiedProcess")
        suspend_source = self._powershell_function("Set-VerifiedManagerSuspended")
        self.assertIn("$process = Get-Process -Id $ProcessId", stop_source)
        self.assertIn("$processHandle = $process.Handle", stop_source)
        self.assertIn("Get-BoundedFrozenProcessDisposition", stop_source)
        self.assertIn("TerminateProcess($processHandle, 1)", stop_source)
        self.assertNotIn("Stop-Process -Id", stop_source)
        self.assertIn("$ExpectedIdentity", suspend_source)
        self.assertIn("$processHandle = $process.Handle", suspend_source)
        self.assertIn("Get-BoundedFrozenProcessDisposition", suspend_source)
        self.assertIn("NtSuspendProcess($processHandle)", suspend_source)

    @unittest.skipUnless(os.name == "nt", "PowerShell fault injection requires Windows")
    def test_frozen_liveness_retries_transient_uncertain_after_initial_snapshot(self) -> None:
        """Reproduce the live 16176 race: shutdown makes one CIM read uncertain."""
        bounded_source = self._powershell_function(
            "Get-BoundedFrozenProcessDisposition"
        )
        liveness_source = self._powershell_function("Test-FrozenProcessAlive")
        with tempfile.TemporaryDirectory() as folder:
            harness = Path(folder) / "transient-uncertain-liveness.ps1"
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                + "$script:observations=0\n"
                + "function Get-FrozenProcessDisposition { param($ExpectedIdentity); "
                + "$script:observations += 1; "
                + "if ($script:observations -eq 1) { return 'IDENTITY_UNCERTAIN' }; "
                + "return 'ABSENT' }\n"
                + bounded_source
                + "\n"
                + liveness_source
                + "\n"
                + "$identity=[pscustomobject]@{role='MANAGER';process_id=16176}\n"
                + "try {\n"
                + "  $alive=Test-FrozenProcessAlive -ProcessId 16176 -Role MANAGER -ExpectedIdentity $identity\n"
                + "  if ($alive) { exit 31 }\n"
                + "  if ($script:observations -ne 2) { exit 32 }\n"
                + "  exit 0\n"
                + "} catch { Write-Error $_; exit 33 }\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(harness),
                ],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)

    @unittest.skipUnless(os.name == "nt", "PowerShell fault injection requires Windows")
    def test_persistent_uncertain_identity_aborts_before_exact_process_action(self) -> None:
        bounded_source = self._powershell_function(
            "Get-BoundedFrozenProcessDisposition"
        )
        stop_source = self._powershell_function("Stop-VerifiedProcess")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            marker = root / "termination-path-entered.txt"
            harness = root / "persistent-uncertain-stop.ps1"
            escaped_marker = str(marker).replace("'", "''")
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                + f"$script:markerPath='{escaped_marker}'\n"
                + "$script:observations=0\n"
                + "$script:fakeProcess=[pscustomobject]@{Handle=[IntPtr]123;StartTime=[datetime]'2026-09-05T12:00:00Z'}\n"
                + "$script:fakeProcess | Add-Member -MemberType ScriptMethod -Name Dispose -Value { }\n"
                + "function Get-Process { param([int]$Id,$ErrorAction); return $script:fakeProcess }\n"
                + "function Add-Type { param($TypeDefinition); Set-Content -LiteralPath $script:markerPath -Value 'ENTERED'; throw 'termination path reached' }\n"
                + "function Get-FrozenProcessDisposition { param($ExpectedIdentity); "
                + "$script:observations += 1; return 'IDENTITY_UNCERTAIN' }\n"
                + bounded_source
                + "\n"
                + stop_source
                + "\n"
                + "$identity=[pscustomobject]@{role='MANAGER';process_id=16176;handle_creation_utc_ticks=[int64]$script:fakeProcess.StartTime.ToUniversalTime().Ticks}\n"
                + "try {\n"
                + "  Stop-VerifiedProcess -ProcessId 16176 -Role MANAGER -ExpectedIdentity $identity\n"
                + "  exit 41\n"
                + "} catch {\n"
                + f"  if (Test-Path -LiteralPath '{escaped_marker}') {{ exit 42 }}\n"
                + "  if ($script:observations -lt 2) { exit 43 }\n"
                + "  if ($_.Exception.Message -notlike '*identity remained uncertain*bounded observations*') { Write-Error $_; exit 44 }\n"
                + "  if ($null -ne ('HeroEngineMaintenanceTerminationNative' -as [type])) { exit 45 }\n"
                + "  exit 0\n"
                + "}\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(harness),
                ],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
            self.assertFalse(marker.exists(), "uncertain identity reached the termination path")

    @unittest.skipUnless(os.name == "nt", "PowerShell fault injection requires Windows")
    def test_process_chain_discovery_retries_stale_shim_and_never_freezes_partial_chain(self) -> None:
        function_source = self._powershell_function(
            "Get-CoherentManagerProcessChainSnapshot"
        )
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            pid_path = root / "manager.pid"
            lock_path = root / "manager-lock.json"
            pid_path.write_text("101\n", encoding="utf-8")
            lock_path.write_text(
                json.dumps(
                    {
                        "state": "HELD",
                        "holder_pid": 101,
                        "holder_started_at": "2026-09-05T12:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            harness = root / "chain-churn.ps1"
            escaped_pid = str(pid_path).replace("'", "''")
            escaped_lock = str(lock_path).replace("'", "''")
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                + "$script:churned=$false; $script:frozenPids=@()\n"
                + "function New-FakeProcess { param([int]$Id,[int]$Parent,[string]$Command='python -m hero_engine.central_manager_phase5'); "
                + "return [pscustomobject]@{ProcessId=$Id;ParentProcessId=$Parent;CommandLine=$Command;CreationDate=[datetime]'2026-09-05T12:00:00Z';ExecutablePath='C:\\\\fake\\\\python.exe'} }\n"
                + "function Assert-ProcessRole { param([int]$ProcessId,[string]$Role); "
                + "if ($ProcessId -eq 101 -and $Role -eq 'MANAGER') { return New-FakeProcess 101 201 }; "
                + "if ($ProcessId -eq 201 -and $Role -eq 'VENV_SHIM' -and -not $script:churned) { "
                + f"Set-Content -LiteralPath '{escaped_pid}' -Value '102'; "
                + f"@{{state='HELD';holder_pid=102;holder_started_at='2026-09-05T12:00:01Z'}} | ConvertTo-Json | Set-Content -LiteralPath '{escaped_lock}'; "
                + "$script:churned=$true; throw 'VENV_SHIM PID 201 is not alive.' }; "
                + "if ($ProcessId -eq 102 -and $Role -eq 'MANAGER') { return New-FakeProcess 102 202 }; "
                + "if ($ProcessId -eq 202 -and $Role -eq 'VENV_SHIM') { return New-FakeProcess 202 302 }; "
                + "if ($ProcessId -eq 302 -and $Role -eq 'LAUNCHER') { return New-FakeProcess 302 0 'powershell.exe -EncodedCommand fixture' }; "
                + "throw \"unexpected role lookup $Role/$ProcessId\" }\n"
                + "function Get-FrozenProcessIdentity { param($Process,[string]$Role); $script:frozenPids += [int]$Process.ProcessId; "
                + "return [pscustomobject]@{role=$Role;process_id=[int]$Process.ProcessId;parent_process_id=[int]$Process.ParentProcessId;creation_utc_ticks=[int64]($Process.ProcessId*10);executable_path=[string]$Process.ExecutablePath;command_line_hash='sha256:fixture'} }\n"
                + "function Get-FrozenProcessDisposition { param($ExpectedIdentity); return 'EXACT_ALIVE' }\n"
                + "function Get-CimInstance { param($ClassName,$ErrorAction); return @((New-FakeProcess 102 202),(New-FakeProcess 202 302)) }\n"
                + function_source
                + "\ntry {\n"
                + f"  $result=Get-CoherentManagerProcessChainSnapshot -PidPath '{escaped_pid}' -LockPath '{escaped_lock}' -TimeoutSeconds 2 -PollMilliseconds 25\n"
                + "  if ($result.manager_pid -ne 102 -or $result.manager_shim_pid -ne 202 -or $result.launcher_pid -ne 302) { exit 31 }\n"
                + "  if ($result.attempt_count -lt 2) { exit 32 }\n"
                + "  if ($script:frozenPids -contains 101 -or $script:frozenPids -contains 201) { exit 33 }\n"
                + "  if (($script:frozenPids -join ',') -ne '102,202,302') { exit 34 }\n"
                + "  exit 0\n"
                + "} catch { Write-Error $_; exit 35 }\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(harness),
                ],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)

    @unittest.skipUnless(os.name == "nt", "PowerShell fault injection requires Windows")
    def test_process_chain_discovery_fails_closed_when_churn_never_settles(self) -> None:
        function_source = self._powershell_function(
            "Get-CoherentManagerProcessChainSnapshot"
        )
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            pid_path = root / "manager.pid"
            lock_path = root / "manager-lock.json"
            marker = root / "identity-returned.txt"
            pid_path.write_text("101\n", encoding="utf-8")
            lock_path.write_text(
                json.dumps(
                    {
                        "state": "HELD",
                        "holder_pid": 101,
                        "holder_started_at": "2026-09-05T12:00:00Z",
                    }
                ),
                encoding="utf-8",
            )
            harness = root / "chain-never-settles.ps1"
            escaped_pid = str(pid_path).replace("'", "''")
            escaped_lock = str(lock_path).replace("'", "''")
            escaped_marker = str(marker).replace("'", "''")
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                + "function Assert-ProcessRole { param([int]$ProcessId,[string]$Role); "
                + "if ($Role -eq 'MANAGER') { return [pscustomobject]@{ProcessId=101;ParentProcessId=201} }; "
                + "throw 'VENV_SHIM PID 201 is not alive.' }\n"
                + "function Get-FrozenProcessIdentity { throw 'partial identity must never be frozen' }\n"
                + "function Get-FrozenProcessDisposition { throw 'no disposition expected' }\n"
                + "function Get-CimInstance { return @() }\n"
                + function_source
                + "\ntry {\n"
                + f"  Get-CoherentManagerProcessChainSnapshot -PidPath '{escaped_pid}' -LockPath '{escaped_lock}' -TimeoutSeconds 1 -PollMilliseconds 25 | Out-Null\n"
                + f"  Set-Content -LiteralPath '{escaped_marker}' -Value 'RETURNED'\n"
                + "  exit 41\n"
                + "} catch {\n"
                + f"  if (Test-Path -LiteralPath '{escaped_marker}') {{ exit 42 }}\n"
                + "  if ($_.Exception.Message -notlike '*bounded observations*VENV_SHIM PID 201 is not alive*') { Write-Error $_; exit 43 }\n"
                + "  exit 0\n"
                + "}\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(harness),
                ],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
            self.assertFalse(marker.exists())

    def test_restart_readiness_requires_schema_bound_capability_console_and_full_chain(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        restart = script[script.index("$restartDeadline ="):script.index("$verifyOut =")]
        for token in (
            "$newManager = Assert-ProcessRole -ProcessId $newPid -Role MANAGER",
            "$newManagerShim = Assert-ProcessRole -ProcessId $newManagerShimPid -Role VENV_SHIM",
            "$newLauncher = Assert-ProcessRole -ProcessId $newLauncherPid -Role LAUNCHER",
            "central_manager_maintenance_capability.schema.json",
            "phase5_review_console_runtime.schema.json",
            "$newCapability.manager_pid",
            "$newCapability.holder_started_at",
            "$newCapability.manager_source_hash",
            "$newCapability.protocol_source_hash",
            "$newReview.status -eq 'LISTENING'",
            "$newReview.process_id -eq $newPid",
            "Restarted runtime identity changed during schema verification",
        ):
            self.assertIn(token, restart)

    def test_native_process_arguments_preserve_python_quotes_and_script_path_spaces(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("$envelopeJson | & $testPython -m hero_engine.maintenance_snapshot --root $projectRoot", script)
        self.assertIn("$OutputEncoding = [System.Text.UTF8Encoding]::new($false)", script)
        self.assertIn("finally { $OutputEncoding = $previousOutputEncoding }", script)
        self.assertNotIn("$canonicalHashProgram", script)
        self.assertIn(
            "'-File', ('\"' + (Join-Path $PSScriptRoot 'verify_phase5_manager_autostart.ps1') + '\"')",
            script,
        )

    def test_legacy_suspend_faults_force_recovery_and_discover_only_owned_request(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        suspend_at = script.index("Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true")
        recovery_required_at = script.index("$restartRequired = $true", suspend_at)
        request_at = script.index("hero_engine.maintenance_protocol request")
        self.assertLess(suspend_at, recovery_required_at)
        self.assertLess(recovery_required_at, request_at)
        recovery = script[script.index("finally {", script.index("catch {\n    $failure = $_")):]
        self.assertIn("if (-not $requestCreated -and (Test-Path -LiteralPath $requestPath", recovery)
        self.assertIn("$discoveredRequest.request_id -eq $requestId", recovery)
        self.assertIn("$restartRequired = $true", recovery)
        self.assertIn("Stop-VerifiedProcess -ProcessId $stopTarget.ProcessId -Role $stopTarget.Role -ExpectedIdentity $stopTarget.Identity", recovery)
        self.assertIn("Invoke-VerifiedScheduledTaskRestart", recovery)
        self.assertIn("Start-ScheduledTask -TaskName $taskName", recovery)
        self.assertNotIn("Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $false", recovery)
        stop_at = recovery.index("Stop-VerifiedProcess -ProcessId $stopTarget.ProcessId")
        restart_at = recovery.index("Start-ScheduledTask -TaskName $taskName")
        self.assertLess(stop_at, restart_at)

    @unittest.skipUnless(os.name == "nt", "PowerShell fault injection requires Windows")
    def test_restart_fault_injection_never_starts_task_when_exact_chain_absence_is_uncertain(self) -> None:
        wait_source = self._powershell_function("Wait-FrozenProcessChainAbsent")
        restart_source = self._powershell_function("Invoke-VerifiedScheduledTaskRestart")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            marker = root / "scheduled-task-started.txt"
            harness = root / "restart-fault-injection.ps1"
            escaped_marker = str(marker).replace("'", "''")
            harness.write_text(
                "$ErrorActionPreference='Stop'\n"
                "function Get-FrozenProcessDisposition { param($ExpectedIdentity) return 'IDENTITY_UNCERTAIN' }\n"
                + wait_source
                + "\n"
                + restart_source
                + "\n"
                + "$chain=@(\n"
                + "  [pscustomobject]@{role='MANAGER';process_id=101;creation_utc_ticks=1},\n"
                + "  [pscustomobject]@{role='VENV_SHIM';process_id=102;creation_utc_ticks=2},\n"
                + "  [pscustomobject]@{role='LAUNCHER';process_id=103;creation_utc_ticks=3}\n"
                + ")\n"
                + "try {\n"
                + "  Invoke-VerifiedScheduledTaskRestart -FrozenProcesses $chain -TimeoutSeconds 0 "
                + f"-StartAction {{ Set-Content -LiteralPath '{escaped_marker}' -Value 'STARTED' }} | Out-Null\n"
                + "  exit 41\n"
                + "}\n"
                + "catch {\n"
                + f"  if (Test-Path -LiteralPath '{escaped_marker}') {{ exit 42 }}\n"
                + "  if ($_.Exception.Message -notlike '*exact-chain absence was not proven*') { Write-Error $_; exit 43 }\n"
                + "  exit 0\n"
                + "}\n",
                encoding="utf-8",
            )
            completed = subprocess.run(
                ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(harness)],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
            self.assertFalse(marker.exists(), "fault injection reached the ScheduledTask start action")

        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        recovery = script[script.index("if ($restartRequired -and $managerWasRunning)"):]
        self.assertIn("Invoke-VerifiedScheduledTaskRestart", recovery)
        self.assertIn("PID_REUSED_FOREIGN", script)
        self.assertIn("IDENTITY_UNCERTAIN", script)
        self.assertIn("pre_restart_exact_chain_absence", script)
        self.assertNotIn("$preRestartStopFailure = $null", recovery)

    def test_read_only_runtime_preview_is_a_fail_closed_pre_stop_barrier(self) -> None:
        script = (ROOT / "scripts/daily.ps1").read_text(encoding="utf-8-sig")
        preview_at = script.index(
            "hero_engine.maintenance_protocol preview-local-runtime"
        )
        preview_exit_guard_at = script.index(
            "Read-only local runtime migration preview failed before the maintenance boundary.",
            preview_at,
        )
        preview_contract_guard_at = script.index(
            "Read-only local runtime migration preview did not prove every zero-effect pre-stop guard.",
            preview_at,
        )
        diagnostic_write_at = script.index(
            "Write-JsonAtomic -Value $runtimeMigrationPreview", preview_at
        )
        run_dir_create_at = script.index(
            "New-Item -ItemType Directory -Path $runDir", preview_at
        )
        suspend_at = script.index(
            "Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true"
        )
        request_at = script.index("hero_engine.maintenance_protocol request")
        stop_at = script.index("Stop-ScheduledTask -TaskName $taskName")
        self.assertLess(preview_at, preview_exit_guard_at)
        self.assertLess(preview_exit_guard_at, preview_contract_guard_at)
        self.assertLess(preview_contract_guard_at, run_dir_create_at)
        self.assertLess(run_dir_create_at, diagnostic_write_at)
        self.assertLess(diagnostic_write_at, suspend_at)
        self.assertLess(diagnostic_write_at, request_at)
        self.assertLess(diagnostic_write_at, stop_at)
        pre_preview = script[:preview_at]
        self.assertNotIn("New-Item -ItemType Directory -Path $runDir", pre_preview)
        self.assertNotIn("hero_engine.maintenance_protocol request", pre_preview)
        self.assertNotIn(
            "Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true",
            pre_preview,
        )
        for zero_effect_field in (
            "PREVIEW_NOT_AN_EXECUTION_REQUEST",
            "external_api_calls",
            "operational_queue_mutations",
            "proofs_persisted",
            "runtime_views_persisted",
            "receipt_committed",
            "control_sources.stage_count",
            "control_sources.all_schemas_valid",
            "control_sources.blockers",
        ):
            self.assertIn(zero_effect_field, script[preview_at:diagnostic_write_at])

    def test_all_maintenance_schemas_are_valid_draft_202012(self) -> None:
        for name in (
            "central_manager_maintenance_request.schema.json",
            "central_manager_maintenance_ack.schema.json",
            "central_manager_maintenance_capability.schema.json",
            "central_manager_maintenance_bootstrap.schema.json",
            "central_manager_maintenance_boundary.schema.json",
            "central_manager_maintenance_recovery_window.schema.json",
            "daily_maintenance_regression_receipt.schema.json",
            "daily_maintenance_receipt.schema.json",
            "phase6_control_cycle_receipt.schema.json",
            "phase6_post_maintenance_verification.schema.json",
        ):
            schema = json.loads((ROOT / "schemas" / name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)


if __name__ == "__main__":
    unittest.main()
