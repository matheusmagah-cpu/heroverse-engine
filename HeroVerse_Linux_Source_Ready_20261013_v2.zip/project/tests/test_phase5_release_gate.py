from __future__ import annotations

import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from hero_engine.phase5_release_gate import build_release_gate


ROOT = Path(__file__).resolve().parents[1]


class Phase5ReleaseGateTests(unittest.TestCase):
    def test_real_limited_canary_passes_every_release_gate(self) -> None:
        release = build_release_gate(ROOT, created_at="2026-09-04T00:30:00Z")
        schema = json.loads((ROOT / "schemas/phase5_release_gate.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator(schema).validate(release)
        self.assertEqual("READY_FOR_PUBLICATION_PIPELINE", release["decision"])
        self.assertTrue(release["publication_pipeline_permitted"])
        self.assertEqual([], release["blockers"])
        self.assertEqual(13, len(release["gates"]))
        self.assertTrue(all(item["status"] == "PASS" for item in release["gates"]))
        self.assertIn("AUTONOMOUS_PERCEPTUAL_QUALITY", {item["gate"] for item in release["gates"]})
        self.assertIn("HUMAN_GOLD_STANDARD_POLICY", {item["gate"] for item in release["gates"]})
        self.assertEqual(6, len(release["authorized_api_methods"]))
        self.assertEqual("private", release["staging_privacy_status"])
        self.assertEqual("public", release["final_privacy_status"])
        self.assertEqual(64, len(release["idempotency_key"]))


if __name__ == "__main__":
    unittest.main()
