from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hero_engine import media_lifecycle


class MediaLifecycleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.package = self.root / "package"
        evidence = self.package / "rights_evidence" / "asset-1.json"
        evidence.parent.mkdir(parents=True)
        evidence.write_text('{"rights":"fixture"}\n', encoding="utf-8")
        candidate = {
            "asset_id": "asset-1", "residency": "REMOTE_CATALOGED", "production_eligible": False,
            "download_url": "https://example.invalid/asset-1.webm", "source": "https://example.invalid/source",
            "rights_evidence_uri": str(evidence), "size_bytes": 3,
        }
        self.catalog = self.package / "asset_candidates.remote.json"
        self.catalog.write_text(json.dumps({"media_downloaded": False, "candidates": [candidate]}), encoding="utf-8")
        self.allocation = self.package / "asset_allocation.json"
        self.allocation.write_text(json.dumps({"takes": [{"take_id": "take-001", "asset_id": "asset-1"}]}), encoding="utf-8")

    def _acquire(self) -> dict:
        def download(_candidate, destination):
            destination.write_bytes(b"abc")
        with patch.object(media_lifecycle, "_download_commons_file", side_effect=download) as download:
            value = media_lifecycle.acquire_catalog_candidate(
                self.root, self.catalog, asset_id="asset-1", allocation_path=self.allocation,
                acquisition_dir=self.package / "acquired",
            )
        download.assert_called_once()
        return value

    def test_acquisition_is_exactly_one_asset_and_binds_approved_take(self) -> None:
        receipt = self._acquire()
        self.assertEqual("RESIDENT_FOR_APPROVED_TAKES", receipt["state"])
        self.assertEqual(["take-001"], receipt["approved_take_ids"])
        self.assertTrue((self.root / receipt["media"]["path"]).is_file())
        self.assertFalse(receipt["publication_authorized"])

    def test_acquisition_requires_an_explicit_take(self) -> None:
        self.allocation.write_text(json.dumps({"takes": []}), encoding="utf-8")
        with self.assertRaisesRegex(PermissionError, "APPROVED_TAKES_REQUIRED"):
            media_lifecycle.acquire_catalog_candidate(
                self.root, self.catalog, asset_id="asset-1", allocation_path=self.allocation,
                acquisition_dir=self.package / "acquired",
            )

    def test_release_requires_complete_clearance_then_keeps_receipt_and_removes_only_media(self) -> None:
        receipt = self._acquire()
        receipt_path = self.package / "acquired" / "receipts" / "asset-1.json"
        with self.assertRaisesRegex(PermissionError, "CLEARANCE_INCOMPLETE"):
            media_lifecycle.release_published_media(self.root, receipt_path, {"publication_status": "COMPLETE_PUBLIC"})
        media = self.root / receipt["media"]["path"]
        clearance = {
            "publication_status": "COMPLETE_PUBLIC", "asset_id": "asset-1",
            "acquisition_receipt_sha256": "sha256:" + hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
            "queue_open": False, "lease_open": False, "render_open": False,
            "evidence_dependency": False, "retention_required": False,
        }
        released = media_lifecycle.release_published_media(self.root, receipt_path, clearance)
        self.assertEqual("INTENTIONALLY_ABSENT_AFTER_COMPLETE_PUBLIC", released["state"])
        self.assertFalse(media.exists())
        self.assertTrue(receipt_path.is_file())
        self.assertTrue(receipt_path.with_name("asset-1.released.json").is_file())

    def test_terminal_publication_is_a_no_op_without_clearance(self) -> None:
        # A publication receipt alone must never turn a broad directory scan
        # into a deletion policy.
        result = media_lifecycle.collect_completed_public_media(
            self.root, {"status": "COMPLETE_PUBLIC", "video_id": "video-1"},
        )
        self.assertEqual("NO_ACQUISITIONS", result["status"])

    def test_collector_releases_only_matching_cleared_acquisition(self) -> None:
        def download(_candidate, destination):
            destination.write_bytes(b"abc")
        directory = self.root / media_lifecycle.STANDARD_ACQUISITION_ROOT
        with patch.object(media_lifecycle, "_download_commons_file", side_effect=download):
            receipt = media_lifecycle.acquire_catalog_candidate(
                self.root, self.catalog, asset_id="asset-1", allocation_path=self.allocation,
                acquisition_dir=directory,
            )
        receipt_path = directory / "receipts" / "asset-1.json"
        clearance = {
            "publication_status": "COMPLETE_PUBLIC", "youtube_video_id": "video-1", "asset_id": "asset-1",
            "acquisition_receipt_sha256": "sha256:" + hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
            "queue_open": False, "lease_open": False, "render_open": False,
            "evidence_dependency": False, "retention_required": False,
        }
        receipt_path.with_name("asset-1.release-clearance.json").write_text(json.dumps(clearance), encoding="utf-8")
        result = media_lifecycle.collect_completed_public_media(
            self.root, {"status": "COMPLETE_PUBLIC", "video_id": "video-1"},
        )
        self.assertEqual([receipt_path.relative_to(self.root).as_posix()], result["released"])
        self.assertFalse((self.root / receipt["media"]["path"]).exists())


if __name__ == "__main__":
    unittest.main()
