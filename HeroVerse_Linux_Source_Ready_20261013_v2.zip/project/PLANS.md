# PLANS.md — Modelo obrigatório de plano de execução

## 11/10/2026 — ligação atual pesquisa → modelagem → preparação de áudio

Escopo causal: ramo selecionado do Gestor não consumia pesquisa/modelagem para preparar a próxima entrega. Reusar observatório público (sem mídia), coortes exatas, diagnóstico próprio, fila transacional e produtor musical. Done when: despacho real testado; amostra/identidade inválida bloqueadas; proposta selada antes da preparação; repetição sem coleta/síntese; QA/direitos/release sem autoridade artificial. Nova candidata requer sua própria prova/adopção; provas anteriores não são repetidas nem transferidas. Resultado e limites em `output/runtime/gestor-central/maintenance-runs/audio-rest-research-production-integration-20261011/`.

## Retomada comprovada e instalação pendente — 08/09 12:48UTC

FEITO: diagnóstico token-endpoint único e recuperação separada com identidade
oficial do canal, proof0012c76c…/5d37aaexit0; um débito de quota, zero upload.
FEITO: auditoria geométrica4238cad3… e12testes; não repetir mídia/anotações.
FEITO FOCAL: watcher não bloqueante,10testes novos+1afetado PASS9f73f6.

1. Revisar encadeamento watcher/health/loop antes da manutenção única do lote.
   Done when: ausência de fonte/grant igual não bloqueiam os estágios; prova
   externa PASS é reconciliada sem nova chamada nem reescrever FAIL histórico.
2. Instalar pela manutenção segura existente, sem refresh na barreira zeroefeito.
   Done when: regressão encerrada, fontes preservadas, D116 PASS, novo processo
   e novo ciclo real12/12; health reconciliado. Testes focais não substituem isso.
3. Retomar integração PUBLICITY/calibração/composição e59estados daA12 pelo
   caminho crítico já descrito. Nenhum timing fictício, gold porIA, render
   prematuro ou promoção de Fase6. Os requisitos de mídia continuam intactos.

Evidência detalhada: output/qa/phase6/diagnostics/oauth-refresh-diagnostic-review-v1/verification.md
e oauth-watcher-unblock-v1/focal-tests-verification.md. Não reexecutar recovery-v2.

## Caminho crítico atualizado — 08/09 12hUTC

FEITO: fonte externaOpenImages adquirida e join real reaberto,6focaisPASS;
primeiroJPEG com MD5original/licença de copyrightobservados, não gold de
instâncias. FEITO: contrato varietyisolado14focais, sem integração real.
Ver verification.md em openimages-calibration-source-v1 e
docs/PHASE6_VARIETY_CONTRACT_VERIFICATION.md. Não repetir esses lotes.

1. Fechar incidenteOAuth11:40 com uma diagnose delimitada/sanitizada sob
   supervisão de processo; preservarFAIL/token e não mudar calendárioretry.
   Done when:causa observada ou indeterminação explícita, sem segredo/efeito
   no canal. Recuperação exige prova normal de identidade/cota separada.
2. Auditoria geométrica metadata-only quantifica ambiguidade de caixas sem
   apagar anotações; definir objetivo presença vs localização antes do
   corpus/policy. Done when:linhasoriginais/pins/métricas/testes/review, nunca
   calibração por existência de dataset. Pilotoinspecionado fora deholdout.
3. Continuar consumidorPUBLICITYruntime/calibração e compositor/variedade
   com fontes concretas e59estados pendentes; não liberarA12incompleta.
4. Integração/gatesA–D/GC01 e manutenção agrupada somente com provas próprias;
   nenhuma nova aprovação de áudio, render, publicação ou Fase6 até lá.

Cota62%restantes/reserva10%/52pp para6.55508dias; qualidade máxima e trabalho
crítico apenas. Isso não assegura desenvolvimento Codex ininterrupto.

## Limite de execução e caminho crítico — 08/09 10:53UTC

Cota observada64%restantes, reserva10%; decisão19c05a8d117eefd0 mantém
FULL_QUALITY_CRITICAL_PATH_ONLY. Não repetir controles/recovery/candidato
intactos nem iniciar fan-out discricionário. Permanecem integraçãoPUBLICITY,
calibração genuína, compositorAV/variedade, estados restantes e gatesA–D/GC01.
Auditoria PHASE6_CONTINUOUS_COMPOSITION_BOUNDARY.md explica por que unir
span_ids não corrige o contador legado por take; exige consumidor versionado
e prova de continuidade/exposição, sem relaxar thresholds ou ocultar cortes.

## Fechamento operacional concluído; próximos contratos — 08/09 10:45UTC

FEITO: par positivo/negativoV2 recuperado por receiptf477c45b… e consumidor
real092a9b; não repetir inferência ou replays intactos. Done when do incremento
restrito atingido, não calibração/publicity. Falhas e produtor antigo preservados.
FEITO: candidato real before/after a9a1f4e…/871d03d0… com17mudanças/83estados
preservados, testes e revisão semântica de037encerrados; zero redução observada.

SEGUINTE: integrar sucesso operacional como evidência separada de calibração
no futuroPUBLICITY, mantendo A12 incompleta bloqueada antes de efeitos.
Analisar composição contínua real vscontagem legada por take antes de produzir
cartelas:3ocorrênciasA/1B/1C são hipótese, não atalho por IDs. Fontes, ancestralidade,
movimento, spans,59estados pendentes, timing/áudio/QA e GC01 continuam
pelos contratos existentes. Referência temporal aplicável ainda não demonstrada.

## Fechar sem reinferir; corrigir composição sem alterar A12 — 08/09 10:26UTC

V2 executou dois controles reais com sucesso interno, mas o terminal agregado
FAILed4139ac… permanece válido: verificador rejeitou origem urllib de0B pinada.
Recuperar por módulo/teste novos e receipt separado; não editar produtor/raws,
não repetir modelo, PPMs, perfil ou testes intactos. Done when completo em
phase6-av-publicity-clock-fix-v1/control-worker-execution.md.

Em paralelo: contrato before/after A/B/C e aritmética exata da proposta em
PHASE6_COMPOSITION_REALLOCATION_CANDIDATE.md. Saída CANDIDATE_ONLY, redução
observada0, todas as strings/ranges/HOLD/identidade preservadas; não materializar
novas fontes nem declarar linhagem nova por ID. Focais novos/adversos e revisão
antes do preflight real somente metadata. Esse incremento não fecha59estados,
tempo, áudio, PUBLICITY, instalação ou vídeo.

Auditoria focal de calibração encerrada: PHASE6_CALIBRATION_SCOPE_AUDIT.md.
Não transformar10% de releases em N facial; não transformar23PCM em30.
Referência humana/publicada aplicável ainda não demonstrada. Continuar os
trabalhos independentes, sem inventar gold nem repetir alinhadores intactos.

## Sonda encerrada, produtor de controles em implementação — 08/09 10:02UTC

Reutilizar probe5b5eaec6… e terminala91fe247…; recuperação real62,593s
aprovou origens específicas, não calibração/modelo/vídeo. Não repetir sonda
intacta. Terminar/revisar/testar produtor dos dois controles e executar o lote
real uma vez: novo processo deve autenticar seu runtime e dados, preservar raw,
impedir segunda inferência após falha e reabrir dependências no fechamento.
Semântica e0ac1e49…, decoder e perfil permanecem pinados e reutilizáveis.
Instalação/manutenção agrupada somente após consumidores/contratos completos.
Reserva/cota:7573c80add3264ef,67%restantes; não iniciar expansão discricionária.

## Recuperação focal e controles reais — 08/09 09:48UTC

FEITO: dois controles decodificados, terminalb60cbf73… e13testes distintos
do decoder em dois lotes; semântica revisada10PASS. Não reprocessar os PPMs.
EM EXECUÇÃO: corrigir origem dos18 namespacesCV e typing.io/re; sonda antiga
FAILb8d400fd… preservada. Done when: focais adversos novos passam e sonda real
sucessora encerra com origens/profiling/containment verificados, sem inferência.
SEGUINTE: produtor dos dois controles, um runtime autenticado por processo,
duas inferências máximas, raw pinado, deriva/erro antes da segunda interrompe;
sanidade operacional não substitui domínio/human gold. Em paralelo, fechar
alocação editorial que reduza exposição real do painel; não alterar A12 por
aritmética condicional. Consumidor/instalação/A–D seguem critérios completos.

## Perfil capturado; próximo passo executável — 08/09 09:00UTC

Perfil realc9225445… concluído uma vez,12focais aprovados. Fechar sonda
isolada com uma validate_profile antes de imports e observação das origens
CV/NumPy/nativos; revisar/testar e executar sob supervisor existente.
Depois, controles frontal/negativo já selecionados, sob mesmo runtime/modelo,
com raw preservado e redução pura8testesPASS; sem refitting de threshold.
Não promover sanidade operacional a calibração de domínio. Consumidor composto
continua dependente dos requisitos reais de A/runtime/calibração; sem repetir
captura, fontes ou modelos íntegros para fabricar evidência equivalente.

## Scope reutilizável fechado — 08/09 08:46UTC

13testes novos do scope de replay passaram59,975s, sem repetir os14métodos
antigos; compatibilidade testada na API antiga. Próximo incremento crítico:
validar perfil local fixo, depois vincular origem executada e controles de
sucesso/calibração antes do consumidor composto. Não criar consumidor que
apenas retorne BLOCKED e anunciá-lo como integração pronta. A12 permanece
incompleta. Planejamento de cota usa decisãoee3214401fdaef6f/71%restantes,
reserva10% e âncora01:57 intacta; somente trabalho crítico já delimitado.

## Incrementos verificados — 08/09 08:32UTC

Triagem5190601 concluída, contato observado e fonte preservada. Reutilizar
inspection-v1-verification.md; candidato a gesto de registro036, não solução
agregada de concentração. Nenhum novo span/retiming ou direito concedido.
Replay de contraprova e scope canônico A passaram focais próprios (11+4 e25),
com correção de identidade do buffer após revisão independente. Próximo:
consumidor versionado composto, runtime fixo e calibração exata, sem repetir
decode ou A.verify para recuperar receipt íntegro. Esses novos componentes
ainda não participam da operação instalada. Manter Fase6 e gates A–D abertos.

## Continuação concreta — 08/09 08:09UTC

A aquisição5190601-v2 encerrou1GET/25.472.389bytes sem custo e sem erro;
18testesPASS, terminal e hashes reabertos. Evidência detalhada em
output/qa/phase6/diagnostics/visual-lineage-feasibility-v1/stock-candidates/acquisition-v2-verification.md.
Não repetir aquisição/probe de streams; seguir inspeção temporal e de quadros,
depois decidir intervalos editoriais permitidos. A12/V6 não alterados.
Em paralelo, implementar adaptador isolado do achado3PUBLICITY: argumentos
externos, root/tail/input descobertos via contexto existente, rejeição precoce
do plano incompleto e uma recomposição A apenas para candidato completo.
Done when focal: testes adversos/contagem de efeitos e prova A12 rejeitada
sem WAV/backend/artefatos; depois integrar ao consumidor versionado. Runtime,
calibração do detector e replay de contraprova permanecem gates separados.

## Resultado focal confirmado — 08/09

RecuperaçãoPUBLICITYv2 fechou11PASS/f8c0a9/33,044s;34métodos distintos
confirmados junto aos23anteriores, sem terminal agregado inicial presumido.
Reutilizar log86407e00…/verification.md. Próximo achado em análise readonly:
consumir A canônica com argumentos externos e recomposição existente, nunca
aceitar timeline ou safe-subset declarado pelo próprio candidato. Não editar
helpers históricos ou reexecutar A12 para obter a mesma prova. Aquisição
quarentenada do clipe segue independente, com limites e terminal persistente.

## Continuação focal — 08/09 07:49UTC

FEITO: contraprova visual implementada/testada16PASS e CLIreal40e40c.
Respeitar o resultado condicional6f01d293… sem novo render de entrada intacta.
EM EXECUÇÃO: PUBLICITYv2 expiração estrita, separado de v1 para não quebrar
pins de clean_plate/adapter11. Recuperar11testes sem terminal;23PASS observados
na primeira execução permanecem evidência. Não instalar antes do lote completo.
EM EXECUÇÃO: quarentena de fonte física de escrita Pexels5190601 para correção
de alocação, não catálogo genérico. v1 parcial preservado; segunda aquisição
com um GET hash-contado/ETag, timeout e receipt persistentes em wrapper focal.
Depois: confirmar conteúdo literal/contexto dos trechos, direitos e capacidade;
definir composição que reduza repetição realmente, mantendo áudio/copy/hooks.
59estados sem vínculo, calibração/áudio e B–D permanecem pendentes. Sem mudança
de fase, publicação, gasto ou repetição da manutenção1780PASS intacta.

## Instalação concluída; corrigir viabilidade antes de ampliar fontes — 08/09 07:12UTC

FEITO: manutenção66aae4cc,1780PASS/1skip,180schemas,554artefatos; D116726e233e…,
Gestor11852 recuperado e ciclo12/12. Não repetir essa regressão intacta.
PRÓXIMO em execução: contraprova reproduzível de exposição por linhagem,
apenas sobre A12/V4/V6 pinados; sem mídia nova ou autoridade produtiva.
A soma independente fa2627 refuta o preenchimento integral das unidades
pelas fontes four-criteria:40,832s frente a28,625s máximos de exposição10%
no teto do protocolo. A correção precede as59fontes pendentes e deve reduzir
exposição real, não renomear ativos, acrescentar silêncio ou relaxar gates.
Depois: sucessor editorial seletivo de fonte-base/composição com contextos
comprovados de preparação, registro e exame; identidade/copy/voz/hooks intactos.
Fontes substitutas suficientes ainda não comprovadas. Os quatro contextos
meteorológicos existentes u004/030/043/050 são candidatos de reuso, não solução
do excesso do painel. PUBLICITY tem cinco correções já conhecidas, não novo
pedido de autorização geral; A temporal/calibração e QA continuam necessários.
Detalhamento da prevenção: docs/PHASE6_VISUAL_FEASIBILITY_CORRECTION.md.

## A12 real fechada; instalação integrada é o próximo elo — 08/09 06:36UTC

Build único encerrado70aeb6exit0; receipt a307d2cc…, timeline c38a12e6…,
arguments b671e551… e A11 original10f31b09… conferidos9b358f. A12 contém
41vínculos/59estados pendentes e conserva bloqueios, sem timing fabricado.
Builder12/12PASS47,328s(13c247); não repetir a construção ou focais intactos.
Agora congelar código/testes e executar uma manutenção agrupada com daily.ps1,
inventário real de testes/schemas, regressão e recuperação D116. Colher o
terminal e receipts; se falhar, preservar FAIL e recuperar o Gestor antes
de corrigir somente a causa comprovada. Durante a execução, apenas análise
read-only da próxima lacuna crítica; nenhuma edição concorrente no lote.

## V4 concluído no escopo próprio — 08/09 06:18UTC

Quatro artefatos V4 hash-conferidos, transação encerrada4da453. Reutilizar
receipt8a4a33c6… e inspection69af2feb…; nenhum replay de geração/OCR ou novo
registro. Falta fechar os testes do builder A12, passar seus pins externos,
preflight e construir uma vez. Depois executar a instalação agrupada/D116.
O aumento para41usos não equivale a41%de qualidade ou conclusão do vídeo.

## Transação em curso — 08/09 06:14UTC

V4 passou preflight real; commit únicob17971ativo. Primeiro colher terminal,
conferir os quatro arquivos e seus hashes sem reinspeção. Depois fechar os
testes do builder A12, fornecer pins externos desses artefatos, preflight e
um único build. O build conserva A11, clock, união26 e os gates pendentes.
Rechecagem de bytes ancorados não pode fingir ser sink de inspector da mesma
chamada; o builder correlaciona o hash real de A antes de conferir os bytes.
Nenhuma nova autorização do proprietário é necessária para estes elos.

## Fechamento focal, ainda sem instalação — 08/09 06:05UTC

V4/joiner18PASS, schemaA12 oitoPASS, compatibilidade16PASS e consumidores
75PASS. Lote inicial de45:43PASS/2FAIL; correção das expectativas atuais de
dependências passou os dois afetados, com FAIL e snapshots preservados.
Próximo elo: materializador V4 exclusivo (um contexto genuíno de replay,
paridade canônica contra inspetor congelado) e integração A12. Rechecar
dependências/saídas após efeito; não redisparar uma transação incompleta.

## Sequência crítica atual — 08/09 05:58UTC

1. FEITO: registro exclusivo dos12estados/24direitos, receipt e2b0beb8…,
   24/24hashes conferidos e provas preservadas; não repetir raster/OCR/commit.
2. FEITO no escopo próprio: body-cache8PASS,V3-cache11PASS,leitorV6 onzePASS;
   recuperam provas exatas sem decodificação, não concedem nova aprovação.
3. EM TESTE: V4/joiner3/schema e A12/C15/adapter11; preservar despacho e
   limites de versões antigas, backups e rejeição de autoridade audiovisual.
4. PRÓXIMO: materializarV4 uma vez após testes e integrarA12 com caller pins;
   conservar A11/29usos/71pendentes até prova real do sucessor.
5. Depois, instalar o lote inteiro com uma regressão aplicável e D116,
   registrar resultados/recuperação e seguir a fila crítica sem pular gates.

## Checkpoint do lote crítico — 08/09 05:30UTC

- Concluídos: 17 focais de fonte, 27 de direitos, 13 do registro (cinco novos e
  oito afetados), mais o preflight real sem escrita. Corrigida antes dos testes
  a instabilidade de identidade single/batch; preservados snapshots anteriores.
- Em execução: materialização exclusiva70207e, uma única chamada, request
  a858dcf333febee3181e4771bc8d4b62528434c90c272f1c69d9905610bd2753.
  Preservar claim/saídas; não redisparar enquanto esta chamada existir.
- Próximos elos do mesmo lote: replay ancorado do V3, replay das provas body
  retidas no novo receipt, leitor V6, usosV4/joiner e A12/consumidores afetados.
  Reutilização exige âncoras externas e recomposição das dependências, nunca
  aceitar apenas uma flag PASS ou lista de arquivos autodeclarada.
- Só depois dos contratos e testes focais: uma instalação agrupada e D116.
  Nenhum avanço de fase ou publicação decorre deste checkpoint.

## Execução agrupada corrente

1. Reutilizar os dois QA estáticos encerrados, sem OCR/raster novos.
2. Revisar e testar replay record, facade de duas famílias e direitos fechados.
3. Concluir os dois testes de contrato real do registrador; os16transacionais
   passaram e não serão repetidos sem mudança afetada.
4. Preflight e materialização exclusiva de24documentos/dozeestados, com um
   replay por template e rechecagem de dependências sem novo decode por estado.
5. Integrar usos/V6/A versionados preservando A11 e seus29usos, depois uma
   única instalação/regressãoD116 para o lote. Nenhum contador41/59 é vigente
   antes da integração real; nenhum direito de imagem se transfere por alias.

## Lote em fechamento — registro e três movimentos

Receita record-learning passou21focais e gerou cinco conteúdos para seis
ocorrências, com bytes e observação visual registrados. Próximo: terminar
revisão/testes de QA independente; medir uma vez cada conteúdo (cinco OCR),
preservar os scans e verificar aliases antes/depois. Não gerar o sexto conteúdo
artificialmente nem chamar a ilustração de aprendizado operacional.

Three-moves tem dez testes de replay aprovados; executar replay real somente
na cadeia de materialização, sem repetição de OCR/raster ou prova herdada.
Após ambos passarem, criar os registros específicos e uma integração agrupada
versionada de doze estados. A11/29/71 continuam vigentes até prova real.

## Restrição de planejamento vigente, sem reduzir qualidade

Observação04:32:27UTC:87%restantes/reserva10; AHEAD_OF_PLAN9,643748pontos.
Preservarâncora e decisão dc0ec169…; concluir incrementos críticos já abertos
de fonte/replay e registro036–038. Não abrir frente discricionária extensa ou
novo fan-out; não repetir geração/OCR/ASR/testes intactos. Operação residente
permanece ativa sob gates, sem compras/resets/downgrade. Uma única integração
agrupada será feita após as provas, não manutenção por cada cartela.

## Próxima entrega concreta — duas famílias de provas, uma integração

Six three-moves encerraram geração e QA estática própria (receipt8a099616…,
report50015cb4…). Não repetir raster/OCR. Preparar replay técnico que recomponha
a prova antes de efeitos, sem herdar PASS do gerador, e registro de direitos.
Implementar separadamente receita/QA do lote036–038 conforme PhaseTask revisada.
Somente depois integrar os dois lotes ao consumidorA versionado, preservando
seus contratos distintos, narração, entradaslexicais e trêslinhagens atuais.
Não disparar regressão integral só por estes novos diagnósticos isolados.

## Fila atual após instalação e staging V6

Manutenção e58a92f9+D116 encerradosPASS, não executar novamente sem mudança
de motor que a exija. V6 staged e body-case20focais encerrados; receita18focais
e preflight real encerrados. Aguardar geração única30152; revisar seisPNG.
Concluir contraprova/correção focal do domínio de filtro do QA e executar
apenas sua suíte afetada; então uma mediçãoOCR por fonte, com scans preservados.
Nenhuma falha permite afrouxar tolerância ou repetir fontes intactas.

Auditoria agrupou71pendentes em23composições (33entradasestruturais/38lexicais).
Os6three-moves continuamWIP, não alteração de29/71. Preparar proposta concreta
de6estados de registro036–038; intenção é uma integração agrupada após provas
separadas, não consumidor novo por microgrupo. Não antecipar41/59, número de
conteúdos/linhagens ou calendários lexicais antes da evidência real.

## Execução sequencial vigente — 08/09/2026 04:09UTC

1. Encerrar manutenção corrigida e58a92f9/sessão65836 e conferir D116 real.
2. Executar 9+11 focais body-case; stagingV6 exclusivo com pins externos.
3. Executar16 focais da receita; preflight contra V6 real, sem geração antecipada.
4. Gerar seisPNG uma única vez; revisar todas e executar QA independente.
5. Somente com provas próprias preparar direitos e consumidor integrado.

Os números de testes acima são inventário preparado, não resultados PASS.
Falha4eaf3294/focal de recuperação1/1 continuam no histórico. Não repetir
V3/A11, áudio ou amostras intactas. Preparação isolada autorizada não libera
efeitos concorrentes à manutenção nem altera a fila de fases.

## Preparação delimitada paralela à regressão A11

Seguir docs/PHASE6_BODY_CASE_AND_THREE_MOVES_TASK.md: uma emenda editorial
case-only21estados/24strings/79preservados, depois seisamostras Name / Test /
Choose. Só NOVOS diagnósticos fora dos inputs/raízes congelados podem ser
preparados durante a manutenção; nenhum teste, OCR, geração ou engine é
executado/alterado em paralelo. A11 conserva29/71. O erro identificado no
downgrade histórico será tratado somente após traceback e recuperação do
Gestor; não suprimir o FAIL nem modificar schema para aceitar campo novo antigo.

## Fila vigente após execução A11 real

A11real06198f55…/receiptac5f859a… encerrado63ef21exit0 em03:26UTC;
29usos/71pendentes, nenhuma alteração do relógio/narração/união26/bloqueios.
Wrapper68ad0ebc… passou12/12fixtures24,329s(3c3bb3); integração4544c860…
passou9/9focais19,603s(be8edd). Materialização concluída; falta instalar o lote
por uma manutenção integral e D116. Prévia D14271b53ede… em03:27:19UTC:
12schemasPASS, zeroAPI/fila/write/custo, erroausente, NO_CHANGE.

Depois da instalação: prosseguir na cobertura audiovisual restante, sem
repetir V3/A11. Próximo candidato delimitado é a identidade de três movimentos
u032/u033/u035/u047/u048/u049: seisestados fora da união26, narração e linhas
V3/V5 idênticas. Ainda é preparação read-only, não receita/QA/capacidade. Antes
de gerar, resolver explicitamente o conflito caixa alta versus sentence case
da Bible, justificar identidade e registrar direitos próprios; nenhuma fonte,
tempo, score de qualidade ou aprovação será herdada automaticamente.

## Fila vigente — integração A11, sem repetição de mídia

Direitos reais das quatro perguntas registrados (ab6bdbb3…); caseV5 leitor
8/8PASS, V3usos9/9PASS e joiner8/8PASS, revisão independente sem defeito
identificado. Esses focais não reduzem o backlog operacional A10 antes da
materialização29/71. Próximos passos: (1) materializador exclusivo V3 e testes;
(2) A11/schema1.10 com evidências históricas V2/V3 separadas de V5 e novo
joiner; (3) consumidores C14/adapter10/B falhando fechado; (4) wrapper A11,
preservação do relógio, pausas, narrativa, união26 e todos os bloqueios;
(5) teste focal integrado, execução única V3 e A11, prévia D142 final;
(6) uma manutenção agrupada e recuperação D116. Nenhum OCR/render/ASR antigo
será repetido. Os seis arquivos existentes possuem backups SHA-conferidos.

## Fila atual após staging real das perguntas

Emenda b07bca4c… e projeção V5 7fd136fe… gravadas sob receipt3e22ff39…;
contratos pure/stager9+10PASS, sem processamento de mídia. Fonte própria
3ed0553a… passou10focais e rights15eb742a… passou17fixtures. Cachev2dos25usos
68221c67… passou7focais com replay real sem decode. Preservar todos os pins.

1. Registrar oito documentos de origem/decisão das quatro cartelas, com nota
   específica79fbcfa9…, claim exclusivo, cadeia reaberta e receipt de direitos.
2. Concluir leitor V5 com históricos V2/V3 separados e somente case2/98 novo.
3. Construir usosv3/joiner: cache25 íntegro + quatro fontes novas =29usos,
   27ativos,26conteúdosPNG,3linhagens e71estados sem vínculo. O quarto template
   não cria uma quarta linhagem; fontequestion herda composiçãofour-criteria.
4. Evoluir A11/schema1.10/C/adapter/dispatch em lote com backups byte-idênticos,
   predicates específicos por versão e gates conservadores. Preservar relógio,
   narração, união26 e blockers. Nenhum modelo21MB entra no rechecker legado.
5. Executar focais do lote e uma regressão agrupada com recuperação D116;
   demonstrar integração pelos argumentos externos e receipt novo, sem
   promover staging ou source_technically_verified a vídeo aprovado.

## Próximo vigente — integrar a contraprova, sem repetir mídia

Reconciliação real0ac7a3fb… PASS_STATIC_SCOPE_ONLY,0,453s em02:07:44UTC;
10/10focais a5f389 antes da execução. Sete medições de tinta em quatroPNG;
FAIL anterior, OCR e vetores de pixels/revelação preservados. Done when da
contraprova atendido; não equivale à admissão das fontes.

Fila sequencial atual: (1) contrato case-only v2 explícito e stager v2,
com replay sem decode/inferência e claim imutável; (2) quatro vínculos próprios
de fonte/receita/copy e registro de direitos limitado à nota específica;
(3) consumidor versionado de projeção/usos, preservando98estados,26alvos,
relógio/narração e todos os blockers A10; (4) testes focais negativos e
regressão agrupada com recuperação D116 quando o motor mudar. Só após o
vínculo operacional comprovado reduzir75estados sem fonte. Áudio, calibração,
timing, composição e B/C/D permanecem posteriores e não recebem aprovação
por esses testes estáticos. Não repetir manutenção A10 intacta.

## Capacidade para continuar — D172

Leitura nativa98%restantes, renovação15/09/2026 01:22:52UTC. Nova âncora
01:57:38UTC e reserva10%, decisão d9be9e5c… GREEN/ON_PLAN.21/21focaisPASS;
nenhum resetresgatado/compra/downgrade. Continuar caminho crítico com reuso de
provas e paralelismo delimitado; não repetir manutenção/mídia intactas por
existir saldo. Não assumir causa da renovação alterada ou cota ilimitada.

## Próximo imediato — contraprova OCR sem repetir inferência

QA das quatro perguntas produziu FAIL eac99752… por envelope do detector,
não texto incorreto: copy4/4 e checks de pixels/revelação passaram. Conservar
as fontes e os4scans. Medir somente o contorno de tinta para associar cada
linha ao campo, sem ampliar safearea/regiões ou baixar confiança; testar
caixa deslocada/cortada, texto trocado e contraprovas. Somente após esse novo
receipt poderá ser evoluído o stagercase e integrado o lote. Testes6+7jápassaram
para o contrato antigo, que continua recusandoFAIL; não os apresentar como
novaQA ou reexecutar sem alteração. Não repetir manutençãoA10 intacta.

## Checkpoint vigente — A10 instalado; QA das quatro perguntas em execução

Lote87be8b35/final50b68c85 PASS em08/09/2026 01:28:01UTC:1.556PASS/1skip,
175schemas; D1162b2aa4c7… e cinco snapshots íntegros, ciclo novo12/12,
GestorPID14048. Done when da instalação A10 atendido, não o da produçãoAV.
QuatroSVG/PNG question-field gerados uma vez em1,375s, receiptf63ac629…,
diretório test-questions-v1/static-a4630336964863b442fdc027. Root observou as
quatro imagens; texto e layout legíveis na inspeção estática, sem inferir
retenção/movimento/timing. Próximo: QA independente de pixels e OCR local;
depois revisão própria de direitos, emenda explícita de capitalização e vínculo
de fontes/uso. Não regenerar imagens, repetir manutenção ou reduzir75pendências
antes da integração efetiva. Plano detalhado na PhaseTask de perguntas TEST.

## D-171 — caminho crítico audiovisual em execução

Continuação independente durante a instalação: `docs/PHASE6_TEST_QUESTIONS_SOURCE_TASK.md`
define4fontes candidatasu019–021/takes024–027. Receita/testes diagnósticos em
output/qa/phase6/diagnostics/test-questions-v1/, ainda não executados. Reusar
primitivas da linhagem owned-four-criteria-panel-v1, nunca ordinais0/4 ou2/4.
Duas mudanças case-only (trêsstrings) são propostas explícitas para cumprir a
Bible; emenda posterior obrigatória antes do consumidor. Fontes atuais75
pendentes não diminuem por código escrito. Sem geração durante manutenção.

A10 real concluída no escopo literal em01:07:13UTC, receipt e0f66701…,
timelinef4be1a12…/42eaa6f7…,15,938s. Reusar, sem rebuild. Done when restante
do lote: regressão/install agrupados+D116. Preservação A9/custo0/gatesfalse
conferida; revisão independente fechou dependências pós-build. Próximo trabalho
produtivo continua dependente das fontes restantes e sincronização comprovada,
sem reduzir guard de direitos, áudio ou compositor para chamar vídeo de pronto.

Atualização posterior ao checkpoint00:23: v2 de usos foi executada00:41:31UTC,
receipt9e14abf9…,25usos/23ativos/22hashes/3linhagens/75pendentes, custo0.
Não rematerializar nem repetir imagens/OCR/ASR. Próximo imediato: encerrar
focais do wrapper transacionalA10, revisão independente e uma execução real
com pins externos; conferir preservação integral de relógio/pausas/união26.
Depois congelar lote e executar UMA manutenção agrupada/regressão+D116.
Os bloqueios produtivos de tempo, áudio, compositor e demais fontes continuam.

Fontes compactas e revisão/registro próprios encerrados no escopo restrito:
receipt5dfd9d4f…/request029d9066…,12OWNEDbindings/1linhagem,6,797s, custo0.
Não rerender/re-OCR/re-registrar. Próximo: concluir contrato v2 de25usos,
replay exato das13ligações antigas e12novas com75estados fora, depois integrar
o consumidor temporal sem transformar uso untimed em span/horário/admissão.
Regressão e instalação agrupadas somente após congelar o lote compatível.
Os focais17+4+1direitos e12registrador são execuções distintas, não a
regressão integral. Gestor vigente segue instalaçãoA9 verificada abaixo.

Próxima PhaseTask ativa: fontes compactas e usos rastreáveis, detalhada em
docs/PHASE6_TWO_COLUMN_REMEDIATION.md. Implementar inspector especializado,
direitos próprios e vínculo25usos/100 sem agendamento; preservar75fora do escopo.
Agrupar compatibilidade e testes antes do próximo deployment, sem rerender.

Lote A9 encerrado: manutençãoa4f5d1da/finaleb285901 PASS,1.469PASS/1skip,
173schemas e D116a503fb61… com ciclo novo12/12 e GestorPID2216. Reutilizar
essas provas; não repetir regressão sem nova alteração aplicável. Continuar
fontes compactas/uso untimed/direitos em lote compatível, sem relógio inventado
ou schema legado ganhando suporte silencioso. Fase6 segueIN_PROGRESS.

Integração realA9 encerrada3f1961exit0,4,438s: receipt36c585e7…,
timeline08c58eb7…/SHA5105f3a4…; ainda BLOCKED_INCOMPLETE. Leitor novo,
A9/schema1.8,C12/schema1.11,adapterv8 e dispatchB implementados. Sem nova
montagem/inferência ou alteração de narrativa. Último passo deste lote:
preview read-only, regressão integral pelo daily e recuperaçãoD116 com novo
ciclo válido. Não alterar novamente código congelado durante os testes.
Falhas focais e real935227 preservadas; detalhes na PhaseTask de
docs/PHASE6_TWO_COLUMN_REMEDIATION.md. Após instalação, continuar vínculo
produtivo das fontes/consistência, tempos reais e A–D; a Fase6 não está pronta.

Staging real encerrado8ba18bexit0: amendment87567b59…/SHAfb2543b0… e projeção
V3d629bce9… existem com10/10focaisPASS. Não reexecutar o writer: saída
existente/parcial falha fechado. Próximo incremento é leitor amendment-aware
com recomposição independente, compatibilidade V2 e rejeição de mutações de
88estados/entradas/D169. Conectar a A somente com versão e pins próprios nos
consumidores afetados; nenhum rótulo staged é autorização produtiva.
Agrupar mudanças compatíveis antes de manutenção; não repetir provas de mídia.

Ensaio compacto fechado por677fe3df…PASS_STATIC_SCOPE_ONLY, não pela simples
saída do gerador:12estados lidos,582.144pixels de foco exatos, OCR reutilizado,
HOLD e regiões de mudança preservados. Três suítes separadas:14receita,
11classificaçãoOCR,6perfil; não apresentar31como uma execução única. Sem
repetir provas intactas. Próximo incremento: migração editorial versionada
dos12estados/9unidades, compatibilidade das decisõesD169 e os demais88estados,
antes de qualquer consumo porA/B/C. O planoV2 continua a fonte ativa atual.

Proposta compacta materializada (não admitida):14/14focaisPASS;12PNG/SVG em
2,571s com11rasters e HOLD reutilizado. Não renderizar novamente as imagens
intactas. Finalizar somente a verificação independente de pixels/OCR por12estados
e o relatório do ensaio; depois integrar o sucessor de forma agrupada com
expectativas de texto/estado e controles de escopo. A produção ainda não recebe
os pins da proposta e a manutençãoD171 PASS não precisa ser repetida por esse
diagnóstico isolado, sem alteração do motor carregado.

Instalação encerrada: tentativa636c9615, final31cfd112 PASS,
1.444 PASS/1 skip em 930,974 s; 172 schemas, D11619b5e05e… e ciclo4cb60c42…
12/12. Os planos de reexecutar a instalação nos checkpoints abaixo são
históricos; reutilizar recibos/snapshots enquanto a base permanecer intacta.

Próximo incremento crítico: resolver a legibilidade integral das duas colunas,
antes de vincular os 12 estados à execução. Done when: copy explícita por estado,
contagem de todos os textos simultâneos, geometria e fonte dentro da Bible,
FACT e inferência distinguíveis, HOLD literal conservado, mudança versionada
com os planos anteriores intactos; OCR deve cobrir cada estado e não pular os
11 takes cujo on_screen_text antigo é null. Não reduzir limites para aprovar
9–19 palavras. Uma amostra estática não aprova movimento, timing ou produção.
Depois: demais fontes, scheduling com referências reais, banda/grade, QA
intencional de holds, admissão e execução A–D; nunca timestamps fictícios.

Incremento de uso estático encerrado no escopo literal: 12/12 focais PASS;
execução real b7b76158… em 8,063 s confirma 13 usos/11 imagens/duas linhagens.
Faltam bindings dos demais estados e integração explícita ao scheduling A/B/C;
isto não aprova as 13 utilizações para produção. Congelar este lote junto à
correção de manutenção (14 novos + 45 afetados PASS) e executar instalação/D116.
Não modificar código durante a regressão nem reabrir os artefatos de mídia
intactos para simular produtividade. Continuar depois pelo mapeamento das
duas colunas e fontes restantes, em paralelo apenas a tarefas independentes
que não alterem a base de prova em execução.

Prioridade corretiva vigente: fechar a corrida de snapshot/relógio do lock na
manutenção. A tentativa 94c3c90d passou 1.418 testes (1 skip), mas falhou no
boundary final; não repetir mídia ou A8. Done when: contraprovas determinísticas
de rotação, horário futuro, expiração, identidade e falha de leitura; captura
real e instalação pelo protocolo de manutenção com fechamento final verificado.
Nenhum aumento de lease, tolerância temporal ou desativação de gate é permitido.

Manutenção1b05273b falhou por duas expectativas legadas de teste;1.416PASS/
2FAIL/1skip,869,973s, runtime recuperadoPID18260. Fixtures corrigidas com backups,
focais3/3PASS(e251260f…). Prioridade imediata é fechar revalidação integral+D116
sem modificar novamente a implementação audiovisual ou repetir mídia intacta.

Incremento literal visual encerrado no seu limite: leitor13/13PASS;
A8/schema1.7 com9novos+6afetadosPASS em lotes separados; rootC11/adapterv7/B+
bundle15/15PASS64,407s, receiptdfbeebc02714250849c64845290e9181628e0c4381a734aa733a9a9b5041c4ab.
RealA8 executada20:38:42UTC em4,297s, receipta944a4f5…/timeline9542021b…,
26alvos literalmente recompostos e nenhum agendamento/render/publicação.
Done when deste incremento atendido, não EtapaA: nova fonte é aditiva ao A7,
100estados/71cues/90fragmentos/51PCM preservados e blockers produtivos intactos.
Próxima sequência: manutenção segura/regressão/recuperação D116 deste lote;
resolver população/calibração acústica elegível sem reusarcohort30 inválido;
vincular os100estados a fontes/intervalos permitidos e resolver banda/grade,
depois B/C/D com evidência própria. Pesquisa de alternativa temporal é read-only
e crítica; não autoriza voz nova, timestamps fictícios ou baixar os mínimos.

Incremento cap71 encerrado no escopo literal: A7/schema1.6 com fonte
caption_intent; adapter passou12/12focais; integraçãoA passou8/8novos e5/5afetados;
root10/10(C10+bundle) e5/5(adapterv6+B), em lotes separados. RealA7 levou4,594s,
receipte0e3a53c…/timeline05a4cc9c…;71cues planejados/zeroagendados. Novo bundle
36ad5f46… conserva cada campo do909f7dbd… e acrescenta somente binding3ddd6d1d….
Done when do incremento atendido:51PCM reabertos e71cues preservados; nenhuma
resegmentação, timestamp inventado ou autoridade. Não é Done when da EtapaA.
Próximo: declaração visual literal integral antes de calibração, separando
ausência de ativo de ausência de decisão de revelação. Mínimo26D169 preservado;
os21declarados/51excluídos do bundle parcial não o substituem.

Prioridade corretiva antes de compilar o bundle novo: A5 contabilizaria apenas
quatro unidades declaradas como se sua união temporal fosse completa. Corrigir
em A6/schema1.5, C9/schema1.8 e adapterv5, com backups byte-idênticos. Done when:
bundle parcial conserva exclusão das unidades desconhecidas; não consome
evidência/policy temporal; não declara `all_required_evidence_live`; testes
negativos e consumidores confirmam bloqueio. O mínimo histórico26 não encolhe.
A conclusão do planejamento literal completo deve ser independente de timestamps
calibrados; a proteção parcial não encerra essa integração nem a Etapa A.

Execução real A6 concluída, receipt09858928…/timeline07084756…,6,422s:
11fontes; declared4/conservative51/scopefalse. Provas focais novas e dirigidas
passaram;70casos restantes tiveram69PASS/1FAIL de fixture, corrigido e retestado
1/1PASS; C9 passou seus sete testes. Os resultados não serão somados como uma
única execução nem usados como aprovação de mídia. Após
esse lote, integrar o plano de captions71 já existente e as decisões D169 sem
refazer copy, observações ou criar tempos fictícios. Manter todos os bloqueios
de sources/spans, publicidade, áudio e release ainda sem comprovação.

1. Integrar os onze estados próprios já rasterizados ao inspector read-only,
   prendendo receitas, PNG/SVG, TakePlan, Bible, fontes e decoder exato. Não gerar
   novamente mídia intacta nem contar estados como variedade independente.
2. Evoluir A5/schema1.4: contratos STATIC_IMAGE/VIDEO_CFR, sequência completa por
   unidade, alvos lexicais preservados, entrada não agendada representada como
   incompleta. Fechar rechecagem de dependências antes do retorno.
3. Evoluir C8/schema1.7 e adapter de duas colunas v4: PNG real [0,1), permanência
   limitada pelos frames de saída e filtros específicos. Recompor A pelos
   argumentos externos, nunca pelo candidato. C segue sem autoridade LIVE.
4. Rodar focais com código congelado, guardar resultado e identidade de cada
   caso, verificar regressões de contratos legados e inputs adulterados. A
   primeira execução intermediária teve 42 casos/3 erros e não é aceite.
5. Integrar B/residência/publicity/capacidade e QA de permanência intencional
   sem converter ausência de duração de PNG em duração fictícia e sem esconder
   congelamentos indevidos. Só então fechar lote e realizar manutenção D116.
   B/schema de direitos1.1, verificadorv2 e registro03fbe140… já possuem provas
   reais restritas às onze imagens, com consumidorB e14,448s/12testes do verificador.
   Completar agora o binding audiovisual, não reabrir o registro íntegro.
   Não executar publicity
   sobre uma timeline fictícia só para obter recibo: sua fonte/metadata deve
   coincidir com o plano aplicável. O QA de hold continua pendente, sem tolerância
   genérica a frames duplicados. Registro editorial não conclui esta etapa5.
6. Completar a união temporal e obter evidência genuína de calibração/percepção;
   compor e avaliar o candidato pela cadeia A–D vigente. Fases e gates mantidos.

Done when deste lote: consumidores realmente usam as fontes tipadas; fontes e
decoders são rechecados; testes positivos/negativos e legados passam sobre uma
versão congelada; artefato real permanece bloqueado quando falta qualquer prova.
Done when da produção não muda: áudio, semântica, sincronização, movimento/holds,
direitos e demais gates independentes precisam de evidência aprovada.

## D-170 — fallbacks transversais, incorporados à operação vigente

**Lote encerrado com evidência técnica, não projeto concluído.** Manutenção
9b618b19 e D116321a0845… PASS:1.292testesPASS/1skip,170schemas,554itens,
Gestor5292 recuperado, ciclo12/12 e preservação operacional comprovada. O run
FAIL anterior permanece intacto. Não rerodar o lote sem alteração material.
Mapa20/17 instalado, sem fornecedor alternativo validado por mera listagem.
Próximo caminho crítico: integração tipada das fontes visuais e dos consumidores
do sucessor A–D, seguida de evidência temporal/sonora, QA e publicação quando
efetivamente elegível. Fase6 permanece ativa; não antecipar Fases7–8 ou pedir
aprovação administrativa que já foi concedida.

Correções dos dois grupos de falha estão prontas e revisadas: fixture de runway
independente da conta e supervisor v2 compatível com o launcher aninhado. Executar
agora uma nova manutenção integral, preservando o run FAIL anterior; conferir
contagem, skip, snapshots operacionais e recuperação D116 antes de encerrar D170.
Código/testes/schema congelados durante essa execução. Nenhuma fase será promovida
por testes de infraestrutura; o caminho audiovisual continua pendente.

Primeira manutenção terminou reprovada, com recuperação do Gestor comprovada
(run2f7de15f, PID14280). Próximo subpasso obrigatório: isolar fixtures de runway
da policy viva e corrigir a consulta de contenção sob o launcher real, preservando
fontes/testes anteriores. Done when: contraprovas pelo `.venv/Scripts/python.exe`,
flags/tetos intactos, fixture determinística, revisão independente e nova manutenção
estável com resultado completo e D116. Não repetir mineração/mídia ou os renders
históricos para compensar essas falhas. Não promover o lote pelo1271PASS parcial.

Revisão independente acrescentou uma falha concreta ao lote: `_cache_valid` do
miner de fixtures aceitava inventário vazio. Corrigir contrato/caminho de cache e
testar sem reexecutar fixtures históricas ou inferência. A implementação do miner
altera a identidade de novos jobs; a regressão histórica deve referenciar os runs
anteriores comprovados, não produzir novos para fazer o teste passar.

A mesma entrega corrige `Retry-After` em pesquisa/download do Commons. Data HTTP
ou segundos do servidor nunca são truncados para uma chamada precoce; espera acima
do orçamento retorna DEFER com evidência e preservação do manifest. Sem cooldown
distribuído anunciado, rede real nos testes ou nova licença/fonte escolhida.

Cobertura implementada em `operation_fallbacks.py` e consumidor executivo/schema
1.5; fontes históricas preservadas, 20 rotas/17 domínios, zero troca equivalente de
fornecedor declarada validada. Testes de integração ajustam a versão nova sem
carregar o novo campo nas fixtures legadas. Detalhamento:
`docs/FALLBACKS_OPERACIONAIS.md`. Implantação/revisão integral ainda pendentes.

Pedido expresso do proprietário: distribuir fallbacks pela operação inteira. Complemento, não substituição da integração audiovisual pendente ou dos gates. Raiz/STATE/masters00/01/07/10/11/prompt05 e contratos relacionados relidos; fases5–8 autorizadas em sequência, Fase6 ativa. Custo técnico R$0,00, sem troca silenciosa de voz/identidade, métricas privadas por públicas, direitos ou capacidade não validada.

Implementar e distinguir: PROVIDER_SWITCH (executor alternativo efetivamente validado), EXACT_CACHE_REPLAY (mesma prova), CHECKPOINT_RECOVERY (recuperação de artefato/ponteiro), RETRY_SAME_PROVIDER (nova tentativa limitada), DEFER (adiamento) e BLOCKED (lacuna). DEFER/BLOCKED não serão contabilizados como provider alternativo ou funcionalidade recuperada.

Sequência concreta desta entrega: (1) mapa executável de cobertura por domínio e evidência, incorporado ao acompanhamento operacional, com lacunas/estados honestos; (2) integrar recuperação do cache de segmento pela âncora imutável antes de qualquer rerender; (3) limitar transporte do observador oficial diário para que timeout retorne ao retry existente, sem chamada/quota extra; (4) testes focais de falha/corrupção/reuso/timeout; (5) revisar consumidores e realizar uma manutenção/regressão aplicável com recuperação D116, não uma por patch. Código/receipts anteriores congelados antes de alterações. Fora de escopo desta unidade: novo renderer/TTS/modelo pago, login, produção indevida, troca de ativo pinado, abandono de gates e execução de fases futuras.

Done when verificável: cache perdido é restaurado a partir da prova integral sem render; corrupção preservada bloqueia sem FFmpeg -y; timeout da Data API cabe no lease e percorre RETRY_WAIT existente com uma tentativa; mapa distingue implementado/validado/declarado/indisponível e expõe o que ainda falta por domínio; testes negativos passam; runtime recuperado após manutenção; nenhuma alegação de fallback universal elimina áudio/alinhamento ainda ausentes. Continuar depois a integração audiovisual, sem substituir essa entrega por outro PNG isolado.

## D-169 — próxima sequência após o insumo visual testado

Encerrado somente o insumo estático005–007: seis estados próprios, revisão/correção de ambiguidade,14testes e13artefatos verificados, sem nova inferência/voz/AV. Reutilizar geraçãoeb8525d7…/receipt076ec5be…; não repetir os quatro PNGs preservados ou o lote existente. Intenção29resolvida documentalmente por observações, sem fontes/spans finais. União mínima26 não deve ser chamada de união integral; cohort30continua inválido.

Próxima unidade independente útil: variantes SEM marcadores do painel u019/u021, a partir da receita existente, preservando exemplo005–007 para callbacksu044/u045; depois composições específicas de u026/u036/u041 e contratos/spans restantes conforme intenção7375e478…. Não escolher fontes por nome/role sem observação. Done when por insumo: copy/Bible/semântica/identidade/continuidade/safeareas testadas, ativo próprio ou permitido e receipt integral; sem autoridadeAVprematura. Agrupar integração de todos os consumidores51unidades/71cues/90takes numa entrega coerente após evidências A, sem adaptar apenas contadores nem refazer medições no verificador. A nova composição não dispensa LIMIT​ED scope, concentração/reuso, direitos/publicity ou avaliação final.

## Retomada operacional D-167/D-168 — 07/09/2026

Concluídos os subescopos supervisor Windows (17testes), reconciliação ASR sem inferência (11testes/8contraprovas) e mudança da única heartbeat para retomada horária sem manutenção incondicional. Não repetir essas provas intactas. Nada disso conclui o áudio ou a Fase6.

Próxima entrega crítica em curso: fontes visuais adequadas aos exemplos u005/u006/u007 e intenção restante, preservando narração e hooks. Done when do insumo estático: correspondência literal/atribuição ao medo, dois estados por exemplo, Bible/safe areas/duas linhas, ausência de informação futura, continuidade da ilustração, hashes e inspeção independente; não incluir aprovação audiovisual. Depois fechar contratos/spans reais e união FINAL de alvos, selecionar holdout/policy genuínos e aplicáveis, resolver percepção/duração, compilar A–D e integrar conjuntamente media/quality/release/publication ao namespace sucessor. A inspeção achou incompatibilidade51unidades/71cues/90takes com os consumidores legados; não adaptar apenas um contador nem usar stem como mixagem final.

Done when da integração posterior: extração do vídeo exato presa por hash/render/timeline/mix, dimensões de áudio com provas aplicáveis, replay sem subprocesso/inferência, rejeição de master trocado, gold de domínio errado, cache antigo, erro/timeout e temporalidade sem calibração; regressão/manutenção D116 após mudança real e recuperação verificada. Não implementada nem aprovada neste checkpoint. Continua autorizada sem consulta administrativa. O último reset não será consumido automaticamente; custo técnico R$0,00.

## D-166 — retomada executiva com capacidade real renovada

Reset gratuito autorizado e aplicado uma vez; nova observação100%restantes/schema-validada e rebase real, sem compra/downgrade. Prioridade imediata continua resolver o áudio e sua integração, não novos catálogos ou repetir renders/testes encerrados. Frentes delimitadas: supervisor local de avaliação com timeout/recuperação; análise factual das divergências de pronúncia; eliminação de dependências artificiais na preparação temporal sem dispensar referência genuína; integração e checagem principal. Cada frente preserva fontes/receipts atuais e só altera arquivos próprios. Não promover os resultados auxiliares a aprovação conjunta.

## Continuidade integral reafirmada; capacidade oficial abaixo da reserva

O proprietário voltou a exigir execução até todas as fases funcionarem, sem encerramento por componente. A autorização técnica permanece; não se deve apresentar um instrumento auxiliar como solução integral. Auditoria retomou a cadeia de áudio/A–D: faltam referências temporais compatíveis e validação completa, não confirmação genérica do proprietário. O contrato LIVE de A foi lido e preservado; não transformar score/ASR em gold.

Preflight oficial materializado em07/09 13:05:42,930610UTC:9% restantes, CRITICAL_RESERVE,2resets gratuitos não usados. Decisão `output/operations/codex-usage/history/codex-usage-08c002b7b684d875.json`, SHAa537918265644f7d03a807ed798df701c7340de17c223ad972f8340df6b6e5c6, idêntica ao latest. Renovação13/09 02:15:36UTC. Sem compra/reset/redução de modelo. A consulta é materialmente nova e substitui a leitura anterior10%; não representa cota esgotada.

Próxima decisão estritamente externa: autorização explícita para consumir um dos dois resets gratuitos. Isso libera capacidade de desenvolvimento, não aprova áudio, render, publicação, medição futura ou as fases. Até essa decisão, encerrar somente o checkpoint seguro sem ampliar trabalho Codex; preservar a rotina local. Existe uma única heartbeat diária ativa `hero-engine-rotina-di-ria`, mantida sem duplicação/alteração. Não confundir esse monitor com desenvolvimento ininterrupto. Depois de eventual reset: materializar a resposta nativa e revalidar/rebasear a âncora por evidência antes de retomar o caminho crítico já listado, sem ressíntese ou medições intactas repetidas.

## D-164 — instrumento automático executado; restante ainda não aprovado

Entregues `hero_engine/audio_perception.py`, 16 testes focais, schema, bundle Microsoft pinado e medição real de 202,780 s/195 janelas em 95,029098 s. Zero repetição de voz/ASR/master. Verificador separado: 14 checks PASS, rede/processo/inferência bloqueados durante replay. Receipt ca771052…; verificação 20bf33c4…. A média geral estimada 2,8111 não é prova de qualidade máxima ou limiar de aprovação. Gates produtivos intactos; nenhuma publicação/deploy de runtime.

Próxima sequência e Done when por unidade em `docs/AUDIO_AUTONOMO_ESTADO_2026-09-07.md`: validação do domínio/erros → pronúncia/prosódia → referências temporais/duração → consumidor produtivo com recuperação/regressão → A–D/QA/release real. Não pedir escuta rotineira ao proprietário, não inventar gold ou limiar, não usar o cohort antigo incompatível. Supervisor com timeout rígido/RAM e recuperação de lote permanecem antes de runtime contínuo; a CLI diagnóstica não é serviço pronto.

## Retomada: avaliador sonoro automático, sem escuta rotineira do proprietário

Pedido expresso posterior: o sistema deve avaliar áudio; não usar o proprietário como executor da revisão. Mantidos A–D, gold temporal e todos os gates. Primeiro incremento delimitado: adapter local DNSMOS P.835 para medições auxiliares de qualidade de fala, ruído e qualidade geral, com versão/modelo/licenças pinados, cobertura integral, controles negativos e cache. NISQA rejeitado pela licença não comercial dos pesos. DNSMOS não demonstra pronúncia, prosódia editorial ou timestamps e nunca aprova o vídeo sozinho.

Entradas: master normalizado já existente (sem ressíntese/normalização/ASR repetidos); código/artefatos Microsoft na revisão `591184a9fcb2cbdec02520fed81a32bbbf9d73ff`; ONNX Runtime/NumPy/SoundFile/FFmpeg locais já disponíveis. Fontes externas e licenças lidas; modelo de 1.157.965 bytes, blob Git `814b8dc6dafa729c0b821a64bef2e7156dc0c01a`. Operação local, sem API de inferência, cadastro ou cobrança; duas threads e memória/tempo limitados. Sem fan-out, novo vídeo ou mudança do runtime.

Saídas previstas: `hero_engine/audio_perception.py`, testes focais, modelo/licenças em diretório próprio e receipt por janela sob diagnósticos. Done when deste incremento: fonte/hash validados; análise real do master executada; ausência de cobertura/NaN/mismatch rejeitada; ruído e silêncio artificiais corretamente diferenciados como controles; replay sem nova inferência; limitações e versão exatas persistidas. Isso entrega um instrumento automático, não resolve sozinho a calibração temporal ou o aceite integral. A integração ao gate produtivo só pode ocorrer após validação específica; não remover guards para obter PASS.

## Bloqueio vigente do objetivo — 07/09/2026 04:35 UTC

Objetivo BLOCKED pela ferramenta oficial após recorrência da dependência sonora, mantendo escopo integral e Fase 6 IN_PROGRESS. A unidade estática abaixo está encerrada; não regenerar seus cinco estados nem usar suas posições de caracteres como relógio audiovisual. Nenhuma nova confirmação administrativa é necessária.

Próximo insumo externo delimitado: revisão perceptual realmente realizada da narração completa, conforme `docs/REVISAO_INICIAL_AUDIO_VIDEO2.md`. A anotação do cohort antigo de 30 está proibida por incompatibilidade; não transferir ao proprietário a correção da seleção interna. Quando houver revisão ou referência aplicável, retomar a intenção visual integral e o pré-registro correto, integrar evidências na cadeia A–D e executar os gates. Uma escuta geral isolada não aprova timing, duração, vídeo, publicação ou as fases seguintes.

Conservar os observadores locais existentes e os receipts concluídos. Não declarar outras tarefas internas concluídas nem esperar em um processo de render inexistente. O bloqueio não é cancelamento, redução do objetivo ou desligamento do runtime; a retomada exige nova auditoria do estado real.

## Unidade encerrada: four-criteria-layout-v1 — composição estática, não AV aprovado

Executada em 07/09/2026 04:23 UTC: cinco estados SVG/PNG próprios e contact sheet, receipt `static-1ada6ec8746d09b6061b634c`, SHA `2b0b541bbbeacf9b7c62d6dbe85bd34ac789b0e7da96d86e1f0ce49a76a7415f`. Oito testes focais PASS em 0,056 s; geração estática 1,881 s. Inspeção estática realizada; verificação posterior dos 11 artefatos, cinco PNGs, marcadores e reaproveitamento sem render PASS (8b000c). Evidência/comandos em `output/qa/phase6/diagnostics/four-criteria-layout-v1/verification.json`.

Os critérios desta unidade estática foram cumpridos; os de sincronização/publicação não fazem parte desse aceite. Não executar novamente a geração nem seus oito testes com entradas intactas. Próximo passo permanece fechar o restante da intenção visual e a união integral; este desenho resolve somente a composição proposta para u034 e não altera a incompatibilidade do cohort antigo. A integração produtiva deverá vincular este novo ativo e seus eventos a A–D, direitos, escopo, concentração e gates; não substituir o baseline diretamente.

### Contrato preservado da unidade

Objetivo único: materializar a composição estática específica da unidade 034 (takes 051–054), corrigindo a associação indevida de três cartões a quatro critérios. Autorização: execução contínua D-047 dentro da Fase 6; tarefa diagnóstica local, sem publicação. Fontes: TakePlan, Style Bible e auditoria temporal 3a6aa9e… hash-pinned. Instruções carregadas: STATE, MASTER_SPEC, EXECUTION_PROTOCOL, PHASES_AND_GATES, masters 10/11, prompt 05_RUN_PILOT e especificação do sucessor AV; D-047 prevalece sobre aprovações administrativas antigas.

Preservar texto, áudio, hooks, fontes, parâmetros e receipts históricos. Produzir receita local determinística, cinco estados SVG/PNG (introdução e quatro critérios), manifesto de proveniência e teste focal sob `output/qa/phase6/diagnostics/four-criteria-layout-v1/`. A composição mantém no máximo duas linhas, paleta/fonte/safe area da Bible e posição fixa; não exibe toda a lista simultaneamente. Um único painel/linhagem, não quatro fontes para simular variedade.

Done when: textos exatos e ordem recompostos; estados com geometria consistente; nenhum texto futuro antecipado no estado anterior; fontes pinadas; zero timestamp inventado; render estático reproduzível e inspecionado; negativos de texto/ordem/identidade rejeitados. Fora de escopo: áudio, vídeo animado, A–D produtivo, integração à fila, novos modelos/dependências, alteração do baseline, duração, publicação e aprovação integral. Ausência de referência temporal mantém a troca dos estados bloqueada. Esta unidade pequena não autoriza fan-out ou processamento pesado na reserva D-152.

## Checkpoint de capacidade — 07/09/2026 04:08 UTC

Decisão oficial persistida `codex-usage-b3802cd962ba419d`: 10% restantes, reserva de 10 pontos, `RESERVE_ONLY`, zero ponto disponível acima da reserva. O modelo não foi alterado e nenhum reset ou compra foi acionado. Manutenção D116 encerrada; não repetir seus testes. Manter o runtime local existente, sem criar outro monitor ou despertar QR Dolar.

A inspeção de três PNGs-fonte foi concluída sem render: cartões sem texto em `scriptural-mechanism-original-v1`, `action-plan-original-v1` e `three-card-decision-original-v1`. As fotos não demonstram as revelações lexicais, os quatro critérios ou as cinco categorias exigidos pela narrativa. Não promovê-las por seus nomes/roles. A união visual integral continua pendente, seguida de nova seleção disjunta e policy temporal aplicável; o cohort de 30 continua incompatível. Escuta genuína do master pode ocorrer independentemente dessa preparação, mas não anotar o cohort inválido.

Done when deste checkpoint: observação schema-válida e byte-idêntica ao histórico, fontes inspecionadas identificadas, estado e relatório atualizados, nenhuma capacidade fictícia promovida. Não equivale a resolver a produção ou encerrar o objetivo. Os próximos elos produtivos e seus critérios permanecem descritos abaixo; não prometer execução pesada contínua com a reserva atual.

## Próxima ação — intenção visual restante e novo cohort, não anotação do v1

Audit3a6aa9e… reconstituiu a cobertura51unidades/90takes/71cues e identificou três alvos adicionais no cohortv1:020,034,041. Conhecidos22alvos, no máximo27candidatas na velocidade correta, incompatíveis com mínimo30 da policy6587e640…. Manter pedido/cohort/policy anteriores preservados e não os usar em anotação, inferência ou calibração. A contraprova foi encerrada e não requer novo processamento.

Resolver agora a intenção visual das unidades marcadas `REMAINING_VISUAL_SCOPE_UNRESOLVED`, a partir de fontes/receitas específicas, sem promover o baseline reprovado ou mascarar fonte desconhecida como corte não semântico. Done when: todos os eventos/cues finais e exceções estruturais explicitamente ligados aos inputs deA, união integral reconstituída e cohort disjunto. Só então pré-registrar nova policy/cohort aplicável antes das estimativas; não escolher27por conveniência nem reutilizar a ordinalidade da seleção antiga sem refazê-la. Critérios acústicos não podem ser reduzidos após observar resultados. Escuta/anotação genuínas continuam necessárias; nenhum timestamp foi preenchido por este diagnóstico.

## Próxima ação delimitada — fechar a união de alvos temporais

Preparação07/09 03:49UTC concluída: policy6587e640… registrada, cohort candidato30PCM/15START/15END com offsets literais e nove verificaçõesPASS. Não repetir montagem, ASR, instalação, busca de arquivos ou esta preparação. A seleção ainda não representa os eventos do vídeo inteiro: antes de estimativa ou pedido de anotação, recompor a união final de captions/eventos dos inputsA e confrontar com o cohort. Done when: união integral explícita/hash-bound, nenhuma sobreposição, voz/velocidade/perfil preservados; caso haja sobreposição, revisar e pré-registrar antes das estimativas, sem reduzir qualidade/narrativa para preservar30amostras. Não consumir seleção parcial como holdoutLIVE.

Policy/pedido/cohort/prova estão identificados no topo deSTATE e no pacote de revisão inicial. O limite800samples é critério proposto deste ensaio, não resultado empírico ou tolerância universal. Anotação e escuta seguem ausentes. O próximo trabalho deve resolver essa dependência concreta; nenhuma nova arquitetura/catálogo ou regressão integral do código intacto é necessária. D116 já está encerrada.

## Checkpoint encerrado — D116 PASS; próximo caminho é o tratamento real

07/09 03:31UTC: manutenção753a9beb concluída, regressão1164PASS/1skip permitido,169schemas, recuperação3968→6660 e novo ciclo12/12. Receipt finalSHAec8a37ac217fc5f34bea4e6e58155abf74d64b7456ac37ce61fa757dcd203e50 e D116SHAaa5e1cc7f8954528ff6e4bc3434d465f92f6d584832ab373954359e58f35dd85; snapshots/schema reconferidos. Os planos antigos de esperar sessão19735 ou executar manutenção novamente estão encerrados por este checkpoint, preservados apenas como histórico. Nenhuma sessão de manutenção/watcher deste lote continua aberta.

1. Manter os observadores e o Gestor existentes, sem novo polling duplicado ou repetição da regressão intacta. Done: recuperação e ciclo operacional posterior já observados; próximos checkpoints seguem a fila canônica.
2. Fechar a dependência sonora com escuta registrada do master exato e referência temporal humana/dataset anotado compatível. Insumos já reunidos em `docs/REVISAO_INICIAL_AUDIO_VIDEO2.md`; não refazer pacote. Done: observações genuínas, origem/hash/escopo válidos, policy anterior às estimativas e calibração pelo contrato, não autorizações ou ASR rotulado como gold.
3. Integrar a timeline editorial elegível e os eventos/spans ao sucessor A–D, preservar locks e comprovar duração sem preenchimento artificial. Done: recomposição real, admissão e capacidade válidas, render retomável, avaliação independente com todos os gates críticos PASS e pacote congelado; não fixture ou grafo incompleto.
4. Publicar pelo release já autorizado, confirmar o vídeo público exato e aguardar a janela de medição pré-registrada. Done: receipt público e avaliação real do tratamento fecham GC-01; só então reavaliar a transição 6→7, com prova de ciclo anterior conforme D107/D109. Aprendizado aplicado, segunda medição e produto permanecem fases posteriores, sem promessa de conclusão antecipada pela manhã.

Gate atual17/18 aplicáveis satisfeitos em seus escopos, não percentual do projeto. A dependência de revisão/anotação é evidência externa real, não nova aprovação entre fases. Custo adicionalR$0,00; sem gasto, reset, downgrade, troca de canal ou publicação nesta manutenção. D152 continua limitando desenvolvimento discricionário extenso após o checkpoint seguro.

## Regressão corretiva D-162 pronta para manutenção integral

Três causas de fixture/descoberta corrigidas e fontes preservadas;29focaisPASS e1165IDs de inventário/descoberta coincidentes. Executar novamente `daily.ps1` com os mesmos guards: os inputs de testes mudaram, portanto a regressão anterior não é prova do lote novo. Preservar544baa2eFAIL e a recuperação3968. Done when permanece receipt finalD116, snapshot estável, contagem exata, recovery e novo ciclo12/12. Esta correção não remove a dependência sonora nem libera produção/publicação.

## Próxima ação em horário seguro — reutilizar sessão19735

Manutenção4a425913 adiada antes de qualquer parada pelo checkpoint protegido `job-fa767913b48bd4fa78f40a62`, devido02:40:35UTC. Watcher local read-only19735 já ativo; não duplicar, não reduzir guard e não antecipar coleta/API. Acompanhar até estado terminal real; timeout só encerra a observação. ApósSUCCEEDED, novo preflight do procedimento diário e uma tentativa na janela elegível. Se falhar, recuperar pelo própriofinally e investigar somente o erro real. Pedido de execução pela madrugada prioriza este caminho, sem prometer fases dependentes de audiência/calibração que ainda não existem.

## Retomada delimitada — manutenção D116 do código já corrigido

Após retomada expressa, executar uma única manutenção necessária, sem novo desenvolvimento, subagentes ou efeitos de mídia. A dependência humana de áudio não impede esta integração de runtime. Preflight read-only `local-runtime-preview-badbe6f537645826f51712a8` (07/09 02:21:47UTC, terminal50c338):12fontes/schemaPASS, nenhum blocker/erro de ciclo, zero escrita/API/fila. GC21 já usa os dois IDs qualificados no disco; não reimplementar a correção. Cota oficial consultada uma vez:13%restantes, sem mudança de modelo/reset/compra; classificar este lote como recuperação operacional crítica, não retomada de trabalho discricionário extenso.

Comando: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/daily.ps1`, parâmetros de proteção padrão. Preservar históricoFAIL, fila/leases/checkpoints/cotas/OAuth/receipts e mídias. O protocolo faz handshake, verifica a cadeia exata antes da parada, migra apenas visões derivadas, inventaria schemas/testes, executa regressão em snapshot estável e recupera em finally. Não realizar parada ou limpeza manual alternativa.

Done when: receipt final schema-válido preso à regressão e novo ciclo12/12; evidência pós-reinício/estado/quota/efeitos/OAuth inalterados sob barreira; barreiras próprias removidas e runtime recuperado. Falha não concluiD116: conservar seu resultado, confirmar recuperação e tratar somente a causa observada. Não concluiA–D, vídeo2 ou Fase6; revisão sonora e demais gates continuam obrigatórios.

## Bloqueio externo confirmado — objetivo BLOCKED, Fase6 IN_PROGRESS

A contraprova de07/09 02:03UTC não encontrou referência sonora aplicável nas pastas autoritativas examinadas. O único candidato textual é revisão de três frames, explicitamente não humana e sem escuta. Terceira recorrência do mesmo impedimento: objetivo marcado BLOCKED, sem apagar escopo ou desligar runtime. O pacote inicial já existe e não deve ser recriado. Próximo insumo é a escuta/anotação real indicada nele; autorização genérica não substitui observação. D116 e demais etapas seguem pendentes, com restrição D-152 sobre execução extensiva. Não declarar espera em render: nenhum novo job foi iniciado neste turno.

## Entrada de revisão reunida — não repetir preparação

`docs/REVISAO_INICIAL_AUDIO_VIDEO2.md` reúne master exato, fragmento audiovisual existente, seis intervalos PCM e protocolo de registro. Links/intervalos/hash conferidos em67699a; documentoSHAf3a0d42d1c6bde650b5f4b5f04f5070a5c984a2582357971ad77284cb94a8a3d. A escuta e as anotações temporais continuam ausentes. Não tratar o pacote como revisão concluída, amostra holdout selecionada ou policy pré-registrada. A próxima ação produtiva exige a evidência real e capacidade compatível; não gerar mais documentação equivalente, mídia repetida ou instrumentos sem relação com esse bloqueio. GatesA–D e pendênciaD116 preservados.

## Ritmo de execução D-152 — 07/09/2026 01:54 UTC

Preflight oficial atualizado:13%restantes, reserva10,3pontos até renovação12/09 23:15:36BRT; decisão `codex-usage-17588c7f443b6963` schema1.2/twin PASS. `AHEAD_OF_PLAN` exige **não iniciar mais trabalho discricionário extenso** neste checkpoint. Integração anterior encerrada e preservada; não repetir seus48testes nem seus processamentos. Nenhum subagente, manutenção integral ou novo monitor iniciado. Sem redução de qualidade, compra ou reset automático; runtime local autorizado não foi interrompido.

A fila técnica permanece: referência temporal/escuta genuínas aplicáveis → timeline editorial válida → admissão/capacidade → composição → QA → release. DeploymentD116 continua pendência independente, não resolvida por esta leitura de tarefa/ciclo. Retomar lotes delimitados sob capacidade compatível e fonte real, sem transformar espera em progresso produtivo. Done when deste checkpoint de governança: observação oficial materializada pelo módulo existente, schema/twin íntegros, ritmo recalculado com âncora preservada e estado/documentação atualizados. Não encerra produção nem fase.

## Unidade encerrada — fonte verificada incorporada ao compositor, 07/09/2026 01:45 UTC

Done when desta integração cumprido: verificador puro v1, adapterv3 e C v7/schema1.6. Root26/26 testes de body/controles PASS33,990s (95099/90932d); root14/14 Cintegração/regressão PASS84,816s (25877/810220); executor separado8/8 verificador PASS17,863s (57528/d97e08).48testes de software, não gates do vídeo. Revisão separada do body sem achado material; root corrigiu/revisou controles numéricos e residência C antes dos testes. Arquivos anteriores preservados.

Integração REAL `phase6-av-render-recipe-b5184c1916f816e14f77e81b`, SHA9cd642c86a13bd0483339c3d08755ad39d736a6674981adc8de15e98f03b32f0: reabre A original, conserva o hook e prende a clean plate com25dependências. Continua `BLOCKED_INCOMPLETE`, zero spans/eventos resolvidos, grafo null e autoridadesfalse; fonte provada não inventa timeline. Relatório `output/qa/phase6/diagnostics/av-clean-plate-binding-v7-root-result.json`, SHA9693a737373b4614ff058d7d096d9a9256907a1194edbafcfea0e545fcbed40c. Terminais brutos preservados; extração do JSON separou marcador `ok` intercalado do unittest, sem repetir compilação ou testes.

**Próxima dependência principal é evidência sonora, não mais variantes visuais.** Auditoria focal não encontrou referência temporal/perceptual genuína aplicável ainda não ligada. Preparar policy temporal pré-registrada e pacote delimitado para anotação/escuta independente do master exato; não inventar gold nem executar estimativa alvo antes da policy. Resultado202.780ms é candidato de escuta, não timeline aprovada; não acrescentar5.020ms para atingir a grade mínima207.800ms. Qualquer duração precisa função editorial demonstrada. A manutenção D116/deployment continua unidade independente autorizada, a ser executada pelo protocolo seguro, sem alterar o FAIL histórico. Não repetir o processamento das entradas já concluídas.

### Preflight preservado da unidade

Continuação anterior: **PROGRESS**, pois criou mídia real, validou1.800frames e provou replay sem execução nativa. Preflight atual reabriu STATE/PLANS, bodyadapter integral, fronteira C/schema e testes envolvidos. Cinco arquivos anteriores copiados e comparados por SHA em `source-freeze-av-before-clean-plate-binding-v1`, terminal548948. Fase6, runtime/filas/receipts e áudio preservados.

Implementar verificador puro da fonte já concluída; binding opcional `clean_plate_receipt` no adapterv3; representação estrita em C v7/schema1.6. Reabrir receipt, runner e cadeia integral sem executar processos ou escrever no namespace; confrontar canal/Bible/TakePlan, asset, linhagem, contagem e intervalo de origem. Ausência de binding mantém bloqueio explícito; divergência rejeita. Fonte tecnicamente comprovada não vira `source_ready` produtivo nem substitui A/gates. Não gerar mais mídia, ASR, voz, corpus ou framework nesta unidade.

Done when: C recompõe A real e incorpora a fonte real sem eventos inventados; negativos recusam adulteração/troca de fonte/linhagem/contagem/escopo/autoridade; casos sem binding e controles anteriores preservados; nenhum subprocesso/escrita na compilação; source receipts anteriores intactos. Em paralelo, auditoria read-only identifica se existe referência temporal/perceptual genuína ainda não ligada; ausência deve ser explícita, não uma aprovação fabricada.

## Unidade encerrada — base limpa própria, 07/09/2026 01:17 UTC

Done when desta fonte cumprido com mídia real: 1.800 frames RGB exatos, relógio/stream/formato válidos e replay com `subprocess.Popen` bloqueado, zero chamadas. Arquivo `two-column-clean-plate-v1-ef0d956239c512d0/clean-plate.mkv`, 9.498.584 bytes, SHA7031f3abc85881e10e2c8b78875b935fa07705a1844dfbeb98b1513cc7529471; receipt SHA25fe4e9047971a8f88d86ce5de07f8ea15b042831ab5fa96b2e277689811ac7a. Todos sob `output/qa/phase6/diagnostics`. Root15/15 testes finais PASS3,258s, terminal32699c. Run41389/5fab9d e replay21984/ae25df. Evidência consolidada `clean-plate-v1-root-result.json`, SHA8e4bd3eb139a6711288d4480bf37dddcff3b138ac91aa0592c1a5f20e9ace5d5.

Render78,219s, probe1,250s e decode/hash101,875s, cada um executado somente uma vez. São tempos destas etapas neste equipamento, não promessa de cadência. Revisão independente e contraprova sobre stdout anterior evitaram rejeitar campos vazios realmente emitidos pelo FFprobe; parser continua estrito. O ativo próprio não foi admitido e não altera a incompletude A/B/C nem a Fase6. Voz, hook anterior, API, runtime e publicação não foram repetidos.

Próximo caminho crítico: ligar esta fonte comprovada à receita sem inventar spans, concluir intenção/timeline editorial válida e as referências temporal/perceptual exigidas, depois admissão/capacidade, render composto, QA integral e release. A ausência de calibração genuína continua explícita; não usar dois ASRs como gold nem relógio do baseline como editorial. Não produzir mais variantes de base plana nem novo framework de render. Trabalhar somente sobre a dependência faltante, com testes focais quando o código mudar.

### Preflight preservado — 07/09/2026 01:01 UTC

Pendência obrigatória T11 (09/09/2026), antes da próxima produção operacional:
integrar preparação ativa de recursos antes de **cada tarefa** — medir memória,
armazenamento e carga; liberar somente recursos próprios encerrados quando
necessário; rechecagem imediatamente anterior, execução limitada, monitoramento
e liberação final dos recursos próprios. A preparação pontual dos testes T11 não
conclui essa integração permanente. Preservar aplicativos do proprietário,
evidências, fixtures, modelos, caches úteis, bancos/auxiliares, locks e mídia aprovada.

T16 (09/09/2026): preparo ativo implementado e testado **localmente** nas entradas
de voz/montagem Phase6; candidata `5cad13a873065539`, sem adoção operacional.
Medição por etapa, passagem única sobre capturas descartáveis próprias, rechecagem,
RESOURCE_WAIT, serialização e restauração do escopo; nenhum parâmetro de qualidade
reduzido. Evidências e limites em
`output/runtime/gestor-central/maintenance-runs/task16-active-resources/RESULTADO.md`.
Não equivale a cobertura/admissão de todos os runners históricos, pico de RAM
calibrado, implantação geral, D-116 ou ponte supervisor/executor. A próxima
dependência é a validação/adoção versionada pelo protocolo existente, sob pausa
até autorização específica; T15 permanece prova apenas da versão anterior.

Escopo fechado: materializar uma única fonte reutilizável RGB `#081827`, 1920×1080, 30 fps, 60 segundos/1.800 frames, sem texto, áudio ou imagens de terceiros. Os 60 segundos são capacidade do ativo, não duração narrativa. Reutilizar identidade e paleta da receita de duas colunas, preservando uma única linhagem e os arquivos anteriores.

Executar somente após revisão do runner e testes focais: preflight local, render FFV1 limitado a 256 MiB/90 s, probe até 30 s, framehash RGB24 até 120 s, captura limitada e journal retomável. Orçamento de disco: 512 MiB mais reserva de 5 GiB; RAM mínima 512 MiB, reavaliados imediatamente antes das etapas. Leitura preliminar de disco às 01:00 UTC: 17.674.305.536 bytes livres; não substitui o preflight do efeito. Nenhum novo ASR, síntese, mux anterior, API ou reinício.

Done when: arquivo real decodificado com 1.800 frames e relógio íntegro, pixels literais 08/18/27 em todos os frames, zero stream de áudio, dimensões/formato conferidos, ferramentas/fontes/receita/runner/saída presos por hash, receipt e replay sem efeitos. Resultado será `SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED`: não concede admissão, liberação jurídica, aprovação perceptual, sincronização, render produtivo ou publicação. Se a etapa falhar, preservar efeito/journal e corrigir somente a causa demonstrada.

## Unidade encerrada — fronteira estrutural PCM e revelação lexical distintas

Fechamento 07/09/2026, 00:41 UTC: A v4/schema1.3, body adapter v2 e C v6/schema1.5 integrados e versionados. Root **33/33 PASS em60,095s** (74513/123234); executor A **12/12 novos PASS13,222s** e **3/3 controles legados PASS19,853s**. Revisão separada sem achado crítico adicional; pins finais A/schema conferidos por teste positivo e adulteração individual. Evidência `output/qa/phase6/diagnostics/av-unit-boundary-v4-root-result.json`, SHA2293e64174cf58d6a20ff9434ba0609cb122afec0b0709c7040ad46b9d4d2d1a. O teste legado permanece byte-exato. Evitada antes da execução a descoberta involuntária de toda a classe antiga importada. Não repetir grupos intactos.

Done when do **contrato estrutural** cumprido. A aplicação produtiva ainda não aconteceu: a integração real reabre os argumentos originais incompletos, com zero eventos/spans; o master editorial continua incompatível com sua duração. Os testes preenchidos são fixtures identificadas. Não houve efeito de mídia, API, gasto, admissão, deployment, publicação nem mudança de fase.

Próxima dependência independente de mídia: fornecer a base limpa própria para a composição de duas colunas por meio da receita local existente. Preflight deve identificar o gerador, paleta/dimensões/frames, espaço/RAM/tempo e namespace diagnóstico exclusivo; fonte gerada precisa de receipt, hash, origem, direito próprio e decodificação, conservando uma linhagem real. Não reutilizar vídeo antigo com textos embutidos, não chamar arquivos equivalentes de fontes distintas nem criar placeholder de qualidade. Isso não resolve a ausência de eventos A, calibração lexical, percepção, banda/grade, admissão ou QA final. A ligação futura deve consumir a timeline editorial elegível, nunca reciclar os tempos do baseline190.800ms como se fossem do master202.780ms.

### Preflight e critérios preservados da unidade encerrada

Continuação anterior classificada PROGRESS: integração A→C/two-column implementada e testada, não simples status. Preflight reabriu STATE/PLANS e o código/schema das fronteiras A/C/adapter; masters/protocolo/fase já lidos permanecem aplicáveis. Antes de editar, oito fontes foram copiadas e tiveram SHA-256 comparado em `output/qa/phase6/diagnostics/source-freeze-av-before-unit-boundary-v1` (terminal796741). Runtime, filas e artefatos históricos não serão alterados.

Implementar A v4/schema1.3 com intenção visual1.1 e evento `UNIT_BOUNDARY`/`WHOLE_UNIT_PCM_START`: frame exatamente derivado do início PCM, unidade e primeiro fragmento presos, sem chars/alignment/incerteza lexical. Intenção1.0 continua interpretada pelo contrato antigo e não autoriza esse novo evento. Preservar calibração de revelações e união integral dos alvos lexicais; não excluir evento malformado do holdout. No adapter, somente os nove estados de início de unidade podem consumir essa fronteira; take014/016 continuam lexicais e take021 mantém continuidade HOLD. C evolui explicitamente para a nova versão, mantendo autoridade falsa e sem grafo integral.

Done when desta unidade: código/schema interoperáveis; fronteira adiantada/atrasada, unidade errada, chars internos, simulação de alinhamento, reclassificação semântica e versão antiga adulterada rejeitados; controles lexicais/holdout preservados; integração real incompleta continua sem efeito; fontes antigas intactas, revisão separada e evidências arquivadas. Não repetir síntese, ASR, mux, cota ou testes globais; execução focal proporcional à superfície alterada. Isso não aprova sincronização lexical, percepção, duração, fonte limpa, render ou publicação.

## Unidade encerrada — integração preparatória das duas colunas, 07/09/2026 00:20 UTC

Done when **desta unidade preparatória** cumprido: 12 estados literais, 64 especificações de texto relativas, layout medido, fontes pinadas e ligação real A→C com schema 1.4. Root: 5 testes novos PASS em 20,236 s e 7 regressões C PASS em 19,731 s. Executor separado: 13 focais PASS em 11,931 s. Revisão independente final sem novo defeito crítico no escopo. Evidência `output/qa/phase6/diagnostics/av-render-recipe-two-column-v5-root-result.json`, SHA 37c498355ca6123e3517f41b602e3a0e6aab8b3981f1cdf12dac911b6138fe73. Não repetir esses grupos com código/fontes intactos.

**Não encerra A, C ou a Fase 6.** A real ainda não contém eventos/spans, logo nenhum intervalo visual foi inventado e nenhum filtro executável foi liberado. O teste com span preenchido é fixture de serialização, não calibração LIVE. Copy, voz, identidade, hooks, direitos e custo zero permanecem preservados.

Próxima unidade crítica, antes de qualquer render do corpo: resolver a interface de eventos entre A e esta receita. Separar fronteiras estruturais de PCM inteiro das duas revelações lexicais internas (u011/u012, palavra `write`); não exigir alinhamento lexical fictício para uma borda estrutural nem dispensá-lo para uma revelação real. A atual não suporta `WHOLE_UNIT_PCM_BOUNDS` em `visual_events`; qualquer extensão exige versão, fontes anteriores preservadas, intenção explícita, recomposição e testes negativos, sem mudar a semântica dos contratos antigos. Done when: contrato compatível representável em A, tempos estruturais calculados apenas a partir de PCM inteiro, e revelação interna continua bloqueada sem calibração real. Não executar outro ASR para buscar concordância.

Dependências seguintes, sem paralelizar efeitos: comprovar clean plate próprio e fonte contínua; fechar evidência temporal/perceptual e banda de duração editorial; ligar admissão/capacidade à receita; render retomável; QA integral; release/publicação. A ausência de referência temporal genuína permanece lacuna explícita, não aprovação pendente do proprietário. Nenhum requisito de áudio, movimento, semântica ou direitos é relaxado para acelerar.

Manutenção: auditoria read-only identificou que D-148 já corrigiu a seleção GC-21 em disco, mas o processo vivo iniciou antes do patch. Não criar segunda correção nem reescrever o FAIL histórico. Aplicar por manutenção verificada e novo D-116 quando o lote de código de runtime estiver congelado, conservando recuperação em `finally`; liveness isolada não aprova manutenção. Evitar reinícios repetidos a cada arquivo editado.

### Escopo e preflight preservados da unidade encerrada

Turno anterior classificado PROGRESS por montagem real e replay guardado. Preflight atual reabriu STATE/PLANS/contrato AV, código A/C/two-column, seus schemas e fontes de narração; os masters/protocolo/fase lidos integralmente no contexto permanecem aplicáveis. C v4, schema e teste real foram preservados byte a byte em `source-freeze-av-render-recipe-v4-before-body` antes de edição. Nenhum novo diagnóstico do hook, render, áudio ou API está autorizado por esta unidade.

Escopo crítico: adaptar a receita existente dos12estados take012–023 à timeline A, preservando copy, colunas, paleta e identidade; integrar essa preparação em C após recomposição independente dos argumentos de A. Estados semanticamente dependentes da fala precisam de eventos compatíveis e evidência temporal, sem reaproveitar cortes antigos. Ausência mantém tempos/filtros executáveis indisponíveis. Done when: fontes/layout/textos recompostos, interface integrada e schema válido, controles de troca de estado/tempo/coluna/copy e evidência real de bloqueio sem eventos; grafo de fixture nunca vira receita LIVE. Revisão separada e testes focais antes de concluir a unidade. A/C integrais e publicação continuam pendentes.

## Unidade encerrada — hook audiovisual QA, 23:52 UTC

Done when do mux QA cumprido: montagem real,150packets visuais preservados,120.000samples PCM idênticos, relógios corretos, quatro terminais concluídos e replay explícito sem processo nativo.15testes rootPASS0,920s. Receipt edac0530…/arquivo dc22036a… e contraprova em STATE. Isso encerra esta unidade, **não a produção integral**. Não reabrir o mux ou criar nova derivação equivalente. Próxima ação útil deve avaliar o audiovisual existente e/ou fechar a receita do corpo com os tempos elegíveis; não mais provas estruturais equivalentes do hook. Sem gold temporal/calibração, não promover word timestamps. O déficit de duração e os demais gates abaixo continuam bloqueios reais a resolver, não autorização pendente do proprietário.

## Entrega verificada — 06/09/2026, 23:32 UTC

Próxima unidade imediata após revisão independente: montar **QA audiovisual do hook3–8s** por stream-copy do candidato visual existente e slice exato[72000,192000) do master. A origem reaberta prova unidade003[72000,166208) e pad existente até192000; não são120.000samples de fala. Não depende de inventar tempos de palavras. Done when: um mux lossless retomável,150pacotes visuais/PTS idênticos e120.000samples PCM idênticos ao slice, preflight/intent/terminal/hash/replay; status apenas AV_HOOK_LISTENING_CANDIDATE_NOT_APPROVED. Sem ressíntese, render visual, publicação ou alteração de A/B. Essa entrega vem antes do contrato visual do corpo porque torna possível avaliar imagem e fala juntas usando material concluído; não substitui as dependências abaixo.

A ligação independente A→C está implementada e testada. C v4/schema1.3 também recompõe o footer editorial real do take003 por adapter v2: 150 frames, 22 dependências e dois textos relativos ao namespace. Isso encerra a unidade de **integração preparatória parcial**, não o Done when de C. Nove testes integrados passaram na v3; quatro testes da comparação final canônica passaram na v4 em38,968s, incluindo troca de número inteiro por decimal e adulteração de filtro. Evidência exata `output/qa/phase6/diagnostics/av-render-recipe-visual-integration-v4-root-result.json`. Nenhum render/ASR/voz/API foi repetido.

Próxima dependência crítica: a receita do corpo/two-column precisa consumir spans e eventos de A com temporização compatível, em vez dos cortes históricos. Preparar apenas o contrato independente que reutiliza os compiladores existentes; nenhuma montagem integral antes da timeline editorial elegível e admissão. Done when: estados visuais literais, fontes/fontes tipográficas pinadas, tempos derivados de eventos observados, cobertura e negativos demonstrados; falta de tempo calibrado bloqueia, não usa limites antigos. A referência temporal anotada genuína, percepção/pronúncia e déficit de duração permanecem lacunas de A, separadas das tarefas independentes. Não acrescentar catálogo, repetir medições encerradas ou declarar aceleração global sem um vídeo integral liberável.

## Unidade ativa — ligação real A→C, preservando a receita v1

Continuação classificada PROGRESS: master real e contrato testado alteraram estado e delimitaram a próxima integração. Preflight reabriu STATE, masters00/10/11, protocolo01, fases07, prompt05, contratoAV e código/schema A/C/admission. Custo0, sem execução de mídia ou runtime. v1 preservada byte-exata em `output/qa/phase6/diagnostics/source-freeze-av-render-recipe-v1-20260906T2300Z` antes de qualquer patch.

Escopo: evoluir C com binding independente do documento PHASE6_AV_RAW_ARGUMENTS já definido na admissão e chamar o verificadorA existente; registrar caminho/hash/identidade/schema das entradas, recompor integralmente a timeline e manter incompletude/FIXTURE sem autoridade. Não confiar nos inputs ou flags do candidato. Em paralelo, auditoria restrita do compilador visual existente para sua ligação allowlisted; não criar gerador universal ou fixture como solução final. Fora de escopo: render, síntese, ASR, API, publicação, runtime, mudança de narrativa e alteração de gates.

Done when: C consome os argumentos originais arquivados e chama o verificador real, negativos de troca de argumentos/canal/protocolo/hash/arquivo e falsa aprovação bloqueiam; teste de contrato completo permanece FIXTURE e contraprova das fontes reais continua corretamente incompleta. A lacuna de ouro temporal é preservada. Verificação independente do patch e testes focais antes de qualquer integração posterior. Não reexecutar normalização ou diagnósticos intactos.

## Fechamento limitado — 06/09/2026, 22:55 UTC

Normalização e sua contraprova read-only encerradas. Contrato puro de receitaC implementado em três arquivos novos e revisado: root7/7PASS em19,084s, sessão22947/892e11; agente7/7PASS em16,718s. Somente FIXTURE compila grafo e permanece explicitamente não executável; blueprint LIVE opaco fica sem grafo. **A EtapaC não está concluída**, não há receita LIVE apta e a capacidade continua projetada. Não repetir esses testes inalterados ou medições de áudio para fabricar novo progresso.

Próximo incremento técnico independente, sem nova frente: evoluir este contrato preservando v1; receber inputs externos do verificadorA e recompor sua prova, substituir filtro opaco por receita visual allowlisted vinculada ao compilador criativo existente, e testar rejeição de fonte/evento/depêndencia divergente. Não conectar ao runtime até a integração comB e a capacidade real. Done when desse próximo incremento: grafo concreto recomposto das fontes e das receitas reais, filtros/legendas/eventos/fontes integralmente pinados, negativa demonstrada, nenhum efeito semA/B. Isso não elimina a ausência de gold temporal LIVE nem resolve a duração fora da banda; essas dependências permanecem explicitamente abertas. Não produzir todos os formatos, reinstalar ferramentas, ressintetizar51falas ou reabrir diagnósticos encerrados.

Contraprova independente da unidade de normalização encerrada: 40 bindings/26 arquivos e cinco terminais conferidos, PCM e números recompostos, nenhuma lacuna crítica no escopo de níveis/proveniência. Não repetir medições ou síntese concluídas. Resta fechar a receitaC pura e seus testes, sem atribuir a ela aprovação temporal A, transação B ou execução audiovisual. A revisão detectou caminhos de ferramenta e grafos de filtros que precisam de restrição antes do aceite deste compilador; corrigir nesta unidade, não por tentativa de render.

## Unidade ativa — normalização contínua derivada, sem ressíntese

**Correção técnica executada22:34:47Z:** primeira derivaçãoFAIL−17,14LUFS preservada; correção medida posteriorPASS−16,37LUFS/−1,49dBTP/zero clipping/exatos4.866.720samples, receipt5d7ebccf…. Oito testes rootPASS. Nenhum sample removido. Não reexecutar render/medição final para gerar outro receipt equivalente. Revisão independente read-only em fechamento; autorização de áudio integral/A permanece ausente.

Próxima unidade independente já em curso: três arquivos da receitaC (`phase6_av_render_recipe.py`, schema e testes). Compila/verifica sem efeitos; exige timeline/blueprint/fontes/áudio concretos e namespace atribuído pela fila somente no commit. Não integrar capacity/admission/runtime enquanto essa unidade não estiver revisada. Fonte atual de áudio abaixo da banda nunca é elegível por ter volume correto. Depois do fechamento, reavaliar o caminho crítico sob cota22%/reserva10; não abrir novas frentes nem repetir ASR contextual já encerrado.

Preflight: raiz/fase6 confirmadas; turno anterior **PROGRESS** por WAV real, ASR e medição que delimitaram a próxima ação. Reabertos STATE, masters00/10/11, protocolo01, fases07, prompt05, contratoAV A–D/schema, renderer e medidor existentes, perfilSTANDARD/pipeline. Preservar fontes, hooks/copy/voz/velocidade, montagem e receipts. Não modificar jobs/receipts congelados nem iniciarB–D dependente.

Implementar função reutilizável de normalização de faixa contínua e runner local limitado ao WAV202.780ms. Reusar loudnorm/FFmpeg e parâmetros vigentes−16LUFS/−1,5dBTP/LRA8; segunda passagem usa o primeiro resultado hash-bound incluindo offset1,96. A simples primeira passagem projetava−17,96LUFS, abaixo do perfilSTANDARD. Não repetir medição de entrada, EQ por corte, TTS, ASR ou render visual.

Done when: derivado real em namespace próprio, entrada rehashada, controles de duração/PCM/clipping e nova medição independentes da saída prevista do filtro;−16±1LUFS e pico≤−1dBTP conformeSTANDARD; nenhuma edição de fala/velocidade. Se o filtro produzir cauda extra, só remover samples adicionais integralmente zero, preservando todos os samples filtrados anteriores; cauda não zero, déficit ou excesso>100ms bloqueiam. A remoção não pode preencher a banda experimental nem criar alegação de sincronização. Testar parser finito, plano de comando sem trim/atempo, gate negativo, zero-tail e replay sem efeito repetido. Publicação/qualidade perceptual permanecem falsas. Em paralelo, revisão read-only de integrações operacionais independentes.

## Unidade ativa — materialização fiel da proposta de pausas existente

Medição adicional encerrada22:23:10Z usando os dois medidores existentes:−25,71LUFS/−2,01dBTP/LRA5,5/zero extremosPCM; receiptf7dfa55f…. Próximo incremento concreto: derivar uma candidata masterizada pela cadeia existente e verificar o resultado, sem ganho linear inseguro, retiming ou reescrita de voz. Não repetir o baseline medido e não aprovar pronúncia/sincronização por loudness. O erro de nome `sys.origargv` ocorreu antes do efeito e foi corrigido; FFmpeg executou uma única medição real.

**Executada, sem promoção produtiva —22:18:27Z.** WAV real202.780ms,51slices intactos,hook byte-idêntico, sete testes PASS e replay sem nova montagem; receipt ea796677…. Contraprova restrita aos cinco desacordos ASR encerrada, quatro testes PASS e replay sem nova inferência; receipt9ef196b3…. Não repetir essas unidades concluídas. Avanço material: narração contínua disponível para avaliação; não a tratar como áudio aprovado ou duração elegível.

Próximo incremento de entrega: medir áudio integral com instrumento já disponível, sem fabricar outro framework; resolver001/007/013/016 por evidência acústica e preservar011 como caso homófono, não defeito comprovado. Referência temporal LIVE/holdout e pausas editoriais elegíveis continuam pendentes. Sem dado externo anotado, não promover alinhador; executar somente trabalho independente permitido de A–D. Não sintetizar51vozes, repetir pesquisa visual rejeitada, congelar uma nova arquitetura geral ou gastar para obter uma contraprova. Done when de A continua o contrato abaixo, não a quantidade de testes/receipts.

Preflight desta continuação: unidade anterior classificada **PROGRESS** (render real + verificação independente), Fase6 permanece autorizada e em execução. Masters, protocolo, fases, prompt, estado, contrato A, schema AV e assembler/compositor existentes foram reabertos. Preservar todas as fontes e o protótipo visual já terminado.

Escopo: criar um adaptador QA pequeno do assembler existente, sem editar os módulos congelados. Reabrir a proposta cb5f0389…, seu baseline190.800ms, reconciliação e51WAV. Inserir exatamente cada pausa adicional após o padding mecânico já existente, mantendo001–003 e todos os samples da voz. A proposta especifica adicional, não alvo de energia; não descontar caudas duas vezes nem arredondar silenciosamente para100ms. Resultado calculado esperado:4.866.720samples/202.780ms; permanece fora da banda e sem autorização produtiva.

Done when: candidato WAV real; preflight/pins;51slices idênticos; gaps somente declarados; hook0–8s idêntico; nenhuma duplicação/omissão/ressíntese/aceleração; teste de entrada adulterada e replay sem nova montagem; receipt e estado honestos. Fora de escopo: preencher déficit de duração, aprovar audição não realizada, inventar gold/timestamps, renderizar vídeo, iniciar B–D dependente ou publicar. A referência temporal LIVE ainda exige anotação humana/dataset verificado do mesmo conjunto de voz, além de segundo método independente; o código não poderá fabricar isso.

## Entrega material — protótipo editorial renderizado em 21:38:30Z

Fechamento21:54:50Z: prova independente dos receipts concluída, SHA40679c5a60eef49fcd49557aa69909346c25a48a734b75fe568278fc63695f48. Root sete testes PASS5,195s e CLI PASS com replay byte-idêntico. Os três pontos de rastreabilidade estão fechados para **esta prova diagnóstica congelada**, sem tornar produtivo o renderer. Não reexecutar esta unidade. Próximo trabalho é A/áudio conforme os materiais abaixo; aprovação audiovisual e publicação continuam pendentes.

Uma nova composição real do take-003 foi produzida em `output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab/preview.mp4`. Receita/schema próprios, upstream e sidecar físico intactos. Render lossless em 35,328 s; 150 frames, 1920×1080, 5.000 ms. Os sete testes focais passaram em 0,252 s. As duas regiões físicas conservaram pixels idênticos à fonte redimensionada em 150/150 frames cada; o cálculo dos 450 hulls registrou 130,4 px mínimos até a faixa. Isso é avanço visual intermediário, não publicação nem aprovação integral.

Fechamento imediato desta unidade: verificador independente **somente de leitura** deve reconciliar receipt de geometria/fonte, fronteiras esperadas dos oito processos, report e replay determinístico. Não repetir render, decode, preview ou testes inalterados. A inspeção root de três frames identifica texto legível e hierarquia separada, mas não comprova cinco segundos de compreensão audiovisual; cards vazios representam ordem e não explicam sozinhos pressão, teste ou escolha fiel.

Próximo caminho crítico permanece A–D: resolver continuidade/duração/temporização de áudio; admitir entradas/capacidade/publicity exatas; compilar sucessor audiovisual conservando os locks; avaliar o vídeo completo e só então atravessar o release. A prova local ainda não promove a fase nem integra o protótipo no job SUCCEEDED. Critério de produtividade final: vídeo completo aprovado/publicado, não quantidade de testes, receipts ou estilos catalogados. Zero nova publicação nesta unidade.

Evitar retrabalho no retorno a A: há duas propostas de pausas diferentes. A editorial persistida (SHA cb5f0389a31b2aa9c481d469dc33bc8d52679734bf42f57e058ef66a61b1bfd9) projeta202.780ms, faltando4.970ms ao piso literal207.750ms; o módulo mais restrito projeta194.600ms, faltando13.200ms ao piso de grade207.800ms. Nenhuma está auditivamente aprovada ou renderizada como sucessor admitido. Não confluir esses números, somar propostas, recriar voz ou completar a banda por silêncio artificial. Reabrir as fontes existentes e avaliar pausas/legibilidade/temporização de modo conjunto dentro do contrato A.

## Prioridade de entrega — encerrar hipótese rejeitada e simplificar o take-003

O proprietário reiterou que a demora e a baixa produtividade são inaceitáveis. A medição em curso terminou: report 5087d20f..., seis pares reais, 0/6 aprovados versus 3/6 históricos; manter a hipótese rejeitada e todos os receipts. Não continuar uma busca de parâmetros de semeadura nesses exemplos, nem repetir a medição terminada. A implementação de retomada está testada; não deve ser confundida com avanço de publicação.

Próxima unidade limitada: verificar e prototipar **uma** composição editorial separada do espaço físico dos cartões para o mesmo take-003. Preserve fala, voz, duração 3–8 s, texto NAME / TEST / CHOOSE, grupo secundário sem equivalência 1:1, fonte, Bible e restrições do experimento. O layout deve mudar de fato, com rótulos claramente pertencentes à interface editorial, sem o defeito de adesão física da versão anterior. Reabrir o contrato literal antes de compilar: se uma invariante protegida não puder ser conservada, registrar o conflito e continuar outra dependência A–D permitida, sem troca silenciosa de escopo.

Done when desta unidade: receita e contrato próprios e hash-bound; preflight de capacidade; um candidato curto real; comparação visual/semântica por frame e movimento integral; voz existente preservada; fonte e regiões importantes não ocultadas indevidamente; legendas, safe areas e identidade verificadas; sem promoção automática de diagnóstico. A versão antiga e seus FAILs continuam intactos. A rota não pode se aprovar apenas porque dispensou rastreamento de etiqueta física. Nenhuma arquitetura nova, formato adicional, nova síntese ou varredura ampla entra nesse lote. Depois, retomar a cadeia A–D com foco no Vídeo 2 completo, gates e publicação idempotente.

## Capacidade vigente — somente YouTube, leitura 20:50:51Z

D-152 mantida sem nova política concorrente: 26% restantes; reserva 10; 16 pontos / 6,225520833333 dias = 2,570066092194 pontos/dia até 12/09 às 23:15:36 BRT. Decisão `codex-usage-10710888172b3bb3`, schema/twin PASS. O uso ainda excede a âncora, portanto somente caminho crítico com qualidade integral, reuso de provas e testes focais por alteração. Não repetir suíte inalterada, decode, render ou fit já concluído para produzir outro relatório equivalente. Não despertar QR, ampliar formatos/fases, reduzir o modelo ou consumir/comprar resets/créditos. A continuidade permitida do runtime local não comprova cadeia produtiva já integrada nem garante disponibilidade ininterrupta do Codex.

## Unidade encerrada — contraprova fotométrica source-only das cadeias

Resultado terminal em 21:08:24Z: execução completa, hipótese rejeitada em 6/6 casos. Wrapper final 7471eacad...; 10/10 testes focais PASS; report 5087d20f3b670b630d9b8763de207fa14fe3b62ed5d745a636651e1f9395da58. Não repetir a unidade nem integrar a proposta. Os itens seguintes preservam seu pré-registro histórico.

Rodada anterior PROGRESS: helpergeométrico14/14 e450hulls concluídos. Preflight desta continuação: STATE, masters00/10/11, protocolo01, fases07, prompt05, specAV, schema do hook e policiesV3/compositor relidos; Fase6 IN_PROGRESS. Nenhum trabalho terminal será reiniciado. Preservar candidato, PCM, recipes, V3/V4 e seus limites/receipts.

Experimento QA limitado, antes de qualquer medição: seis pares fixos `(frame,card)`48/1,49/1,50/1,54/3,55/3,56/3. Observação anterior de cada par é o controle histórico, não será recalculada. Reabrir seus oito frames fonte47/48/49/50/53/54/55/56, com hashes completos, origem de decode por ordinal e runtime pinados. Aplicar somente sementes por cadeia com scan `_edge` e avaliação `_validate_edges` V3 exatos; usar todas as amostrasKLT e H ECC retidos, nunca refazê-los ou escolher por menor residual. Query é o mesmo predeclarado. Novas propostas não provam detecção; dados reais serão relatados mesmo quando piores.

Antes dos reais: controles sintéticos determinísticos de bordas traduzidas conhecidas, baixa diferença de luminância, transformação errada e holdoutKLT; positivos e negativos precisam demonstrar comportamento do instrumento. Isso não é calibraçãoLIVE/humana nem garante aderência do vídeo. Arquivos novos: `paper_chain_photometry_v1.py`, teste correspondente, wrapper `verify_paper_chain_photometry_v1.py`, teste de vínculos/execução e policy externa. Revisão principal e contraprova dos vínculos antes do efeito; novos arquivos, nenhum patch in-place em observadores existentes.

Done when: policy+intent pinados antes da execução, origem/frame/card/hull/query/fit/H comprovados, testes focaisPASS, capacidade fresca, filho nativo próprio limitado e sem órfãos, checkpoint por par/control, hashes/terminal e reavaliação numérica dos resultados (sem repetir scans) conciliados. Report deve expor contagem/cobertura/rank/condição/resíduos/holdout por par; insuficiência continuaBLOCKED. Proibidos decode/render/TTS/KLT/ECC/API/instalação/restart/publicação/gasto e integração no compositor. Próxima ação depende da evidência, não de promessa de que o método passará. Fotometria não encerra acústica/OCR/publicity/admissão/receita/release/fases7–8.

## Unidade concluída — sementes geométricas; próximo passo fotométrico delimitado

Done when geométrico atendido: revisão principal,14/14 testes PASS3,409s,450hulls/segmentos preservados e exemplo real48/1 hash-bound. Evidência `output/qa/phase6/diagnostics/paper-edge-chain-seeds-v1-root-evidence.md`. Nenhum scan foi feito pelo helper; não promover a observador. Próxima unidade: pré-registro de contraprova fonte-only e controles do semeador novo, mantendo fotometria, query, contagens, rank/condição/resíduos e holdout24. Não alterar instrumentos anteriores ou escolher método pelo residual do candidato. Tratar independência de3/55 separadamente. Não repetir redução/teste íntegro sem mudança relevante.

Orçamento nativo20:19:40Z:26%restantes,10reserva,16planejáveis em6,247175925926dias;2,561157263652pontos/dia, ação somente caminho crítico com qualidade máxima. Decisão codex-usage-adb3ab2711205cb6 schema/twinPASS. Sem nova frente discricionária, expansão de fase/formato, downgrade, gasto, reset ou despertarQR.

### Plano preservado da unidade geométrica

A comparação anterior está encerrada: report c4c4f5e5a89c4938eac8f16f66ecf49f8e6b60befb2a1adc5382ecbe1e897de9, sessão99916 exit0, worker14660 rc0, lock removido, 5/5 testes PASS0,287s. Done when atendido como diagnóstico não calibrado. Não repetir comparação, render ou CV com as mesmas entradas. Não existe método vencedor aprovado.

Correção delimitada da causa carta1/49: helper puro e versionado para agrupar fragmentos convexos contíguos do mesmo lado, mantendo comprimento mínimo80px, frações V3 e normal/tangent do segmento local. A semente é proposta geométrica, não borda observada. Revisar e testar convexidade, arclength, wrap circular, segmentos curtos, lado distinto, auto-interseção, valores não finitos/overflow, vértice exato, proveniência, determinismo e imutabilidade. Comparar o comportamento geométrico no hull retido que originou o bloqueio, sem pixels. Correções após hashes exigem cópia física SHA-verificada. Únicos novos arquivos de código: helper e seu teste; não alterar observadores ou policies.

Done when da unidade: revisão principal, testes focais com resultado terminal, hull real hash-bound e evidência de que seus fragmentos não desaparecem da proposta. Não alegar que haverá detecção fotométrica ou cobertura aprovadas. Holdout KLT24px, quantidade/lados, condição100 e resíduos permanecem não avaliados e obrigatórios. O caso carta3/55 é uma dependência separada, não resolvida por este helper. Depois: pré-registro de calibração limitada do observador e correção de independência, antes de consumo em QA produtivo. Acústica/OCR/publicity/admissão/receita/release e fases7/8 não são dispensadas.

## Unidade encerrada — separar representação geométrica e movimento, sem nova mídia

Preflight desta continuação: raiz confirmada; STATE corrente, masters00/10/11, protocolo01, fases07, prompt05, especificação audiovisual, schema do hook e política temporal v2 lidos. Fase6 IN_PROGRESS; rodada anterior PROGRESS com sessão21305 terminal. Preservar integralmente vídeo, voz, receitas, quads, observações, limites e relatórios históricos. Não há novo dado de mercado nem autorização derivada deste diagnóstico.

Objetivo único: distinguir erro da representação da etiqueta e erro de aderência, confrontando três séries pré-declaradas com os mesmos transforms/query do papel. (1) Retângulo envolvente: conservar os resultados do report5e04882e já concluído, sem recalcular sua redução. (2) Quatro bordas externas TLS: reusar os quads medidos no report4bf17320, presos aos mesmos frames/máscaras do candidato corrigido. (3) Quad solicitado14698fff: contrafactual matemático explícito, jamais observação. Nenhuma rota é escolhida pelo menor residual ou promovida por este confronto.

Saídas previstas: `output/qa/phase6/diagnostics/compare_retained_paper_geometry_v1.py`, testes focais e namespace imutável derivado do SHA da fonte. Conferir JSON, identidades, ordinais, máscaras/frames, cardinalidade e origem; cálculo float32/float64 igual ao histórico, derivadas só em frames consecutivos e âncora sem reset. Reuso de pixels é apenas de receipts: este módulo não abrirá pixels nem chamará CV/render/decode/TTS/API.

Done when: três representações classificadas corretamente; resultado por carta/frame e erro observado versus solicitado; vínculo integral dos quads TLS às máscaras corretas; positivos/negativos e testes de troca de origem/ordinal; preflight e filho supervisionado; relatório recomposto, limitações e próxima decisão causal. A inspeção independente das bordas carta1/49 e carta3/55 ocorre em paralelo, somente leitura. Fora de escopo: mudança de limiar, produção, publicação, instalação, reinício, gasto e fases7/8. Ground truth temporal/visual e calibração LIVE continuam ausentes.

## Unidade encerrada — diagnóstico numérico retido, 19:34 UTC

**PROGRESS**, não conclusão da Fase 6. Done when atendido: fontes/ordinais vinculados, histórico numérico reproduzido, frames e lacunas explícitos, 15/15 testes PASS, revisão independente, filho supervisionado e recomposição integral. Report SHA `5e04882e9b87db64db3ef266e6cec78a01d3259aaccc7afee4303729bb2a9adb`; sessão 21305 exit 0, worker 11500 rc 0, lock removido. Tentativas de prepare/aritmética que falharam e cópias de fontes anteriores foram preservadas, não transformadas em PASS.

Resultado: 102 bloqueios por borda ausente/ambígua, um residual reprovado na carta 3/frame 55; a perda da âncora da carta 1/frame 11 é evento distinto e persiste no candidato corrigido. A carta 2 tem todos os 149 pares, mas continua acima do limiar central p95 antigo. Nenhuma nova mídia foi produzida; diagnóstico não é calibração nem aprovação.

Próxima unidade estrita: discriminar observabilidade de borda e erro de trajetória, começando nos receipts carta 1/frame 49, carta 3/frame 55 e na série completa da carta 2. Done when: causa sustentada por borda/frame, limites do observador explicitados e uma correção restrita pré-registrada com controles capazes de distinguir erro do instrumento e erro real. Não ampliar query, reiniciar âncora, escolher retrospectivamente menor residual nem repetir CV/render sem entrada/prova nova. Permanecem as dependências acústicas, OCR, publicity, receita/admissão/release.

Orçamento recalculado pela leitura 19:37:30Z: 28% restantes, reserva 10, 18 pontos planejáveis até 12/09 23:15:36 BRT, teto cooperativo 2,867859395 pontos/dia. Somente YouTube ativo; sem iniciar trabalho discricionário, alterar o modelo para menor qualidade, despertar QR, comprar ou usar reset. O ritmo observado excede o plano: não prometer capacidade ininterrupta nem atribuir economia/velocidade sem benchmark.

## Continuação — causalidade dos bloqueios de movimento, antes de novo CV

Rodada anterior PROGRESS: medição completa do candidato encerrada com resultados recompostos. Sessão91602 terminal, sem retomada. Preflight confirmou raiz/Fase6 e releu masters00/10/11, protocolo01, fases07, prompt05, especificaçãoAV, schema do hook e políticas de geometria/continuidade. Preservar fontes, candidato corrigido, labels, voz e todos os receipts históricos.

Unidade restrita: diagnosticar os447pares retidos do observador de papel e distinguir103seleçõesBLOCKED da perda de domínio da âncora acumulada. Conferir ordinais/origens/hashes; relacionar cada causa a frame/carta; comparar a geometria histórica com a do candidato corrigido sem refazer observação de pixels. Reconstituir a primeira saída de domínio e separar residual de par, deriva acumulada e lacunas temporais. Não extrapolar transformação fora da região validada, reiniciar âncora, interpolar ausências ou calcular aceleração como se pares não contíguos fossem adjacentes.

Done when: causa quantitativa e fontes verificáveis, testes do cálculo/ordem/domínio/lacunas, relatório sem autoridade produtiva e próxima correção determinada pela evidência. Fora de escopo: render/decode/TTS/CV pesado novo, alteração de limiar/receipts/filas, gasto, publicação e fases7/8. Parecer independente read-only dos dados em paralelo à inspeção principal, sem estratégia paralela.

## Resultado executado — 450 recortes e 447 transições reais

Unidade diagnóstica concluída com evidência, não aprovação do vídeo. Sessão91602 terminalexit0; workers8736/17492 rc0 semtimeout;13/13testes rootPASS0,102s; parecer independentePASS. Report2e5954dea225a239af7226ab91f71866b53a618ddf303d6ecbf688b9d525ea2b. Medição e recomposição idênticas: SHAa9cfc0cf2d1a687e146b0077909caa9ab5a5aebf9a238170e4c5c501615315ce. Todas as450origens/áreas/patches e447transições reabertas, sem novo render/decode/voz. Três cartas dentro dos limiaresSSIM/L*/cor/área; estadosdeautoridadefalse.

Done when desta unidade atendido: pins, ordinais, áreas medidas, métricas completas, critérios preservados, pré-registro, capacidade, supervisão de ambos os filhos, repetição e limitações documentadas. É recomposição pelo mesmo método, não calibrador independente ou teste fora da amostra. A falha de supervisão no rascunho foi resolvida antes do primeiro efeito; nenhuma tentativa nativa falhou neste run.

Próxima unidade do caminho crítico: observar a relação etiqueta/papel sem inferi-la do target ou da estabilidade. Reabrir primeiro os BLOCKED/limites de domínio dos journals retidos e especificar uma correção restrita à causa comprovada. Não repetir render, voz ou CV pesado sem entrada alterada/insuficiência identificada. OCR, alinhamento temporal, publicity, receita/admissão e release seguem no encadeamentoA–D, sem expansão de formato/fase.


## Unidade em execução — candidato retido, sem novo render

Continuação anterior PROGRESS: controle residual sintético concluído e reconstituído, sem aprovação do candidato. Implementar e revisar somente `verify_candidate_planned_residual_v1.py` e testes focais. O contrato QA prende as coordenadas planejadas como referência; geometria e áreas continuam medidas nas máscaras externas originais. Reabrir os 150 journals, conferir 450 patches e máscaras, recontar áreas e calcular 447 transições com L*, deltaE76 e SSIM global, preservando limiares. O SSIM anterior é conhecido: serve para reprodução exata, não validação fora da amostra.

Done when: revisão principal e independente, testes de identidade/ordem/área/autoridade, pré-registro pinado anterior ao efeito, capacidade fresca, processo filho supervisionado, terminal e replay integral comparados. Sem novo decode/render/voz, API, instalação, manutenção, publicação ou consumidor produtivo. Limites de geometria/papel, OCR, áudio, publicity e calibração LIVE permanecem. Só o resultado observado definirá a próxima unidade.

Preflight de código: 13/13 testes focais PASS0,102s; código6dc30ef336ee6ccb279e34a5aa33d6715b75f63b4a615e9d97147d8f16e2b48f. Revisão preventiva encontrou e corrigiu recomposição final sem timeout: medição e replay agora usam filhos distintos com limite180s e capacidade fresca própria. Finalização sem cálculo nativo no supervisor. Esta mudança ocorreu no rascunho antes do primeiro run; não é re-render ou alteração de receipt histórico. Parecer final da correção antecederá o efeito.


## Resultado executado — residual com referência fixa

Etapa do instrumento sintético concluída, não do vídeo: sessão56232exit0,8/8testes root3,034s, relatório1bbb2081e740188e6e7460d38a3d775e681cdddfffa0b58d71dfa3891a7b3a5b. Controlezero reproduz o frame74 retido byte-exato e passa; X8/Y8/rotação2graus reprovam com os limiares originais. Finalizador reconstituiu4patches e métricas; base300+3 verificada, sem re-renderizar150frames. A exigência Done when deste diagnóstico foi atendida; nenhum gate produtivo foi satisfeito por isso.

Próxima unidade crítica: criar contratoQA versionado que permite planned coordinates somente como referência residual, nunca geometria observada; consumir450patches `candidate_requested_projective_quad` já retidos no domínio92069e0df02a6078, reconstruindo447transições e também L*/cor/área com base no journal original. Done when: pins/versão/ordinais/spans/pixels/áreas íntegros, todos os componentes efetivamente medidos, critérios originais preservados, relatório independente com limites e nenhum consumidor produtivo ligado. Não repetir source decode/render/voz, não usar resultados conhecidos como validação fora da amostra e não aprovar papel/OCR/calibraçãoLIVE por inferência. Esse passo prepara a avaliação do material real; não substitui a integraçãoA–D.


## Continuação D-153 — instrumento residual, não aprovação pelo target

Rodada anterior classificada **PROGRESS**: contraprova pré-registrada terminou e demonstrou falso flicker possível no caminho binário, alterando a próxima ação. Sessão20889 terminalexit0, sem reexecução. Preflight desta continuação confirmou raiz/Fase6, releu masters, protocolo, gates, prompt da fase, especificaçãoAV, schema de hook e políticas dos observadores. Fontes/candidato/voz/receipts/gates são preservados.

Implementar somente `output/qa/phase6/diagnostics/diagnose_planned_coordinate_residual_v1.py` e teste focal. Referência planejada é sistema de coordenadas, nunca observação ou prova de adesão. Reusar150patches analíticos existentes e produzir somente intervenções pré-definidas no frame74: deslocamento de objeto inteiro8px em X/Y e rotação2graus, antes da retificação fixa. Reusar controles de glifo8px/brilho+36. Estes valores são fixados antes dos resultados;8px já é negativo da política de adesão. Rotação2graus é sensibilidade sintética especificada, não novo limiar produtivo. Todos os limiaresSSIM/L*/cor/área permanecem congelados.

Done when: entradas/implementação/policy/runtime pinados, pré-registro anterior ao efeito, capacidade/lock/worker próprio/terminal/replay verificados, positivoPASS e todos os negativosFAIL com evidência. Falha mantémBLOCKED e não autoriza ajuste oportunista. A hipótese não deve aprovar transformações constantes incorretas: esses casos continuam sob gates externos de geometria e papel. CalibraçãoLIVE e aprovação do vídeo ficam explicitamente fora deste ensaio.

Fora de escopo: novo decode/render do candidato, voz, instalação, API, publicação, manutenção/restart, alteração de política operacional ou expansão de fase. Última cota datada18:00:51Z continua31%, não nova leitura; manter lote crítico sem nova frente discricionária.


## Lote D-153 encerrado com evidência — sem novo render do candidato

ClassificaçãoPROGRESS: sessão20889 terminalexit0; pré-registro sintético completou150frames/149pares por braço, replay300patches+3controles, relatório fab70bbd56fe73447da46a82d35c7aef87ff8c295d4b9af8976d3f790feecd45. Verdade matemáticaPASS e contorno externoFAIL; revisão independente restringe a inferência ao controle sintético. Done when do diagnóstico atendido, não da qualidade do vídeo. Não repetir run, render, fonte, voz ou redução integral sem nova razão.

Próxima unidade crítica, ainda não iniciada: provar um instrumento de erro residual em coordenadas planejadas com controles de etiqueta inteira instável/desprendida, glifo e brilho, mantendo observadores geométricos/papel separados. Done when: receita pré-registrada, negativos realmente detectados, positivo estável, reuso hash-bound de entradas disponíveis, revisão independente e limite de domínio explícito. Referência planejada nunca será rotulada como geometria observada. Só após essa prova avaliar mudança versionada do contrato e o candidato; calibraçãoLIVE e gates restantes seguem obrigatórios. Essa direção substitui a repetição de estimadores binários já reprovados, não as regras permanentes.


## Execução do lote revisado e recálculo de uma operação — 06/09, 18:00:51Z

Somente YouTube permanece no workload ativo, conforme declaração do proprietário. Saldo oficial 31%, reserva 10 pontos, 21 planejáveis / 6,343576389 dias = 3,310435425 pontos/dia até 12/09 23:15:36 BRT. Decisão `codex-usage-985d91af59012a44`, schema/twin PASS, 19/19 testes de gestão PASS em 0,711 s. Não rebasear a âncora para ocultar consumo acelerado; não confundir crédito adicional/reset com franquia semanal; sem redução de qualidade ou gastos.

Plano de aceleração deste lote: terminar a contraprova já revisada e reaproveitar seus resultados, sem repetir render/TTS/decode ou regressão geral. Os 10 testes focais passaram em 2,317 s; sessão 20889 executa o pré-registro sintético pinado c9b3a9761e29f7ed21dc73a802f07750b6909d01577dba84e81e5bcf3c338638. Done when: terminal do processo próprio, cobertura completa, controles positivos/negativos, reduções recompostas dos pixels retidos e conclusão limitada à evidência; não requer que a hipótese seja confirmada. Nenhuma fase posterior ou publicação é liberada por esse diagnóstico.


## Continuação D-153 — Contraprova de precisão antes de novo estimador

Rodada anterior: **PROGRESS**, pois implementou/recompôs o observador nas450máscaras, rejeitou a hipótese de melhoria pelo resultado4bf173…, encerrou sessão27096 e deixou uma causa a discriminar. Não existe sessão de mídia anterior em espera. Raiz e Fase6 confirmadas; STATE, masters00/10/11, protocolo01, gates07, prompt do piloto, especificaçãoAV e schema do hook relidos. Fonte, áudio, mídia, modelos, gates e receipts são preservados.

1. Construir controle analítico/sintético independente para medir a perda de precisão ao converter borda anti-aliased em máscara binária. Dimensões/poses e todas as fases subpixel ficam pré-definidas; o extrator recebe somente máscara, não a verdade geométrica. Comparar todos os pares da população controlada por retificação externa e por verdade matemática conhecida, com os mesmos kernels/limiares. Incluir patch estável, mudança real de glifo e brilho. Done when: script/policy/tests revisados, comando/pins congelados antes do efeito, relatório íntegro e conclusão causal limitada ao controle; se controle/oracle falhar, resultado é inconclusivo, não aprovação.
2. Não criar outro estimador de produção nem suavizar os resultados antes de discriminar a causa. Uma contraprova sintética pode provar erro do instrumento sob condições conhecidas, mas não constitui calibraçãoLIVE ou aprovação deste vídeo. Done when: próximos passos mudam por evidência, não repetição da hipótese reprovada.

Fora de escopo: novos450masks, decode/render/TTS, alteração de voz/timeline/threshold, publicação, instalação, Ads, mudança de modelo, reset, nova frente comercial ou operaçãoQR. Custo adicionalR$0,00. O código de diagnóstico será novo; fontes pinadas não são editadas. Avaliação/review subordinadas ao Gestor, sem estratégia paralela.

Saldo atualizado17:38:05Z:32%,22pontos além da reserva10,6,359386574dias até12/09 23:15:36BRT, teto cooperativo3,459453163pontos/dia. Decisão codex-usage-8b2c1de834474d20/SHA c51d92f847b655071a20df4c49840dc2069392c0ba9bf9eb2f747b4a6c843659; schema/twin PASS. Consumo5,555265pontos antecipado versus âncora; concluir este lote crítico, não abrir trabalho discricionário. A orientação oficial OpenAI Docs confirma que complexidade/contexto/modelo/ferramentas afetam consumo; não há cálculo exato por tarefa. Qualidade/modelo/custozero e2.500créditos/2resets preservados.

## D-153 — Checkpoint executado; não repetir a hipótese reprovada

Passos1–2 do plano abaixo foram implementados e executados, porém o critério de qualidade do passo2 **não passou**. Helper7/7 e wrapper6/6testes root; revisão independente encerrou os achados antes do run. Sessão27096 exit0, report4bf1732095158478eabd01ee098e86c1a49d22736a42b8d5a3b51b6dcae16d0b,450quads/447transições rederivados, trêsFAIL de similaridade temporal. Controle estável e dois negativos produziram os resultados esperados. Tudo diagnóstico/sem autoridade; a integração do passo3 não está liberada por esses resultados.

Próximo lote somente no caminho crítico: medir os saltos dos quads nos piores pares já arquivados e confrontar a precisão do instrumento com a variação subpixel, sem nova produção. Done when: causa discriminada por controle independente e método de medição calibrado no domínio pertinente; não basta elevar um score ou aproximar o resultado do target. Só uma alteração sustentada por essa prova pode justificar nova avaliação. Não repetir450observações completas, ASR, voz, source decode, render ou regressão global enquanto a entrada/método relevante não mudar. Preservar todos os relatórios reprovados.

## D-153 — Observação projectiva externa, sem alterar o vídeo

Rodada anterior classificada PROGRESS: correção de clock renderizada/contraprovada e gestão de cota materializada. Esta continuação reabriu o estado, protocolo, gates, promptFase6, masters de inteligência/Gestor, especificaçãoAV e schema do hook. Raiz confirmada; fase6 permaneceIN_PROGRESS. Fontes/vídeos/voz/limiares/receipts anteriores serão preservados.

Diagnóstico atual concluído, sessões42789/79608 exit0: `hook-flicker-domain-v1-92069e0df02a6078/report.json`, SHA9f3e033f0345a28a0ebc6dd70af57ef00f2d01a4b8882a84cf10b33996d7c712. Todos447pares em três condições, sem novo decode/render/TTS. Mesmos pixels retificados pelo quad projectivo solicitado resultam em mínimos0,991559/0,991961/0,993351, contra0,815972/0,926882/0,938449 pelo retângulo observado. Baseline integral reproduzido; bindings/cardinalidade/reduções contraprovados. Contact sheet inspecionado. Isso discrimina interferência da retificação, não aprova mídia nem transforma o quad esperado em observação independente.

1. Implementar helper QA novo `projective_label_edges_v1.py` e testes: quadrilátero derivado exclusivamente da silhueta observada, quatro lados/cantos estáveis, sem target e sem minAreaRect como resultado final. Parâmetros e limites explícitos; negativos para componentes extras, forma inválida, não finito e cobertura insuficiente. Done when: revisão integral, testes sintéticos de projeção/rotação/subpixel e recusas documentadas. Não é calibraçãoLIVE nem promoção geral.
2. Contraprovar o helper nos mesmos450masks/candidato raw já retidos, sem repetir segmentação/decode/render. Recalcular geometria projectiva e patches/flicker em namespace novo; preservar todos os dados anteriores. Done when: cadeia exata de fonte/ordinal/máscara/versão, cobertura150/450/447, positivos/negativos e avaliação conjunta, sem dependência do quad esperado para extrair resultado.
3. Incorporar somente após a contraprova; geometria/pixels/HUD/voz/semântica/papel e outros gates mantêm suas exigências. Uma correção de instrumento não aprova observações que não foram executadas. A integraçãoA–D segue a sequência vigente.

Fora de escopo deste lote: novo vídeo/render/voz, alteração de threshold, nova fonte de direitos, chamada externa, restart/manutenção, publicação, estilos adicionais ou expansão de canais. Uso local/custo adicionalR$0,00. Não reiniciar sessões terminais.

## Continuação executável D-153 — lote focal, sem repetir voz ou fonte

Passo1 abaixo concluído/contraprovado, sessões74262/16458 exit0; relatório741e5e92e59244d8cdfbc7b0a4bdbb90b5fc132852cefc940c140b9f9c5fe3a5. Geometria/pixels450PASS,150falhas→0, SSIMmínimo0,998624781; HUDPASS; flicker3FAIL; **não aprovado**. Decodeúnico10,157s,150frames fonte reaproveitados. Próximo passo: diagnosticar transições de flicker pelos patches já arquivados, sem novo decode/render/TTS ou flexibilização. Done when: par/timecode/causa verificáveis, controle que discrimine defeito de mídia e limitação de observação, proposta restrita presa aos hashes; observação não equivale a remediação ou release.

Orçamento atualizado na leitura16:50:22Z:33%restantes,23planejáveis além da reserva,6,392523dias, teto3,597953338pontos/dia. Decisão codex-usage-fbcd005d14d51202/schema/twin PASS; mesma âncora/reset. O lote já aberto foi encerrado em checkpoint seguro, sem iniciar outra frente discricionária nem reduzir qualidade. Não confundir esse encerramento de lote com conclusão de fase/projeto; o Gestor residente não foi parado.

Render de relógio concluído: sessão4295 exit0,19,625s; mídia bc4bcc2ca953b0b696417f12972332bc92b7ee74f7d1f2fcf66f1b165560550e; receipt ef37e1d1f6d3b4872ef3393c0f81d038d1242df4aef961ede0cb1341abada1ca. O passo4 do checkpoint histórico abaixo foi executado apenas em QA, sem autoridade produtiva.

1. CONCLUÍDO COMO DIAGNÓSTICO REPROVADO: encerrar e verificar a sessão74262, não reiniciar o render. Novo avaliador pinado0b6075c6b562f1da0d38640b5287b38c18997f1b501fd331cbd42f2d0cb8fcf1,14/14testes root PASS0,067s. Decode único do candidato, source caches originais reutilizados. Done when diagnóstico atendido:150/450/447/150evidências completas, artefatos/receipts reabertos, relatório independente com todos os controles medidos e sem promoção de controles não observados. Falha de um controle permanece explícita; integridade de etiqueta isolada não representa aprovação conjunta.
2. Preservar o problema de observabilidade de papel como tarefa distinta; não deslocar a referência para aprovar erro, não reduzir limiar e não repetir CV de fonte inalterada. Reusar apenas com origem/hash/domínio integralmente conciliados. Este diagnóstico não fecha A nem autoriza a cadeia produtiva.
3. HardeningB já delimitado: aplicar achados do parecer publicity c4b945db98f6e70dd58cb54d4a71dff9e48d67c4048a57581b198c1575a4ec91 antes de qualquer consumo LIVE; contexto/capacidade mantêm as fronteiras anteriores. Done when: ambiente/modelo/calibração reais, StageA canônica, replay integral e expiração final testados e integrados ao admission sob fencing. O módulo atual continua bloqueado para consumo LIVE, não é gate do vídeo aprovado.

Sem novos estilos, pesquisas genéricas, lotes paralelos discricionários ou retomada do QR neste lote. O orçamento e a reserva continuam medidos a partir da âncora existente, sem inventar saldo novo. A aceleração concreta é um render de5s em19,625s e o reuso das fontes; não há promessa de prazo de conclusão sem medição.

## Checkpoint D-153 — causa exata, sem repetir o processamento inteiro

Releitura final16:15:12Z atualiza o planejamento para34%restantes,24pontos além da reserva e3,740098pontos/dia por6,416944dias. Mesma âncora/reset; decisão `codex-usage-6da9ce27b98ff3dc`, schema/twin íntegros. Valores35% abaixo são históricos, não saldo presente. Contexto canônico concluiu13focais root5,970s; integração B continua pendente. Concluir somente o lote crítico já aberto, sem novas frentes discricionárias.

1. Cota materializada às 15:57:53Z: 35% restantes, reserva10, saldo planejável25 pontos percentuais, 6,428970 dias até 13/09 02:15:36Z; teto3,888648 pontos/dia. Decisão `codex-usage-e5a10f6b2244fb65`, schema/twin íntegros. O consumo está 2,856770 pontos acima da trajetória da âncora; somente caminho crítico, mesma qualidade, sem novos lotes discricionários ou despertar QR. Grupo principal governança/schema:21/21 PASS0,967s.
2. QA150 terminal e contraprova concluídos: report SHA `f973241ea007d3e09c1ea72ada422a421558398facff48b730a7e91ae108697c`, `BLOCKED_UNOBSERVABLE`, quality_pass=false. Não retomar sessões51292/43460 encerradas. Reutilizar300caches; cobertura completa não equivale a aprovação.
3. Causa isolada sem novo decode: FFV1 time_base1/1000 versus PNG1/30 faz framesync default usar etiqueta anterior em1,4,...,148. Previsão exata coincide com50falhas; quatro frames falhos e três controles comparados com pixels retidos. Relatório `hook-framesync-diagnosis-v1-dbcb8d01c8c66a3e/report.json`, SHA `c65593db74134e8ba6e6c8cd74212b1f707602fc9afd3e1c6c98cde5693f0a76`. Done when diagnóstico atendido; não é render corrigido.
4. Correção restrita implementada em `hook_clock_correction_v1.py`: ambas entradas `settb=1/30,setpts=N`, somente após prova de150frames na grade arredondada CFR; comando/áudio/parâmetros restantes preservados e destino novo. Quatro testes PASS0,048s; plano real preparado SHA `6791c3d957d40325e158af5407bd25d97e6cc5b2c880a1b508afa2741b3b9722`. Próximo efeito: preflight atual, execução supervisionada do comando pinado em namespace QA novo, contraprova de pixels e movimento; não renderizar novamente a voz ou o vídeo inteiro. Ainda não executado.
5. Fechar somente hardening B já identificado: contexto de fila canônica, capacidade projetada sem falso LIVE e publicity por todos os spans. Componentes em implementação/revisão independente, sem integração de admissão/transação. Done when: provas realmente reabertas, negativos de fixture e origem passam, contrato unificado; nenhum COMMITTED ou render antes deA completo/fencing/locks/gates. Ampliar a arquitetura ou gerar mais estilos não faz parte deste lote.

EtapaA permanece incompleta: proposta de pausas194.600ms (4/4 controles root30,598s) ainda fica13.200ms abaixo do piso de grade. Não preencher com silêncio arbitrário. Calibração LIVE, visual_intent final e aplicação/render do sucessor continuam pendentes; nenhum PASS foi inventado.

## D-152 — Única operação ativa e ritmo até a renovação

Revisão final deste ajuste:31/31 testes PASS0,769s; contraprova15:29:17Z37%restantes,27pontos além da reserva,4,186805pontos/dia,AHEAD_OF_PLAN. Seguir caminho crítico em qualidade integral e adiar expansão discricionária; não anunciar bloqueio técnico do host. Decisão vigente `codex-usage-a4fd4f1a55c29fca` schema/twin/replay íntegros. QA local51292 avançou até46/150 medições na última leitura; processo e checkpoints seguem independentes de geração contínua de tokens. Done when produtivo permanece o relatório integral e, depois, a cadeia AV/gates/release; este ajuste de capacidade não conclui Fase6.

O proprietário declarou QR Dolar pausado. Planejamento atualizado para YouTube apenas, mantendo histórico/qualidade/gates e um único limite de conta. Consulta registrada em 06/09 às 15:10:17Z: 38% disponíveis, renovação 13/09 às 02:15:36Z (12/09 às 23:15:36 BRT). Reserva de 10 pontos percentuais deixa 28 para 6,462025 dias, teto nominal de 4,333007 pontos percentuais/dia. Não é previsão de custo por tarefa nem garantia de Codex ininterrupto.

Implementados `codex_runway.py`, integração da governança, policy/schema1.2 e oito controles novos; 14/14 testes conjuntos principais PASS em 0,192 s. Decisão real `codex-usage-933dae9e40d69fdc`, schema/twin verificados. A automação diária existente foi atualizada, preservando prompt anterior completo, horário, destino e ACTIVE; nenhum novo monitor ou execução do QR. Done when deste ajuste: aritmética, histórico, reserva, indisponibilidade, renovação alterada e desvio de ritmo testados; fonte e cálculo materializados. Não equivale a limitar fisicamente o consumo do host.

Execução local corrente: retomar somente etapas faltantes do QA visual congelado, preservando 300 caches e dez medições. Transporte adicional de espera limitada por capacidade passou 12/12 testes principais em 1,572 s; sessão real 51292 iniciada, sem veredito final. Após terminal, verificar relatório exato ou preservar causa/receipts. Nenhum threshold, modelo ou autorização de publicação foi alterado. Trabalho Codex seguinte deve permanecer no caminho crítico do sucessor AV, sem nova expansão genérica.

## Próximo caminho produtivo concreto — sucessor AV da Fase 6

### Lote de execução atual — D-151, comparação e validade do mercado

Checkpoint posterior: coortes/proveniência/inspector implementados, 45/45 focais principais PASS em 17,349 s. CLI real materializou `format-path-40fd6a83a94fd476afe68196`, SHA `d12b1517764a5a7605a4f9b6ec1ce8b0d926d9062fc2fcaee4dddb9408ab7c8a`: fonte histórica íntegra, mas STALE; recomendação UNDETERMINED. Não é coleta contínua integrada nem seleção produtiva. Comparação atual é pareada no mesmo canal/idade; canais exclusivamente Shorts ou longos exigem extensão separada e continuam uma lacuna explícita.

Próxima execução autorizada pelo preflight técnico deste lote: auditor QA retomável v3 passou 32/32 testes principais em 5,240 s, incluindo timeout real de processo próprio. `prepare` real terminou `PREPARED_ZERO_NEW_DECODE`; intenção SHA `ea02aa2f5adc6c9230c10da2b0993f694485d715db1861d2ba6f1a7a77057f55`, controles PASS, quatro frames retidos reutilizados. Executar os demais frames e medições em `layered-hook-temporal-resumable-v3-root-20260906-a`, verificar relatório e preservar checkpoints em falha. Isso mede a sequência já existente; não cria render, voz, autoridade produtiva ou aprovação por diagnóstico. A execução integral substitui a antiga espera por preparo, sem reabrir o instrumento congelado.

Os 13 arquivos finais deste lote foram copiados byte a byte e rehashados em `output/qa/phase6/diagnostics/source-freeze-d151-market-av-20260906-a/` antes de qualquer nova alteração. Histórico permanece preservado.

O último checkpoint entregou relatório e contraprovas; a resposta final subsequente foi comunicação. Nesta retomada, implementar a correção já identificada, sem recolha externa, alteração de protocolo ativo, produção, publicação, nova fila ou manutenção do Gestor.

- Criar `hero_engine/observatory/format_cohorts.py`, schema e testes: coortes exatas por canal/formato/idade e papel, com proveniência, amostra insuficiente explícita e ausência distinta de zero. Done when: controles de mistura, duplicatas, datas, dados ausentes e conjunto real passam, sem reescrever coortes históricas.
- Criar `hero_engine/observatory/format_paths.py`, política/schema e testes: inspeção executável do conjunto, validade temporal obrigatória, comparação não causal de sinais normalizados, capacidade por rota e LONG/SHORT/HYBRID/UNDETERMINED. Receita/RPM permanecem indisponíveis sem origem própria; uma recomendação de pesquisa não autoriza produção. Done when: CLI real gera artefato reconstituível, rejeita adulteração e sinal vencido, explicita renovação devida e preserva experimento/outputs anteriores byte a byte. Integração da recolha periódica ao Gestor continua um requisito posterior deste mesmo lote, não capacidade pronta por existir o inspector.
- Em paralelo, preparar auditor audiovisual integral retomável em novos arquivos: consumir compositor/ROI congelados, persistir decode e etapas com hashes, supervisionar o processo e testar replay/falha sem executar novamente mídia pesada. Done when: executor testado permite retomar etapas completas sem reduzir os gates; execução real integral permanece obrigatória para aprovar movimento.


### Prioridade executiva urgente — D-150

AuditoriaD-151 concluída: classificação LONG/SHORT existe na coleta, mas coortes perdem formato, seletor diário é LONG-only e o sinal principal está congelado em02/09. A comparação lucrativa entre formatos e a atualização contínua de mercado NÃO estão prontas. Correção aditiva futura: coortes por canal/formato/idade, decisão versionada e freshness obrigatório, atualização oficial gratuita governada pelo Gestor. Não reabrir o protocolo TOPIC_ANGLE nem ampliar o pack LIMITED. O relatório `docs/RELATORIO_ESTAGIO_ATUAL_2026-09-06.md` identifica arquivos, provas, fases e limitações.

Reiteração executiva do proprietário em06/09: acelerar o ciclo completo mercado→produção→publicação→medição→melhoria, preservando a maior qualidade/modelo. A única entrega produtiva corrente é o sucessor AV aprovado; catálogo universal/produto não bloqueiam sua conclusão. A comparação LONG/SHORT/HYBRID será auditada na mineração em paralelo, sem ampliar o FormatPack LIMITED nem trocar silenciosamente o protocolo TOPIC_ANGLE em curso. O relatório detalhado consolidará capacidades reais e lacunas; leitura/documentação não é contabilizada como vídeo entregue.

Manter uma única entrega principal: sucessor audiovisual do Vídeo 2, com voz/copy preservadas e QA integral. Não iniciar expansão de formatos, nova mineração genérica ou nona manutenção enquanto o lote corrente não estiver consolidado. Observação oficial do piloto continua independente no Gestor.

1. **Origem da população temporal corrigida em disco:** v3/schema1.2, seis focais principais PASS em39,118s. Origem de síntese reaberta e união de alvos excluída; uso limitado às unidades reconciliadas do release. Done when focal atendido, sem calibração LIVE nem A integral concluídas. A cópia byte-exata v2 não foi arquivada antes do patch e não está recuperada; não afirmar preservação/reversibilidade não demonstrada. Snapshot v3 atual foi criada e rehashada antes de novas mudanças.
2. **Otimização comprovada nas seis observações reais:** wrapper ROI preserva v2/política, resolução nativa, máscaras pixel-exatas e status. Comparativo `label-roi-equivalence-v1-8ea0f8e67f3046a3`: 10,8956704 s -> 0,5817685 s, 18,73x nesta etapa; quatro testes principais PASS. Próximo uso: avaliador temporal integral versionado, após resolver a observabilidade do papel. Não extrapolar o ganho ao vídeo inteiro ou aprová-lo pela amostra.
3. **Resolver somente as entradas que ainda impedem a montagem:** captions V2 têm 71 cues (34 inteiras/37 internas em17unidades). PocketSphinx5.0.4 já está isolado e carregando, com cobertura250/250, schema/25bindings e5testes rootPASS; não reinstalar. Faltam runner de estimativas preso à policy, holdout realmente anotado, calibração e contraprova independente aplicável. ASR/RMS existentes são auxiliares; não repetir inferência nem criar o reconciliador legado de39limites/800samples. Pausas/spans precisam de função editorial, sem silêncio para preencher banda. Done when: plano AV verificável, copy integral, banda/grade e eventos/captions aprovados temporalmente.
4. **Integrar uma vez o lote produtivo:** B/C/D do plano AV, preflight da receita exata, testes dirigidos dos consumidores, uma regressão consolidada e manutenção D-116; depois render retomável, QA/release e publicação no envelope. Nenhum diagnóstico isolado vira gate PASS do vídeo.

Par candidato28179 e CV61228 já são terminais exit0; não reiniciar nem redecodificar. Usar o checkpoint atual de STATE; entradas abaixo preservam a cronologia histórica, não representam processos ainda vivos.

Atualização do instrumento visual: V3 passou19/19controles root e o replay74/75 mediu cartas2/3; carta1 segueUNOBSERVABLE porque a receita não amostraLEFT, condicionamento182,05. Corrigir extrator de ROI/borda-fonte antes de150frames, preservando limiares e candidato. O ganho ROI de94,66%continua comprovado somente nas seis observações de labels. Nona manutenção permanece adiada até lote consolidado.

Resultado posterior V4: corrigiu LEFT da carta1 (19bordas, condição3,099), mas não mede cartas2/3 pelo mesmo contrato. Não substituir V3 globalmente nem anunciar melhoria geral. O replay é terminal, oito bindings íntegros; 15testes do observador e9do runner PASS no root. Próxima decisão visual fica limitada à composição/fallback por causa geométrica, com regra independente da qualidade aparente do candidato; não fazer outra alteração universal ou repetir esses pixels. Falta medição integral, e V3/V4 não são calibração LIVE.

Preflight temporal por custo medido: soma V3 no par retido=1,8277596s; V4/carta1 adicional=2,340955s. Extrapolação ingênua da rota fixa para149pares=621,14s, mais43,63s para450labels pelo benchmarkROI, sem decode/HUD/IO. É estimativa baseada em um par, não orçamento calibrado nem throughput comprovado. Não executar novamente o auditor monolítico antigo com teto180s. Próximo executor integral deve persistir frames/checkpoints hash-bound, retomar sem redecodificar etapas concluídas e usar orçamento/limites de supervisão separados dos limiares de qualidade. Uma execução mais longa não autoriza enfraquecer nenhum gate.

Compositor V3-first/V4-fallback congelado;17controles rootPASS e recomposição de receipts reais semCV confirmam a rota limitada. Não reabrir este diagnóstico sem evidência nova: consumir `layered_hook_paper_compositor_v1.py` e seu watchdog na integração integral. Mais uma versão exploratória do localizador não faz parte do lote autorizado corrente.

Atualização 06/09: faixa real de escuta de 190,8 s concluída e conferida slice a slice, preservando os 51 PCM. Etapa A implementada, root 22/22 PASS (212,196 s), revisão de origem temporal ainda em curso. Próxima ação produtiva: fechar calibração aplicável, 16 unidades que exigem captions divididas, pausas editoriais e spans reais; não completar a banda por silêncio de preenchimento. Mapeamento transacional da Etapa B é independente, sem admissão de A incompleta. Par candidato 74/75 em execução sessão28179; não repetir a fonte já retida. Manutenção somente depois do lote revisado e congelado, com preview novo gerado pelo protocolo real.

D-148 contraprova principal concluída: 70 testes PASS, GC-21 recomposto read-only PASS_LIVE com os dois testes qualificados e runtime real. Não repetir manutenção antes de concluir a revisão/congelamento do lote de código; D-116 histórico permanece FAIL. Etapa A em implementação e faixa QA de escuta contínua em preparação, sem preencher a banda temporal nem conceder admissão.

Atualização 06/09 11:02Z: oitava manutenção terminal FAIL exclusivamente na verificação final que rejeitou GC-21; 894 testes sem falhas/um skip, Gestor 12748 recuperado. Não iniciar nova regressão integral antes de isolar e contraprovar a causa de GC-21. Preservar o run e não relaxar D-116. Implementar em paralelo somente o domínio temporal da Etapa A (módulo/schema/testes), ainda desconectado de autoridade produtiva.

Contraprova fonte 74/75 concluída em 24,9793 s; replay íntegro sem nova decodificação. O PNG75 independente não é pixel-idêntico à fonte sequencial. Verificar essa diferença com BGR retido e proveniência antes do próximo par/custo; não converter divergência de referência em defeito de vídeo nem aprovação de movimento. Run e SHA constam do checkpoint corrente em STATE.

D-147 implementado e em revisão/contraprova principal: composição Python diretamente da inspection pinada para snapshot canônica e queue-before/after, com retorno somente de metadados ao PS. Grupo do executor 81/81 PASS, incluindo PS5+PS7; não somar ao grupo principal como testes distintos. Negativos, comparação integral antes do trabalho pesado e verificador independente inalterado. Não iniciar outra manutenção antes dessas contraprovas e revisão. Frente audiovisual continua separada e sem novo render integral.

Checkpoint: 51 PCM reais e medição acústica disponíveis; ASR 51/51, 46 matches/cinco divergências, 197 bindings e replay verificados. Contraprova contextual de três janelas concluída, 20 bindings e replay verificados, sem modificar/aprovar voz; divergências continuam auxiliares e não justificam repetir o reconhecedor até obter coincidência. ROI V2 e OCR amostrais passaram; movimento integral não verificado. Sétima manutenção: 882 testes sem falhas e um skip, porém D-116 FAIL por conversão de 11 strings temporais no PowerShell 7.6.5. Runtime recuperado no PID 10332. Preservar objetos opacos da inspeção fora do round-trip PS e testar PS5 + host atual, sem reclassificar receipts anteriores.

Seguir `docs/PHASE6_AV_SUCCESSOR_IMPLEMENTATION.md`: ASR/evidência temporal dos 51 PCM reais, plano AV, admissão transacional distinta de D-138, render por geração, QA independente e publicação pelo tail. O mapa identificou acoplamentos reais em voz/captions/paths e dez medições ainda UNOBSERVABLE; nenhum deles pode ficar implícito ou virar PASS por documentação. Não ressintetizar o conjunto disponível nem repetir render completo antes dessas entradas.

Atualização verificável: D-146 corrigiu a projeção do token, mas não encerrou a manutenção. Antes de outra regressão, provar a preservação literal de queue/quota/effects e executar a comparação integral state/inspection no preflight. OCR passou 18/18 com hash íntegro, mas auditoria temporal excedeu 180 s sem relatório. O profiler seguinte falhou antes do CV: contagem integral da fonte excedeu 35 s. Não repetir 150 frames; validar a contagem histórica da mídia exata e medir somente decode FFV1 sequencial 74/75 com uma thread/teto 30 s, checkpoint BGR e comparação do frame 75. Depois reusar esse par íntegro nas etapas seguintes. Saída ASCII-safe evita o erro cp1252 de apresentação sem reinterpretar o terminal anterior. Não aumentar limite nem enfraquecer qualidade para disfarçar falta de capacidade do avaliador.

## D-145 — Resultado real dos testes, sem novo falso bloqueio ou falso aceite

1. Preservar o run858 com sua distinção: unittest sem falhas/um skip; manutenção FAIL e recuperação bem-sucedida.
2. Unificar interpretação lexical estrita do transcript em daily, verificador de manutenção e seletor de evidência do aceite. Done when: exatamente um resumo íntegro, contagem conciliada, motivos/IDs permitidos de skip explícitos, negativos recusados; teste skipped nunca satisfaz critério que exige resultado ok.
3. Contraprovar contra logs reais preservados e fixtures adversariais antes de nova manutenção. Não repetir suíte integral com consumidores divergentes.
4. Congelar/revisar, preview atual e `daily.ps1` completo com recuperação e D-116. Nada autoriza reusar snapshot histórica como prova viva.
5. Prosseguir nas provas audiovisuais isoladas com memória serializada; seus diagnósticos não concedem admissão, release ou publicação.

## D-144 — Fechar a classe de falha antes da regressão integral

1. Reaproveitar o writer exclusivo/retry testado em helper de baixo nível, preservando wrapper executivo v2 e writers imutáveis.
2. Aplicar somente aos callsites de views mutáveis identificados nos 12 estágios, com testes por consumidor para lock transitório/persistente, bytes completos e zero efeito externo.
3. Congelar/revisar, executar `daily.ps1` com preview corrente, regressão estável e recuperação. Done when: receipt final e D-116 com ciclo novo 12/12; nenhum FAIL anterior é reclassificado.
4. Em paralelo, conservar prova hook002 de 150frames/5s e revisão principal de três frames; falta avaliação temporal integral. Completar somente os 18PCM faltantes quando a capacidade real passar, sem repetir os 33 existentes.
5. Reconciliar os 51PCM, duração medida, alinhamento e retiming na banda do experimento; integrar fontes concretas e remediação audiovisual antes do render completo e Quality Gates. Não promover fase/capacidade por diagnóstico isolado.

## D-143 — Prioridade coerente com o impedimento de produção

- Gate integrado adicional: regressão845 encontrou divergência de representação GOAL no verificador D-116; corrigida por versão no produtor/preview/verificador independente, com21/21 e68/68 focaisPASS. Próxima manutenção deve incluir esses consumidores e registrar nova contagem/hash, sem reinterpretar o FAIL anterior como PASS.
- Sequência corrente: concluir prova curta já em execução; congelar código/schema/testes; nova manutenção integral e recuperação/ciclo12fontes; síntese somente das18faltantes quando capacidaderealPASS; mapa temporal medido e remediação audiovisual integrada. Observação oficial e piloto público permanecem independentes, sem gasto/fase antecipada.

- Atualização verificável: implementação e schemas concluídos em disco; contraprova principal final de 65/65 testes PASS em20,544s, incluindo corrupção posterior à gravação da trajetória. Não é deployment. Fixtures das sete falhas da regressão anterior corrigidas e congeladas: grupo85/85 PASS; após alteração final para PNGs realmente decodificáveis, seis testes impactados PASS. Grupos sobrepostos não são somados.
- Janela protegida concluída: snapshot próprio de06:46:17Z,36,007h,14views,265inscritos observados oficialmente; Analytics/reach/retention indisponíveis. Próxima observação diária06/09 18:45:51Z; checkpoint criativo07/09 18:45:51Z. A manutenção deve reconferir essas fontes no instante do request.
- Inventário de áudio materializado em diagnóstico:51unidades,33PCM disponíveis sem aprovação e18faltantes. Próximo elo: proposta de síntese somente das faltantes, com journal por unidade, parâmetros exatos e preflight antes do efeito; depois retiming/captions e prova integrada. Não sintetizar novamente os33 arquivos apenas por mudança de posição na timeline.
- Hook estático de5s foi produzido, mas reprovado para tracking sobre papel: contenção geométrica não conservou relação espacial convincente durante a câmera. Próxima prova requer coordenadas derivadas do movimento e três frames revisados antes de novo encoder; fontes/MP4s anteriores preservados.

- Fase 6, sem expansão: preservar protocolo, métricas, fila, arquivos históricos e autorizações. A manutenção D-142 migrou a espera, mas a regressão terminou com 2 falhas/5 erros; recuperação confirmou PID 7096 vivo. Não repetir manutenção dentro da janela protegida da observação das 06:41:36Z.
- Corrigir os testes de binding e as fixtures de publicação contra os contratos reais, mantendo os controles negativos e sem desabilitar gates.
- Trajetória 1.3/painel 1.4: reconhecer espera pós-efeito comprovada e erros/bloqueios de mídia antes de recomendar síntese/render; reabrir prova uma vez, registrar identidade/evidência e não transformar timestamp de heartbeat em decisão nova.
- Done when: provas válidas/inválidas/adulteradas testadas; métricas e flags de autoridade conservadas; schemas antigos preservados; painel/ciclo/transição compatíveis; regressão integrada e implantação D-116 posteriores. Nenhuma fixture verde aprova a mídia.
- Frente audiovisual independente: prova curta de 5 s com intermediário e WAV existentes, preflight de memória/disco e retomada de QA sem novo encoder. Não renderizar o vídeo integral antes de continuidade sonora, semântica e nova linhagem aprovadas.

## Checkpoint de execução — integração sem render prematuro

- Escrita do painel: writer v2 implementado; contraprova principal 28/28 PASS em 62,375 s. Próximo gate: preview deve executar a mesma correlação do erro histórico usada pelo commit, incluindo bytes/timestamp/paths exatos, saída posterior íntegra e par JSON/Markdown reconciliado. Só depois congelar e repetir manutenção; falha anterior/recovery permanecem documentados.
- Evidência posterior do hook v3: verificador integral recusou frames 102–149 antes do MP4 candidato. Preservar `layered-hook-proof-a1da6f2da24300a0c475f32c` e seu FFV1. Próxima correção resolve posicionamento contra o span completo, não apenas primeiro frame; retomar depois da manutenção independente D-142. Não baixar clearance/piso para fazer passar.
- Provas D-141 concluídas no escopo diagnóstico: três novas falas, medição acústica e ASR local independente. Contraprova principal de 25/25 testes PASS e 9/9 bindings ASR íntegros. Pronúncia completa, pacing e sincronia não aprovados; não sintetizar as 51 unidades para descobrir novamente o problema no fim.
- Hook: corrigir protrusão real do backing CHOOSE verificada no primeiro frame; manter prova v2 rejeitada para essa exigência e revisar nova prova de cinco segundos antes de integrar.
- Executor: separar espera de correção do vídeo de falha do Gestor, conservando bloqueio de produção e publicação. Preview corrente deve passar após a última mudança; não utilizar um preview anterior como prova da versão atual.
- Implantação: congelar código/testes, executar somente `scripts/daily.ps1`, regressão estável e recuperação D-116. Done when: receipt final, novo processo verificado, ciclo novo 12/12 e cinco fontes íntegras; fila/cota/efeitos preservados. Um WAIT legítimo não equivale a produção pronta.
- Próxima cadeia produtiva: contrato específico de remediação audiovisual, novos ativos concretos admitidos, unidades contínuas com alinhamento e retiming dentro da banda do experimento, namespace preservador, preflight integral e prova curta integrada antes do novo render completo.

## D-141 — Correção integrada antes da próxima renderização completa

- Concluído focal: diagnóstico dos 90 WAVs e planejador de 51 unidades de narração, com preservação de texto/voz/horizonte e contraprova principal de nove testes PASS. Detalhes e limitações em `docs/PHASE6_NARRATION_CONTINUITY_FINDINGS.md`.
- Em execução: amostra real local de três unidades críticas; sidecar e prova curta do hook com N/T/C primário e TRT secundário; migração transacional do estado terminal para uma espera explícita pela remediação. Nenhuma dessas frentes dispensa os gates de produção.
- Done when da prova sonora: preflight PASS, WAVs novos íntegros/medidos sem aceleração ou truncamento, comparação com a montagem histórica, revisão independente e resultado real de alinhamento/pacing. Plano ou duração somada antiga não satisfaz o critério.
- Done when do hook: fonte e voz exatas, geometria declarada como hipótese até revisão dos pixels, 150 frames reais/5 s e contraprova nas bordas/meio/mudança de overlay, mecanismo narrado preservado e ausência de cobertura da função da fonte. Layout matemático isolado não satisfaz.
- Done when do executor: derivado rastreável sem reabrir SUCCEEDED; histórico e fila preservados; falhas e rollback testados; regressão em snapshot estável, recuperação e nova prova viva D-116. Aguardar a coleta própria devida antes da manutenção; observação de 04:41:36Z já concluída, próxima prevista 06:41:36Z.
- Depois: integrar receitas/ativos/voz por remediação explicitamente compatível, revalidar 90 takes, residência/direitos/capacidade e render completo. Fase 6 permanece IN_PROGRESS; Fases 7–8 dependem dos gates reais.

## D-137/D-138/D-139 — Prevenir erro editorial antes do processamento pesado

- Concluído focal: verifier da proposta isolada, receita visual v3/layout medido, opção de capacidade sem alterar latest e OCR diagnóstico real. Proposta `visual-alignment-0d081c519410bf855a2fe0f6` **reprovada editorialmente**, não promover apesar de PASS estrutural.
- D-138: base transacional testada, sem controller integral, verificador vivo, namespace produtor ou integração Quality/Publication. Não é sucessor operacional nem autoriza novos ativos.
- D-139 implementado e revisto em disco: fallback concreto fechado, papéis/fonte/blueprint/allocation reconciliados e progressão TRT incompleta/regressiva bloqueada antes de archive/overwrite. Contraprova principal 44/44 semantic+production PASS em 68,065 s. Corpus corrente continua BLOCKED; nenhum input histórico foi reescrito. Deployment não realizado.
- D-140 em execução: receita especializada de duas colunas literais, plano próprio schema-validável e teste de integridade/semântica que rejeita alteração mesmo com hash recalculado. Preserva as 12 falas/slots originais; prova local planejada em 36,4 s com WAVs exatos reutilizados, câmera estável, labels fact/forecast e sem terceiro card. O script exige preflight local e escreve apenas diagnóstico isolado; não autoriza produção nem fonte nova na biblioteca. 8/8 testes próprios PASS; revisão independente e prova renderizada ainda pendentes neste checkpoint.
- Atualização D-140: prova real v2 de 36,4 s passou no escopo visual local após controle negativo CRLF e emissão byte-exata LF; 23/23 testes focal PASS. O áudio mantém pausas inadequadas e não passou naturalidade. `docs/PHASE6_D140_SOURCE_PROOF.md` registra hashes, dez frames, controles e limites. Próximas frentes bounded: hook em camadas, planejamento de unidades de narração que atravessem cortes e ciclo/migração seguro do estado terminal; sem runtime ou produção autorizados por esses protótipos.
- Próximo artefato criativo: plano coerente com mecanismo principal N/T/C e identidade secundária TRT, infográfico de duas colunas fiel à fala, overlays que não escondam informação e payoff funcional. Nova seleção de ativos precisa remediação explicitamente autorizada pelo contrato técnico e direitos novamente verificados.
- Done when desta correção: testes adversariais PASS; auditoria dos 90 takes; capacidade exata; provas curtas com voz/ativos reais aprovadas independentemente; sucessor preservando história; render completo/QA/release após deployment e regressão D-116. Não marcar pronto com layout, receipt ou fixtures isolados.
- Estado real e provas: `docs/PHASE6_D137_EDITORIAL_REVIEW.md`. Sem nova publicação, gasto, reinício ou fase promovida.

## D-136 — Acertar o contrato antes do custo pesado, Fase 6

- Implementado em disco: checagem cruzada TakePlan/tratamento/Bible/receita, receipt verificável, bloqueio antes de capacity/Queue/TTS/render e antes de overwrite do compiler. Contraprova real de 90 takes BLOCKED em 0,791407 s; nenhuma alegação de vídeo aprovado ou taxa de sucesso futura.
- D-135: resolver query-only de autoridade COMMITTED concluído/testado no escopo local; não constitui sucessor pós-efeito.
- Render anterior terminou SUCCEEDED sem lease em `2026-09-06T02:35:55Z`; preservar checkpoint/bytes. Próxima sequência: reconciliação criativa versionada → sucessor seguro/namespaces → preflight aprovado → provas curtas reais → deployment/regressão/prova viva → produção e QA completo → release/publicação condicionados.
- Done when deste endurecimento: testes positivos/negativos, zero efeito pesado quando bloqueado, receipt recomposto e deployment comprovado. O último requisito ainda falta. Provas curtas e instrumentação agregada de acerto/retrabalho também não são apresentadas como implementadas. Detalhes em `docs/PHASE6_FIRST_PASS_PREVENTION.md`.

## D-133 — Reserva recomposta; retomada do caminho crítico autorizada

Primeiro avanço após a recomposição, D-134: barreira da autoridade PREPARED implementada e revisada; 28 testes queue + 5 media authority PASS, incluindo concorrência/falha de storage/replay. Sem deployment ou alteração de fila viva. O plano completo de sucessor permanece em `docs/PHASE6_POST_EFFECT_REMEDIATION_DESIGN.md`; fechar essa race não equivale a concluir a remediação.

Um reset gratuito confirmado pelo usuário foi aplicado e revalidado em `2026-09-06T02:15:39Z`: 100% disponível, saldo 2.500 intacto, dois resets restantes; decisão `codex-usage-2fd2d836fdeb7945` GREEN/schema-válida/twin idêntico. D-132 continua como política, mas sua restrição temporária de CRITICAL_RESERVE não é o estado corrente. Detalhes/receipt em `docs/CODEX_SHARED_CAPACITY_POLICY.md`.

Retomada limitada ao caminho crítico já auditado: fechar a race de claim do sucessor PREPARED em SQLite temporário, preservar a exportação ativa, reconciliar framework e depois implementar a remediação pós-efeito sem apagar a geração anterior. Não iniciar runtime dependente, novo render ou publicação antes dos respectivos gates. Manter coordenação de capacidade com QR Dolar e reavaliar antes de frentes extensas, sem repetir monitor ou alterar qualidade.

## D-132 — Gestão conjunta de capacidade, aplicada

Checkpoint de retomada: `docs/PHASE6_POST_EFFECT_REMEDIATION_DESIGN.md` preserva a auditoria já concluída, mas não implementada, do sucessor pós-render com histórico intacto. Em `2026-09-06T02:01:54Z`, 90 segmentos estavam prontos e FFmpeg 14952 codificava o MP4; job c516 LEASED com prazo `02:46:50Z`. Próxima ação segura é observar esse efeito até estado terminal confirmado, preservar o resultado e os defeitos conhecidos e reavaliar capacidade antes de implementação nova. Arquivo parcial não autoriza QA/publicação nem reinício.

- Escopo: Modelagem Youtube e QR Dolar, igual importância, um único limite da conta; preservar fases/qualidade/runtimes locais.
- Implementado: roster conjunto, decisão/schema 1.1 com histórico 1.0 preservado, crédito sem origem inferida; seis testes focais PASS; observação viva validada e twin byte-idêntico. Regra confirmada na tarefa QR Dolar e incorporada ao monitor diário existente, sem duplicação.
- Estado: `CRITICAL_RESERVE`, 98% usado/2% restante em `2026-09-06T01:48:37Z`; reserva de 10% não preservada. Saldo 2.500 créditos finitos e três resets não acionados. Renovação `2026-09-10T09:56:07Z`.
- Próximo checkpoint: concluir somente trabalho seguro já iniciado e testes necessários, registrar evidências e adiar expansão discricionária, sem interromper o render residente. Nova etapa extensa exige leitura atual da conta e reavaliação conjunta. Não existe hard cap por projeto ou garantia de saldo infinito.
- Done when desta incorporação: política/schema/testes/observação/registro nas duas tarefas/monitor existente reconciliados. Não equivale à conclusão do YouTube, do QR Dolar ou à reserva efetivamente recomposta. Ver `docs/CODEX_SHARED_CAPACITY_POLICY.md`.

Todo plano de fase deve usar esta estrutura.

## Identificação

- Fase:
- Objetivo único:
- Estado atual:
- Prompt autorizado:
- Documentos lidos:

## Entradas

- Arquivos:
- Dados:
- Fontes:
- Credenciais necessárias:
- Direitos/licenças necessárias:

## Fora de escopo

Liste explicitamente tudo que não será feito nesta fase.

## Entregáveis

Para cada entrega, informe caminho, formato e consumidor.

## Alterações previstas

| Arquivo ou componente | Ação | Motivo | Risco |
|---|---|---|---|
| | | | |

## Testes e evidências

- Testes unitários:
- Testes de integração:
- Testes de aceitação:
- Exemplos reais:
- Comparação com padrão-ouro:

## Critérios de aceitação

Copie os critérios da fase e transforme cada um em verificação objetiva.

## Riscos e bloqueios

- Riscos conhecidos:
- Informações ausentes:
- Decisões necessárias:

## Encerramento

- Resultado:
- Testes executados:
- Critérios aprovados:
- Critérios reprovados:
- Critérios bloqueados:
- Próxima fase da fila autorizada e pré-condições:

## Plano complementar ativo — Inteligência Contínua Viva

- Requisito integral: `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md`.
- Relatório de impacto: `docs/CONTINUOUS_INTELLIGENCE_IMPACT.md`.
- Plano detalhado faseado: `docs/CONTINUOUS_INTELLIGENCE_PLAN.md`.
- Estado: incorporado e aprovado; execução permanece faseada.
- Regra: o complemento não substitui este template nem cria fase paralela. Desde D-047, cada subtarefa entra na fase existente correspondente após gate automático verificável; revisão humana permanece somente onde o contrato exige padrão-ouro, direito ou julgamento externo não automatizável.
- Fase atual: Fase 6 em `IN_PROGRESS`; Fase 5 aprovada após publicação private-first verificável do canário `iK_5edYQtx8`. A janela operacional de 30 dias começou em `2026-09-04T18:45:51Z` e termina em `2026-10-04T18:45:51Z`. O piloto permanece em um canal, nicho e FormatPack `LIMITED`; meta não é tratada como garantia da plataforma.

## Correção permanente ativa — Gestor Central Autônomo

- Requisito integral e imutável: `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`.
- Impacto e mapa de reaproveitamento: `docs/GESTOR_CENTRAL_IMPACT.md`.
- Arquitetura e contratos: `docs/GESTOR_CENTRAL_ARCHITECTURE.md`.
- Autonomia e supervisão por exceção: `docs/GESTOR_CENTRAL_AUTONOMY_MATRIX.md`.
- Aprendizado, previsibilidade e scorecard: `docs/GESTOR_CENTRAL_LEARNING_AND_PREDICTABILITY.md`.
- Plano incremental e critérios `Done when`: `docs/GESTOR_CENTRAL_IMPLEMENTATION_PLAN.md`.
- Aceitação e demonstração: `docs/GESTOR_CENTRAL_ACCEPTANCE.md`.
- Manifesto de arquivos e verificações: `docs/GESTOR_CENTRAL_CHANGE_MANIFEST.md`.
- Estado: requisito aprovado e permanente; implementação incremental.
- Esta correção especializa a Inteligência Contínua como Gestor Central de 100% da operação, preserva a ordem das Fases 1–8 e não permite que o Gestor aprove a própria exceção.
- Escopo atual: Fase 6 — Own-Channel Observer, fila/lease/retry/DLQ, plano editorial controlado, previsão prévia, diagnóstico, pré-registro, receipt de escopo `LIMITED`, ordem de tratamento, compilador de pré-produção, release preparer, executor real de mídia, avaliador independente, controlador private-first e aprendizado factual recebem apenas comandos centrais. O primeiro snapshot próprio existe; o observador está `NOT_DUE` até 24 h. A YouTube Reporting API está ativa e os jobs basic/reach são idempotentes; o adapter de alcance baixa e valida CSV próprio, mas o provedor ainda não entregou o primeiro relatório. A fila real contém o checkpoint de 24 h. Antes dele, diagnóstico e ordem ficam `WAITING_FOR_ELIGIBLE_BASELINE`, variável/métrica `NONE`, receipt de escopo `WAITING`, release/mídia/qualidade/publicação `WAITING` e nenhum job é criado. Depois do snapshot elegível, o Gestor fixa uma variável, pré-registra, exige o overlay exato `fp-broll-cinematic-narration-phase6-controlled-lot@1.0.0`, valida 13 pré-condições e só então percorre a cadeia hash-pinned `pré-produção -> filtro autoral + publicity -> ativos -> síntese/render -> 18 gates + 19 defeitos -> pacote -> release gate -> staging privado -> thumbnail/captions/processamento -> público -> verificação`. `RIGHTS` e `PUBLICITY` são independentes: risco institucional conhecido é excluído antes do render; rosto, arquivo ilegível ou risco remanescente falha fechado no QA com YuNet local versionado. As Fases 7–8 seguem pré-autorizadas e condicionadas; gasto permanece bloqueado.

## Requisito permanente — válvula de aceleração

- Contrato mestre: `docs/12_ACQUISITION_ACCELERATOR_MASTER.md`.
- Schema: `schemas/acquisition_experiment.schema.json`.
- Regra oficial: tráfego, horas e inscritos de campanha não são progresso qualificado do YPP.
- Estratégia: medir incremento orgânico posterior com baseline/controle, `follow-on views`, orçamento limitado e stop-loss.
- RPM: usar dados reais próprios após monetização; proxies pré-YPP permanecem inferidos/indisponíveis.
- Ativação: somente na Fase 6 ou posterior, após conteúdo e métricas próprias, com autorização expressa de gasto.
- Promote: smoke test opcional; Google Ads controlado é preferido quando for necessário experimento e atribuição avançados.

## Requisito permanente — motor editorial adaptativo

- Contrato: `docs/13_ADAPTIVE_VIRAL_EDITORIAL_ENGINE.md`.
- Fronteiras rígidas: nicho, identidade, direitos, política, qualidade, evidência e envelope.
- Variáveis adaptativas: tema, ângulo, promessa, embalagem, hook, ritmo, visuais e CTA.
- Norte: visualizações e velocidade normalizadas, novidade, convergência e evidência contemporânea; nunca views brutas ou garantia de viralização.
- Cada execução registra cutoff, alternativas, rejeições, cobertura, riscos e versão do score.

## Requisito permanente — Direção Criativa e FormatPacks

- Contrato: `docs/15_CREATIVE_DIRECTION_MASTER.md`.
- Implementação incremental: `docs/CREATIVE_DIRECTION_IMPLEMENTATION_PLAN.md`.
- Capacidade real: `docs/CREATIVE_DIRECTION_CAPABILITY_DASHBOARD.md`.
- Ferramentas: `docs/CREATIVE_DIRECTION_TOOL_MATRIX.md`.
- Validação: `docs/CREATIVE_DIRECTION_VALIDATION_MATRIX.md`.
- Estados oficiais: `CATALOGED`, `SPECIFIED`, `PROTOTYPED`, `VALIDATED`, `PRODUCTION_READY`, `LIMITED`, `BLOCKED`, `DEPRECATED`.
- Regra: produção regular usa somente `PRODUCTION_READY`; `LIMITED` exige aderência integral ao limite. Estado inferior bloqueia.
- O Diretor Criativo é executor do Gestor Central, sem estratégia, memória ou aprovação paralelas.
- Cada vídeo exige decisão justificada, Style Bible, TakePlan, perfil de qualidade e 18 gates com evidência.
- Snapshot vigente da Fase 5: 291 entradas; 290 `CATALOGED`; 1 `LIMITED`; 0 `PRODUCTION_READY`. O pack-base foi validado para o primeiro canário. Qualquer próxima ação exige reavaliação própria e receipt imutável do overlay controlado; isso não promove o pack nem libera render/publicação.
- CD-1 a CD-3, conform STANDARD e replay independente passaram. `hero_engine/phase5_autonomous_quality.py` executa avaliação automática por release, presa ao SHA-256, separada do gerador e idempotente; ASR local, captions, movimento, continuidade, semântica, direitos, originalidade, identidade e thumbnail formam doze gates críticos.
- O console humano permanece como instrumento de calibração, amostragem de 10% e exceções. Não é uma etapa manual obrigatória para cada vídeo e não é preenchido pelo sistema. Mudança de pack/pipeline/voz/ferramenta, ambiguidade legal, anomalia/reclamação e o terceiro vídeo `LIMITED` disparam amostra obrigatória; sem ela não há promoção a `PRODUCTION_READY`.
- Estação local supervisionada: `hero_engine/phase5_review_console.py` é servida apenas em `127.0.0.1`, pelo mesmo PID efetivo do Gestor Central, com token efêmero, vídeo por byte range, captions VTT, reprodução sequencial integral em 1×, cobertura mínima de 95%, áudio, prévia móvel, 9 janelas, 12 gates, evidência textual e seleção A/B/C embaralhada. A auditoria real encontrou o MP4 sem iniciar por seleção tardia do `<source>`; o console agora chama `video.load()`, exibe estado `Loading/Ready/Error` e foi verificado no navegador com `Ready · 238.7 s`, barra habilitada e primeiro frame visível. Ela grava receipt canônico somente após validação do contrato; tentativa incompleta permanece separada e não libera publicação.
- Revisão vigente: `creative-v3.2`, com 22/22 remediações automáticas PASS, 238,7 s, 59 takes, 22 fontes, quatro infográficos locais, três fontes no hook, captions completas e 24,7591% de paisagem dominante. O maior ativo ocupa 8,2111%, os seis maiores 44,3653%, há no máximo quatro usos por ativo e três por janela móvel de 60 s. O avaliador autônomo passou 12/12 gates; ASR independente mediu WER 0,009259; thumbnail B foi selecionada pelo rubric predefinido.
- Próxima execução condicionada: coletar o checkpoint próprio de 24 h do canário público, diagnosticar o gargalo dominante, pré-registrar uma única variável e emitir o receipt `LIMITED` para a ação exata; só então a embalagem do canário ou a pré-produção do Vídeo 2 poderá ser compilada. Ads, gasto, exceção de direitos e serviço pago continuam sem autorização. A revisão humana será amostral/por exceção, não uma trava em todo release.
- Integração YouTube: Data/Analytics estão conectadas e vinculadas ao channel ID real. O app `HeroVerse Channel Operations` está `IN_PRODUCTION`, os quatro escopos exatos estão gravados no Data Access e a operação atual registra a isenção oficial `PERSONAL_USE` com um usuário OAuth vitalício. A reautorização pós-configuração foi concluída pela conta Wellisson; espelho atômico, refresh sem navegador, hash atual e identidade `UCuMF6pJQkyMzaVoAxFL86yA` passam. O readiness está `DURABLE_POLICY_CONFIGURED`, sem blockers, e libera somente `active-private-first`. A cota prova 5/10.000 queries, 0/100 uploads e nenhum billing.
- Transição OAuth: `oauth-production-transition-plan.json` v1.1 separa a operação pessoal atual da futura implantação comercial. O site GitHub Pages está público/HTTPS, sem login, com quatro hashes idênticos e custo R$ 0,00; Search Console comprova a propriedade `URL_PREFIX`. Isso não comprova uma `DOMAIN_PROPERTY` DNS de `github.io`: a verificação completa de marca e o produto multiusuário comercial permanecem bloqueados até existir domínio DNS próprio. A reautorização final da conta Wellisson foi concluída e o refresh não interativo passa; nenhuma autenticação está pendente na operação atual.
- Integração vidIQ: o plugin nativo foi validado como `LIMITED` para pesquisa pública. A conta esperada está autenticada, mas a lista de canais próprios autorizados veio vazia; portanto Analytics privado continua indisponível. O bucket gratuito tem 150 créditos renováveis, 55 consumidos, 95 restantes, renovação em `2026-10-03T16:42:50Z` e piso preventivo de 25. Nenhum billing ou custo foi acionado; o fallback é API oficial/cache/análise local.
- Empacotamento vigente: o título de trabalho 82/100 foi substituído no pacote por `The 24-Hour Test: What To Do After You Pray` (91/100), porque expõe o mecanismo real sem prometer resultado. A alternativa 96/100 foi rejeitada por conflito de voz editorial. Scores vidIQ permanecem heurísticos e não equivalem a previsão de CTR.
- Overlay próprio vidIQ: catálogo público de 20 Shorts + 1 long foi reconciliado; sete badges cobrem 90,9749% das views Short. Como as views não mudaram e a transferência Short->long é não comprovada, o ciclo registra `NO_NEW_EVIDENCE` e preserva o hook atual apenas como hipótese.
- Gate operacional atual: `release_gate.json` integra artefatos, QA automático, política de padrão-ouro humano, thumbnail, captions, FormatPack, direitos, canal, OAuth, escopos, private-first e custo/cota. Resultado real `READY_FOR_PUBLICATION_PIPELINE`, 13/13 gates PASS e zero blockers. A ordem congelada é staging privado -> thumbnail -> caption -> verificação -> promoção pública -> verificação final.
- Supervisor executável: `hero_engine/central_manager_phase5.py` preserva o nome histórico, mas agora coordena Fases 5–6: observa insumos, reaplica guards, mantém heartbeat, pausa por arquivo, atualiza Reporting antes dos checkpoints, opera fila transacional e materializa métricas/inteligência/status executivo. Um lock real do SO com lease impede duas autoridades; a tarefa `HeroEngine-Phase5-CentralManager` inicia no logon, reinicia falhas limitadamente e usa credencial fora do workspace. O receipt correlaciona tarefa/PID/lock/console, prova que a segunda instância sai com código 73 e mantém custo R$ 0,00.
- Evidência vigente: STANDARD SHA-256 `33829cd7…3260c`, replay SSIM 0,99782 e QA automático PASS. O baseline `creative-v3.1` foi preservado e marcado como reprovado depois que a amostragem integral expôs 66,3176% de concentração nos seis motivos dominantes.
- Regressão vigente: manutenção transacional completa com código 0; depois da correção final, suíte integral isolada `230/230 PASS` em 135,403 s; `105/105` schemas válidos no Draft 2020-12; manifesto da Fase 5 com 554 artefatos/3.080.086.312 bytes. `scripts/daily.ps1` para a cadeia verificada, reconcilia a snapshot estável, testa, materializa todos os executores da Fase 6, regenera catálogo/forecast e recupera o Gestor em `finally`. A manutenção mais recente recuperou o runtime no PID efetivo 15096, tarefa `Running`, lock `HELD`, console no mesmo PID, duplicata bloqueada com código 73, stderr zero e `operational_ready=true`. A lacuna autoral/publicity foi corrigida com filtro pré-render, QA independente, detector YuNet local de hash fixo e 5 controles direcionados; o work order evoluiu para contrato `1.1.0` sem invalidar o imutável `1.0.0`. Um erro executivo anterior foi arquivado byte a byte por hash e deixou de ser alerta corrente após rematerialização válida. O canário está público, OAuth `HEALTHY`, fila `HEALTHY`; scope receipt, ordem, release, mídia, qualidade e publicação aguardam o snapshot de 24 h sem criar job prematuro; custo R$ 0,00.
- Durabilidade OAuth executável: `--force-reauthorize` substituiu o token somente depois do callback pessoal bem-sucedido, espelhou atomicamente, provou refresh sem navegador e revalidou `UCuMF6pJQkyMzaVoAxFL86yA`. Uma falha real `NameError: ROOT` foi detectada antes do espelho, preservou o token antigo, foi corrigida e ganhou teste de regressão. `OAUTH_DURABILITY` passou; o publicador segue com zero chamadas porque quatro gates editoriais permanecem bloqueados.
- Isolamento de conta: futuras reautorizações usam somente a UI oficial do Google com `prompt="consent select_account"` e `access_type="offline"`. Isso impede herdar silenciosamente a sessão ativa em computadores com várias contas, sem armazenar ou automatizar senha/código; depois do consentimento pessoal, o Gestor volta ao refresh automático e à identidade presa ao channel ID.
- Saúde da sessão: o Gestor valida a concessão a cada 24 horas sem navegador, persiste o token somente após refresh/escopos/channel ID passarem e limita a prova a uma unidade da Data API por dia. Falhas transitórias repetem após 6 horas; ausência real de concessão ou três falhas em sequência geram uma única exceção `REAUTH_REQUIRED`. Estado real atual: `HEALTHY`, identidade verificada, zero falhas, nenhuma intervenção e próxima prova em `2026-09-05T21:47:53.786430Z`.
- Continuidade da estação: o plano Windows Equilibrado está com desligamento de vídeo em `Nunca` para tomada e bateria (`VIDEOIDLE` AC/DC = 0), conforme solicitação do proprietário. Isso não altera bloqueio, senha, segurança ou privacidade.

## Requisito permanente — Channel Readiness

- Contrato: `docs/CHANNEL_READINESS_MASTER.md`.
- Auditoria real: `docs/HEROVERSE_CHANNEL_AUDIT.md`.
- Capacidade/custo do Codex: `docs/CODEX_CAPACITY_AND_COST_REPORT.md`.
- Antes de cada publicação: snapshot autenticado, gates do canal, receipt de mudanças e vínculo no pacote editorial.
- Perfil corrigido em `2026-09-03`: descrição, palavras-chave, localização inglesa conflitante e Home pública com conteúdo.
- Estado: descrição/Home estão corrigidas; banner, avatar e watermark v2 foram salvos e a marca está `VERIFIED_PUBLIC`; Channel Readiness de publicação está `PASS`. Catálogo legado, YPP, OAuth durável e gates humanos do candidato permanecem bloqueios explícitos; nenhum vídeo foi enviado.

## Modo de execução contínua integral — D-047

- Autorização: Fases 5–8 em sequência, sem parada para aprovação inter-fases ou decisão técnica reversível.
- Gate: automático, binário, evidenciado e fail-closed; falha gera correção/reteste, não relaxamento.
- Revisão humana: preservada para padrão-ouro, direitos e julgamentos externos exigidos; não é substituída pelo gerador.
- Ações externas: upload/publicação sem gasto somente quando todos os gates críticos e direitos passarem e houver receipt; orçamento, Ads, serviço pago, exclusão e exceção permanecem protegidos.
- Comunicação: checkpoints informativos não interrompem a execução.

## Requisito permanente — operação técnica com custo zero

- Contrato: `docs/16_ZERO_COST_OPERATION_MASTER.md`.
- **CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.** Nenhum plano pode depender de compra, assinatura, cartão, trial com renovação, API paga, servidor ou domínio comprado.
- Cada fase deve listar cotas gratuitas, consumo observado, renovação, margem preventiva, risco de cobrança, fallback local/gratuito, hardware, tempo e qualidade.
- O Gestor bloqueia antes da cota e troca para fallback sem cobrança; ausência de fallback com qualidade mínima resulta em `BLOCKED` e não em gasto ou redução silenciosa do gate.
- YouTube Promote é exceção somente como mídia; continua desativado até orçamento expresso e não pode financiar ferramentas ou infraestrutura.

## D-089 — Tratamento de embalagem passa a ser executável, reversível e mensurável

- Status: implementado, integrado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` até o checkpoint D1 e os resultados reais seguintes.
- Ramo exato: quando o diagnóstico pré-registrado escolher `TITLE_THUMBNAIL_PROMISE`, `hero_engine/phase6_package_treatment.py` gera a thumbnail selecionada localmente, valida 17 gates críticos e agenda o par exato no primeiro limite elegível de dia do Pacífico. Antes dessa seleção, o estado real é `WAITING_FOR_PREREGISTRATION` e nenhuma API de escrita é chamada.
- Transação: `videos.update(part=snippet)` preserva o snippet completo; `thumbnails.set` aplica somente o JPEG congelado. Cada efeito é persistido, o resultado é confirmado no vídeo público e na imagem entregue pela CDN e uma divergência dispara rollback de título e thumbnail.
- Mensuração: o receipt registra datas do baseline/tratamento e atraso real em relação ao limite. `phase6_learning_runtime.py` aguarda a data completa, baixa linhas diárias do Reporting API e compara somente os dias adjacentes fixados, com impressões como amostra, erro-padrão na unidade percentual correta e classificação limitada ao canal.
- Cota/custo: reserva exata de 100 unidades gerais; cota oficial padrão 10.000/dia, sem billing e com piso preventivo. Custo técnico e mídia permanecem R$ 0,00.
- Gate atual: executor carregado pelo Gestor em `WAITING_FOR_PREREGISTRATION`; `public_package_changed=false`; próxima ação automática continua sendo o checkpoint de 24 horas em `2026-09-05T18:45:51Z`.
- Prova: manutenção transacional código 0; `245/245` testes PASS em 152,584 s; `111/111` schemas válidos; Python compileall PASS; tarefa `Running`, PID 19832, lock/console no mesmo processo, duplicata bloqueada em 73, stderr zero e `operational_ready=true`.

## D-090 — Aceite da Fase 6 deixa de ser documento estático e passa a ser gate executável

- Status: implementado e verificado em `2026-09-04`; Fase 6 permanece corretamente `IN_PROGRESS`.
- `hero_engine/phase6_acceptance.py` reconcilia os 22 casos GC com artifacts e testes exatos, valida SQLite, distingue `PASS_FIXTURE` de `PASS_LIVE`, gera JSON/Markdown e impede promoção enquanto faltar a classe de evidência requerida.
- `scripts/daily.ps1` persiste um receipt da regressão com comando, quantidade, tempo, logs e manifesto; materializa explicitamente tratamento de embalagem e aprendizado, além do loop residente; reconcilia escopo OAuth e release gate antes da snapshot estável.
- Ensaio de falha: a primeira manutenção encontrou o hash antigo do scope OAuth preso no release gate, recuperou o Gestor em `finally` e terminou com erro. A rotina foi corrigida, o caso ganhou asserção e a repetição integral passou.
- Prova histórica: receipt `daily-maintenance-20260905T0134413537349Z`; `247/247` testes PASS em 133,498 s; manifesto 554/3.080.086.312; tarefa `Running`, PID 21412, lock/console coincidentes, duplicata 73, stderr zero. D-092 corrigiu a classificação circular de GC-14 sem removê-lo do produto final.
- Bloqueios honestos da Fase 6: GC-01 ciclo real, GC-11 experimento real e GC-19 outcome da previsão aguardam dados do piloto; GC-14 aplicação futura permanece obrigatório na Fase 7.

## D-091 — Outcome de previsão passa a possuir runtime temporal e receipt imutável

- Status: implementado, integrado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` até os outcomes reais.
- O aceite agora usa o snapshot histórico imutável para provar preservação de dado ausente; a chegada posterior de métricas não apagará GC-08. Previsões posteriores válidas também não invalidarão a prova temporal de GC-10.
- `hero_engine/phase6_prediction_runtime.py` agenda o horizonte exato na fila SQLite, coleta o outcome pela integração oficial, reutiliza checkpoint em retry, grava avaliação imutável e diferencia forecast avaliado de modelo retido por calibração insuficiente.
- O forecast calibrado usa mediana robusta como challenger e último outcome como baseline simples distinto. Somente uplift positivo fora da amostra permite alegar superioridade; `NOT_EVALUABLE_WITHHELD` prova rejeição disciplinada, nunca previsibilidade.
- O painel expõe status, receipt e próximo horizonte. Checkpoints concorrentes são ordenados cronologicamente: D1 próprio em `2026-09-05T18:45:51Z`, avaliação da previsão em `2026-09-05T19:12:01.035029Z`.
- A automação existente `HERO Engine — rotina diária` foi atualizada no lugar, sem duplicata, para verificar o prediction runtime, o aceite executável, os 13 gates e os dois horários exatos.
- Prova final: receipt `daily-maintenance-20260905T0159553275463Z`; `251/251` testes PASS em 152,293 s; `114/114` schemas válidos; compileall PASS; manifesto 554/3.080.086.312; tarefa `Running`, PID 9552, lock/console coincidentes, duplicata 73, stderr zero; fila saudável com dois jobs temporais pendentes; custo R$ 0,00.

## D-092 — Transição 6→7 é automática, imutável e sem dependência circular

- Status: implementado; Fase 6 permanece `IN_PROGRESS` e a Fase 7 ainda não iniciou.
- Correção de fase: GC-14 exige aplicação futura e segunda medição, capacidades pertencentes à Fase 7. Ele continua obrigatório no produto, mas deixa de bloquear a fase que precisa terminar antes que essas capacidades possam operar.
- Controlador: `phase6_transition.py` valida o aceite, recalcula ordem dos 22 checks, suficiência `FIXTURE/LIVE`, contagens, aprovados e blockers. Um rótulo `APPROVED` internamente inconsistente é bloqueado.
- Imutabilidade: quando todos os requisitos da Fase 6 passarem, os bytes exatos do aceite serão arquivados e presos por SHA-256; o receipt único `phase6-to-phase7-transition-receipt.json` autorizará apenas o início da Fase 7 sob D-047.
- Estado atual: `WAITING_FOR_PHASE6_GATE`, sem receipt de transição; blockers exatos GC-01, GC-11 e GC-19; custo R$ 0,00.
- Prova integral: receipt `daily-maintenance-20260905T0217562339914Z`; `255/255 PASS` em 144,712 s; `116/116` schemas; compileall PASS; manifesto 554/3.080.086.312; tarefa `Running`, PID 15952, lock/console coincidentes, duplicata 73, stderr zero, fila saudável e painel sem atenções.

## D-093 — Continuidade de energia e caminho canônico OAuth entram no recovery

- A auditoria ambiental encontrou suspensão em bateria após 600 s e hibernação após 10.800 s. `ensure_power_continuity.ps1` agora aplica e mede display, standby e hibernação em zero para AC/DC, grava receipt versionado e participa de `operational_ready`.
- O runner reaplica o controle no logon; a manutenção o reaplica antes de parar o Gestor. Falha de energia deixa o processo disponível para diagnóstico, mas o verificador recusa prontidão operacional.
- Ensaio real de falha: a primeira reconciliação do hash do runner registrou a tarefa com o fallback LocalAppData sem token; o bootstrap mostrou `token=False`, a tarefa saiu 1 e o recovery recusou o PID morto. A credencial válida permaneceu intacta no destino externo.
- Correção: installer, runner e manutenção resolvem o destino canônico pelo receipt do watcher OAuth e recusam caminho inexistente. A terceira manutenção provou o fluxo automático completo.
- Evidência final: `daily-maintenance-20260905T0238557983597Z`; `256/256 PASS` em 148,539 s; `117/117` schemas; compileall PASS; tarefa `Running`, PID 10316, energia `PASS`, lock/console coincidentes, duplicata 73, stderr zero, fila saudável e custo R$ 0,00.

## D-094 — Preflight local obrigatório antes de produzir o Vídeo 2

- Implementado: `hero_engine/production_capacity.py`, receipt imutável/`latest`, schema próprio, integração no executor, painel executivo e fallback do Gestor.
- Gate-base atual: FFmpeg, FFprobe, Kokoro, vozes, fonte, output e temporário `PASS`; 27.632.054.272 bytes livres e 22.263.345.152 bytes acima da reserva-base de 5 GiB.
- Gate final: imediatamente depois de D1 e da compilação do TakePlan, recalcular componentes por duração/takes/fontes. Somente `PASS` pode criar `EXECUTE_PHASE6_VIDEO2_MEDIA`.
- Se falhar: não enfileirar; registrar o déficit/executável/arquivo/span exato; recuperar apenas por alternativa local gratuita ou liberação segura de capacidade, sem apagar evidência e sem reduzir gates.
- Done when desta etapa: cenários suficiente, disco baixo, ferramenta ausente, span inválido e bloqueio anterior à fila testados; painel schema-validado; manutenção 261/261, 118 schemas, compileall; Gestor residente operacional.
- Próxima ação sequencial: manter D1 em `2026-09-05T18:45:51Z`; após o snapshot, selecionar uma única variável, compilar o caminho autorizado e executar o preflight de plano. Não antecipar postagem nem tratar ausência de dado como zero.

## D-095 — Biblioteca elegível precisa estar residente, íntegra e utilizável antes do D1

- Implementado: `hero_engine/phase6_asset_residency.py`, schema, testes, receipts imutáveis, integração em `scripts/daily.ps1`, painel executivo e automação diária existente.
- Escopo verdadeiro: o filtro reproduz a elegibilidade de produção completa, incluindo direitos comerciais, quality gate e exclusão por `metadata_publicity_risks`; por isso 29 ativos foram auditados, e os dois NASA/Artemis continuam fora do caminho automático.
- Prova por ativo: leitura e SHA-256 completos, ausência das flags Windows `OFFLINE/RECALL`, FFprobe/decodificação/duração, identidade do receipt de direitos e capacidade segura. Resultado real `PASS`, 29/29, 783.561.975 bytes e 1.499.877 ms de capacidade segura.
- Defesa em profundidade: a auditoria diária prepara a biblioteca; depois do D1, o preflight do TakePlan confronta origem, hash, span, duração e `asset_allocation.json` antes de criar o job. `CONTENT_HASH_MISMATCH` e qualquer divergência bloqueiam antes do render.
- Estado sequencial: a infraestrutura está comprovada, mas `production_capacity/latest.json` permanece honestamente `WAITING_PLAN`; o Vídeo 2 só ganha plano após o checkpoint próprio e o pré-registro de uma variável.
- Done when desta etapa: hash divergente bloqueado em teste, pool completo auditado ao vivo, painel schema-validado, manutenção `264/264 PASS`, `119/119` schemas e compileall PASS; tarefa `Running`, PID 15120, lock/console/energia/singleton/stderr aprovados.
- Próxima ação: executar automaticamente D1 em `2026-09-05T18:45:51Z`, avaliar o outcome da previsão em `2026-09-05T19:12:01.035029Z` e somente então compilar o ramo autorizado.

## D-096 — D1 não fica ocioso por atraso de retenção quando a distribuição já é conclusivamente pequena

- Implementado: diagnóstico 1.1 com `eligibility_scope`, origem e valor exatos da amostra; validação raw downstream; scope overlay 1.1; testes de fronteira e automação diária atualizada.
- Regra limitada: em >=24 h, contador oficial do vídeo exato abaixo de 30 views autoriza apenas `DISTRIBUTION_SAMPLE -> TOPIC_ANGLE`, confiança `LOW`. Hook, embalagem, corpo, voz, duração, estilo e gates permanecem bloqueados.
- Regra negativa: contador >=30, falha/ausência de fonte ou tentativa de inferir CTR, hook, retenção ou narrativa sem métricas completas produz espera/bloqueio, nunca aprovação.
- Cadeia: snapshot raw -> diagnosis 1.1 -> protocolo pré-registrado -> scope overlay 1.1 -> ordem. Scope e ordem revalidam valor, fonte, identidade, piso e variável antes de `READY_TO_COMPILE`.
- Incidente/recovery: a primeira manutenção recusou corretamente alterar o receipt imutável 1.0. O overlay foi versionado para 1.1, 1.0 preservado e a repetição integral passou; nenhum job, upload, dado ou custo foi criado/perdido.
- Done when: cenários 12/100 views, full metrics, identidade e pipeline exercitados; manutenção `daily-maintenance-20260905T0343374319511Z`, `267/267 PASS` em 158,116 s, `119/119` schemas, compileall PASS, PID 17732, painel sem atenções.
- Próxima ação: no D1, usar métricas criativas completas quando existirem; se atrasarem e o contador estiver abaixo de 30, iniciar automaticamente somente a produção do Vídeo 2 por novo ângulo e submetê-la a todos os gates posteriores.

## D-097 — Recolha curta e finita elimina a espera cega entre D1 e D3

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` até a evidência real do piloto.
- `phase6-owned-observation-policy-v1` preserva as janelas 0/24/72/168/336/720 h. Quando uma coleta formal a partir de D1 retorna `PARTIAL_DATA_LAG`, o próximo checkpoint passa a ser +120 minutos, não D3.
- O retry é limitado às 12 horas seguintes de cada janela formal, no máximo seis tentativas agendadas; depois disso o observador volta à próxima janela formal. Em D30, a mesma tolerância finita termina com `next_observation_at=null` e `terminal=true`.
- Cada snapshot 1.1 registra motivo, janela ativa, próxima janela/data formal, intervalo, tentativa, teto, deadline e estado terminal. Snapshots 1.0 permanecem válidos como histórico.
- Prova: 52/52 testes direcionados PASS; manutenção `daily-maintenance-20260905T0357151875938Z`, `270/270 PASS` em 148,846 s, `119/119` schemas, compileall PASS, manifesto 554/3.080.086.312; tarefa `Running`, PID 19108, lock/console coincidentes, duplicata 73, stderr zero, energia PASS e custo R$ 0,00.
- A automação `HERO Engine — rotina diária` foi atualizada no mesmo ID; nenhuma rotina duplicada foi criada.

## D-098 — Falha da fonte oficial tem recuperação rápida, teto e escalada observável

- Status: implementado e verificado em `2026-09-05`; nenhuma mudança pública foi executada.
- `FAILED` usa `SOURCE_FAILURE_RETRY`: +30 min por uma janela máxima de 6 h/12 slots a partir do checkpoint formal. Isso é separado do atraso `PARTIAL_DATA_LAG` de +120 min/12 h.
- Fonte recuperada retoma o fluxo. Teto vencido retorna ao calendário formal e emite `OWNED_METRICS_FAILED_RETRY_EXHAUSTED`; nenhuma decisão criativa ou publicação é liberada.
- Prova: 54/54 testes direcionados; manutenção `daily-maintenance-20260905T0407171966381Z`, `272/272 PASS` em 146,436 s; `119/119` schemas e compileall PASS; manifesto 554/3.080.086.312; PID 20192, `operational_ready=true`, zero atenções e R$ 0,00.

## D-099 — Checkpoint próprio passa por guard de cota imediatamente antes da API

- Status: implementado, fail-closed e verificado em `2026-09-05`.
- Operação `phase6_owned_metrics_checkpoint` reserva 1 unidade geral da Data API e exige 12 unidades remanescentes como piso preventivo para a sequência de recuperação. Upload continua com seu piso separado e vidIQ é `NOT_APPLICABLE` para esse checkpoint.
- O preflight é materializado somente quando a coleta está devida, evitando aprovar horas antes com dado vencido. `BLOCKED_UNKNOWN_CONSUMPTION` ou `BLOCKED_INSUFFICIENT_REMAINING` impedem Reporting, Data e Analytics antes da primeira chamada.
- Fallback: aguardar o reset gratuito do Pacífico e usar cache/evidência pública apenas para observação; nunca habilitar billing nem inferir métricas privadas.
- Prova: fixture confirma zero chamadas de API quando o guard falha; 41/41 testes dirigidos; manutenção `daily-maintenance-20260905T0419523321381Z`, `274/274 PASS` em 159,156 s; 119 schemas, compileall, manifesto 554/3.080.086.312; PID 18824 operacional e R$ 0,00.

## D-100 — Compilação criativa adaptativa substitui receitas fixas e notas artificiais

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` até a evidência viva D1.
- `phase6_creative_compiler.py` gera três conceitos concorrentes para cada cluster atualmente suportado, calcula sete componentes com pesos versionados, aplica checks críticos de hook, evidência visual, direitos, linguagem segura e integridade do tratamento e falha fechado quando nenhum conceito é elegível.
- Cada decisão é materializada em `creative_concept_decision.json`, schema-validada e presa ao compilador, sinais, ordem, tratamento e candidato selecionado. Score é prioridade interna, não chance de viralização.
- Integridade experimental: `FIRST_8_SECONDS_MECHANISM` preserva integralmente tese e seções do corpo; `BODY_PROGRESSIVE_DISCLOSURE` preserva os três hooks e apenas reordena o texto anterior; `TOPIC_ANGLE` cria conceito e narrativa novos sem copiar redação da referência.
- O Diretor Criativo passou a executar o seletor real de `FormatPack`. A fixture escolhe `fp-broll-cinematic-narration@1.1.0` com score `0,8082` e fit não uniforme, substituindo os antigos valores `1,0`; o gate exige score mínimo `0,75` e revalida a decisão independentemente.
- Done when: decisão com três candidatos, recomputação determinística, cobertura visual/direitos, linguagem promissória negativa, vazamento FIRST8/BODY e adulteração downstream estão cobertos; manutenção oficial `daily-maintenance-20260905T0445408771607Z`, `280/280 PASS` em `142,785 s`, `120/120` schemas, compileall, manifesto `554/3.080.086.312`; Gestor `Running`, PID `13560`, lock/console coincidentes, duplicata `73`, energia e prontidão aprovadas.
- Próxima ação: o Gestor executará D1 em `2026-09-05T18:45:51Z`; somente o diagnóstico e a variável pré-registrada poderão selecionar o conceito do Vídeo 2. Não antecipar uma segunda ação pública nem usar o score de fixture como resultado vivo.

## D-101 — Busca criativa ampla recebe diversidade, originalidade lexical e red-team recomputado

- Status: implementado, integrado e verificado em `2026-09-05`; substitui o contrato D-100 apenas para novas compilações, preservando a decisão histórica.
- `phase6-adaptive-creative-compiler-v2` avalia seis rotas por cluster suportado e exige ao menos três elegíveis. As rotas cobrem lente narrativa, hook, promessa/embalagem, estrutura de prova e payoff; IDs repetidos ou pool menor falham antes da seleção.
- O score 1.1 possui nove componentes: alinhamento ao mecanismo, hook, prova visual, novidade frente ao canal, distinção entre candidatos, originalidade frente aos títulos-fonte, profundidade da evidência, segurança e integridade da variável.
- Cada alternativa ganha red-team com concorrente mais próximo, similaridade, referência mais próxima, sobreposição lexical, componente mais fraco e desafios de entrega/prova/diferenciação. Cópia lexical, baixa distância ou menos de três rotas aprovadas bloqueia.
- O avaliador independente recalcula scores, elegibilidade, resumo da busca e vencedor; alterar nota, contagem ou status sem alterar a evidência reprova. FIRST8 e BODY mantêm os bloqueios causais de D-100.
- Prova da fixture TOPIC: seis de seis elegíveis; similaridade máxima `0,229730`; sobreposição máxima com título-fonte `0,090909`; vencedor `sw-name-test-choose` com `0,938817`. Esses valores provam o mecanismo, não resposta do público.
- Done when: pool insuficiente, cópia de título, ausência de direitos, linguagem promissória, adulteração de score/resumo e fluxo íntegro exercitados; 24/24 testes dirigidos; manutenção `daily-maintenance-20260905T0504515349131Z`, `283/283 PASS` em `163,237 s`, `120/120` schemas, compileall e manifesto `554/3.080.086.312`; Gestor reiniciado `Running`, PID `12432`, custo R$ 0,00.
- Próxima ação viva permanece o D1 exato. A ordem foi versionada para `phase6-treatment-order-1902a9c26c56d0cbe77c`; continua `WAITING_FOR_ELIGIBLE_BASELINE` e não criou job ou publicação.

## D-102 — Oportunidade de mercado é ranqueada pelo sinal composto, sem contar profundidade duas vezes

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` até os checkpoints vivos.
- Defeito corrigido: a seleção TOPIC ordenava primeiro `evidence_class` e somente depois `opportunity_score`. Como profundidade já compõe o score, uma hipótese `FULL` muito mais fraca podia ultrapassar uma `OPENING_ONLY` superior por dupla contagem.
- Política: `phase6-market-selection-score-first-v1` exige candidato elegível, estratégia suportada, `opportunity_score >= 0,65`, `score_observed_weight >= 0,95`, classe válida e idade `<=168 h`. A ordem é score decrescente; classe, contagem entre canais e ID só desempatarão.
- Identidade: versão da política, piso, ordem literal e candidato selecionado participam do `order_id`. Mudar a decisão material não reaproveita silenciosamente uma ordem antiga.
- Gate: `MARKET_EVIDENCE` reabre o snapshot e verifica score, peso observado, idade e candidato; score continua sendo prioridade de hipótese, não probabilidade de viralidade.
- Testes: 26/26 dirigidos cobrem ranking score-first, desempate por profundidade, rejeição abaixo do piso e os contratos criativos D-101. Manutenção oficial `daily-maintenance-20260905T0516293640558Z`: `285/285 PASS` em `145,626 s`, `120/120` schemas, compileall e manifesto `554/3.080.086.312`.
- Runtime: tarefa `Running`, PID `7200`, lock/console coincidentes, duplicata `73`, energia `PASS`, stderr zero e `operational_ready=true`. Ordem pré-D1 `phase6-treatment-order-2e04301977ef545fd517`, sem candidato, job, ação pública ou gasto.
- Próxima ação: coletar D1 automaticamente em `2026-09-05T18:45:51Z`; somente então a variável pré-registrada poderá selecionar o candidato que passar a política e todos os gates posteriores.

## D-103 — A ordem congela o conteúdo real da oportunidade, não apenas seu ID

- Status: implementado, integrado e verificado em `2026-09-05`; nenhuma ação pública adicional.
- Defeito corrigido: o `order_id` continha política e `candidate_id`, mas um arquivo de sinal alterado poderia manter o mesmo ID. A compilação buscava o candidato novamente por ID e poderia consumir conteúdo posterior ao ato de ordenar.
- Binding: a ordem registra SHA-256 dos bytes de `daily_signal_snapshot.json`, `snapshot_id`, `score_version` e hash canônico do objeto candidato. Todos entram na identidade da ordem junto da política e do ID.
- Revalidação: antes de escrever pré-produção, o compilador reabre exatamente o arquivo, exige hashes/identidade/versão, candidato único e refaz a política score-first. Qualquer desvio lança bloqueio antes de criar receipt.
- Consumo atômico: após a validação, a compilação usa os objetos em memória já verificados, sem uma segunda leitura por ID que pudesse introduzir troca de evidência.
- Teste adversarial: reduzir o score selecionado em `0,001`, preservando o ID, muda `order_id`; tentar compilar a ordem anterior retorna `PermissionError` e não cria `preproduction_receipt.json`.
- Prova oficial: 27/27 testes dirigidos; receipt `daily-maintenance-20260905T0527248074609Z`; `286/286 PASS` em `151,805 s`; `120/120` schemas/latest order, compileall e manifesto `554/3.080.086.312` aprovados.
- Runtime: `ACTIVE_OBSERVING`, tarefa `Running`, PID `19564`, lock/console iguais, duplicata `73`, stderr zero, energia/prontidão PASS, ordem `phase6-treatment-order-eddbd50675a4ded63370`; zero atenção, dead-letter, gasto ou nova publicação.

## D-104 — Embalagem deixa de ser trio fixo e passa por busca adaptativa verificável

- Status: implementado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS` e nenhuma mudança pública foi antecipada.
- Defeito corrigido: o ramo longo já possuía busca criativa, mas o tratamento `TITLE_THUMBNAIL_PROMISE` ainda materializava três pares fixos. O renderer mantinha um segundo mapa A/B/C independente, permitindo divergência entre a seleção e a imagem produzida.
- Busca: `phase6-adaptive-packaging-compiler-v1` avalia seis rotas distintas e conserva exatamente três finalistas elegíveis. Os dez componentes cobrem entrega pelo conteúdo congelado, alinhamento ao hook, ChannelDNA, complementaridade, novidade frente ao baseline, distinção interna, originalidade frente aos títulos-fonte, legibilidade, política e integridade de variável única.
- Cadeia: a decisão registra os hashes D-103, seis avaliações, red-team, source/render spec com hash e três IDs finalistas. O avaliador posterior relê a evidência de mercado e recompõe byte a byte decisão e bundle; o renderer consome o `render_spec` selecionado, não uma tabela paralela.
- Falha fechada: menos de três rotas seguras, promessa ausente no roteiro, excesso de repetição título-thumbnail, fonte alterada ou score/resumo adulterado bloqueiam antes de qualquer ação pública. Score de embalagem é ranking de fitness, nunca CTR ou probabilidade viral.
- Done when: schemas estritos para decisão e bundle; fluxo busca -> finalistas -> avaliação independente -> fonte exata -> thumbnail -> quality exercitado; adulteração autorreferente rejeitada mesmo com receipt atualizado; suíte dirigida `31/31 PASS` e `122/122` schemas válidos antes da manutenção integral.
- Prova oficial: receipt `daily-maintenance-20260905T0552076616926Z`; `288/288 PASS` em `152,108 s`; `122/122` schemas Draft 2020-12; compileall/manifesto `554/3.080.086.312` preservados. Gestor recuperado `Running`, PID `2988`, lock/console/singleton/energia/prontidão PASS. A automação existente foi atualizada no mesmo ID com D-104.

## D-106 — Receipt autoritativo de um ciclo integral do Gestor

- Status: implementado, integrado e comprovado ao vivo em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` até os outcomes reais.
- Cadeia obrigatória: `OWNED_OBSERVER -> PREDICTION_OUTCOME -> TREATMENT_COMPILER -> RELEASE_PREPARER -> PACKAGE_TREATMENT -> MEDIA -> QUALITY -> PUBLICATION -> LEARNING -> PHASE_TRANSITION -> EXECUTIVE_VIEW`.
- Cada estágio valida o schema exato, registra timestamp dentro dos limites do mesmo loop, SHA-256 dos bytes e hash da identidade semântica. Falta, erro, schema inválido ou timestamp externo produz `BLOCKED`.
- `PHASE_TRANSITION=BLOCKED` com `PHASE6_ACCEPTANCE_BLOCKED` e checks GC explícitos é espera legítima do gate e permanece visível, mas não falsifica uma pane do loop. Qualquer outro erro operacional continua bloqueante.
- `INITIAL` e `STATE_CHANGED` são arquivados; `HEARTBEAT_ONLY` substitui apenas `latest.json`. Isso impede que timestamps inflem o histórico de decisões.
- O painel executivo exibe o último receipt já concluído. A manutenção regenera essa visão derivada, depois da parada verificada e antes da regressão, para migrar contratos sem reescrever evidência imutável.
- Incidente recuperado: a primeira manutenção D-106 executou `292` testes, mas dois testes de aceite reprovaram porque o painel anterior ainda não possuía o campo novo. A rotina recusou o fechamento, recuperou o Gestor em `finally`, a ordem pré-teste foi corrigida e `22/22` testes dirigidos passaram.
- Prova oficial final: `daily-maintenance-20260905T0620292450294Z`; `292/292 PASS` em `160,316 s`; `123/123` schemas válidos; compileall PASS; manifesto `554/3.080.086.312`; tarefa `Running`, PID `18692`, lock/console coincidentes, duplicata `73`, stderr zero, energia PASS e `operational_ready=true`.
- Prova viva: receipt `phase6-control-cycle-d727c96e7be25f6eb5603045` obteve `11/11`, schemas e execução integral verdadeiros, zero blocker e `PASS_WAITING`. A iteração seguinte `phase6-control-cycle-c7a71b8d1738f0b56db9baef` foi `HEARTBEAT_ONLY`, não arquivada; o histórico permaneceu em dois estados materiais.
- Próxima ação: o mesmo loop executará D1 em `2026-09-05T18:45:51Z` e o outcome inicial em `2026-09-05T19:12:01.035029Z`; somente dados reais podem promover tratamento, produção e publicação.

## D-107 — A transição 6→7 exige reconciliação material anterior e imutável

- Status: implementado, integrado e verificado em `2026-09-05`; não promoveu a Fase 6 nem produziu efeito público.
- Defeito eliminado: antes, um aceite poderia tornar-se `APPROVED` e criar o receipt 6→7 na mesma iteração em que o aprendizado ou o próprio aceite mudou. O receipt D-106 só era fechado depois dessa decisão e, portanto, ainda não existia como prova reconciliada anterior.
- Barreira temporal: ao detectar aceite aprovado sem ciclo material reconciliado, `phase6_transition.py` retorna `WAITING_FOR_PHASE6_GATE` com `WAIT_FOR_RECONCILED_CONTROL_CYCLE`. O loop fecha e arquiva o estado material; somente uma iteração posterior pode promover.
- Binding: o receipt de transição passa a conter ciclo, caminho imutável do histórico, SHA-256 exato, assinatura substantiva e hashes das identidades `LEARNING` e `PHASE_TRANSITION`. O `transition_id` também depende do hash do ciclo.
- Replay fail-closed: reutilizar receipt exige reler o arquivo histórico, validar schema, bytes, ID, assinatura e identidades congeladas. Exclusão, troca ou adulteração retorna `ERROR`, nunca sucesso idempotente falso.
- Aceite integral: GC-07, GC-20 e GC-22 agora exigem o mesmo `control-cycle` saudável; GC-20 compara assinatura substantiva com o painel para tolerar somente heartbeats semanticamente idênticos.
- Prova: testes dirigidos de transição/ciclo/aceite/painel `20/20 PASS`; caso adversarial altera o histórico e o replay bloqueia. Manutenção oficial `daily-maintenance-20260905T0636010787762Z`: `293/293 PASS` em `163,95 s`; `123/123` schemas válidos; manifesto `554/3.080.086.312`; tarefa `Running`, PID `18320`, singleton/lock/console/energia/prontidão PASS e custo R$ 0,00.
- Estado vivo: aceite `phase6-acceptance-7c1a876c8cb21434ec5a`, 15 critérios PASS, 3 `WAITING_REAL_EVIDENCE`, zero FAIL/MISSING; bloqueadores próprios continuam somente GC-01, GC-11 e GC-19. Não existe receipt 6→7.
- Próxima ação: D1 e outcome inicial permanecem a sequência automática. Quando os três critérios forem satisfeitos por dados reais, haverá obrigatoriamente uma iteração adicional de reconciliação antes da Fase 7.

## D-108 — A meta de 30 dias ganha controle diário por trajetória oficial

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS` até o D1 real.
- Lacuna eliminada: o observador media somente o vídeo e o painel reutilizava o snapshot antigo de 265 inscritos. Assim, o desvio diário até 1.000 não era mensurável com contagem atual.
- Coleta 1.2: cada checkpoint devido reserva 2 unidades gerais, preserva piso preventivo 12 e chama o vídeo exato mais `channels.list(mine=true)`. Channel ID divergente, fonte ausente ou erro permanecem explícitos; nenhum total é inferido.
- Controlador: `phase6_goal_trajectory.py` calcula início público/deadline exatos, baseline, total atual, gap, ganho, dias, ganho linear esperado, delta, ritmos e razão de ritmo. Estados e pressão determinam prioridade operacional, nunca autorização de release ou gasto.
- Honestidade YPP: horas públicas válidas permanecem `null` até fonte oficial. `estimatedMinutesWatched` pode ser evidência criativa, mas não entra como progresso YPP.
- Integração: trajetória schema-validada é materializada em todo ciclo antes do painel; o painel prefere a contagem oficial atual. Histórico só cresce em `INITIAL/STATE_CHANGED`.
- Testes: 25/25 críticos PASS depois da correção do instante público. A primeira manutenção D-108 encontrou um fixture contaminado por `ATTENTION_REQUIRED` vivo; o recovery funcionou, a fixture foi isolada e a falha não foi ocultada.
- Prova oficial final: `daily-maintenance-20260905T0707027468681Z`; `299/299 PASS` em `165,614 s`; `124/124` schemas; sete instâncias vivas validadas; manifesto `554/3.080.086.312`; tarefa `Running`, PID `3524`, console `LISTENING`, energia contínua, stderr do Gestor zero e custo R$ 0,00.
- Estado real pré-D1: `WAITING_FOR_CURRENT_CHANNEL_METRICS`, baseline 265, gap inicial 735, total atual `null`, ação `COLLECT_D1_CHECKPOINT`, zero publicação/gasto. Não existe preflight antecipado; o snapshot histórico 1.0 será sucedido por 1.2 quando a janela abrir.
- Próxima ação: em `2026-09-05T18:45:51Z`, coletar D1 e o total atual no mesmo checkpoint; em `2026-09-05T19:12:01.035029Z`, avaliar o outcome inicial e executar somente o tratamento que a evidência e todos os gates liberarem.

## D-109 — A trajetória passa a ser prova obrigatória do ciclo integral

- Status: implementado, migrado e comprovado ao vivo em `2026-09-05`; sem efeito público ou custo.
- Lacuna eliminada: D-108 recalculava e exibia a trajetória, mas o receipt D-106 ainda provava 11 estágios e podia permanecer válido sem provar que a trajetória usada era daquela iteração.
- Contrato 1.1: `GOAL_TRAJECTORY` ocupa a posição entre `LEARNING` e `PHASE_TRANSITION`; o ciclo exige 12/12, `evaluated_at` dentro da janela, schema, hash dos bytes e identidade por trajectory/signature/custo.
- Compatibilidade: receipts 1.0/11 continuam schema-válidos apenas como histórico imutável. Aceite corrente GC-07/20/22 exige 1.1/12 e o painel nunca apresenta legado como capacidade atual.
- Transição: o receipt futuro 6→7 evoluiu para 1.1 e prende também `goal_trajectory_identity_hash`; drift posterior da meta/decisão obriga novo ciclo material reconciliado.
- Migração: o primeiro restart criou corretamente 12 estágios, mas revelou a circularidade painel legado -> GC-20 `FAIL` -> transição `BLOCKED` -> alerta do painel -> ciclo bloqueado. A passagem passou a omitir somente o resumo legado na primeira iteração e classificar falta de reconciliação como `MISSING_EVIDENCE`; não concede PASS.
- Recovery: a primeira tentativa de parada registrou uma corrida benigna do Windows, pois o PID terminou entre a leitura e `Stop-Process`; a tarefa ficou `Ready` e foi religada sem tocar outro PID. O erro de ciclo transitório foi preservado em `control-cycle-error-0e2045854137a39e.json` e retirado do alerta corrente após sucesso.
- Testes: bateria dirigida 28/28 PASS, incluindo ciclo velho omitido, drift da trajetória bloqueado, 12 estágios/freshness e arquivamento do erro sem apagamento.
- Prova oficial: `daily-maintenance-20260905T0732356315080Z`; `302/302 PASS` em `151,595 s`; `124/124` schemas; sete instâncias vivas e sete histories validados; manifesto `554/3.080.086.312`; tarefa `Running`, PID 21388, stderr zero e `operational_ready=true`.
- Estado vivo: ciclo `phase6-control-cycle-51100a70760dd5e1a15b2f5f`, schema 1.1, 12/12, `GOAL_TRAJECTORY=true`, `PASS_WAITING`, fresco, zero blocker; painel `ACTIVE_OBSERVING`, assinatura coincidente, zero atenção. Aceite voltou a 15 PASS/3 esperas e somente GC-01/11/19 bloqueiam.

## D-110 — Retry da trajetória é independente da validade criativa do checkpoint

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` aguardando o D1 real.
- Lacuna eliminada: uma falha isolada de `channels.list(mine=true)` podia deixar `subscriberCount=null` e, mesmo com vídeo/Analytics completos, agendar a próxima leitura apenas no D3.
- Contrato 1.3: o snapshot separa `status/decision_status` do vídeo de `goal_measurement`. Métricas criativas completas continuam `ELIGIBLE_FOR_COMPARISON`; a fonte de inscritos falha de forma explícita e recebe retry a cada 30 minutos, limitado a 6 horas/12 slots.
- Exaustão: durante retry não há alerta repetitivo. Ao esgotar, o painel emite `SUBSCRIBER_TRAJECTORY_SOURCE_RETRY_EXHAUSTED`; total permanece `null`. Inscritos deliberadamente ocultos geram `UNAVAILABLE_HIDDEN_SUBSCRIBER_COUNT` sem consumo inútil de cota.
- Done when: identidade divergente mantém o vídeo elegível, agenda +30 min e preserva nulo; teto de 6 h alerta; contador oculto não reconsulta; schema histórico 1.0–1.2 continua válido; runtime volta saudável.
- Prova: `26/26` testes dirigidos e compileall PASS; manutenção `daily-maintenance-20260905T0759095235067Z`, `306/306 PASS` em `162,589 s`, `124/124` schemas, manifesto `554/3.080.086.312`; tarefa `Running`, PID `20304`, ciclo 1.1 `12/12 PASS_WAITING`, zero blocker/alerta e custo R$ 0,00.

## D-111 — Controle diário real da meta sem contaminar o experimento criativo

- Status: implementado, integrado ao Gestor e comprovado no runtime em `2026-09-05`; Fase 6 continua `IN_PROGRESS` e nenhum efeito público foi produzido.
- Lacuna eliminada: a trajetória era recalculada em cada loop, mas a contagem oficial só seria renovada nas janelas criativas D1/D3/D7/D14/D30. D2, D4–D6 e demais dias exibiriam uma conta matematicamente nova sobre dado antigo.
- Observador diário: `phase6_channel_goal_observer.py` agenda D1–D30 pela publicação real. Em uma janela criativa, reutiliza o snapshot próprio imutável e consome zero unidades extras. Nos demais dias, chama uma única vez `channels.list(mine=true)` para o channel ID exato, depois de reservar 1 unidade geral e preservar piso 12.
- Isolamento experimental: a coleta diária só mede estatísticas do canal. Ela não chama o Analytics do vídeo, não materializa diagnóstico, não muda hipótese e não reabre o protocolo de variável única.
- Falha e retomada: erro/identidade/cota gera retry a cada 30 minutos, limitado a 6 horas/12 tentativas; exaustão vira alerta. Inscritos ocultos ficam nulos sem loop. Retomada após downtime seleciona o slot diário mais recente e fecha jobs vencidos como `SUPERSEDED_BY_CATCHUP`.
- Trajetória 1.1: escolhe a observação oficial schema-válida mais fresca entre o checkpoint do vídeo e o observador diário; registra tipo, ID, caminho, instante, estado do observador e próximo horário na assinatura substantiva e no painel.
- Done when: pré-D1 sem API; D1 reaproveitado com 0 unidade; D2 direto com 1; retry/exaustão; ocultação; identidade; catch-up; schema adversarial; origem mais fresca; painel/receipt integral e regressão aprovados.
- Prova oficial: `317/317 PASS` em `156,457 s`, `126/126` schemas e compileall PASS; manutenção `daily-maintenance-20260905T0834440018404Z`; manifesto 554/3.080.086.312. Gestor `Running`, PID 14972, lock/console/singleton/energia/prontidão PASS, stderr zero.
- Prova viva: observador `NOT_DUE`, job `job-7599266b58859a5078eafe3e` `PENDING` para D1 `2026-09-05T18:45:51Z`; fila 3 pendentes/0 dead-letter; trajetória 1.1 e painel 1.1 reconciliados; `control-cycle/latest.json` permanece 12/12 `PASS_WAITING`, zero blocker/atenção/custo. O ID do heartbeat muda a cada iteração e não é tratado como identidade estática.

## D-112 — O plano de 30 dias reflete a observação diária real

- Status: implementado e verificado em `2026-09-05`; somente o artefato local de acompanhamento foi alterado.
- Lacuna eliminada: o runtime D-111 já agendava D1–D30, mas a aba `30-Day Plan` ainda exibia D2, D4–D6 e outros dias como `No scheduled checkpoint/Uncommitted`.
- Correção: D1–D30 agora mostram `Official daily channel metrics`; D1/D3/D7/D14/D30 acumulam o checkpoint criativo correspondente. Todos os dias futuros ficam `Scheduled` para observação, enquanto a coluna `Release control` continua sem pré-comprometer publicação.
- Limite explícito: observação diária não é postagem. O plano mantém mídia em R$ 0,00, release subordinado aos gates e diagnóstico criativo restrito às janelas pré-registradas.
- Evidência: workbook reconstruído com `@oai/artifact-tool`; inspeção de `A1:H35` confirma 31 linhas D0–D30, nenhuma ocorrência de `No scheduled checkpoint`, D1 com baseline/pré-registro e D2 com observação sem rediagnóstico. Scan de erros encontrou zero correspondências; render integral das 14 abas e teste dirigido `2/2 PASS`. Export de 41.920 bytes, SHA-256 `06EB061810416762E3163212EB63ED4CEB45D6D22F897DBF3A8AB79B413E5CA8`.

## D-113 — Baseline histórico nunca aparece como contagem atual

- Status: implementado, integrado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS`, sem coleta antecipada, upload ou gasto.
- Defeito observado: `goal-trajectory` preserva corretamente `current_subscribers=null` antes do D1, mas `phase6_reporting.py` recai no snapshot histórico de 265 e o workbook apresenta `CURRENT SUBSCRIBERS=265`, `SUBSCRIBER GAP=735` e projeções derivadas como se fossem atuais.
- Preservado: baseline 265 observado em `2026-09-03T14:32:14Z`, trajetória D-108/D-111, slots D1–D30, gates, fila, OAuth, canário e todos os artefatos imutáveis.
- Fora de escopo: chamar YouTube antes de D1, atribuir horas YPP, mudar estratégia, publicar, alterar metadados ou consumir orçamento.
- Done when verificável:
  1. `executive-status` 1.2 separa baseline, contagem corrente, origem, captura e flag de observação; o alias legado nunca recebe baseline quando o atual é nulo;
  2. schema preserva 1.0/1.1 históricos e exige todos os campos novos em 1.2;
  3. fixture pré-D1 retorna corrente/gap/projeções `null` ou `UNAVAILABLE`, enquanto fixture com observação oficial calcula normalmente;
  4. workbook mostra baseline com data própria, atual e gap indisponíveis antes do D1 e não executa fórmula dependente de gap ausente;
  5. Dashboard e `30-Day Math` passam inspeção, scan de erros, render visual e testes de regressão;
  6. estado vivo permanece operacional, custo R$ 0,00 e zero efeito público.
- Implementação: `executive-status` 1.2 separa `baseline_*` de `current_*`, exige flag/origem/captura e conserva `observed_subscribers` apenas como alias corrente. O workbook só cria gap e cenários quando existe observação oficial atual; antes disso, exibe `UNAVAILABLE` e o baseline em bloco histórico datado.
- Testes: fixture pré-D1 mantém atual/alias/gap nulos; fixture com observação diária oficial preenche 290, origem e horário sem alterar baseline 265; cópia 1.1 sem campos novos continua schema-válida. Bateria dirigida 34/34 e teste final da planilha 2/2 PASS.
- Inspeção visual: Dashboard e `30-Day Math` renderizados; data corrigida de serial Excel para `2026-09-03 14:32 UTC`; scan encontrou zero erro de célula. Workbook final 42.069 bytes, SHA-256 `CE18BA8CD3235D9E396846BE7F63055F2ADAEA71E7509A3F043341CE7392DAFB`.
- Incidente e recuperação: a primeira manutenção provou `318/318 PASS`, mas o cold start do console local ultrapassou por milissegundos o limite de 5 s e o novo Gestor encerrou fail-closed. O budget foi elevado para 30 s, preservando validação de PID/lock/receipt; teste específico e reinicialização real comprovaram a correção.
- Prova oficial final: `daily-maintenance-20260905T0909256526361Z`; `319/319 PASS` em `163,591 s`; `126/126` schemas e compileall PASS; manifesto `554/3.080.086.312`; tarefa `Running`, PID `7956`, lock/console coincidentes, duplicata `73`, stderr zero, energia e `operational_ready=true`.
- Estado vivo: painel 1.2 `ACTIVE_OBSERVING`, baseline 265 em `2026-09-03T14:32:14Z`, atual/alias/gap `null`, fonte `UNAVAILABLE`, zero atenção; ciclo 12/12 `PASS_WAITING`, fila 3 PENDING/0 dead-letter, D1 automático em `2026-09-05T18:45:51Z`, custo e efeito público zero.
- Continuidade: a automação existente `HERO Engine — rotina diária` recebeu D-112/D-113 no mesmo ID, permanece `ACTIVE` e contém cada regra exatamente uma vez.

## D-114 — Ritmo da meta exige duas medições oficiais dentro da janela

- Status: implementado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS` e nenhuma chamada, publicação ou alteração pública foi antecipada.
- Defeito eliminado: o cálculo subtraía a referência de 265 observada `28,226944 h` antes da publicação e dividia essa variação pelo tempo desde a publicação. Assim, inscritos ganhos ou perdidos antes da largada poderiam distorcer o ritmo do D1.
- Contrato 1.2: `goal-trajectory` preserva a referência histórica e seu afastamento da largada, mede o gap atual a partir da fonte oficial mais fresca e cria uma âncora de ritmo exclusivamente dentro da janela. `linear_expected_gain_by_now`, delta, velocidade e razão permanecem `null` até uma segunda observação oficial distinta.
- Deduplicação: a observação diária `OWNED_METRICS_REUSE` herda a origem e o instante efetivo do snapshot próprio. Ela não pode fabricar uma segunda amostra apenas porque o wrapper foi escrito segundos depois.
- Painel 1.3: expõe afastamento do baseline, estado do ritmo, âncora, horário e número de observações comparáveis. `CURRENT_GAP_MEASURED_PACE_PENDING` separa “gap já conhecido” de “ritmo ainda não medido”.
- Done when verificável: D1 calcula gap e exigência diária restante, mas mantém razão nula; reuse D1 deixa contagem comparável em 1; D2 oficial eleva para 2 e calcula ritmo; versões anteriores dos schemas continuam aceitas como histórico; regressão e runtime passam.
- Prova: 33/33 testes dirigidos e fixture adicional de migração 1.1→1.3 PASS. A primeira manutenção bloqueou corretamente a leitura direta de um campo ausente no artefato vivo 1.1 e o recovery também recusou iniciar com painel inconsistente; o leitor ganhou migração compatível e teste dedicado. Manutenção final `daily-maintenance-20260905T0934146020327Z`: 321/321 PASS em 164,288 s, 126/126 schemas, compileall, manifesto 554/3.080.086.312; tarefa `Running`, PID 19968, lock/console/singleton/energia/prontidão PASS e stderr zero.
- Estado vivo: trajetória 1.2 `WAITING_FOR_CURRENT_CHANNEL_METRICS`, referência 265 com afastamento 28,226944 h, corrente/âncora/razão nulas, zero observação comparável pré-D1; painel 1.3 `ACTIVE_OBSERVING`, zero atenção; ciclo 12/12 `PASS_WAITING`, zero blocker.
- Continuidade: a automação existente `hero-engine-rotina-di-ria` foi atualizada no mesmo ID, permanece `ACTIVE` e contém a regra D-114 exatamente uma vez.

## D-115 — Nenhum JSON parcial pode virar ponto oficial da trajetória

- Status: implementado, recuperado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS` e a janela D1 não foi antecipada.
- Defeito eliminado: a enumeração de histórico selecionava campos úteis, mas não validava o contrato completo, filename/ID, confinamento do caminho ou igualdade entre `latest` e seu twin imutável. Um JSON parcial colocado na pasta poderia alterar a âncora ou o total corrente.
- Contrato fail-closed: snapshots próprios e observações diárias validam integralmente no schema; todo imutável usa filename igual ao ID; todo `latest` precisa ser byte-identical ao twin; caminhos precisam permanecer na pasta autoritativa. `OWNED_METRICS_REUSE` ainda reconcilia channel ID, status, contador, precisão, visibilidade, vídeos e views com o checkpoint exato.
- Preservação: o checkpoint inicial anterior à inclusão de `reach_reporting_api` permaneceu intocado, hash `E0DD8A148B78F8AA1337CA44BD52F5BA8F79C315D0B103823DD11F98EB6D1BC3`, e é excluído apenas por allowlist de caminho+hash+ID+versão porque não contém medição de inscritos. Nenhum outro histórico inválido recebe exceção.
- Recuperação: a primeira manutenção terminou 325/325, mas o processo residente ainda carregava o código anterior e o ciclo bloqueou `GOAL_TRAJECTORY`. A segunda repetição encontrou corretamente o receipt de manutenção defasado após esse bloqueio. O ciclo foi reconciliado, erros correntes foram arquivados byte a byte e a terceira manutenção fechou limpa.
- Done when verificável: adulteração parcial própria/diária, twin divergente, path escape e wrapper discordante bloqueiam; reuse válido continua deduplicado; legado exato é preservado e nunca vira ponto; recuperação remove somente o erro corrente depois de arquivá-lo.
- Prova: 45/45 testes dirigidos; manutenção `daily-maintenance-20260905T1003452840119Z`, 327/327 PASS em 145,037 s, manifesto 554/3.080.086.312. Runtime `Running`, PID 17852, lock/console coincidentes, prontidão `true`, stderr zero; ciclo `phase6-control-cycle-2c794c8108a9e37be19d455a` 12/12 `PASS_WAITING`, zero blocker/atenção; aceite somente GC-01/11/19.
- Estado executivo: trajetória `WAITING_FOR_CURRENT_CHANNEL_METRICS`, zero observação comparável antes do D1; workbook 42.065 bytes, SHA-256 `5072176C9BF09F72BA570E94EE09D8B61AA4D2ED3831612DFE0EB17A70FD2E93`, 14 previews e zero erro de célula. Custo R$ 0,00; sem upload, Ads ou alteração pública.

## D-116 — Manutenção só passa depois da prova viva pós-reinício

- Status: implementado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS`, aguardando exclusivamente evidência real dos checkpoints, sem nova publicação ou gasto.
- Defeito eliminado: a suíte integral era executada corretamente contra a snapshot estável com o Gestor parado, mas um teste vivo exigia `PASS_LIVE` nesse exato intervalo. Isso podia reprovar lógica válida pelo efeito transitório da própria manutenção; no sentido inverso, o código de saída não exigia um receipt único ligando a regressão ao novo processo e ao primeiro ciclo posterior.
- Separação rigorosa: testes unitários agora exigem que o avaliador reflita o estado disponível — `PASS_LIVE` somente quando runtime e ciclo realmente estão vivos; o encerramento operacional é mais forte e ocorre depois do restart.
- Pipeline pós-restart: recuperar ou iniciar a tarefa instalada, validar PID/lock/console/singleton/stderr/energia, aguardar até 120 s por ciclo 1.1 de 12/12 estágios iniciado após o `completed_at` da mesma manutenção, recomputar aceite/transição/painel e emitir `phase6-post-maintenance-verification`.
- Imutabilidade: o receipt traz os campos decisivos e arquiva bytes exatos de manutenção, autostart, ciclo, aceite e painel em `source-snapshots/<verification_id>/`; cada SHA-256 é recalculável e colisão divergente bloqueia.
- Fail-closed: ciclo antigo, estágio ausente, blocker técnico, runtime defasado, stderr, blocker inesperado, índice de aceite incoerente, painel ligado a outro ciclo, timestamp fora de ordem ou arquivo de erro corrente recusam a manutenção. Se a tarefa existir mas estiver parada, ela é recuperada e precisa produzir a mesma prova; tarefa ausente falha explicitamente.
- Done when verificável: testes determinísticos e adversariais passam; receipt/schema/history/snapshots validam; maintenance ID é o atual; ciclo começa depois do término da regressão; aceite aguarda somente GC-01/11/19; executivo está `ACTIVE_OBSERVING` no mesmo ciclo, sem atenção; runtime está `Running`; custo é zero.
- Prova oficial: `daily-maintenance-20260905T1025297907302Z`, 334/334 PASS em 169,420 s; 127/127 schemas e compileall PASS; manifesto 554 itens/3.080.086.312 bytes. Receipt `phase6-post-maintenance-213f09ce4d5210e2cfba5ae9` PASS com cinco snapshots/hashs válidos. Tarefa `Running`, PID 6776, lock `HELD`, console `LISTENING`, duplicata 73, stderr zero e prontidão true. Ciclo `phase6-control-cycle-c61632ca76f9c3fc71e2199f` 12/12 `PASS_WAITING`, zero blocker; painel `ACTIVE_OBSERVING`, zero atenção; custo R$ 0,00.
- Continuidade: a automação existente `hero-engine-rotina-di-ria` permanece `ACTIVE`, às 16h BRT, e contém a cláusula D-116 exatamente uma vez.
- Limite: essa prova fecha a integridade operacional da manutenção, não cria resposta de audiência nem garante YPP. D1 permanece em `2026-09-05T18:45:51Z` e continua sendo a próxima fonte externa válida.

## D-117 — Outcome de previsão subordinado ao custo zero e à cota comprovada

- Status: implementado, integrado ao Gestor e verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS`, sem antecipar o horizonte nem produzir nova ação pública.
- Defeito eliminado: o checkpoint próprio D1 já possuía preflight de custo/cota, mas o job posterior de outcome podia chamar `videos.list` sem passar pela mesma barreira. Isso deixava uma rota externa fora do contrato R$ 0,00 e sem prova de margem preventiva.
- Preflight exato: a operação `phase6_prediction_outcome_checkpoint` reserva 2 unidades gerais, exige piso preventivo 12, exclui vidIQ e gera `output/operations/zero-cost/phase6-prediction-outcome-preflight.json` mais cópia imutável em `phase6-prediction-outcome-preflights/<job_id>/preflight-<hash>.json`.
- Ordem transacional: path e SHA-256 entram no checkpoint SQLite antes da chamada externa. Cota ausente, desconhecida, bloqueada, custo diferente de zero ou margem insuficiente retorna `WAITING_FOR_RETRY`, mantém o job pendente por cinco minutos e executa zero chamada.
- Retomada segura: se o snapshot do vídeo já foi coletado e uma etapa posterior falha, o retry não recolhe. Ele reutiliza o snapshot apenas depois de revalidar diretório/filename/hash, schema completo do preflight, operação, `execution_permitted`, quota `PASS`, custo zero, reserva 2 e piso 12. Adulteração bloqueia fail-closed.
- Done when verificável: prova verde persiste no job concluído; cota desconhecida produz zero chamada; falha de avaliação reutiliza um único snapshot; prova adulterada impede reuse e recolha; Gestor recebe a observação de cota corrente.
- Prova dirigida: 14/14 em prediction+zero-cost e 29/29 com o Gestor Central; compilação dirigida PASS.
- Prova oficial: `daily-maintenance-20260905T1042233896565Z`, 338/338 PASS em 168,672 s; 127/127 schemas e compileall PASS; manifesto 554 itens/3.080.086.312 bytes. Verificação `phase6-post-maintenance-59e192d45a705806b8dfd5eb` PASS com 5/5 snapshots e hashes válidos. Tarefa `Running`, PID 12168, lock `HELD`, console `LISTENING`, duplicata 73, stderr zero e prontidão true. Ciclo pós-manutenção `phase6-control-cycle-6e356b9beb55c79b6ac8d024` 12/12 `PASS_WAITING`, zero blocker; aceite somente GC-01/11/19; painel `ACTIVE_OBSERVING`, zero atenção; custo R$ 0,00.
- Limite: o preflight do outcome só nasce quando o horizonte abrir. Antes disso, ausência do arquivo é correta e não autoriza coleta antecipada. A prova reduz risco operacional; não garante audiência, YPP ou monetização em 30 dias.

## D-118 — Aprendizado de tratamento sem rota externa ou retry invisível

- Status: implementado, integrado e provado em `2026-09-05`; nenhuma coleta futura foi antecipada e a Fase 6 continua `IN_PROGRESS`.
- Defeitos eliminados: o observador de aprendizado de Vídeo 2/embalagem chamava Reporting/Data/Analytics sem um preflight específico; e o bloqueio de cota do outcome D-117 informava cinco minutos no painel, mas ainda não movia o relógio transacional do job.
- Fila real: `TransactionalQueue.defer` altera um job não arrendado para `RETRY_WAIT`, grava `available_at` futuro, motivo e checkpoint sem incrementar `attempt_count`. Falha técnica depois do lease continua usando o retry exponencial normal.
- Guarda de aprendizado: `phase6_treatment_metrics_checkpoint` exige reserva 2/piso 12, custo zero e vidIQ ausente. A prova imutável entra no SQLite antes da primeira chamada; cota desconhecida ou insuficiente executa zero chamada e agenda exatamente +5 min.
- Retomada por etapa: registry do Reporting, reach e snapshot próprio são copiados para `external-read-checkpoints/<job_id>/` com hash. Se a avaliação falhar, o retry revalida e reutiliza; se apenas uma etapa terminou, somente a etapa ainda ausente pode executar sob preflight atual. Byte alterado bloqueia sem recolher.
- Done when verificável: fila realmente não reivindica antes de +5 min nem gasta tentativa; package e vídeo fazem zero chamada sem prova; fluxo verde prende preflight/snapshot; falha da avaliação retoma sem chamadas; adulterar snapshot bloqueia; Gestor injeta observação de cota.
- Prova dirigida: 34/34 fila/prediction/custo/aprendizado e 26/26 Gestor/manutenção/aceite; compileall PASS.
- Prova oficial: `daily-maintenance-20260905T1101010831568Z`, 344/344 PASS em 168,341 s; 127/127 schemas e compileall PASS; manifesto 554/3.080.086.312. Verificação `phase6-post-maintenance-d6809992fc2e235118d6effd` PASS, 5/5 snapshots/hashs. Tarefa `Running`, PID 1868, lock/console/singleton/energia/prontidão PASS, stderr zero; ciclo `phase6-control-cycle-437cbe1bcccc0d9e1ab88ebd` 12/12 `PASS_WAITING`, zero blocker; aceite somente GC-01/11/19; painel sem atenção.
- Limite: D-118 garante a disciplina técnica das coletas futuras e da retomada; não cria amostra, retenção, CTR, inscrito ou aprovação YPP.

## D-119 — D1 transacional por etapa, pronto para a janela real

- Status: implementado e provado em `2026-09-05`; checkpoint ainda não devido e nenhuma chamada antecipada.
- Lacuna fechada: o guard do D1 precedia Reporting/Data/Analytics, mas o receipt era apenas uma view mutável e retry posterior a Reporting ou métricas repetia etapas concluídas. O estado default `BLOCKED` ainda podia mascarar exceção técnica como bloqueio esperado.
- Execução: o job exato é localizado/criado primeiro. O preflight `phase6_owned_metrics_checkpoint` vira latest + histórico imutável e entra no SQLite antes das APIs. Falha de cota usa `defer` +5 min com `attempt_count` intacto.
- Journal por etapa: registry e snapshot são copiados para `external-read-checkpoints/<job_id>/`, cada um com SHA-256. Retry revalida prova e pula qualquer etapa já concluída. Antes de produzir previsão/diagnóstico/protocolo, o snapshot arquivado precisa ser byte-identical ao `latest` que o compilador lerá; drift bloqueia.
- Observabilidade: uma falha real depois do lease agora é `ERROR` e usa retry transacional; cota/pré-condição continua `BLOCKED` com causa explícita.
- Done when: bloqueio de cota deixa job `RETRY_WAIT` +5 min/0 tentativas/0 APIs; falha da inteligência preserva provas e retry faz zero chamadas externas; hashes permanecem no job concluído; D1 pré-horizonte permanece PENDING.
- Prova dirigida: 61/61 testes das rotas de Gestor, fila, prediction, aprendizado, cota, autostart e aceite; compileall PASS.
- Prova oficial: `daily-maintenance-20260905T1115050215909Z`, 345/345 PASS em 164,237 s; 127/127 schemas, compileall, manifesto 554/3.080.086.312. Receipt `phase6-post-maintenance-2cd02d38995aa00ddb3bd6eb` PASS, 5/5 snapshots/hashs; tarefa `Running`, PID 5832, lock/console/singleton/energia/prontidão PASS, stderr zero; ciclo `phase6-control-cycle-9c368458660cbae061698383` 12/12 `PASS_WAITING`; fila 3 PENDING/0 dead-letter; aceite GC-01/11/19 e painel sem atenção.
- Limite: a próxima melhoria válida depende do D1 oficial em `2026-09-05T18:45:51Z`. Executar antes destruiria a comparabilidade da janela; aguardar é parte do método, não inatividade.

## D-120 — Trajetória diária sem repetição de API nem consumo falso de tentativa

- Status: implementado e verificado em `2026-09-05`; Fase 6 continua `IN_PROGRESS`, aguardando a janela real D1.
- Defeito eliminado: o fallback diário de inscritos possuía guard antes da API, mas mantinha somente um `latest` mutável. Uma falha depois de `channels.list` podia repetir a leitura; cota não comprovada entrava no retry de fonte e consumia a janela de tentativas.
- Contrato: cada job materializa preflight imutável e hash-bound. A resposta direta vira `phase6_channel_goal_external_read`, isolada pelo slot nominal e ligada à operação, canal, job, horário, métricas e prova de cota exatos.
- Retomada: crash ou falha posterior descobre/revalida o artefato por slot, prende o SHA-256 ao novo job de recuperação e produz a observação sem segunda chamada. Arquivo divergente, múltiplo, fora do diretório, com schema/ID/hash/preflight incompatível bloqueia fail-closed.
- Espera: `defer_claimed` libera apenas o lease pertencente ao worker, reverte atomicamente o incremento pré-efeito e agenda +5 min. O runtime usa `QUOTA_WAIT`; o job fica `RETRY_WAIT` com `attempt_count=0` e nenhuma chamada.
- Done when verificável: zero chamada com quota desconhecida; horário real +5 min; falha pós-leitura retoma com uma única chamada total; adulteração não causa recolha; trajetória/relatório/ciclo continuam compatíveis; suíte, schemas e prova pós-restart passam.
- Prova: 18/18 testes dirigidos e 349/349 na regressão integral em 142,924 s; 128/128 schemas e compileall PASS. Manutenção `daily-maintenance-20260905T1136554953693Z`, verificação `phase6-post-maintenance-6fbc800f60c9e2e9fcd547e3`, manifesto 554/3.080.086.312, runtime PID 9756, ciclo `phase6-control-cycle-62c07d762e648a18fcc2090d` 12/12 `PASS_WAITING`, zero blocker/atenção/erro corrente.
- Limite: D-120 reduz erro operacional controlável; não cria inscritos, retenção, horas públicas válidas nem aprovação do YPP.

## D-121 — Experimento ativo imutável, aceite causal e cota por dia real

- Status: implementado, integrado e oficialmente verificado em `2026-09-05`; Fase 6 permanece `IN_PROGRESS` até os fatos reais de GC-01/11/19.
- Defeito 1: após o primeiro protocolo real `PREREGISTERED`, um checkpoint posterior podia substituir `experiments/latest.json` e trocar silenciosamente baseline, variável ou métrica antes da avaliação do tratamento.
- Correção 1: o primeiro protocolo elegível passa a ser congelado em `experiments/active.json`. Enquanto existir, cada materialização valida o contrato e restaura `latest.json` com bytes idênticos ao ativo; nenhuma nova leitura pode redefinir o experimento em curso.
- Defeito 2: GC-01 aceitava um runtime superficialmente `EVALUATED`; GC-19 podia encontrar uma avaliação de previsão válida, porém alheia à previsão vigente. Assim, artefatos antigos ou desconectados poderiam fechar o gate errado.
- Correção 2: o aceite agora exige a cadeia exata `protocolo ativo -> baseline -> publicação autorizada -> snapshot do tratamento -> avaliação -> runtime`, com channel/video/experiment/metric/IDs, paths confinados, schemas e ordem temporal reconciliados. GC-19 exige exatamente a previsão vigente, o job, o snapshot no horizonte e sua avaliação; uma avaliação não relacionada não conta.
- Defeito 3: a observação de consumo geral vinha do console oficial, mas podia pertencer ao dia anterior da cota YouTube no horário do Pacífico. O fallback de package ainda emitia um valor rejeitado pelo próprio schema.
- Correção 3: a nova contabilidade calcula o dia de cota em `America/Los_Angeles`, zera apenas a base expirada, conta uploads confirmados do dia e adiciona reserva conservadora de 2.000 unidades para uso não rastreado. O artefato registra base, ajuste, uso efetivo, limites, billing falso e fallback gratuito. O schema aceita separadamente deferimento de publicação, package e observação.
- Done when verificável: primeiro protocolo não deriva após nova evidência; `active/latest` são byte-idênticos; runtime ou avaliação avulsos não aprovam GC-01/GC-19; uso defasado gera base zero + reserva 2.000; uso do dia é limitado a 10.000 e bloqueia antes de estourar; todos os fallbacks validam; regressão, schemas, compileall, restart e ciclo 12/12 passam sem chamada antecipada ou efeito público.
- Prova dirigida: 69/69 testes críticos PASS em 19,253 s, incluindo cenários adversariais; custo e efeito público R$ 0,00/nenhum.
- Prova oficial: `daily-maintenance-20260905T1213092631813Z`, 356/356 PASS em 167,554 s; 128/128 schemas e compileall PASS; manifesto 554/3.080.086.312. Receipt pós-restart `phase6-post-maintenance-5b0ea6528029e67fd4243945`, PID 4408, ciclo `phase6-control-cycle-047c8fa7507f244b5082ae12` 12/12, fila 3 PENDING e zero blocker/atenção/erro corrente/custo.
- Continuidade: a automação existente `hero-engine-rotina-di-ria` foi atualizada no mesmo ID, permanece `ACTIVE` e contém a regra D-121 exatamente uma vez. A ausência de `experiments/active.json` antes do D1 foi verificada como estado correto.
- Limite: o endurecimento impede deriva, falsa aceitação e risco de cota; a conclusão causal continua dependendo do D1, do tratamento real e das medições subsequentes. A meta de 30 dias governa a operação, mas não autoriza fabricar resposta da audiência ou decisão do YPP.

## D-122 — Diagnóstico imutável preso à ordem e revalidado no consumo

- Defeito: D-121 congelava o protocolo, mas ele ainda apontava para `diagnoses/latest.json`; uma observação posterior podia mudar o diagnóstico consumido sem mudar o protocolo ativo.
- Contrato: protocolos novos usam schema 1.1 e apontam para `diagnoses/<diagnosis_id>.json`. A ordem registra paths, hashes e `bound_immutable` de protocolo e diagnóstico; READY exige `active.json`, twin `latest` byte-idêntico e diagnóstico nominal schema-válido.
- Consumo: imediatamente antes da compilação, revalidar confinamento, filename/ID, SHA-256, schemas, canal, baseline, variável, métrica, alvo e pré-registro. Drift bloqueia antes do primeiro artefato.
- Compatibilidade: schema 1.0 permanece apenas para história; não pode originar nova produção. `diagnoses/latest.json` continua uma visão observável e pode evoluir sem reescrever o experimento ativo.
- Done when: nova latest não rebinda a ordem; adulteração do diagnóstico preso bloqueia; divergência active/latest bloqueia; compilação verde consome a cadeia exata.
- Prova dirigida atual: 40/40 testes PASS em 17,680 s, incluindo os três adversariais acima.
- Migração comprovada: o overlay mudou para 1.2 e o protocolo de espera inclui a versão do schema no filename. Os artefatos 1.0/1.1 foram preservados; as duas colisões detectadas pela manutenção falharam fechado e ganharam testes de regressão.
- Prova oficial: `daily-maintenance-20260905T1300374758556Z`, 363/363 PASS em 218,863 s, 129/129 schemas e compileall PASS; prova pós-restart `phase6-post-maintenance-4c3b3614f5716a14f37d4d9a`, PID 18828, ciclo `phase6-control-cycle-782108c2aa7ec47bac0609f0` 12/12, zero blocker/atenção/erro/custo.

## D-123 — Governança de capacidade Codex sem downgrade de qualidade

- Política: usar o melhor modelo Codex suportado e esforço `ultra`; nunca reduzir qualidade para economizar. Migração futura exige disponibilidade real, teste de compatibilidade/regressão, registro e rollback.
- Economia: preflight, batching, leitura única, inputs hash-bound, reuse de checkpoints, testes dirigidos antes da regressão e execução local para tarefas determinísticas. Isso elimina retrabalho sem reduzir rigor.
- Faixas: GREEN >=50%; AMBER 25–49%; RED 10–24%; CRITICAL_RESERVE <10%. Nas duas últimas, limitar volume ao caminho crítico ou aguardar reset; manter modelo/esforço e o Gestor local ativos.
- Custo: compra de crédito e auto top-up proibidos; resets gratuitos não são consumidos automaticamente. O limite é da conta inteira, portanto “nunca acabar” é objetivo de preservação, não garantia fabricável.
- Observação vigente pós-manutenção: 37% usados/63% restantes, reset principal `2026-09-10T09:56:07Z`, três resets gratuitos preservados, estado GREEN, zero compra e zero cobrança. A rodada completa moveu o medidor account-wide em 1 ponto percentual; não é uma atribuição exata por tarefa.
- Done when: decisão determinística valida no schema, histórico é imutável, todas as faixas são testadas, downgrade/compra são rejeitados e a automação consulta a telemetria antes de trabalho pesado.
- Prova dirigida atual: 3/3 testes próprios; 40/40 no conjunto D-122/D-123/Fase 6.
- Prova operacional: decisão vigente `codex-usage-4a501a12f7789871` schema-válida e twin histórico byte-idêntico; automação `hero-engine-rotina-di-ria` ACTIVE com D-122/D-123 exatamente uma vez. A manutenção integral acima valida a integração sem consumo de reset ou compra.

## D-124 — Timing de voz executável antes da fila

- Escopo: somente a produção `TOPIC_ANGLE` do Vídeo 2, sem alterar a variável pré-registrada, os direitos, o custo, o bloqueio de publicação ou os gates posteriores.
- Planejamento: cada take de corpo exige margem `ceil(max(400 ms, 10% da duração estimada) / 100 ms) * 100 ms`; o perfil é `am-onyx-kokoro-planning-v2`. A estimativa é triagem determinística, não evidência de áudio medido.
- Prova executável: sintetizar com o Kokoro local exato todos os takes em staging atômico, medir WAV por frames e rejeitar qualquer slot excedido antes de enqueue/claim. Não truncar nem acelerar a locução para obter PASS.
- Done when: manifestos prendem modelo, voz, velocidade, TakePlan, script, timing contract, WAVs e hashes; falha deixa zero conjunto parcial consumível; replay divergente bloqueia.

## D-125 — Supersessão pré-efeito restrita e evidência viva

- Classe permitida: `PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION`, exclusivamente para jobs antigo/novo em `PENDING` ou `RETRY_WAIT`, sem lease e com checkpoint `{}`. Semântica, canal, protocolo, variável, candidato, autoridade de direitos, custo R$ 0,00 e `publication_authorized=false` permanecem iguais e hash-bound; histórico e inputs anteriores não são apagados.
- Receipt vivo: `phase6-media-supersession-511dbf21c5bb4c4cf3b1f455` tornou `job-faae3c79b330903828e90cc7` não reivindicável e vinculou o job vigente `job-c516db5685acbbb423199bc1` a `phase6-production-inputs-79b3e183dd5df410fb3a`.
- Voz viva: `voice-phase6-acec0efc9c0365039525` está `COMPLETE`, com 90/90 takes e `hook_timing_gate=PASS`; `publication_approved=false` permanece preservado.
- Evidência atual: suíte focal `83/83 PASS`. A manutenção integral corrente ainda não produziu PASS; portanto a Fase 6 permanece `IN_PROGRESS`, sem promoção de fase nem alegação de prontidão final.

## D-126 — Quality recompõe integralmente o contrato de voz 1.2

- Defeito: `phase6_quality` ainda exigia o manifesto de voz 1.1, enquanto o produtor vigente já emite 1.2. A incompatibilidade de versão bloquearia um artefato válido sem reaplicar a prova substantiva mais forte.
- Correção focal: `_verify_voice_for_quality` exige schema 1.2 e chama `_verify_voice_manifest_contract` para recompor TakePlan, roteiro, ordem/copy, slots, velocidades, modelo, vozes, eSpeak, WAVs medidos e identidade. A alteração ficou restrita a `hero_engine/phase6_quality.py` e seus testes; compiler, produção e input `phase6-production-inputs-79b3e183dd5df410fb3a` permaneceram byte-idênticos.
- Prova: quality `8/8 PASS`; media+quality `18/18 PASS` em 132,674 s. Contraprova viva direta do helper passou 90/90 takes contra `voice-phase6-acec0efc9c0365039525`; manifesto SHA-256 `d748e4c7e1822f7e86f504f7563d4354114d859597506709e2f01f9b5e56a94e`; código quality SHA-256 `69da211ec1b4d5757ddc84035275902cfa544e8037ae8e72ea7d39d5dcb8acfa`.
- Deployment seguro: o PID 18288 ainda carregava o código anterior no momento da verificação e não deve ser reiniciado antes do término da mídia. O job `job-c516db5685acbbb423199bc1` foi retomado somente por `TransactionalQueue.defer`, de `2026-09-06T01:00:00Z` para `2026-09-06T00:45:40.619277Z`, motivo `PRE_EFFECT_DEPLOYMENT_VERIFIED_RESUME_NOW`, tentativa 0, checkpoint `{}` e exatamente um job de mídia executável. O simples reagendamento não cria nova regra.
- Pendente: rebind do cache de voz ao receipt de capacidade candidato; o custo observado de 363 s decorre de retry pré-efeito, não de loop após `SUCCEEDED`. A correção ainda não foi implementada.
- Limite: não existe PASS de vídeo QA, publicação ou manutenção integral decorrente de D-126; a Fase 6 continua `IN_PROGRESS`.

## D-127 — Liveness Windows read-only, fail-closed e deployment após a mídia

- Defeito observado: em Windows, `os.kill(pid, 0)` retornou `WinError 87` para o PID 18288, embora `Get-Process` comprovasse que o mesmo processo Python estava vivo. Portanto, essa chamada não pode ser usada como sonda neutra de existência no Windows.
- Implementação: `maintenance_protocol.py` centraliza a consulta Windows em `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)`, `GetExitCodeProcess` e `CloseHandle`. Só uma inexistência conclusiva ou um exit code diferente de `STILL_ACTIVE` permite classificar o PID como morto; acesso negado, consulta indisponível e erro ao fechar o handle geram `ProcessLivenessProbeError`.
- Fail-closed: `capture_operational_boundary` distingue `MANAGER_PROCESS_NOT_ALIVE` de `MANAGER_PROCESS_LIVENESS_PROBE_UNAVAILABLE`; a migração usa a mesma primitiva e recusa avançar quando a consulta é inconclusiva. No POSIX, `ESRCH=false`, `EPERM=true` e os demais erros permanecem indisponibilidade, nunca ausência inventada.
- Limite de identidade: a sonda responde somente à vida do PID. PID exato, lock, instante de início, launcher/processo real e cadeia da tarefa continuam obrigatórios nas barreiras externas e não foram relaxados.
- Testes e contraprova: 69/69 PASS nos quatro módulos afetados, incluindo vivo, morto, PID ausente, acesso negado, falha de consulta/fechamento, dispatch Windows sem `os.kill`, POSIX, migração fail-closed e distinção de blocker. A contraprova read-only confirmou PID 18288 vivo, início `2026-09-06T00:25:01.5637671Z`, tanto por `Get-Process` quanto pela nova primitiva, sem sinal nem mutação do processo.
- Fontes oficiais: [Microsoft OpenProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocess), [Microsoft GetExitCodeProcess](https://learn.microsoft.com/pt-br/windows/win32/api/processthreadsapi/nf-processthreadsapi-getexitcodeprocess) e [Python `os.kill`](https://docs.python.org/3/library/os.html#os.kill).
- Arquivos da implementação: `hero_engine/maintenance_protocol.py` — SHA-256 `ee8c02742582bc4b9030f1eef325a902986c1495be85125e446fa7cf5fb14523`; `tests/test_maintenance_process_liveness.py` — SHA-256 `71d4957087a9465491644388121c3730dc73b5b3e28978bfac3803e495803320`. Governança adicionada em `AGENTS.md`, `PLANS.md`, `docs/DECISIONS.md` e `docs/STATE.md`.
- Deployment: **pendente** até a mídia em curso terminar e existir uma janela segura de restart. A geração residente continua corretamente anunciando o hash anterior `74c440d7129c06b3f0bf5513f265ce78d24448514771f17866bf0ba3db2d90a4`; ela não pode alegar que carregou o novo código.
- Done when verificável: após o término da mídia, executar restart seguro, confirmar que a capacidade residente anuncia o novo hash, repetir prova de tarefa/PID/lock/início/console/singleton/energia e somente então realizar a manutenção integral e a prova pós-restart. **Nenhuma manutenção integral recebeu PASS nesta rodada.**

## D-128 — Prioridade normal do Gestor sem reinício da cadeia

- Configuração persistente: `scripts/install_phase5_manager_autostart.ps1:51-52` cria os settings com `New-ScheduledTaskSettingsSet -Priority 5`; a tarefa instalada `HeroEngine-Phase5-CentralManager` expõe `Priority=5`.
- Estado vivo observado: o ajuste do processo ocorreu em `2026-09-06T00:57:26Z`; o PID 18288 reporta `PriorityClass=Normal`. Os settings da tarefa foram persistidos depois, sem restart e preservando a mesma cadeia.
- Semântica oficial: [Microsoft `TaskSettings.Priority`](https://learn.microsoft.com/en-us/windows/win32/taskschd/tasksettings-priority) mapeia `5` para `NORMAL_PRIORITY_CLASS`; o default `7` corresponde a `BELOW_NORMAL_PRIORITY_CLASS`.
- Verificação limitada: o parser do installer foi observado em `PASS`. A comparação XML integral não passou, porque o XML anterior omitia o valor default; ela não é evidência de aprovação desta decisão.
- Limite factual: prioridade normal não prova aceleração causal. Nenhum `PASS` de manutenção integral, QA, deployment ou publicação decorre de D-128; a Fase 6 continua `IN_PROGRESS`.

## D-129 — Correção visual comprovada e retomada sem apagar o render anterior

- Implementado/testado: tratamento de texto nulo e inválido, receita `phase6-standard-v2`, recusa de cache v1; 4/4 testes novos e 1/1 regressão focal PASS.
- Prova limitada em mídia real: um frame do take-002 foi reconstruído em diretório diagnóstico isolado após validar a capacidade e a fonte; o texto `None` desapareceu. Ver `docs/PHASE6_RENDER_VISUAL_INCIDENT.md` e `scripts/verify_phase6_null_overlay_fix.py`.
- Próximo trabalho autorizado: concluir a auditoria independente de texto nos pixels; reconciliar a contradição de framework entre Bible, TakePlan e renderer sem mudar silenciosamente o experimento; criar a remediação pós-efeito local com rastreabilidade, sem reabrir o job concluído; carregar as correções somente na fronteira segura; executar novo render e QA integral.
- Done when: a reconstrução preserva receipt/bytes anteriores, usa receita nova, não reutiliza cache defeituoso, apresenta texto fiel ao plano e passa gates de hook/semântica/legibilidade, regressão integral e prova pós-restart. Frame isolado ou testes focais não satisfazem este aceite.
- Bloqueios de implementação ainda abertos: não existe cancelamento cooperativo na instância residente; o loop serial posterga a coleta de métricas enquanto renderiza; a reserva de mídia começa com relógio anterior à síntese e não se renova. Esses pontos não autorizam forçar estado da fila ou declarar a fase pronta.

## D-197 — ciclo de mídia sob demanda

- Entrada: catálogo remoto com metadados, direitos e decisão de seleção.
- Transição obrigatória: take aprovado -> aquisição única do ativo exato ->
  validação/uso -> publicação confirmada -> eventual liberação somente com
  prova de ausência de referências.
- Proibido: download em lote na mineração, retenção por conveniência ou
  exclusão por idade/tamanho. Esta mudança aguarda a próxima prova integral;
  não autoriza aplicação operacional por si só.
