param(
    [Parameter(ValueFromRemainingArguments=$true)]
    [string[]]$HeroArgs
)

$projectRoot = Split-Path -Parent $PSScriptRoot
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$bundledPython = 'C:\Users\mathe\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$pythonExe = if (Test-Path -LiteralPath $venvPython) { $venvPython } else { $bundledPython }

Push-Location $projectRoot
try {
    & $pythonExe -m hero_engine.cli @HeroArgs
    exit $LASTEXITCODE
}
finally {
    Pop-Location
}

