[CmdletBinding()]
param(
    [ValidateRange(10, 3600)]
    [int]$IntervalSeconds = 60,
    [string]$PackageRelative,
    [string]$CurrentBindings,
    [string]$ExpectedBindingsHash
)

$localData = $env:LOCALAPPDATA
$bootstrapLog = $env:HERO_MANAGER_BOOTSTRAP_LOG
if ([string]::IsNullOrWhiteSpace($bootstrapLog)) {
    $bootstrapLog = Join-Path $localData 'HeroEngine\manager-task-bootstrap.log'
}
$bootstrapDir = Split-Path -Parent $bootstrapLog
New-Item -ItemType Directory -Path $bootstrapDir -Force | Out-Null
try {
    $ErrorActionPreference = 'Stop'
    $projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
    & (Join-Path $PSScriptRoot 'assert_orchestration_root.ps1') | Out-Null
    if (-not $?) { throw 'ORCHESTRATION_ROOT_ASSERT_FAILED' }
    $physicalRoot = 'C:\Users\mathe\OneDrive\READET~1\MODELA~1'
    # The installed runner forwards the same explicit selection accepted by
    # the Python CLI. Partial selections fail before power/start/credentials.
    $managerArguments = @('-B', '-m', 'hero_engine.central_manager_phase5', '--loop', '--interval', [string]$IntervalSeconds)
    $selection = @($PackageRelative, $CurrentBindings, $ExpectedBindingsHash)
    $selectedCount = @($selection | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }).Count
    if ($selectedCount -ne 0) {
        if ($selectedCount -ne 3 -or $ExpectedBindingsHash -notmatch '^sha256:[0-9a-f]{64}$') {
            throw 'AUDIO_SELECTION_REQUIRES_PACKAGE_BINDINGS_AND_EXTERNAL_HASH'
        }
        # Windows Start-Process joins ArgumentList. Quote paths as actual argv,
        # without a shell, so spaces never split the selected package/binding.
        foreach ($value in @($PackageRelative, $CurrentBindings)) {
            if ($value.Contains('"') -or $value.Contains([char]0) -or $value.EndsWith('\')) {
                throw 'AUDIO_SELECTION_PATH_NOT_LITERAL'
            }
        }
        $managerArguments += @('--package-relative', ('"' + $PackageRelative + '"'),
            '--current-bindings', ('"' + $CurrentBindings + '"'), '--expected-bindings-hash', $ExpectedBindingsHash)
    }
    $pythonExe = Join-Path $projectRoot '.venv\Scripts\python.exe'
    $runtimeDir = Join-Path $projectRoot 'output\runtime\gestor-central'
    $tokenPath = $env:HERO_YT_TOKEN_PATH
    if ([string]::IsNullOrWhiteSpace($tokenPath)) {
        $watcherReceipt = Join-Path $runtimeDir 'oauth-reconsent-watcher.json'
        if (Test-Path -LiteralPath $watcherReceipt -PathType Leaf) {
            try {
                $tokenPath = [string](Get-Content -LiteralPath $watcherReceipt -Raw | ConvertFrom-Json).destination_path
            }
            catch {
                $tokenPath = ''
            }
        }
        if ([string]::IsNullOrWhiteSpace($tokenPath)) {
            $tokenPath = Join-Path $localData 'HeroEngine\secrets\youtube-heroverse-token.json'
        }
    }
    $reconsentSourcePath = $env:HERO_YT_RECONSENT_SOURCE_PATH
    if ([string]::IsNullOrWhiteSpace($reconsentSourcePath)) {
        $reconsentSourcePath = Join-Path $localData 'HeroEngine\secrets\youtube-heroverse-token.json'
    }
    $stdoutPath = Join-Path $runtimeDir 'manager.stdout.log'
    $stderrPath = Join-Path $runtimeDir 'manager.stderr.log'
    Add-Content -LiteralPath $bootstrapLog -Value ("RUNNER {0} identity={1} python={2} token={3} token_path={4} reconsent_source={5}" -f [DateTime]::UtcNow.ToString('o'), [System.Security.Principal.WindowsIdentity]::GetCurrent().Name, (Test-Path -LiteralPath $pythonExe -PathType Leaf), (Test-Path -LiteralPath $tokenPath -PathType Leaf), $tokenPath, $reconsentSourcePath)

    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) {
        throw "Python environment is unavailable: $pythonExe"
    }
    if (-not (Test-Path -LiteralPath $tokenPath -PathType Leaf)) {
        try {
            Get-Item -LiteralPath $tokenPath -Force -ErrorAction Stop | Out-Null
        }
        catch {
            Add-Content -LiteralPath $bootstrapLog -Value ("TOKEN_ACCESS_ERROR {0} {1}: {2}" -f [DateTime]::UtcNow.ToString('o'), $_.Exception.GetType().Name, $_.Exception.Message)
        }
        throw 'YouTube token file is unavailable outside the workspace.'
    }

    New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null
    $env:HERO_YT_TOKEN_PATH = $tokenPath
    $env:HERO_YT_RECONSENT_SOURCE_PATH = $reconsentSourcePath

    try {
        & (Join-Path $PSScriptRoot 'ensure_power_continuity.ps1') | Out-Null
        Add-Content -LiteralPath $bootstrapLog -Value ("POWER_CONTINUITY {0} status=PASS" -f [DateTime]::UtcNow.ToString('o'))
    }
    catch {
        # Preserve the manager so diagnostics and alerts remain available, but
        # the independent autostart verifier will mark operational_ready=false
        # until the power-continuity receipt passes.
        Add-Content -LiteralPath $bootstrapLog -Value ("POWER_CONTINUITY_ERROR {0} {1}: {2}" -f [DateTime]::UtcNow.ToString('o'), $_.Exception.GetType().Name, $_.Exception.Message)
    }

    $managerProcess = Start-Process `
        -FilePath $pythonExe `
        -ArgumentList $managerArguments `
        -WorkingDirectory $physicalRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutPath `
        -RedirectStandardError $stderrPath `
        -Wait `
        -PassThru
    $managerExit = $managerProcess.ExitCode
    Add-Content -LiteralPath $bootstrapLog -Value ("MANAGER_EXIT {0} code={1}" -f [DateTime]::UtcNow.ToString('o'), $managerExit)
    exit $managerExit
}
catch {
    Add-Content -LiteralPath $bootstrapLog -Value ("RUNNER_ERROR {0} {1}: {2}" -f [DateTime]::UtcNow.ToString('o'), $_.Exception.GetType().Name, $_.Exception.Message)
    exit 1
}
