from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.oauth_token_mirror import wait_and_mirror
from hero_engine.oauth_refresh_proof import prove_noninteractive_refresh
from hero_engine.oauth_operational_readiness import materialize as materialize_readiness


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Wait for the authorized four-scope OAuth token and mirror it atomically for the Windows manager"
    )
    parser.add_argument("--source", required=True)
    parser.add_argument("--destination", required=True)
    parser.add_argument(
        "--receipt",
        default="output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json",
    )
    parser.add_argument(
        "--refresh-receipt",
        default="output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
    )
    parser.add_argument("--timeout-seconds", type=int, default=86400)
    parser.add_argument("--poll-seconds", type=float, default=2.0)
    args = parser.parse_args()
    receipt = wait_and_mirror(
        Path(args.source),
        Path(args.destination),
        ROOT / args.receipt,
        root=ROOT,
        timeout_seconds=args.timeout_seconds,
        poll_seconds=args.poll_seconds,
    )
    refresh = prove_noninteractive_refresh(
        Path(args.destination),
        ROOT / args.refresh_receipt,
        root=ROOT,
    )
    materialize_readiness(ROOT, token_file=Path(args.destination))
    safe = {
        "status": receipt["status"],
        "receipt_id": receipt["receipt_id"],
        "destination_sha256": receipt["destination_sha256"],
        "granted_scopes": receipt["granted_scopes"],
        "technical_cost_brl": receipt["technical_cost_brl"],
        "mirrored_at": receipt["mirrored_at"],
        "noninteractive_refresh_status": refresh["status"],
        "identity_verified_after_refresh": refresh["identity_verified_after_refresh"],
        "refresh_failure_code": refresh["failure_code"],
    }
    print(json.dumps(safe, ensure_ascii=False, indent=2))
    if refresh["status"] != "PASS":
        raise SystemExit(3)


if __name__ == "__main__":
    main()
