from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
LOCAL_DIR = ROOT / "deployment" / "oauth-compliance"
OUTPUT = ROOT / "output" / "integrations" / "youtube" / "heroverse" / "oauth-public-site-deployment-receipt.json"


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def build_receipt(
    base_url: str,
    repository: str,
    commit_sha: str,
    *,
    search_console_verified: bool = False,
    search_console_property_type: str = "NONE",
    search_console_property: str | None = None,
    oauth_dns_domain_verified: bool = False,
    oauth_dns_domain: str | None = None,
    domain_verification_evidence: str = "UNVERIFIED: Google Search Console ownership has not yet been proven.",
) -> dict:
    base_url = base_url.rstrip("/") + "/"
    if search_console_verified and search_console_property_type == "NONE":
        search_console_property_type = "URL_PREFIX"
    if search_console_verified and search_console_property is None:
        search_console_property = base_url
    assets = ["index.html", "privacy.html", "terms.html", "styles.css"]
    checks = []
    for asset in assets:
        url = base_url if asset == "index.html" else base_url + asset
        request = Request(url, headers={"User-Agent": "HeroVerse-OAuth-Deployment-Verifier/1.0"})
        with urlopen(request, timeout=20) as response:
            remote = response.read()
            final_url = response.geturl()
            status = response.status
        local = (LOCAL_DIR / asset).read_bytes()
        checks.append(
            {
                "asset": asset,
                "url": url,
                "final_url": final_url,
                "status_code": status,
                "local_sha256": sha256(local),
                "remote_sha256": sha256(remote),
                "hash_match": sha256(local) == sha256(remote),
            }
        )
    receipt = {
        "schema_version": "1.1.0",
        "receipt_id": f"oauth-public-site-{commit_sha[:20]}",
        "provider": "GITHUB_PAGES",
        "repository": repository,
        "commit_sha": commit_sha,
        "branch": "main",
        "pages_url": base_url,
        "urls": {
            "homepage": base_url,
            "privacy_policy": base_url + "privacy.html",
            "terms_of_service": base_url + "terms.html",
            "stylesheet": base_url + "styles.css",
        },
        "http_checks": checks,
        "public_without_login": all(item["status_code"] == 200 for item in checks),
        "https_enforced": all(item["final_url"].startswith("https://") for item in checks),
        "authorized_domain": "matheusmagah-cpu.github.io",
        "search_console_property_type": search_console_property_type if search_console_verified else "NONE",
        "search_console_property": search_console_property if search_console_verified else None,
        "search_console_ownership_verified": search_console_verified,
        "oauth_dns_domain_verified": oauth_dns_domain_verified,
        "oauth_dns_domain": oauth_dns_domain if oauth_dns_domain_verified else None,
        "domain_verification_evidence": domain_verification_evidence,
        "billing_required": False,
        "technical_cost_brl": 0,
        "observed_at": datetime.now(timezone.utc).isoformat(),
    }
    schema = json.loads((ROOT / "schemas" / "oauth_public_site_deployment_receipt.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(receipt)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify the zero-cost public OAuth compliance site")
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--commit-sha", required=True)
    parser.add_argument("--search-console-verified", action="store_true")
    parser.add_argument(
        "--search-console-property-type",
        choices=("NONE", "URL_PREFIX", "DOMAIN_PROPERTY"),
        default="NONE",
    )
    parser.add_argument("--search-console-property")
    parser.add_argument("--oauth-dns-domain-verified", action="store_true")
    parser.add_argument("--oauth-dns-domain")
    parser.add_argument(
        "--domain-verification-evidence",
        default="UNVERIFIED: Google Search Console ownership has not yet been proven.",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_receipt(
                args.base_url,
                args.repository,
                args.commit_sha,
                search_console_verified=args.search_console_verified,
                search_console_property_type=args.search_console_property_type,
                search_console_property=args.search_console_property,
                oauth_dns_domain_verified=args.oauth_dns_domain_verified,
                oauth_dns_domain=args.oauth_dns_domain,
                domain_verification_evidence=args.domain_verification_evidence,
            ),
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
