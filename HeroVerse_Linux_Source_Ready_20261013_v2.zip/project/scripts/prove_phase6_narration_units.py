"""Three authorized diagnostic utterances; no production state or paid service.

The PLANNED source grants no authority. The separate bounded diagnostic order
below authorizes only units 011/012/016 after capacity and exact input checks.
"""
from __future__ import annotations

import array
import ctypes
import hashlib
import importlib.metadata
import json
import math
import re
import shutil
import subprocess
import sys
import time
import wave
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from hero_engine.phase6_narration_units import build_narration_unit_plan, canonical_sha, verify_narration_unit_plan

DIAGNOSTIC = "output/qa/phase6/diagnostics/narration-units-v1/narration-continuity-9c22ad5af00a338a97f7877e.json"
DIAGNOSTIC_HASH = "sha256:94706a7b317b2bf97a9d484c48f094b7854c5b6d38f34ecabe84929161e31904"
UNITS = ("narration-unit-011", "narration-unit-012", "narration-unit-016")
COPY = (
    "In the first, write only what happened.",
    "In the second, write what fear says it means.",
    "I will always be abandoned is a sentence fear wrote about your identity.",
)
MIN_DISK_RESERVE = 5 * 1024**3
RAM_RESERVE = 256 * 1024**2
SILENCE_NOISE_DB = -40
SILENCE_MIN_SECONDS = 0.1


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def save_new(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    with Path(path).open("xb") as stream:
        stream.write(raw)


def run(command, timeout=60):
    return subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, timeout=timeout)


def memory_available():
    if sys.platform != "win32":
        import psutil
        memory = psutil.virtual_memory()
        return {"available_bytes": int(memory.available), "total_bytes": int(memory.total), "method": "psutil.virtual_memory"}
    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [(n, ctypes.c_ulonglong) for n in ("total", "available", "total_page", "available_page", "total_virtual", "available_virtual", "available_extended")]
    status = MemoryStatus()
    status.length = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("RAM capacity query unavailable")
    return {"available_bytes": status.available, "total_bytes": status.total, "method": "GlobalMemoryStatusEx"}


def capacity_check(*, available_ram, free_disk, model_bytes, voices_bytes, total_window_ms):
    if any(type(v) is not int or v <= 0 for v in (available_ram, free_disk, model_bytes, voices_bytes, total_window_ms)):
        raise ValueError("capacity measurements must be positive integers")
    # Explicit conservative estimate, not measured model peak: four copies of
    # model weights + voice bank + 256 MiB interpreter/runtime, then reserve.
    estimated_ram = model_bytes * 4 + voices_bytes + 256 * 1024**2
    estimated_disk = math.ceil(total_window_ms / 1000 * 24000 * 2 * 6) + 16 * 1024**2
    reasons = []
    if available_ram < estimated_ram + RAM_RESERVE:
        reasons.append("INSUFFICIENT_RAM_FOR_DIAGNOSTIC_ESTIMATE_AND_RESERVE")
    if free_disk - estimated_disk < MIN_DISK_RESERVE:
        reasons.append("FIVE_GIB_POST_PROOF_RESERVE_NOT_MET")
    return {"status": "BLOCKED" if reasons else "PASS", "blocking_reasons": reasons,
            "available_ram_bytes": available_ram, "estimated_peak_additional_ram_bytes": estimated_ram,
            "ram_reserve_bytes": RAM_RESERVE, "required_available_ram_bytes": estimated_ram + RAM_RESERVE,
            "ram_basis": "model_bytes*4 + voices_bytes + 256MiB runtime + 256MiB reserve; estimate, not observed peak",
            "free_disk_bytes": free_disk, "estimated_peak_new_disk_bytes": estimated_disk,
            "disk_reserve_bytes": MIN_DISK_RESERVE, "post_work_disk_headroom_bytes": free_disk-estimated_disk-MIN_DISK_RESERVE}


def selected_units(plan):
    mapping = {u["unit_id"]: u for u in plan["units"]}
    selected = [mapping[unit_id] for unit_id in UNITS]
    if [u["text"] for u in selected] != list(COPY):
        raise PermissionError("diagnostic copy scope changed")
    for unit, expected_span in zip(selected, ((40700, 45500), (45500, 50600), (59900, 67000)), strict=True):
        if (unit["window_start_ms"], unit["window_end_ms"]) != expected_span or unit["window_limit_ms"] != expected_span[1]-expected_span[0]:
            raise PermissionError("diagnostic visual window scope changed")
        if unit["pinned_speed"] != 1.06 or unit["readiness"] != "NEEDS_SYNTHESIS" or unit["review_issues"]:
            raise PermissionError("diagnostic speed/readiness scope changed")
    return selected


def inspect_wav(path):
    with wave.open(str(path), "rb") as source:
        frames, rate, channels, width = source.getnframes(), source.getframerate(), source.getnchannels(), source.getsampwidth()
        raw = source.readframes(frames)
    if rate != 24000 or channels != 1 or width != 2 or len(raw) != frames*2 or frames <= 0:
        raise ValueError("invalid mono 24kHz PCM16 WAV")
    samples = array.array("h", raw)
    if sys.byteorder != "little":
        samples.byteswap()
    peak = max(abs(int(sample)) for sample in samples) / 32768
    return {"frames": frames, "sample_rate": rate, "channels": channels, "sample_width": width,
            "duration_ms": round(frames*1000/rate, 6), "peak_linear": peak,
            "clipping_samples": sum(int(sample) in (-32768, 32767) for sample in samples), "sha256": sha(path)}, raw


def write_window(path, parts):
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(24000)
        for raw, window_ms in parts:
            slot_bytes = window_ms*24*2
            if len(raw) > slot_bytes:
                raise ValueError("measured audio exceeds immutable window; truncation forbidden")
            output.writeframes(raw + bytes(slot_bytes-len(raw)))


def parse_silence(stderr, duration_ms):
    intervals, pending = [], None
    for line in stderr.splitlines():
        start = re.search(r"silence_start:\s*([-\d.]+)", line)
        if start:
            if pending is not None:
                raise ValueError("nested silence interval")
            pending = max(0., float(start[1])*1000)
        end = re.search(r"silence_end:\s*([-\d.]+)", line)
        if end:
            if pending is None:
                raise ValueError("silence end without start")
            stop = min(float(end[1])*1000, duration_ms)
            if stop < pending:
                raise ValueError("negative silence span")
            intervals.append({"start_ms": round(pending, 6), "end_ms": round(stop, 6), "duration_ms": round(stop-pending, 6)})
            pending = None
    if pending is not None:
        intervals.append({"start_ms": round(pending, 6), "end_ms": duration_ms, "duration_ms": round(duration_ms-pending, 6)})
    internal = [i for i in intervals if i["start_ms"] > 1 and i["end_ms"] < duration_ms-1]
    return {"intervals": intervals, "total_detected_silence_ms": round(sum(i["duration_ms"] for i in intervals), 6),
            "internal_interval_count": len(internal), "internal_silence_ms": round(sum(i["duration_ms"] for i in internal), 6),
            "maximum_internal_silence_ms": max((i["duration_ms"] for i in internal), default=0),
            "threshold_db": SILENCE_NOISE_DB, "minimum_duration_ms": SILENCE_MIN_SECONDS*1000,
            "word_alignment_available": False, "perceptual_quality_approved": False}


def measure_silence(ffmpeg, path, folder, label, duration_ms):
    command = [str(ffmpeg), "-nostdin", "-hide_banner", "-i", str(path), "-af",
               f"silencedetect=noise={SILENCE_NOISE_DB}dB:d={SILENCE_MIN_SECONDS}", "-f", "null", "-"]
    measured = run(command)
    (folder / (label + ".silence.stderr.log")).write_bytes(measured.stderr.encode("utf-8"))
    save_new(folder / (label + ".silence.command.json"), command)
    return parse_silence(measured.stderr, duration_ms)


def phoneme_preflight(engine, units):
    checks = []
    for unit in units:
        phonemes = engine.tokenizer.phonemize(unit["text"], "en-us")
        tokens = engine.tokenizer.tokenize(phonemes)
        batches = engine._split_phonemes(phonemes)
        if not phonemes or len(phonemes) > 510 or len(tokens) > 510 or len(batches) != 1:
            raise PermissionError("diagnostic utterance exceeds one untruncated Kokoro batch")
        checks.append({"unit_id": unit["unit_id"], "text_sha256": unit["text_sha256"], "phoneme_count": len(phonemes),
                       "token_count": len(tokens), "batch_count": len(batches), "phoneme_sha256": canonical_sha(phonemes)})
    return checks


def synthesize_set(engine, units, destination, synthesizer):
    """All members are staged; caller may publish sample receipt only after all fit."""
    records = []
    for unit in units:
        output = destination / (unit["unit_id"] + ".wav")
        if output.exists():
            raise PermissionError("diagnostic WAV already exists")
        result = synthesizer(engine, text=unit["text"], output_path=output, voice_id="am_onyx", speed=unit["pinned_speed"])
        measured, _ = inspect_wav(output)
        if result["content_hash"] != measured["sha256"] or abs(result["duration_ms"]-measured["duration_ms"]) > 0.5:
            raise PermissionError("synthesizer report diverges from actual WAV")
        if measured["frames"]*1000 > unit["window_limit_ms"]*measured["sample_rate"] or measured["clipping_samples"] or result["clipping"]:
            raise PermissionError("sample fails measured fit/clipping; no truncation or speed change allowed")
        records.append({"unit_id": unit["unit_id"], "text": unit["text"], "speed": unit["pinned_speed"],
                        "voice_id": "am_onyx", "window_limit_ms": unit["window_limit_ms"], "wav": output.name,
                        "measured": measured, "render_seconds": result["render_seconds"],
                        "new_end_padding_ms": round(unit["window_limit_ms"]-measured["duration_ms"], 6)})
        print(json.dumps({"event": "STAGED_UNIT_MEASURED_NOT_APPROVED", "unit_id": unit["unit_id"], "duration_ms": measured["duration_ms"]}), flush=True)
    return records


def main():
    started = time.perf_counter()
    diagnostic_path = ROOT / DIAGNOSTIC
    if sha(diagnostic_path) != DIAGNOSTIC_HASH:
        raise PermissionError("exact diagnostic source changed")
    diagnostic = json.loads(diagnostic_path.read_text(encoding="utf-8"))
    # Revalidate source material, not the old compiler's source-code snapshot.
    bindings = diagnostic["source_files"][:3]
    for source in bindings:
        if sha(ROOT / source["path"]) != source["sha256"]:
            raise PermissionError("historical source changed")
    plan, voice = [json.loads((ROOT / source["path"]).read_text(encoding="utf-8")) for source in bindings[:2]]
    proposal = build_narration_unit_plan(plan, voice)
    verify_narration_unit_plan(diagnostic["plan"], plan, voice)
    units = selected_units(proposal)
    if voice["voice_id"] != "am_onyx" or voice["adapter_implementation"] != "KokoroFloatSpeed":
        raise PermissionError("unsupported voice/model adapter")
    model = ROOT / "models/kokoro/kokoro-v1.0.fp16.onnx"
    voices = ROOT / "models/kokoro/voices-v1.0.bin"
    for path, expected in ((model, voice["model_hash"]), (voices, voice["voices_hash"])):
        if sha(path) != expected:
            raise PermissionError("local model hash mismatch; no download fallback")
    ffmpeg = Path(shutil.which("ffmpeg") or "C:/ffmpeg/bin/ffmpeg.exe").resolve(strict=True)
    ffprobe = ffmpeg.with_name("ffprobe.exe" if sys.platform == "win32" else "ffprobe")
    versions = {"ffmpeg": run([str(ffmpeg), "-version"]).stdout.splitlines()[0], "ffprobe": run([str(ffprobe), "-version"]).stdout.splitlines()[0]}
    if "silencedetect" not in run([str(ffmpeg), "-hide_banner", "-filters"]).stdout:
        raise PermissionError("FFmpeg silencedetect missing")
    packages = {name: importlib.metadata.version(name) for name in ("kokoro-onnx", "onnxruntime", "numpy", "soundfile")}
    selected_wavs = {}
    for unit in units:
        for fragment in unit["source_fragments"]:
            item = next(r for r in voice["takes"] if r["take_id"] == fragment["take_id"])
            path = Path(item["path"]).resolve(strict=True)
            if not path.is_relative_to((ROOT / "output/production/phase6/video-002/audio/takes").resolve()):
                raise PermissionError("old WAV escaped expected namespace")
            measured, raw = inspect_wav(path)
            if measured["sha256"] != item["content_hash"] or measured["frames"] != item["frame_count"]:
                raise PermissionError("old WAV binding differs")
            selected_wavs[item["take_id"]] = {"record": item, "measured": measured, "raw": raw}
    parent = ROOT / "output/qa/phase6/diagnostics"
    if parent.resolve() != parent:
        raise PermissionError("diagnostic directory redirected")
    now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination = parent / ("narration-unit-proof-" + now)
    destination.mkdir(exist_ok=False)
    order = {"order_class": "LOCAL_NARRATION_CONTINUITY_SAMPLE_ONLY", "scope": list(UNITS),
             "source_diagnostic": DIAGNOSTIC, "source_diagnostic_sha256": DIAGNOSTIC_HASH,
             "authorization_basis": "Bounded Gestor diagnostic instruction: synthesize three exact local units only after preflight; no production authority",
             "maximum_tts_calls": 3, "new_voice_wav_count": 3, "preserve_windows": True, "speed_change_allowed": False,
             "copy_change_allowed": False, "production_authorized": False, "publication_authorized": False, "technical_cost_brl": 0}
    save_new(destination / "diagnostic-order.json", order)
    try:
        memory = memory_available()
        capacity = capacity_check(available_ram=memory["available_bytes"], free_disk=shutil.disk_usage(parent).free,
                                  model_bytes=model.stat().st_size, voices_bytes=voices.stat().st_size,
                                  total_window_ms=sum(u["window_limit_ms"] for u in units))
        preflight = {"scope": "LOCAL_NARRATION_CONTINUITY_SAMPLE_ONLY", **capacity,
                     "observed_at": now, "memory": memory, "tools": versions, "packages": packages,
                     "model": {"path": str(model), "sha256": sha(model)}, "voices": {"path": str(voices), "sha256": sha(voices)},
                     "ffmpeg_sha256": sha(ffmpeg), "ffprobe_sha256": sha(ffprobe), "order_sha256": sha(destination / "diagnostic-order.json"),
                     "input_bindings": bindings, "runner_sha256": sha(Path(__file__)), "units": units,
                     "queue_authorized": False, "publication_authorized": False, "technical_cost_brl": 0}
        save_new(destination / "preflight.json", preflight)
        if capacity["status"] != "PASS":
            raise PermissionError(";".join(capacity["blocking_reasons"]))
        print(json.dumps({"event": "CAPACITY_PASS", "path": str(destination), "available_ram_bytes": memory["available_bytes"]}), flush=True)
        # Import the heavy runtime only after the RAM/model/disk gate passed.
        from hero_engine.voice_phase5 import build_local_voice, synthesize_voice_sample, revalidate_local_espeak_binding
        engine = build_local_voice(ROOT, expected_binding=voice["espeak_binding"])
        espeak = revalidate_local_espeak_binding(engine._heroverse_espeak_binding, expected_binding=voice["espeak_binding"])
        phonemes = phoneme_preflight(engine, units)
        remaining = memory_available()
        if remaining["available_bytes"] < RAM_RESERVE:
            raise PermissionError("RAM reserve unavailable after model load; no synthesis")
        save_new(destination / "synthesis-preflight.json", {"status": "PASS", "phonemes": phonemes, "espeak_binding": espeak,
                 "memory_after_model_load": remaining, "preflight_sha256": sha(destination / "preflight.json"),
                 "order_sha256": sha(destination / "diagnostic-order.json"), "diagnostic_synthesis_authorized": True,
                 "production_authorized": False, "maximum_tts_calls": 3})
        staged = destination / "staged"
        staged.mkdir()
        records = synthesize_set(engine, units, staged, synthesize_voice_sample)
        revalidate_local_espeak_binding(engine._heroverse_espeak_binding, expected_binding=voice["espeak_binding"])
        engine._heroverse_espeak_binding.close()
        del engine
        comparisons = []
        for unit, record in zip(units, records, strict=True):
            old_path = destination / (unit["unit_id"] + ".historical-window.wav")
            new_path = destination / (unit["unit_id"] + ".continuous-window.wav")
            parts = [(selected_wavs[f["take_id"]]["raw"], f["visual_end_ms"]-f["visual_start_ms"]) for f in unit["source_fragments"]]
            write_window(old_path, parts)
            measured, raw = inspect_wav(staged / record["wav"])
            write_window(new_path, [(raw, unit["window_limit_ms"])])
            old_silence = measure_silence(ffmpeg, old_path, destination, unit["unit_id"]+".old", unit["window_limit_ms"])
            new_silence = measure_silence(ffmpeg, new_path, destination, unit["unit_id"]+".new", unit["window_limit_ms"])
            raw_silence = measure_silence(ffmpeg, staged / record["wav"], destination, unit["unit_id"]+".raw", measured["duration_ms"])
            comparisons.append({"unit_id": unit["unit_id"], "old_window_sha256": sha(old_path), "new_window_sha256": sha(new_path),
                 "historical_padding_ms": unit["historical_padding_ms"], "new_end_padding_ms": record["new_end_padding_ms"],
                 "historical_window_silence": old_silence, "continuous_window_silence": new_silence, "new_raw_silence": raw_silence,
                 "internal_silence_delta_ms": round(new_silence["internal_silence_ms"]-old_silence["internal_silence_ms"], 6),
                 "new_word_timestamps": None, "quality_perceptual_status": "NOT_REVIEWED"})
        for source in bindings:
            if sha(ROOT / source["path"]) != source["sha256"]:
                raise PermissionError("input drift during sample")
        for wav in selected_wavs.values():
            if sha(wav["record"]["path"]) != wav["record"]["content_hash"]:
                raise PermissionError("historical WAV drift")
        if sha(model) != voice["model_hash"] or sha(voices) != voice["voices_hash"]:
            raise PermissionError("model drift")
        artifacts = {p.relative_to(destination).as_posix(): sha(p) for p in destination.rglob("*") if p.is_file()}
        receipt = {"scope": "THREE_UNIT_LOCAL_NARRATION_PROOF_ONLY", "status": "PRODUCED_PENDING_INDEPENDENT_REVIEW",
                   "preflight_sha256": sha(destination / "preflight.json"), "synthesis_preflight_sha256": sha(destination / "synthesis-preflight.json"),
                   "order_sha256": sha(destination / "diagnostic-order.json"), "records": records, "comparisons": comparisons,
                   "artifact_bindings": artifacts, "new_tts_calls": 3, "wall_seconds": round(time.perf_counter()-started, 6),
                   "queue_authorized": False, "publication_authorized": False, "production_authorized": False, "technical_cost_brl": 0,
                   "limitations": ["No independent listening, phonetic ASR or word alignment yet", "Thresholded silence is not semantic pause attribution or perceptual quality",
                     "Raw PCM comparison before final EQ, mastering, music or effects", "Preserved horizon redistributes end padding; pacing is not approved",
                     "Adapter trim=True retains existing silence-edge trim behavior; no truncation to fit and no speed change", "Diagnostic only: no runtime or release integration"]}
        save_new(destination / "receipt.json", receipt)
        print(json.dumps({"event": "PROOF_READY_FOR_REVIEW", "path": str(destination), "receipt_sha256": sha(destination / "receipt.json"),
                          "records": records, "comparisons": comparisons}, ensure_ascii=False), flush=True)
    except BaseException as exc:
        if not (destination / "failure.json").exists():
            save_new(destination / "failure.json", {"status": "FAILED_OR_BLOCKED_NOT_CONSUMABLE", "error": f"{type(exc).__name__}: {exc}",
                      "artifacts_preserved": {p.relative_to(destination).as_posix(): sha(p) for p in destination.rglob("*") if p.is_file()},
                      "production_authorized": False, "publication_authorized": False, "technical_cost_brl": 0})
        print(json.dumps({"event": "PROOF_BLOCKED", "path": str(destination), "error": str(exc)}), flush=True)
        raise


if __name__ == "__main__":
    main()
