[CmdletBinding()]
param(
    [string]$TaskName = 'HeroEngine-Phase5-CentralManager'
)

$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($null -ne $task) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

[pscustomobject]@{
    task_name = $TaskName
    removed = ($null -ne $task)
} | ConvertTo-Json
