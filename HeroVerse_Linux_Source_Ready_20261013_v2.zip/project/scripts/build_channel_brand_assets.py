from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output" / "brand" / "channel" / "heroverse-v2"
SOURCE = OUT / "source" / "prayer-to-action-background-v1.png"
BANNER = OUT / "heroverse-banner-v2.png"
AVATAR = OUT / "heroverse-avatar-v2.png"
WATERMARK = OUT / "heroverse-watermark-v2.png"
MOBILE = OUT / "previews" / "heroverse-banner-mobile-safe-preview.png"
DESKTOP = OUT / "previews" / "heroverse-banner-desktop-preview.png"
MANIFEST = OUT / "brand-asset-pack.json"

GOLD = (232, 177, 74)
WARM_WHITE = (246, 242, 232)
CHARCOAL = (9, 12, 16)


def font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render_mark(canvas: Image.Image, box: tuple[int, int, int, int], *, compact: bool = False) -> None:
    draw = ImageDraw.Draw(canvas)
    x0, y0, x1, y1 = box
    width = x1 - x0
    stroke = max(3, width // 45)
    draw.ellipse(box, fill=(9, 12, 16, 224), outline=GOLD + (255,), width=stroke)
    h_font = font(r"C:\Windows\Fonts\bahnschrift.ttf", int(width * (0.58 if compact else 0.54)))
    bbox = draw.textbbox((0, 0), "H", font=h_font, stroke_width=0)
    tx = x0 + (width - (bbox[2] - bbox[0])) / 2
    ty = y0 + (width - (bbox[3] - bbox[1])) / 2 - bbox[1] - width * 0.025
    draw.text((tx, ty), "H", font=h_font, fill=WARM_WHITE + (255,))
    # The short amber stroke is the repeatable visual metaphor: the first step.
    line_y = y0 + width * 0.72
    draw.rounded_rectangle(
        (x0 + width * 0.31, line_y, x0 + width * 0.69, line_y + max(4, width * 0.035)),
        radius=max(2, width // 80), fill=GOLD + (255,),
    )


def build_banner() -> dict:
    source = Image.open(SOURCE).convert("RGB")
    background = ImageOps.fit(source, (2560, 1440), method=Image.Resampling.LANCZOS)
    background = ImageEnhance.Color(background).enhance(0.88)
    background = ImageEnhance.Contrast(background).enhance(1.05)
    canvas = background.convert("RGBA")

    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    pixels = overlay.load()
    for y in range(1440):
        vignette_y = abs(y - 720) / 720
        for x in range(2560):
            center_distance = abs(x - 1280) / 1280
            alpha = int(42 + 78 * center_distance + 30 * vignette_y)
            if 480 <= x <= 2075 and 500 <= y <= 940:
                alpha += 34
            pixels[x, y] = (4, 7, 10, min(alpha, 184))
    overlay = overlay.filter(ImageFilter.GaussianBlur(radius=22))
    canvas = Image.alpha_composite(canvas, overlay)

    # YouTube universal safe area: 1546 x 423 centered on 2560 x 1440.
    safe = (507, 508, 2053, 931)
    render_mark(canvas, (610, 606, 850, 846))
    draw = ImageDraw.Draw(canvas)
    title_font = font(r"C:\Windows\Fonts\bahnschrift.ttf", 124)
    tagline_font = font(r"C:\Windows\Fonts\arialbd.ttf", 54)
    descriptor_font = font(r"C:\Windows\Fonts\arial.ttf", 28)
    draw.text((900, 574), "HEROVERSE", font=title_font, fill=WARM_WHITE + (255,))
    draw.rounded_rectangle((902, 722, 1366, 729), radius=3, fill=GOLD + (255,))
    draw.text((900, 752), "FROM PRAYER TO ACTION.", font=tagline_font, fill=GOLD + (255,))
    draw.text((902, 828), "CINEMATIC CHRISTIAN MOTIVATION", font=descriptor_font, fill=(226, 228, 229, 255))

    OUT.mkdir(parents=True, exist_ok=True)
    canvas.convert("RGB").save(BANNER, quality=95)
    mobile = canvas.crop(safe).resize((1546, 423), Image.Resampling.LANCZOS)
    MOBILE.parent.mkdir(parents=True, exist_ok=True)
    mobile.convert("RGB").save(MOBILE, quality=94)
    desktop = canvas.crop((0, 508, 2560, 931)).resize((2560, 423), Image.Resampling.LANCZOS)
    desktop.convert("RGB").save(DESKTOP, quality=94)
    return {
        "path": BANNER.relative_to(ROOT).as_posix(),
        "width": 2560, "height": 1440,
        "safe_area": {"x": safe[0], "y": safe[1], "width": safe[2] - safe[0], "height": safe[3] - safe[1]},
        "content_bbox": {"x": 610, "y": 574, "width": 1390, "height": 302},
        "safe_area_pass": 610 >= safe[0] and 2000 <= safe[2] and 574 >= safe[1] and 876 <= safe[3],
        "sha256": sha(BANNER), "bytes": BANNER.stat().st_size,
    }


def build_avatar() -> dict:
    size = 800
    image = Image.new("RGBA", (size, size), CHARCOAL + (255,))
    draw = ImageDraw.Draw(image)
    for radius in range(390, 30, -2):
        ratio = radius / 390
        amber = int(26 * (1 - ratio))
        draw.ellipse((400 - radius, 400 - radius, 400 + radius, 400 + radius), fill=(9 + amber, 12 + amber // 2, 16, 255))
    render_mark(image, (70, 70, 730, 730), compact=True)
    image.save(AVATAR)
    return {"path": AVATAR.relative_to(ROOT).as_posix(), "width": size, "height": size, "sha256": sha(AVATAR), "bytes": AVATAR.stat().st_size, "export_annotation_present": False}


def build_watermark() -> dict:
    image = Image.new("RGBA", (150, 150), (0, 0, 0, 0))
    render_mark(image, (8, 8, 142, 142), compact=True)
    image.save(WATERMARK)
    return {"path": WATERMARK.relative_to(ROOT).as_posix(), "width": 150, "height": 150, "sha256": sha(WATERMARK), "bytes": WATERMARK.stat().st_size, "transparent": True}


def main() -> None:
    banner = build_banner()
    avatar = build_avatar()
    watermark = build_watermark()
    manifest = {
        "schema_version": "1.0.0",
        "pack_id": "heroverse-brand-assets@2.0.0",
        "status": "PROTOTYPED",
        "production_applied": False,
        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
        "channel_dna_ref": "output/modeling/phase4/channel-model-v1/channel_model.json",
        "style_bible_ref": "output/production/phase5/pilot-001/creative-v2/channel_style_bible.json",
        "creative_hypothesis": "A restrained prayer-to-action identity will align the channel promise, improve recognition and avoid the current superhero/fantasy mismatch.",
        "background": {"path": SOURCE.relative_to(ROOT).as_posix(), "sha256": sha(SOURCE), "provider": "builtin-imagegen", "external_cost_usd": 0},
        "assets": {"banner": banner, "avatar": avatar, "watermark": watermark},
        "previews": {"mobile_safe": MOBILE.relative_to(ROOT).as_posix(), "desktop": DESKTOP.relative_to(ROOT).as_posix()},
        "automatic_tests": {
            "banner_dimensions": "PASS" if banner["width"] == 2560 and banner["height"] == 1440 else "FAIL",
            "banner_safe_area": "PASS" if banner["safe_area_pass"] else "FAIL",
            "avatar_dimensions": "PASS" if avatar["width"] == avatar["height"] == 800 else "FAIL",
            "watermark_dimensions": "PASS" if watermark["width"] == watermark["height"] == 150 else "FAIL",
            "watermark_size_under_1mb": "PASS" if watermark["bytes"] < 1_000_000 else "FAIL",
        },
        "human_review": "PENDING_INDEPENDENT",
        "application_gate": "BLOCKED_PENDING_INDEPENDENT_VISUAL_REVIEW",
        "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"manifest": str(MANIFEST), "tests": manifest["automatic_tests"], "application_gate": manifest["application_gate"]}, indent=2))


if __name__ == "__main__":
    main()
