"""Derive a non-rendering, full-span geometry solution for hook take-003.

This diagnostic consumes the lossless 150-frame FFV1 source already produced
by the failed v3 preflight.  It does not extract the source again, compile
filters, render media, call an API, touch the queue, or grant production or
publication authority.

The selected static placement must be inside the intersection of every
assigned card's segmented convex hull, with at least eight pixels of signed
corner clearance on every frame.  Exact Pillow measurements preserve 84px
NAME / TEST / CHOOSE copy; the largest feasible common backing padding wins.
"""
from __future__ import annotations

import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hero_engine.phase6_visual_recipe import _measure, _safe_area
from hero_engine.render_creative_v2_phase5 import _font


SOURCE_PROOF = (
    ROOT / "output/qa/phase6/diagnostics/"
    "layered-hook-proof-a1da6f2da24300a0c475f32c"
)
SOURCE_FFV1 = SOURCE_PROOF / "source-full-span.mkv"
SOURCE_FFV1_SHA256 = (
    "sha256:9b34d8938302b2636a2b858438f05f7303278c68aeec472c58f2f94c98ec9d04"
)
SOURCE_RECEIPT = SOURCE_PROOF / "source-preflight-receipt.json"
SOURCE_RECEIPT_SHA256 = (
    "sha256:2609a29b9316e9cad2ab7d2eeba89bc614621ff798c7684c3b27cdb4450c6398"
)
SOURCE_GEOMETRY = SOURCE_PROOF / "source-full-span-geometry.json"
SOURCE_GEOMETRY_SHA256 = (
    "sha256:c132bd46f0fdae0fbb6b454015ddc70179f3ccedd0be7bf7fa2f137318aa785e"
)
TOKENS = ("NAME", "TEST", "CHOOSE")
FONT_SIZE = 84
VERTICAL_PADDING = 8
HORIZONTAL_PADDING_CANDIDATES = (12, 10, 8, 6, 4)
FRAME_COUNT = 150
FPS = 30
MINIMUM_HULL_FRACTION = 1.0
MINIMUM_CORNER_CLEARANCE = 8.0
MINIMUM_PHOTOMETRIC_FRACTION = 0.85
SAFE_PRIMARY_TOP = 595
SAFE_PRIMARY_BOTTOM = 780
BASELINE_BACKING_LEFTS = (232, 853, 1366)
BASELINE_BACKING_TOP = 632
SECONDARY_PANEL = {"left": 154, "top": 95, "right": 791, "bottom": 255}
ALGORITHM_VERSION = "static-common-convex-intersection-v1"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def save_new(path: Path, value: Any) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)


def _component_hulls(bgr: np.ndarray) -> list[dict[str, Any]]:
    if bgr.shape != (1080, 1920, 3):
        raise PermissionError("FFV1 frame is not 1920x1080 RGB-compatible video")
    crop = bgr[430:970].astype(np.float32) / np.float32(255.0)
    rgb = crop[:, :, ::-1]
    luminance = (
        np.float32(0.2126) * rgb[:, :, 0]
        + np.float32(0.7152) * rgb[:, :, 1]
        + np.float32(0.0722) * rgb[:, :, 2]
    )
    chroma = np.max(rgb, axis=2) - np.min(rgb, axis=2)
    card_mask = ((luminance >= 0.28) & (chroma <= 0.25)).astype(np.uint8) * 255
    card_mask = cv2.morphologyEx(
        card_mask, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8)
    )
    count, labels, stats, _ = cv2.connectedComponentsWithStats(card_mask)
    components: list[dict[str, Any]] = []
    for label_index, (x, y, width, height, area) in enumerate(
        stats[1:count], start=1
    ):
        if int(area) < 100_000:
            continue
        component = (
            labels[int(y):int(y + height), int(x):int(x + width)] == label_index
        ).astype(np.uint8) * 255
        contours, _ = cv2.findContours(
            component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        if not contours:
            raise PermissionError("eligible card component has no external contour")
        contour = max(contours, key=cv2.contourArea)
        hull = cv2.convexHull(contour).astype(np.int32)
        hull[:, :, 0] += int(x)
        hull[:, :, 1] += int(y) + 430
        components.append({
            "left": int(x),
            "top": int(y) + 430,
            "right": int(x + width),
            "bottom": int(y + height) + 430,
            "area_pixels": int(area),
            "hull": hull,
            "card_mask": card_mask,
        })
    components.sort(key=lambda item: item["left"])
    if len(components) != 3:
        raise PermissionError(
            f"expected three assigned card components, observed {len(components)}"
        )
    return components


def _intersect_convex(polygons: list[np.ndarray]) -> np.ndarray:
    if not polygons:
        raise ValueError("cannot intersect an empty polygon collection")
    common = cv2.convexHull(polygons[0].astype(np.float32))
    for polygon in polygons[1:]:
        area, intersection = cv2.intersectConvexConvex(
            common, cv2.convexHull(polygon.astype(np.float32))
        )
        if intersection is None or not math.isfinite(float(area)) or area <= 0:
            raise PermissionError("a card has no common full-span convex region")
        common = cv2.convexHull(intersection.astype(np.float32))
    return common


def _corner_clearances(polygon: np.ndarray, rectangle: dict[str, int]) -> list[float]:
    corners = (
        (rectangle["left"], rectangle["top"]),
        (rectangle["right"] - 1, rectangle["top"]),
        (rectangle["left"], rectangle["bottom"] - 1),
        (rectangle["right"] - 1, rectangle["bottom"] - 1),
    )
    return [
        float(cv2.pointPolygonTest(polygon, (float(x), float(y)), True))
        for x, y in corners
    ]


def _best_x_for_top(
    polygon: np.ndarray,
    *,
    top: int,
    width: int,
    height: int,
    target_left: int,
    safe_left: int,
    safe_right: int,
) -> dict[str, Any] | None:
    best: dict[str, Any] | None = None
    for left in range(safe_left, safe_right - width + 1):
        rectangle = {
            "left": left,
            "top": top,
            "right": left + width,
            "bottom": top + height,
            "width": width,
            "height": height,
        }
        clearances = _corner_clearances(polygon, rectangle)
        minimum = min(clearances)
        if minimum + 1e-9 < MINIMUM_CORNER_CLEARANCE:
            continue
        candidate = {
            "rectangle": rectangle,
            "intersection_corner_clearances_pixels": clearances,
            "minimum_intersection_corner_clearance_pixels": minimum,
            "horizontal_displacement_from_v2_pixels": left - target_left,
        }
        rank = (abs(left - target_left), -minimum, left)
        if best is None or rank < best["rank"]:
            best = {**candidate, "rank": rank}
    return best


def _derive_layout(
    common_polygons: list[np.ndarray], measurements: list[dict[str, Any]]
) -> dict[str, Any]:
    safe = _safe_area()
    attempts: list[dict[str, Any]] = []
    selected: dict[str, Any] | None = None
    for horizontal_padding in HORIZONTAL_PADDING_CANDIDATES:
        widths = [item["width"] + 2 * horizontal_padding for item in measurements]
        heights = [item["height"] + 2 * VERTICAL_PADDING for item in measurements]
        if len(set(heights)) != 1:
            raise PermissionError("primary tokens do not share a common measured height")
        height = heights[0]
        top_results: list[dict[str, Any]] = []
        last_top = min(int(safe["bottom"]) - height, SAFE_PRIMARY_BOTTOM - height)
        first_top = max(int(safe["top"]), SAFE_PRIMARY_TOP)
        for top in range(first_top, last_top + 1):
            placements = [
                _best_x_for_top(
                    common_polygons[index], top=top, width=widths[index],
                    height=height, target_left=BASELINE_BACKING_LEFTS[index],
                    safe_left=int(safe["left"]), safe_right=int(safe["right"]),
                )
                for index in range(3)
            ]
            if any(item is None for item in placements):
                continue
            concrete = [item for item in placements if item is not None]
            displacement = sum(
                abs(item["horizontal_displacement_from_v2_pixels"])
                for item in concrete
            ) + 3 * abs(top - BASELINE_BACKING_TOP)
            minimum_clearance = min(
                item["minimum_intersection_corner_clearance_pixels"]
                for item in concrete
            )
            top_results.append({
                "top": top,
                "placements": concrete,
                "total_axis_displacement_score": displacement,
                "minimum_intersection_corner_clearance_pixels": minimum_clearance,
            })
        attempt = {
            "horizontal_padding_pixels": horizontal_padding,
            "backing_widths": widths,
            "backing_height": height,
            "shared_top_candidate_count": len(top_results),
        }
        attempts.append(attempt)
        if top_results:
            top_results.sort(key=lambda item: (
                item["total_axis_displacement_score"],
                -item["minimum_intersection_corner_clearance_pixels"],
                item["top"],
            ))
            selected = {
                "horizontal_padding_pixels": horizontal_padding,
                "vertical_padding_pixels": VERTICAL_PADDING,
                **top_results[0],
            }
            break
    if selected is None:
        return {"status": "BLOCKED_NO_STATIC_COMMON_REGION", "attempts": attempts}
    overlays = []
    for index, (token, measurement, placement) in enumerate(
        zip(TOKENS, measurements, selected["placements"], strict=True), start=1
    ):
        backing = placement["rectangle"]
        text_left = backing["left"] + (backing["width"] - measurement["width"]) // 2
        text_top = backing["top"] + (backing["height"] - measurement["height"]) // 2
        overlays.append({
            "card_index": index,
            "copy": token,
            "font_size": FONT_SIZE,
            "font_measurement": measurement,
            "text_bounds": {
                "left": text_left, "top": text_top,
                "right": text_left + measurement["width"],
                "bottom": text_top + measurement["height"],
                "width": measurement["width"], "height": measurement["height"],
            },
            "backing": backing,
            "minimum_intersection_corner_clearance_pixels": placement[
                "minimum_intersection_corner_clearance_pixels"
            ],
            "horizontal_displacement_from_v2_pixels": placement[
                "horizontal_displacement_from_v2_pixels"
            ],
        })
    return {
        "status": "STATIC_COMMON_REGION_CANDIDATE",
        "selection_rule": (
            "LARGEST_BACKING_PADDING_THEN_MINIMUM_TOTAL_AXIS_DISPLACEMENT_"
            "WITH_CLEARANCE_TIEBREAK"
        ),
        "attempts": attempts,
        "selected_shared_top": selected["top"],
        "selected_horizontal_padding_pixels": selected["horizontal_padding_pixels"],
        "selected_vertical_padding_pixels": selected["vertical_padding_pixels"],
        "total_axis_displacement_score": selected["total_axis_displacement_score"],
        "overlays": overlays,
    }


def _verify_selected(
    frames: list[list[dict[str, Any]]], layout: dict[str, Any]
) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    for frame_number, components in enumerate(frames):
        card_records = []
        for overlay, component in zip(layout["overlays"], components, strict=True):
            backing = overlay["backing"]
            hull = component["hull"]
            clearances = _corner_clearances(hull, backing)
            local_hull = hull.copy().astype(np.int32)
            local_hull[:, :, 0] -= backing["left"]
            local_hull[:, :, 1] -= backing["top"]
            backing_mask = np.zeros(
                (backing["height"], backing["width"]), dtype=np.uint8
            )
            cv2.fillConvexPoly(backing_mask, local_hull, 255)
            hull_fraction = float(np.mean(backing_mask > 0))
            source_mask = component["card_mask"]
            source_region = source_mask[
                backing["top"] - 430:backing["bottom"] - 430,
                backing["left"]:backing["right"],
            ]
            photometric_fraction = float(np.mean(source_region > 0))
            card_records.append({
                "card_index": overlay["card_index"],
                "copy": overlay["copy"],
                "hull_fraction": hull_fraction,
                "photometric_fraction": photometric_fraction,
                "corner_clearances_pixels": clearances,
                "minimum_corner_clearance_pixels": min(clearances),
                "component_bounds": {
                    key: component[key]
                    for key in ("left", "top", "right", "bottom", "area_pixels")
                },
                "hull_vertices": component["hull"].reshape(-1, 2).tolist(),
            })
        frame_pass = all(
            item["hull_fraction"] >= MINIMUM_HULL_FRACTION
            and item["photometric_fraction"] >= MINIMUM_PHOTOMETRIC_FRACTION
            and item["minimum_corner_clearance_pixels"] >= MINIMUM_CORNER_CLEARANCE
            for item in card_records
        )
        records.append({
            "frame_number": frame_number,
            "relative_offset_ms": frame_number * 1_000 / FPS,
            "status": "PASS" if frame_pass else "FAIL",
            "cards": card_records,
        })
    all_cards = [card for frame in records for card in frame["cards"]]
    failures = [item["frame_number"] for item in records if item["status"] != "PASS"]
    return {
        "schema_version": "1.0.0",
        "status": "PASS_ALL_150_FRAMES" if not failures else "FAIL_FULL_SPAN",
        "required_frame_count": FRAME_COUNT,
        "observed_frame_count": len(records),
        "failed_frame_numbers": failures,
        "minimum_hull_fraction": min(item["hull_fraction"] for item in all_cards),
        "minimum_photometric_fraction": min(
            item["photometric_fraction"] for item in all_cards
        ),
        "minimum_corner_clearance_pixels": min(
            item["minimum_corner_clearance_pixels"] for item in all_cards
        ),
        "frames": records,
    }


def main() -> None:
    pins = {
        SOURCE_FFV1: SOURCE_FFV1_SHA256,
        SOURCE_RECEIPT: SOURCE_RECEIPT_SHA256,
        SOURCE_GEOMETRY: SOURCE_GEOMETRY_SHA256,
    }
    for path, expected in pins.items():
        if not path.is_file() or sha(path) != expected:
            raise PermissionError(f"frozen input missing or changed: {path}")
    prior = json.loads(SOURCE_GEOMETRY.read_text(encoding="utf-8"))
    if (
        prior.get("status") != "FAIL_FULL_SPAN_SOURCE_GEOMETRY"
        or prior.get("observed_frame_count") != FRAME_COUNT
    ):
        raise PermissionError("frozen v3 failure is not the expected control negative")
    font = _font().resolve(strict=True)
    measurements = [_measure(font, token, FONT_SIZE) for token in TOKENS]
    capture = cv2.VideoCapture(str(SOURCE_FFV1))
    if not capture.isOpened():
        raise PermissionError("cannot decode frozen source FFV1")
    frames: list[list[dict[str, Any]]] = []
    try:
        while len(frames) <= FRAME_COUNT:
            decoded, bgr = capture.read()
            if not decoded:
                break
            if len(frames) == FRAME_COUNT:
                raise PermissionError("frozen FFV1 contains more than 150 frames")
            frames.append(_component_hulls(bgr))
    finally:
        capture.release()
    if len(frames) != FRAME_COUNT:
        raise PermissionError(
            f"frozen FFV1 decoded {len(frames)} frames instead of {FRAME_COUNT}"
        )
    common_polygons = [
        _intersect_convex([frame[index]["hull"] for frame in frames])
        for index in range(3)
    ]
    layout = _derive_layout(common_polygons, measurements)
    binding_paths = (*pins.keys(), font, Path(__file__).resolve())
    input_bindings = {
        (
            str(path.relative_to(ROOT))
            if path.is_relative_to(ROOT)
            else "external-local-file:" + str(path)
        ): sha(path)
        for path in binding_paths
    }
    identity = canonical_sha({
        "algorithm_version": ALGORITHM_VERSION,
        "input_bindings": input_bindings,
        "policy": {
            "frame_count": FRAME_COUNT,
            "font_size": FONT_SIZE,
            "minimum_hull_fraction": MINIMUM_HULL_FRACTION,
            "minimum_corner_clearance_pixels": MINIMUM_CORNER_CLEARANCE,
            "minimum_photometric_fraction": MINIMUM_PHOTOMETRIC_FRACTION,
            "horizontal_padding_candidates": HORIZONTAL_PADDING_CANDIDATES,
            "vertical_padding_pixels": VERTICAL_PADDING,
        },
    })
    destination = ROOT / "output/qa/phase6/diagnostics" / (
        "layered-hook-static-geometry-" + identity.split(":", 1)[1][:24]
    )
    destination.mkdir(exist_ok=False)
    common_geometry = {
        "schema_version": "1.0.0",
        "algorithm_version": ALGORITHM_VERSION,
        "common_card_hulls": [item.reshape(-1, 2).tolist() for item in common_polygons],
        "safe_area": _safe_area(),
        "primary_vertical_band": {
            "top": SAFE_PRIMARY_TOP, "bottom": SAFE_PRIMARY_BOTTOM
        },
        "secondary_panel_preserved": SECONDARY_PANEL,
        "secondary_relation": "DISTINCT_CHANNEL_SYSTEM_NOT_CARD_MAPPING",
    }
    save_new(destination / "common-geometry.json", common_geometry)
    save_new(destination / "candidate-layout.json", layout)
    if layout["status"] != "STATIC_COMMON_REGION_CANDIDATE":
        receipt = {
            "schema_version": "1.0.0",
            "scope": "HOOK_003_STATIC_GEOMETRY_DIAGNOSTIC_ONLY",
            "status": "BLOCKED_NO_STATIC_COMMON_REGION",
            "identity_sha256": identity,
            "input_bindings": input_bindings,
            "candidate_layout_sha256": sha(destination / "candidate-layout.json"),
            "render_performed": False,
            "technical_cost_brl": 0,
            "api_calls": 0,
            "queue_authorized": False,
            "production_authorized": False,
            "publication_authorized": False,
        }
        save_new(destination / "receipt.json", receipt)
        print(json.dumps(receipt, ensure_ascii=False), flush=True)
        return
    verification = _verify_selected(frames, layout)
    save_new(destination / "frame-verification.json", verification)
    safe = _safe_area()
    safe_pass = all(
        item["backing"]["left"] >= safe["left"]
        and item["backing"]["right"] <= safe["right"]
        and item["backing"]["top"] >= safe["top"]
        and item["backing"]["bottom"] <= safe["bottom"]
        for item in layout["overlays"]
    )
    secondary_distinct = all(
        item["backing"]["top"] >= SECONDARY_PANEL["bottom"]
        for item in layout["overlays"]
    )
    passed = (
        verification["status"] == "PASS_ALL_150_FRAMES"
        and verification["observed_frame_count"] == FRAME_COUNT
        and verification["minimum_hull_fraction"] >= MINIMUM_HULL_FRACTION
        and verification["minimum_corner_clearance_pixels"]
        >= MINIMUM_CORNER_CLEARANCE
        and verification["minimum_photometric_fraction"]
        >= MINIMUM_PHOTOMETRIC_FRACTION
        and safe_pass
        and secondary_distinct
        and all(item["font_size"] >= 54 for item in layout["overlays"])
    )
    receipt = {
        "schema_version": "1.0.0",
        "scope": "HOOK_003_STATIC_GEOMETRY_DIAGNOSTIC_ONLY",
        "status": (
            "PASS_GEOMETRY_PROPOSAL_NO_RENDER_AUTHORITY"
            if passed else "FAIL_GEOMETRY_BLOCK_RENDER"
        ),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "identity_sha256": identity,
        "input_bindings": input_bindings,
        "candidate_layout_sha256": sha(destination / "candidate-layout.json"),
        "common_geometry_sha256": sha(destination / "common-geometry.json"),
        "frame_verification_sha256": sha(destination / "frame-verification.json"),
        "metrics": {
            key: verification[key]
            for key in (
                "required_frame_count", "observed_frame_count",
                "failed_frame_numbers", "minimum_hull_fraction",
                "minimum_photometric_fraction",
                "minimum_corner_clearance_pixels",
            )
        },
        "font": {
            "path": str(font), "sha256": sha(font), "size": FONT_SIZE,
            "minimum_allowed_size": 54,
        },
        "copy": list(TOKENS),
        "copy_or_font_changed": False,
        "safe_area_pass": safe_pass,
        "secondary_panel_distinct": secondary_distinct,
        "render_performed": False,
        "extraction_performed": False,
        "new_tts_calls": 0,
        "api_calls": 0,
        "technical_cost_brl": 0,
        "queue_authorized": False,
        "production_authorized": False,
        "publication_authorized": False,
        "limitations": [
            "Convex-hull containment is necessary, not perceptual or semantic approval.",
            "A static common region prevents protrusion but does not prove visually convincing paper tracking.",
            "No overlay frame or MP4 was rendered; independent review remains mandatory before a proof render.",
        ],
    }
    save_new(destination / "receipt.json", receipt)
    if not passed:
        raise PermissionError("derived layout failed the unchanged full-span geometry policy")
    print(json.dumps(receipt, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
