[CmdletBinding()]
param(
    [string]$TaskName = 'HeroEngine-Phase5-CentralManager',
    [string]$TokenPath = '',
    [switch]$StartNow
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$runner = Join-Path $PSScriptRoot 'start_phase5_manager.ps1'
$powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$principalUser = if ($env:USERDOMAIN) { "$env:USERDOMAIN\$env:USERNAME" } else { $env:USERNAME }
$bootstrapLog = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'HeroEngine\manager-task-bootstrap.log'
if ([string]::IsNullOrWhiteSpace($TokenPath)) {
    $watcherReceipt = Join-Path $projectRoot 'output\runtime\gestor-central\oauth-reconsent-watcher.json'
    if (Test-Path -LiteralPath $watcherReceipt -PathType Leaf) {
        try {
            $TokenPath = [string](Get-Content -LiteralPath $watcherReceipt -Raw | ConvertFrom-Json).destination_path
        }
        catch {
            $TokenPath = ''
        }
    }
    if ([string]::IsNullOrWhiteSpace($TokenPath)) {
        $TokenPath = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'HeroEngine\secrets\youtube-heroverse-token.json'
    }
}
if (-not (Test-Path -LiteralPath $TokenPath -PathType Leaf)) {
    throw 'External YouTube token path is unavailable.'
}
$tokenPath = (Resolve-Path -LiteralPath $TokenPath).Path
if ($tokenPath.StartsWith($projectRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Credential path must remain outside the project workspace.'
}

if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) {
    throw "Manager runner is unavailable: $runner"
}

$escapedRunner = $runner.Replace("'", "''")
$escapedBootstrapLog = $bootstrapLog.Replace("'", "''")
$escapedBootstrapDir = (Split-Path -Parent $bootstrapLog).Replace("'", "''")
$escapedTokenPath = $tokenPath.Replace("'", "''")
$bootstrapCommand = "`$ErrorActionPreference='Continue'; `$env:HERO_YT_TOKEN_PATH='$escapedTokenPath'; `$env:HERO_MANAGER_BOOTSTRAP_LOG='$escapedBootstrapLog'; New-Item -ItemType Directory -Path '$escapedBootstrapDir' -Force | Out-Null; Add-Content -LiteralPath '$escapedBootstrapLog' -Value ('START ' + [DateTime]::UtcNow.ToString('o') + ' runner_exists=' + (Test-Path -LiteralPath '$escapedRunner') + ' language=' + `$ExecutionContext.SessionState.LanguageMode + ' policy=' + (Get-ExecutionPolicy)); & '$escapedRunner'; `$code=`$LASTEXITCODE; Add-Content -LiteralPath '$escapedBootstrapLog' -Value ('EXIT ' + `$code); exit `$code"
$encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($bootstrapCommand))
$action = New-ScheduledTaskAction `
    -Execute $powershellExe `
    -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand $encodedCommand"
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $principalUser
$principal = New-ScheduledTaskPrincipal -UserId $principalUser -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet `
    -Priority 5 `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero)

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Description 'HeroVerse Phase 5 zero-cost Central Manager; OS lock prevents duplicate managers.' `
    -Force | Out-Null

if ($StartNow) {
    Start-ScheduledTask -TaskName $TaskName
}

$task = Get-ScheduledTask -TaskName $TaskName
$receipt = [ordered]@{
    schema_version = '1.0.0'
    receipt_id = 'phase5-manager-autostart-v1'
    task_name = $task.TaskName
    status = [string]$task.State
    user = $principalUser
    trigger = 'AT_LOGON'
    multiple_instances = 'IGNORE_NEW'
    restart_count = 3
    execution_time_limit_seconds = 0
    runner_path = $runner
    runner_sha256 = (Get-FileHash -LiteralPath $runner -Algorithm SHA256).Hash.ToLowerInvariant()
    action_encoding = 'POWERSHELL_UTF16LE_BASE64'
    bootstrap_log = $bootstrapLog
    technical_cost_brl = 0
    token_path_outside_workspace = $true
    start_requested = [bool]$StartNow
    installed_at = [DateTime]::UtcNow.ToString('o')
    validation_method = 'Get-ScheduledTask'
}
$receiptPath = Join-Path $projectRoot 'output\runtime\gestor-central\autostart-receipt.json'
New-Item -ItemType Directory -Path (Split-Path -Parent $receiptPath) -Force | Out-Null
$receipt | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding utf8
$receipt | ConvertTo-Json
