"""Audit one isolated PocketSphinx install without processing target audio."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hero_engine.phase6_pocketsphinx_alignment import dictionary_coverage


VERSION = "phase6-pocketsphinx-isolated-install-proof-v1"
WHEEL_NAME = "pocketsphinx-5.0.4-cp312-cp312-win_amd64.whl"
WHEEL_SHA = "fd4f9bf9e3643ab00dd7978b64f34876189f4720231636b5185e8e8589c49e16"
WHEEL_BYTES = 29_061_044
UPLOAD_TIME = "2025-01-10T16:56:57.538628Z"
CAPTIONS = Path("output/qa/phase6/diagnostics/narration-caption-chunks-v2/3ddd6d1db0f753c02ea2fdf8.json")
CAPTIONS_SHA = "3ddd6d1db0f753c02ea2fdf8611c15962a01dc6bfa1cdb6287f5e2dd14f588f4"
TOOL = Path("output/qa/phase6/isolated-tools/pocketsphinx-5.0.4")
SCHEMA = Path("schemas/phase6_pocketsphinx_install_receipt.schema.json")
OUTPUT = Path("output/qa/phase6/diagnostics/pocketsphinx-isolated-install-v1")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def binding(path: Path, *, display: str | None = None) -> dict[str, object]:
    if not path.is_file():
        raise FileNotFoundError(path)
    return {"path": display or path.as_posix(), "sha256": sha(path), "bytes": path.stat().st_size}


def canonical(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def tree_binding(root: Path) -> tuple[list[dict[str, object]], str]:
    rows = [binding(path, display=path.relative_to(root).as_posix())
            for path in sorted(root.rglob("*")) if path.is_file()]
    return rows, "sha256:" + hashlib.sha256(canonical(rows)).hexdigest()


def normalized_lf(path: Path) -> bytes:
    return path.read_bytes().replace(b"\r\n", b"\n")


def smoke(isolated_python: Path) -> dict[str, object]:
    code = r'''import importlib.metadata, importlib.util, json, pathlib, platform, sys
import pocketsphinx
d = pocketsphinx.Decoder()
print(json.dumps({
    "version": importlib.metadata.version("pocketsphinx"),
    "python_version": platform.python_version(),
    "machine": platform.machine(),
    "python_executable": str(pathlib.Path(sys.executable).resolve()),
    "module_path": str(pathlib.Path(pocketsphinx.__file__).resolve()),
    "model_path": str(pathlib.Path(pocketsphinx.get_model_path()).resolve()),
    "dictionary_path": str(pathlib.Path(d.config["dict"]).resolve()),
    "sample_rate": int(d.config["samprate"]),
    "set_align_text": hasattr(d, "set_align_text"),
    "set_alignment": hasattr(d, "set_alignment"),
    "get_alignment": hasattr(d, "get_alignment"),
    "dictionary_lookup": d.lookup_word("truth"),
    "sounddevice_installed": importlib.util.find_spec("sounddevice") is not None,
}, sort_keys=True))'''
    env = dict(os.environ)
    env.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "NO_PROXY": "*", "no_proxy": "*"})
    result = subprocess.run([str(isolated_python), "-c", code], cwd=ROOT, env=env,
                            check=False, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(f"isolated Decoder smoke failed ({result.returncode}): {result.stderr[-2000:]}")
    lines = [line for line in result.stdout.splitlines() if line.strip().startswith("{")]
    if len(lines) != 1:
        raise RuntimeError("isolated Decoder smoke did not emit one JSON object")
    value = json.loads(lines[0])
    if (value["version"] != "5.0.4" or value["python_version"] != "3.12.14"
            or value["machine"].upper() not in {"AMD64", "X86_64"}
            or value["sample_rate"] != 16000 or value["sounddevice_installed"]
            or not all(value[key] for key in ("set_align_text", "set_alignment", "get_alignment", "dictionary_lookup"))):
        raise RuntimeError("isolated Decoder smoke contract differs")
    return value


def build(isolated_python: Path) -> dict[str, object]:
    wheel = ROOT / TOOL / "wheels" / WHEEL_NAME
    wheel_binding = binding(wheel, display=(TOOL / "wheels" / WHEEL_NAME).as_posix())
    if wheel_binding["sha256"] != "sha256:" + WHEEL_SHA or wheel_binding["bytes"] != WHEEL_BYTES:
        raise RuntimeError("wheel differs from PyPI SHA-256/size")
    metadata_path = ROOT / TOOL / "license-evidence" / "pypi-5.0.4.json"
    metadata = json.loads(metadata_path.read_bytes())
    releases = [item for item in metadata["urls"] if item["filename"] == WHEEL_NAME]
    if (len(releases) != 1 or releases[0]["digests"]["sha256"] != WHEEL_SHA
            or releases[0]["size"] != WHEEL_BYTES or releases[0]["upload_time_iso_8601"] != UPLOAD_TIME
            or metadata["info"]["requires_dist"] != ["sounddevice"]):
        raise RuntimeError("archived PyPI metadata differs")

    observed = smoke(isolated_python.resolve(strict=True))
    module = Path(observed["module_path"])
    package_root = module.parent
    model_root = Path(observed["model_path"])
    dictionary = Path(observed["dictionary_path"])
    model_files, model_tree_sha = tree_binding(model_root)
    implementation_paths = [module, *sorted(package_root.glob("_pocketsphinx*.pyd")),
                            package_root.parent / "pocketsphinx-5.0.4.dist-info" / "METADATA",
                            package_root.parent / "pocketsphinx-5.0.4.dist-info" / "RECORD"]
    implementation_files = [binding(path, display=str(path.resolve())) for path in implementation_paths]

    caption_path = ROOT / CAPTIONS
    if sha(caption_path) != "sha256:" + CAPTIONS_SHA:
        raise RuntimeError("caption source hash differs")
    captions = json.loads(caption_path.read_bytes())
    dictionary_words = {line.split(maxsplit=1)[0].lower() for line in dictionary.read_text(encoding="utf-8").splitlines() if line.strip()}
    coverage = dictionary_coverage([cue["text"] for cue in captions["cues"]], dictionary_words)
    if coverage["status"] != "PASS":
        raise RuntimeError("current frozen copy is outside bundled dictionary")
    tag_dictionary = ROOT / TOOL / "license-evidence" / "pocketsphinx-v5.0.4-cmudict-en-us.dict"
    tag_normalized = "sha256:" + hashlib.sha256(normalized_lf(tag_dictionary)).hexdigest()
    matches_tag = normalized_lf(dictionary) == normalized_lf(tag_dictionary)
    if not matches_tag:
        raise RuntimeError("installed dictionary differs from tag beyond CRLF conversion")

    license_specs = [
        ("PocketSphinx code/distribution", "BSD-like CMU", "https://raw.githubusercontent.com/cmusphinx/pocketsphinx/v5.0.4/LICENSE", "pocketsphinx-v5.0.4-LICENSE"),
        ("Bundled US-English acoustic model", "BSD-like Alpha Cephei", "https://raw.githubusercontent.com/cmusphinx/pocketsphinx/v5.0.4/model/en-us/en-us/README", "pocketsphinx-v5.0.4-en-us-model-README"),
        ("CMUdict", "BSD-like CMU", "https://raw.githubusercontent.com/cmusphinx/cmudict/master/LICENSE", "cmudict-master-LICENSE"),
        ("PyPI release metadata", "Metadata/provenance", "https://pypi.org/pypi/pocketsphinx/5.0.4/json", "pypi-5.0.4.json"),
    ]
    licenses = [{"subject": subject, "license": license_name, "url": url,
                 "file": binding(ROOT / TOOL / "license-evidence" / filename,
                                 display=(TOOL / "license-evidence" / filename).as_posix())}
                for subject, license_name, url, filename in license_specs]
    if normalized_lf(package_root.parent / "pocketsphinx-5.0.4.dist-info" / "licenses" / "LICENSE") != normalized_lf(ROOT / TOOL / "license-evidence" / "pocketsphinx-v5.0.4-LICENSE"):
        raise RuntimeError("installed distribution license differs from tag")
    if normalized_lf(model_root / "en-us" / "en-us" / "README") != normalized_lf(ROOT / TOOL / "license-evidence" / "pocketsphinx-v5.0.4-en-us-model-README"):
        raise RuntimeError("installed acoustic model license differs from tag")

    created = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    identity = {"version": VERSION, "created_at": created, "wheel": wheel_binding,
                "python": observed["python_executable"], "model_tree_sha256": model_tree_sha,
                "caption_sha256": "sha256:" + CAPTIONS_SHA}
    installation_id = "pocketsphinx-install-" + hashlib.sha256(canonical(identity)).hexdigest()[:24]
    authority = {key: False for key in ("calibrated_alignment", "human_gold_standard", "quality_approved",
        "render_authorized", "retiming_authorized", "queue_authorized", "publication_authorized")}
    coverage.update({"source": CAPTIONS.as_posix(), "source_sha256": "sha256:" + CAPTIONS_SHA,
        "hyphen_policy": "ASCII/Unicode apostrophes preserved; hyphenated copy splits into two CMUdict tokens with original character offsets retained.",
        "tag_dictionary_normalized_lf_sha256": tag_normalized,
        "installed_dictionary_sha256": sha(dictionary), "tag_matches_after_lf_normalization": matches_tag})
    receipt = {
        "schema_version": "1.0.0", "kind": "POCKETSPHINX_ISOLATED_INSTALL_RECEIPT",
        "installation_id": installation_id,
        "status": "INSTALLED_SMOKE_PASS_DICTIONARY_COVERAGE_PASS_ESTIMATE_ONLY_UNCALIBRATED",
        "created_at": created,
        "package": {"name": "pocketsphinx", "version": "5.0.4", "wheel": wheel_binding,
            "upload_time_iso_8601": UPLOAD_TIME, "declared_dependencies": ["sounddevice"],
            "dependency_scope": "sounddevice deliberately not installed; Decoder/API smoke passes and microphone LiveSpeech is outside scope."},
        "isolated_environment": {"python_executable": observed["python_executable"],
            "python_version": observed["python_version"], "platform": "win-amd64",
            "main_project_venv_modified": False, "sounddevice_installed": False},
        "model": {"path": str(model_root), "sample_rate": 16000, "model_files": model_files,
            "model_tree_sha256": model_tree_sha, "implementation_files": implementation_files},
        "dictionary_coverage": coverage, "license_evidence": licenses,
        "source_bindings": [binding(ROOT / path, display=path.as_posix()) for path in (
            CAPTIONS, SCHEMA, Path("hero_engine/phase6_pocketsphinx_alignment.py"),
            Path("scripts/prove_phase6_pocketsphinx_install.py"))],
        "smoke": {"status": "PASS", "decoder_initialized": True,
            "set_align_text": observed["set_align_text"], "set_alignment": observed["set_alignment"],
            "get_alignment": observed["get_alignment"], "dictionary_lookup": observed["dictionary_lookup"],
            "audio_processed": False, "target_alignment_count": 0},
        "constraints": {"adapter_output_status": "ESTIMATE_UNCALIBRATED", "reference_text_supplied": True,
            "source_rate": 24000, "aligner_rate": 16000,
            "mapping": "PocketSphinx 100 Hz frame * 160 samples at 16 kHz maps exactly to frame * 240 samples at 24 kHz; half-open intervals.",
            "calibration_attached": False, "independent_method_attached": False,
            "production_capability_claimed": False,
            "limitations": ["PocketSphinx is not state of the art.",
                "Forced reference text proves no lexical identity, pronunciation or perceptual quality.",
                "LIVE policy, non-target holdout calibration and an independent method remain mandatory."]},
        "authority": authority, "technical_cost_brl": 0,
    }
    schema = json.loads((ROOT / SCHEMA).read_bytes())
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--isolated-python", type=Path, required=True)
    args = parser.parse_args()
    receipt = build(args.isolated_python)
    folder = ROOT / OUTPUT / receipt["installation_id"]
    folder.mkdir(parents=True, exist_ok=False)
    raw = json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8") + b"\n"
    receipt_path = folder / "receipt.json"
    receipt_path.write_bytes(raw)
    digest = "sha256:" + hashlib.sha256(raw).hexdigest()
    (folder / "receipt.sha256").write_text(digest + "\n", encoding="ascii")
    print(json.dumps({"status": receipt["status"], "receipt": receipt_path.relative_to(ROOT).as_posix(),
                      "sha256": digest, "installation_id": receipt["installation_id"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
