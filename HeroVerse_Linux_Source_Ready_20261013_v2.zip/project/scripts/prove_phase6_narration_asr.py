"""Independent local ASR of exactly three diagnostic WAVs; never production QA.

Network is permitted ONLY for archival of the three official license documents
before inference. Inference uses pinned existing files and blocked sockets.
"""
from __future__ import annotations

import contextlib
import importlib.metadata
import json
import math
import numbers
import os
import re
import shutil
import socket
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.prove_phase6_narration_units import COPY, UNITS, RAM_RESERVE, MIN_DISK_RESERVE, inspect_wav, memory_available, save_new, sha

VOICE_PROOF = "output/qa/phase6/diagnostics/narration-unit-proof-20260906T044549920068Z"
RECEIPT_HASH = "sha256:d47bb7ace0942d5ba5c624d7074d9a22962ee8234ec0ba3a3b6e2f01604ae99c"
MODEL = Path("C:/Users/mathe/.cache/huggingface/hub/models--Systran--faster-whisper-base.en/snapshots/3d3d5dee26484f91867d81cb899cfcf72b96be6c")
MODEL_HASHES = {
    "model.bin": "sha256:2a166925539a16005f14ff328359f9b9adb9dc4fb631bb3b227526862e93e2ef",
    "config.json": "sha256:f3bc3821e9fc76a27bae538e11ae5b677dcdd352b4600429ce7951d398569aeb",
    "tokenizer.json": "sha256:929c5252409436dce1b38a75d1abbcb5e132d170d8e324e4e04ed915fa2d22df",
    "vocabulary.txt": "sha256:ff77588746d3a2595d32ab5b69ffd7b95ce2441ac57533cb66fc3eb575a115cf",
}
LICENSE_SOURCES = (
    ("systran-model-card.html", "https://huggingface.co/Systran/faster-whisper-base.en", (b"license", b"mit", b"openai/whisper-base.en")),
    ("openai-whisper-readme.md", "https://raw.githubusercontent.com/openai/whisper/main/README.md", (b"code and model weights", b"mit license")),
    ("openai-whisper-license.txt", "https://raw.githubusercontent.com/openai/whisper/main/LICENSE", (b"mit license", b"permission is hereby granted")),
)
OFFLINE_ENV = {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "HF_HUB_DISABLE_TELEMETRY": "1",
               "TOKENIZERS_PARALLELISM": "false", "OMP_NUM_THREADS": "2", "MKL_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
ASR_PARAMS = {"language": "en", "task": "transcribe", "beam_size": 5, "temperature": 0.0,
              "word_timestamps": True, "vad_filter": False, "condition_on_previous_text": False,
              "initial_prompt": None, "hotwords": None}


def archive_licenses(destination, fetcher=None):
    """Only allowlisted document URLs; no models, inference endpoint or credentials."""
    folder = destination / "license-evidence"
    folder.mkdir(exist_ok=False)
    records = []
    fetch = fetcher or urllib.request.urlopen
    for filename, url, required in LICENSE_SOURCES:
        request = urllib.request.Request(url, headers={"User-Agent": "HeroVerse-local-license-audit/1.0"})
        with fetch(request, timeout=25) as response:
            final_url = response.geturl()
            if not final_url.startswith(("https://huggingface.co/", "https://raw.githubusercontent.com/")):
                raise PermissionError("license document redirected outside official allowlist")
            raw = response.read(1024*1024+1)
            if len(raw) > 1024*1024 or response.status != 200 or not all(value in raw.lower() for value in required):
                raise PermissionError("official license document missing or divergent")
        path = folder / filename
        with path.open("xb") as stream:
            stream.write(raw)
        records.append({"requested_url": url, "resolved_url": final_url, "retrieved_at": datetime.now(timezone.utc).isoformat(),
                        "path": path.relative_to(destination).as_posix(), "sha256": sha(path), "bytes": len(raw), "http_status": 200})
    save_new(folder / "receipt.json", {"status": "OFFICIAL_LICENSE_DOCUMENTS_ARCHIVED", "license": "MIT",
              "scope": "Systran conversion model card plus upstream explicit code-and-model-weight license", "sources": records,
              "model_downloads": 0, "inference_calls": 0, "technical_cost_brl": 0})
    return records


def check_capacity(available_ram, free_disk, model_size):
    if any(type(v) is not int or v <= 0 for v in (available_ram, free_disk, model_size)):
        raise ValueError("capacity values must be positive integers")
    # CPU/int8 inference short samples: 3x pinned file plus runtime and reserve.
    estimate = model_size*3 + 256*1024**2
    required = estimate + RAM_RESERVE
    disk_estimate = 16*1024**2
    blockers = []
    if available_ram < required:
        blockers.append("ASR_DIAGNOSTIC_RAM_ESTIMATE_AND_RESERVE_NOT_MET")
    if free_disk-disk_estimate < MIN_DISK_RESERVE:
        blockers.append("ASR_DIAGNOSTIC_FIVE_GIB_DISK_RESERVE_NOT_MET")
    return {"status": "PASS" if not blockers else "BLOCKED", "blocking_reasons": blockers,
            "available_ram_bytes": available_ram, "estimated_peak_additional_ram_bytes": estimate,
            "required_available_ram_bytes": required, "ram_reserve_bytes": RAM_RESERVE,
            "ram_basis": "3*model.bin bytes +256MiB runtime +256MiB reserve; estimate not measured peak",
            "free_disk_bytes": free_disk, "estimated_peak_new_disk_bytes": disk_estimate, "disk_reserve_bytes": MIN_DISK_RESERVE}


@contextlib.contextmanager
def offline_inference():
    attempts = []
    def blocked(*args, **kwargs):
        attempts.append("NETWORK_ATTEMPT_BLOCKED")
        raise PermissionError("network forbidden during local ASR")
    with patch.dict(os.environ, OFFLINE_ENV), patch.object(socket, "create_connection", blocked), patch.object(socket.socket, "connect", blocked), patch.object(socket.socket, "connect_ex", blocked):
        yield attempts


def normalized_words(text):
    return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", text.lower().replace("’", "'"))


def compare_words(reference, recognized):
    """Post-recognition comparison only; expected words never enter the model."""
    ref, hyp = normalized_words(reference), normalized_words(recognized)
    table = [[0]*(len(hyp)+1) for _ in range(len(ref)+1)]
    for i in range(len(ref)+1): table[i][0] = i
    for j in range(len(hyp)+1): table[0][j] = j
    for i, expected in enumerate(ref,1):
        for j, observed in enumerate(hyp,1):
            table[i][j] = min(table[i-1][j]+1,table[i][j-1]+1,table[i-1][j-1]+(expected != observed))
    edits=[]
    i,j=len(ref),len(hyp)
    while i or j:
        if i and j and ref[i-1] == hyp[j-1] and table[i][j] == table[i-1][j-1]:
            i-=1; j-=1
        elif i and j and table[i][j] == table[i-1][j-1]+1:
            edits.append({"operation":"SUBSTITUTION","reference_index":i-1,"recognized_index":j-1,"reference":ref[i-1],"recognized":hyp[j-1]});i-=1;j-=1
        elif i and table[i][j] == table[i-1][j]+1:
            edits.append({"operation":"DELETION","reference_index":i-1,"recognized_index":None,"reference":ref[i-1],"recognized":None});i-=1
        else:
            edits.append({"operation":"INSERTION","reference_index":None,"recognized_index":j-1,"reference":None,"recognized":hyp[j-1]});j-=1
    edits.reverse()
    return {"reference_words":ref,"recognized_words":hyp,"reference_word_count":len(ref),"recognized_word_count":len(hyp),
            "edit_count":table[-1][-1],"wer":round(table[-1][-1]/len(ref),6) if ref else None,"edits":edits,
            "status":"ALL_NORMALIZED_WORDS_MATCH" if ref == hyp else "TRANSCRIPTION_MISMATCH_NEEDS_REVIEW",
            "asr_agreement_is_human_listening":False,"model_prompt_contained_expected_text":False}


def transcribe_sample(model, wav_path, unit_id, duration_ms):
    started=time.perf_counter()
    segments, info=model.transcribe(str(wav_path), **ASR_PARAMS)
    rows=[]
    for segment in segments:
        words=[]
        for word in segment.words or []:
            values=(word.start,word.end,word.probability)
            if any(isinstance(x,bool) or not isinstance(x,numbers.Real) or not math.isfinite(float(x)) for x in values) or word.end < word.start or not 0<=word.probability<=1:
                raise ValueError("invalid ASR word timestamps/confidence")
            words.append({"word":str(word.word),"start_ms":round(float(word.start)*1000,6),"end_ms":round(float(word.end)*1000,6),
                          "probability":round(float(word.probability),6),"evidence_class":"ASR_ESTIMATED_NOT_WORD_TRUTH",
                          "outside_wav_duration":bool(word.start<0 or word.end*1000>duration_ms+20)})
        rows.append({"start_ms":round(float(segment.start)*1000,6),"end_ms":round(float(segment.end)*1000,6),"text":str(segment.text),"words":words,
                     "average_log_probability":float(segment.avg_logprob),"no_speech_probability":float(segment.no_speech_prob)})
    recognized=" ".join(r["text"].strip() for r in rows).strip()
    if not recognized or not any(r["words"] for r in rows):
        raise ValueError("no transcript/word timestamps from independent local ASR")
    return {"unit_id":unit_id,"wav_sha256":sha(wav_path),"recognized_text":recognized,"segments":rows,
            "language":str(info.language),"language_probability":float(info.language_probability),"duration_ms_reported_by_asr":round(float(info.duration)*1000,6),
            "parameters":ASR_PARAMS,"inference_seconds":round(time.perf_counter()-started,6),"perceptual_quality_status":"NOT_REVIEWED",
            "word_timing_status":"MODEL_ESTIMATES_REQUIRING_ACOUSTIC_CROSSCHECK"}


def main():
    started=time.perf_counter()
    transcription_attempts=0
    parent=ROOT/"output/qa/phase6/diagnostics"
    if parent.resolve()!=parent: raise PermissionError("diagnostic namespace redirected")
    now=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination=parent/("narration-asr-proof-"+now)
    destination.mkdir(exist_ok=False)
    try:
        license_sources=archive_licenses(destination)
        proof=ROOT/VOICE_PROOF
        if sha(proof/"receipt.json")!=RECEIPT_HASH: raise PermissionError("exact voice diagnostic receipt differs")
        receipt=json.loads((proof/"receipt.json").read_text(encoding="utf-8"))
        if tuple(r["unit_id"] for r in receipt["records"])!=UNITS: raise PermissionError("ASR diagnostic scope differs")
        wavs=[]
        for record,expected_text in zip(receipt["records"],COPY,strict=True):
            wav=(proof/"staged"/record["wav"]).resolve(strict=True)
            if not wav.is_relative_to((proof/"staged").resolve()) or record["text"]!=expected_text:
                raise PermissionError("source copy/path drift")
            measured,_=inspect_wav(wav)
            if measured!=record["measured"]: raise PermissionError("source WAV differs from measured receipt")
            wavs.append((record["unit_id"],wav,measured["duration_ms"]))
        model_bindings=[]
        for name,expected in MODEL_HASHES.items():
            path=MODEL/name
            if sha(path)!=expected: raise PermissionError("cached ASR model differs; download forbidden")
            model_bindings.append({"path":str(path),"sha256":expected,"bytes":path.stat().st_size})
        memory=memory_available()
        capacity=check_capacity(memory["available_bytes"],shutil.disk_usage(parent).free,(MODEL/"model.bin").stat().st_size)
        preflight={"scope":"LOCAL_INDEPENDENT_ASR_THREE_DIAGNOSTIC_WAVS_ONLY",**capacity,"created_at":now,
                   "model_snapshot":str(MODEL),"model_bindings":model_bindings,"license_sources":license_sources,
                   "source_voice_proof":VOICE_PROOF,"source_voice_receipt_sha256":RECEIPT_HASH,
                   "offline_environment":OFFLINE_ENV,"socket_policy":"BLOCK_ALL_CONNECTIONS_DURING_INFERENCE",
                   "model_parameters":{"device":"cpu","compute_type":"int8","cpu_threads":2,"num_workers":1,"local_files_only":True},
                   "asr_parameters":ASR_PARAMS,"maximum_transcriptions":3,"packages":{name:importlib.metadata.version(name) for name in ("faster-whisper","ctranslate2","tokenizers","av")},
                   "runner_sha256":sha(Path(__file__)),"memory":memory,"production_authorized":False,"publication_authorized":False,"technical_cost_brl":0}
        save_new(destination/"preflight.json",preflight)
        if capacity["status"]!="PASS": raise PermissionError(";".join(capacity["blocking_reasons"]))
        print(json.dumps({"event":"ASR_PREFLIGHT_PASS","path":str(destination),"available_ram_bytes":memory["available_bytes"]}),flush=True)
        observations=[]
        with offline_inference() as attempts:
            from faster_whisper import WhisperModel
            model=WhisperModel(str(MODEL),device="cpu",compute_type="int8",cpu_threads=2,num_workers=1,local_files_only=True)
            if memory_available()["available_bytes"]<RAM_RESERVE: raise PermissionError("RAM reserve lost after loading ASR")
            for unit_id,wav,duration in wavs:
                transcription_attempts+=1
                value=transcribe_sample(model,wav,unit_id,duration)
                save_new(destination/(unit_id+".asr.json"),value)
                observations.append(value)
                print(json.dumps({"event":"ASR_OBSERVATION_RECORDED","unit_id":unit_id,"text":value["recognized_text"]}),flush=True)
            del model
            if attempts: raise PermissionError("ASR attempted forbidden network connection")
        comparisons=[{"unit_id":row["unit_id"],**compare_words(reference,row["recognized_text"])} for row,reference in zip(observations,COPY,strict=True)]
        for unit_id,wav,duration in wavs:
            original=next(r for r in receipt["records"] if r["unit_id"]==unit_id)
            if sha(wav)!=original["measured"]["sha256"]: raise PermissionError("WAV drift during ASR")
        for name,expected in MODEL_HASHES.items():
            if sha(MODEL/name)!=expected: raise PermissionError("model drift during ASR")
        save_new(destination/"comparison.json",comparisons)
        artifacts={p.relative_to(destination).as_posix():sha(p) for p in destination.rglob("*") if p.is_file()}
        final={"scope":"THREE_DIAGNOSTIC_UTTERANCES_INDEPENDENT_ASR_ONLY","status":"OBSERVED_PENDING_INDEPENDENT_REVIEW",
               "preflight_sha256":sha(destination/"preflight.json"),"comparisons":comparisons,"artifact_bindings":artifacts,
               "actual_transcription_count":len(observations),"transcription_attempt_count":transcription_attempts,"inference_network_attempt_count":len(attempts),"weight_download_count":0,
               "license_document_requests":len(license_sources),"expected_text_prompted":False,"word_timestamps_are_estimates":True,
               "human_listening_performed":False,"perceptual_quality_approved":False,"retiming_authorized":False,
               "production_authorized":False,"publication_authorized":False,"technical_cost_brl":0,"wall_seconds":round(time.perf_counter()-started,6),
               "limitations":["ASR agreement does not establish phonetic perfection, prosody, preference or human review",
                   "Whisper word positions are model estimates, not forced-alignment truth; crosscheck against signal",
                   "No retiming, new synthesis, video render, production queue or final audio QA"]}
        save_new(destination/"receipt.json",final)
        print(json.dumps({"event":"ASR_PROOF_RECORDED","path":str(destination),"receipt_sha256":sha(destination/"receipt.json"),"comparisons":comparisons}),flush=True)
    except BaseException as exc:
        save_new(destination/"failure.json",{"status":"FAILED_OR_BLOCKED_NOT_CONSUMABLE","error":f"{type(exc).__name__}: {exc}",
                   "transcription_attempt_count":transcription_attempts,
                   "artifacts_preserved":{p.relative_to(destination).as_posix():sha(p) for p in destination.rglob("*") if p.is_file()},
                   "production_authorized":False,"publication_authorized":False,"technical_cost_brl":0})
        print(json.dumps({"event":"ASR_PROOF_BLOCKED","path":str(destination),"error":str(exc)}),flush=True)
        raise


if __name__=="__main__": main()
