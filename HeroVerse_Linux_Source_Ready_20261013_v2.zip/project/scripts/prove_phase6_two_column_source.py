"""Render only the corrected 36.4s exercise with the exact existing narration.

No API, TTS, production queue, original artifact overwrite or release action.
The source proof has an independent capacity preflight and repeat-safe outputs.
Hashes detect drift; this is not filesystem immutability or library admission.
"""
from __future__ import annotations

import hashlib
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
import wave
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from jsonschema import Draft202012Validator
import numpy as np
from hero_engine.phase6_two_column_recipe import (
    build_two_column_plan, canonical_sha, compile_two_column_filters, inspect_two_column_layout,
)
from hero_engine.render_creative_v2_phase5 import _font, FFMPEG

BASE = ROOT / "output/production/phase6/video-002"
VOICE = BASE / "audio/manifests/voice-phase6-60322e8ee7586d38077e.json"
PINNED_VOICE = "sha256:f28f2dcd864ff72bce873f892e9912185f3034bc2613c07fd0712f17a4bec6b2"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def save_new(path: Path, value) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(payload)


def run(command: list[str], *, timeout: int = 45):
    return subprocess.run(command, check=True, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=timeout)


def validate(name: str, value) -> None:
    schema = read(ROOT / "schemas" / name)
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(value)


def main() -> None:
    started = time.perf_counter()
    plan_path = BASE / "production/take_plan.json"
    bible_path = BASE / "production/channel_style_bible.json"
    script_path = BASE / "preproduction/narrative_script.json"
    source = read(plan_path)
    bible = read(bible_path)
    validate("take_plan.schema.json", source)
    validate("visual_continuity_bible.schema.json", bible)
    plan = build_two_column_plan(source)
    validate("phase6_two_column_source_plan.schema.json", plan)
    if source["style_bible_id"] != bible["style_bible_id"] or source["channel_id"] != bible["channel_id"]:
        raise PermissionError("source and Bible identity differ")
    if bible["typography"]["minimum_sizes"]["1920x1080"] != 54 or bible["palette"]["locked_hex"] != ["#081827", "#D7A94A", "#E8EDF2", "#2C5364"]:
        raise PermissionError("recipe no longer agrees with the frozen Bible")
    if sha(VOICE) != PINNED_VOICE:
        raise PermissionError("historical voice manifest changed")
    voice = read(VOICE)
    validate("voice_render_manifest.schema.json", voice)
    if voice["take_plan"]["sha256"] != sha(plan_path) or voice["narrative_script"]["sha256"] != sha(script_path):
        raise PermissionError("existing speech is not bound to the exact plan/script")
    if voice["video_id"] != source["video_id"] or voice["status"] != "COMPLETE":
        raise PermissionError("wrong or incomplete historical voice")
    if voice["voice_id"] != "am_onyx" or voice["model_hash"] != "sha256:f3a290d384fbb27966d462905c71a46cef9e5fd00516b40df32a0b4afe77ac96":
        raise PermissionError("historical voice/model identity differs")
    by_take = {item["take_id"]: item for item in voice["takes"]}
    if len(by_take) != len(voice["takes"]):
        raise PermissionError("duplicate voice take")
    selected_voice = []
    for scene in plan["scenes"]:
        item = by_take[scene["take_id"]]
        path = Path(item["path"]).resolve(strict=True)
        if not path.is_relative_to((BASE / "audio/takes").resolve()):
            raise PermissionError("voice source outside the immutable take directory")
        if item["text"] != scene["narration"] or sha(path) != item["content_hash"]:
            raise PermissionError("voice content or copy drift")
        slot = scene["end_ms"] - scene["start_ms"]
        with wave.open(str(path), "rb") as wav:
            measured = {"frames": wav.getnframes(), "sample_rate": wav.getframerate(),
                        "channels": wav.getnchannels(), "sample_width": wav.getsampwidth()}
            samples = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float64)
        peak = float(np.max(np.abs(samples))/32768) if len(samples) else math.inf
        if (measured["frames"] != item["frame_count"] or measured["sample_rate"] != 24000
                or measured["channels"] != 1 or measured["sample_width"] != 2
                or measured["frames"] * 1000 > slot * measured["sample_rate"]
                or item["timeline_slot_ms"] != slot or item["speed"] != 1.06
                or item["fits_timeline_slot"] is not True or item["clipping"] is not False
                or peak >= 0.99):
            raise PermissionError("existing WAV format, duration or slot drift")
        selected_voice.append({"take_id": scene["take_id"], "path": str(path),
                               "sha256": sha(path), "slot_ms": slot, "speed": item["speed"],
                               "measured_peak_linear": peak, **measured})

    font = _font().resolve(strict=True)
    layouts = [inspect_two_column_layout(s, font=font) for s in plan["scenes"]]
    ffmpeg = Path(FFMPEG).resolve(strict=True)
    ffprobe = ffmpeg.with_name("ffprobe.exe" if sys.platform == "win32" else "ffprobe")
    versions = {"ffmpeg": run([str(ffmpeg), "-version"]).stdout.splitlines()[0],
                "ffprobe": run([str(ffprobe), "-version"]).stdout.splitlines()[0]}
    filters_help = run([str(ffmpeg), "-hide_banner", "-h", "filter=drawtext"]).stdout
    if "textfile" not in filters_help or "expansion" not in filters_help:
        raise PermissionError("local FFmpeg lacks the required drawtext recipe")
    # Worst-case rate cap, intermediate allowance, PCM audio and frame samples.
    peak = math.ceil((8_000_000/8 * plan["duration_ms"]/1000) * 2.5
                     + 24_000*2*plan["duration_ms"]/1000 + 64*1024**2)
    reserve = 5*1024**3
    parent = ROOT / "output/qa/phase6/diagnostics"
    parent.mkdir(parents=True, exist_ok=True)
    if parent.resolve() != parent.absolute():
        raise PermissionError("redirected diagnostic output directory")
    with tempfile.TemporaryDirectory(prefix="two-column-write-probe-", dir=parent) as probe:
        probe_file = Path(probe) / "probe"
        probe_file.write_bytes(b"local-source-preflight")
        if probe_file.read_bytes() != b"local-source-preflight":
            raise OSError("diagnostic destination write probe failed")
    free = shutil.disk_usage(parent).free
    if free - peak < reserve:
        raise PermissionError("source proof would violate the five-GiB free-space reserve")
    bindings = {str(path.relative_to(ROOT)): sha(path) for path in (
        plan_path, bible_path, script_path, VOICE, Path(__file__).resolve(),
        ROOT / "hero_engine/phase6_two_column_recipe.py", ROOT / "hero_engine/phase6_visual_recipe.py",
        ROOT / "schemas/phase6_two_column_source_plan.schema.json",
    )}
    identity = canonical_sha({"plan": plan, "inputs": bindings, "voice": selected_voice,
                              "font": sha(font), "ffmpeg": sha(ffmpeg), "ffprobe": sha(ffprobe)})
    destination = parent / ("two-column-proof-" + identity.split(":")[1][:24])
    # Existing proof (including failures) is never overwritten or silently retried.
    destination.mkdir(exist_ok=False)
    preflight = {
        "schema_version": "1.0.0", "scope": "LOCAL_SOURCE_PROOF_ONLY", "status": "PASS",
        "created_at": datetime.now(timezone.utc).isoformat(), "identity_sha256": identity,
        "source_plan_sha256": canonical_sha(plan), "input_bindings": bindings,
        "voice_reuse": selected_voice, "font": {"path": str(font), "sha256": sha(font)},
        "historical_voice_identity": {key: voice[key] for key in ("voice_id", "model", "model_hash", "voices_hash", "adapter_implementation")},
        "tools": versions, "free_bytes": free, "estimated_peak_bytes": peak,
        "reserve_bytes": reserve, "post_work_headroom_bytes": free-peak-reserve,
        "geometry_take_count": len(layouts), "capacity_fallback": "BLOCK_WITHOUT_COST",
        "queue_authorized": False, "publication_authorized": False, "technical_cost_brl": 0,
    }
    save_new(destination / "source-plan.json", plan)
    save_new(destination / "layouts.json", layouts)
    save_new(destination / "preflight.json", preflight)
    print(json.dumps({"event": "PREFLIGHT_PASS", "path": str(destination), "duration_ms": plan["duration_ms"], "wav_reused": len(selected_voice)}), flush=True)
    try:
        filters = compile_two_column_filters(plan, font=font, work_dir=destination / "text")
        graph_path = destination / "video-filters.txt"
        graph_path.write_text(",".join(filters), encoding="utf-8")
        seconds = plan["duration_ms"]/1000
        command = [str(ffmpeg), "-nostdin", "-n", "-hide_banner", "-loglevel", "error",
                   "-threads", "2", "-f", "lavfi", "-i", f"color=c=0x081827:s=1920x1080:r=30:d={seconds:.3f}"]
        for item in selected_voice:
            command += ["-i", item["path"]]
        audio_filters = [f"[{i}:a]apad,atrim=duration={item['slot_ms']/1000:.3f},asetpts=PTS-STARTPTS[a{i}]"
                         for i, item in enumerate(selected_voice, start=1)]
        audio_filters.append("".join(f"[a{i}]" for i in range(1, len(selected_voice)+1))
                             + f"concat=n={len(selected_voice)}:v=0:a=1[voice]")
        artifact = destination / "fact-forecast-source-proof.mp4"
        command += ["-filter_threads", "1", "-filter_complex_threads", "1", "-filter_complex", ";".join(audio_filters),
                    "-map", "0:v", "-map", "[voice]", "-filter_script:v", str(graph_path),
                    "-c:v", "libx264", "-threads", "2", "-preset", "fast", "-crf", "18",
                    "-maxrate", "8M", "-bufsize", "16M", "-c:a", "aac", "-b:a", "192k",
                    "-ar", "24000", "-frames:v", str(plan["duration_ms"]*30//1000),
                    "-t", f"{seconds:.3f}", "-movflags", "+faststart", str(artifact)]
        save_new(destination / "command.json", command)
        render_started = time.perf_counter()
        result = run(command, timeout=600)
        render_seconds = time.perf_counter()-render_started
        (destination / "ffmpeg.stderr.log").write_text(result.stderr, encoding="utf-8")
        probe = json.loads(run([str(ffprobe), "-v", "error", "-count_frames", "-show_streams", "-show_format", "-of", "json", str(artifact)]).stdout)
        video = next(s for s in probe["streams"] if s["codec_type"] == "video")
        audio = next(s for s in probe["streams"] if s["codec_type"] == "audio")
        if (video["width"], video["height"], video["r_frame_rate"], int(video["nb_read_frames"])) != (1920, 1080, "30/1", plan["duration_ms"]*30//1000):
            raise ValueError("rendered source dimensions, fps or frame count drift")
        if abs(float(probe["format"]["duration"])*1000-plan["duration_ms"]) > 50 or audio["sample_rate"] != "24000":
            raise ValueError("rendered source timing/audio drift")
        decoded_path = destination / "decoded-proof-audio.wav"
        run([str(ffmpeg), "-nostdin", "-n", "-v", "error", "-i", str(artifact), "-vn",
             "-ac", "1", "-ar", "24000", "-c:a", "pcm_s16le", str(decoded_path)])
        reference_parts = []
        for item in selected_voice:
            with wave.open(item["path"], "rb") as wav:
                original = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float64)
            slot_samples = item["slot_ms"]*24
            reference_parts.append(np.pad(original, (0, slot_samples-len(original))))
        reference = np.concatenate(reference_parts)
        with wave.open(str(decoded_path), "rb") as wav:
            decoded = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float64)
        if len(decoded) < len(reference):
            raise ValueError("published proof audio lost samples from the original timeline")
        correlation = float(np.corrcoef(reference, decoded[:len(reference)])[0, 1])
        peak_linear = float(np.max(np.abs(decoded))/32768)
        if not math.isfinite(correlation) or correlation < 0.995 or peak_linear >= 0.99:
            raise ValueError("decoded proof audio lost alignment/copy fidelity or clipped")
        audio_evidence = {"method": "ZERO_OFFSET_DECODED_PCM_VS_EXACT_WAV_PLUS_SLOT_SILENCE",
                          "correlation": correlation, "minimum_correlation": 0.995,
                          "peak_linear": peak_linear, "expected_samples": len(reference),
                          "decoded_samples": len(decoded), "decoded_sha256": sha(decoded_path),
                          "status": "PASS_SIGNAL_ALIGNMENT_NOT_PRONUNCIATION_OR_NATURALNESS"}
        frame_receipts = []
        for number, at in enumerate((1.0, 10.0, 13.5, 15.267, 15.333, 19.5, 21.667, 21.733, 27.0, 34.0), start=1):
            path = destination / f"frame-{number:02d}-at-{int(at*1000)}ms.png"
            run([str(ffmpeg), "-nostdin", "-n", "-v", "error", "-ss", str(at), "-i", str(artifact),
                 "-frames:v", "1", "-update", "1", str(path)])
            frame_receipts.append({"at_ms": int(at*1000), "path": str(path.relative_to(ROOT)), "sha256": sha(path)})
        for path, expected in bindings.items():
            if sha(ROOT / path) != expected:
                raise PermissionError("input changed during source proof")
        for item in selected_voice:
            if sha(Path(item["path"])) != item["sha256"]:
                raise PermissionError("voice changed during source proof")
        save_new(destination / "probe.json", probe)
        artifact_bindings = {str(path.relative_to(destination)): sha(path)
                             for path in destination.rglob("*") if path.is_file()}
        receipt = {
            "scope": "TWO_COLUMN_SOURCE_PROOF_NOT_RELEASE_QA", "status": "PRODUCED_PENDING_INDEPENDENT_REVIEW",
            "identity_sha256": identity, "preflight_sha256": sha(destination / "preflight.json"),
            "source_plan_sha256": sha(destination / "source-plan.json"),
            "artifact_path": str(artifact.relative_to(ROOT)), "artifact_sha256": sha(artifact),
            "duration_ms": plan["duration_ms"], "frame_count": int(video["nb_read_frames"]),
            "voice_reused_take_count": len(selected_voice), "new_tts_calls": 0,
            "audio_evidence": audio_evidence,
            "render_seconds": round(render_seconds, 6), "wall_seconds": round(time.perf_counter()-started, 6),
            "frames": frame_receipts, "input_bindings": bindings,
            "artifact_bindings": artifact_bindings,
            "technical_cost_brl": 0, "queue_authorized": False, "publication_authorized": False,
            "limitations": ["No music/mastering/release QA", "No production rights or source-library admission", "Not integrated with canonical media successor", "Diagnostic receipt/preflight not yet an admission schema", "Intentional graphic holds require context-aware temporal QA, not fabricated motion", "Original intra-sentence padding preserved: take013 1196ms, take015 1121ms, take020 1188ms; natural prosody NOT approved"],
        }
        save_new(destination / "receipt.json", receipt)
        print(json.dumps(receipt, ensure_ascii=False), flush=True)
    except Exception as exc:
        save_new(destination / "failure.json", {"error": f"{type(exc).__name__}: {exc}",
                  "publication_authorized": False, "technical_cost_brl": 0})
        raise


if __name__ == "__main__":
    main()
