"""Reproduce the take-002 null-overlay regression in an isolated QA directory.

This is one diagnostic frame, never a render, release or publication approval.
The current TakePlan, source bytes and immutable capacity must all verify first.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hero_engine.phase6_media import PHASE6_SEGMENT_RENDERER, _origin
from hero_engine.production_capacity import verify_phase6_capacity_receipt
from hero_engine.render_creative_v2_phase5 import FFMPEG, _font, _visual_filters


def sha(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    base = ROOT / "output/production/phase6/video-002"
    plan_path = base / "production/take_plan.json"
    treatment_path = base / "production/creative_treatment_plan.json"
    allocation_path = base / "production/asset_allocation.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    treatment = json.loads(treatment_path.read_text(encoding="utf-8"))
    allocation = json.loads(allocation_path.read_text(encoding="utf-8"))
    voice = json.loads((base / "audio/voice_render_manifest.json").read_text(encoding="utf-8"))
    capacity = voice["capacity_preflight"]
    verify_phase6_capacity_receipt(
        ROOT, receipt_path=ROOT / capacity["receipt_path"],
        expected_receipt_id=capacity["receipt_id"],
        expected_sha256=capacity["sha256"], require_pass=True,
    )
    take = next(item for item in plan["takes"] if item["take_id"] == "take-002")
    direction = next(item for item in treatment["takes"] if item["take_id"] == take["take_id"])
    asset = next(item for item in allocation["takes"] if item["take_id"] == take["take_id"])
    assert take["on_screen_text"] is None and direction["treatment"] == "HOOK_QUESTION"
    source, start, end = _origin(ROOT, take["asset_origin"])
    assert sha(source) == asset["content_hash"] and end - start >= 2
    directory = ROOT / "output/qa/phase6/diagnostics/null-overlay-v2"
    directory.mkdir(parents=True, exist_ok=True)
    frame = directory / "take-002-fixed-at-1000ms.png"
    if frame.exists():
        raise FileExistsError("Preserve the earlier diagnostic; select a new version before rerendering.")
    filters = _visual_filters(take, direction, font=_font(), work_dir=directory)
    assert not any("drawtext=" in item for item in filters)
    subprocess.run(
        [FFMPEG, "-hide_banner", "-loglevel", "error", "-threads", "1",
         "-ss", f"{start + 1:.3f}", "-i", str(source), "-filter_threads", "1",
         "-vf", ",".join(filters), "-frames:v", "1", "-update", "1", str(frame)],
        check=True, capture_output=True, text=True, timeout=90,
    )
    assert sha(source) == asset["content_hash"]
    report = {
        "scope": "ONE_FRAME_NULL_OVERLAY_REGRESSION_NOT_RELEASE_QA",
        "renderer": PHASE6_SEGMENT_RENDERER,
        "take_id": take["take_id"], "local_time_ms": 1000,
        "timeline_time_ms": take["start_ms"] + 1000,
        "expected_overlay": None, "drawtext_filters": 0,
        "plan_sha256": sha(plan_path), "treatment_sha256": sha(treatment_path),
        "source_sha256": sha(source), "capacity_preflight": capacity,
        "frame_path": str(frame.relative_to(ROOT)), "frame_sha256": sha(frame),
        "publication_approved": False, "technical_cost_brl": 0,
    }
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
