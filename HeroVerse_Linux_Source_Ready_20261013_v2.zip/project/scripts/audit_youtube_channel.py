from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.channel_readiness import (
    build_channel_readiness_audit,
    collect_owned_channel_snapshot,
    write_json,
)
from hero_engine.youtube_integration import INTEGRATION_SCOPES, _build_services, load_or_authorize_credentials


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a private, fail-closed HeroVerse channel readiness audit")
    parser.add_argument("--credentials", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--output-dir", default="output/audits/channel/heroverse")
    parser.add_argument("--studio-observation", default="output/audits/channel/heroverse/studio-observation.json")
    args = parser.parse_args()
    output = ROOT / args.output_dir
    credentials = load_or_authorize_credentials(
        Path(args.credentials), Path(args.token), authorize=False, scopes=INTEGRATION_SCOPES
    )
    youtube, analytics = _build_services(credentials)
    snapshot = collect_owned_channel_snapshot(youtube, analytics, output_dir=output)
    studio = json.loads((ROOT / args.studio_observation).read_text(encoding="utf-8"))
    audit = build_channel_readiness_audit(snapshot, studio_observation=studio)
    write_json(output / "channel-snapshot.json", snapshot)
    write_json(output / "channel-readiness-audit.json", audit)
    print(json.dumps({
        "snapshot_id": snapshot["snapshot_id"],
        "audit_id": audit["audit_id"],
        "overall_status": audit["overall_status"],
        "critical_open_gates": audit["publication_gate"]["critical_open_gates"],
        "external_cost_usd": snapshot["external_cost_usd"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
