"""Freeze the active Phase 2 run and its implementation evidence with SHA-256."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.contracts.analysis import file_sha256
from hero_engine.mining.pipeline import FIXTURE_IDS, MinerConfig, OUTPUT_ROOT, fixture_catalog, job_key_for


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT.resolve()).as_posix()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    pipeline_version = MinerConfig().pipeline_version
    benchmark_dir = OUTPUT_ROOT / "benchmarks" / pipeline_version
    active_path = OUTPUT_ROOT / "runs" / pipeline_version / "active_run.json"
    integrity_path = OUTPUT_ROOT / "integrity" / f"{pipeline_version}.json"
    catalog = fixture_catalog()
    active_jobs = {
        video_id: job_key_for(catalog[video_id]["content_sha256"], MinerConfig())
        for video_id in FIXTURE_IDS
    }
    previous_generated_at = None
    if active_path.is_file():
        previous = json.loads(active_path.read_text(encoding="utf-8"))
        if previous.get("pipeline_version") == pipeline_version:
            previous_generated_at = previous.get("generated_at") or previous.get("created_at")
    active = {
        "schema_version": "1.0.0",
        "phase": 2,
        "status": "AWAITING_REVIEW",
        "pipeline_version": pipeline_version,
        "generated_at": previous_generated_at or datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "jobs": [],
        "benchmark_summary": rel(benchmark_dir / "summary.json"),
        "automatic_promotion_permitted": False,
    }
    targets: set[Path] = set()
    for video_id, job_key in active_jobs.items():
        job_dir = OUTPUT_ROOT / video_id / job_key
        manifest = json.loads((job_dir / "run_manifest.json").read_text(encoding="utf-8"))
        if manifest["status"] != "COMPLETE":
            raise RuntimeError(f"active job is not complete: {video_id} {job_key}")
        active["jobs"].append({
            "video_id": video_id,
            "job_key": job_key,
            "analysis_id": json.loads((job_dir / "video_mining.json").read_text(encoding="utf-8"))["analysis_id"],
            "semantic_hash": manifest["semantic_hash"],
            "manifest": rel(job_dir / "run_manifest.json"),
            "analysis": rel(job_dir / "video_mining.json"),
            "status": "COMPLETE",
        })
        targets.update(path for path in job_dir.rglob("*") if path.is_file())
    targets.update(path for path in benchmark_dir.rglob("*") if path.is_file())
    learning_dir = OUTPUT_ROOT / "learning" / "cycle-001"
    targets.update(path for path in learning_dir.rglob("*") if path.is_file())
    targets.add(ROOT / "data" / "gold_standard" / "evaluation" / "ocr_literal_v1.json")
    implementation = [
        ROOT / "hero_engine" / "contracts" / "analysis.py",
        ROOT / "hero_engine" / "mining" / "adapters.py",
        ROOT / "hero_engine" / "mining" / "narrative.py",
        ROOT / "hero_engine" / "mining" / "semantics.py",
        ROOT / "hero_engine" / "mining" / "pipeline.py",
        ROOT / "hero_engine" / "evaluation" / "gold_standard.py",
        ROOT / "hero_engine" / "cli.py",
        ROOT / "schemas" / "video_mining.schema.json",
        ROOT / "schemas" / "mining_benchmark.schema.json",
        ROOT / "schemas" / "miner_improvement_cycle.schema.json",
        ROOT / "schemas" / "miner_improvement_outcome.schema.json",
        ROOT / "tests" / "test_mining_phase2.py",
        ROOT / "scripts" / "build_phase2_integrity.py",
        ROOT / "requirements.txt",
    ]
    targets.update(path for path in implementation if path.is_file())
    write_json(active_path, active)
    targets.add(active_path)
    entries = [
        {"artifact": rel(path), "sha256": file_sha256(path), "bytes": path.stat().st_size}
        for path in sorted(targets, key=lambda item: rel(item))
    ]
    manifest = {
        "schema_version": "1.0.0",
        "phase": 2,
        "status": "AWAITING_REVIEW",
        "algorithm": "SHA-256",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "active_job_count": len(active_jobs),
        "item_count": len(entries),
        "total_bytes": sum(item["bytes"] for item in entries),
        "entries": entries,
    }
    write_json(integrity_path, manifest)
    print(json.dumps({
        "active_run": str(active_path),
        "integrity_manifest": str(integrity_path),
        "item_count": manifest["item_count"],
        "total_bytes": manifest["total_bytes"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
