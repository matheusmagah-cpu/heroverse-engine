[CmdletBinding()]
param([switch]$Execute)

# Incident-specific cooperative cancellation, not maintenance installation.
# It never writes token, health, watcher, capability, queue or publication state.
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 with literal JSON dates required.' }
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$runtimeDir = Join-Path $projectRoot 'output/runtime/gestor-central'
$requestPath = Join-Path $runtimeDir 'maintenance-request.json'
$ackPath = Join-Path $runtimeDir 'maintenance-ack.json'
$recoveryWindowPath = Join-Path $runtimeDir 'maintenance-recovery-window.json'
$dailyPath = Join-Path $PSScriptRoot 'daily.ps1'
$proofPath = Join-Path $projectRoot 'output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json'
$watcherPath = Join-Path $runtimeDir 'oauth-reconsent-watcher.json'
$healthPath = Join-Path $runtimeDir 'oauth-session-health.json'
$areaPath = Join-Path $projectRoot 'output/qa/phase6/diagnostics/oauth-watcher-unblock-v1/boundary-recovery-v1'
$expectedManager = 11852
$expectedTokenHash = 'c7f88a2d9ef2b11f0584c28a5a0f5d74a0de5377728900e138fcdb735f20cbaa'
$requestId = 'maintenance-request-' + [DateTimeOffset]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
$mutex = [Threading.Mutex]::new($false, 'Local\HeroEngine.ModelagemYoutube.DailyMaintenance.v1')
$ownedMutex = $false
$createdRequest = $false
$requestObserved = $false
$releaseVerified = $false
$failure = $null

function Read-LiteralJson([string]$Path) {
    return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) | ConvertFrom-Json -DateKind String
}
function Assert-Hash([string]$Path, [string]$Expected) {
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Expected) {
        throw 'Pinned incident input changed; no unobserved replacement is accepted.'
    }
}
function Write-Exclusive([string]$Path, [object]$Value) {
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Value | ConvertTo-Json -Depth 30))
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
}
function Copy-Exclusive([string]$From, [string]$To) {
    $before = (Get-FileHash -LiteralPath $From -Algorithm SHA256).Hash
    [IO.File]::Copy($From,$To,$false)
    if ((Get-FileHash -LiteralPath $To -Algorithm SHA256).Hash -cne $before) { throw 'Snapshot changed during copy.' }
}
function Assert-Incident {
    foreach ($path in @($requestPath,$ackPath,$recoveryWindowPath,$areaPath)) {
        if (Test-Path -LiteralPath $path) { throw 'Existing barrier or incident output must not be replaced.' }
    }
    Assert-Hash $dailyPath '5407f4399b5a34694c6a00b8807916897f5a2a0212bf1e5650f76940dd74d3e0'
    Assert-Hash (Join-Path $projectRoot 'hero_engine/maintenance_protocol.py') '5d02812a1df8f098a18d3cb1852c027feebc747e973d0055f396856b10d81234'
    Assert-Hash (Join-Path $projectRoot 'output/qa/phase6/diagnostics/oauth-watcher-unblock-v1/central_manager_phase5.py.before') '0f8553fd697ff2226f6b839ed500a15eb529fd6c7823e188f9b7a13b37c7ced2'
    Assert-Hash $proofPath '250c9fa6c52e7bbc086c4a8262fcbb6f4d3563dc348261aac2aaef91c17c411e'
    $proof = Read-LiteralJson $proofPath
    if ($proof.status -cne 'PASS' -or $proof.identity_verified_after_refresh -ne $true -or
        $proof.observed_channel_id -cne 'UCuMF6pJQkyMzaVoAxFL86yA') { throw 'Current channel identity proof is required.' }
    $watcher = Read-LiteralJson $watcherPath
    $capability = Read-LiteralJson (Join-Path $runtimeDir 'maintenance-capability.json')
    $lock = Read-LiteralJson (Join-Path $runtimeDir 'manager-lock.json')
    $now = [DateTimeOffset]::UtcNow
    $process = Get-Process -Id $expectedManager -ErrorAction Stop
    if ($watcher.manager_pid -ne $expectedManager -or $capability.manager_pid -ne $expectedManager -or
        $lock.holder_pid -ne $expectedManager -or $lock.state -cne 'HELD' -or
        $capability.holder_started_at -cne $lock.holder_started_at -or
        [DateTimeOffset]$lock.heartbeat_at -gt $now -or [DateTimeOffset]$lock.lease_expires_at -le $now -or
        [Math]::Abs(($process.StartTime.ToUniversalTime() - ([DateTimeOffset]$lock.holder_started_at).UtcDateTime).TotalSeconds) -gt 1 -or
        $capability.manager_source_hash -cne 'sha256:0f8553fd697ff2226f6b839ed500a15eb529fd6c7823e188f9b7a13b37c7ced2') {
        throw 'Expected resident process generation is not proven.'
    }
    $tokenPath = [IO.Path]::GetFullPath([string]$watcher.destination_path)
    if ($tokenPath.StartsWith($projectRoot + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Credential must stay external.'
    }
    Assert-Hash $tokenPath $expectedTokenHash
    if ($capability.runtime_token_hash -cne $expectedTokenHash -or
        [DateTimeOffset]$capability.runtime_token_expires_at -le $now.AddMinutes(10)) { throw 'Recovery runway is insufficient.' }
    $chainCheck = @'
import ast, pathlib, sys
from hero_engine.central_manager_phase5 import _existing_oauth_chain_is_current
root = pathlib.Path(sys.argv[1])
old = root / 'output/qa/phase6/diagnostics/oauth-watcher-unblock-v1/central_manager_phase5.py.before'
new = root / 'hero_engine/central_manager_phase5.py'
def nodes(path):
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, ast.FunctionDef)}
a, b = nodes(old), nodes(new)
assert a['_existing_oauth_chain_is_current'] == b['_existing_oauth_chain_is_current']
assert a['_parse_connection_time'] == b['_parse_connection_time']
assert _existing_oauth_chain_is_current(root, pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]))
print('UNCHANGED_CHAIN_CONTRACT_PASS')
'@
    & (Join-Path $projectRoot '.venv/Scripts/python.exe') -B -X utf8 -c $chainCheck $projectRoot $watcher.source_path $tokenPath
    if ($LASTEXITCODE -ne 0) { throw 'Historical chain contract did not close before the cancellation request.' }
    return $tokenPath
}

try {
    try { $ownedMutex = $mutex.WaitOne(0) }
    catch [Threading.AbandonedMutexException] { $ownedMutex = $true }
    if (-not $ownedMutex) { throw 'Another maintenance owner is active.' }
    $preflightOutput = @(Assert-Incident)
    if ($preflightOutput.Count -ne 2 -or $preflightOutput[0] -cne 'UNCHANGED_CHAIN_CONTRACT_PASS') { throw 'Unexpected preflight output.' }
    $tokenPath = [string]$preflightOutput[1]
    # Load exactly the existing ownership-aware cancellation functions, not the
    # daily script body. Their source bytes were pinned immediately above.
    $parseTokens = $null; $parseErrors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($dailyPath,[ref]$parseTokens,[ref]$parseErrors)
    if ($parseErrors.Count) { throw 'Pinned cancellation source does not parse.' }
    foreach ($name in @('Remove-OwnedBarrierFileBounded','Wait-BarrierReleaseSettled')) {
        $matches = @($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name},$true))
        if ($matches.Count -ne 1) { throw 'Cancellation function identity is not unique.' }
        . ([ScriptBlock]::Create($matches[0].Extent.Text))
    }
    if (-not $Execute) {
        [ordered]@{status='PREFLIGHT_PASS_NO_WRITES'; manager_pid=$expectedManager; network_calls=0; request_created=$false} | ConvertTo-Json
        return
    }
    New-Item -ItemType Directory -Path $areaPath -ErrorAction Stop | Out-Null
    foreach ($pair in @(@($healthPath,'health-before.json'),@($watcherPath,'watcher-before.json'),@($proofPath,'proof-before.json'))) {
        Copy-Exclusive $pair[0] (Join-Path $areaPath $pair[1])
    }
    Write-Exclusive (Join-Path $areaPath 'started.json') ([ordered]@{request_id=$requestId; requester_pid=$PID; manager_pid=$expectedManager; started_at=[DateTimeOffset]::UtcNow.ToString('o'); purpose='COOPERATIVE_WORKER_EXIT_ONLY'; installation_authorized=$false})
    # The official constructor validates and persists the normal barrier.
    $createdRequest = $true # Also clean up a constructor that wrote then failed.
    & (Join-Path $projectRoot '.venv/Scripts/python.exe') -B -X utf8 -m hero_engine.maintenance_protocol --root $projectRoot request --request-id $requestId --requester-pid $PID --guard-seconds 1800 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Official request constructor failed.' }
    Copy-Exclusive $requestPath (Join-Path $areaPath 'request.json')
    $request = Read-LiteralJson $requestPath
    $waitClock = [Diagnostics.Stopwatch]::StartNew()
    do {
        $watcher = Read-LiteralJson $watcherPath
        if (Test-Path -LiteralPath $ackPath -PathType Leaf) {
            $ack = Read-LiteralJson $ackPath
            if ($ack.request_id -ceq $requestId -and $ack.manager_pid -eq $expectedManager -and
                $ack.status -cin @('READY_TO_STOP','DEFERRED') -and
                [DateTimeOffset]$ack.observed_at -ge [DateTimeOffset]$request.requested_at -and
                $watcher.manager_pid -eq $expectedManager -and
                $watcher.status -ceq 'WAITING_FOR_FOUR_SCOPE_TOKEN' -and
                [DateTimeOffset]$watcher.updated_at -ge [DateTimeOffset]$request.requested_at) {
                # DEFERRED is not promoted: it only proves the resident loop
                # observed this request after its old worker returned.
                Write-Exclusive (Join-Path $areaPath 'observed-ack.json') $ack
                Write-Exclusive (Join-Path $areaPath 'observed-watcher.json') $watcher
                foreach ($pair in @(@('central_manager_maintenance_ack.schema.json','observed-ack.json'),@('oauth_reconsent_watcher_runtime.schema.json','observed-watcher.json'))) {
                    & (Join-Path $projectRoot '.venv/Scripts/python.exe') -B -X utf8 -m hero_engine.maintenance_protocol --root $projectRoot validate --schema $pair[0] --document (Join-Path $areaPath $pair[1]) | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Observed resident record failed its schema.' }
                }
                Assert-Hash $tokenPath $expectedTokenHash
                Assert-Hash $proofPath '250c9fa6c52e7bbc086c4a8262fcbb6f4d3563dc348261aac2aaef91c17c411e'
                $requestObserved = $true
                break
            }
        }
        Start-Sleep -Milliseconds 250
    } while ($waitClock.Elapsed.TotalSeconds -lt 40)
    if (-not $requestObserved) { throw 'Resident observation deadline expired; cancellation still required.' }
}
catch { $failure = $_ }
finally {
    try {
        if ($createdRequest) {
            Remove-OwnedBarrierFileBounded -Path $recoveryWindowPath -ExpectedRequestId $requestId
            Remove-OwnedBarrierFileBounded -Path $ackPath -ExpectedRequestId $requestId
            Remove-OwnedBarrierFileBounded -Path $requestPath -ExpectedRequestId $requestId
            Wait-BarrierReleaseSettled -ExpectedRequestId $requestId
            $releaseVerified = $true
            Write-Exclusive (Join-Path $areaPath 'result.json') ([ordered]@{
                request_id=$requestId; observed=$requestObserved; release_verified=$releaseVerified
                finished_at=[DateTimeOffset]::UtcNow.ToString('o'); status= $(if ($requestObserved -and $null -eq $failure) {'REQUEST_CANCELLED_AWAITING_RESIDENT_RECONCILIATION'} else {'FAILED_REQUEST_CANCELLED'})
                process_restart=$false; regression_executed=$false; token_written=$false; health_written=$false; watcher_written=$false; external_api_calls_by_helper=0; technical_cost_brl=0
            })
        }
    }
    finally { if ($ownedMutex) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
}
if ($null -ne $failure) { throw $failure }
[ordered]@{status='REQUEST_CANCELLED_AWAITING_RESIDENT_RECONCILIATION'; request_observed=$requestObserved; release_verified=$releaseVerified} | ConvertTo-Json
