[CmdletBinding()]
param(
    [string]$PhysicalRoot = 'C:\Users\mathe\OneDrive\READET~1\MODELA~1',
    [string]$LogicalRoot = 'C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube'
)

$ErrorActionPreference = 'Stop'
if ($PhysicalRoot -match '[�]') {
    throw 'ORCHESTRATION_ROOT_CORRUPTED: physical root contains a replacement character.'
}
foreach ($path in @($PhysicalRoot, $LogicalRoot)) {
    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        throw "ORCHESTRATION_ROOT_MISSING: $path"
    }
}

# AGENTS.md is immutable enough for a fail-fast identity marker, while its
# content hash proves the short path opens the same project rather than merely
# another existing directory with a similar name.
$physicalMarker = Join-Path $PhysicalRoot 'AGENTS.md'
$logicalMarker = Join-Path $LogicalRoot 'AGENTS.md'
if (-not (Test-Path -LiteralPath $physicalMarker -PathType Leaf) -or -not (Test-Path -LiteralPath $logicalMarker -PathType Leaf)) {
    throw 'ORCHESTRATION_ROOT_MARKER_MISSING: AGENTS.md is required in both views.'
}
$physicalHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $physicalMarker).Hash
$logicalHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $logicalMarker).Hash
if ($physicalHash -ne $logicalHash) {
    throw 'ORCHESTRATION_ROOT_DIVERGED: physical and logical project markers differ.'
}
[pscustomobject]@{
    status = 'PASS'
    physical_root = (Resolve-Path -LiteralPath $PhysicalRoot).Path
    logical_root = (Resolve-Path -LiteralPath $LogicalRoot).Path
    marker_sha256 = "sha256:$($physicalHash.ToLowerInvariant())"
    host_orchestration_only = $true
} | ConvertTo-Json -Compress
