$projectRoot = Split-Path -Parent $PSScriptRoot
$bundledPython = 'C:\Users\mathe\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$venvPath = Join-Path $projectRoot '.venv'
$venvPython = Join-Path $venvPath 'Scripts\python.exe'

if (-not (Test-Path -LiteralPath $venvPython)) {
    & $bundledPython -m venv $venvPath
}

& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r (Join-Path $projectRoot 'requirements.txt')
Push-Location $projectRoot
try {
    & $venvPython -m hero_engine.cli init
}
finally {
    Pop-Location
}

