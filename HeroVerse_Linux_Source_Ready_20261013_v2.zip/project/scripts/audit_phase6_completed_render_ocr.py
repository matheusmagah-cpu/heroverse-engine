"""Read an exact completed render and record isolated OCR diagnostic evidence.

No queue, runtime, input, voice, render or publication file is changed. This is
not a release evaluator and its diagnostic path cannot satisfy the release gate.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hero_engine.phase6_overlay_ocr import materialize_overlay_ocr_audit
from hero_engine.phase6_visual_preflight import INPUTS, PRODUCTION
from jsonschema import Draft202012Validator, FormatChecker


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def main() -> None:
    started = time.perf_counter()
    manifest_path = ROOT / "output/production/phase6/video-002/renders/manifests/render-phase6-1f4cb19d7dee654db8bd.json"
    if sha(manifest_path) != "sha256:6632cfe681bebf06597d05a5a08cc81422ef50acac3ae92b3d396788538cc6b0":
        raise PermissionError("The exact historical manifest changed")
    manifest = json.loads(manifest_path.read_bytes())
    video = Path(manifest["output"]["path"]).resolve()
    if not video.is_relative_to(ROOT) or sha(video) != manifest["output"]["content_hash"]:
        raise PermissionError("The exact completed render changed")
    if manifest["status"] != "COMPLETE" or manifest["publication_approved"] is not False:
        raise PermissionError("This diagnostic is limited to the unapproved completed candidate")
    values, before = {}, {}
    for name, schema_name in INPUTS.items():
        path = ROOT / PRODUCTION / name
        before[path] = path.read_bytes()
        values[name] = json.loads(before[path])
        schema = json.loads((ROOT / "schemas" / schema_name).read_bytes())
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(values[name])
    for name, field, manifest_field in (
        ("take_plan.json", "take_plan_id", "take_plan_id"),
        ("creative_treatment_plan.json", "treatment_plan_id", "creative_treatment_plan_id"),
        ("channel_style_bible.json", "style_bible_id", "style_bible_id"),
    ):
        if values[name][field] != manifest[manifest_field]:
            raise PermissionError("Current inputs are not the historical render's exact identities")
    audit = materialize_overlay_ocr_audit(
        ROOT, video=video, plan=values["take_plan.json"],
        treatment=values["creative_treatment_plan.json"], style_bible=values["channel_style_bible.json"],
        render_manifest=manifest, take_plan_path=ROOT / PRODUCTION / "take_plan.json",
        treatment_path=ROOT / PRODUCTION / "creative_treatment_plan.json",
        style_bible_path=ROOT / PRODUCTION / "channel_style_bible.json",
        output_root=ROOT / "output/qa/phase6/diagnostics/render-1f4cb19d-ocr-v1",
    )
    if any(path.read_bytes() != raw for path, raw in before.items()) or sha(video) != manifest["output"]["content_hash"]:
        raise PermissionError("Source drift during diagnostic; do not consume this observation")
    print(json.dumps({
        "scope": "HISTORICAL_RENDER_DIAGNOSTIC_NOT_RELEASE_QA", "status": audit["status"],
        "summary": audit["summary"], "audit_path": audit["audit_path"],
        "audit_sha256": audit["audit_sha256"], "elapsed_seconds": time.perf_counter() - started,
        "findings": [{"take_id": f["take_id"], "timecode_ms": f["timecode_ms"],
                      "observed_text": f["observed_text"], "failures": f["failures"]}
                     for f in audit["frames"] if f["status"] != "PASS"],
        "publication_authorized": False, "technical_cost_brl": 0,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
