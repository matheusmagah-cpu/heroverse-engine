"""Produce a bounded five-second QA proof for the exact Phase 6 take-003.

Two explicit stages prevent a layout proposal from immediately rendering itself:

1. ``--stage source-preflight`` validates every frozen input and decodes all
   150 source frames through the same BASE_FILTERS used by the recipe.  Every
   primary backing must remain wholly inside its assigned card hull with the
   contractually required clearance; three source snapshots remain only as
   compact review aids.
2. ``--stage render --proof-dir PATH`` revalidates that immutable preflight,
   renders exactly 150 local frames with the existing WAV, and emits five
   review snapshots around the 2.5-second layer boundary.

No API, TTS, queue, production overwrite, release action, or publication occurs.
The resulting diagnostic remains pending independent visual/audio review.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import cv2
import numpy as np
from PIL import Image
from jsonschema import Draft202012Validator

from hero_engine.phase6_layered_hook_recipe import (
    ASSET_END_MS,
    ASSET_PATH,
    ASSET_SHA256,
    ASSET_START_MS,
    DURATION_MS,
    FULL_SPAN_GEOMETRY_POLICY,
    NARRATION,
    RECIPE_ID,
    build_layered_hook_plan,
    canonical_sha,
    compile_layered_hook_filters,
    inspect_layered_hook_layout,
    verify_source_asset_file,
)
from hero_engine.phase6_visual_recipe import BASE_FILTERS
from hero_engine.render_creative_v2_phase5 import FFMPEG, _font


BASE = ROOT / "output/production/phase6/video-002"
PRODUCTION = BASE / "production"
PLAN_PATH = PRODUCTION / "take_plan.json"
TREATMENT_PATH = PRODUCTION / "creative_treatment_plan.json"
ALLOCATION_PATH = PRODUCTION / "asset_allocation.json"
BIBLE_PATH = PRODUCTION / "channel_style_bible.json"
SCRIPT_PATH = BASE / "preproduction/narrative_script.json"
VOICE_MANIFEST = BASE / "audio/manifests/voice-phase6-60322e8ee7586d38077e.json"
PINNED_VOICE_MANIFEST_SHA256 = "sha256:f28f2dcd864ff72bce873f892e9912185f3034bc2613c07fd0712f17a4bec6b2"
PINNED_MODEL_SHA256 = "sha256:f3a290d384fbb27966d462905c71a46cef9e5fd00516b40df32a0b4afe77ac96"
PINNED_VOICES_SHA256 = "sha256:bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d"
PRIOR_PRE_FULL_SPAN_PLAN_ID = "layered-hook-plan-ede082ee49a7ded7a5def69b"
REJECTED_FOOTER_PLAN_ID = "layered-hook-plan-9c2404a63598c40ff7b70d5c"
REJECTED_FOOTER_PROOF_ID = "sha256:7588a8c800541f63c1ba5ea6a2d343b0490dcaa6c9a739823d3c85fe302f31b9"
REJECTED_PROTRUSION_PLAN_ID = "layered-hook-plan-468677426afc2598073d9076"
REJECTED_PROTRUSION_PROOF_ID = "sha256:d43aa97283125da866adb2a8e164f64809869521deedc2615fa336e833710033"
SOURCE_SAMPLE_OFFSETS_MS = (0, 2_500, 4_966.667)
SNAPSHOT_FRAMES = (0, 30, 74, 76, 149)
FULL_SPAN_FRAME_COUNT = 150
RESERVE_BYTES = 5 * 1024**3


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def save_new(path: Path, value: Any) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)


def save_new_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)


def run(command: list[str], *, timeout: int = 60) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command, check=True, capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=timeout,
    )


def validate(schema_name: str, value: Any) -> None:
    schema = read(ROOT / "schemas" / schema_name)
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(value)


def _documents() -> tuple[dict[str, Any], ...]:
    documents = tuple(read(path) for path in (
        PLAN_PATH, TREATMENT_PATH, ALLOCATION_PATH, BIBLE_PATH,
    ))
    validate("take_plan.schema.json", documents[0])
    validate("phase6_creative_treatment_plan.schema.json", documents[1])
    validate("phase6_asset_allocation.schema.json", documents[2])
    validate("visual_continuity_bible.schema.json", documents[3])
    return documents


def _voice_preflight(plan: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], Path, Path, Path]:
    if sha(VOICE_MANIFEST) != PINNED_VOICE_MANIFEST_SHA256:
        raise PermissionError("historical voice manifest changed")
    voice = read(VOICE_MANIFEST)
    validate("voice_render_manifest.schema.json", voice)
    if (
        voice.get("status") != "COMPLETE"
        or voice.get("video_id") != plan["video_id"]
        or voice.get("voice_id") != "am_onyx"
        or voice.get("adapter_implementation") != "KokoroFloatSpeed"
        or voice.get("model_hash") != PINNED_MODEL_SHA256
        or voice.get("voices_hash") != PINNED_VOICES_SHA256
    ):
        raise PermissionError("historical voice/model identity differs")
    if voice["take_plan"]["sha256"] != sha(PLAN_PATH):
        raise PermissionError("voice is not bound to the current exact TakePlan")
    if voice["narrative_script"]["sha256"] != sha(SCRIPT_PATH):
        raise PermissionError("voice is not bound to the current exact narrative script")
    takes = voice.get("takes") or []
    ids = [item.get("take_id") for item in takes]
    if len(ids) != len(set(ids)):
        raise PermissionError("historical voice manifest contains duplicate take IDs")
    matches = [item for item in takes if item.get("take_id") == plan["take_id"]]
    if len(matches) != 1:
        raise PermissionError("historical voice does not contain exactly one take-003")
    item = matches[0]
    if (
        item.get("text") != NARRATION
        or item.get("speed") != 1.06
        or item.get("duration_ms") != 3_925
        or item.get("timeline_slot_ms") != DURATION_MS
        or item.get("fits_timeline_slot") is not True
        or item.get("clipping") is not False
        or item.get("sample_rate") != 24_000
        or item.get("channels") != 1
        or item.get("wav_subtype") != "PCM_16"
        or item.get("content_hash") != "sha256:63c48bfbbcc870e03b234c0f720da96c6bf709977414efd9b641250ddec9b8ba"
    ):
        raise PermissionError("take-003 voice copy/speed/slot/format contract changed")
    wav_path = Path(item["path"]).resolve(strict=True)
    if not wav_path.is_relative_to((BASE / "audio/takes").resolve()):
        raise PermissionError("historical voice WAV is outside the bound take directory")
    if sha(wav_path) != item["content_hash"]:
        raise PermissionError("historical voice WAV hash changed")
    with wave.open(str(wav_path), "rb") as wav:
        frames = wav.getnframes()
        sample_rate = wav.getframerate()
        channels = wav.getnchannels()
        width = wav.getsampwidth()
        samples = np.frombuffer(wav.readframes(frames), dtype="<i2").astype(np.float64)
    measured_duration_ms = frames * 1_000 / sample_rate
    peak = float(np.max(np.abs(samples)) / 32_768) if len(samples) else math.inf
    if (
        frames != item.get("frame_count")
        or sample_rate != 24_000
        or channels != 1
        or width != 2
        or round(measured_duration_ms) != item["duration_ms"]
        or measured_duration_ms > DURATION_MS
        or peak >= 0.99
        or abs(peak - item["peak_linear"]) > 0.000001
    ):
        raise PermissionError("historical WAV measurement no longer satisfies its five-second slot")
    model_path = (ROOT / voice["model"]).resolve(strict=True)
    voices_path = model_path.with_name("voices-v1.0.bin").resolve(strict=True)
    if sha(model_path) != PINNED_MODEL_SHA256 or sha(voices_path) != PINNED_VOICES_SHA256:
        raise PermissionError("pinned local voice model or voice data changed")
    measured = {
        "take_id": item["take_id"], "text": item["text"], "speed": item["speed"],
        "duration_ms_declared": item["duration_ms"],
        "duration_ms_measured": measured_duration_ms,
        "slot_ms": DURATION_MS, "margin_ms": DURATION_MS - measured_duration_ms,
        "frames": frames, "sample_rate": sample_rate, "channels": channels,
        "sample_width": width, "peak_linear": peak, "clipping": False,
        "wav_path": str(wav_path), "wav_sha256": sha(wav_path),
        "voice_id": voice["voice_id"], "model": voice["model"],
        "model_sha256": sha(model_path), "voices_sha256": sha(voices_path),
        "adapter_implementation": voice["adapter_implementation"],
        "tts_calls": 0, "copy_change": False, "speed_change": False,
        "truncation": False,
    }
    return voice, measured, wav_path, model_path, voices_path


def _tools_preflight() -> tuple[Path, Path, Path, dict[str, str]]:
    font = _font().resolve(strict=True)
    ffmpeg = Path(FFMPEG).resolve(strict=True)
    ffprobe = ffmpeg.with_name("ffprobe.exe" if sys.platform == "win32" else "ffprobe").resolve(strict=True)
    versions = {
        "ffmpeg": run([str(ffmpeg), "-version"]).stdout.splitlines()[0],
        "ffprobe": run([str(ffprobe), "-version"]).stdout.splitlines()[0],
    }
    help_text = run([str(ffmpeg), "-hide_banner", "-h", "filter=drawtext"]).stdout
    if "textfile" not in help_text or "expansion" not in help_text:
        raise PermissionError("local FFmpeg lacks the required drawtext contract")
    for encoder in ("libx264", "aac"):
        response = run([str(ffmpeg), "-hide_banner", "-h", f"encoder={encoder}"])
        if f"Encoder {encoder}" not in response.stdout:
            raise PermissionError(f"local FFmpeg lacks required encoder {encoder}")
    return ffmpeg, ffprobe, font, versions


def _source_probe(ffprobe: Path, source_path: Path) -> dict[str, Any]:
    result = json.loads(run([
        str(ffprobe), "-v", "error", "-show_streams", "-show_format", "-of", "json",
        str(source_path),
    ]).stdout)
    videos = [item for item in result.get("streams") or [] if item.get("codec_type") == "video"]
    if len(videos) != 1 or float(result["format"]["duration"]) * 1_000 < ASSET_END_MS:
        raise PermissionError("bound source does not decode across the allocated span")
    return result


def _input_bindings(
    *, source_path: Path, wav_path: Path, model_path: Path, voices_path: Path,
) -> dict[str, str]:
    paths = (
        PLAN_PATH, TREATMENT_PATH, ALLOCATION_PATH, BIBLE_PATH, SCRIPT_PATH,
        VOICE_MANIFEST, source_path, wav_path, model_path, voices_path,
        Path(__file__).resolve(), ROOT / "hero_engine/phase6_layered_hook_recipe.py",
        ROOT / "hero_engine/phase6_visual_recipe.py",
        ROOT / "schemas/phase6_layered_hook_plan.schema.json",
    )
    return {str(path.resolve().relative_to(ROOT)): sha(path.resolve()) for path in paths}


def _estimate_peak_bytes() -> int:
    encoded_video = 8_000_000 / 8 * DURATION_MS / 1_000
    pcm_audio = 24_000 * 2 * DURATION_MS / 1_000
    # Conservatively reserve an uncompressed RGB copy of every source frame,
    # plus the artifact/intermediate allowance and review images.  FFV1 is
    # normally much smaller, but capacity admission must not depend on that.
    full_span_rgb = 1920 * 1080 * 3 * FULL_SPAN_FRAME_COUNT
    return math.ceil(
        encoded_video * 3 + pcm_audio * 3 + full_span_rgb
        + 1920 * 1080 * 4 * 8 + 64 * 1024**2
    )


def _rgb_components_and_coverage(
    rgb_image: np.ndarray, *, layout: dict[str, Any]
) -> dict[str, Any]:
    # Float32 is sufficient for fixed color thresholds and keeps the bounded
    # all-frame verifier comfortably below the memory cost of float64 planes.
    image = np.asarray(rgb_image, dtype=np.float32) / np.float32(255.0)
    if image.shape != (1080, 1920, 3):
        raise PermissionError("source diagnostic frame is not 1920x1080 RGB")
    luminance = 0.2126 * image[:, :, 0] + 0.7152 * image[:, :, 1] + 0.0722 * image[:, :, 2]
    chroma = np.max(image, axis=2) - np.min(image, axis=2)
    card_mask = ((luminance >= 0.28) & (chroma <= 0.25)).astype(np.uint8) * 255
    lower = card_mask[430:970]
    lower = cv2.morphologyEx(lower, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(lower)
    component_geometry: list[tuple[dict[str, int], np.ndarray]] = []
    for label_index, (x, y, width, height, area) in enumerate(stats[1:count], start=1):
        if int(area) >= 100_000:
            points = np.column_stack(np.where(labels == label_index))[:, ::-1].astype(np.int32)
            points[:, 1] += 430
            hull = cv2.convexHull(points.reshape(-1, 1, 2))
            component_geometry.append(({
                "left": int(x), "top": int(y + 430), "right": int(x + width),
                "bottom": int(y + 430 + height), "area_pixels": int(area),
                "convex_hull_vertices": int(len(hull)),
            }, hull))
    component_geometry.sort(key=lambda item: item[0]["left"])
    components = [item[0] for item in component_geometry]
    photometric_coverages = []
    for backing in layout["primary_backgrounds"]:
        region = card_mask[
            backing["top"]:backing["bottom"], backing["left"]:backing["right"]
        ]
        photometric_coverages.append(float(np.mean(region > 0)) if region.size else 0.0)

    assigned_backings: list[dict[str, Any]] = []
    if len(component_geometry) == len(layout["primary_backgrounds"]):
        for card_index, (backing, (component, hull)) in enumerate(
            zip(layout["primary_backgrounds"], component_geometry, strict=True), start=1
        ):
            hull_mask = np.zeros((1080, 1920), dtype=np.uint8)
            cv2.fillConvexPoly(hull_mask, hull, 255)
            backing_hull = hull_mask[
                backing["top"]:backing["bottom"], backing["left"]:backing["right"]
            ]
            hull_fraction = float(np.mean(backing_hull > 0)) if backing_hull.size else 0.0
            corners = (
                (backing["left"], backing["top"]),
                (backing["right"] - 1, backing["top"]),
                (backing["left"], backing["bottom"] - 1),
                (backing["right"] - 1, backing["bottom"] - 1),
            )
            corner_clearances = [
                float(cv2.pointPolygonTest(hull, (float(x), float(y)), True))
                for x, y in corners
            ]
            assigned_backings.append({
                "card_index": card_index,
                "backing": dict(backing),
                "assigned_component": dict(component),
                "convex_hull_fraction": hull_fraction,
                "corner_clearance_pixels": corner_clearances,
                "minimum_corner_clearance_pixels": min(corner_clearances),
            })
    minimum_hull_fraction = min(
        (item["convex_hull_fraction"] for item in assigned_backings), default=0.0
    )
    minimum_corner_clearance = min(
        (item["minimum_corner_clearance_pixels"] for item in assigned_backings), default=-1.0
    )
    panel = layout["secondary_panel"]
    if components and panel["bottom"] <= min(item["top"] for item in components):
        panel_card_clearance = min(item["top"] for item in components) - panel["bottom"]
    elif components and panel["top"] >= max(item["bottom"] for item in components):
        panel_card_clearance = panel["top"] - max(item["bottom"] for item in components)
    else:
        panel_card_clearance = -1
    policy = FULL_SPAN_GEOMETRY_POLICY
    status = (
        "PASS_3_CARD_FRAME_GEOMETRY"
        if (
            len(components) == 3
            and min(photometric_coverages, default=0.0)
            >= policy["minimum_photometric_card_fraction"]
            and minimum_hull_fraction >= policy["minimum_assigned_card_hull_fraction"]
            and minimum_corner_clearance
            >= policy["minimum_assigned_card_corner_clearance_pixels"]
            and panel_card_clearance >= 8
        )
        else "FAIL_SOURCE_GEOMETRY"
    )
    return {
        "status": status,
        "method": "LUMA_CHROMA_MASK_CONNECTED_COMPONENTS_AND_BACKING_COVERAGE",
        "thresholds": {
            "minimum_luminance": 0.28, "maximum_chroma": 0.25,
            "minimum_component_area_pixels": 100_000,
            "minimum_photometric_card_fraction": policy["minimum_photometric_card_fraction"],
            "minimum_assigned_card_hull_fraction": policy["minimum_assigned_card_hull_fraction"],
            "minimum_assigned_card_corner_clearance_pixels": policy[
                "minimum_assigned_card_corner_clearance_pixels"
            ],
            "minimum_panel_card_clearance_pixels": 8,
        },
        "card_component_count": len(components), "card_components": components,
        "assigned_backings": assigned_backings,
        "primary_backing_card_fractions": photometric_coverages,
        "minimum_primary_backing_card_fraction": min(
            photometric_coverages, default=0.0
        ),
        "minimum_assigned_card_hull_fraction": minimum_hull_fraction,
        "minimum_assigned_card_corner_clearance_pixels": minimum_corner_clearance,
        "panel_card_clearance_pixels": panel_card_clearance,
        "not_a_semantic_or_full_span_approval": True,
    }


def _frame_components_and_coverage(
    frame_path: Path, *, layout: dict[str, Any]
) -> dict[str, Any]:
    rgb = np.asarray(Image.open(frame_path).convert("RGB"), dtype=np.uint8)
    return _rgb_components_and_coverage(rgb, layout=layout)


def _summarize_full_span_geometry(records: list[dict[str, Any]]) -> dict[str, Any]:
    required = FULL_SPAN_GEOMETRY_POLICY["required_frame_count"]
    expected_frames = list(range(required))
    observed_frames = [item.get("frame_number") for item in records]
    failed = [
        item.get("frame_number") for item in records
        if item.get("status") != "PASS_3_CARD_FRAME_GEOMETRY"
    ]
    complete = observed_frames == expected_frames
    passed = complete and not failed
    return {
        "schema_version": "1.0.0",
        "status": (
            "PASS_ALL_150_SOURCE_FRAMES_GEOMETRY"
            if passed else "FAIL_FULL_SPAN_SOURCE_GEOMETRY"
        ),
        "required_frame_count": required,
        "observed_frame_count": len(records),
        "frame_numbers_exact_and_ordered": complete,
        "failed_frame_numbers": failed,
        "minimum_photometric_card_fraction": min(
            (item.get("minimum_primary_backing_card_fraction", 0.0) for item in records),
            default=0.0,
        ),
        "minimum_assigned_card_hull_fraction": min(
            (item.get("minimum_assigned_card_hull_fraction", 0.0) for item in records),
            default=0.0,
        ),
        "minimum_assigned_card_corner_clearance_pixels": min(
            (
                item.get("minimum_assigned_card_corner_clearance_pixels", -1.0)
                for item in records
            ),
            default=-1.0,
        ),
        "minimum_panel_card_clearance_pixels": min(
            (item.get("panel_card_clearance_pixels", -1) for item in records),
            default=-1,
        ),
        "frames": records,
        "not_a_semantic_motion_or_release_approval": True,
    }


def _source_preflight() -> Path:
    started = time.perf_counter()
    documents = _documents()
    plan = build_layered_hook_plan(*documents)
    validate("phase6_layered_hook_plan.schema.json", plan)
    layout = inspect_layered_hook_layout(plan, font=_font())
    source_check = verify_source_asset_file(plan, project_root=ROOT)
    source_path = Path(source_check["path"])
    voice, voice_take, wav_path, model_path, voices_path = _voice_preflight(plan)
    ffmpeg, ffprobe, font, versions = _tools_preflight()
    source_probe = _source_probe(ffprobe, source_path)
    bindings = _input_bindings(
        source_path=source_path, wav_path=wav_path,
        model_path=model_path, voices_path=voices_path,
    )
    identity = canonical_sha({
        "recipe_id": RECIPE_ID, "plan": plan, "input_bindings": bindings,
        "voice_take": voice_take, "font_sha256": sha(font),
        "ffmpeg_sha256": sha(ffmpeg), "ffprobe_sha256": sha(ffprobe),
        "source_sample_offsets_ms": SOURCE_SAMPLE_OFFSETS_MS,
        "full_span_geometry_policy": FULL_SPAN_GEOMETRY_POLICY,
        "snapshot_frames": SNAPSHOT_FRAMES,
    })
    parent = ROOT / "output/qa/phase6/diagnostics"
    parent.mkdir(parents=True, exist_ok=True)
    if parent.resolve() != parent.absolute():
        raise PermissionError("diagnostic output root is redirected")
    with tempfile.TemporaryDirectory(prefix="layered-hook-write-probe-", dir=parent) as probe:
        test_path = Path(probe) / "probe"
        test_path.write_bytes(b"layered-hook-local-proof")
        if test_path.read_bytes() != b"layered-hook-local-proof":
            raise OSError("diagnostic write probe failed")
    estimated_peak = _estimate_peak_bytes()
    free = shutil.disk_usage(parent).free
    if free - estimated_peak < RESERVE_BYTES:
        raise PermissionError("layered-hook proof would violate the five-GiB reserve")
    destination = parent / ("layered-hook-proof-" + identity.split(":", 1)[1][:24])
    destination.mkdir(exist_ok=False)
    preflight = {
        "schema_version": "1.0.0", "scope": "LOCAL_LAYERED_HOOK_SOURCE_PREFLIGHT_ONLY",
        "status": "PASS_INPUT_CAPACITY_PENDING_SOURCE_FRAME_REVIEW",
        "created_at": datetime.now(timezone.utc).isoformat(), "identity_sha256": identity,
        "current_plan_id": plan["plan_id"],
        "prior_pre_full_span_plan_id": PRIOR_PRE_FULL_SPAN_PLAN_ID,
        "prior_plan_note": "Preserved identifier from the two-frame preliminary geometry contract.",
        "rejected_footer_plan_id": REJECTED_FOOTER_PLAN_ID,
        "rejected_footer_proof_identity": REJECTED_FOOTER_PROOF_ID,
        "rejected_footer_reason": "Source frames at 0 and 4.966667 seconds showed the footer intersecting card pixels; render was blocked.",
        "rejected_protrusion_plan_id": REJECTED_PROTRUSION_PLAN_ID,
        "rejected_protrusion_proof_identity": REJECTED_PROTRUSION_PROOF_ID,
        "rejected_protrusion_reason": (
            "Independent review found the v2 CHOOSE backing protruding from the "
            "right-card paper in the first rendered frame; its measured source "
            "coverage was 0.92383696994648."
        ),
        "input_bindings": bindings, "source_asset": source_check,
        "source_span_ms": {"start": ASSET_START_MS, "end": ASSET_END_MS, "duration": DURATION_MS},
        "source_probe": source_probe, "voice_reuse": voice_take,
        "historical_voice_identity": {
            key: voice[key] for key in (
                "voice_render_id", "voice_id", "model", "model_hash", "voices_hash",
                "adapter_implementation",
            )
        },
        "font": {"path": str(font), "sha256": sha(font)},
        "tools": versions,
        "free_bytes": free, "estimated_peak_bytes": estimated_peak,
        "reserve_bytes": RESERVE_BYTES, "post_work_headroom_bytes": free - estimated_peak - RESERVE_BYTES,
        "geometry_claim": (
            "HYPOTHESIS_UNTIL_ALL_150_SOURCE_FRAMES_PASS_AND_RENDER_RECEIVES_"
            "INDEPENDENT_REVIEW"
        ),
        "new_tts_calls": 0, "api_calls": 0, "technical_cost_brl": 0,
        "queue_authorized": False, "production_authorized": False, "publication_authorized": False,
    }
    save_new(destination / "layered-hook-plan.json", plan)
    save_new(destination / "layout-proposal.json", layout)
    save_new(destination / "preflight.json", preflight)
    source_filter = ",".join((*BASE_FILTERS, "format=rgb24")).encode("utf-8")
    save_new_bytes(destination / "source-base-filters.txt", source_filter)

    # Decode the exact five-second span once, losslessly, through the same
    # BASE_FILTERS used by the overlay recipe.  Geometry is then checked on
    # every output frame; sparse snapshots cannot authorize the render.
    full_span_path = destination / "source-full-span.mkv"
    full_span_command = [
        str(ffmpeg), "-nostdin", "-n", "-hide_banner", "-loglevel", "error",
        "-ss", f"{ASSET_START_MS / 1000:.6f}", "-i", str(source_path),
        "-an", "-frames:v", str(FULL_SPAN_FRAME_COUNT),
        "-filter_script:v", str(destination / "source-base-filters.txt"),
        "-c:v", "ffv1", "-level", "3", "-pix_fmt", "bgr0",
        str(full_span_path),
    ]
    save_new(destination / "source-full-span-command.json", full_span_command)
    full_span_result = run(full_span_command, timeout=300)
    save_new_bytes(
        destination / "source-full-span.stderr.log",
        full_span_result.stderr.encode("utf-8"),
    )
    full_span_probe = json.loads(run([
        str(ffprobe), "-v", "error", "-count_frames", "-select_streams", "v:0",
        "-show_entries", "stream=codec_name,width,height,r_frame_rate,nb_read_frames",
        "-of", "json", str(full_span_path),
    ]).stdout)
    full_streams = full_span_probe.get("streams") or []
    if len(full_streams) != 1:
        raise PermissionError("full-span source proof lacks exactly one video stream")
    full_stream = full_streams[0]
    if (
        (full_stream.get("width"), full_stream.get("height"), full_stream.get("r_frame_rate"))
        != (1920, 1080, "30/1")
        or int(full_stream.get("nb_read_frames", 0)) != FULL_SPAN_FRAME_COUNT
        or full_stream.get("codec_name") != "ffv1"
    ):
        raise PermissionError("full-span source proof frame contract drifted")
    capture = cv2.VideoCapture(str(full_span_path))
    if not capture.isOpened():
        raise PermissionError("OpenCV could not decode the full-span source proof")
    full_span_records: list[dict[str, Any]] = []
    try:
        while len(full_span_records) <= FULL_SPAN_FRAME_COUNT:
            decoded, bgr = capture.read()
            if not decoded:
                break
            if len(full_span_records) == FULL_SPAN_FRAME_COUNT:
                raise PermissionError("full-span source proof contains more than 150 frames")
            frame_number = len(full_span_records)
            analysis = _rgb_components_and_coverage(
                cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), layout=layout
            )
            analysis.update({
                "frame_number": frame_number,
                "relative_offset_ms": frame_number * 1_000 / 30,
            })
            full_span_records.append(analysis)
    finally:
        capture.release()
    full_span_geometry = _summarize_full_span_geometry(full_span_records)
    full_span_geometry.update({
        "source_full_span_path": str(full_span_path.relative_to(ROOT)),
        "source_full_span_sha256": sha(full_span_path),
        "source_full_span_probe": full_span_probe,
        "method_scope": (
            "GEOMETRIC_CONTAINMENT_OF_KNOWN_OVERLAY_BACKINGS_AGAINST_"
            "SEGMENTED_ASSIGNED_CARD_CONVEX_HULLS"
        ),
    })
    save_new(destination / "source-full-span-geometry.json", full_span_geometry)

    commands = []
    frame_records = []
    geometry_records = []
    for index, offset_ms in enumerate(SOURCE_SAMPLE_OFFSETS_MS, start=1):
        absolute_ms = ASSET_START_MS + offset_ms
        frame_path = destination / f"source-frame-{index:02d}-at-{offset_ms:.3f}ms.png"
        command = [
            str(ffmpeg), "-nostdin", "-n", "-hide_banner", "-loglevel", "error",
            "-ss", f"{absolute_ms / 1000:.6f}", "-i", str(source_path),
            "-frames:v", "1", "-filter_script:v", str(destination / "source-base-filters.txt"),
            "-update", "1", str(frame_path),
        ]
        commands.append(command)
        result = run(command, timeout=120)
        save_new_bytes(destination / f"source-frame-{index:02d}.stderr.log", result.stderr.encode("utf-8"))
        frame_record = {
            "sample_index": index, "relative_offset_ms": offset_ms,
            "absolute_source_ms": absolute_ms,
            "path": str(frame_path.relative_to(ROOT)), "sha256": sha(frame_path),
        }
        frame_records.append(frame_record)
        analysis = _frame_components_and_coverage(frame_path, layout=layout)
        analysis.update(frame_record)
        geometry_records.append(analysis)
    save_new(destination / "source-frame-commands.json", commands)
    full_span_pass = (
        full_span_geometry["status"] == "PASS_ALL_150_SOURCE_FRAMES_GEOMETRY"
    )
    sampled_pass = all(
        item["status"] == "PASS_3_CARD_FRAME_GEOMETRY"
        for item in geometry_records
    )
    sampled_status = (
        "PASS_150_SOURCE_FRAMES_GEOMETRY_PENDING_INDEPENDENT_REVIEW"
        if full_span_pass and sampled_pass
        else "FAIL_SOURCE_GEOMETRY_BLOCK_RENDER"
    )
    geometry = {
        "schema_version": "1.0.0", "status": sampled_status,
        "sample_count": len(geometry_records), "samples": geometry_records,
        "full_span_frame_count": full_span_geometry["observed_frame_count"],
        "full_span_status": full_span_geometry["status"],
        "full_span_geometry_path": str(
            (destination / "source-full-span-geometry.json").relative_to(ROOT)
        ),
        "full_span_geometry_sha256": sha(destination / "source-full-span-geometry.json"),
        "minimum_full_span_photometric_card_fraction": full_span_geometry[
            "minimum_photometric_card_fraction"
        ],
        "minimum_full_span_assigned_card_hull_fraction": full_span_geometry[
            "minimum_assigned_card_hull_fraction"
        ],
        "minimum_full_span_assigned_card_corner_clearance_pixels": full_span_geometry[
            "minimum_assigned_card_corner_clearance_pixels"
        ],
        "proposed_bounds_geometry_pass": layout["proposed_bounds_geometry_pass"],
        "full_span_source_function_status": "UNVERIFIED_PENDING_INDEPENDENT_RENDER_REVIEW",
        "limitations": [
            "All 150 source frames were checked for geometric backing containment; three snapshots are review aids only.",
            "Color segmentation and convex hulls check placement, not narrative clarity or motion quality.",
            "The recipe author is not the independent final reviewer.",
        ],
    }
    save_new(destination / "source-geometry.json", geometry)
    artifact_bindings = {
        str(path.relative_to(destination)): sha(path)
        for path in destination.rglob("*") if path.is_file()
    }
    receipt = {
        "schema_version": "1.0.0", "scope": "LAYERED_HOOK_SOURCE_FRAME_PREFLIGHT_NOT_RELEASE_QA",
        "status": sampled_status, "identity_sha256": identity,
        "input_bindings": bindings, "artifact_bindings": artifact_bindings,
        "preflight_sha256": sha(destination / "preflight.json"),
        "plan_sha256": sha(destination / "layered-hook-plan.json"),
        "layout_sha256": sha(destination / "layout-proposal.json"),
        "geometry_sha256": sha(destination / "source-geometry.json"),
        "full_span_geometry_sha256": sha(destination / "source-full-span-geometry.json"),
        "full_span_source_sha256": sha(full_span_path),
        "frames": frame_records,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "render_performed": False, "new_tts_calls": 0, "api_calls": 0,
        "technical_cost_brl": 0, "queue_authorized": False,
        "production_authorized": False, "publication_authorized": False,
    }
    save_new(destination / "source-preflight-receipt.json", receipt)
    if sampled_status.startswith("FAIL"):
        raise PermissionError("source geometry conflicts with the layered-hook proposal")
    print(json.dumps({
        "event": "SOURCE_PREFLIGHT_COMPLETE", "path": str(destination),
        "status": sampled_status, "identity_sha256": identity,
    }), flush=True)
    return destination


def _revalidate_source_preflight(proof_dir: Path) -> tuple[dict[str, Any], dict[str, Any], tuple[dict[str, Any], ...], Path, Path, Path]:
    destination = proof_dir.resolve(strict=True)
    diagnostic_root = (ROOT / "output/qa/phase6/diagnostics").resolve()
    if not destination.is_relative_to(diagnostic_root) or not destination.name.startswith("layered-hook-proof-"):
        raise PermissionError("proof directory is outside the bounded diagnostic namespace")
    documents = _documents()
    expected_plan = build_layered_hook_plan(*documents)
    plan = read(destination / "layered-hook-plan.json")
    if plan != expected_plan:
        raise PermissionError("stored layered-hook plan differs from the current exact-source build")
    source_check = verify_source_asset_file(plan, project_root=ROOT)
    voice, voice_take, wav_path, model_path, voices_path = _voice_preflight(plan)
    bindings = _input_bindings(
        source_path=Path(source_check["path"]), wav_path=wav_path,
        model_path=model_path, voices_path=voices_path,
    )
    preflight = read(destination / "preflight.json")
    receipt = read(destination / "source-preflight-receipt.json")
    geometry = read(destination / "source-geometry.json")
    full_span_geometry = read(destination / "source-full-span-geometry.json")
    if (
        receipt.get("status")
        != "PASS_150_SOURCE_FRAMES_GEOMETRY_PENDING_INDEPENDENT_REVIEW"
        or geometry.get("status")
        != "PASS_150_SOURCE_FRAMES_GEOMETRY_PENDING_INDEPENDENT_REVIEW"
        or full_span_geometry.get("status")
        != "PASS_ALL_150_SOURCE_FRAMES_GEOMETRY"
        or full_span_geometry.get("observed_frame_count") != FULL_SPAN_FRAME_COUNT
        or geometry.get("full_span_geometry_sha256")
        != sha(destination / "source-full-span-geometry.json")
        or receipt.get("full_span_geometry_sha256")
        != sha(destination / "source-full-span-geometry.json")
        or preflight.get("input_bindings") != bindings
        or receipt.get("input_bindings") != bindings
        or preflight.get("current_plan_id") != plan["plan_id"]
    ):
        raise PermissionError("source preflight is incomplete, divergent, or not render-eligible")
    expected_artifacts = receipt.get("artifact_bindings") or {}
    for relative, expected_hash in expected_artifacts.items():
        path = destination / relative
        if not path.is_file() or sha(path) != expected_hash:
            raise PermissionError("source preflight artifact changed before render")
    return plan, voice_take, documents, wav_path, Path(source_check["path"]), destination


def _render(proof_dir: Path) -> None:
    started = time.perf_counter()
    plan, voice_take, documents, wav_path, source_path, destination = _revalidate_source_preflight(proof_dir)
    ffmpeg, ffprobe, font, _ = _tools_preflight()
    filters = compile_layered_hook_filters(
        plan, *documents, font=font, work_dir=destination / "text",
    )
    graph_path = destination / "video-filters.txt"
    save_new_bytes(graph_path, ",".join(filters).encode("utf-8"))
    artifact = destination / "layered-hook-proof.mp4"
    command = [
        str(ffmpeg), "-nostdin", "-n", "-hide_banner", "-loglevel", "error",
        "-ss", f"{ASSET_START_MS / 1000:.3f}", "-i", str(source_path), "-i", str(wav_path),
        "-filter_threads", "1", "-filter_complex_threads", "1",
        "-filter_complex", "[1:a]apad,atrim=duration=5.000,asetpts=PTS-STARTPTS[voice]",
        "-map", "0:v", "-map", "[voice]", "-filter_script:v", str(graph_path),
        "-c:v", "libx264", "-threads", "2", "-preset", "fast", "-crf", "18",
        "-maxrate", "8M", "-bufsize", "16M", "-c:a", "aac", "-b:a", "192k",
        "-ar", "24000", "-frames:v", "150", "-t", "5.000", "-movflags", "+faststart",
        str(artifact),
    ]
    save_new(destination / "render-command.json", command)
    render_started = time.perf_counter()
    result = run(command, timeout=300)
    render_seconds = time.perf_counter() - render_started
    save_new_bytes(destination / "ffmpeg.stderr.log", result.stderr.encode("utf-8"))
    probe = json.loads(run([
        str(ffprobe), "-v", "error", "-count_frames", "-show_streams", "-show_format",
        "-of", "json", str(artifact),
    ]).stdout)
    videos = [item for item in probe["streams"] if item["codec_type"] == "video"]
    audios = [item for item in probe["streams"] if item["codec_type"] == "audio"]
    if len(videos) != 1 or len(audios) != 1:
        raise ValueError("proof does not contain exactly one video and one audio stream")
    video, audio = videos[0], audios[0]
    if (
        (video.get("width"), video.get("height"), video.get("r_frame_rate")) != (1920, 1080, "30/1")
        or int(video.get("nb_read_frames", 0)) != 150
        or audio.get("sample_rate") != "24000"
        or abs(float(probe["format"]["duration"]) - 5.0) > 0.05
    ):
        raise ValueError("proof frame, duration, size, fps, or audio rate drift")
    decoded = destination / "decoded-proof-audio.wav"
    run([
        str(ffmpeg), "-nostdin", "-n", "-v", "error", "-i", str(artifact),
        "-vn", "-ac", "1", "-ar", "24000", "-c:a", "pcm_s16le", str(decoded),
    ])
    with wave.open(str(wav_path), "rb") as wav:
        original = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float64)
    reference = np.pad(original, (0, DURATION_MS * 24 - len(original)))
    with wave.open(str(decoded), "rb") as wav:
        decoded_samples = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float64)
    if len(decoded_samples) < len(reference):
        raise ValueError("decoded proof audio is shorter than the exact five-second slot")
    correlation = float(np.corrcoef(reference, decoded_samples[:len(reference)])[0, 1])
    decoded_peak = float(np.max(np.abs(decoded_samples)) / 32768)
    if not math.isfinite(correlation) or correlation < 0.995 or decoded_peak >= 0.99:
        raise ValueError("proof audio lost zero-offset alignment or clipped")
    snapshots = []
    for index, frame_number in enumerate(SNAPSHOT_FRAMES, start=1):
        path = destination / f"review-frame-{index:02d}-n{frame_number:03d}.png"
        select = f"select=eq(n\\,{frame_number})"
        run([
            str(ffmpeg), "-nostdin", "-n", "-v", "error", "-i", str(artifact),
            "-vf", select, "-frames:v", "1", "-vsync", "0", str(path),
        ])
        snapshots.append({
            "frame_number": frame_number, "at_ms": frame_number * 1000 / 30,
            "path": str(path.relative_to(ROOT)), "sha256": sha(path),
        })
    # Recompute every original source binding after the final local effect.
    preflight = read(destination / "preflight.json")
    for relative, expected_hash in preflight["input_bindings"].items():
        if sha(ROOT / relative) != expected_hash:
            raise PermissionError("an immutable proof input changed during render")
    save_new(destination / "probe.json", probe)
    artifact_bindings = {
        str(path.relative_to(destination)): sha(path)
        for path in destination.rglob("*") if path.is_file() and path.name != "receipt.json"
    }
    receipt = {
        "schema_version": "1.0.0", "scope": "LAYERED_HOOK_5S_PROOF_NOT_RELEASE_QA",
        "status": "PRODUCED_PENDING_INDEPENDENT_REVIEW",
        "identity_sha256": preflight["identity_sha256"],
        "source_preflight_receipt_sha256": sha(destination / "source-preflight-receipt.json"),
        "plan_id": plan["plan_id"], "recipe_id": plan["recipe_id"],
        "artifact_path": str(artifact.relative_to(ROOT)), "artifact_sha256": sha(artifact),
        "duration_ms": DURATION_MS, "frame_count": 150,
        "snapshot_frames": snapshots,
        "voice": {
            "source_wav_sha256": voice_take["wav_sha256"], "speed": voice_take["speed"],
            "slot_ms": voice_take["slot_ms"], "source_duration_ms": voice_take["duration_ms_measured"],
            "zero_offset_correlation": correlation, "minimum_correlation": 0.995,
            "decoded_peak_linear": decoded_peak,
            "status": "PASS_SIGNAL_ALIGNMENT_NOT_PRONUNCIATION_OR_NATURALNESS",
        },
        "render_seconds": round(render_seconds, 6),
        "wall_seconds": round(time.perf_counter() - started, 6),
        "input_bindings": preflight["input_bindings"], "artifact_bindings": artifact_bindings,
        "new_tts_calls": 0, "api_calls": 0, "technical_cost_brl": 0,
        "queue_authorized": False, "production_authorized": False,
        "publication_authorized": False,
        "full_span_source_function_status": "UNVERIFIED_PENDING_INDEPENDENT_RENDER_REVIEW",
        "limitations": [
            "Five-second isolated diagnostic, not a production asset or release candidate.",
            "No music, full-video mix, narrative-context QA, rights admission, or publication gate.",
            "Signal correlation does not evaluate pronunciation, naturalness, or listening quality.",
            "All 150 source frames passed the geometric containment policy; this does not replace independent review of rendered semantics, motion, endpoints, and event boundary.",
            "The recipe author cannot independently approve this proof.",
        ],
    }
    save_new(destination / "receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True, choices=("source-preflight", "render"))
    parser.add_argument("--proof-dir", type=Path)
    args = parser.parse_args()
    if args.stage == "source-preflight":
        if args.proof_dir is not None:
            parser.error("--proof-dir is only valid for the render stage")
        _source_preflight()
    else:
        if args.proof_dir is None:
            parser.error("--proof-dir is required for the render stage")
        _render(args.proof_dir)


if __name__ == "__main__":
    main()
