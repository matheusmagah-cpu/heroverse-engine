from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build(root: Path, created_at: str | None = None) -> dict:
    package = root / "output" / "production" / "phase5" / "pilot-001"
    destination = package / "integrity_manifest.json"
    successor = package / "integrity_manifest_successor.json"
    if successor.is_file():
        if not destination.is_file():
            raise RuntimeError("committed integrity successor has no historical preimage")
        historical = json.loads(destination.read_text(encoding="utf-8-sig"))
        if historical.get("algorithm") != "SHA-256" or not isinstance(historical.get("entries"), list):
            raise RuntimeError("historical integrity manifest contract differs")
        result = dict(historical)
        result["status"] = "PRESERVED_IMMUTABLE_HISTORY"
        result["historical_manifest_sha256"] = _sha256(destination)
        return result
    entries = []
    for path in sorted(item for item in package.rglob("*") if item.is_file()):
        relative = path.relative_to(package)
        if path == destination or "render_work" in relative.parts or path.suffix == ".tmp":
            continue
        entries.append({"artifact": relative.as_posix(), "sha256": _sha256(path), "bytes": path.stat().st_size})
    value = {
        "schema_version": "1.0.0",
        "algorithm": "SHA-256",
        "scope": "phase5 package excluding reproducible render_work intermediates and temporary files",
        "exclusions": ["integrity_manifest.json", "**/render_work/**", "**/*.tmp"],
        "item_count": len(entries),
        "total_bytes": sum(item["bytes"] for item in entries),
        "entries": entries,
        "created_at": created_at or datetime.now(timezone.utc).isoformat(),
    }
    destination.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return value


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--created-at")
    args = parser.parse_args()
    result = build(Path(__file__).resolve().parents[1], args.created_at)
    print(json.dumps({"item_count": result["item_count"], "total_bytes": result["total_bytes"]}, indent=2))
