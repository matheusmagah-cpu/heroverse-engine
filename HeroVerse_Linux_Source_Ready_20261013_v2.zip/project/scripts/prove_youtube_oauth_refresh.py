from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.oauth_refresh_proof import prove_noninteractive_refresh


def main() -> None:
    parser = argparse.ArgumentParser(description="Prove noninteractive YouTube OAuth refresh and exact channel identity")
    parser.add_argument("--token", required=True, help="External authorized-user token path")
    parser.add_argument(
        "--receipt",
        default="output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
    )
    args = parser.parse_args()
    receipt = prove_noninteractive_refresh(Path(args.token), ROOT / args.receipt, root=ROOT)
    print(json.dumps({
        "status": receipt["status"],
        "channel_id": receipt["observed_channel_id"],
        "refresh_success": receipt["refresh_success"],
        "failure_code": receipt["failure_code"],
        "receipt": args.receipt,
    }, ensure_ascii=False))
    if receipt["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

