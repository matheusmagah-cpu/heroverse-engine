[CmdletBinding()]
param(
    [switch]$VerifyOnly
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$receiptPath = Join-Path $projectRoot 'output\runtime\gestor-central\power-continuity.json'

$settings = @(
    [ordered]@{ id = 'DISPLAY_IDLE'; subgroup = 'SUB_VIDEO'; setting = 'VIDEOIDLE'; change = 'monitor-timeout' },
    [ordered]@{ id = 'STANDBY_IDLE'; subgroup = 'SUB_SLEEP'; setting = 'STANDBYIDLE'; change = 'standby-timeout' },
    [ordered]@{ id = 'HIBERNATE_IDLE'; subgroup = 'SUB_SLEEP'; setting = 'HIBERNATEIDLE'; change = 'hibernate-timeout' }
)

if (-not $VerifyOnly) {
    foreach ($item in $settings) {
        & powercfg /change "$($item.change)-ac" 0 | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "powercfg failed to set $($item.id) for AC power."
        }
        & powercfg /change "$($item.change)-dc" 0 | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "powercfg failed to set $($item.id) for battery power."
        }
    }
}

$observed = @()
foreach ($item in $settings) {
    $query = (& powercfg /query SCHEME_CURRENT $item.subgroup $item.setting 2>&1) -join "`n"
    if ($LASTEXITCODE -ne 0) {
        throw "powercfg failed to query $($item.id)."
    }
    # powercfg prints minimum, maximum, increment, AC and DC hexadecimal
    # values in this order. Taking the final two values is independent of the
    # Windows display language.
    $hexValues = [regex]::Matches($query, '0x[0-9a-fA-F]{8}')
    if ($hexValues.Count -lt 5) {
        throw "Could not parse AC/DC values for $($item.id)."
    }
    $acSeconds = [Convert]::ToInt64($hexValues[$hexValues.Count - 2].Value.Substring(2), 16)
    $dcSeconds = [Convert]::ToInt64($hexValues[$hexValues.Count - 1].Value.Substring(2), 16)
    $observed += [ordered]@{
        id = $item.id
        ac_seconds = $acSeconds
        dc_seconds = $dcSeconds
        pass = $acSeconds -eq 0 -and $dcSeconds -eq 0
    }
}

$continuousAwake = @($observed | Where-Object { -not $_.pass }).Count -eq 0
$activeScheme = ((& powercfg /getactivescheme 2>&1) -join ' ').Trim()
$now = [DateTimeOffset]::UtcNow.ToString('o')
$receipt = [ordered]@{
    schema_version = '1.0.0'
    receipt_id = 'power-continuity-' + [DateTimeOffset]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')
    status = if ($continuousAwake) { 'PASS' } else { 'BLOCKED' }
    mode = if ($VerifyOnly) { 'VERIFY_ONLY' } else { 'APPLY_AND_VERIFY' }
    active_scheme = $activeScheme
    settings = $observed
    continuous_awake = $continuousAwake
    technical_cost_brl = 0
    observed_at = $now
}

New-Item -ItemType Directory -Path (Split-Path -Parent $receiptPath) -Force | Out-Null
$temporary = $receiptPath + '.tmp'
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $temporary -Encoding utf8
Move-Item -LiteralPath $temporary -Destination $receiptPath -Force
$receipt | ConvertTo-Json -Depth 5

if (-not $continuousAwake) {
    throw 'Display, standby or hibernation is still enabled for AC or battery power.'
}
