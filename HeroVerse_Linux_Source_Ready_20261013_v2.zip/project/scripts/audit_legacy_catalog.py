from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.channel_catalog_audit import build_legacy_catalog_audit


def main() -> None:
    snapshot_path = ROOT / "output/audits/channel/heroverse/channel-snapshot.json"
    output_path = ROOT / "output/audits/channel/heroverse/legacy-catalog-audit.json"
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8-sig"))
    audit = build_legacy_catalog_audit(snapshot)
    output_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(audit["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
