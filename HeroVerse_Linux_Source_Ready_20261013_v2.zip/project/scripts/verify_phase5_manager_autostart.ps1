[CmdletBinding()]
param(
    [string]$TaskName = 'HeroEngine-Phase5-CentralManager',
    [switch]$IncludeProcessIdentity
)

function Get-VerifiedManagerIdentity {
    param($Before, $After, [int]$ExpectedPid)
    if ($null -eq $Before -or $null -eq $After -or $ExpectedPid -le 0) { throw 'Manager identity unavailable.' }
    foreach ($sample in @($Before, $After)) {
        if ([int]$sample.ProcessId -ne $ExpectedPid -or [int]$sample.ParentProcessId -le 0 -or
            $null -eq $sample.CreationDate -or [string]::IsNullOrWhiteSpace($sample.ExecutablePath) -or
            [string]::IsNullOrWhiteSpace($sample.CommandLine) -or
            $sample.CommandLine -notmatch '(?:^|\s)-m\s+hero_engine\.central_manager_phase5(?:\s|$)') {
            throw 'Manager identity uncertain or different executable role.'
        }
    }
    if ([int]$Before.ParentProcessId -ne [int]$After.ParentProcessId -or
        ([DateTimeOffset]$Before.CreationDate).ToUniversalTime() -ne ([DateTimeOffset]$After.CreationDate).ToUniversalTime() -or
        [string]$Before.ExecutablePath -cne [string]$After.ExecutablePath -or
        [string]$Before.CommandLine -cne [string]$After.CommandLine) { throw 'Manager identity changed across probe.' }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $exeHash = 'sha256:' + ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$After.ExecutablePath)))).Replace('-','').ToLowerInvariant()
        $commandHash = 'sha256:' + ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$After.CommandLine)))).Replace('-','').ToLowerInvariant()
    } finally { $sha.Dispose() }
    return [ordered]@{pid=$ExpectedPid;parent_pid=[int]$After.ParentProcessId;started_at=([DateTimeOffset]$After.CreationDate).ToUniversalTime().ToString('o');executable_path_sha256=$exeHash;command_sha256=$commandHash;stable_across_probe=$true}
}

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$runtimeDir = Join-Path $projectRoot 'output\runtime\gestor-central'
$pythonExe = Join-Path $projectRoot '.venv\Scripts\python.exe'
$task = Get-ScheduledTask -TaskName $TaskName
$taskInfo = Get-ScheduledTaskInfo -TaskName $TaskName
$pidPath = Join-Path $runtimeDir 'manager.pid'
$lockPath = Join-Path $runtimeDir 'manager-lock.json'
$reviewPath = Join-Path $runtimeDir 'review-console-status.json'
$stderrPath = Join-Path $runtimeDir 'manager.stderr.log'
$powerPath = Join-Path $runtimeDir 'power-continuity.json'
$bootstrapLog = Join-Path $env:LOCALAPPDATA 'HeroEngine\manager-task-bootstrap.log'

$managerPid = if (Test-Path -LiteralPath $pidPath) { [int](Get-Content -LiteralPath $pidPath -Raw) } else { 0 }
$managerProcess = if ($managerPid -gt 0) { Get-Process -Id $managerPid -ErrorAction SilentlyContinue } else { $null }
$identityBefore = if ($IncludeProcessIdentity -and $managerPid -gt 0) { Get-CimInstance Win32_Process -Filter "ProcessId=$managerPid" -ErrorAction Stop } else { $null }
$lock = if (Test-Path -LiteralPath $lockPath) { Get-Content -LiteralPath $lockPath -Raw | ConvertFrom-Json } else { $null }
$review = if (Test-Path -LiteralPath $reviewPath) { Get-Content -LiteralPath $reviewPath -Raw | ConvertFrom-Json } else { $null }
$power = if (Test-Path -LiteralPath $powerPath) { Get-Content -LiteralPath $powerPath -Raw | ConvertFrom-Json } else { $null }

$probeOut = Join-Path $runtimeDir 'duplicate-probe.stdout.log'
$probeErr = Join-Path $runtimeDir 'duplicate-probe.stderr.log'
$probe = Start-Process `
    -FilePath $pythonExe `
    -ArgumentList @('-m', 'hero_engine.central_manager_phase5', '--loop', '--interval', '60') `
    -WorkingDirectory $projectRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $probeOut `
    -RedirectStandardError $probeErr `
    -Wait `
    -PassThru
$probeMessage = if (Test-Path -LiteralPath $probeErr) { (Get-Content -LiteralPath $probeErr -Raw).Trim() } else { '' }

$managerAlive = $null -ne $managerProcess
$lockMatches = $null -ne $lock -and $lock.state -eq 'HELD' -and $lock.holder_pid -eq $managerPid
$reviewMatches = $null -ne $review -and $review.status -eq 'LISTENING' -and $review.process_id -eq $managerPid
$duplicateBlocked = $probe.ExitCode -eq 73 -and $probeMessage -like '*BLOCKED_DUPLICATE_MANAGER*'
$stderrBytes = if (Test-Path -LiteralPath $stderrPath) { (Get-Item -LiteralPath $stderrPath).Length } else { -1 }
$powerContinuity = $null -ne $power -and $power.status -eq 'PASS' -and $power.continuous_awake -eq $true -and @($power.settings | Where-Object { -not $_.pass -or $_.ac_seconds -ne 0 -or $_.dc_seconds -ne 0 }).Count -eq 0
$operationalReady = [string]$task.State -eq 'Running' -and $managerAlive -and $lockMatches -and $reviewMatches -and $duplicateBlocked -and $stderrBytes -eq 0 -and $powerContinuity
$processIdentity = if ($IncludeProcessIdentity) { Get-VerifiedManagerIdentity -Before $identityBefore -After (Get-CimInstance Win32_Process -Filter "ProcessId=$managerPid" -ErrorAction Stop) -ExpectedPid $managerPid } else { $null }

$receipt = [ordered]@{
    schema_version = '1.0.0'
    verification_id = 'phase5-manager-autostart-verification-v1'
    task_name = $TaskName
    task_state = [string]$task.State
    last_task_result = [int64]$taskInfo.LastTaskResult
    manager_pid = $managerPid
    manager_alive = $managerAlive
    lock_state = if ($null -ne $lock) { [string]$lock.state } else { 'UNAVAILABLE' }
    lock_holder_pid = if ($null -ne $lock) { [int]$lock.holder_pid } else { 0 }
    lock_heartbeat_at = if ($null -ne $lock) { ([DateTimeOffset]$lock.heartbeat_at).ToUniversalTime().ToString('o') } else { $null }
    lease_expires_at = if ($null -ne $lock) { ([DateTimeOffset]$lock.lease_expires_at).ToUniversalTime().ToString('o') } else { $null }
    review_console_status = if ($null -ne $review) { [string]$review.status } else { 'UNAVAILABLE' }
    review_process_id = if ($null -ne $review) { [int]$review.process_id } else { 0 }
    same_process_chain = $lockMatches -and $reviewMatches
    duplicate_probe_exit_code = [int]$probe.ExitCode
    duplicate_probe_blocked = $duplicateBlocked
    active_stderr_bytes = [int64]$stderrBytes
    bootstrap_log_exists = Test-Path -LiteralPath $bootstrapLog
    power_continuity_status = if ($null -ne $power) { [string]$power.status } else { 'UNAVAILABLE' }
    power_continuity_receipt = if ($null -ne $power) { 'output/runtime/gestor-central/power-continuity.json' } else { $null }
    continuous_awake = $powerContinuity
    technical_cost_brl = 0
    operational_ready = $operationalReady
    verified_at = [DateTime]::UtcNow.ToString('o')
}

if ($IncludeProcessIdentity) {
    $receipt.schema_version = '1.1.0'
    $receipt.process_identity = $processIdentity
}

$receiptPath = Join-Path $runtimeDir 'autostart-verification.json'
$receipt | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding utf8
$receipt | ConvertTo-Json

if (-not $operationalReady) {
    exit 1
}
