[CmdletBinding()]
param(
    [ValidateRange(10, 600)]
    [int]$HandshakeTimeoutSeconds = 120,

    [ValidateRange(60, 900)]
    [int]$FreshCycleTimeoutSeconds = 420,

    [ValidateRange(60, 21600)]
    [int]$ProtectedDueGuardSeconds = 1800
)

$ErrorActionPreference = 'Stop'
$postCycleValidationBudgetSeconds = 180
$recoverySafetyMarginSeconds = 120
$recoveryGuardSeconds = $FreshCycleTimeoutSeconds + $postCycleValidationBudgetSeconds + (2 * $recoverySafetyMarginSeconds)
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$maintenanceMutexName = 'Local\HeroEngine.ModelagemYoutube.DailyMaintenance.v1'
$maintenanceMutex = [System.Threading.Mutex]::new($false, $maintenanceMutexName)
$maintenanceMutexAcquired = $false

try {
try {
    $maintenanceMutexAcquired = $maintenanceMutex.WaitOne(0)
}
catch [System.Threading.AbandonedMutexException] {
    # An abandoned owner is gone and this process owns the mutex now. Any
    # request it left behind remains foreign and is rejected below.
    $maintenanceMutexAcquired = $true
}
if (-not $maintenanceMutexAcquired) {
    throw 'Another daily maintenance transaction owns the cross-process mutex; no request, run or barrier was touched.'
}

$testPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$runtimeDir = Join-Path $projectRoot 'output\runtime\gestor-central'
$taskName = 'HeroEngine-Phase5-CentralManager'
$maintenanceInvocationStartedAt = [DateTimeOffset]::UtcNow
$maintenanceRequestedAt = $null
$zeroEffectBoundaryStartedAt = $null
$requestId = 'maintenance-request-' + $maintenanceInvocationStartedAt.ToString('yyyyMMddTHHmmssfffffffZ') + '-' + ([guid]::NewGuid().ToString('N').Substring(0, 8))
$runRelative = 'output/runtime/gestor-central/maintenance-runs/' + $requestId
$runDir = Join-Path $projectRoot ($runRelative.Replace('/', '\'))
$requestPath = Join-Path $runtimeDir 'maintenance-request.json'
$ackPath = Join-Path $runtimeDir 'maintenance-ack.json'
$capabilityPath = Join-Path $runtimeDir 'maintenance-capability.json'
$bootstrapPath = Join-Path $runtimeDir 'maintenance-bootstrap-receipt.json'
$recoveryWindowPath = Join-Path $runtimeDir 'maintenance-recovery-window.json'
$requestSnapshot = Join-Path $runDir 'maintenance-request.json'
$ackSnapshot = Join-Path $runDir 'maintenance-ack.json'
$regressionLatest = Join-Path $runtimeDir 'daily-maintenance-regression-receipt.json'
$finalLatest = Join-Path $runtimeDir 'daily-maintenance-receipt.json'
$managerWasRunning = $false
$managerChainStopped = $false
$restartRequired = $false
$requestCreated = $false
$bodySucceeded = $false
$managerPid = 0
$managerShimPid = 0
$launcherPid = 0
$managerIdentity = $null
$managerShimIdentity = $null
$launcherIdentity = $null
$preRestartAbsenceProof = $null
$verifiedTaskAction = $null
$regressionCompletedAt = $null
$failure = $null
$recoveryFailure = $null
$legacyBootstrapMode = $false
$legacyManagerSuspended = $false
$maintenanceEntryPath = $null
$maintenanceEntryIdentity = $null
$bootstrapInspection = $null
$bootstrapSuspendedAt = $null
$bootstrapPidHash = $null
$bootstrapLockHash = $null
$bootstrapReviewHash = $null
$barrierReleasedAt = $null
$holdRequestId = $null
$holdRequestSnapshot = $null
$holdAckSnapshot = $null
$preBoundaryPath = $null
$postBoundaryPath = $null
$recoveryWindowSnapshot = $null
$recoveryMonotonicClock = $null
$recoveryWindowBudgetSeconds = 0.0
$finalCandidatePath = $null
$runtimeMigrationPreview = $null
$runtimeMigrationPreviewPath = $null

function Confirm-RegressionResult {
    param(
        [string]$PythonPath, [string]$InventoryPath, [string]$InventoryHash,
        [object]$ExpectedTestCount, [object]$ProcessExitCode,
        [string]$StdoutPath, [string]$StderrPath, [string]$ResultJson
    )
    if (-not (($ProcessExitCode -is [int] -or $ProcessExitCode -is [long]) -and $ProcessExitCode -eq 0)) {
        throw 'Regression consumer requires the real zero process exit code.'
    }
    if (-not (($ExpectedTestCount -is [int] -or $ExpectedTestCount -is [long]) -and $ExpectedTestCount -gt 0)) {
        throw 'Regression consumer requires the frozen integer test count.'
    }
    # Keep the verifier JSON opaque across PS5/PS7. The canonical consumer
    # authenticates 1.0/1.1 against the frozen inventory and original logs,
    # including aliases, allowed skips and exit code, before any PS projection.
    $consumedRaw = ($ResultJson | & $PythonPath -B -m hero_engine.maintenance_unittest_result `
        --inventory $InventoryPath --stdout $StdoutPath --stderr $StderrPath `
        --exit-code ([string]$ProcessExitCode) --consume-result-stdin `
        --expected-inventory-hash $InventoryHash --expected-test-count ([string]$ExpectedTestCount))
    $consumerExitCode = $LASTEXITCODE
    if ($consumerExitCode -ne 0) {
        throw "Regression result consumer failed with exit code $consumerExitCode."
    }
    return (($consumedRaw -join "`n") | ConvertFrom-Json -ErrorAction Stop)
}

function Get-Sha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    return 'sha256:' + (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-StringSha256 {
    param([Parameter(Mandatory = $true)][string]$Value)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value)
        return 'sha256:' + ([BitConverter]::ToString($algorithm.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $algorithm.Dispose()
    }
}

function Get-FileByteEvidence {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Identity,
        [string]$DisplayPath = $null,
        [string]$SnapshotRelative = $null,
        [switch]$RedactPath
    )
    # A redacted external file must never be copied into the workspace.
    if ($RedactPath -and -not [string]::IsNullOrWhiteSpace($SnapshotRelative)) {
        throw 'Redacted byte evidence cannot have a snapshot destination.'
    }
    $present = Test-Path -LiteralPath $Path -PathType Leaf
    $contentHash = if ($present) { Get-Sha256 -Path $Path } else { $null }
    $snapshotHash = $null
    if ($present -and -not [string]::IsNullOrWhiteSpace($SnapshotRelative)) {
        $snapshotPath = Join-Path $projectRoot ($SnapshotRelative.Replace('/', '\'))
        New-Item -ItemType Directory -Path (Split-Path -Parent $snapshotPath) -Force | Out-Null
        if (Test-Path -LiteralPath $snapshotPath) {
            if (-not (Test-Path -LiteralPath $snapshotPath -PathType Leaf) -or (Get-Sha256 -Path $snapshotPath) -cne $contentHash) {
                throw 'Byte snapshot destination already contains different evidence.'
            }
        }
        else { [IO.File]::Copy($Path, $snapshotPath, $false) }
        $snapshotHash = Get-Sha256 -Path $snapshotPath
        if ($snapshotHash -ne $contentHash) {
            throw "Byte snapshot changed during capture: $Identity"
        }
    }
    return [ordered]@{
        identity = $Identity
        path = if ($RedactPath) { $null } elseif (-not [string]::IsNullOrWhiteSpace($DisplayPath)) { $DisplayPath } else { $Path }
        path_identity_hash = Get-StringSha256 -Value ([IO.Path]::GetFullPath($Path).ToLowerInvariant())
        present = $present
        byte_count = if ($present) { [int64](Get-Item -LiteralPath $Path).Length } else { $null }
        content_hash = $contentHash
        snapshot_path = if ($present -and -not [string]::IsNullOrWhiteSpace($SnapshotRelative)) { $SnapshotRelative } else { $null }
        snapshot_hash = $snapshotHash
    }
}

function Read-StoppedRuntimeTokenMetadata {
    param([Parameter(Mandatory = $true)][string]$WatcherPath)
    # This preflight reads only the watcher and filesystem metadata, never token
    # contents. Do it before byte capture or regression, without logging paths.
    if (-not (Test-Path -LiteralPath $WatcherPath -PathType Leaf)) {
        throw 'Stopped-state OAuth watcher metadata is absent.'
    }
    try {
        $watcher = Get-Content -LiteralPath $WatcherPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    catch { throw 'Stopped-state OAuth watcher metadata is unreadable.' }
    if ($watcher.destination_path -isnot [string] -or [string]::IsNullOrWhiteSpace($watcher.destination_path) -or
        $watcher.destination_path_sha256 -isnot [string] -or $watcher.destination_path_sha256 -cnotmatch '^[0-9a-f]{64}$' -or
        $watcher.destination_exists -isnot [bool] -or -not $watcher.destination_exists -or
        $watcher.destination_outside_workspace -isnot [bool] -or -not $watcher.destination_outside_workspace) {
        throw 'Stopped-state OAuth watcher metadata is incomplete or invalid.'
    }
    try {
        if (-not [IO.Path]::IsPathRooted($watcher.destination_path)) { throw 'relative' }
        $tokenPath = [IO.Path]::GetFullPath($watcher.destination_path)
        $workspacePath = [IO.Path]::GetFullPath($projectRoot).TrimEnd([char[]]'\/')
        $insideWorkspace = $tokenPath.Equals($workspacePath, [StringComparison]::OrdinalIgnoreCase) -or
            $tokenPath.StartsWith($workspacePath + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)
        $pathHash = Get-StringSha256 -Value $tokenPath.ToLowerInvariant()
        $present = Test-Path -LiteralPath $tokenPath -PathType Leaf
        $byteCount = if ($present) { [int64](Get-Item -LiteralPath $tokenPath).Length } else { 0 }
    }
    catch { throw 'Stopped-state OAuth token filesystem metadata is unavailable.' }
    if ($insideWorkspace -or $pathHash -cne ('sha256:' + $watcher.destination_path_sha256) -or -not $present -or $byteCount -le 0) {
        throw 'Stopped-state OAuth token path, presence or size metadata diverged.'
    }
    return $watcher
}

function Assert-StoppedRuntimeTokenProjection {
    param(
        [Parameter(Mandatory = $true)][object]$Evidence,
        [Parameter(Mandatory = $true)][object]$Projection,
        [Parameter(Mandatory = $true)][object]$Watcher
    )
    $keys = @('identity', 'path', 'path_identity_hash', 'present', 'byte_count', 'content_hash')
    if ($Evidence -isnot [System.Collections.IDictionary] -or $Projection -isnot [System.Collections.IDictionary] -or
        $Evidence.Count -ne 8 -or $Projection.Count -ne $keys.Count) {
        throw 'Stopped-state OAuth token projection must remain an object with exact fields.'
    }
    foreach ($key in $keys) {
        if (-not $Evidence.Contains($key) -or -not $Projection.Contains($key) -or
            -not [object]::Equals($Evidence[$key], $Projection[$key])) {
            throw 'Stopped-state OAuth token projection diverged before regression.'
        }
    }
    if ($Evidence.identity -cne 'OAUTH_RUNTIME_TOKEN_EXTERNAL' -or $null -ne $Evidence.path -or
        -not $Evidence.Contains('snapshot_path') -or -not $Evidence.Contains('snapshot_hash') -or
        $null -ne $Evidence.snapshot_path -or $null -ne $Evidence.snapshot_hash -or
        $Evidence.present -isnot [bool] -or -not $Evidence.present -or
        $Evidence.byte_count -isnot [int64] -or $Evidence.byte_count -le 0 -or
        $Evidence.content_hash -isnot [string] -or $Evidence.content_hash -cnotmatch '^sha256:[0-9a-f]{64}$' -or
        $Evidence.path_identity_hash -cne ('sha256:' + $Watcher.destination_path_sha256)) {
        throw 'Stopped-state OAuth token metadata is not safely redacted and bound.'
    }
}

function Write-StoppedOperationalSnapshot {
    param(
        [Parameter(Mandatory = $true)][ValidateSet('PRE_REGRESSION', 'POST_REGRESSION')][string]$Role,
        [Parameter(Mandatory = $true)][string]$OutputPath,
        [Parameter(Mandatory = $true)][int]$FormerManagerPid,
        [Parameter(Mandatory = $true)][DateTimeOffset]$BoundaryStartedAt
    )
    if ($null -ne (Get-Process -Id $FormerManagerPid -ErrorAction SilentlyContinue)) {
        throw "Stopped-state snapshot $Role refused because manager PID $FormerManagerPid is alive."
    }
    $watcherPath = Join-Path $runtimeDir 'oauth-reconsent-watcher.json'
    $watcher = Read-StoppedRuntimeTokenMetadata -WatcherPath $watcherPath
    $inspectionRelative = $runRelative + '/stopped-state-' + $Role.ToLowerInvariant().Replace('_', '-') + '-inspection.json'
    $inspectionPath = Join-Path $projectRoot ($inspectionRelative.Replace('/', '\'))
    if (Test-Path -LiteralPath $inspectionPath) {
        throw 'Stopped-state inspection target already exists; historical evidence is preserved.'
    }
    Push-Location $projectRoot
    try {
        & $testPython -m hero_engine.maintenance_protocol inspect --manager-pid $FormerManagerPid --guard-seconds 0 --output $inspectionRelative | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Stopped-state inspection $Role failed." }
    }
    finally { Pop-Location }
    $inspection = Get-Content -LiteralPath $inspectionPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (@($inspection.active_lease_job_ids).Count -ne 0 -or @($inspection.quota.reserved_ids).Count -ne 0 -or @($inspection.operational_effects.open_receipt_paths).Count -ne 0) {
        throw "Stopped-state snapshot $Role found an open lease, quota reservation or operational effect."
    }

    $queueDb = Join-Path $projectRoot 'output\operations\phase6\runtime\phase6-queue.sqlite3'
    $quotaDb = Join-Path $projectRoot 'output\operations\zero-cost\phase6-quota-ledger.sqlite3'
    $evidenceBase = $runRelative + '/stopped-state-bytes/' + $Role.ToLowerInvariant().Replace('_', '-')
    $queueFiles = @(
        Get-FileByteEvidence -Path $queueDb -Identity 'QUEUE_MAIN' -DisplayPath 'output/operations/phase6/runtime/phase6-queue.sqlite3' -SnapshotRelative ($evidenceBase + '/queue-main.sqlite3')
        Get-FileByteEvidence -Path ($queueDb + '-wal') -Identity 'QUEUE_WAL' -DisplayPath 'output/operations/phase6/runtime/phase6-queue.sqlite3-wal' -SnapshotRelative ($evidenceBase + '/queue-wal.sqlite3')
        Get-FileByteEvidence -Path ($queueDb + '-shm') -Identity 'QUEUE_SHM' -DisplayPath 'output/operations/phase6/runtime/phase6-queue.sqlite3-shm' -SnapshotRelative ($evidenceBase + '/queue-shm.sqlite3')
    )
    $quotaFiles = @(
        Get-FileByteEvidence -Path $quotaDb -Identity 'QUOTA_MAIN' -DisplayPath 'output/operations/zero-cost/phase6-quota-ledger.sqlite3' -SnapshotRelative ($evidenceBase + '/quota-main.sqlite3')
        Get-FileByteEvidence -Path ($quotaDb + '-wal') -Identity 'QUOTA_WAL' -DisplayPath 'output/operations/zero-cost/phase6-quota-ledger.sqlite3-wal' -SnapshotRelative ($evidenceBase + '/quota-wal.sqlite3')
        Get-FileByteEvidence -Path ($quotaDb + '-shm') -Identity 'QUOTA_SHM' -DisplayPath 'output/operations/zero-cost/phase6-quota-ledger.sqlite3-shm' -SnapshotRelative ($evidenceBase + '/quota-shm.sqlite3')
    )
    $effectReceiptFiles = @(@($inspection.operational_effects.receipts) | Sort-Object -Property path | ForEach-Object {
        $relative = [string]$_.path
        $slug = (Get-StringSha256 -Value $relative).Substring(7, 16)
        Get-FileByteEvidence -Path (Join-Path $projectRoot $relative.Replace('/', '\')) -Identity ('EFFECT_RECEIPT:' + $relative) -DisplayPath $relative -SnapshotRelative ($evidenceBase + '/effect-receipt-' + $slug + '.json')
    })
    $effectSurfaceFiles = @('output/operations/phase6/package-treatment-executor-status.json','output/operations/phase6/publication-controller-status.json') | ForEach-Object {
        $slug = (Get-StringSha256 -Value $_).Substring(7, 16)
        Get-FileByteEvidence -Path (Join-Path $projectRoot $_.Replace('/', '\')) -Identity ('EFFECT_SURFACE:' + $_) -DisplayPath $_ -SnapshotRelative ($evidenceBase + '/effect-surface-' + $slug + '.json')
    }
    $oauthProofFiles = @(
        'output/runtime/gestor-central/oauth-session-health.json',
        'output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json',
        'output/runtime/gestor-central/oauth-reconsent-watcher.json',
        'output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json',
        'output/integrations/youtube/heroverse/connection-receipt.json',
        'output/runtime/gestor-central/maintenance-capability.json'
    ) | ForEach-Object {
        $slug = (Get-StringSha256 -Value $_).Substring(7, 16)
        Get-FileByteEvidence -Path (Join-Path $projectRoot $_.Replace('/', '\')) -Identity ('OAUTH_PROOF:' + $_) -DisplayPath $_ -SnapshotRelative ($evidenceBase + '/oauth-proof-' + $slug + '.json')
    }
    $runtimeTokenEvidence = Get-FileByteEvidence -Path ([string]$watcher.destination_path) -Identity 'OAUTH_RUNTIME_TOKEN_EXTERNAL' -RedactPath

    $comparisonFiles = {
        param([object[]]$Items)
        return @($Items | ForEach-Object {
            [ordered]@{
                identity = [string]$_.identity
                path = $_.path
                path_identity_hash = [string]$_.path_identity_hash
                present = [bool]$_.present
                byte_count = $_.byte_count
                content_hash = $_.content_hash
            }
        })
    }
    $tokenProjection = @(& $comparisonFiles @($runtimeTokenEvidence))[0]
    Assert-StoppedRuntimeTokenProjection -Evidence $runtimeTokenEvidence -Projection $tokenProjection -Watcher $watcher
    # No queue_jobs, quota_ledger_tables or operational_effect_receipts cross
    # the shell serializer. The Python compositor reads their pinned bytes.
    $side = if ($Role -eq 'PRE_REGRESSION') { 'before' } else { 'after' }
    $expectedOutput = Join-Path $projectRoot ($runRelative + '/stopped-operational-state-' + $side + '-regression.json')
    if ([IO.Path]::GetFullPath($OutputPath) -cne [IO.Path]::GetFullPath($expectedOutput)) {
        throw 'Stopped-state output is outside its exact role namespace.'
    }
    $envelope = [ordered]@{
        schema_version = '1.0.0'
        request_id = $requestId
        role = $Role
        requested_at = $maintenanceRequestedAt.ToString('o')
        zero_effect_boundary_started_at = $BoundaryStartedAt.ToString('o')
        observed_at = [DateTimeOffset]::UtcNow.ToString('o')
        former_manager_pid = $FormerManagerPid
        inspection_path = $inspectionRelative
        inspection_hash = Get-Sha256 -Path $inspectionPath
        byte_evidence = [ordered]@{
            queue_store_files = @($queueFiles)
            quota_store_files = @($quotaFiles)
            operational_effect_receipt_files = @($effectReceiptFiles)
            operational_effect_surface_files = @($effectSurfaceFiles)
            oauth_proof_files = @($oauthProofFiles)
            oauth_runtime_token = $runtimeTokenEvidence
        }
    }
    $envelopeJson = $envelope | ConvertTo-Json -Depth 20 -Compress
    $previousOutputEncoding = $OutputEncoding
    try {
        $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
        $compositionRaw = ($envelopeJson | & $testPython -m hero_engine.maintenance_snapshot --root $projectRoot)
        $compositionExit = $LASTEXITCODE
    }
    finally { $OutputEncoding = $previousOutputEncoding }
    if ($compositionExit -ne 0) { throw 'Stopped-state lossless composition failed before regression.' }
    $summary = ($compositionRaw -join "`n") | ConvertFrom-Json
    if ($summary.status -cne 'PASS' -or $summary.state_hash -cnotmatch '^sha256:[0-9a-f]{64}$' -or
        $summary.snapshot_hash -cne (Get-Sha256 -Path $OutputPath)) {
        throw 'Stopped-state compositor summary binding diverged.'
    }
    return $summary
}

function Assert-RecoveryWindowRemaining {
    param(
        [Parameter(Mandatory = $true)][System.Diagnostics.Stopwatch]$Clock,
        [Parameter(Mandatory = $true)][double]$BudgetSeconds,
        [Parameter(Mandatory = $true)][double]$MinimumRemainingSeconds,
        [Parameter(Mandatory = $true)][string]$Boundary
    )
    if (-not $Clock.IsRunning) {
        throw "Recovery monotonic clock is not running at $Boundary."
    }
    $remaining = $BudgetSeconds - $Clock.Elapsed.TotalSeconds
    if ($remaining -lt $MinimumRemainingSeconds) {
        throw "Recovery window lacks safe monotonic budget at $Boundary; remaining=$remaining required=$MinimumRemainingSeconds."
    }
}

function Write-JsonAtomic {
    param(
        [Parameter(Mandatory = $true)][object]$Value,
        [Parameter(Mandatory = $true)][string]$Path
    )
    $parent = Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $temporary = Join-Path $parent ('.' + [IO.Path]::GetFileName($Path) + '.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $Value | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $temporary -Encoding utf8
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Remove-OwnedBarrierFileBounded {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$ExpectedRequestId,
        [ValidateRange(1, 60)][int]$TimeoutSeconds = 10
    )
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
    $lastError = $null
    do {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
        try {
            $candidate = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$candidate.request_id -ne $ExpectedRequestId) {
                throw "Refusing to remove a foreign maintenance barrier: $Path"
            }
            Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
        }
        catch {
            $lastError = $_
            if ($_.Exception.Message -like 'Refusing to remove a foreign*') { throw }
        }
        Start-Sleep -Milliseconds 200
    } while ([DateTimeOffset]::UtcNow -lt $deadline)
    $reason = if ($null -ne $lastError) { $lastError.Exception.Message } else { 'file remained present' }
    throw "Owned maintenance barrier could not be removed within ${TimeoutSeconds}s: $Path ($reason)"
}

function Wait-BarrierReleaseSettled {
    param(
        [Parameter(Mandatory = $true)][string]$ExpectedRequestId,
        [ValidateRange(1, 60)][int]$TimeoutSeconds = 10,
        [ValidateRange(100, 5000)][int]$QuietMilliseconds = 1000
    )
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
    $quietSince = $null
    do {
        if (Test-Path -LiteralPath $requestPath -PathType Leaf) {
            throw 'The primary maintenance request reappeared after verified release; refusing to delete an unowned barrier.'
        }
        $secondaryPresent = $false
        foreach ($secondary in @($recoveryWindowPath, $ackPath)) {
            if (Test-Path -LiteralPath $secondary -PathType Leaf) {
                $secondaryPresent = $true
                Remove-OwnedBarrierFileBounded -Path $secondary -ExpectedRequestId $ExpectedRequestId -TimeoutSeconds 2
            }
        }
        if (-not $secondaryPresent -and -not (Test-Path -LiteralPath $ackPath -PathType Leaf) -and -not (Test-Path -LiteralPath $recoveryWindowPath -PathType Leaf)) {
            if ($null -eq $quietSince) { $quietSince = [DateTimeOffset]::UtcNow }
            if (([DateTimeOffset]::UtcNow - $quietSince).TotalMilliseconds -ge $QuietMilliseconds) { return }
        }
        else {
            $quietSince = $null
        }
        Start-Sleep -Milliseconds 100
    } while ([DateTimeOffset]::UtcNow -lt $deadline)
    throw 'Maintenance barrier release did not remain settled for the required quiet interval.'
}

function Archive-PreviousLatest {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Category
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return
    }
    $payload = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    $identity = [string]$payload.receipt_id
    if ([string]::IsNullOrWhiteSpace($identity) -or $identity -notmatch '^[A-Za-z0-9_.-]+$') {
        throw "Cannot archive an unidentifiable prior $Category receipt."
    }
    $archiveDir = Join-Path $runtimeDir ('maintenance-history\' + $Category)
    $destination = Join-Path $archiveDir ($identity + '.json')
    New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null
    if (Test-Path -LiteralPath $destination -PathType Leaf) {
        if ((Get-Sha256 -Path $destination) -ne (Get-Sha256 -Path $Path)) {
            throw "Immutable prior $Category receipt collision: $identity"
        }
        Remove-Item -LiteralPath $Path -Force
    }
    else {
        Move-Item -LiteralPath $Path -Destination $destination
    }
}

function Assert-ProcessRole {
    param(
        [Parameter(Mandatory = $true)][int]$ProcessId,
        [Parameter(Mandatory = $true)][ValidateSet('MANAGER', 'VENV_SHIM', 'LAUNCHER')][string]$Role
    )
    if ($ProcessId -le 0) {
        throw "$Role PID is absent."
    }
    $candidate = Get-CimInstance Win32_Process -Filter ("ProcessId = {0}" -f $ProcessId) -ErrorAction SilentlyContinue
    if ($null -eq $candidate) {
        throw "$Role PID $ProcessId is not alive."
    }
    if ($Role -in @('MANAGER', 'VENV_SHIM')) {
        if ([string]$candidate.CommandLine -notlike '*hero_engine.central_manager_phase5*') {
            throw "PID $ProcessId is not the expected Gestor Central Python process."
        }
        if ($Role -eq 'VENV_SHIM') {
            if (-not [string]::Equals([IO.Path]::GetFullPath([string]$candidate.ExecutablePath), [IO.Path]::GetFullPath($testPython), [StringComparison]::OrdinalIgnoreCase)) {
                throw "PID $ProcessId is not the project venv Python shim."
            }
        }
    }
    else {
        $name = [IO.Path]::GetFileName([string]$candidate.ExecutablePath).ToLowerInvariant()
        if ($name -notin @('powershell.exe', 'pwsh.exe')) {
            throw "PID $ProcessId is not the verified PowerShell task launcher."
        }
        if ($null -eq $verifiedTaskAction) {
            throw 'Scheduled-task action was not verified before launcher inspection.'
        }
        $expectedExecutable = [Environment]::ExpandEnvironmentVariables([string]$verifiedTaskAction.Execute)
        if (-not [string]::Equals([IO.Path]::GetFullPath([string]$candidate.ExecutablePath), [IO.Path]::GetFullPath($expectedExecutable), [StringComparison]::OrdinalIgnoreCase)) {
            throw "PID $ProcessId executable is not the ScheduledTask action executable."
        }
        $expectedArguments = ([string]$verifiedTaskAction.Arguments).Trim()
        if ([string]::IsNullOrWhiteSpace($expectedArguments) -or ([string]$candidate.CommandLine).IndexOf($expectedArguments, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
            throw "PID $ProcessId command line is not bound to the ScheduledTask action arguments."
        }
        $encoded = [regex]::Match($expectedArguments, '(?i)(?:^|\s)-EncodedCommand\s+([A-Za-z0-9+/=]+)(?:\s|$)')
        if (-not $encoded.Success) { throw 'ScheduledTask launcher lacks its encoded runner command.' }
        $decoded = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($encoded.Groups[1].Value))
        $expectedRunner = (Join-Path $PSScriptRoot 'start_phase5_manager.ps1').Replace("'", "''")
        if ($decoded.IndexOf("& '$expectedRunner'", [StringComparison]::OrdinalIgnoreCase) -lt 0) {
            throw 'ScheduledTask encoded action is not bound to the exact manager runner.'
        }
        $configuredWorkingDirectory = [string]$verifiedTaskAction.WorkingDirectory
        if (-not [string]::IsNullOrWhiteSpace($configuredWorkingDirectory) -and -not [string]::Equals([IO.Path]::GetFullPath($configuredWorkingDirectory), $projectRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'ScheduledTask action working directory is outside the exact project root.'
        }
    }
    return $candidate
}

function Stop-VerifiedProcess {
    param(
        [Parameter(Mandatory = $true)][int]$ProcessId,
        [Parameter(Mandatory = $true)][ValidateSet('MANAGER', 'VENV_SHIM', 'LAUNCHER')][string]$Role,
        [Parameter(Mandatory = $true)]$ExpectedIdentity
    )
    if ($ProcessId -le 0) {
        return
    }
    if ($ProcessId -ne [int]$ExpectedIdentity.process_id -or $Role -ne [string]$ExpectedIdentity.role) {
        throw "Stop target does not match the frozen $Role process identity."
    }
    $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if ($null -eq $process) { return }
    try {
        # Force the operating-system handle open before the identity check.
        # Even if the numeric PID is reused afterwards, this handle remains
        # bound to the original kernel process generation.
        $processHandle = $process.Handle
        $handleCreationUtcTicks = [int64]$process.StartTime.ToUniversalTime().Ticks
        if ($handleCreationUtcTicks -ne [int64]$ExpectedIdentity.handle_creation_utc_ticks) {
            # The numeric PID was reused before the action handle was opened.
            # That foreign generation must remain untouched.
            return
        }
        $disposition = Get-BoundedFrozenProcessDisposition `
            -ExpectedIdentity $ExpectedIdentity `
            -TimeoutMilliseconds 2000
        if ($disposition -in @('ABSENT', 'PID_REUSED_FOREIGN')) { return }
        if ($disposition -ne 'EXACT_ALIVE') {
            throw "Cannot safely stop frozen $Role PID $ProcessId; disposition=$disposition."
        }
        if ($null -eq ('HeroEngineMaintenanceTerminationNative' -as [type])) {
            Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class HeroEngineMaintenanceTerminationNative {
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool TerminateProcess(IntPtr processHandle, uint exitCode);
}
'@
        }
        # Terminate the already-open generation-bound handle. Never resolve the
        # numeric PID again after the final exact-identity observation.
        if (-not [HeroEngineMaintenanceTerminationNative]::TerminateProcess($processHandle, 1)) {
            $win32Error = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            throw "Exact-handle termination failed for frozen $Role PID $ProcessId with Win32 error $win32Error."
        }
    }
    finally {
        $process.Dispose()
    }
}

function Get-FrozenProcessIdentity {
    param(
        [Parameter(Mandatory = $true)]$Process,
        [Parameter(Mandatory = $true)][ValidateSet('MANAGER', 'VENV_SHIM', 'LAUNCHER')][string]$Role
    )
    if ($null -eq $Process.CreationDate) {
        throw "$Role process creation time is unavailable; exact identity cannot be frozen."
    }
    $executablePath = [string]$Process.ExecutablePath
    $commandLine = [string]$Process.CommandLine
    if ([string]::IsNullOrWhiteSpace($executablePath) -or [string]::IsNullOrWhiteSpace($commandLine)) {
        throw "$Role process executable or command line is unavailable; exact identity cannot be frozen."
    }
    $creationUtcTicks = ([DateTime]$Process.CreationDate).ToUniversalTime().Ticks
    $handleProcess = Get-Process -Id ([int]$Process.ProcessId) -ErrorAction SilentlyContinue
    if ($null -eq $handleProcess) {
        throw "$Role process exited before its kernel generation could be frozen."
    }
    try {
        # StartTime is read through a live Process handle and therefore binds
        # the numeric PID to the exact Windows kernel process generation.
        $generationHandle = $handleProcess.Handle
        $handleCreationUtcTicks = [int64]$handleProcess.StartTime.ToUniversalTime().Ticks
    }
    finally {
        $handleProcess.Dispose()
    }
    # CIM CreationDate has microsecond precision while Process.StartTime keeps
    # the underlying FILETIME precision. They must describe the same instant
    # within that representation boundary before either value is trusted.
    $creationDeltaTicks = [Math]::Abs([int64]($handleCreationUtcTicks - $creationUtcTicks))
    if ($creationDeltaTicks -gt 10) {
        throw "$Role CIM identity and kernel-handle generation do not match."
    }
    return [pscustomobject][ordered]@{
        role = $Role
        process_id = [int]$Process.ProcessId
        parent_process_id = [int]$Process.ParentProcessId
        creation_utc_ticks = [int64]$creationUtcTicks
        handle_creation_utc_ticks = [int64]$handleCreationUtcTicks
        executable_path = [IO.Path]::GetFullPath($executablePath)
        command_line_hash = Get-StringSha256 -Value $commandLine
    }
}

function Get-FrozenProcessDisposition {
    param([Parameter(Mandatory = $true)]$ExpectedIdentity)
    try {
        $candidate = Get-CimInstance Win32_Process -Filter ("ProcessId = {0}" -f [int]$ExpectedIdentity.process_id) -ErrorAction Stop
    }
    catch {
        return 'IDENTITY_UNCERTAIN'
    }
    if ($null -eq $candidate) { return 'ABSENT' }
    try {
        $current = Get-FrozenProcessIdentity -Process $candidate -Role ([string]$ExpectedIdentity.role)
    }
    catch {
        return 'IDENTITY_UNCERTAIN'
    }
    # PID plus creation time is the Windows process generation. A different
    # creation time proves that the original process ended and the numeric PID
    # was reused; that foreign process is safe to leave untouched.
    if (
        [int64]$current.creation_utc_ticks -ne [int64]$ExpectedIdentity.creation_utc_ticks -or
        [int64]$current.handle_creation_utc_ticks -ne [int64]$ExpectedIdentity.handle_creation_utc_ticks
    ) {
        return 'PID_REUSED_FOREIGN'
    }
    $sameFrozenIdentity = (
        [int]$current.process_id -eq [int]$ExpectedIdentity.process_id -and
        [int]$current.parent_process_id -eq [int]$ExpectedIdentity.parent_process_id -and
        [int64]$current.handle_creation_utc_ticks -eq [int64]$ExpectedIdentity.handle_creation_utc_ticks -and
        [string]::Equals([string]$current.executable_path, [string]$ExpectedIdentity.executable_path, [StringComparison]::OrdinalIgnoreCase) -and
        [string]$current.command_line_hash -eq [string]$ExpectedIdentity.command_line_hash
    )
    if ($sameFrozenIdentity) { return 'EXACT_ALIVE' }
    # A same-generation mismatch is not proof of absence. Fail closed instead
    # of guessing whether WMI returned incomplete or inconsistent identity.
    return 'IDENTITY_UNCERTAIN'
}

function Get-BoundedFrozenProcessDisposition {
    param(
        [Parameter(Mandatory = $true)]$ExpectedIdentity,
        [ValidateRange(0, 10000)][int]$TimeoutMilliseconds = 2000,
        [ValidateRange(10, 1000)][int]$PollMilliseconds = 100
    )
    $deadline = [DateTimeOffset]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    $attempt = 0
    do {
        $attempt += 1
        $disposition = Get-FrozenProcessDisposition -ExpectedIdentity $ExpectedIdentity
        if ($disposition -in @('EXACT_ALIVE', 'ABSENT', 'PID_REUSED_FOREIGN')) {
            return $disposition
        }
        if ($disposition -ne 'IDENTITY_UNCERTAIN') {
            throw "Frozen process disposition is outside the closed contract: $disposition"
        }
        if ([DateTimeOffset]::UtcNow -ge $deadline) { break }
        Start-Sleep -Milliseconds $PollMilliseconds
    } while ($true)
    throw "Frozen $($ExpectedIdentity.role) PID $($ExpectedIdentity.process_id) identity remained uncertain after $attempt bounded observations."
}

function Get-CoherentManagerProcessChainSnapshot {
    param(
        [Parameter(Mandatory = $true)][string]$PidPath,
        [Parameter(Mandatory = $true)][string]$LockPath,
        [ValidateRange(1, 60)][int]$TimeoutSeconds = 10,
        [ValidateRange(25, 1000)][int]$PollMilliseconds = 100
    )
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
    $attempt = 0
    $lastError = $null
    do {
        $attempt += 1
        try {
            if (-not (Test-Path -LiteralPath $PidPath -PathType Leaf) -or -not (Test-Path -LiteralPath $LockPath -PathType Leaf)) {
                throw 'The manager PID/lock pair is temporarily unavailable.'
            }
            $managerPidBefore = [int](Get-Content -LiteralPath $PidPath -Raw)
            $lockBefore = Get-Content -LiteralPath $LockPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (
                $managerPidBefore -le 0 -or
                $managerPidBefore -ne [int]$lockBefore.holder_pid -or
                [string]$lockBefore.state -ne 'HELD' -or
                [string]::IsNullOrWhiteSpace([string]$lockBefore.holder_started_at)
            ) {
                throw 'The PID file and held lock do not identify one stable manager generation.'
            }
            $lockStartedBefore = ([DateTimeOffset]$lockBefore.holder_started_at).ToUniversalTime()

            $managerPid = $managerPidBefore
            $managerProcess = Assert-ProcessRole -ProcessId $managerPid -Role MANAGER
            $managerShimPid = [int]$managerProcess.ParentProcessId
            $managerShim = Assert-ProcessRole -ProcessId $managerShimPid -Role VENV_SHIM
            $launcherPid = [int]$managerShim.ParentProcessId
            $launcher = Assert-ProcessRole -ProcessId $launcherPid -Role LAUNCHER
            if (
                $managerPid -eq $managerShimPid -or
                $managerPid -eq $launcherPid -or
                $managerShimPid -eq $launcherPid -or
                [int]$managerProcess.ParentProcessId -ne [int]$managerShim.ProcessId -or
                [int]$managerShim.ParentProcessId -ne [int]$launcher.ProcessId
            ) {
                throw 'The manager -> venv shim -> ScheduledTask launcher chain is not exact.'
            }

            $initialGenerationTicks = @(
                foreach ($processSample in @($managerProcess, $managerShim, $launcher)) {
                    if ($null -eq $processSample.CreationDate) {
                        throw 'A process creation time disappeared during the initial chain sample.'
                    }
                    [int64]([DateTime]$processSample.CreationDate).ToUniversalTime().Ticks
                }
            )

            # Bracket process discovery with a second PID/lock observation.
            # Heartbeat fields may advance, but holder PID and lock generation
            # must remain identical throughout the sample.
            $managerPidAfter = [int](Get-Content -LiteralPath $PidPath -Raw)
            $lockAfter = Get-Content -LiteralPath $LockPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (
                $managerPidAfter -ne $managerPidBefore -or
                [int]$lockAfter.holder_pid -ne $managerPidBefore -or
                [string]$lockAfter.state -ne 'HELD' -or
                ([DateTimeOffset]$lockAfter.holder_started_at).ToUniversalTime() -ne $lockStartedBefore
            ) {
                throw 'The manager PID/lock generation changed during process-chain discovery.'
            }

            # Re-sample the complete parent chain immediately before freezing
            # identities. A role that exits/restarts between the first sample
            # and this point invalidates the whole attempt; no partial or stale
            # identity can escape to a later stop operation.
            $resampledManager = Assert-ProcessRole -ProcessId $managerPid -Role MANAGER
            $resampledManagerShimPid = [int]$resampledManager.ParentProcessId
            $resampledManagerShim = Assert-ProcessRole -ProcessId $resampledManagerShimPid -Role VENV_SHIM
            $resampledLauncherPid = [int]$resampledManagerShim.ParentProcessId
            $resampledLauncher = Assert-ProcessRole -ProcessId $resampledLauncherPid -Role LAUNCHER
            if (
                $resampledManagerShimPid -ne $managerShimPid -or
                $resampledLauncherPid -ne $launcherPid -or
                [int]$resampledManager.ParentProcessId -ne [int]$resampledManagerShim.ProcessId -or
                [int]$resampledManagerShim.ParentProcessId -ne [int]$resampledLauncher.ProcessId
            ) {
                throw 'The manager process chain changed during the pre-freeze re-sample.'
            }
            $resampledGenerationTicks = @(
                foreach ($processSample in @($resampledManager, $resampledManagerShim, $resampledLauncher)) {
                    if ($null -eq $processSample.CreationDate) {
                        throw 'A process creation time disappeared during the pre-freeze re-sample.'
                    }
                    [int64]([DateTime]$processSample.CreationDate).ToUniversalTime().Ticks
                }
            )
            if (($initialGenerationTicks -join ',') -ne ($resampledGenerationTicks -join ',')) {
                throw 'A process generation changed during the pre-freeze re-sample.'
            }

            $managerProcess = $resampledManager
            $managerShim = $resampledManagerShim
            $launcher = $resampledLauncher
            $managerIdentity = Get-FrozenProcessIdentity -Process $managerProcess -Role MANAGER
            $managerShimIdentity = Get-FrozenProcessIdentity -Process $managerShim -Role VENV_SHIM
            $launcherIdentity = Get-FrozenProcessIdentity -Process $launcher -Role LAUNCHER

            # Both Python generations carry the manager module command. Any
            # additional or missing generation means the task is still
            # churning (or a duplicate exists), so no identity is returned.
            $managerRoleProcesses = @(
                Get-CimInstance Win32_Process -ErrorAction Stop |
                    Where-Object {
                        [IO.Path]::GetFileName([string]$_.ExecutablePath).ToLowerInvariant() -in @('python.exe', 'pythonw.exe') -and
                        -not [string]::IsNullOrWhiteSpace([string]$_.CommandLine) -and
                        ([string]$_.CommandLine).IndexOf(
                            'hero_engine.central_manager_phase5',
                            [StringComparison]::OrdinalIgnoreCase
                        ) -ge 0
                    }
            )
            $managerRolePids = @(
                $managerRoleProcesses |
                    ForEach-Object { [int]$_.ProcessId } |
                    Sort-Object -Unique
            )
            $expectedPythonPids = @(
                @($managerPid, $managerShimPid) | Sort-Object -Unique
            )
            if (
                $managerRolePids.Count -ne 2 -or
                $expectedPythonPids.Count -ne 2 -or
                @($managerRolePids | Where-Object { $_ -notin $expectedPythonPids }).Count -ne 0 -or
                @($expectedPythonPids | Where-Object { $_ -notin $managerRolePids }).Count -ne 0
            ) {
                throw 'The manager task exposes a duplicate or incomplete Python process chain.'
            }

            $managerPidFinal = [int](Get-Content -LiteralPath $PidPath -Raw)
            $lockFinal = Get-Content -LiteralPath $LockPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (
                $managerPidFinal -ne $managerPidBefore -or
                [int]$lockFinal.holder_pid -ne $managerPidBefore -or
                [string]$lockFinal.state -ne 'HELD' -or
                ([DateTimeOffset]$lockFinal.holder_started_at).ToUniversalTime() -ne $lockStartedBefore
            ) {
                throw 'The manager PID/lock generation changed after the pre-freeze re-sample.'
            }
            foreach ($identity in @($managerIdentity, $managerShimIdentity, $launcherIdentity)) {
                if ((Get-FrozenProcessDisposition -ExpectedIdentity $identity) -ne 'EXACT_ALIVE') {
                    throw 'A process generation changed before the coherent chain could be frozen.'
                }
            }
            return [pscustomobject][ordered]@{
                status = 'COHERENT_EXACT_CHAIN'
                attempt_count = $attempt
                observed_at = [DateTimeOffset]::UtcNow.ToString('o')
                manager_pid = $managerPid
                manager_shim_pid = $managerShimPid
                launcher_pid = $launcherPid
                lock = $lockFinal
                manager_process = $managerProcess
                manager_shim_process = $managerShim
                launcher_process = $launcher
                manager_identity = $managerIdentity
                manager_shim_identity = $managerShimIdentity
                launcher_identity = $launcherIdentity
            }
        }
        catch {
            $lastError = $_
            if ([DateTimeOffset]::UtcNow -ge $deadline) { break }
            Start-Sleep -Milliseconds $PollMilliseconds
        }
    } while ($true)
    $reason = if ($null -ne $lastError) { $lastError.Exception.Message } else { 'no coherent sample was returned' }
    throw "The exact ScheduledTask manager chain could not be frozen after $attempt bounded observations: $reason"
}

function Test-FrozenProcessAlive {
    param(
        [Parameter(Mandatory = $true)][int]$ProcessId,
        [Parameter(Mandatory = $true)][ValidateSet('MANAGER', 'VENV_SHIM', 'LAUNCHER')][string]$Role,
        [Parameter(Mandatory = $true)]$ExpectedIdentity
    )
    if ($ProcessId -le 0) { return $false }
    if ($ProcessId -ne [int]$ExpectedIdentity.process_id -or $Role -ne [string]$ExpectedIdentity.role) {
        throw "Liveness target does not match the frozen $Role process identity."
    }
    $disposition = Get-BoundedFrozenProcessDisposition `
        -ExpectedIdentity $ExpectedIdentity `
        -TimeoutMilliseconds 2000
    if ($disposition -eq 'EXACT_ALIVE') { return $true }
    if ($disposition -in @('ABSENT', 'PID_REUSED_FOREIGN')) {
        return $false
    }
    throw "Frozen $Role PID $ProcessId identity is uncertain."
}

function Wait-FrozenProcessChainAbsent {
    param(
        [Parameter(Mandatory = $true)][object[]]$FrozenProcesses,
        [ValidateRange(0, 60)][int]$TimeoutSeconds = 20
    )
    if (@($FrozenProcesses).Count -ne 3) {
        throw 'Restart absence proof requires the exact three-process manager chain.'
    }
    $roles = @($FrozenProcesses | ForEach-Object { [string]$_.role } | Sort-Object -Unique)
    $processIds = @($FrozenProcesses | ForEach-Object { [int]$_.process_id } | Sort-Object -Unique)
    if (($roles -join ',') -ne 'LAUNCHER,MANAGER,VENV_SHIM' -or $processIds.Count -ne 3) {
        throw 'Restart absence proof requires unique frozen MANAGER, VENV_SHIM and LAUNCHER identities.'
    }
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
    do {
        $observations = @(
            foreach ($identity in $FrozenProcesses) {
                [pscustomobject][ordered]@{
                    role = [string]$identity.role
                    process_id = [int]$identity.process_id
                    creation_utc_ticks = [int64]$identity.creation_utc_ticks
                    disposition = Get-FrozenProcessDisposition -ExpectedIdentity $identity
                }
            }
        )
        $notProven = @($observations | Where-Object { $_.disposition -notin @('ABSENT', 'PID_REUSED_FOREIGN') })
        if ($notProven.Count -eq 0) {
            return [pscustomobject][ordered]@{
                verified_at = [DateTimeOffset]::UtcNow.ToString('o')
                status = 'EXACT_CHAIN_ABSENT'
                processes = @($observations)
            }
        }
        if ([DateTimeOffset]::UtcNow -ge $deadline) { break }
        Start-Sleep -Milliseconds 100
    } while ($true)
    $detail = @($notProven | ForEach-Object { "$($_.role):$($_.process_id):$($_.disposition)" }) -join ','
    throw "ScheduledTask restart blocked because exact-chain absence was not proven: $detail"
}

function Invoke-VerifiedScheduledTaskRestart {
    param(
        [Parameter(Mandatory = $true)][object[]]$FrozenProcesses,
        [Parameter(Mandatory = $true)][scriptblock]$StartAction,
        [ValidateRange(0, 60)][int]$TimeoutSeconds = 20
    )
    $absenceProof = Wait-FrozenProcessChainAbsent -FrozenProcesses $FrozenProcesses -TimeoutSeconds $TimeoutSeconds
    $requestedAt = [DateTimeOffset]::UtcNow
    & $StartAction
    return [pscustomobject][ordered]@{
        absence_proof = $absenceProof
        restart_requested_at = $requestedAt
    }
}

function Set-VerifiedManagerSuspended {
    param(
        [Parameter(Mandatory = $true)][int]$ProcessId,
        [Parameter(Mandatory = $true)][bool]$Suspend,
        [Parameter(Mandatory = $true)]$ExpectedIdentity
    )
    if (
        $ProcessId -le 0 -or
        $ProcessId -ne [int]$ExpectedIdentity.process_id -or
        [string]$ExpectedIdentity.role -ne 'MANAGER'
    ) {
        throw 'Suspend target does not match the frozen MANAGER process identity.'
    }
    $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if ($null -eq $process) {
        if ($Suspend) { throw 'Cannot suspend an absent legacy manager process.' }
        return
    }
    try {
        # Open the generation-bound kernel handle before revalidating the CIM
        # identity; PID reuse after this point cannot redirect the native call.
        $processHandle = $process.Handle
        $handleCreationUtcTicks = [int64]$process.StartTime.ToUniversalTime().Ticks
        if ($handleCreationUtcTicks -ne [int64]$ExpectedIdentity.handle_creation_utc_ticks) {
            throw "Cannot act on frozen MANAGER PID $ProcessId because its kernel generation changed."
        }
        $disposition = Get-BoundedFrozenProcessDisposition `
            -ExpectedIdentity $ExpectedIdentity `
            -TimeoutMilliseconds 2000
        if ($disposition -ne 'EXACT_ALIVE') {
            throw "Cannot safely suspend frozen MANAGER PID $ProcessId; disposition=$disposition."
        }
        if ($null -eq ('HeroEngineMaintenanceNative' -as [type])) {
            Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class HeroEngineMaintenanceNative {
    [DllImport("ntdll.dll")]
    public static extern int NtSuspendProcess(IntPtr processHandle);
    [DllImport("ntdll.dll")]
    public static extern int NtResumeProcess(IntPtr processHandle);
}
'@
        }
        $status = if ($Suspend) {
            [HeroEngineMaintenanceNative]::NtSuspendProcess($processHandle)
        }
        else {
            [HeroEngineMaintenanceNative]::NtResumeProcess($processHandle)
        }
        if ($status -ne 0) {
            throw "Native exact-generation suspend/resume failed with NTSTATUS $status."
        }
    }
    finally {
        $process.Dispose()
    }
}

function Invoke-HiddenProcess {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Stdout,
        [Parameter(Mandatory = $true)][string]$Stderr
    )
    $started = [DateTimeOffset]::UtcNow
    $process = Start-Process `
        -FilePath $testPython `
        -ArgumentList $Arguments `
        -WorkingDirectory $projectRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $Stdout `
        -RedirectStandardError $Stderr `
        -Wait `
        -PassThru
    return [ordered]@{
        exit_code = [int]$process.ExitCode
        duration_seconds = [math]::Round(([DateTimeOffset]::UtcNow - $started).TotalSeconds, 6)
    }
}

function Wait-MaintenanceAck {
    param(
        [Parameter(Mandatory = $true)][string]$ExpectedRequestId,
        [Parameter(Mandatory = $true)][int]$ExpectedManagerPid,
        [Parameter(Mandatory = $true)][int]$TimeoutSeconds
    )
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds($TimeoutSeconds)
    do {
        if (Test-Path -LiteralPath $ackPath -PathType Leaf) {
            try {
                $candidate = Get-Content -LiteralPath $ackPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if (
                    [string]$candidate.request_id -eq $ExpectedRequestId -and
                    [int]$candidate.manager_pid -eq $ExpectedManagerPid
                ) {
                    return $candidate
                }
            }
            catch {}
        }
        Start-Sleep -Milliseconds 250
    } while ([DateTimeOffset]::UtcNow -lt $deadline)
    throw "The Gestor Central did not ACK maintenance request $ExpectedRequestId from PID $ExpectedManagerPid."
}

try {
    if ($ProtectedDueGuardSeconds -lt $recoveryGuardSeconds) {
        throw 'ProtectedDueGuardSeconds must exceed FreshCycleTimeoutSeconds by at least 120 seconds.'
    }
    if (-not (Test-Path -LiteralPath $testPython -PathType Leaf)) {
        throw "The project virtual-environment Python is unavailable: $testPython"
    }
    # Maintenance verifies the already-approved power contract but does not
    # mutate OS power settings itself.
    & (Join-Path $PSScriptRoot 'ensure_power_continuity.ps1') -VerifyOnly | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Power-continuity verification failed with exit code $LASTEXITCODE."
    }

    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($null -eq $task -or [string]$task.State -ne 'Running') {
        throw "The required Gestor Central task '$taskName' is not running; maintenance cannot infer a process chain."
    }
    $taskActions = @($task.Actions)
    if ($taskActions.Count -ne 1 -or [string]$taskActions[0].Id -notin @('', $null)) {
        throw 'The Gestor Central ScheduledTask must expose exactly one execution action.'
    }
    $verifiedTaskAction = $taskActions[0]
    $managerWasRunning = $true
    if (Test-Path -LiteralPath $requestPath -PathType Leaf) {
        throw 'A prior maintenance request is still active; refusing to overwrite it.'
    }

    # Resolve and freeze the exact legacy process chain before creating the
    # request.  A resident version that predates the handshake cannot observe
    # the request, so waiting for an ACK first would leave a blind interval in
    # which it could still run OAuth, queue or publication work.
    $pidPath = Join-Path $runtimeDir 'manager.pid'
    $lockPath = Join-Path $runtimeDir 'manager-lock.json'
    $reviewPath = Join-Path $runtimeDir 'review-console-status.json'
    if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf) -or -not (Test-Path -LiteralPath $lockPath -PathType Leaf)) {
        throw 'The manager PID/lock chain is unavailable for maintenance.'
    }
    $initialChain = Get-CoherentManagerProcessChainSnapshot `
        -PidPath $pidPath `
        -LockPath $lockPath `
        -TimeoutSeconds 10
    $managerPid = [int]$initialChain.manager_pid
    $managerShimPid = [int]$initialChain.manager_shim_pid
    $launcherPid = [int]$initialChain.launcher_pid
    $lock = $initialChain.lock
    $managerProcess = $initialChain.manager_process
    $managerShim = $initialChain.manager_shim_process
    $launcher = $initialChain.launcher_process
    $managerIdentity = $initialChain.manager_identity
    $managerShimIdentity = $initialChain.manager_shim_identity
    $launcherIdentity = $initialChain.launcher_identity

    # Run every derived-view/error guard while the manager is still running
    # and before a request, suspension, task stop or run receipt exists.  A
    # failed preview therefore leaves the live process chain and runtime tree
    # untouched.  Its in-memory request-shaped ID is explicitly diagnostic and
    # is never accepted as maintenance authority.
    Push-Location $projectRoot
    try {
        $runtimeMigrationPreviewJson = (& $testPython -m hero_engine.maintenance_protocol preview-local-runtime) -join "`n"
        if ($LASTEXITCODE -ne 0) {
            throw 'Read-only local runtime migration preview failed before the maintenance boundary.'
        }
        $runtimeMigrationPreview = $runtimeMigrationPreviewJson | ConvertFrom-Json
    }
    finally {
        Pop-Location
    }
    if (
        [string]$runtimeMigrationPreview.mode -ne 'READ_ONLY_PREVIEW' -or
        [string]$runtimeMigrationPreview.request_authority -ne 'PREVIEW_NOT_AN_EXECUTION_REQUEST' -or
        $null -ne $runtimeMigrationPreview.active_request_id -or
        [string]$runtimeMigrationPreview.diagnostic_id -notmatch '^local-runtime-preview-[0-9a-f]{24}$' -or
        [int]$runtimeMigrationPreview.control_sources.stage_count -ne 12 -or
        $runtimeMigrationPreview.control_sources.all_schemas_valid -ne $true -or
        @($runtimeMigrationPreview.control_sources.blockers).Count -ne 0 -or
        [int]$runtimeMigrationPreview.external_api_calls -ne 0 -or
        [int]$runtimeMigrationPreview.operational_queue_mutations -ne 0 -or
        [int]$runtimeMigrationPreview.proofs_persisted -ne 0 -or
        [int]$runtimeMigrationPreview.runtime_views_persisted -ne 0 -or
        $runtimeMigrationPreview.receipt_committed -ne $false -or
        [decimal]$runtimeMigrationPreview.technical_cost_brl -ne 0 -or
        [string]$runtimeMigrationPreview.control_cycle_error.action -notin @(
            'NOT_PRESENT',
            'ARCHIVED_CORRELATED_LEGACY_RUNTIME',
            'ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE'
        )
    ) {
        throw 'Read-only local runtime migration preview did not prove every zero-effect pre-stop guard.'
    }
    New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null
    New-Item -ItemType Directory -Path $runDir -Force | Out-Null
    $runtimeMigrationPreviewPath = Join-Path $runDir 'local-runtime-migration-preview.json'
    Write-JsonAtomic -Value $runtimeMigrationPreview -Path $runtimeMigrationPreviewPath

    $capabilityMatches = $false
    if (Test-Path -LiteralPath $capabilityPath -PathType Leaf) {
        $capability = Get-Content -LiteralPath $capabilityPath -Raw -Encoding UTF8 | ConvertFrom-Json
        Push-Location $projectRoot
        try {
            & $testPython -m hero_engine.maintenance_protocol validate `
                --schema central_manager_maintenance_capability.schema.json `
                --document 'output/runtime/gestor-central/maintenance-capability.json' | Out-Null
            if ($LASTEXITCODE -ne 0) {
                throw 'The current manager maintenance capability is schema-invalid.'
            }
        }
        finally {
            Pop-Location
        }
        $capabilityMatches = (
            [int]$capability.manager_pid -eq $managerPid -and
            ([DateTimeOffset]$capability.holder_started_at).ToUniversalTime() -eq
                ([DateTimeOffset]$lock.holder_started_at).ToUniversalTime()
        )
        if (-not $capabilityMatches) {
            throw 'A maintenance capability exists but is not bound to the current PID/lock generation.'
        }
    }
    else {
        if (Test-Path -LiteralPath $bootstrapPath -PathType Leaf) {
            throw 'The one-time legacy maintenance bootstrap was already consumed; ACK is mandatory.'
        }
        if (-not (Test-Path -LiteralPath $reviewPath -PathType Leaf)) {
            throw 'Legacy bootstrap requires the exact live review-console receipt.'
        }
        $review = Get-Content -LiteralPath $reviewPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$review.status -ne 'LISTENING' -or [int]$review.process_id -ne $managerPid) {
            throw 'Legacy bootstrap review-console identity does not match the manager PID.'
        }
        Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true -ExpectedIdentity $managerIdentity
        $legacyManagerSuspended = $true
        $bootstrapSuspendedAt = [DateTimeOffset]::UtcNow
        $legacyBootstrapMode = $true
        # From this point forward recovery must stop/restart the exact chain
        # even if request creation or a later resume attempt fails.
        $restartRequired = $true
    }

    Push-Location $projectRoot
    try {
        & $testPython -m hero_engine.maintenance_protocol request `
            --request-id $requestId `
            --requester-pid $PID `
            --guard-seconds $ProtectedDueGuardSeconds | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Maintenance request validation failed with exit code $LASTEXITCODE."
        }
    }
    finally {
        Pop-Location
    }
    $requestCreated = $true
    $requestDocument = Get-Content -LiteralPath $requestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $maintenanceRequestedAt = ([DateTimeOffset]$requestDocument.requested_at).ToUniversalTime()

    $ack = $null
    if ($capabilityMatches) {
        $ackDeadline = [DateTimeOffset]::UtcNow.AddSeconds($HandshakeTimeoutSeconds)
        do {
            if (Test-Path -LiteralPath $ackPath -PathType Leaf) {
                try {
                    $candidateAck = Get-Content -LiteralPath $ackPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    if ([string]$candidateAck.request_id -eq $requestId) {
                        $ack = $candidateAck
                    }
                }
                catch {
                    $ack = $null
                }
            }
            if ($null -eq $ack) {
                Start-Sleep -Milliseconds 250
            }
        } while ($null -eq $ack -and [DateTimeOffset]::UtcNow -lt $ackDeadline)
    }
    $pidPath = Join-Path $runtimeDir 'manager.pid'
    $lockPath = Join-Path $runtimeDir 'manager-lock.json'
    $reviewPath = Join-Path $runtimeDir 'review-console-status.json'
    if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf) -or -not (Test-Path -LiteralPath $lockPath -PathType Leaf)) {
        throw 'The manager PID/lock chain is unavailable for maintenance.'
    }
    $currentChain = Get-CoherentManagerProcessChainSnapshot `
        -PidPath $pidPath `
        -LockPath $lockPath `
        -TimeoutSeconds 10
    if (
        [int]$currentChain.manager_pid -ne [int]$managerIdentity.process_id -or
        [int]$currentChain.manager_shim_pid -ne [int]$managerShimIdentity.process_id -or
        [int]$currentChain.launcher_pid -ne [int]$launcherIdentity.process_id
    ) {
        throw 'The manager PID file or parent chain changed after its original identity was frozen.'
    }
    foreach ($frozenIdentity in @($managerIdentity, $managerShimIdentity, $launcherIdentity)) {
        if ($null -eq $frozenIdentity -or (Get-FrozenProcessDisposition -ExpectedIdentity $frozenIdentity) -ne 'EXACT_ALIVE') {
            throw 'The originally verified manager process generation changed before the stop boundary.'
        }
    }
    $lock = $currentChain.lock
    $managerProcess = $currentChain.manager_process
    $managerShim = $currentChain.manager_shim_process
    $launcher = $currentChain.launcher_process

    Copy-Item -LiteralPath $requestPath -Destination $requestSnapshot
    if ($null -ne $ack) {
        Push-Location $projectRoot
        try {
            & $testPython -m hero_engine.maintenance_protocol validate `
                --schema central_manager_maintenance_ack.schema.json `
                --document 'output/runtime/gestor-central/maintenance-ack.json' | Out-Null
            if ($LASTEXITCODE -ne 0) {
                throw 'The Gestor Central maintenance ACK is schema-invalid.'
            }
        }
        finally {
            Pop-Location
        }
        if ([string]$ack.status -ne 'READY_TO_STOP' -or $ack.external_effect_boundary_closed -ne $true) {
            $reason = (@($ack.blockers) -join ',')
            throw "Maintenance was deferred without stopping runtime: $reason"
        }
        if ($managerPid -ne [int]$ack.manager_pid) {
            throw 'The maintenance ACK is not bound to the current PID/lock chain.'
        }
        Copy-Item -LiteralPath $ackPath -Destination $ackSnapshot
        $maintenanceEntryPath = $ackSnapshot
        $maintenanceEntryIdentity = [string]$ack.ack_id
        $zeroEffectBoundaryStartedAt = ([DateTimeOffset]$ack.observed_at).ToUniversalTime()
    }
    else {
        # One-time rollout bridge for a resident process that predates the
        # handshake code. A PID-matching capability permanently disables this
        # branch, as does any prior successful bootstrap receipt.
        $capabilityMatches = $false
        if (Test-Path -LiteralPath $capabilityPath -PathType Leaf) {
            try {
                $capability = Get-Content -LiteralPath $capabilityPath -Raw -Encoding UTF8 | ConvertFrom-Json
                $capabilityMatches = [int]$capability.manager_pid -eq $managerPid
            }
            catch {
                $capabilityMatches = $false
            }
        }
        if ($capabilityMatches) {
            throw 'A handshake-capable manager failed to ACK; legacy fallback is forbidden.'
        }
        if (Test-Path -LiteralPath $bootstrapPath -PathType Leaf) {
            throw 'The one-time legacy maintenance bootstrap was already consumed; ACK is mandatory.'
        }
        if (-not (Test-Path -LiteralPath $reviewPath -PathType Leaf)) {
            throw 'Legacy bootstrap requires the exact live review-console receipt.'
        }
        $review = Get-Content -LiteralPath $reviewPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$review.status -ne 'LISTENING' -or [int]$review.process_id -ne $managerPid) {
            throw 'Legacy bootstrap review-console identity does not match the manager PID.'
        }

        if (-not $legacyManagerSuspended) {
            Set-VerifiedManagerSuspended -ProcessId $managerPid -Suspend $true -ExpectedIdentity $managerIdentity
            $legacyManagerSuspended = $true
            $bootstrapSuspendedAt = [DateTimeOffset]::UtcNow
            $restartRequired = $true
        }
        # Hashes are captured only after the process is atomically frozen, so
        # the heartbeat and all operational threads cannot race this proof.
        $bootstrapPidHash = Get-Sha256 -Path $pidPath
        $bootstrapLockHash = Get-Sha256 -Path $lockPath
        $bootstrapReviewHash = Get-Sha256 -Path $reviewPath
        $inspectionRelative = $runRelative + '/legacy-quiescence.json'
        Push-Location $projectRoot
        try {
            & $testPython -m hero_engine.maintenance_protocol inspect `
                --manager-pid $managerPid `
                --guard-seconds $ProtectedDueGuardSeconds `
                --output $inspectionRelative | Out-Null
            if ($LASTEXITCODE -ne 0) {
                throw 'Legacy frozen-state quiescence inspection failed.'
            }
        }
        finally {
            Pop-Location
        }
        $inspectionPath = Join-Path $projectRoot ($inspectionRelative.Replace('/', '\'))
        $bootstrapInspection = Get-Content -LiteralPath $inspectionPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (@($bootstrapInspection.blockers).Count -ne 0) {
            throw ('Legacy bootstrap is not quiescent: ' + (@($bootstrapInspection.blockers) -join ','))
        }
        if ((Get-Sha256 -Path $pidPath) -ne $bootstrapPidHash -or (Get-Sha256 -Path $lockPath) -ne $bootstrapLockHash -or (Get-Sha256 -Path $reviewPath) -ne $bootstrapReviewHash) {
            throw 'Legacy PID/lock/console evidence changed while the exact process was suspended.'
        }
        $legacyBootstrapMode = $true
        $zeroEffectBoundaryStartedAt = $bootstrapSuspendedAt.ToUniversalTime()
    }

    if ($null -eq $maintenanceRequestedAt -or $null -eq $zeroEffectBoundaryStartedAt) {
        throw 'Maintenance lacks distinct request and effective zero-effect boundary timestamps.'
    }

    $restartRequired = $true
    Stop-ScheduledTask -TaskName $taskName
    $naturalDeadline = [DateTimeOffset]::UtcNow.AddSeconds(5)
    while ([DateTimeOffset]::UtcNow -lt $naturalDeadline) {
        if (-not (Test-FrozenProcessAlive -ProcessId $managerPid -Role MANAGER -ExpectedIdentity $managerIdentity) -and -not (Test-FrozenProcessAlive -ProcessId $managerShimPid -Role VENV_SHIM -ExpectedIdentity $managerShimIdentity) -and -not (Test-FrozenProcessAlive -ProcessId $launcherPid -Role LAUNCHER -ExpectedIdentity $launcherIdentity)) {
            break
        }
        Start-Sleep -Milliseconds 250
    }
    Stop-VerifiedProcess -ProcessId $managerPid -Role MANAGER -ExpectedIdentity $managerIdentity
    Stop-VerifiedProcess -ProcessId $managerShimPid -Role VENV_SHIM -ExpectedIdentity $managerShimIdentity
    Stop-VerifiedProcess -ProcessId $launcherPid -Role LAUNCHER -ExpectedIdentity $launcherIdentity
    $stopDeadline = [DateTimeOffset]::UtcNow.AddSeconds(20)
    do {
        $managerAlive = Test-FrozenProcessAlive -ProcessId $managerPid -Role MANAGER -ExpectedIdentity $managerIdentity
        $managerShimAlive = Test-FrozenProcessAlive -ProcessId $managerShimPid -Role VENV_SHIM -ExpectedIdentity $managerShimIdentity
        $launcherAlive = Test-FrozenProcessAlive -ProcessId $launcherPid -Role LAUNCHER -ExpectedIdentity $launcherIdentity
        if ($managerAlive -or $managerShimAlive -or $launcherAlive) {
            Start-Sleep -Milliseconds 250
        }
    } while (($managerAlive -or $managerShimAlive -or $launcherAlive) -and [DateTimeOffset]::UtcNow -lt $stopDeadline)
    if ($managerAlive -or $managerShimAlive -or $launcherAlive) {
        throw 'The verified Gestor Central process chain did not stop within the maintenance deadline.'
    }
    $managerChainStopped = $true
    $legacyManagerSuspended = $false

    if ($legacyBootstrapMode) {
        $bootstrapStoppedAt = [DateTimeOffset]::UtcNow
        $inspectionRelative = $runRelative + '/legacy-quiescence.json'
        $inspectionPath = Join-Path $projectRoot ($inspectionRelative.Replace('/', '\'))
        $bootstrapReceipt = [ordered]@{
            schema_version = '1.0.0'
            receipt_id = 'maintenance-bootstrap-' + $bootstrapStoppedAt.ToString('yyyyMMddTHHmmssfffffffZ') + '-' + ([guid]::NewGuid().ToString('N').Substring(0, 8))
            request_id = $requestId
            status = 'PASS'
            mode = 'LEGACY_ONE_TIME_SUSPEND_AND_INSPECT'
            one_time_fallback_consumed = $true
            capability_present_for_pid = $false
            manager_pid = $managerPid
            launcher_pid = $launcherPid
            suspended_at = $bootstrapSuspendedAt.ToString('o')
            stopped_at = $bootstrapStoppedAt.ToString('o')
            pid_path = 'output/runtime/gestor-central/manager.pid'
            pid_hash = $bootstrapPidHash
            lock_path = 'output/runtime/gestor-central/manager-lock.json'
            lock_hash = $bootstrapLockHash
            review_console_path = 'output/runtime/gestor-central/review-console-status.json'
            review_console_hash = $bootstrapReviewHash
            inspection_path = $inspectionRelative
            inspection_hash = Get-Sha256 -Path $inspectionPath
            queue_jobs_hash = [string]$bootstrapInspection.queue.jobs_hash
            active_lease_job_ids = @($bootstrapInspection.active_lease_job_ids)
            protected_due_job_ids = @($bootstrapInspection.protected_due_job_ids)
            operational_due_job_ids = @($bootstrapInspection.operational_due_job_ids)
            active_quota_reservation_ids = @($bootstrapInspection.quota.reserved_ids)
            open_effect_receipt_paths = @($bootstrapInspection.operational_effects.open_receipt_paths)
            external_effect_boundary_closed = $true
            technical_cost_brl = 0
            claim_boundary = @(
                'This is the single rollout bridge for a resident process loaded before the maintenance handshake existed.',
                'The exact manager PID was suspended before read-only PID, lock, console, queue, due-job and quota/effect inspection.',
                'After this immutable receipt exists, every maintenance attempt requires a PID-bound READY_TO_STOP ACK and no legacy fallback is permitted.'
            )
        }
        $bootstrapRunPath = Join-Path $runDir 'maintenance-bootstrap-receipt.json'
        Write-JsonAtomic -Value $bootstrapReceipt -Path $bootstrapRunPath
        Push-Location $projectRoot
        try {
            & $testPython -m hero_engine.maintenance_protocol validate `
                --schema central_manager_maintenance_bootstrap.schema.json `
                --document ($runRelative + '/maintenance-bootstrap-receipt.json') | Out-Null
            if ($LASTEXITCODE -ne 0) {
                throw 'The one-time maintenance bootstrap receipt is schema-invalid.'
            }
        }
        finally {
            Pop-Location
        }
        Copy-Item -LiteralPath $bootstrapRunPath -Destination $bootstrapPath
        $maintenanceEntryPath = $bootstrapPath
        $maintenanceEntryIdentity = [string]$bootstrapReceipt.receipt_id
    }

    # A new attempt cannot inherit the visible PASS of an older attempt.
    Archive-PreviousLatest -Path $regressionLatest -Category 'regression'
    Archive-PreviousLatest -Path $finalLatest -Category 'final'

    Push-Location $projectRoot
    try {
        $runtimeMigrationJson = (& $testPython -m hero_engine.maintenance_protocol migrate-local-runtime `
            --request-id $requestId `
            --former-manager-pid $managerPid `
            --former-launcher-pid $launcherPid `
            --evidence-dir $runRelative) -join "`n"
        if ($LASTEXITCODE -ne 0) {
            throw 'Barrier-safe local runtime migration failed.'
        }
        $runtimeMigration = $runtimeMigrationJson | ConvertFrom-Json
        if (
            [string]$runtimeMigration.status -ne 'PASS' -or
            [int]$runtimeMigration.stage_count -ne 12 -or
            $runtimeMigration.all_stage_schemas_valid -ne $true -or
            @($runtimeMigration.stage_blockers).Count -ne 0 -or
            [string]$runtimeMigration.queue_jobs_hash_before -ne [string]$runtimeMigration.queue_jobs_hash_after -or
            [string]$runtimeMigration.quota_ledger_hash_before -ne [string]$runtimeMigration.quota_ledger_hash_after -or
            [string]$runtimeMigration.operational_effects_hash_before -ne [string]$runtimeMigration.operational_effects_hash_after
        ) {
            throw 'Local runtime migration did not preserve the operational boundary or clean all 12 sources.'
        }

        $inventoryJson = (& $testPython -m hero_engine.maintenance_protocol inventory --output-dir $runRelative) -join "`n"
        if ($LASTEXITCODE -ne 0) {
            throw 'Test/schema inventory or Draft 2020-12 meta-validation failed.'
        }
        $inventory = $inventoryJson | ConvertFrom-Json

        # Start the measured stopped-regression interval at the real closed
        # boundary, then freeze every operational surface immediately before
        # compilation/tests. The external token path is redacted; its exact
        # bytes are represented by byte count and SHA-256.
        $stoppedBeforeRelative = $runRelative + '/stopped-operational-state-before-regression.json'
        $stoppedBeforePath = Join-Path $projectRoot ($stoppedBeforeRelative.Replace('/', '\'))
        $stoppedBefore = Write-StoppedOperationalSnapshot `
            -Role PRE_REGRESSION `
            -OutputPath $stoppedBeforePath `
            -FormerManagerPid $managerPid `
            -BoundaryStartedAt $zeroEffectBoundaryStartedAt
        $queueBeforeRelative = [string]$stoppedBefore.queue_path
        $queueBeforePath = Join-Path $projectRoot ($queueBeforeRelative.Replace('/', '\'))
        $queueBefore = [pscustomobject]@{ jobs_hash = [string]$stoppedBefore.queue_jobs_hash }

        $compileOutRelative = $runRelative + '/compileall.stdout.log'
        $compileErrRelative = $runRelative + '/compileall.stderr.log'
        $compileOut = Join-Path $projectRoot ($compileOutRelative.Replace('/', '\'))
        $compileErr = Join-Path $projectRoot ($compileErrRelative.Replace('/', '\'))
        $compile = Invoke-HiddenProcess `
            -Arguments @('-m', 'compileall', '-q', 'hero_engine', 'tests') `
            -Stdout $compileOut `
            -Stderr $compileErr
        if ($compile.exit_code -ne 0) {
            throw "compileall failed with exit code $($compile.exit_code)."
        }

        $testOutRelative = $runRelative + '/unittest.stdout.log'
        $testErrRelative = $runRelative + '/unittest.stderr.log'
        $testOut = Join-Path $projectRoot ($testOutRelative.Replace('/', '\'))
        $testErr = Join-Path $projectRoot ($testErrRelative.Replace('/', '\'))
        $tests = Invoke-HiddenProcess `
            -Arguments @('-m', 'unittest', 'discover', '-s', 'tests', '-v') `
            -Stdout $testOut `
            -Stderr $testErr
        $testInventoryPath = Join-Path $projectRoot (([string]$inventory.test_inventory_path).Replace('/', '\'))
        $testVerificationRaw = (& $testPython -m hero_engine.maintenance_unittest_result `
            --inventory $testInventoryPath `
            --stdout $testOut `
            --stderr $testErr `
            --exit-code ([string]$tests.exit_code))
        $testVerificationExitCode = $LASTEXITCODE
        if ($testVerificationExitCode -ne 0) {
            throw "Regression result verification failed with exit code $testVerificationExitCode; process exit=$($tests.exit_code); inspect $testErr."
        }
        $testVerification = Confirm-RegressionResult `
            -PythonPath $testPython -InventoryPath $testInventoryPath `
            -InventoryHash ([string]$inventory.test_inventory_hash) -ExpectedTestCount $inventory.test_count `
            -ProcessExitCode $tests.exit_code -StdoutPath $testOut -StderrPath $testErr `
            -ResultJson ($testVerificationRaw -join "`n")
        if (-not (
            [string]$testVerification.status -eq 'PASS' -and
            $testVerification.process_exit_code_verified -is [bool] -and
            $testVerification.process_exit_code_verified -eq $true
        )) {
            throw 'Regression result consumer did not preserve its execution-bound PASS projection.'
        }
        $executedTestCount = [int]$testVerification.test_count
        if ($executedTestCount -ne [int]$inventory.test_count) {
            throw "Test inventory/execution mismatch: inventoried=$($inventory.test_count), executed=$executedTestCount."
        }

        & $testPython 'scripts\build_phase5_integrity.py'
        if ($LASTEXITCODE -ne 0) {
            throw "Phase 5 integrity rebuild failed with exit code $LASTEXITCODE."
        }
        $integrityRelative = 'output/production/phase5/pilot-001/integrity_manifest.json'
        $integrityPath = Join-Path $projectRoot ($integrityRelative.Replace('/', '\'))
        $integrity = Get-Content -LiteralPath $integrityPath -Raw -Encoding UTF8 | ConvertFrom-Json

        # Nothing may intervene between the end of regression/integrity work
        # and this complete post-state capture.
        $stoppedAfterRelative = $runRelative + '/stopped-operational-state-after-regression.json'
        $stoppedAfterPath = Join-Path $projectRoot ($stoppedAfterRelative.Replace('/', '\'))
        $stoppedAfter = Write-StoppedOperationalSnapshot `
            -Role POST_REGRESSION `
            -OutputPath $stoppedAfterPath `
            -FormerManagerPid $managerPid `
            -BoundaryStartedAt $zeroEffectBoundaryStartedAt
        if ([string]$stoppedBefore.state_hash -ne [string]$stoppedAfter.state_hash) {
            throw 'Stopped regression changed queue, full quota ledger, operational effect receipts/surfaces or OAuth proof bytes.'
        }
        $queueAfterRelative = [string]$stoppedAfter.queue_path
        $queueAfterPath = Join-Path $projectRoot ($queueAfterRelative.Replace('/', '\'))
        $queueAfter = [pscustomobject]@{ jobs_hash = [string]$stoppedAfter.queue_jobs_hash }
        if ([string]$queueBefore.jobs_hash -ne [string]$queueAfter.jobs_hash) {
            throw 'Local maintenance changed Phase 6 jobs, checkpoints, attempts, leases or due times.'
        }

        $regressionCompletedAt = [DateTimeOffset]::UtcNow
        $regressionId = 'daily-regression-' + $regressionCompletedAt.ToString('yyyyMMddTHHmmssfffffffZ') + '-' + ([guid]::NewGuid().ToString('N').Substring(0, 8))
        $regressionReceipt = [ordered]@{
            schema_version = '1.2.0'
            receipt_id = $regressionId
            request_id = $requestId
            requested_at = $maintenanceRequestedAt.ToString('o')
            zero_effect_boundary_started_at = $zeroEffectBoundaryStartedAt.ToString('o')
            started_at = $zeroEffectBoundaryStartedAt.ToString('o')
            regression_completed_at = $regressionCompletedAt.ToString('o')
            status = 'PASS'
            mode = 'LOCAL_VALIDATION_ONLY'
            external_effects_permitted = $false
            external_api_calls = 0
            publication_effects = 0
            operational_queue_mutations = 0
            local_runtime_migration = $runtimeMigration
            compileall = [ordered]@{
                status = 'PASS'
                command = '.venv/Scripts/python.exe -m compileall -q hero_engine tests'
                duration_seconds = [double]$compile.duration_seconds
                stdout_log = $compileOutRelative
                stdout_hash = Get-Sha256 -Path $compileOut
                stderr_log = $compileErrRelative
                stderr_hash = Get-Sha256 -Path $compileErr
            }
            schemas = [ordered]@{
                status = 'PASS'
                schema_count = [int]$inventory.schema_count
                inventory_path = [string]$inventory.schema_inventory_path
                inventory_hash = [string]$inventory.schema_inventory_hash
            }
            tests = [ordered]@{
                status = 'PASS'
                command = '.venv/Scripts/python.exe -m unittest discover -s tests -v'
                test_count = $executedTestCount
                file_count = [int]$inventory.test_file_count
                duration_seconds = [double]$tests.duration_seconds
                inventory_path = [string]$inventory.test_inventory_path
                inventory_hash = [string]$inventory.test_inventory_hash
                stdout_log = $testOutRelative
                stdout_hash = Get-Sha256 -Path $testOut
                stderr_log = $testErrRelative
                stderr_hash = Get-Sha256 -Path $testErr
            }
            queue = [ordered]@{
                before_path = $queueBeforeRelative
                before_hash = Get-Sha256 -Path $queueBeforePath
                before_jobs_hash = [string]$queueBefore.jobs_hash
                after_path = $queueAfterRelative
                after_hash = Get-Sha256 -Path $queueAfterPath
                after_jobs_hash = [string]$queueAfter.jobs_hash
                unchanged = $true
            }
            stopped_state = [ordered]@{
                before_path = $stoppedBeforeRelative
                before_hash = Get-Sha256 -Path $stoppedBeforePath
                before_state_hash = [string]$stoppedBefore.state_hash
                after_path = $stoppedAfterRelative
                after_hash = Get-Sha256 -Path $stoppedAfterPath
                after_state_hash = [string]$stoppedAfter.state_hash
                queue_unchanged = $true
                quota_ledger_unchanged = $true
                operational_effects_unchanged = $true
                effect_surfaces_unchanged = $true
                oauth_proofs_unchanged = $true
            }
            integrity = [ordered]@{
                manifest_path = $integrityRelative
                content_hash = Get-Sha256 -Path $integrityPath
                item_count = [int]$integrity.item_count
                total_bytes = [int64]$integrity.total_bytes
            }
            technical_cost_brl = 0
            claim_boundary = @(
                'This receipt proves only the barrier-safe derived-view migration, local compile, schema meta-validation, exact test discovery, regression and integrity against a stopped stable process chain.',
                'No API, upload, publication, media execution, queue claim, attempt increment or due-time change is permitted by this receipt.',
                'Runtime recovery and a fresh byte-bound 12-stage cycle are separate mandatory evidence and must precede the final maintenance receipt.'
            )
        }
        $regressionRunPath = Join-Path $runDir 'regression-receipt.json'
        Write-JsonAtomic -Value $regressionReceipt -Path $regressionRunPath
        & $testPython -m hero_engine.maintenance_protocol validate `
            --schema daily_maintenance_regression_receipt.schema.json `
            --document ($runRelative + '/regression-receipt.json') | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw 'The stable-snapshot regression receipt is schema-invalid.'
        }
        Copy-Item -LiteralPath $regressionRunPath -Destination $regressionLatest
        $bodySucceeded = $true
    }
    finally {
        Pop-Location
    }
}
catch {
    $failure = $_
}
finally {
    try {
        # A request command can fail after its atomic write. Discover only our
        # exact request ID so cleanup cannot strand the manager behind an
        # untracked barrier and cannot claim a foreign request.
        if (-not $requestCreated -and (Test-Path -LiteralPath $requestPath -PathType Leaf)) {
            try {
                $discoveredRequest = Get-Content -LiteralPath $requestPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([string]$discoveredRequest.request_id -eq $requestId) { $requestCreated = $true }
            }
            catch {}
        }
        # Once a legacy runtime has been suspended it must never be resumed:
        # that process predates the maintenance barrier and could perform an
        # external effect in the interval before an exact-chain stop.  Keep it
        # suspended and recover only by terminating the verified chain and
        # starting the ScheduledTask with current code.
        if ($legacyManagerSuspended) {
            $restartRequired = $true
        }
        # Preserve the initial handshake, but keep the request in place while
        # the new runtime proves PID/lock/console/singleton/power.  Releasing it
        # before restart would allow OAuth/API/queue work before maintenance is
        # able to prove a zero-effect boundary.
        if ($requestCreated) {
            if ((Test-Path -LiteralPath $requestPath -PathType Leaf) -and -not (Test-Path -LiteralPath $requestSnapshot -PathType Leaf)) {
                Copy-Item -LiteralPath $requestPath -Destination $requestSnapshot
            }
            if ((Test-Path -LiteralPath $ackPath -PathType Leaf) -and -not (Test-Path -LiteralPath $ackSnapshot -PathType Leaf)) {
                Copy-Item -LiteralPath $ackPath -Destination $ackSnapshot
            }
        }

        if ($restartRequired -and $managerWasRunning) {
            # If the body failed between task stop and its normal shutdown,
            # finish stopping only the exact pre-ACK process chain before
            # recovering the scheduled runtime.
            $frozenProcessChain = @($managerIdentity, $managerShimIdentity, $launcherIdentity)
            if (@($frozenProcessChain | Where-Object { $null -ne $_ }).Count -ne 3) {
                throw 'ScheduledTask restart blocked because the original process identities were not fully frozen.'
            }
            $preRestartStopFailures = @()
            foreach ($stopTarget in @(
                [pscustomobject]@{ ProcessId = $managerPid; Role = 'MANAGER'; Identity = $managerIdentity },
                [pscustomobject]@{ ProcessId = $managerShimPid; Role = 'VENV_SHIM'; Identity = $managerShimIdentity },
                [pscustomobject]@{ ProcessId = $launcherPid; Role = 'LAUNCHER'; Identity = $launcherIdentity }
            )) {
                try {
                    Stop-VerifiedProcess -ProcessId $stopTarget.ProcessId -Role $stopTarget.Role -ExpectedIdentity $stopTarget.Identity
                }
                catch {
                    $preRestartStopFailures += "$($stopTarget.Role):$($stopTarget.ProcessId):$($_.Exception.Message)"
                }
            }
            try {
                $restartAttempt = Invoke-VerifiedScheduledTaskRestart `
                    -FrozenProcesses $frozenProcessChain `
                    -TimeoutSeconds 20 `
                    -StartAction { Start-ScheduledTask -TaskName $taskName }
                $preRestartAbsenceProof = $restartAttempt.absence_proof
                $restartRequestedAt = ([DateTimeOffset]$restartAttempt.restart_requested_at).ToUniversalTime()
            }
            catch {
                $stopFailureDetail = if ($preRestartStopFailures.Count -gt 0) { '; stop_failures=' + ($preRestartStopFailures -join '|') } else { '' }
                throw "ScheduledTask was not restarted because exact-chain absence remained unproven: $($_.Exception.Message)$stopFailureDetail"
            }
            $restartDeadline = [DateTimeOffset]::UtcNow.AddSeconds(90)
            $runtimeReady = $false
            do {
                Start-Sleep -Milliseconds 500
                $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
                $pidPath = Join-Path $runtimeDir 'manager.pid'
                $lockPath = Join-Path $runtimeDir 'manager-lock.json'
                $newCapabilityPath = Join-Path $runtimeDir 'maintenance-capability.json'
                $newReviewPath = Join-Path $runtimeDir 'review-console-status.json'
                if ($null -ne $task -and [string]$task.State -eq 'Running' -and (Test-Path -LiteralPath $pidPath -PathType Leaf) -and (Test-Path -LiteralPath $lockPath -PathType Leaf) -and (Test-Path -LiteralPath $newCapabilityPath -PathType Leaf) -and (Test-Path -LiteralPath $newReviewPath -PathType Leaf)) {
                    try {
                        $newPid = [int](Get-Content -LiteralPath $pidPath -Raw)
                        $newLock = Get-Content -LiteralPath $lockPath -Raw -Encoding UTF8 | ConvertFrom-Json
                        $lockStartedAt = [DateTimeOffset]$newLock.holder_started_at
                        $newManager = Assert-ProcessRole -ProcessId $newPid -Role MANAGER
                        $newManagerShimPid = [int]$newManager.ParentProcessId
                        $newManagerShim = Assert-ProcessRole -ProcessId $newManagerShimPid -Role VENV_SHIM
                        $newLauncherPid = [int]$newManagerShim.ParentProcessId
                        $newLauncher = Assert-ProcessRole -ProcessId $newLauncherPid -Role LAUNCHER
                        $newCapability = Get-Content -LiteralPath $newCapabilityPath -Raw -Encoding UTF8 | ConvertFrom-Json
                        $newReview = Get-Content -LiteralPath $newReviewPath -Raw -Encoding UTF8 | ConvertFrom-Json
                        $runtimeReady = (
                            $newPid -gt 0 -and
                            $newPid -ne $managerPid -and
                            [int]$newLock.holder_pid -eq $newPid -and
                            [string]$newLock.state -eq 'HELD' -and
                            $lockStartedAt.ToUniversalTime() -ge $restartRequestedAt.ToUniversalTime() -and
                            [int]$newCapability.manager_pid -eq $newPid -and
                            ([DateTimeOffset]$newCapability.holder_started_at).ToUniversalTime() -eq $lockStartedAt.ToUniversalTime() -and
                            ([DateTimeOffset]$newCapability.advertised_at).ToUniversalTime() -ge $restartRequestedAt.ToUniversalTime() -and
                            [string]$newCapability.manager_source_hash -eq (Get-Sha256 -Path (Join-Path $projectRoot 'hero_engine\central_manager_phase5.py')) -and
                            [string]$newCapability.protocol_source_hash -eq (Get-Sha256 -Path (Join-Path $projectRoot 'hero_engine\maintenance_protocol.py')) -and
                            [string]$newReview.status -eq 'LISTENING' -and
                            [int]$newReview.process_id -eq $newPid -and
                            [int]$newManager.ParentProcessId -eq $newManagerShimPid -and
                            [int]$newManagerShim.ParentProcessId -eq $newLauncherPid
                        )
                    }
                    catch {
                        $runtimeReady = $false
                    }
                }
            } while (-not $runtimeReady -and [DateTimeOffset]::UtcNow -lt $restartDeadline)
            if (-not $runtimeReady) {
                throw 'The Gestor Central did not establish a fresh schema-ready manager -> venv shim -> ScheduledTask launcher chain.'
            }

            Push-Location $projectRoot
            try {
                & $testPython -m hero_engine.maintenance_protocol validate --schema central_manager_maintenance_capability.schema.json --document 'output/runtime/gestor-central/maintenance-capability.json' | Out-Null
                if ($LASTEXITCODE -ne 0) { throw 'Restarted-manager capability is schema-invalid.' }
                & $testPython -m hero_engine.maintenance_protocol validate --schema phase5_review_console_runtime.schema.json --document 'output/runtime/gestor-central/review-console-status.json' | Out-Null
                if ($LASTEXITCODE -ne 0) { throw 'Restarted-manager review console is schema-invalid.' }
            }
            finally { Pop-Location }
            $newLock = Get-Content -LiteralPath $lockPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $newCapability = Get-Content -LiteralPath $newCapabilityPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $newReview = Get-Content -LiteralPath $newReviewPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([int]$newLock.holder_pid -ne $newPid -or [int]$newCapability.manager_pid -ne $newPid -or [int]$newReview.process_id -ne $newPid -or ([DateTimeOffset]$newCapability.holder_started_at).ToUniversalTime() -ne ([DateTimeOffset]$newLock.holder_started_at).ToUniversalTime()) {
                throw 'Restarted runtime identity changed during schema verification.'
            }

            $verifyOut = Join-Path $runDir 'runtime-verification.stdout.log'
            $verifyErr = Join-Path $runDir 'runtime-verification.stderr.log'
            $verifier = Start-Process `
                -FilePath 'powershell.exe' `
                -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + (Join-Path $PSScriptRoot 'verify_phase5_manager_autostart.ps1') + '"')) `
                -WorkingDirectory $projectRoot `
                -WindowStyle Hidden `
                -RedirectStandardOutput $verifyOut `
                -RedirectStandardError $verifyErr `
                -Wait `
                -PassThru
            if ($verifier.ExitCode -ne 0) {
                throw "Post-maintenance runtime verification failed with exit code $($verifier.ExitCode)."
            }

            if ($bodySucceeded) {
                # The restarted PID must acknowledge the still-active original
                # barrier.  This also proves the deployed process actually has
                # the maintenance protocol; bootstrap fallback is never used
                # after restart.
                $restartAck = Wait-MaintenanceAck `
                    -ExpectedRequestId $requestId `
                    -ExpectedManagerPid $newPid `
                    -TimeoutSeconds $HandshakeTimeoutSeconds
                if ([string]$restartAck.status -ne 'READY_TO_STOP' -or $restartAck.external_effect_boundary_closed -ne $true) {
                    throw ('Restarted manager did not reach a closed maintenance boundary: ' + (@($restartAck.blockers) -join ','))
                }
                Push-Location $projectRoot
                try {
                    & $testPython -m hero_engine.maintenance_protocol validate `
                        --schema central_manager_maintenance_ack.schema.json `
                        --document 'output/runtime/gestor-central/maintenance-ack.json' | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Restarted-manager maintenance ACK is schema-invalid.' }

                    $preBoundaryRelative = $runRelative + '/operational-boundary-before-release.json'
                    & $testPython -m hero_engine.maintenance_protocol boundary `
                        --request-id $requestId `
                        --manager-pid $newPid `
                        --guard-seconds $recoveryGuardSeconds `
                        --role PRE_RELEASE `
                        --require-barrier true `
                        --output $preBoundaryRelative | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Pre-release operational boundary capture failed.' }
                }
                finally {
                    Pop-Location
                }
                $preBoundaryPath = Join-Path $projectRoot ($preBoundaryRelative.Replace('/', '\'))
                $preBoundary = Get-Content -LiteralPath $preBoundaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($preBoundary.external_effect_boundary_closed -ne $true -or @($preBoundary.blockers).Count -ne 0) {
                    throw ('Pre-release boundary is not closed: ' + (@($preBoundary.blockers) -join ','))
                }

                # Arm one local, no-external-effect, barrier-held 12-stage
                # revalidation. The only manager writes are its cycle receipt,
                # immutable source snapshots and optional immutable history twin. The
                # request is deliberately NOT removed: no operational executor,
                # queue mutation, OAuth probe or provider effect can run.
                $recoveryMonotonicClock = [System.Diagnostics.Stopwatch]::StartNew()
                Push-Location $projectRoot
                try {
                    & $testPython -m hero_engine.maintenance_protocol arm-recovery `
                        --request-id $requestId `
                        --manager-pid $newPid `
                        --duration-seconds $recoveryGuardSeconds | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Could not arm the bounded recovery window.' }
                }
                finally {
                    Pop-Location
                }
                $recoveryWindowSnapshot = Join-Path $runDir 'maintenance-recovery-window.json'
                Copy-Item -LiteralPath $recoveryWindowPath -Destination $recoveryWindowSnapshot
                $recoveryWindow = Get-Content -LiteralPath $recoveryWindowSnapshot -Raw -Encoding UTF8 | ConvertFrom-Json
                $recoveryWindowBudgetSeconds = (
                    ([DateTimeOffset]$recoveryWindow.expires_at).ToUniversalTime() -
                    ([DateTimeOffset]$recoveryWindow.armed_at).ToUniversalTime()
                ).TotalSeconds
                Assert-RecoveryWindowRemaining `
                    -Clock $recoveryMonotonicClock `
                    -BudgetSeconds $recoveryWindowBudgetSeconds `
                    -MinimumRemainingSeconds ($FreshCycleTimeoutSeconds + $postCycleValidationBudgetSeconds + $recoverySafetyMarginSeconds) `
                    -Boundary 'ARMED'
                $cyclePath = Join-Path $projectRoot 'output\operations\phase6\control-cycle\latest.json'
                $cycleDeadline = [DateTimeOffset]::UtcNow.AddSeconds($FreshCycleTimeoutSeconds)
                $freshCycle = $null
                do {
                    if (Test-Path -LiteralPath $cyclePath -PathType Leaf) {
                        try {
                            $candidateCycle = Get-Content -LiteralPath $cyclePath -Raw -Encoding UTF8 | ConvertFrom-Json
                            $cycleStarted = [DateTimeOffset]$candidateCycle.cycle_started_at
                            if (
                                [string]$candidateCycle.schema_version -eq '1.1.0' -and
                                [int]$candidateCycle.stage_count -eq 12 -and
                                [int]$candidateCycle.expected_stage_count -eq 12 -and
                                $candidateCycle.all_schemas_valid -eq $true -and
                                $candidateCycle.all_stages_executed_in_cycle -eq $true -and
                                @($candidateCycle.blockers).Count -eq 0 -and
                                [string]$candidateCycle.decision -in @('PASS_WAITING', 'PASS_ADVANCED') -and
                                [string]$candidateCycle.cycle_mode -eq 'MAINTENANCE_REVALIDATION' -and
                                [string]$candidateCycle.maintenance_window_id -eq [string]$recoveryWindow.window_id -and
                                $cycleStarted.ToUniversalTime() -ge $regressionCompletedAt.ToUniversalTime() -and
                                $cycleStarted.ToUniversalTime() -ge ([DateTimeOffset]$recoveryWindow.armed_at).ToUniversalTime()
                            ) {
                                $freshCycle = $candidateCycle
                            }
                        }
                        catch {
                            $freshCycle = $null
                        }
                    }
                    if ($null -eq $freshCycle) {
                        Start-Sleep -Milliseconds 500
                    }
                } while ($null -eq $freshCycle -and [DateTimeOffset]::UtcNow -lt $cycleDeadline)
                if ($null -eq $freshCycle) {
                    throw 'No fresh integral Phase 6 12/12 cycle appeared after the stable regression receipt.'
                }
                Assert-RecoveryWindowRemaining `
                    -Clock $recoveryMonotonicClock `
                    -BudgetSeconds $recoveryWindowBudgetSeconds `
                    -MinimumRemainingSeconds ($postCycleValidationBudgetSeconds + $recoverySafetyMarginSeconds) `
                    -Boundary 'FRESH_CYCLE'

                Push-Location $projectRoot
                try {
                    & $testPython -m hero_engine.phase6_acceptance | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Post-cycle acceptance reconciliation failed.' }
                    & $testPython -m hero_engine.phase6_reporting | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Post-cycle executive reconciliation failed.' }
                    & $testPython -m hero_engine.phase6_maintenance_verification | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Post-maintenance byte-bound verification failed.' }

                    Assert-RecoveryWindowRemaining `
                        -Clock $recoveryMonotonicClock `
                        -BudgetSeconds $recoveryWindowBudgetSeconds `
                        -MinimumRemainingSeconds $recoverySafetyMarginSeconds `
                        -Boundary 'PRE_POST_BOUNDARY'

                    $postBoundaryRelative = $runRelative + '/operational-boundary-after-cycle.json'
                    & $testPython -m hero_engine.maintenance_protocol boundary `
                        --request-id $requestId `
                        --manager-pid $newPid `
                        --guard-seconds $recoveryGuardSeconds `
                        --role POST_CYCLE `
                        --require-barrier true `
                        --output $postBoundaryRelative | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw 'Post-cycle operational boundary capture failed.' }
                }
                finally {
                    Pop-Location
                }

                $postBoundaryPath = Join-Path $projectRoot ($postBoundaryRelative.Replace('/', '\'))
                $postBoundary = Get-Content -LiteralPath $postBoundaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($postBoundary.external_effect_boundary_closed -ne $true -or @($postBoundary.blockers).Count -ne 0) {
                    throw ('Post-cycle boundary is not closed: ' + (@($postBoundary.blockers) -join ','))
                }
                Assert-RecoveryWindowRemaining `
                    -Clock $recoveryMonotonicClock `
                    -BudgetSeconds $recoveryWindowBudgetSeconds `
                    -MinimumRemainingSeconds 1 `
                    -Boundary 'POST_BOUNDARY'
                if (
                    [string]$preBoundary.queue_jobs_hash -ne [string]$postBoundary.queue_jobs_hash -or
                    [string]$preBoundary.quota_ledger_state_hash -ne [string]$postBoundary.quota_ledger_state_hash -or
                    [string]$preBoundary.operational_effects_hash -ne [string]$postBoundary.operational_effects_hash -or
                    [string]$preBoundary.effect_surfaces_hash -ne [string]$postBoundary.effect_surfaces_hash -or
                    [string]$preBoundary.oauth.refresh_hash -ne [string]$postBoundary.oauth.refresh_hash -or
                    [string]$preBoundary.oauth.refresh_receipt_id -ne [string]$postBoundary.oauth.refresh_receipt_id -or
                    [string]$preBoundary.oauth.refresh_tested_at -ne [string]$postBoundary.oauth.refresh_tested_at -or
                    [string]$preBoundary.oauth.health_hash -ne [string]$postBoundary.oauth.health_hash -or
                    [string]$preBoundary.oauth.watcher_hash -ne [string]$postBoundary.oauth.watcher_hash -or
                    [string]$preBoundary.oauth.mirror_hash -ne [string]$postBoundary.oauth.mirror_hash -or
                    [string]$preBoundary.oauth.connection_hash -ne [string]$postBoundary.oauth.connection_hash -or
                    [string]$preBoundary.oauth.capability_hash -ne [string]$postBoundary.oauth.capability_hash -or
                    [string]$preBoundary.oauth.runtime_token_hash -ne [string]$postBoundary.oauth.runtime_token_hash
                ) {
                        throw 'The barrier-held revalidation changed queue, quota ledger, operational effects or OAuth remote-proof state.'
                }

                $runtimeVerificationPath = Join-Path $runtimeDir 'autostart-verification.json'
                $postPath = Join-Path $projectRoot 'output\operations\phase6\post-maintenance-verification\latest.json'
                $regressionReceipt = Get-Content -LiteralPath $regressionLatest -Raw -Encoding UTF8 | ConvertFrom-Json
                $runtimeVerification = Get-Content -LiteralPath $runtimeVerificationPath -Raw -Encoding UTF8 | ConvertFrom-Json
                $freshCycle = Get-Content -LiteralPath $cyclePath -Raw -Encoding UTF8 | ConvertFrom-Json
                $post = Get-Content -LiteralPath $postPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([string]$post.maintenance.receipt_id -ne [string]$regressionReceipt.receipt_id -or [string]$post.control_cycle.cycle_id -ne [string]$freshCycle.cycle_id) {
                    throw 'Post-maintenance verification is not bound to this regression and control cycle.'
                }

                $completedAt = [DateTimeOffset]::UtcNow
                $finalReceipt = [ordered]@{
                    schema_version = '2.1.0'
                    receipt_id = 'daily-maintenance-' + $completedAt.ToString('yyyyMMddTHHmmssfffffffZ') + '-' + ([guid]::NewGuid().ToString('N').Substring(0, 8))
                    request_id = $requestId
                    started_at = $zeroEffectBoundaryStartedAt.ToString('o')
                    completed_at = $completedAt.ToString('o')
                    status = 'PASS'
                    regression = [ordered]@{
                        path = 'output/runtime/gestor-central/daily-maintenance-regression-receipt.json'
                        content_hash = Get-Sha256 -Path $regressionLatest
                        identity = [string]$regressionReceipt.receipt_id
                    }
                    maintenance_request = [ordered]@{
                        path = $runRelative + '/maintenance-request.json'
                        content_hash = Get-Sha256 -Path $requestSnapshot
                        identity = $requestId
                    }
                    maintenance_quiescence = [ordered]@{
                        path = if ($legacyBootstrapMode) { 'output/runtime/gestor-central/maintenance-bootstrap-receipt.json' } else { $runRelative + '/maintenance-ack.json' }
                        content_hash = Get-Sha256 -Path $maintenanceEntryPath
                        identity = $maintenanceEntryIdentity
                    }
                    runtime_verification = [ordered]@{
                        path = 'output/runtime/gestor-central/autostart-verification.json'
                        content_hash = Get-Sha256 -Path $runtimeVerificationPath
                        identity = [string]$runtimeVerification.verification_id
                    }
                    control_cycle = [ordered]@{
                        path = 'output/operations/phase6/control-cycle/latest.json'
                        content_hash = Get-Sha256 -Path $cyclePath
                        identity = [string]$freshCycle.cycle_id
                    }
                    post_maintenance_verification = [ordered]@{
                        path = 'output/operations/phase6/post-maintenance-verification/latest.json'
                        content_hash = Get-Sha256 -Path $postPath
                        identity = [string]$post.verification_id
                    }
                    operational_boundary = [ordered]@{
                        guard_seconds = $recoveryGuardSeconds
                        barrier_held_through_validation = $true
                        before_path = $preBoundaryRelative
                        before_hash = Get-Sha256 -Path $preBoundaryPath
                        before_identity = [string]$preBoundary.boundary_id
                        recovery_window_path = $runRelative + '/maintenance-recovery-window.json'
                        recovery_window_hash = Get-Sha256 -Path $recoveryWindowSnapshot
                        recovery_window_identity = [string]$recoveryWindow.window_id
                        after_path = $postBoundaryRelative
                        after_hash = Get-Sha256 -Path $postBoundaryPath
                        after_identity = [string]$postBoundary.boundary_id
                        queue_unchanged = $true
                        quota_ledger_unchanged = $true
                        operational_effects_unchanged = $true
                        effect_surfaces_unchanged = $true
                        oauth_refresh_unchanged = $true
                    }
                    external_api_calls = 0
                    publication_effects = 0
                    operational_queue_mutations = 0
                    technical_cost_brl = 0
                    claim_boundary = @(
                        'PASS exists only after the stopped-chain regression, barrier-protected resident restart, singleton verification and one new twelve-stage cycle were all proven.',
                        'The recovery cycle was a barrier-held local no-external-effect revalidation; its permitted writes were limited to control-cycle evidence, and queue, quota-ledger, operational-effect and OAuth remote-proof hashes remained unchanged.',
                        'This receipt does not authorize publication, spend, phase promotion or relaxation of any independent gate.'
                    )
                }
                $finalRunPath = Join-Path $runDir 'final-receipt.json'
                Write-JsonAtomic -Value $finalReceipt -Path $finalRunPath
                Push-Location $projectRoot
                try {
                    & $testPython -m hero_engine.maintenance_protocol validate `
                        --schema daily_maintenance_receipt.schema.json `
                        --document ($runRelative + '/final-receipt.json') | Out-Null
                    if ($LASTEXITCODE -ne 0) {
                        throw 'The final maintenance receipt is schema-invalid.'
                    }
                }
                finally {
                    Pop-Location
                }
                # Publish the latest PASS only after every owned barrier file
                # has been removed and its absence verified in the outer
                # recovery finally.
                $finalCandidatePath = $finalRunPath
            }
        }
    }
    catch {
        $recoveryFailure = $_
    }
    finally {
        # Persist the recovery outcome before removing whichever barrier is
        # active.  On failure this leaves an exact local trail while still
        # returning a live manager to its normal schedule.
        if ($requestCreated) {
            try {
                $activeRequestHash = if (Test-Path -LiteralPath $requestPath -PathType Leaf) { Get-Sha256 -Path $requestPath } else { $null }
                $activeAckHash = if (Test-Path -LiteralPath $ackPath -PathType Leaf) { Get-Sha256 -Path $ackPath } else { $null }
                $recoveryOutcome = [ordered]@{
                    request_id = $requestId
                    status = if ($null -eq $failure -and $null -eq $recoveryFailure -and $null -ne $finalCandidatePath -and (Test-Path -LiteralPath $finalCandidatePath -PathType Leaf)) { 'PASS' } else { 'FAIL' }
                    primary_failure = if ($null -ne $failure) { $failure.Exception.Message } else { $null }
                    recovery_failure = if ($null -ne $recoveryFailure) { $recoveryFailure.Exception.Message } else { $null }
                    manager_pid_before = $managerPid
                    manager_pid_after = if ($null -ne $newPid) { $newPid } else { $null }
                    pre_restart_exact_chain_absence = $preRestartAbsenceProof
                    active_request_hash_before_release = $activeRequestHash
                    active_ack_hash_before_release = $activeAckHash
                    captured_at = [DateTimeOffset]::UtcNow.ToString('o')
                }
                Write-JsonAtomic -Value $recoveryOutcome -Path (Join-Path $runDir 'recovery-outcome.json')
            }
            catch {
                if ($null -eq $recoveryFailure) { $recoveryFailure = $_ }
            }
            finally {
                try {
                    # The request is the fail-closed barrier and is therefore
                    # removed LAST. Every file must still prove ownership by
                    # this request ID; transient OneDrive locks receive a
                    # bounded retry instead of leaving the manager inert.
                    Remove-OwnedBarrierFileBounded -Path $recoveryWindowPath -ExpectedRequestId $requestId
                    Remove-OwnedBarrierFileBounded -Path $ackPath -ExpectedRequestId $requestId
                    Remove-OwnedBarrierFileBounded -Path $requestPath -ExpectedRequestId $requestId
                    Wait-BarrierReleaseSettled -ExpectedRequestId $requestId
                    foreach ($barrierPath in @($recoveryWindowPath, $ackPath, $requestPath)) {
                        if (Test-Path -LiteralPath $barrierPath -PathType Leaf) {
                            throw "Maintenance barrier remained present after bounded release: $barrierPath"
                        }
                    }
                }
                catch {
                    $releaseFailureMessage = $_.Exception.Message
                    if ($null -eq $recoveryFailure) { $recoveryFailure = $_ }
                    try {
                        $incident = [ordered]@{
                            request_id = $requestId
                            status = 'BARRIER_RELEASE_FAILED'
                            operational_ready = $false
                            error = $releaseFailureMessage
                            request_present = Test-Path -LiteralPath $requestPath -PathType Leaf
                            ack_present = Test-Path -LiteralPath $ackPath -PathType Leaf
                            recovery_window_present = Test-Path -LiteralPath $recoveryWindowPath -PathType Leaf
                            observed_at = [DateTimeOffset]::UtcNow.ToString('o')
                        }
                        Write-JsonAtomic -Value $incident -Path (Join-Path $runDir 'barrier-release-incident.json')
                        if ($null -ne $recoveryOutcome) {
                            $recoveryOutcome.status = 'FAIL'
                            $recoveryOutcome.recovery_failure = $releaseFailureMessage
                            $recoveryOutcome.captured_at = [DateTimeOffset]::UtcNow.ToString('o')
                            Write-JsonAtomic -Value $recoveryOutcome -Path (Join-Path $runDir 'recovery-outcome.json')
                        }
                    }
                    catch {}
                }
            }
        }
    }
}

if ($null -eq $failure -and $null -eq $recoveryFailure -and $null -ne $finalCandidatePath) {
    Copy-Item -LiteralPath $finalCandidatePath -Destination $finalLatest
}

if ($null -ne $failure) {
    if ($null -ne $recoveryFailure) {
        throw "Maintenance failed: $($failure.Exception.Message) Runtime recovery also failed: $($recoveryFailure.Exception.Message)"
    }
    throw $failure
}
if ($null -ne $recoveryFailure) {
    throw $recoveryFailure
}
if (-not $bodySucceeded -or -not (Test-Path -LiteralPath $finalLatest -PathType Leaf)) {
    throw 'Maintenance ended without a schema-valid final PASS receipt.'
}

Write-Output $finalLatest
}
finally {
    if ($maintenanceMutexAcquired) {
        try { $maintenanceMutex.ReleaseMutex() } catch {}
    }
    if ($null -ne $maintenanceMutex) { $maintenanceMutex.Dispose() }
}
