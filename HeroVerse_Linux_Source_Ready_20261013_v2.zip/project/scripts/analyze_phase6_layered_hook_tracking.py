"""Derive a measured paper-attached overlay track for Phase 6 take-003.

This is an isolated QA diagnostic.  It consumes the already-decoded, hash-pinned
150-frame card hulls and the already-extracted lossless FFV1 span.  It never
changes the TakePlan, recipes, schemas, runtime, queue, production artifacts or
publication state, and it never invokes a media encoder, TTS or an API.

The original motion-generation command is not available.  Accordingly this
module does not invent one: it fits a smooth quadrilateral trajectory to each
paper card's measured hull, maps NAME / TEST / CHOOSE through a card-local
homography, validates every projected text quad against every measured hull,
and writes three diagnostic PNG composites for independent review.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
DIAGNOSTICS = ROOT / "output/qa/phase6/diagnostics"
STATIC_GEOMETRY = DIAGNOSTICS / "layered-hook-static-geometry-5134aa42820475a5f2f8d433"
HULLS = STATIC_GEOMETRY / "frame-verification.json"
HULLS_SHA256 = "sha256:4e28a583c7b0cab4a9c3333fb4e77f7884dea1ef45acaa5c2950061c2c969aa5"
SOURCE_PROOF = DIAGNOSTICS / "layered-hook-proof-a1da6f2da24300a0c475f32c"
SOURCE_FFV1 = SOURCE_PROOF / "source-full-span.mkv"
SOURCE_FFV1_SHA256 = "sha256:9b34d8938302b2636a2b858438f05f7303278c68aeec472c58f2f94c98ec9d04"
SOURCE_IMAGE = (
    ROOT / "output/production/phase5/pilot-001/creative-v3/assets/"
    "three-card-decision-original-v1.png"
)
SOURCE_IMAGE_SHA256 = "sha256:75805af113aafbe62f3dac3aa5b5b3dab1c8ea3259e199ca2ab30ba18c90edc4"
RIGHTS = (
    ROOT / "output/production/phase5/pilot-001/rights_evidence/"
    "asset-owned-three-card-decision-v1.json"
)
RIGHTS_SHA256 = "sha256:732af847eeffd4e6f2dd98d03a4966842897aa6485694a5670cf9f39d5f72648"
FONT = Path(r"C:\Windows\Fonts\bahnschrift.ttf")
FONT_SHA256 = "sha256:eaad201da94cb323401fdb8cc760650803ddf8fd704cb9fa56317e6c69bc6fd6"

SAMPLE_FRAMES = {
    0: (
        SOURCE_PROOF / "source-frame-01-at-0.000ms.png",
        "sha256:d136a4102b91be2849e030b4eb7c6eabeb9ab66f1b2afa60538a751c5514d688",
    ),
    75: (
        SOURCE_PROOF / "source-frame-02-at-2500.000ms.png",
        "sha256:a03f2b0ca2376dc3b97d2aab048c17f8a5093393043b2807292eff8953a92816",
    ),
    149: (
        SOURCE_PROOF / "source-frame-03-at-4966.667ms.png",
        "sha256:08aaae3d966255089c38da75c216679e3a7ae79fc66748af865b61ed99920881",
    ),
}

ALGORITHM_VERSION = "measured-card-homography-track-v1"
FRAME_COUNT = 150
FPS = 30
TOKENS = ("NAME", "TEST", "CHOOSE")
FONT_SIZE = 84
MINIMUM_FONT_SIZE = 54.0
MINIMUM_HULL_CLEARANCE = 8.0
MINIMUM_HULL_FRACTION = 1.0
SAFE = {"left": 154.0, "top": 86.0, "right": 1766.0, "bottom": 994.0}
NAVY = "#081827"
LIGHT = "#E8EDF2"
ACCENT = "#D7A94A"
MINIMUM_CONTRAST = 4.5
HUD_START_FRAME = 75
HUD_PANEL = {"left": 154, "top": 95, "right": 791, "bottom": 255}
HUD_LINES = ("SYSTEM: TRUTH /", "RESPONSIBILITY / TODAY")
QUAD_EPSILON_FRACTION = 0.035
POLYNOMIAL_DEGREES = tuple(range(3, 9))
MAXIMUM_TRACK_ACCELERATION = 0.10


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def canonical_sha(value: Any) -> str:
    encoded = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def json_bytes(value: Any) -> bytes:
    return (json.dumps(
        value, ensure_ascii=False, indent=2, allow_nan=False
    ) + "\n").encode("utf-8")


def save_new(path: Path, value: Any) -> None:
    payload = json_bytes(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def _read_bgr(path: Path) -> np.ndarray:
    """Decode through bytes so non-ASCII Windows paths remain exact."""

    encoded = np.fromfile(path, dtype=np.uint8)
    image = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    if image is None:
        raise PermissionError(f"image is undecodable: {path}")
    return image


def _write_png_new(path: Path, image: np.ndarray) -> None:
    """Encode before an exclusive write; cv2.imwrite is not Unicode-safe on Windows."""

    success, encoded = cv2.imencode(".png", image, [cv2.IMWRITE_PNG_COMPRESSION, 6])
    if not success:
        raise OSError(f"OpenCV failed to encode PNG: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(encoded.tobytes())
        stream.flush()
        os.fsync(stream.fileno())


def relative(path: Path) -> str:
    resolved = path.resolve()
    try:
        return str(resolved.relative_to(ROOT))
    except ValueError:
        return "external-local-file:" + str(resolved)


def _ordered_quad(vertices: Iterable[Iterable[float]]) -> np.ndarray:
    hull = np.asarray(list(vertices), dtype=np.float32).reshape(-1, 1, 2)
    if len(hull) < 4 or not cv2.isContourConvex(hull):
        raise ValueError("card hull must be convex and contain at least four vertices")
    perimeter = cv2.arcLength(hull, True)
    quad = cv2.approxPolyDP(
        hull, QUAD_EPSILON_FRACTION * perimeter, True
    ).reshape(-1, 2)
    if len(quad) != 4:
        raise ValueError(f"card hull did not reduce to four corners: {len(quad)}")
    sums = quad.sum(axis=1)
    differences = np.diff(quad, axis=1).reshape(-1)
    ordered = np.asarray((
        quad[int(np.argmin(sums))],
        quad[int(np.argmin(differences))],
        quad[int(np.argmax(sums))],
        quad[int(np.argmax(differences))],
    ), dtype=np.float64)
    if len({tuple(item) for item in ordered.tolist()}) != 4:
        raise ValueError("ordered card quadrilateral contains duplicate corners")
    if not cv2.isContourConvex(ordered.astype(np.float32).reshape(-1, 1, 2)):
        raise ValueError("ordered card quadrilateral is not convex")
    return ordered


def _fit_quads(raw: np.ndarray, degree: int) -> tuple[np.ndarray, dict[str, Any]]:
    if raw.shape != (FRAME_COUNT, 3, 4, 2):
        raise ValueError(f"unexpected raw quadrilateral tensor: {raw.shape}")
    normalized_time = np.linspace(-1.0, 1.0, FRAME_COUNT)
    fitted = np.empty_like(raw, dtype=np.float64)
    coefficients: list[list[list[list[float]]]] = []
    for card_index in range(3):
        card_coefficients: list[list[list[float]]] = []
        for corner_index in range(4):
            corner_coefficients: list[list[float]] = []
            for axis_index in range(2):
                values = raw[:, card_index, corner_index, axis_index]
                coeff = np.polynomial.chebyshev.chebfit(
                    normalized_time, values, degree
                )
                fitted[:, card_index, corner_index, axis_index] = (
                    np.polynomial.chebyshev.chebval(normalized_time, coeff)
                )
                corner_coefficients.append([float(value) for value in coeff])
            card_coefficients.append(corner_coefficients)
        coefficients.append(card_coefficients)
    residual = np.linalg.norm(fitted - raw, axis=3)
    centers = fitted.mean(axis=2)
    accelerations = np.linalg.norm(np.diff(centers, n=2, axis=0), axis=2)
    convex = all(
        cv2.isContourConvex(fitted[frame, card].astype(np.float32).reshape(-1, 1, 2))
        for frame in range(FRAME_COUNT)
        for card in range(3)
    )
    metrics = {
        "degree": degree,
        "coefficients": coefficients,
        "per_card": [
            {
                "median_corner_residual_pixels": float(np.median(residual[:, index])),
                "p95_corner_residual_pixels": float(np.percentile(residual[:, index], 95)),
                "maximum_corner_residual_pixels": float(np.max(residual[:, index])),
                "maximum_center_acceleration_pixels_per_frame2": float(
                    np.max(accelerations[:, index])
                ),
            }
            for index in range(3)
        ],
        "all_fitted_quads_convex": bool(convex),
    }
    return fitted, metrics


def _degree_eligible(metrics: dict[str, Any]) -> bool:
    cards = metrics["per_card"]
    return bool(
        metrics["all_fitted_quads_convex"]
        and cards[0]["p95_corner_residual_pixels"] <= 15.0
        and cards[0]["maximum_corner_residual_pixels"] <= 32.0
        and cards[1]["p95_corner_residual_pixels"] <= 3.0
        and cards[1]["maximum_corner_residual_pixels"] <= 3.0
        and cards[2]["p95_corner_residual_pixels"] <= 3.0
        and cards[2]["maximum_corner_residual_pixels"] <= 6.0
        and max(
            item["maximum_center_acceleration_pixels_per_frame2"]
            for item in cards
        ) <= MAXIMUM_TRACK_ACCELERATION
    )


def _unit_to_quad(quad: np.ndarray) -> np.ndarray:
    unit = np.asarray(((0, 0), (1, 0), (1, 1), (0, 1)), dtype=np.float32)
    return cv2.getPerspectiveTransform(unit, quad.astype(np.float32))


def _project_uv_box(quad: np.ndarray, box: tuple[float, float, float, float]) -> np.ndarray:
    left, top, right, bottom = box
    points = np.asarray(
        ((left, top), (right, top), (right, bottom), (left, bottom)),
        dtype=np.float32,
    ).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(points, _unit_to_quad(quad)).reshape(-1, 2).astype(np.float64)


def _point_clearances(hull: np.ndarray, quad: np.ndarray) -> list[float]:
    contour = hull.astype(np.float32).reshape(-1, 1, 2)
    return [
        float(cv2.pointPolygonTest(contour, (float(x), float(y)), True))
        for x, y in quad
    ]


def _safe(quad: np.ndarray) -> bool:
    return bool(
        np.min(quad[:, 0]) >= SAFE["left"]
        and np.max(quad[:, 0]) <= SAFE["right"]
        and np.min(quad[:, 1]) >= SAFE["top"]
        and np.max(quad[:, 1]) <= SAFE["bottom"]
    )


def _font_measurement(token: str) -> dict[str, Any]:
    font = ImageFont.truetype(str(FONT), FONT_SIZE)
    bbox = font.getbbox(token)
    ascent, descent = font.getmetrics()
    width = int(bbox[2] - bbox[0]) + 4
    height = int(ascent + descent + 4)
    return {
        "width": width,
        "height": height,
        "pillow_bbox": [int(value) for value in bbox],
        "ascent": int(ascent),
        "descent": int(descent),
    }


def _local_jacobian(homography: np.ndarray, width: int, height: int) -> np.ndarray:
    center = np.asarray(([[width / 2, height / 2]],), dtype=np.float32)
    x_step = center.copy()
    y_step = center.copy()
    x_step[0, 0, 0] += 1.0
    y_step[0, 0, 1] += 1.0
    mapped = cv2.perspectiveTransform(
        np.concatenate((center, x_step, y_step), axis=0), homography
    ).reshape(-1, 2)
    return np.column_stack((mapped[1] - mapped[0], mapped[2] - mapped[0]))


def _effective_font_size(quad: np.ndarray, measurement: dict[str, Any]) -> float:
    sprite = np.asarray(
        ((0, 0), (measurement["width"], 0),
         (measurement["width"], measurement["height"]), (0, measurement["height"])),
        dtype=np.float32,
    )
    homography = cv2.getPerspectiveTransform(sprite, quad.astype(np.float32))
    singular_values = np.linalg.svd(
        _local_jacobian(homography, measurement["width"], measurement["height"]),
        compute_uv=False,
    )
    return float(FONT_SIZE * np.min(singular_values))


def _candidate_box(
    base_quad: np.ndarray,
    measurement: dict[str, Any],
    *,
    u_center: float,
    v_center: float,
    size_scale: float,
) -> tuple[float, float, float, float]:
    center = _project_uv_box(
        base_quad,
        (u_center - 0.005, v_center - 0.005, u_center + 0.005, v_center + 0.005),
    )
    horizontal_per_unit = float(np.mean((
        np.linalg.norm(center[1] - center[0]),
        np.linalg.norm(center[2] - center[3]),
    )) / 0.01)
    vertical_per_unit = float(np.mean((
        np.linalg.norm(center[3] - center[0]),
        np.linalg.norm(center[2] - center[1]),
    )) / 0.01)
    u_span = measurement["width"] * size_scale / horizontal_per_unit
    v_span = measurement["height"] * size_scale / vertical_per_unit
    return (
        u_center - u_span / 2,
        v_center - v_span / 2,
        u_center + u_span / 2,
        v_center + v_span / 2,
    )


def _evaluate_box(
    fitted: np.ndarray,
    raw_hulls: list[list[np.ndarray]],
    measurement: dict[str, Any],
    card_index: int,
    box: tuple[float, float, float, float],
) -> dict[str, Any]:
    frame_records: list[dict[str, Any]] = []
    for frame_number in range(FRAME_COUNT):
        quad = _project_uv_box(fitted[frame_number, card_index], box)
        clearances = _point_clearances(raw_hulls[frame_number][card_index], quad)
        effective = _effective_font_size(quad, measurement)
        frame_records.append({
            "frame_number": frame_number,
            "quad": [[float(axis) for axis in point] for point in quad],
            "clearances_pixels": clearances,
            "minimum_clearance_pixels": min(clearances),
            "safe_area_pass": _safe(quad),
            "effective_font_size": effective,
        })
    return {
        "frames": frame_records,
        "minimum_clearance_pixels": min(
            item["minimum_clearance_pixels"] for item in frame_records
        ),
        "minimum_effective_font_size": min(
            item["effective_font_size"] for item in frame_records
        ),
        "all_safe": all(item["safe_area_pass"] for item in frame_records),
    }


def _select_placement(
    fitted: np.ndarray,
    raw_hulls: list[list[np.ndarray]],
    measurement: dict[str, Any],
    card_index: int,
) -> dict[str, Any]:
    preferred_u = (0.50, 0.50, 0.40)[card_index]
    preferred_v = 0.64
    evaluated = 0
    best: dict[str, Any] | None = None
    # Largest readable rendering first; position is solved only after size.
    for size_scale in (1.00, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65):
        size_best: dict[str, Any] | None = None
        for u_center in np.arange(0.24, 0.761, 0.01):
            for v_center in np.arange(0.54, 0.751, 0.01):
                box = _candidate_box(
                    fitted[0, card_index], measurement,
                    u_center=float(u_center), v_center=float(v_center),
                    size_scale=size_scale,
                )
                if min(box) < 0 or max(box) > 1:
                    continue
                result = _evaluate_box(
                    fitted, raw_hulls, measurement, card_index, box
                )
                evaluated += 1
                if (
                    result["minimum_clearance_pixels"] + 1e-9 < MINIMUM_HULL_CLEARANCE
                    or result["minimum_effective_font_size"] + 1e-9 < MINIMUM_FONT_SIZE
                    or not result["all_safe"]
                ):
                    continue
                rank = (
                    -result["minimum_clearance_pixels"],
                    abs(float(u_center) - preferred_u) + abs(float(v_center) - preferred_v),
                    abs(float(u_center) - preferred_u),
                    float(u_center),
                    float(v_center),
                )
                candidate = {
                    "uv_box": [float(value) for value in box],
                    "u_center": float(u_center),
                    "v_center": float(v_center),
                    "size_scale_requested": size_scale,
                    "rank": rank,
                    **result,
                }
                if size_best is None or rank < size_best["rank"]:
                    size_best = candidate
        if size_best is not None:
            best = size_best
            break
    if best is None:
        raise PermissionError(
            f"no full-span tracked placement satisfies card {card_index + 1}"
        )
    best["candidate_count_evaluated"] = evaluated
    best.pop("rank", None)
    return best


def _linear_luminance(rgb: np.ndarray) -> np.ndarray:
    normalized = rgb.astype(np.float64) / 255.0
    linear = np.where(
        normalized <= 0.04045,
        normalized / 12.92,
        ((normalized + 0.055) / 1.055) ** 2.4,
    )
    return (
        0.2126 * linear[..., 0]
        + 0.7152 * linear[..., 1]
        + 0.0722 * linear[..., 2]
    )


def _hex_luminance(value: str) -> float:
    raw = value.removeprefix("#")
    rgb = np.asarray([int(raw[index:index + 2], 16) for index in (0, 2, 4)])
    return float(_linear_luminance(rgb))


def _contrast(first: float, second: float) -> float:
    high, low = sorted((first, second), reverse=True)
    return float((high + 0.05) / (low + 0.05))


def _sample_glyph_contrast(
    image_bgr: np.ndarray, quad: np.ndarray, foreground: str,
    sprite: np.ndarray,
) -> dict[str, float]:
    height, width = sprite.shape[:2]
    source = np.asarray(
        ((0, 0), (width, 0), (width, height), (0, height)), dtype=np.float32
    )
    homography = cv2.getPerspectiveTransform(source, quad.astype(np.float32))
    mask = cv2.warpPerspective(
        sprite[:, :, 3], homography, (image_bgr.shape[1], image_bgr.shape[0]),
        flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_CONSTANT, borderValue=0,
    )
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    # Fully and mostly covered glyph pixels determine text contrast.  Transparent
    # sprite margins are intentionally excluded from this measurement.
    values = _linear_luminance(rgb)[mask >= 128]
    if values.size == 0:
        raise PermissionError("projected text quad has no sampled pixels")
    foreground_luminance = _hex_luminance(foreground)
    percentiles = {name: float(np.percentile(values, value)) for name, value in (
        ("p05", 5), ("p10", 10), ("median", 50), ("p90", 90)
    )}
    return {
        **{f"background_{key}_luminance": value for key, value in percentiles.items()},
        **{f"contrast_against_{key}": _contrast(foreground_luminance, value)
           for key, value in percentiles.items()},
    }


def _text_sprite(
    token: str, measurement: dict[str, Any], *, opaque_backing: bool = False
) -> np.ndarray:
    horizontal_padding = 10 if opaque_backing else 0
    vertical_padding = 8 if opaque_backing else 0
    width = measurement["width"] + 2 * horizontal_padding
    height = measurement["height"] + 2 * vertical_padding
    background = (232, 237, 242, 255) if opaque_backing else (0, 0, 0, 0)
    image = Image.new("RGBA", (width, height), background)
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(str(FONT), FONT_SIZE)
    bbox = font.getbbox(token)
    glyph_height = bbox[3] - bbox[1]
    x = (width - (bbox[2] - bbox[0])) / 2 - bbox[0]
    y = (height - glyph_height) / 2 - bbox[1]
    draw.text((x, y), token, font=font, fill=(8, 24, 39, 255))
    return cv2.cvtColor(np.asarray(image), cv2.COLOR_RGBA2BGRA)


def _alpha_composite_warp(
    destination: np.ndarray, sprite: np.ndarray, quad: np.ndarray
) -> np.ndarray:
    height, width = sprite.shape[:2]
    source = np.asarray(
        ((0, 0), (width, 0), (width, height), (0, height)), dtype=np.float32
    )
    homography = cv2.getPerspectiveTransform(source, quad.astype(np.float32))
    warped = cv2.warpPerspective(
        sprite, homography, (destination.shape[1], destination.shape[0]),
        flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0, 0),
    )
    alpha = warped[:, :, 3:4].astype(np.float32) / 255.0
    return np.rint(
        warped[:, :, :3].astype(np.float32) * alpha
        + destination.astype(np.float32) * (1.0 - alpha)
    ).clip(0, 255).astype(np.uint8)


def _hud(image_bgr: np.ndarray) -> np.ndarray:
    image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(image)
    draw.rectangle(
        (HUD_PANEL["left"], HUD_PANEL["top"], HUD_PANEL["right"], HUD_PANEL["bottom"]),
        fill=NAVY,
    )
    draw.rectangle(
        (HUD_PANEL["left"], HUD_PANEL["top"], HUD_PANEL["right"], HUD_PANEL["top"] + 3),
        fill=ACCENT,
    )
    font = ImageFont.truetype(str(FONT), 54)
    draw.text((166, 106), HUD_LINES[0], font=font, fill=LIGHT)
    draw.text((166, 164), HUD_LINES[1], font=font, fill=LIGHT)
    return cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)


def _validate_hulls(document: dict[str, Any]) -> tuple[np.ndarray, list[list[np.ndarray]]]:
    if (
        document.get("schema_version") != "1.0.0"
        or document.get("status") != "PASS_ALL_150_FRAMES"
        or document.get("required_frame_count") != FRAME_COUNT
        or document.get("observed_frame_count") != FRAME_COUNT
        or document.get("failed_frame_numbers") != []
    ):
        raise PermissionError("frozen 150-frame hull document is not the expected PASS input")
    frames = document.get("frames")
    if not isinstance(frames, list) or len(frames) != FRAME_COUNT:
        raise PermissionError("frozen hull collection is incomplete")
    raw_quads = np.empty((FRAME_COUNT, 3, 4, 2), dtype=np.float64)
    raw_hulls: list[list[np.ndarray]] = []
    for frame_number, frame in enumerate(frames):
        if frame.get("frame_number") != frame_number or frame.get("status") != "PASS":
            raise PermissionError("hull frame identity/order/status changed")
        cards = frame.get("cards")
        if not isinstance(cards, list) or len(cards) != 3:
            raise PermissionError("hull frame does not contain exactly three cards")
        frame_hulls: list[np.ndarray] = []
        for card_index, card in enumerate(cards):
            if card.get("card_index") != card_index + 1 or card.get("copy") != TOKENS[card_index]:
                raise PermissionError("hull card identity/copy changed")
            hull = np.asarray(card.get("hull_vertices"), dtype=np.float64)
            if hull.ndim != 2 or hull.shape[1] != 2 or len(hull) < 4 or not np.isfinite(hull).all():
                raise PermissionError("hull vertices are malformed")
            raw_quads[frame_number, card_index] = _ordered_quad(hull)
            frame_hulls.append(hull)
        raw_hulls.append(frame_hulls)
    return raw_quads, raw_hulls


def _bindings() -> dict[str, str]:
    paths = {
        SOURCE_FFV1: SOURCE_FFV1_SHA256,
        HULLS: HULLS_SHA256,
        SOURCE_IMAGE: SOURCE_IMAGE_SHA256,
        RIGHTS: RIGHTS_SHA256,
        FONT: FONT_SHA256,
        Path(__file__).resolve(): None,
        **{path: expected for path, expected in SAMPLE_FRAMES.values()},
    }
    result: dict[str, str] = {}
    for path, expected in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"pinned diagnostic input missing: {path}")
        observed = sha(path)
        if expected is not None and observed != expected:
            raise PermissionError(f"pinned diagnostic input changed: {path}")
        result[relative(path)] = observed
    return result


def _identity(bindings: dict[str, str]) -> str:
    return canonical_sha({
        "algorithm_version": ALGORITHM_VERSION,
        "bindings": bindings,
        "policy": {
            "frame_count": FRAME_COUNT,
            "fps": FPS,
            "tokens": TOKENS,
            "font_size": FONT_SIZE,
            "minimum_font_size": MINIMUM_FONT_SIZE,
            "minimum_hull_fraction": MINIMUM_HULL_FRACTION,
            "minimum_hull_clearance": MINIMUM_HULL_CLEARANCE,
            "safe_area": SAFE,
            "quad_epsilon_fraction": QUAD_EPSILON_FRACTION,
            "polynomial_degrees": POLYNOMIAL_DEGREES,
            "maximum_track_acceleration": MAXIMUM_TRACK_ACCELERATION,
            "hud_start_frame": HUD_START_FRAME,
        },
    })


def _destination(identity: str) -> Path:
    return DIAGNOSTICS / (
        "layered-hook-tracked-geometry-" + identity.split(":", 1)[1][:24]
    )


def self_test() -> dict[str, Any]:
    rectangle = np.asarray(((10, 10), (110, 10), (110, 90), (10, 90)), dtype=np.float64)
    ordered = _ordered_quad(rectangle)
    projected = _project_uv_box(ordered, (0.1, 0.1, 0.9, 0.9))
    if not np.allclose(projected, np.asarray(((20, 18), (100, 18), (100, 82), (20, 82))), atol=1e-4):
        raise AssertionError("synthetic homography projection failed")
    with tempfile.TemporaryDirectory(prefix="hook-track-selftest-") as temporary:
        folder = Path(temporary) / "Área"
        folder.mkdir()
        path = folder / "roundtrip.json"
        value = {"finite": [float(axis) for axis in projected.reshape(-1)]}
        save_new(path, value)
        first_hash = sha(path)
        if json.loads(path.read_text(encoding="utf-8")) != value or sha(path) != first_hash:
            raise AssertionError("exclusive JSON serialization roundtrip failed")
        pixels = np.zeros((8, 8, 3), dtype=np.uint8)
        pixels[:, :, 1] = 127
        image_path = folder / "amostra-á.png"
        _write_png_new(image_path, pixels)
        decoded = _read_bgr(image_path)
        if decoded.shape != pixels.shape or not np.array_equal(decoded, pixels):
            raise AssertionError("Unicode-safe PNG encode/decode roundtrip failed")
    return {
        "status": "PASS",
        "tests": [
            "ordered-convex-quad", "homography-projection", "finite-canonical-json",
            "exclusive-fsync-write-roundtrip", "unicode-path-png-roundtrip",
        ],
    }


def preflight() -> dict[str, Any]:
    self_test_result = self_test()
    bindings = _bindings()
    rights = json.loads(RIGHTS.read_text(encoding="utf-8"))
    if (
        rights.get("asset_id") != "asset-owned-three-card-decision-v1"
        or rights.get("source_image_hash") != SOURCE_IMAGE_SHA256
        or rights.get("motion_hash") != "sha256:417046cd4e2a7c199d574b45fb405cd5278d1e0cc53529a8001add60b9a2f23e"
        or rights.get("decision") != "RESPONSIBLE_REVIEW_APPROVED"
    ):
        raise PermissionError("source provenance/rights record changed")
    hull_document = json.loads(HULLS.read_text(encoding="utf-8"))
    raw_quads, raw_hulls = _validate_hulls(hull_document)
    if raw_quads.shape != (FRAME_COUNT, 3, 4, 2) or len(raw_hulls) != FRAME_COUNT:
        raise AssertionError("validated hull tensors have unexpected dimensions")
    measurements = [_font_measurement(token) for token in TOKENS]
    if [item["width"] for item in measurements] != [232, 189, 323] or any(
        item["height"] != 89 for item in measurements
    ):
        raise PermissionError("real-font measurement changed")
    identity = _identity(bindings)
    destination = _destination(identity)
    receipt = {
        "schema_version": "1.0.0",
        "scope": "HOOK_003_TRACKED_GEOMETRY_PREFLIGHT_NOT_RENDER_AUTHORITY",
        "status": "PASS_PREFLIGHT_NO_DECODE_NO_ENCODER",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "identity_sha256": identity,
        "destination": relative(destination),
        "input_bindings": bindings,
        "validated": {
            "all_paths_and_hashes": True,
            "rights_and_source_identity": True,
            "hull_frames": FRAME_COUNT,
            "ordered_cards_per_frame": 3,
            "finite_quadrilateral_tensor": True,
            "real_font_measurements": measurements,
            "serialization": self_test_result,
        },
        "source_motion_recipe_status": "UNAVAILABLE_NOT_INVENTED",
        "selected_method": "MEASURED_CARD_QUADRILATERAL_HOMOGRAPHY",
        "ffv1_decoded": False,
        "source_extraction_performed": False,
        "encoder_invoked": False,
        "new_tts_calls": 0,
        "api_calls": 0,
        "technical_cost_brl": 0,
        "queue_authorized": False,
        "production_authorized": False,
        "publication_authorized": False,
    }
    destination.mkdir(parents=True, exist_ok=False)
    save_new(destination / "checkpoint-000-preflight.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    return receipt


def analyze(destination: Path) -> dict[str, Any]:
    destination = destination.resolve()
    expected_parent = DIAGNOSTICS.resolve()
    if destination.parent != expected_parent or not destination.name.startswith(
        "layered-hook-tracked-geometry-"
    ):
        raise PermissionError("analysis destination is outside isolated QA namespace")
    preflight_path = destination / "checkpoint-000-preflight.json"
    if not preflight_path.is_file():
        raise FileNotFoundError("analysis requires a completed preflight checkpoint")
    preflight_receipt = json.loads(preflight_path.read_text(encoding="utf-8"))
    bindings = _bindings()
    identity = _identity(bindings)
    if (
        preflight_receipt.get("status") != "PASS_PREFLIGHT_NO_DECODE_NO_ENCODER"
        or preflight_receipt.get("identity_sha256") != identity
        or preflight_receipt.get("destination") != relative(destination)
        or preflight_receipt.get("input_bindings") != bindings
    ):
        raise PermissionError("preflight checkpoint does not bind current analysis")
    for name in (
        "checkpoint-001-tracks.json", "tracked-layout.json", "frame-verification.json",
        "style-comparison.json", "receipt.json",
    ):
        if (destination / name).exists():
            raise FileExistsError(f"analysis refuses to overwrite {name}")

    hull_document = json.loads(HULLS.read_text(encoding="utf-8"))
    raw_quads, raw_hulls = _validate_hulls(hull_document)
    degree_candidates = []
    selected_degree: int | None = None
    selected_fit: np.ndarray | None = None
    for degree in POLYNOMIAL_DEGREES:
        fitted, metrics = _fit_quads(raw_quads, degree)
        metrics["eligible"] = _degree_eligible(metrics)
        degree_candidates.append(metrics)
        if selected_degree is None and metrics["eligible"]:
            selected_degree, selected_fit = degree, fitted
    if selected_degree is None or selected_fit is None:
        checkpoint = {
            "schema_version": "1.0.0", "status": "BLOCKED_NO_STABLE_TRACK",
            "identity_sha256": identity, "degree_candidates": degree_candidates,
            "encoder_invoked": False,
        }
        save_new(destination / "checkpoint-001-tracks.json", checkpoint)
        raise PermissionError("no measured quadrilateral track passed fidelity/stability gates")
    track_checkpoint = {
        "schema_version": "1.0.0",
        "status": "PASS_SMOOTH_TRACK_CANDIDATE",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "identity_sha256": identity,
        "input_hulls_sha256": HULLS_SHA256,
        "selection_rule": "LOWEST_DEGREE_PASSING_ALL_FIDELITY_CONVEXITY_AND_ACCELERATION_GATES",
        "selected_degree": selected_degree,
        "degree_candidates": degree_candidates,
        "fitted_quads": [
            [
                [[float(axis) for axis in point] for point in card]
                for card in frame
            ]
            for frame in selected_fit
        ],
        "encoder_invoked": False,
    }
    save_new(destination / "checkpoint-001-tracks.json", track_checkpoint)

    measurements = [_font_measurement(token) for token in TOKENS]
    placements = [
        _select_placement(selected_fit, raw_hulls, measurements[index], index)
        for index in range(3)
    ]
    layout = {
        "schema_version": "1.0.0",
        "status": "PASS_TRACKED_LAYOUT_GEOMETRY_CANDIDATE",
        "identity_sha256": identity,
        "algorithm_version": ALGORITHM_VERSION,
        "track_checkpoint_sha256": sha(destination / "checkpoint-001-tracks.json"),
        "copy": list(TOKENS),
        "font": {"path": str(FONT), "sha256": FONT_SHA256, "size": FONT_SIZE},
        "primary_style_candidates": {
            "direct_navy_ink": {
                "foreground": NAVY, "opaque_backing": False,
                "paper_texture_preserved": True,
            },
            "light_opaque_label": {
                "foreground": NAVY, "background": LIGHT, "opaque_backing": True,
                "paper_texture_preserved": False,
            },
        },
        "placements": [
            {
                "card_index": index + 1,
                "token": TOKENS[index],
                "font_measurement": measurements[index],
                **{key: value for key, value in placement.items() if key != "frames"},
            }
            for index, placement in enumerate(placements)
        ],
        "secondary_hud": {
            "relation": "DISTINCT_CHANNEL_SYSTEM_NOT_CARD_MAPPING",
            "start_frame": HUD_START_FRAME,
            "start_ms": 2500,
            "panel": HUD_PANEL,
            "copy_lines": list(HUD_LINES),
            "font_size": 54,
        },
        "authority": {
            "encoder": False, "production": False, "publication": False,
        },
    }
    save_new(destination / "tracked-layout.json", layout)

    verification_frames = []
    for frame_number in range(FRAME_COUNT):
        cards = []
        for card_index, placement in enumerate(placements):
            record = placement["frames"][frame_number]
            cards.append({
                "card_index": card_index + 1,
                "token": TOKENS[card_index],
                **record,
            })
        verification_frames.append({
            "frame_number": frame_number,
            "relative_offset_ms": frame_number * 1000 / FPS,
            "status": "PASS" if all(
                item["minimum_clearance_pixels"] >= MINIMUM_HULL_CLEARANCE
                and item["safe_area_pass"]
                and item["effective_font_size"] >= MINIMUM_FONT_SIZE
                for item in cards
            ) else "FAIL",
            "cards": cards,
        })
    all_cards = [card for frame in verification_frames for card in frame["cards"]]
    failures = [
        frame["frame_number"] for frame in verification_frames
        if frame["status"] != "PASS"
    ]
    verification = {
        "schema_version": "1.0.0",
        "status": "PASS_ALL_150_TRACKED_FRAMES" if not failures else "FAIL_TRACKED_GEOMETRY",
        "identity_sha256": identity,
        "tracked_layout_sha256": sha(destination / "tracked-layout.json"),
        "required_frame_count": FRAME_COUNT,
        "observed_frame_count": len(verification_frames),
        "failed_frame_numbers": failures,
        "minimum_corner_clearance_pixels": min(
            item["minimum_clearance_pixels"] for item in all_cards
        ),
        "minimum_effective_font_size": min(
            item["effective_font_size"] for item in all_cards
        ),
        "all_safe_area_pass": all(item["safe_area_pass"] for item in all_cards),
        "frames": verification_frames,
    }
    save_new(destination / "frame-verification.json", verification)
    if verification["status"] != "PASS_ALL_150_TRACKED_FRAMES":
        raise PermissionError("tracked geometry failed before sample compositing")

    contrast_samples = []
    sample_sources: dict[int, np.ndarray] = {}
    for frame_number, (source_path, _) in SAMPLE_FRAMES.items():
        source = _read_bgr(source_path)
        if source.shape != (1080, 1920, 3):
            raise PermissionError(f"representative source frame is undecodable: {source_path}")
        sample_sources[frame_number] = source
        for card_index, placement in enumerate(placements):
            frame_record = placement["frames"][frame_number]
            quad = np.asarray(frame_record["quad"], dtype=np.float64)
            direct_sprite = _text_sprite(
                TOKENS[card_index], measurements[card_index], opaque_backing=False
            )
            contrast_samples.append({
                "frame_number": frame_number,
                "card_index": card_index + 1,
                "token": TOKENS[card_index],
                **_sample_glyph_contrast(source, quad, NAVY, direct_sprite),
            })

    direct_min_p05 = min(item["contrast_against_p05"] for item in contrast_samples)
    direct_min_p10 = min(item["contrast_against_p10"] for item in contrast_samples)
    opaque_contrast = _contrast(_hex_luminance(NAVY), _hex_luminance(LIGHT))
    direct_pass = direct_min_p05 >= MINIMUM_CONTRAST
    opaque_pass = opaque_contrast >= MINIMUM_CONTRAST
    selected_opaque = not direct_pass and opaque_pass
    selected_effective_sizes = []
    for card_index, placement in enumerate(placements):
        selected_measurement = dict(measurements[card_index])
        if selected_opaque:
            selected_measurement["width"] += 20
            selected_measurement["height"] += 16
        for frame_record in placement["frames"]:
            selected_effective_sizes.append(_effective_font_size(
                np.asarray(frame_record["quad"], dtype=np.float64), selected_measurement
            ))
    selected_minimum_font_size = min(selected_effective_sizes)
    selected_style_pass = (direct_pass or opaque_pass) and (
        selected_minimum_font_size >= MINIMUM_FONT_SIZE
    )
    style_decision = {
        "schema_version": "1.0.0",
        "status": "PASS_MEASURED_STYLE_SELECTION" if selected_style_pass else "BLOCKED_NO_LEGIBLE_STYLE",
        "selected": "DIRECT_NAVY_INK_ON_PAPER" if direct_pass else "LIGHT_OPAQUE_LABEL",
        "selection_rule": (
            "PREFER_DIRECT_INK_ONLY_WHEN_REPRESENTATIVE_P05_CONTRAST_PASSES_4_5;"
            "THEN_PRESERVE_PAPER_TEXTURE_AND_MINIMIZE_OCCLUDED_SOURCE_AREA"
        ),
        "direct_ink": {
            "foreground": NAVY,
            "minimum_sampled_p05_contrast_ratio": direct_min_p05,
            "minimum_sampled_p10_contrast_ratio": direct_min_p10,
            "sample_count": len(contrast_samples),
            "opaque_source_area_pixels": 0,
            "paper_texture_preserved": True,
            "status": "PASS" if direct_pass else "FAIL_CONTRAST",
        },
        "opaque_label": {
            "foreground": NAVY,
            "background": LIGHT,
            "fixed_palette_contrast_ratio": opaque_contrast,
            "canonical_opaque_sprite_area_pixels": sum(
                (measurement["width"] + 20) * (measurement["height"] + 16)
                for measurement in measurements
            ),
            "paper_texture_preserved": False,
            "status": "PASS" if opaque_pass else "FAIL_CONTRAST",
            "not_selected_reason": (
                "unnecessary opaque patch when direct ink passes contrast; prior proof showed "
                "the patch reads as a floating sticker under camera motion"
            ) if direct_pass else None,
        },
        "selected_minimum_effective_font_size": selected_minimum_font_size,
        "samples": contrast_samples,
        "limitations": [
            "Contrast is measured on the three exact review frames, not every decoded FFV1 pixel.",
            "Hull geometry and three composites do not replace independent motion review.",
        ],
    }
    save_new(destination / "style-comparison.json", style_decision)

    if not selected_style_pass:
        raise PermissionError("neither measured primary style passes contrast and font gates")
    representative_paths = []
    for frame_number, source in sample_sources.items():
        composed = source.copy()
        for card_index, placement in enumerate(placements):
            quad = np.asarray(
                placement["frames"][frame_number]["quad"], dtype=np.float64
            )
            composed = _alpha_composite_warp(
                composed,
                _text_sprite(
                    TOKENS[card_index], measurements[card_index],
                    opaque_backing=selected_opaque,
                ),
                quad,
            )
        if frame_number >= HUD_START_FRAME:
            composed = _hud(composed)
        output = destination / f"review-frame-{frame_number:03d}.png"
        _write_png_new(output, composed)
        representative_paths.append({
            "frame_number": frame_number,
            "relative_offset_ms": frame_number * 1000 / FPS,
            "path": relative(output),
            "sha256": sha(output),
        })

    receipt = {
        "schema_version": "1.0.0",
        "scope": "HOOK_003_TRACKED_GEOMETRY_AND_THREE_FRAME_DIAGNOSTIC_ONLY",
        "status": (
            "PASS_GEOMETRY_PENDING_INDEPENDENT_FRAME_REVIEW_NO_ENCODER_AUTHORITY"
            if selected_style_pass else "BLOCKED_STYLE_CONTRAST_NO_ENCODER_AUTHORITY"
        ),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "identity_sha256": identity,
        "input_bindings": bindings,
        "preflight_sha256": sha(preflight_path),
        "track_checkpoint_sha256": sha(destination / "checkpoint-001-tracks.json"),
        "tracked_layout_sha256": sha(destination / "tracked-layout.json"),
        "frame_verification_sha256": sha(destination / "frame-verification.json"),
        "style_comparison_sha256": sha(destination / "style-comparison.json"),
        "selected_degree": selected_degree,
        "metrics": {
            "required_frames": FRAME_COUNT,
            "verified_frames": len(verification_frames),
            "failed_frames": failures,
            "minimum_corner_clearance_pixels": verification["minimum_corner_clearance_pixels"],
            "minimum_effective_font_size": verification["minimum_effective_font_size"],
            "maximum_track_acceleration_pixels_per_frame2": max(
                item["maximum_center_acceleration_pixels_per_frame2"]
                for item in degree_candidates[selected_degree - POLYNOMIAL_DEGREES[0]]["per_card"]
            ),
            "minimum_sampled_p05_contrast_ratio": direct_min_p05,
            "selected_style_contrast_ratio": (
                direct_min_p05 if direct_pass else opaque_contrast
            ),
            "selected_minimum_effective_font_size": selected_minimum_font_size,
        },
        "selected_primary_style": style_decision["selected"],
        "representative_frames": representative_paths,
        "source_motion_recipe_status": "UNAVAILABLE_NOT_INVENTED",
        "tracking_method": "MEASURED_CARD_QUADRILATERAL_HOMOGRAPHY",
        "ffv1_decoded": False,
        "source_extraction_performed": False,
        "encoder_invoked": False,
        "audio_used": False,
        "new_tts_calls": 0,
        "api_calls": 0,
        "technical_cost_brl": 0,
        "queue_authorized": False,
        "production_authorized": False,
        "publication_authorized": False,
        "limitations": [
            "Three static composites can verify attachment geometry at sampled instants but cannot approve motion.",
            "The next five-second diagnostic encoder remains blocked pending independent review of these frames.",
            "This diagnostic does not alter or promote the existing layered-hook sidecar contract.",
        ],
    }
    save_new(destination / "receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--self-test", action="store_true")
    group.add_argument("--preflight", action="store_true")
    group.add_argument("--analyze", type=Path)
    arguments = parser.parse_args()
    if arguments.self_test:
        print(json.dumps(self_test(), ensure_ascii=False), flush=True)
    elif arguments.preflight:
        preflight()
    else:
        analyze(arguments.analyze)


if __name__ == "__main__":
    main()
