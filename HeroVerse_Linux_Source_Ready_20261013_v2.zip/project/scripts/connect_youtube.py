from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hero_engine.youtube_integration import connect_owned_channel


def main() -> None:
    parser = argparse.ArgumentParser(description="Authorize and verify HeroVerse without publishing")
    parser.add_argument(
        "--credentials",
        help="Installed-app client JSON. When omitted, reuse the client metadata already stored in the external authorized-user token.",
    )
    parser.add_argument("--token", required=True)
    parser.add_argument("--token-mirror")
    parser.add_argument(
        "--token-mirror-receipt",
        default="output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json",
    )
    parser.add_argument("--receipt", default="output/integrations/youtube/heroverse/connection-receipt.json")
    parser.add_argument("--expected-handle", default="@heroverse74")
    parser.add_argument("--expected-channel-id", default="UCuMF6pJQkyMzaVoAxFL86yA")
    parser.add_argument("--authorize", action="store_true")
    parser.add_argument(
        "--force-reauthorize",
        action="store_true",
        help="Run a fresh official Google consent + account-selection flow even when the stored token is valid; the old token is preserved until success.",
    )
    args = parser.parse_args()
    receipt = connect_owned_channel(
        Path(args.credentials) if args.credentials else None,
        Path(args.token),
        Path(args.receipt),
        authorize=args.authorize,
        force_reauthorize=args.force_reauthorize,
        expected_handle=args.expected_handle,
        expected_channel_id=args.expected_channel_id,
        token_mirror_file=Path(args.token_mirror) if args.token_mirror else None,
        token_mirror_receipt_file=ROOT / args.token_mirror_receipt if args.token_mirror else None,
    )
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
