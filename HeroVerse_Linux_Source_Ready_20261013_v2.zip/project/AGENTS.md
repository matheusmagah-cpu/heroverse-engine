# AGENTS.md — Contrato operacional do projeto

## Regra transversal — conteúdo autêntico e valor substantivo

Todas as fases seguem `docs/08_POLICY_AND_RIGHTS.md`, seção YPP-INAUTHENTIC-2025-07-15.
Mineração/modelagem extraem mecanismos, nunca copiam obras/identidades. OWNED,
licença, hash diferente, render bem codificado ou score de IA não comprovam
autenticidade nem elegibilidade YPP. Exigir contribuição e variação substantivas
do conteúdo e analisar o catálogo do canal, não só um arquivo. Música original
e imagem estática não são proibidas por formato; trocar título, duração, pitch
ou cor não transforma produção genérica em conteúdo autêntico. Melhoria exige
evidência/uma mudança causal/resultado medido; não gera ciclos de refazer etapas.
Não declarar certificação automática YPP: decisão da plataforma permanece externa.

## D-173 — raiz única permanente

A raiz oficial e única é `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`.
Código, configuração, evidência, logs, checkpoints, mídia necessária, resultados
e documentação devem permanecer nela ou em subpastas. TEMP/cache externo só é
transitório e nunca é fonte de verdade; consolide artefatos necessários na raiz.

## D-174 — fronteira durável de caminho do host

Para orquestração Windows/Codex, o diretório físico de trabalho obrigatório é
`C:\Users\mathe\OneDrive\READET~1\MODELA~1`. Ele deve apontar para a mesma raiz
oficial D-173 e é apenas uma camada de transporte contra corrupção Unicode em
`CreateProcess`; nunca é uma segunda raiz nem dependência do produto/runtime.
Antes de qualquer efeito externo, a orquestração deve executar
`scripts/assert_orchestration_root.ps1` e falhar fechada se os marcadores da
raiz física e lógica divergirem. Nenhum processo pode tentar um cwd contendo
`�rea de Trabalho` ou outro caminho Unicode corrompido.

## D-196 — gestão autônoma e permanente de recursos

Antes de qualquer prova integral, aplicação, D-116, retomada, renderização ou
etapa pesada, executar preflight serial. O alvo operacional é ao menos **15 GiB
livres em C:** e **2 GiB de RAM livre estável**; os mínimos técnicos existentes
nunca podem ser reduzidos para admitir uma etapa. Quando a margem não existir,
recuperar primeiro e somente por mecanismos seguros: encerrar graciosamente
processos opcionais que não sustentem Codex, acesso remoto, Chrome, segurança ou
o projeto; limpar temporários/caches comprovadamente regeneráveis; e validar
referências antes de remover mídia descartável. Não tocar em fontes, evidências,
recibos, bancos, credenciais, arquivos pessoais ou conteúdos sincronizados sem
cópia confirmada. Após a etapa crítica, reativar sincronizadores necessários.
Uma política do host que recuse uma ação não deve ser burlada; tente os demais
mecanismos permitidos uma vez, registre caminho/tamanho/motivo e retome o nó
pendente somente após o preflight passar.

## D-197 — aquisição de mídia estritamente sob demanda

Mineração, pesquisa e modelagem analisam fontes online e retêm apenas
metadados, decisões, direitos, hashes publicados e evidências leves. É
proibido baixar uma biblioteca local de vídeos candidatos. Um download local
somente é permitido para um ativo exato já vinculado a take aprovado,
revalidação de direitos e recibo de produção. Candidatos remotos não possuem
autoridade de render ou publicação. Após publicação confirmada, mídia local só
é elegível para liberação quando não houver fila, lease, render, vínculo
probatório ou dever de retenção; recibos, hashes, atribuição e decisões nunca
são removidos para economizar espaço. Não usar exclusão em massa, idade ou
heurística para classificar mídia como descartável.

## D-171 — acesso recuperado; retomada do Gestor ainda em instalação — 08/09 12:48UTC

OAuth real5d37aa/child24312exit0 recuperou o grant existente e confirmou o
canal em12:38:39Z; proof0012c76c… PASS, cota1unidade reservada/consumida.
Reusar recovery-v2 e preservar FAILd9830854…; não repetir refresh/diagnóstico.
A fonte local é histórica04/09 e possui o mesmo grant, não novo consentimento.
Watcherfbc994ea… substitui espera de30dias por passagem única: fonte ausente
retornaWAIT, grantigual não sobrescreve token/proof e monitor mantém retry.
11focaisPASS9f73f6, ainda não runtime instalado/D116; não promover por código.
GeometriaOpenImages4238cad3…:54imagens/77pares ambíguos em3124,12focaisPASS;
triagem de anotações não calibra detector. A12/59pendentes/GC01 permanecem.
Detalhes nos verification dos incrementos OAuth e OpenImages; custo técnico0.

## D-171/D-172 — evidência externa e incidente OAuth — 08/09 12hUTC

OpenImages:4GET/51.011.872B/receipt1da6fc76…; join realc9f2dd5b…,
6focaisPASS. PrimeiroJPEG671605B/1bfb4d1f… preservado; duas caixas contidas
com um rosto discernível exigem triagem, não deduplicação/gold por IA. Reusar
fontes/receipts; nenhum detector calibrado ou direito produtivo novo.
Varietycontract1ab6129e… tem14focaisPASS informados pelo terminale2232b do
executor; sem log persistido, mídia real ou instalação. Não criar tempos dummy.

Gestor11852 observado vivo12:06; lease válido após parse literalString noPS7.
OAuth falhou11:40:58Z/REFRESH_FAILED apósPASS10:45; não supor revogação.
Diagnóstico novo em revisão, separado de retry/credencial/identidade/publicação.
Fontes detalhadas em verificationOpenImages e PHASE6_VARIETY_CONTRACT_VERIFICATION.md.
Cota oficial38%used/62%restantes registrada12:03:33Z; decisãoa820e258b1185606,
reserva10%, âncora intacta. Caminho crítico somente, semreset/compra/downgrade.

## D-172 — observação nativa de cota, sem rebase — 08/09 10:53UTC

Fonte oficial36%usados/64%restantes; registro10:53:09Z SHA0dd9959f…,
decisão19c05a8d117eefd0/SHA0df25891… materializadaf2bf0bexit0. Reserva10%,
âncora01:57 intacta, consumo29,308674pp à frente do plano;54pp disponíveis
acima da reserva até15/09 01:22:52Z. Rendimento por tarefa continua desconhecido.
Qualidade máxima/caminho crítico somente; nenhum reset, compra ou downgrade.
Gestor local continua sob seus gates; não prometer cota ininterrupta ilimitada.

## D-171 — controles recuperados sem reinferência; composição candidata — 08/09 10:45UTC

Recuperação3e1928→cf393eexit0/27,965s, receiptf477c45b…7499B;
consumidor036f8e→092a9bexit0/24,123s.282origens históricas/dados conferidos,
zero nova inferência/decode/perfil/rede. Reusar os dois rawV2; FAILed4139ac…
e erro de inventárioe961ac permanecem. Seis focais novos/afetados PASS7,230s;
correção2a9b8f…/teste52ccb4… incluem process-receipt externoeba7089… e
urllib vazio exato. CHECKPOINT_RECOVERY não é PROVIDER_SWITCH/calibração.

Contrato de realocação25be9623…/teste86e8cf9…:13focaisPASS mais1afetado
após revisão. Real0faf60 gerou candidato a9a1f4e…/JSON871d03d0…:17estados,
83preservados,59pendentes e redução observada0. Receita candidata não aprova
linhagem, reuso/adjacência, timing ou fonte. Não repetir provas intactas;
seguir integração PUBLICITY/calibração/composição real sem promover A12/GC01.

## D-171 — inferências reais preservadas; fechamento em recuperação — 08/09 10:26UTC

V2 e9421e/sessão33910→2773a1exit1: filho8008SUCCEEDED0/147,203s,
duas inferências (positivo1/negativo0), controls81992498…; agregadorFAIL
ed4139ac… ao exigir tamanho positivo de urllib/__init__.py vazio já pinado.
Não repetir inferência, decode ou perfil. Workerfe46a5…/teste27445… intactos;
11focais afetados PASS1,070s. Recuperação exige consumidor novo, exceção de
origem vazia exata e reabertura integral; conservar terminal/problem FAIL.
Não aceitar qualquer falha genérica nem anunciar PROVIDER_SWITCH/calibração.
Audit PHASE6_CALIBRATION_SCOPE_AUDIT.md distingue controle operacional de
gold/domínio e comprova23candidatas contra30; sem novo alinhador/ASR/síntese
até referência temporal aplicável. A12/59pendentes/GC01/Fase6 permanecem abertos.

## D-171 — origem recuperada, não é calibração — 08/09 10:02UTC

Sonda608cea→8b2953exit0:62,593s,280origens, uma validate_profile, nenhuma
inferência. Terminala91fe247…/probe5b5eaec6… conferidosf30fd6. Reutilizar;
preservar FAILb8d400fd… e fixtureFAIL189724/recuperação000841. Worker8de464…
e teste1766… não são produtor PUBLICITY instalado. Processo novo deve atestar
suas próprias origens, sem herdar autenticação da sonda anterior. Dois PPMs
permanecem prontos para controle operacional, não gold/calibração de domínio.
Cota67%restantes/decisão7573c80add3264ef, reserva10%/âncora intactas; sem
reset, compra, downgrade ou fan-out discricionário. Gestor11852 e OAuth
noninteractive09:49PASS continuam; piloto público não conclui Vídeo2/Fase6.

## D-171 — controles decodificados; sonda de origem em recuperação — 08/09 09:48UTC

Dois decodes reais965663→f5d7f2exit0 produziram terminalb60cbf73…,
zero inferência/rede/custo. Três novos testes transacionais PASS1,056s;
reutilizar PPMs/receipts e rejeitar problem/final-problem no consumidor.
Semântica e0ac1e49… fechou10PASS e revisão independente dos dois achados.
Sonda2fd8…/d78… teve3focaisPASS, mas LIVEf58c71exit1/terminalb8d400fd…
falhou em cv2.Error. Não promover falha a origem aprovada. Diagnóstico único
dos imports identificou18 namespaces com _native exato e typing.io/re;
correção deve autenticar objetos/diretórios/arquivos, nunca aceitar prefixos.
Não repetir captura495MB, decodes ou testes intactos. Detalhes completos em
phase6-av-publicity-clock-fix-v1/controls-and-origin-execution.md.
Fase6/A12/59pendentes, calibração, PUBLICITY e GC01 permanecem abertos.

## D-171 — perfil real capturado, origem executada ainda pendente — 08/09 09:00UTC

Captura3ff777→85a026exit0 preserva profilec9225445…/capture18f62a61…:
2423arquivos/495.543.494bytes/87,066s.12focaisPASS17,881s, não workerLIVE.
Reusar captura; próxima sonda será o validador único e observará imports reais,
sem perfil arbitrário/caches ignorados ou repetição integral desnecessária.
Semântica de retorno bf95e54c… passou8testes puros; controles frontal/diagrama
pré-selecionados e observados, zero inferência. Dois exemplos não são gold
humano ou calibração de domínio. Evidência em runtime-profile-verification.md.
Nenhuma admissão, runtime produtivo novo, publicação ou fim de Fase6.

## D-171/D-172 — scope de replay e cota observada — 08/09 08:46UTC

Replay5704a5b7… acrescenta scope privado;13focais novos PASS59,975s
(513250/sessão1722→a73af1exit0), logb017ec66…. Reutilizar provas anteriores;
o teste2ae8a0b… permanece intacto. View expira após saída/falha; cópia dentro
do scope não certifica fechamento futuro. Ainda TESTED_ISOLATED_NOT_ADOPTED.
Cota nativa08:36:38Z:29%usados/71%restantes, decisãoee3214401fdaef6f,
SHA87c32a07…, AHEAD_OF_PLAN23,5046pp; reserva10%, âncora preservada.
Continuar caminho crítico com qualidade máxima, sem fan-out discricionário,
reset/compra/downgrade ou repetição de mídia íntegra. Runtime e calibração
continuam necessários; não promover PUBLICITY, GC01 ou Vídeo2 por este lote.

## D-171 — triagem e adaptadores focais encerrados, não adotados — 08/09 08:32UTC

Inspeção5190601 301435→8446ae exit0: um probe/um decode/12quadros,
terminal6b74034c… e report6c4ff2f8…; 12focaisPASS0,335s. Root viu contato
0954591a…: gesto de escrever é candidato a036, não prova de resultado037/038.
Reusar a triagem; um clipe não resolve sozinho a redução condicional12,207s.
Não ocultar exposição do painel por overlay ou promover direitos/QA final.

ReplayPUBLICITY novo533fe533…: baseline11PASS e revisãoTOCTOU corrigida,
4focaisPASS6,637s; integridade apenas, zero inferência. Adaptadorstage_a
b4e0cf29…:25PASS5,802s, incluindo A12real bloqueada antes de WAV/queue/A.verify.
Evidência em phase6-av-publicity-clock-fix-v1/integration-increments-verification.md.
Consumidorv3/runtime/calibração/instalação ainda pendentes. Não repetir os
lotes intactos, nem tratar testes sintéticos ou scopes privados como LIVE.

## D-171 — fonte candidata adquirida, sem admissão — 08/09 08:09UTC

Aquisição5190601-v2 0a86dcexit0:1GET,25.472.389bytes,source38b74bee…,
receipt3abdbcb2… (hash completo no verification), terminale816f6f1…;
18focaisPASS1,020s/7880ea e preflight7d5f07. Reutilizar os quatro artefatos
conferidos c6a5d9 e não repetir download intacto. Hash completo do receipt:
3abdbcb2cc2216e60d82219da75d8f5a951811b4e5ab074a3caa5b2276b6037d.
Quarentena não aprova PUBLICITY, direitos ou composição; v1 parcial preservado.
RETRY_SAME_PROVIDER não é PROVIDER_SWITCH. FFprobe de contêiner:2732×1440,
42,12s/1053frames declarados,sem áudio; CFR e movimento ainda não aprovados.
Integração canônica PUBLICITY deve usar root/contexto descoberto e argumentos
externos; A12 incompleta precisa falhar antes de A.verify/WAV/backend/escrita.
Não repetir 34 métodos clock-only nem manutenção instalada intacta.

Atualização de evidência: PUBLICITYv2 recuperação77a20d→f8c0a9exit0 fechou
11PASS33,044s;34métodos distintos confirmados com os23anteriores, sem terminal
agregado inicial presumido. Reutilizar log86407e00…/verification.md. O estado
continua TESTED_CLOCK_ONLY_NOT_ADOPTED; quatroachados e integração pendentes.

## D-171 — contraprova visual executada; preservar isolamento de PUBLICITYv2

Preflight4d965e46…/testee86d851c…:16/16PASS em2,897s(root1e85cd).
CLI40e40c calculou6f01d2938c429ad43cce6689, apenasA12/V4/V6metadata:
41estados selecionados/59omitidos; painel979968samples/40832ms e redução
mínima12207ms no cenário full-unit. Reutilizar verification.md; não é
alocação observada, sincronização ou autorização. Novas cartelas permanecem
suspensas até correção real de variedade/semântica, sem relaxar os gates.
PUBLICITYv2 usa módulo/schema separados: os helpersv1 b20ffd38…/schema0a4ef…
e consumidores A12 ficaram byte-exatos. Expiração corrigida não resolve os
outros quatro achados, não instala o sucessor e não cria PASS_LIVE admissível.
Primeira suíte perdeu terminal após23PASS observados; recuperar só11sem
resultado confirmado e preservar esse escopo. Candidato Pexels5190601 é
quarentena, não fonte aprovada. Downloadv1 parcial7b689b33… fica intacto;
nova tentativa exige envelope próprio, ETag, limites e terminal persistente.

## D-171 — lote A12 instalado; concentração exige correção anterior a novas cartelas

Manutenção66aae4cc→836013exit0 fechou1780PASS/1skip permitido,180schemas,
554artefatos; final2160bab5… e D116726e233e… comprovam recuperação do Gestor
PID11852 e ciclo novo12/12. Reutilizar essas provas; não repetir lote intacto.
Isso instala os contratos, não conclui GC01, mídia, publicidade ou Fase6.
Contraprova read-only fa2627: na hipótese de fonte integral por unidade, a
linhagem four-criteria ocuparia979968samples/40,832s; até no teto286,25s sua
parcela14,2645% excede10%. Não produzir mais cartelas dessa linhagem nem usar
IDs, transparência ou nome overlay para ocultar exposição. Exigir correção
real da alocação/composição e contraprova antes de ampliar o lote visual;
preservar A12, fontes, narrativa, hooks, união26 e todos os gates.
Cota nativa06:57:16Z materializada cbca6f27…:76%restantes, reserva10%,
AHEAD_OF_PLAN19,3751pp. Manter FULL_QUALITY_CRITICAL_PATH_ONLY; sem reset,
compra, downgrade, fan-out discricionário ou promessa de capacidade ilimitada.

## D-171 — timeline A12 real materializada; instalação pendente

Build exclusivo8edeca→70aeb6exit0 gerou timeline c38a12e6… e receipt
a307d2cc…; quatro hashes incluindo A11 preservada conferidos em9b358f.
39ativos/41usos/37conteúdos/3linhagens/59estados pendentes são vínculo de
metadados, não sincronização ou porcentagem de conclusão. A12 continua
BLOCKED_INCOMPLETE: união temporal26, nenhuma nova autoridade audiovisual.
Reutilizar o build único; não repetir PCM, imagens, OCR ou geração intactos.
Focais do builder12/12PASS47,328s; integração9PASS/1ERROR de fixture e
recuperação isolada1PASS preservadas. Uma manutenção agrupada/D116 deve
validar a instalação do lote A12/C15/adapter11 e leitores novos antes de
anunciá-lo instalado. Não promover o Vídeo2 ou a Fase6 por esse resultado.

## D-171 — recuperação V4 fechada; não é admissão de vídeo

V4 b17971→4da453exit0: receipt8a4a33c6…, inspection69af2feb…,
input2c836180…, claim24fb6510…; quatro hashes conferidos0eda86.
39ativos/41usos/37conteúdos/3linhagens/59pendentes em metadados sem tempo,
com27sources/29uses anteriores preservados. Zero decode/OCR/render/novo
direito/custo; um envelope com dois replays metadata. Não repetir a transação,
não promover cache a provider alternativo, nova QA, publicidade ou publicação.
A11 continua a última timeline real até construção e prova própria de A12.
Os consumidores novos ainda exigem instalação/regressão agrupada eD116.

## D-171 — registro fechado; replays exatos sem nova medição

Registro body70207e→2825a5 encerrou133,797s: receipte2b0beb8… conserva12provas,
24direitos hash-conferidos,2replays/11decodes/zero OCR/render/custo. Reutilizar
esse registro exclusivo; jamais repetir o commit. Estado apenas direitos
registrados, sem admissão, publicity, timing ou publicação.
Body-cache8PASS31a645, V3-cache11PASS26d9eb e leitorV6 onzePASS1540ea validam
seus escopos próprios. EXACT_CACHE_REPLAY não é PROVIDER_SWITCH ou nova QA.
A12/C15/adapter11 são evolução em teste com backups, ainda não instalados;
não promover41usos/59pendentes antes da timeline real, nem inferir conclusão
da Fase6 a partir de testes estruturais. Uma manutenção agrupada/D116 somente
após fechamento dos contratos/consumidores e testes afetados.

## D-171 — identidade estável e retenção de provas, 08/09 05:30UTC

As provas body são locais ao template e idênticas entre single, subset e lote;
o identificador não pode depender de outra família pedida na mesma chamada.
Contadores por prova representam um replay integral do template, não custo por
estado. O total operacional vem de um sink privado preenchido só após sucesso
integral. Registro preserva as doze provas completas e sua execução, evitando
novo decode para fabricar relatório equivalente. Sinks não aceitam prova/cache
de entrada nem tornam falha parcial em sucesso. Snapshots anteriores preservados.

Focais: facade17PASS10,235s (be142f→0a04a8); direitos27PASS49,975s
(3061c7→408fa2); registro13PASS75,640s (6a1aa5→c0dd3f), sendo cinco novos
contratos e oito transacionais afetados. Oito transacionais intactos do lote
anterior não foram repetidos. Preflight real d205c1 PASS sem escrita. Commit
70207e/sessão64320 em execução; não considerar o registro concluído antes do
terminal e rechecagem. A11 permanece29/71, sem nova autoridade audiovisual.

## D-171 — QA dos dois lotes concluído; integração conjunta em curso

Three-moves preserva receipt8a099616…/QA50015cb4… e dez focais de replay
aprovados. Record-learning preserva receiptc61b7a2a…/QA95295ea2…: cinco
conteúdos/seis ocorrências, cinco OCR, oito checks de pixels em cada registro
e quatro checks de continuidade; o par idêntico compartilha a mesma medição,
não representa seis fontes
independentes. Não repetir raster/OCR. QA estático não aprova compreensão,
timing, áudio, publicidade do conjunto, A11, render ou publicação.

O erro de assinatura da fixture drift ficou preservado em b9fc15; correção
somente do teste passou1/1afetado(02b4b8), dezesseis intactos reutilizados.
Registro conjunto:16testes transacionais sintéticos PASS74,382s(49ea61),
não registro LIVE. Novos facade/direitos/schema/replay continuam em revisão.
Não tratar arquivos novos ou fixture como instalação aprovada: reunir provas,
consumidores versionados e uma manutençãoD116 do lote, mantendo legados eA11.

## D-171 — ritmo de cota observado, não disponibilidade ilimitada

Em08/09/2026 04:32:27UTC, fonteoficial13%used/87%remaining, renovação
15/09 01:22:52UTC; decisão dc0ec169… GREEN/AHEAD_OF_PLAN9,643748pontos.
Não rebasear aâncora01:57 para ocultar o ritmo. Reserva10, criticalpathonly:
fecharlotestécnicoscríticos já abertos, semnovaexpansãodiscricionária ou prova
intacta repetida. Gestorlocal continua; nenhumdowngrade,compra/resetautomático,
conversãodos2500créditos/umresetempercentual ou promessadeoperaçãoinfinita.

## D-171 — instalação A11 encerrada, fontes novas ainda diagnósticas

Manutenção e58a92f9 terminou4a5977exit0:1671executados/1670PASS/1skip de
privilégio já permitido,178schemas,554itens. Final5659fe07… e D1162d56c0be…
comprovam Gestor23076, ciclo novo12/12, cinco snapshots conferidos e barreiras
ausentes. Reutilizar esse lote; não repetir regressão intacta. FAIL4eaf3294
permanece preservado. A11 continua29usos/71pendentes, sem conclusão GC01/Vídeo2.

V6ba7dabb1…/receipt e56a4135… corrige somente24strings em21estados, preserva79,
hooks,29usos, narrativa e união26; STAGED_NOT_ACCEPTED_BY_A11. Não herda QA,
direitos ou timing. Receita three-moves cc31bfaf… tem18focaisPASS, não aprovação
de mídia. Publicação de arquivos finais é exclusiva, inclusive contra colisão
de bytes iguais; privado+link exclusivo não pode herdar a tolerância do writer
legado. Fontes novas só avançam com provas próprias, não com testes de fixture.

## D-171 — contraprova A11 preservada

A manutenção4eaf3294 terminouFAIL:1671executados,1erro,1skip de privilégio
symlink;1310,274s. O schema rejeitou corretamente question_case_amendment_evidence
na fixture de downgrade1.1. Corrigida apenas sua remoção no teste, backup
b2d768d2…/sucessor99c1ea90…, focal1/1PASS3,870s. Recovery a5d2d87a… recuperou
Gestor19872, mas não aprovou manutenção, A11 produtivo, áudio ou Vídeo2.
Preservar FAIL f038e1bc… e repetir somente o lote integral exigido após correção;
não reconstruirV3/A11, renderizar ou reinferir entradas intactas.

## D-171 — A11 materializado, instalação ainda pendente

Reutilizar timeline06198f55…/SHA10f31b09… e receiptac5f859a…: execução única
63ef21exit0 fechou29usos/71pendentes, mantendo clocks, pausas, narração,
históricosV2/V3, união26 e todos os bloqueios A10. V5 é evidência separada;
case2estados/3strings/98preservados não pode mudar uma âncora lexical. Este
sucesso comprova metadados, não scheduling, áudio, B/C/D, runtime produtivo
ou publicação. C14schema e5fdabd7… corrigiu somente o const aninhado do
adapterv10; FAIL23aaec e recuperação focal24/24ab6520 permanecem registrados.
Não repetir V3/A11 concluídos ou seus decodes/receipts para aparentar avanço.
Manutenção agrupada e D116 precisam encerrar antes da próxima integração.

## D-171 — direitos das perguntas e integração A11 em curso

Registro real ab6bdbb3… cobre quatro PNG próprias/oito documentos, sem
autoridade de áudio, sincronização, publicity, render ou publicação. Reutilizar
esse registro e as provas de fonte/reconciliação; não repetir direitos como
nova decisão. V3/joiner passaram9+8focais;29usos/71pendentes ainda são prova
focal, não A operacional. A11 deve manter V2/V3 como história separada de V5,
união26, clocks e bloqueios intactos; question_case_amendment não pode ser
introduzida retroativamente em A10. Limite32MiB só para os três modelos OCR
pinados; leitores legados permanecem16MiB e metadados literais2MB. Backups dos
consumidores em before-A11-integration são hash-conferidos; instalar o lote
somente com regressão agrupada e recuperaçãoD116, sem repetir provas intactas.

## D-171 — V5 staged, reuso de fontes sem refazer mídia

Reutilizar emenda b07bca4c…/projeção7fd136fe…/receipt3e22ff39…; permanecem
STAGED_NOT_ACCEPTED_BY_A10, não plano ativo. Question source3ed0553a… combina
contêinerPNG verificado e QA/ink pinados, sem decode/OCR; rights15eb742a… tem
nota própria79fbcfa9… e17testesFIXTURE, não registroLIVE. Replay68221c67… dos
25usos passou7testes, reabre âncora/input/inspection e toda dependência sem
avaliador de pixels/direitos. Não repetir materialização antiga ou aceitar
cache sem pins/inventários. Novo templatequestion não cria nova linhagem.
71pendentes só após29usos realmente integrados; A10 ainda conserva75. Novos
leitores ainda exigem instalação/regressão agrupada/D116 e não concluem mídia.

## D-171 — reconciliação estática das perguntas encerrada

Report0ac7a3fb… em reconciliation-f3904b4f063f15c87e2bfd9b aprovou somente
STATIC_SCOPE em08/09/2026 02:07:44UTC. Sete contornos de tinta medidos em
quatroPNG,0,453s; zero OCR novo/render/QA integral repetido. Reutilizar esse
receipt e os quatro scans; preservar FAIL eac99752… sem reclassificá-lo.
Os campos, safearea, copy e confiança não foram ampliados. Consumo exige nova
versão explícita do contrato/stager; não converter o report em QA v1PASS.
Caso/projeção ainda não materializados, A10/25usos/75pendentes intactos.
O wrapper antigo foi preservado antes de corrigir limite do modelo21MB e pin
do claim; nove focais56c8d8 PASS, não recuperação ou staging real aprovado.

## D-172 — nova observação nativa de capacidade, sem resgate pelo sistema

Captura08/09/2026 01:57:38UTC retornou2%usados/98%restantes, renovação
2026-09-15T01:22:52Z,1resetdisponível. Causa da mudança da janela é UNAVAILABLE;
nenhum reset foi resgatado por esta verificação. Saldo2500não é porcentagem,
orçamento de compra ou autorização automática de uso do reset. Policy anterior
b3644104… preservada; nova ae2d9e7e… ancora somente essa observação real.
Decisão d9be9e5c827a55d0 GREEN/ON_PLAN; reserva10%/qualidadeultra/custo0 intactos.
21/21focaisPASS0,608s f1314e, sem reabrir regressãoAV. Evidência completa em
output/operations/codex-usage/observations/rebase-20260908T015738Z-evidence.json.
QR Dolar segue pausado; cota compartilhada não se converte em duas reservas.

## D-171 — contraprova do OCR de perguntas

PreservarQA eac99752… FAIL_STATIC_SCOPE e seus4scans: copycorreta4/4,
pixels9/9 por estado/revelação4/4; envelopeOCR não é contorno de glifo.
Contraprova precisa separar associação do detector e tinta real dentro dos
campos originais, sem ampliarlimites/baixarconfiança/refazerOCR. Stagercase
não usa esseFAILcomoPASS; apenas contraprova versionada pode alimentar novo
consumidor, nunca alterarhistória. A10/75estadospendentes seguem intactos.

## D-171 — lote A10 instalado; quatro fontes de perguntas em QA

Instalação 87be8b35 encerrada em08/09/2026 01:28:01UTC, final50b68c85,
SHA55bc5fdea4c340966ac7605eee4628d5f70ceb9ba5142ae2dca6fdfde2eab726:
1.556PASS/1skip permitido,175schemas,554itens. D1162b2aa4c7… PASS,
SHA21610796d575e64eb1d3b4615ee51b510c08b4654688611df76d033baabe9ac0;
cinco snapshots hash-conferidos, Gestor2216→14048 e ciclo novo12/12.
Reutilizar provas; A9 instalado e instalação pendente abaixo são históricos.
Não repetir regressão intacta. Nenhuma aprovação de áudio, B/C/D, GC-01 ou vídeo.
Quatro cartelas u019–021 existem sob receiptf63ac629… (01:28:50UTC), uma
geração1,375s; root observou todas. Não são quatro linhagens nem fontes admitidas.
QA independente, direitos e emenda case-only ainda necessários;75usos sem
vínculo continuam75. Não atribuir tempo/FPS à PNG nem usar UNIT_ENTRY como
onset lexical; preservar u020-s01[18,35) e os96estados fora do lote.

## D-171 — usos v2 verificados, consumidor A10 em validação

Atualização posterior: A10 realf4be1a12…/SHA42eaa6f7… encerrou15,938s,
receipt e0f667014b752c02900d7d94c0ea754fdab1c02040305167b61ecc344d8f54ed.
Argumentos41541066… não serão rematerializados. A10 preserva todos os clocks,
gates e união26; prova limitada25/75 não é fechamento temporal. Wrapperadf57664…
recheca fontes, implementações e allowlistfont/decoder/textwrap até o receipt;
11/11focaisPASS70cbab68…. Resta instalação/regressão+D116 do lote, não novoA10.

V2 real9e14abf9…/inspection14641e1… vincula25ocorrências a23ativos de estado,
22conteúdosPNG e3linhagens; preserva os13usos anteriores e75estados não ligados.
Reutilizar input65be0312… e receipts, sem nova materialização. Fonte verificada
e direitoOWNED não geram tempo, span ou admissão. A10/schema1.9 acrescenta apenas
literal_asset_use_evidence, separada de static_source_evidence temporal;
C13/adapterv9 recusam o compositor antigo sob a emenda. A9 permanece íntegro.
Dois defeitos de migração (enum histórico aninhado e dispatch de bordaPCM)
foram corrigidos preservando FAILa82b3ca1… e backups. Não reduzir guards para
aprovar fixtures antigas. Execução realA10, instalação/regressão/D116 deste
lote ainda pendentes; os resultados abaixo são históricos, não promoção.

## D-171 — cartelas compactas com direitos próprios, uso ainda untimed

Em08/09/2026 00:23:19UTC, registro compacto5dfd9d4f… encerrou12decisões
OWNED limitadas, uma linhagem, custo0 e toda autoridadefalse; request029d9066…
é checkpoint fixo por versão. Não registrar novamente as mesmas fontes.
Reuso exige âncora externa, cadeia/bytes/dependências exatos; corrupção nunca
autoriza overwrite ou promoção. O direito refere-se ao raster esquemático,
não a publicity, parecer jurídico, autoria humana, redistribuição de fonte,
declaração sintética do vídeo completo ou publicação. HOLD conserva12arquivos/
11conteúdos; source[0,1) não recebe FPS/duração de vídeo. Inspectorce21a4c5…
preserva os dois write lexicais e a continuação u016 sem horário inventado.
Direitos9ae330a8… validam previamente todos os documentos do batch antes do
decoder e rechecagem final integral. Registrador386e09cb… inscreve request novo
no Reader antes de efeitos seguintes; retomada exige pin externo do request.
O vínculo25usos está em implementação separada, não admitido em A/B. Manutenção
A9 abaixo não cobre automaticamente este novo lote; não repetir mídia/ASR/OCR.

## D-171 — A9 recomposto, instalação do lote ainda pendente

Atualização posterior: instalaçãoa4f5d1da/finaleb285901 concluiu PASS com
1.469PASS/1skip,173schemas e D116a503fb61…/novo ciclo12/12. GestorPID2216.
Reutilizar essa prova sem repetir manutenção intacta. O título e o texto de
pendência abaixo preservam o checkpoint pré-instalação; não o estado vigente.
Capability do handshake residente é suporte de protocolo, não barreira ativa;
request/ack/recovery são as barreiras que encerraram. GC-01 e o AV permanecem
incompletos. Continuar o próximo incremento de fonte/uso sob contrato próprio.

A9 08c58eb7…/SHA5105f3a4… incorpora a emenda compacta sem alterar relógio,
unidades, intervalos, razões de silêncio, união26 ou blockers de A8. Somente
evidence_ref de padding mecânico/hook migra para o hash integral dos inputs
novos; referências de pausa editorial não mudam. Receipt36c585e7… não aprova
mídia nem scheduling. Preservar FAIL935227/0dd57876… e argumentos parciais
34e60eda… recuperados por leitura exata, sem overwrite. Retomada exige pin
externo válido e recusa timeline já gravada antes de reconstruir. O leitor
novo mantém a prova V2 histórica separada da projeção de12mudanças/88estados
preservados. C12/adapterv8 rejeitam uso do renderizador antigo com a emenda.
Instalação só após regressão agrupada e recuperação D116; não repetir A9,
imagens, OCR ou áudio intactos. A emenda continua SOURCE_PENDING e sem
admissão, compositor compactoAV, referência temporal ou aprovação perceptual.

## D-171 — integração tipada de fontes estáticas, em implementação

Amendment87567b59…/projeçãoV3d629bce9… estão staged com10/10focaisPASS,
não ativas. DecisõesD169 e receita antiga permanecem históricas; somente mapa
before/after externo altera12conteúdos visuais. Preservar88estados,25negativas,
entradas e HOLD. Leitor antigo não aceita wrapper novo; integração exige
recomposição/versionamento, nunca substituição silenciosa ou readiness inferida.

Ensaio two-column-compact-v1: receiptcf6aeb64… possui12estados/11rasters,
e reconciliação677fe3df…passou somente estática/OCR. Reutilizar essas imagens
e11leituras; preservar o FAILec708da8… do teste incorreto deRGB sólido. Perfil
independente6px/LANCZOS mede582.144pixels internos sem tolerância, não bordas,
timing ou vídeo. Não promover os novos rótulos/copy ao planoV2/A8 silenciosamente:
exigir sucessor editorial versionado, narrativa e controlesD169 conservados,
mais direitos/publicity, calibração, scheduling e QAAV aplicáveis.

Lote instalado: manutenção636c9615/final31cfd112 PASS (1.444 PASS/1 skip,
172 schemas), D11619b5e05e… e ciclo4cb60c42…12/12. Reutilizar essas provas;
os checkpoints de instalação pendente abaixo são históricos. FAILs anteriores
permanecem preservados. Runtime recuperado não aprova GC-01, Vídeo2 ou Fase6.
Cartelas two-column-v2 têm 9–19 palavras; não herdam aprovação do guard8 que
lê só on_screen_text nem do OCR que ignora takes null. Exigir composição e
cobertura por estado versionadas, contagem integral, sem waiver de legibilidade
ou freeze. Bindings estáticos13/11/duas linhagens não são fontes prontas.

Manutenção: um snapshot de lock deve usar JSON e SHA do mesmo buffer, lido antes
do relógio de observação; não comparar heartbeat novo a relógio antigo. Conservar
`heartbeat_at <= observed < lease_expires_at`, identidade, processo vivo e todos
os cutoffs. A tentativa 94c3c90d teve 1.418 PASS/1 skip e fechamento final FAIL;
recuperação do PID e D116 intermediário não a tornam aprovada. Preservar a falha
e exigir contraprovas mais nova instalação verificada, sem repetir mídia intacta.

A8/schema1.7 fecha somente a população literal a partir do plano visualv2 e
cap71:26alvos,100estados,90fragmentos,51unidades. Receipt reala944a4f5…,
timeline9542021b…; zero eventos/spans/cues agendados. `scope_complete=true`
neste ramo significa união literal, nunca fontes/tempo prontos. O blocker
TEMPORAL_VISUAL_STATE_BINDINGS_PENDING e all_required_evidence_live=false
preservam a separação até um mapper produtivo versionado comprovar cada estado.
Subset de requirements/captions precisa coincidir literalmente antes de ler
calibração; manter os11contratos estáticos e25decisões não lexicais. Cohort30
continua incompatível com23candidatas na mesma velocidade; não diminuir mínimo
ou inventar referência. C11/schema1.10/adapterv7 e B1.7 preservam esses gates.
Reutilizar A7/A8 e focais já encerrados; manutençãoD116 do loteD171 ainda pendente.

A7/schema1.6 integra somente o plano literal cap71 congelado3ddd6d1d…;
17unidades lexicais/37ranges internas e34cues integrais, sem timestamps criados.
Texto, ranges, ordem, linhas e classe temporal reais precisam corresponder ao
plano; resegmentar sob o mesmo rótulo é rejeitado. Dependências incluem o adapter
e textwrap exato, rechecados. Cobertura literal de captions não autoriza scheduling,
calibração ou escopo visual completo; ausência de cues agendados bloqueia o
agregado temporal. A6/receipt09858928… permanece preservada. C10/schema1.9 e
adapterv6 consomem A7. RealA7/receipte0e3a53c… comprova integração literal,
21alvos declarados/51exclusões conservadoras e zero autoridade, não mídia pronta.

Correção de escopo temporal em curso: os quatro alvos declarados no bundle
parcial não representam a união global. D169 preserva mínimo26; ausência de
intenção, spans ou captions não prova ausência de alvo. A6/schema1.5 deverá
separar alvos declarados, exclusões conservadoras e completude calculada,
bloqueando consumo de calibração quando o escopo estiver incompleto. Não usar
um boolean fornecido pelo candidato como prova nem inventar tempos para fechar
essa condição. C9/schema1.8 e adapterv5 consumirão a nova versão com pins próprios;
as versões A5/C8/v4 e seus testes permanecem histórico, não aprovação da correção.

A6 real07084756…/receipt09858928… já confirma11fontes/4alvos declarados/51exclusões
conservadoras, sem consumir calibração ou conferir autoridade. Reutilizar essa
evidência íntegra. O plano literal de captions71 precisa ser vinculado sem
agendamento inventado: preservar a segmentação editorial específica, inclusive
003/016/031; recontar ranges não autoriza mudar cláusulas sob a mesma versão.
Cobertura literal de captions não equivale a união temporal global completa.

Uma PNG verificada contém exatamente um frame de origem, intervalo [0,1), sem
FPS ou duração de vídeo atribuídos. A duração de permanência vem exclusivamente
da timeline A. Intenção visual 1.2 distingue STATIC_IMAGE de VIDEO_CFR; a versão
anterior não ganha esse suporte. As duas famílias próprias continuam duas
linhagens, não onze fontes independentes. Entrada da unidade não prova onset
lexical: manter cada revelação, seu intervalo literal e a calibração exigida.
Estados não agendados permanecem na união conservadora e bloqueiam conclusão;
não inventar tempos para permitir a compilação. A5/C8 e adapter de duas colunas
v4 são evolução versionada com backups, não promoção de provas antigas.
Teste estrutural ou compilação fixture não aprova B, sincronização perceptual,
freeze QA, direitos/publicity, execução LIVE ou publicação. Não relaxar esses
consumidores para aceitar imagens; integração produtiva exige provas próprias.

Direitos estáticos1.1 de B reabrem proveniência e decisão editorial externas,
imagem/SVG/receita/fontes e inspeção A exatas; não reutilizam duração ou licença
de vídeo. O pool legado continua obrigatório. Rechecagem final usa somente o
sink interno da chamada; dependências de receipt serializado não são prova de
replay. OWNED de composição própria não afirma autoria humana, exclusividade
jurídica, publicity ou aprovação do vídeo integral.

## Missão

Construir um sistema real, verificável e progressivo para minerar, modelar, produzir, validar e escalar canais faceless. A produção deve ser principalmente baseada em recortes permitidos, nova narrativa e montagem orientada por um modelo comprovado, com ferramentas locais e gratuitas sempre que forem suficientes.

## Fontes de verdade

Antes de qualquer ação, leia:

1. `docs/STATE.md`;
2. `docs/00_MASTER_SPEC.md`;
3. `docs/01_EXECUTION_PROTOCOL.md`;
4. `docs/07_PHASES_AND_GATES.md`;
5. a especificação e o prompt da fase ativa;
6. os schemas relacionados à fase.
7. `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md` e `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`.

Estas regras são obrigatórias. Em caso de conflito material, aplique primeiro a regra permanente mais restritiva, registre a decisão e prossiga nas partes independentes. Só solicite intervenção quando o conflito depender de autoridade externa, direito, credencial, pagamento, ação destrutiva ou decisão do proprietário que não possa ser resolvida por evidência.

## Regras imutáveis

- D-170, lote verificado: manutenção9b618b19/D116321a0845… encerraram a instalação com1.292PASS/1skip,170schemas,554itens e novo ciclo12/12. Reutilizar seus receipts/snapshots, sem repetir regressão intacta. O painel20rotas/17domínios tem zero PROVIDER_SWITCH validado e conserva COVERAGE_GAPS; fonte encontrada não equivale a recuperação observada. Gestor recuperado e testes aprovados não concluem GC-01, Vídeo2, áudio ou Fase6. O FAIL2f7de15f e as correções permanecem preservados.

- D-170, contraprova de manutenção: teste de runway usa fixture temporal completa e pinada, nunca policy viva com datas antigas; o rebase real da conta não pode alterar retrospectivamente o caso. O worker Windows verifica o Job Object explícito do supervisor, membership, flags e ambos os tetos exatos; consultar jobNULL sob launcher aninhado não comprova esses limites. Handle QUERY não herdável fecha antes da medição, e falha de consulta/fechamento bloqueia. Não remover flags, ampliar teto, pular os testes ou usar execução direta como única prova do launcher produtivo. Falha de regressão mantém o histórico FAIL e exige recuperação do Gestor; runtime recuperado não é manutenção aprovada.

- D-170: toda rota de fallback distingue PROVIDER_SWITCH, EXACT_CACHE_REPLAY, CHECKPOINT_RECOVERY, RETRY_SAME_PROVIDER, DEFER e BLOCKED. Só troca entre executores realmente validados/equivalentes pode ser anunciada como provider alternativo. Nunca trocar voz/identidade/ativo pinado, métricas privadas por públicas, direito ou padrão-ouro silenciosamente; cada mudança exige novo contrato/receipt e gates aplicáveis. Espera e bloqueio não são sucesso de fallback. Recuperação de cache deve reconstituir âncora/receipts/bytes antes de qualquer efeito; corrupção não permite overwrite. Limite de transporte não pode introduzir retry invisível ou consumo de quota sem reserva por tentativa. Fallbacks permanecem custoR$0 e subordinados à fase ativa e ao Gestor.

- D-169: a intenção7375e478… resolve decisões das29unidades antes indefinidas, não fontes/spans/união final de A. Novos alvos005/006/007/026 elevam a união mínima a26 e deixam no máximo23candidatas de mesma velocidade; o cohort30 continua inutilizável. Os exemplos próprios `fear-examples-design-v1.1` distinguem acontecimento de inferência atribuída a `Fear says:`; nunca mostrar forgotten/rejection/God has left como fato isolado. Uma família de composição não vira seis fontes de variedade. Reutilizar os seis estados/receipt076ec5be… e quatro PNGs preservados; inferências lexicais continuam sem tempo validado e não há admissão produtiva. A cartela OCEAN TODAY, caiaques com pessoas e Torre Eiffel no lugar de porta não foram aprovados. Painéis de u019/u021 não podem herdar os ordinais0/4 e2/4 de u034.

- D-167: continuidade usa a heartbeat existente `hero-engine-rotina-di-ria`, agora horária, sem duplicar o Gestor ou reabrir trabalho concorrente. A instrução antiga de executar `scripts/daily.ps1` em todo despertar foi substituída: manutenção integral somente após alteração efetiva que a exija, com testes focais e recuperação D116; não repetir mídia, ASR, DNSMOS ou regressão intactos. Observar cota quando necessário, sem polling redundante, sem consumo automático do reset restante e sem promessa de disponibilidade ilimitada. Estado inalterado não gera notificação.
- D-168: supervisor Windows `audio_perception_supervisor.py` contém a árvore por Job Object, timeout e memória comprometida; não é gate de percepção. Replay do receipt ca771052… cobre apenas o master WAV8e8909fe…, nunca AAC/mixagem/vídeo final. A reconciliação627cb339… identifica seis unidades com desacordos ASR (001/007/013/014/015/016); 011 é homofonia lexical. Não contar contextos do mesmo Whisper como avaliadores independentes, não fabricar pronúncia correta/incorreta ou escuta. Integrar a avaliação ao sucessor A–D versionado, sem usar o gold de mineração como calibração acústica ou repetir inferência no verificador.

- D-166, capacidade restabelecida: a resposta do proprietário à solicitação específica de reset autorizou UM resgate gratuito. A ferramenta nativa retornou outcome=reset para idempotencyKey d7479865-518e-4a72-b1de-1ad1798dd3ef; cota0%usada/100%restante,1resetgratuito restante, renovação2026-09-14T13:10:45Z. Receipt preservado em output/operations/codex-usage/reset-receipts/. Nova âncora real13:11:51Z, policy anterior copiada/hash-conferida; decisão codex-usage-576f5b798ac3ec08 GREEN/ON_PLAN. A restrição temporal de reserva D165/D152 não rege esta nova observação como se ainda restassem9%; preservá-la como história. Continuar fases autorizadas sob gates, qualidade e reserva10%; sem autorização automática do reset restante, compra, crédito convertido em porcentagem ou promessa de operação ilimitada. Trabalho paralelo só delimitado, relevante e sem repetir provas intactas.

- D-165, observação vigente de capacidade em 07/09/2026 13:05:42 UTC: decisão nativa materializada `codex-usage-08c002b7b684d875` registra 9% restantes, abaixo da reserva10%, estado CRITICAL_RESERVE; renovação2026-09-13T02:15:36Z. Existem2resets gratuitos disponíveis, nenhum consumido. O pedido de continuidade integral mantém as fases autorizadas, mas não é autorização específica para resgatar reset nem suspende automaticamente custo/reserva/qualidade. Concluir checkpoint seguro; conservar Gestor local e gates. Solicitar somente decisão específica sobre um reset gratuito, sem pedir aprovação de fase, escuta rotineira ou oferecer compra. Não criar monitor duplicado, fan-out ou trabalho extenso sob a reserva; uma concessão futura de reset exige ferramenta nativa, idempotência e nova observação antes de rebase.

- D-164: DNSMOS P.835 fullcoverage v1 é instrumento auxiliar local medido, não aprovação de áudio, humano gold, pronúncia, prosódia ou calibração temporal. Reutilizar master/receipt ca771052… e verificação 20bf33c4…; não repetir inferência intacta. Preservar versão Microsoft, licenças, hashes, diferenças SWR/tail e resultados por janela. MOS sozinho não aprova silêncio, clipping ou qualidade editorial. Integração ao gate produtivo exige validação de domínio, contrato de erro, recuperação e regressão aplicável. A ausência dessas capacidades permanece lacuna interna, sem escuta rotineira imposta ao proprietário.

- Avaliação sonora autônoma — correção do proprietário em 07/09: não encaminhar escuta rotineira de vídeo ao proprietário como solução para lacuna do avaliador. A implementação/validação do avaliador permanece responsabilidade do sistema. Distinguir medições técnicas, estimativas perceptuais, pronúncia, prosódia, sincronização e padrão-ouro; nenhum modelo, concordância entre ASRs ou recusa de escuta vira revisão humana. As exigências de referência temporal, direitos e calibração continuam vigentes. Ausência de capacidade mensurável é lacuna interna explícita, não novo pedido de aprovação genérica.

- D-152, reserva atingida: a observação oficial materializada em 07/09/2026 04:08:16 UTC registra 10% restantes e zero ponto percentual acima da reserva. Não iniciar fan-out, processamento pesado ou repetição de trabalho intacto para aparentar avanço. Preservar o checkpoint e a operação local sob seus gates; não consumir reset, comprar capacidade ou reduzir qualidade automaticamente. Isto é restrição de planejamento, não limite oficial já esgotado, autorização para desligar o Gestor ou prova de conclusão. Reavaliar com uma nova observação nativa somente quando necessária, sem polling redundante.

- D-163: policy temporal6587e640… e cohort30PCM são preparação, não calibração ou anotação. Exigir união integral de alvos A antes de solicitar/usar o cohort; a união parcial captions+eventos conhecidos não basta. Sobreposição futura bloqueia, sem alterar narrativa para proteger amostra.800samples é alvo pré-registrado do ensaio, não precisão medida/limiar universal. Preserve anotaçõesnull, ambiguidades e falhas até evidência genuína; policy aceita e nove verificações de contrato não autorizam inferência, render ou publicação.
- D-163, conflito aplicado: o audit3a6aa9e… inclui020/034/041como alvos editoriais adicionais e prova a incompatibilidade do cohort30/mínimo30 com no máximo27candidatas restantes. Não usar esses artefatos antigos; preservar histórico e refazer a seleção somente após união final. Cue de unidade inteira não exclui revelação visual lexical; inventário90/90não prova observação de fontes, união final ou aprovação semântica.

- D-162: fixtures de ciclo não podem herdar estado terminal vivo e apagar a evidência exigida por esse estado. A fixture de previsão é sintética, completa e independente do observer real; o receipt vivo permanece intacto. Teste de calibração deve distinguir referência fora do PCM de erro/cobertura fora da policy, sem enfraquecer os dois guards. Reutilizar um harness por importação do módulo, nunca exportar seu TestCase e descobrir a mesma suíte novamente. Inventário e descoberta devem coincidir por identidade canônica e multiplicidade; correção de fixture não aprova mídia nem dispensa D116.
- D-162, evidência encerrada: manutenção753a9beb passou com1164casosPASS e1skip de ambiente já permitido; D116173200f3… comprova recuperação e ciclo novo12/12. Reutilizar esses receipts/snapshots, não repetir regressão ou render intactos. Um único gate agregado restante(GC-01) não significa projeto quase concluído: o sucessor audiovisual e a medição real continuam obrigatórios; nunca apresentar skip como teste aprovado ou evidência técnica como revisão sonora.

- D-161: binding `clean_plate_receipt` no adapterv3 exige recomposição read-only do receipt real pelo verificador pinado; mantenha canal/Bible/TakePlan, ativo, linhagem, contagem e intervalo de origem coincidentes. `source_technically_verified=true` não equivale a `source_ready`, admissão ou render/publicação. C v7/schema1.6 conserva autoridade falsa, inteiros exatos, identidade JSON canônica e rechecagem de residência/junction/OFFLINE. O único dependency de tamanhozero permitido é o stdout vazio exato do render já preso ao seu terminal; não generalize a exceção a fontes ou receipts.

- D-160: a base própria `two-column-clean-plate-v1` é uma única linhagem de composição, não um vídeo final nem fonte de variedade artificial. Seus 60 segundos representam capacidade do ativo, não duração narrativa autorizada. Reutilize o receipt e os bytes já verificados, sem rerender de entrada intacta; conferir RGB/relógio/streams não dispensa admissão, direitos aplicáveis, sincronização, percepção ou QA do vídeo composto. Replay exige pins externos de runner e receipt e não executa subprocessos. A saída FFprobe da versão pinada pode conter apenas `programs=[]` e `stream_groups=[]` como campos opcionais conhecidos; outros extras, duplicatas e constantes não finitas são rejeitados.

- D-159: `UNIT_BOUNDARY`/`WHOLE_UNIT_PCM_START` é uma borda estrutural exata do contêiner PCM, nunca início observado de palavra. Só intenção visual1.1 e A v4/schema1.3 podem usá-la; a versão antiga não ganha essa capacidade. Frame, unidade, primeiro fragmento e span precisam coincidir; chars/alignment/incerteza permanecem null. O adapter v2 aceita somente os nove pares take/unidade congelados; take014/016 continuam lexicais calibrados e take021 continua HOLD de fonte contínua. Apenas uma borda integralmente recomposta pode ser excluída da união de alvos de calibração; captions/eventos lexicais da mesma unidade continuam nela. Contrato estrutural implementado não significa evento produtivo registrado, mídia pronta, aprovação perceptual ou publicação.

- D-158: a preparação de duas colunas recompõe os 12 estados literais de take012–023 e a intenção narrativa do evento A. Um prefixo lexical só ancora uma revelação quando coincide com o início do fragmento e possui alinhamento validado; fronteira inteira de unidade não é timestamp de palavra nem contrato visual já implementado. A continuação take021 só dispensa nova mudança gráfica quando o mesmo span cobre integralmente o estado take020, sem troca de fonte. Spans fora do exercício, fontes ligadas/não residentes e divergência de bytes bloqueiam. `source_ready=false` e cobertura parcial jamais autorizam render, fila ou publicação; layout e fixture não aprovam mídia. Reutilize as provas concluídas, sem repetir render/ASR/testes intactos para aparentar produtividade.
- Atualização temporal de D-158: a ausência de contrato de fronteira referia-se ao adapter v1/A v3. D-159 acrescenta suporte explícito nas novas versões; não transforma a borda PCM em evidência lexical nem promove artefatos históricos.

- D-157: a receita AV deve recompor A a partir de `PHASE6_AV_RAW_ARGUMENTS` externo, imutável e hash-bound; inputs/rótulos do candidato não são prova. O adapter visual recompõe a receita allowlisted e suas dependências reais; cobertura parcial nunca concede grafo integral, admissão ou render. Os verificadores de C e do adapter comparam bytes JSON canônicos, não igualdade numérica permissiva (`150` e `150.0` têm identidades diferentes). Preserve as versões anteriores; não repita processamento de entradas intactas para criar progresso aparente.

- D-156: a narração contínua editorial de202.780ms e a contraprova ASR das cinco divergências estão materializadas como QA, não aprovadas. Reutilize seus receipts/WAV, sem repetir montagem/inferência ou gerar51vozes novamente. Homofonia write/right não prova erro de locução; divergências001/007/013/016 exigem contraprova acústica, nunca alteração automática do texto esperado. Dois ASRs não são gold humano nem calibração temporal. Não preencher déficit de duração com silêncio sem função editorial.
- D-156, master: o derivado5d7ebccf… passou somente níveis/duração/PCM; fonte e falha anterior preservadas. Não repetir normalização/ASR contextual encerrados nem tratar volume correto como aprovação perceptual, temporal ou produtiva. Próximo componenteC só compila sem efeitos; execução depende integralmente deA/B/gates.
- D-156, contratoC: `phase6-av-render-recipe-v1` possui apenas grafo `COMPILED_FIXTURE_NOT_EXECUTABLE`; LIVE retorna `BLOCKED_INCOMPLETE`. Sete testes de contrato não concluem a EtapaC. A evolução exige recomposição integral deA com inputs externos, compilador visual allowlisted e integração versionada deB/capacidade/runtime. Nunca conectar filtros opacos ou promover flags autorreferentes a prova executável. Preservar os três arquivos congelados antes de evoluir sua versão.

- D-155: o protótipo editorial `editorial-hook-v1-01bb2c91eeccb03bebab` é uma composição nova do take-003, não reclassificação dos rótulos físicos v3. Preservar seus artefatos e os FAILs anteriores. As provas de 150 frames/450 hulls e identidade de pixels em duas regiões demonstram somente separação/preservação da fonte redimensionada; não aprovam narrativa, fonte original, movimento intrínseco, áudio, publicity ou publicação. Reutilizar o render concluído; fechar rastreabilidade por leitura dos receipts, nunca renderizar novamente apenas para obter relatório equivalente. O executor diagnóstico não é executor produtivo; A–D e todos os gates permanecem obrigatórios.

- D-154: a contraprova de semeadura por cadeia `paper-chain-photometry-v1-7471eacad84740f1` terminou com 0/6 pares aprovados, contra 3/6 históricos. Preserve-a rejeitada; não promova melhoria parcial de cobertura/condição nem repita varredura de parâmetros nesses casos. Priorize a entrega do Vídeo 2 e uma composição realmente mais simples quando conservar os locks; alternativa editorial precisa de novo artefato/contrato/prova, não reclassificação de defeito físico como HUD. Não criar arquitetura, catálogo ou pesquisa paralela discricionária por cada falha. Qualidade, direitos, custo zero e cadeia A–D permanecem exigidos.

- D-153, contraprova aplicada: reuso de cache preserva o journal original e reconstitui a cadeia exata de fonte/ordinal/overlay/candidato; não transplante intenção nem aceite lista autodeclarada de dependências. Integridade de etiquetas corrigida não compensa flicker/HUD ou qualquer gate não medido. O report741e5e92e59244d8cdfbc7b0a4bdbb90b5fc132852cefc940c140b9f9c5fe3a5 permanece FAIL_DIAGNOSTIC_CLOCK_QA e sem autoridade produtiva, embora geometria/pixels/HUD passem. Não consumir um boolean de componente como aceite agregado.

- D-153: na composição de sequências indexadas, FPS nominal igual não prova sincronização. Valide contagem, PTS e base racional de cada entrada antes de overlay; normalização por ordinal só cabe em uma grade CFR comprovada, nunca em VFR desconhecido. A contraprova `hook-framesync-diagnosis-v1-dbcb8d01c8c66a3e` demonstra atraso de uma etiqueta em 50/150 frames do candidato histórico; preserve-o reprovado e não desloque a referência do QA para fazê-lo passar. A correção de relógio precisa de novo artefato e contraprova, não limiar menor. Admissão AV continua pendente: contexto deve vir da fila canônica read-only, capacidade não pode anunciar LIVE com receita projetada/injeção de fixture e publicity requer observação de todos os spans e contraprova independente.
- D-152: por declaração do proprietário em 06/09, QR Dolar está pausado e somente Modelagem Youtube participa do planejamento ativo até nova retomada expressa. O limite continua único e compartilhado pela conta; não existe atribuição oficial por projeto nem prova de ausência de outras atividades. O planejamento `workload_plan` usa reserva de 10%, âncora de observação nativa e renovação observada; `renewal_runway` mede ritmo orçamentário, não duração garantida ou custo previsto por tarefa. Nunca converter saldo de créditos/resets em percentual semanal. Mudança de renovação exige nova base real; adiar trabalho discricionário extenso quando o ritmo estiver acima do plano, sem reduzir qualidade, interromper checkpoint seguro ou parar runtime local autorizado. Não despertar a operação pausada nem criar monitor duplicado.
- D-137: verificador estrutural e layout não aprovam semântica. A proposta `visual-alignment-0d081c519410bf855a2fe0f6` está reprovada editorialmente; preserve-a como histórico e não a promova. Reclassificar tratamento não cria evidência visual; mecanismo falado e identidade gráfica precisam de relação compreensível, nunca equivalência 1:1 inventada. Papel de ativo coincidente não prova que número de elementos, conteúdo, legibilidade ou continuidade correspondem à fala. Corrija a seleção/composição, sem ocultar contradições por rótulo ou média de score.
- D-138: o sucessor pós-efeito tem contrato dedicado e exige verificador integral, raiz canônica e prova imutável; a base transacional/fixture não concede essa autoridade. Não reabra SUCCEEDED nem amplie uma classe que preserva ativos para aceitar troca de ativos ou narrativa silenciosamente.

- Execute apenas a fase ativa e a fila sequencial autorizada em `docs/STATE.md`; desde D-047, as Fases 5–8 estão autorizadas em sequência, mas nenhuma pode ser marcada como concluída nem iniciar runtime dependente antes do gate verificável da anterior.
- Não antecipe, simule ou marque como pronta uma fase posterior.
- Não troque implementação real por explicação, pseudocódigo ou mock não identificado.
- Não invente dados, métricas, transcrições, direitos, resultados ou integrações.
- Toda análise relevante precisa apontar evidência: timecode, frame, trecho, métrica, arquivo ou fonte.
- Diferencie sempre: observado, calculado, inferido, privado e indisponível.
- Minere hooks nos intervalos `0–1 s`, `1–3 s` e `3–8 s`; em vídeos longos, inclua `8–30 s`.
- Faça decomposição take por take, não apenas resumo de assunto.
- Modele conjuntos de vídeos, incluindo vencedores, medianos e fracos. Um viral isolado não define o modelo.
- Modele mecanismos e regras; não copie a identidade ou a obra específica de uma referência.
- O modo principal de produção é clip-based. Não substitua automaticamente por geração integral de vídeo.
- Não existe regra de “porcentagem de alteração” que assegure originalidade. Use transformação narrativa substantiva e verificável.
- Só use um ativo na produção quando o status de direitos permitir ou quando houver revisão editorial/jurídica registrada.
- Licença autoral, domínio público ou permissão de reutilização não provam autorização de imagem, marca, publicity ou endosso. Antes da alocação e novamente no QA, o sistema deve falhar fechado diante de instituição/marca conhecida, pessoa detectada, mídia ilegível ou ambiguidade; detecção negativa automática reduz risco, mas não equivale a liberação jurídica. Modelo local usado no gate precisa de licença, versão e SHA-256 fixados.
- Não implemente evasão de Content ID, mascaramento de cópia, remoção de marca d'água ou tentativa de enganar sistemas da plataforma.
- Nenhum upload, publicação ou gasto externo ocorre sem autorização expressa. D-047 autoriza upload/publicação sem gasto somente para artefatos que passem todos os gates críticos, possuam direitos válidos, canal/credencial aptos, receipt e rastreabilidade; Ads, serviço pago e qualquer gasto continuam bloqueados até orçamento explícito.
- **CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.** Ferramenta, API, servidor, domínio, armazenamento, voz, imagem, vídeo, automação e infraestrutura com cobrança são proibidos; não cadastrar cartão nem iniciar trial com renovação.
- Use somente ferramenta gratuita/open source, processamento local, infraestrutura já disponível, API oficial em cota gratuita e serviço gratuito sem exigência de cobrança. Cada adapter registra limite, consumo, renovação, risco de cobrança, fallback gratuito/local, capacidade, tempo e qualidade.
- Ao atingir margem preventiva de cota, migre para fallback gratuito/local e bloqueie a chamada antes de qualquer risco de cobrança. Nenhuma capacidade pode ser declarada pronta se depender de contratação futura.
- Ferramentas locais são a primeira opção, mas qualidade e rastreabilidade não podem ser omitidas. Se o conjunto gratuito não atingir o gate mínimo, o estado correto é `BLOCKED`, nunca gasto, relaxamento ou alegação de capacidade.
- Única exceção financeira: futura mídia no YouTube Promote, tratada como orçamento de anúncio e somente após valor expressamente definido pelo proprietário; não autoriza qualquer assinatura, API, servidor, domínio ou ferramenta paga.
- Credenciais ficam em variáveis de ambiente e nunca são gravadas no repositório.
- OAuth interativo deve usar a tela oficial do provedor, exigir seleção explícita da conta em computadores com múltiplas sessões e validar a identidade final. Não crie, imite, preencha ou automatize senha, código, seleção pessoal ou consentimento; depois da concessão, use refresh não interativo e token isolado.
- O Gestor testa e persiste a saúde OAuth sem navegador em intervalo diário, repete falhas transitórias com espaçamento e só solicita nova concessão diante de revogação/ausência real do refresh token ou falha reiterada. Não abra login recorrente por expiração normal do access token.
- Nunca conte views, horas ou inscritos originados de campanhas como progresso qualificado do YPP; a fonte oficial exclui campanhas.
- RPM real de concorrente ou de canal ainda não monetizado é `UNAVAILABLE`, não uma estimativa apresentada como fato.
- A válvula de aquisição de `docs/12_ACQUISITION_ACCELERATOR_MASTER.md` é ação protegida: planejamento faseado, gasto somente com aprovação expressa e sucesso somente por incremento orgânico qualificado.
- O nicho, a identidade e os gates são rígidos; tema, ângulo, embalagem, hook, ritmo e seleção visual são adaptativos e reavaliados por sinais versionados. Não congele um template criativo nem chame uma hipótese pré-publicação de resultado viral.
- Visualizações só orientam decisões após normalização por idade, formato e baseline comparável. Um outlier isolado, views brutas ou metadados sem profundidade não promovem regra.
- Na Fase 6, o checkpoint próprio elegível deve produzir diagnóstico versionado do gargalo e pré-registro de exatamente uma variável antes do próximo vídeo entrar em produção. Estado sem evidência usa `UNDETERMINED`/`NONE`; autorização de produção nunca equivale a autorização de publicação.
- O diagnóstico elegível deve gerar um `Phase6TreatmentOrder` imutável e atravessar o executor transacional antes de qualquer render. Tratamento de embalagem atua no mesmo vídeo e mantém a timeline bloqueada; ângulo, hook ou narrativa compilam o Vídeo 2. Nenhum dos dois autoriza alteração pública, render ou publicação sem seus gates posteriores.
- Na Fase 6, a cadeia obrigatória do candidato é `tratamento -> escopo LIMITED -> release work order -> síntese/render local -> avaliação independente -> pacote congelado -> release gate -> staging privado -> thumbnail -> captions -> processamento -> promoção pública -> verificação final`. Cada elo valida o hash e o receipt anterior; nenhum estado de espera autoriza o elo seguinte.
- Se o diagnóstico da Fase 6 selecionar `TITLE_THUMBNAIL_PROMISE`, o executor atua somente no canário exato e somente sobre o par título-thumbnail pré-registrado e hash-pinned. Ele preserva o snippet e a thumbnail de rollback, reserva 100 unidades gratuitas de cota (`videos.update` 50 + `thumbnails.set` 50), verifica API e CDN pública e reverte ambos os campos se a confirmação falhar.
- O tratamento de embalagem deve iniciar no limite do dia do Pacífico, registrar o deslocamento real em segundos e manter o pacote congelado durante a medição. O aprendizado compara as duas datas adjacentes exatas do Reporting API, usa impressões como tamanho amostral do CTR e conserva incerteza e limite causal; dado cumulativo do mesmo vídeo não pode representar braços independentes.
- Todo forecast operacional da meta atual usa a janela exata D0–D30. Contador YPP, cadência, probabilidade ou distribuição indisponíveis permanecem `null`/`UNAVAILABLE`; artefatos de horizontes legados ficam fora do caminho vigente e preservados como histórico.
- Score, badge, geração ou recomendação de provedor externo é evidência auxiliar não causal. Ferramentas com créditos gratuitos exigem ledger de limite/consumo/renovação, piso preventivo e fallback sem cobrança; lista vazia de canais autorizados significa Analytics próprio indisponível, mesmo quando a conta está autenticada.
- Modele mecanismos atuais de tração, nunca a redação, identidade, voz ou obra específica de um vídeo viralizado.
- Toda produção passa pelo Diretor Criativo subordinado ao Gestor Central, com `CreativeDirectionDecision`, `FormatPack`, Style Bible, TakePlan e Quality Gates versionados.
- Formato em `CATALOGED`, `SPECIFIED`, `PROTOTYPED` ou `VALIDATED` não é capacidade de produção regular. Só `PRODUCTION_READY` ou `LIMITED` dentro do limite pode ser selecionado.
- Um FormatPack `LIMITED` só pode atravessar uma nova unidade, ação ou ordinal quando um receipt de escopo versionado provar literalmente que o uso continua dentro do limite. Diagnóstico, pré-registro ou estado `LIMITED` isolado não ampliam o contrato; divergência, ausência ou gate pendente bloqueiam compilação.
- É proibido misturar estilos, ferramentas ou pipelines sem justificativa narrativa e regra de continuidade; nenhum prompt, gerador ou montagem universal representa todas as macrofamílias.
- Personagem, cenário, roupa, idade, proporção, cor, iluminação, espaço ou tempo só mudam com exceção narrativa registrada.
- Cada take precisa de função narrativa, alinhamento semântico, função de retenção, origem, direitos, ferramenta, versão, custo e critérios de qualidade.
- Falha crítica de estratégia, ChannelDNA, narrativa, hook, semântica, estilo, continuidade, personagem, movimento, legibilidade, áudio, técnica, direitos, publicidade aplicável, originalidade, identidade, custo ou publicação bloqueia o vídeo; média não compensa falha.
- Correção de criatividade nunca pode ficar em princípios genéricos: identifique defeitos por timecode/take, registre hipótese de correção, produza artefato versionado e compare evidências antes/depois antes de alegar melhoria.
- D-129: `on_screen_text=null` significa ausência de overlay, nunca a string `None`. Tipo inválido falha antes de escrita. Mudança de renderer altera a identidade da receita/cache e preserva receipts históricos; frame diagnóstico isolado não aprova vídeo, e divergência entre texto visível, TakePlan, narração e Style Bible bloqueia a publicação.
- Compilação criativa longa exige busca com no mínimo seis rotas únicas e três alternativas elegíveis, scores decomponíveis, checks críticos explícitos, comparação contra referências, distância entre rotas, red-team e decisão versionada. Um único roteiro fixo, resumo copiado, nota perfeita fabricada ou score tratado como probabilidade viral bloqueia a produção.
- Tratamento de embalagem também exige busca própria com no mínimo seis rotas únicas e três finalistas elegíveis, promessa comprovada pelo vídeo congelado, complementaridade título-thumbnail, distância do baseline e das referências, render source próprio com hash e red-team. O avaliador posterior recompõe a decisão integral antes do render; três pares A/B/C fixos, troca manual ou hash autorreferente não constituem decisão criativa válida.
- O avaliador independente recalcula pesos, scores, elegibilidade, contagens, máximos de similaridade e vencedor da busca criativa. Ele não aceita como prova os rótulos ou resumos emitidos pelo próprio compilador.
- Experimento de uma variável deve preservar as demais de forma verificável: `FIRST_8_SECONDS_MECHANISM` altera somente 0–1/1–3/3–8 s e conserva o corpo; `BODY_PROGRESSIVE_DISCLOSURE` conserva os hooks 0–8 s e usa somente permutação dos blocos anteriores. Vazamento entre dimensões bloqueia compilação e release.
- `CreativeDirectionDecision` usa o seletor real do `FormatPack`, com componentes observáveis e limiar explícito. Fit uniforme em `1.0` sem evidência é inválido; score pré-publicação prioriza hipótese e nunca prova viralidade, retenção ou monetização.
- Seleção de oportunidade de mercado usa `opportunity_score` como chave primária somente depois dos pisos de elegibilidade, observação e atualidade. Profundidade da evidência, quantidade de canais e ID servem apenas como desempates versionados; não podem ser somados novamente fora do score. Política, piso, ordem de ranking, snapshot/versão/hash da fonte e hash canônico do candidato entram na identidade imutável da ordem. Imediatamente antes da compilação, o sistema reabre a fonte, confere hashes/identidade/unicidade e refaz a seleção; divergência bloqueia sem artefato parcial.
- Contagem de fontes únicas e ausência de repetição adjacente não provam variedade. Todo long-form deve medir participação máxima por ativo, concentração dos seis maiores, reutilização total e repetição por janela móvel; resultado encostado no limite exige margem ou justificativa registrada, não aprovação complacente.
- Antes de cada publicação, o pacote deve referenciar um `Channel Readiness Audit` atual. Descrição, localização, Home, marca, catálogo, YPP, política e OAuth são gates do canal; falha crítica bloqueia mesmo quando o vídeo isolado passou.
- Dado visual do YouTube Studio só pertence ao HeroVerse quando a superfície identifica o channel ID/handle correto. Redirect, recurso, strike ou contador de outra sessão Google não pode ser atribuído ao canal; preserve `UNAVAILABLE`, registre a divergência e faça contraprova pública/oficial sem automatizar autenticação.
- Alteração pública de perfil deve gerar receipt e ser confirmada por API ou página pública. Se a experiência resultante estiver vazia ou divergente, reverta quando possível e registre o incidente.
- Manutenção integral deve parar apenas a cadeia de processo verificada do Gestor, reconciliar a integridade somente depois da parada, testar a snapshot estável e recuperar o runtime em `finally`. Comparações de tempo do lock usam UTC por `DateTimeOffset`; falha de teste nunca pode deixar o Gestor desligado.
- O lock do Gestor mantém heartbeat em thread própria durante operações longas. A manutenção trata o launcher do venv e o processo Python real como uma cadeia verificada, tolera somente encerramento transitório do PID exato e compara objetos temporais diretamente em UTC, sem conversão dependente de cultura local.
- D-127: no Windows, liveness de PID usa consulta read-only por `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)` + `GetExitCodeProcess` + `CloseHandle`; acesso/consulta/fechamento indisponível bloqueia manutenção e migração, nunca significa processo morto. `os.kill(pid, 0)` fica restrito ao POSIX, e a prova completa ainda exige PID, lock, início e cadeia da tarefa coincidentes.
- A avaliação de cada vídeo antes da publicação é automática, presa ao hash e executada por avaliador separado do gerador. Revisão humana não é formulário obrigatório por release: serve para calibrar o padrão-ouro, amostra mínima de 10%, mudança de versão/formato/ferramenta, ambiguidade de direitos/publicity, anomalia/reclamação e checkpoint do terceiro vídeo `LIMITED`. Sem amostra humana suficiente, a capacidade não ultrapassa `LIMITED`; o sistema nunca se declara revisor humano.
- A avaliação da Fase 6 materializa os 18 gates críticos permanentes e os 19 defeitos técnicos controlados. Todos precisam `PASS`, junto do padrão-ouro e do controle negativo; média ou score agregado não compensa uma falha crítica.
- O gate `PUBLICITY` da Fase 6 é independente de `RIGHTS`: ele registra evidência por ativo, detector/modelo exato e motivo de bloqueio. Risco conhecido é excluído antes do render; rosto, erro de decodificação ou risco remanescente no candidato bloqueia publicação automática e exige tratamento/revisão aplicável.
- A publicação da Fase 6 é private-first e retomável. Cada efeito externo é persistido imediatamente no receipt; retries reutilizam o mesmo YouTube video ID e a mesma idempotency key. Só a verificação final do vídeo público exato pode produzir `COMPLETE_PUBLIC`.
- O aceite da Fase 6 é materializado por `phase6_acceptance.py` em 22 critérios GC. `PASS_FIXTURE` não substitui evidência viva quando o critério exige `LIVE`; relatório documental antigo, teste verde isolado ou ausência de erro não podem promover a fase. A manutenção persiste comando, contagem, duração e logs da regressão em receipt schema-validado.
- GC-14, aplicação futura de aprendizado, pertence à Fase 7 junto da Rule Registry e da segunda medição; tratá-lo como requisito da Fase 6 cria dependência circular e é proibido. A passagem 6→7 ocorre somente por controlador fail-closed e receipt imutável que recalcula todos os requisitos da Fase 6 em vez de confiar apenas no rótulo `APPROVED`.
- D-106/D-109: uma iteração da Fase 6 só pode ser apresentada como integral quando `control-cycle/latest.json` 1.1 comprovar, no mesmo intervalo do loop, os 12 estágios ordenados — incluindo `GOAL_TRAJECTORY` entre `LEARNING` e `PHASE_TRANSITION` —, schemas válidos, timestamps dentro da janela e hashes de conteúdo/identidade. Ausência, erro operacional, schema inválido ou estágio fora da janela bloqueia. Receipts 1.0/11 permanecem apenas como histórico legado e não satisfazem o aceite corrente. `PHASE_TRANSITION=BLOCKED` com `PHASE6_ACCEPTANCE_BLOCKED` e IDs GC explícitos é resultado legítimo do gate, não falha de execução. Heartbeat sem mudança atualiza `latest` e não cria histórico material.
- D-107/D-109: uma aceitação `APPROVED` nunca pode promover 6→7 no mesmo ciclo em que mudou aprendizado, trajetória, aceite ou transição. O controlador deve aguardar um `control-cycle` 1.1 material anterior (`INITIAL`/`STATE_CHANGED`, `history_archived=true`), idêntico byte a byte ao histórico imutável, com 12/12 estágios, zero blocker e identidades `LEARNING`/`GOAL_TRAJECTORY`/`PHASE_TRANSITION` reconciliadas ao estado corrente. O receipt 6→7 prende caminho, SHA-256, assinatura substantiva e as três identidades; replay revalida tudo e adulteração bloqueia. GC-07, GC-20 e GC-22 consomem a mesma prova integral.
- D-108: a meta de 30 dias exige trajetória oficial de inscritos, não apenas baseline antigo. Em cada checkpoint próprio devido, reserve 2 unidades gerais antes de chamar as APIs e capture o vídeo exato e `channels.list(mine=true)` para o channel ID exato. Calcule baseline, total atual, gap até 1.000, ganho líquido, ritmo observado/exigido, ganho linear esperado, delta e razão de ritmo. Sem contagem oficial atual, preserve `null`; minutos do Analytics nunca substituem horas públicas válidas do YPP. Pressão de trajetória só prioriza a próxima ação já permitida e jamais autoriza publicação, gasto ou bypass de gate.
- D-110: falha isolada de `channels.list` não pode descartar métricas válidas do vídeo nem adiar silenciosamente a trajetória até a próxima janela formal. Preserve a elegibilidade criativa já provada, agende retry próprio da fonte de inscritos a cada 30 minutos por no máximo 6 horas/12 slots e exponha `SUBSCRIBER_TRAJECTORY_SOURCE_RETRY_EXHAUSTED` se o teto terminar. Contagem oculta/indisponível fica `null` e não consome retry inútil.
- D-111: a trajetória de 30 dias exige uma observação oficial de canal em cada D1–D30, separada dos checkpoints criativos D1/D3/D7/D14/D30. Reutilize o snapshot próprio imutável quando ele cobrir o slot diário; nos demais dias, permita exatamente uma unidade gratuita após preflight com piso preventivo 12. Falha recebe retry 30 min/6 h; indisponibilidade oculta não repete. Após downtime, encerre comandos vencidos com receipt de supersessão e colete somente o slot diário mais recente devido. O controlador usa a fonte oficial schema-válida mais fresca, sem reexecutar diagnóstico criativo ou apresentar baseline antigo como contagem atual.
- D-112: todo plano, catálogo ou painel da janela D0–D30 deve representar D1–D30 como observações oficiais agendadas. Diferencie explicitamente observação diária de canal, checkpoint criativo e autorização de publicação; jamais rotule um dia intermediário como “sem checkpoint” quando o observador D-111 estiver ativo, nem apresente uma observação como postagem prometida.
- D-113: baseline histórico e contagem corrente são grandezas distintas. Nenhum painel, cálculo, alias legado ou fallback pode apresentar o baseline como medição atual; enquanto a fonte oficial corrente não existir, total atual, gap e toda projeção dependente permanecem `null`/`UNAVAILABLE`. A medição atual deve registrar flag, origem e instante próprios. Cold starts de componentes locais pesados usam orçamento temporal medido e limitado, sem remover a exigência de receipt/PID/lock coincidentes.
- D-114: ritmo da meta só existe depois de duas origens oficiais distintas dentro da janela iniciada pela publicação. O baseline anterior serve para referência e gap histórico, nunca para o numerador ou denominador do ritmo. Wrapper diário `OWNED_METRICS_REUSE` mantém a identidade e o instante do checkpoint próprio e não cria uma segunda medição.
- D-115: todo ponto usado na trajetória precisa validar integralmente no schema de origem, permanecer na pasta autoritativa esperada, ter filename igual ao identificador interno e, quando for `latest`, ser byte-identical ao seu twin imutável. `OWNED_METRICS_REUSE` só é aceito se caminho, channel ID, status, contagem, precisão, visibilidade, totais de vídeo/views e instante estiverem ligados ao checkpoint próprio schema-válido. JSON ilegível, parcial, deslocado, divergente ou sem twin bloqueia o cálculo; nunca é ignorado nem tratado como observação oficial.
- D-116: a regressão executada com o Gestor parado valida lógica contra uma snapshot estável, não prova runtime vivo. Toda manutenção bem-sucedida precisa, depois do reinício, comprovar tarefa/processo/lock/console/singleton/energia, aguardar um ciclo novo 12/12 iniciado após o mesmo receipt, reconciliar aceite e painel executivo e arquivar snapshots exatos hash-bound dessas cinco fontes. Sem esse receipt pós-manutenção, a manutenção não pode terminar com sucesso.
- D-117: toda coleta externa de outcome de previsão exige, antes da chamada, preflight `phase6_prediction_outcome_checkpoint` schema-válido, custo R$ 0,00, reserva exata de 2 unidades gerais e piso preventivo 12. O caminho imutável e o SHA-256 desse preflight devem entrar no checkpoint transacional antes do efeito externo. Cota desconhecida/bloqueada impede a chamada; retry sobre snapshot já coletado só é permitido depois de revalidar path confinado, hash, schema, operação, reserva, piso, custo e permissão do mesmo preflight, sem recolher novamente.
- D-118: toda coleta externa para avaliar um tratamento exige o mesmo contrato sob a operação `phase6_treatment_metrics_checkpoint`: preflight imutável, 2 unidades gerais, piso 12 e custo zero antes de Reporting/Data/Analytics. Espera por cota deve alterar o `available_at` real da fila sem consumir tentativa. Cada resultado externo concluído precisa ser copiado e preso por SHA-256 no diretório exato do job; retry de etapa posterior reutiliza apenas a prova intacta e nunca repete uma chamada já concluída.
- D-119: o checkpoint próprio D1 segue o mesmo journal por etapa. O job nasce antes do guard; cota bloqueada usa `defer` +5 min sem tentativa. Preflight, Reporting registry e snapshot de métricas são imutáveis e hash-bound no job. Falha depois de uma etapa não pode repeti-la; a inteligência só consome o snapshot arquivado quando a visão `latest` usada pelo compilador permanece byte-identical. Falha técnica é `ERROR`, nunca pode ser ocultada pelo estado inicial `BLOCKED`.
- D-120: o observador diário da trajetória só pode executar `channels.list(mine=true)` depois de preflight imutável preso ao job. A resposta normalizada deve ser arquivada imediatamente em um slot imutável por janela, com schema, identidade, caminho e SHA-256. Falha posterior reutiliza essa leitura e não chama a API novamente; adulteração bloqueia sem recolha. Cota desconhecida ou insuficiente usa `QUOTA_WAIT` real de cinco minutos e devolve o lease sem consumir tentativa.
- O primeiro protocolo real `PREREGISTERED` da Fase 6 torna-se `experiments/active.json` imutável. Checkpoints posteriores não podem trocar baseline, variável, métrica, amostra, janela ou timestamp enquanto o experimento estiver ativo; `latest.json` precisa permanecer byte-idêntico ao protocolo ativo.
- GC-01 e GC-19 só passam com a cadeia viva exata. Um runtime `EVALUATED` solto, avaliação de outra previsão, fixture ou arquivo schema-válido sem binding de canal/vídeo/protocolo/snapshot/horizonte/receipt não constitui aceite.
- Leituras oficiais da Fase 6 usam contabilidade do dia de quota do Pacífico. Observação de console fora do dia zera apenas a base expirada e recebe reserva conservadora de 2.000 unidades para uso não rastreado; o receipt registra base, janela, margem e fallback. Margem insuficiente adia a operação, nunca habilita billing.
- Antes de a regressão diária avaliar evidência viva, toda visão operacional derivada cujo contrato evoluiu deve ser regenerada com o código/schema corrente após a parada verificada do Gestor. Essa migração nunca pode reescrever receipts ou fontes imutáveis.

## Gestor Central Autônomo

- A Inteligência Contínua Viva é o Gestor Central Autônomo e a única autoridade operacional e fonte de verdade de toda a operação, sempre subordinada ao envelope operacional versionado, à fase autorizada e aos gates permanentes.
- Módulos, agentes, subagentes, workflows, schedulers, plugins e integrações são executores subordinados. Eles não mantêm estratégia, regra aprendida, fila prioritária ou memória operacional paralela.
- O proprietário supervisiona por exceção: acompanha postagens, resultados, custos, alertas e decisões importantes; ações protegidas exigem a aprovação definida no envelope. D-047 remove somente a espera por aprovação entre fases e por escolhas técnicas rotineiras; não remove direitos, orçamento, credenciais, política, confirmação obrigatória de plataforma nem revisão humana de padrão-ouro exigida pelo contrato.
- O Gestor pode executar rotina automaticamente somente dentro de limites já aprovados. Publicar, gastar, contratar, trocar credenciais, mudar objetivo, regra protegida, direito, identidade, limite de custo ou política, excluir dados ou ampliar escopo sem autorização permanece bloqueado.
- Toda ordem deve manter a cadeia `objetivo -> evidência -> decisão -> comando -> executor -> artefato -> resultado`, com idempotência, estado, versão e trilha de auditoria.
- Só declare aprendizado após `observação -> baseline -> hipótese -> previsão prévia -> experimento -> resultado -> avaliação -> atualização versionada -> aplicação futura -> nova medição`. Sem evidência nova, registre `NO_NEW_EVIDENCE`.
- Previsibilidade só pode ser alegada após superar baseline simples fora da amostra, com erro, calibração, cobertura, tamanho de amostra, janela e incerteza registrados. Nunca equivale a garantia de monetização, visualizações ou lucro.
- Previsões pré-registradas precisam de job temporal idempotente e avaliação imutável após o horizonte. Uma previsão retida por falta de calibração ainda preserva o outcome real e prova a rejeição do modelo, mas não autoriza a palavra “previsível”.
- Gates de aceitação cumulativos usam receipts imutáveis. A evolução legítima do estado corrente não pode apagar uma prova histórica válida nem transformar `PASS` em `FAIL` só porque o snapshot mais recente mudou.
- `operational_ready` exige continuidade elétrica lógica: monitor, suspensão e hibernação em zero para AC e bateria, receipt schema-validado e rechecagem no bootstrap/manutenção. A reconciliação da tarefa deve propagar o caminho canônico do token externo a partir do watcher OAuth; fallback inexistente nunca pode substituir silenciosamente uma credencial válida.
- Nenhum job local de mídia pode ser criado antes de um preflight de capacidade `PASS` para o TakePlan exato. O receipt deve executar FFmpeg/FFprobe, provar modelos/fonte/diretórios graváveis, validar continuidade, intervalos de origem e alinhamento frame-exact, calcular o pico de disco pela receita real e preservar no mínimo 5 GiB após o render; déficit ou evidência ausente bloqueia antes da fila.
- Antes de selecionar ativos para qualquer produção da Fase 6, o Gestor executa a auditoria integral de residência da biblioteca realmente elegível: leitura e SHA-256 completos, flags Windows `OFFLINE/RECALL`, decodificação FFprobe, duração, direito comercial, receipt de direitos e capacidade segura. Divergência, arquivo remoto/não residente, falha de decode ou direito inconsistente bloqueia a seleção. O TakePlan escolhido revalida novamente hash, span e ledger imediatamente antes da fila de mídia.
- No ramo `TOPIC_ANGLE`, o planejamento de voz do corpo reserva `ceil(max(400 ms, 10% da duração estimada) / 100 ms) * 100 ms` de margem. Esse estimador só elimina texto inviável; a única prova executável de encaixe é a síntese Kokoro exata, presa ao modelo, voz, velocidade, TakePlan e script, concluída atomicamente para todos os takes antes de a fila/claim poder consumir o job. É proibido truncar áudio ou acelerar a locução para forçar encaixe. O perfil vigente é `am-onyx-kokoro-planning-v2`.
- A classe `PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION` só pode substituir um job de mídia quando antigo e novo estão pré-efeito em `PENDING`/`RETRY_WAIT`, sem lease e com checkpoint `{}`. A decisão mantém semântica, canal, protocolo, variável, candidato, direitos, custo R$ 0,00 e `publication_authorized=false`; diferenças ficam em whitelist, presas por hash e receipt imutável, o histórico é preservado e o job antigo torna-se não reivindicável. Essa remediação nunca dispensa render, avaliação independente, Quality Gates, release gate ou publication lock.
- Atraso de métricas criativas no D1 não pode paralisar nem autorizar inferência indevida. Em idade >=24 h, um contador oficial do vídeo exato abaixo do piso de 30 views pode liberar somente `DISTRIBUTION_SAMPLE -> TOPIC_ANGLE`, com confiança baixa e constantes criativas bloqueadas. No piso/acima dele, fonte ausente/divergente ou diagnóstico de embalagem, hook ou narrativa, retenção/CTR/APV próprios completos continuam obrigatórios. O fallback deve ser raw-verificado no snapshot, diagnosis e scope overlay versionado.
- Nenhum mecanismo autônomo pode aprovar a própria exceção, contornar gate de fase ou promover regra entre canais sem teste de transferência.
- O Diretor Criativo é executor do Gestor: não possui memória, estratégia, fila, aprendizado ou autoridade de aprovação paralelos.

## Forma de execução

Para cada fase, em modo contínuo D-047:

1. faça preflight;
2. apresente plano limitado à fase;
3. implemente;
4. crie ou atualize testes;
5. execute as verificações;
6. compare com os critérios de aceitação;
7. apresente evidências;
8. atualize `docs/STATE.md` com o resultado real;
9. se todos os gates passarem, promova a fase automaticamente e inicie a próxima da fila autorizada;
10. se um gate falhar, registre causa, corrija, reexecute e continue; se houver bloqueio externo real, finalize as frentes independentes e consolide uma única solicitação objetiva.

`AWAITING_REVIEW` continua válido para um artefato que realmente dependa de revisão humana/externa, mas não interrompe as demais frentes nem é usado como aprovação inter-fases. O próprio gerador nunca substitui o revisor humano do padrão-ouro.

## Definição de concluído

Uma tarefa só está concluída quando:

- o resultado existe em arquivo ou comportamento executável;
- os testes relevantes passam;
- há exemplo real de entrada e saída;
- todos os critérios foram classificados como aprovado, reprovado ou bloqueado;
- limitações estão explícitas;
- nenhum requisito foi silenciosamente removido;
- o diff foi revisto;
- `docs/STATE.md` e `docs/DECISIONS.md` estão atualizados quando aplicável.

## Correções recorrentes

D-150: acelerar pelo caminho crítico e por custo medido. Reutilizar artefatos íntegros; não repetir ASR, síntese, decode, render ou regressão integral sem entrada/código relevante alterado ou prova anterior insuficiente identificada. Otimização exige equivalência de resultado e benchmark real, sem reduzir gates. Agrupar mudanças compatíveis antes de uma manutenção; diagnóstico concluído só reabre por nova evidência concreta. Prioridade corrente: próximo vídeo integralmente aprovado, não expansão de estilos ou arquitetura paralela.

D-151: a escolha LONG/SHORT/HYBRID exige coortes comparáveis por canal/formato/idade, origem e validade temporal obrigatórias, métricas privadas honestamente indisponíveis e capacidade elegível para cada rota. A coleta atual classifica formatos, mas o seletor diário LONG-only e o snapshot congelado de02/09 não comprovam escolha entre formatos ou pesquisa contínua. Corrigir por versão sem reabrir o protocolo ativo nem ampliar o FormatPack LIMITED. Priorizar tempo até entrega e avaliação real; modelo/esforço máximo não substituem integração ou evidência.

Replay histórico de uma decisão de formato não autoriza seu uso corrente: admissão exige relógio UTC explícito, TTL e origem revalidados. Inspector sem scheduler não é mercado contínuo; comparação pareada não prova comparação entre canais exclusivamente Shorts e exclusivamente longos.

Antes de alterar in-place código/schema/teste já congelado, arquivar seus bytes exatos com escrita exclusiva e conferir o SHA anterior. Hash anotado, reconstrução em memória ou teste histórico não substituem a cópia. Lacuna anterior deve permanecer explícita. Correção localizada de observabilidade não substitui automaticamente o instrumento geral: regressões nos demais casos preservam a versão anterior, sem escolher retrospectivamente o menor residual.

D-149: calibração temporal usa policy externa pré-registrada e pinada; estimativa prende policy ID/hash e instante, com policy <= estimativa <= avaliação em UTC. Referência histórica preserva seu instante próprio. Holdout/PCM/modelo/observação devem ser reabertos; FIXTURE nunca se torna evidência LIVE nem autorização produtiva.

A voz/idioma/modelo/velocidade da população holdout precisam de origem de síntese reconstituída, não apenas perfil autodeclarado. Holdout não pode reutilizar nenhum alvo da união de captions internas e eventos dependentes da fala. Biblioteca instalada, dicionário coberto ou timestamps estimados não constituem calibração nem capacidade produtiva validada.

D-147: dados opacos de inspeção devem ser compostos diretamente de JSON pinado, sem round-trip temporal no shell. Testar PS5 e o host PS7 efetivo; preservar literalmente state e queue-before/after e validar vínculos completos antes da regressão pesada. Instante equivalente não autoriza alterar a string de evidência; o verificador independente não é flexibilizado.

D-146: antes da regressão pesada, validar a projeção real da evidência no Windows PowerShell 5: JSON UTF-8 explícito, coleção singleton preservada, null verdadeiro e caminho de credencial presente/redigido. Executar funções reais em fixtures Unicode; asserções textuais e objetos montados por Python não substituem essa integração. Corrigir o produtor, nunca afrouxar o verificador ou expor/copiar o segredo.

D-145: interpretar logs de teste em todos os consumidores do mesmo contrato antes de repetir regressão pesada. Resumo de sucesso com skip documentado não é falha da suíte, mas skip nunca prova o comportamento específico. Exigir contagem, terminal único e outcomes coerentes; preservar tentativas FAIL e exigir nova prova viva de manutenção.

D-144: hardening de persistência deve distinguir views mutáveis de receipts/avaliações imutáveis antes de alterar writers. Views usam temporário exclusivo, bytes completos e retry limitado para lock transitório; erro persistente permanece explícito. Testar callsites reais, preservar hashes históricos e implantar pelo protocolo de manutenção. Corrigir a classe conhecida nos consumidores identificados, não esperar outro incidente igual.

Na seleção de fontes concretas, D-139 recompõe papel, identidade, caminho e hash contra blueprint e biblioteca; família genérica e frase de compatibilidade não são prova. A progressão TRT deve atingir TRUTH/RESPONSIBILITY/TODAY em ordem antes do fechamento. Contrato exato continua sendo condição necessária, nunca suficiente para aprovação visual. Provas isoladas de composição (D-140) não ampliam FormatPack, direitos, fila, produção ou publicação.

D-141: corte visual não deve impor reinício de prosódia no meio de uma frase. O plano de unidades contínuas preserva fragmentos, voz e limites, mas não prova duração ou qualidade sonora antes de nova síntese e alinhamento observados. Padding calculado não é silêncio acústico medido; duração de WAVs antigos somada não prova o encaixe de uma fala nova. Mudança de unidade de voz exige remediação explicitamente compatível, sem ampliar a classe somente visual ou reabrir o job SUCCEEDED.

D-142: a cadeia histórica terminal e rejeitada só pode ser representada como espera de remediação mediante prova imutável e migração parada COMMITTED, preservando fila/receipts/artefatos. WAITING não autoriza novo job nem release, e divergência do tail/lease/checkpoint/inputs bloqueia. O painel distingue produção bloqueada de falha de execução sem ocultar o motivo nem dispensar os gates. O preview read-only precisa ser reexecutado após a última mudança antes da manutenção; preview anterior e testes focais não provam deployment. Captions, narração contínua e eventos visuais devem compartilhar mapa temporal verificado, sem tomar timestamps estimados de ASR por verdade acústica ou aprovação perceptual.

D-143: prioridade executiva não pode recomendar render quando a fonte de mídia contém bloqueio ou erro. Espera pós-efeito exige reabertura da prova integral; evidência inválida bloqueia trajetória/painel/ciclo e não pode ser ocultada por um `latest` anteriormente válido. Heartbeat isolado não cria decisão material. Resolver o bloqueio é prioridade, nunca autorização de fila, produção, publicação ou gasto.

Mudança de representação de estágio exige versão explícita e testes de produtor, preview e verificador independente, além de transição/receipts. GOAL_TRAJECTORY1.3 usa ação escalar ou BLOCKED para evidência inválida; fontes legadas preservam representação histórica. Não aceitar ambas as representações na versão atual para fazer um teste passar.

O preview da manutenção deve executar os mesmos guards de correlação de erros que o commit, sem efetuar suas escritas. Um erro histórico só pode ser arquivado por prova estreita e preservação transacional dos bytes; erros futuros ou divergentes continuam bloqueantes. Escritas de derivados usam temporários exclusivos, substituição atômica por arquivo e retry limitado, sem apagar temporário alheio. Atomicidade por arquivo não prova atomicidade do par JSON/Markdown: a reconciliação do par permanece obrigatória.

Antes de trabalho pesado, previna retrabalho evitável: D-136 cruza TakePlan, tratamento, Bible e a receita real de texto antes da capacidade, fila, síntese e render, depois da validação da autoridade dos inputs. Divergências exigem evidência por take e bloqueio; o compiler falha antes de sobrescrever produção. Preflight não substitui OCR/pixels/movimento/áudio/Quality; amostras críticas reais continuam necessárias. Nunca afirme acerto de primeira, economia ou taxa de retrabalho sem medição; não relaxe o contrato para evitar uma correção necessária.

Se o usuário corrigir o mesmo comportamento pela segunda vez, registre a regra de forma curta neste arquivo ou na especificação mais próxima. Não aumente este arquivo com detalhes que pertencem aos documentos técnicos.

## Comunicação

- D-148: critérios de aceite que consomem testes usam identidade inequívoca; nome curto ambíguo nunca é prova. GC-21 exige os dois contratos qualificados de protocolo/autostart e runtime vivo. Conferir os seletores no inventário antes de repetir regressão pesada; não renomear evidência histórica nem relaxar D-116 para passar.

- D-132: Modelagem Youtube e QR Dolar têm igual importância e compartilham uma única reserva Codex; nunca atribua o saldo inteiro a cada projeto nem invente consumo individual. Use `config/codex-usage-policy.json` e `docs/CODEX_SHARED_CAPACITY_POLICY.md`. Abaixo da reserva, conclua checkpoints seguros/testes em curso e adie expansão discricionária, sem downgrade, compra, reset automático, interrupção de processos locais ou monitores duplicados. É coordenação cooperativa, não hard cap do host, sem transferência de estratégia, dados ou permissões.

- Responda em português do Brasil.
- Seja direto, mas mostre evidência técnica suficiente.
- Informe imediatamente quando algo não puder ser verificado.
- Nunca trate promessa de monetização ou lucro como garantia.
- Uma contagem observada antes da publicação é referência histórica, nunca baseline temporal da corrida. O ritmo da meta só pode ser calculado após duas observações oficiais, distintas e comparáveis dentro da janela; wrappers que reutilizam o mesmo checkpoint devem ser deduplicados. Antes disso, mostre o gap atual quando disponível e mantenha razão de ritmo, delta e velocidade como indisponíveis.

## Regra permanente — atraso de dados e encerramento temporal

- Um checkpoint formal com `PARTIAL_DATA_LAG` não pode saltar silenciosamente para a janela seguinte. A política versionada faz recolha a cada 120 minutos somente nas 12 horas posteriores à janela, registra janela ativa, tentativa, teto e deadline, e depois retorna ao calendário formal.
- Após a tolerância final de D30, `next_observation_at=null` e `terminal=true`. Timestamp vencido ou loop infinito de coleta é falha crítica.
- Falha da fonte oficial não é `PARTIAL_DATA_LAG`: recebe retry a cada 30 minutos por no máximo 6 horas/12 slots. Durante retry ativo, evite alarme repetitivo; depois do teto, exponha `OWNED_METRICS_FAILED_RETRY_EXHAUSTED` e permaneça fail-closed.
- Cada checkpoint próprio devido deve criar o preflight de custo/cota no instante da chamada: reservar 2 unidades gerais e preservar piso preventivo de 12. Consumo desconhecido ou margem abaixo do piso bloqueia antes de Reporting/Data/Analytics; vidIQ não é dependência desse fluxo.
- O uso do Codex segue `config/codex-usage-policy.json`: selecionar o melhor modelo Codex suportado e esforço `ultra`, sem reduzir qualidade para economizar. Economize por preflight, batching, deduplicação, evidência imutável, testes dirigidos antes da regressão e continuidade local. Com menos de 25% restantes, restrinja o Codex ao caminho crítico; abaixo de 10%, preserve a reserva e aguarde renovação, mantendo o Gestor residente ativo. Nunca compre créditos, ative recarga automática ou alegue que um limite compartilhado não pode se esgotar.
