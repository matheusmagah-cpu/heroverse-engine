# PhaseTask — Fase 4

## Controle

- `phase_id`: `4`
- `task_id`: `phase-4-modeler-v1`
- `status`: `AWAITING_REVIEW`
- `authorized_by`: D-027/D-030
- `authorized_at`: `2026-09-02`

## Objetivo único

Gerar um modelo explicável e executável do canal/formato usando apenas evidência aprovada, sem produzir vídeo.

## Gate

- [x] schema reforçado;
- [x] ChannelDNA com identidade própria;
- [x] arquétipo long-form evidenciado;
- [x] invariantes, variáveis e proibições;
- [x] GenerationSpec executável;
- [x] vencedores/mediano/fraco explicados;
- [x] exemplos e contraexemplos;
- [x] hipóteses falsificáveis em `CANDIDATE`;
- [x] RPM e métricas privadas não imputados;
- [x] replay, refs, testes e integridade;
- [x] nenhum vídeo/Ads/gasto.

## Gate humano restante

- [ ] proprietário aprova `A-LONG-DIRECT-SPIRITUAL-STAKES-V1` para piloto.

Enquanto esse item permanecer aberto, a Fase 5 não inicia.
