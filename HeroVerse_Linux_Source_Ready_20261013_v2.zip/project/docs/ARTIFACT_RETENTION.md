# Retenção de artefatos — incremento T25, 10/09/2026

## Atualização T26 — 11/09/2026

A incompatibilidade de evolução de fonte foi corrigida por sucessor explícito, sem modificar o coletor ou recibos históricos. Nova candidata `58071f2c9afc431ee6b4430e437fb6252f697ef2600d3746a9969d25f152d14d`: integral única aprovada com 2.199 PASS/um skip permitido, prova de 12 arquivos aceita pelo leitor real. **Retenção ainda NÃO ADOTADA; escopo continua limitado a caches de compilação.** Nenhum descarte geral de mídia ou aplicação foi realizado. O registro T25 abaixo documenta a falha anterior, preservada.

Estado: IMPLEMENTADO/TESTADO EM FOCAIS; NÃO ADOTADO. A regressão integral da candidata `dec89b88fb948e7e2ae396a80f25d9539ec7f9cd1d456b770146ccd0afd60e58` terminou com um FAIL de vínculo histórico de fonte. Não há autorização de aplicação ou retomada.

## Capacidade efetiva

`hero_engine/compile_cache_retention.py` registra caches de compilação concluída e recolhe somente bytecode explicitamente excluído das provas, inventariado e selado. Entradas: preparo ativo de recursos insuficientes, replay/mineração concluídos e controlador de publicação após `COMPLETE_PUBLIC`. PAUSE impede a coleta. Não há rotina ou daemon novo.

Exige arquivos próprios, identidades/hashes/tamanhos exatos, processos de compilação e regressão comprovadamente ausentes, regressão selada com exit zero, inexistência de vínculos probatórios com os binários e handles exclusivos. Plano precede efeitos; registro de ausência intencional sucede efeitos. Falha parcial bloqueia repetição cega. No máximo dois caches elegíveis por passagem; sondas desconhecidas, uso concorrente ou substituição bloqueiam.

Não remove mídia, fontes, modelos, bancos, WAL/SHM, locks, credenciais, backups, receipts ou caches válidos. O cache da integral T25 reprovada NÃO é elegível pelo novo coletor. Bytes ainda exigidos por consumidores legítimos permanecem presentes. A retenção automática geral de mídia NÃO foi implementada por este incremento.

## Provas e limites

57 execuções focais, 48 métodos distintos com último PASS; testes nativos em temporários próprios e integrações reais com fronteiras externas simuladas. A integral única executou 2.190 casos (2.183 métodos + sete aliases), com um FAIL e um skip. Fonte de mineração evoluiu, mas o recibo D-170 ainda autentica a versão anterior. Nenhum recibo histórico foi regravado para aprovar a nova fonte.

Evidências: `output/runtime/gestor-central/maintenance-runs/task25-integral-validation-20260910/`, incluindo `INCREMENTO_E_LIMITES.md`, logs integrais e fechamento. A limpeza manual anterior de pip/npm/instaladores é histórica e não foi repetida. Custo técnico adicional autorizado: R$ 0,00.

## D-197 — mídia sob demanda, sem biblioteca local de mineração — 21/09/2026

Mineração, modelagem e seleção semântica passam a trabalhar com catálogo
remoto, metadados de fonte, direitos, hashes publicados quando disponíveis e
decisões versionadas. Elas **não** podem baixar uma biblioteca de vídeos “para
depois”. O `build_asset_catalog()` grava somente candidatos remotos e seus
snapshots de direitos; esses candidatos não são ativos de produção nem possuem
URI local, hash de conteúdo local ou autoridade de render.

Uma aquisição local futura deverá estar vinculada a um take já aprovado, à
revalidação dos direitos e a um recibo de produção. Ela poderá baixar somente o
ativo exato necessário. Depois de publicação confirmada, a mídia local só
poderá ser liberada por política própria que prove ausência de lease, fila,
render, vínculo probatório ou obrigação de retenção. Até essa política estar
integrada e testada, nenhum vídeo existente será apagado automaticamente.
Recibos, metadados, hashes, direitos e atribuição permanecem retidos.

### Implementação do ciclo completo

`hero_engine/media_lifecycle.py` passou a fornecer duas transações pequenas e
fail-closed: `acquire_catalog_candidate()` aceita exatamente um candidato
remoto para takes aprovados e grava recibo imutável; `release_published_media()`
remove somente esse arquivo depois de `COMPLETE_PUBLIC` e de um clearance
vinculado ao hash do recibo, com `queue_open`, `lease_open`, `render_open`,
`evidence_dependency` e `retention_required` todos falsos. O coletor é chamado
pelo controlador de publicação, mas uma ausência ou falha de clearance é no-op
registrável, nunca exclusão. A mídia, receipt e evidência atuais não foram
alterados nesta adoção.
