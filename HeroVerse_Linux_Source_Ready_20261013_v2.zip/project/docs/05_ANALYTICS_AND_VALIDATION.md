# 05 — Analytics, piloto e validação comercial

## 1. Princípio

Dados públicos ajudam a selecionar hipóteses. Dados privados do canal próprio demonstram se embalagem, hook, narrativa e produção funcionam para aquela audiência. A previsibilidade real nasce da combinação dos dois.

## 2. Separação obrigatória

### Concorrentes e referências

Podem fornecer:

- metadados públicos;
- snapshots de views, likes e comentários;
- estrutura de conteúdo;
- padrões editoriais;
- proxies e inferências.

Não fornecem como fatos:

- impressões;
- CTR;
- retenção;
- origem de tráfego;
- RPM;
- receita;
- lucro.

### Canais próprios autenticados

Quando disponíveis, captar:

- impressões;
- CTR;
- views e watch time;
- duração média e percentual médio assistido;
- curva de retenção disponível;
- inscritos ganhos;
- fontes de tráfego;
- audiência recorrente quando disponível;
- receita e RPM quando monetizado;
- custos internos.

Registre disponibilidade e fonte de cada métrica. Não simule uma métrica ausente.

## 3. Unidade experimental

Cada publicação deve estar vinculada a:

- canal e hipótese;
- arquétipo;
- tema e ângulo;
- versão de título e thumbnail;
- versão de blueprint e roteiro;
- fontes dos recortes;
- parâmetros de produção;
- custo e tempo;
- data/hora;
- versão do pipeline;
- decisões humanas.

Sem essa ligação, o sistema não consegue aprender o que causou a mudança.

## 4. Piloto

Comece com:

- um canal;
- um nicho;
- um arquétipo principal;
- uma identidade;
- publicação controlada;
- aprovação humana;
- quantidade e período definidos no plano após avaliar cadência e formato.

Não abra vários canais para compensar um pipeline ainda não validado.

## 5. Diagnóstico por combinação de sinais

Use regras configuráveis, nunca universais:

- baixa resposta à embalagem + boa entrega: revisar título/thumbnail;
- boa resposta à embalagem + baixa retenção: revisar promessa, hook e roteiro;
- boa abertura + queda em ponto específico: revisar o bloco e seus takes;
- boa retenção + pouca distribuição: avaliar tema, audiência, histórico e amostra;
- bom vídeo isolado sem repetição: ainda não há formato comprovado;
- desempenho fraco com amostra pequena: manter como inconclusivo.

Os nomes exatos das métricas e thresholds devem ser definidos conforme dados disponíveis. Não crie números “de mercado” sem fonte.

## 6. Janela e amostra

Toda decisão deve registrar:

- idade do vídeo;
- quantidade de impressões/views;
- janela analisada;
- baseline usado;
- incerteza;
- fatores externos conhecidos.

Não compare vídeos com idades muito diferentes sem normalização. Não encerre hipótese apenas por um vídeo.

## 7. Decisões possíveis

- `CONTINUE`: continuar coleta sem alterar.
- `ITERATE_PACKAGE`: alterar embalagem.
- `ITERATE_HOOK`: alterar primeiros segundos.
- `ITERATE_NARRATIVE`: alterar estrutura.
- `ITERATE_PRODUCTION`: alterar ritmo, áudio ou visuais.
- `EXPAND_SAMPLE`: produzir mais evidência.
- `SCALE_FORMAT`: aumentar produção do arquétipo.
- `PAUSE`: suspender temporariamente.
- `KILL_HYPOTHESIS`: encerrar com justificativa.

Toda recomendação deve conter evidências, confiança e próxima medição.

## 8. Critérios antes de um segundo canal

- minerador aprovado no padrão-ouro;
- modelo explica vencedores, medianos e fracos;
- produção passa em todos os gates;
- custos e tempos conhecidos;
- erros operacionais controlados;
- canal-piloto gerou dados suficientes para decisão;
- pelo menos um arquétipo demonstrou repetibilidade ou foi rejeitado de forma conclusiva.

## 9. Critérios antes de transformar em produto

- uso interno real documentado;
- operação repetida sem depender de correção manual constante;
- onboarding reproduzível;
- separação multicanal testada;
- permissões e licenças do stack revisadas;
- custos por usuário/canal conhecidos;
- métricas e relatórios explicáveis;
- limites e riscos transparentes;
- suporte e recuperação definidos;
- nenhuma promessa de renda ou monetização garantida.

## 10. Previsões pré-registradas

Toda previsão deve ser registrada antes do resultado e permanecer imutável. Inclui alvo, horizonte, cutoff, canal/coorte, baseline, intervalo ou distribuição, probabilidades, features disponíveis, versão, suposições e limitações. Resultado posterior é outra entidade vinculada.

A avaliação mede MAE e MAPE/sMAPE quando aplicável, cobertura/largura de intervalo, Brier score/log loss para probabilidades, calibração por faixa e uplift contra baseline simples fora da amostra. Previsibilidade só pode ser afirmada para alvo/escopo que cumpra thresholds e amostra mínima aprovados.

## 11. Scorecard e champion/challenger

O Gestor mantém scorecard de qualidade do sistema, qualidade do conteúdo e resultado operacional/comercial. Cada métrica registra baseline, atual, delta, direção, amostra, janela, incerteza, custo, versão e trade-offs. Challenger só substitui champion se provar ganho sem regressão crítica.

## 12. Ciclo completo

Aprendizado comprovado exige observação, baseline, hipótese, previsão prévia, experimento, resultado, avaliação, atualização versionada, aplicação futura e nova medição. Rodada sem novos dados produz `NO_NEW_EVIDENCE` e não altera regra.
