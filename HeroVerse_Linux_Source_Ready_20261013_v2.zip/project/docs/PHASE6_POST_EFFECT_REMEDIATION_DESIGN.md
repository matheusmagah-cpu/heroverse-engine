# Remediação pós-efeito de render — auditoria preservada

Atualização D-135/D-136: o resolver read-only de autoridade COMMITTED foi implementado e testado, separado da reconciliação mutável. O job c516 terminou SUCCEEDED em `2026-09-06T02:35:55Z`, sem lease, com render histórico preservado. O preflight visual novo bloqueia os contratos contraditórios antes do próximo processamento pesado. **O mecanismo completo de sucessor/namespaces/deployment ainda não existe.** D-133 recompôs capacidade; a restrição CRITICAL anterior abaixo é histórica, não a condição corrente.

Estado: **DESIGN_NOT_IMPLEMENTED**. Auditoria read-only já concluída, preservada neste checkpoint para evitar repetir a investigação. Não é autorização de publicação, nova capacidade produtiva ou receipt de remediação. Implementação discricionária adiada pela reserva D-132; nenhum job foi criado ou reaberto.

Atualização D-134 após a recomposição D-133: somente a barreira de claim PREPARED foi implementada em disco e revisada. Claim genérico/exato e contagem executável agora excluem também a autoridade PREPARED; COMMITTED preserva a retomada da autoridade e o bloqueio do predecessor. `tests.test_phase6_queue`: 28/28 PASS; `tests.test_phase6_media_authority`: 5/5 PASS; py_compile e concorrência entre duas conexões SQLite temporárias PASS. Nenhum banco operacional/lease/runtime foi alterado. O restante do sucessor pós-efeito continua não implementado, e o deployment desta barreira ainda depende da janela segura.

## Problema verificado

O renderer corrente em disco usa receita v2 e recusa cache v1; o processo residente ainda produz v1. Se esse job terminar SUCCEEDED, ele não poderá ser reaberto nem ter seu checkpoint sobrescrito. O renderer atual escreve em caminhos fixos; executá-lo diretamente de novo destruiria evidência da geração anterior. Além disso, v2 corrige o texto None, mas não resolve a divergência do take-003 entre TakePlan e Style Bible. Ambas as falhas precisam de tratamento próprio, não de bypass do QA.

## Contrato proposto

- Classe separada `POST_EFFECT_LOCAL_RENDER_RECIPE_REMEDIATION`; não relaxar os contratos existentes IDENTITY_ONLY e PRE_EFFECT.
- Predecessor exato SUCCEEDED, sem lease; checkpoint/schema/hash íntegros. Reabrir e prender canal, protocolo, experimento, variável, candidato, FormatPack, pipeline, inputs, TakePlan, Bible, allocation, biblioteca, direitos, voz e custo zero. Nenhuma mudança editorial implícita.
- Verificador histórico dedicado recompõe receita v1, segmentos/receipts/cache/fontes/bytes e streams FFprobe. O verificador corrente continua recusando v1 para produção.
- Sob o mesmo PublicationLock, exigir ausência de receipt, journal BEFORE/AFTER, remote ID, reserva de quota ou início de upload ligado à geração. Efeito externo iniciado bloqueia essa classe. Não tratar ausência de um único arquivo como prova suficiente.
- Capacidade atual PASS para o plano exato antes de criar o sucessor, incluindo disco ocupado pela geração anterior e reserva pós-render de 5 GiB.
- Nova chave determinística prende input, predecessor e versões de receita. Sucessor nasce PENDING, tentativa zero e checkpoint vazio, sem modificar row/bytes/checkpoint do predecessor.
- Inserir sucessor e supersessão PREPARED na mesma transação SQLite BEGIN IMMEDIATE; materializar receipt imutável e então COMMITTED. Replay exato conclui uma preparação interrompida, sem duplicar efeito.
- Race encontrado: claims hoje excluem superseded_job_id em PREPARED, mas não authoritative_job_id. Claims genérico/exato e contadores precisam bloquear ambos até COMMITTED. Não criar sucessor sem corrigir/testar essa barreira.
- Resolver autoridade pela cadeia COMMITTED até o tail, recusando ciclos, forks, divergência de unidade e adulteração. PREPARED bloqueia; predecessor nunca vira fallback executável. Um tail ativo é a única autoridade executável.
- Nova geração escreve integralmente em namespace `render-generations/<job_id>/`, incluindo render-work, captions, áudio derivado, thumbnail, atribuição, MP4, manifests e receipts. Preservar v1; aliases mutáveis só são views derivadas, nunca autoridade.
- Reusar voz 90/90 somente depois de verificação integral do manifesto/WAV/modelo/voz/velocidade/slots/hash. Distinguir capacidade histórica da voz da capacidade atual de render; não ressintetizar silenciosamente para mascarar divergência.
- Quality, package e publication consomem exclusivamente o manifest/checkpoint do tail. Publisher recompõe essa autoridade sob PublicationLock antes de quota/API. Pacotes/release anteriores ficam históricos e inelegíveis.

## Arquivos previstos, ainda não implementados

`queue_phase6.py`, `phase6_media_authority.py`, `phase6_media.py`, integração de consumo no `phase6_quality.py`, guard do `phase6_publication.py`, schema dedicado de receipt pós-efeito e eventual versão do render manifest com job/generation/recipe/remediation binding. Não ampliar silenciosamente schemas históricos.

## Testes de aceite exigidos

Preservação byte a byte de predecessor/inputs; replay idempotente; falha de storage PREPARED sem claim; concorrência no claim; lease/estado não terminal/tamper rejeitados; drift de candidato/experimento/direitos/custo/codec rejeitado; efeito externo bloqueia com zero chamadas; integridade histórica v1 passa mas qualidade corrente v1 falha; namespace sem sobreposição; voz reutilizada sem síntese e tamper bloqueado; package antigo rejeitado; tail v2 consumido; ciclo/fork recusado; capacidade insuficiente cria zero job; regressão e prova viva após deployment seguro.

A contradição NAME/TEST/CHOOSE versus TRUTH/RESPONSIBILITY/TODAY continua independente. Não mudar Bible, candidato ou experimento sem decisão versionada. Se a correção alterar uma receita v2 já identificada, criar versão nova. Reconstrução tecnicamente correta não prova qualidade editorial, retenção ou viralidade.
