# Prompt mestre complementar — Inteligência Contínua Viva

## Natureza deste comando

Este comando **complementa** todo o contrato já existente no projeto. Ele não substitui, invalida, resume ou enfraquece `AGENTS.md`, `PLANS.md`, os documentos de `docs/`, os schemas, os gates de direitos, as fases já aprovadas nem as decisões registradas.

Em caso de dúvida ou conflito:

1. preserve o trabalho existente;
2. respeite a fase atualmente autorizada em `docs/STATE.md`;
3. registre o possível conflito em `docs/DECISIONS.md`;
4. apresente uma proposta de conciliação;
5. pare em `AWAITING_REVIEW` antes de qualquer mudança irreversível ou ampliação de escopo.

## Objetivo obrigatório

Projetar e, quando a fase correspondente estiver autorizada, implementar uma **Inteligência Contínua Viva** que coordene o sistema de canais, aprenda com o mercado e com a operação real, preserve memória entre execuções e converta evidência em melhorias mensuráveis.

Não trate “inteligência viva” como uma personalidade, um chat que apenas dá sugestões, uma memória textual solta ou uma chamada isolada a um modelo de IA. Ela deve existir como um sistema técnico persistente, observável, versionado, testável e reversível.

A inteligência deverá aprender continuamente com três fontes separadas:

1. **Mercado:** canais, vídeos, formatos, temas, embalagens, movimentos, padrões e mudanças observáveis em fontes públicas e permitidas.
2. **Acervo histórico:** vídeos já minerados, modelos, hipóteses, decisões, erros, experimentos, versões de pipeline e resultados anteriores.
3. **Operação própria:** vídeos planejados, produzidos e publicados, métricas privadas autorizadas, retenção, embalagem, audiência, receita quando disponível, custos, incidentes e decisões humanas.

Ela deverá reunir essas fontes sem misturá-las indevidamente, identificar padrões, formular hipóteses, recomendar ou executar somente ações autorizadas, medir o efeito e incorporar o resultado ao conhecimento futuro.

## Resultado final esperado

Construir uma camada coordenadora capaz de:

- saber o que foi observado, inferido, testado, aprovado, rejeitado e ainda é desconhecido;
- manter memória persistente após reinício, atualização ou troca de sessão;
- acompanhar mercado e canais próprios em rotinas configuráveis;
- detectar mudança de padrão, saturação, deterioração, oportunidade e anomalia;
- relacionar desempenho com canal, vídeo, versão, embalagem, hook, take, narrativa, ativos, horário, custo e versão do pipeline;
- comparar resultados com baselines compatíveis e janelas equivalentes;
- gerar hipóteses explícitas, falsificáveis e priorizadas;
- desenhar experimentos pequenos e controlados;
- aprender tanto com acertos quanto com falhas e resultados inconclusivos;
- atualizar regras aprendidas somente com evidência suficiente;
- aplicar o conhecimento no próximo ciclo de mineração, modelagem e produção;
- manter isolamento completo entre canais, nichos, identidades e ativos;
- explicar cada decisão e permitir rollback;
- coordenar o sistema sem ultrapassar aprovações humanas, direitos ou políticas.

## Princípios que não podem ser removidos

### 1. Aprendizado comprovável

Só existe aprendizado real quando todo o ciclo pode ser demonstrado:

`observação -> hipótese -> decisão -> experimento -> resultado -> avaliação -> atualização -> aplicação futura`

Uma recomendação gerada por IA, sem teste e sem efeito medido, é apenas uma hipótese. Não a registre como conhecimento comprovado.

### 2. Evidência antes de conclusão

Toda informação deve manter uma das classificações já definidas no projeto:

- `OBSERVED`;
- `CALCULATED`;
- `INFERRED`;
- `PRIVATE`;
- `UNKNOWN`.

Além da classe, registre fonte, timestamp, escopo, janela, tamanho da amostra, versão do coletor, confiança e limitações. Nunca converta dado ausente em fato.

### 3. Memória persistente e estruturada

Não dependa da memória da conversa, do contexto do modelo ou de um único arquivo Markdown. Implemente armazenamento persistente com contratos de dados e migrações.

No piloto, prefira SQLite quando suficiente. Prepare abstração para PostgreSQL apenas quando escala e concorrência justificarem. Documentos Markdown podem servir como visão humana, nunca como única fonte operacional.

### 4. Separação entre tipos de memória

Implemente, no mínimo:

- **memória factual:** eventos, métricas e observações imutáveis;
- **memória episódica:** o que aconteceu em cada execução, publicação e experimento;
- **memória semântica:** padrões consolidados e relações aprendidas;
- **memória de decisão:** hipótese, evidência, aprovação, responsável e resultado;
- **memória operacional:** filas, estados, falhas, tentativas e checkpoints;
- **memória de canal:** conhecimento isolado por canal e nicho;
- **memória global:** somente aprendizados generalizáveis que passaram por teste de transferência.

Nunca copie automaticamente uma regra de um canal para outro. Primeiro trate como hipótese de transferência.

### 5. Aprendizado versionado, não reescrita silenciosa

Regras aprendidas devem ser overlays versionados sobre os contratos permanentes. A inteligência não pode modificar silenciosamente:

- objetivos fundamentais;
- gates de aprovação;
- regras de direitos e origem;
- segregação entre canais;
- limites de custo;
- permissões de publicação;
- schemas estáveis;
- critérios de segurança.

Toda mudança deve registrar versão anterior, nova versão, motivo, evidências, confiança, escopo, aprovador e mecanismo de rollback.

### 6. Causalidade com prudência

Não declare que uma alteração causou um resultado quando apenas ocorreu junto dele. Sempre que possível use teste controlado, comparação com baseline, coortes equivalentes, repetição e análise de fatores externos.

Resultados de um único vídeo não estabelecem regra universal. Amostra insuficiente deve produzir `INCONCLUSIVE`, nunca falsa certeza.

### 7. Coordenação com autoridade limitada

A inteligência pode observar, calcular, diagnosticar, priorizar e propor. Publicar, gastar, comprar serviço, alterar credencial, remover dados, mudar uma regra protegida ou escalar canais exige autorização correspondente.

## Arquitetura mínima obrigatória

Implemente componentes separados, com interfaces testáveis:

1. **Event Ledger:** registro append-only dos eventos e suas origens.
2. **Market Observer:** coleta permitida e periódica de sinais públicos, respeitando APIs, termos e limites.
3. **Own-Channel Observer:** ingestão autorizada de métricas privadas e dados operacionais.
4. **Normalizer:** padronização de datas, idades dos vídeos, métricas, unidades, fontes e janelas.
5. **Feature Builder:** ligação entre métricas e atributos minerados de embalagem, hook, takes, narrativa e produção.
6. **Knowledge Store:** memória factual, episódica, semântica, decisória e operacional.
7. **Hypothesis Engine:** geração de hipóteses com evidências favoráveis, contrárias, confiança e condições de refutação.
8. **Experiment Planner:** plano de teste, variável alterada, controle, amostra, duração, custo, risco e regra de parada.
9. **Decision Engine:** decisão configurável entre continuar, iterar, testar, escalar, pausar ou rejeitar.
10. **Policy Gate:** validação de autorização, direitos, custo, canal, escopo e fase.
11. **Learning Evaluator:** comparação antes/depois, incerteza, interferências e classificação do resultado.
12. **Rule Registry:** regras candidatas, aprovadas, rejeitadas, suspensas e substituídas, todas versionadas.
13. **Application Planner:** conversão do aprendizado aprovado em mudanças concretas nos próximos blueprints.
14. **Scheduler/Orchestrator:** rotinas idempotentes, filas, retries limitados, checkpoints e dead-letter queue.
15. **Audit and Explainability:** relatório que reconstrói por que cada decisão foi proposta ou aplicada.
16. **Monitoring:** saúde dos coletores, atraso dos dados, falhas, drift, custos e qualidade do próprio sistema.

A orquestração pode usar n8n ou MCP quando trouxer benefício real, mas regras de negócio, validação, memória e avaliação devem permanecer em código testável e independente do orquestrador.

## Contratos mínimos de dados

Crie schemas versionados para, no mínimo:

- `Event`;
- `MarketObservation`;
- `OwnVideoObservation`;
- `FeatureSnapshot`;
- `Baseline`;
- `Hypothesis`;
- `Experiment`;
- `Decision`;
- `LearningEvaluation`;
- `LearnedRule`;
- `RuleVersion`;
- `ApplicationPlan`;
- `Incident`;
- `ChannelMemoryScope`;
- `PipelineVersion`.

Cada entidade deve possuir identificador, timestamps, versão do schema, origem, canal/escopo, evidências relacionadas e trilha de auditoria. Use chaves idempotentes para impedir duplicação na reingestão.

## Ciclo contínuo obrigatório

Para cada rodada:

1. observar mercado e operação própria;
2. validar origem, integridade, atualidade e permissão;
3. normalizar por canal, formato, idade, janela e amostra;
4. ligar resultados às versões exatas dos elementos do vídeo;
5. comparar com baseline e coortes compatíveis;
6. identificar sinal, ruído, anomalia, saturação ou lacuna;
7. gerar hipótese falsificável;
8. procurar evidência favorável e contrária;
9. atribuir confiança calibrada e declarar incerteza;
10. propor experimento de menor risco e custo;
11. passar pelo gate humano quando exigido;
12. executar apenas a ação autorizada;
13. coletar resultado na janela definida;
14. classificar como `SUPPORTED`, `REJECTED`, `INCONCLUSIVE` ou `INVALID_EXPERIMENT`;
15. atualizar o Rule Registry sem apagar o histórico;
16. produzir plano de aplicação para o próximo conteúdo;
17. medir se a aplicação futura repetiu o efeito;
18. detectar regressão e fazer rollback quando necessário.

## Aplicação específica aos vídeos

O sistema deve conseguir relacionar aprendizado a:

- promessa do vídeo;
- título e thumbnail;
- hook em `0–1s`, `1–3s`, `3–8s` e `8–30s` quando aplicável;
- primeiro corte, primeiro texto, primeiro som e primeira mudança visual;
- duração e função de cada take;
- ritmo de corte;
- progressão narrativa;
- densidade de informação;
- provas, curiosidade, tensão e payoff;
- CTA;
- origem e função dos recortes;
- identidade do canal;
- tema, ângulo, arquétipo e estágio de audiência;
- tempo e custo de produção;
- versão de cada ferramenta e pipeline.

Quando uma métrica piorar, o diagnóstico deve separar, no mínimo: embalagem, promessa, hook, narrativa, produção, tema, distribuição, público, amostra, sazonalidade, falha de coleta ou interferência externa.

## Monitoramento do mercado

Crie rotinas configuráveis, nunca números rígidos inventados, para:

- atualizar o catálogo de referências;
- capturar snapshots públicos com timestamp;
- detectar novos formatos, temas e padrões de embalagem;
- acompanhar aceleração e desaceleração comparável;
- identificar repetição excessiva e possível saturação;
- separar tendência ampla de caso isolado;
- reprocessar amostras quando o minerador melhorar;
- expirar conclusões antigas quando o contexto mudar.

Não use scraping proibido, contas falsas, evasão de limite ou dados privados de terceiros. Quando uma fonte não estiver disponível legitimamente, marque a lacuna e continue com fontes permitidas.

## Hierarquia de conhecimento

Classifique cada regra em um nível:

1. `CANDIDATE`: padrão observado, ainda não testado.
2. `TESTING`: experimento autorizado em andamento.
3. `LOCAL_SUPPORTED`: evidência repetida em um canal/arquétipo.
4. `TRANSFER_CANDIDATE`: candidata a teste em outro contexto.
5. `GENERAL_SUPPORTED`: transferida e repetida em contextos aprovados.
6. `SUSPENDED`: perdeu validade ou apresentou regressão.
7. `REJECTED`: hipótese contrariada pela evidência.

Nunca promova uma regra de nível automaticamente sem cumprir critérios configurados e registrar evidência.

## Relatório obrigatório de cada ciclo

Entregue uma visão humana curta e uma saída estruturada contendo:

- o que mudou desde o último ciclo;
- qualidade e cobertura dos dados;
- sinais relevantes;
- hipóteses novas e antigas;
- evidências favoráveis e contrárias;
- aprendizado confirmado, rejeitado ou inconclusivo;
- regras promovidas, rebaixadas ou suspensas;
- recomendações por canal;
- ações bloqueadas e motivo;
- próximos experimentos;
- custo estimado;
- riscos;
- versão do conhecimento antes e depois;
- rollback disponível.

## Plano obrigatório de implementação

Não responda apenas com explicações. Antes de alterar o código:

1. leia integralmente as instruções do projeto;
2. confirme a raiz e a fase autorizada;
3. audite o que já existe de banco, analytics, filas, agendamentos, memória e IA;
4. apresente mapa de reaproveitamento e lacunas;
5. proponha arquitetura encaixada no stack real;
6. defina contratos, migrações, interfaces e testes;
7. divida a construção em subtarefas pequenas, cada uma com `Done when` verificável;
8. registre o plano em `PLANS.md` e as decisões em `docs/DECISIONS.md`;
9. implemente somente a etapa permitida pela fase atual;
10. execute testes e mostre evidência;
11. marque `AWAITING_REVIEW` e pare.

Se este prompt for enviado durante a Fase 0, incorpore a Inteligência Contínua à auditoria e ao plano, mas não construa componentes de domínio antes da autorização da fase correspondente.

## Testes de aceitação indispensáveis

A Inteligência Contínua só poderá ser considerada real quando demonstrar, em ambiente de teste e depois no piloto autorizado:

1. **Persistência:** reiniciar o sistema não apaga memória, estado ou versões.
2. **Idempotência:** reingerir o mesmo evento não duplica resultado.
3. **Rastreabilidade:** uma recomendação pode ser reconstruída até suas fontes.
4. **Dados ausentes:** o sistema recusa conclusão quando faltam evidências.
5. **Contradição:** evidência contrária reduz confiança ou suspende a regra.
6. **Canal isolado:** dados e identidade de um canal não vazam para outro.
7. **Aprendizado local:** um resultado atualiza somente o escopo permitido.
8. **Transferência controlada:** regra de outro canal entra apenas como hipótese.
9. **Gate humano:** ação protegida não é executada sem aprovação.
10. **Rollback:** uma atualização pode ser revertida sem apagar histórico.
11. **Replay:** eventos históricos reproduzem a mesma decisão para a mesma versão.
12. **Versionamento:** mudança de pipeline não contamina comparações silenciosamente.
13. **Drift:** mudança relevante de mercado ou desempenho gera alerta e reavaliação.
14. **Resultado inconclusivo:** amostra pequena não vira regra.
15. **Ciclo completo:** uma hipótese autorizada percorre teste, avaliação, atualização e aplicação futura.
16. **Impacto:** o relatório compara baseline, resultado e incerteza; não usa apenas opinião da IA.

## Demonstração final obrigatória

Apresente uma demonstração reproduzível com dados de fixture antes de usar publicação real:

- ingestão de observações de mercado e de canal próprio;
- criação de baseline;
- geração de uma hipótese;
- bloqueio de ação sem aprovação;
- aprovação simulada;
- execução de experimento simulado;
- entrada de resultado favorável, contrário e inconclusivo em testes separados;
- atualização versionada da regra;
- plano de aplicação no próximo blueprint;
- reinício do sistema preservando tudo;
- rollback;
- relatório de auditoria completo.

Depois, no piloto autorizado, repita o ciclo com dados reais e compare a previsão com o resultado observado.

## Critério final de conclusão

Não declare esta inteligência “pronta”, “viva” ou “aprendendo” apenas porque criou banco, agentes, automações ou relatórios.

Ela estará aprovada somente quando:

- o ciclo completo funcionar ponta a ponta;
- os testes indispensáveis passarem;
- a memória persistir;
- as decisões forem explicáveis;
- o conhecimento modificar de forma controlada uma produção futura;
- o efeito dessa aplicação for medido;
- erros e regressões puderem ser revertidos;
- os gates existentes continuarem intactos;
- o usuário revisar as evidências e aprovar expressamente.

Comece agora pela leitura completa do projeto, incorpore este requisito à fase atualmente autorizada, apresente o plano adaptado e pare no gate correto. Não pule diretamente para uma implementação genérica.

## Adendo operacional posterior — D-047 (2026-09-03)

Este adendo não apaga o contrato acima; altera o mecanismo administrativo de progressão a partir da Fase 5 por autorização posterior e expressa do proprietário:

- Fases 5–8 estão pré-autorizadas em sequência;
- `AWAITING_REVIEW` não interrompe a operação inteira e só identifica dependência humana/externa real;
- gates automáticos, evidência, direitos, padrão-ouro humano, orçamento, política e ações protegidas permanecem;
- quando um gate técnico falhar, a Inteligência diagnostica, corrige, reexecuta, registra e prossegue;
- upload/publicação sem gasto podem ocorrer apenas depois de todos os gates críticos e receipts; gasto/Ads continuam sem autorização;
- a aceitação final continua dependente de evidência real, mas não de pedidos administrativos entre fases.
