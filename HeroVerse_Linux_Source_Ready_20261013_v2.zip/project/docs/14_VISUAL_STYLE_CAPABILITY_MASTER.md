# 14 — Capacidade visual multiformato

## Regra permanente

O produto deve aceitar uma taxonomia ampla de estéticas e formatos, mas nunca declarar capacidade pronta sem executor, licença, fixture, render e quality gate. O registro de verdade é `config/visual_style_registry.json`; o contrato normativo novo é `docs/15_CREATIVE_DIRECTION_MASTER.md`.

Cada produção usa um `VisualStyleProfile` versionado. O Gestor escolhe uma direção coerente conforme nicho, audiência, mecanismo viral, função narrativa, direitos, custo, identidade e capacidade do pipeline. A existência de um estilo no vocabulário não autoriza misturá-lo no vídeo nem tratá-lo como implementado.

## Migração de estados

- `PLANNED` migra para `CATALOGED` quando há apenas identificação;
- `IN_VALIDATION` migra para `SPECIFIED` ou `PROTOTYPED` conforme a evidência real;
- `SUPPORTED_WITH_PROVIDER` não promove automaticamente: exige validação do adapter e pode virar `LIMITED`;
- `SUPPORTED_AND_TESTED` exige nova auditoria antes de `PRODUCTION_READY`;
- `BLOCKED` permanece `BLOCKED`.

Os estados oficiais agora são `CATALOGED`, `SPECIFIED`, `PROTOTYPED`, `VALIDATED`, `PRODUCTION_READY`, `LIMITED`, `BLOCKED` e `DEPRECATED`.

Compatibilidade com um canal é decisão separada: `COMPATIBLE`, `CONDITIONAL` ou `INCOMPATIBLE_WITH_CHANNEL`.

## Gate de perfil

Um perfil só avança quando contém:

1. estilos e funções narrativas;
2. exemplos próprios ou licenciados;
3. executor e versão;
4. resolução, frame rate, cor, tipografia, movimento e áudio;
5. regras de continuidade e proibições;
6. direitos de inputs e outputs;
7. custo externo e recursos locais;
8. fixture, render e inspeção visual;
9. riscos de pessoa, voz, marca, factualidade e disclosure;
10. status de capacidade que não excede a evidência.

## Perfil do piloto da Fase 5

`cinematic_documentary_nature_broll-v1` foi preservado como legado e migrado para `fp-broll-cinematic-narration@1.0.0`, em `SPECIFIED`. Não há render aprovado; portanto, não é capacidade de produção. Nenhum dos demais estilos é chamado de pronto nesta fase.

## Proteções especiais

- jornalístico, notícias, documental, true crime, histórico e científico exigem fonte factual e distinção entre reconstrução e registro;
- bodycam, segurança, webcam, UGC, retrato, lifestyle e pessoas reais exigem direitos, privacidade, publicidade e contexto;
- avatar, VTuber, talking head virtual, reconstituição, CGI e conteúdo sintético exigem disclosure quando aplicável e proíbem impersonação;
- câmera de segurança, bodycam, found footage e jornalístico não podem receber tratamento falso que os apresente como registro real;
- LEGO-like, marcas, personagens, franquias e identidades de artistas não autorizam imitação confundível;
- estilos de alto custo ou geração paga permanecem `PLANNED` ou `BLOCKED` no perfil zero-custo até existir executor local comprovado.
