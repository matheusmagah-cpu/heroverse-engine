# Plano incremental — Gestor Central Autônomo

## Regra de execução

Historicamente, este plano nasceu sem autorização de runtime. D-047 autorizou posteriormente as Fases 5–8 em sequência condicionada, substituiu a parada administrativa entre fases por gates automáticos e manteve todas as travas materiais. O estado atual é Fase 6 `IN_PROGRESS`; Fases 1–5 estão aprovadas. Os blocos abaixo preservam o mapa original, enquanto a evidência vigente é rastreada por `docs/STATE.md` e `output/operations/phase6/acceptance-report.json`.

## Fase 1 — padrão-ouro e medição humana

| Alteração prevista | Resultado | Done when |
|---|---|---|
| extensão ou sidecar aprovado de `video_mining` | Proveniência por campo, anotador, versão e janela | contrato aprovado sem quebrar o schema atual |
| `templates/GOLD_STANDARD_PROTOCOL.md` | Rubric e revisão das janelas/takes | amostra D-012 aprovada e exemplo real anotado |
| `data/gold_standard/...` | Quatro longos contrastivos, take a take | critérios da Fase 1 aprovados e evidências completas |

Fora de escopo: Gestor runtime, ledger, fila, scheduler, IA, publicação e Fase 2.

## Fase 2 — minerador como executor mensurável

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/contracts/analysis.py` | Contratos do artefato e proveniência | valida fixture e rejeita campo sem evidência |
| `hero_engine/mining/*` | Executor determinístico/idempotente | produz análise real por vídeo sem duplicação |
| `hero_engine/evaluation/gold_standard.py` | Métricas por campo e regressão | champion/challenger medidos contra Fase 1 |
| `tests/mining/*` | Idempotência, ausentes, versão, timestamps | testes correspondentes passam |

## Fase 3 — fundação da fonte única de verdade

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/migrations/*` | Migrações SQLite versionadas | banco vazio e legado migram reproduzivelmente |
| `hero_engine/ledger.py` | Event Ledger append-only | reingestão não duplica e replay preserva ordem |
| `hero_engine/state_store.py` | Estado global/por canal e memória tipada | reinício preserva estado e isolamento passa |
| `hero_engine/manager_state.py` | Projeções do Gestor | estado deriva do ledger com versão explícita |
| schemas de evento, observações, escopos e pipeline | Contratos aprovados | validação e compatibilidade documentadas |
| `tests/ledger/*` | Persistência, SSOT, idempotência, isolamento | GC-02, 04, 05, 11 e 15 passam no escopo |

## Fase 4 — hipóteses, coortes e regra candidata

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/hypotheses.py` | Hipótese falsificável com evidência pró/contra | caso real e contraditório auditáveis |
| `hero_engine/baselines.py` | Baseline por coorte/janela | amostra incompatível é recusada |
| `hero_engine/rules.py` | Estados sem promoção automática | amostra pequena retorna `INCONCLUSIVE` |
| schemas `Baseline`, `Hypothesis`, `RuleVersion` | Contratos aprovados | testes de transição passam |

## Fase 5 — Policy Gate e aplicação na produção

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/policy.py` | Fase + regras permanentes + envelope | a regra mais restritiva prevalece |
| `hero_engine/application.py` | Regra aprovada vira mudança explícita | blueprint aponta regra/evidência/versão |
| `hero_engine/executors/*` | Adaptadores dos módulos atuais | execução só ocorre por comando válido |
| `tests/policy/*` | Ações automáticas/protegidas/proibidas | GC-08, 09 e 10 passam |

## Fase 6 — Gestor ativo, fila, experimento e previsão

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/manager.py` | Loop central e rotina diária | um Gestor ativo coordena os executores |
| `hero_engine/commands.py` | Comando idempotente e trace completo | objetivo até receipt é reconstruível |
| `hero_engine/queue.py` | Claim/lease/retry/DLQ/checkpoint | recuperação não duplica efeito |
| `hero_engine/leadership.py` | Lock/lease de líder | segundo Gestor não comanda |
| `hero_engine/experiments.py` | Experimento e stopping rule | três outcomes de fixture avaliados |
| `hero_engine/predictions.py` | Forecast prévio imutável e calibração | métricas contra baseline reproduzíveis |
| `hero_engine/reporting.py` | Relatório executivo e alertas | proprietário vê postagens, resultados, custos e exceções |
| `tests/manager/*` | Concorrência, recovery, gate e prediction | GC-01, 03, 06, 07, 19 e 20 passam; receipt 6→7 é emitido somente após zero blockers |

## Fase 7 — aprendizagem contínua, transferência e scorecard

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| `hero_engine/learning.py` | Ciclo completo com nova medição | GC-14 passa com segunda medição |
| `hero_engine/rule_registry.py` | Promoção, suspensão e rollback | histórico preservado e replay idêntico |
| `hero_engine/drift.py` | Drift e validade temporal | mudança relevante suspende/reavalia |
| `hero_engine/scorecard.py` | Três níveis de melhoria | delta, incerteza, custo e trade-offs visíveis |
| `tests/learning/*` | Contradição, transferência, rollback, drift | GC-16, 17, 18, 21 e 22 passam |

## Fase 8 — endurecimento e produto

| Arquivo/componente previsto | Resultado | Done when |
|---|---|---|
| permissões, secrets e auditoria | Separação proprietário/operador/executor | matriz de permissão testada |
| observabilidade e SLOs | Saúde, atraso, custo e incidentes | alertas e runbooks comprovados |
| concorrência/multiusuário | Operação segura em escala | testes de carga justificam stack |
| adapters n8n/MCP/plugins, se úteis | Orquestração sem regra de domínio | remover adaptador não quebra núcleo |
| avaliação SQLite/PostgreSQL | Decisão baseada em evidência | migração somente se necessária e aprovada |

## Custos e dependências

- Python, SQLite, ffmpeg e ferramentas locais existentes são a primeira opção; custo externo permanece zero enquanto forem suficientes.
- APIs, banco gerenciado, storage, filas externas, modelos pagos, Ads e publicação real não entram sem aprovação.
- Dependência nova exige avaliação de licença, segurança, tamanho, manutenção e alternativa local.
- Credenciais permanecem em variáveis de ambiente/secret store, nunca no repositório.

## Riscos e mitigação

| Risco | Mitigação |
|---|---|
| Gestor virar chat sem estado | Ledger, contratos, reinício e replay |
| Duas fontes de verdade | Writes apenas pelo store/ledger central |
| Autonomia excessiva | Envelope, policy gate e aprovação externa |
| Regra causal falsa | Baseline, experimento, evidência contrária e inconclusivo |
| Previsão cosmética | Pré-registro imutável e baseline fora da amostra |
| Contaminação entre canais | Scope obrigatório e teste de isolamento |
| Regressão do minerador | Gold standard e champion/challenger por campo |
| Duplicidade externa | Idempotência, receipt e checkpoint |
| Arquitetura prematura | Somente capacidades exigidas pela fase |

## Próximo passo vigente

D-047 autorizou a fila contínua até a Fase 8, sempre condicionada ao gate verificável da fase anterior. A Fase 6 está `IN_PROGRESS`; o controlador `phase6_transition.py` aguarda GC-01, GC-11 e GC-19, recalcula a suficiência dos 22 checks e só então arquiva a aceitação exata e emite um receipt imutável para iniciar a Fase 7. GC-14 continua obrigatório na Fase 7, com aplicação futura e segunda medição, e não pode ser antecipado para fabricar o fechamento da Fase 6.
