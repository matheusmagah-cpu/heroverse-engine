# 07 — Fases, entregas e travas

## Regra geral

Desde D-047, as Fases 5–8 estão pré-autorizadas em sequência. Uma fase termina em `APPROVED` automaticamente somente quando todos os gates aplicáveis passarem com evidência; falha mantém `IN_PROGRESS`, exige correção/reteste e não libera a seguinte. `AWAITING_REVIEW` é reservado a dependência humana/externa real e não paralisa frentes independentes. As Fases 0–4 preservam seu histórico de aprovação.

## Fase 0 — Auditoria e incorporação do contrato

### Objetivo

Entender o projeto existente e incorporar este kit sem apagar trabalho válido.

### Entregas

- mapa do repositório;
- inventário de recursos existentes;
- lacunas;
- conflitos com estas especificações;
- stack e comandos reais;
- riscos;
- plano ajustado;
- atualização de `STATE.md` e `DECISIONS.md`.

### Gate

- nenhum código de domínio novo;
- nenhuma conclusão sem inspeção;
- todas as decisões existentes preservadas ou sinalizadas;
- usuário aprova o plano.

## Fase 1 — Padrão-ouro de mineração

### Objetivo

Definir manualmente o que é uma mineração correta.

### Entradas

- vídeos representativos;
- título e thumbnail;
- informações públicas;
- autorização/acesso legítimo ao arquivo para processamento;
- escolha do canal e formato.

### Entregas

- anotações completas;
- hooks por janela;
- takes revisados;
- transcrição e OCR;
- narrativa;
- JSON válido;
- relatório humano;
- fixtures congeladas.

### Gate

- revisão humana aprovada;
- evidências resolvíveis;
- schema validado;
- nenhuma lacuna disfarçada como inferência.

## Fase 2 — Minerador automático

### Objetivo

Implementar pipeline que reproduza o padrão-ouro.

### Entregas

- CLI/API interna;
- adapters locais;
- pipeline de mídia;
- validação de schema;
- testes unitários e integração;
- comparação automática com fixtures;
- relatório de divergências;
- medição de tempo e recursos.

### Gate

- execução reproduzível;
- divergências revisadas e aprovadas;
- nenhuma dependência paga obrigatória;
- falhas explícitas;
- idempotência comprovada.

## Fase 3 — Mineração em lote e observatório

### Objetivo

Processar o conjunto necessário para modelagem comparativa.

### Entregas

- catálogo de canais e vídeos;
- snapshots;
- coortes vencedor/mediano/fraco;
- minerações válidas;
- dashboard/relatório de cobertura;
- lista de erros e reprocessamentos.
- baseline de crescimento e sinais públicos/privados disponíveis necessários à futura válvula de aquisição, sem gasto.

### Gate

- cobertura suficiente para os formatos escolhidos;
- coortes justificadas;
- métricas normalizadas;
- nenhuma métrica privada inventada;
- qualidade amostral aprovada.

## Fase 4 — Modelador

### Objetivo

Gerar ChannelDNA, FormatArchetypes e GenerationSpecs.

### Entregas

- modelo de canal;
- arquétipos;
- invariantes, variáveis e proibições;
- matriz de evidências;
- exemplos e contraexemplos;
- previsões com confiança;
- testes retrospectivos possíveis;
- hipóteses de produção.
- hipóteses de valor/RPM claramente separadas entre observado, proxy e indisponível.

### Gate

- modelo explica diferenças observadas;
- nenhuma dependência de viral isolado;
- produção nova pode ser especificada sem copiar referência;
- usuário aprova um arquétipo para piloto.

## Fase 5 — Produtor clip-based

### Objetivo

Construir um vídeo completo a partir de blueprint e biblioteca permitida.

### Entregas

- catálogo de ativos;
- busca semântica com filtro de direitos;
- embalagem;
- narrativa e roteiro;
- timeline;
- montagem;
- render de revisão;
- manifesto de fontes;
- relatório de gates;
- custo e tempo.
- candidatos de criativo para aquisição futura, ainda sem campanha.
- Diretor Criativo subordinado, catálogo FormatPack, primeiro pack, Style Bible, TakePlan, perfil de produção e relatório completo de gates.

### Gate

- direitos aprovados;
- nova narrativa reconhecível;
- hook e payoff alinhados;
- fidelidade ao arquétipo;
- qualidade técnica;
- avaliação automática por release presa ao hash e separada do gerador; revisão humana por calibração, amostra e exceção conforme D-076.
- FormatPack usado em produção está `PRODUCTION_READY` ou `LIMITED` dentro das restrições; nenhum estado inferior é apresentado como capacidade.
- consistência visual/sonora e continuidade passam por verificação automática; padrão-ouro humano calibra e audita amostras/exceções, sem formulário obrigatório em cada publicação.

## Fase 6 — Canal-piloto

### Objetivo

Validar o método com audiência real.

### Entregas

- plano editorial delimitado;
- lote controlado;
- pacote de publicação;
- coleta de métricas próprias;
- incidentes e correções;
- relatório por vídeo;
- diagnóstico do arquétipo.
- piloto opcional da válvula de aquisição conforme `docs/12_ACQUISITION_ACCELERATOR_MASTER.md`, somente com aprovação explícita de orçamento;
- atribuição de `follow-on views`, controle/holdout, progresso qualificado e stop-loss.

### Gate

- dados suficientes para decisão conforme plano;
- custos e capacidade conhecidos;
- decisões baseadas em evidência;
- nenhuma expansão automática.
- alcance pago não conta como sucesso; qualquer escala exige incremento orgânico qualificado.

## Fase 7 — Aprendizado e segundo canal

### Objetivo

Demonstrar que o sistema aprende e que o método pode ser transferido.

### Entregas

- atualizações justificadas do modelo;
- comparação antes/depois;
- segundo canal ou arquétipo aprovado;
- isolamento multicanal;
- teste de generalização;
- relatório de repetibilidade.
- avaliação posterior da previsão de aquisição, custo incremental, contribuição/RPM real quando disponível e transferência da regra.

### Gate

- aprendizado ligado a dados;
- nenhum vazamento de identidade/ativos entre canais;
- melhoria ou rejeição conclusiva documentada;
- operação estável.

## Fase 8 — Produto

### Objetivo

Transformar o fluxo comprovado em solução utilizável por terceiros.

### Entregas

- arquitetura multiusuário;
- onboarding;
- permissões;
- cobrança/custos, se aplicável;
- documentação;
- contratos de serviço;
- painel;
- suporte e observabilidade;
- revisão de licenças;
- skills/MCP/plugin somente para fluxos estáveis.

### Gate

- evidência de uso interno real;
- custos sustentáveis;
- segurança revisada;
- promessas comerciais compatíveis com resultados;
- usuário aprova lançamento.

## Incorporação faseada do Gestor Central Autônomo

Esta correção não cria fase paralela nem altera gates anteriores:

| Fase | Incorporação limitada à fase | Gate adicional |
|---:|---|---|
| 1 | Proveniência e rubric por campo no padrão-ouro | Nenhum runtime central; exemplo humano real aprovado |
| 2 | Minerador executor idempotente, versionado e medido | Champion/challenger contra padrão-ouro por campo |
| 3 | Ledger append-only, migrações, estado global/por canal, memória tipada e isolamento | Persistência, SSOT, reingestão e isolamento aprovados |
| 4 | Baselines, hipóteses falsificáveis, evidência contrária e estados de conhecimento | Amostra pequena é `INCONCLUSIVE`; modelador não promove regra |
| 5 | Policy Gate, envelope, comando central e `ApplicationPlan` | Ação fora do envelope/protegida é bloqueada |
| 6 | Líder único, fila/lease/retry/checkpoint/DLQ, rotina, experimentos, previsões e relatório | Concorrência, recovery, predição imutável e gate humano passam |
| 7 | Rule Registry, aplicação futura, nova medição, transferência, drift, scorecard, replay e rollback | Ciclo completo e efeito posterior medido |
| 8 | Permissões, segurança, multiusuário e observabilidade; avaliar escala do banco | Produto somente após hardening e uso interno comprovado |

O Gestor pode promover uma fase pré-autorizada somente pela máquina objetiva D-047 e receipts imutáveis; nunca pode fabricar evidência, aprovar direito/custo/credencial/política, dispensar revisão humana exigida ou alterar o gate para passar. Publicação sem gasto é permitida apenas dentro do envelope D-047 após todos os gates. A correção completa só estará aceita após os testes de `docs/GESTOR_CENTRAL_ACCEPTANCE.md` nas fases correspondentes.
