# Gestor Central — runtime operacional da Fase 5

## Estado real

O runtime `gestor-central-heroverse-phase5-v1` está limitado ao gate da Fase 5. Ele observa os insumos que podem alterar a liberação, reavalia contratos, mantém custo técnico em R$ 0,00 e chama o executor de publicação somente se o gate consolidado retornar `READY_FOR_PUBLICATION_PIPELINE`.

Ele não é a Fase 6 antecipada: não coleta métricas pós-publicação, não inicia experimentos, não agenda catálogo futuro e não promove a fase. Seu trabalho é fechar a Fase 5 sem relaxar gates.

## Cadeia executada

1. detecta mudança por SHA-256 dos insumos controlados;
2. valida a revisão humana contra o hash exato do vídeo;
3. aplica, quando elegível, somente a transição `PROTOTYPED -> LIMITED` autorizada;
4. recalcula requisito OAuth e escopos;
5. valida a observação autenticada da cota YouTube e o ledger gratuito vidIQ pelos schemas correspondentes;
6. recalcula o guard de custo zero;
7. recalcula os 12 gates consolidados;
8. se e somente se todos passarem, executa staging privado, thumbnail, captions, verificação, promoção pública e verificação final;
9. persiste status, blockers e receipt idempotente.

## Observabilidade

- estado atual: `output/runtime/gestor-central/status.json`;
- fingerprint: `output/runtime/gestor-central/fingerprint.json`;
- PID efetivo: `output/runtime/gestor-central/manager.pid`;
- estação de revisão: `output/runtime/gestor-central/review-console-status.json`;
- acesso local efêmero: `output/runtime/gestor-central/review-console-access.json`;
- stdout: `output/runtime/gestor-central/manager.stdout.log`;
- stderr: `output/runtime/gestor-central/manager.stderr.log`;
- lock/lease: `output/runtime/gestor-central/manager-lock.json`;
- instalação no logon: `output/runtime/gestor-central/autostart-receipt.json`;
- prova operacional do supervisor: `output/runtime/gestor-central/autostart-verification.json`;
- release gate: `output/production/phase5/pilot-001/creative-v3/release_gate.json`;
- eventual receipt: `output/production/phase5/pilot-001/creative-v3/youtube_publication_receipt.json`.

No Windows, o executável do ambiente virtual pode manter um processo-filho do runtime Python. Isso representa uma execução lógica, não dois gestores concorrentes. O PID gravado é o processo efetivo que executa o loop.

## Instância única e início automático no Windows

O runtime mantém um lock não bloqueante real do sistema operacional em `manager.lock` e um receipt versionado com heartbeat e lease de 180 segundos. O JSON não concede autoridade sozinho: um arquivo obsoleto não bloqueia a recuperação, enquanto um segundo processo concorrente é recusado pelo lock do SO com status `BLOCKED_DUPLICATE_MANAGER` e código 73. Falha ao materializar o receipt depois da aquisição libera o lock e termina com o erro verdadeiro, sem rotular incorretamente a falha como duplicidade.

A tarefa agendada `HeroEngine-Phase5-CentralManager` inicia no logon do usuário, ignora instâncias adicionais, tenta três reinícios com intervalo de um minuto, não possui limite artificial de duração e executa ocultamente o runner versionado. A credencial continua fora do workspace, em diretório privado do usuário, e apenas o caminho entra no ambiente do processo. O conteúdo do token não é copiado para receipt ou log.

Comandos operacionais:

```powershell
.\scripts\install_phase5_manager_autostart.ps1 -TokenPath '<caminho externo do token>' -StartNow
.\scripts\verify_phase5_manager_autostart.ps1
.\scripts\remove_phase5_manager_autostart.ps1
```

O verificador exige simultaneamente: tarefa `Running`, PID vivo, lock `HELD`, console `LISTENING` no mesmo PID, bloqueio de uma segunda instância com código 73 e stderr vazio. Em `2026-09-04`, essa prova passou com o PID efetivo 15120 e custo técnico R$ 0,00.

## Estação de revisão independente

O loop inicia uma thread HTTP no mesmo PID efetivo, vinculada exclusivamente a `127.0.0.1:8765`. O URL contém token efêmero e não é exposto em documentação ou logs de entrega. A superfície aplica `no-store`, política de conteúdo, proteção por token e streaming MP4 com `Range`; captions SRT são entregues como VTT sem alterar as palavras.

O navegador só permite enviar a revisão depois de observar reprodução do início ao fim em 1×, pelo menos 95% dos segundos, captions visíveis, áudio confirmado, prévia de 390 px, identificação/conflito do revisor, nove janelas e doze gates com evidência, attestation e uma escolha A/B/C embaralhada. O servidor revalida o payload pelo schema e pelo avaliador existente. `NEEDS_REVIEW` é salvo como tentativa separada; somente decisão final válida pode criar o receipt canônico, que nunca é sobrescrito silenciosamente. O mecanismo reduz transporte manual, mas não transforma Codex em revisor humano nem elimina a responsabilidade factual do revisor.

Encerramento antecipado de uma conexão de mídia pelo navegador é tratado como disconnect esperado e não gera erro operacional. A regressão inclui um cliente que lê 1.024 bytes do arquivo completo e encerra a conexão; o stderr permanece vazio.

## Iniciar

Na raiz do projeto:

```powershell
.\.venv\Scripts\python.exe -m hero_engine.central_manager_phase5 --loop --interval 60
```

O token OAuth nunca é gravado no projeto. Após a reautorização com os quatro escopos, o processo precisa ser iniciado em ambiente que contenha `HERO_YT_TOKEN_PATH` apontando para o token fora do workspace. Sem a variável, o vídeo não é enviado.

O comando manual é fallback de diagnóstico. Na operação corrente do Windows, a tarefa agendada é o caminho principal; iniciar o comando manual enquanto ela está ativa deve e irá falhar com código 73.

## Pausar e retomar

Criar `output/runtime/gestor-central/PAUSE` pausa de forma fail-closed no ciclo seguinte. Remover somente esse arquivo retoma. Pausar não apaga receipt, token, vídeo remoto, histórico ou evidência.

## Recuperação

- `ERROR`: preservar `status.json` e `stderr`; corrigir a causa e reiniciar. O receipt impede repetir etapas remotas já confirmadas.
- `STAGED_PRIVATE_AWAITING_PROCESSING`: o próximo ciclo retoma a verificação do mesmo `video_id`; não faz novo upload.
- `PARTIAL_PRIVATE_VIDEO`: o vídeo permanece privado e o receipt registra a última etapa confirmada.
- cota insuficiente ou desconhecida: adiar para a renovação gratuita; nunca ativar billing.
- vidIQ: parar chamadas que consumam crédito quando restarem menos de 25 créditos renováveis e migrar para API oficial, cache e análise local; o plugin nunca bloqueia a publicação por si só quando não é necessário ao pipeline.
- identidade de canal divergente: bloquear e não publicar.
- tarefa não inicia: executar o verificador, preservar `autostart-verification.json`, inspecionar o bootstrap em `%LOCALAPPDATA%\HeroEngine\manager-task-bootstrap.log` e reinstalar somente a mesma tarefa versionada; nunca duplicar gestores.

## Done when verificável

O runtime só pode registrar `COMPLETE_PUBLIC` quando vídeo, thumbnail e captions correspondem aos hashes congelados, o canal observado é `UCuMF6pJQkyMzaVoAxFL86yA`, o processamento terminou, o vídeo foi verificado como privado antes da promoção e verificado como público depois dela. Até lá, `BLOCKED` é o comportamento correto.
