# Preflight — melhoria mensurável da Fase 2

## Autorização interpretada

Em `2026-09-02`, o proprietário rejeitou implicitamente o nível qualitativo do challenger submetido e ordenou continuar com padrão “imensuravelmente alto”, aprendizado contínuo real e melhoria contínua. Pela máquina de estados, a Fase 2 retorna de `AWAITING_REVIEW` para `IN_PROGRESS`, limitada à correção dos critérios falhos. A Fase 3 continua `NOT_STARTED`.

## Raiz e instruções

- raiz confirmada: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`;
- instruções: `AGENTS.md`, master spec, protocolo, fases, spec/prompt da Fase 2, schemas, Inteligência Contínua e Gestor Central;
- execução sem Git: integridade continuará por SHA-256;
- nenhuma credencial é necessária.

## Baseline congelado

- pipeline: `miner-local-0.1.0`;
- execução: `output/mining/phase2/active_run.json`;
- benchmark: `output/mining/phase2/benchmarks/summary.json`;
- testes: 33/33;
- decisões: 4× `KEEP_CHAMPION`;
- regressões críticas: 0;
- falhas: OCR 0/4, narrativa 0/4 e embalagem 3/4.

Os diretórios e hashes do baseline não serão sobrescritos. Um challenger novo receberá nova versão, novo hash de implementação e nova árvore de artefatos.

## Conciliação com aprendizado contínuo

O requisito permanente exige ciclo real e não uma alegação textual. Na Fase 2 é autorizado apenas aprender sobre a qualidade do próprio minerador por champion/challenger. Ledger global, regras de conteúdo, experimento em canal, scheduler central, publicação e aprendizado operacional pertencem às Fases 3–7 e não serão antecipados.

Ciclo permitido agora:

`baseline congelado -> hipótese pré-registrada -> mudança do minerador -> regressão -> resultado -> decisão -> próxima hipótese`

## Lacunas metodológicas identificadas

1. O benchmark OCR mistura texto literal com descrições editoriais humanas; é necessário um sidecar literal, sem alterar o padrão-ouro aprovado.
2. O OCR atual usa apenas o midpoint de cada take; isso perde bumper e encerramento.
3. O OCR atual aceita falsos positivos curtos/não latinos sem política de normalização.
4. A narrativa usa grupos com número igual de takes; clusters de cortes rápidos distorcem duração e função.
5. Não existe holdout de vídeo independente. As quatro fixtures são regressão de desenvolvimento; qualquer ganho será local e não prova generalização.
6. Embalagem depende parcialmente da qualidade OCR e precisa de submétricas separadas.

## Preservação

- schemas e documentos aprovados não serão removidos;
- thresholds atuais não serão reduzidos após observar os resultados;
- direitos continuarão bloqueados;
- classes de evidência e `NOT_REVIEWED` serão preservadas;
- nenhuma mídia será coletada ou publicada;
- o baseline continuará auditável.

## Entradas ausentes

- holdout independente anotado: indisponível e não autorizado nesta fase;
- métricas privadas do canal: fora de escopo;
- revisão jurídica/editorial de ativos: ausente, portanto produção permanece bloqueada.

## Preflight

`PASS`, com limitação explícita de generalização. A correção pode prosseguir somente na Fase 2.
