# Plano — Fase 3: mineração em lote e observatório

## Identificação

- Fase: 3.
- Objetivo único: preparar um conjunto versionado, rastreável e comparável de canais/vídeos para a Fase 4, sem gerar ChannelDNA.
- Estado atual: `IN_PROGRESS`.
- Prompt autorizado: bloco “Comando da Fase 3” de `prompts/03_MODEL_CHANNEL.md`.
- Documentos lidos: listados em `docs/PHASE_3_PREFLIGHT.md`.

## Entradas

- arquivos: seeds CSV, banco legado, 24 registros Grace, 16 intros/transcrições, 4 full-minings validados;
- dados: metadados públicos atuais e históricos, snapshots, classes de cobertura e direitos;
- fontes: páginas públicas dos canais/vídeos e artefatos locais;
- credenciais: nenhuma;
- direitos: análise permitida; todos os ativos permanecem fora de produção até gate próprio.

## Fora de escopo

- ChannelDNA, FormatArchetype, GenerationSpec ou regra final;
- download de mídia nova;
- produção/render/upload/publicação;
- Promote, Google Ads, gasto ou OAuth;
- previsão de RPM como fato;
- declarar YPP aprovado ou monetização garantida;
- promoção de licença/direito.

## Entregáveis

| Entrega | Caminho | Formato/consumidor |
|---|---|---|
| migrações SSOT | `migrations/phase3/` | SQL/observatório |
| ledger e repositório | `hero_engine/observatory/` | Python/Gestor Central |
| schemas | `schemas/observatory_*.schema.json` | contratos |
| coleta pública | `hero_engine/observatory/collectors.py` | adapter local |
| CLI | `hero_engine/cli.py` | operador |
| snapshots | `output/observatory/phase3/` | JSON append-only |
| coortes | `output/observatory/phase3/cohorts.json` | entrada Fase 4 |
| cobertura | `output/observatory/phase3/coverage.json` | gate |
| testes | `tests/test_observatory_phase3.py` | verificação |
| relatório | `docs/PHASE_3_REPORT.md` | revisão |

## Alterações previstas

| Componente | Ação | Motivo | Risco/controle |
|---|---|---|---|
| SQLite | migração versionada e transacional | SSOT/ledger/snapshots | backup lógico, idempotência e `integrity_check` |
| observatório | implementar ingestão e coortes | reprodutibilidade | payload hash, classes de evidência |
| coleta pública | metadados sem mídia | atualização real | timeout, cache, falha explícita |
| isolamento | operation/channel IDs | evitar vazamento | constraints e testes |
| cobertura | estratos FULL/OPENING/METADATA | não esconder lacunas | gate por campo |
| forecasts | bloquear prior-only decisório | previsibilidade honesta | status e teste |

## Passos e Done when

1. Congelar catálogo e backup lógico pré-migração.  
   **Done when:** hashes, contagens e `integrity_check` forem registrados.
2. Implementar migrações, ledger append-only, memória tipada e estado por canal.  
   **Done when:** migração e reingestão forem idempotentes, eventos não forem atualizáveis/apagáveis pela API e isolamento passar.
3. Implementar contratos de snapshot, cobertura e coorte.  
   **Done when:** JSON Schema rejeitar dados ambíguos/privados inventados.
4. Coletar snapshots públicos atuais do catálogo aprovado, sem mídia.  
   **Done when:** cada sucesso/erro tiver timestamp, fonte, hash e receipt.
5. Ingerir artefatos locais por estrato.  
   **Done when:** 4 full, 16 opening e população metadata estiverem ligadas sem duplicata.
6. Validar fora da amostra as mecânicas de abertura comparáveis.  
   **Done when:** a interseção real com as fixtures for calculada por ID, todas as intros restantes tiverem análise real e limitações; nenhuma conclusão de narrativa completa. A evidência apurada é 13 holdouts e 3 sobreposições, pois a quarta fixture completa não possui intro separada.
7. Construir coortes vencedor/mediano/fraco/período/cross-channel com regra congelada.  
   **Done when:** idade, velocidade, mediana, amostra e incerteza forem explícitas.
8. Emitir cobertura, erros, reprocessamentos e baseline de aquisição sem gasto.  
   **Done when:** nenhuma métrica privada/RPM ausente for imputada.
9. Executar testes, replay, integridade e relatório.  
   **Done when:** todos os critérios forem APROVADO/REPROVADO/BLOQUEADO e a Fase 3 terminar em gate.

## Testes e evidências

- migração do zero e sobre banco legado;
- reingestão idempotente;
- ledger append-only;
- concorrência/unique constraints;
- isolamento entre canal próprio, referência e fonte;
- snapshot válido e falha explícita;
- coorte determinística com idades normalizadas;
- classificação de cobertura impede uso de abertura como vídeo completo;
- `RPM`, `CTR`, retenção, receita e Earn ausentes continuam indisponíveis;
- 12 openings fora da amostra de Fase 2;
- suíte legada sem regressão;
- hashes e replay.

## Critérios de aceitação

- execução reproduzível;
- cobertura suficiente e discriminada para o formato escolhido;
- coortes justificadas, com vencedores, medianos e fracos;
- métricas normalizadas por idade e baseline;
- nenhuma métrica privada inventada;
- qualidade amostral aprovada por campo;
- SSOT, ledger, migração, reingestão e isolamento aprovados;
- custo externo US$ 0,00;
- erros e reprocessamentos visíveis;
- nenhum modelo final produzido.

## Riscos e bloqueios

- ausência de dados privados impede previsão calibrada de monetização nesta fase;
- cobertura completa de narrativa tem apenas quatro casos;
- mudanças/limites do YouTube podem afetar coleta pública;
- velocidade pública não prova causalidade;
- comparação cross-channel exige cautela por idade, catálogo e posicionamento.

## Encerramento esperado

- resultado: conjunto preparado e auditável;
- próxima fase sugerida: Fase 4, ainda condicionada ao gate integral da Fase 3;
- ações protegidas: continuam bloqueadas.
