# Auditoria focal de calibração — 08/09/2026

Estado: READ_ONLY_CONTRACT_AUDIT / sem nova calibração ou autoridade.
Revisor independente: publicity_contract_audit. Nenhuma inferência, mídia,
teste, rede ou edição de artefatos durante as duas auditorias. Root registra
o resultado para impedir repetição de pesquisa ou novos critérios arbitrários.

## PUBLICITY e controles do detector

O parecer `output/qa/phase6/diagnostics/phase6-av-publicity-independent-review-v1.md`
exige evidência de calibration/success presa ao modelo, preprocessing e runtime
aprovados, com semântica de retorno bem-sucedido. Ele não exige amostragem
exaustiva, acurácia universal ou novo padrão jurídico.

Os dois inputs de `detector-controls-v1/source-observations.md` foram definidos
antes da inferência. O par verifica funcionamento positivo/negativo e rejeita
um detector que retorna sempre vazio, mas não mede desempenho por domínio,
faces pequenas, perfis, oclusão ou pessoas de costas. Rótulos observados pela IA
não são revisão humana. PASS_OPERATIONAL_CONTROLS_ONLY não preenche um campo
detector_calibrated=true. Runtime de uma execução não autentica outra execução.

Não foi encontrado mínimoN, IoU, sensibilidade/especificidade ou FPR/FNR alvo
específico de YuNet nos contratos consultados. O10% de D-076 é amostra de
releases no protocolo humano, não N do conjunto de calibração do detector.
Não importar N30/800samples do alinhamento de fala para PUBLICITY.

Padrão-ouro humano para calibração permanece D-076 e Direção Criativa15; sem
evidência suficiente a capacidade não ultrapassa LIMITED. Isso não impõe
revisão manual do proprietário a cada vídeo e não permite chamar avaliação
da IA de anotação humana. Critérios novos devem ser justificados/versionados
antes do ensaio, nunca escolhidos depois para aprovar resultados.

O consumidor posterior ainda exige A canônica completa, execução própria
autenticada, contraprova persistida reaberta e relógio final estrito. A12
incompleta bloqueia esse caminho antes dos efeitos. Zero rostos amostrados
continua triagem de risco, nunca ausência universal de pessoas ou direito.

## Alinhamento temporal:23 não satisfaz30

A12 SHA `c38a12e6e7c5c2b5a131282ba22d674e0f3c789542ec74d9d58e467c574bedf6`
foi reaberta. São51PCM,26alvos na união e outras2unidades de velocidade
incompatível:23candidatas em1,06. O ramo vigente aceita somente
RECONCILED_NARRATION_UNIT do release atual; origem externa está false.

O contrato em phase6_av_timeline.py verifica população, PCM exato, disjunção,
voz, idioma, sample rate e velocidade, além de recusar aliases por hash/path.
Anotar mais de uma fronteira do mesmo PCM não cria exemplos independentes.
Policy temporal6587e640… exige30, cobertura1, erro máximo800samples. Esses
são critérios desse pré-registro; não serão reduzidos para caber no conjunto.

VERIFIED_ANNOTATED_DATASET e HUMAN_GOLD_STANDARD são referências previstas,
mas precisam do PCM original exato. Referência publicada pode anteceder o
pré-registro preservando seu instante real; não pode ser transferida para
outra voz ou para fala ressintetizada. Concordância de ASR, alinhamento
forçado, RMS e timestamps internos do gerador não viram referência independente.

Corpus externo é evolução reconhecida em D-149 e no sucessorAV, ainda não
implementada. Exige classe de origem versionada que reconstrua identidade,
proveniência, disjunção e compatibilidade, além de anotações reais aplicáveis.
Gerar30WAV sem referência não resolve a lacuna. Não implementar outro alinhador
ou repetir síntese/ASR antes de identificar fonte concreta de referência.

O ramo estrutural existente WHOLE_UNIT_PCM_BOUNDS/UNIT_BOUNDARY pode avançar
somente nas instâncias já definidas assim editorialmente. Não resolve37ranges
internos; não reclassificar revelações/HOLD/copy para evitar calibração.

## Próximos passos delimitados

1. Recuperar o fechamento dos dois controles reais sem repetir inferências.
2. Consumir essa evidência apenas como sucesso operacional, separado da
   calibração de domínio ainda não demonstrada.
3. Continuar contratos/fontes/estados estruturais independentes e correção
   real da variedade visual, preservando os bloqueios lexicais de A12.
4. Identificar referência temporal concreta compatível antes de ampliar a
   população/contrato de holdout. Ausência atual permanece registrada,
   não preenchida por dados fabricados ou hipótese de disponibilidade.

Done when de calibração não foi atingido. Esta auditoria fecha a interpretação
dos requisitos consultados, não os requisitos de produção em si.
