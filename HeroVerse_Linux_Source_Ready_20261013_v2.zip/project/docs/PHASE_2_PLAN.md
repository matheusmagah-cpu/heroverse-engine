# Plano de execução — Fase 2

## Identificação

- Fase: `2`
- Objetivo único: minerador automático mensurável contra o padrão-ouro.
- Estado atual: `AWAITING_REVIEW`.
- Prompt autorizado: `prompts/02_BUILD_MINER.md`.
- Preflight: `docs/PHASE_2_PREFLIGHT.md`.

## Arquitetura limitada à fase

`CLI/API -> job key -> adapters locais -> semântica determinística -> contrato -> run manifest -> benchmark champion/challenger`

O padrão-ouro entra somente depois que o challenger estiver materializado e validado. O pipeline não importa o builder manual da Fase 1.

## Passos

1. criar contratos e adaptadores substituíveis;
2. implementar inspeção, ASR, candidatos de take, keyframes e OCR;
3. montar hooks, narrativa, packaging e conteúdo com evidência explícita;
4. validar schema e proveniência;
5. persistir atomicamente por chave idempotente;
6. comparar cada run ao champion;
7. executar duas vezes para comprovar cache e não duplicação;
8. medir recursos e publicar relatório do gate.

## Métricas do benchmark

- timestamps: acordo de duração;
- transcrição: similaridade normalizada;
- OCR: F1 de tokens com limitação da anotação humana;
- hooks: janelas e similaridade da fala;
- takes: F1 de limites com tolerância declarada;
- narrativa: F1 de limites/papéis;
- packaging: similaridade de tokens/conceitos;
- direitos/proveniência: igualdade conservadora;
- schema: validade binária;
- custo: custo externo zero;
- latência: razão tempo de execução/duração;
- consistência: hash idêntico em cache hit.

## Fora de escopo

Fases 3–8, catálogo em lote, produção, publicação, Ads, credenciais, download de novas fontes e qualquer promoção automática do challenger.

## Encerramento

O resultado será classificado por critério e ficará em `AWAITING_REVIEW`, mesmo que os thresholds automáticos passem.

## Execução do plano

Os oito passos foram executados. O challenger não foi promovido: OCR e narrativa falharam nas quatro fixtures e embalagem falhou em uma. As divergências, recursos, limitações e decisões estão preservados em `output/mining/phase2/benchmarks/` e consolidados em `docs/PHASE_2_REPORT.md`.
