# Controle de execução por gates

## Regra permanente

Uma previsão só pode mudar quando houver uma mudança material registrada:
resultado de gate, identidade de candidata, recurso admitido/rejeitado ou bloqueio externo.
Não há nova regressão, aplicação ou retomada sem uma dessas mudanças.

Cada gate possui uma única saída: `PASS`, `FAIL_CAUSAL`, `RESOURCE_WAIT` ou
`EXTERNAL_BLOCKER`. `FAIL_CAUSAL` abre somente uma correção focal; duas falhas
com a mesma impressão digital proíbem uma terceira tentativa equivalente.

## Linha crítica atual — 17/09/2026

| Ordem | Gate | Entrada verificável | Saída necessária | Ação seguinte única |
|---|---|---|---|---|
| 1 | T110 prova pós-recuperação | candidata `cf33b3a7…`, PAUSE e rollback verificado | envelope aceito pelo leitor real | aplicação controlada pós-recuperação |
| 2 | aplicação controlada | prova T110 + preflight V7 | commit e preservações sob PAUSE | retomada controlada |
| 3 | retomada única | commit válido, PAUSE removível pelo protocolo | líder único e ciclo novo 12/12 | D-116 |
| 4 | D-116 | cinco snapshots atuais + identidade do líder | recibo PASS ou bloqueio causal | gate AV exato |
| 5 | AV / Vídeo 2 | receita visual, direitos e qualidade aprovados | render autorizado | render, revisão e publicação |

## Prazo por gate

O relógio de uma etapa começa no lançamento do processo real e termina no
recibo terminal. O tempo informado ao proprietário é sempre um **limite
operacional**, não uma promessa de resultado:

- T110: até 25 minutos a partir de `2026-09-17T21:06:50-03:00`.
- aplicação controlada: até 15 minutos após prova aceita e preflight.
- retomada + ciclo 12/12: até 30 minutos após aplicação válida.
- D-116: até 15 minutos após ciclo 12/12.

Se o limite vencer sem recibo terminal, a etapa é `FAIL_CAUSAL`/`RESOURCE_WAIT`;
não se altera a previsão nem se inicia uma cópia. Primeiro se identifica a causa
registrada e se executa a correção focal aplicável.

## Separação de resultados

Conclusão do núcleo técnico não equivale a render, publicação, audiência ou
monetização. Esses resultados dependem de gates próprios e de fatores externos.
