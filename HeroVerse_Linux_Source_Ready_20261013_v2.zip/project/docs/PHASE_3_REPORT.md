# Relatório de execução e gate — Fase 3

## Resultado

- Fase: `3 — Mineração em lote e observatório`.
- Lote promovido: `phase3-2026-09-02-catalog-v2`.
- Estado técnico: `APPROVED`.
- Decisão: todos os critérios materiais passaram; a autorização condicional D-027 libera o preflight da Fase 4.
- Custo de API e mídia: `US$ 0,00` observado.
- Ações protegidas executadas: nenhuma.
- Modelo final gerado: não.

O lote v1 foi preservado como diagnóstico, mas não é a entrega promovida: consultava somente `/videos` e ocultava 20 Shorts públicos do HeroVerse. O lote v2 coleta separadamente `/videos` e `/shorts`, mantém a distinção `LONG`/`SHORT` e reconcilia o catálogo próprio em 1 long-form + 20 Shorts.

## Escopo executado

1. backup SQLite anterior à migração, com contagens lógicas e `integrity_check`;
2. migração transacional e idempotente `phase3-001-observatory-ssot`;
3. estado por operação/canal, ledger append-only, snapshots append-only, memória tipada, erros, cobertura e coortes;
4. coleta pública sem mídia e sem credencial nos sete canais aprovados;
5. análise real das 16 intros locais nas janelas `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s`;
6. coortes determinísticas vencedor/mediano/fraco/período/cross-channel;
7. baseline de aquisição sem gasto e sem imputação de Studio/RPM;
8. replay sem rede, testes de isolamento e verificação integral de hashes.

## Evidência pública coletada

Captura congelada em `2026-09-02T18:06:24+00:00`:

| Canal | Função | Longs | Shorts | Estado de abas |
|---|---|---:|---:|---|
| `@heroverse74` | próprio | 1 | 20 | completo |
| `@GraceGritLove` | referência de formato | 24 | 0 | long completo; aba Shorts ausente |
| `@lionofjudahmotivation` | referência de mercado | 12 | 3 | completo dentro do limite |
| `@GospelPath-m3v` | referência de velocidade | 16 | 0 | long completo; aba Shorts ausente |
| `@THECHOSENPATH1.1m` | referência de velocidade | 16 | 0 | long completo; aba Shorts ausente |
| `@GODSLIVINGWORD-p2e` | referência de velocidade | 16 | 0 | long completo; aba Shorts ausente |
| `@DavidDigaHernandez` | fonte isolada | 7 | 8 | completo dentro do limite |

Totais: 7 snapshots de canal + 123 snapshots de vídeo = 130; 126 `COMPLETE`, 4 `PARTIAL`, 0 `FAILED`. Os quatro `PARTIAL` não representam perda dos vídeos longos: registram que a página pública não expôs uma aba de Shorts. Os quatro erros estão materializados em `observatory_errors` e no relatório do lote.

Um item restrito a membros observado durante a coleta não foi acessado nem incluído. Não houve tentativa de contornar acesso.

## Cobertura e validação fora da amostra

| Estrato | Registros | Uso permitido |
|---|---:|---|
| `FULL_VALIDATED` | 4 | hooks, takes, transcrição, narrativa e embalagem completos |
| `OPENING_ONLY` | 16 | somente abertura até 30 s/40 s; sem conclusão de narrativa integral |
| `METADATA_ONLY` | 123 | título/data/views e demais campos públicos; sem causalidade |

A interseção correta por ID entre as 16 intros e as quatro fixtures da Fase 2 é 3. Portanto, existem 13 holdouts reais, não 12. A quarta fixture completa (`Pkede5acSFw`) não possui arquivo de intro separado. Nos 16 arquivos, o `ffmpeg` concluiu a detecção de cortes e todos os quatro intervalos obrigatórios foram emitidos.

Nenhum holdout de abertura foi classificado como `FULL_VALIDATED`. Direitos permanecem `ANALYSIS_ONLY` ou `EDITORIAL_REVIEW_REQUIRED`.

## Coortes

A regra foi congelada como `phase3-quartiles-1.0.0`, com ranking por `PUBLIC_VIEWS_PER_COMPLETE_DAY`, idade mínima de um dia e desempate determinístico por `video_id`:

| Coorte | N | Faixa observada de views/dia |
|---|---:|---:|
| vencedor Q1 | 6 | 212,114–851,019 |
| mediano Q2–Q3 | 12 | 53,818–188,182 |
| fraco Q4 | 6 | 21,048–52,905 |
| período mais recente | 6 | 61,250–851,019 |
| cross-channel | 5 | 851,019–30.398,333 |

As faixas são descritivas. Elas não controlam tamanho de audiência, impressões, fonte de tráfego, retenção, sazonalidade ou posicionamento; logo, não sustentam causalidade. O canal de fonte não foi misturado à coorte de formato.

## SSOT e Gestor Central

No lote v2, o banco contém:

- 7 canais isolados;
- 130 eventos de ledger;
- 130 snapshots públicos;
- 143 registros de cobertura;
- 5 coortes e 35 membros;
- 1 memória tipada de indisponibilidade;
- 4 erros de aba pública.

`PRAGMA integrity_check = ok`. Update/delete no ledger e nos snapshots são bloqueados por trigger. Reingestão do mesmo lote manteve as contagens, reutilizou o cache e não chamou a rede. Chaves estrangeiras impedem evento com canal de outra operação.

## Aquisição, monetização e RPM

O baseline registra:

- `probability_of_ypp_by_30_days = null`;
- `RPM = null`;
- watch hours públicas qualificadas = `null`;
- `calibration_status = INSUFFICIENT_DATA`;
- `ads_activation_permitted = false`;
- gasto = `US$ 0,00`.

Isso é deliberado: 21 itens públicos não fornecem dados autenticados de impressões, CTR, retenção, watch hours qualificadas, inscritos ganhos, receita ou RPM. A válvula paga continua planejada para a Fase 6, mediante conteúdo publicado, série própria e aprovação explícita de orçamento.

## Testes e revisão

- 11/11 testes específicos da Fase 3;
- 49/49 testes completos do projeto;
- `compileall` aprovado;
- `pip check`: nenhuma dependência quebrada;
- 17/17 schemas JSON parseados;
- 17 artefatos do lote, 658.159 bytes, 0 divergências de hash;
- manifesto: SHA-256 `ceaa961d5e81191bf3f72aaf1a5bef758dd7f76c41bc11898cdc04182823e23c`;
- banco: `integrity_check = ok`.

O manifesto histórico da Fase 2 permaneceu inalterado. Como `hero_engine/cli.py` e o próprio teste de integridade são arquivos compartilhados, a evolução autorizada foi registrada com pares exatos de hashes em `phase2_integrity_evolution_receipt.json`; qualquer divergência adicional continua falhando.

## Critérios de aceite

| Critério | Estado | Evidência |
|---|---|---|
| catálogo congelado e reconciliado | APROVADO | 1 long + 20 Shorts do HeroVerse; sete canais |
| migração/SSOT/ledger | APROVADO | receipt, triggers e `integrity_check` |
| reingestão idempotente | APROVADO | replay cache-only, contagens idênticas |
| isolamento | APROVADO | FK e teste fail-closed |
| snapshots públicos reais | APROVADO | 130 snapshots, timestamps e fontes |
| cobertura discriminada | APROVADO | 4 full, 16 opening, 123 metadata |
| coortes justificadas | APROVADO | regra congelada, 5 coortes |
| validação fora da amostra | APROVADO | 13 holdouts de abertura |
| nenhuma métrica privada inventada | APROVADO | RPM/YPP/Studio permanecem `null` |
| erros/reprocessamentos visíveis | APROVADO | quatro erros de aba; v1 preservado; v2 promovido |
| testes e integridade | APROVADO | 49/49; 0 hashes divergentes |
| nenhum ChannelDNA/produção/gasto | APROVADO | ausência de artefato e ações protegidas vazias |

Critérios reprovados: 0. Critérios bloqueados: 0 para o objetivo da Fase 3.

## Limitações transferidas à Fase 4

- somente quatro casos têm narrativa completa validada take a take;
- 13 casos adicionais validam apenas a abertura;
- o HeroVerse possui apenas um long-form público, portanto seu histórico longo próprio não permite inferir um modelo;
- métricas privadas e econômicas continuam indisponíveis;
- views/dia é correlação pública, não causa;
- ausência de aba Shorts não prova ausência histórica de Shorts privados, removidos ou não listados.

## Gate

A Fase 3 está tecnicamente `APPROVED`. A autorização condicional D-027 foi aplicada somente após revisão dos dados, correção do escopo de abas, replay e suíte integral. A Fase 4 pode iniciar no limite de modelagem; produção, publicação, Ads, orçamento, credenciais e exceções de direitos continuam bloqueados.
