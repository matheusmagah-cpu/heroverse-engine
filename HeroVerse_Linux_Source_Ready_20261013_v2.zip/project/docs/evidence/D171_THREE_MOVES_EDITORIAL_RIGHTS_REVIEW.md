# D171 — observação específica dos seis estados de três movimentos

Registrada em 2026-09-08T04:24:13Z. Revisão editorial pelo assistente sob a
autorização do proprietário; não é revisão humana, parecer jurídico, teste de
retenção ou release do vídeo. Custo técnico adicional: R$0,00.

## Fonte efetivamente observada

Diretório `output/qa/phase6/diagnostics/three-moves-identity-v1/static-7db35489d912d00a323e5566/`.
Receipt8a09961699f428d9ddc215c6c6b2ae2acf0ab1277bdfbdc049310c2ef78ce4d2;
receita cc31bfaf4c800d052a0ec220e7a7e69dcf5691d3c55a36059e1ba5f05bafea09.
Execução única136675→f44312exit0, seis chamadas de raster,25,875s internos.
Os13artefatos tiveram hashes conferidos em586ace;15arquivos físicos incluem
started e receipt. Leitura08f0d4 dos seisSVG encontrou apenas retângulos e texto.

O assistente abriu e observou individualmente todas as seisPNG. O cabeçalho
literal é `Name / Test / Choose`, branco sobre azul escuro. A primeira imagem
não destaca nenhuma ação; as demais usam um único sublinhado dourado sob a
ação prevista. Não há destaque acumulado, contadores, checkmarks ou conclusão
de tarefa. Somente033/035 têm segunda frase e um campo de resposta visivelmente
vazio. Não há fotografia, rosto, pessoa, marca, logotipo, endereço, nome de
instituição, pessoa famosa, documento real ou conteúdo externo inserido.

| Estado | Foco / texto adicional observado | SHA256 PNG |
|---|---|---|
| u032-s00 | Nenhum / ausente | d9b1c7d0c0023bc136cc4d22ba54dc3a0706ac0545d25cb07ff06e95374dca10 |
| u033-s00 | Name / Fact: what happened? | e2814019ed03b3a2a2d986cdcb071504e264870d1d4d05d853eeb0b4f7fdd9bd |
| u035-s00 | Choose / One faithful response today | c326dfdf7843efd0eeeb1286b4d4331614a70d9001db07e4f01a0f075a37b7e5 |
| u047-s00 | Name / ausente | 640dbaa8bd1f83ae32fb441cbcb24d4eab4fcc58f1d71a47786fe34e01222bc6 |
| u048-s00 | Test / ausente | c051ce52b8b557202cf4145acc8fc0d312f34a4bd81c86ee58130164395bd427 |
| u049-s00 | Choose / ausente | bd6116478da5b505b6acd1908825395ad242dbf13e321bf42906c08ff57a0bd9 |

Função observada: apresentar/reativar as três operações do exercício e, nos
dois estados auxiliares, reservar a resposta do espectador sem inventá-la.
Espaço vazio não é resultado ausente a ser preenchido automaticamente. Trata-se
de estados esquemáticos curtos, não da prova de que um vídeo inteiro de cartelas
atinge retenção, variedade ou qualidade narrativa suficientes.

## Classificação de origem e limites

Classificação interna OWNED, limitada a RASTERIZED_STILL_IN_YOUTUBE_VIDEO,
pela composição controlada de geometria própria e frases da proposta pinada
V6ba7dabb1…; não deriva dos direitos das quatro cartelas anteriores. A mesma
linhagem ancestral owned-four-criteria-panel-v1 é mantida: seisestados não
significam seislinhagens de variedade ou originalidade editorial garantida.

A fonte Arial Bold local não é embutida nem redistribuída. As condições já
documentadas na revisão das perguntas continuam aplicáveis ao mesmo TTF e
mesmo ambiente, sem nova licença concedida por esta nota:
[revisão tipográfica anterior](D171_TEST_QUESTIONS_EDITORIAL_RIGHTS_REVIEW.md).
Essa referência trata somente o componente tipográfico compartilhado, não
transfere a observação visual, a autoria ou a liberação dos novos ativos.
Não atesta a licença individual do computador ou permite empacotar o TTF no
futuro produto comercial. Não há nova consulta jurídica nesta etapa.

OWNED não implica autoria humana, exclusividade de saída assistida por IA ou
direitos sobre componentes externos. O registro operacional individual dos
novos ativos ainda deve ser produzido e verificado. QA estática independente
está em execução separada; esta nota não declara seu resultado antecipadamente.

Não concede timing, alinhamento lexical, percepção de áudio, compreensão,
retenção, originalidade do vídeo completo, movimento, licença de outros ativos,
publicity do conjunto, renderAV, fila ou publicação. Mudança de bytes, origem,
copy ou contexto exige a revisão aplicável, não reaproveitamento tácito da nota.
