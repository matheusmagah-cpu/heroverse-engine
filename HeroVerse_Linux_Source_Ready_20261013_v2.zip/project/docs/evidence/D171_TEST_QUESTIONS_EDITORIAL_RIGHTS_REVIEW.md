# D171 — revisão específica das quatro cartelas de perguntas

Registrada em 2026-09-08T01:39:24Z. Revisão editorial pelo assistente, autorizada
pelo proprietário; não é revisão humana, parecer jurídico ou release do vídeo.
Custo técnico adicional R$0,00. Não transfere direitos de cartelas anteriores.

## Objeto observado

Quatro PNG/SVG em
`output/qa/phase6/diagnostics/test-questions-v1/static-a4630336964863b442fdc027/`:
u019-s00, u020-s00, u020-s01, u021-s00, todos com prefixo `visual-`.
Receipt SHA f63ac629a6e9c76ba3485e5dd182123034d108fce515985fce632a71d716c622;
receita ea876e4f9ecc8f20f45e44b07002b738460edc813a966e105fb024d3f7cbc025.
As quatro PNG foram abertas e observadas pelo assistente. Leitura c7a5e1 dos
quatro SVG confirmou somente três retângulos e uma ou duas frases por imagem.
Não há fotografia, pessoa, marca, logotipo, endereço, prestação profissional
atribuída ou registro real de acontecimento. Código próprio desenha geometria
e frases previstas no plano; não baixa imagens nem importa fonte visual externa.

| Estado | Texto integral observado | SHA256 PNG |
|---|---|---|
| u019-s00 | Test; Loud is not true | 104947b088a82ce8dc40fc98a79dab985a022399473417807ee81d2bca08e43b |
| u020-s00 | Fully true? | 9e997a992556fbc89d8a600597b7043ea0298b4b574f2b8c9756637fd241fbb7 |
| u020-s01 | Fully true?; Or only possible? | 3be9cfbf8fc33b50541b9948237223f748c3c05ba62f2db50d986230f00656f4 |
| u021-s00 | Character; Is this how I should act? | 69dce86080279482b66b89310af0a1ab5faba9bf5e64ce706836f3d1463d8a44 |

As perguntas são exame editorial, não diagnóstico ou alegação de resultado.
São quatro estados da linhagem `owned-four-criteria-panel-v1`, não quatro
linhagens independentes. Nenhum marcador de progresso anterior foi herdado.

## Decisão de origem e limites

Classificação interna OWNED, limitada a RASTERIZED_STILL_IN_YOUTUBE_VIDEO,
com base na origem controlada e observação destas imagens. Não implica autoria
humana, exclusividade de saída assistida por IA, marca registrada ou direitos
sobre componentes externos. Registro operacional separado ainda é necessário.

Arial Bold local e Pillow já existentes foram usados; não se embute nem se
redistribui o TTF. A Microsoft trata texto rasterizado em vídeo como saída
gráfica, condicionada às licenças aplicáveis do software. Esta consulta não
atesta a licença individual do computador nem autoriza entregar a fonte no
futuro produto. [Microsoft — Font redistribution FAQ](https://learn.microsoft.com/en-us/typography/fonts/font-faq).

Estas cartelas esquemáticas não simulam pessoas ou eventos reais. A regra
consultada dispensa divulgação para produção não realista; a avaliação de
divulgação do vídeo completo permanece separada, incluindo voz e música.
[YouTube — Disclosing use of GenAI content](https://support.google.com/youtube/answer/14328491?hl=en).

Fontes primárias consultadas nesta revisão; o primeiro acesso à página YouTube
falhou por timeout e a pesquisa oficial recuperou seu conteúdo, sem efeito na
conta/canal. Nenhuma condição de licença foi substituída por um score automático.

QA independente de pixels/OCR, emenda case-only, vínculo produtivo, timing,
áudio, composição, variedade e direitos/publicity do conjunto ainda não são
aprovados por esta nota. Mudança de bytes/origem exige nova revisão própria.
