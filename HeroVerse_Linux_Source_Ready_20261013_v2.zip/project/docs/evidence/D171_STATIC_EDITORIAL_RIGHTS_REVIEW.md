# D171 — decisão editorial de uso das duas famílias estáticas próprias

Revisor: Codex, agente principal autorizado pelo proprietário; revisão editorial
automatizada, não revisão humana, parecer jurídico ou concessão de copyright.
Escopo exclusivo: os onze PNGs das duas gerações identificadas abaixo, usados
como imagens rasterizadas na composição do HeroVerse. Não autoriza publicar.

## Evidência examinada

Leitura integral das duas receitas, inspeção visual dos dois contact sheets e
do `state-0.png` que não está na folha de quatro critérios; cadeia de origem,
inventário, pixels e texto vinculados pelo inspector independente D171.

- `fear-examples-v1`: receipt
  `076ec5bec965ccc5c294ecd82ac813faf1886343a928dbb3c30d26d45092c434`,
  receita `84fd21136522efa10b89900a4fc5f06523396d587b27fa356d83e10c908d914b`.
  Estados door-0/door-1, reply-0/reply-1, morning-0/morning-1.
- `four-criteria-v1`: receipt
  `2b0b541bbbeacf9b7c62d6dbe85bd34ac789b0e7da96d86e1f0ce49a76a7415f`,
  receita `ea2000c544bcf8e934509296574510ba20af920d1956e2a4fb84c003314edb11`.
  Estados state-0 a state-4.

As receitas desenham geometria elementar e palavras do TakePlan: porta fechada;
telefone genérico sem marca, contato ou mensagem real; janela, chuva e xícara
sem marca; painel tipográfico com quatro critérios. Não carregam imagens,
logotipos, vídeos ou ilustrações visuais de terceiros. Os quatro PNGs reaproveitados
da geração anterior de medo continuam ligados aos SVGs e à receita preservados.
Não há alegação de autoria humana ou direito exclusivo sobre saída assistida por IA.

## Decisão restrita de uso

Uso editorial comercial das composições próprias classificado como OWNED no
ledger interno, no sentido de origem controlada pelo projeto, não de garantia
de exclusividade jurídica. Aprovação limitada a `RASTERIZED_STILL_IN_YOUTUBE_VIDEO`.
Nenhuma licença de vídeo de terceiros é reutilizada para fundamentar esta decisão.
Não há questão de direitos autorais identificada e não resolvida neste escopo
estreito; suspeita futura, ativo alterado ou origem divergente exige nova decisão.

As palavras da família medo atribuem a interpretação a `Fear says:`; a imagem
não é documento de que abandono, rejeição ou conclusão espiritual ocorreram.
Essa observação não aprova sincronização, semântica do filme integral ou retenção.

## Fonte tipográfica e divulgação

Arial Bold instalada, SHA
`e8f4e3baf6cc35fed6fcce3a540e8b39e8f6cda1d22a28f2ec8f526fef7a43f5`.
Somente rasterização de frases: nenhum TTF embutido, distribuído ou convertido
em biblioteca de bitmap-font. Consulta read-only do Windows retornou
`Windows(R), CoreSingleLanguage edition`, `LicenseStatus=1`; isso registra estado
de ativação observado, não substitui o instrumento de licença do sistema.
A versão comercial não poderá distribuir a fonte junto do produto.

Fundamentação e fontes primárias: `D171_STATIC_RIGHTS_PRIMARY_SOURCES.md`, SHA
`0f7f6c0d241fb50102d35bc90c288b2e259c8fbfb1dbbd1a07b39219e509e407`.
Os onze PNGs são gráficos esquemáticos não fotorealistas; divulgação de IA não
é exigida para essas imagens isoladas segundo a política consultada. Narração,
música, demais imagens e vídeo final exigem decisão agregada própria.

## O que esta decisão não entrega

Não concede publicity, padrão-ouro humano, capacidade de produção, tempos de
revelação, aprovação de movimento, áudio, render final ou publicação. A inspeção
de risco de marca/pessoa continua independente; ausência observada não é garantia
jurídica. As onze imagens representam duas linhagens, nunca onze fontes de variedade.
O estado do vídeo permanece bloqueado pelos gates pendentes. Custo técnico R$0,00.
