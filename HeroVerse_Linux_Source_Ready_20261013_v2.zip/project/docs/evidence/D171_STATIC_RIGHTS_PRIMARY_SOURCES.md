# D171 — fontes primárias para gráficos próprios

Observação em 07/09/2026, registrada às 18:06:56 UTC. Esta nota é análise com
fontes primárias, não uma licença emitida pelo projeto, parecer jurídico,
declaração de autoria humana ou autorização automática de publicação.

## Fonte instalada do Windows

A Microsoft trata texto convertido em imagem e incluído em vídeo como saída
gráfica, desde que o arquivo de fonte não esteja embutido. O uso comercial da
saída não recebe a restrição indicada para aplicativos licenciados somente
para uso doméstico, estudantil ou não comercial. Isso não autoriza redistribuir
a fonte com o futuro produto, copiá-la para servidor, convertê-la em outro
formato ou montar um bitmap-font. A orientação cobre fontes fornecidas pelo
Windows; fontes de terceiros precisam da respectiva licença.

Fonte: [Microsoft — Font redistribution FAQ](https://learn.microsoft.com/en-us/typography/fonts/font-faq),
seções de arquivos gráficos, texto em vídeo, aplicativos e redistribuição.

Aplicação limitada: os onze PNGs usam palavras/frases rasterizadas, sem arquivo
TTF embutido. O SVG referencia Arial pelo nome; não distribui seus bytes. A
linhagem de composição original do projeto é distinta dos direitos da fonte.
Esta nota não comprova por si a licença individual do sistema operacional.

## Divulgação de IA no YouTube

A política vigente exige divulgação para alteração significativa ou geração
fotorealista, incluindo representação enganosa de pessoas, eventos e lugares.
Conteúdo não realista, infográficos e assistência de produção aparecem entre
os exemplos que não exigem divulgação. A plataforma pode acrescentar rótulos
automaticamente. A atualização de maio de 2026 ampliou a visibilidade desses
rótulos; rótulo sozinho não exclui elegibilidade de monetização.

Fontes: [YouTube — Disclosing use of GenAI content](https://support.google.com/youtube/answer/14328491?hl=en)
e [YouTube — atualização de 27/05/2026](https://blog.youtube/news-and-events/improving-ai-labels-viewers-creators/).

Aplicação limitada: os dois templates são gráficos esquemáticos, não registros
fotorealistas. Essa classificação das imagens NÃO determina a classificação
do áudio, da música, de outros ativos ou do vídeo final. A decisão de upload
continua presa à composição integral e ao gate correspondente.
