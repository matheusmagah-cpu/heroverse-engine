# D171 — revisão específica das cartelas compactas

Revisão editorial automatizada autorizada, registrada em 2026-09-07T23:56:00Z.
Não é revisão humana, parecer jurídico, concessão de copyright, garantia de
exclusividade ou aprovação de publicação. Custo técnico adicional: R$0,00.

## Objeto exato

Doze arquivos PNG e SVG em
`output/qa/phase6/diagnostics/two-column-compact-v1/static-5d42a585eacde074510f8f61/`:
visual-u010-s00; u011-s00/s01; u012-s00/s01; u013-s00; u014-s00; u015-s00;
u016-s00/s01; u017-s00; u018-s00 (todos com prefixo visual-).
Receipt cf6aeb64489e6846acd510e5d771ee87db504f1118bbac0262770acbd784737b;
receita 51a6c8d4bab2d4c6d953861093d84cf6ec25ecc16d4ebba53abe335521ec033c;
emenda fb2543b0afb8ff696204c72fb40800bdf67e7e8459563909a5b8f31fb4ba8a5e;
projeção d629bce952153ea32c689ccb5cea5f95d22faa6c3dad39111b0f0672e51acf32.

Os estados u016-s00/s01 compartilham exatamente os mesmos bytes; há11conteúdos
PNG distintos, não12fontes independentes. Linhagem mantida:
`heroverse-owned-two-column-composition`.

## Observações e fundamento da decisão

A receita pinada foi examinada: cria fundo, retângulos e frases rasterizadas
por código do projeto. Não importa fotografia, vídeo, logotipo ou ilustração de
terceiro para esses gráficos. O SVG referencia Arial pelo nome; não embute TTF.
Leitura583544 verificou os12SVGs: somente elementos rect/text e cópia prevista,
incluindo as duas colunas Fact e Fear's forecast. Imagens representativas
u012-s01/u014-s00/u016-s00 foram observadas durante a remediação estática;
essa observação do assistente não é padrão-ouro humano nem revisão do filme.

As frases da direita são previsões atribuídas ao medo, não registros de que o
evento futuro ocorreu. Essa distinção de conteúdo é preservada pela emenda;
legibilidade, tempo de revelação e semântica do composto final permanecem gates.

Decisão interna: origem controlada pelo projeto classificada como OWNED para
uso editorial comercial limitado a `RASTERIZED_STILL_IN_YOUTUBE_VIDEO`.
Não foi identificada questão autoral pendente nesse escopo estreito de gráficos
próprios. Isso não é afirmação de autoria humana ou exclusividade sobre saída
assistida por IA. Alteração de origem, suspeita ou arquivo exige nova revisão.

## Fonte e plataforma — consulta primária nesta revisão

Arial Bold local, SHA
e8f4e3baf6cc35fed6fcce3a540e8b39e8f6cda1d22a28f2ec8f526fef7a43f5.
A orientação da Microsoft permite tratar frases rasterizadas em vídeo como
saída gráfica, sem embutir a fonte. Não autoriza redistribuir o TTF com o
produto nem hospedá-lo em servidor. Licença do ambiente e software utilizados
continuam aplicáveis; a FAQ não prova a licença individual deste computador.
[Microsoft — Font redistribution FAQ](https://learn.microsoft.com/en-us/typography/fonts/font-faq).

As cartelas são gráficos esquemáticos, não cenas fotorealistas nem registros
alterados de pessoas/eventos reais. A política consultada dispensa divulgação
para conteúdo não realista. Portanto estas imagens isoladas não exigem o rótulo
de alteração realista; a decisão do vídeo inteiro continua separada, sobretudo
para narração, música e demais imagens.
[YouTube — Disclosing use of GenAI content](https://support.google.com/youtube/answer/14328491?hl=en).

Também se preserva a nota anterior
`D171_STATIC_RIGHTS_PRIMARY_SOURCES.md`, SHA
0f7f6c0d241fb50102d35bc90c288b2e259c8fbfb1dbbd1a07b39219e509e407.
Ela fornece fundamentação, não decisões OWNED transferíveis de outras PNGs.

## Limite e próximo consumidor

O registro operacional precisa criar proveniência e decisão próprias para cada
arquivo, presas a esta revisão e à inspeção técnica real. Este MD sozinho não
produz PASS de B. Publicity, seleção, duração, ritmo, movimento, áudio, variedade,
QA final, divulgação agregada e publicação não estão autorizados por esta nota.
Nenhum TTF será distribuído e nenhuma nova ferramenta paga é necessária.
