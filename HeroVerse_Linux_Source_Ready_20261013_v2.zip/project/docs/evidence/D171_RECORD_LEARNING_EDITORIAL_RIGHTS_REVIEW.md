# D171 — observação específica do registro e aprendizado, unidades 036–038

Registrada em 2026-09-08T04:50:06Z. Revisão editorial pelo assistente sob a
autorização do proprietário; não é revisão humana, parecer jurídico, teste de
retenção, aprovação audiovisual ou evidência de aprendizado publicado.
Custo técnico adicional: R$0,00.

## Material efetivamente observado

Diretório `output/qa/phase6/diagnostics/record-learning-v1/static-a017a2102dfa76cb8e7755f6/`.
Receipt c61b7a2a69c557e76385c7dc95526298dc37cbde255394cdeb8dad1fc1aa50a6;
receita deaabda55c5ae873f5088fb63144b9e811875cd34e5443fcd1152e808f6c75a6.
Execução única 9e9fb0 → 52fa2f exit0: cinco chamadas de raster para seis caminhos
PNG e seis SVG, 30,219s internos. Os treze artefatos tiveram hashes conferidos
independentemente em 339115. O assistente observou os cinco conteúdos PNG
distintos e leu os seis SVG em cd486b. A ocorrência u037-s00 é a cópia exata de
u036-s00, com SHA e tamanho conferidos; não foi inventada uma sexta imagem.

| Estado | Conteúdo literal observado | SHA256 PNG |
|---|---|---|
| u036-s00 e u037-s00 | Action; Observed result | d2b1a98125e9b6522c4f8870267baa6dd22d5323d95878f0a283ecd0efb3563c |
| u037-s01 | Original prediction; Keep the record unchanged | 86d1d6ce07d3850751a74f1fb382215c9695ae90788ea0aaf6ef971c8225658c |
| u038-s00 | Written evidence; Compare before and after | 01e0f674a9b1b3cdad1c80f97d02bd2f64984b42ab9ff0fbb343308e06392c48 |
| u038-s01 | Was the warning useful? | a036671cb80e0cae10da00a97de18caf06ec51bdfc0436f7c5d0c49536307144 |
| u038-s02 | Or did the story only exhaust? | 5f0e174baf51fa72cc2df1af5b743700c1172b01dcc57d928590b40da90f8469 |

Os SVG contêm somente texto e retângulos controlados. As PNG exibem texto
branco sobre azul escuro, bordas discretas e áreas de escrita vazias, sem
fotografia, pessoas, rostos, marcas, logotipos, instituição, endereço, documento
real, depoimento, dados pessoais ou resultados preenchidos. Nenhum vencedor,
selo de aprovação ou resultado medido é mostrado. Não há material externo
incorporado além do componente tipográfico local já identificado.

## Julgamento editorial específico e limites

u036 e a retomada u037-s00 apresentam um registro de ação e resultado, sem
inventar uma resposta. u037-s01 muda para dois documentos em enquadramento
distinto: a previsão é introduzida como categoria nova, não uma transformação
da palavra Action. A instrução fica fora dos documentos vazios. O documento
direito não tem rótulo próprio; sua interpretação retrospectiva depende da
narração e deverá ser comprovada no gate semântico audiovisual. A imagem
estática sozinha não comprova que o espectador entenda essa relação.

Os três estados u038 conservam duas áreas de comparação nas mesmas posições.
Só as perguntas editoriais mudam; não se declara qual advertência funcionou
nem qual história exauriu o espectador. A relação antes/depois e a mudança de
pergunta ainda dependem de exposição, narração e tempo lexical validado.
Esta nota não elimina essa lacuna nem considera cartelas suficientes para
variedade, retenção ou qualidade do vídeo inteiro.

Classificação interna de origem: OWNED, restrita a
RASTERIZED_STILL_IN_YOUTUBE_VIDEO, pela composição controlada de geometria e
frases da proposta V6 pinada. A linhagem ancestral continua
owned-four-criteria-panel-v1; seis ocorrências/cinco conteúdos não significam
cinco ou seis novas linhagens independentes.

A fonte Arial Bold local não é embutida nem redistribuída. As condições do
mesmo TTF no mesmo ambiente estão documentadas na
[revisão tipográfica anterior](D171_TEST_QUESTIONS_EDITORIAL_RIGHTS_REVIEW.md).
A referência trata somente esse componente compartilhado, não transfere
direitos dos ativos anteriores. Esta nota não atesta a licença individual do
Windows nem autoriza empacotar o TTF no futuro produto comercial. Não há nova
consulta jurídica nesta etapa.

OWNED não é afirmação de autoria humana ou exclusividade jurídica da saída
assistida por IA. Os registros operacionais específicos ainda serão criados e
verificados. QA independente ainda não executado no momento desta nota.
Nenhuma licença, autorização de imagem, marca ou avaliação de outra fonte é
herdada. Mudança de bytes, copy, origem ou contexto exige a revisão aplicável.
Não há aprovação de fonte no consumidor A11, timing, áudio, movimento,
compreensão, publicidade do conjunto, render AV, fila ou publicação.
