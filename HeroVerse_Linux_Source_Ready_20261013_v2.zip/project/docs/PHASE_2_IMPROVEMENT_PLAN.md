# Plano controlado — ciclo de melhoria 001 do minerador

## Objetivo único

Criar e avaliar um challenger global, determinístico e local que melhore OCR, segmentação narrativa e embalagem sem reduzir thresholds, degradar campos aprovados ou relaxar direitos.

## Hipóteses prévias

### H-MINER-001 — OCR

OCR em início/centro/fim nos takes de abertura/fecho, normalização literal e supressão de falsos positivos devem aumentar F1 sem inventar texto.

### H-MINER-002 — Narrativa

Mudanças de coesão lexical, pausas, marcadores discursivos e posição temporal devem aproximar os limites/papéis humanos melhor que agrupamento por quantidade de takes.

### H-MINER-003 — Embalagem

Separar título, OCR literal da thumbnail e alinhamento de promessa deve remover a dependência indevida da descrição editorial e elevar a estabilidade do campo.

## Thresholds congelados

- OCR: `>= 0,35` por fixture;
- narrativa: `>= 0,55` por fixture;
- embalagem: `>= 0,75` por fixture;
- campos já aprovados: nenhuma queda superior a `0,02` na média;
- regressões críticas: `0`;
- direitos/schema/evidência/custo/consistência: `1,0`;
- latência: manter score `>= 0,5`;
- promoção automática: proibida.

## Passos e Done when

1. Congelar baseline e pré-registro estruturado.  
   **Done when:** hashes e previsões existirem antes do código challenger.
2. Criar sidecar OCR literal por inspeção visual.  
   **Done when:** cada token tiver fixture, frame/timecode, revisor, classe e evidência.
3. Implementar OCR multi-frame seletivo e normalização.  
   **Done when:** texto agregado mantiver confiança/proveniência por frame e rejeições forem auditáveis.
4. Implementar segmentação narrativa sem acesso ao gold.  
   **Done when:** o pipeline usar apenas ASR/takes do challenger e emitir razões de mudança.
5. Tornar benchmark metodologicamente equivalente.  
   **Done when:** OCR literal não usar prosa editorial e embalagem tiver submétricas rastreáveis.
6. Executar quatro vídeos e replay.  
   **Done when:** 4/4 jobs completos, 4/4 cache hits e nenhum hash duplicado.
7. Comparar baseline/challenger.  
   **Done when:** ganhos, perdas, custo, incerteza e ausência de holdout estiverem explícitos.
8. Registrar resultado sem reescrever o pré-registro.  
   **Done when:** outcome separado classificar cada hipótese como `SUPPORTED_LOCAL`, `INCONCLUSIVE` ou `REJECTED`.

## Fora de escopo

Fase 3, ledger global, observatório em lote, aprendizado de regras de conteúdo, canal/piloto, geração de vídeo, publicação, Ads, gasto, plugin externo e alegação de generalização.

## Condição de parada

Encerrar em `AWAITING_REVIEW` com o champion preservado se qualquer gate falhar. Não avançar para a Fase 3.
