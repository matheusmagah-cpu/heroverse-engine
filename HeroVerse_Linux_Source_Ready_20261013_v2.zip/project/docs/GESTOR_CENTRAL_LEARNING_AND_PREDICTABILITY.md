# Aprendizado, previsibilidade e melhoria comprováveis

## Ciclo obrigatório de aprendizado

Cada hipótese deve possuir a cadeia completa:

1. observação versionada e classificada;
2. baseline compatível;
3. hipótese falsificável, escopo e evidência contrária;
4. previsão imutável registrada antes do resultado;
5. experimento autorizado, variável, controle, janela, custo e stopping rule;
6. resultado vinculado ao evento e à versão exata do pipeline;
7. avaliação com incerteza, interferências e tamanho da amostra;
8. transição versionada da regra;
9. aplicação explícita em conteúdo futuro;
10. nova medição para verificar repetição do efeito.

Sem observação nova, o ciclo registra `NO_NEW_EVIDENCE` e não altera confiança, regra ou versão de conhecimento.

## Estados de conhecimento

- `CANDIDATE`: sinal observado, não testado;
- `TESTING`: experimento autorizado em curso;
- `SUPPORTED_LOCAL`: efeito repetido no escopo local aprovado;
- `TRANSFER_CANDIDATE`: hipótese para outro canal/arquétipo;
- `SUPPORTED_GENERAL`: efeito repetido após transferências aprovadas;
- `INCONCLUSIVE`: evidência insuficiente ou ambígua;
- `SUSPENDED`: perdeu validade, apresentou regressão ou drift;
- `REJECTED`: foi contrariada pela evidência.

Transições são configuradas, auditáveis e reversíveis. Um vídeo isolado não promove regra geral.

## Aprendizado da qualidade do próprio sistema

O minerador e demais módulos são avaliados contra padrão-ouro humano versionado. Métricas mínimas por campo:

- timestamps: tolerância e erro absoluto;
- transcrição/OCR: precisão/recall ou erro por token/campo;
- takes/cortes: correspondência temporal e função narrativa;
- hooks: cobertura correta das janelas `0–1`, `1–3`, `3–8` e `8–30 s`;
- narrativa/embalagem: concordância por rubric e justificativa com evidência;
- direitos/proveniência: zero liberação sem evidência válida;
- schema: validade e completude;
- custo/latência: mediana, percentis e falhas;
- consistência: mesma entrada/versão produz mesmo resultado onde exigido.

Uma versão challenger só substitui a champion se superar limites aprovados, não introduzir regressão crítica, manter custo/capacidade dentro do envelope e passar revisão exigida.

## Protocolo de previsibilidade

Toda previsão é registrada antes do outcome, com alvo, unidade, horizonte, cutoff, coorte, baseline, features disponíveis no cutoff, distribuição/intervalo, probabilidades, versão e suposições. O registro fica imutável; correções criam nova previsão e não sobrescrevem a anterior.

Após a janela:

- MAE e, quando denominadores forem válidos, MAPE/sMAPE para valores contínuos;
- cobertura e largura de intervalos para incerteza;
- Brier score e log loss para probabilidades;
- calibração por faixas de probabilidade;
- uplift de erro/decisão contra baseline simples;
- desempenho fora da amostra e por canal/coorte;
- tamanho de amostra, janela, dados ausentes e interferências.

O sistema só pode ser chamado de previsível para um alvo/escopo quando superar baseline simples fora da amostra, atingir thresholds aprovados de erro e calibração e possuir amostra mínima configurada. A conclusão é local ao alvo, horizonte, canal e regime; nunca garantia de monetização, views ou lucro.

## Baselines mínimos

- último valor disponível;
- mediana móvel da coorte comparável;
- taxa histórica simples por canal/formato;
- regra determinística existente, quando aplicável.

O baseline vencedor deve ser registrado. Um modelo complexo que não o supera é rejeitado ou mantido como challenger.

## Runtime operacional da previsão — Fase 6

`hero_engine/phase6_prediction_runtime.py` transforma o registro anterior ao resultado em execução temporal real. Cada `PredictionRecord` cria um job idempotente `PREDICTION_OUTCOME_CHECKPOINT`, indisponível para claim antes de `horizon.ends_at`. No instante elegível, o Gestor coleta o vídeo exato pela API oficial, prende o snapshot ao checkpoint da fila, materializa um `PredictionEvaluation` imutável e encerra o mesmo job. Retry reaproveita o snapshot já registrado e não recaptura silenciosamente outro outcome.

Quando a amostra de calibração é insuficiente, o forecast continua `WITHHELD_INSUFFICIENT_CALIBRATION`. A avaliação posterior preserva o outcome observado como `NOT_EVALUABLE_WITHHELD`; isso comprova que o sistema rejeitou falsa precisão e não significa que se tornou previsível. Quando existir amostra mínima, o challenger de mediana robusta é comparado ao baseline simples de último outcome carregado. Somente erro menor fora da amostra conta como uplift positivo.

Estado de implantação em `2026-09-04`: job da previsão do canário `PENDING` para `2026-09-05T19:12:01.035029Z`; o D1 próprio anterior permanece prioritário em `2026-09-05T18:45:51Z`. Contratos: `schemas/prediction_evaluation.schema.json` e `schemas/phase6_prediction_runtime.schema.json`.

## Scorecard de melhoria

Cada métrica contém baseline, valor atual, delta, direção desejada, janela, amostra, incerteza, custo, efeitos colaterais, versão e status.

### Qualidade do sistema

- acurácia por campo contra gold standard;
- cobertura/proveniência e taxa de schema válido;
- idempotência, replay e isolamento;
- latência, custo, falhas, retries e recuperação;
- regressões e incidentes por versão.

### Qualidade do conteúdo

- fidelidade ao arquétipo sem cópia de identidade;
- coerência embalagem-promessa-hook-payoff;
- retenção por janelas e função de take;
- direitos, originalidade editorial e quality gate;
- desempenho champion/challenger com coortes comparáveis.

### Resultado operacional/comercial

- throughput e tempo por vídeo;
- custo por vídeo e por resultado válido;
- taxa de aprovação, bloqueio e retrabalho;
- resultados orgânicos e métricas privadas autorizadas;
- diferença entre previsto e observado;
- escala somente após gates e repetição.

Melhoria só é afirmada quando o delta é mensurável, a incerteza e os trade-offs estão explícitos e nenhum gate crítico regrediu.
