# Arquitetura contratual — Gestor Central Autônomo

## Princípio de comando

Existe um único Gestor Central ativo. Toda ação percorre:

`objetivo -> estado/evidência -> decisão -> policy gate -> comando idempotente -> executor -> artefato -> resultado -> ledger -> avaliação`

Módulos não podem criar uma segunda estratégia, promover regra, alterar prioridade global ou escrever memória sem passar pelos contratos do Gestor.

## Fonte única de verdade

O piloto usará SQLite enquanto suficiente, com interfaces que não prendam o domínio ao banco. A fonte operacional deve conter:

- estado global da operação;
- estado isolado por canal;
- objetivos, orçamento, capacidade e envelope aprovados;
- ledger append-only de observações, comandos, aprovações, resultados e incidentes;
- fila central de tarefas e prioridades;
- checkpoints, retries limitados e dead-letter queue;
- versões de pipeline, conhecimento, regras e schemas;
- previsões prévias e outcomes;
- lock de gestor ativo com lease renovável;
- trilha completa de auditoria.

Markdown e relatórios são projeções humanas; nunca a única fonte operacional.

## Mapa de administração

| # | Área sob gestão central | Executor subordinado | Evidência de saída |
|---:|---|---|---|
| 1 | Objetivos, restrições, orçamento e capacidade | Portfolio/cost planner | objetivo, envelope e decisão |
| 2 | Observatório e atualização das referências | Market Observer | eventos e snapshots públicos |
| 3 | Priorização de nichos, canais, formatos, temas e oportunidades | Portfolio/modelador | ranking com evidência e risco |
| 4 | Mineração vídeo/frame/take e quality control | Minerador/evaluator | artefato e benchmark por campo |
| 5 | Hook, embalagem, narrativa, retenção, ritmo e produção | Analisadores | claims ligados a timecodes/frames |
| 6 | Vencedores, medianos e fracos | Cohort Builder | coorte normalizada e contraexemplos |
| 7 | ChannelDNA, arquétipos e regras de geração | Modelador | modelo/versionamento/limites |
| 8 | Planejamento editorial e calendário multicanal | Planner | plano por canal e capacidade |
| 9 | Títulos, thumbnails, hooks, roteiros, blueprints e variantes | Creative executors | variantes e previsão prévia |
| 10 | Ativos permitidos, montagem, QA e pacote de publicação | Library/montador/QA/publisher | manifesto, render, gates e pacote |
| 11 | Filas, agenda, dependências, retries, falhas e reprocessamento | Orchestrator | comando, checkpoint e receipt |
| 12 | Métricas públicas e privadas autorizadas | Observers | observações validadas e escopadas |
| 13 | Atribuição às versões exatas dos elementos | Feature Builder | feature snapshot e pipeline version |
| 14 | Geração e prioridade de hipóteses | Hypothesis Engine | hipótese pró/contra e falsificação |
| 15 | Desenho e acompanhamento de experimentos | Experiment Planner | plano, aprovação, janela e resultado |
| 16 | Diagnóstico, otimização e aplicação de regras | Decision/Evaluator/Application | regra, transição e aplicação futura |
| 17 | Custos, produtividade, gargalos e capacidade | Cost/capacity monitor | scorecard e alertas |
| 18 | Isolamento de canais, nichos, identidades e ativos | Scope/Policy Gate | bloqueios e teste de não vazamento |
| 19 | Versões, memória, auditoria, segurança e rollback | Store/Audit/Security | ledger, versões e rollback |
| 20 | Previsões, confiança, incerteza e relatório ao proprietário | Predictor/Reporter | forecast, calibração e síntese |
| 21 | Evolução dos módulos subordinados | Benchmark/champion-challenger | regressão, promoção ou rejeição |

## Estados centrais

### Operação

`BOOTSTRAPPING -> READY -> RUNNING -> DEGRADED -> PAUSED -> RECOVERING -> STOPPED`

Transições exigem motivo, ator, versão e evento. `DEGRADED` não libera ações protegidas. `PAUSED` impede novos comandos, salvo diagnóstico e recuperação autorizada.

### Comando

`PLANNED -> POLICY_CHECK -> BLOCKED | AWAITING_APPROVAL | QUEUED -> CLAIMED -> RUNNING -> SUCCEEDED | FAILED_RETRYABLE | DEAD_LETTER | CANCELLED`

Um `idempotency_key` identifica a operação lógica. Retentativas nunca geram publicação, gasto ou artefato duplicado.

### Ação protegida

`PROPOSED -> AWAITING_OWNER -> APPROVED | REJECTED | EXPIRED -> EXECUTED | FAILED`

Quem propõe ou executa não pode forjar a aprovação. Aprovação registra escopo, validade, limites e proprietário.

### Aprendizado

`CANDIDATE -> TESTING -> SUPPORTED_LOCAL -> TRANSFER_CANDIDATE -> SUPPORTED_GENERAL`

De qualquer estágio aplicável: `INCONCLUSIVE`, `SUSPENDED` ou `REJECTED`. Promoção exige critérios configurados; regressão pode rebaixar/suspender sem apagar histórico.

## Concorrência, continuidade e recuperação

- Um único lock renovável identifica o Gestor ativo. Na Fase 5/Windows, isso está implementado com byte-range lock não bloqueante do SO, heartbeat e lease versionado; o segundo processo termina fail-closed com `BLOCKED_DUPLICATE_MANAGER`/73, sem executar ciclo nem publicador.
- Claim de comando é atômico e possui lease; lease expirado permite recuperação controlada.
- Todo executor recebe entrada imutável, versão e idempotency key.
- Cada etapa conclui com receipt; falha recuperável tem limite e backoff; excedido vai para dead-letter.
- Checkpoints permitem retomar sem repetir efeito externo.
- Replay usa eventos históricos e a mesma versão para reproduzir a decisão.
- Rollback cria nova versão compensatória; histórico nunca é apagado.

O início automático vigente usa uma tarefa agendada no logon com `MultipleInstances=IgnoreNew`, três tentativas de reinício e custo técnico zero. O lock do SO continua sendo a autoridade de exclusão, pois configuração do agendador não substitui proteção no domínio. A verificação materializada correlaciona tarefa, PID, lock e estação local de revisão antes de declarar o runtime operacional.

## Isolamento

Toda entidade possui `operation_id`, `channel_id`, `scope` e versão. Consulta ou comando sem escopo explícito deve falhar. Regra de outro canal entra somente como `TRANSFER_CANDIDATE`; ativos, identidade, credenciais e dados privados nunca são compartilhados automaticamente.

## Compatibilidade com os gates existentes

O Gestor não substitui o usuário na aprovação de fase e não pode alterar silenciosamente direitos, política, custo, identidade ou schemas estáveis. O Policy Gate aplica primeiro as regras permanentes, depois a fase e por fim o envelope operacional. A regra mais restritiva prevalece e o conflito é escalado.

## Contratos draft desta revisão

- `schemas/central_manager.schema.json`;
- `schemas/central_command.schema.json`;
- `schemas/operational_envelope.schema.json`;
- `schemas/learning_cycle.schema.json`;
- `schemas/prediction_record.schema.json`;
- `schemas/improvement_scorecard.schema.json`;
- `schemas/mining_benchmark.schema.json`.

Esses schemas são propostas em `AWAITING_REVIEW`; ainda não são contratos de runtime aprovados.
