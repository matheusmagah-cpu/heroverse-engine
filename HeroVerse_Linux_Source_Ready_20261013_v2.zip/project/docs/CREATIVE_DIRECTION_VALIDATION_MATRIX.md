# Matriz de validação por macrofamília

## Unidade de validação

Cada célula aplicável produz fixture, hash, versão, parâmetros, custo/tempo, relatório automático e revisão humana. `N/A` exige justificativa; não é PASS implícito.

| Macrofamília | Estática | Sequência | Curto | Longo | Personagem | Cenário | Movimento | Texto | Voz | Música | Híbrido | Final |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Realismo/cinematografia | R | R | R | R | R | R | R | R | R | R | R | R |
| Documentário/jornalismo | R | R | R | R | C | R | R | R | R | R | R | R |
| UGC/POV/câmera simulada | R | R | R | C | R | R | R | R | R | C | R | R |
| Cartoon/2D | R | R | R | R | R | R | R | R | R | R | R | R |
| Anime/mangá/webtoon | R | R | R | R | R | R | R | R | R | R | R | R |
| Animação/3D | R | R | R | R | R | R | R | R | R | R | R | R |
| Arte tradicional simulada | R | R | R | C | C | R | R | R | R | R | R | R |
| Design/infográfico/motion | R | R | R | R | C | R | R | R | R | R | R | R |
| Estéticas temáticas | R | R | R | R | C | R | R | R | R | R | R | R |
| Baseado em recortes | R | R | R | R | C | R | R | R | R | R | R | R |
| Baseado em imagens | R | R | R | R | R | R | R | R | R | R | R | R |
| Baseado em vídeo | C | R | R | R | R | R | R | R | R | R | R | R |
| Híbrido | R | R | R | R | R | R | R | R | R | R | R | R |
| Conteúdo curto | R | R | R | C | C | C | R | R | R | R | R | R |
| Conteúdo longo | R | R | C | R | C | R | R | R | R | R | R | R |
| Contínuo/ambiente/musical | R | R | C | R | C | R | R | C | C | R | R | R |

Legenda: `R` obrigatório; `C` condicional ao pack.

## Bateria mínima por modalidade

### Imagem estática

- resolução, nitidez, composição, iluminação, cor, anatomia, mãos/rostos, texto/safe area, direitos e aderência ao pack.

### Sequência e recorrência

- identidade, idade, proporção, roupa, objetos, cenário, paleta, iluminação, eixo, escala, tempo e deriva de estilo.

### Movimento/vídeo

- flicker, deformação, fundo pulsante, física, câmera, optical flow, frames duplicados, ghosting, interpolação, compressão e continuidade do corte.

### Áudio

- identidade de voz, pronúncia, velocidade, pausa, emoção, sync, ruído, EQ, compressão, normalização, ducking, clipping, loudness, trilha/SFX e direitos.

### Hook

- verificação separada em `0–1`, `1–3`, `3–8` e `8–30 s`; promessa, informação, mudança visual/sonora, legibilidade e primeiro micro-payoff.

### Render final

- fidelidade ao blueprint, variedade, repetição, narrativa, plataforma, todos os gates e revisão humana em reprodução real.

## Promoção e regressão

- `PROTOTYPED`: uma amostra completa, ainda reprovável.
- `VALIDATED`: matriz aplicável passa em fixture e revisão humana.
- `PRODUCTION_READY`: replay/regressão, perfil STANDARD e operação de fallback passam.
- toda nova versão do pack/pipeline/tool reexecuta testes impactados;
- regressão crítica rebaixa ou bloqueia; histórico nunca é apagado.

## Ordem progressiva

1. clip-based long-form do HeroVerse;
2. sequência de imagens e híbrido no mesmo canal, como challenger controlado;
3. short-form somente com arquétipo e padrão-ouro próprios;
4. 2D/infográfico;
5. realismo/geração com personagem recorrente;
6. 3D e famílias de maior custo;
7. generalização multicanal e produto na Fase 8.

Essa ordem é prioridade de validação, não declaração de suporte.
