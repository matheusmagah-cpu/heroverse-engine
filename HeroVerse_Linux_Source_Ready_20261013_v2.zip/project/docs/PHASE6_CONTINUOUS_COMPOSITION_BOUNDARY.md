# Composição contínua — fronteira de implementação

Estado: READ_ONLY_AUDIT / nenhuma mídia, tempo ou contagem produtiva aprovada.
Complementa a proposta original e o candidato executável a9a1f4e…/871d03d0…;
ambos permanecem intactos. Auditor independente: control_worker_finish.

## O agrupamento editorial é hipótese, não resultado

A032–033, A035 e A047–049 são candidatos a três ocorrências do caminho de
estações. B036–038 pode ser um registro documental contínuo. C015–018 pode
ser um objeto de mensagem contínuo. Isso não cria cinco fontes nem autoriza
contar três/uma/uma sem mídia, intervalos e observação. B ainda necessita
receita espacial concreta para retirar/introduzir documentos em037s01 e038;
um arquivo único com cortes de cartelas continua contendo esses cortes.

O HOLD016s01 não cria novo evento. O painel034 permanece separado e íntegro.
Preservar as strings/entradas/focos/objetos já determinados no candidato.

## Contratos existentes e limite real

| Camada | Contrato real | O que não prova |
|---|---|---|
| A | render_span pode conter vários fragment_ids, com eventos internos | Cobertura/qualidade de cada estado e calibração lexical |
| B | Fonte/hash e intervalos exatos de cada span | Direitos/PUBLICITY de intervalos omitidos pelo agrupamento |
| C | Arquivo por span, concatenação ordenada e áudio contínuo | Continuidade editorial por existir um arquivo único |
| D/quality legado | Allocation por take, reuso/adjacência por asset_origin | Ocorrências contínuas do novo modelo AV |

phase6_release.py966 incrementa a contagem por take alocado e usa inícios
dos takes no rolling60. qa_phase5.py259 compara asset_origin na adjacência.
phase6_quality.py736 consome essas medições. O derivado AV_SPAN_TAKE_PLAN
não é substituto silencioso do TakePlan antigo (phase6_av_timeline.py1357).
Nenhum desses consumidores foi alterado nesta auditoria.

A permite separar fragmentos e spans (PHASE6_AV_SUCCESSOR_IMPLEMENTATION.md156).
O adapter de duas colunas242 demonstra o protocolo de estados/HOLD, mas não
é compositor das propostas atuais. C termina COMPILED_FIXTURE_NOT_EXECUTABLE
ou BLOCKED_INCOMPLETE (phase6_av_render_recipe.py809), não produção pronta.

## Requisitos do consumidor audiovisual sucessor

- Contrato versionado distingue fragmento narrativo, estado, segmento físico,
  composição, componentes ancestrais e ocorrência visual realmente contínua.
  Não aceitar flags, span_id ou nome de arquivo como prova de continuidade.
- Manter os thresholds atuais. Calcular participação pela exposição real,
  incluindo pausas/overlays visíveis; nenhuma diluição por silêncio artificial.
- Conservar grade global30fps/800samples, PCM e spans contíguos, sem gap,
  overlap, estiramento ou fragmentos fora de seus slots (A731).
- Cada estado precisa de subintervalo explícito, copy, objetos/foco e HOLD.
  Revelações lexicais continuam dependentes das âncoras calibradas.
- Conferir continuidade dentro do span e nas emendas físicas. Um mesmo encode
  pode conter várias ocorrências/fontes; não fundi-las por contêiner.
- C617 exige concatenação ordenada e master contínuo, sem reiniciar áudio/EQ
  por take. Captions mantêm seu próprio contrato temporal.
- B265 conserva direitos/PUBLICITY por caminho/hash e intervalo exato, sem
  eliminar cobertura ao unir unidades. Componentes antigos continuam na
  contagem de ancestralidade; transparência ou novoID não ocultam exposição.
- D exige QA independente de movimento, continuidade, legibilidade, áudio,
  narrativa e render final. Não promover observação estrutural a percepção.

## Done when do próximo incremento

Contrato e fixtures adversas diferenciam uma composição realmente contínua
de cortes/reinícios encobertos por agrupamento; consumo rejeita omissões,
ancestralidade divergente e falsoPASS. Depois, prova de mídia/contexto/tempo
aplicável e integração versionada aos consumidores, sem alterar legados.
Sem fontes, clocks e observação, o status permanece CANDIDATE/NOT_EVALUATED.
Esta auditoria não remove59estados pendentes, calibração, áudio, GC01 ou Fase6.
