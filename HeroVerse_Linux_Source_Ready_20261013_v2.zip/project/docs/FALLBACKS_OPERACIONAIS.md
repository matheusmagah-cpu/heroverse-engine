# Fallbacks operacionais — D-170

CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.

## Recuperação OAuth observada; correção do loop ainda não instalada — 08/09 12:48UTC

Diagnóstico único delimitado e retry separado do mesmo grant recuperaram
identidade do canal em12:38:39Z, proof0012c76c…; um débito da cota gratuita,
zero upload. RETRY_SAME_PROVIDER, não PROVIDER_SWITCH; não repetir a prova.
FAIL anterior preservado e causa original ainda desconhecida. O watcher que
podia esperar30dias foi corrigido para passagem única;11focaisPASS, adoção
pendente de manutenção/D116/novo ciclo. Fonte ausente é WAIT e não recuperação.
Grant igual não pode substituir token recente por cópia histórica. Detalhes:
output/qa/phase6/diagnostics/oauth-refresh-diagnostic-review-v1/verification.md
e oauth-watcher-unblock-v1/focal-tests-verification.md. Isso não encerraFase6.

## Recuperação adicional observada, ainda isolada — 08/09 10:45UTC

O controle de detectorV2 executou positivo/negativo, mas falhou no agregador
por uma origemPython vazia e pelo inventário incompleto do receipt do supervisor.
O sucessor recuperou as provas persistidas sem repetir inferência/decode/rede:
receiptf477c45b… em27,965s e consumidor092a9b em24,123s. Falhas originais
preservadas; status PASS_OPERATIONAL_CONTROLS_ONLY / CHECKPOINT_RECOVERY.
Os arquivos exatos e testes estão em
output/qa/phase6/diagnostics/phase6-av-publicity-clock-fix-v1/control-worker-execution.md.

Esta recuperação é própria daquele checkpoint, não dispatcher genérico ou
PROVIDER_SWITCH. O código novo ainda não está instalado no Gestor/consumidores
de produção. Não aumentar a cobertura produtiva do painel20rotas/17domínios
por esse ensaio, nem converter sucesso operacional em calibração/publicity.

## Estado verificado em 07/09/2026, 17:22 UTC

Este lote foi implementado, testado e instalado. **A operação integral e o Vídeo 2
continuam pendentes; não há fallback universal ou fornecedor alternativo validado.**

| Prova | Resultado |
|---|---|
| Regressão completa | 1.293 casos: 1.292 PASS, 1 skip, zero falha/erro |
| Tempo | 1.192,355s do unittest; 1.200,796141s do processo |
| Contratos | 170 schemas; inventário de testes coincide com execução |
| Integridade | 554 itens, 3.080.086.312 bytes |
| Recuperação | Gestor PID14280→5292, sem erro, tarefa Running |
| Ciclo após reinício | 12/12 estágios, schemas válidos, PASS_WAITING |
| Preservação | Fila, quota, efeitos e provas OAuth inalterados |
| Efeitos da manutenção | Zero API externa, publicação ou custo adicional |

O único skip é o teste de symlink impedido por WinError1314 no ambiente, não um
teste aprovado. A primeira rodada falhou e foi corrigida; seus logs permanecem.
O painel registra 20 rotas/17 domínios: 3 replays de cache, 8 recuperações de
checkpoint, 3 retries, 3 adiamentos e 3 bloqueios. As fontes das20rotas foram
localizadas; esse mapa não certifica execução nem converte DEFER/BLOCKED em sucesso.

Evidências permanentes:

- Run: `output/runtime/gestor-central/maintenance-runs/maintenance-request-20260907T1658260158096Z-21c0c601/`.
- `final-receipt.json`: manutenção9b618b19, SHA `f3f80ac1fb0d09e7fd7bfed7bc5877030026dd5023859597e990d79ef02a9b1c`.
- `regression-receipt.json`: regressão6d1a8a5b, SHA `f22b555e9008d6224d27845a15bb565e1368711580183ea95617ee863f5d8819`.
- D116: `output/operations/phase6/post-maintenance-verification/history/phase6-post-maintenance-321a08451c5fe5d9f204c25c.json`.
- Snapshots D116: `output/operations/phase6/post-maintenance-verification/source-snapshots/phase6-post-maintenance-321a08451c5fe5d9f204c25c/`.

Arquivos de código alterados/criados: `hero_engine/operation_fallbacks.py`,
`hero_engine/phase6_reporting.py`, `hero_engine/phase6_media.py`,
`hero_engine/phase6_channel_goal_observer.py`, `hero_engine/mining/pipeline.py`,
`hero_engine/asset_library_phase5.py` e `hero_engine/audio_perception_supervisor.py`.
Schemas de painel/trajectória e testes correspondentes também foram atualizados;
fonte compartilhada de mineração registrada no receipt de evolução da Fase6.
`AGENTS.md`, `PLANS.md`, `docs/STATE.md`, `docs/DECISIONS.md` e o protocolo de
execução registram a incorporação. Não foram instaladas ferramentas pagas nem
alteradas credenciais ou mídias aprovadas.

Este requisito é transversal e aditivo. Não troca a fase ativa, o ChannelDNA, a
variável pré-registrada, as fontes oficiais nem os gates. A execução de fases
seguintes permanece sequencial. Não há autorização de gasto, autenticação pessoal
automática ou publicação de um artefato reprovado.

## Contrato de recuperação

Cada executor deve conservar a identidade do trabalho, o motivo original da falha,
os bytes rejeitados, a tentativa, a cota e os efeitos já confirmados. Recuperação
nunca significa inventar um resultado para permitir que o próximo estágio avance.

| Mecanismo | Significado | Limite |
|---|---|---|
| EXACT_CACHE_REPLAY | Reabrir e conferir prova do mesmo trabalho | Mudança de entrada, receita ou bytes invalida o reuso |
| CHECKPOINT_RECOVERY | Retomar a partir de efeito/estado persistido | Não reabrir terminal nem duplicar efeito externo |
| RETRY_SAME_PROVIDER | Nova tentativa limitada da mesma operação | Deadline, espaçamento, teto e cota por tentativa |
| PROVIDER_SWITCH | Executor alternativo comprovadamente equivalente | Só após validação de qualidade, direitos, identidade e custo |
| DEFER | Preservar o trabalho e aguardar condição legítima | Não contar como recuperação funcional |
| BLOCKED | Falta capacidade ou evidência necessária | Não contar como fornecedor alternativo |

Nenhuma troca equivalente de fornecedor está sendo anunciada como validada nesta
entrega. Isso é uma lacuna explícita, não uma afirmação de que todos os fallbacks
imaginados já existem.

## Incorporação real

O painel executivo da Fase 6 passa a incluir `fallbacks`, no schema 1.5. O módulo
`hero_engine/operation_fallbacks.py` recompõe a cobertura lendo apenas arquivos
locais de código limitados, sem importar ou executar os handlers. Registra os
hashes, a função, o mecanismo, o gatilho, os limites e as lacunas. O Markdown do
painel recebe a mesma cobertura.

São 20 rotas em 17 domínios: autenticação, mineração, aquisição de ativos, direção
criativa, voz, render, áudio/QA, vídeo/QA, capacidade local, persistência,
orquestração, publicação, embalagem do canal, Analytics, aprendizado, custo zero e
capacidade de desenvolvimento. As rotas são descrições vinculadas aos executores
existentes, não um dispatcher que faz substituições silenciosas.

`SOURCE_BOUND_NOT_EXECUTION_PROOF` significa somente que o handler e seus bytes
foram localizados. `NOT_ATTESTED_BY_THIS_VIEW` impede confundir essa observação com
teste aprovado, recuperação observada ou capacidade produtiva. O painel não
executa regressão a cada ciclo. As provas de teste e recuperação são registradas
separadamente nos receipts de teste/manutenção.

Os 12 estágios do ciclo continuam os mesmos. A cobertura entra em
`EXECUTIVE_VIEW`; não cria um décimo terceiro estágio, não muda a identidade
histórica dos estágios e não autoriza render ou publicação. Os schemas 1.0–1.4
permanecem aceitos como legados sem o campo novo. Nova execução gera 1.5 e exige
o campo. Falha do escritor atômico preserva os arquivos/alertas anteriores.

## Correções executáveis desta entrega

1. **Cache de segmentos:** `resolve_phase6_segment_cache` é chamado pelo próprio
   `render_video2`. Um ponteiro ausente só é reconstruído a partir de âncora e
   receipt íntegros, confrontados com fonte, intervalo, receita e saída. Ponteiro
   corrompido, arquivo órfão, origem alterada ou evidência incompleta bloqueiam
   antes de render. O comando para saída nova usa FFmpeg `-n`. Eventos persistem
   recuperação e falhas sem substituir a avaliação da mídia.
2. **Observador oficial diário:** deadline monotônico compartilhado por discovery
   e leitura, configurado em no máximo 240 segundos, com timeout de transporte de
   até 30 segundos limitado ao saldo. Uma execução da leitura por tentativa,
   após preflight de uma unidade. A falha percorre o retry existente de 30 minutos,
   máximo seis horas/12 tentativas. A recuperação de leitura arquivada não repete
   discovery/API. Contagem oculta permanece indisponível. Esse mecanismo não é um
   watchdog capaz de matar qualquer chamada nativa travada fora do transporte.
3. **Cache de mineração de fixtures:** corrigida aceitação de `COMPLETE` com
   inventário vazio/incompleto. A prova corresponde ao contrato real do run,
   sem apagar outputs ou executar novamente ASR/OCR para compensar uma falha de
   integridade. O módulo pertence à validação histórica da Fase 2; não se anuncia
   como mineração contínua de mercado.
   Jobs parciais/FAILED/RUNNING ficam preservados com
   `CACHE_RECOVERY_PROOF_REQUIRED`: não há contrato suficiente para retomar seus
   checkpoints não pinados. Isso restringe explicitamente a antiga retomada
   permissiva; não é anunciado como recuperação automática validada. Novas chaves
   de código não substituem os runs históricos na regressão.
4. **Espera do Commons:** implementada interpretação de `Retry-After`
   tanto em segundos quanto em data HTTP. Uma espera maior que o orçamento local
   deve encerrar a tentativa com DEFER e conservar ativos/manifest, nunca adiantar
   a chamada. A resposta deve ser fechada antes da espera. O limite vale para o
   build corrente; não se anuncia cooldown distribuído entre processos.
5. **Quota entre consumidores:** `QUOTA_WAIT` já existia no observador, mas era
   rejeitado pelos schemas de trajetória e painel. As duas enums foram corrigidas
   sem outros valores, permissões ou métricas. Cinco testes comprovam o fluxo
   real entre os três componentes, quota desconhecida/esgotada, ausência de API,
   dados indisponíveis preservados e replay sem duplicar o job.

## Testes de aceite

- Ponteiro ausente recupera sem subprocesso; segunda passagem é idempotente.
- Fonte, saída, receipt, âncora, número JSON ou intervalo adulterados bloqueiam.
- Corrida ou erro de escrita conserva a evidência e não sobrescreve a saída.
- Entrada real do renderer não executa FFmpeg quando o cache está corrompido.
- Discovery consome o mesmo orçamento; timeout entra em retry, não em sucesso.
- Não há chamada extra sem cota, para contador oculto ou para leitura recuperada.
- Inventário de mineração ausente/vazio, duplicado, externo ou divergente não é hit.
- Cobertura não toca rede, processo, credencial, fila ou mídia; fonte ausente não
  aparece como implementada e presença de código não aparece como teste PASS.
- Schema atual e legados mantêm custo zero e autorização de publicação falsa.
- Regressão integral e D116 verificam parada/recuperação do Gestor e novo ciclo
  12/12, com falhas/skip explicitamente discriminados.

## Lacunas que um fallback não resolve

- Calibração temporal aplicável, pronúncia/prosódia e integração audiovisual ainda
  não estão aprovadas; nenhum cache, ASR auxiliar ou deadline as substitui.
- Não existe voz, modelo visual ou avaliador alternativo intercambiável validado
  para o vídeo congelado. Mudá-los exige nova identidade e avaliação.
- Cache de fixture e snapshot auxiliar do vidIQ não equivalem a observação atual
  de mercado. O uso de quota gratuita não permite atribuir métricas privadas
  indisponíveis.
- Cota oficial do YouTube, revogação OAuth, disco indisponível, computador desligado
  ou falta de orçamento autorizado não podem ser contornados por outro fornecedor.
- Há chamadas de publicação sem o deadline comum. Não adicionar retries cegos em
  operações mutáveis: primeiro reconciliar efeitos e o ID já criado.
- O cliente do Commons respeita `Retry-After` durante o build, mas ainda não há
  cooldown persistente entre processos; orçamento de espera não é deadline total
  do download ou limitação de tamanho durante streaming.
- Fases 7–8 e suporte produtivo ampliado continuam sujeitos a seus gates.

## Operação e recuperação

### Correções verificadas antes do reteste

Runway: 15 testes PASS em 0,730s, usando fixture completa e hash-pinned em vez
da configuração atual da conta. Supervisor v2: job explícito e associação
verificada sob o launcher do venv, limites preservados e fechamento antes da
medição. Lotes focais distintos: 24 PASS, 2 novos PASS e 2 retestes PASS. Receipt
`output/qa/phase6/diagnostics/audio-supervision-v2/verification-d611672e5269ae19c6685ae1.json`.
Essas correções estão congeladas para a nova regressão; não substituem seu resultado.

### Primeira contraprova integral — 07/09/2026

O run `maintenance-request-20260907T1452574048183Z-2f7de15f` executou1282testes
em1191,112s:1271PASS,5FAIL,5ERROR e1skip. O lote não passou. A recuperação do
Gestor funcionou (PID6660→14280; recovery_failure=null), sem converter o erro em
aprovação. Oito casos dependiam de datas fixas combinadas com a policy viva
pós-reset; dois expuseram diferença de Job Object no launcher do venv. As
correções preservam evidência, limites e critérios; focais usarão o mesmo
intérprete da manutenção antes da nova regressão. Logs e recovery-outcome estão
no diretório desse run em `output/runtime/gestor-central/maintenance-runs/`.

O Gestor continua sendo a autoridade operacional. O painel JSON/Markdown é
atualizado pelo estágio executivo existente. Para mudanças de código, usar a
manutenção já prevista em `scripts/daily.ps1`, com snapshots estáveis, regressão e
recuperação em `finally`. Não parar processos por nome nem remover locks para
forçar passagem. Rollback restaura somente as fontes novas identificadas,
mantendo receipts e mídia históricos; nenhuma restauração acontece sem conferir
o alvo e a compatibilidade do estado.

A conclusão desta entrega requer testes e implantação comprovada. Este documento
não conclui a Fase 6 nem a operação integral.
