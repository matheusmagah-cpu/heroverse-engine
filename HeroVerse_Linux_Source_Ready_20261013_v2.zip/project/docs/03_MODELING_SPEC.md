# 03 — Especificação de modelagem

Regra transversal: YPP-INAUTHENTIC-2025-07-15 em `08_POLICY_AND_RIGHTS.md`.
Modelar mecanismos e relações, nunca obra/voz/identidade da referência. A nova
entrega precisa de substância própria; diversidade de metadados não é variação
material. Comparar o catálogo e registrar evidência contrária, não só vencedores.

## 1. Objetivo

Transformar minerações individuais em uma gramática de canal e de formatos. O modelo deve explicar o que se repete, o que varia, por que provavelmente funciona e como produzir uma nova peça sem copiar uma referência específica.

## 2. Unidade correta de análise

Não modele a partir de um único vídeo. Organize o catálogo em coortes:

- vencedores relativos ao próprio canal;
- desempenho mediano;
- desempenho fraco;
- formatos recorrentes;
- períodos editoriais;
- temas comparáveis;
- vídeos de idade semelhante;
- confirmações em canais independentes.

Use dados normalizados por idade do vídeo, tamanho e mediana histórica do canal. Um número absoluto alto não basta.

## 3. Cadeia causal a modelar

Para cada arquétipo, descreva:

`audiência → desejo → tema → ângulo → embalagem → expectativa → hook → progressão → provas → payoff → satisfação → CTA`

Uma regra só entra no modelo quando houver evidência consistente ou quando for explicitamente marcada como hipótese.

## 4. ChannelDNA

O modelo de canal deve conter:

- público;
- job-to-be-done;
- dor, desejo e curiosidade;
- promessa editorial;
- visão de mundo;
- diferenciação;
- pilares;
- mapa de temas;
- formatos;
- identidade verbal, visual e sonora;
- duração e frequência;
- padrões de embalagem;
- mecanismos de retenção;
- formas de payoff;
- relação entre vídeos;
- comportamento histórico;
- riscos;
- evidências;
- confiança.

## 5. FormatArchetype

Cada formato recorrente possui modelo próprio:

- nome funcional;
- audiência e intenção;
- situações em que deve ser usado;
- assuntos compatíveis e incompatíveis;
- tipo de título;
- tipo de thumbnail;
- promessa;
- hook;
- beat sheet;
- progressão emocional;
- open loops;
- provas;
- micro-payoffs;
- payoff final;
- CTA;
- ritmo;
- tipos de take;
- gramática visual;
- gramática sonora;
- complexidade;
- custo;
- risco;
- exemplos e contraexemplos.

## 6. Invariantes, variáveis e proibições

### Invariantes

Mecanismos cuja ausência rompe o arquétipo. Cada um precisa de evidência em múltiplos casos ou justificativa como hipótese.

### Variáveis

Slots que mudam entre vídeos: tema, personagem, situação, exemplos, recortes, provas, texto, ritmo dentro de faixa, CTA e payoff.

### Proibições

- trechos ou frases exclusivas da referência;
- identidade visual confundível;
- thumbnail derivada por pequenas alterações;
- voz clonada sem autorização;
- ativo sem origem;
- mesma sequência de takes;
- mesmas escolhas narrativas sem nova contribuição;
- promessa não entregue.

## 7. Métricas derivadas

O modelador pode calcular, com fórmulas documentadas:

- `relative_outlier_score`;
- `view_velocity_score`;
- `format_repeatability_score`;
- `cross_channel_validation_score`;
- `evergreen_score`;
- `production_feasibility_score`;
- `originality_opportunity_score`;
- `policy_risk_score`;
- `evidence_confidence_score`.

Pesos são configuráveis. Nenhum score substitui a explicação e as evidências.

## 8. GenerationSpec

O resultado operacional deve dizer como criar uma peça nova:

- inputs obrigatórios;
- pergunta editorial;
- promessa possível;
- estrutura de título e thumbnail;
- regras do hook;
- blocos narrativos com faixas de duração;
- tipos de prova;
- slots variáveis;
- regras de recortes;
- transformação narrativa necessária;
- regras visuais e sonoras;
- critérios de rejeição;
- quality gates.

Faixas de duração devem ser derivadas da distribuição observada. Não hardcode uma fórmula universal para todos os formatos.

## 9. Validação do modelo

Um modelo é aprovado quando:

- explica casos vencedores e também diferenças nos fracos;
- não depende de um único vídeo;
- separa padrão de coincidência;
- contém exemplos e contraexemplos;
- indica evidência e confiança;
- consegue gerar blueprint sem copiar referência;
- sobrevive a revisão humana;
- produz hipóteses testáveis;
- não afirma causalidade quando há apenas correlação.

## 10. Saída

- JSON conforme `schemas/channel_model.schema.json`;
- relatório de ChannelDNA;
- catálogo de FormatArchetypes;
- matriz de evidências;
- regras invariantes, variáveis e proibidas;
- GenerationSpec por arquétipo;
- hipóteses e previsões com confiança;
- limitações e dados necessários para melhorar.

## 11. Relação com o Gestor Central

O modelador não promove regras nem decide escala. Entrega coortes, padrões, contraexemplos, incerteza e hipóteses ao Gestor Central. Toda hipótese começa em `CANDIDATE`; somente experimento autorizado, avaliação, aplicação futura e nova medição permitem promoção. Transferência para outro canal começa em `TRANSFER_CANDIDATE`, mantendo identidade, ativos e dados isolados.

## 12. Aplicação adaptativa

O arquétipo define mecanismos, invariantes e limites; não congela tema, texto, título, thumbnail, visual ou CTA. Na produção, o Gestor combina o arquétipo aprovado com um `DailySignalSnapshot` e um `EditorialBrief` conforme `docs/13_ADAPTIVE_VIRAL_EDITORIAL_ENGINE.md`.

Sinais de alta tração são normalizados por idade, formato e baseline do canal. O modelo não promove regra a partir de views brutas, um viral isolado, convergência apenas lexical ou evidência `METADATA_ONLY` usada como narrativa. Hooks atuais fornecem função e timing; a redação deve ser nova.
