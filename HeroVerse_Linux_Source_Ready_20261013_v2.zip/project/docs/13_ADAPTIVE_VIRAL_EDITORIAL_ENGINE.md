# 13 — Motor editorial adaptativo orientado por sinais virais

Regra transversal: YPP-INAUTHENTIC-2025-07-15 em `08_POLICY_AND_RIGHTS.md`.
Aprendizado otimiza resposta e valor original dentro dos gates, não escala
templates genéricos por views. Cada alteração tem hipótese/variável/evidência
e resultado; métricas privadas ausentes e causalidade incerta ficam explícitas.
Não reabrir entrega válida por agendamento/nome novo; nenhuma melhoria ilimitada
substitui a conclusão do workflow vigente.

## 1. Decisão permanente

O nicho, a identidade do canal, os direitos, a política, a qualidade e a rastreabilidade são fronteiras rígidas. Tema, tensão, ângulo, promessa, embalagem, expressão do hook, ritmo, seleção visual e CTA são decisões adaptativas. Nenhum template criativo vira fórmula eterna.

O objetivo operacional é maximizar, com evidência contemporânea, a probabilidade de resposta acima do baseline. O sistema nunca registra `VIRAL` como garantia. Ele usa `VIRAL_CANDIDATE` somente para uma hipótese pré-publicação e mede o resultado depois com dados próprios.

## 2. O que significa “orientado por visualizações”

Visualizações brutas não são comparadas entre vídeos de idades, formatos ou canais diferentes. Para cada snapshot elegível, o Gestor calcula:

- `age_hours`: idade observável na data de corte;
- `views_per_day`: `view_count / max(age_hours / 24, 1)`;
- `channel_age_band_baseline`: mediana de `views_per_day` de vídeos comparáveis do mesmo canal, formato e faixa de idade;
- `relative_velocity`: `views_per_day / max(channel_age_band_baseline, epsilon)`;
- `robust_outlier_score`: desvio de `log1p(views_per_day)` em relação à mediana, escalado por `1.4826 × MAD`; se `MAD=0`, o campo fica indisponível;
- `engagement_proxy`: curtidas e comentários por mil views, somente quando os contadores estão disponíveis e sem tratá-los como retenção;
- `cross_channel_convergence`: quantidade de canais independentes com o mesmo mecanismo/tema em aceleração;
- `freshness`: decaimento explícito pela idade do sinal;
- `novelty`: distância semântica do catálogo recente do HeroVerse;
- `saturation_risk`: repetição excessiva no mercado ou no próprio canal;
- `evidence_depth`: `FULL`, `OPENING_ONLY` ou `METADATA_ONLY`, preservando os limites de cada classe.

Um vídeo só entra como evidência de alta tração se superar o baseline comparável. Um único outlier não define regra; convergência, coorte e evidência contrária continuam obrigatórias.

## 3. Score de oportunidade editorial

Cada candidato recebe componentes normalizados em `[0,1]`:

`opportunity = 0.28*relative_velocity + 0.16*robust_outlier + 0.12*engagement + 0.12*cross_channel + 0.10*freshness + 0.10*novelty + 0.07*evidence_depth + 0.05*rights_feasibility - penalties`

Penalidades obrigatórias:

- incompatibilidade com o nicho;
- saturação no próprio canal;
- embalagem enganosa ou payoff não demonstrável;
- risco de profecia/factualidade não sustentada;
- dependência de identidade, voz, texto ou obra específica de terceiro;
- ativos sem direitos compatíveis;
- ausência de dados mínimos ou comparação inválida.

Os pesos são versão `viral-opportunity-v1` e são hipótese, não verdade universal. Só mudam por ciclo de aprendizado versionado. Campos indisponíveis são registrados; o peso não é redistribuído silenciosamente. O relatório mostra `score_observed_weight` e cobertura do score.

## 4. Rotina diária do Gestor Central

1. congelar `cutoff_at` e fontes consultadas;
2. coletar/reutilizar snapshots idempotentes dentro do envelope;
3. separar canal, formato, idade e profundidade de evidência;
4. gerar temas/mecanismos candidatos sem copiar frases;
5. calcular score, cobertura, riscos e evidência contrária;
6. eliminar candidatos fora do nicho ou dos gates;
7. registrar pelo menos três alternativas e a razão de rejeição;
8. escolher `champion` e, quando houver base, um `challenger` que altere uma variável principal;
9. materializar `DailySignalSnapshot` e `EditorialBrief` imutáveis;
10. emitir `central_command` e `ApplicationPlan` dentro do envelope;
11. gerar embalagem antes do roteiro;
12. executar gates de hook, narrativa, originalidade, direitos, política e técnica;
13. bloquear publicação e gasto enquanto não houver autorização específica.

Se não houver novo dado, o Gestor registra `NO_NEW_EVIDENCE`. Ele pode escolher pauta evergreen do backlog, mas deve declarar que a escolha não decorre de um sinal viral novo.

## 5. Contrato de embalagem e hook

### Título e thumbnail

- uma promessa combinada, específica e entregável;
- leitura imediata em tela pequena;
- tensão e curiosidade sem esconder a categoria do payoff;
- distância textual e visual de qualquer referência isolada;
- nenhuma alegação factual ou espiritual apresentada como certeza observável sem qualificação;
- variantes avaliadas contra saturação e catálogo próprio.

### 0–1 segundo

- primeira imagem e primeira unidade verbal compreensíveis isoladamente;
- assunto espiritual específico;
- tensão, comando, declaração ou consequência;
- alinhamento semântico com a promessa combinada;
- sem cumprimento, bumper ou contexto frouxo.

### 1–3 segundos

- escalar ou inverter a primeira afirmação;
- tornar a relevância pessoal concreta;
- abrir uma pergunta que o vídeo possa responder;
- introduzir mudança visual ou sonora funcional.

### 3–8 segundos

- provar que o vídeo tem mecanismo e direção, não apenas urgência;
- entregar o primeiro micro-payoff;
- estabelecer a progressão e o custo de não continuar;
- preservar coerência entre título, thumbnail, fala, imagem e payoff.

Urgência, caixa alta, choque ou curiosidade sem entrega não passam. O gate mede propriedades do artefato; resultado viral só pode ser medido após publicação.

## 6. Aprendizado contínuo real

Cada brief referencia regra, versão, evidência, escolha e previsão prévia. Após publicação autorizada em fase posterior, o resultado próprio será comparado ao baseline e ao intervalo previsto. Atualização de regra exige múltiplas observações, evidência contrária e nova aplicação medida. Uma rodada sem resultado não altera pesos, regras ou confiança.

## 7. Critérios executáveis da Fase 5

- o nicho bloqueia candidatos incompatíveis;
- o ranking muda quando os sinais mudam, sem alterar as fronteiras rígidas;
- idade, formato e canal são normalizados antes da comparação;
- três alternativas e rejeições são auditáveis;
- hooks existem nas três janelas e referenciam evidência do arquétipo;
- cópia textual ou identitária é rejeitada;
- dado ausente reduz cobertura e nunca vira zero favorável;
- ativo conflitante, `UNKNOWN` ou `RESTRICTED` é excluído;
- ação externa ou protegida é bloqueada pelo Policy Gate;
- `NO_NEW_EVIDENCE` não promove regra.

