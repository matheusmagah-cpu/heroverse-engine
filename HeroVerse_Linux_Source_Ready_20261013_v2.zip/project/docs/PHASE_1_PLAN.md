# Plano adaptado — Fase 1: padrão-ouro de mineração

## Identificação

- Fase: `1`.
- Objetivo único: produzir um conjunto pequeno de minerações manuais, temporalmente completas, revisadas e válidas conforme `schemas/video_mining.schema.json`.
- Estado atual: `AWAITING_REVIEW`; Fase 1 autorizada, mas pausada antes da aprovação da amostra.
- Prompt autorizado: `prompts/01_GOLD_STANDARD_MINER.md`, condicionado à aprovação dos vídeos exatos e ao acesso legítimo às mídias completas.
- Documentos lidos: `AGENTS.md`, `docs/00_MASTER_SPEC.md` a `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`, `docs/STATE.md`, `docs/DECISIONS.md`, `schemas/video_mining.schema.json`, `templates/GOLD_STANDARD_ANNOTATION.md` e `templates/PHASE_TASK.md`.

## Entradas

- Arquivos: mídias completas e legítimas dos vídeos aprovados; título; thumbnail; transcrição bruta quando disponível; metadados públicos; hash.
- Dados: um conjunto representativo do formato longo de 3–5 minutos, cobrindo ao menos desempenho relativo vencedor, mediano e fraco. A quantidade final será confirmada após medir a variabilidade; a proposta inicial é quatro vídeos, sem tratar isso como regra universal.
- Fontes: catálogo local, links públicos e arquivos autorizados. Os 15 recortes de abertura existentes podem apoiar a seleção, mas não substituem a mídia completa necessária para anotação take por take.
- Credenciais necessárias: nenhuma para arquivos locais; se houver coleta autenticada, definir escopo mínimo antes de usar.
- Direitos/licenças: registrar o estado de cada vídeo. Material `UNKNOWN` pode ser analisado como referência, mas não se torna ativo de produção. O vídeo `5-zdruoQKlM` permanece bloqueado para produção até reconciliar os registros contraditórios de licença.

## Fora de escopo

- automatizar mineração em lote;
- gerar `ChannelDNA` ou arquétipo final;
- criar roteiro, blueprint ou vídeo novo;
- baixar ou reutilizar material sem validação;
- publicar ou alterar o modo `dry-run`;
- definir probabilidade de monetização.

## Entregáveis

| Entrega | Caminho proposto | Formato/schema | Consumidor |
|---|---|---|---|
| Manifesto da amostra aprovada | `data/gold_standard/manifest.json` | contrato próprio mínimo + hashes | auditoria e fixtures |
| Transcrição bruta | `data/gold_standard/<video_id>/transcript.raw.json` | saída preservada do provider | revisão humana |
| Transcrição revisada | `data/gold_standard/<video_id>/transcript.reviewed.json` | segmentos temporais | mineração final |
| Keyframes | `data/gold_standard/<video_id>/keyframes/` | imagens + manifesto | evidências |
| Anotação humana | `data/gold_standard/<video_id>/annotation.md` | template do kit | revisor |
| Mineração estruturada | `data/gold_standard/<video_id>/video_mining.json` | `video_mining.schema.json` | Fase 2 |
| Incertezas e ferramentas | `data/gold_standard/<video_id>/run_manifest.json` | JSON versionado | reprodutibilidade |
| Relatório comparativo | `docs/PHASE_1_REPORT.md` | Markdown | gate humano |

## Alterações previstas

| Arquivo ou componente | Ação | Motivo | Risco |
|---|---|---|---|
| `data/gold_standard/` | criar fixtures e evidências | estabelecer verdade manual | volume de mídia e direitos |
| `schemas/video_mining.schema.json` | preservar; alterar somente após decisão formal | contrato já aprovado no kit | quebra de compatibilidade |
| `templates/GOLD_STANDARD_ANNOTATION.md` | instanciar por vídeo, sem alterar o original | revisão consistente | omissão manual |
| `docs/STATE.md` | atualizar ao encerrar | gate obrigatório | avanço indevido se mal marcado |
| `docs/DECISIONS.md` | registrar escolha da amostra e revisores | rastreabilidade | amostra enviesada |

## Sequência permitida

1. confirmar autorização da Fase 1;
2. apresentar e obter aprovação explícita da amostra;
3. verificar acesso local, hash, duração, idioma e estado de direitos;
4. executar `ffprobe` e preservar o relatório técnico;
5. gerar e preservar transcrição bruta;
6. revisar transcrição sem apagar a saída bruta;
7. gerar candidatos a cortes e keyframes;
8. revisar manualmente todos os limites de take;
9. executar OCR e revisar texto em tela;
10. anotar separadamente `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s`;
11. segmentar narrativa e embalagem;
12. vincular toda conclusão a evidências resolvíveis;
13. validar schema, timecodes e cobertura;
14. comparar os exemplares e relatar divergências;
15. marcar `AWAITING_REVIEW` e parar.

## Testes e evidências

- Testes unitários: conversão de timestamps, cobertura de takes, intervalos, enumerações de evidência e estados de direitos.
- Testes de integração: FFmpeg/ffprobe, transcrição e OCR sobre fixture curta e autorizada.
- Testes de aceitação: validação Draft 2020-12; duração/takes sem sobreposição inválida; quatro janelas de hook para longos; referências de evidência existentes.
- Exemplos reais: somente vídeos aprovados e com acesso legítimo registrado.
- Comparação com padrão-ouro: revisão humana de cada JSON e relatório, com status binário por critério.

## Critérios de aceitação adaptados

- cada JSON valida integralmente contra `video_mining.schema.json`;
- duração técnica e último timecode diferem no máximo pela tolerância documentada;
- `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s` estão preenchidos nos vídeos longos;
- takes cobrem a timeline ou explicam toda lacuna, sem sobreposição inválida;
- cada inferência contém confiança, resumo do raciocínio e evidências;
- transcrição bruta e revisada coexistem;
- todos os arquivos citados nas evidências existem e possuem hash;
- direitos são registrados separadamente e nunca inferidos pela disponibilidade pública;
- revisão humana classifica cada vídeo como `APPROVED`, `REJECTED` ou `NEEDS_CORRECTION`;
- custo financeiro externo permanece zero, salvo aprovação posterior específica;
- usuário aprova o padrão-ouro antes de qualquer Fase 2.

## Riscos e bloqueios

- Riscos conhecidos: seleção enviesada; mídia incompleta; OCR ausente no ambiente; tempo de revisão frame a frame; discrepâncias de licença; possível diferença entre o formato histórico do HeroVerse e o novo formato longo.
- Informações ausentes: mídias completas aprovadas da coorte alvo; thumbnails originais preservadas; identidade do revisor humano; decisão sobre incluir Short no mesmo padrão-ouro ou em tarefa separada.
- Decisões necessárias: vídeos exatos, formato prioritário e resolução do histórico de direitos do ativo já baixado.

## Encerramento previsto

- Resultado: fixtures manuais confiáveis para medir a futura automação.
- Critérios aprovados/reprovados/bloqueados: relatório por vídeo e consolidado.
- Próxima fase sugerida, ainda não autorizada: Fase 2, minerador automático contra as fixtures aprovadas.

## Adaptação proposta — Inteligência Contínua Viva

Status: `AWAITING_REVIEW`; não implementada.

O requisito `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md` não muda o objetivo da Fase 1. Ele acrescenta ao plano um manifesto lateral de proveniência por execução para permitir futura ingestão no Event Ledger sem alterar silenciosamente `video_mining.schema.json`.

Campos planejados para o manifesto:

- `run_id` e chave idempotente;
- escopo de canal, nicho, formato e vídeo;
- timestamps de captura e processamento;
- hashes e referências de todos os inputs;
- versões do schema, pipeline e ferramentas;
- parâmetros, custo/tempo, falhas e limitações;
- classes de evidência e revisão humana;
- links para artefatos bruto/revisado, keyframes, takes e JSON final.

Critérios adicionais propostos:

- duas execuções sobre o mesmo input não podem ser confundidas;
- toda saída deve apontar para uma versão exata de pipeline;
- dados de outro canal não podem entrar no escopo;
- nenhuma observação da Fase 1 pode ser promovida automaticamente a regra aprendida;
- o requisito não libera Event Ledger, Hypothesis Engine, scheduler ou Rule Registry nesta fase.

## Correção do Gestor Central nesta fase

A Fase 1 produz somente o padrão-ouro humano e a proveniência necessária para medir o minerador futuro. Não implementa Gestor, envelope executável, comando, ledger, fila, lock, memória, experimento, previsão ou scorecard. Após aprovação desta incorporação, o próximo gate continua sendo D-012: vídeos exatos e acesso legítimo à mídia completa.
