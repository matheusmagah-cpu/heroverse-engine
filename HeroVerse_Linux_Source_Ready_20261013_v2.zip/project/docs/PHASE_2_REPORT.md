# Relatório de gate — Fase 2

## Resultado executivo

- Estado: `AWAITING_REVIEW`.
- Entrega da fase: `IMPLEMENTADA E VERIFICADA`.
- Promoção do challenger automático: `REPROVADA`; o champion humano foi mantido nas quatro fixtures.
- Fase 3: `NOT_STARTED` e não autorizada.
- Ações externas: nenhuma publicação, upload, gasto, Ads, nova coleta ou alteração de canal.

O minerador automático local existe, executa nas quatro fixtures reais, produz análises válidas com evidência resolvível, mede divergência e falha sem fallback silencioso. Ele ainda não substitui a revisão humana: OCR e segmentação narrativa ficaram abaixo dos thresholds aprovados, e embalagem falhou em uma fixture. O gate não transforma essas lacunas em sucesso.

## Escopo executado

Fluxo materializado:

`CLI -> chave(input + parâmetros + versão + código) -> ffprobe/ASR/takes/keyframes/OCR -> semântica -> contrato -> manifesto -> replay -> benchmark champion/challenger`

O padrão-ouro só foi carregado pelo avaliador depois que cada challenger já existia e havia passado pelo contrato. O builder humano da Fase 1 não é importado pelo minerador.

## Entregáveis

| Entrega | Evidência |
|---|---|
| contrato de análise e benchmark | `hero_engine/contracts/analysis.py` |
| adapters locais substituíveis | `hero_engine/mining/adapters.py` |
| executor idempotente | `hero_engine/mining/pipeline.py` |
| montagem semântica determinística | `hero_engine/mining/semantics.py` |
| avaliador champion/challenger | `hero_engine/evaluation/gold_standard.py` |
| CLI | `hero_engine/cli.py`: `mine-video` e `mine-fixtures` |
| testes | `tests/test_mining_phase2.py` |
| execução ativa | `output/mining/phase2/active_run.json` |
| benchmark agregado | `output/mining/phase2/benchmarks/summary.json` |
| integridade | `output/mining/phase2/integrity_manifest.json` |

## Execução real

| Fixture | Papel | Takes | Keyframes | Imagens OCR | Palavras ASR | Tempo total | Métricas aprovadas | Decisão |
|---|---|---:|---:|---:|---:|---:|---:|---|
| `hkf6nDyUfAM` | vencedor principal | 57 | 171 | 58 | 504 | 315,4473 s | 10/12 | `KEEP_CHAMPION` |
| `_sOy7htXJi8` | vencedor recente | 63 | 189 | 64 | 516 | 324,9299 s | 9/12 | `KEEP_CHAMPION` |
| `Pkede5acSFw` | mediano | 55 | 165 | 56 | 639 | 402,8573 s | 10/12 | `KEEP_CHAMPION` |
| `huvUy3pJSp8` | fraco | 81 | 243 | 82 | 499 | 261,8361 s | 10/12 | `KEEP_CHAMPION` |
| **Total** | conjunto completo | **256** | **768** | **260** | **2.158** | **1.305,0706 s** | — | **4× `KEEP_CHAMPION`** |

Observado: as quatro execuções ativas terminaram `COMPLETE`. Calculado: o tempo total equivale a aproximadamente 21,75 minutos. O valor não é previsão para outra máquina.

## Benchmark campo a campo

| Campo | Média | Fixtures aprovadas | Threshold | Classificação |
|---|---:|---:|---:|---|
| timestamps | 1,000000 | 4/4 | 0,999 | aprovado |
| transcrição | 0,991548 | 4/4 | 0,900 | aprovado |
| OCR | 0,151515 | 0/4 | 0,350 | **reprovado** |
| hooks | 0,793821 | 4/4 | 0,750 | aprovado |
| takes | 1,000000 | 4/4 | 0,900 | aprovado |
| narrativa | 0,287386 | 0/4 | 0,550 | **reprovado** |
| embalagem | 0,745455 | 3/4 | 0,750 | **reprovado em 1 fixture** |
| direitos/proveniência | 1,000000 | 4/4 | 1,000 | aprovado |
| schema/evidência | 1,000000 | 4/4 | 1,000 | aprovado |
| custo externo zero | 1,000000 | 4/4 | 1,000 | aprovado |
| latência | 1,000000 | 4/4 | 0,500 | aprovado |
| consistência | 1,000000 | 4/4 | 1,000 | aprovado |

Houve `0` regressões críticas. Isso significa que o challenger não corrompeu hash de origem, schema, evidências nem gate de direitos; não significa que sua semântica já seja equivalente à humana.

### Leitura correta das reprovações

- OCR: o provider local detectou texto literal em 43 linhas nos takes, mas a cobertura/precisão contra a anotação humana foi insuficiente. O padrão-ouro também não é um dataset OCR exaustivo; essa limitação está registrada no benchmark, mas não foi usada para baixar o threshold depois de ver o resultado.
- Narrativa: o baseline automático usa sinais determinísticos e agrupamento de takes. Ele preserva cobertura e papéis válidos no schema, porém não encontra de forma confiável as mudanças funcionais humanas.
- Embalagem: título e thumbnail são rastreáveis; a composição passou em três fixtures e ficou abaixo do threshold no vencedor recente.

## Hooks

As quatro janelas obrigatórias foram emitidas exatamente como `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s`. A métrica combina janela exata, fala e texto de tela, e passou nas quatro fixtures. Cada hook descreve o mecanismo observado e mantém `promise_break_risk`; não copia a redação do hook como template de produção e não autoriza reutilização do ativo.

## Direitos e segurança editorial

Em 4/4 análises:

- `rights.status = EDITORIAL_REVIEW_REQUIRED`;
- `production_eligible = false`;
- `private_metrics_claimed = false`;
- nenhum disclaimer de fair use foi interpretado como licença;
- nenhuma análise converteu mídia pública em biblioteca de produção.

O minerador analisa mecanismos. Qualquer uso futuro de recorte continua sujeito a origem, licença/permissão, contribuição editorial substantiva e revisão registrada.

## Idempotência, falhas e integridade

- A chave inclui SHA-256 da mídia, parâmetros, versão lógica e hash dos arquivos que implementam o minerador.
- O segundo processamento das quatro fixtures retornou `CACHE_HIT` e o mesmo `semantic_hash`.
- Mudança de parâmetro muda a chave, coberta por teste.
- Arquivo ausente, hash divergente, provider indisponível, schema inválido ou evidência ausente propagam falha; não existe fallback silencioso.
- Checkpoints de ASR, cenas, keyframes e OCR só são reutilizados dentro da mesma chave e após validação mínima.
- O manifesto de integridade cobre 1.076 itens e 21.445.479 bytes com SHA-256.
- Não há repositório Git neste workspace; a revisão de integridade usa manifestos por hash, não um diff Git inexistente.

## Recursos e custo

- custo de API externa observado: `US$ 0,00` nas quatro fixtures;
- providers: FFmpeg/ffprobe, faster-whisper CPU int8, OpenCV, RapidOCR/ONNX Runtime, Pillow e jsonschema;
- pico `tracemalloc`: 205.827.503 a 286.033.027 bytes;
- limitação: `tracemalloc` não mede todo o RSS nativo;
- limitação: energia elétrica e depreciação do hardware local não foram convertidas em moeda;
- nenhuma ferramenta, API ou plano pago foi ativado.

## Gestor Central na Fase 2

O minerador foi implementado como executor subordinado e não como estratégia paralela. Ele emite entrada, versão, parâmetros, código, evidências, custos, latência, resultado e recibo. A decisão de benchmark preserva o champion e não promove automaticamente o challenger.

O runtime central, ledger global, fila, policy gate e autonomia operacional ainda não existem nesta fase. Implementá-los agora violaria o gate das fases posteriores.

## Como o aprendizado foi comprovado

O ciclo mensurável disponível nesta fase é:

1. champion humano versionado;
2. challenger fechado por hash antes da avaliação;
3. 12 métricas por fixture com threshold, amostra, evidência e limitação;
4. decisão automática conservadora;
5. resultado persistido para comparação futura.

Não houve promoção de regra nem alegação de aprendizado generalizado. O resultado atual é evidência de quais campos o minerador já reproduz e quais ainda exigem melhoria.

## Como a previsibilidade foi medida

Nesta fase, previsibilidade significa repetibilidade operacional do minerador, não previsão de monetização:

- mesma entrada/configuração/código -> mesma chave e mesmo artefato;
- latência real por fixture comparada ao orçamento de 3× a duração;
- custo externo observado igual a zero;
- quantidade de takes, frames, OCR e palavras registrada;
- falha e checkpoint auditáveis.

Não existem dados suficientes nesta fase para prever CTR, retenção, receita ou prazo de monetização. Nenhum desses resultados é garantido.

## Critérios de aceitação da fase

| Critério | Estado | Evidência |
|---|---|---|
| execução reproduzível | aprovado | 4/4 cache hits com hash idêntico |
| divergências medidas e expostas | aprovado | 48 resultados de campo, com falhas preservadas |
| nenhuma dependência paga obrigatória | aprovado | custo externo US$ 0,00 |
| falhas explícitas | aprovado | exceções, recibos `FAILED`, testes negativos |
| idempotência | aprovado | chave por input/config/código e replay |
| schema válido | aprovado | 4/4 |
| timecodes consistentes | aprovado | 4/4 |
| hooks obrigatórios | aprovado | 16/16 janelas exatas |
| takes com cobertura | aprovado | 256 takes e 768 keyframes reais |
| evidências resolvíveis | aprovado | 4/4 contratos |
| transcrição bruta preservada | aprovado | 4 artefatos ASR |
| fatos e inferências separados | aprovado | classes `OBSERVED`, `CALCULATED` e `INFERRED` |
| nenhum direito presumido | aprovado | 4/4 bloqueados |
| revisão/aprovação humana das divergências | **bloqueado no gate** | depende do proprietário |

## Lacunas e plano de correção proposto

Sem autorização de nova fase, os próximos challengers da própria capacidade de mineração deveriam:

1. criar ground truth OCR literal e exaustivo separado de descrições editoriais;
2. avaliar OCR em início/centro/fim do take, com normalização e supressão de falsos positivos;
3. substituir agrupamento posicional por detecção de mudança temática, silêncio e função retórica;
4. criar holdout adicional para impedir overfitting às quatro fixtures;
5. recalcular os mesmos thresholds sem apagar os resultados atuais;
6. promover somente se todas as métricas aprovadas permanecerem sem regressão crítica.

Esses itens são proposta, não trabalho autorizado nem resultado concluído.

## Testes

- comando: `.venv\\Scripts\\python.exe -m unittest discover -s tests -v`;
- resultado final: `33/33 PASS`;
- legados preservados: 21 testes das fases/baseline anteriores continuam passando;
- novos: contratos, falhas de provider, chave, quatro runs reais, hooks, keyframes, direitos, custo, cache, benchmark e integridade.

## Gate

`AWAITING_REVIEW`

A Fase 2 para aqui. A Fase 3 permanece não iniciada até decisão expressa do proprietário.
