# Matriz de ferramentas e adaptadores

## Regra

Instalação não equivale a qualidade aprovada. Cada adapter terá contrato conforme `schemas/tool_adapter_profile.schema.json`; `AVAILABLE` significa disponibilidade técnica observada, não validação de um FormatPack.

| Adapter | Categoria | Estado observado | Custo externo observado | Evidência | Limite/fallback |
|---|---|---|---:|---|---|
| `adapter-ffmpeg-local` | edição/composição/áudio/QA | AVAILABLE | US$ 0 | executável FFmpeg N-120725 encontrado | qualidade do render ainda não aprovada; falha bloqueia |
| `adapter-wikimedia-commons` | banco de vídeo | AVAILABLE | US$ 0 | manifesto COMPLETE com 10 ativos e evidência de licença | rate limit; revalidar licença antes de publicação |
| `adapter-pillow-local` | imagem/texto/thumbnail | INSTALLED_UNVALIDATED | US$ 0 | dependência local existente | precisa fixture de safe area, fonte e cor |
| `adapter-opencv-local` | QA visual/análise | INSTALLED_UNVALIDATED | US$ 0 | dependência local existente | detector ainda não calibrado contra gold |
| `adapter-onnxruntime-local` | inferência local | AVAILABLE | US$ 0 | versão 1.29.0 observada | qualidade depende do modelo/adapter específico |
| `adapter-kokoro-local` | voz | BLOCKED | US$ 0 | pacote 0.4.9/modelos locais; erro de dtype no teste | corrigir wrapper e validar voz; não usar em produção |
| `adapter-rapidocr-local` | OCR | LIMITED | US$ 0 | validado no escopo da Fase 2 | não é OCR universal; regressão por tipo de vídeo |
| `adapter-yt-dlp-local` | aquisição permitida/análise | LIMITED | US$ 0 | usado em observatório/mineração | somente acesso legítimo; não concede direitos |
| `adapter-image-api` | geração de imagem | DISABLED_NOT_AUTHORIZED | UNAVAILABLE | nenhuma autorização/custo contratada | local validado ou aprovação expressa |
| `adapter-video-api` | geração de vídeo | DISABLED_NOT_AUTHORIZED | UNAVAILABLE | nenhuma autorização/custo contratada | clip-based permanece principal |
| `adapter-three-d` | 3D | NOT_INSTALLED | UNAVAILABLE | capacidade não verificada | instalar somente em etapa autorizada |
| `adapter-music-provider` | trilha/SFX | BLOCKED | UNAVAILABLE | nenhuma biblioteca comercial aprovada | áudio próprio/licenciado com evidência |
| `adapter-vidiq-web` | pesquisa de mercado | LIMITED | US$ 0 nesta sessão | 4 queries + 12 vídeos em `output/market/vidiq/heroverse/2026-09-03/research-observation.json` | canal não conectado; scores auxiliares; país/ordenação parcialmente indisponíveis |
| `adapter-vidiq-plugin` | pesquisa de mercado | LIMITED | R$ 0 nesta sessão | pesquisa pública, outliers, tendências, comparáveis e títulos em `plugin-observation.json`; bucket 150/55 consumidos/95 restantes | zero canais próprios autorizados; scores não causais; piso 25 e fallback API/cache/local |

## Campos obrigatórios futuros

Para cada adapter: formatos, versão, qualidade observada, custo por unidade, velocidade, limites, direitos comerciais, estabilidade, disponibilidade, privacidade, fallback, evidência e data de verificação.

Ferramenta paga ou API só muda de `DISABLED_NOT_AUTHORIZED` após aprovação de custo, direito, privacidade e envelope. Ferramenta gratuita/local só é escolhida quando passa o perfil mínimo; gratuidade não compensa FAIL de qualidade.
