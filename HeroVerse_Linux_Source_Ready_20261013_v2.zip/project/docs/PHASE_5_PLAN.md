# Plano — Fase 5

## Identificação

- Fase: 5 — Produtor clip-based.
- Objetivo único: construir e validar localmente um vídeo completo do arquétipo aprovado, escolhido por um brief adaptativo orientado por sinais contemporâneos.
- Estado atual: `APPROVED`; `creative-v3.2` passou 22/22 checks, 12/12 gates autônomos e release 13/13. O canário `iK_5edYQtx8` concluiu private-first, thumbnail, captions, processamento, promoção pública e verificação externa com receipt `COMPLETE_PUBLIC`.
- Prompt autorizado: `prompts/04_BUILD_PRODUCER.md`.

## Fora de escopo

- publicar ou agendar antes do gate integral; D-047 autoriza a ação sem gasto somente depois de rights/QA/canal/credencial/receipt, não antes;
- anunciar ou gastar sem orçamento expresso;
- prometer viralização, monetização, prazo ou RPM;
- aprender pesos com resultado inexistente;
- criar arquétipo de Shorts sem mineração audiovisual suficiente;
- usar recorte com licença conflitante, desconhecida ou restrita;
- copiar hook, título, voz, identidade ou sequência de referência.

## Entregáveis

- schemas de sinal diário, brief e aplicação;
- executor adaptativo e Policy Gate;
- snapshot de sinais e ranking com alternativas;
- catálogo e manifesto de ativos elegíveis;
- embalagem, roteiro, blueprint e timeline;
- render de revisão local;
- relatório de gates, custo, tempo e limitações;
- testes unitários, integração e aceitação GC-06 e GC-14 aplicáveis.
- pacote editorial completo, adaptador YouTube e receipt de conexão sem segredo; autenticação não equivale a publicação.
- snapshot e gate de prontidão do canal, auditoria do catálogo legado e receipt de qualquer mudança pública de perfil.

## Critérios objetivos

- direitos: zero ativo `UNKNOWN`, `RESTRICTED` ou conflitante no render;
- originalidade: nova tese, texto, seleção, sequência, identidade e contribuição editorial;
- fidelidade: referências resolvíveis às invariantes do arquétipo;
- adaptabilidade: mudança de sinal pode mudar o ranking sem mudar o nicho;
- embalagem e hook: gates explícitos em 0–1 s, 1–3 s e 3–8 s;
- política: ação externa ou protegida bloqueada e auditada;
- técnica: arquivo reproduzível, áudio inteligível, 16:9, sem quadro preto, corte quebrado ou texto fora de safe area;
- custo externo observado: zero.

## Resultado observado

- FormatPack `fp-broll-cinematic-narration@1.1.0`: `LIMITED`, `production_allowed=true` somente no contrato canário HeroVerse/pipeline/profile/version exatos; não é `PRODUCTION_READY`.
- Baseline v1 preservado: 252,4 s, 599 palavras, 44 takes, 9 ativos usados; rejeitado por execução criativa genérica.
- Render DRAFT `creative-v2.1`: 135,2 s, 331 palavras, 32 takes, 1920×1080, 30 fps, H.264/AAC, 4.056 frames e 13 ativos usados.
- Timeline: 0 ms de erro máximo por take e 0 ms de deriva acumulada.
- Contrato criativo: 11/11 PASS; cinco eventos em 0–8 s; oito em 8–30 s; take corporal máximo 6 s; interrupção máxima 21,3 s; 5/5 ações concretas com prova visual; nenhuma repetição consecutiva fora do hook; maior recorte de terceiro 14,4231%.
- QA: 7 PASS, 9 NEEDS_REVIEW, 1 NOT_APPLICABLE e PUBLICATION BLOCKED; nenhum FAIL automático.
- Defeitos: 7 PASS, 9 NEEDS_REVIEW, 3 NOT_APPLICABLE; nenhum FAIL automático; zero black/freeze e zero corte duro interno detectado.
- Direitos/originalidade: PASS; custo externo: USD 0; custo local financeiro: UNAVAILABLE.
- Evidência: `docs/PHASE_5_REPORT.md` e `output/production/phase5/pilot-001/`.

## Revisão criativa ativa

- Contrato: `docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md`.
- Baseline preservado: `renders/move-after-amen.phase5-draft.mp4`.
- Saída nova: `output/production/phase5/pilot-001/creative-v2/` e render versionado, sem sobrescrever o baseline v1 nem o vídeo v2.0 preservado.
- Gate: melhoria alegada somente com comparação antes/depois, evidência por take/timecode, QA automático e revisão humana independente.
- Autorização posterior: conexão e publicação foram autorizadas condicionalmente pelo proprietário, mas continuam bloqueadas até o gate integral da Fase 5.
- Alteração de ordem D-041/D-043: o proprietário autorizou e concluiu a conexão OAuth. Data API e Analytics estão conectadas ao ID fixado do `@heroverse74`; upload e thumbnail continuam configurados porém bloqueados enquanto os demais gates estiverem pendentes.

## Remediação do canal incorporada

- contrato: `docs/CHANNEL_READINESS_MASTER.md`;
- resultado: `docs/HEROVERSE_CHANNEL_AUDIT.md`;
- descrição, keywords, localização conflitante e Home foram corrigidas e verificadas ao vivo;
- banner/avatar/watermark v2 existem apenas como `PROTOTYPED`, aguardando revisão visual independente;
- 21/21 vídeos públicos foram catalogados para revisão de direitos e originalidade; nenhum foi autoaprovado ou removido;
- o pacote de publicação agora consome o audit e permanece bloqueado com gates críticos abertos;
- capacidade Codex: 98% semanal restante no snapshot; uso não é o gargalo da fase.

## Encerramento

A fase está `APPROVED`. O vídeo público é `https://www.youtube.com/watch?v=iK_5edYQtx8`; receipt, API e oEmbed confirmam canal, título e estado público. A revisão por vídeo é automática e idempotente; a estação humana permanece para padrão-ouro, amostra mínima de 10% e exceções. O FormatPack permanece `LIMITED`, e a Fase 6 iniciou automaticamente para um lote controlado e observação real, sem Ads nem promessa de desempenho.
