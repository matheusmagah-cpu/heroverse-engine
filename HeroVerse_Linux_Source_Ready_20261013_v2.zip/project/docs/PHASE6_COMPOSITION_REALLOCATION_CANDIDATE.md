# Correção de composição — candidata, ainda não materializada

Estado: SPECIFIED_ONLY / sem nova fonte, render, timing ou admissão.
Preservar integralmente A12, V6, rasterizações, direitos e recibos anteriores.
Este plano complementa `PHASE6_VISUAL_FEASIBILITY_CORRECTION.md`.

## O problema não se resolve só com três trechos

A12 possui190.800ms planejados; a banda editorial exige pelo menos207.800ms,
e admite no máximo286.250ms. Nenhum desses números é licença para alongar
pausas, atrasar fala, diluir exposição ou inventar onsets. As contas abaixo
usam somente frame_count PCM24k já registrado, não duração atribuída às PNGs.

Na hipótese full-unit, four-criteria soma979.968samples. Para10%:

| Duração de cenário | Limite de exposição | Redução mínima |
|---|---:|---:|
|190,8s planejados|457.920samples /19,08s|522.048samples /21,752s|
|207,8s piso editorial|498.720samples /20,78s|481.248samples /20,052s|
|286,25s teto|687.000samples /28,625s|292.968samples /12,207s|

Os quatro maiores units somam454.144samples; portanto os dois cenários menores
exigem ao menos cinco unidades integralmente recompostas nesta hipótese.
Os cinco maiores somam532.480samples, mas selecionar só pelo tamanho quebraria
a continuidade de exercícios. No teto bastam três:036–038 somam306.688samples;
isso deixa28,053333s de painel e só funciona a partir de280,533333s totais.
Não adotar esse alongamento como solução. Redução atualmente comprovada: zero.

## Lote coerente proposto para não depender do teto

### A. Três movimentos:032/033/035/047/048/049

São os seis estados de `three-moves-identity-v1`, todos UNIT_ENTRY.
Preservar a identidade Name / Test / Choose em todas as retomadas, a ordem,
os campos vazios e a copy específica de cada estado. **034 fica no painel
de quatro critérios**, incluindo suas quatro revelações lexicais e marcadores.

Receita candidata: caminho horizontal de três estações conectadas, um indicador
de foco e uma área de ação em branco abaixo da estação ativa. A recapitulação
retoma a mesma geometria. Sem grade2×2, contador de quatro critérios, fotografia
genérica, imagem velha com transparência ou troca de ID. Construção vetorial
própria, cores/tipografia da Style Bible e faixa de legendas reservada.
Essa mudança estrutural precisa de amostra e decisão de ancestralidade própria;
não está declarada como nova linhagem validada.

Total condicional retirado de four-criteria:367.104samples /15,296s.

### B. Registro documental:036–038

Seis estados,306.688samples /12,778667s. Receita candidata documental:
documento como objeto central, campos vazios, folhas distintas e anotação
externa, sem a grade/contadores/slots herdados do painel. Nada de resultados,
datas, frases de usuários ou estatísticas fabricadas.

-036: `Action` / `Observed result`, ambos vazios. Stock5190601 só comprova
  um gesto de escrever, não os rótulos, autoria do registro ou seu conteúdo.
-037s00 retoma exatamente o documento036. Em s01, a âncora literal
  `fear edits`[34,44) introduz documento de previsão separado; não renomear
  Action como se já fosse Original prediction. Preservar as duas strings
  de V6 e distinguir o relato retrospectivo sem preencher nenhuma afirmação.
-038 mantém duas áreas de registro sem preencher. Preservar literal_copy
  de cada estado, as duas perguntas e as entradas[39,61)/[72,98). Destaque
  indica pergunta, nunca proteção comprovada, vencedor ou PASS.

Uma eventual implementação comparte identidade dentro deste registro. Não
contabilizar cada folha/PNG/foco como fonte independente. O stock não deve ser
usado como fundo genérico sob a cartela para aparentar redução de exposição.

### Resultado parcial A+B

979.968 −367.104 −306.688 =306.176samples /12,757333s ainda no painel,
correspondentes a019/020/021/034. Sob190,8s, isso fica abaixo19,08s.
As duas receitas candidatas também ficam individualmente abaixo desse teto,
**se** a reconstrução justificar linhagens distintas e a alocação realmente
substituir o painel. Não é autorização para produzir sem essas provas.

## A segunda concentração também precisa de solução

Two-column soma624.128samples /26,005333s. Mesmo com A+B, continuaria acima
de10% em190,8s. A candidata coerente é reconstruir o bloco015–018 inteiro
(323.584samples /13,482667s), mantendo010–014 na demonstração original:
restariam300.544samples /12,522667s de two-column.

Receita a demonstrar: explicador com interface de mensagem fictícia, sem marca
nem pessoa, e previsão claramente atribuída. O objeto deve efetivamente mostrar
ausência de resposta sem inventar conversa ou destinatário. Fact e Fear's forecast
conservam sua relação esquerda/direita; os valores e o HOLD016 permanecem
exatos.017 reconhece a dor sem transformar a previsão em fato;018 encerra a
distinção com as strings exatas. Interface/objeto e ação são elementos centrais,
não decoração dentro da mesma tabela raster. Se a revisão constatar que continua
sendo a mesma composição ancestral, contabilizar como a mesma linhagem e rejeitar
esta alternativa; não renomear para passar. Nada foi desenhado ou aprovado ainda.

## O que permanece obrigatório antes de materializar e adotar

1. Contrato before/after explícito por estado; áudio, textos, ranges lexicais,
   HOLD, perguntas, hooks e união26 preservados. Sem alteração in-place de V6.
2. Demonstrar que as três receitas candidatas são composições tecnicamente reais,
   com autoria/procedência e vínculo de ancestralidade conferidos. Reusar estilos,
   fontes e paleta não autoriza ocultar raster ancestral ou redistribuir fonte.
3. Fechar também os59estados ainda sem vínculo e o orçamento visual global,
   sem confundir esses lotes com cobertura total. Conferir top6≤55%, reuso≤5,
   rolling60s≤3, adjacência0, overlap anterior0 e mínimo12fontes nos tempos reais.
   A aritmética deste documento não testa esses limites.
4. QA próprio de fonte e composição: raster completo/OCR, área segura, entendimento,
   continuidade, direitos/publicity e movimento final. Não herdar QA das PNGs antigas.
5. Scheduling somente com evidência temporal apta, nova timeline versionada e
   consumidores/gates A–D. A proposta não resolve áudio, calibração ou GC01.

## Evidência desta análise

Root leu unidades A12 c38a12e6… e effective_rows V6ba7dabb1… nos comandos
b6c824/f30fd6/02cebc. Nenhum PCM, OCR, render ou preflight anterior repetido.
Revisão independente de Darwin verificou036–038, a impossibilidade de duas
unidades no teto, a identidade dos registros e o risco de jogar a exposição
para two-column. As ampliações A/B/015–018 acima são decisão candidata do root,
não aprovação dada pelo revisor. Números são limites de planejamento condicionais.
