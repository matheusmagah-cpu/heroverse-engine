# Tarefa 2 — cancelamento explícito sob pausa

Data: 08/09/2026. Estado: **CORREÇÃO IMPLEMENTADA E TESTADA EM ISOLAMENTO; CANCELAMENTO REAL NÃO EXECUTADO; OPERAÇÃO PAUSADA.**

Referência: caracterização da Tarefa 1, `MAINTENANCE_ABANDONMENT_FOCAL_RESULT.md`, e incidente `maintenance-request-20260908T1258124421621Z-0e1dac1f`. Nenhuma nova investigação do término histórico do solicitante.

## Alteração limitada

- `hero_engine/maintenance_protocol.py`: entrada explícita `cancel_orphaned_maintenance_paused(root, *, request_id, expected_request_hash, expected_ack_hash)` e auxiliares privados necessários. Sem conexão automática ao Gestor, daily, CLI ou agendador. Sem alteração da primitiva legada de remoção por ID.
- `tests/test_paused_maintenance_cancellation.py`: fixtures temporárias, identidades simuladas, schemas reais e operações nativas Windows sobre arquivos/mutex de teste. Os 15 testes de caracterização ficaram intactos.
- Este registro. Nenhuma configuração, instrução, fila, credencial, dependência ou agendamento alterado.

## Resultado demonstrado

Pausa obrigatória; mesmo mutex de manutenção com aquisição imediata, sem retry; request e ACK fixados por ID e SHA-256 dos bytes completos; schema, ordem temporal e correspondência PID/lock do ACK verificados. Solicitante e Gestor precisam retornar ausência explícita pela sonda existente; identidade incerta ou PID vivo/reutilizado bloqueiam. Nenhuma geração histórica é inventada.

Fila e ledger presentes, tabelas conhecidas, ausência de leases/reservas/efeitos abertos e inventário de efeitos verificável. PAUSE, locks, bancos e recibos ficam preservados. Handles nativos impedem alteração/substituição dos arquivos durante a decisão; a remoção atua no handle exato, não em um caminho reaberto após verificar somente ID.

Evidências, decisão, exclusividade e observações de ausência são arquivadas e reconferidas antes da primeira remoção. Ordem: ACK → request. COMMITTED somente após ambas as remoções confirmadas, revalidação e preservação da pausa. Replay exige arquivo de conclusão e evidências íntegros, mantidos sob handles durante a conferência, sem nova remoção. Request/ACK de outra manutenção permanecem intactos.

Arquivamento incompleto ou interrupção parcial deixam tentativa bloqueada, nunca sucesso inferido de arquivo ausente. Esta correção NÃO implementa retomada de cancelamento parcial, reinício do Gestor ou limpeza automática.

## Testes executados

Todos os comandos abaixo executados na raiz do projeto, sem regressão integral:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_maintenance_abandoned_request.py -v
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_cancellation.py -v
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_cancellation.py -k allowed -k completed -k replay -k expired -k partial_ack -k failure_after -v
```

| Execução | Resultado | Referência do terminal |
|---|---|---|
| Caracterização preservada | 15 PASS / 2,852 s / exit 0 | `682406` |
| Primeira execução da nova fixture | 72 executados / 20 erros / 12,356 s | `31f32b` / `24512d` |
| Nova fixture corrigida | 38 PASS / 4,148 s / exit 0 | `d44eea` |
| Incremento final: 3 novos + 6 diretamente afetados | 9 PASS / 1,792 s / exit 0 | `ef2d84` |

Primeira falha preservada: 19 erros de limpeza por conexões SQLite das fixtures não fechadas e um erro de contrato de exceção para ACK inválido. Corrigidos fechamento das conexões e retorno explícito de bloqueio, sem relaxar critérios. Um alias de TestCase descobriu indevidamente 34 testes existentes de manutenção; todos passaram, sem executar o script daily integralmente. A descoberta foi corrigida, e esses 34 não foram repetidos.

Revisão independente também identificou o conflito de compartilhamento Windows ao tentar reler por caminho um arquivo aberto com acesso DELETE. A leitura foi corrigida para usar o próprio handle antes do lote aprovado. O último incremento acrescentou validação das provas de ausência no histórico e pins no replay; os seis casos afetados foram repetidos, não o lote intacto. O arquivo final contém 41 cenários novos; suas provas vêm dos lotes de 38 e 9, não de uma execução integral fictícia de 41.

Cobertura: permitido/repetição; solicitante vivo/reutilizado/incerto; mesmo ID com bytes diferentes; substituição; ACK inválido ou divergente; lease do Gestor e da fila; reserva e efeito aberto; estados ausentes/desconhecidos; mutex ocupado; proteção nativa contra substituição; falha de arquivo; interrupção após ACK e antes do commit; preservação de substitutos; histórico corrompido ou sem prova de ausência; lease expirado com PIDs ausentes.

## Integridade e limite da evidência

SHA-256 final do protocolo: `5371041e93e4cbad2e98352f8bc65c5f5e070baf751d8e39416e9feabd46fdb3`.

SHA-256 final dos testes novos: `b0f99fb5194d3c9664651fbe3aa9206376ab9178da3b545c8f466612b0be28b4`.

Conferência somente leitura `6987ff`: hashes iniciais e finais iguais para daily, Gestor, teste de caracterização, request real, ACK real, PAUSE real e manager-lock.json real. Não foi executada mutação operacional. Os bancos e o lock físico foram comparados byte a byte nas fixtures, não apresentados como nova auditoria dos bancos reais.

Não houve cancelamento real, reinício, habilitação, OAuth, rede, síntese, render, publicação, instalação ou aprovação de implantação. Arquivos temporários dos testes foram encerrados; resultados persistentes desta rodada estão neste registro e nos terminais referidos. Teste com identidades simuladas não prova a causa da saída do processo histórico nem a elegibilidade atual do incidente real.

## Entrada para futura aplicação controlada

Fornecer raiz explícita, request_id e hashes `sha256:<64 hex>` do request e ACK exatos, obtidos por conferência controlada externa à função. A entrada não descobre hashes para autorizar a si própria. Cumprir posteriormente o protocolo de instalação/aplicação pertinente; esta rodada não o executou nem o aprovou.

Exigir PAUSE preservada, exclusividade disponível, solicitante e Gestor comprovadamente ausentes e demais proteções aprovadas. Restrição conservadora: Windows; sem recovery-window presente, sidecars SQLite pendentes, caminhos reparse/hardlinks ou fontes de estado incompletas. Tentativa parcial anterior exige resolução controlada separada; não apagar seu arquivo histórico nem contornar o bloqueio. Não há nova autorização implícita para remover locks, outros requests ou retomar operação.
