# 01 — Protocolo de execução controlada

## 1. Por que este protocolo existe

O projeto é longo e multidisciplinar. Sem travas, um agente pode misturar planejamento, mineração, modelagem e produção, entregar aproximações e considerar o trabalho concluído. Este protocolo transforma cada fase em um contrato verificável.

## 2. Unidade de trabalho

Toda execução usa um `PhaseTask` baseado em `templates/PHASE_TASK.md`. Uma tarefa deve possuir:

- um único objetivo;
- entradas identificadas;
- saídas com caminhos definidos;
- fora de escopo explícito;
- critérios binários ou verificáveis;
- testes;
- evidências;
- condição de parada.

## 3. Máquina de estados

Estados permitidos:

- `NOT_STARTED`;
- `READY`;
- `IN_PROGRESS`;
- `BLOCKED`;
- `AWAITING_REVIEW`;
- `APPROVED`;
- `REJECTED`.

Para as Fases 5–8, D-047 permite transição automática de `IN_PROGRESS` para `APPROVED` quando todos os gates obrigatórios passarem com evidência e receipt. A fase seguinte continua `NOT_STARTED` até essa transição, mas já está pré-autorizada. `AWAITING_REVIEW` permanece para dependência humana/externa real, sem paralisar trabalhos independentes.

## 4. Preflight obrigatório

Antes de editar qualquer arquivo, o Codex deve:

1. confirmar a raiz do projeto;
2. listar as instruções carregadas;
3. ler o estado e os documentos da fase;
4. inspecionar o código existente relacionado;
5. informar o que será preservado;
6. identificar entradas ausentes;
7. copiar os critérios de aceitação para o plano;
8. declarar o fora de escopo;
9. parar se houver conflito material.

## 5. Implementação

Durante a fase:

- faça mudanças pequenas e rastreáveis;
- preserve alterações existentes não relacionadas;
- não introduza dependências sem justificativa;
- valide dados de entrada;
- produza saídas determinísticas quando possível;
- registre versão dos modelos e parâmetros;
- use adaptadores para serviços externos;
- implemente timeout, retry, idempotência e deduplicação;
- não esconda falha com fallback silencioso;
- marque mock, fixture e dado real de forma distinta.

## 6. Verificação

Cada fase deve conter:

- testes unitários do domínio;
- teste de integração quando houver ferramenta externa;
- fixture reproduzível;
- exemplo real autorizado quando aplicável;
- validação de schema;
- relatório de critérios;
- revisão do diff;
- comparação com o padrão-ouro quando existir.

## 7. Relatório de encerramento

O relatório final da fase deve informar:

1. resultado objetivo;
2. arquivos modificados;
3. comandos executados;
4. testes e resultados;
5. exemplos produzidos;
6. critérios aprovados;
7. critérios reprovados;
8. bloqueios;
9. suposições;
10. limitações;
11. custo observado;
12. próxima fase sugerida, sem iniciá-la.

## 8. Controle de mudanças

Uma mudança de objetivo exige registro em `docs/DECISIONS.md`. Se a mudança afetar schema, critérios ou uma fase aprovada:

1. descreva o impacto;
2. identifique artefatos invalidados;
3. proponha migração;
4. aplique D-047 quando a decisão for técnica, reversível e objetivamente comparável; registre e prossiga;
5. solicite aprovação apenas para autoridade externa, direito, orçamento/gasto, credencial, destruição, política ou mudança estratégica fora do envelope;
6. só então altere o contrato protegido.

## 9. Política de dúvidas

- Dúvida que muda objetivo protegido, direito, orçamento, política ou efeito irreversível: consolide e pergunte após concluir frentes independentes.
- Dúvida reversível de implementação: escolha pela evidência, registre, teste e prossiga.
- Informação não verificável: marque `UNKNOWN`.
- Integração indisponível: use adapter/mock apenas se a fase permitir.
- Falha de ferramenta: não declare sucesso parcial como conclusão.

## 10. Sessões do Codex

- Use uma conversa por resultado coerente.
- Comece cada fase em uma nova tarefa quando o contexto anterior estiver inchado.
- O estado do projeto vive nos arquivos, não apenas na conversa.
- Sempre peça ao Codex para resumir as instruções carregadas no preflight.
- Não envie simultaneamente dois prompts de fases diferentes.
- Use checkpoints Git antes e depois de uma fase quando o projeto estiver versionado.

## 11. Protocolo do Gestor Central Autônomo

O Gestor permanece subordinado à máquina de fases. Sob D-047, ele pode executar a transição automática de uma fase pré-autorizada somente quando o avaliador de gates produzir prova completa e independente do executor; não pode autoaprovar exceção, fabricar revisão humana nem executar fase posterior antes desse receipt.

Toda execução de módulo deverá nascer de comando central idempotente com objetivo, evidência, decisão, policy gate, versão, escopo e trace. O executor devolve artefato/receipt; não altera estratégia, memória ou prioridade. O Policy Gate aplica primeiro regras permanentes, depois fase autorizada e envelope; prevalece a regra mais restritiva.

Lock de liderança, fila, retry, checkpoint, dead-letter, replay e rollback somente serão implementados nas fases definidas em `docs/GESTOR_CENTRAL_IMPLEMENTATION_PLAN.md`. Esta incorporação não os declara existentes.

## 12. Recuperação transversal — D-170

Aplicar `docs/FALLBACKS_OPERACIONAIS.md` como complemento permanente. Preservar
gatilho, identidade, entrada, falha, tentativa, quota e efeitos confirmados.
Usar primeiro prova íntegra do mesmo trabalho; depois a recuperação autorizada do
executor. Alternativa de fornecedor exige validação equivalente, não apenas uma
string de configuração. DEFER e BLOCKED são estados honestos, nunca recuperação
funcional contabilizada. Falha em uma tarefa não autoriza repetir outras intactas.

Corrigir ponteiros apenas quando ausentes e a partir de provas completas;
divergência preservada bloqueia antes de sobrescrita. Operação externa mutável
ambígua exige reconciliar seu receipt e ID antes de nova tentativa. Nunca repetir
upload para descobrir se o anterior funcionou. Troca de voz, ativo, estilo,
narrativa, medição oficial ou variável experimental não é fallback transparente.

A cobertura do painel identifica código e limitações, mas não é avaliador nem
autorizador. Só testes executados e receipts aplicáveis comprovam recuperação.
Instalação de alterações deve percorrer a manutenção segura existente, com
regressão e recuperação D116 em vez de uma reinicialização manual sem prova.
