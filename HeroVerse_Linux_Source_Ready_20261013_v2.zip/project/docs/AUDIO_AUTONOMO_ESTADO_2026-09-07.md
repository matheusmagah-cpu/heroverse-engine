# Avaliação sonora autônoma — implementação e evidências reais

## Resultado desta execução

A avaliação rotineira pertence ao sistema. Foi retirada a solicitação de que o proprietário escute o vídeo como solução da lacuna interna. Isso não transforma o sistema em revisor humano nem remove os gates existentes.

Implementado e executado um instrumento local de avaliação perceptual auxiliar, independente do sintetizador: DNSMOS P.835 regular, com versão, modelo, licenças, arquivos e receita identificados por hash. O master foi analisado uma vez, integralmente. **O áudio completo e o Vídeo 2 ainda não estão aprovados.** O instrumento não foi inserido silenciosamente no runtime produtivo como substituto dos gates existentes.

## Medição observada

| Item | Evidência |
|---|---|
| Fonte | `narration-normalized.wav`, SHA-256 `8e8909fef9835f92aee8521db9c7e0153216fa5a48a0bd0f2177444fdeac49b6` |
| Duração | 202,780 s; 4.866.720 samples na fonte PCM16 mono de 24 kHz |
| Entrada do avaliador | 3.244.480 samples a 16 kHz; resampling apenas em memória |
| Cobertura | 195 janelas de 9,01 s; 100% dos samples, zero lacuna no fim |
| Tempo medido | 95,029098 s nesta máquina e nesta execução; não é SLA |
| Fala / fundo / geral | Médias estimadas 3,1391 / 3,8325 / 2,8111 |
| P10 fala / fundo / geral | 2,9385 / 3,6386 / 2,5649 |
| Menor nota geral | 2,3645 na janela 178,00–187,01 s |
| Extremos PCM da fonte | Zero, consistente com o controle técnico anterior |
| Recursos | ONNX Runtime 1.29.0, NumPy 2.5.2, CPU, duas threads intra/uma inter |
| Custo técnico adicional | R$ 0,00; nenhuma chamada de inferência externa |

Essas notas são estimativas do modelo, **não opinião de um ouvinte, percentual de qualidade, probabilidade de retenção ou aprovação**. Ainda não foram calibradas para esta voz TTS e domínio narrativo. Janela com menor nota é prioridade de investigação, não diagnóstico comprovado de defeito ou palavra incorreta. Não afirmar qualidade máxima com esses números.

As outras quatro janelas com menor nota geral começam em 190, 193, 58 e 23 segundos. As janelas se sobrepõem; não representam amostras humanas independentes. Seus resultados integrais permanecem no receipt, não apenas a média.

## Controles de defeitos

Sobre a primeira janela, gerados somente em memória e explicitamente sintéticos:

- Ruído branco com SNR RMS 0 dB: estimativa de fundo 3,8571 → 1,3385 e geral 2,7392 → 1,5600.
- Silêncio absoluto: identificado por sinal zerado, independentemente do MOS. O modelo ainda produziu 3,4724 para fundo; isso demonstra por que uma nota isolada não é gate suficiente.
- Ganho 20 com hard clipping: 57.406 samples no limite, detectados pelo controle PCM; estimativa geral 1,9618.
- Avaliador constante: teste negativo exige falha quando ruído e baseline recebem a mesma nota.

Os quatro checks dos controles reais passaram. Isso comprova respostas específicas a esses defeitos artificiais, **não** sensibilidade/especificidade universal, pronúncia, emoção correta ou calibração humana. Não se repetiu ASR, ressíntese, normalização ou render de vídeo.

## Testes e rastreabilidade

- 16 testes unitários focais PASS, zero skip, 0,355 s no comando `3bb7d0`.
- 14 checagens da medição real PASS no comando `120706`: schema, hashes externos, fonte, modelo/licenças, cobertura, médias recalculadas, controles e rejeição de alegações de aprovação/revisão humana/custo pago.
- Replay realizado com rede, subprocesso e criação de sessão ONNX explicitamente proibidos. Recompõe integridade e agregação; não reexecuta nem certifica a inferência neural.
- Uma falha inicial na constante esperada do teste BAK foi corrigida por recomposição da expressão oficial, sem mudar coeficientes ou tolerância: `-.13166888 × 9 + 1.60915514 × 3 − .39604546 = 3.24640004`. Tentativa `5d3a16` preservada no histórico da execução.
- Um parêntese ausente no verificador foi corrigido após SyntaxError `55c259`, antes da primeira verificação bem-sucedida. Não houve nova inferência ou alteração do master para essas correções.
- A regressão integral histórica de D116 permanece histórica; **não cobre automaticamente o novo módulo/schema/testes**. Não foi repetida para aparentar avanço nem foi alegado deploy produtivo.

| Artefato | SHA-256 |
|---|---|
| `hero_engine/audio_perception.py` | `29a10ffdb93f817d0ddc71cf85608f1a6dc31a2787ecc07909d9622f511bd029` |
| `tests/test_audio_perception.py` | `778b8ba914adb926bae1867ee329292780f377c13a5c49a659332581863fa32f` |
| `schemas/audio_perception.schema.json` | `d3ad542deec619ab04cf2c98d3ae686d92b694738fdd41f1530318a583a61ff1` |
| `audio-perception-v1/master-receipt.json` | `ca77105222422f51de76b01c7e41a91399f76fd104555cc6f6b51263707011d2` |
| `audio-perception-v1/verify_measurement.py` | `e878b87ef9bb6da15cca0970604660fae0277a36f4d61e1123c7e0a3c82290f0` |
| `audio-perception-v1/verification.json` | `20bf33c4be0aaa0810c5ad515b17b15cf5688f9c05ae13dc501a97217f4ab10f` |

Os três últimos caminhos relativos estão sob `output/qa/phase6/diagnostics/`. O verificador recebe/preserva pins externos do runner, receipt e áudio; uma flag autodeclarada não concede autoridade. `master-receipt.json` e `verification.json` são imutáveis.

## Licenças, limites e dependências

Revisão Microsoft `591184a9fcb2cbdec02520fed81a32bbbf9d73ff`; modelo `sig_bak_ovr.onnx`, 1.157.965 bytes, SHA-256 `269fbebdb513aa23cddfbb593542ecc540284a91849ac50516870e1ac78f6edd`. Seis arquivos oficiais foram baixados, conferidos por tamanho, blob Git e SHA-256, em `models/dnsmos/<revisão>/`. Downloads ocorrem apenas em setup explícito; análise/replay são offline. Não houve instalação de serviço, cadastro, cobrança, voz ou nova dependência paga.

Método derivado do código Microsoft DNS-Challenge, licença MIT. Modelo/documentos sob CC BY 4.0 conforme a declaração do repositório; cópias integrais de `LICENSE`, `LICENSE-CODE`, READMEs e código upstream acompanham o bundle. Preservar atribuição, link, licenças e indicação de alterações ao distribuir; não sugerir endosso nem direitos sobre marcas. [Documentação oficial DNSMOS](https://github.com/microsoft/DNS-Challenge/blob/591184a9fcb2cbdec02520fed81a32bbbf9d73ff/DNSMOS/README.md), [licença do código](https://github.com/microsoft/DNS-Challenge/blob/591184a9fcb2cbdec02520fed81a32bbbf9d73ff/LICENSE-CODE) e [licença dos conteúdos](https://github.com/microsoft/DNS-Challenge/blob/591184a9fcb2cbdec02520fed81a32bbbf9d73ff/LICENSE).

Alterações metodológicas explícitas: FFmpeg SWR em lugar de librosa e janela adicional no fim. O lattice original deixaria 28.320 samples/1,77 s deste master sem cobertura. A média do subconjunto original também foi preservada, mas não apresentada como execução idêntica do benchmark upstream.

Esta versão aceita somente mono24kPCM16 de 9,01–600 s em grade exata para 16 kHz. Não repete áudio curto nem acrescenta silêncio. Modelo ausente, fonte diferente, NaN, formato inválido, artefato alterado, arquivo ligado/offline, falha de processo ou orçamento de tempo excedido falham fechados. Reserva de disco na CLI: 5 GiB; FFmpeg limitado a 120 s, medição com verificação de teto de 180 s entre chamadas. Isso não é supervisor capaz de interromper uma chamada ONNX nativa travada: timeout rígido de processo, limite de RAM e retomada de lote interrompido permanecem requisitos antes de runtime contínuo. O limite de 600 s é contrato de entrada, não benchmark de capacidade de produzir/medir esse tamanho dentro do teto.

Fallback atual: reutilizar receipt íntegro quando inputs não mudam; na falta do modelo/capacidade, conservar medições técnicas existentes e o gate bloqueado. Não usar serviço pago nem alegar equivalência perceptual desse fallback. Não descarregar áudio para API externa.

## Resolução completa: etapas ainda necessárias e Done when

1. **Instrumento de medição local — executado neste incremento.** Done when: fonte real preservada, modelo/licença pinados, cobertura integral, controles e replay testados. Evidências acima. Não equivale a capacidade produtiva regular.
2. **Validação de domínio e decisão sonora.** Fixar corpus aplicável, rótulos de referência independentes, política de erro e separação entre desenvolvimento/validação antes de usar limiar MOS. Separar ruído, articulação, pronúncia e prosódia. Done when: sensibilidade, falsos aceites/rejeições, incerteza e falhas de cobertura demonstrados em dados não usados para ajustar a regra; nenhum limiar inventado depois de ver o master. A obtenção de referências não deve ser convertida em tarefa rotineira de escuta do proprietário. Sem dataset aplicável, registrar indisponibilidade, nunca fabricar gold.
3. **Pronúncia e prosódia.** Resolver as divergências acústicas 001/007/013/016 com evidência nova e método adequado, preservando os ASRs e WAVs existentes. `write/right` de 011 continua homofonia, não erro demonstrado. Done when: cada trecho tem contraprova ligada ao PCM e decisão justificável; modelo de qualidade geral não decide palavras. Não ressintetizar as 51 unidades nem repetir os ASRs intactos.
4. **Temporalidade e duração.** Fechar a união integral de alvos visuais/captions, reconstituir referências disjuntas sob nova policy pré-registrada e validar o alinhamento aplicável. O cohort/policy antigos de 30 continuam incompatíveis. Resolver os 5,020 s de déficit de duração narrativa sem silêncio de preenchimento ou mudança não autorizada de hooks. Done when: A recebe referências verdadeiras e os limites temporais/duração passam; MOS e borda PCM não se tornam timestamp de palavra.
5. **Integração e operação contínua.** Versionar consumidor do receipt no gate AUDIO, com decisão por dimensão, supervisor de processo, limite de memória, recuperação e invalidação por mudança de bytes/modelo/pipeline. Done when: testes de sucesso/falha/crash/retry, regressão aplicável e ciclo real do Gestor aprovados sem revisão rotineira por vídeo; falhas e lacunas mantêm o gate fechado. Não recadastrar o mesmo vídeo ou repetir inferência intacta.
6. **Release audiovisual.** Depois de A–D e dos gates anteriores, compor o candidato, avaliar movimento/continuidade/áudio-imagem/direitos/publicity, congelar pacote e seguir private-first até verificação pública. Done when: cadeia real inteira comprova `COMPLETE_PUBLIC` do vídeo exato. Nada nesta medição libera essa etapa.

## Estado operacional honesto

Fase 6 IN_PROGRESS, um piloto público já existente, Vídeo 2 ainda não publicável. Gestor, fila, credenciais e mídias anteriores não foram alterados nesta execução. Não houve nova consulta de cota, fan-out, reset ou gasto. Mantida a reserva D152 e os gates A–D. A avaliação sonora completa é lacuna de implementação/validação do sistema; não há nova solicitação de confirmação ou escuta do proprietário.

Este relatório substitui a orientação operacional de escuta manual que consta nos checkpoints anteriores, sem apagar esse histórico. O instrumento automático foi construído e medido; **não é declaração de resolução definitiva de toda a operação**.
> Atualização D-168: o supervisor Windows antes pendente foi implementado e passou17testes reais/focais, sem reinferência do master. A reconciliação ampliada registra seis unidades com desacordos (incluindo014/015contextuais), não erros de voz confirmados. A integração audiovisual continua pendente: o avaliador legado não representa51unidades/71cues/90takes nem mixagem final. Estado atualizado, arquivos e próximos passos em [Retomada operacional](RETOMADA_OPERACIONAL_2026-09-07.md). As conclusões históricas abaixo permanecem com seu escopo original.
