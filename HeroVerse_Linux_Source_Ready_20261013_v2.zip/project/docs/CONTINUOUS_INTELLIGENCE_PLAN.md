# Plano mestre adaptado — Inteligência Contínua Viva

## Identificação

- Complemento: `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md`.
- Estado: `AWAITING_REVIEW`.
- Fase atual: `1`, pausada durante revisão do planejamento.
- Objetivo: incorporar uma camada persistente, observável, versionada, testável e reversível sem antecipar fases.
- Regra de precedência: todos os contratos, gates, direitos e decisões anteriores permanecem íntegros.
- Correção complementar: a camada é o Gestor Central Autônomo e fonte única de comando de 100% da operação, conforme `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md` e `docs/GESTOR_CENTRAL_IMPLEMENTATION_PLAN.md`. Os componentes abaixo tornam-se executores subordinados; nenhuma parte ganha autoridade para ultrapassar o envelope ou os gates.

## Arquitetura-alvo

O desenho alvo contém os 16 componentes obrigatórios do requisito. Eles serão implementados como módulos de domínio e adapters testáveis, com SQLite no piloto e abstração de persistência. n8n, MCP, skills e plugins não conterão a lógica central e só serão avaliados após os fluxos correspondentes funcionarem por CLI e testes.

Fluxo lógico:

`Observers -> Event Ledger -> Normalizer -> Feature Builder -> Knowledge Store -> Hypothesis -> Experiment -> Policy Gate -> Decision -> Learning Evaluation -> Rule Registry -> Application Plan`

Scheduler, auditoria e monitoring operam transversalmente sem ampliar autoridade.

## Subtarefas por fase e “Done when”

### Fase 1 — Proveniência do padrão-ouro

1. Definir manifesto lateral sem alterar o schema estável.  
   **Done when:** campos, enums, hashes, versões e validações estiverem aprovados no plano.
2. Vincular cada evidência a arquivo, timecode/frame e classe.  
   **Done when:** uma fixture manual puder ser reconstruída somente pelos artefatos preservados.
3. Registrar canal/escopo e versão de ferramentas.  
   **Done when:** duas execuções não puderem ser confundidas silenciosamente.

### Fase 2 — Emissão idempotente pelo minerador

1. Adicionar validação e chave idempotente do job.  
   **Done when:** reprocessar o mesmo hash e versão não duplicar resultado.
2. Emitir run manifest e divergência contra o padrão-ouro.  
   **Done when:** resultado, parâmetros, ferramentas e falhas forem reproduzíveis.
3. Testar ausência e contradição.  
   **Done when:** dados insuficientes gerarem `UNKNOWN`/falha explícita, nunca conclusão inventada.

### Fase 3 — Ledger, observatório e normalização

1. Definir migrações e schemas iniciais.  
   **Done when:** banco vazio e banco existente migrarem de forma testada e reversível.
2. Implementar Event Ledger append-only.  
   **Done when:** reingestão for idempotente e eventos originais não puderem ser sobrescritos.
3. Implementar Market Observer permitido e Normalizer.  
   **Done when:** snapshots datados forem normalizados por canal, formato, idade, janela e fonte.
4. Implementar isolamento de escopo.  
   **Done when:** teste provar ausência de vazamento entre canais.

### Fase 4 — Features, baselines e hipóteses

1. Ligar minerações, embalagem, takes e performance.  
   **Done when:** cada feature apontar para evidência e versão exatas.
2. Criar baselines compatíveis.  
   **Done when:** comparações recusarem janelas/coortes incompatíveis.
3. Implementar Hypothesis Engine.  
   **Done when:** hipótese guardar evidência favorável, contrária, refutação, confiança e limites.
4. Criar memória semântica candidata.  
   **Done when:** nenhuma hipótese não testada for promovida acima de `CANDIDATE`.

### Fase 5 — Política e aplicação em blueprint

1. Implementar Policy Gate unificado.  
   **Done when:** fase, canal, direitos, custo e aprovação bloquearem ações não autorizadas.
2. Implementar Application Plan.  
   **Done when:** mudança proposta referenciar regra, versão, evidência e rollback.
3. Integrar ao blueprint sem reescrita silenciosa.  
   **Done when:** contratos permanentes continuarem imutáveis e overlays forem versionados.

### Fase 6 — Experimento e operação própria

1. Implementar Own-Channel Observer.  
   **Done when:** métricas privadas autorizadas tiverem origem, janela, escopo e vínculo com a produção.
2. Implementar Experiment Planner e Decision Engine versionado.  
   **Done when:** variável, controle, amostra, duração, custo, risco e stop rule estiverem explícitos.
3. Implementar scheduler controlado, retries e DLQ.  
   **Done when:** falha não perder job, não duplicar efeito e gerar incidente observável.
4. Implementar Learning Evaluator.  
   **Done when:** resultados forem `SUPPORTED`, `REJECTED`, `INCONCLUSIVE` ou `INVALID_EXPERIMENT` com baseline e incerteza.

### Fase 7 — Registry, replay, rollback e transferência

1. Implementar Rule Registry versionado.  
   **Done when:** níveis `CANDIDATE` a `REJECTED` exigirem critérios e preservarem histórico.
2. Implementar replay determinístico.  
   **Done when:** mesma sequência e versão reproduzirem a mesma decisão.
3. Implementar rollback.  
   **Done when:** overlay puder ser revertido sem apagar eventos ou decisões.
4. Implementar drift e expiração.  
   **Done when:** mudança relevante suspender ou reabrir regra conforme configuração.
5. Testar transferência.  
   **Done when:** regra local entrar em outro canal somente como `TRANSFER_CANDIDATE` e passar por experimento aprovado.

### Fase 8 — Produto e escala

1. Endurecer multiusuário, permissões e observabilidade.  
   **Done when:** isolamento e auditoria forem demonstrados sob concorrência.
2. Avaliar PostgreSQL por evidência operacional.  
   **Done when:** decisão registrar carga, concorrência, custo e migração reversível.
3. Empacotar interfaces maduras.  
   **Done when:** CLI, testes e contratos estiverem estáveis antes de skill, MCP, plugin ou n8n.

## Contratos e migrações planejados

Os 15 schemas obrigatórios serão versionados em `schemas/intelligence/` quando a fase correspondente estiver autorizada. Toda migração terá:

- identificador e versão;
- caminho `up` e rollback aplicável;
- preflight e backup;
- teste em banco vazio e cópia do banco atual;
- invariantes e contagens antes/depois;
- compatibilidade com materializações legadas;
- registro em `PipelineVersion`.

## Interfaces planejadas

- `EventLedgerRepository`;
- `MarketObserver`;
- `OwnChannelObserver`;
- `Normalizer`;
- `FeatureBuilder`;
- `KnowledgeStore`;
- `HypothesisEngine`;
- `ExperimentPlanner`;
- `DecisionEngine`;
- `PolicyGate`;
- `LearningEvaluator`;
- `RuleRegistry`;
- `ApplicationPlanner`;
- `JobQueue`/`Scheduler`;
- `AuditReporter`;
- `MonitoringSink`.

As interfaces são nomes de planejamento, não código existente.

## Testes de aceitação preservados

Persistência, idempotência, rastreabilidade, dados ausentes, contradição, isolamento, aprendizado local, transferência controlada, gate humano, rollback, replay, versionamento, drift, resultado inconclusivo, ciclo completo e impacto são critérios obrigatórios. Nenhum poderá ser satisfeito apenas por mock ou relatório.

## Demonstração futura

A demonstração por fixtures só será construída quando os componentes correspondentes estiverem autorizados. Ela deverá cobrir observações de mercado e próprias, baseline, hipótese, bloqueio, aprovação simulada, três resultados, atualização de regra, aplicação, reinício, rollback e relatório completo.

## Gate atual

Nenhuma subtarefa de implementação está autorizada por este plano. A única ação atual foi incorporar o requisito, auditar o estado e adaptar o planejamento. O próximo passo possível é o usuário revisar este plano e o impacto; depois, a Fase 1 poderá ser retomada no gate de aprovação da amostra, não avançada para a Fase 2.
