# Relatório de execução — Fase 1

## Estado do gate

- Fase: `1 — padrão-ouro manual de mineração`
- Estado: `AWAITING_REVIEW`
- Escopo executado: somente os quatro vídeos aprovados na D-012
- Fase 2: `NOT_STARTED` e não autorizada
- Publicação, produção, reutilização de mídia e gasto: não executados

O padrão-ouro foi materializado e validado. O gate permanece aberto porque a aprovação do proprietário é uma decisão externa aos testes.

## Entregas verificáveis

| Entrega | Resultado | Evidência |
|---|---:|---|
| Amostra real | 4 vídeos em inglês do mesmo canal/nicho | `data/gold_standard/manifest.json` |
| Mineração estruturada | 4 documentos Draft 2020-12 válidos | `data/gold_standard/<video_id>/video_mining.json` |
| Hooks | 16 janelas: `0–1`, `1–3`, `3–8`, `8–30 s` | seção `hooks` de cada mineração |
| Takes | 256 intervalos contíguos com keyframe individual | `data/gold_standard/<video_id>/keyframes/` |
| Segmentação narrativa | 25 segmentos temporais | seção `narrative_segments` |
| Transcrição | bruto preservado + versão revisada por vídeo | `transcript.raw.json` e `transcript.reviewed.json` |
| Relatório humano | 4 anotações com tabela take por take | `data/gold_standard/<video_id>/annotation.md` |
| Integridade | SHA-256 de mídia, miniaturas, transcrições, minerações e keyframes | `data/gold_standard/integrity_manifest.json` |
| Validação independente | 4/4 aprovados; 0 falhas de schema; 0 evidências ausentes | `data/gold_standard/validation_report.json` |

## Amostra e medidas observadas

As contagens públicas são snapshots, não métricas privadas. “Cortes/min” é calculado a partir dos candidatos de cena revisados; flashes podem gerar microcandidatos e por isso a medida não é tratada como número editorial absoluto.

| Papel D-012 | Vídeo | Duração | Views | Likes | Comentários | Takes | Candidatos/min | Primeira fala |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| vencedor principal | `hkf6nDyUfAM` | 229,801 s | 490.127 | 11.004 | 446 | 57 | 14,88 | 6,770 s |
| vencedor recente | `_sOy7htXJi8` | 209,701 s | 54.578 | 1.851 | 190 | 63 | 18,03 | 6,540 s |
| mediano | `Pkede5acSFw` | 284,367 s | 113.030 | 2.519 | 175 | 55 | 11,60 | 5,740 s |
| fraco | `huvUy3pJSp8` | 242,501 s | 43.612 | 952 | 50 | 81 | 20,04 | 6,670 s |

## Comparação intra-amostra

### O que foi observado

1. Todos os quatro vídeos usam aproximadamente os dois primeiros segundos para o bumper do canal. A fala temática começa entre `5,740` e `6,770 s`; portanto, nestas peças o primeiro segundo não contém a tese verbal.
2. `WARFARE` confirma o mecanismo prometido aos `6,770 s` com “whole armor of God” e mantém coerência visual de combate até o payoff cristológico.
3. `GODS VENGEANCE` declara a tese aos `5,740 s`, mas a miniatura de fantasia angelical não corresponde ao corpo visual observado, composto por luto e thriller de ação.
4. `BROKEN WITH PURPOSE` só define “Brokenness” aos `41,700 s`. O primeiro take narrativo dura de `2,080` a `43,330 s`, criando atraso verificável de promessa.
5. `THE KING IS COMING` usa confronto identitário já na abertura, mas a expressão literal “coming Son of God” só aparece aos `129,140 s`; a promessa é sustentada antes disso por realeza, exército e referências a “that day”.
6. O vídeo classificado como fraco possui a maior taxa calculada de candidatos de corte (`20,04/min`), enquanto o vencedor principal tem `14,88/min`. Nesta amostra, quantidade bruta de cortes não separa vencedor de fraco.

### Inferências permitidas para futura modelagem

- A promessa pode ser confirmada por áudio, visual e identidade, mas o atraso precisa ser medido; não basta copiar a frase do hook.
- Clareza e alinhamento de promessa parecem mais úteis que frequência bruta de cortes nesta amostra.
- Montagens muito aceleradas funcionam como escalada depois da tese; não há evidência nesta amostra de que devam ocupar os primeiros três segundos.
- A conclusão acima é uma hipótese local para a Fase 2, não causalidade comprovada nem regra geral promovida pelo Gestor Central.

## Separação epistemológica

| Classe | Conteúdo registrado |
|---|---|
| `OBSERVED` | título, thumbnail, frames, fala, timecodes, duração técnica, contagens públicas capturadas |
| `CALCULATED` | views/dia de vida, razões like/view e comment/view, candidatos de corte por minuto |
| `INFERRED` | tese, ângulo, público provável, função narrativa, emoção e complexidade de produção |
| `PRIVATE` | nenhum dado privado reivindicado |
| `UNKNOWN` | CTR, retenção, AVD, origem/autorização dos excertos, identidade confirmada dos locutores e efeito causal dos mecanismos |

## Direitos

Os quatro vídeos estão em `EDITORIAL_REVIEW_REQUIRED` e `production_eligible=false`. A licença reportada é nula/ausente; isso não significa domínio público nem permissão comercial. O material baixado é cópia de análise com hash, não biblioteca de produção. Os riscos `RIGHTS` e `REUSED_CONTENT` permanecem bloqueantes.

## Critérios de aceitação

| Critério | Estado | Evidência |
|---|---|---|
| Schema válido | `APROVADO` | 4/4 Draft 2020-12; 0 erros |
| Duração e timecodes consistentes | `APROVADO` | timelines contíguas; tolerância máxima validada em 2 ms |
| Hooks obrigatórios preenchidos | `APROVADO` | 4 janelas por vídeo |
| Takes sem sobreposição inválida e cobertura explicada | `APROVADO` | 256 takes; início zero; fim compatível com ffprobe/detector |
| Evidências resolvíveis | `APROVADO` | 0 artefatos ausentes |
| Transcrição bruta preservada | `APROVADO` | 4 arquivos brutos; versões revisadas separadas |
| Fatos e inferências separados | `APROVADO` | classes de evidência no schema e tabela acima |
| Nenhum direito presumido | `APROVADO` | 4/4 bloqueados para produção |
| Comparação com o padrão-ouro documentada | `APROVADO` | comparação intra-amostra e validação contra schema/template; comparação máquina × benchmark pertence à Fase 2 |
| Execução reproduzível | `APROVADO` | scripts de preparação, montagem determinística e validação |
| Revisão humana do gate | `BLOQUEADO — AGUARDANDO PROPRIETÁRIO` | este relatório e os fixtures estão em `AWAITING_REVIEW` |

## Testes executados

| Teste | Resultado |
|---|---:|
| Preparação real de mídia, ffprobe, transcrição e keyframes | `PASS` |
| Validador independente Draft 2020-12 | `PASS — 4/4` |
| Hash da mídia-fonte | `PASS — 4/4` |
| Evidências locais e URLs | `PASS — 0 ausentes` |
| Invariantes de hooks/takes/duração/direitos | `PASS` |
| Testes específicos do padrão-ouro | `PASS — 7/7` |
| Suíte completa do projeto | `PASS — 21/21` após a inclusão do teste de integridade |

Comandos reproduzíveis:

```powershell
.\.venv\Scripts\python.exe tools\prepare_gold_standard_evidence.py
.\.venv\Scripts\python.exe tools\build_gold_standard_fixtures.py
.\.venv\Scripts\python.exe tools\validate_gold_standard.py
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

O primeiro comando depende das cópias de análise já preservadas. O segundo não é um minerador automático: ele reproduz decisões semânticas manuais codificadas. O terceiro é independente dessas decisões e verifica contrato, arquivos, hashes e invariantes.

## Limitações e lacunas

- Não existem CTR, retenção, AVD ou origem de tráfego públicas; nenhuma delas foi inventada.
- As legendas disponíveis são automáticas. `BROKEN WITH PURPOSE` não tinha VTT; intervalos ambíguos permanecem declarados.
- O limiar de cena `0.25` produz microcandidatos em flashes; cada candidato foi preservado, mas o limite não deve ser confundido com corte editorial perfeito.
- Quatro vídeos de um único canal são benchmark de implementação, não prova estatística de causalidade ou generalização.
- Os papéis vencedor/mediano/fraco são os aprovados na D-012; esta fase não os reclassifica.
- O diretório não possui metadados `.git`; por isso não existe `git diff` verificável. A revisão foi substituída por inventário, validação e manifesto SHA-256 dos artefatos.
- Nenhuma garantia de monetização, lucro ou prazo foi criada.

## Condição de parada

A Fase 1 para aqui em `AWAITING_REVIEW`. Nenhum minerador da Fase 2, runtime do Gestor Central, produção, upload, publicação ou gasto foi iniciado.
