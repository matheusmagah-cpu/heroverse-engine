# Migração do HERO Engine para a nuvem

Data: 02/10/2026. Estado: NÃO MIGRADO; diagnóstico e roteiro preparados.

## Objetivo e estado preservado

O usuário quer desenvolver sem depender do computador Matheus e, depois, vender o programa para uso em qualquer lugar. A migração deve preservar arquivos, dados, decisões e evidências. Desenvolvimento no Codex Cloud e hospedagem do produto são etapas distintas.

Esta é uma proposta de migração. Nenhum contrato de raiz, runtime, gate, pausa, credencial ou autoridade de publicação foi alterado. A origem Windows continua oficial até existir uma cópia completa verificada e uma decisão de troca registrada.

O checkpoint vigente consultado em docs/STATE.md, de 01/10/2026, registra PAUSE preservado, tarefa Disabled e candidata não adotada. Preservar esse estado. Migrar não autoriza iniciar outro ciclo, renderizar ou publicar.

## Diagnóstico verificado nesta sessão

- Origem de execução: C:\Users\mathe\OneDrive\READET~1\MODELA~1.
- assert_orchestration_root.ps1: PASS; marcador AGENTS.md SHA-256 629c24e33fe7cda818bbb92d72cda3838bb9021983d42e6da12662d027d986bd.
- Git e GitHub CLI instalados; gh auth status informa ausência de login.
- A pasta ainda não é um repositório Git.
- Código principal: hero_engine, 185 arquivos, aproximadamente 5,13 MiB, sem __pycache__.
- tests: 228 arquivos, 4,17 MiB; schemas: 183 arquivos, 1,01 MiB.
- data: 358 arquivos, 205,46 MiB; models: 73 arquivos, 782,92 MiB.
- Inventário de output, outputs e tools não concluído. Não há tamanho total confirmado.
- Preflight observado: C: 12,19 GiB livres e RAM livre 1,8 GiB, abaixo dos alvos D-196 de 15 GiB e 2 GiB. Não executar transferência integral, compressão ou provas pesadas antes de recuperar a margem de forma autorizada.
- A integração GitHub foi sugerida; instalação e autenticação não estão confirmadas.

## Dependências que precisam de adaptação

O ambiente de desenvolvimento pode receber o código antes da portabilidade integral. Isso não comprova execução produtiva em Linux.

- scripts/setup.ps1 usa Python da instalação local do Codex e .venv/Scripts/python.exe.
- hero_engine/audio_perception_supervisor.py usa WinDLL, Job Objects e semântica de rename do Windows.
- hero_engine/maintenance_paused_application.py depende de PowerShell e tarefas agendadas.
- hero_engine/phase6_av_publicity_runtime.py fixa Python, FFmpeg, executáveis e DLLs do Windows.
- hero_engine/phase6_av_render_recipe.py fixa binários FFmpeg do Windows e seus hashes.
- hero_engine/renderer.py possui fontes Windows e voz SAPI/System.Speech.

A migração produtiva exige adaptar e verificar essas dependências ou avaliar um executor Windows na nuvem. Nenhum provedor ou gasto foi contratado. A política vigente de custo zero permanece.

## Sequência de migração

1. Instalar e conectar a integração GitHub na conta do usuário ou autenticar o GitHub CLI na tela oficial. Não inserir senhas ou tokens no chat.
2. Revisar os arquivos que entrarão no Git e criar um repositório privado, com nome e conta confirmados.
3. Versionar fontes, testes, schemas, scripts, prompts, templates, migrations, documentação e configurações previamente verificadas como livres de segredos. Revisar .gitignore antes de git add.
4. Preservar data, banco SQLite, mídias, modelos, outputs, receipts e provas em armazenamento privado apropriado. Git não é o backup integral desses dados.
5. Criar snapshot consistente do SQLite e manifesto de integridade. Copiar e conferir os objetos vinculados às provas; não apagar nem modificar os originais.
6. Recriar dependências no destino, em vez de copiar .venv, node_modules e caches locais. Verificar modelos e binários pelos manifestos aplicáveis.
7. Pelo navegador, criar e publicar um ambiente Codex Cloud conectado ao repositório privado. No celular, selecionar o ambiente já publicado.
8. Levar este plano, docs/STATE.md, docs/DECISIONS.md e HEROVERSE_HANDOFF_2026-09-16.md como contexto durável. Sincronização da conversa não envia a pasta inteira.
9. Verificar, em uma nova tarefa Cloud, acesso ao repositório, persistência do trabalho e testes realmente compatíveis. Não iniciar o produtor por comandos de setup.
10. Implementar e validar a portabilidade do executor preservando gates e evidências. Só trocar a origem oficial após a cópia íntegra e o cutover documentado.
11. Para a venda futura, completar uso interno e repetibilidade, depois hospedagem da aplicação e dados, isolamento entre clientes, autenticação, cobrança conforme o produto e requisitos da Fase 8. Migração não conclui a Fase 8.

## Segredos e continuidade

Credenciais OAuth, refresh tokens, .env, chaves e URLs de acesso efêmero ficam fora do Git e de bundles de código. Não ler ou copiar seu conteúdo para documentação, manifests ou logs. Configurá-los no mecanismo de segredos do destino somente na etapa apropriada.

Uma tarefa Codex Cloud é um espaço de desenvolvimento; não substitui servidor permanente, banco ou armazenamento do produto. Guardar o trabalho em commits e dados em armazenamento durável. Não considerar uma sessão temporária como única cópia.

O computador poderá ficar desligado após a migração efetiva. Acesso por celular ou navegador ainda exige internet. Execução na nuvem depende da disponibilidade do serviço escolhido.

## Critérios de conclusão e condição de parada

A migração só estará concluída quando o código estiver salvo no repositório privado, dados e artefatos tiverem cópia íntegra conferida, segredos estiverem configurados sem exposição, o ambiente Cloud tiver acesso verificável e a tarefa puder continuar com o Matheus desligado.

A execução produtiva exige verificação própria no destino. Preservar PAUSE e tarefa Disabled até uma retomada separadamente autorizada e validada. Falta de conexão, armazenamento durável ou integridade impede declarar a migração concluída.

Fora do escopo desta preparação: retomar produção, promover fases, publicar vídeos, remover arquivos, alterar histórico protegido, contratar infraestrutura ou habilitar cobrança.

## Referências oficiais

- https://developers.openai.com/codex/cloud
- https://developers.openai.com/codex/environments/cloud-environments
- https://developers.openai.com/codex/projects
