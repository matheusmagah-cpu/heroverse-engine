# Preflight — Fase 4

## Autorização e instruções

- raiz: `C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube`;
- fase autorizada: 4;
- autorização: D-027 + D-030;
- fontes lidas: `AGENTS.md`, `docs/STATE.md`, `docs/00_MASTER_SPEC.md`, `docs/01_EXECUTION_PROTOCOL.md`, `docs/07_PHASES_AND_GATES.md`, `docs/03_MODELING_SPEC.md`, bloco da Fase 4 em `prompts/03_MODEL_CHANNEL.md` e schemas relacionados;
- conflito material: nenhum;
- estado: `PASS`.

## Entradas aprovadas

- lote Fase 3 v2: 130 snapshots públicos, 143 registros de cobertura e 5 coortes;
- referência de formato: 24 vídeos Grace, Grit & Love com metadados públicos;
- cobertura de abertura: 16 intros, 13 fora das fixtures da Fase 2;
- cobertura completa: 4 vídeos (2 vencedores, 1 mediano, 1 fraco), 256 takes e 25 segmentos;
- canal próprio: 1 long-form + 20 Shorts públicos, somente metadados nesta fase;
- métricas privadas/RPM: indisponíveis.

## Preservação

- `output/modeling/grace-grit-love/master-model.json` permanece baseline legado, não promovido ao contrato da Fase 4;
- padrões-ouro, manifestos e lote v2 não serão alterados;
- identidade da referência e seus ativos não serão copiados;
- direitos permanecem bloqueados para produção.

## Lacunas e impacto

1. quatro narrativas completas limitam confiança do beat sheet;
2. metadados dos Shorts próprios não suportam gramática audiovisual ou de retenção;
3. dados públicos não provam CTR, retenção, watch hours, YPP, receita ou RPM;
4. views/dia permite comparação descritiva, não causal;
5. um único long-form próprio impede aprender desempenho histórico do HeroVerse long-form.

Consequência: emitir um único arquétipo long-form evidenciado. Shorts entram como hipótese `CANDIDATE`, nunca como FormatArchetype aprovado.

## Fora de escopo

- vídeo, roteiro final, EDL, render ou ativo;
- download de mídia;
- publicação, credencial, Ads ou gasto;
- aprovação de direitos;
- promessa de monetização/RPM;
- promoção de hipótese para `SUPPORTED_LOCAL`;
- arquétipo completo de Shorts sem mineração.

## Gate copiado e operacionalizado

- explicar vencedores, mediano e fraco com evidência/contradição;
- não depender de viral isolado;
- especificar peça nova sem copiar identidade/obra;
- validar schema, refs, scores e replay;
- separar observado/calculado/inferido/candidato/indisponível;
- apresentar arquétipo para decisão do proprietário antes do piloto.
