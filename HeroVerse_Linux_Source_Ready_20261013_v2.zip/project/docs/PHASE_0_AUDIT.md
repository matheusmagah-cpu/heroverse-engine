# Auditoria da Fase 0 — HERO Engine + Kit Mestre

Data: `2026-09-02`  
Raiz confirmada: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`  
Estado: `AWAITING_REVIEW`

## 1. Resultado objetivo

O kit mestre foi lido integralmente e incorporado sem sobrescrever código, dados, renders ou o `README.md` operacional. O projeto existente é um protótipo funcional e auditável do HERO Engine, mas seus artefatos são anteriores aos novos contratos e **não** podem ser considerados aprovações das Fases 1 a 6.

Nenhum código de domínio foi criado ou alterado. Não houve instalação, gasto, aprovação, upload ou publicação. `config/engine.json` permanece em `dry-run`.

## 2. Instruções carregadas e precedência

Foram lidos integralmente:

- `AGENTS.md`, `PLANS.md` e `VALIDATION_REPORT.md`;
- `docs/00_MASTER_SPEC.md` a `docs/09_JEF_PROGRAMADOR_LEARNINGS.md`;
- `docs/STATE.md` e `docs/DECISIONS.md`;
- os três schemas;
- os três templates;
- todos os prompts de `00` a `06`.

Somente a Fase 0 estava autorizada. O escopo executado foi auditoria, incorporação documental, validação do estado real e preparação do plano da Fase 1.

## 3. Preservação e backup

- Não havia `AGENTS.md` antes da incorporação.
- Não há repositório Git na raiz; `git status` retorna “not a git repository”.
- O `README.md` existente foi preservado com SHA-256 `C74F7D877DFE577048327794D7DB47CFA9029B8AF07B22ED7F66C25742861DA1`.
- O README do kit foi instalado como `docs/KIT_README.md` para evitar colisão.
- Backup pré-incorporação: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube.phase0-backup-20260902-102541.zip`.
- Tamanho do backup: `135.857.485` bytes.
- SHA-256 do backup: `6B0E09614554390DA20049B604A43C1970E9D4D25FDF69FEAD042588903D83FD`.
- `.venv/` e `node_modules/` não entraram no backup por serem dependências regeneráveis; código, configuração, dados, saídas, testes e ferramentas entraram.

## 4. Mapa do repositório auditado

| Área | Arquivos | Tamanho observado | Função real |
|---|---:|---:|---|
| `.venv/` | 9.243 | 451,2 MB | ambiente Python local |
| `node_modules/` | 7.792 | 317,9 MB | dependências Node, aparentemente via runtime/junction |
| `data/` | 40 | 116,9 MB | SQLite, CSVs, mídia, transcripts e intros |
| `hero_engine/` | 24 | 374,8 KB | núcleo Python e bytecode |
| `output/` | 122 | 19,4 MB | EDLs, renders, reports, shot lists e modelagem |
| `outputs/` | 19 | 3,9 MB | workbook executivo e previews |
| `tools/` | 4 | 69,0 KB | análise de intros, transcrição e geração do workbook |
| `tests/` | 2 | 19,9 KB | 14 testes unitários |
| `scripts/` | 3 | 2,2 KB | setup, wrapper CLI e rotina diária |
| `config/` | 1 | 3,2 KB | canal, cadência, forecast, gates e segurança |
| `docs/`, `schemas/`, `templates/`, `prompts/` | incorporados | contrato mestre | governança das fases |

Arquivos principais preservados: `README.md`, `pyproject.toml`, `requirements.txt` e `.gitignore`.

## 5. Objetivo que o código atual realmente atende

O código atual atende a um pipeline local específico do canal inglês `@heroverse74` para:

1. manter catálogo SQLite de canais, vídeos, licenças, transcrição, candidatos de clips, hooks, modelo, produções, métricas e forecasts;
2. coletar/consultar metadados públicos, importar transcript e bloquear download sem estado `verified_cc` no registro principal;
3. calcular forecasts determinísticos e, somente com amostra própria suficiente, simulações calibradas;
4. modelar um canal de referência fixo, `Grace, Grit & Love`, usando 24 vídeos e 12 aberturas;
5. gerar EDLs pré-definidas para um Short e um longo;
6. gerar shot list, renderizar via FFmpeg e executar quality gates técnicos/editoriais;
7. preparar pacote de upload privado e publicar apenas com dupla liberação (`publish_mode=live` e `--live`) e aprovação no banco;
8. exportar catálogo e workbook executivo.

Ele ainda não atende ao sistema genérico, provider-agnostic e multicanal definido no kit.

## 6. Componentes, scripts, integrações e documentos existentes

| Componente | Responsabilidade observada | Estado |
|---|---|---|
| `hero_engine/db.py` | schema SQLite, seed e consultas | funcional |
| `hero_engine/youtube.py` | metadados, licença, transcript, descoberta e download | parcial; depende de acesso externo e tem conflito de auditoria |
| `hero_engine/planner.py` | scoring textual, hook, clips e EDLs fixas | funcional como protótipo, não como minerador do schema |
| `hero_engine/modeling.py` | modelo do canal de referência e preflight do longo | funcional no formato legado |
| `hero_engine/shotlist.py` | decomposição do longo em 50 planos | funcional; 45 assets bloqueados |
| `hero_engine/renderer.py` | voz SAPI e render FFmpeg | funcional no protótipo Short |
| `hero_engine/quality.py` | 29 checks do render e gates de licença/atribuição | funcional para a EDL legada |
| `hero_engine/publisher.py` | fila e upload YouTube | implementado, credenciais ausentes e live bloqueado |
| `hero_engine/forecast.py` | metas e simulação reproduzível | funcional; probabilidade corretamente retida sem amostra |
| `hero_engine/decision.py` | `SCALE/ITERATE/STOP/INSUFFICIENT_DATA` | funcional sobre snapshots informados |
| `hero_engine/cli.py` | comandos e rotina diária | funcional, mas gera artefatos em contratos legados |
| `tools/analyze_model_intros.py` | amostra top/bottom e frames das aberturas | executado anteriormente; escopo fixo e caminhos absolutos |
| `tools/transcribe_model_intros.py` | transcrição local das intros | executado anteriormente |
| `tools/build_catalog.mjs` | workbook e previews | funcional no ambiente atual |
| `scripts/setup.ps1` | venv e dependências | funcional, contém caminho absoluto do runtime |
| `scripts/daily.ps1` | testes, rotina e workbook | funcional; não atualiza os arquivos nomeados `forecast-21d.*` |

## 7. O que foi verificado como funcionando

### Testes

Comando:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Resultado observado: `14/14` testes aprovados, `Ran 14 tests`, `OK`, exit code `0`.

Os testes cobrem parsing de ID, seed, matemática determinística, reprodutibilidade do forecast, calibração simulada, decisões por métricas, transcript/scoring, participação de fonte, hook, metadata, preflight do longo e banco de 50 planos.

### CLI e banco

- `catalog channels`: exit code `0`, sete canais.
- `catalog sources`: exit code `0`, doze vídeos.
- SQLite: 13 tabelas contando `sqlite_sequence`.
- Registros principais: 24 `model_videos`, 12 `model_openings`, 40 `clip_candidates`, 11 `license_audits`, duas `productions`, uma transcrição e zero `performance_snapshots`.

### Artefatos

- Modelo legado: 24 vídeos, 5,795 milhões de views na análise e mediana de 134 mil.
- Amostra de abertura: seis top e seis bottom; não há coorte mediana anotada.
- Longo `protect-your-identity-long-01`: preflight legado 11/11, 230 s, 45 s de fonte e participação de 19,57%.
- Shot list do longo: 50 planos; `release_blocked=true`; 45 slots aguardam URL/arquivo/evidência.
- Short `identity-attack-before-calling-short-01`: render presente, quality report 29/29 e score técnico/editorial legado 100%.
- Produções no banco: Short em `queued` e longo em `model_preflight_passed`; ambas continuam com `approval_required=1`.
- Mídia fonte: `data/downloads/5-zdruoQKlM.mp4`, 73.500.968 bytes, SHA-256 `63E544B57551D1D15DECCCC4AF004010C8EAA91E6583F9B812B426148BAA4FCD`.
- Render Short: 3.642.813 bytes, SHA-256 `576C0FDA2226DA8C7012D4204107A0B6917BCBB7E14D8DF5A832798C1E9F0092`.

## 8. O que está incompleto, superficial, quebrado ou apenas documentado

### Mineração

- Não existe artefato com a assinatura obrigatória de `video_mining.schema.json`.
- Não há pipeline implementado de take por take, keyframes iniciais/centrais/finais, OCR, quatro janelas temporais do hook, evidências resolvíveis e classes de evidência por campo.
- A transcrição existente é útil, mas não existe preservação estruturada de bruto e revisado conforme o schema.
- A mineração de hook atual trabalha com uma janela agregada e heurísticas textuais; não substitui `0–1`, `1–3`, `3–8` e `8–30` segundos.

### Modelagem

- `master-model.json` é rico, porém incompatível no topo com `channel_model.schema.json`: faltam 10 dos 11 campos obrigatórios do novo contrato, incluindo `cohorts`, `channel_dna`, `format_archetypes`, `scores`, `hypotheses`, `limitations` e `review_status`.
- A amostra controlada possui top e bottom, mas não a coorte mediana obrigatória nem confirmação independente aprovada.
- O código e os caminhos são específicos de `grace-grit-love`; ainda não existe domínio genérico por canal.

### Produção

- As duas EDLs legadas não possuem nenhum dos 14 campos obrigatórios de `production_blueprint.schema.json` nos nomes/estruturas exigidos.
- O longo não pode renderizar: 45 de 50 planos não possuem asset selecionado e evidência de licença.
- O Short passou gates legados, mas não passou o novo conjunto formal de gates do blueprint e não tem aprovação humana.
- Não existe catálogo geral de assets indexado com hash, licença, restrições, reutilização e validade.

### Direitos

- O vídeo `5-zdruoQKlM` possui registros contraditórios no histórico: `verified_cc` no seed, depois `not_verified` e `indeterminate` em auditorias técnicas do mesmo dia.
- O registro principal continua `verified_cc`, portanto o gate atual pode aceitar um ativo apesar de evidência posterior inconclusiva. Isso é bloqueador para qualquer nova produção até reconciliação explícita.
- Percentuais de material-fonte são controles editoriais internos e não aprovam direitos nem monetização; o próprio README reconhece isso.

### Analytics e previsibilidade

- Há tabela e CLI para snapshots, porém ela contém zero linhas. O estado real é `prior_only`.
- Não existe adapter implementado para YouTube Analytics; dados privados precisam ser registrados manualmente.
- `daily-latest.md` está coerente com zero amostras e retém probabilidades.
- `forecast-21d.json` e `forecast-21d.md` são artefatos antigos, datados de `2026-09-01`, com AVD e cadência diferentes do relatório diário atual. `scripts/daily.ps1` não os regenera; portanto estão obsoletos e não devem ser citados como estado atual.

### Tooling, reprodutibilidade e testes

- FFmpeg e ffprobe estão disponíveis em `C:\ffmpeg\bin`.
- `yt-dlp 2026.8.19`, `faster-whisper 1.2.1`, `Pillow 12.3.0`, clientes Google e PyYAML estão instalados.
- Tesseract, PySceneDetect e OpenCV não estão instalados/detectados.
- Não há implementação localizada de OCR, `jsonschema`, retry/backoff, idempotência por hash ou adapter de Analytics.
- Dependências usam limites mínimos, não versões fixadas; scripts contêm caminhos absolutos da máquina.
- Os 14 testes não validam os schemas novos, integrações externas, reconciliação de direitos, render end-to-end ou idempotência.
- Não há Git; revisão de diff e rollback dependem do backup manual desta fase.

## 9. Divergências entre o projeto atual e o contrato mestre

| Contrato mestre | Estado atual | Classificação |
|---|---|---|
| mineração temporal completa por vídeo | transcript, clips e openings parciais | lacuna crítica |
| padrão-ouro humano antes da automação | não existe no novo schema | lacuna crítica |
| hooks em quatro janelas | heurística agregada | divergente |
| coortes winner/median/weak | top/bottom apenas | incompleto |
| `ChannelModel` validado | modelo legado incompatível | migração necessária |
| `ProductionBlueprint` validado | EDLs legadas incompatíveis | migração necessária |
| ativos permitidos e manifesto completo | longo com 45 slots bloqueados; direito conflitante | bloqueador |
| adapters substituíveis | módulos concretos e caminhos fixos | incompleto |
| analytics próprio | estrutura sem dados | indisponível |
| fases aprovadas pelo usuário | trabalho prévio existe sem gates do kit | não aprovado pelo novo contrato |
| local-first | atendido parcialmente | preservável |
| publicação controlada | dupla trava e aprovação | atendido |

## 10. Riscos de perda, conflito e operação

1. **Crítico — direitos contraditórios:** um status seed favorável pode prevalecer sobre auditoria posterior inconclusiva.
2. **Alto — falsa equivalência:** score 100% do Short e preflight 11/11 do longo são gates legados, não aprovação sob os schemas novos.
3. **Alto — ausência de Git:** alterações não têm histórico granular ou rollback por commit.
4. **Alto — mídia incompleta para padrão-ouro:** intros de 15 s não permitem mineração take por take do vídeo completo.
5. **Médio — forecasts obsoletos:** arquivos com nomes correntes contêm premissas históricas.
6. **Médio — dependência da máquina:** paths absolutos e voz SAPI reduzem portabilidade.
7. **Médio — testes insuficientes para os novos contratos:** os testes atuais podem passar enquanto saídas continuam incompatíveis.
8. **Médio — custo operacional invisível:** tempo de revisão, energia, armazenamento e hardware ainda não são medidos.

## 11. Ferramentas e credenciais esperadas

### Disponíveis

- Python 3.12 no `.venv`;
- FFmpeg/ffprobe;
- yt-dlp;
- faster-whisper;
- Pillow;
- bibliotecas Google para upload;
- SQLite;
- Node/runtime usado pelo gerador do workbook.

### Ausentes ou não implementadas

- Tesseract OCR;
- PySceneDetect;
- OpenCV;
- validador JSON Schema integrado ao projeto;
- adapter oficial de YouTube Analytics;
- providers/interfaces definidos em `docs/06_TOOLING_AND_INTEGRATIONS.md`.

### Credenciais

`credentials.json`, `token.json` e `.env` não existem na raiz. Nenhum segredo foi lido ou exposto. Essas credenciais não são necessárias na Fase 1 se a entrada for mídia local autorizada.

## 12. Proposta de incorporação dos contratos e schemas

1. Manter o código e os artefatos atuais como `legacy baseline`, sem promovê-los a fases aprovadas.
2. Usar os schemas do kit como contratos canônicos para novos artefatos.
3. Não converter automaticamente dados legados: cada migração deve manter origem, evidência e campo `UNKNOWN` quando faltar prova.
4. Na Fase 1, criar o padrão-ouro fora das tabelas legadas, em fixtures versionáveis e revisáveis.
5. Na Fase 2, implementar adapters e validação; só depois mapear o SQLite atual para os contratos.
6. Resolver a política de “estado atual de direitos” antes de qualquer novo download/render, com precedência segura para o registro mais restritivo até revisão.
7. Corrigir a política de artefatos de forecast em fase própria: gerar atomicamente relatório/JSON do mesmo estado ou nomeá-los por execução.
8. Inicializar Git somente após decisão do usuário, pois isso altera a governança do projeto e não era necessário para concluir esta auditoria.

## 13. Critérios da Fase 0

| Critério | Estado | Evidência |
|---|---|---|
| nenhum código de domínio novo | aprovado | somente documentos e contratos adicionados/atualizados |
| nenhuma conclusão sem inspeção | aprovado | testes, SQLite, schemas, arquivos, hashes e toolchain verificados |
| trabalho existente preservado | aprovado | README preservado; backup criado; nenhum código/dado sobrescrito |
| conflitos sinalizados | aprovado | direitos, schemas, forecasts, dependências e ausência de Git registrados |
| plano adaptado da Fase 1 | aprovado | `docs/PHASE_1_PLAN.md` |
| aprovação humana para avançar | bloqueado | depende do usuário |

## 14. Comandos e verificações executados

- inventário com `rg --files` e PowerShell;
- `git status --short --branch`;
- leitura integral do ZIP via `System.IO.Compression`;
- backup com `Compress-Archive` e `Get-FileHash`;
- teste unitário via `python -m unittest`;
- `scripts/run.ps1 catalog channels` e `catalog sources`;
- inspeção SQLite somente leitura;
- `Get-Command`, `ffmpeg -version`, `ffprobe -version` e `pip show`;
- parsing dos JSONs e comparação de campos obrigatórios;
- hashes SHA-256 da mídia e do render;
- inspeção de estados de produção, licença, amostra, forecasts e shot list.

## 15. Encerramento

- Resultado: Fase 0 tecnicamente concluída e aguardando revisão.
- Critérios aprovados: todos os critérios executáveis desta fase.
- Critérios reprovados: nenhum.
- Critério bloqueado: aprovação expressa do usuário.
- Custo externo observado: `R$ 0,00`; custos de máquina/tempo não foram medidos.
- Próxima fase sugerida, ainda não autorizada: Fase 1, conforme `docs/PHASE_1_PLAN.md`.
