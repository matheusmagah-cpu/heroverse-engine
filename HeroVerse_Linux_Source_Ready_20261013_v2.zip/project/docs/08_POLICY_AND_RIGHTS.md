# 08 — Direitos, transformação e conformidade

## YPP-INAUTHENTIC-2025-07-15 — regra transversal vigente

Fonte oficial: https://support.google.com/youtube/answer/1311392?hl=pt-BR
Conferida em07/10/2026UTC. Em15/07/2025, o YouTube renomeou a política de
conteúdo repetitivo para conteúdo não autêntico, esclarecendo produção repetitiva
ou em massa; esse material já era inelegível. A política de conteúdo reutilizado
é distinta e permanece aplicável. Regras valem para o canal inteiro.

| Fase | Decisão exigida | Evidência necessária |
| --- | --- | --- |
| F0 — incorporação | Identificar lacunas sem alterar história | Origem, direitos, estado e limites das provas |
| F1 — padrão de mineração | Separar tração de autenticidade | Coortes vencedoras/medianas/fracas e contribuição real |
| F2 — minerador | Analisar, não copiar ativos de referência | Metadados/fontes/datas; risco de reutilização e produção genérica |
| F3 — observatório | Não promover outlier isolado ou fábrica de templates | Comparáveis atuais, convergência e contraprovas |
| F4 — modelagem | Extrair gramática sem reproduzir obra/identidade | Nova intenção e substância, diferenças demonstráveis entre conteúdos |
| F5 — produção | Fazer contribuição própria e verificável | Fonte/receita/composição reais, direitos e transformação; QA técnico separado |
| F6 — canal e release | Examinar arquivo e catálogo | Vídeo/áudio exatos, títulos fiéis, proveniência, variação substantiva e gates existentes |
| F7 — aprendizado | Melhorar com resultado, não nota autodeclarada | Métricas próprias comparáveis, hipótese, mudança delimitada e resultado/incerteza |
| F8 — produto | Preservar regra em cada canal | Isolamento, identidade, registros e mesma cadeia de gates; sem replicação genérica em massa |

Qualidade técnica, direitos e autenticidade são eixos distintos. Um ativo OWNED,
score neural alto, hash novo, troca de título/imagem/duração/velocidade não bastam
para atestar autenticidade. Não inventar percentual mínimo de diferença, nota
universal ou número de variações como regra oficial. Introdução/identidade
recorrentes podem existir; a substância das entregas precisa ser materialmente
variada e oferecer valor criativo, educativo ou de entretenimento.

No formato instrumental: composição, interpretação/sound design e arranjo devem
ter proveniência e propósito demonstráveis. Licença ou ausência de Content ID
não são prova de originalidade. Música longa ou imagem estática não são banidas
automaticamente, mas prolongar/reembalar a mesma composição em série não prova
variação substantiva. Similaridade musical comum também não é, sozinha, infração.
Avaliar fontes, estrutura e catálogo; não substituir avaliação por igualdade
de pixels, timbre diferente, relatório textual ou promessa de monetização.

A seleção/modelagem atuais já tratam novidade, saturação, transformação e risco
de produção genérica. A QA instrumental atual mede integridade/qualidade sonora
e visual: isso NÃO é uma certificação automática de autenticidade ou aprovação
YPP. A comparação substantiva do futuro catálogo musical ainda não foi comprovada
operacionalmente. Não declarar essa lacuna implementada só por este documento.

Melhoria contínua usa o motor existente, uma hipótese/variável por decisão,
evidência própria e critério de encerramento; intervenção só após causa nova.
Preservar entradas/resultados válidos. Agendamento, nome novo, turno ou desejo
de nota melhor não invalidam entrega concluída. Repetição sem mudança material
é proibida. A decisão final de monetização é do YouTube; não prometer data/RPM.

## 1. Objetivo

Permitir produção clip-based sustentável, preservando evidência de origem, licença, transformação editorial e decisões. Este documento é um controle operacional, não parecer jurídico.

## 2. Estados de direitos

- `OWNED`: produzido e controlado pelo projeto.
- `LICENSED_COMMERCIAL`: licença ou autorização explícita para uso comercial.
- `CC_COMMERCIAL`: Creative Commons compatível com uso comercial e condições registradas.
- `PUBLIC_DOMAIN_VERIFIED`: domínio público verificado para a jurisdição/uso relevante.
- `PLATFORM_REMIX_AUTHORIZED`: uso permitido pela ferramenta e pelos termos aplicáveis da plataforma.
- `EDITORIAL_REVIEW_REQUIRED`: possível uso transformativo, sujeito a revisão específica.
- `RESTRICTED`: não pode entrar na produção.
- `UNKNOWN`: origem ou direito insuficiente; não pode entrar na renderização final.

## 3. Regra de produção

Ativos `OWNED`, `LICENSED_COMMERCIAL`, `CC_COMMERCIAL`, `PUBLIC_DOMAIN_VERIFIED` e, quando aplicável, `PLATFORM_REMIX_AUTHORIZED` podem avançar após validação das condições.

`EDITORIAL_REVIEW_REQUIRED` exige registro da finalidade, quantidade usada, nova contribuição e decisão responsável. Esse estado nunca vira aprovação automática por porcentagem.

## 4. Transformação editorial verificável

O relatório deve mostrar, quando aplicável:

- novo objetivo;
- novo público/contexto;
- nova tese ou mensagem;
- nova narrativa;
- nova seleção e sequência;
- comentário, explicação, crítica, análise ou construção editorial própria;
- relação nova entre fontes;
- duração utilizada e necessidade de cada trecho;
- efeito sobre a obra original;
- direitos e restrições conhecidos.

Mudanças cosméticas entram no log técnico, mas não são usadas isoladamente como prova de originalidade.

## 5. Proibições

- assumir que alterar determinada porcentagem garante uso permitido;
- usar “dar créditos” como substituto de licença;
- remover marca d'água ou identificação de origem;
- contornar Content ID ou mecanismos equivalentes;
- esconder a origem de um ativo;
- reutilizar vídeo completo com mudanças superficiais;
- clonar voz, rosto ou identidade sem autorização;
- publicar ativo `UNKNOWN`;
- afirmar fair use/fair dealing como decisão automática.

## 6. Manifesto de direitos

Cada produção final deve possuir:

- lista completa de ativos;
- origem;
- detentor/criador quando conhecido;
- licença e versão;
- prova de autorização;
- exigências de atribuição;
- recortes e duração usados;
- data de verificação;
- responsável pela decisão;
- riscos remanescentes.

## 7. Monetização

Direitos autorais e política de conteúdo reutilizado são análises distintas. Um vídeo pode não receber claim e ainda assim ser considerado reutilizado/inautêntico para monetização. O quality gate deve verificar as duas dimensões.

## 8. Referências oficiais

- Monetização e conteúdo reutilizado: https://support.google.com/youtube/answer/1311392
- Fair use no YouTube: https://support.google.com/youtube/answer/9783148
- Mitos comuns de copyright: https://support.google.com/youtube/answer/2797449
- Licenças do YouTube: https://support.google.com/youtube/answer/2797468
- Conteúdo elegível para monetização: https://support.google.com/youtube/answer/2490020
- Biblioteca de áudio: https://support.google.com/youtube/answer/3376882

As regras e licenças devem ser verificadas novamente antes de publicação ou comercialização do produto.

## 9. Autoridade do Gestor Central

Direitos, conteúdo reutilizado/inautêntico, política e elegibilidade são gates permanentes e mais restritivos que o envelope operacional. O Gestor pode coletar evidência, bloquear, pausar e escalar; não pode presumir licença, aprovar a própria exceção, mascarar cópia, liberar ativo `UNKNOWN` ou transformar ausência de claim em autorização. Mudança de política, direito ou risco crítico exige nova evidência e a aprovação prevista.
