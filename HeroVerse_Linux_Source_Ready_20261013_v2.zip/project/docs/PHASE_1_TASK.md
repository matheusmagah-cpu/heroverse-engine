# PhaseTask — Fase 1

## Controle

- `phase_id`: `1`
- `task_id`: `phase-1-gold-standard-mining`
- `status`: `AWAITING_REVIEW`
- `authorized_by`: usuário
- `authorized_at`: `2026-09-02`

## Objetivo único

Produzir um padrão-ouro manual, temporal e verificável para mineração de vídeos longos em inglês do formato Christian Motivation, validado por `schemas/video_mining.schema.json`.

## Contexto obrigatório

- documentos: `AGENTS.md`, `docs/00_MASTER_SPEC.md`, `docs/01_EXECUTION_PROTOCOL.md`, `docs/02_MINING_SPEC.md`, `docs/07_PHASES_AND_GATES.md`, `docs/08_POLICY_AND_RIGHTS.md`, `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md`, `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md` e `prompts/01_GOLD_STANDARD_MINER.md`;
- componentes existentes: `output/modeling/grace-grit-love/model-analysis.json`, intros locais, transcripts locais, FFmpeg/ffprobe e faster-whisper;
- decisões relacionadas: D-003, D-004, D-005, D-006, D-009, D-010, D-011, D-012, D-013 e D-014.

## Entradas

| Entrada | Local | Obrigatória | Validação | Direitos/credencial |
|---|---|---:|---|---|
| Amostra exata | `docs/PHASE_1_PREFLIGHT.md` | sim | aprovação expressa do usuário | análise não concede direito de produção |
| Mídia completa | `data/modeling/grace-grit-love/full/<video_id>.mp4` | sim | hash + ffprobe + acesso público para análise | `EDITORIAL_REVIEW_REQUIRED`; produção bloqueada |
| Título e URL | manifesto da amostra | sim | snapshot público datado | público/observado |
| Thumbnail | a preservar por vídeo | sim | hash + origem | análise apenas |
| Métricas públicas | snapshot datado | sim | fonte e captura | não inclui métricas privadas |

## Saídas

| Saída | Caminho | Formato/schema | Consumidor |
|---|---|---|---|
| Manifesto | `data/gold_standard/manifest.json` | JSON | fixtures e auditoria |
| Anotações | `data/gold_standard/<video_id>/annotation.md` | template do kit | revisão humana |
| Minerações | `data/gold_standard/<video_id>/video_mining.json` | `video_mining.schema.json` | Fase 2 |
| Transcrições | `data/gold_standard/<video_id>/transcript.*.json` | bruto + revisado | evidência |
| Keyframes/takes | `data/gold_standard/<video_id>/keyframes/` + manifestos | imagens/JSON | revisão frame a frame |
| Relatório | `docs/PHASE_1_REPORT.md` | Markdown | gate humano |

## Fora de escopo

- automação em lote;
- ChannelDNA, arquétipos ou modelagem final;
- produção, renderização ou publicação;
- aprovação de direitos de produção;
- métricas privadas inventadas;
- Fase 2 ou posterior.

## Passos permitidos

1. obter aprovação da amostra exata;
2. preservar mídia, embalagem e hashes;
3. inspecionar tecnicamente;
4. preservar e revisar transcrição;
5. revisar hooks e takes frame a frame;
6. registrar OCR e elementos de tela;
7. segmentar narrativa e analisar embalagem;
8. separar observado, calculado, inferido e desconhecido;
9. validar schema, evidências e timecodes;
10. apresentar para revisão e parar.

## Ações proibidas nesta fase

- iniciar a fase seguinte;
- publicar;
- gerar custos não autorizados;
- remover requisitos;
- substituir dado real por mock sem rótulo;
- usar a amostra como biblioteca de produção.

## Critérios de aceitação

- [x] schema válido;
- [x] duração e timecodes consistentes;
- [x] hooks obrigatórios preenchidos;
- [x] takes sem sobreposição inválida e com cobertura explicada;
- [x] evidências resolvíveis;
- [x] transcrição bruta preservada;
- [x] fatos e inferências separados;
- [x] nenhum direito presumido;
- [x] comparação com padrão-ouro documentada;
- [x] execução reproduzível;
- [ ] revisão humana do gate aprovada pelo proprietário — aguardando.

## Testes obrigatórios

- [x] unitários para invariantes temporais;
- [x] integração local de mídia;
- [x] schema Draft 2020-12;
- [x] fixture/padrão-ouro;
- [x] exemplo real autorizado;
- [x] revisão do manifesto e integridade; `git diff` indisponível porque o diretório não é repositório Git.

## Evidências esperadas

- hashes de mídia, thumbnails, transcripts e keyframes;
- relatórios ffprobe;
- quatro janelas de hook por vídeo longo;
- timecodes e keyframes de cada take;
- referências de evidência existentes;
- estados de direito separados da análise editorial.

## Condição de parada

O processamento está autorizado para os quatro vídeos da D-012, exclusivamente como padrão-ouro de análise. Ao concluir as minerações, marcar a Fase 1 como `AWAITING_REVIEW` e não iniciar a Fase 2.
