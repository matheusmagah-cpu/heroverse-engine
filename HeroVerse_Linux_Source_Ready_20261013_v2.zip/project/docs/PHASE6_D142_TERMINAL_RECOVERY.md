# D-142 — Recuperação do executor após render terminal rejeitado

## Quarta tentativa — testes sem falhas, manutenção recusada pelo parser

`maintenance-request-20260906T0744409944736Z-b2e5f613`: COMMITTED07:45:25Z, unittest858/712,355s/`OK (skipped=1)`, exit0. `daily.ps1` recusou o sufixo legítimo de skip; faltam pós-snapshot, receipt final e D-116, portanto a tentativa continua FAIL. Transcript preservado em `unittest.stderr.log`. D-145 corrige o parser e consumidores antes de nova execução.

Recovery07:58:06.8436967Z: `recovery_failure=null`, PID17880 após18684. Principal confirmou17880 vivo/início07:57:52Z. Prova WAIT original e jobc516SUCCEEDED preservados. Recuperação não é aprovação do segundo vídeo, conclusão de fase ou autorização de mídia.

Estado inicial desta incorporação: implementação em disco, revisão e preflight; implantação ainda não executada. Fase 6 IN_PROGRESS. Este documento não aprova o segundo vídeo nem declara operação produtiva concluída.

## Resultado posterior da segunda manutenção — COMMITTED, regressão FAIL, runtime recuperado

Terceira tentativa posterior `maintenance-request-20260906T0700042896853Z-7f85ce4d`: COMMITTED07:01:01Z,845testes501,312s,3FAIL/3ERROR/1ignorado. Causa comum de integração GOAL no verificador D-116 corrigida em D-143; não tratar como fixturesemOCR. Recovery comprovou18684ativo, início07:09:51Z e recovery_failure=null. A prova WAIT originalce5aa672 permaneceu intacta e foi reutilizada, não reconstruída. Registros desta e das tentativas anteriores são históricosFAIL; nova manutençãointegral permanece requerida.

Request `maintenance-request-20260906T0605485316939Z-15127eb1`: handshake/parada verificados; migração COMMITTED às06:06:29.689695Z, preservando c516 SUCCEEDED, fila e arquivos históricos. Mídia1.3 WAITING vinculada à prova `phase6-post-effect-visual-wait-5735bce11725beb0c15c44b5.json`, SHA `ce5aa672f5e0834549f17386a05a94e8d0a5efac5b908540171796745c6396e8`. Erro histórico arquivado byte a byte, sem remoção genérica de falhas.

Compileall passou. Regressão:815testes/416,829s,2falhas+5erros+1ignorado. A tentativa permanece FAIL. `finally` recuperou processo7096, início06:13:52.017942Z; receipt06:14:00Z registra recovery_failure=null, tarefa/processo/lock/console coincidentes, duplicata73bloqueada e energiaPASS. Contraprova posterior confirmou7096 vivo. Isso não é sucesso integral D-116 nem motivo para desfazer a migração válida.

As falhas de testes foram investigadas: dois casos mecânicos não isolavam o gate semântico anterior; cinco fixtures de publicação ainda usavam binding/evaluator antigos sem OCR. Correções preservaram verificadores reais e controles negativos. Grupo85/85 PASS; revisão final para PNG decodificável recebeu6/6 PASS. D-143 corrige a prioridade executiva que ignorava a espera. Uma nova regressão estável e prova pós-reinício ainda são necessárias.

## Correção posterior da escrita — focal, antes da segunda tentativa

`phase6_reporting.py`, writer `phase6-executive-atomic-writer-v2`, agora utiliza temporário exclusivo no mesmo diretório, UTF-8 binário, flush/fsync e `os.replace`. PermissionError recebe no máximo seis tentativas com espera total máxima de 0,75 s; outras falhas não recebem retry indevido. A limpeza restringe-se ao próprio temporário, preservando destino anterior e arquivos concorrentes.

Contraprova principal: `.venv/Scripts/python.exe -m unittest tests.test_phase6_reporting_atomic_write tests.test_phase6_reporting -v`, 28/28 PASS em 62,375 s. Inclui concorrência real, colisão, erro transitório/persistente, falha de flush, UTF-8 e integração do materializador. São os mesmos testes reportados anteriormente pelo executor; não somar contagens.

Limite: cada arquivo é atômico, o par JSON/Markdown não. A falha da segunda escrita propaga erro e mantém alerta, sem alegar sucesso integral. A manutenção deve conferir o par exato derivado e tolerar somente a convenção de newline produzida pelo escritor correspondente. O ator específico que causou o WinError 5 antigo não foi identificado; a fragilidade do temporário fixo/ausência de retry foi identificada e corrigida.

## Resultado da primeira tentativa real — FAIL preservado

Request `maintenance-request-20260906T0534024835208Z-f3c00b33`, iniciado às05:34:02Z. Preview final anterior `local-runtime-preview-5997bcff2bea1504f311830b`, 05:33:45.220689Z, passou nas12 fontes. Após handshake/parada, a migração falhou no guard de correlação do control-cycle-error antes dos commits. Não houve regressão integral, migração aprovada ou final PASS.

O registro não era falha de schema de prediction: era WinError5 na substituição do temporário fixo do executive-status, ocorrido às02:49:22.292999Z. A preview não chamava esse mesmo guard e portanto não antecipou a falha. Correção exigida: preview e commit compartilham checagem de correlação, erro estranho continua bloqueando, e a escrita do painel recebe temporário exclusivo/retry limitado com teste de preservação. Só uma prova estreita de erro histórico superado pela escrita correspondente permite arquivamento transacional; não remover o arquivo manualmente.

Recuperação automática confirmada: processo22832/tarefaRunning/lock e console coincidentes/duplicata73/energiaPASS, às05:36:35.4550212Z. Processo verificado vivo independentemente e barreiras request/ack ausentes. O outcome da tentativa permanece FAIL, recovery_failure=null. Caminho: `output/runtime/gestor-central/maintenance-runs/maintenance-request-20260906T0534024835208Z-f3c00b33/recovery-outcome.json`. Fontes/código não foram revertidos nem dados apagados; novo runtime carregou o código em disco sem que isso substitua o aceite ainda pendente.

## Causa e limite da correção

A cadeia histórica termina em `job-c516db5685acbbb423199bc1`, SUCCEEDED, tentativa 1, sem lease. O manifesto prova que o processamento local terminou, não que o vídeo passou no QA. O executor residente tentava reconciliá-lo como candidato ainda executável e emitia `QueueConflict: current media job is not an unfinished executable candidate` em vez de conservar a espera explícita pela correção audiovisual.

O derivado novo não reabre esse job, não cria sucessor, não publica o render rejeitado e não aprova sua qualidade. Ele registra WAITING / POST_EFFECT_VISUAL_REMEDIATION_REQUIRED, ligado à cadeia e às fontes exatas. Alteração de tail, lease, checkpoint, input ou prova exige nova reconciliação; um estado antigo de espera não pode esconder um sucessor real.

## Implementação e fontes

- `hero_engine/phase6_media_remediation_wait.py`: resolver read-only da cadeia histórica exata, validação dos receipts/inputs/manifests/90 receipts de segmentos e do audit visual bloqueante; derivação e verificação da prova imutável de espera.
- `hero_engine/phase6_media.py`: guard antes de capacity, claim, síntese e render, reabrindo a prova e o journal de migração COMMITTED antes de preservar WAITING.
- `hero_engine/maintenance_protocol.py`: preview read-only antes de handshake e migração transacional dos derivados somente após parada verificada; preimages, candidatos, journal PREPARED, commit, outcome e rollback.
- `hero_engine/phase6_reporting.py`: explicitar produção bloqueada sem confundir essa condição conhecida com falha de execução do Gestor. Qualquer erro adicional continua crítico.
- `hero_engine/phase6_maintenance_verification.py` e schemas relacionados: validar o binding opcional da migração sem invalidar receipts históricos.
- Testes de linhagem, drift, integridade, ausência de commit, atomicidade, rollback, reporting e continuidade do Gestor. Fixtures não são prova de deployment.

## Correção detectada antes da parada

Após uma mudança no reporting, o preview read-only recusou a versão com `EXECUTIVE_VIEW:ATTENTION_REQUIRED`: o ciclo exige separar falha de execução de espera legítima. Um preview anterior à última mudança não comprova o conjunto atual. A correção deverá usar condição explícita e restrita no painel/schema, com publicação falsa e motivo visível, nunca ignorar todos os ATTENTION_REQUIRED ou reduzir os gates críticos.

## Done when da implantação

Preflight da segunda tentativa: `local-runtime-preview-60979162a3c56c0ca7ba2405`, contraprova principal em `2026-09-06T06:05:04.091766Z`, 12/12 fontes válidas, zero blockers e 12 checks de correlação do erro histórico SHA `1184c5b3d869e30c1c012e4e5f59fdf4dea1ae5c9bd288be59bca3dc9b9fa6b3`. Zero API, fila, proof, runtime ou receipt escritos pelo preview. Código/testes congelados; grupo focal do executor 76/76 PASS em 56,004 s, writer/reporting 28/28 PASS pela contraprova principal. O parser PowerShell passou independentemente. `daily.ps1` executa e valida o preview automaticamente antes de request/suspensão/parada, sem depender de comando manual. A segunda implantação ainda não foi executada neste registro; sucesso depende dos itens abaixo.

Preflight final anterior à implantação: `local-runtime-preview-5ed4a17e1b1a4f6af173ffdb`, observado pelo responsável principal em `2026-09-06T05:20:22.194838Z`. Doze fontes/schema válidos, zero blocker, executivo ACTIVE_OBSERVING_PRODUCTION_BLOCKED, mídia WAITING/POST_EFFECT_VISUAL_REMEDIATION_REQUIRED; zero API, escrita de fila, proof, runtime ou receipt. Regressão focal dos consumidores reportada pelo executor: 109/109 PASS em 66,608 s; código/schema/testes revisados pelo responsável principal. O status novo é permitido apenas para a atenção única e exata da remediação, com o input histórico correspondente e produção/publicação não autorizadas; alerta adicional permanece ATTENTION_REQUIRED. O verificador pós-manutenção exige a mesma migração vinculada ao receipt. Fixtures de alias latest usam bytes da fonte imutável, não um snapshot vivo que possa evoluir legitimamente.

1. Código/testes congelados e preview atual válido para 12/12 fontes, sem escrita operacional.
2. `scripts/daily.ps1` comprova identidade da cadeia, handshake, janela livre de ação protegida e parada segura.
3. Migração preserva fila, cota e efeitos; falhas restauram bytes anteriores. A regressão integral usa snapshot estável e registra contagem, logs, duração e hashes.
4. Recuperação em finally e prova viva posterior D-116: tarefa, processo, lock, console, singleton, energia, novo ciclo 12/12 após o receipt e snapshots exatos das cinco fontes.
5. Após liberar a barreira, o executor conserva WAITING verificado e o observador continua independente. Vídeo 2, sucessor e publicação continuam bloqueados até suas próprias provas.

## Próxima correção produtiva, fora da autoridade deste WAIT

Formalizar remediação audiovisual que componha deltas explícitos de fontes concretas, voz contínua, retiming e captions, preservando o protocolo TOPIC_ANGLE e seus invariantes. A banda de duração é 207.750–286.250 ms; o horizonte histórico exato é apenas baseline. Não alterar os hooks ou copy por conveniência, não somar WAVs antigos para alegar nova prosódia e não usar timestamps estimados do ASR como alinhamento acústico exato. As três amostras existentes podem receber prova de reutilização, sem repetir TTS, mas seus estados de qualidade não são promovidos pela reutilização.

Uma única geração nova deverá integrar essas correções antes do render completo. O caminho antigo e as classes de remediação pré-efeito/somente visual permanecem verificáveis e não recebem autoridade ampliada silenciosamente. Custos técnicos adicionais: R$ 0,00. Sem API paga, instalação, gasto ou publicação por esta correção.
