# D-136 — Prevenção de retrabalho antes do processamento pesado

Estado: implementação e provas focais em disco; **deployment e aceite integral pendentes**. Fase 6 IN_PROGRESS. Esta entrega não aprova o Vídeo 2 e não altera o experimento, direitos, custo ou publicação.

## Causa e mudança concreta

O TakePlan determinou `NAME / TEST / CHOOSE` em take-003, enquanto Bible, grammar e renderer conservaram `TRUTH / RESPONSIBILITY / TODAY`. A comparação ocorria tarde. O texto nulo de take-002 também havia sido convertido em `None`; D-129 corrigiu essa conversão, com frame diagnóstico verificado.

`phase6_visual_preflight.py` recompõe os filtros reais de cada take em diretório temporário isolado, sem FFmpeg, TTS, OCR, modelo ou API. Compara texto planejado e gerado, identidades, cobertura/ordem, timeline, framework, tipo de texto, obrigatoriedade do texto por tratamento e tamanho mínimo da fonte.

A nova política diferencia tratamentos textuais (HOOK_STAMP, HOOK_FRAMEWORK, SCRIPTURE_SEQUENCE, FRAMEWORK_STEP, KEYWORD_PUNCH, SECTION_CARD, PAYOFF_RESOLUTION) de HOOK_QUESTION com texto opcional e ACTION_EVIDENCE/CINEMATIC_BODY sem texto principal. A ausência de texto nos primeiros é uma violação do contrato preventivo novo, não uma afirmação de defeito observado por OCR. Strings legítimas, incluindo frases com “None”, não são apagadas.

No compiler, falha preserva os cinco arquivos existentes de produção e ocorre antes de archive/overwrite. A evidência PROPOSED congela cópias endereçadas por conteúdo, apenas no diretório de auditoria. Ela nunca libera execução de mídia.

No executor, a ordem é: verificar autoridade dos inputs → preflight visual → capacidade → prova de voz → fila/claim → render strict → QA independente. A verificação inicial da autoridade ainda pode ler/hachar ativos; o preflight não é apresentado como anterior a toda leitura de integridade. Contrato visual inválido não inicia capacity, fila, síntese ou render.

O runtime 1.2 e os novos checkpoints prendem ID, caminho, SHA-256 e status do preflight. O verificador reabre schema e fontes, recompõe receita/resultado/ID, verifica filename e caminho confinado. O recipe ID é compartilhado por cache, mídia e preflight. A identidade executada inclui bytecode dos helpers transitivos de filtro, texto, escape de caminho e fonte. Escrita imutável usa temporário, flush/fsync e hardlink sem sobrescrever; falha não publica arquivo parcial.

## Contraprova real

- Audit: `output/operations/phase6/visual-preflight/audits/visual-preflight-394d5a2f84d56d4a3570519f.json`.
- SHA-256: `a35f3479d434e4521dade63739372de1d7e28f2b6327466084d351e5a362c645`.
- 90 takes recompostos; resultado BLOCKED; 0,791407 s para materializar e reverificar na medição local.
- 1 divergência plano/Bible; 1 divergência plano/renderer; 16 ocorrências de tamanho de fonte abaixo do mínimo da Bible; 23 ausências de texto exigido pela nova regra. São 41 findings em 25 takes, não 41 defeitos visuais independentes: o mesmo problema pode produzir mais de uma evidência.
- Fontes de 48 px no framework e 30 px em badges conflitam com o mínimo vigente de 54 px. A nova verificação não altera o mínimo para aprovar a receita.
- `pixel_validation=NOT_EXECUTED`; `publication_authorized=false`; custo técnico adicional R$ 0,00.

O render anterior `render-phase6-1f4cb19d7dee654db8bd` consumiu 4.506,740096 s (cerca de 75,1 min), segundo seu manifesto. Comparar esses tempos demonstra que esta checagem é muito mais barata que renderizar o candidato inteiro; **não prova economia já realizada**, taxa de sucesso futura ou ausência de outros defeitos. O render histórico continua preservado, com `publication_approved=false`.

## Critérios verificáveis

Verificações concluídas nesta incorporação (grupos com sobreposição; não somar como testes únicos):

- `python -m unittest tests.test_phase6_visual_preflight tests.test_phase6_renderer_recipe tests.test_media_lease_heartbeat tests.test_phase6_queue tests.test_phase6_media_authority -q`: 67/67 PASS em 14,657 s, incluindo os 17 testes atuais do preflight.
- `python -m unittest tests.test_phase6_visual_preflight tests.test_phase6_media tests.test_phase6_quality -q`: 32/32 PASS em 88,874 s; executado antes de adicionar os últimos três testes preventivos e renomear a fixture de encoder, sem mudança posterior da lógica produtiva.
- `python -m unittest tests.test_phase6_production tests.test_phase6_integrity_hardening`: 43/43 PASS em 82,100 s, executados pelo agente de testes; código revisado pelo responsável principal.
- `py_compile` dos cinco módulos produtivos envolvidos e seis arquivos de testes: PASS.
- Uma rodada inicial de 93 testes teve seis falhas e dois erros por novas pré-condições e fixture OCR antiga. As fixtures foram atualizadas com escopo unitário explícito, e o teste negativo de integração real foi preservado. Isso não representa QA do vídeo ou regressão integral do projeto.

1. Divergência real de contrato produz BLOCKED antes de Queue/TTS/FFmpeg: coberto por teste com cópia exata dos inputs e executores pesados proibidos.
2. Compiler bloqueia sem archive/overwrite de produção: teste real com hashes/bytes anteriores e receipt PROPOSED.
3. Render strict não contorna a barreira: teste negativo antes de criar render-work.
4. Texto nulo não é convertido; frase legítima não é mutilada; fonte ausente, tipo inválido, IDs duplicados/path-like, mudança de ordem/identidade/gramática bloqueiam.
5. Adulteração com hash atualizado não passa: resultado, ID e fontes são recompostos; schema e caminho também são verificados.
6. Falha de storage não deixa receipt parcial; replay exato não duplica artefato e conteúdo divergente não sobrescreve evidência.
7. Preflight PASS nunca substitui OCR D-131, movimento, áudio, direitos, capacidade ou release. Teste de encoder com `strict=False` é fixture técnica, não aceite de produção.

## Próximo trabalho dentro da Fase 6

1. Resolver os contratos contraditórios por correção versionada, mantendo intactos os inputs, receita, experimento e renders históricos. Não corrigir apenas o rótulo PASS/BLOCKED.
2. Completar a remediação pós-efeito e namespaces de geração: D-134/D-135 são peças testadas, não o sucessor completo. Preservar voz válida somente com verificação exata e capacidade atual.
3. Depois de o contrato passar, produzir provas curtas dos hooks e de cada tratamento usado, com fontes/timing/voz reais e avaliação independente. Os testes sintéticos não substituem essas provas. Ainda não há receipt desse gate integrado ao job; não declarar essa etapa pronta.
4. Executar deployment/manutenção segura, regressão integral e prova viva D-116; depois render completo, QA, release e publicação conforme a cadeia autorizada.

## Medição do acerto de primeira

- Taxa de aprovação na primeira tentativa: unidades que passam todos os gates na primeira avaliação independente / unidades com avaliação encerrada, com versão e janela definidas.
- Retrabalho pesado: execuções completas adicionais por unidade, causa e tempo de processamento medido; cache válido e tarefas retomadas não devem ser contados como nova unidade.
- Efetividade preventiva: violações detectadas antes de síntese/render, por regra e take, sem somar findings correlacionados como falhas independentes.
- Esses indicadores agregados permanecem **UNAVAILABLE** enquanto não houver instrumentação e amostra reconciliadas. Nenhuma porcentagem de “acerto de primeira” foi fabricada. O audit individual já comprova a detecção antecipada descrita acima.
