# Comando corretivo complementar — Gestor Central Autônomo

## Envelope financeiro técnico imutável

**CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.** O Gestor rejeita ferramenta, API, domínio, servidor, armazenamento, trial, assinatura ou automação que possa cobrar. Todo adapter deve expor cota, consumo, renovação, margem de segurança, risco de cobrança e fallback gratuito/local; ao aproximar-se da margem, o Gestor troca o adapter ou bloqueia a tarefa. Falhar em qualidade mantém a capacidade `BLOCKED`. Somente mídia futura no YouTube Promote pode ter orçamento, após autorização expressa e sem financiar componentes técnicos.

## Instrução de incorporação

Incorpore integralmente este comando ao projeto que já está em andamento. Ele esclarece e fortalece o requisito de Inteligência Contínua enviado anteriormente. Não apague, resuma, substitua ou invalide trabalho, regras, fases, schemas, gates, decisões ou implementações existentes.

Registre esta decisão como requisito permanente em `docs/DECISIONS.md`, ajuste a especificação principal, o plano, os contratos, os critérios de aceite e o estado da fase. Primeiro apresente o impacto da correção. Depois implemente apenas o que estiver autorizado pela fase atual e pare em `AWAITING_REVIEW`.

## Correção obrigatória

A Inteligência Contínua Viva não será apenas um módulo de aprendizado, assistente, consultor, painel, agente de recomendações ou coordenador parcial. Ela será o **Gestor Central Autônomo, cérebro operacional e fonte única de verdade de 100% do ecossistema de canais**.

Todo componente deverá operar subordinado a ela. Nenhum minerador, modelador, produtor, scheduler, agente, workflow, plugin ou integração poderá definir prioridades, alterar estratégia ou manter conhecimento paralelo fora dos contratos do Gestor Central.

O proprietário humano deverá atuar principalmente como supervisor. Ele acompanhará publicações, desempenho, alertas, custos, decisões importantes e evolução. Não deverá precisar transportar dados entre etapas, lembrar o sistema de coletar métricas, solicitar cada nova análise, escolher manualmente cada ajuste rotineiro ou explicar novamente o contexto a cada execução.

## O que o Gestor Central deverá administrar

O Gestor Central deverá gerir continuamente e de ponta a ponta:

1. objetivos, restrições, orçamento e capacidade;
2. observatório de mercado e atualização das referências;
3. seleção e priorização de nichos, canais, formatos, temas e oportunidades;
4. mineração vídeo por vídeo, frame/take por frame/take e controle de qualidade;
5. análise de hook, embalagem, narrativa, retenção, ritmo e produção;
6. comparação entre vencedores, medianos e fracos;
7. ChannelDNA, arquétipos e regras de geração;
8. planejamento editorial e calendário multicanal;
9. títulos, thumbnails, hooks, roteiros, blueprints e variantes;
10. busca permitida de ativos, montagem, QA e pacote de publicação;
11. filas, agendamentos, dependências, retries, falhas e reprocessamentos;
12. coleta e validação de métricas públicas e privadas autorizadas;
13. atribuição dos resultados às versões exatas de cada elemento;
14. geração e priorização de hipóteses;
15. desenho e acompanhamento de experimentos;
16. diagnóstico, otimização e aplicação das regras aprendidas;
17. custos, produtividade, gargalos e capacidade;
18. separação completa entre canais, nichos, identidades e ativos;
19. versionamento, memória, auditoria, segurança e rollback;
20. previsões, confiança, incerteza e relatório executivo para o proprietário;
21. evolução e melhoria contínua de todos os módulos subordinados.

## Autonomia operacional real

Implemente dois níveis claramente separados:

### 1. Envelope operacional aprovado

O proprietário define e aprova previamente:

- canais e objetivos;
- orçamento e limites de custo;
- fontes e licenças permitidas;
- cadência e janelas de publicação;
- políticas de conteúdo e risco;
- métricas prioritárias;
- limites de experimentação;
- ações que podem ser executadas automaticamente;
- ações que exigem aprovação específica;
- condições de pausa e emergência.

Dentro desse envelope, o Gestor Central deve operar sozinho: observar, planejar, priorizar, distribuir tarefas, validar entregas, corrigir falhas, coletar resultados, aprender e preparar o próximo ciclo.

### 2. Ações protegidas

Ações fora do envelope, gastos acima do limite, novas credenciais, mudanças estratégicas, exclusões, novas fontes de risco, alteração de direitos ou publicação ainda não autorizada devem ser bloqueadas e encaminhadas ao proprietário.

Não transforme o gate humano em dependência para cada microdecisão. O objetivo é supervisão por exceção, com autonomia rotineira dentro de limites claros.

## Aprendizado real e obrigatório

O sistema não poderá afirmar que aprendeu somente porque guardou dados, executou uma IA ou produziu sugestões. Aprendizado real exige o ciclo completo e rastreável:

`observação -> baseline -> hipótese -> previsão anterior ao teste -> experimento -> resultado -> avaliação -> atualização versionada -> aplicação futura -> nova medição`

Para cada aprendizado, registre obrigatoriamente:

- pergunta ou problema;
- escopo do canal e arquétipo;
- evidências favoráveis e contrárias;
- origem e qualidade dos dados;
- baseline aplicável;
- hipótese falsificável;
- previsão registrada antes da ação;
- confiança e intervalo de incerteza;
- variável modificada;
- fatores mantidos constantes;
- tamanho de amostra e janela;
- resultado observado;
- diferença entre previsão e resultado;
- classificação final;
- regra anterior e nova versão;
- onde a regra poderá ser aplicada;
- onde ela não poderá ser aplicada;
- aprovador quando necessário;
- plano de rollback;
- resultado da aplicação seguinte.

Use os estados:

- `CANDIDATE`;
- `TESTING`;
- `SUPPORTED_LOCAL`;
- `TRANSFER_CANDIDATE`;
- `SUPPORTED_GENERAL`;
- `INCONCLUSIVE`;
- `SUSPENDED`;
- `REJECTED`.

Um vídeo isolado não pode transformar hipótese em regra. Resultado inconclusivo não pode ser apresentado como melhoria. Evidência contrária deve reduzir confiança, suspender ou rejeitar a regra. O sistema precisa aprender também com falhas.

## Aprendizado da própria qualidade de análise

Não aprenda apenas sobre conteúdo. Meça e melhore o próprio minerador e o próprio raciocínio.

Mantenha um conjunto padrão-ouro revisado por humanos e compare cada versão automática contra ele. Registre, por campo e por tipo de vídeo:

- acerto de timestamps;
- qualidade da transcrição;
- precisão de OCR;
- fronteiras de takes;
- classificação da função narrativa;
- decomposição dos primeiros segundos;
- identificação de promessa, prova e payoff;
- concordância entre análise automática e padrão-ouro;
- erros, omissões, falsos positivos e divergências.

Quando uma nova versão do minerador for criada, execute regressão no padrão-ouro. Não promova uma versão que melhore um campo e degrade silenciosamente outro. Nenhuma análise imperfeita pode ser tratada como verdade sem classe de evidência e confiança.

## Previsibilidade mensurável

O sistema deverá construir previsibilidade, não prometer certeza absoluta sobre o mercado.

Antes de cada publicação ou experimento, registre uma previsão contendo:

- métrica prevista;
- horizonte e janela;
- valor ou faixa esperada;
- probabilidade/confiança;
- baseline de comparação;
- variáveis utilizadas;
- versão do conhecimento;
- fatores desconhecidos;
- condições que invalidariam a previsão.

Depois da janela, compare previsão e resultado. Implemente métricas de calibração adequadas, como erro absoluto/percentual para valores, cobertura dos intervalos, Brier score ou log loss para probabilidades e uplift contra baseline quando houver controle válido.

Crie um histórico imutável de previsões anteriores ao resultado. É proibido ajustar a previsão depois de conhecer o desempenho. Apresente:

- acurácia por canal, formato, métrica e horizonte;
- calibração da confiança;
- erro médio e dispersão;
- quantidade de previsões;
- condições em que o sistema prevê bem;
- condições em que ele ainda não sabe prever;
- evolução da precisão entre versões;
- comparação com um baseline simples.

Só utilize a palavra “previsível” quando a qualidade preditiva superar o baseline em amostra suficiente e continuar válida fora dos exemplos usados para formular a regra.

## Melhoria contínua comprovada

Crie um placar de melhoria com três níveis:

### Qualidade do sistema

- qualidade da mineração contra padrão-ouro;
- taxa de falhas e reprocessamentos;
- latência;
- custo por vídeo;
- intervenção humana necessária;
- precisão das previsões.

### Qualidade do conteúdo

- resposta à embalagem;
- retenção inicial;
- retenção e conclusão;
- watch time;
- inscritos e audiência recorrente;
- sinais de satisfação disponíveis;
- consistência entre vídeos do mesmo arquétipo.

### Resultado operacional/comercial

- capacidade e cadência;
- custo de produção;
- tempo até publicação;
- receita e RPM quando disponíveis;
- retorno e margem quando calculáveis;
- repetibilidade por canal e formato.

Não escolha apenas métricas que melhoraram. Mostre ganhos, perdas, trade-offs e incertezas. Separe melhoria do sistema, melhoria do vídeo e resultado financeiro.

## Fonte única de verdade e comando

Implemente:

- um estado global versionado;
- estado isolado por canal;
- Event Ledger append-only;
- fila central de objetivos e tarefas;
- prioridades e dependências explícitas;
- máquina de estados para cada execução;
- lock/eleição que impeça dois gestores centrais simultâneos;
- comandos idempotentes;
- checkpoints e recuperação após falha;
- trilha `objetivo -> decisão -> comando -> executor -> artefato -> resultado`;
- painel executivo derivado da mesma fonte de verdade.

Subagentes e automações são executores. Eles não são donos da estratégia nem da memória global.

## Rotina do Gestor Central

O Gestor Central deverá manter rotinas configuráveis:

- monitorar fontes de mercado permitidas;
- verificar novas métricas dos canais;
- validar atraso e qualidade dos dados;
- revisar filas e gargalos;
- reavaliar hipóteses abertas;
- identificar formatos em crescimento, saturação ou regressão;
- planejar próximos conteúdos dentro do calendário;
- ordenar mineração e produção;
- validar cada artefato contra schemas e gates;
- preparar e executar ações autorizadas;
- acompanhar publicações e janelas de avaliação;
- atualizar aprendizado e previsões;
- detectar incidentes e acionar recuperação;
- entregar relatório de exceções ao proprietário.

Se não houver dado novo, não invente aprendizado. Registre `NO_NEW_EVIDENCE`, mantenha o ciclo e aguarde a próxima janela.

## Prontidão contínua do canal

Antes de liberar qualquer publicação, o Gestor Central deve executar `docs/CHANNEL_READINESS_MASTER.md`. O vídeo e o canal são duas superfícies independentes de aprovação: aprovação técnica/editorial do vídeo não compensa promessa pública falsa, marca conflitante, Home vazia, catálogo sem direitos, contadores YPP indisponíveis ou integração não durável.

Toda mudança pública produz receipt, verificação externa e decisão de manter ou reverter. O Gestor aprende com resultado posterior, nunca com a mera existência da mudança. A auditoria atual passa a integrar o pacote de publicação e não pode ser ignorada por executor, scheduler ou publicador.

## Experimentos e controle

Use estratégia champion/challenger quando aplicável:

- `champion`: abordagem atual aprovada;
- `challenger`: mudança testada;
- uma variável principal por experimento sempre que possível;
- amostra e regra de parada definidas antes;
- não substituir o champion com resultado isolado;
- promover somente com evidência suficiente;
- reverter automaticamente dentro do envelope se houver regressão prevista pela política.

Registre interferências como sazonalidade, mudança de audiência, distribuição, horário, evento externo, atualização de plataforma ou falha de coleta.

## Critérios de aceitação

Não declare que o Gestor Central está pronto enquanto não demonstrar:

1. gestão de um ciclo completo sem transporte manual de informação;
2. persistência após reinício;
3. isolamento entre canais;
4. ingestão idempotente;
5. reconstrução completa de uma decisão;
6. bloqueio de ação fora do envelope;
7. execução automática de rotina dentro do envelope;
8. detecção de dado ausente ou inválido;
9. geração de hipótese com evidência favorável e contrária;
10. previsão registrada antes do resultado;
11. experimento controlado;
12. avaliação favorável, contrária e inconclusiva em fixtures separadas;
13. atualização versionada de uma regra;
14. aplicação da regra em uma produção futura;
15. medição do efeito dessa aplicação;
16. redução de confiança diante de evidência contrária;
17. rollback sem perda de histórico;
18. regressão do minerador contra padrão-ouro;
19. comparação da previsão contra baseline;
20. relatório executivo de exceções e desempenho;
21. recuperação após falha;
22. nenhuma estratégia paralela fora do Gestor Central.

Depois dos testes com fixtures, execute um piloto real autorizado. O piloto só poderá ser considerado validado quando demonstrar operação contínua, aprendizado aplicado, previsão medida, redução da dependência humana e repetibilidade. Não transforme em produto antes dessa prova.

## Entrega exigida agora

Não responda apenas “entendido” e não produza uma arquitetura genérica.

Entregue agora:

1. confirmação textual de que a Inteligência é o Gestor Central de 100% do ecossistema;
2. mapa de tudo que ficará sob sua gestão;
3. comparação entre o requisito anterior e esta correção;
4. lacunas do projeto atual para atingir esse estado;
5. arquitetura integrada ao código existente;
6. contratos de dados e estados necessários;
7. matriz de autonomia: automático, supervisionado, bloqueado e emergência;
8. protocolo de aprendizado real;
9. protocolo de previsibilidade e calibração;
10. placar de melhoria contínua;
11. testes de aceitação e demonstração ponta a ponta;
12. plano incremental, com arquivos reais a alterar e `Done when` por etapa;
13. riscos, custos e dependências;
14. atualização de `PLANS.md`, `docs/DECISIONS.md` e `docs/STATE.md`.

Respeite a fase atual. Ao final, marque `AWAITING_REVIEW` e pare. Não se autodeclare concluído: apresente evidências para revisão humana.

## Resultado não negociável

O resultado final deve ser um Gestor Central que administre toda a operação dentro das políticas aprovadas, aprenda com mercado, histórico e prática, transforme aprendizado em decisões futuras, meça sua própria melhoria, produza previsões calibradas e reduza progressivamente a necessidade de intervenção humana.

## Adendo operacional posterior — D-047 (2026-09-03)

Por autorização expressa posterior do proprietário, o Gestor passa a executar continuamente a fila das Fases 5–8, sem parar para aprovação administrativa entre fases ou escolhas técnicas reversíveis. Este adendo especializa, mas não enfraquece, o contrato:

- promoção de fase exige relatório de gates completo, artefatos reais, testes e receipt;
- avaliador e executor não podem se confundir nos gates que exigem independência;
- revisão humana de padrão-ouro, direito, política e ação externa obrigatória continua válida;
- falha técnica retorna para correção e reteste, preservando baseline e rollback;
- bloqueio externo é isolado e não paralisa frentes independentes;
- publicação sem gasto é permitida somente dentro do envelope e após direitos/QA/canal/credencial; gastos e Ads dependem de orçamento posterior;
- o proprietário recebe checkpoints informativos e revisão final, mantendo supervisão por exceção.

O proprietário acompanha, define limites e intervém por exceção. O Gestor Central observa, planeja, coordena, executa, mede, aprende, corrige e melhora continuamente.
