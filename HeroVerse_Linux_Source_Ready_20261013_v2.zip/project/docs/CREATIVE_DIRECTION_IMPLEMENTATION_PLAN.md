# Plano incremental — Diretor Criativo

## Escopo e autorização

O módulo pertence à Fase 5 e opera subordinado ao Gestor Central. A autorização subsequente do proprietário permite continuar automaticamente as etapas técnicas dentro da fase; direitos, publicação, gasto, credenciais e autoaprovação continuam protegidos.

## CD-0 — Contratos e migração

Entregas: master, 8 schemas, catálogo v2, primeiro FormatPack, dashboard, matriz, plano, decisões e estado.

Done when:

- 291 entradas reconciliadas;
- soma dos estados = 291;
- 290 `CATALOGED`, 1 `SPECIFIED`, zero capacidade inflada;
- schemas passam no meta-schema;
- pack fixture passa no próprio schema;
- trabalho anterior preservado e migração explícita.

## CD-1 — Runtime de decisão e Policy Gate (Fase 5)

Arquivos previstos:

- `hero_engine/creative_direction.py`;
- `hero_engine/policy_phase5.py`;
- `tests/test_creative_direction_phase5.py`;
- fixtures em `output/production/phase5/pilot-001/creative_direction/`.

Comportamento:

- recebe somente `central_command`;
- carrega ChannelDNA, brief, envelope, catálogo e packs;
- bloqueia packs não elegíveis;
- ranqueia por canal/público/nicho/narrativa/retenção/compreensão/custo/capacidade/evidência;
- emite `CreativeDirectionDecision` e receipt idempotente;
- prova que `PUBLISH`, gasto, direitos e pack inelegível são bloqueados.

Done when: decisão é reconstruível; alteração de sinal muda ranking sem romper identidade; nenhum estado baixo é selecionado; GC-06 e gate de pack passam.

## CD-2 — Bíblia, TakePlan e primeiro protótipo

Arquivos previstos:

- `hero_engine/continuity.py`;
- `hero_engine/take_planner.py`;
- Style Bible e TakePlan do piloto;
- adapter de voz corrigido ou fallback local que passe;
- render DRAFT e logs de custo/tempo.

Done when: todo frame pertence a um take; todo take tem função, origem, direito e retenção; hooks respeitam janelas; continuidade é mensurável; o render existe e não é chamado de validado.

## CD-3 — QA e promoção do primeiro pack

Arquivos previstos:

- `hero_engine/creative_quality.py`;
- detectores de vídeo/áudio;
- `CreativeQualityGateReport`;
- contact sheets, amostras de áudio e revisão humana;
- atualização versionada do FormatPack.

Done when: 18 gates aplicáveis, 19 defeitos, hashes, ffprobe, loudness, safe area, identidade, continuidade, direitos, originalidade e revisão humana estão resolvidos. Falha crítica mantém pack em `PROTOTYPED`/`BLOCKED`; somente evidência promove.

## CD-4 — Hardening STANDARD e produção regular

Done when: replay, regressão, fallback, observabilidade, rollback, tempo/custo e duas execuções reproduzíveis passam; pack pode alcançar `PRODUCTION_READY` ou `LIMITED`.

## CD-5 — Expansão progressiva por macrofamília

Uma macrofamília por vez, iniciando por recortes/imagens/híbrido. Cada expansão exige pack próprio, pipeline próprio e matriz aplicável. Não reutilizar prompt ou avaliação universal.

Done when: cada novo pack percorre toda a máquina de estados; painel nunca antecipa suporte.

## CD-6 — Aprendizado publicado (Fases 6–7)

Após publicação autorizada: registrar previsão prévia, métricas privadas, versão exata e avaliação; aplicar regra futura e medir novamente. Um vídeo não promove regra.

Done when: ciclo completo de aprendizado, evidência contrária, rollback, drift, saturação e custo-benefício são demonstrados.

## CD-7 — Produto multi-tenant (Fase 8)

Por cliente/canal: biblioteca, Style Bible, personagens, presets, limites, adapters, direitos, histórico, aprendizado, permissões, qualidade e bloqueios isolados.

Done when: isolamento, permissão, segurança, licenças, custos e observabilidade passam; nenhuma identidade/ativo/aprendizado privado vaza.

## Riscos de implementação

- explosão combinatória de estilos;
- julgamentos visuais difíceis de automatizar;
- modelos não determinísticos;
- direitos de modelo/input/output;
- hardware e tempo não medidos;
- sobreajuste a uma amostra;
- métricas pós-publicação ainda indisponíveis.

Mitigação: estados honestos, validação progressiva, padrão-ouro, adapters, testes por impacto, limites e gates binários.
