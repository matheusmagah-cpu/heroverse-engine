# 15 — Direção Criativa subordinada ao Gestor Central

## 1. Incorporação sem perda

Este contrato adiciona o `CreativeDirector` como executor especializado do Gestor Central Autônomo. Ele não cria estratégia paralela, não altera o `ChannelDNA`, não aprova direitos, custo, fase ou publicação e não aprende fora do ciclo governado. A cadeia obrigatória passa a ser:

`objetivo -> evidência -> decisão central -> CreativeDirectionDecision -> FormatPack -> Style Bible -> TakePlan -> executores -> render -> QualityGateReport -> resultado -> aprendizado versionado`

São preservados integralmente:

- o ChannelModel e o arquétipo aprovado da Fase 4;
- o motor editorial adaptativo, snapshots e brief da Fase 5;
- o catálogo visual de 291 entradas;
- a biblioteca clip-based e sua evidência de direitos;
- os gates de fase, política, originalidade, direitos, custo e supervisão;
- o princípio clip-based como modo principal, sem impedir híbrido quando justificado e autorizado.

O antigo `VisualStyleProfile` torna-se entrada de migração. Seus estados são substituídos, sem apagar histórico, pela máquina de estados de `FormatPack`. O perfil `cinematic_documentary_nature_broll-v1` é migrado para o primeiro pack em estado `SPECIFIED`: há contrato e ativos, mas ainda não há render aprovado. A produção da Fase 5 fica pausada nesse gate.

## 2. Arquitetura

O Gestor Central fornece objetivo, canal, público, nicho, `ChannelDNA`, brief, narrativa, orçamento, direitos, capacidade disponível e evidências. O Diretor Criativo:

1. valida inputs e escopo;
2. para produção, elimina packs incompatíveis, não autorizados ou abaixo de `PRODUCTION_READY`/`LIMITED`; um comando `PROTOTYPE` pode usar `SPECIFIED`/`PROTOTYPED` somente em perfil `DRAFT`, com publicação bloqueada;
3. compara no mínimo três candidatos quando existirem três elegíveis;
4. escolhe formato ou bloqueia a produção;
5. justifica a escolha por critérios ponderados e evidências;
6. materializa Style Bible, perfil de qualidade e TakePlan;
7. distribui ordens a adaptadores especializados;
8. valida continuidade e qualidade;
9. devolve artefatos e receipts ao Gestor;
10. após publicação autorizada, vincula resultado à versão exata do pack, pipeline, ferramenta e vídeo.

Ele não escolhe por sorteio, gosto isolado, prompt genérico, fornecedor disponível ou estética desconectada da narrativa. O `CreativeDirectionDecision` registra candidatos, inelegibilidades, trade-offs, custo, capacidade, hipótese de desempenho e evidência contrária.

## 3. FormatPack

O contrato normativo é `schemas/format_pack.schema.json`. Cada estilo catalogado possui identidade e versão; o conteúdo técnico completo torna-se obrigatório a partir de `SPECIFIED`. Um registro `CATALOGED` contém metadados, estado e lacunas, mas não finge possuir receita.

Estados permitidos:

- `CATALOGED`: identificado e versionado, sem receita;
- `SPECIFIED`: contrato e receita preenchidos;
- `PROTOTYPED`: amostra reprodutível produzida;
- `VALIDATED`: amostra passou a matriz técnica e revisão humana;
- `PRODUCTION_READY`: uso regular liberado no envelope;
- `LIMITED`: validado somente dentro de restrições explícitas;
- `BLOCKED`: impedido por capacidade, direito, risco ou política;
- `DEPRECATED`: preservado para replay, não recomendado para novas produções.

Somente `PRODUCTION_READY` pode ser escolhido sem restrição. `LIMITED` exige que a decisão prove que o vídeo está dentro de todos os limites. `VALIDATED` permite apenas teste controlado, não publicação rotineira. Todos os demais bloqueiam produção.

O pack completo registra finalidade, público, nicho, emoção, gramática visual, composição, câmera, lentes, iluminação, paleta, contraste, textura, profundidade, realismo, personagem, cenário, ritmo, take, transições, texto, áudio, prompts, negative prompts, ferramentas, pipelines, fallback, custo, tempo, hardware, riscos, testes, aprovação, exemplos, contraexemplos e aprendizado versionado.

## 4. Estados reais de capacidade

Snapshot desta incorporação:

| Estado | Quantidade | Prova |
|---|---:|---|
| CATALOGED | 290 | taxonomia v1 preservada |
| SPECIFIED | 1 | primeiro pack clip-based documentado |
| PROTOTYPED | 0 | nenhum render representativo aprovado |
| VALIDATED | 0 | matriz ainda não executada |
| PRODUCTION_READY | 0 | nenhum pack venceu todos os gates |
| LIMITED | 0 | nenhuma limitação validada em amostra |
| BLOCKED | 0 | bloqueios permanecem em nível de adapter/política até avaliação individual |
| DEPRECATED | 0 | nenhum histórico de substituição |

O painel de verdade é `docs/CREATIVE_DIRECTION_CAPABILITY_DASHBOARD.md`. Esses números não significam que os 290 itens catalogados são produzíveis.

## 5. Pipelines por macrofamília

Cada pipeline tem receita, parâmetros, adaptadores, verificações e fallback próprios; nenhum prompt ou gerador universal é aceito.

| Pipeline | Núcleo especializado | Verificações distintivas |
|---|---|---|
| Realismo e cinematografia | shot design, lente, exposição, cor, física | anatomia, luz, movimento, continuidade óptica |
| Documentário e jornalismo | provenance-first, arquivo, fonte, factualidade | fonte, contexto, reconstrução/disclosure, datas |
| UGC/POV/câmeras simuladas | linguagem imperfeita intencional e dispositivo | autenticidade não enganosa, privacidade, estabilidade intencional |
| Cartoon/2D | model sheet, line/color system, poses | line consistency, silhouette, palette, tweening |
| Anime/mangá/webtoon | character sheet, layout, timing estilizado | identidade, proporção, painel/cena, IP/artist-style |
| Animação/3D | modelagem, rig, materiais, luz, render | malha, rig, interseção, física, temporal coherence |
| Arte tradicional simulada | medium grammar, pigmento/papel, borda | consistência de material, textura, falsa atribuição |
| Design/infográfico/motion | data contract, grid, hierarquia, animação | dado correto, legibilidade, contraste, timing |
| Estéticas temáticas | world bible sobre pipeline-base | coerência de mundo, símbolos, saturação, marcas |
| Baseado em recortes | busca semântica, direitos, montagem transformativa | origem, função por take, repetição, nova narrativa |
| Baseado em imagens | storyboard, consistência, parallax/Ken Burns | resolução, continuidade, movimento artificial |
| Baseado em vídeo | shot sourcing/generation, temporal QA | flicker, ghosting, duplicação, física, compressão |
| Híbrido | compositor, color match, depth/motion match | integração, escala, luz, grão, mistura involuntária |
| Conteúdo curto | promessa instantânea, alta densidade | 0–1/1–3/3–8 s, safe areas, loop/payoff |
| Conteúdo longo | progressão, variedade controlada, capítulos | 8–30 s, fadiga visual, repetição, continuidade |

Para o piloto long-form da Fase 5, variedade visual deixa de ser inferida por contagem bruta. O gate específico do projeto mede simultaneamente participação máxima de um ativo (`<=10%`), concentração dos seis maiores (`<=55%`), reutilização total (`<=5`) e aparições da mesma fonte em qualquer janela móvel de 60 segundos (`<=3`). Esses números são limites de remediação do HeroVerse, não uma alegação de ótimo universal. A inspeção visual de amostras distribuídas pela linha do tempo continua obrigatória e pode reprovar uma sequência mesmo quando os contadores passam.
| Contínuo/ambiente/musical | loop, paisagem sonora, baixa intrusão | emenda, monotonia funcional, loudness, direitos musicais |

As receitas implementáveis serão instâncias de `schemas/macro_pipeline.schema.json`. A primeira implementação continua sendo produção por recortes em vídeo longo.

## 6. Sistema de consistência

Antes do TakePlan, cada canal recebe uma `Channel Style Bible`; vídeos com recorrência visual também recebem `Character Bible`, `Environment Bible` e fichas de objetos. O contrato está em `schemas/visual_continuity_bible.schema.json`.

O sistema fixa ou versiona: identidade, paleta, tipografia, iluminação, figurino, idade, proporções, escala, espaço, tempo, posições, câmera, lentes, seeds, referências, embeddings/identificadores, decisões e exceções narrativas. Uma mudança sem `continuity_exception` vinculada ao roteiro é `FAIL`.

A verificação automática compara, quando aplicável, histogramas/paleta, luminância, nitidez, aspect ratio, resolução, face/person identity, pose/anatomia, objetos, background, fluxo óptico, flicker, frame duplication, ghosting, lip-sync, estabilidade e estilo. Resultados automáticos nunca substituem a revisão humana do padrão-ouro.

## 7. Produção take por take

`schemas/take_plan.schema.json` registra, para cada take, início/fim, função, informação, emoção, mídia, pack, composição, câmera, movimento, iluminação, personagem, cenário, ação, texto, narração, música, SFX, transições, origem/direitos, ferramenta, custo, versão, critérios de qualidade e função de retenção.

As janelas `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s` recebem takes e gates próprios. Nenhum take pode existir apenas para preencher tela: `semantic_alignment` e `retention_job` são obrigatórios.

## 8. Quality Gates

O relatório normativo é `schemas/creative_quality_gate_report.schema.json`. Todos os gates emitem `PASS`, `FAIL`, `BLOCKED` ou `NEEDS_REVIEW` com evidência resolvível:

1. estratégia;
2. ChannelDNA;
3. narrativa;
4. hook;
5. coerência semântica;
6. estilo;
7. continuidade;
8. personagens;
9. movimento;
10. legibilidade;
11. áudio;
12. técnico;
13. direitos;
14. publicidade, quando aplicável;
15. originalidade editorial;
16. identidade do canal;
17. custo;
18. publicação.

Os gates críticos são todos, exceto `PUBLICITY` quando formalmente `NOT_APPLICABLE` pelo gate de direitos. Não existe média que compense falha crítica. Publicação automática exige todos os gates aplicáveis em `PASS`, FormatPack utilizável, aprovação/envelope válidos e autorização da fase.

Os detectores devem cobrir flicker, deformação, rostos/mãos, identidade, fundos pulsantes, movimento/física, câmera, cortes, lip-sync, frames duplicados, ghosting, interpolação, resolução, compressão e deriva de estilo. Uma imagem isolada bonita não aprova movimento nem continuidade.

## 9. Perfis de produção

Os nomes são níveis técnicos, não marketing:

- `DRAFT`: protótipo interno; marca d'água de revisão, sem publicação;
- `STANDARD`: pack `PRODUCTION_READY`, todos os gates e parâmetros regulares aprovados;
- `PREMIUM`: maior densidade de revisão, controle de cor/áudio/continuidade e amostragem humana;
- `CINEMATIC`: shot design, color management, áudio e continuidade de maior controle, apenas em packs e hardware comprovados.

Cada perfil terá resolução/fps/codec, tolerâncias, testes, revisão, custo, tempo, ferramentas e limites em `schemas/production_quality_profile.schema.json`. Perfil superior não corrige um FormatPack não validado.

## 10. Ferramentas e adaptadores

O domínio usa interfaces para fonte de vídeo/imagem, edição, composição, animação, imagem, vídeo, 3D, áudio, voz, legenda, OCR e QA. Cada adapter registra formatos, qualidade observada, custo, velocidade, limites, direitos comerciais, estabilidade, disponibilidade, privacidade e fallback. O custo técnico permitido é fixo em R$ 0,00: apenas adapters gratuitos/open source, locais, já disponíveis ou em cota gratuita sem cobrança podem ser elegíveis; proximidade da cota força fallback gratuito/local.

O inventário observado está em `docs/CREATIVE_DIRECTION_TOOL_MATRIX.md`. FFmpeg e biblioteca Commons existem localmente/no fluxo; Kokoro está instalado mas bloqueado para produção até corrigir e validar o erro de compatibilidade observado. Ferramentas pagas/API permanecem desabilitadas sem autorização.

## 11. Testes representativos

A validação progressiva está em `docs/CREATIVE_DIRECTION_VALIDATION_MATRIX.md` e cobre, por macrofamília: imagem estática, sequência, vídeo curto, vídeo longo, personagem recorrente, cenário recorrente, movimento, texto, narração, música, híbrido e render final.

Cada promoção de estado exige fixture, parâmetros congelados, hashes, relatório automático, revisão humana independente do gerador, custo/tempo observado e evidência de regressão.

## 12. Aprendizado por formato

O Gestor liga cada publicação à versão exata de `FormatPack`, pipeline, Style Bible, ferramentas, TakePlan e QualityGateReport. O ciclo segue:

`observação -> baseline -> hipótese -> previsão prévia -> experimento -> resultado -> avaliação -> nova versão -> aplicação futura -> nova medição`

Métricas possíveis: retenção por janela, AVD, conclusão, CTR/embalagem, satisfação, custo, tempo, falhas por gate, reprocessamento, erro técnico e intervenção humana. Antes de dados privados, o efeito permanece `UNAVAILABLE`. Um vídeo isolado não promove pack nem regra. Saturação, regressão e custo-benefício podem rebaixar para `LIMITED`, `BLOCKED` ou `DEPRECATED`, sempre preservando replay e rollback.

Aprendizado global requer teste de transferência e anonimização/isolamento; ativos, identidade e dados de cliente não atravessam canais.

## 13. Arquivos desta incorporação

- `docs/15_CREATIVE_DIRECTION_MASTER.md`;
- `docs/CREATIVE_DIRECTION_IMPLEMENTATION_PLAN.md`;
- `docs/CREATIVE_DIRECTION_VALIDATION_MATRIX.md`;
- `docs/CREATIVE_DIRECTION_CAPABILITY_DASHBOARD.md`;
- `docs/CREATIVE_DIRECTION_TOOL_MATRIX.md`;
- `docs/CREATIVE_DIRECTION_PIPELINE_RECIPES.md`;
- schemas `format_pack`, `creative_direction_decision`, `visual_continuity_bible`, `take_plan`, `creative_quality_gate_report`, `production_quality_profile`, `tool_adapter_profile` e `macro_pipeline`;
- `config/format_packs/fp-broll-cinematic-narration-v1.json`;
- atualizações em `AGENTS.md`, `PLANS.md`, `docs/00_MASTER_SPEC.md`, `docs/04_PRODUCTION_SPEC.md`, `docs/07_PHASES_AND_GATES.md`, `docs/14_VISUAL_STYLE_CAPABILITY_MASTER.md`, `docs/DECISIONS.md`, `docs/STATE.md`, registro visual e blueprint.

## 14. Plano incremental

O plano executável está em `docs/CREATIVE_DIRECTION_IMPLEMENTATION_PLAN.md`. Nesta incorporação, somente contratos e planejamento são autorizados. Implementação de runtime e amostras aguardam aprovação.

## 15. Done when verificável

Documentação incorporada: schemas parseiam e validam fixtures documentais; 291 entradas são reconciliadas; contagem por estado fecha; nenhum estado é inflado; plano, decisões e estado apontam para o mesmo gate.

Implementação futura: decisão reproduzível, pack elegível, Style Bible, TakePlan, adaptadores, render, gates, revisão humana, custo/tempo e receipt ligados por IDs e hashes.

## 16. Limitações atuais

- nenhum FormatPack está `VALIDATED` ou `PRODUCTION_READY`;
- não existe ainda runtime do Diretor Criativo;
- não existe Style Bible executável do HeroVerse;
- nenhum detector de consistência/defeitos foi calibrado contra padrão-ouro;
- não há resultado publicado próprio para aprendizado de formato;
- ferramentas de personagem, 3D, geração de imagem/vídeo e lip-sync não foram instaladas nem autorizadas;
- o TTS local instalado apresentou falha de compatibilidade e não está aprovado;
- custo de eletricidade, hardware, armazenamento e trabalho permanece não precificado.

## 17. Custos e dependências

Esta incorporação documental tem custo externo observado de `US$ 0,00`. A arquitetura aceita somente local, gratuito/open source, infraestrutura já disponível e API oficial em cota gratuita sem cobrança. “Fallback gratuito” não é aceito se falhar no nível mínimo; nesse caso o pack permanece `BLOCKED`. Não há autorização presente ou futura implícita de compra, assinatura, cartão, trial, servidor ou domínio.

## 18. Gate atual

O requisito está incorporado como contrato. A produção da Fase 5 não prossegue até aprovação desta mudança. O estado correto é `AWAITING_REVIEW`; isso não aprova o vídeo, não promove um pack, não autoriza publicação e não inicia a Fase 6.
