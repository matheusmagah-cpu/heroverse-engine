# Plano — Fase 4: modelador explicável

## Identificação

- Fase: 4.
- Objetivo único: produzir ChannelDNA, um FormatArchetype long-form evidenciado, GenerationSpec, matriz de evidências e hipóteses falsificáveis para o HeroVerse.
- Estado: `IN_PROGRESS`.
- Prompt: bloco “Comando da Fase 4” de `prompts/03_MODEL_CHANNEL.md`.
- Preflight: `docs/PHASE_4_PREFLIGHT.md`.

## Entradas

- arquivos: lote v2, quatro gold standards, 16 openings e schema do modelo;
- dados: títulos, datas, views, duração, takes, hooks, narrativa e classes de cobertura;
- credenciais: nenhuma;
- direitos: análise apenas.

## Entregáveis

| Entrega | Caminho |
|---|---|
| schema reforçado | `schemas/channel_model.schema.json` |
| modelador determinístico | `hero_engine/modeling_phase4.py` |
| CLI | `model-phase4` |
| ChannelModel | `output/modeling/phase4/channel-model-v1/channel_model.json` |
| matriz de evidências | `output/modeling/phase4/channel-model-v1/evidence_matrix.json` |
| relatório legível | `output/modeling/phase4/channel-model-v1/channel_model.md` |
| integridade | `output/modeling/phase4/channel-model-v1/integrity_manifest.json` |
| testes | `tests/test_modeling_phase4.py` |
| gate | `docs/PHASE_4_REPORT.md` |

## Passos e Done when

1. Reforçar o schema com GenerationSpec, evidência, knowledge state, economia e validação retrospectiva.  
   **Done when:** ambiguidades, RPM inventado e refs sem classe forem rejeitados.
2. Extrair estatísticas determinísticas das coortes e aberturas.  
   **Done when:** todos os inputs apontarem a snapshot/coorte/artefato.
3. Modelar identidade própria separada dos mecanismos da referência.  
   **Done when:** proibições bloquearem título/thumbnail/voz/takes/identidade copiados.
4. Construir arquétipo long-form e GenerationSpec.  
   **Done when:** hook, beats, variações, prova, payoff, clip policy e gates forem executáveis.
5. Explicar casos e contraexemplos.  
   **Done when:** 2 vencedores, 1 mediano, 1 fraco completos e os cohorts de abertura aparecerem na matriz.
6. Registrar hipóteses como `CANDIDATE`.  
   **Done when:** cada hipótese tiver evidência favorável, contrária e falsificação.
7. Executar replay, schema, referências, regressão e integridade.  
   **Done when:** 0 refs quebradas, output idempotente e suíte completa aprovada.

## Critérios de aceitação

- modelo explica diferenças observadas;
- nenhuma dependência de viral isolado;
- especificação permite criação nova sem copiar referência;
- limitações por nível de cobertura explícitas;
- RPM real continua indisponível;
- nenhum arquétipo de Shorts é inventado;
- custo externo zero;
- proprietário recebe um arquétipo recomendado para piloto.

## Riscos

- pequena amostra completa;
- viés de seleção e idade;
- título/abertura não provam retenção;
- não há resultado próprio long-form para calibrar previsões;
- prova editorial não equivale a licença de uso.
