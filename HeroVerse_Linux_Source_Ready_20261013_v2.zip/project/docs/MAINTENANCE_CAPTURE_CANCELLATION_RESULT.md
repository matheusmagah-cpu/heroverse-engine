# Tarefa 6 — cancelamento com leitura protegida

Data: 2026-09-08. Estado: **INTEGRADO E TESTADO EM ISOLAMENTO; CANCELAMENTO REAL NÃO EXECUTADO; SEM RETOMADA OPERACIONAL.** D-116 permanece separado e pendente; esta evidência não aprova implantação geral.

## Viabilidade e integração mínima

O trecho de autorização `_paused_cancel_boundary` somente consulta estados da fila, leases, cotas e reservas. Não exige mutação desses bancos. `operational_effect_snapshot(root)` e a validação dos journals/receipts externos permanecem na raiz original, com seus gates existentes; não foram substituídos por conclusões dos bancos.

A entrada existente `cancel_orphaned_maintenance_paused` conserva sua assinatura e passou a criar internamente uma captura da execução corrente. Não recebe caminho de captura anterior nem PASS fornecido pelo chamador. Reutiliza a proteção nativa `_PausedCancelPin` e o procedimento de cópia completa demonstrado na Tarefa 4; não reutiliza seus dados antigos como autorização.

- O inventário completo dos dois conjuntos é conferido antes/depois da aquisição dos handles. Os handles originais, compartilhados somente para leitura, pertencem ao `ExitStack` externo e permanecem mantidos até depois da decisão, remoções autorizadas e recibo final.
- Bytes dos bancos e auxiliares são arquivados como evidência e duplicados em diretório temporário de trabalho distinto. **Somente os bancos de trabalho são abertos pelo SQLite**, em leitura, sem checkpoint, alteração de journal_mode, inicialização ou migração.
- Integridade, chaves estrangeiras e os estados exigidos pelo cancelamento são verificados nas cópias. Identidades, handles, inventários e hashes são revalidados antes/depois das consultas e nas fronteiras de remoção.
- O manifesto vincula raiz, incidente, hashes exatos de request/ACK, implementação, identidade dos arquivos, captura e evidências. Prepared/committed 1.1 referenciam esse manifesto; recibos legados 1.0 conservam seu contrato de repetição.
- PAUSE, mutex, processos ausentes com identidade conhecida, request/ACK exatos, estados de leases/reservas/efeitos, arquivamento anterior à remoção, marcadores substitutos e bloqueio após interrupção parcial continuam obrigatórios.

## Arquivos alterados

1. `hero_engine/maintenance_protocol.py`: captura protegida integrada à entrada existente, consulta das cópias e verificação do arquivo de evidências na repetição.
2. `tests/test_paused_maintenance_cancellation.py`: somente inventário recursivo dos arquivos arquivados no teste de repetição, incluindo as novas evidências; critérios anteriores preservados.
3. `tests/test_paused_maintenance_capture_cancellation.py`: 22 casos focais novos do fluxo composto, reaproveitando a fixture anterior sem duplicar sua suíte.
4. Este registro. Nenhuma configuração, instrução operacional, rotina periódica, escritor de banco ou agendamento foi alterado.

## Execuções e resultados

Comandos executados na raiz do projeto, exclusivamente com fixtures temporárias e identidades simuladas:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_cancellation.py -v
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_capture_cancellation.py -v
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_capture_cancellation.py -k corrupt_database -v
.\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_paused_maintenance_capture_cancellation.py -k legacy_1_0 -k manual_or_old -v
```

| Execução | Resultado observado | Referência de execução |
| --- | --- | --- |
| 41 testes existentes diretamente afetados | 41 PASS; 7,163 s | `15e81a` |
| Primeiros 20 casos novos | 19 PASS / 1 ERROR; 8,168 s | `15c444` |
| Recuperação somente do teste de banco corrompido | 1 PASS; 0,289 s | `be6627` |
| Dois casos adicionais de compatibilidade/rejeição | 2 PASS; 1,039 s | `cb106c` |

O ERROR foi da expectativa do teste: o SQLite bloqueou corretamente a cópia corrompida com `sqlite3.DatabaseError: file is not a database`. Corrigiu-se somente o teste para exigir essa falha nativa, preservação dos arquivos e ausência de COMMITTED. Não houve correção produtiva para obter PASS. Os outros 19 casos não foram repetidos. Os dois casos adicionais foram executados separadamente.

Resultado consolidado por casos distintos: **41 existentes + 22 novos com PASS confirmado**. Não representa uma execução única de 63 casos. Os 15 testes de caracterização da Tarefa 1 foram preservados, sem reexecução nesta rodada. Não houve regressão integral.

Os novos casos exercitam a entrada composta: cancelamento elegível com WAL vazio; preservação byte a byte dos conjuntos e bloqueio de escrita durante ambas as remoções; escritor concorrente; proteção perdida antes/depois da remoção de ACK; origem divergente; cópia corrompida; falha de captura; WAL não vazio; par incompleto; auxiliar desconhecido; SHM inválido; lease/reserva abertos; journal externo de efeito aberto; repetição sem nova captura/SQLite/remoção; evidência adulterada; interrupção parcial com marcadores estrangeiros; recibo legado; PASS manual/captura antiga sem COMMITTED. A revisão independente focal não identificou bloqueio crítico no incremento.

## Versão conferida

SHA-256 dos arquivos finais (conferência `bba413`):

| Arquivo | SHA-256 |
| --- | --- |
| `hero_engine/maintenance_protocol.py` | `97c90f7d62ae9349af3277d1b082d099e0bbc8f861776dac1257f0071a6df44c` |
| `tests/test_paused_maintenance_cancellation.py` | `279ddaeddd39150ed1ece9ec3151540be02ba479a4d59c5d3f20d63c7381c1bc` |
| `tests/test_paused_maintenance_capture_cancellation.py` | `8203ef49bd0ab87941e06f5033385600cc15d47d1ab1038c30a815652b1a33d5` |

As referências acima identificam os resultados de comandos desta rodada; não são logs autônomos persistidos nem prova de execução real do incidente.

## Limites, preservações e futura aplicação

O caminho é deliberadamente limitado: até 8 MiB por arquivo; banco sem auxiliares no contrato legado, ou par completo WAL vazio/SHM de 32768 bytes; lock do ledger quando presente. WAL não vazio, outro journal/auxiliar, identidade desconhecida, alteração de origem ou proteção perdida bloqueiam. Não constitui recuperação SQLite universal.

Não houve abertura, leitura de conteúdo ou alteração dos bancos operacionais reais, nem alteração de request, ACK, PAUSE, locks, credenciais, mídia ou agendamentos. Não se executou cancelamento real, Gestor, daily.ps1, rede ou produção. A pausa operacional não foi removida; seu estado não foi reauditado nesta rodada.

Uma aplicação posterior exige cumprir o protocolo aplicável sem dispensar D-116; conferir a versão, raiz e hashes esperados preservados do incidente; verificar pausa, exclusividade e ausências exigidas; então obter **nova captura protegida dentro da própria entrada**, com estados conhecidos e fechados dos bancos e journals externos. A captura não pode ser pré-aprovada manualmente. Qualquer tentativa anterior incompleta continua bloqueada, sem repetição às cegas. Nenhum desses passos reais foi iniciado aqui.
