# Plano de remediação criativa — Fase 5 / creative-v2

## Objetivo único

Substituir o padrão observado no DRAFT v1 — narração original sobre paisagens genericamente relacionadas — por uma peça clip-based com causalidade audiovisual, identidade HeroVerse reconhecível, progressão de retenção e exemplos concretos visíveis. O v1 permanece baseline; nenhuma alegação de melhoria existe sem comparação mensurável.

## Diagnóstico observado

| Janela/takes | Defeito observado no v1 | Efeito | Correção obrigatória |
|---|---|---|---|
| 0–1 s / take-001 | nuvens + caixa de texto; a ação prometida não acontece | slogan legível, mas sem prova física | motivo original `limiar -> passo`, palavra curta, mudança visual e impacto sincronizados |
| 1–3 s / take-002 | paisagem/caminho genérico para “your move” | relação metafórica, não causal | figura cruza o limiar; pergunta `NOW WHAT?` e deslocamento direcional |
| 3–8 s / take-003 | rio/natureza para confiança e ação | micro-payoff apenas narrado | primeiro passo visível + introdução do sistema `TRUTH / RESPONSIBILITY / TODAY` |
| 8–30 s / takes 004–007 | sequência de clima e horizonte | baixa densidade de informação visual | cinco eventos visuais com função: pressão, silêncio, motivo, teste, direção |
| 37,4–51,1 s / takes 010–011 | lista de ações sobre nuvens | exemplos não demonstrados | carta, teclado e ação humana entram como evidência visual concreta |
| 56,6–90,1 s / takes 013–017 | explicação de sabedoria sobre céu/caminho | seção racional sem mecanismo visual | diagrama progressivo `ASK -> EXAMINE -> DO`, nunca como decoração |
| 121,3–156,1 s / takes 023–027 | teste em três partes sobre natureza | ferramenta prática difícil de lembrar | cartões numerados, uma pergunta por cartão e confirmação visual |
| 156,1–185,4 s / takes 028–032 | relacionamento/trabalho/medo ainda abstratos | payoff prático perde credibilidade | escrita de pedido de desculpas, candidatura/teclado e procura de ajuda visualmente distintos |
| corpo completo | repetição de nuvens, água e montanha | fadiga e aparência intercambiável | limite de repetição, alternância ação/ambiente/gráfico e pattern interrupt versionado |
| áudio completo | voz + ruído procedural quase uniforme | poucas viradas perceptíveis | pausas, impactos, risers, silêncio e ambientes por função narrativa |

## Gramática proprietária creative-v2

1. **Motivo do limiar:** porta, linha ou fronteira representa decisão; só aparece em hook, viradas e payoff.
2. **Linha dourada:** `#D7A94A`, espessura e posição congeladas; avança quando uma responsabilidade se torna acionável.
3. **Tríade operacional:** `TRUTH -> RESPONSIBILITY -> TODAY`; surge incompleta, é preenchida durante o vídeo e fecha no payoff.
4. **Regra de causalidade:** frase concreta exige ação concreta na tela. Natureza pode transmitir estado emocional, nunca substituir carta, trabalho, conversa ou decisão.
5. **Texto hierárquico:** palavra-chave grande, complemento menor, sem caixa central genérica; máximo de duas linhas e safe area de 8%.
6. **Ritmo:** hook com pelo menos quatro eventos audiovisuais em 8 s; no corpo, mudança funcional no máximo a cada 6 s e pattern interrupt estruturado no máximo a cada 25 s.
7. **Som:** impacto apenas em decisão, silêncio antes de pergunta, ambiente coerente com a fonte e voz sempre prioritária.

## Embalagem congelada para o teste

- Título primário: `AFTER YOU PRAY, DO THIS NEXT | Christian Motivation`.
- Thumbnail: figura atravessando um limiar; texto `DON'T JUST WAIT`.
- Promessa combinada: o vídeo entrega um teste de três perguntas para transformar oração em um próximo passo responsável, sem prometer resultado divino ou certeza absoluta.
- Hook falado: `Amen. Now what? The next honest step may be the answer you keep asking God to send.`
- Payoff: o espectador identifica uma ação compatível com verdade, responsabilidade e execução hoje.

## Critérios binários da revisão

- 100% dos takes possuem função narrativa, função de retenção, origem, direitos, ferramenta e versão.
- 100% das afirmações concretas nos exemplos usam ação humana ou gráfico causal, não somente paisagem.
- As janelas 0–1, 1–3, 3–8 e 8–30 s possuem storyboard, áudio e evidência separados.
- Pelo menos quatro eventos audiovisuais ocorrem em 0–8 s e cinco em 8–30 s.
- Nenhum ativo é usado em dois takes consecutivos, salvo motivo original documentado no hook.
- Nenhum recorte de terceiros domina mais de 20% do runtime.
- Nenhum take do corpo excede 7 s sem exceção de payoff registrada.
- O sistema `TRUTH / RESPONSIBILITY / TODAY` aparece, progride e é resolvido.
- Loudness integrado fica em `-16 LUFS ± 0,7`; true peak `<= -1 dBTP`; clipping zero.
- Black/freeze, texto fora de safe area, resolução inconsistente, transição dura interna, frame duplicado anômalo e deriva de timeline permanecem zero nos thresholds aprovados.
- Direitos de cada ativo e disclosure de conteúdo sintético realista são registrados no pacote de publicação.
- Todos os 18 gates aplicáveis ficam `PASS`; `NOT_APPLICABLE` só com justificativa; revisão humana independente fica `PASS` antes de promover o pack.

## Artefatos

- `output/production/phase5/pilot-001/creative-v2/creative_treatment_plan.json`;
- `output/production/phase5/pilot-001/creative-v2/assets/`;
- thumbnail versionada;
- roteiro, TakePlan, manifesto e render v2 versionados;
- relatório comparativo v1/v2;
- QA automático e folha de contato v2;
- pacote de publicação ainda não enviado até o gate.

## Condição de parada

Qualquer gate crítico não resolvido mantém o pack em `PROTOTYPED`, o vídeo sem publicação e a Fase 5 em `AWAITING_REVIEW`. O gerador não substitui o revisor humano independente.
