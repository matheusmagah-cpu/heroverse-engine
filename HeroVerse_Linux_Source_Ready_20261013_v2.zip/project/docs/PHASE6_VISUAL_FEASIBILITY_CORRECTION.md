# Fase6 — corrigir viabilidade visual antes de ampliar produção

Estado: IN_PROGRESS; custo técnico adicional R$0; autorização contínua D047.
Não é AWAITING_REVIEW, mudança de fase ou aprovação de mídia.

## Sucessor factual — 08/09 08:09UTC

As pendências de execução descritas abaixo são checkpoints históricos:
PUBLICITYclock-only fechou34métodos distintos PASS (23observados e11recuperados),
sem terminal agregado da primeira suíte. A aquisição5190601-v2 concluiu1GET,
25.472.389bytes, source38b74bee… e terminale816f6f1… hash-conferidos;
18focaisPASS precederam o commit. Ver acquisition-v2-verification.md no diretório
stock-candidates. Não repetir esses trabalhos. Fonte continua candidata em
quarentena: nenhuma correção editorial, direitos ou concentração foi aprovada
pelo download. Segue triagem de quadros/tempo e integração canônica PUBLICITY.

## Incremento executado em08/09,07:49UTC

Preflight4d965e46…/testee86d851c… passou16/16 em2,897s(root1e85cd).
CLI40e40c exit0 calculou
visual-lineage-feasibility-v1-6f01d2938c429ad43cce6689;
27unidades/41estados selecionados,24/59omitidos,979968samples no painel e
12207ms de redução mínima CONDICIONAL no teto. Documento de evidência:
output/qa/phase6/diagnostics/visual-lineage-feasibility-v1/verification.md.
Reutilizar, não repetir três JSON/compilação intactos.

Inspeção de contexto, sem aprovação: as PNGs antigas phone-down(d05499bc…),
action-plan(bce6782c…) e scriptural-mechanism(9034571c…) foram observadas.
Telefone virado não mostra uma resposta pendente; três cartões em mesa não
mostram resultado registrado; texto do livro não prova passagem específica.
Não promovê-las como substitutos por rótulo genérico ou reuso silencioso.

Candidato novo Pexels5190601, cottonbro studio: página/licença observadas;
player2732×1440/42,12s e screenshots nos tempos0/8/20/40s mostram mesa,
cadernos, mãos/escrita e fechamento. Isto é amostragem da prévia, não leitura
literal da escrita, CFR, ausência de riscos em todos os frames ou fonte admitida.
Primeira aquisição original incompleta12.258.944/25.472.389bytes foi preservada;
handle95005 ausente e processo não encontrado. Terminal/causeUNAVAILABLE.
Novo wrapper de aquisição exclusiva com terminal persistente em preparação.

PUBLICITY: correção estrita do relógio isolada em módulo/schema/testesv2,
para preservar helperb20ffd38… pinado pelos consumidores de A12. Originais
restaurados byte-exatos após detectar dependência transversal; nenhum pin
foi relaxado. Primeira suíte teve23PASS observados e11sem terminal confirmado
após interrupção. Recuperação focal somente dos11 em execução; não declarar
34PASS antes do resultado. Outros quatro achados e adoção produtiva pendentes.

## Evidência concreta

Fontes somente lidas: A12 c38a12e6e7c5c2b5a131282ba22d674e0f3c789542ec74d9d58e467c574bedf6;
V4 inspection69af2feb01d23bd2ca66b2cad0e7756b230a1c1943d59385b3c42e5b1036d4ce;
V6ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4.
Seleção: unidades de V6 cujos estados estão integralmente em V4.uses e
correspondem a uma única V4.sources.lineage_id; somar frame_count PCM de A12
a24000Hz, sem pausas, estimativa de palavra ou leitura de áudio. Rootfa2627
recompôs independentemente a análise do revisor.

| Linhagem | Unidades | Estados | Samples PCM | Duração PCM |
|---|---|---:|---:|---:|
| four-criteria |019–021,032–038,047–049|21|979968|40,832s|
| two-column |010–018|12|624128|26,005333s|
| fear-example |005–007,044–045|8|349184|14,549333s|

Hipótese refutada: usar essas fontes como apresentação integral de suas
unidades. Não existe alocação final ou exposição renderizada medida ainda.
O limite10% aplicado por linhagem real permite no máximo28,625s no teto de
286,25s. Four-criteria excede esse máximo em12,207s; diluí-lo exigiria408,32s,
fora da banda. Na timeline atual190,8s, o excesso seria21,752s. Não acrescentar
silêncio, aumentar a banda, renomear IDs ou fragmentar a mesma fonte para passar.
Reuso≤5, recorrência60s≤3, ausência de repetição indevida e mínimo12fontes
permanecem requisitos independentes, ainda sem aprovação por esta soma.

## Mudança de execução

1. Interromper somente a expansão da hipótese fullframe do mesmo painel;
   manter Gestor, fases autorizadas, A12, receitas/PNGs, direitos e FAILs.
2. Materializar preflight focal reproduzível em
   output/qa/phase6/diagnostics/visual-lineage-feasibility-v1/.
   Três inputs externos fixos; CLI read-only; cálculo racional e cenário
   explicitamente condicional. Sem dependências seguidas, mídia ou autoridade.
3. Reprojetar seletivamente fonte-base e exposição nos blocos010–021,
   032–038 e047–049. Preservar áudio, copy, sistemas, identidade e hooks.
   A informação gráfica só pode ser componente separado quando a composição
   realmente o demonstrar; a PNG opaca atual não se torna overlay por rótulo.
4. Selecionar contextos reais permitidos que mostrem preparação, exame,
   registro e comparação sem resultados fabricados. A biblioteca inspecionada
   não comprova ainda substitutos suficientes. Não gerar novas cartelas antes
   de resolver essa disponibilidade e a viabilidade agregada.
5. Só após amostra/QA/contexto/limites demonstrados: sucessor editorial explícito,
   fontes e vínculos novos, consumidor integrado e gates próprios. Nunca
   alterar V6/A12 in-place nem promover provas estáticas a qualidade do vídeo.

Os59estados restantes têm35entradas lexicais e24UNIT_ENTRY. Nenhum possui
par exato(composition_id,literal_copy) entre os41rasters vinculados. Primitivas
existentes não são fontes prontas. Os quatro contextos meteorológicos
004/030/043/050 têm candidatos já existentes e11,392sPCM em conjunto, mas
ainda precisam de spans/observação e não corrigem o excesso dos painéis.

## Done when deste incremento

- Preflight rejeita inputs adulterados, relações faltantes/duplicadas, tipos
  numéricos permissivos, mistura de linhagens e falsa autoridade; testes reais
  de metadados distinguem a hipótese condicional da alocação produtiva.
- Resultado reproduz a soma979968samples e o excesso mínimo12207ms, com
  omissões e limites explícitos, sem nova inferência ou render.
- Correção editorial futura possui fontes observadas, antes/depois mensurável
  e orçamento de exposição compatível; esse critério ainda NÃO foi satisfeito.

## Bloqueios paralelos preservados

PUBLICITY: falta prova consumível dos spans reais dos três hooks; não foi
observado um PERSON_DETECTED pelo detector. A pessoa representada no primeiro
hook é visível em frame retido, mas procedência sintética não é clearance.
O módulo b20ffd38… continua bloqueado pela revisão c4b945db…: recompor runtime,
prender sucesso/calibração, consumir A canônica, verificar counterproof
persistido independentemente e usar expiração estrita ao relógio final.
Sem spans de A, não inventar índices de origem por arredondamento dos ms.

União26/23candidatas não comporta o cohort30 antigo. Zero anotação genuína
permanece zero; não usar concordância ASR como gold, transferir escuta
rotineira ao proprietário ou contornar calibração. Duração/grade, áudio,
movimento, legibilidade final, B/C/D, GC01 e publicação seguem pendentes.
