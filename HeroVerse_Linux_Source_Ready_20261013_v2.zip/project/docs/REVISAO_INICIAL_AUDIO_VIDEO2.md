# Vídeo 2 — pacote de revisão inicial de áudio

## Correção posterior — não atribuir escuta rotineira ao proprietário

O proprietário reafirmou que a avaliação deve ser realizada pela operação. A solicitação anterior de que ele escutasse o master foi retirada como próximo passo. Este pacote permanece como referência histórica de fontes e requisitos, não como formulário obrigatório a ser preenchido por ele. A implementação está ampliando a avaliação automática; não foi produzida revisão humana ou aprovação por essa mudança. Referência temporal, calibração e limitações técnicas continuam exigidas. O cohort antigo de 30 permanece incompatível.

Estado: **INSUMOS REUNIDOS; REVISÃO NÃO REALIZADA**. Este arquivo não aprova áudio, alinhamento, vídeo ou publicação e não é um receipt de padrão-ouro. Não exige nova autorização geral. Se já existir uma revisão efetivamente realizada, seu registro deve ser ligado à versão exata abaixo, sem repetir a escuta.

## Alerta vigente — não anotar o cohort de30

A análise posterior dos90takes identificou três falas que também precisam de sincronização visual: **u020** (“fully true / only possible”), **u034** (truth, character, consequences, wise counsel) e **u041** (emergency, medical, legal, pastoral, safeguarding). Elas não podem servir de holdout para sua própria produção. Com os demais alvos conhecidos, restam no máximo27candidatas de mesma velocidade, abaixo do mínimo30 da policy anterior. O cohort e a policy abaixo ficam preservados como histórico, **não utilizáveis nesse escopo**. Não preencher anotações ou executar estimativas para eles.

O [audit completo do inventário](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/temporal-scope-audit-3a6aa9e15887bd7998b2bc3d.json>) liga51unidades/90takes/71cues e os offsets literais, mas ainda não aprova a união final de eventos nem a semântica das imagens. O Gestor deve concluir a intenção visual restante e pré-registrar uma nova seleção/policy aplicável antes de solicitar anotação temporal. Não escolher27só por ser o número disponível nem alterar a narrativa para preservar amostras. A **escuta perceptual do master exato** abaixo continua válida como tarefa independente; não equivale à anotação temporal.

## Preparação temporal atualizada — 07/09/2026 03:49 UTC

Foi registrada a policy `temporal-policy-6587e640dafb2974367e7d15`, antes de qualquer nova estimação, para o perfil PocketSphinx5.0.4/adapterv1/swr32, am_onyx/en-US/24kHz. O critério escolhido para este ensaio é cobertura30/30 e erro absoluto de no máximo800samples (um frame de30fps). É um **alvo de engenharia pré-registrado, não precisão medida, limiar universal ou garantia de qualidade**. Não reduzir o limite depois de observar erros para aprovar o mesmo candidato. Os critérios de incerteza de cada evento, contraprova acústica e percepção continuam independentes.

As51unidades/90fragmentos foram recompostos e149bindings de origem lidos. Existem30PCM candidatos na velocidade1,06, total87,637333s, depois de excluir17unidades de captions internas, as unidades lexicais011/012 e as velocidades incompatíveis001/002. O [cohort candidato](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/temporal-calibration-cohort-v1.json>) contém caminho/hash, frase, palavra e offsets literais exatos, com15inícios e15fins a anotar. Todos os timestamps acústicos, identidades de observador e avaliações permanecemnull; **não é arquivo de referência nem anotação concluída**.

**Não começar a anotação desse cohort ainda:** a união integral de alvos do vídeo final precisa ser recomposta primeiro. A seleção atual cobre captions e eventos lexicais conhecidos do adapter de duas colunas, não todos os futuros eventos visuais. Se a união final usar qualquer candidato, esta seleção não pode ser consumida; revisar/pré-registrar antes de estimar, sem mudar narrativa ou captions só para preservar o holdout. Isso evita solicitar anotações que depois seriam inelegíveis. A escuta perceptual do master exato abaixo continua uma tarefa distinta e pode ocorrer sem essa seleção temporal.

Arquivos: [pedido técnico](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/temporal-calibration-annotation-request-v1.json>), [policy](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/av-admission/temporal-policies/temporal-policy-6587e640dafb2974367e7d15.json>) e [prova reproduzível de preparação](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/temporal-calibration-preparation-v1-result.json>). Nove verificações passaram, incluindo rejeição de adulteração e a contraprova de que zero anotações reais não passa na calibração. Nenhum modelo foi executado, nenhuma nova mídia foi gerada e nenhum gate produtivo foi aprovado. Os parágrafos históricos abaixo que descrevem policy/amostra ainda não definidas são anteriores a esta preparação; a condição de união integral pendente continua vigente.

## Arquivo certo

[Ouvir a narração completa — 3min22,780s](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/editorial-narration-master-v1-14c3d700a155554bc006af41/refinement-v1/narration-normalized.wav>)

SHA-256: `8e8909fef9835f92aee8521db9c7e0153216fa5a48a0bd0f2177444fdeac49b6`. WAV mono, 24.000 Hz, PCM16, 4.866.720 samples; 9.733.518 bytes. Hash reaberto nesta preparação e coincidente. O arquivo de mesmo nome fora de `refinement-v1` é histórico: não o avaliar como esta versão.

[Ver/ouvir o fragmento audiovisual dos segundos 3–8](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/editorial-hook-av-mux-v1-9484b10e5964c346/hook-av-lossless.mkv>) — mídia já produzida, não gerada novamente. O relógio desse arquivo começa em zero; corresponde ao segundo3 do master. Este trecho não representa o vídeo completo.

Níveis já medidos: −16,37 LUFS, −1,49 dBTP e LRA3. Não repetir normalização para esta revisão: esses valores não demonstram pronúncia, naturalidade, compreensão ou boa sincronização.

## Escuta e registro concretos

Ouvir o master inteiro em velocidade normal, incluindo as pausas. Registrar quem ouviu, quando, qual arquivo/hash, equipamento de reprodução e cobertura efetivamente ouvida. Para cada problema, registrar intervalo no master, trecho ouvido, problema observável e correção desejada. Distinguir pronúncia, palavra truncada, pausa, entonação, ruído, transição e dificuldade de compreensão. Se não for possível julgar, registrar a dúvida, não PASS.

Os intervalos abaixo localizam unidades inteiras para escuta; foram calculados por `sample/24000` a partir do mapa existente. **Não são timestamps de palavras nem uma referência temporal anotada.** Valores exibidos arredondados a seis casas; a origem em samples prevalece.

| Unidade | Início no master (s) | Fim exclusivo (s) | Samples de origem [início,fim) | Atenção |
|---|---:|---:|---|---|
| 001 | 0,000000 | 0,625667 | [0,15016) | Divergência acústica anterior ainda sem resolução perceptual |
| 007 | 18,100000 | 21,236000 | [434400,509664) | Divergência acústica anterior ainda sem resolução perceptual |
| 011 | 34,590000 | 37,086000 | [830160,890064) | `write/right` é homofonia: ortografia do ASR não prova defeito de voz |
| 012 | 37,210000 | 40,111333 | [893040,962672) | Revelação visual depende da palavra `write`; escuta geral não determina seu onset exato |
| 013 | 40,510000 | 42,856667 | [972240,1028560) | Divergência acústica anterior ainda sem resolução perceptual |
| 016 | 49,070000 | 53,443333 | [1177680,1282640) | Conferir ligação da frase e distinção `is/as`, sem presumir erro do sintetizador |

Amostras dirigidas não dispensam a escuta do conjunto. Não pedir para acrescentar5,020s de silêncio para atingir a duração mínima: qualquer pausa precisa função narrativa demonstrada. O master atual continua abaixo da banda experimental e da grade elegível.

## Referência temporal: trabalho distinto da escuta geral

Para liberar eventos lexicais e captions internos, ainda falta referência temporal genuína. Um comentário “áudio bom”, a autorização do proprietário ou dois reconhecedores concordantes não suprem essa referência.

O Gestor precisa primeiro fixar a policy aplicável, seu método/perfil, os critérios de erro/cobertura e a população holdout fora da união de alvos. O número de amostras não foi inventado neste pacote. A anotação deve usar os PCM originais elegíveis, da mesma voz/idioma/velocidade, preservados na reconciliação; **o WAV master normalizado acima não pode ser substituído pelo PCM de holdout**. As seis unidades desta tabela não constituem uma seleção de holdout.

O anotador registra limites acústicos com unidade/palavra ou trecho literal, amostra do PCM, incerteza/ambiguidade, método/versão, identidade e data reais, e conserva o arquivo de anotações. Não deve copiar estimativas do ASR para fazê-las parecer uma referência independente. O sistema posteriormente valida e liga esses dados ao contrato `TEMPORAL_REFERENCE_OBSERVATION` e à calibração, com paths, hashes e origem reconstituídos. Somente `HUMAN_GOLD_STANDARD` ou `VERIFIED_ANNOTATED_DATASET` são aceitos pelo contrato LIVE vigente. Uma referência já existente pode ser usada se realmente aplicável; não é necessário refazê-la só para gerar outro relatório.

A segunda checagem acústica continua separada. O Faster-Whisper já executado é evidência auxiliar reutilizável quando suas fontes coincidem; não se torna padrão-ouro. Não executar novamente inferência-alvo antes da policy pré-registrada.

## Limite desta entrega e próximos efeitos

Este pacote reduz a procura manual pelos arquivos e delimita a evidência faltante; não fecha a EtapaA ou a Fase6. Não contém respostas preenchidas, julgamentos simulados, anotação inventada ou autorização de produção. Não houve nova síntese, ASR, render, remux, instalação ou publicação.

Após evidência sonora válida: integrar timeline editorial, comprovar duração/grade, admitir transacionalmente, verificar capacidade, compor, avaliar o vídeo completo e atravessar release/publicação. Os gates e os arquivos anteriores permanecem intactos. A revisão inicial do padrão-ouro não vira formulário humano obrigatório antes de cada publicação; aplica-se a regra permanente de calibração, amostragem e exceções.

Origem dos intervalos: `output/qa/phase6/diagnostics/narration-editorial-pause-candidate-v1/7323db5ee1c0762cf0ae8095/intent.json`, SHA-256 `7323db5ee1c0762cf0ae809598ef477988f82e674f33cb5f0fe3b5b37de1a020`. Contrato: `docs/PHASE6_AV_SUCCESSOR_IMPLEMENTATION.md` e `hero_engine/phase6_av_timeline.py` v4. O mapa é diagnóstico, não a timeline produtiva aprovada.
