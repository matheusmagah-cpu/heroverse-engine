# Preflight — Fase 3: mineração em lote e observatório

## Autorização

O proprietário autorizou progressão condicional até o final em `2026-09-02`. A Fase 2 passou todos os gates objetivos e foi aprovada em D-025. A Fase 3 está autorizada, sem antecipar ChannelDNA, produção, publicação, Ads ou gasto.

## Fontes de verdade lidas

- `docs/STATE.md`;
- `docs/00_MASTER_SPEC.md`;
- `docs/01_EXECUTION_PROTOCOL.md`;
- `docs/07_PHASES_AND_GATES.md`;
- bloco da Fase 3 de `prompts/03_MODEL_CHANNEL.md`;
- `docs/03_MODELING_SPEC.md` somente para requisitos de coorte que a Fase 3 deve preparar;
- `docs/05_ANALYTICS_AND_VALIDATION.md`;
- `docs/06_TOOLING_AND_INTEGRATIONS.md`;
- `docs/08_POLICY_AND_RIGHTS.md`;
- requisitos do Gestor Central e da válvula de aquisição;
- schemas de mining, gestor, comando, envelope e futuro channel model.

## Inventário utilizável

- SQLite `data/hero_engine.db`: `integrity_check=ok`, 12 tabelas legadas; ainda não possui ledger append-only/migrações da Fase 3;
- catálogo legado: 7 canais e 12 vídeos;
- canal próprio: `@heroverse74`, sem snapshots privados registrados (`performance_snapshots=0`);
- referência de formato principal: Grace, Grit & Love;
- população local de referência: 24 registros de vídeo;
- corpus de abertura: 16 MP4s de introdução e 16 transcrições, dos quais 12 estão fora das quatro fixtures completas;
- mineração completa aprovada: 4 vídeos, 256 takes;
- referências comparativas/speed: Lion of Judah, Gospel Path, The Chosen Path e God's Living Word;
- fonte de ativos separada: David Diga Hernandez, sujeita a auditoria de direito por vídeo;
- `yt-dlp 2026.08.19`: disponível para metadados públicos sem download de mídia;
- ffmpeg/ffprobe, OCR e ASR locais: disponíveis;
- custo obrigatório nesta fase: API externa US$ 0,00.

## Escopo aprovado para o observatório

1. `@heroverse74`: canal próprio e baseline público; métricas privadas ausentes permanecem `UNAVAILABLE`.
2. Grace, Grit & Love: referência de formato; 24 metadados, 16 aberturas existentes e 4 minerações completas.
3. Comparações independentes: canais já catalogados no mesmo nicho, somente metadados públicos e sinais permitidos.
4. David Diga Hernandez: catálogo de possíveis fontes, isolado do modelo de formato e sem promoção de direito.

Nenhuma mídia nova será baixada nesta fase. Metadados podem ser atualizados pela página pública; ativos existentes são usados somente para análise.

## Lacunas e tratamento

| Lacuna | Tratamento |
|---|---|
| sem OAuth/Studio e sem snapshots próprios | registrar `PRIVATE_METRIC_UNAVAILABLE`; não simular CTR, retenção, Earn, RPM ou receita |
| 12 aberturas não são vídeos completos | classificar como `OPENING_ONLY`; não usar como evidência de narrativa/payoff completos |
| apenas 4 full-minings | usar como estrato `FULL_VALIDATED`; cobertura deve ser reportada por campo |
| catálogo público pode mudar | snapshots append-only com `captured_at`, fonte, payload hash e erro explícito |
| dados legados podem divergir do atual | preservar, não sobrescrever; nova coleta entra como snapshot |
| forecasts legados sem amostra | manter como histórico `PRIOR_ONLY`; proibir uso decisório até dados próprios suficientes |
| RPM atual | `UNAVAILABLE`; nenhum ranking de nicho vira dado observado |

## Conflitos

Não há prompt exclusivo de arquivo para a Fase 3, mas `prompts/03_MODEL_CHANNEL.md` contém um bloco separado e inequívoco para ela. O comando manda preparar catálogo/coortes e proíbe gerar o modelo final. `docs/03_MODELING_SPEC.md` é usado apenas para definir a forma da preparação, não para executar a Fase 4.

## Preflight

`PASS` para iniciar a Fase 3 com cobertura estratificada e limitações explícitas. O gate só passará se houver SSOT persistente, snapshots reprodutíveis, coortes justificadas, isolamento, reingestão idempotente, qualidade amostral documentada e validação fora da amostra do que for tecnicamente comparável.
