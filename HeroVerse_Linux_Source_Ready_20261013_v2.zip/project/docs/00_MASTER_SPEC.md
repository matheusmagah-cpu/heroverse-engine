# 00 — Especificação mestre

## 1. Visão

O projeto criará uma operação capaz de aprender, por evidências, como formatos de canais faceless funcionam; converter esse aprendizado em modelos executáveis; produzir vídeos principalmente por recortes permitidos e nova construção narrativa; publicar pilotos; aprender com os dados próprios; e escalar somente padrões comprovados.

O sistema será usado internamente antes de ser transformado em produto. A experiência real do operador, os resultados dos canais e as falhas encontradas devem alimentar a futura versão comercial.

## 2. Resultado final esperado

Ao final, o operador deve conseguir:

1. cadastrar um nicho e um conjunto de canais/vídeos de referência;
2. registrar a situação pública de cada canal e vídeo ao longo do tempo;
3. minerar cada vídeo em nível de embalagem, hook, fala, take, narrativa, retenção e produção;
4. comparar vencedores, medianos e fracos;
5. identificar arquétipos repetíveis e seus limites;
6. gerar um `ChannelModel` explicável;
7. gerar um `ProductionBlueprint` para um novo vídeo;
8. localizar recortes adequados em uma biblioteca de ativos permitidos;
9. montar um vídeo novo com narrativa e contexto próprios;
10. validar fidelidade ao arquétipo, originalidade editorial, direitos, qualidade e política;
11. publicar somente após a aprovação prevista;
12. captar métricas dos canais próprios;
13. recomendar manter, corrigir, escalar ou encerrar uma hipótese;
14. repetir o processo em canais isolados, sem misturar identidade ou dados;
15. transformar o fluxo validado em produto somente depois de comprovar uso real.
16. operar uma válvula opcional de aquisição controlada que mede incremento orgânico qualificado, sem contar alcance pago como progresso do YPP;
17. otimizar valor por RPM real dos canais próprios quando disponível, mantendo proxies e dados indisponíveis explicitamente separados.
18. selecionar direção criativa por evidência e capacidade, usando somente FormatPacks validados, consistência take a take e pipelines especializados.
19. revalidar a prontidão do canal antes de cada publicação, incluindo promessa, marca, Home, catálogo, YPP, política e durabilidade da integração.

O resultado final também deve possuir um Gestor Central Autônomo único, capaz de administrar todos esses itens dentro de um envelope aprovado, mantendo o proprietário como supervisor de postagens, resultados, custos, alertas e decisões importantes.

**CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.** Toda capacidade deve funcionar com recursos locais, gratuitos/open source, infraestrutura já disponível ou cota oficial gratuita sem cobrança automática. O sistema impede gasto, monitora cota e migra para fallback gratuito antes do limite. A única exceção possível é mídia futura no YouTube Promote, separada da infraestrutura e condicionada a orçamento expresso.

## 3. Definições

### Mineração

Decomposição verificável do vídeo. Toda conclusão precisa estar ligada a uma evidência temporal, visual, textual, sonora ou métrica.

### Modelagem

Descoberta dos mecanismos recorrentes que conectam audiência, tema, ângulo, embalagem, hook, progressão, retenção, payoff e resposta do público. Modelagem não é copiar um vídeo; é produzir uma gramática reutilizável.

### Produção clip-based

Criação de uma nova peça editorial usando recortes permitidos como matéria-prima principal. O vídeo deve possuir nova finalidade, narrativa, seleção, ordenação, contexto, entrega e identidade de canal. Transformações apenas cosméticas não satisfazem o projeto.

### Previsibilidade

Estimativa com faixa, evidência e confiança. Antes do piloto, a previsão usa dados públicos e padrões comparáveis. Depois do piloto, incorpora dados privados do próprio canal. Não significa garantia de monetização, visualizações ou lucro.

### Validação

Comparação objetiva entre resultado, schema, padrão-ouro, critérios de aceitação e métricas do canal próprio.

### Gestor Central Autônomo

Camada persistente de comando e aprendizado da Inteligência Contínua Viva. É a fonte única de verdade, prioridade, estado, memória e decisão operacional de todo o ecossistema. Executa automaticamente somente o que o envelope aprovado permite; ações protegidas são escaladas ao proprietário.

### Válvula de aceleração

Experimento protegido de aquisição que tenta produzir efeito orgânico posterior mensurável. Views, horas e inscritos originados de campanhas não são progresso qualificado do YPP. O contrato completo está em `docs/12_ACQUISITION_ACCELERATOR_MASTER.md`.

### Diretor Criativo

Executor especializado e subordinado ao Gestor Central que converte ChannelDNA, brief, narrativa, orçamento, direitos e capacidade em uma direção visual/sonora versionada. Decide por `FormatPack`, cria Style Bible e TakePlan, coordena adaptadores e devolve QualityGateReport. Não aprova a própria exceção nem mantém estratégia paralela. O contrato está em `docs/15_CREATIVE_DIRECTION_MASTER.md`.

## 4. Princípios imutáveis

- Embalagem precede o roteiro: tema, ângulo, promessa, título e thumbnail são definidos antes do texto completo.
- O hook deve cumprir a promessa da embalagem imediatamente.
- Cada bloco do vídeo precisa ter uma função narrativa ou de retenção.
- Modelos derivam de conjuntos comparativos, nunca de um viral isolado.
- Todo padrão possui invariantes, variáveis permitidas e elementos proibidos.
- Toda inferência possui evidência e confiança.
- Cada canal possui configuração, identidade, biblioteca, métricas e aprendizado próprios.
- O sistema deve ser local-first e provider-agnostic.
- O núcleo não pode depender de um único plugin, modelo ou fornecedor.
- Publicação e gasto são ações controladas.
- Produto comercial só nasce depois de operação interna comprovada.
- Toda execução futura é comandada pelo Gestor Central; componentes subordinados não mantêm estratégia ou memória paralela.
- Autonomia nunca substitui direitos, política, limites de custo ou aprovação de ação protegida. D-047 constitui autorização prévia e sequencial das Fases 5–8, sem dispensar o gate objetivo da fase anterior.

### Modo contínuo autorizado — D-047

- As Fases 5–8 compõem uma fila já autorizada; a transição só ocorre após receipt de todos os gates aplicáveis.
- Falha gera correção, reteste e preservação de baseline; não gera aprovação por média nem relaxamento.
- `AWAITING_REVIEW` é uma dependência humana/externa específica, não uma parada global.
- Upload/publicação sem gasto podem ocorrer no envelope após direitos, QA, identidade do canal, credencial e rastreabilidade passarem.
- Ads, serviço pago e gasto permanecem fora do envelope até orçamento explícito.
- Alcance pago nunca é registrado como progresso orgânico qualificado nem como evidência de monetização.
- RPM é otimizado com dados monetários próprios; antes disso permanece `UNAVAILABLE` ou proxy explicitamente inferido.
- O nicho e os gates permanentes são fronteiras; a criação diária não é template fixo. Tema, ângulo, promessa, embalagem, hook, ritmo e seleção visual são reavaliados a partir de sinais contemporâneos versionados.
- “Viral” é objetivo probabilístico pré-publicação e resultado mensurável pós-publicação, nunca garantia. Visualizações são normalizadas por idade, formato, canal e baseline antes de orientar decisão.
- Um estilo catalogado ou especificado não é capacidade disponível. Produção regular exige FormatPack `PRODUCTION_READY` ou `LIMITED` dentro do escopo, pipeline próprio, continuidade e gates completos.

## 5. Camadas do sistema

1. **Gestor Central:** objetivo, envelope, estado, fila, decisão, aprendizado, previsão, auditoria e supervisão por exceção.
2. **Observatório:** canais, vídeos, snapshots e dados públicos.
3. **Minerador:** mídia, transcrição, OCR, hooks, takes e narrativa.
4. **Modelador:** coortes, padrões, arquétipos e ChannelDNA.
5. **Planejador:** hipótese, embalagem e blueprint de produção.
6. **Diretor Criativo:** FormatPack, escolha justificada, Style Bible, TakePlan, perfil de qualidade e consistência.
7. **Biblioteca:** recortes, licenças, atributos e disponibilidade.
8. **Montador:** timeline, áudio, texto, recortes e renderização.
9. **Quality Gate:** estratégia, identidade, semântica, continuidade, áudio, direitos, originalidade, técnica, custo e política.
10. **Publicador:** metadados, aprovação e envio controlado.
11. **Analytics:** métricas próprias, diagnóstico e aprendizado.
12. **Portfólio:** decisão de escalar, iterar, pausar ou encerrar.
13. **Aquisição controlada:** baseline, experimento, atribuição, incrementalidade, orçamento e stop-loss.
14. **Channel Readiness:** identidade, promessa, Home, marca, catálogo, elegibilidade, política e receipt de mudanças públicas.

## 6. Dados públicos e privados

### Observáveis publicamente

- título, descrição, data, duração e thumbnail;
- visualizações, curtidas e comentários quando disponíveis;
- quantidade pública de inscritos quando disponível;
- frequência, catálogo e evolução capturada em snapshots;
- conteúdo audiovisual acessível para análise permitida.

### Privados dos canais próprios

- impressões e CTR;
- duração média e retenção;
- watch time;
- fontes de tráfego;
- inscritos ganhos por vídeo;
- receita e RPM, quando existentes;
- custos reais de produção e margem.

O sistema nunca apresenta métrica privada de concorrente como fato.

## 7. Critérios de sucesso do projeto

### Técnicos

- pipeline reproduzível;
- saídas estruturadas e validadas por schema;
- nenhuma conclusão relevante sem evidência;
- processamento idempotente;
- rastreabilidade de fontes, versões, custos e decisões;
- substituição de providers sem reescrever o domínio.

### Editoriais

- hook, takes, narrativa e embalagem corretamente decompostos;
- novo vídeo cumpre a promessa;
- narrativa adequada ao nicho de destino;
- identidade própria por canal;
- diferença editorial demonstrável em relação às referências.

### Comerciais

- custo por vídeo conhecido;
- tempo por vídeo conhecido;
- taxa de aprovação conhecida;
- resultados do canal-piloto capturados;
- regras de escala baseadas em dados;
- pelo menos uma repetição bem-sucedida antes de empacotar como produto.
- qualquer aceleração paga demonstra incremento orgânico qualificado contra controle, não apenas alcance comprado;
- previsões de prazo e RPM são posteriormente pontuadas e calibradas.

## 8. Fora de escopo inicial

- lançar muitos canais simultaneamente;
- automatizar publicação antes de o conteúdo passar pelo piloto;
- vender o sistema antes do uso interno;
- prometer monetização ou renda;
- depender de geração integral de vídeos por IA paga;
- copiar vídeos, identidades ou bibliotecas de terceiros;
- tratar edição cosmética como transformação editorial;
- decidir arquitetura definitiva antes de auditar o projeto existente.
