# Relatório — Fase 5: protótipo clip-based controlado

## Revisão criativa vigente — creative-v3.2

O candidato vigente é `creative-v3.2`. Ele passou 22/22 remediações automáticas e está `READY_FOR_INDEPENDENT_HUMAN_REVIEW`, com publicação bloqueada. `creative-v3.1` foi reprovado posteriormente por concentração de 66,3176% nos seis ativos dominantes e permanece preservado em `creative-history`. O relatório atual, os hashes exatos e os gates restantes estão em `docs/PHASE_5_CREATIVE_V3_REPORT.md`. Todo o conteúdo v1/v2.1/v3.1 abaixo permanece como histórico auditável, não como candidato vigente.

### Evidência vigente resumida

- render: 238,7 s; 59 takes; 7.161 frames; 1920×1080/30 fps; deriva 0 ms;
- hook: três fontes distintas e sete eventos em 0–8 s;
- captions: 59 cues, cobertura 1,0 e máximo de 12 palavras;
- visual: 22 fontes; paisagem dominante 24,7591%; maior ativo 8,2111%; seis maiores 44,3653%; máximo quatro usos e três/60 s;
- técnica: zero black/freeze; -16,34 LUFS; -1,23 dBTP; 22/22 checks automáticos;
- STANDARD: SHA-256 `33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c`; replay SSIM 0,99782;
- pacote: `creative-v3/publication_package.json`, com `upload_permitted=false`;
- metadata: `The 24-Hour Test: What To Do After You Pray`, challenger 91/100 contra baseline 82/100; o score vidIQ é auxiliar, não causal, e a alternativa 96/100 foi recusada por conflito editorial;
- vidIQ: plugin `LIMITED`, pesquisa pública disponível, 95/150 créditos gratuitos restantes e zero canais próprios autorizados; Analytics privado permanece bloqueado;
- bloqueios: padrão-ouro humano, thumbnail A/B/C, FormatPack `PROTOTYPED` e OAuth `TIME_LIMITED_TESTING`.
- verificação: 129/129 testes, 65/65 schemas e 550 artefatos/3.080.032.782 bytes no manifesto de integridade.

## Histórico — creative-v2.1 rejeitado

O DRAFT v1 descrito nas seções históricas abaixo foi rejeitado pelo proprietário por execução criativa genérica. Ele foi preservado como baseline. A revisão `creative-v2.1` também foi rejeitada pela auditoria crítica D-042 e permanece evidência histórica, sem apagar a evidência anterior.

- título: `AFTER YOU PRAY, DO THIS NEXT | Christian Motivation`;
- thumbnail: `DON'T JUST WAIT`;
- hook falado: `Amen. Now what? The next honest step may be the answer you keep asking God to send.`;
- gramática: `THRESHOLD_TO_STEP` + `TRUTH -> RESPONSIBILITY -> TODAY`;
- render ID: `render-v2-2b8e3c358fc5323eb3b9`;
- SHA-256: `eae07a3990e567ce2ee5f81feacfaa96b1147042c88725a33a7f36d3d7dc2ffc`;
- duração: 135,200 s; 331 palavras; 32 takes; 4.056 frames; 1920×1080; 30 fps; H.264/AAC;
- timeline: erro máximo 0 ms e deriva cumulativa 0 ms;
- áudio: -16,15 LUFS; -1,30 dBTP; LRA 4,5 LU;
- técnica: zero black frame, zero freeze, zero hard transition intra-take e p95 luminância 5,76421;
- direitos: 13/13 ativos usados com hash e estado elegível; disclosure sintético obrigatório registrado;
- originalidade: sobreposição máxima de trigramas 0,006154 contra quatro transcrições revisadas, abaixo do limite 0,02;
- custo externo: USD 0; custo local financeiro: `UNAVAILABLE`.

### Contrato criativo mensurado

| Verificação | Limite | Observado | Estado |
|---|---:|---:|---|
| eventos visuais 0–8 s | >= 4 | 5 | PASS |
| eventos visuais 8–30 s | >= 5 | 8 | PASS |
| duração máxima de take corporal | <= 7.000 ms | 6.000 ms | PASS |
| intervalo máximo de pattern interrupt | <= 25.000 ms | 21.300 ms | PASS |
| maior participação de um recorte de terceiro | <= 20% | 14,4231% | PASS |
| ação concreta com prova visual | 100% | 5/5 | PASS |
| estados do framework | todos | INTRODUCED/TRUTH/RESPONSIBILITY/TODAY/COMPLETE | PASS |
| disclosure sintético | obrigatório | registrado | PASS |
| rastreio do tratamento | versão exata | 2.1.0 | PASS |
| variedade de ativos | >= 10 | 13 | PASS |
| repetição consecutiva fora do hook | zero | zero | PASS |

O primeiro render v2.1 falhou corretamente no gate de freeze: 0,866667 s e 1,9 s entre 4,933333 s e 7,7 s. A causa foi a derivação local do key art do hook. A derivação v2 foi criada com movimento contínuo, o render recebeu novo hash e o mesmo detector retornou zero freeze. Em seguida, a revisão do próprio contrato encontrou repetição consecutiva fora do hook; um ativo original de aprendizagem/pergunta foi criado e o render final eliminou essa repetição sem reduzir a cobertura causal. Os limites não foram relaxados.

### Comparação com o baseline rejeitado

| Métrica estrutural | v1 | v2.1 | Delta |
|---|---:|---:|---:|
| duração | 252.400 ms | 135.200 ms | -117.200 ms |
| palavras | 599 | 331 | -268 |
| takes | 44 | 32 | -12 |
| ativos distintos usados | 9 | 13 | +4 |
| maior participação de recorte de terceiro | 29,3978% | 14,4231% | -14,9747 p.p. |
| tratamentos gráficos especializados | não mensurado | 16 | — |

Esses números comprovam aderência ao novo blueprint e correção das falhas observadas. Eles não comprovam retenção, CTR, audiência, viralização, monetização ou lucro; esses dados só existem após publicação e medição própria.

### Gate vigente

- PASS automático: estratégia, ChannelDNA, narrativa, técnica, direitos, originalidade editorial e custo;
- NEEDS_REVIEW: hook, semântica, estilo, continuidade percebida, movimento, legibilidade, áudio percebido, publicity e identidade do canal;
- NOT_APPLICABLE: personagem recorrente;
- BLOCKED: publicação;
- FAIL automático: zero.

O estado correto permanece `AWAITING_REVIEW`. Os 11/11 contratos criativos automáticos passam. O pack continua `PROTOTYPED`; D-041 permite antecipar somente a conexão OAuth, mas upload e início operacional ainda não podem ocorrer antes da revisão humana independente do arquivo completo.

### Pacote editorial e integração YouTube — D-041

O proprietário posteriormente autorizou antecipar a conexão técnica, sem antecipar publicação. A separação de autoridade ficou explícita:

- `OAuth conectado` significa somente que a identidade e as APIs podem ser consultadas;
- `upload configurado` significa que o adapter conhece o contrato do YouTube;
- `publicação permitida` continua falsa enquanto revisão humana, FormatPack, QA e `publish_mode` não passarem.

Artefatos materializados:

- `creative-v2/publication_package.json`: vídeo e thumbnail fixados por SHA-256, título, descrição, 12 tags, categoria, idioma, audiência, privacidade `private`, créditos e disclosure `status.containsSyntheticMedia=true`;
- `creative-v2/human_review_checklist.md`: nove gates perceptivos com janelas e defeitos de inspeção obrigatória;
- `schemas/publication_package.schema.json`: contrato fail-closed com `upload_permitted=false`;
- `config/integrations/youtube-heroverse-v1.json` e `schemas/youtube_connection_receipt.schema.json`;
- `hero_engine/youtube_integration.py` e `scripts/connect_youtube.py`: OAuth instalado, Data API, Analytics API, verificação `mine` versus `forHandle`, token fora do workspace e receipt sem segredo;
- `hero_engine/publisher.py`: corpo testável com idioma, audiência e disclosure sintético oficial preservados.

A primeira implementação tentou expor o comando no CLI compartilhado. O teste de integridade da Fase 2 detectou corretamente `hero_engine/cli.py` como drift. A mudança foi removida, o hash histórico voltou a passar e o novo executor foi isolado em `scripts/connect_youtube.py`; nenhum manifesto histórico foi reescrito.

O OAuth chegou ao aviso oficial de app em teste/não verificado para a conta indicada pelo proprietário. A continuação desse aviso e a concessão persistente dos três escopos aguardam confirmação humana específica. Nenhum token foi criado, nenhum valor privado foi persistido e nenhum upload foi chamado até esse consentimento.

## Baseline histórico v1 — resultado objetivo

A Fase 5 materializou um protótipo DRAFT completo e reproduzível para o HeroVerse, comandado pelo Gestor Central e produzido pelo Diretor Criativo subordinado. O arquivo existe, foi medido e passou nos gates automáticos aplicáveis sem `FAIL`. Ele não foi publicado e não está autorizado para publicação.

O estado correto é `AWAITING_REVIEW`. O FormatPack avançou somente para `PROTOTYPED`; não é `VALIDATED`, `LIMITED` nem `PRODUCTION_READY`.

## Cadeia auditável

`central_command.creative_direction.json -> policy_decision.json -> creative_direction_decision.json -> channel_style_bible.json -> narrative_script.json -> take_plan.json -> asset_manifest.allocated.json -> voice_render_manifest.json -> render_manifest.json -> creative_quality_gate_report.json`

Todos os artefatos ficam em `output/production/phase5/pilot-001/`.

## Artefato produzido

- vídeo: `renders/move-after-amen.phase5-draft.mp4`;
- render ID: `render-c3fc1b1301f61f67f67c`;
- SHA-256: `960012b831a8334934a161c91dbb2939268e1f4a9a78ad77690d3616645beef1`;
- duração: 252,400 s;
- vídeo: H.264, 1920×1080, 30 fps, 7.572 frames;
- cor: 44/44 segmentos e saída final `tv/bt709/bt709/bt709`;
- áudio: AAC, -16,21 LUFS, -1,35 dBTP, LRA 2,3 LU;
- tamanho: 158.270.348 bytes;
- publicação: `false`.

## Produção take a take

- roteiro original em inglês: 599 palavras, versão 1.1.0;
- takes: 44;
- duração medida de fala: 239,447 s;
- timeline final: 252,400 s;
- erro máximo de duração por take: 0 ms;
- deriva cumulativa: 0 ms;
- janelas de hook: 0–1 s = 0,875 s; 1–3 s = 1,792 s; 3–8 s = 4,715 s;
- 44/44 origens dentro de intervalos seguros sem atravessar fronteira detectada de plano.

## Ativos, direitos e originalidade

- biblioteca ativa: 10 arquivos locais com hashes e evidência de licença;
- custo externo de licença/API: USD 0;
- um ativo licenciado foi reprovado pelo gate de conteúdo e removido do manifesto ativo;
- direitos automáticos do render: PASS;
- similaridade máxima de trigramas do roteiro contra quatro transcrições revisadas: 0,003407, abaixo do limite 0,02;
- a checagem automática não resolve publicity/release, marca, contexto ou análise jurídica final.

## Quality Gates

Relatório: `creative-qa-c1f266b64c5d3d7f7e4e`.

- PASS: 7 — estratégia, ChannelDNA, narrativa, técnica, direitos, originalidade editorial e custo;
- NEEDS_REVIEW: 9 — hook, coerência semântica, estilo, continuidade percebida, movimento, legibilidade, áudio percebido, publicity e identidade do canal;
- NOT_APPLICABLE: 1 — personagem recorrente;
- BLOCKED: 1 — publicação;
- FAIL: 0.

Defeitos: 7 PASS, 8 NEEDS_REVIEW, 4 NOT_APPLICABLE e 0 FAIL. A varredura mediu zero black frame, zero freeze, zero transição dura interna, p95 de delta de luminância 7,928945 e máximo intra-take 18,2727.

## Correções comprovadas durante o protótipo

1. O primeiro hook falava uma frase longa demais para 0–1 s. A solução preservou a tese no quadro inicial e reduziu a fala para “Amen.”, medida em 0,875 s.
2. Um ativo documental licenciado continha texto embutido e sequência estática incompatível. Foi bloqueado e substituído sem relaxar direitos.
3. O render inicial arredondava cada trecho e acumulava quase um segundo de deriva. A nova regra usa contagem exata de frames e resultou em 0 ms de deriva.
4. Um take atravessava uma edição existente na fonte. O scanner agora detecta fronteiras de plano e gera intervalos seguros.
5. Segmentos carregavam matrizes de cor diferentes. A saída foi normalizada e verificada integralmente em BT.709.
6. O amostrador de QA confundia o primeiro frame do take seguinte com o último intervalo do take anterior. O mapeamento passou a usar timeline medida, arredondamento `down` e uma zona explícita de incerteza de um passo apenas em cortes planejados.

## Tempo e custo

- voz local: 216,369161 s para 44 takes;
- render final: 564,416906 s, fator de tempo real 2,2362;
- núcleo voz + render: 780,786067 s, ou 13,013 min, em uma única observação;
- custo externo observado: USD 0;
- energia, hardware, armazenamento, depreciação e trabalho humano: `UNAVAILABLE`;
- o tempo observado não é SLA e não inclui busca de ativos, planejamento, QA ou revisão humana.

## Testes e evidências

- validação Draft 2020-12 de contratos, configs e artefatos estruturados;
- testes unitários de policy, seleção de FormatPack, registry, Style Bible, TakePlan, intervalos seguros e frame lock;
- FFprobe para codec, resolução, fps, frames, duração e cor;
- FFmpeg para loudness, black/freeze, signalstats e folhas de contato;
- hash de ativos e render;
- inspeção visual não independente do hook e das duas folhas de contato.
- manifesto de integridade: 118 arquivos, 862.430.314 bytes, todos conferidos por SHA-256;
- suíte final: 71/71 testes aprovados.

Qualquer regressão posterior reabre a fase.

## Critérios

### Aprovados automaticamente

- comando central e Policy Gate;
- escolha justificada de formato;
- Style Bible e TakePlan completos;
- direitos e hashes resolvíveis;
- roteiro original e funções narrativas;
- hook dentro das janelas temporais;
- timeline e sincronização estrutural;
- resolução, fps, codec, duração e cor;
- loudness/true peak;
- ausência de black/freeze/corte interno detectado;
- custo externo zero;
- publicação bloqueada.

### Pendentes de revisão independente

- força e clareza do hook como experiência completa;
- pronúncia, naturalidade, emoção e identidade vocal;
- coerência semântica de todos os recortes;
- continuidade percebida, movimento e compressão;
- legibilidade no vídeo completo;
- adequação de publicity/releases;
- distinção e aderência à identidade HeroVerse.

### Bloqueados

- publicação/upload;
- promoção para `VALIDATED` ou `PRODUCTION_READY`;
- Fase 6;
- Ads, gasto, credenciais ou ferramenta paga.

## Limitações

- um único vídeo e um único FormatPack não demonstram generalização nem resultado viral;
- não existem métricas privadas pós-publicação, retenção, CTR, RPM ou receita;
- nenhuma regra de desempenho foi aprendida; o registro criado é uma candidata de engenharia local;
- a inspeção visual executada pelo mesmo sistema não é o padrão-ouro humano independente exigido;
- custo local financeiro e recursos de pico continuam não medidos.

## Encerramento

Fase 5: `AWAITING_REVIEW`. O candidato vigente é `creative-v2.1`; a descrição v1 acima permanece somente como baseline auditável. A Fase 6 começa apenas depois da aprovação humana independente. A autorização condicional do proprietário cobre conexão/publicação depois desse gate, mas não autoriza Ads ou gasto.

## Adendo de auditoria crítica — 2026-09-03

Após solicitação de comparação rigorosa com o padrão de mercado e todos os requisitos anteriores, o candidato `creative-v2.1` foi **reprovado para publicação**. O relatório completo está em `docs/PHASE_5_MARKET_AND_VIRAL_REVIEW.md` e o contrato executável em `creative-v2/qa/market_readiness_review.json`.

Bloqueios confirmados:

- H1 falha: `Amen.` não declara tensão/contradição concreta em 0–1 s;
- H2 falha: `Now what?` não declara âncora espiritual + consequência pessoal em 1–3 s;
- 0–8 s utiliza uma única origem visual;
- 135,2 s fica 34,9218% abaixo do mínimo do arquétipo aprovado;
- 77,2929% da timeline é dominada por paisagens genéricas;
- um ativo ocupa 19,5 s com provenance contextual incompatível com o uso editorial pretendido;
- zero faixas de captions;
- thumbnail e áudio percebido permanecem sem challenger/CTR e revisão humana independente;
- FormatPack continua `PROTOTYPED`, `production_allowed=false`.

Os pontos fortes técnicos continuam válidos e devem ser preservados, mas não compensam gate crítico. Naquele checkpoint, a suíte passou em `79/79`; o manifesto continha `278` itens e `1.363.656.838` bytes. Publicação, Ads e Fase 6 continuaram bloqueados; o status OAuth foi atualizado no adendo posterior.

## Adendo de integração YouTube — 2026-09-03

O OAuth foi posteriormente concluído por D-043. Data API e Analytics API confirmaram `HeroVerse / @heroverse74 / UCuMF6pJQkyMzaVoAxFL86yA`; o probe de Analytics proprietário retornou 26 linhas diárias e o token foi reutilizado sem nova interação. O pacote editorial agora registra `connection_status=CONNECTED` e `identity_verified=true`.

Isso não altera a decisão criativa: `upload_permitted=false`, `dry-run`, revisão humana pendente, FormatPack `PROTOTYPED` e render rejeitado continuam bloqueando upload/publicação. Após a integração, a suíte passou em `80/80`; o manifesto contém `278` itens e `1.363.656.967` bytes.

## Adendo de prontidão do canal — 2026-09-03

Foi incorporado um gate independente do vídeo em `docs/CHANNEL_READINESS_MASTER.md`. A execução autenticada gerou snapshot, audit, receipt de mudanças, auditoria de catálogo e matemática YPP.

Correções externas verificadas:

- keywords antigas de super-herói/Marvel/IA foram substituídas por vocabulário do ChannelDNA;
- descrição diária falsa foi substituída e confirmada pela Data API;
- tradução inglesa conflitante “Paz e Clareza / Iron Discipline” foi alinhada;
- Home foi ativada e confirmada no perfil público com conteúdo. A primeira tentativa vazia foi revertida antes da segunda publicação validada.

Lacunas preservadas sem maquiagem:

- banner atual ainda conflita com o nicho e avatar contém anotação de exportação;
- novo banner/avatar/watermark passaram checks automáticos, mas estão `PROTOTYPED` e não foram autoaprovados;
- 21/21 vídeos públicos aguardam direitos e transformação; quatro duplicados, cinco claim-risk e três identidade legada;
- YPP oficial: 265 inscritos, 0 horas e 1.200 Shorts qualificados;
- OAuth conectado permanece `TIME_LIMITED_TESTING`;
- CTR/impressões permaneceram `UNAVAILABLE` no adaptador, sem estimativa substituta.

A matemática de 30 dias exige 24,5 inscritos líquidos/dia (44,1x o baseline) ou 333.293,33 Shorts qualificados/dia (aproximadamente 24.997x). É taxa necessária, não garantia. O pacote editorial agora referencia o audit do canal e contém seis razões independentes para manter `upload_permitted=false`.

Capacidade Codex: 2% da janela semanal usada, 98% restante calculado, nenhum limitador ativo, nenhum reset consumido e USD 0 de gasto externo iniciado. O gargalo é aprovação/evidência, não capacidade de Codex.

Verificação final deste adendo: 88/88 testes aprovados. O manifesto SHA-256 da Fase 5 contém 278 itens e 1.363.657.997 bytes.

## Adendo operacional — estação local de revisão D-065

O candidato vigente não é mais `creative-v2.1`: após as remediações versionadas, o arquivo STANDARD atual é `creative-v3.2`, SHA-256 `33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c`. Para fechar o único julgamento que não pode ser fabricado pelo gerador, foi implementada uma estação de revisão local em `hero_engine/phase5_review_console.py`, integrada ao loop do Gestor Central.

A estação exige reprodução integral/sequencial em 1×, cobertura temporal, captions, áudio, prévia móvel, identidade e conflito do revisor, nove janelas, doze gates, evidência por item, attestation e seleção cega A/B/C. O servidor valida novamente o contrato, separa tentativas inconclusivas e não sobrescreve receipt canônico. No estado observado, a estação está `LISTENING`, mas o receipt humano final ainda não existe; nenhum upload ou gasto ocorreu.

O teste integrado comprovou 403 sem token, 200 para interface/captions e 206 para byte range. O token ativo não aparece no stdout. A regressão vigente é 137/137, 67 schemas válidos e manifesto com 550 artefatos/3.080.032.782 bytes.
