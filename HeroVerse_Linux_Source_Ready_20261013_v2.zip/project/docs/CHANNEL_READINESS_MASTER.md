# Channel Readiness Gate — contrato permanente

## Objetivo

Impedir que um vídeo aprovado isoladamente seja publicado em um canal cuja identidade, promessa, catálogo, navegação, política, mensuração ou integração reduzam conversão, prejudiquem a revisão do YPP ou invalidem aprendizado. O gate pertence ao Gestor Central e é reexecutado antes de cada publicação.

## Entradas obrigatórias

- snapshot autenticado da YouTube Data API e YouTube Analytics API;
- observação autenticada do Studio para campos não expostos pela API;
- ChannelDNA e Style Bible vigentes;
- auditoria do catálogo público;
- contadores oficiais da aba Ganhos;
- receipt de conexão e prontidão operacional OAuth;
- pacote editorial do vídeo e seus gates próprios.

Dados são classificados como observados, calculados, inferidos ou indisponíveis. CTR, retenção, RPM, receita e elegibilidade nunca são inventados. Analytics watch time não substitui horas públicas qualificadas do YPP.

## Gates

1. identidade exata do canal;
2. coerência de posicionamento;
3. integridade da promessa pública;
4. arquitetura de conversão da Home;
5. alinhamento da mensagem visual;
6. ativos de perfil;
7. idioma e duplicação do catálogo;
8. disciplina de embalagem;
9. mensuração oficial do YPP;
10. adequação do catálogo à política de monetização.

Cada gate retorna `PASS`, `FAIL`, `BLOCKED` ou `NEEDS_REVIEW`, com evidência e ação requerida. Qualquer gate crítico diferente de `PASS` produz `BLOCKED_BEFORE_NEXT_PUBLICATION`. A média nunca compensa falha crítica.

## Fluxo operacional

`snapshot -> comparação com ChannelDNA -> gates -> prioridade de correção -> mudança autorizada -> verificação pública/API -> receipt -> novo snapshot -> pacote de publicação`

Mudanças externas são fail-closed: se a verificação pública divergir do esperado, a alteração é revertida quando possível e o incidente é registrado. O pacote de publicação consome o audit ID e não pode ignorar gates abertos.

## Aprendizado

Uma mudança de perfil não é chamada de melhoria por ter sido publicada. Para promover uma regra, o sistema registra baseline, hipótese, previsão, mudança única quando possível, janela, métricas comparáveis, resultado e incerteza. Sem nova evidência: `NO_NEW_EVIDENCE`.

O aprendizado do canal inclui:

- conversão por promessa e tema;
- CTR apenas quando a métrica privada estiver disponível por superfície comparável;
- retenção e inscritos por vídeo;
- progresso YPP oficial;
- coerência entre perfil, embalagem e conteúdo;
- incidentes de direitos, política e identidade;
- custo e tempo por correção.

## Done when verificável

- snapshot e audit validam contra schema;
- descrição, palavras-chave e localização são confirmadas por API ou perfil público;
- Home pública contém conteúdo e não apresenta estado vazio;
- marca aprovada não conflita com o ChannelDNA e passa revisão visual independente;
- catálogo legado possui decisão e evidência por vídeo;
- contadores YPP oficiais e lacunas aritméticas estão registrados;
- OAuth é durável para operação contínua;
- pacote de publicação referencia o audit atual e permanece bloqueado se qualquer gate crítico estiver aberto.

## Limites

Este gate melhora prontidão e coerência; não garante distribuição, viralização, monetização ou prazo. Ele não substitui revisão humana independente, revisão jurídica/editorial de direitos nem os gates do vídeo.
