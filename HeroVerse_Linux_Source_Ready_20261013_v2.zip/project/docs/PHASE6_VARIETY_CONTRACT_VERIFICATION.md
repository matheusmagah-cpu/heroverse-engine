# Variedade AV — contrato isolado, ainda não instalado

Checkpoint08/09/2026. Complementa PHASE6_CONTINUOUS_COMPOSITION_BOUNDARY.md sem
alterar consumidores legados nem aceitar o candidatoA/B/C como resultado real.

- `hero_engine/phase6_av_variety_contract.py`, SHA256
  `1ab6129ee28926db6bfe1867e69069a95042db5f2d5da323bedcb5bfd2df8566`.
- `tests/test_phase6_av_variety_contract.py`, SHA256
  `7702f74e0d40d9c1d206a677b623187390ee44374fd587ae79c905d92c05153e`.
- Execução única do agente control_worker_finish: terminal `e2232b`, exit0,
  `Ran 14 tests in 0.045s`, `OK`; reconfirmado pelo agente ao root nesta retomada.
  Terminal não foi salvo em arquivo pelo executor. Não inventar um stdout
  original nem repetir testes intactos só para produzir outro log.
- Root leu módulo/testes integralmente na execução anterior e conferiu os pins
  `07b59d`; nova revisão independente read-only em andamento nesta retomada.

## O que o contrato faz

Funções puras calculate_variety/verify_diagnostic: grade30fps/24kHz/800samples,
frames inteiros, exposição pela união temporal de cada ancestral, inclusive
pausas e overlays. Exatamente um BASE por segmento físico com cobertura completa.
Aliases não criam fontes; mesmos bytes com ancestralidade conflitante falham.
Soma de participações simultâneas pode ultrapassar100%, sem esconder componentes.

Mantém limites:fonte10%,top6 55%,reuso5,rolling60s3,adjacência0,overlapprévio0,
mínimo12. CUT/RESTART não podem ser fundidos por nome de arquivo. CONTINUOUS
declarado não é prova de movimento. Rolling inclui a borda exata1800frames.

As contagens legadas por take e propostas por ocorrência ficam separadas.
Sem referência reaberta de mídia e observação, contagem observada/aceita=null,
gatesNOT_EVALUATED,qa_pass=false e todas as autoridadesfalse. Doze ancestrais
declarados não são doze fontes independentes verificadas.

## Limites e próximo consumidor

Não há input real de variedade paraA12: seus spans/tempos/render ainda faltam.
Não criar frames de conveniência, finalmedia fictícia ou 3A/1B/1C aprovados.
Reuso do candidato metadata871d03d0… não preenche essas lacunas.
Próximo passo é fonte/compositor com continuidade efetivamente observada,
consumidor versionado e integraçãoD/quality, mantendo direitos/tempo/áudio.
Este incremento não fecha59estados, GC01, Vídeo2 ou Fase6.
