# Impacto da correção — Gestor Central Autônomo

## Estado desta entrega

- Revisão: `AWAITING_REVIEW`.
- Fase corrente: Fase 1, ainda não concluída.
- Runtime do Gestor: não implementado nesta revisão.
- Fase 2: `NOT_STARTED`.
- Publicação e gasto: continuam bloqueados.
- Requisito integral preservado em `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`.

## O que foi incorporado

A Inteligência Contínua Viva deixa de ser somente uma camada coordenadora futura e passa a ser, por contrato permanente, o Gestor Central Autônomo de 100% da operação. O usuário é o proprietário e supervisor por exceção. Todo módulo atual ou futuro será executor subordinado, sem estratégia, memória, fila ou autoridade paralela.

O Gestor administrará metas e orçamento; mercado; nichos, canais, formatos e temas; mineração frame/take; hooks, embalagem e narrativa; coortes, `ChannelDNA` e arquétipos; calendário; títulos, thumbnails, roteiros e blueprints; ativos, render e QA; pacotes de publicação; filas, agendas, retries e incidentes; métricas e atribuição; hipóteses e experimentos; regras e otimização; custos e capacidade; isolamento; versões, segurança e rollback; previsões, incerteza e relatório executivo; e qualidade dos próprios módulos.

## Antes e depois da correção

| Tema | Contrato anterior | Correção incorporada |
|---|---|---|
| Papel da inteligência | Coordenadora persistente | Gestor único de toda a operação |
| Autoridade | Recomenda/executa ações autorizadas | Autonomia rotineira dentro do envelope; exceções ao proprietário |
| Comando | Orquestrador planejado | Fila, prioridade, estado e decisão exclusivamente centrais |
| Módulos | Componentes separados | Executores subordinados, sem estratégia paralela |
| Conhecimento | Memórias tipadas e Rule Registry | Conhecimento único, versionado, com aplicação futura medida |
| Aprendizado | Ciclo até aplicação futura | Inclui baseline, previsão prévia imutável e nova medição |
| Previsibilidade | Faixa, evidência e confiança | Calibração formal contra baseline e fora da amostra |
| Supervisão | Gates humanos | Proprietário acompanha exceções, custos, alertas e decisões importantes |
| Continuidade | Scheduler/orchestrator futuro | Liderança única, lock, idempotência, checkpoint, replay e recuperação |

Nenhuma regra anterior foi removida. A autonomia continua subordinada às fases, direitos, políticas, orçamento, credenciais, identidade, gates e aprovações permanentes.

## Mapa de reaproveitamento

| Existente | Reaproveitamento futuro | Lacuna atual |
|---|---|---|
| `hero_engine/db.py` e SQLite | Adaptador de persistência do piloto | Sem migrações, ledger append-only, lock ou estados centrais |
| `hero_engine/youtube.py` | Executor de observação/auditoria | Sem coletor governado pelo Gestor e sem eventos idempotentes |
| `hero_engine/modeling.py` e mineradores | Executores de análise/modelagem | Sem benchmark por campo contra padrão-ouro humano |
| `hero_engine/planner.py` e `shotlist.py` | Executores de blueprint e montagem | Sem `ApplicationPlan` versionado derivado de regra aprovada |
| `hero_engine/quality.py` | Executor de quality gate | Sem scorecard longitudinal do módulo e detecção de regressão |
| `hero_engine/publisher.py` | Executor protegido de pacote/upload | Fila em JSON; sem comando central transacional ou política por envelope |
| `hero_engine/decision.py` | Base de decisão determinística | Sem hipótese, experimento, evidência contrária e Rule Registry |
| `hero_engine/forecast.py` | Base matemática | Sem previsão pré-registrada, outcome vinculado e calibração formal |
| `scripts/daily.ps1` | Entrypoint temporário de execução | Não é scheduler persistente, líder único ou mecanismo de recuperação |
| Testes atuais | Regressão do baseline | Não cobrem autonomia, aprendizado, previsão ou concorrência |

## Impacto na fase atual

A Fase 1 continua limitada à criação do padrão-ouro. Após aprovação desta revisão, ela deve retomar no gate da amostra D-012. A única adaptação imediata é garantir que o padrão-ouro humano produza proveniência e métricas por campo suficientes para, em fases posteriores, medir a qualidade do minerador. Nenhum serviço central, banco novo, fila, scheduler, agente ou automação será construído na Fase 1.

## Lacunas verificadas

1. Não existe fonte operacional única nem estado global/por canal do Gestor.
2. O banco é mutável e não possui Event Ledger append-only ou migrações versionadas.
3. Não existe lock/leader election, fila transacional, dead-letter queue, checkpoint, replay ou recuperação.
4. Memória factual, episódica, semântica, decisória e operacional não está separada por contrato.
5. Não existem hipóteses falsificáveis, experimentos, avaliações, regras versionadas ou aplicações futuras ligadas ao resultado.
6. Não há previsão imutável anterior à observação nem avaliação MAE/MAPE, cobertura, Brier/log loss ou uplift contra baseline.
7. Não há scorecard longitudinal de sistema, conteúdo e operação/comercial.
8. O minerador não é comparado automaticamente com um padrão-ouro humano por campo.
9. Não existe envelope operacional executável nem matriz de ações protegidas.
10. Não há relatório executivo único que reconstrua comando, custo, risco, decisão e resultado.
11. Analytics próprio ainda não tem amostra; `performance_snapshots` está vazio.
12. O conflito de direitos de `5-zdruoQKlM` permanece bloqueado pela D-010.

## Conclusão da auditoria

A correção é compatível com o projeto desde que seja implementada incrementalmente nas fases existentes. O desenho não substitui o código atual: ele transforma os módulos atuais em executores e adiciona governança central acima deles. Nesta entrega, somente contratos, schemas draft, critérios e plano foram incorporados.
