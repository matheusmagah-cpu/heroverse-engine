# 04 — Especificação de produção por recortes

Regra transversal: YPP-INAUTHENTIC-2025-07-15 em `08_POLICY_AND_RIGHTS.md`.
Direitos/OWNED e QA técnico não substituem contribuição original e valor real.
No ramo instrumental, preservar composição/sound design/arranjo e avaliar
substância no catálogo; não chamar loop reembalado ou score de IA de aprovação
YPP. Formato estático não é proibido por si. Falta de evidência não vira PASS.

## 1. Objetivo

Produzir vídeos novos, adequados a um nicho e a um arquétipo validado, usando recortes permitidos como matéria-prima principal e acrescentando nova construção editorial. Evitar geração integral de vídeo quando a biblioteca de ativos consegue entregar qualidade.

## 2. Ordem obrigatória

1. congelar cutoff, sinais contemporâneos e cobertura;
2. definir audiência e intenção dentro do nicho;
3. ranquear no mínimo três oportunidades por tração relativa, novidade, saturação, evidência e risco;
4. selecionar tema com decisão e rejeições auditáveis;
5. criar ângulo próprio;
6. definir promessa;
7. criar conceito de título e thumbnail;
8. definir o que o hook deve provar em 0–1 s, 1–3 s e 3–8 s;
9. montar beat sheet e narrativa;
10. o Gestor emitir comando ao Diretor Criativo;
11. comparar FormatPacks elegíveis e justificar escolha ou bloquear;
12. definir perfil DRAFT/STANDARD/PREMIUM/CINEMATIC;
13. materializar Channel Style Bible e bíblias condicionais;
14. criar roteiro e TakePlan completo;
15. buscar recortes semanticamente compatíveis;
16. verificar direitos e origem;
17. montar timeline a partir dos takes;
18. criar voz, texto ou condução editorial;
19. aplicar e verificar identidade/continuidade;
20. revisar promessa, narrativa e originalidade;
21. renderizar;
22. executar os gates criativos e permanentes;
23. solicitar aprovação.

Não escreva o roteiro completo antes de aprovar a embalagem e a entrega prometida.

O nicho e os gates não mudam na rotina. As escolhas criativas mudam com os sinais documentados em `docs/13_ADAPTIVE_VIRAL_EDITORIAL_ENGINE.md`. Views brutas, urgência vazia e um outlier isolado não substituem a comparação normalizada.

## 3. Transformação narrativa

O novo vídeo deve possuir:

- público ou contexto claramente definido;
- ângulo editorial próprio;
- pergunta central própria;
- seleção e ordem próprias;
- estrutura de progressão própria;
- texto, roteiro, voz ou condução próprios;
- relações novas entre os recortes;
- provas e explicações compatíveis com o nicho;
- payoff próprio;
- CTA próprio;
- identidade visual do canal.

Crop, zoom, espelhamento, mudança de velocidade, filtro, borda, legenda ou música são técnicas de edição. Isoladamente, não constituem transformação editorial.

## 4. Fonte dos recortes

Cada recorte precisa de:

- `asset_id`;
- arquivo ou URI controlada;
- origem;
- criador/detentor quando conhecido;
- licença/status;
- permissões comerciais;
- atribuição exigida;
- restrições;
- data de verificação;
- hash;
- projetos em que foi utilizado.

Estados permitidos estão em `docs/08_POLICY_AND_RIGHTS.md`.

## 5. Busca de recortes

A busca deve considerar:

- significado do bloco narrativo;
- ação e objeto;
- emoção;
- ambiente;
- movimento;
- orientação e proporção;
- qualidade;
- compatibilidade visual;
- disponibilidade de direitos;
- histórico de reutilização interna;
- diversidade em relação a vídeos anteriores.

O ranking não pode considerar apenas similaridade textual. Direitos e função narrativa são filtros anteriores ao score visual.

## 6. Hook de produção

O blueprint deve especificar:

### 0–1 segundo

- quadro de entrada;
- estímulo visual;
- primeira palavra ou texto;
- interrupção de padrão;
- promessa percebida.

### 1–3 segundos

- confirmação ou escalada;
- primeiro movimento/corte;
- curiosidade mantida;
- conexão com título e thumbnail.

### 3–8 segundos

- contexto mínimo;
- razão para continuar;
- direção da narrativa.

O hook deve nascer do arquétipo minerado. Não use uma receita genérica desconectada das referências.

## 7. Timeline

Cada segmento possui:

- início e fim;
- função narrativa;
- fala/texto;
- pergunta aberta;
- recorte selecionado;
- transformação aplicada;
- fonte e direitos;
- transição;
- áudio;
- evidência de alinhamento com o blueprint.

O segmento não substitui o take. O TakePlan conforme `schemas/take_plan.schema.json` é a unidade obrigatória de produção e registra também emoção, mídia, FormatPack, composição, câmera, movimento, iluminação, personagem, cenário, ação, áudio, ferramenta, versão, custo, continuidade e função de retenção. As janelas do hook possuem cobertura explícita.

## 8. Quality gates

### Gate editorial

- promessa clara;
- hook alinhado;
- progressão sem repetição;
- provas suficientes;
- payoff entregue;
- adequação ao nicho.

### Gate de fidelidade

- pertence ao arquétipo;
- invariantes preservados;
- variáveis utilizadas corretamente;
- duração e ritmo dentro das faixas justificadas.

### Gate de originalidade

- nova tese ou novo contexto;
- nova narrativa;
- nova ordenação e função dos elementos;
- distância suficiente de qualquer referência isolada;
- contribuição editorial reconhecível.

### Gate de direitos

- todos os ativos com status permitido ou revisão aprovada;
- atribuições geradas;
- evidência de permissão preservada;
- nenhum ativo `UNKNOWN` na renderização final.

### Gate técnico

- duração, proporção, resolução e codec válidos;
- áudio inteligível;
- ausência de quadros pretos, cortes quebrados ou texto cortado;
- safe areas respeitadas;
- arquivo reproduzível.

### Gates do Diretor Criativo

- FormatPack utilizável e versão congelada;
- fidelidade ao ChannelDNA e Style Bible;
- coerência semântica de cada take;
- estilo e continuidade entre takes/cenas/episódios;
- personagem, anatomia e cenário quando aplicáveis;
- movimento, física, flicker, ghosting, frames duplicados e compressão;
- legibilidade, safe areas e identidade;
- voz, pronúncia, pausas, sync, mix, loudness, clipping e direitos de áudio;
- custo dentro do envelope;
- relatório conforme `schemas/creative_quality_gate_report.schema.json`.

Falha crítica não pode ser compensada por média nem por uma imagem isolada bonita.

## 9. Saída

- blueprint conforme `schemas/production_blueprint.schema.json`;
- manifesto dos ativos;
- timeline;
- projeto/versionamento de edição;
- render de revisão;
- relatório dos gates;
- log de custo e tempo;
- pacote de publicação ainda não enviado.
- `CreativeDirectionDecision`, FormatPack, Style Bible, TakePlan, perfil de qualidade e relatório de 18 gates.

## 10. Comando e aplicação de aprendizado

Quando autorizado e implementado, cada produção nascerá de um `central_command` e, quando aplicável, de um `ApplicationPlan` que identifique regra, versão, evidências, mudança concreta, previsão prévia, canal e envelope. Planejador, montador, quality gate e publicador permanecem executores. Nenhum deles libera direito, custo, publicação ou exceção por conta própria.
