# D-140 — Prova visual literal antes de novo render completo

Fase 6 continua `IN_PROGRESS`. Este documento registra um protótipo de fonte/composição, não aprovação de vídeo, FormatPack, biblioteca de ativos ou publicação.

## Resultado real

A composição local dos takes012–023 demonstra duas colunas, como exige a narração, mantendo os 12 WAVs e a timeline originais. Produzida em 1920×1080/30fps, 36.400 ms, 1.092 frames. Não há terceiro card, paisagem substituindo a demonstração, movimento de câmera sobre texto nem alteração do conteúdo da voz.

A revisão independente por outro agente abriu os dez frames em resolução original, conferiu as transições dos exemplos e recalculou hashes/sinal. Não é revisão humana do padrão-ouro. Resultado: **PASS somente para protótipo visual local de duas colunas; NOT ELIGIBLE para produção/publicação**.

| Evidência | Resultado e limite |
|---|---|
| Frames 13.500 e 15.267 ms | Somente o fato da reunião na coluna FACT; FORECAST vazio. |
| Frame 15.333 ms | A previsão aparece após a fronteira do take018. |
| Frames 19.500 e 21.667 ms | Novo fato sobre a resposta na coluna FACT, sem previsão antecipada. |
| Frames 21.733 e 27.000 ms | Previsão na coluna direita e par mantido na continuação. |
| Frame 34.000 ms | Fechamento FACT/FORECAST fiel ao exercício. |
| Texto em duas linhas | Fonte preservada; LF explícito corrige o espaçamento real, sem reduzir fonte ou esconder texto. |
| Integridade | 83 artefatos, oito inputs e dez frames conferidos independentemente. |
| Áudio decodificado | Correlação zero-offset 0,9999793296707836 contra WAVs + padding original; pico 0,7664794921875. Prova de alinhamento/sinal, não prosódia. |
| Produção | 21,905945 s de render e 31,655359 s totais, medidos nesta execução. Não extrapolar para o vídeo completo. |
| Custo | R$ 0,00 adicional, zero nova chamada de TTS/API, fila ou publicação. |

## Artefatos verificáveis

- Pasta: `output/qa/phase6/diagnostics/two-column-proof-61b9b5c0b76e39fa3d2ff30f`.
- MP4: `fact-forecast-source-proof.mp4`; SHA-256 `092e46d19d5312b9379df5314b17d345e16bfcba590922c0ab456e07e0c383af`.
- Receipt: `receipt.json`; SHA-256 `5adaa57e8ff966cb2c31c09de8a4ddd74cc7b753f7428b2c54e912c6acd6f6f4`.
- Preflight: `preflight.json`; SHA-256 `d2093634310895a60ff8ae5aebca2bf2a3570c5d9bd2a277856d661c19f6820e`.
- Plano: `source-plan.json`; SHA-256 `fa7050c37f47f01ad761239d95b09dd6ce320dc6de9e8823ed30cb2890a530f7`.
- `layouts.json`, `video-filters.txt`, `command.json`, `probe.json`, log, PNGs, texto e áudio decodificado estão hash-bound no receipt. Os arquivos não possuem imutabilidade de filesystem; o runner recusa sobrescrita e os hashes detectam deriva.

## Causa corrigida e controle negativo

A primeira prova, `two-column-proof-800e89874015a7de67be6238`, preservou a semântica, mas a imagem real mostrou espaçamento multiline incompatível com o layout medido. A revisão identificou CRLF nos textfiles: a escrita em modo texto do Windows convertia o LF medido pelo Pillow. A hipótese inicial de diferença de fonte foi substituída pela causa demonstrada.

`_write_text_atomic` agora emite bytes UTF-8 com LF explícito. A receita visual passou a v4 e a de duas colunas a v2. Um teste renderiza dois frames com o mesmo texto, fonte, geometria e FFmpeg: LF cabe no limite previsto; o controle CRLF excede o limite em mais de 30 px. Esse teste de backend aconteceu **antes** da segunda prova de 36,4 s.

O primeiro MP4, receipt e oito inputs copiados/hash-verificados em `review-source-snapshot` permanecem preservados. Não reutilizar a primeira prova como PASS visual. Testes focais atuais: 23/23 visual-recipe + two-column PASS em 2,389 s, incluindo o teste real LF/CRLF. Não é regressão integral nem implantação.

## Lacunas que continuam bloqueando a produção

1. Narração: o áudio histórico mantém padding de 1.196 ms em `In the first, | write...`, 1.121 ms em `In the second, | write...` e 1.188 ms em `your | identity`. Correlação alta não prova naturalidade; nenhum agente alegou escuta.
2. A receita prova apenas esse exercício. Não resolve as 49 incompatibilidades semânticas do candidato completo nem o hook/paginação do framework.
3. O plano de fonte é schema-validado, mas receipt/preflight diagnósticos ainda não são o contrato operacional de admissão. Direitos, biblioteca, capacidade para novo TakePlan integral, Quality Gates e sucessor transacional continuam exigidos.
4. Não há música/mixagem/masterização nesta prova. Estados gráficos mantidos deliberadamente não podem receber aprovação de movimento nem reprovação de duplicidade sem considerar sua função narrativa.
5. Nenhum input operacional, job, manifesto de voz anterior, MP4 histórico ou estado público foi alterado. Nenhum FormatPack foi promovido.

## Continuidade do trabalho

Reconciliar o candidato completo em uma mudança integrada: hook em camadas, progressão TRT, fontes concretas, prosódia desvinculada dos cortes visuais e fechamento. Depois, provar capacidade/receipts/novos ativos e executar sucessor, regressão/implantação, render final e QA. O protótipo não é atalho entre esses gates.

## Hook 003 — região comum medida, antes da prova audiovisual

### Resultado posterior — tracking renderizado em cinco segundos

Prova `layered-hook-tracked-proof-8ef8140c806785f7b2bbb160`, attempt002: 150 frames, 5,000 s, 1920×1080/30 fps. MP4 SHA `213349f0cd6b8a68f0279a0181abeb46e44f62d64c6dc5bcba2bfdcd0bbf6f29`; receipt SHA `80f7564bc606c80f23ef153b958318387df634f1614e8e25cd03660b972f8ade`. O responsável principal rehashou oito bindings, abriu frames0/75/149 e registrou revisão independente ao lado. Labels agora acompanham os papéis nas amostras; aprovação de movimento integral permanece pendente. Sem TTS novo, extração FFV1, API, fila ou custo adicional.

Attempt001 preservado: encoder terminou, mas `overlay:shortest=1` entregou149frames/4,966667s. Contraprova backend com três frames mediu2 no negativo e3 no positivo `eof_action=repeat:shortest=0`, confirmando o overlay final correto antes do attempt002. Renderer e comando receberam identidades novas. Os artefatos rejeitados não foram sobrescritos nem recebem PASS.

A correlação de áudio0,9999866 é alinhamento de sinal, não escuta/pronúncia. Backing de alto contraste é um adesivo gráfico deliberado; não afirmar tinta fotorrealista. Prova diagnóstica não admite ativo, não altera Bible, não autoriza produção nem substitui Quality Gates integrais.

### Resultado posterior — prova estática produzida e rejeitada para tracking

O diagnóstico `layered-hook-static-proof-924b871d9d9af8cbea151882` produziu150frames/5s/1920×1080/30fps, com fonte e WAV003 exatos reutilizados;27,154249s de render/50,083909s totais. MP4 SHA `7e4421e807c66cc45519c769ac52396fede86028581f4c62273d478e0becfc64`, receipt SHA `7fd338134454bb1e98976bc15ed968cff722693a53b4cb0ed4c9f81dac873c9e`. Dez inputs e cinco frames foram reabertos/hash-verificados pelo responsável principal; não houve nova extração FFV1 ou TTS/API/fila/gasto.

A revisão principal dos frames0/75/149 constatou labels legíveis e contidos, mas fixos na tela enquanto os papéis se deslocam. **FAIL para continuidade/tracking no papel.** Não converter contenção150/150 em aprovação de movimento. O painel TRT separado é intencionalmente fixo; o defeito refere-se aos labels que deveriam pertencer aos cartões. A correlação de áudio0,9999866414300111 comprova somente sinal/alinhamento zero-offset, não pronúncia/naturalidade/escuta.

O receipt original de geração continua imutável e pendente de avaliação; esta avaliação posterior o rejeita para esse requisito sem reescrevê-lo. A correção seguinte deve usar transformação medida por frame, preservar margem/legibilidade, gerar três PNGs antes de outro encoder e ser revisada independentemente. Não inventar uma receita histórica de câmera cuja proveniência só registra derivação de movimento, sem comando exato.

Diagnóstico isolado `layered-hook-static-geometry-5134aa42820475a5f2f8d433` reutilizou o FFV1 existente, sem nova extração de fonte ou MP4. A interseção dos contornos convexos dos cartões nos 150 frames admitiu os textos NAME/TEST/CHOOSE em fonte 84 px, com backing de 10 px horizontais e 8 px verticais. A busca de 12 px horizontais não encontrou uma posição comum; não houve redução dos gates de contenção/margem.

Posições propostas: NAME `[232,662,484,767]`, TEST `[853,662,1062,767]`, CHOOSE `[1412,662,1755,767]`. O painel secundário TRT permanece separado em `[154,95,791,255]`. Receipt SHA `9917c0201c58643810f48ac1e6791a089a9c4c9d7c35aeca101b63f4d3b509dd`.

Contraprova principal: 8/8 bindings de arquivos reabertos, 150 índices ordenados e 1.800 distâncias dos cantos aos hulls recalculadas por geometria independente do gerador. Contenção integral e margem mínima `8,19490616290585 px` confirmadas. A máscara fotométrica por pixel não foi recalculada pelo responsável principal; seu resultado 1,0 permanece evidência do diagnóstico, não contraprova independente.

Estado `PASS_GEOMETRY_PROPOSAL_NO_RENDER_AUTHORITY`. Região comum não demonstra que o texto pareça preso ao papel durante o movimento. Próximo gate é prova audiovisual isolada de cinco segundos com fonte e WAV originais, sem TTS, seguida de revisão de movimento/legibilidade/sincronia. Produção/publicação continuam falsas. A primeira execução diagnóstica perdeu uma leitura por path de fonte externo; a segunda concluiu. Esse retrabalho não foi ocultado e exige preflight completo dos bindings/serialização e persistência intermediária nas próximas execuções.
