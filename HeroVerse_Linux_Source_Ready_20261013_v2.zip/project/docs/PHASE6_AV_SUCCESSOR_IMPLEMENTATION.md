# Fase 6 — Integração do sucessor audiovisual

AtualizaçãoD171/A8: união literal26 recomposta dos51PCM/90fragmentos/100estados
visuais e71cues. Receipt reala944a4f5…/timeline9542021b…;4,297s, custo0. C11/
schema1.10/adapterv7 mantêm restrições. Leitor13PASS, A9novos+6afetadosPASS,
consumidores/bundle15PASS em lotes distintos. O novo scope_complete não é tempo,
fonte, calibração ou admissão: TEMPORAL_VISUAL_STATE_BINDINGS_PENDING preserva
all_required_evidence_live=false e todo o grafo produtivo bloqueado. O cohort30
não cabe nas23candidatas restantes; resolver origem/calibração genuína, não
diminuir mínimo para usar corpus reprovado. Os checkpoints abaixo são históricos.

AtualizaçãoD171/A7: o plano literal71cues entrou no build real,51PCM preservados,
sem novo agendamento ou áudio. Receipt e0e3a53c7182d3dae85a28ea87f3725fa10701b1870364342e43f459c7949949;
timeline05a4cc9c…/statusBLOCKED_INCOMPLETE. A7/schema1.6 e C10/schema1.9/adapterv6
passaram os lotes focais registrados emSTATE. O escopo parcial soma21alvos
declarados e mantém51exclusões conservadoras. Captions literais completas não
fecham intenção visual, calibração ou percepção. Próxima integração deve
declarar a cobertura visual sem precisar de timestamps que dependem dela;
preservar separadamente fontes, direitos/publicity, áudio/banda, execuçãoC e QA.

Resultado posterior: A6real07084756… materializada em6,422s, receipt09858928…,
com11fontes; quatro alvos declarados,51exclusões conservadoras e escopo incompleto.
Não houve decode de vídeo, nova voz, alinhamento, calibração ou publicação.
O read-only inspector reabre as PNGs para a nova integração A; não é rerender.
Regressão dirigida70casos em execução. O plano literal sem timestamps ainda
precisa entrar no contrato, sem reduzir gates ou trocar a referência temporal.

Correção corrente D171: o bundle parcial909f7dbd… e a intenção82df010c… existem
com hashes verificados, mas build A não foi executado. A revisão encontrou que
A5 poderia chamar os quatro alvos declarados de união completa. A6/schema1.5
separará declaração, exclusão conservadora e completude calculada; o consumo
de calibração será bloqueado antes de inspecionar suas provas quando parcial.
C9/schema1.8/adapterv5 estão em implementação e exigem testes/pins próprios.
Não confundir essa proteção com o planejamento literal global ainda necessário:
este deve ser completo antes da seleção de holdout e não depender de timestamps
inventados ou usar o cohort antigo30 incompatível com mínimo26 já conhecido.

AtualizaçãoD171 posterior: registro03fbe140…/SHA36857c5b… materializou22documentos
e11provas restritas de direitos. Consumidor B cruzado com as11fontes reais e
hashes compactos de A passou; grupo11/11PASS,receipt5778c028…. Rightsv2 corrige
domínios de hash sem reclassificar imagens como vídeo. Permanecem duas linhagens.
Este é vínculo real de direitos, não admissão B completa, publicidade ou release.
O próximo bundle A será parcial, sem eventos/timestamps/pausas inventados, e
preservará as nove fontes, argumentos anteriores e bloqueios da união final.

Atualização07/09,D171: inspector PNG v2 prende11estados/2linhagens e19arquivos
Pillow+fonte; A5/schema1.4 separa STATIC_IMAGE[0,1) de VIDEO_CFR, C8/schema1.7
limita hold por frames da timeline; adapter duas colunasv4 mantém limites.
35/35focais iniciaisPASS; regressão82 teve3fixtures incompatíveis, corrigidas
e retestadas3/3PASS. B direitos1.1 acrescenta comprovação tipada e rechecagem
final,17/17focais consumidor+legadoPASS; verificador de direitos10+1PASS em lotes
distintos. Hashes/receipts emSTATE. Não existe B LIVE, C executável ou QA aprovado
por essas provas. As decisões de uso são editoriais automatizadas e não gold
humano, publicity ou parecer jurídico. O registro imutável ainda está sob teste.

Próximos vínculos obrigatórios: fontes/metadados próprios no scanner aplicável,
capacidade real por receita, verificação específica de hold intencional e
continuidade no vídeo final, união temporal completa e calibração/percepção
genuínas, depois cadeiaA–D/produção/release. Nenhuma duração de fonte ou palavra
será inventada para satisfazer um consumidor originalmente exclusivo de vídeo.

Atualização07/09, D-168: supervisor automático Windows concluído (17testesPASS) e reconciliação ASR existente ampliada sem inferência (11testes/8contraprovasPASS). Unidade014/015 também apresenta desacordo contextual; não reduzir o problema à lista antiga de cinco. DNSMOS permanece diagnóstico do stem WAV8e8909fe…, não mixagem final ou calibração. Rotina de escuta não é tarefa transferida ao proprietário.

Auditoria reconfirmou integração conjunta obrigatória: `phase6_quality.py` ainda consome voz1.2por take/captions==takes, não51unidades/71cues/90takes; seu verificador chama builder que pode repetir ASR/medições. Próxima versão não deve apenas anexar MOS ao gate antigo. Exigir extração pinada do vídeo final, render/A/timeline/mixagem/PCM exatos, avaliação separada de todas as dimensões e replay sem inferência. Testes negativos: stem diagnóstico como vídeo final; troca de stream/receita/modelo; gold de mineração como acústico; ASR/níveis bons sem percepção/prosódia; temporalidade ausente; timeout/retry. Todos devem falhar fechado. Implementação/deploy/regressão dessa integração permanecem pendentes até entrada audiovisual aplicável, sem reclassificar o supervisor como etapaA/C/D pronta.

Atualização07/09,01:45UTC / D-161: fonte técnica incorporada via verificador puro v1, bodyadapterv3 e C v7/schema1.6. Receipt real25fe4e90… e25dependências reabertos sem efeito; identidade/bounds/linhagem presos.48testes de software PASS, distribuídos8verificador/26body/14C; fonte anterior intacta. Relatório `av-clean-plate-binding-v7-root-result.json` SHA9693a737373b4614ff058d7d096d9a9256907a1194edbafcfea0e545fcbed40c. Integração REALb5184c… continua A incompleta/zero spans/grafonull, não é um render nem um Done when A/B/C/D completo.

Auditoria focal confirmou que não há gold temporal nem escuta genuína aplicáveis já disponíveis para ligar. Próxima prioridade: policy anterior à estimação, referências holdout elegíveis anotadas e revisão perceptual do master exato. ASR existente pode ser reutilizado somente como método acústico secundário. A proposta editorial anterior proíbe preencher5.020ms para bater207.800ms; não substituir função narrativa por ajuste aritmético. Duração/grade e demais gates continuam abertos. Não produzir mais variações de clean plate ou repetir mídia enquanto o bloqueio é de evidência sonora.

Atualização07/09,01:17UTC / D-160: a base limpa agora existe e passou verificação técnica REAL. Fonte `two-column-clean-plate-v1-ef0d956239c512d0/clean-plate.mkv` sob diagnósticos, SHA7031f3abc85881e10e2c8b78875b935fa07705a1844dfbeb98b1513cc7529471; receipt25fe4e9047971a8f88d86ce5de07f8ea15b042831ab5fa96b2e277689811ac7a. RGB literal em1.800frames, clock e stream único sem áudio. Uma linhagem;60s=capacidade da fonte, não duração narrativa.15testes focaisPASS; efeitos únicos e replay sem subprocessos. Rootreport `clean-plate-v1-root-result.json` SHA8e4bd3eb139a6711288d4480bf37dddcff3b138ac91aa0592c1a5f20e9ace5d5.

Isso fecha apenas a fonte técnica antes ausente. O adapter ainda precisa consumir seu receipt e os spans da timeline editorial válida; não modificar A com o relógio antigo, não declarar `source_ready` de composição pelo fundo isolado e não liberar admissão/publicação. Calibração, percepção, banda/grade e demais Done when seguem abertos. Não repetir fonte, voz, ASR ou hook concluídos.

Atualização07/09,00:41UTC / D-159: A v4/schema1.3 implementa o evento estrutural `UNIT_BOUNDARY`/`WHOLE_UNIT_PCM_START` sob intenção1.1. Frame exato do PCM, primeiro fragmento/span coincidentes e nulos lexicais; não é onset de palavra. Adapterv2 limita aos nove pares take/unidade congelados;014/016 permanecem lexicais,021HOLD. A união de holdout só exclui instância estrutural reconstituída, mantendo qualquer alvo lexical/caption na mesma unidade. C v6/schema1.5 exige A v4, sem ampliar autoridade ou cobertura.

Root33testes PASS60,095s; executor12novos/3legados PASS; revisão separada e pins finais confirmados. Evidência `av-unit-boundary-v4-root-result.json`, SHA2293e64174cf58d6a20ff9434ba0609cb122afec0b0709c7040ad46b9d4d2d1a. A passagem com eventos é fixture; a real permanece sem intenção/eventos/spans compatíveis e não coincide com o master editorial. A implementação resolve o contrato antes ausente, não os Done when A/B/C/D. Próxima dependência independente: fonte própria limpa de composição com prova de origem/frames/hash; não reciclar mídia com texto antigo ou tempos do baseline como se fossem editoriais.

Atualização07/09,00:20UTC / D-158: preparação de duas colunas integrada em C v5/schema1.4, preservando12estados/64textos e o hook anterior. Root5testes novos/7regressões e executor13focais PASS; revisão separada encerrada no escopo. Evidência `av-render-recipe-two-column-v5-root-result.json`, SHA37c498355ca6123e3517f41b602e3a0e6aab8b3981f1cdf12dac911b6138fe73. O adapter consome eventos A, verifica intenção literal, prefixo calibrado, continuidade de fonte no HOLD021, escopo integral do span e residência/hash. Não usa tempos históricos nem materializa mídia. A real incompleta mantém12intervalosnull e grafo ausente; o span positivo é apenas fixture de serialização.

Próximo contrato de A deve representar explicitamente fronteira estrutural de unidade PCM, sem alegar timestamp lexical: o suporte atual de `WHOLE_UNIT_PCM_BOUNDS` só existe em captions. Não forjar alinhamentos para suprir essa lacuna. As revelações internas de u011/u012 (`write`) continuam dependentes de anotação/calibração genuína; copiar o relógio do listening baseline é inválido. A imagem-base limpa própria também não está presa: não utilizar vídeo antigo com texto embutido. Essa entrega fecha a integração preparatória, não os Done when A/B/C/D, qualidade ou publicação.

Atualização23:52Z: fragmento audiovisual QA3–8s agora existe, sem reencode visual/ressíntese:150packets preservados e120.000samples PCM exatos, clocks vídeo/áudio verificados, quatro efeitos journaled e replay sem native calls.15testes rootPASS0,920s. Receipt edac0530…/mídia dc22036a… e caminhos completos em STATE. Só fecha a unidade de montagem diagnóstica do hook; não A/B/C/D, calibração, percepção, direitos ou release. Usar o arquivo já concluído para avaliação conjunta, sem remontagem. O contrato de render integral e os estados do corpo continuam dependentes de A elegível.

Atualização23:32Z / D-157: ligação real A→C e preparação allowlisted do take003 implementadas, testadas e preservadas. C v4/schema1.3 reabre argumentos externos, recompõeA e integra adapterv2 de150frames/22dependências/dois textos. Comparação canônica impede troca de tipo numérico. Nove testes integrados anteriores e quatro finais38,968s PASS; relatório av-render-recipe-visual-integration-v4-root-result.json/hash em STATE. A incompleta, mismatch190.800/202.780ms e cobertura parcial continuam blockers; C não possui grafo integral LIVE nem satisfaz seu Done when. Próxima unidade independente deve ligar estados do corpo/two-column a eventos/spansA, preservando copy e recusando tempos históricos incompatíveis. Nenhum efeito de mídia/runtime/publicação foi executado.

Atualização22:55Z: contraprova independente dos níveis/PCM do master encerrada; oito testes de normalização e sete do contratoC passaram. `phase6-av-render-recipe-v1` existe como compilador/verificador puro: namespaceQUEUE_COMMIT_ONLY, quatro estágios, artefatos/legendas/checkpoints pinados, sem escrita, subprocesso ou fila. **Somente FIXTURE compila** e recebe `COMPILED_FIXTURE_NOT_EXECUTABLE`; LIVE opaco permanece bloqueado. Root7/7PASS19,084s, sessão22947/892e11; três arquivos/hashes em STATE. Não é receitaC apta nem satisfaz seu Done when abaixo. A próxima versão precisa recomporA com os inputs de origem e consumir compilador visual allowlisted real antes de remover o blocker de receita/capacidade. O master diagnóstico de202.780ms continua fora da banda e não recebe aprovação perceptual por esta incorporação. B–D não foram executadas/promovidas.

Atualização22:34:47Z: master derivadoPASS em níveis/duração/PCM,−16,37LUFS/−1,49dBTP/LRA3,0,4.866.720samples e zero clipping/remoção, receipt5d7ebccf7bd20015eb721f61756fe7592b58fd73cb1b6b8b4b78f8a4be0d1508. Original3ede841… e derivaçãoFAIL5f922… intactos. Novo helper contínuo fb948117…/oito testes rootPASS0,010s; não é integração no renderer legado. A ainda precisa de banda/grade, acústica, gold temporal e legibilidade/spans. ReceitaC pura em implementação como dependência independente, sem executarC/admitirB ou remover blockers da capacidade. ASR contextual f66e675… já encerrado, não repetir. Cota22%/reserva10 limita escopo ao incremento crítico em curso.

Medição22:23:10Z: WAV editorial−25,71LUFS/−2,01dBTP/LRA5,5/zero samples extremosPCM16. Instrumentos existentes reutilizados; receiptf7dfa55f3758d044b95e41b1bcb566207b65bf435ea87dfe566248985a4ce12a. Entrada intacta, sem masterização. Próxima correção técnica é dinâmica/normalização derivada com medição posterior, não ganho linear de9,71dB. Não altera os locks nem resolve gold, fonética, pausas ou A completo.

Atualização22:18:27Z / D-156: A possui agora candidato de narração contínua real202.780ms, receipt ea7966778748bc81f80813aae1940a44ea2acac35c9f1af76976aea355f30c2d,51PCM e hook0–8s preservados. Sete testes focais PASS/replay sem montagem. A proposta continua abaixo da banda e fora da grade; não é áudio masterizado, temporalizado ou aprovado. Contraprova ASR livre dos cinco desacordos concluída (quatro testes/replay PASS), receipt9ef196b3d53bd5e617c6592b7f108f206caf4281eef9f52075e92020e0a29b25.011 é homofonia CMU write/right;001/007/013/016 continuam ambiguidades acústicas. Nenhum reconhecimento livre substitui anotação temporal, holdout/calibração LIVE ou avaliação perceptual. Não repetir voz/render/ASR encerrados; reutilizar medidores existentes e continuar apenas dependências efetivamente independentes enquanto faltar evidência. A–D não foram promovidos.

Estado: Etapa A implementada em contraprova; B–D pendentes. A Fase 6 continua IN_PROGRESS. Este plano usa os 51 PCM realmente reconciliados; não concede autoridade de mídia, publicação ou extensão da classe visual D-138.

Fechamento21:54:50Z: protótipo editorial e cadeia diagnóstica preservados, verificação independente40679c5a60eef49fcd49557aa69909346c25a48a734b75fe568278fc63695f48 PASS. Root sete testes adicionais PASS5,195s; replay real idêntico sem render/decode. Não repetir. Retornar a A com51PCM existentes; distinguir propostas de pausa202.780ms e194.600ms, ambas sem aprovação auditiva e abaixo da banda. Não regenerar voz, inventar alinhamento ou preencher déficit com silêncio. A–D e gates audiovisuais continuam obrigatórios.

Atualização21:38:30Z / D-155: protótipo editorial real concluído, report7601950874fcbb22fa6efe6fc3a104ea93e15b8232fda3ab1a332870db09fe6c. Nova receita/footer, source em80% sem crop, fala/tempo/identidade intactos e sem voz nova. Render35,328s, sete testes PASS0,252s,150frames e duas regiões150/150 pixel-idênticas à fonte redimensionada. Inspeção de frames confirma legibilidade e separação, não semântica audiovisual completa. Fechamento de três lacunas de rastreabilidade está restrito a verificação dos receipts, sem repetir render/decode. Ainda candidato não aprovado; não resolve A–D, acústica, OCR, publicity ou release. Próximo avanço precisa consumir esta evidência intacta e remover uma dependência real da entrega, não reiniciar pesquisa física de etiquetas.

Atualização 21:08:24Z / D-154: a contraprova fotométrica dos seis pares terminou, com 0/6 aceitos e regressão em três positivos históricos. Report 5087d20f3b670b630d9b8763de207fa14fe3b62ed5d745a636651e1f9395da58. Não integrar nem continuar varrendo sementes dessa hipótese. O wrapper foi corrigido/testado (10/10, 1,920 s) e conserva medição/manifesto/terminal, retomada exclusiva da verificação, capacidade por etapa e 184 wrappers Python pinados. Isso não resolve a qualidade do vídeo. Próximo exame restrito: composição editorial mais simples do take-003, conservando copy, voz, 3–8 s, fonte, Bible e locks. O sidecar físico antigo permanece intacto; uma alternativa precisa de contrato e candidato realmente novos, avaliação integral e compatibilidade, sem chamar a mesma falha de HUD. A–D e os demais blockers não são dispensados.

Atualização20:18Z: helper puro de sementes ae21971e025f00c93aeb6b7d899a93f4eea4b2c7b8049d8a29f5caf7946acbad passou14/14testes em3,409s, incluindo450hulls retidos. Corrige o descarte geométrico pré-scan; não observa borda ou movimento e não foi integrado em V3/V4. Cadeia48/1 gera pontos novos em fragmentos curtos antes ignorados; aceitação fotométrica permanece desconhecida. Evidência/snapshots/limitações em `output/qa/phase6/diagnostics/paper-edge-chain-seeds-v1-root-evidence.md`. Próximo passo é contraprova fonte-only pré-registrada, sem relaxar24px/coverage/condição/resíduos. Não há novo render, voz ou alteração de A–D. Capacidade20:19:40Z preserva caminho crítico/qualidade e evita expansões; não é prova de runtime contínuo.

Atualização19:55:38Z: comparação das três representações concluída, report **c4c4f5e5a89c4938eac8f16f66ecf49f8e6b60befb2a1adc5382ecbe1e897de9**, sessão99916/worker14660 terminal0, 5/5 testes PASS. Mesmo o quad solicitado conserva residual contra os transforms fonte-only; não basta substituir minAreaRect por TLS nem chamar o target de observação. Nenhum instrumento foi promovido ou calibrado LIVE. Leitura de journals separou duas causas: fragmentos LEFT descartados no pré-scan carta1/49 e suporte extremo excluído corretamente pelo holdout24 na carta3/55. Próxima implementação restrita: `paper_edge_chain_seeds_v1.py`, geometria pura por cadeia convexa contígua, com normal/proveniência locais e todos os gates posteriores preservados. Testes não substituem fotometria, independência ou calibração. Fonte/produção/receitas anteriores permanecem intactas; não executar novamente redução numérica íntegra. Hashes e números completos em STATE; não há fechamento de A–D nem autorização derivada de publicação.

Atualização executada 19:34Z: diagnóstico retido de movimento concluído, não validado para produção. Fonte `diagnose_retained_paper_motion_v1.py` SHA5d16a884c50868b9218eab520f9d61b62d2d860a98965c24ffc81bae00d9c526; report5e04882e9b87db64db3ef266e6cec78a01d3259aaccc7afee4303729bb2a9adb; 15/15 testes PASS, supervisão e recomposição concluídas. O histórico é reproduzido com os tipos float32/float64 exatos; recuperação 74/75 é ramo explícito, não origem presumida. Depois da correção de relógio ainda há 103 pares bloqueados e perda de âncora carta 1/frame 11; carta 2 tem cobertura completa mas p95 residual2,363651px. Não é prova independente de defeito físico: primeiro inspecionar bordas fonte-only em carta1/49, carta3/55 e erro na série completa da carta2. A próxima correção precisa de controles e versão próprios. Nenhum novo decode/render/CV/TTS ocorreu. Não repetir a redução íntegra nem dispensar calibração, acústica, OCR, publicity ou B–D.

Movimento, auditoria causal em curso: separar103ausências de transformação do evento de âncora fora do query (carta1/frame11). O fitChebyshev grau4 do produtor é uma hipótese de trajetória sobre hulls, não prova física. Novo diagnóstico numérico `diagnose_retained_paper_motion_v1.py` recompõe o histórico e compara quads clock-corrected com as mesmas observações fonte-only; conserva frames, não deriva gaps nem reinicia âncora. Não executa pixels/CV e não pode calibrar o observador. Rascunho em teste/revisão, ainda sem resultado dessa comparação ou autoridade de render.

Diagnóstico do candidato real concluído18:50Z: `candidate-planned-residual-v1-6dc30ef336ee6ccb/report.json`, SHA2e5954dea225a239af7226ab91f71866b53a618ddf303d6ecbf688b9d525ea2b. 450patches/450áreas externas/447pares, três cartas dentro dos limiares deSSIM/L*/cor/área;13/13testesPASS0,102s. Dois workers limitados reconstituíram resultados byte-idênticos, compreflight/start/terminal próprios, sessão91602exit0. Sem render/decode/voz/API nova. O contrato é QA e não substitui o operacional: integridade não equivale a calibração, nem estabilidade a adesão ao papel. A redução fica encerrada enquanto entradas/prova permanecerem iguais. Próxima unidade: causas de observabilidade etiqueta/papel dos journals retidos; manter acústica/OCR/publicity/receita/admissão/release pendentes e separados. Nenhum estadoA–D foi promovido por inferência.

Instrumento residual sintético executado: sessão56232exit0, relatório1bbb2081e740188e6e7460d38a3d775e681cdddfffa0b58d71dfa3891a7b3a5b,8/8testes rootPASS3,034s. Referência fixa mantém positivo/zeroPASS e detecta X8/Y8/rotação2graus; controles reconstruídos byte-exatos. Próximo passo é aplicar contratoQA separado ao conjunto450patches/447pares do candidato já retido, medindoSSIM/L*/cor/área sem novo decode. Não é calibraçãoLIVE ou aprovação de geometria/papel/OCR/áudio; todas as pendênciasA–D permanecem explícitas.


Contraprova sintética D-153 concluída, sessão20889exit0: relatório fab70bbd56fe73447da46a82d35c7aef87ff8c295d4b9af8976d3f790feecd45,150frames/149pares em dois braços, controles e replayPASS. O caminho de máscara binária/extração/retificação produziuFAIL em conteúdo matematicamente estável enquanto a referência analítica passou. Próximo diagnóstico será o erro residual em coordenadas planejadas com negativos de jitter/desprendimento, sem trocar referência por observação; não implementado/integrado. Isso evita repetir render para satisfazer um medidor não calibrado, mas não aprova mídia nem fecha A. Gates geométricos/papel, calibraçãoLIVE e todas as pendências B–D permanecem.


Atualização17:30Z: observação projectiva externa foi executada/recomposta nas450máscaras do candidato corrigido, mas a similaridade temporal reprovou nas três cartas. Report4bf1732095158478eabd01ee098e86c1a49d22736a42b8d5a3b51b6dcae16d0b; sessão27096 terminalexit0, sem nova mídia. Helper sintético7/7 e wrapper6/6 não são calibraçãoLIVE. Não integrar esse instrumento como solução aprovada nem repetir o render; a próxima contraprova usa os quads/pares já arquivados para discriminar erro real e erro da medição. Permanecem todas as exigênciasA–D e os resultados históricos abaixo.

Checkpoint D-153: QA do hook150frames encerrado/contraprovado, mas FAIL/BLOCKED; causa de etiqueta atrasada por framesync em50frames comprovada. Correção de relógio comum1/30/PTS=N implementada/testada e renderizada em novo diagnóstico5s,19,625s, receipt ef37e1d1f6d3b4872ef3393c0f81d038d1242df4aef961ede0cb1341abada1ca. Contraprova independente74262/16458 terminalexit0:150falhas de pixel→0,450geometrias/pixelsPASS, HUDPASS, flicker3FAIL; report741e5e92e59244d8cdfbc7b0a4bdbb90b5fc132852cefc940c140b9f9c5fe3a5. Não é aprovação conjunta/produtiva. Não alterar histórico ou limiares. Ver STATE para hashes. CapacidadeB permanece projetada enquanto a receita executávelC não estiver vinculada; contexto canônico/publicity por spans estão em hardening e ainda não integram admission/transação. PublicityB atual não pode ser consumido LIVE até fechar parecer independente c4b945db98f6e70dd58cb54d4a71dff9e48d67c4048a57581b198c1575a4ec91. A compilação da receitaC como dependência pode ser implementada antes da admissão, mas sua execução exigeA/B/gates. Isso elimina dependência circular sem antecipar runtime nem inventar LIVE.

## Entradas preservadas

- Reconciliação `narration-pcm-reconciliation-6e8c38d5b22199b1672fa737`, SHA `a1ecadf4aa36c935cf88acf94e792a0c3359bd48f51db443d34d6e2bf7182b50`: 51 unidades, 4.469.928 frames a 24 kHz, 186.247 ms.
- Texto literal, ordem, voz am_onyx, modelo, velocidades e hooks 0–8 s não mudam. A banda do experimento é 207.750–286.250 ms; na grade conjunta de 100 ms, 207.800–286.200 ms.
- Os 90 fragmentos visuais históricos e seus arquivos permanecem como baseline. O predecessor c516 SUCCEEDED não é reaberto ou substituído silenciosamente.
- O lote das 18 falas novas foi concluído antes de erro de cleanup LF/CRLF. Lock terminal arquivado com bytes preservados; zero nova síntese na recuperação. Novos locks deverão usar modo binário e contraprova Windows.

## Gargalos comprovados no código corrente

| Superfície | Lacuna concreta | Integração necessária |
|---|---|---|
| `phase6_media.py`, verificador de voz e renderer | Exige um WAV por take e reinicia o tratamento de áudio nos cortes | Manifesto com unidades de fala independentes; montagem por posição em samples |
| `voice_render_manifest.schema.json` | Contrato 1.2 contém takes e caminhos históricos | Nova versão com units, preservando dispatch histórico estrito |
| `render_creative_v3_phase5.py` e `phase6_quality.py` | Captions seguem cortes e QA exige quantidade igual aos takes | Cues derivados do mapa de fala, cobertura literal e sincronização verificadas |
| `phase6_release.py` | Bundle congelado em diretório fixo | Receipt de geração que resolve o namespace do sucessor sem sobrescrever baseline |
| `production_capacity.py` | Receita de pico de disco/áudio por take | Preflight calculado pela montagem contínua real e seus intermediários |
| `queue_phase6.py`, `phase6_media_authority.py` | Classe pós-efeito visual mantém os mesmos inputs | Classe audiovisual distinta, com novas entradas explicitamente presas ao predecessor |
| `phase6_media.py`, `phase6_quality.py`, `phase6_publication.py` | Consumo de caminhos BASE fixos | Todos resolvem geração pelo tail autoritativo e revalidam sob seus locks |
| `phase6_two_column_recipe.py` | Eventos seguem os cortes antigos | Nova receita derivada do alinhamento observado, sem reutilizar tempos incompatíveis |

## Sequência de implementação

### A. Evidência sonora e plano temporal

Atualização corrente v3/schema1.2: origem de síntese do holdout reconstituída e população limitada às unidades deste release que não pertençam à união inteira de alvos captions/eventos. Root seis focais PASS39,118s. Corpus externo necessita contrato de origem posterior; não está suportado silenciosamente. A camada estrutural está corrigida, mas ausência de referência temporal anotada, calibração independente, pausas/spans e validação perceptual ainda impede A completo. Snapshot v3 íntegra em `source-freeze-av-v3-20260906T1335Z`; fontes exatas v2 não foram arquivadas antes do patch e permanecem não recuperadas, sem apagar seus receipts históricos.

Atualização D-149/D-150: v2/schema1.1 congelados; root26/26PASS216,984s, sessão77882. Calibração passa a exigir policy externa pré-registrada com hash no estimate, ordem UTC e fontes reabertas para holdout/observações/modelos. FIXTURE nunca gera admissão. Isso encerra a correção identificada do verificador, não a ausência de calibraçãoLIVE. Plano textualV2 tem71cues (34inteiras/37internas), após corrigir três segmentações sem mudar copy; timing interno continua pendente. Resultados anteriores ficam como histórico.

Evidência de implementação em 06/09: módulo/schema/testes criados; grupo principal 22/22 PASS em 212,196 s. A implementação separa mapa literal, spans, eventos e cues, conserva 51 PCM/90 fragmentos e bloqueia fonte visual atribuída fora do slot da unidade ou mesmo hash com linhagens diferentes. Precheck textual versionado é distinto de legibilidade renderizada. A revisão de proveniência da calibração permanece aberta; não há declaração de A integralmente concluída.

Montagem QA real `narration-continuous-listening-baseline-v1/ea4a48ffaf796765b0fba422` produziu faixa de 190,8 s. Receipt SHA `b99fcb0d5aa54d8860928a6d91165ec7b3a6ac685251954c967d3bc9fc42667a`; WAV SHA `4ebb7a3f14eb6c81867e29a71d9daa25b8702634397abca0f83ca30cc1df96a4`. Contraprova principal reabriu 51 slices e 50 silêncios declarados, sem nova síntese. A faixa não satisfaz a banda produtiva nem comprova qualidade perceptual. Dezesseis unidades excedem o precheck de cue única e precisam de divisão/alinhamento; manter a voz inteira não implica exibir toda a sentença numa única legenda.

Coleta real concluída em 06/09: receipt ASR `7c06062515285e92e81277a393d410e99d0d9a0abf96d2d167475ecc61b21a2d`, 51 observações, 46 matches e cinco divergências preservadas; replay read-only principal validou todos os bindings sem repetir inferência. A conclusão deste subpasso não promove a Fase 6 nem a voz.

O contrato temporal distingue três superfícies: `narration_fragment_map` conserva os 90 fragmentos literais; `render_spans` define intervalos visuais contíguos, que podem atravessar vários takes; `visual_events` distingue HOLD, corte não semântico e revelação/mudança semântica. Os 39 limites internos de texto não são automaticamente 39 cortes ou alinhamentos obrigatórios. Somente evento semanticamente dependente da fala exige trigger temporal calibrado. Captions continuam independentes de cortes.

ASR independente não recebe texto esperado. Forced alignment pode usar legitimamente a transcrição exata congelada, mas prova somente posicionamento temporal, não identidade lexical ou pronúncia. Precisão depende de receipt de calibração específico do método/modelo/voz/idioma/sample rate, com holdout, erro, cobertura e intervalos explícitos; `800 samples` não é limiar permanente nem comprovado. RMS de 10 ms mede energia, não erro linguístico. Sem calibração aplicável, a revelação crítica permanece BLOCKED; o sistema não inventa timestamps.

Executar ASR local independente, reutilizando resultado anterior somente quando PCM, modelo, parâmetros, licença e hashes coincidirem. Texto esperado só entra na comparação posterior. Timestamps de ASR permanecem estimativas: eventos críticos precisam de contraprova acústica e incerteza explícita.

Criar `hero_engine/phase6_av_timeline.py`, `schemas/phase6_av_timeline.schema.json` e testes. Entradas: reconciliação pinada, script e TakePlan históricos, protocolo/tratamento, alinhamento, fontes e decisões de pausas. Saídas: 51 unidades com posições em samples, mapa dos 90 fragmentos, eventos visuais por frame, captions independentes dos cortes e TakePlan derivado. Pausas devem possuir função editorial e descontar caudas acústicas existentes; o orçamento aritmético não autoriza silêncio de preenchimento.

Auditoria de implementação em 06/09: o protótipo QA `output/qa/phase6/diagnostics/phase6_av_timeline_candidate.py` conserva funções úteis de identidade/copy/PCM, mas sua camada temporal antiga (39 limites obrigatórios, tolerância fixa de 800 samples e rejeição de transcrição no forced alignment) não corresponde ao contrato acima e não será promovida. Implementar o módulo de domínio com recomposição independente. O resultado incompleto mantém blockers, `derived_take_plan=null` e todas as autoridades falsas; resultado temporal completo é `TIMELINE_VALIDATED_NOT_ADMITTED`, ainda dependente da Etapa B.

Cues de unidade/sentença inteira podem referenciar início/fim dos PCM exatos, sujeitos a cobertura e legibilidade, sem representar esses limites como timestamps de palavras. Um recorte interno de texto ou evento cuja compreensão dependa de uma palavra/revelação precisa da evidência temporal correspondente. Não escolher HOLD, texto longo ilegível ou menos variedade apenas para evitar calibração; narrativa, ritmo e legibilidade continuam gates independentes. O inventário histórico 33/18 não será reescrito: a reconciliação posterior é a fonte que reúne os 51 PCM disponíveis.

Done when: preservação literal e de voz; nenhum PCM truncado, acelerado, duplicado ou omitido; hooks intactos; eventos críticos com fonte temporal suficiente; banda e grade válidas; nenhum resultado incompleto se apresenta como executável.

### B. Admissão transacional

Implementar `POST_EFFECT_LOCAL_AV_CONTINUITY_REMEDIATION`, sem alterar o significado de D-138. Receipt prende predecessor/root, inputs antigos e novos, plano AV, 51 PCM, direitos/publicity, fontes concretas, semântica, estilo e capacidade. Reusar PREPARED/COMMITTED e fencing da fila, com verificador real específico.

Done when: successor e intenção são atômicos; COMMITTED exige prova reconstituída; replay não duplica; falha não cria autoridade; predecessor e bytes históricos permanecem intactos.

### C. Render da geração

Resolver namespace pelo job e montar a voz contínua em samples. EQ/compressão não reiniciam por corte. Captions, SFX e eventos consomem o mesmo plano AV. Segmentos, mix e mux mantêm checkpoints próprios e hash de todas as dependências. Capacidade usa essa receita e conserva 5 GiB livres.

Done when: caminho real gera mídia reprodutível no namespace correto; retomada não ressintetiza áudio existente; testes de falha após segmento/mix/mux não perdem efeito nem repetem etapa concluída; contagens de frames/samples conciliadas.

### D. Avaliação e publicação

Versionar dispatch de QA e publicação para o tail da geração; PREPARED, pacote antigo ou divergência bloqueiam antes de qualquer chamada externa. Preservar release, private-first, thumbnail, captions, processamento, promoção pública e verificação final.

Done when: todos os 18 gates críticos e 19 controles de defeito possuem evidência da mídia exata; pacote congelado passa no release; nenhuma fixture ou diagnóstico substitui prova viva; publicação mantém idempotência e receipt completo.

## Lacunas de qualidade que não podem ficar ocultas

Contraprova de aceleração em 06/09: observador de etiquetas ROI v3 preserva máscaras/status nas seis observações reais e reduz essa etapa de 10,8957 s para 0,5818 s. O futuro avaliador integral deverá consumir essa versão e seus pins, sem modificar a evidência v2. Contraprova fonte-only da carta 3 comprovou extrapolação do H KLT: suporte de apenas 0,9947% do papel, erro de borda até 20,8337 px; ECC separado até 0,8558 px. A próxima correção é do instrumento, não do vídeo: suporte espacial e fallback por regra prévia, teste de borda independente, controles negativos e só então medição integral. As amostras não aprovam o candidato.

O QA corrente contém dez medições UNOBSERVABLE: deformação, rostos, mãos, movimentos impossíveis, câmera, física, ghosting, interpolação, compressão e mudança de estilo. Elas não serão promovidas por presença de um render novo. Precisam de observação independente por take/span, método e versão calibrados, positivos/negativos e limites explícitos. Ausência de capacidade continua BLOCKED/NEEDS_REVIEW.

Frames estáticos intencionais de um diagrama não são automaticamente congelamento defeituoso. A avaliação precisa confrontar movimento observado com a intenção narrativa; não adicionar movimento decorativo para enganar freezedetect.

O protótipo de duas colunas não pode ser distribuído em arquivos diferentes para fingir variedade. Os limites de concentração/reutilização devem considerar linhagem real; escolher demonstrações e recortes genuinamente distintos, semanticamente adequados e permitidos. Se não houver combinação elegível, bloquear a seleção.

## Testes obrigatórios do patch

- 50/52 unidades, duplicação, omissão e captura incompleta.
- Hash, copy, voz, velocidade, canal, protocolo ou alinhamento de outra versão.
- Cue antecipado, forecast mostrado como fato e evento sem evidência acústica suficiente.
- Pausa arbitrária, fragmentos perdidos, banda/grade inválida e corte dentro de palavra crítica.
- Alias de fonte para simular diversidade, direito/publicity ausente e namespace sobreposto.
- Lock Windows LF/CRLF, processo vivo/indeterminado, falha depois de captura/segmento/mux e replay.
- Successor sem prova, tail divergente e publicação concorrente durante supersessão.

Custos: processamento local e ferramentas existentes; nenhum serviço pago, download de modelo obrigatório ou gasto autorizado por este documento. A preparação não modifica dados operacionais durante a manutenção integral.

## Dependências temporais verificadas em 06/09

Atualização posterior: o alinhador PocketSphinx5.0.4 foi instalado isoladamente e validado quanto a carregamento, licença, versão, modelo e dicionário; receipt `pocketsphinx-install-c5503388a0c78754d532afac`, SHA `e7fc1cf565ec072dceb65c2933d4d11bf1fcc84373ca20fd7fd39316b82033ad`. Root validou schema/25bindings/hash de modelo e5testes focais. A `.venv` principal não mudou; o fallback ASCII contornou erro comprovado de leitura nativa do modelo em caminho Unicode. `hero_engine/phase6_pocketsphinx_alignment.py` conserva offsets literais e mapeia grade100Hz/16k para samples24k, mas é adaptador de estimativas sem calibração, sem inferência-alvo e ainda sem integração produtiva. Usar os mesmos arquivos pinados, não reinstalar.

Revisão adicional da EtapaA: a referência do limite precisa também comprovar a população de voz; o rótulo am_onyx sozinho não basta. O hardening v3 em revisão deve reconstituir a origem da síntese e excluir a união inteira dos alvos de captions/eventos do holdout. O mínimo de17PCM-alvo decorre dos37ranges atuais de captions; eventos podem ampliá-lo. O tamanhoN de holdout será o da policy pré-registrada; não há regra inventada de30WAV. Referência humana/dataset anotado real e segundo método independente continuam ausentes. Esses pontos não são supridos pelo smoke de instalação.

O inventário local encontrou somente faster-whisper 1.2.1/ctranslate2 4.8.2, snapshot base.en com licença arquivada, e G2P. Não há alinhador dedicado/modelo CTC ou holdout temporal LIVE compatível no ambiente do projeto. O gold textual anterior não deve ser promovido a gold de timestamps. A próxima seleção precisa incluir licença, versão, SHA, Windows/CPU/Python, consumo de memória/disco, segundo método independente e referência temporal aplicável, antes de instalar ou medir targets. Instalação gratuita continua autorizada pelo envelope permanente; esta ausência não autoriza API paga nem timestamps fabricados.

Consulta primária para evitar integração obsoleta: [TorchAudio](https://docs.pytorch.org/audio/main/tutorials/forced_alignment_tutorial.html) avisa que as APIs desse tutorial foram depreciadas em 2.8 e removidas em 2.9; compatibilidade deve ser conferida na versão escolhida, não presumida. [MFA](https://montreal-forced-aligner.readthedocs.io/en/latest/user_guide/workflows/evaluating_alignments.html) oferece comparação de alinhamentos com referências, mas essa documentação não fornece por si um holdout aplicável à voz do projeto. Nenhum pacote/modelo/dataset foi instalado por esta consulta.
