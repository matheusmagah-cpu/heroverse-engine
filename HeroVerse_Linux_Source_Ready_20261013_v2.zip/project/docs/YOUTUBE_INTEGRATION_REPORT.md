# Integração YouTube — HeroVerse

## Resultado

Integração OAuth concluída e verificada em `2026-09-03` para o canal próprio `HeroVerse`.

- handle esperado e observado: `@heroverse74`;
- channel ID esperado e observado: `UCuMF6pJQkyMzaVoAxFL86yA`;
- identidade: `PASS`;
- status do recibo: `CONNECTED`;
- custo externo observado: `USD 0`.

Recibo sem segredo: `output/integrations/youtube/heroverse/connection-receipt.json`.

## Provas executadas

1. OAuth Installed App Loopback histórico concluído com três escopos. O runtime atual exige um quarto escopo, `youtube.force-ssl`, ainda não concedido; portanto a conexão de leitura continua válida, mas captions e promoção final para público permanecem bloqueadas.
2. O token foi armazenado fora do workspace em diretório local de secrets.
3. O token está válido, não expirado e contém refresh token; nenhum valor secreto foi gravado no recibo ou no repositório.
4. `channels.list(mine=true)` retornou um único canal próprio.
5. A resolução de `@heroverse74` retornou o mesmo channel ID da conta autorizada.
6. O channel ID foi fixado em configuração e pacote de publicação; futuras divergências falham fechadas.
7. A YouTube Analytics API respondeu a um probe proprietário de 28 dias com 26 linhas diárias.
8. O fluxo foi repetido sem `--authorize`, provando reutilização não interativa do token salvo.
9. Recibo e pacote de publicação validaram pelos respectivos JSON Schemas.

## Capacidades reais

| Capacidade | Estado | Evidência/limite |
|---|---|---|
| Leitura do canal | `CONNECTED` | Identidade do canal confirmada pela Data API |
| Analytics próprio | `CONNECTED` | Probe de 28 dias retornou 26 linhas; valores privados não foram persistidos no recibo |
| Upload | `CONFIGURED_BLOCKED` | Escopo concedido e adapter configurado; dry-run e gates impedem chamada |
| Thumbnail customizada | `CONFIGURED_BLOCKED` | Adapter configurado; segue a mesma trava de publicação |
| Caption + promoção pública | `NOT_REQUESTED` no token atual | Requer reautorização com `youtube.force-ssl`; adapter limita o uso a `captions.insert` e `videos.update(status.privacyStatus)` |
| Analytics monetário | `NOT_REQUESTED` | Escopo financeiro adiado até YPP/necessidade explícita |

## Coordenação pelo Gestor Central

A camada de integração da Fase 5 recebe comandos do Gestor Central e devolve receipts, mas a mutação remota continua bloqueada:

- ler identidade e estatísticas do canal;
- consultar Analytics próprio autorizado;
- montar pacote de upload privado e thumbnail sem enviar;
- falhar fechado se handle, channel ID, escopo, token ou gate divergir;
- manter credenciais fora do workspace;
- impedir que conexão OAuth seja confundida com aprovação editorial.

O supervisor limitado ao fechamento da Fase 5 está em execução e registra heartbeat, fingerprint, blockers e retomada do receipt. Scheduler de catálogo, coleta pós-publicação, experimentos, líder/fila/DLQ de escala continuam pertencendo à Fase 6 e não são declarados implementados.

## Trava de publicação preservada

Conectar o canal não libera o vídeo rejeitado. O pacote permanece:

- `status=BLOCKED_PENDING_HUMAN_REVIEW`;
- `upload_permitted=false`;
- `publish_mode=dry-run`;
- `human_review=PENDING`;
- FormatPack `PROTOTYPED`.

Portanto, a integração de sessão está conectada; publicação e operação autônoma contínua ainda dependem dos gates e da fase correspondente.

## Correção de durabilidade

A conexão não pode ser chamada de 100% durável enquanto o projeto OAuth estiver em `Testing`. O estado observado do Google Auth Platform bloqueia `Publish app` porque faltam homepage, política de privacidade e termos públicos. Para um app externo em teste com escopos além dos básicos, a documentação do Google informa validade de sete dias para refresh tokens.

Estado de máquina: `output/integrations/youtube/heroverse/operational-readiness.json`:

- `connection_status=CONNECTED`;
- `token_valid_now=true`;
- `continuous_operation_ready=false`;
- `durability_status=TIME_LIMITED_TESTING`.

Done when: publicar páginas legais verdadeiras em domínio controlado, completar branding, mover o app para produção, cumprir eventual verificação, reautorizar uma vez e comprovar refresh não interativo. Nenhum desses requisitos permite publicar um vídeo reprovado.

## Pacote público preparado

Foi materializado em `deployment/oauth-compliance/` um pacote estático com homepage, política de privacidade, termos e CSS. O conteúdo descreve os três escopos concedidos, finalidade, controles de publicação, retenção/revogação e ausência de garantia de monetização. O audit `oauth-public-site-readiness.json` passa seis verificações automáticas de conteúdo e permanece `BLOCKED`.

O bloqueio restante é externo e não pode ser inventado pelo projeto: nome exato do app no consent screen, nome legal público do operador, email público de suporte, data efetiva, domínio próprio do operador verificado pelo owner/editor do projeto Google Cloud e URLs HTTPS publicadas. O Google exige homepage pública sem login, vínculo para a mesma privacy policy do consent screen e domínio verificável pelo operador.

## Inspeção autenticada do Google Auth Platform

Em leitura autenticada, sem editar ou salvar campos, o projeto foi identificado como `graphic-tide-490010-u9`. O app chama-se `Robo youtube`, usa `willmarquesfotografia@gmail.com` como suporte e contato de desenvolvedor, está `External/Testing`, possui um usuário de teste e mantém `Publish app` desabilitado por configuração incompleta.

Branding não possui homepage, privacy, terms ou domínio autorizado. A página `Data Access` mostra zero escopos não confidenciais, confidenciais e restritos, enquanto o runtime agora requer `youtube.readonly`, `yt-analytics.readonly`, `youtube.upload` e `youtube.force-ssl`. O quarto escopo é exigido por `captions.insert` e `videos.update`; como é amplo, o adapter local limita seu uso à caption congelada e à mudança final de `status.privacyStatus` de privado para público, sem delete, rating, comment, caption update ou alteração alheia. Essa divergência é bloqueio crítico: antes da produção, o consent screen precisa declarar exatamente os quatro escopos e satisfazer a verificação resultante. Um único cliente desktop `Youtube bot`, criado em `2026-03-12`, aparece com aviso de não utilizado.

Evidência: `output/integrations/youtube/heroverse/google-auth-platform-observation.json`. Nenhuma permissão, escopo, domínio, cliente ou status foi alterado durante a inspeção.
