# PhaseTask — fontes específicas das perguntas de TEST

## Integração real A11 encerrada; instalação aguardando evidência

A11real06198f55…/SHA10f31b09… e receiptac5f859a… terminaram63ef21exit0,
total61,266s. Wrapper68ad0ebc… passou12/12fixtures e integração4544c860…
9/9focais. Done when de vínculo contraA10 atendido:29usos/71pendentes,
históricosV2/V3/11provasestáticas/relógio/pausas/narração/união26 e bloqueios
conservados, caseV5 separado. Não reabrir geração/OCR/registroV3/A11.
Falta somente a instalação/regressãoD116 deste lote para fechar esta
PhaseTask restrita; não encerra Fase6, GC01, áudio, calibragem ou Vídeo2.

## Subetapa4 — registro e V3 reais concluídos; A11 em teste

Direitos ab6bdbb3… materializaram4estados/8documentos próprios. ReaderV5
2da7b523… e schema2fc8f9ae… passaram8focais; V3/joiner passaram9+8 e revisão
independente read-only sem defeito identificado. Em03:15:17–03:15:48UTC,
V3materializer3e49ddac… (13fixturesPASS) gravou namespace exclusivo completo:
receipt984b972d…/input3e74c984…/inspection139a68f7…/claim30da0cda…,
terminal4a1a09exit0,total38,156s. Este Done when de vínculos está atendido:
29usos,27ativos,26conteúdos,3linhagens,71pendentes, nenhum tempo criado.

Ainda não atendido: A11 operacional e manutenção/D116 do lote. O wrapper
novo foi revisto antes de executar: serão fechadas comparação independente
do hash das rows, integridade/população dos pins do materializador e vínculo
do claim, mais rechecagem entre claim e argumentos. As versões anteriores
estão preservadas. O FAIL focal decompat23aaec(76executados/2erros) permanece;
correções específicas de fixture/schema aninhado não aprovam mídia.

## Subetapa4 — staging e leitores reais, vínculo operacional pendente

Staging real b22323exit0: receipt3e22ff39…, emenda b07bca4c…, V5 7fd136fe…;
copy3strings/2estados e98preservados, sem qualquer efeito emA10. Purov2
9/9PASS0,793s; stagerv2 10/10PASS3,611s. Sourceinspector novo3ed0553a… passou
10/10PASS10,641s, com quatro fontes reais por replay e contêinerCRC semnova
decode; fake/APNG/tRNS/trailing bytes/drift/inventário foram rejeitados.
Direitos15eb742a…/schema78668a61… passaram17fixtures explícitas; registroLIVE
ainda em execução. Replaydo lote25uses68221c67… passou7/7PASS58,478s sem mídia.
Done when do staging atendido, não o do consumidor/timeline. Próximo contrato
V5 preservaV2/V3 e acrescenta case2/98; usosv3 acrescentará4ao cache25 sem rerender.
Alvo29usos/27ativos/26PNG/3linhagens/71semvínculo só após evidência do novo lote.

## Checkpoint vigente — contraprova aprovada somente no escopo estático

Subetapa3 atendida: reconciliação0ac7a3fb… PASS_STATIC_SCOPE_ONLY em
08/09/2026 02:07:44.742237UTC,0,453s,terminal3e3e55exit0. Sete contornos de
tinta em quatroPNG; quatro classificaçõesOCR recompostas dos scans históricos.
Nenhum OCR/render novo ou repetição dos vetores9pixels/4revelação. AABB do
detector contém toda tinta e centro pertence ao campo original. Copy, pontuação,
confiança≥0,70, safearea e budget8palavras não mudaram. FAIL eac99752… intacto.
Report em reconciliation-f3904b4f063f15c87e2bfd9b/report.json; verifier
bdefea7f1f4e68e5758bcedb6b7b3f91d35d8589a8d37aa0c5f3201d34db7c47 e tests
dadac459b8279f831f0b9c143ef9b32120ca39353bc6595bef0756c762d35d09,
10/10focaisPASS1,600s(a5f389), anteriores à medição real.

Subetapa4 em execução: contratos case-only/staging v2 novos e explícitos,
depois fonte/direitos/usos e consumidor versionado. V1 e fontes intactos.
Nove focais56c8d8 também fecharam correções de model21MB/claim do stager v1,
sem torná-lo consumidor dessa reconciliação. Cobertura25/100,75pendentes.

## Checkpoint posterior — FAIL OCR regional preservado

QA real5d2bd5exit0: quatroinferências22,797s em01:48:12UTC, report
eac99752d4706dba7e59470093d57e6ce4f5715f7e6a72d6a65df5700a28d257,
FAIL_STATIC_SCOPE. Copyexata4/4 e mínima confiança0,99873; pixelvetor9/9 em
cadaPNG e4/4revelaçãoPASS. EnvelopeOCR incluiu margens fora do campo de tinta;
isso exigecontraprova, não aprovação pelo score. Receita/QA/4scansintactos.
Done when adicional: prova versionada que separa detecção de contorno real,
caixa associada à linha correta e contendo toda a tinta, limites de pixels
originais preservados, negativos de deslocamento/corte/copy/confiança; reuso
dos4scanssemOCRnovo. Nenhuma projeção/case amendment foi gravada. Buildpuro6/6
e wrapper7/7PASS emescoposcontract/fixture, não mídia. Histórico completo em
test-questions-v1/focal-staging-and-qa-v1.json. Direitos específicos revisados
na notaD171_TEST_QUESTIONS_EDITORIAL_RIGHTS_REVIEW.md; registro ainda pendente.

## Checkpoint vigente

ManutençãoA10 encerrada50b68c85/D1162b2aa4c7…, PASS, antes da geração.
Geração única real em08/09/2026 01:28:50.475006UTC,1,375s, terminal2fce2dexit0:
quatroPNG/SVG e layouts em static-a4630336964863b442fdc027. Receipt SHA
f63ac629a6e9c76ba3485e5dd182123034d108fce515985fce632a71d716c622.
Root inspecionou todas as quatro PNG; copy integral legível, sem indicadores,
sem elementos na reserva inferior, primeiro campo visualmente preservado.
Subetapa2 atendida como amostra e inspeção estática, não QA automática, direito
ou admissão. Subetapa3 em execução; sem rerender. Textos case-only continuam
proposta explícita, cobertura operacional25/100 permanece inalterada.

Status: IN_PROGRESS. Fase6, autorização contínua D047. Custo adicional R$0.
Esta tarefa pode preparar código diagnóstico durante a regressão A10, mas
não altera engine/schemas/tests/scripts/inputs congelados nem roda geração
concorrente à manutenção. Não conclui qualquer fase ou autoriza publicação.

## Objetivo e entradas

Criar quatro estados legíveis para takes024–027, sem reutilizar os indicadores
0/4 e2/4 de u034. A10f4be1a12… mantém75estados sem vínculo; este lote pode
resolver quatro fontes depois de testes, direitos e integração, nunca por mera
existência de arquivo. União26 e os tempos atuais não serão alterados.

Fontes: projeção literal d629bce9…, suplemento3c2485ef…, TakePlan54721357…,
Biblec53ba3aa…, recipe four-criteria-layout-v1/ea2000c5… e compacta51a6c8d4….
Reutilizar somente primitivas gráficas/renderer próprios, não o conteúdo ou
ordinais anteriores. FonteArialBold ePillow locais já identificados por hash.

## Decisão visual explícita, não substituição silenciosa

| Estado/take | Copy atual | Copy candidata | Entrada preservada |
|---|---|---|---|
| u019-s00 /024 | TEST; LOUD IS NOT TRUE | Test; Loud is not true | UNIT_ENTRY |
| u020-s00 /025 | Fully true? | Fully true? | UNIT_ENTRY |
| u020-s01 /026 | Fully true?; Or only possible? | igual | LEXICAL_START[18,35) |
| u021-s00 /027 | CHARACTER; Is this how I should act? | Character; Is this how I should act? | UNIT_ENTRY |

São duas mudanças de estado exclusivamente de capitalização (três strings),
para cumprir sentence case da Bible. Não alterar fatos, sentido, fala, entradas
ou os96demais estados. Antes de consumo por A, exigir emenda externa versionada
e recomposição dessa diferença; não afirmar que os bytes atuais já coincidem.
Nenhum timestamp nasce de UNIT_ENTRY. A revelação u020-s01 mantém o primeiro
campo visível e acrescenta o segundo somente mediante referência calibrada.

Painel-base1920×1080, frame(192,196,1536,588), paleta bloqueada; sem marcadores,
checkmarks, contador, rating de pessoas ou heading adicional. ArialBold54/92,
no máximo duas linhas e8palavras gráficas; contagens previstas5/2/5/7.
Reserva de captions y864–993, margens8%. Texto grande será medido antes de gerar;
se não couber, corrigir composição antes de rasterizar, sem reduzir abaixo54.
Uma linhagem visual herdada owned-four-criteria-panel-v1, não quatro fontes
independentes de variedade. A linhagem não é autorização de direitos herdada.

## Saídas e execução

Pasta output/qa/phase6/diagnostics/test-questions-v1/: receita específica,
testes focais, design/layout, quatroSVG e quatroPNG com pins e receipt.
Raiz operacional, PCM, imagens anteriores, A10, fila e publicação permanecem
intactos. Sem download, instalação, TTS, ASR, alinhamento ou API.
Persistência: diretório exclusivo por versão, preflight completo, hashes
externos, rechecagem antes/depois, colisão falha sem sobrescrever. Replay exige
receipt externo, inventário e bytes exatos e não chama renderer. Saída parcial
é BLOCKED explícito até recuperação própria validada; não sucesso de fallback.

## Done when por subetapa

1. Receita/testes: exatamente4estados/3unidades/4takes; copy total; duas mudanças
   case-only explícitas;96preservados; entrada lexical literal; sem tempos ou
   autoridade; retângulos/textos/paleta/duaslinhas/margens conferidos; negativos
   rejeitam classe errada, revelação prematura, contador ou heading extra.
2. Amostras: uma geração local após manutenção, quatroSVG/PNG/medidas/receipt
   imutáveis; root inspeciona as quatro imagens. Layout não é prova de pixels
   nem legibilidade final; discrepância impede avançar.
3. QA estática independente: OCR por estado e região; ausência do segundo
   campo antes da revelação; pixels do primeiro campo preservados entre estados;
   indicador ausente; fonte/resolução/contagem/cores/captionreserve medidas.
   Reusar resultados íntegros, não rodar novamente para obter aprovação equivalente.
4. Integração: revisão/direitos próprios, emenda case-only, vínculo de fonte/uso
   versionados e teste contraA10. Os75 só podem diminuir depois dessa prova.
   Scheduling, B/C/D, áudio e QA do vídeo composto permanecem gates separados.

## Limites

Não aprova timing, narração, movimento, personagem, publicity, direitos do
vídeo completo, retenção, variedade global ou monetização. Não usar o ensaio
como substituto geral de recortes, nem estender esta receita a todos os estilos.
Não repetir a regressão A10 por uma preparação diagnóstica isolada; futura
mudança do motor exige novo lote agrupado e recuperação aplicável.

## Checkpoint de contrato e preflight

Receitaea876e4f…/testese2c6c315…:12/12focaisPASS1,805s, terminal493c22,
zeroFAIL/error/skip. Transações usam bytes sintéticos, nãoPNG; somente fontes,
copy e textbbox são leituras/medições reais. A revisão independente confirmou
o escopo e solicitou negativo de arquivo extra, incluído antes da execução.
Preflight real411e04exit0: quatro layouts, contagens5/2/5/7, maior limite direito
1311<1680 e inferior559<864. Zero geração/efeito operacional durante manutenção.
Receipt de teste/preflight em test-questions-v1/focal-preflight-v1.json,
registrado08/09/2026 01:26:59UTC. O destino prospectivo static-a4630336964863b442fdc027
ainda não foi criado por esse preflight. Subetapa1 atendida somente no contrato
e layout; não comprova pixels, OCR, rights ou integração. Gerar uma vez após o
fechamento da instalaçãoA10; reutilizar amostras e não repetir testes intactos.
