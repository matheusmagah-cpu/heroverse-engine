# 12 — Válvula de aceleração de aquisição e monetização

## 1. Requisito permanente

O sistema deve possuir uma válvula opcional para acelerar a aquisição de audiência sem confundir alcance pago com progresso qualificado do YouTube Partner Program (YPP). A válvula é subordinada ao Gestor Central, ao envelope operacional, ao gate de orçamento e às fases existentes. Ela não autoriza gasto, publicação, mudança de nicho ou relaxamento de direitos.

Objetivos, em ordem:

1. maximizar a probabilidade calibrada de atingir o YPP dentro do horizonte definido;
2. maximizar progresso **orgânico e qualificado**, não números comprados;
3. após monetização e amostra suficiente, maximizar contribuição líquida ajustada a risco e RPM real;
4. preservar audiência coerente com o nicho, qualidade do canal e elegibilidade de monetização.

Não existe garantia de monetização, alcance ou RPM. Toda previsão deve trazer data, horizonte, premissas, intervalo, cenário e estado de calibração.

## 2. Fatos oficiais que determinam o desenho

Snapshot de política verificado em `2026-09-02`:

- horas e inscritos obtidos por campanhas publicitárias não contam para os thresholds do YPP;
- views de Shorts geradas por campanhas também não contam;
- Promote é uma camada simplificada de compra de anúncios, alimentada por Google Ads;
- promoções não alteram o desempenho orgânico nem fazem o algoritmo recomendar organicamente o vídeo;
- campanhas criadas no Promote são administradas no YouTube, não no Google Ads;
- na regra vigente nesta data, receita de anúncios exige 1.000 inscritos e 4.000 horas públicas qualificadas em 12 meses, ou 10 milhões de views públicas qualificadas de Shorts em 90 dias;
- o YouTube anunciou mudança, a partir de `2027-02-01`, para 8.000 horas ou 20 milhões de views de Shorts, mantendo 1.000 inscritos; o sistema deve consultar a política novamente antes de cada previsão/experimento;
- atingir thresholds não garante entrada: o canal passa por revisão de políticas;
- conteúdo reutilizado precisa mostrar diferença significativa, comentário original ou modificação substantiva; conteúdo repetitivo/massificado pode ser inelegível.

Fontes oficiais:

- https://support.google.com/youtube/answer/12199105
- https://support.google.com/youtube/answer/72851
- https://support.google.com/youtube/answer/12843009
- https://support.google.com/youtube/answer/1311392
- https://support.google.com/google-ads/answer/16041562
- https://support.google.com/google-ads/answer/12301500
- https://support.google.com/google-ads/answer/10436762

## 3. Decisão: Promote não é o acelerador principal

Promote pode comprar exposição legítima, mas não compra progresso qualificado do YPP e não impulsiona recomendações orgânicas. Portanto:

- `YOUTUBE_PROMOTE`: permitido apenas como smoke test simples de criativo/audiência, com orçamento pequeno, aprovação expressa e sucesso medido por efeito posterior orgânico; nunca por views/inscritos pagos;
- `GOOGLE_ADS_VIDEO` ou `GOOGLE_ADS_DEMAND_GEN`: opção preferencial quando a fase e o orçamento forem autorizados, porque permitem objetivos de engajamento, `follow-on views`, inscrições do canal, segmentação, conversões e experimentos mais controlados;
- nenhum deles é tratado como atalho direto para os thresholds;
- paid views, paid watch hours, paid subscribers, alcance e impressões ficam explicitamente excluídos da métrica primária.

`Follow-on views` são views de vídeos orgânicos do canal realizadas depois de uma exposição a anúncio. O Google Ads oferece janela de 30 dias para conversão pós-clique e 3 dias para conversão pós-engaged-view. Esse sinal mede relacionamento posterior, mas o sistema só contabiliza progresso de YPP a partir do painel `Earn`/dados qualificados; não presume que toda conversão atribuída seja elegível.

## 4. Arquitetura da válvula

```text
conteúdo aprovado
      │
      ▼
baseline orgânico ──► previsão pré-registrada ──► gate de orçamento
      │                                               │
      └────────────────── controle/holdout ◄──────────┤
                                                      ▼
                                          tratamento pago limitado
                                                      │
                                                      ▼
                                     follow-on orgânico + YPP Earn
                                                      │
                                                      ▼
                               incrementalidade + custo + stop/scale
```

Componentes futuros:

- `PolicySnapshot`: thresholds e exclusões oficiais vigentes;
- `AcquisitionExperiment`: contrato em `schemas/acquisition_experiment.schema.json`;
- `OrganicBaseline`: velocidade diária de inscritos e horas/views qualificadas, por formato;
- `ForecastRecord`: previsão imutável antes do gasto;
- `Treatment/Control`: braços comparáveis; uma variável principal por teste;
- `AttributionBridge`: Google Ads `follow-on views`/subscriptions e YouTube Analytics/Earn;
- `BudgetGuard`: teto total, diário, stop-loss, cooldown e proibição de autoaumento;
- `IncrementalityScorecard`: delta tratamento-controle, incerteza e custo por incremento;
- `RPMValueModel`: somente após dados monetários próprios suficientes.

## 5. Métrica de sucesso antes do YPP

A métrica primária é:

```text
incremental_qualified_organic_progress_per_currency =
  (delta_horas_qualificadas / horas_restantes_no_baseline
   + delta_inscritos_organicos / inscritos_restantes_no_baseline)
  / gasto
```

Regras:

- deltas devem ser comparados a controle/holdout ou baseline pré-registrado;
- o numerador usa progresso qualificado observado, nunca métricas pagas brutas;
- quando não houver separação confiável entre orgânico e pago, o resultado é `INCONCLUSIVE`;
- se uma das metas já foi atingida, seu termo sai da fórmula;
- denominadores zero são bloqueados, não imputados;
- a fórmula operacional final deve ser versionada antes do primeiro experimento.

Secundárias:

- `follow_on_views`;
- custo por follow-on view incremental;
- novos espectadores orgânicos e espectadores recorrentes;
- horas públicas qualificadas e inscritos qualificados no painel Earn;
- retenção orgânica por audiência/tipo de tráfego quando disponível;
- velocidade diária pós-tratamento contra baseline;
- risco de audiência desalinhada e de revisão do YPP.

## 6. RPM: otimizar valor real, não folclore

RPM é receita total do criador por 1.000 views e inclui fontes como anúncios, YouTube Premium e fan funding. CPM não é RPM. RPM real só existe depois de monetização e acesso autenticado a dados monetários.

Antes do YPP:

- `actual_rpm = UNAVAILABLE`;
- rankings públicos de “nichos que pagam mais” são apenas proxies e não podem ser gravados como fato;
- o nicho atual não será trocado silenciosamente por um nicho teórico de CPM maior;
- geografia, duração, intenção, ad suitability, formato e mix de receita entram como hipóteses, nunca garantias.

Depois do YPP e com amostra suficiente:

```text
RPM_video_pais = 1000 × estimatedRevenue / views
expected_net_contribution =
  incremental_organic_monetized_views × posterior_RPM / 1000
  - spend
  - variable_cost
```

O modelo usa dados próprios por vídeo, país e janela, com shrinkage para a mediana do canal quando a amostra for pequena. Deve registrar views, monetized playbacks, estimated revenue, Premium revenue, país, formato, intervalo e ajustes de fim de mês. Uma célula de RPM alta com poucas views não vence automaticamente.

Fontes oficiais de definição e API:

- https://support.google.com/youtube/answer/9314357
- https://developers.google.com/youtube/analytics/metrics
- https://developers.google.com/youtube/analytics/sample-requests

## 7. Previsão e meta temporal

Para um horizonte `D`, o Gestor calcula cenários separados:

- `organic_only`;
- `organic_plus_accelerator`;
- `downside`, `base` e `upside`;
- probabilidade de atingir simultaneamente inscritos e horas/views qualificadas;
- data mediana e intervalo de chegada;
- custo total, custo incremental e risco de não conversão.

Com poucos dados, o status obrigatório é `PRIOR_ONLY` ou `INSUFFICIENT_DATA`; mostrar um número pontual como promessa é proibido. Após observações diárias suficientes, usar bootstrap/Monte Carlo ou modelo hierárquico, comparar com baseline simples e medir Brier/log loss, MAE da data prevista e cobertura do intervalo.

## 8. Experimento mínimo profissional

Só pode ser criado na Fase 6 ou posterior, depois de conteúdo publicado e métricas próprias:

1. capturar política oficial e estado do painel Earn;
2. congelar baseline orgânico por formato e vídeo;
3. escolher apenas um vídeo que já passou qualidade, direitos e sinais orgânicos mínimos;
4. pré-registrar hipótese, uma variável, controle, tratamento, janela, orçamento e stop rules;
5. preferir Google Ads com canal vinculado e `follow-on views` como conversão; subscription pode ser secundária;
6. manter controle/holdout comparável; não alterar criativo, targeting e orçamento simultaneamente;
7. medir custo e progresso qualificado separadamente;
8. classificar `SCALE`, `ITERATE`, `STOP` ou `INCONCLUSIVE`;
9. nunca aumentar orçamento sem novo comando protegido aprovado.

Video Experiments podem testar criativos com controle/tratamento, mas resultados conclusivos podem exigir semanas e volume. A meta de 30 dias não justifica encerrar cedo nem declarar vencedor em resultado direcional.

## 9. Gates e stop-loss

O experimento não inicia se faltar qualquer item:

- aprovação do proprietário para valor total e diário;
- conteúdo e canal aptos a políticas/reused content;
- direitos e proveniência aprovados;
- baseline orgânico e painel Earn capturados;
- fonte de atribuição configurada;
- hipótese falsificável e previsão pré-registrada;
- controle/holdout ou justificativa documentada;
- regra de parada, rollback e responsável;
- credenciais somente em variáveis/secret store.

Paradas obrigatórias:

- teto total ou diário atingido;
- gasto sem evidência suficiente dentro da janela pré-registrada;
- limite inferior do efeito incremental não positivo quando houver poder amostral;
- custo incremental acima do teto aprovado;
- queda material de qualidade orgânica ou audiência desalinhada;
- alerta de política, copyright, reused content, segurança ou faturamento;
- dados de atribuição inconsistentes;
- drift da política do YPP.

## 10. Incorporação nas fases

| Fase | Incorporação permitida |
|---:|---|
| 2 | nenhum Ads; somente contrato e separação de métricas |
| 3 | coletar baseline público/privado disponível, fontes de tráfego e coortes; sem gasto |
| 4 | modelar formatos e hipóteses de valor; RPM pré-YPP continua indisponível |
| 5 | produzir criativos/landing videos aptos; direitos e qualidade obrigatórios |
| 6 | implementar e, com aprovação de gasto, executar piloto controlado da válvula |
| 7 | medir efeito posterior, calibrar previsão, transferir ou rejeitar regras |
| 8 | produto multiusuário, permissões, billing, limites e observabilidade |

## 11. Critério de sucesso

A válvula só é considerada validada quando existe evidência de incremento orgânico qualificado contra controle, custo dentro do envelope, ausência de regressão/política, previsão avaliada posteriormente e repetição em nova aplicação. Alcance pago isolado nunca satisfaz o gate.
