# Impacto da incorporação — Inteligência Contínua Viva

Data: `2026-09-02`  
Requisito integral: `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md`  
SHA-256: `44FC5992089CF9265ECF5EC5A9EE11F81BBCBB039070C596B29A1B2AB0D92EE6`  
Estado: `AWAITING_REVIEW — nenhum componente implementado`

> Correção complementar: `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md` especializa esta camada como Gestor Central Autônomo de 100% da operação. Este relatório continua válido como baseline de impacto, mas deve ser lido junto de `docs/GESTOR_CENTRAL_IMPACT.md`; em caso de diferença de papel, vale a correção mais específica sem remover gates anteriores.

## 1. Resultado da incorporação

O requisito complementar foi incorporado integralmente, com conteúdo e hash idênticos ao arquivo fornecido. Ele passa a complementar o contrato existente sem substituir ou enfraquecer:

- `AGENTS.md`;
- `PLANS.md`;
- as Fases 0–8 e seus gates;
- os schemas atuais;
- as decisões D-001 a D-012;
- os gates de direitos, custos, aprovação e publicação;
- o código, banco e artefatos legados.

Não foi encontrado conflito material insolúvel. A conciliação necessária é de **sequenciamento**: a arquitetura de inteligência contínua atravessa várias fases, mas nenhuma parte pode ser antecipada somente porque o requisito foi incorporado.

## 2. Impacto imediato na fase atual

A Fase 1 continua sendo o padrão-ouro manual. Ela não se transforma em fase de construção de Event Ledger, memória, agentes ou scheduler.

Quando a Fase 1 for retomada após esta revisão, o plano passará a exigir, além dos artefatos já previstos, um manifesto lateral de proveniência por execução. A proposta contém:

- identificador idempotente da execução;
- canal, nicho, vídeo e escopo;
- hashes dos arquivos de entrada e evidência;
- timestamps de captura e processamento;
- versão do schema, ferramentas e pipeline;
- classes `OBSERVED`, `CALCULATED`, `INFERRED`, `PRIVATE` e `UNKNOWN`;
- parâmetros do processamento;
- limitações, falhas e revisão humana;
- referências para reconstrução futura do evento.

Esse manifesto é apenas uma adaptação planejada. Ele não foi criado e o schema estável `video_mining.schema.json` não foi alterado.

## 3. Auditoria do que já existe

### Banco e persistência

**Observado:** SQLite contém tabelas de canais, vídeos, auditorias de licença, transcripts, candidatos de clips, hooks, modelos, aberturas, produções, snapshots e forecasts. Há persistência entre execuções.

**Reaproveitável:** `hero_engine/db.py`, conexão SQLite, IDs naturais de algumas entidades e catálogo atual.

**Lacunas:** não existem migrações versionadas, Event Ledger append-only, chave idempotente universal, escopos de memória, versões de regra, experimentos, incidentes, checkpoints, replay ou rollback. Algumas rotinas atualizam ou apagam materializações, o que não preserva um histórico completo.

### Analytics

**Observado:** `performance_snapshots` possui campos privados relevantes e `decision.py` avalia métricas configuráveis. A tabela contém zero registros reais.

**Reaproveitável:** ingestão manual, separação por formato, decisões `SCALE/ITERATE/STOP/INSUFFICIENT_DATA` e retenção de probabilidade no estado `prior_only`.

**Lacunas:** Own-Channel Observer autenticado, baselines versionados, janelas/coortes explícitas, vínculo com versões de embalagem e pipeline, experimentos e Learning Evaluator.

### Fila e estado operacional

**Observado:** existe uma fila de upload em JSON, estado de produção no SQLite e dupla trava de publicação. Há um payload na fila, ainda sujeito a aprovação.

**Reaproveitável:** `productions`, `publisher.py`, `approval_required` e `dry-run`.

**Lacunas:** fila transacional de jobs, tentativas, retries limitados, lease, checkpoint, dead-letter queue, incidentes e idempotência operacional.

### Agendamento e orquestração

**Observado:** `scripts/daily.ps1` executa testes, rotina e workbook quando chamado. Não existe scheduler pertencente ao domínio do projeto.

**Reaproveitável:** CLI e rotina diária como pontos de entrada.

**Lacunas:** agenda configurável, execução idempotente, locks, retries, checkpoints, monitoramento de atraso e observabilidade.

### Memória

**Observado:** o projeto guarda fatos em SQLite, modelos em JSON, relatórios em Markdown e artefatos em disco.

**Reaproveitável:** persistência local e separação parcial entre catálogo, modelo, produção e métricas.

**Lacunas:** memória factual append-only, episódica, semântica, decisória, operacional, por canal e global; promoção controlada; expiração; rollback e transferência entre contextos.

### IA e providers

**Observado:** faster-whisper é usado para transcrição; modelagem, forecast e decisão atuais são predominantemente determinísticos. Não existe agente persistente, embedding store ou provider genérico de raciocínio.

**Reaproveitável:** processamento local, CLI e funções testáveis.

**Lacunas:** interfaces de providers, contratos de hipótese, explicabilidade, avaliação e proteção contra promoção de opinião de IA a conhecimento.

## 4. Mapa de reaproveitamento por componente obrigatório

| Componente futuro | Base reaproveitável | Lacuna principal | Fase de encaixe proposta |
|---|---|---|---|
| Event Ledger | SQLite e timestamps atuais | append-only, idempotência e migrações | Fase 3 |
| Market Observer | catálogo, `youtube.py`, model videos | snapshots permitidos, termos e scheduler | Fase 3 |
| Own-Channel Observer | `performance_snapshots` | ingestão autenticada e provenance | Fase 6 |
| Normalizer | views/dia e idades atuais | unidades/janelas versionadas | Fase 3 |
| Feature Builder | mineração, hooks, EDL e quality | ligação por versão e evidência | Fase 4 |
| Knowledge Store | SQLite/JSON | tipos de memória e escopos | Fases 3–4 |
| Hypothesis Engine | heurísticas e decisões atuais | falsificação, pró/contra e confiança | Fase 4 |
| Experiment Planner | gates configuráveis | controle, baseline e stop rule | Fase 6 |
| Decision Engine | `decision.py` | versões, baseline e incerteza | Fase 6 |
| Policy Gate | direitos, aprovação e `dry-run` | autoridade por ação e fase | Fase 5 |
| Learning Evaluator | nenhuma implementação completa | antes/depois, interferências e status | Fases 6–7 |
| Rule Registry | modelos JSON | lifecycle e versões de regra | Fase 7 |
| Application Planner | EDL/blueprint legado | mudanças aprovadas por blueprint | Fase 5 e aplicação na 7 |
| Scheduler/Orchestrator | `daily.ps1` | jobs, retries, checkpoint e DLQ | Fase 6 |
| Audit/Explainability | relatórios e evidências | reconstrução ponta a ponta | transversal, consolidado na 7 |
| Monitoring | quality reports | saúde, lag, drift e custo | Fases 6–7 |

## 5. Distribuição sem criar fases paralelas

### Fase 1 — Padrão-ouro

- preservar proveniência suficiente para futura ingestão;
- manter bruto/revisado e hashes;
- registrar versão de ferramentas e parâmetros;
- não criar regra aprendida nem automatizar decisões.

### Fase 2 — Minerador automático

- emitir saídas determinísticas e idempotentes;
- produzir run manifests compatíveis com futura ingestão de eventos;
- incluir versão do pipeline e divergência contra fixtures;
- não construir observatório ou aprendizado contínuo completo.

### Fase 3 — Lote e observatório

- introduzir migrações, Event Ledger, Market Observer, Normalizer e materializações;
- criar schemas iniciais de `Event`, `MarketObservation`, `ChannelMemoryScope`, `PipelineVersion` e `Incident`;
- testar idempotência, persistência e isolamento.

### Fase 4 — Modelador

- introduzir `FeatureSnapshot`, `Baseline`, `Hypothesis` e memória semântica candidata;
- ligar hipótese a evidências favoráveis e contrárias;
- manter toda regra como `CANDIDATE` até teste real.

### Fase 5 — Produtor

- integrar `Policy Gate` e `ApplicationPlan` ao blueprint;
- bloquear aplicação sem direitos, escopo, custo e aprovação;
- nunca permitir que inteligência altere regra protegida.

### Fase 6 — Canal-piloto

- introduzir `OwnVideoObservation`, `Experiment`, `Decision`, scheduler controlado e Learning Evaluator;
- medir baseline, resultado, incerteza, custo e incidentes;
- executar somente experiências e publicações aprovadas.

### Fase 7 — Aprendizado e segundo canal

- introduzir `LearnedRule`, `RuleVersion` e lifecycle completo;
- testar replay, rollback, drift, transferência controlada e isolamento;
- medir se uma aplicação futura repetiu o efeito.

### Fase 8 — Produto

- endurecer segurança, concorrência, permissões, multiusuário e observabilidade;
- avaliar PostgreSQL somente quando houver justificativa operacional;
- empacotar skills, MCPs ou plugins apenas após estabilidade.

## 6. Contratos novos planejados, ainda não criados

O requisito exige futuros schemas para:

`Event`, `MarketObservation`, `OwnVideoObservation`, `FeatureSnapshot`, `Baseline`, `Hypothesis`, `Experiment`, `Decision`, `LearningEvaluation`, `LearnedRule`, `RuleVersion`, `ApplicationPlan`, `Incident`, `ChannelMemoryScope` e `PipelineVersion`.

Criá-los agora anteciparia fases e poderia alterar contratos estáveis sem aprovação. O inventário foi registrado no plano, mas os arquivos não existem ainda.

## 7. Impacto nos testes

Os 16 testes indispensáveis do requisito foram preservados como critérios futuros. Eles entram gradualmente:

- Fase 2: persistência do artefato, idempotência do processamento, dados ausentes e versionamento;
- Fase 3: ledger, reingestão, isolamento e replay inicial;
- Fase 4: contradição, amostra inconclusiva e escopo local;
- Fase 5: gate humano e aplicação protegida;
- Fase 6: ciclo experimental controlado e impacto contra baseline;
- Fase 7: transferência, rollback, drift e ciclo completo.

Nenhum teste será marcado como aprovado antes de existir comportamento executável e evidência.

## 8. Riscos introduzidos

1. ampliar a Fase 1 e impedir a entrega do padrão-ouro;
2. criar uma memória textual que não seja fonte operacional;
3. tratar tabela mutável como Event Ledger;
4. promover correlação a regra causal;
5. misturar dados de mercado, canal próprio e operação;
6. copiar regras entre canais sem teste de transferência;
7. alterar schemas ou gates silenciosamente;
8. adicionar scheduler, n8n, MCP ou plugin antes do domínio;
9. criar custos ou dependência de provider;
10. esconder estado incompleto atrás da expressão “IA viva”.

Todos permanecem mitigados pela execução faseada e pelo gate humano.

## 9. Impacto sobre trabalho anterior

- Nenhum código foi alterado.
- Nenhum schema existente foi alterado.
- Nenhuma decisão anterior foi invalidada.
- A amostra proposta D-012 continua pendente, mas seu processamento foi pausado.
- A Fase 1 não foi concluída; entrou em revisão apenas pela mudança de planejamento.
- A Fase 2 continua `NOT_STARTED`.
- Publicação permanece em `dry-run`.

## 10. Decisão solicitada ao usuário

Revisar e aprovar ou corrigir:

1. o encaixe da Inteligência Contínua nas Fases 1–8;
2. o manifesto lateral de proveniência proposto para a Fase 1;
3. a criação futura dos 15 contratos apenas nas fases correspondentes;
4. a preservação de SQLite no piloto e postergação de PostgreSQL;
5. a retomada da Fase 1 no gate anterior de aprovação da amostra.

Até essa decisão, o projeto permanece em `AWAITING_REVIEW` e nenhuma implementação é permitida.
