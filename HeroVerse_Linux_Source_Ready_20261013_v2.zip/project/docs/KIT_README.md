# Kit Mestre — Modelagem e Produção de Canais Dark com Codex

Este pacote transforma o objetivo do projeto em instruções permanentes e verificáveis para o Codex. Ele foi desenhado para evitar que uma tarefa extensa seja resumida, misturada ou executada apenas parcialmente.

## Objetivo final

Construir, validar e operar um sistema de canais faceless baseado em:

- mineração minuciosa de canais e vídeos validados;
- análise por take e por intervalo de tempo;
- estudo separado do hook dos primeiros três segundos;
- modelagem da narrativa, embalagem, retenção e produção;
- produção de novos vídeos principalmente por recortes e montagem;
- adaptação narrativa real para o nicho de destino;
- ferramentas locais e gratuitas sempre que forem suficientes;
- validação em canais próprios antes de transformar o processo em produto;
- expansão para vários canais somente depois de comprovar o método.

## Como usar

1. Faça uma cópia ou backup do projeto existente.
2. Extraia este pacote na raiz do repositório.
3. Se já existir um `AGENTS.md`, não o apague: peça ao Codex para fundir as regras sem remover instruções existentes.
4. Abra o projeto no Codex a partir da raiz correta.
5. Envie somente o conteúdo de `prompts/00_BOOTSTRAP.md`.
6. Aprove ou corrija a auditoria da Fase 0.
7. Avance utilizando um prompt por fase, sempre na ordem estabelecida em `docs/07_PHASES_AND_GATES.md`.

## Regra principal

Nenhuma fase pode avançar apenas porque o Codex informou que terminou. Ela avança somente quando:

- os artefatos previstos existem;
- os testes foram executados;
- os exemplos de saída foram apresentados;
- os critérios de aceitação foram verificados;
- o usuário aprovou expressamente a fase.

## Estrutura do pacote

- `AGENTS.md`: regras curtas e permanentes carregadas pelo Codex.
- `PLANS.md`: modelo obrigatório para planos de execução.
- `docs/00_MASTER_SPEC.md`: contrato do objetivo final.
- `docs/01_EXECUTION_PROTOCOL.md`: forma obrigatória de trabalhar.
- `docs/02_MINING_SPEC.md`: mineração por frame, hook, take e narrativa.
- `docs/03_MODELING_SPEC.md`: transformação da mineração em modelos executáveis.
- `docs/04_PRODUCTION_SPEC.md`: produção baseada em recortes e nova narrativa.
- `docs/05_ANALYTICS_AND_VALIDATION.md`: validação em canal próprio.
- `docs/06_TOOLING_AND_INTEGRATIONS.md`: ferramentas, plugins, MCPs e adaptadores.
- `docs/07_PHASES_AND_GATES.md`: sequência de fases e travas.
- `docs/08_POLICY_AND_RIGHTS.md`: origem, licenças e riscos.
- `docs/09_JEF_PROGRAMADOR_LEARNINGS.md`: aprendizados aproveitados da referência analisada.
- `docs/STATE.md`: estado atual e autorização de avanço.
- `docs/DECISIONS.md`: decisões permanentes do projeto.
- `schemas/`: contratos de dados verificáveis.
- `templates/`: formulários e configurações.
- `prompts/`: comandos curtos, um por fase.

## Expectativa correta

O pacote permite verificar se o sistema foi implementado conforme o solicitado. Ele não promete antecipadamente monetização ou lucro. A previsibilidade comercial será construída com resultados públicos, experimentos controlados e, principalmente, dados privados dos canais próprios.

