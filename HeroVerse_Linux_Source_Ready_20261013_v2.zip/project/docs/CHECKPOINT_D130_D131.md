# Checkpoint técnico seguro — D-130 e D-131

Este checkpoint preserva correções já iniciadas antes de D-132. Não reiniciou o Gestor, não alterou fila viva, não executou render novo nem aprovou publicação.

## D-130 — Reserva de mídia

`hero_engine/media_lease_heartbeat.py` e integração em `phase6_media.py`: claim usa relógio UTC fresco; thread renova somente job/owner exatos, retém falhas, verifica integridade antes de succeed e encerra em finally. D-129/receita v2 preservados. Executor reportou py_compile PASS e 12/12 testes focais (nove novos em `tests/test_media_lease_heartbeat.py` e três regressões).

Limitação: não cancela FFmpeg bloqueante após perda de ownership; impede commit de sucesso/efeitos posteriores depois do retorno. A instância residente ainda usa código carregado anteriormente. Deployment e prova viva são pendentes.

## D-131 — Texto nos pixels e coerência

Novos `hero_engine/phase6_overlay_ocr.py`, `schemas/phase6_overlay_ocr_audit.schema.json` e `tests/test_phase6_overlay_ocr.py`; integração em `phase6_quality.py` e evolução compatível de `phase6_quality_evaluation.schema.json`.

RapidOCR local com três modelos hash-pinned, uma thread por runtime, sem download/cobrança e piso de RAM de 5%. Amostras nas janelas iniciais e nos takes com overlay; frames/timecodes/hashes, sentinelas isoladas, texto ausente/substituído/ilegível, safe area e conflito com Style Bible ligados aos gates HOOK/SEMANTIC_COHERENCE/LEGIBILITY. Avaliador 1.2.0, evidência v3, histórico preservado.

Executor reportou py_compile PASS, 8/8 OCR e 8/8 quality. OCR real não carregado: 3,779% de RAM livre era inferior ao piso de 5%. Estado de contraprova OCR viva **BLOCKED**, não PASS. Amostragem não equivale a avaliação de todos os frames.

## Retomada obrigatória

Contraprova conjunta do agente principal: `python -m unittest tests.test_codex_usage_governance tests.test_media_lease_heartbeat tests.test_phase6_overlay_ocr tests.test_phase6_quality -q` terminou com 31/31 PASS em 2,624 s. Testes locais/focais, não regressão integral ou OCR vivo. PID 18288 vivo e 80 caches de segmentos concluídos às `2026-09-06T01:56:05.7371517Z`; nenhuma alteração da fila/restart.

Fase 6 IN_PROGRESS. Persistem: conflito take-003 Bible/TakePlan/renderer; remediação versionada pós-efeito para não sobrescrever a geração v1; ativação segura dos patches; OCR vivo sob capacidade suficiente; render consistente; QA independente; regressão integral e prova pós-manutenção. Nunca reabrir SUCCEEDED ou forçar lease do job em curso. A gestão de capacidade D-132 não dispensa nenhuma dessas provas.
