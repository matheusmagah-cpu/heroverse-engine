# Preflight — Fase 2

## Controle

- Fase: `2 — minerador automático`
- Estado: `READY_FOR_IMPLEMENTATION`
- Autorização: usuário, mensagem “continue e faça com perfeição”, em `2026-09-02`
- Raiz confirmada: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`

## Instruções carregadas

- `AGENTS.md`;
- `docs/STATE.md`;
- `docs/00_MASTER_SPEC.md`;
- `docs/01_EXECUTION_PROTOCOL.md`;
- `docs/02_MINING_SPEC.md`;
- `docs/07_PHASES_AND_GATES.md`;
- `docs/08_POLICY_AND_RIGHTS.md`;
- `docs/GESTOR_CENTRAL_IMPLEMENTATION_PLAN.md`;
- `docs/CONTINUOUS_INTELLIGENCE_PLAN.md`;
- `prompts/02_BUILD_MINER.md`;
- `schemas/video_mining.schema.json`;
- `schemas/mining_benchmark.schema.json`.

## Estado inspecionado

- Fase 1: padrão-ouro validado em 4 vídeos, 256 takes e 25 segmentos; gate aprovado pela nova autorização do usuário.
- Fase 2: anteriormente `NOT_STARTED`; passa a ser a única fase autorizada.
- Código legado: CLI e módulos de produção/modelagem serão preservados; não serão tratados como entregas da Fase 2.
- Git: a raiz não possui `.git`; integridade será provada por hashes e manifestos.

## Entradas reais

| Entrada | Estado | Evidência |
|---|---|---|
| Quatro mídias D-012 | disponível | `data/modeling/grace-grit-love/full/*.mp4` |
| Metadados e thumbnails | disponível | `.info.json` e `.jpg` por vídeo |
| Champion humano | disponível e congelado | `data/gold_standard/<video_id>/video_mining.json` |
| Schema de saída | disponível | `schemas/video_mining.schema.json` |
| Contrato de benchmark | disponível como draft da fase | `schemas/mining_benchmark.schema.json` |
| FFmpeg/ffprobe | disponível | `C:\ffmpeg\bin` |
| ASR local | disponível | `faster-whisper 1.2.1` |
| OCR local | Tesseract ausente | RapidOCR local será instalado como adapter substituível |
| Credenciais | não necessárias | execução estritamente local |

## Preservação obrigatória

- O padrão-ouro nunca será usado para preencher a saída challenger; somente para avaliação posterior.
- Anotações, transcrições revisadas e keyframes da Fase 1 não serão alterados.
- Direitos permanecem independentes da qualidade editorial e bloqueados para produção.
- Nenhum módulo de publicação, produção, ChannelDNA, catálogo em lote ou Gestor runtime será acionado.

## Decisão de OCR

- Provider: `rapidocr==3.9.2` com `onnxruntime` CPU já disponível.
- Razão: execução local, sem API/custo, modelos empacotados e licença Apache-2.0; Tesseract não está instalado.
- Risco: dependência maior e OCR imperfeito em texto estilizado.
- Mitigação: interface de adapter, versão no run manifest, confiança preservada e `UNKNOWN`/lista vazia quando não houver leitura suficiente.

## Entradas ausentes e limitações

- Não há modelo semântico local treinado para descrição de cenas. A primeira versão usará somente propriedades visuais mensuráveis, OCR e regras linguísticas determinísticas.
- Não há verdade humana completa de OCR/posição em todos os frames; a métrica OCR terá limitação explícita.
- A saída automática terá `manual_review_status=NOT_REVIEWED`.
- Divergência não será escondida nem corrigida copiando o champion.

## Critérios convertidos em verificações

1. CLI e API Python processam um fixture real.
2. Inspeção, ASR, cenas, três keyframes por take e OCR geram artefatos próprios.
3. Os quatro hooks obrigatórios existem e apontam evidências.
4. Saída valida no Draft 2020-12 e rejeita evidência ausente.
5. Job key inclui hash, versão e parâmetros; segunda execução retorna cache hit sem duplicar.
6. Falha de mídia/provider é explícita e deixa receipt de falha.
7. Champion e challenger são comparados campo a campo pelo schema de benchmark.
8. Tempo, CPU, memória Python, disco e custo externo são medidos.
9. Nenhuma dependência paga é obrigatória.
10. Suíte completa passa e a fase termina em `AWAITING_REVIEW`.

## Fora de escopo

- catálogo completo e Fase 3;
- ChannelDNA/modelagem e Fase 4;
- produção, render, publicação, Ads ou gasto;
- promoção definitiva do challenger sem revisão do proprietário;
- runtime, ledger, fila ou scheduler do Gestor Central.

## Resultado do preflight

`PASS`. Não há conflito material nem entrada bloqueante para iniciar a implementação limitada à Fase 2.
