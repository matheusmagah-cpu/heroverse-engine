# DECISIONS — Registro de decisões

## 13/10/2026 — destino Linux independente do Windows, sem promoção por import/teste

Pedido atual do proprietário exige continuar com Windows desligado e custo adicionalR$0. Reutilizar Gestor/gates; não criar supervisor paralelo. Sessão Linux, GitHub para fontes/testes e executor pesado persistente são capacidades distintas. O GitHub privado padrão2CPU/8GB/14GB não prova ganho de CPU ou espaço para mídia longa. Não enviar projeto privado ao único repo público OAuth disponível. Acesso privado/quota/segredos/armazenamento e lote recuperável sem origem são necessários antes de cutover.

Adotar apenas no shadow a correção eSpeak .so/.so.N+ELF anteriormente medida, com preimagem exclusiva e comparação de hashes.20 testes da cadeia de pesquisa passaram em fixtures; erro do21º por histórico ausente permanece explícito. Binding eSpeak real não é síntese aprovada nem QA artístico. PAUSE, fila, ledger, identidade, publicação e candidata Windows congelada continuam separados desta validação de portabilidade.

## 11/10/2026 — pesquisa atual antes da próxima preparação

Usar o ramo atual de áudio, não o compiler/canário histórico. `phase6_audio_production` integra os componentes existentes; `phase6_production.py` histórico ficou byte-idêntico à preimagem. Uma baseline publicada gera no máximo um job exato; coleta sem resultado conhecido/erro não redispara. Coortes mínimas existentes de quatro por canal/formato/idade, com três referências independentes para triagem, não significância estatística. Títulos públicos fornecem hipótese de assunto, não RPM, qualidade sonora ou audiência privada. Receita editorial v5 explícita, proposta e pesquisa pinadas antes da voz; a composição continua controle, não certificação de autenticidade do catálogo. QA/direitos/render/publicação seguem gates nativos. Sem novo framework, gestor, serviço pago ou downloads de concorrentes.

## Conteúdo autêntico como regra transversal — 07/10/2026UTC

Política oficial1311392 conferida: renomeação15/07/2025 esclarece inelegibilidade
já existente de conteúdo repetitivo/produção em massa. Norma incorporada ao
AGENTS e especificações de mineração/modelagem/produção/controle/ aprendizado,
matriz F0–F8 no documento08. Direitos/codec/nota de IA não são autenticidade.
Nenhum threshold oficial inventado, proibição absoluta de IA/música/estático,
promessa de monetização ou promoção automática. Comparação substantiva do
catálogo musical ainda não comprovada: norma documental não fabrica capacidade.
Código/config/schemas e candidata integral0c5d77bb...ab75 preservados; não repetir
a integral1086PASS por mudança apenas documental. Preimagens e conferência em
inauthentic-policy-cross-phase-20261007. Uma etapa por vez, sem fluxo paralelo.

## F6 — qualidade musical independente não é PASS de fala nem liberação — 06/10/2026

Usar Audiobox Aesthetics CPU pinado/safetensors, janelas reais e quatro escores
distintos com incerteza; não converter notas isoladas em aprovação de3h ou
promessa médica. Receita v2 própria melhorou amostra no mesmo modelo/janelas;
v1/piloto preservados. Render/packaging/QA explicitamente instrumentais,
sem narração/captions fictícias e sem fallback ao piloto. Ramo novo de schema
1.2 não relaxa1.0/1.1; só o leitor nativo valida execução/bytes/clock atuais.
89 métodos focais com últimoPASS, não integral. Fonte musical, arquivo renderizado
ou thumbnail autenticados não dispensam qualificação final/release/admissão.
Congelar só após esse consumidor final, para não repetir integral intermediária.

## F6 — fonte musical não é voz substituta nem aprovação final — 06/10/2026

Integrar ao QA público um escopo explícito de entradas instrumentais; não usar
ASR de fala para liberar música. Autenticar bytes atuais antes do produtor,
reservar PCM além do piso de disco, medir duas amostras RAM e usar criação WAV
exclusiva contra concorrência. Fonte concluída reaberta/reutilizada; parcial
preservada sem overwrite. 22/22 focais PASS. Receita real e Bíblia existentes
copiadas byte-exatas pelo writer imutável, sem alterar original ou autoridade.
Nenhuma biblioteca/modelo externo instalado nesta rodada. Pontuações de um
modelo musical, se adotado futuramente, não podem isoladamente atestar conforto
de 3h. Não reaplicar prova do piloto a fontes novas ou antecipar integral antes
de consolidar os consumidores finais necessários.

## F6 — preservar calibração visual, não convertê-la em aprovação musical — 06/10/2026

AST de todas as funções anteriores do avaliador permanece idêntica à preimagem
ca54c3... exceto main (novo dispatch de amostra sem efeitos). Leitor de controles
recebe sucessão exata para bytes3365c6..., aceitando apenas históricos explícitos
c3e119.../ca54c3...; pares desconhecidos continuam bloqueados. Controles históricos
reabertos pelo leitor real sem mudança. 17 focais PASS com tamper/isolamento.
FFT por canal evita cancelamento estéreo; 15 focais PASS. Não converter espectro,
popularidade ou volume em declaração de fadiga/qualidade profissional. Não
usar gates de fala silenciosamente como autorização instrumental; integrar
escopo musical e prova adequada antes da operação.

## F6 — variante contínua sem modificar a base musical histórica — 06/10/2026

Para intenção nova de descanso/oração cristã, preservar a base narrada já válida.
Receita explícita rest-v1 usa desenho instrumental próprio com overlap entre
acordes em vez do fade periódico antigo. Compiler/consumer reais versionam e
recompõem o contrato, mantendo autoridade false. Treze focais PASS e medição
real da amostra demonstram capacidade técnica, não calibração artística.
Não copiar gravação de concorrentes nem usar views/metadata como áudio gold.
Não gerar três horas antes da qualificação sonora independente e adoção correta.

## F6 — áudio longo cristão e aprovação automática por escopo — 06/10/2026

Proprietário confirmou manter canal, identidade cristã, inglês e alvo americano;
autorizou produção/avaliação automática e ativação após conclusão dos gates.
Não transferir popularidade de música genérica nem aprovação do piloto de 4min40s
para áudio musical de três horas. Estender avaliador existente; medições sonoras
autênticas são capacidade nova, mas limites de mix narrada não são rubric artístico
calibrado de música. Não impor escuta rotineira ao proprietário nem fabricar PASS.
Oito métodos focais passaram; referência sonora aplicável e receita longa são a
pendência técnica, não falta de autorização para investigar/implementar no escopo.
Sem novo supervisor, promoção global de Pack ou ativação com código não adotado.

## F6/QUALITY — tempo ativo do decoder e sucessão estrita dos controles — 06/10/2026

Por autorização urgente após FAIL terminal: corrigir somente o relógio do
gerador, que incluía tempo do consumidor entre yields. Orçamento120s continua
na leitura/conversão/sonda final; população integral/FPS/cleanup intactos.
Os demais nós AST do avaliador são idênticos ao preimage. Controles históricos
permanecem imutáveis, com sucessão literal de hashes c3e1197c…→ca54c3c2…;
qualquer outra versão/tamper continua rejeitada.30focaisPASS e leitor real
dos controles PASS não concedem aprovação integral/QA/publicação.
Preservar mídia, observações e receipts históricos; nova candidata4b40fd2f…
exige sua própria prova, ativa uma única vez,995métodos. Sem heartbeat/Meta.


## F6/QUALITY — correção de codec explícita e narração preservada — 01/10/2026

Controle real identificou perda na compressão, não tolerância inadequada.
Limite deltaE8 mantido. Perfil QP1 versionado e mux-copy impedem segunda
codificação; perfil/cache antigo não é repinado. Capacidade usa medição real
com incerteza explícita, margem25% e reserva5GiB, sem alegar teto universal.
Voz1.3 só admite transição codec-only a partir de manifesto1.2 e TakePlan
arquivado exatos: medições/PCM/modelo/copy/clocks iguais, referência imutável,
reabertura no leitor de qualidade; falha bloqueia, nunca síntese silenciosa.
Hash bruto de pacote MP4 não representa qualidade quando SPS/PPS muda no mux;
teste real exige slices codificados E todos os quadros decodificados iguais.
Prova nova625fontes/f0e4bd4e… em typography-codec-proof-20261001; antiga35f9,
aplicação95c2fb30 e D1161cff82f8 preservados, sem aprovação herdada.

## F6/QUALITY — segmentação aprendida não elimina contraprova por conveniência — 27/09/2026

EfficientSAM-Ti usa representação aprendida e prompts automáticos existentes,
não novo detector ou inferência manual. Reuso do leitor público hash-bound;
método desconhecido bloqueia, sem fallback para GrabCut.18métodos/22execuções
PASS e medição real mostram185pixels de decoração incluídos. Não alterar
threshold/prompts pela faixa de teste nem transformar scoreIoU em anatomia.
Preservar FAIL, as três alternativas' hashes e modelo upstream pinado; o novo
código não herda adoção/D116 anterior. Qualificação independente e oclusão
seguem necessárias. Registro visual-learned-hand-segmentation-20260927.

## F6/QUALITY — proposta de máscara não equivale a mão — 27/09/2026

Reuso autenticado de poses/frame foi integrado à extração OpenCV local, sem
interação humana, novo modelo ou repetição de inferência. Todas as sementes
prováveis;nenhum21pontos vira silhueta fixa ou anatomia gold. RNG em worker
nativo serial encerrado, testado contra contaminação do RNG do chamador.
12focaisPASS;execução real única trouxe contraprova: toda a faixa opaca canônica
foi classificada como mão. Proposta9ccf52ce… fica diagnóstica,não admitida.
Não iterar parâmetros contra esse caso; falta identidade semântica/oclusão
qualificada. Referências GTEA sómáscara não suprem RGB/golddo domínio.
Preservar interpretações históricas e todas as autoridadesfalse.

## F6/QUALITY — observação de contorno não inventa anatomia — 27/09/2026

Métricas existentes estendidas com máscaras explícitas0/1/2 e leitor público
autenticado; comparar no sistema de coordenadas declarado, sem refit. Pixel
desconhecido/borda recortada não pode desaparecer como cobertura completa;
componente não é dedo, máscara ausente não é concordância. Distância/IoU são
medidas sem tolerância inventada.13focaisPASS e8anotações GTEA apenas qualificam
a operação geométrica/observabilidade, não um segmentador no vídeo ou HAND_DEFECT.
Conversão Otsu de JPEG é derivação explícita; preservar alternativa desconhecida
e não afirmar contorno gold lossless. Somente anotações3MB foram adquiridas,
com MIT/proveniência dos autores, sem licença inferida de mídia produtiva.
Implementaçãofocal/recibo142d0840… não instala nem libera os dez atributos.

## F6/QUALITY — cobertura espacial não é discriminação anatômica — 27/09/2026

Manter observe/preprocess legados. A grade explícita cobre todo o ROI após a
transformação publicada, mas não prova mão completa, recupera detalhe perdido
ou herda a calibração do score de recorte central. Nos16controles já conhecidos,
o máximo das64janelas falhou12/16; conservar o resultado, não adotar nem ajustar
threshold. Reusar os scores do centro, nunca reinferi-los para combinação por
tentativa. A referência independente ainda precisa medir topologia/oclusão.
Proveniência archive_member deve ser comparada integralmente, não descartada.
Evidências no registro `visual-hand-crop-coverage-20260927`.

## F6/QUALITY — paleta autêntica como negativa unilateral — 27/09/2026

O leitor atual reabre a população histórica ancorada, relógios/fonte/composição,
bytes e tolerâncias; recalcula os pixels, sem reconstruir referência/decodificar.
Uma contraprova válida determina FAIL de STYLE_DRIFT; ausência de negativa em
cobertura parcial nunca determina PASS. Registrar automaticamente o vínculo
do vídeo exato evita omissão pelo caminho padrão e não cria autoridade de fila,
render ou publicação. Histórico de execução e versão atual permanecem separados.
QP1 tem ID próprio e controles próprios; CRF18 padrão/cache antigo não mudam.
O aumento de bytes nos controles exige capacidade/QA da futura saída; nenhum
limite foi alterado nem novo perfil adotado implicitamente. Provas nos registros
`visual-palette-codec-cause-20260927` e `visual-palette-reader-integration-20260927`.

## F6/QUALITY — relógio observado antes de comparação projetada — 27/09/2026

Pedidos de PNG entre frames não constituem timestamps observados. Seleção
proposta só se aceita após PTS real e RGB idêntico em decodificador compatível.
Reutilizar PNGs aprovados/receipts, sem inventar ordem histórica. População de
paleta usa fonte/planos/font/clock independentes e composição nativa; mantém
DeltaE8 por pixel e toda autoridade false. Três negativas reais,19pixels,
foram localizadas antes do mux; não ajustar referência à candidata, omitir
bordas nem promover componente a qualidade completa. Recibos4532eeb7…,
419fdb06…/f18df80c… e testes constam emvisual-palette-frame-clock-20260926.

## F6/QUALITY — domínio de cor consistente no consumidor projetado — 26/09/2026

O frame indexado do detector permanece evidência de relógio, mas seu RGB OpenCV
não pode substituir o PNG FFmpeg na comparação de paleta com referência composta
FFmpeg. A diferença entre buffers do mesmo instante foi medida sem novo decode;
o consumidor v2 exige QA/vídeo/intenção/frame exatos e preserva v1/FAIL. DeltaE8
não muda. Um PASS_COMPONENT_ONLY no take090 não se transfere aos demais pixels,
instantes ou STYLE_DRIFT completo. Nunca inferir executável histórico ausente.

## F6/QUALITY — separar diferença de borda e defeito de estilo — 26/09/2026

Os controles em `visual-palette-region-coverage-20260926` demonstram que converter
para YUV420 após desenhar uma barra pode produzir DeltaE>8 contra a cor uniforme,
mesmo sem compressão com perdas. O escopo novo de região inteira conserva todos
os pixels e a tolerância da Bible, mas não usa essa referência inadequada para
emitir PASS/FAIL de estilo. Exige referência projetada independente antes de
qualificar a borda. Amostra de centro continua limitada; oclusão inclui o fundo
do overlay. Recibos v2 e falhas preservados, nenhum ajuste retroativo.

## T26 — sucessor de evolução autenticado e prova nova — 11/09/2026

Resolver a incompatibilidade T25 por sucessor versionado e leitor de teste estrito, não alterando manifesto/D-170. Pins fixos autenticam os seis vínculos históricos/atuais; preimages exatos também pertencem à candidata. O método de integridade continua confrontando todo o manifesto e exigindo correspondência única. Contraprovas rejeitam corrupção, ausência, corrida e auto-repin. Código produtivo, schemas, scripts, pins audiovisuais históricos e contratos de aplicação/D-116 ficaram byte-exatos em relação à T25.

Aceitar somente a prova NOVA da candidata `58071f2c9afc431ee6b4430e437fb6252f697ef2600d3746a9969d25f152d14d`: integral única 2.200 execuções/2.199 PASS/um skip permitido, exit0; envelope `001706ca751f64df014da75ff198a21675c479d38eea9bd88883875c1f76391d` lido pelo consumidor real sem efeitos operacionais. Isso torna a versão elegível à revisão de aplicação controlada; não a instala nem permite reiniciar. A T25 segue FAIL para seus bytes.

Exceção financeira limitada à ordem SALDO-EXISTENTE-550-20260911, sem compra/recarga/reset/novo serviço. Fonte oficial fornece créditos; R$550 é o teto e saldo informados pelo proprietário/supervisor, não conversão calculada pelo agente. Acompanhar débitos compartilhados e não atribuí-los integralmente ao projeto. Registros separados preservam as observações datadas e a ausência de hard cap nativo.

## T25/T24 — retenção limitada e preservação da recusa integral — 10/09/2026

Conforme ordem de continuação, integrar somente descarte comprovável de caches de compilação excluídos e selados, reutilizando a preparação e as entradas existentes; não substituir binários ainda exigidos por consumidores por relatórios. Política e limites em `docs/ARTIFACT_RETENTION.md`.

Preservar a regressão única da candidata `dec89b88fb948e7e2ae396a80f25d9539ec7f9cd1d456b770146ccd0afd60e58`: exit 1/um FAIL de evolução de fonte, sem afrouxar teste ou alterar recibo D-170. A referência anterior de pipeline termina em `3019`; a atual revisada é `a948886a790c671dac3e863dbf8f81f46268bec45838b02f5be06e5f8d34a11b`. A alteração legítima precisa de sucessor explícito, não de regravação da história ou transferência de PASS. Correção ainda não aplicada.

A observação oficial às 15:23:56 UTC marcou 99% de uso da franquia incluída; não iniciar novo lote próximo do esgotamento nem acessar saldo separado/reset. Concluir somente a reconciliação/preservação já iniciada. PAUSE, agendas e proibição de produção continuam. A integral não será repetida automaticamente; não há aplicação ou D-116 aprovados.

## D-171 — recuperação de acesso não substitui retomada operacional — 08/09 12:48UTC

Após diagnóstico HTTP200 sem persistência, executar uma recuperação delimitada
do mesmo grant, com quota própria e confirmação do canal, foi tecnicamente
justificado. Real5d37aa PASS12:38, um débito; reutilizar prova, não repetir.
Preservar FAILd9830854… e distinguir sua causa desconhecida do sucesso atual.
A fonte local904B é histórica04/09: igualdade do grant não autoriza copiar
seu access token expirado sobre o token mais recente.

O watcher de consentimento não será uma espera permanente que bloqueia toda
a operação. Passagem única retorna WAIT para fonte ausente/inválida, preserva
token/proof se grant igual e mantém mirror/refresh/readiness sob mutex. Retry
do health monitor não é removido. Instalação exige manutenção/D116 e ciclo real;
11focais PASS são somente prova focal. Manter explícito o campo legado de
máximo1probe/dia que não constitui teto implementado; correção futura versionada.
Não há troca de fornecedor, bypass de autenticação ou aprovação audiovisual.

## D-171 — distinguir qualidade da referência e incidente de acesso — 08/09 12hUTC

Fonte externa concretaOpenImages foi adquirida semconta/custo. Preservar quatro
CSV e primeiroJPEG; não repetir o download. Duas caixas aninhadas não serão
contadas como duasfaces independentes nem removidas pelaIA. Novo auditor
geométrico produz triagem por linha, separado de presença facial por imagem.
Publicações com rótulo humano podem fornecer referência independente, mas
licenças porimagem, domínio/objetivo/policy/holdout ainda precisam ser fechados.
Ver verification.md do incremento; não importar N30 temporal para YuNet.

Varietycontract novo conserva thresholds e ancestralidade real; testa contagem
proposta sem obter contagem observada por flags ou agrupamento de arquivos.
14focais do executore2232b não são render, continuidade real ou instalação.

OAuthFAIL11:40 introduz bloqueio concreto novo. Preservar a prova anterior e
usar diagnóstico manual único limitado para recuperar a causa omitida pelo
catch genérico, sem gravar token/monitor nem chamar YouTube. Retry6h não será
removido. A revisão encontrou riscos de sucesso vazio/logsSDK/causeperdida
por retryinterno; corrigidos antes de LIVE, com backups e testes separados.
Expiração de access token~1h explica probes antes de24h: o campo máximo1/dia
não é teto implementado. Correção de observabilidade/integração ficará
versionada e testada, não ocultará consumo nem dispensará identidade.

## D-172 — observação oficial sem rebase — 08/09 12:03UTC

38%consumidos/62%restantes, renovação15/09 01:22:52Z. Registro832dd673…,
decisãoa820e258b1185606/e712387d…, materializaçãoa0fd86exit0. Âncora intacta,
52pp acima reserva10%; ritmo cooperativo0.3305324pp/h, consumo30.6919434pp
à frente do plano. Nenhum reset/compra/downgrade; saldo2500 não é porcentagem.
Somente caminho crítico, sem promessa de operaçãoCodex ilimitada.

## D-172 — preservar qualidade e reserva com medição oficial — 08/09 10:53UTC

Get_usage_limits retornou36% consumidos. Registro local posterior10:53:09Z,
fonte0dd9959ffb073ba86b016271dd9f494787e07957ecfd3bd82d246ca0db816548,
decisão19c05a8d117eefd0/SHA0df25891a343e34a0a26f50c76d427bbc7bf5e7413fd7fef9db5a44acb7b8e75.
64%restantes;54pp acima da reserva10% para6,60397dias. Ritmo cooperativo
0,340704pp/h; consumo29,308674pp à frente do plano, não previsão de tarefas.
Manter âncora antiga, trabalho crítico e qualidade máxima. O saldo2500 e um
reset disponível não foram consumidos ou convertidos em percentual/orçamento.
Operação local continua independente dessa cota, sempre sob os próprios gates.

## D-171 — aceitar recuperação específica, não apagar o FAIL — 08/09 10:45UTC

Receiptf477c45b… e replay092a9b encerram somente a recuperação dos controles
reais. O supervisor já persistia process-receipt; o sucessor passa a exigi-lo
por SHA e igualdade integral com terminal.process, em vez de eliminá-lo para
caber no inventário. A exceção do arquivo urllib vazio continua exata. Não
repetir inferência por erro no agregador: dados preservados foram suficientes.
As falhas v1/v2 permanecem parte da evidência; ver control-worker-execution.md.

Candidato visual a9a1f4e… preserva narração e83estados, alterando só propostas
de composição de17. Revisão corrigiu ambiguidade de037: documento de ação fica
no histórico, previsão/relato distintos vazios entram sem rótulos extras.
Nenhuma linhagem ou redução produtiva é aprovada por essa construção metadata.
Contagem real de reuso/adjacência exige fonte/compositor e contrato versionado;
não agrupar takes porID para ocultar repetição. Fase6/GC01 continuam pendentes.

## D-171 — recuperar fechamento, não repetir medição íntegra — 08/09 10:26UTC

O buffer oficial carregou os mesmos bytes ONNX e as duas inferências reais
V2 passaram internamente. O agregador falhou ao tratar origem.py legitimamente
vazia como binding externo positivo. Não alterar o runtime global nem o worker
congelado para aceitar qualquer tamanho: consumidor sucessor deve reconstruir
o caso exato já pinado em profilec922 e fechar toda a transação preservada.
FAILed4139ac… continua histórico e estado original; receipt novo distinguirá
CHECKPOINT_RECOVERY de inferência nova, replay simples e PROVIDER_SWITCH.
Não refazer os dois raw, não apagar problem, não promover controle a calibração.

Auditoria independente separou o escopo de sucesso/calibraçãoPUBLICITY do
holdout temporal e de D-076. Registros em PHASE6_CALIBRATION_SCOPE_AUDIT.md.
N30/erro800samples/cobertura1 pertencem à policy temporal específica;23não
satisfaz30. Uma evolução de corpus externo só será executada com referência
concreta/compatível e origem versionada. Não criar outra dependência especulativa
ou reduzir critérios para obter PASS. Prosseguir nas partes independentes.

## D-171/D-172 — recuperação observada e capacidade sem rebase — 08/09 10:02UTC

Sonda real recuperada com namespace específico e vínculos de objetos, não
allowlist por prefixo. Support_bindings preserva a distinção entre stub,
arquivo de código e pseudo-módulo; o processo pai também os reabre. Python
efetivo3.12.14 não é substituído pelo número3.12.13 do pyvenv.cfg. Sucesso
terminala91fe247…/probe5b5eaec6… não autentica outro processo nem calibra YuNet.

Observação nativa registrada09:50:22Z(SHA7abc6e0c6f425da528c1cc4a0783d079d38d0ec8ee6d0a38a6be66f3661f5f51)
materializada02ca2e em7573c80add3264ef/SHAa801847d01fda04c64bf50688fb135f10592c0ffea19154e8c5ffb47d34b4f84.
67%restantes,57pp acima da reserva até15/09 01:22:52Z; ritmo cooperativo
0,35727343954pp/h, consumo26,858679pp à frente do plano. Não é previsão por
tarefa ou promessa de disponibilidade. Não houve compra, reset ou rebase.
Conferência read-only do Gestor11852 e OAuth09:49:41PASS confirma continuidade,
não conclusão do fluxo audiovisual pendente.

## D-171 — falha de atribuição exige origem específica, não waiver — 08/09 09:48UTC

A primeira sonda real falhou após imports: o loader do OpenCV cria namespaces
Python sobre diretórios tipados e anexa o objeto nativo original. Esses objetos
não são os próprios exports nativos. A correção conferirá namespace loader,
diretório único/profile, stub pinado e identidade _native exata. typing.io/re
serão reconhecidos apenas como os dois objetos da stdlib pinada que os registra.
Não permitir classes ou módulos arbitrários por prefixo, nome ou flag do chamador.
Preservar FAILb8d400fd… e diagnosticar toda a população de uma vez, evitando
um ciclo de nova validação integral a cada nome faltante.

O terminal de decodeb60cbf73… aprova somente dois PPMs. O consumidor deve
reabrir toda a transação e rejeitar sinais de falha posterior, não confiar no
status serializado isolado. Thresholds e controles prévios permanecem fixos;
sanidade operacional futura não será apresentada como calibração estatística.

## D-171 — perfil de arquivos não substitui origem executada — 08/09 09:00UTC

O perfil real c9225445… identifica bytes fixos e ausências, não atesta worker
ou publicador. A próxima sonda fará a validação integral uma vez antes de
imports, ligada ao processo isolado e origens efetivamente carregadas; evitar
validação separada idêntica. Caches existentes são hash-conferidos, não ignorados.

O retorno não vazio de detect() da implementaçãoOpenCV5.0.0 requer inteiro1;
zero/erro não será interpretado como ausência facial. A correspondência entre
fonte upstream e binário não é pressuposta; a versão efetiva ainda será observada.
Controle frontal foi selecionado por referência externa/hash e rootview antes
de inferência, acompanhado de diagrama próprio negativo. Não reajustar dados
ou threshold para passar. Esse par não substitui calibração estatística/gold
humano e não transfere qualquer autorização de publicação ao canal.

## D-171/D-172 — fechamento privado e disciplina de capacidade — 08/09 08:46UTC

O consumidor futuro mantém o Reader genuíno da contraprova no mesmo scope,
com cópias externas e invalidação após falha; recheck não repete a observação.
Seu resultado só pode ser agregado após fechamento normal e relógio final.
13focais novos comprovaram lifecycle/expiração/drift/compatibilidade, não
runtime, detecção, calibração ou admissão LIVE. Não repetir os testes antigos.

Fonte nativa08:36:38Z (SHA76f52aa9d6cc48ccc9807f178be41ef425fa12a8412d387ffe4398cdd19b1eeb)
foi processada pelo governor existente, sem alterar a âncora01:57.71%restantes
e reserva10% permitem61pp até a renovação15/09 01:22:52Z; teto cooperativo
0,3794227108pp/h, não previsão por tarefa ou promessa de disponibilidade.
Saldo2500 e um reset disponível não são autorização de gasto/resgate.

## D-171 — rechecagem sem inferência e triagem limitada — 08/09 08:32UTC

Preservar o resultado real de triagem5190601; contato não prova o teor da escrita
nem os resultados do roteiro. Admitir apenas candidatura editorial ao gesto de
registro, sujeita a intervalo, composição, direitos e QA. Não usar stock genérico
para alegar que a comparação de previsão/resultado já foi demonstrada.

Replay independente deve autenticar o buffer realmente interpretado, inclusive
população e journals, não apenas um hash de leitura anterior. A falha encontrada
pela revisão foi corrigida localmente sem alterar helpers v1/v2 pinados; baseline,
backup e focais preservados. Scope canônico A usa uma recomposição própria e
closure privada; resultados sintéticos não conferem capacidade LIVE. Integrar
esses módulos somente com runtime/calibração e consumidor versionado, mantendo
distinção entre EXACT_CACHE_REPLAY e novo processamento/provider alternativo.

## D-171 — aquisição observada e origem canônica de PUBLICITY — 08/09 08:09UTC

5190601-v2 concluiu uma tentativa com If-Match forte, tamanho e SHA locais;
18 testes sintéticos passaram antes do commit. Fonte fica em quarentena,
sem substituir A12/V6 ou converter licença de banco em liberação integral.
Não refazer o download completo para obter uma evidência equivalente.

Para o achado3, reutilizar resolve_phase6_av_context (SQLite RO/receipts) e
A.verify(require_complete=True); não invocar B, que depende de PUBLICITY,
nem o materializador exclusivo A12. Somente root é selecionado pelo chamador;
tail/input/checkpoints vêm da origem real. Plano incompleto falha antes da
recomposição de WAV ou qualquer efeito. Contexto preparado é privado à chamada,
nunca um campo verified/lista de dependências confiado ao candidato. Uma nova
verificação de contexto e bytes fecha a operação; não repetir A.verify dentro
da observação interna. Adaptador e consumidor ainda exigem testes e integração.

Atualização factual da decisão focal: recuperação11/11PASS33,044s/f8c0a9
encerra somente os resultados ausentes.34métodos distintos confirmados nos
dois grupos não são um terminal agregado inicial nem instalação/D116. Reusar
essas provas; seguir integração canônica de A e outros achados sem relabelar
o sucessor clock-only como aprovação de direitos ou capacidade LIVE.

## D-171 — execução da contraprova e isolamento de correção temporal

Preflight6f01d293…/16PASS confirma o contraexemplo condicional de concentração.
A correção deve ser editorial real: uma fonte física específica pode ser
candidata, mas não adicionar natureza genérica nem renomear o painel existente.
As PNGs phone-down/action-plan/scriptural-mechanism não demonstram resposta
pendente, registro factual completo ou passagem bíblica específica por rótulo.

Revisão do patchPUBLICITY encontrou dependência de clean_plate/adapter11 no
helperv1b20ffd38…. Escolhido sucessorv2 com schema próprio e testes próprios,
restaurando literalmente os originais antes de teste; nenhuma redução de pin.
A correção de clock trata somente achado5 da revisão original; os outros4
e adoção coordenada continuam exigidos. Perda do terminal não é sucesso:
23PASS observados são preservados e só11sem confirmação serão recuperados.

Aquisição do novo candidato5190601 é limitada a quarentena para inspeção.
Primeiro parcial não contém ETag ligado ao GET; não retomar bytes como cache
validado. Preservar7b689b33… e registrar segunda tentativa em namespace novo,
umGET If-Match/tamanho/timeout/reserva5GiB/receipt. RETRY_SAME_PROVIDER não vira
PROVIDER_SWITCH. Página/licença e frames parciais não aprovam direitos finais,
movimento, semântica, alocação ou publicação. Custo técnico adicionalR$0.

## D-171 — instalação real e prevenção de concentração antes da próxima produção

Lote A12/C15/adapter11 e leitores encerrou manutenção66aae4cc em836013exit0,
1780PASS/1skip,180schemas e554artefatos. Final2160bab5…/D116726e233e…,
recuperação23076→11852 e ciclo novo12/12 comprovados. Reutilizar o lote;
nenhuma falha focal histórica foi apagada e nenhum gate de vídeo foi aprovado.

Na revisão da próxima alocação, a soma independente das unidades inteiras
vinculadas a uma única linhagem refutou a hipótese fullframe:four-criteria
979968samples=40,832s contra28,625s máximos no teto286,25s/limite10%.
Excesso mínimo12,207s; diluição exigiria408,32s fora da banda. É contraprova
condicional sem horários lexicais, não medição de exposição de vídeo pronto.
Não fabricar variedade por IDs/prompt/composição comum; preservar os ativos
estáticos como fontes parciais e corrigir a exposição/alocação de verdade.
Essa verificação passa a anteceder novas cartelas, evitando expandir a hipótese
inviável. O preflight focal será puro, hash-bound e sem autoridade de render.

Leitura nativa06:57:16Z informa76%restantes,1reset intacto; materialização
cbca6f27… conserva âncora e reserva10%. A documentação oficial foi consultada
pela skill OpenAI Docs: consumo depende da tarefa/modelo/contexto, não há
previsão exata por mensagem. Fonte: https://learn.chatgpt.com/docs/pricing.
Aplicação: manter qualidade, caminho crítico e reuso, sem compra/reset ou
rebase para esconder19,3751pp acima do ritmo planejado.

## D-171 — A12 real preserva o histórico sem conceder autoridade de mídia

Build8edeca→70aeb6exit0 produziu timeline c38a12e6… e receipt a307d2cc…,
quatro hashes conferidos9b358f incluindo arguments e A11 intacta. O novo
vínculo literal tem39ativos/41usos/37conteúdos/3linhagens/59pendentes; não é
aprovação de movimento, áudio, sincronização, publicidade ou publicação.
O builder teve12/12focaisPASS47,328s e preflight real sem escrita antes do
commit exclusivo. Corrigida previamente a rechecagem para usar inventário
recomposto na mesma chamada, nunca um sink serializado como prova nova.
Tempos têm escopos explícitos:107,875s no receipt até timeline;124,438s até
rechecagem final;145,6275488s externos. Nenhuma duração é nova medida de mídia.
A próxima ação é instalar/testar o lote inteiro uma vez sob manutenção D116,
sem edição concorrente, sem repetir construção, OCR, narração ou geração.

## D-171 — V4 real concluído por contexto único

Materializador40079c23… teve paridade canônica contra inspectorV4, com16focais
PASS67,784s(e48a66). Commit b17971→4da453exit0 produziu receipt8a4a33c6…,
conferido juntamente com input/inspection/claim por0eda86. Mantidos os29usos
anteriores e adicionados12 sem inferir onsets, spans ou autoridade. A duração
total externa foi128,9811514s;70,313s do commit incluíram rechecagem final.
Um envelope e dois replays metadata, sem nova medição de imagem/OCR/direitos.
Recuperação de cache comprovada nesse escopo, não novo executor de produção.
O próximo builder deverá correlacionar a inspeção externa ao hash recomposto
por A12; rechecagem posterior de bytes não usará objeto serializado como
se fosse sink privado recém-emitido. Instalação/D116 ainda pendentes.

## D-171 — revisão independente do delta A12, 08/09 06:08UTC

Revisão somente leitura não encontrou defeito novo no trio fechado, história
V2/V3/V5 separada, fechamento de40dependências e rechecagens finais do leitor.
Escopo limitado ao delta; não substitui focais, timeline real ou manutenção.
Ressalva preexistente conservada: C pode construir um command_graph de fixture
não executável mesmo com bloqueio de emenda, no ramo sintético810–814.
Isso não libera produção: status COMPILED_FIXTURE_NOT_EXECUTABLE e autoridades
falsas permanecem, enquanto o adapter histórico rejeita V6 antes das fontes.
Não declarar graph=null para toda fixture nem interpretar serialização como
capacidade produtiva. Não houve mudança de código por essa revisão.

## D-171 — evolução compatível e falhas focais registradas

A12/schema1.11.0 captura40dependências, A11 e demais legados conservam teto
global20 e seus limites menores. Contraprovas das dez versões passaram;
não alterar provas históricas para consumir V6. C15/schema1.14.0 e adapter11
despacham A12, mas continuam rejeitando grafo visual emendado sem compositor
próprio e evidência audiovisual completa. B aceita apenas a forma estrutural
da nova versão, não direitos/publicity/admissão por metadado.
Focais V4/joiner18PASS59d539, schema8PASS5cd401, legados16PASS05ac79,
consumidores75PASSbe1ea3. Primeira integração45teve43PASS/2FAIL de expectativa
20versus40; backupdos testes e falhaeab0b2preservados; sódoisafetados
reexecutados2PASS7ca1a6. Nenhum limiar ou consumidor relaxado para passar.
Esses resultados não substituem a instalação agrupada/D116 ainda pendente.

## D-171 — recuperação exata de fontes registradas e evolução conjunta

Commit70207e→2825a5 terminou133,797s, receipte2b0beb8… com12provas e24direitos,
conferidos por leitura independente edc83c. Dois replays/11decodes realizados
nessa única operação; ZERO OCR/render/custo. Não repetir o registro.
Implementados replays distintos do V3 histórico e do novo registro body,
com âncoras externas e recomposição de arquivos/inventários/bytes antes de
qualquer retorno; replays não avaliam novamente a imagem nem criam direitos.
O leitor V6 mantém V5 e suas decisões separados, sem inventar cronograma.
Provas focais:8PASS31a645,11PASS26d9eb,11PASS1540ea respectivamente.
Escolhida integração conjunta A12/C15/adapter11 preservando versões anteriores;
limites legados não podem ser ampliados pela nova contagem de dependências.
Não instalada ainda. A11 real e os bloqueios audiovisuais permanecem vigentes.

## D-171 — provas estáveis por template e receipt com evidência completa

A revisão prévia detectou que incluir dependências e contadores do lote misto
em cada prova alteraria seu hash na verificação individual. A correção mantém
prova/identificador/contador locais ao template e total operacional separado,
medido pelos dois replays que realmente retornaram. Os snapshots90a7b423… e
7748982d… foram preservados antes da evolução; não houve registro real nessa
versão. Facadefinal e240c94a…/testee51b5b75…:17PASS, incluindo equivalência
single/subset/mixed e export somente no sucesso.

O registrador foi melhorado antes de seu primeiro commit para guardar doze
provas de fonte completas, além dos seus hashes já presos aos direitos, e a
contagem da execução. Isso permite ao próximo elo reconstituir uma recuperação
de cache ancorada sem repetir pixels/OCR. Direitos4ddfe87c…/teste658b2e07…
passaram27focais; registrar31d3d3f9…/testea20944b9… passou13 (cinco novos,
oito afetados). Os quatro arquivos anteriores estão hash-conferidos no backup
body-static-registration-v1/before-same-call-proof-retention-v1/.

Preflight real d205c1 passou; commit70207e foi despachado uma vez. Sua espera
não é sucesso, fallback alternativo, conclusão deA11 ou autorização de vídeo.

## D-171 — fechamento do QA record e integração restrita aos doze estados

QA95295ea2… encerrou medição independente: oito checks de pixels por registro,
cinco inferências OCR para seis estados; o par idêntico compartilha medição,
não constitui uma sexta avaliação independente. Continuidade literal/geométrica passou.
Isso não demonstra aprendizado publicado nem interpretação audiovisual.
O FAIL de fixture b9fc15 foi corrigido sem alterar QA, fontes ou tolerâncias;
um método afetado reexecutado, dezesseis resultados intactos preservados.

Escolhida extensão aditiva fechada de fonte/direitos para os dois templates,
sem alargar contratos anteriores. Registro exclusivo cria24documentos, não
doze autorizações de publicação. Pré-valida o lote, faz replay por template
uma única vez, reabre dependências após efeitos e conserva qualquer checkpoint
parcial como falha. Dezesseis testes transacionais passaram, mas não são
evidência LIVE. Consumidores antigos e A11 continuam fechados até sucessores
versionados e regressão da instalação completa.

## D-171 — continuidade literal sem geração duplicada

Record-learning mantém u036-s00/u037-s00 como dois caminhos físicos de mesma
imagem: duas ocorrências narrativas, um conteúdo, mesma linhagem ancestral.
Receita21focaisPASS e geração única c61b7a2a… mediram cinco rasters para seis
estados; observação visual própria registrada em nota específica, não gold
humano ou aprovação audiovisual. O QA independente deverá reabrir ambos os
caminhos ao compartilhar uma única inferência OCR, fechar imagens também em
falha e preservar receipt/scans. Copiar bytes não permite copiar timing,
intenção narrativa ou aprovação operacional de direitos.

Integração será conjunta com three-moves depois de QA/replay específicos,
sem ampliar contratos anteriores por flags ou repetir uma manutenção por
cartela. A11 segue29/71; ocorrência estática não resolve calibração lexical,
compreensão, voz, duração, render ou publicação.

## D-171 — consumo observado sem rebase oportunista

Leituraoficial registrada04:32:27UTC:13%used/87%remaining, mesma renovação
15/09 às01:22:52UTC. Política01:57 permaneceintacta; decisão dc0ec169…
33c155e8… marca AHEAD_OF_PLAN, criticalpathonly. Reserva10/77planejáveis e
11,21085225597169pontos/dia são ritmo deplanejamento, não limiteoficialnem
previsãodetarefa. Limitar novasfrentes, manter qualidade e Gestorlocal; fechar
checkpointscríticosjáemcurso sem repetição. Nenhumresgate ou compraautorizado.

## D-171 — amostra three-moves encerrada e próximo lote coeso

Geração8a099616… e QA50015cb4… mediram seisestados,54checksdepixels,
8linhasOCR/6scans,confmínima0,97452 e headline idêntico. Reutilizar bytes;
PASS_STATIC_SCOPE_ONLY não é compreensão, timing, voz, direitofinal ou release.
Nota bc683119… registra observação própria limitada; novo registro operacional
ainda necessário. O domínio de filtro foi corrigido com suporte matemático,
não alteração de imagem ou tolerância; FAIL e contraprova ficam preservados.

Root aceita a proposta036–038 apenas para protótipo: previsão introduzida como
categoria nova em enquadramento distinto, nunca rebatismo deAction; instruções
fora das áreas vazias, registros038espacialmente estáveis. Sem adicionarcopy
ou resultados. Produzir e provar o lote separadamente antes de uma integração
agrupada comthree-moves, reduzindo manutenção repetida sem omitir consumidores.

## D-171 — regressão recuperada, emenda única e exclusividade de efeitos

Instalação e58a92f9 encerrouPASS4a5977:1670PASS+1skip,178schemas,554itens;
D1169c233c42… recuperou23076 e novo12/12, cinco snapshots conferidos. Preservar
FAIL4eaf3294 e sua correção focal; não repetir o lote agora íntegro.

Proposta body-case foi materializada uma vez:V6ba7dabb1…/e56a4135…,
21/24/79, sem alterarA11/união/áudio. Receita18focais e preflight realPASS
permitem somente a amostra diagnóstica, não admissão ou publicação.

Revisão prévia encontrou tolerância indevida do writer legado a destino final
idêntico. Novos recipe/QA usam privado+os.link exclusivo e inventários; backups
before-exclusive-write-v1 preservam versões anteriores. Colisão é FAIL, nunca
replay tácito. QA teve FAIL sintético2ad36e;3ab672 isolou quatro pixels no
domínio recortado do filtro. Corrigir domínio matemático com guarda fixa de
suporte, não fonte/cor/limiar. Prova de pixels não será chamada de compreensão,
percepção sonora, timing lexical, direito ou aprovação produtiva.

## D-171 — recuperação do FAIL de downgrade, sem alterar o contrato

Manutenção4eaf3294 falhou5d14b9exit1 em um teste sintético entre1671executados;
umskip deWinError1314 continua não aprovado. Traceback confirma que o campo
question_case_amendment_evidence:null foi indevidamente retido ao criar1.1.
Remover exclusivamente esse campo da fixture preserva o guard que rejeita
capacidade nova em contrato antigo. Backupb7fd1f: b2d768d2…; sucessor99c1ea90…;
focal1/1PASS3,870s(a3fed2). Não ampliar schema, não descartar o FAIL e não
apresentar a recuperação19872 como aprovação da manutenção. Novo lote integral
é obrigatório; nenhuma mídia/ASR/OCR intacta será gerada para esse fim.

## D-171 — emenda consolidada do corpo e preparação especializada

Auditoria read-only de V5/A11/Bible/inspectionV3 confirmou24ocorrências em
21estados fora dos29vinculados. Corrigir somente sua caixa por mapa fechado,
preservando79estados, hooks, narrativa, entradas e união26. Precedência
u026-s01 é explícita e limitada à capitalização; Name / Test / Choose é
sentence case por rótulo. Não promover proposta a QA ou suporte produtivo.
Plano em docs/PHASE6_BODY_CASE_AND_THREE_MOVES_TASK.md. Os seis estados
iniciais usam headline branco inteiro, foco por underline dourado e o painel
ancestral existente; isso não acrescenta linhagem independente de variedade.

Preparação paralela durante a manutenção restringe-se a novos diagnósticos
nas pastas body-case-v1 e three-moves-identity-v1. O inventário efetivo da
manutenção cobre tests/test_*.py e schemas; compileall cobre hero_engine/tests
(verificação231594). Nada congelado é alterado e nenhum teste/mídia adicional
será executado simultaneamente. Isso não constitui instalação desses ensaios.

Revisão da duração corrigiu uma interpretação:14100ms é projeção ceil100 de
uma proposta não aplicada, não teto editorial aprovado. O master real202780ms
tem déficit5020ms até a grade207800. A diferença2900ms pertence somente à
projeção204900ms. Não preencher qualquer déficit com silêncio. Avaliar primeiro
necessidade real de READ_VISUAL/COMPREHENSION nos quatro estados agora legíveis
u011-s01/u012-s01/u020-s01/u021-s00, descontando tempo disponível e caudas.
Sem onset validado, o tempo de leitura permanece indisponível. Não reduzir
o piso congelado do experimento nem afirmar que esta hipótese resolveu duração.

## D-171 — A11 real e fechamento do lote de perguntas

A11real06198f55…/10f31b09… sob receiptac5f859a… terminou63ef21exit0 com
preservação integral exigida deA10,29usos/71pendentes e união26 intacta.
Não promoveu fonte estática a vídeo, não criou tempo de palavra, duração ou
capacidade de render. A inspeçãoV3 externa139a68f7… precisa coincidir com a
recomposição própria deA, incluindo effective_rows; ela não se autoaprova.

Revisão do wrapper corrigiu antes do focal três lacunas: hashes de rows antes
apenas mutuamente associados agora também presos à prova externa; população
de8pins/materialization_id/claim recompostos; rechecagem após escrita do claim
antes dos argumentos. Backup24abddb… preservado. Runner68ad0ebc… e test
05b36be6… passaram12/12(3c3bb3), integração4544c860…9/9(be8edd). UsosV3 e
A11 não serão reconstruídos para produzir progresso aparente. A instalação
será concluída em lote único com préviaD142/regressão/D116, sem relaxar gates.

## D-171 — V3 real e contraprova de compatibilidade dos consumidores

Execução real V3 encerrou4a1a09exit0 sob receipt984b972d…, input3e74c984… e
inspection139a68f7…:29usos,27ativos,26PNG,3linhagens e71pendentes;31s internos,
38,156s até a última rechecagem. Um batch de contêineres das quatro perguntas,
sem decode/OCR/render/serviço externo/gasto ou nova concessão de direitos.
O receipt é metadado sem tempo, não timeline nem qualidade final.

Lote legado23aaec teve76execuções/2erros em72,984s; o erro de setup não conta
como teste executado e impede deduzir passes simplesmente por subtração.
Corrigidos somente campo novo null na fixture histórica e const antiga do
adapter no subschema deC. Backups59abcf preservados. Reexecução restrita24/24
PASS57,660s(ab6520), novo negativo decompatbody. Não repetir módulos intactos
como progresso nem enfraquecer schemas para aceitar emendas em versões antigas.

## D-171 — registro real das perguntas e evolução versionada A11

Registro ab6bdbb3… (322771exit0,24,938s total, recorded_at02:35:53UTC) materializou
oito documentos para quatro estados OWNED da linhagem four-criteria já
existente. Escopo somente direitos da arte própria revisada, não aprovação
audiovisual. Registrar18/18PASS4e39ac após correção de bootstrap do teste
df8c6f, preservado; nenhum gate alterado. Case reader8/8PASS5ed463, V3uses
9/9PASS04cd41 e joiner8/8PASSe46c8e; revisão independente read-only dos cinco
arquivos confirmou hashes e não identificou defeito no escopo.

Escolhida evolução aditiva A11/schema1.10: visual_amendment_evidence conserva
V3, nova question_case_amendment_evidence contém apenas delta V5. Novo joiner
recompõe29usos/27ativos/26PNG/3linhagens e mantém71pendentes; metadados não
criam spans ou início lexical. Os seis consumidores/schemas A10/C13/adapter9/B
foram copiados byte-identical em test-questions-v1/before-A11-integration
(658919). Materialização e instalação ainda pendentes; custo adicionalR$0.

## D-171 — staging V5 e cache exato dos 25 vínculos anteriores

Execução b22323 gravou somente emenda b07bca4c…/projeção7fd136fe… sob receipt
3e22ff39…; A10 permanece intacto. Puro9/9 e stager10/10PASS. Novo inspector
question_sources3ed0553a… passou10/10, combinando prova estática pinada com
contêinerPNG/CRC sem alpha/APNG, sem nova decode. O próprio código agora é
pinado antes do replay e rechecado depois; teste de substituição cobre o risco.
Novos direitos têm schema próprio e17fixturesPASS, sem herdar revisão compacta
ou transformar ausência de pessoas/marcas no desenho em publicidade aprovada.

Para evitar repetir o lote compacto, replay68221c67… reabre âncora9e14abf9…,
input65be0312… e inspection14641e12…, recompõe25usos/23ativos/dependências,
confere inventários e bytes atuais.7/7focaisPASS58,478s, sem decode/OCR/rights
evaluator. É EXACT_CACHE_REPLAY, não PROVIDER_SWITCH nem novo direito.
A evolução seguinte terá29usos/27ativos/26conteúdosPNG e apenas3linhagens;
essas contagens são alvo do contrato, ainda não estado operacional observado.

## D-171 — evidência da reconciliação e evolução explícita dos consumidores

A contraprova bdefea7f… foi testada10/10PASS e executada uma vez. Report
0ac7a3fb… PASS_STATIC_SCOPE_ONLY,02:07:44UTC,0,453s: sete contornos medidos em
quatroPNG, sem refazer OCR/render/QA integral. Envelope de detecção contém
toda tinta medida; seu centro associa a linha a um dos campos originais.
Não há tolerância ajustada aos casos ou ampliação do campo. O FAIL original
eac99752… permanece FAIL; nova evidência possui versão e proveniência próprias.
Decisão: criar contrato/stager case-only v2 em novos arquivos; o v1 permanece
incapaz de aceitar a reconciliação. Essa evolução ainda não altera A10 ou
concede autoridade de produção. Wrapper v1 preservado em before-stage-large-model-recheck
antes das correções de modelo21MB e claim pinado;9/9focais56c8d8PASS, sem
reexecutar o staging real ou chamar esse teste de recuperação observada.

## D-172 — rebase por nova resposta nativa, sem inventar sua causa

O endpoint nativo retornou2%usados/98%restantes, renovação15/09/2026
01:22:52UTC e1reset disponível. Captura01:57:38UTC preservada em
account-20260908T015738Z-native.json; IDda conta/bucketSpark/legacyduplicado
omitidos explicitamente. Não houve resgate pelo sistema nesta ação e não se
deduz reset, compra ou comportamento do proprietário da mudança observada.
Policy b3644104… foi copiada/hashconferida antes de trocar somente âncora,
timestamp e referência da observação. Nova policy ae2d9e7e…; decisão
d9be9e5c827a55d0 GREEN/ON_PLAN. Nenhum saldo convertido em percentual, reserva
10%/ultra/custo0 intactos.21/21testesPASS0,608s incluindo fixture temporal
independente. O ciclo deQA não é repetido por esse rebase de configuração.
A orientação oficial confirma que a conta compartilha uso e o consumo varia
por contexto/modelo/tarefa; não há promessa de crédito inesgotável.
[OpenAI — Pricing](https://learn.chatgpt.com/docs/pricing).

## D-171 — detector OCR não é contorno das letras

QA real de perguntas eac99752… FAIL_STATIC_SCOPE preservado: texto correto em
4/4, pixelvetores9/9 por imagem e revelação4/4, mas envelope de detecção excede
os campos de tinta. Não regenerar as fontes nem repetirOCR. A contraprova deve
associar texto à região e medir seu contorno real, preservando os limites
originais de pixels/safearea/caption e a igualdade textual/confiança. Não
ajustar um limiar aos quatro resultados observados nem relabelar oFAILantigo.
Stagercase exigeQAaprovado e bloqueou esseFAILsem escrita em teste realread-only.
A revisão do wrapper adicionou dependências obrigatórias recompostas, modelos
allowlisted, vetor completo9subgates, inventários finais e claimexclusivo.
Focais6+7 são duas execuções; nenhuma emenda/projeção foi materializada.

## D-171 — fechamento de instalação A10 e fontes TEST separadas da admissão

Instalação87be8b35/final50b68c85 e D1162b2aa4c7… encerraram PASS em
08/09/2026 01:28:01UTC:1.556PASS/1skip,175schemas, cinco snapshots conferidos,
GestorPID14048/ciclo12/12. Não repetir regressão intacta por diagnóstico estático.
Quatro fontes question-field geradas após a manutenção, uma vez em1,375s,
receiptf63ac629a6e9c76ba3485e5dd182123034d108fce515985fce632a71d716c622.
As quatro imagens foram observadas por root; não transformar inspeção da IA
em revisão humana, avaliação temporal ou aprovação final. Copy5/2/5/7 sem
indicadores herdados foi mantida; próximas evidências serão QA independente,
direitos do lote e emenda case-only antes de reduzir as75fontes pendentes.
A prova de render estático não amplia a linhagem, FormatPack ou autoridadeAV.

## D-171 — fontes estáticas reais, relógio explícito e consumidor versionado

Próximo lote selecionado por correspondência literal e reuso seguro:
u019/u020/u021,4estados/takes024–027. Auditoria rejeitou reutilizar imagens
state0/state2 de u034 porque trazem contadores0/4 e2/4. A receita própria herda
somente painel/paleta/fonte/renderer, mantendo a mesma linhagem visual. Sem
heading extra (seriam10palavras emu021); copy total5/2/5/7. TEST/LOUD IS NOT TRUE/
CHARACTER passam aTest/Loud is not true/Character em proposta case-only, não
uma dispensa silenciosa de sentence case da Bible.96estados fora do lote ficam
preservados; u020-s01 conserva a âncora literal[18,35), sem timestamp. Preparação
isolada não altera o lote em regressão; testes/geração/QA/rights/amendment/uso
seguem o Done when da nova PhaseTask, não estão concluídos pelo plano.

Fechamento de construçãoA10: execução realf86c7fexit0,15,938s, receipt
e0f667014b752c02900d7d94c0ea754fdab1c02040305167b61ecc344d8f54ed.
A revisão do wrapper identificou uma janela pós-build: source_file_bindings
não cobre necessariamente todos os implementation_dependencies. Correção
adf57664… adiciona o conjunto explícito mais textwrap e font/decoder allowlisted
à conferência final, sem decode ou caminhos externos arbitrários.11/11testes
70cbab68…PASS6,094s; segunda revisão sem achados adicionais nessa correção.
Preservados wrapper72bfd6fe… e testesf1259216… antes do ajuste. Rejeição de
timeline sem receipt continua bloqueio explícito, não fallback de recuperação.
Instalação ainda requer o lote de regressão+D116; não repetir A10/media intactos.

Decisão de integraçãoA10: a capacidade v2untimed é ramo opt-in separado da
inspeção estática temporal. Acrescentar23ativos/25usos não resolve automaticamente
75estados, duração ou calibração. Leitor própriof3cd3a30… recompõe unit/copy/entry
contra100estados e verifica dependências finais; schemas antigos rejeitam campo
novo. C13/adapterv9/B reconhecem versão nova, sem usar o compositor incompatível.
V2 foi materializada uma única vez, receipt9e14abf9…/inspection14641e1…;
replay histórico permanece EXACT_CACHE_REPLAY, nunca PROVIDER_SWITCH.
Preservados FAILs ec16e9 (documento antigo não possuía campo novo), dd58a2
(schema de código não é JSON operacional canônico), a82b3ca1 (duas referências
de versão não migradas), f1218648 (82PASS/1expectativa de schema antiga).
As correções são de despacho/contrato/fixtures, não redução da qualidade.
WrapperA10 reusa silêncio mecânico por hash dos inputs e conserva literalmente
intervalos/razões/referências editoriais. Arquivos parciais exigem pin externo;
timeline já gravada bloqueia reconstrução, mesmo sem receipt final. Tal bloqueio
não será anunciado como recuperação implementada. Instalação permanece pendente.

Decisão08/09/2026: cartelas compactas recebem verificador e revisão próprios,
sem ampliar TEMPLATES dos leitores anteriores. Rights9ae330a8… exige note
137760be… e schema88e074d2…, sem declaração de revisão humana/parecer legal.
OWNED descreve origem controlada da composição esquemática rasterizada e não
exclusividade autoral deIA, redistribuição deArial, publicity ou release final.
Registro real4dfb14exit0,00:23:19UTC,6,797s:5dfd9d4f36ce2d30b276bf82666ef26bdc922f0879cc26fbaa928fed363364aa,
12provas/24documentos/1linhagem e allauthorityfalse. Request029d9066… é fixo
por versão; relógio de aplicação00:22:29UTC é observação nova, não retrodata
a revisão. Nova tentativa requer pin externo e mesmos bytes, não novo horário.

Contraprovas de recuperação e pré-verificação: todos os documentos de um batch
devem ser conferidos antes do primeiro decode. Ausência/corrupção de decisão
posterior bloqueia sem inspecionar imagens. Registro inscreve também o request
recém-escrito nas dependências finais, para detectar deriva durante avaliação.
Sem esse vínculo, a verificação cobria só retomadas; revisão identificou e
corrigiu antes da execução real. Backups preservados; registrador386e09cb…/
testes8d340e1c… com12/12PASS6,219s(c5b5d8e6…). Direitos17PASS históricos,
4novospreflightsPASS e1drift afetadoPASS não serão somados como uma só suíte.

Continuação em arquivo v2: preservar13usos históricos/11assets/2linhagens por
EXACT_CACHE_REPLAY de receiptb7b76158… com cadeia física inteira; somar12usos
compactos/12assets/11hashes/1linhagem sem inflar variedade. Total esperado25
usos,23assetsdeestado,22hashesPNG e3linhagens;75estados continuam sem vínculo.
Esse reuso não é PROVIDER_SWITCH nem aprovação nova. A entrada lexicalwrite,
o HOLDu016 e a origem dos callbacksu044/u045 permanecem literais e sem tempos.
Integração temporal/consumidores seguirá contrato próprio e gates pendentes;
nenhum dado de uso retira o bloqueio de calibração, duração, percepção ou B.

Instalação A9 verificada23:50:27UTC: manutençãoa4f5d1da/finaleb285901, SHA
2d907dc7d73cd29d8143f0b6671e875043fe0faa5ad2c931f04ccaf05d9f881b,
1.469PASS/1skip em1.470casos,173schemas,554itens íntegros; terminal79c63aexit0.
D116a503fb61…/SHA7d68527b… reconcilia GestorPID2216 e ciclo8ea18d2d…12/12.
Cinco snapshots confirmados por bytes; queue/quota/efeitos/OAuth preservados.
Fim das barreiras de request/ack/recovery, preservando capability residente.
Essa evidência encerra somente o lote de integração literal; não conclui
GC-01, áudio, fontes, admissão, compositorAV, Vídeo2 ou Fase6. Reutilizar os
receipts em vez de repetir regressão ou mídia sem alteração efetiva.

A9 real36c585e7…(3f1961exit0,4,438s) fecha apenas a integração literal da
emenda. Implementaçãof52bb315…/schemae19823af… preserva V2 como base
histórica e inspeciona a projeção nova com leitor0205fe37…/schemaa7fc96bc….
12estados alterados/88preservados; união26 e todos os gates pendentes intactos.
C12/adapterv8 bloqueiam renderer histórico sob emenda; B apenas reconhece
schema1.8 estático, sem dispensa de admissão. Backups anteriores byte-idênticos.

Correção de proveniência: input completo de A participa de evidence_ref nos
silêncios LOCKED_HOOK_PAD e MECHANICAL_GRID_PAD. Acrescentar a emenda muda esse
hash, não os tempos. A comparação inicial excessivamente ampla falhou935227;
o sucessor valida o hash antigo e recompõe o novo, comparando canonicamente
intervalos, razões, tipos e ordem; EDITORIAL_PAUSE conserva sua própria prova.
FAIL0dd57876… e argumento34e60eda… preservados, recuperação explícita por
pin externo, nenhuma sobrescrita. Pin nulo/formato inválido falha antes da
leitura; timeline já persistida impede build duplicado. A9 incompleto jamais
é receipt de render ou autoridade. Regressão/D116 deste lote ainda pendentes.

Correção editorial explícita materializada8ba18bexit0(1,698s), depois de
10/10testesPASS2,368s(c14bea). Stager5ff02d0e…/testes2f8ed637… produziu
amendment87567b59…(SHAfb2543b0…) e projeçãoV3d629bce9… com escrita exclusiva.
Não reescrever decisõesD169 que diziam “existing/exact” ou seus bindings para
fingir que o predecessor já continha a composição nova. Preservar as51decisões
históricas, aplicar somente o mapa explícito12before/after e manter88estados,
25negativas, textos e âncoras. A nova cópia Fear's forecast atribui a inferência;
nenhum estado não lexical ganha revelação interna. O kind novo é incompatível
com o leitor antigo de propósito: exige sucessor que recomponha a amendment,
sem alteração silenciosa do planoV2, TakePlan, Bible, experimento ou fonte ativa.
Contagem/inteireza de fontes não concedem tempo, direitos, render ou publicação.

Reconciliação677fe3df…PASS_STATIC_SCOPE_ONLY em1,554s(9150ee) preserva FAIL
ec708da8…, reabre suas11leituras OCR e recalcula expectativas/identidades
sem inferência. Perfil9e7796fd… usa geometria literal seis pixels nos dois
lados+LANCZOS2x, sem cor aprendida da amostra ou tolerância.6/6testesPASS
4,966s(b192e7) incluem12PNGs reais e contraprovas sintéticas de erro;582.144
comparações de interior passaram. Não expandir a alegação às bordas laterais
excluídas, ao vídeo em movimento ou à percepção/sincronização. O mapa estático
é corrigido e medido; integração produtiva e nova decisão editorial explícita
ainda são necessárias. Os31focais pertencem a três execuções distintas.

Contraprova estática ec708da8… permanece FAIL_STATIC_SCOPE apesar de OCR12/12,
HOLD, captions reserve e localização das revelações PASS. O verificador51479ee…
comparou dois pixels y328 com cor sólida; a receita51a6c8d4… rasteriza2x e reduz
por LANCZOS. Leitura51dce6 observou ativoRGB(214,168,74) em328 contra a cor
nominal(215,169,74), com perfil simétrico nas bordas326/331. Não remapear cores
observadas para PASS nem introduzir tolerância. A nova referência deve derivar
do retângulo/filtro pinados e comparar o perfil interior pixel a pixel.
Hipótese inicial de faixa inativa3px rejeitada na leitura do último drawstrip:
a sobreposição real tem6px tanto no gold quanto no teal. Fontes e OCR ficam
intactos; reabrir as11saídas OCR com pins observados na reconciliação, sem alegar
que esses hashes estavam no reportv1. Simulação1D de referência não é render
de mídia nem prova de borda externa, temporal, áudio ou vídeo completo.

Cota nativa materializada uma vez no receipt `codex-usage-31e40d36be9fec82`:
21% usados/79% restantes, renovação2026-09-14T13:11:15Z, reserva10%,
AHEAD_OF_PLAN/FULL_QUALITY_CRITICAL_PATH_ONLY. O campo observed_at22:13:00Z
é o horário de materialização do retorno nativo já consultado nesta execução,
não uma segunda leitura oficial naquele instante. A primeira tentativa de
transporte JSON por argv falhou(d73c74exit1); stdin resolveu(a7ad28exit0).
Nenhum reset, compra, rebase de âncora, downgrade ou despertar do QR Dolar.

Remediação das duas colunas será ensaio estático isolado antes de alterar
consumidores produtivos: cabeçalhos sentence case Fact / Fear's forecast,
valores condensados e ausência de title/footer apenas nos12estados. Apóstrofo
ASCII conserva a tokenização do contador existente. Revisão independente
designada do mapa aceitou a distinção factual/medo, não uma aprovação visual.
TOPIC_ANGLE e os demais locks continuam; o futuro sucessor deve registrar a
reparação e seu efeito potencial, sem atribuir causalidade isolada ao ângulo.
Esse ensaio não substitui V2, não agenda eventos, não reabre SUCCEEDED e não
executa o vídeo produtivo. O rodapé TRT do hook003 e dos outros usos não muda.

Fechamento verificado: manutenção636c9615 terminou PASS, final31cfd112
SHA2245885d3eb043091ad4d3868f4c220d5bf09d6397b24100ef9d7ef2b65f41ba;
1.444 PASS/1 skip, 172 schemas; D11619b5e05e… e ciclo4cb60c42…12/12.
Os FAILs1b05273b/94c3c90d e seus receipts permanecem históricos. Corrigir a
leitura do lock resolveu a condição no ensaio e na instalação; isso não prova
ausência universal de falhas, áudio aprovado, GC-01 ou publicação. Reutilizar
os cinco snapshots imutáveis verificados, sem nova manutenção discricionária.

Auditoria read-only da receita two-column-v2: título4 + cabeçalhos2 + footer3
já totalizam9 palavras; valores elevam a19. O guard8 de phase6_quality:783
mede só TakePlan.on_screen_text; phase6_overlay_ocr:395–401 ignora null e
437–439 amostra um midpoint. O take012 antigo diverge do renderer e013–023
não são cobertos. Uma exceção de caixa alta não resolve quantidade ou cobertura.
Preservar receita/plano antigos, criar composição sucessora mais concisa e
expectativa por estado; não reinterpretar orçamento por bloco ou excluir
decoração textual da contagem para aprovar a saída. Geometria por bloco não
prova legibilidade do conjunto. Não dispensar também a avaliação de congelamento:
o contrato futuro de hold terá de provar intervalo/intenção/frames exatos,
mantendo bloqueio de freeze indevido e sem promover imagem bonita a vídeo PASS.

Execução real de static-asset-uses-v1: b7b76158…/8,063 s, inspeção34450e73…;
13 usos exatos e 11 PNGs permanecem duas linhagens. Doze testes passaram com
uma observação real e transportes fixture explicitamente separados. A8/C11/B
não ganharam automaticamente esse consumidor; proveniência de fonte e nova
unidade de uso continuam campos distintos. As 87 entradas fora do vínculo
não são omitidas, e os 13 vínculos não equivalem a 13 estados aprovados.

Vínculo de reutilização implementado em módulo separado, em testes: não ampliar
silenciosamente o inspector estático v2 para renomear unidade/fragmento original.
Treze usos podem apontar para onze PNGs existentes, mantendo duas linhagens.
u044/u045 são retomadas da observação door-0/reply-0, nunca da inferência Fear.
Preflight de todos os documentos de direitos antecede decode; o avaliador LIVE
existente continua obrigatório e suas dependências são reconferidas ao final.
O resultado deste contrato não concede tempo, publicity, admissão ou publicação.

Correção do snapshot de manutenção: 14/14 contraprovas passaram em 0,251 s
(terminal 3b5ddb), além de 45/45 testes afetados de protocolo/processo em
9,839 s (terminal 1fa8d9). Captura real read-only às 21:24:07.842875Z confirmou
PID vivo, HELD e lease válido; identificou OAUTH_RUNTIME_CAPABILITY_BINDING_MISMATCH.
Correção da interpretação inicial: esse código compara hash/caminho/expiração
do token com a capability, NÃO o hash do protocolo. A hipótese inicial de causa
por versão antiga do código foi rejeitada na leitura das linhas 534–539. A
capability das 21:25:09Z já registra nova expiração 22:23:28Z; uma observação
durante rotação pode bloquear conservadoramente. Não atribuir causa temporal
específica sem os snapshots do instante. Não editar tokens ou capability para
aprovar o resultado; a instalação continua pelo protocolo seguro existente.

Manutenção 94c3c90d: conservar separadamente regressão PASS (1.418 PASS/1 skip)
e fechamento FAIL por MANAGER_LOCK_LEASE_NOT_VALID. Auditoria independente
confirmou duas corridas no código: relógio capturado antes da inspeção e leitura
posterior do heartbeat; JSON e SHA obtidos de gerações potencialmente distintas.
O receipt histórico não contém os bytes do lock, portanto o instante específico
da rotação não é demonstrável retrospectivamente. Corrigir pela captura de um
único buffer antes do relógio de observação, sem aceitar heartbeat futuro ou
lease vencido. `now` explícito continua sendo o relógio completo da fixture;
todos os cutoffs mantêm esse mesmo marco. Não promover o receipt FAIL após
observar um heartbeat saudável posterior, nem chamar D116 intermediário de
manutenção concluída. O parâmetro deadline do snapshot OAuth não constitui,
por si só, prova de proteção temporal; esta correção não amplia essa alegação.

Contraprova integral1b05273b permanece FAIL(1.416PASS/2FAIL/1skip). Corrigir
fixtures, não o produto: o schemaB1.1 acrescentou três patterns que precisam
receber as mesmas contraprovas de tipos, total14; a fixture isolada de PNG não
tem escopo integral e deve observar o bloqueio de população anterior à leitura
de calibração, não uma falsa completude para alcançar outro erro. Três focais
passaram em0,984s, receipte251260f…; manter o registroFAIL e executar manutenção
segura seguinte. Recuperação5292→18260 sem erro não transforma a tentativa emPASS.

Auditoria temporal read-only confirmou ausência de gold aplicável e população
insuficiente. Contrato atual só admite RECONCILED_NARRATION_UNIT entre51, com
voz/velocidade iguais e fora da união26; restam23. Corpus suplementar requer
origem nova verificável e no mínimo7enunciados adicionais se todos23forem
elegíveis; as30referências inteiras ainda exigem anotação independente real.
Não gerar7WAVs nem ampliar schema por si só como se suprissem essa referência.
Gold de mineração/ASR, PocketSphinx sem calibração e DNSMOS não satisfazem esse
requisito. A policy658 permanece histórica, incluindo o pin antigo do adapter.
Preservar30/100%/800samples como desenho pré-registrado, sem alegar precisão
medida, descartar erros ou reduzir mínimo. Não transferir escuta rotineira ao
proprietário nem declarar dados inexistentes; a fonte independente é lacuna real.

A8/schema1.7 dissocia população literal de agendamento: a união26 agora é
recomposta do plano visualv2+caption71, sem usar rótulos de completude como prova.
Ela permite avaliar elegibilidade de evidência temporal; não concede evidência
LIVE nem composição dos100estados. Guard explícito mantém o agregado bloqueado.
Requirements/cues oferecidos têm classe e intervalos literais checados antes da
abertura temporal; os11estados estáticos não podem mudar de sentido por rótulo.
Os25não lexicais, versões anteriores e fontes estão preservados. Codecs/fontes,
direitos/publicity, precisão temporal e percepção continuam gates independentes.
RealA8a944a4f5…/4,297s e focaisdfbeebc0…/15PASS comprovam apenas esta integração.
C11/schema1.10/adapterv7 evoluídos com backups hash-conferidos; B acrescenta
somente dispatch de tipo1.7. Primeiro comando focal desta rodada foi rejeitado
na descoberta, antes de executar casos, por nome de classe incorreto que gerou
identidades repetidas de _FailedTest; corrigida a seleção, não o produto. Não
contabilizar essa rejeição como testePASS ou ocultar a ocorrência.

O próximo bloqueio não será resolvido com agendamento inventado: plano visual
literal independente descreve51unidades/90fragmentos/100estados, enquanto fontes
e tempos continuam pendentes. As15unidades com antiga descrição genérica foram
resolvidas por estados concretos; as25negativasD169 e os alvos anteriores foram
preservados. A revisão separada identificou a discrepância de u029Choose/Complete;
documentosv2 corrigidos preservamv1. Não promover legibilidade, moving clips,
variedade, fontes, sincronização ou qualidade do vídeo pela existência desse
plano. Novo leitor somente pode reconhecer a versão literal exata sob hash.

A integração cap71 foi versionada em A7/schema1.6: fonte opcional sob CORE9,
binding exato do plano v2 e quatro dependências reabertas. Recontar ranges não
autoriza substituir a segmentação congelada003/016/031. Os17IDs lexicais entram
na exclusão antes de qualquer consumo de calibração;34cues integrais conservam
bounds de contêiner, não onset de palavra. Nenhum tempo é inferido pelo adapter.
A7 calcula cobertura literal das captions independentemente de agendamento,
mas conserva o guard visual anterior e emite TEMPORAL_CAPTION_SCHEDULE_INCOMPLETE
quando os cues reais faltam. Ausência de alinhamentos requisitados não produz
sucesso por vacuidade. C10/adapterv6 e B reconhecem a nova versão sem ampliar
autoridade. Backups prévios em before-caption-intent/; A6 intacta. RealA7
receipte0e3a53c… comprova somente a nova integração literal,4,594s; não reduz
o mínimo26D169 nem transforma21declarações parciais em união global.

O lote congelado70casos teve69PASS/1FAIL e o caso de parser foi corrigido na
fixture, não no guard produtivo: JSON temporal só deve ser lido quando o escopo
é completo. Reteste1PASS e suíteC9 setePASS, com receipts/tempos emSTATE. O
plano literal71cues deve agora entrar como fonte própria semtempo; usar null como
zero ou gerar timestamps só para habilitar a calibração criaria circularidade.
Também não se pode promover a mera quantização da proposta de pausas: nem ela
atinge a banda(204.900ms calculados versus207.800ms mínimos) e não é áudio aprovado.

O build real A6 terminou em6,422s com receipt09858928…: onze fontes lidas,
quatro alvos declarados e51exclusões conservadoras, escopo incompleto e nenhuma
evidência temporal consumida. O mínimo histórico26 continua preso à decisão
D169. Esse resultado comprova o bloqueio correto do plano parcial, não aprovação
do audiovisual. Reutilizar esse artefato enquanto suas entradas estiverem iguais.

O ajuste localizado do teste de schema legado em `test_phase6_av_timeline.py`
não teve backup anterior à edição root. Seu predecessor foi depois reconstituído
somente pelo inverso do patch conhecido, em `reconstructed-before-scope-fixture/`,
e conferido contra o pin do focal86f2dcee…: SHA
474b8e2707507b32a9833191521b70142c33c5f002aa7ea67957208489def3fa.
Isso recupera os bytes exatos, mas não será descrito como backup prévio.

Revisão independente encontrou uma falha antes da compilação do novo bundle:
`_temporal_target_units` considera apenas eventos/captions fornecidos, enquanto
o resultado A5 os chama de união inteira. Com onze estados de quatro unidades
e arrays ainda vazios, isso produziria4, não o mínimo histórico26 ou escopo
global concluído. Os blockers de mídia impediam admissão, mas não eram prova
suficiente para o caminho de calibração. Corrigir o cálculo/consumo em A6, sem
reduzir a policy ou inventar eventos. Separar declared, unknown, conservative e
scope_complete calculado. Ausência de coleção não significa ausência de alvo;
calibração não é consumida enquanto o escopo continuar parcial. Preservar A5,
C8, adapterv4 e testes em `before-scope-completeness/`, todos hash-conferidos.

Registro real das onze decisões encerrado em03fbe140…, SHA36857c5b…;22documentos
e11provas independentes consumidos pelo teste real de B. A classificação OWNED
se limita à origem controlada de composições próprias e uso rasterizado; revisão
automatizada não é autoria humana, exclusividade jurídica ou clearance publicity.
1teste integra as11fontes reais+10contratosunitários:11/11PASS em9,359s. Esse lote
não pode ser promovido a B integral/produção pelo número de testes ou presença
de direitos. Fonte estática tem1frame; seleção temporal, capacidade, mídia final
e todos os gates permanecem independentes. Preservar registrosem rerender/ASR.

Contraprova de integração identificada antes de qualquer registro LIVE: A usa
hash JSON compacto (`canonical_sha`), enquanto o inspector usa JSON indentado
com newline em seu ID e serialização. Prefixar um hash não os torna equivalentes.
Direitosv2 preserva o hash serializado anterior e acrescenta campo explícito
`timeline_canonical_sha256`, prendendo também o módulo desse cálculo. B consome
somente esse campo para o vínculo A. Teste precisa cruzar o objeto real de
inspeção, não dois hashes sintéticos iguais. A afirmação intermediária de
equivalência das serializações estava errada; não houve publicação/registro
LIVE sob esse vínculo. Cópias das versões anteriores e provas focais preservadas.

B passa a distinguir direitos1.0(vídeo) e1.1(tipado). Cada PNG exige proveniência
de composição própria e decisão editorial externa hash-bound, com PNG/SVG,
receita, fontes de texto, geração, fonte tipográfica e nota primária reabertos.
`RIGHTS_BINDING_ONLY` não aprova publicity, humano gold, vídeo ou render. O pool
e auditoria de residência anteriores continuam obrigatórios; imagens não recebem
milissegundos nem safe_ranges de vídeo. A rechecagem final de B conserva apenas
proofs realmente produzidos na chamada e fecha a janela de alteração dos arquivos.

O materializador da decisão D171 teve gap de replay detectado antes do commit:
pins de dependências não reconstituem significado, contagem ou associação de
um receipt serializado. A rota foi corrigida para exigir envelope/11estados
exatos e chamar o verificador independente de direitos; chama-se
INDEPENDENT_RIGHTS_REVERIFICATION, não EXACT_CACHE_REPLAY. Não adicionar um
segundo verificador de cache improvisado nem declarar a simples espera como
fallback executado. Primeira versão preservada; nenhum direito LIVE criado por ela.

Escolha técnica: aproveitar as duas famílias próprias já verificadas, sem novo
raster. Os seis estados de exemplos de medo e os cinco estados de critérios
entram por receitas allowlisted e inspector independente read-only. Cada PNG
tem exatamente uma imagem, dimensões/mode/opacidade medidos e linhagem própria
da família. Não se atribuem FPS ou duração à fonte; A controla o hold de saída.

Intenção1.2 exige media_kind e static_source. A5/schema1.4 vincula a inspeção,
mantém estados completos/ordenados por unidade e preserva os sete alvos lexicais.
Entrada não agendada permanece na união conservadora; nunca vira exclusão de
holdout ou onset observado. Faltam eventos/calibração: A continua incompleto.
Revisão encontrou lançamento prematuro de erro por UNIT_BOUNDARY sem agenda;
corrigido somente no novo contrato estático, sem mudar a exclusão D159.

C8/schema1.7 compila entrada de imagem com loop limitado por frames de saída,
filtro próprio e -n; mantém o caminho VIDEO_CFR sem time stretch. Revisão trocou
inspeção repetida por span por batch dentro da chamada, sem cache persistente.
Fonte/timeline continuam recompostas por pins externos. Blueprint fixture e
grafo de comandos não concedem execução LIVE, B, áudio, QA ou publicação.
Adapter de duas colunas v4 prende A5 e conserva limites e provas de clean plate.
Versões anteriores foram copiadas byte a byte antes da evolução.

Pillow somente por nome/versão foi considerado insuficiente: prender também
os arquivos reais do decoder e rechecá-los antes de decodificar e ao final.
A fonte Arial do Windows possui dois hardlinks de sistema; a exceção é somente
o arquivo externo exato com hash fixo, nunca mídia, diretório ou path de receipt.

Primeiro focal intermediário:42 casos,3 erros,178,016s, sem aceite. O relatório
extenso do jsonschema foi truncado pelo terminal; conservar esse resultado e
não atribuir causalidade a erros cujo traceback não foi recuperado. Fixtures
legadas identificadas carregavam campos/dependências de A5; a correção remove
somente esses campos no cenário sintético que testa o schema anterior. Novo
runner focal guarda identidades, mensagens limitadas, pins antes/depois e falha
quando o código muda durante a execução. Não é substituto da regressão integral.

Sem redução de gates, tolerância temporal, reserva de disco ou qualidade. B e
QA de holds ainda precisam de integração própria; a atual falha por ausência
de duração de vídeo em PNG não será resolvida inventando uma duração. Custo
técnico adicional R$0,00; nenhum uso pago, render, inferência ou publicação.

## D-170 — fallbacks por domínio com autoridade e qualidade preservadas

Após o deploy, nova consulta nativa17:26:46UTC registrou9%usados/91%restantes,
renovação14/09 13:11:15UTC, saldo2500 inalterado e1reset não consumido. Fonte
sanitizada `account-20260907T172646Z-post-d170.json`; decisão21448c293c3f957d
schema-validada, sem rebase de âncora. AHEAD_OF_PLAN4,334807pp exige somente
caminho crítico em qualidade integral;81pp acima da reserva/6,822558dias é conta
de planejamento, não disponibilidade garantida ou previsão por tarefa. A primeira
invocação inline tinha parêntese excedente e falhou antes de executar; a chamada
corrigida materializou uma única observação, sem nova consulta/reset/compra.

Fechamento verificado em 07/09/2026 17:22:03 UTC: manutenção9b618b19 PASS,
SHA f3f80ac1fb0d09e7fd7bfed7bc5877030026dd5023859597e990d79ef02a9b1c;
regressão6d1a8a5b SHA f22b555e9008d6224d27845a15bb565e1368711580183ea95617ee863f5d8819.
1.293 casos descobertos/executados em113arquivos:1.292PASS/1skipWinError1314,
zero falha/erro;170schemas;554itens/3.080.086.312bytes. Unittest1192,355s e
processo1200,796141s são medidas distintas, não durações intercambiáveis.
Run2f7de15f FAIL permanece histórico; correção não apaga contraprova.

D116321a0845… SHA6c82e0307260216cf874d4f40c4e4e5df45ef038f9f6d96172f60a7f5d05cdca
comprovou recuperação14280→5292 e ciclo novoefb94ca0… com12/12/zero blocker de
execução. Snapshots de fila/quota/efeitos/OAuth permaneceram iguais. Snapshot
executivo1.5 SHA9f4eb4898b2500067f18170146ea7382b6fe4bf6b17d42aaef27c2f7e825804a
contém cobertura20/17, SHA9cda6fc56b8537468c0b6323f64a569fa5536640fffe5d5e572c51110fe75854.
As20fontes foram localizadas; somente3EXACT_CACHE_REPLAY/8CHECKPOINT_RECOVERY/
3RETRY_SAME_PROVIDER/3DEFER/3BLOCKED, sem PROVIDER_SWITCH validado. Nem mapa,
regressão, runtime ou ciclo concedem aprovação ao Vídeo2 ou fecham GC-01/Fase6.
Não repetir essa manutenção enquanto fontes/contratos permanecerem intactos.

Correção do supervisor concluída, v2 com job nomeado exclusivo e identidade só no
ambiente do filho. Colisão não altera o objeto existente nem cria processo. O
worker confirma associação explícita, QUERY não herdável, flags e dois tetos
exatos; fecha o handle antes de medir. A falha de fechamento bloqueia medição e
commit. O pai conserva término da árvore e zero processos verificado. Root ajustou
somente a precisão do receipt: kill_on_close false quando a configuração não foi
aplicada; não é novo relaxamento. Código final fb645ace63ac88db00a7f34b63b18b3c50b6c6fd4f185df45dfdfec4f68efe08;
testes c7d851312394a8f1f9254a77da3e0b3843fc897b38a63631d982e3ec1684820c.
Receipt d611672e5269ae19c6685ae1084f743e279fb23e67ffd4fb74dbe994dbb6b859
preserva v1 e a falha, registrando 24 PASS/10,405s, 2 novos PASS/0,018s e
2 retestes PASS/0,483s separadamente. Focais pelo venv real; nenhuma inferência,
render ou rede. Revisão independente do guard e principal do delta encerradas.
Novo lote integral será a prova conjunta, não a soma de terminais anteriores.

Fixture de runway corrigida e revisada:15/15PASS/0,730s via
`.venv/Scripts/python.exe -B -m unittest tests.test_codex_runway -v`, terminal40b32b.
O helper abre policy pré-reset e observação histórica com pins próprios; não lê
configuração viva. Escrita atômica em raiz temporária exige1.2/ON_PLAN/558319s e
depoisAHEAD_OF_PLAN. Contraprova anterior à âncora permanece erro; rebase sintético
não modifica fixture/policy do proprietário. SHA do teste58da355839c085e6597c8973b2f0e4f3f0382e2b7b02c4ea8904a71c25f952cc.

A falha sonora foi reproduzida no venv(2/2FAIL,be89e8). Comparação read-only dos
jobs em filhos contidos: Python base retorna flags0x2300/tetos2GiB; launchervenv
consulta jobimediato0x3000/tetos0. Isso confirma causa do guard, não aprovação da
mídia. [QueryInformationJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-queryinformationjobobject)
consulta o jobimediato quando recebeNULL. Novo contrato usará referência explícita,
membership verificada, acesso somenteQUERY e fechamento antes da medição; não
relaxarflags/tetos ou permitir execução sem contenção. V1 e contraprova preservados
em `output/qa/phase6/diagnostics/audio-supervision-v2/`.

Contraprova de instalação: a regressão do run2f7de15f terminou1282casos em1191,112s
com1271PASS,5FAIL,5ERROR e1skip. Logstderr SHA
727411babcf39dc5805646a12b657d1fb3f0b5bd6a2b725b4c3a3c9c6e5499fa;
recovery-outcome SHA f459148db6f13ba58f0ab7ffd3cb438e70954150f73faa6e7b5eda894884c5c2.
`recovery_failure=null`, cadeia antiga ausente comprovada e Gestor recuperado
PID14280. Manutenção não aprovada, sem receiptfinalPASS, sem declarar D116 novo.
Oito casos de runway dependiam da policy viva reancorada depois do reset legítimo,
mas forneciam datas de06/09; fixtures deverão ser independentes da conta atual.
Dois casos do worker falham na verificação das flags do Job Object sob o launcher
venv; conter árvore e consultar o job efetivamente atribuído são provas distintas.
Não remover flags/tetos ou chamar essa divergência de skip. Reproduzir/corrigir
somente os pontos falhos antes de uma nova regressão estável. O comando de busca
rg com âncora de fim não encontrou os FAILs no logCRLF; Select-String confirmou-os.
A ausência naquela busca não era prova de suíte verde; o resultado terminal rege.

Compatibilidade do fallback de quota corrigida: observer1.0 emitia legitimamente
QUOTA_WAIT, mas os schemas consumidores de trajetória/painel o rejeitavam.
Acrescentado somente esse valor às duas enums, mantendo trajetória1.3/painel1.5,
campos, demais constraints e decisões. Cinco testes exercitam o fluxo real
observer→trajetória→painel com quota desconhecida/esgotada, sem API, publicação,
contagem inventada ou novo job no replay. Snapshots dos schemas anteriores
preservam a contraprova. A espera por quota não vira falha operacional fictícia.

Evolução de fontes compartilhadas registrada com hashes exatos de
`hero_engine/mining/pipeline.py` e `tests/test_mining_phase2.py`. Receipt anterior
9cf3f44c… preservado no backup D170; manifesto de integridade Fase2 não refeito.
Testes históricos usam run/manifests pinados, enquanto novos testes exercitam
`mine()` sem providers. Corrupção COMPLETE retorna CACHE_INTEGRITY_BLOCKED;
parcial/FAILED/RUNNING sem prova retorna CACHE_RECOVERY_PROOF_REQUIRED, preservado.
Removido somente ramo de retomada tornado inalcançável na nova versão; original
congelado. Não afirmar que retomada parcial não pinada continua disponível.

Commons: Retry-After segundos/data com fechamento antes de espera, quatro tentativas
e30s cumulativos de espera por requisição lógica; DEFER interrompe o build corrente.
Não é cooldown persistente, deadline total de rede ou provedor alternativo.

Implementação transversal do painel: schema1.5 com cobertura recalculada em leitura
local, sem executar handlers ou criar estágio extra. SOURCE_BOUND não é teste ou
capacidade ativa. A revisão independente corrigiu referência de restauração para
`scripts/daily.ps1` e identificou aceitação incorreta de cache vazio no miner de
fixtures; esse reparo entra no mesmo lote de manutenção. Miner de fixtures não é
mineração contínua de mercado. Controles criativos, áudio, fontes e A–D não mudam.

Testes focais do painel detectaram três expectativas de versão antigas e uma
fixture1.1 que herdava o campo novo. Corrigidas somente as projeções/versionamento
dessas fixtures, mantendo esquema antigo sem fallback e exigência1.5 com fallback;
nenhum gate enfraquecido. Nova fonte de cobertura é observabilidade, não prova de
execução ou promover fase. Inspeção cache de segmentos reutiliza cada hash uma vez
por passagem e mantém as rechecagens posteriores independentes.

O proprietário pediu fallbacks na operação inteira. A auditoria encontrou recuperação real já existente de OAuth, fila, observações, upload privado, legendas, cache e checkpoint, mas não segundo provedor validado para toda função. Registro textual de fallback em zero_cost_guard não é despacho implementado. Cada rota deve expor tipo, gatilho, orçamento de tentativas, prazo, elegibilidade, qualidade, origem/identidade, evidência e resultado; não contar espera ou bloqueio como sucesso alternativo.

Primeiras correções integradas selecionadas por risco e retrabalho: cache de segmento ausente deve ser recuperado pela âncora/receipt imutáveis antes de qualquer rerender; divergência não pode provocar overwrite de saída pinada. Observador diário de inscritos usava transporte sem deadline explícito; reutilizar helperGoogle existente para retornar ao retry30min/6h/12, preservando uma unidade de quota por tentativa e sem retry transparente. As demais superfícies entram no mapa de cobertura real, não em promessa de capacidade ainda não testada.

Nova observação nativa de cota:97%restantes,1resetremanescente, nenhum resgate/compra. Renovação retornada14/09 13:11:15UTC,30s após a observação anterior. Mantida decisão intermediáriaa9bc3689c1c5c680 REBASE_REQUIRED; policy anterior preservada em `policy-history/before-native-renewal-30s-20260907.json`, SHAd3b26eb01d8ee4654988ae1d89e04d48e45ad7645eb020241ac9e242a39a2638. Rebase explícito pela MESMA leitura materializada14:15:03,310080UTC/3%usado, sem fingir nova consulta ou apagar os3%consumidos. Nova decisão7bf5dd32fc90fa78,87pontos acima da reserva/6,95569dias;12,50774pp/dia é teto aritmético, não custo por tarefa nem garantia de continuidade. O último reset continua sem consumo automático autorizado.

## D-169 — intenção visual observada e três exemplos próprios corrigidos

As29unidades antes indefinidas receberam decisões específicas na intenção7375e47825f42b6184deb029, SHA3ce6d7844800c608951f30ae690f0ddfb552fda47143ee74479d9a32c2eebfd4:2hooks preservados,6receitas estruturais existentes,17bordas candidatas ainda sem fontes/contratos integrais e4revelações lexicais novas005/006/007/026. Dez testesPASS0,274s e replay sem novo decode. Quinze snapshots de fontes foram produzidos uma vez para observação estática, não exame de movimento: cartelaOCEAN TODAY/u036, pessoas nos caiaques/u025 e Torre Eiffel/u044 não correspondem ao uso admitido. Paisagens de u005–007 não demonstram porta, mensagem ou manhã. União mínima conhecida26, candidatas possíveis no máximo23; não é união FINAL de A, não selecionar/anotar o cohort antigo30.

Materializada correção concreta do trio005–007: porta fechada; mensagem de saída sem resposta/interface genérica; manhã difícil ilustrada. Dois estados por exemplo, primeiro acontecimento e depois inferência explicitamente atribuída a `Fear says:`. Preservados texto narrado, Bible/paleta/fonte, câmera/escala, duas linhas/até8palavras, área inferior para captions e alvos lexicaisnull. Uma família, não seis vídeos-fontes. Não há pessoas/marcas/contatos/mensagem real inventada e o desenho não é prova de conclusão espiritual.

Primeira geração70521261…/receiptc763366b… foi preservada com código/testes originais em `source-v1-frozen/`. Revisão independente confirmou ambiguidade dos três pontos do telefone com indicador de digitação. Variante1.1 substituiu-os por dois traços abstratos de conteúdo; reutilizou byte a byte quatro PNGs de porta/manhã e rasterizou só dois do telefone. Também corrigiu reuso que aceitava inventário autodeclarado vazio: agora exige pin externo do receipt e13artefatos exatos. SVG referencia fonte local e não é anunciado como pixel-equivalente portátil; PNG pinado é a referência medida.

Geração vigente `output/qa/phase6/diagnostics/fear-examples-design-v1/static-eb8525d749651871f56cafc9/`; receipt076ec5bec965ccc5c294ecd82ac813faf1886343a928dbb3c30d26d45092c434; receita84fd21136522efa10b89900a4fc5f06523396d587b27fa356d83e10c908d914b; testes e706e41cb35d91aadfbd2e3a1e4f157c9266b66caf3b610fb6ea36f11115d005. Quatorze testesPASS0,102s, zero falha/skip; execução2,41519s. Verificação9b8801d688ac14ab8fdb76f09e0f9a8d082798f494a5c1f1f0314d195ed41638:13hashes,3pares com sujeitos idênticos e diferenças confinadas à caixa/texto de inferência,4reusos byte-exatos e replay sem raster. Inspeções original/corrigida realizadas. Não aprova sincronização/movimento/áudio, LIMIT​ED scope, fontes na produção ou publicação; nenhuma mídia AV/fila/runtime foi modificada.

Próxima menor composição existente: u019/take024 e u021/take027 podem derivar geometria de quatro critérios, mas precisam variante SEM marcadores0/4 e2/4, porque a lista de u034 ainda não foi introduzida. Não reutilizar ordinais de outra seção como se fossem progresso narrativo observado. Na integração maior, refazer/validar todos os spans e a união final, sem baixar N por conveniência, mudar narrativa para conservar holdout ou criar suporte de corpus externo sem fonte anotada real elegível.

## D-168 — contenção de áudio testada e divergências reconciliadas

Novo supervisor Windows, SHA5200782600d6aa285800b6fe649b29046303f92441a7bd58e2d2efaced1d049c: Job Object com processo suspenso até atribuição, kill-on-close sem breakaway, teto de memória comprometida por processo/árvore, timeout, logs limitados por polling e recuperação imutável. Dezessete testes PASS, zero skip/falha,6,370713s. Incluem processos reais, neto encerrado,64MiB impedindo alocação256MiB, erro de filho e promoção interrompida. Verificação66633d67357656d3d220dae2673325bb17d95833dcb763b755d6b8a4ba616c90. Cache real195janelas reutilizado sem inferência/rede. Não é garantia de RAM residente, quota rígida de disco ou aprovação sonora; caminho de nova medição não foi repetido sobre o master intacto.

Reconciliação independente de textos capturados:51unidades,282bindings,11testesPASS e8contraprovasPASS. Receipt627cb3398d90f1550416db09d6c95ba51a7a501026a45052e8b9c04670893bc5; verificação c1edcae244b45d2f274e4fc8c9d214c5d8814d3cfb9eb761fc49e8b8c9edb711. Desacordos001/007/013/016 continuam;014/015 antes omitidas divergem somente no contexto.011write/right são homófonos no dicionário pinado. Inserções em fronteira permanecem sem atribuição acústica. Dois contextos do mesmo modelo não geram dois votos; confirmed_voice_errors=null, zero aprovações. Nenhum novo ASR, voz, decodificação ou modificação da copy.

Auditoria da integração: `phase6_quality.py` ainda exige voz1.2por take, captions em quantidade igual aos takes e caminhos BASE históricos. `verify_phase6_quality_evaluation` chama novamente o builder que pode repetir ASR/medições. O sucessor tem51unidades/71cues/90takes: não conectar métricas do stem diagnóstico como se fossem do áudio AAC final. Integração futura deve versionar o consumidor A–D, congelar extração/mixagem/PCM do vídeo exato, separar técnica/inteligibilidade/pronúncia/prosódia/temporalidade/mixagem e usar replay sem inferência. ASR+LUFS não prova AUDIO completo e o gold de mineração não calibra áudio. Não criar novo evaluator sem entrada real apenas para aparentar solução. Módulos auxiliares não foram implantados no runtime e a manutenção histórica não os cobre automaticamente.

## D-167 — continuidade horária sem repetição automática de manutenção

A única heartbeat existente `hero-engine-rotina-di-ria` foi atualizada pelo recurso oficial para retomada horária no mesmo thread; nome e regras anteriores preservados. Backup do contrato anterior em `output/operations/automation-history/hero-engine-before-hourly-20260907.toml`. Read-back confirmou ACTIVE, mesma identidade e nova cadência. Sem tarefa duplicada, nova assinatura, cron alternativo ou despertar do QR Dolar.

A instrução histórica de `scripts/daily.ps1` incondicional não rege cada despertar. Executar a próxima unidade crítica útil, detectar trabalho concorrente, reutilizar provas intactas e realizar manutenção D116 somente quando alterações reais exigirem. Uso de cota consultado somente quando necessário para execução extensa/rebase; reset remanescente não autorizado automaticamente. Silêncio quando estado inalterado, notificação somente material. A retomada depende do computador ligado, aplicativo aberto e projeto disponível, conforme [documentação oficial de tarefas agendadas](https://learn.chatgpt.com/docs/automations?surface=app); não garante execução infinita nem supera gates ou cotas.

## D-166 — resgate autorizado, idempotente e sem compra

A resposta “já autorizei tudo” ocorreu imediatamente após a solicitação específica de um dos dois resets gratuitos; interpretada como autorização desse único resgate, não compra ou resgate recorrente. Ferramenta nativa retornou outcome=reset, chave d7479865-518e-4a72-b1de-1ad1798dd3ef;100%restantes e1resetdisponível. Preservados receipt e observação sem accountId. Não houve retry após sucesso nem segunda consulta redundante de limite.

Renewal mudou para2026-09-14T13:10:45Z; backup byte-conferido da policy8cb45f4d… antes de rebasear a âncora13:11:51Z/0%usado. Decisão schema-validada576f5b798ac3ec08 GREEN/ON_PLAN,90pontosacimadareserva, teto aritmético12,858546pp/dia/0,535773pp/hora. Teto não prevê custo por tarefa ou execução contínua garantida. Modelo/qualidade/custoR$0/reserva10%permanecem. D165/D152 conservados como observações históricas; não bloquear a execução atual por saldo antigo nem autorizar automaticamente o último reset.

## D-165 — continuidade autorizada não dispensa a reserva de capacidade

07/09/2026: o proprietário rejeitou a interrupção após a entrega parcial D164 e reafirmou execução integral. Reconhecida a diferença entre concluir um componente e resolver a operação; nenhuma nova autorização de fase é necessária. A retomada reabriu os contratos ativos e o código de referência temporal, sem alterar seus guards, repetir inferência ou declarar padrão-ouro inexistente.

Nova leitura nativa mostrou91% usados/9% restantes, janela10080min, renovação2026-09-13T02:15:36Z,2resets gratuitos disponíveis e nenhum limite oficialmente esgotado informado. Materialização pelo módulo vigente às13:05:42,930610UTC: `codex-usage-08c002b7b684d875`, CRITICAL_RESERVE. Schema validado pelo materializador; history/latest SHAa537918265644f7d03a807ed798df701c7340de17c223ad972f8340df6b6e5c6. Observação relevante preservada sem accountId em `output/operations/codex-usage/observations/account-20260907-reserve9-native.json`. Não converter saldo2500 ou2resets em percentual disponível, nem resgatar automaticamente.

Aplicação da regra mais restritiva: checkpoint seguro e operação local preservados; solicitar apenas a autorização específica de um reset gratuito para retomar desenvolvimento extenso, sem compra ou downgrade. A ferramenta de objetivo ainda retornou BLOCKED histórico; não declarar ACTIVE por edição documental. A rotina heartbeat existente continua diária/ativa, sem monitor adicional. OpenAI Docs foi usada para verificar o mecanismo de continuidade: [tarefas agendadas](https://learn.chatgpt.com/docs/automations?surface=app), que não substitui cota, gates nem execução testada.

Read-only: tarefa central Running, PID6660/python presente, início de processo03:30:28,0801474UTC e lockHELD com heartbeat13:05:42,701786UTC/leaseaté13:08:42,701786UTC. O instante de aquisição registrado no lock é distinto do início do processo; esta leitura não é nova manutenção D116 nem contraprova completa de cadeia. Nenhum runtime, fila, credencial ou mídia foi alterado; zero publicação ou gasto.

## D-164 — medição perceptual automática com escopo comprovado

Implementado DNSMOS P.835 regular local, modelo/licenças Microsoft na revisão591184a9… e SHA-256 dos seis arquivos. Alterações metodológicas declaradas: FFmpeg SWR e cobertura da cauda; agregação do lattice anterior preservada para comparação, sem alegar benchmark idêntico. Código/testes/schema/verificador próprios; modelo independente do sintetizador. R$0, sem inferência API ou instalação paga.

Master 8e8909fe… preservado; 195 janelas cobrindo202,780s em95,029098s, médias estimadas SIG3,1391/BAK3,8325/OVRL2,8111. Controles sintéticos de ruído, silêncio e hard clipping passaram nos checks específicos. Silêncio ainda teve BAK3,4724, evidenciando que componente MOS isolado não é gate suficiente. Não usar esses números como opinião humana, defeito comprovado, retenção ou aceite.

16 testes focais PASS (3bb7d0) e14 verificações de receipt real PASS (120706), sem reinferência; schema d3ad542d…, receipt ca771052…, verificação20bf33c4…. Falhas iniciais da constante esperada de teste e sintaxe do verificador registradas no relatório, corrigidas sem alterar o modelo, a tolerância ou a mídia. Não repetir regressão histórica D116 nem alegar que ela abrangeu o novo componente. Gate diagnóstico integral continua BLOCKED_CAPABILITY_GAP; runtime produtivo e cadeia A–D intactos. Pronúncia/prosódia/referências temporais/validação de domínio e integração não são resolvidas por este incremento nem transferidas ao proprietário como escuta rotineira. Detalhamento e critérios verificáveis em `docs/AUDIO_AUTONOMO_ESTADO_2026-09-07.md`.

## Correção de responsabilidade — avaliação sonora autônoma

07/09: o proprietário rejeitou executar a escuta e reafirmou que essa capacidade pertence ao sistema. Retirar a solicitação de escuta rotineira como próximo passo operacional. A insuficiência do avaliador deve ser tratada como implementação/validação interna; isso não fornece referência humana nem autoriza alterar os gates de calibração, temporalidade, qualidade ou direitos.

Auditoria do código: `phase6_quality.py` deriva AUDIO de ASR e LUFS/true-peak/LRA; isso não mede integralmente naturalidade, prosódia ou pronúncia. Primeira ampliação: DNSMOS P.835 local como estimativa auxiliar independente do gerador, não aprovação perceptual absoluta. A documentação oficial o apresenta como proxy de avaliações humanas para supressão de ruído: [Microsoft DNSMOS](https://github.com/microsoft/DNS-Challenge/blob/591184a9fcb2cbdec02520fed81a32bbbf9d73ff/DNSMOS/README.md). Código MIT; demais conteúdos CC BY 4.0 conforme declaração/licenças da revisão pinada. Preservar atribuição e não alegar endosso. Pesos NISQA CC BY-NC-SA 4.0 rejeitados para este projeto comercial, sem instalação.

## Bloqueio do objetivo por evidência sonora — 07/09/2026 04:35 UTC

A composição u034 resolve apenas um insumo visual. O verificador A continua exigindo referência temporal independente aplicável; os argumentos produtivos continuam sem bindings, policy, eventos ou spans. O pacote sonoro permanece sem revisão. Revalidação 51032c/a59f4e, após os checkpoints 04:12 e 04:23 com a mesma dependência. Registrar BLOCKED pela ferramenta de objetivo, sem marcar fase concluída, parar runtime ou afirmar que a implementação interna terminou.

Separar dois trabalhos: a escuta do master pode ser realizada agora; a anotação temporal não deve começar com o cohort/policy de 30 incompatíveis. A correção dessa preparação permanece responsabilidade interna, seguida de evidência temporal genuína. Autorizações, oito testes de desenho, ASR, níveis de loudness e offsets de caracteres não são substitutos para essa evidência. O objetivo integral e o próximo caminho técnico permanecem preservados.

## Direção específica u034 — quatro estados, duas linhas, uma linhagem

07/09/2026 04:23 UTC: a correção de takes051–054 materializa quatro critérios nomeados dentro do passo TEST. Escolhido painel estável com um critério por vez, em vez de quatro cartões simultâneos, para preservar a regra de duas linhas e não confundir os quatro critérios com os três movimentos do método. Cabeçalho literal `Test the meaning`; corpo `Truth`, `Character`, `Consequences`, `Wise counsel`; case conforme Bible. Marcadores sem texto indicam posição na sequência, não resultados ou aprovações. Não apresentar todos os critérios antecipadamente nem usar três cartões vazios como prova literal de quatro conceitos.

Receita local própria e cinco estados reais; fonte Arial Bold existente pinada, sem download ou distribuição de arquivo de fonte. A cena mantém margens, paleta, posições e faixa inferior reservada. Esse espaço geométrico não valida as captions finais. Os triggers lexicais ficam sem samples/frames até calibração aplicável; o estado introdutório também não possui tempo inventado. O protótipo não é registrado como fonte admitida ou capacidade produtiva.

Receipt SHA `2b0b541bbbeacf9b7c62d6dbe85bd34ac789b0e7da96d86e1f0ce49a76a7415f`; receita SHA `ea2000c544bcf8e934509296574510ba20af920d1956e2a4fb84c003314edb11`; testes SHA `0a8b05099ba9adc0207758c3af04fb1f4e97f657a4aad4a05426441f421ab180`. Oito focais PASS e contraprova dos bytes/probes/reuso PASS. Evidência estática apenas: não se alegam retenção melhor, prontidão jurídica ou movimento aprovado. A comparação observa correspondência literal ausente nas fontes inspecionadas anteriormente; o vídeo completo anterior não foi reavaliado ou reclassificado.

## Aplicação D-152 e inspeção de fontes — 07/09/2026 04:12 UTC

Observação oficial `codex-usage-b3802cd962ba419d`, SHA `32468b0f5fed9b04e78b6ecb02f3923eb2ab567e2f5bd853288cc21605fb1d7a`: 10% restantes, zero ponto acima da reserva, renovação 12/09 23:15:36 BRT. Schema/twin PASS, terminal 7fe086. Encerrar o checkpoint seguro sem novo fan-out, inferência, render, regressão intacta, reset ou compra. Preservar o modelo e o runtime local. Não alegar capacidade infinita ou transformar reserva de planejamento em falha oficial de serviço.

Foram visualizados os seguintes PNGs existentes em `output/production/phase5/pilot-001/creative-v3/assets/`; hashes reconferidos no terminal 31fd33:

| Fonte | SHA-256 | Observação limitada à imagem estática |
|---|---|---|
| `scriptural-mechanism-original-v1.png` | `9034571c628172ece0c311a2e227c34408703b83944f3752d00000a666979c20` | Livro aberto, caderno e três cartões sem texto; a impressão pequena do livro não é legível nesta inspeção. |
| `action-plan-original-v1.png` | `bce6782cbbceb80247cf9d8b8615072668558d363e90f62d25fd9e25ab9ebb0f` | Três cartões sem texto, telefone, caderno, seta e relógio; não contém os critérios escritos. |
| `three-card-decision-original-v1.png` | `75805af113aafbe62f3dac3aa5b5b3dab1c8ea3259e199ca2ab30ba18c90edc4` | Três cartões sem texto e mão segurando o cartão central; uma imagem não prova movimento. |

Decisão: essas fontes não bastam como evidência de revelação temporal ou de correspondência literal das listas narradas. Não renomear três cartões como quatro critérios ou cinco categorias de apoio; composição apropriada ainda precisa existir e ser avaliada. Esta observação reforça D-137, sem criar outro gate ou reclassificar o baseline rejeitado. Não fecha a união final, não aprova publicity/movimento/direitos ou o vídeo final, e não justifica repetir renders existentes. Foram apenas leituras; nenhuma mídia foi criada ou modificada.

## Aplicação D-163 — rejeitar a seleção parcial antes de anotação

Audit3a6aa9e15887bd7998b2bc3d cobre literalmente51unidades/90takes/71cues e registra decisões editoriais adicionais para020,034,041: contraste true/possible, quatro critérios deTEST e cinco categorias de apoio. O vínculo de texto/takes/fontes histórico é observado; a necessidade de sincronizar esses contrastes/listas é decisão editorial explícita. Nenhum conteúdo visual ou instante acústico foi declarado observado. Não é regra automática sobre toda fragmentação.

Esses três alvos estavam no cohort30; com17alvos de captions e011/012já conhecidos, há pelo menos22unidades a excluir. Restam no máximo27candidatas da velocidade1,06. Preservar a policy de mínimo30 como incompatível com o novo escopo, sem alterar seu conteúdo, reduzir o rigor pós-resultado ou mudar narrativa para fazê-la caber. Nenhuma anotação/inferência foi feita, portanto o erro de seleção foi detectado antes de consumir esse trabalho.

O restante da intenção visual continua aberto; número27 é teto, não amostra aprovada ou união final. Dados e comando reproduzível em `output/qa/phase6/diagnostics/temporal-scope-audit-3a6aa9e15887bd7998b2bc3d.json` (SHA6ba997f4d6d72fff549861abd3e5e4c50193cdfb39898d6d45aedb8b5ad489fe) e `temporal-scope-conflict-v1-execution.json` (SHA1acc3764e9bbfc9e5a2fc518a1eb0cc0bf44ded67e41b4e9a8768311f7079a32). Nenhum gateA–D, qualidade ou publicação passa por esta auditoria; não reiniciar manutenção/testes/mídia intactos.

## D-163 — Pré-registro temporal não equivale a calibração nem cohort final

07/09/2026 03:47:45UTC: registrar policy6587e640… para o perfil PocketSphinx5.0.4/adapterv1/swr32, am_onyx/en-US/24kHz. Critério de ensaio:30referências únicas, cobertura100% e erro máximo800samples, correspondente a um frame30fps. É alvo de engenharia definido antes das estimativas, não precisão observada ou limite permanente. Qualquer falha fica preservada; não flexibilizar após ver resultados para promover o mesmo candidato.

Seleção reproduzida das fontes existentes:51unidades,17alvos de captions internas mais011/012lexicais, duas velocidades incompatíveis;30candidatos de mesma velocidade,87,637333s. Solicitar uma borda lexical porPCM, token mediano literal, START/END alternados por ordinal, sem olhar estimativas;15/15. Cada linha conserva origem, sample_rate, frames, voz e identidade de síntese; campos de observação ficamnull. Não excluir unidade ambígua silenciosamente para melhorar a métrica. Full-master listening permanece distinto.

A seleção é **provisória quanto à união total de alvos**, porque os eventos do restante do vídeo não estão integralmente recompostos. Não chamar de holdout aprovado ou solicitar anotação antes de fechar essa união. Sobreposição posterior exige revisão/pré-registro antes de estimar; narrativa/legibilidade não podem ser degradadas para encaixar o cohort. A policyA e o runner aceitaram o contrato, mas zeroobservações continua reprovando calibração. Prova com nove verificações e comando exato: `output/qa/phase6/diagnostics/temporal-calibration-preparation-v1-result.json`.

Nenhuma inferência, fonte nova, anotação, release, alteração de runtime ou custo foi produzida. PolicySHA196addf074504958b4d54c7e30a6062fc4d231a47de0886fede2a813cb73c6e8, cohortSHA304e3253dab5439d3baa233f66817359b4cc795e4ff731956a6f59ab2c576b7e e pedidoSHA754382d1e9f2fd25dfe383f373baa7d927d3bd2539781d417aeef6efeb3a0c79. Este incremento prepara um insumo concreto; não fechaA,GC-01,Fase6 ou a dependência externa sonora.

## Evidência de encerramento D-162/D116 — manutenção753a9beb

07/09/2026 03:31UTC: a nova execução sobre os três testes corrigidos terminouPASS, sem alterar código produtivo ou relaxar políticas. Inventário1165 coincide com execução1165:1164PASS/1skip WinError1314 previamente permitido. Unittest1151,386s; comando1159,763714s.169schemas e compileallPASS. Guarda/snapshot estável, recuperação3968→6660, singleton, energia, console e ciclo novo12/12 comprovados; barreiras próprias removidas. Queue, cotas, efeitos e provas OAuth inalterados sob barreira, sem chamada externa/publicação/custo.

Receipt final2.1 `daily-maintenance-20260907T0331116262270Z-477c4f57`, SHAec8a37ac217fc5f34bea4e6e58155abf74d64b7456ac37ce61fa757dcd203e50. D116 `phase6-post-maintenance-173200f3a611d6d7438323a2`, SHAaa5e1cc7f8954528ff6e4bc3434d465f92f6d584832ab373954359e58f35dd85, com cinco snapshots imutáveis hash-conferidos. Fontes de teste antigas e tentativasFAIL preservadas. Relatório focal anteriorSHAc865052fe3d05dc0d7eb2a0f8489d4c4e8cf0a4a5a1e04d5aa8dd4f0491868d6 não foi reescrito para fingir que já continha esta prova posterior.

O aceite real passou a12PASS_LIVE/5PASS_FIXTURE/1WAITING/4fora da fase; GC-01 é o único agregado restante. Decisão: encerrar a pendência de manutenção, não repetir processamento intacto e concentrar a próxima unidade na evidência sonora e no tratamento real. Não declarar Fase6 concluída, vídeo2 pronto, áudio revisado, aprendizado aplicado ou projeto100%. A prioridade noturna não substitui referência anotada independente nem tempo de observação de audiência.

## D-162 — Corrigir isolamento e descoberta de testes sem relaxar produção

A manutenção544baa2e executou1169testes em1067,210s, com9erros/1falha/1skip; recuperou o gestor12748→3968 e liberou as barreiras, mas permaneceuFAIL. Três causas verificadas: referência sintética14000 fora do PCM2400; fixture de previsão herdando `NOT_EVALUABLE_WITHHELD` vivo e apagando seu snapshot obrigatório; importação direta deTestCase repetindo sete casos sob prefixos diferentes. Não são dez defeitos independentes do runtime nem evidência de defeito auditivo.

Alterados somente três arquivos de testes, após cópia/hash em `source-freeze-before-maintenance-fixture-repair-v1`. Separar controles de bounds e aceitação temporal; construir a previsão sintética completa sem ler o observer vivo; importar o módulo de fixture e impedir exportação indevida deTestCase. Três testes de regressão adicionais. Código A/C, schemas, policy, dados e receipts produtivos não foram alterados.

Prova focal29/29PASS64,022s (30555/85c7f1); inventário/descoberta/multiplicidade canônica1165/1165/1165PASS (48863/2a1996). Relatório de hashes/causas `output/qa/phase6/diagnostics/maintenance-fixture-repair-v1.json`. Necessária nova manutenção integral antes de declararD116 concluída. Não produzir gold humano/temporal a partir destes testes ou usar a correção para liberar vídeo2.

## Aplicação D-152 — preservar capacidade restante, 07/09/2026 01:54 UTC

Uma nova leitura oficial informa87%usados/13%restantes. O governador existente materializou `codex-usage-17588c7f443b6963` (schema1.2); latest e histórico possuem SHAae90786bcccc5e8652f459e71f1e3633a74570a234b17ff53aeece160f670a6d. Reserva10 mantém3pontos para6,015dias, teto0,4987531172ponto/dia; âncora preservada, `AHEAD_OF_PLAN`23,0630356481pontos. A data registrada corresponde à materialização da consulta deste heartbeat. Não repetir consulta apenas para atualizar relógio.

Aplicar a restrição já aprovada: fechar checkpoint seguro, adiar desenvolvimento extenso e manutenção integral, sem novos agentes/polling e sem reduzir modelo/qualidade. Não gastar, consumir os2resets automaticamente nem converter saldo2500 em percentual. Só YouTube permanece carga ativa por declaração do proprietário; QR não foi acionado. Tarefa Running e ciclo recente lidos são sinais limitados de atividade, não certificado D116 ou prontidão de produção. O segundo vídeo permanece bloqueado; ausência de nova publicação não será escondida por contagem de testes. Nenhuma regra, gate ou evidência anterior foi apagada.

## D-161 — Fonte tecnicamente verificada ligada à receita, sem promoção de autoridade

07/09/2026 01:45UTC: adicionar verificador puro `phase6-av-clean-plate-verifier-v1`, bodyadapterv3 e C v7/schema1.6. Binding `clean_plate_receipt` é opcional para preservar o caminho anterior bloqueado; quando fornecido, exige receipt/runner fixos e replay completo sem main, lock, escrita ou subprocessos. Código do runner/helper é carregado dos bytes já pinados. Reabre25dependências e confronta canal/Bible/TakePlan, mídia, linhagem, capacidade e intervalos. Não chama novamente FFmpeg, FFprobe, síntese ou ASR.

Separação explícita: `source_technically_verified` só descreve a base verificada; `source_ready=false`, render/publicaçãofalse e grafo integralnull permanecem enquanto os demais contratos não existem. Nenhum segmento da mesma base pode ganhar linhagem fictícia. C faz rechecagem residente, compara tipos inteiros e JSON canônico; float1800.0 não substitui frame_count1800. A exceção de0bytes é exclusiva do stdout vazio do render pinado, nunca de um ativo ou receipt.

Root26/26 body/controles PASS33,990s e14/14 C PASS84,816s; executor8/8 verificador PASS17,863s; revisão separada do body encerrada. Fonte anterior preservada em freeze de5arquivos e receipt da mídia continua SHA25fe4e9047971a8f88d86ce5de07f8ea15b042831ab5fa96b2e277689811ac7a. Relatório `av-clean-plate-binding-v7-root-result.json`, SHA9693a737373b4614ff058d7d096d9a9256907a1194edbafcfea0e545fcbed40c. Receita realb5184c…/SHA9cd642c86a13bd0483339c3d08755ad39d736a6674981adc8de15e98f03b32f0 ainda `BLOCKED_INCOMPLETE`. Testes verdes não aprovam o vídeo.

A próxima prioridade volta à evidência de áudio: auditoria não encontrou gold ou escuta genuína aplicável ainda não ligada. Exigir policy pré-registrada e anotações/escuta reais; o ASR já coletado é apenas possível contraprova secundária. Não resolver a diferença202.780→207.800ms acrescentando silêncio calculado pela meta de duração. Pausas precisam justificativa editorial; qualquer outro tratamento exige versão e escopo próprios. Esta constatação não pede nova autorização geral e não invalida o trabalho pronto. Runtime/deploymentD116 permanece pendência separada; zero efeitos externos nesta unidade.

## D-160 — Fonte própria limpa, uma linhagem e verificação reutilizável

07/09/2026 01:17UTC: materializada uma única base RGB literal `#081827` em FFV1/BGR0, 1920×1080/30fps, 60s. Reutiliza a paleta e a identidade da receita existente, sem áudio, texto, figura ou material externo. É capacidade do ativo, não retiming da narrativa e não contorna a duração editorial pendente. Mantém linhagem `heroverse-owned-clean-plate-081827`; segmentos/duplicatas não viram fontes independentes para o gate de variedade.

Antes do render, revisão separada e inspeção root corrigiram riscos demonstráveis: conversão RGB/YUV, JSON permissivo, arquivo de fixture dentro do namespace fechado e hipótese de ordenação de threads no teste. A proposta inicial de aceitar só três campos do FFprobe foi confrontada com stdout real já arquivado da mesma versão: `programs=[]` e `stream_groups=[]` também são emitidos. Ambos passam apenas como listas literalmente vazias; outros extras, duplicatas, NaN/Inf e streams adicionais bloqueiam. A revisão não exigiu novo probe da mídia antiga.

Runner SHAef0d956239c512d08e5fc9559e676225129fe907f6947c45a6134a678831eec2; testes SHAb968926a222d26e1a5ea4c19e524ad5db3583d2c2d94d84719b39487f33d8879. Root15/15 PASS3,258s, terminal32699c. Efeitos reais foram únicos e journaled: render78,219s, probe1,250s, decode/hash101,875s, todosexit0 e dentro dos limites. São medições locais de etapas, não métrica de qualidade editorial nem previsão de entrega.

Arquivo9.498.584bytes/SHA7031f3abc85881e10e2c8b78875b935fa07705a1844dfbeb98b1513cc7529471. ReceiptSHA25fe4e9047971a8f88d86ce5de07f8ea15b042831ab5fa96b2e277689811ac7a sob `output/qa/phase6/diagnostics/two-column-clean-plate-v1-ef0d956239c512d0`; recomposto em replay com pin externo e Popen proibido, sem processo novo. Rootreport `clean-plate-v1-root-result.json`, SHA8e4bd3eb139a6711288d4480bf37dddcff3b138ac91aa0592c1a5f20e9ace5d5.

O resultado é somente `SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED`. Não registra direitos em produção, não aprova semântica/percepção/movimento do vídeo, não altera timeline nem concede fila/render/publicação. Duração/grade e referências temporais continuam necessárias. Voz/hook/provas anteriores preservados; zeroAPI, gasto, instalação ou reinício. O sucessor deve reutilizar esta fonte, não gerar nova base intacta para aparentar progresso.

## D-159 — Borda estrutural PCM não exige nem substitui alinhamento lexical

Em07/09/2026,00:41UTC, A v4/schema1.3 passa a aceitar intenção visual1.1 com o par estrito `UNIT_BOUNDARY`/`WHOLE_UNIT_PCM_START`. O frame deve coincidir exatamente com `pcm_start_sample/800`, dentro do span que contém o primeiro fragmento da unidade; chars, alignment e incerteza lexical são null. É uma borda do contêiner de áudio, não onset de fonema ou palavra. Intenção1.0 e schemas históricos continuam restritos aos tipos anteriores; histórico estruturalmente legível não é reautorizado pelo verificador atual.

O contrato anterior exigia alinhamento lexical para nove estados que começam em unidades inteiras. Essa exigência não descrevia a operação pretendida. Agora o adapter v2 prende nove pares literais:012:u010,013:u011,015:u012,017:u013,018:u014,019:u015,020:u016,022:u017,023:u018. Exige char inicial0, primeiro take da unidade, frame exato, intenção literal e ausência de disputa entre cronogramas estruturais/lexicais. Take014/016 ainda dependem da palavra `write` e de calibração genuína;021 mantém HOLD contínuo. Não reclassificar revelação interna nem alterar texto/voz para obter PASS.

A união de alvos de calibração só exclui uma borda depois de reconstituir sua instância, unidade, primeiro fragmento e span; rótulo, evento ausente/duplicado ou trigger desconhecido não bastam. Captions e eventos lexicais da mesma unidade continuam no conjunto excluído do holdout. Os controles anteriores de reclassificação, falta de alinhamento e união de holdouts passaram sem alteração do teste legado.

Provas: root33/33 PASS60,095s (74513/123234), incluindo21adapter/5integração real incompleta/7regressõesC; executor12novos PASS13,222s (92300/cec3c1) e3legados PASS19,853s (82082/09fe18). Revisão separada sem novo achado crítico; a pendência de pins foi resolvida com os hashes finais e controles de adulteração. Fontes/schema/testes anteriores copiados e comparados antes das mudanças em `source-freeze-av-before-unit-boundary-v1`. Evidência `av-unit-boundary-v4-root-result.json`, SHA2293e64174cf58d6a20ff9434ba0609cb122afec0b0709c7040ad46b9d4d2d1a; hashes atuais em STATE.

Integração real continua incompleta: receita `phase6-av-render-recipe-cb6c551c8d2e807e4c79b9ea`, SHA234c3571e068b13e546e5efc2eb01d70b7eb5b15559d1cdc3e90923f7a864e9e, sem grafo ou autoridade. O positivo com eventos preenchidos é fixture, não medição do canal. A implementação não registrou intenção produtiva, não resolveu a banda editorial/percepção/clean plate e não publicou. Nenhuma voz, ASR, render, API ou runtime repetido; custo adicionalR$0,00.

## D-158 — Duas colunas derivadas de A, sem relógio histórico ou prontidão fictícia

Em 07/09/2026, 00:20 UTC, integração preparatória encerrada com C v5/schema 1.4 e adapter `phase6-av-two-column-adapter-v1`. Reutiliza a receita visual existente: 12 estados take012–023, 64 textos UTF-8 relativos, tipografia/paleta/colunas/copy preservadas. O layout não serializa `start_ms/end_ms` antigos. Filtros preparados usam frame local `n` somente quando existem eventos A compatíveis; não são efeitos de mídia.

A revisão encontrou e corrigiu quatro riscos antes do render: intenção narrativa diferente no mesmo trecho; HOLD com troca de fonte; span que ultrapassa o exercício; leitura de ativo ligado ou não residente. O evento exige intenção literal e prefixo não vazio iniciado no fragmento, com alinhamento A validado. Take021 só herda o estado020 quando a mesma fonte/span cobre todo o intervalo. O compilador reabre bytes/fontes e o verificador compara JSON canônico. C recompõe A pelos argumentos externos antes do adapter, mantém `source_ready=false`, todas as autoridades falsas e `command_graph=null` com a preparação parcial.

Contraprova real: argumentos e8e6… permanecem o baseline incompleto de 190.800 ms, com zero eventos/spans; não correspondem ao master editorial de 202.780 ms. Resultado `BLOCKED_INCOMPLETE`, receita `phase6-av-render-recipe-55079e0d28837cde170c6975`, SHA canônico 0aa7b17ea3be9fda27f75ae3e82e573f5a5321f37cd2b1f56b59224979682f0f. O spec de corpo é `phase6-av-two-column-spec-0028e24282500f154a681f38`, SHA canônico 76627469fa4c363031ec6b22799625abdb2fe1e07be68a2f88d740211d0a4437. A prova positiva preenchida é explicitamente fixture de conversão, não A verificada ou calibração LIVE.

Testes: root 5/5 integração nova (20,236 s) e 7/7 regressão C (19,731 s); agente 13/13 adapter (11,931 s); revisão separada final sem achado crítico adicional. Evidência e terminais: `output/qa/phase6/diagnostics/av-render-recipe-two-column-v5-root-result.json`, SHA 37c498355ca6123e3517f41b602e3a0e6aab8b3981f1cdf12dac911b6138fe73. C v4/schema/teste anteriores preservados em `source-freeze-av-render-recipe-v4-before-body`. Nenhuma mídia, instalação, API, gasto ou nova publicação; teste aprovado não é vídeo aprovado nem prova de cadência maior.

Lacuna contratual explícita: A suporta PCM de unidade inteira para captions, mas ainda não como evento visual estrutural. Não fabricar 11 alinhamentos nem usar a fixture como solução; a próxima extensão precisa distinguir bordas PCM de revelações internas. u011/u012 ainda exigem temporização lexical real. Clean plate próprio, percepção, duração, admissão, QA e release seguem pendentes. Não reutilizar o MP4 antigo com textos embutidos como imagem-base limpa.

Auditoria operacional independente 00:03–00:07 UTC: processo/cadeia/heartbeat/console/ciclo 12/12 observados vivos, sem lease preso. O FAIL D-116 da manutenção c77 permanece real. A causa GC-21 já está corrigida em disco por D-148 (duas identidades de teste qualificadas), porém PID12748 iniciou antes do patch. Contraprova read-only do inventário histórico retorna true; isso não substitui deployment/reinício seguro e novo receipt D-116. Não reescrever a manutenção antiga nem relaxar a allowlist de bloqueios. A operação continua parcial e a Fase 6 não foi promovida.

## D-157 — A receita audiovisual recompõe a origem, não confia em rótulos

Entrega23:52Z: priorizado mux QA real do hook antes de mais expansão de contratos. Reaproveita o vídeo FFV1 e o master; preserva150packets e slice[72000,192000) de120.000samples, sem nova voz/render. Os94.208samples da unidade003 e25.792samples de pausa foram derivados da montagem arquivada, não de estimativa de palavra. Testes15/15PASS e replay com Popen bloqueado provaram integridade/retomada; receipt edac05303ff94307949f9171f6621c913a49ee1085686f3dbb27d3c63a92fa9c. Áudio PCM idêntico isoladamente não prova sincronismo: o gate também valida PTS0, ordem, clocks e endpoint5s. O resultado permanece QA não aprovado, nunca gold, publicação ou solução integralC. A revisão recomenda replay explícito com hash; repetir processamento intacto não conta como progresso.

Fechamento23:32Z: C v4/schema1.3 integra o adapter editorialv2 real, recompõe150frames e22dependências do take003 e mantém cobertura integral falsa. Nove testes integrados passaram na versão anterior; quatro testes finais passaram38,968s. Comparações dos dois verificadores usam bytes canônicos: `150.0` não é idêntico ao inteiro150 assinado. Controle negativo adicional confirmou a rejeição sem alterar gate, render ou dados. Relatório atual aeb71a0b3889c52fa14ee6c71d5ec10b9a7e05d883994f886d89f3033264be48; arquivos/hashes em STATE. O adapter reutiliza a composição editorial existente, não cria novo vídeo. Todo corpo/two-column continua dependente dos eventosA compatíveis; a prova geométrica do footer não aprova semântica, movimento, publicidade ou qualidade integral.

Em06/09/2026, C v2 passa a reabrir `PHASE6_AV_RAW_ARGUMENTS` pelo contrato existente de admissão e executar o verificadorA real com argumentos independentes do candidato. Ausência mantém blocker; divergência de bytes/schema/identidade/namespace/canal/protocolo/argumentos impede a recompilação. A prova de recomposição completa ou incompleta não concede origemLIVE, admissão, qualidade, namespace, render ou publicação. O código/layout/frame visual não pode promover uma wrapperLIVE a autoridade.

Quatro focais novos e sete regressões passaram; revisão read-only separada sem achado crítico. Contraprova de142fontes reais/51PCM/90fragmentos preserva o baseline190.800ms como incompleto e rejeita combinação com master202.780ms. Evidência e hashes emSTATE. A expectativa inicial de um teste sobre calibração em cues inteiras foi corrigida, não o gate. Não repetir medições encerradas. A próxima ligação visual usa funções puras existentes e cobertura explicitamente parcial; não aceita filtro arbitrário nem reexecuta diagnóstico para produzir evidência equivalente. v1 e v2A congeladas antes de evolução. Custo técnico0 e todas as autoridades falsas.

## D-156 — Entrega incremental de áudio sem ressíntese nem correção por falso positivo

Fechamento22:55Z: contraprova separada do master concluiu40bindings/26arquivos/cinco terminais e PCM completo, sem repetição de processamento; níveis e contagem confirmados, não aprovação perceptual. O contrato de receitaC em três arquivos novos passou7/7testes root19,084s (22947/892e11), mas produz apenas `COMPILED_FIXTURE_NOT_EXECUTABLE`. LIVE opaco fica `BLOCKED_INCOMPLETE`; nenhum grafo de produção existe nesta versão. Ferramentas externas pinadas substituem caminho inventado dentro da raiz; A precisa de inputs externos/recomposição real e não pode ser aprovado por seus próprios flags. A ausência desses vínculos é blocker, não verificação cumprida. Isso encerra somente a unidade de contrato, não C ou Fase6. Os três hashes estão em STATE e devem ser preservados antes da evolução. Nenhum módulo de capacidade/admissão/runtime foi alterado.

Fechamento técnico22:34:47Z: preservar a derivaçãoFAIL5f922… e a correçãoPASS5d7ebccf7bd20015eb721f61756fe7592b58fd73cb1b6b8b4b78f8a4be0d1508. Resultado independente de entrada−16,37LUFS/−1,49dBTP/zero extremosPCM;4.866.720samples, zero remoção. Normalização contínua reutiliza loudnorm em vez de reiniciar processamento por corte. Offset adicional0,58 deriva da medição anterior, com teto de uma correção; nenhum limiar foi relaxado. Os oito testes do helper passaram. Isso é aprovação **apenas** de níveis/duração/PCM, não do gateAUDIO completo. O original e a primeira falha permanecem intactos.

Para eliminar espera circular, a receitaC pura será compilada/testada sem execução nem admissão. Nenhum caller ou fixture pode conceder namespace/autoridade. TimelineA completa, contexto/direitos/publicity e capacidade real continuam necessários. Apenas três arquivos novos estão no incremento; a integração versionada da capacidade projetada é posterior. A contraprova ASR contextual f66e675… já existia e não será repetida em busca de concordância.

Capacidade22:39:35Z: decisãoeb2e35183a90dffa,22%restantes/reserva10/12planejáveis,1,9512158400785908pontos/dia; custo variável/compartilhado confirmado por OpenAI Docs. Manter melhor modelo, concluir checkpoints críticos em curso e evitar expansão discricionária. Não comprar/resgatar nem converter2.500créditos empercentual.

Complemento observado22:23:10Z: medição de entrada por instrumentos existentes, receiptf7dfa55f3758d044b95e41b1bcb566207b65bf435ea87dfe566248985a4ce12a.−25,71LUFS/−2,01dBTP/LRA5,5/zero extremosPCM16. Normalização ainda não executada. Preferir cadeia existente e preservar derivação separada; não aplicar9,71dB de ganho linear porque o pico extrapolaria0dBTP. Medição técnica não aprova qualidade perceptual ou os outros gates.

Em06/09 às22:18:27Z, encerra-se a materialização literal da proposta editorial cb5f0389…:51PCM copiados integralmente, hook0–8s intacto,202.780ms, montagem2,0559085s, receipt ea7966778748bc81f80813aae1940a44ea2acac35c9f1af76976aea355f30c2d. A duração permanece insuficiente e não quantizada; não converter pausas adicionais em alvos de energia nem adicionar silêncio para satisfazer o piso. A receita limitada a QA não altera jobs, fontes, voz ou experimento.

Para evitar regenerar áudio correto por erro de transcrição, foi executada uma única contraprova PocketSphinx5.0.4 **sem texto/gramática esperados**, usando instalação gratuita existente, somente nos cinco desacordos. Receipt9ef196b3d53bd5e617c6592b7f108f206caf4281eef9f52075e92020e0a29b25, worker16872 exit0, replay byte-idêntico. O CMU pinado demonstra homofonia write/right, não o som efetivamente ouvido.001/007/013/016 permanecem ambiguidades acústicas, não autorização para alterar texto ou reaprovar áudio. Reconhecedores concordantes não constituem padrão-ouro e timestamps livres não são alinhamento calibrado.

Prioridade: reusar áudio e instrumentos existentes, corrigir apenas defeito comprovado e medir entrega por vídeo integral liberável. Não repetir a montagem, reconhecimento ou render encerrados quando seus hashes permanecerem intactos. A temporalização LIVE continua exigindo referência anotada genuína e segundo método aplicável; autorização genérica não fabrica dados nem elimina essa condição. Nenhuma nova regra de fase, despesa, publicação ou redução de qualidade é criada.

## D-155 — Composição editorial real e encerramento do render diagnóstico

Fechamento da prova em21:54:50Z: o verificador independente c84c9a1f… recompôs os oito estágios e a origem geometry→source, com receipt determinístico40679c5a60eef49fcd49557aa69909346c25a48a734b75fe568278fc63695f48. Sete negativos/positivos root PASS5,195s e verificação real ee391b exit0, byte-idêntica aos replays anteriores. Isso fecha as três lacunas de **rastreabilidade da amostra preservada**, não aprova criação, áudio, movimento intrínseco ou produção. O renderer2758ff… não foi alterado nem generalizado; futuras leituras desta prova usam o verificador separado. O render não será repetido por causa dessas correções.

Em 06/09, 21:38:30Z, foi materializado `editorial-hook-v1-01bb2c91eeccb03bebab`. Report SHA **7601950874fcbb22fa6efe6fc3a104ea93e15b8232fda3ab1a332870db09fe6c**. A fonte cinemática já tratada foi redimensionada uniformemente para 1536×864 e centralizada sem crop; o mecanismo literal NAME / TEST / CHOOSE ocupa faixa editorial fora do viewport. O grupo SYSTEM: TRUTH / RESPONSIBILITY / TODAY aparece a partir do frame75, separado e sem equivalência 1:1 com os cartões. Não houve nova voz, mudança de texto, velocidade, tempo 3–8s, fonte/span, identidade ou experimento.

A nova identidade de receita é `heroverse-take003-editorial-footer-v1`; não altera nem promove o sidecar físico v3. As 450 geometrias observadas e duas regiões pixel-a-pixel são controles de separação e preservação, não atalhos de aprovação semântica/movimento. O render lossless preservado mede 125.600.051B; SHA **02a97a8ab264fdc1fc9c5278fc460ef52f1a5fd12a4be0067115f8d515bd7e09**. Não repetir este render por causa de relatório ou verificação retomada.

A revisão separada encontrou três lacunas no executor diagnóstico: vínculo explícito do receipt da geometria, report com timestamp variável no replay e reconciliação insuficiente da fronteira dos terminais. Fechá-las por verificador independente read-only dos artefatos atuais; não apresentar o renderer diagnóstico como executor produtivo. Seu estado permanece candidato visual não aprovado. Inspeção de frames não substitui áudio/legendas, fonte/movimento intrínseco, publicity ou os gates completos A–D. Nenhuma autorização de publicação decorre destes resultados.

## D-154 — Encerramento da hipótese de semeadura e prioridade de entrega

A execução source-only 7471eacad foi concluída em 21:08:24Z; report 5087d20f3b670b630d9b8763de207fa14fe3b62ed5d745a636651e1f9395da58. Seis pares falharam em suporte LEFT mínimo, incluindo três que o método retido aceitava. Cobertura e condicionamento favoráveis isolados não autorizam promoção. A hipótese fica rejeitada para integração; não tentar outra varredura de frações sobre os mesmos seis casos. Preservar V3/V4/compositor, gates e todos os dados. Isso encerra a unidade experimental e evita transformar cada resultado negativo em uma expansão automática da pesquisa.

O proprietário reiterou prioridade por velocidade com qualidade. O próximo exame deve ser uma composição mais simples e realmente diferente do take-003, preservando o mecanismo falado e todas as invariantes protegidas. Uma faixa de passos no espaço editorial, visivelmente separada dos cartões físicos, é uma hipótese de layout, ainda não capacidade. O schema antigo fixa rótulos físicos e não pode ser relaxado ou reinterpretado retroativamente. Novo contrato/candidato/prova próprios são obrigatórios; se conflitarem com lock protegido, não avançar por autorização genérica. Não copiar a falha antiga e mudar seu nome para HUD. Fala literal, tempo, fonte, custo zero, direitos/publicity, ChannelDNA e gates permanecem.

A medida de entrega é o Vídeo 2 completo aprovado e publicado pelo fluxo autorizado. Testes e diagnósticos são evidências intermediárias; não serão apresentados como produção operacional concluída. Sem nova arquitetura, catálogo ou frente discricionária neste lote. Gestão de capacidade permanece D-152, sem nova consulta duplicada apenas por continuação de turno.

### Aplicação D-152 — observação nativa de 06/09, 20:50:51Z

Não recriar o controlador nem mudar a âncora para ocultar o desvio. A operação única já consta de `config/codex-usage-policy.json` e de AGENTS. Materializar a nova leitura pelos módulos existentes: 26% restantes, reserva 10, 16 pontos planejáveis em 537.885 s, 2,570066092194 pontos/dia. Decisão `codex-usage-10710888172b3bb3`, SHA 756e61f6a2eece3c4eb30701d516d554065078af0ecea5e2fd966758a8719fc6, schema/twin exato PASS. Desvio de 10,975223841567 pontos mantém somente o caminho crítico. Preservar qualidade e aproveitar checkpoints, não alegar velocidade medida ou saldo infinito. Consulta [OpenAI Docs](https://learn.chatgpt.com/docs/pricing#what-are-the-usage-limits-for-my-plan) confirma que contexto, raciocínio, ferramentas e modelo variam o consumo e que a cota é compartilhada. Nenhum gasto, reset, mudança de modelo ou execução do projeto pausado.

## D-153 — Sincronização por origem temporal e separação de capacidade projetada

**Semeador geométrico fechado,20:18Z:** helperae21971e...,14/14testes rootPASS3,409s,450hulls retidos conferidos. CadeiaLEFT48/1 mantém segmentos9–18 e propõe pontos em12/13/13/15/16; antes somente13 passava no piso individual. Não há borda fotométrica observada nem gate aprovado por esta proposta. Manter o helper fora de V3/V4/compositor; próxima prova precisa ser fonte-only, pré-registrada e preservar todos os limites. Documento `paper-edge-chain-seeds-v1-root-evidence.md` mantém hashes completos, snapshots e exemplo. Não reabrir diagnóstico/comparação já concluídos sem evidência nova.

**D-152 aplicado à observação20:19:40Z:**26%restantes;16pontos acima da reserva por6,247175925926dias=2,561157263652pontos/dia. Decisãoadb3ab2711205cb6 schema/twinPASS, SHAaf6afd7a26853f691154600ebb49ec88261ac12bf7d2bb6dd10e83e855bfc5df. Mantida âncora original e desvio11,069055504111pontos explícito. SomenteYouTube ativo; qualidade preservada, sem downgrade, compra/reset ou fan-out discricionário. Consulta oficial e política não provam execução Codex ilimitada ou runtime vivo.

**Comparação concluída, 19:55:38Z:** report **c4c4f5e5a89c4938eac8f16f66ecf49f8e6b60befb2a1adc5382ecbe1e897de9**, sessão99916/worker14660 terminal0, 5/5 testes root PASS0,287s, revisão independente. minAreaRect anterior, TLS externo e quad solicitado foram comparados aos mesmos transforms fonte-only. p95 central TLS por carta: 2,351703/2,163375/2,136458px; contrafactual solicitado:2,338734/2,097537/2,109669px. Melhor valor relativo não torna uma representação vencedora/aprovada. Target continua contrafactual; TLS continua não calibrado; não se pode atribuir todo residual ao retângulo envolvente ou declarar defeito físico apenas por esses números.

**Decisão de correção causal:** leitura dos journals carta1/49 prova que o piso por segmento elimina fragmentos contíguos da lateral antes da fotometria; os scans restantes não fornecem suporte LEFT e a condição é195,401>100. Implementar somente proposta de sementes por arclength de cadeia contígua do mesmo lado, sem descartar fragmentos curtos e sem relaxar scans/condição/resíduos/coverage. Uma cadeia elegível não é borda observada. No caso carta3/55, a exclusão pelo holdout24 é legítima e causa perda de cobertura; não pode ser removida porque o KLT correspondente foi rejeitado para movimento. É necessária uma solução independente de amostragem, ainda não implementada. Proibir qualquer promoção do helper a observador ou aprovação de vídeo por testes geométricos. Permanecem desconhecidas a receita original de movimento e a calibração LIVE.

Antes da primeira execução do helper, revisão principal exigiu hull convexo simples, rejeição de aritmética não finita e testes de segmento local não colinear/vértice exato. Preservar snapshots físicos dos rascunhos já hashados. Esta revisão preventiva não é render/retrabalho de produção. Encerrar reduções numéricas íntegras e concentrar trabalho na causa específica mantém D-150 e o planejamento de capacidade D-152; não existe ganho de velocidade medido ou promessa de saldo infinito.

**Resultado retido, 19:34:51Z:** report `5e04882e9b87db64db3ef266e6cec78a01d3259aaccc7afee4303729bb2a9adb`, sessão 21305 exit 0, worker 11500 rc 0, 15/15 testes PASS 0,146 s. A cadeia inclui o FFV1, a recuperação sequencial exclusiva dos frames 74/75, render clock-normalized, probe, decode, raw e os três bindings exatos de cada frame corrigido. A referência PNG divergente da recuperação continua histórica e não vira defeito inferido do vídeo.

A comparação só passou na reprodução do histórico após preservar os tipos originais: projeção e média projetada float32, transformação e média observada float64. Guard/tolerância 1e-8 e limiares não foram alterados. Prepare 64671 e run 77658 falhos permanecem registrados em STATE; snapshots físicos precederam alterações de fontes congeladas. O novo diagnóstico usa frames explícitos e não deriva através de gaps.

Decisão baseada no resultado: não considerar o problema de adesão resolvido pelo relógio. Permanecem 102 falhas de observação de bordas, uma falha numérica no par carta 3/frame 55 e perda de domínio carta 1/frame 11. A carta 2 completa tem p95 2,363650879 px, acima do limiar antigo 1,5 px. Estes são resultados condicionados ao instrumento anterior, não prova isolada de movimento físico defeituoso. Próxima intervenção precisa distinguir erro do observador e da trajetória com evidência por borda/frame; não repetir produção, expandir query ou selecionar o melhor método retrospectivamente. Nenhuma autoridade produtiva/LIVE ou fase foi promovida.

**D-152, atualização de capacidade às 19:37:30Z:** decisão `codex-usage-0b9f4eee2911e6c2` normaliza a observação nativa de 72% usados/28% restantes. Reserva 10 deixa 18 pontos por 542.286 s, teto 2,867859395 pontos/dia. Mantida a âncora e o modo `FULL_QUALITY_CRITICAL_PATH_ONLY`, pois o consumo está 9,195936373 pontos adiantado. Somente YouTube permanece ativo por declaração do proprietário. Nenhum reset, compra, downgrade ou despertar do QR; política cooperativa, não hard cap do host. Fonte oficial consultada: [OpenAI Docs — limites e variabilidade do uso](https://learn.chatgpt.com/docs/pricing#what-are-the-usage-limits-for-my-plan).

**Auditoria causal do movimento, pré-execução:** a inspeção independente confirmou337V3/7V4/103BLOCKED; carta1 tem55pares observados, carta2 tem149, carta3 tem140. A âncora da carta1 sai do query noframe11 por0,766685px, antes de aplicarH11, embora esse par local possua transformação selecionada. Hashes de fonte indicam150frames distintos, não duplicação exata. Isso não valida sincronismo ou movimento físico por si.

O produtor `scripts/analyze_phase6_layered_hook_tracking.py` SHA4544a7519cc87a5123857841bcaef3413a5eec31c167c3af2df67154641ef63d usa ajusteChebyshev; checkpointc243fe9adbf8e96324b4e11b12341031b662a8a82c4a712d9257a37476c67933 selecionou grau4. Desvio de canto do hull da carta1 relatado:p9514,6634433px/máximo31,3573779px. Estes são resíduos de uma região estimada no produtor, não o mesmo erro de aderência da etiqueta e não ground truth físico; não converter esse PASS de construção em aprovação de movimento.

O agregador histórico compacta vetores após lacunas e calcula diferenças como se endpoints continuassem adjacentes. Seu BLOCKED protege a publicação, mas essas derivadas parciais não representam aceleração por frame. Implementar diagnóstico separado com frame explícito, derivadas somente em pares/triplas consecutivas, âncora sem reset e comparação de quads históricos/corrigidos usando transforms fonte-only retidos. Não alterar o relatório antigo, ampliarquery ou escolher método pelo menor residual. A comparação quantitativa ainda precisa ser executada; hipótese de trajetória inadequada não é defeito do vídeo já comprovado.

**Resultado real18:50Z:** report2e5954dea225a239af7226ab91f71866b53a618ddf303d6ecbf688b9d525ea2b,450recortes/447transições; três cartas dentro dos limiaresSSIM/L*/cor/área. O dado novo é a recomposição completa dos componentes, áreas externas e vínculos; SSIM era conhecido. Dois resultados byte-exatos SHAa9cfc0cf2d1a687e146b0077909caa9ab5a5aebf9a238170e4c5c501615315ce, workers8736/17492 rc0, sessão91602exit0. 13testesPASS0,102s e revisão independentePASS. Custozero, sem nova mídia ou chamada externa.

Decisão: encerrar esta redução como diagnóstico reprodutível e não voltar a renderizar para satisfazer o caminho binário de medição já delimitado pelos controles. O contratoQA de referência residual permanece separado do operacional: não autoriza produção e não transforma geometria planejada em observada. Adesão ao papel, OCR, acústica, publicity e calibração exigem evidências próprias. Próxima unidade começa pelos bloqueios geométricos retidos; repetir cálculo íntegro ou alterar limiar para produzir aprovação continua proibido.

**Contrato de recomposição do candidato, pré-run:** módulo6dc30ef336ee6ccb279e34a5aa33d6715b75f63b4a615e9d97147d8f16e2b48f conserva os450patches reais e reconta a área das450máscaras externas, vinculando frame/card/quad/journal/raw. Resultados SSIM anteriores são conhecidos e devem ser reproduzidos exatamente. O novo relatório acrescenta L*/cor/área sem alterar limiares ou consumidores produtivos. A revisão encontrou trabalho nativo de replay sem watchdog; a correção exige um segundo filho próprio, preflight fresco, limite180s e receipts separados. Finalização é reconciliação, não execução nativa. 13testes rootPASS0,102s. A nomenclatura é recomposição de integridade pelo mesmo método pinado, nunca calibração independente ou LIVE.

**Prova residual executada,18:22Z:** script46ae22e4f08f8c27fe30155f60ea596e4060286a754bddab5510feb88b8c9b35 e8testes rootPASS3,034s; sessão56232exit0; report1bbb2081e740188e6e7460d38a3d775e681cdddfffa0b58d71dfa3891a7b3a5b. A intervenção agora nasce da fonte analítica original com o mesmo LANCZOS4/alpha e só muda o quad renderizado, evitando duplo reamostramento. Zero bate byte-exato; positivoSSIM0,983560552, X8px0,217399211, Y8px0,300512972, rotação2graus0,831873596. Todos os negativos foram detectados sem modificar limiares; reconstrução independente4patches e base300+3 concluídas.

Decisão: permitir preparar o contrato **QA** de erro residual em coordenadas planejadas para avaliação do candidato retido. Não permitir target como observação, nem substituir gates de geometria/papel por estabilidade temporal. Só a medição por si está apoiada pelo controle sintético delimitado; a capacidade permanece sem calibraçãoLIVE/autoridade produtiva. Os resultados conhecidos do candidato serão reavaliados como diagnóstico, não apresentados como teste fora da amostra. O novo contrato não reescreve a política anterior ou seusFAIL históricos. A publicação continua bloqueada pelas superfícies ainda não comprovadas.


**Resultado da contraprova pré-registrada:** report fab70bbd56fe73447da46a82d35c7aef87ff8c295d4b9af8976d3f790feecd45, sessão20889exit0/worker13448exit0,150frames/149pares por braço. Geometria matemática mantémPASS (mínimoSSIM0,981318746), extração binária resultaFAIL (0,904021716), com mesma imagem/métrica/limiar e controles estável/glifo/brilho corretos. Replay dos300patches+3controles e parecer independente sustentam falso positivo possível neste domínio sintético; não transferem aprovação ao vídeo real. Atribuição é ao caminho binário/extração/retificação, não a um único passo isolado provado. Nenhum threshold ou artefato de produção foi alterado.

Decisão de próximo diagnóstico: separar coordenadas de referência da avaliação de geometria. Usar uma transformação planejada como base de medição residual, se controles provarem sensibilidade a desvios reais, não seria declarar target=observado; porém esse contrato ainda não existe na política operacional vigente. Antes de qualquer integração são obrigatórios pré-registro, negativos de jitter/desprendimento do objeto inteiro, prova independente e versão explícita, preservando observação geométrica/papel e calibraçãoLIVE. Não suavizar o próprio sinal para fazê-lo passar. A escolha é uma hipótese limitada, ainda sem implementação ou autoridade.


**Atualização de execução e capacidade, 18:00:51Z:** preservar a decisão D-152 de somente YouTube ativo, sem atuar no QR. Consulta oficial 31% restantes, reserva 10 pontos, 21 planejáveis / 548.085 s: 3,310435425 pontos/dia. Registro `codex-usage-985d91af59012a44`, SHA c95f2e8d3f9a4cf5f20c4dfeb295b83631db21dd32885db0eccf385eb39a3390, schema/twin PASS e 19/19 testes em 0,711 s. O consumo de 7 pontos em 2h50m34s entre as leituras da âncora e a atual equivale a 2,462380301 pontos/h nessa amostra: se persistisse, a reserva seria alcançada em cerca de 8,53 h, não em seis dias. Isso é extrapolação condicional, não previsão calibrada. Portanto não prometer Codex ininterrupto ou acelerar abrindo frentes indiscriminadas; concluir o lote crítico local já preparado, reutilizar evidências e manter qualidade. Nenhum reset, compra ou troca de modelo.

Os 10 controles focais do ensaio sintético passaram em 2,317 s, incluindo intervenção real de glifo/brilho, cobertura parcial, adulteração, capacidade e supervisão. Pré-registro e implementação pinados foram congelados antes do ensaio; a execução não altera qualquer gate operacional. A análise causal continua limitada ao cenário sintético pré-definido e nunca equivale à aprovação deste vídeo.


**Próxima contraprova pré-registrada:** antes de outro estimador, testar em sequência analítica de movimento contínuo conhecido se a máscara binária/ajuste já basta para reprovar um sinal estável. Inspeção do segmentador real128–176 confirma seleção por distânciaBGR≤45 ao backing, deltaLab, close9/open3 e preenchimento de furos; não conserva cobertura alpha subpixel. A extração seguinte não pode tratar essa máscara como geometria contínua exata sem calibração. Controle sintético não será chamadoLIVE, não usa o target para aprovar candidato e não altera thresholds/voz/mídia.

GestãoCodex17:38:05Z:32%restantes,22pontos além da reserva,549.451s/6,359386574dias,3,459453163pontos/dia; decisão codex-usage-8b2c1de834474d20/SHA c51d92f847b655071a20df4c49840dc2069392c0ba9bf9eb2f747b4a6c843659. Mesma âncora,5,555265pontos antecipados, sem rebase ou consumo de resets. [OpenAI Docs sobre limites](https://learn.chatgpt.com/docs/pricing) confirma que modelo, contexto, raciocínio e ferramentas variam o consumo; a resposta nativa da conta, não uma tabela genérica, fornece saldo/reset deste cálculo. Não reduzir modelo, contratar nem prometer capacidade ilimitada; manter só lote crítico já aberto e runtime local sob gates.

**Resultado posterior do observador projectivo externo:** report4bf1732095158478eabd01ee098e86c1a49d22736a42b8d5a3b51b6dcae16d0b, sessão27096 exit0.450observações e447transições completas, extração target-free e replay integral de quad/área/patch, mas trêsFAIL; mínimos SSIM0,894427255/0,944931458/0,753209481. A terceira carta piorou. Portanto o helper não será integrado como correção de qualidade nem declarado calibrado. Testes sintéticos e quatro lados observáveis não provam precisão temporal suficiente. Preservar a contraprova com target apenas como diagnóstico; não adotá-lo como observação, suavizar scores nem reduzir limiares. Investigar a precisão/quantização pelos pares já retidos antes de nova hipótese de algoritmo. O relatório mantém todas autoridades falsas e não altera o estado do candidato público/produtivo.

Antes desse run, o wrapper recebeu CREATE_NEW por invocação e supervisão hash-bound (intent exato, runtime/source/PID do worker e terminal coincidente), além de recomposição independente da máscara exata de cada frame/carta e pixels byte a byte.6/6testes root e parecer independente2fdf0889412a3770034da0eb42264faf867feae435359848d008a7d825c9eca3 fecharam os achados. Essas proteções melhoram a confiabilidade do diagnóstico, não sua conclusão de qualidade. Nenhum código previamente congelado foi substituído.

**Causa do componente de flicker discriminada:** diagnóstico9f3e033f0345a28a0ebc6dd70af57ef00f2d01a4b8882a84cf10b33996d7c712 compara todos447pares, preservando kernel, fonte, mídia e limiares. A extração anterior usa minAreaRect sobre silhueta projectiva e retifica o retângulo, deixando shear/background variável. O contrafactual com os quads projectivos solicitados recupera os mínimos de similaridade para0,991559/0,991961/0,993351, sem editar pixels de entrada; overlay/fundo constante recupera0,989283/0,988888/0,990090. Revisão independente observou saltos angulares medidos1,494°/0,567°/0,278°, contra0,088°/0,004°/0,006° nos targets suaves. Isso aponta o estimador/retificação, não erro de clock restante; não é prova geral de ausência de flicker.

Decisão técnica restrita: implementar observador projectivo externo a partir da máscara já medida, com quatro lados/cantos, versão e controles; não substituir o observado pelo target esperado, não ajustar endpoint/kernel ao mesmo tempo nem reduzir os limiares0,98/0,95. Preservar minAreaRect e todos os resultados antigos como histórico. A contraprova-alvo é hipótese/controlada, não receipt de qualidade ou publicação; a futura extração depende de validação independente e continua limitada ao backing quadrilateral deste hook.

**Contraprova terminal:** report741e5e92e59244d8cdfbc7b0a4bdbb90b5fc132852cefc940c140b9f9c5fe3a5, sessões74262/16458 exit0. A correção restrita eliminou150falhas de integridade, agora450PASS/SSIMmínimo0,998624781; geometria eHUDPASS. Flickerpermanece3FAIL, portanto o agregadoFAIL é preservado e nada é publicado. Próxima investigação usa os patches/frames já retidos; não presume que a reprovação seja artefato do instrumento, nem que todo delta seja defeito perceptível sem contraprova. A origem do papel é inalterada, porém suas observações não são silenciosamente promovidas ao novo candidato.

Gestão atualizada sem rebase às16:50:22Z:33%restantes,23pontos além da reserva/6,392523dias =3,597953338pontos/dia. Decisão codex-usage-fbcd005d14d51202/SHA25b7fb366c55b55f6465ab61eae2d6ee18dc8dfd1bdbcd64dcdc4c1d1c09eba6/schema/twin PASS. Preservar2.500créditos/2resets, custo técnico0, máximo modelo por política e caminho crítico apenas; QR não foi retomado. Encerramento seguro deste lote não é fase concluída nem promessa de execução infinita.

**Aplicação posterior,06/09 16:45Z:** a correção foi renderizada uma vez em QA,19,625s, mídia bc4bcc2ca953b0b696417f12972332bc92b7ee74f7d1f2fcf66f1b165560550e, receipt ef37e1d1f6d3b4872ef3393c0f81d038d1242df4aef961ede0cb1341abada1ca. A menção a plano não executado abaixo é histórica. Nenhuma narração, imagem, configuração de qualidade ou mídia pública foi substituída.

Contraprova independente usa novo candidato e reabre caches da fonte pelo seu journal original, sem transplantar sua identidade nem repetir os447observadores de papel. Replays de probe/decode e dependências por frame são recompostos integralmente. Status conjunto exige todos os controles do escopo; o componente `clock_pixel_correction_confirmed` mede somente geometria/pixels das etiquetas, não é boolean de aprovação e não será ligado a consumidor operacional. A revisão sugeriu unificar esse nome ao agregado; preservou-se a distinção explícita de componentes, com overall_video_approved=false, limites documentados e nenhuma promoção por boolean isolado. Não alterar fonte pinada enquanto o processo74262 está em execução.

PublicityB não entra em LIVE por seus25testes fixture: parecer c4b945db98f6e70dd58cb54d4a71dff9e48d67c4048a57581b198c1575a4ec91 identifica runtime autodeclarado, falta de calibração/sucesso pinado, StageA canônica, replay e relógio final. Corrigir essas fronteiras no lote já autorizado, sem inventar prova jurídica universal ou nova exigência humana a cada release. Não consumir PASS_LIVE atual até fechar os achados.

Releitura final16:15:12Z:34%restantes,24pontos planejáveis e3,740097831pontos/dia até o mesmo reset. Decisão `codex-usage-6da9ce27b98ff3dc`, schema/twin íntegros; consumo3,804664pontos antecipado versus âncora. Não reiniciar a âncora para ocultar o desvio. ContextoB corrigido após revisão independente,13/13focais root PASS5,970s; ainda sem integração/fencing/publicação.

O QA integral terminou e foi reconstituído:150frames/cobertura completa não passaram. As150falhas de integridade das etiquetas concentram-se em50frames f%3==1. A hipótese foi testada sem repetir decode/render: FFprobe de pacotes mede fonteFFV1 em1/1000; PNG entra a30fps em1/30; o timestamp33ms é anterior a1/30s. A [documentação oficial do FFmpeg sobre framesync](https://ffmpeg.org/ffmpeg-filters.html#Options-for-filters-with-several-inputs-_0028framesync_0029) define escolha do frame secundário de timestamp menor ou igual no modo default. Essa regra racional prevê exatamente as50falhas. Pixels retidos de4framesfalhos/3controles corroboram atraso da etiqueta, sem alterar thresholds.

Decisão: normalizar ambas entradas indexadas para a mesma base1/30 ePTS=N somente após provar contagem/CFR, em novo artefato diagnóstico. Não alterar referência do avaliador para aprovar a etiqueta atrasada; não trocar visual, voz ou parâmetros de encode. Histórico/source/runner/receipts congelados permanecem. `hook_clock_correction_v1.py` compila a mudança restrita, quatro negativos/positivos PASS; plano preparado, não executado. O problema de domínio do observador de papel continua distinto e sem aprovação.

Relatório causa SHA `c65593db74134e8ba6e6c8cd74212b1f707602fc9afd3e1c6c98cde5693f0a76`; relatório integral SHA `f973241ea007d3e09c1ea72ada422a421558398facff48b730a7e91ae108697c`. Observação auxilia o reparo, não é calibração universal, aprovação de mídia ou publicação.

Revisão B identificou risco de evidência autodeclarada: o próximo contexto é recomposto da fila canônica read-only, mas não substitui fencing/lock da futura transação. Capacidade com receitaC não vinculada ao executor permanece projeção bloqueada, mesmo com aritmética e arquivos corretos. Injeções de testes, rótulo LIVE no pedido e ausência de reobservação jamais constituem LIVE. Publicity exige todos os spans e nova contraprova de índice/pixels/detector; licença/face negativa não concede autorização jurídica. Fontes anteriores serão congeladas antes de hardening; ainda não há integração ou COMMITTED.

Atualização D-152: medição15:57:53Z preserva âncora,35%restantes e25pontos além da reserva; teto3,888647849pontos/dia. Consumo está acima do planejado, não abaixo: `AHEAD_OF_PLAN` representa antecipação de consumo em2,856770pontos. Decisão real `codex-usage-e5a10f6b2244fb65` materializada/schema/twin íntegros. Manter somente trabalho crítico, sem mudar qualidade ou parar runtime local; nenhum reset/compra e nenhum novo monitor. Redução de retrabalho é o aproveitamento dos300caches/10medições, não promessa de consumo constante.

## D-152 — YouTube como única carga ativa e orçamento até renovação

Contraprova posterior15:29:17Z:37%restantes, mesma janela;27pontos além da reserva,4,186805pontos/dia. Âncora62%usados preservada; desvio0,942828ponto, AHEAD_OF_PLAN. Decisão `codex-usage-a4fd4f1a55c29fca` prende essa conclusão, schema/twin/replay byte-exatos SHA `bf446284b72386e58c6bec94185c01407816d97986d726c7105c3c312738c56b`. Revisão independente encontrou contradição action/continuity, clamp de percentual inválido, lacunas fracionárias e writer mutável; corrigidos sem reduzir reserva ou qualidade. Último lote31/31PASS0,769s, com históricos reais e falha/retry da visão. Primeira seleção de testes incluiu nome de módulo inexistente, corrigida antes da prova final. Cópias exatas das revisões anteriores preservadas. Não existe consumidor automático universal desse campo no host/schedulers; o executor Codex e o monitor aplicam planejamento cooperativo, jamais hard cap fictício.

O proprietário informou que pausou o outro projeto. A configuração agora identifica YouTube como ativo e QR Dolar como pausado até retomada expressa, sem apagar sua importância histórica ou assumir que o limite da conta virou exclusivo tecnicamente. Não despertar a operação pausada. A interface nativa não atribui consumo individual nem garante custo constante por tarefa.

Observação sanitizada `output/operations/codex-usage/observations/account-20260906T151017Z.json`: 62% usados, 38% disponíveis; renovação observada `2026-09-13T02:15:36Z`, saldo separado de 2.500 créditos e dois resets intactos. Timestamp é registro local após a resposta, não instante exposto pelo provedor. Reserva 10%, orçamento 28 pontos percentuais, 558.319 segundos restantes; teto nominal 4,333006758 pontos percentuais/dia. Saldo e resets não foram somados à franquia semanal, consumidos ou convertidos em orçamento infinito.

Implementação aditiva: `hero_engine/codex_runway.py`, integração em `codex_usage_governance.py`, `workload_plan` na policy, schema1.2 retrocompatível e `tests/test_codex_runway.py`. Estados ON_PLAN/AHEAD_OF_PLAN/RESERVE_ONLY/UNAVAILABLE/REBASE_REQUIRED mantêm números ausentes nulos; mudança de janela não reinicia silenciosamente a âncora. A governança pode adiar novas etapas discricionárias extensas, preservando qualidade máxima, testes críticos e conclusão segura do trabalho em curso. Não intercepta todas as chamadas do host e não garante execução Codex permanente.

Provas: 14/14 testes principais PASS em 0,192 s; decisão `codex-usage-933dae9e40d69fdc` schema1.2 e twin byte-idêntico, SHA `f3a7452b91446f9d14cf158d82f69ae776b330636b674cd786b0588f04ade7d1`. Quatro fontes anteriores arquivadas byte a byte em `output/operations/codex-usage/source-freeze-before-single-operation-v1/`. Automação `HERO Engine — rotina diária` atualizada pelo mecanismo oficial; prompt anterior integral, horário, destino e status conferidos. Nenhuma compra, reset, downgrade ou mudança de configuração de modelo do host. OpenAI Docs orientou conferência da [documentação oficial de limites e consumo variável](https://learn.chatgpt.com/docs/pricing).

Redução de retrabalho concreto: o auditor visual parou duas vezes pelo guard de capacidade (sessões 39994/77684, exit1); preservou 300 caches e dez medições concluídas. O novo transporte congelado apenas aguarda capacidade por até cinco minutos por gate, dentro do watchdog global, antes de continuar o executor original. Doze controles principais PASS em 1,572 s; sessão 51292 iniciada para execução real. Ele não reduz o piso de memória/disco, não altera CV, não redecodifica cache completo e não concede aprovação de mídia. Falha de worker permanece terminal, sem retry automático não autorizado.

## D-151 — Prioridade pelo ciclo entregue e comparação real de formatos

Aplicação implementada em 06/09: coortes exatas v1.1, guard de origem e inspector de rotas, com 45/45 controles principais PASS em 17,349 s. O histórico real de 123 vídeos produz 114 elegíveis por idade e nove exclusões abaixo de 24 h; preserva OWNED e papéis das referências sem misturá-los na comparação. Receipt `format-path-40fd6a83a94fd476afe68196` recusa decisão atual: STALE e amostra pareada insuficiente. Replay histórico não equivale a admissão corrente: esta exige relógio UTC explícito, origem LIVE, prazo válido e capacidade literal elegível. Receita, RPM, progresso YPP e probabilidade de monetização continuam indisponíveis. O código novo ainda não integra refresh ao Gestor nem compara adequadamente pools de canais exclusivamente single-format; não deve ser anunciado como decisão completa entre formatos.

Continuidade concreta D-150: executor audiovisual retomável v3 revisado, 32/32 controles root PASS e preflight real PASS. A execução dos 150 frames da sequência existente está no escopo QA, preserva quatro frames retidos e todos os limiares; usa checkpoints por captura/medição e watchdog de processo próprio. Nenhum relatório diagnóstico concede publicação, calibração humana ou OCR. Essa é a próxima medição necessária, não outra expansão de instrumento. Treze fontes correntes arquivadas e rehashadas em `source-freeze-d151-market-av-20260906-a/`.

Em06/09, o proprietário reiterou que o objetivo é validar uma operação rápida para futura comercialização, preservando qualidade máxima/modelo e incluindo decisão LONG/SHORT/HYBRID e mercado continuamente atualizado. A prioridade não é número de testes, documentos ou estilos catalogados: é concluir o próximo ciclo real e medir sua entrega.

Auditoria read-only demonstrou lacunas específicas: `observatory/collectors.py` preserva content_format, mas `observatory/phase3.py:_rankable/build_cohorts` e o schema de coortes perdem a dimensão. `adaptive_editorial.py:232` filtra apenas external_longs e fixa LONG nos candidatos. A hipótese H-RPM-LONG-VS-SHORT não é regra aprendida nem comparador. O sinal principal usa cutoff02/09; no caminho auditado não existe TTL/agenda/supersessão suficientes para afirmar mercado contínuo.

Decisão: manter o experimento LONG/TOPIC_ANGLE e sua próxima publicação como entrega produtiva corrente; preservar todos os artefatos e autorizações. Corrigir a comparação e atualidade por contrato versionado para decisões futuras, em frente independente que não altere o protocolo ativo. Classificação deve ter origem; coortes devem separar canal/formato/idade; dado vencido bloqueia decisão nova; RPM/CTR/retenção/YPP ausentes ficam nulos. HYBRID não é capacidade produtiva sem dois packs/pipelines elegíveis. Não reinterpretar aprovação histórica da Fase3 como prova dessa capacidade ampliada.

Done when da correção futura: negativos de vazamento de formato/canal, baseline/idade, fonte vencida/adulterada, RPM ausente, híbrido inelegível e replay; agenda integrada ao Gestor, ledger gratuito e snapshot recente real; nenhuma estratégia ou fila paralela. Esta decisão registra a lacuna e a prioridade, não declara esse patch implementado.

Modelo/esforço não serão reduzidos. O ganho será medido por tempo ordem→publicação, aprovação no primeiro render, retrabalho medido, atualidade das fontes e tempo publicação→avaliação; indicadores sem baseline suficiente não receberão percentuais fabricados. A meta30dias permanece experimental; prontidão comercial depende de resultados e repetibilidade, não da força nominal do modelo.

## D-150 — Aceleração por reutilização e custo medido no caminho crítico

Composição final implementada sem sobrescrever V3/V4: política fixa V3 primeiro; V4 só após insuficiência geométrica recomposta. Root17/17controlesPASS0,434s; recomposição dos receipts existentes seleciona V4/1,V3/2,V3/3, zero novo CV. Compositor SHA `4401bd8dd1a8cb43bcec0f9bd4040463655559e71c0fc2b18bfb776734a23a58`. Sem menor-residual, ID da carta, erro, ambiguidade ou ausência de origem como permissões de fallback. Encerra a mudança localizada do instrumento neste lote, não o QA integral ou a calibração. Próxima etapa integra a versão congelada e retoma checkpoints, sem reiniciar investigação já resolvida.

Checkpoint 06/09 13:32Z: correção V4 do localizador concluiu 15 controles principais em 0,633 s e runner versionado nove controles em 0,618 s. Replay único com pixels retidos terminou em 6,5703 s, oito bindings reabertos, terminal `a919d94038f36ace5610d6fd89e59c3227ea96e3de551a3cea6e80aceba97373`. Carta1 passou observabilidade (19 bordas, condição3,099); cartas2/3 ficaram UNOBSERVABLE, onde V3 já media. Portanto V4 NÃO substitui V3 globalmente. A prova resolveu a causa localizada de LEFT, mas não é melhoria geral comprovada. Preservar ambos; eventual fallback exige causa geométrica explícita, regra fixada antes de novos dados e controles independentes, nunca escolha pelo residual favorável do candidato. Não repetir o par, render ou 150frames para descobrir novamente a mesma insuficiência.

Incidente de preservação: os três fontes v2 da EtapaA foram alterados antes de arquivamento físico; os hashes/testes/receipts históricos existem, mas os bytes históricos não foram recuperados. Não afirmar rollback exato dessa versão. O lote v3 atual foi copiado exclusivamente e rehashado em `output/qa/phase6/diagnostics/source-freeze-av-v3-20260906T1335Z/`. De agora em diante, snapshot byte-exata antecede alteração in-place de fonte congelada. A pasta contém v3, não recuperação fictícia de v2; mídia e receipts imutáveis não foram reescritos.

Aplicação posterior: o observador de papel V3 é source-only, KLT suportado seguido de no máximo um ECC validado nas bordas. Domínio e política são definidos antes do candidato; cobertura espacial, posto6 e condicionamento normalizado<=100 impedem extrapolação sem suporte. Root19/19controlesPASS e replay único74/75 concluído (terminal `e0cecda765835ad8b840cbdba8da9b2f21d09efe75f7646aa52578c65966999d`). Cartas2/3 observáveis, carta1 bloqueada: ausência deLEFT na extração, não justificativa para afrouxar limiar ou refazer vídeo. A correção seguinte deve atuar na localização/amostragem real da borda; 150frames ainda não estão autorizados por esta prova.

Dependência temporal gratuita viabilizada: PocketSphinx5.0.4 instalado isoladamente, licenças/pins/smoke e250/250palavras comprovados (receipt SHA `e7fc1cf565ec072dceb65c2933d4d11bf1fcc84373ca20fd7fd39316b82033ad`). A biblioteca não é state-of-art nem é promovida a alinhamento calibrado; será confrontada com referências reais antes de uso crítico. A falha de caminho Unicode levou a runtime ASCII isolado no LocalCache, mantendo tentativa e venv do Gestor intactas. Sem microfone, sounddevice, API paga ou inferência-alvo. Usar os artefatos instalados, não repetir instalação a cada retomada.

O proprietário reiterou urgência, assertividade e redução de retrabalho. A resposta não cria mais fases: a prioridade fica no próximo vídeo aprovado. Preservar os51PCM e resultados ASR/OCR/decodes já obtidos; não repetir efeito caro apenas por retomada de sessão. Regressores integrais são agrupados por lote revisado, sem dispensar implantaçãoD-116. Um diagnóstico encerrado só reabre por nova evidência, mudança relevante ou insuficiência específica da prova.

Medição real: `layered-hook-retained-pair-cv-v1-bc3158303f2aa271-20260906T120021551358Z-b74b7f97`, terminal SHA `bb0c60fcf4944c055d72eb13f58648ef99bdb7405fcfca6129acf15613f1e039`;26,6671278s,15etapas,51artefatos rehashados pelo root. Zero nova síntese/render/decode/API. Seis labels consumiram8,6702914s; perfis identificam conversões LAB/float/composição e distanceTransform de1080p inteiro para suportes locais. Preparar wrapper ROI em resolução nativa, sem alterar o instrumento v2 histórico nem os pisos de qualidade.

Done when da otimização: controles positivos/negativos conservados; máscaras e métricas/status equivalentes nas mesmas seis observações reais; benchmark antes/depois, sem alegação antecipada de economia ou aprovação do vídeo. A medição encontrou ainda residual de10,7191px em canto da carta3; distinguir movimento real de extrapolação do estimador antes de qualquer rerender. Um par não aprova150frames.

Resultado posterior comprovado: wrapper ROI nativo SHA `951477c4d01258d74201ad44393dcc4fea532a6530c44ce97a3a4095ab9a8f61`, quatro testes principais PASS; comparativo real de seis labels PASS, 18 máscaras pixel-exatas e status iguais. Soma V2 10,8956704 s / ROI 0,5817685 s = redução de 94,6606% nessa etapa, sem extrapolação ao vídeo inteiro. Report SHA `4509a1732d1d3cd0cd7f79e6492b1c80ebdceef7190dd3c6e6c7d38185c4cfe0`, terminal `03ba46563ea230ea1a8b252ffba952d931001491afce91d0984f9954366e8afe`. V2 continua intacto, usado como fallback quando o recorte não pode ser comprovado. Capacidade produtiva e gates integrais não foram promovidos. Falha pré-CV do primeiro benchmark permanece registrada em STATE, sem esconder retrabalho nem repetir mídia.

Decisão posterior orientada pela contraprova fonte-only: não rerenderizar a carta 3 com base no residual de 10,719 px. O H foi reproduzido, seus pontos cobrem menos de 1% da área e seus cantos extrapolados falham em 30 bordas observadas, com erro máximo de 20,8337 px; ECC separado fica até 0,8558 px. Receipt terminal `641532881ae012f29e39c3822785c59d518b36679cae62ff948b0bb85630348f` preserva ambas as estimativas e a classificação diagnóstica. Corrigir suporte espacial/fallback no instrumento versionado antes do avaliador integral; não escolher retrospectivamente o menor residual do candidato nem transformar essa comparação em aprovação de vídeo.

## D-149 — Origem e pré-registro da calibração audiovisual

Hardening v3/schema1.2 concluído em disco: origem do holdout ligada à síntese reconciliada, voz/idioma/modelo/velocidade/PCM e exclusão da união completa dos alvos temporais. Root seis focais PASS em 39,118 s, sessão4576 exit0, incluindo adulteração com receipts rehashados e falso alinhamento independente. Escopo explícito: unidades reconciliadas deste release fora da união de captions/eventos; corpus externo ainda não tem classe de origem suportada. Schema1.1/v2 permanece legível como histórico estrutural, não executável pela validação v3. Calibração LIVE, avaliação perceptual e EtapaA integral continuam pendentes. Hashes correntes e snapshot estão em STATE; a ausência de cópia histórica v2 está registrada em D-150.

A contraprova do módulo temporal encontrou que números autoconsistentes não bastavam para provar calibração. A v2 agora reabre WAVs holdout, referências, estimativas, modelos/implementações e observação acústica independente; liga perfil/PCM/texto e separa explicitamente FIXTURE/LIVE. Policy é entrada externa `path+SHA256`, não escolhida a partir do resultado: ID canônico/version/registered_at; cada estimativa prende ID/hash/observed_at; ordem UTC policy<=estimativa<=avaliação. Anotação histórica pode anteceder o pré-registro, nunca ser posterior à avaliação.

Arquivos congelados: `hero_engine/phase6_av_timeline.py` SHA `1b05e3cb74323acdf8d72009ddb32889542bfff67e16fb4dc1d88766657ba114`; schema SHA `7580799d884ca5a933e79429207cfe196332c3f2fc85b344f03c8350b7914acd`; testes SHA `e0054a7981b37e718069b49b59356762e28a9c4bfe6a012544eb1e530ea49c95`. Seis focais do executorPASS84,774s; revisão independente sem defeito concreto no escopo. Grupo principal sessão77882 em andamento neste registro. Não há calibraçãoLIVE criada ou deployment.

Done when: troca/pós-datação de policy, duplicação/leakage holdout, desvio de modelo/PCM e falso independente são recusados; FIXTURE conserva blocker; recomposição recebe fontes externas; caso real ausente permanece incompleto. O contrato temporal não substitui direitos, narrativa, arte, áudio perceptual, capacidade ou release.

Contraprova principal posterior: sessão77882 exit0,26/26PASS216,984s, mesmos três hashes congelados. A correção de origem temporal passou; nenhuma evidênciaLIVE foi fabricada nem a EtapaA integral declarada concluída.

## D-148 — Prova de recuperação usa identidade completa dos testes

A oitava manutenção ultrapassou os erros de snapshot, mas D-116 recusou GC-21. Causa comprovada no inventário 894 e log real: `test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime` existe nas classes DailyMaintenanceProtocolTests e Phase5ManagerAutostartTests, ambos com outcome `ok`. O seletor por sufixo rejeitou corretamente os dois matches; o defeito estava na referência ambígua do consumidor, não no runtime ou na conta Google.

Decisão: GC-21 exige as duas identidades totalmente qualificadas, cada uma com prova `ok` no mesmo inventário/log hash-bound, junto do runtime recuperado já exigido. O teste de protocolo verifica ordem transacional e finally; o de autostart cobre cadeia/roles, singleton e executores proibidos. Ausência de qualquer um continua bloqueante. Sufixo ambíguo, skip, log adulterado e hash divergente não são evidência. D-116 e seus blockers permitidos permanecem inalterados.

Implementação: `hero_engine/phase6_acceptance.py` SHA `e11b1ea55e181c4b5c723a5ff60f404e1d4ba02c48526118c1855d304a48abae`; teste SHA `bdc6adf3e810dc8f313a3e8b352a16e2a8632cbb36d7f4028d2816a105bd5fbb`. Contraprova principal dos consumidores: 70 testes PASS em 40,115 s. Recomposição read-only real às 11:12:57.478022Z: GC-21 PASS_LIVE e somente GC-01 bloqueante, sem materialização. Os cinco outros seletores usados pelo aceite têm um único match no inventário 894. A tentativa antiga segue FAIL; a correção não produz deployment retroativo. Próxima manutenção somente após revisão/congelamento das alterações do mesmo lote e preview atual.

Done when: seletores determinísticos e adversariais passam; inventário confirma que os IDs exigidos são resolvidos sem ambiguidade antes de repetir trabalho pesado; uma nova manutenção comprova regressão e recuperação integral, sem relaxar gate nem apagar história.

## D-147 — Dados de inspeção não atravessam conversão temporal do shell

Evidência posterior, oitava manutenção: 894 testes em 771,311 s sem falhas/um skip; o caminho de snapshots ultrapassou a divergência literal anterior. A tentativa inteira ainda é FAIL, pois D-116 recusou GC-21 no aceite pós-reinício. Investigar a evidência específica desse check, mantendo a lista de blockers esperados e os receipts antigos intactos. Runtime 12748 recuperado não substitui a prova conjunta final. Nenhuma nona manutenção autorizada tecnicamente por esse resultado isolado.

A sétima manutenção teve 882 testes sem falhas, com um skip, mas D-116 recusou a snapshot: 11 timestamps em três jobs perderam zeros finais. O host PowerShell 7.6.5 converte strings ISO para DateTime e as reemite com representação diferente; a contraprova PS5 preservou as strings. São instantes equivalentes, porém o contrato exige dados literalmente preservados. Testar somente PS5 foi cobertura insuficiente para o launcher efetivo.

Decisão: o shell continua orquestrando inspeção/captura, mas um compositor Python deriva queue, quota e operational effects diretamente dos bytes pinados da inspection. Ele produz canonical-state, snapshot e queue-before/after; devolve ao PowerShell somente resumo de caminhos/hashes, sem reserialização dos dados opacos. Antes de compileall/regressão, valida as seis igualdades de origem, tipos, confinamento, hashes, estado canônico e redaction. O verificador D-116 permanece independente e estrito. Não normalizar timestamps individualmente, aceitar representações concorrentes, copiar conteúdo de credencial ou reescrever receipt antigo.

Done when: produtor real testado em PS5 e no PS7 efetivo, com frações de 1–7 dígitos, Z/offset, arrays/objetos/null/Unicode/números/bools e negativos de adulteração; contraprova de serialização não muda strings; testes focais e revisão de todos os consumidores passam antes de uma nova manutenção; somente regressão nova + recuperação + receipt D-116 aprovam deployment. Implementação em disco e contraprova principal 81/81 PASS em 76,605 s; revisão independente sem blocker no caminho corrente. Deployment continua pendente de execução integral, sem aceite antecipado. Essa mudança não amplia fase, direitos, custo, fila ou publicação.

## D-146 — Testar a projeção real do PowerShell antes da regressão pesada

A sexta manutenção teve regressão PASS (873 testes, um skip), mas D-116 recusou a projeção da credencial externa. Contraprovas no Windows PowerShell 5 demonstraram três defeitos em `scripts/daily.ps1`: o desempacotamento de uma coleção singleton converteu a projeção em string; `Get-Content` sem UTF-8 explícito corrompeu o caminho acentuado do watcher; parâmetro string nulo tornou `snapshot_path` uma string vazia. Não existe evidência de falha da conta Google; nenhum conteúdo de token foi lido/exposto no diagnóstico.

Decisão técnica: corrigir o produtor, preservando coleção/UTF-8/null e adicionando preflight de presença, identidade do caminho e redaction antes de `compileall`/unittest. Testes devem extrair e executar as funções reais em PS5 com JSON UTF-8 sem BOM, caminho Unicode, singleton, valores ausentes e campos proibidos. Manter verificador independente estrito; projeção escalar, token ausente ou snapshot de segredo continuam bloqueantes. Não modificar receipts históricos nem aceitar evidência inválida por compatibilidade.

Done when: contraprovas reais e negativas PASS; revisão de consumidores da mesma classe; regressão integral nova; finalmente recuperação do runtime e receipt D-116 com ciclo novo e cinco fontes presas por hash. Testes focais ou runtime recuperado isoladamente não constituem manutenção aprovada. Custo adicional R$ 0,00, sem mudança de credencial, conta, direito, fase ou publicação.

## D-145 — Complemento: consumidor histórico omitido da contraprova focal

A quinta regressão integral encontrou uma única falha entre 873 testes: o teste de autostart ainda exigia uma mensagem do parser anterior. A correção troca a dependência de redação pela chamada real do verificador, pelo inventário, pelo exit code e pela confirmação de execução verificada. Não inserir mensagem decorativa no código para satisfazer teste antigo. Busca de impacto deve incluir testes que inspecionam fontes de outras fases, não somente módulos que importam o componente. A tentativa permanece FAIL; 73 testes focais posteriores PASS não a reclassificam.

## D-145 — Interpretar a regressão real sem promover skips a evidência

- A execução integral858 terminou em712,355s com `OK (skipped=1)` e exit0. O leitor de `daily.ps1` aceitava somente `OK` literal, produzindo um bloqueio incorreto; a manutenção b2e5f613 permanece historicamente FAIL e foi recuperada com PID17880, sem falha na recuperação.
- A inspeção encontrou o mesmo pressuposto no verificador pós-manutenção e um seletor fraco de evidência de teste no aceite. A correção deve abranger os três consumidores: leitura lexical estrita, resumo único, conciliação de contagem, motivos/IDs documentados para skip e rejeição de resultados contraditórios, incompletos ou duplicados.
- Um caso ignorado por privilégio de symlink indisponível no Windows não prova esse comportamento. Aceite que exige o caso só passa com outcome `ok`; não contabilizar skip como teste aprovado, desabilitar teste ou ocultar lacuna ambiental.
- O verificador mantém a recomposição dos hashes, identidade e snapshot, sem confiar no rótulo do executor. Testes focais e replay lexical do log histórico antecedem nova regressão; não produzir receipt D-116 retroativo nem reclassificar tentativas anteriores.
- Done when: três consumidores convergem nos transcripts reais e adversariais, regressão nova concilia inventário e outcomes, e manutenção recupera runtime com a prova D-116 completa. Custo zero e gates de conteúdo/publicação permanecem inalterados.

## D-144 — Escrita de views mutáveis sem repetir falhas de disponibilidade

- Evidência: o preview read-only de 07:28:29Z passou; a invocação seguinte de `daily.ps1` foi recusada antes de criar request/parar o Gestor. O ciclo 07:28:46Z registrou WinError 5 ao substituir `learning-runtime.json.tmp`. O mesmo processo 18684 recuperou a view para `WAITING_FOR_TREATMENT_PUBLICATION` às 07:30:03Z. A origem específica do lock Windows não foi comprovada; não atribuir culpa à sincronização ou antivírus sem rastreamento.
- Corrigir a classe de escrita nas views mutáveis identificadas, reutilizando o helper atômico já testado: temporário exclusivo, bytes UTF-8 completos, flush/fsync, seis tentativas de PermissionError e espera total máxima de 0,75 s. Erro persistente continua erro; não apagar evidência nem considerar o retry prova de disponibilidade infinita.
- Extração `hero_engine/atomic_io.py` mantém o wrapper executivo v2. Learning distingue RUNTIME/PREFLIGHT_LATEST de avaliações e receipts imutáveis; estes últimos não são migrados nem sobrescritos. A extensão às demais fontes mutáveis exige whitelist de callsites e testes correspondentes, não substituição textual indiscriminada.
- Mudança de CRLF para LF em view mutável gera hash novo observado; não reescreve snapshot histórico nem dispensa validação de identidade. Atomicidade é de arquivo, não transação de várias views. O protocolo de manutenção continua obrigatório para carregar código novo e provar o ciclo integrado.
- Done when: revisão dos consumidores, testes adversariais de chamadas reais, regressão integral estável, reinício verificado e receipt D-116. Testes focais ou recuperação espontânea não satisfazem esse aceite. Nenhum gate editorial, financeiro, de direitos ou publicação foi alterado.

## D-143 — Bloqueio de mídia também limita a prioridade executiva

- Contraprova integral posterior encontrou incompatibilidade real entre produtor e verificador de status:845testes501,312s,3FAIL/3ERROR. A correção especializa a representação pelo schema da fonte: somente GOAL_TRAJECTORY1.3 usa selected_action ou BLOCKED; versões legadas mantêm str original. Preview e produtor compartilham contrato de execução, enquanto D-116 recompõe independentemente sem aceitar duas representações concorrentes para1.3. Hash/freshness/identidade não foram dispensados. Focais21/21 e68/68 PASS; grupos sobrepostos. Nova regressão integral ainda necessária.
- Aprendizado técnico deste incidente não é aprendizado de mercado: mudança de representação precisa rastrear produtor, preview, snapshots, verificador pós-manutenção e controlador de transição. A busca de consumidores identificou os três pontos reais; os testes agora atravessam a cadeia, inclusive versões legadas e adulteração. Nenhuma manutenção reprovada recebe statusPASS.

- Implementação posterior verificada: trajetória1.3/painel1.4/ciclo e65testes focais PASS em20,544s. O consumidor revalida a evidência mesmo quando `goal-trajectory/latest` já existe; revisão independente encontrou esse caso e controle negativo impede aprovação por snapshot obsoleto. Overrides de migração são candidatos propostos, não prova viva nem dispensa do protocolo de parada/commit.
- A prioridade `RESOLVE_MEDIA_PRODUCTION_BLOCK` conserva medições e flags falsas de publicação/gasto; evidência inválida produz atenção crítica, não espera validada. Mudança apenas de `updated_at` pode ser conciliada, mas mudança substantiva da fonte bloqueia. Implementação em disco ainda exige regressão integral e implantação D-116.

- Defeito observado: `_action` tratava preparador `COMPLETED` como motivo para `SYNTHESIZE_RENDER_VIDEO_2` sem considerar mídia `WAITING` pós-efeito ou `BLOCKED/ERROR`. A prioridade não concedia autoridade, mas orientava uma ação inexequível.
- Decisão: ação explícita `RESOLVE_MEDIA_PRODUCTION_BLOCK`, com prova íntegra para espera D-142 e motivo distinto para evidência inválida. Não confundir erro técnico com espera comprovada nem recomendar render diante de ambos. Versões novas de trajetória/painel preservam os schemas históricos.
- O binding conserva caminho, hash e identidade substantiva; heartbeat não cria aprendizado nem alteração material. Prazo, medição, pressão, publicações, custos e gates não são modificados.
- A regressão de D-142 executou 815 testes em 416,829 s: 2 falhas, 5 erros e 1 ignorado. Migração COMMITTED, recuperação sem erro, PID 7096/start 06:13:52Z confirmado vivo. Não existe receipt final PASS/D-116 dessa tentativa. Fixtures e integração serão corrigidas e verificadas, sem promover o vídeo reprovado.

## D-142 — Job terminal rejeitado não é trabalho executável

- Prevenção integrada ao chamador: `daily.ps1` passa obrigatoriamente pelo preview antes de criar request/suspender/parar. Contraprova principal final `local-runtime-preview-60979162a3c56c0ca7ba2405`, 06:05:04Z, 12 fontes/12 checks do erro exato e zero efeito; parser PASS. Testes focais de manutenção 76/76 PASS em 56,004 s reportados pelo executor, código congelado e revisto. Esses resultados não substituem a regressão e a prova viva da segunda manutenção.
- Hardening posterior do painel: temporário exclusivo e substituição atômica por arquivo com seis tentativas limitadas de PermissionError, preservação da saída anterior e limpeza somente do temporário próprio. Contraprova principal de reporting/writer: 28/28 PASS em 62,375 s. Atomicidade do par JSON/Markdown não foi implementada nem alegada; erro na segunda saída continua explícito e a reconciliação independente é obrigatória. Preview e commit devem compartilhar a correlação estreita do incidente histórico, sem autorizar arquivamento genérico de erros futuros.
- Implementação restrita: classificar a cadeia histórica exata em WAITING com prova imutável, sem reabrir SUCCEEDED, criar sucessor, executar mídia ou publicar. Prova exige binding do journal/outcome COMMITTED da migração parada; regressão PASS não é pré-requisito circular da verificação durante a própria regressão.
- Derivados migram transacionalmente somente pelo protocolo de manutenção existente; preview read-only não concede autoridade e não cria request/proof operacional. Falha restaura preimages e mantém recuperação obrigatória em finally. Histórico de mídia/receipts/fila preservado.
- Estado de produção bloqueada deve permanecer visível sem ser tratado como falha operacional quando apenas a espera exata estiver provada. Erros adicionais continuam críticos. O preview da última versão, não de versão anterior, precisa provar as 12 fontes antes da parada.
- Escopo e Done when em `docs/PHASE6_D142_TERMINAL_RECOVERY.md`. Testes focais e preview não equivalem a implantação; sucesso exige regressão integral e prova viva D-116. Neste registro inicial nenhum restart foi executado e o candidato continua não aprovado.
- Contraprova principal posterior: preview `local-runtime-preview-5ed4a17e1b1a4f6af173ffdb`, `2026-09-06T05:20:22.194838Z`, 12/12 fontes válidas/zero blockers, sem escrita. Consumidores e rollback: 109/109 testes focais reportados PASS em 66,608 s, código revisto. `ACTIVE_OBSERVING_PRODUCTION_BLOCKED` só existe com a atenção única exata; qualquer erro adicional permanece crítico. Implantação ainda pendente deste registro.
- Primeira manutenção real f3c00b33: FAIL antes da migração, guard de erro histórico não coberto pela preview; nenhuma regressão integral. Recovery automático recompôs processo22832 e removeu barreiras, sem apagar evidência. O incidente WinError5 de executive-status.tmp permanece preservado; corrigir escrita com temporário exclusivo/retry e integrar a mesma checagem ao preview. Não arquivar erro por conveniência nem apresentar o reinício recuperado como manutenção aprovada.

## D-141 — Narração contínua independente do corte visual

- Causa demonstrada: o render histórico concatena WAVs sintetizados por take e preenche cada slot. Nos 90 WAVs verificados, 39 das 89 fronteiras não terminam uma frase; o padding calculado nessas fronteiras soma 36.146 ms. Isso não é uma medição de silêncio acústico ou de naturalidade.
- Implementação aditiva: `phase6_narration_units.py`, schema de `NarrationUnitPlan` e nove testes. O planejador recompõe 51 unidades a partir dos 90 fragmentos literais, preserva voz/modelo/velocidades e horizonte de 279.600 ms; ambiguidade de pontuação ou velocidade exige revisão. Não reinicia a proposta de fala porque uma imagem mudou.
- Evidência: diagnóstico `narration-continuity-9c22ad5af00a338a97f7877e`, SHA `94706a7b317b2bf97a9d484c48f094b7854c5b6d38f34ecabe84929161e31904`; relatório em `docs/PHASE6_NARRATION_CONTINUITY_FINDINGS.md`. Contraprova principal dos nove testes PASS em 0,154 s. Não somar com grupos sobrepostos nem alegar regressão integral.
- Limite: `PLANNED_NOT_SYNTHESIZED` não corrige o áudio publicado ou candidato. Duração nova, alinhamento de palavras, encaixe e qualidade perceptual permanecem indisponíveis; agrupar frases pode apenas deslocar pausas para o final se o pacing não for reavaliado.
- Ordem diagnóstica autorizada pelo Gestor: prova isolada das unidades 011, 012 e 016 com Kokoro já local, parâmetros exatos, preflight de memória/disco/modelos/texto e medição real. Sem API, download, fila, mudança de arquivos anteriores ou gasto; capacidade insuficiente bloqueia a amostra. Não autoriza produção nem amplia a classe D-138 exclusivamente visual.
- Integração final exige contrato de remediação compatível com novas unidades de voz, síntese integral medida, alinhamento observado, amostra independente, render novo e gates posteriores. O job SUCCEEDED e o áudio histórico permanecem preservados.
- Evidência posterior: três WAVs locais novos (011/012/016), 48,018153 s de prova, sem aceleração, truncamento de conteúdo ou clipping. Detector de silêncio reduziu pausas internas longas das três frases para zero no limiar declarado, mas deixou 2.859,917/2.741,458/3.353,542 ms finais nos slots antigos. Não é aprovação de pacing. Receipt SHA `d47bb7ace0942d5ba5c624d7074d9a22962ee8234ec0ba3a3b6e2f01604ae99c`, 30/30 bindings recompostos.
- Contraprova ASR independente: três inferências locais com pesos existentes e texto esperado ausente do prompt; receipt SHA `6a431a875b8a9bbe88c98750de3f7ada672ec335c65f452afbee931ad2961457`, 9/9 bindings recompostos. Unidade 012 exata em palavras normalizadas, 011 write/right e 016 is/as permanecem NEEDS_REVIEW. Posições Whisper são estimadas, não alinhamento acústico exato. A tentativa de escuta pela ferramenta retornou áudio indisponível; não houve revisão perceptual/humana.
- Testes focais principais dos módulos/planner/provas: 25/25 PASS em 1,673 s; sem regressão integral ou deployment neste registro. Histórico de tentativas preserva bloqueio RAM e erro de serialização NumPy corrigido por teste real de tipos; não repetir TTS para corrigir falha de persistência de ASR.

## D-140 — Demonstrar a correção literal antes de novo candidato completo

- Extensão posterior ao hook: v2 preservada e rejeitada quanto à protrusão CHOOSE no primeiro frame. v3 adiciona teste negativo e verificação de cada um dos 150 frames com hull integral e margem de 8 px, sem reduzir o piso fotométrico 0,85. Preflight `layered-hook-proof-a1da6f2da24300a0c475f32c` recusa frames 102–149 (mínimo hull 0,997914093591327, clearance -6,403669843145008). Nenhum MP4 candidato novo. Gate válido não significa layout aprovado; conservar FFV1 e resolver região comum/tracking antes da próxima proposta, sem repetir extração nem deslocar por tentativa sem evidência integral.
- Autoridade: cobrança reiterada de assertividade e redução de retrabalho. Não basta detectar falhas após render longo; resolver dependências em uma correção integrada e comprovar trechos críticos primeiro.
- Escopo inicial: exercício de duas colunas, takes012–023. Nova receita local especializada mantém fala, slots, ordem das colunas, exemplos fact/forecast e identidade visual TRT. Não reutiliza o infográfico de três cards, não faz pan sobre texto, não cria terceiro painel e não refaz TTS.
- Implementação: `phase6_two_column_recipe.py`, schema de source plan, testes e `scripts/prove_phase6_two_column_source.py`. Toda geometria é calculada antes da primeira escrita de texto; plano literal, narrativa, ID e timeline são revalidados. Prova exige font/FFmpeg/FFprobe/WAVs/hash/capacidade e cinco GiB de reserva antes de render local.
- Limites: fonte prototipada, não TakePlan de produção, FormatPack validado, admissão de direitos ou autorização de job. Diretório isolado content-addressed; falha e prova anterior não são sobrescritas. Integração do sucessor e revisão de pixels/movimento/narrativa permanecem necessárias.
- Evidência focal inicial: 8/8 testes próprios PASS em 1,119 s; grupo anterior two-column+recipe 21/21 PASS antes do teste adicional. Grupos sobrepostos, não somar. Prova visual independente e render ainda não executados neste registro.
- Evidência posterior: prova v2 `61b9b5c0b76e39fa3d2ff30f` PASS somente como protótipo visual local, 36,4 s/1.092 frames e dez frames revisados; detalhes em `docs/PHASE6_D140_SOURCE_PROOF.md`. Primeira prova rejeitada detectou CRLF no textfile; teste real de um frame LF contra controle CRLF isolou a causa, antes da segunda amostra. UTF-8/LF explícito gerou recipe visual v4 e two-column v2; 23/23 focal PASS. Custo zero, nenhum input/render histórico sobrescrito, nenhuma publicação. Naturalidade da narração continua não aprovada; correlação de sinal não aprova prosódia.

## D-139 — Papel genérico não demonstra ação concreta

- `phase6_semantic_preflight.py` reconcilia blueprint/allocation/manifest/treatment, identidades de vídeo/canal e integridade declarada dos ativos; exige progressão monotônica TRUTH/RESPONSIBILITY/TODAY/COMPLETE. O seletor não aceita família genérica em lugar de fonte concreta. Comparação de metadados não decodifica imagens nem prova compreensão.
- Integração: antes de archive/overwrite dos cinco production inputs. Work order completo ainda pode ser persistido antes do gate; isso não é recibo de produção nem prova de aprovação. Não alegar zero efeito de control-plane.
- Auditoria real isolada: `phase6-semantic-preflight-6a07846cc4fc9ca455a45519`, SHA-256 `e98b3be8a5350be074fc6c6a92ec531a4f101ab9c05c28efb395fffcf7c5c9b6`, schema válido, BLOCKED; 49/90 mismatches concretos, 28 papéis exatos e 13 hipóteses atmosféricas não comprobatórias. Regressão em take024 e ausência de RESPONSIBILITY/TODAY.
- Três testes legados foram reconciliados sem mockar aprovação do novo gate. Corpus inadequado precisa bloquear e conservar sentinelas; teste de archive mecânico usa fixture explicitamente identificada e não é chamado pela integração bloqueada.
- Contraprova principal: `python -m unittest tests.test_phase6_semantic_preflight tests.test_phase6_production -q`, 44/44 PASS em 68,065 s. Não é regressão integral nem deployment. Nenhuma mutação do banco, inputs operacionais, mídia ou canal.

## D-138 — Base transacional dedicada não equivale a remediação operacional

- Classe `POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION`, schema dedicado e status `SUPERSEDED_POST_EFFECT_LOCAL`. Contratos pré-efeito preservados. Novo método insere sucessor+PREPARED atomicamente, materializa receipt antes de COMMITTED e exige verificador de elegibilidade explícito/reexecutado dentro das transações. Sem verificador, falha antes de abrir conexão/transação.
- Resolver aceita cadeia mista, raiz canônica obrigatória no criador, binding da cadeia anterior e receipt imutável. Predecessor SUCCEEDED não é reaberto nem alterado. Provas focais reportadas: 9/9 novos e 37/37 queue/authority; revisão principal examinou schema, criação e fronteira de verificação. Revisão/integracão integral e runtime permanecem pendentes.
- Os verificadores dos testes são fixtures, não aprovação editorial, prova de zero efeito externo ou controller vivo. Não houve escrita no banco operacional. A proposta D-137 reprovada não pode ser consumida. A classe preserva ativos; a revisão editorial que exigir novos ativos precisa contrato explícito diferente, sem alargamento silencioso.
- Hardening posterior: todos os 15 nós com pattern exigem string; o schema distingue predecessor SUCCEEDED/unleased/checkpoint não vazio e sucessor PENDING/attempt0/checkpoint vazio. Teste adversarial injeta tipos incorretos em todos os campos concretos e adultera estados/lease/checkpoints. Contraprova principal 11/11 PASS em 3,664 s. Leitura posterior SQLite exclusivamente read-only confirmou zero edges pós-efeito e c516 intacto; nenhuma escrita operacional foi efetuada.

## D-137 — Rejeitar correção cosmética antes de novo render

- Autoridade: insistência do proprietário em prevenir retrabalho e entregar qualidade real. Verificação técnica não substitui evidência editorial independente.
- Implementação focal: proposta isolada/hash-bound, verificador que recompõe fontes/schemas/diffs/outputs, receita v3 com layout medido e capacidade opcional sem sobrescrever latest operacional. 22/22 testes alignment/recipe e 13/13 capacidade PASS; sem deployment.
- Decisão editorial: **FAIL** para `visual-alignment-0d081c519410bf855a2fe0f6`. A correspondência 1:1 NAME/TEST/CHOOSE → TRT não foi demonstrada; reclassificação em lote não cria prova visual. Preserve o receipt PROPOSED como histórico e não o promova.
- Evidência nova: OCR real de 10 frames no render histórico teve 4 FAIL, e a inspeção visual do take012 comprovou duas colunas faladas versus três cards mostrados. Estado TRT também não progride por RESPONSIBILITY/TODAY. Evidências, hashes e próximos critérios em `docs/PHASE6_D137_EDITORIAL_REVIEW.md`.
- Correções devem agir no compilador e na seleção/composição de ativos, não só em nomes de tratamentos. Correspondência exata de papel é condição necessária, nunca prova suficiente de semântica. Custo R$ 0,00; sem novo render completo/publicação; Fase 6 permanece IN_PROGRESS.

## D-136 — Impedir retrabalho evitável antes de produzir mídia

- Autoridade: o proprietário reiterou que a prevenção deve ocorrer antes do retrabalho; não interpretar como promessa de infalibilidade ou dispensa de testes/correções.
- Mudança: preflight visual determinístico cruza plano/tratamento/Bible com a receita real, antes de capacity/Queue/TTS/render; compiler bloqueia antes de archive/overwrite. Receipts CURRENT/PROPOSED imutáveis, schema, hashes, recomposição integral e runtime 1.2. Histórico 1.0/1.1 preservado; checkpoints novos exigem binding. Fontes mínimas e texto por tratamento são verificações explícitas, sem relaxar o contrato vigente.
- Prova real: 90 takes em 0,791407 s; `visual-preflight-394d5a2f84d56d4a3570519f` BLOCKED, sem produção ou publicação. O conflito de framework e fontes insuficientes continua real; a nova regra também identifica 23 tratamentos textuais sem texto. Ver `docs/PHASE6_FIRST_PASS_PREVENTION.md` para fronteira de cada evidência.
- Implementação/testes em disco não equivalem a deployment. OCR/movimento/áudio/release e correção versionada dos inputs continuam obrigatórios. Não reiniciar ou sobrescrever a geração anterior apenas para fazê-la passar.

## D-135 — Resolver autoridade de mídia sem modificar a fila

- `TransactionalQueue.resolve_media_job_authority` usa transação query-only e segue somente receipts COMMITTED verificados. Bloqueia PREPARED, ciclo, fork, adulteração e divergência de unidade/linhagem/identidade; nunca recua ao predecessor.
- Uma cauda SUCCEEDED é terminal, com zero execução permitida; o resolver não cria supersessão nem chama reconciliação mutável. APIs anteriores preservadas.
- Código revisto e testes com SQLite temporário, incluindo replay de cadeia e zero mutação; sem chamada ao banco vivo. O sucessor pós-efeito e seu deployment permanecem pendentes, conforme `docs/PHASE6_POST_EFFECT_REMEDIATION_DESIGN.md`.

## D-134 — Autoridade PREPARED não pode ser reivindicada

- Correção bounded da race auditada: `queue_phase6.py` bloqueia predecessor e autoridade enquanto a supersessão está PREPARED, tanto em claim genérico/exato quanto na contagem executável. O claim exato recusa antes de consumir tentativa. Após COMMITTED, somente a autoridade volta a ser executável.
- Prova reportada pelo executor e código revisto: 28/28 queue, 5/5 media authority, py_compile; teste com duas conexões SQLite concorrentes comprova generic=None/exact=QueueConflict, ambos PENDING/attempt0, checkpoint vazio e zero executáveis antes do commit; falha de storage/replay e comportamento posterior cobertos.
- Arquivos/hash: `hero_engine/queue_phase6.py` SHA-256 `4a2b4cfdea1bc3f56abfc2207d53cfc60c83ba3b22fe005aa8cb4f8ca305da01`; `tests/test_phase6_queue.py` SHA-256 `02312e28127e5558d665826cd6abf9bc6a2a48edd470a7fb918d638f8907770f`.
- Nenhum banco operacional, lease vivo, receipt, mídia, Quality ou Publication foi alterado. Deployment pendente; o mecanismo completo de remediação pós-efeito não foi criado. Fase 6 IN_PROGRESS, sem novo render/publicação.

## D-133 — Resgate gratuito autorizado e capacidade compartilhada recomposta

- Autoridade: confirmação do proprietário em resposta à pergunta específica sobre usar um dos três resets gratuitos para ambas as operações. Executado exatamente um, sem nova compra/recarga.
- Transação nativa: intenção persistida antes da chamada; chave `13e58d92-968f-4e01-9ff7-d90fd105e327`; resposta `reset`; receipt separado preserva antes, retorno e leitura independente. Nenhum retry/desconto duplicado.
- Evidência anterior: 100% usado, saldo 2.500, três resets. Leitura independente `2026-09-06T02:15:39Z`: 0% usado, 100% disponível, saldo inalterado, dois resets. Nova renovação observada `2026-09-13T02:15:36Z`.
- Governança recomposta: `codex-usage-2fd2d836fdeb7945` GREEN, schema 1.1 válido e histórico byte-idêntico. QR Dolar informado; regras de qualidade/reserva e monitor existente preservados. Nova execução permitida, sem prometer duração infinita ou ampliar gasto.
- Skill OpenAI Docs orientou confirmação oficial de idempotência e leitura posterior; não houve mudança de modelo, effort ou runtime. Fase 6 permanece IN_PROGRESS.

## D-130/D-131 — Checkpoint de mídia e OCR sem deployment prematuro

Renovação owner-bound da reserva e avaliação OCR independente foram implementadas/testadas em disco. Detalhes, arquivos, contagens reportadas e limites em `docs/CHECKPOINT_D130_D131.md`. Sem restart, fila viva, render novo ou publicação; contraprova OCR viva bloqueada pelo piso de RAM. Não confundir testes focais com aceite integral. D-132 preserva esse checkpoint e impede novas expansões discricionárias enquanto a reserva estiver crítica.

## D-132 — Capacidade Codex conjunta entre YouTube e QR Dolar

- Usuário solicitou gestão para ambas as operações, igualmente importantes e sem redução de qualidade.
- Mudança aditiva: roster conjunto na política, decisão/schema 1.1 preservando histórico 1.0, `has_credits` sem origem inventada, seis testes focais PASS. Não cria estratégia paralela nem cota fictícia por projeto.
- Leitura `2026-09-06T01:48:37Z`: 98% usado/2% restante, saldo 2.500 finito, três resets não consumidos. Decisão `codex-usage-d8389a7b42f1a30e` schema-válida/twin byte-idêntico; reserva de 10% não preservada, `CRITICAL_RESERVE`.
- QR Dolar confirmou registro próprio; monitor diário existente atualizado, preservando prompt anterior/horário. Sem monitor novo, compra, recarga, reset, mudança de modelo/esforço ou interrupção local.
- Política cooperativa não impõe hard cap nem garante duração ilimitada. Detalhes em `docs/CODEX_SHARED_CAPACITY_POLICY.md`.

## D-001 — Uso interno antes do produto

- Status: aceito.
- Decisão: operar e validar canais próprios antes de comercializar o sistema.
- Razão: criar prova, aprender com falhas reais e não vender um processo não utilizado.

## D-002 — Produção clip-based como modo principal

- Status: aceito.
- Decisão: priorizar recortes e montagem, evitando geração integral cara quando desnecessária.
- Condição: origem, direitos, transformação editorial e rastreabilidade devem passar pelos gates.

## D-003 — Mineração profunda

- Status: aceito.
- Decisão: analisar hook em janelas, take por take, transcrição, OCR, narrativa, embalagem, áudio, ritmo e evidências.

## D-004 — Execução por fases

- Status: aceito.
- Decisão: nenhuma implementação monolítica. Cada fase termina em revisão e exige autorização para avanço.

## D-005 — Local-first

- Status: aceito.
- Decisão: ferramentas locais e gratuitas são preferidas; providers pagos são opcionais e dependem de aprovação.

## D-006 — Ausência de porcentagem automática

- Status: aceito como restrição técnica.
- Decisão: não declarar que uma porcentagem de mudanças garante originalidade, direitos ou monetização. Usar critérios verificáveis de nova narrativa, contribuição editorial e direito de uso.

## D-007 — Integrações depois do domínio

- Status: aceito.
- Decisão: CLI e módulos testáveis primeiro; n8n, MCP, skills e plugin entram quando o fluxo correspondente estiver estável.

## D-008 — Incorporação sem sobrescrita

- Status: implementado na Fase 0, aguardando revisão.
- Decisão: preservar o `README.md` operacional e instalar o README do kit como `docs/KIT_README.md`.
- Razão: os dois documentos têm funções diferentes e a sobrescrita apagaria o estado real do HERO Engine.

## D-009 — Baseline legado não equivale a fase aprovada

- Status: implementado na Fase 0, aguardando revisão.
- Decisão: preservar código, banco, modelos, EDLs e renders existentes como baseline; não classificá-los automaticamente como entregas aprovadas pelos novos schemas.
- Razão: os artefatos funcionam em seu contrato anterior, mas não possuem a estrutura e os gates do kit mestre.

## D-010 — Conflito de direitos bloqueia produção

- Status: proposto; decisão humana pendente.
- Decisão proposta: quando houver histórico contraditório de licença, usar provisoriamente o estado mais restritivo e impedir download/render até revisão responsável e evidência reconciliada.
- Evidência: `5-zdruoQKlM` possui registros `verified_cc`, `not_verified` e `indeterminate` no banco local.

## D-011 — Aprovação da Fase 0 e autorização da Fase 1

- Status: aceito pelo usuário em `2026-09-02`.
- Decisão: os entregáveis verificáveis da Fase 0 foram aceitos; a Fase 1 está autorizada.
- Limite: a aprovação não autoriza fases posteriores, publicação, gasto ou escolha silenciosa dos vídeos do padrão-ouro.

## D-012 — Amostra proposta para o padrão-ouro longo

- Status: aceita pelo usuário em `2026-09-02` pela autorização “pode continuar”.
- Decisão: anotar `hkf6nDyUfAM`, `_sOy7htXJi8`, `Pkede5acSFw` e `huvUy3pJSp8` como vencedor principal, vencedor recente, mediano e fraco.
- Razão: contraste de views/dia, cobertura de `210–285 s`, mesmo canal/nicho/idioma e inclusão obrigatória de contraexemplos.
- Limite: a seleção é para análise; nenhum estado de produção ou direito é presumido.

## D-013 — Inteligência Contínua Viva como requisito complementar

- Status: incorporado por determinação do usuário em `2026-09-02`; impacto aguardando revisão.
- Decisão: preservar integralmente `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md` como complemento, sem substituir regras, fases, schemas, decisões ou implementações anteriores.
- Evidência: hash de origem e destino `44FC5992089CF9265ECF5EC5A9EE11F81BBCBB039070C596B29A1B2AB0D92EE6`.
- Limite: incorporação documental não autoriza implementação.

## D-014 — Encaixe faseado da Inteligência Contínua

- Status: proposto; aprovação do usuário pendente.
- Decisão proposta: distribuir proveniência, ledger, observadores, hipóteses, experimentos, regras, aplicação e monitoramento pelas Fases 1–8 conforme `docs/CONTINUOUS_INTELLIGENCE_PLAN.md`, sem criar fase paralela.
- Razão: preservar os gates existentes e impedir arquitetura genérica prematura.
- Retomada: após aprovação, voltar à Fase 1 no gate da amostra D-012; não avançar para a Fase 2.

## D-015 — Inteligência Contínua como Gestor Central de toda a operação

- Status: aceito pelo usuário em `2026-09-02` após revisão da incorporação.
- Decisão: a Inteligência Contínua Viva é o Gestor Central Autônomo de 100% da operação e a única fonte de verdade, comando, prioridade, aprendizado e estado operacional.
- Subordinação: módulos, agentes, subagentes, workflows, plugins e integrações executam comandos do Gestor; nenhum mantém estratégia ou memória concorrente.
- Evidência: `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`, preservado com SHA-256 `2BC7AB5DCD7F109F79EF53874143DC0D8C45C1A917C6C60E4967997661984D85`.
- Limite: incorporação documental não autoriza implementação, avanço de fase, publicação ou gasto.

## D-016 — Autonomia por envelope e supervisão por exceção

- Status: aceita contratualmente pelo usuário em `2026-09-02`; implementação permanece faseada.
- Decisão proposta: o Gestor executará rotinas somente dentro de um envelope operacional versionado; ações protegidas, exceções e mudanças estratégicas serão bloqueadas e escaladas ao proprietário.
- Regra de segurança: o Gestor não pode aprovar a própria exceção nem usar autonomia para contornar fase, direitos, custo, credenciais, publicação, identidade, política, exclusão ou mudança de objetivo.
- Contrato: `docs/GESTOR_CENTRAL_AUTONOMY_MATRIX.md` e `schemas/operational_envelope.schema.json`.

## D-017 — Fonte única de verdade, comando único e concorrência controlada

- Status: aceita contratualmente pelo usuário em `2026-09-02`; implementação permanece faseada.
- Decisão proposta: adotar estado global e por canal, ledger append-only, fila central, lock/leader election, idempotência, checkpoints, dead-letter queue, replay, rollback e cadeia completa de comando.
- Migração: SQLite continua no piloto; qualquer migração para PostgreSQL exige evidência de concorrência/escala e nova aprovação.
- Contrato: `docs/GESTOR_CENTRAL_ARCHITECTURE.md` e schemas draft `central_manager`, `central_command` e `operational_envelope`.

## D-018 — Aprendizado comprovável e previsibilidade calibrada

- Status: aceita contratualmente pelo usuário em `2026-09-02`; implementação permanece faseada.
- Decisão proposta: nenhuma regra será promovida sem ciclo completo, previsão pré-registrada, resultado fora da amostra e nova aplicação medida; ausência de dado novo gera `NO_NEW_EVIDENCE`.
- Estados: `CANDIDATE`, `TESTING`, `SUPPORTED_LOCAL`, `TRANSFER_CANDIDATE`, `SUPPORTED_GENERAL`, `INCONCLUSIVE`, `SUSPENDED` e `REJECTED`.
- Previsibilidade: comparar sempre com baseline simples e medir MAE/MAPE quando aplicável, cobertura de intervalo, Brier/log loss para probabilidades e uplift contra baseline.
- Contrato: `docs/GESTOR_CENTRAL_LEARNING_AND_PREDICTABILITY.md` e schemas draft de ciclo, previsão e scorecard.

## D-019 — Correção distribuída pelas fases existentes

- Status: aceita pelo usuário em `2026-09-02`.
- Decisão proposta: incorporar o Gestor Central incrementalmente nas Fases 1–8, sem criar fase paralela. A Fase 1 recebe apenas os contratos de proveniência e padrão-ouro necessários à medição futura da qualidade do minerador.
- Retomada: após aprovação desta revisão, retornar ao gate D-012 da Fase 1. Fase 2 permanece `NOT_STARTED`.

## D-020 — Padrão-ouro da Fase 1 submetido ao gate

- Status: implementado e validado em `2026-09-02`; aprovação do proprietário pendente.
- Decisão executada: materializar a amostra D-012 como benchmark manual com 4 vídeos, 256 takes, 25 segmentos narrativos, 16 janelas de hook, transcrição bruta/revisada e evidência temporal resolvível.
- Validação: 4/4 documentos válidos no Draft 2020-12; 0 falhas de schema; 0 evidências ausentes; 21/21 testes do projeto aprovados.
- Direitos: todos os ativos permanecem `EDITORIAL_REVIEW_REQUIRED` e `production_eligible=false`; a análise não os transforma em biblioteca de produção.
- Evidência: `docs/PHASE_1_REPORT.md`, `data/gold_standard/validation_report.json` e `data/gold_standard/integrity_manifest.json`.
- Limite: Fase 2, runtime do Gestor Central, produção, publicação e gasto não foram autorizados nem iniciados.

## D-021 — Aprovação da Fase 1 e autorização da Fase 2

- Status: aceito pelo usuário em `2026-09-02`.
- Decisão: a mensagem “continue e faça com perfeição”, enviada após o relatório e o estado `AWAITING_REVIEW`, aprova o gate da Fase 1 e autoriza somente a Fase 2.
- Escopo: minerador automático nas quatro fixtures, comparação champion/challenger, schema, evidências, idempotência, falhas e recursos.
- Limite: Fase 3, catálogo em lote, ChannelDNA, Gestor runtime, produção, publicação e gastos não são autorizados.

## D-022 — OCR local substituível na Fase 2

- Status: decisão reversível de implementação da Fase 2.
- Decisão: usar `rapidocr==3.9.2` com ONNX Runtime CPU atrás de adapter local; Tesseract está ausente.
- Razão: provider gratuito, local, Apache-2.0, com modelos empacotados e sem credencial/API.
- Limite: OCR é evidência automática com confiança, não verdade humana; falha ou baixa confiança deve permanecer explícita.

## D-023 — Minerador automático da Fase 2 submetido sem promoção

- Status: implementado e validado em `2026-09-02`; aprovação do proprietário pendente.
- Decisão executada: manter o padrão-ouro humano como champion nas quatro fixtures e registrar 4× `KEEP_CHAMPION`.
- Evidência positiva: 4/4 runs `COMPLETE`; 4/4 replays idempotentes; timestamps, ASR, hooks, takes, direitos, schema, custo, latência e consistência aprovados em 4/4; 33/33 testes passam; 0 regressões críticas.
- Divergências preservadas: OCR 0/4, narrativa 0/4 e embalagem 3/4 nos thresholds do benchmark.
- Custo: API externa observada em `US$ 0,00`; eletricidade e depreciação local não precificadas.
- Evidência: `docs/PHASE_2_REPORT.md`, `output/mining/phase2/active_run.json`, `output/mining/phase2/benchmarks/summary.json` e `output/mining/phase2/integrity_manifest.json`.
- Limite: não autoriza Fase 3, promoção automática, produção, publicação, Ads, gasto ou relaxamento do gate de direitos.

## D-024 — Reabertura da Fase 2 para qualidade e aprendizado do minerador

- Status: aceito pelo usuário em `2026-09-02`.
- Decisão: retornar a Fase 2 para `IN_PROGRESS` e executar novo ciclo champion/challenger limitado aos campos falhos.
- Regra: preservar baseline e thresholds; pré-registrar hipóteses antes da implementação; registrar ganho, perda, custo, contradição e incerteza; não promover automaticamente.
- Aprendizado autorizado: qualidade do próprio minerador contra o gold standard, conforme o bloco da Fase 2 do Gestor Central.
- Limitação: as quatro fixtures são regressão de desenvolvimento, não holdout; resultado não prova generalização.
- Fora de escopo: Fases 3–8, aprendizado operacional de canal, publicação, produção, Ads, gasto e runtime central.

## D-025 — Aprovação técnica da Fase 2 e seleção do minerador 0.2.0

- Status: aceito sob autorização condicional expressa do proprietário em `2026-09-02`.
- Decisão: selecionar `miner-local-0.2.0` como executor da Fase 3 após 48/48 métricas aprovadas, 38/38 testes, 4/4 replays, revisão visual 5/5 e 0 regressões críticas.
- Aprendizado: OCR, narrativa e packaging são `SUPPORTED_LOCAL`; nenhuma alegação de generalização foi feita.
- Evidência: `docs/PHASE_2_IMPROVEMENT_REPORT.md`, `output/mining/phase2/learning/cycle-001/outcome.json` e `output/mining/phase2/integrity/miner-local-0.2.0.json`.
- Limite: direitos de produção continuam bloqueados; validação fora da amostra é obrigação da Fase 3.

## D-026 — Válvula de aceleração não confunde Ads com progresso do YPP

- Status: requisito permanente incorporado por solicitação do proprietário em `2026-09-02`.
- Decisão: Promote não será o acelerador principal, pois horas, inscritos e views de Shorts originados de campanhas não contam para thresholds do YPP e promoções não alteram performance orgânica.
- Estratégia: quando a Fase 6 e um orçamento forem autorizados, preferir experimento controlado via Google Ads com `follow-on views`, controle/holdout, incrementalidade, teto e stop-loss; Promote pode ser apenas smoke test.
- RPM: otimizar somente com dados monetários reais do canal próprio após YPP; proxies pré-YPP ficam `INFERRED` ou `UNAVAILABLE`.
- Contrato: `docs/12_ACQUISITION_ACCELERATOR_MASTER.md` e `schemas/acquisition_experiment.schema.json`.
- Limite: esta decisão não autoriza anúncio, gasto, credencial, publicação ou mudança de nicho.

## D-027 — Autorização condicional de progressão até o final

- Status: aceito pelo usuário em `2026-09-02`.
- Decisão: o proprietário autorizou continuar pelas fases seguintes sem nova pergunta somente quando a fase anterior estiver integralmente executada, revisada e aprovada por evidência.
- Regra: cada fase continua tendo preflight, plano, implementação, testes, relatório e gate; falha ou bloqueio impede avanço automático.
- Limite: a autorização de progressão não autoriza ações protegidas independentes, especialmente gasto, Ads, publicação, uso de credenciais, direitos, exceções de política ou mudança estratégica.

## D-028 — Aprovação técnica da Fase 3 e promoção do observatório v2

- Status: aceito sob autorização condicional D-027 em `2026-09-02`.
- Decisão: aprovar a Fase 3 somente após substituir o escopo v1 de `/videos` pelo lote v2 com `/videos` + `/shorts` e reconciliar o HeroVerse em 1 long-form + 20 Shorts.
- Evidência: 130 snapshots, 143 registros de cobertura, 5 coortes, 13 holdouts de abertura, 49/49 testes e SQLite `integrity_check=ok`.
- Rastreabilidade: `docs/PHASE_3_REPORT.md` e `output/observatory/phase3/phase3-2026-09-02-catalog-v2/`.
- Limite: dados públicos não substituem Studio, YPP, receita ou RPM; nenhuma causalidade foi promovida.

## D-029 — Ausência de aba é erro observável, não zero inferido

- Status: implementado na Fase 3.
- Decisão: quando uma aba pública não existir, preservar os vídeos obtidos na outra aba, marcar o snapshot de canal como `PARTIAL` e registrar erro tipado; não inferir histórico inexistente.
- Evidência: quatro ausências de aba Shorts registradas no lote v2; 0 falhas de vídeo e 0 tentativas de contornar acesso.

## D-030 — Início condicional da Fase 4

- Status: autorizado em `2026-09-02` pela combinação do gate integral da Fase 3 com D-027.
- Decisão: iniciar somente o preflight/modelador da Fase 4, usando coortes e cobertura v2; dados `OPENING_ONLY` e `METADATA_ONLY` não podem sustentar alegações de narrativa completa.
- Limite: produção, piloto, publicação, Ads, gasto, credenciais, licença e aprovação de arquétipo continuam fora de escopo.

## D-031 — Modelador v1 submetido ao gate humano

- Status: implementado e `AWAITING_REVIEW` em `2026-09-02`.
- Decisão técnica: apresentar somente `A-LONG-DIRECT-SPIRITUAL-STAKES-V1`; não inventar arquétipo de Shorts a partir de metadados.
- Evidência: 24 vídeos de população, coortes 6/12/6, 16 openings, 13 holdouts e 4 narrativas completas; 60/60 testes.
- Scores: repeatability 0,785417; profundidade 0,5375; validação completa cross-channel 0; evidência de RPM 0; confiança do arquétipo 0,408248.
- Recomendação: aprovar o arquétipo somente para piloto controlado, não para escala.
- Limite: somente o proprietário pode concluir o gate do arquétipo; Fase 5, produção, direitos, publicação e gasto permanecem bloqueados.

## D-032 — Aprovação condicionada do arquétipo para piloto da Fase 5

- Status: aceito pelo proprietário em `2026-09-02`.
- Decisão: aprovar `A-LONG-DIRECT-SPIRITUAL-STAKES-V1` somente para um piloto controlado da Fase 5; confiança continua `0,408248` e não autoriza escala.
- Condição: o arquétipo é uma gramática de mecanismos, não um template congelado. Nicho e gates são rígidos; tema, ângulo, embalagem, hook, ritmo e visuais são adaptativos.
- Evidência: `output/modeling/phase4/phase4_approval_receipt.json` e SHA-256 do modelo `EC3A6E...B15F7`.
- Limite: publicação, gasto, Ads, credenciais e exceção de direitos permanecem bloqueados.

## D-033 — Visualizações normalizadas e sinais atuais norteiam a linha editorial

- Status: requisito permanente aceito pelo proprietário em `2026-09-02`.
- Decisão: toda produção nasce de ranking contemporâneo de oportunidades; visualizações e velocidade são normalizadas por idade, formato, canal e baseline comparável, combinadas com novidade, convergência, saturação, profundidade de evidência e risco.
- Hook: gates separados em `0–1 s`, `1–3 s` e `3–8 s`; título e thumbnail formam uma promessa única e entregável.
- Originalidade: modelar função, timing e mecanismo; não copiar redação, identidade, voz, sequência ou obra específica.
- Aprendizado: `VIRAL_CANDIDATE` é hipótese; resultado viral só existe após publicação e medição própria. Sem novos dados, registrar `NO_NEW_EVIDENCE`.
- Contrato: `docs/13_ADAPTIVE_VIRAL_EDITORIAL_ENGINE.md`.

## D-034 — Diretor Criativo subordinado e FormatPack como gate de capacidade

- Status: requisito permanente incorporado em `2026-09-02`.
- Decisão: criar o Diretor Criativo como executor especializado do Gestor Central, sem estratégia, memória ou autoridade paralela. Toda escolha deve derivar de ChannelDNA, público, nicho, narrativa, orçamento, objetivo, evidência, capacidade e hipótese de desempenho.
- Contrato: `docs/15_CREATIVE_DIRECTION_MASTER.md` e `schemas/format_pack.schema.json`.
- Estados: `CATALOGED`, `SPECIFIED`, `PROTOTYPED`, `VALIDATED`, `PRODUCTION_READY`, `LIMITED`, `BLOCKED`, `DEPRECATED`.
- Gate: produção regular usa somente `PRODUCTION_READY`; `LIMITED` somente dentro de restrições. `VALIDATED` ainda não equivale a prontidão operacional.
- Migração: 291 entradas preservadas; 290 `CATALOGED`; `cinematic_documentary_nature_broll-v1` migra para `fp-broll-cinematic-narration@1.0.0` em `SPECIFIED`; zero capacidade pronta.
- Qualidade: 18 gates aplicáveis, sem compensação por média; decisão, Style Bible, TakePlan e evidência take a take são obrigatórios.
- Limite: a incorporação não declara suporte universal, não instala ferramenta paga, não publica e não pula a Fase 5.

## D-035 — Continuação técnica automática após a incorporação

- Status: autorizado expressamente pelo proprietário em `2026-09-02`.
- Decisão: após fechar os contratos, continuar CD-1 em diante sem solicitar confirmação a cada etapa técnica, sempre respeitando fase, evidência e gates.
- Regra: a autorização não permite autoaprovação de revisão humana, publicação, gasto, credenciais, direito, política, mudança estratégica ou promoção de FormatPack sem testes.
- Consequência: a Fase 5 permanece `IN_PROGRESS` durante o runtime, protótipo e QA; qualquer falha crítica gera bloqueio explícito, não relaxamento.

## D-036 — Hook visual imediato e duração frame-locked

- Status: implementado no protótipo da Fase 5 em `2026-09-02`.
- Decisão: usar voz curta “Amen.” em 0–1 s e promessa visual “AMEN ISN'T THE END” no primeiro quadro; toda duração de take precisa ser exatamente representável a 30 fps.
- Evidência: tempos medidos de 0,875 s, 1,792 s e 4,715 s nas três primeiras janelas; render final com 7.572 frames, 0 ms de erro por take e 0 ms de deriva acumulada.
- Razão: o primeiro ensaio mostrou que arredondamento por segmento acumulava quase 1 s de dessincronização visual; o pipeline agora falha se uma duração não for representável ou exceder meio frame de erro.
- Limite: timing aprovado não prova força do hook; o gate perceptivo permanece `NEEDS_REVIEW`.

## D-037 — Fonte visual também passa por gate de conteúdo e fronteira de plano

- Status: implementado no protótipo da Fase 5 em `2026-09-02`.
- Decisão: black/freeze e licença não bastam. Cada ativo recebe intervalos seguros que não atravessam fronteiras de plano detectadas; ativo com texto/contexto incompatível é bloqueado mesmo quando licenciado.
- Evidência: `asset-commons-5e179ec59754f50784` foi bloqueado por texto documental/trecho estático e substituído por ativo CC BY 4.0; 44/44 alocações finais cabem integralmente em intervalos seguros.
- Verificação: render final com zero black frame, zero freeze, zero transição dura não planejada e p95 de luminância intra-take 7,928945.
- Limite: detecção automática não substitui julgamento semântico e de publicity.

## D-038 — Primeiro FormatPack promovido somente a PROTOTYPED

- Status: implementado e submetido a revisão em `2026-09-02`.
- Decisão: promover `fp-broll-cinematic-narration@1.0.0` de `SPECIFIED` para `PROTOTYPED`, mantendo `production_allowed=false`.
- Evidência: render `render-c3fc1b1301f61f67f67c`, QA `creative-qa-c1f266b64c5d3d7f7e4e`, Style Bible, TakePlan, manifesto de direitos, áudio e relatório técnico.
- Resultado automático: nenhum FAIL; PUBLICATION BLOCKED; nove gates perceptivos/legais em `NEEDS_REVIEW`.
- Regra: o próprio gerador não pode preencher revisão humana independente. `VALIDATED`, `PRODUCTION_READY`, publicação e Fase 6 continuam bloqueados.

## D-039 — Reabertura criativa da Fase 5 e autorização condicional de publicação

- Status: aceita pelo proprietário em `2026-09-02`.
- Decisão: rejeitar o patamar criativo do DRAFT v1 e reabrir a Fase 5 para uma revisão `creative-v2` baseada em defeitos observados por timecode/take, preservando o v1 como baseline imutável.
- Correção exigida: hook audiovisual, causalidade entre fala e imagem, motivo visual proprietário, ações humanas concretas, tipografia, sound design, ritmo, embalagem e identidade passam a ter contratos e evidências antes/depois; “mais bonito” não é critério.
- Autorização protegida: o proprietário autorizou conexão e publicação somente depois de todos os gates críticos, direitos, política, FormatPack e revisão humana independente passarem. A autorização não permite publicar DRAFT, pular a Fase 5, autoaprovar revisão humana ou executar gasto/Ads.
- Credenciais: o fluxo OAuth pode ser preparado, mas nenhum segredo será criado, inferido, gravado no repositório ou coletado pelo chat; autenticação depende de credencial legítima do proprietário ou sessão Studio já autenticada.
- Evidência planejada: `docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md` e `output/production/phase5/pilot-001/creative-v2/`.

## D-040 — Creative-v2.1 submetido à revisão humana sem autoaprovação

- Status: implementado e `AWAITING_REVIEW` em `2026-09-02`.
- Decisão: substituir o candidato v1 rejeitado pelo render `creative-v2.1`, mantendo o FormatPack em `PROTOTYPED` e `production_allowed=false`.
- Evidência criativa: 11/11 contratos PASS; 5 eventos em 0–8 s; 8 em 8–30 s; take corporal máximo 6 s; pattern interrupt máximo 21,3 s; 5/5 ações concretas visualizadas; 13 ativos distintos; nenhuma repetição consecutiva fora do hook; maior recorte de terceiro 14,4231%.
- Evidência técnica: 135,2 s, 4.056 frames, 0 ms de drift, zero black/freeze/corte duro intra-take, -16,15 LUFS, -1,30 dBTP, direitos 13/13 e originalidade 0,006154.
- Correção comprovada: o freeze gate reprovou 0,866667 s e 1,9 s no hook; a derivação visual foi versionada, o render recebeu novo hash e o mesmo gate retornou zero sem alteração de limite.
- Bloqueio: nove gates perceptivos/legais permanecem `NEEDS_REVIEW`; `PUBLICATION` continua `BLOCKED`. O Gestor e o Diretor Criativo não podem preencher a revisão humana independente.
- Próximo passo: o proprietário revisa o vídeo completo. Somente após aprovação expressa do artefato exato começa a conexão/autenticação e a publicação condicionalmente autorizada; Ads/gasto permanecem proibidos.

## D-041 — Integração OAuth antecipada sem antecipar publicação

- Status: autorizada pelo proprietário em `2026-09-03`; consentimento Google ainda pendente.
- Decisão: antecipar somente a conexão técnica do canal e dos adaptadores YouTube Data API, YouTube Analytics API, upload e thumbnail, sem alterar o gate editorial da Fase 5.
- Identidade: a conta autorizada deve resolver exatamente para o mesmo channel ID retornado pelo handle `@heroverse74`; divergência falha fechada e nenhum dado é aceito.
- Segurança: cliente e token OAuth permanecem fora do workspace; nenhum segredo entra em log, receipt ou Git. O app OAuth local está em modo de teste/não verificado, portanto o aviso do Google exige confirmação humana específica antes de continuar.
- Escopos: `youtube.readonly`, `yt-analytics.readonly` e `youtube.upload`; o escopo monetário não é solicitado antes de necessidade/YPP.
- Travas independentes: OAuth válido não libera upload. `publish_mode=dry-run`, revisão humana pendente, FormatPack `PROTOTYPED` e `publication_eligible=false` continuam bloqueando qualquer chamada de publicação.
- Artefatos: `config/integrations/youtube-heroverse-v1.json`, `schemas/youtube_connection_receipt.schema.json`, `hero_engine/youtube_integration.py`, `scripts/connect_youtube.py` e `creative-v2/publication_package.json`. A integração foi isolada do CLI congelado da Fase 2 após a regressão detectar a primeira tentativa como drift não registrado.
- Limite: não aprova o render, não inicia a Fase 6, não publica, não agenda, não anuncia e não autoriza gasto.

## D-042 — Creative-v2.1 reprovado na auditoria crítica de mercado

- Status: registrado em `2026-09-03`; candidato rejeitado para publicação, sem substituir revisão humana independente.
- Decisão: não aceitar contagem de eventos, limpeza técnica ou estética coerente como prova suficiente de hook, identidade, equivalência de mercado ou potencial viral.
- Hook: `Amen.` em 0–1 s não cumpre H1/I2; `Now what?` em 1–3 s não cumpre H2; as três janelas de 0–8 s usam um único ativo visual.
- Fidelidade: 135,2 s fica 72,55 s e 34,9218% abaixo do mínimo de 207,75 s do arquétipo aprovado.
- Visual: 104,5 s/135,2 s, ou 77,2929%, são paisagens dominantes; a repetição semântica cria stock montage genérico e não identidade HeroVerse de primeira linha.
- Contexto: `asset-commons-fa53a5884174e4e27c` tem licença pública válida, mas provenance ligada a investigação sobre Jeffrey Epstein; direitos não compensam contexto editorial incompatível.
- Acessibilidade: zero faixas `.srt`, `.vtt` ou `.ass`, contrariando o gate de captions da GenerationSpec.
- Embalagem/desempenho: thumbnail limpa, porém sem challengers ou CTR próprio; CTR, retenção, RPM e resultado viral permanecem `UNAVAILABLE`.
- Evidência: `docs/PHASE_5_MARKET_AND_VIRAL_REVIEW.md` e `creative-v2/qa/market_readiness_review.json`.
- Consequência: Fase 5 continua `AWAITING_REVIEW`; o render é baseline rejeitado. OAuth, upload, publicação, Ads e Fase 6 continuam bloqueados até nova versão e todos os gates.

## D-043 — Integração YouTube conectada e identidade fixada

- Status: concluída e verificada em `2026-09-03` após autorização expressa do proprietário.
- Identidade: `HeroVerse`, handle `@heroverse74`, channel ID `UCuMF6pJQkyMzaVoAxFL86yA`; esperado e observado coincidem.
- OAuth: token válido e renovável armazenado fora do workspace; três escopos concedidos: leitura do canal, Analytics próprio e upload.
- Prova: Data API `CHANNEL_READ=CONNECTED`; Analytics API `ANALYTICS_READ=CONNECTED`; probe de 28 dias retornou 26 linhas; segunda execução sem interação reutilizou o token.
- Pinning: configuração, script, schema/pacote de publicação e testes usam o channel ID real; divergência futura falha fechada.
- Publicação: escopo de upload e thumbnail está `CONFIGURED_BLOCKED`; `dry-run`, revisão humana, FormatPack `PROTOTYPED` e candidato reprovado preservam `upload_permitted=false`.
- Monetização: escopo monetário não foi solicitado antes de YPP/necessidade; não há RPM ou receita disponíveis.
- Evidência: `docs/YOUTUBE_INTEGRATION_REPORT.md`, `output/integrations/youtube/heroverse/connection-receipt.json` e `creative-v2/publication_package.json`.
- Limite: integração da Fase 5 concluída não equivale ao runtime autônomo contínuo da Fase 6 e não aprova vídeo, upload, publicação, Ads ou gasto.

## D-044 — Conexão atual não equivale a durabilidade operacional

- Status: registrado em `2026-09-03` após inspeção autenticada do Google Auth Platform.
- Decisão: manter `connection_status=CONNECTED`, mas declarar `continuous_operation_ready=false` e `durability_status=TIME_LIMITED_TESTING` enquanto o app OAuth estiver em Testing.
- Evidência: Google Auth Platform impede `Publish app` com branding incompleto; faltam homepage, privacy policy e terms públicos. A documentação Google registra validade de sete dias do refresh token de app externo em Testing com escopos não básicos.
- Done when: páginas legais verdadeiras em domínio controlado, branding completo, app em produção, eventual verificação atendida, reautorização e prova de refresh não interativo.
- Consequência: integração funciona agora, mas não sustenta coordenação contínua confiável. Nenhum segredo foi movido ao workspace e nenhum upload foi liberado.

## D-045 — Channel Readiness é gate permanente e perfil foi remediado com verificação

- Status: implementado parcialmente e `AWAITING_REVIEW` em `2026-09-03`.
- Decisão: todo pacote de publicação passa a consumir um Channel Readiness Audit atual; vídeo aprovado não compensa canal incoerente.
- Mudanças live verificadas: descrição sem promessa diária falsa; palavras-chave aderentes ao ChannelDNA; localização inglesa que carregava “Paz e Clareza / Iron Discipline” alinhada; Home ativa e publicamente preenchida.
- Fail-closed: uma primeira ativação da Home exibiu estado público vazio e foi revertida; a segunda só foi mantida após reload público mostrar Home, For you, Videos e Shorts.
- Marca: pack `heroverse-brand-assets@2.0.0` foi criado e passou dimensões/safe area, mas permanece `PROTOTYPED`, não aplicado, aguardando revisão visual independente.
- Catálogo: 21/21 vídeos públicos foram registrados; quatro participam de duplicação de packaging, cinco têm claim sensacionalista e três identidade legada. Direitos e transformação permanecem `UNAVAILABLE`, portanto zero autoaprovação e zero remoção automática.
- Desempenho: 2.637 views, 1.024 minutos e 50 inscritos líquidos nos 90 dias; YPP oficial 265 inscritos, 0 horas públicas e 1.200 Shorts qualificados. O objetivo de anúncios em 30 dias exige 44,1x a taxa de inscritos ou aproximadamente 24.997x a taxa qualificada de Shorts observada; não é previsão.
- Custo/capacidade: Codex Pro com 2% semanal usado/98% restante no snapshot; gasto externo iniciado USD 0; o crédito de reset não foi consumido.
- Prova técnica: 88/88 testes; manifesto da Fase 5 com 278 itens e 1.363.657.997 bytes, todos cobertos por SHA-256.
- Bloqueio: marca, catálogo, YPP, política, OAuth durável e novo vídeo continuam abertos; nenhum upload/publicação/Ads.

## D-046 — Retomada integral da Fase 5 e autorização dos ativos de marca exibidos

- Status: autorizado pelo proprietário em `2026-09-03`.
- Decisão: reabrir a Fase 5 para executar todas as correções necessárias até um novo checkpoint verificável. Como a prévia exata de `heroverse-brand-assets@2.0.0` foi exibida imediatamente antes do comando “continue”, os três ativos versionados podem ser aplicados e verificados no canal.
- Escopo: marca pública, auditoria do catálogo, remediação criativa e novo candidato do arquétipo long-form já aprovado.
- Preservação: baselines v1 e `creative-v2.1`, ChannelDNA, direitos, modo clip-based, custo externo zero, Channel Readiness e Quality Gates não são relaxados.
- Limites: autorização ampla de continuidade não transforma dado ausente em direito aprovado, não libera o candidato rejeitado, não autoriza Ads/gasto e não altera o fato de que Fase 6 permanece `NOT_STARTED`.

## D-047 — Execução contínua integral com progressão automática por evidência

- Status: autorizado expressamente pelo proprietário em `2026-09-03`.
- Decisão: pré-autorizar as Fases 5–8 em sequência. A conclusão de uma fase promove a próxima automaticamente somente quando todos os critérios aplicáveis passarem com artefatos, testes e receipts; `AWAITING_REVIEW` não é mais uma parada inter-fases.
- Tratamento de falhas: `FAIL` gera diagnóstico, correção versionada, reteste e comparação; `BLOCKED` externo não paralisa frentes independentes. O gate não pode ser rebaixado para viabilizar avanço.
- Revisão humana: a aprovação administrativa entre fases foi removida; permanecem revisão humana de padrão-ouro, direito, política ou julgamento externo quando exigidas por requisitos anteriores. O gerador não se autoavalia como revisor independente.
- Ações externas: upload/publicação sem gasto estão autorizados se todos os gates críticos, direitos, identidade do canal, credenciais e receipt passarem. Ads, ferramenta paga, serviço cobrado ou qualquer gasto continuam bloqueados até orçamento explícito.
- Preservação: baselines e artefatos aprovados são imutáveis; mudanças estruturais exigem migração, regressão e rollback. Métricas, YPP, RPM, viralidade e previsibilidade continuam sem garantia.
- Evidência inicial: banner, avatar e watermark v2 foram salvos no Studio; watermark configurada para todo o vídeo. O Studio reaberto mostra os novos ativos, mas a página pública ainda exibia banner anterior na primeira checagem, portanto a marca permanece `PROPAGATION_PENDING`, não `VERIFIED_PUBLIC`.

## D-048 — vidIQ somente como adaptador auxiliar e fail-closed

- Status: contrato incorporado em `2026-09-03`; plugin ainda `NOT_INSTALLED` e não conectado.
- Decisão: aceitar vidIQ como fonte auxiliar versionada de descoberta de temas, concorrentes, queries e hipóteses de embalagem quando houver capacidade real instalada e validada. Ele nunca substitui YouTube Data API, YouTube Analytics, YPP oficial, direitos, originalidade, ChannelDNA, Quality Gates ou revisão humana.
- Verdade atual: não existe ferramenta vidIQ chamável nesta sessão; a sugestão de instalação não retornou receipt de instalação/conexão. Nenhum score, dado, recomendação, custo ou métrica vidIQ foi consumido ou alegado.
- Custo e privacidade: plano pago, trial com conversão ou gasto continuam proibidos sem orçamento explícito; escopos e tratamento de dados precisam ser revisados antes da conexão.
- Fallback: APIs oficiais do YouTube e observatório local permanecem operacionais e como fonte de verdade.
- Evidência: `config/tool_adapters/adapter-vidiq-plugin-v1.json` e `schemas/tool_adapter_profile.schema.json`.

## D-049 — creative-v3.1 passa remediação automática e segue bloqueado para publicação

- Status: implementado e verificado em `2026-09-03`; `READY_FOR_INDEPENDENT_HUMAN_REVIEW`.
- Decisão: substituir o candidato rejeitado `creative-v2.1` pelo artefato exato `creative-v3.1`, sem promover o FormatPack nem autoaprovar o padrão-ouro.
- Evidência do render: 238,7 s, 59 takes, 7.161 frames, 1920×1080/30 fps, 0 ms de deriva, zero black/freeze, -16,34 LUFS, -1,23 dBTP e SHA-256 `e1f45f019b2adfb398230fb2416a8b0f32da0c2ea58e5510c80721966ed743c8`.
- Correção objetiva: duração voltou à faixa do arquétipo; paisagem dominante caiu de 77,2929% para 17,5534%; o hook usa três fontes e sete eventos; existem 59 cues de captions com cobertura 1,0; 18/18 checks automáticos passam; fallback genérico de nuvens e ativo de contexto rejeitado estão ausentes.
- Embalagem: três thumbnails passam checks mecânicos; B é somente recomendação automática. Nenhuma foi selecionada sem revisão humana independente.
- Pacote: `creative-v3/publication_package.json` fixa render, candidato de thumbnail, captions, direitos, canal e integração por hash, mas mantém `upload_permitted=false`.
- Regressão: 100/100 testes aprovados; após adicionar o brief humano de thumbnails, o manifesto da Fase 5 foi reconstruído com 398 itens e 1.597.493.837 bytes, todos cobertos por SHA-256, e 13/13 testes focados passaram.
- Bloqueios: revisão humana audiovisual/captions/publicity/identidade, seleção de thumbnail, FormatPack `PROTOTYPED` e OAuth `TIME_LIMITED_TESTING`. Nenhum resultado viral, CTR, retenção ou RPM foi alegado.

## D-050 — vidIQ web validado como evidência auxiliar limitada

- Status: quatro consultas e uma amostra de 12 vídeos observadas em `2026-09-03`, sem custo externo e sem conectar o canal.
- Conta/superfície: vidIQ web autenticado, plano Free; identidade da conta não foi persistida no artefato. HeroVerse aparece `NOT_CONNECTED` e nenhuma permissão de terceiro foi concedida.
- Sinais: `christian motivation` = score 72/alto, volume 197.334/alto, competição 37,9/baixa; `christian motivation prayer` = 56/médio, volume 4.691/médio, competição 42/média; `what to do after prayer` e `faith in action` = score 0, volume abaixo de 750/muito baixo.
- Aplicação: preservar `Christian Motivation` no título como termo amplo observado e usar `after you pray / do this next` como promessa/hook editorial. Isso é racional de embalagem pré-publicação, não prova de CTR ou viralidade.
- Amostra competitiva: resultados exibem padrões de oração específica, tempo/urgência, proteção, ansiedade e promessa forte; vários usam linguagem extrema ou garantida que continua proibida pelo ChannelDNA e pelos gates.
- Limites: quatro países estavam selecionados, mas não foram identificados na captura; ordenação padrão não foi exposta; scores pertencem ao provedor; RPM, monetização privada e causalidade permanecem `UNAVAILABLE`.
- Evidência: `output/market/vidiq/heroverse/2026-09-03/research-observation.json`, `schemas/vidiq_research_observation.schema.json` e `config/tool_adapters/adapter-vidiq-web-v1.json`.

## D-051 — Qualificação STANDARD passa automaticamente com tolerância de replay explícita

- Status: implementado e verificado em `2026-09-03`; permanece bloqueado para produção/publicação.
- Candidato: 238,7 s, 7.161 frames, H.264/AAC 1080p30, 305.941.870 bytes e 9.991,923 kb/s; SHA-256 `1134a50f45fb7979ff83616d273cff87ecd59b7d2f5a8028a2ac945917dbf4c5`.
- Qualidade: -16,34 LUFS, -1,23 dBTP, zero black/freeze e SSIM 0,998247 contra o master DRAFT. Encodes observados em 563,648815 s e 602,045077 s, custo externo USD 0.
- Replay: a segunda codificação multithread não foi bit/pixel exata. Em vez de ocultar a divergência, o contrato registra os dois hashes e aprova somente equivalência mensurável: mesma duração/frames, áudio decodificado idêntico, variação de tamanho <=0,1% e SSIM >=0,995; observado 0,998095 e nove bytes.
- Decisão: `automatic_profile_status=PASS` não equivale a `STANDARD` aprovado. `overall_status=BLOCKED_PENDING_HUMAN_AND_EXTERNAL_GATES`, `production_approved=false` e `publication_eligible=false`.
- Bloqueios: revisão humana integral e independente, seleção de thumbnail, FormatPack ainda `PROTOTYPED` e OAuth `TIME_LIMITED_TESTING`.
- Recuperação: o receipt `replay_variance_incident.json` registra o FAIL inicial, diagnóstico com incerteza, correção, reteste, hash do master antes/depois e bloqueio de publicação.
- Regressão/integridade: 103/103 testes; 403 artefatos e 2.209.395.449 bytes cobertos por SHA-256.
- Evidência: `creative-v3/standard-qualification/standard_qualification_report.json`, `creative-v3/standard-qualification/replay_variance_incident.json`, schemas e testes dedicados.
- Publicação dry-run: o pacote agora fixa o candidato STANDARD e seu checklist humano pelo hash `1134a50f…dbf4c5`; não aponta mais para o DRAFT de bitrate inferior e continua com upload falso.

## D-052 — Pacote OAuth público preparado; deploy bloqueado por identidade e domínio externos

- Status: conteúdo local implementado e auditado em `2026-09-03`; publicação/produção OAuth ainda bloqueadas.
- Entrega: `deployment/oauth-compliance/` contém homepage, privacy policy, terms e CSS. A página explica os três escopos mínimos, finalidade, supervisão, revogação, retenção e limites sem prometer monetização.
- Automação: seis verificações de conteúdo passam; placeholders públicos, domínio verificado e HTTPS permanecem `BLOCKED`. `deployment_permitted=false` impede publicar uma identidade legal inventada.
- Requisitos oficiais: homepage pública e sem login, descrição do app e do uso de Google data, privacy vinculada e igual à do consent screen, termos, URLs em domínio próprio verificado e escopos mínimos.
- Inputs externos ausentes: nome exato do app no consent screen, nome legal público, email público de suporte, data efetiva e domínio do proprietário comprovadamente verificável.
- Consequência: todo trabalho local independente foi adiantado, mas `continuous_operation_ready=false` e `TIME_LIMITED_TESTING` continuam verdadeiros até o owner fornecer/resolver esses itens, configurar o Google Auth Platform e reautorizar.
- Evidência: `output/integrations/youtube/heroverse/oauth-public-site-readiness.json`, schema e teste dedicado; fontes oficiais registradas no receipt.

## D-053 — Google Auth Platform inspecionado e divergência de escopos detectada

- Status: inspeção autenticada somente leitura concluída em `2026-09-03`; nenhuma configuração foi alterada.
- Projeto/app: `graphic-tide-490010-u9`; app `Robo youtube`; suporte/contato `willmarquesfotografia@gmail.com`.
- Público: `EXTERNAL/TESTING`, um usuário de teste, `Publish app` desabilitado e configuração incompleta.
- Branding: homepage, privacy, terms e domínios autorizados vazios.
- Escopos: o console declara zero escopos nas três classes, enquanto o runtime pede `youtube.readonly`, `yt-analytics.readonly` e `youtube.upload`; `configuration_matches_runtime=false`.
- Cliente: um desktop client `Youtube bot`, criado em `2026-03-12`, com aviso visual de não utilizado. O receipt não atribui causalidade sem instrumentação adicional.
- Consequência: produção OAuth exige alinhar os três escopos no consent screen, concluir branding/domínio/HTTPS, publicar e cumprir eventual verificação. Até lá, `continuous_operation_ready=false`.
- Site local: nome do app, email de suporte e data efetiva foram preenchidos com valores observados; apenas nome legal público, domínio verificável e deployment HTTPS continuam externos.
- Evidência: `google-auth-platform-observation.json`, `oauth-public-site-readiness.json`, `operational-readiness.json`; 104/104 testes passam.

## D-054 — Transição OAuth para produção formalizada em nove passos fail-closed

- Status: plano materializado e validado em `2026-09-03`; nenhuma ação protegida live foi executada.
- Ordem: identidade pública -> domínio/Search Console -> HTTPS -> branding -> escopos -> verificação -> publicação do app -> reautorização -> refresh/reuso não interativo.
- Cada passo registra dependência, estado, ação, natureza protegida, evidência e reação à falha. A ordem impede publicar o app antes de branding, escopos e verificação.
- Preservação: o receipt e token atuais não são apagados; novo token só substitui o anterior após identidade e refresh; divergência de channel ID exige revogação do novo grant; incidentes não são apagados.
- Confirmações: mudança pública de branding, domínio, escopos, verificação, status e reautorização continuam protegidas no momento da ação. `protected_actions_authorized_now=false`.
- Evidência: `output/integrations/youtube/heroverse/oauth-production-transition-plan.json`, schema e teste dedicado; 105/105 testes passam.

## D-055 — Overlay vidIQ do catálogo próprio registrado sem promover causalidade

- Status: observação pública read-only concluída em `2026-09-03`; HeroVerse continua público com 265 inscritos, 20 Shorts e um long-form.
- Paridade: as 21 contagens de views coincidem com o snapshot API existente; não há novo resultado de audiência.
- Sinal auxiliar: sete Shorts exibem badge de outlier vidIQ e concentram 2.389/2.626 views de Shorts (90,9749%); máximo sem badge 44 views. Badge ausente é `UNAVAILABLE`, nunca zero.
- Mecanismos: reframe de dor, reversão de agência, urgência personalizada e interrupção por curiosidade. Identidade escolhida, ameaça, segredo garantido, ativos Marvel e intervenção divina certa continuam proibidos.
- Aplicação: `PRAYER ISN'T THE FINISH` + `AFTER YOU PRAY, DO THIS NEXT` alinham-se à reversão de agência com próximo passo concreto; status `PRE_PUBLICATION_HYPOTHESIS`.
- Limite: sinais são todos Short-form; transferência para 238,7 s long-form é não comprovada. Não existe CTR, retenção, RPM ou causalidade.
- Aprendizado: FormatPack recebe `NO_NEW_EVIDENCE`; versão, estado e confiança não mudam.
- Evidência: `output/market/vidiq/heroverse/2026-09-03/channel-outlier-observation.json`; 106/106 testes passam.

## D-056 — Revisão humana da Fase 5 passa a ser um receipt executável e fail-closed

- Status: implementado e validado em `2026-09-03`; receipt humano final ainda ausente.
- Decisão: substituir o transporte manual do checklist por um contrato estruturado preso ao qualification ID e ao SHA-256 exato do candidato STANDARD. O formulário exige nove janelas, doze gates humanos, reprodução integral/sequencial em 1×, áudio, captions, tela pequena, independência, attestation e seleção cega A/B/C.
- Falha fechada: DRAFT, campo ausente, hash/tamanho/duração divergente, gate pendente, `PASS` com defeito registrado, revisor não humano/não independente ou thumbnail ausente não promove o pack e mantém upload/Fase 6 falsos.
- Transição permitida: um receipt final integralmente PASS pode promover automaticamente somente `fp-broll-cinematic-narration@1.1.0` de `PROTOTYPED` para `LIMITED`, com escopo HeroVerse/inglês/long-form/clip-based/STANDARD/custo externo zero. Outros canais, Shorts, personagens recorrentes, outras macrofamílias, níveis PREMIUM/CINEMATIC, gasto e publicação com gate aberto permanecem proibidos.
- Rollback: a aplicação arquiva os bytes/hash do pack anterior, atualiza o registry de forma reconciliada e gera `format_pack_transition_receipt.json`; falha intermediária restaura pack e registry.
- Execução real: qualification ID, hash, tamanho, duração, pacote e STANDARD automático passaram; protocolo humano não passou porque 9 janelas e 12 gates estão `PENDING`. Resultado `PENDING_HUMAN_INPUT`, `eligible=false`, FormatPack intacto em `PROTOTYPED`.
- Correção adicional: o override do registry foi alinhado de `1.0.0` para a versão real `1.1.0`; as contagens continuam 290 `CATALOGED` + 1 `PROTOTYPED`.
- Evidência: `hero_engine/phase5_human_review.py`, schemas `phase5_human_review_submission`, `phase5_human_review_evaluation` e `format_pack_transition_receipt`, `creative-v3/human-review/review_submission.draft.json` e `review_evaluation.json`.
- Verificação: 5/5 testes novos, 111/111 regressão integral, 55 schemas no meta-schema e manifesto da Fase 5 com 405 artefatos/2.209.404.638 bytes.

## D-057 — Custo técnico zero, captions e publicação pública passam a ter guards executáveis

- Status: implementado e verificado em `2026-09-03`; nenhum upload, grant, cobrança ou promoção de fase ocorreu.
- Regra permanente: **CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00**. Cartão, trial com renovação, assinatura, API paga, servidor e domínio comprado são proibidos. YouTube Promote permanece exceção somente de mídia e exige orçamento expresso.
- Quota guard: o pipeline público reserva uma chamada do bucket `videos.insert` e 513 unidades gerais para identidade, thumbnail, captions, rechecagens, `videos.update` e verificação final. O custo configurado passa em zero; consumo real está indisponível, então o preflight retorna `BLOCKED_UNKNOWN_CONSUMPTION` e nunca ativa billing.
- Captions e publicação: o candidato possui SRT verificado com 59 cues, mas zero stream de subtitle embutido. `captions.insert` e a finalização `videos.update` exigem `youtube.force-ssl`; o token histórico concede os outros três escopos e não esse. O adapter usa o escopo amplo somente para inserir a caption congelada e mudar `status.privacyStatus` de privado para público, nunca para excluir ou alterar metadados alheios.
- Consentimento: o proprietário autorizou essa alteração no momento da ação. A tentativa de abrir o projeto provou que o Chrome ativo está em `matheusmarquesmagalhaes5@gmail.com` e não possui permissões `clientauthconfig.clients.list`, `oauthconfig.verification.get`, `resourcemanager.projects.get`, `serviceusage.effectivepolicy.get` e `serviceusage.services.get`. A mudança exige login pessoal na conta do Wellisson com acesso ao projeto; nenhuma autenticação foi automatizada.
- Gate consolidado: 12 gates críticos consomem hashes de vídeo, caption, pacote, revisão humana, transição do pack, canal, OAuth, escopos e zero-cost. Passam integridade, QA automático, direitos, Channel Readiness e private-first; humano, A/B/C, captions humanas, FormatPack, OAuth durável, escopos e cota observada bloqueiam.
- Executor: `phase5_youtube_publisher.py` é idempotente, valida todos os hashes, fixa o channel ID, faz staging `private`, aplica thumbnail e caption, verifica processamento e só então promove para `public`, com verificação final. Não expõe delete nem alteração de metadata fora do status congelado. Com o receipt real bloqueado, o teste prova que nenhuma chamada ao provedor ocorre.
- Evidência: `docs/16_ZERO_COST_OPERATION_MASTER.md`, `config/zero-cost-policy.json`, `oauth-runtime-scope-requirement.json`, `phase5-publication-pipeline-preflight.json`, `creative-v3/release_gate.json`, módulos e quatro schemas novos. O antigo `phase5-private-upload-preflight.json` é evidência histórica anterior à correção de visibilidade, não o preflight vigente.
- Verificação: 118/118 testes, 60/60 schemas no meta-schema e manifesto da Fase 5 com 406 artefatos/2.209.411.735 bytes; custo externo observado neste checkpoint R$ 0,00.

## D-058 — Gestor Central executa o fechamento da Fase 5 em loop observável e fail-closed

- Status: runtime iniciado em `2026-09-03`; nenhum upload, publicação, grant OAuth, billing ou promoção de fase ocorreu.
- Limite: o supervisor fecha exclusivamente a Fase 5. Ele não coleta métricas pós-publicação, não inicia experimentos e não antecipa o scheduler da Fase 6.
- Fluxo: fingerprint dos insumos -> revisão humana hash-pinned -> transição limitada do FormatPack -> escopos -> quota/custo zero -> release gate -> publicador idempotente. Cada ciclo sem mudança emite heartbeat `UNCHANGED`; o arquivo `PAUSE` interrompe de forma fail-closed.
- Quota: `quota-observation.json` só é consumido depois de validar contra `youtube_quota_observation.schema.json`; ausência, billing ativo, formato inválido ou consumo desconhecido bloqueiam escrita.
- Publicação: só um `READY_FOR_PUBLICATION_PIPELINE` com token de quatro escopos no ambiente pode iniciar staging privado. O mesmo receipt permite retomar processamento, caption e promoção pública sem duplicar upload.
- Estado real: `ACTIVE`, release/publicação `BLOCKED`, custo técnico R$ 0,00 e sete blockers explícitos. O par de processos observado no Windows é launcher do venv + processo-filho Python, uma única execução lógica; o PID efetivo fica em `manager.pid`.
- Evidência: `hero_engine/central_manager_phase5.py`, `docs/CENTRAL_MANAGER_RUNTIME.md`, `schemas/central_manager_runtime.schema.json`, `schemas/youtube_quota_observation.schema.json` e `output/runtime/gestor-central/status.json`.
- Verificação: 123/123 testes, 62/62 schemas válidos no Draft 2020-12 e manifesto da Fase 5 com 406 artefatos/2.209.411.735 bytes; nenhuma chamada ao provedor quando o release gate está bloqueado. Dois testes adicionais provam que `invalid_scope` abre reconsentimento quando autorizado e que cancelamento preserva os bytes do token anterior.

## D-059 — Reconsentimento OAuth de quatro escopos iniciado sem automatizar autenticação pessoal

- Status: em andamento em `2026-09-03`; callback loopback local aberto e aguardando seleção pessoal da conta `willmarquesfotografia@gmail.com` no Chrome.
- Correção: o token histórico de três escopos devolveu `invalid_scope` ao tentar refresh com a lista nova. O loader passou a tratar esse caso como necessidade de novo consentimento quando `--authorize` foi expresso; o arquivo antigo só é substituído depois que o fluxo novo conclui.
- Segurança: o token permanece em `AppData/Local/HeroEngine/secrets`, fora do workspace; seu conteúdo não foi exibido nem gravado em logs. O Gestor foi reiniciado com apenas o caminho do token no ambiente.
- Limite: escolher a conta e aceitar consentimento é autenticação pessoal e não é automatizado. A autorização ampla do proprietário não equivale ao clique da conta Google nem permite falsificar a revisão humana.
- Resultado atual: nenhuma mudança remota, nenhum upload e nenhum gasto. Após o callback, identidade e quatro escopos ainda precisam ser revalidados, e OAuth durável continua dependente do console/identidade/domínio.

## D-060 — creative-v3.1 é reprovado retroativamente pelo gate de concentração visual

- Status: implementado em `2026-09-03`; baseline preservado integralmente em `creative-history/creative-v3.1-rejected-visual-repetition`.
- Evidência nova: três folhas com amostragem a cada quatro segundos mostraram concentração que os checks anteriores não capturavam. Os seis ativos dominantes somavam aproximadamente 66,3176% do runtime; um ativo ultrapassava 10%, havia até sete usos e quatro aparições da mesma fonte numa janela móvel de 60 segundos.
- Decisão: invalidar a alegação automática anterior de prontidão criativa, materializar quatro gates adicionais e bloquear pacote/release antes de qualquer upload. Unique count e ausência de repetição adjacente deixam de ser critérios suficientes.
- Preservação: o vídeo, QA, STANDARD, replay, thumbnails e relatórios anteriores foram movidos como histórico reprovado; não foram apagados nem reutilizados como candidato vigente.
- Limite: os thresholds são uma margem de remediação específica deste piloto e não comprovam causalidade de retenção ou um ótimo universal.

## D-061 — creative-v3.2 incorpora infográficos locais, corrige semântica e passa com margem

- Status: implementado e verificado em `2026-09-03`; candidato vigente `READY_FOR_INDEPENDENT_HUMAN_REVIEW`, sem autorização técnica efetiva de upload enquanto os demais gates estão bloqueados.
- Direção: a linha do tempo foi redistribuída take a take; quatro ativos informacionais originais foram criados localmente para Truth Test, Responsibility Map, Next 24 Hours e Safety Network. O gerador `HeroVerseLocalVectorMotion@1.0.1` usa SVG/Pillow/FFmpeg, possui rights receipt próprio e custo externo R$ 0,00.
- Correção observada: uma primeira passagem v3.2 revelou imagem de segurança no take sobre “James under pressure”; os takes 14/19 foram realocados por função semântica. Uma segunda passagem detectou freeze de 1,4 s em `236,167–237,567 s`; o movimento dos infográficos foi corrigido, sem relaxar o limiar.
- Resultado final DRAFT: SHA-256 `b853b292418e54c176d4c47170220ded8b2afdc4d1f98700fdad944574fde4a4`, 238,7 s, 7.161 frames, 59 takes e 22 fontes. Maior ativo 8,2111%; seis maiores 44,3653%; máximo quatro usos; máximo três usos/60 s; paisagem 24,7591%.
- QA: 22/22 checks automáticos PASS; zero black/freeze; zero hard transition intratake; -16,34 LUFS; -1,23 dBTP; mercado `READY_FOR_INDEPENDENT_HUMAN_REVIEW`.
- STANDARD: candidato SHA-256 `33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c`, 305.941.876 bytes, 9.991,932 kb/s, SSIM 0,997925. Replay de 305.941.886 bytes passa equivalência com SSIM 0,99782, timeline/frames idênticos e áudio decodificado idêntico; não se declara determinismo byte a byte.
- Gate: publicação continua bloqueada por revisão humana independente, A/B/C, captions humanas, FormatPack, OAuth durável, escopos e observação de cota gratuita.

## D-062 — Autorização do proprietário gera revisão suplementar por IA, sem falsificar humanidade

- Status: executado em `2026-09-03` sobre o hash STANDARD vigente.
- Decisão: usar a autorização do proprietário para uma revisão adicional por Codex de hook, amostras a cada quatro segundos, identidade, variedade, semântica e thumbnails. O receipt declara explicitamente `CODEX_AI_SUPPLEMENTAL_NON_HUMAN`.
- Resultado: variedade e técnica passam; C é preferência semântica da IA e B permanece recomendação automática de ação. Nenhuma thumbnail foi selecionada. Hook emocional, reprodução sequencial, pronúncia/prosódia, tela pequena e todos os cortes permanecem `NEEDS_HUMAN_REVIEW`.
- Fronteira: autorização do usuário não altera o tipo factual do revisor. `independent_human_gate_satisfied=false` e `publication_gate_satisfied=false`; o Gestor não promove o FormatPack nem publica com esse receipt.
- Evidência: `creative-v3/human-review/ai_supplemental_review.json` e `schemas/phase5_ai_supplemental_review.schema.json`.

## D-076 — Avaliação pré-publicação torna-se automática por release, com humano por amostra e exceção

- Status: implementado e verificado em `2026-09-04`; esta decisão posterior substitui apenas a trava humana rotineira descrita em D-062, preservando o console e a fronteira factual do revisor.
- Correção do proprietário: o sistema deve decidir automaticamente se cada vídeo está apto antes de publicar; um formulário humano em toda postagem inviabiliza a operação autônoma. O padrão-ouro humano permanece como calibração, amostra mínima de 10% e exceção — nova versão/formato/voz/ferramenta, ambiguidade de direitos/publicity, anomalia/reclamação ou checkpoint do terceiro vídeo `LIMITED` — e não como trava rotineira.
- Implementação: `hero_engine/phase5_autonomous_quality.py` fixa vídeo por SHA-256, reutiliza ASR somente quando o artefato coincide, compara voz/roteiro por WER, valida captions, sinal visual, timeline, semântica por take, variedade, direitos, originalidade, identidade e thumbnails. O relatório é idempotente: nenhuma nova evidência significa nenhum novo hash.
- Evidência real: vídeo `33829cd7…3260c`; ASR `faster-whisper base.en` CPU/int8, 540 palavras de referência, 542 observadas, 5 erros e WER `0,009259`; captions 59/59 e WER 0; 477 amostras visuais, p95 de luminância 3,373185 <= 15, zero black/freeze/hard-transition; 22/22 ativos elegíveis; 59/59 takes completos; 12/12 gates críticos PASS.
- Capacidade: `fp-broll-cinematic-narration@1.1.0` promoveu de `PROTOTYPED` para `LIMITED`, com rollback e receipt, somente para HeroVerse/long-form inglês/pipeline/profile/version exatos e um canário. Não há alegação `PRODUCTION_READY`, viralidade, monetização ou resultado de audiência.
- Release: thumbnail B `DO THIS TODAY` escolhida pelo rubric predeclarado; pacote `READY_AUTONOMOUS_LIMITED`; gate consolidado `READY_FOR_PUBLICATION_PIPELINE`, 13/13 PASS, zero blockers. O fluxo continua privado -> thumbnail -> captions -> processamento -> público -> verificação.
- Fronteira: o avaliador declara `human_reviewer_claimed=false`; o console humano permanece preservado para amostra e exceções. Qualquer incerteza/falha crítica bloqueia automaticamente; média não compensa gate.
- Recuperação OAuth: uma prova diária ainda fresca não garantia que o access token de curta duração estivesse válido na hora do upload. O Gestor agora antecipa refresh quando faltam até cinco minutos para expiração, persiste atomicamente, repina o channel ID e só depois reconstrói o release; o caso expirado passa teste dedicado sem abrir navegador.
- Verificação: `54/54` testes focados iniciais, `18/18` focados após a correção OAuth e `166/166` regressão integral PASS; `77/77` schemas válidos; manifesto com 553 artefatos, 3.080.084.082 bytes e SHA-256 por arquivo; custo técnico R$ 0,00.

## D-077 — Canário private-first torna-se público e conclui a Fase 5

- Status: executado e verificado em `2026-09-04`; Fase 5 `APPROVED`, Fase 6 `IN_PROGRESS` pela autorização sequencial D-047.
- Execução: o Gestor enviou somente o artefato congelado `33829cd7…3260c` como privado, repinou o canal `UCuMF6pJQkyMzaVoAxFL86yA`, aplicou thumbnail B e captions, verificou estado privado/processamento e promoveu por `videos.update` somente depois dos gates.
- Resultado externo: vídeo `iK_5edYQtx8`; receipt `youtube-publication-f8f7adb600b32dfbae24` em `COMPLETE_PUBLIC`; `PUBLIC_POST_UPLOAD_VERIFY=PASS`; título `The 24-Hour Test: What To Do After You Pray`; oEmbed público confirma autor `HeroVerse`, URL `@heroverse74` e thumbnail; página pública HTTP 200.
- Recuperação: o primeiro ciclo pós-schema falhou antes do upload por código antigo em memória; o segundo detectou access token expirado. O supervisor passou a renovar sob demanda, e o estado `STAGED_PRIVATE_AWAITING_PROCESSING` ganhou reconsulta temporal. O mesmo receipt/video ID foi retomado; nenhum segundo upload ocorreu.
- Limites: FormatPack continua `LIMITED`; publicação não prova desempenho, viralidade, monetização, retenção ou adequação futura. Ads e gasto continuam bloqueados sem orçamento expresso.
- Verificação: 167/167 testes pós-publicação PASS, 77/77 schemas válidos e manifesto com 554 artefatos/3.080.086.312 bytes; custo técnico e externo R$ 0,00.

## D-078 — A publicação inicia a janela de 30 dias e a Fase 6 passa a observar o canário automaticamente

- Status: implementado e verificado em `2026-09-04`; Fase 6 `IN_PROGRESS`, sem promessa de resultado e sem Ads.
- Marco temporal: o `publishedAt` oficial do vídeo `iK_5edYQtx8` é `2026-09-04T18:45:51Z` (`15:45:51` em Brasília). A meta operacional termina em `2026-10-04T18:45:51Z`. Toda decisão da operação prioriza o alcance da meta, mas a plataforma controla distribuição, validação das métricas e revisão YPP; por isso o estado factual continua sem garantia.
- Plano: `output/operations/phase6/pilot-plan.json` limita a primeira sequência a três longs, um por vez, no HeroVerse e no FormatPack `LIMITED`. As janelas pré-registradas são 0, 24, 72, 168, 336 e 720 horas; 720 h coincide com o fechamento da meta de 30 dias. Vídeo 2 não pode preceder a leitura de 24 h nem contornar qualidade, direitos, política, identidade, cota ou incidente.
- Snapshot: `output/operations/phase6/metrics/iK_5edYQtx8/latest.json` foi capturado com idade `0,151891 h`; Data API observou 2 views, 1 like e 1 comentário. Analytics privado ainda não havia consolidado linhas, logo os campos faltantes permaneceram `null`, o status ficou `PARTIAL_DATA_LAG` e a decisão `INSUFFICIENT_DATA`.
- Alcance: a tentativa de consultar `videoThumbnailImpressions` e CTR pelo Analytics Targeted Queries retornou `400 query not supported`. A documentação oficial vigente aloca essas métricas aos relatórios bulk `channel_reach_basic_a1`/`channel_reach_combined_a1` do YouTube Reporting API. O adapter bulk e seu atraso de disponibilidade pertencem ao trabalho aberto da Fase 6; o sistema não substitui CTR por score ou zero.
- Observador: o loop do Gestor chama `run_phase6_observer_if_due` somente após receipt `COMPLETE_PUBLIC`, usa o token externo e registra `NOT_DUE`, próxima janela e erro tipado. A próxima coleta está agendada para `2026-09-05T18:45:51Z`.
- Correção de credencial: a primeira coleta direta selecionou indevidamente o token de origem em `LOCALAPPDATA`, alterando o receipt de refresh compartilhado e fazendo o readiness falhar por hash. O seletor passou a resolver o destino canônico do watcher; o monitor OAuth passou a exigir correspondência de hash antes de reutilizar receipt. Refresh não interativo, identidade exata, readiness e release foram reconstruídos com o token efetivo.
- Estado real: tarefa `HeroEngine-Phase5-CentralManager` `Running`, PID verificado `14288`, OAuth `continuous_operation_ready=true`, release com 13/13 gates e zero blockers, publicação preservada no mesmo video ID e observador `NOT_DUE`. A correção não gerou upload duplicado.
- Verificação: 24/24 testes focados e 172/172 regressão integral PASS; 80/80 schemas Draft 2020-12 PASS; manifesto congelado da Fase 5 permanece 554 artefatos/3.080.086.312 bytes; custo técnico R$ 0,00.
- Limites: YPP oficial continua bloqueado até seus contadores qualificados e a revisão integral do canal permitirem aplicação. O primeiro snapshot não autoriza inferência de CTR, retenção, watch hours qualificadas, viralidade, RPM ou monetização.

## D-063 — Pacote v3.2 é reintegrado ao Gestor com regressão e integridade completas

- Status: verificado em `2026-09-03`; supervisor `ACTIVE`, release/publicação `BLOCKED` e custo técnico R$ 0,00.
- Regressão: a primeira execução teve 125 sucessos e uma falha porque o arquivo operacional `PAUSE` estava presente durante a rotação segura do candidato. A pausa foi removida, o Gestor recalculou o fingerprint e a suíte integral seguinte passou `126/126`.
- Schemas: `63/63` válidos no Draft 2020-12, incluindo o contrato que impede a revisão Codex de se apresentar como revisão humana independente.
- Integridade: `549` artefatos e `3.080.030.049` bytes cobertos por SHA-256, excluindo somente `render_work`, temporários e o próprio manifesto conforme contrato.
- Runtime: fingerprint `752ad1dae979086933c051f4c9eeadc19273da7c6651f5c723c8291cb7e8f097`; sete bloqueios exatos: captions humanas, FormatPack, revisão humana, OAuth durável, escopos, thumbnail e cota gratuita.
- Resultado: nenhuma chamada remota, upload, publicação, promoção de fase ou gasto ocorreu. O loop continuará reavaliando mudanças válidas.

## D-064 — Plugin vidIQ entra como adaptador público limitado e melhora a embalagem sem promover causalidade

- Status: implementado em `2026-09-03`; custo técnico R$ 0,00, nenhuma assinatura, billing, trial ou add-on acionado.
- Conexão: o plugin confirmou autenticação na conta esperada, mas retornou lista vazia de canais próprios autorizados. Pesquisa pública funciona; YouTube Analytics próprio, retenção, receita e sobreposição de assinantes permanecem indisponíveis.
- Quota: bucket renovável 150, consumo real 55, saldo 95, add-on 0 e renovação `2026-10-03T16:42:50Z`. O guard central aplica piso preventivo 25 e migra para API oficial, cache e análise local antes do esgotamento.
- Snapshot público: HeroVerse tem 265 inscritos, 2.636 views e 21 vídeos; em 30 dias, -2 inscritos, +5 views e zero publicação. Nicho observado `Christian Inspirational Content`, confiança 0,95, inglês/EUA.
- Mercado: comparáveis e breakouts foram coletados como amostra auxiliar. Crescimento, outlier, VPH e score do provedor não são causalidade, RPM, prova de monetização nem previsão de resultado.
- Metadata: baseline `AFTER YOU PRAY, DO THIS NEXT | Christian Motivation` marcou 82. O pacote passou a usar `The 24-Hour Test: What To Do After You Pray`, score 91, porque torna visível o mecanismo real de 24 horas. A alternativa de score 96 foi rejeitada por tom acusatório incompatível com o ChannelDNA; o maior score não venceu automaticamente.
- Preservação: vídeo, áudio, captions, STANDARD e hashes não mudaram. A decisão é um artefato separado, preso ao SHA-256 STANDARD, ainda marcado `SELECTED_FOR_INDEPENDENT_HUMAN_REVIEW`.
- Aprendizado: o FormatPack recebe `CANDIDATE` para a correção técnica v3.2 e `NO_NEW_EVIDENCE` para o overlay/plugin; continua `PROTOTYPED`, pois não há resultado publicado nem revisão humana independente.
- Evidência: `output/market/vidiq/heroverse/2026-09-03/plugin-observation.json`, `schemas/vidiq_plugin_observation.schema.json`, `creative-v3/metadata_packaging_decision.json`, `schemas/metadata_packaging_decision.schema.json`, `adapter-vidiq-plugin-v1.json` e guard de custo zero.
- Verificação: o loop antigo foi reiniciado para carregar a nova lógica em memória; o guard vigente mede 55/150 e piso 25. Regressão integral `129/129`, schemas `65/65` e manifesto da Fase 5 `550` artefatos/`3.080.032.782` bytes PASS. Release/publicação continuam `BLOCKED`; zero chamada remota do publicador.

## D-065 — Gestor Central passa a hospedar a estação local de revisão humana hash-pinned

- Status: implementado e em execução em `2026-09-03`; estação `LISTENING` no loopback local, receipt humano canônico ausente e publicação bloqueada.
- Arquitetura: `hero_engine/phase5_review_console.py` é iniciado por `central_manager_phase5.py` em uma thread daemon do mesmo PID efetivo. O serviço só vincula `127.0.0.1:8765`, usa token efêmero, `no-store`, CSP/referrer protections e não requer servidor, domínio ou API paga.
- Artefato: a interface está presa ao STANDARD SHA-256 `33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c`; vídeo é servido com HTTP Range, thumbnails A/B/C por identificadores ocultos na experiência normal e captions congeladas em VTT.
- Protocolo: o navegador registra reprodução sequencial integral em 1×, cobertura >=95%, captions visíveis, áudio confirmado e prévia de 390 px. Identidade, papel, conflito, 9 janelas, 12 gates, evidência por item, attestation e escolha A/B/C são obrigatórios.
- Fail-closed: o servidor reexecuta schema e avaliador. `NEEDS_REVIEW` gera apenas arquivos `.attempt`; um receipt final existente não é sobrescrito. O próprio gerador não preenche o formulário, não se declara humano e não libera o pack.
- Integração: `review-console-status.json` e `review-console-access.json` registram processo, hash e estado; o painel foi aberto localmente para o proprietário. O Gestor consumirá o receipt canônico em ciclo posterior e, se integralmente PASS, poderá promover apenas a transição estreita já autorizada.
- Limites: observação de eventos no navegador aumenta rastreabilidade, mas não prova identidade por biometria nem substitui a responsabilidade factual do revisor. OAuth pessoal, durabilidade do app e telemetria real da cota YouTube continuam independentes.
- Resultado: endpoints HTML/captions/Range e negação sem token foram exercitados; o arranque foi corrigido para registrar apenas o hash, o token ativo não aparece no stdout e um cliente que abandona o stream após 1.024 bytes não gera stderr; 137/137 testes, 67/67 schemas e integridade de 550 artefatos/3.080.032.782 bytes passaram. Nenhuma revisão, promoção, chamada remota, upload ou gasto foi fabricado.

## D-066 — Gestor Central ganha exclusão mútua real e autostart verificável no Windows

- Status: implementado e verificado em `2026-09-04`; tarefa agendada `Running`, supervisor `ACTIVE`, release/publicação `BLOCKED` e custo técnico R$ 0,00.
- Concorrência: o antigo PID informativo foi complementado por byte-range lock não bloqueante do sistema operacional, metadata versionada, heartbeat e lease de 180 segundos. JSON obsoleto não concede autoridade; uma segunda execução real termina com `BLOCKED_DUPLICATE_MANAGER` e código 73 antes de iniciar estação, ciclo ou publicador.
- Correção de falha: erro ao gravar metadata depois de adquirir o lock agora libera corretamente o handle e propaga a causa original; somente falha efetiva na aquisição é classificada como duplicidade.
- Continuidade: a tarefa `HeroEngine-Phase5-CentralManager` inicia no logon do usuário, usa `MultipleInstances=IgnoreNew`, três reinícios de um minuto, duração ilimitada e execução oculta. O runner usa o Python local já existente e registra stdout/stderr separados.
- Acompanhamento Codex: o heartbeat existente `HERO Engine — rotina diária` foi atualizado, sem criar automação duplicada, para validar o runtime/gates, corrigir falhas internas, ficar silencioso sem mudança material e prosseguir pela fila 5–8 somente depois dos gates reais.
- Credencial: o token permanece fora do repositório e do workspace, em diretório privado do usuário com ACL restrita a usuário/SYSTEM. A tarefa recebe somente o caminho por `HERO_YT_TOKEN_PATH`; segredo, refresh token e client secret não entram nos receipts nem na documentação.
- Evidência runtime: PID efetivo 15120 vivo; lock `HELD` e console `LISTENING` no mesmo processo; segunda instância recusada com código 73; stderr do supervisor com zero bytes; tarefa `Running`; receipt `operational_ready=true`.
- Evidência contratual: schemas `central_manager_lock`, `central_manager_autostart_receipt` e `central_manager_autostart_verification`; scripts versionados de start/install/verify/remove; parsers do PowerShell corrente e do Windows PowerShell 5.1 aprovam os quatro scripts.
- Verificação: 18/18 testes focados, 143/143 regressão integral e 70/70 schemas Draft 2020-12. O manifesto congelado da Fase 5 permanece válido com 550 artefatos/3.080.032.782 bytes, pois receipts de runtime ficam fora de seu escopo.
- Limite: autostart não remove os sete gates editoriais/externos. OAuth pessoal ainda aguarda a seleção da conta, o receipt humano independente não existe e nenhuma chamada remota/upload/publicação foi executada.

## D-067 — Readiness OAuth deixa de ser cenográfico e passa a exigir cadeia de prova operacional

- Status: implementado e verificado em `2026-09-04`; Fase 5 permanece `IN_PROGRESS` e publicação `BLOCKED`.
- Falha corrigida: o fluxo de consentimento gravava em `AppData\\Local`, enquanto a tarefa de logon consumia uma cópia externa diferente. Um consentimento novo poderia concluir sem atualizar o token efetivamente usado pelo Gestor. A lacuna foi fechada com espelho atômico, validação dos quatro escopos, presença de refresh token, comparação SHA-256 pós-escrita e receipt sem segredo.
- Prova posterior: `oauth_refresh_proof` força refresh sem navegador, consulta somente `channels.list(mine=true)`, exige o channel ID exato `UCuMF6pJQkyMzaVoAxFL86yA`, persiste o token somente depois dos gates e registra PASS/FAIL sem token, client secret ou payload privado.
- Readiness real: `oauth_operational_readiness` exige conexão/identidade, quatro escopos no receipt e no console, app `IN_PRODUCTION`, configuração completa, base explícita de verificação ou isenção aplicável, token espelhado depois da configuração, identidade reprovada depois do espelho, refresh posterior, hash do token atual e ordem temporal coerente. Só então o schema aceita `continuous_operation_ready=true`, `active-private-first` e upload permitido.
- Automação: o watcher aberto encadeia `consentimento concluído -> espelho -> refresh -> identidade -> readiness`; o Gestor materializa readiness antes dos gates de escopo/custo e observa os receipts por fingerprint. O manifesto de integridade é reconstruído no mesmo ciclo quando avaliações mutáveis são regravadas, eliminando a janela de hash obsoleto encontrada pela regressão concorrente.
- Fronteira humana: a autorização do proprietário para o Codex avaliar permite manter a revisão suplementar objetiva, mas não converte o gerador em “humano independente”. O receipt canônico continua exigindo pessoa real, reprodução integral/áudio/captions/móvel, evidências e A/B/C; não há autoatestado.
- Evidência: 72/72 schemas Draft 2020-12; 15/15 testes focados iniciais; 152/152 regressão integral final; tarefa `Running`, supervisor PID 19796, watcher efetivo PID 17468, lock/console correlacionados e custo R$ 0,00.
- Estado externo: Chrome está no seletor de contas mostrando Wellisson; automação de autenticação é proibida. A observação vigente ainda prova External/Testing, zero escopos declarados e nenhuma telemetria autenticada da cota YouTube. Esses fatos, mais o receipt humano ausente, mantêm sete gates bloqueados e impedem qualquer chamada de upload.

## D-068 — Consentimento OAuth conclui; token operacional passa e console permanece fail-closed até gravação

- Status: implementado e verificado em `2026-09-04`; Fase 5 continua `IN_PROGRESS`, release/publicação `BLOCKED` e custo técnico R$ 0,00.
- Consentimento: o fluxo autorizado concluiu na conta Wellisson com os quatro escopos exatos: `youtube.readonly`, `yt-analytics.readonly`, `youtube.upload` e `youtube.force-ssl`. O token canônico permaneceu fora do workspace.
- Cadeia operacional: o token foi espelhado atomicamente para o segredo externo da tarefa, passou refresh sem navegador, persistência atômica e nova consulta `channels.list(mine=true)` presa ao canal `UCuMF6pJQkyMzaVoAxFL86yA`. Receipts não contêm segredo; `token_valid_now=true`.
- Sandbox: a tarefa de logon não enxerga o caminho de origem em `AppData`, embora enxergue o segredo de runtime. O watcher passou a aceitar a cadeia canônica já comprovada somente quando destino, hashes, espelho, refresh e identidade pós-espelho coincidem; o estado atual é `MIRRORED_AND_REFRESHED`, nunca uma inferência a partir da simples existência do arquivo.
- Console: a guia foi verificada como `Wellisson Marques Magalhães (willmarquesfotografia@gmail.com)` no projeto `graphic-tide-490010-u9`. Os quatro escopos foram adicionados ao formulário Data Access e estão preparados; o botão `Save` não foi acionado porque grava permissão OAuth persistente e exige confirmação pontual no momento da ação. Nenhum receipt pós-save foi inventado.
- Runtime: a instância não pertencente à tarefa foi encerrada somente depois de confirmar PID, lock e command line; a tarefa foi iniciada e o receipt vigente prova PID `3768`, `Running`, lock/console no mesmo processo, segunda instância recusada com código 73, watcher no mesmo PID, stderr zero e custo R$ 0,00.
- Verificação: `154/154` testes passam; `73/73` schemas Draft 2020-12 passam; manifesto da Fase 5 cobre `550` artefatos e `3.080.032.782` bytes. O teste antigo que esperava token inválido foi atualizado para a nova verdade observada sem relaxar `continuous_operation_ready=false`.
- Limite: o lado do token deixou de ser bloqueio. Persistem app `TESTING`, alinhamento não gravado no console, base de verificação/isenção não comprovada, cota YouTube não observada e os gates editoriais/humanos. Nenhum upload, publicação, billing ou gasto ocorreu.

## D-069 — Escopos e cota passam; conformidade OAuth ganha site público gratuito e verificável

- Status: implementado e verificado em `2026-09-04`; Fase 5 continua `IN_PROGRESS`, sem upload/publicação e custo técnico R$ 0,00.
- Confirmação: o proprietário confirmou expressamente a ação persistente. O `Save` do Data Access foi executado na conta `willmarquesfotografia@gmail.com`; o Google respondeu “As mudanças de acesso aos dados foram salvas” e o readback mostrou um escopo não confidencial, três confidenciais, zero restritos e `Save` desabilitado.
- Cota: a página autenticada da YouTube Data API v3 provou 10.000 queries/dia, uso atual 5 (0,05%), 100 uploads/dia e uso 0. A página de faturamento declarou que o projeto não tem conta de faturamento e não está vinculado a billing. O receipt versionado passa o guard sem inferência nem ativação de cobrança.
- Gate: `OAUTH_SCOPE_ALIGNMENT` e `ZERO_COST_AND_FREE_QUOTA` mudaram para PASS. O release continua bloqueado por cinco itens exatos: revisão humana independente, thumbnail, captions, FormatPack e OAuth durável; `authorized_api_methods` permanece vazio e o publicador não chamou o provedor.
- Site: o placeholder de operador foi resolvido como `HeroVerse Operations, administered by the authorized channel operator`. Um repositório público separado foi criado em `matheusmagah-cpu/heroverse-oauth-compliance`; GitHub Pages usa branch `main`, HTTPS forçado, sem login, sem billing e commit `fa3be45203f5b6cbd5f373be9ef258531e8f906f`.
- Prova de deploy: homepage, privacidade, termos e CSS retornam HTTP 200 e cada hash remoto coincide com o arquivo local. O schema `oauth_public_site_deployment_receipt` e o verificador reproduzível impedem declarar deploy apenas pela existência do repositório.
- Domínio: a propriedade URL-prefix `https://matheusmagah-cpu.github.io/heroverse-oauth-compliance/` foi preenchida no Search Console da conta Wellisson. O botão `Continuar` cria uma propriedade persistente e permanece aguardando confirmação pontual; `search_console_verified=false` é a verdade atual.
- Verificação: seis testes afetados foram corrigidos depois que a primeira regressão expôs expectativas congeladas; a regressão final passa `154/154`, os `74/74` schemas Draft 2020-12 passam e o manifesto cobre 550 artefatos/3.080.032.690 bytes.

## D-070 — Propriedade pública OAuth é comprovada e o Branding fica preparado

- Status: implementado e verificado em `2026-09-04`; Fase 5 continua `IN_PROGRESS`, sem upload/publicação e custo técnico R$ 0,00.
- Confirmação: a reiteração do proprietário foi aplicada no momento da ação à criação da propriedade URL-prefix já identificada. A propriedade foi criada no Search Console da conta Wellisson e o Google exibiu `Propriedade verificada` pelo método `Tag HTML`.
- Persistência: a metatag oficial permanece na homepage pública e no fonte local. O repositório Pages avançou para o commit `22c621f6186ce043724f2dfda425a7796fc1959b`; a build foi concluída e a página pública retorna HTTP 200 com a tag presente.
- Evidência: o deployment receipt foi regenerado com o commit exato, `search_console_verified=true`, quatro hashes locais/remotos idênticos, HTTPS, acesso sem login, billing ausente e custo zero. O auditor `oauth-public-site-readiness` agora retorna `PASS`, `deployment_permitted=true` e zero entradas externas pendentes.
- Reprodutibilidade: `scripts/verify_oauth_public_site.py` passou a aceitar explicitamente o estado e a evidência da verificação; o padrão default continua fail-closed (`false`) quando essa prova não é fornecida. A regressão integral passa `154/154`, os `74/74` schemas passam no Draft 2020-12 e o manifesto preserva 550 artefatos/3.080.032.690 bytes.
- Próximo limite: homepage, privacidade, termos e domínio verificado foram preenchidos no Branding do projeto, sem erro de domínio, mas o botão `Salvar` ainda é uma alteração pública persistente. Depois da gravação será necessário publicar o app, registrar o readback e só então reautorizar/espelhar/testar o token final. O release continua bloqueado pelos mesmos cinco gates e nenhuma chamada de upload foi autorizada.

## D-071 — App entra em produção sob isenção pessoal; prova de domínio é corrigida e reautorização final fica aguardando autenticação

- Status: implementado parcialmente em `2026-09-04`; app e configuração pública concluídos, reautorização pós-configuração aguardando exclusivamente a etapa pessoal do Google. Fase 5, release e publicação permanecem bloqueados.
- Branding: o app foi renomeado para `HeroVerse Channel Operations`; homepage, privacidade, termos e domínio autorizado foram salvos. O Audience readback autenticado mostra `External`, `Em produção` e exatamente um usuário OAuth vitalício.
- Verificação: o verificador automático de marca recusou dois pontos do estado anterior: nome genérico e ausência de propriedade DNS do domínio raiz. O nome foi corrigido. A política oficial do Google permite que o uso pessoal com menos de 100 usuários continue sem verificação obrigatória; portanto o escopo atual registra `NOT_REQUIRED_EXEMPT/PERSONAL_USE`, aceita o aviso e o teto vitalício de 100 usuários e não estende essa isenção à futura versão comercial.
- Domínio: a Search Console comprovou apenas a propriedade `URL_PREFIX` da página GitHub Pages. Os schemas e receipts foram migrados para v1.1 com `search_console_property_type=URL_PREFIX` e `oauth_dns_domain_verified=false`; o auditor agora distingue `site_deployment_ready=true` de `oauth_brand_verification_ready=false`. O produto comercial multiusuário exige domínio DNS próprio e verificação completa.
- Reautorização: `connect_youtube.py --force-reauthorize` mantém o token antigo intacto até o callback, usa somente os quatro escopos aprovados e está aberto no seletor do Google. Seleção de conta, senha, código e consentimento são autenticação pessoal obrigatória e não são automatizados, mesmo com autorização ampla. Depois do callback, o fluxo executa espelho, identidade e readiness; a prova de refresh pós-espelho ainda precisa ser materializada.
- Evidência técnica: contratos `oauth_public_site_*` e `oauth_production_transition_plan` versionados, plano de nove passos atualizado, 8/8 testes OAuth focados PASS e nenhum segredo registrado. Nenhum upload, publicação, billing ou gasto foi executado.

## D-072 — OAuth pós-configuração torna-se durável e o Gestor remove o blocker técnico

- Status: implementado e verificado em `2026-09-04`; `OAUTH_DURABILITY=PASS`, Fase 5 permanece `IN_PROGRESS` por quatro gates humanos/editoriais e nenhuma chamada de publicação ocorreu.
- Autenticação: o proprietário concluiu pessoalmente a nova tela Google. O receipt pós-configuração prova quatro escopos, `@heroverse74`, channel ID `UCuMF6pJQkyMzaVoAxFL86yA`, 265 inscritos, 21 vídeos, 2.636 views e probe Analytics de 26 linhas sem persistir valores privados.
- Recuperação: a primeira tentativa terminou com `NameError: ROOT` antes do espelho. O token anterior permaneceu intacto. A referência de workspace foi corrigida, o timestamp de identidade passou a preservar microssegundos para evitar falsa inversão cronológica e um teste de integração cobre o caminho `connect -> mirror`.
- Durabilidade: o token foi espelhado fora do workspace com SHA-256 idêntico, passou refresh sem navegador, persistência atômica e nova identidade exata. `operational-readiness.json` registra `continuous_operation_ready=true`, `DURABLE_POLICY_CONFIGURED`, zero blockers e modo `active-private-first`.
- Integração: o Gestor reavaliou o fingerprint e removeu somente `OAUTH_DURABILITY`. Restam `INDEPENDENT_HUMAN_REVIEW`, `THUMBNAIL_SELECTION`, `CAPTION_REVIEW` e `FORMAT_CAPABILITY`; `authorized_api_methods=[]` continua provando zero chamadas até o fechamento humano real.
- Contratos: o pacote de publicação passou a aceitar readiness durável e deixou de alegar falsamente que o app continua em Testing. O schema não congela a quantidade histórica de motivos nem bloqueia o novo estado `DURABLE_POLICY_CONFIGURED`.
- Verificação: 158/158 testes, 74/74 schemas Draft 2020-12 e manifesto SHA-256 de 550 artefatos/3.080.032.095 bytes passam. Custo técnico R$ 0,00; nenhum upload, publicação, billing ou gasto.

## D-073 — Console humano passa por teste real de reprodução e corrige falha de carregamento

- Status: implementado e verificado em `2026-09-04`; revisão canônica continua ausente e não foi simulada.
- Defeito observado: a página válida mostrava `Não foi possível abrir a mídia`; endpoint, token e arquivo existiam, mas o JavaScript definia o `src` do elemento `<source>` depois da seleção inicial de recursos sem chamar `HTMLMediaElement.load()`.
- Correção: o console define vídeo/captions, chama `video.load()` explicitamente e exibe `Media: Loading…`, `Ready · duração` ou código de erro. Um teste de regressão exige esse contrato e impede retorno silencioso ao comportamento anterior.
- Evidência de navegador: a nova guia local, presa ao mesmo SHA-256 STANDARD, mostra `Ready · 238.7 s`, barra de reprodução habilitada e o primeiro frame `PRAYER ISN'T THE FINISH`; a revisão não foi preenchida nem enviada pelo Codex.
- Runtime: tarefa `HeroEngine-Phase5-CentralManager` reiniciada para carregar a correção; PID 2516, lock `HELD`, console `LISTENING`, mesma cadeia de processo, segunda instância recusada com código 73, stderr 0 e custo R$ 0,00.
- Verificação: 159/159 testes e 74/74 schemas passam; manifesto permanece 550 artefatos/3.080.032.095 bytes. Os quatro gates humanos/editoriais continuam bloqueados até submissão factual do revisor.

## D-074 — OAuth multi-sessão exige seletor oficial de conta e preserva operação sem login recorrente

- Status: implementado e verificado em `2026-09-04`; OAuth vigente continua durável, sem novo consentimento nem alteração de token.
- Problema prevenido: em computador com várias contas Google, uma reautorização baseada apenas na sessão ativa poderia apresentar a conta errada. A validação final de channel ID já falhava fechado, mas isso só detectaria o erro depois da escolha.
- Decisão: todo fluxo interativo passa `prompt="consent select_account"` e `access_type="offline"` ao endpoint oficial do Google. O seletor do provedor vem antes da concessão, e o token anterior continua preservado até callback bem-sucedido.
- Fronteira: o sistema não cria tela que imite Google, não preenche senha/código, não automatiza diálogo de autenticação e não armazena credenciais. A autorização ampla do proprietário permite iniciar o fluxo oficial, mas a identidade pessoal continua sendo exercida no provedor. A operação normal usa refresh não interativo e, portanto, não exige troca recorrente de conta no navegador.
- Isolamento: o token externo permanece preso ao canal exato `UCuMF6pJQkyMzaVoAxFL86yA`; conta ou canal divergente não substitui o segredo operacional nem libera publicação.
- Base técnica: a documentação oficial do Google define `prompt` como lista delimitada por espaço, `select_account` como seleção explícita e `offline` como condição para refresh quando o usuário não está presente.
- Verificação: teste focado OAuth `7/7` e regressão integral `160/160` PASS. O console humano válido foi reaberto e comprova `Media: Ready · 238.7 s`; o receipt humano canônico continua ausente e não foi fabricado.

## D-075 — Gestor mantém a concessão Google saudável sem tela de login recorrente

- Status: implementado e verificado em `2026-09-04`; saúde real `HEALTHY`, identidade exata `PASS`, zero falhas consecutivas e nenhuma intervenção necessária.
- Renovação: `ensure_oauth_session_health` reutiliza por 24 horas uma prova válida e, ao vencer, executa refresh não interativo pelo token externo, consulta somente `channels.list(mine=true)`, repina `UCuMF6pJQkyMzaVoAxFL86yA`, persiste o token atomicamente e recalcula o readiness.
- Resiliência: falha transitória não abre navegador. O Gestor tenta novamente a cada seis horas e só marca `REAUTH_REQUIRED` quando falta refresh token/escopo/token ou depois de três falhas consecutivas. Isso distingue expiração normal de access token, resolvida automaticamente, de revogação real pelo Google/usuário.
- Cota e custo: uma prova saudável consome uma unidade da Data API; a agenda normal limita a uma prova por dia, muito abaixo das 10.000 unidades observadas. Custo técnico permanece R$ 0,00 e nenhuma API paga, billing ou trial foi habilitado.
- Observabilidade: `schemas/oauth_session_health.schema.json` e `output/runtime/gestor-central/oauth-session-health.json` registram status, última tentativa/sucesso, próxima verificação, falhas, necessidade de intervenção, cota e custo sem armazenar caminho ou segredo.
- Estado observado: última prova em `2026-09-04T16:06:54.484346Z`; próxima verificação em `2026-09-05T16:06:54.484346Z`; `refreshed_now=false`, pois o receipt ainda estava fresco; `user_intervention_required=false`.
- Windows: por pedido expresso do proprietário, o plano ativo Equilibrado foi configurado com `VIDEOIDLE=0` em tomada e bateria. A leitura posterior confirmou AC `0x00000000` e DC `0x00000000`; nenhuma configuração de segurança, login ou privacidade foi alterada.
- Verificação: testes focados Gestor/OAuth `17/17`, regressão integral `162/162`, schemas Draft 2020-12 `75/75` e integridade de 550 artefatos/3.080.032.095 bytes PASS. O supervisor foi reiniciado pela tarefa: PID 620, tarefa `Running`, lock `HELD`, console `LISTENING`, mesma cadeia de processo, segunda instância recusada com código 73, stderr 0, saúde OAuth `HEALTHY` e custo R$ 0,00.

## D-079 — Fase 6 ganha Reporting bulk, fila transacional, previsão honesta e controle executivo

- Status: implementado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` aguardando a janela própria de 24 h, sem Ads e sem promessa de resultado.
- Integração externa: a YouTube Reporting API foi ativada sem billing no projeto OAuth `graphic-tide-490010-u9`, pela sessão autorizada de Wellisson. Os jobs `channel_basic_a3` (`f86c1fe4-93ed-4a03-80de-bd2325e8197b`) e `channel_reach_basic_a1` (`ce0b4a6d-b8db-4550-a856-5ff8e8a83ba2`) foram criados uma vez e a segunda execução retornou `REUSED`, provando idempotência. O estado correto é `ACTIVE_AWAITING_FIRST_REPORT`; ausência de CSV permanece `null`, nunca zero.
- Reach: o adapter baixa CSV por URL autenticada, preserva arquivo bruto e SHA-256, seleciona a versão mais recente por período, isola exatamente `channel_id`/`video_id`/data, contabiliza linhas rejeitadas e agrega CTR ponderado por impressões. CSV incompleto ou identidade divergente falha fechado. O observador atualiza Reporting antes de cada checkpoint próprio.
- Fila: SQLite local em WAL implementa chave idempotente, claim atômico, lease, checkpoint, retry exponencial, recuperação de lease expirado, limite de tentativas, incidentes e dead-letter. O checkpoint de 24 h foi pré-agendado para `2026-09-05T18:45:51Z`; antes desse instante não é reivindicável.
- Inteligência: previsão passa a ser receipt imutável separado do outcome. Como não existem três janelas próprias comparáveis concluídas, o estado real é `WITHHELD_INSUFFICIENT_CALIBRATION`, sem ponto ou intervalo inventado. O protocolo do Vídeo 2 está `WAITING_FOR_24H_BASELINE`, controla uma variável de hook por vez e declara o primeiro canário como baseline observacional não causal. O Learning Evaluator classifica fixtures em `SUPPORTED`, `REJECTED`, `INCONCLUSIVE` e `INVALID_EXPERIMENT` por validade, amostra e intervalo.
- Correção auditada: o primeiro gerador de prediction reutilizou o cutoff como horário de criação; o timestamp foi corrigido antes do horizonte e antes de existir forecast/outcome, e o incidente foi preservado em `output/operations/phase6/intelligence/incidents/prediction-created-at-correction-20260904.json`.
- Supervisão: `executive-status.json`/`EXECUTIVE_STATUS.md` consolidam cronômetro D30, canário, Reporting, fila, previsão, experimento, custo, próxima ação e autorização do próximo vídeo. `READY_TO_PREREGISTER` não autoriza produção; somente tratamento efetivamente pré-registrado e todos os gates podem liberar o Vídeo 2.
- Verificação: `192/192` testes PASS em 87,701 s; `87/87` schemas Draft 2020-12 válidos; compilação Python PASS; custo técnico e mídia R$ 0,00. A Fase 6 não fecha até haver dados suficientes, relatório por vídeo, decisão do lote e gate integral.

## D-080 — Meta D30 governa a operação, e o Gestor ganha resiliência contra lock transitório do OneDrive

- Status: implementado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS`, com a meta de 30 dias tratada como objetivo operacional prioritário e não como garantia de uma decisão externa do YouTube.
- Regra de execução: o Gestor deve descobrir e executar a melhor próxima ação controlável a partir de evidência própria, prazo restante, gates e fila. Ele não pode fingir precisão quando a amostra é insuficiente nem acelerar publicando o Vídeo 2 antes do baseline de 24 h predefinido.
- Incidente observado: durante regressão concorrente, o OneDrive negou temporariamente a troca atômica de `manager-lock.json.tmp`; o processo saiu, e dois artefatos mutáveis foram reemitidos durante a construção do manifesto de integridade. O problema foi isolado como concorrência de escrita, não como defeito do vídeo ou da publicação.
- Correção: receipts atômicos usam temporário único por PID/thread, `os.replace`, oito tentativas com backoff limitado e limpeza do temporário. O caso transitório possui teste dedicado. O manifesto foi reconstruído somente com o Gestor parado, retornando a 554 itens e 3.080.086.312 bytes, e voltou a passar também depois da reativação.
- Prova do runtime: tarefa `HeroEngine-Phase5-CentralManager` `Running`; PID efetivo `5660`; lock `HELD`, console `LISTENING` e processo coincidentes; segunda instância rejeitada com código 73; stderr zero; `operational_ready=true`. O heartbeat avançou de `2026-09-04T20:05:26.027076Z` para `2026-09-04T20:06:26.215981Z` sem nova falha.
- Verificação: regressão integral isolada `192/192 PASS` em 87,701 s; teste de integridade passou antes e depois da reativação; `87/87` schemas Draft 2020-12 válidos; custo técnico e mídia R$ 0,00.

## D-081 — Manutenção diária passa a ser transacional e o painel separa tempo corrente de tempo da evidência

- Status: implementado e exercitado de ponta a ponta em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` e a rotina Codex `HERO Engine — rotina diária` continua `ACTIVE`, sem automação duplicada.
- Risco eliminado: `scripts/daily.ps1` executava a regressão contra os mesmos artefatos enquanto o Gestor permanecia em loop. Isso podia produzir concorrência de hashes mesmo depois do retry atômico. A rotina agora resolve o PID pelo lock, valida a command line exata, para somente a cadeia do Gestor, executa testes, reconstrói integridade, roda o relatório/catálogo e reinicia a tarefa em `finally`.
- Recuperação: o pós-start exige PID vivo, lock novo posterior ao início da manutenção, console `LISTENING` no mesmo PID, bloqueio de duplicidade e stderr zero. O primeiro ensaio revelou quebra de quoting no caminho com espaço/acento; a chamada passou a usar `EncodedCommand`. O segundo revelou receipt de console ainda antigo; a espera passou a exigir o console novo. O terceiro ensaio integral terminou com código 0.
- Supervisão Codex: o heartbeat existente foi atualizado para a realidade da Fase 6 — Reporting bulk, fila/lease/DLQ, checkpoint, prediction, experimento e aprendizado — e permanece silencioso sem mudança material. Ads e qualquer gasto continuam bloqueados sem orçamento.
- Painel: `canary.age_hours` agora é a idade corrente do vídeo; `metrics_captured_at` e `metrics_snapshot_age_hours` identificam quando a evidência foi capturada. O gate do Vídeo 2 continua usando a idade do snapshot, impedindo que a simples passagem do relógio simule um baseline coletado.
- Prova vigente: tarefa `Running`, PID efetivo `12084`, lock/console/receipt no mesmo PID, duplicata código 73, stderr zero e `operational_ready=true`; painel `ACTIVE_OBSERVING`; fila `HEALTHY`; próxima coleta automática `2026-09-05T18:45:51Z`; `193/193` testes PASS em 87,743 s, `87/87` schemas válidos e manifesto 554 itens/3.080.086.312 bytes PASS; custo R$ 0,00.

## D-082 — Catálogo executivo passa a refletir o estado vivo sem cadência ou precisão inventada

- Status: implementado, inspecionado e exercitado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS`.
- Defeito corrigido: a planilha anterior ainda exibia data de geração antiga, cadência fixa de publicação e lacuna de 4.000 horas como se o contador YPP atual fosse zero. Esses valores não eram compatíveis com o plano controlado nem com a indisponibilidade observada do contador oficial.
- Controle vigente: `tools/build_catalog.mjs` lê `output/operations/phase6/executive-status.json`; injeta estado, inscritos observados, limite máximo do lote, autorização do próximo vídeo, prazo e custo; mantém lacuna YPP, views long-form necessárias e rateio por piloto como `UNAVAILABLE` até existir dado oficial suficiente.
- Calendário: o início foi normalizado para `D0 = 2026-09-04T18:45:51Z`; `D1 = 24 h`, `D3 = 72 h`, `D7 = 168 h`, `D14 = 336 h` e `D30 = 720 h = 2026-10-04T18:45:51Z`. As linhas são checkpoints de controle, não promessa de publicação.
- Qualidade visual e lógica: Dashboard, matemática e calendário foram renderizados e inspecionados; textos críticos estão legíveis; o scan final encontrou zero `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?` ou `#N/A`. Dois testes dedicados impedem o retorno da cadência legada, da falsa lacuna YPP e do erro de calendário.
- Automação: a rotina Codex existente foi alinhada para 16:00 BRT, após o checkpoint oficial de 15:45:51 BRT, sem criar duplicata. Ela verifica Reporting, fila, prediction, experimento e aprendizado; permanece silenciosa sem mudança material e não autoriza Ads.
- Prova vigente: manutenção transacional integral terminou com código 0; `195/195` testes PASS em 88,522 s; `87/87` schemas Draft 2020-12 válidos; manifesto da Fase 5 com 554 artefatos/3.080.086.312 bytes PASS; tarefa `Running`, PID 8900, lock `HELD`, console `LISTENING`, mesma cadeia, duplicata código 73, stderr zero e `operational_ready=true`; fila `HEALTHY`, 1 `PENDING`, 0 `DEAD_LETTER`; custo técnico e mídia R$ 0,00.

## D-083 — O checkpoint elegível passa a acionar diagnóstico e pré-registro sem confundir produção com publicação

- Status: implementado, exercitado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` aguardando a coleta própria de 24 h em `2026-09-05T18:45:51Z`.
- Lacuna eliminada: o protocolo anterior podia chegar a `READY_TO_PREREGISTER` sem executor que transformasse a evidência em diagnóstico e tratamento. `phase6_intelligence.py` agora materializa `prediction -> diagnosis -> protocol` no mesmo checkpoint, com schemas e artefatos imutáveis por snapshot.
- Decisão controlada: o diagnóstico exige snapshot `OBSERVED`/`ELIGIBLE_FOR_COMPARISON`, normaliza somente cópias decisórias de métricas percentuais e preserva o bruto. A árvore escolhe exatamente um gargalo entre amostra/distribuição, embalagem, hook, narrativa ou replicação; cada ramo fixa uma única variável e uma métrica primária. Amostra abaixo de 30 views nunca é rotulada como falha criativa: recebe `DISTRIBUTION_SAMPLE`, baixa confiança e tratamento de ângulo.
- Fronteira de autorização: `PREREGISTERED` pode liberar apenas `PRODUCTION_ENTRY_ONLY`. `publication_authorized` permanece `false` até que o novo artefato atravesse direitos, originalidade, política, ChannelDNA, identidade, qualidade, cota, processamento e pipeline private-first. Isso impede que a urgência D30 contorne um gate crítico.
- Forecast: `current_valid_watch_hours` deixou de ser zero fictício e passou a `null/UNAVAILABLE`; cadência diária fixa foi removida. Na falta de contador YPP e cadência observados, simulações executadas são zero, probabilidades/distribuições ficam `null` e as necessidades de views/horas ficam indisponíveis. O horizonte corrente foi reconciliado de 21 para 30 dias e `command_daily` agora grava `forecast-30d.json/.md`; os artefatos de 21 dias foram preservados em `output/reports/archive`.
- Integridade histórica: a mudança legítima no CLI compartilhado não reescreveu o manifesto congelado da Fase 2. `output/operations/phase6/shared_source_evolution_receipt.json` registra hashes históricos e atuais, e a regressão valida essa evolução explicitamente.
- Resiliência operacional: a parada da manutenção passou a aceitar processo já ausente como sucesso idempotente. O writer do console usa temporário único, substituição atômica e seis tentativas com backoff para lock transitório do OneDrive. Ambas as falhas foram observadas em execução real, corrigidas e cobertas por testes dedicados.
- Prova vigente: manutenção transacional terminou com código 0; `200/200` testes PASS em 76,717 s; `88/88` schemas Draft 2020-12 válidos; manifesto da Fase 5 com 554 artefatos/3.080.086.312 bytes PASS; tarefa `Running`, PID 4060, lock `HELD`, console `LISTENING`, duplicata código 73, stderr zero e `operational_ready=true`; fila `HEALTHY`, 1 `PENDING`, 0 `DEAD_LETTER`; diagnóstico `WAITING_FOR_ELIGIBLE_BASELINE`; custo técnico e mídia R$ 0,00.

## D-084 — Diagnóstico e pré-registro passam a produzir uma ordem executável, não uma recomendação solta

- Status: implementado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS` e aguarda legitimamente o snapshot próprio de 24 h.
- Lacuna eliminada: o painel emitia `BUILD_VIDEO_2_CONTROLLED_TREATMENT`, mas nenhum executor consumia essa decisão. `hero_engine/phase6_production.py` agora cria `Phase6TreatmentOrder` imutável, valida 12 pré-condições e compila a pré-produção através da fila SQLite com idempotência, lease, retry e dead-letter.
- Precisão experimental: `TITLE_THUMBNAIL_PROMISE` aponta para o próprio canário, bloqueia qualquer mudança de timeline e compila três pares completos mais rollback; não cria um vídeo duplicado. `TOPIC_ANGLE`, `FIRST_8_SECONDS_MECHANISM` e `BODY_PROGRESSIVE_DISCLOSURE` apontam para o Vídeo 2 e produzem tratamento, brief, roteiro original em inglês, blueprint take a take, cobertura de ativos e plano de 18 gates.
- Evidência e mercado: a ordem exige identidade exata entre snapshot, diagnóstico e protocolo, sinal elegível com cobertura observada >= 0,95 e idade máxima de sete dias no cutoff da evidência. `TOPIC_ANGLE` escolhe o melhor challenger compatível diferente do tema-base; score permanece índice de hipótese, nunca probabilidade de viralização.
- Autonomia segura: `run_phase6_treatment_executor` materializa a ordem em todo ciclo, não cria job antes do baseline e, depois de `READY_TO_COMPILE`, consome o trabalho uma única vez. O receipt conserva hashes/tamanhos e sempre deixa `publication_authorized=false`; render ou mudança pública são etapas posteriores.
- Correção estrutural: `take_planner.py` deixou de rejeitar toda decisão `PRODUCTION`; agora aceita somente `PROTOTYPE/DRAFT` ou `PRODUCTION` não-DRAFT com FormatPack `LIMITED/PRODUCTION_READY` e `production_allowed=true`.
- Prova: estado real `WAITING_FOR_ELIGIBLE_BASELINE`, executor `WAITING`, job `NOT_CREATED`; ramos topic/package, identidade divergente, espera, schema, faixa de duração e idempotência testados; regressão integral `206/206 PASS` em 85,852 s; `91/91` schemas Draft 2020-12 válidos; custo técnico e mídia R$ 0,00.

## D-085 — Manutenção transacional testa snapshot estável e compara o lock em UTC

- Status: implementado, exercitado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS`.
- Falhas observadas: o primeiro ensaio desta revisão encontrou um hash divergente porque o Gestor podia ser interrompido entre a última escrita de evidência e a reconstrução do manifesto; a recuperação iniciou um processo saudável, mas o verificador tratou o timestamp UTC `Z` como hora local e recusou o lock novo.
- Correção: depois de parar somente a cadeia com command line verificada, `daily.ps1` reconcilia o manifesto antes da suíte e testa essa snapshot estável. A comparação usa `DateTimeOffset::UtcNow` e `DateTimeOffset::Parse(...).ToUniversalTime()`. O bloco `finally` continua responsável pelo reinício mesmo quando testes falham.
- Rigor adicional: o compilador do Vídeo 2 agora falha fechado se o blueprint sair da faixa long-form pré-registrada de 207.750–286.250 ms e registra mínimo, máximo, observado e `PASS` no artefato. A amostra de teste mediu 245.700 ms.
- Continuidade: a automação existente `HERO Engine — rotina diária` foi atualizada no lugar, sem duplicata. Ela agora inspeciona `Phase6TreatmentOrder` e o executor, distingue tratamento de embalagem no canário de tratamento do Vídeo 2 e exige a faixa de duração antes de prosseguir.
- Prova final: manutenção integral terminou com código 0; `206/206` testes PASS em 85,852 s; `91/91` schemas válidos; manifesto com 554 artefatos/3.080.086.312 bytes; tarefa `Running`, PID efetivo 10740, lock `HELD`, console `LISTENING` no mesmo PID, tentativa duplicada bloqueada com código 73, stderr zero e `operational_ready=true`. OAuth está `HEALTHY`, identidade verificada, zero falhas e nenhuma intervenção requerida. Custo técnico e mídia: R$ 0,00.

## D-086 — Extensão de FormatPack LIMITED exige autorização literal e versionada

- Status: implementado, migrado e verificado em `2026-09-04`; a Fase 6 continua `IN_PROGRESS` e nenhuma segunda produção foi iniciada antes da evidência própria de 24 h.
- Lacuna encontrada: `fp-broll-cinematic-narration@1.1.0` limita o uso a um canário autônomo seguido de monitoramento. O estado `LIMITED`, o diagnóstico elegível e o pré-registro não constituem, isoladamente, autorização literal para outro ordinal.
- Decisão: `Phase6FormatScopeReceipt` passa a ser pré-condição independente. O overlay `fp-broll-cinematic-narration-phase6-controlled-lot@1.0.0` mantém estado `LIMITED`, channel/nicho/pipeline/profile/voz/custo presos, máximo de três longs e uma ação por vez. Ele nunca promove o pack nem autoriza render ou publicação.
- Gates: sequência do lote, pack-base, pipeline, cadeia pública do canário, snapshot próprio de 24 h, alvo exato do tratamento, ausência de incidente crítico, qualidade autônoma do baseline e custo/publicação travados. A ordem ganhou `FORMATPACK_LIMITATION_SCOPE`, totalizando 13 pré-condições.
- Painel e executor: `phase6_reporting.py` só expõe `PRODUCTION_ENTRY_ONLY` quando o receipt está `AUTHORIZED`, sem `WAITING/BLOCKED`, com ação exata e custo zero. Ausência, divergência ou receipt pendente não pode ser contornado por diagnóstico/protocolo. Estado observado: receipt `WAITING`, ação `WAIT`, 7 PASS/2 WAITING/0 BLOCKED; ordem `WAITING_FOR_ELIGIBLE_BASELINE`; executor `WAITING/NOT_CREATED`; publicação falsa.
- Incidente de migração: durante a troca do schema, um ciclo do Gestor tentou validar a ordem imutável anterior sem os novos campos e registrou `ERROR`. O mesmo executor rematerializou a ordem nova e retornou a `WAITING`, sem criar job, apagar fila ou relaxar gate. O fato e a recuperação estão preservados em `output/operations/phase6/incidents/format-scope-schema-migration-20260904.json`.
- Verificação: 11 casos direcionados de produção/relatório passaram dentro da regressão final, incluindo receipt ausente e alvo divergente; manutenção transacional integral código 0; regressão `209/209 PASS` em 88,644 s; `92/92` schemas Draft 2020-12; manifesto congelado 554 artefatos/3.080.086.312 bytes. Runtime recuperado: tarefa `Running`, PID 9668, lock `HELD`, console no mesmo PID, duplicata código 73, stderr zero, `operational_ready=true`; OAuth `HEALTHY`, identidade exata, zero falhas e nenhuma intervenção; custo técnico e mídia R$ 0,00.

## D-087 — Fase 6 fecha a cadeia automática de mídia, qualidade e publicação sem furar o checkpoint

- Status: implementado, integrado e verificado em `2026-09-04`; a Fase 6 permanece `IN_PROGRESS` aguardando a observação própria de 24 h. Nenhum segundo upload foi tentado e nenhum job posterior foi criado antes do gate.
- Release e mídia: `phase6_release.py` transforma somente a pré-produção autorizada em work order hash-pinned, allocation ledger e receipt de inputs. `phase6_assets.py` ampliou gratuitamente a biblioteca com oito ativos Commons verificados, chegando a 33, e `phase6_media.py` executa voz, captions e render FFmpeg local por fila transacional. O teste de integração produziu e mediu um candidato STANDARD real de oito segundos.
- Qualidade independente: `phase6_quality.py` não reutiliza a decisão do gerador. Ele reconcilia hashes, ffprobe, movimento, freeze/black/flicker, continuidade, áudio/loudness, ASR local, captions, semântica, variedade, direitos, originalidade, ChannelDNA, embalagem, identidade, custo e publicação. O contrato contém exatamente 18 gates críticos e 19 defeitos técnicos; todos, além do padrão-ouro e do controle negativo, precisam `PASS`. Falha crítica não pode ser compensada por média.
- Publicação: `phase6_publication.py` constrói pacote congelado em inglês, atualiza o Channel Readiness quando necessário, reserva a cota gratuita por dia do Pacífico com margem geral de 2.000 unidades, executa guard R$ 0,00 e valida 13 gates de release. O publicador é private-first, grava receipt após cada efeito externo, aplica thumbnail/captions, verifica processamento, promove o mesmo ID para público e só então aceita `COMPLETE_PUBLIC`; retry nunca cria upload novo quando um ID privado já foi persistido.
- Coordenação: o Gestor chama release, mídia, qualidade, publicação e reporting no mesmo ciclo. O heartbeat do lock roda em thread própria durante render longo. O painel executivo expõe cada estágio e gera atenção em `BLOCKED/ERROR/FAIL`, mantendo `WAITING` sem falso alerta enquanto o baseline ainda não existe.
- Falhas reais de manutenção: o primeiro ensaio encontrou lock não restabelecido dentro da janela. O segundo mostrou duas causas: launcher do venv em encerramento após o filho e timestamp ISO re-stringificado, interpretado por cultura local como abril. A correção para o launcher antes do filho, tolerância somente ao desaparecimento do PID exato, cast direto para `DateTimeOffset` UTC, janela limitada de 120 s e último probe observável passou no terceiro ensaio integral.
- Prova final: `224/224` testes PASS em 142,752 s; `105/105` schemas Draft 2020-12; manifesto congelado da Fase 5 preservado em 554 artefatos/3.080.086.312 bytes; catálogo executivo regenerado e inspecionado sem erro de fórmula. Tarefa `Running`, PID 12972, lock `HELD`, console no mesmo PID, duplicata código 73, stderr zero, `operational_ready=true` e nenhum `executive-status-error.json`. Estado executivo `ACTIVE_OBSERVING`; fila `HEALTHY`; release/mídia/qualidade/publicação `WAITING`; próxima coleta automática `2026-09-05T18:45:51Z`; custo técnico e mídia R$ 0,00.

## D-088 — Licença autoral deixa de ser tratada como liberação de publicity, marca ou imagem

- Status: implementado, exercitado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS`, sem segundo render/upload antes da coleta própria de 24 h.
- Lacuna comprovada: o gate `PUBLICITY` repetia o booleano de direitos autorais. A biblioteca expandida continha dois ativos NASA/Artemis em domínio público — `asset-commons-3177de0505321c2bcd` e `asset-commons-d28faacc60527bd92e` — mas licença autoral não resolve aparência de endosso institucional, marca ou pessoa. A automação não pode converter essa ambiguidade em `PASS`.
- Correção pré-render: `phase6_release.py` exclui do universo elegível metadados com risco institucional conhecido antes de alocar takes. Ensaio de capacidade com o manifesto real compilou 90 takes usando 27 ativos sem selecionar os dois riscos; participação máxima 0,071514 e concentração dos seis maiores 0,309229, dentro do contrato de variedade. Essa prova é de capacidade técnica e não autoriza publicação.
- Correção pós-render: `phase6_publicity.py` valida cada ativo efetivamente usado, falha fechado em mídia ilegível, procura risco de instituição/marca nos metadados e executa detecção facial local. A saída registra modelo, hash, ranges, frames, achados e limite de alegação. Resultado negativo reduz risco de triagem; não prova ausência de todo logo, pessoa ou direito de publicidade.
- Dependência gratuita e presa: YuNet oficial foi armazenado em `models/yunet/face_detection_yunet_2026may.onnx`, licença MIT local e SHA-256 `ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0`. Nenhuma API, assinatura, cartão ou servidor foi introduzido; custo técnico permanece R$ 0,00.
- Gate independente: `phase6_quality.py` versão `1.1.0` materializa `publicity_risk_screen.json`; `PUBLICITY` não herda mais `RIGHTS`. Todos os ativos precisam ser decodificáveis, sem rosto detectado e sem risco metadata-driven. O gate de custo também passou a reprovar `paid_tools=true`, além do total monetário.
- Migração imutável: a mudança na elegibilidade alterou o conteúdo do release work order e expôs corretamente uma colisão com o ID antigo. O contrato passou para `1.1.0`, o ID inclui a versão e o schema aceita o histórico `1.0.0` sem reescrita. Work order corrente: `phase6-release-work-order-e8446e09593966c03cd2`, ainda `WAITING_FOR_PREPRODUCTION`.
- Erro corrente versus histórico: uma execução antiga havia deixado `output/operations/phase6/executive-status-error.json` depois de o status válido já existir. A rotina apontava por engano para outro diretório. A correção arquiva os bytes exatos por SHA-256 em `output/operations/phase6/errors/archive` e limpa somente o alerta corrente após materialização completa e schema-validada; colisão de arquivo histórico falha fechado.
- Verificação: cinco testes específicos cobrem paisagem genérica sem rosto, NASA/Artemis, vídeo quebrado, adulteração do hash do modelo e exclusão pré-render. Produção/publicity/quality/report passaram em `25/25`; suíte integral final `230/230 PASS` em 135,403 s; `105/105` schemas Draft 2020-12 e compilação Python PASS. A manutenção integral imediatamente anterior passou `229/229`, preservou os 554 artefatos/3.080.086.312 bytes e recuperou tarefa `Running`, PID 15096, lock `HELD`, console no mesmo PID, duplicata código 73, stderr zero e `operational_ready=true`. Estado atual `ACTIVE_OBSERVING`, fila `HEALTHY`, alerta executivo corrente ausente, evidência histórica preservada, próxima coleta `2026-09-05T18:45:51Z`, custo técnico e mídia R$ 0,00.

## D-089 — O tratamento de título e thumbnail exige transação reversível e janela diária fixa

- Status: implementado, exercitado e verificado em `2026-09-04`; Fase 6 permanece `IN_PROGRESS`.
- Problema eliminado: o ramo de embalagem produzia pares e rollback na pré-produção, mas não existia executor público nem comparação temporal válida. Deixar a troca para operação manual quebraria a automação, e comparar snapshots cumulativos do mesmo vídeo misturaria baseline e tratamento.
- Decisão: `phase6_package_treatment.py` aceita somente o protocolo exato `TITLE_THUMBNAIL_PROMISE`, a cadeia autorizada e um candidato hash-pinned. O Diretor Criativo deriva a seleção de atributos observáveis — complementaridade entre texto e imagem, ação direta, âncora espiritual, tensão honesta e baixa duplicação — e não do ID da variante.
- Gate: 17 verificações críticas cobrem identidade, protocolo, artefatos, alvo, variável única, constraints de título/thumbnail, política, promessa, ChannelDNA, dimensões/bytes/safe area, qualidade visual, diferença perceptual, direitos próprios, rollback, vídeo inalterado, custo e limite temporal.
- Efeito externo: o executor grava estado após cada chamada, preserva todo o snippet necessário para rollback, altera o título e o JPEG exatos, confirma canal/publicidade/título pela API e a thumbnail pela CDN. Falha pós-mutação tenta restaurar título e thumbnail e registra `ROLLED_BACK` ou `PARTIAL_ROLLBACK_REQUIRED`; no máximo três tentativas pré-mutação.
- Tempo e aprendizado: a troca ocorre apenas até 180 s após o primeiro limite elegível da data do Pacífico; se a janela for perdida, adia para o dia seguinte. O deslocamento efetivo fica no release/receipt. O runtime espera completar o dia, seleciona as duas linhas diárias adjacentes de `video_thumbnail_impressions_ctr`, usa impressões como N, calcula erro na mesma unidade percentual e mantém conclusão local e incerta.
- Cota e custo: conforme documentação oficial, `videos.update` custa 50 unidades e `thumbnails.set` custa 50; a operação reserva exatamente 100 dentro da cota gratuita e do piso preventivo. Nenhum billing foi habilitado. Fontes: `https://developers.google.com/youtube/v3/determine_quota_cost`, `https://developers.google.com/youtube/reporting/v1/reports/metrics`.
- Evidência: candidato real de teste 1280×720/JPEG, 76.083 bytes, entropia 5,863822, span do texto 252, desvio 38,676679 e similaridade perceptual 0,756127 versus baseline; rollback duplo foi exercitado contra uma CDN divergente. Manutenção integral código 0; `245/245` testes PASS em 152,584 s; `111/111` schemas válidos; compileall PASS; runtime reiniciado em PID 19832, tarefa `Running`, lock/console no mesmo PID, duplicata 73, stderr zero e `operational_ready=true`.

## D-090 — O gate do Gestor precisa de receipt de regressão e classe explícita de evidência

- Status: implementado, falha exercitada, corrigido e verificado em `2026-09-04`; Fase 6 continua `IN_PROGRESS`.
- Lacuna: `docs/GESTOR_CENTRAL_ACCEPTANCE.md` ainda marcava 22 casos como `NOT_RUN`, embora parte tivesse prova real e parte ainda dependesse do piloto. Ao mesmo tempo, a manutenção não persistia o resumo de testes nem invocava explicitamente tratamento/learning fora do loop residente.
- Decisão: `phase6_acceptance.py` materializa 22 checks em ordem, com requisito `FIXTURE`, `LIVE` ou `LATER_PHASE`. Um `PASS_FIXTURE` não satisfaz um item `LIVE`; somente a classe suficiente entra na elegibilidade da fase. O resultado nunca promove diretamente a fase: apenas um receipt de transição separado poderá fazê-lo quando zero blockers restarem.
- Manutenção: a regressão roda em processo observável, persiste stdout/stderr, verifica o sumário canônico `unittest`, grava receipt atômico e prende o manifesto. Package treatment e learning runtime são chamados nominalmente. A prova pós-reinício materializa novamente o aceite.
- Falha real: o primeiro ensaio final acusou `Release artifact changed: scope_requirement`, porque a nova capacidade OAuth havia atualizado um artefato derivado sem reconstruir o gate que prendia seu hash. O `finally` recuperou a tarefa/PID. A rotina agora reconstrói scope requirement e release gate antes da reconciliação de integridade e da suíte; teste estrutural fixa essa ordem.
- Prova histórica: segunda manutenção código 0; receipt `daily-maintenance-20260905T0134413537349Z`; `247/247 PASS` em 133,498 s; manifesto 554 itens/3.080.086.312 bytes; tarefa `Running`, PID 21412, lock/console no mesmo PID, duplicata 73 e stderr zero. Esse snapshot ainda continha a classificação circular de GC-14, corrigida explicitamente por D-092 sem remover o requisito da Fase 7.

## D-091 — Previsão só é operacional quando possui outcome agendado e avaliação imutável

- Data: 2026-09-04.
- Problema: `evaluate_prediction()` existia e passava em fixture, mas nenhum runtime chamava a avaliação no horizonte real. GC-19 permaneceria sem receipt; além disso, GC-08 e GC-10 dependiam do documento “latest” e poderiam regredir falsamente quando o estado evoluísse.
- Decisão: criar `phase6_prediction_runtime.py` subordinado ao Gestor. Cada previsão imutável gera um job SQLite idempotente disponível apenas no horizonte, coleta o canário exato pela API oficial, prende o snapshot antes da avaliação, grava `PredictionEvaluation` imutável e reaproveita o checkpoint em retry.
- Baseline: em previsão calibrada, mediana da coorte é o challenger e o último outcome é o baseline simples distinto. Superioridade exige uplift de erro estritamente positivo fora da amostra. Forecast retido preserva o outcome real como `NOT_EVALUABLE_WITHHELD`; o gate comprova rejeição da falsa precisão, sem alegar previsibilidade.
- Aceite cumulativo: GC-08 passa pelo snapshot histórico que preservou nulos; GC-10 aceita qualquer estado pré-registrado temporalmente válido; GC-19 examina avaliações imutáveis, não um rótulo inventado no painel. Estado corrente ou prediction `latest` não apagam história válida.
- Coordenação: o runtime entra no loop residente e em `daily.ps1`; o painel expõe avaliação e escolhe o menor timestamp entre checkpoints. D1 segue primeiro em `2026-09-05T18:45:51Z`; outcome da previsão vem em `2026-09-05T19:12:01.035029Z`.
- Continuidade Codex: a automação ativa `HERO Engine — rotina diária` foi atualizada no lugar para ler prediction runtime/avalições/aceite, validar 13 pré-condições e respeitar a ordem D1 -> horizonte; nenhuma segunda automação foi criada.
- Recuperação: erro transitório entra em `RETRY_WAIT`, fica `WAITING_FOR_RETRY` durante o backoff e não produz alerta repetitivo; snapshot só é fixado após schema, identidade, horizonte e outcome passarem. O teste prova falha, espera e sucesso posterior.
- Prova final: `251/251 PASS` em 152,293 s, `114/114` schemas, compileall, manifesto 554 itens/3.080.086.312 bytes, receipt `daily-maintenance-20260905T0159553275463Z`, tarefa `Running`, PID 9552, lock/console iguais, duplicata 73, stderr ativo zero, fila saudável e custo R$ 0,00.

## D-092 — GC-14 pertence à Fase 7 e a transição 6→7 exige receipt independente

- Data: 2026-09-04.
- Problema: o aceite executável marcava GC-14 como requisito da Fase 6, embora `docs/07_PHASES_AND_GATES.md` e o contrato de aceite atribuam atualização de regra, aplicação futura e segunda medição à Fase 7. Isso formava dependência circular: a Fase 6 nunca poderia fechar sem executar uma capacidade proibida antes de seu próprio fechamento.
- Decisão de escopo: GC-14 permanece obrigatório e fail-closed, mas com `minimum_evidence=LATER_PHASE` e `NOT_APPLICABLE_CURRENT_PHASE` na Fase 6. Os blockers atuais e honestos passam a ser GC-01, GC-11 e GC-19. Não houve relaxamento, promoção de fixture ou antecipação do Vídeo 3.
- Transição: `phase6_transition.py` não confia apenas em `phase_decision=APPROVED`. Ele valida o schema, a ordem GC-01–GC-22, recompõe contagens/aprovados/blockers e reavalia a classe mínima de cada requisito. Divergência produz `BLOCKED`; gate incompleto produz `WAITING_FOR_PHASE6_GATE` sem receipt.
- Receipt: após zero blockers, os bytes exatos do aceite são congelados em arquivo imutável, presos por SHA-256 e referenciados por um único `phase6-to-phase7-transition-receipt.json`. Reexecução conserva os mesmos bytes. O receipt autoriza somente iniciar a Fase 7 sob D-047 e não prova YPP, audiência ou previsibilidade.
- Coordenação: o Gestor e `daily.ps1` executam o controlador depois do aceite e regeneram o painel no mesmo ciclo. O relatório executivo mostra status, blockers, receipt e próxima ação da transição.
- Prova: 19/19 testes direcionados passaram, incluindo espera sem receipt, transição idempotente e bloqueio de um relatório `APPROVED` inconsistente. A manutenção transacional integral terminou com receipt `daily-maintenance-20260905T0217562339914Z`, `255/255 PASS` em 144,712 s, `116/116` schemas válidos, compileall PASS e manifesto 554/3.080.086.312. O runtime foi recuperado em PID 15952, tarefa `Running`, lock/console coincidentes, duplicata 73, stderr zero, fila saudável e painel sem atenções; custo R$ 0,00.

## D-093 — A operação só está pronta se o Windows permanecer acordado e o token canônico sobreviver à reconciliação

- Data: 2026-09-04.
- Risco observado: display já estava em `Nunca`, mas standby em bateria era 600 s e hibernação em bateria era 10.800 s. Isso poderia suspender o processo antes do checkpoint, apesar de task/lock saudáveis.
- Decisão: `ensure_power_continuity.ps1` define e verifica `VIDEOIDLE`, `STANDBYIDLE` e `HIBERNATEIDLE` como zero em AC/DC. O receipt `power-continuity.json` é validado e passou a integrar `operational_ready`; runner e manutenção reaplicam o contrato sem serviço pago.
- Falha exercitada: mudar o runner tornou o receipt do instalador obsoleto. A manutenção re-registrou a tarefa, mas o instalador usou o fallback LocalAppData inexistente em vez do destino canônico externo já usado pelo Gestor. O bootstrap registrou `token=False`, exit 1; o verificador recusou a recuperação e nenhum PID falso foi aceito.
- Correção: installer, runner e manutenção resolvem `destination_path` do watcher OAuth e verificam a existência do arquivo externo antes de registrar. O token permaneceu fora do workspace e seu conteúdo não foi copiado ou exposto.
- Prova: incidente `power-and-token-recovery-20260905.json`; manutenção final código 0, receipt `daily-maintenance-20260905T0238557983597Z`, `256/256 PASS` em 148,539 s, `117/117` schemas, compileall PASS, manifesto 554/3.080.086.312, tarefa `Running`, PID 10316, lock/console iguais, duplicata 73, stderr zero, energia 3/3 AC/DC PASS e custo R$ 0,00.

## D-094 — Capacidade local é gate mensurável anterior à fila de mídia

- Data: 2026-09-05.
- Problema: o executor validava o receipt de produção e criava o job antes de provar disco, executáveis, modelos, diretórios e intervalos de origem. Uma falha ambiental consumiria lease/tentativa durante o render e poderia deixar artefatos parciais.
- Decisão: `production_capacity.py` produz um receipt schema-validado antes do `enqueue`. Ele executa `ffmpeg -version` e `ffprobe -version`, prova Kokoro/vozes/fonte, faz round-trip de escrita no output e temporário, valida cada origem, span, timeline e alinhamento a 30 fps.
- Cálculo: a estimativa usa 60 Mb/s para cada uma das duas cópias intermediárias simultâneas, 12 Mb/s + 256 kb/s para o final, PCM real para voz/narração/SFX/música, teto das thumbnails, 64 MiB de metadados, 25% de contingência e 5 GiB obrigatórios de espaço remanescente. Não é chute de tamanho final: é limite conservador da receita configurada, versionado como `phase6-standard-storage-v1`.
- Estado real: `WAITING_PLAN`. Infraestrutura, ferramentas, arquivos e escrita passaram; o volume C: tinha 27.632.054.272 bytes livres, requisito-base 5.368.709.120 e headroom 22.263.345.152. A capacidade de render do Vídeo 2 não é declarada antes de calcular o TakePlan exato após D1.
- Bloqueio: qualquer `CAP-TOOLS`, `CAP-REQUIRED-FILES`, `CAP-WRITABLE-PATHS`, `CAP-PRODUCTION-PLAN` ou `CAP-DISK-HEADROOM` em `FAIL` produz `BLOCKED`, `job_state=NOT_CREATED` e fila inexistente/intacta. O painel expõe receipt, bytes livres, exigidos e headroom.
- Testes: ambiente suficiente, disco insuficiente, FFmpeg ausente, span de fonte curto e integração sem criação de job foram exercitados; render real anterior continua coberto. Manutenção `daily-maintenance-20260905T0304355985727Z`: `261/261 PASS` em 147,902 s; `118/118` schemas; compileall PASS; manifesto 554/3.080.086.312.
- Runtime: tarefa `Running`, PID 1804, lock `HELD`, console `LISTENING` no mesmo processo, duplicata 73, stderr zero, energia PASS e `operational_ready=true`. Custo técnico/mídia R$ 0,00; nenhum efeito público.

## D-095 — Arquivo catalogado só entra no plano depois de prova integral de residência, conteúdo e direito

- Data: 2026-09-05.
- Risco observado: os arquivos da biblioteca ficam em árvore sincronizada pelo OneDrive. Existência, tamanho e metadados não provam que o payload completo esteja local, decodificável ou ainda corresponda ao hash/direito aprovado na hora do render.
- Decisão: `phase6_asset_residency.py` deriva o conjunto verdadeiramente elegível do manifesto corrente e lê integralmente cada ativo. O receipt registra SHA-256, bytes, flags `OFFLINE/RECALL`, probe FFprobe, duração, receipt de direitos, capacidade segura e blockers por ativo.
- Elegibilidade: `production_eligible=true`, uso comercial permitido, status de direitos aceito, quality gate `PASS` e ausência de risco de publicidade institucional. Os dois ativos NASA/Artemis permanecem excluídos, embora sejam domínio público; direito autoral não apaga risco de endorsement.
- Resultado vivo: auditoria `asset-residency-phase6-c756ec467de732712dc0bb76`, `PASS`; 29 elegíveis e 29 verificados; 783.561.975 bytes; 1.499.877 ms de capacidade segura; zero ativo bloqueado; custo R$ 0,00.
- Defesa em profundidade: o pool é auditado diariamente antes da produção; o preflight do TakePlan ainda recalcula o hash da fonte selecionada e cruza caminho, intervalo, duração, direitos e `asset_allocation.json`. Um hash alterado retorna `CONTENT_HASH_MISMATCH` e impede o enqueue.
- Observabilidade: o painel mostra status, contagens, bytes, capacidade segura e autorização de seleção. A automação `HERO Engine — rotina diária` foi atualizada no lugar para alertar apenas em falha ou bloqueio material.
- Prova final: manutenção `daily-maintenance-20260905T0324533781166Z`, `264/264 PASS` em 139,022 s, `119/119` schemas Draft 2020-12, compileall PASS, manifesto 554/3.080.086.312; tarefa `Running`, PID 15120, lock/console no mesmo processo, duplicata 73, stderr zero, energia PASS e `operational_ready=true`. Fase 6 continua `IN_PROGRESS`; nenhum upload ou gasto ocorreu nesta decisão.

## D-096 — Atraso de Analytics criativo permite somente diagnóstico de distribuição por contador exato abaixo do piso

- Data: 2026-09-05.
- Problema: `build_diagnostic_decision()` exigia `intro30sAudienceWatchRatio` para qualquer decisão D1. Se o YouTube atrasasse retenção, uma amostra evidentemente pequena permaneceria parada, embora a única conclusão segura fosse expandir a amostra sem culpar a criação.
- Decisão: diagnosis 1.1 registra `owned_views`, `public_views`, `diagnostic_sample_views`, `diagnostic_sample_source` e `eligibility_scope`. Em >=24 h, uma contagem exata do vídeo próprio abaixo do piso interno de 30 pode produzir apenas `DISTRIBUTION_SAMPLE`, `TOPIC_ANGLE`, `LOW` e `production_may_start=true`.
- Limite de inferência: o fallback não avalia CTR, hook, retenção, APV ou narrativa. Se a contagem alcançar 30, a fonte oficial falhar, o valor raw divergir ou a ação não for `TOPIC_ANGLE`, o Gestor aguarda métricas completas ou bloqueia.
- Defesa downstream: `_baseline_reassessment_pass()` não confia no rótulo do diagnosis. Ele volta ao snapshot raw e confere idade, identidade, status, fonte Data/Analytics, valor, piso, diagnóstico, variável e snapshot ID. Tanto `OWNED_24H_REASSESSMENT` quanto `CANARY_24H_BASELINE` usam essa prova.
- Protocolo: um diagnosis limitado válido ainda prende o snapshot exato e pré-registra uma única variável antes da produção. Demais constantes e todos os gates de direitos, originalidade, qualidade, canal, OAuth, cota e publicação permanecem inalterados.
- Versionamento: a primeira manutenção bloqueou a colisão do scope receipt 1.0, provando imutabilidade. O overlay foi elevado para 1.1, seu identificador entrou no receipt e na ordem, e schemas continuam aceitando 1.0 histórico. Incidente: `distribution-lag-scope-version-recovery-20260905.json`.
- Testes: 12 views públicas com retenção atrasada liberam somente tópico; 100 views sem métricas criativas esperam; full metrics preservam os quatro ramos; raw/source/variável são rechecados no escopo e na ordem.
- Prova final: manutenção `daily-maintenance-20260905T0343374319511Z`, `267/267 PASS` em 158,116 s, `119/119` schemas, compileall PASS, manifesto 554/3.080.086.312; tarefa `Running`, PID 17732, lock/console coincidentes, duplicata 73, stderr zero, energia PASS, painel `ACTIVE_OBSERVING` com zero atenções. Nenhum job de mídia, upload ou gasto ocorreu.

## D-097 — Snapshot parcial não pode adiar a decisão por 48 horas nem criar loop depois de D30

- Data: 2026-09-05.
- Problema: o agendador usava sempre a próxima janela formal. Um `PARTIAL_DATA_LAG` no D1 saltava para D3; sem janela depois de D30, substituía a ausência por 720 h e gerava timestamp vencido.
- Decisão: preservar 0/24/72/168/336/720 h e adicionar `phase6-owned-observation-policy-v1`. A partir de D1, atraso parcial recebe recolha a cada 120 min por 12 h, no máximo seis slots; depois o calendário formal retoma.
- D30: a tolerância finita absorve atraso normal do provedor sem converter nulo em zero. Ao final, `next_observation_at=null`, `reason=WINDOW_PLAN_COMPLETE` e `terminal=true`.
- Contrato: snapshots 1.1 persistem motivo, janela ativa, próxima janela/data formal, intervalo, tentativa, teto, deadline e terminal. O schema preserva 1.0 histórico e exige o novo objeto somente em 1.1.
- Configuração: 120 min/12 h em `config/engine.json`; valores fora dos limites seguros são recusados. Nenhum serviço ou gasto foi adicionado.
- Prova: 52 testes direcionados e 270 integrais PASS; receipt `daily-maintenance-20260905T0357151875938Z`, 148,846 s, 119 schemas, compileall, manifesto 554/3.080.086.312 e PID 19108 operacional.
- Limite: a mudança reduz latência operacional; não cria retenção, causalidade, previsibilidade ou garantia de monetização. A evidência real D1 continua obrigatória.

## D-098 — Erro de fonte exige retry distinto de atraso e escalada somente depois do teto

- Data: 2026-09-05.
- Problema: `collect_video_snapshot()` preservava falha de Data API como `FAILED`, mas o supervisor concluía o checkpoint e a próxima tentativa podia ficar na janela formal distante.
- Decisão: `FAILED` usa intervalo de 30 min e tolerância de 6 h/12 slots; `SOURCE_FAILURE_RETRY` permanece distinto de `DATA_LAG_RETRY`.
- Escalada: com `retry.enabled=true`, a falha fica visível sem alerta repetitivo. Depois do teto, o painel passa a `ATTENTION_REQUIRED` com `OWNED_METRICS_FAILED_RETRY_EXHAUSTED`.
- Fail-closed: snapshot `FAILED` não libera diagnosis, experimento, render, package update ou publicação. Não existe loop ilimitado.
- Prova: 54/54 testes direcionados; manutenção `daily-maintenance-20260905T0407171966381Z`, 272/272 PASS em 146,436 s; 119 schemas, compileall, manifesto 554/3.080.086.312 e PID 20192 operacional.

## D-099 — Retry de métricas só pode consumir cota após preflight no instante devido

- Data: 2026-09-05.
- Problema: o guard geral existia para upload e package update, mas a operação de leitura tinha reserva zero. Uma política de retry rápida sem margem preventiva explícita ficaria incompleta.
- Decisão: adicionar `phase6_owned_metrics_checkpoint` ao `zero_cost_guard`: reserva 1 unidade geral e piso 12. vidIQ recebe piso zero porque não é executor nem fallback exigido da coleta oficial.
- Ordem: avaliar e persistir o guard somente quando `due=true`; falha de custo/cota retorna `BLOCKED` antes de enqueue, Reporting, Data ou Analytics. Não gerar receipt antecipado evita uma falsa aprovação temporal.
- Fallback: adiar para reset gratuito, preservar cache e não habilitar billing. Dado público nunca substitui CTR/retenção quando esses campos forem obrigatórios.
- Prova: teste bloqueado confirma nenhuma chamada externa; fronteiras 9986/9988 unidades confirmam piso; manutenção `daily-maintenance-20260905T0419523321381Z`, 274/274 PASS em 159,156 s, 119 schemas, compileall, manifesto 554/3.080.086.312 e PID 18824 operacional.

## D-100 — Criatividade é decisão comparativa versionada, não receita fixa nem nota perfeita

- Data: 2026-09-05.
- Problema observado: a pré-produção selecionava evidência de mercado de forma adaptativa, mas montava hook, corpo e embalagem a partir de duas receitas textuais estáticas; além disso, o ramo FIRST8 alterava o corpo e `CreativeDirectionDecision` atribuía `1.0` a todas as dimensões. Isso não sustentava variedade real, isolamento causal nem rigor de seleção.
- Decisão: criar `phase6-adaptive-creative-compiler-v1`, com três conceitos por cluster suportado, sete componentes ponderados, checks críticos e rejeição integral quando não houver candidato elegível. O vencedor é determinístico para a mesma ordem/evidência/versão, e todas as alternativas continuam auditáveis.
- Isolamento: FIRST8 muda somente as três janelas de hook e preserva tese/corpo; BODY mantém os hooks exatos e permuta somente as seções anteriores; TOPIC cria nova tese, hooks, progressão e payoff a partir do mecanismo observado. Qualquer contaminação reprova o gate.
- Formato: o release usa `choose_format_pack()` sobre o catálogo real. O pack exato precisa estar permitido, obter score >=0,75 e conservar limitação/risco/hipótese; fit artificialmente uniforme não é aceito.
- Defesa downstream: `phase6_quality.py` valida o schema, exige pelo menos três candidatos, recomputa a elegibilidade do vencedor, confere todos os checks críticos e torna o concept decision parte dos gates `STRATEGY` e `CHANNEL_DNA`. Adulteração impede work order/release.
- Limite: os scores `0,964368` do conceito e `0,8082` do FormatPack são resultados de fixture controlada, não resultado do Vídeo 2, probabilidade viral, previsão de audiência ou garantia de monetização.
- Evidência: novos módulo/schema/testes, alterações em produção/release/quality; manutenção `daily-maintenance-20260905T0445408771607Z`, 280/280 testes PASS em 142,785 s; 120/120 schemas Draft 2020-12; compileall PASS; manifesto 554/3.080.086.312; runtime PID 13560 operacional, custo R$ 0,00 e nenhum efeito público adicional.

## D-101 — Três alternativas são insuficientes sem pressão de diversidade e prova contra cópia

- Data: 2026-09-05.
- Lacuna observada: D-100 criava três decisões distintas, mas ainda não media proximidade entre elas nem sobreposição com os títulos-fonte; o avaliador aceitava scores e resumo do próprio compilador sem recomputação independente.
- Decisão: elevar o compilador a v2/schema 1.1, expandir cada cluster atualmente suportado para seis rotas e exigir pelo menos três elegíveis. O contrato mede cinco eixos criativos e falha fechado com IDs duplicados ou busca estreita.
- Originalidade: comparar cada trecho criativo com tokens distintivos de cada título de referência, removendo somente boilerplate de formato. Uma rota com sobreposição excessiva é rejeitada; títulos curtos não viram falsos positivos por uma única palavra temática.
- Diversidade: medir proximidade lexical para TOPIC/FIRST8 e distância estrutural para BODY, porque o experimento BODY deve conservar exatamente as mesmas palavras. A rota precisa ser materialmente distinta de sua alternativa mais próxima.
- Red-team: persistir referência/rota mais próxima, sobreposições, ponto mais fraco e três desafios adversariais. O status é derivado dos checks, não uma opinião livre.
- Independência: `phase6_quality._creative_concept_integrity()` recompõe todos os nove scores, elegibilidade, quantidades, máximos e vencedor. Qualquer resumo ou score adulterado faz `STRATEGY=FAIL` mesmo que o gerador tenha escrito `PASS`.
- Limite: o banco determinístico local é a melhor capacidade sem custo presente; não há LLM local instalado e nenhuma API paga foi adicionada. A evolução futura ocorre por resultados versionados, não por aleatoriedade.
- Evidência: fixture seis de seis elegíveis, similaridade máxima 0,229730, overlap-fonte 0,090909, vencedor 0,938817; 24/24 dirigidos; manutenção `daily-maintenance-20260905T0504515349131Z`, 283/283 PASS em 163,237 s, 120/120 schemas, compileall, manifesto 554/3.080.086.312 e Gestor PID 12432 operacional. Zero efeito público e custo R$ 0,00.

## D-102 — Classe de evidência não pode vencer o score por dupla contagem

- Data: 2026-09-05.
- Defeito observado: `_select_candidate()` promovia `FULL` antes de comparar `opportunity_score`. Como o próprio score já incorpora `evidence_depth`, a implementação premiava a mesma dimensão uma segunda vez e podia escolher sinal materialmente inferior.
- Decisão: versionar `phase6-market-selection-score-first-v1`. Depois dos filtros, o ranking usa `opportunity_score DESC`; somente empates usam `evidence_class DESC`, `cross_channel_count DESC` e `candidate_id ASC`.
- Pisos fail-closed: `eligible=true`, estratégia suportada, score `>=0,65`, peso realmente observado `>=0,95`, classe conhecida e idade máxima `168 h`. A ausência de candidato retorna espera/bloqueio, nunca relaxamento do piso.
- Rastreabilidade: `selection_policy_version`, `minimum_opportunity_score`, `ranking_order` e candidato selecionado entram no artefato e no cálculo do `order_id`. O schema exige os campos quando existe candidato.
- Defesa independente: o gate `MARKET_EVIDENCE` volta ao snapshot para validar piso, peso e atualidade; o score é um ranking operacional, não causalidade, chance viral ou garantia de monetização.
- Evidência controlada: teste constrói uma hipótese `OPENING_ONLY` de score superior e uma `FULL` inferior e confirma a primeira; quando scores empatam, `FULL` desempata. Outro teste exclui score `0,649999`.
- Prova oficial: 26/26 testes dirigidos; receipt `daily-maintenance-20260905T0516293640558Z`; 285/285 testes em 145,626 s; 120/120 schemas e latest order válidos; compileall PASS; manifesto 554/3.080.086.312. Gestor `Running`, PID 7200, lock/console/singleton/energia/prontidão PASS, stderr zero; zero custo e zero efeito público adicional.

## D-103 — Candidate ID sozinho não é identidade suficiente para compilação

- Data: 2026-09-05.
- Lacuna observada: a D-102 prendia política e ID, porém `_compile_video()` voltava ao snapshot corrente e recuperava o item por esse ID. Uma atualização legítima ou adulteração que conservasse o ID poderia fornecer score, fontes, títulos ou métricas diferentes da decisão original.
- Decisão: registrar `source_snapshot_content_hash`, `source_snapshot_id`, `source_score_version` e `selected_candidate_content_hash` canônico; incluir esses valores no `order_id` e exigir padrão SHA-256 no schema.
- Barreira pré-compilação: `_resolve_bound_market_candidate()` valida os bytes exatos do arquivo, identidade/versão, unicidade, conteúdo integral e vencedor recomputado pela política D-102. Falha ocorre antes de qualquer artefato ou receipt.
- Proteção contra TOCTOU: a rota de vídeo recebe o snapshot e candidato já validados em memória. Não há nova resolução por ID entre o binding e a construção do conceito/brief.
- Abrangência: a mesma barreira vale para o ramo de embalagem, ainda que ele não altere o vídeo, impedindo que uma ordem READY seja executada sobre mercado diferente.
- Evidência: teste altera somente `opportunity_score` em `0,001`, mantém `candidate_id`, observa novo `order_id` e comprova bloqueio da ordem antiga/ausência de receipt. 27/27 dirigidos; manutenção `daily-maintenance-20260905T0527248074609Z`, 286/286 PASS em 151,805 s, 120 schemas, compileall, manifesto 554/3.080.086.312; PID 19564 operacional, custo e efeito público zero.

## D-104 — O tratamento de embalagem exige busca, binding e avaliação independentes

- Data: 2026-09-05.
- Lacuna observada: o compilador de vídeo possuía seis rotas adaptativas, mas embalagem ainda era um trio fixo; depois da seleção, o renderer aplicava outro mapa hardcoded por letra. Isso não atendia criatividade adaptativa nem garantia identidade entre hipótese, par selecionado e ativo renderizado.
- Decisão: adotar `phase6-adaptive-packaging-compiler-v1`, com seis rotas, mínimo de três elegíveis, dez componentes ponderados, gates críticos, red-team e bundle exato de três finalistas. Cada rota deve provar que o vídeo já entrega sua promessa e que a fonte visual é própria e hash-pinned.
- Binding: decisão e bundle carregam order/candidate/snapshot, versão do score e hashes D-103. Na etapa independente, o sistema relê a fonte, exige identidade única e recompõe integralmente os dois documentos; divergência bloqueia mesmo que alguém tenha atualizado o hash do receipt adulterado.
- Render: a thumbnail usa somente `render_spec` do finalista escolhido e revalida o SHA-256 da fonte. Não existe mais tabela A/B/C paralela. O vídeo, áudio, timeline, descrição e demais controles permanecem congelados.
- Causalidade: o score ordena adequação editorial e técnica; não é previsão de CTR, alcance, viralidade, monetização ou lucro. Efeito público só pode ser aprendido na janela pré-registrada posterior.
- Evidência: `31/31` testes dirigidos PASS, incluindo recomposição adversarial e render da fonte exata; manutenção `daily-maintenance-20260905T0552076616926Z`, `288/288 PASS` em `152,108 s`, `122/122` schemas Draft 2020-12, compileall e manifesto `554/3.080.086.312`. Gestor recuperado `Running`, PID `2988`, lock/console/singleton/energia/prontidão PASS; automação atualizada no mesmo ID; custo/efeito público zero.

## D-105 — Superfície Studio de outra conta não é evidência do HeroVerse

- Data: 2026-09-05.
- Observação: a tentativa read-only de abrir a área de monetização no Chrome foi redirecionada para `studio.youtube.com/channel-appeal?authuser=0`, com título “Recurso do canal – YouTube” e aviso sobre um canal não reposto. A URL direta com a conta esperada voltou ao mesmo `authuser=0`; portanto a superfície não comprovou identidade do HeroVerse nem expôs o contador YPP.
- Decisão: não atribuir o aviso, recurso ou qualquer métrica dessa sessão ao HeroVerse e não automatizar seletor/login. O campo `ypp_valid_watch_hours` permanece `null/UNAVAILABLE`; nenhuma estimativa substitui o contador oficial.
- Contraprova: consulta pública sem cota confirmou HTTP 200 em `@heroverse74`, presença do channel ID `UCuMF6pJQkyMzaVoAxFL86yA` e oEmbed do vídeo `iK_5edYQtx8` com título atual e autor `HeroVerse`. OAuth operacional continuou `HEALTHY`, tarefa `Running` e `operational_ready=true`.
- Consequência: a operação API permanece ativa; somente a precisão matemática do gap de horas YPP continua limitada. Isso não é prova de strike no HeroVerse, nem motivo para parar D1, produção condicionada ou coleta oficial.

## D-106 — “Rodou no Gestor” exige prova única de ordem, tempo, schema e identidade

- Data: 2026-09-05.
- Problema: a ordem dos executores existia no código e cada estado podia ser validado isoladamente, mas não havia um artefato único que provasse que todos haviam executado dentro da mesma iteração residente. Timestamps de heartbeat também poderiam parecer novas decisões se todo ciclo fosse arquivado.
- Decisão: materializar `phase6-control-cycle-receipt` ao final de cada loop, cobrindo exatamente 11 estágios em ordem fixa. Para cada estágio, validar o schema, exigir timestamp entre `cycle_started_at` e `cycle_completed_at` e congelar hashes dos bytes e da identidade semântica.
- Semântica de falha: arquivo ausente, schema inválido, execução fora da janela, erro ou status operacional bloqueante retorna `BLOCKED`. O resultado esperado `PHASE_TRANSITION=BLOCKED/PHASE6_ACCEPTANCE_BLOCKED`, com IDs GC não vazios, representa gate de negócio executado corretamente e não pane do ciclo.
- Compactação: a assinatura substantiva exclui timestamps. Somente `INITIAL` e `STATE_CHANGED` entram em `history`; `HEARTBEAT_ONLY` mantém `latest` observável sem inflar a memória.
- Independência: o receipt é escrito depois de congelar o painel e seus dez predecessores. A atualização posterior do painel apenas mostra o receipt; não pode retroativamente aprovar o ciclo.
- Migração segura: `scripts/daily.ps1` passou a regenerar a visão executiva derivada, com o Gestor já parado, antes de a regressão consultar GC-20. A primeira tentativa revelou a ordem antiga e falhou em dois testes; o recovery preservou o processo. A correção dirigida passou `22/22` e a segunda manutenção passou integralmente.
- Evidência: receipt oficial `daily-maintenance-20260905T0620292450294Z`, `292/292 PASS`, `123` schemas, manifesto intacto, PID `18692` operacional. Ciclo vivo `phase6-control-cycle-d727c96e7be25f6eb5603045`: `11/11`, `PASS_WAITING`, zero blocker. Ciclo seguinte `phase6-control-cycle-c7a71b8d1738f0b56db9baef`: `HEARTBEAT_ONLY`, zero archive novo.
- Limite: o receipt prova execução e integridade do controle; não prova resposta de audiência, viralidade, YPP ou monetização.

## D-107 — Aceite e aprendizado precisam atravessar um ciclo material antes da promoção

- Data: 2026-09-05.
- Lacuna observada: D-106 fechava a prova integral ao final do loop, enquanto o controlador 6→7 rodava antes dela. Um aceite recém-aprovado poderia, em tese, criar a transição na mesma iteração e usar apenas estados isolados, sem a prova material reconciliada do ciclo que os produziu.
- Decisão: exigir um `control-cycle` material anterior, arquivado e byte-identical ao histórico para qualquer criação do receipt 6→7. O ciclo precisa ter 11/11 estágios, schemas e janela válidos, `PASS_WAITING`/`PASS_ADVANCED`, zero blockers e identidades atuais de `LEARNING` e `PHASE_TRANSITION` iguais às congeladas.
- Ordem segura: se o aceite estiver aprovado e essa prova ainda não existir, retornar `WAIT_FOR_RECONCILED_CONTROL_CYCLE` sem receipt. O loop atual arquiva a mudança; a transição só pode ser reconsiderada na iteração seguinte.
- Imutabilidade: o receipt de transição incorpora o caminho histórico, SHA-256, assinatura substantiva e hashes de identidade. Seu ID depende também do hash do ciclo. Replay reabre e revalida a prova; adulteração ou ausência produz `ERROR`.
- Coerência executiva: GC-07, GC-20 e GC-22 exigem o receipt integral. O painel e o latest são ligados pela assinatura substantiva, permitindo somente uma mudança de heartbeat sem mudança semântica.
- Evidência: cenários sem ciclo, reconciliação posterior, repetição idempotente e adulteração histórica foram exercitados; suíte dirigida `20/20 PASS`; manutenção `daily-maintenance-20260905T0636010787762Z`, `293/293 PASS` em `163,95 s`, `123` schemas, manifesto intacto e PID `18320` operacional.
- Estado/limite: Fase 6 segue `IN_PROGRESS`, bloqueada apenas por GC-01/11/19. Essa decisão reduz risco de promoção prematura; não garante o resultado de audiência ou a monetização em 30 dias.

## D-108 — Urgência de 30 dias precisa de trajetória observada, não de confiança subjetiva

- Data: 2026-09-05.
- Lacuna observada: havia baseline público de 265 inscritos, mas o snapshot próprio media apenas o canário. O painel não conseguia provar o total corrente nem o ritmo necessário/observado em relação a 1.000.
- Decisão de fonte: atualizar o snapshot para 1.2 nos próximos checkpoints, chamando `videos.list` e `channels.list(mine=true)` somente depois de um preflight gratuito que reserva 2 unidades gerais e mantém piso 12. A resposta de canal precisa coincidir com `UCuMF6pJQkyMzaVoAxFL86yA`.
- Decisão temporal: a janela usa primeiro `published_at` da medição oficial; somente na ausência usa o receipt de publicação. Início `2026-09-04T18:45:51Z`, deadline `2026-10-04T18:45:51Z`; ambos participam da assinatura substantiva.
- Decisão matemática: materializar baseline/atual/meta, gaps, ganho líquido, dias, ganho linear esperado, delta, ritmo observado, ritmo exigido e razão. Ausência de total oficial atual é `null`, não 265 reapresentado como atual.
- Limite YPP: `estimatedMinutesWatched` não equivale a horas públicas válidas. O gap de 4.000 horas permanece indisponível até fonte oficial identificada.
- Autoridade: a pressão `MEASURE/CONTROLLED/HIGH/MAXIMUM_WITHIN_GATES/VERIFY_YPP` altera prioridade, nunca direitos, Quality Gates, escopo de experimento, orçamento ou permissão de publicação.
- Evidência: testes críticos `25/25 PASS`; regressão oficial `299/299 PASS` em `165,614 s`; `124` schemas e sete instâncias vivas PASS; receipt `daily-maintenance-20260905T0707027468681Z`; Gestor `Running` PID 3524, stderr zero, console/energia/prontidão PASS; custo R$ 0,00.
- Estado: antes de D1, a classificação correta é `WAITING_FOR_CURRENT_CHANNEL_METRICS`. O controlador agenda a coleta exata e não cria chamada, preflight, publicação ou gasto antecipado.

## D-109 — Uma trajetória que governa a operação precisa estar dentro da prova do ciclo

- Data: 2026-09-05.
- Problema: o receipt de ciclo ainda possuía 11 estágios. `goal-trajectory/latest.json` era produzido antes do painel, mas não tinha freshness, hash nem identidade congelados no ciclo que alimentava aceite e transição.
- Decisão: criar o contrato `phase6-control-cycle` 1.1 com exatamente 12 estágios e `GOAL_TRAJECTORY` depois de `LEARNING`. O estágio registra schema, `evaluated_at`, content hash e identity hash baseado em trajectory ID, assinatura substantiva e custo.
- Compatibilidade: o schema continua validando receipts 1.0/11 para preservar a história, mas `control_cycle_healthy` aceita somente 1.1/12. O painel 1.1 omite a prova legada durante a primeira iteração de upgrade, em vez de rotulá-la como nova.
- Semântica de aceite: ausência de painel reconciliado é `MISSING_EVIDENCE`, não `FAIL` nem `PASS`. Isso mantém a transição fechada sem criar um deadlock autorreferente entre aceite, transição, painel e ciclo.
- Binding de transição: o futuro receipt 1.1 inclui `goal_trajectory_identity_hash`; criação e replay verificam a identidade congelada. Teste altera a assinatura viva depois do ciclo e obtém `WAIT_FOR_RECONCILED_CONTROL_CYCLE`, sem receipt.
- Preservação de falha: erro corrente de migração é movido byte a byte para `control-cycle/errors/archive` somente depois de um ciclo válido. Colisão divergirá e bloqueará.
- Evidência: 28/28 testes dirigidos; regressão 302/302 em 151,595 s; 124 schemas, sete instâncias vivas e sete receipts históricos PASS; manutenção `daily-maintenance-20260905T0732356315080Z`; runtime PID 21388 operacional, ciclo 1.1/12 sem blocker e custo R$ 0,00.
- Limite: o novo estágio prova que a meta medida governou a iteração; não prova antecipadamente resposta da audiência, horas YPP ou monetização.

## D-110 — Falha da contagem de inscritos não invalida conteúdo observado nem pode esperar até D3

- Data: 2026-09-05.
- Problema: `collect_video_snapshot()` tratava `channels.list` como fonte auxiliar. Se vídeos e Analytics passassem, o snapshot ficava `OBSERVED/ELIGIBLE_FOR_COMPARISON`, mas a contagem atual permanecia nula e `next_observation_at` saltava para a próxima janela formal. No D1 isso significaria até 48 horas sem medir o ritmo da meta.
- Decisão: snapshot 1.3 separa a validade criativa da disponibilidade do contador. Erro/identidade divergente de canal aciona a mesma política técnica finita de 30 minutos/6 horas sem alterar um baseline criativo já válido.
- Estados: `OBSERVED`, `RETRYING_SOURCE_FAILURE`, `SOURCE_FAILURE_RETRY_EXHAUSTED` e `UNAVAILABLE_HIDDEN_SUBSCRIBER_COUNT` são registrados em `goal_measurement`, junto do próximo retry, exaustão e causa. Nunca se imputa um total.
- Supervisão: retry ativo permanece silencioso; exaustão cria `SUBSCRIBER_TRAJECTORY_SOURCE_RETRY_EXHAUSTED`. Contagem escondida é estruturalmente indisponível e não desperdiça cota tentando repetidamente.
- Compatibilidade: schemas 1.0–1.2 continuam aceitos como evidência histórica; somente novas coletas usam 1.3. O Gestor consome o `next_observation_at` mais cedo sem navegador, pagamento ou publicação.
- Evidência: 26/26 testes dirigidos, incluindo rejeição schema-validada de estado contraditório; regressão oficial `306/306 PASS` em `162,589 s`; `124/124` schemas e compileall PASS; receipt `daily-maintenance-20260905T0759095235067Z`; manifesto 554/3.080.086.312; PID 20304, lock e tarefa ativos, ciclo 12/12 sem blocker, painel sem alerta e custo zero.

## D-111 — “Diário” significa observação oficial diária, não recálculo sobre um contador antigo

- Data: 2026-09-05.
- Problema: o controlador D-108 recalculava dias e ritmo continuamente, mas sua única fonte corrente vinha dos checkpoints criativos espaçados. Depois de D1, o total de inscritos poderia permanecer congelado até D3; após D3, até D7. Isso não satisfazia controle diário preciso da meta.
- Decisão de arquitetura: criar um observador de estatísticas de canal subordinado ao Gestor, com calendário D1–D30 e fila transacional própria dentro da operação existente. Ele atualiza apenas o sinal de trajetória e não participa como um décimo terceiro estágio; sua identidade/estado entra na assinatura do estágio `GOAL_TRAJECTORY` já existente.
- Decisão de cota: se a coleta criativa do mesmo slot já contém channel ID e contador válidos em arquivo imutável, reutilizá-la com 0 unidade. Caso contrário, reservar exatamente 1 unidade gratuita, manter piso preventivo 12 e chamar apenas `channels.list(mine=true)`. Billing continua desativado e custo R$ 0,00.
- Decisão temporal: retry fixo de 30 minutos, 12 tentativas dentro de 6 horas. Contador oculto é indisponibilidade estrutural e termina o slot. Em retorno após downtime, não reproduzir backlog contra dados atuais: arquivar o job vencido como supersedido e observar somente o último slot devido.
- Decisão de fonte: a trajetória aceita apenas contagem oficial com identidade exata e escolhe o `captured_at` mais recente. A medição registra `OWNED_VIDEO_CHECKPOINT`, `DAILY_CHANNEL_OBSERVER` ou `UNAVAILABLE`; baseline 265 nunca é disfarçado de total corrente.
- Decisão de aprendizado: a observação diária não chama diagnóstico, previsão criativa nem avaliação do tratamento. Ela mede desvio da meta; o experimento continua dependente das janelas e métricas pré-registradas.
- Evidência: 317/317 testes em 156,457 s; 126/126 schemas; compileall; manutenção `daily-maintenance-20260905T0834440018404Z`; fila viva com job D1 pendente; ciclo 12/12 `PASS_WAITING`; painel sem atenção; Gestor PID 14972 operacional; custo e efeito público zero.

## D-112 — O calendário executivo deve distinguir medição, diagnóstico e publicação

- Data: 2026-09-05.
- Problema: depois da D-111, o backend possuía observações oficiais D1–D30, mas o workbook ainda marcava dias intermediários como sem checkpoint. Isso criava uma divergência operacional visível e escondia a cadência real de controle.
- Decisão: em `30-Day Plan`, D1–D30 são sempre observações de canal agendadas. D1/D3/D7/D14/D30 identificam também a coleta criativa; os demais dias declaram que não reabrem o diagnóstico.
- Separação de autoridade: `Scheduled` descreve a medição, não uma publicação. `Release control` permanece `No release precommitted`, a nota rejeita promessa de post e o gasto continua zero.
- Evidência: builder e teste de contrato atualizados; workbook de 41.920 bytes exportado com SHA-256 `06EB061810416762E3163212EB63ED4CEB45D6D22F897DBF3A8AB79B413E5CA8`; todas as 14 abas renderizadas; inspeção A1:H35 sem lacunas intermediárias; scan de fórmula sem erro; `2/2` testes dirigidos PASS. Nenhum canal, vídeo, credencial, cota ou gasto externo foi alterado.

## D-113 — Baseline histórico nunca substitui uma observação corrente

- Data: 2026-09-05.
- Problema: a trajetória D-111 mantinha corretamente `current_subscribers=null` antes do D1, mas o painel executivo recaía no snapshot histórico de 265. A planilha então mostrava 265 como atual, gap 735 e três cenários de views derivados de uma premissa temporal falsa.
- Decisão de dados: `executive-status` 1.2 separa baseline/instante histórico de atual/flag/origem/instante corrente. O alias `observed_subscribers` continua compatível, mas significa somente medição oficial atual e permanece nulo quando ela não existe.
- Decisão de cálculo: gap e qualquer projeção dependente do total atual não são calculados enquanto `current_subscribers_observed=false`. O workbook mostra `UNAVAILABLE`, preserva o baseline em bloco contextual datado e volta a habilitar as fórmulas somente após fonte oficial schema-válida.
- Compatibilidade: versões 1.0/1.1 permanecem aceitas como história; 1.2 exige os seis campos novos e coerência fail-closed entre flag, valores, fonte e captura.
- Resiliência incidental: a primeira manutenção encontrou o console local iniciando em pouco mais de 5 s. O limite default passou a 30 s, ainda exigindo que thread, receipt, PID, lock e console coincidam; não houve relaxamento de gate.
- Evidência: 34/34 testes dirigidos, 319/319 regressão em 163,591 s, 126/126 schemas, compileall e manifesto 554/3.080.086.312; receipt `daily-maintenance-20260905T0909256526361Z`; Gestor `Running` PID 7956 e `operational_ready=true`. Workbook 42.069 bytes, SHA-256 `CE18BA8CD3235D9E396846BE7F63055F2ADAEA71E7509A3F043341CE7392DAFB`, 14 renders, zero erro de célula e data UTC visualmente legível.
- Continuidade: a automação `hero-engine-rotina-di-ria` foi atualizada no lugar, permanece `ACTIVE` e contém D-112/D-113 uma única vez.
- Limite: a correção elimina precisão falsa; não cria dados antes da fonte, não altera o canal, não antecipa D1, não publica e não garante monetização.

## D-114 — A referência pré-publicação não mede o ritmo iniciado na publicação

- Data: 2026-09-05.
- Observação: o baseline 265 foi capturado `28,226944 h` antes da largada. Embora corretamente rotulado como histórico pela D-113, a trajetória ainda usava sua variação contra o D1 e dividia pelo tempo da janela pública, misturando períodos incompatíveis.
- Decisão: preservar o baseline como referência e calcular o gap atual quando houver fonte oficial, mas reter todo indicador de velocidade até existirem duas origens oficiais distintas capturadas entre a publicação e o deadline. A primeira medição dentro da janela vira a âncora; as seguintes são comparadas contra ela.
- Identidade: `OWNED_METRICS_REUSE` aponta para a mesma origem do checkpoint próprio e é deduplicado. Timestamp de wrapper não cria observação independente.
- Contratos: `phase6_goal_trajectory.schema.json` 1.2 e `phase6_executive_status.schema.json` 1.3; versões anteriores continuam válidas como história. O estado `CURRENT_GAP_MEASURED_PACE_PENDING` representa gap observado sem falsa leitura de ritmo.
- Limite: esse método mede ritmo verificável desde a primeira observação interna, não reconstrói o contador exato do instante de publicação e não garante monetização, alcance ou YPP.
- Custo e efeito externo: R$ 0,00; nenhum.
- Evidência: teste dirigido de trajetória/painel/ciclo/observador 33/33 PASS e migração histórica dedicada PASS; manutenção final `daily-maintenance-20260905T0934146020327Z`, 321/321 PASS em 164,288 s, 126/126 schemas, compileall e manifesto 554/3.080.086.312. Gestor `Running`, PID 19968, mesma cadeia em tarefa/lock/console, stderr zero e `operational_ready=true`.
- Incidente preservado: a primeira manutenção recusou o painel 1.3 porque o `latest` ainda era 1.1 e não possuía o novo campo. O leitor passou a derivar somente o afastamento temporal verificável e a manter o ritmo indisponível; depois materializa 1.2. O fail-closed não foi removido.

## D-115 — Evidência de trajetória exige contrato, identidade, confinamento e twin imutável

- Data: 2026-09-05.
- Problema observado: `_official_subscriber_candidates` aceitava um registro pela presença de poucos campos. Não havia prova integral do schema para o histórico próprio, vínculo filename/ID, igualdade byte a byte do `latest` nem contenção forte do `evidence_path` usado por `OWNED_METRICS_REUSE`.
- Decisão: validar todo ponto candidato no schema integral; exigir pasta exata, filename igual ao identificador interno e twin imutável byte-identical para cada visão `latest`. Erro de parse, schema, identidade, caminho, twin ou conteúdo passa a interromper o cálculo com causa explícita.
- Binding de reuse: o wrapper diário só compartilha a origem do checkpoint quando channel ID, status da API, contador, precisão, hidden flag, videoCount e viewCount coincidem com o arquivo próprio imutável schema-válido; o caminho absoluto, externo, mutável ou de outra pasta é recusado.
- Compatibilidade sem reescrita: o snapshot `own-performance-iK_5edYQtx8-20260904T185457Z.json`, criado antes de `reach_reporting_api` tornar-se obrigatório no contrato 1.0, foi preservado pelos bytes e excluído da trajetória apenas pelo SHA-256 exato `e0dd8a148b78f8aa1337ca44bd52f5ba8f79c315d0b103823dd11f98eb6d1bc3`. Ele não possui fonte/medição de inscritos e jamais pode ser âncora. Alterar um byte elimina a exceção e bloqueia.
- Incidentes/recovery: o primeiro ciclo pós-correção bloqueou porque o processo residente ainda carregava a implementação anterior; o segundo receipt de regressão não foi emitido porque o teste vivo recusou o estado transitório. Depois da iteração reconciliada, a manutenção final passou. Arquivamento hash-bound remove erros correntes somente após sucesso, preservando os bytes em `errors/archive`.
- Evidência: 45/45 testes dirigidos; 327/327 regressão em 145,037 s; receipt `daily-maintenance-20260905T1003452840119Z`; ciclo 12/12 `PASS_WAITING`; PID 17852; `operational_ready=true`; zero atenção, stderr, blocker técnico, custo ou efeito público.
- Limite: integridade de medição reduz erro de decisão; não cria dados antes do D1, não garante audiência ou YPP e não autoriza gasto/publicação por si só.

## D-116 — Regressão estável e prontidão viva são provas distintas e ambas obrigatórias

- Data: 2026-09-05.
- Problema: a manutenção precisa parar o escritor residente para testar uma snapshot coerente. Exigir `PASS_LIVE` durante essa janela mistura prova unitária com disponibilidade transitória; por outro lado, aceitar somente o `OK` da suíte não prova que o novo código reiniciou e executou o fluxo integral.
- Decisão: a suíte valida a classificação real do avaliador contra o estado então disponível. Depois do receipt PASS, a manutenção recupera a tarefa, executa o verificador de processo, espera um ciclo 12/12 iniciado após `completed_at`, rematerializa aceite/transição/painel e exige um verificador pós-manutenção separado antes do exit 0.
- Encadeamento temporal: `maintenance.completed_at <= runtime.verified_at <= ciclo posterior`; o aceite precisa ser gerado depois do ciclo consumido; o painel precisa ser capturado depois do ciclo e carregar o mesmo `cycle_id/decision`; o receipt final vem por último.
- Evidência persistente: cada fonte validada é lida uma vez, seu hash é calculado sobre esses mesmos bytes e os bytes são arquivados imutavelmente. O receipt e seu history referenciam as cinco snapshots; não dependem de `latest` mutáveis para auditoria futura.
- Aceite: os blockers listados precisam coincidir com os checks requeridos não aprovados e só podem ser GC-01, GC-11 e GC-19 nesta janela. GC-07/20/22 precisam estar `PASS_LIVE`. Qualquer arquivo de erro corrente bloqueia.
- Recuperação: tarefa agendada instalada, mesmo inicialmente parada, é iniciada e precisa produzir a prova. Tarefa ausente não pode gerar manutenção verde. Corrida entre writers recebe apenas retry curto com recomputação dos derivados; falha semântica persistente permanece fechada.
- Evidência: 16/16 testes dirigidos finais; regressão oficial 334/334 em 169,420 s; 127 schemas e compileall PASS; manutenção `daily-maintenance-20260905T1025297907302Z`; verificação `phase6-post-maintenance-213f09ce4d5210e2cfba5ae9`; cinco snapshots existentes e cinco hashes válidos; ciclo `phase6-control-cycle-c61632ca76f9c3fc71e2199f`; runtime PID 6776 operacional.
- Custo/efeito externo: R$ 0,00; nenhuma chamada antecipada, Ads, upload, alteração de metadados ou publicação adicional.
- Limite: provar recuperação e execução integral reduz falsos verdes e falsos negativos; não é garantia de monetização ou audiência.

## D-117 — O outcome de uma previsão é um efeito externo e exige preflight próprio

- Data: 2026-09-05.
- Problema: `phase6_prediction_runtime.py` coletava o estado final do vídeo no horizonte, mas essa rota não materializava o zero-cost guard usado pelo checkpoint D1. Ser apenas uma leitura não elimina consumo de cota nem satisfaz o contrato permanente de custo zero.
- Decisão: registrar `phase6_prediction_outcome_checkpoint` no guard, com reserva de 2 unidades gerais, piso preventivo 12, risco de cobrança nulo, fallback local/espera e nenhuma dependência de vidIQ.
- Atomicidade: antes de qualquer chamada, o Gestor grava no job o caminho confinado e o hash do preflight imutável. Assim, um crash entre a prova e a coleta não perde a identidade da autorização técnica.
- Idempotência: depois de um snapshot externo válido, falha na avaliação não permite nova coleta. O retry revalida snapshot e preflight exatos. Qualquer divergência de bytes, operação, custo, reserva, piso ou permissão interrompe o fluxo em vez de contornar o guard.
- Estado bloqueado: observação de cota ausente/bloqueada devolve `WAITING_FOR_RETRY`, agenda cinco minutos e faz zero chamada. Isso é espera segura, não sucesso parcial.
- Evidência: 14/14 testes dirigidos de prediction/zero-cost, 29/29 incluindo Gestor e regressão oficial 338/338 em 168,672 s; 127 schemas, compileall e manifesto 554/3.080.086.312 PASS. Manutenção `daily-maintenance-20260905T1042233896565Z`; prova pós-restart `phase6-post-maintenance-59e192d45a705806b8dfd5eb`; runtime PID 12168 e ciclo 12/12.
- Efeito/custo: R$ 0,00; nenhum acesso antecipado, upload, alteração de metadados, Ads ou publicação adicional.
- Limite: esse controle garante disciplina da operação dentro da evidência disponível; resultado de audiência e elegibilidade do YPP continuam externos.

## D-118 — Espera de cota é estado de fila; leitura concluída é evidência imutável

- Data: 2026-09-05.
- Problema 1: informar `next_observation_at=+5 min` sem atualizar o job permitia ao loop reavaliar o guard a cada minuto. Não havia chamada externa, mas o scheduler não cumpria o próprio contrato temporal.
- Decisão 1: adicionar `TransactionalQueue.defer`, restrito a `PENDING/RETRY_WAIT`, que grava o novo `available_at` sem lease e sem consumir tentativa. Estados `LEASED/SUCCEEDED/DEAD_LETTER` são recusados.
- Problema 2: o observador de aprendizado futuro tinha duas rotas — package e Vídeo 2 — sem zero-cost guard próprio; uma falha depois da coleta podia repetir Reporting e métricas.
- Decisão 2: usar `phase6_treatment_metrics_checkpoint` com reserva de 2 unidades gerais e piso 12. Persistir path/hash do preflight antes das chamadas e copiar cada resultado concluído para o diretório imutável do job.
- Retomada: o checkpoint discrimina etapas. Um registry já arquivado não é chamado novamente; um snapshot completo permite avaliar sem token nem nova consulta. Reuse exige diretório/filename/hash/schema e a prova de quota exata. Adulteração bloqueia fail-closed.
- Evidência: 34/34 testes do núcleo, 26/26 integração e regressão oficial 344/344 em 168,341 s; 127 schemas, compileall, manifesto 554/3.080.086.312. Manutenção `daily-maintenance-20260905T1101010831568Z`, prova `phase6-post-maintenance-d6809992fc2e235118d6effd`, PID 1868 e ciclo 12/12.
- Efeito/custo: R$ 0,00; nenhum API call antecipado, upload, alteração pública ou Ads.
- Limite: evidência imutável elimina repetição acidental; não melhora uma métrica do público por si só.

## D-119 — O D1 não repete Reporting nem métricas quando a inteligência falha

- Data: 2026-09-05.
- Problema: embora o guard viesse antes das APIs, o preflight D1 não era imutável nem checkpointado. Reporting era registrado por caminho mutável, métricas só apareciam no sucesso final e uma falha do compilador repetia as duas chamadas.
- Decisão: adotar journal transacional com `quota_preflight`, `reporting_registry` e `metrics_snapshot`, cada um com hash. Arquivar os bytes no diretório exato do job imediatamente depois de cada efeito e atualizar o checkpoint mantendo campos anteriores.
- Cota: criar/localizar o job antes do guard. Se a quota não passar, persistir a prova negativa, `RETRY_WAIT` e +5 min sem lease ou tentativa. Não existe polling contraditório a cada minuto.
- Retomada: prova de métricas completa permite retry sem token nem chamada; prova só de Reporting permite executar apenas a métrica restante sob novo preflight. Hash/path/schema divergente bloqueia. `latest` divergente do arquivo congelado também bloqueia a inteligência.
- Observabilidade: inicializar a seção de trabalho como `RUNNING`; somente bloqueio esperado define `BLOCKED`. Exceção técnica passa a `ERROR` e preserva o retry, em vez de ser mascarada.
- Evidência: caso de falha da inteligência retomou sem chamadas e terminou com três hashes; 61/61 testes dirigidos e regressão 345/345 em 164,237 s. Manutenção `daily-maintenance-20260905T1115050215909Z`, prova `phase6-post-maintenance-2cd02d38995aa00ddb3bd6eb`, PID 5832, ciclo 12/12.
- Custo/efeito: R$ 0,00; nenhuma chamada D1 antecipada, upload, alteração pública ou Ads.
- Limite: confiabilidade da coleta não equivale a garantia de atingir YPP; a reação do público continua uma variável externa.

## D-120 — Leitura diária de inscritos é uma transação externa recuperável

- Data: 2026-09-05.
- Problema: o observador diário tinha zero-cost guard, mas o receipt era uma visão `latest` mutável e a resposta de `channels.list` não entrava no journal antes da persistência final. Uma queda posterior podia repetir a unidade de cota. Bloqueio de cota também avançava o retry de fonte, embora nenhum efeito tivesse ocorrido.
- Decisão: materializar o preflight por job em histórico imutável, validar operação/custo/reserva/piso e prender path/hash no SQLite antes da chamada. Arquivar a leitura normalizada no slot nominal diário imediatamente após a resposta e antes da observação derivada.
- Identidade: o novo contrato fixa operação, job de origem, canal, janela, captura, status, métricas e prova de cota. ID e filename derivam da carga canônica; bytes são presos por SHA-256. Slot com múltiplos artefatos, path escape, hash/schema/ID divergente ou preflight não permitido é inválido.
- Recuperação: retry lógico da mesma janela procura primeiro a leitura congelada. Se existir e passar todos os vínculos, nenhuma API é construída ou chamada. Falha posterior preserva checkpoints anteriores ao gravar o motivo de retry.
- Cota: `TransactionalQueue.defer_claimed` exige lease ativo do mesmo worker, limpa o lease e reverte somente a tentativa pré-efeito. `QUOTA_WAIT` agenda cinco minutos, mantém tentativa zero e nunca é confundido com falha de fonte.
- Evidência: 18/18 testes dirigidos; queda simulada depois da API retomou com uma chamada total; adulteração bloqueou sem segunda chamada; quota desconhecida fez zero chamadas e zero tentativa. Regressão oficial 349/349 em 142,924 s; 128 schemas, compileall, manutenção `daily-maintenance-20260905T1136554953693Z`, prova `phase6-post-maintenance-6fbc800f60c9e2e9fcd547e3`, PID 9756 e ciclo 12/12.
- Custo/efeito: R$ 0,00; nenhuma chamada antecipada, upload, alteração pública ou Ads.
- Limite: atomicidade local protege a retomada depois de uma resposta arquivada; indisponibilidade física de disco exatamente antes do primeiro write continua como falha técnica explícita, nunca como falsa confirmação de coleta.

## D-121 — Protocolo ativo não deriva e aceite exige a cadeia causal exata

- Data: 2026-09-05.
- Problema experimental: `materialize_current` recompunha o protocolo a cada snapshot. Depois do primeiro `PREREGISTERED`, uma medição posterior poderia selecionar outra variável ou baseline e sobrescrever a visão `latest` durante o mesmo experimento.
- Decisão experimental: o primeiro protocolo real válido torna-se `experiments/active.json`, escrito de forma imutável. Enquanto ele existir, o compilador valida seu schema e força `latest.json` a ser byte-idêntico. Novo diagnóstico permanece evidência observável, mas não troca retrospectivamente a hipótese em tratamento.
- Problema de aceite: GC-01 confiava no estado genérico de um runtime e GC-19 varria avaliações schema-válidas sem provar que pertenciam à previsão atual. Evidência sintaticamente boa, porém causalmente alheia, poderia elevar o estado.
- Decisão de aceite: reconciliar paths confinados, schemas completos, IDs e timestamps da cadeia real. GC-01 só passa com o protocolo ativo, baseline referenciado, receipt da única ação autorizada, snapshot do tratamento congelado no job e avaliação de aprendizado correspondente. GC-19 só passa com a previsão `current`, seu runtime, job, snapshot de outcome e avaliação nominal exata; outcome calibrado precisa superar o baseline e outcome withheld precisa comprovar retenção disciplinada.
- Problema de cota: `observed_usage` oficial podia ser transportado de um dia de cota anterior. Esse valor não era consumo atual, mas também não podia ser ignorado sem uma margem para chamadas não instrumentadas. O fallback de package divergira do enum do schema.
- Decisão de cota: derivar o dia em `America/Los_Angeles`; usar a base oficial apenas quando o `quota_day` coincide; somar uploads confirmados do dia e uma reserva fixa conservadora de 2.000 unidades; limitar o efetivo aos limites oficiais e bloquear no piso preventivo. Persistir a contabilidade schema-válida e manter billing desabilitado. Diferenciar fallbacks de publicação, package e observação.
- Evidência inicial: 69/69 testes críticos PASS em 19,253 s. Casos cobertos: deriva de protocolo, runtime superficial, avaliação alheia, cota defasada, cota alta no mesmo dia, fallback de package e indisponibilidade da fonte.
- Evidência oficial: regressão integral 356/356 em 167,554 s, 128 schemas e compileall PASS; manutenção `daily-maintenance-20260905T1213092631813Z`; prova pós-restart `phase6-post-maintenance-5b0ea6528029e67fd4243945`; runtime PID 4408; ciclo `phase6-control-cycle-047c8fa7507f244b5082ae12` 12/12 `PASS_WAITING`, zero blocker, alerta ou erro corrente. A contabilidade viva registrou 2.000/10.000 unidades gerais efetivas, sem billing.
- Continuidade: a automação diária foi atualizada no mesmo ID e a cláusula D-121 ocorre uma vez. Antes do D1, `active.json` ausente é obrigatório; antecipá-lo seria falsa evidência.
- Efeito/custo: nenhuma chamada externa, upload, alteração de canal, Ads ou gasto; R$ 0,00.
- Limite: o protocolo só será criado no D1 válido e o ciclo causal só poderá passar depois do tratamento e da avaliação reais. Segurança metodológica não é garantia de audiência, receita ou aprovação do YPP.

## D-122 — Uma hipótese ativa prende a versão exata do diagnóstico

- Data: 2026-09-05.
- Problema: o protocolo ativo estava imutável, mas seu ponteiro para `diagnoses/latest.json` não estava. Isso permitia deriva causal indireta em um checkpoint posterior.
- Decisão: protocolo 1.1 referencia `diagnoses/<diagnosis_id>.json`; ordem de tratamento guarda path/hash dos dois documentos. A compilação revalida os bytes e toda a cadeia sem confiar no rótulo READY.
- Segurança: filename/ID, confinamento, schema, canal, baseline, variável, métrica e alvo precisam coincidir; `active/latest` do protocolo precisam ser byte-idênticos. Qualquer divergência falha antes de gerar artefato.
- Compatibilidade: 1.0 é histórico; somente 1.1 pode alimentar uma nova compilação real.
- Evidência dirigida: 40/40 PASS em 17,680 s; latest posterior não rebinda, diagnóstico adulterado bloqueia por hash e protocolo divergente bloqueia.
- Migração imutável: alterar os gates do scope exigiu overlay 1.2; alterar o protocolo de espera exigiu a versão 1.1 no filename. Duas manutenções recusaram corretamente as colisões antigas, o `finally` recuperou o Gestor e nenhum histórico foi sobrescrito.
- Evidência oficial: 363/363 PASS em 218,863 s; 129 schemas e compileall; maintenance `daily-maintenance-20260905T1300374758556Z`; verificação `phase6-post-maintenance-4c3b3614f5716a14f37d4d9a`; PID 18828 e ciclo 12/12 sem blocker.

## D-123 — Créditos são preservados por eficiência, não por rebaixamento

- Data: 2026-09-05.
- Requisito: sempre usar o melhor modelo Codex suportado e esforço `ultra`; uma versão futura superior pode substituir a atual somente após disponibilidade real e regressão comparativa.
- Decisão: adotar `codex-best-quality-capacity-governance-v1`, com reserva semanal de 10%, faixas GREEN/AMBER/RED/CRITICAL_RESERVE e continuidade do Gestor local quando trabalho Codex discricionário precisa aguardar.
- Redução de consumo: evitar retrabalho por preflight, batching, hash de inputs, checkpoints, retomada e testes escalonados. Nenhuma faixa autoriza modelo inferior ou esforço menor.
- Limite honesto: uso é account-wide e varia com contexto/complexidade/ferramentas; logo não existe garantia técnica de saldo eterno. Compra/auto top-up são proibidos e resets gratuitos só podem ser usados por ação compatível com os controles da plataforma.
- Evidência viva pós-manutenção: `codex-usage-4a501a12f7789871`, 37% usados, 63% restantes, GREEN, renovação `2026-09-10T09:56:07Z`, três resets preservados, custo R$ 0,00. A variação observada da rodada foi 1 ponto percentual account-wide, sem falsa atribuição por tarefa. Três testes próprios e 40/40 no conjunto dirigido passaram.
- Automação: o heartbeat existente foi atualizado no mesmo ID, permanece ACTIVE e contém D-122/D-123 uma vez. Ele consulta o limite antes de trabalho pesado e não cria polling adicional.
- Evidência integral: a regressão oficial D-122/D-123 passou 363/363 e a prova viva pós-restart passou; nenhum reset, compra, auto top-up, API paga ou efeito público foi realizado.

## D-124 — O estimador planeja; somente o Kokoro exato prova encaixe

- Data: 2026-09-05.
- Problema: orçamento de palavras ou duração estimada não comprova que a locução real cabe no slot. No corpo `TOPIC_ANGLE`, operar sem margem material ainda permitiria que variação do sintetizador chegasse tarde ao executor.
- Decisão de planejamento: usar o perfil `am-onyx-kokoro-planning-v2` e reservar, por take de corpo, `ceil(max(400 ms, 10% da duração estimada) / 100 ms) * 100 ms`. O arredondamento é sempre para cima na grade de 100 ms; hooks preservam suas janelas próprias.
- Decisão de execução: somente a síntese com o Kokoro local exato, presa ao modelo, voz, velocidade, TakePlan e script, constitui prova de encaixe. Todos os WAVs são produzidos e medidos em staging antes de enqueue/claim; qualquer excedente ou divergência invalida o conjunto inteiro.
- Proibições: não truncar WAV, não acelerar a locução para caber e não tratar estimativa como áudio observado. A correção deve ocorrer no texto ou no planejamento, antes do efeito.
- Limite: manifesto de voz `COMPLETE` não autoriza render final nem publicação; todos os gates posteriores permanecem obrigatórios.

## D-125 — Remediação de compiler/timing só pode substituir mídia antes de qualquer efeito

- Data: 2026-09-05; receipt registrado em `2026-09-06T00:25:20.038035Z`.
- Problema: um job de mídia criado antes do binding atual de compiler e timing não pode ser executado, mas apagá-lo ou reusar seu ID ocultaria a linhagem histórica.
- Decisão: criar a classe exclusiva `PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION`. Antigo e novo precisam estar em `PENDING`/`RETRY_WAIT`, sem lease e com checkpoint `{}`; qualquer efeito, claim ativo ou checkpoint não vazio bloqueia a supersessão.
- Invariantes: operação, canal, protocolo, tratamento `TOPIC_ANGLE`, candidato, autoridade de direitos, custo R$ 0,00 e `publication_authorized=false` permanecem idênticos e presos por hash. Somente diferenças explicitamente permitidas de identidade do compiler, timing de voz, linhagem derivada, timeline e alocação determinística segura podem passar. Histórico e artefatos anteriores são preservados; o job antigo deixa de ser reivindicável.
- Evidência viva: receipt `output/operations/phase6/runtime/media-job-supersession-receipts/phase6-media-supersession-511dbf21c5bb4c4cf3b1f455.json`; `job-faae3c79b330903828e90cc7` foi substituído por `job-c516db5685acbbb423199bc1`, ligado ao receipt `phase6-production-inputs-79b3e183dd5df410fb3a`.
- Prova de voz: `output/production/phase6/video-002/audio/manifests/voice-phase6-acec0efc9c0365039525.json` está `COMPLETE`, contém 90 takes, timing contract `phase6-pinned-voice-slot-v2`, hook `PASS` e `publication_approved=false`.
- Verificação atual: testes focais `83/83 PASS`. A manutenção integral corrente ainda não passou; por isso esta decisão não fecha a Fase 6, não promove a Fase 7 e não autoriza publicação.

## D-126 — O Quality Gate reabre a prova completa de voz 1.2

- Data: 2026-09-05.
- Problema: o produtor de mídia passou a emitir o contrato de voz 1.2, mas `phase6_quality` ainda aceitava somente 1.1. Atualizar apenas o número do schema deixaria o gate dependente de rótulo e não provaria que os 90 WAVs continuam ligados aos inputs atuais.
- Decisão: `_verify_voice_for_quality` exige 1.2 e delega a `_verify_voice_manifest_contract`, que recompõe integralmente plano, roteiro, slots, copy ordenada, velocidades, modelos, vozes, binding eSpeak, WAVs, hashes e identidade. Qualquer divergência continua fail-closed.
- Escopo preservado: somente `hero_engine/phase6_quality.py` e seus testes foram alterados. Permaneceram byte-idênticos `hero_engine/phase6_creative_compiler.py` (`9ff120053f994d05053d9b56e0a07c2a478ffc54cce5fea8f8a364cc4fc6c458`), `hero_engine/phase6_production.py` (`608a7c3e8f6dba96be466caee265c98e3ada451be119b4b369e6a4e7065b6a86`) e `phase6-production-inputs-79b3e183dd5df410fb3a` (`7fae2d55af05a3fb98d1b7edbf73b912062d0b029e5d116deba551840a60f418`).
- Evidência focal: quality `8/8 PASS`; media+quality `18/18 PASS` em 132,674 s. A chamada direta do helper contra `voice-phase6-acec0efc9c0365039525` recomputou 90/90 takes e passou; manifesto SHA-256 `d748e4c7e1822f7e86f504f7563d4354114d859597506709e2f01f9b5e56a94e`; `phase6_quality.py` SHA-256 `69da211ec1b4d5757ddc84035275902cfa544e8037ae8e72ea7d39d5dcb8acfa`.
- Deployment: o Gestor no PID 18288 ainda mantinha o código anterior em memória no momento da prova. Reiniciá-lo antes de a mídia terminar foi proibido para não interromper o job em curso. Isso é deployment pendente, não falha ocultada nem autorização para usar o código antigo no QA.
- Retomada do job: `job-c516db5685acbbb423199bc1` foi adiantado de `2026-09-06T01:00:00Z` para `2026-09-06T00:45:40.619277Z` por `TransactionalQueue.defer`, com motivo `PRE_EFFECT_DEPLOYMENT_VERIFIED_RESUME_NOW`, tentativa 0, checkpoint `{}` e exatamente um job de mídia executável. Não há nova regra: foi apenas reagendamento pré-efeito do mesmo comando hash-bound.
- Lacuna remanescente: o cache de voz ainda não faz rebind ao receipt de capacidade candidato. Os 363 s observados pertencem ao retry pré-efeito; não há evidência de loop depois de `SUCCEEDED`. A correção permanece não implementada.
- Limite: D-126 não prova vídeo QA, publicação nem manutenção integral. A Fase 6 permanece `IN_PROGRESS`.

## D-127 — Liveness no Windows é consulta read-only; erro nunca prova morte

- Data: 2026-09-05.
- Evidência do defeito: `os.kill(18288, 0)` produziu `WinError 87` no Windows para um PID que `Get-Process` comprovou vivo. Tratar esse erro como “morto” permitiria migração sobre um Gestor ainda em execução.
- Decisão: no Windows, a única primitiva de liveness do protocolo é `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)` seguida por `GetExitCodeProcess` e `CloseHandle`. `STILL_ACTIVE` significa vivo; ausência conclusiva ou exit code encerrado significa morto. Erro de acesso, consulta ou fechamento significa `PROBE_UNAVAILABLE` e bloqueia a operação.
- POSIX preservado: `os.kill(pid, 0)` permanece apenas no ramo POSIX; `ESRCH` prova ausência, `EPERM` prova existência sem permissão e qualquer outro erro bloqueia como indisponibilidade.
- Aplicação uniforme: `capture_operational_boundary` e `migrate_local_runtime_views` usam a mesma `_process_alive`. O primeiro diferencia `MANAGER_PROCESS_NOT_ALIVE` de `MANAGER_PROCESS_LIVENESS_PROBE_UNAVAILABLE`; o segundo só migra após morte conclusiva e recusa erro de probe.
- Fronteira: liveness isolada não autentica identidade. PID, lock, instante de início, relação launcher/processo e cadeia da tarefa continuam sendo verificados fora do helper antes de manutenção ou migração.
- Prova: 69/69 testes PASS nos módulos afetados; a matriz cobre vivo, terminado, inexistente, acesso negado, falha de query, falha de close, dispatch Windows sem `os.kill`, semântica POSIX, migração fail-closed e blockers distintos. A contraprova read-only do PID 18288 retornou vivo e coincidiu com `Get-Process`, sem reinício, sinal ou alteração do runtime; início observado `2026-09-06T00:25:01.5637671Z`.
- Fontes primárias: [Microsoft OpenProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocess), [Microsoft GetExitCodeProcess](https://learn.microsoft.com/pt-br/windows/win32/api/processthreadsapi/nf-processthreadsapi-getexitcodeprocess) e [documentação Python de `os.kill`](https://docs.python.org/3/library/os.html#os.kill).
- Integridade: `hero_engine/maintenance_protocol.py` SHA-256 `ee8c02742582bc4b9030f1eef325a902986c1495be85125e446fa7cf5fb14523`; `tests/test_maintenance_process_liveness.py` SHA-256 `71d4957087a9465491644388121c3730dc73b5b3e28978bfac3803e495803320`.
- Arquivos alterados nesta decisão: `hero_engine/maintenance_protocol.py`, `tests/test_maintenance_process_liveness.py`, `AGENTS.md`, `PLANS.md`, `docs/DECISIONS.md` e `docs/STATE.md`.
- Estado de deployment: código e testes estão prontos, mas o runtime PID 18288 não foi reiniciado porque a mídia está em curso. A visão residente continua anunciando o hash anterior `74c440d7129c06b3f0bf5513f265ce78d24448514771f17866bf0ba3db2d90a4`; o deployment só termina após restart seguro e nova prova viva. **Nenhuma manutenção integral recebeu PASS nesta rodada.**

## D-128 — O Gestor usa prioridade normal sem elevar agressivamente o Windows

- Data operacional: 2026-09-06 UTC.
- Decisão: manter o Gestor em prioridade `5`, que corresponde à classe Windows `NORMAL_PRIORITY_CLASS`; não elevar para `HIGH` ou `REALTIME` e não reiniciar a cadeia em curso apenas para persistir o ajuste.
- Evidência de configuração: `scripts/install_phase5_manager_autostart.ps1:51-52` usa `New-ScheduledTaskSettingsSet -Priority 5`, e a tarefa `HeroEngine-Phase5-CentralManager` expõe `Priority=5`.
- Evidência viva: o processo foi ajustado em `2026-09-06T00:57:26Z`; o PID 18288 foi observado com `PriorityClass=Normal`. Os settings da tarefa foram persistidos posteriormente sem restart, preservando a mesma cadeia.
- Fonte primária: [Microsoft `TaskSettings.Priority`](https://learn.microsoft.com/en-us/windows/win32/taskschd/tasksettings-priority) define `4`, `5` e `6` como `NORMAL_PRIORITY_CLASS`; o default `7` pertence a `BELOW_NORMAL_PRIORITY_CLASS`.
- Fronteira da prova: o parser do installer foi observado em `PASS`. A comparação XML integral não passou porque o XML anterior omitia o valor default, portanto não é registrada como evidência positiva.
- Limite: a mudança elimina a configuração abaixo do normal, mas não prova aceleração causal. D-128 não concede `PASS` a manutenção integral, QA, deployment ou publicação e não altera o estado da Fase 6, que permanece `IN_PROGRESS`.

## D-129 — Texto nulo não vira conteúdo; mudança visual invalida a receita anterior

- Evidência real: o take-002, em 2.000 ms da timeline, exibiu a palavra `None` embora o TakePlan determine `on_screen_text=null`. A causa é a conversão `str(None)` no tratamento `HOOK_QUESTION` do renderer compartilhado. O frame e seu hash estão em `docs/PHASE6_RENDER_VISUAL_INCIDENT.md`.
- Correção: texto ausente, nulo, vazio ou só espaços não produz overlay; tipo não-string/não-null falha antes de escrever. Uma string literal intencional não é silenciosamente alterada. O plano, a voz, os ativos, os direitos e a variável experimental permanecem intactos.
- Receita: o renderer corrente da Fase 6 é `phase6-standard-v2`; fingerprint, cache e receipts usam a mesma constante. O schema aceita v1 como histórico, mas o verificador corrente recusa cache/segment set v1. Não reutilizar o take defeituoso após restart.
- Prova focal: 4/4 testes novos, 1/1 regressão de integridade de cache e py_compile PASS. O script `scripts/verify_phase6_null_overlay_fix.py` verificou capacidade imutável e hashes do plano/fonte antes de gerar somente um frame diagnóstico com o código novo; inspeção visual confirmou ausência do texto indevido. Não é prova de vídeo completo.
- Deployment e retomada: pendentes. O PID 18288 continua executando a receita v1 já carregada. Não matar FFmpeg, reabrir `SUCCEEDED`, sobrescrever checkpoint nem alterar a fila por fora do owner. Depois do efeito local encerrado, uma reconstrução exige remediação versionada, preservação dos artefatos anteriores, restart seguro e gates completos.
- Defeito independente ainda aberto: no take-003 o plano pede `NAME / TEST / CHOOSE`, mas o renderer e a Bible herdada fixam `TRUTH / RESPONSIBILITY / TODAY`. O frame comprova a divergência. Não transformar essa contradição em PASS, nem alterar identidade/blueprint silenciosamente.
- Fase 6 `IN_PROGRESS`; nenhuma publicação, aprovação integral ou gasto decorre desta decisão.

## D-197 — mineração sem biblioteca de mídia local

- Decisão: catalogar candidatos online com proveniência e direitos; baixar
  somente o ativo exato após alocação de take aprovada. A descoberta não pode
  criar uma biblioteca local especulativa.
- Implementação: `hero_engine.asset_library_phase5.build_asset_catalog` e o
  consumidor `hero_engine.phase6_assets`.
- Garantias focais: candidatos remotos não têm URI/hash local nem autoridade
  de render; a entrada de expansão não cria pasta de mídia quando só há
  descoberta. 4/4 focais PASS em 21/09/2026.
- Limite: a liberação pós-publicação ainda requer contrato próprio de ausência
  de referências; nenhuma mídia ou evidência existente foi removida.
