# Capacidade e custo de atuação do Codex — 2026-09-03

## Estado vigente — D-133, 05/09/2026 às 23:15:39 BRT

Um reset gratuito foi autorizado pelo usuário e aplicado com resposta nativa `reset`. A leitura independente registrou **100% disponível**, **2.500 créditos intactos** e **dois resets restantes**; antes da ação o limite incluído estava 100% usado. Decisão `codex-usage-2fd2d836fdeb7945`, GREEN, schema/twin válidos. Nova renovação observada: 12/09 às 23:15:36 BRT. Ambas as operações usam esse único limite, mantendo igual importância, qualidade e gestão de consumo. Não houve compra, recarga ou alteração de modelo. Provas e limitações em `docs/CODEX_SHARED_CAPACITY_POLICY.md`. Os estados anteriores abaixo permanecem históricos.

## Estado corrente — D-132, 05/09/2026 às 22:48:37 BRT

Gestão conjunta explícita de **Modelagem Youtube e QR Dolar**, igualmente importantes. Um único limite: **98% usado/2% restante**, saldo separado **2.500 créditos finitos**, **3 resets não consumidos**; renovação 10/09 às 06:56:07 BRT. Reserva de 10% não preservada: `codex-usage-d8389a7b42f1a30e`, `CRITICAL_RESERVE`. Seis testes focais PASS; regra registrada também no QR Dolar e no monitor existente. Ver `docs/CODEX_SHARED_CAPACITY_POLICY.md`. Concluir checkpoints seguros/testes em curso e adiar expansão discricionária, sem downgrade. Não houve compra, recarga, reset ou garantia de capacidade infinita. **As leituras GREEN e conclusões abaixo são histórico preservado, não estado atual.**

## Atualização vigente — 2026-09-05

O controle deixou de ser apenas um snapshot informativo. A política executável `codex-best-quality-capacity-governance-v1` exige o melhor modelo Codex suportado e esforço `ultra`; é proibido economizar por downgrade de qualidade. A economia vem de evitar logística reversa: preflight, inputs presos por hash, reuse de checkpoints, inspeções agrupadas, testes dirigidos antes da regressão integral e continuidade do Gestor em processamento local.

Telemetria oficial da conta em `2026-09-05T12:33:47.905Z`: plano Pro, 36% usados e 64% restantes na janela principal de 10.080 minutos, renovação em `2026-09-10T09:56:07Z`, nenhum rate limit ativo e nenhum spend control. Existem três resets gratuitos disponíveis, com vencimentos em `2026-09-20T22:43:15Z`, `2026-10-04T02:10:41Z` e `2026-10-05T04:18:58Z`; nenhum foi consumido. O saldo comprado é zero e compra/recarga automática continuam proibidas pelo custo técnico R$ 0,00.

O estado calculado é `GREEN` e permite execução normal em qualidade máxima. As faixas seguintes não trocam modelo nem reduzem esforço: `AMBER` (25%–49%) elimina trabalho duplicado; `RED` (10%–24%) usa Codex somente no caminho crítico; `CRITICAL_RESERVE` (0%–9%) aguarda o reset da janela para trabalho discricionário, enquanto o Gestor local, scheduler e coletas autorizadas continuam.

Não existe garantia técnica de crédito infinito: o limite é compartilhado em nível de conta, e volume consumido varia com modelo, contexto, complexidade e ferramentas. A política garante disciplina e preservação de reserva, não controle sobre atividades externas desta conta. Essa fronteira segue a [documentação oficial sobre uso do Codex](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan).

Prova executável: `config/codex-usage-policy.json`, `hero_engine/codex_usage_governance.py`, `schemas/codex_usage_governance.schema.json`, `output/operations/codex-usage/latest.json` e `tests/test_codex_usage_governance.py`.

Leitura pós-manutenção em `2026-09-05T13:06:07.449Z`: 37% usados, 63% restantes, ainda GREEN. A implementação, correções e validação integral desta rodada moveram o indicador account-wide em 1 ponto percentual observado; isso não é atribuição exata por tarefa, mas comprova que a reserva permaneceu ampla. Decisão vigente: `codex-usage-4a501a12f7789871`; três resets continuam disponíveis e não consumidos.

## Resultado

A capacidade de uso do Codex não é o gargalo atual. O snapshot oficial da conta mostra plano `Pro`, 2% usados na janela semanal principal e 98% restantes calculados. Não há rate limit ativo nem spend control atingido.

## Estado observado

| Limite | Uso | Reset |
|---|---:|---|
| Codex semanal, 10.080 min | 2% usados; 98% restantes | 2026-09-10 09:56:06 UTC |
| GPT-5.3-Codex-Spark, 5 h | 0% | 2026-09-03 18:54:42 UTC |
| GPT-5.3-Codex-Spark, semanal | 0% | 2026-09-10 13:54:42 UTC |

Existe um crédito gratuito de full reset, válido até `2026-09-20 22:43:15 UTC`. Ele não foi consumido: não há necessidade operacional agora e a análise de uso não constitui autorização explícita para resgate.

## Custo

- gasto externo de API iniciado nesta operação: USD 0;
- saldo de créditos mostrado pela interface: 0;
- preço da assinatura Pro: `UNAVAILABLE_FROM_USAGE_INTERFACE`;
- cobrança separada do gerador de imagem integrado: `NOT_EXPOSED`;
- custo de energia, hardware, armazenamento e trabalho humano: `UNAVAILABLE`.

O gerador visual integrado produziu um protótipo de marca sem compra de API ou ferramenta paga. Isso não permite afirmar que o uso não consome capacidade do plano.

## Interpretação operacional

Há headroom suficiente para continuar a remediação documental, código, QA e geração do próximo candidato. Os bloqueios reais são:

1. revisão humana independente;
2. qualidade e política do novo vídeo;
3. direitos do catálogo legado;
4. marca ainda não aprovada;
5. OAuth em `Testing`, não durável para operação contínua.

Percentual de uso é da conta inteira e muda com outras tarefas. A interface não oferece atribuição financeira ou de tokens por projeto, por fase ou por vídeo; logo, qualquer custo unitário do Codex seria inventado. O controle adotado é snapshot periódico, item_count de artefatos, tempo de etapas mensuráveis, gasto externo observado e revisão de limite antes de trabalhos pesados.

Prova: `output/operations/codex-usage-snapshot.json` validado por `schemas/codex_usage_snapshot.schema.json`.
