# D-137 — A prova estrutural não pode aprovar uma correção editorial ruim

Estado: Fase 6 `IN_PROGRESS`; proposta de alinhamento **REPROVADA editorialmente**, sem promoção, novo render completo ou publicação. A revisão é de agentes independentes do autor da proposta, com contraprova do responsável principal; não é revisão humana do padrão-ouro.

## O que existe e o que não existe

A receita especializada `phase6_visual_recipe.py` mede texto com fonte local real, preserva copy, exige mínimo de 54 px, máximo de duas linhas e safe area de 8%. Não muda a receita do runtime residente. A inspeção em memória dos 90 takes propostos passou em 0,0838788 s; isso é geometria, não avaliação de pixels, movimento, áudio ou narrativa.

`phase6_visual_alignment.py` construiu uma proposta isolada com 24 mudanças, sem alterar voz, timeline, fontes, direitos ou Bible. O verificador reabre fontes, schemas e outputs, recalcula identidade/diffs e recusa adulteração mesmo com hash externo atualizado. A integridade de uma proposta não torna sua ideia editorial correta.

- Candidato: `visual-alignment-0d081c519410bf855a2fe0f6`.
- Receipt: `output/operations/phase6/visual-alignment/candidates/visual-alignment-0d081c519410bf855a2fe0f6/receipt.json`.
- SHA-256: `85d2533937d15bbc952f3df42e4ea0d8f3afc81983b5118699555fd5ef2f35f5`.
- Estado imutável original: `PROPOSED_NOT_AUTHORIZED`, `queue_authorized=false`, `publication_authorized=false`.
- Decisão posterior desta revisão: **FAIL — não consumir nem promover a proposta**, ainda que seu verificador de integridade passe. O receipt original não foi reescrito para ocultar a hipótese reprovada.

## Defeitos concretos e correção necessária

| Evidência | Problema comprovado | Direção da correção, ainda não aprovada |
|---|---|---|
| Take 003, 3–8 s | A fala apresenta NAME/TEST/CHOOSE. Substituir somente a tela por TRUTH/RESPONSIBILITY/TODAY cria correspondência 1:1 não demonstrada. | Manter o mecanismo falado como informação principal e a identidade TRT separada; contrato de camadas e prova curta precisam ser versionados. Não reescrever a voz só para acomodar o renderer. |
| Takes 013–023 e 050–060, 70,1 s | A proposta chamava todos de ACTION_EVIDENCE sem verificar o conteúdo das fontes. 18 dos 22 têm papel de ativo diferente do requerido. | Remover a substituição genérica como autorização de prova. Escolher ou produzir ativos adequados e validar a composição com a fala. Correspondência de papel é necessária, não suficiente. |
| Take 012, 39,450 s | A barra adicional compete com o infográfico. Além disso, a fala é “Begin with two columns.”, enquanto o frame mostra três cards numerados. | Composição própria de duas colunas, fiel à fala, sem barra que esconda a informação. Remover a barra ou usar o rótulo exato do ativo não resolve sozinho a contradição. |
| Take 049, 155,950 s | Os cards da fonte estão em branco; NAME. TEST. CHOOSE. vem do overlay e é necessário. O bbox começa em x=145, fora do piso x=154. | Conservar a copy e usar geometria segura; não apagar o texto para eliminar o finding. Takes 051/053 exigem continuidade legível, não apenas cards vazios. |
| Progressão integral | Estados: HIDDEN 2, INTRODUCED 75, TRUTH 12, COMPLETE 1; RESPONSIBILITY/TODAY ausentes. Após TRUTH há regressão a INTRODUCED. | Derivar progressão monotônica das viradas narrativas e comprová-la. A proposta atual não corrige isso. |
| Take 090, 277–279,6 s | Trocar PAYOFF_RESOLUTION por CINEMATIC_BODY apenas remove a obrigação textual, sem provar fechamento. | Avaliar bookend com copy já aprovada ou fechamento visual realmente comprovado; manter função de payoff. |

Os 22 takes somam 70.100 ms. Quatro têm rótulo exato de papel, totalizando 10.600 ms: `truth_test_infographic` 5.500 ms e `decision_cards` 5.100 ms. Cards vazios não passam automaticamente. O agrupamento preliminar do agente “52,9 s de natureza” não foi adotado como métrica fechada: classificações por conteúdo precisam ser reconciliadas com cada origem. Não confundir contagem de rótulos com compreensão visual.

Fontes verificadas: TakePlan, creative treatment e asset allocation em `output/production/phase6/video-002/production`; briefing/roteiro/blueprint congelados; Bible, inclusive proibição de paisagem genérica como substituto de chunk não mapeado; FormatPack 1.1 exige que TRT progrida e feche.

## Contraprova OCR em mídia real, sem renderizar outra vez

Com RAM novamente acima do piso, `scripts/audit_phase6_completed_render_ocr.py` validou o hash do manifesto e do MP4 histórico e executou RapidOCR local com modelos fixados, em pasta diagnóstica isolada. Entrada: `render-phase6-1f4cb19d7dee654db8bd`, MP4 SHA-256 `0164b464d0a59a048667e099afb32ead2c86b7aef9698210d67610b3b7764eb2`.

- Audit: `output/qa/phase6/diagnostics/render-1f4cb19d-ocr-v1/audits/phase6-overlay-ocr-c412912412ba7e3e1d89f060.json`.
- SHA-256: `5bbaf2df7e8fabb02bead6a6b53c837b5aa0a85017b9ab8d526baf3294c259cd`.
- Resultado: `FAIL`, 10 frames amostrados, 6 PASS, 4 FAIL, 0 BLOCKED; 276,5951041 s medidos no script. Não é varredura temporal exaustiva nem QA de release.
- Take 002 / 2.000 ms: texto indevido `None` confirmado.
- Take 003 / 5.500 ms: TRT observado, divergindo do plano N/T/C.
- Take 012 / 39.450 ms: overlay principal em x=152, fora do piso x=154; a inspeção visual também confirmou colisão com os cards e a contradição duas/três colunas.
- Take 049 / 155.950 ms: overlay principal em x=145, fora do piso x=154.
- Nenhum input, WAV, MP4, fila, estado operacional ou publicação foi modificado pelo diagnóstico. Custo técnico adicional R$ 0,00.

## Implementações auxiliares e limites

- `production_capacity.py` aceita `materialize_latest=false`: grava/verifica somente receipt imutável, preservando a visão operacional de capacidade. Default anterior mantido; opção inválida bloqueia antes de probes. Não foi usado para autorizar um candidato editorialmente reprovado.
- Receita visual agora mantém percentuais e expressões `%{...}` como texto literal, sem expansão dinâmica do renderer.
- 22/22 testes de alignment/recipe e 13/13 de capacidade passaram em rodadas focais. Isso não é regressão integral, deployment ou aprovação do vídeo.
- Contraprova consolidada do responsável principal: `python -m unittest tests.test_phase6_visual_alignment tests.test_phase6_visual_recipe tests.test_production_capacity tests.test_phase6_queue_post_effect tests.test_phase6_queue tests.test_phase6_media_authority -q` — **81/81 PASS em 22,688 s**. `py_compile` dos cinco módulos/scripts alterados também passou. A suíte é focal, não o aceite integral. Hardening adicional de tipos no schema D-138 e gate semântico D-139 estão sendo verificados separadamente.
- O residente PID 18288 foi observado vivo. Às `2026-09-06T03:19:45.571834Z`, a mídia expôs ERROR: `current media job is not an unfinished executable candidate`; Quality estava WAITING. O job histórico SUCCEEDED continua intacto. Esse incidente exige consumo correto da autoridade terminal, não reabertura do job.
- Contraprova SQLite read-only: a raiz canônica é `job-ddc7d6b9605b194c44fd4f78`, seguida por `job-faae3c79b330903828e90cc7` e pela cauda `job-c516db5685acbbb423199bc1`; os dois edges estão COMMITTED. Começar pelo job intermediário não prova a cadeia completa. Zero edges pós-efeito foram criados.

## Ordem de execução seguinte

1. Fechar a substituição semântica genérica e a progressão incompleta com teste negativo antes de qualquer escrita de produção (D-139 em andamento).
2. Corrigir o plano editorial/visual com camadas distintas, infográficos fiéis e continuidade; preservar a proposta rejeitada e os inputs históricos.
3. Registrar contrato específico de remediação: D-138 preserva os ativos anteriores e não autoriza silenciosamente a troca de ativos exigida pela revisão editorial.
4. Validar plano, capacidade e reutilização exata da voz; produzir apenas provas curtas representativas e submetê-las à avaliação independente.
5. Só depois: sucessor transacional, geração isolada, manutenção/deployment seguro, render integral, QA, release e publicação pelos gates permanentes.

Nenhuma etapa é dispensada para produzir um relatório verde. Nenhuma alegação de acerto de primeira, viralidade, monetização ou ausência de falhas foi fabricada.
