# Tarefa 1 — manutenção abandonada: resultado focal

08/09/2026; conferência final de integridade às18:58:51Z.
Incidente: maintenance-request-20260908T1258124421621Z-0e1dac1f.
Estado: **CARACTERIZAÇÃO REPRODUZIDA; CORREÇÃO NÃO APLICADA; OPERAÇÃO PAUSADA**.

## Execução e evidência

[Teste isolado](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/tests/test_maintenance_abandoned_request.py>), SHA-256:
647a80efcbafc35cbbe5f36e3eb9c08805c590cd7da2ebb84c399c1c8d3bcea1.

Executado uma única vez, terminal08f491/exit0:

    .\.venv\Scripts\python.exe -B -X utf8 -m unittest discover -s tests -p test_maintenance_abandoned_request.py -v
    Ran 15 tests in 3.977s
    OK

Oito testes novos e sete testes existentes reaproveitados, sem regressão integral.
Funções Python produtivas executadas com raiz temporária; funções PowerShell
extraídas do arquivo existente, nunca executando/dot-sourcing daily.ps1.
Identidades de processo e superfícies externas são fixtures. Nenhum Gestor,
servidor, OAuth, rede, síntese, render ou publicação foi iniciado.

## Resultado por condição

| Condição | Resultado verificado |
|---|---|
| Solicitante vivo → ausente → PID reutilizado, simulados | maintenance_barrier permaneceu true e ACK READY_TO_STOP; request/PAUSE intactos. A sonda de vida não foi consultada: o protocolo não distingue essas condições do solicitante. |
| Identidade congelada de processo | Função real Get-FrozenProcessDisposition distinguiu EXACT_ALIVE, ABSENT, PID_REUSED_FOREIGN e IDENTITY_UNCERTAIN com aquisição de identidade simulada. Essa proteção é da cadeia do Gestor, não está vinculada ao requester histórico. |
| Request substituído por outro ID | Janela antiga inválida; limpeza recusou arquivo estrangeiro; novo ACK ligado ao novo request, barreira mantida. |
| Mesmo ID, bytes/requester alterados | Primitiva Remove-OwnedBarrierFileBounded removeu a fixture. Ela verifica ID, não hash integral/vida/ACK; isoladamente não autoriza recuperação. Não se conclui que todo o caller produtivo ignore suas próprias verificações. |
| ACK inválido | Validator real rejeitou; barreira regenerou ACK válido sem liberar o request. |
| Lease, reserva ou efeito BEFORE aberto | Testes existentes produziram DEFERRED/boundary false; nenhum estado real foi tocado. |
| Request malformado, janela expirada, PID divergente/incerto | Fail-closed; nenhuma autorização de execução/restart. |
| Limpeza própria em temporários | Removidos somente marcadores da fixture, PAUSE e lock preservados; chamada unitária run_cycle retornou PAUSED/publicação BLOCKED, sem alcançar QA produtiva. |
| Recuperação normal com PAUSE | capture_operational_boundary retornou exclusivamente PHASE5_MANAGER_PAUSE_TRIGGER_PRESENT no cenário controlado; pausa não pode ser ignorada para obter PASS. |

## Transição demonstrada e limite causal

[maintenance_protocol.py:1243](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/maintenance_protocol.py:1243>)
mantém a barreira enquanto o request existe, sem expiração por idade ou
reconciliação da vida do solicitante.
[daily.ps1:1614](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/daily.ps1:1614>)
depende do finally do próprio solicitante para fechar/remover seus marcadores;
uma nova entrada recusa request anterior em1039–1040.

Reproduzido no limite do protocolo: **request persistido + solicitante simulado
ausente + fechamento não executado → ACK renovável/barreira persistente**.
Não foi morto um processo real nem executado o fluxo completo do daily.
Isso demonstra a falta de transição de cancelamento órfão, mas **não explica
por que o processo histórico18748 terminou**, nem prova se chegou ao finally.
O request histórico registra PID, mas não geração do solicitante.

## Uma correção mínima proposta — não implementada

Adicionar **cancelamento explícito de manutenção órfã em modo pausado, sem
reinício**. Deve exigir exclusividade do mutex, request exato por ID+bytes/hash,
solicitante comprovadamente ausente e nenhuma identidade incerta, lease,
reserva ou efeito aberto. Com PID existente/reutilizado, bloquear
conservadoramente: não inferir geração ausente no registro histórico.
Arquivar a decisão e revalidar propriedade antes de remover somente seus
marcadores. Preservar PAUSE e tarefas desabilitadas; não usar a recuperação
normal retirando a pausa.

**Aceite:** cancelamento do órfão fechado e idempotente; recusa de solicitante
vivo/reutilizado/incerto, request alterado, ACK inválido e efeito/lease aberto;
zero alteração de dados/credenciais/PAUSE e zero início de tarefa, processo ou
efeito externo. Esses são requisitos da correção futura: os testes atuais
caracterizam peças existentes, não certificam um recuperador composto ausente.

## Preservação

Hashes antes/depois iguais para daily.ps1, central_manager_phase5.py,
maintenance_protocol.py, request e ACK reais do incidente e PAUSE (91b626).
Somente o teste novo e este registro foram criados. Relatório completo,
fontes produtivas, configurações, filas, credenciais, locks reais e agendamentos
não foram alterados. Nenhum teste precisou correção ou repetição.
