# PhaseTask — registro preservado e aprendizado, seis estados

## Revisão root — autorizada preparação do protótipo, não aprovação de mídia

Em08/09/2026, root leu integralmente esta proposta e as rows036–038 reais.
Aceita a distinção explícita de objetos em037-s01: novo enquadramento, sem
rebatizar Action nem alegar previsão preexistente observada. A instrução fica
fora dos campos. Em038, rótulo do conjunto e perguntas são a copy autorizada;
posições dos documentos ficam estáveis, sem inventar Before/After. Essa é uma
hipótese editorial para amostra, não prova de que o espectador já a compreende.
Pode implementar receita e QA independentes em novos diagnósticos record-learning-v1,
com preflight tipográfico antes da primeira geração e revisão real depois.
Não é solicitado novo aceite do proprietário. Timings,94outrosestados,áudio,
A11/29/71 e todas as demais provas permanecem inalterados.

Fase6; IN_PROGRESS; autorização contínua D047; custo técnico adicional R$0.
Estado deste documento: PROPOSTA GEOMÉTRICA E NARRATIVA, ainda não implementada
nem aprovada por QA. O root revisará a proposta antes de autorizar seu código.
Não cria pausa de aprovação do proprietário, capacidade produtiva, novo gate,
FormatPack, direito, horário, fonte admitida ou alteração de A11.

## 1. Objetivo e preservação

Preparar um lote coeso de seis estados de u036–u038: registrar, preservar o
registro e formular perguntas sobre ele. Não preencher um registro nem fabricar
aprendizado observado. Há três composições literais e três funções gráficas
especializadas, não uma cartela universal com substituição indiferente de texto.

A11 continua29usos/71pendentes,27ativos/26conteúdos/3linhagens,
BLOCKED_INCOMPLETE; a união temporal continua26. Os seis three-moves em
andamento não foram descontados dessa contagem operacional. Esta proposta
também não desconta os seis registros. Preservar51unidades,90fragmentos,
100estados, narração, entradas, clocks, áudio, fontes, direitos e provas antigas.
Os94estados fora deste lote deverão permanecer idênticos na proposta de receita.

Entradas reabertas por leitura, sem executar compilador, modelo ou mídia:

| Documento | Caminho relativo e SHA256 bruto |
|---|---|
| V6 proposta real | `output/qa/phase6/diagnostics/body-case-v1/staged/body-case-amendment-v1-ac645f2d8cb2fae3414b56c7/staged-visual-v6-ba7dabb1ed63c35a19021648.json` — `ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4` |
| Emenda body-case | Mesmo diretório, `body-case-amendment-v1-ac645f2d8cb2fae3414b56c7.json` — `72c8c8eac653d690fd2afe5f2430d527541fd27d0cbd25e2c39da9753b2dcdcf` |
| Bible | `output/production/phase6/video-002/production/channel_style_bible.json` — `c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049` |
| TakePlan | `output/production/phase6/video-002/production/take_plan.json` — `547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5` |
| A11 vigente | `output/operations/phase6/av-admission/timelines/phase6-av-timeline-06198f553f7dd8184307c7b8.json` — `10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb` |
| UsosV3 | `output/operations/phase6/av-admission/static-asset-uses-v3/inspection.json` — `139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30` |

V6 é `6.0.0-staged`, `STAGED_NOT_ACCEPTED_BY_A11`, `source_ready=false`,
`qa_status=NOT_EVALUATED`, autoridade inteiramente falsa. O lote consome essa
proposta por pin externo e recomposição permitida, não a promove a plano ativo.
O documento anterior `PHASE6_BODY_CASE_AND_THREE_MOVES_TASK.md` é preservado.

## 2. População literal e função

IDs na tabela omitem apenas o prefixo `visual-`. Os takes indicam os fragmentos
da unidade, não a atribuição de tempo de um estado interno a um fragmento.

| Estado / takes | Composition ID | Copy exata em V6, separada por ponto e vírgula | Palavras / linhas | Função |
|---|---|---|---|---|
| u036-s00 /056 | `action-outcome-record-v1` | `Action`; `Observed result` | 3 /2 | Mostrar como registrar sem inventar o resultado. |
| u037-s00 /057–058 | `prediction-record-integrity-v1` | `Action`; `Observed result` | 3 /2 | Retomar exatamente o registro anterior. |
| u037-s01 /057–058 | `prediction-record-integrity-v1` | `Original prediction`; `Keep the record unchanged` | 6 /2 | Distinguir a categoria da previsão original de uma conta retrospectiva; nenhum conteúdo é preenchido. |
| u038-s00 /059–060 | `record-comparison-questions-v1` | `Written evidence`; `Compare before and after` | 6 /2 | Apresentar dois registros vazios a comparar. |
| u038-s01 /059–060 | mesma | `Was the warning useful?` | 4 /1 | Perguntar sobre utilidade, sem afirmar proteção. |
| u038-s02 /059–060 | mesma | `Or did the story only exhaust?` | 6 /1 | Apresentar a alternativa com dúvida, sem fabricar um vencedor. |

As contagens usam a regra ASCII existente, contando também todos os rótulos
gráficos. Não são medição de legibilidade, compreensão, retenção ou OCR.

## 3. Gramática espacial comum, não composição indiferenciada

- Canvas1920×1080; manter painel ancestral: exterior(192,196,1536,588),
  interior(196,200,1528,580). Coordenadas de retângulos são(x,y,width,height),
  com intervalos geométricos semiabertos; nenhum FPS/duração está implícito.
- Fundo/interiores `#081827`, bordas estruturais `#2C5364`, texto `#E8EDF2`.
  `#D7A94A` continua a única cor de acento permitida, mas não é necessária neste
  lote: não colorir uma resposta como vencedora nem sugerir aprovação por ouro.
- Região útil x240–1680/y220–784; reserva de captions y864–993 sem arte nova.
  ArialBold64 em todos os rótulos e instruções deste lote, sentence case.
  O tamanho comum privilegia rótulos funcionais e espaço para registro, não o
  headline de96px dos three-moves. Não é permitido texto menor que54px.
- `arialbd.ttf` permanece a fonte existente, pin
  `e8f4e3baf6cc35fed6fcce3a540e8b39e8f6cda1d22a28f2ec8f526fef7a43f5`.
  Antes de gerar, métricas reais dessa fonte devem caber nos campos propostos;
  estas coordenadas não afirmam que essa medição já ocorreu. Falha bloqueia
  geração para revisão geométrica versionada, sem reduzir fonte/copiar menos.
- Rótulos identificam categorias fora da área de escrita. Instruções ocupam
  faixa editorial fora de qualquer campo. Todo interior de escrita é vazio,
  sem traços que imitem texto, marcações de resultado, cursor ou dados ocultos.
- Nenhuma fotografia, pessoa, voz, marca, textura documental ou campo real é
  introduzido. O próprio esquema de registro tem a função narrativa; OCEAN
  TODAY e recortes decorativos do TakePlan histórico não são reutilizados.
- Proposta de ancestralidade: derivação do painel
  `owned-four-criteria-panel-v1`, não nova fonte independente de variedade.
  Os três composition_ids literais permanecem distintos mesmo quando duas
  ocorrências compartilham exatamente o mesmo raster.

## 4. Receita A — formulário de ação e resultado,036/037-s00

Enquadramento frontal, formulário largo com duas linhas empilhadas. A direção
de leitura corresponde à instrução: primeiro a ação, depois o resultado
observado. Os dois são categorias vazias, nunca registro de algo já ocorrido.

| Elemento | Geometria proposta | Papel |
|---|---|---|
| `Action` | x240, baseline340, ArialBold64 | Rótulo do primeiro campo, não conteúdo escrito. |
| Campo de ação exterior | (240,388,1440,108), borda4px | Espaço visivelmente vazio. |
| Campo de ação interior | (244,392,1432,100), fundo | Zero dados, datas ou rabiscos. |
| `Observed result` | x240, baseline556, ArialBold64 | Rótulo do segundo campo. |
| Campo de resultado exterior | (240,604,1440,108), borda4px | Resultado deliberadamente não preenchido. |
| Campo de resultado interior | (244,608,1432,100), fundo | Zero dados, datas ou rabiscos. |

Os108px reutilizam a gramática de área de resposta visível já especificada;
os216px de passo vertical deixam um corredor de leitura entre campo e próximo
rótulo. Não se acrescenta um título geral que exceda as duas linhas aprovadas.

u036-s00 e u037-s00 DEVEM ser pixel-idênticos integralmente, inclusive rótulos,
campos e background. É retomada narrativa explícita, não duas fontes originais.
Podem apontar ao mesmo conteúdo, mantendo dois estados e os dois composition_ids.
Não impor seis conteúdos distintos ao lote. Igualdade será medida quando houver
rasters; neste documento ainda é um critério. Isso não dispensa os gates de
repetição/continuidade do futuro vídeo nem cria uma duração de HOLD.

## 5. Receita B — previsão original versus conta retrospectiva,037-s01

### Resolver a identidade sem rebatizar Action

O formulário anterior mostra ação/resultado, NÃO previsão. Logo, nenhum campo
anterior pode apenas receber o novo rótulo `Original prediction`, ser deslocado
ou morfado até parecer que sempre guardou uma previsão. O campo de previsão é
uma nova categoria ilustrativa, apresentada somente neste estado porque a
narração passou a tratar das previsões e de sua reescrita retrospectiva.

A passagem planejada é uma mudança de enquadramento por corte funcional,
condicionada ao futuro gatilho lexical validado; não se define aqui seu tempo.
Sai o formulário largo de duas linhas e entra uma visão conjunta de DOIS
documentos separados lateralmente. Não há match-cut, seta de transformação,
mesmo identificador de objeto nem animação Action→prediction. O painel do canal
permanece, mas o objeto representado e sua composição são explicitamente outros.

| Elemento | Geometria proposta | Papel e limite semântico |
|---|---|---|
| `Original prediction` | x240, baseline340, ArialBold64 | Categoria do documento esquerdo, fora de sua área de escrita. Não é uma previsão inventada. |
| Documento original exterior | (240,420,672,216), borda4px | Campo vazio e inteiro, sem raspagem, cursor ou substituição. |
| Documento original interior | (244,424,664,208), fundo | Nenhuma frase atribuída ao passado. |
| Documento retrospectivo exterior | (1008,456,672,180), borda4px | Outro documento, destacado espacialmente e com topo deslocado36px. Não substitui o original. |
| Documento retrospectivo interior | (1012,460,664,172), fundo | Também vazio; não apresenta nova versão ou resultado. |
| `Keep the record unchanged` | x240, baseline736, ArialBold64 | Instrução editorial geral, ABAIXO e FORA dos dois documentos. |

O corredor96px impede a fusão dos campos; a largura672px é a divisão exata de
1440px úteis menos esse corredor. O topo diferente do documento direito marca
uma nota separada, não uma cópia que alterou a mesma folha. A previsão mantém
sua moldura completa enquanto a nota retrospectiva está ao lado; nenhum dado
passa de uma para outra. Não usar cadeado, carimbo, checkmark ou tratamento que
afirme autenticidade documental/imutabilidade técnica já comprovada.

`Keep the record unchanged` NUNCA aparece dentro do campo original ou do
retrospectivo: é orientação ao espectador, não conteúdo de uma previsão ou
relato. Não acrescentar texto `Retrospective`, `Before`, `After`, uma previsão
exemplo ou legenda microscópica. A associação do documento direito à conta
retrospectiva vem da narração literal e da separação gráfica proposta; deve ser
avaliada no contexto audiovisual futuro, não declarada compreendida por OCR.

"Retained" significa aqui representar o original intacto AO LADO da conta
posterior, não provar que uma previsão real foi registrada antes nem alegar que
esse campo já aparecia em036. Ambos são vazios. A continuidade estática não
comprova preservação temporal; esta também dependerá do composto e de seus gates.

## 6. Receita C — comparar e perguntar,038-s00/s01/s02

Retomar visão de comparação: dois registros com mesmo tamanho e peso visual,
para não favorecer uma conclusão. O contexto são registros a examinar, não
um placar de acertos. O corte de enquadramento na entrada da unidade038 é
funcional; não é morph entre documentos nem evento lexical novo.

Elementos invariantes nos três estados:

| Elemento | Geometria proposta |
|---|---|
| Registro esquerdo exterior / interior | (240,464,672,248) / (244,468,664,240) |
| Registro direito exterior / interior | (1008,464,672,248) / (1012,468,664,240) |
| Faixa de leitura primária | x240, baseline308, ArialBold64 |
| Faixa de instrução secundária, quando literal | x240, baseline392, ArialBold64 |

As duas áreas de escrita, bordas e todo o fundo fora da faixa textual devem
ser pixel-idênticos nos três estados. Não preencher, deslocar, aumentar,
recolorir, apagar ou escolher um dos dois registros durante as perguntas.

- s00: `Written evidence` na faixa primária; `Compare before and after` na
  secundária. O primeiro texto é o rótulo do conjunto; o segundo é uma instrução
  exterior às duas áreas. Leitura convencional esquerda→direita apresenta a
  comparação, sem datas, valores ou resultados preenchidos.
- s01: somente `Was the warning useful?` na faixa primária. Faixa secundária
  vazia, registros preservados. A pergunta recebe o foco por ser o único texto,
  não por acender o registro esquerdo como se a proteção estivesse comprovada.
- s02: somente `Or did the story only exhaust?` na MESMA faixa primária. A
  conjunção e a interrogação permanecem; registros seguem vazios e invariantes.
  Não acender o direito como derrotado nem concluir que uma história venceu.

Interpretação editorial a revisar: "stable labels" da descrição de038 não
autoriza criar rótulos adicionais ou manter textos que as literal_copy de
s01/s02 já retiram. A proposta estabiliza os papéis/posições das duas áreas e
as posições dos textos permitidos; não imprime Before/After, sequer em fonte
pequena. A faixa inicial estabelece o contexto da comparação; as perguntas
seguintes mudam apenas a tarefa de leitura sobre os mesmos registros. Se a
revisão considerar essa identificação espacial insuficiente, bloquear o código
para resolver o contrato editorial explicitamente; não inventar copy no render.

## 7. Tempo, tipografia e autoridade: o que esta proposta não resolve

Entradas mantidas literalmente:

- u036-s00/u037-s00/u038-s00: UNIT_ENTRY, chars/text/previous_state null.
- u037-s01: LEXICAL_START, `fear edits`, chars[34,44), predecessor u037-s00.
- u038-s01: LEXICAL_START, `warnings protected you`, chars[39,61), predecessor
  u038-s00.
- u038-s02: LEXICAL_START, `stories only exhausted you`, chars[72,98),
  predecessor u038-s01. `stories` está emtake059 e o restante em060; início de060
  não é onset dessa expressão e não pode ser usado como substituto.

u037/u038 permanecem na união26; UNIT_ENTRY não altera isso. Receita de fonte
estática pode preparar as seis aparências sem horários, mas não pode agendá-las
no vídeo ou converter gatilho lexical em fronteira de unidade. UmaPNG representa
umframe[0,1), semFPS/duração de vídeo. Nada aqui aprova movimento, freeze,
sincronização, voz, B/C/D, GC-01, Fase6 ou publicação.

Não há ainda medição de glyph, raster, OCR, áudio ou compreensão deste lote.
Antes de produzir, a receita específica deverá calcular métricas dos textos
com fonte pinada, fixar os campos de tinta e verificar todas as duas linhas/
oito palavras/safe areas. O QA independente seguirá o método já exigido:
geometria não textual, pixels fora de campos, tinta real, OCR associado por
centroide com confiança mínima0,70 e copy exata, sem confundir envelopeOCR com
contorno de glifo. Não ampliar caixas após observar o resultado nem inferir
gold humano ou semântica audiovisual a partir de OCR correto.

## 8. Sequência delimitada e Done when

1. Revisão root desta proposta, em especial: previsão como novo objeto e não
   rebatismo de Action; instrução fora dos campos; contexto estável de038 sem
   copy adicional. Done when: interpretação/geometria aceitas explicitamente
   para virar receita. Este documento sozinho não satisfaz esse critério.
2. Somente depois: receita especializada com três subcomposições fechadas,
   entradas/pins exatos, testes negativos e persistência exclusiva. Reutilizar
   apenas primitivas gratuitas imutáveis; não executar receita de outra família
   nem exigir seis rasters distintos. Done when: fixtures focalmente aprovadas,
   sem atribuir essas provas a amostras inexistentes.
3. Pré-verificação geométrica com fonte exata, depois geração única das fontes
   necessárias, com estados036/037s00 compartilhando conteúdo quando comprovado.
   Cache apenas porreceipt externo íntegro; corrupção/partial/colisão bloqueiam,
   sem overwrite ou retomada silenciosa. Done when: bytes/receipts e inventários
   verificáveis, ainda com autoridade falsa.
4. QA independente e revisão semântica aplicável às amostras; nota própria de
   direitos com escopo exato, sem herdar a nota de perguntas ou de three-moves.
   Done when: cada evidência dentro de seu escopo; fonte, tipografia ou conjunto
   bonito não equivalem a vídeo autorizado. Máximo estático: PASS_STATIC_SCOPE_ONLY.
5. Quando ambos os lotes estiverem comprovados, propor uma única integração
   versionada para three-moves+registros, conservando receitas/provas separadas.
   Não integrar seis estados agora para repetir a mesma migração logo depois.
   A contagem só muda após vínculos reais; nenhum requisito temporal é removido.

Negativos específicos, sem criar novos tipos de gate: rejeitar relabel/morph
Action→prediction; texto dentro dos campos; preenchimento, números ou datas;
troca de posições; pergunta sem interrogação; foco que escolhe vencedor;
duplicação artificial de conteúdo; diferença entre036/037s00; divergência dos
dois registros entre estados038; tempo inventado, autoridade indevida e uso da
proposta como se V6 estivesse instalada.

Arquivo único criado neste incremento: `docs/PHASE6_RECORD_LEARNING_TASK.md`.
Nenhum engine, schema, teste, mídia, direito, integração, input ou estado global
foi alterado por esta tarefa. Nenhuma cota externa ou ferramenta paga foi usada.
