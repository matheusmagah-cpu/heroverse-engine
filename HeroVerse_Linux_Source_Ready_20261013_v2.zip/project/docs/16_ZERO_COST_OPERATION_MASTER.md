# Operação técnica com custo zero — contrato permanente

## Regra não negociável

**CUSTO TÉCNICO OBRIGATÓRIO DO SISTEMA: R$ 0,00.** Produção, mineração, edição, voz, imagem, vídeo, armazenamento, banco, automação, publicação, analytics e observabilidade usam somente software gratuito/open source, processamento local, infraestrutura já existente e APIs oficiais em cota gratuita sem exigência de cobrança.

São proibidos cartão, assinatura, trial com renovação, API paga, servidor contratado, domínio comprado e dependência cuja conclusão futura exija pagamento. Qualidade mínima não é relaxada para preservar custo: a função fica `BLOCKED` e o Gestor procura outro pipeline gratuito.

## Contrato de adapter

Cada adapter registra: licença; direito comercial; custo financeiro máximo `0`; bucket de cota; limite oficial; consumo observado; fonte da medição; renovação; limiar preventivo; risco de cobrança; fallback gratuito/local; capacidade do host; tempo medido; qualidade observada e status.

O Gestor só executa quando `financial_cost_brl=0`, `billing_method_required=false`, a cota possui margem e o fallback está definido. Consumo desconhecido em ação de escrita resulta em `BLOCKED`. Antes do limiar preventivo, tarefas read-only podem ser adiadas/cacheadas e produção migra para processamento local. O sistema nunca tenta extensão paga nem ativa billing.

## YouTube

A Data API é API oficial com cota gratuita. Em 2026-06-01 a documentação oficial registra buckets padrão separados de 100 chamadas/dia para `search.list` e `videos.insert`, e 10.000 unidades/dia para os demais endpoints; `channels.list`/`videos.list` custam 1, `thumbnails.set` aproximadamente 50 e `captions.insert` 400. Esses limites são externos e sujeitos a mudança, portanto o registro precisa ser revalidado e o consumo confirmado no console antes de escrita.

O pipeline público planejado faz staging privado, valida o resultado e só então muda `status.privacyStatus` para `public`. O mínimo nominal é uma chamada de `videos.insert` e 503 unidades gerais (`channels.list` + dois `videos.list` + `thumbnails.set` + `captions.insert` + `videos.update`); o guard reserva 513 unidades para até dez rechecagens de processamento. Sem telemetria autenticada de cota, a publicação permanece bloqueada. A telemetria precisa validar contra `schemas/youtube_quota_observation.schema.json`; um arquivo manual incompleto não libera a operação.

O adaptador vidIQ usa somente o bucket renovável gratuito observado. Em `2026-09-03`, o limite era 150, o consumo confirmado 55 e o saldo 95, com renovação em `2026-10-03T16:42:50Z`. O Gestor aplica piso preventivo de 25; abaixo dele, interrompe consultas que consomem crédito e usa API oficial, cache e análise local. Créditos de provedor não são custo financeiro, mas são recurso finito e permanecem no mesmo guard fail-closed.

## Exceção de mídia

YouTube Promote poderá consumir orçamento apenas quando o proprietário informar valor exato. É mídia, não custo técnico. A exceção não permite ferramenta, API, servidor, domínio, banco, armazenamento ou assinatura paga; métricas de campanha permanecem fora do progresso qualificado do YPP.

## Done when

- todos os adapters ativos têm receipt de custo/cota/fallback;
- custo técnico calculado e observado é R$ 0,00;
- nenhum segredo, cartão ou billing está no projeto;
- limiar preventivo bloqueia chamada e seleciona fallback sem cobrança;
- produção e publicação possuem caminho gratuito real e testado;
- qualquer dependência externa ainda sem caminho zero-cost aparece como `BLOCKED`, nunca como pronta.

Fontes oficiais: `https://developers.google.com/youtube/v3/getting-started`, `https://developers.google.com/youtube/v3/determine_quota_cost`, `https://developers.google.com/youtube/v3/docs/captions/insert` e `https://developers.google.com/youtube/v3/docs/thumbnails/set`.
