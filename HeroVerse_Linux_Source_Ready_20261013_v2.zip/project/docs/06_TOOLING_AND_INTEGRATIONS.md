# 06 — Ferramentas, integrações, plugins e MCPs

## 1. Estratégia

O núcleo será code-first, local-first e independente de fornecedor. Plugins, MCPs e automações devem chamar contratos estáveis do projeto; não podem conter a lógica editorial central de forma irrecuperável.

## 2. Stack inicial sugerido

| Necessidade | Opção local inicial | Função |
|---|---|---|
| Inspeção de mídia | FFmpeg/ffprobe | Metadados, extração, filtros e render |
| Detecção de takes | PySceneDetect | Candidatos a cortes, fades e mudanças |
| Frames e visão clássica | OpenCV | Keyframes, movimento, histogramas e imagens |
| Transcrição | Whisper/faster-whisper | Texto e timestamps |
| OCR | Tesseract | Texto presente nos frames |
| Orquestração de domínio | Python | Jobs, validação e adapters |
| Contratos | JSON Schema | Validação das saídas |
| Banco do piloto | SQLite | Estado local simples |
| Banco na escala | PostgreSQL ou compatível | Concorrência e operação multicanal |
| Montagem | FFmpeg | Timeline e renderização reproduzível |
| Música/efeitos | YouTube Audio Library e acervo permitido | Áudio com origem registrada |

Versões devem ser fixadas somente depois de verificar o ambiente existente.

## 3. Componentes opcionais

### n8n

Pode atuar como camada visual de orquestração, webhooks, notificações e integrações. A lógica de mineração, modelagem, rights gate e quality gate deve permanecer em módulos testáveis do projeto. Antes de incorporar n8n a um produto comercial, revisar licença e forma de distribuição vigentes.

### MCP

Use MCP quando o Codex precisar chamar de forma repetível uma função externa ou ferramenta do projeto. Possíveis ferramentas futuras:

- `mine_video`;
- `validate_mining_output`;
- `build_channel_model`;
- `search_licensed_assets`;
- `build_production_blueprint`;
- `render_draft`;
- `run_quality_gates`;
- `read_owned_analytics`.

Não crie o MCP antes de as funções de domínio funcionarem via CLI e testes. O MCP é uma interface, não o motor.

### Skills do Codex

Quando a mineração estiver estável e repetível, transforme cada fluxo maduro em uma skill pequena:

- `video-mining`;
- `channel-modeling`;
- `clip-production`;
- `quality-review`;
- `analytics-diagnosis`.

Não empacote como skill um processo que ainda exige correções frequentes.

## 4. Arquitetura de adapters

Defina interfaces substituíveis:

- `TranscriptionProvider`;
- `SceneDetectionProvider`;
- `OCRProvider`;
- `VisionAnalysisProvider`;
- `AssetCatalogProvider`;
- `NarrativeModelProvider`;
- `RendererProvider`;
- `PublisherProvider`;
- `AnalyticsProvider`.

Cada adapter deve declarar:

- capacidades;
- limites;
- custo;
- necessidade de credencial;
- política de retry;
- formato de entrada e saída;
- dados enviados externamente;
- fallback permitido;
- testes.

## 5. Local-first sem perda de qualidade

- Use processamento local para mídia, cortes, OCR e transcrição quando o hardware suportar.
- Meça tempo e recursos por minuto de vídeo.
- Fallback externo nunca é silencioso.
- Nenhum arquivo é enviado a um serviço externo sem configuração e autorização.
- “Gratuito” significa ausência de assinatura/API; armazenamento, energia, hardware e tempo continuam sendo medidos.

## 6. YouTube

- Dados públicos: adapter para a API pública oficial quando disponível.
- Dados próprios: OAuth e API de Analytics, com escopos mínimos.
- Publicação: desativada nas fases iniciais e protegida por aprovação.
- Quota: cache, atualização incremental e rate limiting.
- Credenciais: somente secrets/variáveis de ambiente.

## 7. Biblioteca de ativos

Não busque recortes diretamente durante a renderização. Mantenha catálogo previamente indexado com:

- embedding/descrição;
- objetos, ações, emoção e ambiente;
- duração e qualidade;
- direitos e atribuição;
- hash e duplicatas;
- usos anteriores;
- canais autorizados;
- data de validade da licença.

## 8. Seleção de ferramentas

Antes de adicionar uma ferramenta, responda:

1. qual loop manual ela elimina;
2. qual contrato implementa;
3. qual dado recebe e transmite;
4. qual custo cria;
5. como será substituída;
6. como será testada;
7. qual licença possui;
8. se é necessária nesta fase.

Não instale várias integrações antecipadamente. Comece pelas que desbloqueiam o padrão-ouro e o minerador.

## 9. Segurança e confiabilidade

- menor privilégio;
- segredos fora do Git;
- logs sem tokens;
- validação de arquivos e URLs;
- limites de tamanho e duração;
- timeouts;
- retries com backoff;
- idempotência por hash e job ID;
- sandbox de subprocessos quando aplicável;
- manifesto de dependências;
- versões reproduzíveis.

## 10. Referências técnicas

- FFmpeg: https://ffmpeg.org/documentation.html
- PySceneDetect: https://www.scenedetect.com/docs/latest/
- Whisper: https://github.com/openai/whisper
- Tesseract: https://tesseract-ocr.github.io/
- YouTube Data API: https://developers.google.com/youtube/v3
- YouTube Analytics API: https://developers.google.com/youtube/analytics
- Codex AGENTS.md: https://learn.chatgpt.com/docs/agent-configuration/agents-md
- Codex best practices: https://learn.chatgpt.com/guides/best-practices

## 11. Subordinação ao Gestor Central

CLI, scripts, schedulers, n8n, MCPs, skills, plugins, agentes e providers são adaptadores/executores. Regras, estado, prioridade, memória, envelope, fila e avaliação ficam no núcleo testável. Toda integração recebe comando versionado/idempotente e devolve receipt; não escreve estratégia paralela.

O runtime futuro requer um único líder ativo, claim transacional, leases, retries limitados, checkpoints, dead-letter queue, replay e rollback. Ferramenta externa só entra após avaliação de custo, permissão, termos, segurança, rastreabilidade e alternativa local. Nenhuma integração paga é adicionada sem aprovação.
