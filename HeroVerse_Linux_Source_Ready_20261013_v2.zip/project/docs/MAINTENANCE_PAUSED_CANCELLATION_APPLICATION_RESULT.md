# Tarefa 7 — cancelamento real encerrado sob pausa

**EXECUTADO — CANCELLED_WHILE_PAUSED**, em 09/09/2026, 13:19:09.506528 UTC (10:19 Brasília).

Alvo único: `maintenance-request-20260908T1258124421621Z-0e1dac1f`.

## Decisão protocolar limitada

`AGENTS.md:653` rege a manutenção integral; `AGENTS.md:671` e `docs/DECISIONS.md:2650–2662` exigem prova viva depois do reinício para aprová-la. `docs/01_EXECUTION_PROTOCOL.md`, seção 12, exige manutenção segura/regressão/recuperação D116 para instalação de alterações. Essas exigências continuam obrigatórias para seus respectivos escopos.

Esta intervenção não instala o lote no Gestor, não retoma o runtime e não aprova a manutenção abandonada: cancela exclusivamente seu request/ACK pela entrada explícita testada. Não foi localizada cláusula que exija regressão integral ou reinício antes desse cancelamento específico. A autorização pontual da Tarefa 7 e os guards da entrada permitem somente `CANCELLED_WHILE_PAUSED`. **D-116 permanece pendente, não executado nem dispensado.**

## Pré-requisitos e aplicação

Raiz: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`.

Versão produtiva SHA-256 `97c90f7d62ae9349af3277d1b082d099e0bbc8f861776dac1257f0071a6df44c`, idêntica à Tarefa 6. Os dois arquivos de testes também conservaram seus hashes registrados. Reutilizados os 41 casos existentes e 22 novos confirmados; nenhum teste foi reexecutado.

Pré-checagem `115c0c`, 13:18:48 UTC: PAUSE, request/ACK e locks corresponderam aos hashes preservados. Referência externa: `output/diagnostics/task4-sqlite-copies-20260908-v1/run_once.py`, SHA-256 `d2bc0c109402038460bd81a88eec1beb89de535fd00669c41b7c8fcdde9a3033`, lido, nunca reexecutado. Nenhum hash divergente foi adotado.

A entrada `cancel_orphaned_maintenance_paused` foi chamada **uma única vez**, pelo Python existente, com raiz explícita, ID acima e hashes esperados do request (`b74f87cc…`) e ACK (`7855c227…`). Referência `6139aa`, exit 0, 4,072 s de comando. Nenhum helper de recuperação, CLI de manutenção ou remoção manual foi usado.

O fluxo adquiriu exclusividade, comprovou ausência dos PIDs 18748 e 15244 sem inventar geração, validou request/ACK e pausa, criou captura corrente protegida e conferiu integridade, chaves estrangeiras, leases, reservas e efeitos externos. A captura começou às 13:19:08.181456 UTC; os pins permaneceram até o commit. SQLite abriu somente cópias de trabalho.

## Evidências e preservações verificadas

Arquivo de evidências: `output/runtime/gestor-central/maintenance-cancellations/260b9fdb9f8127abe8bc0bb8/` — 16 arquivos, incluindo request, ACK, PAUSE, PID, lock, boundary, manifesto, sete arquivos dos bancos e prepared/committed.

- `committed.json`: SHA-256 `9d6bb33cebabb23682dc5558c8372683363eb5f43d02c5d49838cf5e95f15629`; `restart_permitted=false`.
- `prepared.json`: SHA-256 `2d0c4ed47bf9c832ac72c129e8781addf96958fe1e331f1be8401e68388fe71f`.
- Captura corrente: `7bea71aa652d44d480c4a0eb5c2e4db0`; sete originais e sete evidências iguais em tamanho/hash depois da aplicação. Fila 241.664 bytes; ledger 61.440; ambos WAL de zero bytes e SHM de 32.768 bytes; lock do ledger de um byte. **Nenhum auxiliar foi removido. Zero conexões SQLite aos originais.**
- Somente `maintenance-ack.json` e `maintenance-request.json` foram removidos; ambos arquivados antes. PAUSE, manager.lock, manager-lock.json e manager.pid preservados.
- Boundary: um receipt externo `COMPLETE_PUBLIC`, sem efeito aberto. Seu SHA-256 `0c0f1faa32e4e67fd208a699b412af378e0cf5d865492cdcdd542f5b5c2c15da` permaneceu igual.
- Conferência posterior `787f2b`, 13:19:48 UTC: todos os bindings de arquivo/manifesto/decisão conferidos; tarefa Windows `Disabled/Enabled=false`; rotina Codex `PAUSED`, arquivo SHA-256 `0ad5c9b998deff9bb3dedae5635f67bbf718b8c17f45be0d7558830b44beed16` inalterado; nenhum Gestor/render identificado.
- Código e testes permaneceram byte-idênticos (`7cfd2f`). Não houve acesso a credenciais, alteração de mídia, rede, OAuth, daily.ps1, Gestor, publicação, instalação ou mudança de regras/agendamentos.

Mudanças desta rodada: arquivo de evidências previsto pelo cancelamento, remoção dos dois marcadores exatos e este registro novo. Não houve falha parcial nem retry. O incidente foi encerrado como cancelamento sob pausa; isso não aprova a manutenção antiga, D-116, a Fase 6 ou a retomada operacional. A rodada termina aqui.
