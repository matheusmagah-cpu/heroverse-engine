# PhaseTask — Fase 2

## Controle

- `phase_id`: `2`
- `task_id`: `phase-2-automatic-miner`
- `status`: `APPROVED`
- `authorized_by`: usuário
- `authorized_at`: `2026-09-02`

## Objetivo único

Implementar e medir um minerador automático, local, reproduzível e idempotente que processe somente as quatro fixtures da Fase 1, produza `video_mining.json` válido e reporte divergências campo a campo contra o champion humano.

## Entradas

| Entrada | Caminho | Regra |
|---|---|---|
| Mídia/metadata/thumbnail | `data/modeling/grace-grit-love/full/` | fonte real aprovada para análise |
| Padrão-ouro | `data/gold_standard/` | somente avaliação; proibido gerar challenger a partir dele |
| Schema | `schemas/video_mining.schema.json` | Draft 2020-12 obrigatório |
| Benchmark | `schemas/mining_benchmark.schema.json` | saída por fixture |

## Entregáveis

| Entrega | Caminho | Consumidor |
|---|---|---|
| Contratos | `hero_engine/contracts/analysis.py` | pipeline e testes |
| Adapters | `hero_engine/mining/adapters.py` | pipeline local |
| Executor | `hero_engine/mining/pipeline.py` | CLI/API interna |
| Semântica determinística | `hero_engine/mining/semantics.py` | saída estruturada |
| Benchmark | `hero_engine/evaluation/gold_standard.py` | gate champion/challenger |
| CLI | `hero_engine/cli.py` | operador |
| Runs | `output/mining/phase2/` | auditoria |
| Testes | `tests/test_mining_phase2.py` | verificação |
| Relatório | `docs/PHASE_2_REPORT.md` | gate humano |

## Critérios de aceitação

- [x] execução reproduzível;
- [x] divergências contra o padrão-ouro medidas e expostas;
- [x] nenhuma dependência paga obrigatória;
- [x] falhas explícitas;
- [x] idempotência comprovada;
- [x] inspeção, transcrição, takes, keyframes, OCR, hooks, narrativa e embalagem implementados;
- [x] schema e evidências validados;
- [x] facts/inferences/unknown separados;
- [x] tempo, recursos e custo medidos;
- [x] execução real nas quatro fixtures;
- [x] revisão de gate coberta pela autorização condicional expressa do proprietário após 48/48 métricas, 38/38 testes e revisão visual 5/5.

## Testes obrigatórios

- contrato rejeita schema/evidência inválida;
- timestamps e takes são consistentes;
- ausência de OCR/ASR falha explicitamente ou produz `UNKNOWN` permitido;
- mesma chave retorna mesmo artefato sem nova execução;
- mudança de parâmetro muda a chave;
- direitos nunca são promovidos pela análise;
- benchmark valida no schema e registra limitações;
- execução CLI real nas fixtures;
- suíte legada não regride.

## Condição de parada

Após execução real, benchmark e relatório, marcar `AWAITING_REVIEW`. Não iniciar a Fase 3.

## Resultado submetido

- execução: 4/4 `COMPLETE`;
- replay: 4/4 `CACHE_HIT` com hash idêntico;
- schema/evidência/direitos: 4/4 aprovados;
- testes: 33/33 aprovados;
- benchmark: timestamps, ASR, hooks, takes, direitos, schema, custo, latência e consistência aprovados em 4/4;
- gaps: OCR 0/4, narrativa 0/4 e embalagem 3/4;
- decisão automática: 4× `KEEP_CHAMPION`, 0 regressões críticas;
- relatório: `docs/PHASE_2_REPORT.md`.

## Iteração de melhoria autorizada

O primeiro challenger permanece como baseline reprovado para promoção. A solicitação posterior do proprietário reabriu a fase para corrigir OCR, narrativa e embalagem conforme `docs/PHASE_2_IMPROVEMENT_PLAN.md`. Thresholds não podem ser reduzidos e a ausência de holdout deve permanecer explícita.

## Resultado da iteração 001

- challenger: `miner-local-0.2.0`;
- 4/4 jobs `COMPLETE`, 4/4 replays idênticos;
- 48/48 gates de campo aprovados;
- OCR médio `0.977273`, narrativa `0.718333`, packaging `0.877403`;
- 38/38 testes; `pip check` sem dependências quebradas;
- 0 regressões críticas; maior queda média `0.0`;
- aprendizado: 3× `SUPPORTED_LOCAL`, sem alegação de generalização;
- decisão de fase: aprovada sob a autorização condicional do proprietário;
- relatório: `docs/PHASE_2_IMPROVEMENT_REPORT.md`.
