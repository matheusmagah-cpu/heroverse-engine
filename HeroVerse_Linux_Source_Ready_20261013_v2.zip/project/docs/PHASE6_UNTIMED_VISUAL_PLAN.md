# Vídeo 2 — intenção visual completa, sem tempos inventados

Estado em 07/09/2026: plano, leitor e integração literal A8 testados e executados.
Isto não é mídia produzida, aprovação audiovisual ou capacidade de publicação.

Revisão separada dos 100 estados encontrou uma correção concreta em u029:
`Choose the next task` não era equivalente à narração `complete the next task`.
A versão v2 usa `Complete the next task`, como ação possível/imperativo, ainda
sem marcar resultado como realizado. Corrigida também a concordância singular
de `1 completed marker` na descrição de u034. Os dois documentos v1 continuam
intactos como predecessores; não foram silenciosamente substituídos.

## O que mudou concretamente

As 51 unidades de narração e os 90 fragmentos existentes estão ligados a 100
estados visuais planejados. O texto e os PCM não foram substituídos. Cada estado
tem conteúdo gráfico literal, função narrativa, continuidade e entrada tipada.
As 48 entradas lexicais estão descritas por caracteres da frase, não por um
timestamp estimado. A duração de cada estado ainda depende da montagem validada.

O plano preserva as 25 decisões não lexicais de D169. As 15 unidades que antes
tinham apenas captions e descrições genéricas de imagem receberam estas decisões:

| Unidades | Decisão específica |
|---|---|
| 008–009 | Separar evento de interpretação; mostrar o risco da decisão não examinada, sem tratar a interpretação como fato. |
| 022–023 | Questionar cada consequência separadamente; distinguir exame de pensamento e obediência automática. |
| 027–029 | Manter resultado/resposta/incerteza desconhecidos e apresentar ações possíveis, sem checkmarks ou resultados fabricados. |
| 031 | Negar explicitamente à pressão autoridade sobre identidade e comportamento, em dois estados distintos. |
| 037–038 | Preservar registro original e formular perguntas de comparação; não inventar histórico, métricas ou aprendizado já observado. |
| 039–040 | Manter as limitações sobre perigo, direitos, deveres e ajuda profissional; sem dramatização gráfica ou promessa de solução espiritual isolada. |
| 042 | Distinguir saída, documentação, relato e ajuda qualificada como possibilidades, sem afirmar que ações externas aconteceram. |
| 046/051 | Fechar a diferença entre acontecimento e interpretação; manter cada negativa completa, sem vereditos prejudiciais isolados. |

Foram também explicitados o contraste de u020, a passagem para resposta em u026
e as cinco categorias de apoio em u041. O hook003 conserva a receita de footer
existente e seu evento gráfico embutido na fonte; esse ordinal não vira onset
lexical. As captions do hook seguem a segmentação progressiva própria.

## Preservação e limites

- Duas colunas conservam FACT/FORECAST, posição, foco e exemplos. u016 mantém o
  mesmo conteúdo no HOLD correspondente ao take021.
- Os seis estados de porta/mensagem/manhã e os cinco estados de critérios são
  reutilizados como intenção. Não foram renderizados novamente.
- u019/u021 não recebem indevidamente os ordinais 0/4 ou 2/4 de u034.
- u044/u045 retomam a mesma porta/mensagem sem resultado novo; o novo uso ainda
  precisa de binding próprio. Uma composição reutilizada não cria outra fonte.
- NAME/TEST/CHOOSE e TRUTH/RESPONSIBILITY/TODAY continuam sistemas distintos.
- O estilo continua híbrido clip-based dentro da Bible. Descrições de inserts
  ainda sem fonte não são vídeos disponíveis. Não existe autorização de trocar
  toda a produção por slides ou por geração integral.
- Todo row mantém `SOURCE_PENDING` e `quality_approved=false`: mesmo as imagens
  tecnicamente verificadas ainda precisam do vínculo de uso audiovisual, tempo,
  direitos/publicity aplicáveis e QA do resultado composto.

## Artefatos

Versões corrigidas verificadas pelo leitor e consumidas em A8:

- `output/operations/phase6/av-admission/visual-intents/untimed-editorial-supplement-v2.json`
  — SHA256 `3c2485ef2b250210919c9c4b6e7189fe7232e7fb59ebc56832e0b67e9908b1da`.
- `output/operations/phase6/av-admission/visual-intents/untimed-visual-intent-v2.json`
  — SHA256 `d8504875d441ec62549d36ceda84d5aab8bce56c094d3a9f76686015b8697b15`.

Predecessores preservados, não admitidos:

- `output/operations/phase6/av-admission/visual-intents/untimed-editorial-supplement-v1.json`
  — SHA256 `2214d57a15fc1c605dfe7db640e46d0308a236161c0b26e86835d8bddaee04cb`.
- `output/operations/phase6/av-admission/visual-intents/untimed-visual-intent-v1.json`
  — SHA256 `8df6ffb83c09a8dd089e8a27130551aefa254631d57d3acc6b6da7f0404a8087`.

Os documentos são entradas editoriais versionadas, não saídas de um avaliador
humano. O suplemento prende as decisões anteriores por arquivo/hash/seletor;
o plano aponta exatamente para o suplemento e para TakePlan/script/cap71.

## Verificação antes de consumo

O leitor deve reabrir os documentos pinados, conferir literalmente unidades,
fragmentos, estados e âncoras, e recompor a união com captions. Um candidato
repinado ou copiado não pode se passar pelo plano congelado. Testar também:
omissão/duplicação, alteração de texto, caracteres fracionários, criação de
tempos, mudança de fonte no HOLD, remoção de revelações e promoção de autoridade.

O conjunto planejado tem 24 unidades com revelações visuais e 17 com captions
internas; há sobreposição. A união recomposta em A8 é 26 unidades, não 41.
O receipt reala944a4f5… registra essa população literal, não tempos ou fontes
prontos. O antigo cohort30 continua incompatível com a
população restante; não foi revalidado ou usado.

## Próximas condições de conclusão

Inventário de aproveitamento, baseado em receitas/receipts e sem novo render:
14 estados possuem material histórico exato (11 PNGs e três hooks); dois são
callbacks das PNGs; 12 possuem receita de duas colunas e clean plate real, mas
não são 12 fontes finais; quatro dependem de seleção de contexto móvel; 68
dependem de composição/binding compatível. Soma 100, não percentual de produção
aprovada. Todos ainda exigem uso, tempo e gates aplicáveis.

Implementação literal testada e executada: `hero_engine/phase6_av_static_asset_uses.py` e
`schemas/phase6_av_static_asset_uses.schema.json` separam 13 usos literais de
11 fontes físicas/duas linhagens. Preservam os seis estados de exemplos e os
cinco de critérios; callbacks u044/u045 apontam apenas para door-0/reply-0,
sem trocar a unidade de proveniência nem herdar o veredito atribuído a Fear.
O contrato reabre os direitos e bytes reais, mas não cria spans, duração, FPS,
timestamps ou autoridade. Ainda não está integrado ao scheduling de A/B/C.
Receipt real b7b76158caac228e7bf3977e33c91fe057ec64bfa6422bc73b83540b3f5d49ed,
8,063 s; inspeção34450e7380b1e68dc4bd9d29; testes12/12 PASS12,645 s.

Done when do vínculo parcial: manifesto imutável; 13 usos/11 ativos/duas
linhagens conferidos; copy e revelações originais preservadas; ausência ou
divergência de direito/pin impede processamento; mutação ao final bloqueia;
testes positivos e negativos mais receipt real. Não é Done when do vídeo.
O verificador de direitos v2 reabre os pixels por ativo; a redundância de decode
local é conhecida, não geração de mídia nem fallback independente. Nenhum cache
de aprovação será introduzido sem contrato próprio de revalidação.

Pendência editorial específica antes de novos inserts: a Bible determina corpo
em sentence case, enquanto rótulos NAME/TEST/CHOOSE e outros nomes de framework
estão em caixa alta no plano. Não alterar o plano pinado ou declarar conformidade
silenciosamente: aplicar a regra de exceção narrativa explícita da Bible para
rótulos nomeados, com evidência/revisão independente designada, ou versionar a
correção. Essa decisão não permite misturar os dois frameworks nem generalizar
caixa alta para todos os textos do corpo.

1. Atendido no escopo: leitor13PASS e integraçãoA8 9novos+6afetadosPASS; root
   15PASS nos consumidores/bundle. São lotes separados, não aprovação de mídia.
2. Atendido no escopo: A8 real4,297s, timeline9542021b…/receipta944a4f5…,
   lê intenção literal antes do agendamento e conserva o bloqueio temporal.
3. Cada estado visual produtivo deve corresponder ao plano, não apenas seus IDs
   de unidade. Estados não instanciados continuam impedindo conclusão do vídeo.
4. Calibração e percepção reais, fontes/variedade, duração/grade, composição,
   movimento, mixagem e todos os gates A–D permanecem obrigatórios.

Custo adicional desta incorporação: R$ 0,00. Não houve compra, nova síntese,
renderização ou publicação. Não há alegação de retenção melhor ou viralidade
comprovada antes de render, QA e resultados medidos.
