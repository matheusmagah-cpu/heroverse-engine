# Fase 6 — Incidente visual anterior à publicação

Data: 2026-09-06 UTC. Escopo: candidato Vídeo 2, job `job-c516db5685acbbb423199bc1`, receita residente `phase6-standard-v1`. Não houve nova publicação neste diagnóstico.

## Observado nos pixels

1. Take-001, frame em 500 ms: `PAUSE BEFORE PANIC`, compatível com o texto planejado naquele frame. Isso não aprova movimento ou retenção.
2. Take-002, frame local em 1.000 ms / timeline em 2.000 ms: aparece `None`, mas o plano exige ausência de texto (`null`). Defeito crítico de fidelidade e legibilidade.
3. Take-003, frame local em 1.000 ms / timeline em 4.000 ms: aparecem `TRUTH`, `RESPONSIBILITY`, `TODAY`. O plano e a narração exigem `NAME / TEST / CHOOSE`. A Bible herdada também contém o framework antigo, portanto há conflito de contrato além do renderer fixo.

## Evidências preservadas

- `output/qa/phase6/diagnostics/voice-render-60322e8e/take-001-at-500ms.png`.
- `output/qa/phase6/diagnostics/voice-render-60322e8e/take-002-at-1000ms.png`: SHA-256 `d4e688beed0dc28ff2c86efa392faf566d5d4deaaf539db70bce6683ed4ac63c`.
- `output/qa/phase6/diagnostics/voice-render-60322e8e/take-003-at-1000ms.png`: SHA-256 `0bd5b882e7a722dc74ce5a4a455620298137c0660a189c43502cc2a8a2b0fd05`.
- TakePlan SHA-256 `547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5`.
- CreativeTreatmentPlan SHA-256 `3ae77eb015cd2364f1741b016a3520b0d51e5c68c41c3a5f5bfea890da1120db`.

## Correção D-129 e comparação real limitada

`str(None)` foi removido do caminho de overlay nulo. A receita v2 invalida os caches anteriores, mas conserva os receipts v1 como histórico. Nulos, campos ausentes e strings vazias não desenham texto; tipos inválidos falham antes da escrita; texto literal intencional não é reescrito.

Executado com sucesso:

```powershell
.\.venv\Scripts\python.exe scripts/verify_phase6_null_overlay_fix.py
```

O script valida a capacidade `capacity-phase6-c627f3d607ab45a84dacde80`, SHA-256 `490bfe65afdffd6de101814aa2abf238e7dfc52236c3f7192181e97bce5a1ebe`, e a fonte antes/depois, SHA-256 `1974e07d3bad82a6c4923b81da9897aecf737f25c725b81c1ebfcef5ac526273`.

Frame corrigido: `output/qa/phase6/diagnostics/null-overlay-v2/take-002-fixed-at-1000ms.png`, SHA-256 `87b07e4493019d2a859516a2197cfe70d07967e0c391538d03dc062fa775ba4a`. A imagem observada não contém o texto indevido; o gerador de filtros emite zero `drawtext`. A fonte, o plano e a narração não mudaram.

O script recusa sobrescrever um diagnóstico existente. Para repetir, use um workspace de teste isolado ou uma nova versão explicitamente registrada; não apague a evidência atual.

## Limites e próximos gates

- A comparação cobre um frame da correção de texto nulo. Não prova movimento, vídeo inteiro, retenção, viralidade ou aprovação editorial.
- O terceiro take continua reprovado por divergência de framework. A correção D-129 não resolve esse conflito.
- A instância residente não possui cancelamento cooperativo entre takes. Não foi morta nem teve lease alterado externamente.
- O novo código ainda exige deployment seguro e remediação/rebuild versionada dos efeitos locais antigos, com todos os gates posteriores.
- A verificação automática deve ler texto nos pixels, com modelo local, hash e timecode; contar apenas palavras do plano não detecta este defeito.
- Fase 6 `IN_PROGRESS`, custo técnico R$ 0,00, `publication_approved=false`.
