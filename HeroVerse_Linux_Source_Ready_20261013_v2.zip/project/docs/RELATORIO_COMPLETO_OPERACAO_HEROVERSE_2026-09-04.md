# Relatório integral da operação HeroVerse

**Período documentado:** início do projeto até 4 de setembro de 2026, 23:01 BRT  
**Canal:** HeroVerse — `@heroverse74`  
**Channel ID imutável:** `UCuMF6pJQkyMzaVoAxFL86yA`  
**Estado geral:** `IN_PROGRESS`  
**Fase vigente:** Fase 6 — piloto controlado, observação própria e aprendizado operacional  
**Custo técnico obrigatório e observado:** `R$ 0,00`  
**Objetivo operacional:** atingir a monetização por anúncios do YPP até 4 de outubro de 2026  

---

## 1. Resumo executivo

A operação saiu de um kit inicial com arquitetura majoritariamente documental e chegou a um fluxo real que:

1. analisa canais e vídeos de referência sem confundir popularidade com causalidade;
2. minera vídeos nas janelas críticas de hook e no nível de take;
3. produz um modelo editorial próprio para o HeroVerse;
4. planeja e monta vídeo original em inglês, take por take;
5. usa somente ativos com situação de direitos compatível com publicação;
6. valida automaticamente hook, narrativa, coerência, áudio, movimento, continuidade, direitos, originalidade, identidade e embalagem;
7. conecta-se ao canal exato com OAuth oficial e refresh não interativo;
8. faz upload privado, aplica thumbnail e captions, verifica processamento e só então promove o mesmo vídeo para público;
9. mantém um Gestor Central local em execução contínua;
10. coleta métricas próprias e interrompe decisões quando ainda não há dados suficientes.

O primeiro canário foi publicado publicamente:

- **vídeo:** [The 24-Hour Test: What To Do After You Pray](https://www.youtube.com/watch?v=iK_5edYQtx8);
- **video ID:** `iK_5edYQtx8`;
- **publicação oficial:** `2026-09-04T18:45:51Z`;
- **horário de Brasília:** `2026-09-04 15:45:51 BRT`;
- **receipt:** `COMPLETE_PUBLIC`;
- **custo:** `R$ 0,00`;
- **Ads:** nenhum;
- **upload duplicado:** nenhum.

Esse timestamp é o marco inicial da corrida de 30 dias. O encerramento da janela ocorre em:

- **UTC:** `2026-10-04T18:45:51Z`;
- **Brasília:** `2026-10-04 15:45:51 BRT`.

### Estado atual em uma tabela

| Dimensão | Estado real | Evidência principal |
|---|---|---|
| Fases 0–5 | `APPROVED` | `docs/STATE.md` |
| Fase 6 | `IN_PROGRESS` | `output/operations/phase6/pilot-plan.json` |
| Fases 7–8 | `NOT_STARTED`, pré-autorizadas e condicionadas | `docs/STATE.md` |
| Vídeo público | `COMPLETE_PUBLIC` | `creative-v3/youtube-publication-receipt.json` |
| Canal | conectado e repinado ao ID exato | `output/integrations/youtube/heroverse/connection-receipt.json` |
| OAuth | `continuous_operation_ready=true` | `output/integrations/youtube/heroverse/operational-readiness.json` |
| Gestor Central | tarefa `Running`, PID efetivo 15096 verificado | `output/runtime/gestor-central/autostart-verification.json` |
| Observador Fase 6 | `NOT_DUE` | `output/operations/phase6/observer-status.json` |
| Próxima coleta | `2026-09-05T18:45:51Z` | mesmo arquivo |
| FormatPack utilizável | 1 em `LIMITED` | `config/visual_style_registry.json` |
| Formatos apenas catalogados | 290 | mesmo arquivo |
| Formatos `PRODUCTION_READY` | 0 | mesmo arquivo |
| Testes | `230/230 PASS` | suíte integral local em 135,403 s |
| Schemas | `105/105 PASS` | Draft 2020-12 |
| Catálogo executivo | estado vivo, valores indisponíveis preservados e calendário D0–D30 exato | `outputs/01a05e82-e950-78c2-aba4-a88e62bf6a82/HERO_Engine_Catalog.xlsx` |
| Integridade congelada Fase 5 | 554 artefatos; 3.080.086.312 bytes | manifesto SHA-256 |
| Custo técnico | `R$ 0,00` | guards, receipts e configuração |
| Orçamento de mídia | não definido | Ads/Promote desativados |

### Controle executivo corrigido no fechamento

A planilha operacional foi reconciliada com a fonte de verdade da Fase 6. Ela não apresenta mais a cadência legada de `1 long + 2 Shorts/dia`, não transforma horas YPP indisponíveis em zero e não calcula necessidade de views com base em um contador inexistente. Dashboard, matemática e plano passam a exibir `UNAVAILABLE` quando falta a observação oficial.

O calendário foi corrigido para janelas exatas a partir do timestamp público: `D0 = 04/09`, `D1 = 24 h`, `D3 = 72 h`, `D7 = 168 h`, `D14 = 336 h` e `D30 = 720 h = 04/10`. Os 31 pontos `D0–D30` são checkpoints de controle, não uma promessa rígida de postagem. A inspeção final encontrou zero erro de fórmula e a revisão visual confirmou legibilidade do Dashboard, da matemática e do plano.

O heartbeat Codex existente foi alinhado para 16:00 BRT, cerca de 14 minutos após o checkpoint de 24 horas do Gestor. Ele não cria um segundo supervisor: lê Reporting, fila, previsão, experimento e aprendizado, age somente dentro dos gates e não habilita Ads sem orçamento.

### Fechamento D-083 — transição automática depois do checkpoint

O caminho entre observação e próxima produção deixou de depender de uma decisão implícita. No checkpoint elegível, o Gestor materializa, nesta ordem: prediction versionada, diagnóstico do gargalo, protocolo de uma variável e status executivo. O diagnóstico só aceita o snapshot próprio quando ele tiver pelo menos 24 horas, estiver `OBSERVED` e `ELIGIBLE_FOR_COMPARISON`. Antes disso, o estado obrigatório é `UNDETERMINED`, variável e métrica `NONE`, confiança `NONE` e produção bloqueada.

Quando a amostra for elegível, somente um ramo pode vencer: amostra/distribuição, embalagem, hook, narrativa ou replicação. Cada ramo possui uma variável única, métrica primária, constantes controladas e instrução de tratamento. Amostra inferior a 30 views não é usada para condenar criatividade; ela gera um tratamento exploratório de distribuição/ângulo com baixa confiança. O pré-registro pode liberar a entrada do Vídeo 2 em produção, mas não sua publicação. Direitos, originalidade, ChannelDNA, QA, identidade, cota e publicação private-first continuam obrigatórios.

O forecast vigente também foi reconciliado com a janela real: 30 dias, horas YPP `UNAVAILABLE`, cadência diária não pré-comprometida, zero simulações quando faltam entradas operacionais e probabilidades/distribuições `null`. O `forecast-30d` é refeito pela rotina diária; a saída de 21 dias foi preservada apenas em `output/reports/archive`.

### Fechamento D-084/D-085 — ordem executável e manutenção comprovada

O diagnóstico agora produz uma `Phase6TreatmentOrder` e o Gestor a consome por fila transacional. Embalagem é tratada no próprio canário; ângulo, hook ou narrativa compilam a pré-produção do Vídeo 2. O roteiro é original em inglês, o blueprint é take a take, os papéis semânticos exigem ativos elegíveis e a duração longa é rejeitada fora de 207.750–286.250 ms. Compilar não autoriza render nem publicação.

O ensaio integral expôs e corrigiu duas falhas reais: uma janela entre escrita e manifesto ao interromper o Gestor, e uma comparação de timestamp `Z` sujeita ao fuso local. A rotina agora para a cadeia verificada, reconcilia a snapshot estável, executa a suíte, rematerializa a operação e recupera o Gestor em `finally`, comparando locks com `DateTimeOffset` UTC.

A rotina Codex `HERO Engine — rotina diária` permanece única e `ACTIVE` às 16h BRT. Seu contrato foi atualizado para consumir ordem/executor, distinguir embalagem no canário de novo vídeo e continuar automaticamente somente depois das evidências e gates correspondentes.

### Fechamento D-086 — limite do FormatPack deixa de depender de interpretação

A auditoria do contrato encontrou uma lacuna precisa: o FormatPack `fp-broll-cinematic-narration@1.1.0` estava `LIMITED` para “um canário autônomo seguido de monitoramento”. Logo, o estado `LIMITED`, o diagnóstico e o pré-registro, sozinhos, não podiam ser tratados como autorização literal do Vídeo 2. O motor passou a emitir o receipt imutável `Phase6FormatScopeReceipt` antes da ordem. Esse recibo prende canal, nicho, formato, pipeline, perfil, ação, ordinal, custo e cadeia de identidade do canário a um overlay versionado.

O overlay `fp-broll-cinematic-narration-phase6-controlled-lot@1.0.0` permanece `LIMITED`; não promove o pack. Ele só chega a `AUTHORIZED` quando nove gates passam: sequência do lote, pack-base, pipeline, cadeia pública do canário, snapshot próprio de 24 h, alvo exato do tratamento, ausência de incidente crítico, qualidade autônoma do baseline e custo/publicação travados. O painel executivo agora exige esse receipt, expõe sua contagem de gates e não pode autorizar compilação apenas porque diagnóstico e protocolo parecem prontos.

Estado real no fechamento: `WAITING`, ação `WAIT`, 7 gates `PASS`, 2 `WAITING`, 0 `BLOCKED`, publicação `false`. A ordem possui agora 13 pré-condições, incluindo `FORMATPACK_LIMITATION_SCOPE`; o executor está `WAITING`, não criou job e não produziu Vídeo 2 prematuramente. Um `ERROR` transitório, gerado quando o runtime leu a ordem antiga durante a troca do schema, foi registrado como incidente resolvido e reconciliado pelo mesmo executor para `WAITING/NOT_CREATED`, sem apagar fila nem relaxar gate.

A manutenção transacional final terminou com código 0: `209/209` testes em 88,644 s, `92/92` schemas, manifesto congelado de 554 artefatos/3.080.086.312 bytes e catálogo/forecast regenerados. O Gestor voltou como tarefa `Running`, PID 9668, lock `HELD`, console no mesmo processo, duplicata bloqueada com código 73, stderr zero e `operational_ready=true`. OAuth permanece `HEALTHY`, identidade exata, zero falhas e nenhuma intervenção requerida.

### Fechamento D-087 — cadeia automática até a publicação e recuperação comprovada

O fluxo do Vídeo 2 deixou de terminar na pré-produção. O Gestor agora coordena, em sequência e com hashes imutáveis: release work order, alocação de ativos licenciados, voz/captions/render local, avaliação independente, pacote editorial, release gate, staging privado, thumbnail, captions, processamento, promoção pública e verificação final. O executor de mídia foi provado com um render FFmpeg STANDARD real de oito segundos; o teste não substitui o futuro vídeo, mas comprova o caminho técnico de render.

O avaliador da Fase 6 possui exatamente 18 gates críticos e 19 classes de defeito. Ele mede integridade, vídeo/áudio, movimento, flicker, black/freeze, ASR/captions, semântica, hook, estilo, continuidade, concentração de ativos, direitos, originalidade, identidade, embalagem, custo e prontidão do canal. Todos os gates e todos os defeitos precisam `PASS`; padrão-ouro e controle negativo também são obrigatórios. O gerador não aprova o próprio trabalho.

O controlador de publicação é retomável e fail-closed. Cada efeito externo é gravado antes do próximo: upload privado, thumbnail, captions, processamento, mudança para público e confirmação final. Se houver falha após o upload, o receipt preserva o ID privado e o retry continua o mesmo vídeo. A cota é reconciliada pelo dia do Pacífico, com reserva geral conservadora de 2.000 unidades e bloqueio preventivo antes de risco de cobrança. Ads não fazem parte desse fluxo.

Dois ensaios de manutenção falharam e foram preservados como evidência, não escondidos. O primeiro expôs um falso negativo na retomada; o segundo isolou o launcher do venv em encerramento e uma data ISO convertida por cultura local. A rotina passou a parar launcher antes do filho, tolerar somente o desaparecimento do PID exato, comparar diretamente `DateTimeOffset` em UTC, registrar o último probe e esperar até 120 segundos. O terceiro ensaio integral terminou com código 0: `224/224` testes em 142,752 s, `105/105` schemas, 554 artefatos/3.080.086.312 bytes preservados e catálogo regenerado. O Gestor voltou no PID 12972 com `operational_ready=true`, lock/console coincidentes, duplicata código 73, stderr zero e nenhum receipt de erro executivo.

Estado factual às `2026-09-05T00:15:26.484976Z`: `ACTIVE_OBSERVING`, 265 inscritos observados, 714,50681 h restantes no D30, fila `HEALTHY`, um checkpoint pendente e zero dead-letter. Como a evidência de 24 h ainda não existe, escopo, ordem, release, mídia, qualidade e publicação permanecem `WAITING`; isso prova que a automação respeita o gate em vez de publicar prematuramente.

### Fechamento D-088 — publicidade, marcas e pessoas deixam de herdar o gate autoral

A auditoria posterior encontrou uma falha conceitual precisa: `PUBLICITY` repetia o resultado de `RIGHTS`. Uma licença Creative Commons compatível ou domínio público pode permitir uso autoral, mas não prova autorização de imagem, marca ou endosso. No manifesto real havia dois ativos NASA/Artemis em domínio público com esse risco institucional. Eles não foram rotulados como infração; foram corretamente impedidos de receber aprovação automática.

O filtro agora atua em duas camadas. Antes do render, o release allocator remove riscos institucionais conhecidos da biblioteca elegível. Depois do render, um avaliador independente verifica todos os ativos efetivamente usados, seus ranges, a decodificação, os metadados e a presença de rostos. A detecção usa YuNet local, com licença MIT preservada e SHA-256 `ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0`. Uma detecção negativa é tratada somente como triagem de risco, nunca como parecer jurídico ou prova de ausência de toda marca/pessoa.

O ensaio com a biblioteca real confirmou que o sistema continua produtivamente viável depois do bloqueio: pré-produção pronta, 90 takes, 27 ativos únicos selecionados, participação máxima por ativo de 0,071514 e concentração dos seis maiores de 0,309229; nenhum dos dois ativos institucionais entrou na seleção. A publicação continuou `false`, pois o snapshot próprio de 24 horas ainda não existe.

A mudança legítima alterou a elegibilidade do release e expôs uma colisão no work order imutável antigo. Em vez de sobrescrever história, o contrato evoluiu para `1.1.0` e gerou `phase6-release-work-order-e8446e09593966c03cd2`; o schema continua aceitando o registro `1.0.0`. Uma segunda lacuna de observabilidade também foi corrigida: o status válido coexistia com um arquivo antigo de erro porque o limpador apontava para o diretório errado. Depois de sucesso schema-validado, o erro corrente é agora arquivado byte a byte sob SHA-256 e deixa de ser alerta atual.

A manutenção transacional posterior à implementação passou `229/229`, recuperou a tarefa no PID 15096 e confirmou lock, console, duplicata bloqueada, stderr zero e `operational_ready=true`. Após o teste novo de preservação histórica, a suíte integral isolada fechou `230/230 PASS` em 135,403 s; `105/105` schemas e compilação Python passaram. O estado atual permanece `ACTIVE_OBSERVING`, fila `HEALTHY`, sem erro executivo corrente, com o erro antigo preservado em `output/operations/phase6/errors/archive` e custo técnico R$ 0,00.

---

## 2. Limite de verdade deste relatório

Este documento usa quatro classes de informação:

- **observado:** veio de arquivo, API, mídia, navegador, console autenticado ou receipt;
- **calculado:** resulta de fórmula explícita aplicada a dado observado;
- **inferido:** hipótese editorial ou operacional ainda sujeita a teste;
- **indisponível:** não foi observado ou a plataforma não oferece a informação pelo canal de acesso usado.

A meta de 30 dias é obrigatória para a direção operacional. Ela define prioridade, velocidade de medição e critérios de correção. Ela não transforma distribuição, contagem qualificada ou aprovação do YouTube em resultado controlável pelo software.

Portanto:

- o sistema deve trabalhar para atingir a meta;
- o sistema deve calcular o desvio diariamente;
- o sistema deve corrigir conteúdo, embalagem e cadência quando houver evidência;
- o sistema não pode declarar viralidade, monetização, RPM ou aprovação YPP antes da evidência oficial;
- alcançar o limiar numérico ainda não substitui a revisão do canal pelo YouTube.

O próprio YouTube informa que, na janela atual, a monetização completa por anúncios exige 1.000 inscritos e uma das duas rotas: 4.000 horas públicas qualificadas em 12 meses ou 10 milhões de visualizações qualificadas de Shorts em 90 dias. O canal ainda passa por revisão depois de alcançar os limiares. Fonte: [visão geral e elegibilidade do YPP](https://support.google.com/youtube/answer/72851).

---

## 3. Como o pedido evoluiu até a operação atual

O projeto começou com os seguintes objetivos do proprietário:

- analisar minuciosamente o HeroVerse;
- manter o nicho em inglês;
- encontrar padrões de canais e vídeos com alta tração;
- modelar mecanismos de hook, narrativa, retenção e embalagem;
- produzir sem custo técnico adicional;
- trabalhar principalmente com recortes permitidos e montagem transformativa;
- automatizar mineração, planejamento, produção, QA, publicação e análise;
- usar Ads apenas como possível acelerador futuro;
- construir algo replicável para múltiplos canais e, depois, comercializável.

O escopo foi progressivamente endurecido:

1. a análise passou a exigir timecodes, frames, métricas e origem da evidência;
2. o hook passou a ser dividido em `0–1 s`, `1–3 s`, `3–8 s` e, em long-form, `8–30 s`;
3. a modelagem passou a exigir vencedores, medianos e fracos, não um viral isolado;
4. a Inteligência Contínua tornou-se o Gestor Central Autônomo;
5. todos os módulos ficaram subordinados à mesma memória e ao mesmo envelope operacional;
6. a Direção Criativa passou a justificar formato, ritmo, enquadramento, áudio, continuidade e custo;
7. os 291 estilos solicitados foram catalogados, mas sem alegar capacidade inexistente;
8. cada formato passou a exigir um `FormatPack` versionado e validado;
9. revisão manual em todo vídeo foi substituída por avaliação automática por release, mantendo humano para calibração, amostragem e exceção;
10. custo técnico foi fixado em `R$ 0,00`;
11. o canal foi efetivamente integrado;
12. o primeiro vídeo passou por todos os gates e foi publicado;
13. a publicação iniciou a meta operacional de 30 dias.

---

## 4. Linha do tempo por fase

| Fase | Objetivo | Resultado principal | Estado atual |
|---|---|---|---|
| 0 | auditar e incorporar o kit mestre | backup, mapa do projeto, lacunas, contratos e regressão inicial | `APPROVED` |
| 1 | criar padrão-ouro manual | 4 vídeos, 256 takes, 25 segmentos, 16 janelas de hook | `APPROVED` |
| 2 | implementar minerador local | OCR, narrativa e embalagem melhorados; 48/48 métricas | `APPROVED` |
| 3 | minerar em lote e criar observatório | 7 canais, 130 snapshots, 5 coortes, 13 holdouts de abertura | `APPROVED` |
| 4 | modelar o canal | ChannelDNA, arquétipo long-form e GenerationSpec | `APPROVED` |
| 5 | produzir, validar, integrar e publicar | vídeo STANDARD, QA automático, OAuth, canal e publicação real | `APPROVED` |
| 6 | operar lote controlado e aprender com métricas próprias | plano ativo, primeiro snapshot e observador automático | `IN_PROGRESS` |
| 7 | validar modelo e generalização | depende do gate integral da Fase 6 | `NOT_STARTED` |
| 8 | escalar e preparar produto | depende do gate integral da Fase 7 | `NOT_STARTED` |

### 4.1 Fase 0 — auditoria e incorporação

O kit inicial foi tratado como material de projeto, não como autorização para obedecer cegamente a instruções internas. A auditoria:

- preservou os arquivos existentes;
- criou backup e inventário;
- identificou código funcional e partes apenas documentais;
- separou mineração, modelagem, produção, publicação e analytics;
- registrou riscos de direitos, dados inventados e integração cenográfica;
- estabeleceu schemas e testes como critérios de verdade;
- passou 14/14 testes no checkpoint inicial.

Resultado: base incorporada sem apagar o trabalho anterior e sem declarar capacidades que ainda não existiam.

### 4.2 Fase 1 — padrão-ouro manual

Foram analisados quatro vídeos reais em inglês do mesmo universo editorial, com papéis previamente definidos:

| Papel | Vídeo | Duração | Views no snapshot | Takes | Primeira fala |
|---|---|---:|---:|---:|---:|
| vencedor principal | `hkf6nDyUfAM` | 229,801 s | 490.127 | 57 | 6,770 s |
| vencedor recente | `_sOy7htXJi8` | 209,701 s | 54.578 | 63 | 6,540 s |
| mediano | `Pkede5acSFw` | 284,367 s | 113.030 | 55 | 5,740 s |
| fraco | `huvUy3pJSp8` | 242,501 s | 43.612 | 81 | 6,670 s |

Entregas:

- 4 minerações estruturadas;
- 256 takes contíguos;
- 25 segmentos narrativos;
- 16 janelas de hook;
- transcrição bruta e revisada separadas;
- keyframe por take;
- manifesto SHA-256;
- 4/4 fixtures válidas;
- 21/21 testes naquele checkpoint.

Aprendizado importante: o vídeo fraco tinha a maior frequência bruta de candidatos de corte. Logo, “mais cortes” não foi promovido como causa de sucesso. Clareza da promessa e alinhamento entre abertura, corpo e payoff mostraram sinal mais útil.

Os quatro vídeos de análise permaneceram `production_eligible=false`. Material público não foi tratado como automaticamente reutilizável.

### 4.3 Fase 2 — minerador local

O minerador foi evoluído de `miner-local-0.1.0` para `miner-local-0.2.0`.

Melhorias medidas:

| Campo | Baseline | Challenger | Delta |
|---|---:|---:|---:|
| OCR | 0,151515 | 0,977273 | +0,825758 |
| Narrativa | 0,287386 | 0,718333 | +0,430947 |
| Packaging | 0,745455 | 0,877403 | +0,131948 |
| Timestamps | 1,000000 | 1,000000 | 0 |
| Takes | 1,000000 | 1,000000 | 0 |
| Direitos/proveniência | 1,000000 | 1,000000 | 0 |

O pipeline executou:

- ASR local;
- detecção de takes;
- seleção de frames;
- OCR seletivo;
- hooks;
- segmentação narrativa;
- embalagem;
- cache, idempotência e replay.

Resultados:

- 48/48 métricas aprovadas;
- 4/4 execuções completas;
- 4/4 replays idênticos por hash semântico;
- 38/38 testes;
- 1.125 artefatos do challenger;
- custo externo `US$ 0,00`.

O aprendizado foi classificado como `SUPPORTED_LOCAL`, não como generalização.

### 4.4 Fase 3 — observatório e lote

O observatório coletou sete canais:

- HeroVerse;
- `@GraceGritLove`;
- `@lionofjudahmotivation`;
- `@GospelPath-m3v`;
- `@THECHOSENPATH1.1m`;
- `@GODSLIVINGWORD-p2e`;
- `@DavidDigaHernandez` como fonte isolada.

Cobertura:

- 7 snapshots de canal;
- 123 snapshots de vídeo;
- 130 snapshots totais;
- 126 completos;
- 4 parciais por ausência pública da aba Shorts;
- 0 falhas silenciosas;
- 4 vídeos `FULL_VALIDATED`;
- 16 aberturas `OPENING_ONLY`;
- 123 itens `METADATA_ONLY`;
- 13 holdouts reais de abertura;
- 5 coortes.

As coortes foram normalizadas por views por dia completo e separadas em vencedor, mediano, fraco, período recente e cross-channel. Views brutas nunca foram aceitas como causa.

O banco recebeu:

- ledger append-only;
- snapshots append-only;
- isolamento por operação/canal;
- erros explícitos;
- memória tipada;
- triggers contra update/delete indevido;
- replay sem rede;
- `PRAGMA integrity_check = ok`.

Checkpoint: 49/49 testes, 17/17 schemas e custo `US$ 0,00`.

### 4.5 Fase 4 — modelo do HeroVerse

O modelo promoveu um único arquétipo long-form:

`promessa espiritual direta → stakes pessoais → mecanismo/prova → reversão/ação → payoff de identidade`

O ChannelDNA manteve:

- idioma inglês;
- motivação cristã;
- segunda pessoa;
- fé prática;
- oração, sabedoria, caráter e ação;
- intensidade sem profecia fabricada;
- promessa respondida pelo corpo do vídeo.

E proibiu:

- copiar logo, sufixo, voz, música, layout ou wording da referência;
- importar personagens ou marcas protegidas;
- “chosen-one superiority”;
- profecia sem sustentação;
- fearbait sem resolução;
- certeza divina ou econômica inventada;
- regra de “percentual de alteração” como licença.

Contrato do hook:

- `0–1 s`: tensão ou contradição concreta;
- `1–3 s`: âncora espiritual e consequência pessoal;
- `3–8 s`: mecanismo/prova e open loop respondível;
- `8–30 s`: primeiro payoff, contexto e stakes.

Confiança do arquétipo: `0,408248`, calculada como `sqrt(4/24)`. Isso autorizou um piloto, não escala.

Checkpoint: 60/60 testes, schema e refs válidos, custo externo `US$ 0,00`.

### 4.6 Fase 5 — produção, correções, integração e publicação

A Fase 5 não aceitou o primeiro vídeo como pronto.

#### Protótipo inicial

- 252,4 s;
- 44 takes;
- 7.572 frames;
- deriva 0 ms;
- 7 gates automáticos PASS;
- 9 itens `NEEDS_REVIEW`;
- publicação bloqueada.

#### Creative-v2.1

- 135,2 s;
- 32 takes;
- 13 ativos;
- 11/11 contratos criativos;
- técnica, direitos, originalidade e custo aprovados.

Mesmo assim, a auditoria de mercado rejeitou a versão porque:

- H1/H2 falhavam;
- 77,2929% do material era paisagem;
- não havia captions;
- a duração ficou 34,9218% abaixo do arquétipo;
- o FormatPack ainda não podia ser usado em produção.

#### Creative-v3.1

A versão seguinte chegou a 238,7 s, 59 takes e 18 ativos. Depois de inspeção ampliada, foi reprovada retroativamente:

- seis motivos dominantes somavam 66,3176% do runtime;
- havia concentração acima da margem;
- contagem de fontes únicas mascarava repetição visual.

O baseline foi preservado em histórico. Não foi apagado nem chamado de aprovado.

#### Creative-v3.2 — versão publicada

A correção introduziu:

- 22 fontes;
- quatro infográficos originais produzidos localmente;
- realocação semântica de takes;
- gates contra concentração por ativo;
- limite de reutilização;
- janela móvel de 60 s;
- redução da participação de paisagem;
- captions completas;
- áudio qualificado;
- equivalência de replay.

Essa versão se tornou o candidato STANDARD que foi publicado.

### 4.7 Fase 6 — operação atual

A Fase 6 iniciou automaticamente depois do receipt público.

Ela já possui:

- plano controlado ativo;
- um vídeo publicado no lote;
- limite inicial de três long-form;
- coleta própria pela Data API e Analytics API;
- observador integrado ao loop do Gestor;
- janelas de 0, 24, 72, 168, 336 e 720 horas;
- preservação de `null` quando a métrica ainda não existe;
- bloqueio de Ads por ausência de orçamento;
- zero custo técnico.

Depois da incorporação D-079, ela também já possui:

- YouTube Reporting API ativa com jobs basic/reach idempotentes;
- adapter bulk que baixa, hasheia, isola e agrega somente o reach do vídeo próprio;
- fila SQLite com claim/lease/checkpoint/retry/DLQ;
- prediction imutável com recusa explícita de falsa calibração;
- protocolo de experimento e Learning Evaluator determinísticos;
- status executivo consolidado.

Ela ainda precisa concluir:

- receber do provedor o primeiro relatório bulk real;
- avaliar previsão somente após horizonte e amostra próprios;
- aprendizado versionado aplicado ao vídeo seguinte;
- fechamento do lote de até três vídeos;
- gate integral antes da Fase 7.

---

## 5. Mineração e modelagem: o que foi realmente aprendido

### 5.1 O que foi modelado

O projeto não copiou a obra específica de um viral. Modelou funções:

- promessa imediata;
- tensão espiritual com consequência pessoal;
- mecanismo concreto;
- progressão de problema para ação;
- payoff que responde à promessa;
- identidade editorial própria;
- hook com função em cada janela;
- ritmo visual subordinado à narrativa;
- embalagem que nomeia o mecanismo.

### 5.2 O que foi rejeitado

- copiar frase ou áudio apenas porque performou;
- usar um único viral como regra;
- concluir que mais cortes causam mais retenção;
- usar score do vidIQ como previsão;
- usar views brutas sem idade e baseline;
- chamar conteúdo público de livre de direitos;
- copiar estética ou personagem protegido;
- usar template visual universal;
- prometer resultado espiritual, financeiro ou algorítmico.

### 5.3 Resultado do modelo

O vídeo publicado não é uma remontagem do roteiro de referência. Ele usa uma tese original e um mecanismo próprio:

`TRUTH → RESPONSIBILITY → TODAY`

A promessa editorial é transformar oração em um próximo passo responsável em 24 horas, sem dizer que qualquer impulso é instrução divina ou que a ação garante o resultado.

---

## 6. Auditoria e preparação do canal

### 6.1 Identidade atual observada

Consulta oficial autenticada em 4 de setembro de 2026:

| Campo | Valor |
|---|---|
| Título | HeroVerse |
| Handle | `@heroverse74` |
| Channel ID | `UCuMF6pJQkyMzaVoAxFL86yA` |
| País configurado | US |
| Idioma de operação | inglês |
| Inscritos públicos | 265 |
| Vídeos públicos | 22 |
| Views agregadas informadas | 2.636 |
| Conteúdo infantil | não |

Observação: o total agregado do canal pode apresentar atraso em relação ao contador do vídeo recém-publicado. O sistema não força reconciliação artificial durante a defasagem da plataforma.

### 6.2 Correções executadas no canal

- descrição reescrita e alinhada ao nicho;
- palavras-chave ajustadas;
- conflito de localização/idioma corrigido;
- Home ativada e verificada com conteúdo;
- banner v2 salvo e confirmado publicamente;
- avatar validado;
- watermark aplicado;
- promessa de postagem diária removida porque não existia cadência que a sustentasse;
- identidade visual alinhada a fé prática e motivação cristã;
- readiness de publicação do canal promovido a `PASS`.

### 6.3 Estado da Home e do catálogo

No snapshot de auditoria anterior ao novo vídeo:

- Home ativada;
- sete seções de canal;
- zero playlists próprias observadas;
- nenhum trailer definido;
- 21 vídeos públicos;
- todos com metadata em inglês;
- 20 thumbnails com aparência de frame vertical;
- repetição de dourado/preto;
- dois grupos de títulos duplicados ou quase duplicados.

Depois da publicação, o catálogo passou a 22 vídeos públicos. O novo long-form não resolve automaticamente os problemas históricos.

### 6.4 Readiness de publicação versus readiness de YPP

São gates diferentes:

- **publicação:** `PASS`;
- **aplicação YPP:** `BLOCKED`.

O YPP permanece bloqueado por:

- contadores qualificados ainda abaixo do limiar;
- auditoria integral de direitos/originalidade do catálogo legado ainda não concluída;
- duplicação histórica de embalagem;
- revisão da adequação do canal inteiro à política de conteúdo reutilizado e produzido em massa;
- ausência de AdSense vinculado confirmada neste projeto, se ainda não existir no Studio.

O YouTube avalia o canal como um todo. Um vídeo novo aprovado não limpa automaticamente riscos do catálogo antigo.

---

## 7. Diretor Criativo e capacidade visual

### 7.1 Arquitetura

O Diretor Criativo é um executor subordinado ao Gestor Central. Ele não possui estratégia, memória ou autorização paralela.

Fluxo:

`ChannelDNA → objetivo → público → orçamento → evidência de mercado → FormatPack → Style Bible → TakePlan → produção → Quality Gates → resultado → aprendizado`

Cada decisão registra:

- formato visual;
- motivo da escolha;
- público e nicho compatíveis;
- emoção pretendida;
- composição e câmera;
- iluminação e paleta;
- movimento e duração de take;
- transições;
- texto e tipografia;
- voz, trilha e sound design;
- ferramentas e fallbacks;
- direitos;
- custo;
- testes;
- versão.

### 7.2 Catálogo de formatos

| Estado | Quantidade |
|---|---:|
| `CATALOGED` | 290 |
| `SPECIFIED` | 0 |
| `PROTOTYPED` | 0 |
| `VALIDATED` | 0 |
| `PRODUCTION_READY` | 0 |
| `LIMITED` | 1 |
| `BLOCKED` | 0 |
| `DEPRECATED` | 0 |

Conclusão correta: a arquitetura conhece 291 formatos, mas só um pode ser usado hoje, e apenas dentro de um limite estreito. Não existe alegação de “todos os formatos suportados”.

### 7.3 FormatPack atual

- ID: `fp-broll-cinematic-narration`;
- versão: `1.1.0`;
- estado: `LIMITED`;
- canal: somente HeroVerse;
- nicho: motivação cristã em inglês;
- tipo: long-form;
- pipeline: `pipeline-clips-longform-v1`;
- perfil: `STANDARD`;
- autorização: lote controlado;
- mudança de versão/ferramenta/voz/format exige nova avaliação;
- terceiro vídeo do lote dispara amostra obrigatória.

### 7.4 Consistência

O projeto mantém:

- Channel Style Bible;
- identidade `TRUTH / RESPONSIBILITY / TODAY`;
- paleta e tipografia;
- regras de continuidade;
- TakePlan com origem do ativo;
- decisão de personagem/cenário quando aplicável;
- câmera e movimento por take;
- histórico visual;
- verificação contra repetição e deriva.

Nenhuma mistura visual é aprovada apenas porque as imagens individuais são bonitas.

---

## 8. Especificação do vídeo publicado

### 8.1 Artefato congelado

| Campo | Valor |
|---|---|
| Título | `The 24-Hour Test: What To Do After You Pray` |
| ID público | `iK_5edYQtx8` |
| Duração de projeto | 238,7 s |
| Duração reportada pelo YouTube | 239 s |
| Resolução | 1920×1080 |
| FPS | 30 |
| Tamanho | 305.941.876 bytes |
| SHA-256 | `33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c` |
| Takes | 59 |
| Fontes visuais | 22 |
| Perfil | `STANDARD` |
| Custo externo | `R$ 0,00` |

### 8.2 Hook

O contrato mede separadamente:

- `0–1 s`;
- `1–3 s`;
- `3–8 s`;
- `8–30 s`.

No gate final:

- primeira unidade de voz: 876 ms;
- segunda unidade acumulada: 1.941 ms;
- terceira unidade: 3.520 ms;
- três fontes visuais distintas no hook;
- sete eventos visuais até 8 s;
- timing: `PASS`;
- promessa visual inicial: `PRAYER ISN'T THE FINISH`.

O hook não foi copiado de um vídeo de referência. A função foi modelada e a redação foi criada para o mecanismo de 24 horas.

### 8.3 Narrativa

- nove seções ordenadas;
- 539 palavras no roteiro canônico;
- tese original;
- mecanismo de três testes;
- aplicação prática;
- exceção de segurança;
- payoff que responde ao título;
- CTA compatível com o canal.

### 8.4 Planejamento take por take

Cada um dos 59 takes registra:

- início e fim;
- função narrativa;
- informação;
- emoção;
- ativo;
- composição;
- câmera;
- movimento;
- iluminação;
- ação;
- texto;
- narração;
- áudio;
- entrada e saída;
- origem;
- direitos;
- ferramenta;
- custo;
- relação com retenção;
- critérios de qualidade.

Cobertura semântica: `59/59` takes completos, 12 funções narrativas distintas e zero fallback genérico proibido.

### 8.5 Variedade visual

| Medida | Observado | Limite |
|---|---:|---:|
| maior participação de um ativo | 8,2111% | 10% |
| participação dos seis maiores | 44,3653% | 55% |
| máximo de usos de um ativo | 4 | 5 |
| máximo da mesma fonte em 60 s | 3 | 3 |
| participação de paisagem | 24,7591% | 25% |

O resultado passou com margem nos principais limites, embora paisagem esteja próxima do teto. A margem pequena permanece informação de risco para o próximo vídeo.

### 8.6 Movimento e continuidade

- 477 amostras visuais;
- p95 de variação de luminância intratake: `3,373185`;
- limiar de flicker: `15`;
- black events: 0;
- freeze events: 0;
- hard transitions intratake: 0;
- erro de duração: 0 ms;
- deriva acumulada: 0 ms;
- repetição adjacente de fonte: não;
- frame lock: `PASS`.

Uma falha real de freeze entre `236,167–237,567 s` foi encontrada numa iteração e corrigida antes do candidato final.

### 8.7 Áudio

- idioma reconhecido: inglês;
- modelo independente: `faster-whisper base.en`, CPU, int8;
- 540 palavras de referência;
- 542 observadas;
- 5 erros;
- WER: `0,009259`;
- limite WER: `0,08`;
- loudness integrado: `-16,34 LUFS`;
- true peak: `-1,23 dBTP`;
- ausência de clipping crítico;
- áudio decodificado equivalente no replay.

O ASR é avaliador local independente do gerador de voz. O sistema não usa a própria geração como única prova de inteligibilidade.

### 8.8 Captions

- idioma: `en-US`;
- cues: 59/59;
- cobertura: 100%;
- máximo: 12 palavras por cue;
- WER contra roteiro: 0;
- hash verificado;
- inserção real no YouTube: `PASS`.

### 8.9 Thumbnail e título

Thumbnail escolhida:

- candidato: B;
- texto: `DO THIS TODAY`;
- tamanho: 1280×720;
- SHA-256: `0a3dd96bf7839365ba54212d17400058b53456b310fc3731f3f002573a00ba4f`;
- seleção: rubric editorial autônomo, não score isolado.

O título anterior recebeu score auxiliar 82. O título publicado recebeu 91. Uma alternativa com 96 foi rejeitada porque o tom acusatório violava o ChannelDNA. Logo, o maior score não ganhou automaticamente.

### 8.10 Direitos e originalidade

- ativos usados: 22;
- elegíveis: 22;
- desconhecidos/restritos: 0;
- material sintético declarado: sim;
- atribuições exigidas incluídas na descrição: sim;
- status automático de direitos: `PASS_AUTOMATIC`;
- comparação de originalidade: 4 fontes;
- maior overlap de trigramas: `0,003752`;
- limiar: `0,02`;
- resultado: `PASS`.

O vídeo combina:

- imagens geradas localmente ou já produzidas para o projeto;
- infográficos próprios;
- material público em domínio público, CC0 ou Creative Commons elegível;
- atribuição na descrição quando exigida.

O fato de um vídeo ou take estar publicamente visível não foi usado como licença. A origem e o direito são avaliados separadamente.

### 8.11 Divulgação de material sintético

O pacote marca `containsSyntheticMedia=true` porque há cenas ilustrativas fotorrealistas que não registram acontecimentos reais. Isso evita representar ilustração como evidência factual capturada.

---

## 9. Quality Gates do release

### 9.1 Gates criativos automáticos

O avaliador autônomo passou 12/12 gates críticos:

| Gate | Estado |
|---|---|
| hook | `PASS` |
| narrativa | `PASS` |
| coerência semântica | `PASS` |
| estilo | `PASS` |
| continuidade | `PASS` |
| movimento | `PASS` |
| legibilidade | `PASS` |
| áudio | `PASS` |
| originalidade | `PASS` |
| direitos/publicidade | `PASS` |
| identidade do canal | `PASS` |
| thumbnail | `PASS` |

### 9.2 Gates consolidados de publicação

O release passou 13/13 gates:

1. integridade dos artefatos;
2. QA automático;
3. qualidade perceptual autônoma;
4. política de padrão-ouro;
5. seleção de thumbnail;
6. captions;
7. capacidade do FormatPack;
8. direitos;
9. readiness do canal;
10. durabilidade OAuth;
11. alinhamento de escopos;
12. staging privado primeiro;
13. custo zero e cota gratuita.

Resultado: `READY_FOR_PUBLICATION_PIPELINE`, zero blockers.

### 9.3 Papel da revisão humana

Não existe formulário humano obrigatório antes de toda postagem.

Política vigente:

- avaliação automática em 100% dos releases;
- amostra humana rotineira de 10%;
- revisão obrigatória por exceção quando houver:
  - dúvida ou falha de gate crítico;
  - novo FormatPack;
  - mudança de pipeline, voz, ferramenta ou versão;
  - ambiguidade de direitos/publicidade;
  - reclamação ou anomalia pós-publicação;
  - terceiro vídeo do lote `LIMITED`.

O avaliador declara `human_reviewer_claimed=false`. Ele não se apresenta como humano.

---

## 10. Integração do YouTube

### 10.1 Conta e canal

A integração foi concluída com a conta autorizada pelo proprietário e repinada ao canal:

- handle: `@heroverse74`;
- channel ID: `UCuMF6pJQkyMzaVoAxFL86yA`;
- identidade após refresh: `PASS`.

Credenciais não foram gravadas no repositório nem neste relatório.

### 10.2 Escopos mínimos

- `youtube.readonly`;
- `yt-analytics.readonly`;
- `youtube.upload`;
- `youtube.force-ssl`.

### 10.3 Configuração OAuth

- app: `HeroVerse Channel Operations`;
- audiência: externa;
- estado: `IN_PRODUCTION`;
- quatro escopos alinhados no console;
- site de conformidade público em GitHub Pages;
- HTTPS ativo;
- Search Console por URL-prefix verificado;
- uso pessoal atual registrado;
- token externo ao workspace;
- espelho atômico por hash;
- refresh sem navegador;
- persistência atômica;
- revalidação do channel ID;
- `continuous_operation_ready=true`.

A configuração pessoal atual não é automaticamente a configuração comercial multiusuário futura. O produto comercial ainda exigirá isolamento por cliente e, provavelmente, domínio/propriedade adequados ao novo escopo.

### 10.4 Saúde automática da sessão

Estado no fechamento deste relatório:

- saúde: `HEALTHY`;
- refresh não interativo: sim;
- falhas consecutivas: 0;
- intervenção humana necessária: não;
- última prova: `2026-09-04T19:00:54.586340Z`;
- próxima prova: `2026-09-05T19:00:54.586340Z`;
- consumo normal por prova: 1 unidade da Data API;
- limite planejado: uma prova saudável por dia.

Falhas transitórias repetem após seis horas. Ausência real de refresh token/escopo ou três falhas seguidas gera `REAUTH_REQUIRED`.

### 10.5 Isolamento entre contas do computador

Quando uma reautorização interativa for realmente necessária, o sistema usa a tela oficial do Google com:

- `prompt="consent select_account"`;
- `access_type="offline"`.

O sistema não imita a tela do Google, não guarda senha e não automatiza código de autenticação. Na operação normal, o refresh evita login recorrente.

---

## 11. Publicação real

### 11.1 Ordem executada

1. canal exato verificado;
2. vídeo congelado enviado como `private`;
3. thumbnail B aplicada;
4. captions em inglês inseridas;
5. vídeo privado e canal reconsultados;
6. processamento confirmado;
7. o mesmo video ID promovido para `public`;
8. estado público/processado/canal verificados;
9. página pública validada por HTTP 200;
10. oEmbed confirmou título, autor e thumbnail.

### 11.2 Receipt

| Campo | Valor |
|---|---|
| receipt ID | `youtube-publication-f8f7adb600b32dfbae24` |
| release ID | `phase5-release-f8f7adb600b32dfbae24` |
| status | `COMPLETE_PUBLIC` |
| privacy | `public` |
| video ID | `iK_5edYQtx8` |
| erro | nenhum |
| custo externo | R$ 0,00 |

### 11.3 Recuperações ocorridas

O pipeline encontrou falhas reais e não duplicou o upload:

- processo antigo em memória após mudança de schema;
- access token de curta duração expirado;
- processamento ainda não finalizado no primeiro ciclo;
- divergência posterior entre token de origem e token canônico do runtime.

Correções:

- refresh antecipado quando faltam até cinco minutos para expirar;
- persistence atômica;
- retry temporal do estado `STAGED_PRIVATE_AWAITING_PROCESSING`;
- idempotency key;
- reutilização do mesmo receipt e video ID;
- comparação de hash do token efetivo com o receipt de refresh;
- resolução do token canônico pelo watcher do Gestor.

Resultado: nenhuma segunda chamada de upload para o canário.

---

## 12. Gestor Central Autônomo

### 12.1 Responsabilidade

O Gestor Central é a autoridade operacional única. Ele mantém a cadeia:

`objetivo → evidência → decisão → comando → executor → artefato → resultado`

Mineração, modelagem, Diretor Criativo, render, QA, publicação, analytics e aprendizado não podem manter estratégias paralelas.

### 12.2 Runtime atual

- tarefa Windows: `HeroEngine-Phase5-CentralManager`;
- estado da tarefa: `Running`;
- PID efetivo verificado no fechamento: `8900`;
- comando: módulo `hero_engine.central_manager_phase5` em loop;
- intervalo: 60 segundos;
- lock real do SO;
- lease e heartbeat;
- segunda instância bloqueada com código 73;
- console local em `127.0.0.1`;
- custo: R$ 0,00.

O nome e o campo `phase=5` do runtime são legado do supervisor criado na Fase 5. Ele já chama o observador da Fase 6, mas a migração de nomenclatura/estado para um Gestor multifáse é trabalho aberto da Fase 6.

### 12.3 Estado lógico

- `mode=ACTIVE`;
- `cycle_status=UNCHANGED` quando não há evidência nova;
- `release_decision=READY_FOR_PUBLICATION_PIPELINE`;
- `publication_status=COMPLETE_PUBLIC`;
- blockers: 0;
- custo técnico: 0.

### 12.4 Pausa e recuperação

O arquivo `output/runtime/gestor-central/PAUSE` coloca o ciclo em pausa controlada. A remoção do arquivo permite retomada. A tarefa do Windows pode ser parada e iniciada sem alterar os artefatos, receipts ou tokens.

### 12.5 Continuidade do computador

O plano de energia ativo foi configurado para não apagar a tela:

- `VIDEOIDLE AC = 0`;
- `VIDEOIDLE DC = 0`.

Isso não remove bloqueio de segurança, senha ou controles do Google.

---

## 13. Inteligência Contínua e aprendizado real

O sistema só declara aprendizado quando existe a sequência completa:

`observação → baseline → hipótese → previsão prévia → experimento → resultado → avaliação → atualização versionada → aplicação futura → nova medição`

Sem evidência nova, o estado é `NO_NEW_EVIDENCE`.

### 13.1 O que já foi aprendido

- o minerador 0.2.0 superou o baseline em OCR, narrativa e packaging na amostra local;
- frequência bruta de cortes não separou vencedor de fraco;
- concentração visual exige medidas de runtime, não apenas contagem de ativos;
- thumbnail com maior score não deve vencer quando conflita com a voz editorial;
- OAuth válido em um arquivo não basta: o runtime e o receipt precisam apontar para o mesmo token;
- uma página de revisão pode estar HTTP 200 e ainda falhar em carregar mídia; o fluxo precisa ser testado no navegador;
- Data API e Analytics API apresentam atraso após publicação;
- impressões/CTR não são suportados pela consulta targeted usada e exigem o Reporting API bulk.

### 13.2 O que ainda não foi aprendido

- retenção real do novo vídeo;
- CTR real da thumbnail B;
- conversão em inscritos;
- origem de tráfego;
- watch hours qualificadas geradas;
- causalidade do hook;
- desempenho contra outro vídeo do mesmo pipeline;
- RPM;
- saturação do formato;
- capacidade de transferência para outro canal.

Esses pontos permanecem indisponíveis ou candidatos, não resultados.

---

## 14. Corrida de monetização em 30 dias

### 14.1 Definição da meta

Meta primária: tornar o HeroVerse elegível à monetização completa por anúncios do YPP até `2026-10-04 15:45:51 BRT`.

Meta expandida de fan funding não substitui a meta primária. Na janela atual, o programa expandido pode ser acessado em regiões elegíveis com 500 inscritos, três uploads públicos recentes e 3.000 horas públicas ou 3 milhões de Shorts qualificados; a monetização completa por anúncios continua no limiar superior. Fonte: [YPP expandido](https://support.google.com/youtube/answer/13429240).

### 14.2 Baseline de partida disponível

| Métrica | Baseline | Data/fonte | Limitação |
|---|---:|---|---|
| inscritos | 265 | Data API em 04/09/2026 | contador público |
| vídeos públicos | 22 | Data API em 04/09/2026 | inclui 2 longs e 20 Shorts observados |
| horas públicas qualificadas | 0 | Earn tab, snapshot em 29/08/2026 | precisa de nova observação oficial |
| Shorts qualificados em 90 dias | 1.200 | Earn tab, snapshot em 29/08/2026 | precisa de nova observação oficial |
| RPM real | indisponível | canal ainda não monetizado | não estimado como fato |

### 14.3 Aritmética da meta completa

Rota long-form:

- inscritos faltantes: `1.000 - 265 = 735`;
- ritmo médio exigido: `735 / 30 = 24,5 inscritos líquidos/dia`;
- horas faltantes no baseline registrado: `4.000`;
- ritmo médio exigido: `4.000 / 30 = 133,3333 horas qualificadas/dia`.

Rota Shorts:

- views qualificadas faltantes: `10.000.000 - 1.200 = 9.998.800`;
- ritmo médio exigido: `9.998.800 / 30 = 333.293,3333 views qualificadas/dia`;
- inscritos faltantes continuam 735.

Essas contas medem a distância. Não são previsão de audiência.

### 14.4 Fórmula operacional para long-form

Quando o Analytics liberar a duração média assistida real:

`views necessárias = minutos qualificados restantes / AVD real em minutos`

Como o AVD ainda é `null`, qualquer número de views necessário neste momento seria uma hipótese. O sistema aguardará o dado real da janela de 24 horas.

### 14.5 Janela de medição

| Marco | Timestamp BRT | Uso |
|---|---|---|
| D0 | 04/09 15:45:51 | publicação, integridade e baseline inicial |
| D1 / 24 h | 05/09 15:45:51 | primeira decisão comparável; liberar ou revisar vídeo 2 |
| D3 / 72 h | 07/09 15:45:51 | tração, retenção, inscritos e origem |
| D7 / 168 h | 11/09 15:45:51 | primeira leitura de tendência semanal |
| D14 / 336 h | 18/09 15:45:51 | revisão de meio de ciclo |
| D30 / 720 h | 04/10 15:45:51 | fechamento da meta e estado YPP |

O observador também pode registrar snapshots adicionais quando ocorrer evento material, mas não deve mudar os marcos pré-registrados retroativamente.

### 14.6 Regra de execução para atingir a meta

1. preparar o próximo vídeo em paralelo;
2. não publicar o vídeo 2 antes do checkpoint de 24 h;
3. medir vídeo, canal e contadores qualificados;
4. identificar o gargalo dominante: impressão, CTR, retenção, conversão, cadência, política ou catálogo;
5. corrigir uma hipótese versionada por vez quando a atribuição exigir isolamento;
6. manter hook, narrativa e embalagem adaptativos, sem congelar template;
7. publicar apenas com release novo e gates completos;
8. comparar cada release com baseline por idade e formato;
9. interromper padrões que falhem repetidamente;
10. ampliar o lote somente quando a evidência e o estado do FormatPack permitirem.

### 14.7 Papel de Shorts e long-form

O caminho inicial é long-form porque:

- existe modelo audiovisual validado para long;
- horas de Shorts no feed não contam para as 4.000 horas;
- 10 milhões de Shorts em 90 dias representam distância muito maior no baseline atual;
- long-form permite medir mecanismo, retenção e watch time.

Shorts continuam possíveis como descoberta, mas não estão liberados como arquétipo produzido porque o projeto ainda não tem mineração audiovisual suficiente dos Shorts do nicho.

### 14.8 Ads e YouTube Promote

Ads estão desativados porque não há orçamento explícito.

Mesmo quando houver orçamento, horas e inscritos gerados diretamente por campanhas não contam para o YPP. O YouTube confirma isso no [guia oficial do Promote](https://support.google.com/youtube/answer/12199105). Somente efeitos orgânicos posteriores, como follow-on views, podem ter valor para a meta.

Portanto, a válvula paga futura deverá medir incremento orgânico, não comprar uma aparência falsa de progresso.

---

## 15. Primeiras métricas pós-publicação

Snapshot mais recente deste relatório:

- captura: `2026-09-04T19:12:01.035029Z`;
- idade: `0,436121 h`;
- status: `PARTIAL_DATA_LAG`;
- decisão: `INSUFFICIENT_DATA`;
- views públicas do vídeo: 2;
- likes: 1;
- comentários: 1;
- processamento: concluído;
- privacidade: pública;
- Analytics privado: sem linha consolidada;
- retenção: sem linha;
- impressões/CTR: adapter ativo, porém primeiro CSV do provedor ainda indisponível;
- próxima observação: `2026-09-05T18:45:51Z`.

Interpretação correta: o vídeo estava novo demais. Dois views, um like e um comentário não autorizam conclusão de qualidade, retenção ou viralidade.

### 15.1 Reach/CTR

A tentativa inicial de pedir `videoThumbnailImpressions` e `videoThumbnailImpressionsClickRate` pelo YouTube Analytics Targeted Queries retornou `400 query not supported`.

A documentação oficial atual informa que reach e CTR de thumbnail estão nos relatórios bulk `channel_reach_basic_a1` e `channel_reach_combined_a1` do YouTube Reporting API. Fontes:

- [Channel Reports — Reach](https://developers.google.com/youtube/reporting/v1/reports/channel_reports);
- [métricas de reach](https://developers.google.com/youtube/reporting/v1/reports/metrics);
- [introdução às APIs Analytics e Reporting](https://developers.google.com/youtube/reporting/).

Correção executada:

- a consulta targeted incompatível deixou de ser repetida;
- o Analytics core registra `EMPTY` sem erro quando ainda não há linha;
- Reporting API ativada no projeto OAuth correto, sem billing;
- jobs `channel_basic_a3` e `channel_reach_basic_a1` criados uma vez e reutilizados;
- reach fica `AWAITING_REPORT`/`null`, não zero, até existir linha própria;
- CTR não é substituído por score do vidIQ;
- CSV é preservado com hash, filtrado por canal/vídeo/data e agregado com CTR ponderado.

---

## 16. Ferramentas, adapters e custo

### 16.1 Ferramentas locais/gratuitas usadas

- FFmpeg/ffprobe;
- OpenCV;
- PySceneDetect;
- faster-whisper local;
- Tesseract/OCR local quando aplicável;
- Pillow/SVG;
- Python;
- SQLite;
- APIs oficiais Google/YouTube em cota gratuita;
- GitHub Pages gratuito para páginas OAuth;
- vidIQ Free apenas como evidência auxiliar;
- processamento local já disponível.

### 16.2 Matriz resumida

| Recurso | Custo | Estado | Fallback/limite |
|---|---:|---|---|
| FFmpeg local | R$ 0,00 | ativo | bloqueia se codec/qualidade falhar |
| ASR faster-whisper | R$ 0,00 | ativo | CPU int8 |
| voz local | R$ 0,00 | ativo | mudança de voz exige novo gate |
| Wikimedia Commons | R$ 0,00 | ativo com filtro | direito por ativo |
| YouTube Data API | R$ 0,00 | ativo | cota gratuita e guard preventivo |
| YouTube Analytics API | R$ 0,00 | ativo | dados podem atrasar |
| YouTube Reporting API | R$ 0,00 | ativa; jobs aguardam primeiro relatório | CSV autenticado + validação local |
| GitHub Pages | R$ 0,00 | ativo | site OAuth público |
| vidIQ Free | R$ 0,00 | `LIMITED` | piso preventivo 25 créditos |
| Ads/Promote | R$ 0,00 gasto | desativado | exige orçamento expresso |

### 16.3 Cotas observadas

Antes do upload, o console mostrou:

- Data API: 5/10.000 unidades consumidas;
- uploads: 0/100;
- billing: não vinculado.

A publicação consumiu cota depois desse snapshot. O saldo atualizado não foi reobservado e, portanto, não é inventado neste relatório.

vidIQ Free:

- total: 150 créditos;
- usados: 55;
- restantes: 95;
- piso preventivo: 25;
- renovação registrada: `2026-10-03T16:42:50Z`;
- add-on: 0;
- custo: R$ 0,00.

### 16.4 Custos não precificados

O requisito de custo zero significa ausência de desembolso técnico adicional. Não foram precificados:

- energia elétrica;
- depreciação do computador;
- tempo humano do proprietário;
- tempo computacional local.

Eles não são apresentados como zero econômico; são `UNAVAILABLE` quando a contabilidade exige valor.

---

## 17. Testes e evidências

### 17.1 Regressão atual

- 251 testes executados;
- 251 aprovados;
- 0 falhas;
- tempo da execução integral mais recente: 152,293 s;
- 114 schemas Draft 2020-12 válidos;
- manifesto congelado da Fase 5: 554 artefatos;
- bytes cobertos: 3.080.086.312;
- hash por arquivo;
- custo de teste externo: R$ 0,00.

### 17.2 Abrangência

Os 41 módulos de teste cobrem:

- motor base;
- padrão-ouro;
- minerador;
- observatório;
- modelagem;
- direção criativa;
- creative-v3;
- assets e QA;
- Channel Readiness;
- OAuth;
- espelho de token;
- refresh;
- escopos;
- readiness;
- console local;
- autostart;
- lock de processo;
- avaliador autônomo;
- release gate;
- publicador private-first;
- idempotência;
- Phase 6 pilot;
- Reporting API bulk;
- fila transacional, lease, retry e dead-letter;
- previsão pré-registrada e avaliação fora da amostra;
- diagnóstico do gargalo e pré-registro de uma variável;
- status executivo e separação produção/publicação;
- observer;
- guard de custo zero;
- vidIQ limitado.

### 17.3 Evidência externa real

Além de testes locais, há evidência de fluxo externo:

- canal consultado pela API oficial;
- OAuth real;
- app em produção;
- refresh real;
- Data API real;
- Analytics API real;
- upload real;
- thumbnail real;
- captions reais;
- vídeo processado;
- promoção real para público;
- watch endpoint HTTP 200;
- oEmbed público;
- snapshot de métricas próprias.

Mocks são usados para caminhos de erro e regressão, mas não são a única evidência de conclusão da Fase 5.

---

## 18. Falhas encontradas e corrigidas

| Falha | Como foi detectada | Correção | Estado |
|---|---|---|---|
| OCR/narrativa fracos | benchmark contra padrão-ouro | minerador 0.2.0 | corrigido |
| observatório ignorava Shorts | reconciliação com catálogo | coleta separada `/videos` e `/shorts` | corrigido |
| creative-v2 curta e repetitiva | auditoria de mercado | nova narrativa e v3 | corrigido |
| v3.1 concentrava ativos | contact sheets e runtime share | v3.2 e quatro gates | corrigido |
| mismatch semântico em takes | revisão take a take | realocação dos takes 14/19 | corrigido |
| freeze final | scan visual | movimento corrigido | corrigido |
| console não carregava MP4 | teste real no navegador | `video.load()` e diagnóstico | corrigido |
| token antigo após reconsent | cadeia de hash | espelho atômico e receipt | corrigido |
| access token expirado no upload | ciclo real | refresh antecipado | corrigido |
| processamento demorou | verificação real | estado retomável | corrigido |
| risco de upload duplicado | retry real | idempotency key e receipt | corrigido |
| observador escolheu token de origem | readiness falhou por hash | token canônico + hash match | corrigido |
| consulta targeted de reach incompatível | erro 400 real | Reporting API ativada + adapter bulk | corrigido; dados aguardam provedor |
| plano não tinha D30 | auditoria deste relatório | janela 720 h adicionada | corrigido |
| lock transitório do OneDrive | `PermissionError` real em troca atômica | temporário único, oito retries limitados e teste dedicado | corrigido |
| hashes divergentes após escrita concorrente | teste integral de integridade | pausa de manutenção, reconstrução e reteste com Gestor reativado | corrigido |
| regressão diária concorria com o loop | ensaio real do `daily.ps1` | manutenção transacional e recuperação em `finally` | corrigido e exercitado |
| verificador quebrava caminho com acento/espaço | primeiro ensaio pós-correção | chamada PowerShell por `EncodedCommand` | corrigido |
| lock novo antecedia console novo | segundo ensaio pós-correção | readiness exige console `LISTENING` no PID novo | corrigido |
| launcher do venv encerrou entre verificações | ensaio integral D-087 | parar launcher antes do filho e tolerar apenas desaparecimento do PID exato | corrigido e retestado |
| lock novo foi classificado como abril por cultura local | probe registrou `09/04` com `started_after_maintenance=false` | cast direto do objeto para `DateTimeOffset` UTC, sem reparse de string | corrigido e retestado |
| gate `PUBLICITY` repetia licença autoral | inspeção do avaliador e dois ativos NASA/Artemis no manifesto | filtro institucional pré-render + triagem facial/metadata independente | corrigido e retestado |
| mudança de elegibilidade colidiu com work order imutável | manutenção real falhou fechada | contrato release `1.1.0`, ID versionado e compatibilidade histórica | corrigido e retestado |
| erro executivo antigo permaneceu ao lado de status válido | inspeção do estado atual | arquivamento byte a byte por SHA-256 e limpeza somente do alerta corrente | corrigido e retestado |

---

## 19. Lacunas reais no momento

### 19.1 Críticas para a Fase 6

1. Analytics do canário ainda não consolidou dados suficientes.
2. O primeiro CSV do YouTube Reporting API ainda não foi gerado pelo provedor; adapter e jobs estão ativos.
3. O Earn tab não possui API pública equivalente no fluxo atual; os contadores qualificados precisam de captura oficial versionada.
4. Só existe um canário publicado no pipeline atual.
5. O FormatPack continua `LIMITED`.
6. O executável mantém nome histórico `central_manager_phase5.py`, embora o runtime já coordene a Fase 6; renomear sem necessidade criaria risco operacional.
7. A fila transacional está ativa, mas o lote ainda tem somente um checkpoint real e um canário.
8. A prediction está corretamente retida; calibração fora da amostra ainda não possui três janelas próprias comparáveis.
9. O catálogo legado ainda precisa de revisão integral de direitos/originalidade antes do pedido ao YPP.

### 19.2 Externas

1. Distribuição do YouTube não é controlável pelo projeto.
2. Validação de views e horas ocorre na plataforma.
3. Aprovação do YPP depende da revisão do YouTube.
4. AdSense e requisitos do Earn tab dependem do estado da conta no Studio.
5. Ads não podem ser iniciados sem orçamento expresso.

### 19.3 Capacidade criativa

- 290 formatos continuam apenas `CATALOGED`;
- nenhum formato é `PRODUCTION_READY`;
- expansão para Shorts, anime, 3D, UGC ou outros formatos exige protótipo, validação e pipeline próprio;
- não existe um prompt universal capaz de produzir todos os estilos com qualidade.

---

## 20. Próximas ações exatas

### Até o checkpoint de 24 horas

1. manter o vídeo público e monitorado;
2. não alterar título/thumbnail sem dado ou incidente;
3. preparar tema, tese, roteiro e assets do vídeo 2 em paralelo;
4. observar a chegada do primeiro CSV bulk e validar a linha própria;
5. atualizar o ledger dos contadores YPP qualificados;
6. manter OAuth e Gestor saudáveis;
7. preservar custo técnico em R$ 0,00.

### No checkpoint de 24 horas

Coletar:

- views;
- engaged views quando disponível;
- minutos assistidos;
- AVD;
- porcentagem média assistida;
- retenção em 30 s;
- inscritos ganhos/perdidos;
- likes, comentários e shares;
- impressões e CTR quando o relatório bulk existir;
- fontes de tráfego quando suportadas;
- incidentes de política/direitos;
- progresso oficial do Earn tab.

Classificar o gargalo:

- **poucas impressões:** tema/distribuição/autoridade do canal;
- **impressões com CTR fraco:** título/thumbnail/promessa;
- **CTR adequado e retenção fraca:** hook, ritmo ou mismatch;
- **retenção adequada e baixa conversão:** proposta do canal/CTA/série;
- **bom vídeo e canal travado:** catálogo/Home/política/cadência.

### Liberação do vídeo 2

Exige:

- snapshot de 24 h;
- nenhum incidente;
- hipótese de mudança registrada;
- release automático novo;
- direitos válidos;
- ChannelDNA;
- FormatPack dentro do limite;
- OAuth/cota/custo `PASS`;
- publicação private-first.

### Vídeo 3

Repete o processo e dispara a revisão amostral obrigatória do lote `LIMITED`.

### Depois do lote

- decidir se o FormatPack permanece `LIMITED`, volta para correção ou pode entrar em validação superior;
- comparar previsões com resultados;
- calibrar erro e cobertura;
- concluir o gate da Fase 6;
- iniciar Fase 7 somente com evidência suficiente.

---

## 21. Como acompanhar, pausar e recuperar

### Estado do Gestor

```powershell
Get-Content 'output/runtime/gestor-central/status.json' -Raw
Get-Content 'output/runtime/gestor-central/oauth-session-health.json' -Raw
Get-Content 'output/operations/phase6/observer-status.json' -Raw
```

### Verificar tarefa do Windows

```powershell
Get-ScheduledTask -TaskName 'HeroEngine-Phase5-CentralManager'
Get-Content 'output/runtime/gestor-central/manager.pid' -Raw
```

### Pausar

```powershell
New-Item 'output/runtime/gestor-central/PAUSE' -ItemType File -Force
```

### Retomar

```powershell
Remove-Item 'output/runtime/gestor-central/PAUSE'
Start-ScheduledTask -TaskName 'HeroEngine-Phase5-CentralManager'
```

### Executar observação manual autenticada

```powershell
.\.venv\Scripts\python.exe -m hero_engine.phase6_pilot --collect
```

O comando resolve o token externo canônico pelo watcher; ele não imprime credenciais.

### Regressão

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
```

### Recuperação

Em falha:

1. preservar receipts e artefatos;
2. ler `status.json` e logs;
3. verificar PID/lock/tarefa;
4. corrigir a causa;
5. reexecutar testes;
6. reconstruir readiness/release quando o token mudou;
7. retomar pelo mesmo idempotency key;
8. nunca fazer novo upload se o receipt já contém video ID válido.

---

## 22. Arquivos de evidência principais

### Governança

- `AGENTS.md`
- `PLANS.md`
- `docs/STATE.md`
- `docs/DECISIONS.md`
- `docs/00_MASTER_SPEC.md`
- `docs/01_EXECUTION_PROTOCOL.md`
- `docs/07_PHASES_AND_GATES.md`
- `docs/10_CONTINUOUS_INTELLIGENCE_MASTER.md`
- `docs/11_GESTOR_CENTRAL_AUTONOMO_MASTER.md`
- `docs/12_ACQUISITION_ACCELERATOR_MASTER.md`
- `docs/13_ADAPTIVE_VIRAL_EDITORIAL_ENGINE.md`
- `docs/15_CREATIVE_DIRECTION_MASTER.md`
- `docs/16_ZERO_COST_OPERATION_MASTER.md`

### Fases

- `docs/PHASE_0_AUDIT.md`
- `docs/PHASE_1_REPORT.md`
- `docs/PHASE_2_IMPROVEMENT_REPORT.md`
- `docs/PHASE_3_REPORT.md`
- `docs/PHASE_4_REPORT.md`
- `docs/PHASE_5_REPORT.md`
- `docs/PHASE_5_CREATIVE_V3_REPORT.md`

### Modelo e canal

- `output/modeling/phase4/channel-model-v1/channel_model.json`
- `output/audits/channel/heroverse/channel-readiness-audit.json`
- `output/audits/channel/heroverse/live-change-receipt.json`
- `output/brand/channel/heroverse-v2/brand-asset-pack.json`

### Produção

- `output/production/phase5/pilot-001/creative-v3/narrative_script.json`
- `output/production/phase5/pilot-001/creative-v3/take_plan.json`
- `output/production/phase5/pilot-001/creative-v3/channel_style_bible.json`
- `output/production/phase5/pilot-001/creative-v3/asset_manifest.allocated.json`
- `output/production/phase5/pilot-001/creative-v3/qa/technical_measurements.json`
- `output/production/phase5/pilot-001/creative-v3/qa/creative_quality_gate_report.json`
- `output/production/phase5/pilot-001/creative-v3/autonomous-review/autonomous_quality_evaluation.json`
- `output/production/phase5/pilot-001/creative-v3/publication_package.json`
- `output/production/phase5/pilot-001/creative-v3/release_gate.json`
- `output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json`

### Integração

- `output/integrations/youtube/heroverse/connection-receipt.json`
- `output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json`
- `output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json`
- `output/integrations/youtube/heroverse/operational-readiness.json`
- `output/runtime/gestor-central/oauth-session-health.json`

### Operação Fase 6

- `output/operations/phase6/pilot-plan.json`
- `output/operations/phase6/metrics/iK_5edYQtx8/latest.json`
- `output/operations/phase6/observer-status.json`
- `output/operations/phase6/reporting/job-registry.json`
- `output/operations/phase6/runtime/queue-snapshot.json`
- `output/operations/phase6/intelligence/predictions/latest.json`
- `output/operations/phase6/intelligence/diagnoses/latest.json`
- `output/operations/phase6/intelligence/experiments/latest.json`
- `output/operations/phase6/production/format-scope-receipt.json`
- `output/operations/phase6/production/latest-order.json`
- `output/operations/phase6/production/executor-status.json`
- `output/operations/phase6/release/latest-work-order.json`
- `output/operations/phase6/release/preparer-status.json`
- `output/operations/phase6/media-executor-status.json`
- `output/operations/phase6/quality-executor-status.json`
- `output/operations/phase6/publication-controller-status.json`
- `output/operations/phase6/incidents/format-scope-schema-migration-20260904.json`
- `output/operations/phase6/executive-status.json`
- `output/operations/phase6/shared_source_evolution_receipt.json`

### Código central

- `hero_engine/mining/`
- `hero_engine/observatory/`
- `hero_engine/modeling_phase4.py`
- `hero_engine/creative_direction.py`
- `hero_engine/phase5_autonomous_quality.py`
- `hero_engine/phase5_release_gate.py`
- `hero_engine/phase5_youtube_publisher.py`
- `hero_engine/central_manager_phase5.py`
- `hero_engine/phase6_pilot.py`
- `hero_engine/phase6_intelligence.py`
- `hero_engine/phase6_production.py`
- `hero_engine/phase6_assets.py`
- `hero_engine/phase6_release.py`
- `hero_engine/phase6_media.py`
- `hero_engine/phase6_quality.py`
- `hero_engine/phase6_publication.py`
- `hero_engine/phase6_package_treatment.py`
- `hero_engine/phase6_prediction_runtime.py`
- `hero_engine/phase6_learning_runtime.py`
- `hero_engine/phase6_reporting.py`
- `hero_engine/phase6_acceptance.py`
- `hero_engine/phase6_transition.py`
- `hero_engine/queue_phase6.py`
- `hero_engine/youtube_reporting_phase6.py`

Inventário de implementação no fechamento:

- 80 arquivos Python no motor;
- 41 módulos de teste;
- 117 schemas JSON;
- 17 arquivos de configuração;
- 16 scripts operacionais Python/PowerShell.

---

## 23. O que está pronto e o que não está

### Pronto e comprovado

- mineração local;
- padrão-ouro;
- observatório público;
- ChannelDNA;
- arquétipo long-form;
- direção criativa do formato atual;
- produção take a take;
- QA automático por release;
- direitos do canário;
- captions;
- thumbnail;
- integração do canal;
- OAuth durável;
- refresh automático;
- private-first;
- publicação pública;
- idempotência do canário;
- Gestor em autostart;
- primeiro snapshot próprio;
- observador da janela de 24 h;
- fila transacional com lease/retry/dead-letter;
- Reporting API bulk com jobs idempotentes;
- diagnóstico automático versionado e seleção de uma variável;
- pré-registro automático fail-closed;
- receipt imutável de escopo `LIMITED` com nove gates;
- ordem de tratamento imutável com 13 gates de entrada;
- executor transacional que compila embalagem no próprio canário ou pré-produção take a take do Vídeo 2;
- release work order e alocação hash-pinned de ativos;
- filtro de risco institucional antes do render e gate `PUBLICITY` independente, com YuNet local de hash fixo;
- síntese local, captions e render FFmpeg transacional;
- avaliador independente da Fase 6 com 18 gates e 19 defeitos técnicos;
- controlador de publicação private-first retomável com receipt por efeito externo;
- executor transacional de tratamento do título-thumbnail no canário, com 17 gates, agenda no dia do Pacífico, verificação API/CDN e rollback duplo;
- aprendizado de embalagem por linhas diárias adjacentes do Reporting API, sem pseudobaseline cumulativo;
- forecast D30 sem imputação de YPP ou cadência;
- custo técnico R$ 0,00.

### Ainda em construção

- execução live da cadeia de síntese, render, qualidade e publicação sobre o tratamento que será escolhido após o snapshot de 24 h; os módulos e testes existem, mas o candidato real ainda não foi autorizado;
- execução live do tratamento de embalagem, somente se o diagnóstico D1 selecionar essa variável; o executor está ativo em `WAITING_FOR_PREREGISTRATION` e não fez escrita prematura;
- operação de lote completa da Fase 6;
- primeiro reach/CTR real via Reporting API bulk;
- contador YPP oficial versionado diariamente;
- vídeos 2 e 3;
- aprendizado pós-publicação;
- previsão calibrada;
- FormatPack `PRODUCTION_READY`;
- auditoria integral do catálogo legado;
- Fases 7 e 8;
- versão comercial multi-canal.

---

## 24. Conclusão factual

A corrida de 30 dias começou de verdade porque há um vídeo público, processado, com thumbnail e captions, no canal correto e com receipt auditável. A operação não está mais limitada a documentação ou dry-run.

O sistema atual consegue produzir, avaliar e publicar o formato long-form do HeroVerse somente dentro do contrato `LIMITED`, com custo técnico zero e sem revisão manual obrigatória em cada vídeo. O Gestor mantém OAuth saudável, observa o release e aguarda a janela de 24 horas para a primeira decisão comparável. Assim que existir um snapshot elegível, o motor possui o caminho testado para diagnosticar um único gargalo, pré-registrar uma única variável, emitir autorização literal do escopo, gerar uma ordem imutável, compilar o tratamento, excluir risco institucional conhecido, preparar o release, renderizar localmente, executar os 18 gates e 19 controles de defeito — incluindo `PUBLICITY` independente de licença autoral — e, somente se tudo passar, operar o pipeline private-first. Embalagem atua no próprio canário sem alterar a timeline; ângulo, hook ou narrativa geram o Vídeo 2. O estado `WAITING` atual impede render e publicação antes da evidência em vez de fingir prontidão do candidato.

O estado ainda não permite afirmar que a monetização será alcançada, porque os contadores qualificados, a retenção, o CTR e a resposta de audiência do canário ainda não existem em volume suficiente. O compromisso operacional, entretanto, está definido: medir a distância até a meta, eliminar o gargalo dominante e repetir apenas o que passar nos gates e mostrar evidência.

**Próximo evento automático obrigatório:** `2026-09-05T18:45:51Z` — snapshot de 24 horas do vídeo `iK_5edYQtx8`.

---

## 25. Atualização operacional D-089 — meta D30 e tratamento automático de embalagem

A meta de 30 dias é tratada como restrição de prioridade e tempo, não como garantia fabricada. O Gestor controla o que é executável: observar no instante correto, escolher o gargalo por dados próprios, alterar uma variável por vez, produzir somente dentro do FormatPack `LIMITED`, reprovar falhas críticas, publicar artefatos aprovados e aplicar o aprendizado no próximo ciclo. A decisão do YPP e a resposta do público permanecem fatores externos.

O ramo que faltava para embalagem está implementado. Se o checkpoint selecionar `TITLE_THUMBNAIL_PROMISE`, o fluxo é:

1. validar identidade exata entre snapshot, diagnóstico, protocolo, ordem e release;
2. escolher o par por mecanismos criativos objetivos, não pelo nome da variante;
3. renderizar localmente o JPEG 1280×720 a partir de ativo próprio;
4. exigir 17 gates críticos e congelar hashes;
5. reservar 100 unidades gratuitas de cota, sem billing;
6. aguardar o limite do dia do Pacífico, com tolerância máxima de 180 segundos e atraso real registrado;
7. preservar snippet e thumbnail anteriores;
8. executar `videos.update(part=snippet)` e `thumbnails.set` no canário exato;
9. confirmar vídeo, canal, visibilidade e título pela API, além da thumbnail entregue pela CDN;
10. reverter título e thumbnail se a confirmação falhar;
11. congelar o pacote por um dia completo;
12. comparar somente o dia anterior e o dia do tratamento no Reporting API, usando impressões como tamanho amostral do CTR;
13. registrar `SUPPORTED`, `REJECTED`, `INCONCLUSIVE` ou `INVALID`, com incerteza e sem promover regra global.

Evidência de engenharia desta atualização:

| Controle | Resultado |
|---|---|
| Regressão integral | `245/245 PASS` |
| Tempo da regressão | `152,584 s` |
| Schemas | `111/111 válidos` |
| Compilação Python | `PASS` |
| Estado do executor de embalagem | `WAITING_FOR_PREREGISTRATION` |
| Escrita pública prematura | `não ocorreu` |
| Tarefa Windows | `Running` |
| PID/lock/console | `19832 / coincidentes` |
| Duplicata | `bloqueada, código 73` |
| stderr | `0 bytes` |
| Custo técnico | `R$ 0,00` |
| Mídia | `R$ 0,00` |

O próximo evento permanece `2026-09-05T18:45:51Z`. Até esse instante, preservar a embalagem atual é parte do experimento, não inatividade. No checkpoint, o Gestor deverá coletar as métricas proprietárias, produzir um diagnóstico de uma variável e encaminhar automaticamente um dos dois caminhos reais: tratamento reversível do canário ou produção completa do Vídeo 2.

---

## 26. Atualização operacional D-090 — aceite executável e prova persistente da regressão

O aceite original do Gestor Central era um documento estático com GC-01–GC-22 em `NOT_RUN`. Isso foi corrigido sem transformar teste em resultado de audiência. O novo auditor atribui a cada critério uma classe mínima (`FIXTURE`, `LIVE` ou fase posterior), valida os artefatos e impede que `PASS_FIXTURE` satisfaça um requisito vivo.

Estado verificável:

| Classe | Quantidade |
|---|---:|
| `PASS_LIVE` | 10 |
| `PASS_FIXTURE` | 5 |
| `WAITING_REAL_EVIDENCE` | 3 |
| `NOT_APPLICABLE_CURRENT_PHASE` | 4 |
| `FAIL` | 0 |
| `MISSING_EVIDENCE` | 0 |

Os três blockers da Fase 6 são objetivos: GC-01 exige o ciclo real até nova medição; GC-11 exige o tratamento real pré-registrado; GC-19 exige o outcome real da previsão. GC-14 permanece obrigatório na Fase 7, onde o aprendizado poderá ser aplicado a uma produção posterior e medido novamente; mantê-lo na Fase 6 criaria dependência circular.

A manutenção também passou a persistir a regressão. O receipt `daily-maintenance-20260905T0134413537349Z` prova `247/247 PASS` em 133,498 s, logs exatos, manifesto de 554 itens/3.080.086.312 bytes e custo zero. O primeiro ensaio expôs uma dependência derivada desatualizada entre o scope OAuth e o release gate; o Gestor foi recuperado em `finally`, a ordem de reconciliação foi corrigida e a segunda execução integral passou.

Arquivos de leitura direta:

- `output/operations/phase6/PHASE6_ACCEPTANCE.md`;
- `output/operations/phase6/acceptance-report.json`;
- `output/runtime/gestor-central/daily-maintenance-receipt.json`;
- `output/runtime/gestor-central/autostart-verification.json`.

---

## 27. Atualização operacional D-091 — avaliação temporal e imutável das previsões

Havia uma lacuna operacional concreta: a função que pontuava previsões existia e passava nos testes, mas não havia um executor que aguardasse o horizonte real, coletasse o outcome e produzisse o receipt. Isso foi corrigido sem inventar uma previsão para uma amostra insuficiente.

O fluxo agora é:

1. o `PredictionRecord` permanece imutável e anterior ao resultado;
2. `phase6_prediction_runtime.py` cria um job SQLite com a mesma identidade e `available_at=horizon.ends_at`;
3. antes do horizonte, a fila não permite claim e o estado é `WAITING_FOR_HORIZON`;
4. no horizonte, o Gestor usa o token externo já validado e consulta o canário exato pela API oficial;
5. o snapshot é preso ao checkpoint antes do cálculo, permitindo retry sem trocar silenciosamente o outcome;
6. a avaliação é validada por schema, gravada de forma imutável e vinculada ao job concluído;
7. forecast calibrado compara a mediana robusta ao baseline simples de último outcome;
8. superioridade requer erro menor fora da amostra; igualdade ou piora não autorizam alegar previsibilidade;
9. forecast retido por amostra insuficiente preserva o outcome como `NOT_EVALUABLE_WITHHELD`, prova a rejeição disciplinada do modelo e continua sem afirmar capacidade preditiva.

O gate de aceite também deixou de depender exclusivamente do arquivo mutável `latest`. GC-08 referencia agora o snapshot imutável `own-performance-iK_5edYQtx8-20260904T191201Z.json`, que prova que valores privados ausentes permaneceram nulos e bloquearam decisão. A chegada de métricas futuras não apagará essa prova. GC-10 aceita registros pré-resultados temporalmente válidos sem exigir que o estado futuro continue retido. GC-19 procura avaliações imutáveis reais.

Existem dois eventos automáticos diferentes e o painel passa a ordenar os timestamps, em vez de escolher apenas o primeiro campo preenchido:

| Ordem | Evento UTC | Evento BRT | Estado |
|---:|---|---|---|
| 1 | `2026-09-05T18:45:51Z` | `2026-09-05 15:45:51` | checkpoint próprio D1 |
| 2 | `2026-09-05T19:12:01.035029Z` | `2026-09-05 16:12:01` | outcome da previsão inicial |

Estado real no fechamento:

| Controle | Resultado |
|---|---|
| Prediction runtime | `WAITING_FOR_HORIZON` |
| Prediction job | `job-21d66f6c4d850aae9fdb364b` / `PENDING` |
| Forecast | `WITHHELD_INSUFFICIENT_CALIBRATION` |
| Fila | `HEALTHY`, 2 jobs temporais pendentes, zero dead-letter |
| Próximo checkpoint executivo | `2026-09-05T18:45:51Z` |
| Atenções executivas | 0 |
| Regressão integral | `251/251 PASS` em 152,293 s |
| Schemas | `114/114` Draft 2020-12 |
| Compileall | `PASS` |
| Manifesto | 554 itens / 3.080.086.312 bytes |
| Receipt de manutenção | `daily-maintenance-20260905T0159553275463Z` |
| Tarefa/PID | `Running` / `9552` |
| Lock/console/duplicata/stderr | coincidentes / código 73 / 0 bytes |
| Custo técnico e mídia | `R$ 0,00` / `R$ 0,00` |

A Fase 6 continua corretamente `IN_PROGRESS`. Os três gates vivos próprios da fase ainda dependem dos outcomes do piloto: ciclo real, experimento pré-registrado e avaliação da previsão. GC-14, aplicação futura, continua obrigatório na Fase 7.

A automação Codex `HERO Engine — rotina diária` também foi atualizada no lugar, preservando o mesmo ID e a execução diária às 16h BRT. Ela agora verifica os 13 gates atuais, `prediction-runtime.json`, avaliações imutáveis, `acceptance-report.json` e a ordem D1 -> horizonte. Nenhuma automação duplicada foi criada.

---

## 28. Atualização operacional D-092 — controlador automático da transição 6→7

A auditoria de fase encontrou uma inconsistência real: GC-14 estava bloqueando a Fase 6, embora dependa da Rule Registry, da aplicação do aprendizado em uma produção posterior e da segunda medição — capacidades que o contrato coloca na Fase 7. A correção não elimina GC-14 nem reduz sua classe de evidência. Ela restaura a ordem causal: primeiro concluir experimento, ciclo e outcome da previsão da Fase 6; depois aplicar o aprendizado e medir novamente na Fase 7.

O novo `phase6_transition.py` executa uma verificação independente antes do avanço. Ele exige o schema integral do aceite, ordem exata GC-01–GC-22, contagens recompostas, conjunto real de aprovados, blockers consistentes e suficiência por classe `FIXTURE/LIVE`. Um documento que apenas declare `APPROVED`, mas contenha um requisito insuficiente, produz `BLOCKED` e não cria receipt.

Quando — e somente quando — os requisitos da Fase 6 atingirem a evidência mínima, o controlador:

1. congela os bytes exatos do aceite em `acceptance-archive`;
2. calcula e prende o SHA-256;
3. cria um único receipt imutável 6→7 sob a autorização D-047;
4. conserva os mesmos bytes em reexecução idempotente;
5. autoriza apenas o início da Fase 7, sem afirmar resultado de audiência ou YPP.

Estado observado antes do gate:

| Controle | Resultado |
|---|---|
| Transição | `WAITING_FOR_PHASE6_GATE` |
| Receipt 6→7 | ausente, como exigido |
| Blockers da Fase 6 | `GC-01`, `GC-11`, `GC-19` |
| Aceite | 10 `PASS_LIVE`; 5 `PASS_FIXTURE`; 3 `WAITING`; 4 posteriores; 0 `FAIL/MISSING` |
| Fase 7 | `NOT_STARTED` |
| Custo técnico | `R$ 0,00` |
| Regressão integral | `255/255 PASS` em `144,712 s` |
| Schemas | `116/116` válidos |
| Compileall Python | `PASS` |
| Manifesto preservado | `554` itens / `3.080.086.312` bytes |
| Receipt da manutenção | `daily-maintenance-20260905T0217562339914Z` |
| Gestor após recovery | tarefa `Running`, PID `15952`, lock/console coincidentes |
| Singleton/stderr | duplicata bloqueada em `73`; `0` bytes |
| Fila | `HEALTHY`, 2 `PENDING`, 0 `DEAD_LETTER` |
| Painel | `ACTIVE_OBSERVING`, 0 atenções |

Os testes direcionados cobrem espera sem receipt, criação imutável/idempotente e bloqueio de aceite internamente contraditório. O Gestor residente e a manutenção diária chamam o controlador após materializar o aceite e atualizam o painel no mesmo ciclo. A manutenção transacional integral terminou com código 0 e recuperou a cadeia operacional sem intervenção.

---

## 29. Atualização operacional D-093 — continuidade elétrica e recovery OAuth

A verificação do computador encontrou um risco capaz de invalidar a automação: embora a tela já estivesse em `Nunca`, o plano Equilibrado suspendia após 600 segundos e hibernava após 10.800 segundos quando alimentado por bateria. Isso foi corrigido no sistema e transformado em capacidade reproduzível, não apenas ajuste manual.

`ensure_power_continuity.ps1` agora aplica e consulta os valores reais do `powercfg`, independentemente do idioma de exibição do Windows. O receipt registra o plano ativo e os seis valores AC/DC. O runner o executa a cada logon, a manutenção o reaplica antes da parada e o verificador só aceita `operational_ready=true` quando display, standby e hibernação estão todos em zero.

O ensaio expôs outra falha concreta. Como o runner mudou, seu receipt ficou obsoleto e a manutenção re-registrou a tarefa. Nessa primeira tentativa, o instalador escolheu o fallback LocalAppData, onde não havia token, em vez do destino externo canônico já validado. O bootstrap registrou `token=False` e exit 1; o recovery recusou corretamente o PID antigo morto. O token real permaneceu intacto fora do workspace e nenhuma ação pública ocorreu.

A correção faz installer, runner e manutenção resolverem `destination_path` no receipt do watcher OAuth, confirmarem que o arquivo existe e somente então reconfigurarem a tarefa. O incidente foi preservado em `output/runtime/gestor-central/incidents/power-and-token-recovery-20260905.json`.

Prova final:

| Controle | Resultado |
|---|---|
| Manutenção | código `0` |
| Receipt | `daily-maintenance-20260905T0238557983597Z` |
| Regressão | `256/256 PASS` em `148,539 s` |
| Schemas | `117/117` válidos |
| Compileall | `PASS` |
| Energia | display/standby/hibernação, AC/DC: `6/6 PASS` |
| Tarefa | `Running` |
| PID | `10316` |
| Lock/console | mesmo PID |
| Duplicata/stderr | `73` / `0 bytes` |
| Fila | `HEALTHY`, 2 pendentes, zero dead-letter |
| Próximo checkpoint | `2026-09-05T18:45:51Z` |
| Custo técnico/mídia | `R$ 0,00 / R$ 0,00` |

---

## 30. Atualização operacional D-094 — capacidade local comprovada antes da fila

O caminho de produção possuía uma lacuna operacional: um receipt de inputs válido permitia criar o job de mídia, mas disco, FFmpeg, FFprobe, modelos, fonte, escrita e spans só seriam descobertos durante o lease. Isso não atende ao padrão fail-closed.

O novo `hero_engine/production_capacity.py` executa antes do `enqueue` e registra:

1. versão realmente executada de FFmpeg e FFprobe;
2. existência e tamanho de Kokoro, banco de vozes e fonte;
3. round-trip de escrita e leitura no diretório de produção e no temporário;
4. existência de cada arquivo-fonte referenciado pelo TakePlan;
5. suficiência de cada intervalo de origem para seu slot;
6. continuidade integral da timeline;
7. duração frame-exact a 30 fps;
8. estimativa versionada de pico adicional;
9. reserva mínima de 5 GiB depois da produção;
10. headroom ou déficit em bytes por volume.

A estimativa `phase6-standard-storage-v1` deriva da receita real: intermediários CRF 18 tratados conservadoramente a 60 Mb/s, cópia silenciosa simultânea, final limitado a 12 Mb/s + 256 kb/s, PCM16 nas taxas/canais configurados, thumbnails/metadados, 25% de contingência e 5 GiB intactos ao final. O valor final do Vídeo 2 só pode ser calculado quando o D1 autorizar e materializar o TakePlan exato.

Estado observado:

| Controle | Resultado |
|---|---|
| Estado do preflight | `WAITING_PLAN` |
| Ferramentas | FFmpeg/FFprobe `PASS` |
| Modelos/fonte | `PASS` |
| Output/temporário graváveis | `PASS` |
| Espaço livre | `27.632.054.272 bytes` |
| Reserva-base | `5.368.709.120 bytes` |
| Margem-base | `22.263.345.152 bytes` |
| TakePlan específico | aguardando D1, sem falsa aprovação |
| Job de mídia | não criado |
| Efeito público/gasto | nenhum / `R$ 0,00` |

O executor agora retorna `BLOCKED/NOT_CREATED` antes da fila se qualquer controle falhar. O painel expõe o receipt e os valores em bytes. Os testes cobrem ambiente suficiente, disco insuficiente, FFmpeg ausente, origem com span curto e prova de que preflight reprovado não cria SQLite/job.

Prova final:

| Verificação | Resultado |
|---|---|
| Receipt da manutenção | `daily-maintenance-20260905T0304355985727Z` |
| Regressão | `261/261 PASS` em `147,902 s` |
| Schemas | `118/118` Draft 2020-12 |
| Compileall | `PASS` |
| Manifesto preservado | `554` itens / `3.080.086.312` bytes |
| Tarefa/PID | `Running` / `1804` |
| Lock/console | `HELD` / `LISTENING`, mesmo PID |
| Singleton/stderr | duplicata `73` / `0 bytes` |
| Energia/prontidão | `PASS` / `operational_ready=true` |
| Fila/painel | `HEALTHY` / `ACTIVE_OBSERVING`, zero atenções |
| Próximo checkpoint | `2026-09-05T18:45:51Z` |

A Fase 6 permanece `IN_PROGRESS`. Os blockers honestos continuam GC-01, GC-11 e GC-19, todos dependentes dos outcomes vivos do piloto; esta correção elimina risco técnico controlável sem fingir que o dado de audiência já chegou.

---

## 31. Atualização operacional D-095 — biblioteca residente, íntegra e pronta para seleção

A preparação para o D1 encontrou um risco concreto: a biblioteca de ativos está em uma árvore sincronizada pelo OneDrive. Um arquivo listado no manifesto pode possuir nome e metadados sem garantir que o conteúdo completo esteja residente, decodificável e idêntico ao que recebeu aprovação de direitos. Isso produziria uma falha tardia justamente depois de o diagnóstico liberar a produção.

Foi implementado `hero_engine/phase6_asset_residency.py`. Antes da produção, ele deriva o conjunto verdadeiramente elegível usando todos os critérios vigentes: `production_eligible`, uso comercial, direito permitido, quality gate aprovado e ausência de `metadata_publicity_risks`. Os dois ativos NASA/Artemis continuam fora do caminho automático por risco de publicidade institucional; domínio público não foi tratado como autorização de endorsement.

Para cada ativo elegível, o Gestor agora:

1. lê o arquivo inteiro e recalcula SHA-256;
2. verifica flags Windows `OFFLINE`, `RECALL_ON_OPEN` e `RECALL_ON_DATA_ACCESS`;
3. executa FFprobe e comprova decodificação e duração;
4. abre e valida o receipt de direitos correspondente;
5. cruza identidade, hash e status comercial;
6. soma bytes e duração segura realmente disponíveis;
7. persiste receipt imutável e atualiza o painel executivo.

A auditoria viva `asset-residency-phase6-c756ec467de732712dc0bb76` apresentou:

| Controle | Resultado |
|---|---|
| Estado | `PASS` |
| Ativos elegíveis | `29` |
| Ativos verificados | `29/29` |
| Ativos bloqueados | `0` |
| Conteúdo integral lido | `783.561.975 bytes` |
| Capacidade segura | `1.499.877 ms` (`24 min 59,877 s`) |
| Flags offline/recall | nenhuma |
| Hash/direitos/decode | `PASS` em todos os elegíveis |
| Custo técnico/mídia | `R$ 0,00 / R$ 0,00` |

Isso não autoriza sozinho o Vídeo 2. Depois do checkpoint D1, o TakePlan exato ainda precisa ser compilado. O preflight de capacidade recalcula o hash de cada fonte selecionada e cruza caminho, intervalo, duração, direitos e `asset_allocation.json`; `CONTENT_HASH_MISMATCH`, span insuficiente ou divergência no ledger bloqueiam antes da criação do job.

Estado corrente do preflight específico:

| Controle | Resultado |
|---|---|
| Estado | `WAITING_PLAN` |
| FFmpeg/FFprobe | `PASS` |
| Kokoro/vozes/fonte | `PASS` |
| Output/temporário | graváveis |
| Espaço livre | `27.358.842.880 bytes` |
| Reserva-base | `5.368.709.120 bytes` |
| Margem-base | `21.990.133.760 bytes` |
| TakePlan/job | ainda não criado, corretamente |

Prova final D-095:

| Verificação | Resultado |
|---|---|
| Receipt da manutenção | `daily-maintenance-20260905T0324533781166Z` |
| Regressão | `264/264 PASS` em `139,022 s` |
| Schemas | `119/119` Draft 2020-12 |
| Compileall | `PASS` |
| Manifesto preservado | `554` itens / `3.080.086.312` bytes |
| Tarefa/PID | `Running` / `15120` |
| Lock/console | `HELD` / `LISTENING`, mesmo PID |
| Singleton/stderr | duplicata `73` / `0 bytes` |
| Energia/prontidão | `PASS` / `operational_ready=true` |
| Fila | `HEALTHY`, 2 pendentes, 0 dead-letter |
| Painel | `ACTIVE_OBSERVING`, zero atenções |

Os dois eventos vivos continuam enfileirados em ordem: D1 em `2026-09-05T18:45:51Z` e outcome da previsão em `2026-09-05T19:12:01.035029Z`. A Fase 6 permanece `IN_PROGRESS`, com GC-01, GC-11 e GC-19 aguardando evidência real. Nenhuma publicação ou despesa foi antecipada.

---

## 32. Atualização operacional D-096 — D1 acelerado sem inventar diagnóstico criativo

A auditoria pré-D1 encontrou uma dependência excessiva: a decisão exigia retenção de 30 segundos mesmo quando a única conclusão segura seria que o vídeo ainda possuía amostra pequena. Métricas de retenção e reach podem atrasar; esperar por elas para reconhecer menos de 30 views desperdiçaria a janela, enquanto usá-las como zero fabricaria uma conclusão.

O diagnosis 1.1 agora separa três classes:

| Classe | Condição | Ação permitida |
|---|---|---|
| `FULL_CREATIVE_METRICS` | >=24 h e métricas próprias completas | diagnosticar embalagem, hook, narrativa ou replicação conforme o gate |
| `DISTRIBUTION_ONLY_EXACT_COUNT` | >=24 h, contador oficial exato abaixo de 30 e métricas criativas atrasadas | somente `TOPIC_ANGLE`, confiança baixa |
| `NOT_ELIGIBLE` | antes de 24 h, fonte inválida, contador >=30 sem métricas criativas ou evidência incompleta | esperar/bloquear |

O fallback registra separadamente views privadas, views públicas, valor usado e fonte. Ele nunca converte `null` em zero. A ordem e o receipt de escopo não confiam somente no diagnosis: voltam ao snapshot bruto e confirmam idade, channel/video ID, status da API, valor idêntico, piso de 30, snapshot ID, `DISTRIBUTION_SAMPLE`, `TOPIC_ANGLE` e `production_may_start=true`.

Foram exercitados dois limites opostos:

- 12 views públicas exatas, >=24 h, retenção ausente: diagnosis `DISTRIBUTION_SAMPLE`, tratamento `TOPIC_ANGLE`, protocolo pré-registrado e escopo/ordem autorizáveis;
- 100 views públicas, >=24 h, retenção ausente: `WAITING_FOR_ELIGIBLE_BASELINE`, nenhuma variável e nenhuma produção.

As métricas completas existentes continuam selecionando exatamente um dos quatro caminhos anteriores. Assim, a mudança elimina espera desnecessária sem permitir que distribuição baixa seja chamada de problema de hook, thumbnail ou roteiro.

A primeira manutenção integral expôs uma colisão legítima: o conteúdo do scope overlay havia mudado, mas seu receipt ainda usava identidade 1.0. O sistema recusou a alteração, saiu com erro, não criou job e recuperou o Gestor no PID 2300. A correção preservou o 1.0 byte a byte e criou o overlay 1.1, incluindo a versão nas identidades de scope e ordem. O incidente está em `output/operations/phase6/incidents/distribution-lag-scope-version-recovery-20260905.json`.

Prova final:

| Verificação | Resultado |
|---|---|
| Diagnóstico corrente | 1.1 / `NOT_ELIGIBLE` antes do D1 |
| Scope corrente | 1.1 / `WAITING` |
| Ordem corrente | `WAITING_FOR_ELIGIBLE_BASELINE` |
| Testes direcionados finais | `28/28 PASS` |
| Regressão integral | `267/267 PASS` em `158,116 s` |
| Schemas | `119/119` Draft 2020-12 |
| Compileall | `PASS` |
| Receipt | `daily-maintenance-20260905T0343374319511Z` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Gestor | tarefa `Running`, PID `17732` |
| Lock/console/singleton/stderr | mesmo PID / duplicata `73` / `0 bytes` |
| Energia/prontidão | `PASS` / `operational_ready=true` |
| Painel | `ACTIVE_OBSERVING`, zero atenções |
| Efeito público/custo | nenhum / `R$ 0,00` |

A automação diária existente foi atualizada no lugar para aplicar os mesmos limites: um contador abaixo de 30 pode liberar apenas novo ângulo; no piso ou acima, métricas criativas completas continuam obrigatórias. O próximo evento permanece D1 em `2026-09-05T18:45:51Z`, seguido do outcome em `2026-09-05T19:12:01.035029Z`.

## 33. Atualização operacional D-097 — atraso do YouTube não congela a operação até D3

O observador tratava `PARTIAL_DATA_LAG` como coleta concluída e agendava somente a próxima janela formal. Se CTR/retenção estivessem atrasados no D1, isso criava 48 horas de latência evitável. Depois de 720 h, o fallback ainda gerava uma data vencida.

`phase6-owned-observation-policy-v1` conserva 0/24/72/168/336/720 h e faz retry a cada 120 minutos por no máximo 12 horas/seis slots após a janela. Esgotado o período, volta ao calendário formal; depois da tolerância D30, encerra com timestamp nulo. O snapshot 1.1 registra todos os parâmetros e o schema mantém 1.0 histórico.

Prova verificável:

- 52/52 testes direcionados e 270/270 integrais PASS em 148,846 s;
- 119/119 schemas Draft 2020-12 e compileall PASS;
- manifesto preservado com 554 itens/3.080.086.312 bytes;
- receipt `daily-maintenance-20260905T0357151875938Z`;
- Gestor PID 19108, tarefa `Running`, lock/console iguais, duplicata 73, stderr zero, energia PASS e `operational_ready=true`;
- automação diária atualizada no mesmo ID, sem cópia paralela;
- nenhuma ação pública adicional e custo R$ 0,00.

O estado real segue pré-D1: `ACTIVE_OBSERVING`, coleta automática em `2026-09-05T18:45:51Z`. D-096 decide somente distribuição quando o contador exato estiver abaixo de 30; D-097 recolhe novamente quando faltarem dados exigidos, sem inventar conclusão. Fase 6 continua `IN_PROGRESS` com GC-01, GC-11 e GC-19 aguardando evidência real.

## 34. Atualização operacional D-098 — falha da fonte não fica oculta nem espera dias

Falha da YouTube Data API é diferente de atraso de Analytics. Agora `SOURCE_FAILURE_RETRY` repete em 30 minutos por no máximo 6 horas/12 slots. Durante a tolerância, o erro aparece no snapshot sem notificação repetitiva; depois do teto, o painel passa a `ATTENTION_REQUIRED` com `OWNED_METRICS_FAILED_RETRY_EXHAUSTED`. Nenhuma inferência ou ação pública é permitida a partir de `FAILED`.

Prova final: 54/54 testes dirigidos; receipt `daily-maintenance-20260905T0407171966381Z`; 272/272 testes integrais em 146,436 s; 119 schemas; compileall; manifesto 554 itens/3.080.086.312 bytes; Gestor PID 20192 com tarefa, lock, console, singleton, stderr, energia e `operational_ready` aprovados. Estado vivo `ACTIVE_OBSERVING`, zero atenções, zero gasto e zero ação pública adicional.

## 35. Atualização operacional D-099 — retry oficial permanece dentro da cota gratuita

O checkpoint de métricas agora possui preflight próprio: reserva 1 unidade geral por leitura e preserva piso de 12 para recuperação. Consumo desconhecido ou margem insuficiente bloqueia antes de enqueue e antes de qualquer API. O crédito vidIQ não participa dessa operação.

O receipt é criado no instante em que o checkpoint estiver devido, não antecipadamente. No estado atual pré-D1, sua ausência é correta; a fixture comprova que um guard bloqueado produz zero chamadas de Reporting e métricas. O fallback é aguardar o reset gratuito, nunca ativar billing.

Prova final: 41/41 testes dirigidos; receipt `daily-maintenance-20260905T0419523321381Z`; 274/274 testes integrais em 159,156 s; 119 schemas; compileall; manifesto 554 itens/3.080.086.312 bytes; Gestor PID 18824 operacional, painel sem atenções, custo R$ 0,00 e nenhuma ação pública adicional.

## 36. Atualização operacional D-100 — criatividade comparativa, variável única e direção sem notas inventadas

A auditoria do caminho real de pré-produção encontrou três fragilidades concretas: duas receitas fixas formavam quase toda a narrativa, o tratamento `FIRST_8_SECONDS_MECHANISM` também alterava o corpo e o Diretor Criativo registrava `1.0` em todas as dimensões sem cálculo. Isso produzia aparência de rigor, mas não uma escolha criativa comparativa nem um experimento causal limpo.

O novo `phase6-adaptive-creative-compiler-v1` cria três conceitos concorrentes por cluster atualmente suportado e registra, para cada um, sete componentes ponderados: alinhamento ao mecanismo, contrato do hook, prova visual, novidade, profundidade da evidência, segurança de política e integridade do tratamento. Cada candidato ainda precisa passar checks críticos de janelas 0–1/1–3/3–8, cobertura por ativos com direitos válidos, vínculo semântico observado, linguagem não promissória e preservação da variável única. Se nenhum passar, a produção falha fechada.

Os ramos agora possuem contratos verificáveis:

- `TOPIC_ANGLE`: conceito, promessa, hooks, corpo e payoff novos, orientados pelo mecanismo observado;
- `FIRST_8_SECONDS_MECHANISM`: altera somente as três janelas iniciais e mantém tese/seções do corpo anterior;
- `BODY_PROGRESSIVE_DISCLOSURE`: mantém os hooks exatos e utiliza uma permutação integral dos blocos anteriores.

O Diretor Criativo também deixou de fabricar encaixe perfeito. Ele chama o seletor real do catálogo, exige o pack exato permitido e score mínimo `0,75`. Na fixture de integração, `fp-broll-cinematic-narration@1.1.0` marcou `0,8082`, com dimensões não uniformes; o conceito vencedor marcou `0,964368` sobre duas alternativas elegíveis. São evidências de que cálculo, comparação e rejeição funcionam — não são probabilidades de viralização nem resultados do futuro Vídeo 2.

O avaliador independente reabre e valida `creative_concept_decision.json`, exige no mínimo três alternativas, confirma que o vencedor é o maior score elegível, checa todos os gates críticos e cruza o FormatPack. Um arquivo adulterado não gera work order nem release.

Prova oficial:

| Verificação | Resultado |
|---|---|
| Receipt | `daily-maintenance-20260905T0445408771607Z` |
| Regressão | `280/280 PASS` em `142,785 s` |
| Schemas | `120/120` Draft 2020-12 |
| Compileall | `PASS` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Runtime | tarefa `Running`, PID `13560`, lock/console no mesmo processo |
| Singleton/energia/prontidão | duplicata `73`, energia `PASS`, `operational_ready=true` |
| Estado público | nenhuma nova ação; canário original preservado |
| Custo | técnico `R$ 0,00`; mídia `R$ 0,00` |

A rotina automática existente foi atualizada no mesmo ID para revalidar os três candidatos, o isolamento de FIRST8/BODY e o score real do FormatPack. O sistema permanece `ACTIVE_OBSERVING`: D1 será executado em `2026-09-05T18:45:51Z`, e somente esse dado vivo poderá escolher a variável e acionar a compilação seguinte. Isso mantém a meta de 30 dias como prioridade operacional sem sacrificar o baseline nem converter desejo de resultado em falsa garantia.

## 37. Atualização operacional D-101 — seis rotas, distância criativa, prova anticópia e red-team

D-100 revelou o próximo limite depois de implementado: três alternativas ainda formavam um espaço estreito e não havia uma medida explícita de proximidade entre candidatos ou contra os títulos minerados. Além disso, o avaliador independente conferia o vencedor, mas não recompunha toda a aritmética do compilador.

O contrato 1.1 resolve essas três lacunas:

- busca mínima de seis rotas únicas, das quais ao menos três precisam passar todos os checks;
- cinco eixos declarados: lente narrativa, hook, promessa/embalagem, estrutura de prova e payoff;
- nove componentes de score, incluindo distinção entre candidatos e originalidade contra títulos-fonte;
- red-team por rota, com alternativa mais próxima, referência mais próxima, sobreposição, componente mais fraco e desafios adversariais;
- recomputação independente de pesos, scores, elegibilidade, contagens, máximos e vencedor.

Para TOPIC e FIRST8, a diversidade é lexical. Para BODY, ela é estrutural, pois as palavras precisam permanecer idênticas para conservar a variável única; o sistema compara posição e adjacência dos blocos. A originalidade contra referência examina cada trecho criativo e remove apenas boilerplate de formato, evitando que `Christian Motivation` distorça o resultado. Copiar um título descritivo para a tese/título reprova a rota em teste.

Resultado controlado da busca TOPIC:

| Medida | Resultado de fixture |
|---|---|
| Rotas avaliadas/elegíveis | `6/6` |
| IDs distintos | `true` |
| Similaridade máxima entre rotas | `0,229730` |
| Sobreposição máxima com título-fonte | `0,090909` |
| Vencedor | `sw-name-test-choose` |
| Score do vencedor | `0,938817` |
| Faixa das alternativas | `0,806379–0,874210` |
| Red-team | `PASS` |

Esses números provam seleção, diversidade e bloqueio; não são previsão de views. Não foi encontrado um LLM local no ambiente, portanto a capacidade atual é uma busca determinística auditável, sem fingir geração ilimitada e sem criar dependência paga.

Prova oficial:

| Verificação | Resultado |
|---|---|
| Testes dirigidos | `24/24 PASS` |
| Regressão integral | `283/283 PASS` em `163,237 s` |
| Receipt | `daily-maintenance-20260905T0504515349131Z` |
| Schemas/compileall | `120/120 PASS` / `PASS` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Runtime | `Running`, PID `12432`, lock/console coincidentes |
| Singleton/energia/prontidão | `73` / `PASS` / `true` |
| Ordem corrente | `phase6-treatment-order-1902a9c26c56d0cbe77c`, `WAITING_FOR_ELIGIBLE_BASELINE` |
| Efeito público/custo | nenhum / `R$ 0,00` |

A automação diária foi atualizada no mesmo ID para exigir v2, seis rotas, três elegíveis e recomputação integral. O próximo ato continua automático no D1; nenhuma autorização humana adicional é necessária.

## 38. Atualização operacional D-102 — oportunidade primeiro, profundidade somente no empate

A auditoria seguinte encontrou um erro de decisão concreto no caminho TOPIC: o seletor ordenava candidatos pela classe de evidência antes do `opportunity_score`. Como a profundidade já era um componente do score, ela recebia peso duas vezes. Na prática, uma hipótese `FULL` bastante inferior podia ultrapassar uma `OPENING_ONLY` com sinal composto superior.

`phase6-market-selection-score-first-v1` corrige o ranking e torna seus limites parte do contrato:

- somente candidatos elegíveis, com estratégia suportada, score `>=0,65`, peso observado `>=0,95`, classe válida e idade `<=168 h` entram;
- `opportunity_score DESC` é a decisão primária;
- classe da evidência, contagem entre canais e ID determinístico servem apenas como desempates;
- versão, piso, ordem literal e candidato são presos à ordem; mudar política ou candidato muda o `order_id`;
- `MARKET_EVIDENCE` recompõe piso, peso e atualidade a partir do snapshot em vez de confiar no rótulo selecionado.

O teste adversarial compara deliberadamente uma hipótese `OPENING_ONLY` superior a uma `FULL` inferior e confirma a primeira. Um empate confirma o uso correto da profundidade; `0,649999` confirma o bloqueio de fronteira. Assim, a correção melhora precisão decisória sem transformar o score em causalidade ou promessa viral.

| Verificação | Resultado |
|---|---|
| Testes dirigidos | `26/26 PASS` |
| Regressão integral | `285/285 PASS` em `145,626 s` |
| Receipt | `daily-maintenance-20260905T0516293640558Z` |
| Schemas/latest order/compileall | `120/120 PASS` / `PASS` / `PASS` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Runtime | tarefa `Running`, PID `7200`, lock/console coincidentes |
| Singleton/energia/prontidão | `73` / `PASS` / `true` |
| Ordem corrente | `phase6-treatment-order-2e04301977ef545fd517`, `WAITING_FOR_ELIGIBLE_BASELINE` |
| Ativos elegíveis | `29/29 PASS`, 783.561.975 bytes |
| Efeito público/custo | nenhum / técnico e mídia `R$ 0,00` |

A automação diária foi atualizada no mesmo ID para impor essa política no checkpoint. O estado continua `ACTIVE_OBSERVING`: o D1 de `2026-09-05T18:45:51Z` e o outcome de `2026-09-05T19:12:01.035029Z` são os próximos fatos capazes de liberar trabalho. A meta de 30 dias determina urgência, medição e correção; não autoriza inventar alcance nem publicar uma segunda peça sem evidência e gates.

## 39. Atualização operacional D-103 — evidência de mercado imutável até o consumo

Depois de corrigir o ranking, a auditoria encontrou um segundo risco: `candidate_id` não era identidade suficiente. O snapshot podia mudar score, fontes, títulos, métricas ou elegibilidade preservando o mesmo ID; a compilação voltava ao arquivo corrente e consumia o objeto localizado por esse ID. Isso quebraria a cadeia `evidência -> decisão -> comando` mesmo com uma ordem aparentemente válida.

A correção congela quatro provas na ordem:

- hash SHA-256 dos bytes exatos do snapshot diário;
- `snapshot_id` e `score_version`;
- hash canônico integral do candidato selecionado;
- política, candidato e todos esses valores dentro do `order_id`.

Antes de qualquer compilação, `_resolve_bound_market_candidate()` reabre a fonte, confere ambos os hashes, identidade, versão e unicidade, e refaz o ranking score-first. Depois disso, o mesmo snapshot/candidato em memória é passado à criação do conceito e do brief. Não existe uma segunda leitura por ID no intervalo crítico.

O teste adversarial reduz em `0,001` o score do candidato, mantendo seu ID. O novo conteúdo gera outro `order_id`; tentar executar a ordem anterior falha antes da escrita e não deixa `preproduction_receipt.json`. Essa é evidência direta de rejeição de drift, não apenas uma declaração arquitetural.

| Verificação | Resultado |
|---|---|
| Testes dirigidos | `27/27 PASS` |
| Regressão integral | `286/286 PASS` em `151,805 s` |
| Receipt | `daily-maintenance-20260905T0527248074609Z` |
| Schemas/latest order/compileall | `120/120 PASS` / `PASS` / `PASS` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Runtime | tarefa `Running`, PID `19564`, lock/console coincidentes |
| Singleton/energia/prontidão | `73` / `PASS` / `true` |
| Ordem corrente | `phase6-treatment-order-eddbd50675a4ded63370`, `WAITING_FOR_ELIGIBLE_BASELINE` |
| Operação | `ACTIVE_OBSERVING`, zero atenção/dead-letter |
| Efeito público/custo | nenhum / `R$ 0,00` |

A automação diária foi atualizada no mesmo ID para exigir essa reconciliação no checkpoint. O D1 permanece a próxima ação automática; a operação ganhou integridade sem antecipar decisão ou publicação.

## 40. Atualização operacional D-104 — embalagem criativa adaptativa

O tratamento do canário deixou de usar três pares estáticos. O compilador `phase6-adaptive-packaging-compiler-v1` pesquisa seis rotas e retém os três finalistas que passam integralmente conteúdo, ChannelDNA, complementaridade, novidade, distinção, originalidade, legibilidade, política, fonte própria e isolamento da variável.

Cada rota registra título, thumbnail, promessa, dez componentes de score, checks, red-team, referência mais próxima e receita exata de render com SHA-256. A decisão permanece ligada ao snapshot/candidato D-103. O avaliador de release recompõe a decisão e o bundle a partir das fontes antes de escolher; o teste adversarial altera score e atualiza o receipt, mas ainda assim recebe bloqueio por não reprodutibilidade.

O renderer não possui mais um mapa A/B/C paralelo: consome caminho, hash, copy e layout do finalista. Um teste produz a thumbnail representativa e obtém `PASS_LIMITED_PACKAGE_TREATMENT`, provando a cadeia até quality, sem publicar.

| Verificação | Resultado |
|---|---|
| Busca | `6` rotas / `3` finalistas |
| Componentes por rota | `10` |
| Testes dirigidos | `31/31 PASS` |
| Regressão integral | `288/288 PASS` em `152,108 s` |
| Receipt | `daily-maintenance-20260905T0552076616926Z` |
| Schemas | `122/122 PASS` |
| Compileall / manifesto | `PASS` / `554` itens e `3.080.086.312` bytes |
| Adulteração autorreferente | `BLOCKED` por recomposição independente |
| Render representativo | `PASS_LIMITED_PACKAGE_TREATMENT` |
| Runtime | tarefa `Running`, PID `2988`, lock/console/singleton/energia/prontidão PASS |
| Efeito público/custo | nenhum / `R$ 0,00` |

Esses resultados provam o mecanismo local, não CTR, viralidade ou monetização. Nenhuma ação pública foi executada pela D-104; a decisão viva segue condicionada ao D1 e a todos os gates posteriores.

A automação diária existente foi atualizada no mesmo ID para exigir a política D-104 no checkpoint; nenhuma tarefa duplicada foi criada.

## 41. Atualização operacional D-105 — identidade da superfície YPP

Foi feita uma tentativa estritamente read-only de obter o contador exato de horas públicas válidas diretamente do YouTube Studio. O Chrome redirecionou a rota de monetização para `studio.youtube.com/channel-appeal?authuser=0`, com uma tela de recurso referente à sessão Google corrente. A tentativa de endereçar a conta operacional diretamente voltou ao mesmo `authuser=0`; logo, essa tela não provou identidade do HeroVerse e não pode fornecer uma métrica válida do projeto.

O sistema não automatizou login, seletor de conta, recurso ou alteração. Também não atribuiu o aviso ao HeroVerse. A contraprova pública sem cota confirmou:

- HTTP 200 para `https://www.youtube.com/@heroverse74`;
- presença do channel ID `UCuMF6pJQkyMzaVoAxFL86yA` na página;
- oEmbed do vídeo `iK_5edYQtx8` com título `The 24-Hour Test: What To Do After You Pray`;
- autor `HeroVerse` e thumbnail pública vigente.

Consequência operacional: OAuth/API, canário público, D1 e cadeia autônoma permanecem ativos. O contador YPP de horas válidas continua corretamente `null/UNAVAILABLE`; isso limita a matemática do gap, mas não paralisa a execução nem autoriza estimativa fabricada. A tela observada de outra sessão não é evidência de strike no HeroVerse.

## 42. Atualização operacional D-106 — prova autoritativa do ciclo integral

Até esta correção, era possível provar a ordem pelo código e validar cada executor separadamente, mas ainda faltava uma única evidência de que observação, previsão, compilação, release, mídia, qualidade, publicação, aprendizado, transição e painel haviam realmente executado na mesma iteração do processo residente. D-106 fecha essa lacuna sem simulação.

O novo receipt cobre, na ordem literal:

1. `OWNED_OBSERVER`;
2. `PREDICTION_OUTCOME`;
3. `TREATMENT_COMPILER`;
4. `RELEASE_PREPARER`;
5. `PACKAGE_TREATMENT`;
6. `MEDIA`;
7. `QUALITY`;
8. `PUBLICATION`;
9. `LEARNING`;
10. `PHASE_TRANSITION`;
11. `EXECUTIVE_VIEW`.

Para cada item, o receipt registra arquivo, schema, status, timestamp, presença na janela, SHA-256 dos bytes e hash da identidade semântica. O ciclo falha fechado se um arquivo faltar, não validar, tiver sido produzido fora da janela ou expuser erro operacional. O estado `PHASE_TRANSITION=BLOCKED` com o código esperado `PHASE6_ACCEPTANCE_BLOCKED` e IDs GC explícitos continua visível como resultado legítimo do gate; não é confundido com falha de execução.

A memória também foi tornada rigorosa. A assinatura substantiva não inclui timestamps. Estados `INITIAL` e `STATE_CHANGED` são arquivados; `HEARTBEAT_ONLY` atualiza o ponteiro vivo sem criar uma falsa nova decisão. O painel executivo lê somente um receipt validado e o apresenta depois da conclusão; essa leitura não pode modificar ou aprovar retroativamente o ciclo congelado.

### Incidente de implantação e recuperação

A primeira manutenção D-106 reprovou dois testes de aceite: a regressão tentou validar o painel derivado da versão anterior contra o novo schema antes de regenerá-lo. O fechamento foi recusado, o erro foi preservado em log e o `finally` recuperou o Gestor. A rotina foi corrigida para, depois de parar a cadeia verificada e estabilizar os dados, migrar a visão executiva derivada antes dos testes. Nenhum receipt ou dado-fonte imutável é reescrito. A bateria dirigida de aceitação/ciclo/painel/recovery passou `22/22`.

### Evidência oficial final

| Verificação | Resultado |
|---|---|
| Manutenção | `daily-maintenance-20260905T0620292450294Z` |
| Regressão | `292/292 PASS` em `160,316 s` |
| Schemas | `123/123 PASS` |
| Compileall | `PASS` |
| Manifesto protegido | `554` itens / `3.080.086.312` bytes |
| Runtime | tarefa `Running`, PID `18692`, lock `HELD`, console `LISTENING` |
| Singleton/recovery | mesma cadeia, duplicata `73`, stderr `0`, energia `PASS`, `operational_ready=true` |
| Primeiro ciclo verificado | `phase6-control-cycle-d727c96e7be25f6eb5603045`, `11/11`, `PASS_WAITING`, zero blocker |
| Ciclo sem mudança | `phase6-control-cycle-c7a71b8d1738f0b56db9baef`, `HEARTBEAT_ONLY`, não arquivado |
| Fila/custo/efeito público | 2 `PENDING`, 0 `DEAD_LETTER`; R$ 0,00; nenhuma nova ação pública |

### Estado operacional real da corrida de 30 dias

- Início verificável: publicação pública do canário em `2026-09-04T18:45:51Z`.
- Fechamento da janela: `2026-10-04T18:45:51Z`.
- Próximo checkpoint: D1 em `2026-09-05T18:45:51Z`.
- Outcome da previsão inicial: `2026-09-05T19:12:01.035029Z`.
- Canal observado: 265 inscritos; gap nominal até 1.000: 735.
- Contador YPP de horas públicas válidas: `UNAVAILABLE`; o gap de horas não é estimado.
- Métrica inicial congelada: 2 views, 1 like, 1 comentário; demais métricas criativas ainda nulas por atraso/idade do dado.
- Próxima publicação: não pré-agendada. Será produzida e publicada automaticamente somente se D1 selecionar uma variável, todos os gates posteriores passarem, direitos/identidade/cota permanecerem válidos e o receipt private-first for confirmado.
- Promote/Ads: desativado; orçamento não definido; mídia R$ 0,00.

A meta de monetização em 30 dias permanece o objetivo operacional prioritário e determina velocidade de coleta, correção e produção. Ela não transforma baixa amostra em diagnóstico nem fatores controlados pelo YouTube em garantia. A redução real de erro vem de decisões versionadas, variável única, gates e ciclos medidos — nunca de declarar antecipadamente um resultado que ainda não ocorreu.

## 43. Atualização operacional D-107 — transição somente após ciclo reconciliado

A prova de ciclo D-106 revelou a última janela temporal relevante: o controlador de fase executava antes de o receipt integral daquele loop ser fechado. Assim, uma futura aceitação recém-aprovada poderia promover 6→7 na mesma iteração em que aprendizado ou aceite mudassem, sem antes existir uma prova material e imutável de que todos os 11 estágios haviam sido reconciliados.

D-107 elimina essa janela. Quando o aceite se tornar `APPROVED`, o primeiro ciclo apenas registra `WAIT_FOR_RECONCILED_CONTROL_CYCLE`, fecha os 11 estágios e arquiva o estado material. Somente uma iteração posterior pode criar a transição, desde que o `latest` continue byte a byte igual ao arquivo histórico e que as identidades exatas de `LEARNING` e `PHASE_TRANSITION` ainda coincidam.

O futuro receipt 6→7 passa a prender:

- ID e caminho do ciclo histórico;
- SHA-256 dos bytes exatos;
- assinatura substantiva;
- hash da identidade `LEARNING`;
- hash da identidade `PHASE_TRANSITION`.

O `transition_id` depende também do hash desse ciclo. Uma repetição idempotente reabre a prova e verifica schema, bytes, ID, assinatura e identidades. O teste adversarial adultera o histórico depois da criação e confirma `ERROR`, impedindo que a simples existência de um receipt antigo seja tratada como autorização atual.

Os critérios GC-07, GC-20 e GC-22 passaram a consumir a mesma prova integral. O painel é confrontado pela assinatura substantiva do ciclo, permitindo que o ID mude apenas por heartbeat sem que o estado semântico deixe de coincidir.

| Verificação | Resultado |
|---|---|
| Testes dirigidos | `20/20 PASS` |
| Regressão integral | `293/293 PASS` em `163,95 s` |
| Manutenção | `daily-maintenance-20260905T0636010787762Z` |
| Schemas | `123/123 PASS` |
| Manifesto | `554` itens / `3.080.086.312` bytes |
| Runtime | tarefa `Running`, PID `18320`, lock/console/singleton/energia/prontidão PASS |
| Aceite atual | `15 PASS`, `3 WAITING_REAL_EVIDENCE`, `0 FAIL`, `0 MISSING_EVIDENCE` |
| Bloqueadores próprios | somente `GC-01`, `GC-11`, `GC-19` |
| Transição 6→7 | `WAITING_FOR_PHASE6_GATE`; receipt ausente |
| Efeito público/custo | nenhum / `R$ 0,00` |

Essa correção não posterga uma ação válida por revisão manual; introduz exatamente uma barreira automática de reconciliação entre a mudança material e a promoção. D1 e o outcome inicial continuam sendo executados pelo Gestor nos horários previstos. Resultado de audiência e monetização continuam dependentes da resposta real da plataforma e do público, não são fabricados pelo mecanismo de controle.

## 44. Atualização operacional D-108 — trajetória oficial da meta de 30 dias

A meta de 30 dias já possuía cronômetro e checkpoints, mas havia uma lacuna objetiva: o observador coletava as métricas do canário e o painel continuava exibindo os 265 inscritos do snapshot anterior à publicação. Esse número era baseline, não uma observação atual. Sem `subscriberCount` corrente, não era possível medir gap restante, ganho líquido, ritmo observado ou desvio da trajetória.

D-108 introduz o controlador `heroverse-30-day-goal-trajectory-v1`. Nos checkpoints devidos, o preflight gratuito reserva duas unidades gerais e somente depois permite `videos.list` do canário e `channels.list(mine=true)` da conta autenticada. O snapshot 1.2 registra channel ID, inscritos, precisão pública arredondada a três algarismos significativos, total de vídeos e views do canal. Fonte falha ou identidade divergente deixa o total indisponível; não reutiliza 265 como se fosse atual.

O controlador calcula e versiona:

- baseline, atual e meta de inscritos;
- gap inicial e restante;
- ganho líquido;
- dias decorridos e restantes;
- ganho linear esperado no instante;
- delta em relação ao cronograma;
- ritmo observado e exigido por dia;
- razão entre o ritmo observado e o necessário;
- pressão e próxima ação já permitida.

O instante também foi auditado. A primeira versão usou `created_at` do receipt e adiantou a janela em 1,63 s. A correção final prioriza `published_at` oficial: início `2026-09-04T18:45:51Z`, deadline `2026-10-04T18:45:51Z`. Ambos agora participam da assinatura substantiva para que qualquer correção temporal produza histórico material rastreável.

### Resultado pré-D1

| Campo | Valor comprovado |
|---|---|
| Estado | `WAITING_FOR_CURRENT_CHANNEL_METRICS` |
| Baseline | 265 em `2026-09-03T14:32:14Z` |
| Meta | 1.000 |
| Gap inicial | 735 |
| Total corrente | `null`, pois D1 ainda não abriu |
| Horas YPP válidas | `null/UNAVAILABLE` |
| Pressão | `MEASURE` |
| Próxima ação | `COLLECT_D1_CHECKPOINT` |
| Agendamento | `2026-09-05T18:45:51Z` |
| Publicação/gasto autorizados pela trajetória | `false/false` |
| Preflight de checkpoint antecipado | ausente, corretamente |
| Custo técnico e mídia | R$ 0,00 |

Minutos assistidos do Analytics permanecem fora da conta de 4.000 horas públicas válidas. Eles podem orientar diagnóstico criativo, mas a elegibilidade YPP só será preenchida por fonte oficial apropriada. A pressão de trajetória nunca substitui direitos, originalidade, ChannelDNA, Quality Gates, cota, OAuth ou autorização de gasto.

### Testes, incidente e prova final

A primeira manutenção D-108 recusou um de 299 testes porque a fixture do receipt de ciclo copiou um `ATTENTION_REQUIRED` transitório do painel vivo. O serviço foi recuperado automaticamente pelo `finally`; a fixture foi isolada do estado ambiental e a bateria crítica passou `25/25`. Uma rodada intermediária passou `299/299`, mas foi substituída pela rodada final depois da correção de 1,63 s.

| Verificação | Resultado final |
|---|---|
| Manutenção | `daily-maintenance-20260905T0707027468681Z` |
| Regressão | `299/299 PASS` em `165,614 s` |
| Schemas | `124/124 PASS` |
| Instâncias vivas auditadas | `7/7 PASS` |
| Manifesto | 554 itens / 3.080.086.312 bytes |
| Gestor | tarefa `Running`, PID 3524, lock `HELD` |
| Supervisão/continuidade | console `LISTENING`, energia contínua, `operational_ready=true` |
| Erro ativo do Gestor | 0 bytes |
| Aceite Fase 6 | 15 PASS, 3 `WAITING_REAL_EVIDENCE`, 0 FAIL/MISSING |
| Transição 6→7 | `WAITING_FOR_PHASE6_GATE`, receipt ausente |
| Efeito público D-108 | nenhum |

Os três checks ainda abertos são GC-01, GC-11 e GC-19: piloto real, aprendizado real/aplicado e avaliação da previsão. Eles dependem dos dados que começam em D1, não de mais código prévio. O Gestor executará a coleta, o tratamento permitido e a avaliação subsequente automaticamente. A meta permanece rígida na operação; o resultado externo continua sujeito à resposta real do público e à decisão do YouTube.

## 45. Atualização operacional D-109 — meta presa ao receipt integral

A auditoria posterior à D-108 encontrou uma diferença entre executar e provar: `goal-trajectory/latest.json` era materializado dentro do loop e aparecia no painel, mas o receipt integral D-106 continuava com 11 estágios. Portanto, ele não congelava schema, tempo, bytes ou identidade da trajetória usada para decidir a prioridade daquela iteração.

D-109 cria o contrato 1.1 de 12 estágios. A nova ordem exata é:

1. `OWNED_OBSERVER`;
2. `PREDICTION_OUTCOME`;
3. `TREATMENT_COMPILER`;
4. `RELEASE_PREPARER`;
5. `PACKAGE_TREATMENT`;
6. `MEDIA`;
7. `QUALITY`;
8. `PUBLICATION`;
9. `LEARNING`;
10. `GOAL_TRAJECTORY`;
11. `PHASE_TRANSITION`;
12. `EXECUTIVE_VIEW`.

`GOAL_TRAJECTORY` precisa validar no schema, ter `evaluated_at` entre o início e o fim do ciclo e fornecer SHA-256 dos bytes e da identidade `trajectory_id + substantive_signature + technical_cost_brl`. Receipts 1.0/11 continuam válidos como histórico, mas não satisfazem mais GC-07, GC-20 ou GC-22.

A transição 6→7 também evoluiu para 1.1. Além de aprendizado e estado da transição, o receipt futuro prende `goal_trajectory_identity_hash`. Um teste altera a assinatura viva depois do ciclo e comprova `WAIT_FOR_RECONCILED_CONTROL_CYCLE`, sem criar receipt.

### Migração e recuperação

O primeiro processo reiniciado criou o ciclo 1.1/12, mas ele foi bloqueado por uma circularidade real: o painel ainda expunha o resumo 1.0; GC-20 virou `FAIL`; a transição virou `BLOCKED`; o painel gerou `PHASE_TRANSITION_BLOCKED`; e o estágio executivo bloqueou o próprio ciclo. A correção não relaxa o gate:

- o painel 1.1 omite temporariamente somente o resumo legado;
- falta de reconciliação é `MISSING_EVIDENCE`, nunca `PASS`;
- o primeiro ciclo novo produz a prova 12/12;
- a iteração seguinte reconcilia painel, aceite e transição.

O erro transitório foi removido do caminho corrente somente após sucesso e preservado byte a byte em `control-cycle/errors/archive/control-cycle-error-0e2045854137a39e.json` (371 bytes; SHA-256 `0E2045854137A39EEEB71382D9A8771CFD449197EB048551846DEE03CD20C206`). Outra tentativa encontrou o PID encerrando entre a checagem e `Stop-Process`; o comando parou, deixou a tarefa em `Ready` e depois apenas a religou. Nenhum processo de identidade incerta foi encerrado.

### Evidência final

| Verificação | Resultado |
|---|---|
| Testes dirigidos | `28/28 PASS` |
| Manutenção | `daily-maintenance-20260905T0732356315080Z` |
| Regressão | `302/302 PASS` em `151,595 s` |
| Schemas | `124/124 PASS` |
| Instâncias/histories validados | `7/7` e `7/7` |
| Compileall/manifesto | `PASS`; 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 21388, stderr zero, `operational_ready=true` |
| Ciclo | `phase6-control-cycle-51100a70760dd5e1a15b2f5f`, 1.1, 12/12, fresco, zero blocker |
| Trajetória no ciclo | presente e hash-pinned |
| Painel | `ACTIVE_OBSERVING`, zero atenção, assinatura coincidente |
| Aceite | 15 PASS, 3 `WAITING_REAL_EVIDENCE`, 0 FAIL/MISSING |
| Efeito público/custo | nenhum / R$ 0,00 |

O próximo fato continua sendo o D1. A diferença é que, quando o total atual e o desvio forem calculados, o sistema agora provará no mesmo receipt que essa trajetória participou da cadeia antes de qualquer futura transição de fase.

## 46. Atualização operacional D-110 — retry independente da trajetória de inscritos

A auditoria pré-D1 encontrou uma falha de acoplamento temporal. `videos.list` e YouTube Analytics podiam produzir um checkpoint criativo completo, enquanto `channels.list(mine=true)` falhava isoladamente. O vídeo continuaria corretamente elegível para diagnóstico, mas a contagem de inscritos ficaria nula e o próximo checkpoint seria o D3 — uma latência evitável de até 48 horas para a meta de 30 dias.

O snapshot novo 1.3 separa as duas decisões. `status` e `decision_status` continuam respondendo se a evidência do vídeo permite comparação. O objeto `goal_measurement` responde se o contador oficial foi observado, está em retry, esgotou a janela de recuperação ou é estruturalmente indisponível por ocultação. Nenhuma dessas situações transforma `null` em zero ou reapresenta o baseline 265 como total atual.

Quando a fonte de canal falha ou retorna identidade divergente, o próximo checkpoint é antecipado para 30 minutos, por até 6 horas/12 slots. Esse retry não invalida métricas criativas completas e continua sujeito ao preflight de duas unidades e piso preventivo de cota. Durante a recuperação o painel permanece silencioso; após o teto, exibe `SUBSCRIBER_TRAJECTORY_SOURCE_RETRY_EXHAUSTED`. Se a própria resposta declara inscritos ocultos, o estado é `UNAVAILABLE_HIDDEN_SUBSCRIBER_COUNT` e não há chamadas repetitivas inúteis.

Provas executadas:

- identidade de canal divergente: vídeo `OBSERVED/ELIGIBLE_FOR_COMPARISON`, contador nulo, retry em +30 min;
- teto de seis horas: contador nulo, retry encerrado e condição de alerta explícita;
- inscritos ocultos: indisponibilidade registrada, retorno ao calendário formal e nenhuma tentativa acelerada;
- fonte integral: contador observado e calendário formal preservado;
- schemas 1.0–1.2 históricos continuam válidos, novas coletas usam 1.3;
- `26/26` testes dirigidos, incluindo rejeição de estado contraditório, compileall e `124/124` schemas PASS;
- manutenção oficial `daily-maintenance-20260905T0759095235067Z`: `306/306 PASS` em `162,589 s`, manifesto `554/3.080.086.312`;
- runtime: tarefa `Running`, PID `20304`, lock `HELD`, ciclo `phase6-control-cycle-e11c9d5a12b77d7068c99caa` 1.1 com `12/12 PASS_WAITING`, zero blocker e painel sem atenção;
- custo técnico/mídia e efeito público da correção: R$ 0,00 / nenhum.

O próximo fato continua D1 em `2026-09-05T18:45:51Z`. A correção não força uma chamada antecipada; garante que uma falha parcial real não congele a mensuração da meta até D3 nem desperdice evidência criativa válida.

## 47. Atualização operacional D-111 — controle oficial diário da corrida de 30 dias

A auditoria posterior à D-110 encontrou uma distinção objetiva entre “recalcular diariamente” e “medir diariamente”. Até então, o controlador atualizava relógio, gap esperado e pressão em cada ciclo, mas a contagem oficial só mudaria nos checkpoints criativos D1, D3, D7, D14 e D30. Um painel de D2 ou D6 continuaria matematicamente correto sobre uma observação antiga, insuficiente para controle diário rígido.

D-111 adiciona o observador `heroverse-daily-channel-goal-observer-v1`, com slots D1–D30 ancorados na publicação pública real. O fluxo não reabre diagnóstico nem coleta métricas criativas fora do protocolo. Ele mede apenas `subscriberCount`, `videoCount` e `viewCount` do canal autenticado e exato.

A cota é conservadora:

- no D1/D3/D7/D14/D30, um snapshot próprio imutável e válido é reutilizado com 0 unidade adicional;
- nos dias intermediários, uma chamada `channels.list(mine=true)` reserva 1 unidade e preserva piso preventivo de 12;
- uso desconhecido ou margem abaixo do piso bloqueia antes da chamada;
- billing permanece desativado e não há dependência paga.

A recuperação é finita e auditável. Falha de fonte, identidade ou cota agenda nova tentativa em 30 minutos, no máximo 12 vezes durante 6 horas. Inscritos ocultos permanecem nulos e encerram o slot, sem chamada repetitiva inútil. Se o computador retornar depois de vários dias, os comandos antigos não consultam o presente fingindo representar o passado: recebem `SUPERSEDED_BY_CATCHUP`, e somente o dia mais recente devido é coletado.

`goal-trajectory` 1.1 escolhe a observação oficial schema-válida com `captured_at` mais recente. O artefato registra tipo, ID, caminho, instante, estado e próximo agendamento, e inclui tudo na assinatura substantiva. O painel 1.1 expõe a mesma origem. O receipt integral permanece em 12 estágios: o estado do novo observador está semanticamente preso ao estágio `GOAL_TRAJECTORY`, evitando duplicar autoridade ou alterar a ordem da fase.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Regressão dirigida | 48/48 PASS |
| Regressão integral | 317/317 PASS em 156,457 s |
| Schemas/compileall | 126/126 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T0834440018404Z` |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 14972, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Observador diário | `NOT_DUE`; job D1 `job-7599266b58859a5078eafe3e` `PENDING` para `2026-09-05T18:45:51Z` |
| Fila | 3 PENDING, 0 LEASED/RETRY/DEAD_LETTER |
| Trajetória/painel | schemas 1.1, fonte ainda `UNAVAILABLE` antes de D1, painel `ACTIVE_OBSERVING`, zero atenção |
| Ciclo | `control-cycle/latest.json`, 12/12, `PASS_WAITING`, zero blocker; ID rotativo por heartbeat |
| Custo/efeito público D-111 | R$ 0,00 / nenhum |

O D1 continua sendo o próximo fato obrigatório. O contador atual permanece corretamente `null` até a janela abrir; o painel mostra 265 somente como baseline histórico, não como uma falsa coleta corrente. A partir do D1, haverá uma observação oficial por dia para medir a distância da meta e priorizar ações já permitidas. Isso reduz erro de controle e latência de reação, mas não fabrica audiência nem converte a meta em garantia do YPP.

## 48. Atualização operacional D-112 — plano de 30 dias reconciliado

Depois da D-111, o observador real possuía slots D1–D30, mas o workbook ainda mostrava os dias fora de D1/D3/D7/D14/D30 como `No scheduled checkpoint`. O runtime estava correto; o artefato executivo não estava. A divergência foi removida.

A aba `30-Day Plan` agora separa três coisas:

- observação oficial do canal, agendada todos os dias de D1 a D30;
- métricas criativas próprias, coletadas somente em D1/D3/D7/D14/D30;
- publicação, que continua sem compromisso antecipado e só pode ocorrer depois dos gates.

D1 combina contagem oficial, baseline próprio e pré-registro de uma variável. D2 e demais dias intermediários mostram `Official daily channel metrics` e declaram `no creative re-diagnosis`. As 30 linhas futuras estão `Scheduled` para medição; `Release control` continua `No release precommitted` e a nota registra que observação diária não é postagem prometida.

O workbook foi reconstruído pelo pipeline gratuito já existente. A inspeção de `A1:H35` confirmou D0–D30 sem lacunas, o scan de fórmulas encontrou zero erros e as 14 abas foram renderizadas. O teste de contrato passou `2/2`. O arquivo final possui 41.920 bytes e SHA-256 `06EB061810416762E3163212EB63ED4CEB45D6D22F897DBF3A8AB79B413E5CA8`. A mudança teve custo R$ 0,00, não consumiu cota do YouTube e não alterou canal, vídeo, metadados ou publicação.

## 49. Atualização operacional D-113 — precisão temporal sem baseline disfarçado de atual

A auditoria cruzada entre trajetória, painel e planilha encontrou uma divergência objetiva: `goal-trajectory` já preservava `current_subscribers=null` antes do D1, porém o relatório executivo substituía esse nulo pelo snapshot histórico de 265. A consequência visível era mais grave que um rótulo: o workbook calculava gap 735 e 147.000/73.500/49.000 views nos cenários de conversão, embora nenhuma contagem oficial corrente tivesse sido observada.

O contrato executivo evoluiu para 1.2. Agora existem campos distintos para baseline e horário histórico, total corrente, flag de observação, origem e horário corrente. O alias legado `observed_subscribers` foi mantido para compatibilidade, mas passou a significar exclusivamente a medição atual; antes do D1 ele é `null`. O schema exige coerência entre esses campos e continua aceitando 1.0/1.1 apenas como evidência histórica.

Na planilha, qualquer fórmula dependente do total corrente é suspensa quando a flag oficial está falsa. Dashboard, gap e projeções mostram `UNAVAILABLE`; o baseline de 265 fica em uma faixa explicitamente histórica com `2026-09-03 14:32 UTC`. Quando o observador D-111 produzir uma fonte válida, o mesmo fluxo preencherá total, origem e captura e então habilitará os cálculos.

Durante a manutenção, um segundo defeito operacional foi capturado pelo próprio gate: o cold start do console de revisão levou pouco mais de 5 segundos, ultrapassou o timeout e fez o novo processo encerrar fail-closed. O limite interno foi ajustado para 30 segundos, ainda condicionado à thread viva e ao receipt com PID igual ao lock e ao Gestor. A repetição real estabeleceu serviço saudável sem intervenção manual recorrente.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Casos dirigidos baseline/corrente | 34/34 PASS |
| Regressão integral final | 319/319 PASS em 163,591 s |
| Schemas/compileall | 126/126 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T0909256526361Z` |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 7956, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Painel vivo | schema 1.2, `ACTIVE_OBSERVING`, baseline 265 datado, atual/alias/gap nulos, zero atenção |
| Operação | ciclo 12/12 `PASS_WAITING`; fila 3 PENDING/0 dead-letter; D1 `2026-09-05T18:45:51Z` |
| Workbook | 42.069 bytes; SHA-256 `CE18BA8CD3235D9E396846BE7F63055F2ADAEA71E7509A3F043341CE7392DAFB`; 14 renders; 0 erro de célula |
| Automação | `hero-engine-rotina-di-ria` `ACTIVE`; D-112/D-113 presentes uma vez, sem rotina duplicada |
| Custo/efeito público D-113 | R$ 0,00 / nenhum |

A D-113 não desacelera a meta: ela impede que o Gestor tome decisões rápidas sobre um dado antigo apresentado como novo. A primeira contagem corrente continuará sendo coletada automaticamente no D1. Só então gap e ritmos passarão de indisponíveis para calculados com origem e horário verificáveis.

## 50. Atualização operacional D-114 — ritmo somente entre pontos temporais comparáveis

A revisão seguinte encontrou um segundo problema, diferente do corrigido pela D-113. O painel já não chamava 265 de contagem atual, mas a trajetória ainda calculava velocidade e razão usando essa referência de `2026-09-03T14:32:14Z` contra um relógio iniciado apenas em `2026-09-04T18:45:51Z`. A diferença é de `28,226944 h`. Qualquer alteração ocorrida nesse intervalo anterior ao vídeo contaminaria o indicador do D1.

O contrato foi corrigido sem apagar o baseline. A contagem histórica continua útil para contexto e gap histórico; a primeira medição oficial capturada dentro da janela pública passa a ser a âncora de ritmo. Somente uma segunda origem oficial distinta permite calcular ganho, tempo decorrido, ganho linear esperado, delta e razão. Até lá, o Gestor mostra o gap atual e a exigência diária restante, mas declara `CURRENT_GAP_MEASURED_PACE_PENDING` e mantém a razão nula.

Existe uma proteção adicional contra falsa amostragem: o observador diário de D1 normalmente envolve o mesmo checkpoint próprio. Como ambos carregam a mesma origem, o wrapper é deduplicado e continua valendo como uma única observação, ainda que tenha sido persistido segundos depois. Uma coleta direta de D2 ou outro checkpoint futuro cria a segunda origem real.

O `goal-trajectory` evoluiu para 1.2 e o painel para 1.3, preservando compatibilidade histórica. O painel passa a mostrar distância temporal da referência, âncora, instante, quantidade comparável e estado do ritmo. Os testes dirigidos cobrem gap D1 sem razão inventada, deduplicação do wrapper, cálculo após a segunda observação, seleção da fonte mais fresca, schema e integração com o ciclo; resultado inicial `33/33 PASS`.

A primeira manutenção encontrou exatamente o risco de migração que precisava bloquear: o painel 1.3 tentou ler o novo campo de um `goal-trajectory` 1.1 ainda vivo. O pré-teste e o recovery recusaram continuar. O leitor ganhou uma migração compatível: deriva apenas a distância temporal a partir dos dois timestamps já provados, mantém todo ritmo indisponível e então materializa o novo contrato 1.2. Uma fixture dedicada impede regressão desse caminho.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Casos dirigidos críticos | 33/33 PASS + migração histórica PASS |
| Regressão integral final | 321/321 PASS em 164,288 s |
| Schemas/compileall | 126/126 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T0934146020327Z` |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 19968, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Estado vivo | trajetória 1.2 e painel 1.3; atual/âncora/razão nulos antes do D1; ciclo 12/12 `PASS_WAITING`, zero blocker |
| Workbook | 42.059 bytes; SHA-256 `7CCA3D52584B2D5D686A6655B05004B0232283906AD4BA066454EE7C637D9EEF`; 14 previews; zero erro de célula |
| Automação | `hero-engine-rotina-di-ria` `ACTIVE`; D-114 presente exatamente uma vez |
| Custo/efeito público D-114 | R$ 0,00 / nenhum |

## 51. Atualização operacional D-115 — cadeia probatória dos pontos de trajetória

A auditoria seguinte encontrou uma lacuna de integridade diferente da correção temporal. O seletor de pontos verificava apenas campos suficientes para calcular o contador. Isso significava que um JSON parcial na pasta, uma visão `latest` sem twin correspondente ou um wrapper apontando para outro arquivo poderiam, em tese, participar do ritmo sem provar o contrato completo.

D-115 fecha a cadeia antes de qualquer cálculo: schema integral, canal exato, pasta autoritativa, filename igual ao ID e igualdade byte a byte entre `latest` e o arquivo imutável. Para `OWNED_METRICS_REUSE`, a observação diária precisa coincidir com o checkpoint próprio em contador, precisão pública, visibilidade, totais de vídeos/views e status oficial. Caminho absoluto, escape, pasta diferente, visão mutável ou divergência interrompem a decisão.

Um caso histórico real foi preservado sem falsificação. O primeiro snapshot próprio nasceu antes de o campo `reach_reporting_api` entrar no contrato ainda rotulado 1.0. O arquivo não foi reescrito. Ele ficou excluído de trajetória somente por caminho, ID, versão e SHA-256 exatos — `e0dd8a148b78f8aa1337ca44bd52f5ba8f79c315d0b103823dd11f98eb6d1bc3` — e porque não contém qualquer observação de inscritos. Um único byte diferente volta a bloquear.

A recuperação também foi exercitada. O processo residente antigo bloqueou o primeiro ciclo; a repetição seguinte recusou o receipt vivo defasado; depois da reconciliação 12/12, a manutenção final `daily-maintenance-20260905T1003452840119Z` passou 327/327 testes em 145,037 s. A tarefa voltou `Running` no PID 17852, com lock e console coincidentes, prontidão verdadeira, stderr zero e nenhum erro corrente. Incidentes anteriores permanecem arquivados por hash.

O resultado operacional não altera o próximo evento: D1 em `2026-09-05T18:45:51Z`. A trajetória segue sem total corrente e sem ritmo antes dessa fonte real. O ciclo `phase6-control-cycle-2c794c8108a9e37be19d455a` está 12/12 `PASS_WAITING`, o aceite aguarda somente GC-01/11/19, o custo é R$ 0,00 e não houve upload, Ads ou mudança pública nesta correção.

## 52. Atualização operacional D-116 — prova viva após a mesma manutenção

A auditoria seguinte eliminou uma ambiguidade no ciclo de manutenção. A regressão precisa de uma snapshot estável e, por isso, o Gestor é interrompido de forma controlada. Um teste que exigia estado `PASS_LIVE` durante essa interrupção podia gerar falso negativo. Mas o inverso também seria insuficiente: 334 testes verdes, isoladamente, não provam que o processo reiniciado carregou o código e executou os doze estágios.

D-116 separa as duas obrigações sem relaxar nenhuma. A suíte testa a classificação verdadeira do estado disponível. Depois do receipt PASS, a tarefa é iniciada, o verificador confirma PID, lock, console, singleton, stderr e energia, e a manutenção aguarda um ciclo 12/12 cujo início seja posterior ao seu próprio `completed_at`. Aceite, transição e painel são então recompostos; só depois um novo receipt permite exit 0.

Esse receipt é auditável no futuro. Os bytes exatos das cinco fontes validadas — manutenção, runtime, ciclo, aceite e executivo — ficam arquivados em `source-snapshots/<verification_id>/`. Os hashes são calculados na mesma leitura usada para validar o schema, evitando corrida entre validação e hash. Ciclo antigo, painel de outro ciclo, blocker não permitido, índice de blockers incoerente, timestamp invertido ou arquivo de erro corrente bloqueiam.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Regressão integral | 334/334 PASS em 169,420 s |
| Schemas/compileall | 127/127 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1025297907302Z` |
| Verificação pós-manutenção | `phase6-post-maintenance-213f09ce4d5210e2cfba5ae9` / PASS |
| Snapshots imutáveis | 5/5 presentes; 5/5 SHA-256 conferidos |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 6776, lock `HELD`, console `LISTENING`, singleton 73, stderr zero, energia/prontidão PASS |
| Ciclo posterior | `phase6-control-cycle-c61632ca76f9c3fc71e2199f`, 12/12 `PASS_WAITING`, zero blocker |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção, mesmo cycle ID |
| Automação | `hero-engine-rotina-di-ria` `ACTIVE` às 16h BRT; D-116 presente exatamente uma vez |
| Custo/efeito público D-116 | R$ 0,00 / nenhum |

A próxima mudança externa continua condicionada à evidência do D1 em `2026-09-05T18:45:51Z`. A prova pós-manutenção reduz erro operacional; não fabrica dados de audiência e não transforma a meta em garantia da plataforma.

## 53. Atualização operacional D-117 — cota e custo zero também no outcome da previsão

A revisão do próximo evento externo identificou uma lacuna concreta: o D1 possuía guarda de custo/cota, mas o job que observará o resultado da previsão às `2026-09-05T19:12:01.035029Z` ainda podia chamar a Data API sem seu próprio preflight. A leitura não gera cobrança no estado atual, mas continuava sendo consumo externo sem a evidência exigida pelo contrato do projeto.

O guard ganhou a operação específica `phase6_prediction_outcome_checkpoint`, com reserva de 2 unidades gerais, piso preventivo 12, custo R$ 0,00 e nenhuma dependência de vidIQ. Quando o horizonte abrir, ele gravará uma visão latest e uma cópia imutável sob o job exato. Caminho e SHA-256 entram na transação antes da chamada; cota desconhecida ou insuficiente agenda nova verificação em cinco minutos e executa zero acesso.

A retomada também foi endurecida. Se a coleta foi concluída e a avaliação falhou depois, o retry reaproveita o snapshot e não chama o YouTube outra vez. Antes disso, ele confere diretório, filename, SHA-256, schema, operação, permissão, quota PASS, reserva 2, piso 12 e custo zero. Qualquer adulteração bloqueia tanto o reuse quanto uma recolha silenciosa.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Testes dirigidos prediction + custo | 14/14 PASS |
| Testes dirigidos incluindo Gestor | 29/29 PASS |
| Regressão integral | 338/338 PASS em 168,672 s |
| Schemas/compileall | 127/127 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1042233896565Z` |
| Verificação pós-manutenção | `phase6-post-maintenance-59e192d45a705806b8dfd5eb` / PASS |
| Snapshots imutáveis | 5/5 presentes; 5/5 SHA-256 conferidos |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 12168, lock `HELD`, console `LISTENING`, singleton 73, stderr zero, energia/prontidão PASS |
| Ciclo posterior | `phase6-control-cycle-6e356b9beb55c79b6ac8d024`, 12/12 `PASS_WAITING`, zero blocker |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção |
| Custo/efeito público D-117 | R$ 0,00 / nenhum |

O Gestor continua operacional e a fila está saudável com três jobs temporais. D1 abre primeiro, em `2026-09-05T18:45:51Z`; o outcome abre depois. A ausência do novo preflight antes do horizonte é intencional: nenhuma prova de permissão é fabricada antes da operação real. Isso aumenta a precisão e a segurança da execução, mas não transforma uma meta operacional em garantia de resposta do público ou do YPP.

## 54. Atualização operacional D-118 — aprendizado externo idempotente e scheduler verdadeiro

A varredura de todas as rotas externas encontrou uma segunda classe de risco. O observador que futuramente comparará o tratamento podia consultar Reporting, Data API e Analytics sem preflight próprio; se a avaliação quebrasse depois, a retomada podia repetir a coleta. Separadamente, o outcome D-117 informava uma espera de cinco minutos, mas ainda não persistia esse horário na fila.

A fila ganhou uma operação de deferimento que não consome tentativa. Ela só aceita jobs sem lease, grava `RETRY_WAIT`, `available_at`, motivo e checkpoint e impede nova reivindicação antes do horário. Falhas técnicas reais depois do lease continuam no mecanismo de retry exponencial existente.

As duas formas de aprendizado — Vídeo 2 e troca de embalagem do canário — agora usam `phase6_treatment_metrics_checkpoint`, com reserva de 2 unidades gerais, piso preventivo 12 e custo R$ 0,00. A prova imutável entra no SQLite antes da chamada. Registry, reach e snapshot próprio são copiados para o diretório do job e presos por hash; em uma retomada, cada etapa concluída é validada e reutilizada. Um byte diferente bloqueia, e nenhuma chamada concluída é repetida.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Núcleo fila/cota/aprendizado | 34/34 PASS |
| Integração Gestor/manutenção/aceite | 26/26 PASS |
| Regressão integral | 344/344 PASS em 168,341 s |
| Schemas/compileall | 127/127 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1101010831568Z` |
| Prova pós-restart | `phase6-post-maintenance-d6809992fc2e235118d6effd` / PASS |
| Snapshots da prova | 5/5 presentes; 5/5 hashes conferidos |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 1868, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Ciclo/fila | `phase6-control-cycle-437cbe1bcccc0d9e1ab88ebd`, 12/12 `PASS_WAITING`; 3 PENDING, zero retry/dead-letter |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção |
| Custo/efeito público D-118 | R$ 0,00 / nenhum |

O sistema agora espera de verdade quando a cota não estiver comprovada e retoma de verdade sem repetir efeitos concluídos. O próximo evento continua sendo D1, em `2026-09-05T18:45:51Z`. Essa engenharia reduz a margem de erro controlável; ela não permite prometer a reação da audiência nem a decisão do YPP.

## 55. Atualização operacional D-119 — D1 irrepetível por etapa

A última varredura pré-D1 confirmou que o guard vinha antes de Reporting/Data/Analytics, mas revelou um risco na recuperação. O preflight estava somente em `latest`; Reporting entrava no checkpoint por caminho mutável; o snapshot próprio só era preso no sucesso final. Se a inteligência falhasse, o retry chamaria novamente etapas que já tinham terminado.

O fluxo agora é um journal. O job exato existe antes do guard. O preflight é copiado para histórico imutável e seu hash entra no SQLite antes da primeira chamada. Registry e métricas entram logo depois de cada efeito, também como bytes congelados e hashes. Na retomada, o Gestor revalida a cadeia e pula etapas prontas; se apenas Reporting terminou, somente a métrica restante pode executar sob uma prova de cota atual.

O compilador de previsão/diagnóstico/protocolo continua lendo `latest`, mas agora o job exige igualdade byte a byte com o snapshot arquivado antes de permitir essa etapa. Isso impede uma coleta posterior de mudar silenciosamente a evidência durante um retry. A classificação também foi corrigida: exceção técnica é `ERROR`; `BLOCKED` fica reservado a uma pré-condição conhecida.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Rotas dirigidas integradas | 61/61 PASS |
| Regressão integral | 345/345 PASS em 164,237 s |
| Schemas/compileall | 127/127 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1115050215909Z` |
| Prova pós-restart | `phase6-post-maintenance-2cd02d38995aa00ddb3bd6eb` / PASS |
| Snapshots da prova | 5/5 presentes; 5/5 hashes conferidos |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 5832, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Ciclo/fila | `phase6-control-cycle-9c368458660cbae061698383`, 12/12 `PASS_WAITING`; 3 PENDING, zero retry/dead-letter |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção |
| Custo/efeito público D-119 | R$ 0,00 / nenhum |

O D1 está tecnicamente preparado para coletar uma vez, preservar cada etapa e se recuperar sem duplicidade. Ele continua agendado para `2026-09-05T18:45:51Z`. Aguardar esse instante protege a validade da análise; antecipá-lo produziria um número rápido, mas metodologicamente errado.

## 56. Atualização operacional D-120 — observação diária sem duplicar cota

A auditoria específica da meta de 30 dias encontrou uma última diferença entre “ter guard” e “ser recuperável”. Quando o D1 próprio não fornece um contador reutilizável, o observador diário usa `channels.list(mine=true)`. O guard já vinha antes da chamada, mas sua visão era mutável e a resposta só ganhava evidência definitiva junto com a observação final. Uma queda depois da API poderia repetir a unidade no retry.

D-120 transforma esse fallback em transação. O preflight é imutável por job e entra no SQLite com SHA-256 antes da chamada. A resposta normalizada é gravada no slot nominal da janela com schema próprio, identidade de operação/canal/job/horário e vínculo à prova de cota. Só depois nasce a observação usada na trajetória. Um retry procura e valida esse checkpoint primeiro; se os bytes estiverem íntegros, termina com zero nova chamada.

A espera de cota também deixou de ser tratada como falha. O novo `defer_claimed` exige o lease do worker, devolve o job para `RETRY_WAIT`, agenda cinco minutos e reverte o incremento da tentativa porque nenhum efeito ocorreu. O painel distingue `QUOTA_WAIT` de retry de fonte. Prova adulterada, arquivo duplicado no slot, fuga de diretório ou divergência de ID/hash/schema bloqueia sem tentar “consertar” recolhendo novamente.

### Prova verificada

| Verificação | Resultado |
|---|---|
| Testes dirigidos fila + observador | 18/18 PASS |
| Regressão integral | 349/349 PASS em 142,924 s |
| Schemas/compileall | 128/128 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1136554953693Z` |
| Prova pós-restart | `phase6-post-maintenance-6fbc800f60c9e2e9fcd547e3` / PASS |
| Snapshots da prova | 5/5 caminhos e hashes registrados |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 9756, lock `HELD`, console `LISTENING`, singleton 73, stderr zero, energia/prontidão PASS |
| Ciclo/fila | `phase6-control-cycle-62c07d762e648a18fcc2090d`, 12/12 `PASS_WAITING`; 3 PENDING, zero retry/dead-letter |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção, nenhum erro corrente |
| Custo/efeito público D-120 | R$ 0,00 / nenhum |

O alvo permanece maximizar a chance de monetização até `2026-10-04T18:45:51Z`. O sistema controla cronômetro, coleta, ritmo, diagnóstico, correção, produção e publicação; não inventa uma garantia sobre audiência ou aprovação do YouTube. O próximo dado válido continua D1 em `2026-09-05T18:45:51Z`.

## 57. Atualização operacional D-121 — experimento imutável, prova causal e cota do dia

A última auditoria antes da primeira janela de 24 horas encontrou três formas de um sistema aparentemente verde tomar uma decisão errada. O protocolo experimental ainda podia ser recomposto após nova evidência; o aceite reconhecia runtimes e avaliações válidos sem amarrá-los integralmente ao experimento corrente; e o console de cota podia mostrar o consumo do dia anterior como se fosse a base do dia atual.

O primeiro protocolo real `PREREGISTERED` agora vira um contrato imutável em `experiments/active.json`. Enquanto o experimento estiver aberto, `latest.json` deve ser byte-idêntico. Uma medição nova pode alimentar observação e diagnóstico, mas não reescreve a hipótese, o baseline, a variável única ou a métrica que serão avaliados.

Os gates GC-01 e GC-19 deixaram de aceitar proximidade semântica. O aprendizado precisa provar o caminho completo entre protocolo, baseline, ação publicada, snapshot de tratamento, avaliação e runtime. A previsibilidade precisa provar a previsão atualmente registrada, o job específico, o snapshot colhido depois do horizonte e sua avaliação exata. Um arquivo antigo, avulso ou pertencente a outro experimento permanece evidência histórica, nunca passe para o gate atual.

A cota passou a ter contabilidade própria por dia do Pacífico. Se a observação oficial pertence ao dia anterior, sua base expira; o sistema ainda soma uploads confirmados do dia e uma reserva conservadora de 2.000 unidades para uso geral não rastreado. O resultado é persistido com a equação, limites, risco de cobrança bloqueado e fallback gratuito. Também foi corrigido o contrato dos fallbacks para package, publicação e observação.

### Prova inicial

| Verificação | Resultado |
|---|---|
| Testes críticos dirigidos | 69/69 PASS em 19,253 s |
| Deriva de protocolo | Bloqueada; ativo e latest byte-idênticos |
| GC-01 superficial | Recusado |
| GC-19 com avaliação alheia | Recusado |
| Cota do dia anterior | Base expirada + reserva 2.000 |
| Cota alta no mesmo dia | Limitada a 10.000 e bloqueada pelo guard |
| Fallback de package | Schema/preflight PASS |
| Custo/efeito público | R$ 0,00 / nenhum |

### Prova oficial

| Verificação | Resultado |
|---|---|
| Regressão integral | 356/356 PASS em 167,554 s |
| Schemas/compileall | 128/128 PASS / PASS |
| Manutenção | `daily-maintenance-20260905T1213092631813Z` |
| Prova pós-restart | `phase6-post-maintenance-5b0ea6528029e67fd4243945` / PASS |
| Manifesto protegido | 554 itens / 3.080.086.312 bytes |
| Runtime | tarefa `Running`, PID 4408, lock/console/singleton/energia/prontidão PASS, stderr zero |
| Ciclo/fila | `phase6-control-cycle-047c8fa7507f244b5082ae12`, 12/12 `PASS_WAITING`; 3 PENDING, zero retry/dead-letter |
| Aceite/painel | somente GC-01/11/19 pendentes; `ACTIVE_OBSERVING`, zero atenção |
| Cota corrente | dia do Pacífico atual; base oficial anterior expirada; 2.000/10.000 efetivas; billing falso |
| Continuidade | automação `ACTIVE`, D-121 presente uma vez; cinco hashes recalculados; zero erro corrente |
| Custo/efeito público D-121 | R$ 0,00 / nenhum |

D-121 está operacionalmente provada antes da janela D1. O objetivo operacional continua monetização em até 30 dias; os controles aqui reduzem erro interno, mas não falsificam a resposta do público nem a decisão do YouTube.

## 58. Atualização D-122 — diagnóstico verdadeiramente imutável

O protocolo ativo agora referencia o arquivo nominal do diagnóstico, e não a visão mutável `latest`. A ordem congela paths e hashes; no instante anterior à compilação, o sistema reabre e valida diagnóstico, protocolo ativo, twin latest, baseline, variável, métrica, alvo e canal. Três testes adversariais comprovam que uma nova latest não rebinda o experimento, que adulteração bloqueia pelo hash e que divergência do protocolo bloqueia antes da produção.

## 59. Atualização D-123 — capacidade Codex com qualidade máxima

A governança de consumo passa a ser executável. O padrão é melhor modelo Codex suportado com esforço `ultra`; qualidade não é reduzida. O consumo é controlado por preflight, agrupamento de inspeções, reaproveitamento de evidência imutável, retomada por checkpoint e testes dirigidos antes de uma única regressão integral.

Em `2026-09-05T12:33:47.905Z`, a conta estava GREEN: 36% usados, 64% restantes, janela de 10.080 minutos renovando em `2026-09-10T09:56:07Z`, três resets gratuitos preservados, nenhum limite ativo e nenhum gasto. O Gestor Central local continua independentemente do saldo Codex. Como o limite é compartilhado pela conta e o consumo varia por tarefa, a engenharia preserva reserva e continuidade, mas não apresenta crédito infinito como garantia.

### Prova integral D-122/D-123

| Verificação | Resultado |
|---|---|
| Testes dirigidos finais | 40/40 PASS em 17,363 s |
| Regressão integral | 363/363 PASS em 218,863 s |
| Schemas / compileall | 129/129 / PASS |
| Manutenção | `daily-maintenance-20260905T1300374758556Z` |
| Prova pós-restart | `phase6-post-maintenance-4c3b3614f5716a14f37d4d9a` / PASS |
| Runtime | tarefa Running, PID 18828, lock/console/singleton/energia PASS, stderr zero |
| Ciclo | `phase6-control-cycle-782108c2aa7ec47bac0609f0`, 12/12 `PASS_WAITING`, zero blocker |
| Aceite | GC-07/20/22 PASS_LIVE; somente GC-01/11/19 aguardam evidência temporal real |
| Codex | GREEN, 63% restante após a manutenção, melhor disponível + Ultra, 3 resets preservados |
| Custo / efeito público | R$ 0,00 / nenhum |

A manutenção detectou duas colisões legítimas durante a migração: scope 1.1 e protocolo de espera sem versão no filename. Ambas foram recusadas antes de sobrescrita, o Gestor foi recuperado pelo `finally`, os contratos subiram para identificadores novos e testes dedicados foram acrescentados. O resultado final preserva os artefatos históricos e elimina a causa do retrabalho futuro.

A leitura final `codex-usage-4a501a12f7789871`, em `2026-09-05T13:06:07.449Z`, registrou 37% usados/63% restantes. A diferença frente à leitura inicial da rodada foi 1 ponto percentual account-wide; os três resets permaneceram intactos.
