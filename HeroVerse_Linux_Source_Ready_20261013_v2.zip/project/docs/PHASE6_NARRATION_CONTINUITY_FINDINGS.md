# Fase 6 — Continuidade de narração antes do render

## Medição acústica independente — limites para o plano AV

Receipt `narration-acoustic-envelope-350ae512790a10e937f02358.json`, SHA `fac970cc1d9ed567084524176290eeda2cff7946b04673a7ea2211690d6f67f2`; runner QA SHA `2cc30aa749d01fd7fab30ca59b7eaff57b46c24cf846b3714349b97ef4a60a9d`. Sete testes sintéticos PASS e auditoria independente das 153 medições (51 unidades × três limiares) sem divergência. Nenhum arquivo sonoro foi editado.

RMS de 10 ms, limiar principal −40 dBFS: 3,310 s iniciais e 29,187 s finais abaixo do limiar, somados sobre as 51 unidades. Junções consecutivas do corpo sem pausa extra já representam 427–827 ms entre regiões RMS ativas, média 651 ms. O orçamento mínimo adicional de 17 s não pode ser distribuído uniformemente: exige função editorial, considerando o espaçamento existente.

Sensibilidade: a −45/−40/−35 dBFS, intervalos internos de pelo menos 100 ms somam respectivamente 4,240/10,580/24,250 s, em 24/76/173 intervalos. Isso demonstra dependência do instrumento, não duração de silêncio linguístico. Unidades 004/013/036/047/048 variam mais no fim da atividade entre limiares e não podem ser truncadas automaticamente.

Nas unidades 011/012/016, o fim estimado pelo ASR antecede o último bloco RMS principal em 220/220/350 ms. Nem ASR nem RMS isolados constituem alinhamento de palavra. Nos hooks, atividade RMS relativa ao WAV: 001 em 110–590 ms; 002 em 90–970 ms; 003 em 40–3.300 ms. Preservar slots 0–1/1–3/3–8 s, com função visual no restante, nunca tela de preenchimento.

Limites do runner diagnóstico preservado: PCM totalmente inativo representaria o mesmo intervalo como leading e trailing (nenhum caso atual); limiar não finito deve ser rejeitado na futura versão antes do cálculo; defaults atuais coincidem com a policy, mas sua futura alteração exige parâmetros explícitos, versão e novos testes. Esses pontos não alteram as medições atuais e não serão silenciosamente transferidos para o módulo operacional.

## Atualização posterior — 51 PCM reais disponíveis, ainda sem timeline aprovada

A situação `PLANNED_NOT_SYNTHESIZED` abaixo registra o diagnóstico inicial. Agora o conjunto completo existe:30unidades históricas +3provas contínuas +18unidades recém-sintetizadas, preservando texto/ordem/modelo/voz/velocidade e sem truncamento para encaixe. Não foram reprocessados os33PCM já disponíveis.

Reconciliação `output/qa/phase6/diagnostics/narration-pcm-reconciliation-v1/narration-pcm-reconciliation-6e8c38d5b22199b1672fa737.json`, SHA `a1ecadf4aa36c935cf88acf94e792a0c3359bd48f51db443d34d6e2bf7182b50`;131bindings rehashados pelo responsável principal. Total4.469.928frames a24kHz =186.247ms. Taxa calculada158,499197palavras/minuto usa texto dividido pelo PCM integral, incluindo pausas acústicas; não é velocidade de fala ativa nem nota perceptual.

Hooks0–8s continuam byte-idênticos e ocupam os slots originais. Com eles, base188.458,666667ms; teto100ms por unidade do corpo produz190.800ms, com intervalo aritmético possível207.800–286.200ms. A duração final não foi escolhida. Os17.000ms adicionais mínimos sobre a grade são orçamento a justificar editorialmente, não comando de inserir silêncio ou esticar a voz.

O runner completou18capturas/18QA estruturais/receipt de lote antes de falhar no cleanup. A causa foi comprovada localmente: `os.open` em modo padrão traduziu LF para CRLF; O_BINARY preservou os bytes na contraprova. Processo20464ausente confirmado por D-127; o lock foi arquivado de forma recuperável, com SHA inalterado, e a reconciliação terminouexit0. Runner/preflight/receipts históricos mantidos; nenhuma nova síntese na recuperação. O sucessor implementado deve usar modo binário e testar cleanup real Windows antes do efeito.

Ainda necessários: avaliação independente de fala, alinhamento com evidência acústica, pausas intencionais e eventos visuais, captions derivadas desse mapa, contrato AV compatível, namespace do sucessor, fontes concretas e Quality Gates. A disponibilidade de51PCM não autoriza render completo, produção ou publicação.

## Diagnóstico inicial preservado

Estado desta entrega: `PLANNED_NOT_SYNTHESIZED`. O planejador e a prova diagnóstica existem; não são uma nova voz, um vídeo aprovado ou uma integração operacional. Nenhum arquivo de produção, WAV, manifesto anterior, fila, receipt operacional, API, publicação ou processo do Gestor foi modificado por esta subtarefa.

## Causa e escopo preservado

O executor `hero_engine/phase6_media.py` monta a narração por take visual: cada fala já foi sintetizada separadamente; na montagem, cada WAV recebe `apad,atrim=0:{duration:.3f}` para preencher o slot e depois é concatenado. Um corte visual acaba impondo tanto uma nova chamada de síntese quanto preenchimento temporal, mesmo no meio de uma frase. A verificação anterior de `fits_timeline_slot=true` prova encaixe, não continuidade de prosódia ou ritmo natural.

O novo planejador puro separa unidade visual de unidade de narração. Ele agrupa os fragmentos ordenados até um final explícito de frase, conserva cada fragmento literal e registra o espaço único usado na junção. Uma unidade pode atravessar vários takes visuais sem reiniciar a fala por causa do corte. Pontuação abreviada/ambígua ou mudança de velocidade dentro da unidade exige `NEEDS_REVIEW`; não é resolvida por aceleração, truncamento ou timestamp inventado.

Texto, ordem, `am_onyx`, modelo e hash, vozes e hash, adapter, taxa de amostragem, velocidades originais, início/fim de cada take e horizonte total são preservados. O plano é executor subordinado; não define estratégia, prioridade ou autoridade paralela.

## Evidência real congelada

Diagnóstico: `output/qa/phase6/diagnostics/narration-units-v1/narration-continuity-9c22ad5af00a338a97f7877e.json`.

SHA-256 do diagnóstico: `94706a7b317b2bf97a9d484c48f094b7854c5b6d38f34ecabe84929161e31904`.

Fontes verificadas por bytes:

| Fonte | SHA-256 |
|---|---|
| TakePlan `phase6-take-plan-bc3f25d5090c1087b1c8` | `547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5` |
| Voice manifest 1.2 `voice-phase6-60322e8ee7586d38077e` | `f28f2dcd864ff72bce873f892e9912185f3034bc2613c07fd0712f17a4bec6b2` |
| Narrative script `script-phase6-84717438dcbbeed0fe31` | `6f8686c2bbfdcb8524eb26e3f94729efec13c17b30ed4f8c59dd223ff2d24e1d` |
| Montador observado `hero_engine/phase6_media.py` | `a824fdc12b7772b230fcc61661d8a7462c30676250a20b20d3dbe384d6cc19d8` |

Os 90 WAVs foram abertos read-only; bytes completos, hash, frames, sample rate, canais, largura PCM e comprimento do payload correspondem aos registros do manifesto. O diagnóstico inclui os 90 bindings individuais, os hashes da implementação/schema e os objetos canônicos de entrada. Não usa um manifesto de outra renderização e não altera `latest` operacional.

## Resultado calculado e limites

| Medida | Resultado |
|---|---:|
| Takes visuais / chamadas de síntese históricas | 90 |
| Fronteiras entre takes | 89 |
| Fronteiras sem final explícito de frase | 39 |
| Unidades de narração propostas | 51 |
| Horizonte visual preservado | 279.600 ms |
| Soma das durações dos WAVs históricos | 205.119 ms |
| Padding total histórico, pela soma `slot − WAV` | 74.481 ms |
| Padding histórico nas 39 fronteiras sem final de frase | 36.146 ms |
| Ambiguidade de pontuação/velocidade detectada neste conjunto | 0 unidades |
| Duração/encaixe/pausas da nova síntese | `null`, não sintetizado |

Os inteiros de padding utilizam as durações arredondadas do manifesto. Cada fronteira também registra o valor exato derivado de `frame_count / sample_rate`, com seis casas decimais. **Padding não é medição de silêncio acústico nem nota de naturalidade.** Os WAVs podem conter pausas internas; música e efeitos podem ocupar a mesma janela. Esta prova não mede isso e não declara aprovação sonora.

### Quebras identificadas e agrupadas

| Fronteira visual | Texto interrompido | Padding histórico | Proposta |
|---|---|---:|---|
| take-013 → 014, 42.900 ms | `In the first,` → `write only what happened.` | 1.196 ms (exato 1.195,666667) | Unidade 011, 40.700–45.500 ms |
| take-015 → 016, 47.700 ms | `In the second,` → `write what fear says it means.` | 1.121 ms (exato 1.120,666667) | Unidade 012, 45.500–50.600 ms |
| take-020 → 021, 64.800 ms | `...about your` → `identity.` | 1.188 ms | Unidade 016, 59.900–67.000 ms |
| take-057 → 058, 183.400 ms | `...after the` → `result.` | 871 ms (exato 870,666667) | Mesma unidade contínua |
| take-059 → 060, 191.600 ms | `...which stories` → `only exhausted you.` | 1.563 ms (exato 1.562,666667) | Mesma unidade contínua |

O relatório JSON contém todas as 89 fronteiras e as 51 unidades, não somente os exemplos acima. Cada unidade retém os tempos visuais como limites, não os transforma em timestamps de palavras.

## O que já funciona e o que não está provado

- `build_narration_unit_plan` é determinístico e puro: sem arquivos, subprocessos, modelos, rede ou fila. As entradas não são mutadas.
- `verify_narration_unit_plan` recompõe todos os campos; alteração de texto, contagem, horizonte, flags ou timestamps falha, mesmo com rótulos de aprovação editados.
- O schema proíbe duração sintetizada, word timestamps, encaixe aprovado e autorização de síntese/render/publicação nesta classe de artefato.
- O diagnóstico CLI valida schemas, vínculo de script/TakePlan, WAVs e a fórmula do montador; escreve somente arquivo imutável de diagnóstico em pasta isolada.
- As 51 unidades não foram sintetizadas. Não existe redução medida de custo, latência, silêncio, intervenção ou taxa de retrabalho; a menor contagem de chamadas é apenas mudança de plano.
- Manter o horizonte original pode apenas deslocar espaço ocioso para o fim de frases. É preciso avaliar pacing real; não preencher todo o espaço com pausas automaticamente nem presumir que agrupar a fala resolve o vídeo.
- A heurística usa pontuação, não é avaliador completo de sintaxe/semântica; zero ambiguidades detectadas não significa zero defeito linguístico.

## Integração mínima futura, sem pular gates

1. Gestor produz nova ordem de remediação explicitamente compatível com a mudança de unidade de voz; mantém o protocolo, copy, identidade, modelo, velocidades, direitos, horizonte e custo. D-138 de correção somente visual não autoriza mudar áudio. Preservar job `SUCCEEDED`, seus bytes e histórico.
2. Compilador produz `NarrationUnitPlan` ligado ao TakePlan/roteiro/candidato exatos, incluindo os bindings raw/hash. Preflight revalida estrutura, identidade, continuidade, escolha visual e capacidade da receita nova antes de autorizar trabalho local.
3. Sintetizador local recebe uma fala completa por unidade, com o modelo/voz/velocidade fixados. Materializa novos WAVs/manifesto em namespace próprio; faz prova de encaixe da unidade inteira. Nunca soma WAVs antigos para fingir prova de prosódia nova e nunca usa estimativa como gate positivo.
4. Alinhamento observado de palavras/frases reconcilia os eventos visuais, captions e narração. Sem timestamps reais, não assumir que a segunda metade da fala começa no antigo corte visual; conflito deve bloquear ou produzir revisão controlada de composição.
5. Prova curta dos trechos críticos testa inteligibilidade, pronúncia, continuidade, pausas, pacing, loudness, clipping e sincronização, por avaliador separado do produtor e padrão-ouro aplicável. Manter duração e reavaliar o espaço ocioso é parte do teste, não resultado presumido.
6. Só depois executar render completo em geração nova, QA independente integral, congelamento, release gate, publicação private-first e verificação pública; todos os bindings e receipts permanecem obrigatórios.

## Testes e Done when desta subtarefa

Comando focal: `.venv\Scripts\python.exe -m unittest tests.test_phase6_narration_units tests.test_phase6_two_column_recipe -v`.

Resultado observado: **17/17 PASS em 1,140 s**, dos quais nove testes do planejador e oito testes da composição de duas colunas. É regressão focal, não manutenção integral nem prova de runtime.

Comando do diagnóstico: `.venv\Scripts\python.exe -m hero_engine.phase6_narration_units --diagnostic`. Resultado: 90 WAVs verificados, relatório acima, `PLANNED_NOT_SYNTHESIZED`, custo técnico adicional R$ 0,00.

| Critério delimitado | Estado / prova |
|---|---|
| `your | identity` identificado e agrupado | PASS, unidade 016 real e teste adversarial |
| Copy e horizonte preservados | PASS, recomposição de 90 fragmentos e 279.600 ms |
| Corte visual não força reset de prosódia na proposta | PASS estrutural, zero resets impostos; áudio futuro indisponível |
| Modelo, voz e velocidade preservados | PASS contratual; mudança interna de velocidade gera NEEDS_REVIEW |
| Duração nova não fabricada | PASS, duração/encaixe/word timestamps `null` e schema restritivo |
| Nenhum efeito operacional | PASS de escopo: novos módulo/schema/testes/doc/diagnóstico; fontes somente lidas |
| Qualidade sonora corrigida de ponta a ponta | NÃO REALIZADO; exige integração, síntese e QA acima |

Arquivos desta entrega: `hero_engine/phase6_narration_units.py`, `schemas/phase6_narration_unit_plan.schema.json`, `tests/test_phase6_narration_units.py`, este relatório e o JSON diagnóstico imutável. Documentos globais, fase, filas e estado operacional ficam sob responsabilidade do Gestor principal.

## Adendo — três unidades sintetizadas por ordem diagnóstica distinta

O Gestor autorizou expressamente uma prova local delimitada das unidades 011, 012 e 016 após o diagnóstico. Essa ordem não altera o `PLANNED_NOT_SYNTHESIZED` do plano das 51 unidades nem concede autoridade de produção. Runner novo: `scripts/prove_phase6_narration_units.py`; testes novos: `tests/test_phase6_narration_unit_proof.py`. Nenhum módulo operacional existente foi alterado.

### Preflight e resultado real

Pasta: `output/qa/phase6/diagnostics/narration-unit-proof-20260906T044549920068Z`.

Receipt `receipt.json`, SHA-256 `d47bb7ace0942d5ba5c624d7074d9a22962ee8234ec0ba3a3b6e2f01604ae99c`; estado `PRODUCED_PENDING_INDEPENDENT_REVIEW`. São 31 arquivos, 30 deles hash-bound pelo receipt final, incluindo ordem, preflights, três WAVs novos, comparadores históricos/contínuos e comandos/logs do FFmpeg. Não houve resíntese por tentativa, alteração de velocidade, render de vídeo, API, fila ou publicação.

- RAM disponível antes de carregar o modelo: 1.491.779.584 bytes; exigência estimada + reserva: 1.219.197.154 bytes. A fórmula conservadora está no receipt; não é medição do pico real.
- Disco livre: 24.036.524.032 bytes; pico novo estimado 21.673.216; reserva mínima 5.368.709.120 bytes (5 GiB); headroom depois da estimativa e reserva 18.646.141.696 bytes.
- Modelo, banco de vozes e eSpeak exatos foram verificados; versões locais registradas. Cada fala possui um único batch, com 38/44/77 fonemas/tokens, abaixo de 510. O limite foi checado para as três antes da primeira síntese para impedir o caminho de truncamento do adapter.
- Três novas chamadas Kokoro; `am_onyx`, speed `1.06`, 24 kHz/mono/PCM16; zero clipping. Tempo total 48,018153 s, dos quais síntese 6,207278 + 6,430187 + 9,101258 s. Não extrapolar para o lote completo.

| Unidade | Novo WAV / duração medida | Janela preservada | SHA-256 do WAV |
|---|---|---:|---|
| 011 | `staged/narration-unit-011.wav`, 2.496,000 ms | 4.800 ms | `7c6addc0cdfdc8ff31845e740e84ba63693aeb63058fed2d5e0af1d558d1830a` |
| 012 | `staged/narration-unit-012.wav`, 2.901,333333 ms | 5.100 ms | `77a41295283efe22341cd6b71e57462ce36ba3ff461d838402f0ce8c61cee9b9` |
| 016 | `staged/narration-unit-016.wav`, 4.373,333333 ms | 7.100 ms | `89a69734d5f766ac0a7c28115f1df849de523743601184694cef9eee50e4ab8d` |

### Comparação acústica objetiva e contrapartida

FFmpeg `silencedetect`, limiar `−40 dB`, duração mínima `100 ms`, em PCM cru comparável antes de EQ/mix/masterização. O histórico foi recomposto com os WAVs exatos + padding de cada take. O novo comparador acrescenta somente padding final, sem cortar ou alterar os samples sintetizados. O detector não conhece palavras, intenção de pausa ou qualidade perceptual.

| Unidade | Silêncio interno histórico | Silêncio interno novo | Silêncio final novo com janela preservada | Silêncio total histórico → novo |
|---|---:|---:|---:|---:|
| 011 | 1.469,417 ms | 0 ms detectado | 2.859,917 ms | 2.647,959 → 2.859,917 ms |
| 012 | 1.329,416 ms | 0 ms detectado | 2.741,458 ms | 2.405,416 → 2.741,458 ms |
| 016 | 1.902,875 ms | 0 ms detectado | 3.353,542 ms | 3.265,708 → 3.353,542 ms |

Há evidência de remoção das pausas internas longas segundo esse detector, **não de aprovação completa de prosódia ou melhoria do ritmo global**. Ao preservar o horizonte, o silêncio final aumentou; a operação não pode apenas substituir os WAVs e considerar o problema encerrado. Além disso, os próprios WAVs novos contêm caudas silenciosas detectadas de 555,917/542,791/626,875 ms. Mantiveram o comportamento `trim=True` do adapter existente; não houve truncamento para forçar encaixe.

Nenhuma escuta independente, ASR de fidelidade ou alinhamento de palavras foi executado nesta subtarefa. Word timestamps seguem `null`; não foi demonstrado em que instante a palavra `identity` ocorre nem se as mudanças visuais continuam sincronizadas. É necessário revisar os WAVs e a alocação temporal dentro da janela, respeitando o protocolo e sem sintetizar ou encurtar o vídeo por autorização implícita.

Testes antes da síntese: `.venv\Scripts\python.exe -m unittest tests.test_phase6_narration_unit_proof tests.test_phase6_narration_units -v`, **17/17 PASS em 0,520 s** (oito do runner e nove do planejador; grupo sobreposto ao anterior, não somar como testes únicos). Cobertura inclui limite de capacidade byte a byte, preservação de copy/speed/janela, fonema excessivo antes da síntese, nenhuma evidência parcial promovida, PCM não truncado e detecção temporal sem aprovação perceptual. Execução real única: `.venv\Scripts\python.exe scripts/prove_phase6_narration_units.py`, exit 0.

### Contraprova principal e indisponibilidade de escuta

O responsável principal reportou contraprova independente de 30/30 hashes dos artefatos e dos frames/sample rate/peak/clipping dos três PCM, todos idênticos. Sua tentativa de fornecer áudio por MP3 diagnóstico recebeu a resposta explícita `audio content omitted because you do not support audio input`. **Não houve escuta pelo responsável principal; isso não produz PASS perceptual.** O bloqueio da ferramenta de escuta não foi contornado nem disfarçado como revisão sonora.

A leitura principal da ordem/protocolo também confirmou uma distinção importante: o tratamento congela a banda de duração `207750–286250 ms`, não obriga que toda nova versão dure exatamente `279600 ms`. Esta prova D-141 preserva os slots anteriores exclusivamente para comparação controlada. Um retiming futuro exige classe/ordem explícita com preservação da banda, voz, copy e experimento, novas provas de alinhamento/capacidade e gates; não é autorizado silenciosamente por este diagnóstico. O padding final atual continua inadequado como solução presumida.

## Inventário local de ASR/alinhamento — sem carregar modelos

Inspeção read-only identificou:

- `faster-whisper 1.2.1`, licença MIT registrada em `.venv/Lib/site-packages/faster_whisper-1.2.1.dist-info/METADATA` e `LICENSE`.
- `CTranslate2 4.8.2`, licença MIT em seu `METADATA` local.
- Cache do modelo `base.en` presente em `C:/Users/mathe/.cache/huggingface/hub/models--Systran--faster-whisper-base.en/snapshots/3d3d5dee26484f91867d81cb899cfcf72b96be6c`. O ref `main` local aponta para esse commit. Os quatro arquivos foram lidos/hashados, não carregados em memória como modelo.

| Arquivo do snapshot | Bytes | SHA-256 observado |
|---|---:|---|
| `model.bin` | 145.216.508 | `2a166925539a16005f14ff328359f9b9adb9dc4fb631bb3b227526862e93e2ef` |
| `config.json` | 2.227 | `f3bc3821e9fc76a27bae538e11ae5b677dcdd352b4600429ce7951d398569aeb` |
| `tokenizer.json` | 2.128.466 | `929c5252409436dce1b38a75d1abbcb5e132d170d8e324e4e04ed915fa2d22df` |
| `vocabulary.txt` | 422.309 | `ff77588746d3a2595d32ab5b69ffd7b95ce2441ac57533cb66fc3eb575a115cf` |

Esses são hashes **observados nesta auditoria**, não uma nova autorização/permanente pinagem do adapter. A licença dos pesos/model card não está arquivada no snapshot de quatro arquivos; a licença MIT do software não é prova isolada da licença dos pesos. O pipeline principal usa o nome `base.en` e não impõe hoje esses hashes; uma prova nova precisa prendê-los explicitamente e registrar a licença aplicável antes de declarar conformidade do modelo.

Rotas existentes:

1. `hero_engine/phase5_autonomous_quality.py::_asr` já solicita `word_timestamps=True`, mas descarta a lista de palavras e retorna somente texto agregado. Não basta para sincronizar a próxima composição.
2. `hero_engine/mining/adapters.py::TranscriptAdapter` preserva palavras, início/fim e confiança; o construtor atual aceita nome do modelo sem `local_files_only`, portanto não deve ser usado sem endurecimento na prova sem download.
3. O código instalado de `faster_whisper/transcribe.py` aceita diretório local explícito e `local_files_only=True`. Com o snapshot exato, `device='cpu'`, `compute_type='int8'` e preflight de RAM/modelo/arquivos, existe rota técnica local para transcrever as três frases e capturar timestamps, sem API ou download. Não foi executada neste inventário.

Não apareceu instalação/modelo de WhisperX, alinhador CTC dedicado, `whisper_timestamped`, aeneas ou stable-whisper no inventário de `site-packages`. Isso é ausência observada nesse ambiente, não afirmação de que são as únicas opções existentes.

Próxima prova proposta ao Gestor: ASR independente sem texto de referência como prompt, guardar segmentos/palavras/confianças e confrontar lexicalmente com a copy exata; só depois usar alinhamento para retiming. Timestamps do ASR são estimativas do modelo e precisam ser confrontados com o sinal acústico, não uma autorização automática de cortes. Nenhuma inferência ASR, novo modelo, instalação, download, API ou mudança de runtime foi feita aqui.

## Adendo ASR — licença arquivada e primeira tentativa bloqueada antes do modelo

O Gestor autorizou posteriormente três transcrições locais independentes. Foram criados `scripts/prove_phase6_narration_asr.py` e `tests/test_phase6_narration_asr_proof.py`, sem alterar os executores operacionais. O runner fixa os quatro hashes do snapshot existente, caminho local absoluto, CPU/int8, dois threads e um worker, `local_files_only=True`, variáveis offline e bloqueio de conexões Python durante a inferência. Não envia texto esperado, `initial_prompt` ou `hotwords`; a comparação de palavras só ocorre depois da transcrição. Toda palavra mantém a classe `ASR_ESTIMATED_NOT_WORD_TRUTH`.

As fontes oficiais foram reabertas e arquivadas **antes** de qualquer carregamento de modelo. A página [Systran base.en](https://huggingface.co/Systran/faster-whisper-base.en) declara MIT e identifica a conversão do modelo OpenAI; o [README oficial do Whisper](https://raw.githubusercontent.com/openai/whisper/main/README.md) inclui expressamente código e pesos na licença; o [LICENSE oficial](https://raw.githubusercontent.com/openai/whisper/main/LICENSE) foi preservado integralmente como artefato de licença. Isso fecha a lacuna documental do inventário anterior, sem editar seu registro histórico nem baixar pesos.

Pasta da primeira tentativa: `output/qa/phase6/diagnostics/narration-asr-proof-20260906T045706142567Z`.

| Documento oficial arquivado | UTC da coleta | SHA-256 |
|---|---|---|
| `license-evidence/systran-model-card.html` | 2026-09-06 04:57:09.335377 | `a9ed318b8459d9068b775d49df7548679e644357fd22f65351b862dec3735b16` |
| `license-evidence/openai-whisper-readme.md` | 2026-09-06 04:57:10.872460 | `38c180c2a8d8ba628a3e131ad42bf06c8a51bb681efb30fbe28d5a0f4b65f288` |
| `license-evidence/openai-whisper-license.txt` | 2026-09-06 04:57:11.425047 | `b5d65a59060e68c4ff940e1eddfa6f94b2d68fdf58ed7f4dd57721c997e35e9d` |

`license-evidence/receipt.json` guarda URLs, timestamps, status HTTP 200, tamanho e hash. Foram somente três leituras HTTP públicas de documentação, zero peso/dependência baixado e zero custo técnico adicional.

O preflight real encontrou **578.502.656 bytes de RAM disponíveis para exigência de 972.520.436 bytes**. Disco de 23.799.050.240 bytes atendia à reserva de 5 GiB. A tentativa foi bloqueada por memória **antes de importar/carregar faster-whisper**, preservando `preflight.json` e `failure.json`; nenhum ASR foi executado nessa tentativa. O piso não foi reduzido e nenhum processo/aplicativo do usuário foi interrompido.

Testes prévios: `.venv\Scripts\python.exe -m unittest tests.test_phase6_narration_asr_proof tests.test_phase6_narration_unit_proof tests.test_phase6_narration_units -v`, **24/24 PASS em 0,750 s**, dos quais sete do runner ASR. Incluem negação de conexão, restauração de ambiente, ausência de prompt esperado, modelo de comparação posterior, limites de memória/disco, fonte de licença ausente/redirect estrangeiro, timestamps inválidos e transcrição vazia. São provas focais de código, não transcrição real nem aprovação de áudio.

## Adendo ASR — três transcrições reais preservadas, com duas divergências

Depois do término confirmado da prova paralela do hook, a única rechecagem de RAM autorizada encontrou 1.365.172.224 bytes disponíveis, acima do piso inalterado de 972.520.436 bytes. Nenhum processo de usuário foi interrompido. A tentativa seguinte, `narration-asr-proof-20260906T045958389491Z`, passou no preflight e executou a primeira transcrição, mas não conseguiu serializar um escalar NumPy no JSON. O erro e o preflight foram preservados; não houve receipt de sucesso nem transcrição parcial promovida. O primeiro resultado desse processo não foi reapresentado como evidência persistida. Portanto, a sequência inteira teve **uma inferência perdida por erro de serialização, além das três inferências finais**, e não deve ser anunciada como execução sem retrabalho.

O runner passou a converter os valores NumPy para `float`/`bool` nativos antes da serialização; o teste de regressão reproduz `float32`, `float64` e `np.bool_` reais e confirma `json.dumps`. A contagem de tentativas passou a ser registrada. Um erro de indentação introduzido durante esse ajuste foi identificado e corrigido pelos testes antes da execução final; não causou inferência adicional. Esses registros permanecem separados dos artefatos anteriores, que não foram reescritos.

### Prova final concluída

Pasta: `output/qa/phase6/diagnostics/narration-asr-proof-20260906T050236371078Z`.

Receipt `receipt.json`, SHA-256 **`6a431a875b8a9bbe88c98750de3f7ada672ec335c65f452afbee931ad2961457`**. Estado `OBSERVED_PENDING_INDEPENDENT_REVIEW`, três resultados completos arquivados, três tentativas de transcrição, zero tentativa de rede durante a inferência e zero download de peso. Houve três leituras HTTP públicas de documentação de licença antes do modelo, não chamadas de inferência externa. Custo técnico adicional R$ 0,00; tempo total 16,427174 s. Não ocorreu nova síntese Kokoro, render ou alteração de timeline.

O preflight final observou 1.368.027.136 bytes de RAM disponível e 23.816.409.088 bytes de disco livre; exigência de RAM 972.520.436 bytes, estimativa de disco novo 16.777.216 bytes e reserva de disco 5 GiB. Os quatro hashes do modelo e os três WAVs de origem foram revalidados. O receipt prende nove artefatos por SHA-256, incluindo transcrições, comparação, preflight e fontes de licença. O SHA do runner executado foi `8ebb0cf35b9f75a227f05892cf5efc32c7ba54e0d666f156eb5451eb1961bc4d`.

| Unidade | Resultado reconhecido independente | Comparação lexical normalizada | Estado |
|---|---|---|---|
| 011 | `in the first right only what happened.` | 7 palavras; substituição `write → right`; WER 0,142857 | `TRANSCRIPTION_MISMATCH_NEEDS_REVIEW` |
| 012 | `In the second, write what fear says it means.` | 9 palavras; zero edições; WER 0 | `ALL_NORMALIZED_WORDS_MATCH` |
| 016 | `I will always be abandoned as a sentence fear wrote about your identity.` | 13 palavras; substituição `is → as`; WER 0,076923 | `TRANSCRIPTION_MISMATCH_NEEDS_REVIEW` |

`write/right` são homófonos em inglês, portanto a divergência pode ser ortográfica do reconhecedor; isso é uma hipótese, não aprovação automática da fala. `is/as` também permanece uma divergência não resolvida, sem atribuir sua causa ao sintetizador ou ao ASR por suposição. Nenhuma média global elimina essas duas pendências. A frase 012 demonstrou concordância lexical do reconhecedor, **não perfeição fonética, entonação ou qualidade perceptual**. A opção `language='en'` foi fixada; o campo `language_probability=1.0` retornado não constitui confiança independente de identificação de idioma.

### Posições de palavras: estimativas, não alinhamento-verdade

Todos os tempos abaixo são relativos ao começo do novo WAV da respectiva unidade e carregam `ASR_ESTIMATED_NOT_WORD_TRUTH`:

| Unidade / palavra | Intervalo estimado | Probabilidade retornada pelo modelo |
|---|---:|---:|
| 011 / `right` (referência: `write`) | 480–800 ms | 0,633839 |
| 012 / `write` | 780–820 ms | 0,964638 |
| 016 / `as` (referência: `is`) | 1.060–1.360 ms | 0,656416 |
| 016 / `your` | 2.880–3.060 ms | 0,993986 |
| 016 / `identity` | 3.060–3.400 ms | 0,991370 |

O reconhecedor preservou `your identity`, sem deleção nessa região. Isso oferece evidência lexical independente complementar à detecção de silêncio, mas não prova ausência absoluta de truncamento ou o instante acústico exato. O intervalo de apenas 40 ms para `write` da unidade 012 ilustra por que os timestamps não podem ser consumidos como corte exato sem contraprova acústica. As probabilidades são saídas internas do modelo, não probabilidades calibradas de qualidade.

A duração reportada pelo ASR difere ligeiramente do contador de samples em duas unidades: 2.901,375 ms versus 2.901,333333 ms; 4.373,375 ms versus 4.373,333333 ms. O PCM medido continua sendo a fonte de verdade de duração. Nenhum timestamp do ASR foi fora da duração nessa amostra, mas isso não valida automaticamente cada palavra. A unidade 016 começa no slot antigo de 59.900 ms: a soma estimada posiciona `identity` em 62.960–63.300 ms, antes do antigo corte visual em 64.800 ms. **Substituir somente o áudio deixaria o corte visual antigo desacoplado dessa estimativa de fala**; a timeline precisa de decisão explícita e verificação própria, não troca cega de WAV.

### Resultado delimitado e congelamento

Testes focais finais, antes da inferência final: `.venv\Scripts\python.exe -m unittest tests.test_phase6_narration_asr_proof tests.test_phase6_narration_unit_proof tests.test_phase6_narration_units -v`: **25/25 PASS em 0,812 s** (oito ASR, oito prova de voz, nove planejador; sobrepostos aos grupos anteriores). A execução real final do runner terminou com exit 0; o sucesso é de captura/transcrição e preservação da evidência, não de aprovação do áudio.

Os novos runners/testes e este relatório são entregues ao Gestor principal congelados para uma única regressão/manutenção integrada. Permanecem pendentes revisão das divergências, contraprova acústica/alinhamento, decisão de pacing/retiming dentro da banda autorizada, integração transacional e todos os gates audiovisuais posteriores. Não há escuta humana ou pelo modelo desta sessão, aprovação perceptual, autorização de retiming/produção/publicação, nova regra aprendida nem solução operacional completa. Nenhuma das outras 48 unidades foi sintetizada ou transcrita nesta prova. Nenhum arquivo global, áudio de produção, TakePlan, fila ou runtime foi alterado por esta subtarefa.
