# 02 — Especificação de mineração minuciosa

Regra transversal: YPP-INAUTHENTIC-2025-07-15 em `08_POLICY_AND_RIGHTS.md`.
Tração/outlier não comprovam autenticidade ou monetização. Extrair mecanismos
com proveniência/coortes, sem baixar biblioteca de candidatos nem copiar obras.
Registrar risco de produção genérica/reutilização sem afirmar infração não provada.

## 1. Objetivo

Converter cada vídeo em uma representação estruturada, temporal, visual, sonora, narrativa e produtiva. O minerador deve permitir reconstruir o mecanismo do vídeo sem depender de um resumo subjetivo.

## 2. Entrada mínima

- identificador do vídeo;
- canal e plataforma;
- URL de referência, quando aplicável;
- arquivo local ou acesso autorizado à mídia para processamento;
- título, thumbnail e data;
- duração;
- idioma;
- status de direitos/licença;
- snapshots públicos disponíveis;
- hash do arquivo processado.

Entradas sem status de direitos podem ser analisadas como referência pública, mas não entram automaticamente na biblioteca de produção.

## 3. Etapas obrigatórias

### 3.1 Inspeção técnica

Use `ffprobe` ou equivalente para registrar:

- container e codecs;
- duração real;
- resolução e proporção;
- FPS;
- bitrate;
- canais e taxa do áudio;
- presença de legendas;
- integridade básica.

### 3.2 Transcrição temporal

Extraia:

- fala por segmento;
- timestamps de início e fim;
- palavras quando o motor suportar;
- pausas relevantes;
- velocidade aproximada da fala;
- idioma detectado;
- confiança;
- trechos incertos.

Nunca corrija silenciosamente uma transcrição. Preserve a saída bruta e grave a versão revisada separadamente.

### 3.3 Detecção de takes

Detecte cortes rápidos, fades e mudanças significativas. Para cada take:

- `take_id`;
- início, fim e duração;
- keyframe inicial, central e final;
- descrição objetiva;
- pessoa, objeto, ambiente e ação;
- escala do plano;
- movimento de câmera ou elemento;
- texto visível;
- fala correspondente;
- tipo de transição;
- função narrativa;
- função de retenção;
- origem do ativo, quando conhecida;
- evidências.

Detecção automática é hipótese. No padrão-ouro, limites de take devem ser revisados manualmente.

### 3.4 OCR e elementos de tela

Extraia por frame ou take:

- texto;
- posição;
- tamanho relativo;
- cor e contraste aproximados;
- entrada e saída;
- relação com a fala;
- função: legenda, prova, título, CTA, contexto ou decoração.

### 3.5 Hook dos primeiros segundos

Analise separadamente:

- `0–1 s`;
- `1–3 s`;
- `3–8 s`;
- `8–30 s` para vídeos longos.

Para cada janela:

- primeiro e último quadro;
- fala exata;
- texto na tela;
- quantidade de mudanças visuais;
- ação principal;
- áudio, música e efeitos;
- promessa explícita e implícita;
- curiosidade aberta;
- emoção;
- padrão interrompido;
- informação entregue;
- informação retida;
- alinhamento com título e thumbnail;
- motivo provável para continuar;
- risco de quebra de promessa;
- evidências e confiança.

Não aceite rótulos vagos como “hook forte”. Descreva o mecanismo observado.

### 3.6 Segmentação narrativa

Divida o vídeo em blocos funcionais, independentemente dos takes:

- hook;
- confirmação da promessa;
- contexto;
- conflito ou tensão;
- desenvolvimento;
- prova;
- escalada;
- micro-payoff;
- reabertura de curiosidade;
- payoff principal;
- CTA;
- encerramento.

Para cada bloco, registre início, fim, objetivo, informação, emoção, pergunta aberta, prova, transição e função de retenção.

### 3.7 Embalagem

Analise título e thumbnail como unidade:

- audiência acionada;
- desejo, medo ou curiosidade;
- promessa;
- informação revelada e omitida;
- contraste;
- benefício e risco;
- complementaridade;
- possível expectativa criada;
- correspondência com o início e o payoff.

### 3.8 Conteúdo e produção

Extraia:

- tema e subtema;
- ângulo;
- tese;
- público provável;
- nível de consciência;
- tipo de narrativa;
- emoção predominante;
- densidade de informação;
- ritmo de cortes;
- tipos de cena;
- proporção entre fala, texto, prova e apoio visual;
- trilha, efeitos e silêncio;
- estrutura de CTA;
- complexidade e custo provável;
- requisitos de ativos.

### 3.9 Desempenho público

Registre snapshots, não apenas o valor atual:

- data/hora;
- idade do vídeo;
- views;
- likes e comentários quando disponíveis;
- inscritos públicos do canal quando disponíveis.

Derivações permitidas:

- velocidade entre snapshots;
- desempenho relativo à mediana do canal;
- relação views/inscritos como proxy pública;
- persistência ao longo do tempo;
- posição na distribuição do canal.

Não inferir CTR, retenção, RPM ou receita como fatos.

## 4. Classes de evidência

- `OBSERVED`: lido diretamente.
- `CALCULATED`: fórmula sobre observados.
- `INFERRED`: interpretação do sistema.
- `PRIVATE`: métrica autenticada de canal próprio.
- `UNKNOWN`: não há base suficiente.

Cada campo inferido deve possuir `confidence`, `reasoning_summary` e `evidence_refs`.

## 5. Padrão-ouro

Antes de processamento em lote:

1. selecione poucos vídeos representativos e autorizados;
2. faça anotação manual completa;
3. revise hooks e limites de takes frame a frame;
4. aprove o JSON e o relatório humano;
5. congele-os como fixtures;
6. implemente o minerador;
7. compare saída automática e padrão-ouro;
8. corrija até aprovação humana;
9. só então libere lote.

O padrão-ouro deve incluir ao menos diferenças de formato, ritmo e duração. Quantidade final será definida pela fase após avaliar a variabilidade.

## 6. Saídas

- JSON válido conforme `schemas/video_mining.schema.json`;
- relatório legível;
- transcrição bruta e revisada;
- manifesto de keyframes;
- manifesto de takes;
- referências de evidência;
- log de ferramentas e versões;
- relatório de incertezas;
- status de direitos separado do resultado editorial.

## 7. Critérios de aceitação

- schema válido;
- duração e timecodes consistentes;
- hooks obrigatórios preenchidos;
- takes sem sobreposição inválida e com cobertura explicada;
- evidências resolvíveis;
- transcrição bruta preservada;
- fatos e inferências separados;
- nenhum direito presumido;
- comparação com padrão-ouro documentada;
- execução reproduzível.

## 8. Ferramentas local-first sugeridas

- FFmpeg/ffprobe: mídia e renderização;
- PySceneDetect: candidatos a corte;
- OpenCV: frames e características visuais;
- Whisper ou faster-whisper: transcrição;
- Tesseract: OCR;
- Python: orquestração e validação;
- JSON Schema: contratos;
- SQLite no piloto e banco configurável na escala.

Ferramenta pode ser substituída por adapter desde que a saída continue cumprindo o schema.

## 9. Qualidade do minerador sob o Gestor Central

O minerador será executor subordinado. Versão, parâmetros, entradas, custos, latência e evidências acompanham cada saída. Sua evolução será aceita somente por comparação contra padrão-ouro humano versionado, campo a campo: timestamps, transcrição, OCR, hooks por janela, limites/função dos takes, narrativa, embalagem, direitos/proveniência e validade de schema.

Uma versão challenger não substitui a champion por opinião. Deve superar os thresholds aprovados sem regressão crítica, com fixture fixa e registro de erro, cobertura, amostra, custo e limitações. Sem nova evidência, o Gestor registra `NO_NEW_EVIDENCE`.
