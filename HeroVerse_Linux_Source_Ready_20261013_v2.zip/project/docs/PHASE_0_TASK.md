# PhaseTask — Fase 0

## Controle

- `phase_id`: `0`
- `task_id`: `phase-0-audit-and-contract-incorporation`
- `status`: `AWAITING_REVIEW`
- `authorized_by`: usuário, ao solicitar a execução severa do prompt mestre do ZIP
- `authorized_at`: `2026-09-02`

## Objetivo único

Auditar o HERO Engine existente e incorporar o contrato do kit mestre sem apagar trabalho válido, implementar código de domínio ou liberar a fase seguinte.

## Contexto obrigatório

- documentos: `AGENTS.md`, `PLANS.md`, todos os arquivos de `docs/`, `schemas/`, `templates/` e `prompts/`;
- componentes existentes: `hero_engine/`, `config/`, `data/`, `scripts/`, `tests/`, `tools/`, `output/` e `outputs/`;
- decisões relacionadas: D-001 a D-010 em `docs/DECISIONS.md`.

## Entradas

| Entrada | Local | Obrigatória | Validação | Direitos/credencial |
|---|---|---:|---|---|
| Kit mestre | `C:\Users\mathe\Downloads\kit_canais_dark_codex_v1.zip` | sim | 29 arquivos instalados; caminhos validados | fornecido pelo usuário |
| Projeto existente | raiz do workspace | sim | mapa, testes, banco e artefatos inspecionados | dados locais do projeto |
| Banco do motor | `data/hero_engine.db` | sim | schema e contagens lidos | nenhuma credencial |
| Mídia e renders | `data/downloads/` e `output/renders/` | não para alterar; sim para auditar | existência, tamanho e SHA-256 | direitos não presumidos |

## Saídas

| Saída | Caminho | Formato/schema | Consumidor |
|---|---|---|---|
| Auditoria | `docs/PHASE_0_AUDIT.md` | Markdown | usuário e fases seguintes |
| Plano adaptado | `docs/PHASE_1_PLAN.md` | estrutura de `PLANS.md` | Fase 1, ainda não autorizada |
| Estado | `docs/STATE.md` | máquina de estados | executor |
| Decisões | `docs/DECISIONS.md` | registro permanente | projeto |
| Contratos | `AGENTS.md`, `schemas/`, `templates/`, `prompts/`, `docs/` | arquivos do kit | Codex e validações |

## Fora de escopo

- criar ou alterar o minerador, modelador, produtor, renderizador ou publicador;
- minerar novos vídeos;
- aprovar direitos;
- publicar, aprovar produção ou mudar `dry-run`;
- instalar dependências, plugins ou serviços;
- iniciar a Fase 1.

## Passos permitidos

1. ler integralmente o kit;
2. inventariar e testar o estado atual;
3. incorporar documentos sem sobrescrever o projeto;
4. registrar lacunas, conflitos, riscos e plano da fase seguinte;
5. parar no gate humano.

## Ações proibidas nesta fase

- iniciar a fase seguinte;
- publicar;
- gerar custos não autorizados;
- remover requisitos;
- substituir dado real por mock sem rótulo.

## Critérios de aceitação

- [x] nenhum código de domínio novo;
- [x] nenhuma conclusão relevante sem inspeção ou evidência;
- [x] decisões e artefatos existentes preservados ou sinalizados;
- [x] mapa, inventário, lacunas, conflitos, stack, comandos e riscos documentados;
- [x] contratos e schemas incorporados sem sobrescrever o README operacional;
- [x] testes atuais executados: 14/14 aprovados;
- [ ] usuário aprovou a Fase 0 e autorizou expressamente a Fase 1.

## Testes obrigatórios

- [x] unitários atuais;
- [x] integração local de leitura via CLI e SQLite;
- [x] parsing dos três JSON Schemas;
- [x] comparação estrutural entre schemas novos e artefatos legados;
- [x] exemplos reais locais inspecionados;
- [x] revisão das alterações documentais por inventário e hashes;

## Evidências esperadas

- relatório `docs/PHASE_0_AUDIT.md`;
- execução de 14 testes com status `OK`;
- contagens reais do SQLite;
- relatório das chaves obrigatórias ausentes nas saídas legadas;
- backup com caminho, tamanho e SHA-256 registrados.

## Condição de parada

A Fase 0 está em `AWAITING_REVIEW`. Nenhuma atividade da Fase 1 pode começar até aprovação expressa do usuário.
