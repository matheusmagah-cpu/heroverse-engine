# Aceitação — Gestor Central Autônomo

## Estado

O estado deixou de ser documental. A fonte operacional é `output/operations/phase6/acceptance-report.json`, validada por `schemas/phase6_acceptance_report.schema.json` e renderizada em `output/operations/phase6/PHASE6_ACCEPTANCE.md`. `PASS_FIXTURE` prova somente o teste controlado nomeado; `PASS_LIVE` prova somente os artefatos vivos listados. A Fase 6 continua `IN_PROGRESS` enquanto qualquer critério obrigatório não atingir sua classe mínima de evidência.

## Testes obrigatórios

| ID | Teste | Evidência mínima | Fase prevista | Estado |
|---|---|---|---:|---|
| GC-01 | Ciclo completo sem transporte manual | observação até nova medição flui por comandos/estados centrais | 6/7 | WAITING_REAL_EVIDENCE |
| GC-02 | Persistência após reinício | estado, fila, memória e versões reaparecem iguais | 3/6 | PASS_LIVE |
| GC-03 | Isolamento entre canais | canal A não lê/escreve dados, identidade ou ativos de B | 3/7 | PASS_FIXTURE |
| GC-04 | Ingestão idempotente | mesmo evento não duplica projeção ou efeito | 2/3 | PASS_FIXTURE |
| GC-05 | Reconstrução completa da decisão | fonte/timecode até comando, artefato e resultado | 3/6 | PASS_LIVE |
| GC-06 | Bloqueio fora do envelope | comando excedente termina bloqueado e auditado | 5/6 | PASS_LIVE |
| GC-07 | Rotina automática dentro do envelope | comando permitido executa sem transporte manual | 6 | PASS_LIVE |
| GC-08 | Dado ausente ou inválido | conclusão é recusada/bloqueada/inconclusiva | 2/4 | PASS_LIVE |
| GC-09 | Hipótese pró e contra | ambas as evidências e falsificação ficam registradas | 4 | PASS_FIXTURE |
| GC-10 | Previsão anterior ao resultado | cutoff comprova registro imutável prévio | 6 | PASS_LIVE |
| GC-11 | Experimento controlado | variável principal, controle, amostra, janela e parada prévias | 6 | WAITING_REAL_EVIDENCE |
| GC-12 | Três avaliações | fixtures favorável, contrária e inconclusiva ficam separadas | 6/7 | PASS_FIXTURE |
| GC-13 | Atualização versionada de regra | transição preserva versões e evidências | 7 | NOT_APPLICABLE_CURRENT_PHASE |
| GC-14 | Aplicação em produção futura | blueprint referencia regra, versão e mudança concreta | 7 | NOT_APPLICABLE_CURRENT_PHASE |
| GC-15 | Medição do efeito aplicado | outcome posterior compara aplicação e baseline | 7 | NOT_APPLICABLE_CURRENT_PHASE |
| GC-16 | Evidência contrária reduz confiança | regra é rebaixada/suspensa/rejeitada sem apagar histórico | 4/7 | PASS_FIXTURE |
| GC-17 | Rollback sem perda de histórico | versão anterior volta por compensação auditável | 7 | NOT_APPLICABLE_CURRENT_PHASE |
| GC-18 | Regressão do minerador | challenger é medido por campo contra gold standard | 2/7 | PASS_LIVE |
| GC-19 | Previsão contra baseline | erro, cobertura e scores aplicáveis superam ou rejeitam modelo | 6/7 | WAITING_REAL_EVIDENCE |
| GC-20 | Relatório executivo | exceções, desempenho, postagens, custos, previsões e decisões | 6 | PASS_LIVE |
| GC-21 | Recuperação após falha | checkpoint/retry/DLQ retomam sem duplicar efeito | 6 | PASS_LIVE |
| GC-22 | Nenhuma estratégia paralela | segundo Gestor/módulo não altera prioridade, regra ou memória | 6/8 | PASS_LIVE |

Snapshot vigente: 10 `PASS_LIVE`, 5 `PASS_FIXTURE`, 3 `WAITING_REAL_EVIDENCE`, 4 `NOT_APPLICABLE_CURRENT_PHASE`, zero `FAIL` e zero `MISSING_EVIDENCE`. Os bloqueios reais da Fase 6 são GC-01, GC-11 e GC-19. GC-14 não foi dispensado: foi corrigido para a Fase 7, onde a Rule Registry, a aplicação em produção posterior e a segunda medição existem sem dependência circular. Testes auxiliares cobrem `NO_NEW_EVIDENCE`, lock/leader election, gate de fase, ação protegida, retry, DLQ e outcomes contraditórios; eles não substituem a evidência viva ainda ausente.

O fechamento não é escrito diretamente pelo auditor. `phase6_transition.py` valida o schema, recompõe contagens, conjunto de aprovados, blockers e suficiência de cada requisito; uma divergência bloqueia. Com zero blockers, ele congela os bytes exatos do aceite, prende o SHA-256 e cria um único receipt imutável 6→7. Antes disso, o estado obrigatório é `WAITING_FOR_PHASE6_GATE` e a Fase 7 não começa.

## Demonstração reproduzível antes do piloto

As fixtures de isolamento, idempotência, bloqueio, outcomes e recovery aplicáveis à Fase 6 passaram e estão ligadas ao receipt integral. Atualização de regra, aplicação posterior, segunda medição, transferência, drift e rollback semântico continuam pertencendo à Fase 7 e não são apresentados como capacidade viva.

## Piloto real posterior

O piloto real está ativo no canário `iK_5edYQtx8`. A publicação, o observador, o forecast retido por falta de calibração, a fila e o painel existem; o experimento de uma variável aguarda o checkpoint D1. Publicação futura continua dependente dos gates e gasto permanece bloqueado.

A avaliação da previsão não depende mais de chamada manual: `phase6_prediction_runtime.py` mantém um job idempotente para o horizonte exato, prende o snapshot de outcome e grava `PredictionEvaluation` imutável. O job real está `PENDING` para `2026-09-05T19:12:01.035029Z`; GC-19 permanece `WAITING_REAL_EVIDENCE` até esse resultado. GC-08 passou a referenciar o snapshot imutável que comprovou nulos preservados, de modo que métricas futuras não apagam a evidência histórica.

## Critério de aceite final

O Gestor só poderá ser declarado real quando todos os testes aplicáveis passarem, o ciclo completo modificar controladamente uma produção futura, a nova medição existir, o efeito e a incerteza forem reportados, rollback/replay funcionarem, os gates permanecerem intactos e o usuário aprovar as evidências.
