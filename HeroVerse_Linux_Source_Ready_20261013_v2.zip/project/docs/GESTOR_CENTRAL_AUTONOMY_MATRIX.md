# Matriz de autonomia — Gestor Central Autônomo

## Regra

O proprietário aprova um envelope versionado. Dentro dele, o Gestor executa rotina e informa por relatório. Fora dele, bloqueia e pede decisão. O Gestor nunca aprova a própria exceção.

| Área | Automático dentro do envelope | Supervisão/alerta | Bloqueado até aprovação explícita |
|---|---|---|---|
| Observação | Coletar fontes permitidas, reingerir idempotentemente, normalizar | Fonte atrasada, drift ou cobertura baixa | Fonte proibida, credencial nova, evasão de limite |
| Mineração | Processar amostras aprovadas com versão fixada | Qualidade abaixo do padrão-ouro | Trocar amostra/gold standard fora do escopo aprovado |
| Modelagem | Calcular coortes e gerar hipótese | Contradição, amostra pequena, mudança de arquétipo | Promover regra protegida ou universalizar sem transferência |
| Produção | Gerar blueprint/EDL/render dentro de direitos, custo e identidade aprovados | QA degradado ou custo perto do limite | Usar ativo sem direito, clonar voz, mudar identidade |
| Publicação | Preparar pacote e agendar se a fase/envelope autorizarem | Alteração de agenda dentro da margem aprovada | Primeiro upload, publicação fora do envelope, apagar vídeo |
| Custos | Consumir cota local/gratuita e orçamento pré-aprovado | 80% do limite, desvio de custo | Assinar/comprar/ultrapassar limite ou adicionar API cobrada |
| Experimentos | Executar teste pré-aprovado com stopping rule | Efeito adverso, interferência, janela incompleta | Mudar variável, público, orçamento ou risco sem aprovação |
| Aprendizado | Atualizar estado conforme regra de transição aprovada | Rebaixar/suspender e explicar | Alterar contrato permanente ou sobrescrever histórico |
| Operação | Priorizar fila, retry limitado, checkpoint e recuperação segura | Dead-letter, degradação, lock perdido | Exclusão material, reset amplo, rotação de credencial |
| Estratégia | Recomendar opção e forecast | Mudança relevante de nicho, canal ou meta | Criar/encerrar canal, alterar objetivo, monetização ou política |

## Conteúdo mínimo do envelope

- versão, vigência, proprietário e status de aprovação;
- canais, nichos, identidades, fontes e tipos de ação permitidos;
- orçamento por ação/período e ferramentas/providers aprovados;
- janelas, frequência, capacidade e limites de concorrência;
- permissões de produção, agendamento e publicação;
- experimentos, métricas, stopping rules e riscos autorizados;
- condições de pausa automática e recuperação;
- matriz de alertas e tempo de resposta;
- ações sempre protegidas e ações sempre proibidas.

## Exceções e emergência

O Gestor pode pausar fila, impedir publicação futura, isolar canal e preservar evidência quando houver risco de direito, política, credencial, custo, vazamento, duplicidade ou integridade. Isso é contenção reversível, não autorização para excluir dados, revogar direitos do proprietário ou executar ação externa nova. Toda contenção gera incidente e alerta.

## Supervisão do proprietário

O relatório do proprietário mostra: postagens preparadas/executadas, resultados por canal, custos e capacidade, alertas, ações bloqueadas, decisões importantes, previsões e calibração, regras modificadas, rollback disponível e solicitações de aprovação. Dados operacionais detalhados continuam auditáveis sob demanda.
