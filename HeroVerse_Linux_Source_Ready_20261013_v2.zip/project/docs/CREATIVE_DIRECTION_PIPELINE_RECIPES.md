# Receitas especializadas por macrofamília

## Contrato comum

Toda receita recebe comando central, `CreativeDirectionDecision`, FormatPack e bíblias; entrega TakePlan, artefatos, hashes, custos, versões e gates. Parâmetros são definidos pelo pack e pelo perfil, não por defaults universais.

## 1. Realismo e cinematografia

- Etapas: shot design -> referência óptica/luz -> aquisição/geração -> consistência -> color pipeline -> temporal/audio QA.
- Adapters: câmera/stock/gerador aprovado, compositor, FFmpeg, detectores de face/anatomia/movimento.
- Parâmetros: lente, sensor/aspect, shutter look, fps, key/fill, white balance, depth, grain e color space.
- Verificações: anatomia, identidade, luz, física, optical flow, flicker, textura de pele, continuidade óptica e disclosure.

## 2. Documentário e jornalismo

- Etapas: claim map -> fontes -> arquivo/registro -> roteiro factual -> edição -> fact/rights/disclosure gate.
- Adapters: observatório, fontes autorizadas, banco de arquivo, OCR/legenda, compositor.
- Parâmetros: data/local/fonte, on-screen attribution, distinção registro/reconstituição e atualidade.
- Verificações: provenance por take, contexto não invertido, alegação suportada, privacidade, publicidade e reconstrução rotulada.

## 3. UGC, POV e câmeras simuladas

- Etapas: dispositivo/persona -> blocking -> captura/simulação -> estabilização intencional -> mix diegético -> authenticity gate.
- Adapters: câmera/stock autorizado, compositor, áudio, estabilização e privacy QA.
- Parâmetros: device profile, rolling shutter, FOV, altura, shake envelope, autoexposure e room tone.
- Verificações: não enganar como registro real, identidade/direitos, estabilidade intencional, continuidade de dispositivo e ambiente.

## 4. Cartoon e ilustração 2D

- Etapas: model sheet -> palette/line bible -> layout -> key poses -> tween/cutout -> composite -> QA.
- Adapters: desenho/vetor/rig 2D, compositor, renderer e line/color QA.
- Parâmetros: line weight, shape language, pose library, easing, frame cadence, cel count e palette.
- Verificações: silhueta, proporção, line boil não intencional, cor, rig, tween, personagem e fundo.

## 5. Anime, mangá, webtoon e variações

- Etapas: character/world bible -> layout/painel -> key art -> motion treatment -> compositing -> IP/style QA.
- Adapters: ilustração/rig aprovados, compositor, OCR/texto e consistency QA.
- Parâmetros: proporção, eye/hair model, line/shading system, panel rhythm, limited-animation cadence e camera.
- Verificações: identidade, rosto/mãos, roupa, painel/cena, artefato temporal, marca/personagem e imitação de artista.

## 6. Animação e renderização 3D

- Etapas: model -> UV/material -> rig -> layout -> animation/sim -> lighting -> render -> comp -> QA.
- Adapters: DCC/engine 3D, renderer, compositor e geometry/physics QA.
- Parâmetros: topology, texel density, rig version, units, fps, samples, GI, camera/lens e motion blur.
- Verificações: malha, interseção, skinning, escala, física, simulação, flicker, temporal denoise e render consistency.

## 7. Arte tradicional simulada

- Etapas: medium bible -> paper/canvas -> stroke/pigment grammar -> sequence consistency -> motion -> comp.
- Adapters: imagem/paint aprovado, texture compositor e style consistency QA.
- Parâmetros: medium, substrate, pigment range, edge behavior, drying/bleed look, stroke scale e grain.
- Verificações: material coerente, textura não pulsante, continuidade, falsa atribuição e negative prompts.

## 8. Design digital, infográfico e motion graphics

- Etapas: data contract -> hierarchy/grid -> storyboard -> components -> animation -> accessibility/data QA.
- Adapters: data parser, vector/compositor, chart engine, typography e OCR.
- Parâmetros: grid, scale, units, typography, contrast, easing, duration, safe area e color encoding.
- Verificações: dado/fonte, escala não enganosa, legibilidade, contraste, truncamento, timing e sincronização com voz.

## 9. Estéticas temáticas

- Etapas: theme overlay -> symbol/material rules -> base-pipeline selection -> world bible -> execution -> saturation/IP QA.
- Adapters: os do pipeline-base; nenhum adapter temático universal.
- Parâmetros: era, material, technology level, symbols, palette, architecture, costume e prohibited clichés.
- Verificações: coerência de mundo, apropriação/sensibilidade, marca/IP, mistura involuntária e saturação.

## 10. Produção baseada em recortes

- Etapas: semantic shot list -> rights-first search -> asset QA -> TakePlan -> transformative edit -> audio/text -> final QA.
- Adapters: fontes autorizadas, manifesto, FFmpeg/compositor, voz/áudio, technical QA.
- Parâmetros: narrative job, source ranges, reuse budget, take duration, crop policy, color match e attribution.
- Verificações: direitos, significado, contexto, repetição, nova seleção/sequência, continuidade e originalidade.

## 11. Produção baseada em imagens

- Etapas: storyboard -> source/generate -> consistency -> depth separation -> motion -> text/audio -> QA.
- Adapters: banco/gerador autorizado, compositor, parallax/Ken Burns e image QA.
- Parâmetros: aspect/resolution, subject anchor, depth planes, motion envelope, hold duration e transition.
- Verificações: anatomia, identidade, resolução, parallax, flicker de sequência, repetição e continuidade.

## 12. Produção baseada em vídeo

- Etapas: shot specification -> source/generate -> temporal QC -> edit -> color -> sound -> final QC.
- Adapters: banco/gerador autorizado, transcode, optical-flow/duplicate/flicker QA e compositor.
- Parâmetros: duration, fps, motion, camera, seed/ref, codec, bitrate e interpolation policy.
- Verificações: deformação, identidade, física, ghosting, duplicated frames, jitter, compressão e style drift.

## 13. Produção híbrida

- Etapas: layer plan -> source by modality -> normalize color/depth/scale -> composite -> motion/audio integration -> QA.
- Adapters: múltiplas fontes autorizadas, compositor, color/depth matcher e QA.
- Parâmetros: layer order, blend, light direction, perspective, grain, sharpness, fps e alpha.
- Verificações: integração, recorte, halo, escala, luz, profundidade, grão, movimento e direitos de cada camada.

## 14. Conteúdo curto

- Etapas: package promise -> 0–1/1–3/3–8 design -> dense TakePlan -> vertical/safe-area edit -> loop/payoff -> QA.
- Adapters: pipeline visual escolhido, caption/text, audio impact e mobile QA.
- Parâmetros: 9:16, hook cut density, words/frame, caption zones, loop point e max cognitive load.
- Verificações: compreensão sem contexto, primeira unidade, safe area, legibilidade, micro-payoff, loop e clipping.

## 15. Conteúdo longo

- Etapas: package -> hook through 30 s -> beat/variety map -> TakePlan -> edit/mix -> fatigue/repetition QA.
- Adapters: pipeline visual escolhido, voice/music, chapter/timeline analyzer e final QA.
- Parâmetros: beat ratios, take-duration bands, novelty budget, open-loop count, chapter rhythm e audio arc.
- Verificações: promessa, 8–30 s, progressão, variedade, repetição, payoff, loudness e retenção hypothesis.

## 16. Conteúdo contínuo, ambiente ou musical

- Etapas: purpose/setting -> rights-cleared soundscape -> visual loop/world -> long render -> seam/loudness QA.
- Adapters: áudio/licença, loop compositor, renderer e spectral/seam QA.
- Parâmetros: loop length, crossfade, LUFS, spectral density, motion rate, brightness variation e duration.
- Verificações: emenda, fadiga, clique, drift, repetição perceptível, direitos musicais, loudness e adequação de uso.

## Gate de instanciação

Estas receitas são `SPECIFIED`, não executores prontos. Cada uma só vira instância utilizável quando existir JSON válido em `schemas/macro_pipeline.schema.json`, adapters elegíveis, FormatPack associado, fixture, testes e revisão.
