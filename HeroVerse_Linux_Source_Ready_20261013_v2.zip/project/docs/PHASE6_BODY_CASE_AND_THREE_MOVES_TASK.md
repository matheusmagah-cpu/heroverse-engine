# PhaseTask — caixa do corpo e seis estados de Name / Test / Choose

Fase6; IN_PROGRESS; autorização contínua D047. Custo técnico adicional R$0.
Objetivo único: corrigir a grafia futura do corpo e produzir seis amostras
específicas de sua identidade de três movimentos, sem modificar o vídeo vigente.

## Preservação e preflight

Instruções: AGENTS, STATE, MASTER_SPEC, protocolo01, fases07, mestres10/11,
Bible/TakePlan de Vídeo2 e cadeia D171. Raiz Modelagem Youtube confirmada.
A11 real10f31b09… permanece29usos/71pendentes, união26 e BLOCKED_INCOMPLETE.
V2/V3/V5, fonte, narração, relógio, direitos, FAILs e receipts permanecem intactos.
A regressão em andamento congela engine, tests, schemas, scripts e seus inputs.
Preparação paralela limita-se a NOVOS arquivos diagnósticos nas duas pastas
abaixo, fora do inventário tests/test_*.py e do compileall hero_engine/tests.
Não executar geração/OCR ou testes paralelos à manutenção; não alterar qualquer
dependência congelada para permitir esse trabalho. Instalação futura é outro gate.

## Entradas fixas e impacto

- Bible c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049:
  body overlays use sentence case; hooks podem usar uppercase.
- V5 7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92.
- A11 10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb.
- Inspeção V3 139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30.
- TakePlan 547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5.

Auditoria somente leitura identificou24ocorrências em21estados;15strings
distintas. Uma emenda única evita versões por microgrupo. Nenhuma capacidade
de mídia é acrescentada pela emenda: os29vinculados e71pendentes não mudam.

| Estados (prefixo visual-) | Antes | Depois |
|---|---|---|
| u004-s00 | PRESSURE IS NOT THE VERDICT | Pressure is not the verdict |
| u008-s00;u046-s00 | EVENT | Event |
| u008-s01 | INTERPRETATION | Interpretation |
| u009-s00;u009-s01 | UNTESTED STORY | Untested story |
| u026-s00 | UNTESTED MEANING | Untested meaning |
| u026-s01 | CHOOSE THE RESPONSE | Choose the response |
| u031-s00 | PRESSURE | Pressure |
| u032-s00;u033-s00;u035-s00;u047-s00;u048-s00;u049-s00 | NAME / TEST / CHOOSE | Name / Test / Choose |
| u036-s00;u037-s00 | ACTION | Action |
| u036-s00;u037-s00 | OBSERVED RESULT | Observed result |
| u039-s00 | WISDOM DOES NOT HIDE DANGER | Wisdom does not hide danger |
| u041-s00 | GET APPROPRIATE SUPPORT | Get appropriate support |
| u042-s00 | POSSIBLE RESPONSES | Possible responses |
| u043-s00 | PRESSURE DOESN'T NAME YOU | Pressure doesn't name you |
| u046-s00 | FEAR'S INTERPRETATION | Fear's interpretation |

Name / Test / Choose usa sentence case por rótulo independente, não troca de
palavras ou sistema. Só o mapa fechado prevalece sobre grafias históricas nas
descrições. u026-s01 conserva frase/pontuação e troca apenas a caixa. Referências
NAME/TEST/CHOOSE nas descrições continuam funções de destaque. O hook001–003,
as29fontes vinculadas e todos os outros campos/entradas permanecem byte-equivalentes
após restauração das24posições. u004/u043 ainda exigem contexto móvel permitido;
esta emenda não os converte em cartelas estáticas.

## Implementação delimitada

1. Nova pasta output/qa/phase6/diagnostics/body-case-v1/: compilador puro,
   stager e seus testes diagnósticos. Quatro buffers brutos pinados, JSON estrito;
   não seguir dependency_bindings nem importar replay de QA. Bible tem SHA bruto
   distinto da reserialização. Proposta21/24/79; V6 STAGED_NOT_ACCEPTED_BY_A11;
   todos os poderes falsos. Namespace exclusivo; outputs parciais bloqueados.
2. Nova pasta output/qa/phase6/diagnostics/three-moves-identity-v1/: receita e
   QA especializados, testes, seisSVG/PNG, layouts, scans e receipts. Usar a V6
   somente como proposta pinada, não como aprovação produtiva. Não editar A11.
3. Revisão visual das seis amostras, QA estática independente e nota de direitos
   específica. Só então preparar consumidor/vínculos versionados em lote.

## Receita dos seis estados

| Estado / take | Foco único | Segunda linha |
|---|---|---|
| u032-s00 /049 | nenhum | ausente |
| u033-s00 /050 | Name | Fact: what happened? |
| u035-s00 /055 | Choose | One faithful response today |
| u047-s00 /084 | Name | ausente |
| u048-s00 /085 | Test | ausente |
| u049-s00 /086 | Choose | ausente |

Um headline completo branco Name / Test / Choose, ArialBold96, baseline340,
x240; auxiliar64, baseline550. Foco por underline dourado abaixo do rótulo,
fora dos campos OCR; sem palavra colorida/recomposta, contador, checkmark ou
progresso cumulativo. Fonte/headline ficam pixel-idênticos nos seis estados.
Mesmo painel de two-question/four-criteria,1920×1080, paleta bloqueada,
frame(192,196,1536,588), captionreserve864–993. Região de conteúdo x240–1680,
y220–784; mínimo54px, até2linhas/8palavras. Campos de resposta deliberadamente
vazios só nos dois estados auxiliares; não sugerem ação já concluída.
Revisão antes de qualquer teste/render: representar o campo vazio de modo
visível, não apenas por metadado. Retângulo exterior x240/y612/w1440/h108,
cor#2C5364; interior x244/y616/w1432/h100, fundo#081827. Assim a borda4px
identifica uma área ilustrativa de resposta, sem inserir fato/previsão/ação.
Somente033/035 possuem esse campo; interior e demais estados ficam vazios.
O QA independente verificará bordas/resposta do filtro e ausência de conteúdo,
sem confundir o campo com progresso, contador ou revisão jurídica.
Ancestralidade owned-four-criteria-panel-v1: seisestados de uma única composição
derivada, não seisfontes de variedade ou nova linhagem independente.

Primitivas permitidas sob pins: four-criteria.svg/raster ea2000c5…;
compact.word_count/runtime_binding51a6c8d4…; Reader/canonical a27d5260…;
writer imutável386e09cb…; nenhum executor/scene de outra família é reutilizado.
Font arialbd.ttf e8f4e3ba… e inventário Pillow devem ser reconferidos. Sem
serviço externo, downloads, novos modelos ou fontes pagas.

## Done when e provas

- Emenda: quatro documentos exatos;51unidades/90fragmentos/100estados;21/24/79
  calculados;29vínculos/71pendentes/3hooks preservados; entradas/narração/união26
  intactas. Negativos de bytes, schema, duplicateJSON, NaN, mudança de palavra,
  pontuação, população, fragmentos, hook, autoridade, colisão e drift passam.
- Receita: seispares exatos; copy e funções pinadas; métricas tipográficas
  prévias, foco não cumulativo,94estados não selecionados preservados por hash;
  teste não é imagem aprovada. Geração única depois da manutenção; persistência
  exclusiva+fsync+rechecagem. Cache externo inteiro sem rerender, parcial bloqueado.
- QA: uma inferênciaOCR por PNG, scans preservados. Especificação independente
  da receita. Imagem inteira sem pixels inesperados; contornos reais de tinta;
  centroide associa OCR ao campo e envelope contém tinta. Não confundir margem
  do detector com contorno dos glifos nem ampliar campos depois de observar.
  Copy/case/barras/pontuação exatas, confiança≥0,70, nenhuma linha rejeitada,
  duaslinhas/8palavras; headline idêntico, seisfocos corretos, áreas vazias e
  reserva de captions. Testar troca de foco, foco cumulativo, deslocamento,
  truncamento, texto ausente/extra, font/paleta, corrupção e repetição indevida.
  OCR+SVG pinado+cores principais não certificam todos os glifos rasterizados
  ou antialias pixel-a-pixel. Explicitar esse limite, sem rerender oculto como
  padrão-ouro. Continuidade do headline e geometria não textual serão medidas.
- Máximo deste ensaio: PASS_STATIC_SCOPE_ONLY. UmaPNG é umframe[0,1), sem FPS,
  duração ou tempo de palavra. Novos direitos/admissão/timeline/B/C/D/QA final
  exigem suas próprias evidências. Nem29/71 nem3linhagens sobem por esse ensaio.

## Fora de escopo e sequência

Não sintetizar voz, alinhar palavras, alterar áudio, inferir percepção, renderizar
vídeo integral, mudar fila, publicar ou concluir Fase6/GC01. Não reabrir fontes
anteriores nem seus testes intactos. Ao fechar este ensaio, atualizar estado e
seguir o próximo elo autorizado; D047 substitui a parada administrativa do
template. Bloqueio crítico permanece explícito, não é sucesso por média.
