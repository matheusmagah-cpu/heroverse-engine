# Revisão de pacing — quatro instruções com fontes estáticas

Escopo: auditoria somente leitura,08/09/2026. Não é decisão de pausa,
alinhamento, escuta humana, render ou aprovação de duração. Nenhum áudio,
imagem, modelo, código do motor ou teste foi executado para esta revisão.

## Fontes e precisão

| Fonte | SHA-256 |
|---|---|
| A11 timeline06198f55… | 10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb |
| Inspeção static-asset-uses-v3 | 139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30 |
| Envelope narration-acoustic-envelope-350ae512790a10e937f02358.json | fac970cc1d9ed567084524176290eeda2cff7946b04673a7ea2211690d6f67f2 |
| narration-editorial-pause-proposal-v1/proposal.json | cb5f0389a31b2aa9c481d469dc33bc8d52679734bf42f57e058ef66a61b1bfd9 |
| Experimento intelligence/experiments/active.json | 3c427fcdeac7b77a98398bb15ab2e97c83ae09430f5f8e1d6aa928a67a47043f |
| treatment_contract.json | 972aa92647772324f98b89d3a2f69dace073bd0c948a4d83c58756e6e87bf901 |
| narrative_script.json | 6f8686c2bbfdcb8524eb26e3f94729efec13c17b30ed4f8c59dd223ff2d24e1d |

Pins documentais conferidos no root e922d2; registros do envelope e pausas
conferidos b6316d. Parecer independente temporal_feasibility e releitura root.
Os documentos são contexto histórico pinado; a revisão não revalida seus PCM.

O piso editorial207750ms/grade207800ms vem da banda de referência congelada
do experimento, não de um requisito técnico do YouTube. A11 tem190800ms;
master atual202780ms, déficit real5020ms até a grade.204900ms é somente
projeção ceil100 não aplicada, cujo déficit seria2900ms.14100ms não é teto
editorial validado. Não aumentar pausas pelo valor de qualquer desses déficits.

## Exposição gráfica

| Estado/take | Copy simultânea | Entrada | PCM local / slot |
|---|---|---|---|
| u011-s01 /014 | Fact; Fear's forecast; What happened (5palavras) | write [14,19) | 59904samples /2500ms |
| u012-s01 /016 | anteriores; Feared meaning (7palavras) | write [15,20) | 69632samples /3000ms |
| u020-s01 /026 | Fully true?; Or only possible? (5palavras) | or only possible? [18,35) | 66560samples /2800ms |
| u021-s00 /027 | Character; Is this how I should act? (7palavras) | UNIT_ENTRY estrutural | 78336samples /3300ms |

Relógio24000samples/s. O PCM é respectivamente2496ms,69632/24ms,66560/24ms
e3264ms; frações mantidas sem arredondamento de evidência. As três primeiras
revelações exigem onset lexical calibrado. UNIT_ENTRY da quarta não é onset de
character. As captions de unidade têm7/9/7/11palavras e tempos globais null.

Exposição real dos quatro estados: **UNAVAILABLE**. Não há spans, eventos ou
cues agendados na A11. Slot de unidade não comprova tempo disponível depois da
revelação. Caption simultânea compete por atenção; QA estática não mediu isso.

## Energia e tempo já existente

| Unidade | Cauda conservadora dentro do PCM | Grade | Baixa energia inicial seguinte | Soma já considerada por A | Adicional histórico já no master |
|---|---|---|---|---|---|
| 011 | 13344samples =556ms | 4ms | 60ms | 620ms | 120ms |
| 012 | 12992samples =12992/24ms | 2368/24ms | 60ms | 700ms | 300ms |
| 020 | 12560samples =12560/24ms | 640/24ms | 80ms | 630ms | 260ms |
| 021 | 13536samples =564ms | 36ms | 60ms | 660ms | 260ms |

Cauda RMS é estimativa de baixa energia, não silêncio linguístico, começo/fim
de palavra ou tempo de compreensão. Os120/300/260/260ms já pertencem ao master
202780ms e não podem ser somados novamente. A11 atual não os incorporou.

Em A, target_low_energy_samples representa alvo TOTAL; o código subtrai caudas,
início seguinte e grade, depois arredonda o acréscimo positivo para a grade.
Não tratar esse campo como quantidade a acrescentar. Não contar o início da
próxima unidade como exposição da imagem anterior sem contrato de continuidade.
Mesmo quando What happened persiste, mudança de foco para a direita não mantém
automaticamente o mesmo estado.

## Próxima decisão verificável, ainda não tomada

Antes de escolher valores, registrar para cada estado:

1. função concreta de leitura/compreensão e copy nova versus persistente;
2. instante de revelação validado e ponto de saída;
3. tempo de exposição que já existe, com sua incerteza;
4. competição com caption e narração;
5. continuidade gráfica durante a pausa e na próxima unidade;
6. caudas/grade/adicionais já incluídos, sem dupla contagem;
7. critério independente de compreensão e pacing, custo e rollback.

A proposta antiga tinha READ_VISUAL=0 por ausência de visual legível comprovado.
Agora existe QA estática das quatro fontes; isso permite rever a hipótese, não
inferir quantos milissegundos faltam para leitura. Se não houver pausa útil
justificável, será necessária emenda explícita de conteúdo útil e sucessor da
cadeia, nunca baixar o piso, alongar locução ou inserir silêncio para passar.

Resultado: lacuna interna de pacing/tempo explícita; nenhuma mudança de áudio,
narração, intenção visual, direitos, gates, fila ou publicação autorizada por
este relatório. Custo técnico adicionalR$0.
