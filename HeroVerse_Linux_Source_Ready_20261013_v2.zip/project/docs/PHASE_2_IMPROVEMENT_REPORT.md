# Relatório da iteração de melhoria — Fase 2

## Veredito

A iteração `miner-local-0.2.0` cumpriu todos os critérios objetivos da Fase 2 nas quatro fixtures autorizadas. Foram aprovadas 48/48 métricas de campo, 38/38 testes do projeto, 4/4 execuções completas, 4/4 replays idênticos, 0 regressões críticas e custo de API externa observado de US$ 0,00.

O resultado comprova melhoria local do minerador, não generalização. As quatro fixtures foram observadas durante o diagnóstico; por isso, o ciclo de aprendizado está classificado como `SUPPORTED_LOCAL` e os benchmarks automáticos permanecem `INCONCLUSIVE`. A validação fora da amostra pertence à Fase 3.

## Escopo executado

- baseline `miner-local-0.1.0` congelado e preservado;
- hipóteses e thresholds registrados antes da implementação;
- OCR seletivo start/mid/end nas janelas prioritárias, com confiança mínima `0.70`, rejeição auditável e proveniência por frame;
- segmentação narrativa por mudança lexical, pausa, reset discursivo e otimização global, sem leitura do gold pelo executor;
- métrica OCR limitada a anotações literais, separada de descrições editoriais;
- packaging separado em título exato e texto literal da thumbnail;
- jobs, benchmarks, active run, ciclo de aprendizado e manifesto versionados sem sobrescrever o champion;
- revisão visual original de 5/5 frames do sidecar OCR;
- nenhuma ação de lote, produção, publicação, Ads ou gasto.

## Resultados por fixture

| Vídeo | OCR | Narrativa | Packaging | Gates | Regressões críticas | Decisão automática |
|---|---:|---:|---:|---:|---:|---|
| `hkf6nDyUfAM` | 0.909091 | 0.740000 | 0.820000 | 12/12 | 0 | `INCONCLUSIVE` |
| `_sOy7htXJi8` | 1.000000 | 0.675000 | 0.918182 | 12/12 | 0 | `INCONCLUSIVE` |
| `Pkede5acSFw` | 1.000000 | 0.675000 | 0.871429 | 12/12 | 0 | `INCONCLUSIVE` |
| `huvUy3pJSp8` | 1.000000 | 0.783334 | 0.900000 | 12/12 | 0 | `INCONCLUSIVE` |

## Comparação champion/challenger

| Campo | Baseline | Challenger | Delta | Threshold | Fixtures aprovadas |
|---|---:|---:|---:|---:|---:|
| Timestamps | 1.000000 | 1.000000 | 0.000000 | 0.999 | 4/4 |
| Transcrição | 0.991548 | 0.991548 | 0.000000 | 0.900 | 4/4 |
| OCR | 0.151515 | 0.977273 | +0.825758 | 0.350 | 4/4 |
| Hook windows | 0.793821 | 0.793821 | 0.000000 | 0.750 | 4/4 |
| Takes | 1.000000 | 1.000000 | 0.000000 | 0.900 | 4/4 |
| Narrativa | 0.287386 | 0.718333 | +0.430947 | 0.550 | 4/4 |
| Packaging | 0.745455 | 0.877403 | +0.131948 | 0.750 | 4/4 |
| Direitos/proveniência | 1.000000 | 1.000000 | 0.000000 | 1.000 | 4/4 |
| Schema | 1.000000 | 1.000000 | 0.000000 | 1.000 | 4/4 |
| Custo | 1.000000 | 1.000000 | 0.000000 | 1.000 | 4/4 |
| Latência | 1.000000 | 1.000000 | 0.000000 | 0.500 | 4/4 |
| Consistência | 1.000000 | 1.000000 | 0.000000 | 1.000 | 4/4 |

Nenhum campo previamente aprovado regrediu. A maior queda média observada foi `0.0`, dentro do máximo pré-registrado de `0.02`.

## Recursos reais

| Vídeo | Wall time | Takes | Keyframes | Imagens OCR | Palavras ASR |
|---|---:|---:|---:|---:|---:|
| `hkf6nDyUfAM` | 293.5282 s | 57 | 171 | 70 | 504 |
| `_sOy7htXJi8` | 316.5079 s | 63 | 189 | 72 | 516 |
| `Pkede5acSFw` | 328.6051 s | 55 | 165 | 66 | 639 |
| `huvUy3pJSp8` | 183.7009 s | 81 | 243 | 94 | 499 |
| **Total** | **1,122.3421 s** | **256** | **768** | **302** | **2,158** |

Limites de medição: `tracemalloc` não mede toda a memória nativa; o tempo de CPU do Python não cobre processos externos ffmpeg/ffprobe; eletricidade e depreciação do hardware local não foram precificadas.

## Aprendizado comprovado

O ciclo separa, de forma imutável, previsão anterior e outcome posterior:

1. `H-MINER-001` — OCR: `SUPPORTED_LOCAL`; média prevista mínima `0.65`, observada `0.977273`; 4/4 fixtures passaram.
2. `H-MINER-002` — narrativa: `SUPPORTED_LOCAL`; média prevista mínima `0.55`, observada `0.718333`; 4/4 passaram.
3. `H-MINER-003` — packaging: `SUPPORTED_LOCAL`; média prevista mínima `0.80`, observada `0.877403`; 4/4 passaram.

Isso é aprendizado real do executor na população local autorizada. Não é aprendizado operacional global do Gestor Central, não prova transferência e não permite declarar `SUPPORTED_GENERAL`.

## Verificações finais

- `python -m compileall -q hero_engine scripts`: aprovado;
- `python -m pip check`: `No broken requirements found`;
- `python -m unittest discover -s tests -v`: 38/38 aprovados;
- benchmark: 48/48 métricas aprovadas;
- replay: 4/4 `CACHE_HIT`, hashes semânticos idênticos;
- validação JSON Schema do outcome: 0 erros;
- revisão visual OCR: 5/5 artefatos concordam com as linhas literais;
- manifesto challenger: 1.125 artefatos, 21.628.175 bytes, todos verificados pelo teste de integração;
- baseline histórico: os três hashes congelados continuam idênticos ao pré-registro.

## Critérios de aceitação

| Critério | Estado | Evidência |
|---|---|---|
| execução reproduzível | APROVADO | 4/4 cache replays idênticos |
| divergências medidas e revisadas | APROVADO | benchmarks por campo e revisão visual 5/5 |
| nenhuma dependência paga obrigatória | APROVADO | providers locais; API externa US$ 0,00 |
| falhas explícitas | APROVADO | adapters fail-closed e testes de falha |
| idempotência | APROVADO | hash de job, inventário e replay |
| pipeline completo da Fase 2 | APROVADO | inspeção, ASR, takes, frames, OCR, hooks, narrativa, packaging |
| schema/evidência/direitos | APROVADO | 4/4; direitos continuam bloqueados para produção |
| fatos e inferências separados | APROVADO | contrato e testes |
| tempo/recursos/custo medidos | APROVADO | quatro manifests e tabela acima |
| exemplo real | APROVADO | quatro vídeos reais, não mocks |
| suíte legada sem regressão | APROVADO | 38/38 testes |

Critérios reprovados: nenhum. Critérios bloqueados dentro do escopo da Fase 2: nenhum. Limitação externa ao gate: ausência de holdout independente, a ser resolvida na Fase 3.

## Artefatos de auditoria

- active run: `output/mining/phase2/runs/miner-local-0.2.0/active_run.json`;
- resumo: `output/mining/phase2/benchmarks/miner-local-0.2.0/summary.json`;
- pré-registro: `output/mining/phase2/learning/cycle-001/preregistration.json`;
- outcome: `output/mining/phase2/learning/cycle-001/outcome.json`, SHA-256 `da959a59b0edf9ed748df48a7cb01a25f2399066b92c29b15629127587dcd115`;
- sidecar OCR revisado: `data/gold_standard/evaluation/ocr_literal_v1.json`, SHA-256 `7abe28ca3121357899736dca6b298688625438d76dc5d1096139767cb61ff45e`;
- integridade: `output/mining/phase2/integrity/miner-local-0.2.0.json`, SHA-256 `a502611ec31612583f6defc32ac5e89a8b2b6087b8a20b6bf38a3d49e5873b58`.

## Decisão de fase

O gate técnico da Fase 2 está aprovado. A promoção não foi automática: ela decorre da revisão registrada e da autorização condicional expressa do proprietário para avançar quando a fase estivesse integralmente executada e revisada. O minerador `miner-local-0.2.0` passa a ser a versão selecionada para a Fase 3, com status de conhecimento `SUPPORTED_LOCAL` e obrigação de validação fora da amostra.
