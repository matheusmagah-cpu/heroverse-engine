# Preflight da Fase 1 — Seleção do padrão-ouro

Data: `2026-09-02`  
Raiz: `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`  
Fase autorizada: `1`  
Estado: `AWAITING_REVIEW — planejamento complementar incorporado; amostra ainda não aprovada`

## Instruções carregadas

Foram relidos o estado, contrato mestre, protocolo de execução, especificação de mineração, fases e gates, política de direitos, plano da Fase 1, prompt autorizado, schema e templates.

## Escopo preservado

- Um canal de referência por vez: `Grace, Grit & Love`.
- Um formato: vídeos longos em inglês no nicho Christian Motivation.
- Mineração manual completa antes de qualquer minerador automático.
- Hook separado em `0–1 s`, `1–3 s`, `3–8 s` e `8–30 s`.
- Direitos registrados separadamente; análise não autoriza produção.
- Nenhuma publicação, produção, fase posterior ou gasto.

## Base objetiva da seleção

O catálogo legado possui 24 vídeos. A seleção usa o snapshot local de `2026-09-01`, classificado por views/dia para reduzir o viés de idade. A população observada possui mediana de `128,2 views/dia` e duração mediana de `230 s`.

As métricas abaixo são `OBSERVED` ou `CALCULATED` no snapshot local. Não são métricas privadas e não provam causalidade.

## Amostra proposta

| Papel | Vídeo | Duração | Views | Views/dia | Rank | Razão de inclusão | Estado local |
|---|---|---:|---:|---:|---:|---|---|
| vencedor principal | [WARFARE HD](https://www.youtube.com/watch?v=hkf6nDyUfAM) (`hkf6nDyUfAM`) | 230 s | 489.000 | 849,0 | 1/24 | maior velocidade normalizada e duração exatamente na mediana | intro local; mídia completa ausente |
| vencedor recente | [THE KING IS COMING HD](https://www.youtube.com/watch?v=_sOy7htXJi8) (`_sOy7htXJi8`) | 210 s | 54.000 | 442,6 | 3/24 | testa padrão vencedor recente com duração menor | intro local; mídia completa ausente |
| mediano comparável | [GODS VENGEANCE HD](https://www.youtube.com/watch?v=Pkede5acSFw) (`Pkede5acSFw`) | 285 s | 112.000 | 109,5 | 13/24 | fica no centro da distribuição e amplia a faixa de duração | nenhuma mídia local |
| fraco comparável | [BROKEN WITH PURPOSE HD](https://www.youtube.com/watch?v=huvUy3pJSp8) (`huvUy3pJSp8`) | 243 s | 43.000 | 20,8 | 24/24 | contraexemplo de pior velocidade com duração próxima do formato | intro local; mídia completa ausente |

### Cobertura obtida

- dois vencedores com temas e recência diferentes;
- um caso mediano;
- um caso fraco;
- faixa de duração de `210–285 s`;
- contraste de velocidade de aproximadamente `40,8×` entre maior e menor caso;
- todos no mesmo canal, idioma, nicho e formato, reduzindo variáveis externas na anotação inicial.

## Exclusões deliberadas

- `5-zdruoQKlM`: não pertence ao formato modelado de 3–5 minutos e tem histórico contraditório de licença; não entra no padrão-ouro desta tarefa.
- Shorts: exigem um padrão-ouro separado por possuírem gramática, retenção e proporção diferentes.
- Um viral isolado: a amostra contém mediano e fraco por contrato.

## Ferramentas verificadas

- FFmpeg: disponível.
- ffprobe: disponível.
- faster-whisper `1.2.1`: disponível.
- Tesseract: ausente.
- PySceneDetect: ausente.
- OpenCV: ausente.
- Thumbnail completa/original: ausente no workspace para os quatro candidatos.

A ausência das três ferramentas não autoriza reduzir o escopo. Na Fase 1, cortes e OCR podem ser revisados manualmente; qualquer instalação será proposta somente após a aprovação da amostra e sem dependência paga.

## Entradas bloqueadoras

1. aprovação explícita dos quatro vídeos;
2. mídia completa obtida por acesso legítimo ou fornecida pelo usuário;
3. thumbnails preservadas com origem e hash;
4. confirmação de que os vídeos serão usados para análise, não como ativos automaticamente liberados para produção.

## Critérios copiados para o plano

- JSON válido no schema;
- timecodes consistentes;
- hooks obrigatórios;
- takes revisados e evidenciados;
- transcrição bruta preservada;
- fatos/inferências separados;
- nenhum direito presumido;
- revisão humana e reprodutibilidade.

## Condição de avanço

Primeiro, o usuário deve revisar os documentos do Gestor Central listados em `PLANS.md`. Se aprovados, a Fase 1 retorna ao gate de aprovação expressa da amostra e definição do acesso legítimo às mídias completas. Sem essas entradas, preencher o restante exigiria inventar evidência, o que o contrato proíbe.
