# Gestão conjunta de capacidade — D-132

## Observação atual — 27/09/2026, registrada às 05:52:18 UTC

Fonte oficial: **51% da franquia semanal restante**, saldo adicional **0 créditos**,
uso incluído permitido e renovação em **03/10/2026 às 14:36:46 BRT**. Astra/Ultra
confirmados na configuração desta conversa; velocidade não exposta pela consulta,
sem alteração. Registro sanitizado: `output/operations/codex-usage/observations/budget-check-20260927T055218Z.json`.

Os percentuais abaixo são históricos, não saldo atual. A diferença de dois pontos
desde 05:23 é da conta compartilhada, não custo exclusivo do HeroVerse. Não existe
medição que comprove orçamento suficiente para concluir todo o projeto: o checkpoint
atual conserva nove atributos visuais sem evidência suficiente e STYLE_DRIFT FAIL.
Nenhuma estimativa de horas, reais ou custo por etapa foi fabricada.

Gestão desta continuidade: manter Astra/Ultra, uma causa por lote, reusar evidências
válidas, testes afetados antes da integral exigida e consultas oficiais nos marcos
materiais. Sem monitor novo, repetição de prova válida, compra, recarga, reset ou
mudança de qualidade. OpenAI Docs confirma Fast a 2,5 vezes a tarifa de créditos
Standard; isso não é conversão direta da franquia incluída. Não ativado por esta
conferência. Controle cooperativo, não limite financeiro nativo nem garantia de
conclusão dentro do saldo. PAUSE, agenda, D116 e vídeo não foram alterados.

## Política vigente D-152 — somente YouTube ativo por declaração do proprietário

**Leitura mais recente:06/09 às17:19:40BRT.**74%usados/**26%disponíveis**, renovação12/09 às23:15:36BRT. Reserva10pontos;16planejáveis /6,247175925926dias =**2,561157263652pontos percentuais/dia**. A decisão codex-usage-adb3ab2711205cb6 é schema1.2-válida, latest byte-idêntico ao histórico, SHAaf6afd7a26853f691154600ebb49ec88261ac12bf7d2bb6dd10e83e855bfc5df. Fonte sanitizada account-20260906T201940Z.json. Âncora preservada: desvio11,069055504111pontos acima do plano, portanto FULL_QUALITY_CRITICAL_PATH_ONLY;26%não autoriza alto consumo só por ainda estar na bandaAMBER. Saldo2.500/doisresets separados e intactos, sem conversão fictícia ou resgate. Nenhum código/modelo/monitor alterado nesta observação; só persistência/validação. A [documentação oficial](https://learn.chatgpt.com/docs/pricing#what-are-the-usage-limits-for-my-plan), conferida via OpenAI Docs, informa consumo variável por modelo/contexto/tarefa; este teto cooperativo não garante uso ininterrupto. As leituras abaixo são históricas.

**Última leitura:06/09 às 12:29:17 BRT.** 37% disponíveis; mesma renovação12/09 às23:15:36BRT. Reserva10%, orçamento27pontos por6,448831dias: **4,186805pontos percentuais/dia**. O consumo ficou0,942828ponto acima do ritmo da âncora62%, que não foi substituída. Estado AHEAD_OF_PLAN: caminho crítico apenas, qualidade preservada, trabalho discricionário extenso pode esperar; não é hard cap do host. Decisão `codex-usage-a4fd4f1a55c29fca`, SHA `bf446284b72386e58c6bec94185c01407816d97986d726c7105c3c312738c56b`, schema/twin/replay exatos. Saldo2.500 e dois resets intactos. Último lote31/31testesPASS0,769s, incluindo extremos, percentuais inválidos/fracionários, históricos reais e publicação atômica/falha da visão. Essa contraprova prevalece sobre a leitura inicial abaixo, sem apagar sua base.

Em 06/09 o proprietário informou que pausou QR Dolar. O plano considera somente Modelagem Youtube até retomada expressa; os dois projetos e sua importância histórica permanecem registrados. O limite ainda é da conta, não uma cota tecnicamente exclusiva. Não foi verificada ausência de outras atividades no host e não há atribuição oficial de consumo por projeto.

Leitura registrada em **06/09 às 12:10:17 BRT** (`2026-09-06T15:10:17Z`): **38% disponíveis**, renovação observada em **12/09 às 23:15:36 BRT**. A regra mantém 10 pontos percentuais de reserva. Cálculo: `(38 - 10) / (558319 / 86400) = 4,333006758` pontos percentuais por dia. É teto nominal de planejamento para 6 dias, 11 horas, 5 minutos e 19 segundos; não previsão exata por tarefa ou garantia de uso ininterrupto. Os 2.500 créditos e dois resets separados permaneceram intactos e não entram nessa conta.

Código: `hero_engine/codex_runway.py`, governança/schema1.2 e `config/codex-usage-policy.json`. O plano usa âncora real para detectar consumo à frente do ritmo previsto; não redefine a âncora a cada consulta para ocultar desvio. Renovação diferente/expirada exige REBASE_REQUIRED; fonte ausente mantém UNAVAILABLE. Qualidade/esforço e gates não são reduzidos; planejamento adia expansão discricionária extensa quando necessário, mantendo recuperação, checkpoints seguros e runtime local dentro de seus gates. Não é hard cap do aplicativo.

Provas: 14/14 testes principais PASS em 0,192 s; decisão `codex-usage-933dae9e40d69fdc`, schema/twin íntegros, SHA `f3a7452b91446f9d14cf158d82f69ae776b330636b674cd786b0588f04ade7d1`. Observação sanitizada em `output/operations/codex-usage/observations/account-20260906T151017Z.json`. O monitor diário existente recebeu o adendo e preserva integralmente as instruções anteriores, horário, destino e ACTIVE. Não desperta o QR pausado, não cria outra automação e permanece silencioso sem mudança relevante. Nenhuma compra, reset, alteração de modelo/esforço ou nova cobrança.

Os registros abaixo são históricos; referências à execução conjunta não reativam a operação pausada. A skill OpenAI Docs orientou conferência da [documentação oficial](https://learn.chatgpt.com/docs/pricing): o consumo é variável e compartilhado. A continuidade do software local não depende de manter uma conversa Codex gerando tokens sem parar; partes ainda não integradas não são anunciadas como operação final pronta.

## Leitura registrada — 2026-09-06T13:37:00Z

Consulta nativa sanitizada `output/operations/codex-usage/observations/account-20260906T133700Z.json`; decisão `codex-usage-9c50df09cac718b0`, schema válido e latest byte-idêntico ao histórico. 56% usados/44% disponíveis, AMBER; saldo separado2.500 e dois resets intactos. Janela/renovação permanecem13/09 02:15:36Z. Timestamp é registro local após resposta do provedor. Banda inalterada: sem novo despertar da outra tarefa, compra, reset, mudança de modelo/esforço ou atribuição individual de consumo. Manter qualidade, lote focal e reutilização, sem promessa de saldo eterno.

## Leitura registrada — 2026-09-06T12:45:43Z

Decisão `codex-usage-5ec49451405683ac`:52%usados/48%disponíveis,AMBER, schema válido/latest idêntico ao histórico. Saldo separado2.500 e dois resets intactos; renovação observada13/09 02:15:36Z. Fonte sanitizada `output/operations/codex-usage/observations/account-20260906T124543Z.json`. A mudança de banda foi comunicada à tarefa `Extrair conversa completa`, sem transferir estratégia, dados ou autoridade. Mesma qualidade, batching/deduplicação, custoR$0; nenhum reset, compra, downgrade ou novo monitor. OpenAI Docs orientou conferência da [fonte oficial de limites compartilhados](https://learn.chatgpt.com/docs/pricing); timestamp é registro local após a resposta nativa, não instante fornecido pelo provedor.

## Leitura registrada — 2026-09-06T10:01:15Z

Decisão `codex-usage-9266c64b4eed60aa`: 39% usados/61% disponíveis, GREEN; schema e twin íntegros. Saldo separado 2.500, dois resets intactos e renovação 13/09 02:15:36Z. Timestamp de registro local após a resposta nativa; fonte sanitizada `output/operations/codex-usage/observations/account-20260906T100115Z.json`, materializada após a manutenção terminal para preservar sua snapshot. OpenAI Docs orientou confirmação da [documentação oficial](https://learn.chatgpt.com/docs/pricing), sem atribuição por projeto, compra, reset, downgrade ou nova coordenação por banda inalterada.

## Leitura registrada — 2026-09-06T09:06:40Z

Decisão `codex-usage-90f5886e50bdfd53`: 35% usados/65% disponíveis, GREEN, schema válido e latest byte-idêntico ao histórico. Saldo separado 2.500 e dois resets intactos; renovação observada 13/09 02:15:36Z. Fonte sanitizada `output/operations/codex-usage/observations/account-20260906T090640Z.json`, materializada depois do encerramento da regressão para preservar sua snapshot estável. Não é nova leitura do provedor no instante da materialização.

OpenAI Docs orientou a confirmação da [documentação oficial](https://learn.chatgpt.com/docs/pricing): limite compartilhado e consumo variável por contexto, raciocínio e ferramentas. Nenhuma atribuição inventada por projeto, compra, reset, mudança de modelo ou promessa de créditos inesgotáveis. Banda permanece GREEN; sem despertar a outra tarefa apenas por status inalterado.

## Leitura registrada — 2026-09-06T07:49:16Z

Decisão `codex-usage-59f3f8e15d385f0e`:29%usados/71%disponíveis, GREEN, schema válido e latest byte-idêntico ao histórico. Saldo separado2.500 e dois resets preservados, renovação13/09 02:15:36Z. Materialização adiada até a regressão terminar para não modificar sua snapshot estável. Timestamp é registro local; o provedor não informa instante da observação. Fonte sanitizada `output/operations/codex-usage/observations/account-20260906T074916Z.json`.

A skill OpenAI Docs orientou a rechecagem da [documentação oficial](https://learn.chatgpt.com/docs/pricing): limite compartilhado e consumo variável. Um único pool para ambos os projetos, sem inventar atribuição individual, duração infinita ou limite rígido executado pelo host. Nenhuma compra, reset, mudança de modelo ou redução de qualidade nesta leitura.

## Leitura posterior — 2026-09-06T07:16:11Z

Consulta nativa sanitizada e materializada em `codex-usage-3058eb997ba99d5e`:26%consumidos/74%disponíveis, GREEN; saldo separado2.500 e dois resets intactos. Renovação13/09 02:15:36Z. Schema válido/latestbyte-idêntico ao histórico. Um único pool permanece compartilhado pelos dois projetos; variação não foi atribuída individualmente. Sem compra/reset/downgrade/alteração de modelo. A documentação oficial já conferida pela skill OpenAI Docs continua como referência de limite finito e consumo variável.

## Leitura posterior — 2026-09-06T06:46:28Z

Decisão `codex-usage-5ead80263adaf020`: GREEN,24%consumidos/76%disponíveis na janela principal da conta, saldo separado2.500 e dois resets intactos; renovação `2026-09-13T02:15:36Z`. Observação sanitizada `output/operations/codex-usage/observations/account-20260906T064628Z.json`; materialização pelo domínio existente, schema válido e twin byte-idêntico. O timestamp é de registro local; a interface nativa não expõe instante próprio.

A skill OpenAI Docs levou à rechecagem da [documentação oficial de limites compartilhados e consumo variável](https://learn.chatgpt.com/docs/pricing). Mantém-se um único pool para Modelagem Youtube e QR Dolar, sem atribuir variação a um projeto nem prometer duração infinita. Sem compra, reset, mudança de modelo/esforço ou nova execução da outra tarefa por status GREEN inalterado.

## Leitura posterior — 2026-09-06T05:53:04Z

Decisão `codex-usage-a8da7676c4d27a61`: GREEN, 20% consumidos/80% disponíveis no limite principal compartilhado, saldo separado 2.500 e dois resets intactos. Renovação observada `2026-09-13T02:15:36Z`. Schema válido e latest byte-idêntico ao histórico. Fonte sanitizada em `output/operations/codex-usage/observations/account-20260906T055304Z.json`; o horário registra a coleta local, pois a resposta nativa não fornece timestamp de observação próprio.

A skill OpenAI Docs orientou a conferência da [documentação oficial de uso](https://learn.chatgpt.com/docs/pricing), que distingue limite compartilhado, consumo variável e créditos. Nenhum reset, compra, recarga, downgrade ou mudança de modelo/esforço foi executado nesta leitura. A banda GREEN não mudou, portanto não foi disparada uma nova execução na outra tarefa apenas para repetir o status. Os registros de reserva crítica abaixo são históricos, não o estado desta leitura.

## Atualização vigente D-133 — um reset gratuito efetivado

O usuário reafirmou sua autorização em resposta à pergunta específica sobre resgatar um dos três resets gratuitos. Foi consumido **exatamente um**, com resposta nativa `reset` e chave idempotente `13e58d92-968f-4e01-9ff7-d90fd105e327`. Antes da ação, o limite incluído já havia chegado a 100% usado; isso não será ocultado nem apresentado como reserva preservada.

Leitura oficial independente em `2026-09-06T02:15:39Z`: **0% usado/100% disponível**, **2.500 créditos de saldo, inalterados**, **dois resets gratuitos restantes**. Nova renovação observada: `2026-09-13T02:15:36Z` (12/09 às 23:15:36 BRT). O provedor alterou o timestamp entre o retorno do resgate e a leitura independente; prevalece o dado posterior, sem promessa de timestamp futuro imutável.

Nova decisão `codex-usage-2fd2d836fdeb7945`, schema 1.1 válido, histórico byte-idêntico, GREEN. O bloqueio de novas etapas por CRITICAL_RESERVE não se aplica a essa leitura. Mantêm-se qualidade, preflight, deduplicação, prioridades iguais, custo técnico zero e proibição de nova compra/recarga. Não foram usados os dois resets restantes. O QR Dolar recebeu a atualização material.

Provas: `output/operations/codex-usage/reset-attempts/reset-20260906T021406Z.intent.json`, receipt ao lado com antes/retorno/contraprova, e `output/operations/codex-usage/observations/account-20260906T021539Z.json`. O campo `consumed_now=false` da decisão de observação indica que o avaliador local não executa resgates; o resgate real está registrado separadamente no receipt nativo e na diferença 3→2, não foi negado ou apagado.

A [documentação oficial do App Server](https://learn.chatgpt.com/pt-BR/docs/app-server) e a skill OpenAI Docs orientaram uso de chave idempotente única e nova leitura após o resgate. A limitação de capacidade finita permanece. Os valores 98%/2% e três resets abaixo são histórico pré-resgate.

Modelagem Youtube e QR Dolar são igualmente importantes e compartilham **um único limite da conta**. Não existem dois saldos independentes nem atribuição oficial por projeto na interface consultada. Não inventar uma divisão percentual.

## Implementação

`config/codex-usage-policy.json` identifica ambos os project IDs. `hero_engine/codex_usage_governance.py` materializa decisões 1.1 com a coordenação; o schema preserva decisões históricas 1.0. O novo campo `has_credits` não deduz origem comprada apenas de `hasCredits=true`.

Leitura nativa registrada em **2026-09-06T01:48:37Z** (05/09 às 22:48:37 BRT):

- 98% usado, 2% restante; janela de 10.080 minutos.
- Renovação: 10/09 às 06:56:07 BRT (`2026-09-10T09:56:07Z`). O provedor variou um segundo entre leituras; prevalece a mais recente.
- Saldo separado: 2.500 créditos finitos; três resets gratuitos disponíveis, nenhum consumido nesta coordenação.
- Decisão `codex-usage-d8389a7b42f1a30e`: `CRITICAL_RESERVE`; reserva de 10% **não preservada**; trabalho novo de alto consumo false.
- Fonte sanitizada em `output/operations/codex-usage/observations/account-20260906T014837Z.json`; decisão em `output/operations/codex-usage/latest.json`, com histórico imutável byte-idêntico. Sem credencial/ID da conta.

Limite incluído, créditos e resets são grandezas distintas. Saldo não significa renovação semanal, autorização de compra ou capacidade infinita. Variação da conta não pode ser atribuída exclusivamente a um dos projetos.

## Aplicação nas duas operações

1. Uma consulta antes de nova etapa de alto consumo e no monitor diário existente. Compartilhar a decisão, sem polling contínuo ou monitor duplicado.
2. Priorizar segurança, recuperação, compromissos e próximos passos críticos com prazo real nas duas operações. Igual importância não implica fabricar cota individual de 50%.
3. Concluir checkpoints seguros e testes necessários de alterações em curso. Não interromper render, transação, processo residente ou efeito externo no meio para poupar uso.
4. Abaixo de 10%, adiar expansão discricionária, pesquisa ampla, fan-out e inspeções sem mudança. Preservar contexto e evidência para retomada; runtimes locais implementados/aprovados continuam sob seus gates.
5. Manter melhor modelo suportado/esforço `ultra`, sem diminuir qualidade ou testes críticos. Esta rodada não alterou modelo, esforço ou configuração de cobrança.
6. Não comprar, ligar recarga, usar API paga ou resgatar reset sem autorização específica aplicável. Saldo observado não cria orçamento técnico novo.
7. Compartilhar somente capacidade; estratégia, dados, identidade, executor, permissões e gates permanecem próprios de cada projeto.

A tarefa QR Dolar, `Extrair conversa completa`, confirmou registro em `dynamic-qr-suite/docs/CODEX_CAPACITY_COORDINATION_2026-09-05.md`; o arquivo foi lido para contraprova. Esta tarefa não alterou código comercial nem publicou no QR Dolar.

A automação existente `HERO Engine — rotina diária` recebeu preflight conjunto antes de seus passos extensos, preservando instruções anteriores e horário; nenhum monitor novo. Sem mudança relevante, permanece silenciosa.

## Provas e limites

Contraprova final da coordenação: 31/31 testes conjuntos de governança, lease, OCR e quality passaram em 2,624 s. O prompt salvo da automação coincide exatamente com o preflight novo + prompt anterior; horário, tarefa destino e status ACTIVE foram preservados. Em `2026-09-06T01:56:05.7371517Z`, a leitura local confirmou PID 18288 vivo e 80 caches de segmentos concluídos, sem interrupção. Isso não aprova o vídeo nem comprova deployment das correções.

**6/6 testes focais PASS**: faixas sem downgrade; materialização/schema/histórico; proibição de compra/recarga/downgrade; reserva única/saldo finito; rejeição de duplicata/prioridade desigual/dois pools/atribuição inventada; compatibilidade histórica. A decisão viva passou no schema e no comparativo byte a byte.

É governança cooperativa registrada nas duas tarefas, **não hard cap da plataforma**. O avaliador local recebe uma leitura nativa Codex; não intercepta todas as chamadas do aplicativo. Atividades externas e tarefas em curso também consomem a conta. Não há garantia de créditos inesgotáveis, duração exata ou erro zero. O estado atual é risco de esgotamento do limite incluído, não reserva saudável.

A [documentação oficial de preços e uso](https://learn.chatgpt.com/docs/pricing) confirma limites compartilhados entre tarefas locais/cloud, consumo variável e distinção entre limite incluído e créditos. A skill OpenAI Docs orientou essa conferência, sem migração de modelo ou contratação.
