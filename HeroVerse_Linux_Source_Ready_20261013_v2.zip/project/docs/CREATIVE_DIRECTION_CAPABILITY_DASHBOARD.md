# Painel de capacidade — Direção Criativa

## Snapshot de incorporação

- Registro: `config/visual_style_registry.json` v2.0.0.
- Total de entradas família+formato: `291`.
- Conceitos textuais únicos: `286`; os cinco nomes repetidos em famílias distintas permanecem entradas distintas porque o pipeline e o risco mudam por família.
- FormatPack completo: `config/format_packs/fp-broll-cinematic-narration-v1.json`.
- Uso regular autorizado: nenhum.

| Estado | Quantidade | Pode produzir? | Falta principal |
|---|---:|---|---|
| CATALOGED | 290 | não | especificação técnica integral |
| SPECIFIED | 0 | não | protótipo reproduzível |
| PROTOTYPED | 1 | não | matriz e revisão humana independente do DRAFT/qualificação STANDARD |
| VALIDATED | 0 | somente teste controlado futuro | hardening e envelope |
| PRODUCTION_READY | 0 | sim, dentro do envelope | — |
| LIMITED | 0 | sim, somente no limite documentado | — |
| BLOCKED | 0 | não | remoção comprovada do bloqueio |
| DEPRECATED | 0 | não | substituição/replay apenas |

## Caminho de promoção

`CATALOGED -> SPECIFIED`

- todos os 41 campos técnicos do schema preenchidos;
- pipeline principal, alternativo e fallback definidos;
- adapter, custo, hardware, direito, risco e testes conhecidos;
- nenhuma capacidade presumida.

`SPECIFIED -> PROTOTYPED`

- amostra representativa renderizada;
- parâmetros, versões, seeds/refs e hashes congelados;
- TakePlan e Style Bible resolvíveis;
- custo, tempo e recursos observados;
- nenhum fallback silencioso.

`PROTOTYPED -> VALIDATED`

- matriz aplicável executada;
- todos os gates críticos da amostra em PASS;
- revisão humana independente do gerador;
- comparação contra padrão-ouro;
- defeitos e limitações registrados.

`VALIDATED -> PRODUCTION_READY`

- replay determinístico ou tolerância documentada;
- regressão passa;
- operação no nível STANDARD passa;
- direitos/comercialidade confirmados;
- monitoramento, rollback e limite de custo definidos.

`VALIDATED -> LIMITED`

- somente quando a amostra passa em escopo estreito;
- `limitation_contract` obrigatório;
- qualquer uso fora do escopo é bloqueado.

## Primeiro pack

`fp-broll-cinematic-narration@1.1.0` está `PROTOTYPED`, com produção desautorizada. Evidências materiais:

1. render `render-c3fc1b1301f61f67f67c`, hash `960012…eef1`, 252,4 s, 1080p/30 fps;
2. 7.572 frames e deriva cumulativa take a take de 0 ms;
3. 44 takes, Style Bible e direitos/hashes resolvíveis;
4. QA `creative-qa-c1f266b64c5d3d7f7e4e`: 7 PASS, 9 NEEDS_REVIEW, 1 N/A, PUBLICATION BLOCKED;
5. zero black frame, freeze ou transição dura interna; p95 de luminância 7,928945;
6. -16,21 LUFS e -1,35 dBTP; direitos e originalidade automática aprovados;
7. custo externo observado: USD 0.

O baseline acima foi rejeitado criativamente. A revisão `creative-v2.1` acrescentou evidência sem promover o estado:

1. render `render-v2-2b8e3c358fc5323eb3b9`, hash `eae07a…2ffc`, 135,2 s, 4.056 frames e deriva zero;
2. 13 ativos distintos, 5/5 ações concretas com prova visual, nenhuma repetição consecutiva fora do hook e máximo de 14,4231% do runtime por recorte de terceiro;
3. 11/11 contratos criativos automáticos PASS;
4. zero black/freeze após o detector reprovar e confirmar a correção do hook;
5. -16,15 LUFS, -1,30 dBTP e originalidade 0,006154;
6. QA vigente: 7 PASS, 9 NEEDS_REVIEW, 1 N/A e PUBLICATION BLOCKED.

A revisão `creative-v3.1` acrescentou a evidência automática mais recente, ainda sem promoção:

1. render `render-v3-9c8379b2fab4fb430ea5`, hash `e1f45f…43c8`, 238,7 s, 7.161 frames e deriva zero;
2. 59 takes, 18 ativos, três fontes e sete eventos no hook 0–8 s;
3. paisagem dominante reduzida de 77,2929% para 17,5534%; maior recorte de terceiro 4,6502%;
4. captions com 59 cues, cobertura 1,0 e máximo de 12 palavras;
5. zero black/freeze, -16,34 LUFS, -1,23 dBTP e 18/18 remediações automáticas PASS;
6. três challengers de thumbnail mecanicamente válidos, sem vencedor autoatribuído;
7. QA `READY_FOR_INDEPENDENT_HUMAN_REVIEW`; `publication_eligible=false` e FormatPack ainda `PROTOTYPED`.

Esse checkpoint foi supersedido e reprovado por D-060: os seis motivos mais usados somavam 66,3176% do runtime. O baseline permanece arquivado como evidência negativa.

A revisão vigente `creative-v3.2` acrescenta evidência mais rígida, ainda sem promoção:

1. render DRAFT SHA-256 `b853b292…fde4a4`, 238,7 s, 7.161 frames e deriva zero;
2. 59 takes e 22 fontes, incluindo quatro infográficos originais locais/zero-cost;
3. maior fonte 8,2111%, seis maiores 44,3653%, máximo quatro usos e três aparições/60 s;
4. paisagem dominante 24,7591%, abaixo do limite específico de 25%;
5. zero black/freeze, zero hard transition intratake, -16,34 LUFS e -1,23 dBTP;
6. 22/22 checks automáticos PASS; STANDARD `33829cd7…3260c` e replay SSIM 0,99782;
7. QA `READY_FOR_INDEPENDENT_HUMAN_REVIEW`; a revisão suplementar por Codex é explicitamente não humana; FormatPack continua `PROTOTYPED`.
8. regressão 129/129, 65 schemas válidos e manifesto de 550 artefatos/3.080.032.782 bytes.
9. decisão de metadata preserva o vídeo congelado e seleciona `The 24-Hour Test: What To Do After You Pray` (vidIQ 91 vs baseline 82), mas mantém o score como evidência auxiliar e a embalagem como pendência humana.

A qualificação `STANDARD` automática também foi materializada, sem promoção:

1. candidato de 305.941.870 bytes, 9.991,923 kb/s, 238,7 s e 7.161 frames;
2. loudness -16,34 LUFS, true peak -1,23 dBTP e zero black/freeze;
3. SSIM 0,998247 contra o master DRAFT;
4. replay independente com SSIM 0,998095, áudio decodificado idêntico, mesma timeline/frames e nove bytes de diferença;
5. H.264 multithread não foi bit/pixel exato, portanto o sistema registra tolerância reproduzível e não alega determinismo de bytes;
6. `automatic_profile_status=PASS`, porém produção/publicação continuam falsas por gates humanos, FormatPack e OAuth.
7. recuperação do FAIL inicial documentada; dry-run fixa o hash STANDARD; regressão atual 111/111 e manifesto de 405 artefatos/2.209.404.638 bytes passam.
8. overlay do catálogo próprio via vidIQ registrado como `NO_NEW_EVIDENCE`; nenhum badge, score ou mecanismo promove capacidade antes de resultado publicado.
9. formulário estruturado de revisão confere o hash exato, 9 janelas, 12 gates e A/B/C; a execução real permanece `PENDING_HUMAN_INPUT` e não altera a contagem de capacidade.
10. plugin vidIQ está `LIMITED`: pesquisa pública e ledger gratuito funcionam, mas zero canais próprios foram autorizados; Analytics privado e aprendizado de resultado continuam indisponíveis.

Lacunas que impedem `VALIDATED`:

1. revisão humana independente do vídeo completo;
2. aprovação humana de pronúncia, emoção e identidade vocal;
3. revisão de publicity/releases;
4. julgamento independente de hook, semântica visual e identidade do canal;
5. aprovação humana independente do candidato STANDARD e fechamento da matriz aplicável;
6. memória, armazenamento, energia, depreciação e trabalho humano ainda não precificados.

O painel não usa porcentagem agregada de “prontidão”. O estado é determinado pelo primeiro requisito obrigatório ausente.

Quando houver um receipt humano final e integralmente PASS, a transição preparada é somente `PROTOTYPED -> LIMITED`, com contrato explícito para HeroVerse, inglês, long-form, clip-based, pipeline `pipeline-clips-longform-v1@1.0.0`, STANDARD, duração observada e custo externo zero. `PRODUCTION_READY` continua proibido sem generalização e evidência adicional.
