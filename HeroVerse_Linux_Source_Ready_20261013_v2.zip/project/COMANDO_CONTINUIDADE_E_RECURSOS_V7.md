﻿# V7 â€” CONTINUIDADE E RECURSOS RÃPIDOS

Vinculante a V2â€“V6. Objetivo: nenhum tempo ocioso evitÃ¡vel e nenhuma repetiÃ§Ã£o sem progresso.

1. O `HeroVerse-ResourceGuard` Ã© obrigatÃ³rio e independente do turno do Codex. Ele deve permanecer ativo a cada 1 minuto.
2. Antes de estÃ¡gio pesado, execute `output/runtime/gestor-central/guards/resource_guard.ps1 -MinFreeRamMiB 1536 -MinFreeDiskGiB 12 -Preflight`.
3. O guard deve ser rÃ¡pido; nÃ£o fazer varredura recursiva ampla a cada ciclo. Higiene pesada sÃ³ fora de uma tarefa crÃ­tica ativa.
4. Durante regressÃ£o/render/ASR/aplicaÃ§Ã£o, priorize o processo crÃ­tico como AboveNormal e reduza OneDrive/sincronizadores nÃ£o crÃ­ticos para BelowNormal; nunca mate o processo crÃ­tico.
5. Disco abaixo de 12 GiB: limpar primeiro TEMP/recycle/cache/instaladores e arquivos redundantes comprovadamente descartÃ¡veis. NÃ£o apagar evidÃªncias, credenciais, bancos, cÃ³digo, mÃ­dia necessÃ¡ria ou dados pessoais de valor incerto.
6. RAM abaixo do alvo: trim rÃ¡pido de working sets nÃ£o crÃ­ticos; se ainda insuficiente, serializar concorrentes e avanÃ§ar frente independente, sem encerrar a missÃ£o.
7. `RESOURCE_WAIT` local nunca Ã© resposta terminal. Resolver recurso ou trabalhar outra frente segura.
8. Progress Guard continua vinculante: duas falhas iguais bloqueiam terceira tentativa equivalente.
9. Um turno terminar nÃ£o significa missÃ£o terminar. Enquanto nÃ£o houver PROJECT_COMPLETE, a mesma thread deve retomar automaticamente do checkpoint.
10. Reduzir o heartbeat desta MESMA `Analyze YouTube channel` para aproximadamente 2 minutos, se suportado, sem criar outro chat/thread. Se houver trabalho ativo, nÃ£o duplicar; se idle em marco intermediÃ¡rio, continuar imediatamente.
11. Para processos longos, preferir watcher por evento ao polling do modelo. Ao terminar, reconciliar e avanÃ§ar o prÃ³ximo gate.
12. Prioridade invariÃ¡vel: fechar manutenÃ§Ã£o -> retomada -> D-116 -> code freeze -> operaÃ§Ã£o real -> pesquisa -> produÃ§Ã£o -> publicaÃ§Ã£o -> mÃ©tricas -> aprendizagem viva -> generalizaÃ§Ã£o -> produto.
13. Nunca confundir atividade com progresso. Cada ciclo deve produzir mudanÃ§a de estado verificÃ¡vel.
14. SÃ³ encerrar em PROJECT_COMPLETE ou TRUE_EXTERNAL_BLOCKER_ALL_FRONTS comprovado, depois de esgotar frentes independentes.
