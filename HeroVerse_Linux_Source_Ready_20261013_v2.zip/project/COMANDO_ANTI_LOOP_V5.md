# EMENDA V5 — PROGRESSO COMPROVÁVEL, SEM CICLO VAZIO

Esta emenda complementa V2/V3/V4 e prevalece em matéria de continuidade e anti-loop.

1. Cada ciclo precisa produzir mudança de estado verificável rumo ao PROJECT_COMPLETE.
2. Duas falhas consecutivas com a mesma causa encerram aquela hipótese; é proibida uma terceira tentativa equivalente.
3. Após duas falhas iguais, mudar obrigatoriamente a abordagem: causa, recurso, launcher, implementação, modelo ou frente independente.
4. Nunca confundir atividade, polling, logs ou CPU com progresso de projeto. Progresso = gate anterior encerrado + próximo gate elegível iniciado/concluído.
5. Não repetir regressão, render, aplicação ou análise íntegra já válida sem nova causa material documentada.
6. RESOURCE_WAIT exige recuperação V4 antes de nova tentativa. Só repetir após medição mostrar recurso acima do gate com margem operacional, não apenas no limite.
7. Para RAM, alvo pré-aplicação: >= 1024 MiB livres; preferível >= 1536 MiB quando recuperável sem encerrar processos essenciais.
8. Se o recurso cair novamente durante preparação, diagnosticar o consumidor que cresceu antes de tentar de novo.
9. Polling do modelo não conta como trabalho; usar espera/processo local/evento e retomar somente em mudança material.
10. Se uma frente estiver bloqueada, avançar outra frente independente segura do V2.
11. A cada heartbeat, registrar mentalmente: estado anterior, evidência nova, próximo gate. Se não houver evidência nova, não repetir a mesma ação.
12. Code freeze após estabilização: não reabrir infraestrutura por resultado editorial/algorítmico ruim sem evidência de defeito técnico.
13. Prioridade: aplicação -> retomada -> D-116 -> operação real -> pesquisa -> produção/publicação -> analytics/aprendizado.
14. Tudo permanece na raiz oficial e na mesma thread Analyze YouTube channel.
15. Só encerrar em PROJECT_COMPLETE ou TRUE_EXTERNAL_BLOCKER_ALL_FRONTS comprovado.