# REGRA VINCULANTE — RAIZ ÚNICA DO PROJETO

Raiz oficial e única do HeroVerse/Modelagem Youtube:
`C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube`

Todo código, configuração, evidência, log, checkpoint, relatório, mídia necessária, resultado de teste, pacote, manifesto e documentação do projeto deve permanecer dentro desta raiz ou de suas subpastas.

Não criar cópias permanentes do projeto em Desktop alternativo, Downloads, TEMP, outras pastas do usuário, outro workspace, outro drive ou outro chat/agente.

Arquivos temporários inevitáveis do sistema, cache de runtime e metadados internos do próprio Codex podem existir fora da raiz somente enquanto forem transitórios; não são fonte de verdade e devem ser descartados quando seguros.

Nunca mover a fonte de verdade para fora desta pasta. Qualquer artefato produzido fora por necessidade técnica deve ser consolidado de volta na raiz antes de ser considerado válido.

Limpeza e otimização devem preservar esta raiz como fonte única e nunca apagar evidência, código, credencial necessária, banco válido ou artefato ainda consumido.