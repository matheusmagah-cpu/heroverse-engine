from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def build_visual_continuity_bible(
    *,
    channel_model: dict[str, Any],
    format_pack: dict[str, Any],
    asset_manifest: dict[str, Any],
    created_at: str | None = None,
) -> dict[str, Any]:
    """Materialize channel identity and continuity invariants for one pack version."""

    dna = channel_model["channel_dna"]
    spec = format_pack["specification"]
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    bible_id = _stable_id("style-bible", channel_model["model_id"], format_pack["format_pack_id"], format_pack["version"])
    references = [
        {
            "reference_id": asset["asset_id"],
            "uri": asset["uri"],
            "hash": asset["content_hash"],
            "rights_ref": asset["rights_evidence_uri"],
            "purpose": asset["semantic_role"],
        }
        for asset in asset_manifest["assets"]
        if asset.get("production_eligible") is True
    ]
    bible = {
        "schema_version": "1.0.0",
        "style_bible_id": bible_id,
        "channel_id": "heroverse74",
        "channel_dna_version": channel_model["model_id"],
        "version": "1.0.0",
        "identity": {
            "principles": [dna["editorial_promise"], *dna["identity"]["visual"]],
            "invariants": [
                "English narration and restrained original typography",
                "every image has a declared narrative job",
                "pressure moves toward earned clarity rather than spectacle",
                "rights status remains attached to every source take",
            ],
            "forbidden_mixes": [
                "random transition packs",
                "anime, 3D, UGC or simulated camera aesthetics inside this pack",
                "ungraded source clips beside the locked cinematic treatment",
                "copied medieval, battle, narrator or typography identity from references",
            ],
        },
        "palette": {
            "locked_hex": spec["palette"]["locked_hex"],
            "role_map": {"dominant": "#081827", "accent": "#D7A94A", "text": "#E8EDF2", "support": "#2C5364"},
            "tolerance_delta_e": 8.0,
        },
        "typography": {
            "families": ["Bahnschrift", "Arial"],
            "weights": ["Semibold", "Bold"],
            "case_rules": ["hook accents may use uppercase", "body overlays use sentence case", "maximum two lines"],
            "safe_area": {"horizontal_percent": 8, "vertical_percent": 8},
            "minimum_sizes": {"1920x1080": 54, "1080x1920": 60},
        },
        "lighting_reference": {
            "key_direction": "side or back light with one readable focal subject",
            "temperature": "cool tension progressing to controlled warm payoff",
            "contrast_ratio": "high but shadow detail retained",
            "exceptions": ["source footage cannot be relit; reject a take if grading cannot converge without damage"],
        },
        "camera_and_lenses": {
            "allowed_shots": spec["framing"],
            "allowed_movements": spec["camera_movements"],
            "lens_set": spec["simulated_lenses"],
            "stabilization_rules": ["retain intentional source movement", "reject accidental shake", "do not synthesize impossible parallax"],
        },
        "characters": [],
        "environments": [
            {
                "environment_id": "env-tension",
                "description": "weather, shadow and scale that communicate pressure without claiming a factual event",
                "layout": "single focal path or horizon with negative space",
                "lighting": "cool low-key",
                "palette": ["#081827", "#2C5364"],
                "time_state": "overcast or predawn",
                "weather_state": "controlled movement",
                "object_positions": ["horizon held outside center text safe area"],
                "reference_ids": [asset["asset_id"] for asset in asset_manifest["assets"] if asset["semantic_role"] in {"tension", "pressure", "urgency"}],
            },
            {
                "environment_id": "env-clarity",
                "description": "open landscape or moving water that communicates an actionable path",
                "layout": "leading line toward clear focal destination",
                "lighting": "neutral-to-warm side or back light",
                "palette": ["#081827", "#D7A94A", "#E8EDF2"],
                "time_state": "dawn or golden transition",
                "weather_state": "stable",
                "object_positions": ["leading line remains visually legible"],
                "reference_ids": [asset["asset_id"] for asset in asset_manifest["assets"] if asset["semantic_role"] in {"decision", "clarity", "progress", "renewal"}],
            },
        ],
        "important_objects": [
            {"object_id": "obj-path", "description": "path or leading line representing the next faithful action", "scale": "environmental", "colors": ["#E8EDF2", "#D7A94A"], "continuity_rules": ["must remain directional", "must not imply a literal location in narration"]}
        ],
        "wardrobe": [],
        "proportions_and_scale": ["do not alter human proportions", "retain source aspect ratio before crop", "no subject stretch"],
        "spatial_continuity": ["screen direction changes only on a narrative turn", "adjacent horizons must not jump without a motivated cut"],
        "temporal_continuity": ["weather and time of day remain coherent inside each narrative block", "the overall arc may move from storm/predawn to calm/dawn"],
        "reference_assets": references,
        "seeds_and_embeddings": [{"provider_or_model": "not-applicable-source-clips", "identifier": "N/A", "scope": "clip-based prototype", "reproducibility_status": "REPRODUCIBLE"}],
        "continuity_rules": [
            {"rule_id": "CONT-001", "rule": "Palette divergence above delta-E tolerance requires rejection or documented narrative exception.", "critical": True, "verification": "sample representative frames and compare locked palette roles"},
            {"rule_id": "CONT-002", "rule": "No adjacent take may repeat the same source range or reverse screen direction without motivation.", "critical": True, "verification": "take-plan adjacency audit"},
            {"rule_id": "CONT-003", "rule": "A source image must transmit the declared semantic job; decorative filler fails.", "critical": True, "verification": "take-level semantic review with asset and narration evidence"},
            {"rule_id": "CONT-004", "rule": "Character, identity, age, wardrobe and environment state cannot change accidentally.", "critical": True, "verification": "automated visual fingerprints plus independent human review"},
            {"rule_id": "CONT-005", "rule": "Text uses only the locked font family, palette and safe area.", "critical": True, "verification": "render overlay geometry and font manifest audit"},
        ],
        "decision_history": [
            {
                "decision_id": _stable_id("visual-decision", bible_id, "initial"),
                "change": "Created the first HeroVerse-specific clip-based style contract.",
                "reason": "The ChannelDNA prohibits inheriting the reference channel's visual identity.",
                "evidence_refs": ["channel-model:channel_dna", f"format-pack:{format_pack['format_pack_id']}@{format_pack['version']}"],
                "created_at": timestamp,
            }
        ],
        "divergence_policy": {
            "automatic_checks": ["palette", "aspect ratio", "frame size", "duplicate source range", "safe area", "continuity references", "asset rights status"],
            "thresholds": {"palette_delta_e": 8.0, "minimum_semantic_alignment": 0.8, "maximum_duplicate_frame_ratio": 0.01},
            "exception_requires": ["narrative justification", "evidence", "owner or designated independent reviewer approval"],
            "failure_action": "BLOCK_RENDER_OR_PUBLICATION",
        },
        "created_at": timestamp,
    }
    if format_pack["format_pack_id"] == "fp-narrated-reflection-static":
        # This is a designed still, not a claim about changing photographed
        # scenes. Keep the legacy branch byte-for-byte in its returned content.
        palette = spec["palette"]["locked_hex"]
        if len(palette) < 3:
            raise ValueError("static reflection requires background/accent/text palette roles")
        bible["identity"]["invariants"] = [
            "Original English narrative remains understandable with the screen off",
            "One owned static composition supports, but does not replace, the audible promise",
            "Exact rights, title, typography and audio evidence remain required",
        ]
        bible["identity"]["forbidden_mixes"] = spec["constraints_and_negative_prompts"]
        bible["palette"]["role_map"] = dict(zip(("dominant", "accent", "text"), palette[:3]))
        bible["lighting_reference"] = {
            "key_direction": "Not applicable: designed static composition",
            "temperature": "Locked palette, no photographic-lighting claim",
            "contrast_ratio": spec["contrast"],
            "exceptions": [],
        }
        bible["camera_and_lenses"]["stabilization_rules"] = ["No simulated camera motion; preserve the owned raster geometry"]
        bible["environments"] = []
        bible["important_objects"] = []
        bible["proportions_and_scale"] = ["Preserve the raster aspect ratio; no stretching"]
        bible["spatial_continuity"] = ["Exact fixed composition and safe area throughout the audio"]
        bible["temporal_continuity"] = ["Intentional static hold; speech and pauses carry progression"]
        bible["reference_assets"] = [
            reference for reference in references
            if any(asset["asset_id"] == reference["reference_id"]
                   and asset.get("rights_status") == "OWNED"
                   and str(asset["uri"]).lower().endswith((".png", ".jpg", ".jpeg"))
                   for asset in asset_manifest["assets"])
        ]
        bible["seeds_and_embeddings"] = [{"provider_or_model": "owned-static-composition", "identifier": "N/A", "scope": "fixed designed raster", "reproducibility_status": "REPRODUCIBLE"}]
        bible["continuity_rules"] = [
            bible["continuity_rules"][0],
            {"rule_id": "CONT-002", "rule": "The bound still remains unchanged; intentional static frames are not an accidental freeze.", "critical": True, "verification": "Compare decoded output to the authenticated composition at start/middle/end; verify actual audio progression."},
            {"rule_id": "CONT-003", "rule": "Title and composition describe the actual original audio, without implying photographed events.", "critical": True, "verification": "Bound script/title/composition correspondence and rights evidence."},
            bible["continuity_rules"][4],
        ]
        bible["decision_history"][0]["change"] = "Created the audio-first static contract for this exact FormatPack version."
        bible["divergence_policy"]["automatic_checks"] = ["palette", "aspect ratio", "frame size", "safe area", "bound static raster", "asset rights status", "audio progression"]
        bible["divergence_policy"]["thresholds"] = {"palette_delta_e": 8.0, "minimum_semantic_alignment": 0.8}
    return bible
