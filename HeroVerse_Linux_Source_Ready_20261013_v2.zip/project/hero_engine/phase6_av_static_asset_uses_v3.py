"""Twenty-nine untimed uses: exact replay of 25 plus four reviewed questions.

No historical still is decoded again. Question source inspection reopens the
fixed static QA/ink/case evidence and PNG containers, not OCR or pixel QA.
Rights binding is recomposed from the external registry, never newly granted.
This module creates no timestamp, source admission, rendering or publication.
"""
from __future__ import annotations

import copy
import importlib.util
import math
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_static_sources as sources
from . import phase6_av_static_uses_v2_replay as previous
from . import phase6_av_question_sources as question
from . import phase6_question_asset_rights as rights
from . import phase6_av_question_case_amendment as case
from .phase6_narration_audio_inventory import Reader as MetadataReader
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-static-asset-uses-v3"
SCHEMA = "schemas/phase6_av_static_asset_uses_v3.schema.json"
REGISTRY_DIRECTORY = "output/operations/phase6/av-admission/evidence/question-rights-registrations/v1"
REGISTRATION = {"path": REGISTRY_DIRECTORY + "/receipt.json",
    "sha256": "ab6bdbb32d4e9ccf399e7a6243cca7fb70de20502e1b535097acb71177b43db4"}
REQUEST = {"path": REGISTRY_DIRECTORY + "/request.json",
    "sha256": "0f62d3ade43c684cfdcd312fcde2fa7b58358f0af8068bf043eeac599fe5220c"}
CLAIM = {"path": REGISTRY_DIRECTORY + "/claim.json",
    "sha256": "8a356aaa3295d55338ef90e452fccb9fea10d40d1446a3e8f4b0e7928f3b78aa"}
REGISTRAR = question.HERE + "/register_question_rights.py"
REGISTRAR_TEST = question.HERE + "/test_register_question_rights.py"
REGISTRAR_SHA = "aa773df1dcce24910981a8d70c1a5704be272c36451fc941f1d6cf0a64c3c2e3"
REGISTRAR_TEST_SHA = "0d6c805d37ca7159afe6f5ec49abc5fb7c7bdddd8c5dacce473be6db02a436e1"
IMPLEMENTATION_PINS = {
    "hero_engine/phase6_av_question_case_amendment.py": "2da7b523f2a3ad6b8c70727791649177c77aa4f2dd4434393d98bf62103b1509",
    "schemas/phase6_av_question_case_amendment.schema.json": "2fc8f9aefdcd8d30ddb6e6e0b90919e3199268c67931b791cfd6497dad8f8004",
    "tests/test_phase6_av_question_case_amendment.py": "9915fc1af1716eddd7815b343eb22e4866995902d75d940236b512689a1b8578",
    "hero_engine/phase6_av_static_uses_v2_replay.py": "68221c67b940ee2a8d65fda3d30d5d2756bb5561c6d0cda5d7bd3b40745e5144",
    "tests/test_phase6_av_static_uses_v2_replay.py": "8d694af4ce2a048a5178a1f8c52810ca542f291ef07b02c7ce937200f9576da7",
    "hero_engine/phase6_av_question_sources.py": "3ed0553ab253e81458f786aa9ba15862ef5a191157bcf9bfc6ebcc0922953ad2",
    "tests/test_phase6_av_question_sources.py": "b623b40c945520423bb0e81e19a7b5894527169b6bc47ac19251854a3fb3cc06",
    "hero_engine/phase6_question_asset_rights.py": "15eb742aa244ca75638e53e99a561fd4c4749a1fd87b41fc53f14cf175839366",
    "schemas/phase6_question_static_rights.schema.json": "78668a612dfb543885754fedb9dbd98bca799f4eb381492f8d7ea10c4e0c7e27",
    "tests/test_phase6_question_asset_rights.py": "9288a0f5d70dfb9a2a1c1b72c1913cac3b4eca93604a7f255cf29fcb375a64b6",
    REGISTRAR: REGISTRAR_SHA, REGISTRAR_TEST: REGISTRAR_TEST_SHA,
}
AUTHORITY = dict(previous.previous.AUTHORITY)


def _same(a, b, message):
    sources._same(a, b, message)


def _json(reader, binding):
    return previous.previous._json(reader, binding)


def _dependencies(reader, items):
    """Bounded root/font reader; 32MiB only for the three fixed OCR models."""
    if type(items) is not list or not items:
        raise ValueError("v3 dependency population missing")
    seen = set()
    for item in items:
        if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                or type(item["path"]) is not str or item["path"] in seen
                or type(item["size_bytes"]) is not int or item["size_bytes"] <= 0):
            raise ValueError("v3 dependency fields or multiplicity differ")
        seen.add(item["path"])
        path = Path(item["path"])
        if not path.is_absolute() or ".." in path.parts:
            raise ValueError("v3 absolute confined dependency required")
        local = path.is_relative_to(reader.root)
        if not local and sources.EXTERNAL_DEPENDENCY_PINS.get(str(path)) != item["sha256"]:
            raise ValueError("v3 dependency escapes root or fixed external allowlist")
        if str(path) in sources.EXTERNAL_DEPENDENCY_PINS:
            _same(item["sha256"], sources.EXTERNAL_DEPENDENCY_PINS[str(path)], "v3 external pin differs")
        model = question.MODEL_PINS.get(path.relative_to(reader.root).as_posix()) if local else None
        if model:
            _same([item["sha256"], item["size_bytes"]], list(model), "v3 model pin or size differs")
        raw = reader.read_path(path, item["sha256"], limit=32 * 1024**2 if model else 16 * 1024**2)
        if len(raw) != item["size_bytes"]:
            raise ValueError("v3 dependency byte size differs")


def _registry_inventory(reader, registry):
    folder = reader.path(REGISTRY_DIRECTORY)
    if {path.name for path in folder.iterdir()} != {"claim.json", "request.json", "receipt.json"}:
        raise ValueError("question rights registration inventory differs")
    entries = registry["request"]["document_bindings"]
    names = {Path(item["path"]).name for item in entries}
    directory = reader.path("output/operations/phase6/av-admission/evidence/question-static-rights")
    if len(names) != 8 or {path.name for path in directory.iterdir()} != names:
        raise ValueError("question eight-rights-document inventory differs")
    for path in (*folder.iterdir(), *directory.iterdir()):
        sources._resident(path)
        if not path.is_file() or path.stat().st_nlink != 1:
            raise ValueError("question rights inventory is not regular single-link files")


def _registry(reader):
    request, registry, claim = (_json(reader, binding) for binding in (REQUEST, REGISTRATION, CLAIM))
    reader.read(REGISTRAR, REGISTRAR_SHA)
    spec = importlib.util.spec_from_file_location("question_rights_registrar_pure_replay_v3", reader.root / REGISTRAR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _same(str(module.ROOT), str(reader.root), "question rights registrar root differs")
    reader.read(REGISTRAR, REGISTRAR_SHA)
    recorded = request["recorded_at"]
    if rights._utc(recorded) < rights._utc(rights.REVIEW_NOT_BEFORE):
        raise ValueError("question registry predates specific editorial review")
    code = {**module.FIXED_PINS, REGISTRAR: REGISTRAR_SHA, REGISTRAR_TEST: REGISTRAR_TEST_SHA}
    _same(request["module_bindings"], [{"path": str(reader.root / name), "sha256": code[name]} for name in module.CODE_PATHS],
          "question registry code population differs")
    for item in request["module_bindings"]:
        reader.read_path(Path(item["path"]), item["sha256"])
    plans = module.plans(reader, recorded)  # Pure exact external-note projection, never run/registration.
    expected = {"version": module.VERSION, "review_binding": {"path": str(reader.root / rights.REVIEW_NOTE), "sha256": rights.REVIEW_NOTE_SHA},
        "recorded_at": recorded, "module_bindings": request["module_bindings"],
        "source_preflight_dependencies": request["source_preflight_dependencies"],
        "states": [{key: row[key] for key in ("template_id", "state_id", "asset_id", "arguments")} for row in plans],
        "document_bindings": [{"path": str(path), "sha256": sources._sha(raw)} for row in plans for path, raw in row["files"]],
        "technical_cost_brl": 0, "authority": dict(rights.AUTHORITY)}
    _same(request, expected, "question registry request does not recompose")
    for row in plans:
        for path, raw in row["files"]:
            if reader.read_path(path, sources._sha(raw)) != raw:
                raise ValueError("question registered rights document differs")
        # Schema, source scope, review/depiction/font/disclosure validation only;
        # all four complete source bindings are reconstituted later in one batch.
        rights._validate(reader.root, **row["arguments"], expected_evidence_mode="LIVE", _preflight_only=True)
    identity = "d171-question-rights-registration-" + REQUEST["sha256"][:24]
    _same(registry["request"], request, "question registry external request differs")
    _same(claim, {"version": module.VERSION, "registration_id": identity, "request_sha256": REQUEST["sha256"],
        "recorded_at": recorded, "status": "CLAIMED_NOT_REGISTERED", "authority": dict(rights.AUTHORITY)}, "question exclusive claim differs")
    _same([registry["registration_id"], registry["status"], registry["state_count"], registry["document_count"],
           registry["lineage_count"], registry["technical_cost_brl"], registry["authority"], registry["image_decode_calls"],
           registry["ocr_inference_calls"], registry["render_calls"], registry["duration_scope"]],
          [identity, "REGISTERED_RIGHTS_ONLY_NOT_ADMITTED", 4, 8, 1, 0, rights.AUTHORITY, 0, 0, 0,
           "THROUGH_RIGHTS_PROOFS_BEFORE_RECEIPT_WRITE"], "question registry scope differs")
    for field, binding in (("request_binding", REQUEST), ("claim_binding", CLAIM)):
        _same(registry[field], {"path": str(reader.root / binding["path"]), "sha256": binding["sha256"]}, "question checkpoint pin differs")
    if rights._utc(registry["created_at"]) < rights._utc(recorded):
        raise ValueError("question registry receipt precedes its request")
    duration = registry["duration_seconds"]
    if type(duration) not in (int, float) or not math.isfinite(duration) or duration < 0:
        raise ValueError("question registry measured duration differs")
    if len(registry["rights_proofs"]) != 4:
        raise ValueError("question registry needs exact four rights proofs")
    for row, proof in zip(plans, registry["rights_proofs"], strict=True):
        previous.previous._identity(proof, "inspection_id", "question-static-rights-")
        _same([proof["version"], proof["status"], proof["scope"], proof["evidence_mode"], proof["source_ready"],
               proof["authority"], proof["technical_cost_brl"], proof["state_id"], proof["asset_id"], proof["rights_status"]],
              [rights.VERSION, "PASS", "RIGHTS_BINDING_ONLY", "LIVE", False, rights.AUTHORITY, 0,
               row["state_id"], row["asset_id"], "OWNED"], "question recorded rights scope differs")
        _dependencies(reader, proof["dependency_bindings"])
    _dependencies(reader, request["source_preflight_dependencies"])
    _registry_inventory(reader, registry)
    return registry


def _case_literal(reader, old):
    compact = previous.previous.compact
    reference = _json(reader, compact.REFERENCE)
    metadata = MetadataReader(reader.root)
    caption = compact.captions.read_caption_intent(metadata, compact.captions.PLAN_BINDING, reference["units"])
    literal = case.read_amended_visual_intent(metadata, case.PROJECTION_BINDING, reference["units"], caption)
    _same(literal["prior_amendment_inspection"], old["literal"], "case amendment changed the historical V3 inspection")
    for item in (*literal["dependency_bindings"], *literal["implementation_dependencies"]):
        data = reader.read(item["path"], item["sha256"][7:])
        if len(data) != item["size_bytes"]:
            raise ValueError("case literal dependency size differs")
    _dependencies(reader, literal["question_replay_dependencies"])
    return literal


def _envelope(root):
    reader = sources._Reader(root)
    for name, digest in IMPLEMENTATION_PINS.items():
        reader.read(name, digest)
    for name in ("hero_engine/phase6_av_static_asset_uses_v3.py", SCHEMA):
        reader.read(name, sources._sha(reader.path(name).read_bytes()))
    old = previous.replay(root)  # Never previous.previous.inspect_static_asset_uses.
    _dependencies(reader, old["dependency_bindings"])
    literal = _case_literal(reader, old)
    registry = _registry(reader)
    return reader, literal, old, registry


def _expected(literal, old_document, registry):
    source_rows, uses = copy.deepcopy(old_document["sources"]), copy.deepcopy(old_document["uses"])
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    for use in uses:
        row, state = states[use["visual_state_id"]]
        _same([row["unit_id"], state["visual_content"]["literal_copy"]], [use["unit_id"], use["literal_copy"]], "case delta changed an existing use")
    for entry in registry["request"]["states"]:
        arguments = entry["arguments"]
        source_rows.append({"source_id": entry["asset_id"],
            "static_source": {key: copy.deepcopy(arguments[key]) for key in ("template_id", "state_id", "receipt_binding")},
            "rights_evidence": {key: copy.deepcopy(arguments[key]) for key in ("provenance_binding", "decision_binding")}})
        row, state = states[entry["state_id"]]
        uses.append({"use_id": "static-use-" + state["state_id"], "visual_state_id": state["state_id"],
            "unit_id": row["unit_id"], "source_id": entry["asset_id"], "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"])})
    return {"kind": "PHASE6_STATIC_ASSET_USES", "schema_version": "3.0.0", "channel_id": sources.CHANNEL,
        "video_id": "video-002", "sources": source_rows, "uses": uses, "technical_cost_brl": 0,
        "source_bindings": {**copy.deepcopy(old_document["source_bindings"]),
            "v2_execution": copy.deepcopy(previous.ANCHOR), "v2_input": copy.deepcopy(previous.INPUT), "v2_inspection": copy.deepcopy(previous.INSPECTION),
            "question_visual_amendment": {"path": case.PROJECTION_BINDING["path"], "sha256": case.PROJECTION_BINDING["sha256"][7:]},
            "question_case_amendment": {"path": case.AMENDMENT_BINDING["path"], "sha256": case.AMENDMENT_BINDING["sha256"][7:]},
            "question_case_staging": {"path": case.STAGING_BINDING["path"], "sha256": case.STAGING_BINDING["sha256"][7:]},
            "question_rights_registration": copy.deepcopy(REGISTRATION), "question_rights_request": copy.deepcopy(REQUEST),
            "question_rights_claim": copy.deepcopy(CLAIM)}}


def _recheck(reader, old, registry, literal):
    # Keep the historical 16MiB reader separate from the new question models.
    legacy_reader = sources._Reader(reader.root)
    legacy_reader.bindings = {item["path"]: copy.deepcopy(item) for item in old["dependency_bindings"]}
    previous.recheck(legacy_reader)
    _dependencies(reader, list(reader.bindings.values()))
    question.recheck_question_dependencies(reader.root, [{"dependency_bindings": list(reader.bindings.values())}])
    case.recheck_question_replay(reader.root, literal)
    _registry_inventory(reader, registry)


def proposed_static_asset_uses(root):
    reader, literal, old, registry = _envelope(root)
    result = _expected(literal, old["input"], registry)
    _recheck(reader, old, registry, literal)
    return result


def inspect_static_asset_uses(root, *, binding):
    reader, literal, old, registry = _envelope(root)
    document = _json(reader, binding)
    schema = sources._json(reader.read(SCHEMA, reader.bindings[str(reader.path(SCHEMA))]["sha256"]))
    Draft202012Validator(schema).validate(document)
    _same(document, _expected(literal, old["input"], registry), "exact twenty-nine-use envelope differs")
    selected = document["sources"][23:]
    current = question.inspect_question_sources(root, requests=[entry["static_source"] for entry in selected])
    _same(sorted(registry["request"]["source_preflight_dependencies"], key=lambda item: item["path"]),
          current[0]["dependency_bindings"], "question preflight dependencies do not recompose from current source chain")
    source_results, use_results = copy.deepcopy(old["inspection"]["sources"]), copy.deepcopy(old["inspection"]["uses"])
    state_map = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    for entry, proof, registered, use in zip(selected, current, registry["rights_proofs"], document["uses"][25:], strict=True):
        _same([proof["inspection_id"], sources._sha(sources._canonical(proof)), canonical_sha(proof)],
              [registered["source_proof"]["inspection_id"], registered["source_proof"]["sha256"], registered["source_proof"]["timeline_canonical_sha256"]],
              "question source differs from externally registered rights source")
        arguments = {**entry["static_source"], **entry["rights_evidence"]}
        replayed = rights._validate(root, **arguments, expected_evidence_mode="LIVE",
                                   _source_loader=lambda _template, _state, _receipt: proof)
        _same(replayed, registered, "question rights binding does not recompose exactly")
        row, state = state_map[use["visual_state_id"]]
        _same([entry["source_id"], proof["state_id"], proof["asset_binding"], use["literal_copy"], state["entry"], row["text"], row["unit_id"]],
              [registered["asset_id"], registered["state_id"], registered["artifacts"]["png_binding"], proof["literal_copy"], proof["entry"], proof["literal_narration"], proof["unit_id"]],
              "question source/use literal or rights association differs")
        source_results.append({"source_id": entry["source_id"], "asset_binding": copy.deepcopy(proof["asset_binding"]),
            "template_id": proof["template_id"], "state_id": proof["state_id"], "lineage_id": proof["lineage_id"],
            "original_unit_id": proof["unit_id"], "original_fragment_ids": copy.deepcopy(proof["fragment_ids"]),
            "original_lexical_target": copy.deepcopy(proof["lexical_target"]), "source_inspection_id": proof["inspection_id"],
            "source_inspection_sha256": sources._sha(sources._canonical(proof)), "rights_inspection_id": registered["inspection_id"],
            "rights_inspection_sha256": sources._sha(sources._canonical(registered))})
        use_results.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]), "source_provenance_unit_id": proof["unit_id"],
            "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
        _dependencies(reader, proof["dependency_bindings"])
    covered = {row["visual_state_id"] for row in use_results}
    _same([len(source_results), len(use_results), len(covered), len(state_map),
           len({row["asset_binding"]["sha256"] for row in source_results}), len({row["lineage_id"] for row in source_results})],
          [27, 29, 29, 100, 26, 3], "twenty-nine-use population differs")
    _recheck(reader, old, registry, literal)
    result = {"version": VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
        "input_binding": copy.deepcopy(binding), "source_bindings": copy.deepcopy(document["source_bindings"]),
        "channel_id": sources.CHANNEL, "video_id": "video-002", "source_count": 27, "use_count": 29,
        "unique_png_content_count": 26, "lineage_count": 3, "sources": source_results, "uses": use_results,
        "remaining_unbound_visual_state_ids": sorted(set(state_map) - covered), "source_ready": False,
        "global_schedule_created": False, "calibrated_timing_available": False, "authority": dict(AUTHORITY), "technical_cost_brl": 0,
        "v2_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "anchor_binding": copy.deepcopy(previous.ANCHOR),
            "input_binding": copy.deepcopy(previous.INPUT), "inspection_binding": copy.deepcopy(previous.INSPECTION),
            "source_count": 23, "use_count": 25, "unique_png_content_count": 22, "lineage_count": 3,
            "image_decode_calls": 0, "rights_evaluation_calls": 0},
        "question_rights_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "registration_binding": copy.deepcopy(REGISTRATION),
            "request_binding": copy.deepcopy(REQUEST), "claim_binding": copy.deepcopy(CLAIM), "source_count": 4,
            "new_lineage_count": 0, "current_source_batch_count": 1, "new_editorial_decision_count": 0,
            "rights_binding_recomposition_count": 4, "scope": "HISTORICAL_RIGHTS_BINDINGS_NOT_NEW_APPROVAL"},
        "visual_amendment_evidence": {"adapter_version": case.VERSION, "inspection_sha256": canonical_sha(literal),
            "effective_rows_sha256": canonical_sha(literal["rows"]), "changed_state_count": 2, "unmodified_state_count": 98,
            "prior_amendment_inspection_sha256": canonical_sha(old["literal"]), "source_ready": False, "global_schedule_created": False},
        "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda row: row["path"]),
        "claim_boundary": "Twenty-nine untimed uses, twenty-seven state assets, twenty-six PNG identities and three lineages. Twenty-five prior uses replayed; four question source/right bindings reconstituted. No new editorial right, calibrated sample, span, publicity, quality, admission, render or publication."}
    result["inspection_id"] = "static-asset-uses-v3-" + sources._sha(sources._canonical(result))[:24]
    return result


def verify_static_asset_uses(candidate, root, *, binding):
    expected = inspect_static_asset_uses(root, binding=binding)
    _same(candidate, expected, "source-use v3 inspection replay differs")
    return expected


def recheck_asset_use_dependencies(root, proofs):
    """Reopen same-call V3 sinks only; never verify external candidate claims."""
    if type(proofs) is not list or not proofs:
        raise ValueError("same-call v3 use proof sink required")
    reader = sources._Reader(root)
    for proof in proofs:
        if type(proof) is not dict or proof.get("version") != VERSION:
            raise ValueError("v3 use proof sink version differs")
        _same(proof.get("authority"), AUTHORITY, "v3 sink cannot gain authority")
        _dependencies(reader, proof.get("dependency_bindings"))
    question.recheck_question_dependencies(root, [{"dependency_bindings": list(reader.bindings.values())}])
    legacy_reader = sources._Reader(root)
    legacy_reader.bindings = {path: copy.deepcopy(item) for path, item in reader.bindings.items()
        if not (Path(path).is_relative_to(reader.root) and Path(path).relative_to(reader.root).as_posix() in question.MODEL_PINS)}
    previous.recheck(legacy_reader)
    _registry_inventory(reader, _json(reader, REGISTRATION))
