from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .queue_phase6 import QUEUE_PATH, TransactionalQueue


CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
TASK_TYPE = "EXECUTE_PHASE6_VIDEO2_MEDIA"
PRODUCTION_ACTION = "SYNTHESIZE_AND_RENDER_VIDEO_2"
WAIT_REASON = "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
ROOT_JOB_ID = "job-ddc7d6b9605b194c44fd4f78"
MIDDLE_JOB_ID = "job-faae3c79b330903828e90cc7"
TAIL_JOB_ID = "job-c516db5685acbbb423199bc1"
TAIL_INPUT_RECEIPT_ID = "phase6-production-inputs-79b3e183dd5df410fb3a"
VISUAL_AUDIT_ID = "visual-preflight-394d5a2f84d56d4a3570519f"
HISTORICAL_RENDERER = "phase6-standard-v1"
CURRENT_RENDERER = "phase6-standard-v2"
MEDIA_RUNTIME_PATH = Path("output/operations/phase6/media-executor-status.json")
PRODUCTION_INPUT_RECEIPTS = Path(
    "output/operations/phase6/release/production-input-receipts"
)
SUPERSESSION_RECEIPTS = Path(
    "output/operations/phase6/runtime/media-job-supersession-receipts"
)
VISUAL_AUDITS = Path("output/operations/phase6/visual-preflight/audits")
HISTORICAL_ARCHIVE_RECEIPT = Path(
    "output/operations/phase6/release/production-artifact-archive-receipts/"
    "phase6-production-artifact-archive-d06a968788c8368e2b1c.json"
)
HISTORICAL_ARCHIVE_RECEIPT_SHA256 = (
    "sha256:867bcf161ec482b0e59d06041ba2e519f9745b041eb2d7f29552e7e119ddb076"
)
# The immutable blocking audit predates the explicit QP1 plan profile. Its
# original schema was preserved before that additive change; never repin the
# audit to today's schema or accept an unrecognized schema evolution.
HISTORICAL_TAKE_PLAN_SCHEMA = Path(
    "output/runtime/gestor-central/maintenance-runs/"
    "typography-codec-adoption-20261001/source-preimages/schemas/take_plan.schema.json"
)
HISTORICAL_TAKE_PLAN_SCHEMA_SHA256 = (
    "sha256:8fe58aa812135111918eee49706751496c5e68aed1178cc70b370d38ea7b36f3"
)
QP1_TAKE_PLAN_SCHEMA_SHA256 = (
    "sha256:d8c4ef32386ab73fcea24e2c391b0002b3cfd325125fee895c5051709f62edef"
)

EXPECTED_CHAIN = (
    (
        "phase6-media-supersession-d4b92b0041c3befd91b4198e",
        "IDENTITY_ONLY",
        ROOT_JOB_ID,
        MIDDLE_JOB_ID,
    ),
    (
        "phase6-media-supersession-511dbf21c5bb4c4cf3b1f455",
        "PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION",
        MIDDLE_JOB_ID,
        TAIL_JOB_ID,
    ),
)


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def canonical_hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value)).hexdigest()


def file_hash(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise PermissionError(f"expected a JSON object: {path}")
    return value


def _validate(root: Path, schema_name: str, value: Any) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(
        schema, format_checker=FormatChecker()
    ).validate(value)


def _confined_file(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise PermissionError("evidence path must be a non-empty workspace-relative path")
    path = (root / relative).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise PermissionError("evidence path escaped the workspace") from exc
    if path.is_symlink() or not path.is_file():
        raise PermissionError(f"bound evidence is unavailable: {relative}")
    return path


def _verify_file(
    root: Path,
    *,
    relative: str,
    expected_sha256: str,
    expected_size: int | None = None,
    schema_name: str | None = None,
) -> tuple[Path, dict[str, Any] | None]:
    path = _confined_file(root, relative)
    if file_hash(path) != expected_sha256:
        raise PermissionError(f"bound evidence hash changed: {relative}")
    if expected_size is not None and path.stat().st_size != expected_size:
        raise PermissionError(f"bound evidence size changed: {relative}")
    value = _read(path) if schema_name is not None else None
    if schema_name is not None:
        _validate(root, schema_name, value)
    return path, value


def _readonly_queue_connection(path: Path) -> sqlite3.Connection:
    from .maintenance_protocol import _PROTECTED_DATABASE_VIEW, _readonly_connection
    if _PROTECTED_DATABASE_VIEW.get() is not None:
        return _readonly_connection(path)
    if not path.is_file():
        raise PermissionError("Phase 6 queue is unavailable")
    connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _resolve_exact_authority(root: Path) -> dict[str, Any]:
    queue = object.__new__(TransactionalQueue)
    queue.root = root
    queue.path = (root / QUEUE_PATH).resolve()
    with closing(_readonly_queue_connection(queue.path)) as connection:
        connection.execute("BEGIN")
        media_rows = connection.execute(
            "SELECT job_id FROM jobs WHERE task_type=? ORDER BY created_at,job_id",
            (TASK_TYPE,),
        ).fetchall()
        media_ids = [str(row["job_id"]) for row in media_rows]
        if media_ids != [ROOT_JOB_ID, MIDDLE_JOB_ID, TAIL_JOB_ID]:
            raise PermissionError(
                "post-effect wait requires the exact closed three-job media lineage"
            )
        resolution = queue._resolve_media_job_authority_in_connection(
            connection,
            ROOT_JOB_ID,
            expected_operation_id=OPERATION_ID,
            expected_channel_id=CHANNEL_ID,
            expected_task_type=TASK_TYPE,
            require_canonical_root=True,
        )
        connection.rollback()

    chain_shape = [
        (
            edge["supersession_id"],
            edge["supersession_class"],
            edge["superseded_job_id"],
            edge["authoritative_job_id"],
        )
        for edge in resolution["chain"]
    ]
    if chain_shape != list(EXPECTED_CHAIN):
        raise PermissionError("media authority lineage is not the reviewed immutable chain")
    tail = resolution["authority_job"]
    if not (
        resolution["authority_state"] == "SUCCEEDED"
        and resolution["authority_kind"] == "TERMINAL_SUCCEEDED"
        and resolution["authoritative_job_id"] == TAIL_JOB_ID
        and resolution["terminal"] is True
        and resolution["executable"] is False
        and resolution["predecessor_fallback_permitted"] is False
        and tail["operation_id"] == OPERATION_ID
        and tail["channel_id"] == CHANNEL_ID
        and tail["task_type"] == TASK_TYPE
        and tail["payload"]
        == {
            "action": PRODUCTION_ACTION,
            "input_receipt_id": TAIL_INPUT_RECEIPT_ID,
        }
        and tail["lease_owner"] is None
        and tail["lease_until"] is None
        and tail["last_error"] is None
        and tail["attempt_count"] == 1
        and tail["checkpoint"]
    ):
        raise PermissionError("media authority tail is not the exact inert SUCCEEDED job")
    return resolution


def _verify_input_lineage(
    root: Path, resolution: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    expected_pairs = (
        (
            "phase6-production-inputs-3048b3d519d8fe07c94c",
            "phase6-production-inputs-bb3a94ffa47603342681",
        ),
        (
            "phase6-production-inputs-bb3a94ffa47603342681",
            TAIL_INPUT_RECEIPT_ID,
        ),
    )
    input_refs: dict[str, dict[str, Any]] = {}
    for edge, pair in zip(resolution["chain"], expected_pairs, strict=True):
        receipt_path, receipt = _verify_file(
            root,
            relative=edge["receipt_path"],
            expected_sha256=edge["receipt_sha256"],
            schema_name="phase6_media_job_supersession_receipt.schema.json",
        )
        assert receipt is not None
        if receipt_path.parent != (root / SUPERSESSION_RECEIPTS).resolve():
            raise PermissionError("supersession receipt left its immutable directory")
        stale = receipt["superseded_input_receipt"]
        authority = receipt["authoritative_input_receipt"]
        if (stale["receipt_id"], authority["receipt_id"]) != pair:
            raise PermissionError("supersession input lineage diverged")
        input_refs[stale["receipt_id"]] = stale
        input_refs[authority["receipt_id"]] = authority

    if set(input_refs) != {item for pair in expected_pairs for item in pair}:
        raise PermissionError("media input lineage is incomplete")
    values: dict[str, dict[str, Any]] = {}
    for receipt_id, reference in input_refs.items():
        expected = (PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json").as_posix()
        if reference["path"] != expected:
            raise PermissionError("production-input receipt left its immutable directory")
        path, value = _verify_file(
            root,
            relative=reference["path"],
            expected_sha256=reference["sha256"],
            schema_name="phase6_production_inputs_receipt.schema.json",
        )
        assert value is not None
        if path.name != f"{receipt_id}.json" or value["receipt_id"] != receipt_id:
            raise PermissionError("production-input receipt identity diverged")
        values[receipt_id] = value
    return input_refs[TAIL_INPUT_RECEIPT_ID], values[TAIL_INPUT_RECEIPT_ID]


def _verify_tail_inputs(root: Path, reference: dict[str, Any], receipt: dict[str, Any]) -> str:
    if not (
        receipt["status"] == "COMPILED"
        and receipt["channel_id"] == CHANNEL_ID
        and receipt["publication_authorized"] is False
        and receipt["technical_cost_brl"] == 0
        and receipt["measurements"]["take_count"] == 90
    ):
        raise PermissionError("terminal production inputs no longer satisfy the frozen contract")
    immutable = root / reference["path"]
    archive_path, _ = _verify_file(
        root,
        relative=HISTORICAL_ARCHIVE_RECEIPT.as_posix(),
        expected_sha256=HISTORICAL_ARCHIVE_RECEIPT_SHA256,
    )
    archive = _read(archive_path)
    if not (
        archive_path.parent == (root / HISTORICAL_ARCHIVE_RECEIPT.parent).resolve()
        and archive.get("status") == "ARCHIVED_BEFORE_OVERWRITE"
        and archive.get("production_input_receipt") == {
            "receipt_id": TAIL_INPUT_RECEIPT_ID,
            "path": reference["path"],
            "sha256": reference["sha256"],
        }
        and archive.get("control", {}).get("all_source_hashes_verified") is True
        and archive.get("control", {}).get("all_archive_bytes_verified") is True
    ):
        raise PermissionError("terminal production-input archive receipt diverged")
    archive_rows = archive.get("artifacts")
    if not isinstance(archive_rows, list) or len(archive_rows) != len(receipt["artifacts"]):
        raise PermissionError("terminal production-input archive is incomplete")
    archive_by_original = {row.get("original_path"): row for row in archive_rows if isinstance(row, dict)}

    bindings: list[dict[str, Any]] = []
    for artifact in receipt["artifacts"]:
        archived = archive_by_original.get(artifact["path"])
        if not isinstance(archived, dict) or not (
            archived.get("sha256") == artifact["sha256"]
            and archived.get("size_bytes") == artifact["size_bytes"]
            and Path(str(archived.get("archive_path") or "")).name
            == Path(artifact["path"]).name
        ):
            raise PermissionError("terminal production artifact archive binding diverged")
        _verify_file(
            root,
            relative=archived["archive_path"],
            expected_sha256=artifact["sha256"],
            expected_size=artifact["size_bytes"],
        )
        # The archive is an implementation detail of revalidation.  Keep the
        # logical historical binding byte-for-byte compatible with the proof
        # produced before aliases evolved: it names the original artifact and
        # its immutable bytes, not the storage location used to reopen them.
        bindings.append({key: artifact[key] for key in ("path", "sha256", "size_bytes")})
    for evidence in receipt["evidence_bindings"]:
        # Source aliases are mutable by design.  Historical proof is bound to
        # the immutable evidence copy, never to a later alias value.
        _verify_file(root, relative=evidence["immutable_path"], expected_sha256=evidence["sha256"], expected_size=evidence["size_bytes"])
        bindings.append(
            {
                "role": evidence["role"],
                "immutable_path": evidence["immutable_path"],
                "sha256": evidence["sha256"],
                "size_bytes": evidence["size_bytes"],
            }
        )
    work_order = receipt["work_order"]
    _verify_file(
        root,
        relative=work_order["path"],
        expected_sha256=work_order["sha256"],
        expected_size=work_order["size_bytes"],
    )
    residency = receipt["asset_residency"]
    _, residency_value = _verify_file(
        root,
        relative=residency["receipt_path"],
        expected_sha256=residency["sha256"],
        schema_name="phase6_asset_residency_audit.schema.json",
    )
    assert residency_value is not None
    if residency_value.get("audit_id") != residency["audit_id"]:
        raise PermissionError("asset-residency receipt identity diverged")
    return canonical_hash(
        {
            "receipt": reference,
            "artifacts": bindings,
            "work_order": work_order,
            "asset_residency": residency,
        }
    )


def _verify_historical_checkpoint(
    root: Path, checkpoint: dict[str, Any]
) -> dict[str, Any]:
    required = {
        "asset_residency_audit_id",
        "asset_residency_sha256",
        "capacity_receipt_id",
        "capacity_receipt_path",
        "capacity_receipt_sha256",
        "input_receipt_id",
        "input_receipt_path",
        "input_receipt_sha256",
        "next_action",
        "render_id",
        "render_manifest",
        "render_manifest_sha256",
        "voice_manifest",
        "voice_manifest_sha256",
        "voice_render_id",
    }
    if set(checkpoint) != required:
        raise PermissionError("terminal media checkpoint shape changed")
    if not (
        checkpoint["input_receipt_id"] == TAIL_INPUT_RECEIPT_ID
        and checkpoint["input_receipt_path"]
        == (PRODUCTION_INPUT_RECEIPTS / f"{TAIL_INPUT_RECEIPT_ID}.json").as_posix()
        and checkpoint["next_action"] == "RUN_PHASE6_VIDEO2_QUALITY_GATES"
    ):
        raise PermissionError("terminal media checkpoint identity changed")
    _verify_file(
        root,
        relative=checkpoint["input_receipt_path"],
        expected_sha256=checkpoint["input_receipt_sha256"],
        schema_name="phase6_production_inputs_receipt.schema.json",
    )
    _, capacity = _verify_file(
        root,
        relative=checkpoint["capacity_receipt_path"],
        expected_sha256=checkpoint["capacity_receipt_sha256"],
        schema_name="phase6_local_capacity_preflight.schema.json",
    )
    _, voice = _verify_file(
        root,
        relative=checkpoint["voice_manifest"],
        expected_sha256=checkpoint["voice_manifest_sha256"],
        schema_name="voice_render_manifest.schema.json",
    )
    _, render = _verify_file(
        root,
        relative=checkpoint["render_manifest"],
        expected_sha256=checkpoint["render_manifest_sha256"],
        schema_name="render_manifest.schema.json",
    )
    assert capacity is not None and voice is not None and render is not None
    if not (
        capacity["receipt_id"] == checkpoint["capacity_receipt_id"]
        and capacity["status"] == "PASS"
        and voice["voice_render_id"] == checkpoint["voice_render_id"]
        and voice["status"] == "COMPLETE"
        and voice["take_count"] == 90
        and voice["publication_approved"] is False
        and render["render_id"] == checkpoint["render_id"]
        and render["status"] == "COMPLETE"
        and render["segment_count"] == 90
        and render["publication_approved"] is False
    ):
        raise PermissionError("historical media manifests diverged from their checkpoint")

    segment_reference = render["segment_receipt_set"]
    _, segment_set = _verify_file(
        root,
        relative=segment_reference["path"],
        expected_sha256=segment_reference["sha256"],
        schema_name="phase6_segment_set.schema.json",
    )
    assert segment_set is not None
    if not (
        segment_set["set_id"] == segment_reference["set_id"]
        and segment_set["production_inputs_receipt_id"] == TAIL_INPUT_RECEIPT_ID
        and len(segment_set["receipts"]) == segment_reference["receipt_count"] == 90
    ):
        raise PermissionError("historical segment set identity diverged")
    renderer_versions: set[str] = set()
    receipt_bindings: list[dict[str, Any]] = []
    for item in segment_set["receipts"]:
        _, segment = _verify_file(
            root,
            relative=item["path"],
            expected_sha256=item["sha256"],
            schema_name="phase6_segment_receipt.schema.json",
        )
        assert segment is not None
        if segment["receipt_id"] != item["receipt_id"] or segment["take_id"] != item["take_id"]:
            raise PermissionError("historical segment receipt identity diverged")
        renderer_versions.add(segment["recipe"]["renderer"])
        receipt_bindings.append(item)
    if renderer_versions != {HISTORICAL_RENDERER}:
        raise PermissionError("historical segment set is not exclusively renderer v1")
    return {
        "capacity": {
            "receipt_id": checkpoint["capacity_receipt_id"],
            "path": checkpoint["capacity_receipt_path"],
            "sha256": checkpoint["capacity_receipt_sha256"],
        },
        "voice": {
            "voice_render_id": checkpoint["voice_render_id"],
            "path": checkpoint["voice_manifest"],
            "sha256": checkpoint["voice_manifest_sha256"],
        },
        "render": {
            "render_id": checkpoint["render_id"],
            "path": checkpoint["render_manifest"],
            "sha256": checkpoint["render_manifest_sha256"],
        },
        "segment_set": {
            **segment_reference,
            "receipts_sha256": canonical_hash(receipt_bindings),
            "renderer_versions": sorted(renderer_versions),
        },
    }


def _verify_blocked_visual_audit(root: Path, receipt: dict[str, Any]) -> dict[str, Any]:
    path = VISUAL_AUDITS / f"{VISUAL_AUDIT_ID}.json"
    absolute = root / path
    audit = _read(absolute)
    _validate(root, "phase6_visual_preflight.schema.json", audit)
    artifact_hashes = {item["path"]: item["sha256"] for item in receipt["artifacts"]}
    archive_receipt_path, _ = _verify_file(
        root,
        relative=HISTORICAL_ARCHIVE_RECEIPT.as_posix(),
        expected_sha256=HISTORICAL_ARCHIVE_RECEIPT_SHA256,
    )
    archive = _read(archive_receipt_path)
    archived_sources = {
        row.get("original_path"): row for row in archive.get("artifacts", [])
        if isinstance(row, dict)
    }
    if not (
        audit["audit_id"] == VISUAL_AUDIT_ID
        and audit["status"] == "BLOCKED"
        and audit["input_stage"] == "CURRENT"
        and audit["recipe_id"] == CURRENT_RENDERER
        and audit["take_count"] == 90
        and audit["pixel_validation"] == "NOT_EXECUTED"
        and audit["publication_authorized"] is False
        and audit["technical_cost_brl"] == 0
        and len(audit["findings"]) > 0
    ):
        raise PermissionError("reviewed visual preflight is not the exact blocking audit")
    expected_source_paths = {
        "output/production/phase6/video-002/production/take_plan.json",
        "output/production/phase6/video-002/production/creative_treatment_plan.json",
        "output/production/phase6/video-002/production/channel_style_bible.json",
    }
    if {item["path"] for item in audit["sources"]} != expected_source_paths:
        raise PermissionError("blocking visual audit source set diverged")
    for source in audit["sources"]:
        if artifact_hashes.get(source["path"]) != source["sha256"]:
            raise PermissionError("blocking visual audit is not bound to terminal inputs")
        archived = archived_sources.get(source["path"])
        if not isinstance(archived, dict) or not (
            archived.get("sha256") == source["sha256"]
            and archived.get("size_bytes") == source.get("size_bytes", archived.get("size_bytes"))
        ):
            raise PermissionError("blocking visual audit archive source diverged")
        artifact_path, _ = _verify_file(
            root,
            relative=archived["archive_path"],
            expected_sha256=source["sha256"],
        )
        schema_path = _confined_file(root, "schemas/" + source["schema"])
        schema_bytes = schema_path.read_bytes()
        schema_hash = "sha256:" + hashlib.sha256(schema_bytes).hexdigest()
        if source["schema"] == "take_plan.schema.json":
            if source["schema_sha256"] != HISTORICAL_TAKE_PLAN_SCHEMA_SHA256:
                raise PermissionError("blocking visual audit historical schema pin changed")
            if schema_hash == QP1_TAKE_PLAN_SCHEMA_SHA256:
                schema_path = _confined_file(root, HISTORICAL_TAKE_PLAN_SCHEMA.as_posix())
                schema_bytes = schema_path.read_bytes()
                schema_hash = "sha256:" + hashlib.sha256(schema_bytes).hexdigest()
        if schema_hash != source["schema_sha256"]:
            raise PermissionError("blocking visual audit schema changed")
        artifact_bytes = artifact_path.read_bytes()
        if "sha256:" + hashlib.sha256(artifact_bytes).hexdigest() != source["sha256"]:
            raise PermissionError("blocking visual audit archive source changed")
        Draft202012Validator(
            json.loads(schema_bytes.decode("utf-8-sig")), format_checker=FormatChecker()
        ).validate(json.loads(artifact_bytes.decode("utf-8-sig")))
    return {
        "audit_id": VISUAL_AUDIT_ID,
        "path": path.as_posix(),
        "sha256": file_hash(absolute),
        "status": "BLOCKED",
    }


def _runtime_identity(runtime: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in runtime.items()
        if key not in {"updated_at", "remediation_wait"}
    }


def derive_post_effect_visual_wait(
    root: Path,
    *,
    request_id: str,
    observed: datetime,
) -> tuple[dict[str, Any], dict[str, Any], str]:
    """Derive a no-effect WAITING view from the exact reviewed terminal lineage."""

    root = root.resolve()
    resolution = _resolve_exact_authority(root)
    input_reference, input_receipt = _verify_input_lineage(root, resolution)
    inputs_sha256 = _verify_tail_inputs(root, input_reference, input_receipt)
    historical = _verify_historical_checkpoint(root, resolution["authority_job"]["checkpoint"])
    visual = _verify_blocked_visual_audit(root, input_receipt)
    chain_sha256 = canonical_hash(resolution["chain"])
    checkpoint_sha256 = canonical_hash(resolution["authority_job"]["checkpoint"])
    base_runtime = {
        "schema_version": "1.3.0",
        "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6,
        "status": "WAITING",
        "input_receipt_id": TAIL_INPUT_RECEIPT_ID,
        "action": "WAIT",
        "job_id": TAIL_JOB_ID,
        "job_state": "SUCCEEDED",
        "voice_manifest": None,
        "render_manifest": None,
        "visual_preflight": visual,
        "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None,
        "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None,
        "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None,
        "next_action": WAIT_REASON,
        "error": None,
        "publication_authorized": False,
        "technical_cost_brl": 0,
    }
    runtime_identity_sha256 = canonical_hash(base_runtime)
    proof_seed = {
        "schema_version": "1.0.0",
        "record_type": "PREPARED_LOCAL_DERIVED_VIEW",
        "status": "ELIGIBLE_FOR_WAITING_STATE",
        "request_id": request_id,
        "reason": WAIT_REASON,
        "operation_id": OPERATION_ID,
        "channel_id": CHANNEL_ID,
        "task_type": TASK_TYPE,
        "authority": {
            "root_job_id": ROOT_JOB_ID,
            "tail_job_id": TAIL_JOB_ID,
            "tail_state": "SUCCEEDED",
            "tail_kind": "TERMINAL_SUCCEEDED",
            "media_unit_key": resolution["media_unit_key"],
            "chain": resolution["chain"],
            "chain_sha256": chain_sha256,
            "predecessor_fallback_permitted": False,
        },
        "tail": {
            "input_receipt": input_reference,
            "payload_sha256": canonical_hash(resolution["authority_job"]["payload"]),
            "checkpoint_sha256": checkpoint_sha256,
            "attempt_count": 1,
            "lease_owner": None,
            "lease_until": None,
        },
        "historical_artifacts": {
            "inputs_sha256": inputs_sha256,
            **historical,
            "historical_renderer": HISTORICAL_RENDERER,
            "required_renderer": CURRENT_RENDERER,
        },
        "blocked_visual_preflight": visual,
        "runtime_identity_sha256": runtime_identity_sha256,
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "production_authorized": False,
        "publication_authorized": False,
        "technical_cost_brl": 0,
        "observed_at": observed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "claim_boundary": [
            "This proof authorizes only a local derived WAITING status for the exact inert terminal media lineage.",
            "The historical renderer-v1 media remains evidence, not a current quality-approved or publishable candidate.",
            "A new visual contract, capacity preflight, render, independent quality evaluation and release gate remain mandatory.",
        ],
    }
    proof_digest = hashlib.sha256(_canonical(proof_seed)).hexdigest()
    proof = {
        **proof_seed,
        "proof_id": "phase6-post-effect-visual-wait-" + proof_digest[:24],
    }
    _validate(root, "phase6_post_effect_visual_wait_proof.schema.json", proof)
    proof_path = (
        Path("output/runtime/gestor-central/maintenance-runs")
        / request_id
        / f"{proof['proof_id']}.json"
    ).as_posix()
    proof_payload = json.dumps(proof, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    proof_sha256 = "sha256:" + hashlib.sha256(proof_payload).hexdigest()
    binding = {
        "proof_id": proof["proof_id"],
        "path": proof_path,
        "sha256": proof_sha256,
        "status": proof["status"],
        "reason": WAIT_REASON,
        "request_id": request_id,
        "authority_root_job_id": ROOT_JOB_ID,
        "authority_tail_job_id": TAIL_JOB_ID,
        "input_receipt_id": TAIL_INPUT_RECEIPT_ID,
        "chain_sha256": chain_sha256,
        "checkpoint_sha256": checkpoint_sha256,
        "runtime_identity_sha256": runtime_identity_sha256,
    }
    runtime = {
        **base_runtime,
        "remediation_wait": binding,
        "updated_at": proof["observed_at"],
    }
    _validate(root, "phase6_media_executor_runtime.schema.json", runtime)
    return runtime, proof, proof_path


def _verify_committed_migration_outcome(
    root: Path,
    binding: dict[str, Any],
    proof: dict[str, Any],
) -> None:
    """Prove the wait target crossed the stopped transaction commit boundary.

    The regression PASS is intentionally not a prerequisite here: the manager
    is still stopped while regression runs.  The migration outcome is written
    only after every target committed and is removed from authority by a full
    byte rollback if its own persistence fails.
    """

    run = (
        root
        / "output/runtime/gestor-central/maintenance-runs"
        / binding["request_id"]
    ).resolve()
    journal_path = run / "local-runtime-migration-journal.json"
    outcome_path = run / "local-runtime-migration-outcome.json"
    if any(path.is_symlink() or not path.is_file() for path in (journal_path, outcome_path)):
        raise PermissionError("media remediation wait migration did not commit")
    journal = _read(journal_path)
    outcome = _read(outcome_path)
    zero_effect = {
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "technical_cost_brl": 0,
    }
    expected_migration = {
        "status": "WAITING",
        "reason": WAIT_REASON,
        "media_runtime_path": MEDIA_RUNTIME_PATH.as_posix(),
        "media_runtime_hash": None,
        "runtime_identity_sha256": binding["runtime_identity_sha256"],
        "proof_request_id": binding["request_id"],
        "proof_id": binding["proof_id"],
        "proof_path": binding["path"],
        "proof_sha256": binding["sha256"],
        "authority_root_job_id": ROOT_JOB_ID,
        "authority_tail_job_id": TAIL_JOB_ID,
        "input_receipt_id": TAIL_INPUT_RECEIPT_ID,
        "chain_sha256": binding["chain_sha256"],
        "checkpoint_sha256": binding["checkpoint_sha256"],
        "historical_renderer": HISTORICAL_RENDERER,
        "required_renderer": CURRENT_RENDERER,
        "visual_preflight": proof["blocked_visual_preflight"],
        "production_authorized": False,
        "publication_authorized": False,
        **zero_effect,
    }
    journal_migration = journal.get("media_runtime_migration")
    outcome_migration = outcome.get("media_runtime_migration")
    if not isinstance(journal_migration, dict) or not isinstance(outcome_migration, dict):
        raise PermissionError("committed migration omits its media wait binding")
    expected_migration["media_runtime_hash"] = journal_migration.get(
        "media_runtime_hash"
    )
    if not (
        journal.get("schema_version") == "1.0.0"
        and journal.get("record_type") == "PREPARED"
        and outcome.get("schema_version") == "1.0.0"
        and outcome.get("record_type") == "COMMITTED"
        and journal.get("request_id") == binding["request_id"]
        and outcome.get("request_id") == binding["request_id"]
        and outcome.get("journal_path") == journal_path.relative_to(root).as_posix()
        and outcome.get("journal_hash") == file_hash(journal_path)
        and all(journal.get(key) == value for key, value in zero_effect.items())
        and all(outcome.get(key) == value for key, value in zero_effect.items())
        and journal_migration == expected_migration
        and outcome_migration == expected_migration
    ):
        raise PermissionError("media remediation migration commit binding diverged")

    targets = journal.get("targets")
    committed_targets = outcome.get("target_hashes")
    if not isinstance(targets, list) or not isinstance(committed_targets, list):
        raise PermissionError("media remediation migration target evidence is absent")
    media_targets = [item for item in targets if item.get("path") == MEDIA_RUNTIME_PATH.as_posix()]
    media_outcomes = [
        item for item in committed_targets if item.get("path") == MEDIA_RUNTIME_PATH.as_posix()
    ]
    if len(media_targets) != 1 or len(media_outcomes) != 1:
        raise PermissionError("media remediation migration target is ambiguous")
    target = media_targets[0]
    committed = media_outcomes[0]
    candidate_relative = target.get("candidate_path")
    candidate_hash = target.get("candidate_hash")
    if not isinstance(candidate_relative, str) or not isinstance(candidate_hash, str):
        raise PermissionError("media remediation migration candidate is incomplete")
    candidate_path = _confined_file(root, candidate_relative)
    if candidate_path.parent != run or file_hash(candidate_path) != candidate_hash:
        raise PermissionError("media remediation migration candidate left its exact run")
    candidate = _read(candidate_path)
    _validate(root, "phase6_media_executor_runtime.schema.json", candidate)
    if not (
        target.get("desired_exists") is True
        and target.get("candidate_size") == candidate_path.stat().st_size
        and candidate_hash == journal_migration["media_runtime_hash"]
        and committed.get("exists") is True
        and committed.get("content_hash") == candidate_hash
        and candidate.get("remediation_wait") == binding
        and canonical_hash(_runtime_identity(candidate))
        == binding["runtime_identity_sha256"]
    ):
        raise PermissionError("media remediation migration candidate was not committed intact")


def verify_post_effect_visual_wait(
    root: Path, runtime: dict[str, Any]
) -> dict[str, Any]:
    """Reopen every frozen dependency before preserving the no-effect wait."""

    root = root.resolve()
    _validate(root, "phase6_media_executor_runtime.schema.json", runtime)
    binding = runtime.get("remediation_wait")
    if not isinstance(binding, dict):
        raise PermissionError("media remediation wait lacks an immutable proof binding")
    if not (
        runtime["schema_version"] == "1.3.0"
        and runtime["status"] == "WAITING"
        and runtime["action"] == "WAIT"
        and runtime["job_id"] == TAIL_JOB_ID
        and runtime["job_state"] == "SUCCEEDED"
        and runtime["input_receipt_id"] == TAIL_INPUT_RECEIPT_ID
        and runtime["voice_manifest"] is None
        and runtime["render_manifest"] is None
        and runtime["capacity_status"] == "UNAVAILABLE"
        and runtime["next_action"] == WAIT_REASON
        and runtime["error"] is None
        and runtime["publication_authorized"] is False
        and runtime["technical_cost_brl"] == 0
    ):
        raise PermissionError("media remediation wait runtime broadened its no-effect boundary")
    proof_path, proof = _verify_file(
        root,
        relative=binding["path"],
        expected_sha256=binding["sha256"],
        schema_name="phase6_post_effect_visual_wait_proof.schema.json",
    )
    assert proof is not None
    expected_parent = (
        root
        / "output/runtime/gestor-central/maintenance-runs"
        / binding["request_id"]
    ).resolve()
    if proof_path.parent != expected_parent or proof_path.name != f"{binding['proof_id']}.json":
        raise PermissionError("media remediation proof left its exact maintenance run")
    if not (
        proof["proof_id"] == binding["proof_id"]
        and proof["request_id"] == binding["request_id"]
        and proof["status"] == binding["status"] == "ELIGIBLE_FOR_WAITING_STATE"
        and proof["reason"] == binding["reason"] == WAIT_REASON
        and proof["authority"]["root_job_id"] == binding["authority_root_job_id"]
        and proof["authority"]["tail_job_id"] == binding["authority_tail_job_id"]
        and proof["authority"]["chain_sha256"] == binding["chain_sha256"]
        and proof["tail"]["input_receipt"]["receipt_id"] == binding["input_receipt_id"]
        and proof["tail"]["checkpoint_sha256"] == binding["checkpoint_sha256"]
        and proof["runtime_identity_sha256"] == binding["runtime_identity_sha256"]
        and canonical_hash(_runtime_identity(runtime)) == binding["runtime_identity_sha256"]
    ):
        raise PermissionError("media remediation runtime/proof binding diverged")

    _verify_committed_migration_outcome(root, binding, proof)

    resolution = _resolve_exact_authority(root)
    input_reference, input_receipt = _verify_input_lineage(root, resolution)
    inputs_sha256 = _verify_tail_inputs(root, input_reference, input_receipt)
    historical = _verify_historical_checkpoint(root, resolution["authority_job"]["checkpoint"])
    visual = _verify_blocked_visual_audit(root, input_receipt)
    if not (
        canonical_hash(resolution["chain"]) == proof["authority"]["chain_sha256"]
        and canonical_hash(resolution["authority_job"]["payload"])
        == proof["tail"]["payload_sha256"]
        and canonical_hash(resolution["authority_job"]["checkpoint"])
        == proof["tail"]["checkpoint_sha256"]
        and inputs_sha256 == proof["historical_artifacts"]["inputs_sha256"]
        and historical == {
            key: proof["historical_artifacts"][key]
            for key in ("capacity", "voice", "render", "segment_set")
        }
        and visual == proof["blocked_visual_preflight"] == runtime["visual_preflight"]
        and proof["historical_artifacts"]["historical_renderer"]
        == HISTORICAL_RENDERER
        and proof["historical_artifacts"]["required_renderer"] == CURRENT_RENDERER
    ):
        raise PermissionError("post-effect wait evidence drifted after maintenance")
    return proof
