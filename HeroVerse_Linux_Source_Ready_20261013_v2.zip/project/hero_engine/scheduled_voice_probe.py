from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import stat
import sys
import time
import uuid
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker

from .production_capacity import RECEIPTS as CAPACITY_RECEIPTS, verify_phase6_capacity_receipt
from .voice_phase5 import (
    SAMPLE_RATE,
    build_local_voice,
    espeak_binding_identity,
    revalidate_local_espeak_binding,
    synthesize_voice_sample,
)


SCHEMA_NAME = "scheduled_voice_probe_receipt.schema.json"
PROBE_TEXT = "HeroVerse local voice probe."
PROBE_VOICE_ID = "am_michael"
PROBE_SPEED = 1.0
ATOMIC_WRITE_METHOD = "SAME_DIRECTORY_TEMP_OS_REPLACE"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _timestamp(value: datetime | None = None) -> str:
    moment = value or datetime.now(timezone.utc)
    if moment.tzinfo is None:
        raise ValueError("probe timestamp must be timezone-aware")
    return moment.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _sample_path_for(receipt_path: Path, probe_id: str) -> Path:
    return receipt_path.with_name(f"{receipt_path.stem}.{probe_id}.sample.wav")


def _absolute_leaf(root: Path, value: Path) -> Path:
    combined = value if value.is_absolute() else root / value
    return combined.parent.resolve() / combined.name


def _write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    encoded = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")
    try:
        with temporary.open("xb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        temporary.unlink(missing_ok=True)


def _is_reparse_or_symlink(path: Path) -> bool:
    if path.is_symlink():
        return True
    try:
        attributes = int(getattr(os.lstat(path), "st_file_attributes", 0))
    except FileNotFoundError:
        return False
    return bool(attributes & int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)))


def _validate_committed_sample(path: Path, expected_hash: str) -> None:
    if (
        not path.is_file()
        or _is_reparse_or_symlink(path)
        or _sha256_file(path) != expected_hash
    ):
        raise PermissionError("committed voice probe WAV is not the exact regular staged file")


def _unlink_best_effort(path: Path) -> None:
    for attempt in range(6):
        try:
            path.unlink(missing_ok=True)
            return
        except PermissionError:
            if attempt < 5:
                time.sleep(0.05 * (attempt + 1))
        except OSError:
            return


def _unlink_required(path: Path) -> None:
    for attempt in range(6):
        try:
            path.unlink(missing_ok=True)
            if not os.path.lexists(path):
                return
        except PermissionError:
            pass
        if attempt < 5:
            time.sleep(0.05 * (attempt + 1))
    raise PermissionError("staged voice probe WAV could not be removed after hard-link commit")


def _commit_sample_create_only(staged: Path, destination: Path, expected_hash: str) -> str:
    """Publish a staged WAV without ever replacing an existing sample."""

    if (
        not staged.is_file()
        or _is_reparse_or_symlink(staged)
        or _sha256_file(staged) != expected_hash
    ):
        raise PermissionError("staged voice probe WAV changed before commit")
    destination.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        for attempt in range(6):
            try:
                os.link(staged, destination)
                created = True
                break
            except FileExistsError:
                _validate_committed_sample(destination, expected_hash)
                return "REUSED_IDENTICAL"
            except PermissionError:
                if destination.exists():
                    _validate_committed_sample(destination, expected_hash)
                    return "REUSED_IDENTICAL"
                if attempt == 5:
                    raise
                time.sleep(0.05 * (attempt + 1))
        if not created:
            raise PermissionError("voice probe WAV create-only commit did not complete")
        _unlink_required(staged)
        _validate_committed_sample(destination, expected_hash)
        return "CREATED"
    finally:
        if not created:
            _unlink_best_effort(staged)


def _read_schema(root: Path) -> dict[str, Any]:
    return json.loads((root / "schemas" / SCHEMA_NAME).read_text(encoding="utf-8-sig"))


def _validate_receipt(root: Path, value: dict[str, Any]) -> None:
    schema = _read_schema(root)
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _parse_timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("probe receipt timestamp must be timezone-aware")
    return parsed.astimezone(timezone.utc)


def _normalize_binding(value: dict[str, Any]) -> dict[str, Any]:
    identity = espeak_binding_identity(value)
    normalized = dict(identity)
    normalized["library_path"] = str(Path(identity["library_path"]).resolve())
    normalized["data_path"] = str(Path(identity["data_path"]).resolve())
    dlls: list[dict[str, Any]] = []
    for item in identity["directory_dlls"]:
        if not isinstance(item, dict):
            raise ValueError("eSpeak DLL inventory entry is not an object")
        dll = dict(item)
        dll["path"] = str(Path(str(item.get("path") or "")).resolve())
        dlls.append(dll)
    normalized["directory_dlls"] = dlls
    return normalized


def _inspect_wav(path: Path) -> dict[str, int]:
    try:
        with wave.open(str(path), "rb") as stream:
            if stream.getcomptype() != "NONE":
                raise ValueError("probe WAV must be uncompressed PCM")
            return {
                "channels": stream.getnchannels(),
                "sample_width_bytes": stream.getsampwidth(),
                "sample_rate": stream.getframerate(),
                "frames": stream.getnframes(),
            }
    except (EOFError, wave.Error) as exc:
        raise ValueError("probe synthesizer did not produce a readable PCM WAV") from exc


def _finite_number(value: Any, label: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"voice probe {label} must be a finite number")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"voice probe {label} must be a finite number") from exc
    if not math.isfinite(number):
        raise ValueError(f"voice probe {label} must be a finite number")
    return number


def _sample_evidence(
    report: dict[str, Any],
    *,
    expected_path: Path,
    expected_text: str,
    expected_voice_id: str,
    expected_speed: float,
) -> dict[str, Any]:
    if not isinstance(report, dict):
        raise TypeError("voice probe report must be an object")
    reported_path = Path(str(report.get("path") or "")).resolve()
    if reported_path != expected_path or not expected_path.is_file():
        raise PermissionError("voice probe report did not bind the exact requested WAV")
    if report.get("text") != expected_text or report.get("voice_id") != expected_voice_id:
        raise PermissionError("voice probe report diverged from the requested phrase or voice")
    if _finite_number(report.get("speed"), "speed") != expected_speed:
        raise PermissionError("voice probe report diverged from the requested speed")

    wav = _inspect_wav(expected_path)
    if wav["channels"] != 1 or wav["sample_width_bytes"] != 2:
        raise ValueError("voice probe WAV must be mono PCM-16")
    if wav["sample_rate"] != SAMPLE_RATE or int(report.get("sample_rate") or 0) != SAMPLE_RATE:
        raise ValueError("voice probe WAV does not use the locked sample rate")
    if wav["frames"] <= 0 or int(report.get("samples") or 0) != wav["frames"]:
        raise ValueError("voice probe WAV frame count diverges from the synthesis report")

    measured_duration_ms = round(wav["frames"] / wav["sample_rate"] * 1000)
    reported_duration_ms = int(report.get("duration_ms") or 0)
    if reported_duration_ms <= 0 or abs(reported_duration_ms - measured_duration_ms) > 1:
        raise ValueError("voice probe WAV duration diverges from the synthesis report")
    content_hash = _sha256_file(expected_path)
    if report.get("content_hash") != content_hash:
        raise PermissionError("voice probe WAV content hash diverges from the synthesis report")

    clipping = report.get("clipping")
    peak = _finite_number(report.get("peak_linear"), "peak")
    if not isinstance(clipping, bool) or peak < 0:
        raise ValueError("voice probe clipping evidence is invalid")
    if peak >= 1.0 and not clipping:
        raise ValueError("voice probe clipping flag contradicts its measured peak")

    render_seconds = _finite_number(report.get("render_seconds"), "render time")
    real_time_factor = _finite_number(report.get("real_time_factor"), "real-time factor")
    if render_seconds < 0 or real_time_factor < 0:
        raise ValueError("voice probe timing evidence is invalid")
    return {
        "text": expected_text,
        "text_hash": _sha256_text(expected_text),
        "voice_id": expected_voice_id,
        "speed": expected_speed,
        "path": str(expected_path),
        "content_hash": content_hash,
        "sample_rate": wav["sample_rate"],
        "frames": wav["frames"],
        "channels": wav["channels"],
        "sample_width_bytes": wav["sample_width_bytes"],
        "duration_ms": measured_duration_ms,
        "render_seconds": render_seconds,
        "real_time_factor": real_time_factor,
        "peak_linear": peak,
        "clipping": clipping,
    }


def _error(stage: str, exc: BaseException) -> dict[str, str]:
    message = str(exc).replace("\r", " ").replace("\n", " ").strip()
    if not message:
        message = type(exc).__name__
    return {
        "stage": stage,
        "error_code": f"{stage}_{type(exc).__name__}".upper(),
        "error_type": type(exc).__name__,
        "message": message[:2000],
    }


def run_scheduled_voice_probe(
    root: Path,
    output: Path,
    *,
    expected_capacity_receipt: Path | None = None,
    created_at: datetime | None = None,
    voice_builder: Callable[..., Any] = build_local_voice,
    binding_revalidator: Callable[..., dict[str, Any]] = revalidate_local_espeak_binding,
    sample_synthesizer: Callable[..., dict[str, Any]] = synthesize_voice_sample,
    capacity_verifier: Callable[..., dict[str, Any]] = verify_phase6_capacity_receipt,
) -> dict[str, Any]:
    """Probe Kokoro/eSpeak in the current process and write one atomic receipt.

    The caller deliberately supplies the receipt path.  The smoke WAV is an
    adjacent probe-ID-named immutable artifact, so replacing a reusable receipt
    cannot invalidate its previous sample.  No runtime, queue, publication or
    Scheduled Task operation is performed by this function.
    """

    project_root = Path(root).resolve()
    raw_output = Path(output)
    receipt_path = _absolute_leaf(project_root, raw_output)
    if receipt_path.suffix.casefold() != ".json":
        raise ValueError("--output must be an explicit .json receipt path")
    if receipt_path.exists() and receipt_path.is_dir():
        raise IsADirectoryError(receipt_path)
    stamp = _timestamp(created_at)
    pid = os.getpid()
    ppid = os.getppid()
    probe_id = "scheduled-voice-probe-" + hashlib.sha256(
        f"{project_root}|{receipt_path}|{stamp}|{pid}|{ppid}".encode("utf-8")
    ).hexdigest()[:24]
    sample_path = _sample_path_for(receipt_path, probe_id)
    staged_sample_path = sample_path.with_name(
        f".{sample_path.name}.{pid}.{uuid.uuid4().hex}.tmp.wav"
    )
    if sample_path == receipt_path:
        raise ValueError("receipt and smoke-sample paths must differ")
    raw_capacity_path = Path(expected_capacity_receipt) if expected_capacity_receipt else None
    capacity_path = (
        (raw_capacity_path if raw_capacity_path.is_absolute() else project_root / raw_capacity_path).resolve()
        if raw_capacity_path is not None
        else None
    )
    capacity_receipt_dir = (project_root / CAPACITY_RECEIPTS).resolve()
    protected_schema = (project_root / "schemas" / SCHEMA_NAME).resolve()
    if receipt_path == protected_schema or receipt_path == capacity_path:
        raise PermissionError("probe output collides with an immutable input or its schema")
    if receipt_path.exists() and _is_reparse_or_symlink(receipt_path):
        raise PermissionError("probe output cannot replace a symlink or reparse point")
    try:
        receipt_path.relative_to(capacity_receipt_dir)
    except ValueError:
        pass
    else:
        raise PermissionError("probe output cannot target the immutable capacity receipt directory")
    model_path = (project_root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx").resolve()
    voices_path = (project_root / "models" / "kokoro" / "voices-v1.0.bin").resolve()
    kokoro: dict[str, Any] = {
        "model_path": str(model_path),
        "model_hash_before": None,
        "model_hash_after": None,
        "voices_path": str(voices_path),
        "voices_hash_before": None,
        "voices_hash_after": None,
        "artifacts_unchanged": None,
        "engine_implementation": None,
    }
    capacity_binding: dict[str, Any] = {
        "mode": "CAPACITY_BOUND" if capacity_path is not None else "DIAGNOSTIC_ONLY",
        "receipt_path": str(capacity_path) if capacity_path is not None else None,
        "receipt_id": None,
        "receipt_sha256_before": None,
        "receipt_sha256_after": None,
        "receipt_unchanged": None,
        "binding_match": None,
    }
    binding_before: dict[str, Any] | None = None
    binding_after: dict[str, Any] | None = None
    binding_unchanged: bool | None = None
    sample: dict[str, Any] | None = None
    failure: dict[str, str] | None = None
    engine: Any | None = None
    binding: Any | None = None
    expected_binding: dict[str, Any] | None = None
    sample_candidate: dict[str, Any] | None = None
    stage = "PREFLIGHT"
    started = time.perf_counter()

    try:
        if not project_root.is_dir():
            raise NotADirectoryError(project_root)
        if capacity_path is not None:
            stage = "CAPACITY_BEFORE"
            capacity_hash = _sha256_file(capacity_path)
            capacity_binding["receipt_sha256_before"] = capacity_hash
            capacity = capacity_verifier(
                project_root,
                receipt_path=capacity_path,
                expected_sha256=capacity_hash,
                require_pass=True,
            )
            if capacity.get("schema_version") != "1.1.0" or (capacity.get("espeak") or {}).get("status") != "PASS":
                raise PermissionError("expected capacity receipt lacks a current PASS eSpeak binding")
            capacity_binding["receipt_id"] = capacity["receipt_id"]
            expected_binding = _normalize_binding(espeak_binding_identity(capacity["espeak"]))
        for required in (model_path, voices_path):
            if not required.is_file():
                raise FileNotFoundError(required)
        kokoro["model_hash_before"] = _sha256_file(model_path)
        kokoro["voices_hash_before"] = _sha256_file(voices_path)

        stage = "BUILD_LOCAL_VOICE"
        if expected_binding is None:
            engine = voice_builder(project_root)
        else:
            engine = voice_builder(project_root, expected_binding=expected_binding)
        kokoro["engine_implementation"] = (
            f"{engine.__class__.__module__}.{engine.__class__.__qualname__}"
        )
        binding = getattr(engine, "_heroverse_espeak_binding", None)
        if binding is None:
            raise PermissionError("local voice engine omitted its eSpeak binding")

        stage = "BINDING_BEFORE"
        if expected_binding is None:
            binding_before = _normalize_binding(binding_revalidator(binding))
        else:
            binding_before = _normalize_binding(
                binding_revalidator(binding, expected_binding=expected_binding)
            )

        stage = "SYNTHESIZE_SAMPLE"
        rendered = sample_synthesizer(
            engine,
            text=PROBE_TEXT,
            output_path=staged_sample_path,
            voice_id=PROBE_VOICE_ID,
            speed=PROBE_SPEED,
        )
        sample_candidate = _sample_evidence(
            rendered,
            expected_path=staged_sample_path,
            expected_text=PROBE_TEXT,
            expected_voice_id=PROBE_VOICE_ID,
            expected_speed=PROBE_SPEED,
        )

        stage = "BINDING_AFTER"
        if expected_binding is None:
            binding_after = _normalize_binding(binding_revalidator(binding))
        else:
            binding_after = _normalize_binding(
                binding_revalidator(binding, expected_binding=expected_binding)
            )
        stage = "BINDING_COMPARE"
        binding_unchanged = binding_before == binding_after
        if not binding_unchanged:
            raise PermissionError("eSpeak binding changed during the Kokoro synthesis probe")
        if expected_binding is not None:
            capacity_binding["binding_match"] = (
                binding_before == expected_binding and binding_after == expected_binding
            )
            if not capacity_binding["binding_match"]:
                raise PermissionError("runtime eSpeak binding diverges from expected capacity")

        stage = "KOKORO_AFTER"
        kokoro["model_hash_after"] = _sha256_file(model_path)
        kokoro["voices_hash_after"] = _sha256_file(voices_path)
        kokoro["artifacts_unchanged"] = (
            kokoro["model_hash_before"] == kokoro["model_hash_after"]
            and kokoro["voices_hash_before"] == kokoro["voices_hash_after"]
        )
        stage = "KOKORO_COMPARE"
        if not kokoro["artifacts_unchanged"]:
            raise PermissionError("Kokoro model or voice data changed during synthesis")

        stage = "SAMPLE_GATE"
        if sample_candidate["clipping"]:
            raise RuntimeError("voice probe WAV clipped")

        if capacity_path is not None:
            stage = "CAPACITY_AFTER"
            capacity_binding["receipt_sha256_after"] = _sha256_file(capacity_path)
            capacity_binding["receipt_unchanged"] = (
                capacity_binding["receipt_sha256_before"]
                == capacity_binding["receipt_sha256_after"]
            )
            if not capacity_binding["receipt_unchanged"]:
                raise PermissionError("expected capacity receipt changed during the probe")
            capacity_verifier(
                project_root,
                receipt_path=capacity_path,
                expected_receipt_id=capacity_binding["receipt_id"],
                expected_sha256=capacity_binding["receipt_sha256_before"],
                require_pass=True,
            )

        stage = "COMMIT_SAMPLE"
        commit_status = _commit_sample_create_only(
            staged_sample_path,
            sample_path,
            sample_candidate["content_hash"],
        )
        sample = dict(sample_candidate)
        sample["path"] = str(sample_path)
        sample["commit_status"] = commit_status
    except Exception as exc:
        failure = _error(stage, exc)
    finally:
        _unlink_best_effort(staged_sample_path)
        if binding is not None and callable(getattr(binding, "close", None)):
            try:
                binding.close()
            except Exception as exc:
                if failure is None:
                    failure = _error("BINDING_CLEANUP", exc)

    status = "FAIL" if failure is not None else "PASS"
    elapsed_seconds = round(time.perf_counter() - started, 6)
    userprofile = os.environ.get("USERPROFILE")
    receipt = {
        "schema_version": "1.1.0",
        "probe_id": probe_id,
        "status": status,
        "created_at": stamp,
        "elapsed_seconds": elapsed_seconds,
        "process_context": {
            "pid": pid,
            "ppid": ppid,
            "python_executable": str(Path(sys.executable).resolve()),
            "path_home": str(Path.home().resolve()),
            "userprofile": str(Path(userprofile).resolve()) if userprofile else None,
            "cwd": str(Path.cwd().resolve()),
            "os_name": os.name,
            "platform": sys.platform,
        },
        "inputs": {
            "root": str(project_root),
            "output": str(receipt_path),
            "sample_output": str(sample_path),
        },
        "kokoro": kokoro,
        "capacity_binding": capacity_binding,
        "binding_before": binding_before,
        "binding_after": binding_after,
        "binding_unchanged": binding_unchanged,
        "sample": sample,
        "effects": {
            "technical_cost_brl": 0,
            "external_api_calls": 0,
            "publication_effects": 0,
            "scheduled_task_invoked": False,
        },
        "receipt_write": {
            "path": str(receipt_path),
            "method": ATOMIC_WRITE_METHOD,
            "atomic_replace": True,
        },
        "error": failure,
    }
    _validate_receipt(project_root, receipt)
    _write_json_atomic(receipt_path, receipt)
    return receipt


def verify_scheduled_voice_probe_receipt(
    root: Path,
    receipt_path: Path,
    *,
    max_age_seconds: float,
    now: datetime | None = None,
    require_capacity_bound: bool = True,
    expected_capacity_receipt: Path | None = None,
    capacity_verifier: Callable[..., dict[str, Any]] = verify_phase6_capacity_receipt,
) -> dict[str, Any]:
    """Verify a fresh probe; diagnostic receipts never satisfy capacity by default."""

    project_root = Path(root).resolve()
    raw_receipt = Path(receipt_path)
    path = _absolute_leaf(project_root, raw_receipt)
    maximum_age = _finite_number(max_age_seconds, "maximum receipt age")
    if maximum_age <= 0:
        raise ValueError("maximum probe receipt age must be positive")
    if not path.is_file() or _is_reparse_or_symlink(path):
        raise PermissionError("scheduled voice probe receipt is not a regular local file")
    receipt_bytes = path.read_bytes()
    value = json.loads(receipt_bytes.decode("utf-8-sig"))
    _validate_receipt(project_root, value)
    if value["status"] != "PASS":
        raise PermissionError("scheduled voice probe receipt is not PASS")
    if (
        Path(value["inputs"]["root"]).resolve() != project_root
        or _absolute_leaf(project_root, Path(value["inputs"]["output"])) != path
        or _absolute_leaf(project_root, Path(value["receipt_write"]["path"])) != path
    ):
        raise PermissionError("scheduled voice probe receipt path binding diverges")
    expected_probe_id = "scheduled-voice-probe-" + hashlib.sha256(
        (
            f"{project_root}|{path}|{value['created_at']}|"
            f"{value['process_context']['pid']}|{value['process_context']['ppid']}"
        ).encode("utf-8")
    ).hexdigest()[:24]
    if value["probe_id"] != expected_probe_id:
        raise PermissionError("scheduled voice probe identity cannot be recomposed")

    moment = now or datetime.now(timezone.utc)
    if moment.tzinfo is None:
        raise ValueError("freshness verification instant must be timezone-aware")
    age_seconds = (moment.astimezone(timezone.utc) - _parse_timestamp(value["created_at"])).total_seconds()
    if age_seconds < 0 or age_seconds > maximum_age:
        raise PermissionError("scheduled voice probe receipt is outside the allowed freshness window")

    expected_model_path = (project_root / "models/kokoro/kokoro-v1.0.fp16.onnx").resolve()
    expected_voices_path = (project_root / "models/kokoro/voices-v1.0.bin").resolve()
    kokoro = value["kokoro"]
    if (
        Path(kokoro["model_path"]).resolve() != expected_model_path
        or Path(kokoro["voices_path"]).resolve() != expected_voices_path
        or not kokoro["artifacts_unchanged"]
        or kokoro["model_hash_before"] != kokoro["model_hash_after"]
        or kokoro["voices_hash_before"] != kokoro["voices_hash_after"]
        or _sha256_file(expected_model_path) != kokoro["model_hash_before"]
        or _sha256_file(expected_voices_path) != kokoro["voices_hash_before"]
    ):
        raise PermissionError("Kokoro artifacts diverge from the fresh probe receipt")
    if (
        not value["binding_unchanged"]
        or value["binding_before"] != value["binding_after"]
    ):
        raise PermissionError("eSpeak binding is not stable in the probe receipt")

    sample = value["sample"]
    sample_path = _absolute_leaf(project_root, Path(sample["path"]))
    if (
        sample_path != _absolute_leaf(project_root, Path(value["inputs"]["sample_output"]))
        or sample_path != _sample_path_for(path, value["probe_id"])
        or not sample_path.is_file()
        or _is_reparse_or_symlink(sample_path)
        or _sha256_file(sample_path) != sample["content_hash"]
        or sample["clipping"]
        or sample["text"] != PROBE_TEXT
        or sample["text_hash"] != _sha256_text(PROBE_TEXT)
        or sample["voice_id"] != PROBE_VOICE_ID
        or sample["speed"] != PROBE_SPEED
    ):
        raise PermissionError("voice probe WAV diverges from its receipt")
    wav = _inspect_wav(sample_path)
    duration_ms = round(wav["frames"] / wav["sample_rate"] * 1000)
    if (
        wav["channels"] != sample["channels"]
        or wav["sample_width_bytes"] != sample["sample_width_bytes"]
        or wav["sample_rate"] != sample["sample_rate"]
        or wav["frames"] != sample["frames"]
        or duration_ms != sample["duration_ms"]
    ):
        raise PermissionError("voice probe WAV measurements diverge from its receipt")

    capacity_binding = value["capacity_binding"]
    if capacity_binding["mode"] == "DIAGNOSTIC_ONLY":
        if require_capacity_bound:
            raise PermissionError("diagnostic voice probe cannot satisfy a capacity consumer")
        if not path.is_file() or path.read_bytes() != receipt_bytes:
            raise PermissionError("scheduled voice probe receipt changed during verification")
        return value

    bound_path = Path(capacity_binding["receipt_path"]).resolve()
    if expected_capacity_receipt is not None:
        raw_expected = Path(expected_capacity_receipt)
        resolved_expected = (
            raw_expected if raw_expected.is_absolute() else project_root / raw_expected
        ).resolve()
        if bound_path != resolved_expected:
            raise PermissionError("probe is bound to a different capacity receipt")
    if (
        not capacity_binding["receipt_unchanged"]
        or not capacity_binding["binding_match"]
        or capacity_binding["receipt_sha256_before"]
        != capacity_binding["receipt_sha256_after"]
        or _sha256_file(bound_path) != capacity_binding["receipt_sha256_before"]
    ):
        raise PermissionError("capacity binding diverges from the probe receipt")
    capacity = capacity_verifier(
        project_root,
        receipt_path=bound_path,
        expected_receipt_id=capacity_binding["receipt_id"],
        expected_sha256=capacity_binding["receipt_sha256_before"],
        require_pass=True,
    )
    expected_binding = _normalize_binding(espeak_binding_identity(capacity["espeak"]))
    if value["binding_before"] != expected_binding or value["binding_after"] != expected_binding:
        raise PermissionError("probe eSpeak binding diverges from verified capacity")
    if not path.is_file() or path.read_bytes() != receipt_bytes:
        raise PermissionError("scheduled voice probe receipt changed during verification")
    return value


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Probe the zero-cost local Kokoro/eSpeak binding in this exact process "
            "and atomically write a PASS/FAIL receipt."
        )
    )
    parser.add_argument("--root", required=True, type=Path, help="HeroVerse project root")
    parser.add_argument("--output", required=True, type=Path, help="Explicit JSON receipt path")
    parser.add_argument(
        "--expected-capacity-receipt",
        type=Path,
        help="Optional immutable Phase 6 capacity receipt whose eSpeak binding must match",
    )
    args = parser.parse_args(argv)
    try:
        receipt = run_scheduled_voice_probe(
            args.root,
            args.output,
            expected_capacity_receipt=args.expected_capacity_receipt,
        )
    except Exception as exc:
        print(
            json.dumps(
                {
                    "status": "FAIL",
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "technical_cost_brl": 0,
                    "scheduled_task_invoked": False,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 3

    stream = sys.stdout if receipt["status"] == "PASS" else sys.stderr
    print(
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False),
        file=stream,
    )
    return 0 if receipt["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
