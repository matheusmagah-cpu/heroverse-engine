from __future__ import annotations

import hashlib
import json
import math
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .google_api_runtime import (
    GOOGLE_OPERATION_DEADLINE_SECONDS,
    GoogleOperationDeadline,
    build_authorized_service,
    execute_google_request,
)
from .queue_phase6 import TransactionalQueue
from .youtube_integration import INTEGRATION_SCOPES
from .zero_cost_guard import evaluate_zero_cost


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
OBSERVER_ID = "heroverse-daily-channel-goal-observer-v1"
OPERATION_ID = "heroverse-30-day-goal-trajectory-v1"
TASK_TYPE = "GOAL_CHANNEL_CHECKPOINT"
BASE = Path("output/operations/phase6/channel-goal-observer")
RUNTIME = BASE / "status.json"
LATEST = BASE / "latest.json"
PUBLICATION = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
OWNED_LATEST = Path(f"output/operations/phase6/metrics/{VIDEO_ID}/latest.json")
CONNECTION = Path("output/integrations/youtube/heroverse/connection-receipt.json")
PREFLIGHT = Path("output/operations/zero-cost/phase6-goal-channel-preflight.json")
PREFLIGHT_HISTORY = Path("output/operations/zero-cost/phase6-goal-channel-preflights")
EXTERNAL_READS = BASE / "external-read-checkpoints"
INTERVAL = timedelta(hours=24)
RETRY_INTERVAL = timedelta(minutes=30)
RETRY_WINDOW = timedelta(hours=6)
MAX_RETRIES = 12
QUOTA_RETRY_INTERVAL = timedelta(minutes=5)
QUOTA_BLOCK_REASON = "PHASE6_GOAL_CHANNEL_ZERO_COST_OR_FREE_QUOTA_BLOCKED"
GOAL_CHANNEL_LEASE_SECONDS = 300
# Preserve a full minute of the lease for checkpoint/retry persistence. This
# bounds the read operation, not the entire lifecycle or a provider outage.
MAX_GOAL_CHANNEL_DEADLINE_SECONDS = GOAL_CHANNEL_LEASE_SECONDS - 60


class _UpstreamChannelRetry(RuntimeError):
    def __init__(self, retry_at: datetime, reason: str) -> None:
        super().__init__(reason)
        self.retry_at = retry_at


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _optional(path: Path) -> dict[str, Any]:
    try:
        return _read(path) if path.is_file() else {}
    except (OSError, json.JSONDecodeError, TypeError):
        return {}


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _bytes_hash(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _confined(root: Path, reference: str, parent: Path) -> Path:
    path = (root / reference).resolve()
    try:
        path.relative_to((root / parent).resolve())
    except ValueError as exc:
        raise PermissionError(f"checkpoint escapes its immutable directory: {reference}") from exc
    if not path.is_file():
        raise FileNotFoundError(f"checkpoint is unavailable: {reference}")
    return path


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    if path.is_file():
        if _read(path) != value:
            raise PermissionError(f"immutable checkpoint collision: {path.name}")
        return
    _write(path, value)


def _load_preflight(root: Path, *, job_id: str, reference: str, expected_hash: str) -> tuple[dict[str, Any], Path]:
    path = _confined(root, reference, PREFLIGHT_HISTORY / job_id)
    if _bytes_hash(path) != expected_hash:
        raise PermissionError("goal-channel quota preflight hash mismatch")
    value = _read(path)
    _validate(root, "zero_cost_guard.schema.json", value)
    if value.get("operation") != "phase6_goal_channel_checkpoint":
        raise PermissionError("goal-channel quota preflight operation mismatch")
    digest = _canonical_hash(value).split(":", 1)[1]
    if path.name != f"preflight-{digest[:24]}.json":
        raise PermissionError("goal-channel quota preflight identity mismatch")
    return value, path


def _materialize_preflight(
    root: Path,
    *,
    job_id: str,
    checkpoint: dict[str, Any],
    observed_usage: dict[str, int] | None,
    current: datetime,
) -> tuple[dict[str, Any], str, str]:
    reference = checkpoint.get("quota_preflight")
    expected_hash = checkpoint.get("quota_preflight_hash")
    if isinstance(reference, str) and isinstance(expected_hash, str):
        prior, _ = _load_preflight(
            root, job_id=job_id, reference=reference, expected_hash=expected_hash,
        )
        if prior.get("execution_permitted") is True:
            return prior, reference, expected_hash
    value = evaluate_zero_cost(
        root,
        operation="phase6_goal_channel_checkpoint",
        observed_usage=observed_usage,
        created_at=_stamp(current),
    )
    _validate(root, "zero_cost_guard.schema.json", value)
    digest = _canonical_hash(value).split(":", 1)[1]
    path = root / PREFLIGHT_HISTORY / job_id / f"preflight-{digest[:24]}.json"
    _write_immutable(path, value)
    _write(root / PREFLIGHT, value)
    return value, _relative(root, path), _bytes_hash(path)


def _external_slot(scheduled: datetime) -> str:
    return hashlib.sha256(_stamp(scheduled).encode("utf-8")).hexdigest()[:24]


def _external_identity(value: dict[str, Any]) -> str:
    semantic = {key: item for key, item in value.items() if key != "checkpoint_id"}
    return _canonical_hash(semantic).split(":", 1)[1]


def _validate_external_read(
    root: Path,
    *,
    scheduled: datetime,
    path: Path,
    expected_hash: str | None = None,
) -> dict[str, Any]:
    if expected_hash is not None and _bytes_hash(path) != expected_hash:
        raise PermissionError("goal-channel external read hash mismatch")
    value = _read(path)
    _validate(root, "phase6_channel_goal_external_read.schema.json", value)
    if value.get("scheduled_at") != _stamp(scheduled):
        raise PermissionError("goal-channel external read schedule mismatch")
    digest = _external_identity(value)
    if value.get("checkpoint_id") != f"phase6-goal-channel-read-{digest[:24]}":
        raise PermissionError("goal-channel external read identity mismatch")
    if path.name != f"channel-read-{digest[:24]}.json":
        raise PermissionError("goal-channel external read filename mismatch")
    preflight, _ = _load_preflight(
        root,
        job_id=str(value["job_id"]),
        reference=str(value["quota_preflight_path"]),
        expected_hash=str(value["quota_preflight_sha256"]),
    )
    if preflight.get("execution_permitted") is not True:
        raise PermissionError("goal-channel external read is not bound to a permitted preflight")
    return value


def _find_external_read(
    root: Path,
    *,
    scheduled: datetime,
    checkpoint: dict[str, Any],
) -> tuple[dict[str, Any], str, str] | None:
    slot_parent = EXTERNAL_READS / _external_slot(scheduled)
    reference = checkpoint.get("external_read")
    expected_hash = checkpoint.get("external_read_hash")
    if isinstance(reference, str) and isinstance(expected_hash, str):
        path = _confined(root, reference, slot_parent)
        value = _validate_external_read(
            root, scheduled=scheduled, path=path, expected_hash=expected_hash,
        )
        return value, reference, expected_hash
    directory = root / slot_parent
    candidates = sorted(directory.glob("channel-read-*.json")) if directory.is_dir() else []
    if not candidates:
        return None
    if len(candidates) != 1:
        raise PermissionError("multiple immutable goal-channel reads exist for one daily slot")
    path = candidates[0]
    value = _validate_external_read(root, scheduled=scheduled, path=path)
    return value, _relative(root, path), _bytes_hash(path)


def _archive_external_read(
    root: Path,
    *,
    job_id: str,
    scheduled: datetime,
    captured: datetime,
    metrics: dict[str, Any],
    source_status: str,
    source_error: str | None,
    preflight_reference: str,
    preflight_hash: str,
) -> tuple[dict[str, Any], str, str]:
    value: dict[str, Any] = {
        "schema_version": "1.0.0",
        "checkpoint_id": "",
        "operation_id": OPERATION_ID,
        "job_id": job_id,
        "channel_id": CHANNEL_ID,
        "scheduled_at": _stamp(scheduled),
        "captured_at": _stamp(captured),
        "source_kind": "YOUTUBE_CHANNELS_LIST",
        "source_status": source_status,
        "source_error": source_error,
        "metrics": metrics,
        "quota_preflight_path": preflight_reference,
        "quota_preflight_sha256": preflight_hash,
        "api_units_consumed": 1,
        "technical_cost_brl": 0,
    }
    digest = _external_identity(value)
    value["checkpoint_id"] = f"phase6-goal-channel-read-{digest[:24]}"
    _validate(root, "phase6_channel_goal_external_read.schema.json", value)
    path = root / EXTERNAL_READS / _external_slot(scheduled) / f"channel-read-{digest[:24]}.json"
    existing = sorted(path.parent.glob("channel-read-*.json")) if path.parent.is_dir() else []
    if existing and (len(existing) != 1 or existing[0].resolve() != path.resolve()):
        raise PermissionError("immutable goal-channel read already exists for the daily slot")
    _write_immutable(path, value)
    return value, _relative(root, path), _bytes_hash(path)


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(
        _read(root / "schemas" / schema_name),
        format_checker=FormatChecker(),
    ).validate(value)


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _publication_window(root: Path) -> tuple[datetime, datetime]:
    receipt = _read(root / PUBLICATION)
    if receipt.get("status") != "COMPLETE_PUBLIC" or receipt.get("video_id") != VIDEO_ID:
        raise PermissionError("daily goal observer requires the exact public canary receipt")
    metrics = _optional(root / OWNED_LATEST)
    started_at = metrics.get("published_at") or receipt.get("updated_at") or receipt.get("created_at")
    if not isinstance(started_at, str):
        raise ValueError("public canary start is unavailable")
    started = _parse(started_at)
    return started, started + timedelta(days=30)


def _next_nominal(root: Path, now: datetime) -> tuple[datetime | None, int, datetime | None]:
    started, deadline = _publication_window(root)
    first = started + INTERVAL
    prior = _optional(root / RUNTIME)
    if prior.get("status") in {"RETRY_WAIT", "QUOTA_WAIT"} and prior.get("active_scheduled_at") and prior.get("next_observation_at"):
        active = _parse(str(prior["active_scheduled_at"]))
        return active, int(prior.get("retry_attempt") or 0), _parse(str(prior["next_observation_at"]))

    latest = _optional(root / LATEST)
    nominal = _parse(str(latest["scheduled_at"])) + INTERVAL if latest.get("scheduled_at") else first
    if nominal > deadline:
        return None, 0, None
    if now >= nominal + INTERVAL:
        skipped = int((now - nominal).total_seconds() // INTERVAL.total_seconds())
        nominal = min(deadline, nominal + skipped * INTERVAL)
    return nominal, 0, nominal


def _runtime_value(
    *,
    now: datetime,
    status: str,
    active_scheduled_at: datetime | None,
    next_observation_at: datetime | None,
    retry_attempt: int,
    retry_deadline_at: datetime | None,
    latest_observation: str | None,
    job_id: str | None,
    job_state: str,
    error: str | None,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "observer_id": OBSERVER_ID,
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "status": status,
        "active_scheduled_at": _stamp(active_scheduled_at) if active_scheduled_at else None,
        "next_observation_at": _stamp(next_observation_at) if next_observation_at else None,
        "retry_attempt": retry_attempt,
        "maximum_retry_attempts": MAX_RETRIES,
        "retry_deadline_at": _stamp(retry_deadline_at) if retry_deadline_at else None,
        "latest_observation": latest_observation,
        "job_id": job_id,
        "job_state": job_state,
        "error": error,
        "technical_cost_brl": 0,
        "updated_at": _stamp(now),
    }


def _persist_runtime(root: Path, value: dict[str, Any]) -> dict[str, Any]:
    _validate(root, "phase6_channel_goal_observer_runtime.schema.json", value)
    _write(root / RUNTIME, value)
    return value


def error_runtime(root: Path = ROOT, *, error: str, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return _persist_runtime(root, _runtime_value(
        now=current,
        status="ERROR",
        active_scheduled_at=None,
        next_observation_at=None,
        retry_attempt=0,
        retry_deadline_at=None,
        latest_observation=_relative(root, root / LATEST) if (root / LATEST).is_file() else None,
        job_id=None,
        job_state="NOT_CREATED",
        error=error,
    ))


def _owned_checkpoint(root: Path, scheduled: datetime, now: datetime) -> tuple[dict[str, Any], dict[str, Any], str] | None:
    latest_path = root / OWNED_LATEST
    if not latest_path.is_file():
        return None
    value = _read(latest_path)
    try:
        _validate(root, "own_channel_performance_snapshot.schema.json", value)
        captured = _parse(str(value["captured_at"]))
    except Exception:
        return None
    source = (value.get("sources") or {}).get("youtube_channel_api") or {}
    channel = value.get("channel_metrics") or {}
    if not (scheduled <= captured <= now and captured < scheduled + INTERVAL and value.get("channel_id") == CHANNEL_ID):
        return None
    immutable = latest_path.parent / f"{value['snapshot_id']}.json"
    if not immutable.is_file() or _read(immutable) != value:
        return None
    return value, source, _relative(root, immutable)


def _reusable_owned_checkpoint(root: Path, scheduled: datetime, now: datetime) -> tuple[dict[str, Any], str, str, str | None] | None:
    checkpoint = _owned_checkpoint(root, scheduled, now)
    if checkpoint is None:
        return None
    value, source, source_path = checkpoint
    channel = value.get("channel_metrics") or {}
    observed = (
        source.get("status") == "PASS"
        and channel.get("channelId") == CHANNEL_ID
        and isinstance(channel.get("subscriberCount"), int)
    )
    hidden = (
        source.get("status") == "EMPTY"
        and channel.get("subscriberCount") is None
        and channel.get("hiddenSubscriberCount") is True
    )
    if not (observed or hidden):
        return None
    metrics = {
        "subscriberCount": channel.get("subscriberCount"),
        "subscriberCountPrecision": channel.get("subscriberCountPrecision", "UNAVAILABLE"),
        "hiddenSubscriberCount": channel.get("hiddenSubscriberCount"),
        "videoCount": channel.get("videoCount"),
        "viewCount": channel.get("viewCount"),
    }
    error = None if observed else "HIDDEN_SUBSCRIBER_COUNT"
    return metrics, source_path, str(source.get("status")), error


def _upstream_retry(root: Path, scheduled: datetime, now: datetime) -> tuple[datetime, str] | None:
    checkpoint = _owned_checkpoint(root, scheduled, now)
    if checkpoint is None:
        return None
    value, _source, _path = checkpoint
    goal = value.get("goal_measurement") or {}
    retry_at = goal.get("next_retry_at")
    reason = goal.get("blocking_reason")
    if goal.get("status") != "RETRYING_SOURCE_FAILURE" or not isinstance(retry_at, str) or not isinstance(reason, str):
        return None
    parsed = _parse(retry_at)
    if parsed <= now:
        parsed = now + RETRY_INTERVAL
    return parsed, f"UPSTREAM_OWNED_CHANNEL_RETRY:{reason}"


def _build_youtube(token_path: Path, *, deadline: GoogleOperationDeadline) -> Any:
    from google.oauth2.credentials import Credentials  # type: ignore

    deadline.pulse("daily-channel.credentials.load:before")
    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    deadline.pulse("daily-channel.credentials.load:after")
    if not credentials.valid:
        raise PermissionError("OAuth health must be valid before the daily channel checkpoint")
    service = build_authorized_service(
        "youtube", "v3", credentials=credentials,
        request_timeout_seconds=deadline.request_timeout("daily-channel.discovery:transport"),
    )
    deadline.pulse("daily-channel.discovery:after")
    return service


def _collect_channel(
    youtube: Any, *, deadline: GoogleOperationDeadline,
) -> tuple[dict[str, Any], str, str | None]:
    deadline.pulse("daily-channel.channels.list:prepare")
    # One request only. Timeout is returned to the existing persisted retry
    # schedule; never retry transparently inside the one-unit quota preflight.
    response = execute_google_request(
        youtube.channels().list(
            part="id,statistics",
            mine=True,
            fields="items(id,statistics(subscriberCount,hiddenSubscriberCount,videoCount,viewCount))",
        ),
        deadline=deadline,
        stage="daily-channel.channels.list",
    )
    items = response.get("items") or []
    item = items[0] if len(items) == 1 else {}
    if item.get("id") != CHANNEL_ID:
        raise PermissionError("Authenticated channel identity mismatch")
    statistics = item.get("statistics") or {}
    metrics = {
        "subscriberCount": int(statistics["subscriberCount"]) if statistics.get("subscriberCount") is not None else None,
        "subscriberCountPrecision": "PUBLIC_ROUNDED_TO_THREE_SIGNIFICANT_FIGURES" if statistics.get("subscriberCount") is not None else "UNAVAILABLE",
        "hiddenSubscriberCount": bool(statistics["hiddenSubscriberCount"]) if statistics.get("hiddenSubscriberCount") is not None else None,
        "videoCount": int(statistics["videoCount"]) if statistics.get("videoCount") is not None else None,
        "viewCount": int(statistics["viewCount"]) if statistics.get("viewCount") is not None else None,
    }
    if metrics["subscriberCount"] is not None:
        return metrics, "PASS", None
    if metrics["hiddenSubscriberCount"] is True:
        return metrics, "EMPTY", "HIDDEN_SUBSCRIBER_COUNT"
    raise RuntimeError("SUBSCRIBER_COUNT_NOT_RETURNED")


def _observation(
    *,
    scheduled: datetime,
    captured: datetime,
    source_kind: str,
    source_status: str,
    source_path: str,
    source_error: str | None,
    metrics: dict[str, Any],
    api_units: int,
    preflight_path: str | None,
) -> dict[str, Any]:
    decision_status = "OBSERVED" if isinstance(metrics.get("subscriberCount"), int) else "UNAVAILABLE_HIDDEN_SUBSCRIBER_COUNT"
    semantic = {
        "scheduled_at": _stamp(scheduled),
        "captured_at": _stamp(captured),
        "source_kind": source_kind,
        "source_path": source_path,
        "metrics": metrics,
        "decision_status": decision_status,
    }
    digest = _canonical_hash(semantic).split(":", 1)[1]
    return {
        "schema_version": "1.0.0",
        "observation_id": f"phase6-channel-goal-observation-{digest[:24]}",
        "observer_id": OBSERVER_ID,
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "scheduled_at": _stamp(scheduled),
        "captured_at": _stamp(captured),
        "source": {
            "kind": source_kind,
            "api_status": source_status,
            "method": "reuse exact immutable owned checkpoint" if source_kind == "OWNED_METRICS_REUSE" else "channels.list mine exact authenticated channel statistics",
            "evidence_path": source_path,
            "error": source_error,
        },
        "metrics": metrics,
        "decision": {
            "status": decision_status,
            "subscriber_count_observed": decision_status == "OBSERVED",
            "eligible_for_trajectory": decision_status == "OBSERVED",
        },
        "quota": {
            "api_units_consumed": api_units,
            "preflight_path": preflight_path,
            "billing_enabled": False,
        },
        "technical_cost_brl": 0,
        "claim_boundary": [
            "The public subscriber count uses the YouTube Data API precision boundary and is not represented as an exact private counter.",
            "One daily observation updates trajectory control; it does not guarantee audience growth or YPP approval.",
            "A reused owned checkpoint consumes zero additional API units; a direct call is allowed only after the zero-cost quota guard passes.",
        ],
    }


def _persist_observation(root: Path, value: dict[str, Any]) -> str:
    _validate(root, "phase6_channel_goal_observation.schema.json", value)
    history = root / BASE / "history" / f"{value['observation_id']}.json"
    if history.is_file():
        if _read(history) != value:
            raise PermissionError("immutable daily channel observation collision")
    else:
        _write(history, value)
    _write(root / LATEST, value)
    return _relative(root, history)


def _enqueue(queue: TransactionalQueue, *, scheduled: datetime, available: datetime, retry_attempt: int, now: datetime) -> dict[str, Any]:
    key = f"phase6-goal-channel:{_stamp(scheduled)}:retry:{retry_attempt}"
    return queue.enqueue(
        idempotency_key=key,
        operation_id=OPERATION_ID,
        channel_id=CHANNEL_ID,
        task_type=TASK_TYPE,
        payload={"scheduled_at": _stamp(scheduled), "retry_attempt": retry_attempt},
        max_attempts=3,
        available_at=available,
        now=now,
    )


def is_closed_failed_window(root: Path, runtime: dict[str, Any], *, now: datetime) -> bool:
    """Authenticate an exhausted historical schedule, never a successful read.

    The original BLOCKED/error stays visible. Only its completed, expired
    lifecycle ceases to be an active execution blocker. Use the existing
    read-only queue view (including the invocation's protected DB capture).
    """
    _validate(root, "phase6_channel_goal_observer_runtime.schema.json", runtime)
    if (runtime.get("status") != "BLOCKED" or runtime.get("job_state") != "SUCCEEDED"
            or runtime.get("next_observation_at") is not None):
        return False
    started, deadline = _publication_window(root)
    scheduled = _parse(runtime["active_scheduled_at"])
    if (not started < scheduled <= deadline < now
            or scheduled + INTERVAL <= deadline
            or _parse(runtime["retry_deadline_at"]) != scheduled + RETRY_WINDOW
            or _parse(runtime["updated_at"]) > now):
        return False
    from .maintenance_protocol import queue_snapshot

    snapshot = queue_snapshot(root, now=now)
    jobs = [job for job in snapshot["jobs"] if job["operation_id"] == OPERATION_ID
            and job["task_type"] == TASK_TYPE]
    matches = [job for job in jobs if job["job_id"] == runtime["job_id"]]
    if len(matches) != 1:
        return False
    job = matches[0]
    payload, checkpoint = job["payload"], job["checkpoint"]
    attempt = payload.get("retry_attempt")
    if isinstance(attempt, bool) or not isinstance(attempt, int) or not 0 <= attempt < MAX_RETRIES:
        return False
    failed_attempt = checkpoint.get("retry_attempt", attempt + 1)
    return bool(
        job["channel_id"] == runtime["channel_id"] == CHANNEL_ID
        and runtime["observer_id"] == OBSERVER_ID
        and payload.get("scheduled_at") == _stamp(scheduled)
        and job["idempotency_key"] == f"phase6-goal-channel:{_stamp(scheduled)}:retry:{attempt}"
        and checkpoint.get("outcome") == "SOURCE_FAILURE_RETRY_EXHAUSTED"
        and failed_attempt == runtime["retry_attempt"] == attempt + 1
        and checkpoint.get("error") == runtime["error"]
        and _parse(job["updated_at"]) <= _parse(runtime["updated_at"])
        and all(item["state"] == "SUCCEEDED" and item["lease_owner"] is None
                and item["lease_until"] is None for item in jobs)
    )


def _claim_expected(
    queue: TransactionalQueue,
    *,
    expected_job_id: str,
    scheduled: datetime,
    now: datetime,
) -> tuple[dict[str, Any] | None, str | None]:
    """Claim the intended slot while retiring stale due slots after downtime.

    The queue deliberately preserves every command.  A machine that resumes on
    D5 may still hold the pre-scheduled D1 command, while the observation policy
    correctly selects D5 as the only useful catch-up slot.  Those old commands
    are closed with an auditable supersession receipt; they are never executed
    against current data and never become dead letters.
    """

    for _ in range(32):
        claimed = queue.claim(
            worker_id=f"gestor-central-goal-channel-{os.getpid()}",
            task_type=TASK_TYPE,
            lease_seconds=GOAL_CHANNEL_LEASE_SECONDS,
            now=now,
        )
        if claimed is None:
            return None, None
        if claimed["job_id"] == expected_job_id:
            return claimed, None
        claimed_scheduled_raw = (claimed.get("payload") or {}).get("scheduled_at")
        try:
            claimed_scheduled = _parse(str(claimed_scheduled_raw))
        except (TypeError, ValueError):
            queue.fail(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                error="MALFORMED_GOAL_CHANNEL_JOB_SCHEDULE", now=now,
            )
            return claimed, f"QUEUE_JOB_IDENTITY_MISMATCH:{claimed['job_id']}"
        if claimed_scheduled >= scheduled:
            queue.fail(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                error=f"UNEXPECTED_GOAL_CHANNEL_JOB_FOR:{_stamp(scheduled)}", now=now,
            )
            return claimed, f"QUEUE_JOB_IDENTITY_MISMATCH:{claimed['job_id']}"
        queue.succeed(
            claimed["job_id"],
            worker_id=claimed["lease_owner"],
            checkpoint={
                "outcome": "SUPERSEDED_BY_CATCHUP",
                "scheduled_at": _stamp(claimed_scheduled),
                "replacement_scheduled_at": _stamp(scheduled),
            },
            now=now,
        )
    return None, "STALE_GOAL_CHANNEL_JOB_DRAIN_LIMIT_REACHED"


def run_daily_channel_goal_observer(
    root: Path = ROOT,
    *,
    token_path: Path | None = None,
    observed_usage: dict[str, int] | None = None,
    youtube: Any | None = None,
    now: datetime | None = None,
    deadline_seconds: float = GOOGLE_OPERATION_DEADLINE_SECONDS,
) -> dict[str, Any]:
    if (
        isinstance(deadline_seconds, bool)
        or not isinstance(deadline_seconds, (int, float))
        or not math.isfinite(deadline_seconds)
        or not 0 < deadline_seconds <= MAX_GOAL_CHANNEL_DEADLINE_SECONDS
    ):
        raise ValueError("daily channel read deadline must be finite, positive and at most 240 seconds")
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    scheduled, retry_attempt, available = _next_nominal(root, current)
    latest_ref = _relative(root, root / LATEST) if (root / LATEST).is_file() else None
    if scheduled is None or available is None:
        return _persist_runtime(root, _runtime_value(
            now=current, status="COMPLETE", active_scheduled_at=None, next_observation_at=None,
            retry_attempt=0, retry_deadline_at=None, latest_observation=latest_ref,
            job_id=None, job_state="NOT_CREATED", error=None,
        ))

    queue = TransactionalQueue(root)
    job = _enqueue(queue, scheduled=scheduled, available=available, retry_attempt=retry_attempt, now=current)
    retry_deadline = scheduled + RETRY_WINDOW
    if current < available:
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current,
            status=(
                "QUOTA_WAIT"
                if retry_attempt == 0 and job.get("last_error") == QUOTA_BLOCK_REASON
                else "RETRY_WAIT" if retry_attempt else "NOT_DUE"
            ),
            active_scheduled_at=scheduled,
            next_observation_at=available,
            retry_attempt=retry_attempt,
            retry_deadline_at=retry_deadline if retry_attempt else None,
            latest_observation=latest_ref,
            job_id=job["job_id"],
            job_state=job["state"],
            error=(
                QUOTA_BLOCK_REASON
                if retry_attempt == 0 and job.get("last_error") == QUOTA_BLOCK_REASON
                else job.get("last_error") if retry_attempt else None
            ),
        ))

    if job["state"] == "SUCCEEDED":
        checkpoint = job.get("checkpoint") or {}
        if checkpoint.get("outcome") == "SOURCE_FAILURE_RETRY_EXHAUSTED":
            # A downtime-expired retry window can end before attempt twelve.
            # Replay the persisted failure, not another API call/queue claim.
            failed_attempt = int(checkpoint.get("retry_attempt")
                                 or (int((job.get("payload") or {}).get("retry_attempt") or 0) + 1))
            next_nominal = scheduled + INTERVAL
            _, deadline = _publication_window(root)
            next_job = (_enqueue(queue, scheduled=next_nominal, available=next_nominal,
                                 retry_attempt=0, now=current)
                        if next_nominal <= deadline else None)
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", active_scheduled_at=scheduled,
                next_observation_at=next_nominal if next_job else None,
                retry_attempt=failed_attempt, retry_deadline_at=retry_deadline,
                latest_observation=latest_ref,
                job_id=next_job["job_id"] if next_job else job["job_id"],
                job_state=next_job["state"] if next_job else "SUCCEEDED",
                error=checkpoint["error"],
            ))
        if checkpoint.get("outcome") == "SOURCE_FAILURE_RETRY" and checkpoint.get("next_retry_at"):
            next_retry = _parse(str(checkpoint["next_retry_at"]))
            next_attempt = int(checkpoint["retry_attempt"])
            next_job = _enqueue(queue, scheduled=scheduled, available=next_retry, retry_attempt=next_attempt, now=current)
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="RETRY_WAIT", active_scheduled_at=scheduled,
                next_observation_at=next_retry, retry_attempt=next_attempt,
                retry_deadline_at=retry_deadline, latest_observation=latest_ref,
                job_id=next_job["job_id"], job_state=next_job["state"], error=checkpoint.get("error"),
            ))
        raise RuntimeError("SUCCEEDED_DAILY_GOAL_JOB_HAS_NO_REPLAYABLE_CHECKPOINT")

    claimed, claim_error = _claim_expected(
        queue,
        expected_job_id=job["job_id"],
        scheduled=scheduled,
        now=current,
    )
    if claimed is None or claimed["job_id"] != job["job_id"]:
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="ERROR", active_scheduled_at=scheduled,
            next_observation_at=available, retry_attempt=retry_attempt,
            retry_deadline_at=retry_deadline if retry_attempt else None, latest_observation=latest_ref,
            job_id=job["job_id"], job_state=job["state"],
            error=claim_error or "EXPECTED_GOAL_CHANNEL_JOB_NOT_CLAIMABLE",
        ))

    operation_deadline = GoogleOperationDeadline(float(deadline_seconds))
    try:
        reused = _reusable_owned_checkpoint(root, scheduled, current)
        if reused is not None:
            metrics, source_path, source_status, source_error = reused
            observation = _observation(
                scheduled=scheduled, captured=current, source_kind="OWNED_METRICS_REUSE",
                source_status=source_status, source_path=source_path, source_error=source_error,
                metrics=metrics, api_units=0, preflight_path=None,
            )
            completion_status = "REUSED_OWNED_CHECKPOINT"
        else:
            upstream_retry = _upstream_retry(root, scheduled, current)
            if upstream_retry is not None:
                raise _UpstreamChannelRetry(upstream_retry[0], upstream_retry[1])
            external = _find_external_read(
                root, scheduled=scheduled, checkpoint=claimed.get("checkpoint") or {},
            )
            if external is None:
                preflight, preflight_ref, preflight_hash = _materialize_preflight(
                    root,
                    job_id=claimed["job_id"],
                    checkpoint=claimed.get("checkpoint") or {},
                    observed_usage=observed_usage,
                    current=current,
                )
                claimed = queue.checkpoint(
                    claimed["job_id"], worker_id=claimed["lease_owner"],
                    value={
                        **(claimed.get("checkpoint") or {}),
                        "quota_preflight": preflight_ref,
                        "quota_preflight_hash": preflight_hash,
                    },
                    now=current,
                )
                if preflight.get("execution_permitted") is not True:
                    next_quota_check = current + QUOTA_RETRY_INTERVAL
                    deferred = queue.defer_claimed(
                        claimed["job_id"],
                        worker_id=claimed["lease_owner"],
                        available_at=next_quota_check,
                        reason=QUOTA_BLOCK_REASON,
                        checkpoint=claimed.get("checkpoint") or {},
                        now=current,
                    )
                    queue.materialize_snapshot(captured_at=current)
                    return _persist_runtime(root, _runtime_value(
                        now=current, status="QUOTA_WAIT", active_scheduled_at=scheduled,
                        next_observation_at=next_quota_check, retry_attempt=0,
                        retry_deadline_at=None, latest_observation=latest_ref,
                        job_id=deferred["job_id"], job_state=deferred["state"],
                        error=QUOTA_BLOCK_REASON,
                    ))
                if youtube is None:
                    if token_path is None or not token_path.is_file():
                        raise FileNotFoundError("external runtime OAuth token is unavailable")
                    youtube = _build_youtube(token_path.resolve(), deadline=operation_deadline)
                metrics, source_status, source_error = _collect_channel(youtube, deadline=operation_deadline)
                external = _archive_external_read(
                    root,
                    job_id=claimed["job_id"],
                    scheduled=scheduled,
                    captured=current,
                    metrics=metrics,
                    source_status=source_status,
                    source_error=source_error,
                    preflight_reference=preflight_ref,
                    preflight_hash=preflight_hash,
                )
            external_value, external_ref, external_hash = external
            claimed = queue.checkpoint(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                value={
                    **(claimed.get("checkpoint") or {}),
                    "external_read": external_ref,
                    "external_read_hash": external_hash,
                },
                now=current,
            )
            metrics = external_value["metrics"]
            source_status = external_value["source_status"]
            source_error = external_value["source_error"]
            observation = _observation(
                scheduled=scheduled, captured=_parse(external_value["captured_at"]), source_kind="YOUTUBE_CHANNELS_LIST",
                source_status=source_status, source_path=external_ref, source_error=source_error,
                metrics=metrics, api_units=1, preflight_path=external_value["quota_preflight_path"],
            )
            completion_status = "COLLECTED"

        observation_ref = _persist_observation(root, observation)
        queue.succeed(
            claimed["job_id"], worker_id=claimed["lease_owner"],
            checkpoint={**(claimed.get("checkpoint") or {}), "outcome": "OBSERVED", "observation": observation_ref}, now=current,
        )
        next_nominal = scheduled + INTERVAL
        _, deadline = _publication_window(root)
        next_job = None
        if next_nominal <= deadline:
            next_job = _enqueue(queue, scheduled=next_nominal, available=next_nominal, retry_attempt=0, now=current)
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status=completion_status, active_scheduled_at=scheduled,
            next_observation_at=next_nominal if next_nominal <= deadline else None,
            retry_attempt=0, retry_deadline_at=None, latest_observation=observation_ref,
            job_id=next_job["job_id"] if next_job else claimed["job_id"],
            job_state=next_job["state"] if next_job else "SUCCEEDED", error=None,
        ))
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        failed_attempt = retry_attempt + 1
        can_retry = failed_attempt < MAX_RETRIES and current + RETRY_INTERVAL <= retry_deadline
        if can_retry:
            requested_retry = getattr(exc, "retry_at", None)
            next_retry = requested_retry if isinstance(requested_retry, datetime) else current + RETRY_INTERVAL
            if next_retry > retry_deadline:
                next_retry = current + RETRY_INTERVAL
            next_job = _enqueue(queue, scheduled=scheduled, available=next_retry, retry_attempt=failed_attempt, now=current)
            queue.succeed(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                checkpoint={
                    **(claimed.get("checkpoint") or {}),
                    "outcome": "SOURCE_FAILURE_RETRY", "error": error,
                    "retry_attempt": failed_attempt, "next_retry_at": _stamp(next_retry),
                },
                now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="RETRY_WAIT", active_scheduled_at=scheduled,
                next_observation_at=next_retry, retry_attempt=failed_attempt,
                retry_deadline_at=retry_deadline, latest_observation=latest_ref,
                job_id=next_job["job_id"], job_state=next_job["state"], error=error,
            ))

        queue.succeed(
            claimed["job_id"], worker_id=claimed["lease_owner"],
            checkpoint={**(claimed.get("checkpoint") or {}), "outcome": "SOURCE_FAILURE_RETRY_EXHAUSTED", "error": error,
                        "retry_attempt": min(MAX_RETRIES, failed_attempt)}, now=current,
        )
        next_nominal = scheduled + INTERVAL
        _, deadline = _publication_window(root)
        next_job = None
        if next_nominal <= deadline:
            next_job = _enqueue(queue, scheduled=next_nominal, available=next_nominal, retry_attempt=0, now=current)
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", active_scheduled_at=scheduled,
            next_observation_at=next_nominal if next_nominal <= deadline else None,
            retry_attempt=min(MAX_RETRIES, failed_attempt), retry_deadline_at=retry_deadline,
            latest_observation=latest_ref,
            job_id=next_job["job_id"] if next_job else claimed["job_id"],
            job_state=next_job["state"] if next_job else "SUCCEEDED", error=error,
        ))


if __name__ == "__main__":
    from .phase6_pilot import resolve_runtime_token
    from .phase6_quota import effective_observation_quota_usage

    print(json.dumps(
        run_daily_channel_goal_observer(
            ROOT,
            token_path=resolve_runtime_token(ROOT),
            observed_usage=effective_observation_quota_usage(ROOT),
        ),
        ensure_ascii=False,
        indent=2,
    ))
