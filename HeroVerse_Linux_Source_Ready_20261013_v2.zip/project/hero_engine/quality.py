from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .db import DEFAULT_DB, ROOT, connect, rows, utc_now
from .planner import analyze_hook, ngram_overlap, score_text
from .modeling import evaluate_opening_line


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"


def _command(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )


def _probe(render_path: Path) -> dict[str, Any]:
    result = _command(
        [
            FFPROBE, "-v", "error", "-show_entries",
            "format=duration,size,bit_rate:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels",
            "-of", "json", str(render_path),
        ]
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    return json.loads(result.stdout)


def _loudness(render_path: Path) -> dict[str, float]:
    result = _command(
        [
            FFMPEG, "-hide_banner", "-i", str(render_path), "-af",
            "loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json",
            "-f", "null", os.devnull,
        ]
    )
    match = re.search(r'\{\s*"input_i"\s*:\s*"([^"]+)".*?"input_tp"\s*:\s*"([^"]+)".*?"input_lra"\s*:\s*"([^"]+)"', result.stderr, re.S)
    if not match:
        raise RuntimeError("Could not parse FFmpeg loudness measurement")
    return {
        "integrated_lufs": float(match.group(1)),
        "true_peak_db": float(match.group(2)),
        "loudness_range_lu": float(match.group(3)),
    }


def _max_silence(render_path: Path) -> float:
    result = _command(
        [
            FFMPEG, "-hide_banner", "-i", str(render_path), "-af",
            "silencedetect=noise=-40dB:d=0.6", "-f", "null", os.devnull,
        ]
    )
    durations = [float(value) for value in re.findall(r"silence_duration:\s*([0-9.]+)", result.stderr)]
    return max(durations, default=0.0)


def _fps(value: str) -> float:
    numerator, denominator = value.split("/", 1)
    return float(numerator) / float(denominator)


def _content_words(value: str) -> set[str]:
    stop = {"a", "an", "and", "are", "as", "at", "be", "before", "by", "for", "from", "in", "is", "it", "of", "on", "or", "the", "this", "to", "you", "your"}
    return {word for word in re.findall(r"[a-z']+", value.lower()) if word not in stop}


def _jaccard(left: str, right: str) -> float:
    left_words = _content_words(left)
    right_words = _content_words(right)
    union = left_words | right_words
    return len(left_words & right_words) / len(union) if union else 1.0


def _cumulative_start(edl: dict[str, Any], segment_index: int) -> float:
    total = 0.0
    for segment in edl["segments"][:segment_index]:
        if segment["type"] == "voiceover":
            total += float(segment["target_seconds"])
        else:
            total += float(segment["end_seconds"]) - float(segment["start_seconds"])
    return total


def audit_production(
    edl_path: Path,
    render_path: Path | None = None,
    db_path: Path | None = None,
) -> dict[str, Any]:
    edl = json.loads(edl_path.read_text(encoding="utf-8"))
    slug = edl["slug"]
    if render_path is None:
        with connect(db_path or DEFAULT_DB) as conn:
            production = conn.execute("SELECT render_path FROM productions WHERE slug=?", (slug,)).fetchone()
        if not production or not production["render_path"]:
            raise ValueError(f"No render found for {slug}")
        render_path = Path(production["render_path"])
    if not render_path.exists():
        raise FileNotFoundError(render_path)

    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, actual: Any, target: str, critical: bool = True) -> None:
        checks.append(
            {
                "name": name,
                "passed": bool(passed),
                "actual": actual,
                "target": target,
                "critical": critical,
            }
        )

    source_segments = [segment for segment in edl["segments"] if segment["type"] == "source_clip"]
    voice_segments = [segment for segment in edl["segments"] if segment["type"] == "voiceover"]
    source_seconds = sum(float(item["end_seconds"]) - float(item["start_seconds"]) for item in source_segments)
    planned_seconds = sum(
        float(item["target_seconds"])
        if item["type"] == "voiceover"
        else float(item["end_seconds"]) - float(item["start_seconds"])
        for item in edl["segments"]
    )
    source_share = source_seconds / planned_seconds if planned_seconds else 1.0
    original_share = 1.0 - source_share
    is_long = edl.get("format") == "long"
    maximum_source_share = 0.25 if is_long else 0.30
    minimum_original_share = 0.75 if is_long else 0.70
    check("source_runtime_share", source_share <= maximum_source_share, round(source_share, 4), f"<= {maximum_source_share:.2f}")
    check("original_runtime_share", original_share >= minimum_original_share, round(original_share, 4), f">= {minimum_original_share:.2f}")
    clip_durations = [round(float(item["end_seconds"]) - float(item["start_seconds"]), 3) for item in source_segments]
    minimum_clip = 6 if is_long else 4
    check("source_clip_duration", all(minimum_clip <= value <= 12 for value in clip_durations), clip_durations, f"each {minimum_clip}–12 seconds")

    video_ids = sorted({item["video_id"] for item in source_segments})
    placeholders = ",".join("?" for _ in video_ids)
    license_rows = rows(
        f"SELECT video_id, license_status FROM videos WHERE video_id IN ({placeholders})",
        tuple(video_ids),
        path=db_path or DEFAULT_DB,
    ) if video_ids else []
    licenses = {item["video_id"]: item["license_status"] for item in license_rows}
    check(
        "source_license_gate",
        all(licenses.get(video_id) == "verified_cc" for video_id in video_ids),
        licenses,
        "verified_cc for every source",
    )
    attribution = edl.get("attribution") or {}
    required_attribution = ["work_title", "author", "source", "license"]
    check(
        "attribution_complete",
        all(attribution.get(field) for field in required_attribution),
        {field: bool(attribution.get(field)) for field in required_attribution},
        "all attribution fields present",
    )
    first = edl["segments"][0]
    hook_total = score_text(first.get("text", ""))[3] if first["type"] == "voiceover" else 0.0
    check(
        "original_hook_first",
        first["type"] == "voiceover" and hook_total >= 3.0,
        {"segment_type": first["type"], "hook_score": round(hook_total, 3)},
        "original voiceover first; lexical hook score >= 3.0",
    )
    primary_title_for_hook = str((edl.get("metadata") or {}).get("primary_title") or (edl.get("title_variants") or [""])[0])
    hook_analysis = (
        evaluate_opening_line(first.get("text", ""), primary_title_for_hook)
        if is_long and first["type"] == "voiceover"
        else analyze_hook(first.get("text", "")) if first["type"] == "voiceover"
        else {"score": 0, "mechanics": {}}
    )
    check(
        "hook_mechanics",
        hook_analysis["score"] >= 7.5 and (hook_analysis.get("passed", True)),
        hook_analysis,
        ">= 7.5/10 using the format-specific empirical opening gate",
    )
    first_duration = float(first.get("target_seconds") or 999)
    hook_deadline = 3.2 if is_long else 4.0
    check("hook_claim_deadline", first_duration <= hook_deadline, first_duration, f"complete opening claim <= {hook_deadline:.1f}s")
    first_source_index = next((index for index, segment in enumerate(edl["segments"]) if segment["type"] == "source_clip"), None)
    first_proof_at = _cumulative_start(edl, first_source_index) if first_source_index is not None else 999.0
    proof_deadline = float((edl.get("hook_blueprint") or {}).get("first_proof_deadline_seconds") or 4.0)
    check("first_proof_deadline", first_proof_at <= proof_deadline, round(first_proof_at, 3), f"source/face proof begins <= {proof_deadline:.1f}s")
    hook_reference = str((edl.get("hook_blueprint") or {}).get("source_hook_text") or "")
    overlap = ngram_overlap(first.get("text", ""), hook_reference)
    maximum_overlap = float((edl.get("hook_blueprint") or {}).get("maximum_trigram_overlap") or 0.35)
    check("hook_originality", bool(hook_reference) and overlap <= maximum_overlap, overlap, f"content-trigram overlap with reference <= {maximum_overlap:.2f}")
    thesis_words = _content_words(edl.get("thesis", ""))
    promise_words = _content_words(" ".join([first.get("text", ""), edl.get("title_variants", [""])[0]]))
    promise_alignment = len(thesis_words & promise_words) / len(thesis_words) if thesis_words else 0.0
    check("hook_promise_alignment", promise_alignment >= 0.60, round(promise_alignment, 3), ">= 60% thesis-keyword alignment across hook + primary title")
    first_eight_beats = sum(
        1 for segment in voice_segments for beat in (segment.get("caption_beats") or [])
        if _cumulative_start(edl, edl["segments"].index(segment)) + float(beat["start"]) < 8.0
    )
    check("opening_visual_beats", first_eight_beats >= 3, first_eight_beats, ">= 3 authored visual beats in first 8 seconds")
    final_segment = edl["segments"][-1]
    payoff_words = _content_words(final_segment.get("text", "")) if final_segment["type"] == "voiceover" else set()
    check(
        "original_closing_payoff",
        final_segment["type"] == "voiceover" and len(payoff_words & thesis_words) >= 2,
        {"segment_type": final_segment["type"], "aligned_words": sorted(payoff_words & thesis_words)},
        "original final segment resolves at least two thesis concepts",
    )
    title_lengths = [len(title) for title in edl.get("title_variants", [])]
    check("title_pack", len(title_lengths) >= 3 and max(title_lengths, default=999) <= 60, title_lengths, ">= 3 variants; each <= 60 chars")
    titles = edl.get("title_variants", [])
    title_similarity = [round(_jaccard(left, right), 3) for index, left in enumerate(titles) for right in titles[index + 1:]]
    check("title_test_distinctness", bool(title_similarity) and max(title_similarity) <= 0.75, title_similarity, "all title-pair Jaccard similarities <= 0.75")
    metadata = edl.get("metadata") or {}
    primary_title = str(metadata.get("primary_title") or "")
    check("primary_title_consistency", primary_title in titles and 30 <= len(primary_title) <= 55, {"title": primary_title, "length": len(primary_title)}, "one approved variant, 30–55 chars")
    description = str(metadata.get("description") or "")
    description_open = description.split("SOURCE EXCERPT", 1)[0]
    hashtags = re.findall(r"(?<!\w)#[A-Za-z0-9_]+", description)
    check(
        "description_package",
        len(description_open.strip()) >= 100 and "SOURCE EXCERPT" in description and len(hashtags) <= 3 and attribution.get("source", "") in description,
        {"viewer_first_chars": len(description_open.strip()), "has_source_block": "SOURCE EXCERPT" in description, "hashtags": hashtags},
        "viewer-first value >= 100 chars; source block + URL; <= 3 hashtags",
    )
    tags = metadata.get("tags") or []
    normalized_tags = {str(tag).strip().lower() for tag in tags if str(tag).strip()}
    check("focused_tag_pack", 6 <= len(tags) <= 12 and len(tags) == len(normalized_tags), tags, "6–12 unique, focused tags")
    pinned_comment = str(metadata.get("pinned_comment") or "")
    check("pinned_comment_prompt", 45 <= len(pinned_comment) <= 220 and "?" in pinned_comment, {"length": len(pinned_comment), "has_question": "?" in pinned_comment}, "45–220 chars and one specific question")
    caption_coverage: list[dict[str, Any]] = []
    for index, segment in enumerate(voice_segments):
        beats = segment.get("caption_beats") or []
        target = float(segment["target_seconds"])
        ordered = sorted(beats, key=lambda item: float(item["start"]))
        covered = bool(ordered) and float(ordered[0]["start"]) <= 0.05 and float(ordered[-1]["end"]) >= target - 0.05
        no_gaps = all(float(right["start"]) - float(left["end"]) <= 0.05 for left, right in zip(ordered, ordered[1:]))
        safe_lines = all(
            all(len(line) <= 20 for line in str(item["text"]).splitlines())
            for item in ordered
        )
        caption_coverage.append({"segment": index, "covered": covered, "no_gaps": no_gaps, "safe_lines": safe_lines})
    check(
        "caption_beat_coverage",
        bool(caption_coverage) and all(item["covered"] and item["no_gaps"] and item["safe_lines"] for item in caption_coverage),
        caption_coverage,
        "100% of original narration covered; no gaps; each authored line <= 20 chars",
    )

    probe = _probe(render_path)
    video = next((item for item in probe["streams"] if item["codec_type"] == "video"), {})
    audio = next((item for item in probe["streams"] if item["codec_type"] == "audio"), {})
    duration = float(probe["format"]["duration"])
    check("render_duration", abs(duration - planned_seconds) <= 0.10, round(duration, 3), f"{planned_seconds:.3f}s ± 0.10s")
    expected_resolution = (1280, 720) if is_long else (720, 1280)
    check(
        "output_resolution",
        video.get("width") == expected_resolution[0] and video.get("height") == expected_resolution[1],
        [video.get("width"), video.get("height")],
        f"{expected_resolution[0]}×{expected_resolution[1]}",
    )
    measured_fps = _fps(video.get("r_frame_rate", "0/1"))
    check("frame_rate", math.isclose(measured_fps, 30.0, abs_tol=0.01), round(measured_fps, 3), "30 fps")
    check("video_codec", video.get("codec_name") == "h264", video.get("codec_name"), "H.264")
    check(
        "audio_format",
        audio.get("codec_name") == "aac" and audio.get("sample_rate") == "48000" and audio.get("channels") == 2,
        {"codec": audio.get("codec_name"), "sample_rate": audio.get("sample_rate"), "channels": audio.get("channels")},
        "AAC, 48 kHz, stereo",
    )
    bitrate = int(probe["format"].get("bit_rate") or 0)
    check("minimum_bitrate", bitrate >= 500_000, bitrate, ">= 500,000 bit/s", critical=False)

    loudness = _loudness(render_path)
    check("integrated_loudness", -18.0 <= loudness["integrated_lufs"] <= -14.0, loudness["integrated_lufs"], "-16 LUFS ± 2")
    check("true_peak", loudness["true_peak_db"] <= -1.0, loudness["true_peak_db"], "<= -1.0 dBTP")
    maximum_silence = _max_silence(render_path)
    check("maximum_silence", maximum_silence <= 1.0, round(maximum_silence, 3), "<= 1.0s above -40 dB")

    critical_checks = [item for item in checks if item["critical"]]
    passed_checks = sum(1 for item in checks if item["passed"])
    release_ready = all(item["passed"] for item in critical_checks)
    report = {
        "slug": slug,
        "generated_at": utc_now(),
        "edl_path": str(edl_path),
        "render_path": str(render_path),
        "release_ready": release_ready,
        "score": round(passed_checks / len(checks) * 100, 2),
        "passed": passed_checks,
        "total": len(checks),
        "measurements": {
            "planned_seconds": planned_seconds,
            "source_seconds": source_seconds,
            "source_share": round(source_share, 4),
            "original_share": round(original_share, 4),
            "loudness": loudness,
            "maximum_silence_seconds": round(maximum_silence, 3),
        },
        "checks": checks,
    }
    return report


def save_quality_report(report: dict[str, Any], db_path: Path | None = None) -> Path:
    output_dir = ROOT / "output" / "reports"
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"quality-{report['slug']}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute(
            """
            UPDATE productions
            SET status=CASE WHEN status IN ('queued', 'published') THEN status ELSE ? END,
                updated_at=?
            WHERE slug=?
            """,
            ("quality_passed" if report["release_ready"] else "quality_failed", utc_now(), report["slug"]),
        )
    return path
