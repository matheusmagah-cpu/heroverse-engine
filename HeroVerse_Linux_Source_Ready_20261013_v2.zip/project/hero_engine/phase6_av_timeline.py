"""F6 audiovisual timeline: deterministic, read-only, never media authority.

51 whole utterances and 90 literal fragments are different surfaces. Visual
spans and captions are independent of historical cuts. Only a whole-utterance
cue can use PCM container bounds without claiming word timing. Semantic events
and internal text selections require applicable calibrated observations. An
explicit UNIT_BOUNDARY is only a whole PCM container edge, not lexical onset.

All planning arguments are explicit caller inputs, not decisions made here.
The verifier requires those inputs again; a candidate cannot authorize its own
different sources, pauses, event requirements or calibration policy.
"""
from __future__ import annotations

import copy
import re
import textwrap
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator

from .phase6_narration_audio_inventory import Reader, _json, inspect_pcm
from .phase6_narration_units import bytes_sha, canonical_sha, verify_narration_unit_plan
from .phase6_av_static_timeline import validate_intent as _static_intent, verify_entry_frames
from .phase6_av_caption_intent import (read_caption_intent, PLAN_BINDING as _CAPTION_PLAN_BINDING,
                                      WHOLE as _CAPTION_WHOLE, LEXICAL as _CAPTION_LEXICAL)
from .phase6_av_visual_intent import (read_visual_intent, PLAN_BINDING as _UNTIMED_VISUAL_PLAN_BINDING,
    SUPPLEMENT_SOURCE_BINDINGS as _UNTIMED_VISUAL_SOURCES, _state_entries as _literal_visual_states)
from .phase6_av_visual_amendment import (read_amended_visual_intent,
    PROJECTION_BINDING as _VISUAL_AMENDMENT_BINDING)
from .phase6_av_asset_use_binding import (read_asset_use_binding,
    validate_binding as _validate_asset_use_binding)
from . import phase6_av_question_case_amendment as _question_case
from . import phase6_av_asset_use_binding_v2 as _question_uses
from . import phase6_av_body_case_amendment as _body_case

VERSION = "phase6-av-timeline-v12"
SCHEMA = "schemas/phase6_av_timeline.schema.json"
RATE, FRAME, GRID = 24000, 800, 2400
CORE = {"reconciliation", "inventory", "diagnostic", "take_plan", "voice_manifest",
        "narrative_script", "protocol", "treatment", "acoustic_envelope"}
AUTHORITY = {k: False for k in ("synthesis_authorized", "render_authorized",
                              "queue_authorized", "publication_authorized", "quality_approved")}
CAPTION_TEXTWRAP_BINDING = {
    "path": "C:/Users/mathe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/Lib/textwrap.py",
    "sha256": "sha256:62867e40cdea6669b361f72af4d7daf0359f207c92cbeddfc7c7506397c1f31c",
}
IMPLEMENTATION_PATHS = (
    SCHEMA, "hero_engine/phase6_narration_audio_inventory.py", "hero_engine/phase6_narration_units.py",
    "hero_engine/phase6_av_static_timeline.py", "hero_engine/phase6_av_static_sources.py",
    "hero_engine/phase6_av_caption_intent.py", "hero_engine/phase6_av_visual_intent.py",
    "schemas/phase6_av_untimed_visual_intent.schema.json",
    "hero_engine/phase6_av_visual_amendment.py", "schemas/phase6_av_visual_amendment.schema.json",
    "hero_engine/phase6_av_asset_use_binding.py", "hero_engine/phase6_av_static_asset_uses_v2.py",
    "schemas/phase6_av_static_asset_uses_v2.schema.json", "hero_engine/phase6_av_question_sources.py",
    "hero_engine/phase6_av_question_case_amendment.py", "schemas/phase6_av_question_case_amendment.schema.json",
    "hero_engine/phase6_av_asset_use_binding_v2.py", "hero_engine/phase6_av_static_asset_uses_v3.py",
    "schemas/phase6_av_static_asset_uses_v3.schema.json",
)
IMPLEMENTATION_PATHS = tuple(dict.fromkeys((*IMPLEMENTATION_PATHS,
    *_body_case.FIXED_IMPLEMENTATIONS, _body_case.MODULE, _body_case.TEST,
    "hero_engine/phase6_av_body_sources.py", "tests/test_phase6_av_body_sources.py",
    "hero_engine/phase6_body_asset_rights.py", "tests/test_phase6_body_asset_rights.py",
    "schemas/phase6_body_static_rights.schema.json", "hero_engine/phase6_av_body_sources_replay.py",
    "tests/test_phase6_av_body_sources_replay.py", "hero_engine/phase6_av_static_uses_v3_replay.py",
    "tests/test_phase6_av_static_uses_v3_replay.py", "hero_engine/phase6_av_static_asset_uses_v4.py",
    "schemas/phase6_av_static_asset_uses_v4.schema.json", "hero_engine/phase6_av_asset_use_binding_v3.py")))
BODY_BINDINGS = {
    "body_case_amendment": _body_case.PROJECTION_BINDING,
    "body_case_evidence": _body_case.AMENDMENT_BINDING,
    "body_case_staging": _body_case.STAGING_BINDING,
}


def integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name}: integer >= {minimum} required")
    return value


def nonempty(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name}: nonempty literal required")
    return value


def exact(value, keys, name):
    if not isinstance(value, dict) or set(value) != set(keys.split()):
        raise ValueError(f"{name}: contract fields differ")


def _same(a, b, message):
    # Canonical JSON comparison is type-sensitive (True != 1, 1 != 1.0).
    if canonical_sha(a) != canonical_sha(b):
        raise ValueError(message)


def _receipt_id(value, field, prefix):
    payload = {k: v for k, v in value.items() if k != field}
    if value.get(field) != prefix + canonical_sha(payload).split(":")[1][:24]:
        raise ValueError(f"{field}: canonical identity differs")


def _sources(reader, bindings):
    if (not isinstance(bindings, dict) or not CORE <= set(bindings)
            or not set(bindings) <= CORE | set(BODY_BINDINGS) | {"visual_intent", "caption_intent", "untimed_visual_intent", "visual_amendment", "question_case_amendment", "literal_asset_uses"}):
        raise ValueError("complete caller-pinned source bundle required")
    if "caption_intent" in bindings:
        _same(bindings["caption_intent"], _CAPTION_PLAN_BINDING, "caption source must bind the exact frozen v2 plan")
    if "untimed_visual_intent" in bindings:
        if "caption_intent" not in bindings:
            raise ValueError("untimed visual intent requires the frozen caption plan")
        _same(bindings["untimed_visual_intent"], _UNTIMED_VISUAL_PLAN_BINDING,
              "untimed visual source must bind the exact frozen v2 plan")
    if "visual_amendment" in bindings:
        if not {"untimed_visual_intent", "caption_intent"} <= set(bindings):
            raise ValueError("visual amendment requires its frozen historical visual and caption plans")
        _same(bindings["visual_amendment"], _VISUAL_AMENDMENT_BINDING,
              "visual amendment must bind the exact frozen projection")
    if "question_case_amendment" in bindings:
        if not {"visual_amendment", "untimed_visual_intent", "caption_intent"} <= set(bindings):
            raise ValueError("case amendment requires its historical V3, V2 and caption bindings")
        _same(bindings["question_case_amendment"], _question_case.PROJECTION_BINDING,
              "question case amendment must bind the exact frozen V5 projection")
    if set(BODY_BINDINGS) & set(bindings):
        if not (set(BODY_BINDINGS) | {"question_case_amendment", "visual_amendment", "untimed_visual_intent", "caption_intent"}) <= set(bindings):
            raise ValueError("body amendment requires its complete V6/evidence/staging trio and historical V5/V3/V2/caption chain")
        for key, expected in BODY_BINDINGS.items():
            _same(bindings[key], expected, "body amendment must bind the exact external V6 staging chain")
    if "literal_asset_uses" in bindings:
        if not {"caption_intent", "untimed_visual_intent", "visual_amendment"} <= set(bindings):
            raise ValueError("literal asset uses require frozen captions, V2 and visual amendment")
        if "body_case_amendment" in bindings:
            from .phase6_av_asset_use_binding_v3 import validate_binding as validator
        else:
            validator = (_question_uses.validate_binding if "question_case_amendment" in bindings
                         else _validate_asset_use_binding)
        validator(bindings["literal_asset_uses"])
    # Caption metadata is consumed by its allowlisted adapter only AFTER A's
    # literal/PCM verification. Its source flag cannot supply verified units.
    data = {key: reader.load(value) for key, value in bindings.items()
            if key not in set(BODY_BINDINGS) | {"caption_intent", "untimed_visual_intent", "visual_amendment", "question_case_amendment", "literal_asset_uses"}}
    rec, inv, diag = (data[k] for k in ("reconciliation", "inventory", "diagnostic"))
    plan, voice, script, protocol, treatment = (data[k] for k in (
        "take_plan", "voice_manifest", "narrative_script", "protocol", "treatment"))
    for value, schema in ((plan, "take_plan.schema.json"),
                          (diag["plan"], "phase6_narration_unit_plan.schema.json"),
                          (inv, "phase6_narration_audio_inventory.schema.json")):
        reader.schema(value, schema)
    _receipt_id(rec, "reconciliation_id", "narration-pcm-reconciliation-")
    _receipt_id(inv, "inventory_id", "narration-audio-inventory-")
    if rec.get("status") != "COMPLETE_PCM_SET_NOT_RETIMED_OR_QUALITY_APPROVED":
        raise ValueError("reconciliation is not a complete captured set")
    if rec.get("schema_version") != "1.0.0" or any(v is not False for v in rec["authority"].values()):
        raise ValueError("reconciliation version or authority differs")
    _same(rec["inventory"], bindings["inventory"], "inventory binding differs")
    for key in ("diagnostic", "protocol", "treatment"):
        _same(inv["sources"][key], bindings[key], "inventory source differs")
    _same(diag["source_files"][:3], [bindings[k] for k in (
        "take_plan", "voice_manifest", "narrative_script")], "historical sources differ")
    verify_narration_unit_plan(diag["plan"], plan, voice)
    if rec["voice_contract_sha256"] != canonical_sha(inv["voice_contract"]):
        raise ValueError("reconciled voice contract differs")
    for key, value in diag["plan"]["voice_contract"].items():
        _same(inv["voice_contract"][key], value, "voice provenance differs")
    for key in ("channel_id", "video_id", "take_plan_id"):
        _same(inv[key], plan[key], "channel/video/plan differs")
    if (plan["channel_id"] != "UCuMF6pJQkyMzaVoAxFL86yA"
            or plan["video_id"] != "phase6-video-002-prepublication"
            or inv["protocol_id"] != protocol["protocol_id"]
            or protocol["channel_id"] != plan["channel_id"]
            or protocol["status"] != "PREREGISTERED"
            or protocol["treatment"]["variable"] != "TOPIC_ANGLE"
            or treatment["variable"] != "TOPIC_ANGLE"
            or not {"voice", "duration_band", "release_gates"}.issubset(protocol["treatment"]["control_lock"])
            or voice["voice_id"] != "am_onyx" or script["language"] != "en-US"):
        raise ValueError("F6 channel, language, experiment or voice lock differs")
    bands = [re.fullmatch(r"(\d+)–(\d+) ms duration band for a new long-form treatment", x)
             for x in treatment["locked_constants"]]
    bands = [[int(m[1]), int(m[2])] for m in bands if m]
    if bands != [[207750, 286250]] or rec["duration_band_ms"] != bands[0] or inv["duration_band_ms"] != bands[0]:
        raise ValueError("exact protocol duration band differs")
    # Rehash frozen capture/journal/code observations, without importing a QA
    # runner, loading the synthesis model or reexecuting any historical effect.
    seen = set()
    for binding in rec["file_bindings"]:
        if binding["path"] in seen:
            raise ValueError("duplicate reconciliation dependency")
        seen.add(binding["path"])
        raw = reader.read(binding["path"], binding["sha256"])
        if len(raw) != integer(binding["size_bytes"], "dependency size"):
            raise ValueError("reconciliation dependency size differs")
    return data


def _literal_pcm(reader, data):
    rec, inv, unit_plan, plan, script = (data["reconciliation"], data["inventory"],
        data["diagnostic"]["plan"], data["take_plan"], data["narrative_script"])
    if len(rec["units"]) != 51 or len(inv["units"]) != 51 or len(plan["takes"]) != 90 or len(unit_plan["units"]) != 51:
        raise ValueError("exact 51 units / 90 fragments required")
    units, fragments, paths = [], [], set()
    take_cursor = script_cursor = 0
    for index, (unit, historical, planned) in enumerate(zip(rec["units"], inv["units"], unit_plan["units"], strict=True)):
        uid = f"narration-unit-{index + 1:03d}"
        if unit["unit_id"] != uid or historical["unit_id"] != uid or planned["unit_id"] != uid:
            raise ValueError("unit order or identity differs")
        for key in ("take_ids", "text", "text_sha256", "speed", "synthesis_identity_sha256", "source_window_ms"):
            _same(unit[key], historical[key], "captured unit provenance differs")
        for key in ("take_ids", "text", "text_sha256"):
            _same(unit[key], planned[key], "original narration grouping differs")
        _same(unit["source_window_ms"], [planned["window_start_ms"], planned["window_end_ms"]],
              "original narration window differs")
        _same(unit["speed"], planned["pinned_speed"], "pinned speed differs")
        if (unit["voice_id"] != "am_onyx" or planned["review_issues"]
                or unit["quality_status"] != "NOT_APPROVED" or unit["word_alignment"] is not None
                or unit["text_sha256"] != bytes_sha(unit["text"].encode("utf-8"))):
            raise ValueError("unit copy, review or voice differs")
        synthesis = {"text": unit["text"], "voice_contract": inv["voice_contract"],
                     "speed": unit["speed"], "output": "MONO_24000_PCM16_WHOLE_UTTERANCE"}
        if canonical_sha(synthesis) != unit["synthesis_identity_sha256"]:
            raise ValueError("synthesis identity does not recompose")
        raw = reader.read(unit["path"], unit["sha256"])
        resolved = (reader.root / unit["path"]).resolve(strict=True)
        if resolved in paths:
            raise ValueError("duplicate PCM assignment")
        paths.add(resolved)
        measured = inspect_pcm(raw)
        _same(measured, {k: unit[k] for k in measured}, "PCM bytes, frame count or measurements differ")
        if measured["clipping_samples"]:
            raise ValueError("clipped PCM cannot enter temporal plan")
        if historical["audio"] is not None:
            _same({"path": unit["path"], **measured}, historical["audio"], "available historical PCM changed")
        local = 0
        for take_id in unit["take_ids"]:
            if take_cursor >= 90:
                raise ValueError("excess fragment membership")
            take = plan["takes"][take_cursor]
            if take_id != take["take_id"] or take_id != f"take-{take_cursor + 1:03d}":
                raise ValueError("fragment order, omission or duplication")
            text = take["narration"]
            if unit["text"][local:local + len(text)] != text or script["full_text"][script_cursor:script_cursor + len(text)] != text:
                raise ValueError("literal fragment does not match frozen copy")
            fragments.append({"take_id": take_id, "unit_id": uid, "text": text,
                "text_sha256": bytes_sha(text.encode("utf-8")), "unit_start_char": local,
                "unit_end_char": local + len(text), "script_start_char": script_cursor,
                "script_end_char": script_cursor + len(text)})
            local += len(text) + 1
            script_cursor += len(text) + 1
            take_cursor += 1
        if local - 1 != len(unit["text"]):
            raise ValueError("unit contains extra literal text")
        units.append({**copy.deepcopy(unit), "wav_sha256": unit["sha256"]})
    if take_cursor != 90 or script_cursor - 1 != len(script["full_text"]) or " ".join(u["text"] for u in units) != script["full_text"]:
        raise ValueError("full literal script coverage differs")
    if [u["source_window_ms"] for u in units[:3]] != [[0, 1000], [1000, 3000], [3000, 8000]]:
        raise ValueError("locked historical hooks differ")
    return units, fragments


def _tails(envelope, units):
    policy = envelope["policy"]
    if (policy["id"] != "pcm-rms-envelope-v1" or policy["window_samples"] != 240
            or policy["sample_rate"] != RATE or policy["levels_dbfs"] != [-45, -40, -35]):
        raise ValueError("acoustic energy policy differs")
    if len(envelope["records"]) != 51:
        raise ValueError("incomplete acoustic observations")
    result = []
    for unit, record in zip(units, envelope["records"], strict=True):
        if (record["unit_id"] != unit["unit_id"] or record["pcm_sha256"] != unit["pcm_sha256"]
                or record["wav_sha256"] != unit["sha256"] or record["sample_count"] != unit["frame_count"]):
            raise ValueError("acoustic observation belongs to another PCM")
        levels = {}
        for row in record["threshold_measurements"]:
            level = row["level_dbfs"]
            if level in levels or level not in (-45, -40, -35):
                raise ValueError("acoustic sensitivity levels differ")
            first = integer(row["first_active_sample"], "first active")
            last = integer(row["last_active_sample_exclusive"], "last active", 1)
            if (not first < last <= unit["frame_count"] or row["leading_below_threshold_samples"] != first
                    or row["trailing_below_threshold_samples"] != unit["frame_count"] - last
                    or row["status"] != "ACTIVITY_MEASURED_NOT_WORD_ALIGNMENT"):
                raise ValueError("acoustic bounds do not recompose")
            levels[level] = (first, unit["frame_count"] - last)
        if set(levels) != {-45, -40, -35}:
            raise ValueError("incomplete energy sensitivity observations")
        result.append(levels)
    return [min(row[level][1] + (result[i + 1][level][0] if i + 1 < 51 else 0)
                for level in (-45, -40, -35)) for i, row in enumerate(result)]


def _place(units, tails, decisions, blockers, input_hash):
    decisions_by_id = {}
    for decision in decisions:
        exact(decision, "after_unit_id before_unit_id function literal_anchor rationale target_low_energy_samples evidence_bindings", "pause")
        uid = decision["after_unit_id"]
        if uid in decisions_by_id or uid not in {u["unit_id"] for u in units[3:]}:
            raise ValueError("pause duplicated or changes locked hooks")
        decisions_by_id[uid] = decision
    placed, gaps, pauses, cursor = [], [], [], 0
    for index, unit in enumerate(units):
        start = cursor
        pcm_end = start + unit["frame_count"]
        if index < 3:
            end = (24000, 72000, 192000)[index]
            if pcm_end > end:
                raise ValueError("whole hook PCM exceeds fixed slot")
            if pcm_end < end:
                gaps.append({"start_sample": pcm_end, "end_sample_exclusive": end,
                    "reason": "LOCKED_HOOK_PAD", "evidence_ref": input_hash})
        else:
            mechanical = (-unit["frame_count"]) % GRID
            decision = decisions_by_id.get(unit["unit_id"])
            extra = 0
            if decision is None:
                blockers.append("PAUSE_DECISION_MISSING:" + unit["unit_id"])
            else:
                before = units[index + 1]["unit_id"] if index + 1 < 51 else None
                if decision["before_unit_id"] != before:
                    raise ValueError("pause neighbor differs")
                function = decision["function"]
                if function not in {"NONE", "COMPREHENSION", "EMPHASIS", "SCENE_TRANSITION", "READ_VISUAL", "CLOSURE"}:
                    raise ValueError("unknown editorial pause function")
                target = integer(decision["target_low_energy_samples"], "pause target")
                if function == "NONE":
                    if target:
                        raise ValueError("NONE cannot insert editorial silence")
                else:
                    if nonempty(decision["literal_anchor"], "pause anchor") not in unit["text"]:
                        raise ValueError("pause anchor differs from literal narration")
                    nonempty(decision["rationale"], "pause rationale")
                    if not decision["evidence_bindings"]:
                        blockers.append("PAUSE_EVIDENCE_MISSING:" + unit["unit_id"])
                extra = ((max(0, target - tails[index] - mechanical) + GRID - 1) // GRID) * GRID
                pauses.append({**copy.deepcopy(decision), "observed_low_energy_samples": tails[index],
                    "mechanical_pad_samples": mechanical, "editorial_added_samples": extra,
                    "measurement_class": "ENERGY_CONTEXT_NOT_WORD_TIMING"})
            end = pcm_end + mechanical + extra
            if mechanical:
                gaps.append({"start_sample": pcm_end, "end_sample_exclusive": pcm_end + mechanical,
                    "reason": "MECHANICAL_GRID_PAD", "evidence_ref": input_hash})
            if extra:
                gaps.append({"start_sample": pcm_end + mechanical, "end_sample_exclusive": end,
                    "reason": "EDITORIAL_PAUSE", "evidence_ref": canonical_sha(decision)})
        if start % GRID or end % GRID:
            raise ValueError("unit slot outside 100 ms grid")
        placed.append({**copy.deepcopy(unit), "slot_start_sample": start, "pcm_start_sample": start,
            "pcm_end_sample_exclusive": pcm_end, "slot_end_sample_exclusive": end})
        cursor = end
    if not 207800 * 24 <= cursor <= 286200 * 24:
        blockers.append("DURATION_OUTSIDE_PROTOCOL_GRID_BAND")
    return placed, gaps, pauses, cursor


def _profile(value):
    exact(value, "method version model_sha256 voice_id language sample_rate", "temporal profile")
    if value["voice_id"] != "am_onyx" or value["language"] != "en-US" or value["sample_rate"] != RATE:
        raise ValueError("temporal profile is not applicable to this voice/language/rate")
    for key in ("method", "version"):
        nonempty(value[key], key)
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", value["model_sha256"]):
        raise ValueError("temporal model hash missing")


def _evidence_class(value, name):
    evidence_class = value.get("evidence_class")
    if evidence_class not in {"FIXTURE", "LIVE"}:
        raise ValueError(f"{name}: explicit FIXTURE or LIVE evidence class required")
    return evidence_class


def _read_binary_binding(reader, binding, name):
    exact(binding, "path sha256", name)
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", binding["sha256"]):
        raise ValueError(f"{name}: SHA-256 binding required")
    raw = reader.read(binding["path"], binding["sha256"])
    if not raw:
        raise ValueError(f"{name}: empty source")
    return raw


def _read_support_bindings(reader, bindings, name):
    if not isinstance(bindings, list) or not bindings:
        raise ValueError(f"{name}: at least one supporting source required")
    paths = set()
    for binding in bindings:
        _read_binary_binding(reader, binding, name)
        if binding["path"] in paths:
            raise ValueError(f"{name}: duplicate supporting source")
        paths.add(binding["path"])


def _bound_pcm(reader, binding, name):
    return inspect_pcm(_read_binary_binding(reader, binding, name))


def _model_and_implementation(reader, profile, model_binding, implementation_binding, name):
    model = _read_binary_binding(reader, model_binding, name + " model")
    implementation = _read_binary_binding(reader, implementation_binding, name + " implementation")
    if model_binding["sha256"] != profile["model_sha256"] or not model or not implementation:
        raise ValueError(f"{name}: model or implementation provenance differs")


def _utc_timestamp(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name}: timezone-aware timestamp required")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{name}: invalid timestamp") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{name}: timezone-aware timestamp required")
    return parsed.astimezone(timezone.utc)


def _temporal_policy(reader, policy, policy_binding, policy_id, profile, evidence_class):
    if policy is None:
        return None
    exact(policy, "kind schema_version policy_version policy_id evidence_class registered_at profile acceptance provenance_bindings", "calibration policy")
    if (policy["kind"] != "TEMPORAL_CALIBRATION_POLICY"
            or policy["schema_version"] != "1.0.0"
            or policy["policy_version"] != "phase6-temporal-calibration-policy-v1"):
        raise ValueError("calibration policy class differs")
    _receipt_id(policy, "policy_id", "temporal-policy-")
    if policy["policy_id"] != policy_id:
        raise ValueError("root-pinned calibration policy identity differs")
    _same(policy["profile"], profile, "calibration policy profile differs")
    if _evidence_class(policy, "calibration policy") != evidence_class:
        raise ValueError("calibration policy evidence class differs")
    registered_at = _utc_timestamp(policy["registered_at"], "calibration policy registered_at")
    _read_support_bindings(reader, policy["provenance_bindings"], "calibration policy provenance")
    acceptance = policy["acceptance"]
    exact(acceptance, "minimum_holdout_count minimum_coverage maximum_absolute_error_samples", "calibration policy acceptance")
    minimum = integer(acceptance["minimum_holdout_count"], "holdout floor", 1)
    limit = integer(acceptance["maximum_absolute_error_samples"], "calibration error limit")
    coverage = acceptance["minimum_coverage"]
    if isinstance(coverage, bool) or not isinstance(coverage, (int, float)) or not 0 < coverage <= 1:
        raise ValueError("invalid calibration coverage")
    return {"minimum": minimum, "coverage": coverage, "limit": limit,
            "policy_id": policy["policy_id"], "policy_sha256": policy_binding["sha256"],
            "registered_at": registered_at}


def _holdout_measurements(reader, calibration, policy, profile, evidence_class,
                          target_unit, voice_population):
    minimum, coverage, limit = policy["minimum"], policy["coverage"], policy["limit"]
    calibration_observed_at = _utc_timestamp(calibration["observed_at"], "calibration observed_at")
    if calibration_observed_at < policy["registered_at"]:
        raise ValueError("calibration predates its root-pinned policy")
    rows = calibration["observations"]
    if not isinstance(rows, list):
        raise ValueError("calibration observations must be an array")
    seen_ids, seen_pcm_paths, seen_pcm_hashes, covered, errors = set(), set(), set(), 0, []
    for row in rows:
        exact(row, "observation_id split pcm_binding voice_origin reference_binding estimate_binding", "holdout observation")
        observation_id = nonempty(row["observation_id"], "holdout observation id")
        if observation_id in seen_ids or row["split"] != "HOLDOUT":
            raise ValueError("duplicate or non-holdout calibration observation")
        seen_ids.add(observation_id)
        measured = _bound_pcm(reader, row["pcm_binding"], "holdout PCM")
        resolved = (reader.root / row["pcm_binding"]["path"]).resolve(strict=True)
        if (resolved in seen_pcm_paths or measured["pcm_sha256"] in seen_pcm_hashes
                or measured["pcm_sha256"] == target_unit["pcm_sha256"]):
            raise ValueError("duplicate or target-leaking holdout PCM")
        seen_pcm_paths.add(resolved)
        seen_pcm_hashes.add(measured["pcm_sha256"])

        # A temporal profile naming am_onyx is not evidence that the holdout
        # audio came from that voice.  Bind every calibration PCM back to a
        # fully re-opened reconciliation unit whose synthesis identity was
        # already recomputed from the frozen model/voice-bank/adapter contract.
        # This deliberately admits no free-standing, self-described PCM.
        origin = row["voice_origin"]
        exact(origin, "kind unit_id voice_id language speed voice_contract_sha256 synthesis_identity_sha256",
              "holdout voice origin")
        if origin["kind"] != "RECONCILED_NARRATION_UNIT":
            raise ValueError("unsupported holdout voice origin")
        source_unit = voice_population["units"].get(origin["unit_id"])
        if source_unit is None:
            raise ValueError("holdout voice origin is outside reconciled population")
        if source_unit["unit_id"] in voice_population["target_unit_ids"]:
            raise ValueError("holdout PCM leaks full temporal target union")
        _same(row["pcm_binding"], {"path": source_unit["path"], "sha256": source_unit["sha256"]},
              "holdout PCM differs from reconciled voice origin")
        if (measured["pcm_sha256"] != source_unit["pcm_sha256"]
                or measured["frame_count"] != source_unit["frame_count"]
                or measured["sample_rate"] != source_unit["sample_rate"]):
            raise ValueError("holdout PCM measurements differ from reconciled voice origin")
        expected_origin = {"kind": "RECONCILED_NARRATION_UNIT",
            "unit_id": source_unit["unit_id"], "voice_id": source_unit["voice_id"],
            "language": voice_population["language"], "speed": source_unit["speed"],
            "voice_contract_sha256": voice_population["voice_contract_sha256"],
            "synthesis_identity_sha256": source_unit["synthesis_identity_sha256"]}
        _same(origin, expected_origin, "holdout voice origin differs")
        if (source_unit["voice_id"] != profile["voice_id"]
                or voice_population["language"] != profile["language"]
                or source_unit["sample_rate"] != profile["sample_rate"]
                or source_unit["speed"] != target_unit["speed"]):
            raise ValueError("holdout synthesis conditions are not applicable to target")

        reference = reader.load(row["reference_binding"])
        exact(reference, "kind schema_version receipt_id evidence_class observed_at observation_id pcm_binding pcm_sha256 sample_rate frame_count reference_sample reference_method source_bindings", "reference receipt")
        if reference["kind"] != "TEMPORAL_REFERENCE_OBSERVATION" or reference["schema_version"] != "1.0.0":
            raise ValueError("reference receipt class differs")
        _receipt_id(reference, "receipt_id", "temporal-reference-")
        if (_evidence_class(reference, "reference receipt") != evidence_class
                or reference["observation_id"] != observation_id):
            raise ValueError("reference receipt identity or evidence class differs")
        _same(reference["pcm_binding"], row["pcm_binding"], "reference PCM binding differs")
        if (reference["pcm_sha256"] != measured["pcm_sha256"]
                or reference["sample_rate"] != measured["sample_rate"]
                or reference["frame_count"] != measured["frame_count"]):
            raise ValueError("reference receipt PCM measurements differ")
        reference_sample = integer(reference["reference_sample"], "reference sample")
        if reference_sample > measured["frame_count"]:
            raise ValueError("reference sample is outside holdout PCM")
        # A frozen annotation/dataset may legitimately predate preregistration;
        # it only needs to exist by the calibration evaluation.  The estimate,
        # separately timestamped below, must not predate the policy.
        if _utc_timestamp(reference["observed_at"], "reference observed_at") > calibration_observed_at:
            raise ValueError("reference observation postdates calibration")
        method = reference["reference_method"]
        exact(method, "kind version", "reference method")
        nonempty(method["version"], "reference method version")
        allowed = ({"SYNTHETIC_FIXTURE"} if evidence_class == "FIXTURE"
                   else {"HUMAN_GOLD_STANDARD", "VERIFIED_ANNOTATED_DATASET"})
        if method["kind"] not in allowed:
            raise ValueError("reference method is incompatible with evidence class")
        _read_support_bindings(reader, reference["source_bindings"], "reference provenance")

        estimate = reader.load(row["estimate_binding"])
        exact(estimate, "kind schema_version receipt_id evidence_class observed_at policy_id policy_sha256 observation_id pcm_binding pcm_sha256 sample_rate frame_count profile expected_text_used estimate_sample lower_sample upper_sample model_binding implementation_binding", "estimate receipt")
        if estimate["kind"] != "TEMPORAL_ESTIMATE_OBSERVATION" or estimate["schema_version"] != "1.0.0":
            raise ValueError("estimate receipt class differs")
        _receipt_id(estimate, "receipt_id", "temporal-estimate-")
        if (_evidence_class(estimate, "estimate receipt") != evidence_class
                or estimate["observation_id"] != observation_id):
            raise ValueError("estimate receipt identity or evidence class differs")
        if (estimate["policy_id"] != policy["policy_id"]
                or estimate["policy_sha256"] != policy["policy_sha256"]):
            raise ValueError("estimate root-pinned policy binding differs")
        estimate_observed_at = _utc_timestamp(estimate["observed_at"], "estimate observed_at")
        if not policy["registered_at"] <= estimate_observed_at <= calibration_observed_at:
            raise ValueError("estimate is outside preregistered policy interval")
        _same(estimate["pcm_binding"], row["pcm_binding"], "estimate PCM binding differs")
        _same(estimate["profile"], profile, "estimate profile differs")
        if (estimate["pcm_sha256"] != measured["pcm_sha256"]
                or estimate["sample_rate"] != measured["sample_rate"]
                or estimate["frame_count"] != measured["frame_count"]):
            raise ValueError("estimate receipt PCM measurements differ")
        if type(estimate["expected_text_used"]) is not bool:
            raise ValueError("estimate transcript policy type differs")
        if profile["method"] == "ASR" and estimate["expected_text_used"]:
            raise ValueError("independent ASR calibration cannot receive expected text")
        _model_and_implementation(reader, profile, estimate["model_binding"],
                                  estimate["implementation_binding"], "estimate receipt")
        estimate_sample, lower, upper = [integer(estimate[key], key) for key in (
            "estimate_sample", "lower_sample", "upper_sample")]
        if not lower <= estimate_sample <= upper <= measured["frame_count"]:
            raise ValueError("estimate interval is outside holdout PCM")
        errors.append(abs(reference_sample - estimate_sample))
        covered += lower <= reference_sample <= upper
    if len(rows) < minimum or not rows or covered / len(rows) < coverage or max(errors) > limit:
        return False, limit
    return True, limit


def _alignment(reader, evidence, temporal_policy, temporal_policy_binding, evidence_id, unit,
               char_start, char_end, tolerance, blockers, evidence_usage, voice_population):
    """Return relative uncertainty intervals, not a generated point estimate."""
    if not isinstance(voice_population, dict) or voice_population.get("scope_complete") is not True:
        blockers.append("TEMPORAL_TARGET_SCOPE_INCOMPLETE")
        return None
    if evidence_id is None or evidence_id not in evidence:
        blockers.append("TEMPORAL_EVIDENCE_MISSING:" + unit["unit_id"])
        return None
    alignment = evidence[evidence_id]
    if alignment.get("kind") != "CALIBRATED_ALIGNMENT":
        blockers.append("TEMPORAL_EVIDENCE_NOT_CALIBRATED:" + evidence_id)
        return None
    exact(alignment, "kind schema_version evidence_class profile unit_id pcm_binding pcm_sha256 text_sha256 expected_text_used calibration_id acoustic_reference_id model_binding implementation_binding segments", "alignment")
    if alignment["schema_version"] != "1.0.0":
        raise ValueError("alignment schema version differs")
    _profile(alignment["profile"])
    evidence_class = _evidence_class(alignment, "alignment")
    if (alignment["unit_id"] != unit["unit_id"] or alignment["pcm_sha256"] != unit["pcm_sha256"]
            or alignment["text_sha256"] != unit["text_sha256"]):
        raise ValueError("alignment is bound to another unit/PCM/copy")
    _same(alignment["pcm_binding"], {"path": unit["path"], "sha256": unit["sha256"]},
          "alignment target PCM binding differs")
    measured_target = _bound_pcm(reader, alignment["pcm_binding"], "alignment target PCM")
    if measured_target["pcm_sha256"] != unit["pcm_sha256"] or measured_target["frame_count"] != unit["frame_count"]:
        raise ValueError("alignment target PCM measurements differ")
    _model_and_implementation(reader, alignment["profile"], alignment["model_binding"],
                              alignment["implementation_binding"], "target alignment")
    if type(alignment["expected_text_used"]) is not bool:
        raise ValueError("alignment transcript policy type differs")
    if alignment["profile"]["method"] == "ASR" and alignment["expected_text_used"]:
        raise ValueError("independent ASR cannot receive expected text")
    # Forced alignment legitimately uses frozen text; it never proves wording.
    calibration = evidence.get(alignment["calibration_id"])
    acoustic = evidence.get(alignment["acoustic_reference_id"])
    if calibration is None or acoustic is None:
        blockers.append("CALIBRATION_OR_ACOUSTIC_REFERENCE_MISSING:" + evidence_id)
        return None
    exact(calibration, "kind schema_version evidence_class observed_at profile policy_id observations", "calibration")
    if calibration["kind"] != "TEMPORAL_CALIBRATION" or calibration["schema_version"] != "1.0.0":
        raise ValueError("wrong calibration class")
    _same(calibration["profile"], alignment["profile"], "calibration profile differs")
    if _evidence_class(calibration, "calibration") != evidence_class:
        raise ValueError("calibration evidence class differs")
    policy = _temporal_policy(reader, temporal_policy, temporal_policy_binding,
                              calibration["policy_id"], alignment["profile"], evidence_class)
    if policy is None:
        blockers.append("CALIBRATION_POLICY_MISSING:" + evidence_id)
        return None
    accepted, limit = _holdout_measurements(reader, calibration, policy,
        alignment["profile"], evidence_class, unit, voice_population)
    if not accepted or limit > tolerance:
        blockers.append("CALIBRATION_ACCEPTANCE_FAILED:" + evidence_id)
        return None
    exact(acoustic, "kind schema_version evidence_class pcm_binding pcm_sha256 text_sha256 profile observation_binding", "acoustic reference")
    if acoustic["kind"] != "INDEPENDENT_BOUNDARY_OBSERVATIONS" or acoustic["schema_version"] != "1.0.0":
        raise ValueError("independent acoustic reference class differs")
    _profile(acoustic["profile"])
    if (_evidence_class(acoustic, "acoustic reference") != evidence_class
            or acoustic["pcm_sha256"] != unit["pcm_sha256"]
            or acoustic["text_sha256"] != unit["text_sha256"]
            or acoustic["profile"]["method"] == alignment["profile"]["method"]
            or acoustic["profile"]["model_sha256"] == alignment["profile"]["model_sha256"]):
        raise ValueError("independent acoustic reference binding differs")
    _same(acoustic["pcm_binding"], alignment["pcm_binding"], "acoustic target PCM binding differs")
    acoustic_pcm = _bound_pcm(reader, acoustic["pcm_binding"], "acoustic target PCM")
    if acoustic_pcm["pcm_sha256"] != unit["pcm_sha256"] or acoustic_pcm["frame_count"] != unit["frame_count"]:
        raise ValueError("acoustic target PCM measurements differ")
    observation = reader.load(acoustic["observation_binding"])
    exact(observation, "kind schema_version receipt_id evidence_class profile pcm_binding pcm_sha256 text_sha256 model_binding implementation_binding source_bindings segments", "acoustic observation receipt")
    if observation["kind"] != "INDEPENDENT_BOUNDARY_OBSERVATION" or observation["schema_version"] != "1.0.0":
        raise ValueError("acoustic observation receipt class differs")
    _receipt_id(observation, "receipt_id", "temporal-acoustic-observation-")
    if _evidence_class(observation, "acoustic observation receipt") != evidence_class:
        raise ValueError("acoustic observation evidence class differs")
    for key in ("profile", "pcm_binding", "pcm_sha256", "text_sha256"):
        _same(observation[key], acoustic[key], "acoustic observation receipt differs")
    _model_and_implementation(reader, acoustic["profile"], observation["model_binding"],
                              observation["implementation_binding"], "acoustic observation")
    _read_support_bindings(reader, observation["source_bindings"], "acoustic observation provenance")
    segments = observation["segments"]
    selected = []
    for row in alignment["segments"]:
        exact(row, "char_start char_end start_lower_sample start_upper_sample end_lower_sample end_upper_sample", "alignment segment")
        values = [integer(row[k], k) for k in ("char_start", "char_end", "start_lower_sample", "start_upper_sample", "end_lower_sample", "end_upper_sample")]
        a, b, sl, su, el, eu = values
        if not (a < b <= len(unit["text"]) and sl <= su < el <= eu <= unit["frame_count"]):
            raise ValueError("alignment segment bounds differ")
        if a == char_start and b == char_end:
            selected.append(row)
    if len(selected) != 1:
        blockers.append("ALIGNED_TEXT_RANGE_MISSING_OR_DUPLICATE:" + evidence_id)
        return None
    row = selected[0]
    references = [x for x in segments if x.get("char_start") == char_start and x.get("char_end") == char_end]
    if len(references) != 1:
        blockers.append("ACOUSTIC_RANGE_MISSING:" + evidence_id)
        return None
    reference = references[0]
    exact(reference, "char_start char_end start_sample end_sample", "acoustic range")
    rs, re_ = integer(reference["start_sample"], "reference start"), integer(reference["end_sample"], "reference end", 1)
    if not 0 <= rs < re_ <= unit["frame_count"]:
        raise ValueError("acoustic reference outside PCM")
    if (not row["start_lower_sample"] <= rs <= row["start_upper_sample"]
            or not row["end_lower_sample"] <= re_ <= row["end_upper_sample"]
            or max(row["start_upper_sample"] - row["start_lower_sample"], row["end_upper_sample"] - row["end_lower_sample"]) > tolerance):
        blockers.append("ACOUSTIC_CONTRAPROOF_OR_UNCERTAINTY_FAILED:" + evidence_id)
        return None
    prior = evidence_usage.setdefault(evidence_id, evidence_class)
    if prior != evidence_class:
        raise ValueError("alignment evidence class changed between uses")
    if evidence_class == "FIXTURE":
        blockers.append("TEMPORAL_EVIDENCE_FIXTURE_ONLY:" + evidence_id)
    return row


def _validate_unit_boundary(requirement, event, intent_version, units, span):
    """Structural PCM edge only; no phoneme/word/onset timing is inferred."""
    exact(requirement, "event_id span_id kind narrative_function unit_id char_start char_end trigger maximum_uncertainty_samples", "unit boundary requirement")
    exact(event, "event_id frame alignment_id", "unit boundary event")
    if intent_version not in {"1.1.0", "1.2.0"}:
        raise ValueError("unit boundary requires visual intent 1.1.0 or 1.2.0")
    if requirement["kind"] != "UNIT_BOUNDARY" or requirement["trigger"] != "WHOLE_UNIT_PCM_START":
        raise ValueError("unit boundary kind/trigger pair differs; lexical intent cannot be reclassified")
    nonempty(requirement["narrative_function"], "unit boundary narrative function")
    if (any(requirement[key] is not None for key in ("char_start", "char_end", "maximum_uncertainty_samples"))
            or event["alignment_id"] is not None or event["event_id"] != requirement["event_id"]):
        raise ValueError("unit boundary cannot claim lexical range, uncertainty or alignment")
    uid = nonempty(requirement["unit_id"], "unit boundary unit")
    unit = units.get(uid)
    if unit is None:
        raise ValueError("unit boundary references unknown unit")
    start = integer(unit["pcm_start_sample"], "unit boundary PCM start")
    frame = integer(event["frame"], "unit boundary frame")
    if start % FRAME or frame * FRAME != start:
        raise ValueError("unit boundary frame must equal exact whole PCM start")
    if (span is None or span.get("span_id") != requirement["span_id"]
            or not integer(span["start_frame"], "unit boundary span start") <= frame
            < integer(span["end_frame"], "unit boundary span end", 1)
            or not unit["take_ids"] or unit["take_ids"][0] not in span["fragment_ids"]):
        raise ValueError("unit boundary span must contain PCM start and first literal fragment")


def _visual(reader, data, spans, events, units, total, evidence, temporal_policy,
            temporal_policy_binding, blockers, evidence_usage, voice_population, *, static_proof_sink=None):
    intent = data.get("visual_intent")
    if intent is None:
        blockers.append("VISUAL_INTENT_NOT_BOUND")
        if spans or events:
            raise ValueError("visual scheduling requires a pinned narrative intent")
        return [], [], []
    exact(intent, "schema_version take_plan_sha256 script_sha256 span_contracts event_requirements", "visual intent")
    if intent["schema_version"] not in {"1.0.0", "1.1.0", "1.2.0"} or intent["take_plan_sha256"] != canonical_sha(data["take_plan"]) or intent["script_sha256"] != canonical_sha(data["narrative_script"]):
        raise ValueError("visual intent belongs to another baseline")
    contracts = intent["span_contracts"]
    if len({x["span_id"] for x in contracts}) != len(contracts):
        raise ValueError("duplicate visual span contract")
    static_proofs = _static_intent(reader, intent, units, spans)
    if static_proof_sink is not None:
        static_proof_sink.extend(static_proofs.values())
    by_id = {x["span_id"]: x for x in contracts}
    fragment_units = {take: unit for unit in units for take in unit["take_ids"]}
    actual, cursor, seen, asset_lineages = [], 0, set(), {}
    for span in spans:
        exact(span, "span_id start_frame end_frame source_start_frame source_end_frame", "render span")
        sid = span["span_id"]
        if sid not in by_id or sid in seen:
            raise ValueError("unknown or duplicate render span")
        seen.add(sid)
        contract = by_id[sid]
        contract_keys = "span_id fragment_ids narrative_function semantic_alignment retention_job asset_binding source_frame_count lineage_id"
        if intent["schema_version"] == "1.2.0":
            contract_keys += " media_kind static_source"
        exact(contract, contract_keys, "span intent")
        ids = contract["fragment_ids"]
        if not ids or len(set(ids)) != len(ids) or any(x not in {f"take-{i:03d}" for i in range(1, 91)} for x in ids):
            raise ValueError("span fragment references differ")
        for key in ("narrative_function", "semantic_alignment", "retention_job", "lineage_id"):
            nonempty(contract[key], key)
        raw = reader.read(contract["asset_binding"]["path"], contract["asset_binding"]["sha256"])
        if not raw:
            raise ValueError("empty visual source")
        is_static = contract.get("media_kind") == "STATIC_IMAGE"
        if raw.startswith(b"\x89PNG\r\n\x1a\n") and not is_static:
            raise ValueError("PNG source requires explicit STATIC_IMAGE contract")
        digest = contract["asset_binding"]["sha256"]
        prior_lineage = asset_lineages.setdefault(digest, contract["lineage_id"])
        if prior_lineage != contract["lineage_id"]:
            raise ValueError("same visual bytes cannot claim different source lineages")
        start, end, a, b = [integer(span[k], k) for k in ("start_frame", "end_frame", "source_start_frame", "source_end_frame")]
        if start != cursor or not start < end <= total // FRAME or not 0 <= a < b <= integer(contract["source_frame_count"], "source frames", 1):
            raise ValueError("visual span gap, overlap, source overrun or time stretch")
        if is_static:
            if [a, b, contract["source_frame_count"]] != [0, 1, 1]:
                raise ValueError("static source must keep the real one-image interval")
        elif b - a != end - start:
            raise ValueError("video source time stretch is not authorized")
        for fragment_id in ids:
            unit = fragment_units[fragment_id]
            if not max(start * FRAME, unit["slot_start_sample"]) < min(end * FRAME, unit["slot_end_sample_exclusive"]):
                raise ValueError("visual fragment is outside its narration unit slot; no implicit recap")
        actual.append({**copy.deepcopy(span), **copy.deepcopy(contract)})
        cursor = end
    if cursor != total // FRAME or seen != set(by_id):
        blockers.append("RENDER_SPAN_COVERAGE_INCOMPLETE")
    if set(x for span in actual for x in span["fragment_ids"]) != {f"take-{i:03d}" for i in range(1, 91)}:
        blockers.append("VISUAL_FRAGMENT_COVERAGE_INCOMPLETE")
    requirements = intent["event_requirements"]
    expected = {x["event_id"]: x for x in requirements}
    if len(expected) != len(requirements):
        raise ValueError("duplicate creative event requirement")
    seen, output = set(), []
    placed = {x["unit_id"]: x for x in units}
    span_map = {x["span_id"]: x for x in actual}
    for event in events:
        exact(event, "event_id frame alignment_id", "visual event")
        eid = event["event_id"]
        if eid in seen or eid not in expected:
            raise ValueError("duplicate or undeclared event")
        seen.add(eid)
        req = expected[eid]
        exact(req, "event_id span_id kind narrative_function unit_id char_start char_end trigger maximum_uncertainty_samples", "event requirement")
        if req["kind"] not in {"HOLD", "NON_SEMANTIC_CUT", "SEMANTIC_CHANGE", "UNIT_BOUNDARY"}:
            raise ValueError("event kind differs")
        nonempty(req["narrative_function"], "event narrative function")
        span = span_map.get(req["span_id"])
        frame = integer(event["frame"], "event frame")
        if span is None or not span["start_frame"] <= frame < span["end_frame"]:
            raise ValueError("event outside its visual span")
        # The caller cannot reclassify an intent's semantic reveal as HOLD.
        if req["kind"] == "UNIT_BOUNDARY" or req["trigger"] == "WHOLE_UNIT_PCM_START":
            _validate_unit_boundary(req, event, intent["schema_version"], placed, span)
        elif req["trigger"] == "NO_SPEECH_DEPENDENCY":
            if req["kind"] == "SEMANTIC_CHANGE" or any(req[k] is not None for k in ("unit_id", "char_start", "char_end", "maximum_uncertainty_samples")) or event["alignment_id"] is not None:
                raise ValueError("semantic event cannot discard speech dependency")
        else:
            if req["trigger"] not in {"NOT_BEFORE_ANCHOR_START", "NOT_BEFORE_ANCHOR_END"}:
                raise ValueError("event trigger differs")
            unit = placed[req["unit_id"]]
            row = _alignment(reader, evidence, temporal_policy, temporal_policy_binding,
                event["alignment_id"], unit,
                integer(req["char_start"], "event text start"), integer(req["char_end"], "event text end", 1),
                integer(req["maximum_uncertainty_samples"], "event uncertainty"), blockers,
                evidence_usage, voice_population)
            if row is not None:
                key = "start_upper_sample" if req["trigger"] == "NOT_BEFORE_ANCHOR_START" else "end_upper_sample"
                earliest = unit["pcm_start_sample"] + row[key]
                if not earliest <= frame * FRAME <= earliest + req["maximum_uncertainty_samples"] + FRAME - 1:
                    blockers.append("SEMANTIC_EVENT_EARLY_OR_LATE:" + eid)
        output.append({**copy.deepcopy(req), **copy.deepcopy(event)})
    if seen != set(expected):
        blockers.append("VISUAL_EVENTS_INCOMPLETE")
        if static_proofs:
            blockers.append("TEMPORAL_STATIC_EVENTS_INCOMPLETE")
    verify_entry_frames(static_proofs, actual, output)
    return actual, output, [{"span_id": sid, "inspection_id": proof["inspection_id"],
                            "inspection_sha256": canonical_sha(proof)}
                           for sid, proof in static_proofs.items()]


def _captions(reader, cues, units, evidence, temporal_policy, temporal_policy_binding,
              blockers, evidence_usage, voice_population):
    by_id = {x["unit_id"]: x for x in units}
    output, seen, covered, last_end = [], set(), {x["unit_id"]: [] for x in units}, 0
    for cue in cues:
        exact(cue, "cue_id unit_id char_start char_end start_sample end_sample text lines timing_basis alignment_id maximum_uncertainty_samples", "caption")
        cid = nonempty(cue["cue_id"], "cue id")
        if cid in seen or cue["unit_id"] not in by_id:
            raise ValueError("duplicate cue or unknown utterance")
        seen.add(cid)
        unit = by_id[cue["unit_id"]]
        a, b, start, end = [integer(cue[k], k) for k in ("char_start", "char_end", "start_sample", "end_sample")]
        if not 0 <= a < b <= len(unit["text"]) or cue["text"] != unit["text"][a:b]:
            raise ValueError("caption literal range differs")
        if not last_end <= start < end or not unit["pcm_start_sample"] <= start < end <= unit["pcm_end_sample_exclusive"]:
            raise ValueError("caption overlaps, anticipates unit or escapes PCM")
        lines = cue["lines"]
        if (not isinstance(lines, list) or not 1 <= len(lines) <= 2
                or any(not isinstance(x, str) or not x or len(x) > 42 for x in lines)
                or " ".join(lines) != cue["text"] or len(cue["text"].split()) > 12):
            blockers.append("CAPTION_LEGIBILITY_FAILED:" + cid)
        if cue["timing_basis"] == "WHOLE_UNIT_PCM_BOUNDS":
            if (a != 0 or b != len(unit["text"]) or start != unit["pcm_start_sample"]
                    or end != unit["pcm_end_sample_exclusive"] or cue["alignment_id"] is not None
                    or cue["maximum_uncertainty_samples"] is not None):
                raise ValueError("whole-unit cue cannot claim internal text timing")
        elif cue["timing_basis"] == "CALIBRATED_TEXT_RANGE":
            tolerance = integer(cue["maximum_uncertainty_samples"], "caption uncertainty")
            row = _alignment(reader, evidence, temporal_policy, temporal_policy_binding,
                             cue["alignment_id"], unit, a, b, tolerance, blockers,
                             evidence_usage, voice_population)
            if row is not None and (start != unit["pcm_start_sample"] + row["start_upper_sample"] or end != unit["pcm_start_sample"] + row["end_lower_sample"]):
                blockers.append("CAPTION_TEMPORAL_BOUNDS_DIFFER:" + cid)
        else:
            raise ValueError("caption timing basis differs")
        covered[unit["unit_id"]].append((a, b))
        output.append(copy.deepcopy(cue))
        last_end = end
    for unit in units:
        cursor = 0
        for a, b in covered[unit["unit_id"]]:
            if a != cursor:
                raise ValueError("caption literal gap/overlap or reordering")
            cursor = b
            if cursor < len(unit["text"]) and unit["text"][cursor] == " ":
                cursor += 1
        if cursor != len(unit["text"]):
            blockers.append("CAPTION_COVERAGE_INCOMPLETE:" + unit["unit_id"])
    return output


def _temporal_target_units(data, caption_cues, unit_ids, *, units=None,
                           render_spans=None, visual_events=None):
    """Return the full frozen set whose timing is evaluated by this contract.

    The population is deliberately limited to narration units reconciled by
    this release.  A calibration holdout may not be any target in the same AV
    plan, even when it is being used to calibrate a different target.
    """
    targets = set()
    intent = data.get("visual_intent")
    if intent is not None:
        requirements = intent.get("event_requirements")
        if not isinstance(requirements, list):
            raise ValueError("visual intent event requirements must be an array")
        for requirement in requirements:
            if not isinstance(requirement, dict):
                raise ValueError("visual intent event requirement must be an object")
            if requirement.get("kind") == "UNIT_BOUNDARY" or requirement.get("trigger") == "WHOLE_UNIT_PCM_START":
                # Exclusion is permitted only after recomposing the explicit
                # instance, unit and span; the new label alone proves nothing.
                if units is None or render_spans is None or visual_events is None:
                    raise ValueError("unit boundary target exclusion requires source-bound frame/span context")
                eid, sid = requirement.get("event_id"), requirement.get("span_id")
                instances = [item for item in visual_events if isinstance(item, dict) and item.get("event_id") == eid]
                scheduled = [item for item in render_spans if isinstance(item, dict) and item.get("span_id") == sid]
                contracts = [item for item in intent.get("span_contracts", []) if isinstance(item, dict) and item.get("span_id") == sid]
                if (intent.get("schema_version") == "1.2.0" and len(contracts) == 1
                        and contracts[0].get("media_kind") == "STATIC_IMAGE" and not instances and not scheduled):
                    # Unscheduled still entry is NOT an exclusion or an onset.
                    # Keep this unit in the conservative target union; _visual
                    # separately verifies the frozen static contract and emits
                    # TEMPORAL_STATIC_EVENTS_INCOMPLETE until events are bound.
                    uid = nonempty(requirement.get("unit_id"), "unbound static entry unit")
                    if uid not in unit_ids:
                        raise ValueError("unbound static entry references unknown unit")
                    targets.add(uid)
                    continue
                if len(instances) != 1 or len(scheduled) != 1 or len(contracts) != 1:
                    raise ValueError("unit boundary requires one explicit instance and span contract")
                placed = {unit["unit_id"]: unit for unit in units}
                if set(placed) != set(unit_ids) or len(placed) != len(units):
                    raise ValueError("unit boundary source population differs")
                _validate_unit_boundary(requirement, instances[0], intent.get("schema_version"),
                                        placed, {**scheduled[0], **contracts[0]})
                continue
            trigger = requirement.get("trigger")
            if trigger != "NO_SPEECH_DEPENDENCY":
                if trigger not in {"NOT_BEFORE_ANCHOR_START", "NOT_BEFORE_ANCHOR_END"}:
                    raise ValueError("unknown temporal event trigger")
                unit_id = nonempty(requirement.get("unit_id"), "speech-dependent event unit")
                if unit_id not in unit_ids:
                    raise ValueError("speech-dependent event references unknown unit")
                targets.add(unit_id)
    for cue in caption_cues:
        if not isinstance(cue, dict):
            raise ValueError("caption must be an object")
        if cue.get("timing_basis") == "CALIBRATED_TEXT_RANGE" or cue.get("alignment_id") is not None:
            unit_id = nonempty(cue.get("unit_id"), "calibrated caption unit")
            if unit_id not in unit_ids:
                raise ValueError("calibrated caption references unknown unit")
            targets.add(unit_id)
    return sorted(targets)


def _validate_caption_intent_subset(caption_cues, proof):
    """Only the internally reopened plan can bind actual scheduled cues."""
    if proof is None:
        return
    expected = {row["cue_id"]: (index, row) for index, row in enumerate(proof["cues"])}
    previous = -1
    fields = ("cue_id", "unit_id", "char_start", "char_end", "text", "lines")
    timing_classes = {_CAPTION_WHOLE: "WHOLE_UNIT_PCM_BOUNDS", _CAPTION_LEXICAL: "CALIBRATED_TEXT_RANGE"}
    for cue in caption_cues:
        exact(cue, "cue_id unit_id char_start char_end start_sample end_sample text lines timing_basis alignment_id maximum_uncertainty_samples", "bound caption")
        cid = nonempty(cue["cue_id"], "bound caption ID")
        if cid not in expected or expected[cid][0] <= previous:
            raise ValueError("caption is not an ordered unique subset of the frozen literal plan")
        previous, original = expected[cid]
        _same({key: cue[key] for key in fields}, {key: original[key] for key in fields},
              "caption differs from frozen literal intent")
        if cue["timing_basis"] != timing_classes[original["timing_state"]]:
            raise ValueError("caption timing class differs from frozen literal intent")


def _literal_visual_targets(proof, units):
    """Recompute targets from same-call frozen rows, not completeness labels."""
    rows = proof["rows"]
    if (len(units) != 51 or len(rows) != len(units)
            or [row["unit_id"] for row in rows] != [unit["unit_id"] for unit in units]):
        raise ValueError("literal visual population differs from A units")
    targets, seen, fragments = set(), set(), []
    for row, unit in zip(rows, units, strict=True):
        _same({key: row[key] for key in ("unit_id", "text", "text_sha256")},
              {key: unit[key] for key in ("unit_id", "text", "text_sha256")}, "literal visual unit differs")
        _same(row["fragment_ids"], unit["take_ids"], "literal visual fragments differ")
        if not row["states"]:
            raise ValueError("literal visual state coverage missing")
        if _literal_visual_states(row, seen):
            targets.add(row["unit_id"])
        fragments.extend(row["fragment_ids"])
    if fragments != [f"take-{index:03d}" for index in range(1, 91)]:
        raise ValueError("literal visual fragment population differs")
    return targets


def _literal_temporal_scope(units, declared_targets, visual_proof, caption_proof):
    """Complete literal target population, explicitly not a source/schedule gate.

    Both proofs come only from their allowlisted readers inside this build. This
    recomputation ignores their complete/count/target flags. Actual 100-state
    source binding remains unsupported in A8 and blocks the aggregate separately.
    """
    if caption_proof is None:
        raise ValueError("literal visual scope requires the frozen caption proof")
    visual_targets = _literal_visual_targets(visual_proof, units)
    by_unit = {unit["unit_id"]: unit for unit in units}
    groups = {uid: [] for uid in by_unit}
    observed = []
    for cue in caption_proof["cues"]:
        if cue["unit_id"] not in groups:
            raise ValueError("literal scope caption unit differs")
        groups[cue["unit_id"]].append(cue)
        observed.append(cue["cue_id"])
    expected, caption_targets = [], set()
    for index, unit in enumerate(units, 1):
        rows, cursor = groups[unit["unit_id"]], 0
        if not rows:
            raise ValueError("literal scope caption coverage missing")
        lexical = len(rows) > 1
        for ordinal, cue in enumerate(rows, 1):
            expected.append(f"caption-{index:03d}-{ordinal:02d}")
            a, b = integer(cue["char_start"], "literal caption start"), integer(cue["char_end"], "literal caption end", 1)
            if (a != cursor or not a < b <= len(unit["text"]) or cue["text"] != unit["text"][a:b]
                    or cue["timing_state"] != (_CAPTION_LEXICAL if lexical else _CAPTION_WHOLE)):
                raise ValueError("literal scope caption range/class differs")
            cursor = b
            if ordinal < len(rows):
                if unit["text"][cursor:cursor + 1] != " ":
                    raise ValueError("literal scope caption separator differs")
                cursor += 1
        if cursor != len(unit["text"]):
            raise ValueError("literal scope caption coverage truncated")
        if lexical:
            caption_targets.add(unit["unit_id"])
    if observed != expected:
        raise ValueError("literal scope caption order/identity differs")
    targets = sorted(visual_targets | caption_targets)
    _same(sorted(set(declared_targets)), targets, "declared temporal targets differ from frozen literal population")
    return {"declared_target_unit_ids": targets, "conservative_exclusion_unit_ids": targets,
        "unknown_scope_unit_ids": [], "scope_complete": True,
        "scope_basis": "FROZEN_UNTIMED_VISUAL_AND_CAPTION_LITERAL_POPULATION"}


def _validate_untimed_visual_subset(reader, data, proof, units, events):
    """Check offered semantic requirements BEFORE any temporal evidence read.

    This is deliberately not the missing 100-state-to-source mapper. Existing
    static states have an independently pinned literal contract; other lexical
    requirements may identify only exact planned ranges. No unplanned cut or
    HOLD can stand in for a reveal. Missing states remain an aggregate blocker.
    """
    if proof is None:
        return
    rows = {row["unit_id"]: row for row in proof["rows"]}
    placed = {unit["unit_id"]: unit for unit in units}
    lexical = {(row["unit_id"], state["entry"]["char_start"], state["entry"]["char_end"])
        for row in proof["rows"] for state in row["states"] if state["entry"]["kind"] == "LEXICAL_START"}
    intent = data.get("visual_intent")
    if intent is None:
        if events:
            raise ValueError("visual events require a source-bound visual intent")
        return
    contracts, requirements = intent.get("span_contracts"), intent.get("event_requirements")
    if not isinstance(contracts, list) or not isinstance(requirements, list):
        raise ValueError("visual subset requires contract and requirement arrays")
    by_span = {row["span_id"]: row for row in contracts}
    if len(by_span) != len(contracts):
        raise ValueError("duplicate visual subset span")
    # Metadata already belongs to the same-call reader proof, never decode or
    # import the source recipe. This prevents a known forecast PNG from being
    # relabelled as an observation/unit entry under the same static source ID.
    frozen = reader.load(_UNTIMED_VISUAL_SOURCES["static_intent"])
    frozen_contracts = {row["span_id"]: row for row in frozen["span_contracts"]}
    static_requirements = {}
    for requirement in frozen["event_requirements"]:
        source = frozen_contracts[requirement["span_id"]]["static_source"]
        static_requirements[(source["template_id"], source["state_id"])] = requirement
    by_event, semantic_seen = {}, set()
    literal_fields = ("kind", "unit_id", "char_start", "char_end", "trigger")
    for req in requirements:
        exact(req, "event_id span_id kind narrative_function unit_id char_start char_end trigger maximum_uncertainty_samples", "literal visual requirement")
        eid, sid = nonempty(req["event_id"], "literal event ID"), nonempty(req["span_id"], "literal span ID")
        if eid in by_event or sid not in by_span:
            raise ValueError("duplicate event or unknown literal span")
        by_event[eid] = req
        nonempty(req["narrative_function"], "literal event narrative function")
        contract = by_span[sid]
        fragment_ids = contract.get("fragment_ids")
        if not isinstance(fragment_ids, list) or not fragment_ids or len(set(fragment_ids)) != len(fragment_ids):
            raise ValueError("literal span fragment identity differs")
        uid, kind, trigger = req["unit_id"], req["kind"], req["trigger"]
        if kind == "SEMANTIC_CHANGE":
            a, b = integer(req["char_start"], "literal event start"), integer(req["char_end"], "literal event end", 1)
            key = (uid, a, b)
            if trigger != "NOT_BEFORE_ANCHOR_START" or key not in lexical or key in semantic_seen:
                raise ValueError("semantic requirement is not an exact unique frozen lexical reveal")
            semantic_seen.add(key)
            integer(req["maximum_uncertainty_samples"], "literal event uncertainty")
        elif kind == "UNIT_BOUNDARY":
            if (trigger != "WHOLE_UNIT_PCM_START" or uid not in rows
                    or any(req[key] is not None for key in ("char_start", "char_end", "maximum_uncertainty_samples"))):
                raise ValueError("literal unit entry cannot claim a lexical reveal")
        elif kind == "HOLD":
            if (trigger != "NO_SPEECH_DEPENDENCY"
                    or any(req[key] is not None for key in ("unit_id", "char_start", "char_end", "maximum_uncertainty_samples"))
                    or fragment_ids != rows["narration-unit-016"]["fragment_ids"]):
                raise ValueError("only the unchanged u016 continuation is a planned speech-independent HOLD")
            uid = "narration-unit-016"
        else:
            raise ValueError("visual requirement kind is absent from the frozen literal plan")
        if not set(fragment_ids) <= set(placed[uid]["take_ids"]):
            raise ValueError("literal visual event belongs to different narration fragments")
        if kind == "UNIT_BOUNDARY" and placed[uid]["take_ids"][0] not in fragment_ids:
            raise ValueError("literal unit entry must contain the first fragment")
        source = contract.get("static_source")
        if contract.get("media_kind") == "STATIC_IMAGE":
            if not isinstance(source, dict):
                raise ValueError("literal static source contract missing")
            original = static_requirements.get((source.get("template_id"), source.get("state_id")))
            if original is None:
                raise ValueError("static source has no frozen literal subset mapping")
            _same({key: req[key] for key in literal_fields}, {key: original[key] for key in literal_fields},
                  "static state cannot change its frozen lexical/entry meaning")
    seen = set()
    for event in events:
        exact(event, "event_id frame alignment_id", "literal visual event")
        eid = event["event_id"]
        if eid not in by_event or eid in seen:
            raise ValueError("visual event is not a unique declared literal requirement")
        seen.add(eid)
        integer(event["frame"], "literal event frame")
        if event["alignment_id"] is not None:
            nonempty(event["alignment_id"], "literal alignment ID")
            if by_event[eid]["kind"] != "SEMANTIC_CHANGE":
                raise ValueError("unit entry or HOLD cannot claim lexical alignment")


def _caption_textwrap_pin():
    """One exact external stdlib file, never arbitrary external Reader access."""
    path = Path(textwrap.__file__).absolute()
    if path != Path(CAPTION_TEXTWRAP_BINDING["path"]):
        raise ValueError("caption textwrap implementation path differs")
    for item in (path, *path.parents):
        if item.is_symlink() or getattr(item.lstat(), "st_file_attributes", 0) & (0x400 | 0x1000 | 0x40000 | 0x400000):
            raise PermissionError("caption textwrap dependency must be resident and unlinked")
    if not path.is_file() or bytes_sha(path.read_bytes()) != CAPTION_TEXTWRAP_BINDING["sha256"]:
        raise ValueError("caption textwrap implementation bytes differ")
    return copy.deepcopy(CAPTION_TEXTWRAP_BINDING)


def _temporal_scope(data, caption_cues, units, declared_targets, render_spans, visual_events, total,
                    *, caption_intent=None, untimed_visual_intent=None):
    """Conservative current-input guard, never a caller's completeness claim.

    The frozen A8 literal readers separate population from scheduling. Without
    that exact optional source, preserve A7's conservative scheduled-visual guard.
    """
    by_unit = {unit["unit_id"]: unit for unit in units}
    unit_ids = set(by_unit)
    if len(by_unit) != len(units) or not set(declared_targets) <= unit_ids:
        raise ValueError("temporal scope unit identity differs")
    if untimed_visual_intent is not None:
        return _literal_temporal_scope(units, declared_targets, untimed_visual_intent, caption_intent)
    intent = data.get("visual_intent") or {}
    contracts = intent.get("span_contracts", [])
    requirements = intent.get("event_requirements", [])
    if not isinstance(contracts, list) or not isinstance(requirements, list):
        raise ValueError("temporal scope requires planning arrays")
    contract_map = {row["span_id"]: row for row in contracts}
    scheduled = {row["span_id"]: row for row in render_spans}
    declared_events = {row["event_id"]: row for row in requirements}
    events = {row["event_id"]: row for row in visual_events}
    if (len(contract_map) != len(contracts) or len(scheduled) != len(render_spans)
            or len(declared_events) != len(requirements) or len(events) != len(visual_events)):
        raise ValueError("duplicate temporal planning identity")
    all_fragments = {tid for unit in units for tid in unit["take_ids"]}
    covered_fragments = set()
    cursor, contiguous = 0, True
    for span in render_spans:
        start = integer(span["start_frame"], "scope span start")
        end = integer(span["end_frame"], "scope span end", 1)
        contiguous = contiguous and start == cursor and start < end <= total // FRAME
        cursor = end
    complete_schedule = bool(render_spans) and contiguous and cursor == total // FRAME and set(scheduled) == set(contract_map)
    for sid, contract in contract_map.items():
        ids = contract.get("fragment_ids")
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids) or not set(ids) <= all_fragments:
            raise ValueError("temporal scope fragment declaration differs")
        required_events = {key for key, row in declared_events.items() if row.get("span_id") == sid}
        # No event requirement is unknown intent, not an implicit HOLD.
        if sid in scheduled and required_events and required_events <= set(events):
            covered_fragments.update(ids)
    visual_unknown = {uid for uid, unit in by_unit.items() if not set(unit["take_ids"]) <= covered_fragments}
    if not complete_schedule or set(events) != set(declared_events):
        visual_unknown.update(unit_ids)
    ranges, cue_ids = {uid: [] for uid in unit_ids}, set()
    # Recompute literal coverage, not a provided complete flag. The optional
    # object is the same-call adapter result, never raw caller input.
    scope_cues = caption_cues if caption_intent is None else caption_intent["cues"]
    for cue in scope_cues:
        uid, cid = cue.get("unit_id"), cue.get("cue_id")
        if uid not in by_unit or cid in cue_ids:
            raise ValueError("temporal scope caption identity differs")
        cue_ids.add(cid)
        a, b = integer(cue["char_start"], "scope caption start"), integer(cue["char_end"], "scope caption end", 1)
        if not 0 <= a < b <= len(by_unit[uid]["text"]) or cue.get("text") != by_unit[uid]["text"][a:b]:
            raise ValueError("temporal scope caption literal differs")
        ranges[uid].append((a, b))
    caption_unknown = set()
    for uid, unit in by_unit.items():
        cursor, contiguous = 0, True
        for a, b in ranges[uid]:
            contiguous = contiguous and a == cursor
            cursor = b
            if cursor < len(unit["text"]) and unit["text"][cursor] == " ":
                cursor += 1
        if not contiguous or cursor != len(unit["text"]):
            caption_unknown.add(uid)
    unknown = visual_unknown | caption_unknown
    return {"declared_target_unit_ids": sorted(set(declared_targets)),
            "conservative_exclusion_unit_ids": sorted(set(declared_targets) | unknown),
            "unknown_scope_unit_ids": sorted(unknown), "scope_complete": not unknown,
            "scope_basis": ("SCHEDULED_LITERAL_COVERAGE_GUARD_UNTIMED_PLAN_SUPPORT_PENDING"
                if caption_intent is None else "LITERAL_CAPTION_PLAN_WITH_SCHEDULED_VISUAL_GUARD")}


def build(root, source_bindings, pause_decisions, render_spans, visual_events,
          caption_cues, temporal_evidence_bindings, *, temporal_policy_binding=None):
    """Read/recompute only. Returns no write, effect, model or queue capability."""
    inputs = copy.deepcopy({"source_bindings": source_bindings, "pause_decisions": pause_decisions,
        "render_spans": render_spans, "visual_events": visual_events, "caption_cues": caption_cues,
        "temporal_evidence_bindings": temporal_evidence_bindings,
        "temporal_policy_binding": temporal_policy_binding})
    canonical_sha(inputs)  # Reject NaN/non-JSON before inspecting any source.
    for key in ("pause_decisions", "render_spans", "visual_events", "caption_cues"):
        if not isinstance(inputs[key], list):
            raise ValueError("planning collections must be arrays")
    if not isinstance(temporal_evidence_bindings, dict):
        raise ValueError("temporal evidence must be an ID-to-binding object")
    # Capture implementations before source work, never legitimize drift by
    # taking their first snapshot only after a long inspection has completed.
    code_root = Path(__file__).resolve().parents[1]
    code_binding = {"path": "hero_engine/phase6_av_timeline.py", "sha256": bytes_sha(Path(__file__).read_bytes())}
    implementation_dependencies = [{"path": path, "sha256": bytes_sha((code_root / path).read_bytes())}
                                  for path in IMPLEMENTATION_PATHS]
    reader = Reader(Path(root))
    data = _sources(reader, source_bindings)
    units, fragments = _literal_pcm(reader, data)
    textwrap_binding = _caption_textwrap_pin()
    caption_intent = (read_caption_intent(reader, source_bindings["caption_intent"], units)
                      if "caption_intent" in source_bindings else None)
    _validate_caption_intent_subset(caption_cues, caption_intent)
    prior_amended_visual_intent = prior_question_visual_intent = None
    if "body_case_amendment" in source_bindings:
        untimed_visual_intent = _body_case.read_amended_visual_intent(
            reader, source_bindings["body_case_amendment"], units, caption_intent,
            amendment_binding=source_bindings["body_case_evidence"], staging_binding=source_bindings["body_case_staging"])
        prior_question_visual_intent = untimed_visual_intent["prior_case_inspection"]
        prior_amended_visual_intent = untimed_visual_intent["prior_amendment_inspection"]
        historical_visual_intent = untimed_visual_intent["base_inspection"]
        for proof, key in ((prior_question_visual_intent, "question_case_amendment"),
                           (prior_amended_visual_intent, "visual_amendment"),
                           (historical_visual_intent, "untimed_visual_intent")):
            _same(proof["source_binding"], source_bindings[key], "body amendment historical chain differs from caller binding")
    elif "question_case_amendment" in source_bindings:
        untimed_visual_intent = _question_case.read_amended_visual_intent(
            reader, source_bindings["question_case_amendment"], units, caption_intent)
        prior_question_visual_intent = untimed_visual_intent
        prior_amended_visual_intent = untimed_visual_intent["prior_amendment_inspection"]
        historical_visual_intent = untimed_visual_intent["base_inspection"]
        _same(prior_amended_visual_intent["source_binding"], source_bindings["visual_amendment"],
              "case amendment historical V3 differs from caller binding")
        _same(historical_visual_intent["source_binding"], source_bindings["untimed_visual_intent"],
              "case amendment historical V2 differs from caller binding")
    elif "visual_amendment" in source_bindings:
        untimed_visual_intent = read_amended_visual_intent(
            reader, source_bindings["visual_amendment"], units, caption_intent)
        prior_amended_visual_intent = untimed_visual_intent
        historical_visual_intent = untimed_visual_intent["base_inspection"]
        _same(historical_visual_intent["source_binding"], source_bindings["untimed_visual_intent"],
              "amendment historical source differs from the caller's frozen V2")
    else:
        untimed_visual_intent = (read_visual_intent(reader, source_bindings["untimed_visual_intent"], units, caption_intent)
                                 if "untimed_visual_intent" in source_bindings else None)
        historical_visual_intent = untimed_visual_intent
    literal_asset_use_proofs = []
    if "body_case_amendment" in source_bindings:
        from .phase6_av_asset_use_binding_v3 import read_asset_use_binding as asset_use_reader
    else:
        asset_use_reader = (_question_uses.read_asset_use_binding if "question_case_amendment" in source_bindings
                            else read_asset_use_binding)
    literal_asset_use_evidence = (asset_use_reader(
        reader, source_bindings["literal_asset_uses"], untimed_visual_intent, proof_sink=literal_asset_use_proofs)
        if "literal_asset_uses" in source_bindings else None)
    _validate_untimed_visual_subset(reader, data, untimed_visual_intent, units, visual_events)
    if untimed_visual_intent is not None:
        for cue in caption_cues:
            # Offered scheduled cues are not untimed plan rows. Reject invented
            # null/float times before opening any external calibration input.
            integer(cue["start_sample"], "bound caption start_sample")
            integer(cue["end_sample"], "bound caption end_sample", 1)
    for decision in pause_decisions:
        for binding in decision.get("evidence_bindings", []):
            reader.read(binding["path"], binding["sha256"])
    blockers = []
    evidence_usage = {}
    units, silence, pauses, total = _place(units, _tails(data["acoustic_envelope"], units),
        pause_decisions, blockers, canonical_sha(inputs))
    if untimed_visual_intent is not None:
        temporal_target_unit_ids = sorted(_literal_visual_targets(untimed_visual_intent, units)
            | set(caption_intent["lexical_unit_ids"]))
        # A12 identifies the entire frozen literal population. It deliberately
        # does not map these 100 SOURCE_PENDING states to a production graph.
        blockers.append("TEMPORAL_VISUAL_STATE_BINDINGS_PENDING")
    else:
        temporal_target_unit_ids = _temporal_target_units(
            data, caption_cues, {unit["unit_id"] for unit in units}, units=units,
            render_spans=render_spans, visual_events=visual_events)
        if caption_intent is not None:
            temporal_target_unit_ids = sorted(set(temporal_target_unit_ids) | set(caption_intent["lexical_unit_ids"]))
    scope = _temporal_scope(data, caption_cues, units, temporal_target_unit_ids,
                            render_spans, visual_events, total, caption_intent=caption_intent,
                            untimed_visual_intent=untimed_visual_intent)
    evidence, temporal_policy = {}, None
    if scope["scope_complete"]:
        evidence = {key: reader.load(binding) for key, binding in temporal_evidence_bindings.items()}
        temporal_policy = (None if temporal_policy_binding is None else reader.load(temporal_policy_binding))
        for record in evidence.values():
            for binding in record.get("source_bindings", []):
                reader.read(binding["path"], binding["sha256"])
    else:
        blockers.append("TEMPORAL_TARGET_SCOPE_INCOMPLETE")
    voice_population = {"units": {unit["unit_id"]: unit for unit in units},
        "language": data["narrative_script"]["language"],
        "voice_contract_sha256": canonical_sha(data["inventory"]["voice_contract"]),
        "target_unit_ids": frozenset(scope["conservative_exclusion_unit_ids"]),
        "scope_complete": scope["scope_complete"]}
    static_proofs = []
    spans, events, static_evidence = _visual(reader, data, render_spans, visual_events, units, total, evidence,
                            temporal_policy, temporal_policy_binding, blockers, evidence_usage,
                            voice_population, static_proof_sink=static_proofs)
    captions = _captions(reader, caption_cues, units, evidence, temporal_policy,
                         temporal_policy_binding, blockers, evidence_usage, voice_population)
    if caption_intent is not None and [row["cue_id"] for row in captions] != [row["cue_id"] for row in caption_intent["cues"]]:
        # Literal completeness is not scheduling/evidence completeness. Empty
        # alignment usage must not become all-required-LIVE for unscheduled cues.
        blockers.append("TEMPORAL_CAPTION_SCHEDULE_INCOMPLETE")
    blockers = sorted(set(blockers))
    requested_alignment_ids = sorted({item["alignment_id"] for item in visual_events + caption_cues
                                      if item.get("alignment_id") is not None})
    evidence_classes = sorted(set(evidence_usage.values()))
    temporal_evidence_assessment = {
        "requested_alignment_ids": requested_alignment_ids,
        "validated_alignment_ids": sorted(evidence_usage),
        "evidence_classes": evidence_classes,
        "fixture_evidence_present": "FIXTURE" in evidence_classes,
        "holdout_population_scope": ("CURRENT_RECONCILED_NARRATION_UNITS_EXCLUDING_FULL_TEMPORAL_TARGET_UNION"
            if scope["scope_complete"] else "CURRENT_RECONCILED_NARRATION_UNITS_EXCLUDING_CONSERVATIVE_UNKNOWN_SCOPE"),
        "external_holdout_origin_supported": False,
        "temporal_target_unit_ids": scope["conservative_exclusion_unit_ids"],
        **scope,
        "all_required_evidence_live": bool(
            scope["scope_complete"] and set(requested_alignment_ids) == set(evidence_usage)
            and "FIXTURE" not in evidence_classes
            and not any(item.startswith(("TEMPORAL_", "CALIBRATION_", "ALIGNED_", "ACOUSTIC_"))
                        for item in blockers)
        ),
    }
    # This derived plan does NOT impersonate TakePlan 1.0 or approve art/rights.
    # B/C must dispatch to this exact version and its independent audio mapping.
    derived = None if blockers else {"schema_version": "1.0.0", "kind": "AV_SPAN_TAKE_PLAN",
        "historical_take_plan_id": data["take_plan"]["take_plan_id"],
        "render_spans": copy.deepcopy(spans), "visual_events": copy.deepcopy(events),
        "narration_fragment_map": copy.deepcopy(fragments), "caption_cues": copy.deepcopy(captions)}
    if derived is not None:
        derived["take_plan_id"] = "phase6-av-takes-" + canonical_sha(derived).split(":")[1][:24]
    implementation_dependencies.append(textwrap_binding)
    if untimed_visual_intent is not None:
        # Merge by exact identity, never append duplicate dependencies or accept
        # implementation drift between the literal reader and this consumer.
        by_path = {row["path"]: row for row in implementation_dependencies}
        for binding in untimed_visual_intent["implementation_dependencies"]:
            expected = {key: binding[key] for key in ("path", "sha256")}
            _same(by_path.get(binding["path"]), expected, "literal visual implementation dependency drifted")
            if (code_root / binding["path"]).stat().st_size != binding["size_bytes"]:
                raise ValueError("literal visual implementation size drifted")
    caption_intent_evidence = None if caption_intent is None else {
        "source_binding": copy.deepcopy(source_bindings["caption_intent"]),
        "inspection_sha256": canonical_sha(caption_intent),
        **{key: copy.deepcopy(caption_intent[key]) for key in (
            "adapter_version", "unit_count", "cue_count", "chunked_unit_count",
            "internal_alignment_cue_count", "whole_unit_cue_count", "lexical_unit_ids",
            "literal_caption_coverage_complete", "global_schedule_created", "calibrated_timing_available")},
    }
    # Keep V2 evidence explicitly historical. A projection's edited copy cannot
    # impersonate that proof, even when all lexical targets/counts are unchanged.
    untimed_visual_intent_evidence = None if historical_visual_intent is None else {
        "source_binding": copy.deepcopy(source_bindings["untimed_visual_intent"]),
        "inspection_sha256": canonical_sha(historical_visual_intent),
        "visual_lexical_range_count": len(historical_visual_intent["visual_lexical_ranges"]),
        **{key: copy.deepcopy(historical_visual_intent[key]) for key in (
            "adapter_version", "editorial_supplement_binding", "unit_count", "fragment_count", "state_count",
            "visual_lexical_unit_ids", "caption_lexical_unit_ids", "temporal_target_unit_ids",
            "literal_visual_coverage_complete", "unknown_intent_unit_ids", "source_ready",
            "global_schedule_created", "calibrated_timing_available")},
    }
    visual_amendment_evidence = None if "visual_amendment" not in source_bindings else {
        "projection_binding": copy.deepcopy(source_bindings["visual_amendment"]),
        "inspection_sha256": canonical_sha(prior_amended_visual_intent),
        "effective_rows_sha256": canonical_sha(prior_amended_visual_intent["rows"]),
        "changed_state_count": 12, "unmodified_state_count": 88,
        **{key: copy.deepcopy(prior_amended_visual_intent[key]) for key in (
            "adapter_version", "amendment_binding", "base_plan_binding", "base_inspection_sha256",
            "decision_reference_scope", "source_ready", "global_schedule_created", "calibrated_timing_available")},
    }
    question_case_amendment_evidence = None if "question_case_amendment" not in source_bindings else {
        "projection_binding": copy.deepcopy(source_bindings["question_case_amendment"]),
        "inspection_sha256": canonical_sha(prior_question_visual_intent),
        "effective_rows_sha256": canonical_sha(prior_question_visual_intent["rows"]),
        **{key: copy.deepcopy(prior_question_visual_intent[key]) for key in (
            "adapter_version", "prior_projection_binding", "amendment_binding", "case_staging_binding",
            "case_reconciliation_binding", "prior_amendment_inspection_sha256", "changed_state_count",
            "changed_string_count", "unmodified_state_count", "decision_reference_scope", "static_proof_scope",
            "source_ready", "global_schedule_created", "calibrated_timing_available")},
    }
    body_case_amendment_evidence = None if "body_case_amendment" not in source_bindings else {
        "adapter_version": _body_case.VERSION,
        "projection_binding": copy.deepcopy(source_bindings["body_case_amendment"]),
        "amendment_binding": copy.deepcopy(source_bindings["body_case_evidence"]),
        "staging_binding": copy.deepcopy(source_bindings["body_case_staging"]),
        "claim_binding": copy.deepcopy(untimed_visual_intent["body_case_claim_binding"]),
        "inspection_sha256": canonical_sha(untimed_visual_intent),
        "effective_rows_sha256": canonical_sha(untimed_visual_intent["rows"]),
        "prior_case_inspection_sha256": canonical_sha(prior_question_visual_intent),
        "changed_state_count": 21, "changed_string_count": 24, "unmodified_state_count": 79,
        "preserved_bound_state_count": len(untimed_visual_intent["preserved_body_case_constraints"]["bound_state_ids"]),
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
    }
    result = {"schema_version": "1.11.0", "timeline_version": VERSION,
        "status": "BLOCKED_INCOMPLETE" if blockers else "TIMELINE_VALIDATED_NOT_ADMITTED",
        "channel_id": data["take_plan"]["channel_id"], "video_id": data["take_plan"]["video_id"],
        "protocol_id": data["protocol"]["protocol_id"], "inputs": inputs, "implementation": code_binding,
        "implementation_dependencies": implementation_dependencies,
        "clock": {"sample_rate": RATE, "fps_numerator": 30, "fps_denominator": 1,
            "samples_per_frame": FRAME, "slot_grid_samples": GRID},
        "units": units, "narration_fragment_map": fragments, "permitted_silence_spans": silence,
        "pause_measurements": pauses, "render_spans": spans, "visual_events": events, "caption_cues": captions,
        "static_source_evidence": static_evidence,
        "caption_intent_evidence": caption_intent_evidence,
        "untimed_visual_intent_evidence": untimed_visual_intent_evidence,
        "visual_amendment_evidence": visual_amendment_evidence,
        "question_case_amendment_evidence": question_case_amendment_evidence,
        "body_case_amendment_evidence": body_case_amendment_evidence,
        "literal_asset_use_evidence": literal_asset_use_evidence,
        "duration": {"pcm_sum_samples": sum(u["frame_count"] for u in units),
            "planned_total_samples": total, "planned_total_frames": total // FRAME,
            "planned_duration_ms": total // 24, "protocol_band_ms": [207750, 286250],
            "grid_band_ms": [207800, 286200], "final_media_duration_ms": None},
        "derived_take_plan": derived, "blockers": blockers, "authority": copy.deepcopy(AUTHORITY),
        "temporal_evidence_assessment": temporal_evidence_assessment,
        "technical_cost_brl": 0, "quality_boundary": "TEMPORAL_CONTRACT_ONLY_NOT_NARRATIVE_RIGHTS_OR_RENDER_QA",
        "caption_precheck": {"policy_version": "phase6-caption-text-precheck-v1", "maximum_lines": 2,
            "maximum_characters_per_line": 42, "maximum_words": 12,
            "rendered_legibility_approved": False, "measurements": [{"cue_id": cue["cue_id"],
                "word_count": len(cue["text"].split()), "line_count": len(cue["lines"]),
                "maximum_line_characters": max((len(line) for line in cue["lines"]), default=0),
                "duration_samples": cue["end_sample"] - cue["start_sample"]} for cue in captions]},
        "unproven_checks": ["RENDERED_CAPTION_LEGIBILITY_AND_READING_PACE", "VISUAL_SOURCE_DECODE_AND_FRAME_COUNT",
            "NARRATIVE_SEMANTICS_AND_HOLD_SUITABILITY", "GENUINE_VISUAL_VARIETY_AND_CONCENTRATION",
            "RIGHTS_AND_PUBLICITY", "AUDIO_PRONUNCIATION_AND_PERCEPTUAL_CONTINUITY", "FINAL_RENDER_QUALITY_GATES"],
        "source_file_bindings": sorted(reader.bindings.values(), key=lambda x: x["path"])}
    result["timeline_id"] = "phase6-av-timeline-" + canonical_sha(result).split(":")[1][:24]
    schema = _json(Path(__file__).resolve().parents[1].joinpath(SCHEMA).read_bytes())
    Draft202012Validator(schema).validate(result)
    # Reject drift after processing, including an already read journal or PCM.
    for binding in list(reader.bindings.values()):
        reader.read(binding["path"], binding["sha256"])
    for binding in [code_binding, *implementation_dependencies]:
        if bytes_sha((code_root / binding["path"]).read_bytes()) != binding["sha256"]:
            raise ValueError("timeline implementation dependency changed during build")
    _caption_textwrap_pin()
    if caption_intent is not None:
        from .phase6_av_caption_intent import _resident as _caption_resident
        for binding in caption_intent["dependency_bindings"]:
            _caption_resident(reader.root, binding["path"])
            if len(reader.read(binding["path"], binding["sha256"])) != binding["size_bytes"]:
                raise ValueError("caption intent dependency changed during build")
    if untimed_visual_intent is not None:
        from .phase6_av_caption_intent import _resident as _literal_resident
        for binding in untimed_visual_intent["dependency_bindings"]:
            _literal_resident(reader.root, binding["path"])
            if len(reader.read(binding["path"], binding["sha256"])) != binding["size_bytes"]:
                raise ValueError("literal visual dependency changed during build")
        for binding in untimed_visual_intent["implementation_dependencies"]:
            _literal_resident(code_root, binding["path"])
            raw = (code_root / binding["path"]).read_bytes()
            if bytes_sha(raw) != binding["sha256"] or len(raw) != binding["size_bytes"]:
                raise ValueError("literal visual implementation changed during build")
    if static_proofs:
        from .phase6_av_static_sources import recheck_static_dependencies
        recheck_static_dependencies(reader.root, static_proofs)
    if literal_asset_use_proofs:
        if "body_case_amendment" in source_bindings:
            from .phase6_av_static_asset_uses_v4 import recheck_asset_use_dependencies
            recheck_asset_use_dependencies(reader.root, literal_asset_use_proofs)
        elif "question_case_amendment" in source_bindings:
            from .phase6_av_static_asset_uses_v3 import recheck_asset_use_dependencies
            recheck_asset_use_dependencies(reader.root, literal_asset_use_proofs)
        else:
            from .phase6_av_static_sources import recheck_static_dependencies
            recheck_static_dependencies(reader.root, literal_asset_use_proofs)
    if "body_case_amendment" in source_bindings:
        _body_case.recheck_body_case_replay(reader.root, untimed_visual_intent)
    elif "question_case_amendment" in source_bindings:
        _question_case.recheck_question_replay(reader.root, untimed_visual_intent)
    return result


def verify(root, candidate, source_bindings, pause_decisions, render_spans,
           visual_events, caption_cues, temporal_evidence_bindings, *,
           temporal_policy_binding=None, require_complete=False):
    """Independent source recomposition; never trusts a candidate's own inputs."""
    expected = build(root, source_bindings, pause_decisions, render_spans,
        visual_events, caption_cues, temporal_evidence_bindings,
        temporal_policy_binding=temporal_policy_binding)
    _same(candidate, expected, "timeline differs from independent source recomposition")
    if require_complete and expected["status"] != "TIMELINE_VALIDATED_NOT_ADMITTED":
        raise ValueError("timeline is incomplete and cannot be consumed as executable")
    return expected


build_phase6_av_timeline = build
verify_phase6_av_timeline = verify
