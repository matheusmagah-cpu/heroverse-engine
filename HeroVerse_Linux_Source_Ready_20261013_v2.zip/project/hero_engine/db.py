from __future__ import annotations

import csv
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT / "data" / "hero_engine.db"
DEFAULT_CONFIG = ROOT / "config" / "engine.json"


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS channels (
    handle TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    subscribers INTEGER,
    video_count INTEGER,
    total_views INTEGER,
    joined_date TEXT,
    country TEXT,
    source_url TEXT NOT NULL,
    notes TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS videos (
    video_id TEXT PRIMARY KEY,
    channel_handle TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    role TEXT NOT NULL,
    license_status TEXT NOT NULL,
    license_evidence TEXT,
    verified_at TEXT,
    views INTEGER,
    duration_seconds INTEGER,
    published_date TEXT,
    notes TEXT,
    source_payload TEXT,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (channel_handle) REFERENCES channels(handle)
);

CREATE TABLE IF NOT EXISTS license_audits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id TEXT NOT NULL,
    status TEXT NOT NULL,
    evidence_text TEXT,
    evidence_url TEXT,
    audited_at TEXT NOT NULL,
    reusable INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);

CREATE TABLE IF NOT EXISTS transcripts (
    video_id TEXT PRIMARY KEY,
    language TEXT,
    source TEXT NOT NULL,
    body TEXT NOT NULL,
    fetched_at TEXT NOT NULL,
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);

CREATE TABLE IF NOT EXISTS clip_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id TEXT NOT NULL,
    start_seconds REAL NOT NULL,
    end_seconds REAL NOT NULL,
    transcript_text TEXT NOT NULL,
    hook_score REAL NOT NULL,
    clarity_score REAL NOT NULL,
    emotion_score REAL NOT NULL,
    total_score REAL NOT NULL,
    approved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);

CREATE TABLE IF NOT EXISTS hook_blueprints (
    video_id TEXT PRIMARY KEY,
    observed_window_seconds REAL NOT NULL,
    observed_text TEXT NOT NULL,
    source_views INTEGER,
    mechanics_json TEXT NOT NULL,
    hook_score REAL NOT NULL,
    evidence_class TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);

CREATE TABLE IF NOT EXISTS channel_models (
    model_id TEXT PRIMARY KEY,
    reference_channel_id TEXT NOT NULL,
    reference_channel_name TEXT NOT NULL,
    population_videos INTEGER NOT NULL,
    total_views INTEGER NOT NULL,
    median_views INTEGER NOT NULL,
    ranking_metric TEXT NOT NULL,
    model_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS model_videos (
    model_id TEXT NOT NULL,
    video_id TEXT NOT NULL,
    title TEXT NOT NULL,
    views INTEGER NOT NULL,
    views_per_day REAL NOT NULL,
    duration_seconds REAL NOT NULL,
    published_date TEXT,
    sample_tier TEXT NOT NULL DEFAULT 'population',
    PRIMARY KEY (model_id, video_id),
    FOREIGN KEY (model_id) REFERENCES channel_models(model_id)
);

CREATE TABLE IF NOT EXISTS model_openings (
    model_id TEXT NOT NULL,
    video_id TEXT NOT NULL,
    sample_tier TEXT NOT NULL,
    opening_text TEXT NOT NULL,
    first_speech_seconds REAL,
    cuts_first_15_seconds INTEGER,
    semantic_score REAL NOT NULL,
    semantic_passed INTEGER NOT NULL,
    diagnostic_json TEXT NOT NULL,
    PRIMARY KEY (model_id, video_id),
    FOREIGN KEY (model_id, video_id) REFERENCES model_videos(model_id, video_id)
);

CREATE TABLE IF NOT EXISTS productions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    format TEXT NOT NULL,
    pillar TEXT NOT NULL,
    thesis TEXT NOT NULL,
    source_video_ids TEXT NOT NULL,
    status TEXT NOT NULL,
    edl_path TEXT,
    render_path TEXT,
    approval_required INTEGER NOT NULL DEFAULT 1,
    approved_at TEXT,
    scheduled_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS performance_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    youtube_video_id TEXT NOT NULL,
    format TEXT NOT NULL,
    captured_at TEXT NOT NULL,
    age_hours REAL,
    impressions INTEGER,
    views INTEGER,
    engaged_views INTEGER,
    watch_hours REAL,
    subscribers_gained INTEGER,
    ctr REAL,
    intro_30s_rate REAL,
    average_view_duration_seconds REAL,
    average_percentage_viewed REAL,
    viewed_rate REAL,
    likes INTEGER,
    comments INTEGER,
    shares INTEGER
);

CREATE TABLE IF NOT EXISTS daily_forecasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    generated_at TEXT NOT NULL,
    scenario TEXT NOT NULL,
    horizon_days INTEGER NOT NULL,
    payload TEXT NOT NULL
);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_config(path: Path | None = None) -> dict[str, Any]:
    target = path or DEFAULT_CONFIG
    return json.loads(target.read_text(encoding="utf-8"))


@contextmanager
def connect(path: Path | None = None) -> Iterator[sqlite3.Connection]:
    target = path or DEFAULT_DB
    target.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(target)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def initialize(path: Path | None = None) -> Path:
    target = path or DEFAULT_DB
    with connect(target) as conn:
        conn.executescript(SCHEMA)
    return target


def _nullable_int(value: str | None) -> int | None:
    if value is None or value.strip() == "":
        return None
    return int(value)


def import_seed_data(path: Path | None = None) -> dict[str, int]:
    target = initialize(path)
    stamp = utc_now()
    channel_count = 0
    video_count = 0
    with connect(target) as conn:
        with (ROOT / "data" / "seed_channels.csv").open(encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                conn.execute(
                    """
                    INSERT INTO channels (
                        handle, name, role, subscribers, video_count, total_views,
                        joined_date, country, source_url, notes, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(handle) DO UPDATE SET
                        name=excluded.name, role=excluded.role,
                        subscribers=excluded.subscribers, video_count=excluded.video_count,
                        total_views=excluded.total_views, joined_date=excluded.joined_date,
                        country=excluded.country, source_url=excluded.source_url,
                        notes=excluded.notes, updated_at=excluded.updated_at
                    """,
                    (
                        row["handle"], row["name"], row["role"],
                        _nullable_int(row["subscribers"]), _nullable_int(row["video_count"]),
                        _nullable_int(row["total_views"]), row["joined_date"] or None,
                        row["country"] or None, row["source_url"], row["notes"] or None, stamp,
                    ),
                )
                channel_count += 1

        with (ROOT / "data" / "seed_videos.csv").open(encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                conn.execute(
                    """
                    INSERT INTO videos (
                        video_id, channel_handle, title, url, role, license_status,
                        license_evidence, verified_at, views, duration_seconds,
                        published_date, notes, source_payload, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(video_id) DO UPDATE SET
                        channel_handle=excluded.channel_handle, title=excluded.title,
                        url=excluded.url, role=excluded.role,
                        license_status=excluded.license_status,
                        license_evidence=excluded.license_evidence,
                        verified_at=excluded.verified_at, views=excluded.views,
                        duration_seconds=excluded.duration_seconds,
                        published_date=excluded.published_date, notes=excluded.notes,
                        updated_at=excluded.updated_at
                    """,
                    (
                        row["video_id"], row["channel_handle"], row["title"], row["url"],
                        row["role"], row["license_status"], row["license_evidence"] or None,
                        row["verified_at"] or None, _nullable_int(row["views"]),
                        _nullable_int(row["duration_seconds"]), row["published_date"] or None,
                        row["notes"] or None, None, stamp,
                    ),
                )
                if row["license_status"] == "verified_cc":
                    existing = conn.execute(
                        "SELECT 1 FROM license_audits WHERE video_id=? AND evidence_text=?",
                        (row["video_id"], row["license_evidence"]),
                    ).fetchone()
                    if not existing:
                        conn.execute(
                            """
                            INSERT INTO license_audits
                            (video_id, status, evidence_text, evidence_url, audited_at, reusable)
                            VALUES (?, 'verified_cc', ?, ?, ?, 1)
                            """,
                            (row["video_id"], row["license_evidence"], row["url"], row["verified_at"]),
                        )
                video_count += 1
    return {"channels": channel_count, "videos": video_count}


def rows(query: str, params: tuple[Any, ...] = (), path: Path | None = None) -> list[dict[str, Any]]:
    with connect(path) as conn:
        return [dict(row) for row in conn.execute(query, params).fetchall()]
