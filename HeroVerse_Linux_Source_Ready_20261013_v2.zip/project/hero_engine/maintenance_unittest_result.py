from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


ALLOWED_SKIPS: dict[str, tuple[str, ...]] = {
    "tests.test_scheduled_voice_probe.ScheduledVoiceProbeTests."
    "test_preexisting_sample_symlink_is_never_reused": (
        "file symlink unavailable: [WinError 1314]",
    ),
}

_SUMMARY_LINE = re.compile(r"Ran (\d+) tests? in ([0-9]+(?:\.[0-9]+)?)s")
_TERMINAL_LINE = re.compile(r"OK(?: \(skipped=(\d+)\))?")
_RESULT_SUFFIXES: tuple[tuple[str, str], ...] = (
    ("unexpected success", "unexpected_success"),
    ("expected failure", "expected_failure"),
    ("ERROR", "error"),
    ("FAIL", "fail"),
    ("ok", "ok"),
)

# A reviewed source contract, not a namespace exemption. These exact files
# implement the preexisting load_tests suite. A source edit needs a separately
# reviewed contract; old inventories cannot authenticate its new bytes.
_ALIAS_LOADER = "tests/test_maintenance_abandoned_request.py"
_ALIAS_SOURCE = "tests/test_daily_maintenance_protocol.py"
_ALIAS_SOURCE_HASH = "sha256:3481394db562ad19abf4564fd8eede9b19974ee71dcac6405f84cd7398f89708"
_ALIAS_DECLARATION = {
    "path": _ALIAS_LOADER,
    "content_hash": "sha256:647a80efcbafc35cbbe5f36e3eb9c08805c590cd7da2ebb84c399c1c8d3bcea1",
    "function": "load_tests",
    "first_line": 269,
    "last_line": 283,
    "declaration_hash": "sha256:b08c74e182766c0e2a6392b64534334d0153362f60f7e0f28a6aae3e12fe5dfa",
}
_ALIAS_METHODS = (
    "test_zero_api_ready_ack_is_read_only_for_operational_state",
    "test_any_active_lease_blocks_manager_stop",
    "test_incomplete_quota_reservation_blocks_external_effect_boundary",
    "test_consumed_quota_with_open_before_journal_still_blocks",
    "test_malformed_request_holds_fail_closed_without_ack",
    "test_expired_revalidation_window_never_releases_the_request_barrier",
    "test_restart_fault_injection_never_starts_task_when_exact_chain_absence_is_uncertain",
)


class UnittestResultError(PermissionError):
    """The captured unittest result is not a complete inventoried PASS."""


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def declared_load_tests_aliases(files: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Resolve only the authenticated, reviewed loader; never import test code."""
    by_path = {item["path"]: item for item in files}
    if _ALIAS_LOADER not in by_path:
        return []
    loader = by_path[_ALIAS_LOADER]
    source = by_path.get(_ALIAS_SOURCE)
    if (
        loader.get("content_hash") != _ALIAS_DECLARATION["content_hash"]
        or source is None
        or source.get("content_hash") != _ALIAS_SOURCE_HASH
    ):
        raise UnittestResultError("load_tests source is incompatible with the authenticated contract")
    aliases = []
    for name in _ALIAS_METHODS:
        source_id = "tests.test_daily_maintenance_protocol.DailyMaintenanceProtocolTests." + name
        if source_id not in source.get("test_ids", []):
            raise UnittestResultError("load_tests alias source test is absent")
        aliases.append({
            "execution_id": "_abandonment_test_daily_maintenance_protocol.DailyMaintenanceProtocolTests." + name,
            "source_test_id": source_id,
            "source_path": _ALIAS_SOURCE,
            "source_hash": _ALIAS_SOURCE_HASH,
            "loading_declaration": dict(_ALIAS_DECLARATION),
        })
    return aliases


def verify_static_load_tests(path: str, payload: bytes, tree: ast.Module) -> None:
    """Fail closed on an unknown discovery hook, using the same bytes as its hash."""
    hooks = [node for node in ast.walk(tree) if (
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "load_tests"
    )]
    if not hooks:
        if path == _ALIAS_LOADER:
            raise UnittestResultError("authenticated load_tests declaration is absent")
        return
    if (
        path != _ALIAS_LOADER or len(hooks) != 1 or hooks[0] not in tree.body
        or "sha256:" + hashlib.sha256(payload).hexdigest() != _ALIAS_DECLARATION["content_hash"]
    ):
        raise UnittestResultError("unsupported or changed load_tests declaration")
    hook = hooks[0]
    declaration = b"".join(payload.splitlines(keepends=True)[hook.lineno - 1:hook.end_lineno])
    if (
        hook.lineno != _ALIAS_DECLARATION["first_line"]
        or hook.end_lineno != _ALIAS_DECLARATION["last_line"]
        or "sha256:" + hashlib.sha256(declaration).hexdigest() != _ALIAS_DECLARATION["declaration_hash"]
        or ast.literal_eval(hook.body[3].iter) != _ALIAS_METHODS
    ):
        raise UnittestResultError("load_tests literal selection diverges from its source contract")


def _inventory_ids(inventory: dict[str, Any]) -> list[str]:
    if not isinstance(inventory, dict):
        raise UnittestResultError("unittest inventory is not an object")
    version = inventory.get("schema_version")
    if version not in {"1.0.0", "1.1.0"}:
        raise UnittestResultError("unittest inventory version is unsupported")
    if version == "1.0.0" and any(
        key in inventory for key in ("load_tests_aliases", "aliases_hash", "method_count", "alias_count")
    ):
        raise UnittestResultError("legacy unittest inventory cannot carry alias evidence")
    files = inventory.get("files")
    if not isinstance(files, list) or not files:
        raise UnittestResultError("unittest inventory has no test files")
    if type(inventory.get("file_count")) is not int or inventory["file_count"] != len(files):
        raise UnittestResultError("unittest inventory file count is inconsistent")

    test_ids: list[str] = []
    paths: set[str] = set()
    for item in files:
        if not isinstance(item, dict):
            raise UnittestResultError("unittest inventory contains a non-object file")
        path = item.get("path")
        ids = item.get("test_ids")
        if (
            not isinstance(path, str)
            or not re.fullmatch(r"tests/test_[^/]+\.py", path)
            or path in paths
            or not isinstance(ids, list)
        ):
            raise UnittestResultError("unittest inventory contains an invalid test file")
        paths.add(path)
        if version == "1.1.0" and not re.fullmatch(r"sha256:[0-9a-f]{64}", str(item.get("content_hash"))):
            raise UnittestResultError("unittest inventory source hash is invalid")
        module = path[:-3].replace("/", ".")
        for test_id in ids:
            if (
                not isinstance(test_id, str)
                or not test_id.startswith(module + ".")
                or not re.fullmatch(r"tests\.test_[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+", test_id)
            ):
                raise UnittestResultError("unittest inventory contains an invalid test id")
            test_ids.append(test_id)

    if version == "1.1.0":
        aliases = declared_load_tests_aliases(files)
        if (
            type(inventory.get("method_count")) is not int
            or inventory["method_count"] != len(test_ids)
            or type(inventory.get("alias_count")) is not int
            or inventory["alias_count"] != len(aliases)
            or _canonical_hash(inventory.get("load_tests_aliases")) != _canonical_hash(aliases)
            or inventory.get("aliases_hash") != _canonical_hash(aliases)
        ):
            raise UnittestResultError("unittest inventory declared alias identity is inconsistent")
        test_ids.extend(alias["execution_id"] for alias in aliases)

    if (
        type(inventory.get("test_count")) is not int
        or inventory["test_count"] != len(test_ids)
        or len(test_ids) != len(set(test_ids))
        or inventory.get("tests_hash") != _canonical_hash(test_ids)
    ):
        raise UnittestResultError("unittest inventory test identity is inconsistent")
    return test_ids


def _decode(payload: bytes, *, label: str) -> str:
    if not isinstance(payload, bytes):
        raise UnittestResultError(f"unittest {label} is not bytes")
    return payload.decode("utf-8-sig", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def _line_candidates(text: str, prefix: tuple[str, ...]) -> list[tuple[int, str]]:
    result: list[tuple[int, str]] = []
    position = 0
    for line in text.splitlines(keepends=True):
        stripped = line.rstrip("\n")
        if stripped.startswith(prefix):
            result.append((position, stripped))
        position += len(line)
    return result


def _identity_occurrence(stderr: str, test_id: str) -> tuple[int, int, int]:
    runtime_ids = [test_id]
    if test_id.startswith("tests."):
        runtime_ids.append(test_id[len("tests."):])
    matches: list[tuple[int, int]] = []
    for runtime_id in runtime_ids:
        marker = f"({runtime_id})"
        start = 0
        while True:
            position = stderr.find(marker, start)
            if position < 0:
                break
            matches.append((position, position + len(marker)))
            start = position + len(marker)
    matches = sorted(set(matches))
    if len(matches) != 1:
        raise UnittestResultError(
            f"unittest transcript contains {len(matches)} occurrences of inventoried test {test_id}"
        )
    marker_start, marker_end = matches[0]
    line_start = stderr.rfind("\n", 0, marker_start) + 1
    method_name = test_id.rsplit(".", 1)[-1]
    if stderr[line_start:marker_start] != method_name + " ":
        raise UnittestResultError(f"unittest result prefix is invalid for {test_id}")
    return line_start, marker_start, marker_end


def _result_from_segment(test_id: str, segment: str) -> tuple[str, str | None]:
    candidates: list[tuple[str, str | None]] = []
    for raw_line in segment.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        skipped = re.fullmatch(r"(?:\.\.\. )?skipped (.+)", line)
        if skipped:
            try:
                reason = ast.literal_eval(skipped.group(1))
            except (SyntaxError, ValueError) as exc:
                raise UnittestResultError(
                    f"unittest skip reason is not a string literal for {test_id}"
                ) from exc
            if not isinstance(reason, str):
                raise UnittestResultError(f"unittest skip reason is not text for {test_id}")
            candidates.append(("skipped", reason))
            continue
        for suffix, outcome in _RESULT_SUFFIXES:
            if line == suffix or line.endswith("... " + suffix):
                candidates.append((outcome, None))
                break
    if len(candidates) != 1:
        raise UnittestResultError(
            f"unittest transcript has {len(candidates)} result markers for {test_id}"
        )
    return candidates[0]


def verify_unittest_result(
    *,
    inventory: dict[str, Any],
    stdout_bytes: bytes,
    stderr_bytes: bytes,
    process_exit_code: int | None,
) -> dict[str, Any]:
    """Reconcile a verbose unittest transcript against its immutable inventory.

    ``process_exit_code`` is mandatory at the execution boundary.  Historical
    receipt consumers may pass ``None`` because receipt schema 1.0--1.2 did not
    persist it; they still revalidate every transcript outcome and binding.
    """

    if process_exit_code is not None and (
        isinstance(process_exit_code, bool)
        or not isinstance(process_exit_code, int)
        or process_exit_code != 0
    ):
        raise UnittestResultError("unittest process exit code is not zero")

    test_ids = _inventory_ids(inventory)
    stdout = _decode(stdout_bytes, label="stdout")
    stderr = _decode(stderr_bytes, label="stderr")

    if _line_candidates(stdout, ("Ran ", "OK", "FAILED")):
        raise UnittestResultError("unittest canonical result markers appeared on stdout")

    summary_candidates = _line_candidates(stderr, ("Ran ",))
    if len(summary_candidates) != 1:
        raise UnittestResultError("unittest transcript does not contain exactly one summary")
    summary_position, summary_line = summary_candidates[0]
    summary = _SUMMARY_LINE.fullmatch(summary_line)
    if not summary:
        raise UnittestResultError("unittest summary is not canonical")

    terminal_candidates = _line_candidates(stderr, ("OK", "FAILED"))
    if len(terminal_candidates) != 1:
        raise UnittestResultError("unittest transcript does not contain exactly one terminal result")
    terminal_position, terminal_line = terminal_candidates[0]
    terminal = _TERMINAL_LINE.fullmatch(terminal_line)
    if not terminal:
        raise UnittestResultError("unittest terminal result is not an allowed PASS")
    if terminal_position <= summary_position:
        raise UnittestResultError("unittest terminal result precedes its summary")
    reported_count = int(summary.group(1))
    if reported_count != len(test_ids):
        raise UnittestResultError(
            f"unittest summary count {reported_count} does not match inventory {len(test_ids)}"
        )

    # A forged summary must not hide an unlisted result, a failing subtest or
    # an error header outside the segments of inventoried methods.
    emitted = list(re.finditer(r"(?m)^[ \t]*test[A-Za-z0-9_]+ \([^()\n]+\)", stderr))
    if re.search(r"(?m)^(?:FAIL|ERROR):", stderr) or re.search(r"(?m)^(?:FAIL|ERROR):", stdout):
        raise UnittestResultError("unittest transcript contains a failure/error header")

    occurrences = []
    for test_id in test_ids:
        line_start, marker_start, marker_end = _identity_occurrence(stderr, test_id)
        if marker_start >= summary_position:
            raise UnittestResultError(f"unittest result occurs after summary for {test_id}")
        occurrences.append((line_start, marker_start, marker_end, test_id))
    occurrences.sort()
    if len({line_start for line_start, _, _, _ in occurrences}) != len(test_ids):
        raise UnittestResultError("unittest transcript maps multiple tests to one result line")
    if [match.start() for match in emitted] != [item[0] for item in occurrences]:
        raise UnittestResultError("unittest transcript contains an unlisted or ambiguous execution")

    outcomes: dict[str, str] = {}
    allowed_skips: list[dict[str, str]] = []
    for index, (line_start, _marker_start, marker_end, test_id) in enumerate(occurrences):
        segment_end = occurrences[index + 1][0] if index + 1 < len(occurrences) else summary_position
        if segment_end <= line_start:
            raise UnittestResultError("unittest result ordering is inconsistent")
        outcome, reason = _result_from_segment(test_id, stderr[marker_end:segment_end])
        if outcome == "skipped":
            permitted_prefixes = ALLOWED_SKIPS.get(test_id, ())
            if reason is None or not any(reason.startswith(prefix) for prefix in permitted_prefixes):
                raise UnittestResultError(f"unittest skip is not permitted for {test_id}")
            outcomes[test_id] = "skipped"
            allowed_skips.append({"test_id": test_id, "reason": reason})
        elif outcome == "ok":
            outcomes[test_id] = "ok"
        else:
            raise UnittestResultError(f"unittest outcome {outcome} is not PASS for {test_id}")

    reported_skips = int(terminal.group(1) or 0)
    if reported_skips != len(allowed_skips):
        raise UnittestResultError(
            f"unittest terminal skip count {reported_skips} does not match allowed results {len(allowed_skips)}"
        )
    result = {
        "schema_version": inventory["schema_version"],
        "status": "PASS",
        "test_count": reported_count,
        "duration_seconds": float(summary.group(2)),
        "skipped_count": reported_skips,
        "allowed_skips": allowed_skips,
        "outcomes": outcomes,
        "process_exit_code_verified": process_exit_code is not None,
    }
    if inventory["schema_version"] == "1.1.0":
        result.update({
            "method_count": inventory["method_count"],
            "alias_count": inventory["alias_count"],
            "inventory_identity_hash": _canonical_hash(inventory),
        })
    return result


def verify_legacy_test_outcome(
    *,
    stdout_bytes: bytes,
    stderr_bytes: bytes,
    test_name: str,
) -> bool:
    """Verify one test in a pre-inventory maintenance transcript.

    Legacy receipts cannot be upgraded to an inventory-bound proof.  This
    compatibility path still parses every emitted result, refuses non-PASS
    outcomes, and never treats a skipped target as a passing fixture.
    """

    if not isinstance(test_name, str) or not re.fullmatch(r"test[A-Za-z0-9_]+", test_name):
        raise UnittestResultError("legacy unittest target name is invalid")
    stdout = _decode(stdout_bytes, label="stdout")
    stderr = _decode(stderr_bytes, label="stderr")
    if _line_candidates(stdout, ("Ran ", "OK", "FAILED")):
        raise UnittestResultError("legacy unittest canonical result markers appeared on stdout")

    summaries = _line_candidates(stderr, ("Ran ",))
    terminals = _line_candidates(stderr, ("OK", "FAILED"))
    if len(summaries) != 1 or len(terminals) != 1:
        raise UnittestResultError("legacy unittest result envelope is incomplete or ambiguous")
    summary_position, summary_line = summaries[0]
    terminal_position, terminal_line = terminals[0]
    summary = _SUMMARY_LINE.fullmatch(summary_line)
    terminal = _TERMINAL_LINE.fullmatch(terminal_line)
    if not summary or not terminal or terminal_position <= summary_position:
        raise UnittestResultError("legacy unittest result envelope is not an allowed PASS")

    result_pattern = re.compile(
        r"(?m)^(test[A-Za-z0-9_]+) \(((?:tests\.)?test_[A-Za-z0-9_.]+)\)"
    )
    matches = [match for match in result_pattern.finditer(stderr, 0, summary_position)]
    if len(matches) != int(summary.group(1)):
        raise UnittestResultError("legacy unittest result count does not match its summary")

    outcomes: dict[str, str] = {}
    skipped_count = 0
    for index, match in enumerate(matches):
        method_name, runtime_id = match.groups()
        canonical_id = runtime_id if runtime_id.startswith("tests.") else "tests." + runtime_id
        if canonical_id.rsplit(".", 1)[-1] != method_name or canonical_id in outcomes:
            raise UnittestResultError("legacy unittest result identity is inconsistent")
        segment_end = matches[index + 1].start() if index + 1 < len(matches) else summary_position
        outcome, reason = _result_from_segment(canonical_id, stderr[match.end():segment_end])
        if outcome == "skipped":
            prefixes = ALLOWED_SKIPS.get(canonical_id, ())
            if reason is None or not any(reason.startswith(prefix) for prefix in prefixes):
                raise UnittestResultError(f"legacy unittest skip is not permitted for {canonical_id}")
            skipped_count += 1
            outcomes[canonical_id] = "skipped"
        elif outcome == "ok":
            outcomes[canonical_id] = "ok"
        else:
            raise UnittestResultError(
                f"legacy unittest outcome {outcome} is not PASS for {canonical_id}"
            )
    if int(terminal.group(1) or 0) != skipped_count:
        raise UnittestResultError("legacy unittest terminal skip count is inconsistent")
    matching = [outcome for test_id, outcome in outcomes.items() if test_id.endswith("." + test_name)]
    return len(matching) == 1 and matching[0] == "ok"


def consume_execution_result(
    *, result: Any, inventory_bytes: bytes, expected_inventory_hash: str,
    expected_test_count: int, stdout_bytes: bytes, stderr_bytes: bytes,
    process_exit_code: int,
) -> dict[str, Any]:
    """Consume a current verifier response, never a historical PASS shortcut.

    Reconcile the original transcript with the same parser and the caller's
    frozen inventory bytes/count and real process exit. 1.0 has no alias or
    canonical-inventory-identity fields; 1.1 must carry all of them. Neither
    contract is upgraded, and the historical reader's exit=None stays separate.
    """
    if type(process_exit_code) is not int or process_exit_code != 0:
        raise UnittestResultError("consumer requires a real zero process exit code")
    if (not isinstance(expected_inventory_hash, str)
            or not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_inventory_hash)
            or "sha256:" + hashlib.sha256(inventory_bytes).hexdigest() != expected_inventory_hash):
        raise UnittestResultError("consumer inventory bytes differ from the frozen manifest")
    inventory = json.loads(inventory_bytes.decode("utf-8-sig"))
    verified = verify_unittest_result(
        inventory=inventory, stdout_bytes=stdout_bytes, stderr_bytes=stderr_bytes,
        process_exit_code=process_exit_code,
    )
    if type(expected_test_count) is not int or expected_test_count != verified["test_count"]:
        raise UnittestResultError("consumer execution count differs from the frozen manifest")
    expected = {key: value for key, value in verified.items() if key != "outcomes"}
    # Canonical JSON equality also distinguishes bool from int, missing/extra
    # fields, alias identities and skip reasons; ordinary Python == would not.
    if not isinstance(result, dict) or _canonical_hash(result) != _canonical_hash(expected):
        raise UnittestResultError("consumer result is incomplete or differs from its execution-bound contract")
    return expected


def _cli() -> int:
    parser = argparse.ArgumentParser(description="Verify a complete inventoried unittest result")
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--stdout", type=Path, required=True)
    parser.add_argument("--stderr", type=Path, required=True)
    parser.add_argument("--exit-code", type=int, required=True)
    parser.add_argument("--consume-result-stdin", action="store_true")
    parser.add_argument("--expected-inventory-hash")
    parser.add_argument("--expected-test-count", type=int)
    args = parser.parse_args()
    try:
        if args.consume_result_stdin:
            result = consume_execution_result(
                result=json.loads(sys.stdin.read()), inventory_bytes=args.inventory.read_bytes(),
                expected_inventory_hash=args.expected_inventory_hash,
                expected_test_count=args.expected_test_count,
                stdout_bytes=args.stdout.read_bytes(), stderr_bytes=args.stderr.read_bytes(),
                process_exit_code=args.exit_code,
            )
        else:
            if args.expected_inventory_hash is not None or args.expected_test_count is not None:
                raise UnittestResultError("consumer manifest arguments require --consume-result-stdin")
            inventory = json.loads(args.inventory.read_text(encoding="utf-8-sig"))
            result = verify_unittest_result(
                inventory=inventory,
                stdout_bytes=args.stdout.read_bytes(),
                stderr_bytes=args.stderr.read_bytes(),
                process_exit_code=args.exit_code,
            )
    except (OSError, UnicodeError, json.JSONDecodeError, UnittestResultError) as exc:
        print(f"unittest-result verification failed: {exc}", file=sys.stderr)
        return 1
    public_result = {key: value for key, value in result.items() if key != "outcomes"}
    print(json.dumps(public_result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
