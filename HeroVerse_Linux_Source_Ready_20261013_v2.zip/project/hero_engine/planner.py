from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .db import DEFAULT_DB, ROOT, connect, utc_now


HOOK_WORDS = {
    "attack": 2.4, "enemy": 2.2, "god": 1.0, "identity": 2.5,
    "calling": 2.1, "chosen": 2.4, "breakthrough": 2.3, "warning": 2.2,
    "before": 1.1, "secret": 2.0, "truth": 1.8, "never": 1.2,
    "stop": 1.5, "now": 1.0, "purpose": 1.6, "destiny": 1.8,
    "confusion": 1.7, "doubt": 1.7, "victory": 1.8, "pressure": 1.3,
}

EMOTION_WORDS = {
    "fear", "alone", "rejected", "loved", "pain", "hardship", "frustrated",
    "disheartened", "vulnerable", "wilderness", "promotion", "glory", "mercy",
    "compassion", "favor", "insecurity", "uncertainty", "freedom", "hope",
}

HOOK_THREAT_WORDS = {
    "attack", "attacks", "enemy", "devil", "danger", "warning", "pressure",
    "lose", "lost", "break", "steal", "war", "battle",
}
HOOK_STAKE_WORDS = {
    "calling", "identity", "future", "purpose", "destiny", "breakthrough",
    "decision", "faith", "life", "god",
}
HOOK_SEQUENCE_WORDS = {"before", "first", "next", "now", "already", "finally"}
HOOK_OPEN_LOOP_WORDS = {"why", "how", "this", "these", "what", "if", "secret", "truth"}
HOOK_GREETING_WORDS = {"welcome", "hello", "hi", "channel", "subscribe"}
HOOK_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from",
    "has", "have", "he", "in", "is", "it", "of", "on", "or", "that", "the",
    "to", "was", "will", "with", "you", "your",
}


@dataclass
class TranscriptLine:
    start: float
    text: str


def parse_timestamp(value: str) -> float:
    parts = [float(part) for part in value.split(":")]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    return parts[0]


def parse_transcript(body: str) -> list[TranscriptLine]:
    lines: list[TranscriptLine] = []
    for raw in body.splitlines():
        match = re.match(r"\[(\d+(?::\d+){1,2})\]\s*(.+)", raw.strip())
        if match:
            lines.append(TranscriptLine(parse_timestamp(match.group(1)), match.group(2).strip()))
    return lines


def score_text(text: str) -> tuple[float, float, float, float]:
    lowered = text.lower()
    words = re.findall(r"[a-z']+", lowered)
    hook = sum(HOOK_WORDS.get(word, 0.0) for word in words)
    hook += 1.5 if "?" in text else 0
    hook += 1.2 if any(token in lowered for token in ("could it be", "listen", "hear this", "notice")) else 0
    clarity = max(0.0, 8.0 - abs(len(words) - 24) * 0.18)
    emotion = sum(1.15 for word in words if word in EMOTION_WORDS)
    total = hook * 0.5 + clarity * 0.25 + emotion * 0.25
    return hook, clarity, emotion, total


def _words(text: str) -> list[str]:
    return re.findall(r"[a-z']+", text.lower())


def analyze_hook(text: str) -> dict[str, Any]:
    """Score observable hook mechanics; this is a pre-publication gate, not a view forecast."""
    words = _words(text)
    word_set = set(words)
    first_sentence = re.split(r"[.!?]", text, maxsplit=1)[0]
    first_sentence_words = _words(first_sentence)
    mechanics = {
        "personal_relevance": bool({"you", "your"} & word_set),
        "tension_or_stakes": bool(HOOK_THREAT_WORDS & word_set) and bool(HOOK_STAKE_WORDS & word_set),
        "order_or_timing": bool(HOOK_SEQUENCE_WORDS & word_set),
        "curiosity_gap": bool(HOOK_OPEN_LOOP_WORDS & word_set) or "not" in word_set,
        "reversal": "not" in word_set or "instead" in word_set or "but" in word_set,
        "concise_first_claim": 4 <= len(first_sentence_words) <= 12,
        "no_greeting": not bool(HOOK_GREETING_WORDS & set(words[:8])),
    }
    weights = {
        "personal_relevance": 1.0,
        "tension_or_stakes": 2.0,
        "order_or_timing": 1.5,
        "curiosity_gap": 1.5,
        "reversal": 1.5,
        "concise_first_claim": 1.5,
        "no_greeting": 1.0,
    }
    score = sum(weights[name] for name, present in mechanics.items() if present)
    return {
        "score": round(score, 3),
        "maximum": round(sum(weights.values()), 3),
        "word_count": len(words),
        "first_claim_words": len(first_sentence_words),
        "mechanics": mechanics,
    }


def ngram_overlap(candidate: str, reference: str, n: int = 3) -> float:
    def ngrams(value: str) -> set[tuple[str, ...]]:
        tokens = [word for word in _words(value) if word not in HOOK_STOPWORDS]
        if len(tokens) < n:
            return {tuple(tokens)} if tokens else set()
        return {tuple(tokens[index:index + n]) for index in range(len(tokens) - n + 1)}

    candidate_ngrams = ngrams(candidate)
    reference_ngrams = ngrams(reference)
    if not candidate_ngrams:
        return 1.0
    return round(len(candidate_ngrams & reference_ngrams) / len(candidate_ngrams), 4)


def mine_hook_blueprint(
    video_id: str,
    window_seconds: float = 18.0,
    db_path: Path | None = None,
) -> dict[str, Any]:
    """Extract mechanics from the opening of a performance-evidenced source.

    Views establish that the source earned attention; they do not prove the hook caused it.
    """
    target_db = db_path or DEFAULT_DB
    with connect(target_db) as conn:
        row = conn.execute(
            """
            SELECT t.body, v.views, v.title, v.url
            FROM transcripts t JOIN videos v ON v.video_id=t.video_id
            WHERE t.video_id=?
            """,
            (video_id,),
        ).fetchone()
    if not row:
        raise ValueError(f"No transcript stored for {video_id}. Run transcript first.")
    lines = parse_transcript(row["body"])
    selected = [line for line in lines if line.start < window_seconds]
    cursor = len(selected)
    while selected and not re.search(r"[.!?]['\"]?$", selected[-1].text) and cursor < len(lines):
        if lines[cursor].start > window_seconds + 6:
            break
        selected.append(lines[cursor])
        cursor += 1
    observed_text = " ".join(line.text for line in selected).strip()
    if not observed_text:
        raise ValueError(f"Transcript for {video_id} has no opening text")
    analysis = analyze_hook(observed_text)
    result = {
        "video_id": video_id,
        "title": row["title"],
        "url": row["url"],
        "source_views": row["views"],
        "observed_window_seconds": window_seconds,
        "observed_text": observed_text,
        "analysis": analysis,
        "evidence_class": "performance_evidenced_not_causal_proof",
        "replication_rule": "model mechanics and timing; write new wording, examples, sequence, and payoff",
    }
    with connect(target_db) as conn:
        conn.execute(
            """
            INSERT INTO hook_blueprints
            (video_id, observed_window_seconds, observed_text, source_views,
             mechanics_json, hook_score, evidence_class, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(video_id) DO UPDATE SET
                observed_window_seconds=excluded.observed_window_seconds,
                observed_text=excluded.observed_text,
                source_views=excluded.source_views,
                mechanics_json=excluded.mechanics_json,
                hook_score=excluded.hook_score,
                evidence_class=excluded.evidence_class,
                created_at=excluded.created_at
            """,
            (
                video_id, window_seconds, observed_text, row["views"],
                json.dumps(analysis["mechanics"]), analysis["score"],
                result["evidence_class"], utc_now(),
            ),
        )
    return result


def mine_clip_candidates(video_id: str, min_seconds: float = 4, max_seconds: float = 12, db_path: Path | None = None) -> list[dict[str, Any]]:
    with connect(db_path or DEFAULT_DB) as conn:
        row = conn.execute("SELECT body FROM transcripts WHERE video_id=?", (video_id,)).fetchone()
    if not row:
        raise ValueError(f"No transcript stored for {video_id}. Run transcript first.")
    lines = parse_transcript(row["body"])
    candidates: list[dict[str, Any]] = []
    for index, line in enumerate(lines):
        words: list[str] = []
        end = line.start
        cursor = index
        while cursor < len(lines):
            current = lines[cursor]
            next_start = lines[cursor + 1].start if cursor + 1 < len(lines) else current.start + 3
            end = max(end, next_start)
            words.append(current.text)
            duration = end - line.start
            if duration >= min_seconds:
                text = " ".join(words)
                hook, clarity, emotion, total = score_text(text)
                if duration <= max_seconds:
                    candidates.append(
                        {
                            "video_id": video_id,
                            "start_seconds": round(line.start, 2),
                            "end_seconds": round(end, 2),
                            "transcript_text": text,
                            "hook_score": round(hook, 3),
                            "clarity_score": round(clarity, 3),
                            "emotion_score": round(emotion, 3),
                            "total_score": round(total, 3),
                        }
                    )
                break
            if duration > max_seconds:
                break
            cursor += 1
    candidates.sort(key=lambda item: item["total_score"], reverse=True)
    top = candidates[:40]
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute("DELETE FROM clip_candidates WHERE video_id=?", (video_id,))
        for item in top:
            conn.execute(
                """
                INSERT INTO clip_candidates
                (video_id, start_seconds, end_seconds, transcript_text,
                 hook_score, clarity_score, emotion_score, total_score, approved, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                """,
                (
                    item["video_id"], item["start_seconds"], item["end_seconds"],
                    item["transcript_text"], item["hook_score"], item["clarity_score"],
                    item["emotion_score"], item["total_score"], utc_now(),
                ),
            )
    return top


def pilot_short_edl() -> dict[str, Any]:
    return {
        "slug": "identity-attack-before-calling-short-01",
        "format": "short",
        "pillar": "chosen_identity_calling",
        "thesis": "The enemy attacks your identity before he attacks your calling.",
        "title_variants": [
            "The Enemy Attacks Your Identity First",
            "Why Spiritual Attacks Hit Before Your Calling",
            "If God Is Calling You, Expect This Attack",
        ],
        "thumbnail_text_variants": ["IDENTITY FIRST", "NOT YOUR CALLING", "PROTECT THE FOUNDATION"],
        "hook_blueprint": {
            "pattern": "threat -> reversal -> proof -> consequence -> response -> payoff",
            "source_video_id": "5-zdruoQKlM",
            "source_views_observed": 894000,
            "source_hook_text": (
                "Just before God uses you, the enemy will try these attacks on you. "
                "Could it be the attack you're experiencing now is the final step before "
                "you step into a breakthrough, a promotion into the divine destiny that God has for you?"
            ),
            "evidence_class": "performance_evidenced_not_causal_proof",
            "first_proof_deadline_seconds": 4.0,
            "maximum_trigram_overlap": 0.35,
            "research_basis": [
                "YouTube Shorts: hook in the first second; shock, intrigue, satisfy",
                "YouTube retention: move compelling moments earlier and match the packaging promise",
            ],
        },
        "metadata": {
            "primary_title": "The Enemy Attacks Your Identity First",
            "description": (
                "Before the enemy pressures your calling, he attacks the identity you need to carry it. "
                "This Short shows how doubt turns into performance—and the faithful response that breaks the pattern.\n\n"
                "What pressure are you refusing to obey today?\n\n"
                "SOURCE EXCERPT\n"
                "Right Before God Uses You, the Devil Will Try These Attacks — David Diga Hernandez\n"
                "https://www.youtube.com/watch?v=5-zdruoQKlM\n"
                "Creative Commons Attribution (CC BY); license verified on YouTube on 2026-09-01.\n\n"
                "Original thesis, narration, structure, captions, and editing by HeroVerse.\n\n"
                "#ChristianMotivation #SpiritualWarfare #IdentityInChrist"
            ),
            "tags": [
                "Christian motivation", "spiritual warfare", "identity in Christ",
                "God's calling", "Christian Shorts", "faith", "spiritual attack", "HeroVerse",
            ],
            "pinned_comment": (
                "Which pressure do you recognize most right now—identity, approval, or fear? "
                "Reply with one word; the next message will address the most common answer."
            ),
            "category_id": "27",
        },
        "source_video_ids": ["5-zdruoQKlM"],
        "target_duration_seconds": 39.4,
        "segments": [
            {
                "type": "voiceover",
                "visual_role": "hook",
                "text": "The enemy attacks your identity first, not your calling.",
                "screen_text": "IDENTITY FIRST. NOT CALLING.",
                "caption_beats": [
                    {"start": 0.0, "end": 1.05, "text": "THE ENEMY ATTACKS"},
                    {"start": 1.05, "end": 2.15, "text": "YOUR IDENTITY FIRST"},
                    {"start": 2.15, "end": 3.2, "text": "NOT YOUR CALLING"},
                ],
                "background_start": 0,
                "target_seconds": 3.2,
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 193,
                "end_seconds": 199,
                "screen_text": "THE FOUNDATION OF YOUR CALLING",
            },
            {
                "type": "voiceover",
                "text": "Because doubt changes what you believe before it changes what you do. Then it reaches your next decision, your boundaries, and the assignment you keep delaying.",
                "screen_text": "BELIEF SHAPES BEHAVIOR",
                "caption_beats": [
                    {"start": 0.0, "end": 2.5, "text": "DOUBT CHANGES\nWHAT YOU BELIEVE"},
                    {"start": 2.5, "end": 5.0, "text": "BEFORE IT CHANGES\nWHAT YOU DO"},
                    {"start": 5.0, "end": 7.5, "text": "THEN YOU DELAY\nTHE ASSIGNMENT"},
                ],
                "background_start": 198,
                "target_seconds": 7.5,
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 810,
                "end_seconds": 815,
                "screen_text": "PRESSURE TO PERFORM",
            },
            {
                "type": "voiceover",
                "text": "Pressure makes you prove what God has already promised. You force doors, perform for approval, and call panic obedience. Stop. Return to what God said, then take the next faithful step.",
                "screen_text": "PRESSURE IS NOT OBEDIENCE",
                "caption_beats": [
                    {"start": 0.0, "end": 2.7, "text": "PRESSURE MAKES YOU\nPROVE THE PROMISE"},
                    {"start": 2.7, "end": 5.4, "text": "YOU FORCE DOORS\nFOR APPROVAL"},
                    {"start": 5.4, "end": 8.1, "text": "DO NOT CALL PANIC\nOBEDIENCE"},
                    {"start": 8.1, "end": 11.5, "text": "RETURN. THEN TAKE\nTHE FAITHFUL STEP"},
                ],
                "background_start": 815,
                "target_seconds": 11.5,
            },
            {
                "type": "voiceover",
                "visual_role": "payoff",
                "text": "If your identity is under attack, do not panic. Protect the foundation, and your calling can move forward.",
                "screen_text": "PROTECT THE FOUNDATION",
                "caption_beats": [
                    {"start": 0.0, "end": 2.1, "text": "DO NOT PANIC"},
                    {"start": 2.1, "end": 4.2, "text": "PROTECT THE\nFOUNDATION"},
                    {"start": 4.2, "end": 6.2, "text": "MOVE YOUR CALLING\nFORWARD"},
                ],
                "background_start": 1182,
                "target_seconds": 6.2,
            },
        ],
        "attribution": {
            "work_title": "Right Before God Uses You, the Devil Will Try These Attacks",
            "author": "David Diga Hernandez",
            "source": "https://www.youtube.com/watch?v=5-zdruoQKlM",
            "license": "Creative Commons Attribution (CC BY), verified on YouTube 2026-09-01",
        },
        "status": "planned",
        "created_at": utc_now(),
    }


def modeled_long_edl() -> dict[str, Any]:
    """First long-form production shaped by the empirical 3–5 minute model.

    Reference excerpts come only from the catalogued CC source. The reference
    channel itself is never treated as a reusable source.
    """
    return {
        "slug": "protect-your-identity-long-01",
        "model_id": "grace-grit-love-3to5-v1",
        "format": "long",
        "canvas": "16:9",
        "pillar": "chosen_identity_calling",
        "thesis": "The spiritual battle targets identity because identity governs how a calling is carried.",
        "title_variants": [
            "PROTECT YOUR IDENTITY | Christian Motivation",
            "THE BATTLE STARTS WITH IDENTITY | Christian Motivation",
            "DON'T LET THE ENEMY NAME YOU | Christian Motivation",
        ],
        "thumbnail_text_variants": ["IDENTITY FIRST", "WHO NAMED YOU?", "PROTECT THE ROOT"],
        "hook_blueprint": {
            "observed_winner_function": "standalone declaration -> immediate spiritual stakes -> authority proof",
            "adaptation": "remove the model channel's silent bumper and start the promise at 0.0s",
            "first_complete_claim_deadline_seconds": 3.2,
            "opening_gate_minimum": 7.5,
            "source_reference_channel": "Grace, Grit & Love (format reference only; no assets reused)",
            "evidence_class": "controlled_top_vs_bottom_opening_comparison",
        },
        "metadata": {
            "primary_title": "PROTECT YOUR IDENTITY | Christian Motivation",
            "description": (
                "The battle often reaches your identity before it reaches your assignment. "
                "This message exposes how doubt becomes pressure, how pressure becomes performance, "
                "and how to return to what God has already said about you.\n\n"
                "What false name or pressure are you refusing today?\n\n"
                "SOURCE EXCERPTS\n"
                "Right Before God Uses You, the Devil Will Try These Attacks — David Diga Hernandez\n"
                "https://www.youtube.com/watch?v=5-zdruoQKlM\n"
                "Creative Commons Attribution (CC BY); license verified on YouTube on 2026-09-01.\n\n"
                "Original thesis, narration, structure, motion design, and editing by HeroVerse.\n\n"
                "#ChristianMotivation #IdentityInChrist #SpiritualWarfare"
            ),
            "tags": [
                "Christian motivation", "identity in Christ", "spiritual warfare",
                "God's calling", "faith under pressure", "Christian encouragement",
                "purpose", "HeroVerse",
            ],
            "pinned_comment": (
                "Which pressure tries to rename you most often—fear, approval, or doubt? "
                "Answer with one word; the next message will address the most common response."
            ),
            "category_id": "27",
        },
        "source_video_ids": ["5-zdruoQKlM"],
        "target_duration_seconds": 230.0,
        "segments": [
            {
                "type": "voiceover",
                "narrative_role": "declaration_and_proof",
                "visual_role": "hook",
                "text": "The battle starts with your identity.",
                "screen_text": "THE BATTLE STARTS HERE",
                "target_seconds": 3.0,
                "visual_plan": "Cold open: solitary figure facing a storm; small persistent HeroVerse mark, no bumper.",
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 193.0,
                "end_seconds": 201.0,
                "screen_text": "IDENTITY IS THE FOUNDATION",
                "narrative_job": "authority proof for the opening declaration",
            },
            {
                "type": "voiceover",
                "narrative_role": "personal_stakes",
                "text": (
                    "That is why the pressure feels so personal. Before you abandon an assignment, "
                    "you begin to question whether you were ever called. Before you force a door, "
                    "you begin to doubt whether God will open one. Fear does not need to destroy your gift; "
                    "it only needs to make you carry that gift like an orphan instead of a child who belongs."
                ),
                "screen_text": "PRESSURE BECOMES A NAME",
                "target_seconds": 31.0,
                "visual_plan": "Concrete consequences: closed door, mirror, unfinished work, hands releasing a handle.",
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 278.0,
                "end_seconds": 286.0,
                "screen_text": "CONFIDENCE UNDER ATTACK",
                "narrative_job": "name the mechanism linking confidence and calling",
            },
            {
                "type": "voiceover",
                "narrative_role": "mechanism",
                "text": (
                    "Watch the sequence. Doubt first changes the sentence inside your mind. Then the sentence "
                    "changes the decision in front of you. You delay what requires courage, perform for people "
                    "who cannot confirm your purpose, and call panic obedience. The enemy does not always need "
                    "a dramatic collapse. A smaller strategy is enough: make you prove today what God asked you "
                    "to trust over time. When urgency replaces conviction, you become busy without becoming faithful."
                ),
                "screen_text": "DOUBT → PRESSURE → PERFORMANCE",
                "target_seconds": 40.0,
                "visual_plan": "Three-stage visual sequence; each concept receives its own visual motif and sound accent.",
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 810.0,
                "end_seconds": 819.0,
                "screen_text": "PRESSURE TO PERFORM",
                "narrative_job": "independent evidence for the pressure mechanism",
            },
            {
                "type": "voiceover",
                "narrative_role": "scripture_or_authority",
                "text": (
                    "Jesus answered temptation from a settled identity. He did not turn stones into bread to prove "
                    "the Father's words. He did not jump from the temple to force public validation. He did not accept "
                    "a kingdom without the cross. In every test, the answer began with what was already written. "
                    "The lesson is not passivity. It is alignment: truth before appetite, obedience before applause, "
                    "and worship before the shortcut that promises power without formation."
                ),
                "screen_text": "IT IS ALREADY WRITTEN",
                "target_seconds": 36.0,
                "visual_plan": "Open Bible, wilderness, high place, then a quiet refusal; avoid literal copyrighted film scenes.",
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 1167.0,
                "end_seconds": 1179.0,
                "screen_text": "REFUSE THE FALSE VOICE",
                "narrative_job": "authority statement that sets up the reversal",
            },
            {
                "type": "voiceover",
                "narrative_role": "reversal",
                "text": (
                    "So reverse the pattern. Do not answer fear with performance. Answer it with agreement. "
                    "Name what God said before you name what you feel. Let the next faithful action be smaller than "
                    "your anxiety and stronger than your hesitation. You do not need to manufacture a breakthrough. "
                    "You need to stop negotiating with the voice that says love, provision, and purpose must be earned. "
                    "Identity is received before calling is carried."
                ),
                "screen_text": "AGREEMENT, NOT PERFORMANCE",
                "target_seconds": 33.0,
                "visual_plan": "Visual movement changes from compression and darkness to open space and forward motion.",
            },
            {
                "type": "source_clip",
                "video_id": "5-zdruoQKlM",
                "start_seconds": 1182.0,
                "end_seconds": 1190.0,
                "screen_text": "KNOW WHO YOU ARE",
                "narrative_job": "state the resolution principle in the licensed speaker's own complete context",
            },
            {
                "type": "voiceover",
                "narrative_role": "crescendo_and_action",
                "text": (
                    "Today, write one sentence you have been obeying that God never spoke. Put the truth beside it. "
                    "Then take one action that agrees with the truth: finish the work, make the call, close the wrong door, "
                    "or wait without forcing the right one. Courage is not noise. Sometimes courage is a quiet decision "
                    "to remain faithful while pressure demands a performance. The battle loses ground every time your next "
                    "step comes from belonging instead of fear."
                ),
                "screen_text": "TAKE THE FAITHFUL STEP",
                "target_seconds": 30.0,
                "visual_plan": "Specific action montage synchronized to four verbs; music rises but narration stays intelligible.",
            },
            {
                "type": "voiceover",
                "narrative_role": "identity_resolution",
                "visual_role": "payoff",
                "text": (
                    "Protect the name God gave you. A calling carried from identity does not need fear to move forward."
                ),
                "screen_text": "IDENTITY BEFORE ASSIGNMENT",
                "target_seconds": 12.0,
                "visual_plan": "Return to opening figure, now moving through the storm; resolve music cleanly without CTA speech.",
            },
        ],
        "attribution": {
            "work_title": "Right Before God Uses You, the Devil Will Try These Attacks",
            "author": "David Diga Hernandez",
            "source": "https://www.youtube.com/watch?v=5-zdruoQKlM",
            "license": "Creative Commons Attribution (CC BY), verified on YouTube 2026-09-01",
        },
        "status": "model_preflight_pending",
        "created_at": utc_now(),
    }


def save_production(edl: dict[str, Any], db_path: Path | None = None) -> Path:
    output_dir = ROOT / "output" / "edl"
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{edl['slug']}.json"
    path.write_text(json.dumps(edl, ensure_ascii=False, indent=2), encoding="utf-8")
    stamp = utc_now()
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute(
            """
            INSERT INTO productions
            (slug, format, pillar, thesis, source_video_ids, status, edl_path,
             approval_required, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
            ON CONFLICT(slug) DO UPDATE SET
                format=excluded.format, pillar=excluded.pillar, thesis=excluded.thesis,
                source_video_ids=excluded.source_video_ids, status=excluded.status,
                edl_path=excluded.edl_path, updated_at=excluded.updated_at
            """,
            (
                edl["slug"], edl["format"], edl["pillar"], edl["thesis"],
                json.dumps(edl["source_video_ids"]), edl["status"], str(path), stamp, stamp,
            ),
        )
    return path
