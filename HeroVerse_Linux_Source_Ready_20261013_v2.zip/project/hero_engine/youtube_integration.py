from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
YOUTUBE_READ_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
YOUTUBE_UPLOAD_SCOPE = "https://www.googleapis.com/auth/youtube.upload"
YOUTUBE_ANALYTICS_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
YOUTUBE_FORCE_SSL_SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl"
INTEGRATION_SCOPES = [
    YOUTUBE_READ_SCOPE,
    YOUTUBE_ANALYTICS_SCOPE,
    YOUTUBE_UPLOAD_SCOPE,
    YOUTUBE_FORCE_SSL_SCOPE,
]
INTERACTIVE_OAUTH_PROMPT = "consent select_account"
ANALYTICS_METRICS = [
    "views",
    "estimatedMinutesWatched",
    "averageViewDuration",
    "averageViewPercentage",
    "subscribersGained",
    "subscribersLost",
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _receipt_id(channel_id: str | None, created_at: str) -> str:
    value = hashlib.sha256(f"youtube-heroverse-v1|{channel_id}|{created_at}".encode()).hexdigest()[:20]
    return f"yt-connection-{value}"


def _as_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)


def _write_secret_atomically(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temporary, stat.S_IREAD | stat.S_IWRITE)
        except OSError:
            pass
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_or_authorize_credentials(
    credentials_file: Path | None,
    token_file: Path,
    *,
    authorize: bool,
    force_reauthorize: bool = False,
    scopes: list[str] | None = None,
) -> Any:
    """Load an OAuth token or run the installed-app flow. Never logs secret material."""
    requested = scopes or INTEGRATION_SCOPES
    try:
        from google.auth.exceptions import RefreshError  # type: ignore
        from google.auth.transport.requests import Request  # type: ignore
        from google.oauth2.credentials import Credentials  # type: ignore
        from google_auth_oauthlib.flow import InstalledAppFlow  # type: ignore
    except ImportError as exc:  # pragma: no cover - installation failure is environment-specific
        raise RuntimeError("Google OAuth dependencies are not installed") from exc

    if force_reauthorize and not authorize:
        raise ValueError("force_reauthorize requires authorize=True")

    creds = None
    if token_file.is_file() and not force_reauthorize:
        creds = Credentials.from_authorized_user_file(str(token_file), requested)
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as exc:
            if not authorize:
                raise PermissionError(
                    "The stored OAuth token cannot refresh the requested scopes; rerun with --authorize"
                ) from exc
            # Preserve the old token on disk. A newly consented token replaces it only
            # after the loopback flow completes successfully below.
            creds = None
    if not creds or not creds.valid or not creds.has_scopes(requested):
        if not authorize:
            raise PermissionError("OAuth authorization is required; rerun with --authorize")
        if credentials_file is not None and credentials_file.is_file():
            flow = InstalledAppFlow.from_client_secrets_file(str(credentials_file), requested)
        elif token_file.is_file():
            token_client = json.loads(token_file.read_text(encoding="utf-8-sig"))
            required_client_fields = ("client_id", "client_secret", "token_uri")
            if not all(token_client.get(field) for field in required_client_fields):
                raise FileNotFoundError(
                    "OAuth client file is absent and the preserved token does not contain reusable client metadata"
                )
            client_config = {
                "installed": {
                    "client_id": token_client["client_id"],
                    "client_secret": token_client["client_secret"],
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": token_client["token_uri"],
                    "redirect_uris": ["http://localhost"],
                }
            }
            flow = InstalledAppFlow.from_client_config(client_config, requested)
        else:
            raise FileNotFoundError("OAuth client metadata is unavailable")
        creds = flow.run_local_server(
            host="127.0.0.1",
            port=0,
            open_browser=True,
            access_type="offline",
            # Never inherit whichever Google session happens to be active in a
            # shared browser profile. Google owns the credential UI; the operator
            # explicitly selects the intended account and grants consent there.
            prompt=INTERACTIVE_OAUTH_PROMPT,
        )
        _write_secret_atomically(token_file, creds.to_json())
        try:
            os.chmod(token_file, stat.S_IREAD | stat.S_IWRITE)
        except OSError:
            pass
    return creds


def _build_services(credentials: Any) -> tuple[Any, Any]:
    try:
        from googleapiclient.discovery import build  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Google API client is not installed") from exc
    return (
        build("youtube", "v3", credentials=credentials, cache_discovery=False),
        build("youtubeAnalytics", "v2", credentials=credentials, cache_discovery=False),
    )


def probe_owned_channel(
    youtube: Any,
    analytics: Any,
    *,
    expected_handle: str = "@heroverse74",
    expected_channel_id: str | None = None,
    granted_scopes: list[str] | None = None,
    token_created: bool = True,
    today: date | None = None,
) -> dict[str, Any]:
    observed_at = _now()
    end = (today or date.today()) - timedelta(days=1)
    start = end - timedelta(days=27)
    mine = youtube.channels().list(part="id,snippet,statistics", mine=True).execute()
    mine_items = mine.get("items") or []
    if len(mine_items) != 1:
        raise RuntimeError(f"Expected one authorized YouTube channel, observed {len(mine_items)}")
    item = mine_items[0]
    channel_id = item["id"]
    handle_lookup = youtube.channels().list(
        part="id", forHandle=expected_handle.lstrip("@")
    ).execute()
    expected_ids = {candidate["id"] for candidate in handle_lookup.get("items") or []}
    identity_verified = channel_id in expected_ids and (
        expected_channel_id is None or channel_id == expected_channel_id
    )
    snippet = item.get("snippet") or {}
    statistics = item.get("statistics") or {}

    analytics_status = "NOT_RUN"
    analytics_rows = 0
    failure: str | None = None
    if identity_verified:
        try:
            report = analytics.reports().query(
                ids="channel==MINE",
                startDate=start.isoformat(),
                endDate=end.isoformat(),
                metrics=",".join(ANALYTICS_METRICS),
                dimensions="day",
                sort="day",
            ).execute()
            analytics_rows = len(report.get("rows") or [])
            analytics_status = "PASS" if analytics_rows else "EMPTY"
        except Exception as exc:  # API error is captured without token/request payload
            analytics_status = "FAILED"
            failure = f"{type(exc).__name__}: {exc}"

    status = "CONNECTED" if identity_verified and analytics_status in {"PASS", "EMPTY"} else (
        "IDENTITY_MISMATCH" if not identity_verified else "FAILED"
    )
    granted = sorted(set(granted_scopes or []))
    has_upload = YOUTUBE_UPLOAD_SCOPE in granted
    has_caption_upload = YOUTUBE_FORCE_SSL_SCOPE in granted
    capabilities = [
        {"capability": "CHANNEL_READ", "status": "CONNECTED" if identity_verified else "FAILED", "reason": "authorized channel identity matched expected handle" if identity_verified else "authorized channel did not match expected handle"},
        {"capability": "ANALYTICS_READ", "status": "CONNECTED" if analytics_status in {"PASS", "EMPTY"} else "FAILED", "reason": f"28-day owner report probe returned {analytics_rows} daily rows" if analytics_status in {"PASS", "EMPTY"} else "owner report probe failed or was not run"},
        {"capability": "UPLOAD", "status": "CONFIGURED_BLOCKED" if has_upload else "NOT_REQUESTED", "reason": "OAuth scope granted; local dry-run and human gate still block calls" if has_upload else "upload scope was not granted"},
        {"capability": "CUSTOM_THUMBNAIL", "status": "CONFIGURED_BLOCKED" if has_upload else "NOT_REQUESTED", "reason": "thumbnail adapter shares upload scope and remains policy-blocked" if has_upload else "upload scope was not granted"},
        {"capability": "CAPTION_AND_PUBLICATION_FINALIZATION", "status": "CONFIGURED_BLOCKED" if has_caption_upload else "NOT_REQUESTED", "reason": "youtube.force-ssl is granted but policy restricts this integration to captions.insert and videos.update(status.privacyStatus only) after release gates" if has_caption_upload else "youtube.force-ssl was not granted; verified captions and private-to-public finalization cannot run automatically"},
        {"capability": "MONETARY_ANALYTICS", "status": "NOT_REQUESTED", "reason": "monetary scope deferred until YPP eligibility and explicit need"},
    ]
    return {
        "schema_version": "1.0.0",
        "receipt_id": _receipt_id(channel_id, observed_at),
        "integration_id": "youtube-heroverse-v1",
        "status": status,
        "expected_channel": {"handle": expected_handle, "channel_id": expected_channel_id},
        "observed_channel": {
            "channel_id": channel_id,
            "title": snippet.get("title") or "",
            "custom_url": snippet.get("customUrl"),
            "subscriber_count": _as_int(statistics.get("subscriberCount")),
            "video_count": _as_int(statistics.get("videoCount")),
            "view_count": _as_int(statistics.get("viewCount")),
        },
        "identity_verified": identity_verified,
        "capabilities": capabilities,
        "authorization": {
            "oauth_flow": "INSTALLED_APP_LOOPBACK",
            "requested_scopes": INTEGRATION_SCOPES,
            "granted_scopes": granted,
            "token_storage": "LOCAL_OUTSIDE_WORKSPACE" if token_created else "NOT_CREATED",
            "secret_logged": False,
        },
        "analytics_probe": {
            "status": analytics_status,
            "start_date": start.isoformat(),
            "end_date": end.isoformat(),
            "metrics": ANALYTICS_METRICS,
            "row_count": analytics_rows,
            "private_values_persisted": False,
        },
        "publication_guard": {
            "publish_mode": "dry-run",
            "human_review": "PENDING",
            "format_pack_status": "PROTOTYPED",
            "upload_permitted": False,
        },
        "failure": failure,
        "external_cost_usd": 0,
        "created_at": observed_at,
    }


def connect_owned_channel(
    credentials_file: Path | None,
    token_file: Path,
    receipt_file: Path,
    *,
    authorize: bool,
    force_reauthorize: bool = False,
    expected_handle: str = "@heroverse74",
    expected_channel_id: str | None = None,
    token_mirror_file: Path | None = None,
    token_mirror_receipt_file: Path | None = None,
) -> dict[str, Any]:
    creds = load_or_authorize_credentials(
        credentials_file,
        token_file,
        authorize=authorize,
        force_reauthorize=force_reauthorize,
        scopes=INTEGRATION_SCOPES,
    )
    if token_mirror_file is not None:
        if token_mirror_receipt_file is None:
            raise ValueError("token_mirror_receipt_file is required with token_mirror_file")
        from .oauth_token_mirror import mirror_authorized_user_token

        mirror_authorized_user_token(
            token_file,
            token_mirror_file,
            token_mirror_receipt_file,
            root=ROOT,
            required_scopes=INTEGRATION_SCOPES,
        )
    youtube, analytics = _build_services(creds)
    receipt = probe_owned_channel(
        youtube,
        analytics,
        expected_handle=expected_handle,
        expected_channel_id=expected_channel_id,
        granted_scopes=list(creds.granted_scopes or creds.scopes or []),
        token_created=token_file.is_file(),
    )
    receipt_file.parent.mkdir(parents=True, exist_ok=True)
    receipt_file.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    return receipt
