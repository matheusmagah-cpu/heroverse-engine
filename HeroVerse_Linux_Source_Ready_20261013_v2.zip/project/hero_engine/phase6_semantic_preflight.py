from __future__ import annotations

import hashlib
import json
import os
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from jsonschema import Draft202012Validator, FormatChecker


CONTRACT_VERSION = "phase6-semantic-preflight-v1"
SCHEMA_VERSION = "1.0.0"
SCHEMA_NAME = "phase6_semantic_preflight.schema.json"
DIAGNOSTIC_AUDIT_ROOT = Path(
    "output/qa/phase6/diagnostics/semantic-preflight-v1/audits"
)

# A family is useful for sourcing atmosphere.  It is not evidence that a clip
# communicates a concrete mechanism, object, relationship or infographic.
ROLE_FAMILIES = {
    "tension": {"hook_threshold", "tension", "pressure", "contemplation"},
    "action": {
        "decision",
        "work_step",
        "progress",
        "relationship_repair",
        "skill_question",
        "phone_down",
        "trusted_counsel",
        "decision_cards",
        "action_plan",
    },
    "explanation": {
        "perspective",
        "clarity",
        "scriptural_mechanism",
        "truth_test_infographic",
        "responsibility_map_infographic",
        "today_timeline_infographic",
        "safe_boundaries",
        "safety_network_infographic",
    },
    "resolution": {"transition", "release", "renewal"},
}

COMPATIBLE_ATMOSPHERIC_FAMILIES = {
    "tension": {"tension", "explanation", "action"},
    "action": {"action", "explanation", "resolution"},
    "explanation": {"explanation", "action", "resolution"},
    "resolution": {"resolution", "action", "explanation", "tension"},
}

# These names describe a concrete thing, action, relationship, boundary or
# mechanism.  A broad family label cannot stand in for them.  Infographic roles
# are also detected by suffix so a newly named infographic fails closed without
# waiting for this set to be expanded.
EXPLICIT_CONCRETE_ROLES = frozenset(
    {
        "hook_threshold",
        "decision",
        "work_step",
        "relationship_repair",
        "skill_question",
        "phone_down",
        "trusted_counsel",
        "decision_cards",
        "action_plan",
        "scriptural_mechanism",
        "safe_boundaries",
    }
)

FRAMEWORK_ORDER = {
    "HIDDEN": 0,
    "INTRODUCED": 1,
    "TRUTH": 2,
    "RESPONSIBILITY": 3,
    "TODAY": 4,
    "COMPLETE": 5,
}


class SemanticPreflightError(PermissionError):
    """A semantic contract failed before production artifacts were replaced."""

    def __init__(self, message: str, audit: dict[str, Any]) -> None:
        super().__init__(message)
        self.audit = audit


def _canonical_sha256(value: Any) -> str:
    raw = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _stamp(value: datetime | None = None) -> str:
    return (
        (value or datetime.now(timezone.utc))
        .astimezone(timezone.utc)
        .isoformat()
        .replace("+00:00", "Z")
    )


def _stable_id(prefix: str, *parts: str) -> str:
    payload = "|".join(parts).encode("utf-8")
    return f"{prefix}-{hashlib.sha256(payload).hexdigest()[:24]}"


def _family(role: str) -> str | None:
    return next((name for name, members in ROLE_FAMILIES.items() if role in members), None)


def is_concrete_role(role: str) -> bool:
    normalized = str(role or "").strip()
    return normalized.endswith("_infographic") or normalized in EXPLICIT_CONCRETE_ROLES


def semantic_candidate_compatibility(
    required_role: str,
    asset_role: str,
) -> dict[str, Any]:
    """Classify a candidate without treating a family or prose as proof.

    Versioned, asset-specific alternative semantic evidence does not yet have a
    repository contract.  Consequently v1 deliberately exposes no escape hatch
    for a concrete-role mismatch.  Adding one later requires a schema, immutable
    evidence binding and its own verifier; a string in ``compatibility`` can
    never supply that authority.
    """

    required = str(required_role or "").strip()
    asset = str(asset_role or "").strip()
    if required and required == asset:
        return {
            "eligible": True,
            "classification": "EXACT_ROLE_IDENTITY",
            "role_identity_match": True,
            "specific_proof_required": False,
            "statement": (
                f"exact semantic role {required}; identity match is necessary "
                "but visual comprehension remains unverified"
            ),
        }

    if is_concrete_role(required):
        return {
            "eligible": False,
            "classification": "BLOCKED_CONCRETE_ROLE_MISMATCH",
            "role_identity_match": False,
            "specific_proof_required": True,
            "statement": (
                f"concrete semantic role {required} requires exact asset role or "
                "immutable versioned asset-specific evidence; no alternative "
                "proof contract is available"
            ),
        }

    required_family = _family(required)
    asset_family = _family(asset)
    if (
        required_family is not None
        and asset_family
        in COMPATIBLE_ATMOSPHERIC_FAMILIES.get(required_family, {required_family})
    ):
        return {
            "eligible": True,
            "classification": "ATMOSPHERIC_SUPPORT_HYPOTHESIS",
            "role_identity_match": False,
            "specific_proof_required": False,
            "statement": (
                f"atmospheric support hypothesis {required}<-{asset}; this is "
                "support, not proof of a concrete narrative function"
            ),
        }

    return {
        "eligible": False,
        "classification": "BLOCKED_UNMAPPED_ROLE_MISMATCH",
        "role_identity_match": False,
        "specific_proof_required": False,
        "statement": (
            f"semantic roles {required or '<missing>'} and {asset or '<missing>'} "
            "have no eligible exact or atmospheric-support contract"
        ),
    }


def _ids(records: Any, key: str) -> list[str]:
    if not isinstance(records, list):
        return []
    return [str(item.get(key) or "") if isinstance(item, dict) else "" for item in records]


def _index(records: Any, key: str) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    if not isinstance(records, list):
        return result
    for item in records:
        if isinstance(item, dict):
            result[str(item.get(key) or "")].append(item)
    return result


def _resolved(root: Path, value: Any) -> Path | None:
    if not isinstance(value, str) or not value.strip():
        return None
    path = Path(value)
    return (path if path.is_absolute() else root / path).resolve()


def _same_path(left: Path | None, right: Path | None) -> bool:
    if left is None or right is None:
        return False
    return os.path.normcase(str(left)) == os.path.normcase(str(right))


def _input_binding(
    value: dict[str, Any],
    identity_key: str,
    source: Mapping[str, Any] | None,
) -> dict[str, Any]:
    source = source or {}
    return {
        "identity": str(value.get(identity_key) or "") or None,
        "canonical_sha256": _canonical_sha256(value),
        "source_path": source.get("path"),
        "source_sha256": source.get("sha256"),
    }


def verify_semantic_preflight(
    blueprint: dict[str, Any],
    allocation: dict[str, Any],
    manifest: dict[str, Any],
    treatment: dict[str, Any],
    *,
    root: Path,
    created_at: str | None = None,
    source_bindings: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Cross-check the four authoritative contracts without inspecting pixels.

    This verifier intentionally does not accept ``allocation.compatibility`` as
    evidence.  Required role comes from the blueprint and asset role/path/hash
    come from the manifest; the allocation must agree with both.
    """

    root = root.resolve()
    source_bindings = source_bindings or {}
    inputs = {
        "blueprint": _input_binding(
            blueprint, "blueprint_id", source_bindings.get("blueprint")
        ),
        "allocation": _input_binding(
            allocation, "allocation_id", source_bindings.get("allocation")
        ),
        "manifest": _input_binding(
            manifest, "library_id", source_bindings.get("manifest")
        ),
        "treatment": _input_binding(
            treatment, "treatment_plan_id", source_bindings.get("treatment")
        ),
    }

    checks: list[dict[str, Any]] = []

    def check(code: str, passed: bool, reason: str, evidence: list[str]) -> None:
        checks.append(
            {
                "code": code,
                "status": "PASS" if passed else "BLOCKED",
                "reason": reason,
                "evidence": evidence,
            }
        )

    blueprint_takes = blueprint.get("takes") if isinstance(blueprint.get("takes"), list) else []
    allocation_takes = allocation.get("takes") if isinstance(allocation.get("takes"), list) else []
    manifest_assets = manifest.get("assets") if isinstance(manifest.get("assets"), list) else []
    treatment_takes = treatment.get("takes") if isinstance(treatment.get("takes"), list) else []

    blueprint_ids = _ids(blueprint_takes, "take_id")
    allocation_ids = _ids(allocation_takes, "take_id")
    asset_ids = _ids(manifest_assets, "asset_id")
    treatment_ids = _ids(treatment_takes, "take_id")

    for label, values in (
        ("BLUEPRINT_TAKE_IDS", blueprint_ids),
        ("ALLOCATION_TAKE_IDS", allocation_ids),
        ("MANIFEST_ASSET_IDS", asset_ids),
        ("TREATMENT_TAKE_IDS", treatment_ids),
    ):
        duplicates = sorted(
            value for value, count in Counter(values).items() if not value or count != 1
        )
        check(
            f"{label}_UNIQUE",
            bool(values) and not duplicates,
            (
                f"{label.lower()} are present and unique."
                if values and not duplicates
                else f"{label.lower()} contain missing or duplicate identities: {duplicates}."
            ),
            [f"{label.lower()}:{len(values)}"],
        )

    check(
        "ALLOCATION_EXACT_BLUEPRINT_COVERAGE",
        bool(blueprint_ids) and allocation_ids == blueprint_ids,
        "Allocation take identities and order must exactly equal the blueprint.",
        [f"blueprint:{len(blueprint_ids)}", f"allocation:{len(allocation_ids)}"],
    )
    check(
        "TREATMENT_EXACT_BLUEPRINT_COVERAGE",
        bool(blueprint_ids) and treatment_ids == blueprint_ids,
        "Treatment take identities and order must exactly equal the blueprint.",
        [f"blueprint:{len(blueprint_ids)}", f"treatment:{len(treatment_ids)}"],
    )
    check(
        "SOURCE_LIBRARY_IDENTITY",
        bool(allocation.get("source_library_id"))
        and allocation.get("source_library_id") == manifest.get("library_id"),
        "Allocation source_library_id must equal the manifest library_id.",
        [
            f"allocation:{allocation.get('source_library_id')}",
            f"manifest:{manifest.get('library_id')}",
        ],
    )
    check(
        "INPUT_IDENTITIES_PRESENT",
        all(binding["identity"] for binding in inputs.values()),
        "Blueprint, allocation, manifest and treatment must each expose a stable identity.",
        [
            f"{name}:{binding['identity'] or '<missing>'}"
            for name, binding in inputs.items()
        ],
    )
    check(
        "VIDEO_IDENTITY",
        bool(blueprint.get("video_id"))
        and allocation.get("video_id") == blueprint.get("video_id")
        and treatment.get("video_id") == blueprint.get("video_id"),
        "Blueprint, allocation and treatment must identify the same non-empty video.",
        [
            f"blueprint:{blueprint.get('video_id')}",
            f"allocation:{allocation.get('video_id')}",
            f"treatment:{treatment.get('video_id')}",
        ],
    )
    check(
        "CHANNEL_IDENTITY",
        bool(blueprint.get("channel_id"))
        and bool(treatment.get("channel_id"))
        and treatment.get("channel_id") == blueprint.get("channel_id"),
        "Blueprint and treatment must identify the same non-empty channel.",
        [
            f"blueprint:{blueprint.get('channel_id')}",
            f"treatment:{treatment.get('channel_id')}",
        ],
    )

    allocations_by_take = _index(allocation_takes, "take_id")
    assets_by_id = _index(manifest_assets, "asset_id")
    treatments_by_take = _index(treatment_takes, "take_id")
    take_results: list[dict[str, Any]] = []
    role_accumulator: dict[str, dict[str, int]] = defaultdict(
        lambda: {
            "total_take_count": 0,
            "runtime_ms": 0,
            "exact_role_count": 0,
            "exact_role_runtime_ms": 0,
            "atmospheric_support_count": 0,
            "atmospheric_support_runtime_ms": 0,
            "blocked_count": 0,
            "blocked_runtime_ms": 0,
        }
    )

    exact_count = atmospheric_count = concrete_count = concrete_exact_count = 0
    for position, blueprint_take in enumerate(blueprint_takes):
        take_id = str(blueprint_take.get("take_id") or f"<missing-{position}>")
        required_role = str(blueprint_take.get("semantic_role") or "")
        duration_ms = max(
            0,
            int(blueprint_take.get("end_ms") or 0)
            - int(blueprint_take.get("start_ms") or 0),
        )
        summary = role_accumulator[required_role or "<missing>"]
        summary["total_take_count"] += 1
        summary["runtime_ms"] += duration_ms
        if is_concrete_role(required_role):
            concrete_count += 1

        allocation_matches = allocations_by_take.get(take_id, [])
        allocation_take = allocation_matches[0] if len(allocation_matches) == 1 else None
        asset_id = str(allocation_take.get("asset_id") or "") if allocation_take else ""
        manifest_matches = assets_by_id.get(asset_id, []) if asset_id else []
        asset = manifest_matches[0] if len(manifest_matches) == 1 else None
        manifest_role = str(asset.get("semantic_role") or "") if asset else ""
        compatibility = semantic_candidate_compatibility(required_role, manifest_role)

        blueprint_allocation_role_match = bool(allocation_take) and (
            str(allocation_take.get("required_role") or "") == required_role
        )
        allocation_manifest_role_match = bool(allocation_take and asset) and (
            str(allocation_take.get("asset_role") or "") == manifest_role
        )
        path_match = bool(allocation_take and asset) and _same_path(
            _resolved(root, allocation_take.get("source_path")),
            _resolved(root, asset.get("uri")),
        )
        hash_match = bool(allocation_take and asset) and (
            str(allocation_take.get("content_hash") or "")
            == str(asset.get("content_hash") or "")
            and str(asset.get("content_hash") or "").startswith("sha256:")
        )
        duration_match = bool(allocation_take) and (
            int(allocation_take.get("duration_ms") or -1) == duration_ms
            and int(allocation_take.get("source_end_ms") or 0)
            - int(allocation_take.get("source_start_ms") or 0)
            == duration_ms
        )
        unique_cross_refs = (
            len(allocation_matches) == 1 and len(manifest_matches) == 1
        )
        passed = all(
            (
                unique_cross_refs,
                blueprint_allocation_role_match,
                allocation_manifest_role_match,
                path_match,
                hash_match,
                duration_match,
                bool(compatibility["eligible"]),
            )
        )

        classification = str(compatibility["classification"])
        if passed and classification == "EXACT_ROLE_IDENTITY":
            exact_count += 1
            summary["exact_role_count"] += 1
            summary["exact_role_runtime_ms"] += duration_ms
            if is_concrete_role(required_role):
                concrete_exact_count += 1
        elif passed and classification == "ATMOSPHERIC_SUPPORT_HYPOTHESIS":
            atmospheric_count += 1
            summary["atmospheric_support_count"] += 1
            summary["atmospheric_support_runtime_ms"] += duration_ms
        else:
            summary["blocked_count"] += 1
            summary["blocked_runtime_ms"] += duration_ms

        failures: list[str] = []
        if len(allocation_matches) != 1:
            failures.append("ALLOCATION_TAKE_IDENTITY")
        if allocation_take and len(manifest_matches) != 1:
            failures.append("MANIFEST_ASSET_IDENTITY")
        if not blueprint_allocation_role_match:
            failures.append("BLUEPRINT_ALLOCATION_ROLE_MISMATCH")
        if not allocation_manifest_role_match:
            failures.append("ALLOCATION_MANIFEST_ROLE_MISMATCH")
        if not path_match:
            failures.append("SOURCE_PATH_MISMATCH")
        if not hash_match:
            failures.append("CONTENT_HASH_MISMATCH")
        if not duration_match:
            failures.append("DURATION_MISMATCH")
        if not compatibility["eligible"]:
            failures.append(classification)

        take_results.append(
            {
                "take_id": take_id,
                "required_role": required_role or None,
                "asset_id": asset_id or None,
                "manifest_asset_role": manifest_role or None,
                "declared_allocation_role": (
                    str(allocation_take.get("asset_role") or "") or None
                    if allocation_take
                    else None
                ),
                "declared_compatibility": (
                    str(allocation_take.get("compatibility") or "") or None
                    if allocation_take
                    else None
                ),
                "authoritative_classification": classification,
                "authoritative_statement": str(compatibility["statement"]),
                "role_identity_match": bool(compatibility["role_identity_match"]),
                "blueprint_allocation_role_match": blueprint_allocation_role_match,
                "allocation_manifest_role_match": allocation_manifest_role_match,
                "path_match": path_match,
                "hash_match": hash_match,
                "duration_match": duration_match,
                "status": "PASS" if passed else "BLOCKED",
                "blockers": failures,
            }
        )

    sequence: list[str] = []
    regressions: list[dict[str, Any]] = []
    for position, take_id in enumerate(blueprint_ids):
        candidates = treatments_by_take.get(take_id, [])
        state = str(candidates[0].get("framework_state") or "") if len(candidates) == 1 else ""
        sequence.append(state)
        if position and state in FRAMEWORK_ORDER and sequence[position - 1] in FRAMEWORK_ORDER:
            if FRAMEWORK_ORDER[state] < FRAMEWORK_ORDER[sequence[position - 1]]:
                regressions.append(
                    {
                        "take_id": take_id,
                        "position": position,
                        "from_state": sequence[position - 1],
                        "to_state": state,
                    }
                )

    def first_index(state: str) -> int | None:
        try:
            return sequence.index(state)
        except ValueError:
            return None

    milestones = {
        "TRUTH": first_index("TRUTH"),
        "RESPONSIBILITY": first_index("RESPONSIBILITY"),
        "TODAY": first_index("TODAY"),
        "COMPLETE": first_index("COMPLETE"),
    }
    all_states_valid = bool(sequence) and all(state in FRAMEWORK_ORDER for state in sequence)
    complete_index = milestones["COMPLETE"]
    milestone_ordered = (
        all(milestones[name] is not None for name in milestones)
        and int(milestones["TRUTH"]) < int(milestones["RESPONSIBILITY"])
        < int(milestones["TODAY"]) < int(milestones["COMPLETE"])
    )
    complete_terminal = complete_index == len(sequence) - 1 and all(
        state != "COMPLETE" for state in sequence[:-1]
    )
    check(
        "FRAMEWORK_STATES_VALID",
        all_states_valid,
        "Every treatment take must use a recognized framework state.",
        [f"states:{len(sequence)}"],
    )
    check(
        "FRAMEWORK_MONOTONIC",
        all_states_valid and not regressions,
        "Framework state cannot regress after a milestone is reached.",
        [f"regressions:{len(regressions)}"],
    )
    check(
        "FRAMEWORK_REACHES_ALL_MILESTONES",
        bool(milestone_ordered),
        "TRUTH, RESPONSIBILITY and TODAY must each be reached in order before COMPLETE.",
        [f"{name}:{index}" for name, index in milestones.items()],
    )
    check(
        "FRAMEWORK_COMPLETE_IS_TERMINAL",
        bool(complete_terminal),
        "COMPLETE must occur exactly at the final take.",
        [f"complete_index:{complete_index}", f"last_index:{len(sequence) - 1}"],
    )

    blocked_take_count = sum(item["status"] == "BLOCKED" for item in take_results)
    status = (
        "PASS"
        if blocked_take_count == 0
        and all(item["status"] == "PASS" for item in checks)
        else "BLOCKED"
    )
    role_summary = [
        {"required_role": role, **counts}
        for role, counts in sorted(role_accumulator.items())
    ]
    substantive_result_hash = _canonical_sha256(
        {
            "checks": checks,
            "take_results": take_results,
            "role_summary": role_summary,
            "framework_sequence": sequence,
            "framework_milestones": milestones,
            "framework_regressions": regressions,
        }
    )
    audit_id = _stable_id(
        "phase6-semantic-preflight",
        CONTRACT_VERSION,
        *(
            f"{name}:{binding['canonical_sha256']}:{binding.get('source_sha256') or 'NO_SOURCE'}"
            for name, binding in inputs.items()
        ),
        substantive_result_hash,
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "audit_id": audit_id,
        "contract_version": CONTRACT_VERSION,
        "phase": 6,
        "status": status,
        "inputs": inputs,
        "policy": {
            "concrete_roles_require_exact_or_versioned_specific_proof": True,
            "alternate_versioned_specific_proof_contract_available": False,
            "compatibility_text_is_authority": False,
            "role_match_is_sufficient_for_visual_comprehension": False,
        },
        "checks": checks,
        "take_results": take_results,
        "role_summary": role_summary,
        "framework": {
            "state_sequence": sequence,
            "milestone_indices": milestones,
            "regressions": regressions,
            "status": (
                "PASS"
                if all(
                    item["status"] == "PASS"
                    for item in checks
                    if item["code"].startswith("FRAMEWORK_")
                )
                else "BLOCKED"
            ),
        },
        "measurements": {
            "blueprint_take_count": len(blueprint_takes),
            "allocation_take_count": len(allocation_takes),
            "treatment_take_count": len(treatment_takes),
            "manifest_asset_count": len(manifest_assets),
            "exact_role_take_count": exact_count,
            "atmospheric_support_take_count": atmospheric_count,
            "blocked_take_count": blocked_take_count,
            "concrete_required_take_count": concrete_count,
            "concrete_exact_take_count": concrete_exact_count,
            "framework_regression_count": len(regressions),
            "visual_evidence_reviewed": False,
        },
        "claim_boundary": [
            "Role, path and hash agreement is necessary, not sufficient, for visual comprehension.",
            "This preflight performs no frame, OCR, motion or narrative-content inspection.",
            "Atmospheric substitutions are support hypotheses and never proof of a concrete function.",
            "A PASS cannot approve a render or publication.",
        ],
        "publication_authorized": False,
        "technical_cost_brl": 0,
        "created_at": created_at or _stamp(),
    }


def validate_semantic_preflight_audit(root: Path, audit: dict[str, Any]) -> None:
    schema = json.loads((root.resolve() / "schemas" / SCHEMA_NAME).read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(audit)


def require_semantic_contract(
    blueprint: dict[str, Any],
    allocation: dict[str, Any],
    manifest: dict[str, Any],
    treatment: dict[str, Any],
    *,
    root: Path,
    created_at: str | None = None,
) -> dict[str, Any]:
    audit = verify_semantic_preflight(
        blueprint,
        allocation,
        manifest,
        treatment,
        root=root,
        created_at=created_at,
    )
    validate_semantic_preflight_audit(root, audit)
    if audit["status"] != "PASS":
        blocked_codes = sorted(
            {
                item["code"]
                for item in audit["checks"]
                if item["status"] == "BLOCKED"
            }
            | {
                blocker
                for item in audit["take_results"]
                for blocker in item["blockers"]
            }
        )
        raise SemanticPreflightError(
            "SEMANTIC_PREFLIGHT_BLOCKED:" + ",".join(blocked_codes),
            audit,
        )
    return audit


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _read_bound_json(root: Path, relative: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    path = (root / relative).resolve()
    path.relative_to(root.resolve())
    raw = path.read_bytes()
    value = json.loads(raw.decode("utf-8-sig"))
    return value, {
        "path": _relative(root, path),
        "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(),
    }


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if path.is_file():
        existing = json.loads(path.read_text(encoding="utf-8"))
        candidate = dict(value)
        candidate["created_at"] = existing.get("created_at")
        if existing != candidate:
            raise PermissionError(f"immutable semantic preflight collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            existing = json.loads(path.read_text(encoding="utf-8"))
            candidate = dict(value)
            candidate["created_at"] = existing.get("created_at")
            if existing != candidate:
                raise PermissionError(
                    f"immutable semantic preflight collision: {path.name}"
                )
    finally:
        temporary.unlink(missing_ok=True)


def materialize_semantic_diagnostic(
    root: Path,
    *,
    blueprint_path: Path = Path(
        "output/production/phase6/video-002/preproduction/take_blueprint.json"
    ),
    allocation_path: Path = Path(
        "output/production/phase6/video-002/production/asset_allocation.json"
    ),
    manifest_path: Path = Path(
        "output/production/phase6/shared-assets/asset_manifest.json"
    ),
    treatment_path: Path = Path(
        "output/production/phase6/video-002/production/creative_treatment_plan.json"
    ),
    created_at: str | None = None,
) -> Path:
    """Write only a diagnostic audit; production inputs remain read-only."""

    root = root.resolve()
    values: dict[str, dict[str, Any]] = {}
    bindings: dict[str, dict[str, Any]] = {}
    for name, relative in (
        ("blueprint", blueprint_path),
        ("allocation", allocation_path),
        ("manifest", manifest_path),
        ("treatment", treatment_path),
    ):
        values[name], bindings[name] = _read_bound_json(root, relative)
    audit = verify_semantic_preflight(
        values["blueprint"],
        values["allocation"],
        values["manifest"],
        values["treatment"],
        root=root,
        created_at=created_at,
        source_bindings=bindings,
    )
    validate_semantic_preflight_audit(root, audit)
    output_root = (root / DIAGNOSTIC_AUDIT_ROOT).resolve()
    output_root.relative_to(root.resolve())
    output = output_root / f"{audit['audit_id']}.json"
    _write_immutable(output, audit)
    return output


__all__ = [
    "CONTRACT_VERSION",
    "DIAGNOSTIC_AUDIT_ROOT",
    "SemanticPreflightError",
    "is_concrete_role",
    "materialize_semantic_diagnostic",
    "require_semantic_contract",
    "semantic_candidate_compatibility",
    "validate_semantic_preflight_audit",
    "verify_semantic_preflight",
]
