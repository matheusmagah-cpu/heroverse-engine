from __future__ import annotations

import json
import math
import re
import statistics
from datetime import datetime
from pathlib import Path
from typing import Any

from .db import ROOT, connect, initialize, load_config, utc_now


DEFAULT_ANALYSIS = ROOT / "output" / "modeling" / "grace-grit-love" / "model-analysis.json"
DEFAULT_MODEL_DIR = ROOT / "output" / "modeling" / "grace-grit-love"


WEAK_OPENERS = (
    "and ", "but ", "so ", "well ", "okay ", "that ", "there may be ",
    "the thing is", "you know", "happy or sad", "if you just do stuff",
)
VAGUE_WORDS = {"stuff", "things", "something", "anything", "nothing", "it", "that"}
DIRECTIVE_WORDS = {
    "ask", "believe", "choose", "do", "don't", "fight", "hear", "keep", "know",
    "look", "pray", "protect", "put", "refuse", "remember", "rise", "stand", "stop",
}
HIGH_STAKES_WORDS = {
    "armor", "attack", "battle", "blood", "calling", "change", "coward", "destiny",
    "devil", "enemy", "faith", "fear", "god", "hope", "identity", "jesus", "king",
    "life", "power", "pray", "prayer", "purpose", "satan", "spirit", "victory", "war",
}
SPECIFIC_ANCHORS = HIGH_STAKES_WORDS | {
    "armor", "dreams", "holy", "pharisees", "promise", "scripture", "strength", "you",
}
TOPIC_MAP = {
    "warfare": {"armor", "attack", "battle", "blood", "devil", "enemy", "principalities", "satan", "war", "wrestle"},
    "faith": {"ask", "believe", "faith", "pray", "prayer", "trust", "victory", "wins"},
    "power": {"authority", "change", "holy", "power", "spirit", "strength"},
    "king": {"coming", "jesus", "king", "lord", "pharisees", "rulers"},
    "identity": {"calling", "child", "confidence", "identity", "purpose", "you"},
    "peace": {"anxiety", "fear", "peace", "rest", "still"},
    "division": {"divide", "division", "separate"},
    "obedience": {"obey", "obedience", "obedient", "prompt"},
    "weary": {"endure", "grow", "tired", "weary"},
    "purpose": {"calling", "purpose", "reason"},
}


def _words(text: str) -> list[str]:
    return re.findall(r"[a-z']+", text.lower())


def _first_sentence(text: str) -> str:
    return re.split(r"(?<=[.!?])\s+", text.strip(), maxsplit=1)[0]


def _title_topics(title: str) -> set[str]:
    title_words = set(_words(title.split("|", 1)[0]))
    topics = {topic for topic, synonyms in TOPIC_MAP.items() if title_words & ({topic} | synonyms)}
    return topics


def _topic_alignment(title: str, hook: str) -> tuple[bool, list[str]]:
    title_topics = _title_topics(title)
    hook_words = set(_words(hook))
    matched = sorted(
        topic for topic in title_topics
        if hook_words & ({topic} | TOPIC_MAP.get(topic, set()))
    )
    return bool(matched), matched


def evaluate_opening_line(text: str, title: str = "") -> dict[str, Any]:
    """Evaluate the first audible unit against the observed winner/loser split.

    This is a structural selection gate. It does not predict views or infer causality.
    """
    cleaned = " ".join(text.strip().split())
    lowered = cleaned.lower()
    sentence = _first_sentence(cleaned)
    words = _words(sentence)
    word_set = set(words)
    weak_starter = next((item.strip() for item in WEAK_OPENERS if lowered.startswith(item)), None)
    standalone = bool(words) and weak_starter is None and len(words) >= 5
    specific_anchor = bool(word_set & SPECIFIC_ANCHORS)
    high_stakes = len(word_set & HIGH_STAKES_WORDS) >= 1
    imperative = bool(words and words[0] in DIRECTIVE_WORDS)
    declarative = bool(
        words
        and words[0] in {"absolute", "god", "jesus", "the", "this", "your", "when"}
        and len(words) >= 6
    )
    promise_command_or_declaration = imperative or declarative
    vague_density = len(word_set & VAGUE_WORDS) / max(1, len(word_set))
    dialogue_only = "?" in sentence and len(words) <= 7
    no_vague_dialogue = vague_density <= 0.16 and not dialogue_only
    title_aligned, matched_topics = _topic_alignment(title, sentence) if title else (True, [])

    features = {
        "standalone_complete_start": standalone,
        "specific_subject_or_anchor": specific_anchor,
        "immediate_stakes": high_stakes,
        "promise_command_or_declaration": promise_command_or_declaration,
        "no_vague_or_setup_only_dialogue": no_vague_dialogue,
        "title_topic_alignment": title_aligned,
    }
    weights = {
        "standalone_complete_start": 2.5,
        "specific_subject_or_anchor": 1.5,
        "immediate_stakes": 2.0,
        "promise_command_or_declaration": 1.5,
        "no_vague_or_setup_only_dialogue": 1.0,
        "title_topic_alignment": 1.5,
    }
    score = sum(weights[name] for name, passed in features.items() if passed)
    failures = [name for name, passed in features.items() if not passed]
    return {
        "score": round(score, 2),
        "maximum": 10.0,
        "passed": score >= 7.5 and standalone and title_aligned,
        "first_sentence": sentence,
        "first_sentence_words": len(words),
        "weak_starter": weak_starter,
        "matched_title_topics": matched_topics,
        "features": features,
        "failures": failures,
        "evidence_scope": "opening-selection heuristic derived from the 12-video controlled cohort; not a view forecast",
    }


def _ranks(values: list[float]) -> list[float]:
    return [
        sum(other < value for other in values)
        + (sum(other == value for other in values) + 1) / 2
        for value in values
    ]


def _spearman(left: list[float], right: list[float]) -> float:
    if len(left) != len(right) or len(left) < 2:
        return 0.0
    left_ranks, right_ranks = _ranks(left), _ranks(right)
    left_mean, right_mean = statistics.mean(left_ranks), statistics.mean(right_ranks)
    numerator = sum((x - left_mean) * (y - right_mean) for x, y in zip(left_ranks, right_ranks))
    denominator = math.sqrt(
        sum((x - left_mean) ** 2 for x in left_ranks)
        * sum((y - right_mean) ** 2 for y in right_ranks)
    )
    return round(numerator / denominator, 3) if denominator else 0.0


def build_master_model(
    analysis_path: Path = DEFAULT_ANALYSIS,
    output_dir: Path = DEFAULT_MODEL_DIR,
) -> dict[str, Any]:
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    openings = []
    for item in analysis["sampled_openings"]:
        diagnostic = evaluate_opening_line(item["opening_15s"], item["title"])
        openings.append(
            {
                "tier": item["sample_tier"],
                "video_id": item["video_id"],
                "title": item["title"],
                "views": item["views"],
                "views_per_day": item["views_per_day"],
                "first_speech_seconds": item["first_speech_seconds"],
                "cuts_first_15_seconds": item["scene_cuts_0_15"],
                "opening": item["opening_15s"],
                "diagnostic": diagnostic,
            }
        )
    top_scores = [item["diagnostic"]["score"] for item in openings if item["tier"] == "top"]
    bottom_scores = [item["diagnostic"]["score"] for item in openings if item["tier"] == "bottom"]
    videos = analysis["videos"]
    duration_velocity_rho = _spearman(
        [float(item["duration_seconds"]) for item in videos],
        [float(item["views_per_day"]) for item in videos],
    )

    config = load_config()
    channel_config = config["channel"]
    target_duration = 230
    current_watch_hours = channel_config.get("current_valid_watch_hours")
    watch_gap = (
        max(0.0, channel_config["target_valid_watch_hours"] - float(current_watch_hours))
        if isinstance(current_watch_hours, (int, float)) else None
    )
    subscriber_gap = max(0, channel_config["target_subscribers"] - channel_config["current_subscribers"])
    retention_cases = []
    for retention in (0.40, 0.55, 0.70):
        avd_seconds = target_duration * retention
        required_views = math.ceil(watch_gap * 3600 / avd_seconds) if watch_gap is not None and avd_seconds else None
        retention_cases.append(
            {
                "average_percentage_viewed": retention,
                "average_view_duration_seconds": round(avd_seconds, 1),
                "required_long_views": required_views,
                "allocation_status": "UNAVAILABLE_NO_FIXED_CADENCE",
            }
        )
    conversion_cases = []
    for conversion in (0.005, 0.01, 0.015):
        conversion_cases.append(
            {
                "subscriber_conversion_rate": conversion,
                "required_total_views": math.ceil(subscriber_gap / conversion) if conversion else 0,
            }
        )

    model = {
        "model_id": "grace-grit-love-3to5-v1",
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "purpose": "Replicate the observable format mechanics for HeroVerse while replacing wording, identity, unlicensed footage, and most narration.",
        "reference_channel": {
            **analysis["channel"],
            "public_ypp_status": "not_publicly_verifiable",
            "source_use_policy": "reference-only; do not reuse this channel's movie footage or sermon audio without a separate license",
        },
        "evidence": {
            "population": analysis["population"],
            "controlled_opening_sample": analysis["sample"],
            "performance_ranking": "views_per_day as of 2026-09-01",
            "opening_gate_top_median_score": round(statistics.median(top_scores), 2),
            "opening_gate_bottom_median_score": round(statistics.median(bottom_scores), 2),
            "duration_vs_velocity_spearman_rho": duration_velocity_rho,
            "full_body_transcripts_reviewed": 1,
            "confidence": {
                "format_and_packaging": "high within this 24-video channel",
                "opening_differentiation": "moderate; 6 top-quartile vs 6 bottom-quartile",
                "full_narrative_arc": "provisional; one complete winner transcript",
                "causal_claims": "none",
            },
        },
        "observed_format_signature": {
            "canvas": "16:9",
            "duration_seconds": {"minimum": 165, "median": 230, "maximum": 531, "core_band": [210, 300], "core_band_count": 13},
            "title_formula": "2–4 word uppercase command/declaration + | Christian Motivation",
            "opening_brand_bumper_seconds": "approximately 5.6–11.1 before speech in sampled videos",
            "median_scene_cuts_first_15_seconds": {"top": 4.0, "bottom": 4.0},
            "visual_grammar": "cinematic conflict/faith imagery; new shot roughly every 3–4 seconds in the opening",
            "audio_grammar": "authoritative sermon-style speech over cinematic music",
        },
        "what_separated_winners": [
            "The first audible unit was self-contained rather than clipped from missing context.",
            "The first unit named a concrete spiritual subject, command, power, or threat immediately.",
            "The opening worked as a declaration/command/promise and matched the title's semantic topic.",
        ],
        "what_did_not_separate_winners": [
            "Speech start time: top median 6.65s vs bottom 6.69s.",
            "Cut count in the first 15s: both cohorts median 4.",
            f"Duration alone: Spearman rho {duration_velocity_rho} against views/day in the 24-video population.",
        ],
        "heroverse_master_template": {
            "format": "long",
            "canvas": "16:9",
            "target_duration_seconds": 230,
            "allowed_duration_seconds": [210, 270],
            "brand_strategy": "No silent bumper. Start the spoken promise at 0.0s; place a small HeroVerse mark inside the image.",
            "hook": {
                "first_complete_claim_deadline_seconds": 3.2,
                "minimum_opening_gate_score": 7.5,
                "required": ["standalone_complete_start", "title_topic_alignment", "immediate_stakes"],
                "forbidden": ["greeting", "setup-only dialogue", "weak conjunction start", "unresolved context", "generic inspiration"],
            },
            "narrative_arc": [
                {"window_seconds": [0, 12], "role": "declaration_and_proof", "job": "State the battle/promise; immediately show one licensed authority excerpt."},
                {"window_seconds": [12, 45], "role": "personal_stakes", "job": "Make the threat concrete in the viewer's decisions, identity, fear, or delay."},
                {"window_seconds": [45, 90], "role": "mechanism", "job": "Explain how the pressure works; no generic encouragement."},
                {"window_seconds": [90, 135], "role": "scripture_or_authority", "job": "Provide biblical proof and a second independently clear excerpt."},
                {"window_seconds": [135, 180], "role": "reversal", "job": "Replace the false response with the faithful response."},
                {"window_seconds": [180, 218], "role": "crescendo_and_action", "job": "Give a concrete action and raise emotional intensity."},
                {"window_seconds": [218, 230], "role": "identity_resolution", "job": "Resolve the exact title promise with one memorable line."},
            ],
            "source_use": {
                "allowed_sources": "owned, public domain, or license-verified only",
                "source_audio_share_range": [0.10, 0.25],
                "original_narrative_minimum_share": 0.75,
                "excerpt_count": [3, 5],
                "excerpt_duration_seconds": [6, 12],
                "rule": "Every excerpt must remain truthful in context and perform a named narrative job; no decorative random takes.",
            },
            "visuals": {
                "opening_average_shot_length_seconds": [2.5, 4.0],
                "body_average_shot_length_seconds": [4.0, 6.0],
                "substitution_for_reference_movie_footage": "licensed stock, public-domain film, self-shot footage, generated motion graphics, or abstract scripture typography",
                "on_screen_text": "1–6 words only at structural turns; full captions optional but accessible captions required in upload",
            },
            "packaging": {
                "title_regex": "^[A-Z0-9'’?! ]{8,42} \\| Christian Motivation$",
                "thumbnail_words": [1, 3],
                "title_thumbnail_rule": "Thumbnail adds tension or consequence; it does not repeat the complete title.",
                "examples": [
                    "PROTECT YOUR IDENTITY | Christian Motivation",
                    "FAITH UNDER PRESSURE | Christian Motivation",
                    "WHEN GOD FEELS SILENT | Christian Motivation",
                ],
            },
        },
        "operating_gates": {
            "pre_render": [
                "opening score >= 7.5/10 and all required hook features pass",
                "210–270 seconds",
                "3–5 licensed excerpts, each 6–12 seconds",
                "source share 10–25%; original narrative >= 75%",
                "all seven narrative roles present in order",
                "title matches the model formula and the hook matches its topic",
            ],
            "post_publish_24h": [
                "CTR, 30-second retention, average view duration, valid watch hours, and subscribers gained recorded",
                "no scaling decision with missing metrics or before 24 hours",
            ],
            "policy": "A model-conforming video can still fail. Only HeroVerse retention data validates scale.",
        },
        "monetization_requirement_math": {
            "deadline_days": channel_config["deadline_days"],
            "starting_subscribers": channel_config["current_subscribers"],
            "subscriber_gap": subscriber_gap,
            "valid_watch_hour_gap": watch_gap,
            "required_average_watch_hours_per_day": round(watch_gap / channel_config["deadline_days"], 2) if watch_gap is not None else None,
            "required_average_subscribers_per_day": round(subscriber_gap / channel_config["deadline_days"], 2),
            "retention_cases_for_230_second_videos": retention_cases,
            "subscriber_conversion_cases": conversion_cases,
            "cadence_cases": {
                "mode": "CONTROLLED_SEQUENTIAL_LOT",
                "maximum_long_videos": 3,
                "next_release_condition": "Prior owned checkpoint, one-variable preregistration and all critical gates must pass.",
            },
            "interpretation": "Requirement arithmetic is emitted only for observed inputs; unavailable YPP progress or cadence remains null, never a fabricated zero.",
        },
        "body_arc_case_study": {
            "video": "REMEMBER YOUR POWER",
            "sequence": [
                "power promise", "specific enemy damage", "protection/authority proof",
                "enemy profile", "fear reversal", "name-of-Jesus crescendo",
                "practical deliverance", "identity affirmation",
            ],
            "status": "provisional until at least four more complete videos are compared",
        },
        "video_catalog": videos,
        "scored_openings": openings,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "master-model.json"
    json_path.write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path = output_dir / "master-model.md"
    md_path.write_text(_model_markdown(model), encoding="utf-8")
    _persist_master_model(model)
    return {"model": model, "json_path": str(json_path), "markdown_path": str(md_path)}


def _persist_master_model(model: dict[str, Any]) -> None:
    initialize()
    stamp = utc_now()
    evidence = model["evidence"]
    channel = model["reference_channel"]
    tier_by_video = {item["video_id"]: item["tier"] for item in model["scored_openings"]}
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO channel_models
            (model_id, reference_channel_id, reference_channel_name, population_videos,
             total_views, median_views, ranking_metric, model_json, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(model_id) DO UPDATE SET
                reference_channel_id=excluded.reference_channel_id,
                reference_channel_name=excluded.reference_channel_name,
                population_videos=excluded.population_videos,
                total_views=excluded.total_views,
                median_views=excluded.median_views,
                ranking_metric=excluded.ranking_metric,
                model_json=excluded.model_json,
                updated_at=excluded.updated_at
            """,
            (
                model["model_id"], channel["channel_id"], channel["channel"],
                evidence["population"]["videos"], evidence["population"]["total_views"],
                evidence["population"]["median_views"], evidence["performance_ranking"],
                json.dumps(model, ensure_ascii=False), stamp,
            ),
        )
        conn.execute("DELETE FROM model_openings WHERE model_id=?", (model["model_id"],))
        conn.execute("DELETE FROM model_videos WHERE model_id=?", (model["model_id"],))
        for video in model["video_catalog"]:
            conn.execute(
                """
                INSERT INTO model_videos
                (model_id, video_id, title, views, views_per_day, duration_seconds,
                 published_date, sample_tier)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    model["model_id"], video["video_id"], video["title"], video["views"],
                    video["views_per_day"], video["duration_seconds"], video["published_date"],
                    tier_by_video.get(video["video_id"], "middle"),
                ),
            )
        for opening in model["scored_openings"]:
            conn.execute(
                """
                INSERT INTO model_openings
                (model_id, video_id, sample_tier, opening_text, first_speech_seconds,
                 cuts_first_15_seconds, semantic_score, semantic_passed, diagnostic_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    model["model_id"], opening["video_id"], opening["tier"], opening["opening"],
                    opening["first_speech_seconds"], opening["cuts_first_15_seconds"],
                    opening["diagnostic"]["score"], int(opening["diagnostic"]["passed"]),
                    json.dumps(opening["diagnostic"], ensure_ascii=False),
                ),
            )


def _model_markdown(model: dict[str, Any]) -> str:
    evidence = model["evidence"]
    sample = evidence["controlled_opening_sample"]
    template = model["heroverse_master_template"]
    lines = [
        "# HERO Engine — ficha-mãe do formato",
        "",
        f"Modelo: `{model['model_id']}`",
        "",
        "## Evidência observada",
        "",
        f"- População: {evidence['population']['videos']} vídeos; mediana de {evidence['population']['median_views']:,} views.",
        f"- Comparação controlada: {sample['top_count']} aberturas do quartil superior e {sample['bottom_count']} do inferior, ranqueadas por views/dia.",
        f"- Velocidade mediana: {sample['top_median_views_per_day']:.1f} vs {sample['bottom_median_views_per_day']:.1f} views/dia.",
        f"- Score semântico do hook: mediana {evidence['opening_gate_top_median_score']:.2f}/10 no topo vs {evidence['opening_gate_bottom_median_score']:.2f}/10 na base.",
        f"- Duração vs velocidade: rho de Spearman {evidence['duration_vs_velocity_spearman_rho']}; duração isolada não explica o desempenho.",
        "",
        "## O que será modelado",
        "",
    ]
    lines.extend(f"- {item}" for item in model["what_separated_winners"])
    lines.extend(["", "## O que não será tratado como causa", ""])
    lines.extend(f"- {item}" for item in model["what_did_not_separate_winners"])
    lines.extend([
        "",
        "## Template HeroVerse",
        "",
        f"- Formato: {template['canvas']}, {template['allowed_duration_seconds'][0]}–{template['allowed_duration_seconds'][1]} s; alvo {template['target_duration_seconds']} s.",
        f"- Hook completo até {template['hook']['first_complete_claim_deadline_seconds']} s; score mínimo {template['hook']['minimum_opening_gate_score']}/10.",
        f"- Material-fonte: {template['source_use']['source_audio_share_range'][0]:.0%}–{template['source_use']['source_audio_share_range'][1]:.0%}; narrativa original >= {template['source_use']['original_narrative_minimum_share']:.0%}.",
        f"- Excertos: {template['source_use']['excerpt_count'][0]}–{template['source_use']['excerpt_count'][1]}, cada um com {template['source_use']['excerpt_duration_seconds'][0]}–{template['source_use']['excerpt_duration_seconds'][1]} s.",
        f"- Título: `{template['packaging']['title_regex']}`.",
        "",
        "## Matemática da meta de 30 dias",
        "",
        f"- Gap: {model['monetization_requirement_math']['subscriber_gap']} inscritos e "
        f"{model['monetization_requirement_math']['valid_watch_hour_gap'] if model['monetization_requirement_math']['valid_watch_hour_gap'] is not None else 'UNAVAILABLE'} horas válidas.",
        f"- Ritmo médio exigido: {model['monetization_requirement_math']['required_average_subscribers_per_day']:.1f} inscritos/dia e "
        f"{model['monetization_requirement_math']['required_average_watch_hours_per_day'] if model['monetization_requirement_math']['required_average_watch_hours_per_day'] is not None else 'UNAVAILABLE'} horas/dia.",
        "",
        "| Retenção média | AVD | Views longas exigidas |",
        "|---:|---:|---:|",
    ])
    for case in model["monetization_requirement_math"]["retention_cases_for_230_second_videos"]:
        lines.append(
            f"| {case['average_percentage_viewed']:.0%} | {case['average_view_duration_seconds']:.1f}s | "
            f"{case['required_long_views'] if case['required_long_views'] is not None else 'UNAVAILABLE'} |"
        )
    lines.extend([
        "",
        "## Arco obrigatório",
        "",
    ])
    for beat in template["narrative_arc"]:
        lines.append(f"- {beat['window_seconds'][0]:03d}–{beat['window_seconds'][1]:03d}s — **{beat['role']}**: {beat['job']}")
    lines.extend([
        "",
        "## Limite de interpretação",
        "",
        "A análise mede padrões observáveis; não prova aprovação no YPP nem que uma única variável causou as views. A validação final vem dos dados de retenção do HeroVerse.",
    ])
    return "\n".join(lines)


def evaluate_edl_against_model(edl: dict[str, Any], model: dict[str, Any]) -> dict[str, Any]:
    template = model["heroverse_master_template"]
    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool, actual: Any, target: str) -> None:
        checks.append({"name": name, "passed": bool(passed), "actual": actual, "target": target})

    segments = edl.get("segments") or []
    source_segments = [item for item in segments if item.get("type") == "source_clip"]
    source_seconds = sum(float(item["end_seconds"]) - float(item["start_seconds"]) for item in source_segments)
    planned_seconds = sum(
        float(item.get("target_seconds") or 0)
        if item.get("type") == "voiceover"
        else float(item["end_seconds"]) - float(item["start_seconds"])
        for item in segments
    )
    source_share = source_seconds / planned_seconds if planned_seconds else 1.0
    first = segments[0] if segments else {}
    title = (edl.get("metadata") or {}).get("primary_title") or (edl.get("title_variants") or [""])[0]
    hook_diagnostic = evaluate_opening_line(first.get("text", ""), title)
    allowed_duration = template["allowed_duration_seconds"]
    allowed_share = template["source_use"]["source_audio_share_range"]
    excerpt_bounds = template["source_use"]["excerpt_duration_seconds"]
    excerpt_count = template["source_use"]["excerpt_count"]
    durations = [float(item["end_seconds"]) - float(item["start_seconds"]) for item in source_segments]
    roles = [item.get("narrative_role") for item in segments if item.get("narrative_role")]
    required_roles = [item["role"] for item in template["narrative_arc"]]

    add("format", edl.get("format") == "long", edl.get("format"), "long")
    add("duration", allowed_duration[0] <= planned_seconds <= allowed_duration[1], round(planned_seconds, 2), f"{allowed_duration[0]}–{allowed_duration[1]}s")
    add("hook_is_first", first.get("type") == "voiceover", first.get("type"), "original voiceover at 0.0s")
    add("hook_claim_deadline", float(first.get("target_seconds") or 999) <= template["hook"]["first_complete_claim_deadline_seconds"], first.get("target_seconds"), f"<= {template['hook']['first_complete_claim_deadline_seconds']}s")
    add("hook_semantics", hook_diagnostic["passed"], hook_diagnostic, ">= 7.5/10 + complete start + title alignment")
    add("title_formula", bool(re.match(template["packaging"]["title_regex"], title)), title, template["packaging"]["title_regex"])
    add("excerpt_count", excerpt_count[0] <= len(source_segments) <= excerpt_count[1], len(source_segments), f"{excerpt_count[0]}–{excerpt_count[1]}")
    add("excerpt_duration", bool(durations) and all(excerpt_bounds[0] <= value <= excerpt_bounds[1] for value in durations), durations, f"each {excerpt_bounds[0]}–{excerpt_bounds[1]}s")
    add("source_share", allowed_share[0] <= source_share <= allowed_share[1], round(source_share, 4), f"{allowed_share[0]:.0%}–{allowed_share[1]:.0%}")
    add("original_share", 1 - source_share >= template["source_use"]["original_narrative_minimum_share"], round(1 - source_share, 4), f">= {template['source_use']['original_narrative_minimum_share']:.0%}")
    ordered_roles = [role for role in required_roles if role in roles]
    add("narrative_roles", ordered_roles == required_roles, roles, f"all roles in order: {required_roles}")
    return {
        "model_id": model["model_id"],
        "slug": edl.get("slug"),
        "passed": all(item["passed"] for item in checks),
        "passed_checks": sum(item["passed"] for item in checks),
        "total_checks": len(checks),
        "measurements": {"planned_seconds": round(planned_seconds, 2), "source_seconds": round(source_seconds, 2), "source_share": round(source_share, 4)},
        "checks": checks,
    }
