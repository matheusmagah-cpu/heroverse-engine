"""Externally anchored exact-cache replay of one completed body registration.

No pixel decoder, source inspector, OCR, renderer, registry writer or new rights
decision runs. The original 2/11 source replays remain historical observations.
Metadata/bytes are reopened, source envelopes rebuilt from actual reader sinks,
and existing rights documents validated against those reconstructed envelopes.
"""
from __future__ import annotations

import copy
import importlib.util
import math
from pathlib import Path

from . import phase6_av_static_sources as primitives
from . import phase6_av_body_sources as body

VERSION = "phase6-av-body-sources-exact-replay-v1"
IMPLEMENTATION = "hero_engine/phase6_av_body_sources_replay.py"
TEST = "tests/test_phase6_av_body_sources_replay.py"
BASE = "output/operations/phase6/av-admission/evidence/body-rights-registrations/v1"
DIRECTORY = "output/operations/phase6/av-admission/evidence/body-static-rights/v1"
REGISTRATION = {"path": BASE + "/receipt.json", "sha256": "e2b0beb856af6d8919b50d5d8b6cc1f3ae99d2d47b2104362ec002f561c756d9"}
REQUEST = {"path": BASE + "/request.json", "sha256": "a858dcf333febee3181e4771bc8d4b62528434c90c272f1c69d9905610bd2753"}
CLAIM = {"path": BASE + "/claim.json", "sha256": "5718c015aebd362636baf7d2cf236852a25406d06b6c18e8c52e8c6e12233492"}
REGISTRAR = "output/qa/phase6/diagnostics/body-static-registration-v1/register_body_rights.py"
CODE_PINS = {
    "hero_engine/phase6_av_body_sources.py": "e240c94ab4ceb0f767456c733ef200d65d4d8661d95256fc000dd8684a0d590b",
    "hero_engine/phase6_av_static_sources.py": "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "hero_engine/phase6_body_asset_rights.py": "4ddfe87c01d75d6d412a7d2c61cafa88da49f07d9fb51886539854e85dbe06c7",
    "hero_engine/phase6_narration_units.py": "737326797c9499cd341198ca43927a3e6447f5616563ceafc6b3bd8278c71fba",
    REGISTRAR: "31d3d3f9616fd1ef001b5d339ad80c129168341afe0b0f74a87f3a94f7487ba1",
    "output/qa/phase6/diagnostics/body-static-registration-v1/test_register_body_rights.py": "a20944b960b3f2bfb802ca066730d6ca803ae9b56ae30a006145e8cb56c745f2",
    "output/qa/phase6/diagnostics/two-column-compact-v1/register_compact_rights.py": "386e09cb92ca2344fbd16ed963b19864bfd5ab70136d502d21d7c258e6c518f9",
    "schemas/phase6_body_static_rights.schema.json": "107720e004776b554d8d234910a7abe87a79c44400d01a1d63b24aee5c07a541",
    "tests/test_phase6_av_body_sources.py": "e51b5b75aea40b624eb67aced5281e38700235108790e2c2aa3f79e40e518cc1",
    "tests/test_phase6_body_asset_rights.py": "658b2e0784f4c31362e8d2d91ccb13e7d4bf4469f4d8271d225a1d35e7701083",
}
NOTE_PINS = {
    "docs/evidence/D171_THREE_MOVES_EDITORIAL_RIGHTS_REVIEW.md": "bc6831191d31481a575d1df66f13b93216ed103ebea1e8b7a6eb97b8a5fbb0ca",
    "docs/evidence/D171_RECORD_LEARNING_EDITORIAL_RIGHTS_REVIEW.md": "32d4be7d6700d99a1f6008ead87ffa369c1ffceef4862a26497b34b2db54926c",
    "docs/evidence/D171_TEST_QUESTIONS_EDITORIAL_RIGHTS_REVIEW.md": "79fbcfa95516d90df7207b719af7df950fe917cc1748e5c922b486019f7f970c",
}
LIMIT = 2 * 1024**2
_same = primitives._same


def _document(reader, binding):
    raw = reader.read(binding["path"], binding["sha256"], limit=LIMIT)
    document = primitives._json(raw)
    if primitives._canonical(document) != raw:
        raise ValueError("canonical body cache document required")
    return document


def _load(reader):
    if Path(__file__).absolute() != reader.root / IMPLEMENTATION:
        raise ValueError("body replay loaded from another root")
    for relative in (IMPLEMENTATION, TEST):
        path = reader.path(relative)
        if not 0 < path.stat().st_size <= LIMIT:
            raise ValueError("bounded body replay implementation required")
        reader.read(relative, primitives._sha(path.read_bytes()), limit=LIMIT)
    for relative, digest in CODE_PINS.items():
        reader.read(relative, digest, limit=LIMIT)
    # All external execution/code anchors precede examination of cached proofs.
    receipt, request, claim = (_document(reader, binding) for binding in (REGISTRATION, REQUEST, CLAIM))
    _same(request["code_pins"], CODE_PINS, "body registration implementation pins differ")
    spec = importlib.util.spec_from_file_location("body_cache_pinned_registrar", reader.root / REGISTRAR)
    registration = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(registration)
    if registration.ROOT != reader.root:
        raise ValueError("body registrar belongs to another root")
    reader.read(REGISTRAR, CODE_PINS[REGISTRAR], limit=LIMIT)
    loaded_body, rights, _writer = registration.bootstrap(reader, dict(CODE_PINS))
    if loaded_body is not body:
        raise ValueError("body facade module identity differs")
    return registration, rights, receipt, request, claim


def _original_replay_sources(context, template):
    """Rebuild historical envelopes, not pixel observations or PASS inputs.

    Reader populations are those just produced by pinned metadata prepare.
    Historical scan associations/aliases have already been independently checked
    there against the frozen report and actual PNG bytes; no serialized list is
    traversed as an input dependency source.
    """
    replay = context.replays[template]
    values, module = replay["context"], replay["module"]
    state, report = values["state"], values["report"]
    dependencies = dict(state["reader"].bindings)
    body._merge(dependencies, list(values["reader"].bindings.values()))
    bindings = copy.deepcopy(list(dependencies.values()))
    qa_rows = {row["state_id"]: row for row in report["states"]}
    sources = []
    for original in state["receipt"]["contract"]["design"]["states"]:
        sid = original["state_id"]
        asset = state["reader"].bindings[str(state["directory"] / (sid + ".png"))]
        proof = {"version": module.VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", "template_id": template,
            "channel_id": primitives.CHANNEL, "state_id": sid, "unit_id": original["unit_id"],
            "lineage_id": "owned-four-criteria-panel-v1", "asset_binding": copy.deepcopy(asset),
            "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1, "media_kind": "STATIC_IMAGE",
            "source_video_fps": None, "source_video_duration": None, "source_technically_verified": True,
            "source_ready": False, "entry": copy.deepcopy(original["entry"]), "literal_copy": copy.deepcopy(original["copy"]),
            "source_receipt": copy.deepcopy(module.SOURCE_RECEIPT), "qa_report_binding": copy.deepcopy(module.REPORT),
            "projection_binding": copy.deepcopy(module.PROJECTION), "authority": dict(module.AUTHORITY), "technical_cost_brl": 0,
            "dependency_bindings": copy.deepcopy(bindings)}
        if template == body.THREE:
            proof["take_id"] = original["take_id"]
        else:
            proof.update(take_ids=copy.deepcopy(original["take_ids"]), composition_id=original["composition_id"],
                primary_scan_state_id=qa_rows[sid]["primary_scan_state_id"], image_aliases=copy.deepcopy(qa_rows[sid]["image_aliases"]))
        proof["inspection_id"] = body.REPLAYS[template]["inspection_prefix"] + primitives._sha(primitives._canonical(proof))[:24]
        sources.append(proof)
    return sources, bindings


def _sources(context):
    """Exact frozen facade envelope recomposition; no source inspector call."""
    result = []
    for template in context.templates:
        config, fixed = body.CONFIGS[template], body.REPLAYS[template]
        originals, sink = _original_replay_sources(context, template)
        dependencies = {str(context.reader.root / relative): copy.deepcopy(context.reader.bindings[str(context.reader.root / relative)])
            for relative in (body.IMPLEMENTATION, body.TEST)}
        body._merge(dependencies, sink)
        bindings = sorted(dependencies.values(), key=lambda item: item["path"])
        hashes = {proof["state_id"]: proof["asset_binding"]["sha256"] for proof in originals}
        if len(set(hashes.values())) != fixed["unique_count"]:
            raise ValueError("body cache content population differs")
        for original in originals:
            sid, digest = original["state_id"], original["asset_binding"]["sha256"]
            aliases = [key for key, value in hashes.items() if value == digest]
            expected = ["visual-u036-s00", "visual-u037-s00"] if template == body.RECORD and sid in ("visual-u036-s00", "visual-u037-s00") else [sid]
            _same(aliases, expected, "body cache alias population differs")
            proof = {"version": body.VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", "template_id": template,
                **copy.deepcopy(context.contracts[template][sid]), "media_kind": "STATIC_IMAGE", "width": 1920, "height": 1080,
                "mode": "RGB", "opacity": "OPAQUE", "asset_binding": copy.deepcopy(original["asset_binding"]), "content_sha256": digest,
                "equivalent_state_ids": aliases, "canonical_content_state_id": aliases[0],
                "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
                "source_video_fps": None, "source_video_duration": None, "observed_sample": None, "video_frame": None,
                "lineage_id": config["lineage_id"], "channel_id": primitives.CHANNEL, "style_bible_id": context.bible["style_bible_id"],
                "source_technically_verified": True, "source_ready": False, "global_schedule_created": False,
                "calibrated_timing_available": False, "technical_cost_brl": 0, "authority": dict(body.AUTHORITY),
                "state_count": 6, "unique_content_count": fixed["unique_count"], "lineage_count": 1,
                "receipt_binding": {"path": str(context.reader.root / config["directory"] / "receipt.json"), "sha256": config["receipt_sha256"]},
                "source_bindings": copy.deepcopy(config["source_bindings"]), "qa_report_binding": copy.deepcopy(fixed["report"]),
                "literal_reference_scope": "STAGED_CASE_V6_METADATA_NOT_ACTIVE_A11_OR_TIMING",
                "historical_qa_scope": "NEW_STATIC_PIXEL_INK_REPLAY_SAVED_OCR_NO_NEW_INFERENCE",
                "image_decode_calls": fixed["unique_count"], "template_image_decode_calls": fixed["unique_count"],
                "counter_scope": "ONE_FULL_TEMPLATE_REPLAY_NOT_PER_STATE_OR_MIXED_OPERATION",
                "proof_identity_scope": "TEMPLATE_LOCAL_INDEPENDENT_OF_REQUEST_BATCH", "ocr_inference_calls": 0, "render_calls": 0,
                "dependency_bindings": copy.deepcopy(bindings),
                "replay_inspection": {"version": original["version"], "inspection_id": original["inspection_id"], "sha256": primitives._sha(primitives._canonical(original))},
                "claim_boundary": "Twelve fixed still states only; no active-plan installation, timing, rights/publicity, audio, motion, final-video QA or new independent lineage."}
            proof["inspection_id"] = "body-source-" + primitives._sha(primitives._canonical(proof))[:24]
            result.append(proof)
    return result


def _execution(context, candidates):
    rows = []
    for template in context.templates:
        values = context.replays[template]
        arguments = values["arguments"]
        rows.append({"template_id": template, "replay_version": values["module"].VERSION,
            "implementation_pins": copy.deepcopy(arguments["code_pins"]), "source_receipt": copy.deepcopy(arguments["source_receipt"]),
            "qa_report_binding": copy.deepcopy(arguments["report_binding"]), "state_count": 6,
            "image_decode_calls": body.REPLAYS[template]["unique_count"], "ocr_inference_calls": 0, "render_calls": 0, "technical_cost_brl": 0})
    return {"version": "phase6-av-body-source-execution-v1", "status": "STATIC_SOURCE_BATCH_VERIFIED_NOT_ADMITTED",
        "templates": [row["template_id"] for row in rows], "replay_count": len(rows),
        "image_decode_calls": sum(row["image_decode_calls"] for row in rows), "ocr_inference_calls": 0, "render_calls": 0,
        "technical_cost_brl": 0, "template_executions": rows,
        "requested_state_ids": [row["state_id"] for row in candidates], "authority": dict(body.AUTHORITY)}


def _request(registration, rights, request, candidates):
    recorded = rights._utc(request["recorded_at"])
    if any(recorded < rights._utc(note["not_before"]) for note in registration.NOTES.values()):
        raise ValueError("body registration predates specific review")
    expected = dict(version=registration.VERSION, review_bindings=registration.NOTES, recorded_at=request["recorded_at"],
        code_pins=CODE_PINS, states=[{key: row[key] for key in ("template_id", "state_id", "asset_id", "arguments")} for row in candidates],
        document_bindings=[{"path": str(path), "sha256": primitives._sha(raw)} for row in candidates for path, raw in row["files"]],
        source_preflight_scope="RECOMPOSED_METADATA_ONLY_NOT_SOURCE_OR_RIGHTS_APPROVAL", technical_cost_brl=0, authority=rights.AUTHORITY)
    _same(request, expected, "body registration request does not independently recompose")
    return expected


def _receipt(registration, rights, reader, receipt, request, claim, sources, proofs, execution):
    identity = "d171-body-rights-registration-" + REQUEST["sha256"][:24]
    expected_claim = dict(version=registration.VERSION, registration_id=identity, request_sha256=REQUEST["sha256"],
        recorded_at=request["recorded_at"], status="CLAIMED_NOT_REGISTERED", authority=rights.AUTHORITY)
    _same(claim, expected_claim, "body registration claim does not recompose")
    created = rights._utc(receipt["created_at"])
    elapsed = receipt["duration_seconds"]
    if (created < rights._utc(request["recorded_at"]) or type(elapsed) not in (int, float)
            or not math.isfinite(elapsed) or elapsed < 0):
        raise ValueError("historical registration measurement differs")
    expected = dict(version=registration.VERSION, registration_id=identity, status="REGISTERED_RIGHTS_ONLY_NOT_ADMITTED", request=request,
        request_binding={"path": str(reader.root / REQUEST["path"]), "sha256": REQUEST["sha256"]},
        claim_binding={"path": str(reader.root / CLAIM["path"]), "sha256": CLAIM["sha256"]},
        created_at=receipt["created_at"], duration_seconds=elapsed, duration_scope="THROUGH_RIGHTS_PROOFS_BEFORE_RECEIPT_WRITE",
        rights_proofs=proofs, source_proofs=sources, source_replay_execution=execution, state_count=12, document_count=24,
        lineage_count=1, technical_cost_brl=0, authority=rights.AUTHORITY,
        claim_boundary="Specific external automated editorial notes and source replay only; no copyright grant, human gold, publicity, timing, source admission or video publication.")
    _same(receipt, expected, "body registration proof/dependency/rights graph does not recompose")


def recheck(reader):
    """Recheck a same-call Reader superset, never a candidate dependency list."""
    if not isinstance(reader, primitives._Reader):
        raise ValueError("actual same-call Reader required for body cache recheck")
    dependencies = dict(reader.bindings)
    for item in tuple(dependencies.values()):
        body._read_dependency(reader, item)
    required = {**CODE_PINS, **NOTE_PINS, **{bound["path"]: bound["sha256"] for bound in (REGISTRATION, REQUEST, CLAIM)}}
    request = _document(reader, REQUEST)
    # All paths here derive from the external request pin, not source/rights
    # proof dependency fields. A superset may carry V3/V4/case same-call inputs.
    for bound in request["document_bindings"]:
        path = Path(bound["path"])
        if not path.is_relative_to(reader.root / DIRECTORY):
            raise ValueError("body registered document escapes fixed namespace")
        required[path.relative_to(reader.root).as_posix()] = bound["sha256"]
    for path, digest in required.items():
        if dependencies.get(str(reader.root / path), {}).get("sha256") != digest:
            raise ValueError("body cache mandatory dependency missing or repinned: " + path)
    for relative in (IMPLEMENTATION, TEST):
        if str(reader.root / relative) not in dependencies:
            raise ValueError("body cache implementation dependency missing")
    body._inventory(reader, BASE, {"receipt.json", "request.json", "claim.json"})
    body._inventory(reader, DIRECTORY, {Path(bound["path"]).name for bound in request["document_bindings"]})
    for template in body.CONFIGS:
        body._required_evidence(reader, template, dependencies)


def replay(root):
    reader = primitives._Reader(root)
    registration, rights, receipt, request, claim = _load(reader)
    candidates = registration.plans(reader, body, rights, request["recorded_at"], dict(CODE_PINS))
    request = _request(registration, rights, request, candidates)
    for row in candidates:
        for path, raw in row["files"]:
            if reader.read_path(path, primitives._sha(raw), limit=LIMIT) != raw:
                raise ValueError("body registered document differs from reconstructed plan")
    arguments = [{key: row["arguments"][key] for key in ("template_id", "state_id", "receipt_binding")} for row in candidates]
    context = body.preflight_body_sources(root, arguments)
    sources = _sources(context)
    _same(receipt["source_proofs"], sources, "registered source proofs differ from independently reopened metadata")
    # Only reconstructed same-call proofs can enter the rights document helper.
    # It reopens schema/notes/artifacts and returns its actual reader union;
    # neither public rights inspector nor source inspector is invoked.
    by_key = {(row["template_id"], row["state_id"]): row for row in sources}
    def source_loader(template, state, binding):
        proof = by_key[(template, state)]
        _same(binding, proof["receipt_binding"], "body rights source receipt association differs")
        return proof
    proofs = [rights._validate(root, **row["arguments"], expected_evidence_mode="LIVE", _source_loader=source_loader) for row in candidates]
    execution = _execution(context, candidates)
    _receipt(registration, rights, reader, receipt, request, claim, sources, proofs, execution)
    # These lists are freshly built by actual Reader-backed helpers, not copied
    # from the registered candidate. Read through the bounded sink again.
    dependencies = dict(context.reader.bindings)
    for proof in proofs:
        body._merge(dependencies, proof["dependency_bindings"])
    for item in dependencies.values():
        body._read_dependency(reader, item)
    body.recheck_body_context(context)
    recheck(reader)
    result = {"version": VERSION, "status": "EXACT_CACHE_REPLAY", "registration_binding": copy.deepcopy(REGISTRATION),
        "request_binding": copy.deepcopy(REQUEST), "claim_binding": copy.deepcopy(CLAIM),
        "sources": copy.deepcopy(sources), "rights": copy.deepcopy(proofs), "registry": copy.deepcopy(request["states"]),
        "state_count": 12, "source_count": 12, "unique_png_content_count": 11, "lineage_count": 1,
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
        "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0, "rights_decisions_created": 0, "technical_cost_brl": 0,
        "historical_source_replay_execution": copy.deepcopy(execution),
        "source_proof_scope": "EXACT_HISTORICAL_REGISTERED_PROOFS_NOT_NEW_PIXEL_OR_RIGHTS_APPROVAL",
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"]), "authority": dict(body.AUTHORITY)}
    result["inspection_id"] = "body-sources-exact-cache-" + primitives._sha(primitives._canonical(result))[:24]
    return primitives._json(primitives._canonical(result))
