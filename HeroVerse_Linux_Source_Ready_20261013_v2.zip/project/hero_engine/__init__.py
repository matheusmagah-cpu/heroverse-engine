"""HERO Engine: auditable YouTube modeling and production pipeline."""

__version__ = "0.1.0"

