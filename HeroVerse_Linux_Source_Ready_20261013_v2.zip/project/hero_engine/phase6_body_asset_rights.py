"""Read-only binding of an externally reviewed OWNED decision to exact stills.

This does not grant copyright, assert human authorship, issue a legal opinion,
approve publicity or create an approval document. Motion rights are not reused.
Only the two separately reviewed body templates and twelve frozen states are
in scope. Shared typography does not transfer observation or source rights.
All earlier still-source inspectors and rights contracts remain unchanged.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
from pathlib import Path
import re

from jsonschema import Draft202012Validator, ValidationError

from . import phase6_av_static_sources as sources
from . import phase6_av_body_sources as body
from .phase6_narration_units import canonical_sha

VERSION = "phase6-body-asset-rights-v1"
SCHEMA = "schemas/phase6_body_static_rights.schema.json"
REVIEW_NOTES = {
    "three-moves-identity-v1": {
        "path": "docs/evidence/D171_THREE_MOVES_EDITORIAL_RIGHTS_REVIEW.md",
        "sha256": "bc6831191d31481a575d1df66f13b93216ed103ebea1e8b7a6eb97b8a5fbb0ca",
        "not_before": "2026-09-08T04:24:13Z"},
    "record-learning-v1": {
        "path": "docs/evidence/D171_RECORD_LEARNING_EDITORIAL_RIGHTS_REVIEW.md",
        "sha256": "32d4be7d6700d99a1f6008ead87ffa369c1ffceef4862a26497b34b2db54926c",
        "not_before": "2026-09-08T04:50:06Z"},
}
PRIMARY_NOTE = "docs/evidence/D171_TEST_QUESTIONS_EDITORIAL_RIGHTS_REVIEW.md"
PRIMARY_NOTE_SHA = "79fbcfa95516d90df7207b719af7df950fe917cc1748e5c922b486019f7f970c"

PROVENANCE_KEYS = set("schema_version document_type provenance_id evidence_mode recorded_at asset_id channel_id template_id state_id lineage_id png_binding svg_binding recipe_binding generation_receipt_binding source_bindings composition_origin depiction_scope font_use technical_cost_brl".split())
DECISION_KEYS = set("schema_version document_type decision_id evidence_mode reviewed_at asset_id channel_id template_id state_id provenance_binding decision rights_status commercial_use reviewer editorial_review_binding decision_basis unresolved_questions output_scope platform_disclosure technical_cost_brl".split())
AUTHORITY = {name: False for name in ("selection_authorized", "source_admitted", "render_authorized",
    "queue_authorized", "publication_authorized", "publicity_approved", "quality_approved",
    "final_video_disclosure_approved", "human_review_performed", "legal_opinion_issued")}
STATES = {
    "three-moves-identity-v1": ("visual-u032-s00", "visual-u033-s00", "visual-u035-s00", "visual-u047-s00", "visual-u048-s00", "visual-u049-s00"),
    "record-learning-v1": ("visual-u036-s00", "visual-u037-s00", "visual-u037-s01", "visual-u038-s00", "visual-u038-s01", "visual-u038-s02"),
}
_IMPLEMENTATION_PINS = {name: sources._sha(sources._resident(Path(__file__).absolute().with_name(name)).read_bytes())
                        for name in ("phase6_body_asset_rights.py", "phase6_narration_units.py")}
_SCHEMA_PIN = sources._sha(sources._resident(Path(__file__).absolute().parent.parent / SCHEMA).read_bytes())


class StaticRightsError(ValueError):
    pass


def _require(condition, code):
    if not condition:
        raise StaticRightsError(code)


def _exact(value, keys, code):
    _require(type(value) is dict and set(value) == keys, code)


def _same(actual, expected, code):
    _require(sources._canonical(actual) == sources._canonical(expected), code)


def _text(value, code):
    _require(type(value) is str and bool(value.strip()), code)


def _merge_dependencies(*groups):
    merged = {}
    for group in groups:
        for item in group:
            _exact(item, {"path", "sha256", "size_bytes"}, "RIGHTS_DEPENDENCY_FIELDS_DIFFER")
            if item["path"] in merged:
                _same(item, merged[item["path"]], "RIGHTS_DEPENDENCY_IDENTITY_CONFLICT")
            merged[item["path"]] = item
    return sorted(merged.values(), key=lambda item: item["path"])


def _utc(value):
    _require(type(value) is str and value.endswith("Z"), "EXPLICIT_UTC_REQUIRED")
    instant = datetime.fromisoformat(value[:-1] + "+00:00")
    _require(instant.utcoffset() == timezone.utc.utcoffset(instant), "UTC_REQUIRED")
    _require(instant <= datetime.now(timezone.utc), "FUTURE_REVIEW_NOT_EVIDENCE")
    return instant


def _identity(document, field, prefix):
    payload = {key: value for key, value in document.items() if key != field}
    _same(document[field], prefix + sources._sha(sources._canonical(payload))[:24], "DOCUMENT_IDENTITY_DIFFERS")


def _pin(reader, binding, *, expected=None):
    _exact(binding, {"path", "sha256"}, "EXTERNAL_PIN_FIELDS_DIFFER")
    _require(type(binding["path"]) is str and type(binding["sha256"]) is str
             and re.fullmatch(r"[a-f0-9]{64}", binding["sha256"]) is not None, "EXPLICIT_RAW_SHA256_REQUIRED")
    path = Path(binding["path"])
    if path.is_absolute():
        _require(path.is_relative_to(reader.root), "RIGHTS_DOCUMENT_ESCAPES_ROOT")
        relative = path.relative_to(reader.root).as_posix()
    else:
        relative = binding["path"]
    path = reader.path(relative)
    if expected is not None:
        expected_path, digest = expected
        _same([str(path), binding["sha256"]], [str(reader.root / expected_path), digest], "RIGHTS_SOURCE_PIN_DIFFERS")
    raw = reader.read(relative, binding["sha256"], limit=2 * 1024**2)
    return {"path": str(path), "sha256": binding["sha256"]}, raw


def _document(reader, binding, keys, kind, field, prefix, mode):
    normalized, raw = _pin(reader, binding)
    _require(Path(normalized["path"]).suffix == ".json", "RIGHTS_DOCUMENT_MUST_BE_JSON")
    document = sources._json(raw)
    _require(sources._canonical(document) == raw, "RIGHTS_JSON_NOT_CANONICAL")
    _exact(document, keys, "RIGHTS_DOCUMENT_FIELDS_DIFFER")
    _same([document["schema_version"], document["document_type"], document["evidence_mode"]],
          ["1.0.0", kind, mode], "RIGHTS_DOCUMENT_KIND_OR_EVIDENCE_MODE_DIFFERS")
    _identity(document, field, prefix)
    return document, normalized


def _expected_scope(root, template_id, state_id, receipt_binding):
    _require(type(template_id) is str and template_id in REVIEW_NOTES and template_id in body.CONFIGS, "UNSUPPORTED_STATIC_TEMPLATE")
    config = body.CONFIGS[template_id]
    _same(list(config["state_ids"]), list(STATES[template_id]), "BODY_TEMPLATE_STATE_POPULATION_DIFFERS")
    _require(type(state_id) is str and state_id in STATES[template_id], "UNSUPPORTED_STATIC_STATE")
    _exact(receipt_binding, {"path", "sha256"}, "STATIC_GENERATION_PIN_REQUIRED")
    _require(receipt_binding["sha256"] == config["receipt_sha256"], "STATIC_GENERATION_PIN_DIFFERS")
    expected = Path(root).absolute() / config["directory"] / "receipt.json"
    _require(receipt_binding["path"] in (str(expected), config["directory"] + "/receipt.json"),
             "STATIC_GENERATION_PATH_DIFFERS")
    return config


def _preflight_artifacts(reader, provenance, config, state_id):
    """Physical pins before any template source replay or PNG container check.

    This is not source approval: the complete inspector must still recompose
    its source/QA history. In particular, aliases retain their own state path.
    """
    receipt_pin, receipt_raw = _pin(reader, provenance["generation_receipt_binding"],
        expected=(config["directory"] + "/receipt.json", config["receipt_sha256"]))
    receipt = sources._json(receipt_raw)
    _same(receipt_raw.decode("utf-8"), sources._canonical(receipt).decode("utf-8"), "SOURCE_RECEIPT_JSON_NOT_CANONICAL")
    names = {sid + extension for sid in config["state_ids"] for extension in (".png", ".svg")} | {"layouts.json"}
    _exact(receipt["artifact_sha256"], names, "SOURCE_ARTIFACT_INVENTORY_DIFFERS")
    expected = {
        "png_binding": (config["directory"] + "/" + state_id + ".png", receipt["artifact_sha256"][state_id + ".png"]),
        "svg_binding": (config["directory"] + "/" + state_id + ".svg", receipt["artifact_sha256"][state_id + ".svg"]),
        "recipe_binding": (config["runner"], config["runner_sha256"]),
    }
    pins = {"generation_receipt_binding": receipt_pin}
    for field, expected_binding in expected.items():
        pins[field], _ = _pin(reader, provenance[field], expected=expected_binding)
    expected_inputs = [{"path": str(reader.root / binding["path"]), "sha256": binding["sha256"]}
                       for _, binding in sorted(config["source_bindings"].items())]
    _same(provenance["source_bindings"], expected_inputs, "OWNED_RECIPE_INPUTS_DIFFER")
    _require(len({item["path"] for item in expected_inputs}) == len(expected_inputs), "DUPLICATE_RECIPE_SOURCE_IDENTITY")
    for source in provenance["source_bindings"]:
        _pin(reader, source)
    return pins


def _validate(root, *, template_id, state_id, receipt_binding, provenance_binding,
              decision_binding, expected_evidence_mode, _source_loader=None, _preflight_only=False):
    config = _expected_scope(root, template_id, state_id, receipt_binding)
    review_note = REVIEW_NOTES[template_id]
    _require(expected_evidence_mode in {"LIVE", "FIXTURE"}, "EXPLICIT_EVIDENCE_MODE_REQUIRED")
    _require(provenance_binding is not None, "STATIC_OWNED_PROVENANCE_MISSING")
    _require(decision_binding is not None, "STATIC_RIGHTS_DECISION_MISSING")
    reader = sources._Reader(root)
    for filename, digest in _IMPLEMENTATION_PINS.items():
        reader.read("hero_engine/" + filename, digest)
    provenance, provenance_pin = _document(reader, provenance_binding, PROVENANCE_KEYS,
        "PHASE6_STATIC_OWNED_PROVENANCE", "provenance_id", "static-owned-provenance-", expected_evidence_mode)
    decision, decision_pin = _document(reader, decision_binding, DECISION_KEYS,
        "PHASE6_STATIC_RIGHTS_DECISION", "decision_id", "static-owned-decision-", expected_evidence_mode)
    _same(decision["provenance_binding"], provenance_pin, "DECISION_REFERENCES_ANOTHER_PROVENANCE")
    _require(_utc(provenance["recorded_at"]) <= _utc(decision["reviewed_at"]), "REVIEW_PRECEDES_PROVENANCE")
    for value in (provenance, decision):
        _same([value["channel_id"], value["template_id"], value["state_id"]],
              [sources.CHANNEL, template_id, state_id], "RIGHTS_CHANNEL_TEMPLATE_OR_STATE_DIFFERS")
        _text(value["asset_id"], "ASSET_ID_REQUIRED")
        _same(value["technical_cost_brl"], 0, "ZERO_TECHNICAL_COST_REQUIRED")
    _same(decision["asset_id"], provenance["asset_id"], "RIGHTS_ASSET_ID_DIFFERS")
    _same(provenance["lineage_id"], config["lineage_id"], "RIGHTS_LINEAGE_DIFFERS")
    _same([decision["decision"], decision["rights_status"], decision["commercial_use"], decision["output_scope"]],
          ["RESPONSIBLE_REVIEW_APPROVED", "OWNED", True, "RASTERIZED_STILL_IN_YOUTUBE_VIDEO"],
          "PERMITTED_OWNED_DECISION_REQUIRED")
    _same(decision["unresolved_questions"], [], "UNRESOLVED_RIGHTS_QUESTIONS")
    reviewer = decision["reviewer"]
    _exact(reviewer, {"id", "type", "human_review_claim", "legal_opinion_claim"}, "REVIEWER_FIELDS_DIFFER")
    _text(reviewer["id"], "RESPONSIBLE_REVIEWER_ID_REQUIRED")
    _same([reviewer["type"], reviewer["human_review_claim"], reviewer["legal_opinion_claim"]],
          ["AUTHORIZED_AUTOMATED_EDITORIAL", False, False], "UNSUPPORTED_REVIEW_AUTHORITY_CLAIM")
    _text(decision["decision_basis"], "RESPONSIBLE_REVIEW_BASIS_REQUIRED")
    editorial_review, _ = _pin(reader, decision["editorial_review_binding"], expected=(review_note["path"], review_note["sha256"]))
    _require(_utc(decision["reviewed_at"]) >= _utc(review_note["not_before"]), "REVIEW_PRECEDES_BODY_EDITORIAL_DECISION")
    origin = provenance["composition_origin"]
    _exact(origin, {"method", "basis", "human_authorship_claim", "exclusive_ai_rights_claim", "third_party_visual_assets"},
           "COMPOSITION_ORIGIN_FIELDS_DIFFER")
    _same([origin["method"], origin["human_authorship_claim"], origin["exclusive_ai_rights_claim"], origin["third_party_visual_assets"]],
          ["PROJECT_CODE_NATIVE_VECTOR", False, False, []], "OWNED_ORIGIN_OR_THIRD_PARTY_SCOPE_DIFFERS")
    _text(origin["basis"], "COMPOSITION_PROVENANCE_BASIS_REQUIRED")
    depiction = provenance["depiction_scope"]
    _exact(depiction, {"kind", "people", "brands", "logos", "real_world_recording", "observation_evidence_binding"},
           "DEPICTION_SCOPE_FIELDS_DIFFER")
    _same([depiction["kind"], depiction["people"], depiction["brands"], depiction["logos"], depiction["real_world_recording"]],
          ["NON_REALISTIC_EDITORIAL_TEXT_DIAGRAM", [], [], [], False], "DEPICTION_OUTSIDE_REVIEWED_SCOPE")
    _pin(reader, depiction["observation_evidence_binding"], expected=(review_note["path"], review_note["sha256"]))
    font = provenance["font_use"]
    _exact(font, {"font_binding", "usage", "font_file_embedded", "font_redistribution", "license_evidence_binding"},
           "FONT_USE_FIELDS_DIFFER")
    _same(font["font_binding"], {"path": str(sources.FONT), "sha256": sources.FONT_SHA}, "FONT_SOURCE_DIFFERS")
    _same([font["usage"], font["font_file_embedded"], font["font_redistribution"]],
          ["RASTERIZED_TEXT_IN_VIDEO", False, False], "FONT_DISTRIBUTION_NOT_AUTHORIZED")
    note, _ = _pin(reader, font["license_evidence_binding"], expected=(PRIMARY_NOTE, PRIMARY_NOTE_SHA))
    disclosure = decision["platform_disclosure"]
    _exact(disclosure, {"scope", "required", "reason", "policy_evidence_binding", "final_video_decision"},
           "STATIC_DISCLOSURE_FIELDS_DIFFER")
    _same([disclosure["scope"], disclosure["final_video_decision"]],
          ["STATIC_IMAGE_ONLY", "REQUIRES_AGGREGATE_VIDEO_GATE"], "DISCLOSURE_CANNOT_APPROVE_WHOLE_VIDEO")
    _require(type(disclosure["required"]) is bool, "EXPLICIT_IMAGE_DISCLOSURE_DECISION_REQUIRED")
    _text(disclosure["reason"], "IMAGE_DISCLOSURE_REASON_REQUIRED")
    _pin(reader, disclosure["policy_evidence_binding"], expected=(PRIMARY_NOTE, PRIMARY_NOTE_SHA))
    schema = sources._json(reader.read(SCHEMA, _SCHEMA_PIN))
    validator = Draft202012Validator(schema)
    validator.validate(provenance)
    validator.validate(decision)
    preflight_artifacts = _preflight_artifacts(reader, provenance, config, state_id)
    if _preflight_only:
        # Private fail-fast document pass, never a proof/cache/approval API.
        # The complete pass reopens these same caller-pinned documents again;
        # source verification and the final batch dependency recheck still run.
        return None
    # Reopen the two-template body source chain and its pinned static QA replay.
    # The source consumer checks PNG containers and all historical byte pins;
    # this rights path neither decodes again nor re-runs OCR/QA.
    proof = (body.inspect_body_source(root, template_id=template_id, state_id=state_id,
                                          receipt_binding=receipt_binding) if _source_loader is None
             else _source_loader(template_id, state_id, receipt_binding))
    _same([proof["status"], proof["channel_id"], proof["template_id"], proof["state_id"], proof["lineage_id"],
           proof["media_kind"], proof["source_frame_count"], proof["source_start_frame"], proof["source_end_frame"],
           proof["source_technically_verified"], proof["source_ready"], proof["technical_cost_brl"]],
          ["STATIC_SOURCE_VERIFIED_NOT_ADMITTED", sources.CHANNEL, template_id, state_id, config["lineage_id"],
           "STATIC_IMAGE", 1, 0, 1, True, False, 0], "BODY_SOURCE_SCOPE_DIFFERS")
    _same(proof["authority"], dict.fromkeys(("synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized",
        "quality_approved", "source_admitted", "timing_validated", "rights_approved", "publicity_approved"), False),
        "BODY_SOURCE_AUTHORITY_FORBIDDEN")
    proof_files = {item["path"]: item for item in proof["dependency_bindings"]}
    _require(len(proof_files) == len(proof["dependency_bindings"]), "BODY_SOURCE_DUPLICATE_DEPENDENCY")
    asset = proof["asset_binding"]
    _same(asset["path"], str(reader.root / config["directory"] / (state_id + ".png")),
          "BODY_SOURCE_ASSET_PATH_DIFFERS")
    _same(asset, proof_files[asset["path"]], "BODY_SOURCE_ASSET_IDENTITY_DIFFERS")
    paths = {"png_binding": Path(asset["path"]), "svg_binding": Path(asset["path"]).with_suffix(".svg"),
             "recipe_binding": reader.root / config["runner"],
             "generation_receipt_binding": reader.root / config["directory"] / "receipt.json"}
    bound_artifacts = {}
    for field, path in paths.items():
        expected = proof_files[str(path)]
        _same(provenance[field], {"path": str(path), "sha256": expected["sha256"]}, "OWNED_ARTIFACT_BINDING_DIFFERS")
        _same(preflight_artifacts[field], provenance[field], "RIGHTS_PREFLIGHT_BINDING_CHANGED")
        pin, _ = _pin(reader, provenance[field])
        bound_artifacts[field] = {**pin, "size_bytes": expected["size_bytes"]}
    expected_inputs = [{"path": str(reader.root / binding["path"]), "sha256": binding["sha256"]}
                       for _, binding in sorted(config["source_bindings"].items())]
    _same(provenance["source_bindings"], expected_inputs, "OWNED_RECIPE_INPUTS_DIFFER")
    for source in provenance["source_bindings"]:
        _pin(reader, source)
    # Only replay/read: no rights receipt, manifest row or admission is created.
    if _source_loader is None:
        body.recheck_body_dependencies(root, [proof])
    for item in tuple(reader.bindings.values()):
        raw = reader.read_path(Path(item["path"]), item["sha256"])
        _same(len(raw), item["size_bytes"], "RIGHTS_DEPENDENCY_SIZE_CHANGED")
    result = {"version": VERSION, "status": "PASS" if expected_evidence_mode == "LIVE" else "PASS_FIXTURE_NOT_LIVE",
        "scope": "RIGHTS_BINDING_ONLY", "evidence_mode": expected_evidence_mode,
        "asset_id": provenance["asset_id"], "channel_id": sources.CHANNEL,
        "template_id": template_id, "state_id": state_id, "lineage_id": config["lineage_id"],
        "media_kind": "STATIC_IMAGE", "source_frame_count": 1,
        "source_start_frame": 0, "source_end_frame": 1,
        "rights_status": "OWNED", "commercial_use": True, "source_ready": False,
        # Preserve the historical pretty-JSON byte pin; Stage A uses a distinct
        # compact canonical encoding, whose prefixed hash is bound explicitly.
        "source_proof": {"inspection_id": proof["inspection_id"], "sha256": sources._sha(sources._canonical(proof)),
                         "timeline_canonical_sha256": canonical_sha(proof)},
        "artifacts": bound_artifacts, "provenance_binding": provenance_pin, "decision_binding": decision_pin,
        "provenance_id": provenance["provenance_id"], "decision_id": decision["decision_id"],
        "platform_disclosure": disclosure, "depiction_scope": depiction, "primary_note_binding": note,
        "editorial_review_binding": editorial_review,
        "dependency_bindings": _merge_dependencies(proof["dependency_bindings"], reader.bindings.values()),
        "technical_cost_brl": 0, "blockers": [], "authority": dict(AUTHORITY),
        "claim_boundary": "Reopened the separate external OWNED decision for this body template and exact static source chain only. Shared typography evidence does not transfer visual rights or create copyright, human review, legal opinion, font redistribution, publicity or video approval."}
    result["inspection_id"] = "body-static-rights-" + sources._sha(sources._canonical(result))[:24]
    return result


def inspect_body_asset_rights(root, *, template_id, state_id, receipt_binding,
                               provenance_binding=None, decision_binding=None,
                               expected_evidence_mode="LIVE"):
    """External documents are required; absent/ambiguous evidence fails closed.

    The default requires LIVE documents. Tests must explicitly request FIXTURE;
    their return is never a LIVE PASS. This function performs no writes/effects.
    """
    try:
        return _validate(root, template_id=template_id, state_id=state_id, receipt_binding=receipt_binding,
                         provenance_binding=provenance_binding, decision_binding=decision_binding,
                         expected_evidence_mode=expected_evidence_mode)
    except (ValueError, OSError, KeyError, TypeError, ValidationError) as exc:
        return {"version": VERSION, "status": "BLOCKED", "scope": "RIGHTS_BINDING_ONLY",
                "rights_status": None, "commercial_use": False, "source_ready": False,
                "technical_cost_brl": 0, "blockers": [str(exc) or type(exc).__name__],
                "authority": dict(AUTHORITY)}


def verify_body_asset_rights(candidate, root, **arguments):
    """Reopen caller-pinned originals, never candidate-selected authority."""
    expected = inspect_body_asset_rights(root, **arguments)
    _same(candidate, expected, "STATIC_RIGHTS_REPLAY_DIFFERS")
    return expected



def inspect_body_asset_rights_batch(root, *, requests, expected_evidence_mode="LIVE",
                                   _source_proof_sink=None, _execution_sink=None):
    """Preflight every document; one source batch, one replay per template.

    The private source cache lives only within this call. No candidate-supplied
    proof, cross-call cache, previous template's rights or cached approval is
    accepted. A later failure invalidates the batch, not just its last state.
    """
    for sink in (_source_proof_sink, _execution_sink):
        _require(sink is None or (type(sink) is list and not sink), "FRESH_PRIVATE_RIGHTS_SINK_REQUIRED")
    _require(_source_proof_sink is None or _source_proof_sink is not _execution_sink,
             "DISTINCT_PRIVATE_RIGHTS_SINKS_REQUIRED")
    _require(type(requests) is list and 1 <= len(requests) <= 12, "BOUNDED_RIGHTS_REQUESTS_REQUIRED")
    required = {"template_id", "state_id", "receipt_binding", "provenance_binding", "decision_binding"}
    seen = set()
    for request in requests:
        _exact(request, required, "RIGHTS_BATCH_REQUEST_FIELDS_DIFFER")
        _expected_scope(root, request["template_id"], request["state_id"], request["receipt_binding"])
        key = (request["template_id"], request["state_id"])
        _require(key not in seen, "DUPLICATE_RIGHTS_STATE")
        seen.add(key)
    for request in requests:
        _validate(root, **request, expected_evidence_mode=expected_evidence_mode, _preflight_only=True)
    cache, executions = {}, []
    def source_loader(template, state, receipt):
        if not cache:
            arguments = [{key: row[key] for key in ("template_id", "state_id", "receipt_binding")} for row in requests]
            extra = {"_execution_sink": executions} if _execution_sink is not None else {}
            proofs = body.inspect_body_sources(root, requests=arguments, **extra)
            _require(type(proofs) is list and len(proofs) == len(requests), "RIGHTS_BATCH_SOURCE_POPULATION_DIFFERS")
            keys = [(proof["template_id"], proof["state_id"]) for proof in proofs]
            _same(keys, [(row["template_id"], row["state_id"]) for row in requests], "RIGHTS_BATCH_SOURCE_ORDER_DIFFERS")
            cache.update(zip(keys, proofs, strict=True))
        proof = cache[(template, state)]
        _same([proof["template_id"], proof["state_id"]], [template, state], "RIGHTS_BATCH_SOURCE_DIFFERS")
        return proof
    result = [_validate(root, **request, expected_evidence_mode=expected_evidence_mode,
                        _source_loader=source_loader) for request in requests]
    # One final same-call recheck covers every decision and source. Individual
    # batch rows do not replay the two complete source histories repeatedly.
    # Recheck every decision and source after the last state; earlier files
    # changing while a later state is verified must invalidate the whole batch.
    body.recheck_body_dependencies(root, result)
    # Export only after every source, decision and final dependency passed.
    # These are private same-call outputs, never an input proof/cache shortcut.
    if _execution_sink is not None:
        _require(len(executions) == 1, "ONE_SUCCESSFUL_SOURCE_BATCH_EXECUTION_REQUIRED")
    exported_sources = copy.deepcopy([cache[(row["template_id"], row["state_id"])] for row in requests])
    exported_executions = copy.deepcopy(executions)
    if _source_proof_sink is not None:
        _source_proof_sink.extend(exported_sources)
    if _execution_sink is not None:
        _execution_sink.extend(exported_executions)
    return result
