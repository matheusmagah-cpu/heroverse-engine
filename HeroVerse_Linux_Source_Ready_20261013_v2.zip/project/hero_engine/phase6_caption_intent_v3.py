"""Current, receipt-bound caption intent for Video 2.

This is a forward-only successor to the frozen A7 caption adapter.  A7 remains
an immutable historical reader; this module never repins it and does not
convert its coverage into timing, render, or publication authority.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any


VERSION = "phase6-caption-intent-v3-current-receipt"
RECEIPT_PATH = "output/production/phase6/video-002/production/production_inputs_receipt.json"
TAKE_PLAN_PATH = "output/production/phase6/video-002/production/take_plan.json"
_FALSE_AUTHORITY = {key: False for key in ("timing", "render", "publication", "queue", "quality")}


class CurrentCaptionIntentError(ValueError):
    pass


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical(value: Any) -> str:
    return _sha(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode())


def _read_json(path: Path, label: str) -> tuple[bytes, dict[str, Any]]:
    raw = path.read_bytes()
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CurrentCaptionIntentError(f"{label} is not UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise CurrentCaptionIntentError(f"{label} is not an object")
    return raw, value


def _binding(path: str, raw: bytes) -> dict[str, Any]:
    return {"path": path, "sha256": _sha(raw), "size_bytes": len(raw)}


def _receipt_and_plan(root: Path, supplied: dict[str, Any] | None = None) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    root = Path(root).resolve(strict=True)
    receipt_raw, receipt = _read_json(root / RECEIPT_PATH, "production inputs receipt")
    receipt_binding = _binding(RECEIPT_PATH, receipt_raw)
    if supplied is not None and supplied != receipt_binding:
        raise CurrentCaptionIntentError("production inputs receipt binding differs")
    if receipt.get("schema_version") != "1.2.0" or receipt.get("status") != "COMPILED":
        raise CurrentCaptionIntentError("production inputs receipt is not compiled")
    artifacts = receipt.get("artifacts")
    if not isinstance(artifacts, list):
        raise CurrentCaptionIntentError("production inputs receipt artifacts are absent")
    by_path = {row.get("path"): row for row in artifacts if isinstance(row, dict)}
    row = by_path.get(TAKE_PLAN_PATH)
    if not isinstance(row, dict) or set(row) != {"path", "sha256", "size_bytes"}:
        raise CurrentCaptionIntentError("production inputs receipt does not bind the current take plan")
    take_raw, take_plan = _read_json(root / TAKE_PLAN_PATH, "current take plan")
    plan_binding = _binding(TAKE_PLAN_PATH, take_raw)
    if row != plan_binding:
        raise CurrentCaptionIntentError("current take plan differs from production inputs receipt")
    takes = take_plan.get("takes")
    if not isinstance(takes, list) or not takes:
        raise CurrentCaptionIntentError("current take plan has no takes")
    return receipt_binding, plan_binding, takes


def active_bindings(root: Path) -> dict[str, dict[str, Any]]:
    receipt, plan, _ = _receipt_and_plan(root)
    return {"production_inputs_receipt": receipt, "take_plan": plan}


def compile_current_caption_intent(root: Path, *, bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    if not isinstance(bindings, dict) or set(bindings) != {"production_inputs_receipt", "take_plan"}:
        raise CurrentCaptionIntentError("current caption bindings differ")
    receipt, plan, takes = _receipt_and_plan(root, bindings["production_inputs_receipt"])
    if bindings["take_plan"] != plan:
        raise CurrentCaptionIntentError("take plan binding differs from production receipt")
    cues = []
    for index, take in enumerate(takes, 1):
        if not isinstance(take, dict):
            raise CurrentCaptionIntentError("take plan contains a non-object take")
        take_id = f"take-{index:03d}"
        narration = take.get("narration")
        if take.get("take_id") != take_id or not isinstance(narration, str) or not narration.strip():
            raise CurrentCaptionIntentError("current take identity or narration differs")
        cues.append({
            "cue_id": f"current-caption-{index:03d}", "take_id": take_id,
            "text": narration, "start_ms": take.get("start_ms"), "end_ms": take.get("end_ms"),
            "timing_state": "TAKE_CONTAINER_ONLY_NOT_WORD_TIMED",
        })
    if len({cue["take_id"] for cue in cues}) != len(cues):
        raise CurrentCaptionIntentError("current caption take population is not unique")
    value = {
        "version": VERSION, "status": "CURRENT_CAPTION_INTENT_ONLY_NOT_TIMED_OR_ADMITTED",
        "scope": "VIDEO_002_CURRENT_PRODUCTION_RECEIPT_BOUND",
        "production_inputs_receipt_binding": receipt, "take_plan_binding": plan,
        "cue_count": len(cues), "cues": cues, "authority": copy.deepcopy(_FALSE_AUTHORITY),
        "blockers": ["WORD_ALIGNMENT_REQUIRED", "CAPTION_RENDER_AND_LEGIBILITY_GATE_REQUIRED", "ADMISSION_REQUIRED"],
        "technical_cost_brl": 0,
    }
    value["caption_intent_id"] = "phase6-current-caption-intent-" + _canonical(value)[7:31]
    value["canonical_sha256"] = _canonical(value)
    return value


def verify_current_caption_intent(root: Path, candidate: dict[str, Any], *, bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    expected = compile_current_caption_intent(root, bindings=bindings)
    if _canonical(candidate) != _canonical(expected):
        raise CurrentCaptionIntentError("current caption intent differs from receipt-bound recompilation")
    return expected
