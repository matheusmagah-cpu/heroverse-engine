from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from hero_engine.codex_runway import calculate_runway, percent, utc
from hero_engine.atomic_io import atomic_write_utf8


ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = Path("config/codex-usage-policy.json")
OUTPUT_PATH = Path("output/operations/codex-usage/latest.json")


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _iso_epoch(value: Any) -> str | None:
    if value is None:
        return None
    return datetime.fromtimestamp(int(value), tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _band(policy: dict[str, Any], remaining: float) -> dict[str, Any]:
    bands = sorted(policy["bands"], key=lambda item: item["minimum_remaining_percent"])
    cursor = 0
    for item in bands:
        lower, upper = item["minimum_remaining_percent"], item["maximum_remaining_percent"]
        if (type(lower) is not int or type(upper) is not int or lower != cursor
                or not lower <= upper <= 100):
            raise ValueError("capacity bands must partition integer percentage bins 0..100")
        cursor = upper + 1
    if cursor != 101:
        raise ValueError("capacity bands must cover 0..100")
    matches = [
        item for item in bands
        if item["minimum_remaining_percent"] <= remaining
        and (remaining < item["maximum_remaining_percent"] + 1)
    ]
    if len(matches) != 1:
        raise ValueError(f"capacity policy does not cover remaining percent exactly once: {remaining}")
    return matches[0]


def evaluate_usage(
    observation: dict[str, Any],
    policy: dict[str, Any],
    *,
    observed_at: str,
) -> dict[str, Any]:
    """Normalize the native Codex usage response and choose a quality-safe action.

    The local runtime cannot query the account itself.  A Codex-hosted task must
    provide the native get_usage_limits response; this function then makes the
    decision deterministic, testable and persistable without storing account ID.
    """

    quality = policy["quality_policy"]
    capacity = policy["capacity_policy"]
    coordination = policy["coordination"]
    projects = coordination["projects"]
    if (coordination.get("pool_count") != 1 or len(projects) != 2
            or len({p["project_id"] for p in projects}) != 2
            or any(p.get("importance") != "EQUAL" for p in projects)
            or coordination.get("per_project_usage") != "UNAVAILABLE"):
        raise ValueError("shared capacity requires two distinct equal-priority projects and no invented attribution")
    if quality.get("quality_reduction_allowed") is not False:
        raise ValueError("Codex capacity policy may not reduce quality")
    if quality.get("model_selection") != "BEST_AVAILABLE_SUPPORTED" or quality.get("reasoning_effort") != "ultra":
        raise ValueError("Codex quality policy must require best available model with ultra reasoning")
    if capacity.get("purchase_credits") is not False or capacity.get("automatic_top_up") is not False:
        raise ValueError("paid Codex capacity is forbidden by the zero-cost contract")

    by_id = observation.get("rateLimitsByLimitId") or {}
    source = by_id.get("codex") or observation.get("rateLimits") or {}
    primary = source.get("primary") or {}
    if primary.get("usedPercent") is None:
        raise ValueError("authoritative Codex usedPercent is unavailable")
    workload = policy.get("workload_plan")
    active_workload = workload is not None and utc(observed_at) >= utc(workload["recorded_at"])
    if active_workload:
        percent(primary["usedPercent"])
    used = min(100.0, max(0.0, float(primary["usedPercent"])))
    remaining = round(100.0 - used, 6)
    selected_band = _band(policy, remaining)
    reserve = float(capacity["minimum_weekly_reserve_percent"])
    reserve_preserved = remaining >= reserve
    status = selected_band["status"]
    high_consumption_allowed = status in {"GREEN", "AMBER"}
    reset_required = status == "CRITICAL_RESERVE" and source.get("rateLimitReachedType") is not None

    reset_block = observation.get("rateLimitResetCredits") or {}
    reset_items = reset_block.get("credits") or []
    expirations = sorted({item for row in reset_items if (item := _iso_epoch(row.get("expiresAt")))})
    credit_block = source.get("credits") or {}
    rationale = [
        f"Authoritative account headroom is {remaining:g}% in the primary Codex window.",
        f"Policy band {status} preserves maximum model quality and changes only scheduling, batching and priority.",
        "Resident local operation remains independent of Codex allowance and continues under its own gates.",
    ]
    core = {
        "schema_version": "1.1.0",
        "policy_id": policy["policy_id"],
        "observed_at": observed_at,
        "scope": policy["scope"],
        "coordination": coordination,
        "plan": source.get("planType"),
        "limits": {
            "primary_limit_id": str(source.get("limitId") or "codex"),
            "used_percent": used,
            "remaining_percent": remaining,
            "window_minutes": primary.get("windowDurationMins"),
            "resets_at": _iso_epoch(primary.get("resetsAt")),
            "rate_limit_reached_type": source.get("rateLimitReachedType"),
            "spend_control_reached": source.get("spendControlReached"),
        },
        "credits": {
            "has_credits": credit_block.get("hasCredits"),
            "unlimited": credit_block.get("unlimited"),
            "balance": credit_block.get("balance"),
        },
        "reset_credits": {
            "available_count": int(reset_block.get("availableCount") or 0),
            "consumed_now": False,
            "expires_at": expirations,
        },
        "quality_policy": {
            "model_selection": quality["model_selection"],
            "reasoning_effort": quality["reasoning_effort"],
            "quality_reduction_allowed": False,
            "runtime_enforcement_status": "POLICY_RECORDED_HOST_SETTING_NOT_EXPOSED",
        },
        "capacity_decision": {
            "status": status,
            "action": selected_band["codex_action"],
            "reserve_percent": reserve,
            "reserve_preserved": reserve_preserved,
            "high_consumption_work_allowed": high_consumption_allowed,
            "reset_required_now": reset_required,
            "rationale": rationale,
        },
        "continuity": {
            "resident_manager_continues": True,
            "local_schedulers_continue": True,
            "codex_discretionary_work_may_wait": status in {"RED", "CRITICAL_RESERVE"},
            "external_actions_remain_gate_bound": True,
        },
        "cost": {
            "technical_cost_brl": 0,
            "credit_purchase_authorized": False,
            "automatic_top_up_authorized": False,
        },
        "evidence_refs": [
            "Codex app get_usage_limits",
            "config/codex-usage-policy.json",
            "https://learn.chatgpt.com/docs/pricing",
        ],
        "limitations": policy["limitations"],
    }
    if active_workload:
        runway = calculate_runway(workload, observed_at=observed_at,
            resets_at=core["limits"]["resets_at"], used_percent=used,
            reserve_percent=reserve, known_project_ids={p["project_id"] for p in projects})
        core.update(schema_version="1.2.0", workload_plan=workload, renewal_runway=runway)
        if runway["status"] != "ON_PLAN":
            core["capacity_decision"]["high_consumption_work_allowed"] = False
            core["continuity"]["codex_discretionary_work_may_wait"] = True
            if status != "CRITICAL_RESERVE":
                core["capacity_decision"]["action"] = "FULL_QUALITY_CRITICAL_PATH_ONLY"
        core["capacity_decision"]["rationale"].append(
            "The owner reports QR Dolar paused; the active workload is YouTube only. "
            "Renewal pacing is a cooperative ceiling, not uninterrupted Codex capacity or a per-task forecast.")
    decision_id = "codex-usage-" + hashlib.sha256(_canonical(core)).hexdigest()[:16]
    return {"schema_version": core.pop("schema_version"), "decision_id": decision_id, **core}


def validate_decision(value: dict[str, Any], root: Path = ROOT) -> None:
    schema = json.loads((root / "schemas/codex_usage_governance.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def materialize_observation(
    observation: dict[str, Any],
    root: Path = ROOT,
    *,
    observed_at: str | None = None,
) -> Path:
    root = root.resolve()
    policy = json.loads((root / POLICY_PATH).read_text(encoding="utf-8"))
    timestamp = observed_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    value = evaluate_usage(observation, policy, observed_at=timestamp)
    validate_decision(value, root)
    latest = root / OUTPUT_PATH
    immutable = latest.parent / "history" / f"{value['decision_id']}.json"
    payload = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    immutable.parent.mkdir(parents=True, exist_ok=True)
    # Preserve the original native-newline serialization and all historical bytes.
    encoded = payload.replace("\n", os.linesep).encode("utf-8")
    descriptor, name = tempfile.mkstemp(prefix=".codex-history-", suffix=".tmp", dir=immutable.parent)
    staged = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(staged, immutable)
        except FileExistsError:
            if immutable.read_text(encoding="utf-8") != payload:
                raise PermissionError(f"immutable Codex usage decision collision: {value['decision_id']}")
        persisted = immutable.read_bytes()
        if persisted.decode("utf-8").replace("\r\n", "\n") != payload:
            raise PermissionError("immutable Codex usage payload differs")
        atomic_write_utf8(latest, persisted.decode("utf-8"))
    finally:
        staged.unlink(missing_ok=True)
    return latest
