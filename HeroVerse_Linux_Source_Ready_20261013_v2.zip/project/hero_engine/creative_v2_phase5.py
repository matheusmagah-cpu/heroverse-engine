from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .continuity import build_visual_continuity_bible
from .creative_direction import choose_format_pack, load_format_packs
from .policy_phase5 import evaluate_phase5_command
from .take_planner import build_take_plan
from .voice_phase5 import SAMPLE_RATE, build_local_voice, synthesize_voice_sample


HOOK_ASSET_ID = "asset-owned-hook-threshold-v2"
LEGACY_HOOK_ASSET_ID = "asset-owned-hook-threshold-v1"
APOLOGY_ASSET_ID = "asset-owned-apology-action-v2"
LEGACY_APOLOGY_ASSET_ID = "asset-owned-apology-action-v1"
RELATIONSHIP_ASSET_ID = "asset-commons-7ba0735b1c524bb107"
WORK_ASSET_ID = "asset-commons-4ada8d76c56bb371fa"
SKILL_ASSET_ID = "asset-owned-skill-question-v1"
TRANSITION_ASSET_ID = "asset-commons-05a1b64e18942c9ded"
PERSPECTIVE_ASSET_ID = "asset-commons-0b1562d453081dca4e"
DECISION_ASSET_ID = "asset-commons-1fc701df609135a29a"
CLARITY_ASSET_ID = "asset-commons-6b4969a187fd6d04f8"
RELEASE_ASSET_ID = "asset-commons-7a427e1f1a265f0631"
RENEWAL_ASSET_ID = "asset-commons-8be5e90cf7c370281e"
TENSION_ASSET_ID = "asset-commons-a594ac0612d8445549"
CONTEMPLATION_ASSET_ID = "asset-commons-c5c632fb2cbabc24c3"
PROGRESS_ASSET_ID = "asset-commons-e070495e3e6b2b6e88"
PRESSURE_ASSET_ID = "asset-commons-fa53a5884174e4e27c"
PACKAGE_DIR = Path("output/production/phase5/pilot-001")
V2_DIR = PACKAGE_DIR / "creative-v2"


SCRIPT_SECTIONS_V2 = [
    {
        "section_id": "S1",
        "role": "TITLE_ALIGNED_STAKE",
        "narrative_function": "deliver the first payoff",
        "text": (
            "Prayer is not a way to avoid responsibility. It is where panic can become clarity and impulse can face truth. "
            "Sometimes nothing around you changes in that moment. But one thing becomes harder to ignore: the next right action already within reach."
        ),
        "intended_emotion": "clarity",
        "semantic_role": "clarity",
        "retention_job": "pay off the title with a concrete internal change before 30 seconds",
        "source_refs": ["James 1:5", "brief:combined_promise"],
        "on_screen_text": "PRAYER REVEALS RESPONSIBILITY",
    },
    {
        "section_id": "S2",
        "role": "PERSONAL_STAKES",
        "narrative_function": "expose disguised avoidance",
        "text": (
            "Many people keep waiting for a feeling that removes every risk. They call the delay patience, even when the next responsible move is obvious: "
            "apologize, make the call, begin the work, or ask for help. Fear loves spiritual language when it wants another day."
        ),
        "intended_emotion": "recognition",
        "semantic_role": "contemplation",
        "retention_job": "make the viewer identify one delayed action",
        "source_refs": ["channel-model:B2", "brief:angle"],
        "on_screen_text": "WAITING — OR HIDING?",
    },
    {
        "section_id": "S3",
        "role": "MECHANISM_AND_PROOF",
        "narrative_function": "connect wisdom to accountable action",
        "text": (
            "James tells people under pressure to ask God for wisdom. Then he warns them not to hear truth without doing it. "
            "That sequence matters. Wisdom is not a private prediction machine. It is truth becoming a faithful response inside a real trial."
        ),
        "intended_emotion": "understanding",
        "semantic_role": "perspective",
        "retention_job": "close the scriptural reasoning loop without a sermon detour",
        "source_refs": ["James 1:2-8", "James 1:22-25"],
        "on_screen_text": "ASK. HEAR. DO.",
    },
    {
        "section_id": "S4",
        "role": "REVERSAL_AND_ACTION",
        "narrative_function": "teach the three-question test",
        "text": (
            "Before you move, test the step with three questions. First: is it true? If it depends on deception, revenge, ego, or a promise God never made, stop. "
            "Second: what responsibility does it accept? Honest action carries a cost you can name. "
            "Third: can you do it today? Reduce the future to one accountable action."
        ),
        "intended_emotion": "agency",
        "semantic_role": "decision",
        "retention_job": "give the viewer a memorable decision tool",
        "source_refs": ["James 1:22-25", "channel-model:B4"],
        "on_screen_text": "THE 3-QUESTION TEST",
    },
    {
        "section_id": "S5",
        "role": "REVERSAL_AND_ACTION",
        "narrative_function": "prove the tool with concrete examples",
        "text": (
            "A damaged relationship may not need forced reconciliation. It may need an apology with no demand attached. "
            "A work decision may not require quitting tonight. It may require one application, one skill, or one precise question. "
            "Fear may not disappear. It may need to be named to someone trustworthy."
        ),
        "intended_emotion": "practical hope",
        "semantic_role": "progress",
        "retention_job": "replace abstraction with actions the viewer can visualize",
        "source_refs": ["channel-model:concrete_response", "brief:payoff"],
        "on_screen_text": "MAKE IT CONCRETE",
    },
    {
        "section_id": "S6",
        "role": "MECHANISM_AND_PROOF",
        "narrative_function": "reframe confidence",
        "text": (
            "Notice the pattern. None of these steps controls another person. None guarantees the outcome. Each puts your character inside the prayer. "
            "Confidence grows not because the whole road becomes predictable, but because the ground beneath your feet becomes honest."
        ),
        "intended_emotion": "earned courage",
        "semantic_role": "progress",
        "retention_job": "deliver the identity reversal before the close",
        "source_refs": ["channel-model:identity_reframe", "brief:payoff"],
        "on_screen_text": "HONEST BEFORE CERTAIN",
    },
    {
        "section_id": "S7",
        "role": "PROMISE_RESOLUTION",
        "narrative_function": "resolve the title and framework",
        "text": (
            "So do not measure prayer only by what changed around you. Measure what became clear enough to obey: one truth, one responsibility, one action today. "
            "Name it. Test it. Take it. Amen is not the finish line. It is where a faithful response begins."
        ),
        "intended_emotion": "quiet resolve",
        "semantic_role": "renewal",
        "retention_job": "close every visual and narrative loop with one action",
        "source_refs": ["brief:combined_promise", "channel-model:B5"],
        "on_screen_text": "TRUTH. RESPONSIBILITY. TODAY.",
    },
]


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(_read_json(root / "schemas" / schema_name)).validate(value)


def _words(text: str) -> int:
    return len(re.findall(r"\b[\w'’–-]+\b", text))


def _split(text: str, maximum_words: int = 14) -> list[str]:
    clauses = [part.strip() for part in re.split(r"(?<=[.!?;:])\s+|(?<=,)\s+", text) if part.strip()]
    chunks: list[str] = []
    pending: list[str] = []
    for clause in clauses:
        words = clause.split()
        while len(words) > maximum_words:
            if pending:
                chunks.append(" ".join(pending))
                pending = []
            chunks.append(" ".join(words[:maximum_words]))
            words = words[maximum_words:]
        if pending and len(pending) + len(words) > maximum_words:
            chunks.append(" ".join(pending))
            pending = []
        pending.extend(words)
    if pending:
        chunks.append(" ".join(pending))
    return chunks


def _estimated_slot(text: str) -> int:
    raw = (_words(text) / 2.55) * 1000 + 300
    return int(max(1_500, min(7_000, math.ceil(raw / 100) * 100)))


def register_original_hook_asset(root: Path, *, created_at: str) -> dict[str, Any]:
    package_dir = root / PACKAGE_DIR
    manifest_path = package_dir / "asset_manifest.json"
    manifest = _read_json(manifest_path)
    v2_dir = root / V2_DIR
    image_path = v2_dir / "assets" / "hero-threshold-original-v1.png"
    motion_path = v2_dir / "assets" / f"{HOOK_ASSET_ID}.mp4"
    if not image_path.is_file() or not motion_path.is_file():
        raise FileNotFoundError("creative-v2 original hook image or motion derivative is missing")
    evidence_path = package_dir / "rights_evidence" / f"{HOOK_ASSET_ID}.json"
    evidence = {
        "schema_version": "1.0.0",
        "asset_id": HOOK_ASSET_ID,
        "asset_type": "AI_GENERATED_ORIGINAL_WITH_LOCAL_MOTION_DERIVATIVE",
        "source_image": str(image_path.resolve()),
        "source_image_hash": _sha256(image_path),
        "motion_derivative": str(motion_path.resolve()),
        "motion_hash": _sha256(motion_path),
        "provider": "OpenAI built-in image generation through Codex",
        "prompt_scope": "original anonymous adult crossing a chapel threshold; no input reference image, logo, celebrity, trademark or copied artist identity",
        "ownership_basis": "OpenAI Terms of Use: as between user and OpenAI, user owns Output to the extent permitted by law; user remains responsible for use.",
        "ownership_source": "https://openai.com/policies/terms-of-use/",
        "platform_disclosure": {
            "required": True,
            "reason": "photorealistic generated scene that did not occur",
            "youtube_source": "https://support.google.com/youtube/answer/14328491",
            "upload_value": True,
        },
        "decision": "RESPONSIBLE_REVIEW_APPROVED",
        "limitations": [
            "Operational rights record, not a legal opinion.",
            "Output may not be unique; similarity and third-party rights remain the publisher's responsibility.",
            "Synthetic-content disclosure must be enabled at upload.",
        ],
        "verified_at": created_at,
    }
    _write_json(evidence_path, evidence)
    record = {
        "asset_id": HOOK_ASSET_ID,
        "semantic_role": "hook_threshold",
        "media_type": "HYBRID",
        "tool_adapter_id": "adapter-ffmpeg-local",
        "tool_version": "imagegen-builtin-observed-2026-09-02+ffmpeg-runtime",
        "uri": str(motion_path.resolve()),
        "content_hash": _sha256(motion_path),
        "source": "generated://openai-imagegen/hero-threshold-original-v1",
        "creator_or_holder": "HeroVerse project / OpenAI output assignment subject to applicable law",
        "rights_status": "OWNED",
        "license": "OpenAI Terms of Use output ownership; responsible-use conditions apply",
        "license_version": "accessed 2026-09-02",
        "commercial_use": True,
        "production_eligible": True,
        "attribution": None,
        "restrictions": ["YouTube synthetic-content disclosure required"],
        "rights_evidence_uri": str(evidence_path.resolve()),
        "verified_at": created_at,
        "rights_decision": "RESPONSIBLE_REVIEW_APPROVED",
        "duration_seconds": 12.0,
        "width": 1920,
        "height": 1080,
        "used_ranges": [],
        "content_quality_gate": "PASS",
        "safe_ranges": [{"start_ms": 0, "end_ms": 12000}],
        "content_quality_evidence": "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md",
    }
    apology_image = v2_dir / "assets" / "apology-original-v1.png"
    apology_motion = v2_dir / "assets" / f"{APOLOGY_ASSET_ID}.mp4"
    if not apology_image.is_file() or not apology_motion.is_file():
        raise FileNotFoundError("creative-v2 original apology image or motion derivative is missing")
    apology_evidence_path = package_dir / "rights_evidence" / f"{APOLOGY_ASSET_ID}.json"
    apology_evidence = {
        "schema_version": "1.0.0",
        "asset_id": APOLOGY_ASSET_ID,
        "asset_type": "AI_GENERATED_ORIGINAL_WITH_LOCAL_MOTION_DERIVATIVE",
        "source_image": str(apology_image.resolve()),
        "source_image_hash": _sha256(apology_image),
        "motion_derivative": str(apology_motion.resolve()),
        "motion_hash": _sha256(apology_motion),
        "provider": "OpenAI built-in image generation through Codex",
        "prompt_scope": "original anonymous hands writing I'M SORRY.; no input reference image, face, logo, celebrity or copied artist identity",
        "ownership_basis": "OpenAI Terms of Use output ownership, subject to applicable law and responsible use.",
        "ownership_source": "https://openai.com/policies/terms-of-use/",
        "platform_disclosure": {"required": True, "reason": "photorealistic generated scene that did not occur", "youtube_source": "https://support.google.com/youtube/answer/14328491", "upload_value": True},
        "decision": "RESPONSIBLE_REVIEW_APPROVED",
        "limitations": ["Operational rights record, not a legal opinion.", "Synthetic-content disclosure must be enabled at upload."],
        "verified_at": created_at,
    }
    _write_json(apology_evidence_path, apology_evidence)
    apology_record = {
        "asset_id": APOLOGY_ASSET_ID,
        "semantic_role": "relationship_repair",
        "media_type": "HYBRID",
        "tool_adapter_id": "adapter-ffmpeg-local",
        "tool_version": "imagegen-builtin-observed-2026-09-02+ffmpeg-runtime",
        "uri": str(apology_motion.resolve()),
        "content_hash": _sha256(apology_motion),
        "source": "generated://openai-imagegen/apology-original-v1",
        "creator_or_holder": "HeroVerse project / OpenAI output assignment subject to applicable law",
        "rights_status": "OWNED",
        "license": "OpenAI Terms of Use output ownership; responsible-use conditions apply",
        "license_version": "accessed 2026-09-02",
        "commercial_use": True,
        "production_eligible": True,
        "attribution": None,
        "restrictions": ["YouTube synthetic-content disclosure required"],
        "rights_evidence_uri": str(apology_evidence_path.resolve()),
        "verified_at": created_at,
        "rights_decision": "RESPONSIBLE_REVIEW_APPROVED",
        "duration_seconds": 20.0,
        "width": 1920,
        "height": 1080,
        "used_ranges": [],
        "content_quality_gate": "PASS",
        "safe_ranges": [{"start_ms": 0, "end_ms": 20000}],
        "content_quality_evidence": "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md",
    }
    skill_image = v2_dir / "assets" / "skill-question-original-v1.png"
    skill_motion = v2_dir / "assets" / f"{SKILL_ASSET_ID}.mp4"
    if not skill_image.is_file() or not skill_motion.is_file():
        raise FileNotFoundError("creative-v2 original skill/question image or motion derivative is missing")
    skill_evidence_path = package_dir / "rights_evidence" / f"{SKILL_ASSET_ID}.json"
    skill_evidence = {
        "schema_version": "1.0.0",
        "asset_id": SKILL_ASSET_ID,
        "asset_type": "AI_GENERATED_ORIGINAL_WITH_LOCAL_MOTION_DERIVATIVE",
        "source_image": str(skill_image.resolve()),
        "source_image_hash": _sha256(skill_image),
        "motion_derivative": str(skill_motion.resolve()),
        "motion_hash": _sha256(skill_motion),
        "provider": "OpenAI built-in image generation through Codex",
        "prompt_scope": "original anonymous hands learning at a non-branded laptop and writing one precise question; no reference input, face, logo, trademark, real interface, celebrity or copied artist identity",
        "ownership_basis": "OpenAI Terms of Use output ownership, subject to applicable law and responsible use.",
        "ownership_source": "https://openai.com/policies/terms-of-use/",
        "platform_disclosure": {"required": True, "reason": "photorealistic generated scene that did not occur", "youtube_source": "https://support.google.com/youtube/answer/14328491", "upload_value": True},
        "decision": "RESPONSIBLE_REVIEW_APPROVED",
        "limitations": ["Operational rights record, not a legal opinion.", "Synthetic-content disclosure must be enabled at upload."],
        "verified_at": created_at,
    }
    _write_json(skill_evidence_path, skill_evidence)
    skill_record = {
        "asset_id": SKILL_ASSET_ID,
        "semantic_role": "skill_question",
        "media_type": "HYBRID",
        "tool_adapter_id": "adapter-ffmpeg-local",
        "tool_version": "imagegen-builtin-observed-2026-09-02+ffmpeg-runtime",
        "uri": str(skill_motion.resolve()),
        "content_hash": _sha256(skill_motion),
        "source": "generated://openai-imagegen/skill-question-original-v1",
        "creator_or_holder": "HeroVerse project / OpenAI output assignment subject to applicable law",
        "rights_status": "OWNED",
        "license": "OpenAI Terms of Use output ownership; responsible-use conditions apply",
        "license_version": "accessed 2026-09-02",
        "commercial_use": True,
        "production_eligible": True,
        "attribution": None,
        "restrictions": ["YouTube synthetic-content disclosure required"],
        "rights_evidence_uri": str(skill_evidence_path.resolve()),
        "verified_at": created_at,
        "rights_decision": "RESPONSIBLE_REVIEW_APPROVED",
        "duration_seconds": 12.0,
        "width": 1920,
        "height": 1080,
        "used_ranges": [],
        "content_quality_gate": "PASS",
        "safe_ranges": [{"start_ms": 0, "end_ms": 12000}],
        "content_quality_evidence": "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md",
    }
    assets = [
        item for item in manifest["assets"]
        if item["asset_id"] not in {HOOK_ASSET_ID, LEGACY_HOOK_ASSET_ID, APOLOGY_ASSET_ID, LEGACY_APOLOGY_ASSET_ID, SKILL_ASSET_ID}
    ]
    for item in assets:
        item["used_ranges"] = []
        if item["asset_id"] == RELATIONSHIP_ASSET_ID:
            item["production_eligible"] = False
            item["content_quality_gate"] = "BLOCKED"
            item["content_quality_evidence"] = "creative-v2/qa/source-review/letter-contact.jpg"
            item.setdefault("restrictions", []).append("Visual review shows arbitrary lettering, not an apology or accountable action.")
    assets.extend([record, apology_record, skill_record])
    manifest["assets"] = assets
    manifest["selected_count"] = len(assets)
    manifest["minimum_required"] = max(int(manifest.get("minimum_required", 0)), 12)
    manifest["provider"] = "Wikimedia Commons API + original generated key/action art"
    limitation = "Photorealistic generated hook art requires the YouTube synthetic-content disclosure."
    if limitation not in manifest["limitations"]:
        manifest["limitations"].append(limitation)
    _write_json(manifest_path, manifest)
    return manifest


def build_brief_v2(brief: dict[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(brief)
    value["package"] = {
        "topic": "what to do immediately after prayer",
        "angle": "prayer clarifies responsibility; it does not replace the next tested action",
        "promise": "give the viewer a three-question test for one responsible next step",
        "title_concept": "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation",
        "title_variants": [
            "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation",
            "DON'T JUST WAIT AFTER YOU PRAY | Christian Motivation",
            "THE NEXT STEP AFTER PRAYER | Christian Motivation",
        ],
        "thumbnail_concept": "Anonymous figure crossing a dark chapel threshold into a narrow dawn path; deep navy and restrained gold; action is visible, not implied.",
        "thumbnail_text_variants": ["DON'T JUST WAIT", "NOW WHAT?", "TAKE THE STEP"],
        "combined_promise": "The viewer receives a test based on truth, responsibility and action today, without a guaranteed-outcome claim.",
        "delivery_test": "PASS",
    }
    hook_text = {
        "0_1S": ("Amen.", "The anonymous figure releases stillness at the threshold; AMEN appears as a decisive stamp."),
        "1_3S": ("Now what?", "The figure crosses the threshold while NOW WHAT? replaces the opening stamp."),
        "3_8S": ("The next honest step may be the answer you keep asking God to send.", "The path advances and the TRUTH / RESPONSIBILITY / TODAY framework is introduced."),
        "8_30S": ("Prayer can reveal responsibility before circumstances change.", "Five functional changes move from pressure to clarity, not a beauty montage."),
    }
    for window in value["hook_windows"]:
        window["original_text"], window["visual_proof"] = hook_text[window["window"]]
        window["gate_status"] = "PASS"
    value["payoff"] = "Name one action that is truthful, accepts responsibility and can be taken today."
    value["originality_controls"]["new_visual_identity"] = True
    return value


def build_script_v2(brief: dict[str, Any], *, created_at: str) -> dict[str, Any]:
    hook = ["Amen.", "Now what?", "The next honest step may be the answer you keep asking God to send."]
    full_text = " ".join([*hook, *[section["text"] for section in SCRIPT_SECTIONS_V2]])
    estimated = 8000 + sum(_estimated_slot(chunk) for section in SCRIPT_SECTIONS_V2 for chunk in _split(section["text"]))
    return {
        "schema_version": "1.0.0",
        "script_id": _stable_id("script-v2", brief["brief_id"], full_text),
        "version": "2.0.0",
        "channel_id": brief["channel_id"],
        "brief_id": brief["brief_id"],
        "language": "en-US",
        "title": brief["package"]["title_concept"],
        "original_thesis": "Prayer can clarify one truthful and responsible action without guaranteeing the outcome.",
        "source_basis": [
            {"source_ref": "James 1:2-8", "use": "wisdom under pressure", "handling": "original contextual paraphrase"},
            {"source_ref": "James 1:22-25", "use": "hearing becomes accountable action", "handling": "original contextual paraphrase"},
            {"source_ref": "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md", "use": "creative-v2 causal audiovisual grammar", "handling": "original production rule"},
        ],
        "hook_windows": [
            {"window": "0_1S", "start_ms": 0, "end_ms": 1000, "function": "auditory stop", "narration": hook[0], "visual_job": "stamp AMEN on the threshold image", "evidence_refs": ["creative-v2:hook-01", "channel-model:H1"]},
            {"window": "1_3S", "start_ms": 1000, "end_ms": 3000, "function": "open loop", "narration": hook[1], "visual_job": "cross the threshold and replace certainty with a question", "evidence_refs": ["creative-v2:hook-02", "channel-model:H2"]},
            {"window": "3_8S", "start_ms": 3000, "end_ms": 8000, "function": "mechanism preview", "narration": hook[2], "visual_job": "introduce the three-question framework while movement continues", "evidence_refs": ["creative-v2:hook-03", "channel-model:H3"]},
            {"window": "8_30S", "start_ms": 8000, "end_ms": 30000, "function": "first payoff", "narration": SCRIPT_SECTIONS_V2[0]["text"], "visual_job": "five functional changes from pressure to clarity", "evidence_refs": ["creative-v2:8-30", "channel-model:H4"]},
        ],
        "sections": SCRIPT_SECTIONS_V2,
        "full_text": full_text,
        "word_count": _words(full_text),
        "estimated_duration_ms": estimated,
        "originality_controls": {
            "written_from_blank": True,
            "reference_wording_used": False,
            "borrowed_audio_used": False,
            "borrowed_sequence_used": False,
            "editorial_purpose": "Teach an original truth-responsibility-today decision framework with causal visuals and licensed/original assets.",
        },
        "created_at": created_at,
    }


SECTION_ASSET_SEQUENCE = {
    "S1": [CLARITY_ASSET_ID, PRESSURE_ASSET_ID, PERSPECTIVE_ASSET_ID, DECISION_ASSET_ID],
    "S2": [CONTEMPLATION_ASSET_ID, APOLOGY_ASSET_ID, WORK_ASSET_ID, TENSION_ASSET_ID],
    "S3": [PERSPECTIVE_ASSET_ID, RELEASE_ASSET_ID, DECISION_ASSET_ID, PRESSURE_ASSET_ID],
    "S4": [DECISION_ASSET_ID, TENSION_ASSET_ID, PERSPECTIVE_ASSET_ID, PROGRESS_ASSET_ID],
    "S5": [PRESSURE_ASSET_ID, APOLOGY_ASSET_ID, WORK_ASSET_ID, SKILL_ASSET_ID, PROGRESS_ASSET_ID],
    "S6": [PRESSURE_ASSET_ID, CLARITY_ASSET_ID, DECISION_ASSET_ID, PROGRESS_ASSET_ID],
    "S7": [RENEWAL_ASSET_ID, PERSPECTIVE_ASSET_ID, RENEWAL_ASSET_ID, RELEASE_ASSET_ID],
}


def _asset_for_chunk(manifest: dict[str, Any], section_id: str, chunk_index: int, text: str) -> str | None:
    ids = {
        item["asset_id"] for item in manifest["assets"]
        if item.get("production_eligible") is True and item.get("content_quality_gate") != "BLOCKED"
    }
    lowered = text.lower()
    if any(term in lowered for term in ("apology", "apologize")) and APOLOGY_ASSET_ID in ids:
        return APOLOGY_ASSET_ID
    if any(term in lowered for term in ("skill", "precise question")) and SKILL_ASSET_ID in ids:
        return SKILL_ASSET_ID
    if any(term in lowered for term in ("work", "application")) and WORK_ASSET_ID in ids:
        return WORK_ASSET_ID
    sequence = SECTION_ASSET_SEQUENCE.get(section_id, [])
    if chunk_index < len(sequence) and sequence[chunk_index] in ids:
        return sequence[chunk_index]
    return TRANSITION_ASSET_ID if TRANSITION_ASSET_ID in ids else None


def _chunk_overlay(section: dict[str, Any], chunk_index: int, chunk: str) -> str | None:
    lowered = chunk.lower()
    if "first: is it true" in lowered:
        return "Q1  //  IS IT TRUE?"
    if any(term in lowered for term in ("deception", "revenge", "ego")):
        return "LIE  /  REVENGE  /  EGO  =  STOP"
    if "second:" in lowered:
        return "Q2  //  WHAT DO I OWN?"
    if "third:" in lowered:
        return "Q3  //  WHAT CAN I DO TODAY?"
    if "fear loves spiritual language" in lowered:
        return "FEAR WANTS ANOTHER DAY"
    if "private prediction machine" in lowered:
        return "WISDOM IS NOT A PREDICTION"
    if "none guarantees" in lowered:
        return "NO GUARANTEED OUTCOME"
    if "name it. test it. take it" in lowered:
        return "NAME IT.  TEST IT.  TAKE IT."
    return section["on_screen_text"] if chunk_index == 0 else None


def build_beats_v2(
    script: dict[str, Any],
    manifest: dict[str, Any],
    duration_overrides: dict[str, int] | None = None,
) -> list[dict[str, Any]]:
    overrides = duration_overrides or {}
    beats: list[dict[str, Any]] = [
        {"beat_id": "H01", "start_ms": 0, "end_ms": 1000, "narrative_function": "auditory stop", "information": "Amen is the transition point, not the resolution.", "intended_emotion": "attention", "semantic_role": "hook_threshold", "action": "AMEN stamps onto a moving threshold", "on_screen_text": "AMEN.", "narration": script["hook_windows"][0]["narration"], "retention_job": "stop the scroll without a greeting", "preferred_asset_id": HOOK_ASSET_ID, "allow_repeat_asset": True, "sound_effect": "impact"},
        {"beat_id": "H02", "start_ms": 1000, "end_ms": 3000, "narrative_function": "open loop", "information": "The viewer must decide what follows prayer.", "intended_emotion": "tension", "semantic_role": "hook_threshold", "action": "figure crosses the threshold as the question replaces the stamp", "on_screen_text": "NOW WHAT?", "narration": script["hook_windows"][1]["narration"], "retention_job": "make the promise personal", "preferred_asset_id": HOOK_ASSET_ID, "allow_repeat_asset": True, "sound_effect": "whoosh"},
        {"beat_id": "H03", "start_ms": 3000, "end_ms": 8000, "narrative_function": "mechanism preview", "information": "An honest step may reveal the response the viewer is seeking.", "intended_emotion": "resolve", "semantic_role": "hook_threshold", "action": "path advances while the three-part framework appears", "on_screen_text": "TRUTH  /  RESPONSIBILITY  /  TODAY", "narration": script["hook_windows"][2]["narration"], "retention_job": "deliver a usable mechanism before eight seconds", "preferred_asset_id": HOOK_ASSET_ID, "allow_repeat_asset": True, "sound_effect": "pulse"},
    ]
    cursor = 8000
    index = 4
    for section in script["sections"]:
        for chunk_index, chunk in enumerate(_split(section["text"])):
            take_id = f"take-{index:03d}"
            duration = int(overrides.get(take_id, _estimated_slot(chunk)))
            if duration < 900 or duration > 7000:
                raise ValueError(f"creative-v2 body duration outside 0.9–7.0 s for {take_id}: {duration}")
            preferred = _asset_for_chunk(manifest, section["section_id"], chunk_index, chunk)
            asset_by_id = {item["asset_id"]: item for item in manifest["assets"]}
            semantic_role = str(asset_by_id.get(preferred, {}).get("semantic_role", section["semantic_role"]))
            beats.append(
                {
                    "beat_id": f"B{index:03d}",
                    "start_ms": cursor,
                    "end_ms": cursor + duration,
                    "narrative_function": section["narrative_function"],
                    "information": chunk,
                    "intended_emotion": section["intended_emotion"],
                    "semantic_role": semantic_role,
                    "action": f"visual proves {semantic_role}; it may not function as decorative filler",
                    "on_screen_text": _chunk_overlay(section, chunk_index, chunk),
                    "narration": chunk,
                    "retention_job": section["retention_job"],
                    "preferred_asset_id": preferred,
                    "allow_repeat_asset": preferred in {APOLOGY_ASSET_ID, WORK_ASSET_ID, SKILL_ASSET_ID},
                    "sound_effect": "section impact" if chunk_index == 0 else None,
                }
            )
            cursor += duration
            index += 1
    return beats


def _build_treatment(plan: dict[str, Any], *, created_at: str) -> dict[str, Any]:
    treatments: list[dict[str, Any]] = []
    framework_state = "HIDDEN"
    for take in plan["takes"]:
        take_id = take["take_id"]
        text = (take.get("information") or "").lower()
        synthetic = any(asset_id in take["asset_origin"] for asset_id in (HOOK_ASSET_ID, APOLOGY_ASSET_ID, SKILL_ASSET_ID))
        if take_id == "take-001":
            treatment, layout, events, interrupt, framework_state, sfx = "HOOK_STAMP", "LEFT_HERO", 2, True, "HIDDEN", "IMPACT"
        elif take_id == "take-002":
            treatment, layout, events, interrupt, framework_state, sfx = "HOOK_QUESTION", "LEFT_HERO", 1, True, "HIDDEN", "WHOOSH"
        elif take_id == "take-003":
            treatment, layout, events, interrupt, framework_state, sfx = "HOOK_FRAMEWORK", "FRAMEWORK_BAR", 2, True, "INTRODUCED", "PULSE"
        elif "first: is it true" in text or "deception" in text:
            treatment, layout, events, interrupt, framework_state, sfx = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "TRUTH", "PULSE"
        elif "second:" in text:
            treatment, layout, events, interrupt, framework_state, sfx = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "RESPONSIBILITY", "PULSE"
        elif "third:" in text or "do it today" in text:
            treatment, layout, events, interrupt, framework_state, sfx = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "TODAY", "PULSE"
        elif take.get("on_screen_text") == "ASK. HEAR. DO.":
            treatment, layout, events, interrupt, sfx = "SCRIPTURE_SEQUENCE", "FRAMEWORK_BAR", 3, True, "PULSE"
        elif take.get("on_screen_text") in {
            "FEAR WANTS ANOTHER DAY",
            "WISDOM IS NOT A PREDICTION",
            "NO GUARANTEED OUTCOME",
            "NAME IT.  TEST IT.  TAKE IT.",
        }:
            treatment, layout, events, interrupt, sfx = "KEYWORD_PUNCH", "CENTER_PAYOFF", 2, True, "IMPACT"
        elif take.get("on_screen_text"):
            treatment = "PAYOFF_RESOLUTION" if "TRUTH." in str(take["on_screen_text"]) else "SECTION_CARD"
            layout = "CENTER_PAYOFF" if treatment == "PAYOFF_RESOLUTION" else "LOWER_LEFT"
            events, interrupt = 2, True
            if treatment == "PAYOFF_RESOLUTION":
                framework_state = "COMPLETE"
            sfx = "RESOLUTION" if treatment == "PAYOFF_RESOLUTION" else "IMPACT"
        elif any(term in text for term in ("apology", "application", "skill", "work")):
            treatment, layout, events, interrupt = "ACTION_EVIDENCE", "NONE", 1, False
            sfx = "PEN" if "apology" in text else "KEYS"
        else:
            treatment, layout, events, interrupt, sfx = "CINEMATIC_BODY", "NONE", 1, False, "NONE"
        treatments.append(
            {
                "take_id": take_id,
                "treatment": treatment,
                "text_layout": layout,
                "visual_event_count": events,
                "pattern_interrupt": interrupt,
                "framework_state": framework_state,
                "sfx": sfx,
                "synthetic_disclosure": synthetic,
                "evidence_refs": [f"take-plan:{take_id}", "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md"],
            }
        )
    coverage = {item["window"]: item["take_ids"] for item in plan["hook_window_coverage"]}
    return {
        "schema_version": "1.0.0",
        "treatment_plan_id": _stable_id("creative-treatment", plan["take_plan_id"], "2.1.0"),
        "version": "2.1.0",
        "video_id": plan["video_id"],
        "channel_id": plan["channel_id"],
        "format_pack_id": plan["format_pack_id"],
        "format_pack_version": plan["format_pack_version"],
        "grammar": {
            "motif": "THRESHOLD_TO_STEP",
            "accent_hex": "#D7A94A",
            "framework": ["TRUTH", "RESPONSIBILITY", "TODAY"],
            "text_rule": "keyword-led lower-left typography; no generic centered black box",
            "semantic_rule": "concrete narration requires concrete action or causal diagram",
            "rhythm_rule": "four events in 0–8 s; functional change <= 6 s; structured interrupt <= 25 s",
        },
        "hook_contract": [
            {"window": "0_1S", "visual_events_minimum": 2, "audio_events_minimum": 2, "proof": "AMEN stamp plus threshold motion and impact", "take_ids": coverage["0_1S"]},
            {"window": "1_3S", "visual_events_minimum": 1, "audio_events_minimum": 2, "proof": "question replacement plus crossing movement and whoosh", "take_ids": coverage["1_3S"]},
            {"window": "3_8S", "visual_events_minimum": 2, "audio_events_minimum": 2, "proof": "path movement plus framework reveal and pulse", "take_ids": coverage["3_8S"]},
            {"window": "8_30S", "visual_events_minimum": 5, "audio_events_minimum": 2, "proof": "at least five functional takes and first section impact", "take_ids": coverage["8_30S"]},
        ],
        "takes": treatments,
        "measurement_contract": {
            "minimum_hook_visual_events": 4,
            "minimum_8_30_visual_events": 5,
            "maximum_body_take_ms": 7000,
            "maximum_pattern_interrupt_gap_ms": 25000,
            "maximum_third_party_asset_runtime_share": 0.2,
            "concrete_claim_visual_coverage": 1.0,
        },
        "created_at": created_at,
    }


def _write_artifacts(root: Path, artifacts: dict[str, tuple[str, dict[str, Any]]]) -> None:
    package_dir = root / PACKAGE_DIR
    v2_dir = root / V2_DIR
    for filename, (schema, value) in artifacts.items():
        _validate(root, schema, value)
        _write_json(package_dir / filename, value)
        _write_json(v2_dir / filename, value)


def materialize_creative_v2(
    root: Path,
    *,
    created_at: str,
    duration_overrides: dict[str, int] | None = None,
) -> dict[str, Any]:
    package_dir = root / PACKAGE_DIR
    manifest = register_original_hook_asset(root, created_at=created_at)
    brief = build_brief_v2(_read_json(package_dir / "editorial_brief.json"))
    _validate(root, "editorial_brief.schema.json", brief)
    _write_json(package_dir / "editorial_brief.json", brief)
    _write_json(root / V2_DIR / "editorial_brief.json", brief)
    command = _read_json(package_dir / "central_command.creative_direction.json")
    envelope = _read_json(root / "config" / "operational_envelopes" / "phase5-zero-cost-v1.json")
    channel_model = _read_json(root / "output" / "modeling" / "phase4" / "channel-model-v1" / "channel_model.json")
    packs = load_format_packs(root / "config" / "format_packs", root / "schemas" / "format_pack.schema.json")
    pack = next(item for item in packs if item["format_pack_id"] == "fp-broll-cinematic-narration")
    policy = evaluate_phase5_command(command, envelope, created_at=created_at)
    decision = choose_format_pack(
        command=command,
        policy_decision=policy,
        channel_model=channel_model,
        brief=brief,
        packs=packs,
        purpose="PROTOTYPE",
        budget_envelope_id=envelope["envelope_id"],
        quality_profile="DRAFT",
        created_at=created_at,
    )
    bible = build_visual_continuity_bible(channel_model=channel_model, format_pack=pack, asset_manifest=manifest, created_at=created_at)
    bible["version"] = "2.0.0"
    bible["identity"]["principles"].extend([
        "threshold-to-step is the proprietary visual motif",
        "concrete narration must use concrete action evidence",
        "TRUTH / RESPONSIBILITY / TODAY is the recurring information system",
    ])
    bible["decision_history"].append(
        {
            "decision_id": "creative-v2-remediation",
            "change": "replace generic nature montage with threshold motif, causal action clips and progressive framework",
            "reason": "DRAFT v1 independent review identified generic imagery and insufficient semantic force",
            "evidence_refs": ["docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md", "baseline-v1/creative_quality_gate_report.json"],
            "created_at": created_at,
        }
    )
    script = build_script_v2(brief, created_at=created_at)
    beats = build_beats_v2(script, manifest, duration_overrides)
    windows = [
        {"window": item["window"], "start_ms": item["start_ms"], "end_ms": item["end_ms"], "promise_function": item["function"], "evidence_refs": item["evidence_refs"]}
        for item in script["hook_windows"]
    ]
    plan, allocated = build_take_plan(
        channel_id="heroverse74",
        video_id="phase5-pilot-001-creative-v2",
        creative_decision=decision,
        style_bible=bible,
        format_pack=pack,
        asset_manifest=manifest,
        narrative_beats=beats,
        hook_windows=windows,
        created_at=created_at,
    )
    treatment = _build_treatment(plan, created_at=created_at)
    artifacts = {
        "policy_decision.json": ("phase5_policy_decision.schema.json", policy),
        "creative_direction_decision.json": ("creative_direction_decision.schema.json", decision),
        "channel_style_bible.json": ("visual_continuity_bible.schema.json", bible),
        "narrative_script.json": ("narrative_script.schema.json", script),
        "take_plan.json": ("take_plan.schema.json", plan),
    }
    _write_artifacts(root, artifacts)
    _write_json(package_dir / "asset_manifest.allocated.json", allocated)
    _write_json(root / V2_DIR / "asset_manifest.allocated.json", allocated)
    _validate(root, "creative_treatment_plan.schema.json", treatment)
    _write_json(root / V2_DIR / "creative_treatment_plan.json", treatment)
    return {"script": script, "plan": plan, "treatment": treatment, "manifest": manifest}


def synthesize_creative_v2(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    preliminary = materialize_creative_v2(root, created_at=timestamp)
    plan = preliminary["plan"]
    script = preliminary["script"]
    engine = build_local_voice(root)
    audio_dir = root / V2_DIR / "audio" / "takes"
    speeds = {"take-001": 1.20, "take-002": 1.16, "take-003": 1.20}
    records: list[dict[str, Any]] = []
    overrides: dict[str, int] = {}
    for take in plan["takes"]:
        take_id = take["take_id"]
        text = str(take["narration"])
        speed = speeds.get(take_id, 1.01)
        rendered = synthesize_voice_sample(engine, text=text, output_path=audio_dir / f"{take_id}.wav", voice_id="am_onyx", speed=speed)
        if take_id in speeds:
            slot = int(take["end_ms"]) - int(take["start_ms"])
        else:
            slot = int(math.ceil(max(1500, rendered["duration_ms"] + 220) / 100) * 100)
            if slot > 7000:
                raise RuntimeError(f"voice requires a body take above the 7 s creative-v2 ceiling: {take_id}={slot}")
            overrides[take_id] = slot
        records.append(
            {
                "take_id": take_id,
                "text": text,
                "speed": speed,
                "duration_ms": rendered["duration_ms"],
                "timeline_slot_ms": slot,
                "fits_timeline_slot": rendered["duration_ms"] <= slot,
                "peak_linear": rendered["peak_linear"],
                "clipping": rendered["clipping"],
                "render_seconds": rendered["render_seconds"],
                "path": rendered["path"],
                "content_hash": rendered["content_hash"],
            }
        )
    if any(not item["fits_timeline_slot"] for item in records[:3]):
        raise RuntimeError("creative-v2 hook narration does not fit 0–1/1–3/3–8 windows")
    if any(item["clipping"] for item in records):
        raise RuntimeError("creative-v2 raw voice render clipped")
    final = materialize_creative_v2(root, created_at=timestamp, duration_overrides=overrides)
    final_plan = final["plan"]
    if [item["take_id"] for item in final_plan["takes"]] != [item["take_id"] for item in records]:
        raise RuntimeError("take IDs changed after measured voice rematerialization")
    timeline_duration = int(final_plan["takes"][-1]["end_ms"])
    manifest = {
        "schema_version": "1.0.0",
        "voice_render_id": _stable_id("voice-v2", script["script_id"], "am_onyx", timestamp),
        "status": "COMPLETE",
        "video_id": final_plan["video_id"],
        "script_id": script["script_id"],
        "script_version": script["version"],
        "adapter_id": "adapter-local-voice",
        "adapter_implementation": "KokoroFloatSpeed",
        "model": "models/kokoro/kokoro-v1.0.fp16.onnx",
        "model_hash": _sha256(root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx"),
        "voices_hash": _sha256(root / "models" / "kokoro" / "voices-v1.0.bin"),
        "voice_id": "am_onyx",
        "sample_rate": SAMPLE_RATE,
        "take_count": len(records),
        "takes": records,
        "hook_timing_gate": "PASS",
        "total_audio_duration_ms": sum(item["duration_ms"] for item in records),
        "total_render_seconds": round(sum(item["render_seconds"] for item in records), 6),
        "timeline_duration_ms": timeline_duration,
        "publication_approved": False,
        "limitations": [
            "Voice changed from am_michael to am_onyx for the challenger; perceived quality still requires independent human review.",
            "The measured timeline is publication-blocked until final mix, QA and human approval pass.",
        ],
        "created_at": timestamp,
    }
    _validate(root, "voice_render_manifest.schema.json", manifest)
    _write_json(root / V2_DIR / "audio" / "voice_render_manifest.json", manifest)
    _write_json(root / PACKAGE_DIR / "audio" / "voice_render_manifest.json", manifest)
    return {"voice": manifest, **final}
