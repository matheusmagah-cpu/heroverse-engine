from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]
BASE = Path("output/integrations/youtube/heroverse")
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _optional(root: Path, name: str, schema_name: str) -> dict[str, Any] | None:
    path = root / BASE / name
    if not path.is_file():
        return None
    value = _read(path)
    _validate(root, schema_name, value)
    return value


def _hash(path: Path) -> str | None:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def build_operational_readiness(
    root: Path = ROOT,
    *,
    token_file: Path | None = None,
    observed_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    connection = _optional(root, "connection-receipt.json", "youtube_connection_receipt.schema.json")
    platform = _optional(root, "google-auth-platform-observation.json", "google_auth_platform_observation.schema.json")
    mirror = _optional(root, "oauth-token-mirror-receipt.json", "oauth_token_mirror_receipt.schema.json")
    refresh = _optional(root, "oauth-noninteractive-refresh-receipt.json", "oauth_noninteractive_refresh_receipt.schema.json")

    blockers: list[str] = []
    actions: list[str] = []

    connection_ok = bool(
        connection
        and connection.get("status") == "CONNECTED"
        and connection.get("identity_verified") is True
        and (connection.get("observed_channel") or {}).get("channel_id") == CHANNEL_ID
    )
    connection_scopes = set((connection or {}).get("authorization", {}).get("granted_scopes") or [])
    if not connection_ok:
        blockers.append("OAUTH_CONNECTION_NOT_PROVEN: no current receipt proves the authorized account controls the exact HeroVerse channel.")
        actions.append("Complete the installed-app OAuth flow with the pinned HeroVerse account and let the identity probe finish.")
    if not set(INTEGRATION_SCOPES).issubset(connection_scopes):
        blockers.append("OAUTH_TOKEN_SCOPE_MISMATCH: the connected token does not grant all four least-use runtime scopes.")
        actions.append("Reauthorize once with the four declared runtime scopes, including youtube.force-ssl.")

    platform_ready = False
    platform_status = "UNKNOWN"
    platform_time: datetime | None = None
    if platform is None:
        blockers.append("GOOGLE_AUTH_PLATFORM_UNOBSERVED: no authenticated production-configuration observation exists.")
        actions.append("Observe the Google Auth Platform configuration with the project-owner account after saving it.")
    else:
        platform_status = platform["audience"]["publishing_status"]
        platform_time = _parse(platform["observed_at"])
        declared = platform["declared_scopes"]
        declared_scopes = set(declared["runtime_requested_scopes"])
        declared_count = sum(int(declared[key]) for key in ("non_sensitive_count", "sensitive_count", "restricted_count"))
        if platform_status != "IN_PRODUCTION" or not platform["audience"]["configuration_complete"]:
            blockers.append("OAUTH_APP_NOT_IN_PRODUCTION: the app is not proven configured and In production; Testing tokens are time-limited.")
            actions.append("Using the authorized project account, complete configuration and change the OAuth app to In production.")
        if not declared["configuration_matches_runtime"] or not set(INTEGRATION_SCOPES).issubset(declared_scopes):
            zero_note = " declares zero scopes" if declared_count == 0 else " does not declare all runtime scopes"
            blockers.append("OAUTH_SCOPE_CONFIGURATION_MISMATCH: Google Auth Platform" + zero_note + "; console and runtime are not aligned.")
            actions.append("Declare the exact four runtime scopes in Data Access and save the configuration.")
        verification = platform["verification"]
        verification_ready = verification.get("status") == "COMPLETED" or (
            verification.get("status") == "NOT_REQUIRED_EXEMPT"
            and verification.get("currently_required") is False
            and verification.get("exemption") in {"PERSONAL_USE", "INTERNAL_USE", "DEVELOPMENT_TESTING"}
        )
        if not verification_ready:
            blockers.append("OAUTH_VERIFICATION_BASIS_UNPROVEN: neither completed verification nor an explicit applicable exemption is recorded.")
            actions.append("Record the console-confirmed verification status or applicable exemption without inferring it from Testing status.")
        platform_ready = (
            platform_status == "IN_PRODUCTION"
            and platform["audience"]["configuration_complete"] is True
            and declared["configuration_matches_runtime"] is True
            and set(INTEGRATION_SCOPES).issubset(declared_scopes)
            and verification_ready
        )

    mirror_ok = bool(
        mirror
        and mirror["status"] == "MIRRORED"
        and mirror["source_sha256"] == mirror["destination_sha256"]
        and mirror["refresh_token_present"] is True
        and set(INTEGRATION_SCOPES).issubset(set(mirror["granted_scopes"]))
    )
    if not mirror_ok:
        blockers.append("OAUTH_RUNTIME_TOKEN_NOT_MIRRORED: no atomic, hash-verified four-scope token mirror receipt exists for the scheduled manager.")
        actions.append("Finish consent; the active watcher will atomically mirror the new token to the manager secret path.")

    refresh_ok = bool(
        refresh
        and refresh["status"] == "PASS"
        and refresh["refresh_success"] is True
        and refresh["noninteractive"] is True
        and refresh["identity_verified_after_refresh"] is True
        and refresh["observed_channel_id"] == CHANNEL_ID
        and refresh["token_persisted"] is True
        and set(INTEGRATION_SCOPES).issubset(set(refresh["granted_scopes"]))
    )
    if not refresh_ok:
        blockers.append("OAUTH_NONINTERACTIVE_REFRESH_UNPROVEN: no passing post-consent refresh and exact-channel identity receipt exists.")
        actions.append("Execute the zero-cost noninteractive refresh proof after mirroring the production token.")

    chronological = True
    mirror_time: datetime | None = _parse(mirror["mirrored_at"]) if mirror else None
    if mirror_time and platform_time and mirror_time < platform_time:
        chronological = False
        blockers.append("OAUTH_TOKEN_PREDATES_PLATFORM_CONFIGURATION: reauthorization did not occur after the observed production configuration.")
        actions.append("Reauthorize after the final production and scope configuration is saved.")
    refresh_reproves_mirrored_identity = bool(
        refresh_ok
        and mirror_time
        and _parse(refresh["tested_at"]) >= mirror_time
    )
    if (
        connection
        and mirror_time
        and _parse(connection["created_at"]) < mirror_time
        and not refresh_reproves_mirrored_identity
    ):
        chronological = False
        blockers.append("OAUTH_IDENTITY_PROBE_PREDATES_TOKEN_MIRROR: channel identity was not reproved with the mirrored token.")
        actions.append("Run the owned-channel identity probe with the new token.")
    if refresh and mirror_time and _parse(refresh["tested_at"]) < mirror_time:
        chronological = False
        blockers.append("OAUTH_REFRESH_PREDATES_TOKEN_MIRROR: the refresh proof is stale.")
        actions.append("Repeat the refresh proof with the current mirrored token.")

    token_hash = None
    token_path_safe = False
    if token_file is not None:
        token_file = token_file.resolve()
        try:
            token_file.relative_to(root)
        except ValueError:
            token_path_safe = True
        token_hash = _hash(token_file) if token_path_safe else None
    token_current = bool(refresh_ok and token_hash and token_hash == refresh["token_sha256"])
    if not token_current:
        blockers.append("OAUTH_RUNTIME_TOKEN_HASH_UNVERIFIED: the scheduled manager token is absent, inside the workspace, or differs from the refresh receipt.")
        actions.append("Expose the external runtime token path to the manager and regenerate the refresh receipt if its hash changed.")

    ready = bool(connection_ok and set(INTEGRATION_SCOPES).issubset(connection_scopes) and platform_ready and mirror_ok and refresh_ok and token_current and chronological)
    if ready:
        blockers = []
        actions = []
    result = {
        "schema_version": "1.0.0",
        "integration_id": "youtube-heroverse-v1",
        "channel_id": CHANNEL_ID,
        "connection_status": connection.get("status", "AUTHORIZATION_REQUIRED") if connection else "AUTHORIZATION_REQUIRED",
        "identity_verified": connection_ok,
        "token_valid_now": token_current,
        "refresh_token_present": bool(mirror and mirror.get("refresh_token_present")),
        "oauth_publishing_status": platform_status,
        "continuous_operation_ready": ready,
        "durability_status": "DURABLE_POLICY_CONFIGURED" if ready else ("TIME_LIMITED_TESTING" if platform_status == "TESTING" else "BLOCKED_CONFIGURATION"),
        "blockers": list(dict.fromkeys(blockers)),
        "required_actions": list(dict.fromkeys(actions)),
        "publication_guard": {
            "upload_permitted": ready,
            "publish_mode": "active-private-first" if ready else "dry-run",
        },
        "evidence_refs": [
            (BASE / "connection-receipt.json").as_posix(),
            (BASE / "google-auth-platform-observation.json").as_posix(),
            (BASE / "oauth-token-mirror-receipt.json").as_posix(),
            (BASE / "oauth-noninteractive-refresh-receipt.json").as_posix(),
        ],
        "observed_at": observed_at or _now(),
    }
    _validate(root, "youtube_operational_readiness.schema.json", result)
    return result


def materialize(root: Path = ROOT, *, token_file: Path | None = None) -> Path:
    root = root.resolve()
    result = build_operational_readiness(root, token_file=token_file)
    path = root / BASE / "operational-readiness.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)
    return path
