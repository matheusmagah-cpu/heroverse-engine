from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
V3 = Path("output/production/phase5/pilot-001/creative-v3")
REPORT = V3 / "autonomous-review/autonomous_quality_evaluation.json"
TRANSITION = V3 / "autonomous-review/format_pack_transition_receipt.json"
PACK = Path("config/format_packs/fp-broll-cinematic-narration-v1.json")
REGISTRY = Path("config/visual_style_registry.json")


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _artifact(root: Path, path: Path) -> dict[str, str]:
    return {"path": _relative(root, path), "sha256": _hash(path)}


def _validate(root: Path, schema_name: str, value: Any) -> None:
    Draft202012Validator(_read(root / "schemas" / schema_name)).validate(value)


def _words(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", text.casefold().replace("twenty-four", "24"))


def _edit_distance(reference: list[str], hypothesis: list[str]) -> int:
    previous = list(range(len(hypothesis) + 1))
    for row, expected in enumerate(reference, start=1):
        current = [row]
        for column, observed in enumerate(hypothesis, start=1):
            current.append(min(
                current[-1] + 1,
                previous[column] + 1,
                previous[column - 1] + (expected != observed),
            ))
        previous = current
    return previous[-1]


def _decoded_static_frames(media: Path, *, expected_frames: int):
    """Bound active local decode, excluding time suspended in the consumer.

    The complete QA retains its separate outer deadline. Every read, RGB
    conversion and the final extra-frame probe consume the active budget.
    Keep the historical 120s floor for short clips; long-form decode has one
    measured media-time budget (30 FPS), not the same short-clip ceiling.
    A single stalled read/conversion still cannot consume more than 120s.
    """
    import cv2
    import time
    import math
    capture = cv2.VideoCapture(str(media))
    started = time.monotonic()
    try:
        observed_fps = capture.get(cv2.CAP_PROP_FPS)
        if not capture.isOpened() or not math.isfinite(observed_fps) or abs(observed_fps - 30) > 0.01:
            raise PermissionError('static decoded observation requires measured 30 FPS')
        decode_budget = max(120.0, expected_frames / observed_fps)
        decode_seconds = time.monotonic() - started
        for index in range(expected_frames):
            if decode_seconds > decode_budget:
                raise TimeoutError('bounded static decode exceeded media-time budget')
            started = time.monotonic()
            ok, frame = capture.read()
            if not ok:
                raise PermissionError('static decoded population incomplete')
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            read_seconds = time.monotonic() - started
            decode_seconds += read_seconds
            if read_seconds > 120 or decode_seconds > decode_budget:
                raise TimeoutError('bounded static decode exceeded active read/media-time budget')
            yield frame
        started = time.monotonic()
        extra_frame = capture.read()[0]
        read_seconds = time.monotonic() - started
        decode_seconds += read_seconds
        if read_seconds > 120 or decode_seconds > decode_budget:
            raise TimeoutError('bounded static decode exceeded active read/media-time budget')
        if extra_frame:
            raise PermissionError('static decoded population exceeds plan')
    finally:
        capture.release()


def measure_audio_static_visual(root: Path, package: Path, media: Path, *,
                                expected_media_hash: str) -> dict[str, Any]:
    """Observe every frame against authenticated own still, not semantic PASS.

    The historical YUV SSIM floor cannot approve this RGB instrument. Text-local
    structure and colour have independent observations; codec-domain controls
    must justify their acceptance limits before final legibility/style approval.
    """
    import numpy as np
    from PIL import Image
    from .procedural_infographics_phase5 import read_audio_static_source
    from .phase6_visual_metrics import spatial_measurements, colour_measurements
    from .render_phase5 import _frame_count_for_duration_ms
    root, package, media = root.resolve(), package.resolve(), media.resolve()
    if (not package.is_relative_to(root / 'output/production')
            or not media.is_relative_to(package)
            or 'sha256:' + _hash(media) != expected_media_hash):
        raise PermissionError('static visual package/media binding diverged')
    plan_path, asset_path = package / 'take_plan.json', package / 'asset_manifest.json'
    plan, assets = _read(plan_path), _read(asset_path)['assets']
    if plan.get('format_pack_id') != 'fp-narrated-reflection-static' or len(assets) != 1:
        raise PermissionError('visual observation requires exactly one static source')
    evidence = _read(Path(assets[0]['rights_evidence_uri']))
    binding = evidence['composition_manifest']
    source = read_audio_static_source(root, Path(binding['path']), expected_sha256=binding['sha256'])
    reference_path = Path(source['produced']['raster']).resolve()
    if assets[0]['content_hash'] != 'sha256:' + _hash(reference_path):
        raise PermissionError('static visual reference differs from current asset')
    expected_origin = str(reference_path) + '#still=' + assets[0]['content_hash']
    start = 0
    expected_frames = 0
    for take in plan['takes']:
        if (take['asset_origin'] != expected_origin or take['start_ms'] != start
                or take['end_ms'] <= start or take.get('on_screen_text')):
            raise PermissionError('static frame/take/reference identity differs')
        expected_frames += _frame_count_for_duration_ms(take['end_ms'] - start)
        start = take['end_ms']
    if not 0 < expected_frames <= 108000:
        raise PermissionError('static observation exceeds existing one-hour bound')
    with Image.open(reference_path) as image:
        reference = np.asarray(image.convert('RGB')).copy()
    left, top, right, bottom = source['produced']['raster_bounds']
    # Include edge context without allowing a full-frame average to hide text.
    region = (slice(max(0, top-6), min(1080, bottom+6)),
              slice(max(0, left-6), min(1920, right+6)))
    paths = [media, plan_path, asset_path, Path(evidence['composition_manifest']['path']),
             Path(assets[0]['rights_evidence_uri']), reference_path, Path(__file__).resolve()]
    captured = {str(path): _hash(path) for path in paths}
    cache = {}
    rows = []
    for index, frame in enumerate(_decoded_static_frames(media, expected_frames=expected_frames)):
        if frame.shape != reference.shape or frame.dtype != np.uint8:
            raise PermissionError('decoded dimensions/type differ from reference')
        digest = hashlib.sha256(frame.tobytes()).hexdigest()
        if digest not in cache:
            # Private invocation-only reuse of identical decoded bytes.
            cache[digest] = {'spatial': spatial_measurements(reference, frame),
                            'text': spatial_measurements(reference[region], frame[region]),
                            'colour': colour_measurements(reference, frame)}
        rows.append({'frame_index': index, 'decoded_rgb_sha256': digest})
    if len(rows) != expected_frames:
        raise PermissionError('decoder omitted the required population')
    if captured != {str(path): _hash(path) for path in paths}:
        raise PermissionError('static observation input changed during decode')
    minimum = min(row['spatial']['mean_ssim'] for row in cache.values())
    return {'status': 'MEASURED_ALL_FRAMES_NOT_FINAL_QUALITY',
        'method': 'native-reference-conditioned-static-rgb-v1',
        'expected_frames': expected_frames, 'observed_frames': len(rows),
        'distinct_decoded_frames': len(cache), 'frames': rows, 'measurements_by_hash': cache,
        'reference': {'path': str(reference_path), 'sha256': 'sha256:'+_hash(reference_path),
                      'composition_id': source['layout']['composition_id'],
                      'title': source['layout']['title'], 'ink_bounds': [left, top, right, bottom]},
        'input_bindings': captured,
        'minimum_frame_mean_ssim': minimum,
        'minimum_text_local_ssim': min(row['text']['minimum_local_ssim'] for row in cache.values()),
        'maximum_colour_delta_e': max(row['colour']['maximum_delta_e'] for row in cache.values()),
        'historical_yuv_transport_floor_not_applied_to_rgb': 0.98,
        'acceptance_limits_calibrated': False,
        'transport_limit_source': 'hero_engine/standard_qualification_phase5.py:visual_fidelity_ssim',
        'remaining': 'Independent exact-codec controls for text-local and colour acceptance; global SSIM is not legibility',
        'quality_authorized': False, 'publication_authorized': False}


def _asr(video: Path, *, local_only: bool = False, include_word_timings: bool = False) -> dict[str, Any]:
    from faster_whisper import WhisperModel  # type: ignore

    model_bindings = []
    if local_only:
        from faster_whisper.utils import download_model
        # Resolve the already installed model only. No fallback download,
        # alternate model or paid provider is admitted in the static branch.
        model_path = Path(download_model('base.en', local_files_only=True)).resolve()
        for path in sorted(model_path.iterdir()):
            if path.is_file() and (path.name in {'model.bin','config.json','tokenizer.json','preprocessor_config.json'}
                                   or path.name.startswith('vocabulary.')):
                model_bindings.append({'path':str(path),'sha256':_hash(path)})
        if not {'model.bin','config.json','tokenizer.json'}.issubset(
                {Path(item['path']).name for item in model_bindings}):
            raise FileNotFoundError('Existing offline ASR model is incomplete')
        model = WhisperModel(str(model_path), device='cpu', compute_type='int8',
                             local_files_only=True, cpu_threads=1, num_workers=1)
    else:
        model = WhisperModel("base.en", device="cpu", compute_type="int8")
    segments, info = model.transcribe(
        str(video), language="en", beam_size=5, vad_filter=True, word_timestamps=True
    )
    rows = list(segments)
    result = {
        "provider": "faster-whisper-base.en-cpu-int8",
        "language": info.language,
        "language_probability": round(float(info.language_probability), 6),
        "duration_seconds": round(float(info.duration), 3),
        "segment_count": len(rows),
        "text": " ".join(item.text.strip() for item in rows).strip(),
    }
    if local_only:
        for item in model_bindings:
            if _hash(Path(item['path'])) != item['sha256']:
                raise PermissionError('Offline ASR model changed during observation')
        result['model_bindings'] = model_bindings
        result['local_files_only'] = True
        result['cpu_threads'] = 1
    if include_word_timings:
        result['words'] = [{'text':word.word.strip(), 'start_ms':round(word.start*1000),
                           'end_ms':round(word.end*1000)}
                          for row in rows for word in (row.words or [])]
    return result


def rest_opening_captions(transcript: dict, *, opening_frames: int) -> str:
    """SRT from actual word timestamps, never estimates or a repeated script."""
    from .render_creative_v3_phase5 import _timestamp
    rows=transcript.get('words',[])
    if not rows or _words(' '.join(row['text'] for row in rows)) != _words(transcript['text']):
        raise PermissionError('opening caption words do not cover actual ASR transcript')
    previous=0
    for row in rows:
        if (type(row['start_ms']) is not int or type(row['end_ms']) is not int
                or not previous <= row['start_ms'] <= row['end_ms']
                or row['end_ms'] > math.ceil(opening_frames/48)):
            raise PermissionError('opening caption timestamps are absent, reversed or outside speech')
        previous=row['end_ms']
    blocks=[]
    # Reuse the existing maximum 12-word cue contract, without extending
    # captions over the intentionally wordless body.
    for index,offset in enumerate(range(0,len(rows),12),start=1):
        group=rows[offset:offset+12]
        # Whisper can observe an instantaneous word boundary. Preserve that
        # measurement, without inventing a duration; the actual displayed cue
        # still must have positive duration and cover all its measured words.
        if group[0]['start_ms'] >= group[-1]['end_ms']:
            raise PermissionError('opening caption cue has no measured duration')
        blocks.append(f"{index}\n{_timestamp(group[0]['start_ms'])} --> {_timestamp(group[-1]['end_ms'])}\n"
                      + ' '.join(row['text'] for row in group)+'\n')
    return '\n'.join(blocks)


def measure_rest_opening_intelligibility(root: Path, package: Path, media: Path,
                                        *, source: dict) -> dict:
    """Reuse offline ASR on only the measured opening of the final mixed media."""
    import tempfile
    import subprocess
    from .qa_phase5 import FFMPEG
    root,package,media=root.resolve(),package.resolve(),media.resolve()
    if not package.is_relative_to(root/'output/production') or not media.is_relative_to(package):
        raise PermissionError('editorial ASR media escaped current package')
    opening=source['opening'];voice=opening['voice']
    frames=voice['samples']*2
    before='sha256:'+_hash(media)
    with tempfile.TemporaryDirectory(prefix='.opening-asr-',dir=package/'qa') as directory:
        excerpt=Path(directory)/'measured-opening.wav'
        command=[str(Path(FFMPEG).resolve()),'-n','-hide_banner','-loglevel','error','-threads','1',
            '-i',str(media),'-map','0:a:0','-af',f'atrim=end_sample={frames},asetpts=PTS-STARTPTS',
            '-ar','48000','-ac','1','-c:a','pcm_s16le',str(excerpt)]
        result=subprocess.run(command,capture_output=True,timeout=120)
        if result.returncode:raise RuntimeError(result.stderr.decode('utf-8',errors='replace'))
        import soundfile as sf
        info=sf.info(excerpt)
        if info.frames!=frames or info.samplerate!=48000 or info.channels!=1:
            raise PermissionError('final speech extraction clock diverged')
        transcript=_asr(excerpt,local_only=True,include_word_timings=True)
        excerpt_hash='sha256:'+_hash(excerpt)
    if before!='sha256:'+_hash(media):raise PermissionError('final media changed during speech observation')
    captions=rest_opening_captions(transcript,opening_frames=frames)
    return {'opening_frames':frames,'media':{'path':str(media),'sha256':before},
        'opening_binding':opening['binding'],'excerpt_sha256':excerpt_hash,
        'transcript':transcript,'captions_text':captions,
        'caption_scope':'MEASURED_SPOKEN_OPENING_ONLY_NOT_FULL_SESSION',
        'method':'EXISTING_OFFLINE_ASR_ON_FINAL_MIX_MEASURED_OPENING'}


def measure_audio_static_intelligibility(root: Path, package: Path, media: Path,
        *, expected_media_hash: str, receipt_binding: dict[str, str] | None = None) -> dict[str, Any]:
    """Extend the existing automatic assessor; observe once or read an anchored receipt."""
    from .phase6_asset_residency import _write_immutable
    root, package, media = root.resolve(), package.resolve(), media.resolve()
    if not package.is_relative_to(root / 'output/production') or not media.is_relative_to(root):
        raise PermissionError('Static ASR escaped project scope')
    plan_path = package / 'take_plan.json'
    plan = _read(plan_path)
    if plan.get('format_pack_id') != 'fp-narrated-reflection-static':
        raise PermissionError('Static ASR requires its exact Pack')
    if 'sha256:' + _hash(media) != expected_media_hash:
        raise PermissionError('Static ASR media differs from authenticated render')
    reference = ' '.join(str(row.get('narration') or '') for row in plan['takes'])
    words = _words(reference)
    if not words:
        raise PermissionError('Static narrated audio has no reference words')
    inputs = {'media':{'path':str(media),'sha256':expected_media_hash},
              'take_plan':{'path':str(plan_path),'sha256':_hash(plan_path)},
              'assessor':{'path':str(Path(__file__).resolve()),'sha256':_hash(Path(__file__))},
              'reference_text_sha256':hashlib.sha256(reference.encode('utf-8')).hexdigest()}
    identity = hashlib.sha256(json.dumps(inputs,sort_keys=True).encode('utf-8')).hexdigest()
    receipt_path = package / 'qa/asr' / (identity+'.json')
    if receipt_binding is not None:
        if (set(receipt_binding) != {'path','sha256'} or Path(receipt_binding['path']).resolve() != receipt_path
                or 'sha256:'+_hash(receipt_path) != receipt_binding['sha256']):
            raise PermissionError('Static ASR receipt anchor/path differs')
        receipt = _read(receipt_path)
        if receipt.get('inputs') != inputs or receipt.get('operation_id') != identity:
            raise PermissionError('Static ASR receipt belongs to previous inputs')
        transcript = receipt['transcript']
    else:
        if receipt_path.exists():
            raise FileExistsError('Existing ASR result must be reconciled with its external hash, not rerun')
        transcript = _asr(media, local_only=True)
    if (transcript.get('provider') != 'faster-whisper-base.en-cpu-int8'
            or transcript.get('local_files_only') is not True or transcript.get('cpu_threads') != 1
            or not transcript.get('model_bindings')):
        raise PermissionError('Static ASR is not the bound offline observer')
    for item in transcript['model_bindings']:
        if _hash(Path(item['path'])) != item['sha256']:
            raise PermissionError('Static ASR model bytes differ')
    distance = _edit_distance(words, _words(str(transcript['text'])))
    wer = distance / len(words)
    result = {'reference_word_count':len(words),'word_error_count':distance,
              'word_error_rate':wer,'threshold_max_word_error_rate':0.08,
              'passed':wer <= 0.08 and transcript.get('language') == 'en'}
    if ('sha256:'+_hash(media) != expected_media_hash or _hash(plan_path) != inputs['take_plan']['sha256']
            or _hash(Path(__file__)) != inputs['assessor']['sha256']):
        raise PermissionError('Static ASR inputs changed before receipt')
    if receipt_binding is None:
        _write_immutable(receipt_path, {'operation_id':identity,'inputs':inputs,'transcript':transcript,
            'measurement':result,'created_at':_now(),'publication_authorized':False})
    elif receipt.get('measurement') != result or receipt.get('publication_authorized') is not False:
        raise PermissionError('Static ASR derived measurement/scope altered')
    return {**result,'receipt':{'path':str(receipt_path),'sha256':'sha256:'+_hash(receipt_path)},
            'publication_authorized':False}


def audio_static_technical_pass(measured: dict[str, float]) -> bool:
    """Reuse the autonomous assessor's existing LUFS/peak/dynamics limits."""
    return (-17.0 <= measured['integrated_lufs'] <= -15.0
            and measured['true_peak_dbtp'] <= -1.0 and 1.0 <= measured['lra_lu'] <= 8.0)


MUSIC_MODEL_REVISION = '9b1dd8e5df9af7216e836a98974fe3b82c56ded6'
MUSIC_MODEL_SHA256 = 'a5a3c2412649cc2384ec525ffd5180ce6c4778f43bed6108e0a1303de04d014e'
MUSIC_MODEL_CONFIG_BLOB = 'e2b5a9ece8c3db1cffec3bef4c63bf678fbcaf4e'


def _music_aesthetic_predictor(root: Path):
    """Pinned local safetensors only; no automatic downloads or pickle loading."""
    import importlib.metadata
    import torch
    import torchaudio
    from audiobox_aesthetics.model.aes import AesMultiOutput
    from safetensors.torch import load_file
    directory = root / 'models/audiobox-aesthetics' / MUSIC_MODEL_REVISION
    weights, config = directory / 'model.safetensors', directory / 'config.json'
    if (any(not path.resolve().is_relative_to(root.resolve()) for path in (directory,weights,config))
            or _hash(weights) != MUSIC_MODEL_SHA256):
        raise PermissionError('music evaluator model anchor diverged')
    raw = config.read_bytes()
    if hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() != MUSIC_MODEL_CONFIG_BLOB:
        raise PermissionError('music evaluator configuration anchor diverged')
    expected = {'audiobox-aesthetics':'0.0.4','torch':'2.8.0+cpu',
                'torchaudio':'2.8.0+cpu','safetensors':'0.8.0'}
    if any(importlib.metadata.version(name) != version for name,version in expected.items()):
        raise PermissionError('music evaluator execution versions differ')
    model = AesMultiOutput(**json.loads(raw))
    model.load_state_dict(load_file(str(weights)), strict=True, assign=True)
    model.eval()
    def predict(audio, sample_rate):
        wav = torchaudio.functional.resample(torch.from_numpy(audio.T.copy()),
            sample_rate, 16000).mean(0, keepdim=True).unsqueeze(0)
        valid = wav.shape[-1]
        if valid < 160000:
            wav = torch.nn.functional.pad(wav, (0,160000-valid))
        mask = torch.zeros_like(wav,dtype=torch.bool);mask[..., :valid]=True
        with torch.inference_mode():
            scores = model({'wav':wav, 'mask':mask})
        return {axis:float(scores[axis].item()*model.target_transform[axis]['std']+
            model.target_transform[axis]['mean']) for axis in ('CE','CU','PC','PQ')}
    return predict, {'revision':MUSIC_MODEL_REVISION,'weights':str(weights),
        'weights_sha256':'sha256:'+MUSIC_MODEL_SHA256,'config':str(config),
        'config_sha256':'sha256:'+_hash(config),'versions':expected,
        'reference':'https://arxiv.org/abs/2502.05139','license':'CC-BY-4.0'}


def measure_music_aesthetics(root: Path, media: Path, *, expected_media_hash: str,
                            expected_duration_ms: int,
                            window_starts_ms: tuple[int, ...] | None = None,
                            music_start_frame: int = 0) -> dict[str, Any]:
    """Real learned music assessment, one bounded 10s buffer/window on CPU.

    Scores retain the model's four distinct meanings. They are not an invented
    pass threshold, medical fatigue prediction or an ASR/codec calibration.
    Partial observations explicitly cannot approve the full duration.
    """
    import math
    import time
    import numpy as np
    import soundfile as sf
    from .production_capacity import _HEAVY_TASK_SLOT, measure_local_resources, ResourceWait
    root, media = root.resolve(), media.resolve()
    if (not media.is_relative_to(root) or not re.fullmatch(r'sha256:[0-9a-f]{64}',expected_media_hash)
            or type(expected_duration_ms) is not int or not 0 < expected_duration_ms <= 14400000):
        raise ValueError('music assessment requires exact local media/duration')
    if 'sha256:'+_hash(media) != expected_media_hash:
        raise PermissionError('music assessment media anchor diverged')
    with sf.SoundFile(media) as stream:
        if (stream.samplerate != 48000 or stream.channels != 2 or stream.subtype != 'PCM_16'
                or stream.frames != math.ceil(expected_duration_ms*48)):
            raise PermissionError('music assessment PCM clock/identity differs')
        if type(music_start_frame) is not int or not 0 <= music_start_frame < stream.frames:
            raise ValueError('musical observation must begin at an actual in-bound PCM sample')
        if music_start_frame and window_starts_ms is not None:
            raise ValueError('editorial musical body cannot substitute selected sparse windows')
        starts = tuple(range(0,expected_duration_ms,10000)) if window_starts_ms is None else window_starts_ms
        if (not isinstance(starts,tuple) or not starts or len(starts)>1440
                or any(type(x) is not int or x<0 or x>=expected_duration_ms for x in starts)
                or tuple(sorted(set(starts))) != starts
                or any(b < a+min(10000,expected_duration_ms-a) for a,b in zip(starts,starts[1:]))):
            raise ValueError('music windows must be ordered, disjoint and in bounds')
        if not _HEAVY_TASK_SLOT.acquire(blocking=False):
            raise ResourceWait({'causes':['OWN_HEAVY_TASK_ACTIVE'],'next_check_seconds':60})
        try:
            samples=[measure_local_resources(root),measure_local_resources(root)]
            if any(s['available_ram_bytes']<1536*1024**2 or s['output_free_bytes']<12*1024**3 for s in samples):
                raise ResourceWait({'causes':['MUSIC_EVALUATOR_CAPACITY'],'samples':samples,'next_check_seconds':60})
            import torch
            previous_threads=torch.get_num_threads()
            try:
                torch.set_num_threads(1)
                started=time.monotonic();predict,model=_music_aesthetic_predictor(root)
                loaded=time.monotonic();rows=[]
                offsets=range(music_start_frame,stream.frames,480000) if music_start_frame else (s*48 for s in starts)
                for offset in offsets:
                    end=min(offset+480000,stream.frames)
                    # The reference uses real 10s contexts. For a final partial
                    # coverage window, reuse preceding REAL musical samples,
                    # never speech, invented silence or repeated samples. Unique
                    # coverage remains [offset,end), independently of context.
                    context_start=offset if end-offset==480000 else max(music_start_frame,end-480000)
                    stream.seek(context_start)
                    audio=stream.read(end-context_start,dtype='float32',always_2d=True)
                    if not np.isfinite(audio).all():raise PermissionError('non-finite music window')
                    at=time.monotonic();scores=predict(audio,48000)
                    if (set(scores)!= {'CE','CU','PC','PQ'}
                            or any(type(v) not in (int,float) or not math.isfinite(v) for v in scores.values())):
                        raise PermissionError('music model returned incomplete/non-finite evidence')
                    rows.append({'start_frame':offset,'end_frame':end,
                        'context_start_frame':context_start,'context_end_frame':end,
                        'scores':scores,'wall_seconds':time.monotonic()-at})
                elapsed=time.monotonic()-started
            finally:torch.set_num_threads(previous_threads)
        finally:_HEAVY_TASK_SLOT.release()
    covered=sum(row['end_frame']-row['start_frame'] for row in rows)
    if ('sha256:'+_hash(media) != expected_media_hash
            or 'sha256:'+_hash(Path(model['weights'])) != model['weights_sha256']
            or 'sha256:'+_hash(Path(model['config'])) != model['config_sha256']):
        raise PermissionError('music input/model changed during assessment')
    return {'status':'MEASURED_MUSIC_AESTHETICS','media_hash':expected_media_hash,
        'window_context_policy':'REAL_MUSICAL_TAIL_CONTEXT_UNIQUE_COVERAGE_V1',
        'duration_ms':expected_duration_ms,'observed_frames':covered,
        'full_duration_observed':covered==math.ceil(expected_duration_ms*48)-music_start_frame,
        **({'observation_start_frame':music_start_frame,'scope':'COMPLETE_MUSICAL_BODY_AFTER_MEASURED_OPENING'} if music_start_frame else {}),
        'windows':rows,'model':model,'device':'cpu','threads':1,
        'model_load_seconds':loaded-started,'wall_seconds':elapsed,'resource_samples':samples,
        'axis_mean':{axis:sum(row['scores'][axis]*(row['end_frame']-row['start_frame'])
            for row in rows)/covered for axis in ('CE','CU','PC','PQ')},
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False,
        'fatigue_or_medical_claim':False,'limitations':['Learned ratings have uncertainty',
            'Content enjoyment is not audience retention','No 3h comfort or hearing-exposure inference']}


def measure_music_sample(media: Path, *, expected_media_hash: str,
                         expected_duration_ms: int) -> dict[str, Any]:
    """Independent short-sample observation; never grants music/release authority.

    Existing narrated-mix limits are reported in their own scope, not silently
    repurposed as a calibrated relaxation-music rubric. Continuity measurements
    have no invented perceptual acceptance threshold.
    """
    import math
    import os
    import subprocess
    import numpy as np
    import soundfile as sf
    from .qa_phase5 import FFMPEG

    media = media.resolve()
    if (not re.fullmatch(r'sha256:[0-9a-f]{64}', expected_media_hash)
            or type(expected_duration_ms) is not int
            or not 0 < expected_duration_ms <= 120_000):
        raise ValueError('music observation requires pinned hash and <=120s short sample')
    if 'sha256:' + _hash(media) != expected_media_hash:
        raise PermissionError('music sample hash diverged')
    count = 0
    peak = square_sum = max_delta = seam_delta = 0.0
    previous = first = last = None
    spectral_windows = []
    previous_spectrum = None
    with sf.SoundFile(media) as decoded:
        rate, channels = decoded.samplerate, decoded.channels
        expected_frames = math.ceil(expected_duration_ms * rate / 1000)
        if (rate != 48_000 or channels != 2 or decoded.subtype != 'PCM_16'
                or decoded.frames != expected_frames):
            raise PermissionError('music PCM identity/duration diverged')
        for block in decoded.blocks(blocksize=rate, dtype='float64', always_2d=True):
            if not np.isfinite(block).all():
                raise PermissionError('non-finite decoded music')
            peak = max(peak, float(np.max(np.abs(block))))
            square_sum += float(np.sum(block * block))
            if len(block) > 1:
                max_delta = max(max_delta, float(np.max(np.abs(np.diff(block, axis=0)))))
            if previous is not None:
                jump = float(np.max(np.abs(block[0] - previous)))
                seam_delta = max(seam_delta, jump)
                max_delta = max(max_delta, jump)
            if first is None:
                first = block[0].copy()
            previous = last = block[-1].copy()
            window = np.hanning(len(block))
            powers = np.mean(np.abs(np.fft.rfft(block * window[:, None], n=rate, axis=0)) ** 2, axis=1)
            frequencies = np.fft.rfftfreq(rate, 1 / rate)
            power_sum = float(np.sum(powers))
            if power_sum > 0:
                spectrum = powers / power_sum
                centroid = float(np.sum(frequencies * spectrum))
                peak_hz = float(frequencies[int(np.argmax(powers))])
                flatness = float(np.exp(np.mean(np.log(np.maximum(powers, np.finfo(float).tiny)))) / np.mean(powers))
                norm = float(np.linalg.norm(spectrum))
                similarity = (float(np.dot(spectrum, previous_spectrum) /
                    (norm * np.linalg.norm(previous_spectrum))) if previous_spectrum is not None else None)
                previous_spectrum = spectrum
            else:
                centroid = peak_hz = flatness = similarity = None
                previous_spectrum = None
            spectral_windows.append({'start_frame': count, 'end_frame': count + len(block),
                'peak_frequency_hz': peak_hz, 'spectral_centroid_hz': centroid,
                'spectral_flatness': flatness, 'previous_window_spectral_cosine': similarity,
                'rms_linear': float(np.sqrt(np.mean(block * block)))})
            count += len(block)
    process = subprocess.run([FFMPEG, '-nostdin', '-hide_banner', '-nostats',
        '-threads', '1', '-i', str(media), '-af',
        'loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json', '-f', 'null', os.devnull],
        capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    if process.returncode:
        raise RuntimeError('music loudness measurement failed: ' + process.stderr[-2000:])
    matches = re.findall(r'\{\s*"input_i".*?\}', process.stderr, re.S)
    if not matches:
        raise RuntimeError('music loudness measurement incomplete')
    payload = json.loads(matches[-1])
    loudness = {key: float(payload[field]) for key, field in (
        ('integrated_lufs', 'input_i'), ('true_peak_dbtp', 'input_tp'), ('lra_lu', 'input_lra'))}
    if 'sha256:' + _hash(media) != expected_media_hash:
        raise PermissionError('music sample changed during observation')
    finite = all(math.isfinite(value) for value in loudness.values())
    # Silent/degenerate input may legitimately be reported as -inf by FFmpeg;
    # persist unavailable measurements as null, never non-standard JSON or PASS.
    serialized_loudness = {key: value if math.isfinite(value) else None
                           for key, value in loudness.items()}
    return {'status': 'MEASURED_SHORT_SAMPLE', 'media': str(media),
        'media_hash': expected_media_hash, 'duration_ms': expected_duration_ms,
        'observed_frames': count, 'sample_rate': rate, 'channels': channels,
        'measurements': {'peak_linear': peak, 'rms_linear': math.sqrt(square_sum / (count * channels)),
            'maximum_adjacent_sample_delta': max_delta,
            'maximum_block_boundary_delta': seam_delta,
            'end_to_start_delta': float(np.max(np.abs(last - first))), 'loudness': serialized_loudness},
        'existing_narrated_mix_gate': {'status': 'PASS' if finite and audio_static_technical_pass(loudness) else 'FAIL',
            'scope': 'NARRATED_MIX_ONLY', 'criteria_source': 'audio_static_technical_pass',
            'limits': {'integrated_lufs': [-17, -15], 'true_peak_dbtp_max': -1, 'lra_lu': [1, 8]}},
        'music_attributes': {
            'timbre': {'status': 'MEASURED_NOT_QUALIFIED',
                'method': 'Hann-windowed per-channel FFT power, combined without mono phase cancellation',
                'reference_scope': 'ACOUSTIC_MEASUREMENT_NOT_GENRE_GOLD'},
            'variation': {'status': 'MEASURED_NOT_QUALIFIED',
                'method': 'Cosine similarity of consecutive power spectra and window RMS',
                'limitation': 'Spectral similarity is not melody identity or a perceptual repetition threshold'},
            'fatigue': {'status': 'NOT_ESTABLISHED',
                'observed_duration_ms': expected_duration_ms,
                'limitation': 'Short-sample loudness/spectrum do not establish three-hour listening comfort, hearing exposure or audience response'},
            'windows': spectral_windows},
        'music_quality_status': 'BLOCKED_UNCALIBRATED_MUSIC_REFERENCE',
        'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}


def _srt_text(path: Path) -> str:
    lines = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        stripped = line.strip()
        if not stripped or stripped.isdigit() or "-->" in stripped:
            continue
        lines.append(stripped)
    return " ".join(lines)


def _gate(
    name: str,
    passed: bool,
    method: str,
    threshold: Any,
    observed: Any,
    evidence: list[str],
) -> dict[str, Any]:
    return {
        "gate": name,
        "critical": True,
        "status": "PASS" if passed else "FAIL",
        "method": method,
        "threshold": threshold,
        "observed": observed,
        "evidence_refs": evidence,
    }


def build_evaluation(
    root: Path = ROOT,
    *,
    asr_result: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    qualification_path = root / V3 / "standard-qualification/standard_qualification_report.json"
    qa_path = root / V3 / "qa/creative_quality_gate_report.json"
    metrics_path = root / V3 / "qa/creative_revision_metrics.json"
    technical_path = root / V3 / "qa/technical_measurements.json"
    take_plan_path = root / V3 / "take_plan.json"
    script_path = root / V3 / "narrative_script.json"
    captions_path = root / V3 / "captions/en-US.srt"
    assets_path = root / V3 / "asset_manifest.allocated.json"
    thumbnails_path = root / V3 / "thumbnail/thumbnail_set_manifest.json"
    package_path = root / V3 / "publication_package.json"
    negative_path = root / "output/production/phase5/pilot-001/creative-v2/qa/market_readiness_review.json"
    gold_path = root / "data/gold_standard/validation_report.json"

    qualification = _read(qualification_path)
    automatic_qa = _read(qa_path)
    metrics = _read(metrics_path)
    technical = _read(technical_path)
    take_plan = _read(take_plan_path)
    script = _read(script_path)
    assets = _read(assets_path)
    thumbnails = _read(thumbnails_path)
    package = _read(package_path)
    negative = _read(negative_path)
    gold = _read(gold_path)
    candidate = qualification["candidate"]
    video = Path(candidate["path"])
    if not video.is_absolute():
        video = root / video
    expected_hash = candidate["content_hash"].removeprefix("sha256:")
    observed_hash = _hash(video) if video.is_file() else ""
    hash_ok = observed_hash == expected_hash == package["video"]["sha256"]

    transcript = asr_result or _asr(video)
    expected_words = _words(script["full_text"])
    observed_words = _words(str(transcript["text"]))
    distance = _edit_distance(expected_words, observed_words)
    wer = round(distance / max(1, len(expected_words)), 6)
    transcript.update({
        "reference_word_count": len(expected_words),
        "observed_word_count": len(observed_words),
        "word_error_count": distance,
        "word_error_rate": wer,
        "threshold_max_word_error_rate": 0.08,
        "passed": wer <= 0.08 and transcript.get("language") == "en",
    })

    caption_words = _words(_srt_text(captions_path))
    caption_distance = _edit_distance(expected_words, caption_words)
    captions = {
        "cue_count": technical["captions"]["cue_count"],
        "expected_cue_count": len(take_plan["takes"]),
        "coverage_ratio": technical["captions"]["coverage_ratio"],
        "maximum_words_per_cue": technical["captions"]["maximum_words_per_cue"],
        "script_word_error_rate": round(caption_distance / max(1, len(expected_words)), 6),
        "hash_verified": technical["captions"]["manifest_hash_matches"],
    }
    captions["passed"] = bool(
        captions["cue_count"] == captions["expected_cue_count"]
        and captions["coverage_ratio"] == 1.0
        and captions["maximum_words_per_cue"] <= 12
        and captions["script_word_error_rate"] == 0
        and captions["hash_verified"]
    )

    takes = take_plan["takes"]
    semantic_complete = sum(bool(
        item.get("narrative_function") and item.get("information") and item.get("action")
        and item.get("semantic_alignment") and item.get("retention_job")
        and item.get("asset_origin") and item.get("rights", {}).get("status")
    ) for item in takes)
    semantic = {
        "take_count": len(takes),
        "complete_take_count": semantic_complete,
        "coverage_ratio": round(semantic_complete / max(1, len(takes)), 6),
        "distinct_narrative_functions": len({item["narrative_function"] for item in takes}),
        "forbidden_generic_cloud_fallback": any(
            check["check"] == "forbidden_generic_cloud_fallback" and check["observed"] is True
            for check in metrics["checks"]
        ),
    }
    semantic["passed"] = semantic["coverage_ratio"] == 1.0 and not semantic["forbidden_generic_cloud_fallback"]

    used_assets = [item for item in assets["assets"] if item.get("used_ranges")]
    rights = {
        "used_asset_count": len(used_assets),
        "eligible_count": sum(bool(item.get("production_eligible")) for item in used_assets),
        "unknown_or_restricted_count": sum(item.get("rights_status") in {"UNKNOWN", "RESTRICTED"} for item in used_assets),
        "synthetic_assets_disclosed": package["disclosure"]["contains_synthetic_media"] is True,
        "all_rights_evidence_present": all(Path(item["rights_evidence_uri"]).is_file() for item in used_assets),
    }
    rights["passed"] = bool(
        rights["used_asset_count"] == rights["eligible_count"]
        and rights["unknown_or_restricted_count"] == 0
        and rights["synthetic_assets_disclosed"]
        and rights["all_rights_evidence_present"]
    )

    signal = technical["signalstats"]
    black = technical["black_freeze"]
    visual_signal = {
        "sample_count": signal["sample_count"],
        "within_take_luminance_delta_p95": signal["within_take_luminance_delta_p95"],
        "flicker_threshold_p95": signal["flicker_threshold_p95"],
        "hard_transition_count": signal["hard_transition_count"],
        "black_event_count": black["black_event_count"],
        "freeze_event_count": black["freeze_event_count"],
    }
    visual_signal["passed"] = bool(
        visual_signal["sample_count"] >= 470
        and visual_signal["within_take_luminance_delta_p95"] <= visual_signal["flicker_threshold_p95"]
        and visual_signal["hard_transition_count"] == 0
        and visual_signal["black_event_count"] == 0
        and visual_signal["freeze_event_count"] == 0
    )

    timeline = copy.deepcopy(technical["timeline"])
    timeline["passed"] = bool(
        timeline["contiguous"] and timeline["no_adjacent_source_repeat"]
        and timeline["absolute_duration_error_ms"] == 0
        and timeline["maximum_take_duration_error_ms"] == 0
        and timeline["maximum_cumulative_drift_ms"] == 0
    )
    variety = copy.deepcopy(technical["visual_repetition"])
    originality = copy.deepcopy(technical["originality"])
    originality["passed"] = originality["maximum_target_trigram_overlap"] <= originality["threshold"]

    hook = technical["hook"]
    hook_pass = bool(
        hook["timing_status"] == "PASS" and len(hook["distinct_sources"]) >= 3
        and hook["visual_event_count"] >= 7 and hook["voice_durations_ms"][0] <= 1000
        and sum(hook["voice_durations_ms"][:2]) <= 3000
    )
    narrative_pass = bool(
        len(script["hook_windows"]) == 4 and len(script["sections"]) == 9
        and 500 <= script["word_count"] <= 575
        and "24-hour" in package["metadata"]["title"].casefold()
    )
    style_pass = bool(
        variety["passed"] and technical["landscape"]["passed"]
        and metrics["automatic_status"] == "PASS"
    )
    audio = technical["loudness"]
    audio_pass = bool(
        transcript["passed"]
        and -17.0 <= audio["integrated_lufs"] <= -15.0
        and audio["true_peak_dbtp"] <= -1.0
        and 1.0 <= audio["lra_lu"] <= 8.0
    )
    legibility_pass = captions["passed"] and all(
        len((item.get("on_screen_text") or "").split()) <= 8 for item in takes
    )
    publicity_pass = rights["passed"] and all(
        item["source"].startswith(("https://commons.wikimedia.org/", "generated://", "procedural://"))
        for item in used_assets
    )
    identity_tokens = {word.upper() for word in _words(script["full_text"])}
    identity_pass = bool(
        all(item["format_pack_id"] == "fp-broll-cinematic-narration" for item in takes)
        and {"TRUTH", "RESPONSIBILITY", "TODAY"}.issubset(identity_tokens)
        and variety["passed"]
    )

    candidate_id = thumbnails["automatic_recommendation"]
    selected = next(item for item in thumbnails["candidates"] if item["candidate_id"] == candidate_id)
    selected_path = Path(selected["path"])
    thumbs_pass = all(item["automated_status"] == "PASS" for item in thumbnails["candidates"])
    thumb_hash = _hash(selected_path)
    thumbnail_ok = thumbs_pass and thumb_hash == selected["content_hash"].removeprefix("sha256:")

    evidence = {
        "qa": _relative(root, qa_path), "metrics": _relative(root, metrics_path),
        "technical": _relative(root, technical_path), "take_plan": _relative(root, take_plan_path),
        "script": _relative(root, script_path), "captions": _relative(root, captions_path),
        "assets": _relative(root, assets_path), "thumbnails": _relative(root, thumbnails_path),
        "qualification": _relative(root, qualification_path), "gold": _relative(root, gold_path),
        "negative": _relative(root, negative_path),
    }
    gates = [
        _gate("HOOK", hook_pass, "frame-locked 0–1/1–3/3–8 timing plus source/event diversity", {"first_unit_max_ms": 1000, "first_two_units_max_ms": 3000, "distinct_sources_min": 3, "events_min": 7}, hook, [evidence["technical"], evidence["script"]]),
        _gate("NARRATIVE", narrative_pass, "ordered nine-section promise/mechanism/payoff contract", {"sections": 9, "words": [500, 575], "title_names_mechanism": True}, {"sections": len(script["sections"]), "words": script["word_count"], "title": package["metadata"]["title"]}, [evidence["script"], _relative(root, package_path)]),
        _gate("SEMANTIC_COHERENCE", semantic["passed"], "take-level narrative/action/asset/retention traceability", {"coverage_ratio": 1.0, "forbidden_fallback": False}, semantic, [evidence["take_plan"], evidence["metrics"]]),
        _gate("STYLE", style_pass, "anti-repetition, landscape-share and locked-format checks", {"single_share_max": 0.10, "top_six_max": 0.55, "landscape_max": 0.25}, {"single_share": variety["maximum_single_asset"]["share"], "top_six_share": variety["top_six_runtime_share"], "landscape_share": technical["landscape"]["share"]}, [evidence["technical"], "output/production/phase5/pilot-001/creative-v3/channel_style_bible.json"]),
        _gate("CONTINUITY", timeline["passed"], "frame-lock, contiguity, adjacent-source and drift checks", {"duration_error_ms": 0, "drift_ms": 0, "adjacent_repeat": False}, timeline, [evidence["technical"], evidence["take_plan"]]),
        _gate("MOVEMENT", visual_signal["passed"], "full-duration 2 fps signal scan plus black/freeze/transition detection", {"sample_count_min": 470, "flicker_p95_max": 15, "black": 0, "freeze": 0, "hard_transition": 0}, visual_signal, [evidence["technical"], "output/production/phase5/pilot-001/creative-v3/qa/supplemental-review/timeline-01.jpg", "output/production/phase5/pilot-001/creative-v3/qa/supplemental-review/timeline-02.jpg", "output/production/phase5/pilot-001/creative-v3/qa/supplemental-review/timeline-03.jpg"]),
        _gate("LEGIBILITY", legibility_pass, "caption density plus take-level text-length/safe-area render contract", {"caption_coverage": 1.0, "cue_words_max": 12, "overlay_words_max": 8}, {"captions": captions, "maximum_overlay_words": max(len((item.get("on_screen_text") or "").split()) for item in takes)}, [evidence["captions"], evidence["take_plan"], evidence["technical"]]),
        _gate("AUDIO", audio_pass, "independent local ASR intelligibility plus loudness/true-peak/dynamics", {"wer_max": 0.08, "lufs": [-17.0, -15.0], "true_peak_max": -1.0, "lra": [1.0, 8.0]}, {"asr": transcript, "loudness": audio}, [evidence["technical"], "output/production/phase5/pilot-001/creative-v3/audio/creative_audio_manifest.json"]),
        _gate("CAPTIONS", captions["passed"], "SRT-to-script exact-word comparison plus cue/hash contract", {"script_wer": 0, "cue_count": len(takes), "coverage": 1.0}, captions, [evidence["captions"], evidence["script"], evidence["technical"]]),
        _gate("PUBLICITY", publicity_pass, "source allowlist, eligibility, evidence and synthetic disclosure", {"eligible_share": 1.0, "unknown": 0, "synthetic_disclosure": True}, rights, [evidence["assets"], "output/production/phase5/pilot-001/creative-v3/attribution.txt", _relative(root, package_path)]),
        _gate("CHANNEL_IDENTITY", identity_pass, "FormatPack pin, locked three-part identity motif and diversity controls", {"format_pack_coverage": 1.0, "motif": ["TRUTH", "RESPONSIBILITY", "TODAY"]}, {"format_pack_coverage": sum(item["format_pack_id"] == "fp-broll-cinematic-narration" for item in takes) / len(takes), "motif_present": True, "variety_pass": variety["passed"]}, [evidence["take_plan"], evidence["script"], "output/production/phase5/pilot-001/creative-v3/channel_style_bible.json"]),
        _gate("THUMBNAIL", thumbnail_ok, "predeclared action/mechanism/fidelity rubric; no provider-score-only selection", {"all_auto_pass": True, "selected": "automatic_recommendation", "hash_match": True}, {"candidate_id": candidate_id, "automatic_basis": thumbnails["automatic_recommendation_basis"], "hash_match": thumb_hash == selected["content_hash"].removeprefix("sha256:")}, [evidence["thumbnails"], "output/production/phase5/pilot-001/creative-v3/metadata_packaging_decision.json"]),
    ]

    calibration = {
        "human_gold_standard_available": bool(gold.get("passed") and gold.get("totals", {}).get("videos") == 4),
        "human_gold_standard_scope": "Human-approved Phase 1 mining/take/hook evidence; it calibrates analysis structure, not audience taste or guaranteed performance.",
        "gold_standard_validation_pass": bool(gold.get("passed")),
        "negative_control_detected": negative.get("verdict") == "REJECTED_FOR_PUBLICATION" and any(item["status"] == "FAIL" for item in negative["gates"]),
        "negative_control_expected": "REJECTED_FOR_PUBLICATION",
        "negative_control_observed": str(negative.get("verdict")),
        "owner_policy_authorization": "AUTONOMOUS_PER_VIDEO_REVIEW_REQUIRED",
        "transfer_limit": "This calibration authorizes only the pinned HeroVerse long-form FormatPack under LIMITED canary constraints; it does not transfer to another channel, format or quality profile.",
    }
    all_pass = hash_ok and all(item["status"] == "PASS" for item in gates) and all((
        calibration["human_gold_standard_available"],
        calibration["gold_standard_validation_pass"],
        calibration["negative_control_detected"],
    ))
    blockers = [] if all_pass else [item["gate"] for item in gates if item["status"] != "PASS"]
    if not hash_ok:
        blockers.append("ARTIFACT_INTEGRITY")
    if not calibration["gold_standard_validation_pass"]:
        blockers.append("GOLD_STANDARD_CALIBRATION")
    decision = "PASS_LIMITED_CANARY" if all_pass else "FAIL"
    timestamp = created_at or _now()
    result = {
        "schema_version": "1.0.0",
        "evaluation_id": f"autonomous-quality-{expected_hash[:20]}",
        "evaluator": {
            "evaluator_id": "heroverse-autonomous-quality-assessor",
            "version": "1.0.0",
            "separate_from_generator": True,
            "human_reviewer_claimed": False,
            "methods": ["frozen-artifact-hash", "faster-whisper-asr", "ffmpeg-signal-analysis", "take-level-contract-audit", "rights-provenance-audit", "negative-control-regression", "thumbnail-fidelity-rubric"],
        },
        "artifact": {"path": _relative(root, video), "sha256": observed_hash, "duration_ms": candidate["duration_ms"], "qualification_id": qualification["qualification_id"], "hash_verified": hash_ok},
        "calibration": calibration,
        "measurements": {
            "asr": transcript, "captions": captions, "visual_signal": visual_signal,
            "timeline": timeline, "rights": rights, "originality": originality,
            "semantic_traceability": semantic, "visual_variety": variety,
        },
        "gates": gates,
        "thumbnail_selection": {
            "candidate_id": candidate_id, "path": str(selected_path.resolve()), "sha256": thumb_hash,
            "selection_method": "predeclared-rubric-plus-editorial-fidelity",
            "all_candidates_automatic_pass": thumbs_pass, "selected": thumbnail_ok,
        },
        "audit_policy": {
            "per_release_human_review": False,
            "routine_human_sample_rate": 0.10,
            "mandatory_triggers": ["any critical automatic gate uncertainty or failure", "new FormatPack/pipeline/voice/tool version", "rights/publicity ambiguity", "post-publication complaint or anomaly", "three-video LIMITED review checkpoint"],
            "production_scope": "HeroVerse English Christian-motivation long-form, this FormatPack/pipeline/profile only",
            "promotion_ceiling_without_human_sample": "LIMITED",
        },
        "decision": decision,
        "publication_eligible": all_pass,
        "format_pack_transition_eligible": all_pass,
        "blockers": sorted(set(blockers)),
        "claim_boundary": [
            "PASS means the measurable release contract passed; it does not guarantee virality, monetization, views, CTR, retention or YPP approval.",
            "The evaluator is autonomous and separate from the generator but is not represented as a human reviewer.",
            "Human gold-standard work remains for calibration and exception sampling, not a form that must be completed before every publication.",
            "LIMITED authorizes one channel/format/profile only and must fail closed on drift, ambiguity or version change.",
        ],
        "evidence_refs": list(evidence.values()),
        "technical_cost_brl": 0,
        "created_at": timestamp,
    }
    _validate(root, "phase5_autonomous_quality_evaluation.schema.json", result)
    return result


def materialize(
    root: Path = ROOT,
    *,
    asr_result: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> Path:
    root = root.resolve()
    path = root / REPORT
    if asr_result is None and path.is_file():
        try:
            prior = _read(path)
            qualification = _read(root / V3 / "standard-qualification/standard_qualification_report.json")
            expected_hash = qualification["candidate"]["content_hash"].removeprefix("sha256:")
            if prior.get("artifact", {}).get("sha256") == expected_hash:
                asr_result = copy.deepcopy(prior["measurements"]["asr"])
        except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
            asr_result = None
    evaluation = build_evaluation(root, asr_result=asr_result, created_at=created_at)
    if created_at is None and path.is_file():
        try:
            prior = _read(path)
            _validate(root, "phase5_autonomous_quality_evaluation.schema.json", prior)
            prior_comparable = copy.deepcopy(prior)
            evaluation_comparable = copy.deepcopy(evaluation)
            prior_comparable.pop("created_at", None)
            evaluation_comparable.pop("created_at", None)
            if prior_comparable == evaluation_comparable:
                return path
        except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
            pass
    _write(path, evaluation)
    return path


def apply_limited_transition(
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    refresh_package: bool = True,
) -> Path:
    root = root.resolve()
    report_path = root / REPORT
    report = _read(report_path)
    _validate(root, "phase5_autonomous_quality_evaluation.schema.json", report)
    if report["decision"] != "PASS_LIMITED_CANARY" or not report["format_pack_transition_eligible"]:
        raise PermissionError("Autonomous quality evaluation is not eligible for LIMITED transition")
    pack_path = root / PACK
    registry_path = root / REGISTRY
    pack = _read(pack_path)
    registry = _read(registry_path)
    if pack["capability_status"] == "LIMITED" and pack["production_allowed"] is True:
        if (root / TRANSITION).is_file():
            return root / TRANSITION
        raise RuntimeError("FormatPack is LIMITED without an autonomous transition receipt")
    if pack["capability_status"] != "PROTOTYPED" or pack["production_allowed"] is not False:
        raise PermissionError("Only the exact PROTOTYPED FormatPack can transition to LIMITED")

    timestamp = created_at or _now()
    archive_dir = root / V3 / "autonomous-review/rollback"
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_path = archive_dir / "fp-broll-cinematic-narration.pre-autonomous-limited.json"
    if not archive_path.exists():
        shutil.copy2(pack_path, archive_path)

    before = _artifact(root, pack_path)
    limitation = {
        "allowed_scope": [
            "HeroVerse channel UCuMF6pJQkyMzaVoAxFL86yA only",
            "English Christian-motivation long-form only",
            "clip-based documentary-cinematic narration using pipeline-clips-longform-v1@1.0.0",
            "STANDARD profile at 1920x1080/30 fps within 207750-286250 ms",
            "one autonomous canary release followed by post-publication monitoring",
            "technical cost R$ 0.00",
        ],
        "forbidden_scope": [
            "other channels, Shorts, other macrofamilies or quality profiles",
            "new pipeline, voice, generator or FormatPack version without re-evaluation",
            "publication with a critical gate below PASS or rights/publicity ambiguity",
            "Ads, paid tools or any spend without a separately approved budget",
            "PRODUCTION_READY claim before the three-video checkpoint and required sampled audit",
        ],
        "expiry_or_review": "Reassess after this canary result, any critical regression/version change/complaint, or no later than the third published video; promotion ceiling remains LIMITED until sampled human calibration exists.",
    }
    pack["capability_status"] = "LIMITED"
    pack["production_allowed"] = True
    pack["limitation_contract"] = limitation
    mandatory_test = "autonomous visual/audio evaluation with human gold-standard calibration and exception sampling"
    pack["specification"]["mandatory_tests"] = list(dict.fromkeys([
        item for item in pack["specification"]["mandatory_tests"]
        if item not in {"human visual and audio review", mandatory_test}
    ] + [mandatory_test]))
    approval_criterion = "autonomous evaluator separate from the generator passes all twelve release gates; sampled human calibration remains mandatory for PRODUCTION_READY"
    pack["specification"]["approval_criteria"] = list(dict.fromkeys([
        item for item in pack["specification"]["approval_criteria"]
        if item not in {"human review independent from generator passes", approval_criterion}
    ] + [approval_criterion]))
    pack["readiness"]["missing_requirements"] = [
        "three-video owned-channel performance checkpoint",
        "sampled human calibration before PRODUCTION_READY",
        "measured local energy/hardware/labor cost remains unavailable but external technical cost is R$ 0.00",
    ]
    pack["readiness"]["last_assessed_at"] = timestamp
    pack["readiness"]["assessed_by"] = "heroverse-autonomous-quality-assessor@1.0.0"
    report_id = report["evaluation_id"]
    if report_id not in pack["evidence"]["test_report_ids"]:
        pack["evidence"]["test_report_ids"].append(report_id)
    report_ref = _relative(root, report_path)
    if report_ref not in pack["evidence"]["source_refs"]:
        pack["evidence"]["source_refs"].append(report_ref)
    pack["learning_history"].append({
        "learning_id": f"format-learning-{report_id}",
        "status": "TESTING",
        "pack_version": pack["version"],
        "pipeline_version": "1.0.0",
        "tool_versions": ["heroverse-autonomous-quality-assessor@1.0.0", report["measurements"]["asr"]["provider"]],
        "video_id": "phase5-pilot-001-creative-v3.2",
        "evidence_refs": [report_ref],
        "result": "LIMITED canary authorization based on an independent automatic release evaluator, human-approved analysis gold standard, rejected negative control and twelve PASS gates. This is a production-capability limit, not audience-performance learning.",
        "created_at": timestamp,
    })
    _validate(root, "format_pack.schema.json", pack)

    overrides = [item for item in registry["format_pack_overrides"] if item["format_pack_id"] == pack["format_pack_id"]]
    if len(overrides) != 1 or registry["capability_counts"].get("PROTOTYPED") != 1:
        raise RuntimeError("Registry is not in the expected one-PROTOTYPED state")
    overrides[0]["capability_status"] = "LIMITED"
    registry["capability_counts"]["PROTOTYPED"] = 0
    registry["capability_counts"]["LIMITED"] = 1
    _write(pack_path, pack)
    _write(registry_path, registry)

    receipt = {
        "schema_version": "1.0.0",
        "transition_id": f"format-pack-autonomous-{report['artifact']['sha256'][:20]}",
        "format_pack_id": pack["format_pack_id"],
        "format_pack_version": pack["version"],
        "from_status": "PROTOTYPED",
        "to_status": "LIMITED",
        "basis": "AUTONOMOUS_QUALITY_PASS_WITH_HUMAN_GOLD_STANDARD_AND_CANARY_LIMIT",
        "quality_evaluation": _artifact(root, report_path),
        "before": before,
        "after": _artifact(root, pack_path),
        "registry": _artifact(root, registry_path),
        "limitation_contract": limitation,
        "rollback": {
            "archive_path": _relative(root, archive_path),
            "archive_sha256": _hash(archive_path),
            "instructions": "Restore only this archived FormatPack, restore registry PROTOTYPED=1/LIMITED=0, and preserve this receipt and all learning history as an incident record.",
        },
        "created_at": timestamp,
    }
    _validate(root, "format_pack_autonomous_transition_receipt.schema.json", receipt)
    path = root / TRANSITION
    _write(path, receipt)
    if refresh_package:
        from .publication_package_creative_v3_phase5 import materialize as materialize_publication_package

        materialize_publication_package(root)
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the autonomous Phase 5 quality evaluator")
    parser.add_argument("--apply-limited", action="store_true")
    parser.add_argument("--music-sample", type=Path)
    parser.add_argument("--expected-music-hash")
    parser.add_argument("--music-duration-ms", type=int)
    args = parser.parse_args()
    if args.music_sample is not None:
        if args.apply_limited or args.expected_music_hash is None or args.music_duration_ms is None:
            parser.error('music sample requires hash/duration and cannot apply a transition')
        print(json.dumps(measure_music_sample(args.music_sample,
            expected_media_hash=args.expected_music_hash,
            expected_duration_ms=args.music_duration_ms), ensure_ascii=False, indent=2))
        return
    if args.expected_music_hash is not None or args.music_duration_ms is not None:
        parser.error('music arguments require --music-sample')
    path = materialize(ROOT)
    if args.apply_limited:
        apply_limited_transition(ROOT)
    print(path)


if __name__ == "__main__":
    main()
