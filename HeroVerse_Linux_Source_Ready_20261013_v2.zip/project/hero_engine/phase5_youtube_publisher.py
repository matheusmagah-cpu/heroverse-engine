from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator

from .publisher import build_youtube_video_body
from .youtube_integration import INTEGRATION_SCOPES
from .atomic_io import atomic_write_utf8


ROOT = Path(__file__).resolve().parents[1]
V3 = Path("output/production/phase5/pilot-001/creative-v3")
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _execute_upload(request: Any) -> dict[str, Any]:
    response = None
    while response is None:
        _, response = request.next_chunk()
    return response


def _validate_release(root: Path, release: dict[str, Any]) -> None:
    Draft202012Validator(_read(root / "schemas/phase5_release_gate.schema.json")).validate(release)
    if release["decision"] != "READY_FOR_PUBLICATION_PIPELINE" or not release["publication_pipeline_permitted"]:
        raise PermissionError("Consolidated release gate is not READY_FOR_PUBLICATION_PIPELINE")
    instrumental=release['schema_version']=='1.2.0'
    required = {"channels.list", "videos.insert", "videos.list", "videos.update", "thumbnails.set"}
    if not instrumental:required.add('captions.insert')
    if set(release["authorized_api_methods"]) != required:
        raise PermissionError("Release receipt does not authorize the exact least-use API set")
    for name in ("video", "thumbnail", "captions", "publication_package", "autonomous_review", "format_transition", "oauth_readiness", "scope_requirement", "channel_audit", "zero_cost"):
        artifact = release["artifacts"][name]
        if instrumental and name=='captions':
            if artifact is not None:raise PermissionError('instrumental release cannot fabricate speech captions')
            continue
        if artifact is None:
            raise PermissionError(f"Required release artifact is absent: {name}")
        path = Path(artifact["path"])
        if not path.is_file() or _hash(path) != artifact["sha256"]:
            raise PermissionError(f"Release artifact changed or disappeared: {name}")
    human = release["artifacts"].get("human_review")
    if human is not None:
        path = Path(human["path"])
        if not path.is_file() or _hash(path) != human["sha256"]:
            raise PermissionError("Optional human audit artifact changed or disappeared")


def _validate_current_release(root, relative, bindings, expected_hash, *, observation_only=False):
    from .phase5_release_gate import build_release_gate
    root, relative = root.resolve(), Path(relative)
    directory = (root / relative).resolve()
    if (relative.is_absolute() or '..' in relative.parts
            or not directory.is_relative_to(root / 'output/production')):
        raise PermissionError('Current publication package must be confined to production')
    if not observation_only and (root / 'output/runtime/gestor-central/PAUSE').exists():
        raise PermissionError('Publication paused before effect')
    path = directory / 'release_gate.json'
    raw = path.read_bytes()
    if expected_hash != 'sha256:' + hashlib.sha256(raw).hexdigest():
        raise PermissionError('Current release external anchor differs')
    release = json.loads(raw.decode('utf-8-sig'))
    current = build_release_gate(root, package_relative=relative, current_bindings=bindings)
    if {k:v for k,v in current.items() if k != 'created_at'} != {
            k:v for k,v in release.items() if k != 'created_at'}:
        raise PermissionError('Current release no longer represents its native inputs')
    _validate_release(root, release)
    if _hash(path) != expected_hash.removeprefix('sha256:'):
        raise PermissionError('Current release changed during validation')
    return release


def _thumbnail_checkpoint_eligible(existing: dict[str, Any], *, explicit_current: bool) -> bool:
    """Authenticate the incident, without authorizing a replacement or expiry reset."""
    pending = set()
    for item in existing['steps']:
        if item['step'].endswith('_BEFORE') and item['status'] == 'NOT_RUN':
            pending.add(item['step'].removesuffix('_BEFORE'))
        elif item['status'] == 'PASS':
            pending.discard(item['step'])
    successful = {item['step']: item['evidence'] for item in existing['steps'] if item['status'] == 'PASS'}
    updated = datetime.fromisoformat(existing['updated_at'].replace('Z', '+00:00'))
    age = (datetime.now(timezone.utc) - updated).total_seconds() if updated.tzinfo else -1
    return bool(explicit_current and pending == {'THUMBNAIL_SET'}
        and existing['status'] == 'PARTIAL_PRIVATE_VIDEO'
        and existing['privacy_status'] == 'private' and existing['channel_id'] == CHANNEL_ID
        and successful.get('CHANNEL_IDENTITY') == CHANNEL_ID
        and existing['video_id'] and successful.get('VIDEO_PRIVATE_UPLOAD') == existing['video_id']
        and isinstance(existing.get('error'), str)
        and existing['error'].startswith('ConnectionAbortedError: [Errno 10053]')
        and sum(item['step'] == 'THUMBNAIL_SET_BEFORE' for item in existing['steps']) == 1
        and not any(item['step'].startswith('THUMBNAIL_RECOVERY') for item in existing['steps'])
        and age >= 0)


def _thumbnail_recovery_eligible(existing: dict[str, Any], *, explicit_current: bool) -> bool:
    """One pending idempotent replacement, never upload/captions/promotion."""
    from .phase6_publication import RECOVERY_WINDOW_SECONDS
    updated = datetime.fromisoformat(existing['updated_at'].replace('Z', '+00:00'))
    age = (datetime.now(timezone.utc) - updated).total_seconds() if updated.tzinfo else -1
    return (_thumbnail_checkpoint_eligible(existing, explicit_current=explicit_current)
            and 0 <= age <= RECOVERY_WINDOW_SECONDS)


def reconcile_private_thumbnail(youtube, root: Path, *, package_relative: Path,
        current_bindings: dict, expected_release_hash: str, expected_receipt_hash: str,
        observed_public: bool = False) -> dict:
    """Read the remote outcome; NEVER redispatch thumbnails.set or publish.

    A lost response can be observed after the replacement window expires. This
    does not extend that window: only an actually matching remote thumbnail can
    close this exact pending effect. Preserve the original bytes before replacing
    the active receipt. All other ambiguous effects remain closed.
    """
    import io
    from PIL import Image
    from urllib.parse import urlsplit
    from .phase6_publication import PublicationLock, _fetch_public_thumbnail, _thumbnail_similarity
    root = root.resolve()
    with PublicationLock(root):
        release = _validate_current_release(root, package_relative, current_bindings,
            expected_release_hash, observation_only=True)
        directory = (root / package_relative).resolve()
        path = directory / 'youtube-publication-receipt.json'
        raw = path.read_bytes()
        if expected_receipt_hash != 'sha256:' + hashlib.sha256(raw).hexdigest():
            raise PermissionError('Thumbnail observation receipt external anchor differs')
        receipt = json.loads(raw.decode('utf-8-sig'))
        Draft202012Validator(_read(root / 'schemas/youtube_publication_receipt.schema.json')).validate(receipt)
        hashes = {name: release['artifacts'][name]['sha256'] if release['artifacts'][name] else None
                  for name in ('video', 'thumbnail', 'captions')}
        if (not _thumbnail_checkpoint_eligible(receipt, explicit_current=True)
                or receipt['release_id'] != release['release_id']
                or receipt['idempotency_key'] != release['idempotency_key']
                or receipt['artifact_hashes'] != hashes):
            raise PermissionError('No exact unresolved private thumbnail for observation')
        owned = youtube.channels().list(part='id', mine=True, fields='items(id)').execute().get('items') or []
        if len(owned) != 1 or owned[0].get('id') != CHANNEL_ID:
            raise PermissionError('Thumbnail observation owned channel differs')
        response = youtube.videos().list(part='id,status,snippet', id=receipt['video_id'],
            fields='items(id,snippet/channelId,snippet/thumbnails,status/privacyStatus,status/uploadStatus)').execute()
        items = response.get('items') or []
        if (len(items) != 1 or items[0].get('id') != receipt['video_id']
                or items[0].get('snippet', {}).get('channelId') != CHANNEL_ID
                or items[0].get('status', {}).get('privacyStatus') != ('public' if observed_public else 'private')
                or items[0].get('status', {}).get('uploadStatus') != 'processed'):
            raise PermissionError('Thumbnail observation requires exact processed ' + ('public' if observed_public else 'private') + ' video')
        variants = items[0]['snippet'].get('thumbnails') or {}
        url = next(((variants.get(name) or {}).get('url') for name in
            ('maxres', 'standard', 'high', 'medium', 'default') if (variants.get(name) or {}).get('url')), None)
        if (not isinstance(url, str) or urlsplit(url).scheme != 'https'
                # The authenticated owned-video response uses i9 for private
                # thumbnails. Accept this observed exact CDN, never a suffix
                # wildcard or a caller-provided URL outside the owned response.
                or urlsplit(url).hostname not in {'i.ytimg.com', 'i9.ytimg.com', 'img.youtube.com'}):
            raise PermissionError('Thumbnail observation has no trusted provider image URL')
        payload = _fetch_public_thumbnail(url)
        with Image.open(io.BytesIO(payload)) as remote, Image.open(release['artifacts']['thumbnail']['path']) as local:
            similarity = _thumbnail_similarity(remote, local)
        # Reuse the resident thumbnail verification tolerance; no new quality
        # proxy and no claim that similarity itself proves editorial quality.
        if similarity < 0.75:
            raise PermissionError('Remote thumbnail does not match the frozen thumbnail')
        _validate_current_release(root, package_relative, current_bindings,
            expected_release_hash, observation_only=True)
        if path.read_bytes() != raw:
            raise PermissionError('Thumbnail observation receipt changed before reconciliation')
        evidence = {'observed_at': _now(), 'receipt_before_sha256': expected_receipt_hash,
            'video_response': response, 'channel_response': owned,
            'remote_bytes_sha256': 'sha256:' + hashlib.sha256(payload).hexdigest(),
            'thumbnail_sha256': hashes['thumbnail'], 'similarity': similarity,
            'provider_mutations': 0, 'publication_performed': False}
        archive = directory / 'publication-reconciliation' / expected_receipt_hash.removeprefix('sha256:')
        archive.mkdir(parents=True, exist_ok=True)
        for target, content in ((archive/'receipt-before.json', raw),
                (archive/'remote-thumbnail.bin', payload),
                (archive/'observation.json', (json.dumps(evidence, ensure_ascii=False, sort_keys=True, indent=2)+'\n').encode('utf-8'))):
            if target.exists():
                if target.read_bytes() != content:
                    raise PermissionError('Thumbnail observation archive collision')
            else:
                with target.open('xb') as stream:
                    stream.write(content); stream.flush(); os.fsync(stream.fileno())
        receipt['steps'].append({'step':'THUMBNAIL_SET', 'status':'PASS',
            'evidence':'Observed remote frozen thumbnail; ' + str(archive/'observation.json')
                + ';sha256:' + _hash(archive/'observation.json')})
        if observed_public:
            # This is an observation, NOT a recovered videos.update response.
            # Captions and final live verification remain outstanding.
            receipt['steps'].append({'step':'PUBLIC_VISIBILITY_OBSERVED', 'status':'PASS',
                'evidence':str(archive/'observation.json') + ';sha256:' + _hash(archive/'observation.json')})
            receipt['status'] = 'PUBLIC_AWAITING_VERIFICATION'
            receipt['privacy_status'] = 'public'
        receipt['error'] = None
        receipt['updated_at'] = evidence['observed_at']
        Draft202012Validator(_read(root / 'schemas/youtube_publication_receipt.schema.json')).validate(receipt)
        if path.read_bytes() != raw:
            raise PermissionError('Thumbnail observation receipt changed before atomic replace')
        atomic_write_utf8(path, json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
        return receipt


def read_contained_thumbnail_checkpoint(root: Path, receipt_path: Path) -> dict[str, Any]:
    """Authenticate stopped incident custody; grants NO remote effect.

    This is custody for local maintenance, not reconciliation of the lost API
    response or a claim that the thumbnail succeeded. Normal release/PAUSE
    validation and fresh private-video identity still precede any recovery.
    Mutable OAuth readiness is not an input to this historical upload custody;
    the normal executor must authenticate it anew before its next effect.
    """
    root = root.resolve(strict=True)
    path = receipt_path.resolve(strict=True)
    if (path.name != 'youtube-publication-receipt.json'
            or not path.is_relative_to(root / 'output/production')
            or any('archive' in part.lower() or 'history' in part.lower()
                   for part in path.relative_to(root).parts[:-1])):
        raise PermissionError('Thumbnail custody is not an active production checkpoint')
    directory = path.parent
    captured = {target: target.read_bytes() for target in (
        path, directory / 'release_gate.json', directory / 'publication_package.json')}
    existing, release, package = (json.loads(raw.decode('utf-8-sig')) for raw in captured.values())
    for name, value in (('youtube_publication_receipt.schema.json', existing),
                        ('phase5_release_gate.schema.json', release),
                        ('publication_package.schema.json', package)):
        Draft202012Validator(_read(root / 'schemas' / name)).validate(value)
    # The native observation can legitimately advance a private checkpoint to
    # public without completing captions/final verification. Maintenance must
    # preserve this pending receipt, not call it terminal or retry a mutation.
    pending = set()
    for step in existing['steps']:
        if step['step'].endswith('_BEFORE') and step['status'] == 'NOT_RUN':
            pending.add(step['step'].removesuffix('_BEFORE'))
        elif step['status'] == 'PASS':
            pending.discard(step['step'])
    observed_public = (existing['status'] == 'PUBLIC_AWAITING_VERIFICATION'
        and existing['privacy_status'] == 'public' and existing['channel_id'] == CHANNEL_ID
        and not pending and _verified_observed_public(directory, existing, release))
    if (release['schema_version'] not in {'1.2.0', '1.3.0'}
            or package['schema_version'] not in {'1.1.0', '1.2.0'}
            or release['decision'] != 'READY_FOR_PUBLICATION_PIPELINE'
            or release['publication_pipeline_permitted'] is not True
            or release['blockers'] or any(row['status'] != 'PASS' for row in release['gates'])
            or not (_thumbnail_checkpoint_eligible(existing, explicit_current=True) or observed_public)):
        raise PermissionError('No bounded current private thumbnail custody')
    package_identity = 'instrumental-publication-' + hashlib.sha256(json.dumps(
        [package['music_bindings'], package['music_qualification_bindings']], sort_keys=True).encode()).hexdigest()[:24]
    identity = hashlib.sha256(f"{CHANNEL_ID}|{package['video']['sha256']}|{package_identity}".encode()).hexdigest()
    hashes = {name: (release['artifacts'][name]['sha256'] if release['artifacts'][name] else None)
              for name in ('video', 'thumbnail', 'captions')}
    if (package['package_id'] != package_identity or release['package_id'] != package_identity
            or release['channel_id'] != CHANNEL_ID or package['channel']['channel_id'] != CHANNEL_ID
            or release['idempotency_key'] != identity or release['release_id'] != 'phase5-release-' + identity[:20]
            or existing['idempotency_key'] != identity or existing['release_id'] != release['release_id']
            or existing['receipt_id'] != 'youtube-publication-' + identity[:20]
            or Path(release['artifacts']['publication_package']['path']).resolve(strict=True) != directory / 'publication_package.json'
            or release['artifacts']['publication_package']['sha256'] != hashlib.sha256(captured[directory / 'publication_package.json']).hexdigest()
            or existing['artifact_hashes'] != hashes):
        raise PermissionError('Private thumbnail custody identity diverged')
    files = {}
    for name in ('video', 'thumbnail', 'captions'):
        artifact = release['artifacts'][name]
        if artifact is None:
            if (name != 'captions' or package.get(name) is not None
                    or package.get('captions_applicability') != 'NOT_APPLICABLE_INSTRUMENTAL_NO_SPEECH'):
                raise PermissionError('Unexpected private custody artifact')
            continue
        target = Path(artifact['path']).resolve(strict=True)
        if (not target.is_relative_to(directory) or Path(package[name]['path']).resolve(strict=True) != target
                or package[name]['sha256'] != artifact['sha256'] or _hash(target) != artifact['sha256']):
            raise PermissionError('Private thumbnail custody artifact changed')
        files[target] = artifact['sha256']
    for ref in list(package['music_bindings'].values()) + list(package['music_qualification_bindings'].values()):
        target = Path(ref['path']).resolve(strict=True)
        if not target.is_relative_to(root) or 'sha256:' + _hash(target) != ref['sha256']:
            raise PermissionError('Private thumbnail custody provenance changed')
        files[target] = ref['sha256'].removeprefix('sha256:')
    if (any(target.read_bytes() != raw for target, raw in captured.items())
            or any(_hash(target) != expected for target, expected in files.items())
            or (observed_public and not _verified_observed_public(directory, existing, release))):
        raise PermissionError('Private thumbnail custody changed during capture')
    return {'purpose': ('CONTAINED_OBSERVED_PUBLIC_FOR_LOCAL_MAINTENANCE_ONLY' if observed_public
                        else 'CONTAINED_PRIVATE_THUMBNAIL_FOR_LOCAL_MAINTENANCE_ONLY'),
        'receipt_sha256': 'sha256:' + hashlib.sha256(captured[path]).hexdigest(),
        'release_sha256': 'sha256:' + hashlib.sha256(captured[directory / 'release_gate.json']).hexdigest(),
        'package_sha256': 'sha256:' + hashlib.sha256(captured[directory / 'publication_package.json']).hexdigest(),
        'video_id': existing['video_id'], 'channel_id': CHANNEL_ID,
        'artifact_hashes': hashes, 'remote_thumbnail_outcome': ('OBSERVED' if observed_public else 'UNKNOWN'),
        'remote_recovery_authorized': False, 'upload_authorized': False, 'publication_authorized': False}


def _verified_observed_public(directory: Path, receipt: dict, release: dict) -> bool:
    """Reopen the native read-only archive; never infer an unrecorded mutation."""
    rows = [s for s in receipt['steps'] if s['step'] == 'PUBLIC_VISIBILITY_OBSERVED']
    if not rows:
        return False
    if len(rows) != 1 or rows[0]['status'] != 'PASS':
        raise PermissionError('Observed public evidence is incomplete')
    try:
        path_text, digest = rows[0]['evidence'].rsplit(';sha256:', 1)
        path = Path(path_text).resolve(strict=True)
        archive = path.parent
        if path.name != 'observation.json' or archive.parent != (directory/'publication-reconciliation').resolve():
            raise ValueError('archive origin')
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError('observation hash')
        evidence = json.loads(raw)
        before_raw = (archive/'receipt-before.json').read_bytes()
        before = json.loads(before_raw)
        prior_hash = 'sha256:' + hashlib.sha256(before_raw).hexdigest()
        items = evidence['video_response'].get('items') or []
        thumbnail_steps = [s for s in receipt['steps'] if s['step']=='THUMBNAIL_SET' and s['status']=='PASS']
        if (archive.name != prior_hash.removeprefix('sha256:')
                or evidence['receipt_before_sha256'] != prior_hash
                or not _thumbnail_checkpoint_eligible(before, explicit_current=True)
                or any(before[k] != receipt[k] for k in ('video_id','channel_id','release_id','idempotency_key','artifact_hashes'))
                or before['release_id'] != release['release_id']
                or evidence['provider_mutations'] != 0 or evidence['publication_performed'] is not False
                or evidence['channel_response'] != [{'id': CHANNEL_ID}]
                or len(items) != 1 or items[0].get('id') != receipt['video_id']
                or items[0].get('snippet',{}).get('channelId') != CHANNEL_ID
                or items[0].get('status',{}).get('privacyStatus') != 'public'
                or items[0].get('status',{}).get('uploadStatus') != 'processed'
                or receipt['privacy_status'] != 'public'
                or receipt['status'] not in ('PUBLIC_AWAITING_VERIFICATION','COMPLETE_PUBLIC')
                or len(thumbnail_steps) != 1 or rows[0]['evidence'] not in thumbnail_steps[0]['evidence']
                or evidence['thumbnail_sha256'] != receipt['artifact_hashes']['thumbnail']
                or evidence['remote_bytes_sha256'] != 'sha256:' + _hash(archive/'remote-thumbnail.bin')
                or evidence['similarity'] < 0.75):
            raise ValueError('archive bindings')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise PermissionError('Observed public evidence differs; no dispatch') from exc
    return True


def _verify_completed_publication_receipt(root: Path, directory: Path, receipt: dict, release: dict) -> dict:
    """Read the canonical terminal chain, retaining its earlier incident log.

    No provider/lock/write occurs here. Local custody and the publisher share
    exactly the same receipt authority; historical FAILURE rows are not erased.
    """
    Draft202012Validator(_read(root / 'schemas/youtube_publication_receipt.schema.json')).validate(receipt)
    hashes = {name: (release['artifacts'][name]['sha256'] if release['artifacts'][name] is not None else None)
              for name in ('video', 'thumbnail', 'captions')}
    if (receipt['status'] != 'COMPLETE_PUBLIC' or receipt['idempotency_key'] != release['idempotency_key']
            or receipt['release_id'] != release['release_id'] or receipt['artifact_hashes'] != hashes):
        raise PermissionError('Terminal publication differs from its exact release')
    pending = set()
    for item in receipt['steps']:
        if item['step'].endswith('_BEFORE') and item['status'] == 'NOT_RUN':
            pending.add(item['step'].removesuffix('_BEFORE'))
        elif item['status'] == 'PASS':
            pending.discard(item['step'])
    if pending:
        raise PermissionError('Terminal publication contains unresolved effects')
    observed_public = _verified_observed_public(directory, receipt, release)
    successful = {item['step']:item['evidence'] for item in receipt['steps'] if item['status']=='PASS'}
    required = {'CHANNEL_IDENTITY','VIDEO_PRIVATE_UPLOAD','THUMBNAIL_SET',
                'PRIVATE_POST_UPLOAD_VERIFY','PROMOTE_PUBLIC','PUBLIC_POST_UPLOAD_VERIFY'}
    if observed_public:
        required -= {'PRIVATE_POST_UPLOAD_VERIFY', 'PROMOTE_PUBLIC'}
        required |= {'PUBLIC_VISIBILITY_OBSERVED', 'POST_UPLOAD_IDENTITY_VERIFY'}
    instrumental = release['schema_version'] == '1.2.0'
    if not instrumental:
        required.add('CAPTIONS_INSERT')
    caption_valid = (receipt['caption_id'] is None and receipt.get('captions_applicability') == 'NOT_APPLICABLE_INSTRUMENTAL_NO_SPEECH'
                     if instrumental else bool(receipt['caption_id'] and successful.get('CAPTIONS_INSERT') == receipt['caption_id']))
    if (not required.issubset(successful) or not receipt['video_id'] or not caption_valid
            or receipt['privacy_status'] != 'public' or successful['CHANNEL_IDENTITY'] != CHANNEL_ID
            or successful['VIDEO_PRIVATE_UPLOAD'] != receipt['video_id']):
        raise PermissionError('Terminal publication receipt lacks its confirmed effect chain')
    return receipt


def execute_publication_pipeline(
    youtube: Any,
    media_factory: Callable[..., Any],
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None,
    expected_release_hash: str | None = None,
) -> dict[str, Any]:
    if package_relative is not None:
        from .phase6_publication import PublicationLock
        root = root.resolve()
        if (root / 'output/runtime/gestor-central/PAUSE').exists():
            raise PermissionError('Publication is paused; no provider access performed')
        # Reuse the resident OS transaction lock, rather than adding an audio
        # executor/lock framework. All current publication mutations serialize.
        with PublicationLock(root):
            return _execute_publication_pipeline_locked(youtube, media_factory, root,
                created_at=created_at, package_relative=package_relative,
                current_bindings=current_bindings, expected_release_hash=expected_release_hash)
    if current_bindings is not None or expected_release_hash is not None:
        raise PermissionError('Current audio bindings require an explicit package')
    return _execute_publication_pipeline_locked(youtube, media_factory, root, created_at=created_at)


def _execute_publication_pipeline_locked(
    youtube: Any, media_factory: Callable[..., Any], root: Path, *,
    created_at: str | None = None, package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None, expected_release_hash: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    relative = V3 if package_relative is None else Path(package_relative)
    directory = (root / relative).resolve()
    if package_relative is not None and (relative.is_absolute() or '..' in relative.parts
            or not directory.is_relative_to(root / 'output/production')):
        raise PermissionError('Current publication package must be confined to production')
    release_path = directory / "release_gate.json"
    package_path = directory / "publication_package.json"
    receipt_path = directory / "youtube-publication-receipt.json"
    bindings = json.loads(json.dumps(current_bindings)) if current_bindings is not None else None
    release = _read(release_path)
    def revalidate() -> None:
        if package_relative is not None:
            current = _validate_current_release(root, relative, bindings, expected_release_hash)
            if current != release:
                raise PermissionError('Current release changed after invocation capture')
        else:
            _validate_release(root, release)
    revalidate()
    package = _read(package_path)
    existing = _read(receipt_path) if receipt_path.is_file() else None
    instrumental=release['schema_version']=='1.2.0'
    hashes = {name: (release['artifacts'][name]['sha256'] if release['artifacts'][name] is not None else None)
        for name in ('video','thumbnail','captions')}
    recover_thumbnail = False
    observed_public = False
    if existing:
        Draft202012Validator(_read(root / 'schemas/youtube_publication_receipt.schema.json')).validate(existing)
        if (existing['idempotency_key'] != release['idempotency_key']
                or existing['release_id'] != release['release_id']
                or existing['artifact_hashes'] != hashes):
            raise PermissionError('Publication receipt differs from this exact release; duplicate blocked')
        pending = set()
        for item in existing['steps']:
            if item['step'].endswith('_BEFORE') and item['status'] == 'NOT_RUN':
                pending.add(item['step'].removesuffix('_BEFORE'))
            elif item['status'] == 'PASS':
                pending.discard(item['step'])
        if pending:
            # Only this replacement is idempotent: same frozen bytes on the
            # already-confirmed private video. Upload/captions/public promotion
            # remain ambiguous and must never inherit this recovery permission.
            recover_thumbnail = _thumbnail_recovery_eligible(existing, explicit_current=package_relative is not None)
            if not recover_thumbnail:
                raise PermissionError('Unresolved publication effect; recover existing response before any dispatch: '
                                      + ','.join(sorted(pending)))
        if package_relative is None and any(s['step']=='PUBLIC_VISIBILITY_OBSERVED' for s in existing['steps']):
            raise PermissionError('Observed public reconciliation requires explicit current bindings')
        observed_public = _verified_observed_public(directory, existing, release)
        if existing['status'] == 'COMPLETE_PUBLIC':
            _verify_completed_publication_receipt(root, directory, existing, release)
    if existing and existing["status"] == "COMPLETE_PUBLIC":
        return existing
    timestamp = existing['created_at'] if existing else created_at or _now()
    video_id: str | None = existing.get("video_id") if existing else None
    caption_id: str | None = existing.get("caption_id") if existing else None
    steps: list[dict[str, str]] = list(existing.get("steps") or []) if existing else []
    def persist(status='IN_PROGRESS', error=None):
        if observed_public and status != 'COMPLETE_PUBLIC':
            status = 'PUBLIC_AWAITING_VERIFICATION'
        receipt = {
            'schema_version':'1.4.0' if instrumental else '1.0.0','receipt_id':f"youtube-publication-{release['idempotency_key'][:20]}",
            'release_id':release['release_id'],'idempotency_key':release['idempotency_key'],'channel_id':CHANNEL_ID,
            'status':status,'privacy_status':'public' if status in ('COMPLETE_PUBLIC','PUBLIC_AWAITING_VERIFICATION') else 'private',
            'video_id':video_id,'caption_id':caption_id,'steps':steps,'artifact_hashes':hashes,
            'external_cost_brl':0,'public_visibility_authorized':True,'error':error,
            'created_at':timestamp,'updated_at':_now(),
        }
        if instrumental:receipt['captions_applicability']='NOT_APPLICABLE_INSTRUMENTAL_NO_SPEECH'
        Draft202012Validator(_read(root/'schemas/youtube_publication_receipt.schema.json')).validate(receipt)
        atomic_write_utf8(receipt_path,json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
        return receipt
    def before_effect(name):
        revalidate()
        if observed_public:
            live = youtube.videos().list(part='id,status,snippet', id=video_id,
                fields='items(id,snippet/channelId,status/privacyStatus,status/uploadStatus)').execute().get('items') or []
            if (len(live) != 1 or live[0].get('id') != video_id
                    or live[0].get('snippet',{}).get('channelId') != CHANNEL_ID
                    or live[0].get('status',{}).get('privacyStatus') != 'public'
                    or live[0].get('status',{}).get('uploadStatus') != 'processed'):
                raise PermissionError('Observed public live identity changed before remaining effects')
        steps.append({'step':name+'_BEFORE','status':'NOT_RUN',
                      'evidence':'Durably recorded before provider effect; never blindly redispatch'})
        persist()
    try:
        revalidate()
        owned = youtube.channels().list(part="id,snippet", mine=True, fields="items(id,snippet/customUrl)").execute().get("items") or []
        observed = owned[0]["id"] if len(owned) == 1 else None
        if observed != CHANNEL_ID:
            raise PermissionError(f"Owned channel mismatch: expected {CHANNEL_ID}, observed {observed}")
        steps.append({"step": "CHANNEL_IDENTITY", "status": "PASS", "evidence": observed})
        persist()
        metadata = package["metadata"]
        if video_id is None:
            body = build_youtube_video_body({
                "title": metadata["title"], "description": metadata["description"], "tags": metadata["tags"],
                "category_id": metadata["category_id"], "language": metadata["default_language"],
                "audio_language": metadata["default_audio_language"], "privacy_status": "private",
                "made_for_kids": metadata["made_for_kids"], "contains_synthetic_media": package["disclosure"]["contains_synthetic_media"],
            })
            before_effect('VIDEO_PRIVATE_UPLOAD')
            response = _execute_upload(youtube.videos().insert(part="snippet,status", body=body, notifySubscribers=False, media_body=media_factory(package["video"]["path"], chunksize=-1, resumable=True)))
            video_id = response["id"]
            steps.append({"step": "VIDEO_PRIVATE_UPLOAD", "status": "PASS", "evidence": video_id})
            persist()
        completed_steps = {step["step"] for step in steps if step["status"] == "PASS"}
        if "THUMBNAIL_SET" not in completed_steps:
            if recover_thumbnail:
                revalidate()
                observed_video = youtube.videos().list(part='id,status,snippet', id=video_id,
                    fields='items(id,snippet/channelId,status/privacyStatus,status/uploadStatus)').execute().get('items') or []
                if (len(observed_video) != 1 or observed_video[0].get('id') != video_id
                        or observed_video[0].get('snippet', {}).get('channelId') != CHANNEL_ID
                        or observed_video[0].get('status', {}).get('privacyStatus') != 'private'
                        or observed_video[0].get('status', {}).get('uploadStatus') != 'processed'):
                    raise PermissionError('Thumbnail recovery requires exact processed private video identity')
                steps.append({'step':'THUMBNAIL_RECOVERY_IDENTITY','status':'PASS',
                    'evidence':f'videoId={video_id};channelId={CHANNEL_ID};privacy=private;thumbnail_sha256={hashes["thumbnail"]}'})
                # Persist before the sole recovery attempt. A lost response here
                # blocks another recovery; it never becomes an automatic loop.
                before_effect('THUMBNAIL_RECOVERY')
            else:
                before_effect('THUMBNAIL_SET')
            mime = 'image/png' if package_relative is not None else 'image/jpeg'
            thumbnail_response = youtube.thumbnails().set(videoId=video_id, media_body=media_factory(release["artifacts"]["thumbnail"]["path"], mimetype=mime, resumable=False)).execute()
            if recover_thumbnail:
                variants = ('maxres','standard','high','medium','default')
                items = thumbnail_response.get('items') if isinstance(thumbnail_response, dict) else None
                if (not isinstance(items, list) or not items or not any(
                        isinstance(item, dict) and isinstance(item.get(name), dict)
                        and isinstance(item[name].get('url'), str) and item[name]['url']
                        for item in items for name in variants)):
                    raise RuntimeError('thumbnails.set recovery returned no confirmed thumbnail resource')
                steps.append({'step':'THUMBNAIL_RECOVERY','status':'PASS',
                    'evidence':f'Confirmed exact frozen replacement;videoId={video_id};thumbnail_sha256={hashes["thumbnail"]}'})
            steps.append({"step": "THUMBNAIL_SET", "status": "PASS", "evidence": release["selected_thumbnail"]})
            persist()
        if caption_id is None and not instrumental:
            before_effect('CAPTIONS_INSERT')
            caption_response = youtube.captions().insert(part="snippet", body={"snippet": {"videoId": video_id, "language": package["captions"]["language"], "name": "English", "isDraft": False}}, media_body=media_factory(package["captions"]["path"], mimetype="application/octet-stream", resumable=False)).execute()
            caption_id = caption_response["id"]
            steps.append({"step": "CAPTIONS_INSERT", "status": "PASS", "evidence": caption_id})
            persist()
        revalidate()
        verify = youtube.videos().list(part="id,status,snippet", id=video_id, fields="items(id,snippet/channelId,status/privacyStatus,status/uploadStatus)").execute().get("items") or []
        already_promoted = 'PROMOTE_PUBLIC' in completed_steps or observed_public
        verified = len(verify) == 1 and verify[0]["id"] == video_id and verify[0]["snippet"]["channelId"] == CHANNEL_ID and verify[0]["status"]["privacyStatus"] == ('public' if already_promoted else 'private')
        if not verified:
            raise RuntimeError("Uploaded video could not be verified as private on the pinned channel")
        steps.append({"step": "POST_UPLOAD_IDENTITY_VERIFY" if observed_public else "PRIVATE_POST_UPLOAD_VERIFY", "status": "PASS", "evidence": f"videoId={video_id};privacy={'public' if observed_public else 'private'};channelId={CHANNEL_ID}"})
        if verify[0]["status"].get("uploadStatus") != "processed":
            status = "STAGED_PRIVATE_AWAITING_PROCESSING"
            error = None
        else:
            public_status = {
                "privacyStatus": "public",
                "selfDeclaredMadeForKids": metadata["made_for_kids"],
                "containsSyntheticMedia": package["disclosure"]["contains_synthetic_media"],
                "embeddable": True,
                "publicStatsViewable": True,
                "license": "youtube",
            }
            if not already_promoted:
                before_effect('PROMOTE_PUBLIC')
                youtube.videos().update(part="status", body={"id": video_id, "status": public_status}).execute()
                steps.append({"step": "PROMOTE_PUBLIC", "status": "PASS", "evidence": "videos.update(status.privacyStatus=public)"})
                persist('PUBLIC_AWAITING_VERIFICATION')
            revalidate()
            final = youtube.videos().list(part="id,status,snippet", id=video_id, fields="items(id,snippet/channelId,status/privacyStatus,status/uploadStatus)").execute().get("items") or []
            public_ok = len(final) == 1 and final[0]['id'] == video_id and final[0]["snippet"]["channelId"] == CHANNEL_ID and final[0]["status"]["privacyStatus"] == "public" and final[0]["status"].get("uploadStatus") == "processed"
            if not public_ok:
                raise RuntimeError("Final public state could not be verified on the pinned channel")
            steps.append({"step": "PUBLIC_POST_UPLOAD_VERIFY", "status": "PASS", "evidence": f"videoId={video_id};privacy=public;processed=true;channelId={CHANNEL_ID}"})
            status = "COMPLETE_PUBLIC"
            error = None
    except Exception as exc:
        steps.append({"step": "FAILURE", "status": "FAIL", "evidence": f"{type(exc).__name__}: {exc}"})
        status = 'PUBLIC_AWAITING_VERIFICATION' if any(s['step']=='PROMOTE_PUBLIC' and s['status']=='PASS' for s in steps) else "PARTIAL_PRIVATE_VIDEO" if video_id else "FAILED_PRE_UPLOAD"
        error = f"{type(exc).__name__}: {exc}"
    receipt = persist(status, error)
    if error:
        raise RuntimeError(error)
    return receipt


def _build_live_service(token_path: Path) -> tuple[Any, Callable[..., Any]]:
    from google.oauth2.credentials import Credentials  # type: ignore
    from googleapiclient.discovery import build  # type: ignore
    from googleapiclient.http import MediaFileUpload  # type: ignore
    if not token_path.is_file():
        raise FileNotFoundError("A pre-authorized token outside the workspace is required; this command never launches an interactive grant")
    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("The production token is invalid/expired; refresh must be proven by the integration gate before upload")
    return build("youtube", "v3", credentials=credentials), MediaFileUpload


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Stage the exact Phase 5 release privately, verify it, then publish it")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument('--reconcile-thumbnail', action='store_true')
    parser.add_argument('--observe-public', action='store_true')
    parser.add_argument('--expected-receipt-hash')
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--package-relative', type=Path)
    parser.add_argument('--current-bindings', type=Path)
    parser.add_argument('--expected-bindings-hash')
    parser.add_argument('--expected-release-hash')
    args = parser.parse_args(argv)
    if args.execute and args.reconcile_thumbnail:
        raise PermissionError('Observation and publication must be separate invocations')
    if args.observe_public and not args.reconcile_thumbnail:
        raise PermissionError('Public observation only qualifies the read-only thumbnail reconciliation')
    if not args.execute and not args.reconcile_thumbnail:
        raise SystemExit("No side effect performed. Pass --execute only after release_gate.json is READY.")
    root = args.root.resolve()
    bindings = None
    if args.package_relative is not None:
        if args.current_bindings is None or args.expected_bindings_hash is None:
            raise PermissionError('Explicit audio publication requires externally anchored current bindings')
        binding_path = (root / args.current_bindings).resolve()
        if not binding_path.is_relative_to(root):
            raise PermissionError('Current bindings must belong to this root')
        raw = binding_path.read_bytes()
        if args.expected_bindings_hash != 'sha256:' + hashlib.sha256(raw).hexdigest():
            raise PermissionError('Current publication bindings external anchor differs')
        bindings = json.loads(raw.decode('utf-8-sig'))
        # Fail before credentials/discovery/provider access, not just upload.
        _validate_current_release(root, args.package_relative, bindings, args.expected_release_hash,
            **({'observation_only': True} if args.reconcile_thumbnail else {}))
    elif any((args.current_bindings, args.expected_bindings_hash, args.expected_release_hash)):
        raise PermissionError('Current publication bindings require an explicit package')
    if args.reconcile_thumbnail and (args.package_relative is None or args.expected_receipt_hash is None):
        raise PermissionError('Thumbnail observation requires current package and external receipt anchor')
    if args.expected_receipt_hash is not None and not args.reconcile_thumbnail:
        raise PermissionError('Receipt observation anchor does not authorize publication')
    token = os.environ.get("HERO_YT_TOKEN_PATH")
    if not token:
        raise SystemExit("HERO_YT_TOKEN_PATH is required and must point outside the workspace")
    youtube, media_factory = _build_live_service(Path(token))
    if args.reconcile_thumbnail:
        print(json.dumps(reconcile_private_thumbnail(youtube, root,
            package_relative=args.package_relative, current_bindings=bindings,
            expected_release_hash=args.expected_release_hash,
            expected_receipt_hash=args.expected_receipt_hash,
            observed_public=args.observe_public), ensure_ascii=False, indent=2))
        return
    print(json.dumps(execute_publication_pipeline(youtube, media_factory, root,
        package_relative=args.package_relative, current_bindings=bindings,
        expected_release_hash=args.expected_release_hash), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
