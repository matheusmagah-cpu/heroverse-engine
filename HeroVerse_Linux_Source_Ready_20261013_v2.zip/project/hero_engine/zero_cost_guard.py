from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def evaluate_zero_cost(
    root: Path = ROOT,
    *,
    operation: str = "phase5_publication_pipeline",
    observed_usage: dict[str, int] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    policy = _read(root / "config/zero-cost-policy.json")
    usage = observed_usage or {}
    reservations = {
        "local-production-stack": 0,
        "youtube-videos-insert-daily": 1 if operation in {"phase5_private_upload", "phase5_publication_pipeline", "phase6_video2_publication_pipeline"} else 0,
        "youtube-general-units-daily": 513 if operation in {"phase5_publication_pipeline", "phase6_video2_publication_pipeline"} else (452 if operation == "phase5_private_upload" else (100 if operation == "phase6_canary_package_update" else (2 if operation in {"phase6_owned_metrics_checkpoint", "phase6_prediction_outcome_checkpoint", "phase6_treatment_metrics_checkpoint"} else (1 if operation == "phase6_goal_channel_checkpoint" else 0)))),
        "optional-session-image-generation": 0,
        "vidiq-renewable-free-credits": 0,
    }
    floors = {
        "youtube-videos-insert-daily": 1,
        "youtube-general-units-daily": 12 if operation in {"phase6_owned_metrics_checkpoint", "phase6_prediction_outcome_checkpoint", "phase6_treatment_metrics_checkpoint", "phase6_goal_channel_checkpoint"} else reservations["youtube-general-units-daily"],
        "vidiq-renewable-free-credits": 0 if operation in {"phase6_video2_publication_pipeline", "phase6_canary_package_update", "phase6_owned_metrics_checkpoint", "phase6_prediction_outcome_checkpoint", "phase6_treatment_metrics_checkpoint", "phase6_goal_channel_checkpoint"} else 25,
    }
    rows: list[dict[str, Any]] = []
    blockers: list[str] = []
    quota_relevant = False
    unknown = False
    insufficient = False
    for resource in policy["resources"]:
        resource_id = resource["resource_id"]
        limit = resource["quota_limit"]
        reserved = reservations.get(resource_id, 0)
        consumed = usage.get(resource_id)
        floor = floors.get(resource_id, 0)
        if limit is not None and (reserved or floor):
            quota_relevant = True
            if consumed is None:
                unknown = True
                blockers.append(f"QUOTA_USAGE_UNAVAILABLE:{resource_id}")
            elif limit - consumed - reserved < floor:
                insufficient = True
                blockers.append(f"FREE_QUOTA_PREVENTIVE_FLOOR:{resource_id}")
        rows.append({
            "resource_id": resource_id,
            "cost_brl": resource["cost_brl"],
            "billing_required": resource["billing_required"],
            "quota_limit": limit,
            "quota_consumed": consumed,
            "quota_reserved": reserved,
            "preventive_floor": floor,
            "renewal": resource["renewal"],
            "fallback": resource["fallback"],
            "quality_status": resource["quality_status"],
            "evidence": resource["evidence"],
        })
    cost_pass = policy["technical_cost_brl"] == 0 and all(row["cost_brl"] == 0 and not row["billing_required"] for row in rows)
    if not cost_pass:
        blockers.append("TECHNICAL_COST_NOT_ZERO")
    if insufficient:
        quota_status = "BLOCKED_INSUFFICIENT_REMAINING"
    elif unknown:
        quota_status = "BLOCKED_UNKNOWN_CONSUMPTION"
    elif quota_relevant:
        quota_status = "PASS"
    else:
        quota_status = "NOT_APPLICABLE"
    permitted = cost_pass and quota_status in {"PASS", "NOT_APPLICABLE"}
    result = {
        "schema_version": "1.0.0",
        "policy_id": policy["policy_id"],
        "technical_cost_brl": 0,
        "cost_status": "PASS" if cost_pass else "FAIL",
        "operation": operation,
        "quota_status": quota_status,
        "execution_permitted": permitted,
        "resources": rows,
        "blockers": sorted(set(blockers)),
        "fallback_decision": "EXECUTE_WITH_FREE_QUOTA" if permitted else "DEFER_OR_USE_DECLARED_ZERO_COST_FALLBACK; NEVER_ENABLE_BILLING",
        "claim_boundary": "This guard proves configured financial cost zero and checks supplied quota observations. It does not infer console usage, electrical cost, labor value or publication quality.",
        "created_at": created_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    Draft202012Validator(_read(root / "schemas/zero_cost_guard.schema.json")).validate(result)
    return result


def materialize(root: Path = ROOT) -> Path:
    target = root.resolve() / "output/operations/zero-cost/phase5-publication-pipeline-preflight.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(evaluate_zero_cost(root), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return target


if __name__ == "__main__":
    print(materialize())
