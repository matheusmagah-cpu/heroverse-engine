"""Span-exact publicity risk observations, not a legal release.

Execution resumes immutable per-sample journals without repeating a completed
decode or inference. Strong verification is deliberately different: it creates
a separate journal and independently repeats the exact source-index decode and
YuNet observation. A hash over a claimed zero-face counter is never sufficient.
Injected backends are FIXTURE only and cannot yield a LIVE verification.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hero_engine.phase6_publicity import YUNET_SHA256, metadata_publicity_risks

VERSION = "phase6-av-publicity-v1"
SCHEMA = "schemas/phase6_av_publicity.schema.json"
LICENSE_SHA = "2ad92c7a6eb7aebede4e19f5ec4930c8bd9d614dbb8e75be1f740edae346734c"
MODEL = "models/yunet/face_detection_yunet_2026may.onnx"
AUTHORITY = {key: False for key in ("queue_authorized", "render_authorized", "publication_authorized", "legal_clearance")}
SETTINGS = {"score_threshold": 0.80, "nms_threshold": 0.30, "top_k": 5000,
            "initial_size": [320, 320], "resize_max_width": 1280,
            "interpolation": "INTER_LINEAR", "pixel_order": "RGB24_TO_BGR_UINT8",
            "threads": 1, "opencl": False}
LIMITS = {"ttl_seconds": 86400, "decode_timeout_seconds": 30, "detector_timeout_seconds": 90,
          "minimum_available_ram_bytes": 536870912, "disk_reserve_bytes": 5368709120,
          "maximum_frame_bytes": 67108864}
CLAIM = ("Negative sampled YuNet detection and metadata screening reduce risk only; "
         "they do not prove absence of unobserved people, logos, marks, property rights or legal claims.")


class PublicityError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def utc(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise PublicityError("timezone required")
    return result.astimezone(timezone.utc)


def stamp():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def resolve(root, value, *, confined=False):
    candidate = Path(value)
    candidate = candidate if candidate.is_absolute() else Path(root) / candidate
    for part in (candidate, *candidate.parents):
        if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
            raise PublicityError("linked source/evidence forbidden")
    candidate = candidate.resolve()
    if confined and not candidate.is_relative_to(Path(root).resolve()):
        raise PublicityError("source/evidence outside root")
    return candidate


def binding(path):
    path = resolve(Path.cwd(), path)
    if not path.is_file() or getattr(path.stat(), "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000):
        raise PublicityError("missing/nonresident source")
    raw = path.read_bytes()
    return {"path": str(path), "sha256": sha(raw), "size_bytes": len(raw)}


def reopen(root, item, *, confined=False):
    path = resolve(root, item["path"], confined=confined)
    actual = binding(path)
    if actual["sha256"] != item["sha256"] or type(item["size_bytes"]) is not int or actual["size_bytes"] != item["size_bytes"]:
        raise PublicityError("source/hash/size changed")
    return path.read_bytes()


def document(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise PublicityError("duplicate JSON key")
            result[key] = value
        return result
    result = json.loads(raw, object_pairs_hook=unique)
    canonical(result)
    return result


def atomic(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise PublicityError("immutable evidence differs")
        return
    temp = path.with_name(path.name + ".partial-" + uuid.uuid4().hex)
    with temp.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    try:
        os.link(temp, path)
    finally:
        temp.unlink()


def save(path, value):
    atomic(path, canonical(value))


def create_policy(root, *, ffmpeg_path="C:/ffmpeg/bin/ffmpeg.exe"):
    """Metadata-only recipe. Caller must pin this before execution."""
    root = Path(root).resolve()
    site = root / ".venv/Lib/site-packages"
    files = []
    for name in ("cv2", "numpy", "numpy.libs"):
        package = site / name
        files.extend(p for p in package.rglob("*") if p.is_file() and
                     not {"tests", "testing", "__pycache__"}.intersection(p.relative_to(package).parts) and
                     (p.suffix in {".py", ".pyd", ".dll"} or "LICENSE" in p.name))
    metadata = sorted(site.glob("opencv_python-*.dist-info/METADATA"))
    numpy_metadata = sorted(site.glob("numpy-*.dist-info/METADATA"))
    if len(metadata) != 1 or len(numpy_metadata) != 1 or not (site / "cv2/cv2.pyd").is_file():
        raise PublicityError("one exact installed OpenCV/NumPy runtime required")
    files.extend(metadata + numpy_metadata)
    files.extend(p.parent / "RECORD" for p in metadata + numpy_metadata)
    settings = dict(line.split("=", 1) for line in (root / ".venv/pyvenv.cfg").read_text(encoding="utf-8").splitlines() if "=" in line)
    home = next(value.strip() for key, value in settings.items() if key.strip() == "home")
    policy = {"version": VERSION, "settings": SETTINGS, "limits": LIMITS,
              "sampling": "EVERY_SPAN_START_MIDDLE_END_FRAME_INDEX_NO_CAP",
              "decoder": "FFMPEG_SELECT_N_RGB24_PPM_NO_SEEK_V1",
              "module": binding(Path(__file__)), "schema": binding(root / SCHEMA),
              "legacy_metadata_implementation": binding(root / "hero_engine/phase6_publicity.py"),
              "model": binding(root / MODEL), "license": binding(root / "models/yunet/LICENSE"),
              "model_card": binding(root / "models/yunet/MODEL_CARD.md"),
              "ffmpeg": binding(ffmpeg_path), "python": binding(Path(home) / "python.exe"),
              "site_packages": str(site), "runtime_files": [binding(p) for p in sorted(set(files))],
              "runtime_scope": "EXECUTABLE_PACKAGES_EXCLUDING_TESTS_PLUS_DISTRIBUTION_RECORDS",
              "authority": AUTHORITY, "technical_cost_brl": 0}
    validate_policy(root, policy)
    return policy


def validate_policy(root, policy):
    if (policy["version"] != VERSION or canonical(policy["settings"]) != canonical(SETTINGS) or canonical(policy["limits"]) != canonical(LIMITS)
            or canonical(policy["authority"]) != canonical(AUTHORITY) or type(policy["technical_cost_brl"]) is not int or policy["technical_cost_brl"] != 0
            or policy["sampling"] != "EVERY_SPAN_START_MIDDLE_END_FRAME_INDEX_NO_CAP"
            or policy["runtime_scope"] != "EXECUTABLE_PACKAGES_EXCLUDING_TESTS_PLUS_DISTRIBUTION_RECORDS"
            or policy["decoder"] != "FFMPEG_SELECT_N_RGB24_PPM_NO_SEEK_V1"):
        raise PublicityError("policy/threshold/authority differs")
    if policy["model"]["sha256"] != "sha256:" + YUNET_SHA256 or policy["license"]["sha256"] != "sha256:" + LICENSE_SHA:
        raise PublicityError("model/license not the existing approved identity")
    for key in ("module", "schema", "legacy_metadata_implementation", "model", "license", "model_card", "ffmpeg", "python"):
        reopen(root, policy[key])
    if binding(__file__)["sha256"] != policy["module"]["sha256"]:
        raise PublicityError("executing implementation differs")
    if not policy["runtime_files"]:
        raise PublicityError("runtime provenance absent")
    for item in policy["runtime_files"]:
        reopen(root, item)


def samples(start, end):
    if type(start) is not int or type(end) is not int or start < 0 or end <= start:
        raise PublicityError("invalid half-open source span")
    return sorted({start, (start + end - 1) // 2, end - 1})


def derive_assets(root, timeline_binding, library_binding):
    timeline = document(reopen(root, timeline_binding, confined=True))
    library = document(reopen(root, library_binding, confined=True))
    grouped = {}; ids = set()
    for span in timeline.get("render_spans") or []:
        if not isinstance(span["span_id"], str) or not span["span_id"] or span["span_id"] in ids:
            raise PublicityError("duplicate/invalid span identity")
        ids.add(span["span_id"])
        source = span["asset_binding"]
        p = resolve(root, source["path"], confined=True)
        actual = binding(p)
        if actual["sha256"] != source["sha256"]:
            raise PublicityError("timeline source bytes differ")
        key = (str(p), actual["sha256"])
        if key not in grouped:
            matches = [asset for asset in library["assets"] if resolve(root, asset["uri"], confined=True) == p
                       and asset["content_hash"] == actual["sha256"]]
            if len(matches) != 1:
                raise PublicityError("asset metadata provenance absent/ambiguous")
            asset = matches[0]
            if any(not isinstance(asset.get(k), str) or not asset[k].strip() for k in ("asset_id", "source", "creator_or_holder")):
                raise PublicityError("asset metadata incomplete")
            grouped[key] = {"asset_id": asset["asset_id"], "source": actual,
                            "metadata_risk_terms": metadata_publicity_risks(asset), "spans": []}
        grouped[key]["spans"].append({"span_id": span["span_id"], "source_start_frame": span["source_start_frame"],
                                      "source_end_frame": span["source_end_frame"],
                                      "samples": samples(span["source_start_frame"], span["source_end_frame"])})
    if not grouped or len({row["asset_id"] for row in grouped.values()}) != len(grouped):
        raise PublicityError("empty/ambiguous asset population")
    return [dict(row, spans=sorted(row["spans"], key=lambda s: s["span_id"])) for _, row in sorted(grouped.items())]


def decode_command(policy, source, index):
    samples(index, index + 1)
    return [policy["ffmpeg"]["path"], "-nostdin", "-v", "error", "-threads", "1",
            "-i", source["path"], "-map", "0:v:0", "-an", "-sn", "-dn", "-filter_threads", "1",
            "-vf", f"select=eq(n\\,{index}),format=rgb24", "-frames:v", "1", "-fps_mode", "passthrough",
            "-fs", str(LIMITS["maximum_frame_bytes"]), "-c:v", "ppm", "-f", "image2pipe", "-"]


def ppm(raw):
    match = re.match(rb"P6\s+(\d+)\s+(\d+)\s+255\s", raw)
    if not match or len(raw) > LIMITS["maximum_frame_bytes"]:
        raise PublicityError("unreadable/oversize actual decoded PPM")
    width, height = map(int, match.groups())
    pixels = raw[match.end():]
    if not width or not height or len(pixels) != width * height * 3:
        raise PublicityError("decoded dimensions/pixel bytes differ")
    return width, height, pixels


def owned(command, timeout):
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    try:
        try:
            stdout, stderr = child.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            child.terminate()
            try: child.communicate(timeout=3)
            except subprocess.TimeoutExpired: child.kill(); child.communicate(timeout=3)
            raise PublicityError("owned child timeout")
        if child.returncode != 0:
            raise PublicityError("owned child failed: " + stderr.decode("utf-8", "backslashreplace")[-2000:])
        return stdout
    finally:
        if child.poll() is None:
            child.kill(); child.communicate(timeout=3)


def face_count(raw, width, height):
    expected = [width, height] if width <= 1280 else [1280, max(1, round(height * (1280 / width)))]
    if (set(raw) != {"settings", "input_size", "opencv_version", "retval", "detections"}
            or canonical(raw.get("settings")) != canonical(SETTINGS) or canonical(raw.get("input_size")) != canonical(expected)
            or type(raw.get("retval")) is not int or raw["retval"] < 0
            or not isinstance(raw.get("opencv_version"), str) or not raw["opencv_version"]):
        raise PublicityError("raw detector/preprocess identity invalid")
    rows = raw.get("detections")
    if rows is None: return 0
    if not isinstance(rows, list): raise PublicityError("raw detections absent")
    for row in rows:
        if (not isinstance(row, list) or len(row) != 15 or any(type(n) not in (int, float) or not math.isfinite(n) for n in row)
                or not 0.80 <= row[-1] <= 1):
            raise PublicityError("malformed raw YuNet row")
    return len(rows)


def capacity(directory):
    import ctypes
    class Memory(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
            (key, ctypes.c_ulonglong) for key in ("total", "available", "page", "page_available", "virtual", "virtual_available", "extended")]
    memory = Memory(); memory.length = ctypes.sizeof(memory)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
        raise PublicityError("memory capacity unavailable")
    free = shutil.disk_usage(directory).free
    if (memory.available < LIMITS["minimum_available_ram_bytes"] or
            free - 2 * LIMITS["maximum_frame_bytes"] < LIMITS["disk_reserve_bytes"]):
        raise PublicityError("RAM/disk reserve unavailable before local observer")
    return {"available_ram_bytes": memory.available, "free_disk_bytes": free, "status": "PASS"}


def detector_worker(request_binding, frame_binding, target):
    request = document(reopen(Path.cwd(), request_binding)); policy = request["policy"]
    reopen(request["root"], request_binding, confined=True)
    target = resolve(request["root"], target, confined=True)
    frame_path = resolve(request["root"], frame_binding["path"], confined=True)
    run = resolve(request["root"], request_binding["path"], confined=True).parent
    if (target.name != "raw.json" or target.parent != frame_path.parent or not target.is_relative_to(run)
            or not run.is_relative_to(Path(request["root"]) / "output")):
        raise PublicityError("worker output/frame outside owned observation namespace")
    validate_policy(request["root"], policy)
    if Path(sys.executable).resolve() != Path(policy["python"]["path"]).resolve():
        raise PublicityError("worker must be real owned base Python")
    capacity(Path(target).parent)
    sys.path.insert(0, policy["site_packages"])
    import cv2
    import numpy as np
    if Path(cv2.__file__).resolve().parent != Path(policy["site_packages"]) / "cv2":
        raise PublicityError("unexpected OpenCV installation")
    cv2.setNumThreads(1); cv2.ocl.setUseOpenCL(False)
    width, height, pixels = ppm(reopen(request["root"], frame_binding, confined=True))
    image = np.frombuffer(pixels, np.uint8).reshape(height, width, 3)[:, :, ::-1].copy()
    if width > 1280:
        image = cv2.resize(image, (1280, max(1, round(height * (1280 / width)))), interpolation=cv2.INTER_LINEAR)
    actual_height, actual_width = image.shape[:2]
    detector = cv2.FaceDetectorYN.create(policy["model"]["path"], "", (320, 320), 0.80, 0.30, 5000)
    detector.setInputSize((actual_width, actual_height))
    retval, detections = detector.detect(image)
    result = {"settings": SETTINGS, "input_size": [actual_width, actual_height], "opencv_version": cv2.__version__,
              "retval": int(retval), "detections": None if detections is None else detections.tolist()}
    face_count(result, width, height)
    save(target, result)  # Persist actual rows before any aggregate interpretation.


class LiveBackend:
    def __init__(self, root, request_path, request):
        self.root, self.request_path, self.request = root, request_path, request

    def decode(self, source, index):
        capacity(self.request_path.parent)
        return owned(decode_command(self.request["policy"], source, index), LIMITS["decode_timeout_seconds"])

    def detect(self, frame_path, output_path):
        capacity(self.request_path.parent)
        policy = self.request["policy"]
        command = [policy["python"]["path"], "-I", str(Path(__file__).resolve()), "--worker",
                   json.dumps(binding(self.request_path)), json.dumps(binding(frame_path)), str(output_path)]
        owned(command, LIMITS["detector_timeout_seconds"])
        return document(output_path.read_bytes())


def _sample(root, directory, request_path, request, source, span_id, index, backend):
    directory.mkdir(parents=True, exist_ok=True)
    common = {"request": binding(request_path), "source": source, "span_id": span_id, "source_frame_index": index,
              "evidence_mode": request["evidence_mode"], "authority": AUTHORITY}
    complete = directory / "sample.json"
    if complete.exists():
        result = document(complete.read_bytes())
        if any(result[k] != v for k, v in common.items()): raise PublicityError("sample identity changed")
        if result["status"] == "PASS":
            frame = reopen(root, result["frame"], confined=True); width, height, _ = ppm(frame)
            raw = document(reopen(root, result["raw"], confined=True))
            _sample_journal(root, result, request)
            if result["face_count"] != face_count(raw, width, height) or result["face_count"] != 0 or result["errors"]:
                raise PublicityError("claimed face count/status differs from raw")
        return result
    result = {**common, "observed_at": stamp(), "status": "FAIL", "frame": None, "raw": None, "face_count": None,
              "decode_receipt": None, "decode_intent": None, "detect_intent": None, "errors": []}
    try:
        frame_path = directory / "frame.ppm"; decode_path = directory / "decode.json"
        command = decode_command(request["policy"], source, index)
        if decode_path.exists():
            decoded = document(decode_path.read_bytes())
            if decoded["common"] != common or decoded["command"] != command: raise PublicityError("decode provenance changed")
            frame = reopen(root, decoded["frame"], confined=True)
        else:
            if (directory / "decode-intent.json").exists(): raise PublicityError("uncertain decode; automatic repeat forbidden")
            save(directory / "decode-intent.json", {"common": common, "command": command})
            frame = backend.decode(source, index); ppm(frame); atomic(frame_path, frame)
            save(decode_path, {"common": common, "command": command, "frame": binding(frame_path)})
        width, height, _ = ppm(frame); result["frame"] = binding(frame_path)
        result["decode_receipt"] = binding(decode_path); result["decode_intent"] = binding(directory / "decode-intent.json")
        raw_path = directory / "raw.json"
        if raw_path.exists():
            raw = document(raw_path.read_bytes())
        else:
            if (directory / "detect-intent.json").exists(): raise PublicityError("uncertain detection; automatic repeat forbidden")
            save(directory / "detect-intent.json", {"common": common, "frame": result["frame"]})
            raw = backend.detect(frame_path, raw_path); save(raw_path, raw)
        result["detect_intent"] = binding(directory / "detect-intent.json")
        result["raw"] = binding(raw_path); result["face_count"] = face_count(raw, width, height)
        result["status"] = "PASS" if result["face_count"] == 0 else "FAIL"
        if result["face_count"]: result["errors"] = ["PERSON_DETECTED"]
        _sample_journal(root, result, request)
    except Exception as exc:
        result["errors"] = [type(exc).__name__ + ":" + str(exc)]
    result["observed_at"] = stamp()
    save(complete, result)
    return result


def _sample_journal(root, sample, request):
    common = {key: sample[key] for key in ("request", "source", "span_id", "source_frame_index", "evidence_mode", "authority")}
    command = decode_command(request["policy"], sample["source"], sample["source_frame_index"])
    decoded = document(reopen(root, sample["decode_receipt"], confined=True))
    decode_intent = document(reopen(root, sample["decode_intent"], confined=True))
    detect_intent = document(reopen(root, sample["detect_intent"], confined=True))
    if (decoded != {"common": common, "command": command, "frame": sample["frame"]}
            or decode_intent != {"common": common, "command": command}
            or detect_intent != {"common": common, "frame": sample["frame"]}):
        raise PublicityError("sample decode/detector journal differs")


def _schema(value):
    from jsonschema import Draft202012Validator, FormatChecker
    schema = document(Path(__file__).resolve().parents[1].joinpath(SCHEMA).read_bytes())
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def execute(root, *, run_dir, timeline_binding, library_binding, policy_binding, evidence_mode="LIVE", backend=None):
    """Observations only. No queue, upload, credential, legal or render authority."""
    root = Path(root).resolve(); directory = resolve(root, run_dir, confined=True)
    if not directory.is_relative_to(root / "output") or directory == root / "output":
        raise PublicityError("dedicated output namespace required")
    if evidence_mode not in {"LIVE", "FIXTURE"} or (backend is not None and evidence_mode != "FIXTURE"):
        raise PublicityError("injected observer cannot create LIVE evidence")
    policy = document(reopen(root, policy_binding)); validate_policy(root, policy)
    assets = derive_assets(root, timeline_binding, library_binding)
    request = {"root": str(root), "timeline": timeline_binding, "library": library_binding, "policy_binding": policy_binding,
               "policy": policy, "assets": assets, "evidence_mode": evidence_mode, "authority": AUTHORITY}
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory / "execution.lock"
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_BINARY", 0), 0o600)
    lock_bytes = canonical({"pid": os.getpid(), "nonce": uuid.uuid4().hex}); os.write(fd, lock_bytes); os.fsync(fd)
    try:
        request_path = directory / "request.json"; save(request_path, request)
        observer = backend or LiveBackend(root, request_path, request)
        records = []
        for asset_index, asset in enumerate(assets):
            reopen(root, asset["source"], confined=True)
            for span_index, span in enumerate(asset["spans"]):
                for index in span["samples"]:
                    target = directory / f"asset-{asset_index:04d}-span-{span_index:04d}-frame-{index:09d}"
                    _sample(root, target, request_path, request, asset["source"], span["span_id"], index, observer)
                    records.append(binding(target / "sample.json"))
        validate_policy(root, policy)
        if derive_assets(root, timeline_binding, library_binding) != assets: raise PublicityError("sources changed during scan")
        observations = [document(reopen(root, item, confined=True)) for item in records]
        passed = bool(observations and all(row["status"] == "PASS" and row["face_count"] == 0 and not row["errors"] for row in observations) and
                      not any(asset["metadata_risk_terms"] for asset in assets))
        observed_at = max(row["observed_at"] for row in observations)
        # TTL starts at the oldest measurement, not at aggregation/replay time.
        oldest = min(utc(row["observed_at"]) for row in observations)
        receipt = {"schema_version": "1.0.0", "document_type": "PHASE6_AV_PUBLICITY_OBSERVATIONS", "version": VERSION,
                   "evidence_mode": evidence_mode, "status": "PASS" if passed else "FAIL", "request": binding(request_path),
                   "observed_at": observed_at, "valid_until": (oldest + timedelta(seconds=LIMITS["ttl_seconds"])).isoformat(),
                   "assets": assets, "samples": records, "sample_count": len(records),
                   "detected_face_count": sum(row["face_count"] or 0 for row in observations),
                   "authority": AUTHORITY, "technical_cost_brl": 0, "claim_boundary": CLAIM}
        _schema(receipt); save(directory / "receipt.json", receipt)
        return receipt
    finally:
        os.close(fd)
        if lock.read_bytes() != lock_bytes: raise PublicityError("owned lock changed; preserved")
        lock.unlink()


def verify(root, *, receipt_binding, expected_timeline, expected_library, expected_policy, verification_dir,
           backend=None, now=None, require_live=True):
    """Strong source/pixel/inference counterproof with its own new journal.

    FIXTURE may exercise this function but never returns PASS_LIVE. The receipt
    is not admitted by merely loading it: a LIVE call uses the real backend.
    """
    root = Path(root).resolve(); now = now or datetime.now(timezone.utc)
    receipt = document(reopen(root, receipt_binding, confined=True)); _schema(receipt)
    if type(require_live) is not bool or (require_live and receipt["evidence_mode"] != "LIVE"):
        raise PublicityError("LIVE source observations required")
    if backend is not None and receipt["evidence_mode"] != "FIXTURE":
        raise PublicityError("injected counter-observer cannot verify LIVE evidence")
    request = document(reopen(root, receipt["request"], confined=True))
    if (request["timeline"] != expected_timeline or request["library"] != expected_library
            or request["policy_binding"] != expected_policy or request["authority"] != AUTHORITY
            or receipt["authority"] != AUTHORITY or request["evidence_mode"] != receipt["evidence_mode"]):
        raise PublicityError("caller-pinned inputs/authority differ")
    if utc(receipt["observed_at"]) > now or utc(receipt["valid_until"]) < now:
        raise PublicityError("future/stale publicity observations")
    assets = derive_assets(root, expected_timeline, expected_library)
    expected = [(a["source"], s["span_id"], i) for a in assets for s in a["spans"] for i in s["samples"]]
    rows = [document(reopen(root, item, confined=True)) for item in receipt["samples"]]
    if (receipt["assets"] != assets or len(rows) != len(expected) or receipt["sample_count"] != len(expected)
            or [(r["source"], r["span_id"], r["source_frame_index"]) for r in rows] != expected):
        raise PublicityError("missing/extra/duplicate span-frame evidence")
    if any(r["status"] != "PASS" or r["errors"] or r["authority"] != AUTHORITY or r["request"] != receipt["request"]
           or r["evidence_mode"] != receipt["evidence_mode"] for r in rows):
        raise PublicityError("original scan contains risk/error/ambiguity")
    if receipt["status"] != "PASS" or receipt["detected_face_count"] != 0 or any(a["metadata_risk_terms"] for a in assets):
        raise PublicityError("original publicity risk screen did not pass")
    oldest = min(utc(row["observed_at"]) for row in rows)
    newest = max(utc(row["observed_at"]) for row in rows)
    if (utc(receipt["observed_at"]) != newest or newest > now or
            utc(receipt["valid_until"]) != oldest + timedelta(seconds=LIMITS["ttl_seconds"])):
        raise PublicityError("TTL/observation interval differs")
    for row in rows:
        _sample_journal(root, row, request)
    directory = resolve(root, verification_dir, confined=True)
    if directory.exists(): raise PublicityError("independent verification requires a fresh journal")
    fresh = execute(root, run_dir=directory, timeline_binding=expected_timeline, library_binding=expected_library,
                    policy_binding=expected_policy, evidence_mode=receipt["evidence_mode"], backend=backend)
    if fresh["status"] != "PASS":
        raise PublicityError("independent source decode/detector contradicts captured evidence or cannot observe it")
    fresh_rows = [document(reopen(root, item, confined=True)) for item in fresh["samples"]]
    for previous, actual in zip(rows, fresh_rows):
        old_frame = reopen(root, previous["frame"], confined=True); old_raw = reopen(root, previous["raw"], confined=True)
        if old_frame != reopen(root, actual["frame"], confined=True) or document(old_raw) != document(reopen(root, actual["raw"], confined=True)):
            raise PublicityError("independent source decode/detector contradicts captured evidence")
        width, height, _ = ppm(old_frame)
        if previous["face_count"] != face_count(document(old_raw), width, height):
            raise PublicityError("forged zero-face counter")
    if (receipt["status"] != "PASS" or fresh["status"] != "PASS" or receipt["detected_face_count"] != 0
            or any(a["metadata_risk_terms"] for a in assets)):
        raise PublicityError("publicity risk screen did not pass")
    reopen(root, receipt_binding, confined=True)
    if utc(receipt["valid_until"]) < max(now, datetime.now(timezone.utc)):
        raise PublicityError("publicity observations expired during independent verification")
    result = {"schema_version": "1.0.0", "document_type": "PHASE6_AV_PUBLICITY_COUNTERPROOF", "version": VERSION,
              "status": "PASS_LIVE" if receipt["evidence_mode"] == "LIVE" else "PASS_FIXTURE",
              "source_receipt": receipt_binding, "counterproof_receipt": binding(directory / "receipt.json"),
              "verified_at": stamp(), "valid_until": receipt["valid_until"],
              "sample_count": len(rows), "authority": AUTHORITY, "technical_cost_brl": 0, "claim_boundary": CLAIM}
    _schema(result)
    save(directory / "verification.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", nargs=3, required=True)
    args = parser.parse_args()
    detector_worker(document(args.worker[0]), document(args.worker[1]), Path(args.worker[2]))
