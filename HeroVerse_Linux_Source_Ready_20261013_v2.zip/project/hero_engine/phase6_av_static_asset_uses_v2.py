"""Twenty-five untimed uses, anchored replay of thirteen historical uses.

No old PNG/rights evaluator is rerun. The two-family cache has an external
execution anchor, exact inputs, identities and current byte rechecks. Twelve
compact sources are measured once and compared with their separately anchored
rights registry. Historical rights replay is not a new approval or a clock.
"""
from __future__ import annotations

import copy
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_static_sources as sources
from . import phase6_av_static_asset_uses as legacy
from . import phase6_av_compact_sources as compact
from . import phase6_compact_asset_rights as compact_rights
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-static-asset-uses-v2"
SCHEMA = "schemas/phase6_av_static_asset_uses_v2.schema.json"
ANCHOR = {
    "path": "output/operations/phase6/av-admission/static-asset-uses/real-static-uses-b7b76158caac228e7bf3977e.json",
    "sha256": "b7b76158caac228e7bf3977e33c91fe057ec64bfa6422bc73b83540b3f5d49ed",
}
LEGACY_INPUT = {
    "path": "output/operations/phase6/av-admission/static-asset-uses/static-asset-uses-input-5411282bfe21702376cfbc5f.json",
    "sha256": "5411282bfe21702376cfbc5f3cc532fa386f3e584e750290bee51e0415b94516",
}
LEGACY_INSPECTION = {
    "path": "output/operations/phase6/av-admission/static-asset-uses/static-asset-uses-34450e7380b1e68dc4bd9d29.json",
    "sha256": "1cfcccc897ca9fd346ca7b9bcf4b5834e1c2298f681192f6deacb9c0dc54dce9",
}
COMPACT_DIRECTORY = "output/operations/phase6/av-admission/evidence/compact-rights-registrations/d171-reviewed-compact-rights-registration-v1"
COMPACT_REGISTRATION = {"path": COMPACT_DIRECTORY + "/receipt.json",
    "sha256": "5dfd9d4f36ce2d30b276bf82666ef26bdc922f0879cc26fbaa928fed363364aa"}
COMPACT_REQUEST = {"path": COMPACT_DIRECTORY + "/request.json",
    "sha256": "029d9066ab43b2f7bdbe97fbd4f330906578de6b6e574b0737b10c9166c4b103"}
LEGACY_IMPLEMENTATIONS = {
    "hero_engine/phase6_av_static_asset_uses.py": "e3d06067bd969adb204bba8dcf9ae835f88f90f39d559358d0620e23e74dc662",
    "schemas/phase6_av_static_asset_uses.schema.json": "4288666ae38d38c05c521239f797b5a07a5929b6ff60fbc3522170cfd617c6bb",
    "output/qa/phase6/diagnostics/av-static-integration-v1/build_static_asset_uses.py": "069448b2216e1b123bb73904c3ca5f98e785ec32c3fb52afec385352f8aff566",
}
IMPLEMENTATION_PINS = {**LEGACY_IMPLEMENTATIONS, **legacy.DEPENDENCY_PINS,
    "hero_engine/phase6_av_compact_sources.py": "ce21a4c51c35b6c0b5f05a7796d5c8558e147110e2cbdf0faebd3aa098e09b31",
    "hero_engine/phase6_compact_asset_rights.py": "9ae330a828d6c20b8b5ac7baaf1a5e7a73e3a526be334aa43f2f123a350a8fda",
    "schemas/phase6_compact_static_rights.schema.json": "88e074d23f07cf646d2eaf48f56d782295bc7d6206e7abc746bdeaced8702c6c",
}
AUTHORITY = dict(legacy.AUTHORITY)


def _same(actual, expected, message):
    sources._same(actual, expected, message)


def _json(reader, binding):
    if type(binding) is not dict or set(binding) != {"path", "sha256"}:
        raise ValueError("exact external binding required")
    path = Path(binding["path"])
    if path.is_absolute():
        if not path.is_relative_to(reader.root):
            raise ValueError("JSON binding escapes root")
        path = path.relative_to(reader.root)
    raw = reader.read(path.as_posix(), binding["sha256"])
    value = sources._json(raw)
    if sources._canonical(value) != raw:
        raise ValueError("canonical JSON byte identity required")
    return value


def _identity(value, field, prefix):
    _same(value[field], prefix + sources._sha(sources._canonical({key: item for key, item in value.items() if key != field}))[:24],
          "cached identity does not recompose")


def _dependencies(reader, items):
    """Reopen only root-confined files and the exact existing decoder/font pins."""
    if type(items) is not list or not items:
        raise ValueError("cached dependency population missing")
    seen = set()
    for item in items:
        if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                or type(item["path"]) is not str or type(item["size_bytes"]) is not int
                or item["size_bytes"] <= 0 or item["path"] in seen):
            raise ValueError("cached dependency fields or multiplicity differ")
        seen.add(item["path"])
        path = Path(item["path"])
        if (not path.is_absolute() or (not path.is_relative_to(reader.root)
                and sources.EXTERNAL_DEPENDENCY_PINS.get(str(path)) != item["sha256"])):
            raise ValueError("cached dependency escapes fixed allowlist")
        if str(path) in sources.EXTERNAL_DEPENDENCY_PINS:
            _same(item["sha256"], sources.EXTERNAL_DEPENDENCY_PINS[str(path)], "fixed external pin differs")
        if len(reader.read_path(path, item["sha256"])) != item["size_bytes"]:
            raise ValueError("cached dependency size differs")


def _recheck(reader):
    _dependencies(reader, list(reader.bindings.values()))
    # Original generation admission required an exact directory, not merely a
    # subset of hashes. Preserve that property during read-only cache replay.
    for config in sources.TEMPLATES.values():
        names = {sid + extension for sid in config["state_ids"] for extension in (".png", ".svg")}
        names.update((config["contact_sheet"], "receipt.json"))
        if {path.name for path in reader.path(config["directory"]).iterdir()} != names:
            raise ValueError("legacy generation inventory changed during replay")


def _rights_registry(reader, registry, *, count, lineages, authority, version):
    _same([registry["status"], registry["state_count"], registry["lineage_count"], registry["technical_cost_brl"], registry["authority"]],
          ["REGISTERED_RIGHTS_ONLY_NOT_ADMITTED", count, lineages, 0, authority], "anchored rights registry scope differs")
    review = registry["request"]["review_binding"]
    if type(review) is not dict or set(review) != {"path", "sha256"}:
        raise ValueError("rights registration review pin fields differ")
    review_path = Path(review["path"])
    if not review_path.is_absolute() or not review_path.is_relative_to(reader.root):
        raise ValueError("rights registration review escapes root")
    reader.read_path(review_path, review["sha256"])
    for item in registry["request"]["module_bindings"]:
        if type(item) is not dict or set(item) != {"path", "sha256"}:
            raise ValueError("rights registration code pin fields differ")
        path = Path(item["path"])
        if not path.is_absolute() or not path.is_relative_to(reader.root):
            raise ValueError("rights registration code escapes root")
        reader.read_path(path, item["sha256"])
    request_hash = sources._sha(sources._canonical(registry["request"]))
    prefix = "d171-static-rights-registration-" if count == 11 else "d171-compact-rights-registration-"
    _same(registry["registration_id"], prefix + request_hash[:24], "rights registration request identity differs")
    rows, proofs = registry["request"]["states"], registry["rights_proofs"]
    if len(rows) != count or len(proofs) != count or len({row["asset_id"] for row in rows}) != count:
        raise ValueError("anchored rights registry population differs")
    for row, proof in zip(rows, proofs, strict=True):
        _same([proof["version"], proof["status"], proof["scope"], proof["evidence_mode"], proof["source_ready"], proof["authority"], proof["technical_cost_brl"]],
              [version, "PASS", "RIGHTS_BINDING_ONLY", "LIVE", False, authority, 0], "cached rights proof scope differs")
        _identity(proof, "inspection_id", "static-rights-")
        _same([proof[key] for key in ("asset_id", "template_id", "state_id")],
              [row[key] for key in ("asset_id", "template_id", "state_id")], "cached rights state association differs")
        arguments = row["arguments"]
        if count == 12:
            _same(proof["editorial_review_binding"], review, "rights registry review association differs")
        for field in ("provenance_binding", "decision_binding"):
            _same(proof[field], arguments[field], "cached rights external document association differs")
            document = _json(reader, arguments[field])
            key = "provenance_id" if field == "provenance_binding" else "decision_id"
            _identity(document, key, "static-owned-provenance-" if key == "provenance_id" else "static-owned-decision-")
            _same([document[key], document["asset_id"], document["template_id"], document["state_id"], document["evidence_mode"]],
                  [proof[key], row["asset_id"], row["template_id"], row["state_id"], "LIVE"], "cached external rights document differs")
            if count == 11 and key == "decision_id":
                # The old frozen schema has no editorial_review_binding. Its
                # request pin and exact registrar-generated basis are the
                # historical link; never retrofit a field into the old proof.
                basis = "Exact narrow decision in " + review_path.relative_to(reader.root).as_posix() + " SHA256=" + review["sha256"]
                basis += "; original schematic project composition, no embedded third-party visuals. OWNED describes controlled origin, not exclusive AI copyright. Does not approve publicity or the final video."
                _same(document["decision_basis"], basis, "legacy registered review basis differs")
        _dependencies(reader, proof["dependency_bindings"])
    return rows, proofs


def _legacy_replay(reader, literal):
    anchor = _json(reader, ANCHOR)
    _same([anchor["kind"], anchor["status"], anchor["source_count"], anchor["use_count"], anchor["lineage_count"],
           anchor["remaining_unbound_visual_state_count"], anchor["authority"], anchor["technical_cost_brl"]],
          ["PHASE6_STATIC_ASSET_USES_REAL_EXECUTION", "VERIFIED_PARTIAL_LITERAL_BINDINGS_NOT_PRODUCTION_READY", 11, 13, 2, 87, AUTHORITY, 0],
          "legacy execution anchor scope differs")
    _same(anchor["implementation_pins"], LEGACY_IMPLEMENTATIONS, "legacy execution implementation pins differ")
    _same([anchor["input_binding"], anchor["inspection_binding"]], [LEGACY_INPUT, LEGACY_INSPECTION], "legacy execution points elsewhere")
    document, inspected = _json(reader, LEGACY_INPUT), _json(reader, LEGACY_INSPECTION)
    old_plan, registry = _json(reader, legacy.PLAN), _json(reader, legacy.REGISTRATION)
    for config in sources.TEMPLATES.values():
        receipt = _json(reader, {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]})
        sources._inventory(reader, config["directory"], receipt, config, decode=False)
    _same(document, legacy._expected(old_plan, registry), "legacy input does not recompose")  # Frozen pure compiler, no evaluator.
    _identity(inspected, "inspection_id", "static-asset-uses-")
    _same([inspected["version"], inspected["status"], inspected["input_binding"], inspected["source_bindings"], inspected["source_count"],
           inspected["use_count"], inspected["lineage_count"], inspected["source_ready"], inspected["global_schedule_created"], inspected["authority"], inspected["technical_cost_brl"]],
          [legacy.VERSION, "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY", LEGACY_INPUT, document["source_bindings"], 11, 13, 2, False, False, AUTHORITY, 0],
          "legacy inspection scope differs")
    _, rights_proofs = _rights_registry(reader, registry, count=11, lineages=2, authority=legacy.rights.AUTHORITY,
                                       version="phase6-static-asset-rights-v2")
    _dependencies(reader, inspected["dependency_bindings"])
    _same(len(inspected["sources"]), 11, "legacy source count differs")
    for source, proof, source_input in zip(inspected["sources"], rights_proofs, document["sources"], strict=True):
        _same([source["source_id"], source["template_id"], source["state_id"], source["lineage_id"], source["asset_binding"],
               source["source_inspection_id"], source["source_inspection_sha256"], source["rights_inspection_id"], source["rights_inspection_sha256"]],
              [proof["asset_id"], proof["template_id"], proof["state_id"], proof["lineage_id"], proof["artifacts"]["png_binding"],
               proof["source_proof"]["inspection_id"], proof["source_proof"]["sha256"], proof["inspection_id"], sources._sha(sources._canonical(proof))],
              "legacy source/right cache chain differs")
        _same(source_input["source_id"], source["source_id"], "legacy source order differs")
    effective = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    by_id = {source["source_id"]: source for source in inspected["sources"]}
    expected = []
    for use in document["uses"]:
        row, state = effective[use["visual_state_id"]]
        _same([row["unit_id"], state["visual_content"]["literal_copy"]], [use["unit_id"], use["literal_copy"]], "amendment changed a legacy use")
        expected.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]),
            "source_provenance_unit_id": by_id[use["source_id"]]["original_unit_id"],
            "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
    _same(inspected["uses"], expected, "legacy use entries/origins do not recompose")
    all_ids = set(effective)
    _same(inspected["remaining_unbound_visual_state_ids"], sorted(all_ids - {row["visual_state_id"] for row in expected}),
          "legacy unbound population differs")
    return document, inspected


def _envelope(root):
    # The frozen metadata reader recomposes captions/base/amendment without PCM
    # or pixel decode, preserving the 88 unchanged states and both write anchors.
    reader, literal, _, _, _ = compact._preflight(root)
    for name, digest in IMPLEMENTATION_PINS.items():
        reader.read(name, digest)
    for name in ("hero_engine/phase6_av_static_asset_uses_v2.py", SCHEMA):
        path = reader.path(name)
        reader.read(name, sources._sha(path.read_bytes()))
    previous_document, previous_proof = _legacy_replay(reader, literal)
    request, registry = _json(reader, COMPACT_REQUEST), _json(reader, COMPACT_REGISTRATION)
    _same(registry["request"], request, "compact registration request differs")
    _same(registry["registration_id"], "d171-compact-rights-registration-" + COMPACT_REQUEST["sha256"][:24], "compact registry identity differs")
    _, rights_proofs = _rights_registry(reader, registry, count=12, lineages=1, authority=compact_rights.AUTHORITY,
                                       version=compact_rights.VERSION)
    _same([row["state_id"] for row in request["states"]], compact.CONFIG["state_ids"], "compact registry state order differs")
    return reader, literal, previous_document, previous_proof, registry, rights_proofs


def _expected(literal, old_document, registry):
    source_rows = copy.deepcopy(old_document["sources"])
    uses = copy.deepcopy(old_document["uses"])
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    for entry in registry["request"]["states"]:
        arguments = entry["arguments"]
        source_rows.append({"source_id": entry["asset_id"],
            "static_source": {key: copy.deepcopy(arguments[key]) for key in ("template_id", "state_id", "receipt_binding")},
            "rights_evidence": {key: copy.deepcopy(arguments[key]) for key in ("provenance_binding", "decision_binding")}})
        row, state = states[entry["state_id"]]
        uses.append({"use_id": "static-use-" + state["state_id"], "visual_state_id": state["state_id"],
            "unit_id": row["unit_id"], "source_id": entry["asset_id"], "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"])})
    return {"kind": "PHASE6_STATIC_ASSET_USES", "schema_version": "2.0.0", "channel_id": sources.CHANNEL,
        "video_id": "video-002", "sources": source_rows, "uses": uses, "technical_cost_brl": 0,
        "source_bindings": {**copy.deepcopy(old_document["source_bindings"]), "legacy_execution": copy.deepcopy(ANCHOR),
            "legacy_input": copy.deepcopy(LEGACY_INPUT), "legacy_inspection": copy.deepcopy(LEGACY_INSPECTION),
            "visual_amendment": {"path": compact.amendment.PROJECTION_BINDING["path"], "sha256": compact.amendment.PROJECTION_BINDING["sha256"][7:]},
            "compact_rights_registration": copy.deepcopy(COMPACT_REGISTRATION), "compact_rights_request": copy.deepcopy(COMPACT_REQUEST)}}


def proposed_static_asset_uses(root):
    """Return a proposal only; no image decode, write or scheduled use."""
    reader, literal, old_document, _, registry, _ = _envelope(root)
    result = _expected(literal, old_document, registry)
    _recheck(reader)
    return result


def inspect_static_asset_uses(root, *, binding):
    reader, literal, old_document, old_proof, registry, rights_proofs = _envelope(root)
    document = _json(reader, binding)
    # Schema source formatting is bound by its raw implementation hash, not an
    # operational document's serializer. Keep strict duplicate/nonfinite JSON.
    schema = sources._json(reader.read(SCHEMA, reader.bindings[str(reader.path(SCHEMA))]["sha256"]))
    sources._canonical(schema)
    Draft202012Validator(schema).validate(document)
    _same(document, _expected(literal, old_document, registry), "exact twenty-five-use envelope differs")
    compact_inputs = document["sources"][11:]
    current = compact.inspect_compact_sources(root, requests=[row["static_source"] for row in compact_inputs])
    source_results = copy.deepcopy(old_proof["sources"])
    use_results = copy.deepcopy(old_proof["uses"])
    state_map = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    for entry, proof, recorded_rights, use in zip(compact_inputs, current, rights_proofs, document["uses"][13:], strict=True):
        _same([proof["inspection_id"], sources._sha(sources._canonical(proof)), canonical_sha(proof)],
              [recorded_rights["source_proof"]["inspection_id"], recorded_rights["source_proof"]["sha256"], recorded_rights["source_proof"]["timeline_canonical_sha256"]],
              "compact source differs from independently anchored rights source")
        _same([proof["state_id"], proof["asset_binding"], entry["source_id"]],
              [recorded_rights["state_id"], recorded_rights["artifacts"]["png_binding"], recorded_rights["asset_id"]], "compact source association differs")
        row, state = state_map[use["visual_state_id"]]
        _same([use["literal_copy"], state["entry"], row["text"], row["unit_id"]],
              [proof["literal_copy"], proof["entry"], proof["literal_narration"], proof["unit_id"]], "compact source/use literal class differs")
        source_results.append({"source_id": entry["source_id"], "asset_binding": copy.deepcopy(proof["asset_binding"]),
            "template_id": proof["template_id"], "state_id": proof["state_id"], "lineage_id": proof["lineage_id"],
            "original_unit_id": proof["unit_id"], "original_fragment_ids": copy.deepcopy(proof["fragment_ids"]),
            "original_lexical_target": copy.deepcopy(proof["lexical_target"]), "source_inspection_id": proof["inspection_id"],
            "source_inspection_sha256": sources._sha(sources._canonical(proof)), "rights_inspection_id": recorded_rights["inspection_id"],
            "rights_inspection_sha256": sources._sha(sources._canonical(recorded_rights))})
        use_results.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]), "source_provenance_unit_id": proof["unit_id"],
            "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
        _dependencies(reader, proof["dependency_bindings"])
    covered = {row["visual_state_id"] for row in use_results}
    counts = [len(source_results), len(use_results), len(covered), len(state_map),
              len({row["asset_binding"]["sha256"] for row in source_results}), len({row["lineage_id"] for row in source_results})]
    _same(counts, [23, 25, 25, 100, 22, 3], "twenty-five-use population differs")
    _recheck(reader)
    result = {"version": VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
        "input_binding": copy.deepcopy(binding), "source_bindings": copy.deepcopy(document["source_bindings"]),
        "channel_id": sources.CHANNEL, "video_id": "video-002", "source_count": 23, "use_count": 25,
        "unique_png_content_count": 22, "lineage_count": 3, "sources": source_results, "uses": use_results,
        "remaining_unbound_visual_state_ids": sorted(set(state_map) - covered), "source_ready": False,
        "global_schedule_created": False, "calibrated_timing_available": False, "authority": dict(AUTHORITY), "technical_cost_brl": 0,
        "legacy_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "anchor_binding": copy.deepcopy(ANCHOR),
            "input_binding": copy.deepcopy(LEGACY_INPUT), "inspection_binding": copy.deepcopy(LEGACY_INSPECTION),
            "source_count": 11, "use_count": 13, "lineage_count": 2, "new_decode_count": 0, "new_rights_evaluation_count": 0},
        "compact_rights_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "registration_binding": copy.deepcopy(COMPACT_REGISTRATION),
            "request_binding": copy.deepcopy(COMPACT_REQUEST), "source_count": 12, "lineage_count": 1,
            "current_source_batch_count": 1, "new_rights_evaluation_count": 0, "scope": "HISTORICAL_RIGHTS_BINDINGS_NOT_NEW_APPROVAL"},
        "visual_amendment_evidence": {"inspection_sha256": canonical_sha(literal),
            "effective_rows_sha256": canonical_sha(literal["rows"]), "changed_state_count": 12, "unmodified_state_count": 88,
            "source_ready": False, "global_schedule_created": False},
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda row: row["path"]),
        "claim_boundary": "Twenty-five untimed uses of twenty-three state assets, twenty-two PNG byte identities and three lineages. Thirteen uses replayed exactly from the independent historical anchor; twelve compact sources checked against previously registered rights. No new rights approval, calibrated samples, spans, publicity, quality, admission, render or publication."}
    result["inspection_id"] = "static-asset-uses-v2-" + sources._sha(sources._canonical(result))[:24]
    return result


def verify_static_asset_uses(candidate, root, *, binding):
    expected = inspect_static_asset_uses(root, binding=binding)
    _same(candidate, expected, "source-use v2 inspection replay differs")
    return expected
