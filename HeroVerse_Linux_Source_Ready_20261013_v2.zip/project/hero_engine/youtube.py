from __future__ import annotations

import html as html_lib
import json
import re
import sqlite3
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .db import DEFAULT_DB, ROOT, connect, utc_now


USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
)


@dataclass
class VideoMetadata:
    video_id: str
    title: str
    channel_id: str | None
    channel_name: str | None
    duration_seconds: int | None
    views: int | None
    published_date: str | None
    license_text: str | None
    reusable: bool
    captions: list[dict[str, Any]]


def video_id_from_url(value: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", value):
        return value
    parsed = urllib.parse.urlparse(value)
    if parsed.hostname in {"youtu.be", "www.youtu.be"}:
        return parsed.path.strip("/")
    query = urllib.parse.parse_qs(parsed.query)
    if "v" in query:
        return query["v"][0]
    match = re.search(r"/(?:shorts|embed)/([A-Za-z0-9_-]{11})", parsed.path)
    if match:
        return match.group(1)
    raise ValueError(f"Could not extract a YouTube video id from: {value}")


def _request(url: str, timeout: int = 25) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _extract_json_after_marker(page: str, markers: list[str]) -> dict[str, Any]:
    decoder = json.JSONDecoder()
    for marker in markers:
        start = page.find(marker)
        if start < 0:
            continue
        brace = page.find("{", start + len(marker))
        if brace < 0:
            continue
        try:
            payload, _ = decoder.raw_decode(page[brace:])
            if isinstance(payload, dict):
                return payload
        except json.JSONDecodeError:
            continue
    raise ValueError("YouTube player metadata was not found in the page")


def fetch_video_metadata(value: str) -> VideoMetadata:
    video_id = video_id_from_url(value)
    url = f"https://www.youtube.com/watch?v={video_id}&hl=en"
    page = _request(url).decode("utf-8", errors="replace")
    player = _extract_json_after_marker(
        page,
        ["var ytInitialPlayerResponse =", "ytInitialPlayerResponse =", '"playerResponse":'],
    )
    details = player.get("videoDetails", {})
    micro = player.get("microformat", {}).get("playerMicroformatRenderer", {})
    captions = (
        player.get("captions", {})
        .get("playerCaptionsTracklistRenderer", {})
        .get("captionTracks", [])
    )
    license_text = micro.get("license")
    if not license_text:
        match = re.search(r'"license"\s*:\s*"([^"]+)"', page)
        license_text = html_lib.unescape(match.group(1)) if match else None
    license_norm = (license_text or "").lower()
    reusable = "creative commons" in license_norm or "reuse allowed" in license_norm
    duration = details.get("lengthSeconds")
    views = details.get("viewCount")
    return VideoMetadata(
        video_id=video_id,
        title=details.get("title") or micro.get("title", {}).get("simpleText") or "",
        channel_id=details.get("channelId") or micro.get("externalChannelId"),
        channel_name=details.get("author") or micro.get("ownerChannelName"),
        duration_seconds=int(duration) if duration else None,
        views=int(views) if views else None,
        published_date=micro.get("publishDate") or micro.get("uploadDate"),
        license_text=license_text,
        reusable=reusable,
        captions=captions,
    )


def audit_license(value: str, db_path: Path | None = None) -> dict[str, Any]:
    metadata = fetch_video_metadata(value)
    status = "verified_cc" if metadata.reusable else ("not_verified" if metadata.license_text else "indeterminate")
    url = f"https://www.youtube.com/watch?v={metadata.video_id}"
    payload = json.dumps(asdict(metadata), ensure_ascii=False)
    with connect(db_path or DEFAULT_DB) as conn:
        existing = conn.execute(
            "SELECT channel_handle, license_status, license_evidence FROM videos WHERE video_id=?",
            (metadata.video_id,),
        ).fetchone()
        if not existing:
            raise ValueError(
                f"Video {metadata.video_id} is not in the catalog. Add it before auditing so attribution remains traceable."
            )
        effective_status = status
        effective_evidence = metadata.license_text
        # A missing/deferred license field is not evidence of a Standard license.
        # Preserve stronger evidence that was visually verified and cataloged.
        if status == "indeterminate" and existing["license_status"] == "verified_cc":
            effective_status = existing["license_status"]
            effective_evidence = existing["license_evidence"]
        conn.execute(
            """
            UPDATE videos SET title=?, views=?, duration_seconds=?, published_date=?,
                license_status=?, license_evidence=?, verified_at=?, source_payload=?, updated_at=?
            WHERE video_id=?
            """,
            (
                metadata.title, metadata.views, metadata.duration_seconds,
                metadata.published_date, effective_status, effective_evidence,
                utc_now(), payload, utc_now(), metadata.video_id,
            ),
        )
        conn.execute(
            """
            INSERT INTO license_audits
            (video_id, status, evidence_text, evidence_url, audited_at, reusable)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                metadata.video_id, status, metadata.license_text or "License field not exposed in technical metadata",
                url, utc_now(), int(metadata.reusable),
            ),
        )
    result = asdict(metadata)
    result["audit_status"] = status
    result["effective_catalog_status"] = effective_status
    return result


def _caption_text(payload: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    lines: list[str] = []
    segments: list[dict[str, Any]] = []
    for event in payload.get("events", []):
        chunks = event.get("segs") or []
        text = "".join(chunk.get("utf8", "") for chunk in chunks).replace("\n", " ").strip()
        if not text:
            continue
        start = event.get("tStartMs", 0) / 1000
        duration = event.get("dDurationMs", 0) / 1000
        end = start + duration
        minutes, seconds = divmod(int(start), 60)
        lines.append(f"[{minutes}:{seconds:02d}] {text}")
        segments.append({"start": start, "end": end, "text": text})
    return "\n".join(lines), segments


def fetch_transcript(value: str, language: str = "en", db_path: Path | None = None) -> dict[str, Any]:
    metadata = fetch_video_metadata(value)
    if not metadata.captions:
        raise ValueError(f"No public caption track found for {metadata.video_id}")
    tracks = metadata.captions
    selected = next((track for track in tracks if track.get("languageCode", "").startswith(language)), tracks[0])
    base_url = selected["baseUrl"]
    separator = "&" if "?" in base_url else "?"
    raw = _request(base_url + separator + "fmt=json3").decode("utf-8", errors="replace")
    try:
        body, segments = _caption_text(json.loads(raw))
    except (json.JSONDecodeError, ValueError):
        body, segments = _fetch_transcript_with_ytdlp(metadata.video_id, language)
    if not body:
        raise ValueError(f"Caption track for {metadata.video_id} was empty")
    transcript_dir = ROOT / "data" / "transcripts"
    transcript_dir.mkdir(parents=True, exist_ok=True)
    transcript_path = transcript_dir / f"{metadata.video_id}.{language}.txt"
    transcript_path.write_text(body, encoding="utf-8")
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute(
            """
            INSERT INTO transcripts (video_id, language, source, body, fetched_at)
            VALUES (?, ?, 'youtube_captions', ?, ?)
            ON CONFLICT(video_id) DO UPDATE SET
                language=excluded.language, source=excluded.source,
                body=excluded.body, fetched_at=excluded.fetched_at
            """,
            (metadata.video_id, selected.get("languageCode"), body, utc_now()),
        )
    return {
        "video_id": metadata.video_id,
        "language": selected.get("languageCode"),
        "path": str(transcript_path),
        "segments": segments,
    }


def _parse_vtt(body: str) -> tuple[str, list[dict[str, Any]]]:
    timestamp = re.compile(r"(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)\s+-->\s+(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)")
    raw_lines = body.replace("\r", "").split("\n")
    lines: list[str] = []
    segments: list[dict[str, Any]] = []
    index = 0
    while index < len(raw_lines):
        match = timestamp.search(raw_lines[index])
        if not match:
            index += 1
            continue
        start = (int(match.group(1) or 0) * 3600 + int(match.group(2)) * 60 + float(match.group(3)))
        end = (int(match.group(4) or 0) * 3600 + int(match.group(5)) * 60 + float(match.group(6)))
        index += 1
        text_parts: list[str] = []
        while index < len(raw_lines) and raw_lines[index].strip():
            clean = re.sub(r"<[^>]+>", "", raw_lines[index]).strip()
            if clean:
                text_parts.append(clean)
            index += 1
        text = " ".join(text_parts)
        if text and (not segments or text != segments[-1]["text"]):
            minutes, seconds = divmod(int(start), 60)
            lines.append(f"[{minutes}:{seconds:02d}] {text}")
            segments.append({"start": start, "end": end, "text": text})
    return "\n".join(lines), segments


def _fetch_transcript_with_ytdlp(video_id: str, language: str) -> tuple[str, list[dict[str, Any]]]:
    yt_dlp = _load_yt_dlp()
    with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True}) as ydl:
        info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=False)
    tracks = info.get("subtitles", {}).get(language) or info.get("automatic_captions", {}).get(language)
    if not tracks:
        raise ValueError(f"No usable caption track found for {video_id}")
    preferred = next((track for track in tracks if track.get("ext") == "json3"), None)
    preferred = preferred or next((track for track in tracks if track.get("ext") == "vtt"), tracks[0])
    raw = _request(preferred["url"]).decode("utf-8", errors="replace")
    if preferred.get("ext") == "json3":
        return _caption_text(json.loads(raw))
    return _parse_vtt(raw)


def import_transcript(video_id: str, transcript_path: Path, language: str = "en", db_path: Path | None = None) -> dict[str, Any]:
    body = transcript_path.read_text(encoding="utf-8")
    if "[" not in body:
        raise ValueError("Transcript does not contain timestamped lines")
    transcript_dir = ROOT / "data" / "transcripts"
    transcript_dir.mkdir(parents=True, exist_ok=True)
    destination = transcript_dir / f"{video_id}.{language}.txt"
    destination.write_text(body, encoding="utf-8")
    with connect(db_path or DEFAULT_DB) as conn:
        if not conn.execute("SELECT 1 FROM videos WHERE video_id=?", (video_id,)).fetchone():
            raise ValueError(f"Video {video_id} is not in the catalog")
        conn.execute(
            """
            INSERT INTO transcripts (video_id, language, source, body, fetched_at)
            VALUES (?, ?, 'verified_import', ?, ?)
            ON CONFLICT(video_id) DO UPDATE SET
                language=excluded.language, source=excluded.source,
                body=excluded.body, fetched_at=excluded.fetched_at
            """,
            (video_id, language, body, utc_now()),
        )
    return {"video_id": video_id, "language": language, "path": str(destination)}


def _load_yt_dlp():
    try:
        import yt_dlp  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Optional dependency yt-dlp is required for discovery/download. Run scripts/setup.ps1.") from exc
    return yt_dlp


def discover(query: str, limit: int = 25) -> list[dict[str, Any]]:
    yt_dlp = _load_yt_dlp()
    options = {"quiet": True, "extract_flat": True, "skip_download": True, "playlistend": limit}
    with yt_dlp.YoutubeDL(options) as ydl:
        result = ydl.extract_info(f"ytsearchdate{limit}:{query}", download=False)
    entries = result.get("entries") or []
    discovered: list[dict[str, Any]] = []
    for entry in entries:
        if not entry:
            continue
        discovered.append(
            {
                "video_id": entry.get("id"),
                "title": entry.get("title"),
                "channel": entry.get("channel") or entry.get("uploader"),
                "channel_id": entry.get("channel_id"),
                "url": entry.get("url") if str(entry.get("url", "")).startswith("http") else f"https://www.youtube.com/watch?v={entry.get('id')}",
                "views": entry.get("view_count"),
                "duration_seconds": entry.get("duration"),
                "published_date": entry.get("upload_date"),
            }
        )
    return discovered


def download_verified_video(video_id: str, db_path: Path | None = None) -> Path:
    yt_dlp = _load_yt_dlp()
    with connect(db_path or DEFAULT_DB) as conn:
        row = conn.execute(
            "SELECT video_id, url, license_status FROM videos WHERE video_id=?", (video_id,)
        ).fetchone()
    if not row:
        raise ValueError(f"Video {video_id} is not in the catalog")
    if row["license_status"] != "verified_cc":
        raise PermissionError(f"Video {video_id} is blocked: license status is {row['license_status']}")
    destination = ROOT / "data" / "downloads"
    destination.mkdir(parents=True, exist_ok=True)
    output_template = str(destination / f"{video_id}.%(ext)s")
    options = {
        "format": "bv*[height<=1080]+ba/b[height<=1080]",
        "merge_output_format": "mp4",
        "outtmpl": output_template,
        "quiet": False,
        "noplaylist": True,
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(row["url"], download=True)
        prepared = Path(ydl.prepare_filename(info))
    merged = destination / f"{video_id}.mp4"
    return merged if merged.exists() else prepared
