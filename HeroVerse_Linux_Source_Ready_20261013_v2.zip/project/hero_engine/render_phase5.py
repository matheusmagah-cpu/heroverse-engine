from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from .phase6_render_contract import PALETTE_QP1_SEGMENT_RENDERER, segment_encoder_arguments
from .atomic_io import atomic_write_utf8
from .production_capacity import Phase6ResourcePreparation
from .phase6_asset_residency import validate_phase6_rights_evidence


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"
FONT_CANDIDATES = [
    Path(r"C:\Windows\Fonts\bahnschrift.ttf"),
    Path(r"C:\Windows\Fonts\arialbd.ttf"),
    Path(r"C:\Windows\Fonts\arial.ttf"),
]
OUTPUT_FPS = 30


def verify_static_voice_reuse(root: Path, target_plan: dict, voice_path: Path,
                              *, expected_voice_hash: str) -> dict[Path, str]:
    """Read-only projection of measured PCM, not approval of a new visual plan."""
    from . import phase6_media as media
    root = root.resolve()
    voice_path = voice_path.resolve()
    if not voice_path.is_relative_to(root):
        raise PermissionError('static voice source escaped root')
    raw = voice_path.read_bytes()
    if 'sha256:' + hashlib.sha256(raw).hexdigest() != expected_voice_hash:
        raise PermissionError('static voice source hash differs')
    voice = json.loads(raw)
    original = (root / media.BASE / 'audio/manifests' / f"{voice.get('voice_render_id')}.json").resolve()
    if not original.is_file() or original.read_bytes() != raw:
        raise PermissionError('static voice needs its immutable measured source')
    media._verify_voice_manifest_contract(root, voice)
    source_path = root / voice['take_plan']['path']
    source = media._read_bound_voice_file(source_path, voice['take_plan']['sha256'], 'original audio TakePlan')
    if (target_plan.get('format_pack_id') != 'fp-narrated-reflection-static'
            or not source.get('channel_id') or target_plan.get('channel_id') != source['channel_id']
            or len(target_plan.get('takes', [])) != len(source['takes'])):
        raise PermissionError('static voice channel/population differs')
    for old, new in zip(source['takes'], target_plan['takes'], strict=True):
        if any(new.get(key) != old.get(key) for key in ('take_id','narration','start_ms','end_ms')):
            raise PermissionError('static voice copy/order/timing differs')
    bindings = {voice_path: expected_voice_hash, original: expected_voice_hash,
                source_path.resolve(): voice['take_plan']['sha256'],
                (root / voice['narrative_script']['path']).resolve(): voice['narrative_script']['sha256'],
                (root / voice['model']).resolve(): voice['model_hash'],
                (root / 'models/kokoro/voices-v1.0.bin').resolve(): voice['voices_hash']}
    for row in voice['takes']:
        path = media._resolve(root, row['path'])
        if not path.is_relative_to(root): raise PermissionError('static WAV escaped root')
        bindings[path] = row['content_hash']
    if voice.get('codec_only_reuse'):
        reuse = voice['codec_only_reuse']
        for key in ('parent_voice','archived_take_plan'):
            entry = reuse[key]
            bindings[media._resolve(root, entry['path'])] = entry['sha256']
    for path, expected in bindings.items():
        if _sha256(path) != expected: raise PermissionError('static voice dependency changed during verification')
    return bindings


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _run(command: list[str]) -> None:
    result = subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True)
    if result.returncode:
        tail = "\n".join(result.stderr.splitlines()[-40:])
        raise RuntimeError(f"command failed ({result.returncode}): {' '.join(command[:8])}\n{tail}")


def _ffmpeg_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels", "-of", "json", str(path)],
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    return json.loads(result.stdout)


def _fps(value: str) -> float:
    numerator, denominator = value.split("/", 1)
    return float(numerator) / float(denominator)


def _frame_count_for_duration_ms(duration_ms: int, fps: int = OUTPUT_FPS) -> int:
    exact = duration_ms * fps / 1000.0
    rounded = round(exact)
    if rounded < 1 or not math.isclose(exact, rounded, abs_tol=1e-9):
        raise ValueError(f"duration {duration_ms} ms is not exactly representable at {fps} fps")
    return rounded


def _parse_origin(origin: str) -> tuple[Path, float, float]:
    path_text, range_text = origin.rsplit("#t=", 1)
    start_text, end_text = range_text.split(",", 1)
    return Path(path_text), float(start_text), float(end_text)


def _asset_id_for_path(path: Path) -> str:
    match = re.search(r"(asset-commons-[a-f0-9]+)", path.name)
    return match.group(1) if match else path.stem


def _font_path() -> Path:
    for candidate in FONT_CANDIDATES:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError("Bahnschrift/Arial font was not found")


def _write_concat(path: Path, files: list[Path]) -> None:
    lines = ["file '" + str(item.resolve()).replace("'", "''") + "'" for item in files]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _recover_static_render(root: Path, package: Path, bindings: dict[str, Any]) -> dict[str, Any]:
    """Read the completed native operation; never dispatch a codec to recover it."""
    from .standard_qualification_phase5 import verify_audio_static_execution

    required = {'render_manifest': 'render_manifest.json',
                'render_inputs': 'render-input-bindings.json',
                'render_execution': 'resource-observation.json'}
    if set(bindings) != set(required):
        raise PermissionError('Static recovery requires exact manifest/input/execution anchors')
    captured = {}
    for name, filename in required.items():
        row = bindings[name]
        target = (package / filename).resolve()
        if set(row) != {'path', 'sha256'} or Path(row['path']).resolve() != target:
            raise PermissionError('Static recovery anchor path differs: ' + name)
        raw = target.read_bytes()
        if row['sha256'] != 'sha256:' + hashlib.sha256(raw).hexdigest():
            raise PermissionError('Static recovery anchor differs: ' + name)
        captured[target] = raw
    manifest = json.loads(captured[(package / 'render_manifest.json').resolve()])
    evidence = json.loads(captured[(package / 'render-input-bindings.json').resolve()])
    Draft202012Validator(_read_json(root / 'schemas/render_manifest.schema.json')).validate(manifest)
    plan = _read_json(package / 'take_plan.json')
    voice = _read_json(package / 'audio/voice_render_manifest.json')
    if (manifest['status'] != 'COMPLETE' or manifest['publication_approved'] is not False
            or evidence.get('render_id') != manifest['render_id']
            or evidence.get('production_authorized') is not False
            or evidence.get('publication_authorized') is not False
            or manifest['voice_render_id'] != voice['voice_render_id']
            or any(manifest[key] != plan[key] for key in
                   ('take_plan_id', 'style_bible_id', 'format_pack_id', 'format_pack_version', 'video_id'))):
        raise PermissionError('Static recovered render identity/authority differs')
    seen = set()
    for row in evidence['inputs']:
        path = Path(row['path']).resolve()
        if (not path.is_relative_to(root) or path in seen
                or _sha256(path) != row['sha256']):
            raise PermissionError('Static recovered input changed or duplicated')
        seen.add(path)
    critical = {package / name for name in ('take_plan.json', 'channel_style_bible.json',
                                           'audio/voice_render_manifest.json', 'asset_manifest.json')}
    critical.add(root / 'config/macro_pipelines/pipeline-audio-static-longform-v1.json')
    if not {path.resolve() for path in critical}.issubset(seen):
        raise PermissionError('Static recovered input population incomplete')
    media = Path(manifest['output']['path']).resolve()
    if (not media.is_relative_to(package) or _sha256(media) != manifest['output']['content_hash']
            or media.stat().st_size != manifest['output']['size_bytes']
            or manifest['render_id'] != 'render-' + hashlib.sha256(
                f"{plan['take_plan_id']}|{manifest['output']['content_hash']}".encode()).hexdigest()[:20]):
        raise PermissionError('Static recovered media/identity differs')
    verify_audio_static_execution(root, package, media, binding=bindings['render_execution'])
    for path, raw in captured.items():
        if path.read_bytes() != raw:
            raise PermissionError('Static recovery evidence changed before return')
    for row in evidence['inputs']:
        if _sha256(Path(row['path'])) != row['sha256']:
            raise PermissionError('Static recovery input changed before return')
    return manifest


def _recover_static_receipt(root: Path, package: Path, bindings: dict[str, Any]) -> dict[str, Any]:
    """Close a post-codec failure using original observations, never a new codec."""
    from .standard_qualification_phase5 import verify_audio_static_execution
    captured = {}
    for name, row in bindings.items():
        if set(row) != {'path', 'sha256'}:
            raise PermissionError('Receipt recovery needs exact external anchors')
        path = Path(row['path']).resolve()
        if (name == 'render_execution' and path != package / 'resource-observation.json'
                or name == 'render_operation' and not path.is_relative_to(
                    root / 'output/runtime/gestor-central/maintenance-runs')):
            raise PermissionError('Receipt recovery anchor path differs')
        raw = path.read_bytes()
        if row['sha256'] != 'sha256:' + hashlib.sha256(raw).hexdigest():
            raise PermissionError('Receipt recovery anchor differs: ' + name)
        captured[path] = raw
    operation = json.loads(captured[Path(bindings['render_operation']['path']).resolve()])
    required = {'take_plan.json', 'audio/voice_render_manifest.json',
                'asset_manifest.json', 'channel_style_bible.json'}
    if (operation.get('operation') != 'RENDER' or set(operation.get('inputs', {})) != required
            or operation.get('result', {}).get('expected', {}).get('publication_effects') != 0):
        raise PermissionError('Original render operation identity differs')
    for name, row in operation['inputs'].items():
        target = (root / row['path']).resolve()
        if target != (package / name).resolve() or _sha256(target) != row['sha256']:
            raise PermissionError('Original render input changed: ' + name)
    media = package / 'renders/move-after-amen.phase5-draft.mp4'
    verify_audio_static_execution(root, package, media, binding=bindings['render_execution'])
    observations = json.loads(captured[package / 'resource-observation.json'])
    executions = [row['execution'] for row in observations['observations'] if 'execution' in row]
    return _render_phase5_pilot(root, package_relative=package.relative_to(root),
        completed_executions=executions, recovery_anchors=captured)


def render_phase5_pilot(root: Path, *, created_at: str | None = None,
                        package_relative: Path | None = None,
                        recovery_bindings: dict[str, Any] | None = None,
                        music_bindings: dict[str, dict[str, str]] | None = None) -> dict[str, Any]:
    """The existing public entry; static work uses the existing serial resource scope."""
    root = root.resolve()
    offered = Path(package_relative) if package_relative is not None else Path("output/production/phase5/pilot-001")
    if offered.is_absolute() or ".." in offered.parts:
        raise PermissionError("pilot package must be workspace-relative")
    package = (root / offered).resolve()
    if not package.is_relative_to((root / "output/production").resolve()):
        raise PermissionError("pilot package escaped production root")
    if music_bindings is not None:
        if package_relative is None or recovery_bindings is not None:
            raise PermissionError('instrumental render cannot substitute legacy receipt recovery')
        return _render_rest_music(root, package, music_bindings=music_bindings,
                                  created_at=created_at)
    plan_path = package / "take_plan.json"
    if _read_json(plan_path).get("format_pack_id") != "fp-narrated-reflection-static":
        if recovery_bindings is not None:
            raise PermissionError('Static recovery cannot substitute a legacy render')
        return _render_phase5_pilot(root, created_at=created_at, package_relative=package_relative)
    resources = Phase6ResourcePreparation(root, plan_path=plan_path)
    if recovery_bindings is not None:
        resources._unpaused()
        if set(recovery_bindings) == {'render_execution', 'render_operation'}:
            return _recover_static_receipt(root, package, json.loads(json.dumps(recovery_bindings)))
        return _recover_static_render(root, package, json.loads(json.dumps(recovery_bindings)))
    with resources:
        try:
            return _render_phase5_pilot(root, created_at=created_at,
                package_relative=package_relative, resources=resources)
        finally:
            if resources.observations:
                atomic_write_utf8(package / "resource-observation.json",
                    json.dumps({"observations": resources.observations, "quality_approval": False}, indent=2) + "\n")


def _rest_render_inputs(root: Path, package: Path,
                        bindings: dict[str, dict[str, str]]) -> tuple[dict, dict, dict[Path, str]]:
    """Reuse current music and admitted static readers; never borrow a voice PASS."""
    from .qa_phase5 import verify_rest_music_source
    from .asset_quality_phase5 import verify_audio_static_asset_admission
    if not isinstance(bindings, dict) or set(bindings) != {'recipe','source','asset'}:
        raise PermissionError('instrumental render needs three exact input bindings')
    anchors = {}
    for ref in bindings.values():
        if (not isinstance(ref,dict) or set(ref) != {'path','sha256'}
                or not re.fullmatch(r'sha256:[0-9a-f]{64}',ref.get('sha256',''))):
            raise PermissionError('instrumental render binding malformed')
        path = Path(ref['path']).resolve()
        if not path.is_relative_to(root) or _sha256(path) != ref['sha256']:
            raise PermissionError('instrumental render input anchor differs')
        anchors[path] = ref['sha256']
    music = verify_rest_music_source(root, package_relative=package.relative_to(root),
        recipe_binding=bindings['recipe'],source_binding=bindings['source'])
    asset = _read_json(Path(bindings['asset']['path']))
    verify_audio_static_asset_admission(root, asset)
    image = Path(asset['uri']).resolve()
    right = Path(asset['rights_evidence_uri']).resolve()
    if not image.is_relative_to(root) or not right.is_relative_to(root):
        raise PermissionError('instrumental visual escaped root')
    evidence = _read_json(right)
    validate_phase6_rights_evidence(root,asset,evidence,media_path=image)
    if evidence.get('asset_type') != 'PROJECT_OWNED_PROCEDURAL_STATIC':
        raise PermissionError('instrumental image requires current static provenance')
    from .procedural_infographics_phase5 import read_audio_static_source
    ref = evidence['composition_manifest']
    visual = read_audio_static_source(root,Path(ref['path']),expected_sha256=ref['sha256'])
    bible = _read_json(package/'channel_style_bible.json')
    if visual['layout']['style_bible'] != bible:
        raise PermissionError('instrumental visual style differs from current channel Bible')
    anchors.update({Path(row['path']).resolve():row['sha256'] for row in music['inputs']})
    for path,digest in ((image,asset['content_hash']),(right,_sha256(right)),
            (Path(ref['path']).resolve(),ref['sha256']),
            (Path(evidence['source_svg']).resolve(),evidence['source_svg_hash'])):
        anchors[path] = digest
    for row in (visual['generator'],visual['layout']['font']):
        anchors[Path(row['path']).resolve()] = row['sha256']
    renderer = root/'hero_engine/render_phase5.py'
    if _sha256(renderer) != _sha256(Path(__file__)):
        raise PermissionError('resident instrumental renderer differs from executed bytes')
    anchors[renderer] = _sha256(renderer)
    for target in (package/'renders',package/'renders/christian-rest.phase5-draft.mp4',
                   package/'music-render-execution.json',package/'render_manifest.json',
                   package/'instrumental-attribution.txt'):
        if not target.resolve().is_relative_to(package):
            raise PermissionError('instrumental output escaped package through alias')
    return music,asset,anchors


def read_rest_music_render(root: Path, *, package_relative: Path,
                           music_bindings: dict[str, dict[str, str]],
                           manifest_binding: dict[str,str]) -> dict[str,Any]:
    """Current output and actual execution, not a final quality/release approval."""
    root = root.resolve()
    offered = Path(package_relative)
    if offered.is_absolute() or '..' in offered.parts:
        raise PermissionError('instrumental package must be production-relative')
    package = (root/offered).resolve()
    manifest_path = package/'render_manifest.json'
    if (not package.is_relative_to(root/'output/production')
            or not isinstance(manifest_binding,dict) or set(manifest_binding) != {'path','sha256'}
            or Path(manifest_binding['path']).resolve() != manifest_path
            or _sha256(manifest_path) != manifest_binding['sha256']):
        raise PermissionError('instrumental render receipt anchor differs')
    raw = manifest_path.read_bytes(); manifest = json.loads(raw.decode('utf-8-sig'))
    Draft202012Validator(_read_json(root/'schemas/render_manifest.schema.json')).validate(manifest)
    music,asset,anchors = _rest_render_inputs(root,package,music_bindings)
    from .creative_direction import rest_delivery_format
    mode = rest_delivery_format(music['recipe'])
    voice_id = ('voice-rest-'+music['opening']['binding']['sha256'][7:27]
                if music['voice_required'] else None)
    output = package/'renders/christian-rest.phase5-draft.mp4'
    if (manifest['schema_version'] != mode['render_schema'] or manifest['status'] != 'COMPLETE'
            or manifest['format_pack_id'] != mode['format_pack_id']
            or manifest['pipeline_id'] != mode['pipeline_id']
            or manifest['quality_profile'] != 'DRAFT'
            or manifest['video_id'] != music['recipe']['recipe_id']
            or manifest['style_bible_id'] != _read_json(package/'channel_style_bible.json')['style_bible_id']
            or manifest['adapter_versions'] != [PALETTE_QP1_SEGMENT_RENDERER,music['music']['generator']]
            or manifest['music_inputs'] != music_bindings
            or manifest['voice_render_id'] != voice_id or manifest['take_plan_id'] is not None
            or manifest['source_asset_ids'] != [asset['asset_id']]
            or manifest['output']['path'] != str(output)
            or manifest['output']['content_hash'] != _sha256(output)
            or manifest['output']['size_bytes'] != output.stat().st_size):
        raise PermissionError('instrumental output identity differs')
    witness = manifest['render_execution']
    observation = Path(witness['path']).resolve()
    if observation != package/'music-render-execution.json' or _sha256(observation) != witness['sha256']:
        raise PermissionError('instrumental render execution anchor differs')
    execution = _read_json(observation)
    observations = execution['observations']
    if any('execution' in row and row.get('stage') not in ('ffmpeg','ffmpeg:static-capacity')
           for row in observations):
        raise PermissionError('instrumental render includes an unknown codec execution')
    rows = [row['execution'] for row in observations
            if 'execution' in row and row.get('stage') == 'ffmpeg']
    capacity_rows = [row for row in observations if row.get('stage') == 'ffmpeg:static-capacity']
    if len(capacity_rows) > 1:
        raise PermissionError('instrumental render includes duplicate capacity executions')
    if capacity_rows:
        from .production_capacity import verify_static_music_capacity_measurement
        capacity = capacity_rows[0]
        if capacity.get('static_capacity_measurement', {}).get('execution') != capacity.get('execution'):
            raise PermissionError('instrumental capacity witness is incomplete')
        verify_static_music_capacity_measurement(root, capacity['static_capacity_measurement'],
            duration_ms=music['music']['duration_ms'], image=Path(asset['uri']),
            audio=Path(music['music']['path']))
    command = _rest_render_command(Path(asset['uri']),Path(music['music']['path']),
                                   output,music['music']['duration_ms'])
    if len(rows) != 1 or rows[0].get('status') != 'COMPLETED' or rows[0].get('exit_code') != 0:
        raise PermissionError('instrumental render has no unique successful actual execution')
    row = rows[0]
    if (row['argv'] != command or row['cwd'] != str(root) or row['quality_approval'] is not False
            or row['output']['path'] != str(output)
            or row['output']['sha256'] != manifest['output']['content_hash']):
        raise PermissionError('instrumental render invocation differs')
    for binding in [row['executable'],*row['inputs'],row['output']]:
        path = Path(binding['path']).resolve()
        if path.stat().st_size != binding['size_bytes'] or _sha256(path) != binding['sha256']:
            raise PermissionError('instrumental codec witness bytes changed')
    if {r['path'] for r in row['inputs']} != {str(Path(asset['uri']).resolve()),music['music']['path']}:
        raise PermissionError('instrumental direct codec inputs differ')
    probe = _probe(output); video = next(s for s in probe['streams'] if s['codec_type']=='video')
    audio = next(s for s in probe['streams'] if s['codec_type']=='audio')
    duration = round(float(probe['format']['duration'])*1000)
    if (duration != manifest['output']['duration_ms']
            or abs(duration-music['music']['duration_ms']) > 1000/OUTPUT_FPS
            or (video['codec_name'],int(video['width']),int(video['height']),_fps(video['r_frame_rate']))
                != ('h264',1920,1080,30)
            or (audio['codec_name'],int(audio['sample_rate']),int(audio['channels'])) != ('aac',48000,2)):
        raise PermissionError('instrumental output clock or streams differ')
    if any(manifest['output'][key]!=value for key,value in {
            'container':'mp4','video_codec':'h264','audio_codec':'aac',
            'width':1920,'height':1080,'fps':30}.items()):
        raise PermissionError('instrumental stored stream observations differ from actual probe')
    elapsed = (datetime.fromisoformat(row['finished_at'].replace('Z','+00:00'))
        -datetime.fromisoformat(row['started_at'].replace('Z','+00:00'))).total_seconds()
    planned = music['music']['duration_ms']; drift = abs(duration-planned)
    expected_measurements = {'total_wall_seconds':elapsed,'video_segment_render_seconds':elapsed,
        'audio_assembly_seconds':0,'final_mux_seconds':elapsed,'real_time_factor':elapsed/(planned/1000),
        'peak_working_set_mb':None,'peak_working_set_status':'UNAVAILABLE','output_fps':30,
        'expected_total_frames':round(planned*30/1000),
        'maximum_take_duration_error_ms':drift,'maximum_cumulative_drift_ms':drift}
    if elapsed<0 or manifest['measurements']!=expected_measurements or manifest['segment_timeline'] != [
            {'take_id':'instrumental-hold','planned_start_ms':0,'planned_end_ms':planned,
             'actual_start_ms':0,'actual_end_ms':duration,'planned_duration_ms':planned,
             'actual_duration_ms':duration,'frame_count':round(planned*30/1000)}]:
        raise PermissionError('instrumental codec timing/coverage observation differs')
    attribution=package/'instrumental-attribution.txt'
    if manifest['attribution_path']!=str(attribution) or attribution.read_text(encoding='utf-8') != (
            'HeroVerse owned procedural music and static composition. Not a quality or publication approval.\n'):
        raise PermissionError('instrumental attribution differs')
    expected_id = 'render-rest-'+hashlib.sha256(
        (music['recipe']['recipe_id']+'|'+_sha256(output)).encode()).hexdigest()[:20]
    if manifest['render_id'] != expected_id:
        raise PermissionError('instrumental render deterministic identity differs')
    if (manifest_path.read_bytes()!=raw or _sha256(observation)!=witness['sha256']
            or _sha256(output)!=manifest['output']['content_hash']
            or any(_sha256(p)!=h for p,h in anchors.items())):
        raise PermissionError('instrumental inputs changed before render consumption')
    return {'status':('AUTHENTICATED_EDITORIAL_REST_RENDER_NOT_RELEASE' if music['voice_required'] else 'AUTHENTICATED_INSTRUMENTAL_RENDER_NOT_RELEASE'),'manifest':manifest,
        'music':music,'asset':asset,'quality_authorized':False,'publication_authorized':False}


def _rest_render_command(image: Path, music: Path, output: Path, duration_ms: int) -> list[str]:
    _frame_count_for_duration_ms(duration_ms)  # Existing frame-exact clock, not rounded intent.
    filters = ('scale=1920:1080:force_original_aspect_ratio=decrease:out_color_matrix=bt709:out_range=tv,'
        'pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p,'
        'setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709')
    return [str(Path(FFMPEG).resolve()),'-n','-hide_banner','-loglevel','error',
        '-loop','1','-framerate','30','-i',str(image.resolve()),'-i',str(music.resolve()),
        '-map','0:v:0','-map','1:a:0','-vf',filters,'-r','30',
        *segment_encoder_arguments(PALETTE_QP1_SEGMENT_RENDERER),
        '-af','loudnorm=I=-16:LRA=8:TP=-1.5',
        '-c:a','aac','-b:a','256k','-ar','48000','-ac','2',
        '-t',f'{duration_ms/1000:.3f}','-movflags','+faststart',str(output.resolve())]


def _render_rest_music(root: Path, package: Path, *, music_bindings: dict,
                       created_at: str | None) -> dict[str,Any]:
    from .production_capacity import measure_local_resources,ResourceWait
    from .phase6_asset_residency import _write_immutable
    music,asset,anchors = _rest_render_inputs(root,package,music_bindings)
    from .creative_direction import rest_delivery_format
    mode = rest_delivery_format(music['recipe'])
    relative = package.relative_to(root)
    manifest_path = package/'render_manifest.json'
    output = package/'renders/christian-rest.phase5-draft.mp4'
    if manifest_path.exists():
        return read_rest_music_render(root,package_relative=relative,music_bindings=music_bindings,
            manifest_binding={'path':str(manifest_path),'sha256':_sha256(manifest_path)})['manifest']
    if output.exists() or (package/'music-render-execution.json').exists():
        raise PermissionError('partial instrumental render preserved; reconcile before new execution')
    def unchanged():
        if any(_sha256(p)!=h for p,h in anchors.items()):
            raise PermissionError('instrumental inputs changed before effect/receipt')
    with Phase6ResourcePreparation(root,music_package_relative=relative,
                                  music_recipe_binding=music_bindings['recipe']) as scope:
        try:
            unchanged()
            scope.measure_static_music_capacity(Path(asset['uri']),Path(music['music']['path']),output.parent)
            samples = [measure_local_resources(root),measure_local_resources(root)]
            requirements = scope._requirements('ffmpeg')
            if any(scope._shortages(sample,requirements) for sample in samples):
                raise ResourceWait({'causes':['INSTRUMENTAL_RENDER_CAPACITY'],'samples':samples,
                                    'requirements':requirements,'next_check_seconds':60})
            scope._unpaused(); unchanged()
            output.parent.mkdir(exist_ok=True)
            command = _rest_render_command(Path(asset['uri']),Path(music['music']['path']),
                                           output,music['music']['duration_ms'])
            scope.run_ffmpeg(command,witness_output=output,
                witness_inputs=(Path(asset['uri']),Path(music['music']['path'])))
        finally:
            if scope.observations:
                _write_immutable(package/'music-render-execution.json',
                    {'observations':scope.observations,'quality_approval':False})
        unchanged(); probe = _probe(output)
        video = next(s for s in probe['streams'] if s['codec_type']=='video')
        audio = next(s for s in probe['streams'] if s['codec_type']=='audio')
        duration = round(float(probe['format']['duration'])*1000)
        planned = music['music']['duration_ms']; drift = abs(duration-planned)
        if drift>1000/OUTPUT_FPS or int(video['width'])!=1920 or int(video['height'])!=1080:
            raise PermissionError('instrumental mux clock or dimensions diverged')
        row = scope.observations[-1]['execution']
        elapsed = (datetime.fromisoformat(row['finished_at'].replace('Z','+00:00'))
            -datetime.fromisoformat(row['started_at'].replace('Z','+00:00'))).total_seconds()
        attribution = package/'instrumental-attribution.txt'
        with attribution.open('x',encoding='utf-8') as stream:
            stream.write('HeroVerse owned procedural music and static composition. Not a quality or publication approval.\n')
        bible = _read_json(package/'channel_style_bible.json')
        manifest = {'schema_version':mode['render_schema'],'status':'COMPLETE',
            'render_id':'render-rest-'+hashlib.sha256((music['recipe']['recipe_id']+'|'+_sha256(output)).encode()).hexdigest()[:20],
            'video_id':music['recipe']['recipe_id'],'quality_profile':'DRAFT',
            'pipeline_id':mode['pipeline_id'],'pipeline_version':'1.0.0',
            'format_pack_id':mode['format_pack_id'],'format_pack_version':'1.0.0',
            'take_plan_id':None,'style_bible_id':bible['style_bible_id'],
            'voice_render_id':('voice-rest-'+music['opening']['binding']['sha256'][7:27]
                               if music['voice_required'] else None),
            'adapter_versions':[PALETTE_QP1_SEGMENT_RENDERER,music['music']['generator']],
            'segment_count':1,'source_asset_ids':[asset['asset_id']],
            'music_inputs':music_bindings,
            'render_execution':{'path':str(package/'music-render-execution.json'),
                'sha256':_sha256(package/'music-render-execution.json')},
            'output':{'path':str(output),'content_hash':_sha256(output),'container':'mp4',
                'video_codec':video['codec_name'],'audio_codec':audio['codec_name'],
                'width':int(video['width']),'height':int(video['height']),'fps':_fps(video['r_frame_rate']),
                'duration_ms':duration,'size_bytes':output.stat().st_size},
            'measurements':{'total_wall_seconds':elapsed,'video_segment_render_seconds':elapsed,
                'audio_assembly_seconds':0,'final_mux_seconds':elapsed,'real_time_factor':elapsed/(planned/1000),
                'peak_working_set_mb':None,'peak_working_set_status':'UNAVAILABLE','output_fps':30,
                'expected_total_frames':round(planned*30/1000),
                'maximum_take_duration_error_ms':drift,'maximum_cumulative_drift_ms':drift},
            'segment_timeline':[{'take_id':'instrumental-hold','planned_start_ms':0,'planned_end_ms':planned,
                'actual_start_ms':0,'actual_end_ms':duration,'planned_duration_ms':planned,
                'actual_duration_ms':duration,'frame_count':round(planned*30/1000)}],
            'attribution_path':str(attribution),'external_cost_usd':0,'publication_approved':False,
            'limitations':['Editorial draft: source speech once, final speech/music/visual qualification and measured captions required; no release approval.'] if music['voice_required'] else
                ['Instrumental draft: no voice or captions, no final musical/visual quality or release approval.'],
            'created_at':created_at or datetime.now(timezone.utc).isoformat()}
        Draft202012Validator(_read_json(root/'schemas/render_manifest.schema.json')).validate(manifest)
        unchanged(); _write_immutable(manifest_path,manifest)
    return read_rest_music_render(root,package_relative=relative,music_bindings=music_bindings,
        manifest_binding={'path':str(manifest_path),'sha256':_sha256(manifest_path)})['manifest']


def _render_phase5_pilot(root: Path, *, created_at: str | None = None,
                         package_relative: Path | None = None, resources=None,
                         completed_executions=None, recovery_anchors=None) -> dict[str, Any]:
    """Render the controlled DRAFT without publishing or using a paid provider."""

    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    if package_relative is not None:
        offered = Path(package_relative)
        if offered.is_absolute() or ".." in offered.parts:
            raise PermissionError("pilot package must be workspace-relative")
        package_dir = (root / offered).resolve()
        if not package_dir.is_relative_to((root / "output/production").resolve()):
            raise PermissionError("pilot package escaped production root")
    input_bytes: dict[Path, bytes] = {}
    def load(path):
        raw = path.read_bytes()
        input_bytes[path.resolve()] = raw
        return json.loads(raw.decode("utf-8-sig"))
    plan = load(package_dir / "take_plan.json")
    bible = load(package_dir / "channel_style_bible.json")
    voice_manifest = load(package_dir / "audio" / "voice_render_manifest.json")
    assets = load(package_dir / "asset_manifest.json")
    static_audio = plan["format_pack_id"] == "fp-narrated-reflection-static"
    pipeline_name = "pipeline-audio-static-longform-v1.json" if static_audio else "pipeline-clips-longform-v1.json"
    pipeline_path = root / "config" / "macro_pipelines" / pipeline_name
    pipeline = load(pipeline_path)
    if plan["quality_profile"] != "DRAFT" or pipeline["status"] not in {"SPECIFIED", "PROTOTYPED"}:
        raise PermissionError("only a DRAFT prototype is permitted before pipeline validation")
    if voice_manifest["status"] != "COMPLETE" or voice_manifest["hook_timing_gate"] != "PASS":
        raise RuntimeError("voice manifest is incomplete or hook timing failed")
    if any(take["rights"]["status"] in {"UNKNOWN", "RESTRICTED", "EDITORIAL_REVIEW_REQUIRED"} for take in plan["takes"]):
        raise PermissionError("take plan contains a rights-blocked asset")

    # A forward static prototype reopens the independently bound source/voice
    # bytes before effects. It never rewrites or promotes the old pilot.
    bound_inputs: dict[Path, str] = {}
    static_sources: dict[str, tuple[Path, str]] = {}
    if static_audio:
        if (plan.get("render_profile") != PALETTE_QP1_SEGMENT_RENDERER
                or pipeline.get("supported_format_pack_ids") != [plan["format_pack_id"]]
                or pipeline.get("parameters", {}).get("publication_allowed") is not False
                or bible.get("style_bible_id") != plan["style_bible_id"]):
            raise PermissionError("static pilot identity/profile/pipeline differs")
        if ((package_dir / "render_manifest.json").exists()
                or (package_dir / 'render-input-bindings.json').exists()
                or ((package_dir / "render_work").exists() and completed_executions is None)):
            raise FileExistsError("existing static pilot must be reconciled, never rerendered blindly")
        bound_inputs.update({path: "sha256:" + hashlib.sha256(raw).hexdigest()
                             for path, raw in input_bytes.items()})
        if voice_manifest.get('schema_version') in {'1.2.0', '1.3.0'}:
            path = (package_dir / 'audio/voice_render_manifest.json').resolve()
            bound_inputs.update(verify_static_voice_reuse(root, plan, path,
                expected_voice_hash=bound_inputs[path]))
        asset_by_path = {Path(item["uri"]).resolve(): item for item in assets["assets"]}
        voice_rows = {row["take_id"]: row for row in voice_manifest["takes"]}
        if len(voice_rows) != len(voice_manifest["takes"]) or set(voice_rows) != {take["take_id"] for take in plan["takes"]}:
            raise PermissionError("static pilot voice/take population differs")
        for take in plan["takes"]:
            path_text, separator, expected = take["asset_origin"].rpartition("#still=")
            source = Path(path_text).resolve()
            asset = asset_by_path.get(source, {})
            if (not separator or not re.fullmatch(r"sha256:[0-9a-f]{64}", expected)
                    or not source.is_relative_to(root.resolve())
                    or source.suffix.lower() not in {".png", ".jpg", ".jpeg"}
                    or take["media_type"] != "GENERATED_IMAGE"
                    or take["rights"]["status"] != "OWNED"
                    or asset.get("rights_status") != "OWNED"
                    or asset.get("production_eligible") is not True
                    or asset.get("content_hash") != expected or _sha256(source) != expected
                    or asset.get("rights_evidence_uri") != take["rights"]["evidence_ref"]
                    or take.get("on_screen_text") or take.get("transition_in") or take.get("transition_out")):
                raise PermissionError("static pilot composition/rights binding differs")
            right_path = Path(take["rights"]["evidence_ref"])
            if not right_path.is_absolute():
                right_path = root / right_path
            right_path = right_path.resolve()
            if not right_path.is_relative_to(root.resolve()) or not right_path.is_file():
                raise PermissionError("static pilot rights evidence unavailable")
            right_document = load(right_path)
            validate_phase6_rights_evidence(root, asset, right_document, media_path=source)
            if right_document.get("asset_type") != "PROJECT_OWNED_PROCEDURAL_STATIC":
                raise PermissionError("static prototype requires exact static provenance, not a motion receipt")
            vector = Path(right_document["source_svg"])
            if not vector.is_absolute():
                vector = root / vector
            bound_inputs[vector.resolve()] = right_document["source_svg_hash"]
            if right_document.get('decision') == 'AUTO_VERIFIED_PROCEDURAL_SOURCE':
                from .procedural_infographics_phase5 import read_audio_static_source
                reference = right_document['composition_manifest']
                manifest_path = Path(reference['path']).resolve()
                produced = read_audio_static_source(root, manifest_path,
                                                    expected_sha256=reference['sha256'])
                bound_inputs[manifest_path] = reference['sha256']
                for entry in (produced['generator'], produced['layout']['font']):
                    bound_inputs[Path(entry['path']).resolve()] = entry['sha256']
            voice = voice_rows[take["take_id"]]
            voice_path = Path(voice["path"]).resolve()
            if (not voice_path.is_relative_to(root.resolve()) or not voice_path.is_file()
                    or _sha256(voice_path) != voice.get("content_hash")
                    or voice.get("text") != take.get("narration")
                    or voice.get("clipping") is not False or voice.get("fits_timeline_slot") is not True):
                raise PermissionError("static pilot voice bytes/text/timing differ")
            measured = round(float(_probe(voice_path)["format"]["duration"]) * 1000)
            if (measured <= 0 or measured != voice.get("duration_ms")
                    or measured > take["end_ms"] - take["start_ms"]):
                raise PermissionError("static pilot measured voice duration differs")
            bound_inputs.update({source: expected, voice_path: voice["content_hash"],
                                 right_path: "sha256:" + hashlib.sha256(input_bytes[right_path]).hexdigest()})
            static_sources[take["take_id"]] = (source, str(asset["asset_id"]))
        if len({row[0] for row in static_sources.values()}) != 1:
            raise PermissionError("static pilot must hold exactly one owned composition")

    replay_cursor = 0
    def run(command):
        nonlocal replay_cursor
        for path, expected in bound_inputs.items():
            if not path.is_file() or _sha256(path) != expected:
                raise PermissionError("static pilot input changed before effects")
        if completed_executions is not None:
            if replay_cursor >= len(completed_executions):
                raise PermissionError('Observed command coverage incomplete')
            observed = completed_executions[replay_cursor]
            if observed['argv'] != command:
                raise PermissionError('Observed command differs from current native producer')
            replay_cursor += 1
            return
        if static_audio:
            if resources is None:
                raise PermissionError("static pilot lacks its native serial resource scope")
            direct_inputs = tuple(dict.fromkeys(Path(command[index+1]).resolve()
                for index,value in enumerate(command[:-1]) if value=='-i'))
            resources.run_ffmpeg(command, witness_output=Path(command[-1]), witness_inputs=direct_inputs)
        else:
            _run(command)

    voice_by_take = {item["take_id"]: item for item in voice_manifest["takes"]}
    work_dir = package_dir / "render_work"
    video_dir = work_dir / "video_segments"
    audio_dir = work_dir / "audio_segments"
    video_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    font = _font_path()
    total_started = time.perf_counter()

    video_started = time.perf_counter()
    video_segments: list[Path] = []
    source_asset_ids: list[str] = []
    segment_timeline: list[dict[str, Any]] = []
    actual_cursor_ms = 0.0
    for take in plan["takes"]:
        take_id = take["take_id"]
        if static_audio:
            source_path, asset_id = static_sources[take_id]
            source_start, source_end = 0, None
        else:
            source_path, source_start, source_end = _parse_origin(take["asset_origin"])
        duration = (int(take["end_ms"]) - int(take["start_ms"])) / 1000.0
        frame_count = _frame_count_for_duration_ms(int(take["end_ms"]) - int(take["start_ms"]))
        if not source_path.is_file():
            raise FileNotFoundError(source_path)
        if source_end is not None and source_end - source_start + 0.002 < duration:
            raise ValueError(f"source allocation shorter than timeline slot for {take_id}")
        if not static_audio:
            asset_id = _asset_id_for_path(source_path)
        source_asset_ids.append(asset_id)
        output = video_dir / f"{take_id}.mp4"
        vf = [
            "scale=1920:1080:force_original_aspect_ratio=increase:out_color_matrix=bt709:out_range=tv",
            "crop=1920:1080",
            "fps=30",
            "setsar=1",
            "eq=contrast=1.07:saturation=0.76:brightness=-0.025:gamma=0.97",
            "colorbalance=bs=0.025:gs=-0.008:rs=-0.012",
            "vignette=angle=PI/5",
            "format=yuv420p",
            "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709",
        ]
        if static_audio:
            vf = ["scale=1920:1080:force_original_aspect_ratio=decrease:out_color_matrix=bt709:out_range=tv",
                  "pad=1920:1080:(ow-iw)/2:(oh-ih)/2", "setsar=1", "format=yuv420p",
                  "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709"]
        if take.get("on_screen_text"):
            text_path = work_dir / f"{take_id}.txt"
            text_path.write_text(str(take["on_screen_text"]), encoding="utf-8")
            size = 88 if take_id == "take-001" else 72
            vf.append(
                "drawtext="
                f"fontfile='{_ffmpeg_path(font)}':textfile='{_ffmpeg_path(text_path)}':"
                f"fontcolor=0xE8EDF2:fontsize={size}:borderw=3:bordercolor=0x081827@0.95:"
                "box=1:boxcolor=0x081827@0.58:boxborderw=28:"
                "x=(w-text_w)/2:y=(h-text_h)/2:line_spacing=12"
            )
        video_input = ["-loop", "1", "-framerate", str(OUTPUT_FPS), "-i", str(source_path)] if static_audio else ["-ss", f"{source_start:.3f}", "-i", str(source_path)]
        encoder = segment_encoder_arguments(PALETTE_QP1_SEGMENT_RENDERER) if static_audio else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p", "-g", "60", "-keyint_min", "30", "-sc_threshold", "0"]
        run(
            [
                FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                *video_input,
                "-an", "-vf", ",".join(vf), "-frames:v", str(frame_count), "-r", str(OUTPUT_FPS),
                *encoder, "-movflags", "+faststart", str(output),
            ]
        )
        segment_probe = _probe(output)
        actual_duration_ms = round(float(segment_probe["format"]["duration"]) * 1000, 6)
        planned_duration_ms = int(take["end_ms"]) - int(take["start_ms"])
        if abs(actual_duration_ms - planned_duration_ms) > (1000 / OUTPUT_FPS) / 2:
            raise RuntimeError(
                f"frame-locked segment {take_id} drifted by {actual_duration_ms - planned_duration_ms:.3f} ms"
            )
        segment_timeline.append(
            {
                "take_id": take_id,
                "planned_start_ms": int(take["start_ms"]),
                "planned_end_ms": int(take["end_ms"]),
                "actual_start_ms": round(actual_cursor_ms, 6),
                "actual_end_ms": round(actual_cursor_ms + actual_duration_ms, 6),
                "planned_duration_ms": planned_duration_ms,
                "actual_duration_ms": actual_duration_ms,
                "frame_count": frame_count,
            }
        )
        actual_cursor_ms += actual_duration_ms
        video_segments.append(output)
    video_segment_seconds = time.perf_counter() - video_started

    audio_started = time.perf_counter()
    audio_segments: list[Path] = []
    for take in plan["takes"]:
        take_id = take["take_id"]
        record = voice_by_take[take_id]
        duration = (int(take["end_ms"]) - int(take["start_ms"])) / 1000.0
        output = audio_dir / f"{take_id}.wav"
        run(
            [
                FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", record["path"],
                "-af", (
                    "aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo,"
                    "highpass=f=65,lowpass=f=15500,"
                    "acompressor=threshold=0.15:ratio=2.4:attack=18:release=180:makeup=1.25,"
                    f"apad,atrim=0:{duration:.3f}"
                ),
                "-c:a", "pcm_s16le", str(output),
            ]
        )
        audio_segments.append(output)

    video_concat_list = work_dir / "video-concat.txt"
    audio_concat_list = work_dir / "audio-concat.txt"
    if completed_executions is None:
        _write_concat(video_concat_list, video_segments)
        _write_concat(audio_concat_list, audio_segments)
    else:
        for path, files in ((video_concat_list, video_segments), (audio_concat_list, audio_segments)):
            expected = '\n'.join("file '" + str(item.resolve()).replace("'", "''") + "'" for item in files) + '\n'
            if path.read_text(encoding='utf-8') != expected:
                raise PermissionError('Observed concat order differs')
    silent_video = work_dir / "video-concat.mp4"
    narration = work_dir / "narration.wav"
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(video_concat_list), "-c", "copy", str(silent_video)])
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(audio_concat_list), "-c:a", "pcm_s16le", str(narration)])
    audio_assembly_seconds = time.perf_counter() - audio_started

    final_started = time.perf_counter()
    output_dir = package_dir / "renders"
    output_dir.mkdir(parents=True, exist_ok=True)
    draft_path = output_dir / "move-after-amen.phase5-draft.mp4"
    duration_seconds = int(plan["takes"][-1]["end_ms"]) / 1000.0
    final_command = [
            FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(silent_video), "-i", str(narration),
            "-f", "lavfi", "-t", f"{duration_seconds:.3f}", "-i", "anoisesrc=color=pink:amplitude=0.014:sample_rate=48000",
            "-f", "lavfi", "-t", f"{duration_seconds:.3f}", "-i", "sine=frequency=55:sample_rate=48000",
            "-filter_complex", (
                "[1:a]volume=1.0[n];"
                "[2:a]highpass=f=80,lowpass=f=520,volume=0.10[amb];"
                "[3:a]lowpass=f=120,volume=0.0018[tone];"
                "[n][amb][tone]amix=inputs=3:duration=first:normalize=0,"
                "loudnorm=I=-16:LRA=8:TP=-1.5[aout]"
            ),
            "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
            "-t", f"{duration_seconds:.3f}", "-movflags", "+faststart", str(draft_path),
        ]
    if static_audio:
        final_command = [FFMPEG, "-n", "-hide_banner", "-loglevel", "error",
            "-i", str(silent_video), "-i", str(narration),
            "-filter_complex", "[1:a]loudnorm=I=-16:LRA=8:TP=-1.5[aout]",
            "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac",
            "-b:a", "192k", "-ar", "48000", "-ac", "2", "-t", f"{duration_seconds:.3f}",
            "-movflags", "+faststart", str(draft_path)]
    run(final_command)
    final_mux_seconds = time.perf_counter() - final_started
    total_wall_seconds = time.perf_counter() - total_started
    if completed_executions is not None:
        if replay_cursor != len(completed_executions):
            raise PermissionError('Extra observed command cannot close receipt')
        def elapsed(row):
            return (datetime.fromisoformat(row['finished_at'].replace('Z', '+00:00'))
                    - datetime.fromisoformat(row['started_at'].replace('Z', '+00:00'))).total_seconds()
        video_segment_seconds = sum(elapsed(row) for row in completed_executions[:len(plan['takes'])])
        audio_assembly_seconds = sum(elapsed(row) for row in completed_executions[len(plan['takes']):-1])
        final_mux_seconds = elapsed(completed_executions[-1])
        total_wall_seconds = (datetime.fromisoformat(completed_executions[-1]['finished_at'].replace('Z', '+00:00'))
            - datetime.fromisoformat(completed_executions[0]['started_at'].replace('Z', '+00:00'))).total_seconds()
        from .standard_qualification_phase5 import verify_audio_static_execution
        observation_path = package_dir / 'resource-observation.json'
        verify_audio_static_execution(root, package_dir, draft_path,
            binding={'path': str(observation_path), 'sha256': 'sha256:' + hashlib.sha256(recovery_anchors[observation_path]).hexdigest()})
        for path, raw in recovery_anchors.items():
            if path.read_bytes() != raw:
                raise PermissionError('Receipt recovery evidence changed before publication')

    used_assets = {item["asset_id"]: item for item in assets["assets"] if item["asset_id"] in set(source_asset_ids)}
    attribution_path = package_dir / "attribution.txt"
    attribution_lines = [
        "HeroVerse Phase 5 controlled local prototype — source attribution",
        "This file is part of the rights record and does not authorize publication by itself.",
        "",
    ]
    for asset_id in sorted(used_assets):
        asset = used_assets[asset_id]
        if static_audio:
            # Owned-static provenance was authenticated before each codec call.
            # Its contract has uri/rights, not borrowed-footage attribution.
            # Do not invent a creator, license or a legacy source field.
            attribution_lines.extend([
                asset_id,
                f"Source: {asset['uri']}",
                f"Rights status: {asset['rights_status']}",
                f"Rights evidence: {asset['rights_evidence_uri']}",
                "Final audiovisual quality and publication remain separately gated.",
                "",
            ])
            continue
        attribution_lines.extend(
            [
                asset_id,
                f"Source: {asset['source']}",
                f"Creator/holder: {asset['creator_or_holder']}",
                f"License: {asset['license']}",
                f"Required attribution: {asset.get('attribution') or 'None recorded'}",
                f"Rights evidence: {asset['rights_evidence_uri']}",
                "",
            ]
        )
    attribution_path.write_text("\n".join(attribution_lines), encoding="utf-8")

    probe = _probe(draft_path)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    measured_duration_ms = round(float(probe["format"]["duration"]) * 1000)
    maximum_take_duration_error_ms = max(
        abs(item["planned_duration_ms"] - item["actual_duration_ms"])
        for item in segment_timeline
    )
    maximum_cumulative_drift_ms = max(
        abs(item["planned_end_ms"] - item["actual_end_ms"])
        for item in segment_timeline
    )
    render_id = "render-" + hashlib.sha256(f"{plan['take_plan_id']}|{_sha256(draft_path)}".encode("utf-8")).hexdigest()[:20]
    manifest = {
        "schema_version": "1.0.0",
        "render_id": render_id,
        "status": "COMPLETE",
        "video_id": plan["video_id"],
        "quality_profile": plan["quality_profile"],
        "pipeline_id": pipeline["pipeline_id"],
        "pipeline_version": pipeline["version"],
        "format_pack_id": plan["format_pack_id"],
        "format_pack_version": plan["format_pack_version"],
        "take_plan_id": plan["take_plan_id"],
        "style_bible_id": bible["style_bible_id"],
        "voice_render_id": voice_manifest["voice_render_id"],
        "adapter_versions": ["adapter-ffmpeg-local@N-120725-g1ad97b82f3-20250813", "adapter-local-voice@KokoroFloatSpeed-1.0.0"],
        "segment_count": len(video_segments),
        "source_asset_ids": sorted(set(source_asset_ids)),
        "output": {
            "path": str(draft_path.resolve()),
            "content_hash": _sha256(draft_path),
            "container": "mp4",
            "video_codec": video["codec_name"],
            "audio_codec": audio["codec_name"],
            "width": int(video["width"]),
            "height": int(video["height"]),
            "fps": round(_fps(video["r_frame_rate"]), 6),
            "duration_ms": measured_duration_ms,
            "size_bytes": draft_path.stat().st_size,
        },
        "measurements": {
            "total_wall_seconds": round(total_wall_seconds, 6),
            "video_segment_render_seconds": round(video_segment_seconds, 6),
            "audio_assembly_seconds": round(audio_assembly_seconds, 6),
            "final_mux_seconds": round(final_mux_seconds, 6),
            "real_time_factor": round(total_wall_seconds / (measured_duration_ms / 1000.0), 6),
            "peak_working_set_mb": None,
            "peak_working_set_status": "UNAVAILABLE",
            "output_fps": OUTPUT_FPS,
            "expected_total_frames": sum(item["frame_count"] for item in segment_timeline),
            "maximum_take_duration_error_ms": round(maximum_take_duration_error_ms, 6),
            "maximum_cumulative_drift_ms": round(maximum_cumulative_drift_ms, 6),
        },
        "segment_timeline": segment_timeline,
        "attribution_path": str(attribution_path.resolve()),
        "external_cost_usd": 0,
        "publication_approved": False,
        "limitations": [
            "DRAFT prototype; the FormatPack and pipeline are not yet validated or production-ready.",
            "No independent human full-video review has occurred.",
            "Automatic defect and creative quality gates must still run.",
            "Procedural ambience is locally synthesized; mix quality is unreviewed.",
        ],
        "created_at": timestamp,
    }
    schema = _read_json(root / "schemas" / "render_manifest.schema.json")
    Draft202012Validator(schema).validate(manifest)
    if static_audio:
        for path, expected in bound_inputs.items():
            if _sha256(path) != expected:
                raise PermissionError("static pilot input changed before receipt publication")
        manifest["limitations"] = ["DRAFT static prototype, not release or publication approval.",
            "Original audio/static rights and quality gates remain required; no recurring scene/motion claim.",
            "No synthetic ambience added; narration reused without new synthesis."]
        if completed_executions is not None:
            manifest['limitations'].append('Receipt closed after codec completion; current input witness measured at recovery, not retroactively captured.')
        atomic_write_utf8(package_dir / "render-input-bindings.json", json.dumps(
            {"inputs": [{"path": str(path), "sha256": digest} for path, digest in bound_inputs.items()],
             "render_id": render_id, "production_authorized": False, "publication_authorized": False}, indent=2) + "\n")
    (package_dir / "render_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest
