from __future__ import annotations

import argparse
import copy
import csv
import json
import statistics
import sys
from pathlib import Path

from . import forecast as forecast_module
from .db import DEFAULT_DB, ROOT, connect, import_seed_data, initialize, load_config, rows, utc_now
from .decision import latest_decisions
from .evaluation.gold_standard import benchmark_analysis, benchmark_fixtures
from .mining.pipeline import FIXTURE_IDS, MinerConfig, MiningPipeline, OUTPUT_ROOT, read_json, write_json
from .mining.semantics import relpath
from .modeling import build_master_model, evaluate_edl_against_model
from .modeling_phase4 import materialize_channel_model
from .observatory import Phase3Config, run_phase3
from .planner import mine_clip_candidates, mine_hook_blueprint, modeled_long_edl, pilot_short_edl, save_production
from .publisher import prepare_upload, upload
from .quality import audit_production, save_quality_report
from .renderer import render_edl
from .shotlist import build_shotlist
from .youtube import audit_license, discover, download_verified_video, fetch_transcript, import_transcript


def _print_json(value) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, default=str))


def _forecast_context() -> tuple[dict, dict[str, object]]:
    config = load_config()
    samples = rows(
        """
        WITH ranked AS (
            SELECT *, ROW_NUMBER() OVER (
                PARTITION BY youtube_video_id
                ORDER BY COALESCE(age_hours, 0) DESC, captured_at DESC
            ) AS rn
            FROM performance_snapshots
        )
        SELECT * FROM ranked WHERE rn=1
        """
    )
    long_samples = [sample for sample in samples if sample["format"] == "long"]
    short_samples = [sample for sample in samples if sample["format"] == "short"]
    observed_long = len(long_samples)
    observed_short = len(short_samples)
    minimum = 10
    calibrated = observed_long >= minimum and observed_short >= minimum
    info: dict[str, object] = {
        "status": "calibrated" if calibrated else "prior_only",
        "observed_long_videos": observed_long,
        "observed_shorts": observed_short,
        "minimum_per_format": minimum,
        "interpretation": (
            "Scenario assumptions recalculated from the latest stored snapshot of each observed video."
            if calibrated
            else "Conditional scenario output; not yet calibrated to this channel's new format."
        ),
    }
    if not calibrated:
        return config, info

    def positive_values(items: list[dict], field: str) -> list[float]:
        return [float(item[field]) for item in items if item.get(field) is not None and float(item[field]) > 0]

    long_views = positive_values(long_samples, "views")
    short_views = positive_values(short_samples, "views")
    avd_minutes = [value / 60 for value in positive_values(long_samples, "average_view_duration_seconds")]
    all_views = sum(float(item.get("views") or 0) for item in samples)
    all_subscribers = sum(float(item.get("subscribers_gained") or 0) for item in samples)
    base_long = statistics.median(long_views) if long_views else 950.0
    base_short = statistics.median(short_views) if short_views else 550.0
    base_avd = statistics.median(avd_minutes) if avd_minutes else 5.0
    base_conversion = all_subscribers / all_views if all_views > 0 else 0.012
    long_breakout_threshold = max(base_long * 3, 5000)
    short_breakout_threshold = max(base_short * 3, 3000)
    long_breakouts = [value for value in long_views if value >= long_breakout_threshold]
    short_breakouts = [value for value in short_views if value >= short_breakout_threshold]
    # Beta smoothing keeps a small sample from producing an impossible 0% or 100% breakout prior.
    base_long_breakout_probability = (len(long_breakouts) + 1) / (len(long_views) + 20)
    base_short_breakout_probability = (len(short_breakouts) + 1) / (len(short_views) + 20)
    base_long_breakout_median = statistics.median(long_breakouts) if long_breakouts else max(base_long * 6, 10000)
    base_short_breakout_median = statistics.median(short_breakouts) if short_breakouts else max(base_short * 6, 6000)

    calibrated_config = copy.deepcopy(config)
    factors = {
        "conservative": (0.65, 0.75, 0.70, 0.65),
        "base": (1.00, 1.00, 1.00, 1.00),
        "upside": (1.50, 1.20, 1.30, 1.50),
    }
    for scenario in calibrated_config["forecast"]["scenarios"]:
        view_factor, avd_factor, conversion_factor, breakout_factor = factors[scenario["name"]]
        scenario["median_views_per_long"] = round(max(50, base_long * view_factor))
        scenario["median_views_per_short"] = round(max(50, base_short * view_factor))
        scenario["average_view_duration_minutes"] = round(min(12, max(1, base_avd * avd_factor)), 3)
        scenario["subscriber_conversion_rate"] = round(
            min(0.05, max(0.001, base_conversion * conversion_factor)), 6
        )
        scenario["breakout_probability_per_long"] = round(
            min(0.20, max(0.01, base_long_breakout_probability * breakout_factor)), 5
        )
        scenario["short_breakout_probability"] = round(
            min(0.20, max(0.01, base_short_breakout_probability * breakout_factor)), 5
        )
        scenario["breakout_median_views"] = round(max(
            scenario["median_views_per_long"] * 5,
            base_long_breakout_median * view_factor,
        ))
        scenario["short_breakout_median_views"] = round(max(
            scenario["median_views_per_short"] * 5,
            base_short_breakout_median * view_factor,
        ))

    info["method"] = "latest snapshot per distinct video; medians for views/AVD; weighted subscribers per view; beta-smoothed breakout frequency"
    info["base_observed_assumptions"] = {
        "median_views_per_long": round(base_long, 2),
        "median_views_per_short": round(base_short, 2),
        "average_view_duration_minutes": round(base_avd, 3),
        "subscriber_conversion_rate": round(base_conversion, 6),
        "breakout_probability_per_long": round(base_long_breakout_probability, 5),
        "short_breakout_probability": round(base_short_breakout_probability, 5),
    }
    return calibrated_config, info


def command_init(_: argparse.Namespace) -> None:
    result = import_seed_data()
    _print_json({"database": str(DEFAULT_DB), **result})


def command_catalog(args: argparse.Namespace) -> None:
    if args.kind == "channels":
        result = rows("SELECT * FROM channels ORDER BY role, subscribers DESC")
    elif args.kind == "sources":
        result = rows(
            """
            SELECT video_id, channel_handle, title, url, license_status,
                   license_evidence, verified_at, views, duration_seconds, notes
            FROM videos ORDER BY license_status, views DESC
            """
        )
    else:
        result = rows("SELECT * FROM productions ORDER BY created_at DESC")
    _print_json(result)


def command_forecast(args: argparse.Namespace) -> None:
    config, calibration = _forecast_context()
    forecasts = forecast_module.all_scenarios(config, args.days, calibration)
    output_dir = ROOT / "output" / "reports"
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"forecast-{args.days}d.json"
    md_path = output_dir / f"forecast-{args.days}d.md"
    json_path.write_text(json.dumps(forecasts, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(forecast_module.markdown_report(config, forecasts), encoding="utf-8")
    with connect() as conn:
        for result in forecasts:
            conn.execute(
                "INSERT INTO daily_forecasts (generated_at, scenario, horizon_days, payload) VALUES (?, ?, ?, ?)",
                (utc_now(), result["scenario"], args.days, forecast_module.serialize(result)),
            )
    _print_json({"json": str(json_path), "markdown": str(md_path), "forecasts": forecasts})


def command_audit(args: argparse.Namespace) -> None:
    targets = [args.video_id]
    if args.video_id == "all":
        targets = [row["video_id"] for row in rows("SELECT video_id FROM videos WHERE role='source'")]
    results = []
    for target in targets:
        try:
            results.append({"ok": True, **audit_license(target)})
        except Exception as exc:
            results.append({"ok": False, "video_id": target, "error": str(exc)})
    _print_json(results)


def command_transcript(args: argparse.Namespace) -> None:
    _print_json(fetch_transcript(args.video_id, args.language))


def command_import_transcript(args: argparse.Namespace) -> None:
    _print_json(import_transcript(args.video_id, Path(args.path), args.language))


def command_mine_clips(args: argparse.Namespace) -> None:
    _print_json(mine_clip_candidates(args.video_id, args.min_seconds, args.max_seconds)[: args.limit])


def command_mine_hook(args: argparse.Namespace) -> None:
    _print_json(mine_hook_blueprint(args.video_id, args.window_seconds))


def _miner_config(args: argparse.Namespace) -> MinerConfig:
    return MinerConfig(
        transcription_model=args.model,
        transcription_beam_size=args.beam_size,
        scene_threshold=args.scene_threshold,
        ocr_minimum_confidence=args.ocr_confidence,
        keyframe_width=args.keyframe_width,
    )


def command_mine_video(args: argparse.Namespace) -> None:
    pipeline = MiningPipeline(_miner_config(args))
    first = pipeline.mine(args.video_id)
    replay = pipeline.mine(args.video_id)
    first["consistency_verified"] = bool(
        replay["cache_hit"] and replay["semantic_hash"] == first["semantic_hash"]
    )
    benchmark = benchmark_analysis(
        Path(first["analysis"]), Path(first["manifest"]),
        cache_consistent=first["consistency_verified"],
    )
    pipeline_version = read_json(Path(first["manifest"]))["pipeline_version"]
    benchmark_path = OUTPUT_ROOT / "benchmarks" / pipeline_version / f"{args.video_id}.json"
    write_json(benchmark_path, benchmark)
    _print_json({
        **first,
        "benchmark": str(benchmark_path),
        "benchmark_decision": benchmark["decision"],
        "passed_metrics": sum(metric["passed"] for metric in benchmark["field_metrics"]),
        "total_metrics": len(benchmark["field_metrics"]),
    })


def command_mine_fixtures(args: argparse.Namespace) -> None:
    pipeline = MiningPipeline(_miner_config(args))
    results = [pipeline.mine(video_id) for video_id in FIXTURE_IDS]
    for result in results:
        replay = pipeline.mine(result["video_id"])
        result["consistency_verified"] = bool(
            replay["cache_hit"] and replay["semantic_hash"] == result["semantic_hash"]
        )
    evaluation = benchmark_fixtures(results)
    pipeline_version = evaluation["summary"]["pipeline_version"]
    active_run_path = OUTPUT_ROOT / "runs" / pipeline_version / "active_run.json"
    write_json(active_run_path, {
        "schema_version": "1.0.0",
        "status": "AWAITING_REVIEW",
        "pipeline_version": pipeline_version,
        "created_at": utc_now(),
        "fixtures": [
            {
                "video_id": result["video_id"],
                "job_key": result["job_key"],
                "cache_hit": result["cache_hit"],
                "consistency_verified": result["consistency_verified"],
                "analysis": relpath(Path(result["analysis"]), ROOT),
                "manifest": relpath(Path(result["manifest"]), ROOT),
                "semantic_hash": result["semantic_hash"],
            }
            for result in results
        ],
        "benchmark_summary": relpath(Path(evaluation["directory"]) / "summary.json", ROOT),
        "automatic_promotion_permitted": False,
    })
    _print_json({
        "status": "AWAITING_REVIEW",
        "fixtures": results,
        "benchmark_directory": evaluation["directory"],
        "active_run": str(active_run_path),
        "field_summary": evaluation["summary"]["field_summary"],
        "decisions": evaluation["summary"]["decisions"],
        "automatic_promotion_permitted": False,
    })


def command_observe_phase3(args: argparse.Namespace) -> None:
    _print_json(run_phase3(Phase3Config(run_id=args.run_id)))


def command_audio_market(args: argparse.Namespace) -> None:
    from .observatory.format_cohorts import compile_audio_market_cohorts
    report = compile_audio_market_cohorts(Path(args.snapshots), Path(args.classifications))
    if args.economics:
        assumptions = read_json(Path(args.economics))
        report["economics"] = forecast_module.audio_revenue_scenarios(**assumptions)
    _print_json(report)


def command_model_phase4(_: argparse.Namespace) -> None:
    _print_json(materialize_channel_model())


def command_pilot(_: argparse.Namespace) -> None:
    edl = pilot_short_edl()
    path = save_production(edl)
    _print_json({"slug": edl["slug"], "edl": str(path), "status": "planned"})


def command_build_model(_: argparse.Namespace) -> None:
    result = build_master_model()
    model = result["model"]
    _print_json(
        {
            "model_id": model["model_id"],
            "json": result["json_path"],
            "markdown": result["markdown_path"],
            "population": model["evidence"]["population"]["videos"],
            "top_opening_score": model["evidence"]["opening_gate_top_median_score"],
            "bottom_opening_score": model["evidence"]["opening_gate_bottom_median_score"],
        }
    )


def command_modeled_long(_: argparse.Namespace) -> None:
    model_result = build_master_model()
    edl = modeled_long_edl()
    preflight = evaluate_edl_against_model(edl, model_result["model"])
    edl["model_preflight"] = preflight
    edl["status"] = "model_preflight_passed" if preflight["passed"] else "model_preflight_failed"
    path = save_production(edl)
    shotlist_result = build_shotlist(path)
    report_dir = ROOT / "output" / "modeling" / "grace-grit-love"
    report_path = report_dir / f"preflight-{edl['slug']}.json"
    report_path.write_text(json.dumps(preflight, ensure_ascii=False, indent=2), encoding="utf-8")
    _print_json(
        {
            "slug": edl["slug"], "edl": str(path), "preflight": str(report_path),
            "shotlist": shotlist_result["json"], "shot_count": shotlist_result["payload"]["shot_count"],
            "asset_release_blocked": shotlist_result["payload"]["release_blocked"],
            **preflight,
        }
    )


def command_model_check(args: argparse.Namespace) -> None:
    model_result = build_master_model()
    edl_path = Path(args.edl)
    edl = json.loads(edl_path.read_text(encoding="utf-8"))
    _print_json(evaluate_edl_against_model(edl, model_result["model"]))


def command_shotlist(args: argparse.Namespace) -> None:
    result = build_shotlist(Path(args.edl))
    payload = result.pop("payload")
    _print_json(
        {
            **result,
            "slug": payload["slug"],
            "duration_seconds": payload["duration_seconds"],
            "shot_count": payload["shot_count"],
            "average_shot_length_seconds": payload["average_shot_length_seconds"],
            "release_blocked": payload["release_blocked"],
            "release_block_reason": payload["release_block_reason"],
        }
    )


def command_download(args: argparse.Namespace) -> None:
    print(download_verified_video(args.video_id))


def command_render(args: argparse.Namespace) -> None:
    if getattr(args, "pilot_package", None):
        if args.edl or args.source:
            raise ValueError("pilot-package cannot be mixed with an EDL or source override")
        from .render_phase5 import render_phase5_pilot
        recovery = None
        if args.render_recovery_bindings is not None or args.expected_recovery_hash is not None:
            import hashlib
            if args.render_recovery_bindings is None or args.expected_recovery_hash is None:
                raise PermissionError('Render recovery requires its external bindings anchor')
            path = (ROOT / args.render_recovery_bindings).resolve()
            if not path.is_relative_to(ROOT.resolve()):
                raise PermissionError('Render recovery bindings escaped project root')
            raw = path.read_bytes()
            if args.expected_recovery_hash != 'sha256:' + hashlib.sha256(raw).hexdigest():
                raise PermissionError('Render recovery bindings external anchor differs')
            recovery = json.loads(raw.decode('utf-8-sig'))
        kwargs = {'recovery_bindings': recovery} if recovery is not None else {}
        music_path=None;music_raw=None
        if args.music_bindings is not None or args.expected_music_bindings_hash is not None:
            import hashlib
            if recovery is not None or args.music_bindings is None or args.expected_music_bindings_hash is None:
                raise PermissionError('Instrumental render requires its exact bindings, not legacy recovery')
            music_path=(ROOT/args.music_bindings).resolve()
            if not music_path.is_relative_to(ROOT.resolve()):
                raise PermissionError('Instrumental render bindings escaped root')
            music_raw=music_path.read_bytes()
            if args.expected_music_bindings_hash!='sha256:'+hashlib.sha256(music_raw).hexdigest():
                raise PermissionError('Instrumental render bindings external anchor differs')
            kwargs['music_bindings']=json.loads(music_raw.decode('utf-8-sig'))
        result=render_phase5_pilot(ROOT, package_relative=Path(args.pilot_package), **kwargs)
        if music_path is not None and music_path.read_bytes()!=music_raw:
            raise PermissionError('Instrumental orchestration bindings changed during render')
        _print_json(result)
        return
    if args.music_bindings is not None or args.expected_music_bindings_hash is not None:
        raise PermissionError('Instrumental render requires an explicit native package')
    if args.render_recovery_bindings is not None or args.expected_recovery_hash is not None:
        raise PermissionError('Render recovery requires an explicit native pilot package')
    if not args.edl:
        raise ValueError("render requires an EDL or an explicit pilot-package")
    source_overrides = {}
    if args.source:
        video_id, file_path = args.source.split("=", 1)
        source_overrides[video_id] = Path(file_path)
    print(render_edl(Path(args.edl), source_overrides))


def command_quality(args: argparse.Namespace) -> None:
    report = audit_production(Path(args.edl), Path(args.render) if args.render else None)
    path = save_quality_report(report)
    _print_json({"report": str(path), **report})


def command_queue(args: argparse.Namespace) -> None:
    print(prepare_upload(args.slug, args.scheduled_at))


def command_approve(args: argparse.Namespace) -> None:
    with connect() as conn:
        changed = conn.execute(
            "UPDATE productions SET approval_required=0, approved_at=?, updated_at=? WHERE slug=?",
            (utc_now(), utc_now(), args.slug),
        ).rowcount
    if not changed:
        raise ValueError(f"Production not found: {args.slug}")
    _print_json({"slug": args.slug, "approved": True})


def command_publish(args: argparse.Namespace) -> None:
    result = upload(Path(args.queue_file), Path(args.credentials), Path(args.token), live=args.live)
    _print_json(result)


def command_discover(args: argparse.Namespace) -> None:
    result = discover(args.query, args.limit)
    output_dir = ROOT / "output" / "discovery"
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "latest.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    _print_json({"path": str(path), "results": result})


def command_record(args: argparse.Namespace) -> None:
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO performance_snapshots
            (youtube_video_id, format, captured_at, age_hours, impressions, views,
             engaged_views, watch_hours, subscribers_gained, ctr, intro_30s_rate,
             average_view_duration_seconds, average_percentage_viewed, viewed_rate,
             likes, comments, shares)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                args.video_id, args.format, utc_now(), args.age_hours, args.impressions,
                args.views, args.engaged_views, args.watch_hours, args.subscribers,
                args.ctr, args.intro_30s, args.avd_seconds, args.apv, args.viewed_rate,
                args.likes, args.comments, args.shares,
            ),
        )
    _print_json({"recorded": args.video_id, "captured_at": utc_now()})


def command_decide(args: argparse.Namespace) -> None:
    config, _ = _forecast_context()
    query = "SELECT * FROM performance_snapshots"
    params: tuple = ()
    if args.video_id != "all":
        query += " WHERE youtube_video_id=?"
        params = (args.video_id,)
    _print_json(latest_decisions(rows(query, params), config))


def command_export_data(_: argparse.Namespace) -> None:
    config, calibration = _forecast_context()
    forecasts = forecast_module.all_scenarios(
        config, config["channel"]["deadline_days"], calibration
    )
    payload = {
        "generated_at": utc_now(),
        "config": config,
        "channels": rows("SELECT * FROM channels ORDER BY role, subscribers DESC"),
        "videos": rows("SELECT * FROM videos ORDER BY role, views DESC"),
        "hooks": rows("SELECT * FROM hook_blueprints ORDER BY source_views DESC"),
        "channel_models": rows("SELECT * FROM channel_models ORDER BY updated_at DESC"),
        "model_videos": rows("SELECT * FROM model_videos ORDER BY model_id, views_per_day DESC"),
        "model_openings": rows("SELECT * FROM model_openings ORDER BY model_id, sample_tier DESC, semantic_score DESC"),
        "licenses": rows("SELECT * FROM license_audits ORDER BY audited_at DESC"),
        "productions": rows("SELECT * FROM productions ORDER BY created_at DESC"),
        "performance": rows("SELECT * FROM performance_snapshots ORDER BY captured_at DESC"),
        "decisions": latest_decisions(
            rows("SELECT * FROM performance_snapshots ORDER BY captured_at DESC"), config
        ),
        "forecasts": forecasts,
    }
    output_dir = ROOT / "output" / "data"
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "catalog.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(path)


def command_daily(args: argparse.Namespace) -> None:
    import_seed_data()
    model_result = build_master_model()
    modeled_preflight = None
    modeled_edl_path = ROOT / "output" / "edl" / "protect-your-identity-long-01.json"
    if not rows("SELECT 1 FROM productions WHERE slug='protect-your-identity-long-01'"):
        modeled_edl = modeled_long_edl()
        modeled_preflight = evaluate_edl_against_model(modeled_edl, model_result["model"])
        modeled_edl["model_preflight"] = modeled_preflight
        modeled_edl["status"] = "model_preflight_passed" if modeled_preflight["passed"] else "model_preflight_failed"
        modeled_edl_path = save_production(modeled_edl)
    shotlist_result = build_shotlist(modeled_edl_path)
    config, calibration = _forecast_context()
    horizon_days = int(config["channel"]["deadline_days"])
    forecasts = forecast_module.all_scenarios(
        config, horizon_days, calibration
    )
    output_dir = ROOT / "output" / "reports"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_text = forecast_module.markdown_report(config, forecasts)
    report = output_dir / "daily-latest.md"
    report.write_text(report_text, encoding="utf-8")
    (output_dir / f"forecast-{horizon_days}d.json").write_text(
        json.dumps(forecasts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8",
    )
    (output_dir / f"forecast-{horizon_days}d.md").write_text(report_text, encoding="utf-8")
    if not rows("SELECT 1 FROM productions WHERE slug='identity-attack-before-calling-short-01'"):
        save_production(pilot_short_edl())
    quality_results = []
    for production in rows(
        "SELECT slug, edl_path, render_path FROM productions WHERE render_path IS NOT NULL"
    ):
        try:
            quality_report = audit_production(Path(production["edl_path"]), Path(production["render_path"]))
            quality_path = save_quality_report(quality_report)
            quality_results.append(
                {
                    "slug": production["slug"],
                    "release_ready": quality_report["release_ready"],
                    "score": quality_report["score"],
                    "report": str(quality_path),
                }
            )
        except Exception as exc:
            quality_results.append({"slug": production["slug"], "release_ready": False, "error": str(exc)})
    command_export_data(args)
    performance_decisions = latest_decisions(
        rows("SELECT * FROM performance_snapshots ORDER BY captured_at DESC"), config
    )
    _print_json(
        {
            "daily_report": str(report),
            "status": "complete",
            "publish_mode": config["safety"]["publish_mode"],
            "channel_model": {
                "model_id": model_result["model"]["model_id"],
                "population": model_result["model"]["evidence"]["population"]["videos"],
                "modeled_long_preflight": modeled_preflight,
                "shotlist": {
                    "path": shotlist_result["json"],
                    "shots": shotlist_result["payload"]["shot_count"],
                    "release_blocked": shotlist_result["payload"]["release_blocked"],
                },
            },
            "quality": quality_results,
            "performance_decisions": performance_decisions,
        }
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hero-engine", description="HERO Engine automation CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="Initialize database and seed audited catalog")
    p.set_defaults(func=command_init)

    p = sub.add_parser("catalog", help="Inspect catalog")
    p.add_argument("kind", choices=["channels", "sources", "productions"])
    p.set_defaults(func=command_catalog)

    p = sub.add_parser("forecast", help="Generate deterministic and probabilistic forecast")
    p.add_argument("--days", type=int, default=21)
    p.set_defaults(func=command_forecast)

    p = sub.add_parser("audit", help="Re-audit Creative Commons license")
    p.add_argument("video_id", help="Catalog video id or 'all'")
    p.set_defaults(func=command_audit)

    p = sub.add_parser("transcript", help="Fetch public caption transcript")
    p.add_argument("video_id")
    p.add_argument("--language", default="en")
    p.set_defaults(func=command_transcript)

    p = sub.add_parser("import-transcript", help="Import a timestamped transcript exported from an audited page")
    p.add_argument("video_id")
    p.add_argument("path")
    p.add_argument("--language", default="en")
    p.set_defaults(func=command_import_transcript)

    p = sub.add_parser("mine-clips", help="Score transcript windows")
    p.add_argument("video_id")
    p.add_argument("--min-seconds", type=float, default=4)
    p.add_argument("--max-seconds", type=float, default=12)
    p.add_argument("--limit", type=int, default=15)
    p.set_defaults(func=command_mine_clips)

    p = sub.add_parser("mine-hook", help="Extract observable opening mechanics without copying wording")
    p.add_argument("video_id")
    p.add_argument("--window-seconds", type=float, default=18.0)
    p.set_defaults(func=command_mine_hook)

    def add_phase2_miner_options(command: argparse.ArgumentParser) -> None:
        command.add_argument("--model", default="base.en")
        command.add_argument("--beam-size", type=int, default=5)
        command.add_argument("--scene-threshold", type=float, default=0.25)
        command.add_argument("--ocr-confidence", type=float, default=0.70)
        command.add_argument("--keyframe-width", type=int, default=640)

    p = sub.add_parser("mine-video", help="Run the Phase 2 local miner on one approved fixture")
    p.add_argument("video_id", choices=FIXTURE_IDS)
    add_phase2_miner_options(p)
    p.set_defaults(func=command_mine_video)

    p = sub.add_parser("mine-fixtures", help="Mine, replay, and benchmark all four Phase 2 fixtures")
    add_phase2_miner_options(p)
    p.set_defaults(func=command_mine_fixtures)

    p = sub.add_parser("observe-phase3", help="Build the audited Phase 3 public observatory without media or spend")
    p.add_argument("--run-id", default="phase3-2026-09-02-catalog-v2")
    p.set_defaults(func=command_observe_phase3)

    p = sub.add_parser("model-phase4", help="Build the evidence-bound Phase 4 ChannelModel without producing media")
    p.set_defaults(func=command_model_phase4)

    p = sub.add_parser("pilot", help="Create the first production EDL")
    p.set_defaults(func=command_pilot)

    p = sub.add_parser("build-model", help="Build the empirical channel/format master model")
    p.set_defaults(func=command_build_model)

    p = sub.add_parser("modeled-long", help="Create the first 3–5 minute production from the master model")
    p.set_defaults(func=command_modeled_long)

    p = sub.add_parser("model-check", help="Check an EDL against the empirical master model")
    p.add_argument("edl")
    p.set_defaults(func=command_model_check)

    p = sub.add_parser("shotlist", help="Expand a modeled EDL into licensed-asset and audio slots")
    p.add_argument("edl")
    p.set_defaults(func=command_shotlist)

    p = sub.add_parser("download", help="Download only a verified reusable source")
    p.add_argument("video_id")
    p.set_defaults(func=command_download)

    p = sub.add_parser("render", help="Render an EDL locally")
    p.add_argument("edl", nargs="?")
    p.add_argument("--pilot-package", help="Existing native DRAFT producer; workspace-relative authenticated static package")
    p.add_argument('--music-bindings',type=Path,help='Exact instrumental recipe/source/admitted-image bindings')
    p.add_argument('--expected-music-bindings-hash',help='External SHA-256 anchor for instrumental bindings')
    p.add_argument('--render-recovery-bindings', type=Path, help='Existing native manifest/input/execution bindings; no re-encoding')
    p.add_argument('--expected-recovery-hash', help='Externally anchored SHA-256 of the recovery bindings file')
    p.add_argument("--source", help="Override as VIDEO_ID=C:\\path\\source.mp4")
    p.set_defaults(func=command_render)

    p = sub.add_parser("quality", help="Run objective editorial and technical release gates")
    p.add_argument("edl")
    p.add_argument("--render", help="Optional render override")
    p.set_defaults(func=command_quality)

    p = sub.add_parser("queue", help="Create upload payload in dry-run mode")
    p.add_argument("slug")
    p.add_argument("--scheduled-at", help="ISO-8601 UTC publishAt")
    p.set_defaults(func=command_queue)

    p = sub.add_parser("approve", help="Approve a reviewed production")
    p.add_argument("slug")
    p.set_defaults(func=command_approve)

    p = sub.add_parser("publish", help="Upload an approved production")
    p.add_argument("queue_file")
    p.add_argument("--credentials", default="credentials.json")
    p.add_argument("--token", default="token.json")
    p.add_argument("--live", action="store_true")
    p.set_defaults(func=command_publish)

    p = sub.add_parser("audio-market", help="Compare evidenced audio cells using public metadata only")
    p.add_argument("snapshots")
    p.add_argument("classifications")
    p.add_argument("--economics", help="Explicit USD assumptions; never observed competitor RPM")
    p.set_defaults(func=command_audio_market)

    p = sub.add_parser("discover", help="Mine recent YouTube results using optional yt-dlp")
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=25)
    p.set_defaults(func=command_discover)

    p = sub.add_parser("record", help="Record a Studio performance snapshot")
    p.add_argument("video_id")
    p.add_argument("--format", choices=["long", "short"], required=True)
    p.add_argument("--age-hours", type=float)
    p.add_argument("--impressions", type=int)
    p.add_argument("--views", type=int)
    p.add_argument("--engaged-views", type=int)
    p.add_argument("--watch-hours", type=float)
    p.add_argument("--subscribers", type=int)
    p.add_argument("--ctr", type=float)
    p.add_argument("--intro-30s", type=float)
    p.add_argument("--avd-seconds", type=float)
    p.add_argument("--apv", type=float)
    p.add_argument("--viewed-rate", type=float)
    p.add_argument("--likes", type=int)
    p.add_argument("--comments", type=int)
    p.add_argument("--shares", type=int)
    p.set_defaults(func=command_record)

    p = sub.add_parser("decide", help="Apply objective SCALE / ITERATE / STOP rules")
    p.add_argument("video_id", help="YouTube video id or 'all'")
    p.set_defaults(func=command_decide)

    p = sub.add_parser("export-data", help="Export workbook/report source JSON")
    p.set_defaults(func=command_export_data)

    p = sub.add_parser("daily", help="Run the safe daily pipeline")
    p.set_defaults(func=command_daily)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
