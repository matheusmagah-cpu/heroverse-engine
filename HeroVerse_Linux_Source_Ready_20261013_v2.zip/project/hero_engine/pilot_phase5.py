from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .continuity import build_visual_continuity_bible
from .creative_direction import choose_format_pack, load_format_packs
from .policy_phase5 import evaluate_phase5_command
from .take_planner import build_take_plan


SCRIPT_SECTIONS = [
    {
        "section_id": "S1",
        "role": "TITLE_ALIGNED_STAKE",
        "narrative_function": "first payoff and context",
        "text": (
            "Prayer can change the person who prays before it changes the problem they face. "
            "It can quiet panic, expose a motive, and make the next honest step visible. "
            "That does not mean every impulse after prayer is an instruction. It means prayer prepares you to test what comes next."
        ),
        "intended_emotion": "clarity",
        "semantic_role": "clarity",
        "retention_job": "pay off the opening claim before 30 seconds",
        "source_refs": ["brief:8_30S", "James 1:5"],
        "on_screen_text": "PRAYER PREPARES THE STEP",
    },
    {
        "section_id": "S2",
        "role": "PERSONAL_STAKES",
        "narrative_function": "recognizable hesitation",
        "text": (
            "You may know the moment. You ask for direction, but then wait for a feeling strong enough to remove every risk. "
            "You call the waiting wisdom, even when the next responsible action is already clear: apologize, make the call, close the door, begin the work, or ask for help. "
            "The delay feels spiritual because it happens after prayer. But sometimes it is fear asking for certainty that obedience never promised."
        ),
        "intended_emotion": "recognition",
        "semantic_role": "contemplation",
        "retention_job": "make the tension concrete without adding a second thesis",
        "source_refs": ["channel-model:B2", "brief:combined_promise"],
        "on_screen_text": "WAITING OR HIDING?",
    },
    {
        "section_id": "S3",
        "role": "MECHANISM_AND_PROOF",
        "narrative_function": "distinguish wisdom from paralysis",
        "text": (
            "James writes to people under pressure and tells them to ask God for wisdom. That context matters. "
            "Wisdom is not a private prediction machine. It is the capacity to live faithfully inside a real trial. "
            "Later, the same letter warns against hearing truth without doing it. The sequence is practical: ask, receive with humility, examine the response, and become a doer. "
            "Prayer and action are not rivals. Right action is one way tested wisdom becomes visible."
        ),
        "intended_emotion": "understanding",
        "semantic_role": "perspective",
        "retention_job": "close the first loop with context-preserving scriptural reasoning",
        "source_refs": ["James 1:2-8", "James 1:22-25"],
        "on_screen_text": "WISDOM BECOMES VISIBLE",
    },
    {
        "section_id": "S4",
        "role": "MECHANISM_AND_PROOF",
        "narrative_function": "separate impulse from faithful action",
        "text": (
            "This is also why movement alone is not proof. An impulsive choice can be fast and still be wrong. "
            "A faithful next step survives examination. It does not require you to twist Scripture, manipulate another person, pretend a guaranteed outcome, or call ego a divine command. "
            "It can be brave without being reckless. It can be small without being insignificant. Often it is the next truthful responsibility already within reach."
        ),
        "intended_emotion": "discernment",
        "semantic_role": "tension",
        "retention_job": "prevent a simplistic move-fast interpretation",
        "source_refs": ["channel-model:humble_certainty_boundaries", "format-pack:rights_and_brand_risks"],
        "on_screen_text": "MOVEMENT ISN'T PROOF",
    },
    {
        "section_id": "S5",
        "role": "REVERSAL_AND_ACTION",
        "narrative_function": "test one next step",
        "text": (
            "So test the step before you romanticize it. First, ask whether it agrees with the clearest truth you already know. "
            "If the move depends on deception, revenge, superiority, or a promise God never made, stop. "
            "Second, ask what responsibility the step accepts. Obedience usually carries a cost you can name: honesty, patience, service, restraint, courage, or repair. "
            "Third, reduce the step to something you can actually do today. Not the entire future. One accountable action."
        ),
        "intended_emotion": "agency",
        "semantic_role": "decision",
        "retention_job": "convert the thesis into a three-part decision tool",
        "source_refs": ["James 1:22-25", "channel-model:B4"],
        "on_screen_text": "TEST THE STEP",
    },
    {
        "section_id": "S6",
        "role": "REVERSAL_AND_ACTION",
        "narrative_function": "demonstrate bounded action",
        "text": (
            "If you prayed about a damaged relationship, the step may not be forcing reconciliation. It may be writing an honest apology with no demand attached. "
            "If you prayed about work, the step may not be quitting tonight. It may be preparing the application, learning the missing skill, or asking a precise question. "
            "If you prayed through fear, the step may be naming the fear to someone trustworthy and refusing the secret that keeps it powerful."
        ),
        "intended_emotion": "practical hope",
        "semantic_role": "progress",
        "retention_job": "give varied concrete examples without promising outcomes",
        "source_refs": ["channel-model:concrete_response", "brief:angle"],
        "on_screen_text": "ONE ACCOUNTABLE ACTION",
    },
    {
        "section_id": "S7",
        "role": "REVERSAL_AND_ACTION",
        "narrative_function": "reframe confidence",
        "text": (
            "Notice what these steps have in common. None of them controls another person. None guarantees the result. "
            "Each places your character inside the answer you are asking for. That is where confidence can begin to grow—not because the road became predictable, but because your next action became honest. "
            "You stop demanding a map of every mile and start becoming faithful with the ground beneath your feet."
        ),
        "intended_emotion": "earned courage",
        "semantic_role": "progress",
        "retention_job": "deliver the identity reversal before the close",
        "source_refs": ["channel-model:identity_reframe", "brief:payoff"],
        "on_screen_text": "HONEST BEFORE CERTAIN",
    },
    {
        "section_id": "S8",
        "role": "PROMISE_RESOLUTION",
        "narrative_function": "resolve the title promise",
        "text": (
            "Do not measure prayer only by what changed around you. Measure what became clearer within you: the motive you can release, the truth you can face, the responsibility you can accept, and the faithful step you can take. "
            "Then move without pretending the outcome is guaranteed. Move because the step has been tested, because it is truthful, and because waiting for perfect confidence would only hand fear another day."
        ),
        "intended_emotion": "resolution",
        "semantic_role": "renewal",
        "retention_job": "answer the exact promise without unsupported certainty",
        "source_refs": ["brief:payoff", "channel-model:B5"],
        "on_screen_text": "MOVE AFTER AMEN",
    },
    {
        "section_id": "S9",
        "role": "PROMISE_RESOLUTION",
        "narrative_function": "single reflective close",
        "text": (
            "What is one faithful action your prayer has already made clear? Name it. Test it. Take it. "
            "Amen is not the finish line. It is where a faithful response can begin."
        ),
        "intended_emotion": "quiet resolve",
        "semantic_role": "renewal",
        "retention_job": "leave one memorable question and no unrelated CTA",
        "source_refs": ["brief:combined_promise"],
        "on_screen_text": "NAME IT. TEST IT. TAKE IT.",
    },
]


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read_json(root / "schemas" / schema_name)
    Draft202012Validator(schema).validate(value)


def _word_count(text: str) -> int:
    return len(re.findall(r"\b[\w'’–-]+\b", text))


def _split_for_takes(text: str, maximum_words: int = 18) -> list[str]:
    clauses = [part.strip() for part in re.split(r"(?<=[.!?;:])\s+|(?<=,)\s+", text) if part.strip()]
    chunks: list[str] = []
    pending: list[str] = []
    for clause in clauses:
        words = clause.split()
        while len(words) > maximum_words:
            if pending:
                chunks.append(" ".join(pending))
                pending = []
            chunks.append(" ".join(words[:maximum_words]))
            words = words[maximum_words:]
        if not words:
            continue
        if pending and len(pending) + len(words) > maximum_words:
            chunks.append(" ".join(pending))
            pending = []
        pending.extend(words)
    if pending:
        chunks.append(" ".join(pending))
    return chunks


def _duration_for_text(text: str) -> int:
    # 2.35 words/s plus a measured-intent pause budget. This is an estimate; the
    # actual voice render later replaces it and hook windows must be measured.
    raw = (_word_count(text) / 2.35) * 1000 + 250
    return int(max(1_600, min(8_000, math.ceil(raw / 100) * 100)))


def build_narrative_script(brief: dict[str, Any], *, created_at: str) -> dict[str, Any]:
    hook_narration = [
        "Amen.",
        "Your next move reveals it.",
        "Confidence often comes after the first faithful step, not before it.",
    ]
    full_text = " ".join([*hook_narration, *[section["text"] for section in SCRIPT_SECTIONS]])
    word_count = _word_count(full_text)
    estimated_duration_ms = 8_000 + sum(_duration_for_text(chunk) for section in SCRIPT_SECTIONS for chunk in _split_for_takes(section["text"]))
    return {
        "schema_version": "1.0.0",
        "script_id": _stable_id("script", brief["brief_id"], full_text),
        "version": "1.1.0",
        "channel_id": brief["channel_id"],
        "brief_id": brief["brief_id"],
        "language": "en-US",
        "title": brief["package"]["title_concept"],
        "original_thesis": "Prayer prepares a person to discern and take one tested faithful action; it does not guarantee the outcome or turn every impulse into instruction.",
        "source_basis": [
            {"source_ref": "James 1:2-8", "use": "wisdom in the context of trials", "handling": "original contextual paraphrase; no borrowed sermon or audio"},
            {"source_ref": "James 1:22-25", "use": "hearing must become accountable action", "handling": "original contextual paraphrase; no translation quoted at length"},
            {"source_ref": "output/modeling/phase4/channel-model-v1/channel_model.json", "use": "approved narrative mechanism and safety boundaries", "handling": "mechanisms used; reference wording and identity prohibited"},
            {"source_ref": "output/production/phase5/pilot-001/audio/hook-benchmark/benchmark.json", "use": "measured hook timing correction", "handling": "the failed 1.579-second first line was shortened; visual typography carries the full contradiction at frame one"},
        ],
        "hook_windows": [
            {"window": "0_1S", "start_ms": 0, "end_ms": 1000, "function": "multimodal contradiction", "narration": hook_narration[0], "visual_job": "show AMEN ISN'T THE END on frame one while decisive motion interrupts stillness", "evidence_refs": ["brief:0_1S", "channel-model:H1", "audio/hook-benchmark/benchmark.json"]},
            {"window": "1_3S", "start_ms": 1000, "end_ms": 3000, "function": "personal consequence", "narration": hook_narration[1], "visual_job": "show a leading line or path beginning", "evidence_refs": ["brief:1_3S", "channel-model:H2"]},
            {"window": "3_8S", "start_ms": 3000, "end_ms": 8000, "function": "mechanism", "narration": hook_narration[2], "visual_job": "move from hesitation to forward motion", "evidence_refs": ["brief:3_8S", "channel-model:H3"]},
            {"window": "8_30S", "start_ms": 8000, "end_ms": 30000, "function": "first payoff and context", "narration": SCRIPT_SECTIONS[0]["text"], "visual_job": "progress from turbulent weather to a readable horizon", "evidence_refs": ["brief:8_30S", "channel-model:H4", "James 1:5"]},
        ],
        "sections": SCRIPT_SECTIONS,
        "full_text": full_text,
        "word_count": word_count,
        "estimated_duration_ms": estimated_duration_ms,
        "originality_controls": {
            "written_from_blank": True,
            "reference_wording_used": False,
            "borrowed_audio_used": False,
            "borrowed_sequence_used": False,
            "editorial_purpose": "Teach a bounded prayer-to-action discernment framework through original narration and function-assigned licensed visuals.",
        },
        "created_at": created_at,
    }


def build_narrative_beats(
    script: dict[str, Any],
    duration_overrides: dict[str, int] | None = None,
) -> list[dict[str, Any]]:
    duration_overrides = duration_overrides or {}
    beats: list[dict[str, Any]] = [
        {"beat_id": "H01", "start_ms": 0, "end_ms": 1000, "narrative_function": "multimodal contradiction", "information": "Amen begins a response rather than ending the subject.", "intended_emotion": "surprise", "semantic_role": "urgency", "action": "hard visual interruption from stillness to motion; full contradiction appears on frame one", "on_screen_text": "AMEN ISN'T THE END", "narration": script["hook_windows"][0]["narration"], "retention_job": "stop and confirm the title tension"},
        {"beat_id": "H02", "start_ms": 1000, "end_ms": 3000, "narrative_function": "personal consequence", "information": "The viewer's next act tests the prayer response.", "intended_emotion": "tension", "semantic_role": "decision", "action": "a leading line advances", "on_screen_text": "YOUR MOVE REVEALS IT", "narration": script["hook_windows"][1]["narration"], "retention_job": "make the promise personal"},
        {"beat_id": "H03", "start_ms": 3000, "end_ms": 8000, "narrative_function": "mechanism", "information": "Confidence may follow one tested faithful action.", "intended_emotion": "resolve", "semantic_role": "progress", "action": "movement crosses from obstruction to open space", "on_screen_text": None, "narration": script["hook_windows"][2]["narration"], "retention_job": "deliver the first micro-payoff"},
    ]
    cursor = 8000
    beat_index = 4
    for section in script["sections"]:
        chunks = _split_for_takes(section["text"])
        for chunk_index, chunk in enumerate(chunks):
            take_id = f"take-{beat_index:03d}"
            duration = int(duration_overrides.get(take_id, _duration_for_text(chunk)))
            if duration < 900 or duration > 10_000:
                raise ValueError(f"duration override for {take_id} is outside FormatPack bounds: {duration}")
            beats.append(
                {
                    "beat_id": f"B{beat_index:03d}",
                    "start_ms": cursor,
                    "end_ms": cursor + duration,
                    "narrative_function": section["narrative_function"],
                    "information": chunk,
                    "intended_emotion": section["intended_emotion"],
                    "semantic_role": section["semantic_role"],
                    "action": f"visual transmits {section['semantic_role']} through source-native movement",
                    "on_screen_text": section["on_screen_text"] if chunk_index == 0 else None,
                    "narration": chunk,
                    "retention_job": section["retention_job"],
                    "sound_effect": "restrained transition impact" if chunk_index == 0 else None,
                }
            )
            cursor += duration
            beat_index += 1
    return beats


def materialize_pilot_contracts(
    root: Path,
    *,
    created_at: str | None = None,
    take_duration_overrides: dict[str, int] | None = None,
) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    command = _read_json(package_dir / "central_command.creative_direction.json")
    envelope = _read_json(root / "config" / "operational_envelopes" / "phase5-zero-cost-v1.json")
    channel_model = _read_json(root / "output" / "modeling" / "phase4" / "channel-model-v1" / "channel_model.json")
    brief = _read_json(package_dir / "editorial_brief.json")
    manifest = _read_json(package_dir / "asset_manifest.json")
    packs = load_format_packs(root / "config" / "format_packs", root / "schemas" / "format_pack.schema.json")
    pack = next(item for item in packs if item["format_pack_id"] == "fp-broll-cinematic-narration")

    policy = evaluate_phase5_command(command, envelope, created_at=timestamp)
    decision = choose_format_pack(
        command=command,
        policy_decision=policy,
        channel_model=channel_model,
        brief=brief,
        packs=packs,
        purpose="PROTOTYPE",
        budget_envelope_id=envelope["envelope_id"],
        quality_profile="DRAFT",
        created_at=timestamp,
    )
    bible = build_visual_continuity_bible(
        channel_model=channel_model,
        format_pack=pack,
        asset_manifest=manifest,
        created_at=timestamp,
    )
    script = build_narrative_script(brief, created_at=timestamp)
    beats = build_narrative_beats(script, duration_overrides=take_duration_overrides)
    hook_windows = [
        {"window": window["window"], "start_ms": window["start_ms"], "end_ms": window["end_ms"], "promise_function": window["function"], "evidence_refs": window["evidence_refs"]}
        for window in script["hook_windows"]
    ]
    plan, allocated_manifest = build_take_plan(
        channel_id="heroverse74",
        video_id="phase5-pilot-001",
        creative_decision=decision,
        style_bible=bible,
        format_pack=pack,
        asset_manifest=manifest,
        narrative_beats=beats,
        hook_windows=hook_windows,
        created_at=timestamp,
    )

    artifacts = {
        "policy_decision.json": ("phase5_policy_decision.schema.json", policy),
        "creative_direction_decision.json": ("creative_direction_decision.schema.json", decision),
        "channel_style_bible.json": ("visual_continuity_bible.schema.json", bible),
        "narrative_script.json": ("narrative_script.schema.json", script),
        "take_plan.json": ("take_plan.schema.json", plan),
    }
    for filename, (schema_name, value) in artifacts.items():
        _validate(root, schema_name, value)
        _write_json(package_dir / filename, value)
    _write_json(package_dir / "asset_manifest.allocated.json", allocated_manifest)
    return {
        "policy": policy["decision"],
        "creative_direction": decision["decision"],
        "format_pack": f"{pack['format_pack_id']}@{pack['version']}",
        "quality_profile": decision["quality_profile"],
        "script_words": script["word_count"],
        "estimated_duration_ms": script["estimated_duration_ms"],
        "timeline_duration_ms": plan["takes"][-1]["end_ms"],
        "timeline_basis": "MEASURED_VOICE" if take_duration_overrides else "SCRIPT_ESTIMATE",
        "take_count": len(plan["takes"]),
        "external_cost_usd": plan["total_cost"]["external"],
        "artifacts": list(artifacts),
    }
