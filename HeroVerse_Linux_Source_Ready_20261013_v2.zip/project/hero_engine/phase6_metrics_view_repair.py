from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .maintenance_protocol import (
    ACK_PATH,
    REQUEST_PATH,
    RUNTIME,
    _process_alive,
    _replace_bytes,
    _write_immutable_bytes,
    file_hash,
    inspect_quiescence,
    ledger_state_snapshot,
    operational_effect_snapshot,
    queue_snapshot,
)


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
METRICS_FOLDER = Path("output/operations/phase6/metrics") / VIDEO_ID
LATEST_PATH = METRICS_FOLDER / "latest.json"
SOURCE_SCHEMA = "own_channel_performance_snapshot.schema.json"
RECEIPT_SCHEMA = "phase6_owned_metrics_view_repair_receipt.schema.json"
HASH_PATTERN = re.compile(r"^sha256:[0-9a-f]{64}$")
SNAPSHOT_ID_PATTERN = re.compile(r"^[A-Za-z0-9_.-]+$")


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _hash_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"


def _read_json_bytes(payload: bytes, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(payload.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PermissionError(f"{label} is not readable UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise PermissionError(f"{label} is not a JSON object")
    return value


def _validate(root: Path, schema_name: str, value: Any) -> None:
    schema = json.loads((root / "schemas" / schema_name).read_text(encoding="utf-8-sig"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _require_hash(value: str, *, label: str) -> str:
    if not HASH_PATTERN.fullmatch(value):
        raise ValueError(f"{label} must be a lowercase prefixed SHA-256")
    return value


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise PermissionError("repair evidence escaped the workspace") from exc


def _require_regular(path: Path, *, label: str) -> None:
    if not path.is_file() or path.is_symlink():
        raise PermissionError(f"{label} must be a regular non-symbolic-link file")


def _operational_hashes(root: Path, *, observed: datetime) -> dict[str, str]:
    queue = queue_snapshot(root, now=observed)
    ledger = ledger_state_snapshot(root)
    effects = operational_effect_snapshot(root)
    return {
        "queue": str(queue["jobs_hash"]),
        "ledger": str(ledger["state_hash"]),
        "effects": str(effects["receipts_hash"]),
    }


def _receipt_identity(
    *, request_id: str, target_path: str, before_hash: str, twin_hash: str
) -> str:
    material = "|".join(
        [
            "phase6-owned-metrics-view-repair-v1",
            request_id,
            target_path,
            before_hash,
            twin_hash,
        ]
    ).encode("utf-8")
    return "phase6-owned-metrics-view-repair-" + hashlib.sha256(material).hexdigest()[:24]


def _validate_maintenance_boundary(
    root: Path,
    *,
    request_id: str,
    former_manager_pid: int,
    former_launcher_pid: int,
    observed: datetime,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    if former_manager_pid < 1 or former_launcher_pid < 1:
        raise ValueError("former process ids must be positive")
    request_path = root / REQUEST_PATH
    ack_path = root / ACK_PATH
    _require_regular(request_path, label="maintenance request")
    _require_regular(ack_path, label="maintenance acknowledgement")
    request = _read_json_bytes(request_path.read_bytes(), label="maintenance request")
    ack = _read_json_bytes(ack_path.read_bytes(), label="maintenance acknowledgement")
    _validate(root, "central_manager_maintenance_request.schema.json", request)
    _validate(root, "central_manager_maintenance_ack.schema.json", ack)
    if not (
        request.get("request_id") == request_id
        and request.get("external_effects_permitted") is False
        and ack.get("request_id") == request_id
        and ack.get("status") == "READY_TO_STOP"
        and ack.get("external_effect_boundary_closed") is True
        and ack.get("manager_pid") == former_manager_pid
        and not ack.get("active_lease_job_ids")
        and not ack.get("protected_due_job_ids")
        and not ack.get("operational_due_job_ids")
        and not ack.get("active_quota_reservation_ids")
        and not ack.get("open_effect_receipt_paths")
        and not ack.get("blockers")
    ):
        raise PermissionError("repair is not bound to one closed READY_TO_STOP maintenance boundary")
    if _process_alive(former_manager_pid) or _process_alive(former_launcher_pid):
        raise PermissionError("repair requires the verified manager and launcher processes to be stopped")
    inspection = inspect_quiescence(
        root,
        manager_pid=former_manager_pid,
        guard_seconds=int(request["protected_due_guard_seconds"]),
        now=observed,
    )
    if inspection.get("blockers"):
        raise PermissionError(
            "repair requires quiescent operational state: "
            + ",".join(str(item) for item in inspection["blockers"])
        )
    return request, ack, inspection


def repair_owned_metrics_latest_view(
    root: Path = ROOT,
    *,
    request_id: str,
    former_manager_pid: int,
    former_launcher_pid: int,
    evidence_dir: Path,
    expected_latest_sha256: str,
    expected_twin_sha256: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Repair only a proven CRLF/LF divergence under stopped maintenance.

    The immutable snapshot is always the source and is never rewritten.  Both
    hashes are caller-supplied compare-and-swap guards, so a newer mutable view
    cannot be mistaken for the originally diagnosed target.
    """

    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    before_expected = _require_hash(expected_latest_sha256, label="expected latest hash")
    twin_expected = _require_hash(expected_twin_sha256, label="expected twin hash")
    expected_evidence = (root / RUNTIME / "maintenance-runs" / request_id).resolve()
    destination = evidence_dir.resolve() if evidence_dir.is_absolute() else (root / evidence_dir).resolve()
    if destination != expected_evidence or not destination.is_dir() or destination.is_symlink():
        raise PermissionError("repair evidence directory is not the exact existing maintenance run")

    request, ack, inspection = _validate_maintenance_boundary(
        root,
        request_id=request_id,
        former_manager_pid=former_manager_pid,
        former_launcher_pid=former_launcher_pid,
        observed=observed,
    )
    request_path = root / REQUEST_PATH
    ack_path = root / ACK_PATH
    request_hash = file_hash(request_path)
    ack_hash = file_hash(ack_path)

    metrics_folder = (root / METRICS_FOLDER).resolve()
    latest_path = (root / LATEST_PATH).resolve()
    if latest_path.parent != metrics_folder:
        raise PermissionError("owned-metrics latest path escaped its exact folder")
    _require_regular(latest_path, label="owned-metrics latest view")
    latest_bytes = latest_path.read_bytes()
    latest = _read_json_bytes(latest_bytes, label="owned-metrics latest view")
    _validate(root, SOURCE_SCHEMA, latest)
    snapshot_id = latest.get("snapshot_id")
    if not (
        latest.get("channel_id") == CHANNEL_ID
        and latest.get("video_id") == VIDEO_ID
        and isinstance(snapshot_id, str)
        and SNAPSHOT_ID_PATTERN.fullmatch(snapshot_id)
    ):
        raise PermissionError("owned-metrics latest identity is not the exact canary snapshot")

    twin_path = (metrics_folder / f"{snapshot_id}.json").resolve()
    if twin_path.parent != metrics_folder or twin_path == latest_path:
        raise PermissionError("immutable snapshot twin path is not confined")
    _require_regular(twin_path, label="immutable owned-metrics twin")
    twin_bytes = twin_path.read_bytes()
    twin = _read_json_bytes(twin_bytes, label="immutable owned-metrics twin")
    _validate(root, SOURCE_SCHEMA, twin)
    if not (
        twin.get("snapshot_id") == snapshot_id
        and twin.get("channel_id") == CHANNEL_ID
        and twin.get("video_id") == VIDEO_ID
    ):
        raise PermissionError("immutable owned-metrics twin identity diverged")
    if latest != twin:
        raise PermissionError("latest and immutable twin differ semantically; line-ending repair is forbidden")

    before_hash = _hash_bytes(latest_bytes)
    twin_hash = _hash_bytes(twin_bytes)
    target_relative = _relative(root, latest_path)
    twin_relative = _relative(root, twin_path)
    receipt_id = _receipt_identity(
        request_id=request_id,
        target_path=target_relative,
        before_hash=before_expected,
        twin_hash=twin_expected,
    )
    receipt_path = destination / f"{receipt_id}.json"
    receipt_relative = _relative(root, receipt_path)

    # A committed receipt is replayable only while the exact repaired target
    # and immutable source are still present.  The original expected hash stays
    # part of the identity even though current latest now has the after hash.
    if receipt_path.is_file():
        if receipt_path.is_symlink():
            raise PermissionError("repair receipt cannot be a symbolic link")
        receipt = _read_json_bytes(receipt_path.read_bytes(), label="repair receipt")
        _validate(root, RECEIPT_SCHEMA, receipt)
        if not (
            receipt.get("receipt_id") == receipt_id
            and receipt.get("receipt_path") == receipt_relative
            and receipt.get("request_id") == request_id
            and (receipt.get("target") or {}).get("before_hash") == before_expected
            and (receipt.get("target") or {}).get("after_hash") == before_hash == twin_hash
            and (receipt.get("immutable_twin") or {}).get("content_hash") == twin_expected == twin_hash
            and (receipt.get("immutable_twin") or {}).get("path") == twin_relative
            and latest_bytes == twin_bytes
        ):
            raise PermissionError("committed repair replay no longer matches target and immutable twin")
        return receipt

    if before_hash != before_expected or twin_hash != twin_expected:
        raise PermissionError("owned-metrics repair compare-and-swap preimage changed")
    if b"\r" in twin_bytes:
        raise PermissionError("immutable owned-metrics twin is not canonical LF bytes")
    bytes_differed = latest_bytes != twin_bytes
    if bytes_differed:
        if b"\r\n" not in latest_bytes or latest_bytes.replace(b"\r\n", b"\n") != twin_bytes:
            raise PermissionError("owned-metrics divergence is not CRLF-to-LF only")
        action = "REPAIRED_LINE_ENDINGS"
        difference_class = "CRLF_TO_LF_ONLY"
        source_newline = "CRLF"
    else:
        action = "NO_CHANGE"
        difference_class = "BYTE_IDENTICAL"
        source_newline = "LF"

    state_before = _operational_hashes(root, observed=observed)
    preimage_path = destination / f"{receipt_id}.before"
    candidate_path = destination / f"{receipt_id}.candidate"
    journal_path = destination / f"{receipt_id}.prepared.json"
    _write_immutable_bytes(preimage_path, latest_bytes)
    _write_immutable_bytes(candidate_path, twin_bytes)
    if preimage_path.read_bytes() != latest_bytes or candidate_path.read_bytes() != twin_bytes:
        raise PermissionError("repair preimage or candidate staging mismatch")
    journal = {
        "schema_version": "1.0.0",
        "record_type": "PREPARED",
        "receipt_id": receipt_id,
        "request_id": request_id,
        "observed_at": _stamp(observed),
        "target_path": target_relative,
        "target_before_hash": before_hash,
        "immutable_twin_path": twin_relative,
        "immutable_twin_hash": twin_hash,
        "preimage_path": _relative(root, preimage_path),
        "preimage_hash": file_hash(preimage_path),
        "candidate_path": _relative(root, candidate_path),
        "candidate_hash": file_hash(candidate_path),
        "semantic_equal": True,
        "difference_class": difference_class,
        "queue_jobs_hash": state_before["queue"],
        "quota_ledger_hash": state_before["ledger"],
        "operational_effects_hash": state_before["effects"],
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "technical_cost_brl": 0,
    }
    journal_payload = _json_bytes(journal)
    _write_immutable_bytes(journal_path, journal_payload)
    if journal_path.read_bytes() != journal_payload:
        raise PermissionError("repair prepared journal staging mismatch")

    mutated = False
    try:
        if _process_alive(former_manager_pid) or _process_alive(former_launcher_pid):
            raise PermissionError("manager process chain restarted before repair commit")
        if file_hash(request_path) != request_hash or file_hash(ack_path) != ack_hash:
            raise PermissionError("maintenance boundary changed before repair commit")
        if latest_path.read_bytes() != latest_bytes or twin_path.read_bytes() != twin_bytes:
            raise PermissionError("repair source changed after prepared journal")
        if bytes_differed:
            _replace_bytes(latest_path, twin_bytes)
            mutated = True
        if latest_path.read_bytes() != twin_bytes or twin_path.read_bytes() != twin_bytes:
            raise PermissionError("owned-metrics latest did not become byte-identical to its immutable twin")

        state_after = _operational_hashes(root, observed=observed)
        if state_after != state_before:
            raise PermissionError("owned-metrics view repair changed operational state")

        receipt = {
            "schema_version": "1.0.0",
            "receipt_id": receipt_id,
            "receipt_path": receipt_relative,
            "request_id": request_id,
            "status": "PASS",
            "action": action,
            "observed_at": _stamp(observed),
            "maintenance_boundary": {
                "request_path": REQUEST_PATH.as_posix(),
                "request_hash": request_hash,
                "ack_path": ACK_PATH.as_posix(),
                "ack_hash": ack_hash,
                "ack_status": ack["status"],
                "external_effect_boundary_closed": ack["external_effect_boundary_closed"],
                "former_manager_pid": former_manager_pid,
                "former_launcher_pid": former_launcher_pid,
                "manager_process_stopped": True,
                "launcher_process_stopped": True,
                "quiescence_observed_at": str(inspection["observed_at"]),
                "blockers": [],
            },
            "target": {
                "path": target_relative,
                "schema": SOURCE_SCHEMA,
                "channel_id": CHANNEL_ID,
                "video_id": VIDEO_ID,
                "snapshot_id": snapshot_id,
                "before_size": len(latest_bytes),
                "before_hash": before_hash,
                "after_size": len(twin_bytes),
                "after_hash": twin_hash,
                "preimage_path": _relative(root, preimage_path),
                "preimage_hash": file_hash(preimage_path),
            },
            "immutable_twin": {
                "path": twin_relative,
                "size": len(twin_bytes),
                "content_hash": twin_hash,
                "candidate_path": _relative(root, candidate_path),
                "candidate_hash": file_hash(candidate_path),
                "untouched": True,
            },
            "comparison": {
                "semantic_equal": True,
                "difference_class": difference_class,
                "source_newline": source_newline,
                "target_newline": "LF",
                "bytes_differed": bytes_differed,
            },
            "transaction": {
                "prepared_journal_path": _relative(root, journal_path),
                "prepared_journal_hash": file_hash(journal_path),
                "mutation_performed": mutated,
                "compare_and_swap_verified": True,
                "rollback_performed": False,
            },
            "operational_state": {
                "queue_jobs_hash_before": state_before["queue"],
                "queue_jobs_hash_after": state_after["queue"],
                "quota_ledger_hash_before": state_before["ledger"],
                "quota_ledger_hash_after": state_after["ledger"],
                "operational_effects_hash_before": state_before["effects"],
                "operational_effects_hash_after": state_after["effects"],
                "unchanged": True,
            },
            "external_api_calls": 0,
            "publication_effects": 0,
            "operational_queue_mutations": 0,
            "technical_cost_brl": 0,
            "claim_boundary": [
                "Repairs only the mutable latest view from its exact immutable same-ID twin.",
                "Semantic divergence, hash drift, active processes or an open maintenance boundary block.",
                "No API, publication, quota or queue mutation is authorized.",
                "The immutable snapshot twin is never modified.",
            ],
        }
        _validate(root, RECEIPT_SCHEMA, receipt)
        receipt_payload = _json_bytes(receipt)
        _write_immutable_bytes(receipt_path, receipt_payload)
        if receipt_path.read_bytes() != receipt_payload:
            raise PermissionError("repair committed receipt mismatch")
        return receipt
    except Exception as exc:
        rollback_error: Exception | None = None
        try:
            if latest_path.read_bytes() != latest_bytes:
                _replace_bytes(latest_path, latest_bytes)
            if latest_path.read_bytes() != latest_bytes:
                raise PermissionError("byte-exact latest preimage was not restored")
            if twin_path.read_bytes() != twin_bytes:
                raise PermissionError("immutable twin changed during failed repair")
        except Exception as rollback_exc:
            rollback_error = rollback_exc
        error = {
            "schema_version": "1.0.0",
            "record_type": "ROLLED_BACK" if rollback_error is None else "ROLLBACK_FAILED",
            "receipt_id": receipt_id,
            "request_id": request_id,
            "observed_at": _stamp(observed),
            "failure_type": type(exc).__name__,
            "failure": str(exc),
            "target_path": target_relative,
            "target_before_hash": before_hash,
            "target_current_hash": _hash_bytes(latest_path.read_bytes()) if latest_path.is_file() else None,
            "immutable_twin_hash": twin_hash,
            "prepared_journal_path": _relative(root, journal_path),
            "prepared_journal_hash": file_hash(journal_path),
            "rollback_verified": rollback_error is None,
            "rollback_error": None
            if rollback_error is None
            else f"{type(rollback_error).__name__}: {rollback_error}",
            "external_api_calls": 0,
            "publication_effects": 0,
            "operational_queue_mutations": 0,
            "technical_cost_brl": 0,
        }
        error_payload = _json_bytes(error)
        error_id = hashlib.sha256(error_payload).hexdigest()[:16]
        error_path = destination / f"{receipt_id}.error-{error_id}.json"
        try:
            _write_immutable_bytes(error_path, error_payload)
        except Exception as evidence_exc:
            if rollback_error is not None:
                raise RuntimeError(
                    "repair failed, rollback is unproven and error evidence could not be persisted"
                ) from exc
            raise RuntimeError("repair rolled back but error evidence could not be persisted") from evidence_exc
        if rollback_error is not None:
            raise RuntimeError(
                "repair failed and byte-exact rollback could not be proven: "
                f"{type(rollback_error).__name__}: {rollback_error}"
            ) from exc
        raise PermissionError(
            "repair failed and latest was restored byte-for-byte; evidence="
            + _relative(root, error_path)
        ) from exc


def _cli() -> int:
    parser = argparse.ArgumentParser(
        description="Repair a Phase 6 owned-metrics latest CRLF/LF divergence under maintenance"
    )
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--former-manager-pid", required=True, type=int)
    parser.add_argument("--former-launcher-pid", required=True, type=int)
    parser.add_argument("--evidence-dir", required=True, type=Path)
    parser.add_argument("--expected-latest-sha256", required=True)
    parser.add_argument("--expected-twin-sha256", required=True)
    args = parser.parse_args()
    value = repair_owned_metrics_latest_view(
        args.root,
        request_id=args.request_id,
        former_manager_pid=args.former_manager_pid,
        former_launcher_pid=args.former_launcher_pid,
        evidence_dir=args.evidence_dir,
        expected_latest_sha256=args.expected_latest_sha256,
        expected_twin_sha256=args.expected_twin_sha256,
    )
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
