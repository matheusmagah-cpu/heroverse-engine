"""Strict contracts for Phase 2 mining outputs and benchmark receipts."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_SCHEMA = ROOT / "schemas" / "video_mining.schema.json"
BENCHMARK_SCHEMA = ROOT / "schemas" / "mining_benchmark.schema.json"


class AnalysisValidationError(ValueError):
    """Raised when an executor attempts to emit an invalid analysis."""


@dataclass(frozen=True)
class ValidationResult:
    schema_valid: bool
    evidence_resolvable: bool
    errors: tuple[str, ...]
    evidence_ids: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.schema_valid and self.evidence_resolvable and not self.errors

    def require(self) -> "ValidationResult":
        if not self.passed:
            raise AnalysisValidationError("; ".join(self.errors) or "analysis validation failed")
        return self


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _load_schema(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _schema_errors(document: dict[str, Any], schema_path: Path) -> list[str]:
    validator = Draft202012Validator(_load_schema(schema_path), format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(document), key=lambda error: [str(part) for part in error.path])
    return [f"schema:{'/'.join(map(str, error.path)) or '<root>'}: {error.message}" for error in errors]


def _walk(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk(child)


def _evidence_blocks(document: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        item for item in _walk(document)
        if {"evidence_id", "class", "artifact", "description"}.issubset(item)
    ]


def _artifact_exists(artifact: str, root: Path) -> bool:
    if artifact.startswith(("https://", "http://")):
        return True
    path = Path(artifact)
    if not path.is_absolute():
        path = root / path
    return path.is_file()


def _time_invariants(document: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    duration = document.get("source", {}).get("duration_ms")
    hooks = document.get("hooks", [])
    expected = [("0_1S", 0, 1000), ("1_3S", 1000, 3000), ("3_8S", 3000, 8000), ("8_30S", 8000, 30000)]
    observed = [(item.get("window"), item.get("start_ms"), item.get("end_ms")) for item in hooks]
    if observed != expected:
        errors.append(f"invariant:hook_windows expected={expected!r} observed={observed!r}")
    for collection_name in ("takes", "narrative_segments"):
        items = document.get(collection_name, [])
        if not items:
            errors.append(f"invariant:{collection_name}:empty")
            continue
        if items[0].get("start_ms") != 0:
            errors.append(f"invariant:{collection_name}:does_not_start_at_zero")
        for previous, current in zip(items, items[1:]):
            delta = int(current["start_ms"]) - int(previous["end_ms"])
            if abs(delta) > 2:
                errors.append(f"invariant:{collection_name}:non_contiguous:{delta}ms")
        if duration is not None and abs(int(items[-1]["end_ms"]) - int(duration)) > 100:
            errors.append(f"invariant:{collection_name}:duration_mismatch")
    for take in document.get("takes", []):
        if take.get("duration_ms") != take.get("end_ms", 0) - take.get("start_ms", 0):
            errors.append(f"invariant:take_duration:{take.get('take_id')}")
    return errors


def _claim_evidence_invariants(document: dict[str, Any], evidence_ids: set[str]) -> list[str]:
    errors: list[str] = []
    for item in _walk(document):
        if {"value", "class", "confidence", "evidence_refs"}.issubset(item):
            refs = item.get("evidence_refs") or []
            if item.get("class") in {"OBSERVED", "CALCULATED", "INFERRED", "PRIVATE"} and not refs:
                errors.append("invariant:claim_without_evidence")
            unresolved = [ref for ref in refs if ref not in evidence_ids]
            if unresolved:
                errors.append(f"invariant:claim_evidence_refs_missing:{','.join(unresolved)}")
    return errors


def validate_analysis(document: dict[str, Any], *, root: Path = ROOT, raise_on_error: bool = False) -> ValidationResult:
    schema_errors = _schema_errors(document, ANALYSIS_SCHEMA)
    blocks = _evidence_blocks(document)
    ids = [str(block["evidence_id"]) for block in blocks]
    duplicate_ids = sorted({item for item in ids if ids.count(item) > 1})
    invariant_errors = _time_invariants(document)
    if duplicate_ids:
        invariant_errors.append(f"invariant:duplicate_evidence_ids:{','.join(duplicate_ids)}")
    invariant_errors.extend(_claim_evidence_invariants(document, set(ids)))
    missing = sorted({str(block["artifact"]) for block in blocks if not _artifact_exists(str(block["artifact"]), root)})
    evidence_errors = [f"evidence:missing:{artifact}" for artifact in missing]
    errors = tuple(schema_errors + invariant_errors + evidence_errors)
    result = ValidationResult(
        schema_valid=not schema_errors,
        evidence_resolvable=not evidence_errors,
        errors=errors,
        evidence_ids=tuple(sorted(set(ids))),
    )
    if raise_on_error:
        result.require()
    return result


def validate_benchmark(document: dict[str, Any], *, raise_on_error: bool = False) -> ValidationResult:
    errors = tuple(_schema_errors(document, BENCHMARK_SCHEMA))
    result = ValidationResult(
        schema_valid=not errors,
        evidence_resolvable=True,
        errors=errors,
        evidence_ids=tuple(
            sorted({str(ref) for metric in document.get("field_metrics", []) for ref in metric.get("evidence_ids", [])})
        ),
    )
    if raise_on_error:
        result.require()
    return result
