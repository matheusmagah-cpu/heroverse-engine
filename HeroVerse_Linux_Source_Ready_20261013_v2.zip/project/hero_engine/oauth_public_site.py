from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


PLACEHOLDERS = {
    "__OAUTH_APP_NAME__": "exact OAuth consent-screen application name",
    "__LEGAL_OWNER_NAME__": "public legal/operator name",
    "__PUBLIC_SUPPORT_EMAIL__": "public support email",
    "__EFFECTIVE_DATE__": "effective date",
}
PAGES = ["index.html", "privacy.html", "terms.html", "styles.css"]
DEPLOYMENT_RECEIPT = Path("output/integrations/youtube/heroverse/oauth-public-site-deployment-receipt.json")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_oauth_public_site(root: Path, *, observed_at: str | None = None) -> dict[str, Any]:
    directory = root / "deployment" / "oauth-compliance"
    timestamp = observed_at or datetime.now(timezone.utc).isoformat()
    files = []
    contents: dict[str, str] = {}
    for name in PAGES:
        path = directory / name
        if not path.is_file():
            raise FileNotFoundError(path)
        contents[name] = path.read_text(encoding="utf-8")
        files.append({"path": str(path.relative_to(root).as_posix()), "sha256": _sha256(path), "size_bytes": path.stat().st_size})

    home = contents["index.html"]
    privacy = contents["privacy.html"]
    terms = contents["terms.html"]
    all_text = "\n".join(contents.values())
    unresolved_tokens = [token for token in PLACEHOLDERS if token in all_text]
    deployment_path = root / DEPLOYMENT_RECEIPT
    deployment: dict[str, Any] | None = None
    if deployment_path.is_file():
        deployment = json.loads(deployment_path.read_text(encoding="utf-8-sig"))
        deployment_schema = json.loads(
            (root / "schemas" / "oauth_public_site_deployment_receipt.schema.json").read_text(encoding="utf-8-sig")
        )
        Draft202012Validator(deployment_schema).validate(deployment)
    public_deployment = bool(
        deployment
        and deployment["public_without_login"] is True
        and deployment["https_enforced"] is True
        and deployment["technical_cost_brl"] == 0
        and deployment["billing_required"] is False
        and all(item["status_code"] == 200 and item["hash_match"] is True for item in deployment["http_checks"])
    )
    search_console_verified = bool(deployment and deployment["search_console_ownership_verified"] is True)
    dns_domain_verified = bool(
        deployment
        and deployment["oauth_dns_domain_verified"] is True
        and deployment["search_console_property_type"] == "DOMAIN_PROPERTY"
    )
    checks = [
        {"check": "homepage_describes_functionality", "status": "PASS" if "What the application does" in home and "Google data" in home else "FAIL", "evidence": "index.html functionality and scope sections"},
        {"check": "homepage_links_privacy", "status": "PASS" if 'href="privacy.html"' in home else "FAIL", "evidence": "index.html link"},
        {"check": "homepage_links_terms", "status": "PASS" if 'href="terms.html"' in home else "FAIL", "evidence": "index.html link"},
        {"check": "privacy_discloses_google_data", "status": "PASS" if all(value in privacy for value in ("Data accessed", "How data is used", "Storage and protection", "Retention and deletion", "Limited Use")) else "FAIL", "evidence": "privacy.html disclosures"},
        {"check": "terms_disclose_no_guarantee", "status": "PASS" if "not guarantees of views, monetization, revenue or profit" in terms else "FAIL", "evidence": "terms.html operational controls"},
        {"check": "required_scopes_disclosed", "status": "PASS" if all(scope in home for scope in ("youtube.readonly", "yt-analytics.readonly", "youtube.upload", "youtube.force-ssl")) else "FAIL", "evidence": "index.html scope list and force-ssl least-use boundary"},
        {"check": "public_identity_values_resolved", "status": "BLOCKED" if unresolved_tokens else "PASS", "evidence": unresolved_tokens},
        {
            "check": "search_console_property_ownership",
            "status": "PASS" if search_console_verified else "BLOCKED",
            "evidence": deployment["domain_verification_evidence"] if deployment else "No owner-controlled verified domain has been provided or proven.",
        },
        {
            "check": "oauth_dns_domain_property_ownership",
            "status": "PASS" if dns_domain_verified else "BLOCKED",
            "evidence": (
                deployment["domain_verification_evidence"]
                if deployment
                else "OAuth brand verification requires a DNS-level Domain Property; no such proof exists."
            ),
        },
        {
            "check": "public_https_deployment",
            "status": "PASS" if public_deployment else "BLOCKED",
            "evidence": deployment["pages_url"] if deployment else "Local files exist; no public HTTPS deployment receipt exists.",
        },
    ]
    hard_fail = any(item["status"] == "FAIL" for item in checks)
    blocked = any(item["status"] == "BLOCKED" for item in checks)
    report = {
        "schema_version": "1.1.0",
        "status": "FAIL" if hard_fail else ("BLOCKED" if blocked else "PASS"),
        "files": files,
        "automatic_checks": checks,
        "unresolved_external_inputs": [
            *[PLACEHOLDERS[token] for token in unresolved_tokens],
            *([] if search_console_verified else ["Search Console ownership of the deployed public URL"]),
            *([] if dns_domain_verified else ["owned DNS-level Domain Property required only for full OAuth brand verification/commercial multi-user rollout"]),
            *([] if public_deployment else ["public HTTPS deployment URLs for homepage, privacy policy and terms"]),
        ],
        "deployment_permitted": not hard_fail and public_deployment,
        "site_deployment_ready": not hard_fail and public_deployment and search_console_verified,
        "oauth_brand_verification_ready": not hard_fail and public_deployment and dns_domain_verified,
        "google_requirements": [
            "public homepage accurately describing app functionality and Google data purpose",
            "privacy policy linked from homepage and matching the OAuth consent screen",
            "terms URL for the external production app",
            "all URLs hosted on a verified domain owned by the operator and publicly reachable without login",
            "authorized domain verified through Google Search Console by a Google Cloud project owner/editor",
            "OAuth scopes kept to the minimum required and accurately declared",
        ],
        "source_urls": [
            "https://developers.google.com/identity/protocols/oauth2/policies",
            "https://developers.google.com/identity/protocols/oauth2/production-readiness/policy-compliance",
            "https://support.google.com/cloud/answer/15549049?hl=en",
            "https://support.google.com/cloud/answer/13804266?hl=en",
        ],
        "observed_at": timestamp,
    }
    schema = json.loads((root / "schemas" / "oauth_public_site_readiness.schema.json").read_text(encoding="utf-8-sig"))
    Draft202012Validator(schema).validate(report)
    output = root / "output" / "integrations" / "youtube" / "heroverse" / "oauth-public-site-readiness.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report
