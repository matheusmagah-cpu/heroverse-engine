"""Bounded visual-contract repair proposal; never publishes or rewrites inputs.

The channel's approved Bible is the constraint, not something this compiler may
relax. This proposal preserves speech, timing, sources, rights and the experiment.
Its semantic mapping is an inspectable hypothesis for independent QA, not a QA
approval. Production still requires a separate post-effect successor controller.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_visual_preflight import INPUTS, PRODUCTION, _atomic_immutable


POLICY = "phase6-visual-alignment-preserve-bible-v1"
DIRECTORY = Path("output/operations/phase6/visual-alignment/candidates")
FRAMEWORK = ["TRUTH", "RESPONSIBILITY", "TODAY"]
OLD_TEXT = "NAME / TEST / CHOOSE"
HOOK_SPEECH = "Name the pressure, test its story, then choose the faithful move."


def _bytes(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _id(prefix: str, value: Any) -> str:
    return prefix + hashlib.sha256(_bytes(value)).hexdigest()[:24]


def _diff(before: Any, after: Any, path: str = "$") -> list[str]:
    if type(before) is not type(after):
        return [path]
    if isinstance(before, dict):
        if before.keys() != after.keys():
            return [path]
        return [changed for key in before for changed in _diff(before[key], after[key], f"{path}.{key}")]
    if isinstance(before, list):
        if len(before) != len(after):
            return [path]
        return [changed for i, (a, b) in enumerate(zip(before, after, strict=True)) for changed in _diff(a, b, f"{path}[{i}]")]
    return [] if before == after else [path]


def build_visual_alignment(plan: dict[str, Any], treatment: dict[str, Any], bible: dict[str, Any]) -> dict[str, Any]:
    if plan.get("channel_id") != "UCuMF6pJQkyMzaVoAxFL86yA" or plan.get("video_id") != "phase6-video-002-prepublication":
        raise PermissionError("visual alignment is limited to the exact controlled HeroVerse video")
    if treatment.get("channel_id") != plan["channel_id"] or treatment.get("video_id") != plan["video_id"]:
        raise PermissionError("visual alignment channel/video identity differs")
    if plan.get("style_bible_id") != bible.get("style_bible_id") or bible.get("channel_id") != plan["channel_id"]:
        raise PermissionError("visual alignment requires the same approved Bible")
    for document in (plan, treatment):
        if document.get("format_pack_id") != "fp-broll-cinematic-narration" or document.get("format_pack_version") != "1.1.0":
            raise PermissionError("visual alignment cannot change FormatPack or version")
    if treatment.get("grammar", {}).get("framework") != FRAMEWORK:
        raise PermissionError("visual alignment cannot redefine the locked framework")
    principles = bible.get("identity", {}).get("principles", [])
    if "TRUTH / RESPONSIBILITY / TODAY remains the locked information system" not in principles:
        raise PermissionError("visual alignment lacks the literal Bible authority")
    takes = plan.get("takes", [])
    directed = treatment.get("takes", [])
    if len(takes) < 3 or [x.get("take_id") for x in takes] != [x.get("take_id") for x in directed]:
        raise PermissionError("visual alignment cannot change take coverage or order")
    if len({x.get("take_id") for x in takes}) != len(takes):
        raise PermissionError("visual alignment cannot accept duplicate takes")
    hook = takes[2]
    if (hook.get("take_id"), hook.get("start_ms"), hook.get("end_ms"), hook.get("on_screen_text"), hook.get("narration")) != (
        "take-003", 3000, 8000, OLD_TEXT, HOOK_SPEECH
    ) or directed[2].get("treatment") != "HOOK_FRAMEWORK":
        raise PermissionError("the observed hook defect or its spoken meaning changed; this repair cannot generalize silently")

    fixed_plan, fixed_treatment = deepcopy(plan), deepcopy(treatment)
    fixed_plan["takes"][2]["on_screen_text"] = " / ".join(FRAMEWORK)
    changes = [{"take_id": "take-003", "before": OLD_TEXT, "after": " / ".join(FRAMEWORK),
                "reason": "Restore the literal channel framework; spoken actions are preserved for independent semantic QA."}]
    allowed_treatment = {"$.treatment_plan_id"}
    for i, (take, direction) in enumerate(zip(takes, fixed_treatment["takes"], strict=True)):
        if take.get("on_screen_text") is not None:
            continue
        if direction["treatment"] == "FRAMEWORK_STEP":
            new_kind = "ACTION_EVIDENCE"
            reason = "The source carries the infographic/action proof; no principal text was planned for this continuation chunk."
        elif direction["treatment"] == "PAYOFF_RESOLUTION" and i == len(takes) - 1:
            new_kind = "CINEMATIC_BODY"
            reason = "The final spoken payoff ends over the source image; retain resolution audio and COMPLETE state without inventing main copy."
        else:
            continue
        changes.append({"take_id": take["take_id"], "before": direction["treatment"], "after": new_kind, "reason": reason})
        direction["treatment"], direction["text_layout"] = new_kind, "NONE"
        allowed_treatment.update({f"$.takes[{i}].treatment", f"$.takes[{i}].text_layout"})
    fixed_plan["take_plan_id"] = _id("phase6-take-plan-", {"policy": POLICY, "prior": plan["take_plan_id"], "takes": fixed_plan["takes"]})
    fixed_treatment["treatment_plan_id"] = _id("phase6-creative-treatment-", {"policy": POLICY, "prior": treatment["treatment_plan_id"], "takes": fixed_treatment["takes"]})
    plan_diff = _diff(plan, fixed_plan)
    treatment_diff = _diff(treatment, fixed_treatment)
    if set(plan_diff) != {"$.take_plan_id", "$.takes[2].on_screen_text"} or not set(treatment_diff).issubset(allowed_treatment):
        raise PermissionError("visual alignment escaped its exact field whitelist")
    return {
        "policy_version": POLICY, "status": "PROPOSED_NOT_AUTHORIZED",
        "take_plan": fixed_plan, "treatment": fixed_treatment, "style_bible": deepcopy(bible),
        "changed_paths": {"take_plan": plan_diff, "treatment": treatment_diff, "style_bible": []},
        "changes": changes,
        "semantic_mapping": [
            {"spoken_action": "Name the pressure", "visual_label": "TRUTH", "hypothesis": "Distinguish the observed event from fear's unsupported verdict."},
            {"spoken_action": "test its story", "visual_label": "RESPONSIBILITY", "hypothesis": "Own the examination of the claim rather than obeying an untested command."},
            {"spoken_action": "choose the faithful move", "visual_label": "TODAY", "hypothesis": "Choose one bounded action in the present, not a guaranteed outcome."},
        ],
        "independent_semantic_qa": "REQUIRED_NOT_RUN",
        "narration_changed": False, "timeline_changed": False, "assets_changed": False,
        "rights_changed": False, "bible_changed": False, "publication_authorized": False,
        "queue_authorized": False, "technical_cost_brl": 0,
    }


def verify_visual_alignment(before: dict[str, Any], proposed: dict[str, Any]) -> None:
    recomputed = build_visual_alignment(before["take_plan"], before["treatment"], before["style_bible"])
    if _bytes(recomputed) != _bytes(proposed):
        raise PermissionError("visual alignment proof or proposed output differs from independent recomputation")


def verify_visual_alignment_candidate(root: Path, binding: dict[str, Any]) -> dict[str, Any]:
    """Reopen all sources and outputs; a proposal is never execution authority.

    Structural recomputation does not evaluate the semantic mapping. That remains
    an explicit independent editorial gate, even when this verifier succeeds.
    """
    root = root.resolve()
    if set(binding) != {"candidate_id", "path", "sha256", "status"}:
        raise PermissionError("alignment binding has missing or unexpected fields")
    candidate_id = binding["candidate_id"]
    if not isinstance(candidate_id, str) or not re.fullmatch(r"visual-alignment-[a-f0-9]{24}", candidate_id):
        raise PermissionError("alignment candidate identifier is invalid")
    folder = (root / DIRECTORY / candidate_id).resolve()
    expected_path = (DIRECTORY / candidate_id / "receipt.json").as_posix()
    if not folder.is_relative_to(root) or binding["path"] != expected_path:
        raise PermissionError("alignment receipt must remain in its exact candidate directory")
    if binding["status"] != "PROPOSED_NOT_AUTHORIZED":
        raise PermissionError("alignment proposal cannot authorize queue or publication")
    receipt_path = folder / "receipt.json"
    if receipt_path.resolve() != folder / "receipt.json":
        raise PermissionError("alignment receipt path is redirected")
    receipt_raw = receipt_path.read_bytes()
    if _sha(receipt_raw) != binding["sha256"]:
        raise PermissionError("alignment receipt hash differs")
    receipt = json.loads(receipt_raw)
    receipt_schema_path = root / "schemas/phase6_visual_alignment_candidate.schema.json"
    receipt_schema_raw = receipt_schema_path.read_bytes()
    Draft202012Validator(json.loads(receipt_schema_raw), format_checker=FormatChecker()).validate(receipt)
    sources, values, records, observed_bytes = {}, {}, [], {receipt_path: receipt_raw, receipt_schema_path: receipt_schema_raw}
    for name, schema_name in INPUTS.items():
        path = (root / PRODUCTION / name).resolve()
        schema_path = (root / "schemas" / schema_name).resolve()
        if not path.is_relative_to(root) or not schema_path.is_relative_to(root):
            raise PermissionError("alignment source or schema escaped workspace")
        source_raw, schema_raw = path.read_bytes(), schema_path.read_bytes()
        source = json.loads(source_raw.decode("utf-8-sig"))
        Draft202012Validator(json.loads(schema_raw), format_checker=FormatChecker()).validate(source)
        sources[name], values[name] = source_raw, source
        records.append({"path": path.relative_to(root).as_posix(), "sha256": _sha(source_raw),
                        "schema": schema_name, "schema_sha256": _sha(schema_raw)})
        observed_bytes.update({path: source_raw, schema_path: schema_raw})
    proposed = build_visual_alignment(values["take_plan.json"], values["creative_treatment_plan.json"], values["channel_style_bible.json"])
    identity = {"policy_version": POLICY, "sources": records, "proposal_sha256": _sha(_bytes(proposed)),
                "compiler_sha256": _sha(Path(__file__).read_bytes())}
    recomputed_id = _id("visual-alignment-", identity)
    if recomputed_id != candidate_id or receipt["candidate_id"] != candidate_id:
        raise PermissionError("alignment source/compiler/identity changed")
    for key, value in identity.items():
        if receipt[key] != value:
            raise PermissionError(f"alignment {key} differs from recomputation")
    for key in ("changed_paths", "changes", "semantic_mapping", "independent_semantic_qa"):
        if receipt[key] != proposed[key]:
            raise PermissionError(f"alignment {key} is not the recomputed proposal")
    documents = {"take_plan.json": _bytes(proposed["take_plan"]),
                 "creative_treatment_plan.json": _bytes(proposed["treatment"]),
                 "channel_style_bible.json": sources["channel_style_bible.json"]}
    artifacts = []
    for name, expected in {**documents, "proposal.json": _bytes(proposed)}.items():
        path = folder / name
        if path.resolve() != path:
            raise PermissionError("alignment artifact path is redirected")
        actual = path.read_bytes()
        if actual != expected:
            raise PermissionError(f"alignment {name} differs from its exact recomputation")
        observed_bytes[path] = actual
        if name in documents:
            artifacts.append({"path": path.relative_to(root).as_posix(), "sha256": _sha(actual)})
    if receipt["artifacts"] != artifacts:
        raise PermissionError("alignment artifacts are not the exact isolated outputs")
    for path, observed in observed_bytes.items():
        if path.read_bytes() != observed:
            raise PermissionError("alignment source or output changed during verification")
    return receipt


def materialize_visual_alignment_candidate(root: Path) -> dict[str, Any]:
    root = root.resolve()
    raw, values, source_records = {}, {}, []
    for name, schema_name in INPUTS.items():
        path = (root / PRODUCTION / name).resolve()
        if not path.is_relative_to(root):
            raise PermissionError("alignment source escaped workspace")
        raw[name] = path.read_bytes()
        values[name] = json.loads(raw[name].decode("utf-8-sig"))
        schema_raw = (root / "schemas" / schema_name).read_bytes()
        Draft202012Validator(json.loads(schema_raw), format_checker=FormatChecker()).validate(values[name])
        source_records.append({"path": path.relative_to(root).as_posix(), "sha256": _sha(raw[name]),
                               "schema": schema_name, "schema_sha256": _sha(schema_raw)})
    proposal = build_visual_alignment(values["take_plan.json"], values["creative_treatment_plan.json"], values["channel_style_bible.json"])
    verify_visual_alignment({"take_plan": values["take_plan.json"], "treatment": values["creative_treatment_plan.json"], "style_bible": values["channel_style_bible.json"]}, proposal)
    documents = {
        "take_plan.json": _bytes(proposal["take_plan"]),
        "creative_treatment_plan.json": _bytes(proposal["treatment"]),
        "channel_style_bible.json": raw["channel_style_bible.json"],
    }
    for name, schema_name in INPUTS.items():
        Draft202012Validator(json.loads((root / "schemas" / schema_name).read_bytes()), format_checker=FormatChecker()).validate(json.loads(documents[name]))
    identity = {"policy_version": POLICY, "sources": source_records, "proposal_sha256": _sha(_bytes(proposal)),
                "compiler_sha256": _sha(Path(__file__).read_bytes())}
    candidate_id = _id("visual-alignment-", identity)
    folder = (root / DIRECTORY / candidate_id).resolve()
    if not folder.is_relative_to(root):
        raise PermissionError("alignment candidate path escaped workspace")
    receipt_path = folder / "receipt.json"
    captured_at = (json.loads(receipt_path.read_bytes())["created_at"] if receipt_path.exists()
                   else datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
    receipt = {
        "schema_version": "1.0.0", "candidate_id": candidate_id, "status": "PROPOSED_NOT_AUTHORIZED",
        **identity, "artifacts": [{"path": (folder / name).relative_to(root).as_posix(), "sha256": _sha(data)} for name, data in documents.items()],
        "changed_paths": proposal["changed_paths"], "changes": proposal["changes"],
        "semantic_mapping": proposal["semantic_mapping"], "independent_semantic_qa": "REQUIRED_NOT_RUN",
        "publication_authorized": False, "queue_authorized": False, "technical_cost_brl": 0, "created_at": captured_at,
    }
    Draft202012Validator(json.loads((root / "schemas/phase6_visual_alignment_candidate.schema.json").read_bytes()), format_checker=FormatChecker()).validate(receipt)
    for name, source in zip(INPUTS, source_records, strict=True):
        if (root / source["path"]).read_bytes() != raw[name]:
            raise PermissionError("alignment source changed during proposal construction")
    for name, data in documents.items():
        _atomic_immutable(folder / name, data)
    _atomic_immutable(folder / "proposal.json", _bytes(proposal))
    _atomic_immutable(receipt_path, _bytes(receipt))
    binding = {"candidate_id": candidate_id, "path": receipt_path.relative_to(root).as_posix(), "sha256": _sha(_bytes(receipt)), "status": receipt["status"]}
    verify_visual_alignment_candidate(root, binding)
    return binding
