from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_publicity import metadata_publicity_risks
from .render_creative_v2_phase5 import FFPROBE
from .asset_quality_phase5 import scoped_typography_reads


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = Path("output/production/phase6/shared-assets/asset_manifest.json")
LATEST = Path("output/operations/phase6/capacity/asset-library-residency.json")
RECEIPTS = Path("output/operations/phase6/capacity/asset-library-residency-receipts")
RIGHTS_RECEIPTS = Path("output/operations/phase6/capacity/asset-rights-evidence")
RIGHTS_OK = {
    "OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL",
    "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED",
}
FILE_ATTRIBUTE_OFFLINE = 0x1000
FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x40000
FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x400000
# Container timestamps can be rounded differently by Commons metadata and
# FFprobe.  Fifty milliseconds is the sole allowed drift; the measured value,
# declared value, delta and this threshold are all sealed into the receipt.
COMMONS_DURATION_TOLERANCE_MS = 50


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable asset-residency receipt collision: {path.name}")
        return
    _write_immutable_bytes(path, payload, label="asset-residency receipt")


def _write_immutable_bytes(path: Path, payload: bytes, *, label: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable {label} collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise PermissionError(f"immutable {label} collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _sha1(path: Path) -> str:
    digest = hashlib.sha1()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    if path.is_absolute():
        resolved = path.resolve()
        try:
            resolved.relative_to(root.resolve())
        except ValueError as exc:
            raise PermissionError(f"asset path escaped project root: {value}") from exc
        return resolved
    parts = path.parts
    for anchor in ("output", "outputs", "data", "config"):
        if anchor in parts:
            candidate = root.joinpath(*parts[parts.index(anchor):])
            if candidate.exists():
                resolved = candidate.resolve()
                try:
                    resolved.relative_to(root.resolve())
                except ValueError as exc:
                    raise PermissionError(f"asset path escaped project root: {value}") from exc
                return resolved
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"asset path escaped project root: {value}") from exc
    return resolved


def _audit_id(value: dict[str, Any]) -> str:
    content = dict(value)
    content.pop("audit_id", None)
    canonical = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "asset-residency-phase6-" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]


def _validate_timestamp(value: Any) -> None:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise PermissionError("asset-residency audited_at must be an explicit UTC timestamp")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as exc:
        raise PermissionError("asset-residency audited_at is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise PermissionError("asset-residency audited_at is not UTC")


def _empty_rights_byte_binding(evidence: dict[str, Any] | None = None) -> dict[str, Any]:
    evidence = evidence or {}
    return {
        "evidence_class": "UNKNOWN",
        "status": "FAIL",
        "local_sha1": None,
        "declared_commons_sha1": None,
        "sha1_status": "NOT_APPLICABLE",
        "local_size_bytes": None,
        "declared_size_bytes": None,
        "size_status": "NOT_APPLICABLE",
        "measured_duration_ms": None,
        "declared_duration_ms": None,
        "duration_delta_ms": None,
        "duration_tolerance_ms": COMMONS_DURATION_TOLERANCE_MS,
        "duration_status": "NOT_APPLICABLE",
        "source_page": evidence.get("source_page"),
        "description_url": None,
        "download_url": None,
        "metadata_revision_id": None,
        "metadata_timestamp": None,
        "evidence_verified_at": evidence.get("verified_at"),
        "expires_at": evidence.get("expires_at"),
        "expiry_status": "NOT_APPLICABLE",
    }


def build_phase6_rights_byte_binding(
    root: Path,
    evidence: dict[str, Any],
    *,
    media_path: Path,
    measured_duration_ms: int | None,
) -> dict[str, Any]:
    """Bind a rights assertion to local bytes and measured container duration.

    Commons SHA-1 and byte size are exact invariants.  Duration permits only
    ``COMMONS_DURATION_TOLERANCE_MS`` of container/metadata rounding drift.
    The returned object is content-bound by the immutable residency receipt.
    """

    binding = _empty_rights_byte_binding(evidence)
    resolved_media = media_path.resolve()
    try:
        resolved_media.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError("rights-bound media path escaped project root") from exc

    if evidence.get("evidence_class") == "TEMPORARY_PERMISSION":
        expiry_status = "FAIL"
        try:
            expires_at = datetime.fromisoformat(str(evidence["expires_at"]).replace("Z", "+00:00"))
            if expires_at.tzinfo is not None and expires_at.astimezone(timezone.utc) > datetime.now(timezone.utc):
                expiry_status = "PASS"
        except (KeyError, TypeError, ValueError):
            pass
        binding.update({
            "evidence_class": "TEMPORARY_PERMISSION",
            "status": "PASS" if expiry_status == "PASS" else "FAIL",
            "local_size_bytes": resolved_media.stat().st_size,
            "size_status": "NOT_APPLICABLE",
            "measured_duration_ms": measured_duration_ms,
            "source_page": evidence.get("source_url"),
            "expires_at": evidence.get("expires_at"),
            "expiry_status": expiry_status,
        })
        return binding

    if evidence.get("source_api") != "https://commons.wikimedia.org/w/api.php":
        binding.update({
            "evidence_class": str(evidence.get("asset_type") or evidence.get("evidence_class") or "PROJECT_OWNED"),
            "status": "PASS",
            "local_size_bytes": resolved_media.stat().st_size,
            "size_status": "NOT_APPLICABLE",
            "measured_duration_ms": measured_duration_ms,
        })
        return binding

    metadata = evidence.get("raw_selected_metadata") or {}
    local_sha1 = _sha1(resolved_media)
    local_size = resolved_media.stat().st_size
    declared_sha1 = metadata.get("commons_sha1")
    declared_size = metadata.get("size_bytes")
    try:
        declared_duration_ms = round(float(metadata["duration_seconds"]) * 1000)
    except (KeyError, TypeError, ValueError):
        declared_duration_ms = None
    duration_delta_ms = (
        abs(int(measured_duration_ms) - int(declared_duration_ms))
        if measured_duration_ms is not None and declared_duration_ms is not None
        else None
    )
    sha1_status = "PASS" if local_sha1 == declared_sha1 else "FAIL"
    size_status = "PASS" if local_size == declared_size else "FAIL"
    duration_status = (
        "PASS"
        if duration_delta_ms is not None and duration_delta_ms <= COMMONS_DURATION_TOLERANCE_MS
        else "FAIL"
    )
    binding.update({
        "evidence_class": "COMMONS_PERMANENT",
        "status": "PASS" if sha1_status == size_status == duration_status == "PASS" else "FAIL",
        "local_sha1": local_sha1,
        "declared_commons_sha1": declared_sha1,
        "sha1_status": sha1_status,
        "local_size_bytes": local_size,
        "declared_size_bytes": declared_size,
        "size_status": size_status,
        "measured_duration_ms": measured_duration_ms,
        "declared_duration_ms": declared_duration_ms,
        "duration_delta_ms": duration_delta_ms,
        "duration_status": duration_status,
        "source_page": evidence.get("source_page"),
        "description_url": metadata.get("description_url"),
        "download_url": metadata.get("download_url"),
        "metadata_revision_id": metadata.get("revision_id"),
        "metadata_timestamp": metadata.get("metadata_timestamp"),
    })
    return binding


def validate_phase6_rights_evidence(
    root: Path,
    asset: dict[str, Any],
    evidence: dict[str, Any],
    *,
    media_path: Path,
    measured_duration_ms: int | None = None,
    require_duration_binding: bool = False,
) -> dict[str, Any]:
    """Validate the rights contract and reconcile it to the exact manifest asset.

    A syntactically valid rights document is not enough: its source, decision,
    commercial status and owned/generated hashes must describe the same bytes.
    """

    schema = _read(root / "schemas/phase6_rights_evidence.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(evidence)
    asset_id = str(asset.get("asset_id") or "")
    if evidence.get("asset_id") != asset_id:
        raise ValueError("rights evidence asset identity mismatch")
    if evidence.get("decision") != asset.get("rights_decision"):
        raise ValueError("rights evidence decision diverges from manifest")
    held_typography = (
        evidence.get('asset_type') == 'PROJECT_OWNED_PROCEDURAL_TYPOGRAPHY_SUCCESSOR'
        and asset.get('production_eligible') is False and asset.get('content_quality_gate') == 'BLOCKED'
        and all(asset.get(key) is False for key in ('quality_authorized','render_authorized','publication_authorized'))
    )
    # A new source may have valid provenance while held out of every selection.
    # This result validates rights bytes only; residency/allocation still require
    # production eligibility AND independent content QA. Legacy rules unchanged.
    held_static = (
        evidence.get('asset_type') == 'PROJECT_OWNED_PROCEDURAL_STATIC'
        and evidence.get('decision') == 'AUTO_VERIFIED_PROCEDURAL_SOURCE'
        and asset.get('production_eligible') is False and asset.get('content_quality_gate') == 'BLOCKED'
        and all(asset.get(key) is False for key in
                ('quality_authorized', 'render_authorized', 'publication_authorized'))
    )
    if asset.get("commercial_use") is not True or (asset.get("production_eligible") is not True and not held_typography and not held_static):
        raise ValueError("rights evidence cannot elevate a non-commercial/non-production asset")

    if evidence.get("evidence_class") == "TEMPORARY_PERMISSION":
        if evidence.get("rights_status") != asset.get("rights_status"):
            raise ValueError("temporary permission rights status diverges from manifest")
        if evidence.get("source_url") != asset.get("source"):
            raise ValueError("temporary permission source URL diverges from manifest")
        if evidence.get("media_hash") != asset.get("content_hash") or _sha(media_path) != evidence.get("media_hash"):
            raise ValueError("temporary permission is not bound to local media bytes")
        binding = build_phase6_rights_byte_binding(
            root, evidence, media_path=media_path, measured_duration_ms=measured_duration_ms,
        )
        if binding["expiry_status"] != "PASS":
            raise ValueError("temporary permission is expired or has an invalid expiry")
        return binding

    if evidence.get("source_api") == "https://commons.wikimedia.org/w/api.php":
        metadata = evidence["raw_selected_metadata"]
        if asset.get("rights_status") not in {"CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED"}:
            raise ValueError("Commons evidence is incompatible with manifest rights status")
        if (
            evidence.get("source_page") != asset.get("source")
            or metadata.get("description_url") != evidence.get("source_page")
            or metadata.get("rights_status") != asset.get("rights_status")
            or metadata.get("license_short") != asset.get("license")
            or metadata.get("license_version") != asset.get("license_version")
        ):
            raise ValueError("Commons license/source metadata diverges from manifest")
        if metadata.get("rights_status") == "CC_COMMERCIAL" and not metadata.get("license_url"):
            raise ValueError("commercial Commons evidence lacks its license URL")
        binding = build_phase6_rights_byte_binding(
            root, evidence, media_path=media_path, measured_duration_ms=measured_duration_ms,
        )
        # SHA-1 and size always bind the claim to the bytes.  The residency
        # gate additionally requires an independent FFprobe measurement.
        if binding["sha1_status"] != "PASS":
            raise ValueError("Commons SHA-1 does not match local media bytes")
        if binding["size_status"] != "PASS":
            raise ValueError("Commons size_bytes does not match local media bytes")
        if require_duration_binding and binding["duration_status"] != "PASS":
            raise ValueError(
                "Commons duration diverges from local FFprobe measurement "
                f"beyond {COMMONS_DURATION_TOLERANCE_MS} ms"
            )
        return binding

    if asset.get("rights_status") != "OWNED":
        raise ValueError("project-owned/generated evidence requires OWNED manifest status")
    if evidence.get("asset_type") == "PROJECT_OWNED_PROCEDURAL_STATIC":
        raster = _resolve(root, evidence["raster"])
        source = _resolve(root, evidence["source_svg"])
        if (raster != media_path.resolve() or raster.suffix.lower() != ".png"
                or evidence["raster_hash"] != asset.get("content_hash")
                or _sha(raster) != evidence["raster_hash"]
                or source.suffix.lower() != ".svg" or _sha(source) != evidence["source_svg_hash"]):
            raise ValueError("owned static source/raster binding differs")
        from xml.etree import ElementTree
        document = ElementTree.fromstring(source.read_bytes())
        if document.tag != "{http://www.w3.org/2000/svg}svg":
            raise ValueError("owned static source is not SVG")
        if any(node.tag.split("}")[-1] in {"image", "script", "foreignObject", "use"}
               or "@import" in (node.text or "").lower() or "url(" in (node.text or "").lower()
               or any(key.split("}")[-1].lower().startswith("on")
                      or key.split("}")[-1].lower() == "href"
                      or "url(" in str(value).lower() or "@import" in str(value).lower()
                      for key, value in node.attrib.items())
               for node in document.iter()):
            raise ValueError("owned static source contains external or executable content")
        if evidence.get('decision') == 'AUTO_VERIFIED_PROCEDURAL_SOURCE':
            from .procedural_infographics_phase5 import read_audio_static_source
            reference = evidence['composition_manifest']
            verified = read_audio_static_source(root, _resolve(root, reference['path']),
                                                expected_sha256=reference['sha256'])
            if (verified['layout']['composition_id'] != asset_id
                    or verified['layout']['version'] != evidence['provider']
                    or _resolve(root, verified['produced']['raster']) != raster
                    or verified['produced']['raster_hash'] != evidence['raster_hash']
                    or _resolve(root, verified['source_svg']) != source
                    or verified['source_svg_hash'] != evidence['source_svg_hash']):
                raise PermissionError('static rights differ from produced source')
            if asset.get('production_eligible') is True:
                from .asset_quality_phase5 import verify_audio_static_asset_admission
                verify_audio_static_asset_admission(root, asset)
        return build_phase6_rights_byte_binding(root, evidence, media_path=media_path,
                                              measured_duration_ms=None)
    derivative = _resolve(root, str(evidence.get("motion_derivative") or ""))
    if derivative != media_path.resolve():
        raise ValueError("owned/generated derivative path diverges from manifest media")
    if evidence.get("motion_hash") != asset.get("content_hash") or _sha(derivative) != evidence.get("motion_hash"):
        raise ValueError("owned/generated derivative hash diverges from manifest bytes")
    if evidence.get('asset_type') == 'PROJECT_OWNED_PROCEDURAL_TYPOGRAPHY_SUCCESSOR':
        from .procedural_infographics_phase5 import read_typography_source_manifest
        reference=evidence['source_manifest']
        verified=read_typography_source_manifest(root,Path(reference['path']),expected_sha256=reference['sha256'])
        matches=[row for row in verified['manifest']['assets'] if row['asset_id']==asset_id]
        if len(matches)!=1:raise ValueError('typography rights lack exact produced source')
        produced=matches[0]
        if (produced['layout_id']!=evidence['layout_id'] or produced['video_hash']!=evidence['motion_hash']
                or _resolve(root,produced['video_path'])!=derivative
                or produced['generator']!=evidence['provider']):
            raise ValueError('typography rights diverge from produced source')
        layout=verified['layouts'][produced['layout_id']]
        if (asset.get('historical_asset_id')!=produced['historical_asset_id']
                or asset.get('take_scope')!=[produced['take_id']]
                or asset.get('semantic_role')!=layout['source_spec']['semantic_role']
                or asset.get('tool_version')!=produced['generator']):
            raise ValueError('typography catalogue scope diverges from source layout')
        if asset.get('production_eligible') is True:
            from .asset_quality_phase5 import verify_typography_asset_admission
            verify_typography_asset_admission(root,asset)
        return build_phase6_rights_byte_binding(root,evidence,media_path=media_path,
                                              measured_duration_ms=measured_duration_ms)
    if evidence.get("asset_type") == "AI_GENERATED_ORIGINAL_WITH_LOCAL_MOTION_DERIVATIVE":
        source_key, hash_key = "source_image", "source_image_hash"
    elif evidence.get("asset_type") == "PROJECT_OWNED_PROCEDURAL_VECTOR_MOTION":
        source_key, hash_key = "source_svg", "source_svg_hash"
    else:
        raise ValueError("unsupported owned/generated rights evidence class")
    source = _resolve(root, str(evidence.get(source_key) or ""))
    if not source.is_file() or _sha(source) != evidence.get(hash_key):
        raise ValueError("owned/generated source hash is missing or divergent")
    disclosure = evidence.get("platform_disclosure") or {}
    if not isinstance(disclosure.get("required"), bool) or not str(disclosure.get("reason") or "").strip():
        raise ValueError("owned/generated evidence lacks a disclosure decision")
    return build_phase6_rights_byte_binding(
        root, evidence, media_path=media_path, measured_duration_ms=measured_duration_ms,
    )


def _probe(path: Path, command_runner: Callable[..., Any]) -> tuple[str, int | None, str | None]:
    try:
        result = command_runner(
            [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        if int(getattr(result, "returncode", 1)) != 0:
            return "FAIL", None, f"FFPROBE_EXIT_{getattr(result, 'returncode', 'UNKNOWN')}"
        payload = json.loads(str(getattr(result, "stdout", "") or "{}"))
        duration_ms = round(float(payload["format"]["duration"]) * 1000)
        if duration_ms <= 0:
            raise ValueError("non-positive media duration")
        return "PASS", duration_ms, None
    except Exception as exc:
        return "FAIL", None, f"{type(exc).__name__}:{exc}"


def _receipt_identity(root: Path, path: Path, value: dict[str, Any]) -> dict[str, Any]:
    return {
        "audit_id": value["audit_id"],
        "receipt_path": path.resolve().relative_to(root.resolve()).as_posix(),
        "sha256": _sha(path),
        "manifest_content_hash": value["manifest_content_hash"],
    }


@scoped_typography_reads
def verify_phase6_asset_residency(
    root: Path = ROOT,
    *,
    receipt_path: str | Path | None = None,
    expected_sha256: str | None = None,
    expected_audit_id: str | None = None,
    required_asset_ids: Iterable[str] | None = None,
    command_runner: Callable[..., Any] = subprocess.run,
    recheck_media: bool = True,
    recheck_decode: bool = False,
) -> dict[str, Any]:
    """Validate one immutable residency receipt and, optionally, the live bytes.

    Downstream stages must bind to a receipt under ``RECEIPTS``.  ``latest`` is
    only a discovery pointer and is never itself accepted as immutable proof.
    """

    root = root.resolve()
    if receipt_path is None:
        latest_path = root / LATEST
        latest = _read(latest_path)
        candidate = root / RECEIPTS / f"{latest['audit_id']}.json"
        if not candidate.is_file() or latest_path.read_bytes() != candidate.read_bytes():
            raise PermissionError("asset-residency latest is not byte-identical to its immutable receipt")
    else:
        raw = Path(receipt_path)
        candidate = (raw if raw.is_absolute() else root / raw).resolve()
    parent = (root / RECEIPTS).resolve()
    if candidate.parent != parent:
        raise PermissionError("asset-residency receipt is outside the immutable receipt directory")
    value = _read(candidate)
    schema = _read(root / "schemas/phase6_asset_residency_audit.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    _validate_timestamp(value.get("audited_at"))
    if value.get("audit_id") != _audit_id(value):
        raise PermissionError("asset-residency audit_id does not match its complete timestamped content")
    if candidate.name != f"{value['audit_id']}.json":
        raise PermissionError("asset-residency receipt filename and audit id diverge")
    observed_receipt_hash = _sha(candidate)
    if expected_sha256 is not None and observed_receipt_hash != expected_sha256:
        raise PermissionError("asset-residency receipt hash mismatch")
    if expected_audit_id is not None and value["audit_id"] != expected_audit_id:
        raise PermissionError("asset-residency audit id mismatch")
    if value.get("status") != "PASS" or value.get("selection_authorized") is not True:
        raise PermissionError("asset-residency receipt does not authorize selection")

    manifest_path = root / MANIFEST
    if not manifest_path.is_file() or _sha(manifest_path) != value["manifest_content_hash"]:
        raise PermissionError("asset-residency manifest changed after the audit")
    manifest = _read(manifest_path)
    manifest_rows = manifest.get("assets") or []
    receipt_rows = value.get("assets") or []
    manifest_assets = {item["asset_id"]: item for item in manifest_rows}
    receipt_assets = {item["asset_id"]: item for item in receipt_rows}
    if len(manifest_assets) != len(manifest_rows) or len(receipt_assets) != len(receipt_rows):
        raise PermissionError("duplicate asset identity in manifest or residency receipt")
    selected = sorted(set(required_asset_ids or receipt_assets))
    if not selected or any(asset_id not in receipt_assets for asset_id in selected):
        raise PermissionError("asset-residency receipt does not cover every required asset")

    if recheck_media:
        for asset_id in selected:
            record = receipt_assets[asset_id]
            asset = manifest_assets.get(asset_id)
            if asset is None or record.get("status") != "PASS":
                raise PermissionError(f"asset-residency record is not eligible: {asset_id}")
            media = _resolve(root, str(asset["uri"]))
            rights = _resolve(root, str(asset["rights_evidence_uri"]))
            frozen_rights = _resolve(root, str(record.get("rights_evidence_path") or ""))
            if frozen_rights.parent != (root / RIGHTS_RECEIPTS).resolve():
                raise PermissionError(f"rights evidence is not an immutable residency snapshot: {asset_id}")
            expected_rights_hash = f"sha256:{frozen_rights.stem}"
            if not frozen_rights.is_file() or _sha(frozen_rights) != expected_rights_hash or _sha(rights) != expected_rights_hash:
                raise PermissionError(f"rights evidence bytes changed after residency audit: {asset_id}")
            stat = media.stat()
            attributes = int(getattr(stat, "st_file_attributes", 0))
            if attributes & (FILE_ATTRIBUTE_OFFLINE | FILE_ATTRIBUTE_RECALL_ON_OPEN | FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS):
                raise PermissionError(f"asset is offline or recall-backed: {asset_id}")
            current_hash = _sha(media)
            if not (
                current_hash == asset.get("content_hash")
                and current_hash == record.get("expected_content_hash")
                and current_hash == record.get("observed_content_hash")
            ):
                raise PermissionError(f"asset bytes changed after residency audit: {asset_id}")
            evidence = _read(rights)
            frozen_evidence = _read(frozen_rights)
            if evidence.get("asset_id") != asset_id or frozen_evidence != evidence:
                raise PermissionError(f"rights evidence identity changed: {asset_id}")
            duration_ms = int(record.get("duration_ms") or 0)
            if recheck_decode:
                probe_status, duration_ms, probe_error = _probe(media, command_runner)
                if probe_status != "PASS" or duration_ms is None:
                    raise PermissionError(f"asset decode failed after residency audit: {asset_id}:{probe_error}")
            try:
                current_binding = validate_phase6_rights_evidence(
                    root,
                    asset,
                    evidence,
                    media_path=media,
                    measured_duration_ms=duration_ms,
                    require_duration_binding=True,
                )
            except Exception as exc:
                raise PermissionError(f"rights evidence is not semantically valid: {asset_id}:{type(exc).__name__}:{exc}") from exc
            sealed_binding = record.get("rights_byte_binding")
            if value.get("schema_version") != "1.2.0" or sealed_binding != current_binding:
                raise PermissionError(f"rights-to-bytes binding is absent or divergent: {asset_id}")
            safe_end = max((int(item["end_ms"]) for item in asset.get("safe_ranges") or []), default=0)
            if safe_end <= 0 or duration_ms < safe_end:
                raise PermissionError(f"asset duration no longer covers its safe ranges: {asset_id}")

    identity = _receipt_identity(root, candidate, value)
    identity["verified_asset_ids"] = selected
    return identity


@scoped_typography_reads
def run_phase6_asset_residency_audit(
    root: Path = ROOT,
    *,
    now: datetime | None = None,
    command_runner: Callable[..., Any] = subprocess.run,
) -> dict[str, Any]:
    root = root.resolve()
    timestamp = _stamp(now)
    manifest_path = root / MANIFEST
    manifest = _read(manifest_path)
    manifest_hash = _sha(manifest_path)
    candidates = [
        item for item in manifest.get("assets") or []
        if item.get("production_eligible") is True
        and item.get("commercial_use") is True
        and item.get("rights_status") in RIGHTS_OK
        and item.get("content_quality_gate") == "PASS"
        and not metadata_publicity_risks(item)
    ]
    records: list[dict[str, Any]] = []
    for asset in sorted(candidates, key=lambda item: item["asset_id"]):
        media = root / "__invalid_asset_path__"
        rights = root / "__invalid_rights_path__"
        expected = str(asset["content_hash"])
        observed: str | None = None
        read_error: str | None = None
        size: int | None = None
        attributes = 0
        try:
            media = _resolve(root, str(asset["uri"]))
            observed = _sha(media)
            stat = media.stat()
            size = stat.st_size
            attributes = int(getattr(stat, "st_file_attributes", 0))
        except Exception as exc:
            read_error = f"{type(exc).__name__}:{exc}"
        probe_status, duration_ms, probe_error = _probe(media, command_runner) if observed else ("FAIL", None, "MEDIA_NOT_READABLE")
        rights_status, rights_error = "FAIL", None
        rights_record_path = str(rights)
        rights_binding = _empty_rights_byte_binding()
        try:
            rights = _resolve(root, str(asset["rights_evidence_uri"]))
            rights_record_path = str(rights)
            rights_bytes = rights.read_bytes()
            evidence = json.loads(rights_bytes.decode("utf-8-sig"))
            rights_binding = build_phase6_rights_byte_binding(
                root, evidence, media_path=media, measured_duration_ms=duration_ms,
            )
            validate_phase6_rights_evidence(
                root,
                asset,
                evidence,
                media_path=media,
                measured_duration_ms=duration_ms,
                require_duration_binding=True,
            )
            rights_digest = hashlib.sha256(rights_bytes).hexdigest()
            frozen_rights = root / RIGHTS_RECEIPTS / f"{rights_digest}.json"
            _write_immutable_bytes(frozen_rights, rights_bytes, label="asset rights evidence")
            rights_record_path = frozen_rights.resolve().relative_to(root).as_posix()
            rights_status = "PASS"
        except Exception as exc:
            rights_error = f"{type(exc).__name__}:{exc}"
        hash_status = "PASS" if observed == expected else "FAIL"
        offline = bool(attributes & FILE_ATTRIBUTE_OFFLINE)
        recall = bool(attributes & (FILE_ATTRIBUTE_RECALL_ON_OPEN | FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS))
        status = "PASS" if hash_status == rights_status == probe_status == "PASS" and not offline and not recall else "FAIL"
        records.append({
            "asset_id": asset["asset_id"], "path": str(media), "size_bytes": size,
            "expected_content_hash": expected, "observed_content_hash": observed,
            "hash_status": hash_status, "read_error": read_error,
            "file_attributes": attributes, "offline_attribute": offline, "recall_attribute": recall,
            "probe_status": probe_status, "duration_ms": duration_ms, "probe_error": probe_error,
            "rights_status": asset["rights_status"], "rights_evidence_path": rights_record_path,
            "rights_evidence_status": rights_status, "rights_evidence_error": rights_error,
            "rights_byte_binding": rights_binding,
            "safe_capacity_ms": sum(int(item["end_ms"]) - int(item["start_ms"]) for item in asset.get("safe_ranges") or []),
            "status": status,
        })
    blockers = [item["asset_id"] for item in records if item["status"] != "PASS"]
    verified = len(records) - len(blockers)
    status = "PASS" if len(records) >= 12 and not blockers else "BLOCKED"
    value = {
        "schema_version": "1.2.0", "audit_id": "asset-residency-phase6-pending", "phase": 6, "status": status,
        "library_id": manifest.get("library_id"), "manifest_path": MANIFEST.as_posix(),
        "manifest_content_hash": manifest_hash, "eligible_asset_count": len(records),
        "verified_asset_count": verified, "blocked_asset_ids": blockers,
        "total_verified_bytes": sum(int(item["size_bytes"] or 0) for item in records if item["status"] == "PASS"),
        "total_safe_capacity_ms": sum(item["safe_capacity_ms"] for item in records if item["status"] == "PASS"),
        "assets": records, "minimum_pool_size": 12, "selection_authorized": status == "PASS",
        "publication_authorized": False, "technical_cost_brl": 0, "audited_at": timestamp,
    }
    value["audit_id"] = _audit_id(value)
    audit_id = value["audit_id"]
    schema = _read(root / "schemas/phase6_asset_residency_audit.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    immutable = root / RECEIPTS / f"{audit_id}.json"
    _write_immutable(immutable, value)
    _write(root / LATEST, value)
    if (root / LATEST).read_bytes() != immutable.read_bytes():
        raise PermissionError("asset-residency latest diverged from immutable receipt")
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_asset_residency_audit(), ensure_ascii=False, indent=2))
