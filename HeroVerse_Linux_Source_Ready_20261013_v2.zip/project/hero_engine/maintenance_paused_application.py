"""Explicit paused branch of maintenance_protocol; no scheduler or restart.

An externally reviewed envelope hash is the trust anchor, NOT a hash learned
from the offered proof. The regression launcher owns its evidence. This consumer
does not execute tests, issue historical receipts or manufacture an ACK.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import tomllib
from contextlib import ExitStack, closing
from datetime import datetime, timezone
from pathlib import Path

from . import maintenance_protocol as p
from .maintenance_snapshot import _json, _publish
from .maintenance_unittest_result import consume_execution_result
from .production_capacity import Phase6ResourcePreparation, measure_local_resources
from .phase6_maintenance_verification import verify_local_migration_evidence

RUNS = p.RUNTIME / "maintenance-runs"
TASK = "HeroEngine-Phase5-CentralManager"
COMMAND = ".venv/Scripts/python.exe -B -u -X utf8 -m unittest discover -s tests -v"
VIEWS = {p.RUNTIME / "fingerprint.json", p.PREDICTION_RUNTIME_PATH, p.MEDIA_EXECUTOR_STATUS_PATH,
         p.QUALITY_EXECUTOR_STATUS_PATH,
         p.EXECUTIVE_STATUS_PATH, p.EXECUTIVE_STATUS_MARKDOWN_PATH, p.CONTROL_CYCLE_ERROR_PATH}
PROOF_FILES = {"candidate-before.json", "candidate-after.json", "dependencies-before.json",
               "dependencies-after.json", "test-inventory.json", "schema-inventory.json",
               "unittest.stdout.log", "unittest.stderr.log", "full-process-result.json",
               "verifier-result.json", "preservation-before.json", "preservation-after.json"}
IMPLEMENTATIONS = ("maintenance_protocol.py", "maintenance_paused_application.py",
                   "maintenance_unittest_result.py", "maintenance_snapshot.py",
                   "phase6_maintenance_verification.py", "phase6_media_remediation_wait.py",
                   "phase6_forward_post_effect_eligibility.py",
                   "production_capacity.py")


def require(condition, reason):
    if not condition:
        raise PermissionError("PAUSED_APPLICATION_" + reason)


def _failure_code(exc: BaseException) -> str:
    """Return a non-sensitive, stable gate code for a failed paused run.

    A failed run is terminal evidence: it must explain which *protocol gate*
    rejected the transaction without serialising arbitrary exception text (which
    can contain a host path or provider detail).  OS-level PermissionError
    instances and unexpected exception classes intentionally remain classified
    rather than being treated as a successful protocol rejection.
    """
    if isinstance(exc, PermissionError):
        message = str(exc)
        prefix = "PAUSED_APPLICATION_"
        if message.startswith(prefix):
            candidate = message[len(prefix):]
            if re.fullmatch(r"[A-Z0-9_]+", candidate):
                return candidate
        # Nested protocol guards use their own stable uppercase namespaces.
        # Preserve only that code (never the trailing host/file detail).
        nested = re.match(r"([A-Z][A-Z0-9_]+)(?::|$)", message)
        if nested is not None:
            return nested.group(1)
        return "UNCLASSIFIED_PERMISSION_ERROR"
    return "UNCLASSIFIED_" + type(exc).__name__.upper()


def _path(root, relative):
    require(type(relative) is str and relative and "\\" not in relative
            and not Path(relative).is_absolute() and ".." not in Path(relative).parts, "PATH_INVALID")
    path = root / relative
    p._paused_cancel_safe_path(root, path)
    require(path.resolve().is_relative_to(root), "PATH_ESCAPED")
    return path


def _digest(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _records(paths, root=None):
    rows = []
    for path in paths:
        raw = path.read_bytes()
        rows.append({"path": path.relative_to(root).as_posix() if root else str(path.resolve()),
                     "size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    return sorted(rows, key=lambda row: row["path"])


def source_paths(root):
    paths = [path for folder in ("hero_engine", "tests", "schemas", "scripts")
             for path in (root / folder).rglob("*") if path.is_file()
             and path.suffix in {".py", ".ps1", ".json"} and "__pycache__" not in path.parts]
    paths += [root / name for name in ("requirements.txt", "pyproject.toml") if (root / name).is_file()]
    return sorted(paths)


def candidate_identity(root):
    """Same byte identity rule used by T15–T19; no approval is produced."""
    files = _records(source_paths(root), root)
    raw = "".join(f"{r['path']}\t{r['sha256']}\t{r['size_bytes']}\n" for r in files).encode()
    return {"source_set_sha256": hashlib.sha256(raw).hexdigest(), "file_count": len(files), "files": files}


def _dependency_paths():
    # Narrow execution dependency profile, not AV models or arbitrary caches.
    # Full Python stdlib plus actual validator packages, including native rpds.
    files = {Path(sys.executable).resolve(), Path(sys._base_executable).resolve()}
    base = Path(sys.base_prefix)
    for directory in (base / "Lib", base / "DLLs"):
        files.update(path for path in directory.rglob("*") if path.is_file()
                     and path.suffix.lower() in {".py", ".pyd", ".dll", ".zip"}
                     and not {"site-packages", "__pycache__", "test", "tests"}.intersection(path.parts))
    files.update(base.glob("python*.dll"))
    files.update(base.glob("python*.zip"))
    for package in ("jsonschema", "jsonschema_specifications", "referencing", "attrs", "attr", "rpds"):
        spec = importlib.util.find_spec(package)
        require(spec is not None and spec.origin is not None, "DEPENDENCY_UNAVAILABLE")
        directory = Path(spec.origin).parent
        files.update(path for path in directory.rglob("*") if path.is_file()
                     and path.suffix.lower() in {".py", ".pyd", ".dll", ".json"})
    cfg = Path(sys.prefix) / "pyvenv.cfg"
    if cfg.is_file():
        files.add(cfg)
    return sorted(files)


def dependency_identity():
    return {"profile": "paused-maintenance-python-validator-v1", "python_version": sys.version,
            "executable": str(Path(sys.executable).resolve()), "files": _records(_dependency_paths())}


def _host_observation(root):
    """Bounded read-only Windows boundary. Never changes tasks or processes."""
    require(os.name == "nt", "WINDOWS_OBSERVATION_REQUIRED")
    shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    script = """$ErrorActionPreference='Stop'
function Test-ProvenReadOnlyObserver($process) {
 if($process.Name -notmatch '^(powershell|pwsh)(\\.exe)?$'){return $false}
 if($process.CommandLine -notmatch '(?i)\\s-NoProfile(?:\\s|$)'){return $false}
 # A signature in an argument/comment is not an invocation. Only exempt a
 # fully parsed, narrowly read-only command; dynamic/unknown commands, method
 # calls, redirections and script-file/encoded launchers remain fail-closed.
 if($process.CommandLine -notmatch '(?is)^(.*?)\\s-Command\\s+(.+)$'){return $false}
 $prefix=$Matches[1]; $body=$Matches[2].Trim()
 # Do not mistake arguments to -File/-EncodedCommand for a script body.
 # Prefix abbreviations and quoted switches are deliberately conservative.
 if($prefix -match '(?i)-(?:f|e|c)[a-z]*'){return $false}
 if($body.StartsWith('"') -and $body.EndsWith('"')){$body=$body.Substring(1,$body.Length-2)}
 $tokens=$null; $parseErrors=$null
 $ast=[System.Management.Automation.Language.Parser]::ParseInput($body,[ref]$tokens,[ref]$parseErrors)
 if($parseErrors.Count -gt 0){return $false}
 $unsafe=$ast.FindAll({param($node)
   $node -is [System.Management.Automation.Language.InvokeMemberExpressionAst] -or
   $node -is [System.Management.Automation.Language.FileRedirectionAst] -or
   $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -or
   $node -is [System.Management.Automation.Language.TypeExpressionAst] -or
   $node -is [System.Management.Automation.Language.TypeConstraintAst] -or
   $node -is [System.Management.Automation.Language.TypeDefinitionAst] -or
   $node -is [System.Management.Automation.Language.UsingStatementAst] -or
   $node -is [System.Management.Automation.Language.ScriptBlockExpressionAst]
 },$true)
 if($unsafe.Count -gt 0){return $false}
 $allowed=@('Get-Content','Get-Item','Get-Process','Get-CimInstance',
   'Get-ScheduledTask','Get-ScheduledTaskInfo','Select-Object','ConvertTo-Json',
   'Out-String','Write-Output','Start-Sleep','Test-Path','Get-FileHash','Get-Date','Get-Location')
 $commands=$ast.FindAll({param($node) $node -is [System.Management.Automation.Language.CommandAst]},$true)
 foreach($command in $commands){
   if($command.InvocationOperator -ne [System.Management.Automation.Language.TokenKind]::Unknown -or
      $command.GetCommandName() -notin $allowed){return $false}
 }
 return $true
}
$all=@(Get-CimInstance Win32_Process -ErrorAction Stop)
$ancestors=@([int]$env:HERO_APPLICATION_PID, [int]$PID)
$cursor=[int]$env:HERO_APPLICATION_PID
for($i=0;$i -lt 12;$i++){ $entry=@($all | Where-Object ProcessId -eq $cursor); if($entry.Count -ne 1){break}; $cursor=[int]$entry[0].ParentProcessId; $ancestors+= $cursor }
$suspects=@($all | Where-Object { $_.ProcessId -notin $ancestors -and
 ($_.Name -match '^(pythonw?|ffmpeg|ffprobe)(\\.exe)?$' -or
  ($_.Name -match '^(powershell|pwsh)(\\.exe)?$' -and [string]::IsNullOrWhiteSpace($_.CommandLine)) -or
  ($_.CommandLine -match 'central_manager_phase5|scripts[\\\\/]daily\\.ps1' -and
   -not (Test-ProvenReadOnlyObserver $_)) -or
  ($_.Name -match '^pythonw?(\\.exe)?$' -and $_.CommandLine -match 'maintenance_protocol.*apply-paused')) } |
 ForEach-Object { [ordered]@{pid=[int]$_.ProcessId;identity_known=($null -ne $_.CreationDate -and -not [string]::IsNullOrWhiteSpace($_.CommandLine))} })
$t=@(Get-ScheduledTask -TaskName 'HeroEngine-Phase5-CentralManager' -ErrorAction Stop)
if($t.Count -ne 1){throw 'ambiguous task'}
[ordered]@{task_name=$t[0].TaskName;task_state=[string]$t[0].State;task_enabled=[bool]$t[0].Settings.Enabled;executors=$suspects}|ConvertTo-Json -Depth 5 -Compress
"""
    env = dict(os.environ, HERO_APPLICATION_PID=str(os.getpid()))
    child = subprocess.run([str(shell), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script],
                           capture_output=True, timeout=15, env=env, check=True)
    host = _json(child.stdout)
    automation = Path.home() / ".codex/automations/hero-engine-rotina-di-ria/automation.toml"
    raw = automation.read_bytes()
    host.update(automation_paused=tomllib.loads(raw.decode("utf-8-sig")).get("status") == "PAUSED",
                automation_hash=_digest(raw))
    return host


def _check_host(root):
    host = _host_observation(root)
    require(host.get("task_name") == TASK and host.get("task_state") == "Disabled"
            and host.get("task_enabled") is False and host.get("automation_paused") is True
            and type(host.get("executors")) is list and not host["executors"], "EXECUTOR_OR_SCHEDULE_NOT_PROVEN_STOPPED")
    for relative in (p.REQUEST_PATH, p.ACK_PATH, p.RECOVERY_WINDOW_PATH):
        require(not (root / relative).exists() and not (root / relative).is_symlink(), "MAINTENANCE_BARRIER_PRESENT")
    lock = p._read(root / p.RUNTIME / "manager-lock.json")
    p.validate(root, "central_manager_lock.schema.json", lock)
    pid_path = root / p.RUNTIME / "manager.pid"
    if pid_path.is_file():
        manager = int(pid_path.read_text("utf-8-sig").strip())
    else:
        # The manager's canonical finally removes its own PID file. Never
        # reconstruct that file or fabricate a live identity to admit upkeep.
        require(not pid_path.exists() and not pid_path.is_symlink()
                and lock["state"] == "RELEASED", "MANAGER_IDENTITY_UNCERTAIN")
        manager = lock["holder_pid"]
        # Bind this intentional absence to the transaction's repeated host
        # comparison; a PID file appearing later is a changed boundary.
        host = dict(host, manager_pid_file_absent=True)
    require(type(lock["holder_pid"]) is int and manager == lock["holder_pid"] > 0, "MANAGER_IDENTITY_UNCERTAIN")
    require(p._parse(lock["lease_expires_at"]) <= datetime.now(timezone.utc), "MANAGER_LEASE_OPEN")
    p._paused_cancel_absent(manager, "MANAGER")
    return host


def _operational_paths(root):
    paths = {p.RUNTIME / name for name in ("PAUSE", "manager.pid", "manager.lock", "manager-lock.json")}
    paths |= {Path("data/hero_engine.db"), Path("output/production/phase5/pilot-001/integrity_manifest.json"),
              Path("output/production/phase6/shared-assets/asset_manifest.json")}
    if not (root / p.RUNTIME / "manager.pid").is_file():
        _check_host(root)
    for directory in ("output/operations", "output/production", "output/audits", "config"):
        for path in (root / directory).rglob("*"):
            if path.is_file() and path.suffix in {".json", ".md"}:
                paths.add(path.relative_to(root))
    # Only the existing migration's derived targets / exact correlated-error
    # archive may change. Their preimages are owned by its existing journal.
    require(all((root / name).is_file() for name in (
        p.RUNTIME / "PAUSE", p.RUNTIME / "manager.lock",
        p.RUNTIME / "manager-lock.json", Path("data/hero_engine.db"),
        Path("output/production/phase5/pilot-001/integrity_manifest.json"),
        Path("output/production/phase6/shared-assets/asset_manifest.json"))), "PROTECTED_SOURCE_MISSING")
    paths = {path for path in paths if path not in VIEWS
             and not path.is_relative_to(p.CONTROL_CYCLE_ERROR_ARCHIVE)}
    return sorted(path for path in paths if (root / path).is_file())


def _prepare(root, total_bytes):
    # Do not bypass Phase6ResourcePreparation._unpaused. Maintenance is not a
    # production stage. Reuse only the existing measurement/shortage primitives.
    sample = measure_local_resources(root)
    required = {"required_ram_bytes": max(512 * 1024**2, 4 * total_bytes),
                "required_output_free_bytes": 5 * 1024**3 + 3 * total_bytes,
                "required_temp_free_bytes": 1024**3 + total_bytes}
    for key in ("available_ram_bytes", "output_free_bytes", "temp_free_bytes"):
        require(type(sample.get(key)) is int and sample[key] >= 0, "RESOURCE_PROBE_UNKNOWN")
    require(type(sample.get("cpu_load_percent")) in (float, int)
            and math.isfinite(sample["cpu_load_percent"]) and 0 <= sample["cpu_load_percent"] <= 100, "RESOURCE_LOAD_UNKNOWN")
    causes = Phase6ResourcePreparation._shortages(sample, required)
    # This entry owns no idle media captures, hence no foreign reclamation.
    require(not causes, "RESOURCE_WAIT:" + ",".join(causes) + ";next_check_seconds=60")
    return {"status": "ADMITTED", "sample": sample, "requirements": required,
            "own_concurrency": 1, "released_idle_resources": 0}


def read_regression_proof(root, envelope_path, expected_hash, expected_candidate, stack):
    """Authenticate exact regression bytes, not mutable post-restart state.

    This reader does not authorize application or restart. The applying caller
    must additionally prove quiescence and the current preservation population.
    """
    require(re.fullmatch(r"sha256:[0-9a-f]{64}", expected_hash) is not None
            and re.fullmatch(r"[0-9a-f]{64}", expected_candidate) is not None, "EXTERNAL_ANCHOR_INVALID")
    path = _path(root, envelope_path.as_posix())
    require(path.parent.parent == root / RUNS, "PROOF_NOT_EXACT_RUN")
    pins = []

    def read(target):
        p._paused_cancel_safe_path(root, target)
        pin = stack.enter_context(closing(p._PausedCancelPin(target)))
        pins.append(pin)
        return pin.payload

    raw = read(path)
    require(_digest(raw) == expected_hash, "ENVELOPE_HASH_DIVERGED")
    envelope = _json(raw)
    require(set(envelope) == {"schema_version", "purpose", "root", "proof_run", "candidate_sha256", "files"}
            and envelope["schema_version"] == "1.0.0"
            and envelope["purpose"] == "EXACT_LOCAL_REGRESSION_FOR_PAUSED_APPLICATION"
            and envelope["proof_run"] == path.parent.relative_to(root).as_posix()
            and envelope["root"] == str(root) and envelope["candidate_sha256"] == expected_candidate
            and set(envelope["files"]) == PROOF_FILES, "ENVELOPE_CONTRACT_DIVERGED")
    payloads = {}
    for name in sorted(PROOF_FILES):
        payloads[name] = read(path.parent / name)
        require(_digest(payloads[name]) == envelope["files"][name], "PROOF_FILE_DIVERGED:" + name)
    docs = {name: _json(raw) for name, raw in payloads.items() if name.endswith(".json")}
    current = candidate_identity(root)
    require(current["source_set_sha256"] == expected_candidate, "CANDIDATE_DIVERGED")
    for name in IMPLEMENTATIONS:
        require(p.file_hash(root / "hero_engine" / name) == p.file_hash(Path(__file__).with_name(name)), "EXECUTED_IMPLEMENTATION_DIVERGED")
    for name in ("candidate-before.json", "candidate-after.json"):
        require(all(docs[name].get(key) == value for key, value in current.items()), "SOURCE_PROOF_DIVERGED")
    require(docs["dependencies-before.json"] == docs["dependencies-after.json"] == dependency_identity(), "DEPENDENCIES_DIVERGED")
    process = docs["full-process-result.json"]
    require(type(process.get("exit_code")) is int and process["exit_code"] == 0
            and process.get("timed_out") is False and process.get("command") == COMMAND
            and type(process.get("test_pid")) is int and process["test_pid"] > 0
            and p._parse(process["started_at"]) < p._parse(process["finished_at"]) <= datetime.now(timezone.utc), "PROCESS_PROOF_INVALID")
    require(p._parse(docs["candidate-before.json"]["observed_at"]) <= p._parse(process["started_at"])
            < p._parse(process["finished_at"]) <= p._parse(docs["candidate-after.json"]["observed_at"])
            <= datetime.now(timezone.utc), "REGRESSION_TIME_BOUNDARY_INVALID")
    with tempfile.TemporaryDirectory(prefix="hero-paused-inventory-", dir=path.parent) as directory:
        actual = p.build_validation_manifests(root, output_dir=Path(directory))
        for key, name in (("test_inventory_path", "test-inventory.json"), ("schema_inventory_path", "schema-inventory.json")):
            require(p._read(root / actual[key]) == docs[name], "INVENTORY_DIVERGED")
    result = consume_execution_result(
        result=docs["verifier-result.json"], inventory_bytes=payloads["test-inventory.json"],
        expected_inventory_hash=envelope["files"]["test-inventory.json"],
        expected_test_count=docs["test-inventory.json"]["test_count"],
        stdout_bytes=payloads["unittest.stdout.log"], stderr_bytes=payloads["unittest.stderr.log"],
        process_exit_code=process["exit_code"],
    )
    require(type(process.get("wall_seconds")) in (int, float)
            and math.isfinite(process["wall_seconds"])
            and process["wall_seconds"] >= result["duration_seconds"], "PROCESS_DURATION_INVALID")
    before, after = docs["preservation-before.json"], docs["preservation-after.json"]
    require(before == after and set(before) == {"operation", "task_enabled", "automation_paused", "files"}
            and before["operation"] == "PAUSED" and before["task_enabled"] is False
            and before["automation_paused"] is True and type(before["files"]) is dict
            and bool(before["files"]), "REGRESSION_PRESERVATION_INVALID")
    return {"candidate": current, "regression": result, "pins": pins,
            "proof_files": envelope["files"], "proof_path": path.relative_to(root).as_posix(),
            "protected_hashes": before["files"], "regression_finished_at": process["finished_at"],
            "regression_process": process, "proof_family": "LEGACY_REGRESSION"}


def _load_proof(root, envelope_path, expected_hash, expected_candidate, stack):
    # Legacy full-regression evidence remains byte-for-byte governed by its
    # original reader.  The only forward alternative is a purpose-separated,
    # current-operational proof that binds the committed integrity successor,
    # receipt-bound captions and current visual contract before it can enter
    # this same transactional boundary.
    from .current_operational_application_proof import (
        NotCurrentOperationalProof, read_current_operational_proof,
    )
    try:
        proof = read_current_operational_proof(root, envelope_path, expected_hash, expected_candidate, stack)
    except NotCurrentOperationalProof:
        proof = read_regression_proof(root, envelope_path, expected_hash, expected_candidate, stack)
    p._paused_cancel_absent(proof["regression_process"]["test_pid"], "REGRESSION_EXECUTOR")
    expected_protected = set(_operational_paths(root)) | set(p._paused_cancel_database_files(root))
    require(set(proof["protected_hashes"]) == {name.as_posix() for name in expected_protected}, "REGRESSION_PRESERVATION_INCOMPLETE")
    for relative, digest in proof["protected_hashes"].items():
        require(p.file_hash(_path(root, relative)) == digest, "PRESERVATION_SOURCE_DIVERGED")
    return proof


def _safe_rollback(states, *, replace_bytes=None):
    owned, foreign = [], []
    for state in states:
        target = state["target"]
        if p._target_matches_preimage(target, existed=state["existed_before"], payload=state["before"]):
            continue
        if p._target_matches_desired(target, exists=state["desired_exists"], payload=state["payload"]):
            owned.append(state)
        else:
            foreign.append(state["relative_path"])
    result = p._rollback_migration_targets(owned, replace_bytes=replace_bytes)
    result["foreign_targets_preserved"] = foreign
    result["verified"] = result["verified"] and not foreign
    return result


def _check_view_preimages(root, run, preimages):
    journal = run / "local-runtime-migration-journal.json"
    if journal.is_file():
        # A foreign change during derivation must not become the transaction's
        # newly accepted 'before'. Compare its journal to the earlier snapshot.
        for item in p._read(journal)["targets"]:
            if Path(item["path"]) in VIEWS:
                require(preimages[item["path"]] == {"exists": item["existed_before"],
                        "sha256": item["before_hash"]}, "VIEW_CHANGED_DURING_PREPARATION")
    else:
        for name, before in preimages.items():
            target = _path(root, name)
            current = {"exists": target.is_file(), "sha256": p.file_hash(target) if target.is_file() else None}
            require(current == before, "VIEW_CHANGED_AFTER_PREFLIGHT")


def prepare_forward_post_effect_journal(root, run):
    """Persist the queue subtransaction's exact preimage before its first effect.

    This is deliberately preparation only: it neither materializes eligibility
    nor mutates the queue.  The caller must retain the normal PAUSE/mutex and
    revalidate the returned journal immediately before any later commit.
    """
    from .phase6_forward_post_effect_eligibility import (
        derive_forward_post_effect_current_plan,
        forward_post_effect_journal_contract,
    )
    root, run = Path(root).resolve(), Path(run).resolve()
    require((root / p.RUNTIME / "PAUSE").is_file(), "OWNER_PAUSE_REQUIRED")
    require(run.is_relative_to(root) and run.is_dir() and not run.is_symlink(), "FORWARD_JOURNAL_RUN_INVALID")
    plan = derive_forward_post_effect_current_plan(root)
    journal = forward_post_effect_journal_contract(plan)
    target = _path(root, journal["eligibility_receipt_expected"]["path"])
    if target.exists():
        require(target.is_file() and not target.is_symlink(), "FORWARD_JOURNAL_RECEIPT_TYPE_INVALID")
        observed = {"exists": True, "sha256": p.file_hash(target)}
        require(observed["sha256"] == journal["eligibility_receipt_expected"]["sha256"], "FORWARD_JOURNAL_RECEIPT_FOREIGN")
    else:
        observed = {"exists": False, "sha256": None}
    journal["eligibility_receipt_preimage"] = observed
    _publish(run / "forward-post-effect-journal.json", p._canonical_bytes(journal))
    return journal


def revalidate_prepared_forward_post_effect_journal(root, run, *, allow_own_materialized=False):
    """Fail closed if the prepared forward edge or its receipt preimage drifted."""
    root, run = Path(root).resolve(), Path(run).resolve()
    require((root / p.RUNTIME / "PAUSE").is_file(), "OWNER_PAUSE_REQUIRED")
    journal_path = run / "forward-post-effect-journal.json"
    require(run.is_relative_to(root) and journal_path.is_file() and not journal_path.is_symlink(), "FORWARD_JOURNAL_MISSING")
    stored = _json(journal_path.read_bytes())
    temporary = run / ".forward-journal-revalidation"
    require(not temporary.exists(), "FORWARD_JOURNAL_REVALIDATION_RESIDUE")
    temporary.mkdir()
    fresh = prepare_forward_post_effect_journal(root, temporary)
    # The helper writes into an owned disposable subdirectory so its derivation
    # is identical to preparation; remove only that exact generated evidence.
    try:
        stored_plan = {key: value for key, value in stored.items()
                       if key != "eligibility_receipt_preimage"}
        fresh_plan = {key: value for key, value in fresh.items()
                      if key != "eligibility_receipt_preimage"}
        require(stored_plan == fresh_plan, "FORWARD_JOURNAL_PLAN_DRIFTED")
        same_preimage = stored.get("eligibility_receipt_preimage") == fresh.get("eligibility_receipt_preimage")
        own_materialized = (
            allow_own_materialized
            and stored.get("eligibility_receipt_preimage") == {"exists": False, "sha256": None}
            and fresh.get("eligibility_receipt_preimage") == {
                "exists": True,
                "sha256": stored["eligibility_receipt_expected"]["sha256"],
            }
        )
        require(same_preimage or own_materialized, "FORWARD_JOURNAL_PREIMAGE_DRIFTED")
        return stored
    finally:
        for path in sorted(temporary.rglob("*"), reverse=True):
            if path.is_file():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
        if temporary.exists():
            temporary.rmdir()


def commit_prepared_forward_post_effect_journal(root, run):
    """Commit one already-prepared forward edge; safe to resume after its own write."""
    from .phase6_forward_post_effect_eligibility import (
        derive_forward_post_effect_current_plan,
        forward_post_effect_journal_contract,
        materialize_forward_post_effect_eligibility,
        verify_forward_post_effect_current_eligibility,
    )
    from .queue_phase6 import TransactionalQueue
    root, run = Path(root).resolve(), Path(run).resolve()
    require((root / p.RUNTIME / "PAUSE").is_file(), "OWNER_PAUSE_REQUIRED")
    committed_path = run / "forward-post-effect-committed.json"
    if committed_path.is_file():
        return _json(committed_path.read_bytes())
    journal = revalidate_prepared_forward_post_effect_journal(root, run, allow_own_materialized=True)
    plan = derive_forward_post_effect_current_plan(root)
    observation = plan.get("committed_successor_observation")
    if observation is not None:
        protected_view = p._PROTECTED_DATABASE_VIEW.get()
        capture = protected_view[1] if protected_view is not None and protected_view[0] == root else None
        if capture is not None:
            capture.revalidate()
        queue = (TransactionalQueue(root, path=capture.work_root / p.QUEUE_PATH,
                                    read_only=True, immutable=True)
                 if capture is not None else TransactionalQueue(root, read_only=True, immutable=True))
    else:
        queue = TransactionalQueue(root)
    successor_preimage = journal.get("successor_queue_preimage")
    if isinstance(successor_preimage, dict) and successor_preimage.get("exists") is False:
        # The absence was authenticated before the queue write boundary opened.
        # Create only the deterministic, inert command required by this exact
        # forward lineage; voice, render, upload and publication remain outside
        # this transaction.  Re-derive immediately so a foreign/interleaved
        # command cannot be adopted merely because its ID happens to match.
        successor = queue.enqueue(
            idempotency_key=str(successor_preimage["idempotency_key"]),
            operation_id=plan["media_unit"]["operation_id"],
            channel_id=plan["media_unit"]["channel_id"],
            task_type=plan["media_unit"]["task_type"],
            payload=dict(plan["successor_job"]["payload"]),
            max_attempts=3,
        )
        if (
            successor.get("job_id") != successor_preimage["job_id"]
            or successor.get("idempotency_key") != successor_preimage["idempotency_key"]
        ):
            raise PermissionError("FORWARD_JOURNAL_SUCCESSOR_CREATION_DIVERGED")
        refreshed = derive_forward_post_effect_current_plan(root)
        refreshed_contract = forward_post_effect_journal_contract(refreshed)
        stored_without_preimage = {
            key: value for key, value in journal.items()
            if key not in {"successor_queue_preimage", "eligibility_receipt_preimage"}
        }
        refreshed_without_preimage = {
            key: value for key, value in refreshed_contract.items()
            if key != "successor_queue_preimage"
        }
        if (
            refreshed_without_preimage != stored_without_preimage
            or refreshed_contract.get("successor_queue_preimage", {}).get("exists") is not True
        ):
            raise PermissionError("FORWARD_JOURNAL_SUCCESSOR_CREATION_DIVERGED")
        plan = refreshed
    if observation is not None:
        # Derivation reopened the historical receipt and committed edge. Do not
        # re-run pre-effect eligibility against an already attempted command.
        reference = journal["eligibility_receipt_expected"]
        require(p.file_hash(_path(root, reference["path"])) == reference["sha256"],
                "FORWARD_JOURNAL_RECEIPT_DIVERGED")
    else:
        reference = materialize_forward_post_effect_eligibility(
            root, authority_root_job=plan["authority_root_job"], predecessor_job=plan["predecessor_job"],
            successor_job=plan["successor_job"], media_unit=plan["media_unit"],
            historical_input=plan["historical_input_receipt"], current_input=plan["current_input_receipt"],
        )
    require(reference == journal["eligibility_receipt_expected"], "FORWARD_JOURNAL_RECEIPT_DIVERGED")
    if plan.get("committed_forward_replay") is True:
        # The exact queue effect was already committed by this lineage before
        # an outer paused finalization rolled its derived views back.  It is
        # safe only to verify and record that immutable edge here; attempting
        # to reconcile or adopt again would mutate a completed queue effect.
        edge = queue.get_media_job_supersession(plan["predecessor_job_id"])
        # ``TransactionalQueue`` deliberately returns the immutable receipt
        # document, whose authoritative job is nested under ``receipt``.  Some
        # test doubles retain the compact edge shape, so normalize only these
        # two authenticated representations; never accept a caller-supplied
        # successor or a missing receipt identity.
        nested_authoritative = (
            edge.get("receipt", {}).get("authoritative_job", {}).get("job_id")
            if isinstance(edge, dict) and isinstance(edge.get("receipt"), dict)
            else None
        )
        edge_successor = edge.get("authoritative_job_id") if isinstance(edge, dict) else None
        if edge_successor is None:
            edge_successor = nested_authoritative
        require(isinstance(edge, dict)
                and edge.get("state") == "COMMITTED"
                and edge_successor == plan["successor_job_id"],
                "FORWARD_JOURNAL_COMMITTED_REPLAY_DIVERGED")
        if observation is not None:
            require(edge.get("receipt_path") == observation["edge_path"]
                    and edge.get("receipt_sha256") == observation["edge_sha256"],
                    "FORWARD_JOURNAL_COMMITTED_OBSERVATION_DIVERGED")
        outcome = {
            "state": "COMMITTED",
            "receipt": edge.get("receipt"),
            "receipt_path": edge.get("receipt_path"),
            "receipt_sha256": edge.get("receipt_sha256"),
            "replayed_committed_edge": True,
        }
    elif plan.get("pending_tail_rebase") is True:
        # Do not bypass a previously committed, inert canonical tail.  The
        # queue's ordinary reconciler owns this exact pre-effect transition,
        # recomputes its remediation proof and records the immutable edge.
        # This branch is deliberately narrower than the historical-terminal
        # adoption below: only the frozen PENDING/zero-attempt tail may enter.
        from .phase6_media_authority import reconcile_phase6_media_authority

        reconciled = reconcile_phase6_media_authority(
            root, authoritative_job_id=plan["successor_job_id"]
        )
        matching = [
            item for item in reconciled.get("superseded_jobs", [])
            if item.get("job_id") == plan["predecessor_job_id"]
        ]
        require(len(matching) == 1, "FORWARD_JOURNAL_PENDING_TAIL_NOT_REBASED")
        edge = queue.get_media_job_supersession(plan["predecessor_job_id"])
        require(isinstance(edge, dict) and edge.get("state") == "COMMITTED",
                "FORWARD_JOURNAL_QUEUE_NOT_COMMITTED")
        outcome = {
            "state": "COMMITTED",
            "receipt": edge.get("receipt"),
            "receipt_path": matching[0].get("receipt_path"),
            "receipt_sha256": matching[0].get("receipt_sha256"),
            "reconciled": reconciled,
        }
    else:
        outcome = queue.adopt_forward_post_effect_current_input(
            plan["authority_root_job_id"], predecessor_job_id=plan["predecessor_job_id"],
            successor_job_id=plan["successor_job_id"], media_unit=plan["media_unit"],
            historical_input_receipt=plan["historical_input_receipt"], current_input_receipt=plan["current_input_receipt"],
            eligibility_receipt=reference,
            eligibility_verifier=verify_forward_post_effect_current_eligibility,
        )
        require(outcome.get("state") == "COMMITTED", "FORWARD_JOURNAL_QUEUE_NOT_COMMITTED")
    receipt = {"schema_version": "1.0.0", "status": "COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT",
               "journal": {"path": (run / "forward-post-effect-journal.json").relative_to(root).as_posix(),
                           "sha256": p.file_hash(run / "forward-post-effect-journal.json")},
               "eligibility_receipt": reference, "queue_outcome": outcome,
               "publication_authorized": False, "technical_cost_brl": 0}
    _publish(committed_path, p._canonical_bytes(receipt))
    return receipt


def recover_incomplete_paused_application(root, *, application_id):
    """Roll back a crashed paused application only from its own exact journal.

    This is deliberately a recovery path, not a way to manufacture a missing
    ``committed.json``.  It accepts only a run which has no terminal receipt,
    whose four derived views still equal its journal candidates, and whose
    queue/effects boundary remains unchanged.  The original run is never
    edited; recovery evidence is written to a separate run.
    """
    root = Path(root).resolve()
    require(type(application_id) is str and re.fullmatch(r"maintenance-request-[0-9TZa-f-]+", application_id),
            "RECOVERY_APPLICATION_ID_INVALID")
    original = _path(root, (RUNS / application_id).as_posix())
    recovery = _path(root, (RUNS / ("recovery-" + application_id)).as_posix())
    require(original.is_dir() and not original.is_symlink(), "RECOVERY_ORIGINAL_RUN_MISSING")
    binding = {"root": str(root), "application_id": application_id}

    with p._paused_cancel_exclusive(), ExitStack() as stack:
        host = _check_host(root)
        pause = stack.enter_context(closing(p._PausedCancelPin(root / p.RUNTIME / "PAUSE")))
        require(not (original / "committed.json").exists()
                and not (original / "failed.json").exists()
                and not (original / "paused-finalization-failure.json").exists(),
                "RECOVERY_TERMINAL_RECEIPT_PRESENT")

        required = ("prepared.json", "after.json", "local-runtime-migration-journal.json",
                    "local-runtime-migration-outcome.json")
        pins = {}
        for name in required:
            path = original / name
            p._paused_cancel_safe_path(root, path)
            require(path.is_file() and not path.is_symlink(), "RECOVERY_EVIDENCE_MISSING")
            pins[name] = stack.enter_context(closing(p._PausedCancelPin(path)))
        prepared = _json(pins["prepared.json"].payload)
        after = _json(pins["after.json"].payload)
        journal = _json(pins["local-runtime-migration-journal.json"].payload)
        outcome = _json(pins["local-runtime-migration-outcome.json"].payload)
        require(prepared.get("status") == "PREPARED_WHILE_PAUSED" and prepared.get("binding")
                and after.get("host") == host and after.get("boundary") == prepared.get("boundary")
                and after.get("protected_hashes") == prepared.get("protected_hashes"),
                "RECOVERY_PREPARATION_DIVERGED")
        require(journal.get("record_type") == "PREPARED" and outcome.get("record_type") == "COMMITTED"
                and journal.get("request_id") == application_id and outcome.get("request_id") == application_id
                and outcome.get("journal_path") == (original / "local-runtime-migration-journal.json").relative_to(root).as_posix()
                and outcome.get("journal_hash") == _digest(pins["local-runtime-migration-journal.json"].payload),
                "RECOVERY_JOURNAL_DIVERGED")
        zero_effect = {"external_api_calls": 0, "publication_effects": 0,
                       "operational_queue_mutations": 0, "technical_cost_brl": 0}
        require(all(journal.get(key) == value and outcome.get(key) == value for key, value in zero_effect.items()),
                "RECOVERY_EFFECT_BOUNDARY_DIVERGED")
        targets, committed = journal.get("targets"), outcome.get("target_hashes")
        require(isinstance(targets, list) and isinstance(committed, list)
                and journal.get("target_count") == len(targets) == outcome.get("target_count") == len(committed),
                "RECOVERY_TARGET_SET_DIVERGED")

        target_states = []
        committed_by_path = {item.get("path"): item for item in committed if isinstance(item, dict)}
        require(len(committed_by_path) == len(committed), "RECOVERY_TARGET_IDENTITY_AMBIGUOUS")
        for item in targets:
            require(isinstance(item, dict) and isinstance(item.get("ordinal"), int)
                    and isinstance(item.get("path"), str) and isinstance(item.get("existed_before"), bool)
                    and isinstance(item.get("desired_exists"), bool),
                    "RECOVERY_TARGET_CONTRACT_INVALID")
            relative = item["path"]
            target = _path(root, relative)
            expected_before = original / f"{item['ordinal']:02d}-{Path(relative).name}.before"
            expected_candidate = original / f"{item['ordinal']:02d}-{Path(relative).name}.candidate"
            before_pin = candidate_pin = target_pin = None
            if item["existed_before"]:
                require(item.get("before_path") == expected_before.relative_to(root).as_posix()
                        and isinstance(item.get("before_hash"), str) and expected_before.is_file(),
                        "RECOVERY_PREIMAGE_PATH_INVALID")
                before_pin = stack.enter_context(closing(p._PausedCancelPin(expected_before)))
                before = before_pin.payload
                require(_digest(before) == item["before_hash"], "RECOVERY_PREIMAGE_HASH_DIVERGED")
            else:
                require(item.get("before_path") is None and item.get("before_hash") is None,
                        "RECOVERY_PREIMAGE_PATH_INVALID")
                before = b""
            if item["desired_exists"]:
                require(item.get("candidate_path") == expected_candidate.relative_to(root).as_posix()
                        and isinstance(item.get("candidate_hash"), str) and expected_candidate.is_file(),
                        "RECOVERY_CANDIDATE_PATH_INVALID")
                candidate_pin = stack.enter_context(closing(p._PausedCancelPin(expected_candidate)))
                desired = candidate_pin.payload
                require(_digest(desired) == item["candidate_hash"], "RECOVERY_CANDIDATE_HASH_DIVERGED")
                target_pin = stack.enter_context(closing(p._PausedCancelPin(target, capture=False)))
            else:
                require(item.get("candidate_path") is None and item.get("candidate_hash") is None,
                        "RECOVERY_CANDIDATE_PATH_INVALID")
                desired = b""
            committed_item = committed_by_path.get(relative)
            require(committed_item is not None and committed_item.get("exists") is bool(item.get("desired_exists"))
                    and committed_item.get("content_hash") == (item["candidate_hash"] if item["desired_exists"] else None),
                    "RECOVERY_OUTCOME_DIVERGED")
            require(p._target_matches_desired(target, exists=bool(item["desired_exists"]), payload=desired),
                    "RECOVERY_TARGET_FOREIGN_OR_INCOMPLETE")
            target_states.append({"target": target, "relative_path": relative,
                                  "existed_before": bool(item.get("existed_before")), "before": before,
                                  "desired_exists": bool(item["desired_exists"]), "payload": desired,
                                  "evidence_pins": tuple(pin for pin in (before_pin, candidate_pin) if pin is not None),
                                  "target_pin": target_pin})

        require(not recovery.exists(), "RECOVERY_ALREADY_EXISTS")
        recovery.mkdir(parents=True, exist_ok=False)
        capture = p._PausedCancelDatabaseCapture(root, recovery, binding, stack)
        boundary = p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True)
        require(boundary == prepared["boundary"], "RECOVERY_BOUNDARY_DIVERGED")
        _publish(recovery / "prepared.json", p._canonical_bytes({"status": "RECOVERY_PREPARED_WHILE_PAUSED",
                 "binding": binding, "original_run": original.relative_to(root).as_posix(), "host": host,
                 "boundary": boundary, "database_capture": capture.reference(),
                 "journal_hash": _digest(pins["local-runtime-migration-journal.json"].payload)}))
        pins_to_revalidate = (
            list(pins.values()) + [pause]
            + [pin for state in target_states for pin in state["evidence_pins"]]
            + [state["target_pin"] for state in target_states if state["target_pin"] is not None]
        )
        for pin in pins_to_revalidate:
            pin.revalidate()
        capture.revalidate()
        require(_check_host(root) == host and p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True) == boundary,
                "RECOVERY_CHANGED_BEFORE_ROLLBACK")
        # Windows replacement cannot proceed while this recovery's own read
        # handle pins the target.  The target has just been revalidated; its
        # immutable evidence and every safety boundary remain pinned.  Any
        # subsequent foreign write is rejected by _safe_rollback rather than
        # overwritten.
        for state in target_states:
            if state["target_pin"] is not None:
                state["target_pin"].close()
        result = _safe_rollback(target_states)
        require(result["verified"], "RECOVERY_ROLLBACK_NOT_VERIFIED")
        receipt = {"schema_version": "1.0.0", "status": "ROLLED_BACK_INCOMPLETE_PAUSED_APPLICATION",
                   "binding": binding, "original_run": original.relative_to(root).as_posix(),
                   "journal_hash": _digest(pins["local-runtime-migration-journal.json"].payload),
                   "rollback": result, "operational_state": "PAUSED", "restart_permitted": False,
                   "D116": "NOT_EXECUTED", "technical_cost_brl": 0, "external_api_calls": 0}
        _publish(recovery / "committed.json", p._canonical_bytes(receipt))
        return receipt


def attest_no_effect_preprepare_application(root, *, application_id):
    """Close only an interrupted application that never reached ``prepared``.

    A host can terminate a process while it is copying preimages.  That is not
    an application result and must neither be retried under the same binding
    nor silently discarded.  This path verifies the original run has no
    prepared/migration/terminal record and that every captured mutable view is
    still byte-identical.  It writes a separate recovery receipt and grants no
    operational authority; a later application still requires a fresh proof.
    """
    root = Path(root).resolve()
    require(type(application_id) is str and re.fullmatch(r"maintenance-request-[0-9TZa-f-]+", application_id),
            "NO_EFFECT_APPLICATION_ID_INVALID")
    original = _path(root, (RUNS / application_id).as_posix())
    recovery = _path(root, (RUNS / ("recovery-no-effect-" + application_id)).as_posix())
    require(original.is_dir() and not original.is_symlink(), "NO_EFFECT_ORIGINAL_RUN_MISSING")
    binding = {"root": str(root), "application_id": application_id}

    with p._paused_cancel_exclusive(), ExitStack() as stack:
        host = _check_host(root)
        pause = stack.enter_context(closing(p._PausedCancelPin(root / p.RUNTIME / "PAUSE")))
        forbidden = ("prepared.json", "preview.json", "after.json", "committed.json", "failed.json",
                     "paused-finalization-failure.json", "local-runtime-migration-journal.json",
                     "local-runtime-migration-outcome.json")
        require(not any((original / name).exists() for name in forbidden), "NO_EFFECT_STAGE_ALREADY_REACHED")
        views_root = original / "views-before"
        require(views_root.is_dir() and not views_root.is_symlink(), "NO_EFFECT_VIEW_PREIMAGES_MISSING")
        view_records = []
        for name in sorted(VIEWS):
            target = _path(root, name.as_posix())
            preimage = views_root / name
            p._paused_cancel_safe_path(root, preimage)
            if preimage.exists():
                require(preimage.is_file() and not preimage.is_symlink(), "NO_EFFECT_VIEW_PREIMAGE_INVALID")
                pin = stack.enter_context(closing(p._PausedCancelPin(preimage)))
                require(target.is_file() and pin.payload == target.read_bytes(), "NO_EFFECT_VIEW_CHANGED")
                view_records.append({"path": name.as_posix(), "exists": True, "sha256": _digest(pin.payload)})
            else:
                require(not target.exists(), "NO_EFFECT_VIEW_CHANGED")
                view_records.append({"path": name.as_posix(), "exists": False, "sha256": None})
        require(not recovery.exists(), "NO_EFFECT_RECOVERY_ALREADY_EXISTS")
        recovery.mkdir(parents=True, exist_ok=False)
        capture = p._PausedCancelDatabaseCapture(root, recovery, binding, stack)
        boundary = p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True)
        prepared = {"status": "NO_EFFECT_PREPARE_ATTESTED", "binding": binding,
                    "original_run": original.relative_to(root).as_posix(), "host": host,
                    "views": view_records, "database_capture": capture.reference(), "boundary": boundary}
        _publish(recovery / "prepared.json", p._canonical_bytes(prepared))
        pause.revalidate()
        capture.revalidate()
        require(_check_host(root) == host and p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True) == boundary,
                "NO_EFFECT_BOUNDARY_CHANGED")
        receipt = {"schema_version": "1.0.0", "status": "ABANDONED_BEFORE_PREPARE_NO_EFFECT",
                   "binding": binding, "original_run": original.relative_to(root).as_posix(),
                   "views": view_records, "operational_state": "PAUSED", "restart_permitted": False,
                   "D116": "NOT_EXECUTED", "technical_cost_brl": 0, "external_api_calls": 0}
        _publish(recovery / "committed.json", p._canonical_bytes(receipt))
        return receipt


def verify_archived_commit(root, run, binding):
    """Read historical application evidence; never authorize live repetition."""
    require((run / "committed.json").is_file() and not (run / "failed.json").exists()
            and not (run / "paused-finalization-failure.json").exists(), "PARTIAL_ATTEMPT_REQUIRES_REVIEW")
    receipt = _json((run / "committed.json").read_bytes())
    prepared = p._read(run / "prepared.json")
    base_fields = {"schema_version", "status", "application_id", "binding", "regression", "migration", "evidence",
                   "operational_state", "restart_permitted", "D116", "technical_cost_brl", "external_api_calls"}
    forward = prepared.get("forward_post_effect_journal")
    expected_fields = base_fields | ({"forward_post_effect"} if forward is not None else set())
    require(set(receipt) == expected_fields
            and receipt["schema_version"] == "1.0.0" and receipt["operational_state"] == "PAUSED"
            and type(receipt["technical_cost_brl"]) is int and receipt["technical_cost_brl"] == 0
            and type(receipt["external_api_calls"]) is int and receipt["external_api_calls"] == 0
            and receipt.get("application_id") == run.name
            and receipt.get("binding") == binding and receipt.get("status") == "APPLIED_WHILE_PAUSED"
            and receipt.get("restart_permitted") is False and receipt.get("D116") == "NOT_EXECUTED", "REPEAT_BINDING_INVALID")
    files = {path.relative_to(root).as_posix() for path in run.rglob("*")
             if path.is_file() and path != run / "committed.json"}
    required = {str((run / name).relative_to(root)).replace("\\", "/")
                for name in ("prepared.json", "after.json", "preview.json", "databases/manifest.json",
                             "local-runtime-migration-journal.json", "local-runtime-migration-outcome.json")}
    if forward is not None:
        expected_journal_relative = (run / "forward-post-effect-journal.json").relative_to(root).as_posix()
        journal_path = _path(root, forward.get("path", ""))
        forward_commit_path = run / "forward-post-effect-committed.json"
        require(forward.get("path") == expected_journal_relative
                and journal_path.is_file() and p.file_hash(journal_path) == forward.get("sha256")
                and forward_commit_path.is_file(), "FORWARD_ARCHIVE_JOURNAL_INVALID")
        require(receipt.get("forward_post_effect") == _json(forward_commit_path.read_bytes()),
                "FORWARD_ARCHIVE_COMMIT_DIVERGED")
        required |= {
            str(journal_path.relative_to(root)).replace("\\", "/"),
            str(forward_commit_path.relative_to(root)).replace("\\", "/"),
        }
    require(set(receipt["evidence"]) == files and required.issubset(files), "REPEAT_EVIDENCE_INCOMPLETE")
    for relative, digest in receipt["evidence"].items():
        target = _path(root, relative)
        require(target.is_relative_to(run) and p.file_hash(target) == digest, "REPEAT_EVIDENCE_DIVERGED")
    after = p._read(run / "after.json")
    require(prepared["binding"] == binding and prepared["status"] == "PREPARED_WHILE_PAUSED"
            and prepared["boundary"] == after["boundary"]
            and prepared["protected_hashes"] == after["protected_hashes"]
            and prepared["regression"] == receipt["regression"], "REPEAT_SNAPSHOT_DIVERGED")
    _check_view_preimages(root, run, prepared["view_preimages"])
    verify_local_migration_evidence(root, request_id=run.name, migration=receipt["migration"],
                                    scope="PAUSED_APPLICATION_ARCHIVE")
    outcome = p._read(run / "local-runtime-migration-outcome.json")
    require(outcome["record_type"] == "COMMITTED", "REPEAT_OUTCOME_INVALID")
    return receipt


def _verify_forward_archived_queue(root, run, forward_commit):
    """Authenticate the exact committed forward edge without writing it again."""
    from .queue_phase6 import TransactionalQueue

    journal = p._read(run / "forward-post-effect-journal.json")
    outcome = forward_commit.get("queue_outcome", {})
    queue = TransactionalQueue(root)
    stored = queue.get_media_job_supersession(journal["predecessor_job_id"])
    require(stored is not None and stored.get("state") == "COMMITTED"
            and stored.get("receipt") == outcome.get("receipt")
            and stored.get("receipt_sha256") == outcome.get("receipt_sha256"),
            "REPEAT_FORWARD_QUEUE_DIVERGED")
    jobs = {job.get("job_id"): job for job in queue.snapshot().get("jobs", [])}
    successor = jobs.get(journal["successor_job_id"])
    current = journal["current_input_receipt"]
    observation = journal.get("committed_successor_observation")
    if observation is not None:
        require(isinstance(successor, dict) and p.canonical_hash(successor) == observation["job_sha256"]
                and stored.get("receipt_path") == observation["edge_path"]
                and stored.get("receipt_sha256") == observation["edge_sha256"],
                "REPEAT_FORWARD_COMMITTED_OBSERVATION_DIVERGED")
        return
    require(isinstance(successor, dict) and successor.get("state") == "PENDING"
            and successor.get("attempt_count") == 0 and successor.get("lease_owner") is None
            and successor.get("lease_until") is None and successor.get("checkpoint") == {}
            and successor.get("payload", {}).get("input_receipt_id") == current.get("receipt_id"),
            "REPEAT_FORWARD_SUCCESSOR_DIVERGED")


def _verify_repeat(root, run, binding):
    receipt = verify_archived_commit(root, run, binding)
    verify_local_migration_evidence(root, request_id=run.name, migration=receipt["migration"])
    outcome = p._read(run / "local-runtime-migration-outcome.json")
    for target in outcome["target_hashes"]:
        path = _path(root, target["path"])
        require((path.is_file() and p.file_hash(path) == target["content_hash"]) if target["exists"]
                else not path.exists(), "REPEAT_TARGET_DIVERGED")
    if "forward_post_effect" in receipt:
        _verify_forward_archived_queue(root, run, receipt["forward_post_effect"])
    return receipt


def recover_forward_paused_finalization(root, *, application_id):
    """Record a crash after a committed forward edge without replaying it.

    This is intentionally separate from the normal rollback recovery.  A
    forward edge is durable queue history and cannot be rolled back by copying
    an older database.  The recovery therefore proves the already-committed
    edge, the committed local migration and the current PAUSE state, then
    writes a new immutable recovery receipt.  It never edits the interrupted
    run or issues another queue adoption.
    """
    root = Path(root).resolve()
    require(type(application_id) is str and re.fullmatch(r"maintenance-request-[0-9TZa-f-]+", application_id),
            "FORWARD_RECOVERY_APPLICATION_ID_INVALID")
    original = _path(root, (RUNS / application_id).as_posix())
    recovery = _path(root, (RUNS / ("recovery-forward-finalization-" + application_id)).as_posix())
    require(original.is_dir() and not original.is_symlink(), "FORWARD_RECOVERY_ORIGINAL_RUN_MISSING")
    with p._paused_cancel_exclusive(), ExitStack() as stack:
        host = _check_host(root)
        pause = stack.enter_context(closing(p._PausedCancelPin(root / p.RUNTIME / "PAUSE")))
        require(not (original / "committed.json").exists(), "FORWARD_RECOVERY_TERMINAL_RECEIPT_PRESENT")
        required = ("prepared.json", "after.json", "migration.json", "forward-post-effect-journal.json",
                    "forward-post-effect-committed.json", "local-runtime-migration-outcome.json")
        pins = {}
        for name in required:
            path = original / name
            p._paused_cancel_safe_path(root, path)
            require(path.is_file() and not path.is_symlink(), "FORWARD_RECOVERY_EVIDENCE_MISSING")
            pins[name] = stack.enter_context(closing(p._PausedCancelPin(path)))
        prepared = _json(pins["prepared.json"].payload)
        after = _json(pins["after.json"].payload)
        migration = _json(pins["migration.json"].payload)
        forward = _json(pins["forward-post-effect-committed.json"].payload)
        outcome = _json(pins["local-runtime-migration-outcome.json"].payload)
        require(prepared.get("status") == "PREPARED_WHILE_PAUSED"
                and isinstance(prepared.get("forward_post_effect_journal"), dict)
                and after.get("host") == host and after.get("boundary") == prepared.get("boundary")
                and after.get("protected_hashes") == prepared.get("protected_hashes"),
                "FORWARD_RECOVERY_PREPARATION_DIVERGED")
        require(forward.get("status") == "COMMITTED_FORWARD_POST_EFFECT_CURRENT_INPUT"
                and outcome.get("record_type") == "COMMITTED", "FORWARD_RECOVERY_OUTCOME_INVALID")
        verify_local_migration_evidence(root, request_id=application_id, migration=migration,
                                        scope="PAUSED_APPLICATION_ARCHIVE")
        for target in outcome.get("target_hashes", []):
            path = _path(root, target["path"])
            require((path.is_file() and p.file_hash(path) == target["content_hash"]) if target.get("exists")
                    else not path.exists(), "FORWARD_RECOVERY_TARGET_DIVERGED")
        _verify_forward_archived_queue(root, original, forward)
        require(not recovery.exists(), "FORWARD_RECOVERY_ALREADY_EXISTS")
        recovery.mkdir(parents=True, exist_ok=False)
        evidence = {path.relative_to(root).as_posix(): p.file_hash(path)
                    for path in original.rglob("*") if path.is_file()}
        receipt = {"schema_version": "1.0.0", "status": "RECOVERED_FORWARD_FINALIZATION_WHILE_PAUSED",
                   "original_run": original.relative_to(root).as_posix(), "host": host,
                   "migration": migration, "forward_post_effect": forward, "original_evidence": evidence,
                   "operational_state": "PAUSED", "restart_permitted": False,
                   "D116": "NOT_EXECUTED", "technical_cost_brl": 0, "external_api_calls": 0}
        for pin in list(pins.values()) + [pause]:
            pin.revalidate()
        require(_check_host(root) == host, "FORWARD_RECOVERY_HOST_CHANGED")
        _publish(recovery / "committed.json", p._canonical_bytes(receipt))
        return receipt


def _anchored_application_run(root, proof_envelope, expected_hash, expected_candidate):
    """Route an already-committed application without trusting mutable state.

    This deliberately verifies only the externally anchored envelope and the
    exact process record needed to derive the deterministic application ID.
    It grants no new authority; archive verification and live queue checks are
    still required by ``_verify_repeat`` before any result is returned.
    """
    require(re.fullmatch(r"sha256:[0-9a-f]{64}", expected_hash) is not None
            and re.fullmatch(r"[0-9a-f]{64}", expected_candidate) is not None,
            "EXTERNAL_ANCHOR_INVALID")
    path = _path(root, Path(proof_envelope).as_posix())
    require(path.parent.parent == root / RUNS and path.is_file(), "PROOF_NOT_EXACT_RUN")
    # Commit must not precede discovery of an incompatible reference path.
    # Direct-protocol aliases retain their exact externally anchored binding;
    # the downstream legacy process-witness branch remains canonical-only.
    reference_path_contract = p._schema(
        root, "phase6_paused_application_reference.schema.json"
    )["properties"]["proof_path"]
    require(p.Draft202012Validator(reference_path_contract).is_valid(
        Path(proof_envelope).as_posix()), "REFERENCE_PROOF_PATH_INVALID")
    raw = path.read_bytes()
    require(_digest(raw) == expected_hash, "ENVELOPE_HASH_DIVERGED")
    envelope = _json(raw)
    require(set(envelope) == {"schema_version", "purpose", "root", "proof_run", "candidate_sha256", "files"}
            and envelope.get("schema_version") == "1.0.0" and envelope.get("root") == str(root)
            and envelope.get("proof_run") == path.parent.relative_to(root).as_posix()
            and envelope.get("candidate_sha256") == expected_candidate
            and isinstance(envelope.get("files"), dict), "ENVELOPE_CONTRACT_DIVERGED")
    process_name = "full-process-result.json"
    require(isinstance(envelope["files"].get(process_name), str), "PROCESS_PROOF_MISSING")
    process_path = path.parent / process_name
    require(process_path.is_file() and _digest(process_path.read_bytes()) == envelope["files"][process_name],
            "PROCESS_PROOF_DIVERGED")
    process = _json(process_path.read_bytes())
    require(type(process.get("test_pid")) is int and process["test_pid"] > 0
            and type(process.get("exit_code")) is int and process["exit_code"] == 0
            and process.get("timed_out") is False
            and p._parse(process["started_at"]) < p._parse(process["finished_at"]),
            "PROCESS_PROOF_INVALID")
    stamp = p._parse(process["finished_at"])
    binding = {"root": str(root), "proof_path": Path(proof_envelope).as_posix(),
               "proof_hash": expected_hash, "candidate_sha256": expected_candidate}
    application_id = ("maintenance-request-" + stamp.strftime("%Y%m%dT%H%M%S%f")
                      + "0Z-" + p.canonical_hash(binding).split(":")[1][:8])
    return root / RUNS / application_id, binding


def write_direct_paused_application_reference(root, *, run, binding):
    """Publish a forward-only D-116 reference for a direct protocol commit.

    Legacy launcher references attest an OS child and exact stdout. A direct
    protocol invocation has no parent process witness, so this function never
    fabricates one. It binds only the committed transaction and its immutable
    prepared/journal/outcome records, and is idempotent after an interruption.
    """
    root = Path(root).resolve()
    run = Path(run).resolve()
    require(run.parent == root / RUNS and re.fullmatch(
        r"maintenance-request-[0-9]{8}T[0-9]{13}Z-[0-9a-f]{8}", run.name),
        "DIRECT_REFERENCE_RUN_INVALID")
    receipt = verify_archived_commit(root, run, binding)
    prepared = run / "prepared.json"
    journal = run / "local-runtime-migration-journal.json"
    outcome = run / "local-runtime-migration-outcome.json"
    migration = run / "migration.json"
    for path in (prepared, journal, outcome, migration):
        require(path.is_file() and not path.is_symlink(), "DIRECT_REFERENCE_EVIDENCE_MISSING")
    prepared_value = _json(prepared.read_bytes())
    journal_value = _json(journal.read_bytes())
    outcome_value = _json(outcome.read_bytes())
    require(prepared_value.get("binding") == binding, "DIRECT_REFERENCE_PREPARED_BINDING_DIVERGED")
    require(journal_value.get("request_id") == run.name and outcome_value.get("request_id") == run.name,
            "DIRECT_REFERENCE_MIGRATION_REQUEST_DIVERGED")
    require(outcome_value.get("record_type") == "COMMITTED"
            and outcome_value.get("journal_hash") == p.file_hash(journal),
            "DIRECT_REFERENCE_MIGRATION_OUTCOME_DIVERGED")
    require(receipt.get("migration") == _json(migration.read_bytes()),
            "DIRECT_REFERENCE_MIGRATION_DIVERGED")
    commit = run / "committed.json"
    suffix = run.name.removeprefix("maintenance-request-")
    record = root / RUNS / ("direct-application-reference-" + suffix)
    reference = {
        "schema_version": "1.1.0", "reference_kind": "DIRECT_PROTOCOL",
        "commit_path": commit.relative_to(root).as_posix(), "commit_sha256": p.file_hash(commit),
        "proof_path": binding["proof_path"], "proof_sha256": binding["proof_hash"],
        "candidate_sha256": binding["candidate_sha256"],
        "prepared_path": prepared.relative_to(root).as_posix(), "prepared_sha256": p.file_hash(prepared),
        "migration_journal_path": journal.relative_to(root).as_posix(),
        "migration_journal_sha256": p.file_hash(journal),
        "migration_outcome_path": outcome.relative_to(root).as_posix(),
        "migration_outcome_sha256": p.file_hash(outcome),
    }
    p.validate(root, "phase6_paused_application_reference.schema.json", reference)
    target = record / "paused-application-reference.json"
    if target.exists():
        require(target.is_file() and not target.is_symlink()
                and target.read_bytes() == p._canonical_bytes(reference),
                "DIRECT_REFERENCE_REPEAT_DIVERGED")
        return target
    require(not record.exists(), "DIRECT_REFERENCE_RECORD_EXISTS")
    record.mkdir(parents=False)
    _publish(target, p._canonical_bytes(reference))
    return target


def apply_paused(root, *, proof_envelope, expected_proof_hash, expected_candidate_hash):
    root = Path(root).resolve()
    require((root / p.RUNTIME / "PAUSE").is_file(), "OWNER_PAUSE_REQUIRED")
    binding = {"root": str(root), "proof_path": Path(proof_envelope).as_posix(),
               "proof_hash": expected_proof_hash, "candidate_sha256": expected_candidate_hash}
    with p._paused_cancel_exclusive(), ExitStack() as stack:
        host = _check_host(root)
        repeat_run, routed_binding = _anchored_application_run(
            root, proof_envelope, expected_proof_hash, expected_candidate_hash)
        require(routed_binding == binding, "REPEAT_BINDING_INVALID")
        if repeat_run.exists():
            require(repeat_run.is_dir() and not repeat_run.is_symlink(), "REPEAT_RUN_INVALID")
            prepared_repeat = p._read(repeat_run / "prepared.json")
            # A forward queue commit changes the queue bytes which its original
            # proof correctly captured *before* application.  Only that
            # explicitly journaled branch uses archive+live-edge replay; the
            # legacy path below retains its full preservation/capture checks.
            if "forward_post_effect_journal" in prepared_repeat:
                require(candidate_identity(root)["source_set_sha256"] == expected_candidate_hash,
                        "REPEAT_CANDIDATE_DIVERGED")
                result = _verify_repeat(root, repeat_run, binding)
                require(_check_host(root) == host, "HOST_CHANGED")
                write_direct_paused_application_reference(root, run=repeat_run, binding=binding)
                return result
        proof = _load_proof(root, Path(proof_envelope), expected_proof_hash, expected_candidate_hash, stack)
        # Existing migration/media schemas share this namespace. Its date here
        # is the pinned regression completion, NOT a fabricated request time or
        # process generation. The full binding disambiguates any short collision.
        stamp = p._parse(proof["regression_finished_at"])
        application_id = ("maintenance-request-" + stamp.strftime("%Y%m%dT%H%M%S%f")
                          + "0Z-" + p.canonical_hash(binding).split(":")[1][:8])
        run = root / RUNS / application_id
        source_set = source_paths(root)
        dependency_set = _dependency_paths()
        immutable = _operational_paths(root)
        require(p.RUNTIME / "PAUSE" in immutable, "OWNER_PAUSE_REQUIRED")
        database_files = p._paused_cancel_database_files(root)
        # Capacity must be admitted before this transaction opens hundreds of
        # immutable dependency handles.  Measuring afterwards turns the
        # protocol's own integrity protection into the cause of RESOURCE_WAIT.
        # The exact identities are still rehashed after all handles are owned;
        # this only moves a non-authorizing resource admission earlier.
        total_bytes = sum((root / name).stat().st_size for name in immutable) + sum(
            (root / name).stat().st_size for name in database_files)
        preparation = _prepare(root, total_bytes)
        pinned = []
        from .central_manager_phase5 import paused_fingerprint_source_paths
        fingerprint_sources = paused_fingerprint_source_paths(root)
        for path in source_set + dependency_set + [root / name for name in immutable + database_files] + fingerprint_sources:
            if path.is_relative_to(root):
                p._paused_cancel_safe_path(root, path)
            pinned.append(stack.enter_context(closing(p._PausedCancelPin(path, capture=False))))
        # Pinning follows validation: rehash once AFTER all handles are owned.
        require(candidate_identity(root) == proof["candidate"], "SOURCE_CHANGED_BEFORE_PIN")
        require(dependency_identity() == _json((root / proof["proof_path"]).with_name("dependencies-before.json").read_bytes()), "DEPENDENCY_CHANGED_BEFORE_PIN")
        protected = {name.as_posix(): p.file_hash(root / name) for name in immutable + database_files}
        require(protected == proof["protected_hashes"], "PROTECTED_CHANGED_BEFORE_PIN")
        immutable_hashes = {name.as_posix(): p.file_hash(root / name) for name in immutable}
        owned_goal_hash = immutable_hashes.get(p.GOAL_TRAJECTORY_PATH.as_posix())
        if run.exists():
            # Legacy repeat is read-only and never reconstructs missing completion.
            _check_host(root)
            result = _verify_repeat(root, run, binding)
            prepared = p._read(run / "prepared.json")
            previous = p._paused_cancel_verify_capture(run, binding, prepared["database_capture"])
            for item in previous["files"]:
                require(p.file_hash(root / item["relative"]) == item["sha256"], "REPEAT_DATABASE_CHANGED")
            for pin in pinned + proof["pins"]:
                pin.revalidate()
            write_direct_paused_application_reference(root, run=run, binding=binding)
            return result
        p._paused_cancel_safe_path(root, run)
        run.mkdir(parents=True, exist_ok=False)
        try:
            def replace_owned_goal(target, payload, *, rollback=False):
                """Hand off only this journaled target, under the held mutex.

                Keep the global population and authenticated preimage intact.
                The old Windows deny-delete handle cannot span os.replace, so
                close only its handles at the writer boundary, recheck exact
                bytes on EVERY atomic attempt, then immediately pin the new
                inode. Rollback uses the same handoff in the reverse direction.
                No foreign bytes become an accepted preimage or rollback target.
                """
                nonlocal owned_goal_hash
                writer = p._replace_bytes if rollback else p._commit_migration_replacement
                goal = root / p.GOAL_TRAJECTORY_PATH
                if target != goal or owned_goal_hash is None:
                    return writer(target, payload)
                with ExitStack() as evidence:
                    journal_pin = evidence.enter_context(closing(p._PausedCancelPin(
                        run / "local-runtime-migration-journal.json")))
                    journal = _json(journal_pin.payload)
                    matches = [item for item in journal["targets"]
                               if item["path"] == p.GOAL_TRAJECTORY_PATH.as_posix()]
                    require(journal["request_id"] == application_id and len(matches) == 1,
                            "OWNED_GOAL_JOURNAL_INVALID")
                    item = matches[0]
                    require(item["existed_before"] and item["desired_exists"] and item["changed"]
                            and item["before_hash"] == immutable_hashes[item["path"]],
                            "OWNED_GOAL_PREIMAGE_DIVERGED")
                    for path_field, hash_field in (("before_path", "before_hash"),
                                                  ("candidate_path", "candidate_hash")):
                        path = _path(root, item[path_field])
                        require(path.is_relative_to(run), "OWNED_GOAL_EVIDENCE_ORIGIN")
                        pin = evidence.enter_context(closing(p._PausedCancelPin(path)))
                        require(_digest(pin.payload) == item[hash_field], "OWNED_GOAL_EVIDENCE_DIVERGED")
                    expected = item["candidate_hash"] if rollback else item["before_hash"]
                    desired = item["before_hash"] if rollback else item["candidate_hash"]
                    require(owned_goal_hash == expected and _digest(payload) == desired,
                            "OWNED_GOAL_WRITE_NOT_AUTHORIZED")
                    owners = [pin for pin in pinned if pin.path == target]
                    require(bool(owners), "OWNED_GOAL_PROTECTION_MISSING")
                    for pin in owners:
                        pin.revalidate()
                    original_identity = owners[0].identity
                    def check_exact_preimage():
                        p._paused_cancel_safe_path(root, target)
                        info = target.lstat()
                        require((info.st_dev, info.st_ino) == original_identity,
                                "OWNED_GOAL_IDENTITY_CHANGED")
                        require(target.is_file() and p.file_hash(target) == expected,
                                "OWNED_GOAL_PREIMAGE_CHANGED")
                    check_exact_preimage()
                    for pin in owners:
                        pin.close()
                        pinned.remove(pin)
                    try:
                        # The actual replacement stays in the native atomic
                        # writer; the check is also applied to bounded retries.
                        p._replace_bytes(target, payload, recheck=check_exact_preimage)
                    finally:
                        # A writer can fail after replacement. Protect the
                        # observed inode before propagating to safe rollback.
                        pin = stack.enter_context(closing(p._PausedCancelPin(target, capture=False)))
                        pinned.append(pin)
                        actual = p.file_hash(target)
                        if actual == desired:
                            owned_goal_hash = desired
                        require(actual in (expected, desired), "OWNED_GOAL_FOREIGN_WRITE")

            def rollback_owned(states):
                return _safe_rollback(states, replace_bytes=lambda target, payload:
                                      replace_owned_goal(target, payload, rollback=True))

            capture = p._PausedCancelDatabaseCapture(root, run, binding, stack)
            token = p._PROTECTED_DATABASE_VIEW.set((root, capture))
            stack.callback(p._PROTECTED_DATABASE_VIEW.reset, token)
            boundary = p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True)
            view_preimages = {}
            for name in sorted(VIEWS):
                target = _path(root, name.as_posix())
                require(not target.exists() or target.is_file(), "VIEW_TYPE_UNKNOWN")
                raw = target.read_bytes() if target.is_file() else None
                view_preimages[name.as_posix()] = {"exists": raw is not None,
                                                  "sha256": _digest(raw) if raw is not None else None}
                if raw is not None:
                    _publish(run / "views-before" / name, raw)

            def recheck_nonview_boundary(owned_new_targets=()):
                """Recheck immutable inputs while the view transaction owns its writes.

                ``_migrate_local_runtime_views_transaction`` calls its guard
                before each sequential replacement and after it has written the
                derived views.  Those views are checked by that transaction
                against its exact before/desired bytes, so comparing them to
                their original preimages here would reject the transaction's
                own first write as foreign drift.
                """
                require(_check_host(root) == host, "HOST_CHANGED")
                require(source_paths(root) == source_set and _dependency_paths() == dependency_set, "FILE_SET_CHANGED")
                # ``current.json`` is a forward-only successor of the locked
                # historical goal trajectory.  It may be introduced by the
                # immediately preceding, journaled migration replacement;
                # accept it only when this exact invocation supplied its
                # staged bytes.  No other new operational path is admissible.
                expected_operational = set(immutable)
                current_goal = Path("output/operations/phase6/goal-trajectory/current.json")
                for relative, payload in owned_new_targets:
                    candidate = Path(relative)
                    require(candidate == current_goal,
                            "OWNED_OPERATIONAL_TARGET_UNEXPECTED")
                    # ``_migrate_local_runtime_views_transaction`` carries
                    # relative paths as ``Path`` values; the public resolver
                    # deliberately accepts only normalized strings.  Convert
                    # at this boundary rather than weakening that resolver.
                    target = _path(root, candidate.as_posix())
                    require(target.is_file() and p.file_hash(target) == _digest(payload),
                            "OWNED_OPERATIONAL_TARGET_DIVERGED")
                    expected_operational.add(candidate)
                require(set(_operational_paths(root)) == expected_operational,
                        "OPERATIONAL_FILE_SET_CHANGED")
                for pin in pinned + proof["pins"]:
                    if pin.path.is_relative_to(root):
                        p._paused_cancel_safe_path(root, pin.path)
                    pin.revalidate()
                if owned_goal_hash is not None:
                    require(p.file_hash(root / p.GOAL_TRAJECTORY_PATH) == owned_goal_hash,
                            "OWNED_GOAL_OBSERVATION_DIVERGED")
                capture.revalidate()
                require(p._paused_cancel_boundary(root, database_root=capture.work_root, contain_private_thumbnail=True) == boundary, "BOUNDARY_CHANGED")

            def recheck(owned_new_targets=()):
                recheck_nonview_boundary(owned_new_targets)
                _check_view_preimages(root, run, view_preimages)

            def recheck_after_owned_forward_commit(forward_commit, committed_targets):
                """Recheck every unchanged boundary after the queue's own commit.

                The generic recheck deliberately detects database drift.  Once
                this transaction commits its *own* reviewed queue edge, that
                comparison would turn a valid effect into a false foreign
                write.  Keep all non-queue pins strict and authenticate the
                exact committed supersession through the queue reader instead.
                """
                from .queue_phase6 import TransactionalQueue

                require(_check_host(root) == host, "HOST_CHANGED")
                require(source_paths(root) == source_set and _dependency_paths() == dependency_set,
                        "FILE_SET_CHANGED")
                # The reviewed forward queue edge materializes one immutable
                # supersession receipt under ``output/operations``.  That is
                # an owned effect, not a foreign writer.  Bind its exact path
                # and bytes to the queue outcome before allowing the final
                # recheck; every other population change remains fail-closed.
                outcome = forward_commit.get("queue_outcome")
                require(isinstance(outcome, dict), "FORWARD_QUEUE_OUTCOME_INVALID")
                receipt_relative = outcome.get("receipt_path")
                receipt_sha256 = outcome.get("receipt_sha256")
                require(isinstance(receipt_relative, str)
                        and isinstance(receipt_sha256, str), "FORWARD_QUEUE_RECEIPT_INVALID")
                receipt_path = _path(root, receipt_relative)
                from .queue_phase6 import MEDIA_JOB_SUPERSESSION_RECEIPTS
                expected_parent = (root / MEDIA_JOB_SUPERSESSION_RECEIPTS).resolve()
                require(receipt_path.parent == expected_parent
                        and receipt_path.name.startswith("phase6-media-supersession-")
                        and receipt_path.suffix == ".json"
                        and receipt_path.is_file()
                        and p.file_hash(receipt_path) == receipt_sha256,
                        "FORWARD_QUEUE_RECEIPT_INVALID")
                expected_operational = set(immutable)
                expected_operational.add(Path(receipt_relative))
                # A fresh forward edge also materializes its reviewed eligibility
                # receipt. Bind this second owned output to the *pre-write*
                # journal and its exact preimage; never derive permission from
                # an arbitrary file merely appearing after the queue commit.
                from .queue_phase6 import POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS
                eligibility = forward_commit.get("eligibility_receipt")
                expected_eligibility = (forward_journal or {}).get("eligibility_receipt_expected")
                eligibility_preimage = (forward_journal or {}).get("eligibility_receipt_preimage")
                require(isinstance(eligibility, dict)
                        and set(eligibility) == {"receipt_id", "path", "sha256"}
                        and eligibility == expected_eligibility
                        and isinstance(eligibility.get("receipt_id"), str)
                        and re.fullmatch(r"phase6-post-effect-visual-eligibility-[0-9a-f]{24}",
                                         eligibility["receipt_id"]) is not None
                        and isinstance(eligibility.get("path"), str)
                        and isinstance(eligibility.get("sha256"), str),
                        "FORWARD_ELIGIBILITY_RECEIPT_INVALID")
                eligibility_relative = POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS / (eligibility["receipt_id"] + ".json")
                require(eligibility["path"] == eligibility_relative.as_posix()
                        and eligibility_preimage == (
                            {"exists": True, "sha256": immutable_hashes[eligibility_relative.as_posix()]}
                            if eligibility_relative in immutable else {"exists": False, "sha256": None}),
                        "FORWARD_ELIGIBILITY_RECEIPT_INVALID")
                eligibility_path = _path(root, eligibility["path"])
                require(eligibility_path.is_file(), "FORWARD_ELIGIBILITY_RECEIPT_INVALID")
                if eligibility_relative not in immutable:
                    # Keep the newly published bytes protected through the
                    # outer committed receipt, like every pre-existing source.
                    pinned.append(stack.enter_context(closing(
                        p._PausedCancelPin(eligibility_path, capture=False))))
                require(p.file_hash(eligibility_path) == eligibility["sha256"],
                        "FORWARD_ELIGIBILITY_RECEIPT_INVALID")
                expected_operational.add(eligibility_relative)
                # ``current.json`` is an owned, forward-only view written by
                # the immediately preceding local-runtime migration.  The
                # migration outcome below binds every committed target by
                # path and hash; admit this *one* absent-before operational
                # path only when it is explicitly among those targets.  This
                # keeps a foreign operational addition fail-closed while
                # avoiding rejection of our own validated migration.
                current_goal = p.GOAL_TRAJECTORY_PATH
                current_goal_target = next(
                    (item for item in committed_targets
                     if item.get("path") == current_goal.as_posix()),
                    None,
                )
                if current_goal_target is not None:
                    require(current_goal_target.get("exists") is True,
                            "OWNED_GOAL_TRAJECTORY_INVALID")
                    expected_operational.add(current_goal)
                require(set(_operational_paths(root)) == expected_operational,
                        "OPERATIONAL_FILE_SET_CHANGED")
                database_origins = {(root / name).resolve() for name in database_files}
                for pin in pinned + proof["pins"]:
                    if pin.path.resolve() not in database_origins:
                        if pin.path.is_relative_to(root):
                            p._paused_cancel_safe_path(root, pin.path)
                        pin.revalidate()
                journal = forward_journal
                require(journal is not None, "FORWARD_JOURNAL_MISSING")
                replay = journal.get("committed_successor_observation") is not None
                if replay:
                    # No queue write occurred: retain every original handle and
                    # byte check, including empty WAL/SHM. A writable constructor
                    # here would initialize SQLite and remove those auxiliaries.
                    require(outcome.get("replayed_committed_edge") is True,
                            "FORWARD_QUEUE_REPLAY_REQUIRED")
                    capture.revalidate()
                else:
                    capture.revalidate_after_owned_queue_commit()
                # The four derived views are now an owned migration effect.
                # Reopen their exact committed target bytes rather than their
                # obsolete preimages; any unexpected replacement still fails
                # closed before the final receipt is written.
                for item in committed_targets:
                    target = _path(root, item["path"])
                    require((target.is_file() and p.file_hash(target) == item["content_hash"])
                            if item["exists"] else not target.exists(), "FINAL_TARGET_CHANGED")
                queue = (TransactionalQueue(root, path=capture.work_root / p.QUEUE_PATH,
                                            read_only=True, immutable=True)
                         if replay else TransactionalQueue(root))
                stored = queue.get_media_job_supersession(journal["predecessor_job_id"])
                require(stored is not None and stored.get("state") == "COMMITTED",
                        "FORWARD_QUEUE_COMMIT_UNVERIFIABLE")
                require(stored.get("receipt") == outcome.get("receipt")
                        and stored.get("receipt_sha256") == outcome.get("receipt_sha256"),
                        "FORWARD_QUEUE_COMMIT_DIVERGED")
                if replay:
                    capture.revalidate()

            def release_queue_write_protection():
                """Open one queue-only write boundary immediately before its commit."""
                capture.revalidate()
                queue_origins = {
                    (root / name).resolve() for name in database_files
                    if name == p.QUEUE_PATH or str(name).startswith(str(p.QUEUE_PATH) + "-")
                }
                if not queue_origins:
                    raise PermissionError("FORWARD_QUEUE_WRITE_BOUNDARY_MISSING")
                for pin in pinned:
                    if pin.path.resolve() in queue_origins:
                        pin.close()
                capture.release_queue_sources_for_owned_commit()

            recheck()
            # Preserve immutable source bytes and the logical/database snapshot;
            # migration itself archives every mutable view's exact preimage.
            for name in immutable:
                _publish(run / "protected-before" / name, (root / name).read_bytes())
            prepared = {"status": "PREPARED_WHILE_PAUSED", "binding": binding,
                        "host": host, "resources": preparation, "protected_hashes": immutable_hashes,
                        "boundary": boundary, "database_capture": capture.reference(),
                        "view_preimages": view_preimages,
                        "regression": proof["regression"], "restart_permitted": False}
            forward_journal = None
            if proof.get("proof_family") == "CURRENT_OPERATIONAL":
                forward_journal = prepare_forward_post_effect_journal(root, run)
                prepared["forward_post_effect_journal"] = {
                    "path": (run / "forward-post-effect-journal.json").relative_to(root).as_posix(),
                    "sha256": p.file_hash(run / "forward-post-effect-journal.json"),
                }
            # Snapshot publication is immutable.  Build the optional current
            # operational journal first, then publish the one canonical
            # prepared record which binds it; never rewrite prepared.json.
            _publish(run / "prepared.json", p._canonical_bytes(prepared))
            # Existing preview and transaction derive from the same held source
            # set. No preview request is persisted as an operational barrier.
            preview = p.preview_local_runtime_migration(root)
            _publish(run / "preview.json", p._canonical_bytes(preview))
            recheck()
            final = {}

            def finalize(migration):
                # Freeze committed views for receipt publication. Release these
                # handles BEFORE propagating an error to the existing rollback.
                with ExitStack() as committed_pins:
                    outcome = p._read(run / "local-runtime-migration-outcome.json")
                    for item in outcome["target_hashes"]:
                        target = _path(root, item["path"])
                        if item["exists"]:
                            committed_pins.enter_context(closing(p._PausedCancelPin(target, capture=False)))
                        require((target.is_file() and p.file_hash(target) == item["content_hash"])
                                if item["exists"] else not target.exists(), "FINAL_TARGET_CHANGED")
                    # The goal-trajectory successor can be absent in the
                    # preimage and become present only through this exact
                    # transaction.  Reopen its committed bytes from the
                    # migration outcome and pass that one reviewed addition
                    # to the boundary guard.  A naked recheck here would
                    # falsely classify the transaction's own forward target
                    # as a foreign operational file-set change.
                    # Outcome target hashes deliberately omit the preimage
                    # flag.  Use the journal, which is immutable and bound to
                    # this request, to identify only reviewed absent-before
                    # additions.
                    journal_targets = p._read(run / "local-runtime-migration-journal.json")["targets"]
                    owned_new_targets = tuple(
                        (item["path"], _path(root, item["path"]).read_bytes())
                        for item in journal_targets
                        if (not item["existed_before"] and item["desired_exists"])
                        and item["path"]
                        == "output/operations/phase6/goal-trajectory/current.json"
                    )
                    recheck_nonview_boundary(owned_new_targets)
                    verify_local_migration_evidence(root, request_id=application_id, migration=migration)
                    _publish(run / "migration.json", p._canonical_bytes(migration))
                    _publish(run / "after.json", p._canonical_bytes({"host": host, "boundary": boundary,
                             "protected_hashes": immutable_hashes, "candidate": proof["candidate"]["source_set_sha256"]}))
                    forward_commit = None
                    if forward_journal is not None:
                        # All source/capture/pin checks occur before this point.
                        # The forward commit intentionally changes its own queue
                        # and receipt preimages, so a later generic recheck would
                        # misclassify that owned effect as foreign drift.
                        if forward_journal.get("committed_successor_observation") is None:
                            release_queue_write_protection()
                        forward_commit = commit_prepared_forward_post_effect_journal(root, run)
                    evidence = {path.relative_to(root).as_posix(): p.file_hash(path)
                                for path in run.rglob("*") if path.is_file()}
                    final.update(schema_version="1.0.0", application_id=application_id,
                                 status="APPLIED_WHILE_PAUSED", binding=binding,
                                 regression=proof["regression"], migration=migration, evidence=evidence,
                                 operational_state="PAUSED", restart_permitted=False, D116="NOT_EXECUTED",
                                 technical_cost_brl=0, external_api_calls=0)
                    if forward_commit is not None:
                        final["forward_post_effect"] = forward_commit
                    if forward_commit is None:
                        # Keep the same exact journaled forward addition bound
                        # through the final generic recheck.  Calling the
                        # no-argument variant here would reject the migration's
                        # own absent-before goal successor after it had already
                        # been authenticated above.
                        recheck(owned_new_targets)
                    else:
                        recheck_after_owned_forward_commit(
                            forward_commit, outcome["target_hashes"]
                        )
                    _publish(run / "committed.json", p._canonical_bytes(final))

            p._migrate_local_runtime_views_transaction(root, request_id=application_id,
                destination=run, observed=datetime.now(timezone.utc), recheck=recheck_nonview_boundary,
                finalize=finalize, rollback_targets=rollback_owned, replace_target=replace_owned_goal)
            write_direct_paused_application_reference(root, run=run, binding=binding)
            return final
        except BaseException as exc:
            # Partial attempts are never auto-retried. All previous evidence
            # survives, including a committed migration followed by outer failure.
            if not (run / "committed.json").is_file():
                _publish(run / "failed.json", p._canonical_bytes({"status": "FAILED_WHILE_PAUSED",
                         "binding": binding, "failure_type": type(exc).__name__,
                         "failure_code": _failure_code(exc),
                         "restart_permitted": False, "D116": "NOT_EXECUTED"}))
            raise
