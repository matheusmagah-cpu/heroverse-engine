from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import yt_dlp

from .store import stable_id


PRIVATE_UNAVAILABLE = [
    "IMPRESSIONS", "CTR", "INTRO_RETENTION", "AVERAGE_VIEW_DURATION",
    "WATCH_HOURS", "SUBSCRIBERS_GAINED", "REVENUE", "RPM",
]


@dataclass(frozen=True)
class PublicChannel:
    channel_id: str
    handle: str
    source_uri: str
    role: str
    max_videos: int


def _collector() -> dict[str, str]:
    return {
        "name": "yt-dlp",
        "version": getattr(yt_dlp.version, "__version__", "unknown"),
        "mode": "PUBLIC_METADATA_NO_MEDIA",
    }


def _snapshot(
    operation_id: str,
    channel_id: str,
    entity_type: str,
    entity_id: str,
    captured_at: str,
    source_uri: str,
    status: str,
    payload: dict[str, Any] | None,
    error: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "snapshot_id": stable_id("snap", operation_id, channel_id, entity_type, entity_id, captured_at),
        "operation_id": operation_id,
        "channel_id": channel_id,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "collection_status": status,
        "captured_at": captured_at,
        "source_uri": source_uri,
        "collector": _collector(),
        "evidence_class": "OBSERVED",
        "payload": payload,
        "unavailable_metrics": list(PRIVATE_UNAVAILABLE),
        "error": error,
    }


def _clean_video(info: dict[str, Any], channel: PublicChannel, content_format: str) -> dict[str, Any]:
    video_id = str(info.get("id") or "")
    upload_date = info.get("upload_date")
    timestamp = info.get("timestamp") or info.get("release_timestamp")
    return {
        "video_id": video_id,
        "title": info.get("title"),
        "webpage_url": info.get("webpage_url") or f"https://www.youtube.com/watch?v={video_id}",
        "channel_id_public": info.get("channel_id"),
        "channel_handle_public": info.get("channel_url") or info.get("uploader_url"),
        "upload_date": upload_date,
        "timestamp": timestamp,
        "duration_seconds": info.get("duration"),
        "view_count": info.get("view_count"),
        "like_count": info.get("like_count"),
        "comment_count": info.get("comment_count"),
        "availability": info.get("availability"),
        "live_status": info.get("live_status"),
        "was_live": info.get("was_live"),
        "age_limit": info.get("age_limit"),
        "language": info.get("language"),
        "public_fields_only": True,
        "catalog_role": channel.role,
        "content_format": content_format,
    }


def collect_channel(operation_id: str, channel: PublicChannel, captured_at: str) -> list[dict[str, Any]]:
    options: dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "ignoreerrors": True,
        "playlistend": channel.max_videos,
        "socket_timeout": 20,
        "retries": 2,
        "fragment_retries": 0,
        "extract_flat": False,
        "noplaylist": False,
    }
    tab_results: list[dict[str, Any]] = []
    clean_by_id: dict[str, dict[str, Any]] = {}
    representative: dict[str, Any] | None = None
    for tab, content_format in (("videos", "LONG"), ("shorts", "SHORT")):
        url = channel.source_uri.rstrip("/") + f"/{tab}"
        try:
            with yt_dlp.YoutubeDL(options) as downloader:
                info = downloader.extract_info(url, download=False)
            if not info:
                raise RuntimeError("collector returned no tab payload")
            representative = representative or info
            raw_entries = [entry for entry in (info.get("entries") or []) if entry and entry.get("id")]
            for entry in raw_entries:
                item = _clean_video(entry, channel, content_format)
                clean_by_id.setdefault(item["video_id"], item)
            tab_results.append(
                {
                    "tab": tab,
                    "source_uri": url,
                    "status": "COMPLETE",
                    "returned_video_count": len(raw_entries),
                    "playlist_count_reported": info.get("playlist_count"),
                    "error": None,
                }
            )
        except Exception as exc:
            tab_results.append(
                {
                    "tab": tab,
                    "source_uri": url,
                    "status": "FAILED",
                    "returned_video_count": 0,
                    "playlist_count_reported": None,
                    "error": {"code": type(exc).__name__.upper(), "message": str(exc)[:1000], "retryable": True},
                }
            )
    clean_entries = list(clean_by_id.values())
    if representative is not None:
        info = representative
        channel_payload = {
            "handle_requested": channel.handle,
            "channel_id_public": info.get("channel_id") or info.get("id"),
            "channel_name_public": info.get("channel") or info.get("uploader") or info.get("title"),
            "channel_url_public": info.get("channel_url") or info.get("webpage_url") or channel.source_uri,
            "channel_follower_count_public": info.get("channel_follower_count"),
            "requested_video_limit_per_tab": channel.max_videos,
            "returned_video_count": len(clean_entries),
            "tabs": tab_results,
            "catalog_role": channel.role,
            "media_downloaded": False,
        }
        status = "COMPLETE" if all(item["status"] == "COMPLETE" for item in tab_results) else "PARTIAL"
        snapshots = [
            _snapshot(operation_id, channel.channel_id, "CHANNEL", channel.channel_id,
                      captured_at, channel.source_uri, status, channel_payload)
        ]
        for item in clean_entries:
            item_status = "COMPLETE" if item.get("view_count") is not None and (item.get("upload_date") or item.get("timestamp")) else "PARTIAL"
            snapshots.append(
                _snapshot(operation_id, channel.channel_id, "VIDEO", item["video_id"], captured_at,
                          item["webpage_url"], item_status, item)
            )
        return snapshots
    combined_message = "; ".join(
        f"{item['tab']}: {item['error']['message']}" for item in tab_results if item["error"]
    ) or "both public tabs returned no payload"
    return [
        _snapshot(
            operation_id, channel.channel_id, "CHANNEL", channel.channel_id, captured_at,
            channel.source_uri, "FAILED", None,
            {"code": "ALL_TABS_FAILED", "message": combined_message[:1000], "retryable": True},
        )
    ]
