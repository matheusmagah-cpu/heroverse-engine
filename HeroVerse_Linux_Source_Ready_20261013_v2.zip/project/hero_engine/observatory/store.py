from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing, contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from hero_engine.db import DEFAULT_DB, ROOT


MIGRATION = ROOT / "migrations" / "phase3" / "001_observatory_ssot.sql"
MIGRATION_VERSION = "phase3-001-observatory-ssot"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def stable_id(prefix: str, *parts: object) -> str:
    material = "\x1f".join(str(part) for part in parts).encode("utf-8")
    return f"{prefix}-{sha256_bytes(material)[:24]}"


@contextmanager
def sqlite_connection(path: Path = DEFAULT_DB) -> Iterator[sqlite3.Connection]:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def database_inventory(path: Path) -> dict[str, Any]:
    with sqlite_connection(path) as conn:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        tables = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
        ]
        counts = {table: conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] for table in tables}
    try:
        display_path = path.relative_to(ROOT).as_posix()
    except ValueError:
        display_path = str(path.resolve())
    return {
        "path": display_path,
        "exists": path.is_file(),
        "size_bytes": path.stat().st_size if path.is_file() else 0,
        "sha256": sha256_file(path) if path.is_file() else None,
        "integrity_check": integrity,
        "tables": counts,
    }


def create_verified_backup(path: Path, output_dir: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"database not found: {path}")
    output_dir.mkdir(parents=True, exist_ok=True)
    backup_path = output_dir / "hero_engine.pre_phase3.sqlite3"
    with closing(sqlite3.connect(path)) as source, closing(sqlite3.connect(backup_path)) as destination:
        source.backup(destination)
    original = database_inventory(path)
    backup = database_inventory(backup_path)
    logical_match = original["tables"] == backup["tables"] and backup["integrity_check"] == "ok"
    result = {
        "schema_version": "1.0.0",
        "created_at": utc_now(),
        "method": "sqlite_online_backup",
        "original": original,
        "backup": backup,
        "logical_counts_match": logical_match,
        "verified": logical_match,
    }
    manifest = output_dir / "database_backup_manifest.json"
    manifest.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if not logical_match:
        raise RuntimeError("pre-migration backup verification failed")
    return result


def apply_migration(path: Path = DEFAULT_DB, migration: Path = MIGRATION) -> dict[str, Any]:
    sql = migration.read_text(encoding="utf-8")
    digest = sha256_bytes(sql.encode("utf-8"))
    with closing(sqlite3.connect(path, timeout=30)) as conn:
        conn.row_factory = sqlite3.Row
        existing_table = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'"
        ).fetchone()
        if existing_table:
            row = conn.execute(
                "SELECT content_sha256, applied_at FROM schema_migrations WHERE version=?",
                (MIGRATION_VERSION,),
            ).fetchone()
            if row:
                if row["content_sha256"] != digest:
                    raise RuntimeError("applied migration content differs from repository migration")
                return {
                    "version": MIGRATION_VERSION,
                    "content_sha256": digest,
                    "applied_at": row["applied_at"],
                    "already_applied": True,
                }
        stamp = utc_now()
        quoted_version = MIGRATION_VERSION.replace("'", "''")
        quoted_digest = digest.replace("'", "''")
        quoted_stamp = stamp.replace("'", "''")
        script = (
            "BEGIN IMMEDIATE;\n"
            + sql
            + f"\nINSERT INTO schema_migrations(version, applied_at, content_sha256) "
              f"VALUES ('{quoted_version}', '{quoted_stamp}', '{quoted_digest}');\nCOMMIT;"
        )
        try:
            conn.executescript(script)
        except Exception:
            if conn.in_transaction:
                conn.rollback()
            raise
        conn.commit()
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"post-migration integrity_check failed: {integrity}")
    return {
        "version": MIGRATION_VERSION,
        "content_sha256": digest,
        "applied_at": stamp,
        "already_applied": False,
    }


@dataclass(frozen=True)
class ChannelRegistration:
    channel_id: str
    handle: str
    role: str
    source_uri: str
    identity_version: str = "seed-2026-09-02"


class ObservatoryStore:
    def __init__(self, path: Path = DEFAULT_DB):
        self.path = path

    def create_operation(self, operation_id: str, owner_id: str, objective: str, scope: dict[str, Any], started_at: str) -> None:
        scope_hash = sha256_bytes(canonical_json(scope).encode("utf-8"))
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_operations
                (operation_id, owner_id, objective, authorized_phase, status, scope_sha256,
                 external_api_cost_usd, started_at)
                VALUES (?, ?, ?, 3, 'RUNNING', ?, 0, ?)
                ON CONFLICT(operation_id) DO NOTHING
                """,
                (operation_id, owner_id, objective, scope_hash, started_at),
            )
            row = conn.execute(
                "SELECT owner_id, objective, scope_sha256 FROM observatory_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if not row or dict(row) != {"owner_id": owner_id, "objective": objective, "scope_sha256": scope_hash}:
                raise RuntimeError("operation id already exists with a different immutable scope")

    def register_channel(self, operation_id: str, item: ChannelRegistration, created_at: str) -> None:
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_channels
                (operation_id, channel_id, handle, role, identity_version, status, source_uri, created_at)
                VALUES (?, ?, ?, ?, ?, 'READY', ?, ?)
                ON CONFLICT(operation_id, channel_id) DO NOTHING
                """,
                (operation_id, item.channel_id, item.handle, item.role, item.identity_version, item.source_uri, created_at),
            )
            row = conn.execute(
                "SELECT handle, role, source_uri FROM observatory_channels WHERE operation_id=? AND channel_id=?",
                (operation_id, item.channel_id),
            ).fetchone()
            if not row or dict(row) != {"handle": item.handle, "role": item.role, "source_uri": item.source_uri}:
                raise RuntimeError(f"channel isolation conflict: {item.channel_id}")

    def append_event(
        self,
        operation_id: str,
        event_type: str,
        evidence_class: str,
        trace_id: str,
        payload: dict[str, Any],
        occurred_at: str,
        channel_id: str | None = None,
        source_uri: str | None = None,
    ) -> dict[str, Any]:
        payload_json = canonical_json(payload)
        payload_hash = sha256_bytes(payload_json.encode("utf-8"))
        event_id = stable_id("evt", operation_id, channel_id, event_type, trace_id, payload_hash)
        recorded_at = utc_now()
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_ledger_events
                (event_id, operation_id, channel_id, event_type, evidence_class, trace_id,
                 source_uri, occurred_at, recorded_at, payload_json, payload_sha256)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(event_id) DO NOTHING
                """,
                (event_id, operation_id, channel_id, event_type, evidence_class, trace_id,
                 source_uri, occurred_at, recorded_at, payload_json, payload_hash),
            )
        return {
            "event_id": event_id,
            "operation_id": operation_id,
            "channel_id": channel_id,
            "event_type": event_type,
            "evidence_class": evidence_class,
            "trace_id": trace_id,
            "source_uri": source_uri,
            "occurred_at": occurred_at,
            "recorded_at": recorded_at,
            "payload": payload,
            "payload_sha256": payload_hash,
        }

    def add_snapshot(self, snapshot: dict[str, Any]) -> None:
        payload = snapshot["payload"]
        payload_json = canonical_json(payload) if payload is not None else None
        payload_hash = sha256_bytes(payload_json.encode("utf-8")) if payload_json is not None else None
        error = snapshot["error"] or {}
        collector = canonical_json(snapshot["collector"])
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_public_snapshots
                (snapshot_id, operation_id, channel_id, entity_type, entity_id,
                 collection_status, captured_at, source_uri, collector, payload_json,
                 payload_sha256, error_code, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(snapshot_id) DO NOTHING
                """,
                (
                    snapshot["snapshot_id"], snapshot["operation_id"], snapshot["channel_id"],
                    snapshot["entity_type"], snapshot["entity_id"], snapshot["collection_status"],
                    snapshot["captured_at"], snapshot["source_uri"], collector, payload_json,
                    payload_hash, error.get("code"), error.get("message"),
                ),
            )

    def add_coverage(self, operation_id: str, record: dict[str, Any], recorded_at: str) -> None:
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_coverage
                (operation_id, video_id, channel_id, coverage_level, fields_json, artifact_uri,
                 artifact_sha256, rights_status, holdout_from_phase2, limitations_json, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(operation_id, video_id, coverage_level) DO NOTHING
                """,
                (
                    operation_id, record["video_id"], record["channel_id"], record["coverage_level"],
                    canonical_json(record["fields"]), record["artifact_uri"], record["artifact_sha256"],
                    record["rights_status"], int(record["holdout_from_phase2"]),
                    canonical_json(record["limitations"]), recorded_at,
                ),
            )

    def add_cohort(self, operation_id: str, cohort: dict[str, Any], cutoff_at: str, ranking_metric: str) -> None:
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_cohorts
                (operation_id, cohort_id, channel_id, kind, selection_rule, cutoff_at,
                 ranking_metric, limitations_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(operation_id, cohort_id) DO NOTHING
                """,
                (operation_id, cohort["cohort_id"], cohort["channel_id"], cohort["kind"],
                 cohort["selection_rule"], cutoff_at, ranking_metric, canonical_json(cohort["limitations"])),
            )
            for member in cohort["members"]:
                conn.execute(
                    """
                    INSERT INTO observatory_cohort_members
                    (operation_id, cohort_id, video_id, rank_value, rank_position, evidence_snapshot_id)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(operation_id, cohort_id, video_id) DO NOTHING
                    """,
                    (operation_id, cohort["cohort_id"], member["video_id"], member["rank_value"],
                     member["rank_position"], member["evidence_snapshot_id"]),
                )

    def add_memory(
        self,
        operation_id: str,
        memory_type: str,
        knowledge_status: str,
        payload: dict[str, Any],
        evidence_ids: list[str],
        valid_from: str,
        channel_id: str | None = None,
    ) -> str:
        payload_hash = sha256_bytes(canonical_json(payload).encode("utf-8"))
        memory_id = stable_id("mem", operation_id, channel_id, memory_type, knowledge_status, payload_hash)
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_typed_memory
                (memory_id, operation_id, channel_id, memory_type, knowledge_status, version,
                 payload_json, evidence_ids_json, valid_from)
                VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)
                ON CONFLICT(memory_id) DO NOTHING
                """,
                (memory_id, operation_id, channel_id, memory_type, knowledge_status,
                 canonical_json(payload), canonical_json(evidence_ids), valid_from),
            )
        return memory_id

    def add_error(
        self,
        operation_id: str,
        stage: str,
        error_type: str,
        message: str,
        occurred_at: str,
        channel_id: str | None = None,
        retryable: bool = True,
        attempt: int = 1,
    ) -> str:
        error_id = stable_id("err", operation_id, channel_id, stage, error_type, message, attempt)
        with sqlite_connection(self.path) as conn:
            conn.execute(
                """
                INSERT INTO observatory_errors
                (error_id, operation_id, channel_id, stage, retryable, attempt,
                 error_type, message, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(error_id) DO NOTHING
                """,
                (error_id, operation_id, channel_id, stage, int(retryable), attempt,
                 error_type, message[:2000], occurred_at),
            )
        return error_id

    def set_status(self, operation_id: str, status: str, completed_at: str | None = None) -> None:
        with sqlite_connection(self.path) as conn:
            conn.execute(
                "UPDATE observatory_operations SET status=?, completed_at=? WHERE operation_id=?",
                (status, completed_at, operation_id),
            )

    def counts(self, operation_id: str) -> dict[str, int]:
        tables = [
            "observatory_channels", "observatory_ledger_events", "observatory_public_snapshots",
            "observatory_coverage", "observatory_cohorts", "observatory_cohort_members",
            "observatory_typed_memory", "observatory_errors",
        ]
        with sqlite_connection(self.path) as conn:
            return {
                table: conn.execute(f"SELECT COUNT(*) FROM {table} WHERE operation_id=?", (operation_id,)).fetchone()[0]
                for table in tables
            }
