from __future__ import annotations

import json
import re
import shutil
import statistics
import subprocess
from pathlib import Path
from typing import Any

from hero_engine.db import ROOT
from hero_engine.mining.pipeline import FIXTURE_IDS

from .store import canonical_json, sha256_bytes, sha256_file


MODEL_ROOT = ROOT / "data" / "modeling" / "grace-grit-love"
WINDOWS = (("0_1S", 0.0, 1.0), ("1_3S", 1.0, 3.0), ("3_8S", 3.0, 8.0), ("8_30S", 8.0, 30.0))


def _words(record: dict[str, Any]) -> list[dict[str, Any]]:
    return [word for segment in record.get("segments", []) for word in segment.get("words", [])]


def _scene_cuts(path: Path, threshold: float = 0.25) -> tuple[list[float], str]:
    executable = shutil.which("ffmpeg")
    if not executable:
        return [], "UNAVAILABLE_FFMPEG"
    command = [
        executable, "-hide_banner", "-loglevel", "info", "-i", str(path),
        "-vf", f"select='gt(scene,{threshold})',showinfo", "-an", "-f", "null", "-",
    ]
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=120, check=False,
    )
    if result.returncode != 0:
        return [], f"FAILED_EXIT_{result.returncode}"
    cuts = sorted({round(float(value), 3) for value in re.findall(r"pts_time:([0-9.]+)", result.stderr or "")})
    return cuts, "COMPLETE"


def analyze_openings() -> dict[str, Any]:
    transcript_path = MODEL_ROOT / "intro-transcripts.json"
    records = json.loads(transcript_path.read_text(encoding="utf-8"))
    output: list[dict[str, Any]] = []
    for record in sorted(records, key=lambda item: item["video_id"]):
        video_id = record["video_id"]
        video_path = MODEL_ROOT / "intros" / f"{video_id}.mp4"
        if not video_path.is_file():
            raise FileNotFoundError(f"opening media missing: {video_path}")
        words = _words(record)
        cut_times, cut_status = _scene_cuts(video_path)
        windows = []
        for label, start, end in WINDOWS:
            selected = [word for word in words if float(word["start"]) < end and float(word["end"]) > start]
            probabilities = [float(word.get("probability", 0)) for word in selected]
            windows.append(
                {
                    "window": label,
                    "start_ms": round(start * 1000),
                    "end_ms": round(end * 1000),
                    "spoken_word_count": len(selected),
                    "transcript_text": " ".join(str(word.get("word", "")).strip() for word in selected).strip(),
                    "median_word_probability": round(statistics.median(probabilities), 4) if probabilities else None,
                    "scene_cut_count": sum(start <= item < end for item in cut_times),
                }
            )
        first_speech = min((float(word["start"]) for word in words), default=None)
        record_hash = sha256_bytes(canonical_json(record).encode("utf-8"))
        output.append(
            {
                "video_id": video_id,
                "coverage_level": "OPENING_ONLY",
                "holdout_from_phase2": video_id not in FIXTURE_IDS,
                "first_speech_seconds": first_speech,
                "scene_detection": {"status": cut_status, "threshold": 0.25, "cut_times_seconds": cut_times},
                "windows": windows,
                "evidence": {
                    "video_artifact": video_path.relative_to(ROOT).as_posix(),
                    "video_sha256": sha256_file(video_path),
                    "transcript_artifact": transcript_path.relative_to(ROOT).as_posix(),
                    "transcript_record_sha256": record_hash,
                    "evidence_class": "OBSERVED_AND_CALCULATED",
                },
                "limitations": [
                    "Only the first 40 seconds are available; no complete-narrative conclusion is permitted.",
                    "ASR is machine-generated and has not been promoted to a verbatim human-reviewed transcript.",
                ],
            }
        )
    holdout_count = sum(item["holdout_from_phase2"] for item in output)
    return {
        "schema_version": "1.0.0",
        "window_contract": [
            {"window": label, "start_ms": round(start * 1000), "end_ms": round(end * 1000)}
            for label, start, end in WINDOWS
        ],
        "records": output,
        "counts": {
            "opening_records": len(output),
            "phase2_intersection": len(output) - holdout_count,
            "holdout_from_phase2": holdout_count,
        },
        "generalization_claim": "NOT_PERMITTED",
    }
