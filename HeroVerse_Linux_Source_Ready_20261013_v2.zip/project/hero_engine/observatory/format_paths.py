"""Evidence-bound format research; no production, network or scheduling effects.

This is a consumer of exact-format cohorts, not another strategy owner. The
Central Manager can consume an inspection only after independently validating
it. The active experiment and its production/publication authority are untouched.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import statistics
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.atomic_io import atomic_write_utf8
from .format_cohorts import compile_format_cohorts, validate_format_cohorts
from .format_path_provenance import validate_market_source

VERSION = "market-format-inspector-v1"
FORMATS = ("LONG", "SHORT")
# Typed compatibility adapter for the *exact* legacy recipe already validated.
# Merely relabelling a copy of a LONG pack/pipeline cannot create SHORT support.
# A future recipe needs its own verified adapter, sample and scope contract.
LEGACY_FORMAT_BINDINGS = {
    ("db162df446ebb04cc7fa040c067da812fdc90975a14ab9761553d8155ef35d9f",
     "0e79c13825b81cea4a91bb1baedb5d900d87bd276a002b26f67114d31545b24b"): {"LONG"},
}
DEPENDENCIES = (
    "hero_engine/observatory/format_paths.py",
    "hero_engine/observatory/format_cohorts.py",
    "hero_engine/observatory/format_path_provenance.py",
    "hero_engine/atomic_io.py",
    "schemas/market_format_policy.schema.json",
    "schemas/format_path_decision.schema.json",
    "schemas/observatory_format_cohorts.schema.json",
    "schemas/observatory_snapshot.schema.json",
    "schemas/format_pack.schema.json",
    "schemas/macro_pipeline.schema.json",
)


def _bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _json(data: bytes) -> Any:
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(f"non-finite JSON: {value}")
    def finite_float(value):
        number = float(value)
        if not math.isfinite(number):
            invalid(value)
        return number
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique, parse_constant=invalid, parse_float=finite_float)


def _time(value: str) -> datetime:
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("timezone required")
    return result.astimezone(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat()


def _confined(root: Path, name: str) -> Path:
    if Path(name).is_absolute() or ".." in Path(name).parts:
        raise ValueError("binding must be a confined relative path")
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("binding escapes project")
    return path


def _bound(root: Path, binding: dict) -> tuple[Path, Any]:
    path = _confined(root, binding["path"])
    data = path.read_bytes()
    if _sha(data) != binding["sha256"]:
        raise ValueError(f"binding changed: {binding['path']}")
    return path, _json(data)


def _validate(root: Path, name: str, value: Any) -> None:
    schema = _json((root / "schemas" / name).read_bytes())
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _capabilities(root: Path, policy: dict) -> dict:
    result = {fmt: {"state": "UNAVAILABLE", "research_eligible": False,
                    "pack_id": None, "pack_version": None, "pipeline_id": None,
                    "pipeline_version": None, "requires_release_scope": True,
                    "reasons": ["NO_PINNED_CAPABILITY"]} for fmt in FORMATS}
    seen = set()
    for route in policy["capability_candidates"]:
        fmt = route["content_format"]
        if fmt in seen:
            raise ValueError("duplicate format capability")
        seen.add(fmt)
        _, pack = _bound(root, route["pack"])
        _, pipeline = _bound(root, route["pipeline"])
        _validate(root, "format_pack.schema.json", pack)
        _validate(root, "macro_pipeline.schema.json", pipeline)
        reasons = []
        compatible = LEGACY_FORMAT_BINDINGS.get((route["pack"]["sha256"], route["pipeline"]["sha256"]), set())
        if fmt not in compatible:
            reasons.append("NO_VERIFIED_FORMAT_RECIPE_ADAPTER")
        expected_clause = "English Christian-motivation " + ("long-form" if fmt == "LONG" else "Shorts") + " only"
        if route["format_scope_clause"] != expected_clause:
            raise ValueError("format mapping contradicts scope clause")
        allowed = (pack.get("limitation_contract") or {}).get("allowed_scope", [])
        if route["channel_scope_clause"] not in allowed or expected_clause not in allowed:
            reasons.append("CHANNEL_OR_FORMAT_SCOPE_NOT_PROVEN")
        forbidden = " ".join((pack.get("limitation_contract") or {}).get("forbidden_scope", []))
        format_word = r"\bShorts\b" if fmt == "SHORT" else r"\blong-form\b"
        if re.search(format_word, forbidden, flags=re.IGNORECASE):
            reasons.append("FORMAT_APPEARS_IN_FORBIDDEN_SCOPE")
        if pack["capability_status"] not in {"LIMITED", "PRODUCTION_READY"} or not pack["production_allowed"]:
            reasons.append("PACK_NOT_PRODUCTION_CLASS")
        if pipeline["status"] not in {"LIMITED", "PRODUCTION_READY"}:
            reasons.append("PIPELINE_NOT_PRODUCTION_CLASS")
        spec = pack.get("specification") or {}
        if spec.get("primary_pipeline_id") != pipeline["pipeline_id"] or pack["format_pack_id"] not in pipeline["supported_format_pack_ids"]:
            reasons.append("PACK_PIPELINE_MISMATCH")
        cost = spec.get("estimated_cost") or {}
        if cost.get("external_max") != 0 or pipeline["cost_model"].get("external_cost_usd") != 0:
            reasons.append("ZERO_COST_NOT_PROVEN")
        result[fmt] = {
            "state": pack["capability_status"], "research_eligible": not reasons,
            "pack_id": pack["format_pack_id"], "pack_version": pack["version"],
            "pipeline_id": pipeline["pipeline_id"], "pipeline_version": pipeline["version"],
            "requires_release_scope": True,
            "reasons": reasons or ["RESEARCH_ONLY_RELEASE_SCOPE_AND_ALL_GATES_STILL_REQUIRED"],
        }
    return result


def _comparison(cohorts: dict, policy: dict) -> dict:
    cells: dict[tuple, dict] = {}
    counts = {fmt: {"all_videos": 0, "rankable_videos": 0, "excluded_videos": 0,
                    "market_videos": 0, "sufficient_market_groups": 0} for fmt in FORMATS}
    for exclusion in cohorts["exclusions"]:
        fmt = exclusion["observed_content_format"]
        if fmt in counts:
            counts[fmt]["all_videos"] += 1
            counts[fmt]["excluded_videos"] += 1
    for group in cohorts["groups"]:
        fmt = group["content_format"]
        counts[fmt]["all_videos"] += len(group["members"])
        counts[fmt]["rankable_videos"] += len(group["members"])
        if group["catalog_role"] not in policy["market_roles"]:
            continue
        counts[fmt]["market_videos"] += len(group["members"])
        if group["status"] != "SUFFICIENT":
            continue
        counts[fmt]["sufficient_market_groups"] += 1
        winners = [m["relative_velocity"] for m in group["members"] if m["kind"] == "WINNER"]
        if not winners or any(v is None or not math.isfinite(v) or v <= 0 for v in winners):
            continue
        key = (group["channel_id"], group["catalog_role"], group["age_band"])
        if fmt in cells.setdefault(key, {}):
            raise ValueError("duplicate exact comparison cell")
        cells[key][fmt] = {"group_id": group["group_id"], "winner_lift": statistics.median(winners)}
    matched = [{"channel_id": key[0], "catalog_role": key[1], "age_band": key[2], **cell}
               for key, cell in sorted(cells.items()) if set(cell) == set(FORMATS)]
    channels = sorted({c["channel_id"] for c in matched})
    # First give each age cell equal weight within its channel, then each channel
    # equal weight. A large channel/catalog cannot dominate by duplicate entries.
    scores = {fmt: (statistics.median([
        statistics.median([c[fmt]["winner_lift"] for c in matched if c["channel_id"] == channel])
        for channel in channels]) if channels else None) for fmt in FORMATS}
    enough = len(channels) >= policy["min_matched_market_channels"]
    return {"metric": "CHANNEL_BALANCED_MATCHED_UPPER_QUARTILE_LIFT",
            "counts": counts, "matched_cells": matched, "matched_channel_count": len(channels),
            "minimum_matched_channels": policy["min_matched_market_channels"],
            "status": "SUFFICIENT_FOR_RESEARCH" if enough else "INSUFFICIENT_MATCHED_SAMPLE",
            "scores": scores, "causal_claims_permitted": False,
            "predictive_calibration_status": "UNAVAILABLE"}


def _recommend(comparison: dict, capabilities: dict, config: dict, freshness: dict) -> tuple[str, list[str]]:
    """Pure research rule; its caller must independently prove all its inputs."""
    reasons = []
    recommendation = "UNDETERMINED"
    if freshness["status"] != "CURRENT":
        reasons.append("MARKET_SOURCE_EXPIRED")
    if comparison["status"] != "SUFFICIENT_FOR_RESEARCH":
        reasons.append("INSUFFICIENT_MATCHED_SAMPLE")
    if not reasons:
        scores = comparison["scores"]
        winner = max(FORMATS, key=lambda f: scores[f])
        loser = next(f for f in FORMATS if f != winner)
        ratio = scores[winner] / scores[loser]
        if ratio >= config["minimum_lift_ratio"]:
            if capabilities[winner]["research_eligible"]:
                recommendation = winner
            else:
                reasons.append("SIGNAL_WINNER_CAPABILITY_UNAVAILABLE")
        elif config["allow_hybrid_research"] and all(c["research_eligible"] for c in capabilities.values()):
            recommendation = "HYBRID"
        else:
            reasons.append("NO_SUPPORTED_SEPARATION_OR_HYBRID_CAPABILITY")
    return recommendation, reasons


def compile_format_path_decision(root: Path, *, source: dict, policy: dict, evaluated_at: str) -> dict:
    root = root.resolve()
    dependencies = [{"path": p, "sha256": _sha((root / p).read_bytes())} for p in DEPENDENCIES]
    source_path, snapshots = _bound(root, source)
    _, config = _bound(root, policy)
    _validate(root, "market_format_policy.schema.json", config)
    provenance = validate_market_source(root, source, snapshots, config["source_contract"])
    if config["refresh_interval_seconds"] > config["max_age_seconds"]:
        raise ValueError("refresh cadence exceeds validity window")
    now = _time(evaluated_at)
    cutoff = _time(snapshots["captured_at"])
    times = [_time(item["captured_at"]) for item in snapshots["snapshots"]]
    if not times or now < cutoff or any(t > cutoff for t in times):
        raise ValueError("missing or future source timestamp")
    oldest = min(times)
    expires = oldest + timedelta(seconds=config["max_age_seconds"])
    refresh = oldest + timedelta(seconds=config["refresh_interval_seconds"])
    freshness = {"status": "CURRENT" if now < expires else "STALE",
                 "oldest_observation_at": _iso(oldest), "cutoff_at": _iso(cutoff),
                 "age_seconds": (now - oldest).total_seconds(),
                 "max_age_seconds": config["max_age_seconds"], "expires_at": _iso(expires),
                 "refresh_due_at": _iso(refresh), "refresh_due": now >= refresh,
                 "collection_executed": False, "scheduler_integrated": False}
    cohorts = compile_format_cohorts(source_path, min_group_size=config["min_group_size"])
    validate_format_cohorts(cohorts)
    if _sha(source_path.read_bytes()) != source["sha256"]:
        raise ValueError("source changed during compilation")
    comparison = _comparison(cohorts, config)
    capabilities = _capabilities(root, config)
    recommendation, reasons = _recommend(comparison, capabilities, config, freshness)
    for dependency in dependencies:
        if _sha((root / dependency["path"]).read_bytes()) != dependency["sha256"]:
            raise ValueError("dependency changed during compilation")
    # A file modified between validation and the end of the operation must not
    # create a mixed-version receipt, even when it was valid at the first read.
    for binding in (source, policy, *(b for route in config["capability_candidates"] for b in (route["pack"], route["pipeline"]))):
        _bound(root, binding)
    if validate_market_source(root, source, snapshots, config["source_contract"]) != provenance:
        raise ValueError("provenance changed during compilation")
    document = {
        "schema_version": "1.0.0", "version": VERSION,
        "channel_id": config["channel_id"], "evaluated_at": _iso(now),
        "mode": config["mode"], "source": source, "policy": policy,
        "evidence_mode": config["source_contract"]["evidence_mode"], "source_provenance": provenance,
        "dependencies": dependencies, "cohorts": cohorts,
        "freshness": freshness, "comparison": comparison, "capabilities": capabilities,
        "recommended_research_format": recommendation, "reasons": reasons,
        "financial_comparison": {"status": "UNAVAILABLE", "more_profitable_format": None,
                                 "rpm_long": None, "rpm_short": None, "ypp_qualified_hours": None,
                                 "ypp_qualified_shorts_views": None, "monetization_probability_d30": None},
        "technical_cost_brl": 0, "production_authorized": False, "publication_authorized": False,
        "active_experiment_modified": False,
        "limitations": [
            "Upper-quartile lift is a public-metadata research proxy, not profit or causal performance.",
            "No renewal is performed by this inspector; due dates do not prove a running collector.",
            "A LIMITED pack still needs its exact release scope receipt and all downstream gates.",
            "Research recommendations do not change the active experiment or authorize media or publication.",
            "Policy screening floors are not calibrated success probabilities.",
        ],
    }
    document["decision_id"] = "format-path-" + _sha(_bytes(document))[:24]
    _validate(root, "format_path_decision.schema.json", document)
    return document


def replay_format_path_decision(root: Path, document: dict) -> None:
    """Historical arithmetic/integrity replay only; never authorizes present use."""
    _validate(root, "format_path_decision.schema.json", document)
    expected = compile_format_path_decision(root, source=document["source"], policy=document["policy"], evaluated_at=document["evaluated_at"])
    if _bytes(expected) != _bytes(document):
        raise ValueError("decision does not reproduce from its bound sources")


def validate_format_path_decision(root: Path, document: dict, *, now: str) -> None:
    """Live consumer admission: explicit current clock, proven source and TTL."""
    replay_format_path_decision(root, document)
    moment = _time(now)
    if moment < _time(document["evaluated_at"]) or moment >= _time(document["freshness"]["expires_at"]):
        raise ValueError("decision is not valid at use time")
    if document["evidence_mode"] != "LIVE":
        raise ValueError("fixture evidence cannot be admitted for live use")


def materialize(root: Path, document: dict) -> Path:
    """Archive an inspection (including STALE), not an admission for live use."""
    replay_format_path_decision(root, document)
    payload = json.dumps(document, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    folder = _confined(root, "output/observatory/format-paths/" + document["decision_id"])
    path = folder / "decision.json"
    if folder.exists():
        if not path.is_file() or path.read_bytes() != payload.encode("utf-8"):
            raise ValueError("incomplete or conflicting immutable decision directory")
        return path
    folder.mkdir(parents=True, exist_ok=False)
    try:
        atomic_write_utf8(path, payload)
    except BaseException:
        # Remove only our newly-created EMPTY directory. Never erase evidence,
        # receipts, another writer's temporary file, or an existing run.
        try:
            folder.rmdir()
        except OSError:
            pass
        raise
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--source", required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--policy", default="config/market-format-policy-v1.json")
    parser.add_argument("--policy-sha256", required=True)
    parser.add_argument("--at", default=None)
    parser.add_argument("--write", action="store_true", help="Archive inspection only; no active state or network effects")
    args = parser.parse_args()
    result = compile_format_path_decision(args.root, source={"path": args.source, "sha256": args.source_sha256},
                                         policy={"path": args.policy, "sha256": args.policy_sha256},
                                         evaluated_at=args.at or _iso(datetime.now(timezone.utc)))
    if args.write:
        path = materialize(args.root, result)
        print(json.dumps({"path": str(path), "sha256": _sha(path.read_bytes()), "decision_id": result["decision_id"],
                          "freshness": result["freshness"], "recommendation": result["recommended_research_format"],
                          "reasons": result["reasons"]}, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
