"""Fail-closed provenance guard for market-format source bundles.

The guard proves where a local observation bundle came from.  It does not
rank formats, collect data, or grant production/publication authority.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit


_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_COLLECTOR_KEYS = {"name", "version", "mode"}
_CONTRACT_KEYS = {"evidence_mode", "operation_id", "collector", "integrity_manifest"}
_BINDING_KEYS = {"path", "sha256"}


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _strict_json(data: bytes, label: str) -> Any:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"{label} has duplicate JSON key: {key}")
            result[key] = value
        return result

    def finite(value: str) -> Any:
        raise ValueError(f"{label} has non-finite JSON number: {value}")

    try:
        return json.loads(
            data.decode("utf-8-sig"),
            object_pairs_hook=unique,
            parse_constant=finite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} is not strict UTF-8 JSON") from exc


def _confined(root: Path, relative: str, label: str) -> Path:
    if not isinstance(relative, str) or not relative:
        raise ValueError(f"{label}.path must be a non-empty relative path")
    raw = Path(relative)
    if raw.is_absolute() or ".." in raw.parts:
        raise ValueError(f"{label}.path must be confined")
    path = (root / raw).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError(f"{label}.path is missing or escapes root")
    return path


def _binding(root: Path, value: Any, label: str) -> tuple[Path, bytes, dict[str, str]]:
    if not isinstance(value, dict) or set(value) != _BINDING_KEYS:
        raise ValueError(f"{label} must contain exactly path and sha256")
    digest = value.get("sha256")
    if not isinstance(digest, str) or _SHA256.fullmatch(digest) is None:
        raise ValueError(f"{label}.sha256 must be lowercase SHA-256")
    path = _confined(root, value.get("path"), label)
    data = path.read_bytes()
    if _sha256(data) != digest:
        raise ValueError(f"{label} binding changed")
    normalized = {"path": path.relative_to(root).as_posix(), "sha256": digest}
    return path, data, normalized


def _instant(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be an offset-aware timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{label} is not a timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{label} needs an explicit UTC offset")
    return parsed.astimezone(timezone.utc)


def _collector(value: Any) -> dict[str, str]:
    if not isinstance(value, dict) or set(value) != _COLLECTOR_KEYS:
        raise ValueError("collector contract must have exactly name, version and mode")
    if any(not isinstance(value[key], str) or not value[key] for key in _COLLECTOR_KEYS):
        raise ValueError("collector contract fields must be non-empty strings")
    if value["mode"] != "PUBLIC_METADATA_NO_MEDIA":
        raise ValueError("collector mode is not public-metadata/no-media")
    return {key: value[key] for key in ("name", "version", "mode")}


def _watch_id(uri: Any, label: str) -> str:
    if not isinstance(uri, str):
        raise ValueError(f"{label} must be a YouTube watch URI")
    parsed = urlsplit(uri)
    if parsed.scheme != "https" or (parsed.hostname or "").lower() not in {"youtube.com", "www.youtube.com"}:
        raise ValueError(f"{label} must use the HTTPS YouTube host")
    if parsed.path.rstrip("/") != "/watch":
        raise ValueError(f"{label} must be a /watch URI")
    values = parse_qs(parsed.query, keep_blank_values=True).get("v", [])
    if len(values) != 1 or not values[0]:
        raise ValueError(f"{label} must contain one video id")
    return values[0]


def _manifest_entries(root: Path, manifest: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(manifest, dict):
        raise ValueError("integrity manifest must be an object")
    if manifest.get("schema_version") != "1.0.0" or manifest.get("algorithm") != "SHA-256":
        raise ValueError("unsupported integrity manifest contract")
    entries = manifest.get("entries")
    if not isinstance(entries, list) or type(manifest.get("item_count")) is not int:
        raise ValueError("integrity manifest entries/count are invalid")
    if manifest["item_count"] != len(entries):
        raise ValueError("integrity manifest item_count does not reconcile")
    indexed: dict[str, dict[str, Any]] = {}
    resolved: set[Path] = set()
    total = 0
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict) or set(entry) != {"artifact", "size_bytes", "sha256"}:
            raise ValueError(f"manifest entry {index} has an invalid shape")
        size = entry["size_bytes"]
        digest = entry["sha256"]
        if type(size) is not int or size < 0 or not isinstance(digest, str) or _SHA256.fullmatch(digest) is None:
            raise ValueError(f"manifest entry {index} has invalid size/hash")
        path = _confined(root, entry["artifact"], f"manifest entry {index}")
        relative = path.relative_to(root).as_posix()
        if relative in indexed or path in resolved:
            raise ValueError("integrity manifest has duplicate artifact identity")
        normalized = {"artifact": relative, "size_bytes": size, "sha256": digest}
        indexed[relative] = normalized
        resolved.add(path)
        total += size
    if type(manifest.get("total_size_bytes")) is not int or manifest["total_size_bytes"] != total:
        raise ValueError("integrity manifest total_size_bytes does not reconcile")
    return indexed


def _entry_for(path: Path, root: Path, entries: dict[str, dict[str, Any]], label: str) -> dict[str, Any]:
    relative = path.relative_to(root).as_posix()
    entry = entries.get(relative)
    if entry is None:
        raise ValueError(f"integrity manifest has no unique {label} entry")
    data = path.read_bytes()
    if entry["size_bytes"] != len(data) or entry["sha256"] != _sha256(data):
        raise ValueError(f"integrity manifest {label} entry does not match resident bytes")
    return entry


def _check_bundle(
    bundle: dict[str, Any], operation_id: str, expected_collector: dict[str, str]
) -> tuple[int, int, dict[str, dict[str, Any]]]:
    if bundle.get("operation_id") != operation_id:
        raise ValueError("source operation_id diverges from provenance contract")
    cutoff = _instant(bundle.get("captured_at"), "source.captured_at")
    records = bundle.get("snapshots")
    if not isinstance(records, list):
        raise ValueError("source.snapshots must be an array")
    channels: dict[str, dict[str, Any]] = {}
    video_count = 0
    for index, item in enumerate(records):
        if not isinstance(item, dict):
            raise ValueError(f"snapshot {index} is not an object")
        if item.get("operation_id") != operation_id:
            raise ValueError(f"snapshot {index} operation_id diverges")
        if _instant(item.get("captured_at"), f"snapshot {index}.captured_at") != cutoff:
            raise ValueError(f"snapshot {index} cutoff diverges")
        entity_type = item.get("entity_type")
        if entity_type not in {"CHANNEL", "VIDEO", "POLICY"}:
            raise ValueError(f"snapshot {index} entity type is unsupported")
        if entity_type not in {"CHANNEL", "VIDEO"}:
            continue
        if item.get("collector") != expected_collector:
            raise ValueError(f"snapshot {index} collector diverges")
        if item.get("evidence_class") != "OBSERVED":
            raise ValueError(f"snapshot {index} is not observed evidence")
        if entity_type == "CHANNEL":
            internal = item.get("channel_id")
            if not isinstance(internal, str) or not internal or item.get("entity_id") != internal:
                raise ValueError(f"snapshot {index} internal channel identity diverges")
            if internal in channels:
                raise ValueError(f"duplicate CHANNEL snapshot: {internal}")
            channels[internal] = item
        else:
            video_count += 1
            video_id = item.get("entity_id")
            if not isinstance(video_id, str) or not video_id or _watch_id(item.get("source_uri"), f"snapshot {index}.source_uri") != video_id:
                raise ValueError(f"snapshot {index} watch URI/video identity diverges")
            payload = item.get("payload")
            if isinstance(payload, dict):
                if payload.get("video_id") != video_id:
                    raise ValueError(f"snapshot {index} payload video identity diverges")
                webpage = payload.get("webpage_url")
                if webpage is not None and _watch_id(webpage, f"snapshot {index}.payload.webpage_url") != video_id:
                    raise ValueError(f"snapshot {index} payload watch URI diverges")
    return len(channels), video_count, channels


def validate_market_source(
    root: Path,
    source: dict[str, str],
    snapshots: dict[str, Any],
    contract: dict[str, Any],
) -> dict[str, Any]:
    """Validate a bound source and return a non-authoritative provenance summary.

    ``FIXTURE`` mode exists only for deterministic algorithm tests.  It can
    never return the live-evidence status consumed by a use-time gate.
    """
    root = Path(root).resolve()
    if not isinstance(contract, dict) or set(contract) != _CONTRACT_KEYS:
        raise ValueError("provenance contract has an invalid shape")
    evidence_mode = contract.get("evidence_mode")
    if evidence_mode not in {"LIVE", "FIXTURE"}:
        raise ValueError("evidence_mode must be LIVE or FIXTURE")
    operation_id = contract.get("operation_id")
    if not isinstance(operation_id, str) or not operation_id:
        raise ValueError("contract operation_id must be a non-empty string")
    expected_collector = _collector(contract.get("collector"))
    source_path, source_bytes, source_binding = _binding(root, source, "source")
    resident = _strict_json(source_bytes, "source")
    if not isinstance(resident, dict) or not isinstance(snapshots, dict):
        raise ValueError("source bundle must be an object")
    if _canonical(resident) != _canonical(snapshots):
        raise ValueError("supplied snapshots diverge from bound source bytes")
    channel_count, video_count, channel_records = _check_bundle(resident, operation_id, expected_collector)

    base = {
        "evidence_mode": evidence_mode,
        "operation_id": operation_id,
        "source": {
            **source_binding,
            "size_bytes": len(source_bytes),
            "cutoff_at": resident.get("captured_at"),
        },
        "collector": expected_collector,
        "channel_count": channel_count,
        "video_count": video_count,
    }
    manifest_binding = contract.get("integrity_manifest")
    if evidence_mode == "FIXTURE":
        if manifest_binding is not None:
            raise ValueError("FIXTURE provenance must not carry a live integrity manifest")
        if _sha256(source_path.read_bytes()) != source_binding["sha256"]:
            raise ValueError("source changed during provenance validation")
        return {"status": "FIXTURE_NOT_LIVE", **base, "manifest": None, "scope": None}

    if manifest_binding is None:
        raise ValueError("LIVE provenance requires an integrity manifest binding")
    manifest_path, manifest_bytes, normalized_manifest = _binding(
        root, manifest_binding, "integrity_manifest"
    )
    if manifest_path.name != "integrity_manifest.json" or manifest_path.parent != source_path.parent:
        raise ValueError("LIVE manifest and source must belong to the same immutable run directory")
    manifest = _strict_json(manifest_bytes, "integrity_manifest")
    entries = _manifest_entries(root, manifest)
    source_entry = _entry_for(source_path, root, entries, "source")
    scope_path = source_path.parent / "scope.json"
    if not scope_path.is_file():
        raise ValueError("LIVE run has no resident scope.json")
    scope_entry = _entry_for(scope_path.resolve(), root, entries, "scope")
    scope_bytes = scope_path.read_bytes()
    scope = _strict_json(scope_bytes, "scope")
    if not isinstance(scope, dict) or scope.get("run_id") != operation_id or scope.get("phase") != 3:
        raise ValueError("scope identity diverges from source operation")
    catalog = scope.get("channels")
    if not isinstance(catalog, list):
        raise ValueError("scope channel catalog is missing")
    by_internal: dict[str, dict[str, Any]] = {}
    for index, route in enumerate(catalog):
        if not isinstance(route, dict):
            raise ValueError(f"scope channel {index} is not an object")
        internal = route.get("channel_id")
        if not isinstance(internal, str) or not internal or internal in by_internal:
            raise ValueError("scope has duplicate/invalid internal channel identity")
        if not isinstance(route.get("source_uri"), str) or not isinstance(route.get("role"), str):
            raise ValueError(f"scope channel {internal} lacks URI/role")
        by_internal[internal] = route
    if set(channel_records) != set(by_internal):
        raise ValueError("CHANNEL snapshots do not cover the exact scoped catalog")
    for internal, item in channel_records.items():
        route = by_internal[internal]
        if item.get("source_uri") != route["source_uri"]:
            raise ValueError(f"CHANNEL source URI diverges from scope: {internal}")
        payload = item.get("payload")
        if isinstance(payload, dict):
            if payload.get("catalog_role") != route["role"]:
                raise ValueError(f"CHANNEL role diverges from scope: {internal}")
            if payload.get("handle_requested") != route.get("handle"):
                raise ValueError(f"CHANNEL requested handle diverges from scope: {internal}")
    for index, item in enumerate(resident["snapshots"]):
        if item.get("entity_type") != "VIDEO":
            continue
        internal = item.get("channel_id")
        if internal not in by_internal:
            raise ValueError(f"VIDEO snapshot {index} belongs to an unscoped channel")
        payload = item.get("payload")
        if isinstance(payload, dict) and payload.get("catalog_role") != by_internal[internal]["role"]:
            raise ValueError(f"VIDEO role diverges from scope: {item.get('entity_id')}")

    for path, digest, label in (
        (source_path, source_binding["sha256"], "source"),
        (manifest_path, normalized_manifest["sha256"], "integrity manifest"),
        (scope_path, scope_entry["sha256"], "scope"),
    ):
        if _sha256(path.read_bytes()) != digest:
            raise ValueError(f"{label} changed during provenance validation")
    return {
        "status": "VERIFIED_LIVE",
        **base,
        "manifest": {
            **normalized_manifest,
            "source_entry": source_entry,
            "scope_entry": scope_entry,
        },
        "scope": {
            "path": scope_path.resolve().relative_to(root).as_posix(),
            "sha256": scope_entry["sha256"],
            "run_id": scope["run_id"],
            "channel_count": len(by_internal),
        },
    }
