from __future__ import annotations

import hashlib
import json
import math
import statistics
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import parse_qs, urlparse

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.db import ROOT


SCHEMA_VERSION = "1.1.0"
RULE_VERSION = "observatory-format-cohorts-v1.1"
RANKING_METRIC = "PUBLIC_VIEWS_PER_COMPLETE_DAY"
DEFAULT_MIN_GROUP_SIZE = 4
CONTENT_FORMATS = {"LONG", "SHORT"}
CATALOG_ROLES = {
    "OWNED",
    "FORMAT_REFERENCE",
    "MARKET_REFERENCE",
    "SPEED_REFERENCE",
    "LICENSED_SOURCE",
}
AGE_BANDS: tuple[tuple[str, int, int | None], ...] = (
    ("0_7D", 1, 7),
    ("8_30D", 8, 30),
    ("31_90D", 31, 90),
    ("91_365D", 91, 365),
    ("366D_PLUS", 366, None),
)


class FormatCohortError(ValueError):
    """Raised when source or compiled cohort evidence is internally inconsistent."""


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _stable_id(prefix: str, *parts: Any) -> str:
    body = _canonical(list(parts)).encode("utf-8")
    return f"{prefix}-{_sha256_bytes(body)[:24]}"


def _aware_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise FormatCohortError(f"{label} must be a non-empty RFC3339 timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise FormatCohortError(f"{label} is not a valid timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise FormatCohortError(f"{label} must include an explicit UTC offset")
    return parsed


def _published_at(payload: Mapping[str, Any]) -> tuple[datetime | None, str | None]:
    timestamp = payload.get("timestamp")
    if timestamp is not None:
        if (
            not isinstance(timestamp, (int, float))
            or isinstance(timestamp, bool)
            or not math.isfinite(float(timestamp))
        ):
            return None, None
        try:
            return datetime.fromtimestamp(float(timestamp), tz=timezone.utc), "TIMESTAMP"
        except (ValueError, OverflowError, OSError):
            return None, None
    upload_date = payload.get("upload_date")
    if isinstance(upload_date, str) and len(upload_date) == 8 and upload_date.isdigit():
        try:
            return datetime.strptime(upload_date, "%Y%m%d").replace(tzinfo=timezone.utc), "DATE"
        except ValueError:
            pass
    return None, None


def _age_band(age_complete_days: int) -> str:
    for name, minimum, maximum in AGE_BANDS:
        if age_complete_days >= minimum and (maximum is None or age_complete_days <= maximum):
            return name
    raise FormatCohortError(f"age outside configured bands: {age_complete_days}")


def _count(value: Any, label: str, *, required: bool) -> int | None:
    if value is None and not required:
        return None
    if type(value) is not int or value < 0:  # bool is intentionally rejected.
        raise FormatCohortError(f"{label} must be a non-negative integer or null")
    return value


def _relative_velocity(value: float, baseline: float) -> float | None:
    return round(value / baseline, 6) if baseline > 0 else None


def _finite_number(value: Any, label: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)):
        raise FormatCohortError(f"{label} must be a finite number")
    return float(value)


def _source_artifact_path(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return resolved.as_posix()


def _strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise FormatCohortError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def _reject_nonfinite_json(value: str) -> Any:
    raise FormatCohortError(f"non-finite JSON number is forbidden: {value}")


def _validate_source_snapshot(snapshot: Any, operation_id: str, captured_at: str) -> None:
    if not isinstance(snapshot, dict):
        raise FormatCohortError("every source snapshot must be an object")
    schema_path = ROOT / "schemas" / "observatory_snapshot.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(snapshot),
        key=lambda item: list(item.absolute_path),
    )
    if errors:
        error = errors[0]
        where = "/".join(str(part) for part in error.absolute_path) or "<root>"
        raise FormatCohortError(f"source snapshot schema invalid at {where}: {error.message}")
    if snapshot.get("operation_id") != operation_id:
        raise FormatCohortError("source snapshot operation_id diverges from bundle")
    if snapshot.get("captured_at") != captured_at:
        raise FormatCohortError("source snapshot captured_at diverges from bundle cutoff")
    _aware_datetime(snapshot.get("captured_at"), "snapshot.captured_at")


def _deduplicate_snapshots(snapshots: list[Any], operation_id: str, captured_at: str) -> tuple[list[dict[str, Any]], int, int]:
    by_snapshot_id: dict[str, str] = {}
    by_entity: dict[tuple[str, str, str], str] = {}
    unique: list[dict[str, Any]] = []
    exact_duplicate_count = 0
    exact_duplicate_video_count = 0
    for raw in snapshots:
        _validate_source_snapshot(raw, operation_id, captured_at)
        snapshot = dict(raw)
        canonical = _canonical(snapshot)
        snapshot_id = snapshot["snapshot_id"]
        prior_snapshot = by_snapshot_id.get(snapshot_id)
        if prior_snapshot is not None:
            if prior_snapshot != canonical:
                raise FormatCohortError(f"conflicting duplicate snapshot_id: {snapshot_id}")
            exact_duplicate_count += 1
            exact_duplicate_video_count += int(snapshot["entity_type"] == "VIDEO")
            continue
        entity_key = (snapshot["channel_id"], snapshot["entity_type"], snapshot["entity_id"])
        prior_entity = by_entity.get(entity_key)
        if prior_entity is not None:
            if prior_entity != canonical:
                raise FormatCohortError(
                    "conflicting duplicate entity: " + "/".join(entity_key)
                )
            exact_duplicate_count += 1
            exact_duplicate_video_count += int(snapshot["entity_type"] == "VIDEO")
            continue
        by_snapshot_id[snapshot_id] = canonical
        by_entity[entity_key] = canonical
        unique.append(snapshot)
    return unique, exact_duplicate_count, exact_duplicate_video_count


def _channel_index(snapshots: list[dict[str, Any]]) -> dict[str, dict[str, str]]:
    channels: dict[str, dict[str, str]] = {}
    public_to_internal: dict[str, str] = {}
    for snapshot in snapshots:
        if snapshot["entity_type"] != "CHANNEL" or snapshot["payload"] is None:
            continue
        payload = snapshot["payload"]
        public_id = payload.get("channel_id_public")
        role = payload.get("catalog_role")
        if not isinstance(public_id, str) or not public_id:
            raise FormatCohortError(f"channel {snapshot['channel_id']} lacks channel_id_public")
        if role not in CATALOG_ROLES:
            raise FormatCohortError(f"channel {snapshot['channel_id']} has unsupported catalog_role")
        current = {"channel_id_public": public_id, "catalog_role": role}
        prior = channels.get(snapshot["channel_id"])
        if prior is not None and prior != current:
            raise FormatCohortError(f"conflicting channel identity: {snapshot['channel_id']}")
        prior_internal = public_to_internal.get(public_id)
        if prior_internal is not None and prior_internal != snapshot["channel_id"]:
            raise FormatCohortError(
                f"public channel identity is aliased by multiple internal IDs: {public_id}"
            )
        channels[snapshot["channel_id"]] = current
        public_to_internal[public_id] = snapshot["channel_id"]
    return channels


def _exclusion(snapshot: Mapping[str, Any], reason: str, observed_format: Any = None) -> dict[str, Any]:
    return {
        "snapshot_id": snapshot["snapshot_id"],
        "channel_id": snapshot["channel_id"],
        "video_id": snapshot["entity_id"],
        "captured_at": snapshot["captured_at"],
        "reason": reason,
        "observed_content_format": observed_format if isinstance(observed_format, str) else None,
    }


def _is_exact_public_watch_url(value: Any, video_id: str) -> bool:
    if not isinstance(value, str) or not value:
        return False
    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True)
        return (
            parsed.scheme == "https"
            and parsed.hostname == "www.youtube.com"
            and parsed.port is None
            and parsed.username is None
            and parsed.password is None
            and parsed.path == "/watch"
            and parsed.params == ""
            and parsed.fragment == ""
            and set(query) == {"v"}
            and query["v"] == [video_id]
        )
    except (TypeError, ValueError):
        return False


def _rankable_member(
    snapshot: Mapping[str, Any],
    channel: Mapping[str, str],
    cutoff: datetime,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    payload = snapshot.get("payload")
    if not isinstance(payload, dict):
        return None, _exclusion(snapshot, "NO_VIDEO_PAYLOAD")
    video_id = payload.get("video_id")
    if video_id != snapshot["entity_id"]:
        raise FormatCohortError(f"video identity diverges for {snapshot['snapshot_id']}")
    if payload.get("channel_id_public") != channel["channel_id_public"]:
        raise FormatCohortError(f"public channel identity diverges for {snapshot['snapshot_id']}")
    if payload.get("catalog_role") != channel["catalog_role"]:
        raise FormatCohortError(f"catalog role diverges for {snapshot['snapshot_id']}")
    content_format = payload.get("content_format")
    if snapshot.get("collection_status") != "COMPLETE":
        return None, _exclusion(snapshot, "SNAPSHOT_NOT_COMPLETE", content_format)
    if payload.get("availability") != "public":
        return None, _exclusion(snapshot, "AVAILABILITY_NOT_PUBLIC", content_format)
    if payload.get("public_fields_only") is not True:
        return None, _exclusion(snapshot, "PUBLIC_FIELDS_FLAG_NOT_TRUE", content_format)
    if not _is_exact_public_watch_url(snapshot.get("source_uri"), snapshot["entity_id"]):
        return None, _exclusion(snapshot, "INVALID_OR_DIVERGENT_WATCH_URL", content_format)
    if not _is_exact_public_watch_url(payload.get("webpage_url"), snapshot["entity_id"]):
        return None, _exclusion(snapshot, "INVALID_OR_DIVERGENT_WATCH_URL", content_format)
    if content_format not in CONTENT_FORMATS:
        return None, _exclusion(snapshot, "UNKNOWN_CONTENT_FORMAT", content_format)
    published, precision = _published_at(payload)
    if published is None:
        return None, _exclusion(snapshot, "INVALID_OR_MISSING_PUBLICATION_TIME", content_format)
    elapsed_seconds = (cutoff.astimezone(timezone.utc) - published).total_seconds()
    if not math.isfinite(elapsed_seconds) or elapsed_seconds < 0:
        return None, _exclusion(snapshot, "PUBLICATION_AFTER_CUTOFF", content_format)
    age_complete_days = math.floor(elapsed_seconds / 86400)
    if age_complete_days < 1:
        return None, _exclusion(snapshot, "AGE_BELOW_COMPLETE_DAY", content_format)
    view_value = payload.get("view_count")
    if view_value is None:
        return None, _exclusion(snapshot, "MISSING_VIEW_COUNT", content_format)
    view_count = _count(view_value, f"{snapshot['snapshot_id']}.view_count", required=True)
    like_count = _count(payload.get("like_count"), f"{snapshot['snapshot_id']}.like_count", required=False)
    comment_count = _count(payload.get("comment_count"), f"{snapshot['snapshot_id']}.comment_count", required=False)
    views_per_day = round(view_count / age_complete_days, 6)
    snapshot_sha256 = _sha256_bytes(_canonical(snapshot).encode("utf-8"))
    return {
        "snapshot_id": snapshot["snapshot_id"],
        "snapshot_sha256": snapshot_sha256,
        "video_id": snapshot["entity_id"],
        "channel_id": snapshot["channel_id"],
        "catalog_role": channel["catalog_role"],
        "population_scope": "OWNED" if channel["catalog_role"] == "OWNED" else "MARKET",
        "content_format": content_format,
        "age_band": _age_band(age_complete_days),
        "captured_at": snapshot["captured_at"],
        "source_uri": snapshot["source_uri"],
        "published_at": published.isoformat(),
        "published_at_precision": precision,
        "age_complete_days": age_complete_days,
        "view_count": view_count,
        "like_count": like_count,
        "comment_count": comment_count,
        "views_per_complete_day": views_per_day,
        "relative_velocity": None,
        "rank_position": 0,
        "kind": None,
    }, None


def _compile_group(
    operation_id: str,
    key: tuple[str, str, str, str, str],
    members: list[dict[str, Any]],
    min_group_size: int,
) -> dict[str, Any]:
    population_scope, role, channel_id, content_format, age_band = key
    ranked = sorted(
        members,
        key=lambda item: (-item["views_per_complete_day"], item["video_id"], item["snapshot_id"]),
    )
    baseline = round(statistics.median(item["views_per_complete_day"] for item in ranked), 6)
    sufficient = len(ranked) >= min_group_size
    quartile_size = math.ceil(len(ranked) * 0.25) if sufficient else 0
    winner_ids: list[str] = []
    median_ids: list[str] = []
    weak_ids: list[str] = []
    for position, member in enumerate(ranked, 1):
        member["rank_position"] = position
        member["relative_velocity"] = _relative_velocity(member["views_per_complete_day"], baseline)
        if sufficient:
            if position <= quartile_size:
                member["kind"] = "WINNER"
                winner_ids.append(member["snapshot_id"])
            elif position > len(ranked) - quartile_size:
                member["kind"] = "WEAK"
                weak_ids.append(member["snapshot_id"])
            else:
                member["kind"] = "MEDIAN"
                median_ids.append(member["snapshot_id"])
    group_id = _stable_id(
        "fmtgrp", operation_id, population_scope, role, channel_id, content_format, age_band, RULE_VERSION
    )
    return {
        "group_id": group_id,
        "channel_id": channel_id,
        "catalog_role": role,
        "population_scope": population_scope,
        "content_format": content_format,
        "age_band": age_band,
        "status": "SUFFICIENT" if sufficient else "INSUFFICIENT_SAMPLE",
        "sample_count": len(ranked),
        "minimum_sample_size": min_group_size,
        "baseline_views_per_day": baseline,
        "relative_velocity_status": "AVAILABLE" if baseline > 0 else "UNAVAILABLE_ZERO_BASELINE",
        "members": ranked,
        "cohorts": {
            "winner": winner_ids,
            "median": median_ids,
            "weak": weak_ids,
        },
    }


def compile_audio_market_cohorts(snapshots_path: Path, classifications_path: Path) -> dict[str, Any]:
    """Reuse public ranking for explicitly evidenced audio research cells.

    Target country is a research question, never inferred audience geography.
    Classification pins each original snapshot and cites its source. Missing
    classifications remain excluded; discovery metadata does not prove rights.
    """
    source_raw = Path(snapshots_path).read_bytes()
    annotation_raw = Path(classifications_path).read_bytes()
    source = json.loads(source_raw, object_pairs_hook=_strict_object,
                        parse_constant=_reject_nonfinite_json)
    annotations = json.loads(annotation_raw, object_pairs_hook=_strict_object,
                             parse_constant=_reject_nonfinite_json)
    if annotations.get("source_sha256") != _sha256_bytes(source_raw):
        raise FormatCohortError("audio classification source bytes diverged")
    if source.get("schema_version") != "1.0.0":
        raise FormatCohortError("unsupported public bundle")
    operation, captured = source["operation_id"], source["captured_at"]
    cutoff = _aware_datetime(captured, "bundle.captured_at")
    snapshots, _, _ = _deduplicate_snapshots(source["snapshots"], operation, captured)
    channels = _channel_index(snapshots)
    by_id = {row["snapshot_id"]: row for row in snapshots if row["entity_type"] == "VIDEO"}
    video_channels = {}
    for snapshot in by_id.values():
        video_id, channel_id = snapshot["entity_id"], snapshot["channel_id"]
        if video_id in video_channels and video_channels[video_id] != channel_id:
            raise FormatCohortError("global audio video identity appears under multiple channels")
        video_channels[video_id] = channel_id
    labels = {}
    for row in annotations["classifications"]:
        sid = row["snapshot_id"]
        if sid in labels or sid not in by_id:
            raise FormatCohortError("duplicate or unknown audio snapshot")
        snapshot = by_id[sid]
        if row["snapshot_sha256"] != _sha256_bytes(_canonical(snapshot).encode("utf-8")):
            raise FormatCohortError("audio classification snapshot diverged")
        if row.get("evidence_uri") != snapshot["source_uri"]:
            raise FormatCohortError("audio classification evidence source diverged")
        if row.get("target_country") not in {"US", "CA", "GB", "AU"}:
            raise FormatCohortError("target country outside initial research scope")
        for field in ("language", "subject", "audio_format", "classification_basis"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise FormatCohortError(f"audio classification lacks {field}")
        duration = snapshot["payload"].get("duration_seconds")
        if _finite_number(duration, "duration_seconds") <= 0:
            raise FormatCohortError("positive observed duration required")
        labels[sid] = row
    groups = {}
    excluded = []
    for sid, snapshot in sorted(by_id.items()):
        if sid not in labels:
            excluded.append(_exclusion(snapshot, "AUDIO_CLASSIFICATION_MISSING"))
            continue
        channel = channels.get(snapshot["channel_id"])
        if channel is None:
            raise FormatCohortError("audio video lacks channel identity")
        member, exclusion = _rankable_member(snapshot, channel, cutoff)
        if exclusion:
            excluded.append(exclusion)
            continue
        label = labels[sid]
        cell = tuple(label[key] for key in ("target_country", "language", "subject", "audio_format"))
        key = (*cell, member["population_scope"], member["catalog_role"],
               member["channel_id"], member["content_format"], member["age_band"])
        groups.setdefault(key, []).append(member)
    compiled = []
    for key, members in sorted(groups.items()):
        cell = dict(zip(("target_country", "language", "subject", "audio_format"), key[:4]))
        group = _compile_group(_stable_id("audio-cell", operation, cell), key[4:], members,
                               DEFAULT_MIN_GROUP_SIZE)
        selected = [by_id[item["snapshot_id"]] for item in members]
        published = [_published_at(item["payload"])[0] for item in selected]
        span_days = (max(published) - min(published)).total_seconds() / 86400
        group.update(research_cell=cell, duration_seconds_median=statistics.median(
            item["payload"]["duration_seconds"] for item in selected),
            observed_upload_span_days=span_days,
            uploads_per_week_in_observed_span=(len(selected)-1)*7/span_days if span_days > 0 else None)
        compiled.append(group)
    return {"rule_version": "audio-market-cohorts-v1", "source_sha256": _sha256_bytes(source_raw),
            "classifications_sha256": _sha256_bytes(annotation_raw), "captured_at": captured,
            "groups": compiled, "exclusions": excluded,
            "audience_country_observed": False, "competitor_rpm_observed": False,
            "production_authorized": False, "publication_authorized": False}


def compile_format_cohorts(
    snapshots_path: Path,
    *,
    min_group_size: int = DEFAULT_MIN_GROUP_SIZE,
) -> dict[str, Any]:
    """Compile exact-format/age/channel cohorts without mutating legacy artifacts."""
    if type(min_group_size) is not int or min_group_size < 4:
        raise FormatCohortError("min_group_size must be an integer >= 4")
    path = Path(snapshots_path)
    raw_bytes = path.read_bytes()
    try:
        source = json.loads(
            raw_bytes.decode("utf-8"),
            object_pairs_hook=_strict_object,
            parse_constant=_reject_nonfinite_json,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FormatCohortError("public snapshot bundle is not valid UTF-8 JSON") from exc
    if not isinstance(source, dict):
        raise FormatCohortError("public snapshot bundle must be an object")
    if source.get("schema_version") != "1.0.0":
        raise FormatCohortError("unsupported public snapshot bundle schema_version")
    operation_id = source.get("operation_id")
    captured_at = source.get("captured_at")
    snapshots = source.get("snapshots")
    if not isinstance(operation_id, str) or not operation_id:
        raise FormatCohortError("bundle operation_id must be a non-empty string")
    cutoff = _aware_datetime(captured_at, "bundle.captured_at")
    if not isinstance(snapshots, list):
        raise FormatCohortError("bundle snapshots must be an array")
    unique, exact_duplicate_count, exact_duplicate_video_count = _deduplicate_snapshots(
        snapshots, operation_id, captured_at
    )
    channels = _channel_index(unique)
    grouped: dict[tuple[str, str, str, str, str], list[dict[str, Any]]] = {}
    exclusions: list[dict[str, Any]] = []
    video_snapshot_count = 0
    video_to_channel: dict[str, str] = {}
    for snapshot in unique:
        if snapshot["entity_type"] != "VIDEO":
            continue
        video_snapshot_count += 1
        prior_channel = video_to_channel.get(snapshot["entity_id"])
        if prior_channel is not None and prior_channel != snapshot["channel_id"]:
            raise FormatCohortError(
                f"global video_id appears under multiple channels: {snapshot['entity_id']}"
            )
        video_to_channel[snapshot["entity_id"]] = snapshot["channel_id"]
        channel = channels.get(snapshot["channel_id"])
        if channel is None:
            raise FormatCohortError(f"video lacks matching channel snapshot: {snapshot['snapshot_id']}")
        member, exclusion = _rankable_member(snapshot, channel, cutoff)
        if exclusion is not None:
            exclusions.append(exclusion)
            continue
        assert member is not None
        key = (
            member["population_scope"], member["catalog_role"], member["channel_id"],
            member["content_format"], member["age_band"],
        )
        grouped.setdefault(key, []).append(member)
    groups = [
        _compile_group(operation_id, key, grouped[key], min_group_size)
        for key in sorted(grouped)
    ]
    exclusions.sort(key=lambda item: (item["channel_id"], item["video_id"], item["snapshot_id"], item["reason"]))
    source_sha256 = _sha256_bytes(raw_bytes)
    result = {
        "schema_version": SCHEMA_VERSION,
        "artifact_id": _stable_id(
            "fmtcoh", operation_id, captured_at, source_sha256, min_group_size, RULE_VERSION
        ),
        "operation_id": operation_id,
        "cutoff_at": captured_at,
        "rule_version": RULE_VERSION,
        "ranking_metric": RANKING_METRIC,
        "source": {
            "artifact_path": _source_artifact_path(path),
            "content_sha256": source_sha256,
            "schema_version": source["schema_version"],
            "operation_id": operation_id,
            "captured_at": captured_at,
            "snapshot_count": len(snapshots),
            "unique_snapshot_count": len(unique),
            "video_snapshot_count": sum(
                1 for item in snapshots if isinstance(item, dict) and item.get("entity_type") == "VIDEO"
            ),
            "unique_video_count": video_snapshot_count,
            "exact_duplicate_video_count": exact_duplicate_video_count,
        },
        "policy": {
            "minimum_group_size": min_group_size,
            "age_bands": [
                {"age_band": name, "minimum_complete_days": minimum, "maximum_complete_days": maximum}
                for name, minimum, maximum in AGE_BANDS
            ],
            "group_key": ["population_scope", "catalog_role", "channel_id", "content_format", "age_band"],
            "cross_group_fallback_permitted": False,
        },
        "groups": groups,
        "exclusions": exclusions,
        "exact_duplicate_count": exact_duplicate_count,
        "causal_claims_permitted": False,
        "private_metrics_used": False,
        "production_authorized": False,
        "publication_authorized": False,
        "limitations": [
            "Public views per complete day is descriptive and does not expose impressions, retention, RPM, qualified YPP progress, or causality.",
            "Groups never fall back across channel, catalog role, content format, or age band.",
            "INSUFFICIENT_SAMPLE groups are preserved but may not be used for format comparison.",
        ],
    }
    validate_format_cohorts(result)
    return result


def validate_format_cohorts(document: Mapping[str, Any]) -> None:
    """Validate the new schema and recompute all deterministic cohort invariants."""
    schema_path = ROOT / "schemas" / "observatory_format_cohorts.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(document),
        key=lambda item: list(item.absolute_path),
    )
    if errors:
        error = errors[0]
        where = "/".join(str(part) for part in error.absolute_path) or "<root>"
        raise FormatCohortError(f"format cohort schema invalid at {where}: {error.message}")
    source = document["source"]
    expected_artifact_id = _stable_id(
        "fmtcoh", document["operation_id"], document["cutoff_at"], source["content_sha256"],
        document["policy"]["minimum_group_size"], document["rule_version"],
    )
    if document["artifact_id"] != expected_artifact_id:
        raise FormatCohortError("artifact_id does not bind source, cutoff, policy, and rule")
    if source["operation_id"] != document["operation_id"] or source["captured_at"] != document["cutoff_at"]:
        raise FormatCohortError("top-level identity diverges from source binding")
    cutoff = _aware_datetime(document["cutoff_at"], "document.cutoff_at")
    if source["snapshot_count"] != source["unique_snapshot_count"] + document["exact_duplicate_count"]:
        raise FormatCohortError("source snapshot counts do not reconcile")
    if source["video_snapshot_count"] != source["unique_video_count"] + source["exact_duplicate_video_count"]:
        raise FormatCohortError("source video counts do not reconcile")
    expected_group_key = ["population_scope", "catalog_role", "channel_id", "content_format", "age_band"]
    if document["policy"]["group_key"] != expected_group_key:
        raise FormatCohortError("group key policy diverges from current rule")
    expected_bands = [
        {"age_band": name, "minimum_complete_days": minimum, "maximum_complete_days": maximum}
        for name, minimum, maximum in AGE_BANDS
    ]
    if document["policy"]["age_bands"] != expected_bands:
        raise FormatCohortError("age-band policy diverges from current rule")
    seen_groups: set[tuple[str, str, str, str, str]] = set()
    seen_snapshots: set[str] = set()
    seen_entities: set[tuple[str, str]] = set()
    ordered_keys: list[tuple[str, str, str, str, str]] = []
    member_count = 0
    for group in document["groups"]:
        key = (
            group["population_scope"], group["catalog_role"], group["channel_id"],
            group["content_format"], group["age_band"],
        )
        if key in seen_groups:
            raise FormatCohortError("duplicate exact cohort group")
        seen_groups.add(key)
        ordered_keys.append(key)
        expected_scope = "OWNED" if group["catalog_role"] == "OWNED" else "MARKET"
        if group["population_scope"] != expected_scope:
            raise FormatCohortError(f"population scope conflicts with catalog role: {group['group_id']}")
        expected_group_id = _stable_id("fmtgrp", document["operation_id"], *key, document["rule_version"])
        if group["group_id"] != expected_group_id:
            raise FormatCohortError(f"group_id mismatch: {group['group_id']}")
        members = group["members"]
        member_count += len(members)
        if group["sample_count"] != len(members):
            raise FormatCohortError(f"sample_count mismatch: {group['group_id']}")
        sufficient = len(members) >= group["minimum_sample_size"]
        if group["minimum_sample_size"] != document["policy"]["minimum_group_size"]:
            raise FormatCohortError("group minimum sample diverges from policy")
        if group["status"] != ("SUFFICIENT" if sufficient else "INSUFFICIENT_SAMPLE"):
            raise FormatCohortError(f"group status mismatch: {group['group_id']}")
        values = [
            _finite_number(member["views_per_complete_day"], f"{member['snapshot_id']}.views_per_complete_day")
            for member in members
        ]
        expected_baseline = round(statistics.median(values), 6)
        observed_baseline = _finite_number(group["baseline_views_per_day"], f"{group['group_id']}.baseline")
        if observed_baseline != expected_baseline:
            raise FormatCohortError(f"baseline mismatch: {group['group_id']}")
        if group["relative_velocity_status"] != (
            "AVAILABLE" if expected_baseline > 0 else "UNAVAILABLE_ZERO_BASELINE"
        ):
            raise FormatCohortError(f"relative-velocity status mismatch: {group['group_id']}")
        expected_order = sorted(
            members,
            key=lambda item: (-item["views_per_complete_day"], item["video_id"], item["snapshot_id"]),
        )
        if [item["snapshot_id"] for item in members] != [item["snapshot_id"] for item in expected_order]:
            raise FormatCohortError(f"member ordering mismatch: {group['group_id']}")
        quartile_size = math.ceil(len(members) * 0.25) if sufficient else 0
        expected_cohorts = {"winner": [], "median": [], "weak": []}
        for position, member in enumerate(members, 1):
            if member["snapshot_id"] in seen_snapshots:
                raise FormatCohortError(f"snapshot appears in multiple groups: {member['snapshot_id']}")
            seen_snapshots.add(member["snapshot_id"])
            entity_key = (member["channel_id"], member["video_id"])
            if entity_key in seen_entities:
                raise FormatCohortError("video entity appears in multiple groups")
            seen_entities.add(entity_key)
            for field, expected in (
                ("channel_id", group["channel_id"]),
                ("catalog_role", group["catalog_role"]),
                ("population_scope", group["population_scope"]),
                ("content_format", group["content_format"]),
                ("age_band", group["age_band"]),
            ):
                if member[field] != expected:
                    raise FormatCohortError(f"member {field} crosses its exact group")
            if member["rank_position"] != position:
                raise FormatCohortError(f"rank position mismatch: {member['snapshot_id']}")
            if member["captured_at"] != document["cutoff_at"]:
                raise FormatCohortError(f"member capture diverges from cutoff: {member['snapshot_id']}")
            published = _aware_datetime(member["published_at"], f"{member['snapshot_id']}.published_at")
            elapsed_seconds = (cutoff.astimezone(timezone.utc) - published.astimezone(timezone.utc)).total_seconds()
            expected_age = math.floor(elapsed_seconds / 86400)
            if expected_age < 1 or member["age_complete_days"] != expected_age:
                raise FormatCohortError(f"member age mismatch: {member['snapshot_id']}")
            if member["age_band"] != _age_band(expected_age):
                raise FormatCohortError(f"member age band mismatch: {member['snapshot_id']}")
            expected_views_per_day = round(member["view_count"] / member["age_complete_days"], 6)
            if member["views_per_complete_day"] != expected_views_per_day:
                raise FormatCohortError(f"views-per-day mismatch: {member['snapshot_id']}")
            expected_relative = _relative_velocity(member["views_per_complete_day"], expected_baseline)
            if member["relative_velocity"] is not None:
                _finite_number(member["relative_velocity"], f"{member['snapshot_id']}.relative_velocity")
            if member["relative_velocity"] != expected_relative:
                raise FormatCohortError(f"relative velocity mismatch: {member['snapshot_id']}")
            expected_kind = None
            if sufficient:
                if position <= quartile_size:
                    expected_kind = "WINNER"
                    cohort_key = "winner"
                elif position > len(members) - quartile_size:
                    expected_kind = "WEAK"
                    cohort_key = "weak"
                else:
                    expected_kind = "MEDIAN"
                    cohort_key = "median"
                expected_cohorts[cohort_key].append(member["snapshot_id"])
            if member["kind"] != expected_kind:
                raise FormatCohortError(f"cohort kind mismatch: {member['snapshot_id']}")
        if group["cohorts"] != expected_cohorts:
            raise FormatCohortError(f"cohort membership mismatch: {group['group_id']}")
    if ordered_keys != sorted(ordered_keys):
        raise FormatCohortError("groups are not in deterministic key order")
    exclusion_ids: set[str] = set()
    exclusion_order: list[tuple[str, str, str, str]] = []
    for exclusion in document["exclusions"]:
        if exclusion["snapshot_id"] in seen_snapshots or exclusion["snapshot_id"] in exclusion_ids:
            raise FormatCohortError("excluded snapshot is duplicated or also ranked")
        exclusion_ids.add(exclusion["snapshot_id"])
        if exclusion["captured_at"] != document["cutoff_at"]:
            raise FormatCohortError("excluded snapshot capture diverges from cutoff")
        exclusion_order.append((
            exclusion["channel_id"], exclusion["video_id"], exclusion["snapshot_id"], exclusion["reason"]
        ))
    if exclusion_order != sorted(exclusion_order):
        raise FormatCohortError("exclusions are not in deterministic order")
    if member_count + len(document["exclusions"]) != source["unique_video_count"]:
        raise FormatCohortError("ranked and excluded videos do not reconcile to source")
