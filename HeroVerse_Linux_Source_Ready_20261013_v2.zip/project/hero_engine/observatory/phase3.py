from __future__ import annotations

import csv
import hashlib
import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from hero_engine.db import DEFAULT_DB, ROOT, initialize
from hero_engine.mining.pipeline import FIXTURE_IDS

from .collectors import PublicChannel, collect_channel
from .openings import analyze_openings
from .store import (
    ChannelRegistration,
    ObservatoryStore,
    apply_migration,
    canonical_json,
    create_verified_backup,
    database_inventory,
    sha256_bytes,
    sha256_file,
    stable_id,
    utc_now,
)


OUTPUT_ROOT = ROOT / "output" / "observatory" / "phase3"
ROLE_MAP = {
    "owned": "OWNED",
    "format_reference": "FORMAT_REFERENCE",
    "market_reference": "MARKET_REFERENCE",
    "speed_reference": "SPEED_REFERENCE",
    "licensed_source": "LICENSED_SOURCE",
}
ROLE_LIMITS = {
    "OWNED": 50,
    "FORMAT_REFERENCE": 30,
    "MARKET_REFERENCE": 12,
    "SPEED_REFERENCE": 16,
    "LICENSED_SOURCE": 8,
}


@dataclass(frozen=True)
class Phase3Config:
    run_id: str = "phase3-2026-09-02-catalog-v2"
    db_path: Path = DEFAULT_DB
    output_root: Path = OUTPUT_ROOT
    collect_public_metadata: bool = True


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _load_schema(name: str) -> dict[str, Any]:
    return json.loads((ROOT / "schemas" / name).read_text(encoding="utf-8"))


def _validate(name: str, payload: Any) -> list[str]:
    validator = Draft202012Validator(_load_schema(name), format_checker=FormatChecker())
    return [
        f"{'/'.join(str(part) for part in error.absolute_path) or '<root>'}: {error.message}"
        for error in sorted(validator.iter_errors(payload), key=lambda item: list(item.absolute_path))
    ]


def _catalog() -> list[dict[str, Any]]:
    with (ROOT / "data" / "seed_channels.csv").open(encoding="utf-8", newline="") as handle:
        records = list(csv.DictReader(handle))
    result = []
    for item in records:
        role = ROLE_MAP.get(item["role"])
        if role is None:
            raise ValueError(f"unsupported catalog role: {item['role']}")
        result.append(
            {
                "channel_id": stable_id("chn", item["handle"].lower()),
                "handle": item["handle"],
                "name": item["name"],
                "role": role,
                "source_uri": item["source_url"],
                "max_videos": ROLE_LIMITS[role],
            }
        )
    return result


def _run_context(run_dir: Path, run_id: str) -> dict[str, str]:
    path = run_dir / "run_context.json"
    if path.is_file():
        context = json.loads(path.read_text(encoding="utf-8"))
        if context.get("run_id") != run_id:
            raise RuntimeError("run directory contains another run id")
        return context
    context = {"run_id": run_id, "operation_id": run_id, "captured_at": utc_now()}
    _write_json(path, context)
    return context


def _snapshot_cache_path(run_dir: Path) -> Path:
    return run_dir / "public_snapshots.json"


def _collect_or_load(
    config: Phase3Config,
    catalog: list[dict[str, Any]],
    operation_id: str,
    captured_at: str,
    run_dir: Path,
) -> tuple[list[dict[str, Any]], bool]:
    cache = _snapshot_cache_path(run_dir)
    if cache.is_file():
        payload = json.loads(cache.read_text(encoding="utf-8"))
        return payload["snapshots"], True
    if not config.collect_public_metadata:
        raise RuntimeError("public snapshot cache is absent and collection is disabled")
    snapshots: list[dict[str, Any]] = []
    per_channel_dir = run_dir / "snapshots"
    for item in catalog:
        channel = PublicChannel(
            channel_id=item["channel_id"], handle=item["handle"], source_uri=item["source_uri"],
            role=item["role"], max_videos=item["max_videos"],
        )
        observed = collect_channel(operation_id, channel, captured_at)
        snapshots.extend(observed)
        _write_json(per_channel_dir / f"{item['handle'].lstrip('@')}.json", {
            "channel": item, "snapshots": observed,
        })
    _write_json(cache, {
        "schema_version": "1.0.0",
        "operation_id": operation_id,
        "captured_at": captured_at,
        "snapshots": snapshots,
    })
    return snapshots, False


def _coverage(
    operation_id: str,
    captured_at: str,
    format_channel_id: str,
    opening_payload: dict[str, Any],
    snapshots: list[dict[str, Any]],
) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    for video_id in FIXTURE_IDS:
        artifact = ROOT / "data" / "gold_standard" / video_id / "video_mining.json"
        document = json.loads(artifact.read_text(encoding="utf-8"))
        records.append(
            {
                "video_id": video_id,
                "channel_id": format_channel_id,
                "coverage_level": "FULL_VALIDATED",
                "fields": ["FULL_VIDEO", "HOOKS_0_30S", "TAKES", "TRANSCRIPT", "NARRATIVE_SEGMENTS", "PACKAGING"],
                "artifact_uri": artifact.relative_to(ROOT).as_posix(),
                "artifact_sha256": sha256_file(artifact),
                "rights_status": document["rights"]["status"],
                "holdout_from_phase2": False,
                "limitations": ["Local gold-standard evidence; public performance metrics remain unavailable."],
            }
        )
    opening_by_id = {item["video_id"]: item for item in opening_payload["records"]}
    for video_id, item in sorted(opening_by_id.items()):
        artifact = ROOT / item["evidence"]["video_artifact"]
        records.append(
            {
                "video_id": video_id,
                "channel_id": format_channel_id,
                "coverage_level": "OPENING_ONLY",
                "fields": ["HOOKS_0_30S", "FIRST_SPEECH", "SCENE_CUTS", "ASR_WORDS"],
                "artifact_uri": artifact.relative_to(ROOT).as_posix(),
                "artifact_sha256": item["evidence"]["video_sha256"],
                "rights_status": "ANALYSIS_ONLY",
                "holdout_from_phase2": item["holdout_from_phase2"],
                "limitations": list(item["limitations"]),
            }
        )
    for snapshot in sorted(
        (item for item in snapshots if item["entity_type"] == "VIDEO" and item["payload"] is not None),
        key=lambda item: (item["channel_id"], item["entity_id"]),
    ):
        payload_json = canonical_json(snapshot["payload"])
        fields = [key.upper() for key, value in snapshot["payload"].items() if value is not None]
        records.append(
            {
                "video_id": snapshot["entity_id"],
                "channel_id": snapshot["channel_id"],
                "coverage_level": "METADATA_ONLY",
                "fields": sorted(set(fields)),
                "artifact_uri": snapshot["source_uri"],
                "artifact_sha256": sha256_bytes(payload_json.encode("utf-8")),
                "rights_status": "ANALYSIS_ONLY",
                "holdout_from_phase2": snapshot["entity_id"] not in FIXTURE_IDS,
                "limitations": [
                    "Public point-in-time metadata only; no retention, CTR, watch hours, revenue, or RPM.",
                    "Public velocity is descriptive and does not establish causality.",
                ],
            }
        )
    levels = {level: sum(item["coverage_level"] == level for item in records) for level in ("FULL_VALIDATED", "OPENING_ONLY", "METADATA_ONLY")}
    field_summary: dict[str, int] = {}
    for record in records:
        for field in record["fields"]:
            field_summary[field] = field_summary.get(field, 0) + 1
    return {
        "schema_version": "1.0.0",
        "operation_id": operation_id,
        "generated_at": captured_at,
        "levels": levels,
        "records": records,
        "field_summary": dict(sorted(field_summary.items())),
        "limitations": [
            "The 16 opening clips contain 13 IDs outside Phase 2; one Phase 2 fixture has no separate intro clip.",
            "Only four videos have full validated take-by-take coverage.",
            "Metadata-only records must never be interpreted as full narrative analyses.",
        ],
    }


def _publication_datetime(payload: dict[str, Any]) -> datetime | None:
    if payload.get("timestamp") is not None:
        try:
            return datetime.fromtimestamp(float(payload["timestamp"]), tz=timezone.utc)
        except (TypeError, ValueError, OSError):
            pass
    value = payload.get("upload_date")
    if isinstance(value, str) and len(value) == 8 and value.isdigit():
        return datetime.strptime(value, "%Y%m%d").replace(tzinfo=timezone.utc)
    return None


def _rankable(snapshots: list[dict[str, Any]], cutoff_at: str) -> list[dict[str, Any]]:
    cutoff = datetime.fromisoformat(cutoff_at.replace("Z", "+00:00"))
    items = []
    for snapshot in snapshots:
        if snapshot["entity_type"] != "VIDEO" or snapshot["payload"] is None:
            continue
        payload = snapshot["payload"]
        published = _publication_datetime(payload)
        views = payload.get("view_count")
        if published is None or not isinstance(views, (int, float)) or views < 0 or published > cutoff:
            continue
        age_days = max(1, math.floor((cutoff - published).total_seconds() / 86400))
        items.append(
            {
                "video_id": snapshot["entity_id"],
                "channel_id": snapshot["channel_id"],
                "role": payload.get("catalog_role"),
                "rank_value": round(float(views) / age_days, 6),
                "age_complete_days": age_days,
                "published_at": published.isoformat(),
                "evidence_snapshot_id": snapshot["snapshot_id"],
            }
        )
    return items


def _members(items: list[dict[str, Any]], global_rank: dict[tuple[str, str], int]) -> list[dict[str, Any]]:
    return [
        {
            "video_id": item["video_id"],
            "rank_value": item["rank_value"],
            "rank_position": global_rank[(item["channel_id"], item["video_id"])],
            "age_complete_days": item["age_complete_days"],
            "evidence_snapshot_id": item["evidence_snapshot_id"],
        }
        for item in items
    ]


def build_cohorts(
    operation_id: str,
    cutoff_at: str,
    format_channel_id: str,
    snapshots: list[dict[str, Any]],
) -> dict[str, Any]:
    rankable = _rankable(snapshots, cutoff_at)
    reference = sorted(
        (item for item in rankable if item["channel_id"] == format_channel_id),
        key=lambda item: (-item["rank_value"], item["video_id"]),
    )
    if len(reference) < 12:
        raise RuntimeError(f"insufficient rankable format-reference sample: {len(reference)} < 12")
    global_rank = {(item["channel_id"], item["video_id"]): index for index, item in enumerate(reference, 1)}
    quartile = max(1, math.ceil(len(reference) * 0.25))
    winner = reference[:quartile]
    weak = reference[-quartile:]
    median = reference[quartile:-quartile]
    latest = sorted(reference, key=lambda item: (-datetime.fromisoformat(item["published_at"]).timestamp(), item["video_id"]))[:quartile]
    cohorts = [
        {
            "cohort_id": "grace-winner-q1",
            "channel_id": format_channel_id,
            "kind": "WINNER",
            "selection_rule": f"Top ceil(N*0.25) by public views per complete day; N={len(reference)}, q={quartile}; deterministic video_id tie-break.",
            "sample_size": len(winner),
            "members": _members(winner, global_rank),
            "limitations": ["Public views are a point-in-time count and do not expose impressions or retention."],
        },
        {
            "cohort_id": "grace-median-q2-q3",
            "channel_id": format_channel_id,
            "kind": "MEDIAN",
            "selection_rule": f"Middle N-2*ceil(N*0.25) by public views per complete day; N={len(reference)}, q={quartile}.",
            "sample_size": len(median),
            "members": _members(median, global_rank),
            "limitations": ["The middle band is descriptive; it is not a causal control group."],
        },
        {
            "cohort_id": "grace-weak-q4",
            "channel_id": format_channel_id,
            "kind": "WEAK",
            "selection_rule": f"Bottom ceil(N*0.25) by public views per complete day; N={len(reference)}, q={quartile}; deterministic video_id tie-break.",
            "sample_size": len(weak),
            "members": _members(weak, global_rank),
            "limitations": ["Low public velocity does not identify the cause of underperformance."],
        },
        {
            "cohort_id": "grace-latest-period",
            "channel_id": format_channel_id,
            "kind": "PERIOD",
            "selection_rule": f"Latest {quartile} rankable format-reference videos by public publication timestamp.",
            "sample_size": len(latest),
            "members": _members(latest, global_rank),
            "limitations": ["Period cohort may mix platform, seasonality, and editorial changes."],
        },
    ]
    comparison_roles = {"FORMAT_REFERENCE", "MARKET_REFERENCE", "SPEED_REFERENCE"}
    best_by_channel: list[dict[str, Any]] = []
    for channel_id in sorted({item["channel_id"] for item in rankable if item["role"] in comparison_roles}):
        candidates = sorted(
            (item for item in rankable if item["channel_id"] == channel_id),
            key=lambda item: (-item["rank_value"], item["video_id"]),
        )
        if candidates:
            best_by_channel.append(candidates[0])
    cross_rank = {
        (item["channel_id"], item["video_id"]): index
        for index, item in enumerate(sorted(best_by_channel, key=lambda item: (-item["rank_value"], item["video_id"])), 1)
    }
    if best_by_channel:
        cohorts.append(
            {
                "cohort_id": "cross-channel-public-velocity",
                "channel_id": None,
                "kind": "CROSS_CHANNEL",
                "selection_rule": "Highest public views per complete day among the collected sample of each format/market/speed reference channel.",
                "sample_size": len(best_by_channel),
                "members": _members(sorted(best_by_channel, key=lambda item: (-item["rank_value"], item["video_id"])), cross_rank),
                "limitations": [
                    "Different channel sizes, catalog ages, audiences, and collection limits make this a descriptive comparison only.",
                    "No monetization approval, RPM, retention, or traffic-source equivalence is observable publicly.",
                ],
            }
        )
    return {
        "schema_version": "1.0.0",
        "operation_id": operation_id,
        "cutoff_at": cutoff_at,
        "ranking_metric": "PUBLIC_VIEWS_PER_COMPLETE_DAY",
        "rule_version": "phase3-quartiles-1.0.0",
        "cohorts": cohorts,
        "causal_claims_permitted": False,
        "limitations": [
            "Views per day normalizes age but not impressions, audience size, distribution source, or seasonality.",
            "This phase prepares evidence and does not issue a final channel model.",
        ],
    }


def _integrity_manifest(run_dir: Path) -> dict[str, Any]:
    entries = []
    for path in sorted(item for item in run_dir.rglob("*") if item.is_file() and item.name != "integrity_manifest.json"):
        entries.append(
            {
                "artifact": path.relative_to(ROOT).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    payload = {
        "schema_version": "1.0.0",
        "algorithm": "SHA-256",
        "item_count": len(entries),
        "total_size_bytes": sum(item["size_bytes"] for item in entries),
        "entries": entries,
    }
    _write_json(run_dir / "integrity_manifest.json", payload)
    return payload


def run_phase3(config: Phase3Config | None = None) -> dict[str, Any]:
    config = config or Phase3Config()
    initialize(config.db_path)
    run_dir = config.output_root / config.run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    context = _run_context(run_dir, config.run_id)
    operation_id = context["operation_id"]
    captured_at = context["captured_at"]
    catalog = _catalog()
    scope = {
        "phase": 3,
        "run_id": config.run_id,
        "channels": catalog,
        "public_tabs": ["videos", "shorts"],
        "limits_apply_per_tab": True,
        "media_download": False,
        "external_spend": False,
        "final_model": False,
    }
    _write_json(run_dir / "scope.json", scope)

    backup_dir = config.output_root / "preflight"
    backup_manifest_path = backup_dir / "database_backup_manifest.json"
    if backup_manifest_path.is_file():
        backup = json.loads(backup_manifest_path.read_text(encoding="utf-8"))
    else:
        backup = create_verified_backup(config.db_path, backup_dir)
    migration = apply_migration(config.db_path)
    _write_json(run_dir / "migration_receipt.json", migration)

    store = ObservatoryStore(config.db_path)
    store.create_operation(operation_id, "project-owner", "PHASE3_AUDITABLE_OBSERVATORY", scope, captured_at)
    for item in catalog:
        store.register_channel(
            operation_id,
            ChannelRegistration(item["channel_id"], item["handle"], item["role"], item["source_uri"]),
            captured_at,
        )
    snapshots, cache_hit = _collect_or_load(config, catalog, operation_id, captured_at, run_dir)
    snapshot_errors: list[str] = []
    ledger_schema_errors: list[str] = []
    public_tab_failures: list[dict[str, Any]] = []
    for snapshot in snapshots:
        errors = _validate("observatory_snapshot.schema.json", snapshot)
        snapshot_errors.extend(f"{snapshot['snapshot_id']}: {error}" for error in errors)
        if errors:
            continue
        store.add_snapshot(snapshot)
        event = store.append_event(
            operation_id,
            "PUBLIC_SNAPSHOT_RECORDED",
            "OBSERVED",
            snapshot["snapshot_id"],
            {
                "snapshot_id": snapshot["snapshot_id"],
                "entity_type": snapshot["entity_type"],
                "entity_id": snapshot["entity_id"],
                "collection_status": snapshot["collection_status"],
            },
            captured_at,
            channel_id=snapshot["channel_id"],
            source_uri=snapshot["source_uri"],
        )
        ledger_schema_errors.extend(_validate("observatory_ledger_event.schema.json", event))
        if snapshot["collection_status"] == "FAILED":
            error = snapshot["error"] or {"code": "UNKNOWN", "message": "unknown collection failure", "retryable": True}
            store.add_error(operation_id, "PUBLIC_COLLECTION", error["code"], error["message"], captured_at,
                            channel_id=snapshot["channel_id"], retryable=error["retryable"])
        if snapshot["entity_type"] == "CHANNEL" and snapshot["payload"] is not None:
            for tab in snapshot["payload"].get("tabs", []):
                if tab.get("status") != "FAILED" or not tab.get("error"):
                    continue
                tab_error = {
                    "channel_id": snapshot["channel_id"],
                    "tab": tab["tab"],
                    "source_uri": tab["source_uri"],
                    "error": tab["error"],
                }
                public_tab_failures.append(tab_error)
                store.add_error(
                    operation_id, f"PUBLIC_COLLECTION_{tab['tab'].upper()}", tab["error"]["code"],
                    tab["error"]["message"], captured_at, channel_id=snapshot["channel_id"],
                    retryable=tab["error"]["retryable"],
                )

    openings = analyze_openings()
    openings["operation_id"] = operation_id
    openings["generated_at"] = captured_at
    _write_json(run_dir / "opening_observations.json", openings)
    format_channel_id = next(item["channel_id"] for item in catalog if item["role"] == "FORMAT_REFERENCE")
    coverage = _coverage(operation_id, captured_at, format_channel_id, openings, snapshots)
    coverage_errors = _validate("observatory_coverage.schema.json", coverage)
    _write_json(run_dir / "coverage.json", coverage)
    for record in coverage["records"]:
        store.add_coverage(operation_id, record, captured_at)

    cohort_error: str | None = None
    try:
        cohorts = build_cohorts(operation_id, captured_at, format_channel_id, snapshots)
    except Exception as exc:
        cohort_error = str(exc)
        cohorts = {
            "schema_version": "1.0.0", "operation_id": operation_id, "cutoff_at": captured_at,
            "ranking_metric": "PUBLIC_VIEWS_PER_COMPLETE_DAY", "rule_version": "phase3-quartiles-1.0.0",
            "cohorts": [], "causal_claims_permitted": False,
            "limitations": [f"Cohort build blocked: {cohort_error}"],
        }
        store.add_error(operation_id, "COHORT_BUILD", type(exc).__name__, str(exc), captured_at, retryable=True)
    cohort_errors = _validate("observatory_cohorts.schema.json", cohorts)
    _write_json(run_dir / "cohorts.json", cohorts)
    if not cohort_errors:
        for cohort in cohorts["cohorts"]:
            store.add_cohort(operation_id, cohort, captured_at, cohorts["ranking_metric"])

    acquisition_baseline = {
        "schema_version": "1.0.0",
        "operation_id": operation_id,
        "captured_at": captured_at,
        "status": "INSUFFICIENT_PRIVATE_DATA",
        "external_spend_usd": 0.0,
        "ads_activation_permitted": False,
        "activation_phase_minimum": 6,
        "qualified_ypp_progress": {
            "subscribers": None, "public_watch_hours": None, "shorts_views_90d": None,
            "evidence_class": "UNAVAILABLE",
        },
        "economics": {"revenue": None, "rpm": None, "evidence_class": "UNAVAILABLE"},
        "forecast": {
            "probability_of_ypp_by_30_days": None,
            "calibration_status": "INSUFFICIENT_DATA",
            "decision_use_permitted": False,
        },
        "reason": "No authenticated YouTube Studio/Analytics outcome series exists; public metadata cannot substitute for qualified YPP or RPM data.",
    }
    _write_json(run_dir / "acquisition_baseline.json", acquisition_baseline)
    store.add_memory(
        operation_id, "LIMITATION", "UNAVAILABLE", acquisition_baseline,
        [snapshot["snapshot_id"] for snapshot in snapshots if snapshot["channel_id"] == next(item["channel_id"] for item in catalog if item["role"] == "OWNED")],
        captured_at,
        channel_id=next(item["channel_id"] for item in catalog if item["role"] == "OWNED"),
    )

    format_video_snapshots = [
        item for item in snapshots
        if item["channel_id"] == format_channel_id and item["entity_type"] == "VIDEO" and item["payload"] is not None
    ]
    gates = {
        "backup_verified": bool(backup.get("verified")),
        "migration_recorded": bool(migration.get("content_sha256")),
        "all_snapshot_schemas_valid": not snapshot_errors,
        "all_ledger_event_schemas_valid": not ledger_schema_errors,
        "coverage_schema_valid": not coverage_errors,
        "cohort_schema_valid": not cohort_errors,
        "format_reference_public_videos_at_least_20": len(format_video_snapshots) >= 20,
        "owned_public_catalog_reconciled": len([
            item for item in snapshots
            if item["channel_id"] == next(entry["channel_id"] for entry in catalog if entry["role"] == "OWNED")
            and item["entity_type"] == "VIDEO"
        ]) >= 20,
        "full_validated_exactly_4": coverage["levels"]["FULL_VALIDATED"] == 4,
        "openings_exactly_16": openings["counts"]["opening_records"] == 16,
        "opening_holdout_exactly_13": openings["counts"]["holdout_from_phase2"] == 13,
        "private_metrics_not_imputed": acquisition_baseline["economics"]["rpm"] is None and acquisition_baseline["qualified_ypp_progress"]["public_watch_hours"] is None,
        "external_api_cost_zero": acquisition_baseline["external_spend_usd"] == 0,
        "no_final_model_generated": not (run_dir / "channel_dna.json").exists(),
        "public_tab_failures_are_visible": all(item["error"]["message"] for item in public_tab_failures),
    }
    gate_passed = all(gates.values())
    store.set_status(operation_id, "AWAITING_REVIEW" if gate_passed else "FAILED", utc_now() if gate_passed else None)
    db_after = database_inventory(config.db_path)
    summary = {
        "schema_version": "1.0.0",
        "operation_id": operation_id,
        "status": "AWAITING_REVIEW" if gate_passed else "FAILED",
        "captured_at": captured_at,
        "snapshot_cache_hit": cache_hit,
        "catalog_channels": len(catalog),
        "snapshots": {
            "total": len(snapshots),
            "channel": sum(item["entity_type"] == "CHANNEL" for item in snapshots),
            "video": sum(item["entity_type"] == "VIDEO" for item in snapshots),
            "complete": sum(item["collection_status"] == "COMPLETE" for item in snapshots),
            "partial": sum(item["collection_status"] == "PARTIAL" for item in snapshots),
            "failed": sum(item["collection_status"] == "FAILED" for item in snapshots),
        },
        "coverage": coverage["levels"],
        "openings": openings["counts"],
        "cohorts": len(cohorts["cohorts"]),
        "gates": gates,
        "schema_errors": {
            "snapshots": snapshot_errors,
            "ledger": ledger_schema_errors,
            "coverage": coverage_errors,
            "cohorts": cohort_errors,
        },
        "cohort_build_error": cohort_error,
        "public_tab_failures": public_tab_failures,
        "database": {"integrity_check": db_after["integrity_check"], "counts": store.counts(operation_id)},
        "external_api_cost_usd": 0.0,
        "protected_actions_executed": [],
    }
    summary["integrity"] = {
        "manifest": (run_dir / "integrity_manifest.json").relative_to(ROOT).as_posix(),
        "algorithm": "SHA-256",
    }
    _write_json(run_dir / "phase3_summary.json", summary)
    _integrity_manifest(run_dir)
    return summary
