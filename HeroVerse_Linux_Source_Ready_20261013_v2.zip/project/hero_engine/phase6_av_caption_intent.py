"""Read a pinned literal caption plan; never schedule or approve captions.

The caller must supply the 51 PCM units already independently verified by A.
This adapter reopens metadata and planner bytes, never executes the planners or
reads/decodes audio. Container bounds are NOT observed lexical boundaries.
Its computed coverage describes captions only, never the full temporal union.
Consumers must pin this implementation and reopen dependencies at final build;
the returned object is not a stand-alone approval or serialized replay proof.
"""
from __future__ import annotations

import copy
from pathlib import Path
import re
import textwrap

from .phase6_narration_audio_inventory import _json

VERSION = "phase6-av-caption-intent-v1"
PLAN_BINDING = {
    "path": "output/qa/phase6/diagnostics/narration-caption-chunks-v2/3ddd6d1db0f753c02ea2fdf8.json",
    "sha256": "sha256:3ddd6d1db0f753c02ea2fdf8611c15962a01dc6bfa1cdb6287f5e2dd14f588f4",
}
STATUS = "EDITORIAL_CAPTION_INPUT_NOT_TIMED_OR_ADMITTED"
POLICY_VERSION = "phase6-caption-text-precheck-v1"
WHOLE = "WHOLE_UNIT_CONTAINER_BOUNDS_ONLY"
LEXICAL = "CALIBRATED_TEXT_RANGE_REQUIRED"
SOURCE = {
    "path": "output/qa/phase6/diagnostics/narration-continuous-listening-baseline-v1/ea4a48ffaf796765b0fba422/receipt.json",
    "sha256": "sha256:b99fcb0d5aa54d8860928a6d91165ec7b3a6ac685251954c967d3bc9fc42667a",
}
IMPLEMENTATION = {
    "path": "output/qa/phase6/diagnostics/plan_narration_caption_chunks_v2.py",
    "sha256": "sha256:f9e8d62556811d1c6c1fff001f698556a4b05e3a2729d2e17ae8e96b884fd042",
    "primitive_sha256": "sha256:d9d8a8c679a3ab5603b252b03399435adaef347766068c9a993a33c0994641f7",
}
PRIMITIVE = {
    "path": "output/qa/phase6/diagnostics/plan_narration_caption_chunks_v1.py",
    "sha256": IMPLEMENTATION["primitive_sha256"],
}
CHANGES = {
    "003": "Keep Name / Test / Choose progressive; no simultaneous whole-hook cue.",
    "016": "Keep fear attribution with the abandoned forecast; no isolated identity assertion.",
    "031": "Keep let pressure write your identity together; split parallel behavior clause.",
}
LIMITATIONS = [
    "No estimated word timestamps or global timing.",
    "Literal segmentation is not rendered legibility, perceptual audio or video approval.",
]
AUTHORITY = {key: False for key in (
    "retiming", "calibration", "quality", "render", "publication", "queue")}
TOP_FIELDS = set("authority changes chunked_unit_count cue_count cues implementation "
    "internal_alignment_cue_count limitations model_calls policy_version schema_version "
    "source status supersedes_editorial_proposal_only technical_cost_brl unit_count".split())
CUE_FIELDS = set("char_end char_start cue_id global_end_sample global_start_sample lines "
    "pcm_sha256 reason rendered_legibility_approved text timing_state unit_id "
    "unit_relative_end_sample unit_relative_start_sample wav_sha256".split())
UNIT_FIELDS = set("frame_count pcm_end_sample_exclusive pcm_sha256 pcm_start_sample "
                  "source_path text unit_id wav_sha256".split())


def _exact(value, keys, name):
    if not isinstance(value, dict) or set(value) != keys:
        raise ValueError(f"{name}: exact fields required")


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name}: exact integer >= {minimum} required")
    return value


def _binding(value):
    _exact(value, {"path", "sha256"}, "binding")
    if (not isinstance(value["sha256"], str)
            or not re.fullmatch(r"sha256:[a-f0-9]{64}", value["sha256"])):
        raise ValueError("binding: explicit prefixed SHA-256 required")
    name = value["path"]
    if (not isinstance(name, str) or not name or "\\" in name or ":" in name
            or Path(name).is_absolute() or any(p in ("", ".", "..") for p in name.split("/"))):
        raise PermissionError("binding: confined relative path required")


def _resident(root, name):
    # Do not resolve away a junction or hydrate a OneDrive placeholder.
    current = Path(root)
    for part in (None, *Path(name).parts):
        if part is not None:
            current = current / part
        info = current.lstat()
        if current.is_symlink() or getattr(info, "st_file_attributes", 0) & (0x400 | 0x1000 | 0x40000 | 0x400000):
            raise PermissionError("caption dependency must be resident and unlinked")
    if not current.is_file() or not 0 < current.stat().st_size <= 2_000_000:
        raise ValueError("caption dependency must be a bounded nonempty metadata file")


def read_caption_intent(reader, binding, units):
    """Recompose literal coverage using A-verified units, without global times.

    A supplied complete flag is not accepted. Returned whole-cue relative bounds
    remain the original [0, PCM frame_count), not onset/offset observations.
    Dependency rechecking here closes this call; A must recheck after later work.
    """
    _binding(binding)
    # LIMITED to the frozen reviewed editorial segmentation, not an editor for
    # any new hash-pinned candidate claiming the same planner/envelope labels.
    if binding != PLAN_BINDING:
        raise ValueError("only the exact frozen v2 caption-plan binding is supported")
    dependencies = {}

    def read(bound):
        _binding(bound)
        _resident(reader.root, bound["path"])
        raw = reader.read(bound["path"], bound["sha256"])
        dependencies[bound["path"]] = {**copy.deepcopy(bound), "size_bytes": len(raw)}
        return raw

    plan = _json(read(binding))
    _exact(plan, TOP_FIELDS, "caption plan")
    if (plan["schema_version"] != "2.0.0" or plan["status"] != STATUS
            or plan["policy_version"] != POLICY_VERSION
            or plan["source"] != SOURCE or plan["implementation"] != IMPLEMENTATION
            or plan["changes"] != CHANGES or plan["limitations"] != LIMITATIONS
            or plan["supersedes_editorial_proposal_only"] != "sha256:39a91821cb7c4bc1276d417b5a2e6be52102e0dbb9e0422379a4699b8f4d6c27"):
        raise ValueError("caption version, provenance or editorial envelope differs")
    _exact(plan["authority"], {"retiming", "quality", "render", "publication", "queue"}, "authority")
    if any(value is not False for value in plan["authority"].values()):
        raise PermissionError("literal caption plan cannot confer authority")
    for key in ("model_calls", "technical_cost_brl"):
        if _integer(plan[key], key) != 0:
            raise ValueError("caption reader requires zero model calls and cost")
    # These bytes establish lineage only. The literal checks below are independent
    # of generator labels; neither planner is imported or executed.
    read({key: IMPLEMENTATION[key] for key in ("path", "sha256")})
    read(PRIMITIVE)
    baseline = _json(read(SOURCE))
    source_units = baseline.get("unit_text_map")
    expected_ids = [f"narration-unit-{index:03d}" for index in range(1, 52)]
    for rows in (units, source_units):
        if (not isinstance(rows, list) or len(rows) != 51
                or any(not isinstance(row, dict) for row in rows)
                or [row.get("unit_id") for row in rows] != expected_ids):
            raise ValueError("exact ordered 51-unit population required")
    for actual, original in zip(units, source_units, strict=True):
        _exact(original, UNIT_FIELDS, "baseline unit")
        count = _integer(actual.get("frame_count"), "PCM frame count", 1)
        if (_integer(original["frame_count"], "baseline frame count", 1) != count
                or _integer(original["pcm_end_sample_exclusive"], "baseline PCM end", 1)
                - _integer(original["pcm_start_sample"], "baseline PCM start") != count):
            raise ValueError("PCM frame count differs from pinned baseline")
        for key in ("text", "pcm_sha256", "wav_sha256"):
            if not isinstance(actual.get(key), str) or actual[key] != original[key]:
                raise ValueError(f"A unit {key} differs from pinned baseline")
        if (actual.get("sha256") != original["wav_sha256"]
                or actual.get("path") != original["source_path"]):
            raise ValueError("A unit WAV identity/path differs from pinned baseline")
    if not isinstance(plan["cues"], list) or not plan["cues"]:
        raise ValueError("caption cues required")
    by_unit = {uid: [] for uid in expected_ids}
    observed_order = []
    for cue in plan["cues"]:
        _exact(cue, CUE_FIELDS, "caption cue")
        if not isinstance(cue["unit_id"], str) or cue["unit_id"] not in by_unit:
            raise ValueError("caption references unknown unit")
        by_unit[cue["unit_id"]].append(cue)
        observed_order.append(cue["cue_id"])
    expected_order, lexical, whole, lexical_units = [], [], [], []
    for index, unit in enumerate(units, 1):
        rows = by_unit[unit["unit_id"]]
        if not rows:
            raise ValueError("caption literal coverage missing unit")
        is_whole = len(rows) == 1
        if not is_whole:
            lexical_units.append(unit["unit_id"])
        cursor = 0
        for ordinal, cue in enumerate(rows, 1):
            expected_id = f"caption-{index:03d}-{ordinal:02d}"
            expected_order.append(expected_id)
            start = _integer(cue["char_start"], "caption char start")
            end = _integer(cue["char_end"], "caption char end", 1)
            text = cue["text"]
            if (cue["cue_id"] != expected_id or start != cursor
                    or not start < end <= len(unit["text"])
                    or not isinstance(text, str) or text != unit["text"][start:end]):
                raise ValueError("caption literal range, order, gap or identity differs")
            lines = textwrap.wrap(text, width=42, break_long_words=False, break_on_hyphens=False)
            if (cue["lines"] != lines or not 1 <= len(lines) <= 2
                    or max(map(len, lines)) > 42 or len(text.split()) > 12
                    or " ".join(lines) != text):
                raise ValueError("caption original line/word precheck differs")
            if (cue["wav_sha256"] != unit["wav_sha256"] or cue["pcm_sha256"] != unit["pcm_sha256"]):
                raise ValueError("caption PCM/WAV binding differs")
            if (cue["global_start_sample"] is not None or cue["global_end_sample"] is not None
                    or cue["rendered_legibility_approved"] is not False):
                raise ValueError("caption plan cannot invent global timing or legibility approval")
            reason = ("Whole utterance fits textual precheck." if is_whole else
                      "Preserve a coherent clause and literal copy; avoid oversized sentence caption.")
            if cue["timing_state"] != (WHOLE if is_whole else LEXICAL) or cue["reason"] != reason:
                raise ValueError("caption timing class must follow complete literal coverage")
            if is_whole:
                if (_integer(cue["unit_relative_start_sample"], "container start") != 0
                        or _integer(cue["unit_relative_end_sample"], "container end", 1) != unit["frame_count"]
                        or start != 0 or end != len(unit["text"])):
                    raise ValueError("whole caption must cover exact unit container")
                whole.append(copy.deepcopy(cue))
            else:
                if (cue["unit_relative_start_sample"] is not None
                        or cue["unit_relative_end_sample"] is not None):
                    raise ValueError("internal caption requires unmeasured null lexical times")
                lexical.append(copy.deepcopy(cue))
            cursor = end
            if ordinal < len(rows):
                if unit["text"][cursor:cursor + 1] != " ":
                    raise ValueError("caption boundary must preserve the literal separator")
                cursor += 1
        if cursor != len(unit["text"]):
            raise ValueError("caption literal coverage is truncated")
    if observed_order != expected_order:
        raise ValueError("caption order/duplication differs")
    counts = {"unit_count": len(units), "cue_count": len(expected_order),
              "chunked_unit_count": len(lexical_units), "internal_alignment_cue_count": len(lexical)}
    if any(_integer(plan[key], key) != count for key, count in counts.items()):
        raise ValueError("caption counts do not recompose")
    result = {
        "adapter_version": VERSION, "status": "LITERAL_CAPTION_INTENT_ONLY_NOT_TIMED_OR_ADMITTED",
        "policy_version": POLICY_VERSION, "source_binding": copy.deepcopy(binding),
        "source_unit_map_binding": copy.deepcopy(SOURCE),
        "literal_caption_coverage_complete": True, "ordered_unit_ids": expected_ids,
        "lexical_unit_ids": lexical_units, "lexical_ranges": lexical,
        "whole_unit_cues": whole, "cues": copy.deepcopy(plan["cues"]), **counts,
        "whole_unit_cue_count": len(whole), "authority": copy.deepcopy(AUTHORITY),
        "global_schedule_created": False, "calibrated_timing_available": False,
        "technical_cost_brl": 0, "model_calls": 0,
        "limitations": [*LIMITATIONS,
            "Caption coverage is not global visual/temporal scope completeness.",
            "The caller must independently verify PCM units; this adapter reads metadata only."],
    }
    # Reopen every dependency after validation, including the external plan pin.
    for item in list(dependencies.values()):
        raw = read({key: item[key] for key in ("path", "sha256")})
        if len(raw) != item["size_bytes"]:
            raise ValueError("caption dependency size changed during inspection")
    result["dependency_bindings"] = sorted(dependencies.values(), key=lambda row: row["path"])
    return result
