"""D-154 isolated editorial alternative; never grants production authority.

Unlike layered-hook-v3, the mechanism is an actual screen-space footer. No
glyph is attached to a physical card, and the old recipe is not reclassified.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .phase6_layered_hook_recipe import build_layered_hook_plan, canonical_sha
from .phase6_visual_recipe import _Region, _drawtext_filter, _place_copy

RECIPE_ID = "heroverse-take003-editorial-footer-v1"
TRANSFORM = {"width": 1536, "height": 864, "x": 192, "y": 0,
             "scale": 0.8, "crop": False, "temporal_warp": False}


def build_plan(take_plan, treatment_plan, allocation, style_bible, *, font: Path) -> dict[str, Any]:
    # Reuse only upstream lock validation, not the old physical-label layout.
    upstream = build_layered_hook_plan(take_plan, treatment_plan, allocation, style_bible)
    primary = _place_copy(
        role="editorial-mechanism", source="NAME / TEST / CHOOSE", font_path=font,
        preferred_size=84, region=_Region(154, 875, 1612, 118), color="0xE8EDF2",
        filename="mechanism.txt", allow_wrap=False)
    secondary = _place_copy(
        role="channel-system", source="SYSTEM: TRUTH / RESPONSIBILITY / TODAY", font_path=font,
        preferred_size=54, region=_Region(166, 100, 620, 150, horizontal="left"),
        color="0xE8EDF2", filename="system.txt", allow_wrap=True)
    primary.update(start_frame=0, end_frame_exclusive=150)
    secondary.update(start_frame=75, end_frame_exclusive=150)
    plan = {
        "schema_version": "1.0.0", "recipe_id": RECIPE_ID,
        "scope": "ISOLATED_EDITORIAL_HOOK_PROTOTYPE_NOT_PRODUCTION",
        "status": "CANDIDATE_NOT_APPROVED",
        **{key: upstream[key] for key in (
            "channel_id", "video_id", "take_id", "start_ms", "end_ms", "duration_ms",
            "source_bindings", "source_asset", "narration", "voice_policy", "style_contract")},
        "source_transform": dict(TRANSFORM),
        "primary_semantics": "ORDERED_SPOKEN_MECHANISM_IN_SEPARATE_EDITORIAL_FOOTER",
        "secondary_semantics": "CHANNEL_IDENTITY_SYSTEM_NOT_STEP_MAPPING",
        "physical_card_labels": False, "one_to_one_system_card_mapping_allowed": False,
        "overlays": [primary, secondary],
        "panels": [
            {"role": "footer-rule", "x": 154, "y": 868, "width": 1612, "height": 4,
             "color": "0xD7A94A", "start_frame": 0, "end_frame_exclusive": 150},
            {"role": "system-backing", "x": 154, "y": 95, "width": 637, "height": 160,
             "color": "0x081827", "start_frame": 75, "end_frame_exclusive": 150},
            {"role": "system-rule", "x": 154, "y": 95, "width": 637, "height": 4,
             "color": "0xD7A94A", "start_frame": 75, "end_frame_exclusive": 150}],
        "evaluation_limits": [
            "visual-only prototype; no audio/narrative/release approval",
            "source-region identity proves preservation, not intrinsic motion quality",
            "geometric separation does not approve semantics or publicity rights"],
        "authority": {"production_authorized": False, "release_authorized": False,
                      "publication_authorized": False, "human_review_claimed": False,
                      "technical_cost_brl": 0},
    }
    plan["plan_id"] = "editorial-hook-" + canonical_sha(plan).removeprefix("sha256:")[:24]
    return plan


def compile_filters(plan: dict, *, font: Path, texts: dict[str, Path]) -> str:
    if plan["recipe_id"] != RECIPE_ID or plan["source_transform"] != TRANSFORM:
        raise ValueError("editorial recipe identity/transform mismatch")
    # Retained FFV1 input already contains the locked cinematic grade. Never
    # apply that grade a second time or change its 150-frame source interval.
    filters = ["format=rgb24", "scale=1536:864:flags=lanczos", "format=rgb24",
               "pad=1920:1080:192:0:color=0x081827", "setsar=1",
               "settb=expr=1/30", "setpts=N"]
    for panel in plan["panels"]:
        filters.append(
            f"drawbox=x={panel['x']}:y={panel['y']}:w={panel['width']}:h={panel['height']}:"
            f"color={panel['color']}:t=fill:enable='gte(n,{panel['start_frame']})*lt(n,{panel['end_frame_exclusive']})'")
    for overlay in plan["overlays"]:
        filters.append(_drawtext_filter(font, texts[overlay["filename"]], overlay)
                       + f":enable='gte(n,{overlay['start_frame']})*lt(n,{overlay['end_frame_exclusive']})'")
    filters.append("format=bgr0")
    return ",".join(filters)


def verify_geometry(plan, retained_geometry):
    """All 450 retained source hulls must stay clear of both overlay regions."""
    frames = retained_geometry["frames"]
    if len(frames) != 150 or [f["frame_number"] for f in frames] != list(range(150)):
        raise ValueError("source geometry requires exact 150 ordered frames")
    rectangles = [dict(left=p["x"], top=p["y"], right=p["x"]+p["width"],
                       bottom=p["y"]+p["height"]) for p in plan["panels"]]
    rectangles += [o["bounds"] for o in plan["overlays"]]
    min_vertical_clearance = float("inf")
    for frame in frames:
        if [c["card_index"] for c in frame["cards"]] != [1, 2, 3]:
            raise ValueError("source card identity mismatch")
        for card in frame["cards"]:
            points = [(192 + .8*x, .8*y) for x, y in card["hull_vertices"]]
            xs, ys = zip(*points)
            if not all(192 <= x <= 1728 and 0 <= y <= 864 for x, y in points):
                raise ValueError("source hull leaves uncropped source viewport")
            for rect in rectangles:
                dx = max(rect["left"]-max(xs), min(xs)-rect["right"])
                dy = max(rect["top"]-max(ys), min(ys)-rect["bottom"])
                if max(dx, dy) < 8:
                    raise ValueError("editorial overlay touches a physical card")
            min_vertical_clearance = min(min_vertical_clearance, 868-max(ys))
    return {"status": "PASS_GEOMETRIC_SEPARATION_ONLY", "frames": 150, "hulls": 450,
            "minimum_card_to_footer_pixels": min_vertical_clearance,
            "semantics_approved": False, "motion_approved": False}
