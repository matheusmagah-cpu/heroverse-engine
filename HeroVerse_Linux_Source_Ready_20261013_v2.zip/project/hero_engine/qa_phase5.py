from __future__ import annotations

import hashlib
import copy
import json
import math
import os
import re
import shutil
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"
GATES = [
    "STRATEGY", "CHANNEL_DNA", "NARRATIVE", "HOOK", "SEMANTIC_COHERENCE", "STYLE",
    "CONTINUITY", "CHARACTERS", "MOVEMENT", "LEGIBILITY", "AUDIO", "TECHNICAL",
    "RIGHTS", "PUBLICITY", "EDITORIAL_ORIGINALITY", "CHANNEL_IDENTITY", "COST", "PUBLICATION",
]
DEFECTS = [
    "FLICKER", "OBJECT_DEFORMATION", "FACE_VARIATION", "HAND_DEFECT", "CHARACTER_IDENTITY_DRIFT",
    "BACKGROUND_PULSING", "IMPOSSIBLE_MOTION", "UNINTENDED_CAMERA_INSTABILITY", "INCOHERENT_PHYSICS",
    "DISCONTINUOUS_CUT", "LIP_SYNC_ERROR", "DUPLICATE_FRAMES", "GHOSTING", "ARTIFICIAL_INTERPOLATION",
    "INCONSISTENT_RESOLUTION", "COMPRESSION_ARTIFACT", "STYLE_DRIFT", "AUDIO_CLIPPING", "LOUDNESS_OUT_OF_RANGE",
]


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True)


def _probe(path: Path) -> dict[str, Any]:
    result = _run(
        [
            FFPROBE, "-v", "error", "-show_entries",
            "format=duration,size,bit_rate:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels,bit_rate",
            "-of", "json", str(path),
        ]
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    return json.loads(result.stdout)


def _loudness(path: Path) -> dict[str, float]:
    result = _run(
        [
            FFMPEG, "-hide_banner", "-nostats", "-i", str(path), "-af",
            "loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json", "-f", "null", os.devnull,
        ]
    )
    matches = re.findall(r"\{\s*\"input_i\".*?\}", result.stderr, re.S)
    if not matches:
        raise RuntimeError("FFmpeg loudness JSON was not found")
    payload = json.loads(matches[-1])
    return {
        "integrated_lufs": float(payload["input_i"]),
        "true_peak_dbtp": float(payload["input_tp"]),
        "lra_lu": float(payload["input_lra"]),
        "threshold_lufs": float(payload["input_thresh"]),
    }


def _black_freeze_scan(path: Path) -> dict[str, Any]:
    result = _run(
        [
            FFMPEG, "-hide_banner", "-nostats", "-i", str(path), "-vf",
            "blackdetect=d=0.20:pix_th=0.08,freezedetect=n=-45dB:d=0.75", "-an", "-f", "null", os.devnull,
        ]
    )
    black = [float(value) for value in re.findall(r"black_duration:([0-9.]+)", result.stderr)]
    freeze = [float(value) for value in re.findall(r"lavfi\.freezedetect\.freeze_duration: ([0-9.]+)", result.stderr)]
    return {
        "maximum_black_seconds": max(black, default=0.0),
        "black_event_count": len(black),
        "maximum_freeze_seconds": max(freeze, default=0.0),
        "freeze_event_count": len(freeze),
        "command_return_code": result.returncode,
    }


def _actual_take_windows(plan: dict[str, Any], render_manifest: dict[str, Any]) -> list[dict[str, Any]]:
    rendered = render_manifest.get("segment_timeline") or []
    if len(rendered) != len(plan["takes"]):
        raise ValueError("render manifest does not contain one measured timeline record per take")
    windows: list[dict[str, Any]] = []
    for planned, actual in zip(plan["takes"], rendered):
        if planned["take_id"] != actual["take_id"]:
            raise ValueError("render segment order does not match TakePlan")
        windows.append(
            {
                "take_id": planned["take_id"],
                "start_ms": float(actual["actual_start_ms"]),
                "end_ms": float(actual["actual_end_ms"]),
            }
        )
    return windows


def _signal_scan(
    path: Path,
    output_path: Path,
    plan: dict[str, Any],
    render_manifest: dict[str, Any],
    *,
    canonical_evidence: bool = False,
) -> dict[str, Any]:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result = _run(
        [
            FFMPEG, "-hide_banner", "-nostats", "-filter_threads", "1", "-i", str(path), "-vf",
            "fps=2:round=down,signalstats,metadata=print" + (":file=-" if canonical_evidence else ""),
            "-an", "-f", "null", os.devnull,
        ]
    )
    if result.returncode:
        return {"status": "UNAVAILABLE", "reason": result.stderr[-1000:]}
    text = result.stdout if canonical_evidence else result.stderr
    if not canonical_evidence:
        # Legacy callers retain their original diagnostic-file contract.
        output_path.write_text(text, encoding="utf-8")
    else:
        # FFmpeg's stderr contains process addresses and elapsed/speed values.
        # Preserve it, but never use those diagnostics as a measurement identity.
        raw = result.stderr.encode("utf-8")
        archive = output_path.parent / "raw-diagnostics" / (hashlib.sha256(raw).hexdigest() + ".log")
        archive.parent.mkdir(parents=True, exist_ok=True)
        try:
            with archive.open("xb") as handle:
                handle.write(raw)
        except FileExistsError:
            if archive.read_bytes() != raw:
                raise PermissionError("signal diagnostic archive collision")
    frames: list[tuple[float, float, float]] = []
    current_time: float | None = None
    yavg: float | None = None
    satavg: float | None = None
    for line in text.splitlines():
        time_match = re.search(r"pts_time:([0-9.]+)", line)
        if time_match:
            if current_time is not None and yavg is not None and satavg is not None:
                frames.append((current_time, yavg, satavg))
            current_time = float(time_match.group(1))
            yavg = None
            satavg = None
        elif "lavfi.signalstats.YAVG=" in line:
            yavg = float(line.rsplit("=", 1)[1])
        elif "lavfi.signalstats.SATAVG=" in line:
            satavg = float(line.rsplit("=", 1)[1])
    if current_time is not None and yavg is not None and satavg is not None:
        frames.append((current_time, yavg, satavg))

    if canonical_evidence:
        if not frames or any(not all(math.isfinite(value) for value in frame) for frame in frames):
            raise PermissionError("signal metadata is empty or non-finite")
        raw = text.encode("utf-8")
        try:
            with output_path.open("xb") as handle:
                handle.write(raw)
        except FileExistsError:
            if output_path.read_bytes() != raw:
                raise PermissionError("immutable signal metadata differs from recomputation")

    actual_windows = _actual_take_windows(plan, render_manifest)

    def take_at(seconds: float) -> str | None:
        millis = seconds * 1000
        for take in actual_windows:
            if take["start_ms"] <= millis < take["end_ms"]:
                return str(take["take_id"])
        return None

    sample_interval_seconds = 0.5
    planned_boundaries = [float(item["end_ms"]) / 1000.0 for item in actual_windows[:-1]]

    def boundary_adjacent(start: float, end: float) -> bool:
        # The fps filter assigns samples to a fixed grid. A content frame chosen
        # around an edit can be timestamped up to one sample step away; events in
        # that explicit uncertainty band are planned-cut evidence, not intra-take.
        return any(
            abs(start - boundary) <= sample_interval_seconds
            or abs(end - boundary) <= sample_interval_seconds
            for boundary in planned_boundaries
        )

    all_same_take_events = [
        (abs(right[1] - left[1]), left[0], right[0], take_at(left[0]))
        for left, right in zip(frames, frames[1:])
        if take_at(left[0]) == take_at(right[0])
    ]
    luminance_events = [
        event for event in all_same_take_events
        if not boundary_adjacent(event[1], event[2])
    ]
    luminance_deltas = [event[0] for event in luminance_events]
    hard_transition_threshold = 45.0
    hard_transitions = [event for event in luminance_events if event[0] > hard_transition_threshold]
    saturation = [frame[2] for frame in frames]
    p95 = statistics.quantiles(luminance_deltas, n=20)[-1] if len(luminance_deltas) >= 20 else max(luminance_deltas, default=0.0)
    return {
        "status": "MEASURED",
        "sample_count": len(frames),
        "within_take_luminance_delta_p95": round(p95, 6),
        "within_take_luminance_delta_max": round(max(luminance_deltas, default=0.0), 6),
        "largest_within_take_events": [
            {"delta": round(delta, 6), "from_seconds": start, "to_seconds": end, "take_id": take_id}
            for delta, start, end, take_id in sorted(luminance_events, reverse=True)[:12]
        ],
        "hard_transition_threshold": hard_transition_threshold,
        "hard_transition_count": len(hard_transitions),
        "hard_transition_events": [
            {"delta": round(delta, 6), "from_seconds": start, "to_seconds": end, "take_id": take_id}
            for delta, start, end, take_id in sorted(hard_transitions, reverse=True)
        ],
        "planned_boundary_exclusion_seconds": sample_interval_seconds,
        "planned_boundary_adjacent_event_count": len(all_same_take_events) - len(luminance_events),
        "saturation_average": round(statistics.mean(saturation), 6) if saturation else None,
        "saturation_standard_deviation": round(statistics.pstdev(saturation), 6) if len(saturation) > 1 else 0.0,
        "flicker_threshold_p95": 15.0,
    }


def _trigrams(text: str) -> set[tuple[str, str, str]]:
    words = re.findall(r"[a-z']+", text.lower())
    return set(zip(words, words[1:], words[2:]))


def _originality_scan(root: Path, script: dict[str, Any]) -> dict[str, Any]:
    target = _trigrams(script["full_text"])
    maximum = 0.0
    maximum_source = None
    comparisons = 0
    for path in (root / "data" / "gold_standard").glob("*/transcript.reviewed.json"):
        data = _read_json(path)
        source_text = " ".join(str(item) for item in data.values()) if isinstance(data, dict) else str(data)
        source = _trigrams(source_text)
        if not target:
            ratio = 0.0
        else:
            ratio = len(target & source) / len(target)
        comparisons += 1
        if ratio > maximum:
            maximum = ratio
            maximum_source = path.as_posix()
    return {"comparison_count": comparisons, "maximum_target_trigram_overlap": round(maximum, 6), "maximum_source": maximum_source, "threshold": 0.02}


def _rights_scan(manifest: dict[str, Any], plan: dict[str, Any]) -> dict[str, Any]:
    assets = {item["asset_id"]: item for item in manifest["assets"]}
    failures: list[str] = []
    verified: list[str] = []
    for take in plan["takes"]:
        asset_id_match = re.search(r"asset-(?:commons|owned)-[a-z0-9-]+", take["asset_origin"])
        asset_id = asset_id_match.group(0) if asset_id_match else "UNKNOWN"
        asset = assets.get(asset_id)
        if not asset:
            failures.append(f"{take['take_id']}: asset missing from manifest")
            continue
        local_path = Path(asset["uri"])
        observed_hash = _sha256(local_path) if local_path.is_file() else "MISSING"
        if observed_hash != asset["content_hash"]:
            failures.append(f"{take['take_id']}: hash mismatch for {asset_id}")
        elif not asset.get("production_eligible"):
            failures.append(f"{take['take_id']}: {asset_id} is not production eligible")
        else:
            verified.append(asset_id)
    return {"passed": not failures, "verified_asset_ids": sorted(set(verified)), "failures": failures}


def _timeline_scan(plan: dict[str, Any], render_manifest: dict[str, Any], measured_duration_ms: int) -> dict[str, Any]:
    contiguous = all(left["end_ms"] == right["start_ms"] for left, right in zip(plan["takes"], plan["takes"][1:]))
    origins = [take["asset_origin"].split("#t=", 1)[0] for take in plan["takes"]]
    no_adjacent_repeat = all(left != right for left, right in zip(origins, origins[1:]))
    expected = int(plan["takes"][-1]["end_ms"])
    timing = render_manifest["measurements"]
    return {
        "contiguous": contiguous,
        "no_adjacent_source_repeat": no_adjacent_repeat,
        "expected_duration_ms": expected,
        "measured_duration_ms": measured_duration_ms,
        "absolute_duration_error_ms": abs(expected - measured_duration_ms),
        "frame_locked": timing["maximum_take_duration_error_ms"] <= (1000 / timing["output_fps"]) / 2,
        "maximum_take_duration_error_ms": timing["maximum_take_duration_error_ms"],
        "maximum_cumulative_drift_ms": timing["maximum_cumulative_drift_ms"],
    }


def _create_visual_evidence(render: Path, evidence_dir: Path) -> dict[str, Any]:
    evidence_dir.mkdir(parents=True, exist_ok=True)
    measured_duration = float(_probe(render)["format"]["duration"])
    hook_paths = []
    sample_points = [("000p1", 0.1), ("001p2", 1.2), ("003p2", 3.2), ("007p0", 7.0), ("015", 15), ("030", 30), ("120", 120), ("final", max(0.1, measured_duration - 1.0))]
    for label, second in sample_points:
        if second >= measured_duration:
            continue
        destination = evidence_dir / f"frame-{label}.jpg"
        selector = f"select=gte(t\\,{second:.3f})"
        result = _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(render), "-vf", selector, "-frames:v", "1", "-q:v", "2", str(destination)])
        if result.returncode:
            raise RuntimeError(result.stderr[-1000:])
        hook_paths.append(destination)
    for stale in evidence_dir.glob("contact-sheet-*.jpg"):
        stale.unlink()
    contact_pattern = evidence_dir / "contact-sheet-%02d.jpg"
    result = _run(
        [
            FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(render), "-vf",
            "fps=1/8,scale=480:270,tile=4x4:padding=4:margin=4:color=0x081827", "-q:v", "2", str(contact_pattern),
        ]
    )
    if result.returncode:
        raise RuntimeError(result.stderr[-1000:])
    pages = sorted(evidence_dir.glob("contact-sheet-*.jpg"))
    if not pages:
        raise RuntimeError("contact sheet generation produced no page")
    return {"contact_sheet": str(pages[0].resolve()), "contact_sheet_pages": [str(page.resolve()) for page in pages], "hook_frames": [str(path.resolve()) for path in hook_paths]}


def _audio_static_inputs(root: Path, package: Path) -> dict[str, Any]:
    """Reopen exact source/voice proofs; never treat source PASS as final QA."""
    from .asset_quality_phase5 import verify_audio_static_asset_admission
    from .phase6_asset_residency import validate_phase6_rights_evidence
    from .render_phase5 import verify_static_voice_reuse
    from .phase6_render_contract import PALETTE_QP1_SEGMENT_RENDERER
    root = root.resolve()
    paths = [package / name for name in ('take_plan.json', 'asset_manifest.json',
             'channel_style_bible.json', 'audio/voice_render_manifest.json')]
    before = {path: _sha256(path) for path in paths}
    plan, catalogue, bible, voice = [_read_json(path) for path in paths]
    if (plan.get('format_pack_id') != 'fp-narrated-reflection-static'
            or plan.get('render_profile') != PALETTE_QP1_SEGMENT_RENDERER
            or plan.get('style_bible_id') != bible.get('style_bible_id')
            or len(catalogue.get('assets', [])) != 1 or not plan.get('takes')):
        raise PermissionError('static QA format/source/bible identity differs')
    asset = catalogue['assets'][0]
    admission = verify_audio_static_asset_admission(root, asset)
    rights_path = Path(asset['rights_evidence_uri']).resolve()
    before[rights_path] = _sha256(rights_path)
    rights = validate_phase6_rights_evidence(root, asset, _read_json(rights_path),
                                            media_path=Path(asset['uri']))
    expected_origin = str(Path(asset['uri'])) + '#still=' + asset['content_hash']
    expected_start = 0
    for take in plan['takes']:
        if (take['asset_origin'] != expected_origin or take['media_type'] != 'GENERATED_IMAGE'
                or take['start_ms'] != expected_start or take['end_ms'] <= expected_start
                or take.get('on_screen_text') or take.get('transition_in') or take.get('transition_out')
                or take['rights'] != {'status':'OWNED','evidence_ref':asset['rights_evidence_uri']}):
            raise PermissionError('static QA contains changed composition, rights, timing or overlays')
        expected_start = take['end_ms']
    voice_bindings = verify_static_voice_reuse(root, plan, paths[3], expected_voice_hash=before[paths[3]])
    before.update(voice_bindings)
    for path, expected in before.items():
        if _sha256(path) != expected:
            raise PermissionError('static QA input changed while observed')
    return {'status':'PASS_SOURCE_INPUT_SCOPE', 'admission':admission, 'rights':rights,
        'voice_render_id':voice['voice_render_id'], 'take_count':len(plan['takes']),
        'timeline_duration_ms':expected_start, 'intentional_static_hold':True,
        'frame_clock_source':'Measured original narration; fixed visual has no source clock',
        'inputs':[{'path':str(path),'sha256':digest} for path,digest in before.items()],
        'final_video_quality_authorized':False, 'publication_authorized':False}


def verify_rest_music_source(root: Path, *, package_relative: Path,
                             recipe_binding: dict[str, str],
                             source_binding: dict[str, str]) -> dict[str, Any]:
    """Musical source consumer, explicitly distinct from spoken intelligibility."""
    import soundfile as sf
    import numpy as np
    from .creative_direction import read_christian_rest_music_inputs
    root = root.resolve()
    inputs = read_christian_rest_music_inputs(root, package_relative=package_relative,
                                            recipe_binding=recipe_binding)
    package = (root / package_relative).resolve()
    receipt_path = package / 'audio/rest_music_receipt.json'
    if (not isinstance(source_binding, dict) or set(source_binding) != {'path', 'sha256'}
            or Path(source_binding['path']).resolve() != receipt_path
            or _sha256(receipt_path) != source_binding['sha256']):
        raise PermissionError('rest source requires exact external receipt anchor')
    raw = receipt_path.read_bytes()
    receipt = json.loads(raw.decode('utf-8-sig'))
    media = package / 'audio/original-rest-music.wav'
    producer = root / 'hero_engine/render_creative_v3_phase5.py'
    if any(not path.resolve().is_relative_to(root) for path in (media, producer, receipt_path)):
        raise PermissionError('rest source escaped root through alias')
    music = receipt.get('music', {})
    recipe = inputs['recipe']
    if (receipt.get('version') != 'christian-rest-music-source-v1'
            or receipt.get('status') != 'COMPLETE'
            or receipt.get('inputs') != inputs['inputs']
            or receipt.get('canonical_recipe_hash') != inputs['canonical_recipe_hash']
            or receipt.get('producer') != {'path': str(producer), 'sha256': _sha256(producer)}
            or receipt.get('authority') != {'quality': False, 'render': False, 'publication': False}
            or music.get('generator') != ('HeroVerseEditorialRest@v3' if 'editorial' in recipe else 'HeroVerseProceduralPad@rest-v2'
                if recipe['recipe_version']=='heroverse-christian-rest-instrumental-v2'
                else 'HeroVerseProceduralPad@rest-v1')
            or music.get('path') != str(media)
            or music.get('content_hash') != _sha256(media)
            or music.get('recipe_hash') != inputs['canonical_recipe_hash']
            or music.get('recipe_id') != recipe['recipe_id']
            or music.get('scope') != 'FULL_DURATION_PROTOTYPE'
            or music.get('duration_ms') != recipe['duration_ms']
            or music.get('parameters') != recipe['sound_design']
            or music.get('rights_status') != 'OWNED_PROCEDURAL'
            or music.get('external_cost_usd') != 0
            or any(music.get(key) is not False for key in
                   ('clipping', 'quality_authorized', 'render_authorized', 'publication_authorized'))):
        raise PermissionError('rest music source identity, completeness or authority diverged')
    info = sf.info(media)
    if (info.samplerate != 48000 or info.channels != 2 or info.subtype != 'PCM_16'
            or info.frames != math.ceil(recipe['duration_ms'] * 48000 / 1000)):
        raise PermissionError('rest music PCM population or clock diverged')
    peak = max(float(np.max(np.abs(block))) for block in sf.blocks(
        media, blocksize=48000 * 4, dtype='float32', always_2d=True))
    if peak >= .98 or round(peak, 6) != music.get('peak_linear'):
        raise PermissionError('rest music peak observation diverged')
    opening = None
    if 'editorial' in recipe:
        opening = read_rest_opening(root, package_relative=package_relative,
            recipe_binding=recipe_binding, opening_binding=receipt.get('opening'))
        from .render_creative_v3_phase5 import _rest_opening_resample_command
        command = _rest_opening_resample_command(Path(opening['voice']['path']))
        resampler = music.get('opening_resampler', {})
        if resampler != {'path':command[0],'sha256':_sha256(Path(command[0])),
                'argv':command,'input_sha256':opening['voice']['content_hash'],
                'output_samples':opening['voice']['samples']*2}:
            raise PermissionError('editorial resampler origins or actual clock diverged')
        opening['inputs'].append({'path':command[0],'sha256':resampler['sha256']})
    elif 'opening' in receipt:
        raise PermissionError('instrumental receipt cannot contain an editorial opening')
    if (receipt_path.read_bytes() != raw or _sha256(media) != music['content_hash']
            or any(_sha256(Path(row['path'])) != row['sha256'] for row in inputs['inputs'])):
        raise PermissionError('rest music source changed before QA consumption')
    return {'status': 'AUTHENTICATED_COMPLETE_REST_MUSIC_SOURCE_NOT_RELEASE',
        'binding': dict(source_binding), 'music': music, 'recipe': recipe,
        'inputs': inputs['inputs'] + [receipt['producer'],
            {'path': str(media), 'sha256': music['content_hash']}] + (opening['inputs'] if opening else []),
        **({'opening':opening} if opening else {}),
        'voice_required': opening is not None, 'quality_authorized': False,
        'render_authorized': False, 'publication_authorized': False}


def read_rest_opening(root: Path, *, package_relative: Path, recipe_binding: dict,
                      opening_binding: dict) -> dict:
    """Authenticate real speech and its current text/origins; not intelligibility QA.

    This reader is called by the existing complete-source consumer. A musical
    receipt cannot conceal a new narration or reuse the historical pilot.
    """
    import soundfile as sf
    import numpy as np
    from .creative_direction import read_christian_rest_music_inputs
    from .voice_phase5 import espeak_binding_identity, hash_local_espeak_data, inventory_local_espeak_dlls
    root = root.resolve()
    source = read_christian_rest_music_inputs(root, package_relative=package_relative,
                                             recipe_binding=recipe_binding)
    recipe = source['recipe']
    if 'editorial' not in recipe:
        raise PermissionError('instrumental recipe has no spoken opening')
    directory = (root/package_relative/'audio/opening').resolve()
    path = directory/'receipt.json'
    if (not isinstance(opening_binding, dict) or set(opening_binding) != {'path','sha256'}
            or Path(opening_binding['path']).resolve() != path
            or not directory.is_relative_to(root/'output/production')
            or _sha256(path) != opening_binding['sha256']):
        raise PermissionError('editorial opening requires exact current receipt anchor')
    raw = path.read_bytes(); receipt = json.loads(raw.decode('utf-8-sig'))
    voice = receipt.get('voice',{}); editorial = recipe['editorial']
    media = directory/'voice.wav'
    if (receipt.get('version') != 'heroverse-rest-opening-v1'
            or receipt.get('recipe_binding') != recipe_binding or receipt.get('editorial') != editorial
            or receipt.get('authority') != {'quality':False,'render':False,'publication':False}
            or voice.get('path') != str(media) or voice.get('content_hash') != _sha256(media)
            or voice.get('text') != editorial['full_text']
            or voice.get('voice_id') != editorial['voice_id'] or voice.get('speed') != editorial['speed']
            or voice.get('clipping') is not False):
        raise PermissionError('editorial opening text, source, voice or authority diverged')
    expected_paths = [root/'models/kokoro/kokoro-v1.0.fp16.onnx',
                      root/'models/kokoro/voices-v1.0.bin',root/'hero_engine/voice_phase5.py']
    if receipt.get('origins') != [{'path':str(p),'sha256':_sha256(p)} for p in expected_paths]:
        raise PermissionError('editorial voice model/producer origins diverged')
    identity = espeak_binding_identity(receipt['espeak'])
    library, data = Path(identity['library_path']), Path(identity['data_path'])
    if (identity['library_hash'] != _sha256(library)
            or identity['data_hash'] != hash_local_espeak_data(data)
            or identity['directory_dlls'] != inventory_local_espeak_dlls(library)):
        raise PermissionError('editorial phonemizer origins diverged')
    info = sf.info(media)
    samples, rate = sf.read(media, dtype='float32')
    peak = float(np.max(np.abs(samples))) if len(samples) else 1.0
    if (info.channels != 1 or info.subtype != 'PCM_16' or rate != voice['sample_rate']
            or rate != 24000 or len(samples) != voice['samples']
            or not 0 < info.duration <= 360 or info.duration*1000 >= recipe['duration_ms']
            or round(info.duration*1000) != voice['duration_ms'] or not 0 < peak < .98):
        raise PermissionError('editorial voice PCM or measured timing diverged')
    rows = [{'path':str(p),'sha256':_sha256(p)} for p in [path, media, *expected_paths, library]]
    if path.read_bytes() != raw or _sha256(media) != voice['content_hash']:
        raise PermissionError('editorial opening changed during consumption')
    reused=receipt.get('reused_from')
    predecessor_inputs=[]
    if reused is not None:
        if (recipe['recipe_version']!='heroverse-christian-rest-editorial-v4'
                or not isinstance(reused,dict)
                or set(reused)!={'package_relative','recipe_binding','opening_binding'}
                or not isinstance(reused['package_relative'],str)
                or (root/reused['package_relative']).resolve()==(root/package_relative).resolve()):
            raise PermissionError('editorial voice reuse has no distinct explicit predecessor')
        previous=read_christian_rest_music_inputs(root,package_relative=Path(reused['package_relative']),
            recipe_binding=reused['recipe_binding'])
        if (previous['recipe']['recipe_version']!='heroverse-christian-rest-editorial-v3'
                or previous['recipe']['editorial']!=editorial):
            raise PermissionError('reused editorial differs from immutable predecessor')
        predecessor=read_rest_opening(root,package_relative=Path(reused['package_relative']),
            recipe_binding=reused['recipe_binding'],opening_binding=reused['opening_binding'])
        expected_voice=dict(predecessor['voice'],path=str(media))
        if (voice!=expected_voice or receipt['origins']!=json.loads(
                Path(reused['opening_binding']['path']).read_bytes())['origins']):
            raise PermissionError('reused voice bytes, timing or origins differ')
        predecessor_inputs=previous['inputs']+predecessor['inputs']
    elif 'reused_at' in receipt:
        raise PermissionError('editorial copy timestamp without predecessor')
    if path.read_bytes()!=raw or _sha256(media)!=voice['content_hash']:
        raise PermissionError('editorial opening changed during predecessor authentication')
    return {'status':'AUTHENTICATED_EDITORIAL_OPENING_NOT_FINAL_QA','voice':voice,
        'editorial':editorial,'binding':dict(opening_binding),'inputs':rows+predecessor_inputs,
        **({'reused_from':copy.deepcopy(reused)} if reused is not None else {}),
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}


def _rest_music_visual(root: Path, package: Path, media: Path, bindings: dict,
                       duration_ms: int) -> dict[str, Any]:
    """All-frame static transfer; no narrated plan, sampling or anatomy claims."""
    import numpy as np
    from PIL import Image
    from .render_phase5 import _rest_render_inputs, _frame_count_for_duration_ms
    from .procedural_infographics_phase5 import read_audio_static_source
    from .phase5_autonomous_quality import _decoded_static_frames
    from .phase6_visual_metrics import spatial_measurements, colour_measurements
    _,asset,anchors=_rest_render_inputs(root,package,bindings)
    evidence=_read_json(Path(asset['rights_evidence_uri']))
    ref=evidence['composition_manifest']
    source=read_audio_static_source(root,Path(ref['path']),expected_sha256=ref['sha256'])
    reference_path=Path(source['produced']['raster'])
    with Image.open(reference_path) as image:reference=np.asarray(image.convert('RGB')).copy()
    left,top,right,bottom=source['produced']['raster_bounds']
    region=(slice(max(0,top-6),min(1080,bottom+6)),slice(max(0,left-6),min(1920,right+6)))
    expected=_frame_count_for_duration_ms(duration_ms)
    if not 0<duration_ms<=14400000:raise PermissionError('instrumental visual clock outside recipe scope')
    before=_sha256(media);count=0;cache={};chain=hashlib.sha256()
    for frame in _decoded_static_frames(media,expected_frames=expected):
        if frame.shape!=reference.shape or frame.dtype!=np.uint8:
            raise PermissionError('instrumental decoded frame dimensions/type differ')
        digest=hashlib.sha256(frame.tobytes()).digest();chain.update(digest);count+=1
        if digest not in cache:
            # Bounded private cache; every distinct frame is measured even after
            # eviction. Extrema are retained, never a representative-frame PASS.
            value=(spatial_measurements(reference[region],frame[region])['minimum_local_ssim'],
                colour_measurements(reference,frame)['maximum_delta_e'])
            if len(cache)>=64:cache.clear()
            cache[digest]=value
        text,colour=cache[digest]
        minimum=text if count==1 else min(minimum,text)
        maximum=colour if count==1 else max(maximum,colour)
    if (count!=expected or _sha256(media)!=before
            or any(_sha256(path)!=digest for path,digest in anchors.items())):
        raise PermissionError('instrumental visual population or inputs changed')
    return {'expected_frames':expected,'observed_frames':count,'decoded_frame_hash_chain':chain.hexdigest(),
        'minimum_text_local_ssim':minimum,'maximum_colour_delta_e':maximum,
        'reference':{'path':str(reference_path),'sha256':asset['content_hash']},
        'method':'ALL_DECODED_FRAMES_OWNED_STATIC_RGB_NOT_MOTION_OR_ANATOMY'}


# This is the independently executed selected-source observation, not an
# arbitrary caller threshold or a universal claim about listener comfort.
REST_MUSIC_REFERENCE_SHA256='sha256:5fe54921933654a9dc264846a949868516438a66c278e77f0abd56ef5859d133'


def _rest_music_quality_decision(observed: dict, reference: dict, controls: dict,
                                 profile: dict, duration_ms: int, *, opening: dict | None = None) -> dict:
    """Reconstruct decisions, not consume a supplied PASS dictionary."""
    aesthetic=observed['aesthetics'];visual=observed['visual'];loudness=observed['final_loudness']
    frames=math.ceil(duration_ms*48)
    start=opening['voice']['samples']*2 if opening else 0
    cursor=start
    context_policy=aesthetic.get('window_context_policy')
    if context_policy not in (None,'REAL_MUSICAL_TAIL_CONTEXT_UNIQUE_COVERAGE_V1'):
        raise PermissionError('unknown musical observation context policy')
    if opening and aesthetic.get('observation_start_frame')!=start:
        raise PermissionError('musical body does not follow the exact measured opening')
    for row in aesthetic['windows']:
        if context_policy is not None:
            context_start=(cursor if min(frames,cursor+480000)-cursor==480000
                           else max(start,min(frames,cursor+480000)-480000))
            if (type(row.get('context_start_frame')) is not int
                    or type(row.get('context_end_frame')) is not int
                    or row['context_start_frame']!=context_start
                    or row['context_end_frame']!=min(frames,cursor+480000)):
                raise PermissionError('musical context differs from real in-bound coverage')
        elif 'context_start_frame' in row or 'context_end_frame' in row:
            raise PermissionError('musical context has no explicit policy')
        if (row['start_frame']!=cursor or row['end_frame']!=min(frames,cursor+480000)
                or set(row['scores'])!={'CE','CU','PC','PQ'}
                or any(type(v) not in (int,float) or not math.isfinite(v) for v in row['scores'].values())):
            raise PermissionError('musical qualification window population diverged')
        cursor=row['end_frame']
    if not aesthetic['windows'] or cursor!=frames or aesthetic['observed_frames']!=frames-start or aesthetic['full_duration_observed'] is not True:
        raise PermissionError('partial music assessment cannot qualify the long track')
    means={axis:sum(row['scores'][axis]*(row['end_frame']-row['start_frame'])
        for row in aesthetic['windows'])/(frames-start) for axis in ('CE','CU','PC','PQ')}
    if means!=aesthetic['axis_mean']:raise PermissionError('music score aggregation diverged')
    # Measured minimum of the independently selected sample, not an invented
    # universal score. A strong mean cannot conceal a regressed window.
    floors={axis:min(row['scores'][axis] for row in reference['windows']) for axis in ('CE','PQ')}
    minimum=profile['technical_minimums'];level=minimum['loudness_lufs']
    expected_video_frames=duration_ms*30//1000
    if visual['expected_frames']!=expected_video_frames or visual['observed_frames']!=expected_video_frames:
        raise PermissionError('partial visual observation cannot qualify final delivery')
    gates={
        'FULL_MUSIC_CLOCK':True,
        'PREDICTED_QUALITY_NONREGRESSION':all(row['scores'][k]>=floors[k]
            for row in aesthetic['windows'] for k in floors),
        'FINAL_LOUDNESS':math.isfinite(loudness['integrated_lufs']) and abs(loudness['integrated_lufs']-level['target'])<=level['tolerance'],
        'FINAL_TRUE_PEAK':math.isfinite(loudness['true_peak_dbtp']) and loudness['true_peak_dbtp']<=minimum['true_peak_dbtp'],
        'ALL_FRAME_TEXT_FIDELITY':1-visual['minimum_text_local_ssim']<=controls['limits']['text_error'],
        'ALL_FRAME_COLOUR_FIDELITY':visual['maximum_colour_delta_e']<=controls['limits']['colour_error']}
    speech_measurement=None
    if opening:
        from .phase5_autonomous_quality import _words, _edit_distance, rest_opening_captions
        speech=observed['speech'];transcript=speech['transcript']
        if (speech['opening_frames']!=start or speech['opening_binding']!=opening['binding']
                or transcript.get('provider')!='faster-whisper-base.en-cpu-int8'
                or transcript.get('local_files_only') is not True or transcript.get('cpu_threads')!=1
                or not transcript.get('model_bindings')
                or speech['captions_text']!=rest_opening_captions(transcript,opening_frames=start)):
            raise PermissionError('editorial speech observation/captions/origins differ')
        words=_words(opening['editorial']['full_text']);distance=_edit_distance(words,_words(transcript['text']))
        # Exactly the existing static spoken-word threshold, not a new waived
        # instrumental score or manually declared semantic/audio PASS.
        speech_measurement={'reference_words':len(words),'word_errors':distance,
            'word_error_rate':distance/len(words),'threshold':0.08}
        gates['SPOKEN_INTELLIGIBILITY']=distance/len(words)<=0.08 and transcript.get('language')=='en'
        gates['MEASURED_OPENING_CAPTIONS']=True
    return {'gates':{name:'PASS' if passed else 'FAIL' for name,passed in gates.items()},
        'status':('PASS_EDITORIAL_REST_DELIVERY_SCOPE' if opening else 'PASS_INSTRUMENTAL_DELIVERY_SCOPE') if all(gates.values()) else
            ('FAIL_EDITORIAL_REST_DELIVERY_SCOPE' if opening else 'FAIL_INSTRUMENTAL_DELIVERY_SCOPE'),
        **({'speech_measurement':speech_measurement} if opening else {}),
        'reference_axis_minima':floors,'observed_axis_means':means,
        'scope':('Original spoken opening intelligibility, measured captions and complete musical body nonregression' if opening else 'Original instrumental delivery fidelity and full-duration predicted quality nonregression'),
        'limitations':['Learned ratings are uncertain, not audience outcomes',
            'No medical, fatigue-free, sleep, monetization or retention guarantee'],
        'publication_authorized':False}


def qualify_rest_music_delivery(root: Path, *, package_relative: Path, music_bindings: dict,
                                render_binding: dict, visual_controls_binding: dict,
                                aesthetic_reference_binding: dict) -> dict:
    """Existing QA consumer: real final video, complete musical source and exact references."""
    from .render_phase5 import read_rest_music_render
    from .publication_package_phase5 import read_audio_static_packaging
    from .standard_qualification_phase5 import read_audio_static_codec_controls
    from .phase5_autonomous_quality import measure_music_aesthetics, MUSIC_MODEL_SHA256
    from .phase6_asset_residency import _write_immutable
    root=root.resolve();package=(root/package_relative).resolve()
    path=package/'qa/instrumental_quality_receipt.json'
    if path.exists():
        return read_rest_music_qualification(root,package_relative=package_relative,
            music_bindings=music_bindings,render_binding=render_binding,
            qualification_binding={'path':str(path),'sha256':_sha256(path)},
            visual_controls_binding=visual_controls_binding,aesthetic_reference_binding=aesthetic_reference_binding)
    reference_path=Path(aesthetic_reference_binding['path']).resolve()
    if (not reference_path.is_relative_to(root/'output/runtime/gestor-central/maintenance-runs')
            or aesthetic_reference_binding['sha256']!=REST_MUSIC_REFERENCE_SHA256
            or _sha256(reference_path)!=REST_MUSIC_REFERENCE_SHA256):
        raise PermissionError('selected music reference is not the independently anchored observation')
    reference=_read_json(reference_path)
    if (reference['status']!='MEASURED_MUSIC_AESTHETICS'
            or reference['model']['weights_sha256']!='sha256:'+MUSIC_MODEL_SHA256):
        raise PermissionError('selected musical reference model differs')
    rendered=read_rest_music_render(root,package_relative=package_relative,
        music_bindings=music_bindings,manifest_binding=render_binding)
    packaging=read_audio_static_packaging(root,package_relative=package_relative,music_bindings=music_bindings)
    source=verify_rest_music_source(root,package_relative=package_relative,
        recipe_binding=music_bindings['recipe'],source_binding=music_bindings['source'])
    controls=read_audio_static_codec_controls(root,package,binding=visual_controls_binding,music_bindings=music_bindings)
    profile_path=root/'config/production_quality_profiles/standard-v1.json'
    profile_hash=_sha256(profile_path);profile=_read_json(profile_path)
    duration=source['music']['duration_ms'];video=Path(rendered['manifest']['output']['path'])
    opening=source.get('opening')
    aesthetic=measure_music_aesthetics(root,Path(source['music']['path']),
        expected_media_hash=source['music']['content_hash'],expected_duration_ms=duration,
        **({'music_start_frame':opening['voice']['samples']*2} if opening else {}))
    from .production_capacity import _HEAVY_TASK_SLOT,measure_local_resources,ResourceWait
    if not _HEAVY_TASK_SLOT.acquire(blocking=False):raise ResourceWait({'causes':['OWN_HEAVY_TASK_ACTIVE'],'next_check_seconds':60})
    try:
        samples=[measure_local_resources(root),measure_local_resources(root)]
        if any(s['available_ram_bytes']<1536*1024**2 or s['output_free_bytes']<12*1024**3 for s in samples):
            raise ResourceWait({'causes':['INSTRUMENTAL_QUALIFICATION_CAPACITY'],'samples':samples,'next_check_seconds':60})
        observed={'aesthetics':aesthetic,'final_loudness':_loudness(video),
            'visual':_rest_music_visual(root,package,video,music_bindings,duration)}
        if opening:
            from .phase5_autonomous_quality import measure_rest_opening_intelligibility
            path.parent.mkdir(parents=True,exist_ok=True)
            observed['speech']=measure_rest_opening_intelligibility(root,package,video,source=source)
    finally:_HEAVY_TASK_SLOT.release()
    decision=_rest_music_quality_decision(observed,reference,controls,profile,duration,opening=opening)
    receipt={'version':'christian-rest-final-qualification-v1','music_bindings':music_bindings,
        'render_binding':render_binding,'visual_controls_binding':visual_controls_binding,
        'aesthetic_reference_binding':aesthetic_reference_binding,
        'profile_binding':{'path':str(profile_path),'sha256':profile_hash},
        'producer':{'path':str(Path(__file__).resolve()),'sha256':_sha256(Path(__file__))},
        'duration_ms':duration,'observed':observed,'decision':decision,
        'created_at':datetime.now(timezone.utc).isoformat(),
        'authority':{'publication':False,'operational_activation':False}}
    # Native readers re-open the same exact inputs before any receipt is published.
    if (read_rest_music_render(root,package_relative=package_relative,music_bindings=music_bindings,manifest_binding=render_binding)!=rendered
            or read_audio_static_packaging(root,package_relative=package_relative,music_bindings=music_bindings)!=packaging
            or _sha256(reference_path)!=REST_MUSIC_REFERENCE_SHA256 or _sha256(profile_path)!=profile_hash):
        raise PermissionError('instrumental qualification inputs changed during observation')
    _write_immutable(path,receipt)
    if opening:
        captions=package/'qa/opening-captions.srt'
        with captions.open('xb') as stream:stream.write(observed['speech']['captions_text'].encode('utf-8'))
    return read_rest_music_qualification(root,package_relative=package_relative,music_bindings=music_bindings,
        render_binding=render_binding,qualification_binding={'path':str(path),'sha256':_sha256(path)},
        visual_controls_binding=visual_controls_binding,aesthetic_reference_binding=aesthetic_reference_binding)


def read_rest_music_qualification(root: Path, *, package_relative: Path, music_bindings: dict,
                                 render_binding: dict, qualification_binding: dict,
                                 visual_controls_binding: dict, aesthetic_reference_binding: dict) -> dict:
    """Read completed observation without a second inference/decode or caller PASS."""
    from .render_phase5 import read_rest_music_render
    from .standard_qualification_phase5 import read_audio_static_codec_controls
    from .phase5_autonomous_quality import MUSIC_MODEL_SHA256
    root=root.resolve();package=(root/package_relative).resolve()
    path=package/'qa/instrumental_quality_receipt.json'
    if (set(qualification_binding)!={'path','sha256'} or Path(qualification_binding['path']).resolve()!=path
            or not path.is_relative_to(root/'output/production') or _sha256(path)!=qualification_binding['sha256']):
        raise PermissionError('final musical qualification receipt anchor differs')
    raw=path.read_bytes();receipt=json.loads(raw.decode('utf-8-sig'))
    if (receipt.get('version')!='christian-rest-final-qualification-v1'
            or receipt.get('music_bindings')!=music_bindings or receipt.get('render_binding')!=render_binding
            or receipt.get('visual_controls_binding')!=visual_controls_binding
            or receipt.get('aesthetic_reference_binding')!=aesthetic_reference_binding
            or receipt.get('authority')!={'publication':False,'operational_activation':False}
            or receipt.get('producer')!={'path':str(Path(__file__).resolve()),'sha256':_sha256(Path(__file__))}):
        raise PermissionError('musical qualification identity/producer/authority differs')
    reference_path=Path(aesthetic_reference_binding['path']).resolve()
    if (not reference_path.is_relative_to(root/'output/runtime/gestor-central/maintenance-runs')
            or aesthetic_reference_binding['sha256']!=REST_MUSIC_REFERENCE_SHA256
            or _sha256(reference_path)!=REST_MUSIC_REFERENCE_SHA256):
        raise PermissionError('musical qualification reference differs')
    reference=_read_json(reference_path)
    source=verify_rest_music_source(root,package_relative=package_relative,
        recipe_binding=music_bindings['recipe'],source_binding=music_bindings['source'])
    rendered=read_rest_music_render(root,package_relative=package_relative,music_bindings=music_bindings,manifest_binding=render_binding)
    controls=read_audio_static_codec_controls(root,package,binding=visual_controls_binding,music_bindings=music_bindings)
    profile_path=root/'config/production_quality_profiles/standard-v1.json'
    if receipt['profile_binding']!={'path':str(profile_path),'sha256':_sha256(profile_path)}:
        raise PermissionError('musical qualification quality profile changed')
    observed=receipt['observed'];aesthetic=observed['aesthetics']
    if (receipt['duration_ms']!=source['music']['duration_ms']
            or aesthetic['media_hash']!=source['music']['content_hash']
            or aesthetic['duration_ms']!=receipt['duration_ms']
            or aesthetic['model']['weights_sha256']!='sha256:'+MUSIC_MODEL_SHA256
            or reference['model']['weights_sha256']!=aesthetic['model']['weights_sha256']
            or observed['visual']['reference']!= {'path':_read_json(Path(music_bindings['asset']['path']))['uri'],
                'sha256':_read_json(Path(music_bindings['asset']['path']))['content_hash']}):
        raise PermissionError('musical qualification observation source/model/reference differs')
    for key in ('weights','config'):
        if _sha256(Path(aesthetic['model'][key]))!=aesthetic['model'][key+'_sha256']:
            raise PermissionError('musical qualification model bytes changed')
    opening=source.get('opening')
    if opening:
        speech=observed['speech']
        if speech['media']!={'path':rendered['manifest']['output']['path'],
                              'sha256':rendered['manifest']['output']['content_hash']}:
            raise PermissionError('speech assessment does not observe current final mix')
        for row in speech['transcript']['model_bindings']:
            if _sha256(Path(row['path']))!='sha256:'+row['sha256']:
                raise PermissionError('speech observer model bytes changed')
        captions=package/'qa/opening-captions.srt'
        if captions.read_bytes()!=speech['captions_text'].encode('utf-8'):
            raise PermissionError('measured opening captions differ from final observation')
    expected=_rest_music_quality_decision(observed,reference,controls,_read_json(profile_path),receipt['duration_ms'],opening=opening)
    if receipt['decision']!=expected or path.read_bytes()!=raw:
        raise PermissionError('musical qualification decision or receipt changed')
    return {'status':expected['status'],'decision':expected,'binding':dict(qualification_binding),
        'render':rendered,'source':source,'publication_authorized':False,'operational_activation_authorized':False}


def _audio_static_editorial(root: Path, package: Path) -> dict[str, Any]:
    """Measure audible contract traceability; not a prediction of hook strength."""
    names = ('take_plan.json','narrative_script.json','editorial_brief.json',
             'creative_direction_decision.json','channel_style_bible.json','audio/voice_render_manifest.json')
    paths = [package/name for name in names]
    before = {path:_sha256(path) for path in paths}
    plan,script,brief,creative,bible,voice = [_read_json(path) for path in paths]
    words = lambda text: re.findall(r"[\w'’]+", str(text).casefold())
    source = voice.get('narrative_script',{})
    expected = source.get('sha256')
    script_bound = isinstance(expected,str) and before[paths[1]] == expected
    schema = _read_json(root/'schemas/narrative_script.schema.json')
    schema_ok = not list(Draft202012Validator(schema).iter_errors(script))
    sections = script.get('sections',[])
    hooks = script.get('hook_windows',[])
    takes = plan.get('takes',[])
    full = words(script.get('full_text',''))
    spoken = words(' '.join(take.get('narration','') for take in takes))
    hooks_ok = schema_ok and len(hooks)==4
    observations=[]
    # Native measured-voice hook_timing_gate authenticates the first three
    # slots only. The fourth script window is an editorial duration estimate,
    # not authority to shorten/re-synthesise the already measured narration.
    for window,(start,end) in zip(hooks[:3],((0,1000),(1000,3000),(3000,8000))):
        selected = [take for take in takes if take['start_ms']>=start and take['end_ms']<=end]
        coverage = bool(selected) and selected[0]['start_ms']==start and selected[-1]['end_ms']==end
        matches = words(' '.join(take['narration'] for take in selected)) == words(window.get('narration',''))
        passed = (window.get('start_ms')==start and window.get('end_ms')==end
                  and coverage and matches and bool(words(window.get('narration',''))))
        hooks_ok = hooks_ok and passed
        observations.append({'start_ms':start,'end_ms':end,'covered':coverage,'spoken_text_matches':matches})
    expansion = {'declared_end_ms':hooks[3].get('end_ms') if len(hooks)==4 else None,
                 'measured_end_ms':None,'spoken_text_matches':False}
    if len(hooks)==4:
        expansion_words=words(hooks[3].get('narration',''))
        accumulated=[]
        for take in takes[3:]:
            accumulated.extend(words(take['narration']))
            if len(accumulated)>=len(expansion_words):
                expansion.update(measured_end_ms=take['end_ms'],spoken_text_matches=accumulated==expansion_words)
                break
    roles = [section.get('role') for section in sections]
    required = ['TITLE_ALIGNED_STAKE','PERSONAL_STAKES','MECHANISM_AND_PROOF','REVERSAL_AND_ACTION','PROMISE_RESOLUTION']
    roles_ok = all(role in roles for role in required) and roles[-1:] == ['PROMISE_RESOLUTION']
    if roles_ok:
        roles_ok = [roles.index(role) for role in required] == sorted(roles.index(role) for role in required)
    reconstructed = words(' '.join([row.get('narration','') for row in hooks[:3]]
                                  +[row.get('text','') for row in sections]))
    narrative_ok = schema_ok and script_bound and bool(full) and reconstructed==full and roles_ok
    coherence_ok = narrative_ok and spoken==full and expansion['spoken_text_matches'] and script.get('brief_id')==brief.get('brief_id')
    identity_ok = (coherence_ok and brief.get('niche_fit',{}).get('status')=='PASS'
        and script.get('language')=='en-US'
        and all(value.get('channel_id')==script.get('channel_id') for value in (brief,creative,bible))
        and creative.get('brief_id')==brief.get('brief_id')
        and creative.get('decision_id')==plan.get('creative_direction_decision_id')
        and bible.get('style_bible_id')==plan.get('style_bible_id')
        and creative.get('channel_dna_version')==bible.get('channel_dna_version')
        and creative.get('selected_format_pack',{}).get('format_pack_id')==plan.get('format_pack_id')=='fp-narrated-reflection-static'
        and creative.get('selected_format_pack',{}).get('version')==plan.get('format_pack_version'))
    if any(_sha256(path)!=expected for path,expected in before.items()):
        raise PermissionError('Static editorial inputs changed during observation')
    return {'hook_pass':bool(hooks_ok and script_bound),'narrative_pass':bool(narrative_ok),
        'semantic_pass':bool(coherence_ok),'identity_pass':bool(identity_ok),
        'schema_pass':schema_ok,'script_matches_measured_voice':script_bound,
        'section_roles':roles,'hook_windows':observations,'spoken_word_count':len(spoken),
        'opening_expansion':expansion,
        'script_word_count':len(full),'creative_brief_matches_current':creative.get('brief_id')==brief.get('brief_id'),
        'inputs':[{'path':str(path),'sha256':digest} for path,digest in before.items()],
        'scope':'Authenticated narrative/identity and audible timing contract, not market retention or theological truth',
        'publication_authorized':False}


def run_phase5_quality_gates(root: Path, *, created_at: str | None = None,
        package_relative: Path | None = None, inputs_only: bool = False,
        asr_receipt_binding: dict[str, str] | None = None,
        visual_controls_binding: dict[str, str] | None = None,
        render_execution_binding: dict[str, str] | None = None,
        music_recipe_binding: dict[str, str] | None = None,
        music_aesthetics: bool = False,
        music_source_binding: dict[str, str] | None = None,
        music_render_binding: dict[str, str] | None = None,
        music_asset_binding: dict[str, str] | None = None,
        music_reference_binding: dict[str, str] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    if package_relative is not None:
        offered = Path(package_relative)
        package_dir = (root / offered).resolve()
        if (offered.is_absolute() or '..' in offered.parts
                or not package_dir.is_relative_to((root / 'output/production').resolve())):
            raise PermissionError('QA package escaped the production root')
    if type(music_aesthetics) is not bool or (music_aesthetics and music_recipe_binding is None):
        raise PermissionError('music assessment requires an explicit instrumental source scope')
    if (music_render_binding is not None or music_asset_binding is not None) and music_recipe_binding is None:
        raise PermissionError('instrumental render observation requires explicit current music inputs')
    if music_reference_binding is not None:
        if (inputs_only or music_recipe_binding is None or music_source_binding is None
                or music_render_binding is None or music_asset_binding is None
                or visual_controls_binding is None or asr_receipt_binding or render_execution_binding):
            raise PermissionError('final musical qualification needs actual delivery and independent reference/codec controls')
        result=qualify_rest_music_delivery(root,package_relative=package_relative,
            music_bindings={'recipe':music_recipe_binding,'source':music_source_binding,'asset':music_asset_binding},
            render_binding=music_render_binding,visual_controls_binding=visual_controls_binding,
            aesthetic_reference_binding=music_reference_binding)
        return result,_read_json(Path(result['binding']['path']))['observed']
    if music_recipe_binding is not None or music_source_binding is not None:
        if (package_relative is None or music_recipe_binding is None
                or music_source_binding is None or any((asr_receipt_binding,
                    visual_controls_binding, render_execution_binding))):
            raise PermissionError('rest source inspection is explicit and cannot substitute final QA')
        if ((inputs_only and (music_render_binding is not None or music_asset_binding is not None))
                or (not inputs_only and (music_render_binding is None or music_asset_binding is None))):
            raise PermissionError('instrumental inputs and actual render observations are distinct anchored scopes')
        musical_inputs = verify_rest_music_source(root, package_relative=package_relative,
            recipe_binding=music_recipe_binding, source_binding=music_source_binding)
        if musical_inputs['voice_required'] and (not inputs_only or music_aesthetics):
            raise PermissionError('editorial source requires spoken and musical delivery qualification, not instrumental-only QA')
        if music_aesthetics:
            from .phase5_autonomous_quality import measure_music_aesthetics
            musical_inputs['aesthetics'] = measure_music_aesthetics(root,
                Path(musical_inputs['music']['path']),
                expected_media_hash=musical_inputs['music']['content_hash'],
                expected_duration_ms=musical_inputs['music']['duration_ms'])
        if not inputs_only:
            from .render_phase5 import read_rest_music_render
            from .publication_package_phase5 import read_audio_static_packaging
            bindings={'recipe':music_recipe_binding,'source':music_source_binding,'asset':music_asset_binding}
            rendered=read_rest_music_render(root,package_relative=package_relative,
                music_bindings=bindings,manifest_binding=music_render_binding)
            packaging=read_audio_static_packaging(root,package_relative=package_relative,music_bindings=bindings)
            video=Path(rendered['manifest']['output']['path'])
            from .production_capacity import _HEAVY_TASK_SLOT,measure_local_resources,ResourceWait
            if not _HEAVY_TASK_SLOT.acquire(blocking=False):
                raise ResourceWait({'causes':['OWN_HEAVY_TASK_ACTIVE'],'next_check_seconds':60})
            try:
                samples=[measure_local_resources(root),measure_local_resources(root)]
                if any(row['available_ram_bytes']<1536*1024**2 or row['output_free_bytes']<12*1024**3 for row in samples):
                    raise ResourceWait({'causes':['INSTRUMENTAL_QA_CAPACITY'],'samples':samples,'next_check_seconds':60})
                final_loudness=_loudness(video)
            finally:_HEAVY_TASK_SLOT.release()
            if read_rest_music_render(root,package_relative=package_relative,
                    music_bindings=bindings,manifest_binding=music_render_binding)!=rendered:
                raise PermissionError('instrumental render changed during QA')
            if read_audio_static_packaging(root,package_relative=package_relative,music_bindings=bindings)!=packaging:
                raise PermissionError('instrumental packaging changed during QA')
            musical_inputs.update(render=rendered,packaging=packaging,
                final_loudness=final_loudness,render_binding=music_render_binding)
            return {'status':'MEASURED_INSTRUMENTAL_DELIVERY_NOT_RELEASE',
                'publication_eligible':False,'final_video_quality_authorized':False,
                'created_at':timestamp,
                'limitation':'Measured instrumental delivery; independent final visual and music qualification remain required.'},musical_inputs
        return {'status': 'PASS_MUSICAL_SOURCE_INPUT_SCOPE', 'publication_eligible': False,
            'final_video_quality_authorized': False, 'created_at': timestamp}, musical_inputs
    plan = _read_json(package_dir / 'take_plan.json')
    static_audio = plan.get('format_pack_id') == 'fp-narrated-reflection-static'
    static_inputs = _audio_static_inputs(root, package_dir) if static_audio else None
    static_packaging = None
    if static_audio and (package_dir/'packaging/static_packaging_receipt.json').exists():
        from .publication_package_phase5 import read_audio_static_packaging
        static_packaging=read_audio_static_packaging(root,package_relative=package_dir.relative_to(root.resolve()))
    static_controls = None
    if visual_controls_binding is not None:
        if not static_audio:raise PermissionError('Static codec controls cannot approve the legacy format')
        from .standard_qualification_phase5 import read_audio_static_codec_controls
        static_controls=read_audio_static_codec_controls(root,package_dir,binding=visual_controls_binding)
    if inputs_only:
        if not static_audio:
            raise PermissionError('Input-only inspection is explicit to the static audio Pack')
        return {'status':'PASS_SOURCE_INPUT_SCOPE','publication_eligible':False,
                'final_video_quality_authorized':False,'created_at':timestamp}, static_inputs
    render_manifest = _read_json(package_dir / "render_manifest.json")
    render = Path(render_manifest["output"]["path"])
    render_hash_before = None
    if static_audio:
        render = render.resolve()
        if (not render.is_relative_to(root.resolve())
                or any(render_manifest.get(key) != plan.get(key) for key in
                       ('take_plan_id','style_bible_id','format_pack_id','format_pack_version','video_id'))
                or render_manifest.get('voice_render_id') != static_inputs['voice_render_id']):
            raise PermissionError('static QA final media belongs to another package/version')
        render_hash_before = _sha256(render)
        if render_manifest['output'].get('content_hash') != render_hash_before:
            raise PermissionError('static QA final media hash differs')
    static_execution=None
    if render_execution_binding is not None:
        if not static_audio:raise PermissionError('Static execution cannot approve legacy media')
        from .standard_qualification_phase5 import verify_audio_static_execution
        static_execution=verify_audio_static_execution(root,package_dir,render,binding=render_execution_binding)
    plan = _read_json(package_dir / "take_plan.json")
    script = _read_json(package_dir / "narrative_script.json")
    brief = _read_json(package_dir / "editorial_brief.json")
    creative = _read_json(package_dir / "creative_direction_decision.json")
    bible = _read_json(package_dir / "channel_style_bible.json")
    asset_manifest = _read_json(package_dir / "asset_manifest.json")
    voice = _read_json(package_dir / "audio" / "voice_render_manifest.json")
    probe = _probe(render)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    duration_ms = round(float(probe["format"]["duration"]) * 1000)
    bitrate = int(probe["format"].get("bit_rate") or 0)
    fps_n, fps_d = video["r_frame_rate"].split("/", 1)
    fps = float(fps_n) / float(fps_d)
    loudness = _loudness(render)
    black_freeze = _black_freeze_scan(render)
    signal = _signal_scan(render, package_dir / "qa" / "signalstats.txt", plan, render_manifest)
    originality = _originality_scan(root, script)
    rights = _rights_scan(asset_manifest, plan)
    timeline = _timeline_scan(plan, render_manifest, duration_ms)
    visual_evidence = _create_visual_evidence(render, package_dir / "qa" / "frames")
    hook_timing_pass = voice["hook_timing_gate"] == "PASS" and all(item["fits_timeline_slot"] for item in voice["takes"][:3])
    technical_pass = (
        video["codec_name"] == "h264" and audio["codec_name"] == "aac"
        and int(video["width"]) == 1920 and int(video["height"]) == 1080
        and math.isclose(fps, 30.0, abs_tol=0.01)
        and timeline["absolute_duration_error_ms"] <= 150
        and timeline["frame_locked"]
        and timeline["maximum_cumulative_drift_ms"] <= (1000 / fps) / 2
        and black_freeze["maximum_black_seconds"] <= 0.20
        and (static_audio or black_freeze["maximum_freeze_seconds"] <= 0.75)
    )
    audio_technical_pass = -18.0 <= loudness["integrated_lufs"] <= -14.0 and loudness["true_peak_dbtp"] <= -1.0
    intelligibility = None
    static_visual = None
    if static_audio:
        from .phase5_autonomous_quality import measure_audio_static_intelligibility, audio_static_technical_pass
        audio_technical_pass = audio_static_technical_pass(loudness)
        intelligibility = measure_audio_static_intelligibility(root, package_dir, render,
            expected_media_hash='sha256:'+render_hash_before.removeprefix('sha256:'),
            receipt_binding=asr_receipt_binding)
        from .phase5_autonomous_quality import measure_audio_static_visual
        static_visual = measure_audio_static_visual(root, package_dir, render,
            expected_media_hash=render_hash_before)
    flicker_pass = signal.get("status") == "MEASURED" and signal["within_take_luminance_delta_p95"] <= signal["flicker_threshold_p95"]
    discontinuous_cut_pass = signal.get("status") == "MEASURED" and signal["hard_transition_count"] == 0
    originality_pass = originality["comparison_count"] >= 4 and originality["maximum_target_trigram_overlap"] <= originality["threshold"]
    cost_pass = render_manifest["external_cost_usd"] == 0 and plan["total_cost"]["external"] == 0
    if static_audio:
        # A static image has no absent limb/face, scene physics or intended
        # camera motion to review. It still requires decoded fidelity, text,
        # audio, timing and policy; no release is granted by non-applicability.
        rights = {'passed':static_inputs['rights']['status']=='PASS',
                  'verified_asset_ids':render_manifest['source_asset_ids'],'failures':[]}

    word_count = len(re.findall(r"\b[\w'’–-]+\b", script["full_text"]))
    hook_durations = [round(item["duration_ms"] / 1000, 3) for item in voice["takes"][:3]]
    hook_description = (
        'Measured original narration slots: ' + ', '.join(f'{value}s' for value in hook_durations)
        + '; audible promise/intelligibility still require their independent automatic evidence'
        if static_audio else
        f"timing passed at {hook_durations[0]}s, {hook_durations[1]}s and {hook_durations[2]}s inside 0–1/1–3/3–8; strength and clarity require independent sequential viewing"
    )
    gate_statuses = {
        "STRATEGY": ("PASS", ["approved Phase 4 archetype and Phase 5 controlled-pilot command"], ["output/modeling/phase4/channel-model-v1/channel_model.json", "policy_decision.json"]),
        "CHANNEL_DNA": ("PASS", ["creative decision is tied to exact ChannelDNA version"], ["creative_direction_decision.json", "channel_style_bible.json"]),
        "NARRATIVE": ("PASS", [f"original {word_count}-word script contains the required functional roles, a named decision framework and bounded claims"], ["narrative_script.json", "editorial_brief.json"]),
        "HOOK": ("NEEDS_REVIEW", [hook_description], ["creative-v2/audio/voice_render_manifest.json", visual_evidence["hook_frames"][0], visual_evidence["hook_frames"][1], visual_evidence["hook_frames"][2]]),
        "SEMANTIC_COHERENCE": ("NEEDS_REVIEW", ["every take has a declared semantic relation; visual truthfulness requires independent review"], ["take_plan.json", visual_evidence["contact_sheet"]]),
        "STYLE": ("NEEDS_REVIEW", ["locked grade and typography were applied; perceived consistency requires independent review"], ["channel_style_bible.json", visual_evidence["contact_sheet"]]),
        "CONTINUITY": (
            "NEEDS_REVIEW" if discontinuous_cut_pass else "FAIL",
            [f"timeline contiguous={timeline['contiguous']}; no adjacent source repeat={timeline['no_adjacent_source_repeat']}; frame-locked={timeline['frame_locked']}; unplanned hard transitions={signal.get('hard_transition_count')}; spatial/temporal continuity still requires independent review"],
            ["take_plan.json", "render_manifest.json", "qa/technical_measurements.json", visual_evidence["contact_sheet"]],
        ),
        "CHARACTERS": ("NOT_APPLICABLE", ["no recurring character is specified in this clip-based FormatPack"], ["channel_style_bible.json"]),
        "MOVEMENT": ("NEEDS_REVIEW", ["freeze/flicker automation ran; impossible motion and intentional camera behavior need visual review"], ["qa/technical_measurements.json", visual_evidence["contact_sheet"]]),
        "LEGIBILITY": ("NEEDS_REVIEW", ["renderer uses locked font, keyword-led layouts and an 8% safe-area contract; full-video visual confirmation pending"], ["hero_engine/render_creative_v2_phase5.py", visual_evidence["hook_frames"][0]]),
        "AUDIO": ("NEEDS_REVIEW" if audio_technical_pass else "FAIL", [f"measured {loudness['integrated_lufs']} LUFS and {loudness['true_peak_dbtp']} dBTP; pronunciation/emotion/mix review pending"], ["qa/technical_measurements.json", "audio/voice_render_manifest.json"]),
        "TECHNICAL": ("PASS" if technical_pass else "FAIL", [f"{video['codec_name']}/{audio['codec_name']} 1920x1080 {fps:.3f}fps; duration error {timeline['absolute_duration_error_ms']}ms; maximum cumulative segment drift {timeline['maximum_cumulative_drift_ms']}ms"], ["render_manifest.json", "qa/technical_measurements.json"]),
        "RIGHTS": ("PASS" if rights["passed"] else "FAIL", [f"{len(rights['verified_asset_ids'])} used assets matched local hashes and eligible rights states"], ["asset_manifest.json", "attribution.txt", "qa/technical_measurements.json"]),
        "PUBLICITY": ("NEEDS_REVIEW", ["automatic pipeline does not verify every potentially identifiable person or property release"], [visual_evidence["contact_sheet"], "asset_manifest.json"]),
        "EDITORIAL_ORIGINALITY": ("PASS" if originality_pass else "FAIL", [f"maximum target trigram overlap={originality['maximum_target_trigram_overlap']} across {originality['comparison_count']} reviewed reference transcripts"], ["narrative_script.json", "qa/technical_measurements.json"]),
        "CHANNEL_IDENTITY": ("NEEDS_REVIEW", ["forbidden reference identity is contractually excluded; distinctness needs independent visual/audio judgment"], ["channel_style_bible.json", visual_evidence["contact_sheet"]]),
        "COST": ("PASS" if cost_pass else "FAIL", ["external production cost recorded as USD 0; local cost remains unavailable"], ["render_manifest.json", "take_plan.json"]),
        "PUBLICATION": ("BLOCKED", ["DRAFT profile, FormatPack not validated, and independent human review pending"], ["render_manifest.json", "config/format_packs/fp-broll-cinematic-narration-v1.json"]),
    }
    if static_audio:
        editorial = _audio_static_editorial(root,package_dir)
        for gate,key in (('HOOK','hook_pass'),('NARRATIVE','narrative_pass'),
                         ('SEMANTIC_COHERENCE','semantic_pass'),('CHANNEL_IDENTITY','identity_pass')):
            gate_statuses[gate] = ('PASS' if editorial[key] and intelligibility['passed'] else 'FAIL',
                ['Authenticated script/sections, measured narration slots and current brief/Pack identity; not a retention prediction'],
                ['qa/technical_measurements.json','narrative_script.json','editorial_brief.json'])
        for gate in ('CHARACTERS','MOVEMENT'):
            gate_statuses[gate] = ('NOT_APPLICABLE',
                ['Authenticated original designed still has no character or camera motion'],
                ['asset_manifest.json','channel_style_bible.json'])
        gate_statuses['PUBLICITY'] = ('PASS',
            ['Native procedural provenance: only owned shapes and text, no depicted person/property'],
            ['asset_manifest.json','qa/technical_measurements.json'])
        gate_statuses['AUDIO'] = ('PASS' if audio_technical_pass and intelligibility['passed'] else 'FAIL',
            ['Offline independent ASR <=8% word error plus measured LUFS/true peak; no human PASS'],
            ['qa/technical_measurements.json',intelligibility['receipt']['path']])
        gate_statuses['CONTINUITY'] = ('PASS' if timeline['contiguous'] and discontinuous_cut_pass else 'FAIL',
            ['One intentional static hold; original narration/timing and observed unplanned transitions checked'],
            ['take_plan.json','render_manifest.json','qa/technical_measurements.json'])
        gate_statuses['LEGIBILITY'] = ('NEEDS_REVIEW',
            ['All decoded frames/text region measured; exact-codec text-local acceptance controls remain required'],
            ['qa/technical_measurements.json','asset_manifest.json'])
        if static_controls is not None and static_execution is not None:
            text_pass=1-static_visual['minimum_text_local_ssim']<=static_controls['limits']['text_error']
            colour_pass=static_visual['maximum_colour_delta_e']<=static_controls['limits']['colour_error']
            gate_statuses['LEGIBILITY']=('PASS' if text_pass else 'FAIL',
                ['Source font/safe area plus all-frame text-local transfer against authenticated disjoint codec controls'],
                ['qa/technical_measurements.json',visual_controls_binding['path'],render_execution_binding['path']])
            gate_statuses['STYLE']=('PASS' if colour_pass and text_pass else 'FAIL',
                ['Owned static layout/Bible and all-frame colour/text fidelity; not cinematic style inference'],
                ['qa/technical_measurements.json',visual_controls_binding['path']])
        gate_statuses['PUBLICATION'] = ('BLOCKED',
            ['Source-input PASS is not final audiovisual QA or production capability approval'],
            ['render_manifest.json','config/format_packs/fp-narrated-reflection-static-v1.json'])
    gates = [
        {
            "gate": gate,
            "status": gate_statuses[gate][0],
            "critical": gate not in {"CHARACTERS"},
            "checks": gate_statuses[gate][1],
            "evidence_refs": gate_statuses[gate][2],
            "reviewer": "phase5-automatic-qa" if gate_statuses[gate][0] in {"PASS", "FAIL"} else None,
        }
        for gate in GATES
    ]

    defect_map: dict[str, tuple[str, str, Any, Any]] = {
        "FLICKER": ("PASS" if flicker_pass else "FAIL", "2 fps signalstats; within-take luminance delta p95", signal.get("flicker_threshold_p95"), signal.get("within_take_luminance_delta_p95")),
        "OBJECT_DEFORMATION": ("NEEDS_REVIEW", "independent full-motion visual review", "no deformation", None),
        "FACE_VARIATION": ("NOT_APPLICABLE", "no recurring face in the Style Bible", "stable recurring face", "no recurring face"),
        "HAND_DEFECT": ("NEEDS_REVIEW", "generated apology-action hands require independent frame review", "valid hands", None),
        "CHARACTER_IDENTITY_DRIFT": ("NOT_APPLICABLE", "characters array is empty", "zero drift", "no recurring character"),
        "BACKGROUND_PULSING": ("NEEDS_REVIEW", "signalstats plus full-motion review", "no pulsing", signal),
        "IMPOSSIBLE_MOTION": ("NEEDS_REVIEW", "independent full-motion visual review", "physically coherent", None),
        "UNINTENDED_CAMERA_INSTABILITY": ("NEEDS_REVIEW", "independent full-motion visual review", "no unintended shake", None),
        "INCOHERENT_PHYSICS": ("NEEDS_REVIEW", "independent full-motion visual review", "coherent source motion", None),
        "DISCONTINUOUS_CUT": (
            "PASS" if discontinuous_cut_pass else "FAIL",
            "2 fps signalstats mapped to measured frame-locked take boundaries; independent review remains required for motivated planned cuts",
            {"unplanned_within_take_hard_transition_count": 0, "luminance_delta_threshold": signal.get("hard_transition_threshold")},
            {"count": signal.get("hard_transition_count"), "events": signal.get("hard_transition_events")},
        ),
        "LIP_SYNC_ERROR": ("NOT_APPLICABLE", "no visible speaking presenter", "synchronized", "no visible speaker"),
        "DUPLICATE_FRAMES": ("PASS" if black_freeze["maximum_freeze_seconds"] <= 0.75 else "FAIL", "FFmpeg freezedetect", 0.75, black_freeze["maximum_freeze_seconds"]),
        "GHOSTING": ("NEEDS_REVIEW", "independent frame and motion review", "no ghosting", None),
        "ARTIFICIAL_INTERPOLATION": ("PASS", "renderer uses source frames and fps normalization without optical-flow interpolation", "no optical-flow interpolation", "fps filter only"),
        "INCONSISTENT_RESOLUTION": ("PASS" if int(video["width"]) == 1920 and int(video["height"]) == 1080 else "FAIL", "ffprobe", "1920x1080", [video["width"], video["height"]]),
        "COMPRESSION_ARTIFACT": ("NEEDS_REVIEW", "bitrate measurement plus independent frame review", ">=2500 kbps and no visible damage", round(bitrate / 1000, 3)),
        "STYLE_DRIFT": ("NEEDS_REVIEW", "signalstats/contact sheet against Style Bible", "no involuntary drift", signal),
        "AUDIO_CLIPPING": ("PASS" if loudness["true_peak_dbtp"] <= -1.0 else "FAIL", "FFmpeg loudnorm measurement", "<= -1.0 dBTP", loudness["true_peak_dbtp"]),
        "LOUDNESS_OUT_OF_RANGE": ("PASS" if -18 <= loudness["integrated_lufs"] <= -14 else "FAIL", "FFmpeg loudnorm measurement", "-16 LUFS ±2", loudness["integrated_lufs"]),
    }
    if static_audio:
        defect_map['COMPRESSION_ARTIFACT'] = (
            'NEEDS_REVIEW',
            'All decoded frames against owned precompression reference; local text/colour controls pending',
            {'independent_exact_codec_controls_required':True}, static_visual)
        if static_controls is not None and static_execution is not None:
            defect_map['COMPRESSION_ARTIFACT']=('PASS' if text_pass and colour_pass else 'FAIL',
                'All-frame local structure/colour with exact-domain disjoint codec controls',static_controls['limits'],static_visual)
            defect_map['STYLE_DRIFT']=('PASS' if colour_pass and text_pass else 'FAIL',
                'Authenticated owned composition colour/text transfer',static_controls['limits'],static_visual)
            defect_map['GHOSTING']=('PASS' if text_pass and colour_pass else 'FAIL',
                'Designed-still scope: every decoded text region and pixel colour against the owned reference and disjoint codec controls; no claim about moving scenes',
                static_controls['limits'],static_visual)
            defect_map['BACKGROUND_PULSING']=('PASS' if flicker_pass and colour_pass and text_pass else 'FAIL',
                'Native temporal luminance check plus every decoded frame within the independently calibrated static colour/text envelope',
                {'temporal_luminance_delta_p95':signal.get('flicker_threshold_p95'),
                 'static_codec_limits':static_controls['limits']},
                {'temporal_luminance_delta_p95':signal.get('within_take_luminance_delta_p95'),
                 'all_frame_colour_delta_e':static_visual['maximum_colour_delta_e'],
                 'all_frame_text_error':1-static_visual['minimum_text_local_ssim']})
        for defect in ('OBJECT_DEFORMATION','FACE_VARIATION','HAND_DEFECT','CHARACTER_IDENTITY_DRIFT',
                'IMPOSSIBLE_MOTION','UNINTENDED_CAMERA_INSTABILITY','INCOHERENT_PHYSICS',
                'LIP_SYNC_ERROR','DUPLICATE_FRAMES','ARTIFICIAL_INTERPOLATION'):
            defect_map[defect] = ('NOT_APPLICABLE','Authenticated designed still scope; final fidelity remains required',
                                  'No photographed/generated anatomy or motion', 'Intentional static composition')
    defects = [
        {
            "defect": defect,
            "status": defect_map[defect][0],
            "method": defect_map[defect][1],
            "evidence_refs": ["qa/technical_measurements.json", visual_evidence["contact_sheet"]],
            "threshold": defect_map[defect][2],
            "observed": defect_map[defect][3],
        }
        for defect in DEFECTS
    ]
    critical_failures = [gate["gate"] for gate in gates if gate["critical"] and gate["status"] in {"FAIL", "BLOCKED"}]
    report = {
        "schema_version": "1.1.0" if static_audio else "1.0.0",
        "report_id": "creative-qa-" + hashlib.sha256(f"{render_manifest['render_id']}|{timestamp}".encode("utf-8")).hexdigest()[:20],
        "video_id": plan["video_id"],
        "channel_id": plan["channel_id"],
        "format_pack_id": plan["format_pack_id"],
        "format_pack_version": plan["format_pack_version"],
        "pipeline_version": render_manifest["pipeline_version"],
        "quality_profile": plan["quality_profile"],
        "gates": gates,
        "defect_evaluations": defects,
        "automatic_evaluator_versions": ["ffprobe@N-120725", "ffmpeg-black-freeze@N-120725", "ffmpeg-signalstats-boundary-aware@1.1.0", "hero-originality-trigram@1.0.0", "hero-rights-hash@1.0.0"],
        "human_review": {"required": not static_audio, "status": "NOT_REQUIRED" if static_audio else "PENDING", "reviewer_id": None, "evidence_ref": None, "independent_from_generator": False},
        "critical_gate_failures": critical_failures,
        "publication_eligible": False,
        "created_at": timestamp,
    }
    measurements = {
        "schema_version": "1.0.0",
        "render_path": str(render.resolve()),
        "render_hash": _sha256(render),
        "probe": probe,
        "loudness": loudness,
        "black_freeze": black_freeze,
        "signalstats": signal,
        "originality": originality,
        "rights": rights,
        "timeline": timeline,
        "hook_timing": {"status": "PASS" if hook_timing_pass else "FAIL", "durations_ms": [item["duration_ms"] for item in voice["takes"][:3]]},
        "visual_evidence": visual_evidence,
        "brief_id": brief["brief_id"],
        "creative_decision_id": creative["decision_id"],
        "style_bible_id": bible["style_bible_id"],
    }
    if static_audio:
        measurements['static_editorial'] = editorial
        measurements['static_packaging'] = static_packaging
        if static_packaging is not None:
            for item in static_packaging['inputs']:
                if _sha256(Path(item['path'])) != item['sha256']:
                    raise PermissionError('Static packaging input changed before publication')
        for item in editorial['inputs']:
            if _sha256(Path(item['path'])) != item['sha256']:
                raise PermissionError('Static editorial input changed before publication')
        measurements['static_source_inputs'] = static_inputs
        measurements['intelligibility'] = intelligibility
        measurements['static_decoded_visual'] = static_visual
        measurements['static_codec_controls'] = static_controls
        measurements['static_observed_execution'] = static_execution
        for item in static_inputs['inputs']:
            if _sha256(Path(item['path'])) != item['sha256']:
                raise PermissionError('static QA input changed before publication')
        if _sha256(render) != render_hash_before:
            raise PermissionError('static QA media changed before publication')
        for observed in (static_controls,static_execution):
            if observed is not None:
                bound=observed['binding']
                if _sha256(Path(bound['path']))!=bound['sha256']:
                    raise PermissionError('static QA observation anchor changed before publication')
                for item in observed['authenticated_inputs']:
                    if _sha256(Path(item['path']))!=item['sha256']:
                        raise PermissionError('static QA observation input changed before publication')
    schema = _read_json(root / "schemas" / "creative_quality_gate_report.schema.json")
    Draft202012Validator(schema).validate(report)
    qa_dir = package_dir / "qa"
    qa_dir.mkdir(parents=True, exist_ok=True)
    (qa_dir / "technical_measurements.json").write_text(json.dumps(measurements, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (qa_dir / "creative_quality_gate_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report, measurements
