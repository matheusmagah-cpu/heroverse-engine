"""Read the frozen V3 -> V5 case-only amendment without admitting a source.

V2 and V3 inspections remain separate history. The question staging, original
failed QA, OCR and ink observations are replayed under external pins, never
remeasured. A must recheck both document and question-replay dependencies after
its remaining work; no timestamp, PCM measurement, renderer or authority exists
in this adapter. A serialized candidate is not an alternative source of proof.
"""
from __future__ import annotations

import copy
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_question_sources as question
from . import phase6_av_static_sources as source
from . import phase6_av_visual_amendment as legacy
from .phase6_av_caption_intent import _binding, _resident
from .phase6_av_visual_intent import _state_entries
from .phase6_narration_audio_inventory import _json
from .phase6_narration_units import bytes_sha, canonical_sha

VERSION = "phase6-av-question-case-amendment-v1"
SCHEMA = "schemas/phase6_av_question_case_amendment.schema.json"
HERE = "output/qa/phase6/diagnostics/test-questions-v1"
PROJECTION_BINDING = {"path": HERE + "/staged-visual-v5-7fd136fe0bc4557433b24e46.json",
    "sha256": "sha256:7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92"}
AMENDMENT_BINDING = {"path": HERE + "/question-case-amendment-v2-1e60348b0c51a9116c8177f9.json",
    "sha256": "sha256:b07bca4c9adc736ffe0abdfca49c341c2e114d9fa12cc269f6dc1aed8fbbadbf"}
STAGING_BINDING = {"path": HERE + "/question-case-amendment-v2-1e60348b0c51a9116c8177f9-receipt.json",
    "sha256": "sha256:3e22ff3998f04596ebbb22d8c0d1d0f69db0d5f8c2c01c5ab06c056cc7579761"}
RECONCILIATION_BINDING = {"path": HERE + "/reconciliation-f3904b4f063f15c87e2bfd9b/report.json",
    "sha256": "sha256:0ac7a3fbfbf14da0d0bb6bc15993a303fb03510d76cafcddcbf6369620770aff"}
QUESTION_TEST_BINDING = {"path": "tests/test_phase6_av_question_sources.py",
    "sha256": "b623b40c945520423bb0e81e19a7b5894527169b6bc47ac19251854a3fb3cc06"}
FIXED_IMPLEMENTATIONS = {
    "hero_engine/phase6_av_visual_intent.py": "9ea8fa3f1d465b6bb8a0aa5491d291ae592400c64e7445b17733190b7431c791",
    "schemas/phase6_av_untimed_visual_intent.schema.json": "706c1f5a62ba75790c0d8e7ab3ce31dca520c519f72f626ecce4f9f2c0caa9cc",
    "hero_engine/phase6_av_caption_intent.py": "36f7c2fd82b36ef824221dfe031c304794fde07042e761065df233311bb51763",
    "hero_engine/phase6_narration_audio_inventory.py": "11e56ca46d3f4928882ece936500b49a428caf7cbd1ff542069eceb47db4bde6",
    "hero_engine/phase6_narration_units.py": "737326797c9499cd341198ca43927a3e6447f5616563ceafc6b3bd8278c71fba",
    "hero_engine/phase6_av_visual_amendment.py": "0205fe37622d4ea1bbef501d28a32a9e7c328d00129e33a994119161fa129085",
    "schemas/phase6_av_visual_amendment.schema.json": "a7fc96bcd6916504c08b7669cafbc430446ae0903ca6ba5dc1fa4f9918550cc1",
    "hero_engine/phase6_av_question_sources.py": "3ed0553ab253e81458f786aa9ba15862ef5a191157bcf9bfc6ebcc0922953ad2",
}
EXPECTED_CHANGES = (
    ("visual-u019-s00", "narration-unit-019", ["TEST", "LOUD IS NOT TRUE"], ["Test", "Loud is not true"]),
    ("visual-u021-s00", "narration-unit-021", ["CHARACTER", "Is this how I should act?"], ["Character", "Is this how I should act?"]),
)
SELECTED_STATES = ["visual-u019-s00", "visual-u020-s00", "visual-u020-s01", "visual-u021-s00"]
DECISION_REFERENCE_SCOPE = "HISTORICAL_V2_AND_V3_USE_EXPLICIT_CASE_AMENDMENT_FOR_V5"
REPLAY_SCOPE = "EXTERNAL_PINNED_STAGING_PIXEL_OCR_INK_REPLAY_NOT_REMEASURED"


def _same(left, right, message):
    source._same(left, right, message)


def _documents(projection, amendment, schema):
    for key, document in (("projection", projection), ("amendment", amendment)):
        canonical_sha(document)
        Draft202012Validator({"$ref": "#/$defs/" + key, "$defs": schema["$defs"]}).validate(document)
        _same(document["authority"], legacy.AUTHORITY, "case amendment cannot confer authority")
        if type(document["technical_cost_brl"]) is not int or document["technical_cost_brl"] != 0:
            raise ValueError("case amendment cost must be exact integer zero")
        _same(document["base_projection"], legacy.PROJECTION_BINDING, "case amendment base must remain V3")
    _same(projection["case_amendment"], AMENDMENT_BINDING, "case projection amendment differs")
    _same(amendment["independent_static_reconciliation"], RECONCILIATION_BINDING, "case reconciliation differs")
    for name, wanted in (("changed_state_count", 2), ("changed_string_count", 3), ("unchanged_state_count", 98), ("unselected_state_count", 96)):
        if type(amendment[name]) is not int or amendment[name] != wanted:
            raise ValueError("case population count must be exact")
    unsigned = {key: value for key, value in amendment.items() if key != "amendment_id"}
    if amendment["amendment_id"] != "question-case-amendment-v2-" + source._sha(source._canonical(unsigned))[:24]:
        raise ValueError("case amendment identity differs")


def _apply_case(base, projection, amendment):
    """Independently apply only the two exact casing deltas to verified V3."""
    effective = copy.deepcopy(base["rows"])
    index = {state["state_id"]: (row, state) for row in effective for state in row["states"]}
    if len(effective) != 51 or len(index) != 100:
        raise ValueError("case amendment requires exact 51/100 population")
    wanted_changes, string_count = [], 0
    for sid, uid, before, after in EXPECTED_CHANGES:
        row, state = index[sid]
        _same([row["unit_id"], state["visual_content"]["literal_copy"]], [uid, before], "case old copy/unit differs")
        if [text.casefold() for text in before] != [text.casefold() for text in after]:
            raise ValueError("non-case change is forbidden")
        wanted_changes.append({"state_id": sid, "unit_id": uid, "before_copy": before, "after_copy": after,
            "preserved_entry": copy.deepcopy(state["entry"]), "reason": "Sentence case in body overlays; wording and meaning unchanged."})
        string_count += sum(left != right for left, right in zip(before, after, strict=True))
        state["visual_content"]["literal_copy"] = copy.deepcopy(after)
    _same(amendment["changes"], wanted_changes, "case change mapping/entry/copy differs")
    _same(amendment["selected_source_state_ids"], SELECTED_STATES, "case selected state population differs")
    changed_ids = {row[0] for row in EXPECTED_CHANGES}
    unchanged = [state for row in base["rows"] for state in row["states"] if state["state_id"] not in changed_ids]
    unselected = [state for row in base["rows"] for state in row["states"] if state["state_id"] not in SELECTED_STATES]
    _same([len(unchanged), len(unselected), string_count, amendment["unchanged_states_sha256"], amendment["unselected_states_sha256"]],
          [98, 96, 3, source._sha(source._canonical(unchanged)), source._sha(source._canonical(unselected))], "case unchanged-state identity differs")
    _same(projection["effective_rows"], effective, "case projection modifies more than three casing strings")
    seen, lexical = set(), []
    for row in effective:
        lexical.extend(_state_entries(row, seen))
    _same(lexical, base["visual_lexical_ranges"], "case projection changes temporal literal population")
    return effective


def read_amended_visual_intent(reader, binding, units, caption_proof):
    """Recompose V2, V3 and the exact V5 case delta; metadata only.

    `dependency_bindings` remains bounded document metadata for the existing
    literal reader. Larger runtime/model bytes and the fixed external font are
    explicit `question_replay_dependencies`, rechecked by the dedicated helper.
    These are not PCM assets and do not acquire audio/source/timing authority.
    """
    _binding(binding)
    _same(binding, PROJECTION_BINDING, "only the exact frozen V5 projection is supported")
    root = Path(__file__).absolute().parents[1]
    if source._resident(reader.root) != source._resident(root):
        raise ValueError("case amendment requires its canonical resident root")
    guard = source._Reader(root)
    implementation = []
    for path, digest in FIXED_IMPLEMENTATIONS.items():
        raw = guard.read(path, digest)
        implementation.append({"path": path, "sha256": "sha256:" + digest, "size_bytes": len(raw)})
    for path in ("hero_engine/phase6_av_question_case_amendment.py", SCHEMA):
        raw = source._resident(root / path).read_bytes()
        digest = source._sha(raw)
        guard.read(path, digest)
        implementation.append({"path": path, "sha256": "sha256:" + digest, "size_bytes": len(raw)})
    guard.read(QUESTION_TEST_BINDING["path"], QUESTION_TEST_BINDING["sha256"])
    schema = _json(guard.read(SCHEMA, implementation[-1]["sha256"][7:]))
    dependencies = {}

    def read(bound):
        _binding(bound)
        _resident(reader.root, bound["path"])
        raw = reader.read(bound["path"], bound["sha256"])
        if bytes_sha(raw) != bound["sha256"]:
            raise ValueError("case document hash differs")
        item = {**copy.deepcopy(bound), "size_bytes": len(raw)}
        _same(dependencies.setdefault(bound["path"], item), item, "case document identity drift")
        return raw

    projection, amendment = (_json(read(bound)) for bound in (binding, AMENDMENT_BINDING))
    _documents(projection, amendment, schema)
    # One independently recomposed V3 inspection retains its original V2 proof.
    base = legacy.read_amended_visual_intent(reader, legacy.PROJECTION_BINDING, units, caption_proof)
    for item in base["implementation_dependencies"]:
        _same(item, next(row for row in implementation if row["path"] == item["path"]), "legacy reader implementation drift")
    for item in base["dependency_bindings"]:
        _same(dependencies.setdefault(item["path"], copy.deepcopy(item)), item, "legacy document identity differs")
    effective = _apply_case(base, projection, amendment)
    # Metadata-only replay of the real exclusive staging and measured evidence.
    # Deliberately NOT inspect_question_sources or its PNG CRC/decode path.
    stager, replay = question._preflight(root)
    _same(projection, replay["projection"], "independently replayed V5 projection differs")
    _same(amendment, replay["body"], "independently replayed case amendment differs")
    _same(_json(read(STAGING_BINDING)), _json(replay["reader"].read(STAGING_BINDING["path"], STAGING_BINDING["sha256"][7:])), "staging receipt association differs")
    for item in guard.bindings.values():
        replay["reader"].read_path(Path(item["path"]), item["sha256"])
    result = {**copy.deepcopy(base), "adapter_version": VERSION,
        "status": "LITERAL_CASE_AMENDMENT_IDENTIFIED_SOURCES_AND_TIMING_PENDING",
        "source_binding": copy.deepcopy(binding), "rows": effective,
        "prior_projection_binding": copy.deepcopy(legacy.PROJECTION_BINDING),
        "prior_amendment_inspection": copy.deepcopy(base), "prior_amendment_inspection_sha256": canonical_sha(base),
        "amendment_binding": copy.deepcopy(AMENDMENT_BINDING), "case_staging_binding": copy.deepcopy(STAGING_BINDING),
        "case_reconciliation_binding": copy.deepcopy(RECONCILIATION_BINDING),
        "effective_rows_sha256": canonical_sha(effective), "decision_reference_scope": DECISION_REFERENCE_SCOPE,
        "changed_state_count": 2, "changed_string_count": 3, "unmodified_state_count": 98,
        "static_proof_scope": REPLAY_SCOPE, "question_replay_dependencies": sorted(replay["reader"].bindings.values(), key=lambda row: row["path"]),
        "dependency_bindings": sorted(dependencies.values(), key=lambda row: row["path"]),
        "implementation_dependencies": implementation,
        "limitations": [*base["limitations"],
            "The intact base_inspection is historical V2; prior_amendment_inspection is historical V3. Only the explicit case delta supplies V5 copy.",
            "Two states/three strings change casing; 98 states, all narration, entries and the 26-target literal union remain identical to V3.",
            "Question staging, original FAIL, OCR and ink observations are externally pinned historical replay, not new pixel measurements or source admission.",
            "Source/render scheduling, rights, publicity, final-video quality, audio and publication remain unapproved."]}
    recheck_question_replay(root, result)
    for item in list(dependencies.values()):
        read({key: item[key] for key in ("path", "sha256")})
    for item in implementation:
        guard.read(item["path"], item["sha256"][7:])
    return result


def recheck_question_replay(root, proof):
    """Recheck the same-call sink after A's later work; not a proof verifier.

    Never use this helper to approve an externally supplied/serialized report.
    It does not recompose the case projection or confer any authority alone.
    """
    if type(proof) is not dict or proof.get("adapter_version") != VERSION:
        raise ValueError("same-call question amendment proof required")
    _same(proof.get("source_binding"), PROJECTION_BINDING, "question replay source differs")
    _same(proof.get("static_proof_scope"), REPLAY_SCOPE, "question replay scope differs")
    _same(proof.get("authority"), dict.fromkeys(("timing", "source", "quality", "render", "admission", "publication"), False),
          "case replay cannot confer authority")
    if type(proof.get("technical_cost_brl")) is not int or proof["technical_cost_brl"] != 0:
        raise ValueError("case replay cost must remain exact zero")
    if any(proof.get(name) is not False for name in ("source_ready", "global_schedule_created", "calibrated_timing_available")):
        raise ValueError("case replay cannot acquire readiness or timing")
    source._Reader(root).read("hero_engine/phase6_av_question_sources.py", FIXED_IMPLEMENTATIONS["hero_engine/phase6_av_question_sources.py"])
    return question.recheck_question_dependencies(root, [{"dependency_bindings": proof.get("question_replay_dependencies")}])
