"""Authenticate the narrow, paused commit of an integrity successor view.

This is intentionally *not* an installation regression reader.  It can
authorize only ``integrity_manifest_successor.json`` after a current candidate
and an exact staged successor have been tested.  It never grants restart,
render, upload, or publication authority, and it cannot consume a historical
or forward-only result by accident.
"""
from __future__ import annotations

import hashlib
import json
import tempfile
from contextlib import ExitStack, closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import maintenance_paused_application as paused
from .maintenance_unittest_result import verify_unittest_result
from .phase5_integrity_maintenance import verify_staged_successor


VERSION = "phase5-integrity-successor-proof-v1"
PURPOSE = "EXACT_CURRENT_INTEGRITY_SUCCESSOR_MAINTENANCE"
FILES = frozenset({
    "candidate-before.json", "candidate-after.json", "test-inventory.json",
    "unittest.stdout.log", "unittest.stderr.log", "process-result.json",
    "verifier-result.json", "preservation-before.json", "preservation-after.json",
    "integrity_manifest_successor.json",
})
TEST_PREFIXES = (
    "tests.test_phase5_integrity_maintenance.",
    "tests.test_phase5_integrity_successor_proof.",
)


class IntegritySuccessorProofError(PermissionError):
    pass


def _digest(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _json(raw: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise IntegritySuccessorProofError(f"{label} is not valid JSON") from exc
    if not isinstance(value, dict):
        raise IntegritySuccessorProofError(f"{label} is not an object")
    return value


def build_test_inventory(full_inventory: dict[str, Any]) -> dict[str, Any]:
    """Derive the exact narrow test population from an authenticated inventory."""
    if full_inventory.get("schema_version") != "1.1.0" or not isinstance(full_inventory.get("files"), list):
        raise IntegritySuccessorProofError("full inventory contract differs")
    rows = []
    for item in full_inventory["files"]:
        ids = [item_id for item_id in item.get("test_ids", []) if item_id.startswith(TEST_PREFIXES)]
        if ids:
            rows.append({"path": item["path"], "content_hash": item["content_hash"], "test_ids": ids})
    selected = [item_id for row in rows for item_id in row["test_ids"]]
    if not selected or len(selected) != len(set(selected)):
        raise IntegritySuccessorProofError("integrity successor test population is empty or ambiguous")
    result = {
        "schema_version": "1.1.0",
        "discovery_pattern": "EXACT_CURRENT_INTEGRITY_SUCCESSOR_MAINTENANCE_V1",
        "file_count": len(rows), "method_count": len(selected), "alias_count": 0,
        "test_count": len(selected), "tests_hash": _canonical_hash(selected),
        "load_tests_aliases": [], "aliases_hash": _canonical_hash([]), "files": rows,
    }
    return result


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _proof_relative_path(root: Path, offered: Path) -> str:
    """Accept an absolute CLI path only when it canonically stays in root."""
    offered = Path(offered)
    if not offered.is_absolute():
        return offered.as_posix()
    try:
        return offered.resolve(strict=True).relative_to(root).as_posix()
    except (OSError, ValueError) as exc:
        raise IntegritySuccessorProofError("proof envelope path is invalid") from exc


def read_integrity_successor_proof(root: Path, envelope_path: Path, expected_envelope_hash: str,
                                  expected_candidate_hash: str, expected_successor_hash: str,
                                  stack: ExitStack) -> dict[str, Any]:
    """Read one exact current-maintenance proof under TOCTOU pins.

    The caller supplies external hashes.  This function never learns an anchor
    from the offered evidence and never accepts an alternate purpose.
    """
    root = Path(root).resolve(strict=True)
    if not all(isinstance(item, str) and len(item) == 71 and item.startswith("sha256:")
               for item in (expected_envelope_hash, expected_successor_hash)) or not (
                   isinstance(expected_candidate_hash, str) and len(expected_candidate_hash) == 64):
        raise IntegritySuccessorProofError("external proof anchors are invalid")
    try:
        # The public commit entry receives a Path and callers commonly provide
        # an absolute path.  Normalize it to the root-relative contract before
        # applying the existing traversal guard; never stringify an absolute
        # path into a faux relative one.
        envelope = paused._path(root, _proof_relative_path(root, envelope_path))
    except Exception as exc:
        raise IntegritySuccessorProofError("proof envelope path is invalid") from exc
    if envelope.parent.parent != root / paused.RUNS:
        raise IntegritySuccessorProofError("proof run is not under maintenance-runs")
    pins = []

    def read(path: Path) -> bytes:
        pin = stack.enter_context(closing(paused.p._PausedCancelPin(path)))
        pins.append(pin)
        return pin.payload

    raw = read(envelope)
    if _digest(raw) != expected_envelope_hash:
        raise IntegritySuccessorProofError("proof envelope hash differs")
    doc = _json(raw, "proof envelope")
    if (set(doc) != {"schema_version", "purpose", "root", "proof_run", "candidate_sha256", "successor_sha256", "files"}
            or doc.get("schema_version") != "1.0.0" or doc.get("purpose") != PURPOSE
            or doc.get("root") != str(root) or doc.get("proof_run") != envelope.parent.relative_to(root).as_posix()
            or doc.get("candidate_sha256") != expected_candidate_hash or doc.get("successor_sha256") != expected_successor_hash
            or set(doc.get("files", {})) != FILES):
        raise IntegritySuccessorProofError("proof envelope contract differs")
    payloads = {name: read(envelope.parent / name) for name in sorted(FILES)}
    if any(_digest(payloads[name]) != doc["files"][name] for name in FILES):
        raise IntegritySuccessorProofError("proof file hash differs")
    candidate = paused.candidate_identity(root)
    if candidate["source_set_sha256"] != expected_candidate_hash:
        raise IntegritySuccessorProofError("current candidate differs")
    before = _json(payloads["candidate-before.json"], "candidate before")
    after = _json(payloads["candidate-after.json"], "candidate after")
    if before != candidate or after != candidate:
        raise IntegritySuccessorProofError("candidate capture differs")
    staged = _json(payloads["integrity_manifest_successor.json"], "staged successor")
    if staged.get("successor_sha256") != expected_successor_hash:
        raise IntegritySuccessorProofError("staged successor hash differs")
    verify_staged_successor(root, staged)
    inventory = _json(payloads["test-inventory.json"], "test inventory")
    with tempfile.TemporaryDirectory(prefix=".integrity-proof-inventory-", dir=envelope.parent) as directory:
        actual_full = paused.p.build_validation_manifests(root, output_dir=Path(directory))
        full_inventory = paused.p._read(root / actual_full["test_inventory_path"])
    if inventory != build_test_inventory(full_inventory):
        raise IntegritySuccessorProofError("integrity successor test inventory differs")
    parsed = verify_unittest_result(inventory=inventory, stdout_bytes=payloads["unittest.stdout.log"],
                                    stderr_bytes=payloads["unittest.stderr.log"], process_exit_code=_json(payloads["process-result.json"], "process result").get("exit_code"))
    if _json(payloads["verifier-result.json"], "verifier result") != parsed:
        raise IntegritySuccessorProofError("verifier result differs")
    process = _json(payloads["process-result.json"], "process result")
    if not (isinstance(process.get("started_at"), str) and isinstance(process.get("finished_at"), str)
            and paused.p._parse(process["started_at"]) < paused.p._parse(process["finished_at"]) <= datetime.now(timezone.utc)):
        raise IntegritySuccessorProofError("process chronology differs")
    preservation_before = _json(payloads["preservation-before.json"], "preservation before")
    preservation_after = _json(payloads["preservation-after.json"], "preservation after")
    if preservation_before != preservation_after:
        raise IntegritySuccessorProofError("proof preservation differs")
    return {"candidate": candidate, "staged": staged, "pins": pins, "parsed": parsed,
            "proof_path": envelope.relative_to(root).as_posix(), "purpose": PURPOSE,
            "authority": {"integrity_successor_commit": True, "application": False,
                          "restart": False, "render": False, "publication": False}}
