"""Read-only inspection of two frozen, owned static composition families.

This module never imports the render recipes, creates media or assigns timing.
PNG bytes and complete receipt inventories are checked independently; semantic
contracts are recomposed from the frozen TakePlan, not generator approval flags.
One image is one source frame, irrespective of a future A-controlled hold.
"""
from __future__ import annotations

import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import re
import stat
from types import MappingProxyType
from xml.etree import ElementTree

from PIL import Image, PngImagePlugin, __version__ as PILLOW_VERSION

VERSION = "phase6-av-static-sources-v2"
CHANNEL = "UCuMF6pJQkyMzaVoAxFL86yA"
BASE = "output/qa/phase6/diagnostics/"
PLAN = "output/production/phase6/video-002/production/take_plan.json"
BIBLE = "output/production/phase6/video-002/production/channel_style_bible.json"
AUDIT = BASE + "temporal-scope-audit-3a6aa9e15887bd7998b2bc3d.json"
INPUT_PINS = {
    PLAN: "547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5",
    BIBLE: "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049",
    AUDIT: "6ba997f4d6d72fff549861abd3e5e4c50193cdfb39898d6d45aedb8b5ad489fe",
}
FONT = Path("C:/Windows/Fonts/arialbd.ttf")
FONT_SHA = "e8f4e3baf6cc35fed6fcce3a540e8b39e8f6cda1d22a28f2ec8f526fef7a43f5"
# Observed under the project's actual .venv, not a receipt-selected installation.
# Reading the bytes precedes decoder calls. The PNG-specific entry point avoids
# Image.open's unrelated-format plugin discovery. Python/OS are not attested here.
DECODER_VERSION = "12.3.0"
DECODER_DIRECTORY = Path(__file__).absolute().parents[1] / ".venv/Lib/site-packages/PIL"
DECODER_MODULE_PINS = MappingProxyType({
    "PIL": ("__init__.py", "3fffff8502f4b59ca61d39cce713d55ffef046954262fce1abac3e97f3803734"),
    "PIL.ExifTags": ("ExifTags.py", "362cafb665044fbf41322a248a3313a7fabc75e596ce9c9db5371305f272f0a1"),
    "PIL.GimpGradientFile": ("GimpGradientFile.py", "cec216d4c915ea4a39964e072555de8121d4df250fc16d695329d1b39cf48990"),
    "PIL.GimpPaletteFile": ("GimpPaletteFile.py", "126047710f44c42e1fe3bb5a0fb4bb1ba55a324afd1e3ca7955f0d7535d5e624"),
    "PIL.Image": ("Image.py", "59f1b98ed7bfd7b516b9f13ffd9dd3bc0aa1a495042accdb5ae4609b41c329d5"),
    "PIL.ImageChops": ("ImageChops.py", "859f043d43e5408cee82c11e755f2dae4297d230420c66fa0acce66ba65e3194"),
    "PIL.ImageColor": ("ImageColor.py", "295faeec79d95abacbdf3b8100e2ea7ab23eeef15c5d3c5d2dea1a6158ec9f02"),
    "PIL.ImageFile": ("ImageFile.py", "e972c9d8785ad1fd44f860a375d8719f3fdff8e46da1cc311950699f93e4f539"),
    "PIL.ImageMode": ("ImageMode.py", "50b900fa3b02806c31563af62cf48fe367439a3ea759a424f4be142a3eca7d28"),
    "PIL.ImagePalette": ("ImagePalette.py", "f4a973fbb23a253494a7695f64933a5740f270540a926e91c5fc970d3e14fe7c"),
    "PIL.ImageSequence": ("ImageSequence.py", "82e64751da56af39f3664718d0e6290f3b85d2e15794212edbad283feedefdf2"),
    "PIL.PaletteFile": ("PaletteFile.py", "41d11af7d8cb0be3cf844a86cbaff87c3b9af13cca4925339007987029455fb3"),
    "PIL.PngImagePlugin": ("PngImagePlugin.py", "26e6495edc516f7589dea911c330d7f16d4ec96eed78af838da00902e77e6040"),
    "PIL.TiffTags": ("TiffTags.py", "16c76a6c8409388ee2846ecc67f2b8614403678ce8fab6986e28550dee3653d1"),
    "PIL._binary": ("_binary.py", "ba6dc47fa221e747297ee81afcbdaef2ea9be664c7a4b51f5382563132e0b20b"),
    "PIL._deprecate": ("_deprecate.py", "522ac3970b3279feaeeac2ffae51379a72ad45fd666af9a7864b7fd4f03b43c0"),
    "PIL._imaging": ("_imaging.cp312-win_amd64.pyd", "c8c519ec72bf75b2945b4fc4afa854af2fca8b970a403134f9ddda3e164d85e9"),
    "PIL._util": ("_util.py", "78ff087e658999b13f3ea6d425be2a4ea18d2e2e334f44d369daebaa6ca483b6"),
    "PIL._version": ("_version.py", "8367607a728dc206da64e3de6b24f826f3030d7f3c053f25c3b3a1fde94fb9d7"),
})
EXTERNAL_DEPENDENCY_PINS = MappingProxyType({str(FONT): FONT_SHA, **{
    str(DECODER_DIRECTORY / filename): digest for filename, digest in DECODER_MODULE_PINS.values()}})
PALETTE = ["#081827", "#D7A94A", "#E8EDF2", "#2C5364"]
TEMPLATES = {
    "fear-examples-v1": {
        "directory": BASE + "fear-examples-design-v1/static-eb8525d749651871f56cafc9",
        "receipt_sha256": "076ec5bec965ccc5c294ecd82ac813faf1886343a928dbb3c30d26d45092c434",
        "runner": BASE + "fear-examples-design-v1/recipe.py",
        "runner_sha256": "84fd21136522efa10b89900a4fc5f06523396d587b27fa356d83e10c908d914b",
        "lineage_id": "owned-fear-example-triptych-v1",
        "state_ids": [f"{subject}-{n}" for subject in ("door", "reply", "morning") for n in (0, 1)],
        "contact_sheet": "contact-sheet.png", "sheet_size": [960, 810],
    },
    "four-criteria-v1": {
        "directory": BASE + "four-criteria-layout-v1/static-1ada6ec8746d09b6061b634c",
        "receipt_sha256": "2b0b541bbbeacf9b7c62d6dbe85bd34ac789b0e7da96d86e1f0ce49a76a7415f",
        "runner": BASE + "four-criteria-layout-v1/recipe.py",
        "runner_sha256": "ea2000c544bcf8e934509296574510ba20af920d1956e2a4fb84c003314edb11",
        "lineage_id": "owned-four-criteria-panel-v1",
        "state_ids": [f"state-{n}" for n in range(5)],
        "contact_sheet": "four-state-contact-sheet.png", "sheet_size": [960, 540],
    },
}
EXAMPLES = (
    ("005", "door", "A closed door", "Fear says: forgotten", "forgotten",
     "A closed door becomes proof that you are forgotten."),
    ("006", "reply", "A delayed reply", "Fear says: rejection", "rejection",
     "A delayed reply becomes proof that rejection is coming."),
    ("007", "morning", "A hard morning", "Fear says: God has left", "God has left",
     "A hard morning becomes proof that God has left."),
)
CRITERIA = ("Truth", "Character", "Consequences", "Wise counsel")
FOUR_LITERAL = "Test the meaning against truth, character, consequences, and wise counsel."
AUTHORITY = {key: False for key in (
    "synthesis_authorized", "render_authorized", "queue_authorized",
    "publication_authorized", "quality_approved", "source_admitted", "timing_validated")}


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _canonical(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def _json(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result

    def nonfinite(value):
        raise ValueError("nonfinite JSON number: " + value)

    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=nonfinite)


def _same(actual, expected, message):
    if _canonical(actual) != _canonical(expected):
        raise ValueError(message)


def _resident(path):
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError("absolute resident path required")
    for item in (path, *path.parents):
        info = item.lstat()
        if (stat.S_ISLNK(info.st_mode) or item.is_symlink()
                or (hasattr(item, "is_junction") and item.is_junction())):
            raise ValueError("linked path is not admitted")
        if getattr(info, "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000):
            raise ValueError("offline or recall-on-access path is not admitted")
    return path


class _Reader:
    def __init__(self, root):
        self.root = _resident(Path(root).absolute())
        self.bindings = {}

    def path(self, relative):
        if type(relative) is not str or not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise ValueError("confined relative source required")
        path = self.root / relative
        if not path.is_relative_to(self.root):
            raise ValueError("source escapes root")
        return _resident(path)

    def read(self, relative, expected_sha, *, limit=16 * 1024**2):
        return self.read_path(self.path(relative), expected_sha, limit=limit)

    def read_path(self, path, expected_sha, *, limit=16 * 1024**2):
        if type(expected_sha) is not str or re.fullmatch(r"[0-9a-f]{64}", expected_sha) is None:
            raise ValueError("exact SHA-256 pin required")
        path = _resident(path)
        before = path.stat()
        fixed_system_font = path == FONT and expected_sha == FONT_SHA
        if (not stat.S_ISREG(before.st_mode) or (before.st_nlink != 1 and not fixed_system_font)
                or not 0 < before.st_size <= limit):
            raise ValueError("nonregular, linked, empty or oversized source")
        raw = path.read_bytes()
        after = _resident(path).stat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise ValueError("source changed during inspection")
        if len(raw) != before.st_size or _sha(raw) != expected_sha:
            raise ValueError("source hash mismatch")
        binding = {"path": str(path), "sha256": expected_sha, "size_bytes": len(raw)}
        old = self.bindings.setdefault(str(path), binding)
        _same(old, binding, "dependency identity differs")
        return raw


def _verify_decoder(reader):
    if PILLOW_VERSION != DECODER_VERSION:
        raise ValueError("unrecognized Pillow decoder version")
    dependencies = []
    for name, (filename, digest) in DECODER_MODULE_PINS.items():
        path = DECODER_DIRECTORY / filename
        reader.read_path(path, digest)
        dependencies.append(reader.bindings[str(path)])
    for name, (filename, _) in DECODER_MODULE_PINS.items():
        module = importlib.import_module(name)  # Fixed names only, after byte checks.
        if _resident(Path(module.__file__).absolute()) != DECODER_DIRECTORY / filename:
            raise ValueError("Pillow decoder loaded from another installation")
    if Image.core is not importlib.import_module("PIL._imaging"):
        raise ValueError("Pillow native decoder identity differs")
    return {"name": "Pillow typed PNG verify and pixel decode", "version": DECODER_VERSION,
            "entrypoint": "PIL.PngImagePlugin.PngImageFile", "dependencies": dependencies,
            "scope": "PINNED_PILLOW_PNG_STACK_NOT_PYTHON_OS_ATTESTATION"}


def _png(raw, expected_size):
    # Two independent opens: verify compressed-file integrity, then decode pixels.
    with PngImagePlugin.PngImageFile(io.BytesIO(raw)) as probe:
        if probe.format != "PNG" or probe.size != tuple(expected_size):
            raise ValueError("PNG dimensions/format differ")
        if getattr(probe, "is_animated", False) or getattr(probe, "n_frames", 1) != 1:
            raise ValueError("animated or multiple-image source is not a static frame")
        probe.verify()
    with PngImagePlugin.PngImageFile(io.BytesIO(raw)) as decoded:
        decoded.load()
        mode = decoded.mode
        if mode not in ("RGB", "RGBA"):
            raise ValueError("only measured RGB or opaque RGBA is supported")
        opaque = mode == "RGB" or decoded.getchannel("A").getextrema() == (255, 255)
        if not opaque or "transparency" in decoded.info:
            raise ValueError("transparent static source is not admitted")
        return {"width": decoded.width, "height": decoded.height, "mode": mode,
                "opacity": "OPAQUE", "source_frame_count": 1}


def _states(template_id, plan, bible, audit):
    if plan["channel_id"] != CHANNEL or bible["channel_id"] != CHANNEL:
        raise ValueError("ChannelDNA identity differs")
    _same(bible["palette"]["locked_hex"], PALETTE, "locked palette differs")
    takes = plan["takes"]
    if len(takes) != 90 or len({take["take_id"] for take in takes}) != 90:
        raise ValueError("literal fragment inventory differs")
    by_id = {take["take_id"]: take for take in takes}
    states, contracts = [], {}
    if template_id == "fear-examples-v1":
        for ordinal, subject, fact, thought, anchor, literal in EXAMPLES:
            tid, uid = "take-" + ordinal, "narration-unit-" + ordinal
            if by_id[tid]["narration"] != literal or literal.count(anchor) != 1:
                raise ValueError("fear example literal differs")
            for index in (0, 1):
                sid = f"{subject}-{index}"
                start = literal.index(anchor) if index else None
                end = start + len(anchor) if index else None
                state = {"state_id": sid, "subject": subject, "unit_id": uid, "take_id": tid,
                         "state": index, "fact": fact, "thought": thought if index else None,
                         "literal_narration": literal, "lexical_anchor": anchor if index else None,
                         "lexical_char_start": start, "lexical_char_end": end,
                         "trigger_kind": "CALIBRATED_LEXICAL_REQUIRED" if index else "UNIT_ENTRY_NOT_BOUND",
                         "observed_sample": None, "video_frame": None}
                states.append(state)
                contracts[sid] = {"unit_id": uid, "fragment_ids": [tid], "unit_fragment_ids": [tid],
                    "literal_narration": literal, "text_lines": [fact, thought] if index else [fact],
                    "timing_kind": state["trigger_kind"], "lexical_target": None if not index else {
                        "unit_id": uid, "fragment_id": tid, "text": anchor, "char_start": start, "char_end": end}}
    else:
        tids = [f"take-{n:03d}" for n in range(51, 55)]
        literal = " ".join(by_id[tid]["narration"] for tid in tids)
        if literal != FOUR_LITERAL or audit["additional_editorial_decisions"]["narration-unit-034"]["take_ids"] != tids:
            raise ValueError("four-criteria literal/editorial scope differs")
        for index in range(5):
            label = CRITERIA[index - 1] if index else None
            anchor = label.lower() if label else None
            start = literal.index(anchor) if anchor else None
            end = start + len(anchor) if anchor else None
            tid, uid = tids[index - 1] if index else tids[0], "narration-unit-034"
            state = {"state": index, "take_id": tid, "heading": "Test the meaning", "criterion": label,
                     "lexical_char_start": start, "lexical_char_end": end,
                     "timing_kind": "CALIBRATED_LEXICAL_REQUIRED" if label else "ENTRY_UNRESOLVED",
                     "observed_sample": None, "video_frame": None, "completed_markers": index}
            states.append(state)
            contracts[f"state-{index}"] = {"unit_id": uid, "fragment_ids": [tid], "unit_fragment_ids": tids,
                "literal_narration": literal, "text_lines": ["Test the meaning", label] if label else ["Test the meaning"],
                "timing_kind": state["timing_kind"], "lexical_target": None if not label else {
                    "unit_id": uid, "fragment_id": tid, "text": anchor, "char_start": start, "char_end": end}}
    return states, contracts


def _svg(raw, lines):
    if b"<!" in raw or b"<?" in raw:
        raise ValueError("SVG declarations/entities are not admitted")
    value = ElementTree.fromstring(raw)
    ns = "{http://www.w3.org/2000/svg}"
    _same(value.attrib, {"width": "1920", "height": "1080", "viewBox": "0 0 1920 1080"}, "SVG canvas differs")
    if value.tag != ns + "svg" or any(element.tag not in {ns + tag for tag in ("svg", "rect", "line", "ellipse", "polygon", "text")} for element in value.iter()):
        raise ValueError("SVG contains an unrecognized element")
    texts = [element for element in value.iter() if element.tag == ns + "text"]
    _same([element.text for element in texts], lines, "visible SVG copy differs from literal contract")
    if len(lines) > 2 or sum(len(line.split()) for line in lines) > 8:
        raise ValueError("two-line/eight-word lock exceeded")
    for element in texts:
        if (element.attrib.get("font-family") != "Arial" or element.attrib.get("font-weight") != "700"
                or int(element.attrib["font-size"]) < 54):
            raise ValueError("SVG typography differs")


def _inventory(reader, directory, receipt, config, *, decode=True):
    names = {sid + ext for sid in config["state_ids"] for ext in (".png", ".svg")} | {config["contact_sheet"]}
    _same(sorted(receipt["artifact_sha256"]), sorted(names), "complete artifact inventory differs")
    actual = {entry.name for entry in reader.path(directory).iterdir()}
    if actual != names | {"receipt.json"}:
        raise ValueError("actual directory inventory differs")
    data, measures = {}, {}
    for name in sorted(names):
        raw = reader.read(directory + "/" + name, receipt["artifact_sha256"][name])
        data[name] = raw
        if decode and name.endswith(".png"):
            measures[name] = _png(raw, config["sheet_size"] if name == config["contact_sheet"] else [1920, 1080])
    return data, measures


def _inspect_template(root, *, template_id, receipt_binding):
    """Reopen all exact dependencies; return one immutable image contract or raise.

    An exception means BLOCKED to callers, never a request to render replacements.
    No cached candidate, timestamps, source FPS or source duration is accepted.
    """
    if type(template_id) is not str or template_id not in TEMPLATES:
        raise ValueError("unknown allowlisted static template")
    config = TEMPLATES[template_id]
    if type(receipt_binding) is not dict or set(receipt_binding) != {"path", "sha256"}:
        raise ValueError("external receipt binding requires path and sha256 only")
    reader = _Reader(root)
    # The caller must retain this binding too: source inspection is versioned
    # code, not a timeless declaration from a historical renderer.
    implementation_raw = _resident(Path(__file__).absolute()).read_bytes()
    reader.read("hero_engine/phase6_av_static_sources.py", _sha(implementation_raw))
    decoder = _verify_decoder(reader)
    receipt_relative = config["directory"] + "/receipt.json"
    expected_path = reader.path(receipt_relative)
    if type(receipt_binding["path"]) is not str or receipt_binding["path"] not in (receipt_relative, str(expected_path)):
        raise ValueError("receipt path differs from allowlisted generation")
    if receipt_binding["sha256"] != config["receipt_sha256"]:
        raise ValueError("external receipt pin differs from allowlist")
    raw = reader.read(receipt_relative, receipt_binding["sha256"], limit=1024**2)
    receipt = _json(raw)
    if _canonical(receipt) != raw:
        raise ValueError("receipt canonical byte identity differs")
    reader.read(config["runner"], config["runner_sha256"])
    pins = {name: INPUT_PINS[name] for name in (PLAN, BIBLE, AUDIT) if name != AUDIT or template_id == "four-criteria-v1"}
    sources = {name: _json(reader.read(name, digest)) for name, digest in pins.items()}
    reader.read_path(FONT, FONT_SHA)  # Only this fixed external font is allowed; no receipt-selected file.
    states, contracts = _states(template_id, sources[PLAN], sources[BIBLE], sources.get(AUDIT))
    design = receipt["design"]
    for actual, expected in (
        (receipt["status"], "STATIC_DESIGN_RENDERED_NOT_PRODUCTION_APPROVED"),
        (receipt["renderer_sha256"], config["runner_sha256"]),
        (receipt["pillow_version"], "12.3.0"), (design["states"], states),
        (design["channel_id"], CHANNEL), (design["style_bible_id"], sources[BIBLE]["style_bible_id"]),
        (design["canvas"], [1920, 1080]), (design["font"], {"path": str(FONT), "sha256": FONT_SHA}),
        (design["input_pins" if template_id == "fear-examples-v1" else "source_bindings"], pins),
        (design["composition_lineage_id" if template_id == "fear-examples-v1" else "lineage_id"], config["lineage_id"]),
    ):
        _same(actual, expected, "frozen design identity does not recompose")
    identity_key = "design" if template_id == "fear-examples-v1" else "plan"
    identity = _sha(_canonical({identity_key: design, "renderer": config["runner_sha256"], "pillow": receipt["pillow_version"]}))[:24]
    if Path(config["directory"]).name != "static-" + identity:
        raise ValueError("generation identity does not recompose")
    data, measures = _inventory(reader, config["directory"], receipt, config)
    for sid, contract in contracts.items():
        _svg(data[sid + ".svg"], contract["text_lines"])
    if template_id == "fear-examples-v1":
        prior_directory = BASE + "fear-examples-design-v1/static-705212615d14f157bf415ab2"
        old_runner = BASE + "fear-examples-design-v1/source-v1-frozen/recipe.py"
        prior_sha = "c763366b51ca7349765ff7feeeb184f051a723dedfba79600ba9c0b4cc803892"
        runner_sha = "5000a6e437bdfef0b954e7afe20ff2f6f41d2a2605f8e8ee60535b20f18f30c8"
        reader.read(old_runner, runner_sha)
        prior = _json(reader.read(prior_directory + "/receipt.json", prior_sha))
        prior_data, _ = _inventory(reader, prior_directory, prior, config, decode=False)
        reused = ["door-0.png", "door-1.png", "morning-0.png", "morning-1.png"]
        _same(receipt["reused_pngs_byte_exact"], reused, "reuse lineage differs")
        for name in reused:
            if data[name] != prior_data[name] or data[name.replace(".png", ".svg")] != prior_data[name.replace(".png", ".svg")]:
                raise ValueError("preserved illustration lineage differs")
    common = {
        "version": VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED",
        "template_id": template_id, "media_kind": "STATIC_IMAGE",
        "source_start_frame": 0, "source_end_frame": 1, "lineage_id": config["lineage_id"],
        "channel_id": CHANNEL, "style_bible_id": sources[BIBLE]["style_bible_id"],
        "observed_sample": None, "video_frame": None,
        "receipt_binding": {"path": str(expected_path), "sha256": config["receipt_sha256"]},
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"]),
        "decoder": decoder,
        "external_font_evidence": {"path": str(FONT), "sha256": FONT_SHA,
                                   "observed_hard_link_count": FONT.stat().st_nlink,
                                   "exception": "FIXED_PINNED_WINDOWS_FONT_ONLY_NOT_MEDIA"},
        "source_technically_verified": True, "source_ready": False,
        "technical_cost_brl": 0, "authority": dict(AUTHORITY),
        "claim_boundary": "Frozen original static pixels and literal contract only; no duration, calibrated timing, motion, rights/publicity admission or production approval.",
    }
    results = {}
    for state_id in config["state_ids"]:
        result = {**common, "state_id": state_id, **contracts[state_id],
                  **measures[state_id + ".png"],
                  "asset_binding": reader.bindings[str(reader.path(config["directory"] + "/" + state_id + ".png"))]}
        result["inspection_id"] = "static-source-" + _sha(_canonical(result))[:24]
        results[state_id] = result
    return results


def inspect_static_sources(root, *, requests):
    """One-build batch: decode each template once, then rehash every dependency.

    No cache survives this call. Repeated states can be used by distinct output
    spans, but cannot gain a different lineage, receipt or temporal authority.
    """
    if type(requests) is not list or not 1 <= len(requests) <= 256:
        raise ValueError("bounded nonempty list of static requests required")
    templates, bindings, results = {}, {}, []
    for request in requests:
        if type(request) is not dict or set(request) != {"template_id", "state_id", "receipt_binding"}:
            raise ValueError("static request fields differ")
        template_id, state_id = request["template_id"], request["state_id"]
        if type(template_id) is not str or template_id not in TEMPLATES:
            raise ValueError("unknown allowlisted static template")
        if type(state_id) is not str or state_id not in TEMPLATES[template_id]["state_ids"]:
            raise ValueError("unknown static state")
        if template_id in templates:
            _same(request["receipt_binding"], bindings[template_id], "conflicting receipt in one build")
        else:
            templates[template_id] = _inspect_template(root, template_id=template_id,
                                                       receipt_binding=request["receipt_binding"])
            bindings[template_id] = request["receipt_binding"]
        results.append(templates[template_id][state_id])
    recheck_static_dependencies(root, results)
    # Do not return aliases that let a consumer mutate another state's proof.
    return _json(_canonical(results))


def recheck_static_dependencies(root, proofs):
    """Rehash same-call inspector proof dependencies, with no pixel decode.

    This is not a proof verifier or approval API: callers must only supply their
    internal sink of results from inspect_static_sources in the current build.
    Checking bytes alone does not validate a candidate's semantics or authority.
    """
    if type(proofs) is not list or not proofs:
        raise ValueError("nonempty same-build static proof sink required")
    reader = _Reader(root)
    dependencies = {}
    for proof in proofs:
        items = proof.get("dependency_bindings") if type(proof) is dict else None
        if type(items) is not list or not items:
            raise ValueError("static dependency sink is empty or invalid")
        seen = set()
        for item in items:
            if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                    or type(item["path"]) is not str or type(item["size_bytes"]) is not int
                    or item["size_bytes"] <= 0 or item["path"] in seen):
                raise ValueError("static dependency binding differs")
            seen.add(item["path"])
            _same(dependencies.setdefault(item["path"], item), item, "conflicting static dependency pins")
        if not set(EXTERNAL_DEPENDENCY_PINS).issubset(seen):
            raise ValueError("font/decoder dependency pins missing")
    for path, item in sorted(dependencies.items()):
        source = Path(path)
        if path in EXTERNAL_DEPENDENCY_PINS:
            if item["sha256"] != EXTERNAL_DEPENDENCY_PINS[path]:
                raise ValueError("fixed external dependency pin differs")
        elif not source.is_relative_to(reader.root):
            raise ValueError("dependency escapes root/exact external allowlist")
        raw = reader.read_path(source, item["sha256"])
        if len(raw) != item["size_bytes"]:
            raise ValueError("dependency size changed during build")
    return len(dependencies)


def inspect_static_source(root, *, template_id, state_id, receipt_binding):
    """Single-state convenience API; same complete verification as the batch."""
    return inspect_static_sources(root, requests=[{
        "template_id": template_id, "state_id": state_id, "receipt_binding": receipt_binding,
    }])[0]


def verify_static_source(candidate, root, *, template_id, state_id, receipt_binding):
    """Independent replay inputs, never candidate-selected dependencies."""
    expected = inspect_static_source(root, template_id=template_id, state_id=state_id,
                                     receipt_binding=receipt_binding)
    _same(candidate, expected, "static inspection replay differs")
    return expected
