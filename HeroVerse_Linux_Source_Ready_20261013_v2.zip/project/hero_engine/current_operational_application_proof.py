"""Proof for one *current* controlled paused application.

This is a forward-only contract.  It deliberately does not replay A7/A9, does
not mutate a historical manifest, and is the only alternate proof family that
the paused-application consumer may read.  The transaction itself remains
responsible for host quiescence, preimages, rollback and commit.
"""
from __future__ import annotations

import hashlib
import json
import tempfile
import subprocess
import unittest
from contextlib import ExitStack, closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import maintenance_paused_application as paused
from .maintenance_unittest_result import consume_execution_result
from .phase5_integrity_maintenance import HISTORICAL_NAME, PACKAGE
from .phase5_integrity_successor_consumer import read_current_integrity_successor
from .phase6_caption_intent_v3 import active_bindings, compile_current_caption_intent
from .phase6_visual_preflight import build_visual_contract
from .phase6_current_production_inputs import current_production_input_contract


VERSION = "current-operational-application-proof-v1"
PURPOSE = "EXACT_CURRENT_OPERATIONAL_PROOF_FOR_CONTROLLED_APPLICATION"
FILES = frozenset(set(paused.PROOF_FILES) | {"operational-bindings.json"})
TEST_PREFIXES = (
    "tests.test_current_audio_research_production.",
    "tests.test_rest_editorial_final_consumers.",
    "tests.test_rest_editorial_native_inputs.",
    # Exact current instrumental source, learned observation and final consumers.
    # Inclusion is regression coverage, not approval of a production music track.
    "tests.test_christian_rest_music_recipe.",
    "tests.test_rest_music_native_inputs.",
    "tests.test_rest_music_render.",
    "tests.test_rest_static_capacity.",
    "tests.test_rest_packaging_successor.",
    "tests.test_music_spectral_observation.",
    "tests.test_music_aesthetic_assessment.",
    "tests.test_rest_music_final_qualification.",
    # Current owned audio/static delivery: its native producers, effect-chain
    # readers and selected manager consumers belong to the application proof.
    "tests.test_audio_static_control_reader.",
    "tests.test_audio_static_composition.",
    "tests.test_audio_static_voice_reuse.",
    "tests.test_audio_static_source_admission.",
    "tests.test_audio_static_rights.",
    "tests.test_audio_static_render_recovery.",
    "tests.test_audio_static_release_gate.",
    "tests.test_audio_static_ready_chain.",
    "tests.test_audio_static_qualification_dispatch.",
    "tests.test_audio_static_qa_completion.",
    "tests.test_audio_static_qa.",
    "tests.test_audio_static_publication_package.",
    "tests.test_audio_static_publication_executor.",
    "tests.test_audio_static_producer.",
    "tests.test_audio_static_packaging.",
    "tests.test_audio_static_owned_observation.",
    "tests.test_audio_static_observer_queue.",
    "tests.test_audio_static_manager_dispatch.",
    "tests.test_audio_static_intelligibility.",
    "tests.test_audio_static_intelligence_current.",
    "tests.test_audio_static_executive_current.",
    "tests.test_audio_static_editorial_gates.",
    "tests.test_audio_static_decoded_observation.",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_goal_ownership_",
    "tests.test_paused_maintenance_application.StoppedManagerIdentityTests.",
    "tests.test_phase5_paused_fingerprint.",
    "tests.test_phase6_codec_voice_reuse.",
    "tests.test_phase6_palette_profile_integration.",
    "tests.test_phase6_visual_codec_controls.SegmentEncoderContractTests.",
    "tests.test_phase6_media.",
    "tests.test_production_capacity.",
    # Current typography producer -> measured admission -> rights -> allocation.
    # Historical receipts remain bound to their original population and bytes.
    "tests.test_procedural_typography_successor.",
    "tests.test_phase6_typography_adoption.",
    "tests.test_phase6_asset_discovery_on_demand.",
    "tests.test_phase6_asset_expansion.",
    "tests.test_phase6_semantic_preflight.",
    "tests.test_phase6_visual_typography.",
    "tests.test_phase6_visual_reference.VisualReferenceTests.",
    "tests.test_phase6_production.",
    "tests.test_phase6_asset_residency.",
    "tests.test_phase6_overlay_ocr.",
    "tests.test_phase6_historical_preproduction.",
    "tests.test_phase6_media_authority.",
    "tests.test_phase6_queue_post_effect.",
    "tests.test_phase6_forward_post_effect_eligibility.",
    "tests.test_maintenance_application_launcher.",
    "tests.test_maintenance_boundary_snapshot.",
    "tests.test_phase6_channel_goal_observer.",
    "tests.test_phase5_integrity_builder.",
    "tests.test_phase5_integrity_maintenance.",
    "tests.test_phase5_integrity_successor_consumer.",
    "tests.test_phase5_current_operational_application_proof.",
    "tests.test_phase6_caption_intent_v3.",
    "tests.test_phase6_integrity_successor_input_gate.",
    "tests.test_phase6_visual_preflight.",
    "tests.test_phase6_segment_cache_recovery.",
    "tests.test_phase6_render_execution_witness.",
    "tests.test_active_resource_preparation.",
    "tests.test_phase6_renderer_recipe.",
    "tests.test_phase6_media_remediation_wait.",
    "tests.test_phase6_goal_media_block.",
    "tests.test_maintenance_migration_atomicity.",
    "tests.test_phase6_maintenance_verification.",
    "tests.test_phase6_maintenance_verification_v12.",
    "tests.test_paused_d116_integration.",
    "tests.test_phase6_manager_cycle_reconciliation.",
    "tests.test_phase6_current_chain.",
    "tests.test_phase6_acceptance.",
    "tests.test_d116_consistent_capture.",
    "tests.test_phase6_signal_evidence.",
    "tests.test_phase6_quality.",
    "tests.test_phase6_publicity.",
    "tests.test_phase6_reporting.",
)

# The composed paused application has an intentionally broad, slow fixture
# population.  Authenticate the exact behavioral tests that exercise the
# public consumer and the fail-receipt contract, rather than treating a timeout
# of unrelated crash-recovery permutations as proof coverage.
EXACT_TEST_IDS = frozenset({
    "tests.test_paused_maintenance_application.HostObserverClassificationTests.test_read_only_reference_and_comment_are_not_invocations",
    "tests.test_paused_maintenance_application.HostObserverClassificationTests.test_operational_dynamic_and_uncertain_commands_remain_blocked",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_executor_or_task_active_blocks",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_host_probe_scopes_apply_signature_to_python_executor",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_process_uncertain_or_alive_blocks",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_race_after_preflight_blocks_before_commit",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_pause_required_and_not_synthesized",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_second_commit_failure_restores_exact_views",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_transaction_commits_media_and_goal_from_same_proposed_state",
    "tests.test_phase6_control_cycle.Phase6ControlCycleTests.test_maintenance_revalidation_allows_only_local_cycle_evidence_writes",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_reference_contract_rejects_unsupported_name_before_preparation",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_reference_contract_alias_preserves_external_envelope_anchor",
    "tests.test_phase6_forward_post_effect_eligibility.ForwardPostEffectEligibilityTests.test_terminal_forward_commit_is_replayed_without_queue_or_evidence_writes",
    "tests.test_phase6_forward_post_effect_eligibility.ForwardPostEffectEligibilityTests.test_terminal_forward_replay_rejects_eligibility_tampering",
    "tests.test_phase6_control_cycle.Phase6ControlCycleTests.test_observing_fixture_separates_paused_witness_and_preserves_source",
    "tests.test_phase6_control_cycle.Phase6ControlCycleTests.test_quality_fixture_never_reads_live_runtime",
    "tests.test_phase6_integrity_hardening.Phase6IntegrityHardeningTests.test_quality_verifier_rejects_a_changed_latest_evaluation",
    "tests.test_phase6_queue.Phase6QueueTests.test_read_only_snapshot_never_initializes_or_creates_wal_sidecars",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_valid_composed_preparation_commit_and_idempotent_repeat",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_current_operational_proof_wires_forward_journal_once",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_preexisting_eligibility_receipt_remains_pinned",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_new_eligibility_tamper_blocks_finalization",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_new_eligibility_missing_blocks_finalization",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_new_eligibility_binding_mismatch_blocks_finalization",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_new_eligibility_foreign_path_blocks_finalization",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_forward_new_eligibility_does_not_admit_foreign_addition",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_committed_forward_replay_preserves_complete_database_sets",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_committed_forward_replay_rejects_outcome_mismatch_and_rolls_back",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_committed_forward_replay_lost_protection_blocks_finalization",
    "tests.test_paused_maintenance_application.PausedMaintenanceApplicationTests.test_failed_receipt_never_serializes_arbitrary_permission_message",
})


class CurrentOperationalProofError(PermissionError):
    pass


class NotCurrentOperationalProof(CurrentOperationalProofError):
    """The envelope belongs to the immutable legacy reader instead."""


def _digest(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical(value: Any) -> str:
    return _digest(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def _json(raw: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise CurrentOperationalProofError(f"{label} is invalid JSON") from exc
    if not isinstance(value, dict):
        raise CurrentOperationalProofError(f"{label} is not an object")
    return value


def _relative(root: Path, offered: Path) -> str:
    offered = Path(offered)
    if not offered.is_absolute():
        return offered.as_posix()
    try:
        return offered.resolve(strict=True).relative_to(root).as_posix()
    except (OSError, ValueError) as exc:
        raise CurrentOperationalProofError("proof path is outside the workspace") from exc


def _binding(root: Path, relative: str) -> dict[str, Any]:
    path = root / relative
    raw = path.read_bytes()
    return {"path": relative, "sha256": _digest(raw), "size_bytes": len(raw)}


def build_test_inventory(full_inventory: dict[str, Any]) -> dict[str, Any]:
    """Select exactly the producers and consumers of this proof family."""
    if full_inventory.get("schema_version") != "1.1.0" or not isinstance(full_inventory.get("files"), list):
        raise CurrentOperationalProofError("full test inventory contract differs")
    rows = []
    for item in full_inventory["files"]:
        identifiers = [test_id for test_id in item.get("test_ids", [])
                       if test_id.startswith(TEST_PREFIXES) or test_id in EXACT_TEST_IDS]
        if identifiers:
            rows.append({"path": item["path"], "content_hash": item["content_hash"], "test_ids": identifiers})
    selected = [identifier for row in rows for identifier in row["test_ids"]]
    if not selected or len(selected) != len(set(selected)):
        raise CurrentOperationalProofError("operational proof test population is empty or ambiguous")
    result = {
        "schema_version": "1.1.0", "discovery_pattern": "EXACT_CURRENT_OPERATIONAL_APPLICATION_V1",
        "file_count": len(rows), "method_count": len(selected), "alias_count": 0,
        "test_count": len(selected), "tests_hash": _canonical(selected),
        "load_tests_aliases": [], "aliases_hash": _canonical([]), "files": rows,
    }
    return result


def public_verifier_receipt(verified: dict[str, Any]) -> dict[str, Any]:
    """Match the execution receipt consumed by the shared strict reader."""
    if not isinstance(verified, dict) or not isinstance(verified.get("outcomes"), dict):
        raise CurrentOperationalProofError("verifier result is incomplete")
    return {key: value for key, value in verified.items() if key != "outcomes"}


def test_command(inventory: dict[str, Any], *, executable: str) -> list[str]:
    """Compact transport only; resolve and compare every selected method first.

    Full modules are safe selectors only when their actual unittest population
    equals the authenticated inventory. Partial modules retain exact IDs.
    Discovery never executes test bodies, and aliases/duplicates fail closed.
    """
    expected = [item for row in inventory["files"] for item in row["test_ids"]]
    selectors: list[str] = []
    for row in inventory["files"]:
        names = row["test_ids"]
        prefix = next((prefix for prefix in TEST_PREFIXES
                       if all(name.startswith(prefix) for name in names)), None)
        selectors.extend([prefix.rstrip(".")] if prefix else names)
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromNames(selectors)

    def identifiers(test):
        if isinstance(test, unittest.TestSuite):
            for child in test:
                yield from identifiers(child)
        else:
            yield test.id()

    actual = list(identifiers(suite))
    if loader.errors or len(actual) != len(set(actual)) or sorted(actual) != sorted(expected):
        raise CurrentOperationalProofError("compact test selectors differ from the exact inventory")
    command = [executable, "-B", "-u", "-X", "utf8", "-m", "unittest", "-v", *selectors]
    if len(subprocess.list2cmdline(command).encode("utf-16-le")) // 2 + 1 > 32767:
        raise CurrentOperationalProofError("test command exceeds the Windows CreateProcess limit")
    return command


def _visual_binding(root: Path) -> dict[str, Any]:
    paths = {
        "take_plan": "output/production/phase6/video-002/production/take_plan.json",
        "creative_treatment_plan": "output/production/phase6/video-002/production/creative_treatment_plan.json",
        "channel_style_bible": "output/production/phase6/video-002/production/channel_style_bible.json",
    }
    try:
        documents = {name: _json((root / path).read_bytes(), name) for name, path in paths.items()}
        contract = build_visual_contract(documents["take_plan"], documents["creative_treatment_plan"], documents["channel_style_bible"])
    except Exception as exc:
        raise CurrentOperationalProofError("current visual contract cannot be evaluated") from exc
    if contract.get("status") != "PASS":
        raise CurrentOperationalProofError("current visual contract is blocked")
    return {"documents": {name: _binding(root, path) for name, path in paths.items()},
            "contract_sha256": _canonical(contract), "take_count": contract.get("take_count")}


def current_operational_bindings(root: Path) -> dict[str, Any]:
    """Recompute the current forward-only inputs without granting an effect."""
    root = Path(root).resolve(strict=True)
    try:
        successor = read_current_integrity_successor(root)
        caption_bindings = active_bindings(root)
        caption_intent = compile_current_caption_intent(root, bindings=caption_bindings)
    except Exception as exc:
        raise CurrentOperationalProofError("current integrity or caption consumer rejected inputs") from exc
    commit_path = "output/runtime/gestor-central/maintenance-runs/task62-integrity-successor-proof-pathfix-20260916/commit-result.json"
    rollback_path = "output/runtime/gestor-central/maintenance-runs/task58-forward-caption-and-integrity-20260916/integrity-successor-stage/rollback-preimage.json"
    commit = _json((root / commit_path).read_bytes(), "integrity successor commit")
    if (commit.get("status") != "COMMITTED_SUCCESSOR_VIEW_WHILE_PAUSED"
            or commit.get("successor_sha256") != successor["successor_sha256"]
            or commit.get("historical_manifest_unchanged") is not True):
        raise CurrentOperationalProofError("committed integrity successor evidence differs")
    return {
        "version": VERSION,
        "candidate": paused.candidate_identity(root),
        "integrity_successor": {
            "current": successor,
            "commit_receipt": _binding(root, commit_path),
            "rollback_preimage": _binding(root, rollback_path),
            "historical_manifest": _binding(root, (PACKAGE / HISTORICAL_NAME).as_posix()),
        },
        "captions": {"bindings": caption_bindings, "intent_sha256": _canonical(caption_intent)},
        # Configuration is not in candidate_identity's source folders. Bind it
        # explicitly so a proof cannot authorize a different research catalog.
        "current_audio_research": _binding(root, "config/current_audio_research.json"),
        "visual": _visual_binding(root),
        # This is a forward-only re-open of the current media inputs.  It
        # remains a zero-authority binding; it cannot replay the old compiler
        # or convert the historical WAITING record into a render approval.
        "current_production_inputs": current_production_input_contract(root),
        "historical_gaps": [{
            "gap_id": "A9_READER_SOURCE_UNAVAILABLE",
            "status": "HISTORICAL_PROVENANCE_GAP",
            "path": "hero_engine/phase6_narration_audio_inventory.py",
            "required_sha256": "sha256:11e56ca46d3f4928882ece936500b49a428caf7cbd1ff542069eceb47db4bde6",
        }],
        "authority": {"controlled_apply": False, "restart": False, "render": False, "publication": False},
    }


def read_current_operational_proof(root: Path, envelope_path: Path, expected_hash: str,
                                   expected_candidate: str, stack: ExitStack) -> dict[str, Any]:
    """Authenticate a current operational proof for the existing apply boundary."""
    root = Path(root).resolve(strict=True)
    if not (isinstance(expected_hash, str) and len(expected_hash) == 71 and expected_hash.startswith("sha256:")
            and isinstance(expected_candidate, str) and len(expected_candidate) == 64):
        raise CurrentOperationalProofError("external anchors are invalid")
    envelope_path = paused._path(root, _relative(root, envelope_path))
    if envelope_path.parent.parent != root / paused.RUNS:
        raise CurrentOperationalProofError("proof run is not under maintenance-runs")
    pins = []
    def read(path: Path) -> bytes:
        pin = stack.enter_context(closing(paused.p._PausedCancelPin(path)))
        pins.append(pin)
        return pin.payload
    raw = read(envelope_path)
    if _digest(raw) != expected_hash:
        raise CurrentOperationalProofError("proof envelope hash differs")
    envelope = _json(raw, "proof envelope")
    if envelope.get("purpose") != PURPOSE:
        raise NotCurrentOperationalProof("proof purpose belongs to another reader")
    if (set(envelope) != {"schema_version", "purpose", "root", "proof_run", "candidate_sha256", "files"}
            or envelope.get("schema_version") != "1.0.0" or envelope.get("root") != str(root)
            or envelope.get("proof_run") != envelope_path.parent.relative_to(root).as_posix()
            or envelope.get("candidate_sha256") != expected_candidate or set(envelope.get("files", {})) != FILES):
        raise CurrentOperationalProofError("proof envelope contract differs")
    payloads = {name: read(envelope_path.parent / name) for name in sorted(FILES)}
    if any(_digest(payloads[name]) != envelope["files"][name] for name in FILES):
        raise CurrentOperationalProofError("proof file hash differs")
    docs = {name: _json(raw, name) for name, raw in payloads.items() if name.endswith(".json")}
    current = paused.candidate_identity(root)
    if current["source_set_sha256"] != expected_candidate or docs["candidate-before.json"] != current or docs["candidate-after.json"] != current:
        raise CurrentOperationalProofError("candidate differs from current source")
    if docs["dependencies-before.json"] != docs["dependencies-after.json"] or docs["dependencies-before.json"] != paused.dependency_identity():
        raise CurrentOperationalProofError("dependency identity differs")
    if docs["operational-bindings.json"] != current_operational_bindings(root):
        raise CurrentOperationalProofError("current operational bindings differ")
    with tempfile.TemporaryDirectory(prefix=".current-operational-inventory-", dir=envelope_path.parent) as directory:
        manifest = paused.p.build_validation_manifests(root, output_dir=Path(directory))
        full_inventory = paused.p._read(root / manifest["test_inventory_path"])
        actual_schemas = paused.p._read(root / manifest["schema_inventory_path"])
    inventory = docs["test-inventory.json"]
    if inventory != build_test_inventory(full_inventory) or docs["schema-inventory.json"] != actual_schemas:
        raise CurrentOperationalProofError("current inventory differs")
    process = docs["full-process-result.json"]
    if not (process.get("exit_code") == 0 and process.get("timed_out") is False and isinstance(process.get("test_pid"), int)
            and process["test_pid"] > 0 and paused.p._parse(process["started_at"]) < paused.p._parse(process["finished_at"]) <= datetime.now(timezone.utc)):
        raise CurrentOperationalProofError("process proof differs")
    result = consume_execution_result(result=docs["verifier-result.json"], inventory_bytes=payloads["test-inventory.json"],
        expected_inventory_hash=envelope["files"]["test-inventory.json"], expected_test_count=inventory["test_count"],
        stdout_bytes=payloads["unittest.stdout.log"], stderr_bytes=payloads["unittest.stderr.log"], process_exit_code=process["exit_code"])
    if not (isinstance(process.get("wall_seconds"), (int, float)) and process["wall_seconds"] >= result["duration_seconds"]):
        raise CurrentOperationalProofError("process duration differs")
    before, after = docs["preservation-before.json"], docs["preservation-after.json"]
    if before != after or set(before) != {"operation", "task_enabled", "automation_paused", "files"} or before.get("operation") != "PAUSED" or before.get("task_enabled") is not False or before.get("automation_paused") is not True or not before.get("files"):
        raise CurrentOperationalProofError("proof preservation differs")
    return {"candidate": current, "regression": result, "pins": pins, "proof_files": envelope["files"],
            "proof_path": envelope_path.relative_to(root).as_posix(), "protected_hashes": before["files"],
            "regression_finished_at": process["finished_at"], "regression_process": process,
            "proof_family": "CURRENT_OPERATIONAL",
            "authority": {"controlled_apply": True, "restart": False, "render": False, "publication": False}}
