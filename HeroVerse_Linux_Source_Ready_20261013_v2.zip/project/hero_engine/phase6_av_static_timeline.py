"""Typed owned-still contracts shared by A and C; never assigns word timing.

Source index [0,1) denotes one decoded PNG, not an invented source video.
Output holds remain explicit Stage-A frame intervals. Source validation does
not approve reading pace, visual variety, final freeze QA or publicity.
"""
from __future__ import annotations

from pathlib import Path

from . import phase6_av_static_sources as sources
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-static-timeline-v1"
STATIC_FILTER = "scale=1920:1080:flags=lanczos"


def _same(actual, expected, message):
    if canonical_sha(actual) != canonical_sha(expected):
        raise ValueError(message)


def source_request(value):
    if type(value) is not dict or set(value) != {"template_id", "state_id", "receipt_binding"}:
        raise ValueError("static source requires explicit template/state/receipt")
    binding = value["receipt_binding"]
    if type(binding) is not dict or set(binding) != {"path", "sha256"}:
        raise ValueError("static receipt binding differs")
    digest = binding["sha256"]
    if type(digest) is not str or len(digest) != 71 or not digest.startswith("sha256:"):
        raise ValueError("static receipt requires prefixed SHA-256")
    return {"template_id": value["template_id"], "state_id": value["state_id"],
            "receipt_binding": {"path": binding["path"], "sha256": digest[7:]}}


def inspect_span(root, span):
    """Consumer-side source/lineage/index recheck, not timeline approval."""
    return inspect_spans(root, [span])[0]


def inspect_spans(root, spans):
    """Decode each static family once within this call; never a persistent cache."""
    if not spans:
        return []
    proofs = sources.inspect_static_sources(root, requests=[source_request(span["static_source"]) for span in spans])
    for span, proof in zip(spans, proofs, strict=True):
        _check_source(root, span, proof)
    return proofs


def _check_source(root, span, proof):
    root = Path(root).resolve(strict=True)
    actual = proof["asset_binding"]
    source_path = Path(actual["path"])
    if not source_path.is_relative_to(root):
        raise ValueError("static asset is outside the canonical workspace")
    _same(span["asset_binding"], {"path": source_path.relative_to(root).as_posix(),
        "sha256": "sha256:" + actual["sha256"]}, "static PNG binding differs")
    _same(span["source_frame_count"], 1, "one PNG is exactly one source frame")
    if "source_start_frame" in span:
        _same([span["source_start_frame"], span["source_end_frame"]], [0, 1],
              "static source indices cannot impersonate a source duration")
    _same(span["lineage_id"], proof["lineage_id"], "static composition lineage differs")
    _same(span["fragment_ids"], proof["fragment_ids"], "static literal fragment differs")
    if span["media_kind"] != "STATIC_IMAGE":
        raise ValueError("static media kind differs")


def validate_intent(reader, intent, units, render_spans):
    """Validate declared states even if their render intervals are not yet bound.

Each family/unit is indivisible: intro plus every lexical reveal, in order.
Required lexical targets therefore cannot disappear from A's holdout union.
"""
    contracts = intent["span_contracts"]
    typed = intent["schema_version"] == "1.2.0"
    base = {"span_id", "fragment_ids", "narrative_function", "semantic_alignment",
            "retention_job", "asset_binding", "source_frame_count", "lineage_id"}
    selected, seen = [], set()
    for contract in contracts:
        keys = base | ({"media_kind", "static_source"} if typed else set())
        if type(contract) is not dict or set(contract) != keys:
            raise ValueError("versioned span intent fields differ")
        if not typed:
            continue
        kind = contract["media_kind"]
        if kind not in {"VIDEO_CFR", "STATIC_IMAGE"}:
            raise ValueError("unknown visual media kind")
        if kind == "VIDEO_CFR":
            if contract["static_source"] is not None:
                raise ValueError("video cannot carry a static source contract")
            continue
        request = source_request(contract["static_source"])
        key = (request["template_id"], request["state_id"])
        if key in seen:
            raise ValueError("duplicate static state cannot create source variety")
        seen.add(key)
        selected.append((contract, request))
    proofs = {}
    by_unit = {unit["unit_id"]: unit for unit in units}
    schedule = {span["span_id"]: span for span in render_spans}
    groups = {}
    inspected = sources.inspect_static_sources(reader.root, requests=[request for _, request in selected]) if selected else []
    for (contract, request), proof in zip(selected, inspected, strict=True):
        _check_source(reader.root, contract, proof)
        uid = proof["unit_id"]
        unit = by_unit.get(uid)
        if unit is None:
            raise ValueError("static source belongs to an unknown narration unit")
        _same([unit["text"], unit["take_ids"]],
              [proof["literal_narration"], proof["unit_fragment_ids"]],
              "static source belongs to another frozen narration")
        # The font is independently fixed and reopened by the inspector; it is
        # not generalized into an arbitrary external path accepted by Reader.
        for binding in proof["dependency_bindings"]:
            path = Path(binding["path"])
            if path.is_relative_to(reader.root):
                raw = reader.read(path.relative_to(reader.root).as_posix(), "sha256:" + binding["sha256"])
                if len(raw) != binding["size_bytes"]:
                    raise ValueError("static dependency size changed")
            elif sources.EXTERNAL_DEPENDENCY_PINS.get(str(path)) != binding["sha256"]:
                raise ValueError("unknown external static dependency")
        sid = contract["span_id"]
        requirements = [row for row in intent["event_requirements"] if row["span_id"] == sid]
        if len(requirements) != 1:
            raise ValueError("each static state requires exactly one entry event")
        req = requirements[0]
        lexical = proof["lexical_target"]
        if lexical is None:
            expected = ("UNIT_BOUNDARY", "WHOLE_UNIT_PCM_START", None, None, None)
        else:
            tolerance = req["maximum_uncertainty_samples"]
            if type(tolerance) is not int or tolerance <= 0:
                raise ValueError("static lexical reveal needs explicit uncertainty")
            expected = ("SEMANTIC_CHANGE", "NOT_BEFORE_ANCHOR_START",
                        lexical["char_start"], lexical["char_end"], tolerance)
        _same([req[key] for key in ("kind", "trigger", "char_start", "char_end", "maximum_uncertainty_samples")],
              list(expected), "static lexical reveal cannot be reclassified or removed")
        if req["unit_id"] != uid:
            raise ValueError("static event unit differs")
        proofs[sid] = proof
        groups.setdefault((request["template_id"], uid), []).append((contract, proof, req))
    for (template, uid), rows in groups.items():
        # Closed supported families; no arbitrary inclusion/exclusion recipe.
        expected_states = (list(sources.TEMPLATES[template]["state_ids"]) if template == "four-criteria-v1"
                           else [rows[0][1]["state_id"].rsplit("-", 1)[0] + f"-{i}" for i in (0, 1)])
        if [proof["state_id"] for _, proof, _ in rows] != expected_states:
            raise ValueError("static unit requires its complete ordered state sequence")
        placed = [schedule.get(contract["span_id"]) for contract, _, _ in rows]
        if any(placed) and not all(placed):
            raise ValueError("partially scheduled static narration unit")
        if all(placed):
            unit = by_unit[uid]
            if (placed[0]["start_frame"] * 800 != unit["pcm_start_sample"]
                    or placed[-1]["end_frame"] * 800 != unit["slot_end_sample_exclusive"]
                    or any(a["end_frame"] != b["start_frame"] for a, b in zip(placed, placed[1:]))):
                raise ValueError("static state sequence must cover its exact whole-unit slot")
    return proofs


def verify_entry_frames(proofs, spans, events):
    """A missing entry is incomplete, never a fabricated timestamp."""
    by_span = {span["span_id"]: span for span in spans}
    for sid in proofs:
        found = [event for event in events if event["span_id"] == sid]
        if sid in by_span and found and found[0]["frame"] != by_span[sid]["start_frame"]:
            raise ValueError("static entry event must coincide with the visible state change")
