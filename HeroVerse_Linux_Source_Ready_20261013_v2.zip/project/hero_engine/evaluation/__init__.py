"""Evaluation helpers for champion/challenger comparisons."""

from .gold_standard import benchmark_analysis, benchmark_fixtures

__all__ = ["benchmark_analysis", "benchmark_fixtures"]
