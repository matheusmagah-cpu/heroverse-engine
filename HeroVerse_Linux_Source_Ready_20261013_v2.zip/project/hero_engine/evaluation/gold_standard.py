"""Field-by-field champion/challenger evaluation against Phase 1 gold data."""

from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from hero_engine.contracts.analysis import file_sha256, validate_analysis, validate_benchmark
from hero_engine.mining.pipeline import FIXTURE_IDS, GOLD_ROOT, OUTPUT_ROOT, ROOT, read_json, write_json
from hero_engine.mining.semantics import content_tokens, relpath


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _normalize_text(text: str | None) -> str:
    return " ".join(content_tokens(text))


def _transcript_text(analysis: dict[str, Any]) -> str:
    return " ".join(
        (segment.get("reviewed_text") or segment.get("raw_text") or "")
        for segment in analysis["transcript"]["segments"]
    )


def _text_similarity(left: str | None, right: str | None) -> float:
    a, b = _normalize_text(left), _normalize_text(right)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return round(SequenceMatcher(None, a, b, autojunk=False).ratio(), 6)


def _token_f1(expected: Iterable[str], observed: Iterable[str]) -> tuple[float, int]:
    left = set(content_tokens(" ".join(expected)))
    right = set(content_tokens(" ".join(observed)))
    if not left and not right:
        return 1.0, 0
    if not left or not right:
        return 0.0, len(left)
    true_positive = len(left & right)
    precision = true_positive / len(right)
    recall = true_positive / len(left)
    return (round(2 * precision * recall / (precision + recall), 6) if true_positive else 0.0), len(left)


def _literal_token_f1(expected: Iterable[str], observed: Iterable[str]) -> tuple[float, int]:
    left = set(re.findall(r"[A-Za-z0-9]{2,}", " ".join(expected).lower()))
    right = set(re.findall(r"[A-Za-z0-9]{2,}", " ".join(observed).lower()))
    if not left and not right:
        return 1.0, 0
    if not left or not right:
        return 0.0, len(left)
    true_positive = len(left & right)
    precision = true_positive / len(right)
    recall = true_positive / len(left)
    return (round(2 * precision * recall / (precision + recall), 6) if true_positive else 0.0), len(left)


def _boundary_f1(expected: list[int], observed: list[int], tolerance_ms: int) -> tuple[float, int]:
    expected = sorted(expected)
    observed = sorted(observed)
    used: set[int] = set()
    matches = 0
    for boundary in expected:
        candidates = [
            (abs(boundary - candidate), index)
            for index, candidate in enumerate(observed)
            if index not in used and abs(boundary - candidate) <= tolerance_ms
        ]
        if candidates:
            _, index = min(candidates)
            used.add(index)
            matches += 1
    if not expected and not observed:
        return 1.0, 0
    precision = matches / len(observed) if observed else 0.0
    recall = matches / len(expected) if expected else 0.0
    score = 2 * precision * recall / (precision + recall) if matches else 0.0
    return round(score, 6), len(expected)


def _boundaries(items: list[dict[str, Any]]) -> list[int]:
    if len(items) <= 1:
        return []
    return [int(item["end_ms"]) for item in items[:-1]]


def _ocr_text(analysis: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for hook in analysis["hooks"]:
        values.extend(hook.get("screen_text", []))
    for take in analysis["takes"]:
        values.extend(take.get("screen_text", []))
    thumbnail = analysis["packaging"]["thumbnail_analysis"]["value"]
    if isinstance(thumbnail, dict):
        values.append(str(thumbnail.get("ocr_text") or ""))
    elif isinstance(thumbnail, str):
        values.append(thumbnail)
    return values


def _literal_ocr_score(video_id: str, candidate: dict[str, Any]) -> tuple[float, int, list[str]]:
    sidecar_path = GOLD_ROOT / "evaluation" / "ocr_literal_v1.json"
    sidecar = read_json(sidecar_path)
    fixture = next(item for item in sidecar["fixtures"] if item["video_id"] == video_id)
    expected: list[str] = []
    observed: list[str] = []
    artifacts = [relpath(sidecar_path, ROOT)]
    for annotation in fixture["observations"]:
        start_ms, end_ms = int(annotation["start_ms"]), int(annotation["end_ms"])
        expected.extend(annotation["literal_lines"])
        artifacts.append(annotation["artifact"])
        for take in candidate["takes"]:
            if int(take["end_ms"]) > start_ms and int(take["start_ms"]) < end_ms:
                observed.extend(take.get("screen_text", []))
    score, sample_size = _literal_token_f1(expected, observed)
    return score, sample_size, artifacts


def _thumbnail_literal_score(gold: dict[str, Any], candidate: dict[str, Any]) -> tuple[float, int]:
    value = gold["packaging"]["thumbnail_analysis"]["value"]
    description = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    uppercase = re.findall(r"(?<![A-Za-z])[A-Z][A-Z'& ]{2,}(?![A-Za-z])", description)
    expected = [item.strip() for item in uppercase if item.strip()]
    if not expected:
        expected = [str(gold["source"]["title"]).split("ᴴᴰ", 1)[0].strip()]
    thumbnail = candidate["packaging"]["thumbnail_analysis"]["value"]
    observed = str(thumbnail.get("ocr_text") or "") if isinstance(thumbnail, dict) else str(thumbnail or "")
    return _literal_token_f1(expected, [observed])


def _hook_score(gold: dict[str, Any], candidate: dict[str, Any]) -> float:
    scores: list[float] = []
    by_window = {item["window"]: item for item in candidate["hooks"]}
    for expected in gold["hooks"]:
        observed = by_window.get(expected["window"])
        if observed is None:
            scores.append(0.0)
            continue
        exact = float(
            observed["start_ms"] == expected["start_ms"]
            and observed["end_ms"] == expected["end_ms"]
        )
        spoken = _text_similarity(expected.get("spoken_text"), observed.get("spoken_text"))
        screen, _ = _token_f1(expected.get("screen_text", []), observed.get("screen_text", []))
        scores.append(0.4 * exact + 0.4 * spoken + 0.2 * screen)
    return round(sum(scores) / max(1, len(scores)), 6)


def _narrative_score(gold: dict[str, Any], candidate: dict[str, Any]) -> tuple[float, int]:
    boundary, sample = _boundary_f1(
        _boundaries(gold["narrative_segments"]),
        _boundaries(candidate["narrative_segments"]),
        5000,
    )
    pairs = zip(gold["narrative_segments"], candidate["narrative_segments"])
    pair_count = min(len(gold["narrative_segments"]), len(candidate["narrative_segments"]))
    role = sum(left["role"] == right["role"] for left, right in pairs) / max(1, pair_count)
    return round(0.65 * boundary + 0.35 * role, 6), sample


def _metric(field: str, metric: str, value: float, threshold: float, sample_size: int,
            evidence_ids: list[str], limitations: list[str] | None = None) -> dict[str, Any]:
    item = {
        "field": field,
        "metric": metric,
        "value": round(float(value), 6),
        "threshold": float(threshold),
        "passed": float(value) >= float(threshold),
        "sample_size": int(sample_size),
        "evidence_ids": evidence_ids,
    }
    if limitations:
        item["limitations"] = limitations
    return item


def benchmark_analysis(candidate_path: Path, manifest_path: Path, *, cache_consistent: bool) -> dict[str, Any]:
    candidate = read_json(candidate_path)
    run_manifest = read_json(manifest_path)
    video_id = candidate["source"]["video_id"]
    gold_path = GOLD_ROOT / video_id / "video_mining.json"
    gold = read_json(gold_path)
    validation = validate_analysis(candidate, root=ROOT)
    evidence_ids = list(validation.evidence_ids)
    gold_duration = int(gold["source"]["duration_ms"])
    candidate_duration = int(candidate["source"]["duration_ms"])
    duration_score = max(0.0, 1 - abs(gold_duration - candidate_duration) / gold_duration)
    transcript_score = _text_similarity(_transcript_text(gold), _transcript_text(candidate))
    ocr_score, ocr_sample, ocr_evidence = _literal_ocr_score(video_id, candidate)
    hook_score = _hook_score(gold, candidate)
    take_score, take_sample = _boundary_f1(
        _boundaries(gold["takes"]), _boundaries(candidate["takes"]), 500,
    )
    narrative_score, narrative_sample = _narrative_score(gold, candidate)
    title_match = float(candidate["source"]["title"] == gold["source"]["title"])
    thumbnail_score, thumbnail_sample = _thumbnail_literal_score(gold, candidate)
    packaging_score = 0.7 * title_match + 0.3 * thumbnail_score
    rights_score = float(
        candidate["rights"]["status"] == gold["rights"]["status"]
        and candidate["rights"]["production_eligible"] == gold["rights"]["production_eligible"]
    )
    resource = run_manifest["resources"]
    latency_target = max(1.0, candidate_duration / 1000 * 3.0)
    latency_score = min(1.0, latency_target / max(0.001, float(resource["wall_seconds"])))
    metrics = [
        _metric("TIMESTAMPS", "normalized_duration_agreement", duration_score, 0.999, 1,
                [candidate["analysis_id"], gold["analysis_id"]]),
        _metric("TRANSCRIPT", "normalized_sequence_similarity", transcript_score, 0.90,
                len(candidate["transcript"]["segments"]), [candidate["analysis_id"], gold["analysis_id"]],
                ["Candidate and gold use the same base.en family but gold contains human-reviewed corrections."]),
        _metric("OCR", "unique_content_token_f1", ocr_score, 0.35, ocr_sample,
                ocr_evidence, [
                    "Metric is restricted to literal sidecar windows; the broader gold OCR is not exhaustive.",
                    "Sidecar is visually inspected by Codex but remains pending owner approval.",
                    "Candidate scans start/mid/end only in the opening and ending priority windows.",
                ]),
        _metric("HOOK_WINDOWS", "exact_window_weighted_text_similarity", hook_score, 0.75, 4,
                [item["evidence"][0]["evidence_id"] for item in candidate["hooks"]]),
        _metric("TAKES", "boundary_f1_tolerance_500ms", take_score, 0.90, take_sample,
                [item["evidence"][0]["evidence_id"] for item in candidate["takes"]]),
        _metric("NARRATIVE", "boundary_role_composite_tolerance_5000ms", narrative_score, 0.55,
                narrative_sample, [item["evidence"][0]["evidence_id"] for item in candidate["narrative_segments"]],
                ["Narrative roles remain unreviewed hypotheses; boundaries use a gold-independent lexical/pause model."]),
        _metric("PACKAGING", "title_exact_plus_thumbnail_literal_token_f1", packaging_score, 0.75,
                1 + thumbnail_sample,
                [item["evidence_id"] for item in candidate["packaging"]["evidence"]]),
        _metric("RIGHTS_PROVENANCE", "status_and_production_gate_exact", rights_score, 1.0, 2,
                candidate["rights"]["evidence_artifacts"]),
        _metric("SCHEMA", "schema_and_evidence_contract", float(validation.passed), 1.0,
                len(evidence_ids), evidence_ids),
        _metric("COST", "external_api_zero_cost", float(resource["external_api_cost_usd"] == 0), 1.0, 1,
                [relpath(manifest_path, ROOT)], ["Electricity and local hardware depreciation are not priced."]),
        _metric("LATENCY", "three_times_realtime_budget_score", latency_score, 0.5, 1,
                [relpath(manifest_path, ROOT)], ["Wall-clock benchmark is hardware- and cache-dependent."]),
        _metric("CONSISTENCY", "cache_replay_same_semantic_hash", float(cache_consistent), 1.0, 1,
                [run_manifest["semantic_hash"]]),
    ]
    critical: list[str] = []
    if candidate["source"]["content_hash"] != gold["source"]["content_hash"]:
        critical.append("source hash diverges from gold fixture")
    if not validation.schema_valid:
        critical.append("candidate violates video_mining schema")
    if not validation.evidence_resolvable:
        critical.append("candidate contains unresolved evidence artifacts")
    if candidate["rights"]["production_eligible"] and not gold["rights"]["production_eligible"]:
        critical.append("candidate relaxed the gold rights gate")
    if critical:
        decision = "REJECT_CHALLENGER"
    elif all(metric["passed"] for metric in metrics):
        decision = "INCONCLUSIVE"
    else:
        decision = "KEEP_CHAMPION"
    benchmark = {
        "schema_version": "0.1.0-draft",
        "review_status": "AWAITING_REVIEW",
        "benchmark_id": f"phase2-benchmark-{video_id}-{run_manifest['job_key'][:16]}",
        "gold_standard_analysis_id": gold["analysis_id"],
        "candidate_analysis_id": candidate["analysis_id"],
        "gold_standard_version": "phase1-human-v1",
        "pipeline_version": run_manifest["pipeline_version"],
        "fixture_hash": file_sha256(gold_path),
        "field_metrics": metrics,
        "critical_regressions": critical,
        "cost_delta": float(resource["external_api_cost_usd"]),
        "latency_delta": round(float(resource["wall_seconds"]) - candidate_duration / 1000, 6),
        "decision": decision,
        "created_at": utc_now(),
    }
    validate_benchmark(benchmark, raise_on_error=True)
    return benchmark


def benchmark_fixtures(results: list[dict[str, Any]]) -> dict[str, Any]:
    by_id = {result["video_id"]: result for result in results}
    first_manifest = read_json(Path(by_id[FIXTURE_IDS[0]]["manifest"]))
    pipeline_version = first_manifest["pipeline_version"]
    benchmark_dir = OUTPUT_ROOT / "benchmarks" / pipeline_version
    benchmark_dir.mkdir(parents=True, exist_ok=True)
    benchmarks: list[dict[str, Any]] = []
    for video_id in FIXTURE_IDS:
        result = by_id[video_id]
        benchmark = benchmark_analysis(
            Path(result["analysis"]), Path(result["manifest"]),
            cache_consistent=bool(result.get("consistency_verified")),
        )
        write_json(benchmark_dir / f"{video_id}.json", benchmark)
        benchmarks.append(benchmark)
    fields: dict[str, dict[str, Any]] = {}
    for field in [metric["field"] for metric in benchmarks[0]["field_metrics"]]:
        selected = [
            metric for benchmark in benchmarks for metric in benchmark["field_metrics"]
            if metric["field"] == field
        ]
        mean = sum(item["value"] for item in selected) / len(selected)
        fields[field] = {
            "mean": round(mean, 6),
            "passed_fixtures": sum(item["passed"] for item in selected),
            "total_fixtures": len(selected),
            "thresholds": sorted({item["threshold"] for item in selected}),
        }
    summary = {
        "schema_version": "1.0.0",
        "status": "AWAITING_REVIEW",
        "pipeline_version": benchmarks[0]["pipeline_version"],
        "created_at": utc_now(),
        "fixture_count": len(benchmarks),
        "decisions": {video_id: benchmark["decision"] for video_id, benchmark in zip(FIXTURE_IDS, benchmarks)},
        "critical_regression_count": sum(len(item["critical_regressions"]) for item in benchmarks),
        "field_summary": fields,
        "automatic_promotion_permitted": False,
        "promotion_gate": "Owner review is required even if every threshold passes.",
    }
    preregistration_path = OUTPUT_ROOT / "learning" / "cycle-001" / "preregistration.json"
    if preregistration_path.is_file():
        preregistration = read_json(preregistration_path)
        baseline_fields = preregistration["baseline"]["field_metrics"]
        summary["baseline_comparison"] = {
            field: {
                "baseline_mean": float(baseline_fields[field]),
                "candidate_mean": values["mean"],
                "delta": round(values["mean"] - float(baseline_fields[field]), 6),
            }
            for field, values in fields.items()
        }
    write_json(benchmark_dir / "summary.json", summary)
    return {"benchmarks": benchmarks, "summary": summary, "directory": str(benchmark_dir)}
