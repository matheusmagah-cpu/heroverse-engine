"""Source-specific editorial graphics, not an all-format generator.

This recipe reconstructs the fact/forecast exercise literally. It does not
replace the production TakePlan, certify rights, or authorize a media job.
Geometry is measured before FFmpeg; pixel/motion review remains independent.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .phase6_visual_recipe import (
    _Region, _drawtext_filter, _place_copy, _write_text_atomic, OUTPUT_FILTERS,
)

RECIPE = "heroverse-fact-forecast-two-column-v2"
CHANNEL = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO = "phase6-video-002-prepublication"
EXPECTED_NARRATION = (
    "Begin with two columns.",
    "In the first,",
    "write only what happened.",
    "In the second,",
    "write what fear says it means.",
    "The meeting changed is a fact.",
    "My future is ruined is a forecast.",
    "The person has not replied is a fact.",
    "I will always be abandoned is a sentence fear wrote about your",
    "identity.",
    "This separation does not deny pain.",
    "It stops pain from pretending to know the whole future.",
)
STAGES = (
    # Text changes are timed at the original take boundary, not on a loop.
    ("BOTH", "", "", "LABELS", "Name the two distinct columns before adding an example."),
    ("LEFT", "", "", "LABELS", "Direct attention to the first column, preserving its position."),
    ("LEFT", "What happened", "", "INSTRUCTION", "Show only the task named in the first-column instruction."),
    ("RIGHT", "What happened", "", "INSTRUCTION", "Move attention, not the columns, to the second column."),
    ("RIGHT", "What happened", "What fear says it means", "INSTRUCTION", "Complete the paired instruction without a third category."),
    ("LEFT", "The meeting changed.", "", "MEETING", "Introduce the fact; withhold the forecast until its narration."),
    ("RIGHT", "The meeting changed.", "My future is ruined.", "MEETING", "Contrast the narrated forecast with the still-visible fact."),
    ("LEFT", "The person has not replied.", "", "REPLY", "Replace the example pair together, not just its conclusion."),
    ("RIGHT", "The person has not replied.", "I will always be abandoned.", "REPLY", "Mark the feared conclusion as a forecast, not as a fact."),
    ("RIGHT", "The person has not replied.", "I will always be abandoned.", "REPLY", "Hold the example across the continuation word identity."),
    ("BOTH", "The person has not replied.", "I will always be abandoned.", "REPLY", "Keep evidence and interpretation distinct while acknowledging pain."),
    ("BOTH", "What happened", "What fear predicts", "SUMMARY", "Close with the distinction the exercise actually demonstrated."),
)


def canonical_sha(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def build_two_column_plan(take_plan: dict[str, Any]) -> dict[str, Any]:
    """Compile an isolated, exact-narration source plan. No I/O or mutation."""
    if (take_plan.get("channel_id"), take_plan.get("video_id")) != (CHANNEL, VIDEO):
        raise PermissionError("two-column recipe is confined to the exact HeroVerse candidate")
    if (take_plan.get("format_pack_id"), take_plan.get("format_pack_version")) != (
        "fp-broll-cinematic-narration", "1.1.0"
    ):
        raise PermissionError("recipe is outside the versioned cinematic clip FormatPack")
    if not take_plan.get("take_plan_id") or not take_plan.get("style_bible_id"):
        raise PermissionError("source plan identity is missing")
    all_takes = take_plan.get("takes") or []
    ids = [item.get("take_id") for item in all_takes]
    if len(ids) != len(set(ids)):
        raise PermissionError("duplicate take identities")
    selected = [item for item in all_takes if item.get("take_id") in {
        f"take-{number:03d}" for number in range(12, 24)
    }]
    if [item["take_id"] for item in selected] != [f"take-{n:03d}" for n in range(12, 24)]:
        raise PermissionError("two-column takes are missing or out of order")
    if tuple(item.get("narration") for item in selected) != EXPECTED_NARRATION:
        raise PermissionError("narration differs from the reviewed literal exercise")
    previous_end = selected[0]["start_ms"]
    origin = previous_end
    scenes = []
    for take, stage in zip(selected, STAGES, strict=True):
        start, end = take.get("start_ms"), take.get("end_ms")
        if type(start) is not int or type(end) is not int or start != previous_end or end <= start:
            raise PermissionError("discontinuous or invalid source timing")
        if (end - start) * 30 % 1000:
            raise PermissionError("source timing is not frame-exact at 30 fps")
        previous_end = end
        focus, left, right, example, rationale = stage
        scenes.append({
            "take_id": take["take_id"], "start_ms": start - origin, "end_ms": end - origin,
            "original_start_ms": start, "original_end_ms": end,
            "narration": take["narration"], "focus": focus,
            "left_text": left, "right_text": right, "example": example,
            "narrative_rationale": rationale,
        })
    plan = {
        "schema_version": "1.0.0", "recipe_id": RECIPE,
        "scope": "ISOLATED_SOURCE_PROTOTYPE_NOT_PRODUCTION",
        "channel_id": CHANNEL, "video_id": VIDEO,
        "source_take_plan_id": take_plan["take_plan_id"],
        "source_take_plan_sha256": canonical_sha(take_plan),
        "style_bible_id": take_plan["style_bible_id"],
        "column_count": 2, "column_order": ["FACT", "FORECAST"],
        "camera": "LOCKED_NO_PAN_OR_ZOOM", "motion": "NARRATION_BOUND_STATE_CHANGES",
        "width": 1920, "height": 1080, "fps": 30,
        "duration_ms": previous_end - origin, "scenes": scenes,
        "rights_status": "NOT_ASSESSED_FOR_PRODUCTION",
        "technical_cost_brl": 0, "queue_authorized": False, "publication_authorized": False,
    }
    plan["plan_id"] = "two-column-plan-" + canonical_sha(plan).split(":")[1][:24]
    return plan


def validate_two_column_plan(plan: dict[str, Any]) -> None:
    schema_path = Path(__file__).resolve().parents[1] / "schemas/phase6_two_column_source_plan.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(plan)
    body = {key: value for key, value in plan.items() if key != "plan_id"}
    if plan["plan_id"] != "two-column-plan-" + canonical_sha(body).split(":")[1][:24]:
        raise PermissionError("source plan identity no longer matches its content")
    for index, (scene, stage) in enumerate(zip(plan["scenes"], STAGES, strict=True)):
        if (scene["take_id"] != f"take-{index+12:03d}"
                or scene["narration"] != EXPECTED_NARRATION[index]
                or tuple(scene[k] for k in ("focus", "left_text", "right_text", "example", "narrative_rationale")) != stage):
            raise PermissionError("source plan changed a reviewed semantic state")
        if (scene["original_end_ms"]-scene["original_start_ms"] != scene["end_ms"]-scene["start_ms"]
                or scene["original_start_ms"]-scene["start_ms"] != plan["scenes"][0]["original_start_ms"]):
            raise PermissionError("source plan changed its original timeline mapping")


def inspect_two_column_layout(scene: dict[str, Any], *, font: Path) -> dict[str, Any]:
    """Measure the actual FFmpeg copy, with no overlaid third panel or badge."""
    if scene.get("focus") not in {"LEFT", "RIGHT", "BOTH"}:
        raise ValueError("unknown column focus")
    if scene.get("example") not in {"LABELS", "INSTRUCTION", "MEETING", "REPLY", "SUMMARY"}:
        raise ValueError("unknown reviewed example")
    duration = scene["end_ms"] - scene["start_ms"]
    if type(duration) is not int or duration <= 0:
        raise ValueError("invalid scene duration")
    overlays = []
    boxes = [
        "drawbox=x=154:y=116:w=80:h=8:color=0xD7A94A:t=fill",
        "drawbox=x=154:y=354:w=774:h=446:color=0x2C5364@0.24:t=fill",
        "drawbox=x=992:y=354:w=774:h=446:color=0x2C5364@0.24:t=fill",
        "drawbox=x=154:y=866:w=1612:h=2:color=0x2C5364:t=fill",
    ]

    def text(role: str, value: str, region: _Region, size: int = 60, color: str = "0xE8EDF2"):
        if not isinstance(value, str):
            raise TypeError("graphic copy must be a string; null is not renderable copy")
        if value:
            overlays.append(_place_copy(
                role=role, source=value, font_path=font, preferred_size=size,
                region=region, color=color, filename=f"{role}.txt",
            ))

    text("title", "Separate fact from forecast.", _Region(154, 154, 1612, 160, "left"), 84)
    text("left-header", "FACT", _Region(190, 380, 700, 110, "left"), 64, "0xD7A94A")
    text("right-header", "FORECAST", _Region(1028, 380, 700, 110, "left"), 64, "0xD7A94A")
    text("left-value", scene["left_text"], _Region(190, 524, 700, 236, "left"), 64)
    text("right-value", scene["right_text"], _Region(1028, 524, 700, 236, "left"), 64)
    text("channel-system", "TRUTH / RESPONSIBILITY / TODAY", _Region(154, 889, 1612, 88, "left"), 54)
    # Focus is a steady strip, never a looping animation or readability-reducing pan.
    for side, x in (("LEFT", 154), ("RIGHT", 992)):
        if scene["focus"] in {side, "BOTH"}:
            boxes.append(f"drawbox=x={x}:y=354:w=774:h=6:color=0xD7A94A:t=fill")
    return {
        "recipe_id": RECIPE, "take_id": scene["take_id"], "column_count": 2,
        "column_order": ["FACT", "FORECAST"], "focus": scene["focus"],
        "camera": "LOCKED_NO_PAN_OR_ZOOM", "decorations": boxes, "overlays": overlays,
        "all_text_safe": all(item["safe_area_pass"] for item in overlays),
        "all_copy_preserved": all(item["copy_preserved"] for item in overlays),
        "minimum_font_size": min(item["font_size"] for item in overlays),
    }


def compile_two_column_filters(plan: dict[str, Any], *, font: Path, work_dir: Path) -> list[str]:
    """Each source state is active on [start,end), avoiding one-frame collisions."""
    if plan.get("recipe_id") != RECIPE or plan.get("column_count") != 2:
        raise PermissionError("wrong source recipe or column count")
    if plan.get("queue_authorized") is not False or plan.get("publication_authorized") is not False:
        raise PermissionError("a source proof cannot authorize a production action")
    validate_two_column_plan(plan)
    scenes = plan.get("scenes") or []
    if not scenes:
        raise ValueError("source plan has no scenes")
    previous_end = 0
    layouts = []
    for scene in scenes:
        if scene["start_ms"] != previous_end:
            raise ValueError("source scene gap or overlap")
        previous_end = scene["end_ms"]
        layouts.append(inspect_two_column_layout(scene, font=font))
    if previous_end != plan.get("duration_ms"):
        raise ValueError("source duration drift")
    # All geometry has passed before any text file is written.
    work_dir.mkdir(parents=True, exist_ok=True)
    filters = ["setsar=1"]
    for index, (scene, layout) in enumerate(zip(scenes, layouts, strict=True)):
        enable = f":enable='gte(t,{scene['start_ms']/1000:.3f})*lt(t,{scene['end_ms']/1000:.3f})'"
        filters.extend(item + enable for item in layout["decorations"])
        for overlay in layout["overlays"]:
            path = work_dir / f"scene-{index:02d}-{overlay['filename']}"
            _write_text_atomic(path, overlay["render_text"])
            filters.append(_drawtext_filter(font, path, overlay) + enable)
    filters.extend(OUTPUT_FILTERS)
    return filters
