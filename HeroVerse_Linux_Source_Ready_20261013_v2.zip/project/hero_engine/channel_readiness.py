from __future__ import annotations

import hashlib
import json
import math
import re
import urllib.request
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any


CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
CHANNEL_HANDLE = "@heroverse74"
YPP_SOURCE = "https://support.google.com/youtube/answer/72851"
CHANNEL_CUSTOMIZATION_SOURCE = "https://support.google.com/youtube/answer/3027950"
MONETIZATION_POLICY_SOURCE = "https://support.google.com/youtube/answer/1311392"


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _parse_duration_seconds(value: str) -> int:
    match = re.fullmatch(r"P(?:\d+D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", value or "")
    if not match:
        return 0
    hours, minutes, seconds = (int(item or 0) for item in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def _chunked(values: list[str], size: int = 50) -> list[list[str]]:
    return [values[index:index + size] for index in range(0, len(values), size)]


def _analytics_table(report: dict[str, Any]) -> list[dict[str, Any]]:
    names = [item["name"] for item in report.get("columnHeaders") or []]
    return [dict(zip(names, row)) for row in report.get("rows") or []]


def _download(url: str, destination: Path) -> dict[str, Any]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "HeroVerseChannelAudit/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        body = response.read()
    destination.write_bytes(body)
    result: dict[str, Any] = {
        "path": destination.as_posix(),
        "sha256": hashlib.sha256(body).hexdigest(),
        "bytes": len(body),
    }
    try:
        from PIL import Image

        with Image.open(destination) as image:
            result["width"] = image.width
            result["height"] = image.height
            result["format"] = image.format
    except Exception:
        result.update({"width": None, "height": None, "format": None})
    return result


def _contact_sheet(items: list[dict[str, Any]], destination: Path) -> dict[str, Any] | None:
    try:
        from PIL import Image, ImageDraw, ImageOps
    except ImportError:
        return None
    if not items:
        return None
    thumb_w, thumb_h, label_h, columns = 320, 180, 44, 4
    rows = math.ceil(len(items) / columns)
    canvas = Image.new("RGB", (columns * thumb_w, rows * (thumb_h + label_h)), "#10131a")
    draw = ImageDraw.Draw(canvas)
    for index, item in enumerate(items):
        image = Image.open(item["local_path"]).convert("RGB")
        image = ImageOps.fit(image, (thumb_w, thumb_h))
        x = (index % columns) * thumb_w
        y = (index // columns) * (thumb_h + label_h)
        canvas.paste(image, (x, y))
        title = re.sub(r"\s+", " ", item["title"])
        label = f"{index + 1:02d} | {item['views']} views | {title[:38]}"
        draw.rectangle((x, y + thumb_h, x + thumb_w, y + thumb_h + label_h), fill="#10131a")
        draw.text((x + 7, y + thumb_h + 8), label, fill="#ffffff")
    destination.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(destination, quality=92)
    body = destination.read_bytes()
    return {
        "path": destination.as_posix(),
        "sha256": hashlib.sha256(body).hexdigest(),
        "bytes": len(body),
        "width": canvas.width,
        "height": canvas.height,
    }


def collect_owned_channel_snapshot(
    youtube: Any,
    analytics: Any,
    *,
    output_dir: Path,
    today: date | None = None,
) -> dict[str, Any]:
    observed_at = _now()
    observed_day = today or date.today()
    channel_response = youtube.channels().list(
        part="id,snippet,statistics,brandingSettings,status,contentDetails,topicDetails",
        mine=True,
    ).execute()
    items = channel_response.get("items") or []
    if len(items) != 1 or items[0].get("id") != CHANNEL_ID:
        raise RuntimeError("Authenticated channel did not match the pinned HeroVerse channel")
    channel = items[0]
    snippet = channel.get("snippet") or {}
    branding = channel.get("brandingSettings") or {}
    channel_branding = branding.get("channel") or {}
    image_branding = branding.get("image") or {}
    statistics = channel.get("statistics") or {}
    status = channel.get("status") or {}
    uploads_id = channel["contentDetails"]["relatedPlaylists"]["uploads"]

    upload_ids: list[str] = []
    page_token: str | None = None
    while True:
        response = youtube.playlistItems().list(
            part="contentDetails", playlistId=uploads_id, maxResults=50, pageToken=page_token
        ).execute()
        upload_ids.extend(item["contentDetails"]["videoId"] for item in response.get("items") or [])
        page_token = response.get("nextPageToken")
        if not page_token:
            break

    video_resources: list[dict[str, Any]] = []
    for chunk in _chunked(upload_ids):
        response = youtube.videos().list(
            part="id,snippet,contentDetails,statistics,status", id=",".join(chunk), maxResults=50
        ).execute()
        video_resources.extend(response.get("items") or [])

    privacy_counts: Counter[str] = Counter()
    public_videos: list[dict[str, Any]] = []
    thumbnails_dir = output_dir / "evidence" / "thumbnails"
    for video in video_resources:
        privacy = video.get("status", {}).get("privacyStatus") or "unknown"
        privacy_counts[privacy] += 1
        if privacy != "public":
            continue
        video_snippet = video.get("snippet") or {}
        video_stats = video.get("statistics") or {}
        thumbnails = video_snippet.get("thumbnails") or {}
        selected = thumbnails.get("maxres") or thumbnails.get("standard") or thumbnails.get("high") or {}
        thumbnail_url = selected.get("url")
        local_path = thumbnails_dir / f"{video['id']}.jpg"
        thumbnail_evidence = _download(thumbnail_url, local_path) if thumbnail_url else None
        public_videos.append({
            "video_id": video["id"],
            "title": video_snippet.get("title") or "",
            "description_length": len(video_snippet.get("description") or ""),
            "published_at": video_snippet.get("publishedAt"),
            "default_language": video_snippet.get("defaultLanguage"),
            "duration_seconds": _parse_duration_seconds(video.get("contentDetails", {}).get("duration") or ""),
            "views": int(video_stats.get("viewCount") or 0),
            "likes": int(video_stats.get("likeCount") or 0),
            "comments": int(video_stats.get("commentCount") or 0),
            "tag_count": len(video_snippet.get("tags") or []),
            "thumbnail_url": thumbnail_url,
            "thumbnail_evidence": thumbnail_evidence,
            "local_path": str(local_path),
        })
    public_videos.sort(key=lambda item: item["published_at"] or "", reverse=True)

    playlists = youtube.playlists().list(
        part="id,snippet,contentDetails,status", mine=True, maxResults=50
    ).execute().get("items") or []
    sections = youtube.channelSections().list(
        part="id,snippet,contentDetails", mine=True
    ).execute().get("items") or []

    end = observed_day - timedelta(days=1)
    start = end - timedelta(days=89)
    metric_names = (
        "views,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,"
        "subscribersGained,subscribersLost,likes,comments,shares"
    )
    totals_report = analytics.reports().query(
        ids="channel==MINE", startDate=start.isoformat(), endDate=end.isoformat(), metrics=metric_names
    ).execute()
    daily_report = analytics.reports().query(
        ids="channel==MINE", startDate=start.isoformat(), endDate=end.isoformat(), metrics=metric_names,
        dimensions="day", sort="day",
    ).execute()
    public_ids = [item["video_id"] for item in public_videos]
    video_analytics: list[dict[str, Any]] = []
    if public_ids:
        video_report = analytics.reports().query(
            ids="channel==MINE", startDate=start.isoformat(), endDate=end.isoformat(), metrics=metric_names,
            dimensions="video", filters=f"video=={','.join(public_ids)}", sort="-views", maxResults=200,
        ).execute()
        video_analytics = _analytics_table(video_report)
        metadata_by_id = {item["video_id"]: item for item in public_videos}
        for row in video_analytics:
            metadata = metadata_by_id.get(row.get("video"), {})
            row["title"] = metadata.get("title")
            row["duration_seconds"] = metadata.get("duration_seconds")

    impressions_payload: dict[str, Any]
    try:
        impressions_total_report = analytics.reports().query(
            ids="channel==MINE", startDate=start.isoformat(), endDate=end.isoformat(),
            metrics="impressions,impressionClickThroughRate",
        ).execute()
        impression_video_rows: list[dict[str, Any]] = []
        if public_ids:
            impression_video_report = analytics.reports().query(
                ids="channel==MINE", startDate=start.isoformat(), endDate=end.isoformat(),
                metrics="impressions,impressionClickThroughRate", dimensions="video",
                filters=f"video=={','.join(public_ids)}", sort="-impressions", maxResults=200,
            ).execute()
            impression_video_rows = _analytics_table(impression_video_report)
            metadata_by_id = {item["video_id"]: item for item in public_videos}
            for row in impression_video_rows:
                metadata = metadata_by_id.get(row.get("video"), {})
                row["title"] = metadata.get("title")
                row["duration_seconds"] = metadata.get("duration_seconds")
        impressions_payload = {
            "status": "AVAILABLE",
            "totals": (_analytics_table(impressions_total_report) or [{}])[0],
            "public_video_rows": impression_video_rows,
            "interpretation": "YouTube thumbnail impressions and CTR do not cover every surface equally; compare only like-for-like traffic and format cohorts.",
        }
    except Exception as exc:
        impressions_payload = {
            "status": "UNAVAILABLE",
            "reason": f"{type(exc).__name__}: {exc}",
            "totals": {},
            "public_video_rows": [],
            "interpretation": "No CTR claim is permitted until the private Analytics metric is available.",
        }

    avatar_url = (snippet.get("thumbnails") or {}).get("high", {}).get("url")
    banner_url = image_branding.get("bannerExternalUrl")
    avatar = _download(avatar_url, output_dir / "evidence" / "avatar.jpg") if avatar_url else None
    banner = _download(banner_url, output_dir / "evidence" / "banner.jpg") if banner_url else None
    contact_items = [{**item, "local_path": item["local_path"]} for item in public_videos if item["thumbnail_evidence"]]
    contact_sheet = _contact_sheet(contact_items, output_dir / "evidence" / "thumbnail-contact-sheet.jpg")

    for item in public_videos:
        item.pop("local_path", None)
    return {
        "schema_version": "1.0.0",
        "snapshot_id": f"channel-snapshot-{hashlib.sha256((CHANNEL_ID + observed_at).encode()).hexdigest()[:16]}",
        "observed_at": observed_at,
        "evidence_class": "PRIVATE_AUTHENTICATED_API",
        "channel_id": channel["id"],
        "handle": snippet.get("customUrl"),
        "profile": {
            "title": snippet.get("title") or "",
            "description": snippet.get("description") or "",
            "default_language": snippet.get("defaultLanguage"),
            "country": snippet.get("country"),
            "keywords": channel_branding.get("keywords") or "",
            "avatar": avatar,
            "banner": banner,
            "trailer_video_id": channel_branding.get("unsubscribedTrailer"),
        },
        "status": {
            "privacy_status": status.get("privacyStatus"),
            "is_linked": status.get("isLinked"),
            "long_uploads_status": status.get("longUploadsStatus"),
            "made_for_kids": status.get("madeForKids"),
            "monetization_enabled": status.get("isChannelMonetizationEnabled"),
        },
        "statistics": {
            "subscribers": int(statistics.get("subscriberCount") or 0),
            "public_video_count": int(statistics.get("videoCount") or 0),
            "public_view_count": int(statistics.get("viewCount") or 0),
        },
        "catalog": {
            "public_videos": public_videos,
            "privacy_counts_in_uploads_playlist": dict(sorted(privacy_counts.items())),
            "owned_playlist_count": len(playlists),
            "owned_playlists": [
                {"playlist_id": item["id"], "title": item["snippet"]["title"], "privacy": item["status"]["privacyStatus"], "item_count": item["contentDetails"]["itemCount"]}
                for item in playlists
            ],
            "channel_section_count": len(sections),
            "channel_sections": [
                {"section_id": item["id"], "type": item["snippet"].get("type"), "title": item["snippet"].get("title")}
                for item in sections
            ],
            "contact_sheet": contact_sheet,
        },
        "analytics_90d": {
            "start_date": start.isoformat(),
            "end_date": end.isoformat(),
            "totals": (_analytics_table(totals_report) or [{}])[0],
            "daily_rows": _analytics_table(daily_report),
            "public_video_rows": video_analytics,
            "impressions": impressions_payload,
            "qualification_note": "Analytics watch time is not equivalent to YPP qualified public watch hours.",
        },
        "source_refs": [
            "youtubeData:v3/channels.mine",
            "youtubeData:v3/playlistItems.uploads",
            "youtubeData:v3/videos",
            "youtubeData:v3/playlists.mine",
            "youtubeData:v3/channelSections.mine",
            "youtubeAnalytics:v2/reports.channel==MINE",
        ],
        "external_cost_usd": 0,
    }


def _normalized_title(title: str) -> str:
    title = re.sub(r"#[\w-]+", "", title.lower())
    title = re.sub(r"[^a-z0-9]+", " ", title)
    return " ".join(title.split())


def build_channel_readiness_audit(
    snapshot: dict[str, Any],
    *,
    studio_observation: dict[str, Any],
    created_at: str | None = None,
) -> dict[str, Any]:
    created = created_at or _now()
    profile = snapshot["profile"]
    catalog = snapshot["catalog"]
    videos = catalog["public_videos"]
    latest = max((item["published_at"] for item in videos if item["published_at"]), default=None)
    latest_day = datetime.fromisoformat(latest.replace("Z", "+00:00")).date() if latest else None
    observed_day = datetime.fromisoformat(snapshot["observed_at"]).date()
    inactivity_days = (observed_day - latest_day).days if latest_day else None
    normalized = [_normalized_title(item["title"]) for item in videos]
    duplicate_groups = [title for title, count in Counter(normalized).items() if title and count > 1]
    english_metadata = sum(1 for item in videos if (item.get("default_language") or "").lower().startswith("en"))
    keyword_text = profile["keywords"].lower()
    christian_terms = ["christian", "faith", "god", "bible", "jesus", "spiritual"]
    legacy_terms = ["superhero", "marvel", "movie shorts", "ai animation", "ai generated"]
    christian_hits = [term for term in christian_terms if term in keyword_text]
    legacy_hits = [term for term in legacy_terms if term in keyword_text]
    description = profile["description"]
    daily_claim = "daily" in description.lower() or "every day" in description.lower()
    title_lengths = [len(item["title"]) for item in videos]
    hashtags_in_titles = [len(re.findall(r"#[\w-]+", item["title"])) for item in videos]
    subscribers = snapshot["statistics"]["subscribers"]
    ypp = studio_observation["ypp"]
    brand_public_status = studio_observation["profile"]["brand_public_propagation_status"]
    analytics_by_video = sorted(
        snapshot["analytics_90d"]["public_video_rows"],
        key=lambda item: item.get("views", 0),
        reverse=True,
    )
    top_performers = analytics_by_video[:5]
    weak_prophecy_or_secrecy = [
        item for item in analytics_by_video
        if any(term in (item.get("title") or "").lower() for term in ["prophecy", "secret", "hidden"])
        and item.get("views", 0) <= 50
    ]
    analytics_totals = snapshot["analytics_90d"]["totals"]
    net_subscribers_90d = int(analytics_totals.get("subscribersGained", 0)) - int(analytics_totals.get("subscribersLost", 0))
    observed_net_subscribers_per_day = net_subscribers_90d / 90
    observed_qualified_shorts_views_per_day = ypp["observed"]["qualified_shorts_views_90d"] / 90
    ad_subscriber_gap = max(0, ypp["ads_thresholds"]["subscribers"] - subscribers)
    early_subscriber_gap = max(0, ypp["early_thresholds"]["subscribers"] - subscribers)
    thirty_day = {
        "objective_days": 30,
        "ads_subscriber_gap": ad_subscriber_gap,
        "required_net_subscribers_per_day": round(ad_subscriber_gap / 30, 4),
        "early_subscriber_gap": early_subscriber_gap,
        "required_net_subscribers_per_day_early": round(early_subscriber_gap / 30, 4),
        "observed_net_subscribers_90d": net_subscribers_90d,
        "observed_net_subscribers_per_day_90d": round(observed_net_subscribers_per_day, 4),
        "subscriber_acceleration_multiple_required_ads": round((ad_subscriber_gap / 30) / observed_net_subscribers_per_day, 4) if observed_net_subscribers_per_day > 0 else None,
        "subscriber_acceleration_multiple_required_early": round((early_subscriber_gap / 30) / observed_net_subscribers_per_day, 4) if observed_net_subscribers_per_day > 0 else None,
        "observed_qualified_watch_hours": ypp["observed"]["qualified_watch_hours_365d"],
        "required_qualified_watch_hours_per_day_ads": round(max(0, ypp["ads_thresholds"]["qualified_watch_hours"] - ypp["observed"]["qualified_watch_hours_365d"]) / 30, 4),
        "required_qualified_shorts_views_per_day_ads": round(max(0, ypp["ads_thresholds"]["qualified_shorts_views_90d"] - ypp["observed"]["qualified_shorts_views_90d"]) / 30, 4),
        "required_qualified_shorts_views_per_day_early": round(max(0, ypp["early_thresholds"]["qualified_shorts_views_90d"] - ypp["observed"]["qualified_shorts_views_90d"]) / 30, 4),
        "observed_qualified_shorts_views_per_day_90d": round(observed_qualified_shorts_views_per_day, 4),
        "shorts_acceleration_multiple_required_ads": round((max(0, ypp["ads_thresholds"]["qualified_shorts_views_90d"] - ypp["observed"]["qualified_shorts_views_90d"]) / 30) / observed_qualified_shorts_views_per_day, 4) if observed_qualified_shorts_views_per_day > 0 else None,
        "shorts_acceleration_multiple_required_early": round((max(0, ypp["early_thresholds"]["qualified_shorts_views_90d"] - ypp["observed"]["qualified_shorts_views_90d"]) / 30) / observed_qualified_shorts_views_per_day, 4) if observed_qualified_shorts_views_per_day > 0 else None,
        "forecast_status": "UNAVAILABLE_INSUFFICIENT_ACTIVE_BASELINE",
        "guarantee": False,
        "reason": "A target rate is arithmetic, not a performance forecast; the channel has no current consistent publishing baseline and zero qualified long-form watch hours.",
    }

    gates = [
        {
            "gate": "CHANNEL_IDENTITY",
            "critical": True,
            "status": "PASS" if snapshot["channel_id"] == CHANNEL_ID and snapshot["handle"] == CHANNEL_HANDLE else "FAIL",
            "evidence": [f"channel_id={snapshot['channel_id']}", f"handle={snapshot['handle']}", f"title={profile['title']}"],
            "required_action": None,
        },
        {
            "gate": "POSITIONING_COHERENCE",
            "critical": True,
            "status": "FAIL" if legacy_hits else "PASS",
            "evidence": [f"current_christian_keyword_hits={christian_hits}", f"legacy_keyword_hits={legacy_hits}", "ChannelDNA targets English Christian motivation and practical faith."],
            "required_action": "Replace legacy superhero/Marvel/AI-production keywords with a narrow Christian motivation, practical faith and spiritual-growth vocabulary." if legacy_hits else None,
        },
        {
            "gate": "PROMISE_INTEGRITY",
            "critical": True,
            "status": "FAIL" if daily_claim and (inactivity_days is None or inactivity_days > 2) else "PASS",
            "evidence": [f"description_claims_daily={daily_claim}", f"days_since_latest_public_upload={inactivity_days}", f"latest_public_upload={latest}"],
            "required_action": "Remove the unsupported daily cadence promise or establish and maintain the stated schedule before restoring it." if daily_claim and (inactivity_days is None or inactivity_days > 2) else None,
        },
        {
            "gate": "HOME_CONVERSION_ARCHITECTURE",
            "critical": False,
            "status": (
                "FAIL" if not studio_observation["home_tab"]["enabled"]
                else "NEEDS_REVIEW" if not all([
                    studio_observation["home_tab"]["channel_trailer_present"],
                    studio_observation["home_tab"]["returning_viewer_spotlight_present"],
                ])
                else "PASS"
            ),
            "evidence": [f"home_tab_enabled={studio_observation['home_tab']['enabled']}", f"channel_sections_api={catalog['channel_section_count']}", f"trailer_video_id={profile['trailer_video_id']}", f"owned_playlist_count_api={catalog['owned_playlist_count']}"],
            "required_action": "Configure a non-subscriber trailer and returning-viewer spotlight using a policy-cleared, identity-aligned video; the Home tab and automatic content shelves are already live and publicly verified." if studio_observation["home_tab"]["enabled"] and not all([studio_observation["home_tab"]["channel_trailer_present"], studio_observation["home_tab"]["returning_viewer_spotlight_present"]]) else ("Enable Home, then configure a non-subscriber trailer, returning-viewer spotlight and coherent long-form/Shorts topic sections." if not studio_observation["home_tab"]["enabled"] else None),
        },
        {
            "gate": "BRAND_MESSAGE_ALIGNMENT",
            "critical": True,
            "status": (
                "FAIL" if studio_observation["profile"]["banner_message_conflicts_with_channel_dna"]
                else "BLOCKED" if brand_public_status != "VERIFIED_PUBLIC"
                else "PASS"
            ),
            "evidence": [
                f"banner_copy={studio_observation['profile']['banner_copy']}",
                f"banner_categories={studio_observation['profile']['banner_categories']}",
                f"conflicts_with_channel_dna={studio_observation['profile']['banner_message_conflicts_with_channel_dna']}",
                f"public_propagation_status={brand_public_status}",
                "ChannelDNA targets practical Christian faith, not superheroes or unlimited fantasy worlds.",
            ],
            "required_action": (
                "Replace the live banner only after an independently reviewed asset communicates practical Christian faith and preserves mobile-safe legibility."
                if studio_observation["profile"]["banner_message_conflicts_with_channel_dna"]
                else "Wait for public propagation and verify the exact banner on the public channel before publication."
                if brand_public_status != "VERIFIED_PUBLIC"
                else None
            ),
        },
        {
            "gate": "PROFILE_CONVERSION_ASSETS",
            "critical": True,
            "status": "FAIL" if not all([profile["avatar"], profile["banner"], studio_observation["profile"]["video_watermark_present"]]) or studio_observation["profile"]["avatar_contains_export_annotation"] else "PASS",
            "evidence": [
                f"avatar_present={bool(profile['avatar'])}",
                f"avatar_contains_export_annotation={studio_observation['profile']['avatar_contains_export_annotation']}",
                f"banner_present={bool(profile['banner'])}",
                f"links_count={studio_observation['profile']['links_count']}",
                f"business_email_present={studio_observation['profile']['business_email_present']}",
                f"video_watermark_present={studio_observation['profile']['video_watermark_present']}",
            ],
            "required_action": "Validate avatar/banner against the Style Bible; add a branded subscribe watermark. Links and business email are recommended but not required for the first controlled publication.",
        },
        {
            "gate": "CATALOG_LANGUAGE_AND_DUPLICATION",
            "critical": False,
            "status": "FAIL" if duplicate_groups or english_metadata != len(videos) else "PASS",
            "evidence": [f"public_videos={len(videos)}", f"english_metadata={english_metadata}", f"normalized_duplicate_titles={duplicate_groups}"],
            "required_action": "Remove duplicate packaging and keep all new public metadata in English; review legacy public duplicates before YPP application." if duplicate_groups or english_metadata != len(videos) else None,
        },
        {
            "gate": "PACKAGING_DISCIPLINE",
            "critical": False,
            "status": "NEEDS_REVIEW",
            "evidence": [f"title_length_min={min(title_lengths) if title_lengths else None}", f"title_length_median={sorted(title_lengths)[len(title_lengths)//2] if title_lengths else None}", f"title_length_max={max(title_lengths) if title_lengths else None}", f"max_hashtags_in_title={max(hashtags_in_titles) if hashtags_in_titles else None}", f"contact_sheet={catalog['contact_sheet']['path'] if catalog['contact_sheet'] else None}"],
            "required_action": "Run blind thumbnail/title challenger review and only promote a winner after promise, mobile legibility, novelty and policy-risk checks pass; CTR remains unproven until impressions exist.",
        },
        {
            "gate": "YPP_ELIGIBILITY_PROGRESS",
            "critical": False,
            "status": "NEEDS_REVIEW",
            "evidence": [f"subscribers={subscribers}", f"qualified_watch_hours_365d={ypp['observed']['qualified_watch_hours_365d']}", f"qualified_shorts_views_90d={ypp['observed']['qualified_shorts_views_90d']}", f"metric_as_of={ypp['observed']['as_of']}"],
            "required_action": "Use the official Earn-tab counters as the sole YPP progress source; choose an explicit long-form or Shorts threshold path per experiment while keeping ads traffic excluded.",
        },
        {
            "gate": "MONETIZATION_POLICY_FIT",
            "critical": False,
            "status": "NEEDS_REVIEW",
            "evidence": [MONETIZATION_POLICY_SOURCE, "YouTube reviews the channel as a whole, including newest/most-viewed videos, metadata and About; reused and mass-produced content require substantive original value."],
            "required_action": "Audit every public legacy video for rights, meaningful original commentary, narrative transformation, metadata accuracy and non-templated value before YPP application.",
        },
    ]
    critical_open = [item["gate"] for item in gates if item["critical"] and item["status"] != "PASS"]
    observed_ypp = ypp["observed"]
    ads_eligible = (
        subscribers >= ypp["ads_thresholds"]["subscribers"]
        and (
            observed_ypp["qualified_watch_hours_365d"] >= ypp["ads_thresholds"]["qualified_watch_hours"]
            or observed_ypp["qualified_shorts_views_90d"] >= ypp["ads_thresholds"]["qualified_shorts_views_90d"]
        )
    )
    early_eligible = (
        subscribers >= ypp["early_thresholds"]["subscribers"]
        and observed_ypp["valid_public_uploads_90d"] >= 3
        and (
            observed_ypp["qualified_watch_hours_365d"] >= ypp["early_thresholds"]["qualified_watch_hours"]
            or observed_ypp["qualified_shorts_views_90d"] >= ypp["early_thresholds"]["qualified_shorts_views_90d"]
        )
    )
    eligible_tier = "ADS" if ads_eligible else "EARLY" if early_eligible else "NONE"
    ypp_open = []
    if eligible_tier == "NONE":
        ypp_open.append("YPP_ELIGIBILITY_COUNTERS")
    if duplicate_groups or english_metadata != len(videos):
        ypp_open.append("LEGACY_CATALOG_LANGUAGE_AND_DUPLICATION")
    ypp_open.append("LEGACY_RIGHTS_AND_ORIGINALITY_REVIEW")
    ypp_open.append("MONETIZATION_POLICY_FIT_REVIEW")
    return {
        "schema_version": "1.0.0",
        "audit_id": f"channel-readiness-{hashlib.sha256((snapshot['snapshot_id'] + created).encode()).hexdigest()[:16]}",
        "channel_id": snapshot["channel_id"],
        "handle": snapshot["handle"],
        "created_at": created,
        "snapshot_ref": "output/audits/channel/heroverse/channel-snapshot.json",
        "policy_version": "channel-readiness-policy@1.1.0",
        "market_basis": {
            "channel_dna_ref": "output/modeling/phase4/channel-model-v1/channel_model.json",
            "market_review_ref": "docs/PHASE_5_MARKET_AND_VIRAL_REVIEW.md",
            "official_sources": [YPP_SOURCE, CHANNEL_CUSTOMIZATION_SOURCE, MONETIZATION_POLICY_SOURCE],
            "causal_claims_permitted": False,
        },
        "measurements": {
            "public_video_count_api": len(videos),
            "days_since_latest_public_upload": inactivity_days,
            "owned_playlist_count_api": catalog["owned_playlist_count"],
            "channel_section_count_api": catalog["channel_section_count"],
            "description_length": len(description),
            "daily_schedule_claim": daily_claim,
            "legacy_keyword_hits": legacy_hits,
            "normalized_duplicate_titles": duplicate_groups,
            "english_metadata_ratio": round(english_metadata / len(videos), 6) if videos else 0,
            "performance_signals_90d": {
                "totals": analytics_totals,
                "net_subscribers": net_subscribers_90d,
                "top_public_videos": top_performers,
                "weak_prophecy_or_secrecy_videos": weak_prophecy_or_secrecy,
                "interpretation": "Observed private performance signal only; Shorts average percentage above 100% can reflect loops and is not a data error.",
            },
            "visual_catalog_observation": {
                "public_thumbnails_reviewed": studio_observation["profile"]["public_thumbnails_reviewed"],
                "vertical_frame_like_thumbnails_observed": studio_observation["profile"]["vertical_frame_like_thumbnails_observed"],
                "gold_black_repetition_observed": studio_observation["profile"]["gold_black_repetition_observed"],
                "contact_sheet": catalog["contact_sheet"]["path"] if catalog["contact_sheet"] else None,
            },
            "remediation_artifacts": {
                "live_change_receipt": "output/audits/channel/heroverse/live-change-receipt.json",
                "legacy_catalog_audit": "output/audits/channel/heroverse/legacy-catalog-audit.json",
                "brand_asset_pack": "output/brand/channel/heroverse-v2/brand-asset-pack.json",
                "oauth_operational_readiness": "output/integrations/youtube/heroverse/operational-readiness.json",
                "codex_usage_snapshot": "output/operations/codex-usage-snapshot.json"
            },
            "thirty_day_target_math": thirty_day,
        },
        "gates": gates,
        "overall_status": "BLOCKED_BEFORE_NEXT_PUBLICATION" if critical_open else "PASS",
        "publication_gate": {
            "status": "BLOCKED" if critical_open else "PASS",
            "critical_open_gates": critical_open,
            "auto_publish_permitted": not critical_open,
            "reason": "This is only the channel-level publication prerequisite. Every candidate must still pass its video, rights, originality, human gold-standard, FormatPack, integration and publication gates.",
        },
        "ypp_application_gate": {
            "status": "BLOCKED" if ypp_open else "PASS",
            "eligible_tier": eligible_tier,
            "critical_open_gates": ypp_open,
            "auto_apply_permitted": False,
            "reason": "Eligibility counters and whole-channel policy review govern YPP application; they do not block publishing a new independently cleared video.",
        },
        "priority_actions": [
            {"priority": 1, "action": "Produce a new Phase 5 candidate that passes market, hook, captions, continuity, rights and human gold-standard gates; only then publish and use it as trailer or spotlight.", "protected_external_change": True},
            {"priority": 2, "action": "Complete timecoded rights and substantive-originality review for all 21 public legacy videos before any YPP application, starting with the highest risk scores.", "protected_external_change": False},
            {"priority": 3, "action": "Measure the applied HeroVerse v2 identity against a versioned baseline; do not attribute outcome before a comparable observation window.", "protected_external_change": False},
            {"priority": 4, "action": "Move the OAuth app from Testing to In production after publishing truthful legal and branding pages, then reauthorize and prove refresh durability.", "protected_external_change": True},
            {"priority": 5, "action": "Maintain a versioned 30-day measurement ledger using official qualified YPP counters, organic attribution and pre-registered hypotheses.", "protected_external_change": False},
        ],
        "learning_protocol": {
            "loop": ["snapshot", "baseline", "hypothesis", "pre_registered_prediction", "approved_change", "measurement", "evaluation", "versioned_update"],
            "minimum_comparison_window_days": 7,
            "required_dimensions": ["traffic_source", "format", "video_age", "impressions", "ctr", "retention", "qualified_ypp_progress", "subscriber_conversion", "rights_incidents"],
            "no_new_evidence_status": "NO_NEW_EVIDENCE",
            "global_learning_without_transfer_test": False,
        },
        "limitations": [
            "One authenticated snapshot does not prove the effect of any proposed change.",
            "Thumbnail visual quality requires an independent human gold-standard review; the contact sheet is evidence, not an approval.",
            "YouTube Analytics watch time is not substituted for the official qualified YPP counters.",
            "The 30-day goal is not guaranteed; only required rates and observed progress can be stated before controlled experiments.",
            "Publication readiness and YPP application readiness are separate gates; passing the former does not imply YPP eligibility or policy acceptance.",
        ],
    }


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
