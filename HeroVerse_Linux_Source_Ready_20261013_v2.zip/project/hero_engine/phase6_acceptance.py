from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker, ValidationError

from .maintenance_unittest_result import (
    UnittestResultError,
    verify_legacy_test_outcome,
    verify_unittest_result,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = Path("output/operations/phase6/acceptance-report.json")
MARKDOWN = Path("output/operations/phase6/PHASE6_ACCEPTANCE.md")
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
CANARY_VIDEO_ID = "iK_5edYQtx8"
INITIAL_MISSING_DATA_SNAPSHOT = (
    "output/operations/phase6/metrics/iK_5edYQtx8/"
    "own-performance-iK_5edYQtx8-20260904T191201Z.json"
)
ACTIVE_EXPERIMENT = "output/operations/phase6/intelligence/experiments/active.json"
EXPERIMENT_LATEST = "output/operations/phase6/intelligence/experiments/latest.json"
PREDICTION_RUNTIME = "output/operations/phase6/intelligence/prediction-runtime.json"
LEARNING_RUNTIME = "output/operations/phase6/intelligence/learning-runtime.json"
LEARNING_EVIDENCE_ROOT = "output/operations/phase6/intelligence/learning"
LEARNING_EXTERNAL_ROOT = "output/operations/phase6/intelligence/external-read-checkpoints"
VIDEO2_PUBLICATION = "output/production/phase6/video-002/publication/youtube-publication-receipt.json"
PACKAGE_PUBLICATION = "output/production/phase6/canary-package-update/publication/youtube-package-update-receipt.json"
GC21_RECOVERY_TEST_IDS = (
    "tests.test_daily_maintenance_protocol.DailyMaintenanceProtocolTests."
    "test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime",
    "tests.test_phase5_manager_autostart.Phase5ManagerAutostartTests."
    "test_daily_maintenance_stops_only_verified_manager_and_always_recovers_runtime",
)


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _stamp(value: str | None = None) -> str:
    return value or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _valid(root: Path, schema: str, artifact: str) -> dict[str, Any] | None:
    path = root / artifact
    if not path.is_file():
        return None
    try:
        value = _read(path)
        Draft202012Validator(_read(root / "schemas" / schema)).validate(value)
        return value
    except Exception:
        return None


def _sqlite_ok(path: Path) -> bool:
    if not path.is_file():
        return False
    try:
        with sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True) as connection:
            return connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    except Exception:
        return False


def _test_evidence(root: Path, receipt: dict[str, Any] | None, test_name: str) -> bool:
    if not receipt:
        return False
    if receipt.get("status") == "PASS" and isinstance(receipt.get("tests"), dict):
        tests = receipt["tests"]
        try:
            inventory_path = root / str(tests["inventory_path"])
            inventory_bytes = inventory_path.read_bytes()
            if "sha256:" + hashlib.sha256(inventory_bytes).hexdigest() != tests["inventory_hash"]:
                return False
            inventory = json.loads(inventory_bytes.decode("utf-8-sig"))
            exact_ids = [
                test_id
                for item in inventory.get("files", [])
                for test_id in item.get("test_ids", [])
            ]
            matching_ids = [
                test_id
                for test_id in exact_ids
                if test_id == test_name or test_id.endswith("." + test_name)
            ]
            if len(matching_ids) != 1:
                return False
            logs: dict[str, bytes] = {}
            for key, hash_key in (("stdout_log", "stdout_hash"), ("stderr_log", "stderr_hash")):
                path = root / str(tests[key])
                payload = path.read_bytes()
                if "sha256:" + hashlib.sha256(payload).hexdigest() != tests[hash_key]:
                    return False
                logs[key] = payload
            result = verify_unittest_result(
                inventory=inventory,
                stdout_bytes=logs["stdout_log"],
                stderr_bytes=logs["stderr_log"],
                process_exit_code=None,
            )
            return result["outcomes"].get(matching_ids[0]) == "ok"
        except (KeyError, OSError, ValueError, json.JSONDecodeError, UnittestResultError):
            return False
    if receipt.get("regression_status") != "PASS":
        return False
    try:
        logs: dict[str, bytes] = {}
        for key in ("stdout_log", "stderr_log"):
            path = root / str(receipt.get(key) or "")
            logs[key] = path.read_bytes() if path.is_file() else b""
        return verify_legacy_test_outcome(
            stdout_bytes=logs["stdout_log"],
            stderr_bytes=logs["stderr_log"],
            test_name=test_name,
        )
    except (OSError, UnittestResultError):
        return False


def _gc21_recovery_test_evidence(root: Path, receipt: dict[str, Any] | None) -> bool:
    """Bind both qualified recovery contracts from one inventoried regression.

    The tests intentionally share a method name while covering different
    boundaries. A basename lookup is ambiguous and is never accepted as proof.
    """

    return all(_test_evidence(root, receipt, test_id) for test_id in GC21_RECOVERY_TEST_IDS)


def _confined_valid(
    root: Path,
    reference: Any,
    *,
    parent: str,
    schema: str,
) -> tuple[Path, dict[str, Any]] | None:
    if not isinstance(reference, str) or not reference:
        return None
    try:
        path = (root / reference).resolve()
        path.relative_to((root / parent).resolve())
        value = _read(path)
        Draft202012Validator(_read(root / "schemas" / schema)).validate(value)
        return path, value
    except Exception:
        return None


def _live_preregistration(root: Path, protocol: dict[str, Any] | None) -> bool:
    if not protocol:
        return False
    treatment = protocol.get("treatment") or {}
    baseline = protocol.get("baseline") or {}
    diagnosis_ref = protocol.get("diagnosis") or {}
    baseline_id = baseline.get("snapshot_id")
    if not (
        protocol.get("schema_version") == "1.1.0"
        and protocol.get("status") == "PREREGISTERED"
        and protocol.get("channel_id") == CHANNEL_ID
        and treatment.get("variable") not in {None, "NONE"}
        and treatment.get("preregistered_before_production") is True
        and protocol.get("primary_metric") not in {None, "NONE"}
        and isinstance(baseline_id, str)
        and baseline_id
        and diagnosis_ref.get("status") == "DIAGNOSED"
    ):
        return False
    baseline_path = (
        root / "output/operations/phase6/metrics" / CANARY_VIDEO_ID / f"{baseline_id}.json"
    )
    try:
        baseline_value = _read(baseline_path)
        Draft202012Validator(
            _read(root / "schemas/own_channel_performance_snapshot.schema.json")
        ).validate(baseline_value)
        diagnosis_result = _confined_valid(
            root,
            diagnosis_ref.get("path"),
            parent="output/operations/phase6/intelligence/diagnoses",
            schema="phase6_diagnostic_decision.schema.json",
        )
        if diagnosis_result is None:
            return False
        diagnosis_path, diagnosis = diagnosis_result
        active_path = root / ACTIVE_EXPERIMENT
        latest_path = root / EXPERIMENT_LATEST
        active_matches = (
            active_path.is_file()
            and latest_path.is_file()
            and active_path.read_bytes() == latest_path.read_bytes()
            and _read(active_path) == protocol
        )
        return bool(
            active_matches
            and diagnosis_path.name == f"{diagnosis_ref.get('diagnosis_id')}.json"
            and diagnosis_path.name != "latest.json"
            and baseline_value.get("snapshot_id") == baseline_id
            and baseline_value.get("video_id") == CANARY_VIDEO_ID
            and baseline_value.get("channel_id") == CHANNEL_ID
            and float(baseline_value.get("age_hours") or 0) >= 24
            and diagnosis.get("diagnosis_id") == diagnosis_ref.get("diagnosis_id")
            and (diagnosis.get("baseline") or {}).get("snapshot_id") == baseline_id
            and (diagnosis.get("decision") or {}).get("treatment_variable") == treatment.get("variable")
            and (diagnosis.get("decision") or {}).get("primary_metric") == protocol.get("primary_metric")
            and (diagnosis.get("decision") or {}).get("production_may_start") is True
            and _parse(protocol["created_at"]) >= _parse(baseline_value["captured_at"])
        )
    except Exception:
        return False


def _complete_live_learning_cycle(
    root: Path,
    protocol: dict[str, Any] | None,
    learning: dict[str, Any] | None,
) -> bool:
    if not _live_preregistration(root, protocol) or not learning:
        return False
    treatment = protocol.get("treatment") or {}
    variable = treatment.get("variable")
    baseline_id = (protocol.get("baseline") or {}).get("snapshot_id")
    expected_baseline = (
        f"output/operations/phase6/metrics/{CANARY_VIDEO_ID}/{baseline_id}.json"
    )
    if not (
        learning.get("status") == "EVALUATED"
        and learning.get("job_state") == "SUCCEEDED"
        and learning.get("error") is None
        and learning.get("protocol_id") == protocol.get("protocol_id")
        and learning.get("treatment_variable") == variable
        and learning.get("baseline_snapshot") == expected_baseline
        and learning.get("classification") in {"SUPPORTED", "REJECTED", "INCONCLUSIVE"}
    ):
        return False
    baseline = _confined_valid(
        root,
        learning.get("baseline_snapshot"),
        parent=f"output/operations/phase6/metrics/{CANARY_VIDEO_ID}",
        schema="own_channel_performance_snapshot.schema.json",
    )
    if baseline is None or baseline[1].get("snapshot_id") != baseline_id:
        return False

    if variable == "TITLE_THUMBNAIL_PROMISE":
        receipt_ref = PACKAGE_PUBLICATION
        receipt_schema = "youtube_package_update_receipt.schema.json"
        treatment_schema = "youtube_reach_snapshot.schema.json"
    else:
        receipt_ref = VIDEO2_PUBLICATION
        receipt_schema = "youtube_publication_receipt.schema.json"
        treatment_schema = "own_channel_performance_snapshot.schema.json"
    if learning.get("publication_receipt") != receipt_ref:
        return False
    receipt = _valid(root, receipt_schema, receipt_ref)
    if variable != "TITLE_THUMBNAIL_PROMISE" and receipt is not None:
        try:
            from .phase6_publication import verify_phase6_publication_receipt

            receipt = verify_phase6_publication_receipt(
                root,
                receipt_path=receipt_ref,
                require_complete=True,
            )
        except Exception:
            receipt = None
    treatment_snapshot = _confined_valid(
        root,
        learning.get("latest_treatment_snapshot"),
        parent=LEARNING_EXTERNAL_ROOT,
        schema=treatment_schema,
    )
    evaluation_result = _confined_valid(
        root,
        learning.get("evaluation"),
        parent=LEARNING_EVIDENCE_ROOT,
        schema="phase6_learning_evaluation.schema.json",
    )
    if receipt is None or treatment_snapshot is None or evaluation_result is None:
        return False
    treatment_path, treatment_value = treatment_snapshot
    evaluation_path, evaluation = evaluation_result
    job_id = learning.get("job_id")
    if not isinstance(job_id, str) or treatment_path.parent.name != job_id:
        return False
    if evaluation_path.name != f"{evaluation.get('evaluation_id')}.json":
        return False
    target_video_id = learning.get("target_video_id")
    if variable == "TITLE_THUMBNAIL_PROMISE":
        expected_experiment_id = (
            f"{protocol['protocol_id']}-{CANARY_VIDEO_ID}-package-"
            f"{receipt.get('treatment_start_date_pt')}"
        )
        receipt_time = receipt.get("mutation_started_at")
        receipt_ok = (
            receipt.get("status") == "COMPLETE_PUBLIC_PACKAGE"
            and receipt.get("channel_id") == CHANNEL_ID
            and receipt.get("video_id") == CANARY_VIDEO_ID
            and target_video_id == CANARY_VIDEO_ID
            and treatment_value.get("video_id") == CANARY_VIDEO_ID
        )
    else:
        expected_experiment_id = f"{protocol['protocol_id']}-{target_video_id}"
        receipt_time = receipt.get("created_at")
        receipt_ok = (
            receipt.get("status") == "COMPLETE_PUBLIC"
            and receipt.get("privacy_status") == "public"
            and receipt.get("channel_id") == CHANNEL_ID
            and isinstance(target_video_id, str)
            and target_video_id not in {"", CANARY_VIDEO_ID}
            and receipt.get("video_id") == target_video_id
            and treatment_value.get("video_id") == target_video_id
            and treatment.get("video_id") in {"phase6-video-2-prepublication", target_video_id}
        )
    validity = evaluation.get("validity") or {}
    evidence_ids = set(evaluation.get("evidence_ids") or [])
    receipt_id = receipt.get("receipt_id") or f"publication-{target_video_id}"
    required_evidence = {
        str(protocol.get("protocol_id")),
        str(baseline_id),
        str(treatment_value.get("snapshot_id")),
        str(receipt_id),
    }
    try:
        temporal_ok = bool(
            receipt_time
            and _parse(protocol["created_at"]) <= _parse(str(receipt_time))
            and _parse(str(learning["scheduled_window_at"])) <= _parse(evaluation["evaluated_at"])
        )
    except Exception:
        temporal_ok = False
    return bool(
        receipt_ok
        and temporal_ok
        and evaluation.get("channel_id") == CHANNEL_ID
        and evaluation.get("experiment_id") == expected_experiment_id
        and evaluation.get("metric") == protocol.get("primary_metric")
        and evaluation.get("classification") == learning.get("classification")
        and validity.get("preregistered") is True
        and validity.get("same_window") is True
        and validity.get("single_variable") is True
        and validity.get("critical_incident") is False
        and required_evidence.issubset(evidence_ids)
    )


def _immutable_prediction_outcome_chain(
    root: Path,
) -> list[str] | None:
    """Find one complete historical outcome chain without trusting mutable latest views.

    ``predictions/latest.json`` and ``prediction-runtime.json`` describe the
    next/current observer command.  They are intentionally replaced when a new
    prediction is preregistered, so they cannot be the sole index for the
    cumulative GC-19 proof.  The queue keeps every completed command and is the
    authoritative index.  Every candidate is then reconstructed from its exact
    immutable prediction, job-owned snapshot and deterministic evaluation.
    """

    root = root.resolve()
    queue_ref = "output/operations/phase6/runtime/queue-snapshot.json"
    queue = _valid(root, "phase6_queue_snapshot.schema.json", queue_ref)
    if queue is None:
        return None
    predictions_root = (
        root / "output/operations/phase6/intelligence/predictions"
    ).resolve()
    evaluations_root = (
        root / "output/operations/phase6/intelligence/prediction-evaluations"
    ).resolve()
    outcome_root = (
        root / "output/operations/phase6/intelligence/prediction-outcomes"
    ).resolve()
    try:
        predictions_root.relative_to(root)
        evaluations_root.relative_to(root)
        outcome_root.relative_to(root)
        prediction_schema = _read(root / "schemas/prediction_record.schema.json")
        evaluation_schema = _read(root / "schemas/prediction_evaluation.schema.json")
        binding_schema = _read(
            root / "schemas/phase6_prediction_outcome_binding.schema.json"
        )
    except Exception:
        return None

    jobs = sorted(
        (queue.get("jobs") or []),
        key=lambda item: (str(item.get("updated_at") or ""), str(item.get("job_id") or "")),
        reverse=True,
    )
    for job in jobs:
        if not (
            job.get("state") == "SUCCEEDED"
            and job.get("task_type") == "PREDICTION_OUTCOME_CHECKPOINT"
            and job.get("operation_id") == "heroverse-phase6-controlled-longform-v1"
            and job.get("channel_id") == CHANNEL_ID
            and job.get("lease_owner") is None
            and job.get("lease_until") is None
            and job.get("last_error") is None
        ):
            continue
        job_id = job.get("job_id")
        checkpoint = job.get("checkpoint") or {}
        binding = checkpoint.get("outcome_binding")
        payload = job.get("payload") or {}
        if not isinstance(job_id, str) or not isinstance(binding, dict):
            continue
        try:
            Draft202012Validator(
                binding_schema, format_checker=FormatChecker()
            ).validate(binding)
        except Exception:
            continue
        prediction_id = binding.get("prediction_id")
        horizon_ends_at = binding.get("horizon_ends_at")
        if not (
            isinstance(prediction_id, str)
            and prediction_id
            and "/" not in prediction_id
            and "\\" not in prediction_id
            and payload.get("prediction_id") == prediction_id
            and payload.get("video_id") == CANARY_VIDEO_ID
            and payload.get("horizon_ends_at") == horizon_ends_at
            and job.get("idempotency_key")
            == f"phase6-prediction-outcome:{prediction_id}:{horizon_ends_at}"
            and binding.get("operation") == "phase6_prediction_outcome_checkpoint"
            and binding.get("job_id") == job_id
            and binding.get("channel_id") == CHANNEL_ID
            and binding.get("video_id") == CANARY_VIDEO_ID
        ):
            continue

        prediction_candidate = predictions_root / f"{prediction_id}.json"
        if prediction_candidate.is_symlink():
            continue
        prediction_path = prediction_candidate.resolve()
        try:
            prediction_path.relative_to(predictions_root)
        except ValueError:
            continue
        if (
            prediction_path.parent != predictions_root
            or prediction_path.name != f"{prediction_id}.json"
            or prediction_path.is_symlink()
            or not prediction_path.is_file()
        ):
            continue
        try:
            prediction = _read(prediction_path)
            Draft202012Validator(
                prediction_schema, format_checker=FormatChecker()
            ).validate(prediction)
            horizon = _parse(prediction["horizon"]["ends_at"])
        except Exception:
            continue
        expected_prediction_id = "prediction-{}-{}".format(
            CANARY_VIDEO_ID,
            hashlib.sha256(
                (
                    f"{prediction.get('available_feature_snapshot_id')}|"
                    f"{prediction.get('horizon', {}).get('hours')}|"
                    f"{prediction.get('target')}"
                ).encode()
            ).hexdigest()[:16],
        )
        if not (
            prediction.get("prediction_id") == prediction_id == expected_prediction_id
            and prediction.get("operation_id") == job.get("operation_id")
            and prediction.get("channel_id") == CHANNEL_ID
            and prediction.get("video_id") == CANARY_VIDEO_ID
            and prediction.get("horizon", {}).get("ends_at") == horizon_ends_at
            and _parse(prediction["cutoff_at"]) <= _parse(prediction["created_at"])
            and _parse(prediction["created_at"]) <= horizon
            and (
                horizon - _parse(prediction["cutoff_at"])
            ).total_seconds()
            == int(prediction["horizon"]["hours"]) * 3600
        ):
            continue

        horizon_key = horizon.strftime("%Y%m%dT%H%M%SZ")
        evaluation_name = f"evaluation-{prediction_id}-{horizon_key}.json"
        evaluation_candidate = evaluations_root / evaluation_name
        if evaluation_candidate.is_symlink():
            continue
        evaluation_path = evaluation_candidate.resolve()
        if (
            evaluation_path.parent != evaluations_root
            or evaluation_path.name != evaluation_name
            or evaluation_path.is_symlink()
            or not evaluation_path.is_file()
        ):
            continue
        snapshot_ref = checkpoint.get("outcome_snapshot")
        expected_snapshot_candidate = outcome_root / job_id / "snapshot.json"
        if expected_snapshot_candidate.is_symlink():
            continue
        expected_snapshot = expected_snapshot_candidate.resolve()
        try:
            snapshot_candidate = root / str(snapshot_ref)
            if snapshot_candidate.is_symlink():
                continue
            snapshot_path = snapshot_candidate.resolve()
            snapshot_path.relative_to(outcome_root)
        except (OSError, ValueError):
            continue
        if (
            snapshot_path != expected_snapshot
            or snapshot_path.parent != (outcome_root / job_id).resolve()
            or snapshot_path.name != "snapshot.json"
            or snapshot_path.is_symlink()
            or not snapshot_path.is_file()
            or checkpoint.get("evaluation")
            != evaluation_path.relative_to(root).as_posix()
        ):
            continue
        try:
            evaluation = _read(evaluation_path)
            snapshot = _read(snapshot_path)
            Draft202012Validator(
                evaluation_schema, format_checker=FormatChecker()
            ).validate(evaluation)
            Draft202012Validator(
                _read(root / "schemas/own_channel_performance_snapshot.schema.json"),
                format_checker=FormatChecker(),
            ).validate(snapshot)
        except Exception:
            continue
        observed_hash = "sha256:" + hashlib.sha256(snapshot_path.read_bytes()).hexdigest()
        bound_snapshot = binding.get("snapshot") or {}
        outcome = evaluation.get("outcome") or {}
        try:
            temporal_ok = bool(
                _parse(snapshot["captured_at"]) >= horizon
                and _parse(evaluation["evaluated_at"]) >= horizon
            )
        except Exception:
            temporal_ok = False
        if not (
            temporal_ok
            and evaluation.get("prediction_id") == prediction_id
            and evaluation.get("evaluation_id") == evaluation_path.stem
            and evaluation.get("out_of_sample") is True
            and snapshot.get("channel_id") == CHANNEL_ID
            and snapshot.get("video_id") == CANARY_VIDEO_ID
            and snapshot.get("snapshot_id") == outcome.get("source_id")
            and snapshot.get("captured_at") == outcome.get("observed_at")
            and snapshot.get("captured_at") == evaluation.get("evaluated_at")
            and snapshot.get("public_metrics", {}).get("viewCount") == outcome.get("value")
            and checkpoint.get("outcome_snapshot_hash") == observed_hash
            and checkpoint.get("outcome_snapshot_schema")
            == "own_channel_performance_snapshot.schema.json"
            and bound_snapshot.get("path") == snapshot_ref
            and bound_snapshot.get("sha256") == observed_hash
            and bound_snapshot.get("schema")
            == "own_channel_performance_snapshot.schema.json"
            and bound_snapshot.get("schema_version") == snapshot.get("schema_version")
            and bound_snapshot.get("snapshot_id") == snapshot.get("snapshot_id")
            and bound_snapshot.get("captured_at") == snapshot.get("captured_at")
        ):
            continue

        # Recompute the outcome independently from the frozen prediction and
        # snapshot.  A schema-valid but altered evaluation cannot satisfy GC-19.
        try:
            from .phase6_intelligence import evaluate_prediction

            recomputed = evaluate_prediction(
                prediction,
                outcome_value=snapshot.get("public_metrics", {}).get("viewCount"),
                observed_at=snapshot["captured_at"],
                outcome_source_id=snapshot["snapshot_id"],
            )
        except Exception:
            continue
        if recomputed != evaluation:
            continue
        if prediction.get("forecast") is None:
            accepted = bool(
                prediction.get("status") == "WITHHELD_INSUFFICIENT_CALIBRATION"
                and evaluation.get("status") == "NOT_EVALUABLE_WITHHELD"
                and evaluation.get("errors") is None
                and evaluation.get("baseline_comparison", {}).get(
                    "baseline_absolute_error"
                )
                is None
                and evaluation.get("baseline_comparison", {}).get(
                    "forecast_uplift_vs_baseline_error"
                )
                is None
            )
        else:
            accepted = bool(
                evaluation.get("status") == "EVALUATED"
                and evaluation.get("errors") is not None
                and evaluation.get("baseline_comparison", {}).get(
                    "baseline_absolute_error"
                )
                is not None
                and float(
                    evaluation.get("baseline_comparison", {}).get(
                        "forecast_uplift_vs_baseline_error"
                    )
                    or 0
                )
                > 0
            )
        if accepted:
            return [
                prediction_path.relative_to(root).as_posix(),
                evaluation_path.relative_to(root).as_posix(),
                snapshot_path.relative_to(root).as_posix(),
                queue_ref,
            ]
    return None


def _prediction_outcome_matches_current(
    root: Path,
    prediction: dict[str, Any] | None,
    runtime: dict[str, Any] | None,
) -> bool:
    """Backward-compatible boolean facade for the cumulative GC-19 proof."""

    del prediction, runtime
    return _immutable_prediction_outcome_chain(root) is not None


def _check(
    check_id: str,
    name: str,
    *,
    required: bool,
    minimum: str,
    status: str,
    reason: str,
    evidence: list[str],
) -> dict[str, Any]:
    return {
        "check_id": check_id,
        "name": name,
        "required_for_phase6": required,
        "minimum_evidence": minimum,
        "status": status,
        "reason": reason,
        "evidence": list(dict.fromkeys(evidence)),
    }


def build_phase6_acceptance(root: Path = ROOT, *, generated_at: str | None = None,
                           package_relative: Path | None = None,
                           current_bindings: dict[str, Any] | None = None,
                           expected_release_hash: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    selected = any(value is not None for value in (package_relative, current_bindings, expected_release_hash))
    current_executive = None
    current_pins = {}
    if selected:
        if any(value is None for value in (package_relative, current_bindings, expected_release_hash)):
            raise PermissionError('Current acceptance requires complete explicit delivery selection')
        from .phase6_reporting import build_status
        directory = (root / package_relative).resolve()
        executive_path = directory / 'intelligence/executive-status.json'
        executive_raw = executive_path.read_bytes()
        current_executive = json.loads(executive_raw.decode('utf-8-sig'))
        rebuilt = build_status(root, package_relative=package_relative,
            current_bindings=current_bindings, expected_release_hash=expected_release_hash,
            captured_at=current_executive['captured_at'])
        if current_executive != rebuilt:
            raise PermissionError('Current acceptance executive differs from its completed producers')
        current_pins[executive_path] = executive_raw
        for binding in current_executive['producer_receipts'].values():
            source = (root / binding['path']).resolve()
            raw = source.read_bytes()
            if not source.is_relative_to(root) or 'sha256:' + hashlib.sha256(raw).hexdigest() != binding['sha256']:
                raise PermissionError('Current acceptance producer bytes diverged')
            current_pins[source] = raw
    maintenance = _valid(root, "daily_maintenance_regression_receipt.schema.json", "output/runtime/gestor-central/daily-maintenance-regression-receipt.json")
    autostart = _valid(root, "central_manager_autostart_verification.schema.json", "output/runtime/gestor-central/autostart-verification.json")
    queue = _valid(root, "phase6_queue_snapshot.schema.json", "output/operations/phase6/runtime/queue-snapshot.json")
    executive = current_executive if selected else _valid(root, "phase6_executive_status.schema.json", "output/operations/phase6/executive-status.json")
    # Bind the consumed cycle's ID and hash from the same buffer. A later
    # latest.json cannot silently become the provenance of this report.
    control_cycle, control_cycle_evidence = None, None
    try:
        cycle_raw = (directory / 'intelligence/control-cycle/latest.json' if selected else
                     root / "output/operations/phase6/control-cycle/latest.json").read_bytes()
        cycle_value = json.loads(cycle_raw.decode("utf-8-sig"))
        Draft202012Validator(_read(root / "schemas/phase6_control_cycle_receipt.schema.json")).validate(cycle_value)
        if selected:
            from .phase6_control_cycle import verify_audio_cycle_sources
            verify_audio_cycle_sources(root, cycle_value, current_executive)
            current_pins[directory/'intelligence/control-cycle/latest.json'] = cycle_raw
        control_cycle = cycle_value
        control_cycle_evidence = {"cycle_id": cycle_value["cycle_id"],
                                  "content_hash": "sha256:" + hashlib.sha256(cycle_raw).hexdigest()}
    except (OSError, ValueError, KeyError, ValidationError):
        if selected and (directory/'intelligence/control-cycle/latest.json').exists():
            raise PermissionError('Current acceptance cycle is incomplete or incompatible')
        pass
    prediction = _valid(root, "prediction_record.schema.json", "output/operations/phase6/intelligence/predictions/latest.json")
    initial_snapshot = _valid(
        root, "own_channel_performance_snapshot.schema.json", INITIAL_MISSING_DATA_SNAPSHOT
    )
    protocol = _valid(root, "phase6_experiment_protocol.schema.json", EXPERIMENT_LATEST)
    active_protocol = _valid(root, "phase6_experiment_protocol.schema.json", ACTIVE_EXPERIMENT)
    if active_protocol is not None:
        protocol = active_protocol
    learning = _valid(root, "phase6_learning_runtime.schema.json", LEARNING_RUNTIME)
    prediction_runtime = _valid(root, "phase6_prediction_runtime.schema.json", PREDICTION_RUNTIME)
    order = _valid(root, "phase6_treatment_order.schema.json", "output/operations/phase6/production/latest-order.json")
    publication = _valid(root, "youtube_publication_receipt.schema.json", "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
    if selected:
        # Historical experiments/outcomes remain auditable but never stand in
        # for a current publication, preregistration or learning evaluation.
        sources = current_executive['producer_receipts']
        def producer(label):
            return _read(root / sources[label]['path']) if label in sources else None
        publication = producer('publication')
        prediction = producer('prediction')
        initial_snapshot = producer('owned_snapshot')
        protocol = producer('experiment')
        active_protocol = learning = prediction_runtime = order = None
    benchmark_path = root / "output/mining/phase2/benchmarks/summary.json"
    benchmark = _read(benchmark_path) if benchmark_path.is_file() else None

    suite_ref = "output/runtime/gestor-central/daily-maintenance-regression-receipt.json"
    live_runtime = bool(
        autostart
        and autostart.get("operational_ready") is True
        and autostart.get("manager_alive") is True
        and autostart.get("same_process_chain") is True
        and autostart.get("duplicate_probe_blocked") is True
        and autostart.get("active_stderr_bytes") == 0
    )
    queue_integrity = bool(queue and _sqlite_ok(root / str(queue.get("database_path") or "")))
    control_cycle_healthy = bool(
        control_cycle
        and control_cycle.get("schema_version") in ({"1.2.0","1.3.0"} if selected else {"1.1.0"})
        and control_cycle.get("stage_count") == 12
        and control_cycle.get("all_schemas_valid") is True
        and control_cycle.get("all_stages_executed_in_cycle") is True
        and control_cycle.get("decision") in {"PASS_WAITING", "PASS_ADVANCED"}
        and not control_cycle.get("blockers")
    )
    executive_cycle_visible = False
    executive_evidence = None
    if selected:
        executive_cycle_visible = control_cycle_healthy
    if executive and control_cycle_healthy and not selected:
        from .phase6_control_cycle import verify_completed_projection
        try:
            executive_raw = (root / "output/operations/phase6/executive-status.json").read_bytes()
            if json.loads(executive_raw.decode("utf-8-sig")) != executive:
                raise PermissionError("CURRENT_CHAIN_EXECUTIVE_CHANGED_DURING_ACCEPTANCE")
            binding = verify_completed_projection(
                root, control_cycle, control_cycle_evidence["content_hash"], executive)
            executive_evidence = {**binding, "executive_sha256": "sha256:" + hashlib.sha256(executive_raw).hexdigest()}
            executive_cycle_visible = True
        except (OSError, ValueError, KeyError, PermissionError, ValidationError):
            pass  # GC-20 remains MISSING_EVIDENCE; no fallback to an older report.
    suite_pass = bool(maintenance and (maintenance.get("status") or maintenance.get("regression_status")) == "PASS")
    publication_live = bool(
        publication
        and publication.get("status") == "COMPLETE_PUBLIC"
        and publication.get("privacy_status") == "public"
        and publication.get("channel_id") == CHANNEL_ID
        and publication.get("video_id") == (current_executive['current_delivery']['video_id'] if selected else CANARY_VIDEO_ID)
    )
    missing_is_preserved = bool(
        initial_snapshot
        and initial_snapshot.get("status") == "PARTIAL_DATA_LAG"
        and initial_snapshot.get("decision_status") == "INSUFFICIENT_DATA"
        and initial_snapshot.get("private_metrics", {}).get("views") is None
        and initial_snapshot.get("private_metrics", {}).get("videoThumbnailImpressionsClickRate") is None
        and initial_snapshot.get("missing_metrics")
        and float(initial_snapshot.get("technical_cost_brl") or 0) == 0
    )
    prediction_prior = bool(
        prediction
        and prediction.get("channel_id") == CHANNEL_ID
        and prediction.get("video_id") == (current_executive['current_delivery']['video_id'] if selected else CANARY_VIDEO_ID)
        and _parse(prediction["created_at"]) <= _parse(prediction["horizon"]["ends_at"])
        and prediction.get("status") in {
            "WITHHELD_INSUFFICIENT_CALIBRATION",
            "PRE_REGISTERED_UNCALIBRATED",
            "PRE_REGISTERED_CALIBRATED",
        }
    )
    experiment_live = False if selected else _live_preregistration(root, protocol)
    complete_cycle = False if selected else _complete_live_learning_cycle(root, protocol, learning)
    benchmark_live = bool(
        benchmark
        and int(benchmark.get("fixture_count") or 0) >= 4
        and benchmark.get("critical_regression_count") is not None
        and int(benchmark["critical_regression_count"]) == 0
        and len(benchmark.get("field_summary") or {}) >= 10
    )
    prediction_outcome_evidence = None if selected else _immutable_prediction_outcome_chain(root)
    calibrated = prediction_outcome_evidence is not None

    checks: list[dict[str, Any]] = []
    checks.append(_check("GC-01", "Ciclo completo sem transporte manual", required=True, minimum="LIVE", status="PASS_LIVE" if complete_cycle else "WAITING_REAL_EVIDENCE", reason="A avaliação real pós-tratamento, íntegra e ligada ao protocolo ativo, ainda não existe." if not complete_cycle else "Protocolo ativo, baseline, publicação, nova medição e avaliação foram ligados por identidade, tempo, schema e evidência no runtime.", evidence=[LEARNING_RUNTIME, ACTIVE_EXPERIMENT, LEARNING_EVIDENCE_ROOT + "/"]))
    checks.append(_check("GC-02", "Persistência após reinício", required=True, minimum="LIVE", status="PASS_LIVE" if live_runtime and queue_integrity and suite_pass else "MISSING_EVIDENCE", reason="Reinício, singleton, SQLite e regressão persistida passam." if live_runtime and queue_integrity and suite_pass else "Falta um receipt contemporâneo que una reinício, fila persistida e regressão.", evidence=["output/runtime/gestor-central/autostart-verification.json", "output/operations/phase6/runtime/phase6-queue.sqlite3", suite_ref]))
    checks.append(_check("GC-03", "Isolamento entre canais", required=True, minimum="FIXTURE", status="PASS_FIXTURE" if _test_evidence(root, maintenance, "test_channel_isolation_and_schema_valid_snapshot") else "MISSING_EVIDENCE", reason="O teste de isolamento da fila passou dentro da regressão integral." if _test_evidence(root, maintenance, "test_channel_isolation_and_schema_valid_snapshot") else "O piloto possui um canal; o receipt da fixture isolada ainda não está disponível.", evidence=[suite_ref, "tests/test_phase6_queue.py"]))
    checks.append(_check("GC-04", "Ingestão idempotente", required=True, minimum="FIXTURE", status="PASS_FIXTURE" if _test_evidence(root, maintenance, "test_idempotency_returns_same_job_and_rejects_divergent_payload") else "MISSING_EVIDENCE", reason="A mesma chave retorna o mesmo job e payload divergente é recusado." if _test_evidence(root, maintenance, "test_idempotency_returns_same_job_and_rejects_divergent_payload") else "Falta receipt de regressão que prove a fixture idempotente.", evidence=[suite_ref, "tests/test_phase6_queue.py"]))
    checks.append(_check("GC-05", "Reconstrução completa da decisão", required=True, minimum="LIVE", status="PASS_LIVE" if publication_live and executive else "MISSING_EVIDENCE", reason="O canário público e o painel preservam identidade, hashes, receipts e cadeia de evidência." if publication_live and executive else "A cadeia pública ou o painel validado está ausente.", evidence=["output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json", "output/operations/phase6/executive-status.json"]))
    policy_fixture = _test_evidence(root, maintenance, "test_policy_blocks_cost_and_protects_publication")
    policy_live = bool(executive and executive.get("release_control", {}).get("publication_authorized") is False and executive.get("cost", {}).get("technical_cost_brl") == 0)
    checks.append(_check("GC-06", "Bloqueio fora do envelope", required=True, minimum="LIVE", status="PASS_LIVE" if policy_fixture and policy_live else "MISSING_EVIDENCE", reason="A fixture bloqueia custo/publicação e o estado vivo mantém a próxima publicação fechada." if policy_fixture and policy_live else "A prova conjunta de fixture e estado vivo ainda não está completa.", evidence=[suite_ref, "output/operations/phase6/executive-status.json"]))
    checks.append(_check("GC-07", "Rotina automática dentro do envelope", required=True, minimum="LIVE", status="PASS_LIVE" if live_runtime and control_cycle_healthy else "MISSING_EVIDENCE", reason="Tarefa, processo, lock e console estão ativos e um receipt prova os 12 estágios, incluindo a trajetória da meta, no mesmo ciclo." if live_runtime and control_cycle_healthy else "Falta prova conjunta de runtime ativo e execução integral dos 12 estágios.", evidence=["output/runtime/gestor-central/autostart-verification.json", "output/operations/phase6/control-cycle/latest.json"]))
    checks.append(_check("GC-08", "Dado ausente ou inválido", required=True, minimum="LIVE", status="PASS_LIVE" if missing_is_preserved else "FAIL", reason="O snapshot imutável preserva métricas ausentes como nulas e a decisão insuficiente." if missing_is_preserved else "A evidência imutável não preserva corretamente a indisponibilidade de dados.", evidence=[INITIAL_MISSING_DATA_SNAPSHOT]))
    hypothesis_fixture = _test_evidence(root, maintenance, "test_every_hypothesis_is_falsifiable_candidate_with_support_and_contradiction")
    checks.append(_check("GC-09", "Hipótese com evidência pró e contra", required=True, minimum="FIXTURE", status="PASS_FIXTURE" if hypothesis_fixture else "MISSING_EVIDENCE", reason="As hipóteses do modelo passaram o contrato de suporte, contradição e falsificação." if hypothesis_fixture else "Falta receipt contemporâneo do teste de hipóteses.", evidence=[suite_ref, "output/modeling/phase4/channel-model-v1/channel_model.json"]))
    checks.append(_check("GC-10", "Previsão anterior ao resultado", required=True, minimum="LIVE", status="PASS_LIVE" if prediction_prior else "FAIL", reason="A previsão imutável foi registrada antes do fim da janela e reteve o forecast por falta de calibração." if prediction_prior else "O registro prévio não é temporalmente válido.", evidence=["output/operations/phase6/intelligence/predictions/latest.json"]))
    checks.append(_check("GC-11", "Experimento controlado", required=True, minimum="LIVE", status="PASS_LIVE" if experiment_live else "WAITING_REAL_EVIDENCE", reason="D1 ainda não selecionou e bloqueou de forma imutável uma variável real." if not experiment_live else "Baseline, diagnóstico imutável, variável, métrica, amostra, janela e parada foram pré-registrados e o protocolo ativo permanece byte-idêntico à visão corrente.", evidence=[EXPERIMENT_LATEST, ACTIVE_EXPERIMENT, "output/operations/phase6/intelligence/diagnoses/"]))
    three_outcomes = _test_evidence(root, maintenance, "test_learning_evaluator_classifies_supported_rejected_inconclusive_and_invalid")
    checks.append(_check("GC-12", "Avaliações favorável, contrária e inconclusiva", required=True, minimum="FIXTURE", status="PASS_FIXTURE" if three_outcomes else "MISSING_EVIDENCE", reason="Os outcomes separados passaram no avaliador." if three_outcomes else "Falta receipt da regressão que contém os três outcomes.", evidence=[suite_ref, "tests/test_phase6_intelligence.py"]))
    checks.append(_check("GC-13", "Atualização versionada de regra", required=False, minimum="LATER_PHASE", status="NOT_APPLICABLE_CURRENT_PHASE", reason="Promoção de Rule Registry pertence à Fase 7; a Fase 6 preserva somente a avaliação.", evidence=["docs/07_PHASES_AND_GATES.md#fase-7--aprendizado-e-segundo-canal"]))
    checks.append(_check("GC-14", "Aplicação em produção futura", required=False, minimum="LATER_PHASE", status="NOT_APPLICABLE_CURRENT_PHASE", reason="Aplicar um aprendizado avaliado a uma produção posterior exige a Rule Registry e o ciclo de segunda medição da Fase 7; classificá-lo como gate da Fase 6 criaria uma dependência circular entre fases.", evidence=["docs/07_PHASES_AND_GATES.md#fase-7--aprendizado-e-segundo-canal", "docs/GESTOR_CENTRAL_ACCEPTANCE.md"] ))
    checks.append(_check("GC-15", "Medição do efeito aplicado", required=False, minimum="LATER_PHASE", status="NOT_APPLICABLE_CURRENT_PHASE", reason="A segunda medição após aplicação pertence ao gate da Fase 7.", evidence=["docs/07_PHASES_AND_GATES.md#fase-7--aprendizado-e-segundo-canal"]))
    checks.append(_check("GC-16", "Evidência contrária reduz confiança", required=True, minimum="FIXTURE", status="PASS_FIXTURE" if three_outcomes else "MISSING_EVIDENCE", reason="O avaliador separa resultado rejeitado e inconclusivo sem promoção de regra." if three_outcomes else "Falta receipt do avaliador contraditório.", evidence=[suite_ref, "tests/test_phase6_intelligence.py"]))
    checks.append(_check("GC-17", "Rollback de regra sem apagar histórico", required=False, minimum="LATER_PHASE", status="NOT_APPLICABLE_CURRENT_PHASE", reason="Rollback de regra pertence à Fase 7; rollback transacional de publicação já possui fixture separada.", evidence=["tests/test_phase6_package_treatment.py", "docs/07_PHASES_AND_GATES.md#fase-7--aprendizado-e-segundo-canal"]))
    checks.append(_check("GC-18", "Regressão do minerador contra padrão-ouro", required=True, minimum="LIVE", status="PASS_LIVE" if benchmark_live else "FAIL", reason="Quatro fixtures foram medidas por campo, sem regressão crítica, mantendo divergências visíveis." if benchmark_live else "O benchmark por campo está ausente ou registra regressão crítica.", evidence=["output/mining/phase2/benchmarks/summary.json"]))
    checks.append(_check("GC-19", "Previsão contra baseline", required=True, minimum="LIVE", status="PASS_LIVE" if calibrated else "WAITING_REAL_EVIDENCE", reason="Nenhuma cadeia histórica completa liga uma previsão imutável ao job concluído, snapshot byte-pinned e outcome fora da amostra exatos." if not calibrated else "Uma cadeia histórica imutável foi integralmente recomposta; uma previsão corrente posterior não apaga essa prova cumulativa. O outcome superou o baseline simples ou comprovou que o forecast foi corretamente retido por calibração insuficiente. Isso não autoriza alegar previsibilidade.", evidence=prediction_outcome_evidence or ["output/operations/phase6/intelligence/predictions/", "output/operations/phase6/intelligence/prediction-evaluations/", "output/operations/phase6/intelligence/prediction-outcomes/", "output/operations/phase6/runtime/queue-snapshot.json"]))
    checks.append(_check("GC-20", "Relatório executivo", required=True, minimum="LIVE", status="PASS_LIVE" if executive and executive_cycle_visible else "MISSING_EVIDENCE", reason="O painel validado expõe canal, release, fila, inteligência, custos, alertas, próxima ação e a assinatura substantiva do ciclo integral." if executive and executive_cycle_visible else "A prova executiva ainda está ausente ou não reconciliada com um ciclo integral atual; a transição permanece bloqueada até a próxima iteração, sem transformar ausência de prova em falha observada.", evidence=["output/operations/phase6/executive-status.json", "output/operations/phase6/EXECUTIVE_STATUS.md", "output/operations/phase6/control-cycle/latest.json"]))
    recovery_fixture = _gc21_recovery_test_evidence(root, maintenance)
    checks.append(_check("GC-21", "Recuperação após falha", required=True, minimum="LIVE", status="PASS_LIVE" if recovery_fixture and live_runtime else "MISSING_EVIDENCE", reason="Manutenção transacional e reinício verificado passaram sem duplicar autoridade." if recovery_fixture and live_runtime else "Falta prova conjunta de recovery testado e runtime recuperado.", evidence=[suite_ref, "output/runtime/gestor-central/autostart-verification.json"]))
    checks.append(_check("GC-22", "Nenhuma estratégia paralela", required=True, minimum="LIVE", status="PASS_LIVE" if live_runtime and control_cycle_healthy else "MISSING_EVIDENCE", reason="Lock exclusivo e probe duplicado impedem uma segunda autoridade; o receipt integral comprova os executores subordinados na ordem única." if live_runtime and control_cycle_healthy else "A liderança única ou a execução subordinada integral não está comprovada no runtime atual.", evidence=["output/runtime/gestor-central/autostart-verification.json", "output/runtime/gestor-central/manager-lock.json", "output/operations/phase6/control-cycle/latest.json"]))

    if selected:
        # Keep all twenty-two criteria and their evidence minima. An unexecuted
        # current producer is waiting, not a failed old canary or a fake PASS.
        refs = current_executive['producer_receipts']
        scoped = [item['path'] for item in refs.values()]
        for item in checks:
            item['evidence'] = [reference for reference in item['evidence']
                if not reference.startswith('output/production/phase5/pilot-001/')
                and not reference.startswith('output/operations/phase6/intelligence/')
                and not reference.startswith('output/operations/phase6/metrics/')
                and reference not in {'output/operations/phase6/executive-status.json',
                    'output/operations/phase6/EXECUTIVE_STATUS.md', 'output/operations/phase6/control-cycle/latest.json'}]
            item['evidence'].extend(scoped)
        for index in (0, 10, 18):
            checks[index].update(status='WAITING_REAL_EVIDENCE', reason='The current delivery has no authenticated completed preregistered treatment/outcome yet; historical evidence cannot substitute it.')
        if initial_snapshot is None:
            checks[7].update(status='WAITING_REAL_EVIDENCE', reason='No current owned snapshot exists yet; missing current data is not replaced with the historical pilot.')
        if prediction is None:
            checks[9].update(status='WAITING_REAL_EVIDENCE', reason='No current prediction exists yet; no historical forecast is inherited.')
        checks[4]['reason'] = 'Current native publication and executive bindings are authenticated.' if publication_live else 'The current delivery has not completed publication.'
        checks[5].update(status='PASS_LIVE' if policy_fixture and not current_executive['cost']['paid_tools'] else 'MISSING_EVIDENCE',
            reason='Current native release/effect readers retain their gates; the report itself grants no effects.')

    expected_ids = [f"GC-{number:02d}" for number in range(1, 23)]
    if [item["check_id"] for item in checks] != expected_ids:
        raise AssertionError("acceptance checks are incomplete or out of order")
    pass_statuses = {"PASS_FIXTURE", "PASS_LIVE"}
    passing = [item["check_id"] for item in checks if item["status"] in pass_statuses]
    blocking = []
    for item in checks:
        if not item["required_for_phase6"]:
            continue
        enough = item["status"] == "PASS_LIVE" if item["minimum_evidence"] == "LIVE" else item["status"] in pass_statuses
        if not enough:
            blocking.append(item["check_id"])
    failed = any(item["status"] == "FAIL" and item["required_for_phase6"] for item in checks)
    ready = not blocking
    decision = "APPROVED" if ready else ("BLOCKED" if failed else "IN_PROGRESS")
    counts = Counter(item["status"] for item in checks)
    generated = _stamp(generated_at)
    identity = "|".join(f"{item['check_id']}:{item['status']}" for item in checks)
    if selected:
        identity += '|' + current_executive['source_candidate_sha256'] + '|' + expected_release_hash + '|' + hashlib.sha256(executive_raw).hexdigest()
    report = {
        "schema_version": "1.1.0",
        "control_cycle_evidence": control_cycle_evidence,
        "executive_evidence": executive_evidence,
        "report_id": "phase6-acceptance-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20],
        "phase": 6,
        "phase_decision": decision,
        "current_phase_ready": ready,
        "checks": checks,
        "counts": {name: int(counts.get(name, 0)) for name in ("PASS_FIXTURE", "PASS_LIVE", "WAITING_REAL_EVIDENCE", "MISSING_EVIDENCE", "FAIL", "NOT_APPLICABLE_CURRENT_PHASE")},
        "passing_check_ids": passing,
        "blocking_check_ids": blocking,
        "next_action": "Execute the D1 owned checkpoint, preregister one real treatment, complete its observation window and evaluate the preregistered prediction." if blocking else "Promote Phase 6 only through the separate immutable phase-transition receipt.",
        "technical_cost_brl": 0,
        "claim_boundary": [
            "PASS_FIXTURE proves the named controlled test, not a live audience outcome.",
            "PASS_LIVE proves only the exact evidence listed for that acceptance check.",
            "Phase 6 cannot close before its real experiment, complete observed cycle and preregistered prediction outcome are evaluated; future application and second measurement remain mandatory in Phase 7.",
            "An approved engineering gate never guarantees YPP acceptance, views, revenue or monetization by D30.",
        ],
        "generated_at": generated,
    }
    if selected:
        report.update(schema_version='1.2.0', current_delivery=current_executive['current_delivery'],
            source_candidate_sha256=current_executive['source_candidate_sha256'],
            current_executive_evidence={'path': executive_path.relative_to(root).as_posix(),
                'sha256': 'sha256:' + hashlib.sha256(executive_raw).hexdigest()})
        report['claim_boundary'].append('Selected current delivery evidence never approves adoption, D116, restart or external effects; the existing twenty-two phase criteria remain required.')
        if any(source.read_bytes() != raw for source, raw in current_pins.items()):
            raise PermissionError('Current acceptance producers changed during evaluation')
    Draft202012Validator(_read(root / "schemas/phase6_acceptance_report.schema.json")).validate(report)
    if executive_evidence is not None and (
        (root / "output/operations/phase6/executive-status.json").read_bytes() != executive_raw
        or (root / "output/operations/phase6/control-cycle/latest.json").read_bytes() != cycle_raw
    ):
        raise PermissionError("CURRENT_CHAIN_SOURCE_CHANGED_DURING_ACCEPTANCE")
    return report


def _render(report: dict[str, Any]) -> str:
    rows = [
        "# Aceitação verificável da Fase 6",
        "",
        f"- Decisão: `{report['phase_decision']}`",
        f"- Pronta para promoção: `{str(report['current_phase_ready']).lower()}`",
        f"- Bloqueios de evidência: `{', '.join(report['blocking_check_ids']) or 'nenhum'}`",
        f"- Gerado em: `{report['generated_at']}`",
        "",
        "| ID | Critério | Mínimo | Estado | Evidência/limite |",
        "|---|---|---|---|---|",
    ]
    for item in report["checks"]:
        reason = item["reason"].replace("|", "/")
        rows.append(f"| {item['check_id']} | {item['name']} | {item['minimum_evidence']} | `{item['status']}` | {reason} |")
    rows.extend(["", "## Próxima ação", "", report["next_action"], "", "## Limite da conclusão", ""])
    rows.extend(f"- {line}" for line in report["claim_boundary"])
    return "\n".join(rows) + "\n"


def materialize(root: Path = ROOT, *, package_relative: Path | None = None,
                current_bindings: dict[str, Any] | None = None,
                expected_release_hash: str | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    report = build_phase6_acceptance(root, package_relative=package_relative,
        current_bindings=current_bindings, expected_release_hash=expected_release_hash)
    if package_relative is not None:
        directory = root / package_relative / 'intelligence'
        json_path, md_path = directory / 'acceptance-report.json', directory / 'PHASE6_ACCEPTANCE.md'
    else:
        json_path, md_path = root / OUTPUT, root / MARKDOWN
    json_path.parent.mkdir(parents=True, exist_ok=True)
    for path, content in ((json_path, json.dumps(report, ensure_ascii=False, indent=2) + "\n"), (md_path, _render(report))):
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(content, encoding="utf-8")
        os.replace(temp, path)
    return json_path, md_path


if __name__ == "__main__":
    print("\n".join(str(path) for path in materialize()))
