from __future__ import annotations

import hashlib
import copy
import json
import math
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf
from jsonschema import Draft202012Validator

from .creative_v3_phase5 import PACKAGE_DIR, V3_DIR
from .render_creative_v2_phase5 import (
    FFMPEG,
    OUTPUT_FPS,
    _asset_id,
    _build_sfx,
    _concat_file,
    _font,
    _fps,
    _frames,
    _origin,
    _probe,
    _run,
    _sha256,
    _text_filter,
    _visual_filters,
    _write,
)


def _timestamp(ms: int) -> str:
    hours, remainder = divmod(ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, milliseconds = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{milliseconds:03d}"


def _build_captions(plan: dict[str, Any], destination: Path) -> dict[str, Any]:
    cues = []
    blocks = []
    for index, take in enumerate(plan["takes"], start=1):
        text = re.sub(r"\s+", " ", str(take.get("narration") or "")).strip()
        if not text:
            raise ValueError(f"caption text missing for {take['take_id']}")
        start_ms, end_ms = int(take["start_ms"]), int(take["end_ms"])
        blocks.append(f"{index}\n{_timestamp(start_ms)} --> {_timestamp(end_ms)}\n{text}\n")
        cues.append({"index": index, "take_id": take["take_id"], "start_ms": start_ms, "end_ms": end_ms, "text": text, "word_count": len(text.split())})
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(blocks), encoding="utf-8")
    maximum_words = max(item["word_count"] for item in cues)
    if maximum_words > 12:
        raise RuntimeError(f"caption cue exceeds 12-word take contract: {maximum_words}")
    return {"schema_version": "1.0.0", "language": "en-US", "format": "SRT", "path": str(destination.resolve()), "content_hash": _sha256(destination), "cue_count": len(cues), "maximum_words_per_cue": maximum_words, "timeline_start_ms": cues[0]["start_ms"], "timeline_end_ms": cues[-1]["end_ms"], "coverage_ratio": 1.0, "cues": cues, "human_language_review": "PENDING"}


def _build_original_music(duration_ms: int, destination: Path, *, created_at: str,
                          music_recipe: dict[str, Any] | None = None,
                          expected_recipe_hash: str | None = None,
                          opening_media: Path | None = None) -> dict[str, Any]:
    if music_recipe is not None:
        from .creative_direction import verify_christian_rest_music_recipe
        verify_christian_rest_music_recipe(music_recipe, expected_hash=expected_recipe_hash)
        if type(duration_ms) is not int or not 0 < duration_ms <= music_recipe['duration_ms']:
            raise PermissionError('rest music sample exceeds bound recipe')
        if ('editorial' in music_recipe) != (opening_media is not None):
            raise PermissionError('editorial music requires its actual opening; instrumental cannot contain speech')
        return _build_continuous_rest_music(duration_ms, destination, created_at=created_at,
            recipe=music_recipe, recipe_hash=expected_recipe_hash, opening_media=opening_media)
    if opening_media is not None:
        raise PermissionError('opening speech requires an explicit editorial recipe')
    if expected_recipe_hash is not None:
        raise PermissionError('recipe hash without recipe')
    sample_rate = 48_000
    total_samples = math.ceil(duration_ms / 1000 * sample_rate)
    block_seconds = 12.0
    progression = [(146.83, 174.61, 220.00), (116.54, 146.83, 174.61), (174.61, 220.00, 261.63), (130.81, 164.81, 196.00)]
    destination.parent.mkdir(parents=True, exist_ok=True)
    with sf.SoundFile(destination, mode="w", samplerate=sample_rate, channels=2, subtype="PCM_16") as output:
        cursor = 0
        block_size = sample_rate * 4
        while cursor < total_samples:
            count = min(block_size, total_samples - cursor)
            t = (np.arange(count, dtype=np.float64) + cursor) / sample_rate
            chord_index = (t / block_seconds).astype(int) % len(progression)
            mono = np.zeros(count, dtype=np.float64)
            for index, chord in enumerate(progression):
                mask = chord_index == index
                if not np.any(mask):
                    continue
                local_t = t[mask]
                phrase = np.zeros(len(local_t), dtype=np.float64)
                for frequency in chord:
                    phrase += np.sin(2 * np.pi * frequency * local_t) + 0.22 * np.sin(2 * np.pi * frequency * 2 * local_t)
                mono[mask] = phrase / (len(chord) * 1.22)
            phase = np.mod(t, block_seconds) / block_seconds
            envelope = np.minimum(1.0, phase / 0.12) * np.minimum(1.0, (1.0 - phase) / 0.16)
            low_pulse = np.sin(2 * np.pi * 55 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * t / 6.0))
            mono = (mono * envelope * 0.085) + (low_pulse * 0.008)
            stereo = np.column_stack([mono * (0.98 + 0.02 * np.sin(2 * np.pi * t / 9.0)), mono * (0.98 + 0.02 * np.cos(2 * np.pi * t / 11.0))]).astype(np.float32)
            output.write(stereo)
            cursor += count
    # Verify the encoded PCM itself, but retain at most the existing four-second
    # block. Loading a 3–4 hour stereo WAV would allocate 3.9–5.1 GiB here.
    peak = max(float(np.max(np.abs(block))) for block in sf.blocks(
        destination, blocksize=sample_rate * 4, dtype="float32", always_2d=True))
    if peak >= 0.98:
        raise RuntimeError("procedural music clipped")
    return {"schema_version": "1.0.0", "generator": "HeroVerseProceduralPad@1.0.0", "path": str(destination.resolve()), "content_hash": _sha256(destination), "duration_ms": duration_ms, "sample_rate": sample_rate, "channels": 2, "peak_linear": round(peak, 6), "clipping": False, "rights_status": "OWNED_PROCEDURAL", "external_cost_usd": 0, "parameters": {"key_center": "D minor", "progression": ["Dm", "Bb", "F", "C"], "block_seconds": block_seconds, "narration_ducking": True}, "created_at": created_at}


def _build_continuous_rest_music(duration_ms: int, destination: Path, *, created_at: str,
                                 recipe: dict[str, Any], recipe_hash: str,
                                 opening_media: Path | None = None) -> dict[str, Any]:
    design = recipe['sound_design']
    rate = design['sample_rate']
    total = math.ceil(duration_ms * rate / 1000)
    opening = None
    resampler = None
    if opening_media is not None:
        info = sf.info(opening_media)
        if (info.channels != 1 or info.subtype != 'PCM_16' or info.frames <= 0
                or info.duration > 360 or info.samplerate != 24000):
            raise PermissionError('editorial opening must be bounded native mono Kokoro PCM')
        command = _rest_opening_resample_command(opening_media)
        executable = Path(command[0]).resolve()
        origin = _sha256(executable); source_hash = _sha256(opening_media)
        result = subprocess.run(command, capture_output=True, timeout=120, check=True)
        if _sha256(executable) != origin or _sha256(opening_media) != source_hash:
            raise PermissionError('opening or native resampler changed during conversion')
        opening = np.frombuffer(result.stdout, dtype='<f4')
        if len(opening) != info.frames*2 or not np.isfinite(opening).all():
            raise PermissionError('native opening resample clock/population diverged')
        resampler = {'path':str(executable),'sha256':origin,'argv':command,
                     'input_sha256':source_hash,'output_samples':len(opening)}
        if len(opening) >= math.ceil(recipe['duration_ms'] * rate / 1000):
            raise PermissionError('opening leaves no musical body')
    chords = [(146.83,174.61,220.00),(116.54,146.83,174.61),
              (174.61,220.00,261.63),(130.81,164.81,196.00)]
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive OS creation closes the check/create race between producers.
    # A competing or interrupted source is evidence, never an overwrite target.
    with destination.open('xb') as owned, sf.SoundFile(owned, mode='w', format='WAV',
            samplerate=rate, channels=2, subtype='PCM_16') as output:
        cursor=0
        while cursor < total:
            count=min(rate*4,total-cursor)
            t=(np.arange(count,dtype=np.float64)+cursor)/rate
            current=(t/design['chord_seconds']).astype(int)%len(chords)
            position=np.mod(t,design['chord_seconds'])
            blend=np.minimum(position/design['crossfade_seconds'],1.0)
            previous=(current-1)%len(chords)
            mono=np.zeros(count,dtype=np.float64)
            for index,chord in enumerate(chords):
                tone=sum(np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*2*f*t) for f in chord)/(len(chord)*1.22)
                weight=(current==index)*np.sin(blend*np.pi/2)+(previous==index)*np.cos(blend*np.pi/2)
                # At the initial attack there is no preceding musical section.
                weight=np.where(t<design['chord_seconds'],(current==index),weight)
                mono += tone*weight
            fade=np.minimum(t/design['attack_seconds'],1.0)*np.clip((total/rate-t)/design['release_seconds'],0,1)
            mono=(mono*.085 + np.sin(2*np.pi*55*t)*(.5+.5*np.sin(2*np.pi*t/6))*.008)*fade
            melodic=design.get('melodic_voice')
            if melodic is not None:
                # Finite note tails make every block independently reproducible;
                # no reset/loop seams or accumulating whole-track buffers.
                piano=np.zeros(count,dtype=np.float64)
                first_note=max(0,int((t[0]-melodic['tail_seconds']-.37)//melodic['note_seconds']))
                last_note=int(t[-1]//melodic['note_seconds'])
                for note in range(first_note,last_note+1):
                    phrase = melodic['frequencies_hz']
                    for section in design.get('sections', []):
                        if section['start_fraction'] <= (note*melodic['note_seconds'])/(recipe['duration_ms']/1000) < section['end_fraction']:
                            phrase = section['frequencies_hz']
                            break
                    frequency=phrase[note%len(phrase)]
                    for delay,gain in [(0.0,1.0),*[(tap['seconds'],tap['gain']) for tap in melodic['echo_taps']]]:
                        age=t-note*melodic['note_seconds']-delay
                        alive=(age>=0)&(age<melodic['tail_seconds'])
                        local=np.maximum(age,0)
                        envelope=np.minimum(local/melodic['attack_seconds'],1.0)*np.clip(
                            (melodic['tail_seconds']-local)/1.92,0,1)*alive
                        tone=np.zeros(count,dtype=np.float64)
                        for harmonic,amplitude in enumerate(melodic['partials'],start=1):
                            hz=frequency*harmonic*math.sqrt(1+melodic['inharmonicity']*harmonic**2)
                            tone += amplitude*np.sin(2*np.pi*hz*local)*np.exp(
                                -local*harmonic/melodic['fundamental_decay_seconds'])
                        piano += tone*envelope*gain
                mono=(mono*melodic['pad_gain']+piano*melodic['amplitude'])*fade
            if opening is not None and cursor < len(opening):
                covered = min(count, len(opening)-cursor)
                mix = design['opening_mix']
                mono[:covered] = (mono[:covered]*mix['music_gain_during_speech']
                                 + opening[cursor:cursor+covered]*mix['voice_gain'])
            stereo=np.column_stack([mono*(.98+.02*np.sin(2*np.pi*t/9)),
                                    mono*(.98+.02*np.cos(2*np.pi*t/11))]).astype(np.float32)
            output.write(stereo)
            cursor+=count
    peak=max(float(np.max(np.abs(block))) for block in sf.blocks(destination,
        blocksize=rate*4,dtype='float32',always_2d=True))
    if peak >= .98: raise RuntimeError('procedural rest music clipped')
    generator=('HeroVerseEditorialRest@v3' if opening is not None else
               'HeroVerseProceduralPad@rest-v2' if design.get('melodic_voice') else 'HeroVerseProceduralPad@rest-v1')
    return {'schema_version':'1.0.0','generator':generator,
        'path':str(destination.resolve()),'content_hash':_sha256(destination),
        'duration_ms':duration_ms,'sample_rate':rate,'channels':2,'peak_linear':round(peak,6),
        'clipping':False,'rights_status':'OWNED_PROCEDURAL','external_cost_usd':0,
        'parameters':design,'recipe_id':recipe['recipe_id'],'recipe_hash':recipe_hash,
        **({'opening_resampler':resampler} if resampler is not None else {}),
        'scope':'FULL_DURATION_PROTOTYPE' if duration_ms==recipe['duration_ms'] else 'SHORT_SAMPLE',
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False,
        'created_at':created_at}


def _rest_opening_resample_command(media: Path) -> list[str]:
    return [str(Path(FFMPEG).resolve()), '-hide_banner', '-loglevel', 'error',
            '-threads', '1', '-i', str(media.resolve()), '-map', '0:a:0',
            '-af', 'aresample=48000:filter_size=64:phase_shift=10',
            '-ar', '48000', '-ac', '1', '-f', 'f32le', 'pipe:1']


def prepare_christian_rest_music(root: Path, *, package_relative: Path,
                                 recipe_binding: dict[str, str],
                                 opening_reuse: dict[str, Any] | None = None,
                                 created_at: str | None = None) -> dict[str, Any]:
    """Native production entry: exact inputs, owner pause and completed-byte reuse.

    This prepares the musical input, not a final video or release. A changed
    or partial package never authorizes replacing existing work.
    """
    from .creative_direction import read_christian_rest_music_inputs
    from .production_capacity import Phase6ResourcePreparation, ResourceWait, measure_local_resources
    from .phase6_asset_residency import _write_immutable

    root = root.resolve()
    inputs = read_christian_rest_music_inputs(root, package_relative=package_relative,
                                            recipe_binding=recipe_binding)
    package = (root / package_relative).resolve()
    music_path = package / 'audio/original-rest-music.wav'
    receipt_path = package / 'audio/rest_music_receipt.json'
    producer_path = root / 'hero_engine/render_creative_v3_phase5.py'
    producer_hash = _sha256(Path(__file__))
    if _sha256(producer_path) != producer_hash:
        raise PermissionError('resident rest producer does not match executed implementation')
    if any(not path.resolve().is_relative_to(package) for path in (music_path, receipt_path)):
        raise PermissionError('musical output escaped package through alias')
    def unchanged():
        if any(_sha256(Path(row['path'])) != row['sha256'] for row in inputs['inputs']):
            raise PermissionError('rest input changed before effect/receipt')
        if _sha256(Path(__file__)) != producer_hash or _sha256(producer_path) != producer_hash:
            raise PermissionError('rest music producer changed during operation')
    reused_opening = None
    if opening_reuse is not None:
        from .qa_phase5 import read_rest_opening
        if (inputs['recipe']['recipe_version']!='heroverse-christian-rest-editorial-v4'
                or not isinstance(opening_reuse,dict)
                or set(opening_reuse)!={'package_relative','recipe_binding','opening_binding'}
                or not isinstance(opening_reuse['package_relative'],str)
                or (root/opening_reuse['package_relative']).resolve()==package):
            raise PermissionError('opening reuse requires a distinct explicitly bound predecessor')
        previous=read_christian_rest_music_inputs(root,package_relative=Path(opening_reuse['package_relative']),
            recipe_binding=opening_reuse['recipe_binding'])
        if (previous['recipe']['recipe_version']!='heroverse-christian-rest-editorial-v3'
                or previous['recipe']['editorial']!=inputs['recipe']['editorial']):
            raise PermissionError('voice reuse cannot change editorial text, voice or speed')
        reused_opening=read_rest_opening(root,package_relative=Path(opening_reuse['package_relative']),
            recipe_binding=opening_reuse['recipe_binding'],opening_binding=opening_reuse['opening_binding'])
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text(encoding='utf-8-sig'))
        from .qa_phase5 import verify_rest_music_source
        return verify_rest_music_source(root, package_relative=package_relative,
            recipe_binding=recipe_binding,
            source_binding={'path': str(receipt_path), 'sha256': _sha256(receipt_path)})
    opening_dir = package/'audio/opening'
    if music_path.exists() or opening_dir.exists():
        raise PermissionError('partial musical source must be reconciled, not regenerated')
    # Reuse the existing serial slot and owner-pause guard, but measure the
    # exact PCM stage rather than pretending it renders the cinematic plan.
    with Phase6ResourcePreparation(root) as scope:
        samples = [measure_local_resources(root), measure_local_resources(root)]
        pcm_bytes = math.ceil(inputs['recipe']['duration_ms'] * 48000 / 1000) * 4 + 44
        required_disk = 12 * 1024**3 + math.ceil(pcm_bytes * 1.25)
        causes = []
        if any(s['available_ram_bytes'] < 1536 * 1024**2 for s in samples):
            causes.append('RAM_BELOW_STAGE_REQUIREMENT')
        if any(s['output_free_bytes'] < required_disk for s in samples):
            causes.append('OUTPUT_DISK_RESERVE')
        if causes:
            raise ResourceWait({'causes': causes, 'next_check_seconds': 60,
                'samples': samples, 'required_disk_bytes': required_disk})
        scope._unpaused()
        unchanged()
        opening = None
        if reused_opening is not None:
            from .qa_phase5 import read_rest_opening
            old=read_rest_opening(root,package_relative=Path(opening_reuse['package_relative']),
                recipe_binding=opening_reuse['recipe_binding'],opening_binding=opening_reuse['opening_binding'])
            if old!=reused_opening:
                raise PermissionError('opening changed before exclusive copy')
            old_receipt=json.loads(Path(opening_reuse['opening_binding']['path']).read_bytes())
            opening=copy.deepcopy(old_receipt)
            opening['recipe_binding']=dict(recipe_binding)
            opening['reused_from']=copy.deepcopy(opening_reuse)
            opening['reused_at']=datetime.now(timezone.utc).isoformat()
            opening_dir.mkdir(parents=True,exist_ok=False)
            copied=opening_dir/'voice.wav'
            with Path(old['voice']['path']).open('rb') as source, copied.open('xb') as target:
                while block:=source.read(1024*1024):target.write(block)
            if (_sha256(copied)!=old['voice']['content_hash']
                    or read_rest_opening(root,package_relative=Path(opening_reuse['package_relative']),
                        recipe_binding=opening_reuse['recipe_binding'],
                        opening_binding=opening_reuse['opening_binding'])!=old):
                raise PermissionError('voice predecessor changed during copy')
            opening['voice']['path']=str(copied)
            _write_immutable(opening_dir/'receipt.json',opening)
            read_rest_opening(root,package_relative=package_relative,recipe_binding=recipe_binding,
                opening_binding={'path':str(opening_dir/'receipt.json'),
                                 'sha256':_sha256(opening_dir/'receipt.json')})
        elif 'editorial' in inputs['recipe']:
            from .voice_phase5 import build_local_voice, synthesize_voice_sample, espeak_binding_identity
            model_paths = [root/'models/kokoro/kokoro-v1.0.fp16.onnx',
                           root/'models/kokoro/voices-v1.0.bin',root/'hero_engine/voice_phase5.py']
            origins = [{'path':str(p),'sha256':_sha256(p)} for p in model_paths]
            opening_dir.mkdir(parents=True, exist_ok=False)
            engine = build_local_voice(root)
            try:
                selected = engine._heroverse_espeak_binding
                text = inputs['recipe']['editorial']
                observation = synthesize_voice_sample(engine, text=text['full_text'],
                    output_path=opening_dir/'voice.wav', voice_id=text['voice_id'], speed=text['speed'])
                if any(_sha256(Path(row['path'])) != row['sha256'] for row in origins):
                    raise PermissionError('editorial voice origins changed during synthesis')
                opening = {'version':'heroverse-rest-opening-v1', 'recipe_binding':recipe_binding,
                    'editorial':text, 'voice':observation,
                    'origins':origins,
                    'espeak':espeak_binding_identity(selected),
                    'authority':{'quality':False,'render':False,'publication':False}}
                _write_immutable(opening_dir/'receipt.json', opening)
            finally:
                binding = getattr(engine, '_heroverse_espeak_binding', None)
                if binding is not None: binding.close()
                del engine
            unchanged()
            from .qa_phase5 import read_rest_opening
            read_rest_opening(root, package_relative=package_relative, recipe_binding=recipe_binding,
                opening_binding={'path':str(opening_dir/'receipt.json'),
                                 'sha256':_sha256(opening_dir/'receipt.json')})
        music = _build_original_music(inputs['recipe']['duration_ms'], music_path,
            created_at=created_at or datetime.now(timezone.utc).isoformat(),
            music_recipe=inputs['recipe'], expected_recipe_hash=inputs['canonical_recipe_hash'],
            **({'opening_media':Path(opening['voice']['path'])} if opening else {}))
        unchanged()
        receipt = {'version': 'christian-rest-music-source-v1', 'status': 'COMPLETE',
            'inputs': inputs['inputs'], 'canonical_recipe_hash': inputs['canonical_recipe_hash'],
            'producer': {'path': str(producer_path), 'sha256': producer_hash},
            'music': music, 'resource_samples': samples,
            'authority': {'quality': False, 'render': False, 'publication': False}}
        if opening is not None:
            receipt['opening'] = {'path':str(opening_dir/'receipt.json'),
                                  'sha256':_sha256(opening_dir/'receipt.json')}
        _write_immutable(receipt_path, receipt)
    from .qa_phase5 import verify_rest_music_source
    return verify_rest_music_source(root, package_relative=package_relative,
        recipe_binding=recipe_binding,
        source_binding={'path': str(receipt_path), 'sha256': _sha256(receipt_path)})


def _render_thumbnail(root: Path, *, font: Path, source: Path, output: Path, line_one: str, line_two: str, layout: str) -> dict[str, Any]:
    output.parent.mkdir(parents=True, exist_ok=True)
    one = output.with_suffix(".line1.txt")
    two = output.with_suffix(".line2.txt")
    one.write_text(line_one, encoding="utf-8")
    two.write_text(line_two, encoding="utf-8")
    if layout == "LEFT":
        boxes = ["drawbox=x=0:y=0:w=690:h=720:color=0x081827@0.56:t=fill", "drawbox=x=72:y=145:w=10:h=430:color=0xD7A94A@1.0:t=fill"]
        text = [_text_filter(font, one, size=88, x="120", y="210", color="0xE8EDF2"), _text_filter(font, two, size=80, x="120", y="385", color="0xD7A94A")]
    else:
        boxes = ["drawbox=x=0:y=455:w=1280:h=265:color=0x081827@0.72:t=fill", "drawbox=x=0:y=450:w=1280:h=7:color=0xD7A94A@1.0:t=fill"]
        text = [_text_filter(font, one, size=76, x="(w-text_w)/2", y="495", color="0xE8EDF2"), _text_filter(font, two, size=72, x="(w-text_w)/2", y="605", color="0xD7A94A")]
    vf = ",".join(["scale=1280:720:force_original_aspect_ratio=increase", "crop=1280:720", "eq=contrast=1.12:saturation=0.86:brightness=-0.02", *boxes, *text, "format=yuvj420p"])
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(source), "-vf", vf, "-frames:v", "1", "-q:v", "2", str(output)])
    if output.stat().st_size > 2_097_152:
        raise RuntimeError(f"thumbnail exceeds YouTube 2 MB ceiling: {output}")
    return {"path": str(output.resolve()), "content_hash": _sha256(output), "width": 1280, "height": 720, "size_bytes": output.stat().st_size, "text": f"{line_one} {line_two}".strip(), "source_asset": source.name, "synthetic_content_disclosure": True}


def _render_thumbnail_set(root: Path, font: Path, *, created_at: str) -> dict[str, Any]:
    v3 = root / V3_DIR
    v2 = root / PACKAGE_DIR / "creative-v2"
    directory = v3 / "thumbnail"
    candidates = [
        ("A", v3 / "assets" / "phone-down-original-v1.png", directory / "challenger-a-after-amen.jpg", "AFTER", "AMEN...", "LEFT"),
        ("B", v3 / "assets" / "three-card-decision-original-v1.png", directory / "challenger-b-do-this-today.jpg", "DO THIS", "TODAY", "BOTTOM"),
        ("C", v2 / "assets" / "hero-threshold-original-v1.png", directory / "challenger-c-prayer-isnt-finish.jpg", "PRAYER ISN'T", "THE FINISH", "LEFT"),
    ]
    rendered = []
    for candidate_id, source, output, line_one, line_two, layout in candidates:
        item = _render_thumbnail(root, font=font, source=source, output=output, line_one=line_one, line_two=line_two, layout=layout)
        item.update({"candidate_id": candidate_id, "automated_status": "PASS", "human_gold_standard": "PENDING", "hypothesis": {"A": "consequence/open-loop", "B": "mechanism/action", "C": "contrarian-title"}[candidate_id]})
        rendered.append(item)
    manifest = {"schema_version": "1.0.0", "set_id": "thumbnail-v3-" + hashlib.sha256("|".join(item["content_hash"] for item in rendered).encode()).hexdigest()[:20], "title": "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation", "candidates": rendered, "automatic_recommendation": "B", "automatic_recommendation_basis": ["directly depicts the three-test mechanism", "two short high-contrast text lines", "single focal hand action", "no sensational or guaranteed-outcome wording"], "selected_candidate": None, "selection_status": "BLOCKED_PENDING_INDEPENDENT_HUMAN_REVIEW", "created_at": created_at}
    _write(directory / "thumbnail_set_manifest.json", manifest)
    return manifest


def _segment_fingerprint(take: dict[str, Any], treatment: dict[str, Any]) -> str:
    source = Path(str(take["asset_origin"]).split("#t=", 1)[0])
    treatment_version = str(treatment.get("version") or "unknown")
    renderer_version = f"creative-{treatment_version}-hook-fit" if treatment["treatment"] == "HOOK_STAMP" else f"creative-{treatment_version}"
    payload = json.dumps(
        {"take": take, "treatment": treatment, "source_hash": _sha256(source), "renderer": renderer_version},
        sort_keys=True,
        ensure_ascii=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def render_creative_v3(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir, v3 = root / PACKAGE_DIR, root / V3_DIR
    plan = json.loads((v3 / "take_plan.json").read_text(encoding="utf-8-sig"))
    bible = json.loads((v3 / "channel_style_bible.json").read_text(encoding="utf-8-sig"))
    voice = json.loads((v3 / "audio" / "voice_render_manifest.json").read_text(encoding="utf-8-sig"))
    treatment = json.loads((v3 / "creative_treatment_plan.json").read_text(encoding="utf-8-sig"))
    assets = json.loads((package_dir / "asset_manifest.json").read_text(encoding="utf-8-sig"))
    pipeline = json.loads((root / "config" / "macro_pipelines" / "pipeline-clips-longform-v1.json").read_text(encoding="utf-8-sig"))
    if plan["quality_profile"] != "DRAFT" or voice["status"] != "COMPLETE":
        raise PermissionError("creative-v3 requires a complete measured DRAFT")
    if any(take["rights"]["status"] in {"UNKNOWN", "RESTRICTED", "EDITORIAL_REVIEW_REQUIRED"} for take in plan["takes"]):
        raise PermissionError("creative-v3 take plan contains a rights-blocked asset")
    voice_by_take = {item["take_id"]: item for item in voice["takes"]}
    treatment_by_take = {item["take_id"]: item for item in treatment["takes"]}
    work = v3 / "render_work"
    video_dir, audio_dir = work / "video_segments", work / "audio_segments"
    video_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    font = _font()
    total_started = time.perf_counter()
    video_started = time.perf_counter()
    video_files, asset_ids, timeline = [], [], []
    cursor = 0.0
    for take in plan["takes"]:
        take_id = take["take_id"]
        source, source_start, source_end = _origin(take["asset_origin"])
        duration_ms = int(take["end_ms"]) - int(take["start_ms"])
        frame_count = _frames(duration_ms)
        if source_end - source_start + 0.002 < duration_ms / 1000:
            raise ValueError(f"source span too short for {take_id}")
        asset_ids.append(_asset_id(source))
        output, cache_record = video_dir / f"{take_id}.mp4", video_dir / f"{take_id}.cache.json"
        fingerprint = _segment_fingerprint(take, treatment_by_take[take_id])
        filters = _visual_filters(take, treatment_by_take[take_id], font=font, work_dir=work)
        reusable = False
        if output.is_file() and cache_record.is_file():
            try:
                cache = json.loads(cache_record.read_text(encoding="utf-8-sig"))
                reusable = cache.get("fingerprint") == fingerprint and abs(float(_probe(output)["format"]["duration"]) * 1000 - duration_ms) <= 1000 / OUTPUT_FPS / 2
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                reusable = False
        if not reusable:
            _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{source_start:.3f}", "-i", str(source), "-an", "-vf", ",".join(filters), "-frames:v", str(frame_count), "-r", "30", "-c:v", "libx264", "-profile:v", "high", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-g", "60", "-keyint_min", "30", "-sc_threshold", "0", "-movflags", "+faststart", str(output)])
            _write(cache_record, {"fingerprint": fingerprint, "take_id": take_id, "created_at": timestamp})
        actual = round(float(_probe(output)["format"]["duration"]) * 1000, 6)
        if abs(actual - duration_ms) > 1000 / OUTPUT_FPS / 2:
            raise RuntimeError(f"segment drift for {take_id}: {actual-duration_ms} ms")
        timeline.append({"take_id": take_id, "planned_start_ms": int(take["start_ms"]), "planned_end_ms": int(take["end_ms"]), "actual_start_ms": round(cursor, 6), "actual_end_ms": round(cursor + actual, 6), "planned_duration_ms": duration_ms, "actual_duration_ms": actual, "frame_count": frame_count})
        cursor += actual
        video_files.append(output)
    video_seconds = time.perf_counter() - video_started
    audio_started = time.perf_counter()
    audio_files = []
    for take in plan["takes"]:
        take_id = take["take_id"]
        duration = (int(take["end_ms"]) - int(take["start_ms"])) / 1000
        output = audio_dir / f"{take_id}.wav"
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", voice_by_take[take_id]["path"], "-af", f"aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo,highpass=f=65,lowpass=f=15500,acompressor=threshold=0.15:ratio=2.2:attack=16:release=170:makeup=1.20,apad,atrim=0:{duration:.3f}", "-c:a", "pcm_s16le", str(output)])
        audio_files.append(output)
    video_list, audio_list = work / "video-concat.txt", work / "audio-concat.txt"
    _concat_file(video_list, video_files)
    _concat_file(audio_list, audio_files)
    silent_video, narration = work / "video-concat.mp4", work / "narration.wav"
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(video_list), "-c", "copy", str(silent_video)])
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(audio_list), "-c:a", "pcm_s16le", str(narration)])
    sfx = _build_sfx(plan, treatment, work / "creative-sfx.wav")
    duration_ms = int(plan["takes"][-1]["end_ms"])
    music = _build_original_music(duration_ms, work / "original-music-bed.wav", created_at=timestamp)
    _write(v3 / "audio" / "creative_audio_manifest.json", {"schema_version": "1.0.0", "voice_render_id": voice["voice_render_id"], "sfx": sfx, "music": music, "mix_contract": {"integrated_loudness_lufs": -16, "true_peak_dbtp": -1.3, "music_ducking": "sidechain from narration", "clipping_permitted": False}, "created_at": timestamp})
    captions = _build_captions(plan, v3 / "captions" / "en-US.srt")
    _write(v3 / "captions" / "caption_manifest.json", captions)
    audio_seconds = time.perf_counter() - audio_started
    final_started = time.perf_counter()
    render_dir = v3 / "renders"
    render_dir.mkdir(parents=True, exist_ok=True)
    output = render_dir / "after-you-pray-do-this-next.phase5-creative-v3-draft.mp4"
    duration_seconds = duration_ms / 1000
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(silent_video), "-i", str(narration), "-i", sfx["path"], "-i", music["path"], "-filter_complex", "[1:a]volume=1.0,asplit=2[nmix][nkey];[2:a]volume=0.82[sfx];[3:a]volume=0.70[m];[m][nkey]sidechaincompress=threshold=0.035:ratio=8:attack=18:release=380[md];[nmix][sfx][md]amix=inputs=3:duration=first:normalize=0,loudnorm=I=-16:LRA=7:TP=-1.3[aout]", "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2", "-t", f"{duration_seconds:.3f}", "-movflags", "+faststart", str(output)])
    final_seconds = time.perf_counter() - final_started
    total_seconds = time.perf_counter() - total_started
    thumbnails = _render_thumbnail_set(root, font, created_at=timestamp)
    probe = _probe(output)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    measured_ms = round(float(probe["format"]["duration"]) * 1000)
    asset_map = {item["asset_id"]: item for item in assets["assets"]}
    attribution = v3 / "attribution.txt"
    lines = ["HeroVerse creative-v3 DRAFT — source attribution and synthetic-content record", "Publication requires linked gates, human gold-standard review and YouTube synthetic-content disclosure.", ""]
    for asset_id in sorted(set(asset_ids)):
        item = asset_map[asset_id]
        lines.extend([asset_id, f"Source: {item['source']}", f"Creator/holder: {item.get('creator_or_holder')}", f"Rights: {item['rights_status']} / {item.get('license')}", f"Attribution: {item.get('attribution') or 'None recorded'}", f"Evidence: {item['rights_evidence_uri']}", ""])
    lines.extend(["Original procedural music", f"Source: {music['generator']}", f"Rights: {music['rights_status']}", f"Hash: {music['content_hash']}", ""])
    attribution.write_text("\n".join(lines), encoding="utf-8")
    manifest = {"schema_version": "1.0.0", "render_id": "render-v3-" + hashlib.sha256(f"{plan['take_plan_id']}|{_sha256(output)}".encode()).hexdigest()[:20], "status": "COMPLETE", "video_id": plan["video_id"], "quality_profile": "DRAFT", "pipeline_id": pipeline["pipeline_id"], "pipeline_version": pipeline["version"], "format_pack_id": plan["format_pack_id"], "format_pack_version": plan["format_pack_version"], "take_plan_id": plan["take_plan_id"], "style_bible_id": bible["style_bible_id"], "creative_treatment_plan_id": treatment["treatment_plan_id"], "creative_treatment_version": treatment["version"], "voice_render_id": voice["voice_render_id"], "adapter_versions": ["adapter-ffmpeg-local@runtime", "adapter-local-voice@KokoroFloatSpeed-1.0.0", "adapter-openai-imagegen-builtin@observed-2026-09-03", "HeroVerseProceduralPad@1.0.0"], "segment_count": len(video_files), "source_asset_ids": sorted(set(asset_ids)), "output": {"path": str(output.resolve()), "content_hash": _sha256(output), "container": "mp4", "video_codec": video["codec_name"], "audio_codec": audio["codec_name"], "width": int(video["width"]), "height": int(video["height"]), "fps": round(_fps(video["r_frame_rate"]), 6), "duration_ms": measured_ms, "size_bytes": output.stat().st_size}, "measurements": {"total_wall_seconds": round(total_seconds, 6), "video_segment_render_seconds": round(video_seconds, 6), "audio_assembly_seconds": round(audio_seconds, 6), "final_mux_seconds": round(final_seconds, 6), "real_time_factor": round(total_seconds / (measured_ms / 1000), 6), "peak_working_set_mb": None, "peak_working_set_status": "UNAVAILABLE", "output_fps": OUTPUT_FPS, "expected_total_frames": sum(item["frame_count"] for item in timeline), "maximum_take_duration_error_ms": round(max(abs(item["planned_duration_ms"] - item["actual_duration_ms"]) for item in timeline), 6), "maximum_cumulative_drift_ms": round(max(abs(item["planned_end_ms"] - item["actual_end_ms"]) for item in timeline), 6)}, "segment_timeline": timeline, "captions": {key: captions[key] for key in ("path", "content_hash", "cue_count", "language", "coverage_ratio")}, "audio_design": {"manifest_path": str((v3 / "audio" / "creative_audio_manifest.json").resolve()), "music_content_hash": music["content_hash"], "rights_status": music["rights_status"]}, "thumbnail_set": {"manifest_path": str((v3 / "thumbnail" / "thumbnail_set_manifest.json").resolve()), "set_id": thumbnails["set_id"], "selection_status": thumbnails["selection_status"]}, "attribution_path": str(attribution.resolve()), "external_cost_usd": 0, "publication_approved": False, "limitations": ["creative-v3 DRAFT; independent human full-video, voice, captions and thumbnail review remains required", "photorealistic generated illustrative scenes require YouTube synthetic-content disclosure", "local energy, labor and depreciation remain unavailable"], "created_at": timestamp}
    schema = json.loads((root / "schemas" / "render_manifest.schema.json").read_text(encoding="utf-8-sig"))
    Draft202012Validator(schema).validate(manifest)
    _write(v3 / "render_manifest.json", manifest)
    return manifest
