"""Pure adapter for PocketSphinx forced-alignment estimates.

This module deliberately does not import PocketSphinx and has no runtime or
queue integration.  A policy-bound runner may pass word/phone alignment rows
to :func:`build_uncalibrated_estimate`; the result can never impersonate the
LIVE calibration receipts required by ``phase6_av_timeline``.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re


VERSION = "phase6-pocketsphinx-forced-alignment-adapter-v1"
SOURCE_RATE = 24_000
ALIGNER_RATE = 16_000
ALIGNMENT_FRAME_RATE = 100

_WORD = re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?", re.IGNORECASE)
_SHA = re.compile(r"sha256:[a-f0-9]{64}")
_AUTHORITY = {
    "calibrated_alignment": False,
    "human_gold_standard": False,
    "quality_approved": False,
    "render_authorized": False,
    "retiming_authorized": False,
    "queue_authorized": False,
    "publication_authorized": False,
}


def _integer(value: object, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _sha(value: object, name: str) -> str:
    if not isinstance(value, str) or _SHA.fullmatch(value) is None:
        raise ValueError(f"{name} must be a SHA-256 binding")
    return value


def reference_tokens(text: str) -> list[dict[str, object]]:
    """Normalize punctuation transparently and split hyphens for CMUdict.

    Returned offsets always address the supplied, unmodified copy.  A hyphen
    is not assigned to either adjacent word; both word ranges remain exact.
    """
    if not isinstance(text, str) or not text.strip():
        raise ValueError("reference text must be non-empty")
    canonical = text.replace("\u2019", "'")
    tokens = []
    for match in _WORD.finditer(canonical.replace("-", " ")):
        # Replacing a one-codepoint hyphen preserves every character offset.
        tokens.append({"word": match.group(0).lower(), "char_start": match.start(),
                       "char_end": match.end()})
    if not tokens:
        raise ValueError("reference text has no alignable words")
    return tokens


def normalized_reference_text(text: str) -> str:
    return " ".join(str(item["word"]) for item in reference_tokens(text))


def dictionary_coverage(texts: list[str], dictionary_words: set[str]) -> dict[str, object]:
    if not isinstance(texts, list) or not texts:
        raise ValueError("at least one reference text is required")
    if not isinstance(dictionary_words, set) or not dictionary_words:
        raise ValueError("dictionary words are required")
    required = sorted({str(token["word"]) for text in texts for token in reference_tokens(text)})
    available = {word.lower() for word in dictionary_words}
    missing = [word for word in required if word not in available]
    return {
        "required_unique_word_count": len(required),
        "covered_unique_word_count": len(required) - len(missing),
        "missing_words": missing,
        "status": "PASS" if not missing else "BLOCKED_DICTIONARY_COVERAGE",
    }


def alignment_frames_to_source_samples(start_frame: int, duration_frames: int,
                                        *, source_rate: int = SOURCE_RATE,
                                        aligner_rate: int = ALIGNER_RATE,
                                        frame_rate: int = ALIGNMENT_FRAME_RATE) -> dict[str, int]:
    """Map a half-open PocketSphinx frame interval exactly to 24 kHz samples."""
    start_frame = _integer(start_frame, "start frame")
    duration_frames = _integer(duration_frames, "duration frames", 1)
    source_rate = _integer(source_rate, "source rate", 1)
    aligner_rate = _integer(aligner_rate, "aligner rate", 1)
    frame_rate = _integer(frame_rate, "frame rate", 1)
    if aligner_rate % frame_rate:
        raise ValueError("aligner samples per frame are not integral")
    start_aligner = start_frame * (aligner_rate // frame_rate)
    end_aligner = (start_frame + duration_frames) * (aligner_rate // frame_rate)
    start_numerator, end_numerator = start_aligner * source_rate, end_aligner * source_rate
    if start_numerator % aligner_rate or end_numerator % aligner_rate:
        raise ValueError("alignment interval cannot map exactly to source samples")
    return {
        "aligner_start_sample": start_aligner,
        "aligner_end_sample_exclusive": end_aligner,
        "source_start_sample": start_numerator // aligner_rate,
        "source_end_sample_exclusive": end_numerator // aligner_rate,
    }


def build_uncalibrated_estimate(*, unit_id: str, reference_text: str,
                                 source_pcm_sha256: str, resampled_pcm_sha256: str,
                                 model_sha256: str, dictionary_sha256: str,
                                 implementation_sha256: str,
                                 alignment_words: list[dict[str, object]]) -> dict[str, object]:
    """Bind PocketSphinx rows to copy while preserving non-authority."""
    if not isinstance(unit_id, str) or not unit_id:
        raise ValueError("unit id is required")
    tokens = reference_tokens(reference_text)
    if not isinstance(alignment_words, list) or len(alignment_words) != len(tokens):
        raise ValueError("alignment word count differs from normalized reference")
    rows = []
    prior_end = 0
    for token, observed in zip(tokens, alignment_words):
        if set(observed) != {"word", "start_frame", "duration_frames", "score"}:
            raise ValueError("alignment word fields differ")
        if observed["word"] != token["word"]:
            raise ValueError("alignment word differs from supplied reference")
        mapped = alignment_frames_to_source_samples(
            _integer(observed["start_frame"], "word start frame"),
            _integer(observed["duration_frames"], "word duration frames", 1),
        )
        if mapped["source_start_sample"] < prior_end:
            raise ValueError("alignment words overlap or reorder")
        score = observed["score"]
        if isinstance(score, bool) or not isinstance(score, int):
            raise ValueError("PocketSphinx score must be an integer")
        rows.append({**copy.deepcopy(token), **mapped, "start_frame": observed["start_frame"],
                     "duration_frames": observed["duration_frames"], "score": score})
        prior_end = mapped["source_end_sample_exclusive"]
    identity = {
        "adapter_version": VERSION,
        "unit_id": unit_id,
        "reference_text_sha256": "sha256:" + hashlib.sha256(reference_text.encode("utf-8")).hexdigest(),
        "source_pcm_sha256": _sha(source_pcm_sha256, "source PCM"),
        "resampled_pcm_sha256": _sha(resampled_pcm_sha256, "resampled PCM"),
        "model_sha256": _sha(model_sha256, "model"),
        "dictionary_sha256": _sha(dictionary_sha256, "dictionary"),
        "implementation_sha256": _sha(implementation_sha256, "implementation"),
    }
    payload = {
        "schema_version": "1.0.0",
        "kind": "POCKETSPHINX_FORCED_ALIGNMENT_ESTIMATE",
        "status": "ESTIMATE_UNCALIBRATED",
        "profile": {"method": "FORCED_ALIGNMENT", "implementation": "PocketSphinx",
                    "version": "5.0.4", "voice_id": "am_onyx", "language": "en-US",
                    "source_sample_rate": SOURCE_RATE, "aligner_sample_rate": ALIGNER_RATE,
                    "alignment_frame_rate": ALIGNMENT_FRAME_RATE},
        "identity": identity,
        "reference_text": reference_text,
        "normalized_reference_text": normalized_reference_text(reference_text),
        "reference_text_supplied": True,
        "sample_interval_convention": "HALF_OPEN_START_PLUS_DURATION",
        "words": rows,
        "authority": copy.deepcopy(_AUTHORITY),
        "limitations": [
            "Forced text was supplied; this estimate cannot prove lexical identity or pronunciation.",
            "No LIVE calibration policy, holdout error, coverage or independent boundary receipt is attached.",
        ],
        "technical_cost_brl": 0,
    }
    payload["estimate_id"] = "ps-estimate-" + hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:24]
    return payload
