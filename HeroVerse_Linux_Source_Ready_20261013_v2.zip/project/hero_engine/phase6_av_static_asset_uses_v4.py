"""Forty-one untimed uses: exact V3 replay plus twelve registered body states.

Reopens historical source/right proofs through dedicated metadata-only replays;
no source inspector, PNG decode, OCR, renderer or new right is invoked. The
V6 body-case reader preserves V5 history separately. No timestamp is created.
"""
from __future__ import annotations

import copy
import importlib
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_static_sources as sources
from . import phase6_av_body_case_amendment as case
from . import phase6_av_asset_use_binding_v3 as joiner
from .phase6_narration_audio_inventory import Reader as MetadataReader
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-static-asset-uses-v4"
MODULE = "hero_engine/phase6_av_static_asset_uses_v4.py"
SCHEMA = "schemas/phase6_av_static_asset_uses_v4.schema.json"
PREVIOUS = "hero_engine/phase6_av_static_uses_v3_replay.py"
BODY = "hero_engine/phase6_av_body_sources_replay.py"
BODY_STATES = (
    *(f"visual-u{uid:03d}-s00" for uid in (32, 33, 35, 47, 48, 49)),
    "visual-u036-s00", "visual-u037-s00", "visual-u037-s01", "visual-u038-s00", "visual-u038-s01", "visual-u038-s02")
IMPLEMENTATION_PINS = {
    # T11 current replay contract; historical V3 claim/receipt pins stay frozen.
    PREVIOUS: "b7d177a3b284c3c2b6d4330a94cc2468fe692cabd210de34fb5f3fde332c490a",
    "tests/test_phase6_av_static_uses_v3_replay.py": "81a5e4933591cd4ace07b449fafa7d4d12fbbf478967dabc69ab71040caa1465",
    BODY: "7f9867ea5313f4cc20425b2c8b3c2063f229fc9bbe95baa8293739f0a5a61da0",
    "tests/test_phase6_av_body_sources_replay.py": "48d56c8ce521d53f9a69e71bbca620b264676e618b10211bf5dd6f28ee858757",
    "hero_engine/phase6_av_body_case_amendment.py": "a175510b5d9326661069431d6b2ddf3d1bd04e59f45c6b6f66fe89bc6c3e001c",
    "tests/test_phase6_av_body_case_amendment.py": "bea0c5aa7f1ed8a0166577d2be47cecf3d1ccd8e80a5f729eaeaf854df7d0410",
}
AUTHORITY = dict(joiner.AUTHORITY)
_same = sources._same


def _load_replays(reader):
    modules = []
    for path in (PREVIOUS, BODY):
        digest = IMPLEMENTATION_PINS[path]
        reader.read(path, digest)
        module = importlib.import_module(path[:-3].replace("/", "."))
        if sources._resident(Path(module.__file__).absolute()) != reader.root / path:
            raise ValueError("replay implementation loaded from another root")
        reader.read(path, digest)
        modules.append(module)
    return tuple(modules)


def _dependencies(reader, items):
    """Use the frozen V3 bounded reader; never widen its 16/32MiB allowlist."""
    from . import phase6_av_static_asset_uses_v3 as old_uses
    old_uses._dependencies(reader, items)


def _json(reader, binding):
    from . import phase6_av_static_asset_uses_v3 as old_uses
    return old_uses._json(reader, binding)


def _raw(binding):
    return {"path": binding["path"], "sha256": binding["sha256"][7:]}


def _anchors(previous, body):
    return {"v3_execution": copy.deepcopy(previous.ANCHOR), "v3_input": copy.deepcopy(previous.INPUT),
        "v3_inspection": copy.deepcopy(previous.INSPECTION), "v3_claim": copy.deepcopy(previous.CLAIM),
        "body_visual_amendment": _raw(case.PROJECTION_BINDING), "body_case_amendment": _raw(case.AMENDMENT_BINDING),
        "body_case_staging": _raw(case.STAGING_BINDING), "body_case_claim": _raw(case.CLAIM_BINDING),
        "body_rights_registration": copy.deepcopy(body.REGISTRATION), "body_rights_request": copy.deepcopy(body.REQUEST),
        "body_rights_claim": copy.deepcopy(body.CLAIM)}


def _literal(reader, old):
    reference = _json(reader, case.SOURCE_BINDINGS["a11"])
    metadata = MetadataReader(reader.root)
    from . import phase6_av_caption_intent as captions
    caption = captions.read_caption_intent(metadata, captions.PLAN_BINDING, reference["units"])
    literal = case.read_amended_visual_intent(metadata, case.PROJECTION_BINDING, reference["units"], caption,
        amendment_binding=case.AMENDMENT_BINDING, staging_binding=case.STAGING_BINDING)
    _same(literal["prior_case_inspection"], old["literal"], "V6 changed the historical V5 inspection")
    for item in (*literal["dependency_bindings"], *literal["implementation_dependencies"]):
        raw = reader.read(item["path"], item["sha256"][7:])
        if len(raw) != item["size_bytes"]:
            raise ValueError("V6 literal dependency size differs")
    _dependencies(reader, literal["question_replay_dependencies"])
    return literal


def _envelope(root):
    reader = sources._Reader(root)
    for path, digest in IMPLEMENTATION_PINS.items():
        reader.read(path, digest)
    for path in (MODULE, SCHEMA, joiner.PATH):
        reader.read(path, sources._sha(reader.path(path).read_bytes()))
    previous, body = _load_replays(reader)
    old = previous.replay(root)
    _same([old[key] for key in ("version", "mode", "source_count", "use_count", "unique_png_content_count", "lineage_count",
        "remaining_unbound_visual_state_count", "image_decode_calls", "ocr_inference_calls", "render_calls", "authority", "technical_cost_brl")],
        [previous.VERSION, "EXACT_CACHE_REPLAY", 27, 29, 26, 3, 71, 0, 0, 0, AUTHORITY, 0], "V3 replay scope differs")
    _dependencies(reader, old["dependency_bindings"])
    literal = _literal(reader, old)
    current = body.replay(root)
    _same([current["version"], current["status"], current["image_decode_calls"], current["ocr_inference_calls"], current["render_calls"]],
          [body.VERSION, "EXACT_CACHE_REPLAY", 0, 0, 0], "body replay must be read-only exact cache replay")
    for key in ("sources", "rights", "registry"):
        if type(current[key]) is not list or len(current[key]) != 12:
            raise ValueError("exact twelve body replay states/rights required")
    _same([entry["state_id"] for entry in current["registry"]], list(BODY_STATES), "body replay registry order differs")
    _dependencies(reader, current["dependency_bindings"])
    return reader, literal, old, current, previous, body


def _expected(literal, old_document, registry, anchors):
    """Pure exact mapping; no caller-selected scene/style/count expansion."""
    joiner.amendment_evidence(literal)
    if len(old_document["sources"]) != 27 or len(old_document["uses"]) != 29:
        raise ValueError("exact preserved V3 population required")
    _same([row["state_id"] for row in registry], list(BODY_STATES), "exact twelve ordered body registry states required")
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    previous_states = {state["state_id"]: (row, state) for row in literal["prior_case_inspection"]["rows"] for state in row["states"]}
    source_rows, uses = copy.deepcopy(old_document["sources"]), copy.deepcopy(old_document["uses"])
    for use in uses:
        row, state = states[use["visual_state_id"]]
        old_row, old_state = previous_states[use["visual_state_id"]]
        _same([row["unit_id"], state["visual_content"]["literal_copy"], state["entry"]],
            [use["unit_id"], use["literal_copy"], old_state["entry"]], "body case changed an existing use")
        _same([row["text"], row["fragment_ids"], state], [old_row["text"], old_row["fragment_ids"], old_state], "body case changed a protected state")
    for entry in registry:
        arguments = entry["arguments"]
        _same([arguments["template_id"], arguments["state_id"]], [entry["template_id"], entry["state_id"]], "body registry request differs")
        source_rows.append({"source_id": entry["asset_id"],
            "static_source": {key: copy.deepcopy(arguments[key]) for key in ("template_id", "state_id", "receipt_binding")},
            "rights_evidence": {key: copy.deepcopy(arguments[key]) for key in ("provenance_binding", "decision_binding")}})
        row, state = states[entry["state_id"]]
        uses.append({"use_id": "static-use-" + state["state_id"], "visual_state_id": state["state_id"],
            "unit_id": row["unit_id"], "source_id": entry["asset_id"], "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"])})
    _same(sorted(use["visual_state_id"] for use in uses), list(joiner.COVERED), "closed41-use population differs")
    return {"kind": "PHASE6_STATIC_ASSET_USES", "schema_version": "4.0.0", "channel_id": sources.CHANNEL,
        "video_id": "video-002", "sources": source_rows, "uses": uses, "technical_cost_brl": 0,
        "source_bindings": {**copy.deepcopy(old_document["source_bindings"]), **copy.deepcopy(anchors)}}


def _append_body_results(document, literal, old, current):
    source_results = copy.deepcopy(old["inspection"]["sources"])
    use_results = copy.deepcopy(old["inspection"]["uses"])
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    for entry, proof, right, use in zip(document["sources"][27:], current["sources"], current["rights"], document["uses"][29:], strict=True):
        _same([proof["inspection_id"], sources._sha(sources._canonical(proof)), canonical_sha(proof)],
            [right["source_proof"]["inspection_id"], right["source_proof"]["sha256"], right["source_proof"]["timeline_canonical_sha256"]],
            "body source proof differs from registered right")
        _same([right["status"], right["scope"], right["evidence_mode"], right["rights_status"], right["source_ready"], right["technical_cost_brl"]],
            ["PASS", "RIGHTS_BINDING_ONLY", "LIVE", "OWNED", False, 0], "body right scope differs")
        if not right["authority"] or any(value is not False for value in right["authority"].values()):
            raise ValueError("body rights cannot confer admission or publicity")
        row, state = states[use["visual_state_id"]]
        _same([entry["source_id"], entry["static_source"]["state_id"], entry["static_source"]["template_id"], proof["state_id"], right["template_id"],
            entry["static_source"]["receipt_binding"], proof["asset_binding"], use["source_id"], use["literal_copy"],
            row["unit_id"], row["text"], row["fragment_ids"], state["entry"], state["visual_content"]],
            [right["asset_id"], right["state_id"], proof["template_id"], right["state_id"], proof["template_id"], proof["receipt_binding"], right["artifacts"]["png_binding"],
             right["asset_id"], proof["literal_copy"], proof["unit_id"], proof["literal_narration"], proof["unit_fragment_ids"],
             proof["entry"], proof["visual_content"]], "body source/right/use V6 literal association differs")
        _same([proof[key] for key in ("status", "source_technically_verified", "source_ready", "global_schedule_created",
            "calibrated_timing_available", "media_kind", "source_frame_count", "source_start_frame", "source_end_frame",
            "source_video_fps", "source_video_duration", "observed_sample", "video_frame", "technical_cost_brl")],
            ["STATIC_SOURCE_VERIFIED_NOT_ADMITTED", True, False, False, False, "STATIC_IMAGE", 1, 0, 1, None, None, None, None, 0],
            "body still proof cannot acquire time or readiness")
        if not proof["authority"] or any(value is not False for value in proof["authority"].values()):
            raise ValueError("body source authority differs")
        _same(proof["source_bindings"]["visual_projection"], _raw(case.PROJECTION_BINDING), "body source references another visual projection")
        _same([entry["rights_evidence"]["provenance_binding"], entry["rights_evidence"]["decision_binding"]],
            [right["provenance_binding"], right["decision_binding"]], "body use substitutes registered rights")
        source_results.append({"source_id": entry["source_id"], "asset_binding": copy.deepcopy(proof["asset_binding"]),
            "template_id": proof["template_id"], "state_id": proof["state_id"], "lineage_id": proof["lineage_id"],
            "original_unit_id": proof["unit_id"], "original_fragment_ids": copy.deepcopy(proof["fragment_ids"]),
            "original_lexical_target": copy.deepcopy(proof["lexical_target"]), "source_inspection_id": proof["inspection_id"],
            "source_inspection_sha256": sources._sha(sources._canonical(proof)), "rights_inspection_id": right["inspection_id"],
            "rights_inspection_sha256": sources._sha(sources._canonical(right))})
        use_results.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]), "source_provenance_unit_id": proof["unit_id"],
            "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
    _same([len(source_results), len(use_results), len({row["source_id"] for row in source_results}),
        len({row["visual_state_id"] for row in use_results}), len(states),
        len({row["asset_binding"]["sha256"] for row in source_results}), len({row["lineage_id"] for row in source_results})],
        [39, 41, 39, 41, 100, 37, 3], "41 uses / 39 state assets / 37 PNG / 3 lineages required")
    _same(source_results[:27], old["inspection"]["sources"], "historical source rows changed")
    _same(use_results[:29], old["inspection"]["uses"], "historical use rows changed")
    return source_results, use_results, sorted(set(states) - {row["visual_state_id"] for row in use_results})


def _recheck(reader, literal, previous, body):
    _dependencies(reader, list(reader.bindings.values()))
    previous.recheck(reader)
    body.recheck(reader)
    case.recheck_body_case_replay(reader.root, literal)


def proposed_static_asset_uses(root):
    reader, literal, old, current, previous, body = _envelope(root)
    result = _expected(literal, old["input"], current["registry"], _anchors(previous, body))
    _recheck(reader, literal, previous, body)
    return result


def inspect_static_asset_uses(root, *, binding):
    reader, literal, old, current, previous, body = _envelope(root)
    document = _json(reader, binding)
    schema = sources._json(reader.read(SCHEMA, reader.bindings[str(reader.path(SCHEMA))]["sha256"]))
    Draft202012Validator(schema).validate(document)
    _same(document, _expected(literal, old["input"], current["registry"], _anchors(previous, body)), "exact41-use envelope differs")
    source_rows, use_rows, remaining = _append_body_results(document, literal, old, current)
    if len(remaining) != 59:
        raise ValueError("exact59 unbound visual states required")
    _recheck(reader, literal, previous, body)
    result = {"version": VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
        "input_binding": copy.deepcopy(binding), "source_bindings": copy.deepcopy(document["source_bindings"]),
        "channel_id": sources.CHANNEL, "video_id": "video-002", "source_count": 39, "use_count": 41,
        "unique_png_content_count": 37, "lineage_count": 3, "sources": source_rows, "uses": use_rows,
        "remaining_unbound_visual_state_ids": remaining, "source_ready": False, "global_schedule_created": False,
        "calibrated_timing_available": False, "authority": dict(AUTHORITY), "technical_cost_brl": 0,
        "v3_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "anchor_binding": copy.deepcopy(previous.ANCHOR),
            "input_binding": copy.deepcopy(previous.INPUT), "inspection_binding": copy.deepcopy(previous.INSPECTION),
            "claim_binding": copy.deepcopy(previous.CLAIM), "source_count": 27, "use_count": 29, "unique_png_content_count": 26,
            "lineage_count": 3, "image_decode_calls": 0, "new_editorial_decision_count": 0},
        "body_rights_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "registration_binding": copy.deepcopy(body.REGISTRATION),
            "request_binding": copy.deepcopy(body.REQUEST), "claim_binding": copy.deepcopy(body.CLAIM),
            "source_count": 12, "unique_png_content_count": 11, "new_lineage_count": 0,
            "new_editorial_decision_count": 0, "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
            "historical_source_replay_execution": copy.deepcopy(current["historical_source_replay_execution"]),
            "scope": "HISTORICAL_SOURCE_AND_RIGHTS_BINDINGS_NOT_NEW_QA_OR_APPROVAL"},
        "visual_amendment_evidence": joiner.amendment_evidence(literal),
        "prior_visual_amendment_evidence": copy.deepcopy(old["inspection"]["visual_amendment_evidence"]),
        "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"]),
        "claim_boundary": "41 untimed uses, 39 state assets, 37 PNG identities and three preserved lineages. Historical29 uses and twelve body source/right bindings replayed. V6 case only; no new right, timing, span, publicity, quality, admission, render or publication."}
    result["inspection_id"] = "static-asset-uses-v4-" + sources._sha(sources._canonical(result))[:24]
    return result


def verify_static_asset_uses(candidate, root, *, binding):
    expected = inspect_static_asset_uses(root, binding=binding)
    _same(candidate, expected, "source-use V4 inspection replay differs")
    return expected


def recheck_asset_use_dependencies(root, proofs):
    """Same-call inspector sinks only; never approve a serialized candidate."""
    if type(proofs) is not list or not proofs:
        raise ValueError("same-call V4 use proof sink required")
    reader = sources._Reader(root)
    for proof in proofs:
        if type(proof) is not dict or proof.get("version") != VERSION:
            raise ValueError("V4 use proof sink version differs")
        _same([proof.get(key) for key in ("authority", "source_ready", "global_schedule_created", "calibrated_timing_available", "technical_cost_brl")],
              [AUTHORITY, False, False, False, 0], "V4 sink cannot gain authority")
        _dependencies(reader, proof.get("dependency_bindings"))
    previous, body = _load_replays(reader)
    for path, digest in IMPLEMENTATION_PINS.items():
        _same(reader.bindings.get(str(reader.root / path), {}).get("sha256"), digest, "V4 implementation dependency missing")
    for path in (MODULE, SCHEMA, joiner.PATH):
        if str(reader.root / path) not in reader.bindings:
            raise ValueError("V4 consumer implementation/schema dependency missing")
    previous.recheck(reader)
    body.recheck(reader)
    case._inventory(reader.root)
