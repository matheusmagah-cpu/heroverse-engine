"""Lossless stopped-state composition. Never reads external token contents.

PowerShell supplies only capture metadata. Opaque queue/quota/effect values
come exclusively from the pinned UTF-8 inspection, not a shell JSON round-trip.
The snapshot is published last and atomically, as the bundle's commit point.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .maintenance_protocol import canonical_hash


GROUPS = (
    "queue_store_files", "quota_store_files", "operational_effect_receipt_files",
    "operational_effect_surface_files", "oauth_proof_files",
)
PROJECTED = ("identity", "path", "path_identity_hash", "present", "byte_count", "content_hash")
EVIDENCE_KEYS = {*PROJECTED, "snapshot_path", "snapshot_hash"}
BINDINGS = {
    "queue_jobs_hash": ("queue", "jobs_hash"),
    "queue_jobs": ("queue", "jobs"),
    "quota_ledger_state_hash": ("quota_ledger", "state_hash"),
    "quota_ledger_tables": ("quota_ledger", "tables"),
    "operational_effects_hash": ("operational_effects", "receipts_hash"),
    "operational_effect_receipts": ("operational_effects", "receipts"),
}
ENVELOPE_KEYS = {
    "schema_version", "request_id", "role", "requested_at",
    "zero_effect_boundary_started_at", "observed_at", "former_manager_pid",
    "inspection_path", "inspection_hash", "byte_evidence",
}


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise PermissionError(message)


def _digest(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        _require(key not in result, "Snapshot JSON contains duplicate keys")
        result[key] = value
    return result


def _json(raw: bytes) -> Any:
    def invalid_constant(_: str) -> None:
        raise PermissionError("Snapshot JSON contains a non-finite number")
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_object, parse_constant=invalid_constant)


def _confined(root: Path, relative: str, scope: Path) -> Path:
    _require(type(relative) is str and bool(relative) and not Path(relative).is_absolute(), "Snapshot path is not relative")
    path = (root / relative).resolve()
    _require(path.is_relative_to(scope.resolve()) and path != scope.resolve(), "Snapshot path escaped its scope")
    return path


def _stamp(value: Any) -> datetime:
    _require(type(value) is str, "Snapshot timestamp must be a string")
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    _require(stamp.tzinfo is not None, "Snapshot timestamp lacks timezone")
    return stamp.astimezone(timezone.utc)


def _hash(value: Any) -> bool:
    return type(value) is str and re.fullmatch(r"sha256:[0-9a-f]{64}", value) is not None


def _projection(item: Any) -> dict[str, Any]:
    _require(type(item) is dict and set(item) == EVIDENCE_KEYS, "Snapshot byte evidence fields diverged")
    _require(type(item["identity"]) is str and bool(item["identity"]), "Snapshot byte identity is invalid")
    _require(type(item["present"]) is bool and _hash(item["path_identity_hash"]), "Snapshot byte evidence types diverged")
    if item["present"]:
        _require(type(item["byte_count"]) is int and item["byte_count"] >= 0 and _hash(item["content_hash"]), "Snapshot present-byte metadata is invalid")
    else:
        _require(all(item[key] is None for key in ("byte_count", "content_hash", "snapshot_path", "snapshot_hash")), "Snapshot absent-byte metadata must be null")
    return {key: item[key] for key in PROJECTED}


def _validate_byte_evidence(root: Path, scope: Path, records: Any, inspection: dict[str, Any]) -> dict[str, Any]:
    _require(type(records) is dict and set(records) == {*GROUPS, "oauth_runtime_token"}, "Snapshot byte groups diverged")
    projections: dict[str, Any] = {}
    seen: set[str] = set()
    paths: set[str] = set()
    copies: set[str] = set()
    watcher = None
    queue_path = "output/operations/phase6/runtime/phase6-queue.sqlite3"
    quota_path = "output/operations/zero-cost/phase6-quota-ledger.sqlite3"
    expected = {
        "queue_store_files": {queue_path + suffix: "QUEUE_" + tag for suffix, tag in (("", "MAIN"), ("-wal", "WAL"), ("-shm", "SHM"))},
        "quota_store_files": {quota_path + suffix: "QUOTA_" + tag for suffix, tag in (("", "MAIN"), ("-wal", "WAL"), ("-shm", "SHM"))},
        "operational_effect_receipt_files": {item["path"]: "EFFECT_RECEIPT:" + item["path"] for item in inspection["operational_effects"]["receipts"]},
        "operational_effect_surface_files": {path: "EFFECT_SURFACE:" + path for path in ("output/operations/phase6/package-treatment-executor-status.json", "output/operations/phase6/publication-controller-status.json")},
        "oauth_proof_files": {path: "OAUTH_PROOF:" + path for path in (
            "output/runtime/gestor-central/oauth-session-health.json",
            "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
            "output/runtime/gestor-central/oauth-reconsent-watcher.json",
            "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json",
            "output/integrations/youtube/heroverse/connection-receipt.json",
            "output/runtime/gestor-central/maintenance-capability.json",
        )},
    }
    for group in GROUPS:
        _require(type(records[group]) is list, "Snapshot byte group must remain an array")
        _require(len(records[group]) == len(expected[group]), "Snapshot byte group membership diverged")
        projections[group] = []
        for item in records[group]:
            projected = _projection(item)
            _require(type(item["path"]) is str and expected[group].get(item["path"]) == item["identity"], "Snapshot byte group membership diverged")
            _require(item["identity"] not in seen, "Snapshot byte identity is duplicated")
            seen.add(item["identity"])
            source = _confined(root, item["path"], root)
            _require(str(source).casefold() not in paths, "Snapshot byte source is duplicated")
            paths.add(str(source).casefold())
            _require(item["path_identity_hash"] == _digest(str(source).lower().encode()), "Snapshot source path identity diverged")
            _require(source.is_file() is item["present"], "Snapshot source presence changed during capture")
            if item["present"]:
                copy = _confined(root, item["snapshot_path"], scope)
                _require(str(copy).casefold() not in copies, "Snapshot byte copy is duplicated")
                copies.add(str(copy).casefold())
                raw = copy.read_bytes()
                _require(_hash(item["snapshot_hash"]) and item["snapshot_hash"] == item["content_hash"] == _digest(raw) and len(raw) == item["byte_count"], "Snapshot byte copy hash or size diverged")
                _require(source.read_bytes() == raw, "Snapshot source bytes changed during capture")
                if item["identity"] == "OAUTH_PROOF:output/runtime/gestor-central/oauth-reconsent-watcher.json":
                    watcher = _json(raw)
            projections[group].append(projected)
    token = records["oauth_runtime_token"]
    projections["oauth_runtime_token"] = _projection(token)
    _require(token["identity"] == "OAUTH_RUNTIME_TOKEN_EXTERNAL" and token["present"] is True and token["byte_count"] > 0 and all(token[key] is None for key in ("path", "snapshot_path", "snapshot_hash")), "Snapshot token is not safely redacted")
    _require(type(watcher) is dict and watcher.get("destination_exists") is True and watcher.get("destination_outside_workspace") is True, "Snapshot token watcher metadata is absent")
    destination = watcher.get("destination_path")
    _require(type(destination) is str and Path(destination).is_absolute(), "Snapshot token path metadata is invalid")
    destination_path = Path(destination).resolve()
    _require(not destination_path.is_relative_to(root), "Snapshot token must remain outside workspace")
    path_hash = _digest(str(destination_path).lower().encode())
    _require(path_hash == token["path_identity_hash"] == "sha256:" + str(watcher.get("destination_path_sha256")), "Snapshot token path binding diverged")
    # Metadata only: never open/hash the credential. D116 still verifies its
    # full bytes independently after recovery under the existing contract.
    _require(destination_path.is_file() and destination_path.stat().st_size == token["byte_count"], "Snapshot token presence or size diverged")
    return projections


def verify_projection(snapshot: dict[str, Any], canonical_state: Any, inspection: dict[str, Any]) -> None:
    state = snapshot.get("state")
    _require(type(state) is dict and set(state) == {*BINDINGS, *GROUPS, "oauth_runtime_token"}, "Snapshot state fields diverged")
    _require(canonical_hash(state) == canonical_hash(canonical_state) == snapshot.get("state_hash"), "Snapshot canonical state diverged")
    for key, (group, field) in BINDINGS.items():
        _require(type(inspection.get(group)) is dict and field in inspection[group], "Snapshot inspection binding is absent")
        _require(canonical_hash(state[key]) == canonical_hash(inspection[group][field]), "Snapshot differs from pinned inspection")
    for value, hash_key in (("queue_jobs", "queue_jobs_hash"), ("quota_ledger_tables", "quota_ledger_state_hash"), ("operational_effect_receipts", "operational_effects_hash")):
        _require(type(state[value]) is list and canonical_hash(state[value]) == state[hash_key], "Snapshot source collection hash or type diverged")


def _publish(path: Path, payload: bytes) -> None:
    """No-overwrite atomic publication. A final path never contains partial bytes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".snapshot-", suffix=".tmp", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary_path, path)
        except FileExistsError:
            _require(path.read_bytes() == payload, "Snapshot destination already contains different evidence")
    finally:
        temporary_path.unlink(missing_ok=True)


def compose(root: Path, envelope: dict[str, Any]) -> dict[str, Any]:
    root = root.resolve()
    _require(type(envelope) is dict and set(envelope) == ENVELOPE_KEYS and envelope["schema_version"] == "1.0.0", "Snapshot envelope contract diverged")
    request_id = envelope["request_id"]
    _require(type(request_id) is str and re.fullmatch(r"maintenance-request-[A-Za-z0-9-]+", request_id) is not None, "Snapshot request identity is invalid")
    role = envelope["role"]
    _require(role in {"PRE_REGRESSION", "POST_REGRESSION"}, "Snapshot role is invalid")
    _require(type(envelope["former_manager_pid"]) is int and envelope["former_manager_pid"] > 0, "Snapshot manager PID is invalid")
    before = role == "PRE_REGRESSION"
    role_slug = "pre-regression" if before else "post-regression"
    side = "before" if before else "after"
    relative = Path("output/runtime/gestor-central/maintenance-runs") / request_id
    run = _confined(root, relative.as_posix(), root)
    scope_relative = relative / "stopped-state-bytes" / role_slug
    scope = _confined(root, scope_relative.as_posix(), run)
    inspection_relative = (relative / f"stopped-state-{role_slug}-inspection.json").as_posix()
    _require(envelope["inspection_path"] == inspection_relative and _hash(envelope["inspection_hash"]), "Snapshot inspection path/hash is not exact")
    inspection_raw = _confined(root, inspection_relative, run).read_bytes()
    _require(_digest(inspection_raw) == envelope["inspection_hash"], "Snapshot pinned inspection hash diverged")
    inspection = _json(inspection_raw)
    _require(type(inspection) is dict and inspection.get("blockers") == [] and type(inspection.get("manager_pid")) is int and inspection["manager_pid"] == envelope["former_manager_pid"], "Snapshot inspection identity or blockers diverged")
    _require(_stamp(envelope["requested_at"]) <= _stamp(envelope["zero_effect_boundary_started_at"]) <= _stamp(inspection["observed_at"]) <= _stamp(envelope["observed_at"]), "Snapshot inspection time binding diverged")
    _require(inspection.get("active_lease_job_ids") == [] and inspection.get("quota", {}).get("reserved_ids") == [] and inspection.get("operational_effects", {}).get("open_receipt_paths") == [], "Snapshot inspection is not quiescent")
    state = _validate_byte_evidence(root, scope, envelope["byte_evidence"], inspection)
    for key, (group, field) in BINDINGS.items():
        _require(type(inspection.get(group)) is dict and field in inspection[group], "Snapshot inspection field is missing")
        state[key] = inspection[group][field]
    canonical_relative = (scope_relative / "canonical-state.json").as_posix()
    queue_relative = (relative / f"queue-{side}.json").as_posix()
    snapshot_relative = (relative / f"stopped-operational-state-{side}-regression.json").as_posix()
    canonical_raw = _bytes(state)
    snapshot = {**envelope, "canonical_state_path": canonical_relative, "canonical_state_hash": _digest(canonical_raw), "state_hash": canonical_hash(state), "state": state}
    verify_projection(snapshot, _json(canonical_raw), inspection)
    queue_raw = _bytes(inspection["queue"])
    snapshot_raw = _bytes(snapshot)
    # Reparse actual serialized bytes before any final file exists.
    verify_projection(_json(snapshot_raw), _json(canonical_raw), inspection)
    _require(canonical_hash(_json(queue_raw)) == canonical_hash(inspection["queue"]), "Snapshot queue serialization diverged")
    outputs = [(_confined(root, canonical_relative, scope), canonical_raw), (_confined(root, queue_relative, run), queue_raw), (_confined(root, snapshot_relative, run), snapshot_raw)]
    for path, payload in outputs:
        _require(not path.exists() or path.is_file() and path.read_bytes() == payload, "Snapshot destination already contains different evidence")
    # Dependencies first, final snapshot last. A crash leaves no partial final;
    # a replay may reuse only identical completed dependency files.
    for path, payload in outputs:
        _publish(path, payload)
    for path, payload in outputs:
        _require(path.read_bytes() == payload, "Snapshot published bytes diverged")
    return {"status": "PASS", "inspection_path": inspection_relative, "inspection_hash": envelope["inspection_hash"], "snapshot_path": snapshot_relative, "snapshot_hash": _digest(snapshot_raw), "canonical_state_path": canonical_relative, "canonical_state_hash": _digest(canonical_raw), "state_hash": snapshot["state_hash"], "queue_path": queue_relative, "queue_hash": _digest(queue_raw), "queue_jobs_hash": state["queue_jobs_hash"]}


def main() -> int:
    import sys
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    try:
        summary = compose(args.root, _json(sys.stdin.buffer.read()))
        print(json.dumps(summary, ensure_ascii=True))
        return 0
    except Exception:
        # Never expose watcher destination, external path or input contents.
        print(json.dumps({"status": "FAIL", "reason": "STOPPED_SNAPSHOT_COMPOSITION_REJECTED"}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
