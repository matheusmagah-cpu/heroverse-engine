from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from .db import DEFAULT_DB, ROOT, connect, load_config, utc_now


YOUTUBE_UPLOAD_SCOPE = "https://www.googleapis.com/auth/youtube.upload"


def build_youtube_video_body(payload: dict[str, Any]) -> dict[str, Any]:
    """Create the exact API body; pure so disclosure and safety fields are testable."""
    status: dict[str, Any] = {
        "privacyStatus": payload.get("privacy_status", "private"),
        "selfDeclaredMadeForKids": bool(payload.get("made_for_kids", False)),
        "containsSyntheticMedia": bool(payload.get("contains_synthetic_media", False)),
    }
    if payload.get("scheduled_at"):
        status["privacyStatus"] = "private"
        status["publishAt"] = payload["scheduled_at"]
    return {
        "snippet": {
            "title": payload["title"],
            "description": payload["description"],
            "tags": payload.get("tags") or [],
            "categoryId": payload.get("category_id") or "27",
            "defaultLanguage": payload.get("language") or "en",
            "defaultAudioLanguage": payload.get("audio_language") or payload.get("language") or "en",
        },
        "status": status,
    }


def prepare_upload(slug: str, scheduled_at: str | None = None, db_path: Path | None = None) -> Path:
    with connect(db_path or DEFAULT_DB) as conn:
        row = conn.execute("SELECT * FROM productions WHERE slug=?", (slug,)).fetchone()
    if not row:
        raise ValueError(f"Production not found: {slug}")
    if not row["render_path"] or not Path(row["render_path"]).exists():
        raise ValueError(f"Production {slug} has no completed render")
    quality_path = ROOT / "output" / "reports" / f"quality-{slug}.json"
    if not quality_path.exists():
        raise ValueError(f"Production {slug} has no objective quality report. Run `hero-engine quality <edl>` first.")
    quality = json.loads(quality_path.read_text(encoding="utf-8"))
    if not quality.get("release_ready"):
        raise ValueError(f"Production {slug} failed one or more critical quality gates")
    edl = json.loads(Path(row["edl_path"]).read_text(encoding="utf-8"))
    metadata = edl.get("metadata") or {}
    description = metadata.get("description")
    if not description:
        raise ValueError(f"Production {slug} has no approved viewer-first description package")
    payload = {
        "slug": slug,
        "video_file": row["render_path"],
        "title": metadata.get("primary_title") or edl["title_variants"][0],
        "description": description,
        "tags": metadata.get("tags") or [],
        "pinned_comment": metadata.get("pinned_comment"),
        "title_variants": edl["title_variants"],
        "thumbnail_text_variants": edl.get("thumbnail_text_variants") or [],
        "category_id": metadata.get("category_id") or "27",
        "language": "en",
        "privacy_status": "private",
        "scheduled_at": scheduled_at,
        "altered_content": False,
        "contains_synthetic_media": bool(metadata.get("contains_synthetic_media", False)),
        "made_for_kids": bool(metadata.get("made_for_kids", False)),
        "approval_required": bool(row["approval_required"]),
        "quality_score": quality["score"],
        "quality_report": str(quality_path),
        "prepared_at": utc_now(),
    }
    queue_dir = ROOT / "output" / "queue"
    queue_dir.mkdir(parents=True, exist_ok=True)
    path = queue_dir / f"{slug}.upload.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute(
            "UPDATE productions SET status='queued', scheduled_at=?, updated_at=? WHERE slug=?",
            (scheduled_at, utc_now(), slug),
        )
    return path


def upload(queue_file: Path, credentials_file: Path, token_file: Path, live: bool = False) -> dict[str, Any]:
    config = load_config()
    if config["safety"]["publish_mode"] != "live" or not live:
        raise PermissionError(
            "Publishing is locked in dry-run mode. Set safety.publish_mode to live and pass --live after reviewing the render."
        )
    try:
        from google.oauth2.credentials import Credentials  # type: ignore
        from google_auth_oauthlib.flow import InstalledAppFlow  # type: ignore
        from google.auth.transport.requests import Request  # type: ignore
        from googleapiclient.discovery import build  # type: ignore
        from googleapiclient.http import MediaFileUpload  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Google API dependencies are missing. Run scripts/setup.ps1.") from exc

    creds = None
    if token_file.exists():
        creds = Credentials.from_authorized_user_file(str(token_file), [YOUTUBE_UPLOAD_SCOPE])
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(str(credentials_file), [YOUTUBE_UPLOAD_SCOPE])
            creds = flow.run_local_server(port=0)
        token_file.write_text(creds.to_json(), encoding="utf-8")

    payload = json.loads(queue_file.read_text(encoding="utf-8"))
    if payload.get("approval_required"):
        raise PermissionError("This production still requires approval in the catalog before upload.")
    body = build_youtube_video_body(payload)
    youtube = build("youtube", "v3", credentials=creds)
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(payload["video_file"], chunksize=-1, resumable=True),
    )
    response = None
    while response is None:
        _, response = request.next_chunk()
    return response
