"""Read-only, hash-bound PCM inventory, NOT synthesis or production authority.

An existing whole utterance may be reused; concatenated fragment WAVs never
stand in for continuous speech. Consumers must call verify_inventory immediately
before using its audio/dependency bindings. No audio timing/quality is approved.
"""
from __future__ import annotations

import argparse
import array
import copy
import hashlib
import io
import json
import re
import sys
import wave
from pathlib import Path

from .phase6_narration_units import bytes_sha, canonical_sha, verify_narration_unit_plan

VERSION = "phase6-narration-audio-inventory-v1"
SCHEMA = "schemas/phase6_narration_audio_inventory.schema.json"
OUTPUT = "output/qa/phase6/diagnostics/narration-audio-inventory-v1"
DEFAULT_SOURCES = {
    "diagnostic": {"path": "output/qa/phase6/diagnostics/narration-units-v1/narration-continuity-9c22ad5af00a338a97f7877e.json", "sha256": "sha256:94706a7b317b2bf97a9d484c48f094b7854c5b6d38f34ecabe84929161e31904"},
    "proof": {"path": "output/qa/phase6/diagnostics/narration-unit-proof-20260906T044549920068Z/receipt.json", "sha256": "sha256:d47bb7ace0942d5ba5c624d7074d9a22962ee8234ec0ba3a3b6e2f01604ae99c"},
    "protocol": {"path": "output/operations/phase6/intelligence/experiments/active.json", "sha256": "sha256:3c427fcdeac7b77a98398bb15ab2e97c83ae09430f5f8e1d6aa928a67a47043f"},
    "treatment": {"path": "output/production/phase6/video-002/preproduction/treatment_contract.json", "sha256": "sha256:972aa92647772324f98b89d3a2f69dace073bd0c948a4d83c58756e6e87bf901"},
}

def _json(raw: bytes):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate JSON key")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def _path(root: Path, value: str, within: Path | None = None) -> Path:
    if not isinstance(value, str) or not value or ".." in Path(value).parts:
        raise PermissionError("invalid source path")
    path = (root / value).resolve(strict=True)
    if not path.is_relative_to(within or root) or not path.is_file():
        raise PermissionError("source escaped expected namespace")
    # Never recall cloud placeholders merely to produce this inventory.
    if getattr(path.stat(), "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000):
        raise PermissionError("non-resident source")
    return path


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def inspect_pcm(raw: bytes) -> dict:
    """Decode the same bytes that were hashed; no second-read TOCTOU window."""
    with wave.open(io.BytesIO(raw), "rb") as stream:
        frames, rate, channels, width = (stream.getnframes(), stream.getframerate(),
                                         stream.getnchannels(), stream.getsampwidth())
        pcm = stream.readframes(frames)
        if stream.getcomptype() != "NONE" or frames <= 0 or rate != 24000 or channels != 1 or width != 2 or len(pcm) != frames * 2:
            raise ValueError("whole mono 24kHz PCM16 WAV required")
    samples = array.array("h", pcm)
    if sys.byteorder != "little":
        samples.byteswap()
    return {"frame_count": frames, "sample_rate": rate, "channels": channels,
            "sample_width_bytes": width, "duration_ms": round(frames * 1000 / rate, 6),
            "pcm_sha256": bytes_sha(pcm), "sha256": bytes_sha(raw),
            "peak_linear": max(abs(int(v)) for v in samples) / 32768,
            "clipping_samples": sum(int(v) in (-32768, 32767) for v in samples)}


class Reader:
    def __init__(self, root: Path):
        self.root = root.resolve(strict=True)
        self.bindings: dict[str, dict] = {}

    def read(self, value: str, expected: str | None = None, *, within: Path | None = None) -> bytes:
        path = _path(self.root, value, within)
        raw = path.read_bytes()
        digest = bytes_sha(raw)
        if expected is not None and digest != expected:
            raise ValueError(f"source hash mismatch: {path.name}")
        self._record(path, digest, len(raw))
        return raw

    def _record(self, path: Path, digest: str, size: int):
        name = path.relative_to(self.root).as_posix() if path.is_relative_to(self.root) else str(path)
        value = {"path": name, "sha256": digest, "size_bytes": size}
        if name in self.bindings and self.bindings[name] != value:
            raise ValueError("source changed during inventory")
        self.bindings[name] = value

    def hash_file(self, path: Path, expected: str):
        path = path.resolve(strict=True)
        if _digest(path) != expected:
            raise ValueError("dependency hash mismatch")
        self._record(path, expected, path.stat().st_size)

    def load(self, binding: dict) -> dict:
        if set(binding) != {"path", "sha256"} or not re.fullmatch(r"sha256:[a-f0-9]{64}", binding["sha256"]):
            raise ValueError("explicit path/hash source binding required")
        return _json(self.read(binding["path"], binding["sha256"]))

    def schema(self, value: dict, name: str):
        from jsonschema import Draft202012Validator, FormatChecker
        Draft202012Validator(_json(self.read("schemas/" + name)), format_checker=FormatChecker()).validate(value)


def _espeak_files(reader: Reader, binding: dict) -> None:
    """Same length-prefixed path + file-byte hash as voice_phase5, without
    importing ONNX/Kokoro or loading a native DLL just to inspect files."""
    library = Path(binding["library_path"]).resolve(strict=True)
    base = Path(binding["data_path"]).resolve(strict=True)
    reader.hash_file(library, binding["library_hash"])
    actual = []
    for dll in sorted((p for p in library.parent.iterdir() if p.is_file() and p.suffix.lower() == ".dll"), key=lambda p: p.name.casefold()):
        if dll.resolve().parent != library.parent:
            raise PermissionError("DLL redirected")
        digest = _digest(dll)
        reader.hash_file(dll, digest)
        actual.append({"name": dll.name, "path": str(dll.resolve()), "content_hash": digest, "size_bytes": dll.stat().st_size})
    if actual != binding["directory_dlls"] or not actual:
        raise ValueError("eSpeak DLL inventory mismatch")
    digest = hashlib.sha256()
    files = sorted((p for p in base.rglob("*") if p.is_file()), key=lambda p: p.relative_to(base).as_posix())
    if not files:
        raise ValueError("empty eSpeak data")
    for path in files:
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(base):
            raise PermissionError("eSpeak data redirected outside root")
        relative = resolved.relative_to(base).as_posix().encode()
        raw = resolved.read_bytes()
        digest.update(len(relative).to_bytes(8, "big")); digest.update(relative); digest.update(raw)
        reader._record(resolved, bytes_sha(raw), len(raw))
    if "sha256:" + digest.hexdigest() != binding["data_hash"]:
        raise ValueError("eSpeak data hash mismatch")


def _proof_records(reader: Reader, sources: dict, diagnostic: dict, voice: dict) -> tuple[dict, dict]:
    proof = reader.load(sources["proof"])
    folder = (reader.root / sources["proof"]["path"]).resolve().parent
    if proof.get("status") != "PRODUCED_PENDING_INDEPENDENT_REVIEW" or proof.get("scope") != "THREE_UNIT_LOCAL_NARRATION_PROOF_ONLY":
        raise ValueError("unsupported proof state/scope")
    if any(proof.get(k) is not False for k in ("queue_authorized", "publication_authorized", "production_authorized")) or proof.get("technical_cost_brl") != 0:
        raise PermissionError("proof authority/cost differs")
    artifacts = proof["artifact_bindings"]
    for path, digest in artifacts.items():
        reader.read(str(folder / path), digest, within=folder)
    def child(name: str, key: str):
        if artifacts.get(name) != proof[key]:
            raise ValueError("proof journal binding mismatch")
        return _json(reader.read(str(folder / name), proof[key], within=folder))
    preflight = child("preflight.json", "preflight_sha256")
    synthesis = child("synthesis-preflight.json", "synthesis_preflight_sha256")
    order = child("diagnostic-order.json", "order_sha256")
    if preflight["status"] != "PASS" or synthesis["status"] != "PASS" or synthesis["preflight_sha256"] != proof["preflight_sha256"] or synthesis["order_sha256"] != proof["order_sha256"]:
        raise ValueError("proof preflight chain invalid")
    if order["source_diagnostic"] != sources["diagnostic"]["path"] or order["source_diagnostic_sha256"] != sources["diagnostic"]["sha256"]:
        raise ValueError("proof belongs to another narration plan")
    if preflight["input_bindings"] != diagnostic["source_files"][:3] or synthesis["espeak_binding"] != voice["espeak_binding"]:
        raise ValueError("proof source/eSpeak provenance mismatch")
    for field, key in (("model", "model_hash"), ("voices", "voices_hash")):
        if preflight[field]["sha256"] != voice[key]:
            raise ValueError("proof model/voice bank mismatch")
    units = {u["unit_id"]: u for u in diagnostic["plan"]["units"]}
    records = proof["records"]
    ids = [r["unit_id"] for r in records]
    if len(set(ids)) != len(ids) or ids != order["scope"] or proof["new_tts_calls"] != len(ids) or order["maximum_tts_calls"] != len(ids):
        raise ValueError("duplicate/incomplete proof utterances")
    if preflight["units"] != [units[uid] for uid in ids] or [p["unit_id"] for p in synthesis["phonemes"]] != ids:
        raise ValueError("proof utterance order or source unit differs")
    result = {}
    for record, phonemes in zip(records, synthesis["phonemes"], strict=True):
        unit = units[record["unit_id"]]
        if record["text"] != unit["text"] or record["speed"] != unit["pinned_speed"] or record["voice_id"] != voice["voice_id"] or record["window_limit_ms"] != unit["window_limit_ms"]:
            raise ValueError("proof text/voice/speed/window differs")
        if any(type(phonemes[k]) is not int for k in ("batch_count", "phoneme_count", "token_count")) or phonemes["text_sha256"] != unit["text_sha256"] or phonemes["batch_count"] != 1 or not 0 < phonemes["phoneme_count"] <= 510 or not 0 < phonemes["token_count"] <= 510:
            raise ValueError("proof continuous batch not established")
        relative = "staged/" + record["wav"]
        if relative not in artifacts or artifacts[relative] != record["measured"]["sha256"]:
            raise ValueError("proof PCM missing from journal")
        path = _path(reader.root, str(folder / relative), folder / "staged")
        measured = inspect_pcm(reader.read(str(path), artifacts[relative], within=folder / "staged"))
        expected = {"frames": measured["frame_count"], "sample_rate": 24000, "channels": 1,
                    "sample_width": 2, "duration_ms": measured["duration_ms"], "peak_linear": measured["peak_linear"],
                    "clipping_samples": measured["clipping_samples"], "sha256": measured["sha256"]}
        if any(type(record["measured"][k]) is not int for k in ("frames", "sample_rate", "channels", "sample_width", "clipping_samples")) or record["measured"] != expected:
            raise ValueError("proof PCM measurement mismatch")
        result[unit["unit_id"]] = {"path": path.relative_to(reader.root).as_posix(), **measured}
    return result, preflight


def build_inventory(root: Path, *, sources: dict | None = None) -> dict:
    """Read sources and dependencies, rederive every unit; no writes or effects."""
    sources = copy.deepcopy(DEFAULT_SOURCES if sources is None else sources)
    if set(sources) != set(DEFAULT_SOURCES):
        raise ValueError("complete pinned source bundle required")
    reader = Reader(root)
    diagnostic = reader.load(sources["diagnostic"])
    protocol, treatment = reader.load(sources["protocol"]), reader.load(sources["treatment"])
    plan, voice, script = [reader.load(b) for b in diagnostic["source_files"][:3]]
    reader.schema(plan, "take_plan.schema.json")
    reader.schema(voice, "voice_render_manifest.schema.json")
    reader.schema(script, "narrative_script.schema.json")
    reader.schema(protocol, "phase6_experiment_protocol.schema.json")
    reader.schema(diagnostic["plan"], "phase6_narration_unit_plan.schema.json")
    verify_narration_unit_plan(diagnostic["plan"], plan, voice)
    if voice["take_plan"]["sha256"] != diagnostic["source_files"][0]["sha256"] or voice["narrative_script"]["sha256"] != diagnostic["source_files"][2]["sha256"]:
        raise ValueError("voice raw source binding differs")
    if Path(diagnostic["source_files"][1]["path"]).stem != voice["voice_render_id"] or script["script_id"] != voice["script_id"] or script["version"] != voice["script_version"] or script["full_text"] != " ".join(t["narration"] for t in plan["takes"]):
        raise ValueError("script identity/copy mismatch")
    if protocol["status"] != "PREREGISTERED" or protocol["channel_id"] != plan["channel_id"] or protocol["treatment"]["variable"] != "TOPIC_ANGLE" or treatment["variable"] != "TOPIC_ANGLE" or not {"voice", "duration_band", "release_gates"}.issubset(protocol["treatment"]["control_lock"]):
        raise PermissionError("experiment scope/locks differ")
    bands = [re.fullmatch(r"(\d+)–(\d+) ms duration band for a new long-form treatment", text) for text in treatment["locked_constants"]]
    bands = [match for match in bands if match]
    if len(bands) != 1:
        raise ValueError("one explicit duration band required")
    band = [int(bands[0][1]), int(bands[0][2])]
    if not 0 < band[0] <= diagnostic["plan"]["timeline_duration_ms"] <= band[1]:
        raise ValueError("historical duration outside locked band")
    if voice["voice_id"] != "am_onyx" or voice["adapter_implementation"] != "KokoroFloatSpeed" or script["language"] != "en-US":
        raise PermissionError("unsupported pinned voice adapter/language")
    proof_records, preflight = _proof_records(reader, sources, diagnostic, voice)
    model = _path(reader.root, voice["model"], reader.root / "models")
    voices = _path(reader.root, preflight["voices"]["path"], reader.root / "models")
    reader.hash_file(model, voice["model_hash"]); reader.hash_file(voices, voice["voices_hash"])
    if model != _path(reader.root, preflight["model"]["path"], reader.root / "models"):
        raise ValueError("model path differs from synthesis provenance")
    _espeak_files(reader, voice["espeak_binding"])
    contract = {**copy.deepcopy(diagnostic["plan"]["voice_contract"]), "language": "en-US",
                "espeak_binding": copy.deepcopy(voice["espeak_binding"]), "packages_observed_at_proof": preflight["packages"],
                "adapter_current_source_sha256": bytes_sha(reader.read("hero_engine/voice_phase5.py")),
                "historical_adapter_binary_identity": "UNAVAILABLE_IN_VOICE_MANIFEST"}
    historical = {r["take_id"]: r for r in voice["takes"]}
    records = []
    for unit in diagnostic["plan"]["units"]:
        audio, state, origin = None, "NEEDS_SYNTHESIS", None
        if len(unit["take_ids"]) == 1:
            record = historical[unit["take_ids"][0]]
            path = _path(reader.root, record["path"], reader.root / "output/production/phase6/video-002/audio/takes")
            measured = inspect_pcm(reader.read(str(path), record["content_hash"]))
            if record["text"] != unit["text"] or record["speed"] != unit["pinned_speed"] or record["frame_count"] != measured["frame_count"] or round(measured["duration_ms"]) != record["duration_ms"] or abs(record["peak_linear"] - measured["peak_linear"]) > .000001 or record["clipping"] != bool(measured["clipping_samples"]):
                raise ValueError("historical utterance PCM/text/settings mismatch")
            audio = {"path": path.relative_to(reader.root).as_posix(), **measured}
            state, origin = "PCM_AVAILABLE_NOT_APPROVED", "HISTORICAL_SINGLE_TAKE"
        elif unit["unit_id"] in proof_records:
            audio = proof_records[unit["unit_id"]]
            state, origin = "PCM_AVAILABLE_NOT_APPROVED", "DIAGNOSTIC_CONTINUOUS_UTTERANCE"
        if unit["review_issues"]:
            state = "BLOCKED_UNIT_REVIEW"
        synthesis_identity = {"text": unit["text"], "voice_contract": contract, "speed": unit["pinned_speed"], "output": "MONO_24000_PCM16_WHOLE_UTTERANCE"}
        records.append({"unit_id": unit["unit_id"], "take_ids": unit["take_ids"], "text": unit["text"],
                        "text_sha256": unit["text_sha256"], "speed": unit["pinned_speed"], "state": state,
                        "origin": origin, "audio": audio, "synthesis_identity_sha256": canonical_sha(synthesis_identity),
                        "source_window_ms": [unit["window_start_ms"], unit["window_end_ms"]],
                        "word_alignment": None, "retimed_window_ms": None, "quality_status": "NOT_APPROVED",
                        "review_issues": unit["review_issues"], "production_eligible": False})
    hooks = records[:3]
    if [r["source_window_ms"] for r in hooks] != [[0, 1000], [1000, 3000], [3000, 8000]] or any(r["origin"] != "HISTORICAL_SINGLE_TAKE" for r in hooks):
        raise PermissionError("three exact historical hook windows/PCM must be preserved")
    missing = [r["unit_id"] for r in records if r["state"] == "NEEDS_SYNTHESIS"]
    reader.read("hero_engine/phase6_narration_units.py")
    reader.read("hero_engine/phase6_narration_audio_inventory.py")
    reader.read(SCHEMA)
    result = {"schema_version": "1.0.0", "inventory_version": VERSION,
              "status": "INVENTORIED_NOT_PRODUCTION_READY", "sources": sources,
              "channel_id": plan["channel_id"], "video_id": plan["video_id"], "take_plan_id": plan["take_plan_id"],
              "narration_plan_id": diagnostic["plan"]["plan_id"], "protocol_id": protocol["protocol_id"],
              "voice_contract": contract, "duration_band_ms": band, "historical_duration_ms": diagnostic["plan"]["timeline_duration_ms"],
              "units": records, "needs_synthesis_unit_ids": missing,
              "summary": {"unit_count": len(records), "historical_single_take_count": sum(r["origin"] == "HISTORICAL_SINGLE_TAKE" for r in records),
                          "diagnostic_continuous_count": sum(r["origin"] == "DIAGNOSTIC_CONTINUOUS_UTTERANCE" for r in records),
                          "needs_synthesis_count": len(missing), "blocked_unit_count": sum(r["state"] == "BLOCKED_UNIT_REVIEW" for r in records),
                          "available_pcm_frames": sum(r["audio"]["frame_count"] for r in records if r["audio"]), "complete_new_audio_duration_ms": None},
              "file_bindings": sorted(reader.bindings.values(), key=lambda b: b["path"]),
              "authority": {"synthesis_authorized": False, "render_authorized": False, "queue_authorized": False, "publication_authorized": False},
              "effects": {"new_tts_calls": 0, "render_calls": 0, "api_calls": 0, "queue_mutations": 0, "technical_cost_brl": 0},
              "limitations": ["PCM availability is not perceptual quality, pronunciation, continuity or release approval.",
                              "Historical manifest pins named adapter and model but not historical adapter source/binary or package versions; current source is a consumption dependency, not fabricated historical provenance.",
                              "Existing diagnostic ASR discrepancies in units 011 and 016 remain unresolved; this inventory performs no listening or ASR.",
                              "eSpeak native version is historical metadata tied to hashes, not a freshly executed native probe.",
                              "All retimed windows, word alignment and complete new audio duration remain unavailable.",
                              "Historical fragments of multi-take units are never concatenated as substitute continuous audio."]}
    result["inventory_id"] = "narration-audio-inventory-" + canonical_sha(result).split(":")[1][:24]
    reader.schema(result, Path(SCHEMA).name)
    # Re-read full bindings after composition; never silently skip missing/drifted files.
    for binding in result["file_bindings"]:
        path = (reader.root / binding["path"]).resolve(strict=True)
        if _digest(path) != binding["sha256"] or path.stat().st_size != binding["size_bytes"]:
            raise ValueError("source drift at inventory completion")
    return result


def verify_inventory(root: Path, candidate: dict, *, expected_sources: dict | None = None) -> None:
    sources = DEFAULT_SOURCES if expected_sources is None else expected_sources
    if candidate.get("sources") != sources:
        raise ValueError("inventory source bundle differs from caller-pinned source authority")
    if candidate != build_inventory(root, sources=sources):
        raise ValueError("inventory differs from complete source recomputation")


def materialize_inventory(root: Path) -> dict:
    root = root.resolve(strict=True)
    value = build_inventory(root)
    folder = root / OUTPUT
    if folder.resolve() != folder:
        raise PermissionError("diagnostic output redirected")
    encoded = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / (value["inventory_id"] + ".json")
    if target.exists():
        if target.read_bytes() != encoded:
            raise ValueError("immutable inventory collision")
    else:
        with target.open("xb") as stream:
            stream.write(encoded)
    return {"path": target.relative_to(root).as_posix(), "sha256": bytes_sha(encoded), "summary": value["summary"], "needs_synthesis_unit_ids": value["needs_synthesis_unit_ids"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Inventory existing PCM only; never synthesize/render or alter runtime")
    parser.add_argument("--diagnostic", action="store_true", required=True)
    parser.parse_args()
    print(json.dumps(materialize_inventory(Path.cwd()), indent=2))
