from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
V3 = Path("output/production/phase5/pilot-001/creative-v3")
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _artifact(root: Path, path: Path) -> dict[str, str]:
    absolute = path if path.is_absolute() else root / path
    return {"path": str(absolute), "sha256": _hash(absolute)}


def _optional_artifact(root: Path, path: Path) -> dict[str, str] | None:
    absolute = path if path.is_absolute() else root / path
    return _artifact(root, absolute) if absolute.is_file() else None


def _build_audio_static_release_gate(root, relative, bindings, created_at):
    from .publication_package_phase5 import build_publication_package, read_audio_static_packaging
    from .standard_qualification_phase5 import read_audio_static_codec_controls, verify_audio_static_execution
    from .phase5_autonomous_quality import measure_audio_static_intelligibility
    root = root.resolve()
    required={'quality_report','measurements','publication_package'}
    allowed=required|{'visual_controls','render_execution','asr_receipt','format_transition'}
    if not isinstance(bindings,dict) or not required.issubset(bindings) or set(bindings)-allowed:
        raise PermissionError('Current release binding population is incomplete or unknown')
    current = build_publication_package(root, package_relative=relative,
        quality_report_binding=bindings['quality_report'], measurement_binding=bindings['measurements'])
    directory = (root/relative).resolve()
    inputs = {}
    def bound(name, expected_path):
        binding = bindings.get(name)
        path = expected_path.resolve()
        if not binding or Path(binding['path']).resolve() != path:
            raise PermissionError('Release requires the exact '+name+' external binding')
        raw = path.read_bytes(); digest = hashlib.sha256(raw).hexdigest()
        if binding['sha256'] != 'sha256:'+digest:
            raise PermissionError('Release '+name+' anchor differs')
        inputs[path] = digest
        return json.loads(raw.decode('utf-8-sig'))
    package_path = directory/'publication_package.json'
    package = bound('publication_package', package_path)
    if {k:v for k,v in package.items() if k!='created_at'} != {
            k:v for k,v in current.items() if k!='created_at'}:
        raise PermissionError('Frozen publication package does not represent current inputs')
    qa_path = directory/'qa/creative_quality_gate_report.json'
    qa = bound('quality_report', qa_path)
    measured = bound('measurements', directory/'qa/technical_measurements.json')
    packaging = read_audio_static_packaging(root, package_relative=relative)
    for row in packaging['inputs']:
        inputs[Path(row['path'])] = row['sha256'].removeprefix('sha256:')
    video = Path(package['video']['path'])
    inputs[video] = package['video']['sha256']
    controls = execution = intelligibility = None
    if bindings.get('visual_controls'):
        controls = read_audio_static_codec_controls(root, directory, binding=bindings['visual_controls'])
        if measured.get('static_codec_controls') != controls:
            raise PermissionError('Release control observation differs from measured QA')
    if bindings.get('render_execution'):
        execution = verify_audio_static_execution(root, directory, video, binding=bindings['render_execution'])
        if measured.get('static_observed_execution') != execution:
            raise PermissionError('Release execution differs from measured QA')
    if bindings.get('asr_receipt'):
        intelligibility = measure_audio_static_intelligibility(root, directory, video,
            expected_media_hash='sha256:'+package['video']['sha256'], receipt_binding=bindings['asr_receipt'])
        if measured.get('intelligibility') != intelligibility:
            raise PermissionError('Release ASR differs from the measured final artifact')
        inputs[Path(bindings['asr_receipt']['path'])] = bindings['asr_receipt']['sha256'].removeprefix('sha256:')
        asr_receipt=_read(Path(bindings['asr_receipt']['path']))
        for row in asr_receipt['transcript']['model_bindings']:
            inputs[Path(row['path'])]=row['sha256'].removeprefix('sha256:')
    for observation in (controls, execution):
        if observation is not None:
            inputs[Path(observation['binding']['path'])] = observation['binding']['sha256'].removeprefix('sha256:')
            for row in observation['authenticated_inputs']:
                inputs[Path(row['path'])] = row['sha256'].removeprefix('sha256:')
    for row in measured['static_editorial']['inputs']:
        inputs[Path(row['path'])] = row['sha256'].removeprefix('sha256:')
    inputs[directory/'render_manifest.json'] = _hash(directory/'render_manifest.json')
    policy_paths = {
        'pack':root/'config/format_packs/fp-narrated-reflection-static-v1.json',
        'oauth':root/'output/integrations/youtube/heroverse/operational-readiness.json',
        'scope':root/'output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json',
        'channel':root/'output/audits/channel/heroverse/channel-readiness-audit.json',
        'cost':root/'output/operations/zero-cost/phase5-publication-pipeline-preflight.json'}
    policy = {}
    for name,path in policy_paths.items():
        raw=path.read_bytes();inputs[path]=hashlib.sha256(raw).hexdigest()
        policy[name]=json.loads(raw.decode('utf-8-sig'))
    transition_path=directory/'autonomous-review/format_pack_transition_receipt.json'
    transition=None
    if bindings.get('format_transition'):
        transition=bound('format_transition',transition_path)
    pack=policy['pack']
    # A package-local canary receipt must bind this exact observation. A global
    # LIMITED pack or a legacy cinematic transition cannot approve this media.
    canary = bool(pack['capability_status'] in ('SPECIFIED','PROTOTYPED','VALIDATED','LIMITED','PRODUCTION_READY')
        and transition
        and transition.get('basis')=='AUTHENTICATED_AUDIO_STATIC_FINAL_QA'
        and transition.get('package_id')==package['package_id']
        and transition.get('quality_report')==bindings['quality_report']
        and transition.get('measurements')==bindings['measurements']
        and transition.get('format_pack_id')==pack['format_pack_id']
        and transition.get('format_pack_version')==pack['version']
        and transition.get('channel_id')==CHANNEL_ID
        and transition.get('video_sha256')==package['video']['sha256']
        and transition.get('controls')==bindings.get('visual_controls')
        and transition.get('execution')==bindings.get('render_execution')
        and transition.get('asr')==bindings.get('asr_receipt')
        and transition.get('pack_sha256')==inputs[policy_paths['pack']]
        and transition.get('producer_sha256')==_hash(Path(__file__))
        and transition.get('scope')=={'maximum_releases':1,'global_pack_promotion':False,
                                     'exact_media_only':True,'privacy':'private-first'})
    inputs[Path(__file__)]=_hash(Path(__file__))
    perceptual = package['quality_gate']['automatic_status']=='PASS' and bool(intelligibility and intelligibility['passed'])
    calibrated = controls is not None and execution is not None
    oauth=policy['oauth'];scopes=policy['scope'];channel=policy['channel'];cost=policy['cost']
    checks = [
        ('ARTIFACT_INTEGRITY', True, [str(package_path)]),
        ('AUTOMATIC_QUALITY', perceptual, [str(qa_path)]),
        ('AUTONOMOUS_PERCEPTUAL_QUALITY', perceptual and calibrated, [str(qa_path)]),
        ('INDEPENDENT_CODEC_CALIBRATION', calibrated, ['Externally anchored disjoint controls and observed encoder']),
        ('THUMBNAIL_SELECTION', True, [package['thumbnail']['path']]),
        ('CAPTION_REVIEW', bool(intelligibility and intelligibility['passed']), [package['captions']['path']]),
        ('FORMAT_CAPABILITY', canary, [str(policy_paths['pack']),str(transition_path)]),
        ('RIGHTS', package['rights']['status']=='PASS_AUTOMATIC', [package['rights']['manifest']]),
        ('CHANNEL_READINESS', channel['overall_status']=='PASS' and not channel['publication_gate']['critical_open_gates'], [str(policy_paths['channel'])]),
        ('OAUTH_DURABILITY', package['integration']['identity_verified'] and oauth['continuous_operation_ready'] is True
            and oauth['publication_guard']['upload_permitted'] is True, [str(policy_paths['oauth'])]),
        ('OAUTH_SCOPE_ALIGNMENT', scopes['status']=='PASS' and not scopes['missing_scopes'], [str(policy_paths['scope'])]),
        ('PRIVATE_FIRST', package['metadata']['privacy_status']=='private', ['privacyStatus=private']),
        ('ZERO_COST_AND_FREE_QUOTA', cost['technical_cost_brl']==0 and cost['execution_permitted'] is True, [str(policy_paths['cost'])])]
    gates=[{'gate':name,'critical':True,'status':'PASS' if passed else 'BLOCKED','evidence':evidence}
           for name,passed,evidence in checks]
    blockers=[row['gate'] for row in gates if row['status']!='PASS'];ready=not blockers
    identity=hashlib.sha256(f"{CHANNEL_ID}|{package['video']['sha256']}|{package['package_id']}".encode()).hexdigest()
    result={'schema_version':'1.1.0','release_id':'phase5-release-'+identity[:20],
        'channel_id':CHANNEL_ID,'package_id':package['package_id'],
        'decision':'READY_FOR_PUBLICATION_PIPELINE' if ready else 'BLOCKED',
        'publication_pipeline_permitted':ready,'staging_privacy_status':'private','final_privacy_status':'public',
        'selected_thumbnail':'owned-static','artifacts':{
            'video':_artifact(root,video),'thumbnail':_artifact(root,Path(package['thumbnail']['path'])),
            'captions':_artifact(root,Path(package['captions']['path'])),
            'publication_package':_artifact(root,package_path),'autonomous_review':_artifact(root,qa_path),
            'human_review':None,'format_transition':_artifact(root,transition_path) if transition else None,
            'oauth_readiness':_artifact(root,policy_paths['oauth']),'scope_requirement':_artifact(root,policy_paths['scope']),
            'channel_audit':_artifact(root,policy_paths['channel']),'zero_cost':_artifact(root,policy_paths['cost'])},
        'gates':gates,'blockers':blockers,
        'authorized_api_methods':['channels.list','videos.insert','videos.list','videos.update','thumbnails.set','captions.insert'] if ready else [],
        'idempotency_key':identity,'claim_boundary':'Current audio/static release only. Source provenance alone is not final QA; exact final media, independently anchored controls/ASR, observed execution, current canary capability, channel/OAuth/cost gates are required. No legacy calibration, revenue or performance claim.',
        'created_at':created_at or datetime.now(timezone.utc).isoformat().replace('+00:00','Z')}
    if any(_hash(path)!=expected for path,expected in inputs.items()):
        raise PermissionError('Release input changed before decision')
    final_package=build_publication_package(root,package_relative=relative,
        quality_report_binding=bindings['quality_report'],measurement_binding=bindings['measurements'])
    if {k:v for k,v in final_package.items() if k!='created_at'} != {
            k:v for k,v in current.items() if k!='created_at'}:
        raise PermissionError('Current package or connection changed before release decision')
    Draft202012Validator(_read(root/'schemas/phase5_release_gate.schema.json')).validate(result)
    return result


def _build_instrumental_release_gate(root, relative, bindings, created_at):
    from .publication_package_phase5 import build_publication_package
    root=root.resolve();directory=(root/relative).resolve()
    required={'music_inputs','qualification_inputs','publication_package'}
    if not required.issubset(bindings) or set(bindings)-required-{'format_transition'}:
        raise PermissionError('instrumental release binding population incomplete or unknown')
    current=build_publication_package(root,package_relative=relative,music_bindings=bindings['music_inputs'],
        music_qualification_bindings=bindings['qualification_inputs'])
    captures={}
    def bound(ref,expected):
        expected=expected.resolve()
        if (set(ref)!={'path','sha256'} or Path(ref['path']).resolve()!=expected
                or not expected.is_relative_to(root) or 'sha256:'+_hash(expected)!=ref['sha256']):
            raise PermissionError('instrumental release exact artifact anchor diverged')
        captures[expected]=_hash(expected);return _read(expected)
    package_path=directory/'publication_package.json'
    package=bound(bindings['publication_package'],package_path)
    if {k:v for k,v in package.items() if k!='created_at'}!={k:v for k,v in current.items() if k!='created_at'}:
        raise PermissionError('instrumental publication package is not current')
    spoken=package['schema_version']=='1.2.0'
    from .creative_direction import rest_delivery_format
    recipe=_read(Path(bindings['music_inputs']['recipe']['path']))
    mode=rest_delivery_format(recipe)
    paths={'pack':root/'config/format_packs'/mode['pack_file'],
        'oauth':root/'output/integrations/youtube/heroverse/operational-readiness.json',
        'scope':root/'output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json',
        'channel':root/'output/audits/channel/heroverse/channel-readiness-audit.json',
        'cost':root/'output/operations/zero-cost/phase5-publication-pipeline-preflight.json'}
    policy={name:_read(path) for name,path in paths.items()};captures.update({p:_hash(p) for p in paths.values()})
    pack=policy['pack'];oauth=policy['oauth'];scope=policy['scope'];channel=policy['channel'];cost=policy['cost']
    transition_path=directory/'autonomous-review/format_pack_transition_receipt.json'
    expected_transition={'basis':mode['transition_basis'],'package_id':package['package_id'],
        'music_inputs':bindings['music_inputs'],'qualification_inputs':bindings['qualification_inputs'],
        'video_sha256':package['video']['sha256'],'channel_id':CHANNEL_ID,
        'format_pack_id':pack['format_pack_id'],'format_pack_version':pack['version'],
        'pack_sha256':captures[paths['pack']],'producer_sha256':_hash(Path(__file__)),
        'scope':{'maximum_releases':1,'global_pack_promotion':False,'exact_media_only':True,'privacy':'private-first'}}
    transition=bound(bindings['format_transition'],transition_path) if bindings.get('format_transition') else None
    canary=(transition==expected_transition and pack['capability_status'] in
        ('SPECIFIED','PROTOTYPED','VALIDATED','LIMITED','PRODUCTION_READY'))
    checks=[('ARTIFACT_INTEGRITY',True),('AUTOMATIC_QUALITY',True),('AUTONOMOUS_PERCEPTUAL_QUALITY',True),
        ('INDEPENDENT_CODEC_CALIBRATION',True),('THUMBNAIL_SELECTION',True),
        ('CAPTION_REVIEW',(package['captions_applicability']=='MEASURED_SPOKEN_OPENING_ONLY'
            and bool(package.get('captions'))) if spoken else
            package['captions_applicability']=='NOT_APPLICABLE_INSTRUMENTAL_NO_SPEECH'),
        ('FORMAT_CAPABILITY',canary),('RIGHTS',package['rights']['status']=='PASS_AUTOMATIC'),
        ('CHANNEL_READINESS',package['integration']['identity_verified'] and channel['overall_status']=='PASS'
            and not channel['publication_gate']['critical_open_gates']),
        ('OAUTH_DURABILITY',package['integration']['identity_verified'] and oauth['continuous_operation_ready'] is True
            and oauth['publication_guard']['upload_permitted'] is True),
        ('OAUTH_SCOPE_ALIGNMENT',scope['status']=='PASS' and not scope['missing_scopes']),
        ('PRIVATE_FIRST',package['metadata']['privacy_status']=='private'),
        ('ZERO_COST_AND_FREE_QUOTA',cost['technical_cost_brl']==0 and cost['execution_permitted'] is True)]
    evidence=[str(package_path),bindings['qualification_inputs']['qualification']['path']]
    gates=[{'gate':name,'critical':True,'status':'PASS' if ok else 'BLOCKED','evidence':evidence} for name,ok in checks]
    blockers=[r['gate'] for r in gates if r['status']!='PASS'];ready=not blockers
    identity=hashlib.sha256(f"{CHANNEL_ID}|{package['video']['sha256']}|{package['package_id']}".encode()).hexdigest()
    result={'schema_version':mode['release_schema'],'release_id':'phase5-release-'+identity[:20],'channel_id':CHANNEL_ID,
        'package_id':package['package_id'],'decision':'READY_FOR_PUBLICATION_PIPELINE' if ready else 'BLOCKED',
        'publication_pipeline_permitted':ready,'staging_privacy_status':'private','final_privacy_status':'public',
        'selected_thumbnail':'owned-static','instrumental_inputs':bindings['music_inputs'],
        'instrumental_qualification':bindings['qualification_inputs'],
        'artifacts':{'video':_artifact(root,Path(package['video']['path'])),
            'thumbnail':_artifact(root,Path(package['thumbnail']['path'])),
            'captions':_artifact(root,Path(package['captions']['path'])) if spoken else None,
            'publication_package':_artifact(root,package_path),
            'autonomous_review':_artifact(root,Path(bindings['qualification_inputs']['qualification']['path'])),
            'human_review':None,'format_transition':_artifact(root,transition_path) if transition else None,
            'oauth_readiness':_artifact(root,paths['oauth']),'scope_requirement':_artifact(root,paths['scope']),
            'channel_audit':_artifact(root,paths['channel']),'zero_cost':_artifact(root,paths['cost'])},
        'gates':gates,'blockers':blockers,'authorized_api_methods':[
            'channels.list','videos.insert','videos.list','videos.update','thumbnails.set'] if ready else [],
        'idempotency_key':identity,'claim_boundary':'Exact original instrumental only; no spoken captions/ASR or medical/comfort/outcome claim. Full musical/source/render/visual observations plus current policy and exact-media canary required.',
        'created_at':created_at or datetime.now(timezone.utc).isoformat()}
    if spoken:
        if ready:result['authorized_api_methods'].append('captions.insert')
        result['claim_boundary']='Exact original spoken reflection once then owned composed prayer music; final ASR captions cover speech only. No YPP, medical, sleep, fatigue-free or outcome guarantee.'
    if any(_hash(path)!=digest for path,digest in captures.items()):raise PermissionError('instrumental release policy changed')
    final=build_publication_package(root,package_relative=relative,music_bindings=bindings['music_inputs'],
        music_qualification_bindings=bindings['qualification_inputs'])
    if {k:v for k,v in final.items() if k!='created_at'}!={k:v for k,v in current.items() if k!='created_at'}:
        raise PermissionError('instrumental release native inputs changed before decision')
    Draft202012Validator(_read(root/'schemas/phase5_release_gate.schema.json')).validate(result)
    return result


def build_release_gate(root: Path = ROOT, *, created_at: str | None = None,
                       package_relative: Path | None = None, current_bindings=None) -> dict[str, Any]:
    if package_relative is not None:
        if current_bindings and 'music_inputs' in current_bindings:
            return _build_instrumental_release_gate(root,Path(package_relative),current_bindings,created_at)
        return _build_audio_static_release_gate(root,Path(package_relative),current_bindings or {},created_at)
    if current_bindings is not None:
        raise PermissionError('Audio release bindings require an explicit current package')
    root = root.resolve()
    package_path = root / V3 / "publication_package.json"
    human_path = root / V3 / "human-review/review_submission.json"
    autonomous_path = root / V3 / "autonomous-review/autonomous_quality_evaluation.json"
    transition_path = root / V3 / "autonomous-review/format_pack_transition_receipt.json"
    pack_path = root / "config/format_packs/fp-broll-cinematic-narration-v1.json"
    oauth_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    scope_path = root / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
    channel_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    zero_cost_path = root / "output/operations/zero-cost/phase5-publication-pipeline-preflight.json"
    package = _read(package_path)
    autonomous = _read(autonomous_path)
    pack = _read(pack_path)
    oauth = _read(oauth_path)
    scopes = _read(scope_path)
    channel = _read(channel_path)
    zero_cost = _read(zero_cost_path)
    human = _read(human_path) if human_path.is_file() else None
    transition = _read(transition_path) if transition_path.is_file() else None

    selected = autonomous.get("thumbnail_selection", {}).get("candidate_id")
    thumbs = _read(root / V3 / "thumbnail/thumbnail_set_manifest.json")
    thumb = next((item for item in thumbs["candidates"] if item["candidate_id"] == selected), None)
    video_path = Path(package["video"]["path"])
    caption_path = Path(package["captions"]["path"])
    hash_ok = (
        video_path.is_file() and _hash(video_path) == package["video"]["sha256"]
        and caption_path.is_file() and _hash(caption_path) == package["captions"]["sha256"]
    )
    thumb_ok = bool(thumb and Path(thumb["path"]).is_file() and _hash(Path(thumb["path"])) == thumb["content_hash"].removeprefix("sha256:"))
    autonomous_pass = bool(
        autonomous["decision"] == "PASS_LIMITED_CANARY"
        and autonomous["publication_eligible"] is True
        and autonomous["artifact"]["sha256"] == package["video"]["sha256"]
        and all(item["status"] == "PASS" for item in autonomous["gates"])
    )
    gold_policy_pass = bool(
        autonomous["calibration"]["human_gold_standard_available"] is True
        and autonomous["calibration"]["gold_standard_validation_pass"] is True
        and autonomous["calibration"]["negative_control_detected"] is True
        and autonomous["audit_policy"]["per_release_human_review"] is False
        and autonomous["audit_policy"]["routine_human_sample_rate"] > 0
    )
    pack_pass = bool(
        pack["capability_status"] in {"LIMITED", "PRODUCTION_READY"}
        and pack["production_allowed"] is True
        and transition is not None
        and transition.get("basis") == "AUTONOMOUS_QUALITY_PASS_WITH_HUMAN_GOLD_STANDARD_AND_CANARY_LIMIT"
    )
    oauth_pass = oauth["continuous_operation_ready"] is True and oauth["publication_guard"]["upload_permitted"] is True
    scope_pass = scopes["status"] == "PASS" and not scopes["missing_scopes"]
    channel_pass = channel["overall_status"] == "PASS" and not channel["publication_gate"]["critical_open_gates"]
    rights_pass = package["rights"]["status"] == "PASS_AUTOMATIC"
    automatic_pass = package["quality_gate"]["automatic_status"] == "PASS"
    caption_gate = next((item for item in autonomous["gates"] if item["gate"] == "CAPTIONS"), None)
    caption_pass = bool(caption_gate and caption_gate["status"] == "PASS" and package["captions"]["cue_count"] > 0)
    privacy_pass = package["metadata"]["privacy_status"] == "private"
    zero_cost_pass = zero_cost["technical_cost_brl"] == 0 and zero_cost["execution_permitted"] is True
    gates = [
        ("ARTIFACT_INTEGRITY", hash_ok, [package["video"]["sha256"], package["captions"]["sha256"]]),
        ("AUTOMATIC_QUALITY", automatic_pass, [package["quality_gate"]["report"]]),
        ("AUTONOMOUS_PERCEPTUAL_QUALITY", autonomous_pass, [str(autonomous_path)]),
        ("HUMAN_GOLD_STANDARD_POLICY", gold_policy_pass, [str(autonomous_path), "data/gold_standard/validation_report.json", "docs/DECISIONS.md:D-021"]),
        ("THUMBNAIL_SELECTION", thumb_ok, [str(root / V3 / "thumbnail/thumbnail_set_manifest.json"), f"selected={selected}"]),
        ("CAPTION_REVIEW", caption_pass, [str(caption_path), f"cue_count={package['captions']['cue_count']}"]),
        ("FORMAT_CAPABILITY", pack_pass, [str(pack_path), str(transition_path)]),
        ("RIGHTS", rights_pass, [package["rights"]["manifest"], package["rights"]["attribution"]]),
        ("CHANNEL_READINESS", channel_pass, [str(channel_path)]),
        ("OAUTH_DURABILITY", oauth_pass, [str(oauth_path)]),
        ("OAUTH_SCOPE_ALIGNMENT", scope_pass, [str(scope_path)]),
        ("PRIVATE_FIRST", privacy_pass, ["privacyStatus=private"]),
        ("ZERO_COST_AND_FREE_QUOTA", zero_cost_pass, [str(zero_cost_path), f"quota_status={zero_cost['quota_status']}"]),
    ]
    gate_rows = [{"gate": name, "critical": True, "status": "PASS" if passed else "BLOCKED", "evidence": evidence} for name, passed, evidence in gates]
    blockers = [row["gate"] for row in gate_rows if row["status"] != "PASS"]
    ready = not blockers
    idempotency = hashlib.sha256(f"{CHANNEL_ID}|{package['video']['sha256']}|{package['package_id']}".encode()).hexdigest()
    result = {
        "schema_version": "1.1.0",
        "release_id": f"phase5-release-{idempotency[:20]}",
        "channel_id": CHANNEL_ID,
        "package_id": package["package_id"],
        "decision": "READY_FOR_PUBLICATION_PIPELINE" if ready else "BLOCKED",
        "publication_pipeline_permitted": ready,
        "staging_privacy_status": "private",
        "final_privacy_status": "public",
        "selected_thumbnail": selected,
        "artifacts": {
            "video": _artifact(root, video_path),
            "thumbnail": _artifact(root, Path(thumb["path"])) if thumb_ok else None,
            "captions": _artifact(root, caption_path),
            "publication_package": _artifact(root, package_path),
            "autonomous_review": _artifact(root, autonomous_path),
            "human_review": _optional_artifact(root, human_path),
            "format_transition": _optional_artifact(root, transition_path),
            "oauth_readiness": _artifact(root, oauth_path),
            "scope_requirement": _artifact(root, scope_path),
            "channel_audit": _artifact(root, channel_path),
            "zero_cost": _artifact(root, zero_cost_path),
        },
        "gates": gate_rows,
        "blockers": blockers,
        "authorized_api_methods": ["channels.list", "videos.insert", "videos.list", "videos.update", "thumbnails.set", "captions.insert"] if ready else [],
        "idempotency_key": idempotency,
        "claim_boundary": "READY authorizes one LIMITED canary, private-first staging upload of the exact frozen artifacts and automatic promotion to public only after post-upload identity, processing, thumbnail and caption checks. Human gold-standard review is calibration/exception sampling, not a manual form per release. It does not authorize Ads, deletion, unrelated metadata mutation, another channel or a performance guarantee.",
        "created_at": created_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    Draft202012Validator(_read(root / "schemas/phase5_release_gate.schema.json")).validate(result)
    return result


def stage_audio_static_canary(root: Path = ROOT, *, package_relative: Path, current_bindings) -> Path:
    if 'music_inputs' in current_bindings:
        from .phase6_asset_residency import _write_immutable
        checked=build_release_gate(root,package_relative=package_relative,current_bindings=current_bindings)
        if checked['blockers']!=['FORMAT_CAPABILITY']:
            raise PermissionError('instrumental canary requires all other release gates PASS')
        from .creative_direction import rest_delivery_format
        mode=rest_delivery_format(_read(Path(current_bindings['music_inputs']['recipe']['path'])))
        pack=root/'config/format_packs'/mode['pack_file'];value=_read(pack)
        receipt={'basis':mode['transition_basis'],'package_id':checked['package_id'],
            'music_inputs':current_bindings['music_inputs'],'qualification_inputs':current_bindings['qualification_inputs'],
            'video_sha256':checked['artifacts']['video']['sha256'],'channel_id':CHANNEL_ID,
            'format_pack_id':value['format_pack_id'],'format_pack_version':value['version'],
            'pack_sha256':_hash(pack),'producer_sha256':_hash(Path(__file__)),
            'scope':{'maximum_releases':1,'global_pack_promotion':False,'exact_media_only':True,'privacy':'private-first'}}
        path=root.resolve()/package_relative/'autonomous-review/format_pack_transition_receipt.json'
        _write_immutable(path,receipt);return path
    """Scope one measured pilot; never mutate the Pack or bypass another gate."""
    from .phase6_asset_residency import _write_immutable
    # Discarding a rejected transition is not a fallback. It must be reconciled,
    # not silently replaced by another receipt with a conveniently new name.
    if current_bindings.get('format_transition'):
        result=build_release_gate(root,package_relative=package_relative,current_bindings=current_bindings)
        if not result['publication_pipeline_permitted']:
            raise PermissionError('Existing canary failed the release reader')
        return Path(current_bindings['format_transition']['path'])
    result=build_release_gate(root,package_relative=package_relative,current_bindings=current_bindings)
    if result['blockers']!=['FORMAT_CAPABILITY']:
        raise PermissionError('Canary requires all actual quality/policy gates: '+','.join(result['blockers']))
    root=root.resolve();directory=(root/package_relative).resolve()
    package=_read(directory/'publication_package.json')
    pack_path=root/'config/format_packs/fp-narrated-reflection-static-v1.json';pack=_read(pack_path)
    receipt={'basis':'AUTHENTICATED_AUDIO_STATIC_FINAL_QA','package_id':package['package_id'],
        'quality_report':current_bindings['quality_report'],'measurements':current_bindings['measurements'],
        'format_pack_id':pack['format_pack_id'],'format_pack_version':pack['version'],'channel_id':CHANNEL_ID,
        'video_sha256':package['video']['sha256'],'controls':current_bindings['visual_controls'],
        'execution':current_bindings['render_execution'],'asr':current_bindings['asr_receipt'],
        'pack_sha256':_hash(pack_path),'producer_sha256':_hash(Path(__file__)),
        'scope':{'maximum_releases':1,'global_pack_promotion':False,'exact_media_only':True,'privacy':'private-first'}}
    path=directory/'autonomous-review/format_pack_transition_receipt.json'
    if path.exists():
        if _read(path)!=receipt:raise PermissionError('Existing canary differs; preserve and reconcile')
    else:_write_immutable(path,receipt)
    # Reopen all readers after persistence. Returning a receipt is not an
    # attestation for a changed future invocation or a global pack transition.
    bindings={**current_bindings,'format_transition':{'path':str(path),'sha256':'sha256:'+_hash(path)}}
    final=build_release_gate(root,package_relative=package_relative,current_bindings=bindings)
    if not final['publication_pipeline_permitted']:
        raise PermissionError('Canary inputs changed before final recheck')
    return path


def materialize(root: Path = ROOT, *, package_relative: Path | None = None, current_bindings=None) -> Path:
    if package_relative is not None:
        from .phase6_asset_residency import _write_immutable
        value=build_release_gate(root,package_relative=package_relative,current_bindings=current_bindings)
        path=root.resolve()/package_relative/'release_gate.json'
        if path.exists():
            existing=_read(path)
            if {k:v for k,v in existing.items() if k!='created_at'} != {
                    k:v for k,v in value.items() if k!='created_at'}:
                raise PermissionError('Existing release differs; reconcile without overwrite')
            return path
        _write_immutable(path,value)
        return path
    if current_bindings is not None:
        raise PermissionError('Current release bindings require explicit package')
    path = root.resolve() / V3 / "release_gate.json"
    path.write_text(json.dumps(build_release_gate(root), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def main(argv=None) -> int:
    import argparse
    parser=argparse.ArgumentParser(description='Existing release gate; exact current audio bindings are optional and explicit')
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--package-relative',type=Path)
    parser.add_argument('--current-bindings',type=Path)
    parser.add_argument('--expected-bindings-hash')
    parser.add_argument('--stage-canary',action='store_true')
    args=parser.parse_args(argv)
    if args.package_relative is None:
        if args.current_bindings or args.expected_bindings_hash or args.stage_canary:
            raise PermissionError('Current bindings/canary require explicit package')
        print(materialize(args.root));return 0
    if args.current_bindings is None or args.expected_bindings_hash is None:
        raise PermissionError('Current CLI requires an externally anchored binding file')
    root=args.root.resolve();path=args.current_bindings
    path=(root/path).resolve() if not path.is_absolute() else path.resolve()
    if not path.is_relative_to(root):raise PermissionError('Release bindings escaped root')
    raw=path.read_bytes()
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=args.expected_bindings_hash:
        raise PermissionError('CLI binding file differs from external anchor')
    bindings=json.loads(raw.decode('utf-8-sig'))
    if args.stage_canary:
        receipt=stage_audio_static_canary(root,package_relative=args.package_relative,current_bindings=bindings)
        if path.read_bytes()!=raw:raise PermissionError('CLI bindings changed during canary observation')
        print(receipt);return 0
    result=materialize(root,package_relative=args.package_relative,current_bindings=bindings)
    if path.read_bytes()!=raw:raise PermissionError('CLI bindings changed during release observation')
    print(result)
    return 0 if _read(result)['publication_pipeline_permitted'] else 2


if __name__ == "__main__":
    raise SystemExit(main())
