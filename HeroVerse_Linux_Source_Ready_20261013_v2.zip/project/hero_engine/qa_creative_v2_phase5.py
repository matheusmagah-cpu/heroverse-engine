from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


PACKAGE = Path("output/production/phase5/pilot-001")
V2 = PACKAGE / "creative-v2"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _asset_id(origin: str) -> str:
    match = re.search(r"asset-(?:commons|owned)-[a-z0-9-]+", origin)
    if not match:
        raise ValueError(f"asset id missing from origin: {origin}")
    return match.group(0)


def _word_count(text: str) -> int:
    return len(re.findall(r"\b[\w'’–-]+\b", text))


def _asset_runtime(plan: dict[str, Any]) -> dict[str, Any]:
    total_ms = int(plan["takes"][-1]["end_ms"])
    runtime: dict[str, int] = defaultdict(int)
    take_ids: dict[str, list[str]] = defaultdict(list)
    for take in plan["takes"]:
        asset_id = _asset_id(str(take["asset_origin"]))
        duration = int(take["end_ms"]) - int(take["start_ms"])
        runtime[asset_id] += duration
        take_ids[asset_id].append(str(take["take_id"]))
    by_asset = {
        asset_id: {
            "runtime_ms": duration,
            "share": round(duration / total_ms, 6),
            "take_ids": take_ids[asset_id],
        }
        for asset_id, duration in sorted(runtime.items())
    }
    third_party = {asset_id: value for asset_id, value in by_asset.items() if asset_id.startswith("asset-commons-")}
    maximum_id = max(third_party, key=lambda item: third_party[item]["share"]) if third_party else None
    return {
        "total_ms": total_ms,
        "unique_asset_count": len(by_asset),
        "maximum_third_party_share": third_party[maximum_id]["share"] if maximum_id else 0.0,
        "maximum_third_party_asset_id": maximum_id,
        "by_asset": by_asset,
    }


def _concrete_coverage(plan: dict[str, Any]) -> dict[str, Any]:
    rules = [
        (("apologize", "apology"), "asset-owned-apology-action-v2"),
        (("make the call", "begin the work", "work decision", "application"), "asset-commons-4ada8d76c56bb371fa"),
        (("skill", "precise question"), "asset-owned-skill-question-v1"),
    ]
    items: list[dict[str, Any]] = []
    for take in plan["takes"]:
        text = str(take["information"]).lower()
        for terms, expected in rules:
            if any(term in text for term in terms):
                observed = _asset_id(str(take["asset_origin"]))
                items.append({"take_id": take["take_id"], "expected_asset_id": expected, "observed_asset_id": observed, "passed": observed == expected})
                break
    passed = sum(1 for item in items if item["passed"])
    return {"matched": passed, "total": len(items), "ratio": round(passed / len(items), 6) if items else 0.0, "items": items}


def _pattern_interrupt_gap(plan: dict[str, Any], treatment: dict[str, Any]) -> int:
    take_by_id = {item["take_id"]: item for item in plan["takes"]}
    points = [0]
    points.extend(int(take_by_id[item["take_id"]]["start_ms"]) for item in treatment["takes"] if item["pattern_interrupt"])
    points.append(int(plan["takes"][-1]["end_ms"]))
    ordered = sorted(set(points))
    return max(right - left for left, right in zip(ordered, ordered[1:]))


def _baseline(root: Path) -> dict[str, Any]:
    base = root / PACKAGE / "baseline-v1"
    plan = _read(base / "take_plan.json")
    script = _read(base / "narrative_script.json")
    render = _read(base / "render_manifest.json")
    runtime = _asset_runtime(plan)
    return {
        "revision": "baseline-v1",
        "duration_ms": render["output"]["duration_ms"],
        "word_count": _word_count(script["full_text"]),
        "take_count": len(plan["takes"]),
        "unique_asset_count": runtime["unique_asset_count"],
        "maximum_third_party_share": runtime["maximum_third_party_share"],
    }


def run_creative_v2_metrics(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    plan = _read(root / V2 / "take_plan.json")
    treatment = _read(root / V2 / "creative_treatment_plan.json")
    script = _read(root / V2 / "narrative_script.json")
    render = _read(root / V2 / "render_manifest.json")
    package = _read(root / V2 / "thumbnail" / "package_manifest.json")
    manifest = _read(root / PACKAGE / "asset_manifest.json")
    runtime = _asset_runtime(plan)
    treatment_by_id = {item["take_id"]: item for item in treatment["takes"]}
    hook_events = sum(treatment_by_id[f"take-{index:03d}"]["visual_event_count"] for index in (1, 2, 3))
    body_8_30_events = sum(
        treatment_by_id[take["take_id"]]["visual_event_count"]
        for take in plan["takes"] if int(take["start_ms"]) < 30_000 and int(take["end_ms"]) > 8_000
    )
    max_body_take = max(int(item["end_ms"]) - int(item["start_ms"]) for item in plan["takes"][3:])
    max_interrupt_gap = _pattern_interrupt_gap(plan, treatment)
    concrete = _concrete_coverage(plan)
    states = [item["framework_state"] for item in treatment["takes"]]
    required_states = {"INTRODUCED", "TRUTH", "RESPONSIBILITY", "TODAY", "COMPLETE"}
    used_ids = set(runtime["by_asset"])
    asset_by_id = {item["asset_id"]: item for item in manifest["assets"]}
    synthetic_used = {item for item in used_ids if item.startswith("asset-owned-")}
    disclosure_pass = bool(package["synthetic_content_disclosure"]) and all(
        "YouTube synthetic-content disclosure required" in asset_by_id[item].get("restrictions", [])
        for item in synthetic_used
    )
    ordered_assets = [_asset_id(str(take["asset_origin"])) for take in plan["takes"]]
    unexpected_adjacent_repeats = [
        {"take_id": plan["takes"][index]["take_id"], "asset_id": ordered_assets[index]}
        for index in range(3, len(ordered_assets))
        if ordered_assets[index] == ordered_assets[index - 1]
    ]
    checks = [
        ("hook_visual_events_0_8", hook_events >= 4, 4, hook_events),
        ("visual_events_8_30", body_8_30_events >= 5, 5, body_8_30_events),
        ("maximum_body_take_ms", max_body_take <= 7000, 7000, max_body_take),
        ("maximum_pattern_interrupt_gap_ms", max_interrupt_gap <= 25000, 25000, max_interrupt_gap),
        ("maximum_third_party_asset_runtime_share", runtime["maximum_third_party_share"] <= 0.2, 0.2, runtime["maximum_third_party_share"]),
        ("concrete_claim_visual_coverage", concrete["ratio"] == 1.0, 1.0, concrete),
        ("framework_state_completion", required_states.issubset(set(states)), sorted(required_states), sorted(set(states))),
        ("synthetic_content_disclosure", disclosure_pass, True, disclosure_pass),
        ("render_treatment_traceability", render.get("creative_treatment_plan_id") == treatment["treatment_plan_id"] and render.get("creative_treatment_version") == treatment["version"], treatment["version"], render.get("creative_treatment_version")),
        ("asset_visual_variety", runtime["unique_asset_count"] >= 10, 10, runtime["unique_asset_count"]),
        ("no_adjacent_asset_repeat_outside_hook", not unexpected_adjacent_repeats, [], unexpected_adjacent_repeats),
    ]
    evidence = ["creative-v2/take_plan.json", "creative-v2/creative_treatment_plan.json", "creative-v2/render_manifest.json"]
    check_records = [
        {"check": name, "status": "PASS" if passed else "FAIL", "threshold": threshold, "observed": observed, "evidence_refs": evidence}
        for name, passed, threshold, observed in checks
    ]
    base = _baseline(root)
    current = {
        "revision": "creative-v2.1",
        "duration_ms": render["output"]["duration_ms"],
        "word_count": _word_count(script["full_text"]),
        "take_count": len(plan["takes"]),
        "unique_asset_count": runtime["unique_asset_count"],
        "maximum_third_party_share": runtime["maximum_third_party_share"],
        "specialized_treatment_count": sum(1 for item in treatment["takes"] if item["treatment"] not in {"CINEMATIC_BODY", "ACTION_EVIDENCE"}),
    }
    value = {
        "schema_version": "1.0.0",
        "revision": "creative-v2.1",
        "video_id": plan["video_id"],
        "checks": check_records,
        "asset_runtime": runtime,
        "comparison": {"baseline": base, "current": current, "deltas": {"duration_ms": current["duration_ms"] - base["duration_ms"], "word_count": current["word_count"] - base["word_count"], "take_count": current["take_count"] - base["take_count"], "unique_asset_count": current["unique_asset_count"] - base["unique_asset_count"], "maximum_third_party_share": round(current["maximum_third_party_share"] - base["maximum_third_party_share"], 6)}},
        "automatic_status": "PASS" if all(item["status"] == "PASS" for item in check_records) else "FAIL",
        "human_review_required": True,
        "publication_eligible": False,
        "created_at": created_at or datetime.now(timezone.utc).isoformat(),
    }
    Draft202012Validator(_read(root / "schemas" / "creative_revision_metrics.schema.json")).validate(value)
    _write(root / V2 / "qa" / "creative_revision_metrics.json", value)
    _write(root / V2 / "qa" / "v1_v2_1_comparison.json", value["comparison"])
    return value
