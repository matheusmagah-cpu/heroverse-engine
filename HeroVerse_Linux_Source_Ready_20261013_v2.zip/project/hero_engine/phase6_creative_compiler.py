from __future__ import annotations

import hashlib
import json
import math
import re
from copy import deepcopy
from pathlib import Path
from typing import Any


COMPILER_VERSION = "phase6-adaptive-creative-compiler-v3"
COMPILER_IDENTITY_VERSION = "phase6-creative-compiler-identity-v1"
SCORE_WEIGHTS = {
    "mechanism_alignment": 0.20,
    "hook_contract": 0.18,
    "visual_provability": 0.16,
    "novelty": 0.10,
    "candidate_distinctness": 0.10,
    "source_originality": 0.10,
    "evidence_depth": 0.06,
    "policy_safety": 0.05,
    "treatment_integrity": 0.05,
}
EVIDENCE_DEPTH = {"METADATA_ONLY": 0.20, "OPENING_ONLY": 0.55, "FULL": 1.0}
STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "before", "but", "by", "do",
    "for", "from", "has", "have", "how", "if", "in", "is", "it", "of", "on",
    "or", "that", "the", "this", "to", "what", "when", "with", "you", "your",
}
REFERENCE_BOILERPLATE = {"christian", "motivation", "watch", "video", "official", "today"}
FORBIDDEN = re.compile(
    r"\b(guaranteed|miracle money|god told me|will happen today|instant breakthrough|"
    r"secret prophecy|soulmate|millionaire|trillion|urgent warning)\b",
    re.I,
)
OPENING_FORBIDDEN = re.compile(r"\b(welcome|subscribe|hello everyone|in this video)\b", re.I)

# This is a deliberately conservative, deterministic planning model for the
# pinned am_onyx voice.  It is not presented as measured audio.  Its purpose is
# to reject obviously impossible copy before a concept can win and before the
# real, model-bound voice preflight runs.  The latter remains authoritative.
VOICE_TIMING_PROFILE_VERSION = "am-onyx-kokoro-planning-v2"
VOICE_TIMING_EXECUTION_CONTRACT_VERSION = "phase6-pinned-voice-slot-v2"
VOICE_ID = "am_onyx"
VOICE_SPEED_BY_TAKE_INDEX = (1.20, 1.12, 1.06)
HOOK_SLOT_MS = (1_000, 2_000, 5_000)
VOICE_DURATION_GRID_MS = 100
VOICE_BODY_HEADROOM_MINIMUM_MS = 400
VOICE_BODY_HEADROOM_RATIO = 0.10


def planned_voice_speed(take_index: int) -> float:
    if take_index < 0:
        raise ValueError("take index cannot be negative")
    return VOICE_SPEED_BY_TAKE_INDEX[min(take_index, len(VOICE_SPEED_BY_TAKE_INDEX) - 1)]


def estimate_spoken_duration_ms(text: str, *, speed: float) -> int:
    """Return a conservative planning duration, rounded to a 100 ms frame grid.

    Letter, boundary and punctuation costs are intentionally more cautious than
    the former words-per-slot rule.  A fixed 450 ms envelope covers onset,
    release and the planning safety margin.  Exact Kokoro synthesis still has
    to prove the slot before a media job may consume an attempt.
    """

    clean = str(text or "").strip()
    if not clean:
        raise ValueError("spoken text cannot be empty")
    if speed < 0.8 or speed > 1.25:
        raise ValueError("voice speed must remain inside the approved 0.8-1.25 range")
    letters = len(re.findall(r"[A-Za-z]", clean))
    digits = len(re.findall(r"\d", clean))
    words = len(re.findall(r"[A-Za-z0-9']+", clean))
    commas = len(re.findall(r"[,;:]", clean))
    sentence_stops = len(re.findall(r"[.!?]", clean))
    articulation_ms = (
        letters * 70
        + digits * 90
        + max(0, words - 1) * 35
        + commas * 140
        + sentence_stops * 220
    )
    return int(
        math.ceil(
            (articulation_ms / speed + 450) / VOICE_DURATION_GRID_MS,
        ) * VOICE_DURATION_GRID_MS
    )


def required_body_voice_headroom_ms(estimated_duration_ms: int) -> int:
    """Return the planning-only safety envelope for newly written body copy.

    The deterministic estimator is intentionally not treated as measured audio.
    Its output therefore needs a material, grid-aligned envelope before exact
    pinned-model synthesis can decide whether a take is executable.
    """

    estimate = int(estimated_duration_ms)
    if estimate <= 0:
        raise ValueError("estimated voice duration must be positive")
    unrounded = max(
        VOICE_BODY_HEADROOM_MINIMUM_MS,
        estimate * VOICE_BODY_HEADROOM_RATIO,
    )
    return int(
        math.ceil(unrounded / VOICE_DURATION_GRID_MS) * VOICE_DURATION_GRID_MS
    )


def validate_planned_voice_slots(takes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Fail closed when the deterministic blueprint cannot carry its narration."""

    evidence: list[dict[str, Any]] = []
    for index, take in enumerate(takes):
        take_id = str(take.get("take_id") or "")
        slot_ms = int(take.get("end_ms") or 0) - int(take.get("start_ms") or 0)
        speed = planned_voice_speed(index)
        estimate_ms = estimate_spoken_duration_ms(str(take.get("narration") or ""), speed=speed)
        is_body = index >= len(HOOK_SLOT_MS)
        required_headroom_ms = (
            required_body_voice_headroom_ms(estimate_ms) if is_body else 0
        )
        observed_headroom_ms = slot_ms - estimate_ms
        fits = slot_ms > 0 and observed_headroom_ms >= required_headroom_ms
        evidence.append({
            "take_id": take_id,
            "speed": speed,
            "slot_ms": slot_ms,
            "estimated_duration_ms": estimate_ms,
            "estimated_headroom_ms": observed_headroom_ms,
            "required_headroom_ms": required_headroom_ms,
            "observed_headroom_ms": observed_headroom_ms,
            "slot_class": "BODY" if is_body else "HOOK",
            "evidence_class": "DETERMINISTIC_PLANNING_ESTIMATE_NOT_MEASURED_AUDIO",
            "fits": fits,
            "profile_version": VOICE_TIMING_PROFILE_VERSION,
        })
        if not fits:
            raise ValueError(
                f"planned voice does not fit take slot: {take_id}:"
                f"estimate={estimate_ms}:slot={slot_ms}:"
                f"observed_headroom={observed_headroom_ms}:"
                f"required_headroom={required_headroom_ms}:"
                f"profile={VOICE_TIMING_PROFILE_VERSION}"
            )
    return evidence


def _hook(window: str, function: str, narration: str, visual: str, rules: list[str]) -> dict[str, Any]:
    return {
        "window": window,
        "function": function,
        "narration": narration,
        "visual_proof": visual,
        "archetype_rule_refs": rules,
    }


CONCEPT_BANK: dict[str, list[dict[str, Any]]] = {
    "spiritual_warfare": [
        {
            "concept_id": "sw-name-test-choose",
            "narrative_lens": "Expose the false interpretation before it becomes behavior.",
            "thesis": "Spiritual pressure gains behavioral power when an untested interpretation becomes identity; naming, testing and choosing restores a bounded faithful response.",
            "package": {
                "topic": "the moment pressure tries to write the meaning of an event",
                "angle": "name the pressure, test the story it tells, then choose a faithful response",
                "promise": "a three-move method that separates a real event from fear's verdict",
                "titles": [
                    "BEFORE PANIC CHOOSES FOR YOU | Christian Motivation",
                    "WHEN PRESSURE TRIES TO CONTROL YOU | Christian Motivation",
                    "NAME THE LIE BEFORE YOU OBEY IT | Christian Motivation",
                ],
                "thumbnail": ["DON'T OBEY PANIC", "TEST THE STORY", "NAME THE LIE"],
                "thumbnail_concept": "A steady figure beside two visibly separated layers—event and verdict—with one amber decision mark on deep navy.",
                "combined": "The viewer learns to interrupt pressure before fear's interpretation becomes identity and action.",
                "payoff": "Pressure can describe the moment; it cannot name you or choose your next faithful response.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Pause.", "An interrupted forward motion makes the pause physical, with no greeting or logo.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Panic commands.", "A second source shows a hand stopping immediately before an impulsive action.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Name the pressure, test its story, then choose the faithful move.", "Three distinct information states label pressure, interpretation and bounded response.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes separate event, fearful meaning and responsible choice.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["PAUSE BEFORE PANIC", None, "NAME / TEST / CHOOSE"],
            "required_roles": ["hook_threshold", "tension", "decision_cards", "truth_test_infographic", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "sw-thought-on-trial",
            "narrative_lens": "Treat the fearful thought as a claim that must survive evidence.",
            "thesis": "A loud thought is not a verdict; testing its truth, fruit and consequence prevents fear from commanding the next decision.",
            "package": {
                "topic": "how to test a fearful thought before obeying it",
                "angle": "put the thought on trial instead of treating emotional volume as truth",
                "promise": "three questions that expose whether a thought deserves authority",
                "titles": [
                    "PUT THAT FEARFUL THOUGHT ON TRIAL | Christian Motivation",
                    "LOUD DOES NOT MEAN TRUE | Christian Motivation",
                    "TEST THE THOUGHT BEFORE YOU OBEY IT | Christian Motivation",
                ],
                "thumbnail": ["TEST THE THOUGHT", "LOUD ≠ TRUE", "WHERE'S THE PROOF?"],
                "thumbnail_concept": "A handwritten fearful claim under a narrow beam of light, with three evidence marks and no courtroom cliché.",
                "combined": "The viewer learns that emotional force does not establish truth and receives a repeatable test.",
                "payoff": "The thought may remain loud after the test, but volume no longer grants it authority.",
            },
            "hooks": [
                _hook("0_1S", "command", "Test.", "A written claim lands in frame and is immediately marked for examination.", ["H1", "I2"]),
                _hook("1_3S", "contradiction", "Volume isn't truth.", "A waveform peaks while a separate truth marker stays fixed.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Question the evidence before fear turns a feeling into your verdict.", "Evidence, consequence and response appear as separate functional beats.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five proof-bearing changes move from thought to test to response.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["TEST THE THOUGHT", None, "LOUD IS NOT TRUE"],
            "required_roles": ["hook_threshold", "tension", "truth_test_infographic", "decision_cards", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "sw-event-versus-verdict",
            "narrative_lens": "Separate what happened from the total future fear predicts.",
            "thesis": "Fear turns one real event into a total verdict; separating fact from forecast protects identity and reveals the next responsible action.",
            "package": {
                "topic": "the difference between a painful event and fear's verdict",
                "angle": "the event may be true while the identity sentence attached to it is not",
                "promise": "a fact-versus-forecast test that produces one responsible next action",
                "titles": [
                    "THE EVENT IS NOT THE VERDICT | Christian Motivation",
                    "FEAR CANNOT PREDICT YOUR WHOLE FUTURE | Christian Motivation",
                    "SEPARATE THE FACT FROM THE FEAR | Christian Motivation",
                ],
                "thumbnail": ["NOT THE VERDICT", "FACT / FEAR", "FEAR CAN'T DECIDE"],
                "thumbnail_concept": "One real closed door beside a separate translucent forecast label that visibly breaks apart.",
                "combined": "The viewer separates the present fact from fear's unsupported future and chooses a defensible response.",
                "payoff": "The event deserves an honest response, but it does not receive authority to predict your identity or future.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Wrong.", "A stamped verdict is interrupted before it covers the underlying event.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Fear wrote the ending.", "A second source reveals a future sentence extending beyond the known fact.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Separate the event from fear's forecast. Then choose your response.", "A two-column fact/forecast split resolves into one bounded action.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes expose how one event becomes an unsupported identity forecast.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["NOT THE VERDICT", None, "FACT / FEAR / RESPONSE"],
            "required_roles": ["hook_threshold", "tension", "truth_test_infographic", "decision_cards", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "sw-alarm-not-command",
            "narrative_lens": "Distinguish the body's alarm from the authority to choose a response.",
            "thesis": "Pressure can trigger a real alarm without earning command of the next decision; naming sensation, interpretation and responsibility restores choice.",
            "package": {
                "topic": "when a real alarm begins acting like an unquestionable command",
                "angle": "honor the warning without surrendering the decision to panic",
                "promise": "a sensation-story-response separation that protects responsible action",
                "titles": [
                    "THE ALARM IS NOT THE COMMAND | Christian Motivation",
                    "WHEN FEAR ORDERS THE NEXT MOVE | Christian Motivation",
                    "FEEL THE WARNING—TEST THE ORDER | Christian Motivation",
                ],
                "thumbnail": ["NOT A COMMAND", "TEST THE ALARM", "WHO CHOOSES NEXT?"],
                "thumbnail_concept": "A visible warning pulse stops at a clear decision boundary before reaching a human hand.",
                "combined": "The viewer respects a real warning while recovering authority over the response.",
                "payoff": "An alarm can ask for attention; it cannot decide what truth, wisdom and faithfulness require next.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Stop.", "A warning pulse reaches a hard decision boundary and stops.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Alarm isn't authority.", "A second source separates physical tension from an impulsive hand movement.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Name the alarm. Test its story. Choose the response.", "Three layers—sensation, story and action—appear without decorative filler.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes show an alarm becoming a story and then a tested response.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["NOT A COMMAND", None, "SENSATION / STORY / RESPONSE"],
            "required_roles": ["hook_threshold", "tension", "truth_test_infographic", "decision_cards", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "sw-urgency-borrowed-authority",
            "narrative_lens": "Expose how urgency borrows authority from speed and emotion.",
            "thesis": "Urgency becomes spiritually dangerous when speed is mistaken for truth; a pause for evidence, consequence and counsel prevents emotion from impersonating authority.",
            "package": {
                "topic": "the false authority created by spiritual urgency",
                "angle": "slow the command long enough to test truth, consequence and counsel",
                "promise": "a pressure test for decisions that feel too urgent to examine",
                "titles": [
                    "URGENCY BORROWED AUTHORITY | Christian Motivation",
                    "DON'T LET SPEED PRETEND TO BE TRUTH | Christian Motivation",
                    "TEST THE DECISION THAT CAN'T WAIT | Christian Motivation",
                ],
                "thumbnail": ["BORROWED AUTHORITY", "SPEED ≠ TRUTH", "TEST THE URGENCY"],
                "thumbnail_concept": "A racing clock loses its glow beside three stable evidence markers in the locked navy and amber system.",
                "combined": "The viewer learns why emotional speed is not evidence and how to test the demanded action.",
                "payoff": "If a decision cannot survive truth, consequence and wise counsel, urgency never made it faithful.",
            },
            "hooks": [
                _hook("0_1S", "rupture", "Slow.", "A fast-moving instruction freezes before execution.", ["H1", "I2"]),
                _hook("1_3S", "contradiction", "Speed isn't truth.", "A moving clock separates from a stable evidence marker in a second source.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Test evidence, consequence, and counsel before urgency chooses.", "Three proof states disarm an untested command.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five evidence-bearing changes reveal how speed acquired false authority.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["SLOW THE COMMAND", None, "EVIDENCE / CONSEQUENCE / COUNSEL"],
            "required_roles": ["hook_threshold", "tension", "decision_cards", "trusted_counsel", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "sw-two-sentences",
            "narrative_lens": "Make interpretation visible by forcing fact and fear into separate sentences.",
            "thesis": "Writing the event and fear's prediction as two different sentences reveals where evidence ends and identity-threatening interpretation begins.",
            "package": {
                "topic": "the two sentences that expose fear's hidden prediction",
                "angle": "write one sentence for the fact and one for the future fear invented",
                "promise": "a sixty-second written test that separates evidence from identity panic",
                "titles": [
                    "WRITE THESE TWO SENTENCES WHEN FEAR HITS | Christian Motivation",
                    "ONE FACT. ONE FEAR. DON'T CONFUSE THEM. | Christian Motivation",
                    "THE 60-SECOND TEST FOR SPIRITUAL PRESSURE | Christian Motivation",
                ],
                "thumbnail": ["TWO SENTENCES", "FACT / FEAR", "WRITE IT DOWN"],
                "thumbnail_concept": "Two handwritten lines remain physically separate: one factual and one visibly marked as an untested forecast.",
                "combined": "The viewer externalizes the hidden interpretation and turns it into a testable claim.",
                "payoff": "Keep the honest fact, cross out the unsupported verdict, and choose the response the evidence can carry.",
            },
            "hooks": [
                _hook("0_1S", "command", "Write.", "Two empty ruled lines snap into view with distinct labels.", ["H1", "I2"]),
                _hook("1_3S", "contrast", "One fact. One fear.", "A second source shows the lines separating rather than merging.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Keep what happened; test the future fear wrote around it.", "The fact stays fixed while the forecast receives evidence marks.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes turn a hidden interpretation into an inspectable written claim.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["TWO SENTENCES", None, "KEEP THE FACT / TEST THE FEAR"],
            "required_roles": ["hook_threshold", "truth_test_infographic", "decision_cards", "safe_boundaries", "renewal"],
        },
    ],
    "prayer_obedience": [
        {
            "concept_id": "po-tested-next-step",
            "narrative_lens": "Move from prayer to one tested action without claiming certainty.",
            "thesis": "Prayer and discernment become accountable when one step passes truth, responsibility and today tests.",
            "package": {
                "topic": "what must happen after prayer",
                "angle": "prayer prepares one truthful, responsible and bounded response",
                "promise": "a three-test decision method for the next twenty-four hours",
                "titles": ["AFTER YOU PRAY, TEST THIS STEP | Christian Motivation", "THE NEXT STEP AFTER AMEN | Christian Motivation", "PRAY. TEST. MOVE. | Christian Motivation"],
                "thumbnail": ["TEST THE STEP", "AFTER AMEN", "MOVE WITH TRUTH"],
                "thumbnail_concept": "Three decision cards beside a phone placed face down, using the locked navy/amber identity.",
                "combined": "The viewer tests one action by truth, responsibility and today without treating impulse as revelation.",
                "payoff": "Complete one truthful and responsible action inside wise boundaries, then record what it teaches.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Wait.", "A stopped hand makes delay visible without a greeting.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Fear calls delay wisdom.", "A second source contrasts stillness with a prepared next step.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Test one step: true, responsible, and possible today.", "Three separate cards make the test immediately usable.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes expose the cost of postponing a known responsibility.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["STILL WAITING?", None, "TRUE / RESPONSIBLE / TODAY"],
            "required_roles": ["hook_threshold", "phone_down", "decision_cards", "trusted_counsel", "renewal"],
        },
        {
            "concept_id": "po-decision-remains",
            "narrative_lens": "Make the unanswered decision—not a mystical prediction—the open loop.",
            "thesis": "Prayer does not remove responsibility; it can prepare the character required to make a bounded decision.",
            "package": {
                "topic": "the decision that remains after prayer",
                "angle": "clarity can be enough for one testable action without revealing the whole outcome",
                "promise": "a safe way to act when complete certainty does not arrive",
                "titles": ["THE DECISION STILL REMAINS | Christian Motivation", "WHEN PRAYER DOESN'T GIVE THE WHOLE MAP | Christian Motivation", "ENOUGH CLARITY FOR ONE STEP | Christian Motivation"],
                "thumbnail": ["THE DECISION REMAINS", "ENOUGH FOR ONE STEP", "DON'T HIDE IN WAITING"],
                "thumbnail_concept": "A partial map ending at one illuminated step, with no promised destination.",
                "combined": "The viewer learns how sufficient clarity differs from a guarantee and acts within a boundary.",
                "payoff": "You do not need the whole map to complete the next truthful responsibility.",
            },
            "hooks": [
                _hook("0_1S", "rupture", "Amen.", "A visible end mark becomes the start of a decision path.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "The decision remains.", "A different source isolates the unresolved action.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "You need enough truth for one step, not a guarantee.", "Known fact, owned duty and bounded action appear in sequence.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five proof-bearing events contrast sufficient clarity with outcome control.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["AMEN IS A TURN", None, "ENOUGH FOR ONE STEP"],
            "required_roles": ["hook_threshold", "perspective", "decision_cards", "trusted_counsel", "renewal"],
        },
        {
            "concept_id": "po-response-next",
            "narrative_lens": "Frame the viewer's response as the next measurable part of prayer.",
            "thesis": "A prayer-shaped response owns truth, consequence and action without trying to control the outcome.",
            "package": {
                "topic": "the response that comes after amen",
                "angle": "a faithful response is measurable even when the external result is not controllable",
                "promise": "turn one known responsibility into a safe action today",
                "titles": ["YOUR RESPONSE COMES NEXT | Christian Motivation", "DON'T STOP AT AMEN | Christian Motivation", "MAKE THE PRAYER VISIBLE | Christian Motivation"],
                "thumbnail": ["YOUR RESPONSE", "DON'T STOP", "MAKE IT VISIBLE"],
                "thumbnail_concept": "A threshold crossed by one concrete action while the outcome remains outside frame.",
                "combined": "The viewer makes prayer visible through one honest response without claiming control of the result.",
                "payoff": "Measure the next step by faithfulness, not by whether it forces the outcome you wanted.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Next.", "A finish line opens into one actionable threshold.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Your response is next.", "A second source places the responsibility with the viewer.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Make prayer visible through one honest action you can finish today.", "One bounded action becomes visible while the uncontrolled outcome remains off-screen.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic events distinguish responsible action from outcome control.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["AMEN ISN'T DONE", None, "ONE HONEST ACTION"],
            "required_roles": ["hook_threshold", "work_step", "decision_cards", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "po-name-one-duty",
            "narrative_lens": "Reduce an abstract prayer request to one responsibility the viewer can actually own.",
            "thesis": "The next faithful step becomes clearer when the viewer names one duty that is true, personally owned and possible today.",
            "package": {
                "topic": "the one responsibility already visible after prayer",
                "angle": "name the duty before asking for certainty about the whole outcome",
                "promise": "a three-boundary test that turns one responsibility into a finishable action",
                "titles": ["NAME ONE DUTY AFTER YOU PRAY | Christian Motivation", "WHAT IS ALREADY YOURS TO DO? | Christian Motivation", "ONE RESPONSIBILITY. ONE STEP. | Christian Motivation"],
                "thumbnail": ["NAME ONE DUTY", "YOURS TO DO", "ONE RESPONSIBILITY"],
                "thumbnail_concept": "One handwritten responsibility remains illuminated while unrelated outcomes stay outside the frame.",
                "combined": "The viewer stops seeking control of every result and identifies one truthful responsibility.",
                "payoff": "You cannot own the outcome, but you can finish the responsibility that truth has already placed in your hands.",
            },
            "hooks": [
                _hook("0_1S", "command", "Name.", "One responsibility is isolated from a field of uncontrolled outcomes.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Prayer didn't erase it.", "A second source shows the unfinished responsibility still present after amen.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Test it: true, yours, and possible today.", "Three boundary cards convert duty into a finishable action.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic changes separate owned duty from uncontrolled result.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["NAME ONE DUTY", None, "TRUE / YOURS / TODAY"],
            "required_roles": ["hook_threshold", "responsibility_map_infographic", "decision_cards", "work_step", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "po-certainty-trap",
            "narrative_lens": "Reveal when the search for certainty becomes a sophisticated form of avoidance.",
            "thesis": "Wanting certainty can protect wisdom, but demanding complete certainty can also postpone a responsibility that already has enough evidence for one bounded test.",
            "package": {
                "topic": "when waiting for certainty becomes avoidance",
                "angle": "distinguish a missing safeguard from a missing guarantee",
                "promise": "two questions that reveal whether delay protects wisdom or protects fear",
                "titles": ["WHEN CERTAINTY BECOMES THE TRAP | Christian Motivation", "ARE YOU WAITING—or HIDING? | Christian Motivation", "YOU MAY ALREADY HAVE ENOUGH LIGHT | Christian Motivation"],
                "thumbnail": ["THE CERTAINTY TRAP", "WAITING OR HIDING?", "ENOUGH LIGHT"],
                "thumbnail_concept": "A bright loop labeled certainty surrounds one small open path, with no promised destination.",
                "combined": "The viewer tests whether waiting is serving wisdom or avoiding a bounded responsibility.",
                "payoff": "Do not trade wisdom for haste—but do not rename fear as discernment when one safe test is already available.",
            },
            "hooks": [
                _hook("0_1S", "contradiction", "Trap.", "A searchlight circles without revealing the open step beside it.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Waiting protects fear.", "A second source reveals one repeatedly postponed action.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Ask whether you need a safeguard—or a guarantee no one can give.", "Safeguard and guarantee separate into two visible decision paths.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five semantic events distinguish wise delay from avoidance.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["THE CERTAINTY TRAP", None, "SAFEGUARD / GUARANTEE"],
            "required_roles": ["hook_threshold", "contemplation", "truth_test_infographic", "trusted_counsel", "safe_boundaries", "renewal"],
        },
        {
            "concept_id": "po-make-step-measurable",
            "narrative_lens": "Demand an observable completion condition for the next faithful response.",
            "thesis": "A next step becomes accountable when it has a concrete verb, a boundary and a finish condition instead of remaining an inspiring intention.",
            "package": {
                "topic": "how to make the next step after prayer measurable",
                "angle": "replace a vague intention with one verb, one boundary and one finish condition",
                "promise": "a practical construction test for action that can be completed today",
                "titles": ["MAKE YOUR NEXT STEP MEASURABLE | Christian Motivation", "A PRAYER NEEDS A VERB | Christian Motivation", "TURN THE INTENTION INTO AN ACTION | Christian Motivation"],
                "thumbnail": ["GIVE IT A VERB", "MAKE IT MEASURABLE", "FINISH THE STEP"],
                "thumbnail_concept": "A vague intention sharpens into a verb, a boundary and one checked completion box.",
                "combined": "The viewer converts inspiration into an observable, bounded action without promising the outcome.",
                "payoff": "A faithful step is not measured by controlling the result; it is measured by completing the honest action you defined.",
            },
            "hooks": [
                _hook("0_1S", "command", "Act.", "A vague intention condenses into one action word.", ["H1", "I2"]),
                _hook("1_3S", "personal consequence", "Intentions don't finish.", "A second source contrasts an open intention with a checked action.", ["H2", "I1"]),
                _hook("3_8S", "mechanism", "Choose one action, one boundary, and one finish condition for today.", "Three fields lock into a measurable action card.", ["H3", "I3"]),
                _hook("8_30S", "title-aligned proof", "", "Five visual changes turn a vague intention into a completed bounded step.", ["H4", "I3"]),
            ],
            "hook_text_overlays": ["GIVE IT A VERB", None, "ACTION / BOUNDARY / FINISH"],
            "required_roles": ["hook_threshold", "work_step", "decision_cards", "today_timeline_infographic", "safe_boundaries", "renewal"],
        },
    ],
}


BODY_PROFILES = [
    {
        "concept_id": "body-question-test-example-boundary-payoff",
        "narrative_lens": "Move from the viewer's cost into tests, examples, boundary and payoff.",
        "section_order": ["S1", "S2", "S4", "S5", "S6", "S3", "S7", "S8", "S9"],
    },
    {
        "concept_id": "body-mechanism-before-ladder",
        "narrative_lens": "Explain the scriptural mechanism before the three-part decision ladder.",
        "section_order": ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9"],
    },
    {
        "concept_id": "body-action-preview-then-proof",
        "narrative_lens": "Preview concrete action before explaining why the mechanism is safe.",
        "section_order": ["S1", "S6", "S2", "S3", "S4", "S5", "S7", "S8", "S9"],
    },
    {
        "concept_id": "body-diagnostic-before-explanation",
        "narrative_lens": "Move the diagnostic contrast forward, then earn the mechanism and action.",
        "section_order": ["S1", "S3", "S2", "S4", "S5", "S6", "S7", "S8", "S9"],
    },
    {
        "concept_id": "body-example-before-framework",
        "narrative_lens": "Show the concrete example immediately before naming the reusable framework.",
        "section_order": ["S1", "S2", "S5", "S3", "S4", "S6", "S7", "S8", "S9"],
    },
    {
        "concept_id": "body-boundary-before-action",
        "narrative_lens": "Establish the safety boundary immediately before the action ladder.",
        "section_order": ["S1", "S2", "S3", "S6", "S4", "S5", "S7", "S8", "S9"],
    },
]


def _canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def creative_recipe_identity_payload() -> dict[str, Any]:
    """Return every declarative input that can change selected creative copy.

    The source hash below is deliberately conservative and changes for any code
    edit.  This separate canonical payload makes copy/recipe drift explicit and
    inspectable even when a maintainer forgets to advance ``COMPILER_VERSION``.
    """

    return {
        "compiler_version": COMPILER_VERSION,
        "score_weights": deepcopy(SCORE_WEIGHTS),
        "evidence_depth": deepcopy(EVIDENCE_DEPTH),
        "stopwords": sorted(STOPWORDS),
        "reference_boilerplate": sorted(REFERENCE_BOILERPLATE),
        "forbidden_pattern": FORBIDDEN.pattern,
        "forbidden_flags": FORBIDDEN.flags,
        "opening_forbidden_pattern": OPENING_FORBIDDEN.pattern,
        "opening_forbidden_flags": OPENING_FORBIDDEN.flags,
        "concept_bank": deepcopy(CONCEPT_BANK),
        "body_profiles": deepcopy(BODY_PROFILES),
    }


def voice_timing_identity_payload() -> dict[str, Any]:
    """Return the exact planning/execution voice profile bound by an order."""

    return {
        "voice_id": VOICE_ID,
        "planning_profile_version": VOICE_TIMING_PROFILE_VERSION,
        "execution_contract_version": VOICE_TIMING_EXECUTION_CONTRACT_VERSION,
        "speed_by_take_index": list(VOICE_SPEED_BY_TAKE_INDEX),
        "hook_slot_ms": list(HOOK_SLOT_MS),
        "speed_minimum": 0.8,
        "speed_maximum": 1.25,
        "duration_grid_ms": VOICE_DURATION_GRID_MS,
        "body_headroom_minimum_ms": VOICE_BODY_HEADROOM_MINIMUM_MS,
        "body_headroom_ratio": VOICE_BODY_HEADROOM_RATIO,
        "body_headroom_rounding": "CEILING_TO_DURATION_GRID",
        "fixed_envelope_ms": 450,
        "letter_cost_ms": 70,
        "digit_cost_ms": 90,
        "word_boundary_cost_ms": 35,
        "comma_cost_ms": 140,
        "sentence_stop_cost_ms": 220,
    }


def build_creative_compiler_identity(
    *,
    source_bytes: bytes | None = None,
    recipe_payload: dict[str, Any] | None = None,
    voice_profile_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the immutable code/content identity consumed by Phase 6 orders.

    Optional byte/payload arguments exist so the identity contract can be
    regression-tested without editing the running checkout or live outputs.
    Production callers always use the loaded module and its current source.
    """

    code = Path(__file__).read_bytes() if source_bytes is None else source_bytes
    recipe = (
        creative_recipe_identity_payload()
        if recipe_payload is None else deepcopy(recipe_payload)
    )
    voice = (
        voice_timing_identity_payload()
        if voice_profile_payload is None else deepcopy(voice_profile_payload)
    )
    identity = {
        "identity_version": COMPILER_IDENTITY_VERSION,
        "compiler_version": COMPILER_VERSION,
        "source_path": "hero_engine/phase6_creative_compiler.py",
        "code_sha256": f"sha256:{hashlib.sha256(code).hexdigest()}",
        "recipe_content_sha256": _canonical_sha256(recipe),
        "voice_profile_version": str(voice["planning_profile_version"]),
        "voice_profile_content_sha256": _canonical_sha256(voice),
        "voice_execution_contract_version": str(
            voice["execution_contract_version"]
        ),
    }
    identity["identity_sha256"] = _canonical_sha256(identity)
    return identity


def _stable_id(prefix: str, *parts: Any) -> str:
    digest = hashlib.sha256("|".join(str(part) for part in parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _tokens(*values: Any) -> set[str]:
    text = " ".join(str(value) for value in values if value is not None)
    return {
        token for token in re.findall(r"[a-z']+", text.lower())
        if len(token) > 2 and token not in STOPWORDS
    }


def _jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 0.0


def _flatten(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        result: list[str] = []
        for item in value.values():
            result.extend(_flatten(item))
        return result
    if isinstance(value, list):
        result = []
        for item in value:
            result.extend(_flatten(item))
        return result
    return []


def _concept_material(concept: dict[str, Any]) -> str:
    return " ".join(_flatten({
        "lens": concept["narrative_lens"],
        "thesis": concept["thesis"],
        "package": concept["package"],
        "hooks": concept["hooks"][:3],
        "section_order": concept.get("section_order") or [],
    }))


def _sequence_similarity(left: list[str], right: list[str]) -> float:
    """Compare editorial structures, not identical words held by experiment."""

    if not left or not right or set(left) != set(right):
        return 1.0
    left_edges = set(zip(left, left[1:]))
    right_edges = set(zip(right, right[1:]))
    edge_union = left_edges | right_edges
    edge_similarity = len(left_edges & right_edges) / max(1, len(edge_union))
    position_similarity = sum(a == b for a, b in zip(left, right)) / len(left)
    return round(0.65 * edge_similarity + 0.35 * position_similarity, 6)


def _hook_contract(
    concept: dict[str, Any], *, preserve_rendered_voice_timing: bool = False,
) -> tuple[float, dict[str, bool]]:
    hooks = concept["hooks"]
    combined_opening = " ".join(item["narration"] for item in hooks[:3])
    planned_durations = [
        estimate_spoken_duration_ms(item["narration"], speed=planned_voice_speed(index))
        for index, item in enumerate(hooks[:3])
    ]
    checks = {
        "exact_windows": [item["window"] for item in hooks] == ["0_1S", "1_3S", "3_8S", "8_30S"],
        "spoken_slot_fit": preserve_rendered_voice_timing or all(
            duration <= slot for duration, slot in zip(planned_durations, HOOK_SLOT_MS)
        ),
        "distinct_opening_lines": len({item["narration"].lower() for item in hooks[:3]}) == 3,
        "no_greeting_or_logo_copy": OPENING_FORBIDDEN.search(combined_opening) is None,
        "spiritual_or_decision_anchor": bool(_tokens(combined_opening) & {"faith", "fear", "prayer", "amen", "pressure", "truth", "panic", "obedience", "responsible"}),
    }
    return sum(checks.values()) / len(checks), checks


def _materialize_concepts(
    variable: str,
    topic_cluster: str,
    prior_script: dict[str, Any],
    topic_sections: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if variable == "BODY_PROGRESSIVE_DISCLOSURE":
        by_id = {item["section_id"]: item for item in prior_script["sections"]}
        concepts = []
        for profile in BODY_PROFILES:
            concept = deepcopy(CONCEPT_BANK["prayer_obedience"][0])
            concept.update(profile)
            concept["hooks"] = [
                {
                    "window": item["window"], "function": item["function"],
                    "narration": item["narration"], "visual_proof": item["visual_job"],
                    "archetype_rule_refs": ["H1" if index == 0 else "H2" if index == 1 else "H3" if index == 2 else "H4"],
                }
                for index, item in enumerate(prior_script["hook_windows"])
            ]
            concept["required_roles"] = sorted({by_id[item]["semantic_role"] for item in profile["section_order"]})
            concepts.append(concept)
        return concepts
    concepts = deepcopy(CONCEPT_BANK[topic_cluster])
    first_section = topic_sections[0]["text"]
    for concept in concepts:
        concept["hooks"][3]["narration"] = first_section
    return concepts


def select_creative_concept(
    *,
    variable: str,
    order: dict[str, Any],
    candidate: dict[str, Any],
    signal: dict[str, Any],
    channel_model: dict[str, Any],
    asset_manifest: dict[str, Any],
    prior_script: dict[str, Any],
    topic_sections: list[dict[str, Any]],
    created_at: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Select one original treatment from measured, inspectable alternatives.

    This is a deterministic prepublication ranking, never a virality probability.
    It refuses random style choice and cannot relax rights, hook or treatment gates.
    """

    topic_cluster = str(candidate["topic_cluster"])
    if topic_cluster not in CONCEPT_BANK:
        raise PermissionError(f"no validated creative recipe bank for topic cluster {topic_cluster}")
    concepts = _materialize_concepts(variable, topic_cluster, prior_script, topic_sections)
    concept_ids = [str(item["concept_id"]) for item in concepts]
    if len(concepts) < 6 or len(set(concept_ids)) != len(concept_ids):
        raise PermissionError("creative search requires at least six uniquely identified alternatives")
    eligible_roles = {
        str(item["semantic_role"])
        for item in asset_manifest.get("assets", [])
        if item.get("production_eligible") is True
        and item.get("rights_status") in {
            "OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL",
            "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED",
        }
    }
    mechanism_tokens = _tokens(candidate.get("mechanism"))
    prior_tokens = _tokens(prior_script.get("full_text"), prior_script.get("title"))
    concept_material = {str(item["concept_id"]): _concept_material(item) for item in concepts}
    concept_tokens = {concept_id: _tokens(material) for concept_id, material in concept_material.items()}
    source_title_tokens = {
        str(item.get("video_id") or item.get("snapshot_id") or index): _tokens(item.get("title")) - REFERENCE_BOILERPLATE
        for index, item in enumerate(candidate.get("representative_sources") or [])
        if item.get("title")
    }
    assessments: list[dict[str, Any]] = []
    for concept in concepts:
        concept_id = str(concept["concept_id"])
        material = concept_material[concept_id]
        tokens = concept_tokens[concept_id]
        mechanism_alignment = len(mechanism_tokens & tokens) / max(1, len(mechanism_tokens))
        hook_score, hook_checks = _hook_contract(
            concept,
            preserve_rendered_voice_timing=variable == "BODY_PROGRESSIVE_DISCLOSURE",
        )
        required_roles = set(concept["required_roles"])
        visual = len(required_roles & eligible_roles) / max(1, len(required_roles))
        novelty = 1.0 - _jaccard(tokens, prior_tokens)
        alternative_similarities: list[tuple[str, float]] = []
        for other in concepts:
            other_id = str(other["concept_id"])
            if other_id == concept_id:
                continue
            similarity = (
                _sequence_similarity(concept.get("section_order") or [], other.get("section_order") or [])
                if variable == "BODY_PROGRESSIVE_DISCLOSURE"
                else _jaccard(tokens, concept_tokens[other_id])
            )
            alternative_similarities.append((other_id, round(similarity, 6)))
        closest_id, maximum_candidate_similarity = max(alternative_similarities, key=lambda item: item[1])
        candidate_distinctness = 1.0 - maximum_candidate_similarity
        source_similarities: list[tuple[str, float]] = []
        creative_strings = _flatten({
            "lens": concept["narrative_lens"], "thesis": concept["thesis"],
            "package": concept["package"], "hooks": concept["hooks"][:3],
        })
        for source_id, source_tokens in source_title_tokens.items():
            piece_scores = []
            for creative_string in creative_strings:
                piece_tokens = _tokens(creative_string) - REFERENCE_BOILERPLATE
                if not piece_tokens or not source_tokens:
                    continue
                jaccard = _jaccard(piece_tokens, source_tokens)
                source_coverage = len(piece_tokens & source_tokens) / len(source_tokens) if len(source_tokens) >= 4 else 0.0
                piece_scores.append(max(jaccard, source_coverage))
            source_similarities.append((source_id, round(max(piece_scores, default=0.0), 6)))
        if source_similarities:
            closest_source_id, maximum_source_title_overlap = max(source_similarities, key=lambda item: item[1])
        else:
            closest_source_id, maximum_source_title_overlap = "NO_SOURCE_TITLE", 0.0
        source_originality = 1.0 - maximum_source_title_overlap
        evidence_depth = EVIDENCE_DEPTH.get(str(candidate.get("evidence_class")), 0.0)
        policy = 0.0 if FORBIDDEN.search(material) else 1.0
        if variable == "TOPIC_ANGLE":
            integrity = 1.0 if topic_cluster != "prayer_obedience" else 0.0
        elif variable == "FIRST_8_SECONDS_MECHANISM":
            integrity = 1.0
        elif variable == "BODY_PROGRESSIVE_DISCLOSURE":
            ids = [item["section_id"] for item in prior_script["sections"]]
            integrity = 1.0 if sorted(ids) == sorted(concept["section_order"]) else 0.0
        else:
            integrity = 0.0
        components = {
            "mechanism_alignment": round(mechanism_alignment, 6),
            "hook_contract": round(hook_score, 6),
            "visual_provability": round(visual, 6),
            "novelty": round(novelty, 6),
            "candidate_distinctness": round(candidate_distinctness, 6),
            "source_originality": round(source_originality, 6),
            "evidence_depth": round(evidence_depth, 6),
            "policy_safety": round(policy, 6),
            "treatment_integrity": round(integrity, 6),
        }
        score = round(sum(SCORE_WEIGHTS[key] * components[key] for key in SCORE_WEIGHTS), 6)
        critical_checks = {
            "hook_windows_and_timing": hook_score == 1.0,
            "rights_eligible_visual_coverage": visual == 1.0,
            "policy_language": policy == 1.0,
            "single_variable_integrity": integrity == 1.0,
            "mechanism_has_observed_semantic_link": mechanism_alignment >= 0.20,
            "alternative_is_materially_distinct": candidate_distinctness >= 0.20,
            "reference_wording_is_original": source_originality >= 0.50,
        }
        rejection = [name for name, passed in critical_checks.items() if not passed]
        weakest_component = min(components, key=lambda key: (components[key], key))
        challenges = [
            "Can the promise be delivered by the exact script without certainty, prophecy or superiority language?",
            "Can every claimed mechanism be shown by a rights-eligible visual job rather than decorative footage?",
            "Does this route remain distinguishable from both the prior HeroVerse release and the closest competing route?",
        ]
        assessments.append({
            "concept_id": concept_id, "narrative_lens": concept["narrative_lens"],
            "eligible": not rejection, "score_components": components,
            "selection_score": score, "score_coverage": 1.0,
            "critical_checks": critical_checks,
            "red_team": {
                "status": "PASS" if not rejection else "FAIL",
                "closest_candidate_id": closest_id,
                "maximum_candidate_similarity": round(maximum_candidate_similarity, 6),
                "closest_reference_video_id": closest_source_id,
                "maximum_source_title_overlap": round(maximum_source_title_overlap, 6),
                "weakest_component": weakest_component,
                "challenges": challenges,
            },
            "evidence_refs": [
                f"signal:{signal['snapshot_id']}", f"candidate:{candidate['candidate_id']}",
                f"channel-model:{channel_model['model_id']}", "format-pack:fp-broll-cinematic-narration@1.1.0",
                "asset-library:phase5-pilot-001",
            ],
            "risks": ["Prepublication score ranks execution fitness; it does not predict views or virality."],
            "rejection_reasons": rejection,
        })
    assessments.sort(key=lambda item: (-item["selection_score"], item["concept_id"]))
    eligible = [item for item in assessments if item["eligible"]]
    if len(eligible) < 3:
        raise PermissionError("no creative concept set retained at least three alternatives after hook, originality, diversity, visual, policy and treatment-integrity gates")
    winner = eligible[0]
    selected = next(item for item in concepts if item["concept_id"] == winner["concept_id"])
    decision_id = _stable_id(
        "phase6-creative-concept", order["order_id"], signal["snapshot_id"],
        COMPILER_VERSION,
        (order.get("compiler_identity") or {}).get("identity_sha256", "unbound"),
        winner["concept_id"],
    )
    decision = {
        "schema_version": "1.2.0", "decision_id": decision_id,
        "compiler_version": COMPILER_VERSION, "order_id": order["order_id"],
        "compiler_identity": deepcopy(order["compiler_identity"]),
        "channel_id": order["channel_id"], "treatment_variable": variable,
        "signal_snapshot_id": signal["snapshot_id"], "market_candidate_id": candidate["candidate_id"],
        "topic_cluster": topic_cluster, "archetype_id": "A-LONG-DIRECT-SPIRITUAL-STAKES-V1",
        "score_weights": SCORE_WEIGHTS,
        "creative_search": {
            "minimum_candidate_count": 6,
            "candidate_count": len(assessments),
            "eligible_candidate_count": len(eligible),
            "distinct_candidate_ids": len(set(concept_ids)) == len(concept_ids),
            "maximum_pairwise_similarity": round(max(item["red_team"]["maximum_candidate_similarity"] for item in assessments), 6),
            "maximum_source_title_overlap": round(max(item["red_team"]["maximum_source_title_overlap"] for item in assessments), 6),
            "search_axes": ["narrative lens", "hook route", "promise and packaging", "proof structure", "payoff structure"],
            "red_team_status": "PASS",
        },
        "candidate_assessments": assessments,
        "selected_concept": {
            "concept_id": winner["concept_id"], "narrative_lens": winner["narrative_lens"],
            "selection_score": winner["selection_score"],
            "selection_reason": "Highest eligible deterministic score after every critical creative check passed; lexical score is a production-fit ranking, not a performance forecast.",
        },
        "locked_dimensions": list(order["treatment"]["locked_constants"]),
        "changed_dimensions": list(order["treatment"]["change_only"]),
        "claim_boundary": [
            "The market signal controls the problem space, not reference wording or identity.",
            "All narration, sequence, packaging and visual direction are original HeroVerse work.",
            "The selected score measures evidence-linked production fitness only and cannot guarantee views, retention, monetization or YPP approval.",
            "A later owned result may update the compiler only through the versioned learning protocol.",
        ],
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": created_at,
    }
    return decision, selected
