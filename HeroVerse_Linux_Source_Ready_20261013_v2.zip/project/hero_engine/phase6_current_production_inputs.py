"""Forward-only verifier for the active Phase 6 production inputs.

The historical release verifier intentionally replays the compiler identity that
created an immutable receipt.  Current execution needs a different boundary
after legitimate source evolution: verify the three current aliases, every
bound byte, the receipt identity, and live asset residency without pretending
that the old compiler source is still the active implementation.

This module grants no queue, voice, render, quality, or publication authority.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_asset_residency import verify_phase6_asset_residency


VERSION = "phase6-current-production-inputs-v1"
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
PRODUCTION_VIEW = Path(
    "output/production/phase6/video-002/production/production_inputs_receipt.json"
)
LATEST_VIEW = Path(
    "output/operations/phase6/release/latest-production-inputs-receipt.json"
)
IMMUTABLE_RECEIPTS = Path(
    "output/operations/phase6/release/production-input-receipts"
)
WORK_ORDERS = Path("output/operations/phase6/release/work-orders")
PRODUCTION_ROOT = Path("output/production/phase6/video-002/production")
EXPECTED_ARTIFACTS = (
    "creative_direction_decision.json",
    "channel_style_bible.json",
    "creative_treatment_plan.json",
    "asset_allocation.json",
    "take_plan.json",
)
EXPECTED_EVIDENCE_ROLES = (
    "TREATMENT_ORDER",
    "FORMAT_SCOPE",
    "PREPRODUCTION_RECEIPT",
    "PILOT_PLAN",
    "FORMAT_PACK",
    "PIPELINE",
    "ASSET_LIBRARY",
)
SCHEMAS = {
    "creative_direction_decision.json": "creative_direction_decision.schema.json",
    "creative_treatment_plan.json": "phase6_creative_treatment_plan.schema.json",
    "asset_allocation.json": "phase6_asset_allocation.schema.json",
    "take_plan.json": "take_plan.schema.json",
}
FALSE_AUTHORITY = {
    "queue": False,
    "voice": False,
    "render": False,
    "quality": False,
    "publication": False,
}


class CurrentProductionInputsError(PermissionError):
    pass


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _read_json(raw: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise CurrentProductionInputsError(f"{label} is invalid JSON") from exc
    if not isinstance(value, dict):
        raise CurrentProductionInputsError(f"{label} is not an object")
    return value


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read_json((root / "schemas" / schema_name).read_bytes(), schema_name)
    Draft202012Validator(
        schema, format_checker=FormatChecker()
    ).validate(value)


def _file(root: Path, relative: str, label: str) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise CurrentProductionInputsError(f"{label} path is not workspace-relative")
    offered = root / relative
    if offered.is_symlink() or not offered.is_file():
        raise CurrentProductionInputsError(f"{label} file is unavailable")
    resolved = offered.resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise CurrentProductionInputsError(f"{label} path escaped the workspace") from exc
    return resolved


def _binding(root: Path, relative: str, label: str) -> dict[str, Any]:
    path = _file(root, relative, label)
    raw = path.read_bytes()
    return {"path": relative, "sha256": _sha(raw), "size_bytes": len(raw)}


def _verify_bound_file(
    root: Path, binding: dict[str, Any], label: str
) -> tuple[Path, bytes]:
    if not isinstance(binding, dict) or set(binding) != {
        "path",
        "sha256",
        "size_bytes",
    }:
        raise CurrentProductionInputsError(f"{label} binding fields differ")
    path = _file(root, binding["path"], label)
    raw = path.read_bytes()
    if (
        binding["sha256"] != _sha(raw)
        or type(binding["size_bytes"]) is not int
        or binding["size_bytes"] != len(raw)
    ):
        raise CurrentProductionInputsError(f"{label} bound bytes changed")
    return path, raw


def _stable_id(prefix: str, *parts: str) -> str:
    payload = "|".join(parts)
    return (
        prefix
        + "-"
        + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]
    )


def verify_current_production_inputs(
    root: Path,
    *,
    expected_receipt_id: str | None = None,
    recheck_decode: bool = False,
) -> dict[str, Any]:
    """Verify the active receipt without replaying historical compiler source."""

    root = Path(root).resolve(strict=True)
    aliases = (PRODUCTION_VIEW, LATEST_VIEW)
    alias_raw: list[bytes] = []
    for relative in aliases:
        path = _file(root, relative.as_posix(), f"current receipt alias {relative.name}")
        alias_raw.append(path.read_bytes())
    if alias_raw[0] != alias_raw[1]:
        raise CurrentProductionInputsError("current production-input aliases differ")

    receipt = _read_json(alias_raw[0], "current production-input receipt")
    _validate(root, "phase6_production_inputs_receipt.schema.json", receipt)
    receipt_id = receipt.get("receipt_id")
    if expected_receipt_id is not None and receipt_id != expected_receipt_id:
        raise CurrentProductionInputsError("current production-input identity changed")
    if not (
        receipt.get("schema_version") == "1.2.0"
        and receipt.get("status") == "COMPILED"
        and receipt.get("action") == "PREPARE_VIDEO_2_INPUTS"
        and receipt.get("next_action") == "SYNTHESIZE_VIDEO_2_VOICE"
        and receipt.get("channel_id") == CHANNEL_ID
        and receipt.get("publication_authorized") is False
        and receipt.get("technical_cost_brl") == 0
    ):
        raise CurrentProductionInputsError("current production-input contract differs")

    immutable_relative = (
        IMMUTABLE_RECEIPTS / f"{receipt_id}.json"
    ).as_posix()
    immutable = _file(
        root, immutable_relative, "immutable current production-input receipt"
    )
    if immutable.read_bytes() != alias_raw[0]:
        raise CurrentProductionInputsError(
            "current production-input aliases differ from the immutable receipt"
        )

    records = receipt.get("artifacts")
    if not isinstance(records, list):
        raise CurrentProductionInputsError("current production artifacts are absent")
    names = [Path(str(row.get("path") or "")).name for row in records if isinstance(row, dict)]
    expected_paths = [(PRODUCTION_ROOT / name).as_posix() for name in EXPECTED_ARTIFACTS]
    if (
        len(records) != len(EXPECTED_ARTIFACTS)
        or names != list(EXPECTED_ARTIFACTS)
        or [row.get("path") for row in records] != expected_paths
    ):
        raise CurrentProductionInputsError("current production artifact set differs")

    documents: dict[str, dict[str, Any]] = {}
    for row, name in zip(records, EXPECTED_ARTIFACTS, strict=True):
        path, raw = _verify_bound_file(root, row, f"current artifact {name}")
        if path.parent != (root / PRODUCTION_ROOT).resolve():
            raise CurrentProductionInputsError(
                f"current artifact {name} left the production root"
            )
        value = _read_json(raw, f"current artifact {name}")
        schema_name = SCHEMAS.get(name)
        if schema_name is not None:
            _validate(root, schema_name, value)
        documents[name] = value

    take_rows = documents["take_plan.json"].get("takes")
    allocation_rows = documents["asset_allocation.json"].get("takes")
    if not isinstance(take_rows, list) or not isinstance(allocation_rows, list):
        raise CurrentProductionInputsError("current take populations are absent")
    take_ids = [row.get("take_id") for row in take_rows if isinstance(row, dict)]
    allocation_ids = [
        row.get("take_id") for row in allocation_rows if isinstance(row, dict)
    ]
    asset_ids = [
        row.get("asset_id") for row in allocation_rows if isinstance(row, dict)
    ]
    measurements = receipt.get("measurements") or {}
    if not (
        len(take_ids) == len(take_rows) == len(allocation_ids) == len(allocation_rows)
        and take_ids == allocation_ids
        and len(take_ids) == len(set(take_ids)) == measurements.get("take_count")
        and all(isinstance(asset_id, str) and asset_id for asset_id in asset_ids)
        and len(set(asset_ids)) == measurements.get("unique_asset_count")
    ):
        raise CurrentProductionInputsError(
            "current production populations differ from receipt measurements"
        )

    work = receipt.get("work_order")
    work_path, work_raw = _verify_bound_file(
        root, work, "current release work order"
    )
    expected_work_path = (
        root / WORK_ORDERS / f"{receipt.get('work_order_id')}.json"
    ).resolve()
    if work_path != expected_work_path:
        raise CurrentProductionInputsError(
            "current release work order left its immutable directory"
        )
    work_order = _read_json(work_raw, "current release work order")
    _validate(root, "phase6_release_work_order.schema.json", work_order)
    if not (
        work_order.get("schema_version") == "1.3.0"
        and work_order.get("work_order_id") == receipt.get("work_order_id")
        and work_order.get("treatment_order_id")
        == receipt.get("treatment_order_id")
        and work_order.get("preproduction_receipt_id")
        == receipt.get("preproduction_receipt_id")
        and work_order.get("status") == "READY_TO_PREPARE"
        and work_order.get("action") == receipt.get("action")
        and work_order.get("channel_id") == CHANNEL_ID
        and work_order.get("publication_authorized") is False
        and work_order.get("technical_cost_brl") == 0
        and work_order.get("evidence_bindings") == receipt.get("evidence_bindings")
    ):
        raise CurrentProductionInputsError(
            "current release work-order contract differs"
        )

    evidence = receipt.get("evidence_bindings")
    if (
        not isinstance(evidence, list)
        or [row.get("role") for row in evidence if isinstance(row, dict)]
        != list(EXPECTED_EVIDENCE_ROLES)
        or len(evidence) != len(EXPECTED_EVIDENCE_ROLES)
    ):
        raise CurrentProductionInputsError("current evidence binding set differs")
    for row in evidence:
        if not isinstance(row, dict) or set(row) != {
            "role",
            "source_path",
            "immutable_path",
            "sha256",
            "size_bytes",
            "identity",
        }:
            raise CurrentProductionInputsError("current evidence binding shape differs")
        expected = {
            "sha256": row["sha256"],
            "size_bytes": row["size_bytes"],
        }
        for key in ("source_path", "immutable_path"):
            observed = _binding(
                root, row[key], f"{row['role']} {key}"
            )
            if {
                "sha256": observed["sha256"],
                "size_bytes": observed["size_bytes"],
            } != expected:
                raise CurrentProductionInputsError(
                    f"current evidence bytes changed: {row['role']} {key}"
                )

    residency = receipt.get("asset_residency")
    if not isinstance(residency, dict):
        raise CurrentProductionInputsError(
            "current asset-residency binding is absent"
        )
    verified_residency = verify_phase6_asset_residency(
        root,
        receipt_path=residency.get("receipt_path"),
        expected_sha256=residency.get("sha256"),
        expected_audit_id=residency.get("audit_id"),
        required_asset_ids=asset_ids,
        recheck_media=True,
        recheck_decode=recheck_decode,
    )
    for key in (
        "audit_id",
        "receipt_path",
        "sha256",
        "manifest_content_hash",
    ):
        if verified_residency.get(key) != residency.get(key):
            raise CurrentProductionInputsError(
                "current asset-residency identity differs"
            )

    expected_id = _stable_id(
        "phase6-production-inputs",
        str(receipt["work_order_id"]),
        str(work["sha256"]),
        str(residency["sha256"]),
        *[str(row["sha256"]) for row in evidence],
        *[str(row["sha256"]) for row in records],
    )
    if receipt_id != expected_id:
        raise CurrentProductionInputsError(
            "current production-input receipt id differs from its bound hashes"
        )
    return receipt


def current_production_input_contract(root: Path) -> dict[str, Any]:
    """Return a compact, no-authority binding for proofs and diagnostics."""

    root = Path(root).resolve(strict=True)
    receipt = verify_current_production_inputs(root)
    aliases = [
        _binding(root, relative.as_posix(), f"current receipt alias {relative.name}")
        for relative in (PRODUCTION_VIEW, LATEST_VIEW)
    ]
    immutable_relative = (
        IMMUTABLE_RECEIPTS / f"{receipt['receipt_id']}.json"
    ).as_posix()
    return {
        "version": VERSION,
        "receipt_id": receipt["receipt_id"],
        "aliases": aliases,
        "immutable_receipt": _binding(
            root, immutable_relative, "immutable current production-input receipt"
        ),
        "artifact_bindings": list(receipt["artifacts"]),
        "asset_residency": dict(receipt["asset_residency"]),
        "take_count": receipt["measurements"]["take_count"],
        "unique_asset_count": receipt["measurements"]["unique_asset_count"],
        "authority": dict(FALSE_AUTHORITY),
        "technical_cost_brl": 0,
    }
