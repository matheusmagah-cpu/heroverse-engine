from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .oauth_scope_requirements import materialize as materialize_scope
from .oauth_operational_readiness import materialize as materialize_oauth_readiness
from .oauth_refresh_proof import prove_noninteractive_refresh
from .oauth_token_mirror import inspect_authorized_user_token, mirror_authorized_user_token
from .phase5_autonomous_quality import (
    REPORT as AUTONOMOUS_REVIEW_REPORT,
    TRANSITION as AUTONOMOUS_TRANSITION,
    apply_limited_transition as apply_autonomous_limited_transition,
    materialize as materialize_autonomous_quality,
)
from .phase5_human_review import apply_limited_transition, evaluate_file
from .phase5_release_gate import build_release_gate
from .phase5_youtube_publisher import _build_live_service, execute_publication_pipeline
from .phase5_review_console import DEFAULT_PORT as REVIEW_CONSOLE_PORT, serve as serve_review_console
from .zero_cost_guard import evaluate_zero_cost
from .youtube_integration import INTEGRATION_SCOPES
from scripts.build_phase5_integrity import build as build_phase5_integrity


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path("output/runtime/gestor-central")
V3 = Path("output/production/phase5/pilot-001/creative-v3")
OAUTH_REFRESH_INTERVAL_SECONDS = 24 * 60 * 60
OAUTH_REFRESH_RETRY_SECONDS = 6 * 60 * 60
OAUTH_REFRESH_FAILURE_THRESHOLD = 3
INPUTS = [
    V3 / "human-review/review_submission.json",
    V3 / "human-review/review_submission.draft.json",
    AUTONOMOUS_REVIEW_REPORT,
    AUTONOMOUS_TRANSITION,
    V3 / "publication_package.json",
    Path("config/format_packs/fp-broll-cinematic-narration-v1.json"),
    Path("config/visual_style_registry.json"),
    Path("config/zero-cost-policy.json"),
    Path("config/integrations/youtube-heroverse-v1.json"),
    Path("output/integrations/youtube/heroverse/connection-receipt.json"),
    Path("output/integrations/youtube/heroverse/operational-readiness.json"),
    Path("output/integrations/youtube/heroverse/google-auth-platform-observation.json"),
    Path("output/integrations/youtube/heroverse/quota-observation.json"),
    Path("output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json"),
    Path("output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"),
    Path("output/market/vidiq/heroverse/2026-09-03/plugin-observation.json"),
    Path("output/audits/channel/heroverse/channel-readiness-audit.json"),
]
# INPUTS also defines the immutable V1 capture contract. Do not repin or remove
# historical rows. V2 separates mutable observations from approved content and
# configuration; live OAuth/identity/readiness are still checked by their gates.
VOLATILE_INPUTS = frozenset({
    Path("output/integrations/youtube/heroverse/connection-receipt.json"),
    Path("output/integrations/youtube/heroverse/operational-readiness.json"),
    Path("output/integrations/youtube/heroverse/google-auth-platform-observation.json"),
    Path("output/integrations/youtube/heroverse/quota-observation.json"),
    Path("output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json"),
    Path("output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"),
    Path("output/market/vidiq/heroverse/2026-09-03/plugin-observation.json"),
    Path("output/audits/channel/heroverse/channel-readiness-audit.json"),
})
FINGERPRINT_VERSION = "phase5-stable-inputs-v2"
_OAUTH_EFFECT_LOCK = threading.Lock()


class ManagerAlreadyRunning(RuntimeError):
    pass


class ManagerLock:
    def __init__(self, root: Path, *, lease_seconds: int) -> None:
        self.root = root.resolve()
        self.runtime = self.root / RUNTIME
        self.lock_path = self.runtime / "manager.lock"
        self.metadata_path = self.runtime / "manager-lock.json"
        self.lease_seconds = max(30, int(lease_seconds))
        self.handle: Any | None = None
        self.acquired_at: str | None = None
        self.mechanism = "windows_byte_range_lock" if os.name == "nt" else "posix_flock"
        self._metadata_mutex = threading.Lock()
        self._heartbeat_stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._heartbeat_error: BaseException | None = None

    def _lock_handle(self) -> None:
        assert self.handle is not None
        self.handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock_handle(self) -> None:
        assert self.handle is not None
        self.handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)

    def _write_metadata(self, state: str, *, released_at: str | None = None) -> dict[str, Any]:
        with self._metadata_mutex:
            now = datetime.now(timezone.utc)
            value = {
                "schema_version": "1.0.0",
                "lock_id": "gestor-central-heroverse-phase5-singleton-v1",
                "state": state,
                "holder_pid": os.getpid(),
                "holder_started_at": self.acquired_at,
                "heartbeat_at": now.isoformat().replace("+00:00", "Z"),
                "lease_seconds": self.lease_seconds,
                "lease_expires_at": (now + timedelta(seconds=self.lease_seconds)).isoformat().replace("+00:00", "Z"),
                "released_at": released_at,
                "mechanism": self.mechanism,
                "lock_file": self.lock_path.relative_to(self.root).as_posix(),
                "technical_cost_brl": 0,
            }
            schema = _read(self.root / "schemas/central_manager_lock.schema.json")
            Draft202012Validator(schema).validate(value)
            _write(self.metadata_path, value)
        return value

    def _heartbeat_worker(self) -> None:
        interval = max(10.0, min(30.0, self.lease_seconds / 3.0))
        while not self._heartbeat_stop.wait(interval):
            try:
                self.heartbeat()
            except BaseException as exc:
                self._heartbeat_error = exc
                return

    def _start_heartbeat_worker(self) -> None:
        self._heartbeat_stop.clear()
        self._heartbeat_error = None
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_worker,
            name="gestor-central-lock-heartbeat",
            daemon=True,
        )
        self._heartbeat_thread.start()

    def acquire(self) -> "ManagerLock":
        self.runtime.mkdir(parents=True, exist_ok=True)
        self.handle = self.lock_path.open("a+b")
        self.handle.seek(0, os.SEEK_END)
        if self.handle.tell() == 0:
            self.handle.write(b"0")
            self.handle.flush()
        try:
            self._lock_handle()
        except OSError as exc:
            self.handle.close()
            self.handle = None
            raise ManagerAlreadyRunning("another central manager holds the OS lock") from exc
        try:
            self.acquired_at = _now()
            self._write_metadata("HELD")
            self._start_heartbeat_worker()
        except Exception:
            try:
                self._unlock_handle()
            finally:
                self.handle.close()
                self.handle = None
            raise
        return self

    def heartbeat(self) -> dict[str, Any]:
        if self.handle is None or self.acquired_at is None:
            raise RuntimeError("manager lock is not held")
        if self._heartbeat_error is not None and threading.current_thread() is not self._heartbeat_thread:
            error = self._heartbeat_error
            self._heartbeat_error = None
            raise RuntimeError("background manager heartbeat failed") from error
        return self._write_metadata("HELD")

    def release(self) -> None:
        if self.handle is None:
            return
        self._heartbeat_stop.set()
        heartbeat_thread = self._heartbeat_thread
        if heartbeat_thread is not None and heartbeat_thread is not threading.current_thread():
            heartbeat_thread.join(timeout=5)
        self._heartbeat_thread = None
        released_at = _now()
        try:
            self._write_metadata("RELEASED", released_at=released_at)
        finally:
            try:
                self._unlock_handle()
            finally:
                self.handle.close()
                self.handle = None

    def __enter__(self) -> "ManagerLock":
        return self.acquire()

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.release()


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        for attempt in range(8):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(min(0.5, 0.05 * (2 ** attempt)))
    finally:
        if temporary.exists():
            temporary.unlink()


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable owned-observer checkpoint collision: {path.name}")
        return
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(payload)
    os.replace(temporary, path)


def _archive_owned_artifact(root: Path, *, job_id: str, label: str, source: Path) -> tuple[str, str]:
    payload = source.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    target = root / "output/operations/phase6/intelligence/external-read-checkpoints" / job_id / f"{label}-{digest[:24]}.json"
    _write_immutable_bytes(target, payload)
    return target.relative_to(root).as_posix(), "sha256:" + digest


def _read_owned_artifact(
    root: Path,
    *,
    job_id: str,
    label: str,
    reference: Any,
    expected_hash: Any,
    schema_name: str | None = None,
) -> tuple[Path, dict[str, Any]]:
    if not (
        isinstance(reference, str)
        and isinstance(expected_hash, str)
        and expected_hash.startswith("sha256:")
        and len(expected_hash) == 71
    ):
        raise PermissionError(f"checkpointed {label} identity is incomplete")
    path = (root / reference).resolve()
    parent = (root / "output/operations/phase6/intelligence/external-read-checkpoints" / job_id).resolve()
    if path.parent != parent or path.name != f"{label}-{expected_hash.split(':', 1)[1][:24]}.json":
        raise PermissionError(f"checkpointed {label} is outside the exact owned job")
    payload = path.read_bytes()
    if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
        raise PermissionError(f"checkpointed {label} hash mismatch")
    value = json.loads(payload.decode("utf-8-sig"))
    if schema_name:
        Draft202012Validator(_read(root / "schemas" / schema_name)).validate(value)
    return path, value


def _materialize_owned_preflight(
    root: Path,
    *,
    job_id: str,
    current: datetime,
) -> tuple[dict[str, Any], str, str]:
    value = evaluate_zero_cost(
        root,
        operation="phase6_owned_metrics_checkpoint",
        observed_usage=_quota_usage(root),
        created_at=current.isoformat().replace("+00:00", "Z"),
    )
    Draft202012Validator(_read(root / "schemas/zero_cost_guard.schema.json")).validate(value)
    payload = _canonical_bytes(value)
    digest = hashlib.sha256(payload).hexdigest()
    history = root / "output/operations/zero-cost/phase6-owned-metrics-preflights" / job_id / f"preflight-{digest[:24]}.json"
    _write_immutable_bytes(history, payload)
    _write(root / "output/operations/zero-cost/phase6-owned-metrics-preflight.json", value)
    return value, history.relative_to(root).as_posix(), "sha256:" + digest


def _validate_owned_preflight(root: Path, *, job_id: str, checkpoint: dict[str, Any]) -> None:
    reference = checkpoint.get("quota_preflight")
    expected_hash = checkpoint.get("quota_preflight_hash")
    if not (
        isinstance(reference, str)
        and isinstance(expected_hash, str)
        and expected_hash.startswith("sha256:")
        and len(expected_hash) == 71
    ):
        raise PermissionError("owned checkpoint is missing quota-preflight identity")
    path = (root / reference).resolve()
    parent = (root / "output/operations/zero-cost/phase6-owned-metrics-preflights" / job_id).resolve()
    if path.parent != parent or path.name != f"preflight-{expected_hash.split(':', 1)[1][:24]}.json":
        raise PermissionError("owned quota-preflight is outside the exact job")
    payload = path.read_bytes()
    if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
        raise PermissionError("owned quota-preflight hash mismatch")
    value = json.loads(payload.decode("utf-8-sig"))
    Draft202012Validator(_read(root / "schemas/zero_cost_guard.schema.json")).validate(value)
    general = next((item for item in value["resources"] if item["resource_id"] == "youtube-general-units-daily"), None)
    if not (
        value.get("operation") == "phase6_owned_metrics_checkpoint"
        and value.get("execution_permitted") is True
        and value.get("quota_status") == "PASS"
        and value.get("technical_cost_brl") == 0
        and isinstance(general, dict)
        and general.get("quota_reserved") == 2
        and general.get("preventive_floor") == 12
    ):
        raise PermissionError("owned quota-preflight did not authorize the exact collection")


def _workspace_artifact_binding(root: Path, path: Path) -> tuple[str, str]:
    candidate = path.resolve()
    try:
        relative = candidate.relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise PermissionError("observer artifact must remain inside the workspace") from exc
    if not candidate.is_file():
        raise FileNotFoundError(f"observer artifact is missing: {relative}")
    return relative, "sha256:" + hashlib.sha256(candidate.read_bytes()).hexdigest()


def _validate_phase6_publication_receipt(
    root: Path,
    publication_path: Path,
    *,
    expected_hash: str | None = None,
) -> tuple[str, str]:
    """Validate and pin the exact canary receipt before any external setup."""

    expected_path = (root / V3 / "youtube-publication-receipt.json").resolve()
    candidate = publication_path.resolve()
    if candidate != expected_path or candidate.is_symlink() or not candidate.is_file():
        raise PermissionError("Phase 6 publication receipt path or residency diverged")
    payload = candidate.read_bytes()
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    if expected_hash is not None and digest != expected_hash:
        raise PermissionError("Phase 6 publication receipt changed after validation")
    try:
        receipt = json.loads(payload.decode("utf-8-sig"))
        Draft202012Validator(
            _read(root / "schemas/youtube_publication_receipt.schema.json")
        ).validate(receipt)
    except Exception as exc:
        raise PermissionError("Phase 6 publication receipt is not schema-valid") from exc
    if not (
        receipt.get("status") == "COMPLETE_PUBLIC"
        and receipt.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
        and receipt.get("video_id") == "iK_5edYQtx8"
        and receipt.get("privacy_status") == "public"
        and receipt.get("public_visibility_authorized") is True
    ):
        raise PermissionError("Phase 6 publication receipt identity/state diverged")
    return candidate.relative_to(root).as_posix(), digest


def _reporting_registry_intent(
    root: Path,
    *,
    job_id: str,
    observed_at: datetime,
) -> dict[str, Any]:
    registry = root / "output/operations/phase6/reporting/job-registry.json"
    prior_hash = (
        "sha256:" + hashlib.sha256(registry.read_bytes()).hexdigest()
        if registry.is_file()
        else None
    )
    timestamp = observed_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    material = f"{job_id}|{timestamp}|{prior_hash or 'NONE'}"
    return {
        "intent_id": "phase6-reporting-intent-"
        + hashlib.sha256(material.encode("utf-8")).hexdigest()[:24],
        "job_id": job_id,
        "observed_at": timestamp,
        "prior_registry_sha256": prior_hash,
        "registry_path": "output/operations/phase6/reporting/job-registry.json",
    }


def _recover_reporting_registry_from_intent(
    root: Path,
    *,
    job_id: str,
    intent: Any,
) -> tuple[Path, str] | None:
    if not (
        isinstance(intent, dict)
        and intent.get("job_id") == job_id
        and isinstance(intent.get("intent_id"), str)
        and intent.get("registry_path")
        == "output/operations/phase6/reporting/job-registry.json"
        and isinstance(intent.get("observed_at"), str)
    ):
        return None
    registry = (root / intent["registry_path"]).resolve()
    if registry != (root / "output/operations/phase6/reporting/job-registry.json").resolve():
        raise PermissionError("Reporting intent registry path diverged")
    if not registry.is_file() or registry.is_symlink():
        return None
    payload = registry.read_bytes()
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    if digest == intent.get("prior_registry_sha256"):
        return None
    try:
        value = json.loads(payload.decode("utf-8-sig"))
        Draft202012Validator(
            _read(root / "schemas/youtube_reporting_job_registry.schema.json")
        ).validate(value)
    except Exception as exc:
        raise PermissionError("post-intent Reporting registry is malformed") from exc
    if not (
        value.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
        and value.get("observed_at") == intent["observed_at"]
        and value.get("technical_cost_brl") == 0
    ):
        raise PermissionError("post-intent Reporting registry identity diverged")
    return registry, digest.removeprefix("sha256:")


def _validate_orphan_owned_metrics_source(root: Path, *, job_id: str, path: Path) -> dict[str, Any]:
    expected = (
        root
        / "output/operations/phase6/intelligence/external-read-checkpoints"
        / job_id
        / "owned-metrics-source.json"
    ).resolve()
    if path.resolve() != expected or path.is_symlink() or not path.is_file():
        raise PermissionError("orphaned owned-metrics source is outside the exact job journal")
    value = _read(path)
    Draft202012Validator(
        _read(root / "schemas/own_channel_performance_snapshot.schema.json")
    ).validate(value)
    if not (
        value.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
        and value.get("video_id") == "iK_5edYQtx8"
        and value.get("technical_cost_brl") == 0
    ):
        raise PermissionError("orphaned owned-metrics source identity diverged")
    return value


def _restore_owned_metrics_views(root: Path, *, source: Path, value: dict[str, Any]) -> Path:
    payload = _canonical_bytes(value)
    if source.read_bytes() != payload:
        raise PermissionError("job-owned metrics source is not canonical")
    folder = root / "output/operations/phase6/metrics" / str(value["video_id"])
    history = folder / f"{value['snapshot_id']}.json"
    _write_immutable_bytes(history, payload)
    latest = folder / "latest.json"
    temporary = latest.with_name(
        f".{latest.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )
    temporary.write_bytes(payload)
    try:
        os.replace(temporary, latest)
    finally:
        if temporary.exists():
            temporary.unlink()
    return history


def _quota_debit_checkpoint(value: dict[str, Any]) -> dict[str, Any]:
    checkpoint = {
        key: value.get(key)
        for key in (
            "debit_id",
            "idempotency_key",
            "operation_id",
            "job_id",
            "attempt_count",
            "channel_id",
            "units",
            "state",
            "quota_day_start",
            "quota_day_end",
            "requested_effective_before",
            "preventive_floor",
            "effective_before",
            "effective_after",
            "reserved_at",
            "consumed_at",
        )
    }
    checkpoint["ledger_version"] = "phase6-general-quota-ledger-v1.1"
    return checkpoint


def _validate_owned_quota_debit_chain(
    root: Path,
    *,
    job: dict[str, Any],
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    from .phase6_quota import get_general_quota_debit

    checkpoint = job.get("checkpoint") or {}
    debit = checkpoint.get("quota_debit")
    if not (
        checkpoint.get("quota_ledger_version") == "phase6-general-quota-ledger-v1.1"
        and isinstance(debit, dict)
        and debit.get("ledger_version") == "phase6-general-quota-ledger-v1.1"
        and debit.get("state") == "CONSUMED"
        and debit.get("operation_id") == "phase6_owned_metrics_checkpoint"
        and debit.get("job_id") == job.get("job_id")
        and debit.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
        and debit.get("units") == 2
        and debit.get("preventive_floor") == 12
        and isinstance(debit.get("idempotency_key"), str)
        and isinstance(debit.get("debit_id"), str)
        and debit.get("debit_id") in (checkpoint.get("quota_debit_ids") or [])
    ):
        raise PermissionError("owned metrics checkpoint lacks the consumed quota-ledger 1.1 chain")
    stored = get_general_quota_debit(root, idempotency_key=debit["idempotency_key"])
    comparable = {key: stored.get(key) for key in debit if key != "ledger_version"} if stored else None
    if comparable != {key: value for key, value in debit.items() if key != "ledger_version"}:
        raise PermissionError("owned metrics checkpoint quota debit diverged from the ledger")
    captured = _parse_connection_time(str(snapshot.get("captured_at")))
    if not (
        _parse_connection_time(str(debit["quota_day_start"]))
        <= captured
        < _parse_connection_time(str(debit["quota_day_end"]))
    ):
        raise PermissionError("owned metrics snapshot falls outside its quota debit day")
    return stored


def _recoverable_owned_metrics_job(queue: Any, current: datetime) -> dict[str, Any] | None:
    """Return the earliest exact due observer command that is not complete.

    The shared metrics ``latest`` view may already point at D3 after a D1 crash.
    Queue state is authoritative for unfinished work, so it must be consulted
    before that mutable view is allowed to say NOT_DUE.
    """

    candidates: list[tuple[datetime, str, dict[str, Any]]] = []
    for job in queue.snapshot(captured_at=current).get("jobs") or []:
        payload = job.get("payload") or {}
        if not (
            job.get("state") in {"PENDING", "LEASED", "RETRY_WAIT"}
            and job.get("task_type") == "OWNED_METRICS_CHECKPOINT"
            and job.get("operation_id") == "heroverse-phase6-controlled-longform-v1"
            and job.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
            and payload.get("video_id") == "iK_5edYQtx8"
        ):
            continue
        raw_window = payload.get("scheduled_window")
        try:
            scheduled = (
                _parse_connection_time(str(raw_window))
                if raw_window != "INITIAL"
                else _parse_connection_time(str(job["available_at"]))
            )
        except (KeyError, TypeError, ValueError):
            continue
        if scheduled <= current:
            candidates.append((scheduled, str(job.get("created_at") or ""), job))
    return sorted(candidates, key=lambda item: (item[0], item[1], item[2]["job_id"]))[0][2] if candidates else None


def _commit_owned_observer_transaction(
    root: Path,
    *,
    queue: Any,
    claimed: dict[str, Any],
    completion_checkpoint: dict[str, Any],
    experiment_path: Path,
    now: datetime,
) -> tuple[dict[str, Any], dict[str, Any], Exception | None]:
    """Prevalidate a new activation or revalidate an existing active protocol."""

    from .phase6_intelligence import (
        activate_preregistered_protocol,
        validate_preregistered_protocol_activation,
        verify_active_preregistered_protocol,
    )

    root = root.resolve()
    experiment = _read(experiment_path)
    preregistered = experiment.get("status") == "PREREGISTERED"
    experiments = (root / "output/operations/phase6/intelligence/experiments").resolve()
    active_path = experiments / "active.json"
    resolved_experiment = experiment_path.resolve()
    already_active = resolved_experiment == active_path
    if resolved_experiment == experiments / "latest.json":
        raise PermissionError("mutable protocol latest cannot authorize observer completion")

    checkpoint = dict(completion_checkpoint)
    immutable_stage: Path | None = None
    if preregistered and already_active:
        immutable_stage = verify_active_preregistered_protocol(
            root, protocol_path=experiment_path,
        )
        checkpoint.pop("experiment_protocol_stage", None)
        checkpoint.pop("experiment_protocol_stage_hash", None)
        checkpoint.update(
            {
                "experiment_protocol_state": "ALREADY_ACTIVE_VERIFIED",
                "active_protocol": active_path.relative_to(root).as_posix(),
                "active_protocol_hash": _workspace_artifact_binding(root, active_path)[1],
                "active_protocol_immutable_source": immutable_stage.relative_to(root).as_posix(),
                "active_protocol_immutable_source_hash": _workspace_artifact_binding(
                    root, immutable_stage,
                )[1],
            }
        )
    elif preregistered:
        try:
            resolved_experiment.relative_to(experiments)
        except ValueError as exc:
            raise PermissionError("staged protocol escaped the Phase 6 experiment store") from exc
        checkpoint["experiment_protocol_state"] = "ACTIVATION_VALIDATED"

    # Persist and prevalidate every substantive binding while the lease is
    # active.  The immutable active view is still an outbox effect of the queue
    # commit, so a crash can be recovered without exposing an uncommitted active
    # protocol to downstream production.
    prepared = queue.checkpoint(
        claimed["job_id"],
        worker_id=claimed["lease_owner"],
        value=checkpoint,
        now=now,
    )

    if preregistered and already_active:
        revalidated_stage = verify_active_preregistered_protocol(
            root, protocol_path=experiment_path,
        )
        if revalidated_stage != immutable_stage:
            raise PermissionError("active protocol immutable source changed during observer commit")
    elif preregistered:
        validate_preregistered_protocol_activation(
            root,
            protocol_path=experiment_path,
            completion_job=prepared,
        )

    completed = queue.succeed(
        prepared["job_id"],
        worker_id=prepared["lease_owner"],
        checkpoint=prepared.get("checkpoint") or {},
        now=now,
    )
    activation_error: Exception | None = None
    if preregistered and not already_active:
        try:
            activate_preregistered_protocol(
                root,
                protocol_path=experiment_path,
                completion_job=completed,
            )
            revalidated_stage = verify_active_preregistered_protocol(
                root, protocol_path=active_path,
            )
            if revalidated_stage != resolved_experiment:
                raise PermissionError(
                    "activated protocol does not resolve to the committed immutable stage"
                )
        except Exception as exc:
            # The successful queue job is the durable outbox record.  Return
            # the error to the caller only after exposing the completed job so
            # its generic failure handler cannot rewrite it as failed.
            activation_error = exc
    return prepared, completed, activation_error


def _recover_committed_protocol_activation(root: Path, queue: Any) -> bool:
    """Finish the local half of a committed observer transaction after crash."""

    from .phase6_intelligence import activate_preregistered_protocol

    jobs = [
        job
        for job in queue.snapshot().get("jobs") or []
        if job.get("state") == "SUCCEEDED"
        and job.get("task_type") == "OWNED_METRICS_CHECKPOINT"
        and (job.get("checkpoint") or {}).get("observer_transaction_version")
        == "phase6-owned-observer-transaction-v2"
        and isinstance((job.get("checkpoint") or {}).get("experiment_protocol_stage"), str)
    ]
    recovered = False
    for job in sorted(jobs, key=lambda item: (str(item.get("updated_at") or ""), item["job_id"])):
        checkpoint = job["checkpoint"]
        staged = (root / checkpoint["experiment_protocol_stage"]).resolve()
        experiments = (root / "output/operations/phase6/intelligence/experiments").resolve()
        try:
            staged.relative_to(experiments)
        except ValueError as exc:
            raise PermissionError("committed protocol stage escaped the Phase 6 experiment store") from exc
        value = _read(staged)
        if value.get("status") != "PREREGISTERED":
            continue
        active = root / "output/operations/phase6/intelligence/experiments/active.json"
        latest = root / "output/operations/phase6/intelligence/experiments/latest.json"
        if staged.name in {"active.json", "latest.json"}:
            from .phase6_intelligence import verify_active_preregistered_protocol

            verify_active_preregistered_protocol(root, protocol_path=active)
            continue
        if active.is_file() and latest.is_file() and active.read_bytes() == staged.read_bytes() == latest.read_bytes():
            from .phase6_intelligence import (
                validate_preregistered_protocol_activation,
                verify_active_preregistered_protocol,
            )

            validate_preregistered_protocol_activation(
                root, protocol_path=staged, completion_job=job,
            )
            verified_stage = verify_active_preregistered_protocol(
                root, protocol_path=active,
            )
            if verified_stage != staged:
                raise PermissionError(
                    "active protocol immutable source diverged from the committed observer stage"
                )
            continue
        activate_preregistered_protocol(root, protocol_path=staged, completion_job=job)
        recovered = True
    return recovered


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _captured_fingerprint(inputs, *, version: str, observations: bool = False) -> str:
    """Hash exact captures; old journals retain their original V1 semantics.

    This is an identity calculation, never OAuth, release or restart authority.
    Code/candidate/application identities remain separately authenticated by the
    maintenance proof, resident capability and D116 binding (no circular hash).
    """
    if version not in {"phase5-inputs-v1", FINGERPRINT_VERSION}:
        raise PermissionError("PHASE5_FINGERPRINT_VERSION_UNKNOWN")
    if [row[0] for row in inputs] != [p.as_posix() for p in INPUTS]:
        raise PermissionError("PHASE5_FINGERPRINT_INPUT_POPULATION_CHANGED")
    digest = hashlib.sha256()
    if version == FINGERPRINT_VERSION:
        digest.update((version + (":observations" if observations else ":stable")).encode())
    elif observations:
        raise PermissionError("PHASE5_FINGERPRINT_LEGACY_OBSERVATIONS_UNSUPPORTED")
    for name, raw in inputs:
        if version == FINGERPRINT_VERSION and ((Path(name) in VOLATILE_INPUTS) != observations):
            continue
        digest.update(name.encode())
        digest.update(bytes.fromhex(raw) if raw is not None else b"<MISSING>")
    return digest.hexdigest()


def _capture_fingerprint_inputs(root: Path):
    return [(name.as_posix(), (root / name).read_bytes().hex()
             if (root / name).is_file() else None) for name in INPUTS]


def input_fingerprint(root: Path = ROOT) -> str:
    return _captured_fingerprint(_capture_fingerprint_inputs(root.resolve()), version=FINGERPRINT_VERSION)


def observation_fingerprint(root: Path = ROOT) -> str:
    """Change trigger only: mutable state must still cause local re-evaluation."""
    return _captured_fingerprint(_capture_fingerprint_inputs(root.resolve()),
                                 version=FINGERPRINT_VERSION, observations=True)


def paused_fingerprint_source_paths(root: Path) -> list[Path]:
    """Inputs owned by the existing paused migration, not a second evaluator."""
    root = root.resolve()
    checkpoint = root / RUNTIME / "fingerprint.json"
    if not checkpoint.is_file() or _read(checkpoint).get("input_fingerprint") == input_fingerprint(root):
        return []
    watcher_path = root / RUNTIME / "oauth-reconsent-watcher.json"
    watcher = _read(watcher_path)
    Draft202012Validator(_read(root / "schemas/oauth_reconsent_watcher_runtime.schema.json")).validate(watcher)
    token = Path(watcher["destination_path"]).resolve()
    if token.is_relative_to(root) or not token.is_file():
        raise PermissionError("PHASE5_FINGERPRINT_RUNTIME_TOKEN_INVALID")
    paths = [root / name for name in INPUTS]
    paths += [watcher_path, token,
        root / V3 / "youtube-publication-receipt.json",
        root / V3 / "thumbnail/thumbnail_set_manifest.json",
        root / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json",
        root / "output/operations/zero-cost/phase5-publication-pipeline-preflight.json"]
    package = _read(root / V3 / "publication_package.json")
    review = _read(root / AUTONOMOUS_REVIEW_REPORT)
    thumbnails = _read(root / V3 / "thumbnail/thumbnail_set_manifest.json")
    selected = review["thumbnail_selection"]["candidate_id"]
    paths += [Path(package[key]["path"]).resolve() for key in ("video", "captions")]
    paths += [Path(item["path"]).resolve() for item in thumbnails["candidates"]
              if item["candidate_id"] == selected]
    if any(not path.is_relative_to(root) for path in paths if path != token):
        raise PermissionError("PHASE5_FINGERPRINT_SOURCE_OUTSIDE_PROJECT")
    return sorted(set(path for path in paths if path.is_file()))


def build_paused_fingerprint_reconciliation(root: Path, *, observed_at: str):
    """Re-evaluate the already-published canary locally; never publish or refresh.

    Only the official migration writes the returned candidate, with its original
    preimage and rollback. A paused observation alone does not approve inputs.
    """
    root = root.resolve()
    checkpoint = root / RUNTIME / "fingerprint.json"
    if not checkpoint.is_file():
        return None
    before = checkpoint.read_bytes()
    previous = json.loads(before.decode("utf-8-sig"))
    current = input_fingerprint(root)
    if previous.get("input_fingerprint") == current:
        return None
    if not (root / RUNTIME / "PAUSE").is_file():
        raise PermissionError("PHASE5_FINGERPRINT_OWNER_PAUSE_REQUIRED")
    if (not isinstance(previous.get("input_fingerprint"), str)
            or len(previous["input_fingerprint"]) != 64
            or any(c not in "0123456789abcdef" for c in previous["input_fingerprint"])):
        raise PermissionError("PHASE5_FINGERPRINT_PREIMAGE_INVALID")
    sources = paused_fingerprint_source_paths(root)
    from .maintenance_protocol import file_hash
    source_hashes = {path: file_hash(path) for path in sources}
    # Preserve exact bytes, including a possible UTF-8 BOM, for the digest.
    inputs = _capture_fingerprint_inputs(root)
    if _captured_fingerprint(inputs, version=FINGERPRINT_VERSION) != current:
        raise PermissionError("PHASE5_FINGERPRINT_INPUT_CAPTURE_CHANGED")
    from .oauth_operational_readiness import build_operational_readiness
    from .phase5_youtube_publisher import _validate_release
    watcher = _read(root / RUNTIME / "oauth-reconsent-watcher.json")
    readiness = _read(root / "output/integrations/youtube/heroverse/operational-readiness.json")
    replay = build_operational_readiness(root, token_file=Path(watcher["destination_path"]),
                                       observed_at=readiness["observed_at"])
    if replay != readiness or not replay["continuous_operation_ready"]:
        raise PermissionError("PHASE5_FINGERPRINT_READINESS_NOT_REPRODUCIBLE")
    release = build_release_gate(root, created_at=observed_at)
    _validate_release(root, release)
    publication_path = root / V3 / "youtube-publication-receipt.json"
    publication = _read(publication_path)
    Draft202012Validator(_read(root / "schemas/youtube_publication_receipt.schema.json")).validate(publication)
    expected_hashes = {name: release["artifacts"][name]["sha256"] for name in ("video", "thumbnail", "captions")}
    if not (publication["status"] == "COMPLETE_PUBLIC"
            and publication["channel_id"] == release["channel_id"]
            and publication["release_id"] == release["release_id"]
            and publication["idempotency_key"] == release["idempotency_key"]
            and publication["artifact_hashes"] == expected_hashes
            and all(step["status"] == "PASS" for step in publication["steps"])):
        raise PermissionError("PHASE5_FINGERPRINT_NOT_EXACT_COMPLETED_PUBLICATION")
    if (checkpoint.read_bytes() != before or input_fingerprint(root) != current
            or any(file_hash(path) != expected for path, expected in source_hashes.items())):
        raise PermissionError("PHASE5_FINGERPRINT_INPUTS_CHANGED_DURING_RECONCILIATION")
    value = {"input_fingerprint": current, "updated_at": observed_at,
             "fingerprint_version": FINGERPRINT_VERSION,
             "observation_fingerprint": _captured_fingerprint(inputs, version=FINGERPRINT_VERSION, observations=True)}
    evidence = {"kind": "PAUSED_COMPLETED_PHASE5_LOCAL_RECONCILIATION_V2",
        "previous_fingerprint": previous["input_fingerprint"], "current_fingerprint": current,
        "input_bytes": inputs, "release": release, "publication": publication,
        "readiness": readiness, "external_api_calls": 0, "publication_effects": 0}
    return value, evidence


def _publication_retry_due(root: Path) -> bool:
    status_path = root.resolve() / RUNTIME / "status.json"
    if not status_path.is_file():
        return False
    try:
        return _read(status_path).get("publication_status") == "STAGED_PRIVATE_AWAITING_PROCESSING"
    except (OSError, json.JSONDecodeError, TypeError):
        return False


def _run_current_audio_observer(root, token_file, *, relative, bindings, release_hash, current):
    """Use the resident queue/quota and exact job-owned collection journal."""
    from .phase5_youtube_publisher import _validate_current_release, execute_publication_pipeline
    from .phase6_pilot import materialize_video_live
    from .queue_phase6 import TransactionalQueue
    from .phase6_quota import reserve_general_quota, consume_general_quota, get_general_quota_debit
    started = time.monotonic()
    initial_current = current
    def observed_now():
        return initial_current + timedelta(seconds=time.monotonic() - started)
    root = root.resolve(); relative = Path(relative)
    _validate_current_release(root, relative, bindings, release_hash)
    publication = execute_publication_pipeline(None, None, root, package_relative=relative,
        current_bindings=bindings, expected_release_hash=release_hash)
    if publication.get('status') != 'COMPLETE_PUBLIC':
        raise PermissionError('Current observer requires a completed public delivery')
    directory = root / relative; receipt_path = directory / 'youtube-publication-receipt.json'
    publication_hash = 'sha256:' + hashlib.sha256(receipt_path.read_bytes()).hexdigest()
    video = publication['video_id']; operation = 'heroverse-audio-static-longform-v1'
    queue = TransactionalQueue(root); claimed = None
    current = observed_now()
    jobs = [j for j in queue.snapshot(captured_at=current)['jobs']
            if j['task_type'] == 'OWNED_METRICS_CHECKPOINT' and j['operation_id'] == operation
            and j['payload'].get('video_id') == video
            and j['payload'].get('publication_receipt_hash') == publication_hash]
    next_at = None; latest_ref = None; status = 'BLOCKED'; error = None

    def read_completed(job):
        _validate_owned_preflight(root, job_id=job['job_id'], checkpoint=job['checkpoint'])
        path, value = _read_owned_artifact(root, job_id=job['job_id'], label='owned-metrics',
            reference=job['checkpoint'].get('metrics_snapshot'),
            expected_hash=job['checkpoint'].get('metrics_snapshot_hash'),
            schema_name='own_channel_performance_snapshot.schema.json')
        if value['video_id'] != video or value['channel_id'] != publication['channel_id']:
            raise PermissionError('Current observer checkpoint belongs to another delivery')
        _validate_owned_quota_debit_chain(root, job=job, snapshot=value)
        return path, value

    try:
        unfinished = [j for j in jobs if j['state'] != 'SUCCEEDED']
        completed = sorted([j for j in jobs if j['state'] == 'SUCCEEDED'], key=lambda j:j['created_at'])
        if completed:
            path, value = read_completed(completed[-1]); latest_ref = path.relative_to(root).as_posix()
            next_at = value['next_observation_at']
            alias = root / 'output/operations/phase6/metrics' / video / 'latest.json'
            if alias.is_file() and alias.read_bytes() != path.read_bytes():
                raise PermissionError('Current observer latest differs from completed checkpoint')
            if not alias.is_file():
                _restore_owned_metrics_views(root, source=path, value=value)
        if not unfinished and completed and (next_at is None or current < _parse_connection_time(next_at)):
            status = 'NOT_DUE'
        else:
            if len(unfinished) > 1:
                raise PermissionError('Current observer has ambiguous unfinished checkpoints')
            if token_file is None or not token_file.is_file() or not _outside_workspace(token_file, root):
                raise PermissionError('EXTERNAL_RUNTIME_TOKEN_UNAVAILABLE')
            job = unfinished[0] if unfinished else queue.enqueue(
                idempotency_key=f'audio-owned-metrics:{video}:{publication_hash}:{next_at or "INITIAL"}',
                operation_id=operation, channel_id=publication['channel_id'], task_type='OWNED_METRICS_CHECKPOINT',
                payload={'video_id':video,'publication_receipt_hash':publication_hash,'scheduled_window':next_at or 'INITIAL'},
                max_attempts=2, now=observed_now())
            cp = dict(job.get('checkpoint') or {})
            source = root / 'output/operations/phase6/intelligence/external-read-checkpoints' / job['job_id'] / 'owned-metrics-source.json'
            def claim():
                nonlocal claimed
                claimed = queue.claim_job(job['job_id'],worker_id=f'gestor-central-{os.getpid()}',
                    expected_task_type='OWNED_METRICS_CHECKPOINT',lease_seconds=900,now=observed_now())
                if claimed is None:
                    raise PermissionError('Current observer job is active, terminal or not due; no redispatch')
            if source.is_file():
                claim()
                _validate_owned_preflight(root,job_id=job['job_id'],checkpoint=cp)
                debit = get_general_quota_debit(root,idempotency_key=cp['quota_debit']['idempotency_key'])
                if not debit or debit['job_id'] != job['job_id'] or debit['units'] != 2:
                    raise PermissionError('Current observer recovered source lacks its quota reservation')
            else:
                # This native exception is raised at the first pulse, before
                # OAuth or discovery exists. It is not an unknown API outcome.
                before_oauth_timeout = (job['state'] == 'RETRY_WAIT' and
                    job.get('last_error') == 'GoogleOperationDeadlineExceeded:Google operation deadline exhausted at oauth.phase6-pilot:before')
                if cp.get('collection_started') and not before_oauth_timeout:
                    raise PermissionError('Current observer collection outcome unknown; query repetition forbidden')
                def begin_or_renew():
                    nonlocal claimed, debit
                    if claimed is not None:
                        claimed = queue.renew_lease(job['job_id'],worker_id=claimed['lease_owner'],lease_seconds=900,now=observed_now())
                        return
                    claim()
                    zero, ref, digest = _materialize_owned_preflight(root,job_id=job['job_id'],current=observed_now())
                    if not zero['execution_permitted']:
                        raise PermissionError('Current observer free quota preflight blocks collection')
                    usage = _quota_usage(root)
                    if not usage or not isinstance(usage.get('youtube-general-units-daily'),int):
                        raise PermissionError('Current observer effective free quota unavailable')
                    if before_oauth_timeout:
                        _validate_owned_preflight(root,job_id=job['job_id'],checkpoint=cp)
                        old = cp.get('quota_debit') or {}
                        debit = get_general_quota_debit(root,idempotency_key=old.get('idempotency_key',''))
                        if (not debit or debit['state'] != 'RESERVED' or debit['job_id'] != job['job_id']
                                or debit['units'] != 2 or _quota_debit_checkpoint(debit) != old):
                            raise PermissionError('Pre-OAuth timeout lacks its exact unused quota reservation')
                    else:
                        debit = reserve_general_quota(root,idempotency_key=f'audio-owned-metrics:{job["job_id"]}',
                            operation_id='phase6_owned_metrics_checkpoint',job_id=job['job_id'],
                            attempt_count=claimed['attempt_count'],effective_general_before=usage['youtube-general-units-daily'],
                            units=2,preventive_floor=12,now=observed_now())
                    cp.update(quota_preflight=ref,quota_preflight_hash=digest,quota_debit=_quota_debit_checkpoint(debit),
                        quota_debit_ids=[debit['debit_id']],quota_ledger_version='phase6-general-quota-ledger-v1.1',collection_started=True)
                    claimed=queue.checkpoint(job['job_id'],worker_id=claimed['lease_owner'],value=cp,now=observed_now())
                materialize_video_live(root,token_path=token_file,video_id=video,publication_receipt=receipt_path,
                    captured_at=observed_now().isoformat().replace('+00:00','Z'),immutable_destination=source,
                    progress=begin_or_renew,deadline_seconds=240,package_relative=relative,current_bindings=bindings,expected_release_hash=release_hash)
                if claimed is None:
                    raise PermissionError('Current collector returned without native dispatch admission')
            value=_read(source)
            Draft202012Validator(_read(root/'schemas/own_channel_performance_snapshot.schema.json')).validate(value)
            if value['video_id'] != video or value['channel_id'] != publication['channel_id']:
                raise PermissionError('Current observer source identity differs')
            claimed = queue.renew_lease(job['job_id'],worker_id=claimed['lease_owner'],lease_seconds=900,now=observed_now())
            _validate_current_release(root,relative,bindings,release_hash)
            if 'sha256:'+hashlib.sha256(receipt_path.read_bytes()).hexdigest() != publication_hash:
                raise PermissionError('Current publication changed during observer transaction')
            debit=consume_general_quota(root,idempotency_key=debit['idempotency_key'],now=observed_now())
            _restore_owned_metrics_views(root,source=source,value=value)
            ref,digest=_archive_owned_artifact(root,job_id=job['job_id'],label='owned-metrics',source=source)
            cp.update(metrics_snapshot=ref,metrics_snapshot_hash=digest,quota_debit=_quota_debit_checkpoint(debit),
                      next_observation_at=value['next_observation_at'])
            _validate_owned_quota_debit_chain(root,job={**claimed,'checkpoint':cp},snapshot=value)
            queue.succeed(job['job_id'],worker_id=claimed['lease_owner'],checkpoint=cp,now=observed_now())
            claimed=None;latest_ref=ref;next_at=value['next_observation_at'];status='COLLECTED'
        if status in {'COLLECTED', 'NOT_DUE'} and latest_ref:
            from .phase6_intelligence import materialize_current
            materialize_current(root, package_relative=relative, current_bindings=bindings,
                                expected_release_hash=release_hash, snapshot_reference=latest_ref)
    except Exception as exc:
        error=f'{type(exc).__name__}:{exc}';status='ERROR'
        if claimed is not None:
            queue.fail(claimed['job_id'],worker_id=claimed['lease_owner'],error=error,
                       checkpoint=claimed.get('checkpoint') or {},now=observed_now())
    value={'schema_version':'1.1.0','observer_id':'heroverse-own-channel-observer-v1','phase':6,
           'status':status,'video_id':video,'latest_snapshot':latest_ref,'next_observation_at':next_at,
           'error':error,'technical_cost_brl':0,'updated_at':observed_now().isoformat().replace('+00:00','Z')}
    Draft202012Validator(_read(root/'schemas/phase6_observer_runtime.schema.json')).validate(value)
    _write(directory/'observer-status.json',value)
    return value


def run_phase6_observer_if_due(
    root: Path,
    token_file: Path | None,
    *,
    now: datetime | None = None,
    package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None,
    expected_release_hash: str | None = None,
) -> dict[str, Any]:
    """Run the Phase 6 owner-metrics observer only at a preregistered window."""

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if package_relative is not None:
        if current_bindings is None or expected_release_hash is None:
            raise PermissionError('Current observer selection requires external bindings')
        return _run_current_audio_observer(root,token_file,relative=package_relative,
            bindings=current_bindings,release_hash=expected_release_hash,current=current)
    if current_bindings is not None or expected_release_hash is not None:
        raise PermissionError('Current observer bindings require an explicit package')
    output = root / "output/operations/phase6/observer-status.json"
    latest_path = root / "output/operations/phase6/metrics/iK_5edYQtx8/latest.json"
    plan_path = root / "output/operations/phase6/pilot-plan.json"
    publication_path = root / V3 / "youtube-publication-receipt.json"
    status = "BLOCKED"
    error: str | None = None
    next_observation: str | None = None
    latest_ref: str | None = None
    publication_ref: str | None = None
    publication_hash: str | None = None
    publication_error: str | None = None
    if plan_path.is_file() and publication_path.is_file():
        try:
            publication_ref, publication_hash = _validate_phase6_publication_receipt(
                root, publication_path
            )
        except Exception as exc:
            publication_error = f"{type(exc).__name__}: {exc}"
    if not plan_path.is_file() or not publication_path.is_file():
        error = "PHASE6_PLAN_OR_PUBLICATION_RECEIPT_MISSING"
    elif publication_error is not None:
        error = f"PUBLICATION_RECEIPT_INVALID:{publication_error}"
    elif token_file is None or not token_file.is_file() or not _outside_workspace(token_file, root):
        error = "EXTERNAL_RUNTIME_TOKEN_UNAVAILABLE"
    else:
        from .queue_phase6 import TransactionalQueue

        queue = TransactionalQueue(root)
        recovery_error: str | None = None
        activation_recovered = False
        try:
            activation_recovered = _recover_committed_protocol_activation(root, queue)
            resume_job = _recoverable_owned_metrics_job(queue, current)
        except Exception as exc:
            resume_job = None
            recovery_error = f"{type(exc).__name__}: {exc}"
        due = True
        if latest_path.is_file():
            latest = _read(latest_path)
            latest_ref = latest_path.relative_to(root).as_posix()
            next_observation = latest.get("next_observation_at")
            due = bool(next_observation and current >= _parse_connection_time(next_observation))
        due = due or resume_job is not None
        if recovery_error is not None:
            status = "ERROR"
            error = recovery_error
        elif not due:
            status = "COLLECTED" if activation_recovered else "NOT_DUE"
        else:
            claimed = None
            completed = None
            status = "RUNNING"
            try:
                from .youtube_reporting_phase6 import materialize_live as materialize_reporting
                from .phase6_pilot import materialize_live
                from .phase6_intelligence import materialize_current as materialize_intelligence
                from .phase6_quota import (
                    QuotaReservationBlocked,
                    consume_general_quota,
                    get_general_quota_debit,
                    reserve_general_quota,
                )

                queue = TransactionalQueue(root)
                if resume_job is not None:
                    queued = resume_job
                    scheduled_window = str((queued.get("payload") or {}).get("scheduled_window") or "INITIAL")
                else:
                    scheduled_window = next_observation or "INITIAL"
                    queued = queue.enqueue(
                        idempotency_key=f"phase6-owned-metrics:{scheduled_window}",
                        operation_id="heroverse-phase6-controlled-longform-v1",
                        channel_id="UCuMF6pJQkyMzaVoAxFL86yA",
                        task_type="OWNED_METRICS_CHECKPOINT",
                        payload={"video_id": "iK_5edYQtx8", "scheduled_window": scheduled_window},
                        max_attempts=3,
                        now=current,
                    )
                if queued["state"] in {"RETRY_WAIT", "PENDING"} and current < _parse_connection_time(queued["available_at"]):
                    status = "BLOCKED"
                    error = queued.get("last_error")
                    next_observation = queued["available_at"]
                    queue.materialize_snapshot(captured_at=current)
                    raise PermissionError(error or "PHASE6_OWNED_METRICS_JOB_NOT_DUE")
                checkpoint = queued.get("checkpoint") or {}
                checkpointed_metrics = isinstance(checkpoint.get("metrics_snapshot"), str)
                if checkpointed_metrics:
                    _validate_owned_preflight(root, job_id=queued["job_id"], checkpoint=checkpoint)
                    _, latest = _read_owned_artifact(
                        root, job_id=queued["job_id"], label="owned-metrics",
                        reference=checkpoint.get("metrics_snapshot"), expected_hash=checkpoint.get("metrics_snapshot_hash"),
                        schema_name="own_channel_performance_snapshot.schema.json",
                    )
                    _validate_owned_quota_debit_chain(
                        root, job=queued, snapshot=latest,
                    )
                    preflight_ref = checkpoint["quota_preflight"]
                    preflight_hash = checkpoint["quota_preflight_hash"]
                else:
                    zero, preflight_ref, preflight_hash = _materialize_owned_preflight(
                        root, job_id=queued["job_id"], current=current,
                    )
                    if zero.get("execution_permitted") is not True:
                        retry_at = current + timedelta(minutes=5)
                        deferred = queue.defer(
                            queued["job_id"], available_at=retry_at,
                            reason="PHASE6_OWNED_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
                            checkpoint={**checkpoint, "quota_preflight": preflight_ref, "quota_preflight_hash": preflight_hash},
                            now=current,
                        )
                        status = "BLOCKED"
                        error = "PHASE6_OWNED_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED"
                        next_observation = deferred["available_at"]
                        queue.materialize_snapshot(captured_at=current)
                        raise PermissionError(error)
                claimed = queue.claim_job(
                    queued["job_id"],
                    worker_id=f"gestor-central-{os.getpid()}",
                    expected_task_type="OWNED_METRICS_CHECKPOINT",
                    lease_seconds=900,
                    now=current,
                )
                if claimed is None or claimed["job_id"] != queued["job_id"]:
                    raise RuntimeError(f"PHASE6_QUEUE_JOB_NOT_CLAIMABLE:{queued['state']}")
                lease_clock_started = time.monotonic()

                def operation_now() -> datetime:
                    elapsed_seconds = int(max(0.0, time.monotonic() - lease_clock_started))
                    return current + timedelta(seconds=elapsed_seconds)

                def renew_owned_lease() -> None:
                    nonlocal claimed
                    if claimed is None:
                        raise RuntimeError("owned metrics lease is no longer active")
                    claimed = queue.renew_lease(
                        claimed["job_id"],
                        worker_id=claimed["lease_owner"],
                        lease_seconds=900,
                        now=operation_now(),
                    )

                claimed = queue.checkpoint(
                    claimed["job_id"], worker_id=claimed["lease_owner"],
                    value={
                        **(claimed.get("checkpoint") or {}),
                        "quota_preflight": preflight_ref,
                        "quota_preflight_hash": preflight_hash,
                        "publication_receipt": publication_ref,
                        "publication_receipt_hash": publication_hash,
                    },
                    now=operation_now(),
                )
                reporting_ref = claimed["checkpoint"].get("reporting_registry")
                if isinstance(reporting_ref, str):
                    _read_owned_artifact(
                        root, job_id=claimed["job_id"], label="reporting-registry",
                        reference=reporting_ref, expected_hash=claimed["checkpoint"].get("reporting_registry_hash"),
                        schema_name="youtube_reporting_job_registry.schema.json",
                    )
                else:
                    _validate_phase6_publication_receipt(
                        root, publication_path, expected_hash=str(publication_hash)
                    )
                    reporting_intent = claimed["checkpoint"].get("reporting_intent")
                    if not isinstance(reporting_intent, dict):
                        reporting_intent = _reporting_registry_intent(
                            root,
                            job_id=claimed["job_id"],
                            observed_at=operation_now(),
                        )
                        claimed = queue.checkpoint(
                            claimed["job_id"],
                            worker_id=claimed["lease_owner"],
                            value={
                                **(claimed.get("checkpoint") or {}),
                                "reporting_intent": reporting_intent,
                            },
                            now=operation_now(),
                        )
                    recovered_registry = _recover_reporting_registry_from_intent(
                        root,
                        job_id=claimed["job_id"],
                        intent=reporting_intent,
                    )
                    if recovered_registry is not None:
                        reporting_path = recovered_registry[0]
                    else:
                        reporting_path = materialize_reporting(
                            root,
                            token_path=token_file.resolve(),
                            captured_at=reporting_intent["observed_at"],
                            progress=renew_owned_lease,
                            deadline_seconds=240,
                        )
                    reporting_ref, reporting_hash = _archive_owned_artifact(
                        root, job_id=claimed["job_id"], label="reporting-registry", source=reporting_path,
                    )
                    claimed = queue.checkpoint(
                        claimed["job_id"], worker_id=claimed["lease_owner"],
                        value={**(claimed.get("checkpoint") or {}), "reporting_registry": reporting_ref, "reporting_registry_hash": reporting_hash},
                        now=operation_now(),
                    )
                if checkpointed_metrics:
                    snapshot, latest = _read_owned_artifact(
                        root, job_id=claimed["job_id"], label="owned-metrics",
                        reference=claimed["checkpoint"].get("metrics_snapshot"),
                        expected_hash=claimed["checkpoint"].get("metrics_snapshot_hash"),
                        schema_name="own_channel_performance_snapshot.schema.json",
                    )
                else:
                    raw_source = (
                        root
                        / "output/operations/phase6/intelligence/external-read-checkpoints"
                        / claimed["job_id"]
                        / "owned-metrics-source.json"
                    )
                    debit_checkpoint = (claimed.get("checkpoint") or {}).get("quota_debit")
                    if raw_source.is_file():
                        if not isinstance(debit_checkpoint, dict) or not isinstance(
                            debit_checkpoint.get("idempotency_key"), str
                        ):
                            raise PermissionError("orphaned owned metrics has no committed quota reservation")
                        prior_debit = get_general_quota_debit(
                            root, idempotency_key=debit_checkpoint["idempotency_key"]
                        )
                        if not (
                            isinstance(prior_debit, dict)
                            and prior_debit.get("job_id") == claimed["job_id"]
                            and prior_debit.get("operation_id") == "phase6_owned_metrics_checkpoint"
                            and prior_debit.get("units") == 2
                        ):
                            raise PermissionError("orphaned owned metrics quota reservation diverged")
                        latest = _validate_orphan_owned_metrics_source(
                            root, job_id=claimed["job_id"], path=raw_source,
                        )
                        debit = consume_general_quota(
                            root,
                            idempotency_key=debit_checkpoint["idempotency_key"],
                            now=operation_now(),
                        )
                        _restore_owned_metrics_views(root, source=raw_source, value=latest)
                    else:
                        _validate_phase6_publication_receipt(
                            root, publication_path, expected_hash=str(publication_hash)
                        )
                        observed_usage = _quota_usage(root)
                        general_before = (
                            observed_usage.get("youtube-general-units-daily")
                            if isinstance(observed_usage, dict)
                            else None
                        )
                        if not isinstance(general_before, int) or isinstance(general_before, bool):
                            raise QuotaReservationBlocked("effective general quota is unavailable before debit")
                        debit_key = (
                            f"phase6-owned-metrics:{claimed['job_id']}:"
                            f"attempt-{claimed['attempt_count']}"
                        )
                        try:
                            debit = reserve_general_quota(
                                root,
                                idempotency_key=debit_key,
                                operation_id="phase6_owned_metrics_checkpoint",
                                job_id=claimed["job_id"],
                                attempt_count=int(claimed["attempt_count"]),
                                effective_general_before=general_before,
                                units=2,
                                preventive_floor=12,
                                now=operation_now(),
                            )
                        except QuotaReservationBlocked as exc:
                            retry_at = operation_now() + timedelta(minutes=5)
                            deferred = queue.defer_claimed(
                                claimed["job_id"],
                                worker_id=claimed["lease_owner"],
                                available_at=retry_at,
                                reason="PHASE6_OWNED_METRICS_ATOMIC_QUOTA_RESERVATION_BLOCKED",
                                checkpoint=claimed.get("checkpoint") or {},
                                now=operation_now(),
                            )
                            status = "BLOCKED"
                            error = f"PHASE6_OWNED_METRICS_ATOMIC_QUOTA_RESERVATION_BLOCKED:{exc}"
                            next_observation = deferred["available_at"]
                            queue.materialize_snapshot(captured_at=operation_now())
                            claimed = None
                            raise PermissionError(error) from exc
                        debit_ids = list((claimed.get("checkpoint") or {}).get("quota_debit_ids") or [])
                        if debit["debit_id"] not in debit_ids:
                            debit_ids.append(debit["debit_id"])
                        claimed = queue.checkpoint(
                            claimed["job_id"],
                            worker_id=claimed["lease_owner"],
                            value={
                                **(claimed.get("checkpoint") or {}),
                                "quota_debit": _quota_debit_checkpoint(debit),
                                "quota_debit_ids": debit_ids,
                                "quota_ledger_version": "phase6-general-quota-ledger-v1.1",
                            },
                            now=operation_now(),
                        )
                        source_snapshot = materialize_live(
                            root,
                            token_path=token_file.resolve(),
                            captured_at=current.isoformat().replace("+00:00", "Z"),
                            immutable_destination=raw_source,
                            progress=renew_owned_lease,
                            deadline_seconds=240,
                        )
                        if not raw_source.is_file():
                            value = _read(source_snapshot)
                            _write_immutable_bytes(raw_source, _canonical_bytes(value))
                        latest = _validate_orphan_owned_metrics_source(
                            root, job_id=claimed["job_id"], path=raw_source,
                        )
                        debit = consume_general_quota(
                            root, idempotency_key=debit_key, now=operation_now(),
                        )
                        _restore_owned_metrics_views(root, source=raw_source, value=latest)
                    snapshot_ref, snapshot_hash = _archive_owned_artifact(
                        root, job_id=claimed["job_id"], label="owned-metrics", source=raw_source,
                    )
                    claimed = queue.checkpoint(
                        claimed["job_id"], worker_id=claimed["lease_owner"],
                        value={
                            **(claimed.get("checkpoint") or {}),
                            "quota_debit": _quota_debit_checkpoint(debit),
                            "quota_ledger_version": "phase6-general-quota-ledger-v1.1",
                            "metrics_snapshot": snapshot_ref,
                            "metrics_snapshot_hash": snapshot_hash,
                        },
                        now=operation_now(),
                    )
                    snapshot = root / snapshot_ref
                latest_ref = snapshot.relative_to(root).as_posix()
                next_observation = latest["next_observation_at"]
                if not latest_path.is_file() or latest_path.read_bytes() != snapshot.read_bytes():
                    raise PermissionError("OWNED_METRICS_LATEST_DIVERGED_BEFORE_INTELLIGENCE")
                prediction_path, diagnosis_path, experiment_path = materialize_intelligence(root)
                prediction_ref, prediction_hash = _workspace_artifact_binding(root, prediction_path)
                diagnosis_ref, diagnosis_hash = _workspace_artifact_binding(root, diagnosis_path)
                experiment_ref, experiment_hash = _workspace_artifact_binding(root, experiment_path)
                completion_checkpoint = {
                    **(claimed.get("checkpoint") or {}),
                    "observer_transaction_version": "phase6-owned-observer-transaction-v2",
                    "reporting_registry": reporting_ref,
                    "metrics_snapshot": latest_ref,
                    "baseline_snapshot_id": latest.get("snapshot_id"),
                    "prediction_record": prediction_ref,
                    "prediction_record_hash": prediction_hash,
                    "diagnostic_decision": diagnosis_ref,
                    "diagnostic_decision_hash": diagnosis_hash,
                    "experiment_protocol": experiment_ref,
                    "experiment_protocol_stage": experiment_ref,
                    "experiment_protocol_stage_hash": experiment_hash,
                    "next_observation_at": next_observation,
                }
                claimed, completed, activation_error = _commit_owned_observer_transaction(
                    root,
                    queue=queue,
                    claimed=claimed,
                    completion_checkpoint=completion_checkpoint,
                    experiment_path=experiment_path,
                    now=operation_now(),
                )
                if activation_error is not None:
                    raise activation_error
                queue.materialize_snapshot(captured_at=current)
                status = "COLLECTED"
            except Exception as exc:
                if status != "BLOCKED":
                    status = "ERROR"
                    error = f"{type(exc).__name__}: {exc}"
                if queue is not None and claimed is not None and completed is None:
                    try:
                        current_job = next(
                            (
                                item
                                for item in queue.snapshot(captured_at=operation_now()).get("jobs") or []
                                if item.get("job_id") == claimed["job_id"]
                            ),
                            claimed,
                        )
                        queue.fail(
                            claimed["job_id"], worker_id=claimed["lease_owner"],
                            error=error,
                            checkpoint=current_job.get("checkpoint") or {},
                            now=operation_now(),
                        )
                        queue.materialize_snapshot(captured_at=current)
                    except Exception as queue_exc:
                        error += f" | QUEUE_FAILURE:{type(queue_exc).__name__}:{queue_exc}"
    value = {
        "schema_version": "1.0.0", "observer_id": "heroverse-own-channel-observer-v1",
        "phase": 6, "status": status, "video_id": "iK_5edYQtx8",
        "latest_snapshot": latest_ref, "next_observation_at": next_observation,
        "error": error, "technical_cost_brl": 0,
        "updated_at": current.isoformat().replace("+00:00", "Z"),
    }
    Draft202012Validator(_read(root / "schemas/phase6_observer_runtime.schema.json")).validate(value)
    _write(output, value)
    return value


def run_phase6_treatment_executor(
    root: Path,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Compile an eligible treatment through the transactional Phase 6 queue.

    The worker ends at preproduction. It never publishes, updates public
    metadata or spends; those actions retain their own critical gates.
    """

    from .phase6_production import (
        compile_preproduction,
        materialize_treatment_order,
        verify_preproduction_receipt,
    )
    from .queue_phase6 import TransactionalQueue

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    status_path = root / "output/operations/phase6/production/executor-status.json"
    order_path = materialize_treatment_order(root, created_at=current.isoformat().replace("+00:00", "Z"))
    order = _read(order_path)
    status = "WAITING"
    job_id: str | None = None
    job_state = "NOT_CREATED"
    receipt_path: str | None = None
    error: str | None = None
    next_action = "Wait for the exact 24-hour owned snapshot and preregistered diagnosis."
    if order["status"] == "BLOCKED":
        status = "BLOCKED"
        next_action = "Repair the failed prerequisite gates without relaxing them, then rematerialize the order."
    elif order["status"] == "READY_TO_COMPILE":
        queue = TransactionalQueue(root)
        job = queue.enqueue(
            idempotency_key=order["execution_contract"]["idempotency_key"],
            operation_id=order["operation_id"],
            channel_id=order["channel_id"],
            task_type="COMPILE_PHASE6_TREATMENT",
            payload={
                "order_id": order["order_id"],
                "order_path": order_path.relative_to(root).as_posix(),
                "action": order["action"],
            },
            max_attempts=int(order["execution_contract"]["maximum_attempts"]),
            now=current,
        )
        job_id, job_state = job["job_id"], job["state"]
        if job_state == "SUCCEEDED":
            checkpoint = job.get("checkpoint") or {}
            receipt_path = checkpoint.get("preproduction_receipt")
            try:
                verified_receipt = verify_preproduction_receipt(
                    root,
                    receipt_path=receipt_path,
                    expected_order_id=order["order_id"],
                    expected_receipt_id=checkpoint.get("receipt_id"),
                )
                if (
                    checkpoint.get("order_content_hash")
                    != verified_receipt.get("order_content_hash")
                    or checkpoint.get("compiler_identity_hash")
                    != (verified_receipt.get("compiler_identity") or {}).get("identity_sha256")
                ):
                    raise PermissionError(
                        "successful treatment checkpoint identity/hash binding diverged"
                    )
                status = "COMPLETED"
                next_action = checkpoint.get(
                    "next_action", "Continue with the next quality-gated production stage."
                )
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                status = "BLOCKED"
                next_action = (
                    "Preserve the succeeded job and repair its immutable preproduction "
                    "evidence; never reuse an unverified checkpoint."
                )
        else:
            claimed = queue.claim_job(
                job_id,
                worker_id=f"gestor-central-treatment-{os.getpid()}",
                expected_task_type="COMPILE_PHASE6_TREATMENT",
                lease_seconds=900,
                now=current,
            )
            if claimed is None:
                status = "RETRY_WAIT" if job_state == "RETRY_WAIT" else "WAITING"
                next_action = "The idempotent treatment job is already leased or waiting for its bounded retry window."
            elif claimed["job_id"] != job_id:
                error = f"PHASE6_TREATMENT_QUEUE_IDENTITY_MISMATCH:{claimed['job_id']}"
                queue.fail(
                    claimed["job_id"], worker_id=claimed["lease_owner"], error=error, now=current,
                )
                status = "ERROR"
                next_action = "Preserve the mismatched job and retry only through its own idempotency key."
            else:
                treatment_clock_started = time.monotonic()

                def treatment_now() -> datetime:
                    return current + timedelta(
                        seconds=max(0.0, time.monotonic() - treatment_clock_started)
                    )

                lease_stop = threading.Event()
                lease_errors: list[BaseException] = []

                def treatment_lease_heartbeat() -> None:
                    while not lease_stop.wait(60):
                        try:
                            queue.renew_lease(
                                job_id,
                                worker_id=claimed["lease_owner"],
                                lease_seconds=900,
                                now=treatment_now(),
                            )
                        except BaseException as exc:  # surfaced before commit
                            lease_errors.append(exc)
                            return

                lease_thread = threading.Thread(
                    target=treatment_lease_heartbeat,
                    name=f"phase6-treatment-lease-{job_id}",
                    daemon=True,
                )
                lease_thread.start()
                try:
                    receipt = compile_preproduction(order, root, created_at=order["created_at"])
                    if lease_errors:
                        raise RuntimeError(
                            f"TREATMENT_LEASE_HEARTBEAT_FAILED:{lease_errors[0]}"
                        )
                    queue.renew_lease(
                        job_id,
                        worker_id=claimed["lease_owner"],
                        lease_seconds=900,
                        now=treatment_now(),
                    )
                    receipt_path = (
                        "output/operations/phase6/production/preproduction-receipts/"
                        f"{receipt['receipt_id']}.json"
                    )
                    completed = queue.succeed(
                        job_id,
                        worker_id=claimed["lease_owner"],
                        checkpoint={
                            "preproduction_receipt": receipt_path,
                            "receipt_id": receipt["receipt_id"],
                            "order_content_hash": receipt["order_content_hash"],
                            "compiler_identity_hash": receipt["compiler_identity"]["identity_sha256"],
                            "next_action": receipt["next_action"],
                        },
                        now=treatment_now(),
                    )
                    job_state, status = completed["state"], "COMPLETED"
                    next_action = receipt["next_action"]
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    failed = queue.fail(
                        job_id,
                        worker_id=claimed["lease_owner"],
                        error=error,
                        checkpoint=claimed.get("checkpoint") or {},
                        now=treatment_now(),
                    )
                    job_state = failed["state"]
                    status = "BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT"
                    next_action = "Correct the recorded compilation failure and continue through the bounded transactional retry."
                finally:
                    lease_stop.set()
                    lease_thread.join(timeout=5)
        queue.materialize_snapshot(captured_at=current)
    value = {
        "schema_version": "1.0.0",
        "executor_id": "heroverse-phase6-treatment-executor-v1",
        "phase": 6,
        "status": status,
        "order_id": order.get("order_id"),
        "order_status": order.get("status", "UNAVAILABLE"),
        "job_id": job_id,
        "job_state": job_state,
        "receipt": receipt_path,
        "next_action": next_action,
        "error": error,
        "technical_cost_brl": 0,
        "updated_at": current.isoformat().replace("+00:00", "Z"),
    }
    Draft202012Validator(
        _read(root / "schemas/phase6_treatment_executor_runtime.schema.json")
    ).validate(value)
    _write(status_path, value)
    return value


def _quota_usage(root: Path) -> dict[str, int] | None:
    from .phase6_quota import effective_observation_quota_usage

    combined = dict(effective_observation_quota_usage(root) or {})

    vidiq_path = root / "output/market/vidiq/heroverse/2026-09-03/plugin-observation.json"
    vidiq_schema = root / "schemas/vidiq_plugin_observation.schema.json"
    if vidiq_path.is_file() and vidiq_schema.is_file():
        vidiq = _read(vidiq_path)
        Draft202012Validator(_read(vidiq_schema)).validate(vidiq)
        consumed = vidiq.get("quota", {}).get("consumed_credits")
        if isinstance(consumed, int) and consumed >= 0:
            combined["vidiq-renewable-free-credits"] = consumed
    return combined or None


def _run_audio_static_cycle(root: Path, relative: Path, bindings: dict[str, Any]) -> dict[str, Any]:
    """Select the current audio consumer; never evaluate or dispatch V3 cinema."""
    from .phase5_youtube_publisher import _validate_current_release

    directory = (root / relative).resolve()
    if (relative.is_absolute() or '..' in relative.parts
            or not directory.is_relative_to(root / 'output/production')):
        raise PermissionError('Manager audio package must be confined to production')
    # Capture caller-owned values privately. The native reader reopens every
    # bound artifact; a dictionary does not supply quality or effect authority.
    bindings = json.loads(json.dumps(bindings))
    recovery = bindings.pop('render_recovery', None)
    if recovery is not None:
        # Recovery is an explicit externally anchored completed operation, not
        # permission to start a replacement codec or to inherit quality PASS.
        from .render_phase5 import render_phase5_pilot
        render_phase5_pilot(root, package_relative=relative, recovery_bindings=recovery)
    release_path = directory / 'release_gate.json'
    existing = _read(release_path) if release_path.is_file() else None
    release = build_release_gate(root, package_relative=relative, current_bindings=bindings,
                                 created_at=existing['created_at'] if existing else None)
    if release != existing:
        _write(release_path, release)
    expected_hash = 'sha256:' + hashlib.sha256(release_path.read_bytes()).hexdigest()
    publication_status = 'BLOCKED'
    blockers = list(release['blockers'])
    if release['decision'] == 'READY_FOR_PUBLICATION_PIPELINE':
        _validate_current_release(root, relative, bindings, expected_hash)
        receipt_path = directory / 'youtube-publication-receipt.json'
        receipt = _read(receipt_path) if receipt_path.is_file() else None
        if receipt and receipt.get('status') == 'COMPLETE_PUBLIC':
            # Recover through the same strict effect-chain reader. Do not even
            # construct a discovery service to reopen a concluded delivery.
            receipt = execute_publication_pipeline(None, None, root, package_relative=relative,
                current_bindings=bindings, expected_release_hash=expected_hash)
            publication_status = receipt['status']
        else:
            token = os.environ.get('HERO_YT_TOKEN_PATH')
            if not token:
                blockers.append('HERO_YT_TOKEN_PATH_MISSING_FROM_MANAGER_ENVIRONMENT')
            else:
                # Recheck PAUSE/current bytes before credentials or discovery;
                # the publisher repeats admission under its resident OS lock.
                _validate_current_release(root, relative, bindings, expected_hash)
                youtube, media_factory = _build_live_service(Path(token))
                receipt = execute_publication_pipeline(youtube, media_factory, root,
                    package_relative=relative, current_bindings=bindings,
                    expected_release_hash=expected_hash)
                publication_status = receipt['status']
    identity = {key: value for key, value in release.items() if key != 'created_at'}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    status = {
        'schema_version': '1.0.0', 'manager_id': 'gestor-central-heroverse-phase5-v1',
        'mode': 'ACTIVE', 'phase': 5, 'input_fingerprint': fingerprint,
        'cycle_status': 'EVALUATED', 'release_decision': release['decision'],
        'publication_status': publication_status, 'blockers': sorted(set(blockers)),
        'technical_cost_brl': 0,
        'next_action': 'Consume this exact audio package and current gates; preserve legacy cinema evidence without dispatching its executors.',
        'updated_at': _now(),
    }
    Draft202012Validator(_read(root / 'schemas/central_manager_runtime.schema.json')).validate(status)
    _write(root / RUNTIME / 'status.json', status)
    # INPUTS/fingerprint.json are historical V1/V2 contracts. A selected audio
    # invocation must not overwrite that checkpoint with a different population.
    return status


def run_cycle(root: Path = ROOT, *, package_relative: Path | None = None,
              current_bindings: dict[str, Any] | None = None) -> dict[str, Any]:
    root = root.resolve()
    runtime = root / RUNTIME
    pause_path = runtime / "PAUSE"
    fingerprint = input_fingerprint(root)
    if pause_path.exists():
        status = {
            "schema_version": "1.0.0", "manager_id": "gestor-central-heroverse-phase5-v1", "mode": "PAUSED", "phase": 5,
            "input_fingerprint": fingerprint, "cycle_status": "PAUSED", "release_decision": "UNAVAILABLE", "publication_status": "BLOCKED",
            "blockers": ["OPERATOR_PAUSE_FILE_PRESENT"], "technical_cost_brl": 0, "next_action": "Remove the PAUSE file to resume the zero-cost supervisor.", "updated_at": _now(),
        }
        _write(runtime / "status.json", status)
        return status
    if package_relative is not None:
        if current_bindings is None:
            raise PermissionError('Manager audio selection requires authenticated current bindings')
        return _run_audio_static_cycle(root, Path(package_relative), current_bindings)
    if current_bindings is not None:
        raise PermissionError('Manager current bindings require an explicit audio package')
    final_review = root / V3 / "human-review/review_submission.json"
    draft_review = root / V3 / "human-review/review_submission.draft.json"
    if final_review.is_file():
        pack = _read(root / "config/format_packs/fp-broll-cinematic-narration-v1.json")
        evaluate_file(final_review, root, apply=pack["capability_status"] == "PROTOTYPED")
    elif draft_review.is_file():
        evaluate_file(draft_review, root, apply=False)
    autonomous_path = materialize_autonomous_quality(root)
    autonomous = _read(autonomous_path)
    pack = _read(root / "config/format_packs/fp-broll-cinematic-narration-v1.json")
    if autonomous["decision"] == "PASS_LIMITED_CANARY" and pack["capability_status"] == "PROTOTYPED":
        apply_autonomous_limited_transition(root)
    runtime_token = Path(os.environ["HERO_YT_TOKEN_PATH"]) if os.environ.get("HERO_YT_TOKEN_PATH") else None
    materialize_oauth_readiness(root, token_file=runtime_token)
    materialize_scope(root)
    zero = evaluate_zero_cost(root, observed_usage=_quota_usage(root))
    zero_path = root / "output/operations/zero-cost/phase5-publication-pipeline-preflight.json"
    _write(zero_path, zero)
    release = build_release_gate(root)
    release_path = root / V3 / "release_gate.json"
    _write(release_path, release)
    publication_status = "BLOCKED"
    if release["decision"] == "READY_FOR_PUBLICATION_PIPELINE":
        token = os.environ.get("HERO_YT_TOKEN_PATH")
        if not token:
            release["blockers"].append("HERO_YT_TOKEN_PATH_MISSING_FROM_MANAGER_ENVIRONMENT")
        else:
            youtube, media_factory = _build_live_service(Path(token))
            receipt = execute_publication_pipeline(youtube, media_factory, root)
            publication_status = receipt["status"]
    status = {
        "schema_version": "1.0.0", "manager_id": "gestor-central-heroverse-phase5-v1", "mode": "ACTIVE", "phase": 5,
        "input_fingerprint": input_fingerprint(root), "cycle_status": "EVALUATED", "release_decision": release["decision"],
        "publication_status": publication_status, "blockers": sorted(set(release["blockers"])), "technical_cost_brl": 0,
        "next_action": "Monitor inputs; on a valid change, re-evaluate and continue automatically without relaxing gates.", "updated_at": _now(),
    }
    Draft202012Validator(_read(root / "schemas/central_manager_runtime.schema.json")).validate(status)
    _write(runtime / "status.json", status)
    _write(runtime / "fingerprint.json", {"input_fingerprint": status["input_fingerprint"],
           "updated_at": status["updated_at"], "fingerprint_version": FINGERPRINT_VERSION,
           "observation_fingerprint": observation_fingerprint(root)})
    build_phase5_integrity(root)
    return status


def _start_review_console(root: Path, *, timeout_seconds: float = 30.0) -> threading.Thread:
    review_console = threading.Thread(
        target=serve_review_console,
        kwargs={"root": root, "port": REVIEW_CONSOLE_PORT},
        name="phase5-review-console",
        daemon=True,
    )
    review_console.start()
    status_path = root / RUNTIME / "review-console-status.json"
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if not review_console.is_alive():
            raise RuntimeError("review console terminated before becoming ready")
        if status_path.is_file():
            try:
                status = _read(status_path)
            except (OSError, json.JSONDecodeError):
                status = {}
            if status.get("status") == "LISTENING" and status.get("process_id") == os.getpid():
                return review_console
        time.sleep(0.05)
    raise TimeoutError("review console did not publish a matching readiness receipt")


def _outside_workspace(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        return True
    return False


def _oauth_watcher_status(
    root: Path,
    *,
    status: str,
    source: Path,
    destination: Path,
    refresh_status: str = "PENDING",
    identity_verified: bool = False,
    failure_code: str | None = None,
) -> dict[str, Any]:
    value = {
        "schema_version": "1.0.0",
        "watcher_id": "youtube-heroverse-oauth-reconsent-watcher-v1",
        "status": status,
        "manager_pid": os.getpid(),
        "source_outside_workspace": _outside_workspace(source, root),
        "destination_outside_workspace": _outside_workspace(destination, root),
        "source_path_sha256": hashlib.sha256(str(source.resolve()).casefold().encode()).hexdigest(),
        "destination_path_sha256": hashlib.sha256(str(destination.resolve()).casefold().encode()).hexdigest(),
        "source_path": str(source.resolve()),
        "destination_path": str(destination.resolve()),
        "source_exists": source.is_file(),
        "destination_exists": destination.is_file(),
        "source_destination_distinct": source.resolve() != destination.resolve(),
        "mirror_receipt": "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json",
        "refresh_receipt": "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
        "refresh_status": refresh_status,
        "identity_verified_after_refresh": identity_verified,
        "failure_code": failure_code,
        "technical_cost_brl": 0,
        "updated_at": _now(),
    }
    schema = _read(root / "schemas/oauth_reconsent_watcher_runtime.schema.json")
    Draft202012Validator(schema).validate(value)
    _write(root / RUNTIME / "oauth-reconsent-watcher.json", value)
    return value


def _existing_oauth_chain_is_current(root: Path, source: Path, destination: Path) -> bool:
    mirror_path = root / "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json"
    refresh_path = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
    connection_path = root / "output/integrations/youtube/heroverse/connection-receipt.json"
    if not destination.is_file() or not mirror_path.is_file() or not refresh_path.is_file() or not connection_path.is_file():
        return False
    try:
        destination_token = inspect_authorized_user_token(destination)
        mirror = _read(mirror_path)
        refresh = _read(refresh_path)
        connection = _read(connection_path)
        Draft202012Validator(_read(root / "schemas/oauth_token_mirror_receipt.schema.json")).validate(mirror)
        Draft202012Validator(_read(root / "schemas/oauth_noninteractive_refresh_receipt.schema.json")).validate(refresh)
        Draft202012Validator(_read(root / "schemas/youtube_connection_receipt.schema.json")).validate(connection)
        from .maintenance_protocol import oauth_source_change_pending

        source_matches = not oauth_source_change_pending(
            source,
            destination,
            mirrored_source_sha256=mirror["source_sha256"],
        )
    except Exception:
        return False
    return bool(
        source_matches
        and refresh["status"] == "PASS"
        and refresh["token_sha256"] == destination_token["sha256"]
        and refresh["identity_verified_after_refresh"] is True
        and connection["status"] == "CONNECTED"
        and connection["identity_verified"] is True
        and connection["observed_channel"]["channel_id"] == "UCuMF6pJQkyMzaVoAxFL86yA"
        and set(INTEGRATION_SCOPES).issubset(set(connection["authorization"]["granted_scopes"]))
        # The noninteractive refresh performs its own exact channels.list(mine)
        # identity probe.  It is the current proof for a newly mirrored token;
        # the older connection receipt remains the configuration/capability
        # baseline and must not be rewritten with unobserved channel metadata.
        and _parse_connection_time(refresh["tested_at"]) >= _parse_connection_time(mirror["mirrored_at"])
    )


def _parse_connection_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _oauth_access_token_ready(token_file: Path, current: datetime, *, margin_seconds: int = 300) -> bool:
    """Return whether the current access token can safely start an external operation.

    The daily identity proof validates the durable grant. Access tokens expire much
    sooner, so a release also needs an on-demand refresh check without exposing any
    token value or opening an interactive login.
    """

    try:
        token = json.loads(token_file.read_text(encoding="utf-8-sig"))
        try:
            expiry = _parse_connection_time(str(token["expiry"]))
        except ValueError:
            expiry = datetime.strptime(
                str(token["expiry"]), "%m/%d/%Y %H:%M:%S"
            ).replace(tzinfo=timezone.utc)
        scopes = {item for item in token.get("scopes", []) if isinstance(item, str)}
        return bool(
            token.get("token")
            and token.get("refresh_token")
            and set(INTEGRATION_SCOPES).issubset(scopes)
            and expiry > current + timedelta(seconds=margin_seconds)
        )
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return False


def ensure_oauth_session_health(
    root: Path,
    token_file: Path | None,
    *,
    now: datetime | None = None,
    deadline: Any | None = None,
) -> dict[str, Any]:
    """Keep the installed-app OAuth grant healthy without browser interaction.

    A successful proof is reused for 24 hours. A stale proof is refreshed and
    identity-pinned through the official token endpoint plus one channels.list
    probe. Transient failures retry at most every six hours; only a missing
    refresh grant or three consecutive failures require owner intervention.
    """

    root = root.resolve()
    from .maintenance_protocol import oauth_refresh_due_at

    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    health_path = root / RUNTIME / "oauth-session-health.json"
    receipt_path = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
    receipt_schema_path = root / "schemas/oauth_noninteractive_refresh_receipt.schema.json"
    health_schema = _read(root / "schemas/oauth_session_health.schema.json")

    prior: dict[str, Any] = {}
    if health_path.is_file():
        try:
            candidate = _read(health_path)
            Draft202012Validator(health_schema).validate(candidate)
            prior = candidate
        except Exception:
            prior = {}

    receipt: dict[str, Any] | None = None
    if receipt_path.is_file():
        try:
            candidate = _read(receipt_path)
            Draft202012Validator(_read(receipt_schema_path)).validate(candidate)
            receipt = candidate
        except Exception:
            receipt = None

    status = "BLOCKED_CONFIGURATION"
    reason_code: str | None = "TOKEN_PATH_MISSING"
    failures = int(prior.get("consecutive_failures", 0))
    last_success_at = prior.get("last_success_at")
    last_attempt_at = receipt.get("tested_at") if receipt else prior.get("last_attempt_at")
    next_check: datetime | None = None
    refreshed_now = False

    token_ready = token_file is not None and token_file.resolve().is_file() and _outside_workspace(token_file, root)
    if token_ready:
        access_token_ready = _oauth_access_token_ready(token_file.resolve(), current)
        receipt_matches_token = bool(
            receipt
            and receipt.get("token_sha256") == hashlib.sha256(token_file.resolve().read_bytes()).hexdigest()
        )
        due = True
        retrying_failed_receipt = False
        if receipt is not None:
            if receipt["status"] == "PASS":
                last_success_at = receipt["tested_at"]
                failures = 0
                next_check = oauth_refresh_due_at(
                    receipt["tested_at"], interval_seconds=OAUTH_REFRESH_INTERVAL_SECONDS
                )
                due = current >= next_check or not access_token_ready or not receipt_matches_token
                if not due:
                    status = "HEALTHY"
                    reason_code = None
            else:
                failures = max(1, failures)
                retrying_failed_receipt = True
                next_check = oauth_refresh_due_at(
                    receipt["tested_at"], interval_seconds=OAUTH_REFRESH_RETRY_SECONDS
                )
                due = current >= next_check
                reason_code = receipt.get("failure_code") or "NONINTERACTIVE_REFRESH_FAILED"

        if due:
            receipt = prove_noninteractive_refresh(
                token_file.resolve(), receipt_path, root=root, deadline=deadline,
            )
            refreshed_now = True
            last_attempt_at = receipt["tested_at"]
            if receipt["status"] == "PASS":
                status = "REFRESHED"
                reason_code = None
                failures = 0
                last_success_at = receipt["tested_at"]
                next_check = oauth_refresh_due_at(
                    receipt["tested_at"], interval_seconds=OAUTH_REFRESH_INTERVAL_SECONDS
                )
                materialize_oauth_readiness(root, token_file=token_file.resolve())
            else:
                failures = failures + 1 if retrying_failed_receipt or prior else 1
                reason_code = receipt.get("failure_code") or "NONINTERACTIVE_REFRESH_FAILED"
                next_check = oauth_refresh_due_at(
                    receipt["tested_at"], interval_seconds=OAUTH_REFRESH_RETRY_SECONDS
                )

        if receipt is not None and receipt["status"] == "FAIL":
            immediate = reason_code in {"REFRESH_TOKEN_MISSING", "REQUIRED_SCOPE_MISSING", "TOKEN_FILE_MISSING"}
            status = "REAUTH_REQUIRED" if immediate or failures >= OAUTH_REFRESH_FAILURE_THRESHOLD else "DEGRADED_RETRYING"

    value = {
        "schema_version": "1.0.0",
        "monitor_id": "youtube-heroverse-oauth-session-health-v1",
        "status": status,
        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
        "noninteractive": True,
        "refresh_interval_seconds": OAUTH_REFRESH_INTERVAL_SECONDS,
        "retry_interval_seconds": OAUTH_REFRESH_RETRY_SECONDS,
        "failure_threshold": OAUTH_REFRESH_FAILURE_THRESHOLD,
        "refresh_receipt": "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
        "refresh_receipt_status": receipt["status"] if receipt else "MISSING",
        "identity_verified": bool(receipt and receipt["status"] == "PASS" and receipt["identity_verified_after_refresh"]),
        "refreshed_now": refreshed_now,
        "consecutive_failures": failures,
        "last_attempt_at": last_attempt_at,
        "last_success_at": last_success_at,
        "next_check_at": next_check.isoformat().replace("+00:00", "Z") if next_check else None,
        "user_intervention_required": status in {"REAUTH_REQUIRED", "BLOCKED_CONFIGURATION"},
        "reason_code": reason_code,
        "quota_units_per_successful_probe": 1,
        "maximum_scheduled_probe_units_per_day": 1,
        "technical_cost_brl": 0,
        "checked_at": current.isoformat().replace("+00:00", "Z"),
    }
    Draft202012Validator(health_schema).validate(value)
    _write(health_path, value)
    return value


def _oauth_reconsent_worker(root: Path, source: Path, destination: Path) -> None:
    """Inspect once, and transact only a genuinely new usable grant.

    The manager joins this worker before running any stage. Waiting for a
    missing/partial consent file must therefore return, not hold a live thread
    for days. The next ordinary loop inspects again. A grant already present
    in the runtime token belongs to the health monitor and its six-hour failure
    retry policy, even when the most recent identity proof failed.
    """
    mirror_receipt = root / "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json"
    refresh_receipt = root / "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
    _oauth_watcher_status(
        root,
        status="WAITING_FOR_FOUR_SCOPE_TOKEN",
        source=source,
        destination=destination,
    )
    try:
        with _OAUTH_EFFECT_LOCK:
            if (root / RUNTIME / "maintenance-request.json").is_file():
                return
            if _existing_oauth_chain_is_current(root, source, destination):
                _oauth_watcher_status(
                    root,
                    status="MIRRORED_AND_REFRESHED",
                    source=source,
                    destination=destination,
                    refresh_status="PASS",
                    identity_verified=True,
                )
                return
            try:
                source_info = inspect_authorized_user_token(source)
                if not set(INTEGRATION_SCOPES).issubset(source_info["scopes"]):
                    raise PermissionError("OAuth source lacks required scopes")
            except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError, ValueError, PermissionError) as exc:
                _oauth_watcher_status(
                    root,
                    status="WAITING_FOR_FOUR_SCOPE_TOKEN",
                    source=source,
                    destination=destination,
                    failure_code="SOURCE_NOT_READY_" + type(exc).__name__,
                )
                return
            try:
                destination_info = inspect_authorized_user_token(destination)
            except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError, ValueError, PermissionError):
                destination_info = None
            if destination_info and source_info["grant_sha256"] == destination_info["grant_sha256"]:
                _oauth_watcher_status(
                    root,
                    status="WAITING_FOR_FOUR_SCOPE_TOKEN",
                    source=source,
                    destination=destination,
                    failure_code="RUNTIME_GRANT_UNCHANGED_HEALTH_MONITOR_OWNS_RETRY",
                )
                return
            # Mirror and refresh remain one indivisible boundary for the
            # manager ACK. No loop stage can observe the intermediate token.
            mirror_authorized_user_token(
                source, destination, mirror_receipt, root=root
            )
            refresh = prove_noninteractive_refresh(
                destination, refresh_receipt, root=root
            )
            materialize_oauth_readiness(root, token_file=destination)
        if refresh["status"] == "PASS":
            _oauth_watcher_status(
                root,
                status="MIRRORED_AND_REFRESHED",
                source=source,
                destination=destination,
                refresh_status="PASS",
                identity_verified=True,
            )
        else:
            _oauth_watcher_status(
                root,
                status="FAILED",
                source=source,
                destination=destination,
                refresh_status="FAIL",
                identity_verified=False,
                failure_code=refresh["failure_code"] or "REFRESH_PROOF_FAILED",
            )
    except Exception as exc:
        _oauth_watcher_status(
            root,
            status="FAILED",
            source=source,
            destination=destination,
            failure_code=type(exc).__name__,
        )


def _start_oauth_reconsent_watcher(root: Path) -> threading.Thread | None:
    source_value = os.environ.get("HERO_YT_RECONSENT_SOURCE_PATH")
    destination_value = os.environ.get("HERO_YT_TOKEN_PATH")
    if not source_value or not destination_value:
        return None
    source = Path(source_value).resolve()
    destination = Path(destination_value).resolve()
    if source == destination:
        raise ValueError("OAuth reconsent source and runtime token must be distinct")
    if not _outside_workspace(source, root) or not _outside_workspace(destination, root):
        raise PermissionError("OAuth watcher secret paths must remain outside the workspace")
    watcher = threading.Thread(
        target=_oauth_reconsent_worker,
        args=(root, source, destination),
        name="youtube-oauth-reconsent-watcher",
        daemon=True,
    )
    watcher.start()
    return watcher


def loop(root: Path = ROOT, interval_seconds: int = 60, *,
         package_relative: Path | None = None, current_bindings: dict[str, Any] | None = None) -> None:
    root = root.resolve()
    runtime = root / RUNTIME
    runtime.mkdir(parents=True, exist_ok=True)
    pid_path = runtime / "manager.pid"
    lease_seconds = max(60, max(10, interval_seconds) * 3)
    with ManagerLock(root, lease_seconds=lease_seconds) as manager_lock:
        pid_path.write_text(str(os.getpid()) + "\n", encoding="utf-8")
        from .maintenance_protocol import publish_capability, refresh_capability_token_binding

        publish_capability(
            root,
            manager_pid=os.getpid(),
            holder_started_at=str(manager_lock.acquired_at),
        )
        _start_review_console(root)
        # The OAuth watcher can mirror a token and perform a remote refresh.
        # It must therefore start only after any boot-time maintenance barrier
        # has been released, never merely because the process/lock is alive.
        oauth_watcher: threading.Thread | None = None
        try:
            while True:
                manager_lock.heartbeat()
                # A maintenance request is honored only at this boundary,
                # after the preceding loop has fully returned and before any
                # OAuth health probe, queue claim, quota reservation, media
                # work or provider effect can begin.  Malformed requests also
                # close the barrier; maintenance must never fail open.
                from .maintenance_protocol import maintenance_barrier, recovery_window_state

                with _OAUTH_EFFECT_LOCK:
                    # A token may have been atomically refreshed by the normal
                    # health probe or the reconsent watcher in the preceding
                    # iteration.  Repin only its hash/path/expiry before the
                    # maintenance handshake; retain this process generation's
                    # boot-time source hashes.
                    try:
                        refresh_capability_token_binding(
                            root,
                            manager_pid=os.getpid(),
                            holder_started_at=str(manager_lock.acquired_at),
                        )
                    except Exception:
                        # The subsequent quiescence inspection fails closed on
                        # any invalid or stale token binding.  Normal OAuth
                        # health processing remains responsible for recovery.
                        pass
                    maintenance_requested = maintenance_barrier(
                        root, manager_pid=os.getpid()
                    )
                if maintenance_requested:
                    try:
                        recovery_state = recovery_window_state(
                            root, manager_pid=os.getpid()
                        )
                    except Exception:
                        recovery_state = None
                    if recovery_state is not None:
                        latest_cycle_path = (
                            root / "output/operations/phase6/control-cycle/latest.json"
                        )
                        latest_cycle = (
                            _read(latest_cycle_path) if latest_cycle_path.is_file() else {}
                        )
                        if latest_cycle.get("maintenance_window_id") != recovery_state["window_id"]:
                            from .phase6_control_cycle import (
                                materialize as materialize_phase6_control_cycle,
                            )

                            validation_started = datetime.now(timezone.utc)
                            materialize_phase6_control_cycle(
                                root,
                                cycle_started_at=validation_started,
                                cycle_completed_at=None,
                                maintenance_revalidation=True,
                                maintenance_window_id=str(recovery_state["window_id"]),
                            )
                    time.sleep(max(0.1, min(float(interval_seconds), 1.0)))
                    continue
                # Owner pause contains the whole operational loop, not only
                # run_cycle's Phase 5 return. Keep the maintenance handshake
                # above available, without starting OAuth or Phase 6 effects.
                if (runtime / "PAUSE").exists():
                    time.sleep(max(0.1, min(float(interval_seconds), 1.0)))
                    continue
                # The source grant can change after process boot.  Re-run the
                # finite watcher whenever its prior pass has ended so a new
                # official consent artifact is mirrored without waiting for a
                # manager restart. Each pass returns immediately when a new
                # source is absent, invalid or the durable grant is unchanged.
                # A live transaction owns the OAuth effect lock;
                # the ordinary health probe waits for the next loop instead of
                # racing it or causing a duplicate identity probe.
                if oauth_watcher is None or not oauth_watcher.is_alive():
                    oauth_watcher = _start_oauth_reconsent_watcher(root)
                if oauth_watcher is not None:
                    oauth_watcher.join(timeout=1.0)
                if oauth_watcher is not None and oauth_watcher.is_alive():
                    # Mirroring plus refresh is one credential transaction.
                    # No queue, media or provider executor may observe the
                    # intermediate token while that transaction is active.
                    manager_lock.heartbeat()
                    time.sleep(max(0.1, min(float(interval_seconds), 1.0)))
                    continue
                # A watcher already in flight may finish after owner pause.
                # Drain that transaction, but do not begin another health probe.
                if (runtime / "PAUSE").exists():
                    time.sleep(max(0.1, min(float(interval_seconds), 1.0)))
                    continue
                token_value = os.environ.get("HERO_YT_TOKEN_PATH")
                if oauth_watcher is None or not oauth_watcher.is_alive():
                    with _OAUTH_EFFECT_LOCK:
                        ensure_oauth_session_health(
                            root, Path(token_value) if token_value else None
                        )
                if package_relative is not None:
                    # Selected current audio never falls through into the
                    # legacy Phase 6 cinema queue, render or publication lane,
                    # including on an admission failure. Native readers reopen
                    # current policy/bytes on each bounded supervisor pass.
                    audio_cycle_started = datetime.now(timezone.utc)
                    current_status = run_cycle(root, package_relative=package_relative, current_bindings=current_bindings)
                    release_path = root / package_relative / 'release_gate.json'
                    observer_bindings = {k:v for k,v in current_bindings.items() if k != 'render_recovery'}
                    if current_status.get('publication_status') == 'COMPLETE_PUBLIC':
                        current_observation = run_phase6_observer_if_due(root, Path(token_value) if token_value else None,
                            package_relative=package_relative,current_bindings=observer_bindings,
                            expected_release_hash='sha256:'+hashlib.sha256(release_path.read_bytes()).hexdigest())
                        if current_observation.get('status') in ('COLLECTED', 'NOT_DUE'):
                            from .phase6_audio_production import run_current_audio_research_production
                            next_production = run_current_audio_research_production(root,
                                package_relative=package_relative,current_bindings=observer_bindings,
                                expected_release_hash='sha256:'+hashlib.sha256(release_path.read_bytes()).hexdigest(),
                                snapshot_reference=current_observation.get('latest_snapshot'))
                            _write(root/package_relative/'intelligence/next-production-status.json',next_production)
                    from .phase6_reporting import materialize as materialize_current_executive
                    materialize_current_executive(root, package_relative=package_relative,
                        current_bindings=observer_bindings,
                        expected_release_hash='sha256:'+hashlib.sha256(release_path.read_bytes()).hexdigest())
                    from .phase6_control_cycle import materialize as materialize_current_cycle
                    materialize_current_cycle(root, cycle_started_at=audio_cycle_started,
                        cycle_completed_at=None, package_relative=package_relative,
                        current_bindings=observer_bindings,
                        expected_release_hash='sha256:'+hashlib.sha256(release_path.read_bytes()).hexdigest())
                    from .phase6_acceptance import materialize as materialize_current_acceptance
                    materialize_current_acceptance(root, package_relative=package_relative,
                        current_bindings=observer_bindings,
                        expected_release_hash='sha256:'+hashlib.sha256(release_path.read_bytes()).hexdigest())
                    manager_lock.heartbeat()
                    time.sleep(max(10, interval_seconds))
                    continue
                prior_path = runtime / "fingerprint.json"
                prior_value = _read(prior_path) if prior_path.is_file() else {}
                prior = prior_value.get("input_fingerprint")
                current = input_fingerprint(root)
                phase5_status = None
                if (prior != current or prior_value.get("observation_fingerprint") != observation_fingerprint(root)
                        or (runtime / "PAUSE").exists() or _publication_retry_due(root)):
                    try:
                        phase5_status = run_cycle(root)
                    except Exception as exc:
                        status = {
                            "schema_version": "1.0.0", "manager_id": "gestor-central-heroverse-phase5-v1", "mode": "ERROR", "phase": 5,
                            "input_fingerprint": current, "cycle_status": "ERROR", "release_decision": "UNAVAILABLE", "publication_status": "ERROR",
                            "blockers": [f"{type(exc).__name__}:{exc}"], "technical_cost_brl": 0, "next_action": "Preserve evidence and retry only after an input change or supervised restart.", "updated_at": _now(),
                        }
                        _write(runtime / "status.json", status)
                else:
                    status_path = runtime / "status.json"
                    if status_path.is_file():
                        status = _read(status_path)
                        status["cycle_status"] = "UNCHANGED"
                        status["updated_at"] = _now()
                        Draft202012Validator(_read(root / "schemas/central_manager_runtime.schema.json")).validate(status)
                        _write(status_path, status)
                # Do not promote a paused Phase 5 attempt to a Phase 6 cycle,
                # even if the owner removes the marker before this boundary.
                # A fresh unpaused iteration must perform its own admission.
                if ((runtime / "PAUSE").exists()
                        or (phase5_status or {}).get("cycle_status") == "PAUSED"):
                    time.sleep(max(0.1, min(float(interval_seconds), 1.0)))
                    continue
                phase6_cycle_started = datetime.now(timezone.utc)
                try:
                    status_path = runtime / "status.json"
                    manager_status = _read(status_path) if status_path.is_file() else {}
                    if manager_status.get("publication_status") == "COMPLETE_PUBLIC":
                        run_phase6_observer_if_due(root, Path(token_value) if token_value else None)
                except Exception as exc:
                    _write(root / "output/operations/phase6/observer-status.json", {
                        "schema_version": "1.0.0", "observer_id": "heroverse-own-channel-observer-v1",
                        "phase": 6, "status": "ERROR", "video_id": "iK_5edYQtx8",
                        "latest_snapshot": None, "next_observation_at": None,
                        "error": f"{type(exc).__name__}: {exc}", "technical_cost_brl": 0, "updated_at": _now(),
                    })
                try:
                    from .phase6_prediction_runtime import run_prediction_observer

                    run_prediction_observer(
                        root,
                        token_path=Path(token_value) if token_value else None,
                        observed_usage=_quota_usage(root),
                    )
                except Exception as exc:
                    _write(root / "output/operations/phase6/intelligence/prediction-runtime.json", {
                        "schema_version": "1.1.0",
                        "observer_id": "heroverse-phase6-prediction-outcome-v1",
                        "phase": 6,
                        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                        "status": "ERROR",
                        "prediction_id": None,
                        "prediction_status": None,
                        "horizon_ends_at": None,
                        "next_observation_at": None,
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "outcome_snapshot": None,
                        "outcome_snapshot_hash": None,
                        "outcome_snapshot_schema": None,
                        "evaluation": None,
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    run_phase6_treatment_executor(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/production/executor-status.json", {
                        "schema_version": "1.0.0",
                        "executor_id": "heroverse-phase6-treatment-executor-v1",
                        "phase": 6,
                        "status": "ERROR",
                        "order_id": None,
                        "order_status": "UNAVAILABLE",
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "receipt": None,
                        "next_action": "Preserve evidence and retry without relaxing prerequisite gates.",
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_release import run_phase6_release_preparer

                    run_phase6_release_preparer(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/release/preparer-status.json", {
                        "schema_version": "1.0.0",
                        "executor_id": "heroverse-phase6-release-preparer-v1",
                        "phase": 6,
                        "status": "ERROR",
                        "work_order_id": None,
                        "work_order_status": "UNAVAILABLE",
                        "action": "WAIT",
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "receipt": None,
                        "next_action": "Preserve evidence and retry without relaxing post-preproduction gates.",
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_package_treatment import run_phase6_package_treatment_executor

                    run_phase6_package_treatment_executor(
                        root,
                        token_path=Path(token_value) if token_value else None,
                    )
                except Exception as exc:
                    _write(root / "output/operations/phase6/package-treatment-executor-status.json", {
                        "schema_version": "1.0.0",
                        "executor_id": "heroverse-phase6-package-treatment-executor-v1",
                        "phase": 6,
                        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                        "video_id": "iK_5edYQtx8",
                        "status": "ERROR",
                        "protocol_id": None,
                        "candidate": None,
                        "quality_evaluation": None,
                        "release_gate": None,
                        "publication_receipt": None,
                        "scheduled_for": None,
                        "next_action": "Preserve the public baseline and retry the exact preregistered package treatment without relaxing gates.",
                        "blockers": [],
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_media import run_phase6_media_executor

                    run_phase6_media_executor(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/media-executor-status.json", {
                        "schema_version": "1.1.0",
                        "executor_id": "heroverse-phase6-media-executor-v1",
                        "phase": 6,
                        "status": "ERROR",
                        "input_receipt_id": None,
                        "action": "WAIT",
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "voice_manifest": None,
                        "render_manifest": None,
                        "capacity_preflight_receipt": None,
                        "capacity_preflight_sha256": None,
                        "capacity_status": "UNAVAILABLE",
                        "capacity_observed_free_bytes": None,
                        "capacity_required_free_bytes": None,
                        "capacity_headroom_bytes": None,
                        "next_action": "Preserve evidence and retry without relaxing media or release gates.",
                        "error": f"{type(exc).__name__}: {exc}",
                        "publication_authorized": False,
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_quality import run_phase6_quality_executor

                    run_phase6_quality_executor(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/quality-executor-status.json", {
                        "schema_version": "1.0.0",
                        "executor_id": "heroverse-phase6-quality-executor-v1",
                        "phase": 6,
                        "status": "ERROR",
                        "media_render_id": None,
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "evaluation": None,
                        "decision": "BLOCKED",
                        "publication_eligible": False,
                        "next_action": "Preserve evidence and retry without relaxing any critical quality gate.",
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_publication import run_phase6_publication_controller

                    run_phase6_publication_controller(
                        root,
                        token_path=Path(token_value) if token_value else None,
                    )
                except Exception as exc:
                    _write(root / "output/operations/phase6/publication-controller-status.json", {
                        "schema_version": "1.0.0",
                        "controller_id": "heroverse-phase6-publication-controller-v1",
                        "phase": 6,
                        "status": "ERROR",
                        "quality_evaluation_id": None,
                        "package": None,
                        "release": None,
                        "release_decision": "BLOCKED",
                        "publication_receipt": None,
                        "youtube_video_id": None,
                        "privacy_status": "none",
                        "next_action": "Preserve any private-first receipt and retry without duplicate upload or gate relaxation.",
                        "blockers": [],
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "media_spend_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_learning_runtime import run_phase6_learning_observer

                    run_phase6_learning_observer(
                        root,
                        token_path=Path(token_value) if token_value else None,
                        observed_usage=_quota_usage(root),
                    )
                except Exception as exc:
                    _write(root / "output/operations/phase6/intelligence/learning-runtime.json", {
                        "schema_version": "1.0.0",
                        "observer_id": "heroverse-phase6-treatment-learning-v1",
                        "phase": 6,
                        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
                        "status": "ERROR",
                        "protocol_id": None,
                        "treatment_variable": None,
                        "target_video_id": None,
                        "publication_receipt": None,
                        "baseline_snapshot": None,
                        "latest_treatment_snapshot": None,
                        "scheduled_window_at": None,
                        "next_observation_at": None,
                        "job_id": None,
                        "job_state": "NOT_CREATED",
                        "evaluation": None,
                        "classification": None,
                        "next_action": "Preserve all evidence and retry the treatment observer without changing the preregistered protocol.",
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_channel_goal_observer import run_daily_channel_goal_observer

                    run_daily_channel_goal_observer(
                        root,
                        token_path=Path(token_value) if token_value else None,
                        observed_usage=_quota_usage(root),
                    )
                except Exception as exc:
                    from .phase6_channel_goal_observer import error_runtime as channel_goal_error_runtime

                    channel_goal_error_runtime(root, error=f"{type(exc).__name__}: {exc}")
                try:
                    from .phase6_goal_trajectory import materialize as materialize_phase6_goal_trajectory

                    materialize_phase6_goal_trajectory(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/goal-trajectory-error.json", {
                        "schema_version": "1.0.0", "phase": 6, "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}", "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_reporting import materialize as materialize_phase6_status

                    materialize_phase6_status(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/executive-status-error.json", {
                        "schema_version": "1.0.0", "phase": 6, "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}", "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_acceptance import materialize as materialize_phase6_acceptance

                    materialize_phase6_acceptance(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/acceptance-report-error.json", {
                        "schema_version": "1.0.0", "phase": 6, "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}", "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_transition import run_phase6_transition

                    run_phase6_transition(root)
                    # Acceptance and transition are evaluated after the first
                    # report build. Refresh the derived executive view in the
                    # same cycle so it never lags the authoritative gate.
                    from .phase6_reporting import materialize as refresh_phase6_status

                    refresh_phase6_status(root)
                except Exception as exc:
                    _write(root / "output/operations/phase6/phase-transition-runtime-error.json", {
                        "schema_version": "1.0.0", "phase": 6, "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}", "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                try:
                    from .phase6_control_cycle import materialize as materialize_phase6_control_cycle

                    materialize_phase6_control_cycle(
                        root,
                        cycle_started_at=phase6_cycle_started,
                        cycle_completed_at=datetime.now(timezone.utc),
                    )
                    # Publish the completed receipt in the executive view. The
                    # receipt has already frozen the twelve stages, so this
                    # observational refresh cannot retroactively approve them.
                    from .phase6_reporting import materialize as refresh_phase6_status_after_cycle

                    refresh_phase6_status_after_cycle(root)
                    # The transition consumed the preceding acceptance above.
                    # Now bind the observational acceptance to this completed
                    # cycle, after its executive projection is visible. Do not
                    # rerun transition or rewrite the frozen stage snapshots.
                    materialize_phase6_acceptance(root)
                    # Acceptance seals the exact completed executive bytes.
                    # A second timestamp-only rewrite would invalidate that
                    # evidence even though nothing operational had changed.
                except Exception as exc:
                    _write(root / "output/operations/phase6/control-cycle-error.json", {
                        "schema_version": "1.0.0",
                        "phase": 6,
                        "status": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}",
                        "technical_cost_brl": 0,
                        "updated_at": _now(),
                    })
                manager_lock.heartbeat()
                time.sleep(max(10, interval_seconds))
        finally:
            if pid_path.exists() and pid_path.read_text(encoding="utf-8").strip() == str(os.getpid()):
                pid_path.unlink()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Zero-cost Phase 5 central manager")
    parser.add_argument("--loop", action="store_true")
    parser.add_argument("--interval", type=int, default=60)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--package-relative', type=Path)
    parser.add_argument('--current-bindings', type=Path)
    parser.add_argument('--expected-bindings-hash')
    args = parser.parse_args(argv)
    root = args.root.resolve()
    bindings = None
    if args.package_relative is not None:
        if args.current_bindings is None or args.expected_bindings_hash is None:
            raise PermissionError('Manager audio selection requires an externally anchored bindings file')
        path = (root / args.current_bindings).resolve()
        if not path.is_relative_to(root):
            raise PermissionError('Manager bindings must belong to this root')
        raw = path.read_bytes()
        if args.expected_bindings_hash != 'sha256:' + hashlib.sha256(raw).hexdigest():
            raise PermissionError('Manager bindings external anchor differs')
        bindings = json.loads(raw.decode('utf-8-sig'))
    elif args.current_bindings is not None or args.expected_bindings_hash is not None:
        raise PermissionError('Manager bindings require an explicit package')
    selection = {'package_relative': args.package_relative, 'current_bindings': bindings} if bindings is not None else {}
    if args.loop:
        try:
            loop(root, args.interval, **selection)
        except ManagerAlreadyRunning as exc:
            print(json.dumps({"status": "BLOCKED_DUPLICATE_MANAGER", "reason": str(exc)}), file=sys.stderr)
            raise SystemExit(73)
    else:
        print(json.dumps(run_cycle(root, **selection), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
