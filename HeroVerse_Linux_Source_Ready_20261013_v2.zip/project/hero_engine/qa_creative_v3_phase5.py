from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .creative_v3_phase5 import TRANSITION_ASSET_ID
from .qa_creative_v2_phase5 import _asset_runtime, _pattern_interrupt_gap, _word_count
from .qa_phase5 import (
    FFMPEG,
    DEFECTS,
    GATES,
    _black_freeze_scan,
    _create_visual_evidence,
    _loudness,
    _originality_scan,
    _probe,
    _rights_scan,
    _sha256,
    _signal_scan,
    _timeline_scan,
    _run,
)


PACKAGE = Path("output/production/phase5/pilot-001")
V3 = PACKAGE / "creative-v3"

# This is an explicit project remediation threshold, not a claim about a
# universal market optimum. The rejected v2.1 baseline measured 77.2929%.
MAX_LANDSCAPE_DOMINANT_SHARE = 0.25
MAX_SINGLE_ASSET_RUNTIME_SHARE = 0.10
MAX_TOP_SIX_ASSET_RUNTIME_SHARE = 0.55
MAX_ASSET_REUSE_COUNT = 5
MAX_ROLLING_60S_SAME_ASSET_COUNT = 3
LANDSCAPE_ROLES = {
    "transition", "perspective", "decision", "progress", "tension",
    "release", "renewal", "clarity", "contemplation", "pressure",
}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _plain_hash(path: Path) -> str:
    return _sha256(path).removeprefix("sha256:")


def _fps(value: str) -> float:
    numerator, denominator = value.split("/", 1)
    return float(numerator) / float(denominator)


def _caption_scan(plan: dict[str, Any], render_manifest: dict[str, Any]) -> dict[str, Any]:
    record = render_manifest["captions"]
    path = Path(record["path"])
    text = path.read_text(encoding="utf-8-sig")
    cue_count = len(re.findall(r"(?m)^\d+\s*$", text))
    word_counts = [_word_count(str(take.get("narration") or "")) for take in plan["takes"]]
    return {
        "path": str(path.resolve()),
        "content_hash": _sha256(path),
        "manifest_hash_matches": _sha256(path) == record["content_hash"],
        "cue_count": cue_count,
        "expected_cue_count": len(plan["takes"]),
        "maximum_words_per_cue": max(word_counts),
        "coverage_ratio": float(record["coverage_ratio"]),
        "language": record["language"],
        "human_language_review": "PENDING",
        "passed": (
            _sha256(path) == record["content_hash"]
            and cue_count == len(plan["takes"])
            and max(word_counts) <= 12
            and math.isclose(float(record["coverage_ratio"]), 1.0)
        ),
    }


def _landscape_scan(plan: dict[str, Any], manifest: dict[str, Any], runtime: dict[str, Any]) -> dict[str, Any]:
    roles = {item["asset_id"]: item.get("semantic_role") for item in manifest["assets"]}
    matching = {
        asset_id: value
        for asset_id, value in runtime["by_asset"].items()
        if roles.get(asset_id) in LANDSCAPE_ROLES
    }
    total = sum(int(value["runtime_ms"]) for value in matching.values())
    duration = int(plan["takes"][-1]["end_ms"])
    return {
        "classification": "project-specific semantic-role classification",
        "roles": sorted(LANDSCAPE_ROLES),
        "assets": matching,
        "runtime_ms": total,
        "share": round(total / duration, 6),
        "threshold": MAX_LANDSCAPE_DOMINANT_SHARE,
        "rejected_v2_1_share": 0.772929,
        "delta_vs_v2_1": round(total / duration - 0.772929, 6),
        "passed": total / duration <= MAX_LANDSCAPE_DOMINANT_SHARE,
    }


def _visual_repetition_scan(plan: dict[str, Any], runtime: dict[str, Any]) -> dict[str, Any]:
    ranked = sorted(
        (
            {
                "asset_id": asset_id,
                "runtime_ms": int(value["runtime_ms"]),
                "share": float(value["share"]),
                "use_count": len(value["take_ids"]),
                "take_ids": list(value["take_ids"]),
            }
            for asset_id, value in runtime["by_asset"].items()
        ),
        key=lambda item: (-item["runtime_ms"], item["asset_id"]),
    )
    take_assets = [
        (
            re.search(r"asset-(?:commons|owned)-[a-z0-9-]+", take["asset_origin"]).group(0),
            int(take["start_ms"]),
            int(take["end_ms"]),
            take["take_id"],
        )
        for take in plan["takes"]
    ]
    rolling_max = 0
    rolling_evidence: dict[str, Any] | None = None
    for asset_id in runtime["by_asset"]:
        occurrences = [item for item in take_assets if item[0] == asset_id]
        for _, window_start, _, _ in occurrences:
            window_end = window_start + 60_000
            matching = [item for item in occurrences if window_start <= item[1] < window_end]
            if len(matching) > rolling_max:
                rolling_max = len(matching)
                rolling_evidence = {
                    "asset_id": asset_id,
                    "window_start_ms": window_start,
                    "window_end_ms": min(window_end, int(plan["takes"][-1]["end_ms"])),
                    "take_ids": [item[3] for item in matching],
                }
    maximum = ranked[0]
    top_six = ranked[:6]
    top_six_share = round(sum(item["share"] for item in top_six), 6)
    maximum_use_count = max(item["use_count"] for item in ranked)
    passed = (
        maximum["share"] <= MAX_SINGLE_ASSET_RUNTIME_SHARE
        and top_six_share <= MAX_TOP_SIX_ASSET_RUNTIME_SHARE
        and maximum_use_count <= MAX_ASSET_REUSE_COUNT
        and rolling_max <= MAX_ROLLING_60S_SAME_ASSET_COUNT
    )
    return {
        "classification": "project-specific anti-repetition guard; not a universal retention optimum",
        "thresholds": {
            "maximum_single_asset_runtime_share": MAX_SINGLE_ASSET_RUNTIME_SHARE,
            "maximum_top_six_runtime_share": MAX_TOP_SIX_ASSET_RUNTIME_SHARE,
            "maximum_asset_reuse_count": MAX_ASSET_REUSE_COUNT,
            "maximum_rolling_60s_same_asset_count": MAX_ROLLING_60S_SAME_ASSET_COUNT,
        },
        "maximum_single_asset": maximum,
        "top_six_assets": top_six,
        "top_six_runtime_share": top_six_share,
        "maximum_asset_reuse_count": maximum_use_count,
        "maximum_rolling_60s_same_asset_count": rolling_max,
        "rolling_60s_evidence": rolling_evidence,
        "sample_evidence": [
            "creative-v3/qa/supplemental-review/timeline-01.jpg",
            "creative-v3/qa/supplemental-review/timeline-02.jpg",
            "creative-v3/qa/supplemental-review/timeline-03.jpg"
        ],
        "passed": passed,
    }


def _create_supplemental_timeline(render: Path, directory: Path) -> list[str]:
    directory.mkdir(parents=True, exist_ok=True)
    for stale in directory.glob("timeline-*.jpg"):
        stale.unlink()
    duration = float(_probe(render)["format"]["duration"])
    pages = [
        (1, 0.0, min(100.0, duration), "5x5", 25),
        (2, 100.0, max(0.0, min(100.0, duration - 100.0)), "5x5", 25),
        (3, 200.0, max(0.0, duration - 200.0), "5x2", 10),
    ]
    created = []
    for number, start, span, layout, frame_count in pages:
        if span <= 0:
            continue
        destination = directory / f"timeline-{number:02d}.jpg"
        result = _run(
            [
                FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                "-ss", f"{start:.3f}", "-t", f"{span:.3f}", "-i", str(render),
                "-vf", f"fps=1/4,scale=384:216,tile={layout}:nb_frames={frame_count}:padding=4:margin=4:color=0x081827",
                "-frames:v", "1", "-q:v", "2", str(destination),
            ]
        )
        if result.returncode or not destination.is_file():
            raise RuntimeError(f"supplemental timeline page {number} was not produced")
        created.append(str(destination.resolve()))
    if len(created) != 3:
        raise RuntimeError(f"supplemental full-timeline evidence requires three pages, got {len(created)}")
    return created


def _record(name: str, passed: bool, threshold: Any, observed: Any, refs: list[str]) -> dict[str, Any]:
    return {
        "check": name,
        "status": "PASS" if passed else "FAIL",
        "threshold": threshold,
        "observed": observed,
        "evidence_refs": refs,
    }


def run_creative_v3_quality_gates(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    v3 = root / V3
    qa_dir = v3 / "qa"
    plan = _read(v3 / "take_plan.json")
    script = _read(v3 / "narrative_script.json")
    treatment = _read(v3 / "creative_treatment_plan.json")
    brief = _read(v3 / "editorial_brief.json")
    creative = _read(v3 / "creative_direction_decision.json")
    bible = _read(v3 / "channel_style_bible.json")
    manifest = _read(v3 / "asset_manifest.allocated.json")
    voice = _read(v3 / "audio" / "voice_render_manifest.json")
    render_manifest = _read(v3 / "render_manifest.json")
    thumbnails = _read(v3 / "thumbnail" / "thumbnail_set_manifest.json")
    format_pack = _read(root / "config" / "format_packs" / "fp-broll-cinematic-narration-v1.json")
    render = Path(render_manifest["output"]["path"])

    probe = _probe(render)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    fps = _fps(video["r_frame_rate"])
    duration_ms = round(float(probe["format"]["duration"]) * 1000)
    bitrate = int(probe["format"].get("bit_rate") or 0)
    loudness = _loudness(render)
    black_freeze = _black_freeze_scan(render)
    signal = _signal_scan(render, qa_dir / "signalstats.txt", plan, render_manifest)
    originality = _originality_scan(root, script)
    rights = _rights_scan(manifest, plan)
    timeline = _timeline_scan(plan, render_manifest, duration_ms)
    visual = _create_visual_evidence(render, qa_dir / "frames")
    _create_supplemental_timeline(render, qa_dir / "supplemental-review")
    captions = _caption_scan(plan, render_manifest)
    runtime = _asset_runtime(plan)
    landscape = _landscape_scan(plan, manifest, runtime)
    repetition = _visual_repetition_scan(plan, runtime)

    treatment_by_take = {item["take_id"]: item for item in treatment["takes"]}
    hook_ids = ["take-001", "take-002", "take-003"]
    hook_sources = {
        re.search(r"asset-(?:commons|owned)-[a-z0-9-]+", take["asset_origin"]).group(0)
        for take in plan["takes"][:3]
    }
    hook_events = sum(int(treatment_by_take[take_id]["visual_event_count"]) for take_id in hook_ids)
    body_events = sum(
        int(treatment_by_take[take["take_id"]]["visual_event_count"])
        for take in plan["takes"]
        if int(take["start_ms"]) < 30_000 and int(take["end_ms"]) > 8_000
    )
    max_body_take = max(int(item["end_ms"]) - int(item["start_ms"]) for item in plan["takes"][3:])
    interrupt_gap = _pattern_interrupt_gap(plan, treatment)
    ordered_assets = [re.search(r"asset-(?:commons|owned)-[a-z0-9-]+", item["asset_origin"]).group(0) for item in plan["takes"]]
    adjacent = [plan["takes"][index]["take_id"] for index in range(1, len(ordered_assets)) if ordered_assets[index] == ordered_assets[index - 1]]
    context_asset_used = any("asset-commons-fa53a5884174e4e27c" in take["asset_origin"] for take in plan["takes"])
    generic_cloud_used = any(TRANSITION_ASSET_ID in take["asset_origin"] for take in plan["takes"])
    hook_timing = voice["hook_timing_gate"] == "PASS" and all(bool(item["fits_timeline_slot"]) for item in voice["takes"][:3])
    technical_pass = (
        video["codec_name"] == "h264" and audio["codec_name"] == "aac"
        and int(video["width"]) == 1920 and int(video["height"]) == 1080
        and math.isclose(fps, 30.0, abs_tol=0.01)
        and timeline["absolute_duration_error_ms"] <= 150
        and timeline["frame_locked"]
        and timeline["maximum_cumulative_drift_ms"] <= (1000 / fps) / 2
        and black_freeze["maximum_black_seconds"] <= 0.20
        and black_freeze["maximum_freeze_seconds"] <= 0.75
    )
    audio_technical_pass = -18.0 <= loudness["integrated_lufs"] <= -14.0 and loudness["true_peak_dbtp"] <= -1.0
    flicker_pass = signal.get("status") == "MEASURED" and signal["within_take_luminance_delta_p95"] <= signal["flicker_threshold_p95"]
    discontinuous_cut_pass = signal.get("status") == "MEASURED" and signal["hard_transition_count"] == 0
    originality_pass = originality["comparison_count"] >= 4 and originality["maximum_target_trigram_overlap"] <= originality["threshold"]
    cost_pass = render_manifest["external_cost_usd"] == 0 and plan["total_cost"]["external"] == 0
    thumbnail_auto_pass = len(thumbnails["candidates"]) >= 3 and all(item["automated_status"] == "PASS" for item in thumbnails["candidates"])

    common_refs = ["creative-v3/take_plan.json", "creative-v3/creative_treatment_plan.json", "creative-v3/render_manifest.json"]
    checks = [
        _record("archetype_duration_ms", 207_750 <= duration_ms <= 286_250, [207_750, 286_250], duration_ms, common_refs),
        _record("hook_voice_timing", hook_timing, "all voice units fit 0-1/1-3/3-8", [item["duration_ms"] for item in voice["takes"][:3]], ["creative-v3/audio/voice_render_manifest.json"]),
        _record("distinct_visual_sources_0_8s", len(hook_sources) >= 3, 3, sorted(hook_sources), common_refs),
        _record("hook_visual_events_0_8s", hook_events >= 4, 4, hook_events, common_refs),
        _record("visual_events_8_30s", body_events >= 5, 5, body_events, common_refs),
        _record("maximum_body_take_ms", max_body_take <= 7000, 7000, max_body_take, common_refs),
        _record("maximum_pattern_interrupt_gap_ms", interrupt_gap <= 25000, 25000, interrupt_gap, common_refs),
        _record("unique_asset_count", runtime["unique_asset_count"] >= 15, 15, runtime["unique_asset_count"], common_refs),
        _record("maximum_single_asset_runtime_share", repetition["maximum_single_asset"]["share"] <= MAX_SINGLE_ASSET_RUNTIME_SHARE, MAX_SINGLE_ASSET_RUNTIME_SHARE, repetition["maximum_single_asset"], [*common_refs, *repetition["sample_evidence"]]),
        _record("top_six_asset_runtime_concentration", repetition["top_six_runtime_share"] <= MAX_TOP_SIX_ASSET_RUNTIME_SHARE, MAX_TOP_SIX_ASSET_RUNTIME_SHARE, {"share": repetition["top_six_runtime_share"], "assets": repetition["top_six_assets"]}, [*common_refs, *repetition["sample_evidence"]]),
        _record("maximum_asset_reuse_count", repetition["maximum_asset_reuse_count"] <= MAX_ASSET_REUSE_COUNT, MAX_ASSET_REUSE_COUNT, repetition["maximum_asset_reuse_count"], [*common_refs, *repetition["sample_evidence"]]),
        _record("maximum_rolling_60s_same_asset_count", repetition["maximum_rolling_60s_same_asset_count"] <= MAX_ROLLING_60S_SAME_ASSET_COUNT, MAX_ROLLING_60S_SAME_ASSET_COUNT, {"count": repetition["maximum_rolling_60s_same_asset_count"], "evidence": repetition["rolling_60s_evidence"]}, [*common_refs, *repetition["sample_evidence"]]),
        _record("maximum_third_party_asset_runtime_share", runtime["maximum_third_party_share"] <= 0.2, 0.2, runtime["maximum_third_party_share"], common_refs),
        _record("landscape_dominant_runtime_share", landscape["passed"], MAX_LANDSCAPE_DOMINANT_SHARE, landscape, ["creative-v3/qa/technical_measurements.json", "creative-v2/qa/market_readiness_review.json"]),
        _record("forbidden_generic_cloud_fallback", not generic_cloud_used, False, generic_cloud_used, common_refs),
        _record("rejected_context_asset_absent", not context_asset_used, False, context_asset_used, ["creative-v3/asset_manifest.allocated.json", "creative-v2/qa/market_readiness_review.json"]),
        _record("no_adjacent_asset_repeat", not adjacent, [], adjacent, common_refs),
        _record("caption_sidecar", captions["passed"], {"coverage": 1.0, "max_words": 12}, captions, ["creative-v3/captions/en-US.srt", "creative-v3/render_manifest.json"]),
        _record("thumbnail_challenger_set", thumbnail_auto_pass and thumbnails["selection_status"] == "BLOCKED_PENDING_INDEPENDENT_HUMAN_REVIEW", "three auto-pass challengers; no self-selected winner", {"count": len(thumbnails["candidates"]), "selection_status": thumbnails["selection_status"]}, ["creative-v3/thumbnail/thumbnail_set_manifest.json"]),
        _record("rights_hash_and_eligibility", rights["passed"], True, rights, ["creative-v3/asset_manifest.allocated.json", "creative-v3/attribution.txt"]),
        _record("render_treatment_traceability", render_manifest["creative_treatment_plan_id"] == treatment["treatment_plan_id"] and render_manifest["creative_treatment_version"] == treatment["version"], treatment["version"], render_manifest["creative_treatment_version"], common_refs),
        _record("external_production_cost_usd", cost_pass, 0, render_manifest["external_cost_usd"], common_refs),
    ]
    automatic_status = "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL"

    automatic_metrics = {
        "schema_version": "1.0.0",
        "revision": "creative-v3.2",
        "video_id": plan["video_id"],
        "checks": checks,
        "asset_runtime": runtime,
        "visual_repetition": repetition,
        "comparison": {
            "rejected_v2_1": {"duration_ms": 135200, "landscape_share": 0.772929, "caption_track_count": 0, "distinct_hook_sources": 1},
            "creative_v3_2": {"duration_ms": duration_ms, "landscape_share": landscape["share"], "caption_track_count": 1, "distinct_hook_sources": len(hook_sources), "take_count": len(plan["takes"]), "unique_asset_count": runtime["unique_asset_count"]},
            "deltas": {"duration_ms": duration_ms - 135200, "landscape_share": round(landscape["share"] - 0.772929, 6), "caption_track_count": 1, "distinct_hook_sources": len(hook_sources) - 1},
        },
        "automatic_status": automatic_status,
        "human_review_required": True,
        "publication_eligible": False,
        "created_at": timestamp,
    }
    Draft202012Validator(_read(root / "schemas" / "creative_revision_metrics.schema.json")).validate(automatic_metrics)

    gate_statuses: dict[str, tuple[str, list[str], list[str]]] = {
        "STRATEGY": ("PASS", ["Phase 4 archetype, Phase 5 command and project-specific remediation thresholds are linked"], ["output/modeling/phase4/channel-model-v1/channel_model.json", "creative-v3/policy_decision.json"]),
        "CHANNEL_DNA": ("PASS", ["decision and Style Bible reference the exact HeroVerse channel model"], ["creative-v3/creative_direction_decision.json", "creative-v3/channel_style_bible.json"]),
        "NARRATIVE": ("PASS", [f"original {_word_count(script['full_text'])}-word script supplies a named framework, contextual basis, safe boundaries and a concrete practice"], ["creative-v3/narrative_script.json", "creative-v3/editorial_brief.json"]),
        "HOOK": ("NEEDS_REVIEW" if hook_timing and len(hook_sources) >= 3 else "FAIL", [f"measured voice durations {[item['duration_ms'] for item in voice['takes'][:3]]} ms and {len(hook_sources)} distinct sources; perceived strength requires sequential human viewing"], ["creative-v3/audio/voice_render_manifest.json", *visual["hook_frames"][:4]]),
        "SEMANTIC_COHERENCE": ("NEEDS_REVIEW", [f"forbidden clouds fallback absent; landscape-dominant share measured {landscape['share']:.4%}; every take still requires human truthfulness review"], ["creative-v3/take_plan.json", visual["contact_sheet"]]),
        "STYLE": ("NEEDS_REVIEW" if repetition["passed"] else "FAIL", [f"locked palette and typography are consistent, but anti-repetition passed={repetition['passed']}; top-six share={repetition['top_six_runtime_share']:.4%}; maximum reuse={repetition['maximum_asset_reuse_count']}; rolling 60 s maximum={repetition['maximum_rolling_60s_same_asset_count']}"], ["creative-v3/channel_style_bible.json", visual["contact_sheet"], *repetition["sample_evidence"]]),
        "CONTINUITY": ("NEEDS_REVIEW" if discontinuous_cut_pass and not adjacent else "FAIL", [f"contiguous={timeline['contiguous']}; adjacent source repeats={len(adjacent)}; unplanned within-take hard transitions={signal.get('hard_transition_count')}; planned cuts still require human motivation review"], ["creative-v3/take_plan.json", "creative-v3/qa/technical_measurements.json", visual["contact_sheet"]]),
        "CHARACTERS": ("NOT_APPLICABLE", ["no recurring speaking character is specified"], ["creative-v3/channel_style_bible.json"]),
        "MOVEMENT": ("NEEDS_REVIEW", ["freeze and flicker automation ran; physical plausibility and intentional motion require full-motion human review"], ["creative-v3/qa/technical_measurements.json", visual["contact_sheet"]]),
        "LEGIBILITY": ("NEEDS_REVIEW", [f"caption coverage={captions['coverage_ratio']}; maximum cue words={captions['maximum_words_per_cue']}; typography and safe areas require device-level human review"], ["creative-v3/captions/en-US.srt", visual["contact_sheet"]]),
        "AUDIO": ("NEEDS_REVIEW" if audio_technical_pass else "FAIL", [f"measured {loudness['integrated_lufs']} LUFS and {loudness['true_peak_dbtp']} dBTP; pronunciation, prosody, emotion and mix require listening review"], ["creative-v3/qa/technical_measurements.json", "creative-v3/audio/creative_audio_manifest.json"]),
        "TECHNICAL": ("PASS" if technical_pass else "FAIL", [f"{video['codec_name']}/{audio['codec_name']} {video['width']}x{video['height']} {fps:.3f}fps; duration error {timeline['absolute_duration_error_ms']} ms; drift {timeline['maximum_cumulative_drift_ms']} ms"], ["creative-v3/render_manifest.json", "creative-v3/qa/technical_measurements.json"]),
        "RIGHTS": ("PASS" if rights["passed"] and not context_asset_used else "FAIL", [f"{len(rights['verified_asset_ids'])} used assets matched hashes and eligible rights states; rejected context asset used={context_asset_used}"], ["creative-v3/asset_manifest.allocated.json", "creative-v3/attribution.txt"]),
        "PUBLICITY": ("NEEDS_REVIEW", ["faceless/original still strategy lowers exposure but automatic analysis cannot establish every property or likeness release"], [visual["contact_sheet"], "creative-v3/asset_manifest.allocated.json"]),
        "EDITORIAL_ORIGINALITY": ("PASS" if originality_pass else "FAIL", [f"maximum target trigram overlap={originality['maximum_target_trigram_overlap']} across {originality['comparison_count']} reviewed transcripts"], ["creative-v3/narrative_script.json", "creative-v3/qa/technical_measurements.json"]),
        "CHANNEL_IDENTITY": ("NEEDS_REVIEW", ["HeroVerse palette, framework and visual motif are versioned; distinctness from market references requires independent judgment"], ["creative-v3/channel_style_bible.json", visual["contact_sheet"]]),
        "COST": ("PASS" if cost_pass else "FAIL", ["external production cost recorded as USD 0; local energy, labor, storage and depreciation remain unavailable"], ["creative-v3/render_manifest.json", "creative-v3/take_plan.json"]),
        "PUBLICATION": ("BLOCKED", [f"automatic status={automatic_status}; independent gold-standard review, thumbnail selection, FormatPack promotion and durable OAuth remain pending"], ["creative-v3/qa/creative_revision_metrics.json", "config/format_packs/fp-broll-cinematic-narration-v1.json", "output/integrations/youtube/heroverse/operational-readiness.json"]),
    }
    gates = [{
        "gate": gate,
        "status": gate_statuses[gate][0],
        "critical": gate != "CHARACTERS",
        "checks": gate_statuses[gate][1],
        "evidence_refs": gate_statuses[gate][2],
        "reviewer": "phase5-v3.1-automatic-qa" if gate_statuses[gate][0] in {"PASS", "FAIL"} else None,
    } for gate in GATES]

    defect_map: dict[str, tuple[str, str, Any, Any]] = {
        "FLICKER": ("PASS" if flicker_pass else "FAIL", "2 fps boundary-aware signalstats", signal.get("flicker_threshold_p95"), signal.get("within_take_luminance_delta_p95")),
        "OBJECT_DEFORMATION": ("NEEDS_REVIEW", "independent full-motion visual review", "no deformation", None),
        "FACE_VARIATION": ("NEEDS_REVIEW", "faceless scenes can include non-identifiable partial/background people", "no unstable face", None),
        "HAND_DEFECT": ("NEEDS_REVIEW", "generated action-insert frame review", "valid hands", None),
        "CHARACTER_IDENTITY_DRIFT": ("NOT_APPLICABLE", "no recurring character", "zero drift", "no recurring character"),
        "BACKGROUND_PULSING": ("NEEDS_REVIEW", "signalstats and full-motion review", "no pulsing", signal),
        "IMPOSSIBLE_MOTION": ("NEEDS_REVIEW", "independent full-motion review", "coherent motion", None),
        "UNINTENDED_CAMERA_INSTABILITY": ("NEEDS_REVIEW", "independent full-motion review", "no unintended shake", None),
        "INCOHERENT_PHYSICS": ("NEEDS_REVIEW", "independent full-motion review", "coherent physics", None),
        "DISCONTINUOUS_CUT": ("PASS" if discontinuous_cut_pass else "FAIL", "boundary-aware signalstats", 0, signal.get("hard_transition_count")),
        "LIP_SYNC_ERROR": ("NOT_APPLICABLE", "no visible speaking presenter", "synchronized", "no visible speaker"),
        "DUPLICATE_FRAMES": ("PASS" if black_freeze["maximum_freeze_seconds"] <= 0.75 else "FAIL", "FFmpeg freezedetect", 0.75, black_freeze["maximum_freeze_seconds"]),
        "GHOSTING": ("NEEDS_REVIEW", "independent frame and motion review", "no ghosting", None),
        "ARTIFICIAL_INTERPOLATION": ("PASS", "renderer fingerprint and filters", "no optical-flow interpolation", "fps normalization/zoompan only"),
        "INCONSISTENT_RESOLUTION": ("PASS" if int(video["width"]) == 1920 and int(video["height"]) == 1080 else "FAIL", "ffprobe", "1920x1080", [video["width"], video["height"]]),
        "COMPRESSION_ARTIFACT": ("NEEDS_REVIEW", "bitrate plus independent frame review", ">=2500 kbps and no visible damage", round(bitrate / 1000, 3)),
        "STYLE_DRIFT": ("NEEDS_REVIEW", "contact sheet against Style Bible", "no involuntary drift", signal),
        "AUDIO_CLIPPING": ("PASS" if loudness["true_peak_dbtp"] <= -1.0 else "FAIL", "FFmpeg loudnorm", "<=-1.0 dBTP", loudness["true_peak_dbtp"]),
        "LOUDNESS_OUT_OF_RANGE": ("PASS" if -18 <= loudness["integrated_lufs"] <= -14 else "FAIL", "FFmpeg loudnorm", "-16 LUFS +/-2", loudness["integrated_lufs"]),
    }
    defects = [{"defect": defect, "status": defect_map[defect][0], "method": defect_map[defect][1], "evidence_refs": ["creative-v3/qa/technical_measurements.json", visual["contact_sheet"]], "threshold": defect_map[defect][2], "observed": defect_map[defect][3]} for defect in DEFECTS]
    critical_failures = [item["gate"] for item in gates if item["critical"] and item["status"] in {"FAIL", "BLOCKED"}]
    report = {
        "schema_version": "1.0.0",
        "report_id": "creative-qa-v3-" + hashlib.sha256(f"{render_manifest['render_id']}|{timestamp}".encode()).hexdigest()[:20],
        "video_id": plan["video_id"], "channel_id": plan["channel_id"],
        "format_pack_id": plan["format_pack_id"], "format_pack_version": plan["format_pack_version"],
        "pipeline_version": render_manifest["pipeline_version"], "quality_profile": plan["quality_profile"],
        "gates": gates, "defect_evaluations": defects,
        "automatic_evaluator_versions": ["ffprobe@runtime", "ffmpeg-black-freeze@runtime", "ffmpeg-signalstats-boundary-aware@1.1.0", "hero-originality-trigram@1.0.0", "hero-rights-hash@1.0.0", "hero-landscape-role-classifier@1.0.0", "hero-visual-repetition-guard@1.0.0", "hero-caption-sidecar@1.0.0"],
        "human_review": {"required": True, "status": "PENDING", "reviewer_id": None, "evidence_ref": None, "independent_from_generator": False},
        "critical_gate_failures": critical_failures, "publication_eligible": False, "created_at": timestamp,
    }
    Draft202012Validator(_read(root / "schemas" / "creative_quality_gate_report.schema.json")).validate(report)

    measurements = {
        "schema_version": "1.0.0", "render_path": str(render.resolve()), "render_hash": _sha256(render),
        "probe": probe, "loudness": loudness, "black_freeze": black_freeze, "signalstats": signal,
        "originality": originality, "rights": rights, "timeline": timeline, "captions": captions,
        "asset_runtime": runtime, "landscape": landscape, "visual_repetition": repetition,
        "hook": {"timing_status": "PASS" if hook_timing else "FAIL", "voice_durations_ms": [item["duration_ms"] for item in voice["takes"][:3]], "distinct_sources": sorted(hook_sources), "visual_event_count": hook_events},
        "visual_evidence": visual, "brief_id": brief["brief_id"], "creative_decision_id": creative["decision_id"], "style_bible_id": bible["style_bible_id"],
    }

    preferred_thumbnail = next(item for item in thumbnails["candidates"] if item["candidate_id"] == thumbnails["automatic_recommendation"])
    market_gates = [
        {"gate": "AUTOMATIC_REMEDIATION_CONTRACT", "status": automatic_status, "critical": True, "observation": f"{sum(item['status'] == 'PASS' for item in checks)}/{len(checks)} automatic remediation checks passed.", "evidence": ["creative-v3/qa/creative_revision_metrics.json"], "required_correction": "Correct every failed automatic check before human review; preserve the evidence when all pass."},
        {"gate": "HOOK_PERCEPTUAL", "status": "NEEDS_REVIEW", "critical": True, "observation": "Timing, source count and event density pass automatically; irresistible clarity and emotional authority cannot be inferred from counters.", "evidence": [*visual["hook_frames"][:4], "creative-v3/audio/voice_render_manifest.json"], "required_correction": "Complete an independent sequential 0-30 second review with timecoded defects and corrections."},
        {"gate": "VISUAL_SEMANTIC_DENSITY", "status": "NEEDS_REVIEW" if landscape["passed"] and not generic_cloud_used and repetition["passed"] else "FAIL", "critical": True, "observation": f"Landscape-dominant runtime={landscape['share']:.4%}; generic clouds fallback used={generic_cloud_used}; top-six asset concentration={repetition['top_six_runtime_share']:.4%}; maximum asset reuse={repetition['maximum_asset_reuse_count']}; rolling 60 s maximum={repetition['maximum_rolling_60s_same_asset_count']}.", "evidence": ["creative-v3/qa/technical_measurements.json", visual["contact_sheet"], *repetition["sample_evidence"]], "required_correction": "Replace repeated motifs until all anti-repetition thresholds pass, then repeat the contact-sheet and full-motion review."},
        {"gate": "THUMBNAIL_SELECTION", "status": "NEEDS_REVIEW", "critical": True, "observation": "Three mechanically valid challengers exist and B is an automatic hypothesis only; no winner has been self-declared.", "evidence": ["creative-v3/thumbnail/thumbnail_set_manifest.json"], "required_correction": "Run blinded independent human review and record the selected candidate before upload."},
        {"gate": "FORMAT_CAPABILITY", "status": "BLOCKED", "critical": True, "observation": f"FormatPack remains {format_pack['capability_status']} with production_allowed={format_pack['production_allowed']}.", "evidence": ["config/format_packs/fp-broll-cinematic-narration-v1.json", "creative-v3/qa/creative_quality_gate_report.json"], "required_correction": "Promote only after representative automatic tests and independent human gold-standard review pass."},
        {"gate": "PUBLICATION", "status": "BLOCKED", "critical": True, "observation": "Automatic QA does not replace the independent gold-standard review, thumbnail choice or durable integration gate.", "evidence": ["creative-v3/qa/creative_quality_gate_report.json", "output/integrations/youtube/heroverse/operational-readiness.json"], "required_correction": "Satisfy all remaining protected gates; do not upload or publish early."},
    ]
    market_review = {
        "schema_version": "1.0.0", "review_id": "market-readiness-v3-" + hashlib.sha256(f"{render_manifest['render_id']}|{timestamp}".encode()).hexdigest()[:20],
        "video_id": plan["video_id"], "reviewer_class": "INTERNAL_NON_HUMAN_CRITICAL_AUDIT", "independent_human_review_satisfied": False,
        "evaluated_render": {"path": str(render.resolve()), "sha256": _plain_hash(render), "duration_ms": duration_ms, "thumbnail_path": preferred_thumbnail["path"], "thumbnail_sha256": preferred_thumbnail["content_hash"].removeprefix("sha256:")},
        "verdict": "READY_FOR_INDEPENDENT_HUMAN_REVIEW" if automatic_status == "PASS" and technical_pass and audio_technical_pass else "REJECTED_FOR_PUBLICATION",
        "claim_boundary": {"viral_result": "UNAVAILABLE_BEFORE_PUBLICATION", "market_leadership": "NOT_DEMONSTRATED", "ctr": "UNAVAILABLE", "retention": "UNAVAILABLE", "rpm": "UNAVAILABLE"},
        "measurements": {"archetype_duration_min_ms": 207750, "archetype_duration_max_ms": 286250, "duration_shortfall_ms": max(0, 207750 - duration_ms), "duration_shortfall_ratio": round(max(0, 207750 - duration_ms) / 207750, 6), "landscape_dominant_runtime_ms": landscape["runtime_ms"], "landscape_dominant_runtime_ratio": landscape["share"], "caption_track_count": 1, "distinct_visual_sources_0_8s": len(hook_sources), "format_pack_status": format_pack["capability_status"], "production_allowed": bool(format_pack["production_allowed"])},
        "gates": market_gates,
        "strengths": [f"Frame-locked 1080p30 render with {timeline['maximum_cumulative_drift_ms']} ms measured cumulative drift.", f"Landscape-dominant share reduced by {abs(landscape['delta_vs_v2_1']):.4%} versus the rejected v2.1 baseline.", f"Three distinct hook sources, {captions['cue_count']} caption cues and {runtime['unique_asset_count']} total visual sources are packaged.", f"Maximum single third-party runtime share is {runtime['maximum_third_party_share']:.4%}; all used asset hashes and eligibility records passed."],
        "required_next_action": "Complete independent full-video visual/audio/caption review and blinded thumbnail selection; correct every timecoded defect, re-run automatic QA, then evaluate FormatPack promotion and publication prerequisites.",
        "created_at": timestamp,
    }
    Draft202012Validator(_read(root / "schemas" / "market_readiness_review.schema.json")).validate(market_review)

    _write(qa_dir / "technical_measurements.json", measurements)
    _write(qa_dir / "creative_revision_metrics.json", automatic_metrics)
    _write(qa_dir / "creative_quality_gate_report.json", report)
    _write(qa_dir / "market_readiness_review.json", market_review)
    return {"report": report, "measurements": measurements, "metrics": automatic_metrics, "market_review": market_review}


if __name__ == "__main__":
    result = run_creative_v3_quality_gates(Path.cwd())
    print(json.dumps({"automatic_status": result["metrics"]["automatic_status"], "verdict": result["market_review"]["verdict"], "critical_gate_failures": result["report"]["critical_gate_failures"]}, indent=2))
