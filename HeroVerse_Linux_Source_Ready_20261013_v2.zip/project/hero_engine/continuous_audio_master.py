"""Continuous loudnorm recipe and measurable checks, never release authority."""
from __future__ import annotations
import array
import io
import json
import math
from pathlib import Path
import re
import sys
import wave

VERSION = "continuous-loudnorm-v1"


def parse_loudnorm(stderr: str) -> dict[str, float]:
    matches = re.findall(r'\{\s*"input_i".*?\}', stderr, re.S)
    if len(matches) != 1:
        raise ValueError("one complete loudnorm measurement required")
    payload = json.loads(matches[0])
    fields = ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")
    result = {key: float(payload[key]) for key in fields}
    if not all(math.isfinite(v) for v in result.values()):
        raise ValueError("nonfinite loudnorm measurement")
    if not (-99 <= result["input_i"] <= 0 and -99 <= result["input_tp"] <= 99
            and 0 <= result["input_lra"] <= 99 and -99 <= result["input_thresh"] <= 0
            and -99 <= result["target_offset"] <= 99):
        raise ValueError("measurement outside filter limits")
    return result


def normalization_command(ffmpeg: str, source: Path, output: Path, measured: dict) -> list[str]:
    if source.resolve() == output.resolve():
        raise ValueError("normalization cannot overwrite source")
    # Parse again: no unvalidated string may enter a filter expression.
    values = parse_loudnorm(json.dumps(measured))
    chain = "loudnorm=I=-16:TP=-1.5:LRA=8"
    for option, key in (("measured_I", "input_i"), ("measured_TP", "input_tp"),
                        ("measured_LRA", "input_lra"), ("measured_thresh", "input_thresh"),
                        ("offset", "target_offset")):
        chain += f":{option}={values[key]:.8f}"
    chain += ":linear=false:print_format=json"
    return [ffmpeg, "-n", "-nostdin", "-hide_banner", "-nostats", "-threads", "1",
            "-i", str(source), "-map", "0:a:0", "-vn", "-filter_threads", "1",
            "-af", chain, "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(output)]


def exact_source_duration(raw: bytes, source_frames: int) -> tuple[bytes, dict]:
    """Remove only an observed all-zero filter tail, never speech or padding input."""
    if type(source_frames) is not int or source_frames <= 0:
        raise ValueError("positive exact source sample count required")
    with wave.open(io.BytesIO(raw), "rb") as f:
        if (f.getnchannels(), f.getsampwidth(), f.getframerate(), f.getcomptype()) != (1, 2, 24000, "NONE"):
            raise ValueError("mono24kPCM16 required")
        frames = f.getnframes()
        pcm = f.readframes(frames)
    extra = frames - source_frames
    if len(pcm) != frames * 2 or not 0 <= extra <= 2400:
        raise ValueError("missing samples or excessive filter tail")
    if any(pcm[source_frames * 2:]):
        raise ValueError("nonzero tail cannot be removed")
    if not extra:
        return raw, {"removed_zero_samples": 0, "retained_samples": frames}
    result = io.BytesIO()
    with wave.open(result, "wb") as f:
        f.setparams((1, 2, 24000, source_frames, "NONE", "not compressed"))
        f.writeframes(pcm[:source_frames * 2])
    return result.getvalue(), {"removed_zero_samples": extra, "retained_samples": source_frames}


def assess(raw: bytes, levels: dict, expected_frames: int, profile: dict) -> dict:
    with wave.open(io.BytesIO(raw), "rb") as f:
        fmt = (f.getnchannels(), f.getsampwidth(), f.getframerate(), f.getcomptype())
        frames = f.getnframes()
        pcm = f.readframes(frames)
    if fmt != (1, 2, 24000, "NONE") or len(pcm) != frames * 2:
        raise ValueError("unexpected normalized PCM format")
    samples = array.array("h", pcm)
    if sys.byteorder != "little": samples.byteswap()
    clipping = sum(v in (-32768, 32767) for v in samples)
    i, tp = levels["input_i"], levels["input_tp"]
    if not all(type(v) in (int, float) and math.isfinite(v) for v in (i, tp)):
        raise ValueError("nonfinite quality measurement")
    limits = profile["technical_minimums"]
    loud = limits["loudness_lufs"]
    checks = {"exact_sample_count": frames == expected_frames,
              "no_pcm_extremes": clipping == 0,
              "integrated_loudness": abs(i - loud["target"]) <= loud["tolerance"],
              "true_peak": tp <= limits["true_peak_dbtp"]}
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
            "frames": frames, "clipping_samples": clipping,
            "scope": "DURATION_LEVELS_PCM_EXTREMES_ONLY_NOT_PERCEPTUAL_OR_RELEASE_QA"}
