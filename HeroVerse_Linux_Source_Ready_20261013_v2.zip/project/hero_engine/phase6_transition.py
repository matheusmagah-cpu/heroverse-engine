from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .atomic_io import atomic_write_utf8
from .phase6_control_cycle import stage_identity_hash


ROOT = Path(__file__).resolve().parents[1]
BASE = Path("output/operations/phase6")
ACCEPTANCE = BASE / "acceptance-report.json"
RUNTIME = BASE / "phase-transition-runtime.json"
RECEIPT = BASE / "phase6-to-phase7-transition-receipt.json"
CONTROLLER_ID = "heroverse-phase6-to-phase7-transition-v1"
CONTROL_CYCLE_LATEST = BASE / "control-cycle/latest.json"
CONTROL_CYCLE_HISTORY = BASE / "control-cycle/history"
LEARNING_RUNTIME = BASE / "intelligence/learning-runtime.json"
GOAL_TRAJECTORY_RUNTIME = BASE / "goal-trajectory/current.json"


def _stamp(value: str | None = None) -> str:
    return value or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _atomic_write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _write_runtime_view(path: Path, value: dict[str, Any]) -> None:
    atomic_write_utf8(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _archive_stale_external_error(root: Path) -> None:
    stale = root / "output/operations/phase6/phase-transition-runtime-error.json"
    if not stale.is_file():
        return
    payload = stale.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    archive = root / "output/operations/phase6/errors/archive" / (
        f"phase-transition-runtime-error-{digest[:16]}.json"
    )
    archive.parent.mkdir(parents=True, exist_ok=True)
    if archive.is_file():
        if archive.read_bytes() != payload:
            raise RuntimeError("phase-transition stale error archive collision")
        stale.unlink()
    else:
        os.replace(stale, archive)


def _runtime(
    *,
    status: str,
    updated_at: str,
    report_id: str | None,
    report_hash: str | None,
    blockers: list[str],
    receipt: str | None,
    next_action: str,
    error: str | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "controller_id": CONTROLLER_ID,
        "from_phase": 6,
        "to_phase": 7,
        "status": status,
        "acceptance_report_id": report_id,
        "acceptance_sha256": report_hash,
        "blocking_check_ids": blockers,
        "transition_receipt": receipt,
        "next_action": next_action,
        "error": error,
        "technical_cost_brl": 0,
        "updated_at": updated_at,
    }


def _logical_gate_errors(report: dict[str, Any]) -> tuple[list[str], list[str], list[str]]:
    errors: list[str] = []
    checks = report.get("checks") or []
    observed_ids = [item.get("check_id") for item in checks]
    expected_ids = [f"GC-{number:02d}" for number in range(1, 23)]
    if observed_ids != expected_ids:
        errors.append("CHECK_SET_OR_ORDER_INVALID")

    required = [item for item in checks if item.get("required_for_phase6") is True]
    required_ids = [item["check_id"] for item in required]
    satisfied_ids: list[str] = []
    computed_blockers: list[str] = []
    for item in required:
        if item.get("minimum_evidence") == "LIVE":
            sufficient = item.get("status") == "PASS_LIVE"
        elif item.get("minimum_evidence") == "FIXTURE":
            sufficient = item.get("status") in {"PASS_FIXTURE", "PASS_LIVE"}
        else:
            sufficient = False
            errors.append(f"REQUIRED_CHECK_HAS_INVALID_MINIMUM:{item['check_id']}")
        (satisfied_ids if sufficient else computed_blockers).append(item["check_id"])

    declared_blockers = report.get("blocking_check_ids") or []
    if declared_blockers != computed_blockers:
        errors.append("DECLARED_BLOCKERS_DIVERGE_FROM_CHECKS")
    declared_passing = set(report.get("passing_check_ids") or [])
    actual_passing = {
        item["check_id"] for item in checks
        if item.get("status") in {"PASS_FIXTURE", "PASS_LIVE"}
    }
    if declared_passing != actual_passing:
        errors.append("DECLARED_PASSING_CHECKS_DIVERGE_FROM_CHECKS")

    counted = {
        name: sum(1 for item in checks if item.get("status") == name)
        for name in (
            "PASS_FIXTURE", "PASS_LIVE", "WAITING_REAL_EVIDENCE",
            "MISSING_EVIDENCE", "FAIL", "NOT_APPLICABLE_CURRENT_PHASE",
        )
    }
    if report.get("counts") != counted:
        errors.append("DECLARED_COUNTS_DIVERGE_FROM_CHECKS")
    return errors, required_ids, satisfied_ids


def _control_cycle_binding(
    root: Path,
    report: dict[str, Any],
) -> tuple[list[str], dict[str, Any] | None]:
    """Require a prior material cycle that froze the state being promoted.

    The transition stage runs before the current cycle receipt is written. A
    changed learning/acceptance state therefore waits one manager iteration;
    the next iteration can bind the immutable STATE_CHANGED history receipt.
    """
    latest_path = root / CONTROL_CYCLE_LATEST
    if not latest_path.is_file():
        return ["CONTROL_CYCLE_MISSING"], None
    try:
        latest_bytes = latest_path.read_bytes()
        cycle = json.loads(latest_bytes.decode("utf-8-sig"))
        _validate(root, "phase6_control_cycle_receipt.schema.json", cycle)
    except Exception as exc:
        return [f"CONTROL_CYCLE_INVALID:{type(exc).__name__}"], None

    errors: list[str] = []
    if cycle.get("decision") not in {"PASS_WAITING", "PASS_ADVANCED"}:
        errors.append("CONTROL_CYCLE_NOT_PASSING")
    if cycle.get("all_schemas_valid") is not True:
        errors.append("CONTROL_CYCLE_SCHEMA_SET_NOT_VALID")
    if cycle.get("all_stages_executed_in_cycle") is not True:
        errors.append("CONTROL_CYCLE_NOT_INTEGRAL")
    if cycle.get("blockers"):
        errors.append("CONTROL_CYCLE_HAS_BLOCKERS")
    if cycle.get("change_class") not in {"INITIAL", "STATE_CHANGED"} or cycle.get("history_archived") is not True:
        errors.append("CONTROL_CYCLE_NOT_MATERIAL")

    stage_records = cycle.get("stages") or []
    by_stage = {item.get("stage"): item for item in stage_records}
    if cycle.get("schema_version") != "1.1.0" or len(by_stage) != 12 or "GOAL_TRAJECTORY" not in by_stage:
        errors.append("CONTROL_CYCLE_STAGE_SET_INVALID")

    history_relative = CONTROL_CYCLE_HISTORY / f"{cycle.get('cycle_id')}.json"
    history_path = root / history_relative
    if not history_path.is_file():
        errors.append("CONTROL_CYCLE_HISTORY_MISSING")
    elif history_path.read_bytes() != latest_bytes:
        errors.append("CONTROL_CYCLE_HISTORY_DIVERGES")

    learning_path = root / LEARNING_RUNTIME
    goal_trajectory_path = root / GOAL_TRAJECTORY_RUNTIME
    if not goal_trajectory_path.is_file():
        goal_trajectory_path = root / BASE / "goal-trajectory/latest.json"
    transition_path = root / RUNTIME
    if not learning_path.is_file():
        errors.append("CONTROL_CYCLE_LEARNING_SOURCE_MISSING")
    else:
        learning = _read(learning_path)
        if (by_stage.get("LEARNING") or {}).get("identity_hash") != stage_identity_hash("LEARNING", learning):
            errors.append("CONTROL_CYCLE_LEARNING_NOT_RECONCILED")
    if not goal_trajectory_path.is_file():
        errors.append("CONTROL_CYCLE_GOAL_TRAJECTORY_SOURCE_MISSING")
    else:
        goal_trajectory = _read(goal_trajectory_path)
        _validate(root, "phase6_goal_trajectory.schema.json", goal_trajectory)
        if (by_stage.get("GOAL_TRAJECTORY") or {}).get("identity_hash") != stage_identity_hash("GOAL_TRAJECTORY", goal_trajectory):
            errors.append("CONTROL_CYCLE_GOAL_TRAJECTORY_NOT_RECONCILED")
    if not transition_path.is_file():
        errors.append("CONTROL_CYCLE_TRANSITION_SOURCE_MISSING")
    else:
        transition = _read(transition_path)
        if (by_stage.get("PHASE_TRANSITION") or {}).get("identity_hash") != stage_identity_hash("PHASE_TRANSITION", transition):
            errors.append("CONTROL_CYCLE_TRANSITION_NOT_RECONCILED")
        if transition.get("acceptance_report_id") != report.get("report_id"):
            errors.append("CONTROL_CYCLE_ACCEPTANCE_NOT_RECONCILED")

    if errors:
        return sorted(set(errors)), None
    return [], {
        "cycle_id": cycle["cycle_id"],
        "immutable_snapshot_path": history_relative.as_posix(),
        "sha256": _sha256_bytes(latest_bytes),
        "substantive_signature": cycle["substantive_signature"],
        "learning_identity_hash": by_stage["LEARNING"]["identity_hash"],
        "goal_trajectory_identity_hash": by_stage["GOAL_TRAJECTORY"]["identity_hash"],
        "phase_transition_identity_hash": by_stage["PHASE_TRANSITION"]["identity_hash"],
    }


def _use_existing_receipt(root: Path, *, updated_at: str) -> dict[str, Any] | None:
    receipt_path = root / RECEIPT
    if not receipt_path.is_file():
        return None
    receipt = _read(receipt_path)
    _validate(root, "phase6_to_phase7_transition_receipt.schema.json", receipt)
    acceptance = receipt["acceptance"]
    snapshot_path = root / acceptance["immutable_snapshot_path"]
    if not snapshot_path.is_file():
        raise RuntimeError("immutable acceptance snapshot referenced by transition receipt is missing")
    if _sha256_bytes(snapshot_path.read_bytes()) != acceptance["sha256"]:
        raise RuntimeError("immutable acceptance snapshot hash no longer matches transition receipt")
    control = receipt["control_cycle"]
    control_path = root / control["immutable_snapshot_path"]
    if not control_path.is_file():
        raise RuntimeError("immutable control-cycle snapshot referenced by transition receipt is missing")
    control_bytes = control_path.read_bytes()
    if _sha256_bytes(control_bytes) != control["sha256"]:
        raise RuntimeError("immutable control-cycle snapshot hash no longer matches transition receipt")
    control_value = json.loads(control_bytes.decode("utf-8-sig"))
    _validate(root, "phase6_control_cycle_receipt.schema.json", control_value)
    if control_value.get("cycle_id") != control["cycle_id"] or control_value.get("substantive_signature") != control["substantive_signature"]:
        raise RuntimeError("immutable control-cycle identity no longer matches transition receipt")
    frozen_stages = {item.get("stage"): item for item in control_value.get("stages") or []}
    if (frozen_stages.get("LEARNING") or {}).get("identity_hash") != control["learning_identity_hash"]:
        raise RuntimeError("immutable learning identity no longer matches transition receipt")
    if (frozen_stages.get("GOAL_TRAJECTORY") or {}).get("identity_hash") != control["goal_trajectory_identity_hash"]:
        raise RuntimeError("immutable goal-trajectory identity no longer matches transition receipt")
    if (frozen_stages.get("PHASE_TRANSITION") or {}).get("identity_hash") != control["phase_transition_identity_hash"]:
        raise RuntimeError("immutable phase-transition identity no longer matches transition receipt")
    runtime = _runtime(
        status="TRANSITIONED",
        updated_at=updated_at,
        report_id=acceptance["report_id"],
        report_hash=acceptance["sha256"],
        blockers=[],
        receipt=RECEIPT.as_posix(),
        next_action="START_PHASE7_FROM_IMMUTABLE_TRANSITION_RECEIPT",
    )
    _validate(root, "phase6_transition_runtime.schema.json", runtime)
    return runtime


def run_phase6_transition(root: Path = ROOT, *, updated_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    timestamp = _stamp(updated_at)
    try:
        existing = _use_existing_receipt(root, updated_at=timestamp)
        if existing is not None:
            _write_runtime_view(root / RUNTIME, existing)
            _archive_stale_external_error(root)
            return existing

        acceptance_path = root / ACCEPTANCE
        if not acceptance_path.is_file():
            runtime = _runtime(
                status="WAITING_FOR_PHASE6_GATE", updated_at=timestamp,
                report_id=None, report_hash=None, blockers=[], receipt=None,
                next_action="MATERIALIZE_PHASE6_ACCEPTANCE_REPORT",
            )
        else:
            payload = acceptance_path.read_bytes()
            report_hash = _sha256_bytes(payload)
            report = json.loads(payload.decode("utf-8-sig"))
            _validate(root, "phase6_acceptance_report.schema.json", report)
            errors, required_ids, satisfied_ids = _logical_gate_errors(report)
            blockers = list(report.get("blocking_check_ids") or [])
            declared_ready = (
                report.get("phase_decision") == "APPROVED"
                and report.get("current_phase_ready") is True
                and not blockers
            )
            if errors:
                runtime = _runtime(
                    status="BLOCKED", updated_at=timestamp,
                    report_id=report.get("report_id"), report_hash=report_hash,
                    blockers=blockers, receipt=None,
                    next_action="CORRECT_PHASE6_ACCEPTANCE_INTEGRITY_AND_REEVALUATE",
                    error=";".join(errors),
                )
            elif not declared_ready:
                status = "BLOCKED" if report.get("phase_decision") == "BLOCKED" else "WAITING_FOR_PHASE6_GATE"
                runtime = _runtime(
                    status=status, updated_at=timestamp,
                    report_id=report.get("report_id"), report_hash=report_hash,
                    blockers=blockers, receipt=None,
                    next_action=report.get("next_action") or "WAIT_FOR_PHASE6_EVIDENCE",
                    error="PHASE6_ACCEPTANCE_BLOCKED" if status == "BLOCKED" else None,
                )
            elif set(required_ids) != set(satisfied_ids):
                runtime = _runtime(
                    status="BLOCKED", updated_at=timestamp,
                    report_id=report.get("report_id"), report_hash=report_hash,
                    blockers=sorted(set(required_ids) - set(satisfied_ids)), receipt=None,
                    next_action="CORRECT_PHASE6_ACCEPTANCE_INTEGRITY_AND_REEVALUATE",
                    error="REQUIRED_CHECKS_NOT_SATISFIED",
                )
            else:
                cycle_errors, cycle_binding = _control_cycle_binding(root, report)
                if cycle_errors:
                    runtime = _runtime(
                        status="WAITING_FOR_PHASE6_GATE", updated_at=timestamp,
                        report_id=report.get("report_id"), report_hash=report_hash,
                        blockers=[], receipt=None,
                        next_action="WAIT_FOR_RECONCILED_CONTROL_CYCLE:" + ",".join(cycle_errors),
                        error=None,
                    )
                    _validate(root, "phase6_transition_runtime.schema.json", runtime)
                    _write_runtime_view(root / RUNTIME, runtime)
                    _archive_stale_external_error(root)
                    return runtime
                assert cycle_binding is not None
                snapshot_relative = BASE / "acceptance-archive" / (
                    f"{report['report_id']}-{report_hash[:16]}.json"
                )
                snapshot_path = root / snapshot_relative
                snapshot_path.parent.mkdir(parents=True, exist_ok=True)
                if snapshot_path.is_file():
                    if snapshot_path.read_bytes() != payload:
                        raise RuntimeError("immutable acceptance archive collision")
                else:
                    temporary = snapshot_path.with_suffix(".json.tmp")
                    temporary.write_bytes(payload)
                    os.replace(temporary, snapshot_path)
                receipt = {
                    "schema_version": "1.1.0",
                    "transition_id": "phase6-to-phase7-" + hashlib.sha256(
                        f"{report_hash}|{cycle_binding['sha256']}".encode("utf-8")
                    ).hexdigest()[:20],
                    "from_phase": 6,
                    "to_phase": 7,
                    "status": "AUTHORIZED_TO_START",
                    "authorization_decision": "D-047",
                    "acceptance": {
                        "report_id": report["report_id"],
                        "source_path": ACCEPTANCE.as_posix(),
                        "immutable_snapshot_path": snapshot_relative.as_posix(),
                        "sha256": report_hash,
                        "phase_decision": "APPROVED",
                        "required_check_ids": required_ids,
                        "satisfied_check_ids": satisfied_ids,
                        "counts": report["counts"],
                    },
                    "control_cycle": cycle_binding,
                    "previous_state": "PHASE6_IN_PROGRESS",
                    "next_state": "PHASE7_AUTHORIZED_TO_START",
                    "technical_cost_brl": 0,
                    "claim_boundary": [
                        "This receipt proves only that the versioned Phase 6 engineering gate passed.",
                        "It does not guarantee monetization, YPP approval, views, revenue or the 30-day target.",
                        "Phase 7 must still execute its Rule Registry, future application, second measurement, transfer, drift and rollback gates.",
                    ],
                    "created_at": timestamp,
                }
                _validate(root, "phase6_to_phase7_transition_receipt.schema.json", receipt)
                _atomic_write(root / RECEIPT, receipt)
                runtime = _runtime(
                    status="TRANSITIONED", updated_at=timestamp,
                    report_id=report["report_id"], report_hash=report_hash,
                    blockers=[], receipt=RECEIPT.as_posix(),
                    next_action="START_PHASE7_FROM_IMMUTABLE_TRANSITION_RECEIPT",
                )
        _validate(root, "phase6_transition_runtime.schema.json", runtime)
    except Exception as exc:
        runtime = _runtime(
            status="ERROR", updated_at=timestamp,
            report_id=None, report_hash=None, blockers=[], receipt=None,
            next_action="PRESERVE_EVIDENCE_CORRECT_TRANSITION_CONTROLLER_AND_RETRY",
            error=f"{type(exc).__name__}:{exc}",
        )
        _validate(root, "phase6_transition_runtime.schema.json", runtime)
    _write_runtime_view(root / RUNTIME, runtime)
    if runtime["status"] != "ERROR":
        _archive_stale_external_error(root)
    return runtime


if __name__ == "__main__":
    print(json.dumps(run_phase6_transition(), ensure_ascii=False, indent=2))
