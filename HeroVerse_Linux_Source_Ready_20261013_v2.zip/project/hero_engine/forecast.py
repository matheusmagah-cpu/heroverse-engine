from __future__ import annotations

import json
import math
import random
import statistics
from dataclasses import dataclass, asdict
from typing import Any, Iterable


def audio_revenue_scenarios(*, views: int, scenarios: list[dict[str, Any]],
                            monetized: bool, observed_revenue_usd: float | None = None) -> dict[str, Any]:
    """Separate supplied USD assumptions from observed revenue and profit.

    Public market views never supply a competitor's private RPM. No default
    RPM, country multiplier or probability of monetization is invented here.
    """
    if type(views) is not int or views < 0 or type(monetized) is not bool:
        raise ValueError("nonnegative views and explicit monetization state required")
    def number(value, label):
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise ValueError(f"{label} must be finite and nonnegative")
        return value
    if observed_revenue_usd is not None:
        number(observed_revenue_usd, "observed revenue")
    rows = []
    names = set()
    for scenario in scenarios:
        name = scenario["name"]
        if not isinstance(name, str) or not name.strip() or name in names:
            raise ValueError("unique scenario name required")
        names.add(name)
        basis = scenario["assumption_basis"]
        if not isinstance(basis, str) or not basis.strip():
            raise ValueError("explicit assumption basis required")
        rpm = number(scenario["assumed_rpm_usd"], "assumed RPM")
        cost = number(scenario["cost_usd"], "cost")
        hypothetical = views / 1000 * rpm
        revenue = hypothetical if monetized else 0.0
        rows.append({"name": name, "assumption_basis": basis, "assumed_rpm_usd": rpm,
                     "cost_usd": cost, "conditional_monetized_revenue_usd": hypothetical,
                     "modeled_revenue_usd": revenue, "modeled_profit_usd": revenue - cost,
                     "break_even_views_if_monetized": math.ceil(cost * 1000 / rpm) if rpm else None})
    return {"currency": "USD", "views": views, "monetized": monetized,
            "observed_revenue_usd": observed_revenue_usd, "scenarios": rows,
            "scope": "CONDITIONAL_ASSUMPTIONS_NOT_OBSERVED_COMPETITOR_REVENUE"}


@dataclass(frozen=True)
class DeterministicTarget:
    horizon_days: int
    subscriber_gap: int
    watch_hour_gap: float | None
    required_long_views: int | None
    required_total_views_for_subscribers: int
    long_videos: int | None
    shorts: int | None
    required_long_views_per_day: int | None
    required_long_views_per_video: int | None
    required_subscribers_per_day: float


def deterministic_target(config: dict[str, Any], scenario: dict[str, Any], horizon_days: int) -> DeterministicTarget:
    channel = config["channel"]
    publishing = config["publishing"]
    subscriber_gap = max(0, channel["target_subscribers"] - channel["current_subscribers"])
    current_watch_hours = channel.get("current_valid_watch_hours")
    watch_hour_gap = (
        max(0.0, channel["target_valid_watch_hours"] - float(current_watch_hours))
        if isinstance(current_watch_hours, (int, float)) else None
    )
    avd = scenario["average_view_duration_minutes"]
    conversion = scenario["subscriber_conversion_rate"]
    required_long_views = math.ceil(watch_hour_gap * 60 / avd) if watch_hour_gap is not None and avd else None
    required_total_views_for_subscribers = math.ceil(subscriber_gap / conversion) if conversion else 0
    long_rate = publishing.get("long_videos_per_day")
    short_rate = publishing.get("shorts_per_day")
    long_videos = int(long_rate * horizon_days) if isinstance(long_rate, (int, float)) else None
    shorts = int(short_rate * horizon_days) if isinstance(short_rate, (int, float)) else None
    return DeterministicTarget(
        horizon_days=horizon_days,
        subscriber_gap=subscriber_gap,
        watch_hour_gap=watch_hour_gap,
        required_long_views=required_long_views,
        required_total_views_for_subscribers=required_total_views_for_subscribers,
        long_videos=long_videos,
        shorts=shorts,
        required_long_views_per_day=math.ceil(required_long_views / horizon_days) if required_long_views is not None else None,
        required_long_views_per_video=(
            math.ceil(required_long_views / max(1, long_videos))
            if required_long_views is not None and long_videos is not None else None
        ),
        required_subscribers_per_day=subscriber_gap / horizon_days,
    )


def _draw_views(rng: random.Random, median: float, sigma: float) -> int:
    if median <= 0:
        return 0
    return max(0, round(rng.lognormvariate(math.log(median), sigma)))


def _quantile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def simulate(
    config: dict[str, Any],
    scenario: dict[str, Any],
    horizon_days: int,
    simulations: int | None = None,
    seed: int = 74,
) -> dict[str, Any]:
    publishing = config["publishing"]
    channel = config["channel"]
    runs = simulations or config["forecast"]["simulations"]
    long_rate = publishing.get("long_videos_per_day")
    short_rate = publishing.get("shorts_per_day")
    current_hours = channel.get("current_valid_watch_hours")
    deterministic = deterministic_target(config, scenario, horizon_days)
    operational_inputs_available = all(
        isinstance(value, (int, float))
        for value in (long_rate, short_rate, current_hours)
    )
    if not operational_inputs_available:
        return {
            "scenario": scenario["name"],
            "horizon_days": horizon_days,
            "simulations": 0,
            "assumptions": {
                "average_view_duration_minutes": scenario["average_view_duration_minutes"],
                "subscriber_conversion_rate": scenario["subscriber_conversion_rate"],
                "median_views_per_long": scenario["median_views_per_long"],
                "median_views_per_short": scenario["median_views_per_short"],
                "breakout_probability_per_long": scenario["breakout_probability_per_long"],
                "breakout_median_views": scenario["breakout_median_views"],
            },
            "deterministic_target": asdict(deterministic),
            "probability_status": "withheld_missing_operational_inputs",
            "probability": {"reach_subscribers": None, "reach_watch_hours": None, "reach_both": None},
            "distribution": {"long_views": None, "short_views": None, "subscribers_total": None, "valid_watch_hours_total": None},
        }
    long_count = int(long_rate * horizon_days)
    short_count = int(short_rate * horizon_days)
    rng = random.Random(seed)

    target_subscribers = channel["target_subscribers"]
    target_hours = channel["target_valid_watch_hours"]
    current_subscribers = channel["current_subscribers"]
    current_hours = float(current_hours)

    reached_subscribers = 0
    reached_hours = 0
    reached_both = 0
    long_views_results: list[float] = []
    short_views_results: list[float] = []
    subscriber_results: list[float] = []
    watch_hour_results: list[float] = []

    for _ in range(runs):
        long_views = 0
        for _ in range(long_count):
            is_breakout = rng.random() < scenario["breakout_probability_per_long"]
            median = scenario["breakout_median_views"] if is_breakout else scenario["median_views_per_long"]
            long_views += _draw_views(rng, median, 0.72 if is_breakout else 0.90)

        short_views = 0
        for _ in range(short_count):
            is_breakout = rng.random() < scenario["short_breakout_probability"]
            median = scenario["short_breakout_median_views"] if is_breakout else scenario["median_views_per_short"]
            short_views += _draw_views(rng, median, 0.82 if is_breakout else 1.0)

        all_views = long_views + short_views
        rate_noise = max(0.35, rng.lognormvariate(0, 0.22))
        gained_subscribers = round(all_views * scenario["subscriber_conversion_rate"] * rate_noise)
        subscribers = current_subscribers + gained_subscribers

        avd_noise = max(0.45, rng.normalvariate(1.0, 0.14))
        avd = scenario["average_view_duration_minutes"] * avd_noise
        watch_hours = current_hours + long_views * avd / 60

        sub_ok = subscribers >= target_subscribers
        hours_ok = watch_hours >= target_hours
        reached_subscribers += int(sub_ok)
        reached_hours += int(hours_ok)
        reached_both += int(sub_ok and hours_ok)
        long_views_results.append(long_views)
        short_views_results.append(short_views)
        subscriber_results.append(subscribers)
        watch_hour_results.append(watch_hours)

    def summary(values: list[float]) -> dict[str, float]:
        return {
            "p10": round(_quantile(values, 0.10), 2),
            "p50": round(_quantile(values, 0.50), 2),
            "p90": round(_quantile(values, 0.90), 2),
            "mean": round(statistics.fmean(values), 2),
        }

    return {
        "scenario": scenario["name"],
        "horizon_days": horizon_days,
        "simulations": runs,
        "assumptions": {
            "average_view_duration_minutes": scenario["average_view_duration_minutes"],
            "subscriber_conversion_rate": scenario["subscriber_conversion_rate"],
            "median_views_per_long": scenario["median_views_per_long"],
            "median_views_per_short": scenario["median_views_per_short"],
            "breakout_probability_per_long": scenario["breakout_probability_per_long"],
            "breakout_median_views": scenario["breakout_median_views"],
        },
        "deterministic_target": asdict(deterministic),
        "probability": {
            "reach_subscribers": round(reached_subscribers / runs, 4),
            "reach_watch_hours": round(reached_hours / runs, 4),
            "reach_both": round(reached_both / runs, 4),
        },
        "distribution": {
            "long_views": summary(long_views_results),
            "short_views": summary(short_views_results),
            "subscribers_total": summary(subscriber_results),
            "valid_watch_hours_total": summary(watch_hour_results),
        },
    }


def all_scenarios(
    config: dict[str, Any],
    horizon_days: int | None = None,
    calibration: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    days = horizon_days or config["channel"]["deadline_days"]
    calibration_info = calibration or {
        "status": "prior_only",
        "observed_long_videos": 0,
        "observed_shorts": 0,
        "minimum_per_format": 10,
        "interpretation": "Conditional scenario output; not yet calibrated to this channel's new format.",
    }
    results = [simulate(config, scenario, days) for scenario in config["forecast"]["scenarios"]]
    for result in results:
        result["calibration"] = dict(calibration_info)
        if calibration_info.get("status") != "calibrated" and result.get("probability_status") != "withheld_missing_operational_inputs":
            result["probability_status"] = "withheld_unobserved_channel_sample"
            result["probability"] = {
                "reach_subscribers": None,
                "reach_watch_hours": None,
                "reach_both": None,
            }
            result["distribution"] = {
                "long_views": None,
                "short_views": None,
                "subscribers_total": None,
                "valid_watch_hours_total": None,
            }
    return results


def markdown_report(config: dict[str, Any], forecasts: Iterable[dict[str, Any]]) -> str:
    channel = config["channel"]
    lines = [
        "# HERO Engine — Forecast de monetização",
        "",
        f"Canal: **{channel['name']} ({channel['handle']})**",
        "",
        f"Estado inicial: {channel['current_subscribers']} inscritos e "
        f"{channel['current_valid_watch_hours'] if channel.get('current_valid_watch_hours') is not None else 'UNAVAILABLE'} horas válidas.",
        "",
        f"Meta: {channel['target_subscribers']} inscritos e "
        f"{channel['target_valid_watch_hours']} horas válidas.",
        "",
        "> Probabilidades ficam ocultas sem calibração própria. Aritmética determinística só é exibida quando o contador YPP e a cadência existem como observações; entradas ausentes permanecem UNAVAILABLE.",
        "",
        "| Cenário | Dias | P(inscritos) | P(horas) | P(ambos) | Long views P50 | Horas P50 | Inscritos P50 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for result in forecasts:
        p = result["probability"]
        d = result["distribution"]
        if p["reach_both"] is None:
            lines.append(f"| {result['scenario']} | {result['horizon_days']} | — | — | — | — | — | — |")
        else:
            lines.append(
                f"| {result['scenario']} | {result['horizon_days']} | {p['reach_subscribers']:.1%} | "
                f"{p['reach_watch_hours']:.1%} | {p['reach_both']:.1%} | "
                f"{d['long_views']['p50']:,.0f} | {d['valid_watch_hours_total']['p50']:,.0f} | "
                f"{d['subscribers_total']['p50']:,.0f} |"
            )
    first = next(iter(forecasts), None)
    if first:
        calibration = first.get("calibration", {})
        lines.extend(
            [
                "",
                "## Estado de calibração",
                "",
                f"- Estado: `{calibration.get('status', 'prior_only')}`.",
                f"- Amostra observada: {calibration.get('observed_long_videos', 0)} longos e {calibration.get('observed_shorts', 0)} Shorts.",
                f"- Mínimo operacional para recalibrar: {calibration.get('minimum_per_format', 10)} publicações por formato.",
                "- A lacuna de inscritos continua calculável. Lacuna de horas, necessidade de views e rateio por vídeo ficam indisponíveis sem contador YPP e cadência observados.",
            ]
        )
    lines.extend(["", "## Metas determinísticas", ""])
    for result in forecasts:
        t = result["deterministic_target"]
        a = result["assumptions"]
        lines.extend(
            [
                f"### {result['scenario'].title()}",
                "",
                f"- Duração média usada: {a['average_view_duration_minutes']:.1f} min.",
                f"- Conversão em inscritos usada: {a['subscriber_conversion_rate']:.2%}.",
                f"- Views longas necessárias: {t['required_long_views'] if t['required_long_views'] is not None else 'UNAVAILABLE'}.",
            ]
        )
        if t["long_videos"] is None:
            lines.append("- Views por vídeo longo: UNAVAILABLE; não existe cadência pré-comprometida.")
        else:
            lines.append(f"- Views por vídeo longo: {t['required_long_views_per_video']} em {t['long_videos']} vídeos.")
        lines.extend(
            [
                f"- Views totais necessárias para o gap de inscritos: {t['required_total_views_for_subscribers']:,}.",
                "",
            ]
        )
    return "\n".join(lines)


def serialize(result: dict[str, Any]) -> str:
    return json.dumps(result, ensure_ascii=False, sort_keys=True)
