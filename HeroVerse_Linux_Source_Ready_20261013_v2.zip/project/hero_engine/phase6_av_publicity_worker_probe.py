"""One bounded import-origin probe; never create a detector or consume media.

The external file profile is validated once, inside the isolated worker. This
records Python module origins, not OS/DLL or in-memory code attestation.
"""
from __future__ import annotations

import _imp
import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import types
import uuid

VERSION = "phase6-av-publicity-worker-origin-probe-v1"
ROOT = Path(__file__).absolute().parents[1]
MODULE = Path(__file__).absolute()
TEST = ROOT / "tests/test_phase6_av_publicity_worker_probe.py"
RUNTIME = ROOT / "hero_engine/phase6_av_publicity_runtime.py"
RUNTIME_SHA = "c000f7988b1c97242686f338bde8a83bb8296b64b45aa0cdf1b7c25c4ec0c9d7"
SUPERVISOR = ROOT / "hero_engine/audio_perception_supervisor.py"
SUPERVISOR_SHA = "fb645ace63ac88db00a7f34b63b18b3c50b6c6fd4f185df45dfdfec4f68efe08"
AUDIO_SUPPORT = ROOT / "hero_engine/audio_perception.py"
AUDIO_SUPPORT_SHA = "29a10ffdb93f817d0ddc71cf85608f1a6dc31a2787ecc07909d9622f511bd029"
PROFILE_PATH = ROOT / "output/qa/phase6/diagnostics/phase6-av-publicity-clock-fix-v1/runtime-profile-real-v1/profile.json"
PROFILE_SHA = "c9225445a94fa2e5f5bec2578608681e3eb2993fa9cc76ef0a4f18581fe3a6ab"
PROFILE_SIZE = 978691
TIMEOUT_SECONDS = 300
MEMORY_BYTES = 2 * 1024**3
NATIVE_EXPORT_LIMIT = 2048
NATIVE_NAMESPACES = frozenset("Error aruco barcode ccm cuda detail dnn fisheye flann instr ipp mcc ocl ogl parallel samples segmentation videoio_registry".split())
AUTHORITY = dict.fromkeys(("detector_calibrated", "source_admitted", "quality_approved",
                           "publicity_approved", "render_authorized", "queue_authorized",
                           "publication_authorized"), False)
LIMITATIONS = ["ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION", "NO_SOURCE_FRAME_OR_DETECTOR_USED",
               "PYTHON_MODULE_FILE_ORIGINS_NOT_OS_DLL_OR_IN_MEMORY_CODE_ATTESTATION",
               "RECORDED_CACHE_PRESENCE_NOT_PROOF_EVERY_CACHE_WAS_EXECUTED",
               "NO_RETROACTIVE_AUTHENTICATION_OF_OLD_PUBLICITY_JOURNALS",
               "NOT_INSTALLED_IN_ADMISSION_OR_PUBLICATION"]


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _same(left, right, reason):
    if _canonical(left) != _canonical(right):
        raise ValueError(reason)


def _pin(path, digest, cap=8 * 1024**2):
    """Bootstrap only: fixed code/profile paths, one authenticated byte buffer."""
    path = Path(path).absolute()
    if ".." in path.parts or type(digest) is not str or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ValueError("exact bootstrap path and SHA required")
    def snapshot():
        for part in (path, *path.parents):
            info = part.lstat()
            if (part.is_symlink() or getattr(part, "is_junction", lambda: False)()
                    or getattr(info, "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000)):
                raise ValueError("linked/nonresident bootstrap file")
        return path.stat()
    before = snapshot()
    if not path.is_file() or before.st_nlink != 1 or not 0 < before.st_size <= cap:
        raise ValueError("invalid bootstrap file size/type")
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(cap + 1)
        closed = os.fstat(stream.fileno())
    after = snapshot()
    identity = lambda value: (value.st_dev, value.st_ino, value.st_nlink, value.st_size, value.st_mtime_ns)
    if any(identity(value) != identity(before) for value in (opened, closed, after)) or len(raw) != before.st_size or _sha(raw) != digest:
        raise ValueError("bootstrap bytes changed")
    return raw


def _load(path, digest, name):
    raw = _pin(path, digest)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__spec__ = importlib.util.spec_from_file_location(name, path)
    # Execute the authenticated source, not a second loader read or .pyc.
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    _pin(path, digest)
    return module


def _runtime():
    return _load(RUNTIME, RUNTIME_SHA, "_publicity_probe_runtime_v1")


def _supervisor():
    return _load(SUPERVISOR, SUPERVISOR_SHA, "_publicity_probe_supervisor_v2")


def _profile(runtime, binding):
    expected = {"path": str(PROFILE_PATH), "sha256": "sha256:" + PROFILE_SHA, "size_bytes": PROFILE_SIZE}
    _same(binding, expected, "only the externally frozen local profile is permitted")
    raw = _pin(PROFILE_PATH, PROFILE_SHA)
    if len(raw) != PROFILE_SIZE:
        raise ValueError("profile size differs")
    profile = runtime._json(raw)
    for key, value in {"kind": runtime.PROFILE_KIND, "version": runtime.VERSION,
                       "project_root": str(ROOT), "base_python": str(runtime.BASE_PYTHON),
                       "site_packages": str(ROOT / ".venv/Lib/site-packages"),
                       "ffmpeg_directory": str(runtime.FFMPEG_DIRECTORY),
                       "authority": runtime.AUTHORITY, "technical_cost_brl": 0}.items():
        _same(profile[key], value, "fixed runtime profile header differs")
    return profile


def _directory(runtime, value):
    path = Path(value).absolute()
    prefix = ROOT / "output/qa/phase6/diagnostics"
    if ".." in path.parts or path == prefix or not path.is_relative_to(prefix):
        raise ValueError("new diagnostic child namespace required")
    runtime._resident(path.parent)
    if os.path.lexists(path):
        raise ValueError("probe namespace already exists; no implicit retry or overwrite")
    return path


def _binding(path, digest):
    raw = _pin(path, digest)
    return {"path": str(path), "sha256": "sha256:" + digest, "size_bytes": len(raw)}


def prepare_probe(root, *, profile_binding, expected_worker_sha, expected_test_sha, run_directory):
    runtime = _runtime()
    if runtime._root(root) != ROOT:
        raise ValueError("fixed probe root required")
    directory = _directory(runtime, run_directory)
    profile = _profile(runtime, profile_binding)
    _same(profile["population"], runtime._population(ROOT), "profile inventory changed before process")
    bindings = {item["path"]: item for item in profile["file_bindings"]}
    files = runtime._Files()
    # Authenticate fixed startup executable/DLLs before allowing the process.
    for name in runtime.BASE_FILES:
        path = runtime.BASE_PYTHON / name
        files.read(path, cap=runtime.FILE_CAP, expected=bindings[str(path)])
    code = {"worker": _binding(MODULE, expected_worker_sha), "test": _binding(TEST, expected_test_sha),
            "runtime": _binding(RUNTIME, RUNTIME_SHA), "supervisor": _binding(SUPERVISOR, SUPERVISOR_SHA),
            "supervisor_support": _binding(AUDIO_SUPPORT, AUDIO_SUPPORT_SHA)}
    files.recheck()
    request = {"version": VERSION, "root": str(ROOT), "profile_binding": dict(profile_binding),
               "code_bindings": code, "run_directory": str(directory), "memory_bytes": MEMORY_BYTES,
               "timeout_seconds": TIMEOUT_SECONDS, "authority": dict(AUTHORITY), "technical_cost_brl": 0}
    return {"status": "PREFLIGHT_ONLY_NO_PROCESS", "request": request,
            "request_sha256": _sha(_canonical(request)), "process_calls": 0, "files_written": 0}


def _exclusive(path, raw):
    if os.path.lexists(path):
        raise ValueError("exclusive output collision, including identical bytes")
    temporary = path.with_name("." + path.name + "." + uuid.uuid4().hex + ".partial")
    created = False
    try:
        with temporary.open("xb") as stream:
            created = True
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        if created:
            temporary.unlink()
    _pin(path, _sha(raw))


def _startup(runtime, *, flags=None, path_entries=None, executable=None, prefix=None, base_prefix=None, loaded=None):
    flags = sys.flags if flags is None else flags
    entries = list(sys.path if path_entries is None else path_entries)
    loaded = sys.modules if loaded is None else loaded
    observed_flags = {key: getattr(flags, key) for key in ("isolated", "no_site", "dont_write_bytecode", "ignore_environment", "no_user_site", "safe_path")}
    if any(value not in (1, True) for value in observed_flags.values()):
        raise ValueError("worker requires actual -I -S -B startup flags")
    base = runtime.BASE_PYTHON
    if (Path(sys.executable if executable is None else executable).absolute() != base / "python.exe"
            or Path(sys.prefix if prefix is None else prefix).absolute() != base
            or Path(sys.base_prefix if base_prefix is None else base_prefix).absolute() != base):
        raise ValueError("worker interpreter origin is not the fixed base")
    permitted = {str(base / "python312.zip"), str(base / "DLLs"), str(base / "Lib"), str(base)}
    if (not entries or len(entries) != len(set(entries)) or any(entry not in permitted for entry in entries)
            or str(base / "Lib") not in entries or str(base / "DLLs") not in entries
            or any(name == "site" or name.split(".")[0] in {"cv2", "numpy"} for name in loaded)):
        raise ValueError("foreign startup search path or premature site/package import")
    return {"flags": observed_flags, "sys_path": entries, "executable": str(base / "python.exe"),
            "prefix": str(base), "base_prefix": str(base), "site_inserted_at_startup": False,
            "interpreter": {"version": sys.version, "version_info": list(sys.version_info),
                            "implementation": sys.implementation.name,
                            "cache_tag": sys.implementation.cache_tag}}


def _origins(runtime, profile, *, modules, extra_bindings, native_exports=()):
    bindings = {item["path"]: item for item in profile["file_bindings"]}
    for item in extra_bindings:
        if item["path"] in bindings:
            _same(bindings[item["path"]], item, "extra code identity differs from profile")
        bindings[item["path"]] = item
    files, rows, absent_caches = runtime._Files(), [], []
    native_ids = {id(item) for item in native_exports}
    checked = set()
    def check(path):
        path = runtime._resident(Path(path).absolute())
        item = bindings.get(str(path))
        if item is None:
            raise ValueError("imported file/cache outside externally profiled population: " + str(path))
        if str(path) not in checked:
            files.read(path, cap=runtime.FILE_CAP, expected=item)
            checked.add(str(path))
        return dict(item)
    for name, module in sorted(tuple(modules.items())):
        if module is None:
            raise ValueError("unresolved module in origin population")
        filename = getattr(module, "__file__", None)
        spec_origin = getattr(getattr(module, "__spec__", None), "origin", None)
        row = {"module": name, "file_binding": None, "cache_binding": None, "spec_origin": spec_origin,
               "support_bindings": []}
        if filename:
            row["file_binding"] = check(filename)
            if spec_origin not in (None, "built-in", "frozen") and Path(spec_origin).absolute() != Path(filename).absolute():
                raise ValueError("module spec and file origins differ")
            row["origin_kind"] = "PROFILED_FILE"
            cached = getattr(module, "__cached__", None)
            if cached:
                cache = Path(cached).absolute()
                if os.path.lexists(cache):
                    row["cache_binding"] = check(cache)
                else:
                    if not cache.is_relative_to(runtime.BASE_PYTHON / "Lib") and not cache.is_relative_to(Path(profile["site_packages"])):
                        raise ValueError("cache path outside closed Python roots")
                    absent_caches.append(str(cache))
        elif _imp.is_builtin(name) or _imp.is_frozen(name):
            row["origin_kind"] = "INTERPRETER_BUILTIN_OR_FROZEN"
        elif id(module) in native_ids:
            row["origin_kind"] = "VERIFIED_NATIVE_MODULE_EXPORT_WITHOUT_FILE"
        elif name in {"cv2." + child for child in NATIVE_NAMESPACES}:
            spec = getattr(module, "__spec__", None)
            directory = Path(profile["site_packages"]) / "cv2" / name[4:]
            expected_paths = [str(directory)]
            native = getattr(module, "_native", None)
            if (type(getattr(spec, "loader", None)) is not importlib.machinery.NamespaceLoader
                    or getattr(spec, "name", None) != name or spec_origin is not None
                    or list(getattr(module, "__path__", ())) != expected_paths
                    or list(getattr(spec, "submodule_search_locations", ()) or ()) != expected_paths
                    or str(directory) not in profile["population"].get("directories", ())
                    or id(native) not in native_ids or getattr(native, "__name__", None) != name
                    or any(os.path.lexists(directory / leaf) for leaf in ("__init__.py", "__init__.pyc"))):
                raise ValueError("namespace is not the exact profiled native attachment: " + name)
            runtime._resident(directory)
            row["support_bindings"] = [check(directory / "__init__.pyi")]
            row["namespace_paths"] = expected_paths
            row["origin_kind"] = "PROFILED_NAMESPACE_WITH_VERIFIED_NATIVE_ATTACHMENT"
        elif name in {"typing.io", "typing.re"}:
            owner = modules.get("typing")
            source = runtime.BASE_PYTHON / "Lib/typing.py"
            if (owner is None or not isinstance(module, type)
                    or vars(owner).get(name[7:]) is not module
                    or getattr(owner, "__file__", None) != str(source)
                    or getattr(getattr(owner, "__spec__", None), "origin", None) != str(source)
                    or module.__module__ != "typing"):
                raise ValueError("typing pseudo-module is not the exact profiled stdlib export")
            row["support_bindings"] = [check(source)]
            row["origin_kind"] = "PROFILED_STDLIB_EXACT_PSEUDO_MODULE_EXPORT"
        else:
            raise ValueError("module without attributable file/builtin/native origin: " + name)
        rows.append(row)
    # Native DLL data is not exposed via __file__; reopen the declared package DLLs,
    # without claiming Windows loaded-module or transitive OS-DLL attestation.
    site = Path(profile["site_packages"])
    for item in profile["file_bindings"]:
        path = Path(item["path"])
        if path.suffix.lower() == ".dll" and (path.is_relative_to(site / "cv2") or path.is_relative_to(site / "numpy.libs")):
            check(path)
    return {"modules": rows, "absent_cache_paths": sorted(set(absent_caches))}, files


def _native_module_exports(native):
    """Object-reachable fileless exports of the already path-verified native root.

    Filed Python wrappers are checked separately by _origins, not used as bridges
    to authorize unrelated virtual modules. No module-name prefix grants origin.
    """
    if not isinstance(native, types.ModuleType):
        raise ValueError("verified native root must be an actual module object")
    pending, visited, exports = [native], {id(native)}, []
    while pending:
        current = pending.pop()
        for child in vars(current).values():
            if not isinstance(child, types.ModuleType) or id(child) in visited:
                continue
            if getattr(child, "__file__", None):
                continue
            if len(visited) >= NATIVE_EXPORT_LIMIT:
                raise ValueError("native module-export graph exceeds fixed bound")
            visited.add(id(child))
            exports.append(child)
            pending.append(child)
    return exports


def _native_observation(runtime, cv2, numpy):
    site = ROOT / ".venv/Lib/site-packages"
    native = getattr(cv2, "_native", None)
    multiarray = sys.modules.get("numpy._core._multiarray_umath")
    expected = ((cv2, site / "cv2/__init__.py"), (native, site / "cv2/cv2.pyd"),
                (numpy, site / "numpy/__init__.py"),
                (multiarray, site / "numpy/_core/_multiarray_umath.cp312-win_amd64.pyd"))
    for module, path in expected:
        if module is None or runtime._resident(Path(module.__file__).absolute()) != path:
            raise ValueError("OpenCV/NumPy top-level or native origin differs")
    if cv2.__version__ != "5.0.0" or numpy.__version__ != "2.5.2":
        raise ValueError("observed native package versions differ from fixed distribution family")
    exports = _native_module_exports(native)
    return {"opencv_native_version": cv2.__version__, "numpy_version": numpy.__version__,
            "opencv_distribution_version": "5.0.0.93", "numpy_distribution_version": "2.5.2",
            "native_module_paths": [str(path) for _, path in expected]}, exports


def _recheck(runtime, profile, files, request, request_path, request_sha):
    files.recheck()
    _same(profile["population"], runtime._population(ROOT), "runtime inventory changed after imports")
    _pin(PROFILE_PATH, PROFILE_SHA)
    _pin(request_path, request_sha)
    for item in request["code_bindings"].values():
        _pin(Path(item["path"]), item["sha256"][7:])


def _worker(request_path, request_sha, expected_worker_sha, expected_test_sha):
    started = time.perf_counter()
    runtime = _runtime()
    startup = _startup(runtime)
    raw = _pin(request_path, request_sha)
    request = runtime._json(raw)
    keys = {"version", "root", "profile_binding", "code_bindings", "run_directory", "memory_bytes", "timeout_seconds", "authority", "technical_cost_brl"}
    if type(request) is not dict or set(request) != keys:
        raise ValueError("closed worker request required")
    directory = runtime._resident(Path(request["run_directory"]))
    prefix = ROOT / "output/qa/phase6/diagnostics"
    if directory == prefix or not directory.is_relative_to(prefix) or Path(request_path).absolute() != directory / "request.json":
        raise ValueError("worker request outside exact owned namespace")
    expected_code = {"worker": _binding(MODULE, expected_worker_sha), "test": _binding(TEST, expected_test_sha),
                     "runtime": _binding(RUNTIME, RUNTIME_SHA), "supervisor": _binding(SUPERVISOR, SUPERVISOR_SHA),
                     "supervisor_support": _binding(AUDIO_SUPPORT, AUDIO_SUPPORT_SHA)}
    for key, value in {"version": VERSION, "root": str(ROOT), "code_bindings": expected_code,
                       "memory_bytes": MEMORY_BYTES, "timeout_seconds": TIMEOUT_SECONDS,
                       "authority": AUTHORITY, "technical_cost_brl": 0}.items():
        _same(request[key], value, "worker request identity/limits differ")
    profile = _profile(runtime, request["profile_binding"])
    supervisor = _supervisor()
    containment = supervisor._require_worker_containment(MEMORY_BYTES)
    file_validation = runtime.validate_profile(ROOT, profile_binding=request["profile_binding"])
    # No site processing: only this exact already-validated installation is inserted.
    site = str(ROOT / ".venv/Lib/site-packages")
    sys.path.insert(0, site)
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    import cv2
    import numpy
    native, exports = _native_observation(runtime, cv2, numpy)
    origin, files = _origins(runtime, profile, modules=sys.modules, extra_bindings=list(expected_code.values()), native_exports=exports)
    _recheck(runtime, profile, files, request, request_path, request_sha)
    for path in origin["absent_cache_paths"]:
        if os.path.lexists(path):
            raise ValueError("cache appeared during isolated no-write probe")
    report = {"version": VERSION, "status": "ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION",
              "request_binding": {"path": str(request_path), "sha256": "sha256:" + request_sha, "size_bytes": len(raw)},
              "profile_binding": request["profile_binding"], "code_bindings": expected_code,
              "startup": startup, "inserted_site": site, "native_observation": native,
              "origins": origin, "file_validation": file_validation, "containment": containment,
              "module_count": len(origin["modules"]), "profile_validation_calls": 1,
              "elapsed_seconds": time.perf_counter() - started, "authority": dict(AUTHORITY),
              "technical_cost_brl": 0, "detector_calls": 0, "decode_calls": 0, "network_calls": 0,
              "limitations": list(LIMITATIONS)}
    _exclusive(directory / "probe.json", _canonical(report))
    _recheck(runtime, profile, files, request, request_path, request_sha)
    _pin(directory / "probe.json", _sha(_canonical(report)))
    # Link the produced bytes to the supervisor's independently captured stdout.
    print(_canonical({"probe_sha256": _sha(_canonical(report))}).decode("utf-8"), flush=True)
    return report


def run_probe(root, *, profile_binding, expected_worker_sha, expected_test_sha, run_directory, commit=False):
    if type(commit) is not bool:
        raise ValueError("explicit boolean commit required")
    prepared = prepare_probe(root, profile_binding=profile_binding, expected_worker_sha=expected_worker_sha,
                             expected_test_sha=expected_test_sha, run_directory=run_directory)
    if not commit:
        return prepared
    request = prepared["request"]
    directory = Path(request["run_directory"])
    directory.mkdir(exist_ok=False)
    request_path = directory / "request.json"
    _exclusive(request_path, _canonical(request))
    runtime, supervisor = _runtime(), _supervisor()
    command = [str(runtime.BASE_PYTHON / "python.exe"), "-I", "-S", "-B", str(MODULE), "--worker",
               str(request_path), prepared["request_sha256"], expected_worker_sha, expected_test_sha]
    result = supervisor.run_bounded(command, cwd=ROOT, logs=directory / "process",
                                    timeout_seconds=TIMEOUT_SECONDS, memory_bytes=MEMORY_BYTES)
    terminal = {"version": VERSION, "status": "PROBE_FAILED_NOT_ADMITTED", "process": result,
                "request_binding": _binding(request_path, prepared["request_sha256"]),
                "probe_binding": None, "authority": dict(AUTHORITY), "technical_cost_brl": 0}
    if (result["status"] == "SUCCEEDED" and result["exit_code"] == 0
            and result["remaining_processes_verified"] == 0 and result["assigned_before_resume"] is True
            and result["kill_on_close"] is True and result["committed_memory_limit_bytes"] == MEMORY_BYTES):
        path = directory / "probe.json"
        logs = [item for item in result["logs"] if Path(item["path"]) == directory / "process/stdout.log"]
        if len(logs) != 1:
            raise ValueError("supervised stdout identity missing")
        stdout = _pin(Path(logs[0]["path"]), logs[0]["sha256"])
        completed = runtime._json(stdout)
        if (type(completed) is not dict or set(completed) != {"probe_sha256"}
                or len(stdout) != logs[0]["size"] or stdout.strip() != _canonical(completed)):
            raise ValueError("worker output is not the bytes completed by the supervised process")
        raw = _pin(path, completed["probe_sha256"])
        report = runtime._json(raw)
        report_keys = {"version", "status", "request_binding", "profile_binding", "code_bindings", "startup",
                       "inserted_site", "native_observation", "origins", "file_validation", "containment",
                       "module_count", "profile_validation_calls", "elapsed_seconds", "authority",
                       "technical_cost_brl", "detector_calls", "decode_calls", "network_calls", "limitations"}
        if type(report) is not dict or set(report) != report_keys:
            raise ValueError("closed worker report required")
        for key, value in {"version": VERSION, "status": "ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION",
                           "request_binding": terminal["request_binding"], "profile_binding": profile_binding,
                           "code_bindings": request["code_bindings"], "profile_validation_calls": 1,
                           "authority": AUTHORITY, "technical_cost_brl": 0, "detector_calls": 0,
                           "decode_calls": 0, "network_calls": 0, "limitations": LIMITATIONS}.items():
            _same(report[key], value, "worker report differs from bounded request")
        profile = _profile(runtime, profile_binding)
        _same(profile["population"], runtime._population(ROOT), "runtime inventory changed before terminal")
        files = runtime._Files()
        bindings = {item["path"]: item for item in (*profile["file_bindings"], *request["code_bindings"].values())}
        rows = report["origins"]["modules"]
        if (type(rows) is not list or not rows or type(report["module_count"]) is not int
                or len(rows) != report["module_count"] or len({row["module"] for row in rows}) != len(rows)):
            raise ValueError("worker module population differs")
        for row in report["origins"]["modules"]:
            support = row.get("support_bindings", [])
            if type(support) is not list or len(support) > 1:
                raise ValueError("closed origin support bindings required")
            for item in (row["file_binding"], row["cache_binding"], *support):
                if item is not None:
                    _same(item, bindings.get(item.get("path")), "worker reported an unprofiled origin")
                    files.read(item["path"], cap=runtime.FILE_CAP, expected=item)
        _recheck(runtime, profile, files, request, request_path, prepared["request_sha256"])
        terminal.update(status="ORIGIN_PROBE_ONLY_NOT_DETECTOR_CALIBRATION", probe_binding=_binding(path, _sha(raw)))
    _exclusive(directory / "terminal.json", _canonical(terminal))
    _pin(request_path, prepared["request_sha256"])
    _pin(PROFILE_PATH, PROFILE_SHA)
    for item in request["code_bindings"].values():
        _pin(Path(item["path"]), item["sha256"][7:])
    return terminal


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", nargs=4, required=True)
    arguments = parser.parse_args().worker
    _worker(Path(arguments[0]), arguments[1], arguments[2], arguments[3])
