"""Recover one pinned parent-close failure, without repeating the worker.

The only new acceptance is the already-profiled empty urllib/__init__.py.
This reopens historical file-origin evidence; it does not authenticate this
process as a detector runtime, calibrate YuNet or approve publicity.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

VERSION = "phase6-av-publicity-control-recovery-v2"
ROOT = Path(__file__).absolute().parents[1]
MODULE = Path(__file__).absolute()
TEST = ROOT / "tests/test_phase6_av_publicity_control_recovery.py"
LEGACY = ROOT / "hero_engine/phase6_av_publicity_control_worker.py"
LEGACY_SHA = "fe46a595fdade439888fe3ee089c979f2792d96c3c4d5a32037f3f7976b34428"
LEGACY_TEST_SHA = "27445c566699e8652638387f8d8e0e5731a1b0c5791e358296233deda59df288"
SOURCE = ROOT / "output/qa/phase6/diagnostics/phase6-av-publicity-clock-fix-v1/control-worker-real-v2"
SOURCE_PINS = {
    "request.json": "9d08037142fbc8dc86a5dae217f2d17dc85fbfaa854ea294b6ba22f9744533c3",
    "controls.json": "81992498fa513d3b26e42f407efcdbb7d6ce0ae837a2a6a22ff280f721959271",
    "terminal.json": "ed4139ac5ef6ec6bb07d47e7073021ff192814fe5600ff67a562d65bf646babd",
    "problem.json": "ed4139ac5ef6ec6bb07d47e7073021ff192814fe5600ff67a562d65bf646babd",
    "process/process-receipt.json": "eba7089bca0891844eca69d11bea8ee9660f464a252b58e456ee96ce8baef67e",
}
EMPTY_SHA = "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
EXPECTED_ERROR = {"type": "RuntimeProfileError", "message": "external positive binding triple required"}
AUTHORITY = dict.fromkeys(("runtime_current_authenticated", "detector_calibrated", "human_gold",
    "source_admitted", "quality_approved", "publicity_approved", "legal_clearance", "render_authorized",
    "queue_authorized", "publication_authorized"), False)
LIMITATIONS = ["CHECKPOINT_RECOVERY_OF_ONE_PINNED_PARENT_CLOSE_FAILURE", "ORIGINAL_FAILURE_PRESERVED",
    "TWO_OPERATIONAL_EXAMPLES_NOT_DOMAIN_CALIBRATION", "HISTORICAL_RECORDED_ORIGINS_NOT_CURRENT_RUNTIME_ATTESTATION",
    "NO_HUMAN_GOLD_OR_PUBLICITY_CLEARANCE", "NO_REINFERENCE_DECODE_NETWORK_OR_PROFILE_RECAPTURE",
    "NOT_INSTALLED_IN_PRODUCTION_CONSUMERS"]


def _dependencies():
    # Bootstrap the exact legacy bytes. No import of its mutable .pyc or native
    # runtime occurs; its authenticated helper loader is reused afterwards.
    path = LEGACY
    for part in (path, *path.parents):
        info = part.lstat()
        if (part.is_symlink() or getattr(part, "is_junction", lambda: False)()
                or getattr(info, "st_file_attributes", 0) & (0x400 | 0x1000 | 0x40000 | 0x400000)):
            raise ValueError("linked/nonresident recovery bootstrap")
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or not 0 < before.st_size <= 128 * 1024:
        raise ValueError("invalid recovery bootstrap file")
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(128 * 1024 + 1)
        closed = os.fstat(stream.fileno())
    identity = lambda item: (item.st_dev, item.st_ino, item.st_nlink, item.st_size, item.st_mtime_ns)
    if (any(identity(item) != identity(before) for item in (opened, closed, path.stat()))
            or len(raw) != before.st_size or hashlib.sha256(raw).hexdigest() != LEGACY_SHA):
        raise ValueError("fixed legacy recovery source pin differs")
    c = types.ModuleType("_publicity_control_recovery_legacy")
    c.__file__ = str(path)
    sys.modules[c.__name__] = c
    exec(compile(raw, str(path), "exec"), c.__dict__)
    w = c._probe()
    w._pin(path, LEGACY_SHA)
    return c, w, w._runtime()


def _inventory(runtime, c):
    expected = {*SOURCE_PINS, "process/stdout.log", "process/stderr.log",
                *(path.name for path in c._output_paths(SOURCE))}
    actual = set()
    for path in runtime._resident(SOURCE).iterdir():
        runtime._resident(path)
        if path.is_dir():
            if path.name != "process":
                raise ValueError("unexpected recovery source directory")
            for child in path.iterdir():
                runtime._resident(child)
                if not child.is_file():
                    raise ValueError("nested recovery source output")
                actual.add("process/" + child.name)
        elif path.is_file():
            actual.add(path.name)
        else:
            raise ValueError("nonregular recovery source output")
    if actual != expected:
        raise ValueError("closed recovery inventory differs; unexpected failure or output")


def _reopen_origins(w, runtime, profile, request, origins):
    """Legacy reopen equivalence, with exactly one authenticated zero-byte case."""
    if type(origins) is not dict or set(origins) != {"modules", "absent_cache_paths"}:
        raise ValueError("closed worker-origin observation required")
    if type(origins["modules"]) is not list or not origins["modules"]:
        raise ValueError("worker origin population absent")
    if type(origins["absent_cache_paths"]) is not list:
        raise ValueError("closed absent-cache population required")
    allowed = {row["path"]: row for row in (*profile["file_bindings"], *request["code_bindings"].values())}
    empty_path = str(runtime.BASE_PYTHON / "Lib/urllib/__init__.py")
    empty = {"path": empty_path, "sha256": EMPTY_SHA, "size_bytes": 0}
    w._same(allowed.get(empty_path), empty, "empty urllib source is not exactly authenticated by profile")
    files, names, checked, exceptions = runtime._Files(), set(), set(), []
    for row in origins["modules"]:
        name = row["module"]
        if type(name) is not str or name in names:
            raise ValueError("duplicate or invalid worker origin")
        names.add(name)
        supports = row.get("support_bindings")
        if type(supports) is not list or len(supports) > 1:
            raise ValueError("namespace and pseudo-module support closure absent")
        for item in (row["file_binding"], row["cache_binding"], *supports):
            if item is not None:
                if item == empty:
                    if name != "urllib" or item is not row["file_binding"] or exceptions:
                        raise ValueError("empty source exception is limited to exact urllib file origin")
                    # Canonical equality also rejects booleans masquerading as 0.
                    w._same(item, empty, "empty source binding type differs")
                    exceptions.append(deepcopy(empty))
                else:
                    runtime._binding(item)
                w._same(item, allowed.get(item["path"]), "reported origin outside fixed profile")
                if item["path"] not in checked:
                    files.read(item["path"], cap=runtime.FILE_CAP, expected=item)
                    checked.add(item["path"])
        for value in row.get("namespace_paths", []):
            if value not in profile["population"]["directories"] or not runtime._resident(Path(value)).is_dir():
                raise ValueError("reported namespace outside fixed population")
    if not {"cv2", "numpy", "numpy._core._multiarray_umath", "urllib"}.issubset(names) or exceptions != [empty]:
        raise ValueError("required observed origins or exact empty source absent")
    for path in origins["absent_cache_paths"]:
        if type(path) is not str or os.path.lexists(path):
            raise ValueError("reported absent cache appeared")
    site = Path(profile["site_packages"])
    for item in profile["file_bindings"]:
        path = Path(item["path"])
        if path.suffix.lower() == ".dll" and (path.is_relative_to(site / "cv2") or path.is_relative_to(site / "numpy.libs")):
            if item["path"] not in checked:
                runtime._binding(item)
                files.read(path, cap=runtime.FILE_CAP, expected=item)
                checked.add(item["path"])
    return files, exceptions


def _completed(c, w, runtime, request, request_binding, process, source_files):
    """Replay the frozen _completed checks; no patch to that consumer."""
    request_path, request_sha = Path(request_binding["path"]), request_binding["sha256"][7:]
    for key, value in {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
            "assigned_before_resume": True, "kill_on_close": True, "committed_memory_limit_bytes": w.MEMORY_BYTES,
            "timeout_seconds": float(w.TIMEOUT_SECONDS), "error": None, "release_authority": False, "audio_approved": False}.items():
        w._same(process[key], value, "control worker did not complete inside exact process bounds")
    logs = process["logs"]
    if type(logs) is not list or len(logs) != 2:
        raise ValueError("exact supervised log pair required")
    log_files, log_raw = runtime._Files(), []
    for row, name in zip(logs, ("stdout.log", "stderr.log")):
        if (type(row) is not dict or set(row) != {"path", "sha256", "size"}
                or row["path"] != str(SOURCE / "process" / name)
                or type(row["sha256"]) is not str or len(row["sha256"]) != 64
                or type(row["size"]) is not int or row["size"] < 0):
            raise ValueError("supervised log identity differs")
        log_raw.append(log_files.read(row["path"], cap=1024**2, capture=True,
            expected={"path": row["path"], "sha256": "sha256:" + row["sha256"], "size_bytes": row["size"]}))
    completed = runtime._json(log_raw[0])
    if (type(completed) is not dict or set(completed) != {"controls_sha256"}
            or log_raw[0].strip() != w._canonical(completed)
            or completed["controls_sha256"] != SOURCE_PINS["controls.json"]):
        raise ValueError("unexpected supervised output")
    report_path = SOURCE / "controls.json"
    report = runtime._json(source_files.read(report_path, cap=runtime.METADATA_CAP, capture=True,
        expected=source_files.items[str(report_path)][0]))
    keys = {"version", "status", "request_binding", "profile_binding", "code_bindings", "decode_terminal_binding",
        "model_bindings", "model_loading", "startup", "containment", "native_observation", "origins", "file_validation",
        "profile_validation_calls", "observations", "evaluation", "output_bindings", "inference_calls", "decode_calls",
        "network_calls", "technical_cost_brl", "authority", "elapsed_seconds", "limitations"}
    if type(report) is not dict or set(report) != keys:
        raise ValueError("closed control-worker report required")
    for key in ("profile_binding", "code_bindings", "decode_terminal_binding", "model_bindings", "model_loading"):
        w._same(report[key], request[key], "completed report differs from request")
    w._same(report["model_loading"], c.MODEL_LOADING, "completed model-loading recipe differs")
    for key, value in {"version": c.VERSION, "request_binding": request_binding, "authority": c.AUTHORITY,
            "profile_validation_calls": 1, "inference_calls": 2, "decode_calls": 0, "network_calls": 0,
            "technical_cost_brl": 0, "limitations": c.LIMITATIONS}.items():
        w._same(report[key], value, "completed report scope differs")
    w._same(report["native_observation"]["opencv_native_version"], "5.0.0", "actual OpenCV version differs")
    w._same(report["native_observation"]["numpy_version"], "2.5.2", "actual NumPy version differs")
    w._same(report["file_validation"]["status"], "FILE_PROFILE_VALIDATED_NOT_ADMITTED", "worker validation absent")
    w._same(report["file_validation"]["authority"], runtime.AUTHORITY, "runtime validation authority changed")
    semantics = w._load(c.SEMANTICS, c.SEMANTICS_SHA, "_publicity_recovery_semantics")
    w._same(request["settings"], semantics.SETTINGS, "request detector settings differ from pinned semantics")
    evaluation = semantics.evaluate_controls(report["observations"])
    w._same(report["evaluation"], evaluation, "operational semantics changed")
    w._same(report["status"], "PASS_OPERATIONAL_CONTROLS_ONLY", "fixed operational pair did not pass")
    w._same(report["status"], evaluation["status"], "operational status differs")
    context = c._control_inputs(w, runtime)
    for key in ("controls", "decode_terminal_binding", "model_bindings"):
        w._same(request[key], context[key], "input identity changed before recovery completion")
    for row in report["observations"]:
        w._same(row["observed_opencv_version"], report["native_observation"]["opencv_native_version"],
                "raw was measured under a different actual runtime")
    profile = w._profile(runtime, request["profile_binding"])
    origin_files, exceptions = _reopen_origins(w, runtime, profile, request, report["origins"])
    def close():
        context["files"].recheck()
        c._decode_inventory(runtime)
        log_files.recheck()
        w._recheck(runtime, profile, origin_files, request, request_path, request_sha)
        c._reopen_outputs(w, runtime, SOURCE, report, context["controls"])
        source_files.recheck()
        for path in report["origins"]["absent_cache_paths"]:
            if os.path.lexists(path):
                raise ValueError("cache appeared before recovery completion")
        _inventory(runtime, c)
    close()
    return {"evaluation": evaluation, "source_bindings": [item[0] for item in source_files.items.values()],
        "profile_binding": request["profile_binding"], "original_process": process,
        "empty_source_exception": exceptions[0], "original_inference_calls": report["inference_calls"],
        "original_profile_validation_calls": report["profile_validation_calls"],
        "raw_and_reservation_bindings": report["output_bindings"],
        "stderr_binding": log_files.items[logs[1]["path"]][0], "stderr_preserved": True,
        "historical_origin_module_count": len(report["origins"]["modules"])}, close


def _prepare(root, expected_module_sha, expected_test_sha):
    c, w, runtime = _dependencies()
    if runtime._root(root) != ROOT:
        raise ValueError("fixed recovery project root required")
    code = {"recovery": w._binding(MODULE, expected_module_sha), "test": w._binding(TEST, expected_test_sha)}
    _inventory(runtime, c)
    files, docs = runtime._Files(), {}
    for name, digest in SOURCE_PINS.items():
        path = SOURCE / name
        raw = files.read(path, cap=runtime.METADATA_CAP, capture=True)
        if w._sha(raw) != digest:
            raise ValueError("fixed recovery evidence pin differs: " + name)
        docs[name] = runtime._json(raw)
    request, terminal = docs["request.json"], docs["terminal.json"]
    request_binding = files.items[str(SOURCE / "request.json")][0]
    expected_code = c._codes(w, LEGACY_SHA, LEGACY_TEST_SHA)
    expected_keys = {"version", "root", "profile_binding", "code_bindings", "run_directory", "memory_bytes",
        "timeout_seconds", "authority", "technical_cost_brl", "controls", "decode_terminal_binding",
        "model_bindings", "model_loading", "settings"}
    if type(request) is not dict or set(request) != expected_keys:
        raise ValueError("closed recovery source request required")
    for key, value in {"version": c.VERSION, "root": str(ROOT), "run_directory": str(SOURCE),
            "code_bindings": expected_code, "authority": c.AUTHORITY, "memory_bytes": w.MEMORY_BYTES,
            "timeout_seconds": w.TIMEOUT_SECONDS, "technical_cost_brl": 0, "model_loading": c.MODEL_LOADING}.items():
        w._same(request[key], value, "fixed recovery request differs")
    expected_terminal = {"version": c.VERSION, "status": "CONTROL_WORKER_FAILED_NOT_ADMITTED", "process": terminal["process"],
        "request_binding": request_binding, "controls_binding": None, "authority": c.AUTHORITY,
        "technical_cost_brl": 0, "error": EXPECTED_ERROR, "automatic_retries": 0}
    w._same(terminal, expected_terminal, "only the exact parent-close failure is recoverable")
    w._same(docs["problem.json"], terminal, "problem and original terminal differ")
    w._same(docs["process/process-receipt.json"], terminal["process"],
            "persisted supervisor receipt differs from complete original process")
    data, original_close = _completed(c, w, runtime, request, request_binding, terminal["process"], files)
    def close():
        original_close()
        for item in code.values():
            w._pin(Path(item["path"]), item["sha256"][7:])
    close()
    return c, w, runtime, {"version": VERSION, "status": "PASS_OPERATIONAL_CONTROLS_ONLY",
        "recovery_kind": "CHECKPOINT_RECOVERY", "original_terminal_status": terminal["status"],
        "recovered_failure": EXPECTED_ERROR, "implementation_bindings": code, **data,
        "recovery_inference_calls": 0, "recovery_decode_calls": 0, "recovery_profile_validation_calls": 0,
        "recovery_process_calls": 0, "recovery_network_calls": 0, "technical_cost_brl": 0,
        "authority": dict(AUTHORITY), "limitations": list(LIMITATIONS)}, close


def _receipt_inventory(runtime, directory):
    runtime._resident(directory)
    paths = list(directory.iterdir())
    if len(paths) != 1 or paths[0].name != "receipt.json" or not runtime._resident(paths[0]).is_file():
        raise ValueError("recovery receipt inventory differs or failure marker exists")


def recover(root, *, expected_module_sha, expected_test_sha, run_directory, commit=False):
    """Exclusive separate receipt only after complete metadata replay closes."""
    if type(commit) is not bool:
        raise ValueError("explicit boolean commit required")
    directory = Path(run_directory).absolute()
    prefix = ROOT / "output/qa/phase6/diagnostics"
    if (".." in directory.parts or directory == prefix or not directory.is_relative_to(prefix)
            or directory == SOURCE or directory.is_relative_to(SOURCE) or SOURCE.is_relative_to(directory)):
        raise ValueError("separate recovery diagnostic child required")
    if os.path.lexists(directory):
        raise ValueError("recovery output collision; no overwrite or implicit retry")
    _, w, runtime, data, close = _prepare(root, expected_module_sha, expected_test_sha)
    runtime._resident(directory.parent)
    if not commit:
        close()
        return {"version": VERSION, "status": "PREFLIGHT_ONLY_NO_RECOVERY_RECEIPT", "files_written": 0,
                "recovery_kind": "CHECKPOINT_RECOVERY", "authority": dict(AUTHORITY)}
    directory.mkdir(exist_ok=False)
    try:
        close()
        receipt = {**data, "recovered_at": datetime.now(timezone.utc).isoformat(), "run_directory": str(directory)}
        raw = w._canonical(receipt)
        w._exclusive(directory / "receipt.json", raw)
        close()
        _receipt_inventory(runtime, directory)
        w._pin(directory / "receipt.json", w._sha(raw))
        return receipt
    except Exception as exc:
        w._exclusive(directory / "problem.json", w._canonical({"version": VERSION,
            "status": "RECOVERY_FAILED_NOT_ACCEPTED", "error": {"type": type(exc).__name__, "message": str(exc)},
            "authority": AUTHORITY}))
        raise


def verify_recovery(root, *, receipt_binding, expected_module_sha, expected_test_sha):
    """Consumers must use this replay, never a serialized PASS by itself."""
    _, w, runtime, expected, close = _prepare(root, expected_module_sha, expected_test_sha)
    runtime._binding(receipt_binding)
    path = Path(receipt_binding["path"]).absolute()
    prefix = ROOT / "output/qa/phase6/diagnostics"
    if (path.name != "receipt.json" or ".." in path.parts or not path.is_relative_to(prefix)
            or path.is_relative_to(SOURCE) or SOURCE.is_relative_to(path.parent)):
        raise ValueError("separate recovery receipt required")
    files = runtime._Files()
    raw = files.read(path, cap=runtime.METADATA_CAP, capture=True, expected=receipt_binding)
    receipt = runtime._json(raw)
    stamp = datetime.fromisoformat(receipt["recovered_at"])
    if stamp.utcoffset() is None or not datetime.fromisoformat(expected["original_process"]["finished_at"]) <= stamp <= datetime.now(timezone.utc):
        raise ValueError("recovery timestamp outside historical/current interval")
    w._same(receipt, {**expected, "recovered_at": receipt["recovered_at"], "run_directory": str(path.parent)},
            "persisted recovery differs from complete replay")
    close()
    files.recheck()
    _receipt_inventory(runtime, path.parent)
    return deepcopy(receipt)
