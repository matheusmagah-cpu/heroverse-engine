from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import time
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .google_api_runtime import (
    GOOGLE_OPERATION_DEADLINE_SECONDS,
    GoogleOperationDeadline,
    GoogleOperationDeadlineExceeded,
    build_authorized_service,
    execute_google_request,
)
from .youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
PHASE6 = Path("output/operations/phase6")
PUBLICATION_RECEIPT = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
WINDOWS_HOURS = [0, 24, 72, 168, 336, 720]
OBSERVATION_POLICY_ID = "phase6-owned-observation-policy-v1"
CORE_METRICS = [
    "views", "estimatedMinutesWatched", "averageViewDuration", "averageViewPercentage",
    "subscribersGained", "subscribersLost", "likes", "comments", "shares",
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _serialized_bytes(value: dict[str, Any]) -> bytes:
    """Serialize once so Windows newline translation cannot split twin bytes."""

    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(_serialized_bytes(value))
    temporary.replace(path)


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    """Create one historical JSON record without ever replacing prior bytes."""

    payload = _serialized_bytes(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise PermissionError(f"historical snapshot cannot be a symbolic link: {path.name}")
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable owned-performance snapshot collision: {path.name}")
        return
    try:
        with path.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable owned-performance snapshot collision: {path.name}")


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate(root: Path, schema: str, value: dict[str, Any]) -> None:
    Draft202012Validator(_read(root / "schemas" / schema)).validate(value)


def _duration_seconds(value: str | None) -> int | None:
    if not value:
        return None
    match = re.fullmatch(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", value)
    if not match:
        return None
    hours, minutes, seconds = (int(item or 0) for item in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def _row(report: dict[str, Any]) -> dict[str, Any]:
    headers = [item.get("name") for item in report.get("columnHeaders") or []]
    rows = report.get("rows") or []
    return dict(zip(headers, rows[0], strict=False)) if len(rows) == 1 else {}


def _target_video_id(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", value):
        raise ValueError("invalid YouTube video id")
    return value


def _receipt_path(root: Path, value: Path) -> Path:
    candidate = (root / value).resolve() if not value.is_absolute() else value.resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise PermissionError("publication receipt must remain inside the workspace") from exc
    return candidate


def _owned_reach_evidence(
    root: Path,
    captured: datetime,
    *,
    video_id: str = VIDEO_ID,
) -> tuple[str, str | None, dict[str, Any]]:
    """Resolve only time-valid, exact-video bulk reach evidence."""

    empty = {
        "videoThumbnailImpressions": None,
        "videoThumbnailImpressionsClickRate": None,
    }
    target_video_id = _target_video_id(video_id)
    latest_path = root / "output/operations/phase6/reporting/reach" / target_video_id / "latest.json"
    registry_path = root / "output/operations/phase6/reporting/job-registry.json"
    if latest_path.is_file():
        value = _read(latest_path)
        if value.get("channel_id") != CHANNEL_ID or value.get("video_id") != target_video_id:
            return "FAILED", "REACH_SNAPSHOT_IDENTITY_MISMATCH", empty
        observed_at = value.get("captured_at")
        if not isinstance(observed_at, str) or _parse(observed_at) > captured:
            return "UNAVAILABLE", "NO_TIME_VALID_REACH_SNAPSHOT_AT_CUTOFF", empty
        if value.get("status") == "OBSERVED":
            metrics = value.get("metrics") or {}
            impressions = metrics.get("videoThumbnailImpressions")
            ctr = metrics.get("videoThumbnailImpressionsClickRate")
            if impressions is None:
                return "FAILED", "OBSERVED_REACH_SNAPSHOT_HAS_NULL_IMPRESSIONS", empty
            return "PASS", None, {
                "videoThumbnailImpressions": impressions,
                "videoThumbnailImpressionsClickRate": ctr,
            }
        if value.get("status") == "AWAITING_REPORT":
            return "EMPTY", str(value.get("missing_reason") or "REPORT_NOT_AVAILABLE_YET"), empty
        return "FAILED", str(value.get("source", {}).get("error") or value.get("missing_reason") or "REACH_COLLECTION_FAILED"), empty
    if registry_path.is_file():
        registry = _read(registry_path)
        status = registry.get("status")
        if status in {"ACTIVE_AWAITING_FIRST_REPORT", "ACTIVE_REPORTS_AVAILABLE"}:
            return "EMPTY", status, empty
        if status in {"PARTIAL", "BLOCKED", "ERROR"}:
            return "FAILED", f"REPORTING_JOB_REGISTRY_{status}", empty
    return "UNAVAILABLE", "OWNED_REACH_REPORTING_ADAPTER_NOT_MATERIALIZED", empty


def _observation_policy(root: Path) -> dict[str, int]:
    """Load and strictly bound the zero-cost retry policy."""

    config = _read(root / "config/engine.json") if (root / "config/engine.json").is_file() else {}
    gates = config.get("quality_gates") or {}
    values = {
        "data_lag_retry_interval_minutes": int(gates.get("phase6_data_lag_retry_interval_minutes", 120)),
        "data_lag_retry_window_hours": int(gates.get("phase6_data_lag_retry_window_hours", 12)),
        "source_failure_retry_interval_minutes": int(gates.get("phase6_source_failure_retry_interval_minutes", 30)),
        "source_failure_retry_window_hours": int(gates.get("phase6_source_failure_retry_window_hours", 6)),
    }
    if not 15 <= values["data_lag_retry_interval_minutes"] <= 360:
        raise ValueError("phase6 data-lag retry interval must be between 15 and 360 minutes")
    if not 2 <= values["data_lag_retry_window_hours"] <= 24:
        raise ValueError("phase6 data-lag retry window must be between 2 and 24 hours")
    if not 15 <= values["source_failure_retry_interval_minutes"] <= 120:
        raise ValueError("phase6 source-failure retry interval must be between 15 and 120 minutes")
    if not 1 <= values["source_failure_retry_window_hours"] <= 12:
        raise ValueError("phase6 source-failure retry window must be between 1 and 12 hours")
    return values


def _observation_schedule(
    root: Path,
    *,
    captured: datetime,
    published: datetime,
    age_hours: float,
    snapshot_status: str,
    goal_source_failure: bool = False,
) -> tuple[str | None, dict[str, Any]]:
    """Choose a finite next checkpoint without confusing API lag with evidence.

    Formal windows remain immutable. A PARTIAL_DATA_LAG observation made at or
    after D1 receives short retries only inside a bounded grace period following
    the current formal window. D30 has the same finite grace period and then
    terminates, so no past-due timestamp can create an infinite manager loop.
    """

    policy = _observation_policy(root)
    active_window = max(hours for hours in WINDOWS_HOURS if hours <= age_hours + 0.01)
    next_formal = next((hours for hours in WINDOWS_HOURS if hours > age_hours + 0.01), None)
    next_formal_at = published + timedelta(hours=next_formal) if next_formal is not None else None
    source_failure = snapshot_status == "FAILED" or goal_source_failure
    if source_failure:
        retry_interval_minutes = policy["source_failure_retry_interval_minutes"]
        retry_window_hours = policy["source_failure_retry_window_hours"]
    else:
        retry_interval_minutes = policy["data_lag_retry_interval_minutes"]
        retry_window_hours = policy["data_lag_retry_window_hours"]
    retry_deadline = published + timedelta(hours=active_window + retry_window_hours)
    retry_interval = timedelta(minutes=retry_interval_minutes)
    maximum_retries = retry_window_hours * 60 // retry_interval_minutes
    retry_enabled = captured < retry_deadline and (
        source_failure
        or (snapshot_status == "PARTIAL_DATA_LAG" and active_window >= 24)
    )

    reason = "FORMAL_WINDOW"
    retry_attempt: int | None = None
    next_at = next_formal_at
    if retry_enabled:
        elapsed_since_window = max(0.0, (captured - (published + timedelta(hours=active_window))).total_seconds())
        retry_attempt = min(
            maximum_retries,
            int(elapsed_since_window // retry_interval.total_seconds()) + 1,
        )
        next_at = min(captured + retry_interval, retry_deadline)
        reason = "SOURCE_FAILURE_RETRY" if source_failure else "DATA_LAG_RETRY"
    elif next_formal_at is None:
        reason = "WINDOW_PLAN_COMPLETE"

    value = {
        "policy_id": OBSERVATION_POLICY_ID,
        "reason": reason,
        "active_window_hours": active_window,
        "next_formal_window_hours": next_formal,
        "next_formal_at": next_formal_at.isoformat().replace("+00:00", "Z") if next_formal_at else None,
        "retry": {
            "enabled": retry_enabled,
            "interval_minutes": retry_interval_minutes,
            "attempt": retry_attempt,
            "maximum_attempts": maximum_retries,
            "deadline_at": retry_deadline.isoformat().replace("+00:00", "Z"),
        },
        "terminal": next_at is None,
    }
    return (
        next_at.isoformat().replace("+00:00", "Z") if next_at else None,
        value,
    )


def build_pilot_plan(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    receipt = _read(root.resolve() / PUBLICATION_RECEIPT)
    if receipt.get("status") != "COMPLETE_PUBLIC" or receipt.get("video_id") != VIDEO_ID:
        raise PermissionError("Phase 6 requires the exact completed public canary receipt")
    value = {
        "schema_version": "1.0.0",
        "plan_id": "heroverse-phase6-controlled-longform-v1",
        "phase": 6,
        "status": "ACTIVE",
        "channel": {"channel_id": CHANNEL_ID, "handle": "@heroverse74", "language": "en-US", "niche": "English Christian motivation"},
        "scope": {
            "format_pack_id": "fp-broll-cinematic-narration", "format_pack_version": "1.1.0",
            "capability_status": "LIMITED", "pipeline_id": "pipeline-clips-longform-v1",
            "quality_profile": "STANDARD", "other_channels_allowed": False,
        },
        "lot": {
            "maximum_long_videos": 3, "published_video_ids": [VIDEO_ID],
            "next_video_not_before_checkpoint": "24H_CANARY_OBSERVATION",
            "expansion_policy": "Video 2 requires a 24-hour owned-metrics snapshot, no policy/rights/quality incident, a fresh autonomous release PASS and an updated LIMITED contract. Video 3 repeats the same rule and triggers the mandatory sampled audit.",
        },
        "observation_windows_hours": WINDOWS_HOURS,
        "stage_gates": [
            "exact channel and publication receipt", "owned-metrics provenance and API status",
            "no policy, copyright, publicity or quality incident", "automatic per-release quality PASS",
            "FormatPack limitation contract permits the next release", "zero technical cost and free quota margin",
            "no performance claim before comparable observation",
        ],
        "review_policy": {
            "automatic_per_release": True, "routine_human_sample_rate": 0.1,
            "mandatory_exception_triggers": ["critical uncertainty/failure", "version or tool drift", "rights/publicity ambiguity", "complaint or anomaly", "third LIMITED video checkpoint"],
        },
        "ads": {"enabled": False, "budget_brl": 0, "reason": "No explicit media budget exists; campaign traffic would not count as qualified YPP progress."},
        "cost": {"technical_cost_brl": 0, "external_tool_cost_brl": 0},
        "claim_boundary": [
            "The three-video maximum is a controlled learning lot, not a promised publishing volume.",
            "The second and third releases remain conditional and cannot bypass quality, rights, policy or capability gates.",
            "No view, retention, subscriber, watch-hour, monetization or revenue result is guaranteed.",
        ],
        "created_at": created_at or _now(),
    }
    _validate(root.resolve(), "phase6_pilot_plan.schema.json", value)
    return value


def materialize_plan(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    path = root / PHASE6 / "pilot-plan.json"
    value = build_pilot_plan(root, created_at=created_at)
    if path.is_file():
        prior = _read(path)
        left, right = dict(prior), dict(value)
        left.pop("created_at", None)
        right.pop("created_at", None)
        if left == right:
            return path
    _write(path, value)
    return path


def collect_video_snapshot(
    youtube: Any,
    analytics: Any,
    root: Path = ROOT,
    *,
    video_id: str,
    publication_receipt: Path,
    captured_at: str | None = None,
    deadline: GoogleOperationDeadline | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    target_video_id = _target_video_id(video_id)
    timestamp = captured_at or _now()
    captured = _parse(timestamp)
    receipt_path = _receipt_path(root, publication_receipt)
    receipt = _read(receipt_path)
    phase6_video2_receipt = (
        root
        / "output/production/phase6/video-002/publication/youtube-publication-receipt.json"
    ).resolve()
    if receipt_path.resolve() == phase6_video2_receipt:
        from .phase6_publication import verify_phase6_publication_receipt

        receipt = verify_phase6_publication_receipt(
            root,
            receipt_path=receipt_path,
            require_complete=True,
        )
    if (
        receipt.get("status") != "COMPLETE_PUBLIC"
        or receipt.get("video_id") != target_video_id
        or receipt.get("channel_id") != CHANNEL_ID
    ):
        raise PermissionError("The exact completed public-video receipt is required")
    operation_deadline = deadline or GoogleOperationDeadline()

    data_error: str | None = None
    channel_error: str | None = None
    analytics_error: str | None = None
    retention_error: str | None = None
    item: dict[str, Any] = {}
    try:
        response = execute_google_request(
            youtube.videos().list(
                part="id,snippet,statistics,contentDetails,status", id=target_video_id,
                fields="items(id,snippet(channelId,publishedAt,title),statistics,contentDetails/duration,status(privacyStatus,uploadStatus))",
            ),
            deadline=operation_deadline,
            stage="youtube.videos.list",
        )
        items = response.get("items") or []
        item = items[0] if len(items) == 1 else {}
        if (
            item.get("id") != target_video_id
            or item.get("snippet", {}).get("channelId") != CHANNEL_ID
            or item.get("status", {}).get("privacyStatus") != "public"
        ):
            raise PermissionError("Public video identity/state mismatch")
    except (PermissionError, GoogleOperationDeadlineExceeded):
        raise
    except Exception as exc:
        data_error = f"{type(exc).__name__}: {exc}"

    channel_metrics: dict[str, Any] = {
        "channelId": None,
        "subscriberCount": None,
        "subscriberCountPrecision": "UNAVAILABLE",
        "hiddenSubscriberCount": None,
        "videoCount": None,
        "viewCount": None,
    }
    channel_source_status = "FAILED"
    channel_source_error: str | None = None
    try:
        channel_response = execute_google_request(
            youtube.channels().list(
                part="id,statistics",
                mine=True,
                fields="items(id,statistics(subscriberCount,hiddenSubscriberCount,videoCount,viewCount))",
            ),
            deadline=operation_deadline,
            stage="youtube.channels.list.mine",
        )
        channel_items = channel_response.get("items") or []
        channel_item = channel_items[0] if len(channel_items) == 1 else {}
        if channel_item.get("id") != CHANNEL_ID:
            raise PermissionError("Authenticated channel identity mismatch")
        statistics = channel_item.get("statistics") or {}
        channel_metrics = {
            "channelId": channel_item["id"],
            "subscriberCount": int(statistics["subscriberCount"]) if statistics.get("subscriberCount") is not None else None,
            "subscriberCountPrecision": "PUBLIC_ROUNDED_TO_THREE_SIGNIFICANT_FIGURES" if statistics.get("subscriberCount") is not None else "UNAVAILABLE",
            "hiddenSubscriberCount": bool(statistics["hiddenSubscriberCount"]) if statistics.get("hiddenSubscriberCount") is not None else None,
            "videoCount": int(statistics["videoCount"]) if statistics.get("videoCount") is not None else None,
            "viewCount": int(statistics["viewCount"]) if statistics.get("viewCount") is not None else None,
        }
        if channel_metrics["subscriberCount"] is not None:
            channel_source_status = "PASS"
        else:
            channel_source_status = "EMPTY"
            channel_source_error = (
                "HIDDEN_SUBSCRIBER_COUNT"
                if channel_metrics["hiddenSubscriberCount"] is True
                else "SUBSCRIBER_COUNT_NOT_RETURNED"
            )
    except GoogleOperationDeadlineExceeded:
        raise
    except Exception as exc:
        channel_error = f"{type(exc).__name__}: {exc}"
        channel_source_error = channel_error

    published_at = (
        item.get("snippet", {}).get("publishedAt")
        or receipt.get("updated_at")
        or receipt["created_at"]
    )
    published = _parse(published_at)
    age_hours = round(max(0.0, (captured - published).total_seconds() / 3600), 6)
    start_date = published.date().isoformat()
    end_date = captured.date().isoformat()

    private: dict[str, Any] = {name: None for name in CORE_METRICS}
    try:
        report = execute_google_request(
            analytics.reports().query(
                ids="channel==MINE", startDate=start_date, endDate=end_date,
                metrics=",".join(CORE_METRICS), filters=f"video=={target_video_id}",
            ),
            deadline=operation_deadline,
            stage="youtubeAnalytics.reports.query.core",
        )
        private.update(_row(report))
        analytics_status = "PASS" if report.get("rows") else "EMPTY"
    except GoogleOperationDeadlineExceeded:
        raise
    except Exception as exc:
        analytics_error = f"{type(exc).__name__}: {exc}"
        analytics_status = "FAILED"

    private.update({"videoThumbnailImpressions": None, "videoThumbnailImpressionsClickRate": None, "intro30sAudienceWatchRatio": None})
    reach_status, reach_error, reach_metrics = _owned_reach_evidence(
        root, captured, video_id=target_video_id,
    )
    private.update(reach_metrics)

    retention_status = "UNAVAILABLE"
    try:
        retention = execute_google_request(
            analytics.reports().query(
                ids="channel==MINE", startDate=start_date, endDate=end_date,
                metrics="audienceWatchRatio", dimensions="elapsedVideoTimeRatio",
                filters=f"video=={target_video_id}", sort="elapsedVideoTimeRatio",
            ),
            deadline=operation_deadline,
            stage="youtubeAnalytics.reports.query.retention",
        )
        headers = [entry.get("name") for entry in retention.get("columnHeaders") or []]
        rows = [dict(zip(headers, row, strict=False)) for row in retention.get("rows") or []]
        duration = _duration_seconds(item.get("contentDetails", {}).get("duration")) or 239
        target_ratio = min(1.0, 30 / duration)
        nearest = min(rows, key=lambda row: abs(float(row["elapsedVideoTimeRatio"]) - target_ratio)) if rows else None
        if nearest:
            private["intro30sAudienceWatchRatio"] = nearest.get("audienceWatchRatio")
            retention_status = "PASS"
        else:
            retention_status = "EMPTY"
    except GoogleOperationDeadlineExceeded:
        raise
    except Exception as exc:
        retention_error = f"{type(exc).__name__}: {exc}"
        retention_status = "UNAVAILABLE"

    public = {
        "title": item.get("snippet", {}).get("title"),
        "privacyStatus": item.get("status", {}).get("privacyStatus"),
        "uploadStatus": item.get("status", {}).get("uploadStatus"),
        "durationSeconds": _duration_seconds(item.get("contentDetails", {}).get("duration")),
        "viewCount": (
            int(item.get("statistics", {})["viewCount"])
            if item and item.get("statistics", {}).get("viewCount") is not None
            else None
        ),
        "likeCount": int(item.get("statistics", {}).get("likeCount", 0)) if item.get("statistics", {}).get("likeCount") is not None else None,
        "commentCount": int(item.get("statistics", {}).get("commentCount", 0)) if item.get("statistics", {}).get("commentCount") is not None else None,
    }
    required = ["views", "estimatedMinutesWatched", "averageViewDuration", "averageViewPercentage", "subscribersGained", "intro30sAudienceWatchRatio"]
    advisory = ["videoThumbnailImpressions", "videoThumbnailImpressionsClickRate"]
    missing_required = sorted(name for name in required if private.get(name) is None)
    missing = sorted(name for name in required + advisory if private.get(name) is None)
    data_status = "FAILED" if data_error else "PASS"
    snapshot_status = "FAILED" if data_error else ("OBSERVED" if analytics_status == "PASS" and not missing_required else "PARTIAL_DATA_LAG")
    eligible = age_hours >= 24 and not missing_required and snapshot_status == "OBSERVED"
    goal_source_recoverable = channel_source_status == "FAILED" or (
        channel_source_status == "EMPTY" and channel_metrics["hiddenSubscriberCount"] is not True
    )
    next_observation_at, observation_schedule = _observation_schedule(
        root,
        captured=captured,
        published=published,
        age_hours=age_hours,
        snapshot_status=snapshot_status,
        goal_source_failure=goal_source_recoverable,
    )
    goal_retrying = goal_source_recoverable and observation_schedule["retry"]["enabled"]
    if channel_source_status == "PASS":
        goal_measurement_status = "OBSERVED"
    elif goal_retrying:
        goal_measurement_status = "RETRYING_SOURCE_FAILURE"
    elif goal_source_recoverable:
        goal_measurement_status = "SOURCE_FAILURE_RETRY_EXHAUSTED"
    else:
        goal_measurement_status = "UNAVAILABLE_HIDDEN_SUBSCRIBER_COUNT"
    value = {
        "schema_version": "1.3.0",
        "snapshot_id": f"own-performance-{target_video_id}-{captured.strftime('%Y%m%dT%H%M%SZ')}",
        "phase": 6, "channel_id": CHANNEL_ID, "video_id": target_video_id,
        "captured_at": timestamp, "published_at": published_at,
        "age_hours": age_hours, "status": snapshot_status,
        "sources": {
            "youtube_data_api": {"status": data_status, "method": "videos.list exact owned public video", "error": data_error},
            "youtube_channel_api": {"status": channel_source_status, "method": "channels.list mine exact authenticated channel statistics", "error": channel_source_error},
            "youtube_analytics_api": {"status": analytics_status, "method": "reports.query channel==MINE filtered by exact video", "error": analytics_error},
            "reach_reporting_api": {"status": reach_status, "method": "YouTube Reporting API channel_reach_basic_a1 bulk report", "error": reach_error},
            "retention_api": {"status": retention_status, "method": "elapsedVideoTimeRatio nearest to 30 seconds", "error": retention_error},
        },
        "public_metrics": public,
        "channel_metrics": channel_metrics,
        "goal_measurement": {
            "status": goal_measurement_status,
            "subscriber_count_observed": channel_source_status == "PASS",
            "next_retry_at": next_observation_at if goal_retrying else None,
            "retry_exhausted": goal_measurement_status == "SOURCE_FAILURE_RETRY_EXHAUSTED",
            "blocking_reason": channel_source_error,
        },
        "private_metrics": private, "missing_metrics": missing,
        "decision_status": "ELIGIBLE_FOR_COMPARISON" if eligible else ("INVALID_OBSERVATION" if snapshot_status == "FAILED" else "INSUFFICIENT_DATA"),
        "next_observation_at": next_observation_at,
        "observation_schedule": observation_schedule,
        "publication_receipt": {"path": receipt_path.relative_to(root).as_posix(), "sha256": _hash(receipt_path), "status": "COMPLETE_PUBLIC"},
        "technical_cost_brl": 0,
        "claim_boundary": [
            "Analytics data can lag after publication; null is not zero.",
            "A snapshot younger than 24 hours cannot trigger a scale/stop decision.",
            "Reach metrics remain advisory and null until the bulk Reporting API adapter produces an owned report; they are never replaced by a provider score.",
            "Campaign-derived YPP progress is not counted and no campaign is active.",
            "The public subscriberCount is recorded with the YouTube Data API precision boundary and is not presented as an unrounded private counter.",
            "A recoverable channel-statistics failure receives its own finite retry without invalidating otherwise complete video-performance evidence.",
        ],
    }
    _validate(root, "own_channel_performance_snapshot.schema.json", value)
    return value


def collect_snapshot(
    youtube: Any,
    analytics: Any,
    root: Path = ROOT,
    *,
    captured_at: str | None = None,
) -> dict[str, Any]:
    """Backward-compatible collector for the immutable Phase 5 canary."""

    return collect_video_snapshot(
        youtube,
        analytics,
        root,
        video_id=VIDEO_ID,
        publication_receipt=PUBLICATION_RECEIPT,
        captured_at=captured_at,
    )


def _build_services(token_path: Path, *, request_timeout_seconds: float = 30.0) -> tuple[Any, Any]:
    from google.oauth2.credentials import Credentials  # type: ignore

    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("Central OAuth health must refresh the access token before metrics collection")
    return (
        build_authorized_service(
            "youtube", "v3", credentials=credentials,
            request_timeout_seconds=request_timeout_seconds,
        ),
        build_authorized_service(
            "youtubeAnalytics", "v2", credentials=credentials,
            request_timeout_seconds=request_timeout_seconds,
        ),
    )


def materialize_video_live(
    root: Path = ROOT,
    *,
    token_path: Path,
    video_id: str,
    publication_receipt: Path,
    captured_at: str | None = None,
    immutable_destination: Path | None = None,
    progress: Callable[[], Any] | None = None,
    deadline_seconds: float = GOOGLE_OPERATION_DEADLINE_SECONDS,
    package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None,
    expected_release_hash: str | None = None,
) -> Path:
    root = root.resolve()
    from .central_manager_phase5 import ensure_oauth_session_health

    admission_started = time.monotonic()
    # Receipt identity is checked before OAuth/network setup.  The collector
    # repeats the check at its own effect boundary.
    target_receipt = _receipt_path(root, publication_receipt)
    selected = package_relative is not None
    if selected:
        relative = Path(package_relative)
        package = (root / relative).resolve()
        if (relative.is_absolute() or '..' in relative.parts
                or not package.is_relative_to(root / 'output/production')
                or target_receipt != package / 'youtube-publication-receipt.json'
                or current_bindings is None or expected_release_hash is None):
            raise PermissionError('Current observation requires exact package/receipt/release bindings')
        from .phase5_youtube_publisher import _validate_current_release, execute_publication_pipeline
        # Reuse the complete effect-chain reader; a status string or historical
        # canary receipt cannot grant authority to observe another delivery.
        _validate_current_release(root, relative, current_bindings, expected_release_hash)
        completed = execute_publication_pipeline(None, None, root,
            package_relative=relative, current_bindings=current_bindings,
            expected_release_hash=expected_release_hash)
        if completed.get('status') != 'COMPLETE_PUBLIC' or completed.get('video_id') != video_id:
            raise PermissionError('Current observation publication identity differs')
        publication_bytes = target_receipt.read_bytes()
    elif current_bindings is not None or expected_release_hash is not None:
        raise PermissionError('Current observation bindings require an explicit package')
    initial_receipt = _read(target_receipt)
    if not (
        initial_receipt.get("status") == "COMPLETE_PUBLIC"
        and initial_receipt.get("video_id") == _target_video_id(video_id)
        and initial_receipt.get("channel_id") == CHANNEL_ID
    ):
        raise PermissionError("The exact completed public-video receipt is required before OAuth")
    # Local authenticity checks can reopen large immutable profiles. They are
    # not Google requests and must finish before starting the network budget.
    if selected and captured_at is not None:
        captured_at = (datetime.fromisoformat(captured_at.replace('Z', '+00:00'))
            + timedelta(seconds=time.monotonic() - admission_started)).astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')
    deadline = GoogleOperationDeadline(deadline_seconds, progress=progress)
    deadline.pulse("oauth.phase6-pilot:before")
    health = ensure_oauth_session_health(root, token_path, deadline=deadline)
    deadline.pulse("oauth.phase6-pilot:after")
    if health["status"] not in {"HEALTHY", "REFRESHED"}:
        raise PermissionError(f"OAuth health blocks collection: {health['status']}")
    deadline.pulse("google.discovery.phase6-pilot:before")
    youtube, analytics = _build_services(
        token_path,
        request_timeout_seconds=deadline.request_timeout(
            "google.discovery.phase6-pilot:transport"
        ),
    )
    deadline.pulse("google.discovery.phase6-pilot:after")
    value = collect_video_snapshot(
        youtube,
        analytics,
        root,
        video_id=video_id,
        publication_receipt=publication_receipt,
        captured_at=captured_at,
        deadline=deadline,
    )
    if selected:
        _validate_current_release(root, relative, current_bindings, expected_release_hash)
        if target_receipt.read_bytes() != publication_bytes:
            raise PermissionError('Current observation receipt changed during collection')
    if progress is not None:
        # Network is finished. Keep the native job lease current through local
        # closing verification without resetting/extending the Google budget.
        progress()
    # A transactional caller may nominate its own immutable journal target.
    # Persist that copy first: once collection returns successfully, every
    # later retry can recover from the job-owned bytes even if writing the
    # shared historical/latest views fails or the process exits.
    job_path: Path | None = None
    if immutable_destination is not None:
        job_path = immutable_destination.resolve()
        try:
            job_path.relative_to(root)
        except ValueError as exc:
            raise PermissionError("immutable snapshot destination must remain inside the workspace") from exc
        _write_immutable(job_path, value)
    folder = root / PHASE6 / "metrics" / value["video_id"]
    path = folder / f"{value['snapshot_id']}.json"
    _write_immutable(path, value)
    _write(folder / "latest.json", value)
    return job_path or path


def materialize_live(
    root: Path = ROOT,
    *,
    token_path: Path,
    captured_at: str | None = None,
    immutable_destination: Path | None = None,
    progress: Callable[[], Any] | None = None,
    deadline_seconds: float = GOOGLE_OPERATION_DEADLINE_SECONDS,
) -> Path:
    """Backward-compatible materializer for the immutable Phase 5 canary."""

    return materialize_video_live(
        root,
        token_path=token_path,
        video_id=VIDEO_ID,
        publication_receipt=PUBLICATION_RECEIPT,
        captured_at=captured_at,
        immutable_destination=immutable_destination,
        progress=progress,
        deadline_seconds=deadline_seconds,
    )


def resolve_runtime_token(root: Path = ROOT) -> Path:
    configured = os.environ.get("HERO_YT_TOKEN_PATH")
    if configured:
        return Path(configured).resolve()
    watcher = root.resolve() / "output/runtime/gestor-central/oauth-reconsent-watcher.json"
    if watcher.is_file():
        destination = _read(watcher).get("destination_path")
        if isinstance(destination, str) and destination:
            candidate = Path(destination).resolve()
            try:
                candidate.relative_to(root.resolve())
            except ValueError:
                return candidate
    raise FileNotFoundError("The external runtime token path is not configured; interactive login is not started by the observer")


def main() -> None:
    parser = argparse.ArgumentParser(description="Materialize the controlled Phase 6 plan and an authenticated own-channel snapshot")
    parser.add_argument("--collect", action="store_true")
    args = parser.parse_args()
    print(materialize_plan(ROOT))
    if args.collect:
        print(materialize_live(ROOT, token_path=resolve_runtime_token(ROOT)))


if __name__ == "__main__":
    main()
