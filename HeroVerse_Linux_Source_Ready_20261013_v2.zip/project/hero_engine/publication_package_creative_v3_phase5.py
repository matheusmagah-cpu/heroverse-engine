from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .db import ROOT


PILOT = Path("output/production/phase5/pilot-001")
V3 = PILOT / "creative-v3"
EXPECTED_CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
WORKING_TITLE = "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation"
TITLE = "The 24-Hour Test: What To Do After You Pray"
DESCRIPTION = """Prayer is preparation—not the finish line. If you have been waiting for certainty, use this simple three-test framework to choose a faithful next step today.

Ask:
1. Is it true?
2. What responsibility does it accept?
3. Can I act on it today?

This original Christian motivation message draws from James 1:2–8 and James 1:22–25. It does not promise that every opportunity is a sign from God or that one action guarantees an outcome. Prayer, Scripture, honest responsibility, trusted counsel, safe boundaries and concrete action belong together.

Write down one truthful and responsible step you can take in the next 24 hours.

Subscribe to HeroVerse for original Christian motivation about faith, wisdom, character and action.

Visual credits:
• “Madeira Levada- Ponta Delgada - Sao Jorge” — Madeira Levadas, CC BY 3.0: https://commons.wikimedia.org/wiki/File:Madeira_Levada-_Ponta_Delgada_-_Sao_Jorge.webm
• “Hunt and peck typing — Monkeytype benchmark” — C40115, CC BY 4.0: https://commons.wikimedia.org/wiki/File:Hunt_and_peck_typing_%E2%80%94_Monkeytype_benchmark.webm
• “Timelapse 2025 Kinnaur Monsoon” — Dfromhimalayas, CC BY 4.0: https://commons.wikimedia.org/wiki/File:Timelapse_2025_Kinnaur_Monsoon.webm
• “Oberer Vallüla-Bach Zeitlupe” — Stefan W. Wolf, CC BY 4.0: https://commons.wikimedia.org/wiki/File:Oberer_Vall%C3%BCla-Bach_Zeitlupe_Stefan-W-Wolf_Wikipedia.webm
• “Mount Bromo HD Timelapse Movie” — Justin Ng, CC BY 3.0: https://commons.wikimedia.org/wiki/File:Mount_Bromo_HD_Timelapse_Movie_by_Justin_Ng.webm

Other included footage is public domain or CC0; full source and license evidence is preserved in the production record.

#ChristianMotivation #Prayer #FaithInAction"""
TAGS = [
    "Christian motivation", "after prayer", "what to do after praying",
    "faith in action", "James 1", "biblical wisdom", "Christian devotional",
    "spiritual growth", "prayer and action", "Christian encouragement",
    "trusted counsel", "HeroVerse",
]


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _assert_hash(path: Path, expected: str, label: str) -> None:
    actual = _sha256(path)
    if actual != expected.removeprefix("sha256:"):
        raise ValueError(f"{label} hash mismatch: expected {expected}, observed sha256:{actual}")


def build_metadata_packaging_decision(*, created_at: str) -> dict[str, Any]:
    """Return the versioned, non-causal packaging decision for the frozen video.

    The video itself was qualified under ``WORKING_TITLE``.  A packaging title
    can be improved without mutating the frozen media, but the provider score is
    only auxiliary evidence and never substitutes for CTR after publication.
    """

    candidates = [
        {
            "title": WORKING_TITLE,
            "provider_score": 82,
            "editorial_status": "BASELINE",
            "reason": "Accurate, but generic and does not expose the distinctive twenty-four-hour mechanism.",
        },
        {
            "title": TITLE,
            "provider_score": 91,
            "editorial_status": "SELECTED",
            "reason": "Accurate to the script, names the distinctive mechanism, preserves the prayer/action promise and makes no guaranteed-outcome claim.",
        },
        {
            "title": "Prayer Isn't The End. Why You're Missing The Next Step",
            "provider_score": 96,
            "editorial_status": "REJECTED_EDITORIAL_RISK",
            "reason": "Higher provider score, but the accusatory 'you're missing' frame is less faithful to the supportive HeroVerse voice.",
        },
        {
            "title": "Why Your Prayers Don't Feel Like They Work",
            "provider_score": 93,
            "editorial_status": "REJECTED_PROMISE_MISMATCH",
            "reason": "Changes the thesis toward prayer not working and risks a promise the video does not deliver.",
        },
    ]
    decision_basis = "|".join(f"{item['title']}:{item['provider_score']}:{item['editorial_status']}" for item in candidates)
    decision_id = "metadata-packaging-" + hashlib.sha256(decision_basis.encode("utf-8")).hexdigest()[:20]
    return {
        "schema_version": "1.0.0",
        "decision_id": decision_id,
        "video_sha256": "33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c",
        "working_title": WORKING_TITLE,
        "selected_title": TITLE,
        "selection_status": "SELECTED_BY_AUTONOMOUS_EDITORIAL_RUBRIC",
        "provider": "vidIQ Codex plugin",
        "provider_observation_ref": "output/market/vidiq/heroverse/2026-09-03/plugin-observation.json",
        "candidates": candidates,
        "editorial_checks": {
            "promise_fidelity": "PASS",
            "channel_dna": "PASS",
            "specificity": "PASS",
            "policy_risk": "PASS",
            "guaranteed_outcome_claim": False,
        },
        "claim_boundary": [
            "A provider score is an auxiliary heuristic, not a CTR forecast or a viral-result guarantee.",
            "The title is selected by the autonomous editorial-fidelity rubric; owned CTR remains the only performance test.",
            "Only post-publication impressions, CTR, retention and qualified YPP progress can evaluate performance.",
        ],
        "external_cost_brl": 0,
        "created_at": created_at,
    }


def build_creative_v3_publication_package(root: Path = ROOT) -> dict[str, Any]:
    v3 = root / V3
    render = _read(v3 / "render_manifest.json")
    qa = _read(v3 / "qa/creative_quality_gate_report.json")
    metrics = _read(v3 / "qa/creative_revision_metrics.json")
    thumbs = _read(v3 / "thumbnail/thumbnail_set_manifest.json")
    technical = _read(v3 / "qa/technical_measurements.json")
    standard = _read(v3 / "standard-qualification/standard_qualification_report.json")
    pack = _read(root / "config/format_packs/fp-broll-cinematic-narration-v1.json")
    autonomous_path = v3 / "autonomous-review/autonomous_quality_evaluation.json"
    autonomous = _read(autonomous_path) if autonomous_path.is_file() else None
    autonomous_ready = bool(
        autonomous
        and autonomous.get("decision") == "PASS_LIMITED_CANARY"
        and autonomous.get("publication_eligible") is True
        and not autonomous.get("blockers")
    )

    automatic_pass = metrics["automatic_status"] == "PASS"
    if qa["human_review"]["status"] != "PENDING" or qa["publication_eligible"]:
        raise ValueError("Base QA must remain fail-closed; autonomous release authority is a separate artifact")
    if thumbs["selected_candidate"] is not None:
        raise ValueError("This package must not self-select a thumbnail")
    if standard["automatic_profile_status"] != "PASS" or standard["production_approved"] or standard["publication_eligible"]:
        raise ValueError("Publication package requires a measured, fail-closed STANDARD qualification candidate")

    recommended_id = autonomous["thumbnail_selection"]["candidate_id"] if autonomous_ready else thumbs["automatic_recommendation"]
    thumb = next(item for item in thumbs["candidates"] if item["candidate_id"] == recommended_id)
    render_path = Path(standard["candidate"]["path"])
    thumb_path = Path(thumb["path"])
    caption_path = Path(technical["captions"]["path"])
    _assert_hash(render_path, standard["candidate"]["content_hash"], "STANDARD candidate")
    _assert_hash(thumb_path, thumb["content_hash"], "automatic thumbnail candidate")
    _assert_hash(caption_path, technical["captions"]["content_hash"], "caption sidecar")

    receipt_path = root / "output/integrations/youtube/heroverse/connection-receipt.json"
    operational_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    channel_audit_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    receipt = _read(receipt_path) if receipt_path.is_file() else None
    operational = _read(operational_path) if operational_path.is_file() else None
    channel_audit = _read(channel_audit_path) if channel_audit_path.is_file() else None
    connected = bool(
        receipt
        and receipt.get("status") == "CONNECTED"
        and receipt.get("identity_verified")
        and (receipt.get("expected_channel") or {}).get("channel_id") == EXPECTED_CHANNEL_ID
        and (receipt.get("observed_channel") or {}).get("channel_id") == EXPECTED_CHANNEL_ID
        and (receipt.get("observed_channel") or {}).get("custom_url", "").lower() == "@heroverse74"
    )
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    metadata_decision = build_metadata_packaging_decision(created_at=created_at)
    package_hash = hashlib.sha256(
        f"{standard['qualification_id']}|{standard['candidate']['content_hash']}|{thumbs['set_id']}|{TITLE}".encode()
    ).hexdigest()[:20]
    reasons = [] if autonomous_ready else [
        "autonomous twelve-gate visual/audio/semantic review has not passed",
        "FormatPack is not yet usable under LIMITED or PRODUCTION_READY status",
    ]
    if not operational or not operational.get("continuous_operation_ready"):
        reasons.append("OAuth continuous-operation readiness is not proven")
    if not automatic_pass:
        reasons.insert(0, "the expanded visual anti-repetition gate failed; this candidate requires creative remediation and requalification")
    if not channel_audit or channel_audit.get("overall_status") != "PASS":
        reasons.append("channel readiness has critical open gates")

    return {
        "schema_version": "1.0.0",
        "package_id": f"publication-package-v3-{package_hash}",
        "status": "READY_AUTONOMOUS_LIMITED" if autonomous_ready and pack["capability_status"] == "LIMITED" else ("BLOCKED_PENDING_HUMAN_REVIEW" if automatic_pass else "BLOCKED_AUTOMATIC_QUALITY"),
        "channel": {"channel_id": EXPECTED_CHANNEL_ID, "handle": "@heroverse74", "language": "en-US"},
        "video": {
            "render_id": standard["qualification_id"], "path": str(render_path),
            "sha256": standard["candidate"]["content_hash"].removeprefix("sha256:"),
            "size_bytes": standard["candidate"]["size_bytes"], "duration_ms": standard["candidate"]["duration_ms"],
            "width": render["output"]["width"], "height": render["output"]["height"],
            "fps": int(render["output"]["fps"]),
        },
        "thumbnail": {
            "path": str(thumb_path), "sha256": thumb["content_hash"].removeprefix("sha256:"),
            "size_bytes": thumb["size_bytes"], "width": thumb["width"], "height": thumb["height"],
            "text": thumb["text"], "candidate_id": thumb["candidate_id"],
            "selection_status": "SELECTED_BY_AUTONOMOUS_EDITORIAL_RUBRIC" if autonomous_ready else thumbs["selection_status"],
        },
        "metadata": {
            "title": TITLE, "description": DESCRIPTION, "tags": TAGS, "category_id": "27",
            "default_language": "en", "default_audio_language": "en",
            "made_for_kids": False, "privacy_status": "private",
        },
        "metadata_decision": {
            "decision_id": metadata_decision["decision_id"],
            "path": str(v3 / "metadata_packaging_decision.json"),
            "selected_title": metadata_decision["selected_title"],
            "selection_status": metadata_decision["selection_status"],
            "provider_score": next(item["provider_score"] for item in metadata_decision["candidates"] if item["editorial_status"] == "SELECTED"),
            "provider_score_is_causal": False,
        },
        "disclosure": {
            "contains_synthetic_media": True,
            "reason": "The video contains original photorealistic AI-generated illustrative scenes that did not occur.",
            "api_field": "status.containsSyntheticMedia",
        },
        "rights": {
            "status": "PASS_AUTOMATIC", "manifest": str(v3 / "asset_manifest.allocated.json"),
            "attribution": str(v3 / "attribution.txt"), "required_attributions_in_description": True,
        },
        "quality_gate": {
            "report_id": qa["report_id"], "report": str(v3 / "qa/creative_quality_gate_report.json"),
            "automatic_status": metrics["automatic_status"],
            "human_review": "NOT_REQUIRED_PER_RELEASE" if autonomous_ready else qa["human_review"]["status"],
            "autonomous_review": str(autonomous_path) if autonomous else None,
            "human_review_policy": "CALIBRATION_AND_EXCEPTION_SAMPLING" if autonomous_ready else "PER_RELEASE",
            "publication_eligible": autonomous_ready and pack["capability_status"] == "LIMITED" and pack["production_allowed"],
            "standard_qualification_id": standard["qualification_id"],
            "standard_qualification_report": str(v3 / "standard-qualification/standard_qualification_report.json"),
        },
        "integration": {
            "integration_id": "youtube-heroverse-v1",
            "connection_status": "CONNECTED" if connected else ("FAILED" if receipt else "PENDING_AUTHORIZATION"),
            "identity_verified": connected, "receipt": str(receipt_path) if receipt else None,
            "continuous_operation_ready": bool(operational and operational.get("continuous_operation_ready")),
            "durability_status": operational.get("durability_status") if operational else "UNAVAILABLE",
            "operational_readiness": str(operational_path) if operational else None,
        },
        "channel_readiness": {
            "audit": str(channel_audit_path) if channel_audit else None,
            "overall_status": channel_audit.get("overall_status") if channel_audit else "UNAVAILABLE",
            "critical_open_gates": channel_audit.get("publication_gate", {}).get("critical_open_gates", []) if channel_audit else [],
            "pass": bool(channel_audit and channel_audit.get("overall_status") == "PASS"),
        },
        "publication_policy": {
            "upload_permitted": autonomous_ready and pack["capability_status"] == "LIMITED" and pack["production_allowed"], "reason": reasons,
            "next_allowed_action": "AUTONOMOUS_PRIVATE_FIRST_UPLOAD" if autonomous_ready and pack["capability_status"] == "LIMITED" else ("INDEPENDENT_HUMAN_REVIEW" if automatic_pass else "CREATIVE_REMEDIATION_AND_REQUALIFICATION"),
        },
        "captions": {
            "path": str(caption_path), "sha256": technical["captions"]["content_hash"].removeprefix("sha256:"),
            "language": technical["captions"]["language"], "cue_count": technical["captions"]["cue_count"],
            "coverage_ratio": technical["captions"]["coverage_ratio"],
            "human_language_review": "SAMPLED_NOT_REQUIRED_PER_RELEASE" if autonomous_ready else technical["captions"]["human_language_review"],
            "automatic_language_review": "PASS" if autonomous_ready else "PENDING",
        },
        "format_capability": {
            "format_pack_id": pack["format_pack_id"], "version": pack["version"],
            "status": pack["capability_status"], "production_allowed": pack["production_allowed"],
        },
        "external_cost_usd": 0,
        "created_at": created_at,
    }


def materialize(root: Path = ROOT) -> Path:
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    decision = build_metadata_packaging_decision(created_at=created_at)
    decision_path = root / V3 / "metadata_packaging_decision.json"
    decision_path.write_text(json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8")
    package = build_creative_v3_publication_package(root)
    path = root / V3 / "publication_package.json"
    path.write_text(json.dumps(package, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


if __name__ == "__main__":
    print(materialize())
