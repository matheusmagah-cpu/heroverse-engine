from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .continuity import build_visual_continuity_bible
from .creative_direction import choose_format_pack, load_format_packs
from .creative_v2_phase5 import (
    APOLOGY_ASSET_ID,
    CLARITY_ASSET_ID,
    CONTEMPLATION_ASSET_ID,
    DECISION_ASSET_ID,
    HOOK_ASSET_ID,
    PACKAGE_DIR,
    PERSPECTIVE_ASSET_ID,
    PRESSURE_ASSET_ID,
    PROGRESS_ASSET_ID,
    RELEASE_ASSET_ID,
    RENEWAL_ASSET_ID,
    SKILL_ASSET_ID,
    TENSION_ASSET_ID,
    TRANSITION_ASSET_ID,
    WORK_ASSET_ID,
    _estimated_slot,
    _read_json,
    _sha256,
    _split,
    _stable_id,
    _validate,
    _words,
    _write_json,
)
from .policy_phase5 import evaluate_phase5_command
from .procedural_infographics_phase5 import SPECS as PROCEDURAL_INFOGRAPHIC_SPECS
from .take_planner import build_take_plan
from .voice_phase5 import SAMPLE_RATE, build_local_voice, synthesize_voice_sample


V3_DIR = PACKAGE_DIR / "creative-v3"
CREATIVE_VERSION = "3.2.0"
PHONE_ASSET_ID = "asset-owned-phone-down-v1"
COUNSEL_ASSET_ID = "asset-owned-trusted-counsel-v1"
CARDS_ASSET_ID = "asset-owned-three-card-decision-v1"
SCRIPTURE_ASSET_ID = "asset-owned-scriptural-mechanism-v1"
BOUNDARY_ASSET_ID = "asset-owned-safe-boundaries-v1"
PRACTICE_ASSET_ID = "asset-owned-action-plan-v1"
TRUTH_INFOGRAPHIC_ASSET_ID = "asset-owned-truth-test-motion-v1"
TRUTH_EVIDENCE_INFOGRAPHIC_ASSET_ID = "asset-owned-truth-evidence-motion-v1"
TRUTH_MEANING_INFOGRAPHIC_ASSET_ID = "asset-owned-truth-meaning-motion-v1"
TRUTH_CONFIRMATION_INFOGRAPHIC_ASSET_ID = "asset-owned-truth-confirmation-motion-v1"
RESPONSIBILITY_INFOGRAPHIC_ASSET_ID = "asset-owned-responsibility-map-motion-v1"
TODAY_INFOGRAPHIC_ASSET_ID = "asset-owned-today-timeline-motion-v1"
SAFETY_INFOGRAPHIC_ASSET_ID = "asset-owned-safety-network-motion-v1"
SYNTHETIC_IDS = {
    HOOK_ASSET_ID, APOLOGY_ASSET_ID, SKILL_ASSET_ID, PHONE_ASSET_ID,
    COUNSEL_ASSET_ID, CARDS_ASSET_ID, SCRIPTURE_ASSET_ID,
    BOUNDARY_ASSET_ID, PRACTICE_ASSET_ID,
}


SCRIPT_SECTIONS_V3 = [
    {
        "section_id": "S1", "role": "TITLE_ALIGNED_STAKE", "narrative_function": "deliver the title payoff",
        "text": (
            "Prayer can change your posture before it changes your circumstances. But if you rise, unlock the same distraction, repeat the same excuse, and delay the same honest task, fear is still directing the day. The first answer may not be new information. It may be the responsibility you already understand."
        ),
        "intended_emotion": "recognition", "semantic_role": "phone_down",
        "retention_job": "turn the title into a concrete consequence before thirty seconds",
        "source_refs": ["James 1:5", "brief:combined_promise"], "on_screen_text": "PRAYER CHANGES THE NEXT MOVE",
    },
    {
        "section_id": "S2", "role": "PERSONAL_STAKES", "narrative_function": "separate discernment from delay",
        "text": (
            "That does not mean every impulse after prayer is God's instruction. Urgency can be anxiety wearing a spiritual label. Discernment slows you enough to compare the step with truth, character, consequences, and wise counsel. Delay asks for perfect certainty. Discernment asks what is faithful with the light you actually have."
        ),
        "intended_emotion": "sober clarity", "semantic_role": "trusted_counsel",
        "retention_job": "remove the false choice between impulse and paralysis",
        "source_refs": ["James 1:5-8", "channel-model:B2"], "on_screen_text": "DISCERNMENT IS NOT DELAY",
    },
    {
        "section_id": "S3", "role": "MECHANISM_AND_PROOF", "narrative_function": "establish the scriptural mechanism",
        "text": (
            "James writes to believers under pressure. He tells them to ask God for wisdom, then later warns them not to become hearers who never act. Put those ideas together. Wisdom is not a private prediction machine. It helps a tested person respond faithfully to truth. Prayer, hearing, and doing belong in one sequence."
        ),
        "intended_emotion": "understanding", "semantic_role": "perspective",
        "retention_job": "close the reasoning loop with contextual paraphrase",
        "source_refs": ["James 1:2-8", "James 1:22-25"], "on_screen_text": "ASK. HEAR. DO.",
    },
    {
        "section_id": "S4", "role": "REVERSAL_AND_ACTION", "narrative_function": "teach the truth test",
        "text": (
            "Start with the first test: is the step true? Name the facts without editing them to protect your pride. If the move requires deception, revenge, manipulation, or a promise God never made, it fails here. Truth may reduce the drama, but it gives the next action solid ground."
        ),
        "intended_emotion": "honesty", "semantic_role": "decision_cards",
        "retention_job": "make the first question operational",
        "source_refs": ["James 1:22-25", "channel-model:B4"], "on_screen_text": "Q1  //  IS IT TRUE?",
    },
    {
        "section_id": "S5", "role": "REVERSAL_AND_ACTION", "narrative_function": "teach the responsibility test",
        "text": (
            "Then ask: what responsibility does this accept? Responsible action names a cost you can carry. It may be an apology without a demand, a boundary without cruelty, an application without pretending the result is guaranteed, or a request for help without blaming everyone else. Responsibility puts your character inside the prayer."
        ),
        "intended_emotion": "accountability", "semantic_role": "relationship_repair",
        "retention_job": "attach the framework to visible real-life costs",
        "source_refs": ["channel-model:concrete_response", "brief:payoff"], "on_screen_text": "Q2  //  WHAT DO I OWN?",
    },
    {
        "section_id": "S6", "role": "REVERSAL_AND_ACTION", "narrative_function": "teach the today test",
        "text": (
            "Finally ask: what can I do today? Not solve the whole relationship. Write the honest message. Not redesign your entire career. Study one skill, send one application, or ask one precise question. Not eliminate every fear. Put the phone down, call someone trustworthy, and schedule the next responsible move."
        ),
        "intended_emotion": "agency", "semantic_role": "work_step",
        "retention_job": "compress an overwhelming future into executable actions",
        "source_refs": ["channel-model:B4", "brief:payoff"], "on_screen_text": "Q3  //  WHAT CAN I DO TODAY?",
    },
    {
        "section_id": "S7", "role": "MECHANISM_AND_PROOF", "narrative_function": "define safe boundaries",
        "text": (
            "A faithful next step is not reckless. It does not ignore safety, professional advice, legal obligations, or the rights of another person. It does not turn a feeling into a guarantee from God. When consequences are serious, seek qualified help and trusted counsel. Courage is not moving fastest. It is moving honestly within wise boundaries."
            " If the situation involves abuse, self-harm, medical danger, or immediate risk, the faithful action is not a dramatic private decision. Contact appropriate emergency, medical, legal, pastoral, or safeguarding support. Wisdom can look like refusing to face danger alone."
        ),
        "intended_emotion": "earned confidence", "semantic_role": "trusted_counsel",
        "retention_job": "prevent impulsive or guaranteed-outcome interpretation",
        "source_refs": ["channel-model:risk_controls", "brief:non_guarantee"], "on_screen_text": "COURAGE NEEDS WISE BOUNDARIES",
    },
    {
        "section_id": "S8", "role": "REVERSAL_AND_ACTION", "narrative_function": "give the twenty-four-hour practice",
        "text": (
            "Use this practice before tomorrow. On three cards, write Truth, Responsibility, and Today. Under Truth, record what you know, not what fear predicts. Under Responsibility, name what is yours to own. Under Today, choose an action small enough to finish in twenty-four hours. Then tell one trustworthy person what you chose."
            " Put the final card where you will see it. When the action is complete, record what happened and what you learned instead of rewriting the prediction after the result."
        ),
        "intended_emotion": "focused resolve", "semantic_role": "decision_cards",
        "retention_job": "convert the framework into a memorable physical ritual",
        "source_refs": ["channel-model:concrete_response", "original-framework:v3"], "on_screen_text": "THE 24-HOUR PRACTICE",
    },
    {
        "section_id": "S9", "role": "PROMISE_RESOLUTION", "narrative_function": "resolve the promise",
        "text": (
            "You may still feel uncertain after you pray. Uncertainty is not permission to abandon truth. Name what is true. Accept what is yours. Complete one faithful action today. Do not worship the outcome, and do not hide inside waiting. Amen is not the finish. It is where an honest response begins."
        ),
        "intended_emotion": "quiet resolve", "semantic_role": "renewal",
        "retention_job": "close the title, hook, framework, and action loop",
        "source_refs": ["brief:combined_promise", "channel-model:B5"], "on_screen_text": "TRUTH. RESPONSIBILITY. TODAY.",
    },
]


def _owned_asset_record(root: Path, *, asset_id: str, semantic_role: str, image_name: str, prompt_scope: str, created_at: str) -> dict[str, Any]:
    base = root / V3_DIR / "assets"
    image_path = base / image_name
    motion_path = base / f"{asset_id}.mp4"
    if not image_path.is_file() or not motion_path.is_file():
        raise FileNotFoundError(f"missing v3 source or motion derivative for {asset_id}")
    evidence_path = root / PACKAGE_DIR / "rights_evidence" / f"{asset_id}.json"
    evidence = {
        "schema_version": "1.0.0", "asset_id": asset_id,
        "asset_type": "AI_GENERATED_ORIGINAL_WITH_LOCAL_MOTION_DERIVATIVE",
        "source_image": str(image_path.resolve()), "source_image_hash": _sha256(image_path),
        "motion_derivative": str(motion_path.resolve()), "motion_hash": _sha256(motion_path),
        "provider": "OpenAI built-in image generation through Codex", "prompt_scope": prompt_scope,
        "ownership_basis": "OpenAI Terms of Use output ownership, subject to applicable law and responsible use.",
        "ownership_source": "https://openai.com/policies/terms-of-use/",
        "platform_disclosure": {"required": True, "reason": "photorealistic generated scene that did not occur", "youtube_source": "https://support.google.com/youtube/answer/14328491", "upload_value": True},
        "decision": "RESPONSIBLE_REVIEW_APPROVED",
        "limitations": ["Operational rights record, not a legal opinion.", "Output may not be unique; similarity and third-party rights remain the publisher's responsibility.", "Synthetic-content disclosure must be enabled at upload."],
        "verified_at": created_at,
    }
    _write_json(evidence_path, evidence)
    return {
        "asset_id": asset_id, "semantic_role": semantic_role, "media_type": "HYBRID",
        "tool_adapter_id": "adapter-ffmpeg-local", "tool_version": "imagegen-builtin-observed-2026-09-03+ffmpeg-runtime",
        "uri": str(motion_path.resolve()), "content_hash": _sha256(motion_path),
        "source": f"generated://openai-imagegen/{image_name}",
        "creator_or_holder": "HeroVerse project / OpenAI output assignment subject to applicable law",
        "rights_status": "OWNED", "license": "OpenAI Terms of Use output ownership; responsible-use conditions apply",
        "license_version": "accessed 2026-09-03", "commercial_use": True, "production_eligible": True,
        "attribution": None, "restrictions": ["YouTube synthetic-content disclosure required"],
        "rights_evidence_uri": str(evidence_path.resolve()), "verified_at": created_at,
        "rights_decision": "RESPONSIBLE_REVIEW_APPROVED", "duration_seconds": 60.0,
        "width": 1920, "height": 1080, "used_ranges": [], "content_quality_gate": "PASS",
        "safe_ranges": [{"start_ms": 0, "end_ms": 60000}],
        "content_quality_evidence": "output/production/phase5/pilot-001/creative-v3/assets",
    }


def _procedural_asset_record(root: Path, *, asset_id: str, semantic_role: str, created_at: str) -> dict[str, Any]:
    directory = root / V3_DIR / "assets"
    motion_path = directory / f"{asset_id}.mp4"
    svg_path = directory / "procedural" / f"{asset_id}.svg"
    if not motion_path.is_file() or not svg_path.is_file():
        raise FileNotFoundError(f"missing local procedural infographic for {asset_id}")
    evidence_path = root / PACKAGE_DIR / "rights_evidence" / f"{asset_id}.json"
    evidence = {
        "schema_version": "1.0.0",
        "asset_id": asset_id,
        "asset_type": "PROJECT_OWNED_PROCEDURAL_VECTOR_MOTION",
        "source_svg": str(svg_path.resolve()),
        "source_svg_hash": _sha256(svg_path),
        "motion_derivative": str(motion_path.resolve()),
        "motion_hash": _sha256(motion_path),
        "provider": "HeroVerseLocalVectorMotion@1.0.1 + FFmpeg",
        "ownership_basis": "Original project-authored vector layout and locally rendered motion derivative.",
        "platform_disclosure": {"required": False, "reason": "abstract infographic; not a realistic altered or synthetic event"},
        "decision": "RESPONSIBLE_REVIEW_APPROVED",
        "limitations": ["Operational rights record, not a legal opinion.", "Font rendering uses the locally available system font selected by the production adapter."],
        "verified_at": created_at,
    }
    _write_json(evidence_path, evidence)
    return {
        "asset_id": asset_id,
        "semantic_role": semantic_role,
        "media_type": "INFOGRAPHIC",
        "tool_adapter_id": "adapter-ffmpeg-local",
        "tool_version": "HeroVerseLocalVectorMotion@1.0.1+ffmpeg-runtime",
        "uri": str(motion_path.resolve()),
        "content_hash": _sha256(motion_path),
        "source": f"procedural://heroverse/{asset_id}",
        "creator_or_holder": "HeroVerse project",
        "rights_status": "OWNED",
        "license": "Project-owned original procedural work",
        "license_version": "1.0.0",
        "commercial_use": True,
        "production_eligible": True,
        "attribution": None,
        "restrictions": [],
        "rights_evidence_uri": str(evidence_path.resolve()),
        "verified_at": created_at,
        "rights_decision": "RESPONSIBLE_REVIEW_APPROVED",
        "duration_seconds": 18.0,
        "width": 1920,
        "height": 1080,
        "used_ranges": [],
        "content_quality_gate": "PASS",
        "safe_ranges": [{"start_ms": 0, "end_ms": 18000}],
        "content_quality_evidence": "output/production/phase5/pilot-001/creative-v3/assets/procedural/manifest.json",
    }


def register_v3_assets(root: Path, *, created_at: str,
                       typography_sources: Path | None = None,
                       expected_typography_sha256: str | None = None,
                       successor_directory: Path | None = None,
                       typography_audit_directory: Path | None = None,
                       typography_appearance: bool = False,
                       typography_content: bool = False) -> dict[str, Any]:
    if type(typography_content) is not bool or typography_content and not typography_appearance:
        raise PermissionError('content conformance requires explicit appearance audit')
    if type(typography_appearance) is not bool or typography_appearance and typography_audit_directory is None:
        raise PermissionError('appearance requires an explicit source audit')
    if typography_audit_directory is not None and typography_sources is None:
        raise PermissionError('typography audit cannot enter the legacy catalogue')
    if any(value is not None for value in (typography_sources,expected_typography_sha256,successor_directory)):
        # A new immutable catalogue, never the live manifest or legacy rights.
        from .procedural_infographics_phase5 import read_typography_source_manifest, TYPOGRAPHY_SUCCESSOR_VERSION
        from .phase6_asset_residency import _write_immutable, validate_phase6_rights_evidence
        if any(value is None for value in (typography_sources,expected_typography_sha256,successor_directory)):
            raise PermissionError('complete anchored successor catalogue request required')
        root=root.resolve(); destination=successor_directory.resolve()
        if root not in destination.parents or destination.exists() or (root/PACKAGE_DIR).resolve() in destination.parents:
            raise PermissionError('successor catalogue requires a new nonhistorical confined directory')
        original=root/PACKAGE_DIR/'asset_manifest.json'
        previous_hash=_sha256(original)
        manifest=copy.deepcopy(_read_json(original))
        observed=read_typography_source_manifest(root,typography_sources,expected_sha256=expected_typography_sha256)
        typography_audit = None
        if typography_audit_directory is not None:
            from .phase6_visual_typography import audit_typography_sources
            typography_audit = audit_typography_sources(root,typography_sources,
                expected_sha256=expected_typography_sha256,output_directory=typography_audit_directory,
                **({'appearance':True,**({'content':True} if typography_content else {})} if typography_appearance else {}))
            expected_status=('PASS_SOURCE_CONTENT_CONFORMANCE' if typography_content else
                             'PASS_SOURCE_TYPOGRAPHY_TRANSFER' if typography_appearance else 'PASS_SOURCE_GLYPH_SUPPORT')
            if typography_audit['status'] != expected_status:
                raise PermissionError('source typography audit failed; catalogue not committed')
            audit_path = (typography_audit_directory/'audit.json').resolve()
            # Bind the exact bytes produced/evaluated in this invocation, not
            # whatever file happens to occupy the path after the evaluator.
            audit_raw = (json.dumps(typography_audit,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
            if audit_path.read_bytes() != audit_raw:
                raise PermissionError('typography audit differs before hash binding')
            typography_audit = {'path':str(audit_path),
                                'sha256':'sha256:'+hashlib.sha256(audit_raw).hexdigest(),
                                'scope':('SOURCE_CONTENT_CONFORMANCE_NOT_FINAL_VIDEO_QA' if typography_content else
                                         'SOURCE_TYPOGRAPHY_TRANSFER_NOT_FULL_CONTENT_QA' if typography_appearance
                                         else 'SOURCE_GLYPH_SUPPORT_ONLY_NOT_FULL_CONTENT_QA')}
        ids={row['asset_id'] for row in manifest['assets']}
        records=[]; evidences=[]
        for source in observed['manifest']['assets']:
            asset_id=source['asset_id']; layout=observed['layouts'][source['layout_id']]
            if asset_id in ids:raise PermissionError('successor asset collides with existing catalogue')
            ids.add(asset_id)
            rights=destination/'rights'/f'{asset_id}.json'
            evidence={'schema_version':'1.1.0','asset_id':asset_id,
                'asset_type':'PROJECT_OWNED_PROCEDURAL_TYPOGRAPHY_SUCCESSOR',
                'source_manifest':observed['binding'],'layout_id':source['layout_id'],
                'motion_derivative':source['video_path'],'motion_hash':source['video_hash'],
                'provider':TYPOGRAPHY_SUCCESSOR_VERSION+'+FFmpeg',
                'ownership_basis':'Exact canonical project-authored layout and locally generated text/decorative layers; no inherited claim over the prior clip.',
                'platform_disclosure':{'required':False,'reason':'Abstract project-authored typography/decorative grid, not a realistic synthetic event.'},
                'decision':'AUTO_PROJECT_SOURCE_PROVENANCE_VERIFIED',
                'limitations':['Source provenance only; not a legal opinion or video-quality approval.',
                               'Does not grant permission to redistribute installed font files.'],
                'verified_at':created_at}
            record={'asset_id':asset_id,'semantic_role':layout['source_spec']['semantic_role'],
                'media_type':'INFOGRAPHIC','tool_adapter_id':'adapter-ffmpeg-local',
                'tool_version':evidence['provider'],'uri':source['video_path'],'content_hash':source['video_hash'],
                'source':f'procedural://heroverse/typography/{source["layout_id"]}',
                'creator_or_holder':'HeroVerse project','rights_status':'OWNED',
                'license':'Project-owned original procedural work','license_version':'1.1.0',
                'commercial_use':True,'production_eligible':False,'attribution':None,
                'restrictions':['Not eligible for allocation until independent content QA passes.'],
                'rights_evidence_uri':str(rights),'rights_decision':evidence['decision'],'verified_at':created_at,
                'duration_seconds':source['duration_seconds'],'width':1920,'height':1080,
                'used_ranges':[],'safe_ranges':[],'content_quality_gate':'BLOCKED',
                'content_quality_evidence':None,'historical_asset_id':source['historical_asset_id'],
                'take_scope':[source['take_id']],'quality_authorized':False,'render_authorized':False,
                'publication_authorized':False}
            if typography_audit is not None:
                record['typography_quality_evidence'] = typography_audit
            validate_phase6_rights_evidence(root,record,evidence,media_path=Path(source['video_path']))
            records.append(record);evidences.append((rights,evidence))
        if _sha256(original)!=previous_hash:raise PermissionError('historical catalogue changed during registration')
        rechecked=read_typography_source_manifest(root,typography_sources,expected_sha256=expected_typography_sha256)
        if rechecked!=observed:raise PermissionError('successor inputs changed during registration')
        destination.mkdir(parents=True,exist_ok=False)
        for path,evidence in evidences:_write_immutable(path,evidence)
        # Reopen everything before the only successful catalogue receipt.
        if (_sha256(original)!=previous_hash or
                read_typography_source_manifest(root,typography_sources,expected_sha256=expected_typography_sha256)!=observed):
            raise PermissionError('catalogue inputs changed before commit')
        for path,evidence in evidences:
            if _read_json(path)!=evidence:raise PermissionError('successor rights changed before catalogue')
        if typography_audit is not None and _sha256(Path(typography_audit['path']))!=typography_audit['sha256']:
            raise PermissionError('typography audit changed before catalogue commit')
        manifest['assets'].extend(records)
        manifest['selected_count']=len(manifest['assets'])
        manifest['typography_successor']={'source_manifest':observed['binding'],
            'base_manifest':{'path':str(original),'sha256':previous_hash},
            'status':'REGISTERED_CANDIDATES_NOT_ADOPTED','asset_ids':[r['asset_id'] for r in records],
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
        _write_immutable(destination/'asset_manifest.json',manifest)
        return manifest
    path = root / PACKAGE_DIR / "asset_manifest.json"
    manifest = _read_json(path)
    new_records = [
        _owned_asset_record(root, asset_id=PHONE_ASSET_ID, semantic_role="phone_down", image_name="phone-down-original-v1.png", prompt_scope="anonymous hand placing a non-branded phone face down after prayer; no input reference, logo, face, celebrity or private data", created_at=created_at),
        _owned_asset_record(root, asset_id=COUNSEL_ASSET_ID, semantic_role="trusted_counsel", image_name="trusted-counsel-original-v1.png", prompt_scope="two anonymous adults in a serious counsel conversation; no input reference, identifiable face, organization, logo or readable private data", created_at=created_at),
        _owned_asset_record(root, asset_id=CARDS_ASSET_ID, semantic_role="decision_cards", image_name="three-card-decision-original-v1.png", prompt_scope="anonymous hand moving one of exactly three blank decision cards; no input reference, text, logo, face, trademark or private data", created_at=created_at),
        _owned_asset_record(root, asset_id=SCRIPTURE_ASSET_ID, semantic_role="scriptural_mechanism", image_name="scriptural-mechanism-original-v1.png", prompt_scope="open unbranded Bible-like book, notebook and exactly three blank cards illustrating ask-hear-do; no input reference, person, logo or readable copied text", created_at=created_at),
        _owned_asset_record(root, asset_id=BOUNDARY_ASSET_ID, semantic_role="safe_boundaries", image_name="safe-boundaries-original-v1.png", prompt_scope="unbranded phone, abstract emergency-contact card and counsel chair illustrating safe help; no person, private data, institution, logo or sensational danger", created_at=created_at),
        _owned_asset_record(root, asset_id=PRACTICE_ASSET_ID, semantic_role="action_plan", image_name="action-plan-original-v1.png", prompt_scope="exactly three blank cards, face-down phone, pen and analog clock illustrating a twenty-four-hour plan; no input reference, person, logo or readable text", created_at=created_at),
        *[
            _procedural_asset_record(
                root,
                asset_id=str(spec["asset_id"]),
                semantic_role=str(spec["semantic_role"]),
                created_at=created_at,
            )
            for spec in PROCEDURAL_INFOGRAPHIC_SPECS
        ],
    ]
    replacement_ids = {item["asset_id"] for item in new_records}
    assets = [item for item in manifest["assets"] if item["asset_id"] not in replacement_ids]
    for item in assets:
        item["used_ranges"] = []
        if item["asset_id"] == PRESSURE_ASSET_ID:
            item["production_eligible"] = False
            item["content_quality_gate"] = "BLOCKED"
            item["content_quality_evidence"] = "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md#asset-context-rejection"
            restriction = "Rejected for this narrative: source provenance concerns an unrelated criminal investigation and creates false context."
            if restriction not in item.setdefault("restrictions", []):
                item["restrictions"].append(restriction)
    assets.extend(new_records)
    manifest["assets"] = assets
    manifest["selected_count"] = len(assets)
    manifest["provider"] = "Wikimedia Commons API + original generated action inserts"
    _write_json(path, manifest)
    return manifest


def build_brief_v3(brief: dict[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(brief)
    value["package"] = {
        "topic": "what to do immediately after prayer",
        "angle": "prayer must become one truthful, responsible and bounded action",
        "promise": "a three-test decision method and a twenty-four-hour practice",
        "title_concept": "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation",
        "title_variants": ["AFTER YOU PRAY, DO THIS NEXT | Christian Motivation", "PRAYER ISN'T THE FINISH | Do This Next", "WHAT TO DO AFTER YOU PRAY | 3 Tests"],
        "thumbnail_concept": "a hand placing a phone face down beside three decision cards; one action is visible and the spiritual promise is explicit",
        "thumbnail_text_variants": ["PRAYER ISN'T THE FINISH", "AFTER AMEN...", "DO THIS TODAY"],
        "combined_promise": "The viewer learns to test one action by truth, responsibility and today without treating impulse as revelation or guaranteeing an outcome.",
        "delivery_test": "PASS",
    }
    replacements = {
        "0_1S": ("Not finished.", "PRAYER ISN'T THE FINISH appears over threshold action while the voice lands the contradiction"),
        "1_3S": ("Amen? Fear still decides.", "phone goes face down; the spiritual anchor and consequence are visible"),
        "3_8S": ("Test one step: truth, responsibility, and action today.", "three separate cards introduce the usable mechanism"),
        "8_30S": (SCRIPT_SECTIONS_V3[0]["text"], "distinct action inserts show posture, distraction, excuse and responsibility"),
    }
    for window in value["hook_windows"]:
        window["original_text"], window["visual_proof"] = replacements[window["window"]]
        window["gate_status"] = "PASS"
    value["payoff"] = "Complete one truthful and responsible action within twenty-four hours, inside wise boundaries."
    value["originality_controls"]["new_visual_identity"] = True
    return value


def build_script_v3(brief: dict[str, Any], *, created_at: str) -> dict[str, Any]:
    hook = ["Not finished.", "Amen? Fear still decides.", "Test one step: truth, responsibility, and action today."]
    full_text = " ".join([*hook, *[section["text"] for section in SCRIPT_SECTIONS_V3]])
    estimated = 8000 + sum(_estimated_slot(chunk) for section in SCRIPT_SECTIONS_V3 for chunk in _split(section["text"], 12))
    return {
        "schema_version": "1.0.0", "script_id": _stable_id("script-v3", brief["brief_id"], full_text), "version": CREATIVE_VERSION,
        "channel_id": brief["channel_id"], "brief_id": brief["brief_id"], "language": "en-US", "title": brief["package"]["title_concept"],
        "original_thesis": "Prayer becomes faithful action when one step passes truth, responsibility, timing and wise-boundary tests.",
        "source_basis": [
            {"source_ref": "James 1:2-8", "use": "wisdom under pressure", "handling": "original contextual paraphrase"},
            {"source_ref": "James 1:22-25", "use": "hearing becomes accountable action", "handling": "original contextual paraphrase"},
            {"source_ref": "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md", "use": "measured remediation requirements", "handling": "versioned production contract"},
        ],
        "hook_windows": [
            {"window": "0_1S", "start_ms": 0, "end_ms": 1000, "function": "contradiction", "narration": hook[0], "visual_job": "threshold movement establishes that prayer is a transition", "evidence_refs": ["creative-v3:H1", "channel-model:H1"]},
            {"window": "1_3S", "start_ms": 1000, "end_ms": 3000, "function": "consequence", "narration": hook[1], "visual_job": "a different source shows the phone placed face down", "evidence_refs": ["creative-v3:H2", "channel-model:H2"]},
            {"window": "3_8S", "start_ms": 3000, "end_ms": 8000, "function": "mechanism", "narration": hook[2], "visual_job": "a third source gives the framework three tangible cards", "evidence_refs": ["creative-v3:H3", "channel-model:H3"]},
            {"window": "8_30S", "start_ms": 8000, "end_ms": 30000, "function": "first payoff", "narration": SCRIPT_SECTIONS_V3[0]["text"], "visual_job": "at least five functional changes with no decorative fill", "evidence_refs": ["creative-v3:H4", "channel-model:H4"]},
        ],
        "sections": SCRIPT_SECTIONS_V3, "full_text": full_text, "word_count": _words(full_text), "estimated_duration_ms": estimated,
        "originality_controls": {"written_from_blank": True, "reference_wording_used": False, "borrowed_audio_used": False, "borrowed_sequence_used": False, "editorial_purpose": "Teach an original truth-responsibility-today method using licensed clips, original action inserts, original narration and a new sequence."},
        "created_at": created_at,
    }


SECTION_ASSETS = {
    # Recipes remain semantic fallbacks. The measured v3.2 assignment below is
    # the authoritative cut map and prevents a small group of motifs from
    # dominating an otherwise varied timeline.
    "S1": [HOOK_ASSET_ID, PHONE_ASSET_ID, TENSION_ASSET_ID, DECISION_ASSET_ID, CLARITY_ASSET_ID],
    "S2": [COUNSEL_ASSET_ID, CONTEMPLATION_ASSET_ID, PERSPECTIVE_ASSET_ID, COUNSEL_ASSET_ID, DECISION_ASSET_ID],
    "S3": [TENSION_ASSET_ID, SCRIPTURE_ASSET_ID, WORK_ASSET_ID, PERSPECTIVE_ASSET_ID, SCRIPTURE_ASSET_ID, DECISION_ASSET_ID],
    "S4": [CARDS_ASSET_ID, TENSION_ASSET_ID, APOLOGY_ASSET_ID, BOUNDARY_ASSET_ID, CLARITY_ASSET_ID, WORK_ASSET_ID],
    "S5": [APOLOGY_ASSET_ID, PRACTICE_ASSET_ID, APOLOGY_ASSET_ID, WORK_ASSET_ID, COUNSEL_ASSET_ID, APOLOGY_ASSET_ID],
    "S6": [PHONE_ASSET_ID, SKILL_ASSET_ID, WORK_ASSET_ID, PHONE_ASSET_ID, PROGRESS_ASSET_ID],
    "S7": [BOUNDARY_ASSET_ID, DECISION_ASSET_ID, BOUNDARY_ASSET_ID, COUNSEL_ASSET_ID, BOUNDARY_ASSET_ID, PHONE_ASSET_ID, DECISION_ASSET_ID, BOUNDARY_ASSET_ID, COUNSEL_ASSET_ID],
    "S8": [PRACTICE_ASSET_ID, CARDS_ASSET_ID, PRACTICE_ASSET_ID, PROGRESS_ASSET_ID, PRACTICE_ASSET_ID, CARDS_ASSET_ID, PROGRESS_ASSET_ID, WORK_ASSET_ID, RELEASE_ASSET_ID],
    "S9": [RENEWAL_ASSET_ID, SCRIPTURE_ASSET_ID, HOOK_ASSET_ID, RELEASE_ASSET_ID, HOOK_ASSET_ID],
}

# Capacity-aware take assignments. These are not aesthetic guesses: each entry
# replaces a measured fallback to generic clouds after a concrete 30-second
# insert exhausted its non-overlapping source ranges.
TAKE_ASSET_OVERRIDES = {
    # Full measured cut map for takes 004–059. It was designed against the
    # persisted 238.7 s voice timeline and is accepted only when the QA layer
    # confirms: <=10% per asset, <=55% for the six largest assets, <=5 uses per
    # asset and <=3 appearances of one asset in every rolling 60-second window.
    "take-004": HOOK_ASSET_ID,
    "take-005": PHONE_ASSET_ID,
    "take-006": TENSION_ASSET_ID,
    "take-007": APOLOGY_ASSET_ID,
    "take-008": CLARITY_ASSET_ID,
    "take-009": COUNSEL_ASSET_ID,
    "take-010": CONTEMPLATION_ASSET_ID,
    "take-011": TRUTH_INFOGRAPHIC_ASSET_ID,
    "take-012": COUNSEL_ASSET_ID,
    "take-013": CARDS_ASSET_ID,
    "take-014": TENSION_ASSET_ID,
    "take-015": SCRIPTURE_ASSET_ID,
    "take-016": WORK_ASSET_ID,
    "take-017": PERSPECTIVE_ASSET_ID,
    "take-018": SCRIPTURE_ASSET_ID,
    "take-019": TODAY_INFOGRAPHIC_ASSET_ID,
    "take-020": CARDS_ASSET_ID,
    "take-021": TENSION_ASSET_ID,
    "take-022": APOLOGY_ASSET_ID,
    "take-023": BOUNDARY_ASSET_ID,
    "take-024": CLARITY_ASSET_ID,
    "take-025": WORK_ASSET_ID,
    "take-026": DECISION_ASSET_ID,
    "take-027": RESPONSIBILITY_INFOGRAPHIC_ASSET_ID,
    "take-028": APOLOGY_ASSET_ID,
    "take-029": WORK_ASSET_ID,
    "take-030": DECISION_ASSET_ID,
    "take-031": PRACTICE_ASSET_ID,
    "take-032": TODAY_INFOGRAPHIC_ASSET_ID,
    "take-033": APOLOGY_ASSET_ID,
    "take-034": SKILL_ASSET_ID,
    "take-035": PHONE_ASSET_ID,
    "take-036": PROGRESS_ASSET_ID,
    "take-037": BOUNDARY_ASSET_ID,
    "take-038": SAFETY_INFOGRAPHIC_ASSET_ID,
    "take-039": SCRIPTURE_ASSET_ID,
    "take-040": COUNSEL_ASSET_ID,
    "take-041": BOUNDARY_ASSET_ID,
    "take-042": PHONE_ASSET_ID,
    "take-043": PRACTICE_ASSET_ID,
    "take-044": BOUNDARY_ASSET_ID,
    "take-045": COUNSEL_ASSET_ID,
    "take-046": PRACTICE_ASSET_ID,
    "take-047": CARDS_ASSET_ID,
    "take-048": PRACTICE_ASSET_ID,
    "take-049": PROGRESS_ASSET_ID,
    "take-050": DECISION_ASSET_ID,
    "take-051": PERSPECTIVE_ASSET_ID,
    "take-052": PROGRESS_ASSET_ID,
    "take-053": SKILL_ASSET_ID,
    "take-054": RELEASE_ASSET_ID,
    "take-055": RENEWAL_ASSET_ID,
    "take-056": SCRIPTURE_ASSET_ID,
    "take-057": HOOK_ASSET_ID,
    "take-058": RELEASE_ASSET_ID,
    "take-059": TODAY_INFOGRAPHIC_ASSET_ID,
}


def _asset_for_chunk(manifest: dict[str, Any], section_id: str, index: int, text: str, previous_asset_id: str | None = None) -> str | None:
    ids = {item["asset_id"] for item in manifest["assets"] if item.get("production_eligible") is True and item.get("content_quality_gate") != "BLOCKED"}
    lowered = text.lower()
    semantic = [
        (("phone", "distraction"), PHONE_ASSET_ID), (("counsel", "trustworthy", "qualified help"), COUNSEL_ASSET_ID),
        (("three cards", "under truth", "under responsibility", "under today"), CARDS_ASSET_ID),
        (("apology", "apologize"), APOLOGY_ASSET_ID), (("skill", "precise question"), SKILL_ASSET_ID), (("application", "career", "work"), WORK_ASSET_ID),
    ]
    selected: str | None = None
    for terms, asset_id in semantic:
        if any(term in lowered for term in terms) and asset_id in ids:
            selected = asset_id
            break
    sequence = SECTION_ASSETS.get(section_id, [])
    if selected and selected != previous_asset_id:
        return selected
    if sequence:
        for offset in range(len(sequence)):
            candidate = sequence[(index + offset) % len(sequence)]
            if candidate in ids and candidate != previous_asset_id:
                return candidate
    if selected in ids:
        return selected
    # Missing creative coverage is a specification error, not permission to
    # fill the screen with unrelated stock footage.
    raise ValueError(f"no production-eligible visual recipe for {section_id} chunk {index}")


def _overlay(section: dict[str, Any], index: int, text: str) -> str | None:
    lowered = text.lower()
    rules = [
        ("is the step true", "Q1  //  IS IT TRUE?"), ("what responsibility", "Q2  //  WHAT DO I OWN?"),
        ("what can i do today", "Q3  //  WHAT CAN I DO TODAY?"), ("private prediction machine", "WISDOM IS NOT A PREDICTION"),
        ("does not turn a feeling", "NO GUARANTEED OUTCOME"), ("before tomorrow", "THE 24-HOUR PRACTICE"),
        ("situation involves abuse", "SAFETY FIRST  //  GET QUALIFIED HELP"),
        ("do not worship the outcome", "HONEST BEFORE CERTAIN"),
        ("amen is not the finish", "AMEN IS WHERE ACTION BEGINS"),
    ]
    for needle, value in rules:
        if needle in lowered:
            return value
    return section["on_screen_text"] if index == 0 else None


def build_beats_v3(script: dict[str, Any], manifest: dict[str, Any], duration_overrides: dict[str, int] | None = None) -> list[dict[str, Any]]:
    overrides = duration_overrides or {}
    beats = [
        {"beat_id": "H01", "start_ms": 0, "end_ms": 1000, "narrative_function": "contradiction", "information": "Prayer is a transition, not the finish.", "intended_emotion": "attention", "semantic_role": "hook_threshold", "action": "figure crosses a threshold", "on_screen_text": "PRAYER ISN'T THE FINISH", "narration": script["hook_windows"][0]["narration"], "retention_job": "state the contrarian promise in one second", "preferred_asset_id": HOOK_ASSET_ID, "allow_repeat_asset": False, "sound_effect": "impact"},
        {"beat_id": "H02", "start_ms": 1000, "end_ms": 3000, "narrative_function": "consequence", "information": "Fear keeps deciding when prayer produces no action.", "intended_emotion": "tension", "semantic_role": "phone_down", "action": "hand puts the phone face down", "on_screen_text": "FEAR KEEPS DECIDING", "narration": script["hook_windows"][1]["narration"], "retention_job": "make the consequence visible using a second source", "preferred_asset_id": PHONE_ASSET_ID, "allow_repeat_asset": False, "sound_effect": "whoosh"},
        {"beat_id": "H03", "start_ms": 3000, "end_ms": 8000, "narrative_function": "mechanism", "information": "Truth, responsibility and today test one next step.", "intended_emotion": "agency", "semantic_role": "decision_cards", "action": "one of three cards moves forward", "on_screen_text": "TRUTH  /  RESPONSIBILITY  /  TODAY", "narration": script["hook_windows"][2]["narration"], "retention_job": "deliver the mechanism with a third source", "preferred_asset_id": CARDS_ASSET_ID, "allow_repeat_asset": False, "sound_effect": "pulse"},
    ]
    cursor = 8000
    take_index = 4
    previous_preferred = CARDS_ASSET_ID
    for section in script["sections"]:
        for chunk_index, chunk in enumerate(_split(section["text"], 12)):
            take_id = f"take-{take_index:03d}"
            duration = int(overrides.get(take_id, _estimated_slot(chunk)))
            if duration < 900 or duration > 7000:
                raise ValueError(f"creative-v3 duration outside 0.9–7.0 s for {take_id}: {duration}")
            preferred = TAKE_ASSET_OVERRIDES.get(
                take_id,
                _asset_for_chunk(manifest, section["section_id"], chunk_index, chunk, previous_preferred),
            )
            if preferred == previous_preferred:
                raise ValueError(f"creative-v3.2 specifies an adjacent visual repeat at {take_id}")
            previous_preferred = preferred
            assets = {item["asset_id"]: item for item in manifest["assets"]}
            semantic_role = str(assets.get(preferred, {}).get("semantic_role", section["semantic_role"]))
            beats.append({
                "beat_id": f"B{take_index:03d}", "start_ms": cursor, "end_ms": cursor + duration,
                "narrative_function": section["narrative_function"], "information": chunk,
                "intended_emotion": section["intended_emotion"], "semantic_role": semantic_role,
                "action": f"visual proves {semantic_role}; no decorative filler", "on_screen_text": _overlay(section, chunk_index, chunk),
                "narration": chunk, "retention_job": section["retention_job"], "preferred_asset_id": preferred,
                "allow_repeat_asset": False, "sound_effect": "section impact" if chunk_index == 0 else None,
            })
            cursor += duration
            take_index += 1
    return beats


def _build_treatment_v3(plan: dict[str, Any], *, created_at: str) -> dict[str, Any]:
    treatments = []
    framework_state = "HIDDEN"
    for take in plan["takes"]:
        take_id = take["take_id"]
        text = (take.get("information") or "").lower()
        asset_id = re.search(r"(asset-(?:commons|owned)-[a-z0-9-]+)", take["asset_origin"])
        synthetic = bool(asset_id and asset_id.group(1) in SYNTHETIC_IDS)
        if take_id == "take-001":
            treatment, layout, events, interrupt, sfx = "HOOK_STAMP", "LEFT_HERO", 2, True, "IMPACT"
        elif take_id == "take-002":
            treatment, layout, events, interrupt, sfx = "HOOK_QUESTION", "LEFT_HERO", 2, True, "WHOOSH"
        elif take_id == "take-003":
            treatment, layout, events, interrupt, sfx, framework_state = "HOOK_FRAMEWORK", "FRAMEWORK_BAR", 3, True, "PULSE", "INTRODUCED"
        elif "first test" in text or "is the step true" in text:
            treatment, layout, events, interrupt, sfx, framework_state = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "PULSE", "TRUTH"
        elif "what responsibility" in text or "responsible action" in text:
            treatment, layout, events, interrupt, sfx, framework_state = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "PULSE", "RESPONSIBILITY"
        elif "what can i do today" in text or "under today" in text:
            treatment, layout, events, interrupt, sfx, framework_state = "FRAMEWORK_STEP", "FRAMEWORK_BAR", 3, True, "PULSE", "TODAY"
        elif take.get("on_screen_text") == "ASK. HEAR. DO.":
            treatment, layout, events, interrupt, sfx = "SCRIPTURE_SEQUENCE", "FRAMEWORK_BAR", 3, True, "PULSE"
        elif take.get("on_screen_text") in {"WISDOM IS NOT A PREDICTION", "NO GUARANTEED OUTCOME", "HONEST BEFORE CERTAIN"}:
            treatment, layout, events, interrupt, sfx = "KEYWORD_PUNCH", "CENTER_PAYOFF", 2, True, "IMPACT"
        elif take.get("on_screen_text"):
            treatment = "PAYOFF_RESOLUTION" if "TRUTH." in str(take["on_screen_text"]) else "SECTION_CARD"
            layout, events, interrupt, sfx = ("CENTER_PAYOFF", 2, True, "RESOLUTION") if treatment == "PAYOFF_RESOLUTION" else ("LOWER_LEFT", 2, True, "IMPACT")
            if treatment == "PAYOFF_RESOLUTION":
                framework_state = "COMPLETE"
        elif any(term in text for term in ("apology", "application", "skill", "phone", "counsel", "cards")):
            treatment, layout, events, interrupt, sfx = "ACTION_EVIDENCE", "NONE", 1, False, "PEN" if "apology" in text else "KEYS"
        else:
            treatment, layout, events, interrupt, sfx = "CINEMATIC_BODY", "NONE", 1, False, "NONE"
        treatments.append({"take_id": take_id, "treatment": treatment, "text_layout": layout, "visual_event_count": events, "pattern_interrupt": interrupt, "framework_state": framework_state, "sfx": sfx, "synthetic_disclosure": synthetic, "evidence_refs": [f"take-plan:{take_id}", "docs/PHASE_5_CREATIVE_REMEDIATION_PLAN.md"]})
    coverage = {item["window"]: item["take_ids"] for item in plan["hook_window_coverage"]}
    return {
        "schema_version": "1.0.0", "treatment_plan_id": _stable_id("creative-treatment", plan["take_plan_id"], CREATIVE_VERSION), "version": CREATIVE_VERSION,
        "video_id": plan["video_id"], "channel_id": plan["channel_id"], "format_pack_id": plan["format_pack_id"], "format_pack_version": plan["format_pack_version"],
        "grammar": {"motif": "THRESHOLD_TO_STEP", "accent_hex": "#D7A94A", "framework": ["TRUTH", "RESPONSIBILITY", "TODAY"], "text_rule": "keyword-led typography with full sidecar captions; no generic filler text", "semantic_rule": "every concrete claim requires concrete action or a causal information layer", "rhythm_rule": "three distinct sources in 0–8 s; functional change <= 7 s; structured interrupt <= 25 s"},
        "hook_contract": [
            {"window": "0_1S", "visual_events_minimum": 2, "audio_events_minimum": 2, "proof": "threshold motion plus contradiction and impact", "take_ids": coverage["0_1S"]},
            {"window": "1_3S", "visual_events_minimum": 2, "audio_events_minimum": 2, "proof": "different phone source plus consequence and whoosh", "take_ids": coverage["1_3S"]},
            {"window": "3_8S", "visual_events_minimum": 3, "audio_events_minimum": 2, "proof": "third source plus three-card framework and pulse", "take_ids": coverage["3_8S"]},
            {"window": "8_30S", "visual_events_minimum": 5, "audio_events_minimum": 2, "proof": "five or more semantic changes and first-section impacts", "take_ids": coverage["8_30S"]},
        ],
        "takes": treatments,
        "measurement_contract": {"minimum_hook_visual_events": 4, "minimum_8_30_visual_events": 5, "maximum_body_take_ms": 7000, "maximum_pattern_interrupt_gap_ms": 25000, "maximum_third_party_asset_runtime_share": 0.2, "maximum_single_asset_runtime_share": 0.1, "maximum_top_six_asset_runtime_share": 0.55, "maximum_asset_reuse_count": 5, "maximum_rolling_60s_same_asset_count": 3, "concrete_claim_visual_coverage": 1.0},
        "created_at": created_at,
    }


def materialize_creative_v3(root: Path, *, created_at: str, duration_overrides: dict[str, int] | None = None) -> dict[str, Any]:
    package_dir = root / PACKAGE_DIR
    manifest = register_v3_assets(root, created_at=created_at)
    brief = build_brief_v3(_read_json(package_dir / "editorial_brief.json"))
    _validate(root, "editorial_brief.schema.json", brief)
    command = _read_json(package_dir / "central_command.creative_direction.json")
    envelope = _read_json(root / "config" / "operational_envelopes" / "phase5-zero-cost-v1.json")
    channel_model = _read_json(root / "output" / "modeling" / "phase4" / "channel-model-v1" / "channel_model.json")
    packs = load_format_packs(root / "config" / "format_packs", root / "schemas" / "format_pack.schema.json")
    pack = next(item for item in packs if item["format_pack_id"] == "fp-broll-cinematic-narration")
    policy = evaluate_phase5_command(command, envelope, created_at=created_at)
    decision = choose_format_pack(command=command, policy_decision=policy, channel_model=channel_model, brief=brief, packs=packs, purpose="PROTOTYPE", budget_envelope_id=envelope["envelope_id"], quality_profile="DRAFT", created_at=created_at)
    bible = build_visual_continuity_bible(channel_model=channel_model, format_pack=pack, asset_manifest=manifest, created_at=created_at)
    bible["version"] = CREATIVE_VERSION
    bible["identity"]["principles"].extend(["three distinct causal sources are mandatory in 0–8 seconds", "action inserts must be interleaved with licensed moving clips", "TRUTH / RESPONSIBILITY / TODAY remains the locked information system", "generic landscape footage cannot be a fallback for an unmapped narrative chunk", "asset variety is measured by runtime concentration and rolling-window reuse, not merely by unique-source count"])
    bible["decision_history"].append({"decision_id": "creative-v3-1-remediation", "change": "replace v2 repeated hook source, short runtime, landscape dominance, missing captions and the v3.0 clouds fallback with a measured hybrid narrative", "reason": "creative-v2.1 market review rejected H1/H2, source variety, runtime and delivery readiness; v3.0 pre-gate audit measured 48 seconds of generic clouds caused by incomplete section recipes", "evidence_refs": ["docs/PHASE_5_MARKET_AND_VIRAL_REVIEW.md", "creative-v2/qa/creative_revision_metrics.json", "hero_engine/creative_v3_phase5.py:SECTION_ASSETS"], "created_at": created_at})
    bible["decision_history"].append({"decision_id": "creative-v3-2-repetition-remediation", "change": "rebalance all 59 takes using a complete semantic cut map and four hard anti-repetition thresholds", "reason": "supplemental full-timeline sampling found that six motifs occupied 66.3176% of creative-v3.1 despite unique-source and adjacent-repeat checks passing", "evidence_refs": ["creative-history/creative-v3.1-rejected-visual-repetition/qa/supplemental-review/timeline-01.jpg", "creative-history/creative-v3.1-rejected-visual-repetition/qa/supplemental-review/timeline-02.jpg", "creative-history/creative-v3.1-rejected-visual-repetition/qa/supplemental-review/timeline-03.jpg", "hero_engine/qa_creative_v3_phase5.py:_visual_repetition_scan"], "created_at": created_at})
    script = build_script_v3(brief, created_at=created_at)
    beats = build_beats_v3(script, manifest, duration_overrides)
    windows = [{"window": item["window"], "start_ms": item["start_ms"], "end_ms": item["end_ms"], "promise_function": item["function"], "evidence_refs": item["evidence_refs"]} for item in script["hook_windows"]]
    plan, allocated = build_take_plan(channel_id="heroverse74", video_id="phase5-pilot-001-creative-v3.2", creative_decision=decision, style_bible=bible, format_pack=pack, asset_manifest=manifest, narrative_beats=beats, hook_windows=windows, created_at=created_at)
    generic_fallback_takes = [take["take_id"] for take in plan["takes"] if TRANSITION_ASSET_ID in take["asset_origin"]]
    if generic_fallback_takes:
        raise RuntimeError(f"creative-v3.2 allocated forbidden generic clouds fallback: {generic_fallback_takes}")
    treatment = _build_treatment_v3(plan, created_at=created_at)
    artifacts = {"editorial_brief.json": ("editorial_brief.schema.json", brief), "policy_decision.json": ("phase5_policy_decision.schema.json", policy), "creative_direction_decision.json": ("creative_direction_decision.schema.json", decision), "channel_style_bible.json": ("visual_continuity_bible.schema.json", bible), "narrative_script.json": ("narrative_script.schema.json", script), "take_plan.json": ("take_plan.schema.json", plan), "creative_treatment_plan.json": ("creative_treatment_plan.schema.json", treatment)}
    for filename, (schema, value) in artifacts.items():
        _validate(root, schema, value)
        _write_json(root / V3_DIR / filename, value)
    _write_json(root / V3_DIR / "asset_manifest.allocated.json", allocated)
    return {"script": script, "plan": plan, "treatment": treatment, "manifest": manifest, "allocated": allocated}


def synthesize_creative_v3(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    preliminary = materialize_creative_v3(root, created_at=timestamp)
    engine = build_local_voice(root)
    audio_dir = root / V3_DIR / "audio" / "takes"
    speeds = {"take-001": 1.25, "take-002": 1.25, "take-003": 1.16}
    records, overrides = [], {}
    for take in preliminary["plan"]["takes"]:
        take_id, text = take["take_id"], str(take["narration"])
        speed = speeds.get(take_id, 1.01)
        rendered = synthesize_voice_sample(engine, text=text, output_path=audio_dir / f"{take_id}.wav", voice_id="am_onyx", speed=speed)
        slot = int(take["end_ms"]) - int(take["start_ms"]) if take_id in speeds else int(math.ceil(max(1500, rendered["duration_ms"] + 240) / 100) * 100)
        if slot > 7000:
            raise RuntimeError(f"voice requires a body take above the 7 s v3 ceiling: {take_id}={slot}")
        if take_id not in speeds:
            overrides[take_id] = slot
        records.append({"take_id": take_id, "text": text, "speed": speed, "duration_ms": rendered["duration_ms"], "timeline_slot_ms": slot, "fits_timeline_slot": rendered["duration_ms"] <= slot, "peak_linear": rendered["peak_linear"], "clipping": rendered["clipping"], "render_seconds": rendered["render_seconds"], "path": rendered["path"], "content_hash": rendered["content_hash"]})
    if any(not item["fits_timeline_slot"] for item in records[:3]):
        raise RuntimeError("creative-v3 hook narration does not fit 0–1/1–3/3–8 windows")
    if any(item["clipping"] for item in records):
        raise RuntimeError("creative-v3 raw voice render clipped")
    final = materialize_creative_v3(root, created_at=timestamp, duration_overrides=overrides)
    if [item["take_id"] for item in final["plan"]["takes"]] != [item["take_id"] for item in records]:
        raise RuntimeError("take IDs changed after measured voice rematerialization")
    timeline_duration = int(final["plan"]["takes"][-1]["end_ms"])
    if not 207_750 <= timeline_duration <= 286_250:
        raise RuntimeError(f"creative-v3 runtime outside measured archetype range: {timeline_duration} ms")
    manifest = {"schema_version": "1.0.0", "voice_render_id": _stable_id("voice-v3", final["script"]["script_id"], "am_onyx", timestamp), "status": "COMPLETE", "video_id": final["plan"]["video_id"], "script_id": final["script"]["script_id"], "script_version": final["script"]["version"], "adapter_id": "adapter-local-voice", "adapter_implementation": "KokoroFloatSpeed", "model": "models/kokoro/kokoro-v1.0.fp16.onnx", "model_hash": _sha256(root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx"), "voices_hash": _sha256(root / "models" / "kokoro" / "voices-v1.0.bin"), "voice_id": "am_onyx", "sample_rate": SAMPLE_RATE, "take_count": len(records), "takes": records, "hook_timing_gate": "PASS", "total_audio_duration_ms": sum(item["duration_ms"] for item in records), "total_render_seconds": round(sum(item["render_seconds"] for item in records), 6), "timeline_duration_ms": timeline_duration, "publication_approved": False, "limitations": ["Independent human full-video review remains required before publication.", "Photorealistic illustrative scenes require YouTube synthetic-content disclosure."], "created_at": timestamp}
    _validate(root, "voice_render_manifest.schema.json", manifest)
    _write_json(root / V3_DIR / "audio" / "voice_render_manifest.json", manifest)
    return {"voice": manifest, **final}


def recover_creative_v3_voice(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    """Recover a completed take set when orchestration ended after the last WAV.

    This path never claims synthesis latency. It re-measures every persisted WAV,
    rebuilds the timeline from those measurements, and fails closed on a missing,
    clipping, mismatched-rate, or overlong take.
    """

    import numpy as np
    import soundfile as sf

    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    preliminary = materialize_creative_v3(root, created_at=timestamp)
    audio_dir = root / V3_DIR / "audio" / "takes"
    speeds = {"take-001": 1.25, "take-002": 1.25, "take-003": 1.16}
    records: list[dict[str, Any]] = []
    overrides: dict[str, int] = {}
    for take in preliminary["plan"]["takes"]:
        take_id = take["take_id"]
        path = audio_dir / f"{take_id}.wav"
        if not path.is_file():
            raise FileNotFoundError(path)
        samples, sample_rate = sf.read(path, dtype="float32", always_2d=False)
        samples = np.asarray(samples, dtype=np.float32).reshape(-1)
        if sample_rate != SAMPLE_RATE or not len(samples):
            raise RuntimeError(f"invalid recovered voice artifact: {take_id}")
        duration_ms = round(len(samples) / sample_rate * 1000)
        peak = float(np.max(np.abs(samples)))
        slot = int(take["end_ms"]) - int(take["start_ms"]) if take_id in speeds else int(math.ceil(max(1500, duration_ms + 240) / 100) * 100)
        if slot > 7000:
            raise RuntimeError(f"recovered voice requires a body take above 7 s: {take_id}={slot}")
        if take_id not in speeds:
            overrides[take_id] = slot
        records.append({"take_id": take_id, "text": str(take["narration"]), "speed": speeds.get(take_id, 1.01), "duration_ms": duration_ms, "timeline_slot_ms": slot, "fits_timeline_slot": duration_ms <= slot, "peak_linear": round(peak, 6), "clipping": peak >= 1.0, "render_seconds": 0.0, "path": str(path.resolve()), "content_hash": _sha256(path)})
    if any(not item["fits_timeline_slot"] for item in records[:3]):
        raise RuntimeError("recovered creative-v3 hook does not fit 0–1/1–3/3–8 windows")
    if any(item["clipping"] for item in records):
        raise RuntimeError("recovered creative-v3 voice contains clipping")
    final = materialize_creative_v3(root, created_at=timestamp, duration_overrides=overrides)
    timeline_duration = int(final["plan"]["takes"][-1]["end_ms"])
    if not 207_750 <= timeline_duration <= 286_250:
        raise RuntimeError(f"recovered creative-v3 runtime outside measured archetype range: {timeline_duration} ms")
    manifest = {"schema_version": "1.0.0", "voice_render_id": _stable_id("voice-v3-recovered", final["script"]["script_id"], "am_onyx", timestamp), "status": "COMPLETE", "video_id": final["plan"]["video_id"], "script_id": final["script"]["script_id"], "script_version": final["script"]["version"], "adapter_id": "adapter-local-voice", "adapter_implementation": "KokoroFloatSpeed+MeasuredArtifactRecovery", "model": "models/kokoro/kokoro-v1.0.fp16.onnx", "model_hash": _sha256(root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx"), "voices_hash": _sha256(root / "models" / "kokoro" / "voices-v1.0.bin"), "voice_id": "am_onyx", "sample_rate": SAMPLE_RATE, "take_count": len(records), "takes": records, "hook_timing_gate": "PASS", "total_audio_duration_ms": sum(item["duration_ms"] for item in records), "total_render_seconds": 0.0, "timeline_duration_ms": timeline_duration, "publication_approved": False, "limitations": ["All 59 persisted WAV artifacts were re-measured after orchestration lost the completed process handle; per-take synthesis latency is unavailable and therefore recorded as zero, not estimated.", "Independent human pronunciation, emotion and full-video review remain required.", "Photorealistic illustrative scenes require YouTube synthetic-content disclosure."], "created_at": timestamp}
    _validate(root, "voice_render_manifest.schema.json", manifest)
    _write_json(root / V3_DIR / "audio" / "voice_render_manifest.json", manifest)
    return {"voice": manifest, **final}
