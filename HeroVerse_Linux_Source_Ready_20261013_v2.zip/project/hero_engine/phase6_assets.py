from __future__ import annotations

import hashlib
import copy
import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from contextlib import ExitStack, closing, contextmanager

from jsonschema import Draft202012Validator, FormatChecker

from .asset_library_phase5 import build_asset_catalog
from .asset_quality_phase5 import _safe_ranges, _scan


ROOT = Path(__file__).resolve().parents[1]
# `asset_manifest.json` is the versioned owner catalog written by
# `register_v3_assets`.  The older allocated view is a subset and cannot
# represent a newly approved local derivative, so using it here would make
# Phase 6 report a false semantic-capacity exhaustion.
BASELINE = Path("output/production/phase5/pilot-001/asset_manifest.json")
PHASE6_ROOT = Path("output/production/phase6/shared-assets")
MANIFEST = PHASE6_ROOT / "asset_manifest.json"
RECEIPT = PHASE6_ROOT / "asset_library_expansion.json"
TARGET_NEW = 6
QUERIES = [
    ("transition", "calm water nature filetype:video"),
    ("tension", "storm clouds timelapse filetype:video"),
    ("pressure", "storm clouds timelapse filetype:video"),
    ("perspective", "mountain clouds timelapse filetype:video"),
    ("clarity", "mountain clouds timelapse filetype:video"),
    ("renewal", "sunrise timelapse"),
    ("release", "sunrise timelapse"),
    ("progress", "river flowing landscape filetype:video"),
    ("decision", "river flowing landscape filetype:video"),
    ("action_plan", "river flowing landscape filetype:video"),
]


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _typography(asset: dict[str, Any]) -> bool:
    return str(asset.get('source', '')).startswith('procedural://heroverse/typography/')


@contextmanager
def _protected_font_dependency(path: Path, digest: str):
    """Read-only Windows font pin, never a deletable maintenance marker.

    Installed fonts legitimately have WinSxS hardlinks. Sharing is enforced on
    the file object (including its hardlinks); no write/delete sharing is given.
    Only fonts already authenticated by the source reader use this scope.
    """
    from . import maintenance_protocol as p
    ctypes, kernel = p._paused_cancel_kernel()
    handle = kernel.CreateFileW(str(path), 0x80000000, 1, None, 3, 0x200000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise PermissionError('font dependency protection unavailable')
    try:
        before = path.lstat()
        if not path.is_file() or getattr(before, 'st_file_attributes', 0) & 0x400:
            raise PermissionError('font dependency is not a regular file')
        def revalidate():
            size = ctypes.c_longlong()
            after = path.lstat()
            if (not kernel.GetFileSizeEx(handle, ctypes.byref(size))
                    or (before.st_dev, before.st_ino, before.st_size) != (after.st_dev, after.st_ino, after.st_size)
                    or _hash(path) != digest):
                raise PermissionError('font dependency changed or protection lost')
        revalidate()
        yield revalidate
        revalidate()
    finally:
        if not kernel.CloseHandle(handle):
            raise PermissionError('font dependency protection release failed')


def _adopt_typography_sources(root: Path, *, admission: Path, admission_hash: str,
        manifest_hash: str, receipt_hash: str, directory: Path, timestamp: str) -> dict[str, Any]:
    """Paused two-view transaction. Reuse measured sources, never rescan them.

    The historical catalog and six independent expansion sources stay intact.
    New IDs are take-scoped derivatives, not additional independent lineages.
    This grants allocation only, not installation, render or publication.
    """
    from . import maintenance_protocol as p, maintenance_paused_application as paused
    from .asset_quality_phase5 import verify_typography_asset_admission, _pinned_json
    from .phase6_visual_typography import read_typography_content_audit

    root = root.resolve(); directory = directory.resolve(); admission = admission.resolve()
    if directory.parent != (root / paused.RUNS).resolve():
        raise PermissionError('asset adoption requires a direct maintenance-run directory')
    binding = {'version': 'phase6-typography-active-library-v1',
        'admission': {'path': _relative(root, admission), 'sha256': admission_hash},
        'before_manifest_sha256': manifest_hash, 'before_expansion_sha256': receipt_hash}
    targets = (root / MANIFEST, root / RECEIPT)
    with p._paused_cancel_exclusive(), ExitStack() as stack:
        host = paused._check_host(root)
        pause = stack.enter_context(closing(p._PausedCancelPin(root / p.RUNTIME / 'PAUSE')))
        offered = _pinned_json(root, admission, admission_hash)
        ids = offered.get('typography_successor', {}).get('asset_ids', [])
        selected = [a for a in offered.get('assets', []) if a.get('asset_id') in ids]
        if not ids or len(set(ids)) != len(ids) or [a['asset_id'] for a in selected] != ids:
            raise PermissionError('asset adoption requires the exact admitted population')
        for asset in selected:
            if not _typography(asset) or asset.get('used_ranges') != []:
                raise PermissionError('asset adoption requires unconsumed admitted derivatives')
            verify_typography_asset_admission(root, asset)
        references = [a['typography_content_admission'] for a in selected]
        if any(ref != references[0] for ref in references):
            raise PermissionError('asset adoption requires one complete admission')
        # Pin the authenticated transitive proof until the two-view commit.
        files = {admission: admission_hash, root / BASELINE: _hash(root / BASELINE)}
        for asset in selected:
            ref = asset['typography_content_admission']
            report = _pinned_json(root, Path(ref['path']), ref['sha256'])
            if report['asset_ids'] != ids:
                raise PermissionError('asset adoption admission population differs')
            files[Path(ref['path'])] = ref['sha256']
            base = report['base_catalogue']; files[Path(base['path'])] = base['sha256']
            for item in report['rights']:
                files[Path(item['path'])] = item['sha256']
        proof = report['content_audit']
        checked = read_typography_content_audit(root, Path(proof['path']), expected_sha256=proof['sha256'])
        for item in [*checked['files'], *checked['source']['verified_bindings']]:
            files[Path(item['path'])] = item['sha256']
        fonts = {Path(layout[key]['path']).resolve() for layout in checked['source']['layouts'].values()
                 for key in ('font', 'composition_font')}
        pins = []
        for path, digest in files.items():
            if not path.resolve().is_relative_to(root):
                if path.resolve() not in fonts:
                    raise PermissionError('foreign non-font adoption dependency')
                pins.append(stack.enter_context(_protected_font_dependency(path, digest)))
                continue
            pin = stack.enter_context(closing(p._PausedCancelPin(path, capture=False)))
            if _hash(path) != digest:
                raise PermissionError('asset adoption dependency changed before pinning')
            pins.append(pin.revalidate)
        if directory.exists():
            commit = _read(directory / 'committed.json')
            prepared = _read(directory / 'prepared.json')
            if (commit.get('status') != 'COMMITTED_SOURCE_ALLOCATION_ONLY'
                    or prepared.get('binding') != binding or commit.get('binding') != binding
                    or commit.get('prepared_sha256') != _hash(directory / 'prepared.json')
                    or commit.get('after') != prepared.get('after')
                    or commit.get('after') != {r.as_posix(): _hash(root/r) for r in (MANIFEST, RECEIPT)}
                    or any(commit.get(k) is not False for k in ('render_authorized', 'publication_authorized'))):
                raise PermissionError('asset adoption prior attempt is incomplete or divergent')
            for row in prepared['preimages']:
                if _hash(directory / row['file']) != row['sha256']:
                    raise PermissionError('asset adoption preimage changed')
            pause.revalidate()
            for revalidate in pins: revalidate()
            return commit
        before = [path.read_bytes() for path in targets]
        if [p._hash_bytes(raw) for raw in before] != [manifest_hash, receipt_hash]:
            raise PermissionError('active library preimage differs')
        current, expansion = [json.loads(raw) for raw in before]
        p.validate(root, 'phase6_asset_library_expansion.schema.json', expansion)
        if expansion['status'] != 'COMPLETE' or expansion['manifest']['sha256'] != manifest_hash:
            raise PermissionError('active library expansion is not authenticated')
        current_ids = [a['asset_id'] for a in current['assets']]
        scopes = [take for a in selected for take in a['take_scope']]
        if (len(set(current_ids)) != len(current_ids) or set(ids) & set(current_ids)
                or len(scopes) != len(set(scopes))
                or any(a.get('historical_asset_id') not in current_ids for a in selected)
                or any(set(a.get('take_scope', [])) & set(scopes) for a in current['assets'] if _typography(a))):
            raise PermissionError('asset adoption identity or take ownership collides')
        updated = copy.deepcopy(current)
        updated['assets'].extend(copy.deepcopy(selected))
        updated['selected_count'] = len(updated['assets'])
        updated.setdefault('typography_adoptions', []).append(binding['admission'])
        manifest_bytes = (json.dumps(updated, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        expanded = copy.deepcopy(expansion)
        # Do not count procedural IDs as additional Commons assets/lineages.
        expanded['manifest']['sha256'] = p._hash_bytes(manifest_bytes)
        expanded['expansion_id'] = 'phase6-asset-expansion-' + p.canonical_hash(binding)[7:27]
        expanded['created_at'] = timestamp
        p.validate(root, 'phase6_asset_library_expansion.schema.json', expanded)
        receipt_bytes = (json.dumps(expanded, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        paused._prepare(root, sum(len(raw) for raw in (*before, manifest_bytes, receipt_bytes)))
        directory.mkdir(exist_ok=False)
        capture = p._PausedCancelDatabaseCapture(root, directory, binding, stack)
        boundary = p._paused_cancel_boundary(root, database_root=capture.work_root)
        states = []
        for index, (path, raw, payload) in enumerate(zip(targets, before, (manifest_bytes, receipt_bytes))):
            p._write_immutable_bytes(directory / f'preimage-{index}.json', raw)
            states.append({'target': path, 'relative_path': _relative(root, path),
                'existed_before': True, 'before': raw, 'desired_exists': True, 'payload': payload})
        prepared = {'binding': binding, 'database_capture': capture.reference(), 'boundary': boundary,
            'preimages': [{'path': s['relative_path'], 'file': f'preimage-{i}.json',
                          'sha256': p._hash_bytes(s['before'])} for i,s in enumerate(states)],
            'after': {s['relative_path']: p._hash_bytes(s['payload']) for s in states},
            'render_authorized': False, 'publication_authorized': False}
        p._write_immutable_bytes(directory/'prepared.json', p._canonical_bytes(prepared))
        def recheck():
            pause.revalidate()
            for revalidate in pins: revalidate()
            capture.revalidate()
            if (paused._check_host(root) != host
                    or p._paused_cancel_boundary(root, database_root=capture.work_root) != boundary):
                raise PermissionError('asset adoption operational boundary changed')
        try:
            recheck()
            for state in states:
                if not p._target_matches_preimage(state['target'], existed=True, payload=state['before']):
                    raise PermissionError('asset adoption target changed before commit')
                p._commit_migration_replacement(state['target'], state['payload'])
            recheck()
            if any(s['target'].read_bytes() != s['payload'] for s in states):
                raise PermissionError('asset adoption committed bytes diverged')
            commit = {'status': 'COMMITTED_SOURCE_ALLOCATION_ONLY', 'binding': binding,
                'prepared_sha256': _hash(directory/'prepared.json'), 'after': prepared['after'],
                'asset_ids': ids, 'historical_catalog_preserved': True, 'independent_lineages_added': 0,
                'render_authorized': False, 'publication_authorized': False,
                'completed_at': datetime.now(timezone.utc).isoformat()}
            p._write_immutable_bytes(directory/'committed.json', p._canonical_bytes(commit))
            return commit
        except BaseException as exc:
            rollback = paused._safe_rollback(states)
            p._write_immutable_bytes(directory/'rollback.json', p._canonical_bytes({
                'error_type': type(exc).__name__, 'rollback': rollback,
                'render_authorized': False, 'publication_authorized': False}))
            raise


def materialize_phase6_asset_expansion(root: Path = ROOT, *, created_at: str | None = None,
        typography_admission: Path | None = None, expected_admission_sha256: str | None = None,
        expected_manifest_sha256: str | None = None, expected_expansion_sha256: str | None = None,
        transaction_directory: Path | None = None) -> dict[str, Any]:
    root = root.resolve()
    timestamp = created_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    options = (typography_admission, expected_admission_sha256, expected_manifest_sha256,
               expected_expansion_sha256, transaction_directory)
    if any(item is not None for item in options):
        if any(item is None for item in options):
            raise PermissionError('complete anchored asset adoption request required')
        return _adopt_typography_sources(root, admission=typography_admission,
            admission_hash=expected_admission_sha256, manifest_hash=expected_manifest_sha256,
            receipt_hash=expected_expansion_sha256, directory=transaction_directory, timestamp=timestamp)
    baseline_path = root / BASELINE
    output_root = root / PHASE6_ROOT
    manifest_path = root / MANIFEST
    baseline = _read(baseline_path)
    baseline_ids = {item["asset_id"] for item in baseline["assets"]}
    if not manifest_path.is_file():
        seeded = dict(baseline)
        seeded["library_id"] = "phase6-heroverse-rights-library-v1"
        seeded["errors"] = []
        seeded["status"] = "PARTIAL"
        _write(manifest_path, seeded)

    current = _read(manifest_path)
    for asset in current.get('assets', []):
        if _typography(asset):
            from .asset_quality_phase5 import verify_typography_asset_admission
            verify_typography_asset_admission(root, asset)
    # The phase-5 allocated manifest is the authoritative catalog for owned
    # HeroVerse derivatives.  An existing Phase-6 expansion must absorb a
    # newly versioned owned asset before capacity is assessed; otherwise an
    # old expansion can falsely report semantic exhaustion even though the
    # verified source exists locally.  Third-party expansion records remain
    # untouched and every baseline record retains its own byte/hash evidence.
    baseline_by_id = {str(item["asset_id"]): item for item in baseline.get("assets", [])}
    current_by_id = {str(item["asset_id"]): item for item in current.get("assets", [])}
    merged_assets = [
        baseline_by_id.get(str(item.get("asset_id")), item)
        for item in current.get("assets", [])
    ]
    merged_ids = {str(item.get("asset_id")) for item in merged_assets}
    merged_assets.extend(
        item for asset_id, item in baseline_by_id.items() if asset_id not in merged_ids
    )
    if current.get("assets", []) != merged_assets:
        current["assets"] = merged_assets
        _write(manifest_path, current)
    eligible_existing_new = [
        item for item in current.get("assets", [])
        if item.get("asset_id") not in baseline_ids and not _typography(item) and item.get("content_quality_gate") == "PASS"
    ]
    if len(eligible_existing_new) < TARGET_NEW:
        # Discovery must remain remote-only.  The prior call downloaded a broad
        # Commons library before a take selected any of those bytes.  Catalogued
        # candidates deliberately never enter the active asset manifest: a
        # later allocation/acquisition step must request each exact asset.
        catalog = build_asset_catalog(
            output_root, max_candidates=len(QUERIES), queries=QUERIES,
        )
        expanded = dict(current)
        expanded["errors"] = [
            *list(current.get("errors", [])),
            {
                "query": "phase6-remote-catalog",
                "error": (
                    "LOCAL_ACQUISITION_DEFERRED_UNTIL_APPROVED_TAKE:"
                    f"{catalog['candidate_count']} remote candidates catalogued"
                ),
            },
        ]
    else:
        expanded = current

    records = []
    for asset in expanded.get("assets", []):
        if asset["asset_id"] in baseline_ids or _typography(asset):
            continue
        path = Path(asset["uri"])
        if not path.is_file() or _hash(path) != asset.get("content_hash"):
            asset["content_quality_gate"] = "BLOCKED"
            asset["safe_ranges"] = []
            safe_capacity = 0
        else:
            scan = _scan(path)
            safe = _safe_ranges(float(asset["duration_seconds"]), scan)
            safe_capacity = sum(item["end_ms"] - item["start_ms"] for item in safe)
            asset["safe_ranges"] = safe
            asset["used_ranges"] = []
            asset["content_quality_gate"] = "PASS" if safe_capacity >= 8_000 else "LIMITED"
            asset["content_quality_evidence"] = RECEIPT.as_posix()
        records.append({
            "asset_id": asset["asset_id"], "semantic_role": asset["semantic_role"],
            "rights_status": asset["rights_status"], "quality_status": asset["content_quality_gate"],
            "safe_capacity_ms": safe_capacity, "content_hash": asset["content_hash"],
            "rights_evidence_ref": _relative(root, Path(asset["rights_evidence_uri"])),
        })

    eligible_new = sum(item["quality_status"] == "PASS" for item in records)
    expanded["schema_version"] = "1.0.0"
    expanded["library_id"] = "phase6-heroverse-rights-library-v1"
    expanded["provider"] = "Wikimedia Commons API + inherited verified HeroVerse assets"
    expanded["provider_cost_usd"] = 0
    expanded["license_fee_usd"] = 0
    expanded["selected_count"] = len(expanded.get("assets", []))
    expanded["minimum_required"] = len(baseline_ids) + TARGET_NEW
    expanded["status"] = "COMPLETE" if eligible_new >= TARGET_NEW else "PARTIAL"
    _write(manifest_path, expanded)
    manifest_hash = _hash(manifest_path)
    expansion_id = "phase6-asset-expansion-" + hashlib.sha256(
        (manifest_hash + "|" + "|".join(sorted(item["asset_id"] for item in records))).encode()
    ).hexdigest()[:20]
    value = {
        "schema_version": "1.0.0", "expansion_id": expansion_id,
        "status": "COMPLETE" if eligible_new >= TARGET_NEW else ("PARTIAL" if records else "BLOCKED"),
        "library_id": "phase6-heroverse-rights-library-v1", "provider": "Wikimedia Commons API",
        "baseline_asset_count": len(baseline_ids), "target_new_asset_count": TARGET_NEW,
        "new_asset_count": len(records), "eligible_new_asset_count": eligible_new,
        "assets": records, "errors": expanded.get("errors", []),
        "manifest": {"path": _relative(root, manifest_path), "sha256": manifest_hash},
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": timestamp,
    }
    schema = _read(root / "schemas/phase6_asset_library_expansion.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    _write(root / RECEIPT, value)
    return value


if __name__ == "__main__":
    print(json.dumps(materialize_phase6_asset_expansion(ROOT), ensure_ascii=False, indent=2))
