from __future__ import annotations

from typing import Any


def evaluate_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    format_name = snapshot["format"]
    gates = config["quality_gates"]
    age_hours = snapshot.get("age_hours")
    if age_hours is None or float(age_hours) < 24:
        return {
            "youtube_video_id": snapshot["youtube_video_id"],
            "format": format_name,
            "decision": "INSUFFICIENT_DATA",
            "reason": "A comparable decision requires a snapshot at age >= 24 hours.",
            "gates": [],
        }

    if format_name == "long":
        required = {
            "ctr": snapshot.get("ctr"),
            "intro_30s_rate": snapshot.get("intro_30s_rate"),
            "average_view_duration_minutes": (
                float(snapshot["average_view_duration_seconds"]) / 60
                if snapshot.get("average_view_duration_seconds") is not None
                else None
            ),
        }
        thresholds = {
            "ctr": gates["long_ctr_scale"],
            "intro_30s_rate": gates["long_intro_30s_scale"],
            "average_view_duration_minutes": gates["long_average_view_duration_minutes_scale"],
        }
    elif format_name == "short":
        views = float(snapshot.get("views") or 0)
        subscribers = float(snapshot.get("subscribers_gained") or 0)
        required = {
            "viewed_rate": snapshot.get("viewed_rate"),
            "average_percentage_viewed": snapshot.get("average_percentage_viewed"),
            "subscribers_per_1000_views": subscribers / views * 1000 if views > 0 else None,
        }
        thresholds = {
            "viewed_rate": gates["short_viewed_rate_scale"],
            "average_percentage_viewed": gates["short_average_percentage_viewed_scale"],
            "subscribers_per_1000_views": gates["short_subscribers_per_1000_scale"],
        }
    else:
        raise ValueError(f"Unknown format: {format_name}")

    missing = [name for name, value in required.items() if value is None]
    if missing:
        return {
            "youtube_video_id": snapshot["youtube_video_id"],
            "format": format_name,
            "decision": "INSUFFICIENT_DATA",
            "reason": f"Missing required metrics: {', '.join(missing)}.",
            "gates": [],
        }

    evaluated = [
        {
            "metric": name,
            "actual": round(float(required[name]), 6),
            "threshold": threshold,
            "passed": float(required[name]) >= float(threshold),
        }
        for name, threshold in thresholds.items()
    ]
    passed = sum(1 for item in evaluated if item["passed"])
    if passed == len(evaluated):
        decision = "SCALE"
        reason = "All scale gates passed. Produce controlled variations of the same thesis and packaging pattern."
    elif passed >= 2:
        decision = "ITERATE"
        reason = "Two gates passed. Change only the failed variable, then retest at the same snapshot age."
    else:
        decision = "STOP"
        reason = "Fewer than two gates passed. Do not create another variation until the thesis or packaging is replaced."
    return {
        "youtube_video_id": snapshot["youtube_video_id"],
        "format": format_name,
        "age_hours": age_hours,
        "decision": decision,
        "passed_gates": passed,
        "total_gates": len(evaluated),
        "reason": reason,
        "gates": evaluated,
    }


def latest_decisions(snapshots: list[dict[str, Any]], config: dict[str, Any]) -> list[dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for snapshot in snapshots:
        video_id = snapshot["youtube_video_id"]
        current = latest.get(video_id)
        current_age = float(current.get("age_hours") or 0) if current else -1
        candidate_age = float(snapshot.get("age_hours") or 0)
        if current is None or candidate_age > current_age:
            latest[video_id] = snapshot
    return [evaluate_snapshot(snapshot, config) for snapshot in latest.values()]
