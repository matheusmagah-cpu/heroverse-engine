from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Any, Callable, Protocol


MEDIA_LEASE_SECONDS = 7_200
MEDIA_LEASE_HEARTBEAT_SECONDS = 300.0


class LeaseRenewalQueue(Protocol):
    def renew_lease(
        self,
        job_id: str,
        *,
        worker_id: str,
        lease_seconds: int,
        now: datetime | None = None,
    ) -> dict[str, Any]: ...


class MediaLeaseHeartbeatError(RuntimeError):
    """The exact media lease could not be proven healthy."""


def _utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        raise ValueError("media lease heartbeat clock must be timezone-aware")
    return value.astimezone(timezone.utc)


def _parse_timestamp(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        raise ValueError("renewed media lease omitted its deadline")
    return _utc(datetime.fromisoformat(value.replace("Z", "+00:00")))


class MediaLeaseHeartbeat:
    """Owner-bound lease renewal for one synchronous local media execution.

    The daemon never claims or finishes a job.  It can only renew the exact
    lease supplied by the caller, and any queue error or identity divergence is
    retained for the foreground executor to reject before committing success.
    A blocking subprocess cannot be cancelled safely by this helper; when a
    failure happens during that subprocess, local work may finish, but
    ``assert_healthy`` prevents all subsequent queue success/downstream effects.
    """

    def __init__(
        self,
        queue: LeaseRenewalQueue,
        *,
        job_id: str,
        worker_id: str,
        lease_seconds: int = MEDIA_LEASE_SECONDS,
        interval_seconds: float = MEDIA_LEASE_HEARTBEAT_SECONDS,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        if not isinstance(job_id, str) or not job_id.startswith("job-"):
            raise ValueError("media lease heartbeat requires an exact job id")
        if not isinstance(worker_id, str) or not worker_id:
            raise ValueError("media lease heartbeat requires an exact worker id")
        if lease_seconds < 2:
            raise ValueError("media lease heartbeat requires a lease of at least two seconds")
        if interval_seconds <= 0 or interval_seconds >= lease_seconds:
            raise ValueError("media lease heartbeat interval must be inside the lease window")
        self._queue = queue
        self.job_id = job_id
        self.worker_id = worker_id
        self.lease_seconds = lease_seconds
        self.interval_seconds = float(interval_seconds)
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._stop = threading.Event()
        self._failed = threading.Event()
        self._state_lock = threading.Lock()
        self._renew_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._failure: Exception | None = None
        self._last_deadline: datetime | None = None

    @property
    def failed(self) -> bool:
        return self._failed.is_set()

    @property
    def running(self) -> bool:
        thread = self._thread
        return bool(thread is not None and thread.is_alive())

    @property
    def daemon(self) -> bool | None:
        thread = self._thread
        return thread.daemon if thread is not None else None

    @property
    def last_deadline(self) -> datetime | None:
        with self._state_lock:
            return self._last_deadline

    def _record_failure(self, exc: Exception) -> None:
        with self._state_lock:
            if self._failure is None:
                self._failure = exc
                self._failed.set()
        self._stop.set()

    def assert_healthy(self) -> None:
        with self._state_lock:
            failure = self._failure
        if failure is not None:
            raise MediaLeaseHeartbeatError(
                f"media lease heartbeat failed for {self.job_id}/{self.worker_id}: "
                f"{type(failure).__name__}: {failure}"
            ) from failure

    def renew_now(self) -> dict[str, Any]:
        self.assert_healthy()
        if self._stop.is_set():
            raise MediaLeaseHeartbeatError(
                f"media lease heartbeat is already stopped for {self.job_id}"
            )
        with self._renew_lock:
            self.assert_healthy()
            if self._stop.is_set():
                raise MediaLeaseHeartbeatError(
                    f"media lease heartbeat is already stopped for {self.job_id}"
                )
            moment = _utc(self._clock())
            try:
                renewed = self._queue.renew_lease(
                    self.job_id,
                    worker_id=self.worker_id,
                    lease_seconds=self.lease_seconds,
                    now=moment,
                )
                if (
                    renewed.get("job_id") != self.job_id
                    or renewed.get("state") != "LEASED"
                    or renewed.get("lease_owner") != self.worker_id
                ):
                    raise PermissionError(
                        "renewed media lease diverges from its exact job/owner/state"
                    )
                deadline = _parse_timestamp(renewed.get("lease_until"))
                if deadline <= moment:
                    raise PermissionError("renewed media lease is not future-dated")
            except Exception as exc:
                self._record_failure(exc)
                raise MediaLeaseHeartbeatError(
                    f"could not renew exact media lease {self.job_id}/{self.worker_id}"
                ) from exc
            with self._state_lock:
                self._last_deadline = deadline
            return renewed

    def _run(self) -> None:
        while not self._stop.wait(self.interval_seconds):
            try:
                self.renew_now()
            except MediaLeaseHeartbeatError:
                return

    def start(self) -> None:
        with self._state_lock:
            if self._thread is not None:
                raise RuntimeError("media lease heartbeat cannot be started twice")
        # Prove ownership synchronously before any protected media work begins.
        self.renew_now()
        thread = threading.Thread(
            target=self._run,
            name=f"media-lease-heartbeat-{self.job_id[-12:]}",
            daemon=True,
        )
        with self._state_lock:
            self._thread = thread
        thread.start()

    def stop(self) -> None:
        self._stop.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            # Event.wait wakes immediately; joining without a timeout ensures no
            # late renewal can escape the exact execution boundary.
            thread.join()

    def __enter__(self) -> MediaLeaseHeartbeat:
        self.start()
        return self

    def __exit__(self, _exc_type: object, _exc: object, _tb: object) -> bool:
        self.stop()
        return False
