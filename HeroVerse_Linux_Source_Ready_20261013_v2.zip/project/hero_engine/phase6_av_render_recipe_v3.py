"""Receipt-bound active successor for the frozen Stage-C render recipe v15.

The v15 module remains available for historical replay.  This successor uses
the same pure compiler but replaces only its editorial visual preparation with
the v3 receipt-bound consumer during one call, then records the new source
implementation in the resulting candidate.
"""
from __future__ import annotations

import copy
import hashlib
from pathlib import Path
from threading import RLock
from typing import Any

from . import phase6_av_render_recipe as _v2
from .phase6_av_visual_recipe_adapter_v3 import compile_take003_editorial_visual_spec

AVRenderRecipeError = _v2.AVRenderRecipeError
_LOCK = RLock()


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _editorial_visual_preparation(root: Path, timeline: dict[str, Any], timeline_ref: dict[str, Any], bindings: dict[str, Any] | None) -> dict[str, Any] | None:
    if bindings is None:
        return None
    if timeline_ref["independent_arguments"] is None:
        raise AVRenderRecipeError("visual preparation requires independent Stage-A recomposition first")
    spec = compile_take003_editorial_visual_spec(root, timeline=timeline, bindings=bindings)
    if spec["status"] != "COMPILED_TAKE003_VISUAL_SPEC_NOT_ADMITTED" or any(spec["authority"].values()):
        raise AVRenderRecipeError("active visual preparation attempted unsupported authority")
    return {
        "adapter_version": spec["adapter_version"], "recipe_id": spec["recipe_id"],
        "visual_spec_id": spec["visual_spec_id"], "spec_canonical_sha256": spec["canonical_sha256"],
        "filtergraph": spec["filtergraph"], "source_binding": spec["source_binding"],
        "generated_files": copy.deepcopy(spec["generated_files"]),
        "dependency_bindings": copy.deepcopy(spec["dependency_bindings"]),
        "covered_frame_count": spec["coverage"]["covered_frame_count"],
        "planned_total_frame_count": spec["coverage"]["planned_total_frame_count"],
        "global_start_frame": spec["supported_span"]["global_start_frame"],
        "global_end_frame_exclusive": spec["supported_span"]["global_end_frame_exclusive"],
        "full_timeline_covered": False, "blockers": list(spec["blockers"]),
        "authority": copy.deepcopy(_v2.FALSE_AUTHORITY),
    }


def _active_result(root: Path, value: dict[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(value)
    # The successor calls the frozen compiler as a constrained implementation
    # dependency.  Keep that provenance rather than presenting the v3 wrapper
    # as if it were a clean-room compiler.  Historical receipts still bind v2,
    # while an active recipe additionally binds the active consumer pair.
    paths = list(value["implementation_bindings"])
    present = {row["path"] for row in paths}
    for relative in ("hero_engine/phase6_av_render_recipe_v3.py", "hero_engine/phase6_av_visual_recipe_adapter_v3.py"):
        if relative not in present:
            raw = (root / relative).read_bytes()
            paths.append({"path": relative, "sha256": _sha(raw), "size_bytes": len(raw)})
    value["implementation_bindings"] = paths
    value["recipe_id"] = _v2._identity(value, "recipe_id", "phase6-av-render-recipe-")
    _v2._validate_output(value)
    return value


def compile_phase6_av_render_recipe(root: Path, timeline: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    root = Path(root).resolve(strict=True)
    with _LOCK:
        original = _v2._editorial_visual_preparation
        _v2._editorial_visual_preparation = _editorial_visual_preparation
        try:
            value = _v2.compile_phase6_av_render_recipe(root, timeline, **kwargs)
        finally:
            _v2._editorial_visual_preparation = original
    return _active_result(root, value)


def verify_phase6_av_render_recipe(root: Path, candidate: dict[str, Any], timeline: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    expected = compile_phase6_av_render_recipe(root, timeline, **kwargs)
    if _v2._canonical(candidate) != _v2._canonical(expected):
        raise AVRenderRecipeError("render recipe differs from independent active recompilation")
    return expected
