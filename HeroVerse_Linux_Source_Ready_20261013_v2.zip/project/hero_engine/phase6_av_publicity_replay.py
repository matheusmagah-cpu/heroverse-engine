"""Read-only integrity replay of an externally pinned v2 counter-observation.

This does not run a detector or authenticate the missing LIVE runtime,
calibration, or canonical Stage-A boundary. It cannot approve publication.
The future consumer must enforce those separate boundaries itself. Historical
v1 evidence is not silently promoted. No file is created by this module.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

from hero_engine import phase6_av_publicity_v2 as P

VERSION = "phase6-av-publicity-counterproof-integrity-replay-v1"
SCOPE_VERSION = "phase6-av-publicity-counterproof-integrity-scope-v1"
LIMITATIONS = (
    "INTEGRITY_REPLAY_IS_NOT_NEW_DECODE_OR_INFERENCE",
    "CANONICAL_STAGE_A_MUST_BE_VERIFIED_BY_CONSUMER",
    "LIVE_RUNTIME_AND_DETECTOR_CALIBRATION_REQUIRE_SEPARATE_PROOF",
    "NEGATIVE_SAMPLING_IS_NOT_LEGAL_CLEARANCE",
    "NOT_INSTALLED_IN_ADMISSION_OR_PUBLICATION",
)


def _clock():
    return datetime.now(timezone.utc)


class _Reader:
    def __init__(self, root):
        self.root = root
        self.items = {}

    def raw(self, item, *, confined=True):
        if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                or type(item["size_bytes"]) is not int or item["size_bytes"] <= 0):
            raise P.PublicityError("exact positive binding triple required")
        key = str(P.resolve(self.root, item["path"], confined=confined))
        if key in self.items and self.items[key][0] != item:
            raise P.PublicityError("one path has divergent replay identities")
        raw = P.reopen(self.root, item, confined=confined)
        if len(raw) != item["size_bytes"] or P.sha(raw) != item["sha256"]:
            raise P.PublicityError("returned replay buffer differs from external pin")
        # Only the caller-owned reader can accumulate the closure.
        self.items[key] = (dict(item), confined)
        return raw

    def doc(self, item, *, confined=True):
        return P.document(self.raw(item, confined=confined))

    def touch(self, item, *, confined=True):
        key = str(P.resolve(self.root, item["path"], confined=confined))
        if key not in self.items:
            self.raw(item, confined=confined)
        elif self.items[key][0] != item:
            raise P.PublicityError("one path has divergent replay identities")

    def recheck(self):
        for item, confined in tuple(self.items.values()):
            self.raw(item, confined=confined)


def _assets(reader, timeline_binding, library_binding):
    """Population from authenticated buffers, never helper-side semantic reopens."""
    timeline, library = reader.doc(timeline_binding), reader.doc(library_binding)
    grouped, span_ids = {}, set()
    for span in timeline.get("render_spans") or []:
        span_id = span["span_id"]
        if type(span_id) is not str or not span_id or span_id in span_ids:
            raise P.PublicityError("duplicate or invalid span identity")
        span_ids.add(span_id)
        supplied = span["asset_binding"]
        path = P.resolve(reader.root, supplied["path"], confined=True)
        actual = P.binding(path)
        if actual["sha256"] != supplied["sha256"]:
            raise P.PublicityError("timeline source bytes differ")
        reader.touch(actual)
        key = str(path), actual["sha256"]
        if key not in grouped:
            matches = [a for a in library["assets"] if P.resolve(reader.root, a["uri"], confined=True) == path
                       and a["content_hash"] == actual["sha256"]]
            if len(matches) != 1:
                raise P.PublicityError("ambiguous asset metadata")
            asset = matches[0]
            if any(type(asset.get(k)) is not str or not asset[k].strip() for k in ("asset_id", "source", "creator_or_holder")):
                raise P.PublicityError("asset metadata incomplete")
            grouped[key] = {"asset_id": asset["asset_id"], "source": actual,
                            "metadata_risk_terms": P.metadata_publicity_risks(asset), "spans": []}
        grouped[key]["spans"].append({"span_id": span_id,
            "source_start_frame": span["source_start_frame"], "source_end_frame": span["source_end_frame"],
            "samples": P.samples(span["source_start_frame"], span["source_end_frame"])})
    if not grouped or len({a["asset_id"] for a in grouped.values()}) != len(grouped):
        raise P.PublicityError("empty or ambiguous asset population")
    return [dict(row, spans=sorted(row["spans"], key=lambda s: s["span_id"])) for _, row in sorted(grouped.items())]


def _journal(reader, row, request):
    common = {key: row[key] for key in ("request", "source", "span_id", "source_frame_index", "evidence_mode", "authority")}
    command = P.decode_command(request["policy"], row["source"], row["source_frame_index"])
    if (reader.doc(row["decode_receipt"]) != {"common": common, "command": command, "frame": row["frame"]}
            or reader.doc(row["decode_intent"]) != {"common": common, "command": command}
            or reader.doc(row["detect_intent"]) != {"common": common, "frame": row["frame"]}):
        raise P.PublicityError("authenticated sample journal differs")


def _scan(reader, receipt_binding, expected_inputs, assets, now):
    receipt = reader.doc(receipt_binding)
    P._schema(receipt)
    if receipt.get("document_type") != "PHASE6_AV_PUBLICITY_OBSERVATIONS":
        raise P.PublicityError("observation receipt required")
    request = reader.doc(receipt["request"])
    if (request.get("root") != str(reader.root)
            or any(request.get(key) != value for key, value in expected_inputs.items())
            or request.get("authority") != P.AUTHORITY
            or request.get("evidence_mode") != receipt["evidence_mode"]
            or receipt["authority"] != P.AUTHORITY
            or receipt["status"] != "PASS" or receipt["detected_face_count"] != 0
            or receipt["claim_boundary"] != P.CLAIM):
        raise P.PublicityError("receipt/request identity, mode or risk differs")
    policy = reader.doc(expected_inputs["policy_binding"], confined=False)
    if request.get("policy") != policy:
        raise P.PublicityError("embedded policy differs from external binding")
    P.validate_policy(reader.root, policy)
    for key in ("module", "schema", "legacy_metadata_implementation", "model",
                "license", "model_card", "ffmpeg", "python"):
        reader.raw(policy[key], confined=False)
    for item in policy["runtime_files"]:
        reader.raw(item, confined=False)
    if (receipt["assets"] != assets or request.get("assets") != assets
            or any(asset["metadata_risk_terms"] for asset in assets)):
        raise P.PublicityError("asset population or metadata risk differs")
    expected = [(a["source"], s["span_id"], i) for a in assets
                for s in a["spans"] for i in s["samples"]]
    rows = [reader.doc(item) for item in receipt["samples"]]
    paths = [str(P.resolve(reader.root, item["path"], confined=True)) for item in receipt["samples"]]
    if (len(set(paths)) != len(paths) or receipt["sample_count"] != len(expected)
            or len(rows) != len(expected)
            or [(r["source"], r["span_id"], r["source_frame_index"]) for r in rows] != expected):
        raise P.PublicityError("missing, duplicated or reordered sample coverage")
    observed = [P.utc(row["observed_at"]) for row in rows]
    oldest, newest = min(observed), max(observed)
    if (P.utc(receipt["observed_at"]) != newest or newest > now
            or P.utc(receipt["valid_until"]) != oldest + timedelta(seconds=P.LIMITS["ttl_seconds"])
            or now >= P.utc(receipt["valid_until"])):
        raise P.PublicityError("stale, future or forged observation interval")
    pixels_and_raw = []
    for row in rows:
        if (row["status"] != "PASS" or row["errors"] or type(row["face_count"]) is not int
                or row["face_count"] != 0 or row["authority"] != P.AUTHORITY
                or row["request"] != receipt["request"] or row["evidence_mode"] != receipt["evidence_mode"]):
            raise P.PublicityError("sample mode, request, risk or authority differs")
        reader.touch(row["source"])
        frame = reader.raw(row["frame"])
        raw = reader.doc(row["raw"])
        width, height, _ = P.ppm(frame)
        if P.face_count(raw, width, height) != 0:
            raise P.PublicityError("stored raw detector contradicts zero-face sample")
        _journal(reader, row, request)
        # Retain fingerprints, not every full RGB frame in RAM simultaneously.
        pixels_and_raw.append((P.sha(frame), P.sha(P.canonical(raw))))
    return receipt, rows, pixels_and_raw


def _prepare_replay(root, *, counterproof_binding, expected_source_receipt,
                    expected_counter_receipt, expected_timeline,
                    expected_library, expected_policy, require_live=True, now=None):
    """One actual reconstruction; its Reader never comes from caller evidence."""
    if type(require_live) is not bool:
        raise P.PublicityError("require_live must be an explicit boolean")
    (counterproof_binding, expected_source_receipt, expected_counter_receipt,
     expected_timeline, expected_library, expected_policy) = deepcopy((
        counterproof_binding, expected_source_receipt, expected_counter_receipt,
        expected_timeline, expected_library, expected_policy))
    root = Path(root).resolve()
    started = P._instant(_clock() if now is None else now)
    reader = _Reader(root)
    proof = reader.doc(counterproof_binding)
    P._schema(proof)
    if (proof.get("document_type") != "PHASE6_AV_PUBLICITY_COUNTERPROOF"
            or proof["source_receipt"] != expected_source_receipt
            or proof["counterproof_receipt"] != expected_counter_receipt
            or proof["authority"] != P.AUTHORITY or proof["claim_boundary"] != P.CLAIM):
        raise P.PublicityError("counterproof external identity/authority differs")
    if require_live and proof["status"] != "PASS_LIVE":
        raise P.PublicityError("LIVE counterproof required")
    if (P.resolve(root, expected_source_receipt["path"], confined=True).parent
            == P.resolve(root, expected_counter_receipt["path"], confined=True).parent):
        raise P.PublicityError("source and counter-observation require separate journals")
    if P.utc(proof["verified_at"]) > started or started >= P.utc(proof["valid_until"]):
        raise P.PublicityError("counterproof is future or expired")
    reader.raw(expected_timeline)
    reader.raw(expected_library)
    reader.raw(expected_policy, confined=False)
    assets = _assets(reader, expected_timeline, expected_library)
    inputs = {"timeline": expected_timeline, "library": expected_library, "policy_binding": expected_policy}
    original, old_rows, old_payloads = _scan(reader, expected_source_receipt, inputs, assets, started)
    counter, new_rows, new_payloads = _scan(reader, expected_counter_receipt, inputs, assets, started)
    mode = original["evidence_mode"]
    if (counter["evidence_mode"] != mode or proof["status"] != "PASS_" + mode
            or (require_live and mode != "LIVE")):
        raise P.PublicityError("counterproof does not preserve required evidence mode")
    if (proof["sample_count"] != original["sample_count"]
            or proof["sample_count"] != counter["sample_count"]
            or proof["valid_until"] != original["valid_until"]
            or P.utc(proof["verified_at"]) < max(P.utc(original["observed_at"]), P.utc(counter["observed_at"]))
            or P.utc(proof["verified_at"]) >= min(P.utc(original["valid_until"]), P.utc(counter["valid_until"]))):
        raise P.PublicityError("counterproof time or sample count does not derive from journals")
    for old, new, left, right in zip(old_rows, new_rows, old_payloads, new_payloads):
        if left != right:
            raise P.PublicityError("counter-observation pixels or raw output contradict source receipt")
        for key in ("frame", "raw", "decode_receipt", "decode_intent", "detect_intent"):
            if P.resolve(root, old[key]["path"], confined=True) == P.resolve(root, new[key]["path"], confined=True):
                raise P.PublicityError("counter-observation aliases the original journal")
    expires = min(P.utc(original["valid_until"]), P.utc(counter["valid_until"]))
    result = {
        "version": VERSION, "status": "EXACT_CACHE_REPLAY_INTEGRITY_ONLY_NOT_ADMITTED",
        "evidence_mode": mode, "counterproof": dict(counterproof_binding),
        "valid_until": expires.isoformat(),
        "sample_pairs": len(old_rows), "reopened_files": len(reader.items),
        "decode_calls": 0, "inference_calls": 0, "files_written": 0,
        "provider_switch": False, "technical_cost_brl": 0,
        "authority": dict(P.AUTHORITY), "limitations": list(LIMITATIONS),
    }
    return _ReplayScope(reader, result, max(started, P.utc(proof["verified_at"])), expires)


class _ReplayScope:
    """Same-call closure only; no public API accepts this object as evidence."""
    def __init__(self, reader, result, not_before, expires):
        self._reader = reader
        self._result = result
        self._last_checked = not_before
        self._expires = expires
        self._closed = False
        self._failed = False

    def _active(self):
        if self._closed or self._failed:
            raise P.PublicityError("replay scope is closed or previously failed")

    def snapshot(self):
        self._active()
        if "replayed_at" not in self._result:
            raise P.PublicityError("replay scope has not completed its initial recheck")
        return deepcopy(self._result)

    def recheck(self):
        self._active()
        try:
            self._reader.recheck()  # Reopens authenticated bytes; no _scan or inference.
            final = P._instant(_clock())
            if final < self._last_checked or final >= self._expires:
                raise P.PublicityError("replay clock rolled back or evidence expired during replay")
            self._last_checked = final
            self._result["replayed_at"] = final.isoformat()
            return self.snapshot()
        except BaseException:
            # A caller cannot catch a failed recheck and later close successfully.
            self._failed = True
            raise

    def close(self):
        try:
            return self.recheck()
        finally:
            self._closed = True


class _ReplayView:
    """Copied observations, not a receipt certifying a still-open coordinator."""
    def __init__(self, scope):
        self.__scope = scope

    @property
    def result(self):
        return self.__scope.snapshot()

    def recheck(self):
        return self.__scope.recheck()


@contextmanager
def verified_counterproof_integrity(root, *, counterproof_binding, expected_source_receipt,
                                   expected_counter_receipt, expected_timeline,
                                   expected_library, expected_policy, require_live=True, now=None):
    """Keep the genuine replay closure private while a consumer composes checks.

    Preparation runs once, including both authenticated journals. Access and
    recheck return independent copies; the view expires on every exit. Rechecks
    do not call _assets/_scan, decode, inference or writes. A failed recheck
    poisons the scope even if caught by the consumer.

    A result read inside the with-block records its latest successful recheck,
    not a future closing time. The consumer MUST finish the block normally and
    apply its own aggregate final clock before claiming an integrated result.
    Neither this view nor its copies approve runtime, calibration or Stage A.
    """
    scope = _prepare_replay(root, counterproof_binding=counterproof_binding,
        expected_source_receipt=expected_source_receipt, expected_counter_receipt=expected_counter_receipt,
        expected_timeline=expected_timeline, expected_library=expected_library,
        expected_policy=expected_policy, require_live=require_live, now=now)
    try:
        scope.recheck()
    except BaseException:
        scope._closed = True
        raise
    try:
        yield _ReplayView(scope)
    finally:
        scope.close()


def replay_counterproof(root, *, counterproof_binding, expected_source_receipt,
                        expected_counter_receipt, expected_timeline,
                        expected_library, expected_policy, require_live=True, now=None):
    """Compatible integrity-only replay: one preparation and one final recheck.

    LIVE describes the recorded mode, not authentication of the still-unresolved
    runtime/calibration. Returns the existing result shape, with replayed_at from
    the exact final clock after the Reader closes its integrity recheck. Never
    accepts a ready closure, backend or success flag and never refreshes TTL.
    """
    scope = _prepare_replay(root, counterproof_binding=counterproof_binding,
        expected_source_receipt=expected_source_receipt, expected_counter_receipt=expected_counter_receipt,
        expected_timeline=expected_timeline, expected_library=expected_library,
        expected_policy=expected_policy, require_live=require_live, now=now)
    return scope.close()
