from __future__ import annotations

import hashlib
from copy import deepcopy
import json
import math
import os
import re
import shutil
import stat
import subprocess
import tempfile
import time
import uuid
from datetime import datetime, timezone
from contextvars import ContextVar
from functools import wraps
from pathlib import Path
from typing import Any, Callable

import numpy as np
import soundfile as sf
from jsonschema import Draft202012Validator, FormatChecker

from .production_capacity import RECEIPTS as CAPACITY_RECEIPTS, run_phase6_capacity_preflight, verify_phase6_capacity_receipt, Phase6ResourcePreparation, ResourceWait
from .phase6_visual_preflight import (materialize_current_visual_preflight, require_current_visual_preflight,
                                      verify_visual_preflight, verify_completed_visual_preflight)
from .phase6_render_contract import (PHASE6_SEGMENT_RENDERER, PALETTE_QP1_SEGMENT_RENDERER,
                                    segment_encoder_arguments, plan_renderer, final_video_arguments)
from .media_lease_heartbeat import MEDIA_LEASE_SECONDS, MediaLeaseHeartbeat, MediaLeaseHeartbeatError
from .phase6_asset_residency import verify_phase6_asset_residency
from .phase6_creative_compiler import planned_voice_speed
from .phase6_media_authority import reconcile_phase6_media_authority, verify_completed_phase6_media_authority
from .phase6_media_remediation_wait import verify_post_effect_visual_wait
from .phase6_current_production_inputs import verify_current_production_inputs
from .phase6_release import PRODUCTION_INPUT_RECEIPTS, PRODUCTION_ARTIFACT_ARCHIVES
from .queue_phase6 import LeaseConflict, QueueConflict, TransactionalQueue
from .render_creative_v2_phase5 import (
    FFMPEG, FFPROBE, OUTPUT_FPS, _build_sfx, _concat_file, _font,
    _fps, _frames, _probe as _legacy_probe, _run as _legacy_run, _text_filter,
)
from .phase6_visual_recipe import visual_filters as _visual_filters
from .render_creative_v3_phase5 import _build_captions, _build_original_music
from .voice_phase5 import (
    build_local_voice,
    espeak_binding_identity,
    revalidate_local_espeak_binding,
    synthesize_voice_sample,
)


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
VIDEO_ID = "phase6-video-002-prepublication"
BASE = Path("output/production/phase6/video-002")
RUNTIME = Path("output/operations/phase6/media-executor-status.json")
SEGMENT_RECEIPTS = BASE / "render-work/video-segment-receipts"
SEGMENT_RECIPE_ANCHORS = SEGMENT_RECEIPTS / "by-recipe"
CURRENT_SEGMENT_WORKSET = "current-v1"
SEGMENT_SETS = BASE / "render-work/video-segment-sets"
SEGMENT_CACHE_EVENTS = BASE / "render-work/segment-cache-events"
SEGMENT_CACHE_RECOVERY_VERSION = "phase6-segment-exact-cache-recovery-v1"


def _segment_anchor_dir(root: Path, output: Path, fingerprint: str) -> Path:
    """Resolve the immutable anchor namespace from the output workset.

    The path is part of the forward-only binding: a current segment can never
    accidentally consult the legacy recipe pointer merely because its recipe
    fingerprint is the same.
    """
    current = root / BASE / "render-work" / f"video-segments-{CURRENT_SEGMENT_WORKSET}"
    relative = output.resolve().relative_to(root.resolve())
    if relative.is_relative_to(current.relative_to(root)):
        if output.parent.resolve() != (current / fingerprint).resolve():
            raise PermissionError("current segment workset does not match its exact recipe")
        return root / SEGMENT_RECIPE_ANCHORS / CURRENT_SEGMENT_WORKSET
    return root / SEGMENT_RECIPE_ANCHORS


VOICE_TIMING_CONTRACT_VERSION = "phase6-pinned-voice-slot-v2"

_RESOURCE_SCOPE: ContextVar[Phase6ResourcePreparation | None] = ContextVar("phase6_media_resources", default=None)


def _resource_scoped(function):
    @wraps(function)
    def wrapped(root: Path = ROOT, *args, **kwargs):
        # This gate is deliberately inside the actual media entry, not just its
        # caller. It never removes PAUSE. ContextVar restoration is exception-safe.
        resources = Phase6ResourcePreparation(root)
        with resources:
            token = _RESOURCE_SCOPE.set(resources)
            try:
                return function(root, *args, **kwargs)
            finally:
                _RESOURCE_SCOPE.reset(token)
                if resources.observations:
                    _write_immutable(
                        root / BASE / "resource-preparation" / f"{uuid.uuid4().hex}.json",
                        {"version": "phase6-active-resources-v1", "entry": function.__name__,
                         "observations": resources.observations, "quality_approval": False},
                    )
    return wrapped


def _resource_call(stage: str, function, *args, **kwargs):
    resources = _RESOURCE_SCOPE.get()
    if resources is None:
        raise RuntimeError("heavy media task lacks resource scope")
    with resources.task(stage):
        return function(*args, **kwargs)


def _run(command, *, witness_output=None, witness_inputs=()):
    resources = _RESOURCE_SCOPE.get()
    if resources is None:
        if witness_output is not None:
            raise RuntimeError("execution witness requires the actual live resource scope")
        return _legacy_run(command)
    return resources.run_ffmpeg(command, witness_output=witness_output, witness_inputs=witness_inputs)


def _probe(path):
    resources = _RESOURCE_SCOPE.get()
    if resources is None:
        return _legacy_probe(path)
    return _resource_call("ffprobe", _legacy_probe, path)


class VoiceSlotPreflightError(RuntimeError):
    """The pinned voice cannot deliver exact approved copy inside its slot."""

    def __init__(self, take_id: str, *, duration_ms: int, slot_ms: int, speed: float) -> None:
        self.take_id = take_id
        self.duration_ms = duration_ms
        self.slot_ms = slot_ms
        self.speed = speed
        super().__init__(
            f"voice slot preflight failed: {take_id}:duration={duration_ms}:"
            f"slot={slot_ms}:speed={speed:.3f}"
        )


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write_immutable(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").replace("\n", os.linesep).encode("utf-8")
    if path.is_file():
        if path.read_bytes() != encoded:
            raise PermissionError(f"immutable media receipt collision: {path.name}")
        return _read(path)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(encoded)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != encoded:
                raise PermissionError(f"immutable media receipt collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)
    return _read(path)


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _commit_content_addressed_audio(staged: Path, destination: Path, expected_hash: str) -> Path:
    """Publish one verified WAV without overwriting another content identity."""

    if _sha(staged) != expected_hash:
        raise PermissionError("voice synthesizer hash diverges from staged WAV bytes")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file():
        if _sha(destination) != expected_hash:
            raise PermissionError(f"content-addressed voice collision: {destination.name}")
        return destination
    try:
        os.link(staged, destination)
    except FileExistsError:
        if _sha(destination) != expected_hash:
            raise PermissionError(f"content-addressed voice collision: {destination.name}")
    if _sha(destination) != expected_hash:
        raise PermissionError(f"committed voice hash mismatch: {destination.name}")
    return destination


def _inspect_voice_wav(path: Path) -> dict[str, Any]:
    """Measure the committed PCM stream, independently from the synthesizer."""

    try:
        with sf.SoundFile(path, mode="r") as stream:
            evidence = {
                "format": str(stream.format),
                "subtype": str(stream.subtype),
                "sample_rate": int(stream.samplerate),
                "channels": int(stream.channels),
                "frame_count": int(stream.frames),
            }
            peak_integer = 0
            while True:
                block = stream.read(65_536, dtype="int16", always_2d=True)
                if not len(block):
                    break
                peak_integer = max(
                    peak_integer,
                    int(np.max(np.abs(block.astype(np.int32)))),
                )
    except Exception as exc:
        raise PermissionError(f"voice WAV is not independently decodable: {path.name}") from exc
    if (
        evidence["format"] != "WAV"
        or evidence["subtype"] != "PCM_16"
        or evidence["sample_rate"] != 24_000
        or evidence["channels"] != 1
        or evidence["frame_count"] <= 0
    ):
        raise PermissionError(
            "voice WAV must be non-empty mono WAV/PCM_16 at 24000 Hz: "
            f"{path.name}:{evidence}"
        )
    evidence.update({
        "duration_ms": round(evidence["frame_count"] * 1000 / evidence["sample_rate"]),
        "peak_linear": round(peak_integer / 32768.0, 6),
        # A saturated PCM-16 endpoint is rejected even when a producer claims
        # clipping=False.  The raw producer flag is checked separately.
        "clipping": peak_integer >= 32767,
    })
    return evidence


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _post_application_wait(root: Path, prior: dict[str, Any], *, timestamp: str) -> dict[str, Any] | None:
    """Hold zero-effect owner-pause recovery until D116 binds this live manager/cycle."""

    expected = {
        "schema_version": "1.1.0", "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6, "status": "WAITING", "input_receipt_id": None, "action": "WAIT",
        "job_id": None, "job_state": "NOT_CREATED", "voice_manifest": None,
        "render_manifest": None, "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None, "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None, "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None, "error": None, "publication_authorized": False,
        "technical_cost_brl": 0,
    }
    reason = (
        "OWNER_PAUSE_RELEASE_REQUIRED: no media command, voice, render, or "
        "publication effect occurred; resume only through the verified control cycle."
    )
    legacy_wait = (all(prior.get(key) == value for key, value in expected.items())
                   and prior.get("next_action") == reason)
    retry_hold = prior.get("next_action", "").startswith(
        "OWNER_PAUSE_RELEASE_REQUIRED: PermissionError: segment cache recovery blocked before render:")
    reserve_hold = prior.get("next_action", "").startswith(
        "OWNER_PAUSE_RELEASE_REQUIRED: ResourceWait: RESOURCE_WAIT: OUTPUT_DISK_RESERVE, TEMP_DISK_RESERVE")
    if retry_hold:
        from .maintenance_protocol import _cache_rejection_media_wait_candidate
        held, _ = _cache_rejection_media_wait_candidate(
            root, current=prior, source_path=root / RUNTIME,
            observed=datetime.fromisoformat(timestamp.replace("Z", "+00:00")))
        if held is None:
            raise PermissionError("cache-rejection hold contract differs")
    elif reserve_hold:
        from .maintenance_protocol import _resource_reserve_media_wait_candidate
        held, _ = _resource_reserve_media_wait_candidate(
            root, current=prior, source_path=root / RUNTIME,
            observed=datetime.fromisoformat(timestamp.replace("Z", "+00:00")))
        if held is None:
            raise PermissionError("resource-reserve hold contract differs")
    elif not legacy_wait:
        forward_reason = (
            "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
            "resume only through the verified control cycle."
        )
        if prior.get("next_action") != forward_reason:
            return None
        # Reuse the producer's exact schema/shape/current-byte checks. Its 1.2
        # successor has an input ID and an action but grants no media effects.
        # An incompatible or adulterated hold must not fall through to queue.
        from .maintenance_protocol import _exact_owner_pause_media_wait_candidate
        held, _ = _exact_owner_pause_media_wait_candidate(
            root, current=prior, source_path=root / RUNTIME,
            observed=datetime.fromisoformat(timestamp.replace("Z", "+00:00")),
        )
        if held is None:
            raise PermissionError("forward owner-pause hold contract differs")
    try:
        d116 = _read(root / "output/operations/phase6/post-maintenance-verification/latest.json")
        cycle = _read(root / "output/operations/phase6/control-cycle/latest.json")
        released = (
            d116.get("status") == "PASS"
            and (d116.get("runtime") or {}).get("manager_pid") == os.getpid()
            and (d116.get("control_cycle") or {}).get("cycle_id") == cycle.get("cycle_id")
            and datetime.fromisoformat(str(d116["verified_at"]).replace("Z", "+00:00"))
            > datetime.fromisoformat(str(prior["updated_at"]).replace("Z", "+00:00"))
        )
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        released = False
    if released:
        return None
    return {**prior, "updated_at": timestamp}


def _job_is_due(job: dict[str, Any], current: datetime) -> bool:
    if job.get("state") not in {"PENDING", "RETRY_WAIT"}:
        return False
    available = datetime.fromisoformat(str(job["available_at"]).replace("Z", "+00:00"))
    return available.astimezone(timezone.utc) <= current.astimezone(timezone.utc)


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(
        _read(root / "schemas" / schema_name), format_checker=FormatChecker()
    ).validate(value)


def _verified_inputs(root: Path) -> tuple[dict[str, Any] | None, str | None]:
    receipt_path = root / "output/operations/phase6/release/latest-production-inputs-receipt.json"
    if not receipt_path.is_file():
        return None, "Production inputs do not exist yet."
    try:
        receipt = _read(receipt_path)
        _validate(root, "phase6_production_inputs_receipt.schema.json", receipt)
        if receipt.get("action") != "PREPARE_VIDEO_2_INPUTS" or receipt.get("next_action") != "SYNTHESIZE_VIDEO_2_VOICE":
            return None, "The current production-input receipt belongs to a different branch."
        receipt = verify_current_production_inputs(
            root,
            expected_receipt_id=receipt["receipt_id"],
        )
        return receipt, None
    except Exception as exc:
        raise PermissionError(f"invalid production-input receipt: {type(exc).__name__}:{exc}") from exc


def _reverify_same_inputs(root: Path, expected_receipt_id: str, *, recheck_decode: bool) -> dict[str, Any]:
    receipt, reason = _verified_inputs(root)
    if receipt is None:
        raise PermissionError(reason or "production inputs are unavailable")
    if receipt.get("receipt_id") != expected_receipt_id:
        raise PermissionError("production inputs changed while media work was in progress")
    return verify_current_production_inputs(
        root,
        expected_receipt_id=expected_receipt_id,
        recheck_decode=recheck_decode,
    )


def _voice_source_bindings(
    root: Path, plan: dict[str, Any], script: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    plan_path = root / BASE / "production/take_plan.json"
    script_path = root / BASE / "preproduction/narrative_script.json"
    take_plan = {
        "take_plan_id": plan["take_plan_id"],
        "path": _relative(root, plan_path),
        "sha256": _sha(plan_path),
    }
    narrative_script = {
        "script_id": script["script_id"],
        "path": _relative(root, script_path),
        "sha256": _sha(script_path),
    }
    rows = [
        {
            "ordinal": index + 1,
            "take_id": take["take_id"],
            "text": str(take.get("narration") or "").strip(),
            "start_ms": int(take["start_ms"]),
            "end_ms": int(take["end_ms"]),
            "timeline_slot_ms": int(take["end_ms"]) - int(take["start_ms"]),
            "speed": planned_voice_speed(index),
        }
        for index, take in enumerate(plan["takes"])
    ]
    canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    timing = {
        "version": VOICE_TIMING_CONTRACT_VERSION,
        "take_count": len(rows),
        "content_hash": "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
    }
    return take_plan, narrative_script, timing


def _voice_manifest_identity(value: dict[str, Any]) -> tuple[str, str]:
    """Bind every semantic and technical input that makes a voice set reusable.

    Wall-clock and benchmark fields are intentionally excluded; the exact
    TakePlan/script bytes, ordered copy/slots/speeds, pinned runtime, voice,
    hook result and rendered audio evidence are all included.
    """

    take_rows = [
        {
            key: record[key]
            for key in (
                "take_id", "text", "speed", "duration_ms", "timeline_slot_ms",
                "fits_timeline_slot", "peak_linear", "clipping", "frame_count",
                "sample_rate", "channels", "wav_subtype", "path", "content_hash",
            )
        }
        for record in value.get("takes") or []
    ]
    payload = {
        "contract": VOICE_TIMING_CONTRACT_VERSION,
        "video_id": value.get("video_id"),
        "script_id": value.get("script_id"),
        "script_version": value.get("script_version"),
        "take_plan": value.get("take_plan"),
        "narrative_script": value.get("narrative_script"),
        "timing_contract": value.get("timing_contract"),
        "adapter_id": value.get("adapter_id"),
        "adapter_implementation": value.get("adapter_implementation"),
        "model": value.get("model"),
        "model_hash": value.get("model_hash"),
        "voices_hash": value.get("voices_hash"),
        "espeak_binding": value.get("espeak_binding"),
        "capacity_preflight": value.get("capacity_preflight"),
        "voice_id": value.get("voice_id"),
        "sample_rate": value.get("sample_rate"),
        "take_count": value.get("take_count"),
        "takes": take_rows,
        "hook_timing_gate": value.get("hook_timing_gate"),
        "total_audio_duration_ms": value.get("total_audio_duration_ms"),
        "timeline_duration_ms": value.get("timeline_duration_ms"),
    }
    if value.get("schema_version") == "1.3.0":
        payload["codec_only_reuse"] = value.get("codec_only_reuse")
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    identity_hash = "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return identity_hash, "voice-phase6-" + identity_hash.removeprefix("sha256:")[:20]


def _verify_voice_manifest_contract(
    root: Path,
    value: dict[str, Any],
    *,
    expected_capacity_reference: dict[str, Any] | None = None,
    expected_espeak: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Recompute every reusable voice input instead of trusting its labels."""

    _validate(root, "voice_render_manifest.schema.json", value)
    if value.get("schema_version") not in ("1.2.0", "1.3.0"):
        raise PermissionError("legacy voice manifests cannot satisfy the pinned slot contract")
    plan = _read(root / BASE / "production/take_plan.json")
    script = _read(root / BASE / "preproduction/narrative_script.json")
    take_plan, narrative_script, timing = _voice_source_bindings(root, plan, script)
    if (
        value.get("status") != "COMPLETE"
        or value.get("video_id") != VIDEO_ID
        or value.get("take_plan") != take_plan
        or value.get("narrative_script") != narrative_script
        or value.get("timing_contract") != timing
        or value.get("script_id") != script["script_id"]
        or value.get("script_version") != script["version"]
        or value.get("take_count") != len(plan["takes"])
        or value.get("voice_id") != "am_onyx"
        or value.get("adapter_implementation") != "KokoroFloatSpeed"
        or value.get("model") != "models/kokoro/kokoro-v1.0.fp16.onnx"
        or value.get("model_hash") != _sha(root / "models/kokoro/kokoro-v1.0.fp16.onnx")
        or value.get("voices_hash") != _sha(root / "models/kokoro/voices-v1.0.bin")
        or value.get("hook_timing_gate") != "PASS"
        or value.get("sample_rate") != 24_000
        or value.get("publication_approved") is not False
    ):
        raise PermissionError("voice manifest diverges from current plan/script/model/voice identity")
    if expected_capacity_reference is not None and value.get("capacity_preflight") != expected_capacity_reference:
        raise PermissionError("voice manifest diverges from its exact capacity receipt")
    if expected_espeak is not None and value.get("espeak_binding") != expected_espeak:
        raise PermissionError("voice manifest diverges from its exact eSpeak binding")
    records = value.get("takes") or []
    if len(records) != len(plan["takes"]):
        raise PermissionError("voice manifest take count diverges from TakePlan")
    for index, (take, record) in enumerate(zip(plan["takes"], records)):
        text = str(take.get("narration") or "").strip()
        slot = int(take["end_ms"]) - int(take["start_ms"])
        if (
            record.get("take_id") != take["take_id"]
            or record.get("text") != text
            or float(record.get("speed", -1)) != planned_voice_speed(index)
            or int(record.get("timeline_slot_ms", -1)) != slot
            or int(record.get("duration_ms", slot + 1)) > slot
            or record.get("fits_timeline_slot") is not True
            or record.get("clipping") is not False
        ):
            raise PermissionError(f"voice manifest timing/copy/order mismatch: {take['take_id']}")
        wav_path = _resolve(root, str(record.get("path") or ""))
        _assert_hash(wav_path, str(record.get("content_hash") or ""), f"voice take {take['take_id']}")
        wav = _inspect_voice_wav(wav_path)
        if (
            int(record.get("duration_ms", -1)) != wav["duration_ms"]
            or int(record.get("frame_count", -1)) != wav["frame_count"]
            or int(record.get("sample_rate", -1)) != wav["sample_rate"]
            or int(record.get("channels", -1)) != wav["channels"]
            or record.get("wav_subtype") != wav["subtype"]
            or float(record.get("peak_linear", -1)) != wav["peak_linear"]
            or wav["clipping"] is True
        ):
            raise PermissionError(f"voice manifest diverges from measured WAV evidence: {take['take_id']}")
    if (
        int(value.get("total_audio_duration_ms", -1))
        != sum(int(record["duration_ms"]) for record in records)
        or float(value.get("total_render_seconds", -1))
        != round(sum(float(record["render_seconds"]) for record in records), 6)
        or int(value.get("timeline_duration_ms", -1)) != int(plan["takes"][-1]["end_ms"])
        or not all(record.get("fits_timeline_slot") is True for record in records[:3])
    ):
        raise PermissionError("voice manifest COMPLETE totals/timeline/hook evidence diverge")
    identity_hash, voice_render_id = _voice_manifest_identity(value)
    if value.get("identity_hash") != identity_hash or value.get("voice_render_id") != voice_render_id:
        raise PermissionError("voice manifest identity does not bind its complete reusable proof")
    if value["schema_version"] == "1.3.0":
        _verify_codec_only_voice_reuse(root, value, plan)
    return value


def _read_bound_voice_file(path: Path, expected: str, label: str) -> dict[str, Any]:
    raw = path.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected:
        raise PermissionError(f"{label} hash mismatch")
    return json.loads(raw.decode("utf-8-sig"))


def _verify_codec_only_voice_reuse(root: Path, value: dict[str, Any], plan: dict[str, Any]) -> None:
    """Authenticate the old immutable voice and archived plan, never a PASS flag.

    Current copy, slots, model, runtime and each PCM are remeasured by the normal
    verifier above. This additional proof limits the transition to the visual
    codec only; it cannot transfer old QA, render or publication authority.
    """
    evidence = value["codec_only_reuse"]
    parent_binding, plan_binding = evidence["parent_voice"], evidence["archived_take_plan"]
    parent_path = _segment_resident_path(root, _resolve(root, parent_binding["path"]))
    if parent_path != (root / BASE / "audio/manifests" / f"{parent_binding['voice_render_id']}.json").resolve():
        raise PermissionError("codec voice parent must be its immutable manifest")
    parent = _read_bound_voice_file(parent_path, parent_binding["sha256"], "codec voice parent")
    _validate(root, "voice_render_manifest.schema.json", parent)
    identity, identifier = _voice_manifest_identity(parent)
    if (parent["schema_version"] != "1.2.0" or parent["identity_hash"] != identity
            or parent["voice_render_id"] != identifier or identifier != parent_binding["voice_render_id"]):
        raise PermissionError("codec voice parent identity diverged")
    archived_path = _segment_resident_path(root, _resolve(root, plan_binding["path"]))
    archive_root = (root / PRODUCTION_ARTIFACT_ARCHIVES).resolve()
    if archived_path.parent.parent != archive_root or archived_path.name != "take_plan.json":
        raise PermissionError("codec voice plan must be in the production artifact archive")
    archived = _read_bound_voice_file(archived_path, parent["take_plan"]["sha256"], "codec voice archived TakePlan")
    if plan_binding["sha256"] != parent["take_plan"]["sha256"]:
        raise PermissionError("codec voice archive hash diverges from parent")
    if archived.get("take_plan_id") != parent["take_plan"]["take_plan_id"]:
        raise PermissionError("codec voice archive plan identity diverged")
    if plan_renderer(archived) != PHASE6_SEGMENT_RENDERER or plan_renderer(plan) != PALETTE_QP1_SEGMENT_RENDERER:
        raise PermissionError("codec voice reuse only supports the explicit v2 to palette transition")
    # All other plan fields (including every take, source, text and timestamp)
    # must remain exact. Only creation time/ID and the explicit codec may differ.
    excluded = {"take_plan_id", "created_at", "render_profile"}
    if ({k: v for k, v in archived.items() if k not in excluded}
            != {k: v for k, v in plan.items() if k not in excluded}):
        raise PermissionError("codec-only transition changed non-codec TakePlan content")
    allowed = {"schema_version", "voice_render_id", "identity_hash", "take_plan",
               "capacity_preflight", "created_at", "codec_only_reuse"}
    if ({k: v for k, v in parent.items() if k not in allowed}
            != {k: v for k, v in value.items() if k not in allowed}):
        raise PermissionError("codec voice successor changed original measured audio evidence")
    if datetime.fromisoformat(value["created_at"].replace("Z", "+00:00")) < datetime.fromisoformat(parent["created_at"].replace("Z", "+00:00")):
        raise PermissionError("codec voice successor predates its parent")
    # Hold the bytes used by the transition through its final validation.
    _assert_hash(parent_path, parent_binding["sha256"], "codec voice parent final")
    _assert_hash(archived_path, plan_binding["sha256"], "codec voice archive final")


def _reuse_codec_only_voice(root: Path, prior: dict[str, Any], *, timestamp: str,
                           capacity_reference: dict[str, Any], expected_espeak: dict[str, Any]) -> dict[str, Any]:
    """A forward receipt for already measured PCM; never invokes synthesis."""
    if prior.get("schema_version") != "1.2.0":
        raise PermissionError("codec voice reuse needs an exact schema-1.2 immutable parent")
    parent_path = root / BASE / "audio/manifests" / f"{prior['voice_render_id']}.json"
    alias = root / BASE / "audio/voice_render_manifest.json"
    if not parent_path.is_file() or parent_path.read_bytes() != alias.read_bytes():
        raise PermissionError("codec voice alias is not its immutable parent")
    parent_hash = _sha(parent_path)
    plan_path = root / BASE / "production/take_plan.json"
    plan = _read(plan_path)
    script = _read(root / BASE / "preproduction/narrative_script.json")
    plan_binding, _, _ = _voice_source_bindings(root, plan, script)
    # Discovery is confined to the existing immutable archive. The parent hash
    # is the expected value; discovered bytes never become their own authority.
    matches = []
    for path in sorted((root / PRODUCTION_ARTIFACT_ARCHIVES).glob("*/take_plan.json")):
        path = _segment_resident_path(root, path)
        if _sha(path) == prior["take_plan"]["sha256"]:
            matches.append(path)
    if not matches:
        raise PermissionError("codec voice reuse lacks the exact archived TakePlan")
    value = deepcopy(prior)
    value.update(schema_version="1.3.0", take_plan=plan_binding,
                 capacity_preflight=capacity_reference, created_at=timestamp,
                 codec_only_reuse={
                     "version": "phase6-codec-only-voice-reuse-v1",
                     "parent_voice": {"path": _relative(root, parent_path),
                                      "sha256": parent_hash, "voice_render_id": prior["voice_render_id"]},
                     "archived_take_plan": {"path": _relative(root, matches[0]),
                                            "sha256": prior["take_plan"]["sha256"]},
                     "synthesis_performed": False,
                 })
    value["identity_hash"], value["voice_render_id"] = _voice_manifest_identity(value)
    _verify_voice_manifest_contract(root, value, expected_capacity_reference=capacity_reference,
                                    expected_espeak=expected_espeak)
    # Recheck the mutable alias too: no overwriting a different intervening voice.
    _assert_hash(alias, parent_hash, "codec voice alias before commit")
    value = _write_immutable(root / BASE / "audio/manifests" / f"{value['voice_render_id']}.json", value)
    _verify_voice_manifest_contract(root, value, expected_capacity_reference=capacity_reference,
                                    expected_espeak=expected_espeak)
    _assert_hash(alias, parent_hash, "codec voice alias final")
    _write(alias, value)
    return value


def _verify_bound_assets(root: Path, receipt: dict[str, Any], *, recheck_decode: bool) -> dict[str, Any]:
    binding = receipt.get("asset_residency")
    if not isinstance(binding, dict):
        raise PermissionError("production inputs lack an immutable asset-residency binding")
    allocation = _read(root / BASE / "production/asset_allocation.json")
    asset_ids = [item["asset_id"] for item in allocation.get("takes") or []]
    return verify_phase6_asset_residency(
        root,
        receipt_path=binding.get("receipt_path"),
        expected_sha256=binding.get("sha256"),
        expected_audit_id=binding.get("audit_id"),
        required_asset_ids=asset_ids,
        recheck_media=True,
        recheck_decode=recheck_decode,
    )


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    resolved = (path if path.is_absolute() else root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"media path escaped the project root: {value}") from exc
    return resolved


def _verify_completed_media_checkpoint(root: Path, checkpoint: dict[str, Any], receipt: dict[str, Any]) -> dict[str, Any]:
    visual_binding = checkpoint.get("visual_preflight")
    if not isinstance(visual_binding, dict):
        raise PermissionError("completed media checkpoint lacks the pre-effect visual contract binding")
    immutable_input = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt['receipt_id']}.json"
    if (
        checkpoint.get("input_receipt_id") != receipt["receipt_id"]
        or checkpoint.get("input_receipt_path") != _relative(root, immutable_input)
        or checkpoint.get("input_receipt_sha256") != _sha(immutable_input)
    ):
        raise PermissionError("completed media checkpoint lacks the exact immutable input receipt")
    verify_completed_visual_preflight(root, visual_binding)
    capacity_path = _resolve(root, str(checkpoint.get("capacity_receipt_path") or ""))
    capacity_hash = str(checkpoint.get("capacity_receipt_sha256") or "")
    capacity = verify_phase6_capacity_receipt(
        root,
        receipt_path=capacity_path,
        expected_receipt_id=str(checkpoint.get("capacity_receipt_id") or ""),
        expected_sha256=capacity_hash,
        require_pass=True,
    )
    if capacity.get("schema_version") != "1.1.0" or (capacity.get("espeak") or {}).get("status") != "PASS":
        raise PermissionError("completed media checkpoint uses a legacy or failed eSpeak capacity receipt")
    capacity_reference = {
        "receipt_id": capacity["receipt_id"],
        "receipt_path": _relative(root, capacity_path),
        "sha256": capacity_hash,
    }
    expected_espeak = espeak_binding_identity(capacity["espeak"])
    for kind, schema_name, directory, id_key in (
        ("voice", "voice_render_manifest.schema.json", root / BASE / "audio/manifests", "voice_render_id"),
        ("render", "render_manifest.schema.json", root / BASE / "renders/manifests", "render_id"),
    ):
        path = _resolve(root, str(checkpoint.get(f"{kind}_manifest") or ""))
        if not path.is_file() or path.parent.resolve() != directory.resolve():
            raise PermissionError(f"completed media checkpoint has no immutable {kind} manifest")
        value = _read(path)
        _validate(root, schema_name, value)
        if path.name != f"{value[id_key]}.json" or checkpoint.get(id_key) != value[id_key]:
            raise PermissionError(f"completed media checkpoint {kind} identity mismatch")
        if checkpoint.get(f"{kind}_manifest_sha256") != _sha(path):
            raise PermissionError(f"completed media checkpoint {kind} hash mismatch")
        if kind == "voice":
            _verify_voice_manifest_contract(
                root,
                value,
                expected_capacity_reference=capacity_reference,
                expected_espeak=expected_espeak,
            )
        else:
            video = _resolve(root, value["output"]["path"])
            _assert_hash(video, value["output"]["content_hash"], "frozen render")
            verify_phase6_segment_set(
                root, value.get("segment_receipt_set") or {},
                expected_input_receipt_id=receipt["receipt_id"],
                expected_renderer=plan_renderer(_read(root / BASE / "production/take_plan.json")),
            )
    return capacity


@_resource_scoped
def synthesize_video2_voice(
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    capacity_receipt_path: str | Path | None = None,
    expected_capacity_receipt_id: str | None = None,
    expected_capacity_receipt_sha256: str | None = None,
    voice_builder: Callable[..., Any] | None = None,
    sample_synthesizer: Callable[..., dict[str, Any]] | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    timestamp = created_at or _stamp()
    if capacity_receipt_path is None or not expected_capacity_receipt_id or not expected_capacity_receipt_sha256:
        raise PermissionError("Phase 6 voice synthesis requires an exact immutable capacity receipt binding")
    capacity = verify_phase6_capacity_receipt(
        root,
        receipt_path=capacity_receipt_path,
        expected_receipt_id=expected_capacity_receipt_id,
        expected_sha256=expected_capacity_receipt_sha256,
        require_pass=True,
    )
    if capacity.get("schema_version") != "1.1.0" or (capacity.get("espeak") or {}).get("status") != "PASS":
        raise PermissionError("Phase 6 voice synthesis requires a current PASS eSpeak capacity binding")
    capacity_path = Path(capacity_receipt_path)
    if not capacity_path.is_absolute():
        capacity_path = root / capacity_path
    capacity_path = capacity_path.resolve()
    capacity_reference = {
        "receipt_id": capacity["receipt_id"],
        "receipt_path": _relative(root, capacity_path),
        "sha256": expected_capacity_receipt_sha256,
    }
    expected_espeak = espeak_binding_identity(capacity["espeak"])
    production = root / BASE / "production"
    preproduction = root / BASE / "preproduction"
    plan = _read(production / "take_plan.json")
    script = _read(preproduction / "narrative_script.json")
    take_plan_binding, script_binding, timing_contract = _voice_source_bindings(
        root, plan, script,
    )
    prior_path = root / BASE / "audio/voice_render_manifest.json"
    if prior_path.is_file():
        prior = _read(prior_path)
        try:
            prior = _verify_voice_manifest_contract(
                root,
                prior,
                expected_capacity_reference=capacity_reference,
                expected_espeak=expected_espeak,
            )
            immutable = root / BASE / "audio/manifests" / f"{prior['voice_render_id']}.json"
            prior = _write_immutable(immutable, prior)
            _write(prior_path, prior)
            return prior
        except Exception:
            if plan_renderer(plan) == PALETTE_QP1_SEGMENT_RENDERER:
                # Invalid provenance is a hard failure, not silent synthesis.
                return _reuse_codec_only_voice(
                    root, prior, timestamp=timestamp,
                    capacity_reference=capacity_reference, expected_espeak=expected_espeak,
                )
    builder = voice_builder or build_local_voice
    synthesizer = sample_synthesizer or synthesize_voice_sample
    engine = _resource_call("voice:model", builder, root, expected_binding=capacity["espeak"])
    binding = getattr(engine, "_heroverse_espeak_binding", None)
    if binding is None:
        raise PermissionError("local voice engine omitted its eSpeak runtime binding")
    runtime_espeak = revalidate_local_espeak_binding(binding, expected_binding=capacity["espeak"])
    if runtime_espeak != expected_espeak:
        raise PermissionError("runtime eSpeak binding diverges before voice synthesis")
    audio_root = root / BASE / "audio"
    staging_parent = audio_root / ".voice-staging"
    staging_parent.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    # All utterances are measured against the exact pinned model before a
    # single take becomes consumable.  A failure removes the staging tree and
    # leaves no partially committed voice set.  We deliberately do not speed
    # up an overlong line: copy or slot planning must be corrected upstream.
    with tempfile.TemporaryDirectory(prefix="phase6-voice-", dir=staging_parent) as folder:
        staged_records: list[dict[str, Any]] = []
        staging = Path(folder)
        for index, take in enumerate(plan["takes"]):
            text = str(take.get("narration") or "").strip()
            if not text:
                raise ValueError(f"{take['take_id']} has no narration")
            slot = int(take["end_ms"]) - int(take["start_ms"])
            speed = planned_voice_speed(index)
            staged = staging / f"{take['take_id']}.wav"
            rendered = _resource_call("voice:take", synthesizer,
                engine, text=text, output_path=staged, voice_id="am_onyx", speed=speed,
            )
            wav = _inspect_voice_wav(staged)
            rendered_duration = int(wav["duration_ms"])
            if int(rendered.get("duration_ms", -1)) != rendered_duration:
                raise PermissionError(f"voice producer duration diverges from WAV frames: {take['take_id']}")
            if rendered_duration > slot:
                raise VoiceSlotPreflightError(
                    str(take["take_id"]), duration_ms=rendered_duration,
                    slot_ms=slot, speed=speed,
                )
            if rendered["clipping"] or wav["clipping"]:
                raise RuntimeError(f"raw voice clipping: {take['take_id']}")
            content_hash = str(rendered["content_hash"])
            if _sha(staged) != content_hash:
                raise PermissionError(f"voice synthesizer hash mismatch: {take['take_id']}")
            staged_records.append({
                "take_id": take["take_id"], "text": text, "speed": speed,
                "duration_ms": rendered_duration, "timeline_slot_ms": slot,
                "fits_timeline_slot": True, "peak_linear": wav["peak_linear"],
                "clipping": False, "render_seconds": rendered["render_seconds"],
                "frame_count": wav["frame_count"], "sample_rate": wav["sample_rate"],
                "channels": wav["channels"], "wav_subtype": wav["subtype"],
                "_staged_path": staged, "content_hash": content_hash,
            })
        runtime_espeak = revalidate_local_espeak_binding(binding, expected_binding=capacity["espeak"])
        if runtime_espeak != expected_espeak:
            raise PermissionError("runtime eSpeak binding diverges after voice-slot preflight")
        immutable_take_dir = audio_root / "takes" / str(script["script_id"])
        for staged_record in staged_records:
            content_hash = str(staged_record["content_hash"])
            staged = Path(staged_record.pop("_staged_path"))
            output = immutable_take_dir / (
                f"{staged_record['take_id']}-{content_hash.removeprefix('sha256:')[:16]}.wav"
            )
            _commit_content_addressed_audio(staged, output, content_hash)
            staged_record["path"] = str(output.resolve())
            records.append(staged_record)
    manifest = {
        "schema_version": "1.2.0",
        "status": "COMPLETE", "video_id": VIDEO_ID, "script_id": script["script_id"],
        "script_version": script["version"], "adapter_id": "adapter-local-voice",
        "adapter_implementation": "KokoroFloatSpeed", "model": "models/kokoro/kokoro-v1.0.fp16.onnx",
        "model_hash": _sha(root / "models/kokoro/kokoro-v1.0.fp16.onnx"),
        "voices_hash": _sha(root / "models/kokoro/voices-v1.0.bin"),
        "espeak_binding": runtime_espeak, "capacity_preflight": capacity_reference,
        "take_plan": take_plan_binding, "narrative_script": script_binding,
        "timing_contract": timing_contract, "voice_id": "am_onyx",
        "sample_rate": 24000, "take_count": len(records), "takes": records,
        "hook_timing_gate": "PASS" if all(item["fits_timeline_slot"] for item in records[:3]) else "FAIL",
        "total_audio_duration_ms": sum(item["duration_ms"] for item in records),
        "total_render_seconds": round(sum(item["render_seconds"] for item in records), 6),
        "timeline_duration_ms": int(plan["takes"][-1]["end_ms"]), "publication_approved": False,
        "limitations": [
            "Final intelligibility is evaluated independently from the mixed render by local ASR.",
            "This voice receipt never authorizes publication.",
        ],
        "created_at": timestamp,
    }
    identity_hash, voice_render_id = _voice_manifest_identity(manifest)
    manifest["identity_hash"] = identity_hash
    manifest["voice_render_id"] = voice_render_id
    _validate(root, "voice_render_manifest.schema.json", manifest)
    _verify_voice_manifest_contract(
        root,
        manifest,
        expected_capacity_reference=capacity_reference,
        expected_espeak=expected_espeak,
    )
    manifest = _write_immutable(
        root / BASE / "audio/manifests" / f"{manifest['voice_render_id']}.json",
        manifest,
    )
    _write(prior_path, manifest)
    return manifest


def _origin(root: Path, value: str) -> tuple[Path, float, float]:
    path_text, span = value.rsplit("#t=", 1)
    start, end = span.split(",", 1)
    path = _resolve(root, path_text)
    return path, float(start), float(end)


def _fingerprint(path: Path, take: dict[str, Any], treatment: dict[str, Any], *, source_hash: str | None = None, renderer: str = PHASE6_SEGMENT_RENDERER) -> str:
    segment_encoder_arguments(renderer)
    payload = json.dumps({"take": take, "treatment": treatment, "source_hash": source_hash or _sha(path), "renderer": renderer}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()


def _segment_receipt_id(value: dict[str, Any]) -> str:
    content = dict(value)
    content.pop("receipt_id", None)
    content.pop("created_at", None)
    encoded = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "phase6-segment-" + hashlib.sha256(encoded).hexdigest()[:32]


def _segment_resident_path(root: Path, path: Path) -> Path:
    """Check lexical ancestry before resolving; never hydrate or follow a link."""
    root = root.absolute()
    path = (path if path.is_absolute() else root / path).absolute()
    if ".." in path.parts:
        raise PermissionError("segment cache path contains parent traversal")
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise PermissionError("segment cache path escaped project root") from exc
    for part in reversed((path, *path.parents)):
        try:
            metadata = part.lstat()
        except FileNotFoundError:
            continue
        attributes = getattr(metadata, "st_file_attributes", 0)
        if stat.S_ISLNK(metadata.st_mode) or attributes & (0x400 | 0x1000 | 0x40000 | 0x400000):
            raise PermissionError("linked/offline segment cache dependency")
    return path


def _segment_strict_json(path: Path) -> dict[str, Any]:
    if not path.is_file() or not 0 < path.stat().st_size <= 1024 * 1024:
        raise PermissionError("missing, empty or oversized segment cache proof")

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key in segment cache proof")
            result[key] = value
        return result

    def nonfinite(_):
        raise ValueError("nonfinite number in segment cache proof")

    value = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=pairs,
                       parse_constant=nonfinite)
    if not isinstance(value, dict):
        raise ValueError("segment cache proof must be an object")
    return value


def _segment_json_identity(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _inspect_segment_cache_proof(
    output: Path, cache: Path, *, root: Path, take_id: str, fingerprint: str,
    duration_ms: int, source_path: Path, source_hash: str,
    source_start_ms: float, source_end_ms: float, renderer: str = PHASE6_SEGMENT_RENDERER,
) -> dict[str, Any]:
    """Hash-only recovery inspection. It never replaces the existing probe/QA."""
    observed_hashes: dict[Path, str] = {}
    segment_encoder_arguments(renderer)

    def observed_hash(path: Path) -> str:
        # Reuse one measurement within this pass only. A second inspection,
        # post-render verification or concat guard must reopen its own bytes.
        if path not in observed_hashes:
            observed_hashes[path] = _sha(path)
        return observed_hashes[path]

    if not re.fullmatch(r"[0-9a-f]{64}", fingerprint) or not re.fullmatch(r"sha256:[0-9a-f]{64}", source_hash):
        raise ValueError("segment fingerprint/source hash missing or invalid")
    if type(duration_ms) is not int or duration_ms <= 0:
        raise ValueError("exact positive segment duration required")
    for value in (source_start_ms, source_end_ms):
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError("invalid source interval")
    if not 0 <= source_start_ms < source_end_ms or source_end_ms - source_start_ms + 2 < duration_ms:
        raise ValueError("source interval cannot cover segment")
    output, cache, source_path = (_segment_resident_path(root, item) for item in (output, cache, source_path))
    anchors = _segment_anchor_dir(root, output, fingerprint)
    anchor = _segment_resident_path(root, anchors / f"{fingerprint}.json")
    if cache != output.with_suffix(".cache.json"):
        raise PermissionError("cache pointer does not belong to the exact output")
    if not source_path.is_file() or source_path.stat().st_size <= 0 or observed_hash(source_path) != source_hash:
        raise PermissionError("segment cache source bytes changed or disappeared")
    exists = [path.exists() for path in (output, cache, anchor)]
    if not any(exists):
        return {"state": "FRESH_OUTPUT_ABSENT", "receipt": None, "pointer": None,
                "evidence": [{"path": _relative(root, source_path), "sha256": source_hash,
                              "size_bytes": source_path.stat().st_size}]}
    if not output.is_file() or not anchor.is_file():
        raise PermissionError("existing segment evidence is incomplete; refusing replacement render")
    anchor_value = _segment_strict_json(anchor)
    if set(anchor_value) != {"schema_version", "fingerprint", "receipt_id", "receipt_path", "receipt_sha256"}:
        raise PermissionError("segment recipe anchor contract differs")
    receipt_id = anchor_value["receipt_id"]
    if not isinstance(receipt_id, str) or not re.fullmatch(r"phase6-segment-[0-9a-f]{32}", receipt_id):
        raise PermissionError("segment receipt identity invalid")
    receipt_path = _segment_resident_path(root, Path(str(anchor_value["receipt_path"])))
    expected_receipt = root.absolute() / SEGMENT_RECEIPTS / f"{receipt_id}.json"
    if receipt_path != expected_receipt:
        raise PermissionError("segment recipe anchor points outside its exact receipt")
    receipt = _segment_strict_json(receipt_path)
    _validate(root, "phase6_segment_receipt.schema.json", receipt)
    if receipt_id != _segment_receipt_id(receipt):
        raise PermissionError("segment receipt identity does not recompose")
    expected_anchor = {"schema_version": "1.0.0", "fingerprint": fingerprint,
                       "receipt_id": receipt_id, "receipt_path": _relative(root, receipt_path),
                       "receipt_sha256": observed_hash(receipt_path)}
    if _segment_json_identity(anchor_value) != _segment_json_identity(expected_anchor):
        raise PermissionError("segment recipe anchor binding differs")
    expected_source = {"path": _relative(root, source_path), "sha256": source_hash,
                       "start_ms": source_start_ms, "end_ms": source_end_ms}
    expected_recipe = {"fingerprint": fingerprint, "renderer": renderer,
                       "output_fps": OUTPUT_FPS, "planned_duration_ms": duration_ms}
    measured = receipt["segment"]["measured_duration_ms"]
    if type(measured) not in (int, float) or not math.isfinite(measured) or abs(measured - duration_ms) > 1000 / OUTPUT_FPS / 2:
        raise PermissionError("pinned segment duration fails the existing drift bound")
    expected_segment = {"path": _relative(root, output), "sha256": observed_hash(output),
                        "size_bytes": output.stat().st_size, "measured_duration_ms": measured}
    if receipt["take_id"] != take_id or any(
        _segment_json_identity(receipt[name]) != _segment_json_identity(expected)
        for name, expected in (("source", expected_source), ("recipe", expected_recipe), ("segment", expected_segment))
    ):
        raise PermissionError("segment receipt differs from exact source, recipe or output bytes")
    pointer = {"schema_version": "2.0.0", "receipt_id": receipt_id,
               "receipt_path": _relative(root, receipt_path), "receipt_sha256": observed_hash(receipt_path)}
    if cache.exists() and _segment_json_identity(_segment_strict_json(cache)) != _segment_json_identity(pointer):
        raise PermissionError("existing segment pointer is corrupt/divergent; preserve it")
    evidence_paths = [source_path, output, anchor, receipt_path] + ([cache] if cache.exists() else [])
    evidence = [{"path": _relative(root, path), "sha256": observed_hash(path), "size_bytes": path.stat().st_size}
                for path in evidence_paths]
    return {"state": "CACHE_VERIFIED" if cache.exists() else "MISSING_POINTER_RECOVERABLE",
            "receipt": receipt, "pointer": pointer, "evidence": evidence}


def _record_segment_cache_event(root: Path, event: dict[str, Any]) -> dict[str, Any]:
    event_id = "segment-cache-" + hashlib.sha256(_segment_json_identity(event)).hexdigest()[:32]
    path = _segment_resident_path(root, root / SEGMENT_CACHE_EVENTS / f"{event_id}.json")
    payload = {**event, "event_id": event_id, "first_observed_at": _stamp()}
    if path.exists():
        existing = _segment_strict_json(path)
        observed = existing.get("first_observed_at")
        if not isinstance(observed, str) or datetime.fromisoformat(observed.replace("Z", "+00:00")).utcoffset() is None:
            raise PermissionError("cache event has no genuine timezone-aware observation")
        payload["first_observed_at"] = observed
    _write_immutable(path, payload)
    return {**payload, "event_path": _relative(root, path), "event_sha256": _sha(path)}


def verify_first_segment_cache_rejection(root: Path, error: str) -> dict[str, str]:
    """Read exact preserved first-take rejection; never recover or render it.

    This proves only the recorded pre-render guard failure. Voice may already
    exist, and the queue attempt must remain recorded. Later-take or changed
    observations are deliberately outside this narrow maintenance transition.
    """
    prefix = "PermissionError: segment cache recovery blocked before render: take-001:"
    if not isinstance(error, str) or not error.startswith(prefix):
        raise PermissionError("cache hold is not a first-segment rejection")
    relative = error[len(prefix):]
    path = _segment_resident_path(root, root / relative)
    if path.parent != (root / SEGMENT_CACHE_EVENTS).resolve() or _relative(root, path) != relative:
        raise PermissionError("cache hold event escaped its immutable directory")
    raw = path.read_bytes()
    event = _segment_strict_json(path)
    seed = {key: value for key, value in event.items() if key not in {"event_id", "first_observed_at"}}
    expected_id = "segment-cache-" + hashlib.sha256(_segment_json_identity(seed)).hexdigest()[:32]
    expected = {"schema_version": "1.0.0", "version": SEGMENT_CACHE_RECOVERY_VERSION,
                "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "take_id": "take-001",
                "route_type": "NONE", "status": "BLOCKED", "reusable": False,
                "fresh_output_absent": False, "provider_switched": False,
                "render_executed": False, "publication_authorized": False,
                "existing_output_overwrite_permitted": False, "evidence": [],
                "error": {"type": "PermissionError", "message":
                          "existing segment evidence is incomplete; refusing replacement render"}}
    if (event.get("event_id") != expected_id or path.name != expected_id + ".json"
            or any(event.get(key) != value for key, value in expected.items())):
        raise PermissionError("cache hold event identity/semantics diverged")
    fingerprint = event.get("fingerprint", "")
    if len(fingerprint) != 64 or any(c not in "0123456789abcdef" for c in fingerprint):
        raise PermissionError("cache hold fingerprint invalid")
    output = root / BASE / "render-work/video-segments/take-001.mp4"
    anchor = root / SEGMENT_RECIPE_ANCHORS / (fingerprint + ".json")
    if Path(event["output_path"]).resolve() != output.resolve() or Path(event["cache_path"]).resolve() != output.with_suffix(".cache.json").resolve():
        raise PermissionError("cache hold is not the preserved legacy workset")
    observations = event.get("failure_observations")
    if not isinstance(observations, list) or len(observations) != 4:
        raise PermissionError("cache hold observations incomplete")
    seen = set()
    for item in observations:
        target = _segment_resident_path(root, Path(item["path"]))
        if target in seen:
            raise PermissionError("cache hold duplicate observation")
        seen.add(target)
        if item["status"] == "ABSENT":
            if target != anchor.resolve() or target.exists() or item.get("sha256") is not None or item.get("size_bytes") is not None:
                raise PermissionError("cache hold absent anchor diverged")
        elif (item["status"] != "REJECTED_INPUT_BYTES_OBSERVED" or not target.is_file()
              or target.stat().st_size != item.get("size_bytes") or _sha(target) != item.get("sha256")):
            raise PermissionError("cache hold observed bytes diverged")
    required = {output.resolve(), output.with_suffix(".cache.json").resolve(), anchor.resolve()}
    source = seen - required
    if not required.issubset(seen) or len(source) != 1 or _sha(next(iter(source))) != event["source_expected_sha256"]:
        raise PermissionError("cache hold source set diverged")
    if path.read_bytes() != raw:
        raise PermissionError("cache hold event changed during read")
    return {"path": relative, "sha256": "sha256:" + hashlib.sha256(raw).hexdigest()}


def resolve_phase6_segment_cache(
    output: Path, cache: Path, *, root: Path, take_id: str, fingerprint: str,
    duration_ms: int, source_path: Path, source_hash: str,
    source_start_ms: float, source_end_ms: float, renderer: str = PHASE6_SEGMENT_RENDERER,
) -> dict[str, Any]:
    """Restore only an absent pointer from complete immutable proof, never media.

    EXACT_CACHE_REPLAY is a processing-avoidance route, not a provider switch,
    semantic approval or render permission. Existing FFprobe/release guards stay.
    """
    root = root.absolute()
    arguments = dict(root=root, take_id=take_id, fingerprint=fingerprint, duration_ms=duration_ms,
                     source_path=source_path, source_hash=source_hash,
                     source_start_ms=source_start_ms, source_end_ms=source_end_ms, renderer=renderer)
    event = {"schema_version": "1.0.0", "version": SEGMENT_CACHE_RECOVERY_VERSION,
             "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "take_id": take_id,
             "fingerprint": fingerprint, "source_expected_sha256": source_hash,
             "output_path": str(output), "cache_path": str(cache), "route_type": "NONE",
             "status": "BLOCKED", "reusable": False, "fresh_output_absent": False,
             "provider_switched": False, "render_executed": False, "publication_authorized": False,
             "existing_output_overwrite_permitted": False, "evidence": [],
             "failure_observations": [], "error": None}
    try:
        proof = _inspect_segment_cache_proof(output, cache, **arguments)
        event["evidence"] = proof["evidence"]
        if proof["state"] == "FRESH_OUTPUT_ABSENT":
            event.update(status="FRESH_OUTPUT_ABSENT", fresh_output_absent=True)
        else:
            if proof["state"] == "MISSING_POINTER_RECOVERABLE":
                # Exclusive commit refuses a concurrently created, different pointer.
                _write_immutable(_segment_resident_path(root, cache), proof["pointer"])
                verified = _inspect_segment_cache_proof(output, cache, **arguments)
                if verified["state"] != "CACHE_VERIFIED":
                    raise PermissionError("recovered segment pointer did not revalidate")
                event.update(status="POINTER_RECOVERED", evidence=verified["evidence"])
            else:
                event["status"] = "CACHE_VERIFIED"
            event.update(route_type="EXACT_CACHE_REPLAY", reusable=True)
    except Exception as exc:
        event.update(status="BLOCKED", reusable=False, fresh_output_absent=False,
                     error={"type": type(exc).__name__, "message": str(exc)})
        # Preserve a read-only fingerprint of accessible failed inputs. These are
        # observations of rejected bytes, never reclassified as verified proof.
        paths = [output, cache, source_path]
        if isinstance(fingerprint, str) and re.fullmatch(r"[0-9a-f]{64}", fingerprint):
            try:
                paths.append(_segment_anchor_dir(root, output, fingerprint) / f"{fingerprint}.json")
            except (ValueError, PermissionError):
                pass  # Invalid output scope is already recorded as a failure.
        for candidate in paths:
            row = {"path": str(candidate), "status": "UNAVAILABLE", "sha256": None, "size_bytes": None}
            try:
                candidate = _segment_resident_path(root, candidate)
                if candidate.is_file():
                    row.update(status="REJECTED_INPUT_BYTES_OBSERVED", sha256=_sha(candidate),
                               size_bytes=candidate.stat().st_size)
                elif not candidate.exists():
                    row["status"] = "ABSENT"
            except Exception:
                pass
            event["failure_observations"].append(row)
    return _record_segment_cache_event(root, event)


def _segment_cache_reusable(
    output: Path,
    cache: Path,
    *,
    root: Path,
    take_id: str,
    fingerprint: str,
    duration_ms: int,
    source_path: Path,
    source_hash: str,
    source_start_ms: float,
    source_end_ms: float,
    renderer: str = PHASE6_SEGMENT_RENDERER,
) -> bool:
    """Accept cache only through an immutable content receipt and recipe anchor."""

    if not output.is_file() or not cache.is_file():
        return False
    try:
        segment_encoder_arguments(renderer)
        output = _resolve(root, str(output))
        cache = _resolve(root, str(cache))
        source_path = _resolve(root, str(source_path))
        pointer = _read(cache)
        receipt_id = str(pointer.get("receipt_id") or "")
        receipt_path = _resolve(root, str(pointer.get("receipt_path") or ""))
        expected_dir = (root / SEGMENT_RECEIPTS).resolve()
        if receipt_path.parent != expected_dir or receipt_path.name != f"{receipt_id}.json":
            return False
        anchor = (_segment_anchor_dir(root, output, fingerprint) / f"{fingerprint}.json").resolve()
        if not receipt_path.is_file() or not anchor.is_file():
            return False
        receipt = _read(receipt_path)
        anchor_value = _read(anchor)
        _validate(root, "phase6_segment_receipt.schema.json", receipt)
        if receipt_id != _segment_receipt_id(receipt):
            return False
        if (
            pointer.get("schema_version") != "2.0.0"
            or pointer.get("receipt_sha256") != _sha(receipt_path)
            or anchor_value != {
                "schema_version": "1.0.0", "fingerprint": fingerprint,
                "receipt_id": receipt_id, "receipt_path": _relative(root, receipt_path),
                "receipt_sha256": _sha(receipt_path),
            }
        ):
            return False
        measured_ms = float(_probe(output)["format"]["duration"]) * 1000
        return bool(
            receipt.get("take_id") == take_id
            and receipt.get("source") == {
                "path": _relative(root, source_path), "sha256": source_hash,
                "start_ms": source_start_ms, "end_ms": source_end_ms,
            }
            and receipt.get("recipe") == {
                "fingerprint": fingerprint, "renderer": renderer,
                "output_fps": OUTPUT_FPS, "planned_duration_ms": duration_ms,
            }
            and receipt.get("segment") == {
                "path": _relative(root, output), "sha256": _sha(output),
                "size_bytes": output.stat().st_size, "measured_duration_ms": measured_ms,
            }
            and _sha(source_path) == source_hash
            and abs(measured_ms - duration_ms) <= 1000 / OUTPUT_FPS / 2
        )
    except Exception:
        return False


def _materialize_segment_receipt(
    root: Path,
    output: Path,
    cache: Path,
    *,
    take_id: str,
    fingerprint: str,
    duration_ms: int,
    source_path: Path,
    source_hash: str,
    source_start_ms: float,
    source_end_ms: float,
    created_at: str,
    renderer: str = PHASE6_SEGMENT_RENDERER,
) -> dict[str, Any]:
    segment_encoder_arguments(renderer)
    output, cache, source_path = (_resolve(root, str(item)) for item in (output, cache, source_path))
    measured_ms = float(_probe(output)["format"]["duration"]) * 1000
    receipt = {
        "schema_version": "1.0.0", "receipt_id": "phase6-segment-pending", "take_id": take_id,
        "source": {"path": _relative(root, source_path), "sha256": source_hash, "start_ms": source_start_ms, "end_ms": source_end_ms},
        "recipe": {"fingerprint": fingerprint, "renderer": renderer, "output_fps": OUTPUT_FPS, "planned_duration_ms": duration_ms},
        "segment": {"path": _relative(root, output), "sha256": _sha(output), "size_bytes": output.stat().st_size, "measured_duration_ms": measured_ms},
        "created_at": created_at,
    }
    receipt["receipt_id"] = _segment_receipt_id(receipt)
    _validate(root, "phase6_segment_receipt.schema.json", receipt)
    receipt_path = root / SEGMENT_RECEIPTS / f"{receipt['receipt_id']}.json"
    anchor_path = _segment_anchor_dir(root, output, fingerprint) / f"{fingerprint}.json"
    if anchor_path.is_file():
        anchor = _read(anchor_path)
        pinned = _resolve(root, str(anchor.get("receipt_path") or ""))
        if anchor.get("fingerprint") != fingerprint or anchor.get("receipt_id") != receipt["receipt_id"] or not pinned.is_file():
            raise PermissionError(f"segment recipe already pins different bytes: {take_id}")
        receipt = _read(pinned)
        receipt_path = pinned
    else:
        receipt = _write_immutable(receipt_path, receipt)
        anchor = {
            "schema_version": "1.0.0", "fingerprint": fingerprint,
            "receipt_id": receipt["receipt_id"], "receipt_path": _relative(root, receipt_path),
            "receipt_sha256": _sha(receipt_path),
        }
        _write_immutable(anchor_path, anchor)
    pointer = {
        "schema_version": "2.0.0", "receipt_id": receipt["receipt_id"],
        "receipt_path": _relative(root, receipt_path), "receipt_sha256": _sha(receipt_path),
    }
    _write_immutable(cache, pointer)
    return receipt


def verify_phase6_segment_set(
    root: Path,
    binding: dict[str, Any],
    *,
    expected_input_receipt_id: str | None = None,
    expected_renderer: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    path = _resolve(root, str(binding.get("path") or ""))
    if path.parent != (root / SEGMENT_SETS).resolve() or not path.is_file():
        raise PermissionError("render lacks a confined immutable segment-receipt set")
    value = _read(path)
    _validate(root, "phase6_segment_set.schema.json", value)
    payload = dict(value)
    payload.pop("set_id", None)
    payload.pop("created_at", None)
    expected_set_id = "phase6-segment-set-" + hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:32]
    if (
        value.get("set_id") != expected_set_id
        or path.name != f"{expected_set_id}.json"
        or binding.get("set_id") != expected_set_id
        or binding.get("sha256") != _sha(path)
        or binding.get("receipt_count") != len(value.get("receipts") or [])
    ):
        raise PermissionError("segment-receipt set identity/hash diverged")
    if expected_input_receipt_id is not None and value.get("production_inputs_receipt_id") != expected_input_receipt_id:
        raise PermissionError("segment-receipt set belongs to different production inputs")
    renderers = set()
    if expected_renderer is not None:
        segment_encoder_arguments(expected_renderer)
    for record in value["receipts"]:
        receipt_path = _resolve(root, record["path"])
        if receipt_path.parent != (root / SEGMENT_RECEIPTS).resolve() or receipt_path.name != f"{record['receipt_id']}.json":
            raise PermissionError(f"segment receipt escaped its immutable directory: {record['take_id']}")
        if not receipt_path.is_file() or _sha(receipt_path) != record["sha256"]:
            raise PermissionError(f"segment receipt hash mismatch: {record['take_id']}")
        receipt = _read(receipt_path)
        _validate(root, "phase6_segment_receipt.schema.json", receipt)
        renderer = receipt["recipe"]["renderer"]
        try:
            segment_encoder_arguments(renderer)
        except ValueError as exc:
            raise PermissionError(f"segment bytes/source/recipe no longer match immutable receipt: {record['take_id']}") from exc
        renderers.add(renderer)
        if len(renderers) != 1 or (expected_renderer is not None and renderer != expected_renderer):
            raise PermissionError("segment set renderer differs from exact plan or mixes profiles")
        if receipt.get("receipt_id") != record["receipt_id"] or _segment_receipt_id(receipt) != record["receipt_id"]:
            raise PermissionError(f"segment receipt identity mismatch: {record['take_id']}")
        segment = _resolve(root, receipt["segment"]["path"])
        source = _resolve(root, receipt["source"]["path"])
        cache = segment.with_suffix(".cache.json")
        if not _segment_cache_reusable(
            segment, cache, root=root, take_id=receipt["take_id"],
            fingerprint=receipt["recipe"]["fingerprint"],
            duration_ms=receipt["recipe"]["planned_duration_ms"],
            source_path=source, source_hash=receipt["source"]["sha256"],
            source_start_ms=receipt["source"]["start_ms"], source_end_ms=receipt["source"]["end_ms"],
            renderer=receipt["recipe"]["renderer"],
        ):
            raise PermissionError(f"segment bytes/source/recipe no longer match immutable receipt: {record['take_id']}")
    return value


def _assert_hash(path: Path, expected: str, label: str) -> None:
    if not path.is_file() or _sha(path) != expected:
        raise PermissionError(f"{label} changed while media bytes were being consumed: {path}")


def _strict_output_path(root: Path, receipt_id: str) -> Path:
    """Return the one forward-owned final-output path for an input receipt."""
    if not re.fullmatch(r"phase6-production-inputs-[0-9a-f]{20}", receipt_id):
        raise PermissionError("strict final output lacks an exact production-input identity")
    return _segment_resident_path(
        root,
        root / BASE / "renders" / f"heroverse-phase6-video-002.{receipt_id}.standard-candidate.mp4",
    )


def _resident_mux_witness(root: Path, output: Path) -> dict[str, Any]:
    """Authenticate, rather than merely notice, a completed strict mux.

    A retry may never adopt an arbitrary pre-existing MP4.  The sole admissible
    resident output is one produced by the resource-scoped FFmpeg witness whose
    output bytes and every declared input still match.  The caller rechecks the
    current production inputs separately, so this historical command evidence
    cannot become a general output fallback.
    """
    matches: list[dict[str, Any]] = []
    directory = root / BASE / "resource-preparation"
    for path in sorted(directory.glob("*.json")):
        try:
            value = _read(path)
        except (OSError, ValueError, json.JSONDecodeError):
            continue
        if value.get("entry") != "render_video2":
            continue
        for observation in value.get("observations") or []:
            execution = observation.get("execution") if isinstance(observation, dict) else None
            if not isinstance(execution, dict):
                continue
            recorded = execution.get("output")
            if not isinstance(recorded, dict) or execution.get("status") != "COMPLETED" or execution.get("exit_code") != 0:
                continue
            try:
                recorded_path = Path(str(recorded["path"])).resolve()
            except (KeyError, OSError, ValueError):
                continue
            if recorded_path != output.resolve():
                continue
            matches.append({"path": path, "observation": observation, "execution": execution})
    if len(matches) != 1:
        raise PermissionError("resident strict output lacks one exact completed mux witness")
    witness = matches[0]
    execution = witness["execution"]
    recorded = execution["output"]
    if not output.is_file() or _sha(output) != recorded.get("sha256") or output.stat().st_size != recorded.get("size_bytes"):
        raise PermissionError("resident strict output differs from its completed mux witness")
    for item in execution.get("inputs") or []:
        try:
            item_path = Path(str(item["path"])).resolve()
        except (KeyError, OSError, ValueError) as exc:
            raise PermissionError("resident mux witness has an invalid input path") from exc
        if not item_path.is_file() or _sha(item_path) != item.get("sha256") or item_path.stat().st_size != item.get("size_bytes"):
            raise PermissionError("resident mux witness input changed")
    return witness


def _thumbnail_lines(text: str) -> tuple[str, str]:
    words = re.findall(r"[A-Za-z0-9']+", text.upper())[:5]
    split = max(1, math.ceil(len(words) / 2))
    return " ".join(words[:split]), " ".join(words[split:])


def _render_thumbnails(
    root: Path,
    plan: dict[str, Any],
    brief: dict[str, Any],
    font: Path,
    created_at: str,
    *,
    source_hashes: dict[Path, str] | None = None,
) -> dict[str, Any]:
    directory = root / BASE / "thumbnail"
    directory.mkdir(parents=True, exist_ok=True)
    texts = (brief.get("package") or {}).get("thumbnail_text_variants") or ["TEST THE THOUGHT", "NAME TEST CHOOSE", "PRESSURE LIES"]
    candidates = []
    used_sources = []
    for take in plan["takes"]:
        source, start, _ = _origin(root, take["asset_origin"])
        if source not in [item[0] for item in used_sources]:
            used_sources.append((source, start))
        if len(used_sources) == 3:
            break
    for index, ((source, start), text) in enumerate(zip(used_sources, texts), start=1):
        candidate_id = chr(64 + index)
        line1, line2 = _thumbnail_lines(text)
        first, second = directory / f"{candidate_id}-line1.txt", directory / f"{candidate_id}-line2.txt"
        first.write_text(line1, encoding="utf-8")
        second.write_text(line2, encoding="utf-8")
        output = directory / f"candidate-{candidate_id.lower()}.jpg"
        expected_source_hash = (source_hashes or {}).get(source.resolve())
        if source_hashes is not None:
            if expected_source_hash is None:
                raise PermissionError(f"thumbnail source is outside the bound allocation: {source}")
            _assert_hash(source, expected_source_hash, f"thumbnail source {candidate_id}")
        filters = ",".join([
            "scale=1280:720:force_original_aspect_ratio=increase", "crop=1280:720",
            "eq=contrast=1.14:saturation=0.84:brightness=-0.025",
            "drawbox=x=0:y=0:w=720:h=720:color=0x081827@0.58:t=fill",
            "drawbox=x=72:y=145:w=10:h=430:color=0xD7A94A@1.0:t=fill",
            _text_filter(font, first, size=86, x="120", y="225", color="0xE8EDF2"),
            _text_filter(font, second, size=78, x="120", y="390", color="0xD7A94A"), "format=yuvj420p",
        ])
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}", "-i", str(source), "-vf", filters, "-frames:v", "1", "-q:v", "2", str(output)])
        if expected_source_hash is not None:
            _assert_hash(source, expected_source_hash, f"thumbnail source {candidate_id}")
        if output.stat().st_size > 2_097_152:
            raise RuntimeError(f"thumbnail exceeds 2 MiB: {candidate_id}")
        candidates.append({
            "candidate_id": candidate_id, "path": str(output.resolve()), "content_hash": _sha(output),
            "width": 1280, "height": 720, "size_bytes": output.stat().st_size,
            "text": text, "source": _relative(root, source), "automated_status": "PENDING_FULL_GATE",
        })
    manifest = {
        "schema_version": "1.0.0",
        "set_id": "phase6-thumbnails-" + hashlib.sha256("|".join(item["content_hash"] for item in candidates).encode()).hexdigest()[:20],
        "title_variants": (brief.get("package") or {}).get("title_variants") or [],
        "candidates": candidates, "selection_status": "PENDING_AUTONOMOUS_QUALITY_GATE",
        "selected_candidate": None, "publication_authorized": False,
        "technical_cost_brl": 0, "created_at": created_at,
    }
    _write(directory / "thumbnail_set_manifest.json", manifest)
    return manifest


@_resource_scoped
def render_video2(
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    strict_inputs: bool = False,
    voice_manifest_path: Path | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    timestamp = created_at or _stamp()
    bound_receipt: dict[str, Any] | None = None
    if strict_inputs:
        bound_receipt, reason = _verified_inputs(root)
        if bound_receipt is None:
            raise PermissionError(reason or "strict render has no production-input receipt")
        require_current_visual_preflight(root)
    render_dir = root / BASE / "renders"
    final_output = render_dir / "heroverse-phase6-video-002.standard-candidate.mp4"
    if strict_inputs:
        input_id = str(bound_receipt.get("receipt_id") or "")
        # Keep earlier render paths valid for their immutable manifests.  A
        # fresh receipt owns a new output; an existing output is not retry input.
        final_output = _strict_output_path(root, input_id)
        if final_output.exists():
            raise PermissionError("strict final output already exists; refusing overwrite")
    production, preproduction = root / BASE / "production", root / BASE / "preproduction"
    plan = _read(production / "take_plan.json")
    renderer = plan_renderer(plan)
    bible = _read(production / "channel_style_bible.json")
    treatment = _read(production / "creative_treatment_plan.json")
    allocation = _read(production / "asset_allocation.json")
    brief = _read(preproduction / "editorial_brief.json")
    selected_voice_path = voice_manifest_path or (root / BASE / "audio/voice_render_manifest.json")
    voice = _read(selected_voice_path)
    if strict_inputs:
        capacity_reference = voice.get("capacity_preflight") or {}
        capacity_path = _resolve(root, str(capacity_reference.get("receipt_path") or ""))
        capacity = verify_phase6_capacity_receipt(
            root,
            receipt_path=capacity_path,
            expected_receipt_id=str(capacity_reference.get("receipt_id") or ""),
            expected_sha256=str(capacity_reference.get("sha256") or ""),
            require_pass=True,
        )
        _verify_voice_manifest_contract(
            root,
            voice,
            expected_capacity_reference=capacity_reference,
            expected_espeak=espeak_binding_identity(capacity["espeak"]),
        )
    treatment_by_take = {item["take_id"]: item for item in treatment["takes"]}
    voice_by_take = {item["take_id"]: item for item in voice["takes"]}
    allocation_by_take = {item["take_id"]: item for item in allocation["takes"]}
    work = root / BASE / "render-work"
    # A strict render is a current forward-only execution.  It must not read,
    # overwrite, or reinterpret the historical segment workset.
    workset = CURRENT_SEGMENT_WORKSET if strict_inputs else "legacy"
    video_dir = work / (f"video-segments-{workset}" if strict_inputs else "video-segments")
    audio_dir = work / (f"audio-segments-{workset}" if strict_inputs else "audio-segments")
    video_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    font = _font()
    total_started = time.perf_counter()
    video_started = time.perf_counter()
    video_files, timeline, asset_ids, segment_records = [], [], [], []
    source_hashes: dict[Path, str] = {}
    cursor = 0.0
    for take in plan["takes"]:
        take_id = take["take_id"]
        source, source_start, source_end = _origin(root, take["asset_origin"])
        duration_ms = int(take["end_ms"]) - int(take["start_ms"])
        if not source.is_file() or source_end - source_start + 0.002 < duration_ms / 1000:
            raise PermissionError(f"invalid source span for {take_id}")
        allocation_row = allocation_by_take.get(take_id)
        if allocation_row is None:
            raise PermissionError(f"allocation missing for {take_id}")
        expected_source_hash = str(allocation_row.get("content_hash") or _sha(source))
        if strict_inputs:
            if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_source_hash):
                raise PermissionError(f"allocation source hash missing or malformed for {take_id}")
            declared_source = Path(str(allocation_row.get("source_path") or ""))
            declared_source = declared_source if declared_source.is_absolute() else root / declared_source
            if declared_source.resolve() != source.resolve():
                raise PermissionError(f"TakePlan/allocation source path mismatch for {take_id}")
            if abs(float(allocation_row.get("source_start_ms", -1)) - source_start * 1000) > 0.5 or abs(float(allocation_row.get("source_end_ms", -1)) - source_end * 1000) > 0.5:
                raise PermissionError(f"TakePlan/allocation source span mismatch for {take_id}")
            _assert_hash(source, expected_source_hash, f"source asset for {take_id}")
        source_hashes[source.resolve()] = expected_source_hash
        fingerprint = _fingerprint(source, take, treatment_by_take[take_id], source_hash=expected_source_hash, renderer=renderer)
        # Distinct recipes own distinct immutable outputs. A newer recipe must
        # not overwrite a previous successful or incomplete render for this take.
        segment_dir = video_dir / fingerprint if strict_inputs else video_dir
        output = segment_dir / f"{take_id}.mp4"
        cache = output.with_suffix(".cache.json")
        cache_resolution = resolve_phase6_segment_cache(
            output, cache, root=root, take_id=take_id, fingerprint=fingerprint, duration_ms=duration_ms,
            source_path=source, source_hash=expected_source_hash,
            source_start_ms=source_start * 1000, source_end_ms=source_end * 1000,
            renderer=renderer,
        )
        if cache_resolution["status"] == "BLOCKED":
            raise PermissionError(
                f"segment cache recovery blocked before render: {take_id}:"
                f"{cache_resolution['event_path']}"
            )
        reusable = cache_resolution["reusable"]
        if not reusable:
            if not cache_resolution["fresh_output_absent"] or output.exists():
                raise PermissionError(f"segment output is not fresh; refusing overwrite: {take_id}")
            segment_dir.mkdir(parents=True, exist_ok=True)
            filters = _visual_filters(take, treatment_by_take[take_id], font=font, work_dir=work)
            if strict_inputs:
                _assert_hash(source, expected_source_hash, f"source asset for {take_id}")
            _run([FFMPEG, "-n", "-hide_banner", "-loglevel", "error", "-ss", f"{source_start:.3f}", "-i", str(source), "-an", "-vf", ",".join(filters), "-frames:v", str(_frames(duration_ms)), "-r", "30", *segment_encoder_arguments(renderer), str(output)], witness_output=output, witness_inputs=(source,))
            if strict_inputs:
                _assert_hash(source, expected_source_hash, f"source asset for {take_id}")
        actual = round(float(_probe(output)["format"]["duration"]) * 1000, 6)
        if abs(actual - duration_ms) > 1000 / OUTPUT_FPS / 2:
            raise RuntimeError(f"segment drift for {take_id}: {actual - duration_ms} ms")
        segment_hash = _sha(output)
        if not reusable:
            segment_receipt = _materialize_segment_receipt(
                root, output, cache, take_id=take_id, fingerprint=fingerprint,
                duration_ms=duration_ms, source_path=source, source_hash=expected_source_hash,
                source_start_ms=source_start * 1000, source_end_ms=source_end * 1000,
                created_at=timestamp,
                renderer=renderer,
            )
        else:
            segment_receipt = _read(_resolve(root, _read(cache)["receipt_path"]))
        if not _segment_cache_reusable(
            output, cache, root=root, take_id=take_id, fingerprint=fingerprint, duration_ms=duration_ms,
            source_path=source, source_hash=expected_source_hash,
            source_start_ms=source_start * 1000, source_end_ms=source_end * 1000,
            renderer=renderer,
        ):
            raise PermissionError(f"segment cache/content binding failed for {take_id}")
        timeline.append({"take_id": take_id, "planned_start_ms": int(take["start_ms"]), "planned_end_ms": int(take["end_ms"]), "actual_start_ms": round(cursor, 6), "actual_end_ms": round(cursor + actual, 6), "planned_duration_ms": duration_ms, "actual_duration_ms": actual, "frame_count": _frames(duration_ms)})
        cursor += actual
        video_files.append(output)
        segment_records.append((output, cache, take_id, fingerprint, duration_ms, segment_hash, source, expected_source_hash, source_start * 1000, source_end * 1000, segment_receipt))
        asset_id = allocation_row["asset_id"]
        asset_ids.append(asset_id)
    video_seconds = time.perf_counter() - video_started
    audio_started = time.perf_counter()
    audio_files = []
    for take in plan["takes"]:
        take_id = take["take_id"]
        duration = (int(take["end_ms"]) - int(take["start_ms"])) / 1000
        output = audio_dir / f"{take_id}.wav"
        voice_source = _resolve(root, voice_by_take[take_id]["path"])
        expected_voice_hash = voice_by_take[take_id].get("content_hash")
        if strict_inputs:
            if not isinstance(expected_voice_hash, str):
                raise PermissionError(f"voice hash missing for {take_id}")
            _assert_hash(voice_source, expected_voice_hash, f"voice take for {take_id}")
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(voice_source), "-af", f"aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo,highpass=f=65,lowpass=f=15500,acompressor=threshold=0.15:ratio=2.2:attack=16:release=170:makeup=1.20,apad,atrim=0:{duration:.3f}", "-c:a", "pcm_s16le", str(output)])
        if strict_inputs:
            _assert_hash(voice_source, expected_voice_hash, f"voice take for {take_id}")
        audio_files.append(output)
    for segment, cache, take_id, fingerprint, planned_ms, expected_hash, source, source_hash, source_start_ms, source_end_ms, _ in segment_records:
        if _sha(segment) != expected_hash or not _segment_cache_reusable(
            segment, cache, root=root, take_id=take_id, fingerprint=fingerprint, duration_ms=planned_ms,
            source_path=source, source_hash=source_hash,
            source_start_ms=source_start_ms, source_end_ms=source_end_ms,
            renderer=renderer,
        ):
            raise PermissionError(f"segment changed before concat: {take_id}")
    segment_set = {
        "schema_version": "1.0.0", "set_id": "phase6-segment-set-pending",
        "production_inputs_receipt_id": bound_receipt.get("receipt_id") if bound_receipt else None,
        "take_plan_id": plan["take_plan_id"],
        "receipts": [
            {
                "take_id": take_id, "receipt_id": segment_receipt["receipt_id"],
                "path": _relative(root, root / SEGMENT_RECEIPTS / f"{segment_receipt['receipt_id']}.json"),
                "sha256": _sha(root / SEGMENT_RECEIPTS / f"{segment_receipt['receipt_id']}.json"),
            }
            for _, _, take_id, _, _, _, _, _, _, _, segment_receipt in segment_records
        ],
        "created_at": timestamp,
    }
    segment_set_payload = dict(segment_set)
    segment_set_payload.pop("set_id", None)
    segment_set_payload.pop("created_at", None)
    segment_set["set_id"] = "phase6-segment-set-" + hashlib.sha256(
        json.dumps(segment_set_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:32]
    _validate(root, "phase6_segment_set.schema.json", segment_set)
    segment_set_path = root / SEGMENT_SETS / f"{segment_set['set_id']}.json"
    segment_set = _write_immutable(segment_set_path, segment_set)
    video_list, audio_list = work / "video-concat.txt", work / "audio-concat.txt"
    _concat_file(video_list, video_files)
    _concat_file(audio_list, audio_files)
    silent, narration = work / "silent-concat.mp4", work / "narration.wav"
    copy_video = renderer == PALETTE_QP1_SEGMENT_RENDERER
    if not copy_video:
        _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(video_list), "-c", "copy", str(silent)], witness_output=silent, witness_inputs=tuple([video_list] + video_files))
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(audio_list), "-c:a", "pcm_s16le", str(narration)])
    for segment, _, take_id, _, _, expected_hash, _, _, _, _, _ in segment_records:
        if _sha(segment) != expected_hash:
            raise PermissionError(f"segment changed during concat: {take_id}")
    sfx = _resource_call("audio:sfx", _build_sfx, plan, treatment, work / "creative-sfx.wav")
    duration_ms = int(plan["takes"][-1]["end_ms"])
    music = _resource_call("audio:music", _build_original_music, duration_ms, work / "original-music.wav", created_at=timestamp)
    audio_manifest = {"schema_version": "1.0.0", "voice_render_id": voice["voice_render_id"], "sfx": sfx, "music": music, "mix_contract": {"integrated_loudness_lufs": -16, "true_peak_dbtp": -1.3, "music_ducking": "sidechain from narration", "clipping_permitted": False}, "created_at": timestamp}
    _write(root / BASE / "audio/creative_audio_manifest.json", audio_manifest)
    captions = _build_captions(plan, root / BASE / "captions/en-US.srt")
    _write(root / BASE / "captions/caption_manifest.json", captions)
    audio_seconds = time.perf_counter() - audio_started
    render_dir.mkdir(parents=True, exist_ok=True)
    output = final_output
    final_started = time.perf_counter()
    video_input_arguments = (["-f", "concat", "-safe", "0", "-i", str(video_list)]
                             if copy_video else ["-i", str(silent)])
    mux_inputs = ([video_list, *video_files] if copy_video else [silent]) + [narration, _resolve(root, sfx["path"]), _resolve(root, music["path"])]
    mux_hashes = {path.resolve(): _sha(path) for path in mux_inputs}
    if strict_inputs and bound_receipt is not None:
        _reverify_same_inputs(root, bound_receipt["receipt_id"], recheck_decode=False)
        if _segment_resident_path(root, output).exists():
            raise PermissionError("strict final output appeared before mux; refusing overwrite")
    _run([FFMPEG, "-n" if strict_inputs else "-y", "-hide_banner", "-loglevel", "error", *video_input_arguments, "-i", str(narration), "-i", sfx["path"], "-i", music["path"], "-filter_complex", "[1:a]volume=1.0,asplit=2[nmix][nkey];[2:a]volume=0.82[sfx];[3:a]volume=0.70[m];[m][nkey]sidechaincompress=threshold=0.035:ratio=8:attack=18:release=380[md];[nmix][sfx][md]amix=inputs=3:duration=first:normalize=0,loudnorm=I=-16:LRA=7:TP=-1.3[aout]", "-map", "0:v:0", "-map", "[aout]", *final_video_arguments(renderer), "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2", "-t", f"{duration_ms / 1000:.3f}", "-movflags", "+faststart", str(output)], witness_output=output, witness_inputs=tuple(mux_inputs))
    for path in mux_inputs:
        _assert_hash(path, mux_hashes[path.resolve()], "final mux input")
    if strict_inputs and bound_receipt is not None:
        _reverify_same_inputs(root, bound_receipt["receipt_id"], recheck_decode=False)
    final_seconds = time.perf_counter() - final_started
    thumbnails = _render_thumbnails(
        root, plan, brief, font, timestamp,
        source_hashes=source_hashes if strict_inputs else None,
    )
    probe = _probe(output)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    measured_ms = round(float(probe["format"]["duration"]) * 1000)
    library_path = root / "output/production/phase6/shared-assets/asset_manifest.json"
    library = _read(library_path)
    asset_map = {item["asset_id"]: item for item in library["assets"]}
    attribution = root / BASE / "attribution.txt"
    lines = ["HeroVerse Phase 6 Video 2 — source attribution and original-audio record", "Every source is used inside an original English narrative and semantic edit.", ""]
    for asset_id in sorted(set(asset_ids)):
        item = asset_map[asset_id]
        lines.extend([asset_id, f"Source: {item['source']}", f"Creator/holder: {item.get('creator_or_holder')}", f"Rights: {item['rights_status']} / {item.get('license')}", f"Attribution: {item.get('attribution') or 'None recorded'}", f"Evidence: {item['rights_evidence_uri']}", ""])
    lines.extend(["Original procedural music", f"Generator: {music['generator']}", f"Rights: {music['rights_status']}", f"Hash: {music['content_hash']}", ""])
    attribution.write_text("\n".join(lines), encoding="utf-8")
    total_seconds = time.perf_counter() - total_started
    manifest = {
        "schema_version": "1.1.0", "render_id": "render-phase6-" + hashlib.sha256((plan["take_plan_id"] + "|" + _sha(output)).encode()).hexdigest()[:20],
        "status": "COMPLETE", "video_id": VIDEO_ID, "quality_profile": "STANDARD",
        "pipeline_id": "pipeline-clips-longform-v1", "pipeline_version": "1.0.0",
        "format_pack_id": plan["format_pack_id"], "format_pack_version": plan["format_pack_version"],
        "take_plan_id": plan["take_plan_id"], "style_bible_id": bible["style_bible_id"],
        "creative_treatment_plan_id": treatment["treatment_plan_id"], "creative_treatment_version": treatment["version"],
        "voice_render_id": voice["voice_render_id"],
        "adapter_versions": ["adapter-ffmpeg-local@runtime", "adapter-local-voice@KokoroFloatSpeed-1.0.0", "HeroVerseProceduralPad@1.0.0"],
        "segment_count": len(video_files), "source_asset_ids": sorted(set(asset_ids)),
        "output": {"path": str(output.resolve()), "content_hash": _sha(output), "container": "mp4", "video_codec": video["codec_name"], "audio_codec": audio["codec_name"], "width": int(video["width"]), "height": int(video["height"]), "fps": round(_fps(video["r_frame_rate"]), 6), "duration_ms": measured_ms, "size_bytes": output.stat().st_size},
        "measurements": {"total_wall_seconds": round(total_seconds, 6), "video_segment_render_seconds": round(video_seconds, 6), "audio_assembly_seconds": round(audio_seconds, 6), "final_mux_seconds": round(final_seconds, 6), "real_time_factor": round(total_seconds / (measured_ms / 1000), 6), "peak_working_set_mb": None, "peak_working_set_status": "UNAVAILABLE", "output_fps": OUTPUT_FPS, "expected_total_frames": sum(item["frame_count"] for item in timeline), "maximum_take_duration_error_ms": round(max(abs(item["planned_duration_ms"] - item["actual_duration_ms"]) for item in timeline), 6), "maximum_cumulative_drift_ms": round(max(abs(item["planned_end_ms"] - item["actual_end_ms"]) for item in timeline), 6)},
        "segment_timeline": timeline,
        "segment_receipt_set": {"set_id": segment_set["set_id"], "path": _relative(root, segment_set_path), "sha256": _sha(segment_set_path), "receipt_count": len(segment_set["receipts"])},
        "captions": {key: captions[key] for key in ("path", "content_hash", "cue_count", "language", "coverage_ratio")},
        "audio_design": {"manifest_path": str((root / BASE / "audio/creative_audio_manifest.json").resolve()), "music_content_hash": music["content_hash"], "rights_status": music["rights_status"]},
        "thumbnail_set": {"manifest_path": str((root / BASE / "thumbnail/thumbnail_set_manifest.json").resolve()), "set_id": thumbnails["set_id"], "selection_status": thumbnails["selection_status"]},
        "attribution_path": str(attribution.resolve()), "external_cost_usd": 0, "publication_approved": False,
        "limitations": ["STANDARD candidate still requires independent automatic quality, rights, originality, ASR and release gates.", "Audience response and YPP approval are not render outputs."],
        "created_at": timestamp,
    }
    _validate(root, "render_manifest.schema.json", manifest)
    if strict_inputs and bound_receipt is not None:
        _reverify_same_inputs(root, bound_receipt["receipt_id"], recheck_decode=True)
    manifest = _write_immutable(
        root / BASE / "renders/manifests" / f"{manifest['render_id']}.json",
        manifest,
    )
    verify_phase6_segment_set(
        root, manifest["segment_receipt_set"],
        expected_input_receipt_id=bound_receipt.get("receipt_id") if bound_receipt else None,
        expected_renderer=renderer,
    )
    _write(root / BASE / "render_manifest.json", manifest)
    return manifest


@_resource_scoped
def resume_resident_strict_mux(
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    voice_manifest_path: Path | None = None,
) -> dict[str, Any]:
    """Finish only the post-mux portion of one witnessed strict render.

    This is intentionally not a retry of ``render_video2``: segment rendering,
    audio construction and the final mux are already complete and must not be
    repeated.  Every mutable input is reopened, and the resident MP4 is usable
    only when a single immutable resource witness proves the exact completed
    mux and still-current inputs.
    """
    root = root.resolve()
    timestamp = created_at or _stamp()
    receipt, reason = _verified_inputs(root)
    if receipt is None:
        raise PermissionError(reason or "strict resident recovery has no production-input receipt")
    require_current_visual_preflight(root)
    output = _strict_output_path(root, str(receipt["receipt_id"]))
    witness = _resident_mux_witness(root, output)
    _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=True)

    production, preproduction = root / BASE / "production", root / BASE / "preproduction"
    plan = _read(production / "take_plan.json")
    bible = _read(production / "channel_style_bible.json")
    treatment = _read(production / "creative_treatment_plan.json")
    allocation = _read(production / "asset_allocation.json")
    brief = _read(preproduction / "editorial_brief.json")
    voice_path = voice_manifest_path or (root / BASE / "audio/voice_render_manifest.json")
    voice = _read(voice_path)
    capacity_reference = voice.get("capacity_preflight") or {}
    capacity_path = _resolve(root, str(capacity_reference.get("receipt_path") or ""))
    capacity = verify_phase6_capacity_receipt(
        root,
        receipt_path=capacity_path,
        expected_receipt_id=str(capacity_reference.get("receipt_id") or ""),
        expected_sha256=str(capacity_reference.get("sha256") or ""),
        require_pass=True,
    )
    _verify_voice_manifest_contract(
        root, voice,
        expected_capacity_reference=capacity_reference,
        expected_espeak=espeak_binding_identity(capacity["espeak"]),
    )

    renderer = plan_renderer(plan)
    candidates: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted((root / SEGMENT_SETS).glob("*.json")):
        value = _read(path)
        if (
            value.get("production_inputs_receipt_id") == receipt["receipt_id"]
            and value.get("take_plan_id") == plan.get("take_plan_id")
        ):
            candidates.append((path, value))
    if len(candidates) != 1:
        raise PermissionError("resident mux lacks one exact immutable segment set")
    segment_path, segment_set = candidates[0]
    segment_binding = {
        "set_id": segment_set["set_id"],
        "path": _relative(root, segment_path),
        "sha256": _sha(segment_path),
        "receipt_count": len(segment_set.get("receipts") or []),
    }
    verified_set = verify_phase6_segment_set(
        root, segment_binding,
        expected_input_receipt_id=receipt["receipt_id"], expected_renderer=renderer,
    )
    if len(verified_set.get("receipts") or []) != len(plan.get("takes") or []):
        raise PermissionError("resident mux segment set does not cover current plan")
    by_take = {item["take_id"]: item for item in verified_set["receipts"]}
    allocation_by_take = {item["take_id"]: item for item in allocation.get("takes") or []}
    timeline: list[dict[str, Any]] = []
    source_hashes: dict[Path, str] = {}
    asset_ids: list[str] = []
    cursor = 0.0
    for take in plan.get("takes") or []:
        take_id = str(take["take_id"])
        record = by_take.get(take_id)
        row = allocation_by_take.get(take_id)
        if record is None or row is None:
            raise PermissionError("resident mux plan/segment/allocation identity diverged")
        segment_receipt = _read(_resolve(root, record["path"]))
        segment = _resolve(root, segment_receipt["segment"]["path"])
        actual = round(float(_probe(segment)["format"]["duration"]) * 1000, 6)
        planned = int(take["end_ms"]) - int(take["start_ms"])
        if abs(actual - planned) > 1000 / OUTPUT_FPS / 2:
            raise PermissionError(f"resident mux segment drift: {take_id}")
        source, _, _ = _origin(root, take["asset_origin"])
        expected_source_hash = str(row.get("content_hash") or "")
        _assert_hash(source, expected_source_hash, f"resident mux source {take_id}")
        source_hashes[source.resolve()] = expected_source_hash
        timeline.append({
            "take_id": take_id, "planned_start_ms": int(take["start_ms"]),
            "planned_end_ms": int(take["end_ms"]), "actual_start_ms": round(cursor, 6),
            "actual_end_ms": round(cursor + actual, 6), "planned_duration_ms": planned,
            "actual_duration_ms": actual, "frame_count": _frames(planned),
        })
        cursor += actual
        asset_ids.append(str(row["asset_id"]))

    audio_manifest = _read(root / BASE / "audio/creative_audio_manifest.json")
    if audio_manifest.get("voice_render_id") != voice.get("voice_render_id"):
        raise PermissionError("resident mux creative audio belongs to a different voice set")
    for label in ("sfx", "music"):
        item = audio_manifest.get(label)
        if not isinstance(item, dict):
            raise PermissionError("resident mux creative audio is incomplete")
        audio_path = _resolve(root, str(item.get("path") or ""))
        _assert_hash(audio_path, str(item.get("content_hash") or ""), f"resident mux {label}")
    captions = _read(root / BASE / "captions/caption_manifest.json")
    caption_path = _resolve(root, str(captions.get("path") or ""))
    _assert_hash(caption_path, str(captions.get("content_hash") or ""), "resident mux captions")

    font = _font()
    thumbnails = _render_thumbnails(root, plan, brief, font, timestamp, source_hashes=source_hashes)
    probe = _probe(output)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    measured_ms = round(float(probe["format"]["duration"]) * 1000)
    library = _read(root / "output/production/phase6/shared-assets/asset_manifest.json")
    asset_map = {item["asset_id"]: item for item in library["assets"]}
    attribution = root / BASE / "attribution.txt"
    lines = ["HeroVerse Phase 6 Video 2 — source attribution and original-audio record", "Every source is used inside an original English narrative and semantic edit.", ""]
    for asset_id in sorted(set(asset_ids)):
        item = asset_map[asset_id]
        lines.extend([asset_id, f"Source: {item['source']}", f"Creator/holder: {item.get('creator_or_holder')}", f"Rights: {item['rights_status']} / {item.get('license')}", f"Attribution: {item.get('attribution') or 'None recorded'}", f"Evidence: {item['rights_evidence_uri']}", ""])
    music = audio_manifest["music"]
    lines.extend(["Original procedural music", f"Generator: {music['generator']}", f"Rights: {music['rights_status']}", f"Hash: {music['content_hash']}", ""])
    attribution.write_text("\n".join(lines), encoding="utf-8")
    execution = witness["execution"]
    manifest = {
        "schema_version": "1.1.0", "render_id": "render-phase6-" + hashlib.sha256((plan["take_plan_id"] + "|" + _sha(output)).encode()).hexdigest()[:20],
        "status": "COMPLETE", "video_id": VIDEO_ID, "quality_profile": "STANDARD",
        "pipeline_id": "pipeline-clips-longform-v1", "pipeline_version": "1.0.0",
        "format_pack_id": plan["format_pack_id"], "format_pack_version": plan["format_pack_version"],
        "take_plan_id": plan["take_plan_id"], "style_bible_id": bible["style_bible_id"],
        "creative_treatment_plan_id": treatment["treatment_plan_id"], "creative_treatment_version": treatment["version"],
        "voice_render_id": voice["voice_render_id"],
        "adapter_versions": ["adapter-ffmpeg-local@runtime", "adapter-local-voice@KokoroFloatSpeed-1.0.0", "HeroVerseProceduralPad@1.0.0"],
        "segment_count": len(timeline), "source_asset_ids": sorted(set(asset_ids)),
        "output": {"path": str(output.resolve()), "content_hash": _sha(output), "container": "mp4", "video_codec": video["codec_name"], "audio_codec": audio["codec_name"], "width": int(video["width"]), "height": int(video["height"]), "fps": round(_fps(video["r_frame_rate"]), 6), "duration_ms": measured_ms, "size_bytes": output.stat().st_size},
        "measurements": {"total_wall_seconds": round(float(witness["observation"].get("elapsed_seconds") or 0.0), 6), "video_segment_render_seconds": 0.0, "audio_assembly_seconds": 0.0, "final_mux_seconds": round(float(witness["observation"].get("elapsed_seconds") or 0.0), 6), "real_time_factor": round(float(witness["observation"].get("elapsed_seconds") or 0.0) / (measured_ms / 1000), 6), "peak_working_set_mb": None, "peak_working_set_status": "UNAVAILABLE", "output_fps": OUTPUT_FPS, "expected_total_frames": sum(item["frame_count"] for item in timeline), "maximum_take_duration_error_ms": round(max(abs(item["planned_duration_ms"] - item["actual_duration_ms"]) for item in timeline), 6), "maximum_cumulative_drift_ms": round(max(abs(item["planned_end_ms"] - item["actual_end_ms"]) for item in timeline), 6)},
        "segment_timeline": timeline, "segment_receipt_set": segment_binding,
        "captions": {key: captions[key] for key in ("path", "content_hash", "cue_count", "language", "coverage_ratio")},
        "audio_design": {"manifest_path": str((root / BASE / "audio/creative_audio_manifest.json").resolve()), "music_content_hash": music["content_hash"], "rights_status": music["rights_status"]},
        "thumbnail_set": {"manifest_path": str((root / BASE / "thumbnail/thumbnail_set_manifest.json").resolve()), "set_id": thumbnails["set_id"], "selection_status": thumbnails["selection_status"]},
        "attribution_path": str(attribution.resolve()), "external_cost_usd": 0, "publication_approved": False,
        "limitations": ["Resident mux recovery requires independent automatic quality, rights, originality, ASR and release gates.", "Audience response and YPP approval are not render outputs."], "created_at": timestamp,
    }
    _validate(root, "render_manifest.schema.json", manifest)
    _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=True)
    manifest = _write_immutable(root / BASE / "renders/manifests" / f"{manifest['render_id']}.json", manifest)
    _write(root / BASE / "render_manifest.json", manifest)
    return manifest


def run_phase6_media_executor(root: Path = ROOT, *, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    Phase6ResourcePreparation(root)._unpaused()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    timestamp = _stamp(current)
    if (root / RUNTIME).is_file():
        post_application_wait = _post_application_wait(
            root, _read(root / RUNTIME), timestamp=timestamp,
        )
        if post_application_wait is not None:
            _validate(
                root, "phase6_media_executor_runtime.schema.json",
                post_application_wait,
            )
            _write(root / RUNTIME, post_application_wait)
            return post_application_wait
    # A stopped-maintenance migration may have classified one exact historical
    # SUCCEEDED render as unusable under the current visual contract.  Reopen
    # its immutable proof and complete queue lineage before doing any capacity,
    # synthesis, render or claim work.  This remains WAITING, never COMPLETED.
    if (root / RUNTIME).is_file():
        prior_runtime = _read(root / RUNTIME)
        if (
            prior_runtime.get("schema_version") == "1.3.0"
            or prior_runtime.get("remediation_wait") is not None
        ):
            verify_post_effect_visual_wait(root, prior_runtime)
            latest_path = (
                root
                / "output/operations/phase6/release/latest-production-inputs-receipt.json"
            )
            latest = _read(latest_path)
            if latest.get("receipt_id") == prior_runtime.get("input_receipt_id"):
                waiting = {**prior_runtime, "updated_at": timestamp}
                _validate(
                    root, "phase6_media_executor_runtime.schema.json", waiting
                )
                _write(root / RUNTIME, waiting)
                return waiting
            # The immutable historical wait remains verified evidence, but a
            # later fully bound production receipt must not be hidden by it.
            # Fall through to the active current-receipt consumer; it reopens
            # every current byte before capacity, queue, voice, or render.
    receipt, wait_reason = _verified_inputs(root)
    visual_preflight: dict[str, Any] | None = None
    if receipt is not None:
        try:
            proof = require_current_visual_preflight(root)
            visual_preflight = {key: proof[key] for key in ("audit_id", "path", "sha256", "status")}
        except Exception as exc:
            proof = getattr(exc, "binding", None)
            visual_preflight = ({key: proof[key] for key in ("audit_id", "path", "sha256", "status")} if proof else None)
            blocked = {
                "schema_version": "1.2.0", "executor_id": "heroverse-phase6-media-executor-v1", "phase": 6,
                "status": "BLOCKED", "input_receipt_id": receipt["receipt_id"],
                "action": "SYNTHESIZE_AND_RENDER_VIDEO_2", "job_id": None, "job_state": "NOT_CREATED",
                "voice_manifest": None, "render_manifest": None, "visual_preflight": visual_preflight,
                "capacity_preflight_receipt": None, "capacity_preflight_sha256": None,
                "capacity_status": "UNAVAILABLE", "capacity_observed_free_bytes": None,
                "capacity_required_free_bytes": None, "capacity_headroom_bytes": None,
                "next_action": "Resolve the visual contract before capacity, queue, synthesis or render; historical jobs and media are untouched.",
                "error": f"{type(exc).__name__}: {exc}", "publication_authorized": False,
                "technical_cost_brl": 0, "updated_at": timestamp,
            }
            _validate(root, "phase6_media_executor_runtime.schema.json", blocked)
            _write(root / RUNTIME, blocked)
            return blocked
    capacity = run_phase6_capacity_preflight(root, now=current, require_asset_residency=receipt is not None)
    capacity_receipt_path = root / CAPACITY_RECEIPTS / f"{capacity['receipt_id']}.json"
    capacity_receipt = _relative(root, capacity_receipt_path)
    capacity_receipt_hash = _sha(capacity_receipt_path) if capacity_receipt_path.is_file() else None
    if capacity_receipt_hash is not None:
        verify_phase6_capacity_receipt(
            root,
            receipt_path=capacity_receipt_path,
            expected_receipt_id=capacity["receipt_id"],
            expected_sha256=capacity_receipt_hash,
            require_pass=capacity["status"] == "PASS",
        )
    output_volume = next((item for item in capacity["volumes"] if item["role"] == "production_output"), None)
    status, action = "WAITING", "WAIT"
    job_id: str | None = None
    job_state = "NOT_CREATED"
    voice_path: str | None = None
    render_path: str | None = None
    error: str | None = None
    next_action = wait_reason or "Wait for production inputs."
    if receipt is not None:
        action = "SYNTHESIZE_AND_RENDER_VIDEO_2"
        if capacity["status"] != "PASS" or capacity_receipt_hash is None:
            status = "BLOCKED"
            reasons = list(capacity.get("blocking_reasons") or [])
            if capacity_receipt_hash is None:
                reasons.append("CAP-IMMUTABLE-RECEIPT")
            error = "LOCAL_CAPACITY_PREFLIGHT_BLOCKED:" + ",".join(reasons or ["CAP-PRODUCTION-PLAN"])
            next_action = "Restore the evidenced zero-cost local capacity prerequisite; no media job was created."
        else:
            queue = TransactionalQueue(root)
            key = f"{receipt['receipt_id']}:synthesize-render-standard-v2"
            payload = {"input_receipt_id": receipt["receipt_id"], "action": action}
            existing = queue.get_by_idempotency_key(key)
            job = queue.get_verified_recovered_media_job(
                idempotency_key=key,
                operation_id=OPERATION_ID,
                channel_id=CHANNEL_ID,
                task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                payload=payload,
                original_max_attempts=3,
            )
            if job is None and existing is not None and existing["state"] == "SUCCEEDED":
                # A completed command is observed, not re-enqueued or elected by
                # the pre-effect reconciler. The exact budget above and immutable
                # authority graph below remain mandatory before checkpoint reuse.
                job = existing
            voice: dict[str, Any] | None = None
            voice_immutable: Path | None = None
            voice_preflight_error: Exception | None = None

            def exact_voice_preflight() -> tuple[dict[str, Any], Path]:
                _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=False)
                verify_visual_preflight(root, visual_preflight)
                measured = synthesize_video2_voice(
                    root,
                    created_at=timestamp,
                    capacity_receipt_path=capacity_receipt_path,
                    expected_capacity_receipt_id=capacity["receipt_id"],
                    expected_capacity_receipt_sha256=capacity_receipt_hash,
                )
                immutable = root / BASE / "audio/manifests" / f"{measured['voice_render_id']}.json"
                _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=False)
                if not immutable.is_file() or _sha(immutable) != _sha(
                    root / BASE / "audio/voice_render_manifest.json"
                ):
                    raise PermissionError("voice preflight latest/immutable manifests diverged")
                return measured, immutable

            # A brand-new command does not enter the queue until every spoken
            # take has passed the exact pinned-model timing gate.  Existing
            # legacy jobs are measured immediately before claim, so a bad slot
            # cannot consume another attempt.
            if job is None and existing is None:
                try:
                    voice, voice_immutable = exact_voice_preflight()
                    voice_path = _relative(root, voice_immutable)
                except Exception as exc:
                    voice_preflight_error = exc
            if job is None and (existing is not None or voice_preflight_error is None):
                job = queue.enqueue(
                    idempotency_key=key,
                    operation_id=OPERATION_ID,
                    channel_id=CHANNEL_ID,
                    task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                    payload=payload,
                    max_attempts=3,
                    now=current,
                )
            if job is not None:
                if job["state"] == "SUCCEEDED":
                    job = verify_completed_phase6_media_authority(
                        root, authoritative_job_id=job["job_id"], queue=queue, now=current,
                    )
                else:
                    authority = reconcile_phase6_media_authority(
                        root,
                        authoritative_job_id=job["job_id"],
                        now=current,
                        queue=queue,
                    )
                    if authority.get("executable_media_jobs") != 1:
                        raise QueueConflict(
                            "media authority did not retain exactly one executable job"
                        )
                    job = queue.get_by_idempotency_key(key)
                job_id, job_state = job["job_id"], job["state"]
            if voice_preflight_error is not None:
                error = f"{type(voice_preflight_error).__name__}: {voice_preflight_error}"
                status = "BLOCKED"
                next_action = (
                    "Recompile the exact narration/slot blueprint under the pinned voice profile; "
                    "do not truncate copy or accelerate the approved voice."
                )
                if isinstance(voice_preflight_error, ResourceWait):
                    status = "WAITING"
                    next_action = "RESOURCE_WAIT: recheck resources once after 60 seconds; preserve owner PAUSE and exact voice/quality."
            elif job is None:
                error = "VOICE_SLOT_PREFLIGHT_BLOCKED_WITHOUT_QUEUE_COMMAND"
                status = "BLOCKED"
                next_action = "Repair the voice timing contract before creating a media command."
            elif job_state == "SUCCEEDED":
                checkpoint = job.get("checkpoint") or {}
                voice_path, render_path = checkpoint.get("voice_manifest"), checkpoint.get("render_manifest")
                try:
                    observed_queue = queue.snapshot(captured_at=current)
                    capacity = _verify_completed_media_checkpoint(root, checkpoint, receipt)
                    after_queue = queue.snapshot(captured_at=current)
                    if (any(observed_queue[key] != after_queue[key] for key in ("jobs", "media_job_supersessions"))
                            or queue.get_by_idempotency_key(key) != job
                            or _sha(root / "output/operations/phase6/release/latest-production-inputs-receipt.json")
                            != _sha(root / PRODUCTION_INPUT_RECEIPTS / f"{receipt['receipt_id']}.json")):
                        raise PermissionError("completed media authority changed during checkpoint verification")
                    capacity_receipt = str(checkpoint["capacity_receipt_path"])
                    capacity_receipt_hash = str(checkpoint["capacity_receipt_sha256"])
                    output_volume = next((item for item in capacity["volumes"] if item["role"] == "production_output"), None)
                    status, next_action = "COMPLETED", checkpoint.get("next_action", "RUN_PHASE6_VIDEO2_QUALITY_GATES")
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    status, next_action = "BLOCKED", "Repair or rebuild the hash-bound media checkpoint; do not consume mutable media."
            else:
                if _job_is_due(job, current) and voice is None:
                    try:
                        voice, voice_immutable = exact_voice_preflight()
                        voice_path = _relative(root, voice_immutable)
                    except Exception as exc:
                        voice_preflight_error = exc
                if voice_preflight_error is not None:
                    error = f"{type(voice_preflight_error).__name__}: {voice_preflight_error}"
                    status = "BLOCKED"
                    next_action = (
                        "Recompile the exact narration/slot blueprint under the pinned voice profile; "
                        "the queue attempt remains unconsumed."
                    )
                    if isinstance(voice_preflight_error, ResourceWait):
                        status = "WAITING"
                        next_action = "RESOURCE_WAIT: recheck resources once after 60 seconds; no queue attempt consumed."
                    claimed = None
                elif not _job_is_due(job, current):
                    claimed = None
                    status = "RETRY_WAIT" if job_state == "RETRY_WAIT" else "WAITING"
                    next_action = "Media job is already leased or inside its bounded retry window."
                else:
                    lease_clock = (
                        (lambda: current)
                        if now is not None
                        else (lambda: datetime.now(timezone.utc))
                    )
                    worker_id = f"gestor-central-media-{os.getpid()}"
                    claim_moment = lease_clock()
                    claimed = queue.claim_job(
                        job_id,
                        worker_id=worker_id,
                        expected_task_type="EXECUTE_PHASE6_VIDEO2_MEDIA",
                        lease_seconds=MEDIA_LEASE_SECONDS,
                        now=claim_moment,
                    )
                if claimed is not None and claimed["job_id"] != job_id:
                    error = f"PHASE6_MEDIA_QUEUE_IDENTITY_MISMATCH:{claimed['job_id']}"
                    queue.fail(
                        claimed["job_id"], worker_id=claimed["lease_owner"],
                        error=error, now=claim_moment,
                    )
                    status, next_action = "ERROR", "Preserve the mismatched job and retry only through its idempotency key."
                elif claimed is not None:
                    heartbeat = MediaLeaseHeartbeat(
                        queue,
                        job_id=job_id,
                        worker_id=claimed["lease_owner"],
                        lease_seconds=MEDIA_LEASE_SECONDS,
                        clock=lease_clock,
                    )
                    try:
                        heartbeat.start()
                        residency = _verify_bound_assets(root, receipt, recheck_decode=True)
                        receipt = _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=True)
                        if voice is None or voice_immutable is None:
                            raise PermissionError("claimed media job lacks its exact pre-attempt voice proof")
                        voice_path = _relative(root, voice_immutable)
                        receipt = _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=True)
                        # Recheck after voice generation as the final barrier immediately
                        # before FFmpeg consumes any external source bytes.
                        residency = _verify_bound_assets(root, receipt, recheck_decode=True)
                        resident_output = _strict_output_path(root, receipt["receipt_id"])
                        # A completed strict mux can be finished only through its
                        # exact resource witness.  This branch never re-encodes
                        # segments or overwrites the MP4; arbitrary pre-existing
                        # outputs still fail closed in render_video2.
                        render = (
                            resume_resident_strict_mux(
                                root, created_at=timestamp,
                                voice_manifest_path=voice_immutable,
                            )
                            if resident_output.exists()
                            else render_video2(
                                root,
                                created_at=timestamp,
                                strict_inputs=True,
                                voice_manifest_path=voice_immutable,
                            )
                        )
                        heartbeat.assert_healthy()
                        render_immutable = root / BASE / "renders/manifests" / f"{render['render_id']}.json"
                        render_path = _relative(root, render_immutable)
                        receipt = _reverify_same_inputs(root, receipt["receipt_id"], recheck_decode=True)
                        residency = _verify_bound_assets(root, receipt, recheck_decode=True)
                        input_immutable = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt['receipt_id']}.json"
                        checkpoint = {
                            "visual_preflight": visual_preflight,
                            "input_receipt_id": receipt["receipt_id"],
                            "input_receipt_path": _relative(root, input_immutable),
                            "input_receipt_sha256": _sha(input_immutable),
                            "voice_manifest": voice_path,
                            "voice_manifest_sha256": _sha(voice_immutable),
                            "voice_render_id": voice["voice_render_id"],
                            "render_manifest": render_path,
                            "render_manifest_sha256": _sha(render_immutable),
                            "render_id": render["render_id"],
                            "capacity_receipt_id": capacity["receipt_id"],
                            "capacity_receipt_path": capacity_receipt,
                            "capacity_receipt_sha256": capacity_receipt_hash,
                            "asset_residency_audit_id": residency["audit_id"],
                            "asset_residency_sha256": residency["sha256"],
                            "next_action": "RUN_PHASE6_VIDEO2_QUALITY_GATES",
                        }
                        _verify_completed_media_checkpoint(root, checkpoint, receipt)
                        # The foreground owner performs one final synchronous
                        # renewal, then stops the daemon before committing.  A
                        # failed or divergent heartbeat therefore cannot race a
                        # successful queue transition.
                        heartbeat.renew_now()
                        heartbeat.stop()
                        heartbeat.assert_healthy()
                        finished = queue.succeed(
                            job_id,
                            worker_id=claimed["lease_owner"],
                            checkpoint=checkpoint,
                            now=lease_clock(),
                        )
                        job_state, status, next_action = finished["state"], "COMPLETED", "RUN_PHASE6_VIDEO2_QUALITY_GATES"
                    except Exception as exc:
                        heartbeat.stop()
                        error = f"{type(exc).__name__}: {exc}"
                        try:
                            heartbeat.assert_healthy()
                        except MediaLeaseHeartbeatError as heartbeat_exc:
                            if not isinstance(exc, MediaLeaseHeartbeatError):
                                error += (
                                    "; MediaLeaseHeartbeatError: "
                                    f"{heartbeat_exc}"
                                )
                        try:
                            failed = queue.fail(
                                job_id,
                                worker_id=claimed["lease_owner"],
                                error=error,
                                checkpoint=claimed.get("checkpoint") or {},
                                now=lease_clock(),
                            )
                        except LeaseConflict as lease_exc:
                            # Never claim, renew or finish a lease now owned by
                            # another worker.  A blocking FFmpeg invocation may
                            # already have produced local bytes, but they remain
                            # uncommitted and cannot advance downstream gates.
                            observed = queue.get_by_idempotency_key(key)
                            job_state = (
                                observed["state"] if observed is not None
                                else claimed["state"]
                            )
                            status = "BLOCKED"
                            error += (
                                "; MEDIA_LEASE_FINALIZATION_BLOCKED: "
                                f"{lease_exc}"
                            )
                            next_action = (
                                "Preserve uncommitted local media and reconcile "
                                "the exact queue owner/deadline before any retry."
                            )
                        else:
                            job_state = failed["state"]
                            status = "BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT"
                            next_action = "Correct the evidenced media failure and retry without changing rights, cost or quality thresholds."
                    finally:
                        heartbeat.stop()
                elif voice_preflight_error is None and _job_is_due(job, current):
                    status = "WAITING"
                    next_action = "The exact job was claimed concurrently; wait for its bounded lease outcome."
            queue.materialize_snapshot(captured_at=datetime.now(timezone.utc))
    value = {
        "schema_version": "1.2.0", "executor_id": "heroverse-phase6-media-executor-v1", "phase": 6,
        "status": status, "input_receipt_id": receipt.get("receipt_id") if receipt else None,
        "action": action, "job_id": job_id, "job_state": job_state,
        "voice_manifest": voice_path, "render_manifest": render_path,
        "visual_preflight": visual_preflight,
        "capacity_preflight_receipt": capacity_receipt,
        "capacity_preflight_sha256": capacity_receipt_hash,
        "capacity_status": capacity["status"],
        "capacity_observed_free_bytes": output_volume["free_bytes"] if output_volume else None,
        "capacity_required_free_bytes": capacity["required_free_bytes"],
        "capacity_headroom_bytes": output_volume["headroom_bytes"] if output_volume and capacity["required_free_bytes"] is not None else None,
        "next_action": next_action, "error": error, "publication_authorized": False,
        "technical_cost_brl": 0, "updated_at": timestamp,
    }
    _validate(root, "phase6_media_executor_runtime.schema.json", value)
    _write(root / RUNTIME, value)
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_media_executor(ROOT), ensure_ascii=False, indent=2))
