"""Reference-conditioned measurements, not assertions about unobserved pixels.

The reference is never fitted to the candidate. Metric calibration consumes
independent positive/negative controls and a disjoint holdout. Source anatomy,
physics and semantic correctness are separate from rendering fidelity; these
functions cannot certify either merely because a candidate copied its source.
All units/scopes are explicit so the quality consumer cannot borrow a scalar
measurement as approval of a different attribute.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
import time
from fractions import Fraction
from datetime import datetime
from pathlib import Path
from typing import Any

import cv2
import numpy as np


VERSION = "phase6-reference-conditioned-metrics-v1"
REQUIREMENTS = {
    "OBJECT_DEFORMATION": ("landmark_shape_error", "dimensionless", "corresponding object contours and declared projection"),
    "FACE_VARIATION": ("landmark_shape_error", "dimensionless", "face identity, corresponding landmarks and appearance tracks"),
    "HAND_DEFECT": ("landmark_shape_error", "dimensionless", "hand topology/contours plus corresponding articulated landmarks"),
    "IMPOSSIBLE_MOTION": ("trajectory_error", "pixels/second^2", "canonical object trajectories at exact presentation timestamps"),
    "UNINTENDED_CAMERA_INSTABILITY": ("trajectory_error", "pixels/second^2", "independent global camera track separated from object motion"),
    "INCOHERENT_PHYSICS": ("relation_error", "dimensionless", "canonical object relation graph, contacts and occlusion order"),
    "GHOSTING": ("temporal_mixture", "previous-frame coefficient", "current/previous/next canonical frames with full-rank temporal evidence"),
    "ARTIFICIAL_INTERPOLATION": ("temporal_mixture", "next-frame coefficient", "source frame/PTS mapping and canonical adjacent frames"),
    "COMPRESSION_ARTIFACT": ("spatial_measurements", "SSIM loss; code-value boundary excess", "matched pre-compression reference with independent codec controls"),
    "STYLE_DRIFT": ("colour_measurements", "CIE76 deltaE", "canonical intended colour/composition, semantic roles and Style Bible"),
}


class VisualMeasurementUnavailable(ValueError):
    """A variable required by the measurement is absent or unobservable."""


def read_observed_render_commands(root: Path, record_path: Path, *, expected_sha256: str,
                                  expected_output_sha256: str) -> dict[str, Any]:
    """Reopen an externally anchored *new* render's actual execution record.

    No reconstruction for cached/historical segments. This is evidence about
    commands and declared file bindings, not a complete dependency manifest,
    intrinsic source quality, or proof of interpolation absence. In particular
    copying a source's defect is not a successful visual-quality observation.
    """
    root, record_path = root.resolve(), record_path.resolve()
    directory = root / "output/production/phase6/video-002/resource-preparation"
    if record_path.parent != directory or not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_sha256):
        raise VisualMeasurementUnavailable("confined record and external execution anchor required")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_output_sha256):
        raise VisualMeasurementUnavailable("exact output anchor required")
    raw = record_path.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise VisualMeasurementUnavailable("execution record hash diverged")
    record = json.loads(raw)
    if (record.get("version") != "phase6-active-resources-v1" or record.get("entry") != "render_video2"
            or record.get("quality_approval") is not False):
        raise VisualMeasurementUnavailable("record is not an unapproved forward render observation")

    def reopen(binding, *, confined=True):
        if (not isinstance(binding, dict) or set(binding) != {"path", "sha256", "size_bytes"}
                or type(binding["size_bytes"]) is not int or binding["size_bytes"] <= 0
                or not isinstance(binding["path"], str) or not Path(binding["path"]).is_absolute()):
            raise VisualMeasurementUnavailable("incomplete observed file binding")
        path = Path(binding["path"]).resolve()
        if confined and not path.is_relative_to(root):
            raise VisualMeasurementUnavailable("observed media escaped root")
        digest, size = hashlib.sha256(), 0
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                size += len(block)
                digest.update(block)
        if size != binding["size_bytes"] or "sha256:" + digest.hexdigest() != binding["sha256"]:
            raise VisualMeasurementUnavailable("observed file bytes diverged")
        return path

    observations = record.get("observations")
    if not isinstance(observations, list) or not observations:
        raise VisualMeasurementUnavailable("missing forward observations")
    executions, output_paths = [], set()
    for row in observations:
        if not isinstance(row, dict) or row.get("status") != "ADMITTED":
            raise VisualMeasurementUnavailable("render resource admission was incomplete")
        execution = row.get("execution")
        if execution is None:
            continue
        if (row.get("stage") != "ffmpeg" or not isinstance(execution, dict)
                or execution.get("version") != "phase6-observed-ffmpeg-execution-v1"
                or execution.get("status") != "COMPLETED"
                or type(execution.get("exit_code")) is not int or execution["exit_code"] != 0
                or execution.get("quality_approval") is not False
                or execution.get("scope") != "OBSERVED_COMMAND_AND_DECLARED_FILE_BINDINGS_NOT_VISUAL_QUALITY"
                or not isinstance(execution.get("cwd"), str) or not Path(execution["cwd"]).is_absolute()
                or Path(execution.get("cwd", "")).resolve() != root):
            raise VisualMeasurementUnavailable("execution is incomplete, failed or from another root")
        argv = execution.get("argv")
        if (not isinstance(argv, list) or len(argv) < 2 or any(type(arg) is not str for arg in argv)
                or not Path(argv[0]).is_absolute() or not Path(argv[-1]).is_absolute()):
            raise VisualMeasurementUnavailable("exact observed argv missing")
        try:
            start, end = (datetime.fromisoformat(execution[k].replace("Z", "+00:00"))
                          for k in ("started_at", "finished_at"))
            if start.utcoffset() is None or end.utcoffset() is None or end < start:
                raise ValueError("invalid chronology")
        except (ValueError, KeyError, TypeError, AttributeError) as exc:
            raise VisualMeasurementUnavailable("invalid execution chronology") from exc
        executable = reopen(execution.get("executable"), confined=False)
        output = reopen(execution.get("output"))
        if Path(argv[0]).resolve() != executable or Path(argv[-1]).resolve() != output or output in output_paths:
            raise VisualMeasurementUnavailable("argv/file identity mismatch or duplicate output")
        inputs = execution.get("inputs")
        if not isinstance(inputs, list) or not inputs:
            raise VisualMeasurementUnavailable("declared execution inputs missing")
        paths = [reopen(item) for item in inputs]
        if len(set(paths)) != len(paths) or output in paths:
            raise VisualMeasurementUnavailable("ambiguous execution inputs")
        from .production_capacity import verify_observed_ffmpeg_file_inputs
        try:
            verify_observed_ffmpeg_file_inputs(root, argv, tuple(paths))
        except ValueError as exc:
            raise VisualMeasurementUnavailable(str(exc)) from exc
        for name in ("stdout", "stderr"):
            log = execution.get(name)
            if (not isinstance(log, dict) or set(log) != {"size_bytes", "sha256"}
                    or type(log["size_bytes"]) is not int or log["size_bytes"] < 0
                    or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(log["sha256"]))):
                raise VisualMeasurementUnavailable("process diagnostic digest missing")
        executions.append(execution)
        output_paths.add(output)
    if not executions or sum(e["output"]["sha256"] == expected_output_sha256 for e in executions) != 1:
        raise VisualMeasurementUnavailable("no unique forward witness for exact output; history is not inferred")
    if record_path.read_bytes() != raw:
        raise VisualMeasurementUnavailable("execution record changed during read")
    return {"status": "OBSERVED_FORWARD_COMMANDS", "record_sha256": expected_sha256,
            "output_sha256": expected_output_sha256, "executions": executions,
            "quality_approval": False, "interpolation_absence_proven": False,
            "historical_argv_inferred": False,
            "limitations": ["Declared file bindings only; not exhaustive filter/font dependencies.",
                            "Hashes at process boundaries do not prove absence of transient concurrent writes.",
                            "Cached segments have no new execution witness; require their own archived evidence.",
                            "No frame/source anatomy, codec bound, full-population or visual PASS is granted."]}


def renderer_output_sync_profile(probe: dict[str, Any], version: str) -> dict[str, Any]:
    """Exact default -r 30 rule of the installed FFmpeg source revision.

    fftools/ffmpeg_mux_init.c at 1ad97b82f3 selects VSCFR for one input
    stream with zero -itsoffset; otherwise CFR. ffmpeg_filter.c preserves
    the first origin for VSCFR, but pads it for CFR. This is current canonical
    command semantics, not reconstructed historical argv or candidate fitting.
    No copyts/itsoffset/explicit fps_mode is allowed in this narrow profile.
    """
    if not version.startswith("ffmpeg version N-120725-g1ad97b82f3-20250813 "):
        raise VisualMeasurementUnavailable("renderer output synchronization build not qualified")
    streams = probe.get("streams")
    if (not isinstance(streams, list) or not 1 <= len(streams) <= 2
            or sum(s.get("codec_type") == "video" for s in streams) != 1
            or any(s.get("codec_type") not in {"video", "audio"} for s in streams)):
        raise VisualMeasurementUnavailable("renderer input stream population outside qualified profile")
    cfr = len(streams) > 1
    return {"version":"phase6-ffmpeg-auto-output-sync-v1", "ffmpeg_revision":"1ad97b82f3",
            "input_stream_count":len(streams), "mode":"CFR" if cfr else "VSCFR",
            "filters":["fps=fps=30:start_time=0:round=near"] if cfr else ["setpts=PTS-STARTPTS"],
            "command_scope":{"output_rate":30,"input_ts_offset":0,"copyts":False,"explicit_fps_mode":False},
            "candidate_fitted":False,"historical_argv_witness":False}


def observe_renderer_output_sync(source: Path, *, ffmpeg: str, ffprobe: str) -> dict[str, Any]:
    """Read the input stream population and bind both actual executables."""
    def run(argv):
        p = subprocess.run(argv,capture_output=True,text=True,encoding="utf-8",errors="strict",timeout=20,
                           creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if p.returncode:
            raise VisualMeasurementUnavailable("output sync probe failed: "+p.stderr[-1000:])
        return p.stdout
    bindings = [{"path":str(Path(p).resolve()),"sha256":"sha256:"+hashlib.sha256(Path(p).read_bytes()).hexdigest()}
                for p in (ffmpeg,ffprobe)]
    version = run([ffmpeg,"-version"]).splitlines()[0]
    probe = json.loads(run([ffprobe,"-v","error","-show_entries","stream=index,codec_type","-of","json",str(source.resolve())]))
    profile = renderer_output_sync_profile(probe,version)
    if any("sha256:"+hashlib.sha256(Path(b["path"]).read_bytes()).hexdigest()!=b["sha256"] for b in bindings):
        raise PermissionError("output sync executable changed during probe")
    return {"profile":profile,"source_stream_probe":probe,"ffmpeg_version":version,"executable_bindings":bindings}


def read_transfer_statistics(stats: str, stderr: str, *, frame_count: int,
                             fps: Fraction, observe_reference_origin: bool = False) -> dict[str, Any]:
    """Require both observed clocks and every FFmpeg SSIM frame, not just a mean.

    The instrument uses FFmpeg's existing YUV SSIM implementation, NOT the
    Gaussian RGB metric below. Printed decimals have six-place resolution;
    a later tolerance consumer must account for that, not round a near miss.
    """
    if type(frame_count) is not int or frame_count <= 0 or fps <= 0:
        raise ValueError("positive exact population and FPS required")
    rows = []
    for line in stats.splitlines():
        fields = re.findall(r"\b(n|Y|U|V|All):(-?(?:\d+(?:\.\d+)?))", line)
        record = dict(fields)
        if len(fields) != 5 or set(record) != {"n", "Y", "U", "V", "All"}:
            raise VisualMeasurementUnavailable("incomplete/duplicate SSIM frame statistic")
        if record["n"] != str(len(rows) + 1):
            raise VisualMeasurementUnavailable("SSIM frame order/identity differs")
        row = {k: float(record[k]) for k in ("Y", "U", "V", "All")}
        if any(not math.isfinite(v) or not -1 <= v <= 1 for v in row.values()):
            raise VisualMeasurementUnavailable("invalid SSIM measurement")
        rows.append({"frame_index": len(rows), **row})
    if len(rows) != frame_count:
        raise VisualMeasurementUnavailable("SSIM coverage differs from exact take population")
    clocks = {}
    for name in ("reference", "candidate"):
        prefix = rf"\[showinfo@{name}\s+@[^\]]+\]"
        times = re.findall(prefix + r"\s+config in time_base:\s*(\d+)/(\d+)", stderr)
        frames = re.findall(prefix + r"\s+n:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:", stderr)
        if len(times) != 1 or len(frames) != frame_count:
            raise VisualMeasurementUnavailable(name + " clock/coverage is incomplete")
        time_base = Fraction(int(times[0][0]), int(times[0][1]))
        # Native seek+fps can start at a nonzero tick; the production encoder
        # rebases that first displayed frame, rather than inventing preceding
        # image data. Observe and retain this origin only in the explicit
        # reference-domain contract. Candidate time remains strictly zero.
        origin = int(frames[0][1]) if name == "reference" and observe_reference_origin else 0
        if origin < 0:
            raise VisualMeasurementUnavailable("negative reference clock origin")
        for index, (observed_index, pts) in enumerate(frames):
            if int(observed_index) != index or (int(pts) - origin) * time_base != Fraction(index, 1) / fps:
                raise VisualMeasurementUnavailable(name + " observed frame/PTS differs")
        clocks[name] = {"time_base": str(time_base), "frames": frame_count,
                        "first_pts": int(frames[0][1]), "last_pts": int(frames[-1][1]),
                        "display_origin_pts": origin, "origin_seconds": str(origin * time_base)}
    return {"method": "ffmpeg-yuv420p-ssim-all-frames-v2" if observe_reference_origin else "ffmpeg-yuv420p-ssim-all-frames-v1", "frames": rows,
            "clocks": clocks, "frame_count": frame_count,
            "mean_all": math.fsum(r["All"] for r in rows) / frame_count,
            "minimum_all": min(r["All"] for r in rows),
            "minimum_luma": min(r["Y"] for r in rows),
            "printed_decimal_resolution": 0.000001,
            "semantic_quality_proved": False}


def measure_ffmpeg_transfer(reference: Path, candidate: Path, *, ffmpeg: str,
                            directory: Path, frame_count: int, fps: Fraction,
                            reference_seek_ms: Fraction = Fraction(0),
                            candidate_start_frame: int = 0,
                            reference_filters: tuple[str, ...] = (),
                            observe_reference_origin: bool = False) -> dict[str, Any]:
    """Decode a whole bounded take to null; do not encode or change channel media.

    Candidate frames retain their observed clock (no FPS conversion). The
    reference uses only externally bound production filters. Both are measured
    in the native decoder/filter domain, avoiding PNG colour round trips.
    Seeks follow the existing renderer's millisecond contract. These are new
    observations, not historical argv or native source-PTS witnesses.
    """
    if (type(frame_count) is not int or not 0 < frame_count <= 1800 or fps <= 0
            or type(candidate_start_frame) is not int or candidate_start_frame < 0
            or reference_seek_ms < 0 or reference_seek_ms.denominator != 1
            or not isinstance(reference_filters, tuple)
            or any(not isinstance(f, str) or not f for f in reference_filters)):
        raise ValueError("bounded exact take/seek/filter contract required")
    candidate_seek_ms = Fraction(candidate_start_frame * 1000, 1) / fps
    if candidate_seek_ms.denominator != 1:
        raise VisualMeasurementUnavailable("candidate start is not millisecond exact")
    if reference.resolve() == candidate.resolve():
        raise PermissionError("candidate cannot be its own reference")
    if directory.exists():
        raise FileExistsError("transfer evidence directory already exists")
    def digest(path):
        sha = hashlib.sha256()
        with Path(path).open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                sha.update(chunk)
        return {"path": str(Path(path).resolve()), "sha256": "sha256:" + sha.hexdigest(),
                "size_bytes": Path(path).stat().st_size}
    inputs = [digest(p) for p in (reference, candidate, Path(ffmpeg))]
    directory.mkdir(parents=True, exist_ok=False)
    def seek(value):
        return f"{value.numerator // 1000}.{value.numerator % 1000:03d}"
    ref_graph = ",".join((*reference_filters, "format=yuv420p", f"trim=end_frame={frame_count}",
                          "showinfo@reference=checksum=0", "setpts=PTS-STARTPTS"))
    out_graph = f"format=yuv420p,trim=end_frame={frame_count},showinfo@candidate=checksum=0,setpts=PTS-STARTPTS"
    graph = (f"[0:v:0]{ref_graph}[ref];[1:v:0]{out_graph}[out];"
             "[ref][out]ssim=stats_file=frame-ssim.log:shortest=1:repeatlast=0:eof_action=endall[result]")
    command = [str(Path(ffmpeg).resolve()), "-nostdin", "-hide_banner", "-nostats", "-loglevel", "info",
               "-threads", "1", "-ss", seek(reference_seek_ms), "-i", str(reference.resolve()),
               "-threads", "1", "-ss", seek(candidate_seek_ms), "-i", str(candidate.resolve()),
               "-filter_complex_threads", "1", "-filter_complex", graph, "-map", "[result]",
               "-an", "-sn", "-dn", "-threads", "1", "-frames:v", str(frame_count),
               "-fps_mode", "passthrough", "-f", "null", "-"]
    with (directory / "command.json").open("x", encoding="utf-8") as stream:
        json.dump({"argv": command, "cwd": str(directory.resolve()), "inputs": inputs}, stream, indent=2)
    started = time.monotonic()
    with (directory / "stdout.log").open("xb") as stdout, (directory / "stderr.log").open("xb") as stderr:
        try:
            process = subprocess.run(command, cwd=directory, stdout=stdout, stderr=stderr, timeout=120,
                                     shell=False, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            outcome = {"exit_code": process.returncode, "timed_out": False}
        except subprocess.TimeoutExpired:
            outcome = {"exit_code": None, "timed_out": True}
    outcome["elapsed_seconds"] = time.monotonic() - started
    with (directory / "process-result.json").open("x", encoding="utf-8") as stream:
        json.dump(outcome, stream, indent=2)
    if outcome["timed_out"] or outcome["exit_code"] != 0:
        raise VisualMeasurementUnavailable("bounded transfer process failed; see preserved process-result/stderr")
    measured = read_transfer_statistics((directory / "frame-ssim.log").read_text(),
        (directory / "stderr.log").read_text(encoding="utf-8", errors="replace"), frame_count=frame_count, fps=fps,
        observe_reference_origin=observe_reference_origin)
    if [digest(p) for p in (reference, candidate, Path(ffmpeg))] != inputs:
        raise PermissionError("transfer inputs changed during measurement")
    return {"version": "phase6-native-full-take-transfer-v2" if observe_reference_origin else "phase6-native-full-take-transfer-v1", "inputs": inputs,
            "measurement": measured, "process": outcome,
            "artifacts": [digest(directory / n) for n in ("command.json", "stdout.log", "stderr.log", "frame-ssim.log", "process-result.json")],
            "reference_seek_ms": str(reference_seek_ms), "candidate_seek_ms": str(candidate_seek_ms),
            "candidate_start_frame": candidate_start_frame, "historical_command_witness": False,
            "native_absolute_source_pts_observed": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}


def decode_source_clock_frame(source: Path, *, ffmpeg: str, start_ms: Fraction,
                              frame_index: int, fps: Fraction,
                              composition_filters: tuple[str, ...] | None = None) -> tuple[np.ndarray, dict[str, Any]]:
    """Observe a canonical source on the production FPS clock, before styling.

    A variable-rate source index is NOT a render index. Reuse FFmpeg's actual
    seek + fps resampling, observe its integer output PTS/time base, and bind
    pixels to that observation. This is a NEW reference reconstruction, never
    a fabricated historical render-command witness or native source PTS.
    One bounded owned subprocess, one frame, no source or channel media writes.
    """
    from .phase6_av_publicity_v2 import LIMITS, ppm

    if start_ms < 0 or fps <= 0 or type(frame_index) is not int or frame_index < 0:
        raise ValueError("nonnegative source start/index and positive FPS required")
    # The existing renderer seeks at millisecond precision. Do not silently
    # round a reference that claims a more precise clock.
    if start_ms.denominator != 1:
        raise VisualMeasurementUnavailable("source start is not millisecond exact")
    seek = f"{start_ms.numerator // 1000}.{start_ms.numerator % 1000:03d}"
    rate = f"{fps.numerator}/{fps.denominator}"
    if composition_filters is not None and (not isinstance(composition_filters, tuple)
            or not composition_filters or any(not isinstance(f, str) or not f for f in composition_filters)):
        raise ValueError("nonempty immutable composition filter sequence required")
    # Styling must operate in the source decoder's colour domain. Applying it
    # to an intermediate RGB PNG changes colour/rounding before grading. Keep
    # native input -> declared filters -> RGB extraction in ONE filter graph.
    graph = ",".join(composition_filters) if composition_filters is not None else f"fps={rate}"
    command = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "info", "-threads", "1",
               "-ss", seek, "-i", str(source), "-map", "0:v:0", "-an", "-sn", "-dn",
               "-filter_threads", "1", "-vf", f"{graph},select=eq(n\\,{frame_index}),showinfo",
               "-frames:v", "1", "-fps_mode", "passthrough", "-fs", str(LIMITS["maximum_frame_bytes"]),
               "-pix_fmt", "rgb24", "-c:v", "ppm", "-f", "image2pipe", "-"]
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=30, shell=False,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    stderr = result.stderr.decode("utf-8", "backslashreplace")
    if result.returncode:
        raise VisualMeasurementUnavailable("source-clock decoder failed: " + stderr[-2000:])
    clocks = re.findall(r"config in time_base:\s*(\d+)/(\d+)", stderr)
    stamps = re.findall(r"\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:", stderr)
    if len(clocks) != 1 or len(stamps) != 1 or int(stamps[0][0]) != 0:
        raise VisualMeasurementUnavailable("source-clock decoder lacks unique observed PTS")
    clock = Fraction(int(clocks[0][0]), int(clocks[0][1]))
    pts = int(stamps[0][1])
    if clock != 1 / fps or pts * clock != Fraction(frame_index, 1) / fps:
        raise VisualMeasurementUnavailable("source-clock observed PTS differs from declared mapping")
    width, height, pixels = ppm(result.stdout)
    rgb = np.frombuffer(pixels, dtype=np.uint8).reshape(height, width, 3)
    return rgb, {"method": "source-seek-fps-select-observed-pts-v1", "command": command,
                 "composition_domain": "native-decoder-before-rgb" if composition_filters is not None else "ungraded-source",
                 "exit_code": result.returncode, "stderr": stderr, "source_seek_ms": str(start_ms),
                 "resampled_frame_index": frame_index, "observed_pts": pts,
                 "observed_time_base": str(clock), "resampled_pts_ms": str(pts * clock * 1000),
                 "mapped_source_time_ms": str(start_ms + pts * clock * 1000),
                 "native_source_pts_observed": False, "historical_command_witness": False,
                 "decoded_rgb_sha256": "sha256:" + hashlib.sha256(pixels).hexdigest(),
                 "width": width, "height": height, "elapsed_seconds": time.monotonic() - started}


def indexed_frame_clock(index: int, fps: Fraction) -> tuple[float, float]:
    """Shared producer/reader clock, not a tolerance supplied by evidence."""
    if type(index) is not int or index < 0 or isinstance(fps, bool):
        raise VisualMeasurementUnavailable('nonnegative integer frame and positive rational FPS required')
    try:
        rate = Fraction(fps)
        if rate <= 0:
            raise ValueError('nonpositive FPS')
        expected_ms = float(Fraction(index * 1000, 1) / rate)
        alternative_ms = float(index) / float(rate) * 1000
        if not math.isfinite(expected_ms) or not math.isfinite(alternative_ms):
            raise ValueError('unrepresentable clock')
        return expected_ms, max(math.ulp(expected_ms), math.ulp(alternative_ms)) * 8
    except (ValueError, TypeError, OverflowError, ZeroDivisionError) as exc:
        raise VisualMeasurementUnavailable('finite representable frame clock required') from exc


def extract_indexed_frames(video: Path, indices: list[int], directory: Path, *, fps: Fraction, timeout_seconds: float = 120,
                           frame_observer=None, retain_pixels: bool = True, require_eof: bool = False) -> dict[int, dict[str, Any]]:
    """Serial, bounded decode by frame index; persist exact measured pixels/PTS.

    OpenCV's existing FFmpeg backend is reused with one decoder thread. No seek
    rounding, shell command, external download or production video is generated.
    Timestamp tolerance is floating-point representation error (ULP), NOT a
    relaxed frame-alignment tolerance. A decoder lacking PTS fails closed.
    Optional serial observation retains hashes instead of PNGs; an observer
    cannot alter the measured buffer. Complete-population callers additionally
    require a zero-based contiguous selection and observed end of stream.
    """
    if not indices or indices != sorted(set(indices)) or any(type(i) is not int or i < 0 for i in indices) or fps <= 0:
        raise ValueError("sorted distinct nonnegative frame indices and positive FPS required")
    if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
        raise ValueError("finite positive decode deadline required")
    if (type(retain_pixels) is not bool or type(require_eof) is not bool
            or frame_observer is not None and not callable(frame_observer)
            or not retain_pixels and frame_observer is None
            or require_eof and indices != list(range(indices[-1]+1))):
        raise ValueError('hash-only observation needs a callback; complete coverage needs consecutive frames from zero')
    if directory.exists():
        raise FileExistsError("frame evidence directory already exists")
    directory.mkdir(parents=True)
    capture = cv2.VideoCapture(str(video), cv2.CAP_FFMPEG, [cv2.CAP_PROP_N_THREADS, 1])
    deadline = time.monotonic() + timeout_seconds
    result = {}
    try:
        if not capture.isOpened():
            raise VisualMeasurementUnavailable("video decoder did not open")
        first = indices[0]
        if first and not capture.set(cv2.CAP_PROP_POS_FRAMES, first):
            raise VisualMeasurementUnavailable("decoder refused indexed seek")
        if capture.get(cv2.CAP_PROP_POS_FRAMES) != first:
            raise VisualMeasurementUnavailable("decoder seek position differs from requested frame")
        wanted = set(indices)
        for index in range(first, indices[-1] + 1):
            if time.monotonic() >= deadline:
                raise TimeoutError(f"bounded visual decode deadline exceeded before frame {index}")
            ok, bgr = capture.read()
            if not ok:
                raise VisualMeasurementUnavailable(f"decode ended before frame {index}")
            if capture.get(cv2.CAP_PROP_POS_FRAMES) != index + 1:
                raise VisualMeasurementUnavailable("decoder returned a different frame index")
            if index not in wanted:
                continue
            observed_ms = capture.get(cv2.CAP_PROP_POS_MSEC)
            expected_ms, rounding = indexed_frame_clock(index, fps)
            if not math.isfinite(observed_ms) or abs(observed_ms - expected_ms) > rounding:
                raise VisualMeasurementUnavailable(f"decoded PTS differs at frame {index}: {observed_ms} != {expected_ms}")
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            row = {"frame_index": index, "pts_ms": observed_ms, "expected_pts_ms": expected_ms,
                   "verified_seek_frame": first, "decoded_frames_to_observation": index - first + 1,
                   "pts_rounding_tolerance_ms": rounding,
                   "decoded_rgb_sha256": "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest(),
                   "width": int(rgb.shape[1]), "height": int(rgb.shape[0])}
            # OpenCV 5's narrow-path imwrite fails on Windows Unicode paths.
            # Encode unchanged pixels in memory, then use Python's native Unicode
            # filesystem API with exclusive creation; never rewrite prior evidence.
            if retain_pixels:
                path = directory / f"frame-{index:08d}.png"
                encoded_ok, encoded = cv2.imencode(".png", bgr)
                if not encoded_ok:
                    raise OSError("PNG evidence encode failed")
                with path.open("xb") as stream:
                    stream.write(encoded.tobytes())
                row.update(path=str(path.resolve()),sha256="sha256:"+hashlib.sha256(path.read_bytes()).hexdigest())
            else:
                row['pixel_storage']='HASH_ONLY_TARGET_REPLAY'
            if frame_observer is not None:
                observation=frame_observer(dict(row),rgb)
                if 'sha256:'+hashlib.sha256(rgb.tobytes()).hexdigest()!=row['decoded_rgb_sha256']:
                    raise PermissionError('frame observer altered measured pixels')
                if time.monotonic() >= deadline:
                    raise TimeoutError('bounded visual observation deadline exceeded')
                # Require a detached, finite JSON observation, not caller-owned state.
                row['observation']=json.loads(json.dumps(observation,allow_nan=False))
            result[index]=row
        if require_eof and capture.read()[0]:
            raise VisualMeasurementUnavailable('decoder contains frames beyond declared complete population')
    finally:
        capture.release()
    return result


def read_sample_clock_statistics(stderr: str, indices: list[int], fps: Fraction) -> list[dict[str, Any]]:
    """Read the selected frames' real PTS; selection arithmetic is not evidence."""
    if (not indices or indices != sorted(set(indices)) or any(type(i) is not int or i < 0 for i in indices)
            or not isinstance(fps,Fraction) or fps <= 0):
        raise VisualMeasurementUnavailable("distinct sorted integer indices and positive rational FPS required")
    clocks = re.findall(r"config in time_base:\s*(\d+)/(\d+)",stderr)
    stamps = re.findall(r"\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:",stderr)
    if len(clocks) != 1 or len(stamps) != len(indices):
        raise VisualMeasurementUnavailable("sample decoder lacks a unique complete observed clock")
    try:
        time_base = Fraction(int(clocks[0][0]),int(clocks[0][1]))
    except ZeroDivisionError as exc:
        raise VisualMeasurementUnavailable("sample clock denominator is zero") from exc
    if time_base <= 0:
        raise VisualMeasurementUnavailable("sample clock must be positive")
    rows = []
    for ordinal,(index,(n,pts)) in enumerate(zip(indices,stamps)):
        if int(n) != ordinal or int(pts)*time_base != Fraction(index,1)/fps:
            raise VisualMeasurementUnavailable("sample observed PTS/order differs from selected frame")
        rows.append({"frame_index":index,"observed_pts":int(pts),"observed_time_base":str(time_base),
                     "observed_pts_ms":str(int(pts)*time_base*1000)})
    return rows


def verify_existing_ffmpeg_sample_clocks(video: Path, samples: list[dict[str, Any]], *,
                                        fps: Fraction, width: int, height: int,
                                        ffmpeg: str, directory: Path) -> dict[str, Any]:
    """One serial sparse decode authenticates old PNGs against actual frame PTS.

    Requested half-frame timestamps propose the first not-earlier index, but
    only observed PTS AND byte-identical decoded RGB can confirm that proposal.
    Never relabel a mismatched old PNG. FFmpeg is used to keep its colour domain;
    OpenCV's different conversion is not substituted. No channel encode or OCR.
    """
    import tempfile
    from PIL import Image
    if (not isinstance(fps,Fraction) or fps <= 0 or type(width) is not int or type(height) is not int
            or not 0 < width <= 4096 or not 0 < height <= 2160 or not 1 <= len(samples) <= 100):
        raise VisualMeasurementUnavailable("bounded native sample population/canvas required")
    if directory.exists():
        raise FileExistsError("sample-clock evidence already exists")
    captured, indices, bound_samples = {}, [], []
    def bind(path):
        path = Path(path).resolve()
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):
                digest.update(block)
        value = {"path":str(path),"sha256":"sha256:"+digest.hexdigest(),"size_bytes":path.stat().st_size}
        captured[path] = value
        return value
    for row in samples:
        stamp = row["requested_ms"]
        if type(stamp) not in (int,float) or not math.isfinite(stamp) or stamp < 0:
            raise VisualMeasurementUnavailable("finite nonnegative requested timestamp required")
        position = Fraction(str(stamp))*fps/1000
        index = math.ceil(position)
        if index > 108000: # existing bounded one-hour profile, not a quality threshold
            raise VisualMeasurementUnavailable("sample clock exceeds the bounded capture horizon")
        bound = bind(row["path"])
        if bound["sha256"] != row["sha256"] or bound["size_bytes"] != row["size_bytes"]:
            raise PermissionError("sample PNG anchor differs before decode")
        indices.append(index)
        bound_samples.append({**bound,"requested_ms":stamp,"proposed_index":index})
    if indices != sorted(set(indices)):
        raise VisualMeasurementUnavailable("sample observations must resolve to distinct ordered frames")
    inputs = [bind(video),bind(Path(ffmpeg))]
    directory.mkdir(parents=True,exist_ok=False)
    def save(name,value):
        with (directory/name).open('x',encoding='utf-8') as stream:
            json.dump(value,stream,indent=2,allow_nan=False)
    graph = "select="+'+'.join(f"eq(n\\,{i})" for i in indices)+",showinfo=checksum=0"
    argv = [str(Path(ffmpeg).resolve()),"-nostdin","-hide_banner","-nostats","-loglevel","info",
            "-threads","1","-i",str(video.resolve()),"-map","0:v:0","-an","-sn","-dn",
            "-filter_threads","1","-vf",graph,"-frames:v",str(len(indices)),
            "-fps_mode","passthrough","-pix_fmt","rgb24","-c:v","rawvideo","-threads","1","-f","rawvideo","-"]
    save('command.json',{"argv":argv,"cwd":str(directory.resolve()),"inputs":inputs,"samples":bound_samples,
                         "selection_rule":"propose first frame not earlier than requested time; require real PTS and exact stored RGB"})
    started = time.monotonic()
    # Owned temporary binary only. Each successful frame is already preserved
    # by an authenticated PNG; a mismatch is retained separately, never hidden.
    with tempfile.TemporaryFile(dir=directory) as raw, (directory/'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.run(argv,stdout=raw,stderr=stderr,cwd=directory,timeout=180,shell=False,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            outcome = {"exit_code":process.returncode,"timed_out":False}
        except subprocess.TimeoutExpired:
            outcome = {"exit_code":None,"timed_out":True}
        size = raw.tell()
        outcome.update(elapsed_seconds=time.monotonic()-started,stdout_bytes=size)
        save('process-result.json',outcome)
        if outcome['timed_out'] or outcome['exit_code'] != 0 or size != width*height*3*len(indices):
            # Preserve partial data on actual process/canvas failure.
            raw.seek(0)
            with (directory/'partial.rgb').open('xb') as partial:
                for block in iter(lambda:raw.read(1024*1024),b''):
                    partial.write(block)
            raise VisualMeasurementUnavailable("sample decode failed or population/canvas differs; evidence retained")
        clocks = read_sample_clock_statistics((directory/'stderr.log').read_text(encoding='utf-8',errors='strict'),indices,fps)
        raw.seek(0)
        rows, output_digest = [], hashlib.sha256()
        for sample,clock in zip(bound_samples,clocks):
            frame_bytes = raw.read(width*height*3)
            output_digest.update(frame_bytes)
            with Image.open(sample['path']) as image:
                stored = np.asarray(image.convert('RGB'))
            actual = np.frombuffer(frame_bytes,np.uint8).reshape(height,width,3)
            matches = bool(stored.shape == actual.shape and np.array_equal(stored,actual))
            row = {**sample,**clock,"rgb_identical":matches,"observed_rgb_sha256":"sha256:"+hashlib.sha256(frame_bytes).hexdigest()}
            if not matches:
                mismatch = directory/f"mismatch-{clock['frame_index']:08d}.png"
                with mismatch.open('xb') as stream:
                    Image.fromarray(actual).save(stream,format='PNG')
                row['mismatch_evidence'] = bind(mismatch)
            rows.append(row)
        result = {"version":"phase6-existing-ffmpeg-frame-clocks-v1",
                  "status":"OBSERVED_EXACT_FRAME_BINDINGS" if all(r['rgb_identical'] for r in rows) else "FRAME_PIXELS_DIVERGED",
                  "observations":rows,"inputs":inputs,"process":outcome,
                  "stdout_sha256":"sha256:"+output_digest.hexdigest(),"new_video_decodes":1,
                  "new_channel_renders":0,"new_ocr_inferences":0,"quality_authorized":False}
    # Stream hashes, not retaining the original video/binary in RAM.
    for path,before in list(captured.items()):
        if bind(path) != before:
            raise PermissionError("sample-clock input changed during observation")
    save('measurement.json',result)
    if result['status'] != 'OBSERVED_EXACT_FRAME_BINDINGS':
        raise VisualMeasurementUnavailable("stored sample does not match its proposed frame; do not relabel it")
    return result


def inventory() -> list[dict[str, str]]:
    return [{"criterion": key, "method": row[0], "unit": row[1], "required_reference": row[2],
             "version": VERSION, "scope": "REFERENCE_CONDITIONED_METRIC_NOT_INTRINSIC_SOURCE_APPROVAL"}
            for key, row in REQUIREMENTS.items()]


def layout_landmark_visibility(points: Any, layout: dict[str, Any]) -> dict[str, Any]:
    """Measure planned overlays at observed positions, not invented visibility.

    Filled-box alpha is exact declared composition. Text bounds are a
    conservative *potential* occlusion region, not a claim of glyph ink at
    every pixel. No occluded landmark can be discarded to approve anatomy.
    Unsupported compositing primitives fail closed for this instrument.
    """
    positions = _array(points, 2)
    if positions.shape[1] != 2:
        raise VisualMeasurementUnavailable("2-D landmark positions required")
    width, height = layout["canvas"]["width"], layout["canvas"]["height"]
    inside = ((positions >= [0, 0]) & (positions < [width, height])).all(axis=1)
    transparency = np.ones(len(positions), dtype=np.float64)
    regions = []
    for decoration in layout["decorations"]:
        match = re.fullmatch(r"drawbox=x=(\d+):y=(\d+):w=(\d+):h=(\d+):color=0x[0-9A-Fa-f]{6}@([0-9.]+):t=fill", decoration)
        if not match:
            raise VisualMeasurementUnavailable("unsupported layout visibility primitive")
        x, y, w, h = map(int, match.groups()[:4])
        alpha = float(match[5])
        if not math.isfinite(alpha) or not 0 <= alpha <= 1 or min(w, h) <= 0:
            raise VisualMeasurementUnavailable("invalid layout opacity/extent")
        covered = inside & (positions[:, 0] >= x) & (positions[:, 0] < x + w) & (positions[:, 1] >= y) & (positions[:, 1] < y + h)
        transparency[covered] *= 1 - alpha
        regions.append({"primitive": decoration, "covered_indices": np.flatnonzero(covered).tolist()})
    text = []
    for overlay in layout["overlays"]:
        b = overlay["bounds"]
        if b["right"] <= b["left"] or b["bottom"] <= b["top"]:
            raise VisualMeasurementUnavailable("invalid text bounds")
        covered = inside & (positions[:, 0] >= b["left"]) & (positions[:, 0] < b["right"]) & (positions[:, 1] >= b["top"]) & (positions[:, 1] < b["bottom"])
        text.append({"role": overlay["role"], "potentially_occluded_indices": np.flatnonzero(covered).tolist()})
    return {"method": "declared-layout-transmission-at-landmarks-v1", "inside_frame": inside.tolist(),
            "declared_source_transmission": [float(value) if within else None for within, value in zip(inside, transparency)],
            "decoration_regions": regions, "text_bound_regions": text, "text_bounds_are_ink": False,
            "quality_authorized": False}


def _array(value: Any, ndim: int) -> np.ndarray:
    result = np.asarray(value, dtype=np.float64)
    if result.ndim != ndim or not result.size or not np.isfinite(result).all():
        raise VisualMeasurementUnavailable("finite nonempty measurement array required")
    return result


def _frames(reference: Any, candidate: Any) -> tuple[np.ndarray, np.ndarray]:
    ref, out = _array(reference, 3), _array(candidate, 3)
    if ref.shape != out.shape or ref.shape[2] != 3 or min(ref.shape[:2]) < 16:
        raise VisualMeasurementUnavailable("matched RGB frames at least 16x16 required")
    if min(ref.min(), out.min()) < 0 or max(ref.max(), out.max()) > 255:
        raise VisualMeasurementUnavailable("RGB code values outside [0,255]")
    return ref, out


def _visible_mask(value: Any) -> np.ndarray:
    """0 background, 1 visible foreground, 2 unobserved; never infer hidden anatomy."""
    mask = np.asarray(value)
    if (mask.dtype != np.uint8 or mask.ndim != 2 or min(mask.shape) < 3
            or mask.size > 8_388_608 or not np.isin(mask, [0, 1, 2]).all()):
        raise VisualMeasurementUnavailable("bounded uint8 label mask (0/1/2), at least 3x3 required")
    return np.ascontiguousarray(mask)


def _supported_mask_boundary(mask: np.ndarray) -> tuple[np.ndarray, int]:
    foreground = (mask == 1).astype(np.uint8)
    kernel = np.ones((3, 3), np.uint8)
    interior = cv2.erode(foreground, kernel, borderType=cv2.BORDER_CONSTANT, borderValue=0)
    boundary = (foreground != 0) & (interior == 0)
    # Do not count the artificial cut against unknown pixels or outside frame
    # as a measured object contour. Every 8-neighbour must be observed.
    support = cv2.erode((mask != 2).astype(np.uint8), kernel,
                       borderType=cv2.BORDER_CONSTANT, borderValue=0) != 0
    valid = boundary & support
    return valid, int(np.count_nonzero(boundary & ~support))


def compare_sparse_face_points(labels: Any, reference: dict[str, Any]) -> dict[str, Any]:
    """Compare a proposal to independent points, never fill a dense oracle.

    The caller authenticates the published receipt/image. Continuous point
    positions touching different raster labels are explicitly unknown, not
    resolved by rounding or an invented probability/quality threshold.
    """
    mask=_visible_mask(labels)
    if (not isinstance(reference,dict) or reference.get('version')!='phase6-published-sparse-face-points-v1'
            or any(reference.get(k) is not False for k in ('dense_visibility_proved','landmark_visibility_proved',
                                                          'identity_proved','quality_authorized'))
            or not isinstance(reference.get('points'),list) or not reference['points']):
        raise VisualMeasurementUnavailable('typed non-authorizing sparse face reference required')
    h,w=mask.shape
    rows=[];seen=set();counts={'MATCH':0,'CONTRADICTION':0,'REFERENCE_UNSURE':0,'RASTER_SUPPORT_UNKNOWN':0}
    declared={'yes':0,'no':0,'unsure':0}
    for index,point in enumerate(reference['points']):
        norm=np.asarray(point['xy_normalized'],np.float64)
        xy=np.asarray(point['xy_pixels'],np.float64)
        expected=point['face_membership']
        annotation=point['annotation'];label=annotation['EstimatedYesNo']
        if (norm.shape!=(2,) or xy.shape!=(2,) or not np.isfinite(norm).all() or not np.isfinite(xy).all()
                or (norm<0).any() or (norm>1).any() or not np.array_equal(xy,norm*np.array([w-1,h-1]))
                or label not in declared or annotation.get('Label')!='/m/0dzct'
                or annotation.get('Source') not in ('ih','cs')
                or expected is not {'yes':True,'no':False,'unsure':None}.get(label)
                or tuple(norm) in seen):
            raise VisualMeasurementUnavailable('sparse point identity, coordinates or label differs')
        seen.add(tuple(norm));declared[label]+=1
        x0,y0=np.floor(xy).astype(int);x1,y1=np.ceil(xy).astype(int)
        positions=sorted({(int(x),int(y)) for x in (x0,x1) for y in (y0,y1)})
        values={int(mask[y,x]) for x,y in positions}
        observed=bool(next(iter(values))) if len(values)==1 and 2 not in values else None
        status=('REFERENCE_UNSURE' if expected is None else 'RASTER_SUPPORT_UNKNOWN' if observed is None else
                'MATCH' if observed==expected else 'CONTRADICTION')
        counts[status]+=1
        rows.append({'point_index':index,'xy_pixels':xy.tolist(),'source_csv_line':point['csv_line'],
            'expected_membership':expected,'observed_membership':observed,'support_xy':[list(p) for p in positions],
            'support_labels':sorted(values),'status':status})
    if reference.get('counts')!=declared:
        raise VisualMeasurementUnavailable('sparse point population count differs')
    return {'method':'independent-sparse-face-membership-v1','rows':rows,'counts':counts,
        'status':'REFERENCE_CONTRADICTION' if counts['CONTRADICTION'] else 'SPARSE_POINTS_MEASURED_NOT_QUALIFICATION',
        'known_reference_points':declared['yes']+declared['no'],'total_reference_points':len(rows),
        'mask_sha256':'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
        'raster_rule':'all floor/ceil support labels must agree; label 2 is unobserved',
        'tolerance':None,'dense_visibility_proved':False,'identity_proved':False,
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}


def visible_mask_geometry(labels: Any) -> dict[str, Any]:
    """Raster facts, not hand/finger counts or an occlusion-order assertion.

    Foreground uses 8-connectivity and complement 4-connectivity (dual digital
    topology). Unknown pixels are included in the complement so an unobserved
    gap cannot be closed artificially to invent a hole. No denoising, largest-
    component selection, resizing or fitting to a candidate is performed.
    """
    mask = _visible_mask(labels)
    foreground = (mask == 1).astype(np.uint8)
    count, components, stats, _ = cv2.connectedComponentsWithStats(foreground, connectivity=8)
    support_boundary, censored = _supported_mask_boundary(mask)
    complement_count, complement = cv2.connectedComponents(1-foreground, connectivity=4)
    if max(count, complement_count) > 4097:
        raise VisualMeasurementUnavailable('mask topology exceeds bounded component workload; no subset accepted')
    exterior = set(np.concatenate((complement[0], complement[-1], complement[:, 0], complement[:, -1])).tolist())
    unknown_components = set(complement[mask == 2].tolist())
    areas = np.bincount(complement.ravel(), minlength=complement_count)
    holes = [int(areas[i]) for i in range(1, complement_count)
             if i not in exterior and i not in unknown_components]
    border = np.zeros(mask.shape, bool)
    border[[0, -1], :] = True
    border[:, [0, -1]] = True
    unknown_neighbours = cv2.dilate((mask == 2).astype(np.uint8), np.ones((3, 3), np.uint8)) != 0
    at_border, at_unknown = set(components[border].tolist()), set(components[unknown_neighbours].tolist())
    rows = []
    for i in range(1, count):
        rows.append({'component': i, 'area_px': int(stats[i, cv2.CC_STAT_AREA]),
                     'bbox_xywh': stats[i, :4].astype(int).tolist(),
                     'touches_frame': i in at_border, 'touches_unknown': i in at_unknown})
    return {'method': 'observed-mask-digital-geometry-v1', 'size_wh': [mask.shape[1], mask.shape[0]],
            'mask_sha256': 'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
            'foreground_px': int(foreground.sum()), 'background_px': int(np.count_nonzero(mask == 0)),
            'unknown_px': int(np.count_nonzero(mask == 2)), 'visible_foreground_components': rows,
            'closed_observed_hole_areas_px': holes,
            'supported_boundary_px': int(support_boundary.sum()), 'censored_boundary_px': censored,
            'complete_raster_observation': bool(not np.any(mask == 2)),
            'complete_object_visible': None, 'finger_count': None, 'occlusion_order': None,
            'quality_authorized': False,
            'scope': 'VISIBLE_RASTER_GEOMETRY_NOT_INTRINSIC_ANATOMY_OR_OCCLUSION_PROOF'}


def compare_visible_masks(reference: Any, candidate: Any) -> dict[str, Any]:
    """Compare pre-registered visible labels; never align away a local defect.

    Inputs must already share an independently established image coordinate
    system. Unknown support is fully counted, never silently excluded from a
    claim of complete coverage. Distances are Euclidean pixels on supported
    raster contours, not an acceptance tolerance or anatomical interpretation.
    """
    ref, out = _visible_mask(reference), _visible_mask(candidate)
    if ref.shape != out.shape:
        raise VisualMeasurementUnavailable('registered masks must share dimensions')
    known = (ref != 2) & (out != 2)
    a, b = (ref == 1) & known, (out == 1) & known
    intersection, union = int(np.count_nonzero(a & b)), int(np.count_nonzero(a | b))
    if not known.any() or union == 0:
        raise VisualMeasurementUnavailable('no jointly observed foreground; absence is not agreement')
    # Shared support applies to both boundary computations. The other mask's
    # unknowns cannot create a spurious large distance or vanish from coverage.
    x, y = ref.copy(), out.copy()
    x[~known] = y[~known] = 2
    boundary_a, censored_a = _supported_mask_boundary(x)
    boundary_b, censored_b = _supported_mask_boundary(y)
    distances = None
    if boundary_a.any() and boundary_b.any():
        to_b = cv2.distanceTransform((~boundary_b).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)[boundary_a]
        to_a = cv2.distanceTransform((~boundary_a).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)[boundary_b]
        distances = {'hausdorff_px': float(max(to_b.max(), to_a.max())),
                     'symmetric_mean_px': float((to_b.sum(dtype=np.float64)+to_a.sum(dtype=np.float64))/(len(to_a)+len(to_b))),
                     'reference_to_candidate_max_px': float(to_b.max()),
                     'candidate_to_reference_max_px': float(to_a.max())}
    return {'method': 'registered-visible-mask-comparison-v1',
            'status': 'COMPLETE_RASTER_MEASUREMENT' if known.all() else 'PARTIAL_RASTER_MEASUREMENT',
            'jointly_observed_px': int(known.sum()), 'unobserved_px': int(np.count_nonzero(~known)),
            'intersection_px': intersection, 'union_px': union, 'iou_observed': intersection/union,
            'missing_foreground_px': int(np.count_nonzero(a & ~b)),
            'extra_foreground_px': int(np.count_nonzero(b & ~a)),
            'boundary_distances': distances, 'censored_boundary_px': [censored_a, censored_b],
            'reference': visible_mask_geometry(ref), 'candidate': visible_mask_geometry(out),
            'tolerance': None, 'quality_authorized': False, 'render_authorized': False,
            'publication_authorized': False,
            'scope': 'REGISTERED_MASK_FIDELITY_NOT_INTRINSIC_ANATOMY_OR_SEGMENTER_QUALIFICATION'}


def visible_mask_error_support(reference: Any, candidate: Any) -> dict[str, Any]:
    """Locate known label errors relative to the observed candidate contour.

    This is an empirical error measurement, NOT an uncertainty guarantee or a
    quality tolerance. Unknown reference pixels remain unobserved. A closest
    contour censored by the canvas or an unknown neighbourhood cannot establish
    a distance to the true boundary. No smoothing, resizing or best-component
    selection is permitted here.
    """
    ref, out = _visible_mask(reference), _visible_mask(candidate)
    if ref.shape != out.shape:
        raise VisualMeasurementUnavailable('registered error masks must share dimensions')
    known = (ref != 2) & (out != 2)
    shared = out.copy()
    shared[~known] = 2
    valid, _ = _supported_mask_boundary(shared)
    foreground = (shared == 1).astype(np.uint8)
    interior = cv2.erode(foreground, np.ones((3,3), np.uint8),
        borderType=cv2.BORDER_CONSTANT, borderValue=0)
    raw_boundary = (foreground != 0) & (interior == 0)
    censored = raw_boundary & ~valid
    distance = (cv2.distanceTransform((~valid).astype(np.uint8), cv2.DIST_L2,
        cv2.DIST_MASK_PRECISE) if valid.any() else None)
    observed = known.copy() if distance is not None else np.zeros(ref.shape, bool)
    if censored.any() and distance is not None:
        to_censored = cv2.distanceTransform((~censored).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
        observed &= distance < to_censored  # a tie cannot favour the measured contour
    result = {}
    for label, errors in (('extra_foreground', known & (out == 1) & (ref == 0)),
                           ('missing_foreground', known & (out == 0) & (ref == 1))):
        measured = errors & observed
        values = distance[measured] if distance is not None else np.empty(0)
        maximum = float(values.max()) if values.size else None
        yx = np.argwhere(measured & (distance == maximum)) if values.size else np.empty((0,2), dtype=int)
        result[label] = {'error_pixels': int(errors.sum()), 'distance_observed_pixels': int(measured.sum()),
            'distance_unobserved_pixels': int(np.count_nonzero(errors & ~observed)),
            'maximum_distance_px': maximum,
            'mean_distance_px': float(values.mean(dtype=np.float64)) if values.size else None,
            'first_maximum_xy': yx[0,::-1].tolist() if len(yx) else None}
    return {'method':'registered-label-error-contour-support-v1', 'errors':result,
        'jointly_observed_pixels':int(known.sum()), 'unobserved_label_pixels':int(np.count_nonzero(~known)),
        'candidate_supported_boundary_pixels':int(valid.sum()), 'candidate_censored_boundary_pixels':int(censored.sum()),
        'reference_mask_sha256':'sha256:'+hashlib.sha256(ref.tobytes()).hexdigest(),
        'candidate_mask_sha256':'sha256:'+hashlib.sha256(out.tobytes()).hexdigest(),
        'distance_rule':'Euclidean pixels to candidate foreground contour; censored-nearest/tie is unobserved',
        'tolerance':None, 'project_domain_calibrated':False, 'identity_proved':False,
        'quality_authorized':False, 'render_authorized':False, 'publication_authorized':False}


def read_visible_mask_pair(root: Path, reference_path: Path, candidate_path: Path, *,
                           expected_reference_sha256: str, expected_candidate_sha256: str,
                           include_error_support: bool = False) -> dict[str, Any]:
    """Public bytes-bound measurement of explicit lossless 0/1/2 label PNGs.

    Does not read/write video, queue, models or receipts. A caller cannot pass
    a precomputed PASS. Both files are rechecked after real metrics; outputs
    remain measurements requiring semantic registration and qualification.
    """
    if type(include_error_support) is not bool:
        raise VisualMeasurementUnavailable('explicit boolean error-support mode required')
    root = root.resolve()
    bindings, buffers, masks = [], [], []
    for value, expected in ((reference_path, expected_reference_sha256),
                            (candidate_path, expected_candidate_sha256)):
        path = (root / value).resolve()
        if not path.is_relative_to(root) or not re.fullmatch(r'sha256:[0-9a-f]{64}', expected):
            raise VisualMeasurementUnavailable('confined mask and exact external anchor required')
        if not path.is_file() or not 1 <= path.stat().st_size <= 16*1024*1024:
            raise VisualMeasurementUnavailable('mask file missing or outside bounded workload')
        raw = path.read_bytes()
        if len(raw) > 16*1024*1024 or 'sha256:'+hashlib.sha256(raw).hexdigest() != expected:
            raise VisualMeasurementUnavailable('mask bytes differ from external anchor')
        if raw[:8] != b'\x89PNG\r\n\x1a\n' or len(raw) < 29 or raw[12:16] != b'IHDR':
            raise VisualMeasurementUnavailable('lossless PNG label bytes required')
        width, height = int.from_bytes(raw[16:20], 'big'), int.from_bytes(raw[20:24], 'big')
        if min(width, height) < 3 or width*height > 8_388_608 or raw[24:26] != b'\x08\x00':
            raise VisualMeasurementUnavailable('bounded 8-bit grayscale mask required before decoding')
        decoded = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_UNCHANGED)
        if decoded is None or decoded.shape != (height, width):
            raise VisualMeasurementUnavailable('mask decoder returned no complete raster')
        masks.append(_visible_mask(decoded))
        buffers.append(raw)
        bindings.append({'path': str(path.relative_to(root)), 'sha256': expected, 'size_bytes': len(raw)})
    result = compare_visible_masks(*masks)
    if include_error_support:
        result['error_support'] = visible_mask_error_support(*masks)
    for row, raw in zip(bindings, buffers):
        if (root / row['path']).read_bytes() != raw:
            raise VisualMeasurementUnavailable('mask changed during measurement')
    return {**result, 'bindings': bindings, 'reader': 'anchored-visible-mask-pair-v1'}


def landmark_shape_error(reference: Any, candidate: Any) -> dict[str, Any]:
    """Remove translation, rotation and uniform framing scale, not local warp.

    Correspondence/order must come from the independent tracker. A reflected
    pose is not silently accepted as a rotation. This metric alone does not
    identify a face/hand or prove anatomy; its consumer must establish that scope.
    """
    ref, out = _array(reference, 2), _array(candidate, 2)
    if ref.shape != out.shape or ref.shape[1] != 2 or len(ref) < 3:
        raise VisualMeasurementUnavailable("at least three corresponding 2-D landmarks required")
    ref, out = ref - ref.mean(axis=0), out - out.mean(axis=0)
    if np.linalg.matrix_rank(ref) < 2 or np.linalg.matrix_rank(out) < 2:
        raise VisualMeasurementUnavailable("landmarks do not constrain planar shape")
    ref /= np.linalg.norm(ref)
    out /= np.linalg.norm(out)
    u, _, vt = np.linalg.svd(out.T @ ref)
    orientation = np.eye(2)
    orientation[1, 1] = np.sign(np.linalg.det(u @ vt))
    aligned = out @ u @ orientation @ vt
    distances = np.linalg.norm(aligned - ref, axis=1)
    return {"method": "orientation-preserving-procrustes", "rms": float(np.sqrt(np.mean(distances ** 2))),
            "maximum": float(distances.max()), "landmark_count": len(ref), "unit": "dimensionless"}


def track_reference_points(reference: Any, candidate: Any, points: Any) -> dict[str, Any]:
    """Forward/backward pixel transport at independently projected positions.

    This measures displacement, not anatomical validity. OpenCV's documented
    LK defaults define the estimator's search/support, NOT a quality tolerance.
    Missing texture/out-of-frame positions remain explicit unobserved rows;
    no averaging can drop them and claim complete coverage. Backtracking is a
    reported error, not an invented acceptance cutoff.
    """
    ref, out = _frames(reference, candidate)
    original = _array(points, 2)
    if original.shape[1] != 2:
        raise VisualMeasurementUnavailable("2-D projected points required")
    valid = ((original >= [0, 0]) & (original < [ref.shape[1], ref.shape[0]])).all(axis=1)
    rows = [{"point_index": i, "reference_xy": p.tolist(), "status": "OUTSIDE_FRAME",
             "observed_xy": None, "displacement_px": None, "forward_backward_error_px": None}
            for i, p in enumerate(original)]
    settings = {"winSize": (21, 21), "maxLevel": 3,
                "criteria": (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 30, .01),
                "flags": 0, "minEigThreshold": 1e-4}
    # A 21x21 window plus interpolation needs 11 px of real support. At level
    # L this is 11*2**L native pixels. Reflected border padding isn't observed
    # image content: choose the largest level whose support exists per point.
    margin = np.minimum(original, [ref.shape[1] - 1, ref.shape[0] - 1] - original).min(axis=1)
    supported = valid & (margin >= 11)
    levels = np.full(len(original), -1, dtype=int)
    levels[supported] = np.minimum(3, np.floor(np.log2(margin[supported] / 11))).astype(int)
    for identity in np.flatnonzero(valid & ~supported):
        rows[identity]["status"] = "UNOBSERVABLE_WINDOW_SUPPORT"
    a = cv2.cvtColor(ref.astype(np.uint8), cv2.COLOR_RGB2GRAY)
    b = cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_RGB2GRAY)
    for level in sorted(set(levels[supported].tolist())):
        ids = np.flatnonzero(levels == level)
        actual_settings = {**settings, "maxLevel": level}
        p = original[ids].astype(np.float32).reshape(-1, 1, 2)
        forward, status, error = cv2.calcOpticalFlowPyrLK(a, b, p, None, **actual_settings)
        if forward is None or status is None or error is None:
            raise VisualMeasurementUnavailable("optical-flow instrument returned no observation")
        observed_xy = forward.reshape(-1, 2)
        observed_margin = np.minimum(observed_xy, [ref.shape[1] - 1, ref.shape[0] - 1] - observed_xy).min(axis=1)
        valid_forward = (status.ravel() == 1) & np.isfinite(observed_xy).all(axis=1) & (observed_margin >= 11 * 2 ** level)
        backwards = np.full_like(p, np.nan)
        backward_status = np.zeros(len(ids), dtype=np.uint8)
        if valid_forward.any():
            back, flag, _ = cv2.calcOpticalFlowPyrLK(b, a, forward[valid_forward], None, **actual_settings)
            if back is not None and flag is not None:
                backwards[valid_forward] = back
                backward_status[valid_forward] = flag.ravel()
        for position, identity in enumerate(ids):
            row = rows[identity]
            row["maximum_pyramid_level"] = level
            row["status"] = "UNOBSERVABLE_TEXTURE_OR_TRACK"
            if not valid_forward[position] or backward_status[position] != 1 or not np.isfinite(backwards[position]).all() or not math.isfinite(float(error[position, 0])):
                continue
            observed = forward[position, 0].astype(np.float64)
            if not ((observed >= [0, 0]) & (observed < [ref.shape[1], ref.shape[0]])).all():
                row["status"] = "TRACK_LEFT_FRAME"
                continue
            row.update(status="PIXEL_TRACK_OBSERVED", observed_xy=observed.tolist(),
                       displacement_px=float(np.linalg.norm(observed - original[identity])),
                       forward_backward_error_px=float(np.linalg.norm(backwards[position, 0] - original[identity])),
                       patch_l1_code_values=float(error[position, 0]))
    return {"method": "reference-conditioned-pyramidal-lk-forward-backward-v1", "settings": settings,
            "rows": rows, "requested_points": len(original),
            "observed_points": sum(row["status"] == "PIXEL_TRACK_OBSERVED" for row in rows),
            "tolerance": None, "quality_authorized": False,
            "limitation": "Pixel transport and observability only; estimator defaults are not quality acceptance thresholds."}


def declared_source_motion_support(layout: dict[str, Any]) -> tuple[np.ndarray, dict[str, Any]]:
    """Conservative declared-source support, not a background/camera label.

    Reuse the layout visibility contract in bounded row strips. Text bounding
    rectangles are potential ink, not all ink. Any declared attenuation is
    excluded, rather than inventing an acceptable transparency threshold.
    The 102-pixel halo covers the existing LK estimator: eleven pixels at
    pyramid level three plus the 5-tap pyrDown support (2*(1+2+4)). This is
    an instrument support radius, not a motion-quality tolerance.
    """
    width, height = layout['canvas']['width'], layout['canvas']['height']
    if (type(width) is not int or type(height) is not int
            or min(width, height) < 32 or max(width, height) > 8192):
        raise VisualMeasurementUnavailable('invalid declared motion canvas')
    visible = np.zeros((height, width), np.uint8)
    for start in range(0, height, 16):
        ys, xs = np.mgrid[start:min(start + 16, height), :width]
        points = np.column_stack((xs.ravel(), ys.ravel()))
        value = layout_landmark_visibility(points, layout)
        allowed = np.asarray(value['declared_source_transmission']) == 1
        for region in value['text_bound_regions']:
            allowed[region['potentially_occluded_indices']] = False
        visible[start:start + len(ys)] = allowed.reshape(xs.shape).astype(np.uint8)
    radius = 11 * 2**3 + 2 * (1 + 2 + 4)
    support = cv2.erode(visible, np.ones((2*radius+1, 2*radius+1), np.uint8),
                        borderType=cv2.BORDER_CONSTANT, borderValue=0)
    return support, {'method': 'declared-source-lk-support-v1',
        'canvas_pixels': width*height, 'unattenuated_nontext_pixels': int(visible.sum()),
        'supported_centre_pixels': int(support.sum()), 'support_radius_px': radius,
        'text_bounds_are_ink': False, 'background_identity_proved': False,
        'historical_command_witness': False, 'quality_authorized': False}


def reference_motion_transfer(reference_frames: Any, candidate_frames: Any,
                              timestamps_seconds: Any, *, source_layout: dict[str, Any] | None = None) -> dict[str, Any]:
    """Measure observed trajectories; do not assume a stationary reference.

    Features are selected on the reference alone, before seeing the candidate.
    The existing forward/backward LK instrument supplies all correspondences.
    Every requested feature and every failure is retained. Corner selection and
    LK defaults are estimator settings, NOT defect/acceptance tolerances.
    A feature is not automatically background, an anatomical part or a rigid
    object; without that independent semantic assignment there is no global
    camera/anatomy/physics verdict. Partial tracks cannot prove absence of error.
    """
    refs, outs = np.asarray(reference_frames), np.asarray(candidate_frames)
    times = _array(timestamps_seconds, 1)
    if (refs.dtype != np.uint8 or outs.dtype != np.uint8 or refs.ndim != 4
            or refs.shape != outs.shape or refs.shape[-1] != 3
            or not 3 <= len(refs) <= 30 or len(times) != len(refs)
            or min(refs.shape[1:3]) < 32 or (np.diff(times) <= 0).any()):
        raise VisualMeasurementUnavailable("3..30 matched RGB uint8 frames and strictly ordered PTS required")
    # One native LK window requires eleven observed pixels on all sides.
    mask = np.zeros(refs.shape[1:3], np.uint8)
    mask[11:-11, 11:-11] = 255
    source_support, support_evidence = None, None
    if source_layout is not None:
        source_support, support_evidence = declared_source_motion_support(source_layout)
        if source_support.shape != mask.shape:
            raise VisualMeasurementUnavailable('declared source layout/frame canvas differs')
        mask &= source_support * 255
    settings = {"maxCorners": 32, "qualityLevel": .01, "minDistance": 22, "blockSize": 3}
    corners = cv2.goodFeaturesToTrack(cv2.cvtColor(refs[0], cv2.COLOR_RGB2GRAY), mask=mask, **settings)
    rows = []
    if corners is not None:
        positions = corners.reshape(-1, 2).astype(np.float64)
        reference_tracks = [track_reference_points(refs[0], frame, positions) for frame in refs]
        candidate_tracks = [track_reference_points(refs[0], frame, positions) for frame in outs]
        for i, point in enumerate(positions):
            a, b = ([v["rows"][i] for v in collection] for collection in (reference_tracks, candidate_tracks))
            observed = all(v["status"] == "PIXEL_TRACK_OBSERVED" for v in a + b)
            row = {"point_index": i, "reference_origin_xy": point.tolist(),
                   "status": "TRAJECTORY_OBSERVED" if observed else "INCOMPLETE_TRACK",
                   "reference_track": a, "candidate_track": b, "measurement": None}
            if source_support is not None:
                # Check both endpoints at every observed timestamp. Missing or
                # crossing tracks stay in the population; never drop a failure.
                supports = []
                for entry in a + b:
                    xy = entry['observed_xy']
                    if xy is None:
                        supports.append(None)
                        continue
                    low, high = np.floor(xy).astype(int), np.ceil(xy).astype(int)
                    valid = ((low >= 0).all() and high[0] < source_support.shape[1]
                             and high[1] < source_support.shape[0])
                    supports.append(bool(valid and source_support[low[1]:high[1]+1, low[0]:high[0]+1].all()))
                row['declared_support_at_observations'] = supports
                if observed and not all(supports):
                    observed = False
                    row['status'] = 'TRACK_LEFT_DECLARED_SOURCE_SUPPORT'
            if observed:
                xy_ref, xy_out = (np.asarray([v["observed_xy"] for v in values]) for values in (a, b))
                row["measurement"] = {**trajectory_error(times, xy_ref, xy_out),
                    "maximum_position_error_px": float(np.linalg.norm(xy_out-xy_ref, axis=1).max())}
            rows.append(row)
    measured = [r["measurement"] for r in rows if r["measurement"] is not None]
    result = {"method": "reference-selected-pixel-trajectories-v1", "feature_settings": settings,
            "timestamps_seconds": times.tolist(), "rows": rows,
            "selected_points": len(rows), "observed_points": len(measured),
            "status": "TRAJECTORIES_MEASURED" if measured else "UNOBSERVABLE_TRACK_POPULATION",
            "sampled_point_coverage_complete": bool(rows) and len(measured) == len(rows),
            "maximum_acceleration_error_px_s2": max((v["maximum_acceleration_error_px_s2"] for v in measured), default=None),
            "tolerance": None, "full_frame_coverage": False,
            "semantic_point_roles": "UNAVAILABLE", "intrinsic_source_motion_approved": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    if source_support is not None:
        result.update(method='declared-source-selected-pixel-trajectories-v1',
                      source_support=support_evidence,
                      source_support_sha256='sha256:'+hashlib.sha256(source_support.tobytes()).hexdigest())
    return result


def trajectory_error(timestamps_seconds: Any, reference: Any, candidate: Any) -> dict[str, Any]:
    """Compare velocity/acceleration to canonical motion, never zero motion.

    Intentional pan/time-lapse is not shake merely because it moves quickly.
    Observations must belong to one continuous take, with identical PTS mapping.
    """
    times = _array(timestamps_seconds, 1)
    ref, out = _array(reference, 2), _array(candidate, 2)
    if ref.shape != out.shape or len(ref) != len(times) or len(times) < 3:
        raise VisualMeasurementUnavailable("three aligned trajectory observations required")
    dt = np.diff(times)
    if (dt <= 0).any():
        raise VisualMeasurementUnavailable("presentation timestamps must strictly increase")
    ref_velocity, out_velocity = np.diff(ref, axis=0) / dt[:, None], np.diff(out, axis=0) / dt[:, None]
    mid_dt = (dt[:-1] + dt[1:]) / 2
    acceleration = (np.diff(out_velocity, axis=0) - np.diff(ref_velocity, axis=0)) / mid_dt[:, None]
    return {"method": "reference-conditioned-temporal-derivatives", "samples": len(times),
            "maximum_velocity_error_px_s": float(np.linalg.norm(out_velocity - ref_velocity, axis=1).max()),
            "maximum_acceleration_error_px_s2": float(np.linalg.norm(acceleration, axis=1).max())}


def relation_error(reference: Any, candidate: Any, edges: Any) -> dict[str, Any]:
    """Measure declared pairwise relations; not a general physical world model."""
    ref, out = _array(reference, 2), _array(candidate, 2)
    if ref.shape != out.shape or ref.shape[1] != 2:
        raise VisualMeasurementUnavailable("matched 2-D object positions required")
    pairs = np.asarray(edges)
    if pairs.ndim != 2 or pairs.shape[1] != 2 or not len(pairs) or not np.issubdtype(pairs.dtype, np.integer):
        raise VisualMeasurementUnavailable("explicit integer relation edges required")
    if (pairs < 0).any() or (pairs >= len(ref)).any() or (pairs[:, 0] == pairs[:, 1]).any():
        raise VisualMeasurementUnavailable("invalid relation endpoint")
    lengths = np.linalg.norm(ref[pairs[:, 0]] - ref[pairs[:, 1]], axis=1)
    if (lengths == 0).any():
        raise VisualMeasurementUnavailable("contact needs an explicit contact model, not division by zero")
    observed = np.linalg.norm(out[pairs[:, 0]] - out[pairs[:, 1]], axis=1)
    error = np.abs(observed / lengths - 1)
    return {"method": "canonical-relation-distance-residual", "edge_count": len(pairs),
            "maximum_relative_error": float(error.max()), "rms_relative_error": float(np.sqrt(np.mean(error ** 2)))}


def temporal_mixture(previous: Any, reference: Any, following: Any, candidate: Any) -> dict[str, Any]:
    """Quantify adjacent-frame contributions; don't infer interpolation from FPS.

    Rank-deficient/static references are explicitly unobservable, not PASS.
    A least-squares coefficient is not itself a defect verdict: calibration and
    intended temporal composition/frame mapping remain mandatory.
    """
    ref, out = _frames(reference, candidate)
    prev, _ = _frames(previous, reference)
    nxt, _ = _frames(following, reference)
    design = np.column_stack(((prev - ref).ravel(), (nxt - ref).ravel()))
    target = (out - ref).ravel()
    coefficients, _, rank, singular = np.linalg.lstsq(design, target, rcond=None)
    if rank != 2:
        raise VisualMeasurementUnavailable("adjacent frames cannot independently identify temporal contributions")
    fitted = design @ coefficients
    return {"method": "two-sided-canonical-temporal-mixture", "previous_coefficient": float(coefficients[0]),
            "next_coefficient": float(coefficients[1]), "rank": int(rank),
            "condition_number": float(singular[0] / singular[-1]),
            "unmixed_rms_code_values": float(np.sqrt(np.mean(target ** 2))),
            "fitted_rms_code_values": float(np.sqrt(np.mean((target - fitted) ** 2)))}


def temporal_noise_sensitivity(previous: Any, reference: Any, following: Any,
                               candidate: Any) -> dict[str, Any]:
    """Measure identifiability, without interpreting a coefficient as a defect.

    The 2-column least-squares model is identical to temporal_mixture. For an
    unknown additive error of RMS epsilon code values, Cauchy-Schwarz gives
    |delta coefficient_i| <= epsilon * sqrt(N * inv(X.T X)[i,i]). This is an
    exact worst-case sensitivity of the linear instrument, not a confidence
    interval, a codec calibration or a tolerance fitted to the candidate.
    A nonzero estimate cannot exclude zero unless an INDEPENDENT error bound
    is strictly below the reported break-even value. Equality includes zero.

    Accumulate the 2x2 normal matrix in rows: don't allocate an image-sized
    design matrix, pseudoinverse or fitted RGB image merely to report bounds.
    The historical observer and its receipts remain unchanged.
    """
    ref, out = _frames(reference, candidate)
    prev, _ = _frames(previous, reference)
    nxt, _ = _frames(following, reference)
    gram = np.zeros((2, 2), dtype=np.float64)
    target = np.zeros(2, dtype=np.float64)
    for y in range(ref.shape[0]):
        a, b, c = prev[y] - ref[y], nxt[y] - ref[y], out[y] - ref[y]
        gram += [[np.sum(a*a), np.sum(a*b)], [np.sum(a*b), np.sum(b*b)]]
        target += [np.sum(a*c), np.sum(b*c)]
    eigenvalues = np.linalg.eigvalsh(gram)
    # This is numerical rank at float64 precision, not a visual threshold.
    if eigenvalues[-1] <= 0 or eigenvalues[0] <= np.finfo(np.float64).eps * eigenvalues[-1] * 2:
        raise VisualMeasurementUnavailable("temporal noise bounds require independently observable adjacent frames")
    inverse = np.linalg.inv(gram)
    coefficients = np.linalg.solve(gram, target)
    sensitivity = np.sqrt(ref.size * np.diag(inverse))
    return {"method": "temporal-linear-error-propagation-v1", "compared_code_values": int(ref.size),
            "reference_rms_previous": float(np.sqrt(gram[0, 0] / ref.size)),
            "reference_rms_next": float(np.sqrt(gram[1, 1] / ref.size)),
            "condition_number": float(np.sqrt(eigenvalues[-1] / eigenvalues[0])),
            "rows": [{"component": name, "coefficient": float(coefficients[i]),
                      "coefficient_error_per_rms_code_value": float(sensitivity[i]),
                      "independent_rms_error_must_be_strictly_below": float(abs(coefficients[i]) / sensitivity[i])}
                     for i, name in enumerate(("previous", "next"))],
            "independent_error_bound": None, "calibration_status": "INDEPENDENT_CODEC_ERROR_BOUND_REQUIRED",
            "scope": "LINEAR_INSTRUMENT_IDENTIFIABILITY_NOT_TEMPORAL_DEFECT_APPROVAL",
            "quality_authorized": False, "publication_authorized": False}


def temporal_noise_intervals(previous: Any, reference: Any, following: Any,
                             candidate: Any, *, independent_rms_error_bound: float) -> dict[str, Any]:
    """Conditional deterministic intervals, not confidence or quality scores.

    Recompute the instrument from pixels: never accept a caller's PASS or
    precomputed sensitivity. The caller must separately authenticate and justify
    the bound for the exact domain/codec; this numerical function cannot do so.
    Inclusion of zero means unidentifiable, NOT absence of a temporal defect.
    Exclusion means a component under this linear model, NOT semantic intent.
    No empirical training maximum is silently promoted to a universal bound.
    """
    if (isinstance(independent_rms_error_bound, bool) or
        not isinstance(independent_rms_error_bound, (int, float)) or
        not math.isfinite(independent_rms_error_bound) or independent_rms_error_bound < 0):
        raise VisualMeasurementUnavailable('finite nonnegative independent RMS bound required')
    observed = temporal_noise_sensitivity(previous, reference, following, candidate)
    rows = []
    for row in observed['rows']:
        radius = independent_rms_error_bound * row['coefficient_error_per_rms_code_value']
        low, high = row['coefficient'] - radius, row['coefficient'] + radius
        if not all(math.isfinite(value) for value in (radius, low, high)):
            raise VisualMeasurementUnavailable('temporal error interval overflow')
        rows.append({**row, 'lower': low, 'upper': high, 'radius': radius,
                     'zero_included': low <= 0 <= high,
                     'identification': 'INCONCLUSIVE_WITHIN_ERROR_BOUND' if low <= 0 <= high
                                       else 'NONZERO_UNDER_CONDITIONAL_LINEAR_MODEL'})
    return {'method': 'conditional-temporal-error-intervals-v1',
            'independent_rms_error_bound': float(independent_rms_error_bound),
            'rows': rows, 'reference_condition_number': observed['condition_number'],
            'bound_authenticated': False,
            'scope': 'NUMERIC_PROPAGATION_ONLY_REQUIRES_INDEPENDENT_DOMAIN_BOUND',
            'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}


def spatial_measurements(reference: Any, candidate: Any) -> dict[str, Any]:
    """Local structural similarity and coding-grid residual, not byte equality.

    SSIM constants are the algorithm's dynamic-range stabilizers (8-bit input),
    not acceptance thresholds. No global average can hide a damaged small area:
    a local minimum and worst boundary are returned separately.
    """
    ref, out = _frames(reference, candidate)
    ref = cv2.cvtColor(ref.astype(np.float32), cv2.COLOR_RGB2GRAY).astype(np.float64)
    out = cv2.cvtColor(out.astype(np.float32), cv2.COLOR_RGB2GRAY).astype(np.float64)
    blur = lambda x: cv2.GaussianBlur(x, (11, 11), 1.5, borderType=cv2.BORDER_REFLECT_101)
    mr, mo = blur(ref), blur(out)
    vr, vo = np.maximum(0, blur(ref * ref) - mr * mr), np.maximum(0, blur(out * out) - mo * mo)
    covariance = blur(ref * out) - mr * mo
    c1, c2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
    score = ((2 * mr * mo + c1) * (2 * covariance + c2)) / ((mr * mr + mo * mo + c1) * (vr + vo + c2))
    score = np.clip(score[5:-5, 5:-5], -1, 1)
    residual = out - ref
    boundaries = []
    for axis in (0, 1):
        difference = np.abs(np.diff(residual, axis=axis))
        ids = np.arange(7, difference.shape[axis], 8)
        if len(ids): boundaries.append(np.take(difference, ids, axis=axis).ravel())
    boundary = np.concatenate(boundaries)
    return {"method": "local-ssim-and-reference-grid-residual", "mean_ssim": float(score.mean()),
            "minimum_local_ssim": float(score.min()), "maximum_grid_residual_code_values": float(boundary.max()),
            "mean_grid_residual_code_values": float(boundary.mean()), "compared_pixels": int(ref.size)}


def colour_measurements(reference: Any, candidate: Any) -> dict[str, Any]:
    ref, out = _frames(reference, candidate)
    lab_r = cv2.cvtColor(ref.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
    lab_o = cv2.cvtColor(out.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
    error = np.linalg.norm(lab_o - lab_r, axis=2)
    return {"method": "CIE76-reference-conditioned-colour", "mean_delta_e": float(error.mean()),
            "maximum_delta_e": float(error.max()), "compared_pixels": int(error.size),
            "limitation": "Colour fidelity alone is not semantic style or composition approval."}


def locked_palette_patches(rgb: Any, layout: dict[str, Any], bible: dict[str, Any], *,
                           coverage: str = "centres") -> dict[str, Any]:
    """Observe fixed centre patches of opaque recipe decorations, not all style.

    Geometry comes only from the canonical layout; colours/tolerance only from
    the Bible. A 2x2 patch centred in each rectangle is a deterministic sample,
    NOT a claim about its borders, every pixel, typography or natural footage.
    The opt-in opaque_rectangles scope observes every pixel of an uncovered
    declared rectangle, including its borders. Those borders are DIAGNOSTIC:
    a flat RGB swatch is not a qualified reference for post-draw chroma sampling.
    It does not cover natural source objects, text, the whole frame or time.
    Never relocate a sample towards
    convenient colours. Transparent/covered regions remain explicitly unknown.
    """
    if coverage not in ("centres", "opaque_rectangles"):
        raise VisualMeasurementUnavailable("unknown palette coverage contract")
    rgb = np.asarray(rgb)
    canvas = layout.get("canvas", {})
    if (rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3
            or rgb.shape[:2] != (canvas.get("height"), canvas.get("width"))):
        raise VisualMeasurementUnavailable("palette requires the declared native RGB canvas")
    palette = bible["palette"]
    roles = palette["role_map"]
    tolerance = palette["tolerance_delta_e"]
    if (type(tolerance) not in (float, int) or not math.isfinite(tolerance) or tolerance <= 0
            or tolerance != bible["divergence_policy"]["thresholds"]["palette_delta_e"]):
        raise PermissionError("palette tolerance must be finite and agree with the Bible policy")
    if (not roles or any(not re.fullmatch(r"#[0-9A-Fa-f]{6}", value) for value in roles.values())
            or set(roles.values()) != set(palette["locked_hex"])):
        raise PermissionError("palette role population differs from locked colours")
    pattern = r"drawbox=x=(\d+):y=(\d+):w=(\d+):h=(\d+):color=0x([0-9A-Fa-f]{6})@(0(?:\.\d+)?|1(?:\.0+)?):t=fill"
    boxes = []
    for expression in layout["decorations"]:
        match = re.fullmatch(pattern, expression)
        if match is None:
            raise VisualMeasurementUnavailable("palette decoration outside explicit rectangle contract")
        x, y, w, h = map(int, match.groups()[:4])
        if w < 2 or h < 2 or x+w > rgb.shape[1] or y+h > rgb.shape[0]:
            raise VisualMeasurementUnavailable("palette rectangle clipped or too small")
        boxes.append((x, y, w, h, "#"+match[5].upper(), float(match[6])))
    rows = []
    for index, (x, y, w, h, colour, alpha) in enumerate(boxes):
        context = {"decoration_index": index, "rectangle": [x,y,x+w,y+h], "declared_colour": colour}
        if alpha != 1.0:
            rows.append({**context, "status": "TRANSPARENT_NOT_MEASURED", "reason": "composited colour depends on the underlying image"})
            continue
        role = [key for key,value in roles.items() if value.upper() == colour]
        if len(role) != 1:
            raise PermissionError("opaque decoration has no unique locked palette role")
        left, top = (x, y) if coverage == "opaque_rectangles" else (x+(w-2)//2, y+(h-2)//2)
        right, bottom = (x+w, y+h) if coverage == "opaque_rectangles" else (left+2, top+2)
        def overlaps(bounds):
            return left < bounds[2] and right > bounds[0] and top < bounds[3] and bottom > bounds[1]
        covered = any(overlaps((bx,by,bx+bw,by+bh)) for bx,by,bw,bh,_,_ in boxes[index+1:])
        for overlay in layout["overlays"]:
            for bounds in (overlay["bounds"], overlay.get("background_bounds", overlay["bounds"])):
                covered |= overlaps(tuple(bounds[key] for key in ("left","top","right","bottom")))
        context.update(role=role[0], patch=[left,top,right,bottom])
        if covered:
            rows.append({**context,"status":"UNOBSERVABLE_PATCH_OCCLUDED"})
            continue
        observed = rgb[top:bottom,left:right]
        expected_rgb = np.array([int(colour[k:k+2],16) for k in (1,3,5)], dtype=np.uint8)
        reference_lab = cv2.cvtColor(expected_rgb.reshape(1,1,3).astype(np.float32)/255, cv2.COLOR_RGB2LAB)
        observed_lab = cv2.cvtColor(observed.astype(np.float32)/255, cv2.COLOR_RGB2LAB)
        error = np.linalg.norm(observed_lab-reference_lab,axis=2)
        row = {**context, "status":"PASS" if bool(np.all(error <= tolerance)) else "FAIL",
               "expected_rgb":expected_rgb.tolist(), "maximum_delta_e":float(error.max()),
               "tolerance_delta_e":tolerance, "exceeding_pixels":int(np.count_nonzero(error > tolerance)),
               "pixel_count":int(error.size)}
        if coverage == "centres":
            row.update(observed_rgb=observed.tolist(), delta_e_cie76=error.tolist())
        else:
            # Keep evidence compact: the bound frame supplies all pixels. No
            # percentile or average may hide a failing edge or interior pixel.
            py, px = np.unravel_index(int(error.argmax()), error.shape)
            bad_y, bad_x = np.nonzero(error > tolerance)
            row.update(observed_region_rgb_sha256="sha256:"+hashlib.sha256(observed.tobytes()).hexdigest(),
                maximum_error_pixel={"xy":[left+int(px),top+int(py)],"rgb":observed[py,px].tolist()},
                exceeding_pixel_bounds=([left+int(bad_x.min()),top+int(bad_y.min()),
                    left+int(bad_x.max())+1,top+int(bad_y.max())+1] if len(bad_y) else None))
            row.update(status="MEASURED", flat_reference_within_tolerance=bool(np.all(error <= tolerance)),
                       boundary_reference_qualified=False)
        rows.append(row)
    measured = [row for row in rows if "pixel_count" in row]
    unknown = [row for row in rows if row["status"] == "UNOBSERVABLE_PATCH_OCCLUDED"]
    return {"method":("canonical-opaque-decoration-regions-cie76-v2" if coverage == "opaque_rectangles"
                      else "canonical-opaque-decoration-centres-cie76-v1"), "measurements":rows,
            "status":("MEASURED_UNQUALIFIED_EDGE_REFERENCE" if measured else "INCOMPLETE") if coverage == "opaque_rectangles" else
                     ("FAIL" if any(row["status"] == "FAIL" for row in measured) else
                      ("PASS_SAMPLED_PATCHES_ONLY" if measured and not unknown else "INCOMPLETE")),
            "measured_patches":len(measured), "unobservable_patches":len(unknown),
            "tolerance_origin":"Style Bible palette and divergence_policy, never candidate-fitted",
            "full_style_covered":False, "quality_authorized":False, "publication_authorized":False}


def projected_palette_regions(reference: Any, candidate: Any, layout: dict[str, Any],
                              bible: dict[str, Any]) -> dict[str, Any]:
    """Compare declared roles in a source-projected colour domain, not flat RGB.

    The public caller authenticates the independent composition and its clock.
    No alignment, fitted colour transform, percentile, border erosion or dropped
    outliers. The Bible's perceptual limit applies to every observed pixel.
    Passing this component is not full style, time coverage or intrinsic QA.
    """
    expected, actual = np.asarray(reference), np.asarray(candidate)
    if actual.dtype != np.uint8 or actual.shape != expected.shape:
        raise VisualMeasurementUnavailable("projected palette needs corresponding native uint8 RGB frames")
    geometry = locked_palette_patches(expected, layout, bible, coverage="opaque_rectangles")
    rows = []
    for region in geometry["measurements"]:
        if "pixel_count" not in region:
            rows.append(region)
            continue
        left, top, right, bottom = region["rectangle"]
        a, b = expected[top:bottom,left:right], actual[top:bottom,left:right]
        a_lab = cv2.cvtColor(a.astype(np.float32)/255, cv2.COLOR_RGB2LAB)
        b_lab = cv2.cvtColor(b.astype(np.float32)/255, cv2.COLOR_RGB2LAB)
        error = np.linalg.norm(a_lab-b_lab,axis=2)
        bad_y, bad_x = np.nonzero(error > region["tolerance_delta_e"])
        py, px = np.unravel_index(int(error.argmax()),error.shape)
        rows.append({key:region[key] for key in ("decoration_index","rectangle","role","declared_colour","pixel_count","tolerance_delta_e")}
                    | {"status":"FAIL" if len(bad_y) else "PASS_COMPONENT_ONLY",
                       "reference_rgb_sha256":"sha256:"+hashlib.sha256(a.tobytes()).hexdigest(),
                       "observed_rgb_sha256":"sha256:"+hashlib.sha256(b.tobytes()).hexdigest(),
                       "maximum_delta_e":float(error.max()),"exceeding_pixels":len(bad_y),
                       "maximum_error_pixel":{"xy":[left+int(px),top+int(py)],"reference_rgb":a[py,px].tolist(),"observed_rgb":b[py,px].tolist()},
                       "exceeding_pixel_bounds":([left+int(bad_x.min()),top+int(bad_y.min()),left+int(bad_x.max())+1,top+int(bad_y.max())+1] if len(bad_y) else None)})
    measured = [r for r in rows if "pixel_count" in r]
    unknown = sum(r["status"] == "UNOBSERVABLE_PATCH_OCCLUDED" for r in rows)
    return {"method":"source-projected-palette-cie76-v1","measurements":rows,
            "status":"FAIL_COMPONENT" if any(r["status"] == "FAIL" for r in measured) else
                     ("PASS_COMPONENT_ONLY" if measured and not unknown else "INCOMPLETE"),
            "measured_regions":len(measured),"unobservable_regions":unknown,
            "measured_pixels":sum(r["pixel_count"] for r in measured),
            "reference_fitted_to_candidate":False,"tolerance_origin":geometry["tolerance_origin"],
            "full_style_covered":False,"quality_authorized":False,"publication_authorized":False}


def _controls(rows: list[dict[str, Any]], *, candidate_hash: str, used: set[str]) -> list[float]:
    if not rows:
        raise VisualMeasurementUnavailable("positive, negative and independent holdout controls are required")
    values = []
    for row in rows:
        identity, value = row["source_sha256"], row["value"]
        if not isinstance(identity, str) or len(identity) != 64 or any(c not in "0123456789abcdef" for c in identity):
            raise VisualMeasurementUnavailable("control lacks source hash")
        if identity == candidate_hash or identity in used:
            raise VisualMeasurementUnavailable("candidate/self calibration or control/holdout overlap")
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value < 0:
            raise VisualMeasurementUnavailable("finite nonnegative error measurement required")
        used.add(identity)
        values.append(float(value))
    return values


def calibrate_error_limit(*, candidate_hash: str, positive: list[dict[str, Any]], negative: list[dict[str, Any]],
                          holdout_positive: list[dict[str, Any]], holdout_negative: list[dict[str, Any]]) -> dict[str, Any]:
    """Derive a bound from reference controls, then independently falsify it.

    No percentile picked to accommodate the candidate; no target result is an
    input. Failure of separation is an instrument failure, not a new threshold.
    This numeric contract does not authenticate files: the caller/reader must
    reopen the control artifacts and recompute the supplied measurements.
    """
    if len(candidate_hash) != 64 or any(c not in "0123456789abcdef" for c in candidate_hash):
        raise VisualMeasurementUnavailable("candidate identity required to exclude self calibration")
    used: set[str] = set()
    good = _controls(positive, candidate_hash=candidate_hash, used=used)
    bad = _controls(negative, candidate_hash=candidate_hash, used=used)
    hold_good = _controls(holdout_positive, candidate_hash=candidate_hash, used=used)
    hold_bad = _controls(holdout_negative, candidate_hash=candidate_hash, used=used)
    limit = max(good)
    separated = min(bad) > limit and max(hold_good) <= limit and min(hold_bad) > limit
    return {"method": "worst-positive-bound-with-disjoint-holdout", "status": "CALIBRATED_NUMERIC_SCOPE" if separated else "FAILED_CONTROL_SEPARATION",
            "maximum_error": limit, "positive_count": len(good), "negative_count": len(bad),
            "holdout_positive_count": len(hold_good), "holdout_negative_count": len(hold_bad),
            "negative_minimum": min(bad), "holdout_positive_maximum": max(hold_good),
            "holdout_negative_minimum": min(hold_bad), "candidate_used_for_fitting": False,
            "semantic_or_publication_authority": False}
