from __future__ import annotations

"""Read-only reconstruction of the Phase-6 audiovisual queue context.

This module deliberately does not create an admission proof, a successor, or a
publication lock.  It only observes an already committed media-authority chain
inside one SQLite read snapshot and reopens the immutable receipts to which that
chain points.  A future write transaction must repeat the authority resolution
under its own fencing and independently acquire/revalidate the publication
lock.
"""

import hashlib
import json
import re
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Any

from hero_engine.queue_phase6 import (
    CHANNEL_ID,
    MEDIA_JOB_SUPERSESSION_RECEIPTS,
    PRODUCTION_INPUT_RECEIPTS,
    QUEUE_PATH,
    QueueConflict,
    TransactionalQueue,
    _canonical,
)


CONTEXT_VERSION = "phase6-av-observational-context-v1"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
TASK_TYPE = "EXECUTE_PHASE6_VIDEO2_MEDIA"
PRODUCTION_ACTION = "SYNTHESIZE_AND_RENDER_VIDEO_2"
TREATMENT_ACTION = "COMPILE_VIDEO_2"
TARGET_ID = "phase6-video-2-prepublication"
_JOB_ID = re.compile(r"job-[0-9a-f]{24}\Z")


class Phase6AVContextError(PermissionError):
    """The stored queue/receipt state cannot form an observational AV context."""


def _sha256_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _strict_json_bytes(raw: bytes, *, label: str) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in items:
            if key in value:
                raise Phase6AVContextError(f"{label} contains duplicate JSON keys")
            value[key] = item
        return value

    def invalid_constant(value: str) -> None:
        raise Phase6AVContextError(f"{label} contains non-finite JSON value {value}")

    try:
        value = json.loads(
            raw.decode("utf-8-sig"),
            object_pairs_hook=pairs,
            parse_constant=invalid_constant,
        )
    except Phase6AVContextError:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise Phase6AVContextError(f"{label} is not strict UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise Phase6AVContextError(f"{label} must be a JSON object")
    return value


def _strict_database_document(raw_text: str, *, label: str) -> dict[str, Any]:
    value = _strict_json_bytes(raw_text.encode("utf-8"), label=label)
    if raw_text != _canonical(value):
        raise Phase6AVContextError(f"{label} is not stored in canonical JSON form")
    return value


def _confined_file(root: Path, relative: str, parent: Path) -> Path:
    if not isinstance(relative, str) or not relative:
        raise Phase6AVContextError("immutable receipt path is missing")
    supplied = Path(relative)
    if supplied.is_absolute():
        raise Phase6AVContextError("immutable receipt path must be workspace-relative")
    allowed = (root / parent).resolve()
    candidate = (root / supplied).resolve()
    if candidate.parent != allowed:
        raise Phase6AVContextError("immutable receipt escaped its exact directory")
    return candidate


def _load_input_receipt(
    queue: TransactionalQueue,
    reference: dict[str, Any],
) -> tuple[Path, bytes, dict[str, Any]]:
    if set(reference) != {"receipt_id", "path", "sha256"}:
        raise Phase6AVContextError("input receipt reference is not the exact identity triple")
    receipt_id = reference.get("receipt_id")
    if not isinstance(receipt_id, str) or not receipt_id.startswith(
        "phase6-production-inputs-"
    ):
        raise Phase6AVContextError("input receipt identity is invalid")
    expected_relative = (PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json").as_posix()
    if reference.get("path") != expected_relative:
        raise Phase6AVContextError("input receipt is outside its exact immutable path")
    path = _confined_file(queue.root, expected_relative, PRODUCTION_INPUT_RECEIPTS)
    if not path.is_file():
        raise Phase6AVContextError("input receipt is unavailable")
    raw = path.read_bytes()
    if reference.get("sha256") != _sha256_bytes(raw):
        raise Phase6AVContextError("input receipt bytes differ from the committed reference")
    document = _strict_json_bytes(raw, label="input receipt")
    queue._validate_document("phase6_production_inputs_receipt.schema.json", document)
    if (
        document.get("receipt_id") != receipt_id
        or document.get("channel_id") != CHANNEL_ID
        or document.get("action") != "PREPARE_VIDEO_2_INPUTS"
        or document.get("publication_authorized") is not False
        or document.get("technical_cost_brl") != 0
    ):
        raise Phase6AVContextError("input receipt identity/envelope is divergent")
    return path, raw, document


def _raw_job(
    connection: sqlite3.Connection,
    job_id: str,
) -> tuple[sqlite3.Row, dict[str, Any], dict[str, Any]]:
    row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
    if row is None:
        raise QueueConflict("media authority job disappeared from the read snapshot")
    payload = _strict_database_document(
        str(row["payload_json"]), label=f"job {job_id} payload"
    )
    checkpoint = _strict_database_document(
        str(row["checkpoint_json"]), label=f"job {job_id} checkpoint"
    )
    return row, payload, checkpoint


def _validate_media_unit(unit: Any) -> dict[str, Any]:
    if not isinstance(unit, dict):
        raise Phase6AVContextError("committed chain has no semantic media unit")
    semantic = dict(unit)
    unit_key = semantic.pop("media_unit_key", None)
    expected_key = "phase6-media-unit-" + hashlib.sha256(
        _canonical(semantic).encode("utf-8")
    ).hexdigest()[:24]
    if not isinstance(unit_key, str) or unit_key != expected_key:
        raise Phase6AVContextError("media-unit key does not bind its semantic content")
    if (
        semantic.get("operation_id") != OPERATION_ID
        or semantic.get("channel_id") != CHANNEL_ID
        or semantic.get("task_type") != TASK_TYPE
        or semantic.get("production_action") != PRODUCTION_ACTION
        or semantic.get("treatment_action") != TREATMENT_ACTION
        or semantic.get("target_id") != TARGET_ID
    ):
        raise Phase6AVContextError("media unit is outside the exact Phase-6 Video-2 contract")
    return dict(unit)


def _last_receipt(
    queue: TransactionalQueue,
    connection: sqlite3.Connection,
    resolution: dict[str, Any],
) -> dict[str, Any]:
    chain = resolution.get("chain")
    if not isinstance(chain, list) or not chain:
        raise Phase6AVContextError(
            "media-unit/input lineage requires a committed supersession chain"
        )
    last = chain[-1]
    row = connection.execute(
        "SELECT * FROM media_job_supersessions WHERE supersession_id=?",
        (last["supersession_id"],),
    ).fetchone()
    if row is None:
        raise QueueConflict("terminal media supersession disappeared")
    verified = queue._verified_media_job_supersession_row(row)
    receipt = verified["receipt"]
    if (
        receipt["authoritative_job"]["job_id"]
        != resolution["authoritative_job_id"]
        or verified["receipt_sha256"] != last["receipt_sha256"]
        or verified["receipt_path"] != last["receipt_path"]
    ):
        raise Phase6AVContextError("terminal supersession receipt is divergent")
    return verified


def _reopen_chain_receipts(
    root: Path,
    chain: list[dict[str, Any]],
) -> None:
    for edge in chain:
        receipt_id = edge["supersession_id"]
        expected_relative = (
            MEDIA_JOB_SUPERSESSION_RECEIPTS / f"{receipt_id}.json"
        ).as_posix()
        if edge["receipt_path"] != expected_relative:
            raise Phase6AVContextError("supersession receipt path is not exact")
        path = _confined_file(root, expected_relative, MEDIA_JOB_SUPERSESSION_RECEIPTS)
        if not path.is_file() or _sha256_bytes(path.read_bytes()) != edge["receipt_sha256"]:
            raise Phase6AVContextError("supersession receipt changed during observation")


def _open_read_snapshot(queue_path: Path) -> sqlite3.Connection:
    """Copy one URI/read-only SQLite snapshot into a private in-memory DB.

    The file-backed handle is closed before receipt verification.  Besides
    preventing a long-lived lock on Windows, this makes it impossible for the
    resolver to observe two queue commits in one reconstruction.
    """

    uri = queue_path.as_uri() + "?mode=ro&cache=private"
    # Open the disposable destination first, then acquire the file handle in a
    # closing context.  The outer exception path deterministically closes the
    # destination if source connect, query-only enforcement, backup, or final
    # snapshot preparation fails.  Only the successful query-only snapshot is
    # transferred to the caller.
    snapshot = sqlite3.connect(":memory:", timeout=5, isolation_level=None)
    try:
        with closing(
            sqlite3.connect(uri, uri=True, timeout=5, isolation_level=None)
        ) as source:
            try:
                source.execute("PRAGMA query_only=ON")
                if int(source.execute("PRAGMA query_only").fetchone()[0]) != 1:
                    raise Phase6AVContextError(
                        "SQLite query_only could not be enforced"
                    )
                source.execute("BEGIN")
                # Establish the source read transaction before copying its
                # committed view.
                source.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
                source.backup(snapshot)
            finally:
                if source.in_transaction:
                    source.rollback()
        snapshot.row_factory = sqlite3.Row
        snapshot.execute("PRAGMA query_only=ON")
        if int(snapshot.execute("PRAGMA query_only").fetchone()[0]) != 1:
            raise Phase6AVContextError(
                "in-memory SQLite snapshot is not query-only"
            )
        snapshot.execute("BEGIN")
        return snapshot
    except BaseException:
        try:
            if snapshot.in_transaction:
                snapshot.rollback()
        finally:
            snapshot.close()
        raise


def resolve_phase6_av_context(
    root: Path,
    *,
    expected_root_job_id: str,
) -> dict[str, Any]:
    """Reconstruct one terminal Phase-6 AV context without writes or authority.

    ``expected_root_job_id`` is only a selector.  All proof-bearing values are
    obtained from the SQLite snapshot and its immutable receipts; the caller
    cannot supply a tail, media unit, checkpoint, or input-receipt hash.
    """

    if not isinstance(expected_root_job_id, str) or not _JOB_ID.fullmatch(
        expected_root_job_id
    ):
        raise ValueError("an exact canonical root job id is required")
    workspace = Path(root).resolve()
    queue_path = (workspace / QUEUE_PATH).resolve()
    if queue_path.parent != (workspace / QUEUE_PATH.parent).resolve():
        raise Phase6AVContextError("queue path escaped the Phase-6 runtime directory")
    if not queue_path.is_file():
        raise FileNotFoundError("Phase-6 queue database is unavailable")

    # Deliberately bypass __init__: it creates directories and executes migrations.
    queue = object.__new__(TransactionalQueue)
    queue.root = workspace
    queue.path = queue_path
    connection = _open_read_snapshot(queue_path)
    try:
        first = queue._resolve_media_job_authority_in_connection(
            connection,
            expected_root_job_id,
            expected_operation_id=OPERATION_ID,
            expected_channel_id=CHANNEL_ID,
            expected_task_type=TASK_TYPE,
            require_canonical_root=True,
        )
        media_unit = _validate_media_unit(first.get("media_unit"))
        # Invoke the real resolver again with the DB-discovered key, never a
        # caller assertion.  This also reopens every immutable edge receipt.
        resolution = queue._resolve_media_job_authority_in_connection(
            connection,
            expected_root_job_id,
            expected_media_unit_key=media_unit["media_unit_key"],
            expected_operation_id=OPERATION_ID,
            expected_channel_id=CHANNEL_ID,
            expected_task_type=TASK_TYPE,
            require_canonical_root=True,
        )
        if resolution != first:
            raise Phase6AVContextError("media authority changed during one read snapshot")
        if (
            resolution["authority_state"] != "SUCCEEDED"
            or resolution["authority_kind"] != "TERMINAL_SUCCEEDED"
            or resolution["terminal"] is not True
            or resolution["executable"] is not False
            or resolution["predecessor_fallback_permitted"] is not False
        ):
            raise Phase6AVContextError(
                "canonical media tail must be terminal SUCCEEDED and non-executable"
            )

        root_row, root_payload, root_checkpoint = _raw_job(
            connection, expected_root_job_id
        )
        tail_id = resolution["authoritative_job_id"]
        tail_row, tail_payload, tail_checkpoint = _raw_job(connection, tail_id)
        if (
            tail_row["state"] != "SUCCEEDED"
            or tail_row["lease_owner"] is not None
            or tail_row["lease_until"] is not None
            or tail_checkpoint == {}
        ):
            raise Phase6AVContextError(
                "terminal predecessor must be SUCCEEDED, unleased and checkpointed"
            )

        verified_tail_receipt = _last_receipt(queue, connection, resolution)
        input_reference = verified_tail_receipt["receipt"][
            "authoritative_input_receipt"
        ]
        input_path, input_raw, input_document = _load_input_receipt(
            queue, input_reference
        )
        if tail_payload.get("input_receipt_id") != input_document["receipt_id"]:
            raise Phase6AVContextError(
                "terminal payload does not name the authoritative input receipt"
            )

        _reopen_chain_receipts(workspace, resolution["chain"])
        if input_path.read_bytes() != input_raw:
            raise Phase6AVContextError("input receipt changed during observation")

        context = {
            "authority_root_job_id": expected_root_job_id,
            "authority_root_payload_sha256": _sha256_bytes(
                str(root_row["payload_json"]).encode("utf-8")
            ),
            "authority_root_checkpoint_sha256": _sha256_bytes(
                str(root_row["checkpoint_json"]).encode("utf-8")
            ),
            "predecessor_job_id": tail_id,
            "predecessor_payload_sha256": _sha256_bytes(
                str(tail_row["payload_json"]).encode("utf-8")
            ),
            "predecessor_checkpoint_sha256": _sha256_bytes(
                str(tail_row["checkpoint_json"]).encode("utf-8")
            ),
            "predecessor_state": "SUCCEEDED",
            "predecessor_lease_owner": None,
            "tail_job_id": tail_id,
            "media_unit_key": media_unit["media_unit_key"],
            "input_receipt_id": input_document["receipt_id"],
            "input_receipt_sha256": _sha256_bytes(input_raw),
        }
        return {
            "schema_version": "1.0.0",
            "context_version": CONTEXT_VERSION,
            "status": "OBSERVED_TERMINAL_CONTEXT_NOT_TRANSACTION_AUTHORITY",
            "source_schema_root": "phase6",
            "database": {
                "path": QUEUE_PATH.as_posix(),
                "open_mode": "SQLITE_URI_MODE_RO_QUERY_ONLY_SNAPSHOT",
            },
            "context": context,
            "media_unit": media_unit,
            "chain": resolution["chain"],
            "input_receipt": {
                "receipt_id": input_document["receipt_id"],
                "path": input_path.relative_to(workspace).as_posix(),
                "sha256": _sha256_bytes(input_raw),
                "size_bytes": len(input_raw),
            },
            "authority": {
                "admission": False,
                "successor_creation": False,
                "queue_claim": False,
                "render": False,
                "publication": False,
            },
            "transaction_fencing_verified": False,
            "external_publication_lock_verified": False,
            "checkpoint_publication_absence_is_lock": False,
            "future_transaction_requirements": [
                "REOPEN_CANONICAL_CHAIN_UNDER_WRITE_TRANSACTION",
                "REVALIDATE_QUEUE_FENCING",
                "ACQUIRE_AND_REVALIDATE_EXTERNAL_PUBLICATION_LOCK",
            ],
            "limitations": [
                "OBSERVATION_IS_NOT_AN_ADMISSION_OR_SUPERSESSION_RECEIPT",
                "CHECKPOINT_CONTENT_DOES_NOT_PROVE_AN_EXTERNAL_PUBLICATION_LOCK",
                "A_FUTURE_TRANSACTION_MUST_REVALIDATE_ALL_BINDINGS",
            ],
        }
    finally:
        if connection.in_transaction:
            connection.rollback()
        connection.close()


resolve = resolve_phase6_av_context
