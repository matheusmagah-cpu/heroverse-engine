from __future__ import annotations

import hashlib
import io
import json
import os
import platform
import re
import time
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

from jsonschema import Draft202012Validator, FormatChecker
from PIL import Image

from .channel_readiness import build_channel_readiness_audit, collect_owned_channel_snapshot
from .phase6_quality import package_fidelity_measurement, verify_phase6_quality_evaluation
from .phase6_quota import (
    consume_composed_quota,
    consume_general_quota,
    effective_observation_quota_usage,
    get_general_quota_debit,
    mark_composed_quota_effect_started,
    reserve_composed_quota,
    reserve_general_quota,
    revalidate_composed_quota,
    validate_composed_quota_receipt_binding,
)
from .queue_phase6 import TransactionalQueue
from .publisher import build_youtube_video_body
from .youtube_integration import INTEGRATION_SCOPES
from .zero_cost_guard import evaluate_zero_cost


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
HANDLE = "@heroverse74"
BASE = Path("output/production/phase6/video-002")
QUALITY = BASE / "quality/independent_quality_evaluation.json"
QUALITY_EVALUATIONS = BASE / "quality/evaluations"
PACKAGE = BASE / "publication/publication_package.json"
RELEASE = BASE / "publication/release_gate.json"
PUBLICATION_RECEIPT = BASE / "publication/youtube-publication-receipt.json"
CONTROLLER = Path("output/operations/phase6/publication-controller-status.json")
QUOTA_ACCOUNTING = Path("output/operations/zero-cost/phase6-video2-quota-accounting.json")
QUOTA_PREFLIGHT = Path("output/operations/zero-cost/phase6-video2-publication-preflight.json")
API_METHODS = {
    "channels.list",
    "playlistItems.list",
    "videos.insert",
    "videos.list",
    "videos.update",
    "thumbnails.set",
    "captions.insert",
    "captions.list",
    "thumbnail.fetch",
}
MAX_NON_IDEMPOTENT_MUTATION_ATTEMPTS = 1
MAX_IDEMPOTENT_MUTATION_ATTEMPTS = 3
MAX_RECOVERY_PROBES = 3
MAX_READ_ATTEMPTS = 120
RECOVERY_WINDOW_SECONDS = 6 * 60 * 60
QUOTA_UNIT_COSTS = {
    "channels.list": 1,
    "playlistItems.list": 1,
    "videos.insert": 100,
    "videos.list": 1,
    "videos.update": 50,
    "thumbnails.set": 50,
    "captions.insert": 400,
    "captions.list": 50,
    "thumbnail.fetch": 0,
}
EFFECT_CONTRACTS = {
    "CHANNEL_IDENTITY_PROBE": ("channels.list", "READ"),
    "VIDEO_PRIVATE_UPLOAD": ("videos.insert", "MUTATION"),
    "UPLOAD_RECOVERY_PLAYLIST_PROBE": ("playlistItems.list", "READ"),
    "UPLOAD_RECOVERY_VIDEO_PROBE": ("videos.list", "READ"),
    "STAGED_VIDEO_IDENTITY_PROBE": ("videos.list", "READ"),
    "THUMBNAIL_SET": ("thumbnails.set", "MUTATION"),
    "THUMBNAIL_RECOVERY_PROBE": ("thumbnail.fetch", "READ"),
    "CAPTION_TARGET_IDENTITY_PROBE": ("videos.list", "READ"),
    "CAPTION_RECOVERY_PROBE": ("captions.list", "READ"),
    "CAPTIONS_INSERT": ("captions.insert", "MUTATION"),
    "CAPTION_SERVING_PROBE": ("captions.list", "READ"),
    "VIDEO_PROCESSING_PROBE": ("videos.list", "READ"),
    "PROMOTE_PUBLIC": ("videos.update", "MUTATION"),
    "FINAL_PUBLIC_PROBE": ("videos.list", "READ"),
    "FINAL_CAPTION_SERVING_PROBE": ("captions.list", "READ"),
    "STAGED_THUMBNAIL_PROBE": ("thumbnail.fetch", "READ"),
    "PUBLIC_THUMBNAIL_PROBE": ("thumbnail.fetch", "READ"),
}
VIDEO_LIST_FIELDS = (
    "items(id,snippet(channelId,title,description,tags,categoryId,defaultLanguage,"
    "defaultAudioLanguage,publishedAt,thumbnails),contentDetails/duration,status(privacyStatus,uploadStatus,"
    "selfDeclaredMadeForKids,containsSyntheticMedia,embeddable,publicStatsViewable,license))"
)
RELEASE_GATE_ORDER = [
    "ARTIFACT_INTEGRITY",
    "INDEPENDENT_18_GATE_QUALITY",
    "THUMBNAIL_AND_CAPTIONS",
    "RIGHTS_AND_ATTRIBUTION",
    "FORMAT_SCOPE",
    "CONTROLLED_LOT",
    "FRESH_CHANNEL_READINESS",
    "OAUTH_DURABILITY",
    "OAUTH_SCOPE_ALIGNMENT",
    "ZERO_COST_AND_FREE_QUOTA",
    "PRIVATE_FIRST",
    "METADATA_PROMISE_AND_DISCLOSURE",
    "PUBLICATION_PACKAGE",
]


class PublicationAlreadyRunning(PermissionError):
    """Raised before provider access when another process owns this release."""


class PublicationLock:
    """Single-host OS lock for the exact Phase 6 publication transaction.

    The open handle owns the lock, so the operating system releases it after an
    abrupt process death.  The marker file is metadata only; its existence is
    never treated as ownership.
    """

    def __init__(self, root: Path) -> None:
        self.path = root.resolve() / BASE / "publication/publication-transaction.lock"
        self.handle: Any | None = None

    def acquire(self) -> "PublicationLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        self.handle.seek(0, os.SEEK_END)
        if self.handle.tell() == 0:
            self.handle.write(b"0")
            self.handle.flush()
            os.fsync(self.handle.fileno())
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.handle.close()
            self.handle = None
            raise PublicationAlreadyRunning(
                "another process owns the exact Phase 6 publication transaction"
            ) from exc
        return self

    def release(self) -> None:
        if self.handle is None:
            return
        try:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None

    def __enter__(self) -> "PublicationLock":
        return self.acquire()

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.release()


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        for attempt in range(8):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(min(0.5, 0.05 * (2 ** attempt)))
    finally:
        if temporary.exists():
            temporary.unlink()


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _fingerprint(api_method: str, payload: dict[str, Any]) -> str:
    canonical = json.dumps(
        {"api_method": api_method, "payload": payload},
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _json_hash(value: Any) -> str:
    canonical = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _idempotency_marker(idempotency_key: str) -> str:
    return f"hv-p6-{idempotency_key[:32]}"


def _youtube_duration_ms(value: Any) -> int | None:
    if not isinstance(value, str):
        return None
    match = re.fullmatch(
        r"P(?:(?P<days>\d+)D)?(?:T(?:(?P<hours>\d+)H)?(?:(?P<minutes>\d+)M)?"
        r"(?:(?P<seconds>\d+(?:\.\d+)?)S)?)?",
        value,
    )
    if match is None or not any(match.groupdict().values()):
        return None
    seconds = (
        int(match.group("days") or 0) * 86400
        + int(match.group("hours") or 0) * 3600
        + int(match.group("minutes") or 0) * 60
        + float(match.group("seconds") or 0)
    )
    return round(seconds * 1000)


def _general_quota_binding(debit: dict[str, Any]) -> dict[str, Any]:
    return {
        "mode": "GENERAL",
        "binding_id": str(debit["debit_id"]),
        "idempotency_key": str(debit["idempotency_key"]),
        "path": None,
        "sha256": _json_hash(debit),
        "state": str(debit["state"]),
        "quota_day_start": str(debit["quota_day_start"]),
        "quota_day_end": str(debit["quota_day_end"]),
        "general_units": int(debit["units"]),
        "upload_units": 0,
    }


def _composed_quota_binding(binding: dict[str, Any]) -> dict[str, Any]:
    receipt = binding["receipt"]
    return {
        "mode": "COMPOSED_UPLOAD",
        "binding_id": str(receipt["reservation_id"]),
        "idempotency_key": str(receipt["idempotency_key"]),
        "path": str(binding["path"]),
        "sha256": str(binding["sha256"]),
        "state": str(receipt["state"]),
        "quota_day_start": str(receipt["quota_day_start"]),
        "quota_day_end": str(receipt["quota_day_end"]),
        "general_units": int(receipt["buckets"]["youtube-general-units-daily"]["units"]),
        "upload_units": 1,
    }


def _package_identity(value: dict[str, Any]) -> str:
    material = {key: item for key, item in value.items() if key not in {"package_id", "created_at"}}
    return "phase6-publication-package-" + _json_hash(material)[:24]


def _validate_effect_journal(receipt: dict[str, Any]) -> None:
    if receipt.get("schema_version") not in {"1.1.0", "1.2.0", "1.3.0"}:
        return
    journal = receipt.get("effect_journal") or []
    if [item.get("sequence") for item in journal] != list(range(1, len(journal) + 1)):
        raise PermissionError("publication effect journal sequence is not contiguous")
    before_keys: set[tuple[str, int]] = set()
    after_by_key: dict[tuple[str, int], list[dict[str, Any]]] = {}
    before_attempts: dict[str, list[int]] = {}
    known_authorizations = {
        item.get("authorization_id")
        for item in (receipt.get("release_authorizations") or [])
    }
    for item in journal:
        effect_id = str(item.get("effect_id"))
        key = (effect_id, int(item.get("attempt") or 0))
        expected_contract = EFFECT_CONTRACTS.get(effect_id)
        if expected_contract is None or expected_contract != (
            item.get("api_method"),
            item.get("kind"),
        ):
            raise PermissionError(f"publication effect violates its API/kind contract: {effect_id}")
        request_payload = item.get("request_payload")
        if receipt.get("schema_version") == "1.3.0" and (
            not isinstance(request_payload, dict)
            or _fingerprint(str(item.get("api_method")), request_payload)
            != item.get("request_fingerprint")
        ):
            raise PermissionError(f"publication effect fingerprint cannot be recomputed: {effect_id}")
        if receipt.get("schema_version") == "1.3.0":
            quota = item.get("quota_debit")
            expected_units = QUOTA_UNIT_COSTS[str(item.get("api_method"))]
            if expected_units == 0:
                if quota is not None:
                    raise PermissionError(f"zero-quota effect carries a debit: {effect_id}")
            elif not isinstance(quota, dict):
                raise PermissionError(f"quota-consuming effect has no debit: {effect_id}")
            else:
                expected_upload_units = 1 if item.get("api_method") == "videos.insert" else 0
                expected_mode = "COMPOSED_UPLOAD" if expected_upload_units else "GENERAL"
                expected_key = f"{receipt['idempotency_key']}:{effect_id}:{item.get('attempt')}"
                expected_state = (
                    "RESERVED"
                    if item.get("checkpoint") == "BEFORE"
                    or item.get("outcome") in {"FAILED", "AMBIGUOUS"}
                    else "CONSUMED"
                )
                if (
                    quota.get("general_units") != expected_units
                    or quota.get("upload_units") != expected_upload_units
                    or quota.get("mode") != expected_mode
                    or quota.get("idempotency_key") != expected_key
                    or quota.get("state") != expected_state
                ):
                    raise PermissionError(f"quota debit does not match effect/attempt/outcome: {effect_id}")
                checkpoint_time = _parse(str(item.get("checkpointed_at")))
                if not (
                    _parse(str(quota.get("quota_day_start")))
                    <= checkpoint_time
                    < _parse(str(quota.get("quota_day_end")))
                ):
                    raise PermissionError(f"quota debit day does not cover its effect: {effect_id}")
                if quota.get("mode") == "COMPOSED_UPLOAD":
                    # The project-root/path check is performed by the receipt verifier,
                    # where the actual root is available.  Here, at minimum, the
                    # immutable file binding cannot be syntactically omitted.
                    if not quota.get("path") or not re.fullmatch(r"[a-f0-9]{64}", str(quota.get("sha256") or "")):
                        raise PermissionError("composed upload debit lacks immutable path/hash")
        if receipt.get("schema_version") in {"1.2.0", "1.3.0"} and item.get(
            "authorization_id"
        ) not in known_authorizations:
            raise PermissionError(
                f"publication effect is not bound to a frozen release authorization: {effect_id}"
            )
        if item.get("checkpoint") == "BEFORE":
            if key in before_keys:
                raise PermissionError(f"publication effect journal repeats BEFORE checkpoint: {key}")
            before_keys.add(key)
            before_attempts.setdefault(effect_id, []).append(key[1])
        else:
            if item.get("kind") == "READ" and item.get("outcome") not in {
                "CONFIRMED",
                "FAILED",
            }:
                raise PermissionError(f"read effect has an invalid outcome: {effect_id}")
            if item.get("kind") == "MUTATION" and item.get("outcome") not in {
                "CONFIRMED",
                "AMBIGUOUS",
                "RECOVERED",
            }:
                raise PermissionError(f"mutation effect has an invalid outcome: {effect_id}")
            after_by_key.setdefault(key, []).append(item)
    for effect_id, attempts in before_attempts.items():
        if attempts != list(range(1, len(attempts) + 1)):
            raise PermissionError(
                f"publication effect attempts are not contiguous for {effect_id}: {attempts}"
            )
    for index, item in enumerate(journal):
        if item.get("checkpoint") != "AFTER":
            continue
        matching_before = [
            prior
            for prior in journal[:index]
            if prior.get("checkpoint") == "BEFORE"
            and prior.get("effect_id") == item.get("effect_id")
            and prior.get("attempt") == item.get("attempt")
            and prior.get("api_method") == item.get("api_method")
            and prior.get("kind") == item.get("kind")
            and prior.get("request_fingerprint") == item.get("request_fingerprint")
        ]
        if len(matching_before) != 1:
            raise PermissionError(
                f"publication effect journal has an unbound AFTER checkpoint: {item.get('effect_id')}"
            )
        before_quota = matching_before[0].get("quota_debit")
        after_quota = item.get("quota_debit")
        if receipt.get("schema_version") == "1.3.0" and (
            isinstance(before_quota, dict) != isinstance(after_quota, dict)
            or (
                isinstance(before_quota, dict)
                and (
                    before_quota.get("binding_id") != after_quota.get("binding_id")
                    or before_quota.get("idempotency_key") != after_quota.get("idempotency_key")
                    or before_quota.get("quota_day_start") != after_quota.get("quota_day_start")
                    or before_quota.get("quota_day_end") != after_quota.get("quota_day_end")
                )
            )
        ):
            raise PermissionError(f"publication AFTER quota debit is not bound to BEFORE: {item.get('effect_id')}")
    for key, afters in after_by_key.items():
        outcomes = [str(item.get("outcome")) for item in afters]
        if len(outcomes) > 2 or (len(outcomes) == 2 and outcomes != ["AMBIGUOUS", "RECOVERED"]):
            raise PermissionError(
                f"publication effect journal has conflicting AFTER checkpoints: {key}={outcomes}"
            )
    if receipt.get("schema_version") == "1.3.0":
        latest_quota: dict[str, dict[str, Any]] = {}
        for item in journal:
            quota = item.get("quota_debit")
            if isinstance(quota, dict):
                latest_quota[str(quota["binding_id"])] = quota
        if receipt.get("quota_debits") != list(latest_quota.values()):
            raise PermissionError("publication receipt quota summary diverges from its journal")
    retry_policy = receipt.get("retry_policy") or {}
    non_idempotent = {"VIDEO_PRIVATE_UPLOAD", "CAPTIONS_INSERT"}
    recovery_reads = {
        "UPLOAD_RECOVERY_PLAYLIST_PROBE",
        "UPLOAD_RECOVERY_VIDEO_PROBE",
        "CAPTION_RECOVERY_PROBE",
        "THUMBNAIL_RECOVERY_PROBE",
        "STAGED_THUMBNAIL_PROBE",
        "PUBLIC_THUMBNAIL_PROBE",
    }
    for effect_id, attempts in before_attempts.items():
        kind = EFFECT_CONTRACTS[effect_id][1]
        if kind == "MUTATION":
            maximum = int(
                retry_policy.get(
                    "non_idempotent_mutation_max_attempts"
                    if effect_id in non_idempotent
                    else "idempotent_mutation_max_attempts",
                    0,
                )
            )
        elif effect_id in recovery_reads:
            maximum = int(retry_policy.get("recovery_probe_max_attempts", 0))
        else:
            maximum = int(retry_policy.get("read_max_attempts", 0))
            ordered_outcomes = [
                after["outcome"]
                for attempt in attempts
                for after in after_by_key.get((effect_id, attempt), [])[-1:]
            ]
            longest_failure_run = 0
            current_failure_run = 0
            for outcome in ordered_outcomes:
                current_failure_run = current_failure_run + 1 if outcome == "FAILED" else 0
                longest_failure_run = max(longest_failure_run, current_failure_run)
            if maximum < 1 or longest_failure_run > maximum:
                raise PermissionError(
                    f"publication read exceeds its consecutive-failure policy: "
                    f"{effect_id}={longest_failure_run}/{maximum}"
                )
            continue
        if maximum < 1 or len(attempts) > maximum:
            raise PermissionError(
                f"publication effect exceeds its frozen retry policy: {effect_id}={len(attempts)}/{maximum}"
            )
    if receipt.get("status") == "COMPLETE_PUBLIC":
        required_steps = {
            "CHANNEL_IDENTITY",
            "VIDEO_PRIVATE_UPLOAD",
            "STAGED_VIDEO_IDENTITY_VERIFY",
            "THUMBNAIL_SET",
            "CAPTION_TARGET_IDENTITY_VERIFY",
            "CAPTIONS_INSERT",
            "CAPTIONS_SERVING",
            "POST_UPLOAD_IDENTITY_VERIFY",
            "PROMOTE_PUBLIC",
            "PUBLIC_POST_UPLOAD_VERIFY",
            "FINAL_CAPTIONS_SERVING",
            "STAGED_THUMBNAIL_VERIFY",
            "PUBLIC_THUMBNAIL_VERIFY",
        }
        passed_steps = {
            item.get("step") for item in (receipt.get("steps") or []) if item.get("status") == "PASS"
        }
        if not required_steps.issubset(passed_steps):
            raise PermissionError("complete publication receipt is missing a required PASS step")
        confirmed_effects = {
            item.get("effect_id")
            for item in journal
            if item.get("checkpoint") == "AFTER"
            and item.get("outcome") in {"CONFIRMED", "RECOVERED"}
        }
        required_effects = {
            "CHANNEL_IDENTITY_PROBE",
            "VIDEO_PRIVATE_UPLOAD",
            "STAGED_VIDEO_IDENTITY_PROBE",
            "THUMBNAIL_SET",
            "CAPTION_TARGET_IDENTITY_PROBE",
            "CAPTIONS_INSERT",
            "CAPTION_SERVING_PROBE",
            "VIDEO_PROCESSING_PROBE",
            "PROMOTE_PUBLIC",
            "FINAL_PUBLIC_PROBE",
            "FINAL_CAPTION_SERVING_PROBE",
            "STAGED_THUMBNAIL_PROBE",
            "PUBLIC_THUMBNAIL_PROBE",
        }
        if not required_effects.issubset(confirmed_effects):
            raise PermissionError("complete publication receipt lacks confirmed external effects")
        successful = {
            effect_id: next(
                (
                    item
                    for item in journal
                    if item.get("effect_id") == effect_id
                    and item.get("checkpoint") == "AFTER"
                    and item.get("outcome") in {"CONFIRMED", "RECOVERED"}
                ),
                None,
            )
            for effect_id in required_effects
        }
        ordered = [
            "CHANNEL_IDENTITY_PROBE",
            "VIDEO_PRIVATE_UPLOAD",
            "STAGED_VIDEO_IDENTITY_PROBE",
            "THUMBNAIL_SET",
            "CAPTION_TARGET_IDENTITY_PROBE",
            "CAPTIONS_INSERT",
            "CAPTION_SERVING_PROBE",
            "VIDEO_PROCESSING_PROBE",
            "STAGED_THUMBNAIL_PROBE",
            "PROMOTE_PUBLIC",
            "FINAL_PUBLIC_PROBE",
            "FINAL_CAPTION_SERVING_PROBE",
            "PUBLIC_THUMBNAIL_PROBE",
        ]
        sequences = [int(successful[name]["sequence"]) for name in ordered]
        if sequences != sorted(sequences) or len(set(sequences)) != len(sequences):
            raise PermissionError("complete publication receipt has an invalid effect order")
        video_id = receipt.get("video_id")
        caption_id = receipt.get("caption_id")
        for effect_id in ("VIDEO_PRIVATE_UPLOAD", "PROMOTE_PUBLIC"):
            if successful[effect_id].get("remote_resource_id") != video_id:
                raise PermissionError(
                    f"complete publication receipt has a foreign resource id for {effect_id}"
                )
        if successful["CAPTIONS_INSERT"].get("remote_resource_id") != caption_id:
            raise PermissionError(
                "complete publication receipt has a foreign captions resource id"
            )
        unmatched = [
            key
            for key in before_keys
            if key not in after_by_key
            or not any(
                item.get("outcome") in {"CONFIRMED", "RECOVERED", "FAILED"}
                for item in after_by_key[key]
            )
        ]
        unresolved = [
            key
            for key, items in after_by_key.items()
            if items[-1].get("outcome") == "AMBIGUOUS"
        ]
        if unmatched or unresolved:
            raise PermissionError(
                f"complete publication receipt contains unfinished effects: unmatched={unmatched}; unresolved={unresolved}"
            )
        successful_mutations = [
            item["effect_id"]
            for item in journal
            if item.get("kind") == "MUTATION"
            and item.get("checkpoint") == "AFTER"
            and item.get("outcome") in {"CONFIRMED", "RECOVERED"}
        ]
        if len(successful_mutations) != len(set(successful_mutations)):
            raise PermissionError("complete publication receipt repeats a successful mutation")
        terminal_indices = [
            index
            for index, item in enumerate(journal)
            if item.get("effect_id") == "PUBLIC_THUMBNAIL_PROBE"
            and item.get("checkpoint") == "AFTER"
            and item.get("outcome") == "CONFIRMED"
        ]
        if len(terminal_indices) != 1 or terminal_indices[0] != len(journal) - 1:
            raise PermissionError("complete publication receipt has effects after its terminal proof")


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _confined_path(root: Path, value: str, label: str) -> Path:
    path = _resolve(root, value).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"{label} escaped the project root") from exc
    return path


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(_read(root / "schemas" / schema_name), format_checker=FormatChecker()).validate(value)


def _artifact(root: Path, path: Path) -> dict[str, Any]:
    absolute = path if path.is_absolute() else root / path
    return {"path": _relative(root, absolute), "sha256": _sha(absolute), "size_bytes": absolute.stat().st_size}


def _dhash(image: Image.Image) -> int:
    gray = image.convert("L").resize((9, 8), Image.Resampling.LANCZOS)
    pixels = list(gray.tobytes())
    value = 0
    for y in range(8):
        for x in range(8):
            value = (value << 1) | int(pixels[y * 9 + x] > pixels[y * 9 + x + 1])
    return value


def _thumbnail_similarity(left: Image.Image, right: Image.Image) -> float:
    distance = (_dhash(left) ^ _dhash(right)).bit_count()
    shape_similarity = 1.0 - distance / 64.0
    left_rgb = left.convert("RGB").resize((1, 1), Image.Resampling.LANCZOS).getpixel((0, 0))
    right_rgb = right.convert("RGB").resize((1, 1), Image.Resampling.LANCZOS).getpixel((0, 0))
    color_similarity = 1.0 - sum(
        abs(int(a) - int(b)) for a, b in zip(left_rgb, right_rgb, strict=True)
    ) / 765.0
    return round(0.4 * shape_similarity + 0.6 * color_similarity, 6)


def _fetch_public_thumbnail(url: str) -> bytes:
    if not isinstance(url, str) or not url.startswith("https://"):
        raise PermissionError("public thumbnail verification requires an HTTPS URL")
    request = urllib.request.Request(url, headers={"User-Agent": "HeroVerse-Thumbnail-QA/1.0"})
    with urllib.request.urlopen(request, timeout=20) as response:  # nosec: URL is provider-returned HTTPS
        payload = response.read(5 * 1024 * 1024 + 1)
    if not payload or len(payload) > 5 * 1024 * 1024:
        raise RuntimeError("public thumbnail response is empty or exceeds the verification limit")
    return payload


def _quality_ready(root: Path) -> tuple[dict[str, Any] | None, str | None]:
    runtime_path = root / "output/operations/phase6/quality-executor-status.json"
    if not runtime_path.is_file():
        return None, "Independent quality evaluation is not available."
    runtime = _read(runtime_path)
    _validate(root, "phase6_quality_executor_runtime.schema.json", runtime)
    if runtime["status"] != "COMPLETED" or runtime["job_state"] != "SUCCEEDED":
        return None, f"Quality executor is {runtime['status']}/{runtime['job_state']}."
    runtime_evaluation = runtime.get("evaluation")
    job_id = runtime.get("job_id")
    if not isinstance(runtime_evaluation, str) or not runtime_evaluation:
        raise PermissionError("completed quality runtime has no evaluation path")
    if not isinstance(job_id, str) or not job_id:
        raise PermissionError("completed quality runtime has no exact queue job id")

    matching_jobs = [
        item
        for item in TransactionalQueue(root).snapshot()["jobs"]
        if item.get("job_id") == job_id
    ]
    if len(matching_jobs) != 1:
        raise PermissionError("quality runtime does not bind exactly one queue job")
    job = matching_jobs[0]
    checkpoint = job.get("checkpoint") or {}
    if (
        job.get("state") != "SUCCEEDED"
        or job.get("task_type") != "EVALUATE_PHASE6_VIDEO2_QUALITY"
        or job.get("channel_id") != CHANNEL_ID
    ):
        raise PermissionError("quality runtime queue job is not the exact successful quality task")
    evaluation_id = checkpoint.get("evaluation_id")
    evaluation_sha256 = checkpoint.get("evaluation_sha256")
    checkpoint_evaluation = checkpoint.get("evaluation")
    if not isinstance(evaluation_id, str) or not evaluation_id:
        raise PermissionError("quality queue checkpoint has no evaluation_id")
    if not isinstance(evaluation_sha256, str) or not re.fullmatch(r"sha256:[a-f0-9]{64}", evaluation_sha256):
        raise PermissionError("quality queue checkpoint has no valid evaluation_sha256")
    expected_relative = (QUALITY_EVALUATIONS / f"{evaluation_id}.json").as_posix()
    if runtime_evaluation != checkpoint_evaluation or runtime_evaluation != expected_relative:
        raise PermissionError("quality runtime/checkpoint path is not the exact immutable evaluation")
    report_path = _resolve(root, runtime_evaluation).resolve()
    expected_parent = (root / QUALITY_EVALUATIONS).resolve()
    if report_path.parent != expected_parent or report_path.name != f"{evaluation_id}.json":
        raise PermissionError("quality evaluation path escaped or copied outside its immutable identity")
    if not report_path.is_file() or f"sha256:{_sha(report_path)}" != evaluation_sha256:
        raise PermissionError("quality queue checkpoint hash does not match the immutable evaluation")
    report = verify_phase6_quality_evaluation(
        root,
        report_path=report_path,
        expected_evaluation_id=evaluation_id,
    )
    if report["decision"] != "PASS_LIMITED_RELEASE" or not report["publication_eligible"]:
        return None, f"Quality decision is {report['decision']}."
    if (
        runtime.get("decision") != report["decision"]
        or runtime.get("publication_eligible") is not report["publication_eligible"]
        or checkpoint.get("decision") != report["decision"]
        or checkpoint.get("publication_eligible") is not report["publication_eligible"]
    ):
        raise PermissionError("quality runtime/checkpoint decision diverges from the evaluation")
    if not all(item["status"] == "PASS" for item in report["gates"] + report["defect_evaluations"]):
        raise PermissionError("quality report contains a non-PASS critical result")
    video = root / report["artifact"]["path"]
    if not video.is_file() or _sha(video) != report["artifact"]["sha256"]:
        raise PermissionError("quality-approved video changed or disappeared")
    return {
        "report": report,
        "job_id": job_id,
        "evaluation": {
            "evaluation_id": evaluation_id,
            "path": expected_relative,
            "sha256": _sha(report_path),
            "size_bytes": report_path.stat().st_size,
        },
    }, None


def _description(root: Path, brief: dict[str, Any], allocation: dict[str, Any], library: dict[str, Any]) -> str:
    package = brief["package"]
    opening = (
        f"{package['promise']}\n\n"
        "Use the HeroVerse three-part test: name what is true, accept the responsibility that is yours, and choose one faithful action you can complete today. "
        "This original English Christian-motivation episode is designed to turn pressure into grounded action without presenting feelings, urgency or outcomes as a guarantee from God.\n\n"
        f"{brief['payoff']}\n\n"
        "Write one truthful, responsible next step in the comments. Subscribe to HeroVerse for cinematic Christian motivation about prayer, wisdom, character and action.\n\n"
        "Visual source credits:\n"
    )
    assets = {item["asset_id"]: item for item in library["assets"]}
    credits: list[str] = []
    for asset_id in dict.fromkeys(item["asset_id"] for item in allocation["takes"]):
        asset = assets[asset_id]
        if str(asset.get("license") or "").upper().startswith("CC BY"):
            value = str(asset.get("attribution") or "").strip()
            if not value:
                raise PermissionError(f"required CC attribution is empty: {asset_id}")
            credits.append(f"• {value}")
    footer = (
        "\nFull per-take hashes, source ranges and license evidence are preserved in the production record. "
        "No paid production tool or paid API was used.\n\n"
        "#ChristianMotivation #FaithInAction #BiblicalWisdom"
    )
    description = opening + ("\n".join(credits) if credits else "• Public-domain or project-owned visual sources; detailed evidence is preserved in the production record.") + footer
    if len(description) > 5000:
        raise ValueError(f"required description and attribution exceed YouTube limit: {len(description)}")
    return description


def build_phase6_publication_package(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    quality_context, reason = _quality_ready(root)
    if quality_context is None:
        raise PermissionError(reason)
    quality = quality_context["report"]
    quality_artifact = quality_context["evaluation"]
    timestamp = created_at or _stamp()
    manifest = _read(root / BASE / "render_manifest.json")
    brief = _read(root / BASE / "preproduction/editorial_brief.json")
    allocation = _read(root / BASE / "production/asset_allocation.json")
    library = _read(root / "output/production/phase6/shared-assets/asset_manifest.json")
    scope = _read(root / "output/operations/phase6/production/format-scope-receipt.json")
    thumbnail = quality["thumbnail_selection"]
    video = root / quality["artifact"]["path"]
    thumb = _resolve(root, thumbnail["path"])
    captions = _resolve(root, manifest["captions"]["path"])
    if _sha(video) != quality["artifact"]["sha256"] or _sha(thumb) != thumbnail["sha256"] or "sha256:" + _sha(captions) != manifest["captions"]["content_hash"]:
        raise PermissionError("frozen publication inputs changed after quality approval")
    selected_assets = {item["asset_id"] for item in allocation["takes"]}
    sources = {item["asset_id"]: item.get("source", "") for item in library["assets"]}
    synthetic = any(str(sources[asset_id]).startswith("generated://") for asset_id in selected_assets)
    title = thumbnail["title"]
    description = _description(root, brief, allocation, library)
    banned = re.compile(r"\b(guaranteed|instant miracle|god told you|will happen)\b", re.I)
    policy_pass = banned.search(title + " " + description) is None
    thumbnail_text = next(item["text"] for item in _read(root / BASE / "thumbnail/thumbnail_set_manifest.json")["candidates"] if item["candidate_id"] == thumbnail["candidate_id"])
    fidelity = package_fidelity_measurement(
        root, brief, _read(root / BASE / "preproduction/narrative_script.json"),
        _read(root / BASE / "production/take_plan.json"),
        title=title, thumbnail_text=thumbnail_text,
    )["passed"]
    if not fidelity:
        raise PermissionError("publication package fidelity requires a review of the exact current narrative and package")
    quality_pass = all(item["status"] == "PASS" for item in quality["gates"] + quality["defect_evaluations"])
    ready = bool(quality_pass and fidelity and policy_pass and scope.get("status") == "AUTHORIZED" and scope.get("requested_action") == "COMPILE_VIDEO_2" and scope.get("target_video_id") == "phase6-video-2-prepublication" and scope.get("video_ordinal") == 2)
    value = {
        "schema_version": "1.2.0", "package_id": "PENDING_CONTENT_ID",
        "status": "READY_FOR_RELEASE_GATE" if ready else "BLOCKED",
        "channel": {"channel_id": CHANNEL_ID, "handle": HANDLE, "language": "en-US"},
        "video": {"render_id": manifest["render_id"], "path": str(video.resolve()), "sha256": _sha(video), "size_bytes": video.stat().st_size, "duration_ms": int(manifest["output"]["duration_ms"]), "width": int(manifest["output"]["width"]), "height": int(manifest["output"]["height"]), "fps": int(round(float(manifest["output"]["fps"])))},
        "thumbnail": {"candidate_id": thumbnail["candidate_id"], "path": str(thumb.resolve()), "sha256": _sha(thumb), "size_bytes": thumb.stat().st_size, "width": 1280, "height": 720, "text": thumbnail_text},
        "captions": {"path": str(captions.resolve()), "sha256": _sha(captions), "language": "en-US", "cue_count": int(manifest["captions"]["cue_count"]), "coverage_ratio": float(manifest["captions"]["coverage_ratio"])},
        "metadata": {"title": title, "description": description, "tags": ["Christian motivation", "faith in action", "biblical wisdom", "prayer and action", "Christian encouragement", "spiritual growth", "daily faith", "responsible action", "discernment", "Christian devotional", "HeroVerse", "English Christian motivation"], "category_id": "27", "default_language": "en", "default_audio_language": "en", "made_for_kids": False, "privacy_status": "private"},
        "metadata_decision": {"selected_title": title, "selected_thumbnail": thumbnail["candidate_id"], "method": "independent-predeclared-editorial-and-legibility-rubric", "provider_score_is_causal": False, "promise_fidelity": "PASS" if fidelity else "FAIL", "policy_language": "PASS" if policy_pass else "FAIL", "performance_status": "UNTESTED_UNTIL_PUBLICATION"},
        "disclosure": {"contains_synthetic_media": synthetic, "reason": "Some project-owned generated illustration is present and is disclosed." if synthetic else "The selected edit uses licensed/public-domain footage and original local motion/audio without realistic synthetic-event depiction.", "api_field": "status.containsSyntheticMedia"},
        "rights": {"status": "PASS_AUTOMATIC", "asset_manifest": "output/production/phase6/shared-assets/asset_manifest.json", "allocation": _relative(root, root / BASE / "production/asset_allocation.json"), "attribution": _relative(root, root / BASE / "attribution.txt"), "attribution_in_description": True},
        "quality": {"evaluation_id": quality["evaluation_id"], "evaluation": quality_artifact["path"], "evaluation_sha256": quality_artifact["sha256"], "evaluation_size_bytes": quality_artifact["size_bytes"], "decision": quality["decision"], "all_critical_gates_pass": all(item["status"] == "PASS" for item in quality["gates"]), "all_defects_pass": all(item["status"] == "PASS" for item in quality["defect_evaluations"]), "publication_eligible": quality["publication_eligible"]},
        "format_capability": {"format_pack_id": "fp-broll-cinematic-narration", "version": "1.1.0", "status": "LIMITED", "scope_receipt": "output/operations/phase6/production/format-scope-receipt.json"},
        "publication_policy": {"upload_permitted": ready, "private_first": True, "public_after_processing_verification": True, "notify_subscribers": False, "ads_enabled": False, "budget_brl": 0},
        "technical_cost_brl": 0, "created_at": timestamp,
    }
    value["package_id"] = _package_identity(value)
    _validate(root, "phase6_publication_package.schema.json", value)
    return value


def materialize_phase6_publication_package(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    path = root / PACKAGE
    value = build_phase6_publication_package(root, created_at=created_at)
    if path.is_file():
        existing = _read(path)
        _validate(root, "phase6_publication_package.schema.json", existing)
        if existing.get("schema_version") != "1.2.0":
            raise PermissionError(
                "legacy publication package lacks a full content identity and cannot be reused"
            )
        if _package_identity(existing) != existing.get("package_id"):
            raise PermissionError("existing publication package content identity is invalid")
        if existing["package_id"] == value["package_id"]:
            return path
        receipt_path = root / PUBLICATION_RECEIPT
        if receipt_path.is_file():
            raise PermissionError(
                "publication package changed after transaction receipt creation; frozen core preserved"
            )
    _write(path, value)
    return path


def _quota_day(now: datetime) -> tuple[datetime, datetime]:
    pacific = ZoneInfo("America/Los_Angeles")
    local = now.astimezone(pacific)
    start_local = local.replace(hour=0, minute=0, second=0, microsecond=0)
    return start_local.astimezone(timezone.utc), (start_local + timedelta(days=1)).astimezone(timezone.utc)


def materialize_phase6_quota_preflight(root: Path = ROOT, *, now: datetime | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    effective = effective_observation_quota_usage(root, now=current)
    if effective is None:
        raise PermissionError("Phase 6 free-quota accounting is unavailable or malformed")
    authoritative = root / "output/operations/zero-cost/phase6-observation-quota-accounting.json"
    if not authoritative.is_file():
        raise PermissionError("Phase 6 quota accounting was not materialized atomically")
    accounting = _read(authoritative)
    _validate(root, "phase6_quota_accounting.schema.json", accounting)
    start, end = _quota_day(current)
    if (
        accounting.get("schema_version") != "1.1.0"
        or accounting.get("effective_consumption_for_gate") != effective
        or accounting.get("quota_day_start") != _stamp(start)
        or accounting.get("quota_day_end") != _stamp(end)
        or accounting.get("ledger_path")
        != "output/operations/zero-cost/phase6-quota-ledger.sqlite3"
        or accounting.get("billing_enabled") is not False
        or accounting.get("technical_cost_brl") != 0
    ):
        raise PermissionError("Phase 6 quota accounting identity/day/cost is inconsistent")
    accounting_path = root / QUOTA_ACCOUNTING
    _write(accounting_path, accounting)
    preflight = evaluate_zero_cost(root, operation="phase6_video2_publication_pipeline", observed_usage=effective, created_at=_stamp(current))
    preflight_path = root / QUOTA_PREFLIGHT
    _write(preflight_path, preflight)
    return accounting_path, preflight_path


def refresh_channel_readiness(root: Path, token_path: Path, *, force: bool = False, now: datetime | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    output = root / "output/audits/channel/heroverse"
    snapshot_path, audit_path = output / "channel-snapshot.json", output / "channel-readiness-audit.json"
    if not force and snapshot_path.is_file() and audit_path.is_file():
        try:
            snapshot = _read(snapshot_path)
            if current - _parse(snapshot["observed_at"]) <= timedelta(hours=1):
                return snapshot_path, audit_path
        except Exception:
            pass
    from google.oauth2.credentials import Credentials  # type: ignore
    from googleapiclient.discovery import build  # type: ignore

    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("noninteractive OAuth token is not valid at the channel-refresh boundary")
    youtube = build("youtube", "v3", credentials=credentials, cache_discovery=False)
    analytics = build("youtubeAnalytics", "v2", credentials=credentials, cache_discovery=False)
    snapshot = collect_owned_channel_snapshot(youtube, analytics, output_dir=output, today=current.date())
    studio = _read(output / "studio-observation.json")
    audit = build_channel_readiness_audit(snapshot, studio_observation=studio, created_at=_stamp(current))
    _validate(root, "channel_readiness_audit.schema.json", audit)
    _write(snapshot_path, snapshot)
    _write(audit_path, audit)
    return snapshot_path, audit_path


CORE_RELEASE_ARTIFACTS = (
    "video",
    "thumbnail",
    "captions",
    "publication_package",
    "quality_evaluation",
    "scope_receipt",
)


def _release_core_material(release: dict[str, Any]) -> dict[str, Any]:
    return {
        "channel_id": release["channel_id"],
        "package_id": release["package_id"],
        "quality_evaluation_id": release["quality_evaluation_id"],
        "execution_host_id": release["execution_host_id"],
        "staging_privacy_status": release["staging_privacy_status"],
        "final_privacy_status": release["final_privacy_status"],
        "selected_thumbnail": release["selected_thumbnail"],
        "artifacts": {name: release["artifacts"][name] for name in CORE_RELEASE_ARTIFACTS},
        "authorized_api_methods": release["authorized_api_methods"],
        "idempotency_key": release["idempotency_key"],
        "claim_boundary": release["claim_boundary"],
        "technical_cost_brl": release["technical_cost_brl"],
    }


def _release_core_id(release: dict[str, Any]) -> str:
    return "phase6-publication-core-" + _json_hash(_release_core_material(release))[:24]


def _release_authorization_id(release: dict[str, Any]) -> str:
    material = {
        key: item
        for key, item in release.items()
        if key not in {"authorization_id", "created_at"}
    }
    return "phase6-release-authorization-" + _json_hash(material)[:24]


def build_phase6_release_gate(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    package_path = root / PACKAGE
    package = _read(package_path)
    _validate(root, "phase6_publication_package.schema.json", package)
    if (
        package.get("schema_version") != "1.2.0"
        or _package_identity(package) != package.get("package_id")
    ):
        raise PermissionError("release gate cannot bind a legacy or identity-invalid package")
    evaluation_id = package["quality"]["evaluation_id"]
    quality_path = _resolve(root, package["quality"]["evaluation"]).resolve()
    expected_quality_path = (root / QUALITY_EVALUATIONS / f"{evaluation_id}.json").resolve()
    if quality_path != expected_quality_path:
        raise PermissionError("publication package quality path is not its exact immutable twin")
    quality_artifact = _artifact(root, quality_path)
    if (
        quality_artifact["path"] != package["quality"]["evaluation"]
        or quality_artifact["sha256"] != package["quality"]["evaluation_sha256"]
        or quality_artifact["size_bytes"] != package["quality"]["evaluation_size_bytes"]
    ):
        raise PermissionError("publication package quality hash/size/path binding changed")
    quality = verify_phase6_quality_evaluation(
        root,
        report_path=quality_path,
        expected_evaluation_id=evaluation_id,
    )
    scope_path = root / "output/operations/phase6/production/format-scope-receipt.json"
    snapshot_path = root / "output/audits/channel/heroverse/channel-snapshot.json"
    channel_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    oauth_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    scopes_path = root / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
    preflight_path = root / QUOTA_PREFLIGHT
    accounting_path = root / QUOTA_ACCOUNTING
    paths = [scope_path, snapshot_path, channel_path, oauth_path, scopes_path, preflight_path, accounting_path]
    if any(not path.is_file() for path in paths):
        raise FileNotFoundError("release evidence is incomplete")
    scope, snapshot, channel, oauth, scopes, preflight, accounting = map(_read, paths)
    _validate(root, "zero_cost_guard.schema.json", preflight)
    _validate(root, "phase6_quota_accounting.schema.json", accounting)
    now = _parse(created_at) if created_at else datetime.now(timezone.utc)
    video, thumb, captions = (_resolve(root, package[name]["path"]) for name in ("video", "thumbnail", "captions"))
    hashes_pass = all(path.is_file() and _sha(path) == package[name]["sha256"] for path, name in ((video, "video"), (thumb, "thumbnail"), (captions, "captions")))
    quality_pass = bool(quality["decision"] == "PASS_LIMITED_RELEASE" and quality["publication_eligible"] and not quality["blockers"] and all(item["status"] == "PASS" for item in quality["gates"] + quality["defect_evaluations"]) and quality["artifact"]["sha256"] == package["video"]["sha256"])
    scope_pass = bool(scope.get("status") == "AUTHORIZED" and scope.get("requested_action") == "COMPILE_VIDEO_2" and scope.get("target_video_id") == "phase6-video-2-prepublication" and scope.get("video_ordinal") == 2 and not [item for item in scope.get("gates") or [] if item.get("status") != "PASS"])
    snapshot_age_hours = max(0.0, (now - _parse(snapshot["observed_at"])).total_seconds() / 3600)
    audit_age_hours = max(0.0, (now - _parse(channel["created_at"])).total_seconds() / 3600)
    generation_gap_seconds = abs(
        (_parse(channel["created_at"]) - _parse(snapshot["observed_at"])).total_seconds()
    )
    expected_audit_id = "channel-readiness-" + hashlib.sha256(
        (snapshot["snapshot_id"] + channel["created_at"]).encode()
    ).hexdigest()[:16]
    channel_pass = bool(
        snapshot.get("channel_id") == CHANNEL_ID
        and str(snapshot.get("handle") or "").casefold() == HANDLE
        and channel.get("channel_id") == CHANNEL_ID
        and str(channel.get("handle") or "").casefold() == HANDLE
        and channel.get("snapshot_ref") == _relative(root, snapshot_path)
        and channel.get("audit_id") == expected_audit_id
        and snapshot_age_hours <= 1
        and audit_age_hours <= 1
        and generation_gap_seconds <= 300
        and channel.get("overall_status") == "PASS"
        and not (channel.get("publication_gate") or {}).get("critical_open_gates")
        and (channel.get("publication_gate") or {}).get("auto_publish_permitted") is True
    )
    oauth_pass = bool(oauth.get("continuous_operation_ready") is True and (oauth.get("publication_guard") or {}).get("upload_permitted") is True and scopes.get("status") == "PASS" and not (scopes.get("missing_scopes") or []))
    quota_resources = {
        item.get("resource_id"): item.get("quota_consumed")
        for item in (preflight.get("resources") or [])
    }
    quota_pass = bool(
        preflight.get("execution_permitted") is True
        and preflight.get("technical_cost_brl") == 0
        and preflight.get("quota_status") == "PASS"
        and preflight.get("operation") == "phase6_video2_publication_pipeline"
        and accounting.get("schema_version") == "1.1.0"
        and accounting.get("technical_cost_brl") == 0
        and accounting.get("billing_enabled") is False
        and accounting.get("quota_day_start") == _stamp(_quota_day(now)[0])
        and accounting.get("quota_day_end") == _stamp(_quota_day(now)[1])
        and quota_resources.get("youtube-videos-insert-daily")
        == accounting.get("effective_consumption_for_gate", {}).get("youtube-videos-insert-daily")
        and quota_resources.get("youtube-general-units-daily")
        == accounting.get("effective_consumption_for_gate", {}).get("youtube-general-units-daily")
        and preflight.get("created_at") == accounting.get("created_at")
    )
    package_pass = bool(package["status"] == "READY_FOR_RELEASE_GATE" and package["publication_policy"]["upload_permitted"] is True)
    attribution_pass = package["rights"]["status"] == "PASS_AUTOMATIC" and package["rights"]["attribution_in_description"] is True
    plan = _read(root / "output/operations/phase6/pilot-plan.json")
    canary = _read(root / "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
    lot_pass = bool(plan["lot"]["maximum_long_videos"] == 3 and len(plan["lot"]["published_video_ids"]) < 3 and canary.get("status") == "COMPLETE_PUBLIC" and canary.get("video_id") in plan["lot"]["published_video_ids"])
    gates_raw = [
        ("ARTIFACT_INTEGRITY", hashes_pass, [package["video"]["sha256"], package["thumbnail"]["sha256"], package["captions"]["sha256"]]),
        ("INDEPENDENT_18_GATE_QUALITY", quality_pass, [_relative(root, quality_path), quality["decision"]]),
        ("THUMBNAIL_AND_CAPTIONS", hashes_pass and package["thumbnail"]["size_bytes"] <= 2_097_152 and package["captions"]["coverage_ratio"] == 1.0, [_relative(root, thumb), _relative(root, captions)]),
        ("RIGHTS_AND_ATTRIBUTION", attribution_pass, [package["rights"]["asset_manifest"], package["rights"]["attribution"]]),
        ("FORMAT_SCOPE", scope_pass, [_relative(root, scope_path)]),
        ("CONTROLLED_LOT", lot_pass, ["output/operations/phase6/pilot-plan.json", str(canary.get("video_id"))]),
        ("FRESH_CHANNEL_READINESS", channel_pass, [_relative(root, snapshot_path), _relative(root, channel_path), f"snapshot_age_hours={snapshot_age_hours:.6f}", f"audit_age_hours={audit_age_hours:.6f}", f"generation_gap_seconds={generation_gap_seconds:.3f}", f"snapshot_sha256={_sha(snapshot_path)}", f"audit_sha256={_sha(channel_path)}"]),
        ("OAUTH_DURABILITY", oauth_pass, [_relative(root, oauth_path)]),
        ("OAUTH_SCOPE_ALIGNMENT", oauth_pass, [_relative(root, scopes_path)]),
        ("ZERO_COST_AND_FREE_QUOTA", quota_pass, [_relative(root, preflight_path), _relative(root, accounting_path), str(accounting.get("accounting_id"))]),
        ("PRIVATE_FIRST", package["metadata"]["privacy_status"] == "private" and package["publication_policy"]["private_first"] is True, ["privacyStatus=private"]),
        ("METADATA_PROMISE_AND_DISCLOSURE", package["metadata_decision"]["promise_fidelity"] == "PASS" and package["metadata_decision"]["policy_language"] == "PASS" and len(package["metadata"]["description"]) <= 5000, [package["metadata"]["title"], f"description_length={len(package['metadata']['description'])}"]),
        ("PUBLICATION_PACKAGE", package_pass, [_relative(root, package_path)]),
    ]
    gates = [{"gate": name, "critical": True, "status": "PASS" if passed else "BLOCKED", "evidence": evidence} for name, passed, evidence in gates_raw]
    blockers = [item["gate"] for item in gates if item["status"] != "PASS"]
    ready = not blockers
    idempotency = hashlib.sha256(f"{CHANNEL_ID}|{package['package_id']}|{package['video']['sha256']}".encode()).hexdigest()
    value = {
        "schema_version": "1.3.0", "release_id": "phase6-release-" + idempotency[:24], "authorization_id": "PENDING_AUTHORIZATION_ID", "core_binding_id": "PENDING_CORE_BINDING_ID", "channel_id": CHANNEL_ID, "package_id": package["package_id"], "quality_evaluation_id": evaluation_id, "execution_host_id": platform.node(), "quota_accounting_id": accounting["accounting_id"], "quota_day_start": accounting["quota_day_start"], "quota_day_end": accounting["quota_day_end"],
        "decision": "READY_FOR_PUBLICATION_PIPELINE" if ready else "BLOCKED", "publication_pipeline_permitted": ready,
        "staging_privacy_status": "private", "final_privacy_status": "public", "selected_thumbnail": package["thumbnail"]["candidate_id"] if ready else None,
        "artifacts": {"video": _artifact(root, video), "thumbnail": _artifact(root, thumb), "captions": _artifact(root, captions), "publication_package": _artifact(root, package_path), "quality_evaluation": quality_artifact, "scope_receipt": _artifact(root, scope_path), "channel_snapshot": _artifact(root, snapshot_path), "channel_audit": _artifact(root, channel_path), "oauth_readiness": _artifact(root, oauth_path), "scope_requirement": _artifact(root, scopes_path), "quota_preflight": _artifact(root, preflight_path), "quota_accounting": _artifact(root, accounting_path)},
        "gates": gates, "blockers": blockers, "authorized_api_methods": sorted(API_METHODS) if ready else [], "idempotency_key": idempotency,
        "claim_boundary": "READY authorizes only this exact frozen Phase 6 Video 2 package, private-first upload to the pinned HeroVerse channel, and public promotion only after processing and identity verification. It authorizes no Ads, paid tool, unrelated mutation, guaranteed audience result or another release.",
        "technical_cost_brl": 0, "created_at": created_at or _stamp(),
    }
    value["core_binding_id"] = _release_core_id(value)
    value["authorization_id"] = _release_authorization_id(value)
    _validate(root, "phase6_release_gate.schema.json", value)
    return value


def materialize_phase6_release_gate(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    path = root / RELEASE
    value = build_phase6_release_gate(root, created_at=created_at)
    if path.is_file():
        existing = _read(path)
        try:
            _validate(root, "phase6_release_gate.schema.json", existing)
        except Exception:
            existing = {}
        if (
            existing.get("schema_version") == "1.3.0"
            and existing.get("authorization_id") == value["authorization_id"]
            and existing.get("core_binding_id") == value["core_binding_id"]
        ):
            if (
                _release_core_id(existing) != existing["core_binding_id"]
                or _release_authorization_id(existing) != existing["authorization_id"]
            ):
                raise PermissionError("existing release authorization identity is invalid")
            return path
    _write(path, value)
    return path


def _validate_release(root: Path, release: dict[str, Any], *, now: datetime | None = None) -> None:
    _validate(root, "phase6_release_gate.schema.json", release)
    if release.get("schema_version") != "1.3.0":
        raise PermissionError("legacy release gate cannot authorize a new external effect")
    if release.get("core_binding_id") != _release_core_id(release):
        raise PermissionError("release core binding identity is invalid")
    if release.get("authorization_id") != _release_authorization_id(release):
        raise PermissionError("release authorization identity is invalid")
    if not platform.node() or release.get("execution_host_id") != platform.node():
        raise PermissionError("release is fenced to a different or unknown execution host")
    if release["decision"] != "READY_FOR_PUBLICATION_PIPELINE" or not release["publication_pipeline_permitted"]:
        raise PermissionError("Phase 6 release is not ready")
    gate_names = [item.get("gate") for item in release["gates"]]
    if gate_names != RELEASE_GATE_ORDER or len(gate_names) != len(set(gate_names)):
        raise PermissionError("release gate identities/order differ from the 13-gate contract")
    expected_blockers = [
        item["gate"]
        for item in release["gates"]
        if item.get("critical") is not True or item.get("status") != "PASS"
    ]
    if release["blockers"] != expected_blockers or expected_blockers:
        raise PermissionError("release blockers do not exactly reflect all non-PASS critical gates")
    if set(release["authorized_api_methods"]) != API_METHODS:
        raise PermissionError("release does not authorize the exact least-use API set")
    validation_now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    accounting_artifact = release["artifacts"].get("quota_accounting") or {}
    accounting_path = _confined_path(root, str(accounting_artifact.get("path") or ""), "release quota accounting")
    expected_accounting_path = (root / QUOTA_ACCOUNTING).resolve()
    expected_preflight_path = (root / QUOTA_PREFLIGHT).resolve()
    if accounting_path != expected_accounting_path:
        raise PermissionError("release quota accounting path is not authoritative")
    accounting = _read(accounting_path)
    _validate(root, "phase6_quota_accounting.schema.json", accounting)
    preflight_path = _confined_path(root, release["artifacts"]["quota_preflight"]["path"], "release quota preflight")
    if preflight_path != expected_preflight_path:
        raise PermissionError("release quota preflight path is not authoritative")
    preflight = _read(preflight_path)
    _validate(root, "zero_cost_guard.schema.json", preflight)
    resource_usage = {
        item.get("resource_id"): item.get("quota_consumed")
        for item in (preflight.get("resources") or [])
    }
    day_start, day_end = _quota_day(validation_now)
    if (
        accounting.get("schema_version") != "1.1.0"
        or accounting_artifact != _artifact(root, accounting_path)
        or release.get("quota_accounting_id") != accounting.get("accounting_id")
        or release.get("quota_day_start") != accounting.get("quota_day_start")
        or release.get("quota_day_end") != accounting.get("quota_day_end")
        or accounting.get("quota_day_start") != _stamp(day_start)
        or accounting.get("quota_day_end") != _stamp(day_end)
        or preflight.get("created_at") != accounting.get("created_at")
        or preflight.get("operation") != "phase6_video2_publication_pipeline"
        or preflight.get("execution_permitted") is not True
        or preflight.get("quota_status") != "PASS"
        or resource_usage.get("youtube-videos-insert-daily")
        != accounting.get("effective_consumption_for_gate", {}).get("youtube-videos-insert-daily")
        or resource_usage.get("youtube-general-units-daily")
        != accounting.get("effective_consumption_for_gate", {}).get("youtube-general-units-daily")
    ):
        raise PermissionError("release quota preflight/accounting/day binding is stale or divergent")

    package_path = root / PACKAGE
    package = _read(package_path)
    _validate(root, "phase6_publication_package.schema.json", package)
    if (
        package.get("schema_version") != "1.2.0"
        or package.get("package_id") != release.get("package_id")
        or _package_identity(package) != package.get("package_id")
    ):
        raise PermissionError("release does not bind the exact current hardened package")

    evaluation_id = package["quality"]["evaluation_id"]
    quality_path = _resolve(root, package["quality"]["evaluation"]).resolve()
    expected_quality_path = (root / QUALITY_EVALUATIONS / f"{evaluation_id}.json").resolve()
    if quality_path != expected_quality_path or release.get("quality_evaluation_id") != evaluation_id:
        raise PermissionError("release/package quality evaluation identity or path diverges")
    if not quality_path.is_file():
        raise PermissionError("immutable quality evaluation is missing")
    quality_artifact = _artifact(root, quality_path)
    if (
        package["quality"]["evaluation"] != quality_artifact["path"]
        or package["quality"]["evaluation_sha256"] != quality_artifact["sha256"]
        or package["quality"]["evaluation_size_bytes"] != quality_artifact["size_bytes"]
    ):
        raise PermissionError("package quality evidence binding changed after release")
    quality = verify_phase6_quality_evaluation(
        root,
        report_path=quality_path,
        expected_evaluation_id=evaluation_id,
    )
    if (
        quality.get("decision") != "PASS_LIMITED_RELEASE"
        or quality.get("publication_eligible") is not True
        or quality.get("artifact", {}).get("sha256") != package["video"]["sha256"]
        or quality.get("artifact", {}).get("path") != _relative(root, _resolve(root, package["video"]["path"]))
        or quality.get("thumbnail_selection", {}).get("sha256") != package["thumbnail"]["sha256"]
        or quality.get("thumbnail_selection", {}).get("path") != _relative(root, _resolve(root, package["thumbnail"]["path"]))
    ):
        raise PermissionError("quality decision does not bind the exact package video/thumbnail")

    snapshot_path = _confined_path(
        root, release["artifacts"]["channel_snapshot"]["path"], "release channel snapshot"
    )
    audit_path = _confined_path(
        root, release["artifacts"]["channel_audit"]["path"], "release channel audit"
    )
    if (
        snapshot_path != (root / "output/audits/channel/heroverse/channel-snapshot.json").resolve()
        or audit_path
        != (root / "output/audits/channel/heroverse/channel-readiness-audit.json").resolve()
    ):
        raise PermissionError("release readiness evidence paths are not authoritative")
    snapshot, audit = _read(snapshot_path), _read(audit_path)
    snapshot_delta = validation_now - _parse(str(snapshot.get("observed_at")))
    audit_delta = validation_now - _parse(str(audit.get("created_at")))
    generation_gap = abs(
        (_parse(str(audit.get("created_at"))) - _parse(str(snapshot.get("observed_at")))).total_seconds()
    )
    expected_audit_id = "channel-readiness-" + hashlib.sha256(
        (str(snapshot.get("snapshot_id")) + str(audit.get("created_at"))).encode()
    ).hexdigest()[:16]
    if not (
        snapshot.get("channel_id") == CHANNEL_ID
        and str(snapshot.get("handle") or "").casefold() == HANDLE
        and audit.get("channel_id") == CHANNEL_ID
        and str(audit.get("handle") or "").casefold() == HANDLE
        and audit.get("snapshot_ref") == _relative(root, snapshot_path)
        and audit.get("audit_id") == expected_audit_id
        and timedelta(0) <= snapshot_delta <= timedelta(hours=1)
        and timedelta(0) <= audit_delta <= timedelta(hours=1)
        and generation_gap <= 300
        and audit.get("overall_status") == "PASS"
        and not (audit.get("publication_gate") or {}).get("critical_open_gates")
        and (audit.get("publication_gate") or {}).get("auto_publish_permitted") is True
    ):
        raise PermissionError("release readiness snapshot/audit generation is stale or divergent")

    expected_core = {
        "video": _artifact(root, _resolve(root, package["video"]["path"])),
        "thumbnail": _artifact(root, _resolve(root, package["thumbnail"]["path"])),
        "captions": _artifact(root, _resolve(root, package["captions"]["path"])),
        "publication_package": _artifact(root, package_path),
        "quality_evaluation": quality_artifact,
        "scope_receipt": _artifact(root, _resolve(root, package["format_capability"]["scope_receipt"])),
    }
    for name, expected in expected_core.items():
        if release["artifacts"].get(name) != expected:
            raise PermissionError(f"release {name} artifact is not the exact package/quality binding")
    for name, artifact in release["artifacts"].items():
        path = _confined_path(root, artifact["path"], f"release artifact {name}")
        if not path.is_file() or _sha(path) != artifact["sha256"] or path.stat().st_size != artifact["size_bytes"]:
            raise PermissionError(f"release artifact changed or disappeared: {name}")

    # Recompute every one of the 13 release decisions from its underlying
    # evidence.  Gate labels and content-derived IDs are not signatures: a
    # locally rewritten release with freshly calculated IDs must still fail if
    # any authoritative input does not independently prove PASS.
    scope_path = _confined_path(
        root, release["artifacts"]["scope_receipt"]["path"], "release format scope"
    )
    scope = _read(scope_path)
    scope_pass = bool(
        scope.get("status") == "AUTHORIZED"
        and scope.get("requested_action") == "COMPILE_VIDEO_2"
        and scope.get("target_video_id") == "phase6-video-2-prepublication"
        and scope.get("video_ordinal") == 2
    )
    oauth_path = _confined_path(
        root, release["artifacts"]["oauth_readiness"]["path"], "release OAuth readiness"
    )
    scopes_path = _confined_path(
        root, release["artifacts"]["scope_requirement"]["path"], "release OAuth scopes"
    )
    if (
        oauth_path
        != (root / "output/integrations/youtube/heroverse/operational-readiness.json").resolve()
        or scopes_path
        != (
            root
            / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
        ).resolve()
    ):
        raise PermissionError("release OAuth evidence paths are not authoritative")
    oauth, scopes = _read(oauth_path), _read(scopes_path)
    oauth_pass = bool(
        oauth.get("continuous_operation_ready") is True
        and (oauth.get("publication_guard") or {}).get("upload_permitted") is True
        and scopes.get("status") == "PASS"
        and not (scopes.get("missing_scopes") or [])
    )
    plan = _read(root / "output/operations/phase6/pilot-plan.json")
    canary = _read(
        root
        / "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
    )
    lot = plan.get("lot") or {}
    published_video_ids = lot.get("published_video_ids") or []
    lot_pass = bool(
        lot.get("maximum_long_videos") == 3
        and isinstance(published_video_ids, list)
        and len(published_video_ids) < 3
        and canary.get("status") == "COMPLETE_PUBLIC"
        and canary.get("video_id") in published_video_ids
    )
    quality_pass = bool(
        quality.get("decision") == "PASS_LIMITED_RELEASE"
        and quality.get("publication_eligible") is True
        and package.get("quality", {}).get("all_critical_gates_pass") is True
        and package.get("quality", {}).get("all_defects_pass") is True
        and all(item.get("critical") is True and item.get("status") == "PASS" for item in quality["gates"])
        and all(item.get("status") == "PASS" for item in quality["defect_evaluations"])
    )
    artifact_integrity_pass = all(
        release["artifacts"].get(name) == expected for name, expected in expected_core.items()
    )
    attribution_pass = bool(
        package.get("rights", {}).get("status") == "PASS_AUTOMATIC"
        and package.get("rights", {}).get("attribution_in_description") is True
        and next(
            (item.get("status") for item in quality["gates"] if item.get("gate") == "RIGHTS"),
            None,
        )
        == "PASS"
    )
    metadata = package.get("metadata") or {}
    metadata_decision = package.get("metadata_decision") or {}
    policy = package.get("publication_policy") or {}
    recomputed = {
        "ARTIFACT_INTEGRITY": artifact_integrity_pass,
        "INDEPENDENT_18_GATE_QUALITY": quality_pass,
        "THUMBNAIL_AND_CAPTIONS": bool(
            artifact_integrity_pass
            and package["thumbnail"]["size_bytes"] <= 2_097_152
            and package["captions"]["coverage_ratio"] == 1.0
        ),
        "RIGHTS_AND_ATTRIBUTION": attribution_pass,
        "FORMAT_SCOPE": scope_pass,
        "CONTROLLED_LOT": lot_pass,
        "FRESH_CHANNEL_READINESS": True,
        "OAUTH_DURABILITY": oauth_pass,
        "OAUTH_SCOPE_ALIGNMENT": oauth_pass,
        "ZERO_COST_AND_FREE_QUOTA": True,
        "PRIVATE_FIRST": bool(
            metadata.get("privacy_status") == "private" and policy.get("private_first") is True
        ),
        "METADATA_PROMISE_AND_DISCLOSURE": bool(
            metadata_decision.get("promise_fidelity") == "PASS"
            and metadata_decision.get("policy_language") == "PASS"
            and len(str(metadata.get("description") or "")) <= 5000
            and package.get("disclosure", {}).get("api_field")
            == "status.containsSyntheticMedia"
        ),
        "PUBLICATION_PACKAGE": bool(
            package.get("status") == "READY_FOR_RELEASE_GATE"
            and policy.get("upload_permitted") is True
        ),
    }
    observed_gate_statuses = {
        item["gate"]: item["status"] == "PASS" and item.get("critical") is True
        for item in release["gates"]
    }
    if list(recomputed) != RELEASE_GATE_ORDER or observed_gate_statuses != recomputed:
        failed = [name for name, passed in recomputed.items() if not passed]
        raise PermissionError(
            "release gate statuses are not independently reproducible: " + ",".join(failed)
        )


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable publication artifact collision: {path}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise PermissionError(f"immutable publication artifact collision: {path}")
        except OSError:
            # The transaction lock serializes local writers; replace is used only
            # when hard-link creation is unavailable (notably some OneDrive roots).
            if path.exists():
                if path.read_bytes() != payload:
                    raise PermissionError(f"immutable publication artifact collision: {path}")
            else:
                os.replace(temporary, path)
        if path.read_bytes() != payload:
            raise OSError(f"immutable publication artifact verification failed: {path}")
    finally:
        if temporary.exists():
            temporary.unlink()


def _freeze_artifact_copy(root: Path, artifact: dict[str, Any], label: str) -> Path:
    source = _confined_path(root, artifact["path"], label)
    if (
        not source.is_file()
        or _sha(source) != artifact["sha256"]
        or source.stat().st_size != artifact["size_bytes"]
    ):
        raise PermissionError(f"{label} changed before immutable staging")
    target = (
        root
        / BASE
        / "publication/frozen-inputs"
        / f"{artifact['sha256']}{source.suffix.lower()}"
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if _sha(target) != artifact["sha256"] or target.stat().st_size != artifact["size_bytes"]:
            raise PermissionError(f"immutable staged {label} collided with different bytes")
        return target
    temporary = target.with_name(f".{target.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        digest = hashlib.sha256()
        size = 0
        with source.open("rb") as reader, temporary.open("xb") as writer:
            for block in iter(lambda: reader.read(1024 * 1024), b""):
                writer.write(block)
                digest.update(block)
                size += len(block)
            writer.flush()
            os.fsync(writer.fileno())
        if digest.hexdigest() != artifact["sha256"] or size != artifact["size_bytes"]:
            raise PermissionError(f"{label} changed while immutable staging was created")
        os.replace(temporary, target)
        if _sha(target) != artifact["sha256"] or target.stat().st_size != artifact["size_bytes"]:
            raise PermissionError(f"immutable staged {label} verification failed")
        return target
    finally:
        if temporary.exists():
            temporary.unlink()


def _receipt_core_binding(release: dict[str, Any]) -> dict[str, Any]:
    return {
        "binding_id": release["core_binding_id"],
        "package_id": release["package_id"],
        "staging_privacy_status": release["staging_privacy_status"],
        "final_privacy_status": release["final_privacy_status"],
        "selected_thumbnail": release["selected_thumbnail"],
        "quality_evaluation": {
            "evaluation_id": release["quality_evaluation_id"],
            **release["artifacts"]["quality_evaluation"],
        },
        "execution_host_id": release["execution_host_id"],
        "artifacts": {name: release["artifacts"][name] for name in CORE_RELEASE_ARTIFACTS},
        "authorized_api_methods": release["authorized_api_methods"],
        "idempotency_key": release["idempotency_key"],
        "claim_boundary": release["claim_boundary"],
    }


def _freeze_release_authorization(root: Path, release: dict[str, Any]) -> dict[str, Any]:
    source = root / RELEASE
    payload = source.read_bytes()
    parsed = json.loads(payload.decode("utf-8-sig"))
    if parsed != release:
        raise PermissionError("release changed while its authorization was being frozen")
    release_sha = hashlib.sha256(payload).hexdigest()
    immutable = (
        root
        / BASE
        / "publication/release-authorizations"
        / f"{release['authorization_id']}.json"
    )
    _write_immutable_bytes(immutable, payload)
    return {
        "authorization_id": release["authorization_id"],
        "release_id": release["release_id"],
        "release_path": _relative(root, immutable),
        "release_sha256": release_sha,
        "core_binding_id": release["core_binding_id"],
        "quota_accounting_id": release["quota_accounting_id"],
        "quota_accounting_path": release["artifacts"]["quota_accounting"]["path"],
        "quota_accounting_sha256": release["artifacts"]["quota_accounting"]["sha256"],
        "quota_day_start": release["quota_day_start"],
        "quota_day_end": release["quota_day_end"],
        "authorized_at": release["created_at"],
    }


def _validate_release_authorizations(
    root: Path,
    authorizations: list[dict[str, Any]],
    core_binding_id: str,
) -> None:
    expected_parent = (root / BASE / "publication/release-authorizations").resolve()
    seen: set[str] = set()
    for binding in authorizations:
        authorization_id = str(binding["authorization_id"])
        if authorization_id in seen:
            raise PermissionError("publication receipt repeats a release authorization")
        seen.add(authorization_id)
        path = _resolve(root, binding["release_path"]).resolve()
        if path.parent != expected_parent or path.name != f"{authorization_id}.json":
            raise PermissionError("release authorization path escaped its immutable directory")
        if not path.is_file() or _sha(path) != binding["release_sha256"]:
            raise PermissionError("release authorization is missing or changed")
        release = _read(path)
        _validate(root, "phase6_release_gate.schema.json", release)
        if (
            release.get("schema_version") != "1.3.0"
            or release.get("authorization_id") != authorization_id
            or release.get("release_id") != binding["release_id"]
            or release.get("core_binding_id") != core_binding_id
            or binding.get("core_binding_id") != core_binding_id
            or binding.get("quota_accounting_id") != release.get("quota_accounting_id")
            or binding.get("quota_accounting_path")
            != release.get("artifacts", {}).get("quota_accounting", {}).get("path")
            or binding.get("quota_accounting_sha256")
            != release.get("artifacts", {}).get("quota_accounting", {}).get("sha256")
            or binding.get("quota_day_start") != release.get("quota_day_start")
            or binding.get("quota_day_end") != release.get("quota_day_end")
            or release.get("created_at") != binding["authorized_at"]
            or _release_core_id(release) != core_binding_id
            or _release_authorization_id(release) != authorization_id
        ):
            raise PermissionError("release authorization binding is internally inconsistent")


def _verify_frozen_quota_binding(root: Path, binding: dict[str, Any]) -> None:
    """Verify a debit as historical evidence without requiring its day to be current."""
    if binding["mode"] == "GENERAL":
        row = get_general_quota_debit(root, idempotency_key=binding["idempotency_key"])
        if row is None or _general_quota_binding(row) != binding:
            raise PermissionError("general quota ledger binding is missing or divergent")
        return
    value = validate_composed_quota_receipt_binding(
        root,
        receipt_path=str(binding["path"]),
        receipt_sha256=str(binding["sha256"]),
    )
    bucket_general = value["buckets"]["youtube-general-units-daily"]
    if (
        binding["binding_id"] != value["reservation_id"]
        or binding["idempotency_key"] != value["idempotency_key"]
        or binding["state"] != value["state"]
        or binding["quota_day_start"] != value["quota_day_start"]
        or binding["quota_day_end"] != value["quota_day_end"]
        or binding["general_units"] != bucket_general["units"]
        or binding["upload_units"] != 1
    ):
        raise PermissionError("composed quota receipt content identity diverged")


def verify_phase6_publication_receipt(
    root: Path = ROOT,
    *,
    receipt_path: str | Path = PUBLICATION_RECEIPT,
    require_complete: bool = False,
) -> dict[str, Any]:
    """Recompute the hardened receipt chain; JSON-schema validation alone is insufficient."""
    root = root.resolve()
    path = _confined_path(root, str(receipt_path), "Phase 6 publication receipt")
    value = _read(path)
    _validate(root, "youtube_publication_receipt.schema.json", value)
    if value.get("schema_version") != "1.3.0":
        raise PermissionError("legacy publication receipt cannot satisfy a current gate")
    if require_complete and value.get("status") != "COMPLETE_PUBLIC":
        raise PermissionError("publication receipt is not terminal COMPLETE_PUBLIC")
    _validate_effect_journal(value)
    core = value["core_binding"]
    if (
        core.get("execution_host_id") != platform.node()
        or core.get("idempotency_key") != value.get("idempotency_key")
        or set(core.get("authorized_api_methods") or []) != API_METHODS
    ):
        raise PermissionError("publication receipt core host/idempotency/API binding diverged")
    _validate_release_authorizations(root, value["release_authorizations"], core["binding_id"])
    for authorization in value["release_authorizations"]:
        frozen_release = _read(_confined_path(root, authorization["release_path"], "release authorization"))
        if _receipt_core_binding(frozen_release) != core:
            raise PermissionError("publication receipt core differs from its frozen release")
    for name, artifact in core["artifacts"].items():
        artifact_path = _confined_path(root, artifact["path"], f"receipt artifact {name}")
        if (
            not artifact_path.is_file()
            or _sha(artifact_path) != artifact["sha256"]
            or artifact_path.stat().st_size != artifact["size_bytes"]
        ):
            raise PermissionError(f"publication receipt artifact changed or disappeared: {name}")
    package = _read(_confined_path(root, core["artifacts"]["publication_package"]["path"], "receipt package"))
    _validate(root, "phase6_publication_package.schema.json", package)
    quality = core["quality_evaluation"]
    if (
        package.get("schema_version") != "1.2.0"
        or package.get("package_id") != core["package_id"]
        or _package_identity(package) != core["package_id"]
        or package.get("quality", {}).get("evaluation_id") != quality["evaluation_id"]
        or package.get("quality", {}).get("evaluation") != quality["path"]
        or package.get("quality", {}).get("evaluation_sha256") != quality["sha256"]
        or package.get("quality", {}).get("evaluation_size_bytes") != quality["size_bytes"]
        or value["artifact_hashes"]
        != {name: core["artifacts"][name]["sha256"] for name in ("video", "thumbnail", "captions")}
    ):
        raise PermissionError("publication receipt package/quality/artifact binding diverged")
    verify_phase6_quality_evaluation(
        root,
        report_path=_confined_path(root, quality["path"], "receipt quality evaluation"),
        expected_evaluation_id=quality["evaluation_id"],
    )
    verified_quota: set[tuple[str, str]] = set()
    for entry in value["effect_journal"]:
        binding = entry.get("quota_debit")
        if isinstance(binding, dict) and binding.get("mode") == "COMPOSED_UPLOAD":
            identity = (str(binding["binding_id"]), str(binding["sha256"]))
            if identity not in verified_quota:
                _verify_frozen_quota_binding(root, binding)
                verified_quota.add(identity)
    for binding in value["quota_debits"]:
        if binding.get("mode") == "GENERAL":
            _verify_frozen_quota_binding(root, binding)
    return value


def _execute_upload(request: Any) -> dict[str, Any]:
    response = None
    while response is None:
        _, response = request.next_chunk()
    return response


def _observe_complete_publication(
    youtube: Any,
    thumbnail_fetcher: Callable[[str], bytes],
    root: Path,
    package: dict[str, Any],
    receipt: dict[str, Any],
) -> dict[str, Any]:
    """Create a new read-only proof; never let a historical COMPLETE mask drift."""
    video_id = str(receipt["video_id"])
    marker = str(receipt["idempotency_marker"])
    attempt_boundary = datetime.now(timezone.utc)
    attempt_id = f"{_stamp(attempt_boundary)}:{uuid.uuid4().hex}"
    quota_debits: list[dict[str, Any]] = []

    def quota_read(effect_id: str, api_method: str, call: Callable[[], Any]) -> Any:
        effect_now = datetime.now(timezone.utc)
        basis = effective_observation_quota_usage(root, now=effect_now)
        if basis is None:
            raise PermissionError(f"official free-quota basis unavailable before {effect_id}")
        key = f"{receipt['idempotency_key']}:current-observation:{attempt_id}:{effect_id}"
        reserved = reserve_general_quota(
            root,
            idempotency_key=key,
            operation_id="phase6_complete_publication_observation",
            job_id=receipt["receipt_id"],
            attempt_count=1,
            effective_general_before=int(basis["youtube-general-units-daily"]),
            units=QUOTA_UNIT_COSTS[api_method],
            preventive_floor=12,
            now=effect_now,
        )
        frozen = _general_quota_binding(reserved)
        checked = get_general_quota_debit(root, idempotency_key=key)
        if checked is None or _general_quota_binding(checked) != frozen:
            raise PermissionError("current-observation quota reservation changed before read")
        response_value = call()
        consumed = _general_quota_binding(
            consume_general_quota(root, idempotency_key=key, now=effect_now)
        )
        quota_debits.append(consumed)
        return response_value

    owned = quota_read(
        "CURRENT_CHANNEL_IDENTITY",
        "channels.list",
        lambda: youtube.channels().list(part="id", mine=True, fields="items(id)").execute(),
    )
    response = quota_read(
        "CURRENT_VIDEO_IDENTITY",
        "videos.list",
        lambda: youtube.videos().list(
            part="id,snippet,status", id=video_id, fields=VIDEO_LIST_FIELDS
        ).execute(),
    )
    captions = quota_read(
        "CURRENT_CAPTION_IDENTITY",
        "captions.list",
        lambda: youtube.captions().list(
            part="id,snippet", videoId=video_id,
            fields="items(id,snippet(videoId,language,name,isDraft,status,failureReason,trackKind))",
        ).execute(),
    )
    items = response.get("items") or [] if isinstance(response, dict) else []
    item = items[0] if len(items) == 1 else {}
    snippet = item.get("snippet") or {}
    status = item.get("status") or {}
    expected_tags = list(package["metadata"]["tags"]) + [marker]
    expected_caption_name = f"English [{marker}]"
    caption_matches = [
        value
        for value in ((captions or {}).get("items") or [])
        if value.get("id") == receipt.get("caption_id")
        and (value.get("snippet") or {}).get("videoId") == video_id
        and (value.get("snippet") or {}).get("language") == "en-US"
        and (value.get("snippet") or {}).get("name") == expected_caption_name
        and (value.get("snippet") or {}).get("isDraft") is False
        and (value.get("snippet") or {}).get("status") == "serving"
    ]
    checks = {
        "owned_channel": isinstance(owned, dict)
        and [entry.get("id") for entry in (owned.get("items") or [])] == [CHANNEL_ID],
        "exact_video": len(items) == 1 and item.get("id") == video_id,
        "channel": snippet.get("channelId") == CHANNEL_ID,
        "title": snippet.get("title") == package["metadata"]["title"],
        "description": snippet.get("description") == package["metadata"]["description"],
        "tags_and_marker": snippet.get("tags") == expected_tags and expected_tags.count(marker) == 1,
        "category": str(snippet.get("categoryId")) == package["metadata"]["category_id"],
        "languages": snippet.get("defaultLanguage") == package["metadata"]["default_language"]
        and snippet.get("defaultAudioLanguage") == package["metadata"]["default_audio_language"],
        "made_for_kids": status.get("selfDeclaredMadeForKids") is package["metadata"]["made_for_kids"],
        "synthetic_disclosure": status.get("containsSyntheticMedia") is package["disclosure"]["contains_synthetic_media"],
        "public_processed": status.get("privacyStatus") == "public"
        and status.get("uploadStatus") == "processed",
        "public_contract": status.get("embeddable") is True
        and status.get("publicStatsViewable") is True
        and status.get("license") == "youtube",
        "caption_serving": len(caption_matches) == 1,
    }
    thumbnail_similarity: float | None = None
    thumbnails = snippet.get("thumbnails") or {}
    public_url = next(
        ((thumbnails.get(name) or {}).get("url") for name in ("maxres", "standard", "high", "medium", "default") if (thumbnails.get(name) or {}).get("url")),
        None,
    )
    if isinstance(public_url, str) and public_url:
        local = _freeze_artifact_copy(root, receipt["core_binding"]["artifacts"]["thumbnail"], "thumbnail")
        observed_similarities: list[float] = []
        for attempt in range(3):
            separator = "&" if "?" in public_url else "?"
            payload = thumbnail_fetcher(f"{public_url}{separator}heroverse_observe={attempt}")
            try:
                with Image.open(io.BytesIO(payload)) as remote, Image.open(local) as frozen:
                    observed_similarities.append(_thumbnail_similarity(remote, frozen))
            except Exception:
                observed_similarities.append(0.0)
            if observed_similarities[-1] >= 0.75:
                break
        thumbnail_similarity = max(observed_similarities, default=0.0)
    checks["thumbnail"] = thumbnail_similarity is not None and thumbnail_similarity >= 0.75
    observed_at = _stamp()
    result = {
        "schema_version": "1.0.0",
        "observation_id": "phase6-publication-observation-" + _json_hash(
            {"receipt_id": receipt["receipt_id"], "observed_at": observed_at, "checks": checks,
             "thumbnail_similarity": thumbnail_similarity}
        )[:24],
        "receipt_id": receipt["receipt_id"], "video_id": video_id,
        "channel_id": CHANNEL_ID, "status": "PASS" if all(checks.values()) else "DRIFT",
        "checks": checks, "thumbnail_similarity": thumbnail_similarity,
        "quota_debits": quota_debits,
        "observed_at": observed_at, "technical_cost_brl": 0,
    }
    _validate(root, "phase6_publication_observation.schema.json", result)
    payload = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    immutable = root / BASE / "publication/current-observations" / f"{result['observation_id']}.json"
    _write_immutable_bytes(immutable, payload)
    _write(root / BASE / "publication/current-publication-observation.json", result)
    if result["status"] != "PASS":
        raise RuntimeError(
            "historical COMPLETE_PUBLIC is not current: "
            + ",".join(name for name, passed in checks.items() if not passed)
        )
    return result


def execute_phase6_publication_pipeline(
    youtube: Any,
    media_factory: Callable[..., Any],
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    thumbnail_fetcher: Callable[[str], bytes] | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    with PublicationLock(root):
        return _execute_phase6_publication_pipeline_locked(
            youtube,
            media_factory,
            root,
            created_at=created_at,
            thumbnail_fetcher=thumbnail_fetcher,
        )


def _execute_phase6_publication_pipeline_locked(
    youtube: Any,
    media_factory: Callable[..., Any],
    root: Path = ROOT,
    *,
    created_at: str | None = None,
    thumbnail_fetcher: Callable[[str], bytes] | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    release, package = _read(root / RELEASE), _read(root / PACKAGE)
    validation_now = _parse(created_at) if created_at else datetime.now(timezone.utc)
    _validate_release(root, release, now=validation_now)
    _validate(root, "phase6_publication_package.schema.json", package)
    if package.get("schema_version") != "1.2.0":
        raise PermissionError("legacy publication package cannot authorize an external effect")
    if package.get("package_id") != release["package_id"] or _package_identity(package) != package.get("package_id"):
        raise PermissionError("publication package identity is not bound to the release")
    receipt_path = root / PUBLICATION_RECEIPT
    existing = _read(receipt_path) if receipt_path.is_file() else None
    release_hashes = {
        name: release["artifacts"][name]["sha256"]
        for name in ("video", "thumbnail", "captions")
    }
    frozen_inputs = {
        name: _freeze_artifact_copy(root, release["artifacts"][name], name)
        for name in ("video", "thumbnail", "captions")
    }
    if existing:
        _validate(root, "youtube_publication_receipt.schema.json", existing)
        if existing.get("schema_version") != "1.3.0":
            raise PermissionError(
                "legacy publication receipt cannot authorize or satisfy the hardened Phase 6 transaction"
            )
        _validate_effect_journal(existing)
    if existing and existing["idempotency_key"] != release["idempotency_key"]:
        raise PermissionError("a different Phase 6 upload receipt exists; duplicate upload is blocked")
    if existing and (
        existing.get("release_id") != release["release_id"]
        or existing.get("channel_id") != CHANNEL_ID
        or existing.get("artifact_hashes") != release_hashes
        or existing.get("idempotency_marker")
        != _idempotency_marker(release["idempotency_key"])
    ):
        raise PermissionError("the existing publication receipt is not bound to the exact frozen release")
    core_binding = _receipt_core_binding(release)
    release_authorizations = list(existing.get("release_authorizations") or []) if existing else []
    if existing:
        if existing.get("core_binding") != core_binding:
            raise PermissionError(
                "the frozen publication core changed; refreshed readiness cannot replace package, quality or scope"
            )
        _validate_release_authorizations(root, release_authorizations, release["core_binding_id"])
        if existing["status"] == "COMPLETE_PUBLIC":
            verified_receipt = verify_phase6_publication_receipt(
                root,
                receipt_path=PUBLICATION_RECEIPT,
                require_complete=True,
            )
            if verified_receipt != existing:
                raise PermissionError("current publication receipt changed during semantic verification")
            _observe_complete_publication(
                youtube,
                thumbnail_fetcher or _fetch_public_thumbnail,
                root,
                package,
                existing,
            )
            return existing
    current_authorization = _freeze_release_authorization(root, release)
    prior_same_authorization = [
        item
        for item in release_authorizations
        if item["authorization_id"] == current_authorization["authorization_id"]
    ]
    if prior_same_authorization and prior_same_authorization != [current_authorization]:
        raise PermissionError("release authorization identity collided with different immutable bytes")
    if not prior_same_authorization:
        release_authorizations.append(current_authorization)
    created = existing["created_at"] if existing else (created_at or _stamp())
    video_id = existing.get("video_id") if existing else None
    caption_id = existing.get("caption_id") if existing else None
    steps = list(existing.get("steps") or []) if existing else []
    privacy = existing.get("privacy_status", "private") if existing else "private"
    effect_journal = list(existing.get("effect_journal") or []) if existing else []
    marker = _idempotency_marker(release["idempotency_key"])
    caption_track_name = f"English [{marker}]"
    fetch_thumbnail = thumbnail_fetcher or _fetch_public_thumbnail
    pipeline_attempt = int((existing or {}).get("attempt_count") or 0) + 1
    if not steps:
        steps.append(
            {
                "step": "INITIALIZE",
                "status": "NOT_RUN",
                "evidence": "transaction journal initialized before external effects",
            }
        )

    def completed(name: str) -> bool:
        return any(item["step"] == name and item["status"] == "PASS" for item in steps)

    def add(name: str, status: str, evidence: str) -> None:
        if status == "PASS" and completed(name):
            return
        steps.append({"step": name, "status": status, "evidence": evidence})

    def persist(status: str, *, error: str | None = None) -> dict[str, Any]:
        quota_by_binding: dict[str, dict[str, Any]] = {}
        for journal_item in effect_journal:
            quota_binding = journal_item.get("quota_debit")
            if isinstance(quota_binding, dict):
                quota_by_binding[str(quota_binding["binding_id"])] = quota_binding
        receipt = {
            "schema_version": "1.3.0",
            "receipt_id": f"youtube-publication-{release['idempotency_key'][:20]}",
            "release_id": release["release_id"],
            "idempotency_key": release["idempotency_key"],
            "idempotency_marker": marker,
            "channel_id": CHANNEL_ID,
            "status": status,
            "privacy_status": privacy,
            "video_id": video_id,
            "caption_id": caption_id,
            "attempt_count": pipeline_attempt,
            "retry_policy": {
                "non_idempotent_mutation_max_attempts": MAX_NON_IDEMPOTENT_MUTATION_ATTEMPTS,
                "idempotent_mutation_max_attempts": MAX_IDEMPOTENT_MUTATION_ATTEMPTS,
                "recovery_probe_max_attempts": MAX_RECOVERY_PROBES,
                "read_max_attempts": MAX_READ_ATTEMPTS,
                "on_exhaustion": "FAIL_CLOSED_NO_DUPLICATE_EFFECT",
                "recovery_window_seconds": RECOVERY_WINDOW_SECONDS,
                "read_attempt_semantics": "CONSECUTIVE_TRANSPORT_FAILURES_NOT_SUCCESSFUL_POLLS",
            },
            "steps": steps,
            "effect_journal": effect_journal,
            "core_binding": core_binding,
            "release_authorizations": release_authorizations,
            "quota_debits": list(quota_by_binding.values()),
            "artifact_hashes": release_hashes,
            "external_cost_brl": 0,
            "public_visibility_authorized": True,
            "error": error,
            "created_at": created,
            "updated_at": created_at or _stamp(),
        }
        _validate(root, "youtube_publication_receipt.schema.json", receipt)
        _validate_effect_journal(receipt)
        _validate_release_authorizations(root, release_authorizations, core_binding["binding_id"])
        _write(receipt_path, receipt)
        return receipt

    def effect_attempts(effect_id: str) -> int:
        return sum(
            1
            for item in effect_journal
            if item["effect_id"] == effect_id and item["checkpoint"] == "BEFORE"
        )

    def effect_started(effect_id: str) -> bool:
        return effect_attempts(effect_id) > 0

    def consecutive_read_failures(effect_id: str) -> int:
        failures = 0
        for item in reversed(effect_journal):
            if item["effect_id"] != effect_id or item["checkpoint"] != "AFTER":
                continue
            if item["outcome"] == "FAILED":
                failures += 1
                continue
            break
        return failures

    def require_recovery_window(effect_id: str) -> None:
        beginnings = [
            _parse(item["checkpointed_at"])
            for item in effect_journal
            if item["effect_id"] == effect_id and item["checkpoint"] == "BEFORE"
        ]
        if not beginnings:
            raise RuntimeError(f"cannot recover {effect_id} without persisted intent")
        current = _parse(created_at) if created_at else datetime.now(timezone.utc)
        age_seconds = max(0.0, (current - min(beginnings)).total_seconds())
        if age_seconds > RECOVERY_WINDOW_SECONDS:
            raise RuntimeError(
                f"recovery window exhausted for {effect_id}: {age_seconds:.3f}s; duplicate mutation blocked"
            )

    def confirmed_effect(effect_id: str) -> dict[str, Any] | None:
        return next(
            (
                item
                for item in reversed(effect_journal)
                if item["effect_id"] == effect_id
                and item["checkpoint"] == "AFTER"
                and item["outcome"] in {"CONFIRMED", "RECOVERED"}
            ),
            None,
        )

    def append_checkpoint(
        *,
        effect_id: str,
        api_method: str,
        kind: str,
        checkpoint: str,
        attempt: int,
        request_fingerprint: str,
        request_payload: dict[str, Any],
        quota_debit: dict[str, Any] | None,
        outcome: str,
        evidence: str,
        remote_resource_id: str | None = None,
    ) -> None:
        effect_journal.append(
            {
                "sequence": len(effect_journal) + 1,
                "effect_id": effect_id,
                "api_method": api_method,
                "kind": kind,
                "checkpoint": checkpoint,
                "attempt": attempt,
                "request_fingerprint": request_fingerprint,
                "request_payload": request_payload,
                "quota_debit": quota_debit,
                "authorization_id": release["authorization_id"],
                "outcome": outcome,
                "evidence": evidence,
                "remote_resource_id": remote_resource_id,
                "checkpointed_at": created_at or _stamp(),
            }
        )

    def working_status() -> str:
        return "IN_PROGRESS" if video_id is None else "PARTIAL_PRIVATE_VIDEO"

    def verification_waiting_status() -> str:
        return (
            "PUBLIC_AWAITING_VERIFICATION"
            if privacy == "public"
            else "STAGED_PRIVATE_AWAITING_PROCESSING"
        )

    def call_external(
        effect_id: str,
        api_method: str,
        kind: str,
        payload: dict[str, Any],
        call: Callable[[], Any],
        *,
        maximum_attempts: int,
        resource_id: Callable[[Any], str | None] | None = None,
        evidence: Callable[[Any], str] | None = None,
        validate_response: Callable[[Any], None] | None = None,
    ) -> Any:
        attempt = effect_attempts(effect_id) + 1
        recovery_probe = effect_id in {
            "UPLOAD_RECOVERY_PLAYLIST_PROBE",
            "UPLOAD_RECOVERY_VIDEO_PROBE",
            "CAPTION_RECOVERY_PROBE",
            "THUMBNAIL_RECOVERY_PROBE",
            "STAGED_THUMBNAIL_PROBE",
            "PUBLIC_THUMBNAIL_PROBE",
        }
        exhausted = (
            attempt > maximum_attempts
            if kind == "MUTATION" or recovery_probe
            else consecutive_read_failures(effect_id) >= maximum_attempts
        )
        if exhausted:
            raise RuntimeError(
                f"bounded {'mutation attempts' if kind == 'MUTATION' else 'consecutive read failures'} "
                f"exhausted for {effect_id}: {maximum_attempts}; no external effect executed"
            )
        effect_now = _parse(created_at) if created_at else datetime.now(timezone.utc)
        # Every effect reopens the exact frozen authorization and current-day
        # quota evidence. A READY label from an earlier day is never reusable.
        _validate_release(root, release, now=effect_now)
        _validate_release_authorizations(
            root, release_authorizations, core_binding["binding_id"]
        )
        request_fingerprint = _fingerprint(api_method, payload)
        prior_fingerprints = {
            item["request_fingerprint"]
            for item in effect_journal
            if item["effect_id"] == effect_id and item["checkpoint"] == "BEFORE"
        }
        if kind == "MUTATION" and prior_fingerprints and prior_fingerprints != {request_fingerprint}:
            raise PermissionError(
                f"idempotency fingerprint changed for {effect_id}; external effect blocked"
            )
        quota_cost = QUOTA_UNIT_COSTS[api_method]
        quota_key = f"{release['idempotency_key']}:{effect_id}:{attempt}"
        quota_source: dict[str, Any] | None = None
        quota_debit: dict[str, Any] | None = None
        if quota_cost:
            if api_method == "videos.insert":
                quota_source = reserve_composed_quota(
                    root,
                    idempotency_key=quota_key,
                    effect_id=effect_id,
                    attempt_count=attempt,
                    channel_id=CHANNEL_ID,
                    release_id=release["release_id"],
                    general_units=quota_cost,
                    now=effect_now,
                )
                quota_debit = _composed_quota_binding(quota_source)
            else:
                basis = effective_observation_quota_usage(root, now=effect_now)
                if basis is None:
                    raise PermissionError(
                        f"official free-quota basis unavailable before {effect_id}"
                    )
                quota_source = reserve_general_quota(
                    root,
                    idempotency_key=quota_key,
                    operation_id="phase6_publication_pipeline",
                    job_id=release["release_id"],
                    attempt_count=attempt,
                    effective_general_before=int(basis["youtube-general-units-daily"]),
                    units=quota_cost,
                    preventive_floor=12,
                    now=effect_now,
                )
                quota_debit = _general_quota_binding(quota_source)
        # A videos.insert debit has two independently bounded buckets.  Freeze
        # the exact in-day external-effect boundary before persisting the
        # provider intent; an orphaned marker remains charged conservatively.
        if quota_debit is not None and quota_debit["mode"] == "COMPOSED_UPLOAD":
            checked = revalidate_composed_quota(
                root,
                receipt_path=quota_debit["path"],
                receipt_sha256=quota_debit["sha256"],
                now=effect_now,
            )
            started = mark_composed_quota_effect_started(
                root,
                receipt_path=checked["path"],
                receipt_sha256=checked["sha256"],
                now=effect_now,
            )
            quota_debit = _composed_quota_binding(started)
        append_checkpoint(
            effect_id=effect_id,
            api_method=api_method,
            kind=kind,
            checkpoint="BEFORE",
            attempt=attempt,
            request_fingerprint=request_fingerprint,
            request_payload=payload,
            quota_debit=quota_debit,
            outcome="PENDING",
            evidence="intent persisted before provider call",
        )
        persist(working_status())
        if quota_debit is not None:
            if quota_debit["mode"] == "COMPOSED_UPLOAD":
                checked = revalidate_composed_quota(
                    root,
                    receipt_path=quota_debit["path"],
                    receipt_sha256=quota_debit["sha256"],
                    now=effect_now,
                )
                if _composed_quota_binding(checked) != quota_debit:
                    raise PermissionError("composed quota reservation changed before provider effect")
            else:
                checked = get_general_quota_debit(root, idempotency_key=quota_key)
                if checked is None or _general_quota_binding(checked) != quota_debit:
                    raise PermissionError("general quota reservation changed before provider effect")
                current_start, current_end = _quota_day(effect_now)
                if (
                    quota_debit["quota_day_start"] != _stamp(current_start)
                    or quota_debit["quota_day_end"] != _stamp(current_end)
                ):
                    raise PermissionError("general quota reservation crossed the Pacific reset")
        try:
            response = call()
            if validate_response:
                validate_response(response)
            remote_id = resource_id(response) if resource_id else None
            response_evidence = evidence(response) if evidence else "provider response received"
        except Exception as exc:
            append_checkpoint(
                effect_id=effect_id,
                api_method=api_method,
                kind=kind,
                checkpoint="AFTER",
                attempt=attempt,
                request_fingerprint=request_fingerprint,
                request_payload=payload,
                quota_debit=quota_debit,
                outcome="AMBIGUOUS" if kind == "MUTATION" else "FAILED",
                evidence=f"{type(exc).__name__}: {exc}",
            )
            persist(working_status(), error=f"{type(exc).__name__}: {exc}")
            raise
        append_checkpoint(
            effect_id=effect_id,
            api_method=api_method,
            kind=kind,
            checkpoint="AFTER",
            attempt=attempt,
            request_fingerprint=request_fingerprint,
            request_payload=payload,
            quota_debit=(
                _composed_quota_binding(
                    consume_composed_quota(
                        root,
                        receipt_path=quota_debit["path"],
                        receipt_sha256=quota_debit["sha256"],
                        confirmation_id=remote_id or f"response-{_json_hash(response)[:24]}",
                        confirmation_sha256=_json_hash(response),
                        now=effect_now,
                    )
                )
                if quota_debit is not None and quota_debit["mode"] == "COMPOSED_UPLOAD"
                else (
                    _general_quota_binding(
                        consume_general_quota(root, idempotency_key=quota_key, now=effect_now)
                    )
                    if quota_debit is not None
                    else None
                )
            ),
            outcome="CONFIRMED",
            evidence=response_evidence,
            remote_resource_id=remote_id,
        )
        persist(working_status())
        return response

    def require_mapping(response: Any, api_method: str) -> None:
        if not isinstance(response, dict):
            raise RuntimeError(f"{api_method} returned a non-object response")

    def response_id(response: Any, api_method: str, *, expected: str | None = None) -> str:
        require_mapping(response, api_method)
        remote_id = response.get("id")
        if not isinstance(remote_id, str) or not remote_id:
            raise RuntimeError(f"{api_method} returned no resource id")
        if expected is not None and remote_id != expected:
            raise RuntimeError(
                f"{api_method} returned a different resource id: expected {expected}, observed {remote_id}"
            )
        return remote_id

    def require_thumbnail_response(response: Any) -> None:
        require_mapping(response, "thumbnails.set")
        items = response.get("items")
        variants = ("maxres", "standard", "high", "medium", "default")
        if (
            not isinstance(items, list)
            or not items
            or not any(
                isinstance((item or {}).get(name), dict)
                and isinstance((item or {}).get(name, {}).get("url"), str)
                and bool((item or {}).get(name, {}).get("url"))
                for item in items
                for name in variants
            )
        ):
            raise RuntimeError("thumbnails.set returned no confirmed thumbnail resource")

    def recover_effect(
        effect_id: str,
        api_method: str,
        remote_resource_id: str | None,
        evidence: str,
    ) -> None:
        if confirmed_effect(effect_id) is not None:
            raise RuntimeError(f"cannot append RECOVERED after {effect_id} is already confirmed")
        previous = next(
            (
                item
                for item in reversed(effect_journal)
                if item["effect_id"] == effect_id and item["checkpoint"] == "BEFORE"
            ),
            None,
        )
        if previous is None:
            raise RuntimeError(f"cannot recover {effect_id} without a persisted pre-effect checkpoint")
        prior_quota = previous.get("quota_debit")
        if not isinstance(prior_quota, dict):
            raise PermissionError(f"cannot recover {effect_id} without its frozen quota debit")
        recovery_now = _parse(created_at) if created_at else datetime.now(timezone.utc)
        if prior_quota["mode"] == "COMPOSED_UPLOAD":
            consumed_quota = _composed_quota_binding(
                consume_composed_quota(
                    root,
                    receipt_path=prior_quota["path"],
                    receipt_sha256=prior_quota["sha256"],
                    confirmation_id=remote_resource_id or f"recovered-{effect_id}",
                    confirmation_sha256=_json_hash(
                        {"remote_resource_id": remote_resource_id, "evidence": evidence}
                    ),
                    now=recovery_now,
                )
            )
        else:
            consumed_quota = _general_quota_binding(
                consume_general_quota(
                    root,
                    idempotency_key=prior_quota["idempotency_key"],
                    now=recovery_now,
                )
            )
        append_checkpoint(
            effect_id=effect_id,
            api_method=api_method,
            kind="MUTATION",
            checkpoint="AFTER",
            attempt=int(previous["attempt"]),
            request_fingerprint=previous["request_fingerprint"],
            request_payload=previous["request_payload"],
            quota_debit=consumed_quota,
            outcome="RECOVERED",
            evidence=evidence,
            remote_resource_id=remote_resource_id,
        )
        persist(working_status())

    def video_item_evidence(item: dict[str, Any]) -> str:
        status = item.get("status") or {}
        return (
            f"videoId={item.get('id')};channelId={(item.get('snippet') or {}).get('channelId')};"
            f"privacy={status.get('privacyStatus')};uploadStatus={status.get('uploadStatus')}"
        )

    def verify_remote_thumbnail(item: dict[str, Any], effect_id: str) -> float:
        thumbnails = (item.get("snippet") or {}).get("thumbnails") or {}
        public_url = next(
            (
                (thumbnails.get(name) or {}).get("url")
                for name in ("maxres", "standard", "high", "medium", "default")
                if (thumbnails.get(name) or {}).get("url")
            ),
            None,
        )
        if not isinstance(public_url, str) or not public_url:
            raise RuntimeError("public thumbnail URL is unavailable after thumbnails.set")
        local_path = frozen_inputs["thumbnail"]
        similarities: list[float] = []
        for verification_attempt in range(3):
            separator = "&" if "?" in public_url else "?"
            cache_busted = f"{public_url}{separator}heroverse_verify={verification_attempt}"

            def fetch_and_compare() -> dict[str, Any]:
                payload = fetch_thumbnail(cache_busted)
                if not isinstance(payload, bytes) or not payload:
                    raise RuntimeError("thumbnail fetcher returned no image bytes")
                with Image.open(io.BytesIO(payload)) as public_image, Image.open(local_path) as local_image:
                    similarity = _thumbnail_similarity(public_image, local_image)
                return {
                    "url_sha256": hashlib.sha256(public_url.encode("utf-8")).hexdigest(),
                    "bytes_sha256": hashlib.sha256(payload).hexdigest(),
                    "size_bytes": len(payload),
                    "similarity": similarity,
                }

            result = call_external(
                effect_id,
                "thumbnail.fetch",
                "READ",
                {
                    "videoId": video_id,
                    "thumbnail_sha256": package["thumbnail"]["sha256"],
                    "url_sha256": hashlib.sha256(public_url.encode("utf-8")).hexdigest(),
                    "verification_attempt": verification_attempt,
                },
                fetch_and_compare,
                maximum_attempts=MAX_RECOVERY_PROBES,
                evidence=lambda value: (
                    f"videoId={video_id};thumbnail_similarity={value['similarity']};"
                    f"bytes_sha256={value['bytes_sha256']}"
                ),
            )
            similarities.append(float(result["similarity"]))
            if similarities[-1] >= 0.75:
                return similarities[-1]
            if verification_attempt < 2:
                time.sleep(2)
        raise RuntimeError(
            f"public thumbnail verification similarity too low: {max(similarities, default=0.0)}"
        )

    def exact_video_item(
        response: Any,
        *,
        context: str,
        expected_privacies: set[str],
        require_processed: bool = False,
        require_thumbnail: bool = False,
        require_public_contract: bool = False,
    ) -> dict[str, Any]:
        require_mapping(response, "videos.list")
        items = response.get("items") or []
        if len(items) != 1:
            raise RuntimeError(f"{context}: exact video was not returned once")
        item = items[0]
        snippet = item.get("snippet") or {}
        status = item.get("status") or {}
        expected_tags = list(package["metadata"]["tags"]) + [marker]
        observed_tags = snippet.get("tags") or []
        checks = {
            "id": item.get("id") == video_id,
            "channel": snippet.get("channelId") == CHANNEL_ID,
            "marker_exactly_once": observed_tags.count(marker) == 1,
            "tags": observed_tags == expected_tags,
            "title": snippet.get("title") == package["metadata"]["title"],
            "description": snippet.get("description") == package["metadata"]["description"],
            "category": str(snippet.get("categoryId")) == package["metadata"]["category_id"],
            "default_language": snippet.get("defaultLanguage") == package["metadata"]["default_language"],
            "default_audio_language": snippet.get("defaultAudioLanguage") == package["metadata"]["default_audio_language"],
            "made_for_kids": status.get("selfDeclaredMadeForKids") is package["metadata"]["made_for_kids"],
            "synthetic_disclosure": status.get("containsSyntheticMedia") is package["disclosure"]["contains_synthetic_media"],
            "privacy": status.get("privacyStatus") in expected_privacies,
            "processed": (not require_processed) or status.get("uploadStatus") == "processed",
            "thumbnail": (not require_thumbnail) or bool(snippet.get("thumbnails")),
            "embeddable": (not require_public_contract) or status.get("embeddable") is True,
            "public_stats": (not require_public_contract) or status.get("publicStatsViewable") is True,
            "license": (not require_public_contract) or status.get("license") == "youtube",
        }
        failed = [name for name, passed in checks.items() if not passed]
        if failed:
            raise RuntimeError(f"{context}: exact staged-video binding failed: {','.join(failed)}")
        return item

    try:
        owned_response = call_external(
            "CHANNEL_IDENTITY_PROBE",
            "channels.list",
            "READ",
            {"part": "id,snippet,contentDetails", "mine": True},
            lambda: youtube.channels()
            .list(
                part="id,snippet,contentDetails",
                mine=True,
                fields="items(id,snippet/customUrl,contentDetails/relatedPlaylists/uploads)",
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: f"owned_items={len(response.get('items') or [])}",
        )
        owned = owned_response.get("items") or []
        observed = owned[0]["id"] if len(owned) == 1 else None
        if observed != CHANNEL_ID:
            raise PermissionError(f"owned channel mismatch: expected {CHANNEL_ID}, observed {observed}")
        add("CHANNEL_IDENTITY", "PASS", observed)
        if video_id is None:
            prior_upload = confirmed_effect("VIDEO_PRIVATE_UPLOAD")
            if prior_upload and prior_upload.get("remote_resource_id"):
                video_id = str(prior_upload["remote_resource_id"])
                privacy = "private"
                add("VIDEO_PRIVATE_UPLOAD", "PASS", f"receipt-recovered:{video_id}")
                persist("PARTIAL_PRIVATE_VIDEO")
            elif effect_started("VIDEO_PRIVATE_UPLOAD"):
                require_recovery_window("VIDEO_PRIVATE_UPLOAD")
                uploads_playlist = (
                    ((owned[0].get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
                )
                if not uploads_playlist:
                    raise RuntimeError(
                        "upload recovery cannot read the owned uploads playlist; duplicate upload blocked"
                    )
                playlist_response = call_external(
                    "UPLOAD_RECOVERY_PLAYLIST_PROBE",
                    "playlistItems.list",
                    "READ",
                    {"playlistId": uploads_playlist, "maxResults": 50},
                    lambda: youtube.playlistItems()
                    .list(
                        part="contentDetails",
                        playlistId=uploads_playlist,
                        maxResults=50,
                        fields="items(contentDetails/videoId)",
                    )
                    .execute(),
                    maximum_attempts=MAX_RECOVERY_PROBES,
                    evidence=lambda response: f"candidate_count={len(response.get('items') or [])}",
                )
                candidate_ids = [
                    str((item.get("contentDetails") or {}).get("videoId"))
                    for item in (playlist_response.get("items") or [])
                    if (item.get("contentDetails") or {}).get("videoId")
                ]
                candidate_items: list[dict[str, Any]] = []
                if candidate_ids:
                    recovery_response = call_external(
                        "UPLOAD_RECOVERY_VIDEO_PROBE",
                        "videos.list",
                        "READ",
                        {"ids": candidate_ids, "marker": marker},
                        lambda: youtube.videos()
                        .list(
                            part="id,snippet,status,contentDetails",
                            id=",".join(candidate_ids),
                            fields=VIDEO_LIST_FIELDS,
                        )
                        .execute(),
                        maximum_attempts=MAX_RECOVERY_PROBES,
                        evidence=lambda response: f"inspected_count={len(response.get('items') or [])}",
                    )
                    upload_intent = min(
                        _parse(item["checkpointed_at"])
                        for item in effect_journal
                        if item["effect_id"] == "VIDEO_PRIVATE_UPLOAD"
                        and item["checkpoint"] == "BEFORE"
                    )
                    recovery_now = _parse(created_at) if created_at else datetime.now(timezone.utc)
                    expected_tags = list(package["metadata"]["tags"]) + [marker]

                    def exact_recovery_candidate(item: dict[str, Any]) -> bool:
                        snippet = item.get("snippet") or {}
                        status = item.get("status") or {}
                        observed_duration = _youtube_duration_ms(
                            (item.get("contentDetails") or {}).get("duration")
                        )
                        try:
                            published_at = _parse(str(snippet.get("publishedAt")))
                        except Exception:
                            return False
                        return bool(
                            isinstance(item.get("id"), str)
                            and item.get("id") in candidate_ids
                            and snippet.get("channelId") == CHANNEL_ID
                            and snippet.get("title") == package["metadata"]["title"]
                            and snippet.get("description") == package["metadata"]["description"]
                            and snippet.get("tags") == expected_tags
                            and expected_tags.count(marker) == 1
                            and str(snippet.get("categoryId")) == package["metadata"]["category_id"]
                            and snippet.get("defaultLanguage") == package["metadata"]["default_language"]
                            and snippet.get("defaultAudioLanguage") == package["metadata"]["default_audio_language"]
                            and status.get("selfDeclaredMadeForKids")
                            is package["metadata"]["made_for_kids"]
                            and status.get("containsSyntheticMedia")
                            is package["disclosure"]["contains_synthetic_media"]
                            and status.get("privacyStatus") == "private"
                            and status.get("uploadStatus") in {"uploaded", "processed"}
                            and observed_duration is not None
                            and abs(observed_duration - int(package["video"]["duration_ms"])) <= 1000
                            and upload_intent - timedelta(minutes=5)
                            <= published_at
                            <= recovery_now + timedelta(minutes=5)
                        )

                    candidate_items = [
                        item
                        for item in (recovery_response.get("items") or [])
                        if exact_recovery_candidate(item)
                    ]
                if len(candidate_items) != 1:
                    raise RuntimeError(
                        "upload effect is ambiguous after persisted intent: "
                        f"marker_matches={len(candidate_items)}; duplicate upload blocked"
                    )
                recovered = candidate_items[0]
                video_id = str(recovered["id"])
                privacy = str((recovered.get("status") or {}).get("privacyStatus") or "private")
                recover_effect(
                    "VIDEO_PRIVATE_UPLOAD",
                    "videos.insert",
                    video_id,
                    f"owned uploads probe matched exact idempotency marker {marker}; "
                    f"{video_item_evidence(recovered)}",
                )
                add("VIDEO_PRIVATE_UPLOAD", "PASS", f"probe-recovered:{video_id}")
                persist("PARTIAL_PRIVATE_VIDEO")
            else:
                metadata = package["metadata"]
                body_tags = list(metadata["tags"])
                if marker not in body_tags:
                    body_tags.append(marker)
                body = build_youtube_video_body(
                    {
                        "title": metadata["title"],
                        "description": metadata["description"],
                        "tags": body_tags,
                        "category_id": metadata["category_id"],
                        "language": metadata["default_language"],
                        "audio_language": metadata["default_audio_language"],
                        "privacy_status": "private",
                        "made_for_kids": metadata["made_for_kids"],
                        "contains_synthetic_media": package["disclosure"]["contains_synthetic_media"],
                    }
                )
                response = call_external(
                    "VIDEO_PRIVATE_UPLOAD",
                    "videos.insert",
                    "MUTATION",
                    {"body": body, "video_sha256": release_hashes["video"], "notifySubscribers": False},
                    lambda: _execute_upload(
                        youtube.videos().insert(
                            part="snippet,status",
                            body=body,
                            notifySubscribers=False,
                            media_body=media_factory(
                                str(frozen_inputs["video"]), chunksize=-1, resumable=True
                            ),
                        )
                    ),
                    maximum_attempts=MAX_NON_IDEMPOTENT_MUTATION_ATTEMPTS,
                    resource_id=lambda result: response_id(result, "videos.insert"),
                    evidence=lambda result: (
                        f"videoId={result.get('id')};privacy=private;marker={marker}"
                    ),
                )
                if not response.get("id"):
                    raise RuntimeError(
                        "videos.insert returned no video id; recovery marker probe is required"
                    )
                video_id = str(response["id"])
                privacy = "private"
                add("VIDEO_PRIVATE_UPLOAD", "PASS", video_id)
                persist("PARTIAL_PRIVATE_VIDEO")
        _validate_release(root, release, now=validation_now)
        staged_response = call_external(
            "STAGED_VIDEO_IDENTITY_PROBE",
            "videos.list",
            "READ",
            {
                "videoId": video_id,
                "expectedChannelId": CHANNEL_ID,
                "expectedMarker": marker,
                "expectedTitle": package["metadata"]["title"],
                "expectedPrivacy": "private-before-mutations",
            },
            lambda: youtube.videos()
            .list(
                part="id,status,snippet",
                id=video_id,
                fields=VIDEO_LIST_FIELDS,
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: video_item_evidence((response.get("items") or [{}])[0]),
        )
        pending_staging_mutation = not completed("THUMBNAIL_SET") or not completed("CAPTIONS_INSERT")
        staged = exact_video_item(
            staged_response,
            context="pre-staging-mutation",
            expected_privacies={"private"} if pending_staging_mutation else {"private", "public"},
        )
        privacy = str((staged.get("status") or {}).get("privacyStatus"))
        add(
            "STAGED_VIDEO_IDENTITY_VERIFY",
            "PASS",
            f"videoId={video_id};channelId={CHANNEL_ID};marker={marker};title=exact;privacy={privacy}",
        )
        persist("PARTIAL_PRIVATE_VIDEO")
        if not completed("THUMBNAIL_SET"):
            if confirmed_effect("THUMBNAIL_SET"):
                add(
                    "THUMBNAIL_SET",
                    "PASS",
                    f"receipt-recovered:{package['thumbnail']['candidate_id']}",
                )
                persist("PARTIAL_PRIVATE_VIDEO")
            elif effect_started("THUMBNAIL_SET"):
                # thumbnails.set is externally ambiguous after a crash until the
                # exact frozen rendition is visible from YouTube's own CDN.  A
                # second set call would hide the first attempt and leave an
                # unresolved journal entry, so recover only from perceptual
                # equality and otherwise fail closed without another mutation.
                require_recovery_window("THUMBNAIL_SET")
                recovered_similarity = verify_remote_thumbnail(
                    staged,
                    "THUMBNAIL_RECOVERY_PROBE",
                )
                recover_effect(
                    "THUMBNAIL_SET",
                    "thumbnails.set",
                    video_id,
                    "YouTube CDN matched the exact frozen thumbnail after an "
                    f"ambiguous set; similarity={recovered_similarity}; threshold=0.75",
                )
                add(
                    "THUMBNAIL_SET",
                    "PASS",
                    f"probe-recovered:{package['thumbnail']['candidate_id']}",
                )
                persist("PARTIAL_PRIVATE_VIDEO")
            else:
                call_external(
                    "THUMBNAIL_SET",
                    "thumbnails.set",
                    "MUTATION",
                    {"videoId": video_id, "thumbnail_sha256": release_hashes["thumbnail"]},
                    lambda: youtube.thumbnails()
                    .set(
                        videoId=video_id,
                        media_body=media_factory(
                            str(frozen_inputs["thumbnail"]),
                            mimetype="image/jpeg",
                            resumable=False,
                        ),
                    )
                    .execute(),
                    maximum_attempts=MAX_IDEMPOTENT_MUTATION_ATTEMPTS,
                    evidence=lambda _response: (
                        f"videoId={video_id};thumbnail_sha256={release_hashes['thumbnail']}"
                    ),
                    validate_response=require_thumbnail_response,
                )
                add("THUMBNAIL_SET", "PASS", package["thumbnail"]["candidate_id"])
                persist("PARTIAL_PRIVATE_VIDEO")
        if completed("CAPTIONS_INSERT") and not completed("CAPTION_TARGET_IDENTITY_VERIFY"):
            raise PermissionError(
                "caption mutation lacks a persisted pre-effect identity proof; legacy continuation blocked"
            )
        if not completed("CAPTIONS_INSERT"):
            caption_target_response = call_external(
                "CAPTION_TARGET_IDENTITY_PROBE",
                "videos.list",
                "READ",
                {
                    "videoId": video_id,
                    "expectedChannelId": CHANNEL_ID,
                    "expectedMarker": marker,
                    "expectedTitle": package["metadata"]["title"],
                    "expectedPrivacy": "private",
                },
                lambda: youtube.videos()
                .list(
                    part="id,status,snippet",
                    id=video_id,
                    fields=VIDEO_LIST_FIELDS,
                )
                .execute(),
                maximum_attempts=MAX_READ_ATTEMPTS,
                evidence=lambda response: video_item_evidence(
                    (response.get("items") or [{}])[0]
                ),
            )
            exact_video_item(
                caption_target_response,
                context="pre-caption-mutation",
                expected_privacies={"private"},
            )
            add(
                "CAPTION_TARGET_IDENTITY_VERIFY",
                "PASS",
                f"videoId={video_id};channelId={CHANNEL_ID};marker={marker};title=exact;privacy=private",
            )
            persist("PARTIAL_PRIVATE_VIDEO")
        if caption_id is None:
            prior_caption = confirmed_effect("CAPTIONS_INSERT")
            if prior_caption and prior_caption.get("remote_resource_id"):
                caption_id = str(prior_caption["remote_resource_id"])
                add("CAPTIONS_INSERT", "PASS", f"receipt-recovered:{caption_id}")
                persist("PARTIAL_PRIVATE_VIDEO")
            elif effect_started("CAPTIONS_INSERT"):
                require_recovery_window("CAPTIONS_INSERT")
                caption_response = call_external(
                    "CAPTION_RECOVERY_PROBE",
                    "captions.list",
                    "READ",
                    {
                        "videoId": video_id,
                        "language": "en-US",
                        "name": caption_track_name,
                    },
                    lambda: youtube.captions()
                    .list(
                        part="id,snippet",
                        videoId=video_id,
                        fields="items(id,snippet(videoId,language,name,isDraft,status,failureReason,trackKind))",
                    )
                    .execute(),
                    maximum_attempts=MAX_RECOVERY_PROBES,
                    evidence=lambda response: f"caption_count={len(response.get('items') or [])}",
                )
                matches = [
                    item
                    for item in (caption_response.get("items") or [])
                    if (item.get("snippet") or {}).get("language") == "en-US"
                    and (item.get("snippet") or {}).get("name") == caption_track_name
                    and (item.get("snippet") or {}).get("isDraft") is False
                    and (item.get("snippet") or {}).get("videoId") == video_id
                ]
                if len(matches) != 1:
                    raise RuntimeError(
                        "caption effect is ambiguous after persisted intent: "
                        f"matches={len(matches)}; duplicate caption blocked"
                    )
                caption_id = str(matches[0]["id"])
                recover_effect(
                    "CAPTIONS_INSERT",
                    "captions.insert",
                    caption_id,
                    "captions.list matched exact video/language/name/draft tuple; "
                    f"captionId={caption_id}",
                )
                add("CAPTIONS_INSERT", "PASS", f"probe-recovered:{caption_id}")
                persist("PARTIAL_PRIVATE_VIDEO")
            else:
                response = call_external(
                    "CAPTIONS_INSERT",
                    "captions.insert",
                    "MUTATION",
                    {
                        "videoId": video_id,
                        "language": "en-US",
                        "name": caption_track_name,
                        "captions_sha256": release_hashes["captions"],
                    },
                    lambda: youtube.captions()
                    .insert(
                        part="snippet",
                        body={
                            "snippet": {
                                "videoId": video_id,
                                "language": "en-US",
                                "name": caption_track_name,
                                "isDraft": False,
                            }
                        },
                        media_body=media_factory(
                            str(frozen_inputs["captions"]),
                            mimetype="application/octet-stream",
                            resumable=False,
                        ),
                    )
                    .execute(),
                    maximum_attempts=MAX_NON_IDEMPOTENT_MUTATION_ATTEMPTS,
                    resource_id=lambda result: response_id(result, "captions.insert"),
                    evidence=lambda result: (
                        f"videoId={video_id};captionId={result.get('id')};"
                        f"captions_sha256={release_hashes['captions']}"
                    ),
                )
                if not response.get("id"):
                    raise RuntimeError(
                        "captions.insert returned no caption id; captions.list recovery is required"
                    )
                caption_id = str(response["id"])
                add("CAPTIONS_INSERT", "PASS", caption_id)
                persist("PARTIAL_PRIVATE_VIDEO")
        caption_response = call_external(
            "CAPTION_SERVING_PROBE",
            "captions.list",
            "READ",
            {"videoId": video_id, "captionId": caption_id, "expectedStatus": "serving"},
            lambda: youtube.captions()
            .list(
                part="id,snippet",
                videoId=video_id,
                fields="items(id,snippet(videoId,language,name,isDraft,status,failureReason,trackKind))",
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: f"caption_count={len(response.get('items') or [])}",
        )
        caption_matches = [
            item
            for item in (caption_response.get("items") or [])
            if item.get("id") == caption_id
            and (item.get("snippet") or {}).get("videoId") == video_id
            and (item.get("snippet") or {}).get("language") == "en-US"
            and (item.get("snippet") or {}).get("name") == caption_track_name
            and (item.get("snippet") or {}).get("isDraft") is False
        ]
        if len(caption_matches) != 1:
            return persist(verification_waiting_status())
        caption_snippet = caption_matches[0].get("snippet") or {}
        caption_status = caption_snippet.get("status")
        if caption_status == "failed":
            raise RuntimeError(
                "caption processing failed: " + str(caption_snippet.get("failureReason") or "UNAVAILABLE")
            )
        if caption_status != "serving":
            return persist(verification_waiting_status())
        add("CAPTIONS_SERVING", "PASS", f"captionId={caption_id};status=serving;videoId={video_id}")
        persist("PARTIAL_PRIVATE_VIDEO")
        observed_response = call_external(
            "VIDEO_PROCESSING_PROBE",
            "videos.list",
            "READ",
            {"videoId": video_id, "expectedChannelId": CHANNEL_ID},
            lambda: youtube.videos()
            .list(
                part="id,status,snippet",
                id=video_id,
                fields=VIDEO_LIST_FIELDS,
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: video_item_evidence((response.get("items") or [{}])[0]),
        )
        observed_video = exact_video_item(
            observed_response,
            context="pre-publication",
            expected_privacies={"private", "public"} if effect_started("PROMOTE_PUBLIC") else {"private"},
            require_thumbnail=True,
        )
        privacy = str((observed_video.get("status") or {}).get("privacyStatus"))
        add("POST_UPLOAD_IDENTITY_VERIFY", "PASS", f"videoId={video_id};channelId={CHANNEL_ID};marker={marker};title=exact;privacy={privacy}")
        if (observed_video.get("status") or {}).get("uploadStatus") != "processed":
            return persist(verification_waiting_status())
        if not completed("STAGED_THUMBNAIL_VERIFY"):
            staged_thumbnail_similarity = verify_remote_thumbnail(
                observed_video,
                "STAGED_THUMBNAIL_PROBE",
            )
            add(
                "STAGED_THUMBNAIL_VERIFY",
                "PASS",
                f"videoId={video_id};similarity={staged_thumbnail_similarity};threshold=0.75",
            )
            persist("PARTIAL_PRIVATE_VIDEO")
        if privacy == "public" and not completed("PROMOTE_PUBLIC"):
            if confirmed_effect("PROMOTE_PUBLIC") is not None:
                add("PROMOTE_PUBLIC", "PASS", "receipt-recovered:privacyStatus=public")
            elif effect_started("PROMOTE_PUBLIC"):
                recover_effect(
                    "PROMOTE_PUBLIC",
                    "videos.update",
                    video_id,
                    "videos.list proved the exact staged video is already public; "
                    "duplicate mutation skipped",
                )
                add("PROMOTE_PUBLIC", "PASS", "probe-recovered:privacyStatus=public")
            else:
                raise RuntimeError("video became public without a persisted promotion intent")
            persist("PARTIAL_PRIVATE_VIDEO")
        elif privacy != "public" and confirmed_effect("PROMOTE_PUBLIC"):
            return persist("PARTIAL_PRIVATE_VIDEO")
        elif privacy != "public":
            _validate_release(root, release, now=validation_now)
            metadata = package["metadata"]
            public_body = {
                "id": video_id,
                "status": {
                    "privacyStatus": "public",
                    "selfDeclaredMadeForKids": metadata["made_for_kids"],
                    "containsSyntheticMedia": package["disclosure"]["contains_synthetic_media"],
                    "embeddable": True,
                    "publicStatsViewable": True,
                    "license": "youtube",
                },
            }
            call_external(
                "PROMOTE_PUBLIC",
                "videos.update",
                "MUTATION",
                public_body,
                lambda: youtube.videos().update(part="status", body=public_body).execute(),
                maximum_attempts=MAX_IDEMPOTENT_MUTATION_ATTEMPTS,
                resource_id=lambda result: response_id(
                    result, "videos.update", expected=str(video_id)
                ),
                evidence=lambda _result: f"videoId={video_id};privacyStatus=public",
            )
            add("PROMOTE_PUBLIC", "PASS", "videos.update(status.privacyStatus=public)")
            privacy = "public"
            persist("PARTIAL_PRIVATE_VIDEO")
        final_response = call_external(
            "FINAL_PUBLIC_PROBE",
            "videos.list",
            "READ",
            {"videoId": video_id, "expectedPrivacy": "public", "expectedChannelId": CHANNEL_ID},
            lambda: youtube.videos()
            .list(
                part="id,status,snippet",
                id=video_id,
                fields=VIDEO_LIST_FIELDS,
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: video_item_evidence((response.get("items") or [{}])[0]),
        )
        final_video = exact_video_item(
            final_response,
            context="final-publication",
            expected_privacies={"public"},
            require_processed=True,
            require_thumbnail=True,
            require_public_contract=True,
        )
        privacy = "public"
        add("PUBLIC_POST_UPLOAD_VERIFY", "PASS", f"videoId={video_id};privacy=public;processed=true;channelId={CHANNEL_ID}")
        final_caption_response = call_external(
            "FINAL_CAPTION_SERVING_PROBE",
            "captions.list",
            "READ",
            {
                "videoId": video_id,
                "captionId": caption_id,
                "expectedStatus": "serving-after-public-promotion",
            },
            lambda: youtube.captions()
            .list(
                part="id,snippet",
                videoId=video_id,
                fields="items(id,snippet(videoId,language,name,isDraft,status,failureReason,trackKind))",
            )
            .execute(),
            maximum_attempts=MAX_READ_ATTEMPTS,
            evidence=lambda response: f"caption_count={len(response.get('items') or [])}",
        )
        final_caption_matches = [
            item
            for item in (final_caption_response.get("items") or [])
            if item.get("id") == caption_id
            and (item.get("snippet") or {}).get("videoId") == video_id
            and (item.get("snippet") or {}).get("language") == "en-US"
            and (item.get("snippet") or {}).get("name") == caption_track_name
            and (item.get("snippet") or {}).get("isDraft") is False
        ]
        if len(final_caption_matches) != 1:
            return persist("PUBLIC_AWAITING_VERIFICATION")
        final_caption_snippet = final_caption_matches[0].get("snippet") or {}
        if final_caption_snippet.get("status") == "failed":
            raise RuntimeError(
                "caption processing failed after public promotion: "
                + str(final_caption_snippet.get("failureReason") or "UNAVAILABLE")
            )
        if final_caption_snippet.get("status") != "serving":
            return persist("PUBLIC_AWAITING_VERIFICATION")
        add(
            "FINAL_CAPTIONS_SERVING",
            "PASS",
            f"captionId={caption_id};status=serving;videoId={video_id};privacy=public",
        )
        public_thumbnail_similarity = verify_remote_thumbnail(
            final_video,
            "PUBLIC_THUMBNAIL_PROBE",
        )
        add(
            "PUBLIC_THUMBNAIL_VERIFY",
            "PASS",
            f"videoId={video_id};similarity={public_thumbnail_similarity};threshold=0.75",
        )
        return persist("COMPLETE_PUBLIC")
    except Exception as exc:
        add("FAILURE", "FAIL", f"{type(exc).__name__}: {exc}")
        failure_status = (
            "FAILED_PRE_UPLOAD"
            if video_id is None
            else (
                "PUBLIC_AWAITING_VERIFICATION"
                if privacy == "public"
                else "PARTIAL_PRIVATE_VIDEO"
            )
        )
        receipt = persist(failure_status, error=f"{type(exc).__name__}: {exc}")
        raise RuntimeError(receipt["error"]) from exc


def _build_live_service(token_path: Path) -> tuple[Any, Callable[..., Any]]:
    from google.oauth2.credentials import Credentials  # type: ignore
    from googleapiclient.discovery import build  # type: ignore
    from googleapiclient.http import MediaFileUpload  # type: ignore

    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("production OAuth token is invalid at upload boundary")
    return build("youtube", "v3", credentials=credentials, cache_discovery=False), MediaFileUpload


def _record_public_lot(root: Path, video_id: str, receipt: dict[str, Any]) -> None:
    plan_path = root / "output/operations/phase6/pilot-plan.json"
    plan = _read(plan_path)
    if video_id not in plan["lot"]["published_video_ids"]:
        if len(plan["lot"]["published_video_ids"]) >= plan["lot"]["maximum_long_videos"]:
            raise PermissionError("controlled Phase 6 lot is already full")
        plan["lot"]["published_video_ids"].append(video_id)
        _write(plan_path, plan)
    _write(root / BASE / "publication/lot-update-receipt.json", {"schema_version": "1.0.0", "video_id": video_id, "publication_receipt_id": receipt["receipt_id"], "published_video_ids": plan["lot"]["published_video_ids"], "maximum_long_videos": plan["lot"]["maximum_long_videos"], "technical_cost_brl": 0, "created_at": _stamp()})


def run_phase6_publication_controller(root: Path = ROOT, *, token_path: Path | None = None, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    timestamp = _stamp(current)
    quality_context, wait_reason = _quality_ready(root)
    status, release_decision, privacy = "WAITING", "WAIT", "none"
    quality_id = (
        quality_context["evaluation"]["evaluation_id"] if quality_context else None
    )
    package_ref: str | None = None
    release_ref: str | None = None
    receipt_ref: str | None = None
    youtube_video_id: str | None = None
    blockers: list[str] = []
    error: str | None = None
    next_action = wait_reason or "Wait for an independent quality PASS."
    if quality_context is not None:
        token = token_path or (Path(os.environ["HERO_YT_TOKEN_PATH"]) if os.environ.get("HERO_YT_TOKEN_PATH") else None)
        if token is None or not token.is_file():
            status, release_decision = "BLOCKED", "BLOCKED"
            blockers = ["HERO_YT_TOKEN_PATH_UNAVAILABLE"]
            next_action = "Restore the existing external OAuth token path; do not launch interactive consent from the controller."
        else:
            try:
                refresh_channel_readiness(root, token, now=current)
                materialize_phase6_quota_preflight(root, now=current)
                package_path = materialize_phase6_publication_package(root, created_at=timestamp)
                package_ref = _relative(root, package_path)
                release_path = materialize_phase6_release_gate(root, created_at=timestamp)
                release_ref = _relative(root, release_path)
                release = _read(release_path)
                release_decision = release["decision"]
                blockers = list(release["blockers"])
                if release_decision != "READY_FOR_PUBLICATION_PIPELINE":
                    status, next_action = "BLOCKED", "Correct the evidenced release blocker; never bypass it."
                else:
                    status = "READY"
                    youtube, media_factory = _build_live_service(token)
                    receipt = execute_phase6_publication_pipeline(youtube, media_factory, root, created_at=timestamp)
                    receipt_ref = _relative(root, root / PUBLICATION_RECEIPT)
                    youtube_video_id, privacy = receipt.get("video_id"), receipt["privacy_status"]
                    if receipt["status"] == "COMPLETE_PUBLIC":
                        _record_public_lot(root, str(youtube_video_id), receipt)
                        status, next_action = "COMPLETE_PUBLIC", "OBSERVE_PHASE6_VIDEO2_AT_PREREGISTERED_WINDOWS"
                    elif receipt["privacy_status"] == "public":
                        status = "ERROR"
                        error = "PUBLIC_AWAITING_VERIFICATION: remote video is public but final verification is incomplete"
                        next_action = "RECHECK_EXACT_PUBLIC_VIDEO_AND_CAPTION_SERVING; NEVER_DUPLICATE_PROMOTION"
                    else:
                        status, next_action = "STAGED_PRIVATE", "RECHECK_PROCESSING_AND_PROMOTE_PUBLIC_AFTER_VERIFICATION"
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                receipt_path = root / PUBLICATION_RECEIPT
                if receipt_path.is_file():
                    receipt = _read(receipt_path)
                    receipt_ref = _relative(root, receipt_path)
                    youtube_video_id, privacy = receipt.get("video_id"), receipt.get("privacy_status", "private")
                status = "ERROR"
                next_action = "Retry transactionally from the persisted private-first receipt; never duplicate-upload or relax a gate."
    value = {"schema_version": "1.0.0", "controller_id": "heroverse-phase6-publication-controller-v1", "phase": 6, "status": status, "quality_evaluation_id": quality_id, "package": package_ref, "release": release_ref, "release_decision": release_decision, "publication_receipt": receipt_ref, "youtube_video_id": youtube_video_id, "privacy_status": privacy, "next_action": next_action, "blockers": sorted(set(blockers)), "error": error, "technical_cost_brl": 0, "media_spend_brl": 0, "updated_at": timestamp}
    _validate(root, "phase6_publication_controller_runtime.schema.json", value)
    _write(root / CONTROLLER, value)
    if value["status"] == "COMPLETE_PUBLIC":
        # This narrow collector never deletes media or frozen release evidence.
        from .compile_cache_retention import collect_completed_caches
        collect_completed_caches(root)
        # Media has a separate, fail-closed lifecycle.  It can release only a
        # one-take acquisition with an exact public receipt and independent
        # clearance from every live consumer; absent clearance is a no-op.
        from .media_lifecycle import collect_completed_public_media
        collect_completed_public_media(root, receipt)
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_publication_controller(ROOT), ensure_ascii=False, indent=2))
