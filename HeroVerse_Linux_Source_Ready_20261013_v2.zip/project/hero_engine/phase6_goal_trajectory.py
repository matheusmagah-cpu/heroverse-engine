from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.exceptions import ValidationError


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
TARGET_SUBSCRIBERS = 1_000
TARGET_YPP_WATCH_HOURS = 4_000
TARGET_DAYS = 30
BASE = Path("output/operations/phase6/goal-trajectory")
CURRENT = BASE / "current.json"
LEGACY_LATEST = BASE / "latest.json"
PUBLICATION = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
METRICS = Path(f"output/operations/phase6/metrics/{VIDEO_ID}/latest.json")
CHANNEL_SNAPSHOT = Path("output/audits/channel/heroverse/channel-snapshot.json")
DAILY_CHANNEL_OBSERVATION = Path("output/operations/phase6/channel-goal-observer/latest.json")
DAILY_CHANNEL_RUNTIME = Path("output/operations/phase6/channel-goal-observer/status.json")
MEDIA_RUNTIME = Path("output/operations/phase6/media-executor-status.json")
MEDIA_BLOCK_IDENTITY_FIELDS = (
    "status", "reason", "runtime_identity_sha256", "proof_path", "proof_sha256"
)
LEGACY_OWNED_TRAJECTORY_EXCLUSIONS = {
    "output/operations/phase6/metrics/iK_5edYQtx8/own-performance-iK_5edYQtx8-20260904T185457Z.json": {
        "sha256": "e0dd8a148b78f8aa1337ca44bd52f5ba8f79c315d0b103823dd11f98eb6d1bc3",
        "snapshot_id": "own-performance-iK_5edYQtx8-20260904T185457Z",
        "schema_version": "1.0.0",
        "reason": "CONTRACT_PREDATES_REACH_REPORTING_FIELD",
    },
}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _optional(path: Path) -> dict[str, Any]:
    try:
        return _read(path) if path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _archive_stale_error(root: Path, path: Path, archive_folder: Path) -> None:
    if not path.is_file():
        return
    payload = path.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    archive = archive_folder / f"{path.stem}-{digest[:16]}.json"
    archive.parent.mkdir(parents=True, exist_ok=True)
    if archive.is_file():
        if archive.read_bytes() != payload:
            raise RuntimeError(f"stale error archive collision: {archive}")
        path.unlink()
    else:
        os.replace(path, archive)


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _validate_authoritative(
    root: Path,
    value: dict[str, Any],
    path: Path,
    schema_name: str,
) -> None:
    """Fail closed when an authoritative observation is not contract-valid."""

    try:
        Draft202012Validator(
            _read(root / "schemas" / schema_name),
            format_checker=FormatChecker(),
        ).validate(value)
    except (OSError, json.JSONDecodeError, ValidationError) as exc:
        try:
            relative = path.resolve().relative_to(root).as_posix()
        except ValueError:
            relative = str(path)
        raise PermissionError(
            f"authoritative trajectory evidence failed {schema_name}: {relative}: {exc}"
        ) from exc


def _read_authoritative(root: Path, path: Path, schema_name: str) -> dict[str, Any]:
    try:
        value = _read(path)
    except (OSError, json.JSONDecodeError) as exc:
        raise PermissionError(f"authoritative trajectory evidence is unreadable: {path}") from exc
    _validate_authoritative(root, value, path, schema_name)
    return value


def _read_owned_history(root: Path, path: Path) -> dict[str, Any] | None:
    """Read current-contract history or exclude one exact hash-pinned legacy record.

    The excluded record predates a required source field and contains no channel
    subscriber observation. Its bytes are preserved, but it can never become a
    pace point. No other schema-invalid history receives this treatment.
    """

    try:
        return _read_authoritative(
            root, path, "own_channel_performance_snapshot.schema.json"
        )
    except PermissionError as contract_error:
        try:
            relative = path.resolve().relative_to(root).as_posix()
        except ValueError:
            raise contract_error
        exclusion = LEGACY_OWNED_TRAJECTORY_EXCLUSIONS.get(relative)
        if exclusion is None:
            raise contract_error
        try:
            value = _read(path)
            observed_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        except (OSError, json.JSONDecodeError):
            raise contract_error
        if not (
            observed_hash == exclusion["sha256"]
            and value.get("snapshot_id") == exclusion["snapshot_id"]
            and value.get("schema_version") == exclusion["schema_version"]
            and value.get("channel_id") == CHANNEL_ID
            and value.get("video_id") == VIDEO_ID
            and "youtube_channel_api" not in (value.get("sources") or {})
            and value.get("channel_metrics") is None
        ):
            raise contract_error
        return None


def _require_id_filename(path: Path, identifier: Any, *, label: str) -> None:
    expected = f"{identifier}.json" if isinstance(identifier, str) and identifier else None
    if expected is None or path.name != expected:
        raise PermissionError(
            f"{label} immutable filename must equal its internal identifier: {path.name}"
        )


def _require_exact_folder(root: Path, path: Path, folder: Path, *, label: str) -> None:
    resolved_root = root.resolve()
    resolved_path = path.resolve()
    resolved_folder = folder.resolve()
    try:
        resolved_path.relative_to(resolved_root)
    except ValueError as exc:
        raise PermissionError(f"{label} escapes the workspace") from exc
    if resolved_path.parent != resolved_folder:
        raise PermissionError(f"{label} is outside its authoritative folder")


def _require_latest_twin(
    root: Path,
    latest_path: Path,
    value: dict[str, Any],
    *,
    identifier_field: str,
    immutable_folder: Path,
    schema_name: str,
    label: str,
) -> Path:
    _require_exact_folder(root, latest_path, latest_path.parent, label=f"{label} latest")
    identifier = value.get(identifier_field)
    if not isinstance(identifier, str) or not identifier:
        raise PermissionError(f"{label} latest evidence has no immutable identifier")
    twin = immutable_folder / f"{identifier}.json"
    _require_exact_folder(root, twin, immutable_folder, label=f"{label} immutable twin")
    twin_value = _read_authoritative(root, twin, schema_name)
    _require_id_filename(twin, twin_value.get(identifier_field), label=label)
    if latest_path.read_bytes() != twin.read_bytes():
        raise PermissionError(f"{label} latest evidence is not byte-identical to its immutable twin")
    return twin


def _resolve_owned_reuse_evidence(root: Path, raw_path: Any) -> Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise PermissionError("OWNED_METRICS_REUSE requires an evidence_path")
    supplied = Path(raw_path)
    if supplied.is_absolute():
        raise PermissionError("OWNED_METRICS_REUSE evidence_path must be workspace-relative")
    candidate = (root / supplied).resolve()
    expected_folder = (root / METRICS.parent).resolve()
    try:
        candidate.relative_to(root)
        candidate.relative_to(expected_folder)
    except ValueError as exc:
        raise PermissionError(
            "OWNED_METRICS_REUSE evidence_path must remain inside the exact owned metrics folder"
        ) from exc
    if candidate.parent != expected_folder or candidate.name == "latest.json":
        raise PermissionError(
            "OWNED_METRICS_REUSE must reference an immutable owned checkpoint, not a mutable view"
        )
    return candidate


def _owned_subscriber_candidate(
    value: dict[str, Any],
    path: Path,
    *,
    root: Path,
    started: datetime,
    now: datetime,
) -> dict[str, Any] | None:
    source = (value.get("sources") or {}).get("youtube_channel_api") or {}
    channel = value.get("channel_metrics") or {}
    count = channel.get("subscriberCount")
    try:
        captured = _parse(str(value["captured_at"]))
    except (KeyError, TypeError, ValueError):
        return None
    if not (
        value.get("channel_id") == CHANNEL_ID
        and source.get("status") == "PASS"
        and channel.get("channelId") == CHANNEL_ID
        and isinstance(count, int)
        and not isinstance(count, bool)
        and count >= 0
        and started <= captured <= now
    ):
        return None
    snapshot_id = str(value.get("snapshot_id") or "")
    if not snapshot_id:
        return None
    return {
        "kind": "OWNED_VIDEO_CHECKPOINT",
        "id": snapshot_id,
        "origin_key": f"OWNED:{snapshot_id}",
        "path": path.relative_to(root).as_posix(),
        "captured_at": _stamp(captured),
        "captured": captured,
        "count": count,
        "api_status": "PASS",
        "precision": channel.get("subscriberCountPrecision", "UNAVAILABLE"),
    }


def _daily_subscriber_candidate(
    value: dict[str, Any],
    path: Path,
    *,
    root: Path,
    started: datetime,
    now: datetime,
) -> dict[str, Any] | None:
    source = value.get("source") or {}
    metrics = value.get("metrics") or {}
    decision = value.get("decision") or {}
    count = metrics.get("subscriberCount")
    try:
        captured = _parse(str(value["captured_at"]))
    except (KeyError, TypeError, ValueError):
        return None
    if not (
        value.get("channel_id") == CHANNEL_ID
        and source.get("api_status") == "PASS"
        and decision.get("eligible_for_trajectory") is True
        and isinstance(count, int)
        and not isinstance(count, bool)
        and count >= 0
        and started <= captured <= now
    ):
        return None

    # The daily observer normally wraps the exact owned D1 checkpoint.  That
    # wrapper is not a second comparable observation.  Pin both records to the
    # same origin and effective capture time so a few seconds of orchestration
    # latency can never manufacture a pace measurement.
    origin_key = f"DAILY:{value.get('observation_id')}"
    effective_captured = captured
    if source.get("kind") == "OWNED_METRICS_REUSE":
        evidence_path = _resolve_owned_reuse_evidence(root, source.get("evidence_path"))
        evidence = _read_authoritative(
            root,
            evidence_path,
            "own_channel_performance_snapshot.schema.json",
        )
        evidence_id = evidence.get("snapshot_id")
        _require_id_filename(evidence_path, evidence_id, label="owned checkpoint")
        try:
            evidence_captured = _parse(str(evidence["captured_at"]))
        except (KeyError, TypeError, ValueError):
            evidence_captured = None
        evidence_source = (evidence.get("sources") or {}).get("youtube_channel_api") or {}
        evidence_metrics = evidence.get("channel_metrics") or {}
        exact_binding = (
            evidence.get("channel_id") == CHANNEL_ID
            and evidence_source.get("status") == "PASS"
            and evidence_metrics.get("channelId") == CHANNEL_ID
            and evidence_metrics.get("subscriberCount") == count
            and evidence_metrics.get("subscriberCountPrecision")
            == metrics.get("subscriberCountPrecision")
            and evidence_metrics.get("hiddenSubscriberCount")
            == metrics.get("hiddenSubscriberCount")
            and evidence_metrics.get("videoCount") == metrics.get("videoCount")
            and evidence_metrics.get("viewCount") == metrics.get("viewCount")
        )
        if not exact_binding:
            raise PermissionError(
                "OWNED_METRICS_REUSE wrapper does not exactly match its authoritative checkpoint"
            )
        if not (
            evidence_id
            and evidence_captured is not None
            and started <= evidence_captured <= now
        ):
            raise PermissionError(
                "OWNED_METRICS_REUSE checkpoint is outside the active goal measurement window"
            )
        origin_key = f"OWNED:{evidence_id}"
        effective_captured = evidence_captured

    return {
        "kind": "DAILY_CHANNEL_OBSERVER",
        "id": str(value.get("observation_id") or ""),
        "origin_key": origin_key,
        "path": path.relative_to(root).as_posix(),
        "captured_at": _stamp(effective_captured),
        "captured": effective_captured,
        "count": count,
        "api_status": "PASS",
        "precision": metrics.get("subscriberCountPrecision", "UNAVAILABLE"),
    }


def _official_subscriber_candidates(
    root: Path,
    *,
    metrics: dict[str, Any],
    daily_observation: dict[str, Any],
    started: datetime,
    now: datetime,
) -> list[dict[str, Any]]:
    """Return unique, in-window official counts ordered by effective capture.

    Mutable ``latest.json`` files are accepted only when byte-bound to a
    schema-valid immutable twin. Every history record is schema-valid and its
    filename is bound to its internal identifier. Reused daily wrappers are
    also bound to the exact owned checkpoint they cite before deduplication.
    """

    candidates: list[dict[str, Any]] = []
    owned_folder = root / METRICS.parent
    owned_paths = sorted(owned_folder.glob("*.json")) if owned_folder.is_dir() else []
    if root / METRICS not in owned_paths:
        owned_paths.append(root / METRICS)
    for path in owned_paths:
        _require_exact_folder(root, path, owned_folder, label="owned checkpoint")
        value = metrics if path == root / METRICS else _read_owned_history(root, path)
        if value is None:
            continue
        if path != root / METRICS:
            _require_id_filename(path, value.get("snapshot_id"), label="owned checkpoint")
        candidate = _owned_subscriber_candidate(
            value, path, root=root, started=started, now=now
        )
        if candidate is not None:
            candidates.append(candidate)

    daily_paths: list[Path] = []
    history = (root / DAILY_CHANNEL_OBSERVATION).parent / "history"
    if history.is_dir():
        daily_paths.extend(sorted(history.glob("*.json")))
    if (root / DAILY_CHANNEL_OBSERVATION).is_file():
        daily_paths.append(root / DAILY_CHANNEL_OBSERVATION)
    for path in daily_paths:
        _require_exact_folder(
            root,
            path,
            history if path != root / DAILY_CHANNEL_OBSERVATION else (root / DAILY_CHANNEL_OBSERVATION).parent,
            label="daily observation",
        )
        value = daily_observation if path == root / DAILY_CHANNEL_OBSERVATION else _read_authoritative(
            root, path, "phase6_channel_goal_observation.schema.json"
        )
        if path != root / DAILY_CHANNEL_OBSERVATION:
            _require_id_filename(path, value.get("observation_id"), label="daily observation")
        candidate = _daily_subscriber_candidate(
            value, path, root=root, started=started, now=now
        )
        if candidate is not None:
            candidates.append(candidate)

    unique: dict[str, dict[str, Any]] = {}
    for candidate in candidates:
        prior = unique.get(candidate["origin_key"])
        if prior is None or (
            candidate["kind"] == "DAILY_CHANNEL_OBSERVER"
            and prior["kind"] != "DAILY_CHANNEL_OBSERVER"
        ):
            unique[candidate["origin_key"]] = candidate
    return sorted(unique.values(), key=lambda item: (item["captured"], item["origin_key"]))


def _media_decision_context(
    root: Path, *, media_override: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Read once; an explicit/uncertain media block cannot become render priority.

    The immutable post-effect proof is reopened by its existing verifier, not
    inferred from WAIT/SUCCEEDED labels. This read-only check grants no authority.
    Raw bytes bind the observation, while a timestamp-free identity drives change.
    """
    path = root / MEDIA_RUNTIME
    if media_override is None and not path.is_file():
        return {}, None
    raw: bytes | None = None
    media: dict[str, Any] = {}
    block: dict[str, Any] = {
        "status": "EVIDENCE_INVALID",
        "reason": "MEDIA_RUNTIME_EVIDENCE_INVALID",
        "runtime_path": MEDIA_RUNTIME.as_posix(),
        "runtime_sha256": None,
        "runtime_identity_sha256": None,
        "proof_path": None,
        "proof_sha256": None,
        "error": None,
    }
    try:
        # A transaction must derive all of its views from the SAME proposed
        # state. This is a schema-checked proposal, never a live observation.
        raw = (path.read_bytes() if media_override is None else
               (json.dumps(media_override, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
        block["runtime_sha256"] = "sha256:" + hashlib.sha256(raw).hexdigest()
        block["runtime_identity_sha256"] = block["runtime_sha256"]
        parsed = json.loads(raw.decode("utf-8-sig"))
        if not isinstance(parsed, dict):
            raise ValueError("media runtime must be an object")
        media = parsed
        is_wait = media.get("schema_version") == "1.3.0" or "remediation_wait" in media
        if is_wait:
            block["reason"] = "MEDIA_REMEDIATION_WAIT_EVIDENCE_INVALID"
        _validate_authoritative(
            root, media, path, "phase6_media_executor_runtime.schema.json"
        )
        is_blocked = (
            media.get("status") in {"BLOCKED", "ERROR", "RETRY_WAIT"}
            or media.get("capacity_status") == "BLOCKED"
            or (media.get("visual_preflight") or {}).get("status") == "BLOCKED"
        )
        if not is_wait and not is_blocked:
            return media, None
        block["runtime_identity_sha256"] = _canonical_hash({
            key: value for key, value in media.items() if key != "updated_at"
        })
        if is_wait:
            from .phase6_media_remediation_wait import verify_post_effect_visual_wait

            verify_post_effect_visual_wait(root, media)
            binding = media["remediation_wait"]
            block.update({
                "status": "VALIDATED_WAIT",
                "reason": "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED",
                "runtime_identity_sha256": binding["runtime_identity_sha256"],
                "proof_path": binding["path"],
                "proof_sha256": binding["sha256"],
            })
        else:
            block.update({
                "status": "REPORTED_BLOCK",
                "reason": "MEDIA_PRODUCTION_" + str(media["status"]),
                "error": media.get("error"),
            })
        current_raw = path.read_bytes() if media_override is None else raw
        if current_raw != raw:
            current = json.loads(current_raw.decode("utf-8-sig"))
            _validate_authoritative(root, current, path, "phase6_media_executor_runtime.schema.json")
            if {key: val for key, val in current.items() if key != "updated_at"} != {
                key: val for key, val in media.items() if key != "updated_at"
            }:
                raise PermissionError("media runtime identity changed during priority evidence verification")
        return media, block
    except Exception as exc:
        # An explicit evidence error is safer than falling through to a completed
        # preparer. Preserve the error; never call this a verified waiting state.
        block.update({
            "status": "EVIDENCE_INVALID",
            "reason": (
                "MEDIA_REMEDIATION_WAIT_EVIDENCE_INVALID"
                if media.get("schema_version") == "1.3.0" or "remediation_wait" in media
                else "MEDIA_RUNTIME_EVIDENCE_INVALID"
            ),
            "proof_path": None,
            "proof_sha256": None,
            "error": f"{type(exc).__name__}: {exc}",
        })
        return media, block


def _action(
    root: Path, metrics: dict[str, Any], now: datetime, started: datetime,
    *, media: dict[str, Any], media_block: dict[str, Any] | None,
) -> tuple[str, str | None, list[str], str]:
    transition = _optional(root / "output/operations/phase6/phase-transition-runtime.json")
    publication = _optional(root / "output/operations/phase6/publication-controller-status.json")
    quality = _optional(root / "output/operations/phase6/quality-executor-status.json")
    preparation = _optional(root / "output/operations/phase6/release/preparer-status.json")
    package = _optional(root / "output/operations/phase6/package-treatment-executor-status.json")
    treatment = _optional(root / "output/operations/phase6/production/executor-status.json")
    order = _optional(root / "output/operations/phase6/production/latest-order.json")
    age_hours = max(0.0, (now - started).total_seconds() / 3600)

    if transition.get("status") == "TRANSITIONED":
        return "TRANSITION_PHASE", None, [], "The immutable Phase 6 acceptance receipt authorizes the sequential Phase 7 start."
    if publication.get("status") == "COMPLETE_PUBLIC":
        return "OBSERVE_TREATMENT_OUTCOME", None, [], "A gated treatment is public; preserve the preregistered observation window."
    if media_block is not None:
        return (
            "RESOLVE_MEDIA_PRODUCTION_BLOCK", None, [media_block["reason"]],
            (
                "Correct the rejected audiovisual inputs and admit a post-effect successor through its own contract; the SUCCEEDED predecessor authorizes neither another render nor publication."
                if media_block["status"] == "VALIDATED_WAIT" else
                "Resolve the recorded media or evidence failure before production; a completed preparer cannot override this block."
            ),
        )
    if publication.get("status") in {"READY", "STAGED_PRIVATE"} or (
        quality.get("status") == "COMPLETED" and quality.get("publication_eligible") is True
    ):
        return "EXECUTE_PRIVATE_FIRST_PUBLICATION", None, [], "The exact release passed quality; publication remains private-first and receipt-bound."
    if media.get("status") == "COMPLETED":
        return "RUN_QUALITY_GATES", None, [], "Rendered media exists and must pass the independent quality contract before publication."
    if preparation.get("status") == "COMPLETED":
        return "SYNTHESIZE_RENDER_VIDEO_2", None, [], "Verified production inputs exist for the local zero-cost media pipeline."
    if treatment.get("status") == "COMPLETED":
        return "PREPARE_RELEASE_INPUTS", None, [], "The preregistered treatment compiled; release inputs are the next bounded stage."
    if package.get("status") in {"WAITING_FOR_INPUTS", "NOT_DUE", "READY"}:
        return "EXECUTE_PACKAGE_TREATMENT", package.get("scheduled_for"), [], "The single-variable package path controls the next permitted action."
    if order.get("status") == "READY_TO_COMPILE":
        return "COMPILE_PREREGISTERED_TREATMENT", None, [], "The exact evidence-bound order is ready; no alternative variable may enter."
    if metrics.get("status") == "FAILED":
        return (
            "RECOVER_METRICS_SOURCE",
            metrics.get("next_observation_at"),
            ["OWNED_METRICS_SOURCE_FAILED"],
            "Recover the official source within its finite retry policy before any creative decision.",
        )
    if age_hours < 24 or metrics.get("decision_status") == "INSUFFICIENT_DATA":
        return (
            "COLLECT_D1_CHECKPOINT",
            metrics.get("next_observation_at"),
            ["D1_OWNED_CHECKPOINT_NOT_COMPLETE"],
            "The first valid intervention requires the owned 24-hour checkpoint; collection is automatic.",
        )
    return (
        "WAIT_FOR_PREREGISTERED_SIGNAL",
        metrics.get("next_observation_at"),
        ["NO_EVIDENCE_BOUND_TREATMENT_READY"],
        "No downstream action is legal until one diagnosis and one variable are preregistered.",
    )


def build_goal_trajectory(
    root: Path = ROOT,
    *,
    evaluated_at: str | None = None,
    media_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    now = _parse(evaluated_at) if evaluated_at else datetime.now(timezone.utc)
    publication = _read(root / PUBLICATION)
    if publication.get("status") != "COMPLETE_PUBLIC" or publication.get("video_id") != VIDEO_ID:
        raise PermissionError("goal trajectory requires the exact completed public canary receipt")
    metrics = _read(root / METRICS)
    _validate_authoritative(
        root,
        metrics,
        root / METRICS,
        "own_channel_performance_snapshot.schema.json",
    )
    _require_latest_twin(
        root,
        root / METRICS,
        metrics,
        identifier_field="snapshot_id",
        immutable_folder=(root / METRICS).parent,
        schema_name="own_channel_performance_snapshot.schema.json",
        label="owned metrics",
    )
    if metrics.get("channel_id") != CHANNEL_ID or metrics.get("video_id") != VIDEO_ID:
        raise PermissionError("goal trajectory metrics identity mismatch")
    started = _parse(
        str(metrics.get("published_at") or publication.get("updated_at") or publication.get("created_at"))
    )
    deadline = started + timedelta(days=TARGET_DAYS)
    baseline = _read(root / CHANNEL_SNAPSHOT)
    if baseline.get("channel_id", CHANNEL_ID) != CHANNEL_ID:
        raise PermissionError("goal trajectory baseline channel identity mismatch")
    baseline_subscribers = (baseline.get("statistics") or {}).get("subscribers")
    if not isinstance(baseline_subscribers, int) or baseline_subscribers < 0:
        raise ValueError("goal trajectory requires a non-negative subscriber baseline")
    baseline_at = _parse(str(baseline["observed_at"]))
    if baseline_at > started:
        raise PermissionError("subscriber baseline must precede the public canary")

    daily_observation = (
        _read_authoritative(
            root,
            root / DAILY_CHANNEL_OBSERVATION,
            "phase6_channel_goal_observation.schema.json",
        )
        if (root / DAILY_CHANNEL_OBSERVATION).is_file()
        else {}
    )
    daily_runtime = _optional(root / DAILY_CHANNEL_RUNTIME)
    if daily_observation:
        _require_latest_twin(
            root,
            root / DAILY_CHANNEL_OBSERVATION,
            daily_observation,
            identifier_field="observation_id",
            immutable_folder=(root / DAILY_CHANNEL_OBSERVATION).parent / "history",
            schema_name="phase6_channel_goal_observation.schema.json",
            label="daily observation",
        )
    if daily_runtime:
        Draft202012Validator(
            _read(root / "schemas/phase6_channel_goal_observer_runtime.schema.json"),
            format_checker=FormatChecker(),
        ).validate(daily_runtime)

    channel_source = (metrics.get("sources") or {}).get("youtube_channel_api") or {}
    candidates = _official_subscriber_candidates(
        root,
        metrics=metrics,
        daily_observation=daily_observation,
        started=started,
        now=now,
    )
    selected_source = candidates[-1] if candidates else None
    pace_anchor = candidates[0] if candidates else None
    source_valid = selected_source is not None
    current_subscribers = selected_source["count"] if selected_source else None
    elapsed_days = round(max(0.0, (now - started).total_seconds() / 86400), 6)
    remaining_days = round(max(0.0, (deadline - now).total_seconds() / 86400), 6)
    initial_gap = max(0, TARGET_SUBSCRIBERS - baseline_subscribers)
    historical_net_change: int | None = None
    pace_net_change: int | None = None
    pace_elapsed_days: float | None = None
    expected_gain: float | None = None
    remaining_gap: int | None = None
    pace_ratio: float | None = None
    schedule_delta: float | None = None
    required_per_remaining_day: float | None = None
    observed_per_elapsed_day: float | None = None
    pace_status = "UNAVAILABLE_NO_CURRENT_OBSERVATION"
    trajectory_status = "WAITING_FOR_CURRENT_CHANNEL_METRICS"
    if current_subscribers is not None:
        historical_net_change = current_subscribers - baseline_subscribers
        remaining_gap = max(0, TARGET_SUBSCRIBERS - current_subscribers)
        required_per_remaining_day = round(remaining_gap / remaining_days, 6) if remaining_days > 0 else None
        if pace_anchor is not None and len(candidates) >= 2:
            pace_elapsed_days = round(
                max(0.0, (selected_source["captured"] - pace_anchor["captured"]).total_seconds() / 86400),
                6,
            )
            anchor_remaining_days = max(
                0.0, (deadline - pace_anchor["captured"]).total_seconds() / 86400
            )
            pace_net_change = current_subscribers - pace_anchor["count"]
            if pace_elapsed_days > 0 and anchor_remaining_days > 0:
                expected_gain = round(
                    max(0, TARGET_SUBSCRIBERS - pace_anchor["count"])
                    * min(1.0, pace_elapsed_days / anchor_remaining_days),
                    6,
                )
                observed_per_elapsed_day = round(pace_net_change / pace_elapsed_days, 6)
                schedule_delta = round(pace_net_change - expected_gain, 6)
                pace_ratio = round(pace_net_change / expected_gain, 6) if expected_gain > 0 else None
                pace_status = "MEASURED_FROM_IN_WINDOW_ANCHOR"
            else:
                pace_status = "WAITING_SECOND_DISTINCT_IN_WINDOW_OBSERVATION"
        else:
            pace_status = "WAITING_SECOND_DISTINCT_IN_WINDOW_OBSERVATION"
        if current_subscribers >= TARGET_SUBSCRIBERS:
            trajectory_status = "SUBSCRIBER_TARGET_REACHED"
        elif now >= deadline:
            trajectory_status = "DEADLINE_EXPIRED_BELOW_SUBSCRIBER_TARGET"
        elif pace_status != "MEASURED_FROM_IN_WINDOW_ANCHOR":
            trajectory_status = "CURRENT_GAP_MEASURED_PACE_PENDING"
        elif pace_ratio is not None and pace_ratio >= 1:
            trajectory_status = "ON_OR_ABOVE_LINEAR_TRAJECTORY"
        elif pace_ratio is not None and pace_ratio >= 0.5:
            trajectory_status = "BELOW_LINEAR_TRAJECTORY"
        else:
            trajectory_status = "CRITICAL_LINEAR_TRAJECTORY_DEFICIT"

    if trajectory_status == "WAITING_FOR_CURRENT_CHANNEL_METRICS" or elapsed_days < 1:
        pressure = "MEASURE"
    elif trajectory_status == "SUBSCRIBER_TARGET_REACHED":
        pressure = "VERIFY_YPP"
    elif trajectory_status == "CURRENT_GAP_MEASURED_PACE_PENDING":
        pressure = "HIGH"
    elif trajectory_status == "ON_OR_ABOVE_LINEAR_TRAJECTORY":
        pressure = "CONTROLLED"
    elif trajectory_status == "BELOW_LINEAR_TRAJECTORY":
        pressure = "HIGH"
    else:
        pressure = "MAXIMUM_WITHIN_GATES"

    media, media_block = _media_decision_context(root, media_override=media_override)
    action, scheduled_at, blocking_gates, rationale = _action(
        root, metrics, now, started, media=media, media_block=media_block
    )
    production_block = media_block if action == "RESOLVE_MEDIA_PRODUCTION_BLOCK" else None
    source_snapshot = selected_source["id"] if selected_source else None
    source_kind = selected_source["kind"] if selected_source else "UNAVAILABLE"
    source_path = selected_source["path"] if selected_source else None
    source_captured_at = selected_source["captured_at"] if selected_source else None
    source_api_status = selected_source["api_status"] if selected_source else channel_source.get("status", "UNAVAILABLE")
    source_precision = selected_source["precision"] if selected_source else "UNAVAILABLE"
    daily_observer_status = daily_runtime.get("status", "UNAVAILABLE")
    daily_observer_next_at = daily_runtime.get("next_observation_at")
    semantic = {
        "started_at": _stamp(started),
        "deadline_at": _stamp(deadline),
        "subscriber_source_kind": source_kind,
        "subscriber_source_id": source_snapshot,
        "subscriber_source_path": source_path,
        "subscriber_source_captured_at": source_captured_at,
        "daily_observer_status": daily_observer_status,
        "daily_observer_next_at": daily_observer_next_at,
        "current_subscribers": current_subscribers,
        "pace_anchor_source_id": pace_anchor["id"] if pace_anchor else None,
        "pace_comparable_observation_count": len(candidates),
        "pace_status": pace_status,
        "subscriber_status": trajectory_status,
        "pressure_level": pressure,
        "selected_action": action,
        "scheduled_at": scheduled_at,
        "blocking_gates": blocking_gates,
        "production_block_identity": (
            {
                key: production_block[key]
                for key in MEDIA_BLOCK_IDENTITY_FIELDS
            } if production_block else None
        ),
    }
    signature = _canonical_hash(semantic)
    trajectory_id = "phase6-goal-trajectory-" + signature.split(":", 1)[1][:24]
    value = {
        "schema_version": "1.3.0",
        "trajectory_id": trajectory_id,
        "controller_id": "heroverse-30-day-goal-trajectory-v1",
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "goal": {
            "started_at": _stamp(started),
            "deadline_at": _stamp(deadline),
            "target_days": TARGET_DAYS,
            "target_subscribers": TARGET_SUBSCRIBERS,
            "target_ypp_valid_watch_hours": TARGET_YPP_WATCH_HOURS,
            "result_guaranteed": False,
        },
        "measurement": {
            "source_snapshot_id": source_snapshot,
            "source_captured_at": source_captured_at,
            "channel_api_status": source_api_status,
            "subscriber_count_precision": source_precision,
            "current_subscribers_observed": source_valid,
            "subscriber_source_kind": source_kind,
            "subscriber_source_id": source_snapshot,
            "subscriber_source_path": source_path,
            "daily_observer_status": daily_observer_status,
            "daily_observer_next_at": daily_observer_next_at,
        },
        "subscriber_trajectory": {
            "baseline_subscribers": baseline_subscribers,
            "baseline_observed_at": _stamp(baseline_at),
            "baseline_precedes_goal_start_hours": round((started - baseline_at).total_seconds() / 3600, 6),
            "current_subscribers": current_subscribers,
            "target_subscribers": TARGET_SUBSCRIBERS,
            "initial_gap": initial_gap,
            "remaining_gap": remaining_gap,
            "net_change_since_baseline": historical_net_change,
            "elapsed_days": elapsed_days,
            "remaining_days": remaining_days,
            "pace_anchor_subscribers": pace_anchor["count"] if pace_anchor else None,
            "pace_anchor_observed_at": pace_anchor["captured_at"] if pace_anchor else None,
            "pace_anchor_source_kind": pace_anchor["kind"] if pace_anchor else "UNAVAILABLE",
            "pace_anchor_source_id": pace_anchor["id"] if pace_anchor else None,
            "pace_comparable_observation_count": len(candidates),
            "pace_elapsed_days": pace_elapsed_days,
            "net_change_since_pace_anchor": pace_net_change,
            "pace_status": pace_status,
            "linear_expected_gain_by_now": expected_gain,
            "schedule_delta_subscribers": schedule_delta,
            "observed_net_subscribers_per_elapsed_day": observed_per_elapsed_day,
            "required_net_subscribers_per_remaining_day": required_per_remaining_day,
            "pace_ratio_to_linear_target": pace_ratio,
            "status": trajectory_status,
        },
        "watch_hour_trajectory": {
            "current_ypp_valid_watch_hours": None,
            "target_ypp_valid_watch_hours": TARGET_YPP_WATCH_HOURS,
            "remaining_gap": None,
            "status": "UNAVAILABLE_OFFICIAL_YPP_PROGRESS_NOT_OBSERVED",
            "analytics_watch_minutes_observed": (metrics.get("private_metrics") or {}).get("estimatedMinutesWatched"),
            "analytics_is_ypp_qualified_progress": False,
        },
        "decision": {
            "overall_visibility": "PARTIAL_SUBSCRIBER_ONLY" if source_valid else "INSUFFICIENT_CURRENT_MEASUREMENT",
            "pressure_level": pressure,
            "selected_action": action,
            "scheduled_at": scheduled_at,
            "automatic": True,
            "rationale": rationale,
            "blocking_gates": blocking_gates,
            "production_block": production_block,
            "priority_only": True,
            "can_override_quality_or_rights_gates": False,
            "publication_authorized": False,
            "spend_authorized": False,
        },
        "substantive_signature": signature,
        "change_class": "INITIAL",
        "previous_substantive_signature": None,
        "history_archived": True,
        "evidence": list(dict.fromkeys([
            PUBLICATION.as_posix(), METRICS.as_posix(), CHANNEL_SNAPSHOT.as_posix(),
            *([DAILY_CHANNEL_RUNTIME.as_posix()] if daily_runtime else []),
            *([DAILY_CHANNEL_OBSERVATION.as_posix()] if daily_observation else []),
            *([MEDIA_RUNTIME.as_posix()] if production_block else []),
            *([production_block["proof_path"]] if production_block and production_block["proof_path"] else []),
        ])),
        "technical_cost_brl": 0,
        "claim_boundary": [
            "The 30-day deadline is a rigid operating target, not a guarantee of audience response or YPP approval.",
            "Subscriber pace is calculated only from official channel counts; an unavailable current count stays null.",
            "The historical pre-publication baseline is never treated as the goal-start counter; pace begins only after two distinct official observations inside the 30-day window.",
            "A daily wrapper that reuses an owned checkpoint is deduplicated and cannot manufacture a second pace observation.",
            "The freshest schema-valid official subscriber observation wins; one exact hash-pinned pre-contract record without subscriber data is preserved but permanently excluded.",
            "YouTube Analytics watch minutes are not represented as YPP-valid public watch hours.",
            "Trajectory pressure prioritizes the next already-permitted action and cannot bypass rights, quality, policy, identity, quota or publication gates.",
        ],
        "evaluated_at": _stamp(now),
    }
    return value


def current_path(root: Path = ROOT) -> Path:
    """Resolve the forward-only trajectory view without mutating legacy latest."""
    root = Path(root).resolve()
    successor = root / CURRENT
    if successor.is_file():
        return successor
    cycle_path = root / "output/operations/phase6/control-cycle/latest.json"
    try:
        cycle = _read(cycle_path) if cycle_path.exists() else {}
        if not isinstance(cycle, dict) or not isinstance(cycle.get("stages", []), list):
            raise ValueError("invalid cycle selection evidence")
    except (OSError, ValueError) as exc:
        raise PermissionError("CURRENT_CHAIN_CYCLE_SELECTION_UNREADABLE") from exc
    if any(row.get("stage") == "GOAL_TRAJECTORY" and row.get("path") == CURRENT.as_posix()
           for row in cycle.get("stages", [])):
        raise PermissionError("CURRENT_CHAIN_TRAJECTORY_ALIAS_MISSING")
    return root / LEGACY_LATEST


def materialize(root: Path = ROOT, *, evaluated_at: str | None = None) -> Path:
    root = root.resolve()
    output_path = root / CURRENT if (root / LEGACY_LATEST).is_file() else root / LEGACY_LATEST
    previous = _optional(current_path(root))
    value = build_goal_trajectory(root, evaluated_at=evaluated_at)
    previous_signature = previous.get("substantive_signature")
    value["previous_substantive_signature"] = previous_signature
    value["change_class"] = (
        "INITIAL" if not previous else (
            "STATE_CHANGED" if value["substantive_signature"] != previous_signature else "HEARTBEAT_ONLY"
        )
    )
    value["history_archived"] = value["change_class"] in {"INITIAL", "STATE_CHANGED"}
    Draft202012Validator(
        _read(root / "schemas/phase6_goal_trajectory.schema.json"),
        format_checker=FormatChecker(),
    ).validate(value)
    _write(output_path, value)
    if value["history_archived"]:
        history = root / BASE / "history" / f"{value['trajectory_id']}.json"
        if not history.is_file():
            _write(history, value)
    _archive_stale_error(
        root,
        root / "output/operations/phase6/goal-trajectory-error.json",
        root / BASE / "errors/archive",
    )
    return output_path


if __name__ == "__main__":
    print(materialize(ROOT))
