"""Cheap, pre-effect cross-check of the actual text recipe, not a video QA pass.

No network, model, speech synthesis or FFmpeg invocation is made here. The
renderer builds its real filter graph in an isolated temporary directory. Its
text inputs are independently compared to the frozen editorial/style contract.
Pixel OCR, motion, audio and all release gates remain mandatory downstream.
"""
from __future__ import annotations

import hashlib
import json
import marshal
import os
import re
import tempfile
import uuid
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .render_creative_v2_phase5 import _font
from .phase6_visual_recipe import _drawtext_filter, _ffmpeg_path, visual_filters as _visual_filters
from .phase6_render_contract import PHASE6_SEGMENT_RENDERER, plan_renderer


VERSION = "1.0.0"
PRODUCTION = Path("output/production/phase6/video-002/production")
AUDITS = Path("output/operations/phase6/visual-preflight/audits")
SCHEMA = "phase6_visual_preflight.schema.json"
INPUTS = {
    "take_plan.json": "take_plan.schema.json",
    "creative_treatment_plan.json": "phase6_creative_treatment_plan.schema.json",
    "channel_style_bible.json": "visual_continuity_bible.schema.json",
}
# The completed v2 render predates QP1. These exact preserved bytes authenticate
# its historical observation; they never approve a current QP1 preflight.
PRE_QP1_AUDITOR = Path(
    "output/runtime/gestor-central/maintenance-runs/typography-codec-adoption-20261001/"
    "source-preimages/hero_engine/phase6_visual_preflight.py"
)
PRE_QP1_AUDITOR_SHA256 = "sha256:317f3e4a384e1dd31ce641c4b570baf95bd20c6d130ad4ed60426aaac8731cee"
PRE_QP1_PLAN_SCHEMA = PRE_QP1_AUDITOR.parent.parent / "schemas/take_plan.schema.json"
PRE_QP1_PLAN_SCHEMA_SHA256 = "sha256:8fe58aa812135111918eee49706751496c5e68aed1178cc70b370d38ea7b36f3"
QP1_PLAN_SCHEMA_SHA256 = "sha256:d8c4ef32386ab73fcea24e2c391b0002b3cfd325125fee895c5051709f62edef"
KINDS = {
    "HOOK_STAMP", "HOOK_QUESTION", "HOOK_FRAMEWORK", "SECTION_CARD",
    "ACTION_EVIDENCE", "CINEMATIC_BODY", "PAYOFF_RESOLUTION", "FRAMEWORK_STEP",
    "SCRIPTURE_SEQUENCE", "KEYWORD_PUNCH",
}


class VisualContractError(PermissionError):
    def __init__(self, message: str, *, binding: dict[str, Any] | None = None):
        super().__init__(message)
        self.binding = binding


def _hash(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _encoded(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _tokens(value: str | None) -> list[str]:
    return re.findall(r"\w+", (value or "").casefold())


def _locked_framework(bible: dict[str, Any]) -> list[str]:
    matches = []
    for value in bible.get("identity", {}).get("principles", []):
        match = re.match(r"^(.+?)\s+remains\s+the\s+locked\s+information\s+system\b", value, re.I)
        if match:
            matches.append(_tokens(match.group(1)))
    if len(matches) != 1:
        raise VisualContractError("STYLE_BIBLE_LOCKED_FRAMEWORK_MISSING_OR_AMBIGUOUS")
    return matches[0]


def build_visual_contract(
    plan: dict[str, Any], treatment: dict[str, Any], bible: dict[str, Any],
) -> dict[str, Any]:
    """Recompute all takes with the loaded renderer; never trust its PASS labels."""
    findings: list[dict[str, Any]] = []
    takes: list[dict[str, Any]] = []

    def fail(code: str, take_id: str | None = None, detail: str = "") -> None:
        findings.append({"code": code, "take_id": take_id, "detail": detail})

    for field in ("channel_id", "format_pack_id", "format_pack_version", "video_id"):
        if not plan.get(field) or plan.get(field) != treatment.get(field):
            fail("INPUT_IDENTITY_MISMATCH", detail=field)
    if not bible.get("channel_id") or bible.get("channel_id") != plan.get("channel_id"):
        fail("STYLE_BIBLE_CHANNEL_MISMATCH")
    if not bible.get("style_bible_id") or bible.get("style_bible_id") != plan.get("style_bible_id"):
        fail("STYLE_BIBLE_ID_MISMATCH")
    planned = plan.get("takes") or []
    directed = treatment.get("takes") or []
    plan_ids = [item.get("take_id") for item in planned]
    treatment_ids = [item.get("take_id") for item in directed]
    if not plan_ids or any(not isinstance(i, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", i) for i in plan_ids):
        fail("INVALID_TAKE_IDS")
    if len(set(plan_ids)) != len(plan_ids) or len(set(treatment_ids)) != len(treatment_ids):
        fail("DUPLICATE_TAKE_IDS")
    if plan_ids != treatment_ids:
        fail("TAKE_ORDER_OR_COVERAGE_MISMATCH")
    try:
        locked = _locked_framework(bible)
    except VisualContractError as exc:
        locked = []
        fail(str(exc))
    grammar = treatment.get("grammar", {}).get("framework")
    if not isinstance(grammar, list) or not all(isinstance(i, str) for i in grammar):
        fail("INVALID_FRAMEWORK_GRAMMAR")
        grammar = []
    if _tokens(" / ".join(grammar)) != locked:
        fail("GRAMMAR_STYLE_BIBLE_MISMATCH")
    minimum_font = bible.get("typography", {}).get("minimum_sizes", {}).get("1920x1080")
    if type(minimum_font) not in (int, float) or minimum_font <= 0:
        fail("MINIMUM_FONT_UNAVAILABLE")
        minimum_font = None
    # Invalid path-like IDs must never reach the renderer's textfile writes.
    if any(item["code"] in {"INVALID_TAKE_IDS", "DUPLICATE_TAKE_IDS", "TAKE_ORDER_OR_COVERAGE_MISMATCH"} for item in findings):
        return {"status": "BLOCKED", "takes": takes, "findings": findings, "take_count": len(planned)}

    previous_end = 0
    try:
        font = _font()
    except OSError as exc:
        fail("FONT_UNAVAILABLE", detail=f"{type(exc).__name__}: {exc}")
        return {"status": "BLOCKED", "takes": takes, "findings": findings, "take_count": len(planned)}
    with tempfile.TemporaryDirectory(prefix="heroverse-visual-contract-") as temporary:
        base = Path(temporary)
        for take, direction in zip(planned, directed, strict=True):
            take_id = take["take_id"]
            start, end = take.get("start_ms"), take.get("end_ms")
            if type(start) is not int or type(end) is not int or start != previous_end or end <= start:
                fail("TAKE_TIMELINE_MISMATCH", take_id, f"{start}..{end}; previous_end={previous_end}")
            previous_end = end
            kind = direction.get("treatment")
            if kind not in KINDS:
                fail("UNSUPPORTED_TREATMENT", take_id, str(kind))
                continue
            expected = take.get("on_screen_text")
            if expected is not None and not isinstance(expected, str):
                fail("INVALID_TEXT_TYPE", take_id, type(expected).__name__)
                continue
            if kind in {"HOOK_STAMP", "HOOK_FRAMEWORK", "SCRIPTURE_SEQUENCE", "FRAMEWORK_STEP", "KEYWORD_PUNCH", "SECTION_CARD", "PAYOFF_RESOLUTION"} and not (expected or "").strip():
                fail("REQUIRED_TEXT_MISSING", take_id, kind)
            if kind in {"ACTION_EVIDENCE", "CINEMATIC_BODY"} and expected is not None:
                fail("TEXT_PROHIBITED_FOR_TREATMENT", take_id, kind)
            work = base / take_id
            work.mkdir()
            try:
                filters = _visual_filters(take, direction, font=font, work_dir=work)
            except (TypeError, ValueError, KeyError, OSError) as exc:
                fail("RENDERER_RECIPE_ERROR", take_id, f"{type(exc).__name__}: {exc}")
                continue
            text_filters = [value for value in filters if value.startswith("drawtext=")]
            texts = []
            for path in sorted(work.glob("*.txt")):
                texts.append({"name": path.name, "text": path.read_text(encoding="utf-8")})
            if len(texts) != len(text_filters):
                fail("TEXT_FILTER_INPUT_COUNT_MISMATCH", take_id)
            # State badges and the locked channel-system signature are
            # supplemental identity, never substitutes for the planned hook.
            primary = [item["text"] for item in texts if not item["name"].endswith("-state.txt") and "-system-" not in item["name"]]
            if _tokens(" ".join(primary)) != _tokens(expected):
                fail("PLANNED_VS_RENDERER_TEXT_MISMATCH", take_id,
                     json.dumps({"planned": expected, "recipe": primary}, ensure_ascii=False))
            if kind == "HOOK_FRAMEWORK":
                system = [item["text"] for item in texts if "-system-" in item["name"]]
                if _tokens(" ".join(system)) != locked:
                    fail("PLAN_STYLE_BIBLE_FRAMEWORK_MISMATCH", take_id,
                         json.dumps({"style_bible": locked, "recipe_system": system}, ensure_ascii=False))
            sizes = []
            for value in text_filters:
                match = re.search(r"(?:^|:)fontsize=(\d+)(?=:|$)", value)
                size = int(match.group(1)) if match else None
                sizes.append(size)
                if size is None or minimum_font is None or size < minimum_font:
                    fail("FONT_BELOW_STYLE_BIBLE_MINIMUM", take_id, f"recipe={size}; minimum={minimum_font}")
            takes.append({
                "take_id": take_id, "start_ms": start, "end_ms": end,
                "treatment": kind, "expected_text": expected,
                "recipe_texts": texts, "font_sizes": sizes,
            })
    return {"status": "BLOCKED" if findings else "PASS", "takes": takes,
            "findings": findings, "take_count": len(planned)}


def require_visual_contract(plan: dict[str, Any], treatment: dict[str, Any], bible: dict[str, Any], *, evidence_root: Path | None = None) -> None:
    if evidence_root is not None:
        values = dict(zip(INPUTS, (plan, treatment, bible), strict=True))
        result = _materialize(evidence_root.resolve(), values=values, proposed=True)
    else:
        result = build_visual_contract(plan, treatment, bible)
    if result["status"] != "PASS":
        details = ";".join(f"{f['code']}:{f['take_id'] or 'contract'}" for f in result["findings"])
        raise VisualContractError("VISUAL_CONTRACT_PREFLIGHT_BLOCKED:" + details + ";evidence=" + result.get("path", "in-memory"))


def _build_audit(values: dict[str, Any], sources: list[dict[str, Any]], *, proposed: bool) -> dict[str, Any]:
    try:
        result = build_visual_contract(values["take_plan.json"], values["creative_treatment_plan.json"],
                                       values["channel_style_bible.json"])
    except OSError as exc:
        result = {"status": "BLOCKED", "takes": [], "take_count": len(values["take_plan.json"]["takes"]),
                  "findings": [{"code": "LOCAL_RECIPE_INSPECTION_UNAVAILABLE", "take_id": None,
                                "detail": f"{type(exc).__name__}: {exc}"}]}
    result.update({
        "schema_version": VERSION, "auditor_version": VERSION,
        "input_stage": "PROPOSED" if proposed else "CURRENT",
        "recipe_id": plan_renderer(values["take_plan.json"]),
        "evidence_type": "PRE_EFFECT_RECIPE_INSPECTION_NOT_PIXEL_QA",
        "sources": sources,
        "loaded_recipe_sha256": _hash(marshal.dumps(tuple(f.__code__ for f in (_visual_filters, _drawtext_filter, _ffmpeg_path, _font)))),
        "validator_source_sha256": _hash(Path(__file__).read_bytes()),
        "pixel_validation": "NOT_EXECUTED", "publication_authorized": False,
        "technical_cost_brl": 0,
    })
    audit_id = "visual-preflight-" + hashlib.sha256(_encoded(result)).hexdigest()[:24]
    result["audit_id"] = audit_id
    return result


def _atomic_immutable(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise VisualContractError("IMMUTABLE_VISUAL_PREFLIGHT_COLLISION")
    finally:
        temporary.unlink(missing_ok=True)


def _materialize(root: Path, *, values: dict[str, Any] | None = None, proposed: bool = False) -> dict[str, Any]:
    values = {} if values is None else dict(values)
    sources = []
    for name, schema_name in INPUTS.items():
        if proposed:
            data = _encoded(values[name])
            path = root / AUDITS / "inputs" / (_hash(data).split(":")[1] + ".json")
        else:
            path = (root / PRODUCTION / name).resolve()
            if path.parent != (root / PRODUCTION).resolve() or not path.is_relative_to(root):
                raise VisualContractError("VISUAL_INPUT_PATH_ESCAPED")
            data = path.read_bytes()
            values[name] = json.loads(data.decode("utf-8-sig"))
        schema_data = (root / "schemas" / schema_name).read_bytes()
        Draft202012Validator(json.loads(schema_data), format_checker=FormatChecker()).validate(values[name])
        if proposed:
            if not path.resolve().is_relative_to(root):
                raise VisualContractError("VISUAL_PROPOSED_INPUT_PATH_ESCAPED")
            _atomic_immutable(path, data)
        sources.append({"path": path.relative_to(root).as_posix(), "sha256": _hash(data),
                        "schema": schema_name, "schema_sha256": _hash(schema_data)})
    result = _build_audit(values, sources, proposed=proposed)
    schema = json.loads((root / "schemas" / SCHEMA).read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(result)
    for source in sources:
        if _hash((root / source["path"]).read_bytes()) != source["sha256"] or _hash(
            (root / "schemas" / source["schema"]).read_bytes()
        ) != source["schema_sha256"]:
            raise VisualContractError("VISUAL_CONTRACT_CHANGED_DURING_PREFLIGHT")
    destination = root / AUDITS / f"{result['audit_id']}.json"
    if not destination.resolve().is_relative_to(root):
        raise VisualContractError("VISUAL_AUDIT_OUTPUT_PATH_ESCAPED")
    payload = _encoded(result)
    _atomic_immutable(destination, payload)
    return {"status": result["status"], "audit_id": result["audit_id"],
            "path": destination.relative_to(root).as_posix(), "sha256": _hash(payload),
            "findings": result["findings"]}


def materialize_current_visual_preflight(root: Path) -> dict[str, Any]:
    return _materialize(root.resolve())


def verify_visual_preflight(root: Path, binding: dict[str, Any], *, require_pass: bool = True) -> dict[str, Any]:
    return _verify_visual_preflight(root, binding, require_pass=require_pass, completed_checkpoint=False)


def verify_completed_visual_preflight(root: Path, binding: dict[str, Any]) -> dict[str, Any]:
    """Reopen completed v2 evidence, without making it a current render gate."""
    return _verify_visual_preflight(root, binding, require_pass=True, completed_checkpoint=True)


def _verify_visual_preflight(root: Path, binding: dict[str, Any], *, require_pass: bool,
                             completed_checkpoint: bool) -> dict[str, Any]:
    root = root.resolve()
    path = (root / binding["path"]).resolve()
    if not path.is_relative_to(root) or path.parent != (root / AUDITS).resolve() or path.name != f"{binding['audit_id']}.json":
        raise VisualContractError("VISUAL_AUDIT_PATH_OR_ID_DIVERGED")
    data = path.read_bytes()
    if _hash(data) != binding["sha256"]:
        raise VisualContractError("VISUAL_AUDIT_HASH_DIVERGED")
    audit = json.loads(data)
    Draft202012Validator(json.loads((root / "schemas" / SCHEMA).read_bytes()), format_checker=FormatChecker()).validate(audit)
    values = {}
    proposed = audit["input_stage"] == "PROPOSED"
    historical = completed_checkpoint and audit["validator_source_sha256"] == PRE_QP1_AUDITOR_SHA256
    if historical:
        if proposed or audit["recipe_id"] != PHASE6_SEGMENT_RENDERER:
            raise VisualContractError("COMPLETED_VISUAL_HISTORY_SCOPE_DIVERGED")
        archived_validator = (root / PRE_QP1_AUDITOR).resolve()
        if not archived_validator.is_relative_to(root) or _hash(archived_validator.read_bytes()) != PRE_QP1_AUDITOR_SHA256:
            raise VisualContractError("COMPLETED_VISUAL_VALIDATOR_ARCHIVE_DIVERGED")
    if len(audit["sources"]) != len(INPUTS):
        raise VisualContractError("VISUAL_AUDIT_SOURCE_COUNT_DIVERGED")
    for (name, schema_name), source in zip(INPUTS.items(), audit["sources"], strict=True):
        expected = root / (AUDITS / "inputs" / (source["sha256"].split(":")[1] + ".json") if proposed else PRODUCTION / name)
        observed = (root / source["path"]).resolve()
        if not observed.is_relative_to(root) or observed != expected.resolve() or source["schema"] != schema_name:
            raise VisualContractError("VISUAL_AUDIT_SOURCE_IDENTITY_DIVERGED")
        raw = observed.read_bytes()
        schema_raw = (root / "schemas" / schema_name).read_bytes()
        if historical and schema_name == "take_plan.schema.json":
            if source["schema_sha256"] != PRE_QP1_PLAN_SCHEMA_SHA256:
                raise VisualContractError("COMPLETED_VISUAL_SCHEMA_PIN_DIVERGED")
            if _hash(schema_raw) == QP1_PLAN_SCHEMA_SHA256:
                archived_schema = (root / PRE_QP1_PLAN_SCHEMA).resolve()
                if not archived_schema.is_relative_to(root):
                    raise VisualContractError("COMPLETED_VISUAL_SCHEMA_ARCHIVE_ESCAPED")
                schema_raw = archived_schema.read_bytes()
        if _hash(raw) != source["sha256"] or _hash(schema_raw) != source["schema_sha256"]:
            raise VisualContractError("VISUAL_AUDIT_SOURCE_HASH_DIVERGED")
        values[name] = json.loads(raw.decode("utf-8-sig"))
        Draft202012Validator(json.loads(schema_raw), format_checker=FormatChecker()).validate(values[name])
    recomputed = _build_audit(values, audit["sources"], proposed=proposed)
    if historical:
        # Authenticate the original ID/source independently, then demand exact
        # equality of all measured contract fields, sources and loaded recipe.
        # Do not rewrite either identity or transfer its PASS to new bytes.
        original_body = {key: value for key, value in audit.items() if key != "audit_id"}
        original_id = "visual-preflight-" + hashlib.sha256(_encoded(original_body)).hexdigest()[:24]
        identities = {"audit_id", "validator_source_sha256"}
        matches = (
            original_id == audit["audit_id"] and _encoded(audit) == data
            and {key: value for key, value in recomputed.items() if key not in identities}
            == {key: value for key, value in audit.items() if key not in identities}
        )
    else:
        matches = _encoded(recomputed) == data
    if not matches or binding["audit_id"] != audit["audit_id"] or binding["status"] != audit["status"]:
        raise VisualContractError("VISUAL_AUDIT_RECOMPUTATION_DIVERGED")
    if require_pass and (audit["status"] != "PASS" or proposed):
        raise VisualContractError("CURRENT_VISUAL_PREFLIGHT_PASS_REQUIRED")
    return audit


def require_current_visual_preflight(root: Path) -> dict[str, Any]:
    result = materialize_current_visual_preflight(root)
    verify_visual_preflight(root, result, require_pass=False)
    if result["status"] != "PASS":
        codes = sorted({item["code"] for item in result["findings"]})
        raise VisualContractError(f"VISUAL_CONTRACT_PREFLIGHT_BLOCKED:{','.join(codes)};evidence={result['path']}", binding=result)
    return result
