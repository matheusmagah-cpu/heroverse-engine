from __future__ import annotations

import hashlib
import json
import os
import stat
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _outside_workspace(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        return True
    return False


def inspect_authorized_user_token(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    value = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("OAuth token must be a JSON object")
    scopes = value.get("scopes")
    if not isinstance(scopes, list) or not all(isinstance(scope, str) and scope for scope in scopes):
        raise ValueError("OAuth token scopes are missing or invalid")
    for field in ("token", "refresh_token", "token_uri", "client_id", "client_secret"):
        if not isinstance(value.get(field), str) or not value[field]:
            raise ValueError(f"OAuth token field is missing: {field}")
    durable_grant = {
        "refresh_token": value["refresh_token"],
        "token_uri": value["token_uri"],
        "client_id": value["client_id"],
        "client_secret": value["client_secret"],
        "scopes": sorted(set(scopes)),
    }
    return {
        "raw": raw,
        "sha256": _sha256_bytes(raw),
        # This digest intentionally excludes the short-lived access token and
        # expiry.  It detects a genuinely different installed-app grant
        # without exposing any credential value.
        "grant_sha256": _sha256_bytes(
            json.dumps(
                durable_grant,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ),
        "bytes": len(raw),
        "scopes": sorted(set(scopes)),
        "refresh_token_present": bool(value.get("refresh_token")),
    }


def mirror_authorized_user_token(
    source: Path,
    destination: Path,
    receipt_path: Path,
    *,
    root: Path = ROOT,
    required_scopes: list[str] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    source = source.resolve()
    destination = destination.resolve()
    if source == destination:
        raise ValueError("OAuth source and runtime mirror must be distinct files")
    if not _outside_workspace(source, root) or not _outside_workspace(destination, root):
        raise PermissionError("OAuth source and runtime mirror must remain outside the workspace")

    inspected = inspect_authorized_user_token(source)
    required = sorted(set(required_scopes or INTEGRATION_SCOPES))
    missing = sorted(set(required) - set(inspected["scopes"]))
    if missing:
        raise PermissionError("OAuth source does not grant every required runtime scope")

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("wb") as handle:
            handle.write(inspected["raw"])
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temporary, stat.S_IREAD | stat.S_IWRITE)
        except OSError:
            pass
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()

    mirrored = inspect_authorized_user_token(destination)
    if mirrored["sha256"] != inspected["sha256"] or mirrored["bytes"] != inspected["bytes"]:
        raise OSError("OAuth runtime mirror failed its post-replace hash verification")

    receipt = {
        "schema_version": "1.0.0",
        "receipt_id": f"oauth-token-mirror-{inspected['sha256'][:20]}",
        "integration_id": "youtube-heroverse-v1",
        "status": "MIRRORED",
        "source_class": "OAUTH_LOCAL_SECRET_OUTSIDE_WORKSPACE",
        "destination_class": "WINDOWS_TASK_SECRET_OUTSIDE_WORKSPACE",
        "source_outside_workspace": True,
        "destination_outside_workspace": True,
        "source_sha256": inspected["sha256"],
        "destination_sha256": mirrored["sha256"],
        "size_bytes": mirrored["bytes"],
        "required_scopes": required,
        "granted_scopes": mirrored["scopes"],
        "refresh_token_present": mirrored["refresh_token_present"],
        "atomic_replace": True,
        "secret_logged": False,
        "technical_cost_brl": 0,
        "mirrored_at": created_at or _now(),
    }
    schema = json.loads((root / "schemas/oauth_token_mirror_receipt.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(receipt)
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_receipt = receipt_path.with_suffix(receipt_path.suffix + ".tmp")
    temporary_receipt.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary_receipt.replace(receipt_path)
    return receipt


def wait_and_mirror(
    source: Path,
    destination: Path,
    receipt_path: Path,
    *,
    root: Path = ROOT,
    timeout_seconds: int = 86400,
    poll_seconds: float = 2.0,
) -> dict[str, Any]:
    deadline = time.monotonic() + max(1, timeout_seconds)
    last_error = "OAuth source is not ready"
    while time.monotonic() < deadline:
        try:
            return mirror_authorized_user_token(source, destination, receipt_path, root=root)
        except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError, ValueError, PermissionError) as exc:
            last_error = f"{type(exc).__name__}: {exc}"
        time.sleep(max(0.1, poll_seconds))
    raise TimeoutError(f"OAuth token mirror timed out without a four-scope source: {last_error}")
