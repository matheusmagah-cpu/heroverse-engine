from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .youtube_integration import (
    INTEGRATION_SCOPES,
    YOUTUBE_ANALYTICS_SCOPE,
    YOUTUBE_FORCE_SSL_SCOPE,
    YOUTUBE_READ_SCOPE,
    YOUTUBE_UPLOAD_SCOPE,
)


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _subtitle_stream_count(path: Path) -> int:
    completed = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "s", "-show_entries", "stream=index", "-of", "json", str(path)],
        check=True,
        capture_output=True,
        text=True,
    )
    return len(json.loads(completed.stdout).get("streams") or [])


def build_scope_requirement(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    integration = _read(root / "config/integrations/youtube-heroverse-v1.json")
    receipt = _read(root / "output/integrations/youtube/heroverse/connection-receipt.json")
    observation = _read(root / "output/integrations/youtube/heroverse/google-auth-platform-observation.json")
    package = _read(root / "output/production/phase5/pilot-001/creative-v3/publication_package.json")
    video = Path(package["video"]["path"])
    caption = Path(package["captions"]["path"])
    required = list(integration["oauth"]["scopes"])
    if required != INTEGRATION_SCOPES:
        raise ValueError("Integration config and runtime scope order differ")
    granted = sorted(set(receipt["authorization"]["granted_scopes"]))
    missing = [scope for scope in required if scope not in granted]
    declared_count = sum(
        int(observation["declared_scopes"][key])
        for key in ("non_sensitive_count", "sensitive_count", "restricted_count")
    )
    console_match = declared_count == len(required) and observation["declared_scopes"]["configuration_matches_runtime"]
    if missing and not console_match:
        status = "BLOCKED_MISSING_GRANT_AND_CONSOLE_MISMATCH"
    elif missing:
        status = "BLOCKED_MISSING_GRANT"
    elif not console_match:
        status = "BLOCKED_CONSOLE_MISMATCH"
    else:
        status = "PASS"
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    capabilities = [
        ("CHANNEL_IDENTITY_AND_METADATA", "channels.list/videos.list", YOUTUBE_READ_SCOPE, "read-only calls only", "access to owned-channel read data"),
        ("OWNED_CHANNEL_ANALYTICS", "youtubeAnalytics.reports.query", YOUTUBE_ANALYTICS_SCOPE, "aggregate owner metrics; no monetary scope", "access to authorized private Analytics"),
        ("VIDEO_AND_THUMBNAIL_UPLOAD", "videos.insert/thumbnails.set", YOUTUBE_UPLOAD_SCOPE, "private upload only after release receipt", "ability to manage uploaded video content"),
        ("CAPTION_TRACK_UPLOAD", "captions.insert", YOUTUBE_FORCE_SSL_SCOPE, "adapter exposes captions.insert for the frozen SRT; no caption update/delete/rating/comment methods", "Google defines this scope broadly enough to edit or delete videos, ratings, comments and captions"),
        ("PUBLIC_VISIBILITY_FINALIZATION", "videos.update", YOUTUBE_FORCE_SSL_SCOPE, "adapter may change only status.privacyStatus from private to public after post-upload gates; no delete or unrelated metadata update", "a premature or incorrect update could expose an incomplete video"),
        ("CANARY_PACKAGE_TREATMENT", "videos.update(snippet)/thumbnails.set", YOUTUBE_FORCE_SSL_SCOPE, "adapter may change only the preregistered canary title-thumbnail pair after the package release gate; it preserves the full snippet, verifies the public result and rolls both fields back on failure", "an incorrect package mutation could misrepresent or visually damage the public canary"),
    ]
    report = {
        "schema_version": "1.0.0",
        "requirement_id": "oauth-scope-requirement-" + hashlib.sha256("|".join(required).encode()).hexdigest()[:20],
        "integration_id": integration["integration_id"],
        "channel_id": CHANNEL_ID,
        "required_scopes": required,
        "current_granted_scopes": granted,
        "missing_scopes": missing,
        "capabilities": [
            {"capability": name, "api_method": method, "required_scope": scope, "granted_now": scope in granted, "least_use_boundary": boundary, "risk": risk}
            for name, method, scope, boundary, risk in capabilities
        ],
        "caption_delivery": {
            "sidecar_path": str(caption),
            "sidecar_exists": caption.is_file(),
            "embedded_subtitle_stream_count": _subtitle_stream_count(video),
            "automatic_method": "captions.insert",
            "required_scope": YOUTUBE_FORCE_SSL_SCOPE,
            "fallbacks": [
                {"mode": "BURNED_IN_REQUALIFIED_RENDER", "automation_level": "AUTOMATIC_LOCAL", "impact": "Changes the frozen render hash and requires a new STANDARD qualification plus human review."},
                {"mode": "MANUAL_YOUTUBE_STUDIO_CAPTION_UPLOAD", "automation_level": "HUMAN", "impact": "Preserves the render but violates the target of unattended publication."},
            ],
        },
        "console_alignment": {"declared_scope_count_observed": declared_count, "configuration_matches_runtime": console_match},
        "status": status,
        "protected_action_required": True,
        "claim_boundary": "This report proves the scope needed by the selected API method and current grant/configuration gaps. It does not authorize consent, broaden adapter behavior, make OAuth durable or permit upload.",
        "official_sources": [
            "https://developers.google.com/youtube/v3/docs/captions/insert",
            "https://developers.google.com/youtube/v3/guides/authentication",
            "https://developers.google.com/youtube/v3/docs/videos/update",
            "https://developers.google.com/youtube/v3/docs/thumbnails/set",
            "https://developers.google.com/youtube/v3/determine_quota_cost",
        ],
        "created_at": timestamp,
    }
    schema = _read(root / "schemas/oauth_runtime_scope_requirement.schema.json")
    Draft202012Validator(schema).validate(report)
    return report


def materialize(root: Path = ROOT) -> Path:
    result = build_scope_requirement(root)
    path = root.resolve() / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    print(materialize())
