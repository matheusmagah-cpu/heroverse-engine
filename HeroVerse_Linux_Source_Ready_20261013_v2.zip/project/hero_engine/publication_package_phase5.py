from __future__ import annotations

import hashlib
import io
import os
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .db import ROOT


PILOT = Path("output/production/phase5/pilot-001")


def _static_sha(path: Path) -> str:
    return 'sha256:' + _sha256(path)


def _static_packaging_inputs(root: Path, relative: Path):
    from .qa_phase5 import _audio_static_inputs
    from .procedural_infographics_phase5 import read_audio_static_source
    root=root.resolve();relative=Path(relative);package=(root/relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not package.is_relative_to(root/'output/production'):
        raise PermissionError('Packaging escaped production root')
    observed=_audio_static_inputs(root,package)
    bindings={Path(row['path']):row['sha256'] for row in observed['inputs']}
    plan=_read(package/'take_plan.json');voice=_read(package/'audio/voice_render_manifest.json')
    script=package/'narrative_script.json'
    if _static_sha(script)!=voice['narrative_script']['sha256']:
        raise PermissionError('Packaging script differs from measured voice')
    bindings[script]=_static_sha(script)
    asset=_read(package/'asset_manifest.json')['assets'][0]
    rights=_read(Path(asset['rights_evidence_uri']))
    source=rights['composition_manifest'];manifest=Path(source['path'])
    composition=read_audio_static_source(root,manifest,expected_sha256=source['sha256'])
    bindings[manifest]=source['sha256']
    for path,expected in ((composition['produced']['raster'],composition['produced']['raster_hash']),
        (composition['source_svg'],composition['source_svg_hash']),
        (composition['generator']['path'],composition['generator']['sha256']),
        (composition['layout']['font']['path'],composition['layout']['font']['sha256'])):
        bindings[Path(path)]=expected
    return package,plan,asset,composition,bindings


def _static_caption_bytes(plan):
    from .render_creative_v3_phase5 import _timestamp
    blocks=[];expected_start=0
    for index,take in enumerate(plan['takes'],1):
        text=' '.join(str(take.get('narration') or '').split())
        if (not text or len(text.split())>12 or take['start_ms']!=expected_start
                or take['end_ms']<=expected_start):
            raise PermissionError('Caption copy, population or measured clock invalid')
        blocks.append(f"{index}\n{_timestamp(take['start_ms'])} --> {_timestamp(take['end_ms'])}\n{text}\n")
        expected_start=take['end_ms']
    # Existing Path.write_text caption producer uses the host's native newline.
    return '\n'.join(blocks).replace('\n',os.linesep).encode('utf-8')


def _static_thumbnail_bytes(asset):
    from PIL import Image
    with Image.open(asset['uri']) as image:
        if image.size!=(1920,1080):raise PermissionError('Thumbnail source geometry differs')
        thumbnail=image.convert('RGB').resize((1280,720),Image.Resampling.LANCZOS)
    buffer=io.BytesIO();thumbnail.save(buffer,format='PNG')
    raw=buffer.getvalue()
    if len(raw)>2_097_152:raise PermissionError('Owned thumbnail exceeds platform limit')
    return raw


def read_audio_static_packaging(root: Path, *, package_relative: Path,
                                 music_bindings: dict | None = None) -> dict[str, Any]:
    """Native provenance/caption reader; never claims final release quality."""
    if music_bindings is not None:
        return _instrumental_packaging(root,package_relative,music_bindings,prepare=False)
    package,plan,asset,source,bindings=_static_packaging_inputs(root,package_relative)
    path=package/'packaging/static_packaging_receipt.json';receipt=_read(path)
    records=[{'path':str(p),'sha256':h} for p,h in sorted(bindings.items())]
    identity=hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if (receipt.get('version')!='audio-static-packaging-v1'
            or receipt.get('inputs')!=records or receipt.get('packaging_id')!='audio-static-packaging-'+identity[:24]
            or receipt.get('take_plan_id')!=plan['take_plan_id']
            or receipt.get('authority')!={'render':False,'publication':False}):
        raise PermissionError('Packaging identity/inputs/authority diverged')
    expected={'captions/en-US.srt':_static_caption_bytes(plan),
              'thumbnail/owned-static.png':_static_thumbnail_bytes(asset)}
    if set(receipt.get('artifacts',{}))!=set(expected):raise PermissionError('Packaging artifact population differs')
    for name,raw in expected.items():
        target=package/name;row=receipt['artifacts'][name]
        digest='sha256:'+hashlib.sha256(raw).hexdigest()
        if target.read_bytes()!=raw or row!={'path':str(target),'sha256':digest,'size_bytes':len(raw)}:
            raise PermissionError('Caption or owned thumbnail differs from native reproduction')
    if any(_static_sha(p)!=h for p,h in bindings.items()):raise PermissionError('Packaging source changed')
    return {'status':'CAPTIONS_AND_THUMBNAIL_PROVENANCE_VERIFIED_NOT_RELEASED',
        'binding':{'path':str(path),'sha256':_static_sha(path)},'cue_count':len(plan['takes']),
        'caption_clock':'MEASURED_TAKE_CONTAINERS_NOT_WORD_ALIGNMENT',
        'thumbnail':receipt['artifacts']['thumbnail/owned-static.png'],
        'thumbnail_text':[row['source_text'] for row in source['layout']['texts']],
        'quality_authorized':False,'publication_authorized':False,
        'inputs':records+list(receipt['artifacts'].values())+[{'path':str(path),'sha256':_static_sha(path)}]}


def prepare_audio_static_packaging(root: Path, *, package_relative: Path,
                                    music_bindings: dict | None = None,
                                    previous_packaging_binding: dict | None = None,
                                    previous_renderer_binding: dict | None = None) -> dict[str, Any]:
    """Reuse native captions and owned composition; no FFmpeg, voice or upload."""
    if music_bindings is not None:
        return _instrumental_packaging(root,package_relative,music_bindings,prepare=True,
            previous_packaging_binding=previous_packaging_binding,
            previous_renderer_binding=previous_renderer_binding)
    if previous_packaging_binding is not None or previous_renderer_binding is not None:
        raise PermissionError('renderer successor is restricted to the explicit musical packaging branch')
    from .render_creative_v3_phase5 import _build_captions
    from .phase6_asset_residency import _write_immutable
    package,plan,asset,source,bindings=_static_packaging_inputs(root,package_relative)
    if (package/'packaging/static_packaging_receipt.json').exists():
        return read_audio_static_packaging(root,package_relative=package_relative)
    destinations=[package/'captions/en-US.srt',package/'thumbnail/owned-static.png']
    if any(p.exists() for p in destinations):raise PermissionError('Partial packaging must be reconciled, not overwritten')
    caption_raw=_static_caption_bytes(plan);thumbnail_raw=_static_thumbnail_bytes(asset)
    captions=_build_captions(plan,destinations[0])
    if destinations[0].read_bytes()!=caption_raw:raise PermissionError('Native caption producer differs')
    destinations[1].parent.mkdir(parents=True,exist_ok=True)
    with destinations[1].open('xb') as stream:stream.write(thumbnail_raw)
    if any(_static_sha(p)!=h for p,h in bindings.items()):raise PermissionError('Packaging source changed before receipt')
    records=[{'path':str(p),'sha256':h} for p,h in sorted(bindings.items())]
    identity=hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    _write_immutable(package/'packaging/static_packaging_receipt.json',{
        'version':'audio-static-packaging-v1','packaging_id':'audio-static-packaging-'+identity[:24],
        'take_plan_id':plan['take_plan_id'],'inputs':records,'captions':captions,
        'artifacts':{str(p.relative_to(package)).replace('\\','/'):{'path':str(p),
            'sha256':_static_sha(p),'size_bytes':p.stat().st_size} for p in destinations},
        'authority':{'render':False,'publication':False},
        'scope':'Owned source reproduction and measured sentence containers, not final audiovisual quality'})
    return read_audio_static_packaging(root,package_relative=package_relative)


def _instrumental_packaging(root: Path, relative: Path, bindings: dict, *, prepare: bool,
        previous_packaging_binding: dict | None = None,
        previous_renderer_binding: dict | None = None) -> dict:
    """One explicit musical branch of the existing producer/reader.

    No fake script, voice or caption file. Reuse exactly the admitted owned
    composition and deterministic thumbnail transform. This is not a release
    receipt, current channel readiness or a performance/medical prediction.
    """
    from .render_phase5 import _rest_render_inputs
    from .phase6_asset_residency import _write_immutable
    root=root.resolve();relative=Path(relative);package=(root/relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not package.is_relative_to(root/'output/production'):
        raise PermissionError('Instrumental packaging escaped production root')
    music,asset,inputs=_rest_render_inputs(root,package,bindings)
    image=_static_thumbnail_bytes(asset)
    duration=music['recipe']['duration_ms']
    prefix=f'{duration//3600000} Hours of ' if duration%3600000==0 else ''
    metadata={'title':prefix+'Gentle Instrumental Music for Quiet Prayer | HeroVerse',
        'description':'Original HeroVerse instrumental music with an owned static composition for quiet Christian prayer and reflection. '
            'No borrowed recording, narration, medical treatment or guaranteed sleep, revenue or outcome.\n'
            '#Prayer #InstrumentalMusic #HeroVerse',
        'tags':['Christian prayer','instrumental music','quiet reflection','HeroVerse'],
        'language':'en-US','expected_channel_id':EXPECTED_CHANNEL_ID,
        'privacy':'private','contains_synthetic_media':True}
    if music['voice_required']:
        editorial=music['recipe']['editorial'];samples=music['opening']['voice']['samples']
        seconds=(samples+23999)//24000
        metadata.update(title=editorial['title'],
            description='Original HeroVerse Christian perspective: rest and responsibility need not compete. '
                f'One spoken opening (measured {seconds} seconds), then original piano and pad without repeated speech. '
                'Three deliberately composed musical sections: settle, remain, return. '
                'No borrowed recording, medical treatment or guaranteed sleep, revenue or outcome.\n'
                f'00:00 Original reflection\n{seconds//3600:02d}:{seconds//60%60:02d}:{seconds%60:02d} Music without further speech\n'
                '#Prayer #ChristianReflection #HeroVerse',
            tags=['Christian reflection','prayer music','rest and responsibility','HeroVerse'])
    raw_metadata=(json.dumps(metadata,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode('utf-8')
    expected={'thumbnail/owned-static.png':image,'packaging/instrumental-metadata.json':raw_metadata}
    targets={name:(package/name).resolve() for name in expected}
    path=(package/'packaging/instrumental_packaging_receipt.json').resolve()
    if any(not target.is_relative_to(package) for target in [*targets.values(),path]):
        raise PermissionError('Instrumental packaging output escaped through alias')
    records=[{'path':str(p),'sha256':h} for p,h in sorted(inputs.items())]
    identity=hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    receipt={'version':'christian-rest-instrumental-packaging-v1',
        'packaging_id':'instrumental-packaging-'+identity[:24],
        'recipe_id':music['recipe']['recipe_id'],'music_bindings':bindings,'inputs':records,
        'artifacts':{name:{'path':str(targets[name]),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest(),
                           'size_bytes':len(raw)} for name,raw in expected.items()},
        'captions_applicability':('MEASURED_SPOKEN_OPENING_ONLY' if music['voice_required'] else
                                  'NOT_APPLICABLE_INSTRUMENTAL_NO_SPEECH'),
        'authority':{'quality':False,'render':False,'publication':False}}
    if path.exists() and _read(path) != receipt:
        # Only code-origin evolution, with exact unchanged metadata/media. The
        # old receipt is never overwritten, repinned or treated as current QA.
        legacy = path
        legacy_hash = _static_sha(legacy)
        successor_id = hashlib.sha256((identity+'|'+legacy_hash).encode()).hexdigest()
        path = (package/'packaging/instrumental-packaging-successors'/f'{successor_id}.json').resolve()
        if not path.is_relative_to(package):
            raise PermissionError('packaging successor escaped through alias')
        if path.exists():
            archived = _read(path)
            if previous_packaging_binding is None and previous_renderer_binding is None:
                previous_packaging_binding = archived.get('previous_packaging')
                previous_renderer_binding = archived.get('previous_renderer')
        if previous_packaging_binding is None or previous_renderer_binding is None:
            raise PermissionError('stale packaging needs an explicitly anchored native code-only successor')
        for bound in (previous_packaging_binding,previous_renderer_binding):
            if type(bound) is not dict or set(bound) != {'path','sha256'}:
                raise PermissionError('packaging predecessor binding is incomplete')
            target=Path(bound['path']).resolve()
            if not target.is_relative_to(root) or _static_sha(target) != bound['sha256']:
                raise PermissionError('packaging predecessor bytes differ')
        archive=Path(previous_renderer_binding['path']).resolve()
        if (Path(previous_packaging_binding['path']).resolve() != legacy
                or previous_packaging_binding['sha256'] != legacy_hash
                or not archive.is_relative_to(root/'output/runtime/gestor-central/maintenance-runs')
                or 'source-preimages' not in archive.parts or archive.parent.name != 'hero_engine'
                or archive.name != 'render_phase5.py'):
            raise PermissionError('packaging needs its actual immutable renderer preimage')
        old=_read(legacy)
        old_inputs={entry['path']:entry['sha256'] for entry in old['inputs']}
        new_inputs={entry['path']:entry['sha256'] for entry in records}
        renderer=str(root/'hero_engine/render_phase5.py')
        if (len(old_inputs)!=len(old['inputs']) or renderer not in old_inputs
                or old_inputs[renderer] != previous_renderer_binding['sha256']
                or old_inputs[renderer] == new_inputs.get(renderer)
                or {p:h for p,h in old_inputs.items() if p!=renderer}
                   != {p:h for p,h in new_inputs.items() if p!=renderer}):
            raise PermissionError('packaging successor is not exact renderer-only evolution')
        projected=dict(old,inputs=records,packaging_id=receipt['packaging_id'])
        if projected != receipt or any(targets[name].read_bytes()!=raw for name,raw in expected.items()):
            raise PermissionError('packaging successor cannot change approved metadata or media')
        receipt=dict(receipt,version='christian-rest-instrumental-packaging-v2',
            packaging_id='instrumental-packaging-successor-'+successor_id[:24],
            previous_packaging=previous_packaging_binding,previous_renderer=previous_renderer_binding)
        if prepare and not path.exists():
            if (any(_static_sha(p)!=h for p,h in inputs.items())
                    or _static_sha(legacy)!=legacy_hash or _static_sha(archive)!=previous_renderer_binding['sha256']):
                raise PermissionError('packaging inputs changed before native successor receipt')
            _write_immutable(path,receipt)
    elif previous_packaging_binding is not None or previous_renderer_binding is not None:
        raise PermissionError('packaging successor requires actual renderer evolution')
    if prepare and not path.exists():
        if any(target.exists() for target in targets.values()):
            raise PermissionError('Partial instrumental packaging preserved; no overwrite')
        if any(_static_sha(p)!=h for p,h in inputs.items()):
            raise PermissionError('Instrumental packaging input changed before effects')
        for name,raw in expected.items():
            target=targets[name];target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:stream.write(raw)
        if any(_static_sha(p)!=h for p,h in inputs.items()):
            raise PermissionError('Instrumental packaging input changed before receipt')
        _write_immutable(path,receipt)
    if _read(path)!=receipt or any(targets[name].read_bytes()!=raw for name,raw in expected.items()):
        raise PermissionError('Instrumental metadata/thumbnail identity or native bytes differ')
    if any(_static_sha(p)!=h for p,h in inputs.items()):
        raise PermissionError('Instrumental packaging inputs changed during consumption')
    history=[]
    if receipt['version']=='christian-rest-instrumental-packaging-v2':
        history=[receipt['previous_packaging'],receipt['previous_renderer']]
        if any(_static_sha(Path(bound['path']))!=bound['sha256'] for bound in history):
            raise PermissionError('packaging predecessor changed during consumption')
    return {'status':'INSTRUMENTAL_METADATA_AND_THUMBNAIL_VERIFIED_NOT_RELEASED',
        'binding':{'path':str(path),'sha256':_static_sha(path)},'recipe_id':music['recipe']['recipe_id'],
        'metadata':metadata,'thumbnail':receipt['artifacts']['thumbnail/owned-static.png'],
        'captions_applicability':receipt['captions_applicability'],
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False,
        'inputs':records+list(receipt['artifacts'].values())+[{'path':str(path),'sha256':_static_sha(path)}]+history}
TITLE = "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation"
DESCRIPTION = """Prayer is not the end of obedience. If you have been waiting for clarity, use these three questions to identify the next honest step.

This original Christian motivation message draws from James 1:2–8 and James 1:22–25:

1. Is it true?
2. What responsibility does it accept?
3. Can you act on it today?

This video does not promise that every opportunity is a sign from God or that one action guarantees an outcome. It encourages prayer, biblical wisdom, honest responsibility, trusted counsel, and concrete action.

If this helped you, write down one truthful and responsible step you can take today.

Subscribe to HeroVerse for original Christian motivation built around faith, wisdom, character, and action.

Visual credits:
• “Wolken Zeitraffer - Clouds Timelapse 4K HD 24FPS” — FreeSwissVideo, CC BY 3.0.
• “Madeira Levada- Ponta Delgada - Sao Jorge” — Madeira Levadas, CC BY 3.0.
• “Timelapse 2025 Kinnaur Monsoon” — Dfromhimalayas, CC BY 4.0.
• “Oberer Vallüla-Bach Zeitlupe” — Stefan W. Wolf, CC BY 4.0.
Full source links and license evidence are preserved in the production attribution record.

#ChristianMotivation #Prayer #FaithInAction"""
TAGS = [
    "Christian motivation",
    "after prayer",
    "what to do after praying",
    "Christian encouragement",
    "faith in action",
    "James 1",
    "biblical wisdom",
    "Christian devotional",
    "spiritual growth",
    "prayer and action",
    "obey God",
    "HeroVerse",
]
EXPECTED_CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _build_audio_static_publication_package(root, relative, report_binding, measurement_binding):
    """Assemble current frozen delivery inputs, without granting release authority.

    QA is consumed by externally supplied hashes, never by an unbound latest
    alias or a caller-provided PASS dictionary. The release gate remains owner
    of upload authority; this producer does not promote a FormatPack.
    """
    from jsonschema import Draft202012Validator
    from .qa_phase5 import GATES, _audio_static_editorial, _audio_static_inputs

    package, plan, asset, source, inputs = _static_packaging_inputs(root, relative)
    if plan['channel_id'] != EXPECTED_CHANNEL_ID:
        raise PermissionError('Current audio package belongs to another channel')
    packaging = read_audio_static_packaging(root, package_relative=relative)
    inputs.update({Path(row['path']): row['sha256'] for row in packaging['inputs']})
    editorial = _audio_static_editorial(root, package)
    inputs.update({Path(row['path']): row['sha256'] for row in editorial['inputs']})
    observed = []
    for name, binding in (('creative_quality_gate_report.json', report_binding),
                          ('technical_measurements.json', measurement_binding)):
        target = package / 'qa' / name
        if not binding or Path(binding['path']).resolve() != target.resolve():
            raise PermissionError('Current package QA requires its exact external binding')
        raw = target.read_bytes()
        digest = 'sha256:' + hashlib.sha256(raw).hexdigest()
        if binding['sha256'] != digest:
            raise PermissionError('Current QA binding differs')
        inputs[target] = digest
        observed.append(json.loads(raw.decode('utf-8-sig')))
    qa, measured = observed
    Draft202012Validator(_read(root/'schemas/creative_quality_gate_report.schema.json')).validate(qa)
    if (qa['schema_version']!='1.1.0' or len(qa['gates']) != len(GATES) or {row['gate'] for row in qa['gates']} != set(GATES)
            or any(qa[key] != plan[key] for key in
                   ('video_id', 'channel_id', 'format_pack_id', 'format_pack_version'))):
        raise PermissionError('QA population or current package identity differs')
    if measured['static_source_inputs'] != _audio_static_inputs(root, package):
        raise PermissionError('QA source population/results do not match the current native reader')
    for row in measured['static_source_inputs']['inputs']:
        path = Path(row['path'])
        if inputs.get(path) != row['sha256']:
            raise PermissionError('QA refers to different current source bytes')
    if measured['static_editorial'] != editorial:
        raise PermissionError('QA editorial inputs/results differ from the current producer')
    manifest_path = package/'render_manifest.json'
    inputs[manifest_path] = _static_sha(manifest_path)
    render = _read(manifest_path)
    video = Path(render['output']['path']).resolve()
    if (not video.is_relative_to(package) or measured['render_path'] != str(video)
            or measured['render_hash'] != _static_sha(video)
            or render['output']['content_hash'] != measured['render_hash']
            or render['voice_render_id'] != measured['static_source_inputs']['voice_render_id']
            or any(render[key] != plan[key] for key in
                   ('take_plan_id', 'style_bible_id', 'video_id', 'format_pack_id', 'format_pack_version'))):
        raise PermissionError('Publication media is not the current measured render')
    inputs[video] = measured['render_hash']
    script = _read(package/'narrative_script.json')
    title = script['title']
    if not title or len(title) > 100:
        raise PermissionError('Current title exceeds the platform contract')
    description = (script['original_thesis'] + '\n\n' +
        '\n'.join('Scripture context: '+row['source_ref'] for row in script['source_basis']) +
        '\n\nOriginal HeroVerse reflection with synthetic narration and an owned designed still. '
        'No borrowed recording, medical claim or guaranteed outcome.\n#ChristianReflection #Faith #HeroVerse')
    if len(description) > 5000:
        raise PermissionError('Current description exceeds the platform contract')
    integration_dir = root/'output/integrations/youtube/heroverse'
    optional = {}
    for name, path in (
        ('connection', integration_dir/'connection-receipt.json'),
        ('operational', integration_dir/'operational-readiness.json'),
        ('channel', root/'output/audits/channel/heroverse/channel-readiness-audit.json'),
        ('pack', root/'config/format_packs/fp-narrated-reflection-static-v1.json')):
        if path.is_file():
            raw = path.read_bytes(); inputs[path] = 'sha256:'+hashlib.sha256(raw).hexdigest()
            optional[name] = json.loads(raw.decode('utf-8-sig'))
    pack = optional['pack']
    if pack['version'] != plan['format_pack_version']:
        raise PermissionError('Current FormatPack version differs')
    connection = optional.get('connection', {}); operational = optional.get('operational', {})
    channel = optional.get('channel', {})
    connected = bool(connection.get('status') == 'CONNECTED' and connection.get('identity_verified') is True
        and all(connection.get(key, {}).get('channel_id') == EXPECTED_CHANNEL_ID
                for key in ('expected_channel', 'observed_channel'))
        and connection.get('observed_channel', {}).get('custom_url', '').lower() == '@heroverse74')
    automatic = all(row['status'] in ('PASS', 'NOT_APPLICABLE') for row in qa['gates'] if row['gate'] != 'PUBLICATION')
    automatic = automatic and all(row['status'] in ('PASS', 'NOT_APPLICABLE') for row in qa['defect_evaluations'])
    probe_video = next(row for row in measured['probe']['streams'] if row['codec_type'] == 'video')
    artifacts = packaging['inputs']
    captions = next(row for row in artifacts if row['path'].endswith('en-US.srt'))
    thumb = packaging['thumbnail']
    identity = hashlib.sha256(json.dumps([
        {'path':str(p), 'sha256':h} for p,h in sorted(inputs.items())],
        sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    result = {
        'schema_version':'1.0.0', 'package_id':'publication-package-'+identity[:20],
        'status':'BLOCKED_AUTOMATIC_QUALITY',
        'channel':{'channel_id':EXPECTED_CHANNEL_ID, 'handle':'@heroverse74', 'language':'en-US'},
        'video':{'render_id':render['render_id'], 'path':str(video),
            'sha256':measured['render_hash'].removeprefix('sha256:'), 'size_bytes':video.stat().st_size,
            'duration_ms':plan['takes'][-1]['end_ms'], 'width':int(probe_video['width']),
            'height':int(probe_video['height']), 'fps':30},
        'thumbnail':{'path':thumb['path'], 'sha256':thumb['sha256'].removeprefix('sha256:'),
            'size_bytes':thumb['size_bytes'], 'width':1280, 'height':720,
            'text':' / '.join(packaging['thumbnail_text'])},
        'metadata':{'title':title, 'description':description, 'tags':['Christian reflection','faith under pressure',
            'HeroVerse','biblical wisdom','Christian encouragement','faith in action','practical reflection','original narration'],
            'category_id':'27', 'default_language':'en', 'default_audio_language':'en',
            'made_for_kids':False, 'privacy_status':'private'},
        'disclosure':{'contains_synthetic_media':True,
            'reason':'Synthetic narration and an owned designed still, not filmed events.',
            'api_field':'status.containsSyntheticMedia'},
        'rights':{'status':'PASS_AUTOMATIC', 'manifest':str(package/'asset_manifest.json'),
            'attribution':asset['rights_evidence_uri'], 'required_attributions_in_description':True},
        'quality_gate':{'report_id':qa['report_id'], 'report':str(package/'qa/creative_quality_gate_report.json'),
            'automatic_status':'PASS' if automatic else 'FAIL', 'human_review':'NOT_REQUIRED_PER_RELEASE', 'publication_eligible':False},
        'integration':{'integration_id':'youtube-heroverse-v1',
            'connection_status':'CONNECTED' if connected else 'PENDING_AUTHORIZATION', 'identity_verified':connected,
            'receipt':str(integration_dir/'connection-receipt.json') if connection else None,
            'continuous_operation_ready':connected and operational.get('continuous_operation_ready') is True,
            'durability_status':operational.get('durability_status','UNAVAILABLE'),
            'operational_readiness':str(integration_dir/'operational-readiness.json') if operational else None},
        'channel_readiness':{'audit':str(root/'output/audits/channel/heroverse/channel-readiness-audit.json') if channel else None,
            'overall_status':channel.get('overall_status','UNAVAILABLE'),
            'critical_open_gates':channel.get('publication_gate',{}).get('critical_open_gates',[]),
            'pass':channel.get('overall_status')=='PASS'},
        'publication_policy':{'upload_permitted':False,
            'reason':['Current QA, capability transition and independent release gate must authorize these exact artifacts'],
            'next_allowed_action':'CREATIVE_REMEDIATION_AND_REQUALIFICATION'},
        'captions':{'path':captions['path'], 'sha256':captions['sha256'].removeprefix('sha256:'),
            'language':'en-US', 'cue_count':packaging['cue_count'], 'coverage_ratio':1.0,
            'human_language_review':'PENDING', 'automatic_language_review':'PENDING'},
        'format_capability':{'format_pack_id':pack['format_pack_id'], 'version':pack['version'],
            'status':pack['capability_status'], 'production_allowed':pack['production_allowed']},
        'external_cost_usd':0, 'created_at':datetime.now(timezone.utc).isoformat(),
    }
    if any(_static_sha(path) != digest for path,digest in inputs.items()):
        raise PermissionError('Publication inputs changed before assembly completed')
    Draft202012Validator(_read(root/'schemas/publication_package.schema.json')).validate(result)
    return result


def build_publication_package(root: Path = ROOT, *, package_relative: Path | None = None,
                              quality_report_binding=None, measurement_binding=None,
                              music_bindings=None, music_qualification_bindings=None) -> dict[str, Any]:
    if music_bindings is not None or music_qualification_bindings is not None:
        if (package_relative is None or music_bindings is None or music_qualification_bindings is None
                or quality_report_binding is not None or measurement_binding is not None):
            raise PermissionError('instrumental publication inputs cannot borrow narrated QA')
        from .qa_phase5 import read_rest_music_qualification
        required={'render','qualification','visual_controls','aesthetic_reference'}
        if set(music_qualification_bindings)!=required:
            raise PermissionError('instrumental final qualification binding population incomplete')
        qualified=read_rest_music_qualification(root,package_relative=package_relative,
            music_bindings=music_bindings,render_binding=music_qualification_bindings['render'],
            qualification_binding=music_qualification_bindings['qualification'],
            visual_controls_binding=music_qualification_bindings['visual_controls'],
            aesthetic_reference_binding=music_qualification_bindings['aesthetic_reference'])
        from .creative_direction import rest_delivery_format
        mode=rest_delivery_format(qualified['source']['recipe'])
        spoken=qualified['source']['voice_required']
        if qualified['status']!=mode['quality_status']:
            raise PermissionError('final instrumental delivery failed qualification')
        packaged=read_audio_static_packaging(root,package_relative=package_relative,music_bindings=music_bindings)
        metadata=packaged['metadata']
        manifest=qualified['render']['manifest'];output=manifest['output']
        current_paths={
            'pack':root/'config/format_packs'/mode['pack_file'],
            'connection':root/'output/integrations/youtube/heroverse/connection-receipt.json',
            'operational':root/'output/integrations/youtube/heroverse/operational-readiness.json',
            'channel':root/'output/audits/channel/heroverse/channel-readiness-audit.json'}
        captures={path:_static_sha(path) for path in current_paths.values()}
        pack,connection,operational,channel=(_read(current_paths[name]) for name in ('pack','connection','operational','channel'))
        if pack['format_pack_id']!=manifest['format_pack_id'] or pack['version']!=manifest['format_pack_version']:
            raise PermissionError('current instrumental FormatPack identity differs')
        connected=(connection.get('status')=='CONNECTED' and connection.get('identity_verified') is True
            and all(connection.get(name,{}).get('channel_id')==EXPECTED_CHANNEL_ID for name in ('expected_channel','observed_channel'))
            and connection.get('observed_channel',{}).get('custom_url','').lower()=='@heroverse74')
        thumb=packaged['thumbnail'];asset=_read(Path(music_bindings['asset']['path']))
        result={'schema_version':mode['package_schema'],
            'package_id':'instrumental-publication-'+hashlib.sha256(json.dumps(
                [music_bindings,music_qualification_bindings],sort_keys=True).encode()).hexdigest()[:24],
            'music_bindings':music_bindings,'music_qualification_bindings':music_qualification_bindings,
            'channel':{'channel_id':EXPECTED_CHANNEL_ID,'handle':'@heroverse74','language':'en-US'},
            'video':{'render_id':manifest['render_id'],'path':output['path'],'sha256':output['content_hash'].removeprefix('sha256:'),
                'size_bytes':output['size_bytes'],'duration_ms':output['duration_ms'],'width':1920,'height':1080,'fps':30},
            'metadata':{'title':metadata['title'],'description':metadata['description'],
                'tags':metadata['tags']+['original instrumental','gentle piano','quiet prayer music','faith reflection'],
                'category_id':'27','default_language':'en','default_audio_language':'en','made_for_kids':False,'privacy_status':'private'},
            'thumbnail':{'path':thumb['path'],'sha256':thumb['sha256'].removeprefix('sha256:'),'size_bytes':thumb['size_bytes'],
                'width':1280,'height':720,'text':'Quiet Prayer With HeroVerse'},
            'disclosure':{'contains_synthetic_media':True,'reason':'Owned procedural instrumental and designed still; no filmed events.',
                'api_field':'status.containsSyntheticMedia'},
            'rights':{'status':'PASS_AUTOMATIC','manifest':music_bindings['asset']['path'],
                'attribution':asset['rights_evidence_uri'],'required_attributions_in_description':True},
            'quality_gate':{'report_id':qualified['binding']['sha256'],'report':qualified['binding']['path'],
                'automatic_status':'PASS','human_review':'NOT_REQUIRED_PER_RELEASE','publication_eligible':False},
            'integration':{'integration_id':'youtube-heroverse-v1','connection_status':'CONNECTED' if connected else 'PENDING_AUTHORIZATION',
                'identity_verified':connected,'receipt':str(current_paths['connection']),
                'continuous_operation_ready':connected and operational.get('continuous_operation_ready') is True,
                'durability_status':operational.get('durability_status','UNAVAILABLE'),'operational_readiness':str(current_paths['operational'])},
            'channel_readiness':{'audit':str(current_paths['channel']),'overall_status':channel.get('overall_status','UNAVAILABLE'),
                'critical_open_gates':channel.get('publication_gate',{}).get('critical_open_gates',[]),'pass':channel.get('overall_status')=='PASS'},
            'format_capability':{'format_pack_id':pack['format_pack_id'],'version':pack['version'],
                'status':pack['capability_status'],'production_allowed':pack['production_allowed']},
            'captions_applicability':packaged['captions_applicability'],
            'status':'BLOCKED_AUTOMATIC_QUALITY',
            'publication_policy':{'upload_permitted':False,'reason':['Exact-media canary and current release policy still required'],
                'next_allowed_action':'CREATIVE_REMEDIATION_AND_REQUALIFICATION'},'external_cost_usd':0,
            'created_at':datetime.now(timezone.utc).isoformat()}
        if any(_static_sha(path)!=digest for path,digest in captures.items()):
            raise PermissionError('instrumental policy inputs changed during assembly')
        if spoken:
            speech=_read(Path(qualified['binding']['path']))['observed']['speech']
            captions=(root/package_relative/'qa/opening-captions.srt').resolve()
            if captions.read_text(encoding='utf-8')!=speech['captions_text']:
                raise PermissionError('current spoken captions differ from measured final audio')
            result['captions']={'path':str(captions),'sha256':_static_sha(captions).removeprefix('sha256:'),
                'language':'en-US','cue_count':(len(speech['transcript']['words'])+11)//12,
                'coverage_ratio':1.0,'human_language_review':'NOT_REQUIRED_AUTONOMOUS_QA',
                'automatic_language_review':'PASS'}
            result['metadata']['tags']=['Christian reflection','rest and responsibility','prayer music',
                'original reflection','gentle piano','quiet prayer','faith under pressure','HeroVerse']
            result['disclosure']['reason']='Original local synthetic reflection once, owned composed instrumental and designed still.'
        from jsonschema import Draft202012Validator
        Draft202012Validator(_read(root/'schemas/publication_package.schema.json')).validate(result)
        return result
    if package_relative is not None:
        return _build_audio_static_publication_package(root.resolve(), Path(package_relative),
            quality_report_binding, measurement_binding)
    if quality_report_binding is not None or measurement_binding is not None:
        raise PermissionError('Current QA bindings require an explicit package')
    pilot = root / PILOT
    render = _read(pilot / "render_manifest.json")
    qa = _read(pilot / "qa/creative_quality_gate_report.json")
    thumb = _read(pilot / "creative-v2/thumbnail/thumbnail_manifest.json")
    render_path = Path(render["output"]["path"])
    thumb_path = Path(thumb["path"])
    if _sha256(render_path) != render["output"]["content_hash"].removeprefix("sha256:"):
        raise ValueError("Render hash no longer matches the approved automatic-QA artifact")
    if _sha256(thumb_path) != thumb["content_hash"].removeprefix("sha256:"):
        raise ValueError("Thumbnail hash no longer matches its manifest")

    receipt_path = root / "output/integrations/youtube/heroverse/connection-receipt.json"
    receipt = _read(receipt_path) if receipt_path.is_file() else None
    operational_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    operational = _read(operational_path) if operational_path.is_file() else None
    channel_audit_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    channel_audit = _read(channel_audit_path) if channel_audit_path.is_file() else None
    connected = bool(
        receipt
        and receipt.get("status") == "CONNECTED"
        and receipt.get("identity_verified")
        and (receipt.get("expected_channel") or {}).get("channel_id") == EXPECTED_CHANNEL_ID
        and (receipt.get("observed_channel") or {}).get("channel_id") == EXPECTED_CHANNEL_ID
        and (receipt.get("observed_channel") or {}).get("custom_url", "").lower() == "@heroverse74"
    )
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    package_hash = hashlib.sha256(
        f"{render['render_id']}|{render['output']['content_hash']}|{thumb['content_hash']}|{TITLE}".encode()
    ).hexdigest()[:20]
    publication_reasons = [
        "independent human review is pending",
        "FormatPack is PROTOTYPED, not PRODUCTION_READY or LIMITED",
        "project publish_mode is dry-run",
        "the current video candidate failed the market and viral readiness review",
        "the current candidate is missing an approved caption delivery artifact and challenger selection",
    ]
    if not operational or not operational.get("continuous_operation_ready"):
        publication_reasons.append("OAuth continuous-operation readiness is not proven")
    if not channel_audit or channel_audit.get("overall_status") != "PASS":
        publication_reasons.append("channel readiness has critical open gates")
    return {
        "schema_version": "1.0.0",
        "package_id": f"publication-package-{package_hash}",
        "status": "BLOCKED_PENDING_HUMAN_REVIEW",
        "channel": {"channel_id": EXPECTED_CHANNEL_ID, "handle": "@heroverse74", "language": "en-US"},
        "video": {
            "render_id": render["render_id"],
            "path": str(render_path),
            "sha256": render["output"]["content_hash"].removeprefix("sha256:"),
            "size_bytes": render["output"]["size_bytes"],
            "duration_ms": render["output"]["duration_ms"],
            "width": render["output"]["width"],
            "height": render["output"]["height"],
            "fps": int(render["output"]["fps"]),
        },
        "thumbnail": {
            "path": str(thumb_path),
            "sha256": thumb["content_hash"].removeprefix("sha256:"),
            "size_bytes": thumb_path.stat().st_size,
            "width": thumb["width"], "height": thumb["height"], "text": thumb["thumbnail_text"],
        },
        "metadata": {
            "title": TITLE, "description": DESCRIPTION, "tags": TAGS, "category_id": "27",
            "default_language": "en", "default_audio_language": "en",
            "made_for_kids": False, "privacy_status": "private",
        },
        "disclosure": {
            "contains_synthetic_media": True,
            "reason": "The video contains photorealistic AI-generated illustrative scenes that did not occur.",
            "api_field": "status.containsSyntheticMedia",
        },
        "rights": {
            "status": "PASS_AUTOMATIC",
            "manifest": str(pilot / "asset_manifest.json"),
            "attribution": str(pilot / "attribution.txt"),
            "required_attributions_in_description": True,
        },
        "quality_gate": {
            "report_id": qa["report_id"],
            "report": str(pilot / "qa/creative_quality_gate_report.json"),
            "automatic_status": "PASS_WITH_HUMAN_REVIEW_PENDING",
            "human_review": qa["human_review"]["status"],
            "publication_eligible": qa["publication_eligible"],
        },
        "integration": {
            "integration_id": "youtube-heroverse-v1",
            "connection_status": "CONNECTED" if connected else ("FAILED" if receipt else "PENDING_AUTHORIZATION"),
            "identity_verified": connected,
            "receipt": str(receipt_path) if receipt else None,
            "continuous_operation_ready": bool(operational and operational.get("continuous_operation_ready")),
            "durability_status": operational.get("durability_status") if operational else "UNAVAILABLE",
            "operational_readiness": str(operational_path) if operational else None,
        },
        "channel_readiness": {
            "audit": str(channel_audit_path) if channel_audit else None,
            "overall_status": channel_audit.get("overall_status") if channel_audit else "UNAVAILABLE",
            "critical_open_gates": channel_audit.get("publication_gate", {}).get("critical_open_gates", []) if channel_audit else [],
            "pass": bool(channel_audit and channel_audit.get("overall_status") == "PASS"),
        },
        "publication_policy": {
            "upload_permitted": False,
            "reason": publication_reasons,
            "next_allowed_action": "CHANNEL_REMEDIATION_AND_NEW_VIDEO_CANDIDATE",
        },
        "external_cost_usd": 0,
        "created_at": created_at,
    }


def materialize(root: Path = ROOT, *, package_relative: Path | None = None,
                quality_report_binding=None, measurement_binding=None,
                music_bindings=None, music_qualification_bindings=None) -> Path:
    if package_relative is not None:
        from .phase6_asset_residency import _write_immutable
        package = build_publication_package(root, package_relative=package_relative,
            quality_report_binding=quality_report_binding, measurement_binding=measurement_binding,
            music_bindings=music_bindings,music_qualification_bindings=music_qualification_bindings)
        path = root.resolve()/package_relative/'publication_package.json'
        if path.exists():
            before = _read(path)
            # Observation time is not input identity. No renamed package or
            # new turn permits overwriting an existing, divergent delivery.
            if {k:v for k,v in before.items() if k!='created_at'} != {
                    k:v for k,v in package.items() if k!='created_at'}:
                raise PermissionError('Existing publication package differs; reconcile without overwrite')
            return path
        _write_immutable(path, package)
        return path
    if quality_report_binding is not None or measurement_binding is not None:
        raise PermissionError('Current QA bindings require an explicit package')
    package = build_publication_package(root)
    path = root / PILOT / "creative-v2/publication_package.json"
    path.write_text(json.dumps(package, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


if __name__ == "__main__":
    print(materialize())
