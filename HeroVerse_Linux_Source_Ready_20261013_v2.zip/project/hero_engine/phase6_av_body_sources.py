"""Closed reader for two frozen body-source batches, not an A11 consumer.

One independent replay per requested template: six three-moves PNG decodes or
five record-learning decodes (six aliases). Saved OCR is reevaluated, never
inferred again. Metadata preflight/recheck never decodes. All source intervals
are [0,1); literal fragment ranges below are not timestamps or admission.

State proofs and their counters/dependencies are template-local and therefore
byte-identical for single-state, subset or mixed-template requests. Counters
mean one full template replay, not one decode count per returned state. The
private successful-call context retains the union of dependencies and measured
operation totals: a mixed call performs two replays and eleven decodes, not six
or five and not the sum of counters repeated on twelve state proofs.
"""
from __future__ import annotations

import copy
import importlib.util
from pathlib import Path

from . import phase6_av_static_sources as primitives

VERSION = "phase6-av-body-sources-v1"
IMPLEMENTATION = "hero_engine/phase6_av_body_sources.py"
TEST = "tests/test_phase6_av_body_sources.py"
BASE = "output/qa/phase6/diagnostics/"
THREE, RECORD = "three-moves-identity-v1", "record-learning-v1"
CASE = BASE + "body-case-v1/"
STAGED = CASE + "staged/body-case-amendment-v1-ac645f2d8cb2fae3414b56c7/"
PROJECTION = {"path": STAGED + "staged-visual-v6-ba7dabb1ed63c35a19021648.json",
    "sha256": "ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4"}
DOCUMENTS = {
    "style_bible": {"path": "output/production/phase6/video-002/production/channel_style_bible.json", "sha256": "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049"},
    "take_plan": {"path": "output/production/phase6/video-002/production/take_plan.json", "sha256": "547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5"},
    "base_projection": {"path": BASE + "test-questions-v1/staged-visual-v5-7fd136fe0bc4557433b24e46.json", "sha256": "7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92"},
    "active_a11": {"path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-06198f553f7dd8184307c7b8.json", "sha256": "10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb"},
    "historical_uses_v3": {"path": "output/operations/phase6/av-admission/static-asset-uses-v3/inspection.json", "sha256": "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30"},
    "visual_projection": PROJECTION,
}
CONFIGS = {
    THREE: {"directory": BASE + THREE + "/static-7db35489d912d00a323e5566",
        "receipt_sha256": "8a09961699f428d9ddc215c6c6b2ae2acf0ab1277bdfbdc049310c2ef78ce4d2",
        "runner": BASE + THREE + "/recipe.py", "runner_sha256": "cc31bfaf4c800d052a0ec220e7a7e69dcf5691d3c55a36059e1ba5f05bafea09",
        "state_ids": [f"visual-u{uid:03d}-s00" for uid in (32, 33, 35, 47, 48, 49)],
        "lineage_id": "owned-four-criteria-panel-v1", "source_bindings": copy.deepcopy(DOCUMENTS)},
    RECORD: {"directory": BASE + RECORD + "/static-a017a2102dfa76cb8e7755f6",
        "receipt_sha256": "c61b7a2a69c557e76385c7dc95526298dc37cbde255394cdeb8dad1fc1aa50a6",
        "runner": BASE + RECORD + "/recipe.py", "runner_sha256": "deaabda55c5ae873f5088fb63144b9e811875cd34e5443fcd1152e808f6c75a6",
        "state_ids": ["visual-u036-s00", "visual-u037-s00", "visual-u037-s01", "visual-u038-s00", "visual-u038-s01", "visual-u038-s02"],
        "lineage_id": "owned-four-criteria-panel-v1", "source_bindings": {**copy.deepcopy(DOCUMENTS),
            "case_amendment": {"path": STAGED + "body-case-amendment-v1-ac645f2d8cb2fae3414b56c7.json", "sha256": "72c8c8eac653d690fd2afe5f2430d527541fd27d0cbd25e2c39da9753b2dcdcf"},
            "record_task": {"path": "docs/PHASE6_RECORD_LEARNING_TASK.md", "sha256": "16d5b03d520ba45e0c33c88f25874e058b4c39896510d6a89ab7038adcf71a16"}}},
}
REPLAYS = {
    THREE: {"runner_sha256": "23f111b6172437d844d8f734a4ab8d85fffe663c4120e036be6d04c60af2c993",
        "test_sha256": "a73bad2d939f6fb02d044dde7c4b606f7b07b099c3cd53791a4d40a2ff22d0a8",
        "report": {"path": BASE + THREE + "/qa-e891bae18c9c26639fc2c385/report.json", "sha256": "50015cb4e807fb659f2e4e10c5e2440661442afbe1182e47c9927bc408b86c4a"},
        "version": "three-moves-static-source-replay-v1", "inspection_prefix": "three-moves-static-inspection-", "unique_count": 6},
    RECORD: {"runner_sha256": "c467f742d9cfcef474cd25e0e165b08d804edecdd0052d76c0b0ec8f90f6c554",
        "test_sha256": "0c822618405b0cd113fe65e2b0791b4155baec371bdbb66136edfcb28110221f",
        "report": {"path": BASE + RECORD + "/qa-eac4809eb0499d16e0ced7a8/report.json", "sha256": "95295ea21ed5a84aec5b4fcb7fb6e475dd6a918aaf494c52520ddaf265e712a6"},
        "version": "record-learning-static-source-replay-v1", "inspection_prefix": "record-learning-static-inspection-", "unique_count": 5},
}
AUTHORITY = dict.fromkeys(("synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized",
    "quality_approved", "source_admitted", "timing_validated", "rights_approved", "publicity_approved"), False)
MODEL_PINS = {
    ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_det_small.onnx": ("090f04abcd9d9a7498bc4ebf677e4cb9bdce1fe4197ddb7e529f1ef44e1ff94f", 9929594),
    ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_rec_small.onnx": ("6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884", 21234383),
    ".venv/Lib/site-packages/rapidocr/models/ch_ppocr_mobile_v2.0_cls_mobile.onnx": ("e47acedf663230f8863ff1ab0e64dd2d82b838fceb5957146dab185a89d6215c", 585532),
}
LEXICAL = {"visual-u037-s01": (34, 44, "fear edits", "visual-u037-s00"),
    "visual-u038-s01": (39, 61, "warnings protected you", "visual-u038-s00"),
    "visual-u038-s02": (72, 98, "stories only exhausted you", "visual-u038-s01")}
LIMIT = 2 * 1024**2
_same = primitives._same


def _requests(root, requests):
    if type(requests) is not list or not 1 <= len(requests) <= 12:
        raise ValueError("one to twelve explicit body sources required")
    seen = set()
    for row in requests:
        if type(row) is not dict or set(row) != {"template_id", "state_id", "receipt_binding"}:
            raise ValueError("body request fields differ")
        tid, sid = row["template_id"], row["state_id"]
        if (type(tid) is not str or tid not in CONFIGS or type(sid) is not str
                or sid not in CONFIGS[tid]["state_ids"] or sid in seen):
            raise ValueError("unknown or duplicate body source")
        seen.add(sid)
        config, bound = CONFIGS[tid], row["receipt_binding"]
        relative = config["directory"] + "/receipt.json"
        if (type(bound) is not dict or set(bound) != {"path", "sha256"}
                or bound["path"] not in (relative, str(Path(root).absolute() / relative))
                or bound["sha256"] != config["receipt_sha256"]):
            raise ValueError("body source external receipt pin differs")
    return [tid for tid in CONFIGS if any(row["template_id"] == tid for row in requests)]


def _read_document(reader, binding):
    return primitives._json(reader.read(binding["path"], binding["sha256"], limit=LIMIT))


def _load_replay(reader, template):
    rel = BASE + template + "/"
    fixed = REPLAYS[template]
    pins = {rel + "verify_sources.py": fixed["runner_sha256"], rel + "test_verify_sources.py": fixed["test_sha256"]}
    for path, digest in pins.items():
        reader.read(path, digest, limit=LIMIT)
    spec = importlib.util.spec_from_file_location("body_source_" + template.replace("-", "_"), reader.root / (rel + "verify_sources.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.ROOT != reader.root or Path(module.__file__).absolute() != reader.root / (rel + "verify_sources.py"):
        raise ValueError("body replay loaded from another root")
    # Helper pins come from these externally pinned implementation bytes, never
    # a candidate report or a self-declared dependency list.
    pins.update(module.FIXED_CODE_PINS)
    _same(sorted(pins), sorted(module.CODE_PATHS), "body replay implementation population differs")
    for path, digest in pins.items():
        reader.read(path, digest, limit=LIMIT)
    config = CONFIGS[template]
    arguments = {"code_pins": pins, "report_binding": copy.deepcopy(fixed["report"]),
        "source_receipt": {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]},
        "projection_binding": copy.deepcopy(PROJECTION)}
    return module, arguments


def _contract(template, row, state, original, takes):
    sid, uid = state["state_id"], row["unit_id"]
    if sid not in CONFIGS[template]["state_ids"]:
        raise ValueError("body state outside closed population")
    _same(state, original["source_state"], "body state differs from frozen source design")
    _same([original["state_id"], original["unit_id"], original["copy"]],
        [sid, uid, state["visual_content"]["literal_copy"]], "body identity or copy differs")
    fragments = [original["take_id"]] if template == THREE else original["take_ids"]
    _same(fragments, row["fragment_ids"], "body source fragment population differs")
    texts = [takes[tid]["narration"] for tid in fragments]
    _same(" ".join(texts), row["text"], "body literal narration does not recompose from TakePlan")
    _same(row["text_sha256"], "sha256:" + primitives._sha(row["text"].encode("utf-8")), "body narration identity differs")
    values = LEXICAL.get(sid)
    entry = ({"kind": "LEXICAL_START", "char_start": values[0], "char_end": values[1], "text": values[2], "previous_state_id": values[3]}
        if values else {"kind": "UNIT_ENTRY", "char_start": None, "char_end": None, "text": None, "previous_state_id": None})
    _same([state["entry"], original["entry"]], [entry, entry], "body literal entry differs or invents timing")
    target = None
    if values:
        start, end, literal, _ = values
        if row["text"][start:end] != literal:
            raise ValueError("body lexical range differs from narration")
        spans, offset = [], 0
        for tid, text in zip(fragments, texts, strict=True):
            left, right = max(start, offset), min(end, offset + len(text))
            if left < right:
                spans.append({"fragment_id": tid, "unit_char_start": left, "unit_char_end": right,
                    "fragment_char_start": left - offset, "fragment_char_end": right - offset,
                    "text": text[left - offset:right - offset]})
            offset += len(text) + 1
        if " ".join(span["text"] for span in spans) != literal:
            raise ValueError("body lexical support does not cover the exact phrase")
        target = {"unit_id": uid, "fragment_ids": [span["fragment_id"] for span in spans],
            "fragment_spans": spans, "text": literal, "char_start": start, "char_end": end}
    return {"state_id": sid, "unit_id": uid, "fragment_ids": copy.deepcopy(fragments),
        "unit_fragment_ids": copy.deepcopy(row["fragment_ids"]), "literal_narration": row["text"],
        "literal_copy": copy.deepcopy(original["copy"]), "text_blocks": copy.deepcopy(original["copy"]),
        "entry": entry, "timing_kind": "CALIBRATED_LEXICAL_REQUIRED" if values else "UNIT_ENTRY_NOT_BOUND",
        "lexical_target": target, "continuation_of_state_id": None, "visual_content": copy.deepcopy(state["visual_content"])}


class _Context:
    """Not serializable evidence; only this call's readers and pinned modules."""
    def __init__(self, reader, requests, templates):
        self.reader, self.requests, self.templates = reader, copy.deepcopy(requests), templates
        self.replays, self.contracts = {}, {}
        self.operation_dependencies = []
        self.operation_counts = {"template_replay_calls": 0, "image_decode_calls": 0,
            "ocr_inference_calls": 0, "render_calls": 0, "technical_cost_brl": 0}
        self.operation_template_executions = []
        self.operation_complete = False


def preflight_body_sources(root, requests):
    templates = _requests(root, requests)
    reader = primitives._Reader(root)
    if Path(__file__).absolute() != reader.root / IMPLEMENTATION:
        raise ValueError("body inspector loaded from another root")
    reader.read("hero_engine/phase6_av_static_sources.py", "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb", limit=LIMIT)
    for relative in (IMPLEMENTATION, TEST):
        path = reader.path(relative)
        if not 0 < path.stat().st_size <= LIMIT:
            raise ValueError("bounded body implementation required")
        reader.read(relative, primitives._sha(path.read_bytes()), limit=LIMIT)
    documents = {}
    for template in templates:
        for role, binding in CONFIGS[template]["source_bindings"].items():
            documents[role] = _read_document(reader, binding) if binding["path"].endswith(".json") else reader.read(binding["path"], binding["sha256"], limit=LIMIT)
    projection, bible, plan = (documents[key] for key in ("visual_projection", "style_bible", "take_plan"))
    _same([projection["status"], projection["source_ready"], projection["global_schedule_created"], projection["calibrated_timing_available"]],
        ["STAGED_NOT_ACCEPTED_BY_A11", False, False, False], "body V6 is not a staged untimed reference")
    _same([bible["channel_id"], bible["palette"]["locked_hex"], plan["channel_id"], plan["style_bible_id"]],
        [primitives.CHANNEL, primitives.PALETTE, primitives.CHANNEL, bible["style_bible_id"]], "body ChannelDNA differs")
    states = {state["state_id"]: (row, state) for row in projection["effective_rows"] for state in row["states"]}
    takes = {take["take_id"]: take for take in plan["takes"]}
    context = _Context(reader, requests, templates)
    context.bible = bible
    for template in templates:
        config = CONFIGS[template]
        receipt = _read_document(reader, {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]})
        originals = receipt["contract"]["design"]["states"]
        _same([item["state_id"] for item in originals], config["state_ids"], "body receipt state population differs")
        context.contracts[template] = {item["state_id"]: _contract(template, *states[item["state_id"]], item, takes) for item in originals}
        module, arguments = _load_replay(reader, template)
        replay_context = module.prepare(**copy.deepcopy(arguments))
        context.replays[template] = {"module": module, "arguments": arguments, "context": replay_context, "receipt": receipt}
    recheck_body_context(context)
    return context


def recheck_body_context(context):
    if type(context) is not _Context:
        raise ValueError("private same-call body context required")
    for item in tuple(context.reader.bindings.values()):
        context.reader.read_path(Path(item["path"]), item["sha256"], limit=LIMIT)
    for replay in context.replays.values():
        replay["module"].recheck(replay["context"])


def _merge(dependencies, items):
    if type(items) is not list or not items:
        raise ValueError("nonempty same-call body dependency sink required")
    seen = set()
    for item in items:
        if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                or type(item["path"]) is not str or item["path"] in seen
                or type(item["size_bytes"]) is not int or item["size_bytes"] <= 0):
            raise ValueError("invalid or duplicate body dependency")
        seen.add(item["path"])
        _same(dependencies.setdefault(item["path"], item), item, "conflicting body dependency")


def _read_dependency(reader, item):
    path = Path(item["path"])
    if not path.is_absolute() or str(path) != item["path"] or ".." in path.parts:
        raise ValueError("canonical absolute body dependency required")
    if item["path"] in primitives.EXTERNAL_DEPENDENCY_PINS:
        _same(item["sha256"], primitives.EXTERNAL_DEPENDENCY_PINS[item["path"]], "body font/decoder pin differs")
    elif not path.is_relative_to(reader.root):
        raise ValueError("body dependency escapes root")
    model = MODEL_PINS.get(path.relative_to(reader.root).as_posix()) if path.is_relative_to(reader.root) else None
    if model:
        _same([item["sha256"], item["size_bytes"]], list(model), "body model pin or size differs")
    raw = reader.read_path(path, item["sha256"], limit=32 * 1024**2 if model else 16 * 1024**2)
    if len(raw) != item["size_bytes"]:
        raise ValueError("body dependency byte length changed")


def _inventory(reader, directory, names):
    path = reader.path(directory)
    if {child.name for child in path.iterdir()} != set(names):
        raise ValueError("body source, QA or runtime inventory drift")


def _required_evidence(reader, template, dependencies):
    """Derive required names/pins from fixed envelopes, not their dependency lists."""
    config, replay = CONFIGS[template], REPLAYS[template]
    receipt_binding = {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]}
    receipt, report = _read_document(reader, receipt_binding), _read_document(reader, replay["report"])
    pins = {receipt_binding["path"]: receipt_binding["sha256"], replay["report"]["path"]: replay["report"]["sha256"],
        **{bound["path"]: bound["sha256"] for bound in config["source_bindings"].values()},
        **receipt["contract"]["source_pins"], **report["code_pins"], **report["ocr_code_pins"],
        BASE + template + "/verify_sources.py": replay["runner_sha256"], BASE + template + "/test_verify_sources.py": replay["test_sha256"],
        CASE + "case_proposal.py": "eeab6c1135ba9a259ff7f2fd3b0cf05ee07d0b2663c0724ff03ff748dbaa66b8",
        CASE + "test_case_proposal.py": "88423910a7409b8834f0239091010d56938e08dd68fdb3902f71e1e4f13b89ca"}
    names = {sid + suffix for sid in config["state_ids"] for suffix in (".png", ".svg")} | {"layouts.json"}
    _same(sorted(receipt["artifact_sha256"]), sorted(names), "body source artifact inventory differs")
    _inventory(reader, config["directory"], names | {"started.json", "receipt.json"})
    pins.update({config["directory"] + "/" + name: digest for name, digest in receipt["artifact_sha256"].items()})
    pins[receipt["started_binding"]["path"]] = receipt["started_binding"]["sha256"]
    qa_directory = str(Path(replay["report"]["path"]).parent).replace("\\", "/")
    primary = config["state_ids"] if template == THREE else [sid for sid in config["state_ids"] if sid != "visual-u037-s00"]
    _same([item["path"] for item in report["ocr_scans"]], [qa_directory + "/ocr-" + sid + ".json" for sid in primary], "body raw OCR population differs")
    _inventory(reader, qa_directory, {"started.json", "report.json"} | {"ocr-" + sid + ".json" for sid in primary})
    for bound in (report["started_binding"], *report["ocr_scans"]):
        pins[bound["path"]] = bound["sha256"]
    runtime = receipt["contract"]["runtime"]
    runtime_dir = reader.path(".venv/Lib/site-packages/PIL")
    if len(runtime) != 105 or {child.name for child in runtime_dir.iterdir() if child.suffix in (".py", ".pyd")} != set(runtime):
        raise ValueError("body Pillow inventory drift")
    pins.update({".venv/Lib/site-packages/PIL/" + name: digest for name, digest in runtime.items()})
    pins.update({path: data[0] for path, data in MODEL_PINS.items()})
    for relative, digest in pins.items():
        if Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise ValueError("body pinned evidence path escapes root")
        if dependencies.get(str(reader.root / relative), {}).get("sha256") != digest:
            raise ValueError("body mandatory evidence omitted or repinned: " + relative)
    required = {str(reader.root / relative) for relative in (IMPLEMENTATION, TEST)} | set(primitives.EXTERNAL_DEPENDENCY_PINS)
    if not required.issubset(dependencies):
        raise ValueError("body implementation/font/decoder dependency missing")


def recheck_body_dependencies(root, proofs):
    """Only recheck a caller's own same-call sink; this does not verify proofs."""
    if type(proofs) is not list or not proofs:
        raise ValueError("body same-call proof sink required")
    reader, dependencies, templates = primitives._Reader(root), {}, set()
    for proof in proofs:
        if type(proof) is not dict or proof.get("template_id") not in CONFIGS:
            raise ValueError("body proof template missing or unknown")
        templates.add(proof["template_id"])
        _merge(dependencies, proof.get("dependency_bindings"))
    for item in dependencies.values():
        _read_dependency(reader, item)
    for template in sorted(templates):
        _required_evidence(reader, template, dependencies)
    return len(dependencies)


def _validate_batch(context, template, batch, sink):
    replay, config, fixed = context.replays[template], CONFIGS[template], REPLAYS[template]
    module, arguments = replay["module"], replay["arguments"]
    _same([batch["version"], batch["status"], batch["source_receipt"], batch["qa_report_binding"], batch["projection_binding"],
        batch["implementation_pins"], batch["state_ids"], batch["source_count"], batch["source_frame_interval"],
        batch["source_video_fps"], batch["source_video_duration"], batch["source_ready"], batch["authority"],
        batch["png_decodes_this_call"], batch["ocr_inferences_this_call"], batch["source_renders_this_call"], batch["technical_cost_brl"]],
        [fixed["version"], "PASS_STATIC_SOURCE_REPLAY_ONLY", arguments["source_receipt"], fixed["report"], PROJECTION,
         arguments["code_pins"], config["state_ids"], 6, [0, 1], None, None, False, module.AUTHORITY,
         fixed["unique_count"], 0, 0, 0], "body replay envelope or counters differ")
    _same(batch["dependency_bindings"], sink, "body replay dependencies differ from private same-call sink")
    _same([batch["source_technically_verified"], batch["global_schedule_created"], batch["calibrated_timing_available"],
        batch["lineage_id"], batch["new_independent_lineage_claimed"]],
        [True, False, False, config["lineage_id"], False], "body replay grants unsupported readiness or lineage")
    _same([item["state_id"] for item in batch["sources"]], config["state_ids"], "body replay result population differs")
    for proof in batch["sources"]:
        payload = {key: value for key, value in proof.items() if key != "inspection_id"}
        _same(proof["inspection_id"], fixed["inspection_prefix"] + primitives._sha(primitives._canonical(payload))[:24], "body replay per-state identity differs")
        sid = proof["state_id"]
        contract = context.contracts[template][sid]
        _same([proof["version"], proof["status"], proof["template_id"], proof["channel_id"], proof["lineage_id"],
            proof["source_frame_count"], proof["source_start_frame"], proof["source_end_frame"], proof["media_kind"],
            proof["source_technically_verified"], proof["source_ready"], proof["authority"], proof["technical_cost_brl"],
            proof["source_video_fps"], proof["source_video_duration"], proof["source_receipt"], proof["qa_report_binding"], proof["projection_binding"],
            proof["entry"], proof["literal_copy"], proof["unit_id"], proof["dependency_bindings"]],
            [fixed["version"], "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", template, primitives.CHANNEL, config["lineage_id"],
             1, 0, 1, "STATIC_IMAGE", True, False, module.AUTHORITY, 0, None, None, arguments["source_receipt"], fixed["report"], PROJECTION,
             contract["entry"], contract["literal_copy"], contract["unit_id"], sink],
            "body replay source differs from literal contract")
        path = str(context.reader.root / config["directory"] / (sid + ".png"))
        asset = next((item for item in sink if item["path"] == path), None)
        if asset is None:
            raise ValueError("body replay source missing from actual dependency sink")
        _same(proof["asset_binding"], asset, "body replay asset not actually read")
        _same(asset["sha256"], replay["receipt"]["artifact_sha256"][sid + ".png"], "body replay PNG differs from fixed receipt")
        fragments = [proof["take_id"]] if template == THREE else proof["take_ids"]
        _same(fragments, contract["fragment_ids"], "body replay fragments differ")
        if template == RECORD:
            _same(proof["composition_id"], contract["visual_content"]["composition_id"], "body replay composition differs")


def inspect_body_sources(root, requests, *, _context_sink=None, _execution_sink=None):
    """Return stable template-local proofs; optionally retain one private context.

    The private sink is populated only after all replays and final rechecks pass.
    It is not candidate evidence or a serialized cache and grants no authority.
    """
    if _context_sink is not None and type(_context_sink) is not list:
        raise ValueError("private same-call body context sink must be a list")
    if _execution_sink is not None and (type(_execution_sink) is not list or _execution_sink):
        raise ValueError("private body execution sink must be a fresh empty list")
    if _execution_sink is not None and _execution_sink is _context_sink:
        raise ValueError("body context and execution sinks must be distinct")
    context = preflight_body_sources(root, requests)
    dependencies = dict(context.reader.bindings)
    results = {}
    for template in context.templates:
        replay, sink, new_contexts = context.replays[template], [], []
        kwargs = {**copy.deepcopy(replay["arguments"]), "_dependency_sink": sink}
        if template == RECORD:
            kwargs["_context_sink"] = new_contexts
        batch = replay["module"].verify(**kwargs)
        _validate_batch(context, template, batch, sink)
        _merge(dependencies, sink)
        # Each verifier's actual sink already contains its own complete frozen
        # source/QA/implementation chain. Add only the common facade guards,
        # never metadata introduced by another template in this mixed call.
        local_dependencies = {str(context.reader.root / relative): copy.deepcopy(
            context.reader.bindings[str(context.reader.root / relative)]) for relative in (IMPLEMENTATION, TEST)}
        _merge(local_dependencies, sink)
        local_bindings = sorted(local_dependencies.values(), key=lambda item: item["path"])
        context.operation_counts["template_replay_calls"] += 1
        for target, field in (("image_decode_calls", "png_decodes_this_call"),
                ("ocr_inference_calls", "ocr_inferences_this_call"), ("render_calls", "source_renders_this_call"),
                ("technical_cost_brl", "technical_cost_brl")):
            context.operation_counts[target] += batch[field]
        context.operation_template_executions.append({"template_id": template, "replay_version": batch["version"],
            "implementation_pins": copy.deepcopy(batch["implementation_pins"]),
            "source_receipt": copy.deepcopy(batch["source_receipt"]), "qa_report_binding": copy.deepcopy(batch["qa_report_binding"]),
            "state_count": batch["source_count"], "image_decode_calls": batch["png_decodes_this_call"],
            "ocr_inference_calls": batch["ocr_inferences_this_call"], "render_calls": batch["source_renders_this_call"],
            "technical_cost_brl": batch["technical_cost_brl"]})
        if template == RECORD:
            if len(new_contexts) != 1:
                raise ValueError("one private successful record replay context required")
            replay["context"] = new_contexts[0]
        recheck_body_context(context)
        config = CONFIGS[template]
        hashes = {proof["state_id"]: proof["asset_binding"]["sha256"] for proof in batch["sources"]}
        if len(set(hashes.values())) != REPLAYS[template]["unique_count"]:
            raise ValueError("body unique content population differs")
        expected_alias = ["visual-u036-s00", "visual-u037-s00"]
        for old in batch["sources"]:
            sid, digest = old["state_id"], hashes[old["state_id"]]
            aliases = [key for key, value in hashes.items() if value == digest]
            _same(aliases, expected_alias if template == RECORD and sid in expected_alias else [sid], "body content aliases differ")
            proof = {"version": VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", "template_id": template,
                **context.contracts[template][sid], "media_kind": "STATIC_IMAGE", "width": 1920, "height": 1080,
                "mode": "RGB", "opacity": "OPAQUE", "asset_binding": copy.deepcopy(old["asset_binding"]), "content_sha256": digest,
                "equivalent_state_ids": aliases, "canonical_content_state_id": aliases[0],
                "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
                "source_video_fps": None, "source_video_duration": None, "observed_sample": None, "video_frame": None,
                "lineage_id": config["lineage_id"], "channel_id": primitives.CHANNEL, "style_bible_id": context.bible["style_bible_id"],
                "source_technically_verified": True, "source_ready": False, "global_schedule_created": False,
                "calibrated_timing_available": False, "technical_cost_brl": 0, "authority": dict(AUTHORITY),
                "state_count": 6, "unique_content_count": REPLAYS[template]["unique_count"], "lineage_count": 1,
                "receipt_binding": {"path": str(context.reader.root / config["directory"] / "receipt.json"), "sha256": config["receipt_sha256"]},
                "source_bindings": copy.deepcopy(config["source_bindings"]), "qa_report_binding": copy.deepcopy(REPLAYS[template]["report"]),
                "literal_reference_scope": "STAGED_CASE_V6_METADATA_NOT_ACTIVE_A11_OR_TIMING",
                "historical_qa_scope": "NEW_STATIC_PIXEL_INK_REPLAY_SAVED_OCR_NO_NEW_INFERENCE",
                "image_decode_calls": batch["png_decodes_this_call"], "template_image_decode_calls": batch["png_decodes_this_call"],
                "counter_scope": "ONE_FULL_TEMPLATE_REPLAY_NOT_PER_STATE_OR_MIXED_OPERATION",
                "proof_identity_scope": "TEMPLATE_LOCAL_INDEPENDENT_OF_REQUEST_BATCH",
                "ocr_inference_calls": 0, "render_calls": 0,
                "dependency_bindings": copy.deepcopy(local_bindings),
                "replay_inspection": {"version": old["version"], "inspection_id": old["inspection_id"], "sha256": primitives._sha(primitives._canonical(old))},
                "claim_boundary": "Twelve fixed still states only; no active-plan installation, timing, rights/publicity, audio, motion, final-video QA or new independent lineage."}
            results[sid] = proof
    # Do not publish a partial result if the second batch or the final sink drifts.
    context.operation_dependencies = copy.deepcopy(sorted(dependencies.values(), key=lambda item: item["path"]))
    for proof in results.values():
        proof["inspection_id"] = "body-source-" + primitives._sha(primitives._canonical(proof))[:24]
    selected = [results[row["state_id"]] for row in requests]
    recheck_body_dependencies(root, list(results.values()))
    recheck_body_context(context)
    answer = primitives._json(primitives._canonical(selected))
    execution = {"version": "phase6-av-body-source-execution-v1", "status": "STATIC_SOURCE_BATCH_VERIFIED_NOT_ADMITTED",
        "templates": [item["template_id"] for item in context.operation_template_executions],
        "replay_count": context.operation_counts["template_replay_calls"],
        **{key: context.operation_counts[key] for key in ("image_decode_calls", "ocr_inference_calls", "render_calls", "technical_cost_brl")},
        "template_executions": copy.deepcopy(context.operation_template_executions),
        "requested_state_ids": [item["state_id"] for item in requests], "authority": dict(AUTHORITY)}
    context.operation_complete = True
    if _context_sink is not None:
        _context_sink.append(context)
    if _execution_sink is not None:
        _execution_sink.append(execution)
    return answer


def inspect_body_source(root, *, template_id, state_id, receipt_binding):
    return inspect_body_sources(root, [{"template_id": template_id, "state_id": state_id, "receipt_binding": receipt_binding}])[0]


def verify_body_source(candidate, root, **arguments):
    expected = inspect_body_source(root, **arguments)
    _same(candidate, expected, "body source proof replay differs")
    return expected
