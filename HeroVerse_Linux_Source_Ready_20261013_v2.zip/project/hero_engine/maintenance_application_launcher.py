"""Durable T22-style process witness for the existing paused application CLI.

The child owns all maintenance guards and mutations. This parent records its
actual exit once; it never retries, restarts the manager, or invents old exits.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path


def _save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def _sha256(path):
    """Return the project spelling used by the evidence schemas."""
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _write_paused_application_reference(
    root, *, record, proof_envelope, expected_proof_hash, expected_candidate_hash, result
):
    """Bind a successful child to the exact committed application it produced.

    This is deliberately post-exit work: the child remains the sole writer of
    application state.  The witness never converts a process exit into an
    application success; it reopens the anchored proof, routes the deterministic
    application run, and requires the child's stdout to be byte-identical to its
    committed receipt before publishing the D-116 reference.
    """
    if result.get("exit_code") != 0:
        return None
    from . import maintenance_paused_application as paused
    from . import maintenance_protocol as protocol

    record = Path(record).resolve(strict=True)
    envelope = Path(proof_envelope).resolve(strict=True)
    run, binding = paused._anchored_application_run(
        root, envelope.relative_to(root).as_posix(), expected_proof_hash, expected_candidate_hash
    )
    committed = run / "committed.json"
    stdout = record / "application.stdout.log"
    stderr = record / "application.stderr.log"
    process = record / "process-result.json"
    if not (committed.is_file() and stdout.is_file() and stderr.is_file() and process.is_file()):
        raise RuntimeError("successful application lacks one or more witness files")
    # Do not parse/re-serialize either side: the exact emitted receipt is the
    # only proof that the process result belongs to this commit.
    if stdout.read_bytes() != committed.read_bytes():
        raise RuntimeError("application stdout is not byte-identical to committed receipt")
    if stderr.read_bytes() != b"":
        raise RuntimeError("successful application emitted stderr")
    receipt = json.loads(committed.read_text(encoding="utf-8"))
    if not (
        receipt.get("status") == "APPLIED_WHILE_PAUSED"
        and receipt.get("binding") == binding
    ):
        raise RuntimeError("committed application receipt does not match the anchored binding")
    reference = {
        "schema_version": "1.0.0",
        "commit_path": committed.relative_to(root).as_posix(),
        "commit_sha256": _sha256(committed),
        "proof_path": envelope.relative_to(root).as_posix(),
        "proof_sha256": expected_proof_hash,
        "candidate_sha256": expected_candidate_hash,
        "process_path": process.relative_to(root).as_posix(),
        "process_sha256": _sha256(process),
        "stdout_sha256": _sha256(stdout),
        "stderr_sha256": _sha256(stderr),
    }
    protocol.validate(root, "phase6_paused_application_reference.schema.json", reference)
    target = record / "paused-application-reference.json"
    _save(target, reference)
    return target


def _record_once(root, directory, command):
    directory.mkdir(parents=False, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    _save(directory / 'dispatch.json', {'command': command, 'started_at': started, 'automatic_retry': False})
    with (directory / 'application.stdout.log').open('xb') as stdout, (directory / 'application.stderr.log').open('xb') as stderr:
        try:
            child = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr,
                                     env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        except OSError as exc:
            _save(directory / 'launch-failure.json', {'error_type': type(exc).__name__,
                  'message': str(exc), 'child_started': False})
            raise
        _save(directory / 'process-start.json', {'pid': child.pid, 'started_at': started, 'command': command})
        child.wait()
    result = dict(command=command, pid=child.pid, started_at=started,
                  finished_at=datetime.now(timezone.utc).isoformat(), wall_seconds=time.monotonic()-clock,
                  exit_code=child.returncode, automatic_retry=False, supervisor_restart_authorized=False)
    _save(directory / 'process-result.json', result)
    return result


def launch(root, *, record, proof_envelope, expected_proof_hash, expected_candidate_hash):
    root = Path(root).resolve(strict=True)
    runs = root / 'output/runtime/gestor-central/maintenance-runs'
    if not re.fullmatch(r'sha256:[0-9a-f]{64}', expected_proof_hash or '') or not re.fullmatch(r'[0-9a-f]{64}', expected_candidate_hash or ''):
        raise ValueError('explicit external anchors required')
    record = Path(record)
    envelope = Path(proof_envelope)
    record = (root / record).resolve()
    envelope = (root / envelope).resolve(strict=True)
    if record.parent != runs or envelope.parent.parent != runs or record == envelope.parent:
        raise ValueError('separate direct maintenance-runs directories required')
    if record.exists():
        raise FileExistsError('prior dispatch exists: reconcile; never resend')
    if not (root / 'output/runtime/gestor-central/PAUSE').is_file():
        raise PermissionError('owner pause required')
    command = [str(root / '.venv/Scripts/python.exe'), '-B', '-m', 'hero_engine.maintenance_protocol',
               '--root', str(root), 'apply-paused', '--proof-envelope', envelope.relative_to(root).as_posix(),
               '--expected-proof-hash', expected_proof_hash, '--expected-candidate-hash', expected_candidate_hash]
    result = _record_once(root, record, command)
    _write_paused_application_reference(
        root,
        record=record,
        proof_envelope=envelope,
        expected_proof_hash=expected_proof_hash,
        expected_candidate_hash=expected_candidate_hash,
        result=result,
    )
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--record', type=Path, required=True)
    parser.add_argument('--proof-envelope', type=Path, required=True)
    parser.add_argument('--expected-proof-hash', required=True)
    parser.add_argument('--expected-candidate-hash', required=True)
    args = parser.parse_args(argv)
    result = launch(**vars(args))
    print(json.dumps(result), flush=True)
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
