from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .db import ROOT, utc_now


SHOT_BANK: dict[str, list[dict[str, str]]] = {
    "declaration_and_proof": [
        {"concept": "A lone figure faces a moving storm before taking one step forward", "query": "silhouette person storm ridge cinematic", "composition": "wide silhouette, negative space on left", "audio_cue": "cold impact on the word battle"},
    ],
    "personal_stakes": [
        {"concept": "Unfinished work on a desk while the subject hesitates", "query": "person unfinished work desk moody", "composition": "overhead insert", "audio_cue": "low pulse begins"},
        {"concept": "Hand reaches for a closed door and stops", "query": "hand reaching closed door cinematic", "composition": "tight detail", "audio_cue": "subtle latch texture"},
        {"concept": "A mirror reflection falls partially into shadow", "query": "person mirror shadow identity cinematic", "composition": "symmetrical medium close-up", "audio_cue": "no accent"},
        {"concept": "An empty church aisle suggests isolation rather than spectacle", "query": "empty church aisle cinematic light", "composition": "centered leading lines", "audio_cue": "room tone opens"},
        {"concept": "A figure watches other people move while remaining still", "query": "person still crowd motion blur", "composition": "locked medium shot", "audio_cue": "pulse doubles softly"},
        {"concept": "Hands release a handle instead of forcing it", "query": "hands release door handle close up", "composition": "macro insert", "audio_cue": "pressure sound drops"},
        {"concept": "A child walks beside a parent, visualizing belonging", "query": "parent child walking backlit silhouette", "composition": "rear wide shot", "audio_cue": "warm pad enters"},
    ],
    "mechanism": [
        {"concept": "A false sentence is written in a notebook", "query": "handwriting doubt notebook close up", "composition": "top-down macro", "audio_cue": "pencil scratch"},
        {"concept": "The sentence repeats across layered paper", "query": "layered handwritten notes cinematic", "composition": "graphic match cut", "audio_cue": "single echo"},
        {"concept": "A decision remains unchecked on a list", "query": "unchecked task list hand hesitation", "composition": "tight insert", "audio_cue": "clock pulse"},
        {"concept": "The subject turns away from meaningful work", "query": "person leaves unfinished work dark room", "composition": "medium rear shot", "audio_cue": "low boom"},
        {"concept": "Applause is seen without hearing it clearly", "query": "crowd applause slow motion dark", "composition": "compressed telephoto", "audio_cue": "muffled crowd"},
        {"concept": "A locked door is pushed with increasing strain", "query": "person pushing locked door cinematic", "composition": "side profile", "audio_cue": "rising friction"},
        {"concept": "Fast calendar pages imply activity without progress", "query": "calendar pages time lapse", "composition": "macro time lapse", "audio_cue": "rhythmic ticks"},
        {"concept": "Busy feet cross in opposing directions", "query": "crowd feet crosswalk motion blur", "composition": "low angle", "audio_cue": "tempo lift"},
        {"concept": "The main subject remains centered but motion blurs around them", "query": "still person busy crowd time lapse", "composition": "centered wide", "audio_cue": "music briefly thins"},
        {"concept": "A clenched hand opens as urgency releases", "query": "clenched hand opens close up", "composition": "extreme close-up", "audio_cue": "release breath"},
    ],
    "scripture_or_authority": [
        {"concept": "An open Bible is lit by a narrow moving beam", "query": "open Bible dramatic light cinematic", "composition": "45-degree close-up", "audio_cue": "music shifts to grounded chord"},
        {"concept": "Wind moves across an empty wilderness", "query": "desert wilderness wind cinematic", "composition": "ultra-wide", "audio_cue": "wind layer"},
        {"concept": "Bread and stones share one frame without literal reenactment", "query": "bread stones rustic table dramatic", "composition": "symbolic still life", "audio_cue": "low hit"},
        {"concept": "A high ledge is shown from a safe abstract angle", "query": "rooftop edge city dawn cinematic", "composition": "wide downward perspective", "audio_cue": "high tension tone"},
        {"concept": "A hand closes rather than grabs a symbolic crown", "query": "hand refuses crown silhouette", "composition": "profile close-up", "audio_cue": "tension stops"},
        {"concept": "A cross silhouette appears beyond the foreground", "query": "cross silhouette sunrise cinematic", "composition": "long lens with foreground", "audio_cue": "choir texture enters"},
        {"concept": "A finger follows a line of scripture", "query": "finger reading Bible verse close up", "composition": "macro tracking", "audio_cue": "page texture"},
        {"concept": "The subject steps away from a bright shortcut", "query": "person choosing narrow path sunrise", "composition": "rear wide shot", "audio_cue": "cadence resolves"},
        {"concept": "A quiet kneeling silhouette replaces the temptation imagery", "query": "kneeling prayer silhouette window", "composition": "static side profile", "audio_cue": "one beat of near-silence"},
    ],
    "reversal": [
        {"concept": "The subject steps backward from the forced door", "query": "person steps back from closed door", "composition": "matched medium shot", "audio_cue": "reversal impact"},
        {"concept": "A slow breath settles visible tension", "query": "person deep breath window light", "composition": "close-up profile", "audio_cue": "audible breath"},
        {"concept": "A true sentence is written beside the false one", "query": "writing truth beside crossed out words", "composition": "top-down insert", "audio_cue": "pencil scratch"},
        {"concept": "A small next step begins on an empty path", "query": "single step walking path close up", "composition": "low tracking shot", "audio_cue": "soft footstep"},
        {"concept": "A phone is set down instead of seeking approval", "query": "phone set down table intentional", "composition": "tight insert", "audio_cue": "notification cuts off"},
        {"concept": "The wrong door closes calmly", "query": "door closes softly warm light", "composition": "static wide", "audio_cue": "gentle latch"},
        {"concept": "Open space replaces compressed framing", "query": "person open field dawn freedom", "composition": "expanding wide shot", "audio_cue": "stereo field widens"},
        {"concept": "The subject stands still with quiet confidence", "query": "confident person still sunrise silhouette", "composition": "low-angle medium wide", "audio_cue": "theme returns"},
    ],
    "crescendo_and_action": [
        {"concept": "One false label is written on paper", "query": "hand writes false label paper close up", "composition": "macro insert", "audio_cue": "downbeat one"},
        {"concept": "The label is crossed out once, decisively", "query": "crossing out word notebook", "composition": "match cut", "audio_cue": "marker stroke"},
        {"concept": "A truthful sentence is written beneath it", "query": "writing affirmation journal cinematic", "composition": "top-down", "audio_cue": "music rises"},
        {"concept": "A meaningful phone call is placed", "query": "person makes phone call window light", "composition": "medium profile", "audio_cue": "subtle dial tone"},
        {"concept": "Unfinished work is completed", "query": "hands finish creative work desk", "composition": "over-shoulder", "audio_cue": "rhythmic accent"},
        {"concept": "The subject waits beside a closed door without forcing it", "query": "person waiting closed door peaceful", "composition": "centered wide", "audio_cue": "music holds"},
        {"concept": "Feet move forward from stillness", "query": "walking forward path sunrise feet", "composition": "low tracking", "audio_cue": "final rise"},
    ],
    "identity_resolution": [
        {"concept": "Return to the original storm ridge from the same angle", "query": "silhouette storm ridge cinematic", "composition": "opening callback wide", "audio_cue": "opening motif returns"},
        {"concept": "The figure walks through the weather instead of waiting for it to end", "query": "person walking through storm cinematic", "composition": "rear tracking wide", "audio_cue": "full theme"},
        {"concept": "Clouds open into a restrained sunrise", "query": "storm clouds opening sunrise cinematic", "composition": "very wide closing frame", "audio_cue": "clean resolved chord"},
    ],
}


def build_shotlist(edl_path: Path) -> dict[str, Any]:
    edl = json.loads(edl_path.read_text(encoding="utf-8"))
    cursor = 0.0
    shots: list[dict[str, Any]] = []
    for segment_index, segment in enumerate(edl["segments"]):
        if segment["type"] == "source_clip":
            duration = float(segment["end_seconds"]) - float(segment["start_seconds"])
            shots.append(
                {
                    "shot": len(shots) + 1,
                    "start_seconds": round(cursor, 3),
                    "end_seconds": round(cursor + duration, 3),
                    "duration_seconds": round(duration, 3),
                    "segment_index": segment_index,
                    "narrative_role": segment.get("narrative_job", "licensed_authority_excerpt"),
                    "asset_type": "licensed_source_excerpt",
                    "concept": segment.get("screen_text"),
                    "search_query": None,
                    "composition": "speaker crop plus purposeful punch-in; preserve truthful context",
                    "source_pool": "catalogued Creative Commons source",
                    "license_requirement": "verified_cc plus attribution",
                    "license_status": "verified_cc_2026-09-01_reaudit_before_render",
                    "recognizable_person_check": "speaker attribution; no endorsement claim",
                    "overlay": segment.get("screen_text"),
                    "audio_cue": "music ducks 8–10 dB under source speech",
                }
            )
            cursor += duration
            continue

        duration = float(segment["target_seconds"])
        role = segment["narrative_role"]
        concepts = SHOT_BANK[role]
        shot_duration = duration / len(concepts)
        for concept_index, concept in enumerate(concepts):
            start = cursor + concept_index * shot_duration
            end = cursor + (concept_index + 1) * shot_duration
            pool = "Pexels or Pixabay official library"
            shots.append(
                {
                    "shot": len(shots) + 1,
                    "start_seconds": round(start, 3),
                    "end_seconds": round(end, 3),
                    "duration_seconds": round(end - start, 3),
                    "segment_index": segment_index,
                    "narrative_role": role,
                    "asset_type": "licensed_stock_or_self_shot",
                    "concept": concept["concept"],
                    "search_query": concept["query"],
                    "composition": concept["composition"],
                    "source_pool": pool,
                    "license_requirement": "official Pexels/Pixabay download page captured; no standalone use; trademark/privacy review",
                    "license_status": "blocked_pending_asset_selection_and_evidence",
                    "recognizable_person_check": "required; no negative implication or endorsement",
                    "overlay": segment.get("screen_text") if concept_index == 0 else None,
                    "audio_cue": concept["audio_cue"],
                }
            )
        cursor += duration

    payload = {
        "slug": edl["slug"],
        "generated_at": utc_now(),
        "model_id": edl.get("model_id"),
        "duration_seconds": round(cursor, 3),
        "shot_count": len(shots),
        "average_shot_length_seconds": round(cursor / len(shots), 3),
        "release_blocked": any(item["license_status"].startswith("blocked_") for item in shots),
        "release_block_reason": "Every stock slot needs a selected asset URL and saved license evidence before render.",
        "source_policy": {
            "pexels": "https://www.pexels.com/legal-pages/license/",
            "pixabay": "https://pixabay.com/service/license-summary/",
            "wikimedia_optional": "https://commons.wikimedia.org/wiki/Commons:Reusing_content_outside_Wikimedia/licenses",
            "music": "Pixabay music is allowed only inside a larger creative work; retain download/certificate evidence and review Content ID status.",
        },
        "audio_design": {
            "narrator": "neutral licensed human or commercially cleared local voice; famous-voice cloning forbidden",
            "narration_target": "-16 LUFS integrated final program; speech intelligible throughout",
            "music_bed": "single cinematic arc with three intensity zones; duck 8–10 dB under all speech",
            "music_license_status": "blocked_pending_track_selection_download_record_and_content_id_check",
            "transition_rule": "hard cuts for declarations and evidence; dissolves only at reversal and final resolution",
            "sfx_rule": "maximum one meaningful accent per structural turn; no whoosh on every cut",
        },
        "shots": shots,
    }
    output_dir = ROOT / "output" / "shotlists"
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"{edl['slug']}.json"
    csv_path = output_dir / f"{edl['slug']}.csv"
    md_path = output_dir / f"{edl['slug']}.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fieldnames = list(shots[0].keys())
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(shots)
    md_lines = [
        f"# Shot list — {edl['slug']}", "",
        f"- {len(shots)} shots across {cursor:.1f}s; ASL {cursor / len(shots):.2f}s.",
        f"- Release blocked: {payload['release_blocked']} — {payload['release_block_reason']}",
        "", "| # | Timeline | Role | Concept | Source / status |", "|---:|---:|---|---|---|",
    ]
    for shot in shots:
        md_lines.append(
            f"| {shot['shot']} | {shot['start_seconds']:.1f}–{shot['end_seconds']:.1f}s | "
            f"{shot['narrative_role']} | {shot['concept']} | {shot['source_pool']} — {shot['license_status']} |"
        )
    md_path.write_text("\n".join(md_lines), encoding="utf-8")
    return {"payload": payload, "json": str(json_path), "csv": str(csv_path), "markdown": str(md_path)}
