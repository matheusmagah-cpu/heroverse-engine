"""Closed A/B/C composition candidate over frozen A12/V4/V6 metadata.

This is an executable literal-preservation and arithmetic contract, not a
renderer, ancestry decision, source admission or temporal allocation. Only the
fixed metadata/code buffers below are consumed; old media is never reopened.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import stat
import types

VERSION = "phase6-composition-reallocation-candidate-v1"
ROOT = Path(__file__).absolute().parents[1]
CAP = 2 * 1024**2
SOURCE_BINDINGS = {
    "a12": {"path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-cc5a42e083848fe0a7c6e843.json",
            "sha256": "c38a12e6e7c5c2b5a131282ba22d674e0f3c789542ec74d9d58e467c574bedf6"},
    "v4": {"path": "output/operations/phase6/av-admission/static-asset-uses-v4/inspection.json",
           "sha256": "69af2feb01d23bd2ca66b2cad0e7756b230a1c1943d59385b3c42e5b1036d4ce"},
    "v6": {"path": "output/qa/phase6/diagnostics/body-case-v1/staged/body-case-amendment-v1-ac645f2d8cb2fae3414b56c7/staged-visual-v6-ba7dabb1ed63c35a19021648.json",
           "sha256": "ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4"},
    "proposal": {"path": "docs/PHASE6_COMPOSITION_REALLOCATION_CANDIDATE.md",
                 "sha256": "559e83dfca5ae5b548d866a797a752a20d742563279366cc70b6055f3f66e2d5"},
    "three_recipe": {"path": "output/qa/phase6/diagnostics/three-moves-identity-v1/recipe.py",
                     "sha256": "cc31bfaf4c800d052a0ec220e7a7e69dcf5691d3c55a36059e1ba5f05bafea09"},
    "record_recipe": {"path": "output/qa/phase6/diagnostics/record-learning-v1/recipe.py",
                      "sha256": "deaabda55c5ae873f5088fb63144b9e811875cd34e5443fcd1152e808f6c75a6"},
    "compact_recipe": {"path": "output/qa/phase6/diagnostics/two-column-compact-v1/recipe.py",
                       "sha256": "51a6c8d4bab2d4c6d953861093d84cf6ec25ecc16d4ebba53abe335521ec033c"},
    "bible": {"path": "output/production/phase6/video-002/production/channel_style_bible.json",
              "sha256": "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049"},
    "graph_validator": {"path": "output/qa/phase6/diagnostics/visual-lineage-feasibility-v1/preflight.py",
                        "sha256": "4d965e46cb8c7a72cadf4ea750ea294410a71de7e9b344bb8aa272c750c22d00"},
}
GROUPS = {"A": (32, 33, 35, 47, 48, 49), "B": (36, 37, 38), "C": (15, 16, 17, 18)}
GROUP_SAMPLES = {"A": 367104, "B": 306688, "C": 323584}
FOUR = "owned-four-criteria-panel-v1"
TWO = "heroverse-owned-two-column-composition"
FEAR = "owned-fear-example-triptych-v1"
RECIPE_IDS = {"A": "three-station-path-candidate-v1", "B": "documentary-record-object-candidate-v1",
              "C": "reply-object-attributed-forecast-candidate-v1"}
AUTHORITY = dict.fromkeys(("new_lineage_validated", "source_admitted", "timing_validated", "quality_approved",
                           "rights_approved", "publicity_approved", "render_authorized", "publication_authorized"), False)
LIMITATIONS = ["CANDIDATE_ONLY_NO_NEW_COMPOSITION_EVIDENCE", "OBSERVED_EXPOSURE_REDUCTION_IS_ZERO",
              "FULL_UNIT_PCM_HYPOTHESIS_NOT_MEASURED_EXPOSURE_OR_STATE_DURATION",
              "NO_ANCESTRY_CHANGE_ACCEPTED_FROM_NAMES_OR_DESCRIPTIONS", "59_UNBOUND_STATES_REMAIN",
              "TOP6_REUSE_ROLLING60_ADJACENCY_PRIOR_OVERLAP_MINIMUM12_NOT_EVALUATED",
              "NO_SOURCE_BYTES_OCR_RENDER_AUDIO_RIGHTS_OR_PUBLICITY_RECHECK",
              "NOT_INSTALLED_IN_A_B_C_D_OR_PRODUCTION"]


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _same(actual, expected, reason):
    if canonical(actual) != canonical(expected):
        raise ValueError(reason)


def rational(value):
    value = Fraction(value)
    return {"numerator": value.numerator, "denominator": value.denominator}


def _validator(raw):
    module = types.ModuleType("_fixed_composition_graph_validator")
    module.__file__ = str(ROOT / SOURCE_BINDINGS["graph_validator"]["path"])
    # The hash of this exact buffer is checked before this function is reached.
    # Only metadata graph helpers are called, never old preflight/media executors.
    exec(compile(raw, module.__file__, "exec"), module.__dict__)
    return module


def _recipe(group):
    common = {"recipe_id": RECIPE_IDS[group], "status": "TECHNICAL_BRIEF_NOT_RENDERER",
              "all_text": "EXACT_STATE_LITERAL_COPY_ONLY", "added_words": [],
              "blank_fields_content": None, "caption_lane": "PRESERVE_BIBLE_AND_VALIDATE_COMPOSED_FRAME",
              "motion_timing": None, "new_lineage_id": None, "composition_evidence": None,
              "ancestry_decision": "PENDING_REAL_SAMPLE_AND_REVIEW",
              "forbidden": ["RENAME_OLD_LINEAGE", "OLD_RASTER_AS_TRANSPARENT_OVERLAY", "HIDDEN_ANCESTRAL_BASE",
                            "INVENTED_RESULTS", "INVENTED_WORD_ONSETS", "GENERIC_STOCK_BACKGROUND"]}
    if group == "A":
        return {**common, "construction": "Own vector horizontal path with three connected stations; focus indicator and blank action area.",
                "object_identities": ["name-station", "test-station", "choose-station", "blank-action-area"],
                "forbidden_topology": ["FOUR_CRITERIA_COUNTER", "TWO_BY_TWO_GRID"],
                "recap_geometry": "IDENTICAL_TO_FIRST_THREE_STATION_PRESENTATION"}
    if group == "B":
        return {**common, "construction": "Document objects and distinct blank sheets, with external annotation; no inherited slots or counters.",
                "object_identities": ["action-outcome-document", "original-prediction-document", "retrospective-document",
                                      "earlier-comparison-document", "later-comparison-document"],
                "forbidden_topology": ["PANEL_GRID", "RENAME_ACTION_AS_ORIGINAL_PREDICTION"],
                "stock5190601": "UNADMITTED_WRITING_GESTURE_ONLY_NOT_RECORD_CONTENT_OR_ANCESTRY_PROOF"}
    return {**common, "construction": "Fictional unbranded message interface as the central object, with an explicitly attributed forecast outside it.",
            "object_identities": ["reply-observation-object", "attributed-forecast-object"],
            "category_positions": {"Fact": "LEFT", "Fear's forecast": "RIGHT"},
            "forbidden_topology": ["SAME_TWO_COLUMN_TABLE_WITH_DECORATIVE_PHONE"],
            "fiction_boundary": "NO_INVENTED_CONVERSATION_PERSON_RECIPIENT_OR_HISTORY"}


def _state_design(group, unit, ordinal):
    if group == "A":
        focus = {32: "ALL", 33: "NAME", 35: "CHOOSE", 47: "NAME", 48: "TEST", 49: "CHOOSE"}[unit]
        return {"layout": "THREE_CONNECTED_STATIONS", "focus": focus, "blank_action_area": True,
                "retained_object": None, "introduced_object": None}
    if group == "B":
        if unit == 36 or (unit == 37 and ordinal == 0):
            return {"layout": "ACTION_OUTCOME_DOCUMENT", "focus": "BLANK_FIELDS",
                    "retained_object": "action-outcome-document", "introduced_object": None}
        if unit == 37:
            return {"layout": "SEPARATE_PREDICTION_AND_RETROSPECTIVE_DOCUMENTS", "focus": "RECORD_INTEGRITY",
                    "historical_objects_preserved_not_visible": ["action-outcome-document"],
                    "introduced_objects": ["original-prediction-document", "retrospective-document"],
                    "visible_objects": ["original-prediction-document", "retrospective-document"],
                    "blank_content_by_object": {"original-prediction-document": None, "retrospective-document": None},
                    "label_targets": [{"literal_copy_index": 0, "target": "original-prediction-document"},
                                      {"literal_copy_index": 1, "target": "EXTERNAL_RECORD_INTEGRITY_ANNOTATION"}],
                    "forbidden": ["SHOW_ACTION_OBSERVED_RESULT_LABELS", "RENAME_OLD_DOCUMENT_AS_PREDICTION",
                                  "FABRICATE_BEFORE_AFTER_CONTENT"]}
        return {"layout": "TWO_UNFILLED_COMPARISON_DOCUMENTS", "focus": ("INTRODUCTION", "WARNING_QUESTION", "STORY_QUESTION")[ordinal],
                "retained_object": "comparison-document-pair", "introduced_object": None}
    return {"layout": "MESSAGE_OBJECT_AND_ATTRIBUTED_FORECAST", "focus": {15: "LEFT", 16: "RIGHT", 17: "BOTH", 18: "BOTH"}[unit],
            "retained_object": "reply-observation-object", "introduced_object": None,
            "hold_previous_visual": unit == 16 and ordinal == 1}


def _accounting(selected, affected):
    current, hypothetical, units_by_bucket = defaultdict(int), defaultdict(int), defaultdict(list)
    for unit in selected:
        uid, lineage, samples = unit["unit_id"], unit["lineage_id"], unit["pcm_frame_count"]
        current[lineage] += samples
        bucket = "UNVALIDATED_RECIPE:" + affected[uid] if uid in affected else "RETAINED_LINEAGE:" + lineage
        hypothetical[bucket] += samples
        units_by_bucket[bucket].append(uid)
    _same(dict(current), {FOUR: 979968, TWO: 624128, FEAR: 349184}, "frozen lineage population changed")
    for group, samples in GROUP_SAMPLES.items():
        _same(hypothetical["UNVALIDATED_RECIPE:" + group], samples, "candidate group arithmetic differs")
    scenarios = []
    for label, milliseconds in (("CURRENT_PLANNED_NOT_VALIDATED", 190800), ("EDITORIAL_GRID_FLOOR", 207800),
                                ("PROTOCOL_CEILING_NOT_TARGET", 286250)):
        limit = Fraction(milliseconds * 24000, 1000) / 10
        scenarios.append({"scenario": label, "total_runtime_ms": milliseconds, "single_lineage_limit_samples": rational(limit),
            "before_excess_samples": {lineage: rational(max(Fraction(0), samples - limit)) for lineage, samples in sorted(current.items())},
            "hypothetical_buckets": [{"bucket": bucket, "unit_ids": units_by_bucket[bucket], "pcm_samples": samples,
                "pcm_duration_ms": rational(Fraction(samples * 1000, 24000)),
                "share": rational(Fraction(samples * 1000, 24000 * milliseconds)),
                "single_share_arithmetic_within_limit": samples <= limit,
                "ancestry_evidence_validated": False} for bucket, samples in sorted(hypothetical.items())]})
    return {"assumption": "EACH_SELECTED_UNIT_USES_ONE_BASE_COMPOSITION_FOR_ITS_FULL_PCM;_NEW_BUCKETS_REQUIRE_REAL_DISTINCT_ANCESTRY_AND_REPLACEMENT",
            "current_conservative_lineage_samples": dict(sorted(current.items())),
            "accepted_after_lineage_samples": dict(sorted(current.items())),
            "observed_exposure_reduction_samples": 0, "accepted_lineage_reallocation_samples": 0,
            "hypothetical_replacement_samples_by_group": deepcopy(GROUP_SAMPLES), "scenarios": scenarios}


def compile_candidate(raw_documents, *, source_bindings):
    """Deterministic closed candidate; supplied buffers must match external pins."""
    _same(source_bindings, SOURCE_BINDINGS, "closed external input pins required")
    if type(raw_documents) is not dict or set(raw_documents) != set(SOURCE_BINDINGS):
        raise ValueError("exact metadata/recipe/validator source population required")
    for key, binding in SOURCE_BINDINGS.items():
        raw = raw_documents[key]
        if type(raw) is not bytes or not 0 < len(raw) <= CAP or sha(raw) != binding["sha256"]:
            raise ValueError("fixed raw input differs: " + key)
    validator = _validator(raw_documents["graph_validator"])
    _same(validator.SOURCE_BINDINGS, {key: SOURCE_BINDINGS[key] for key in ("a12", "v4", "v6")}, "validator source population differs")
    a, v, p, bible = [validator.parse_document(raw_documents[key]) for key in ("a12", "v4", "v6", "bible")]
    rows, units, sources, uses, remaining, targets = validator._validate_graph(a, v, p)
    selected, omitted = validator._select_units(rows, units, sources, uses)
    _same(bible["channel_id"], a["channel_id"], "channel identity differs")
    affected_units = {f"narration-unit-{unit:03d}": group for group, numbers in GROUPS.items() for unit in numbers}
    selected_map = {unit["unit_id"]: unit for unit in selected}
    if not set(affected_units) <= set(selected_map):
        raise ValueError("candidate requires complete historical source bindings for each selected unit")
    changes, preserved, candidate_rows = [], [], deepcopy(p["effective_rows"])
    for index, (uid, row) in enumerate(rows.items()):
        for ordinal, before in enumerate(row["states"]):
            sid = before["state_id"]
            if uid not in affected_units:
                preserved.append(deepcopy(before))
                continue
            group = affected_units[uid]
            lineage = selected_map[uid]["lineage_id"]
            _same(lineage, TWO if group == "C" else FOUR, "before lineage cannot be renamed")
            design = _state_design(group, int(uid[-3:]), ordinal)
            visual_design = {key: value for key, value in design.items() if key != "hold_previous_visual"}
            after = deepcopy(before)
            after["visual_content"]["composition_id"] = RECIPE_IDS[group]
            after["visual_content"]["description"] = _recipe(group)["construction"] + " State instruction: " + json.dumps(visual_design, sort_keys=True) + ". All visible wording remains exactly literal_copy; no new event or time is introduced."
            candidate_rows[index]["states"][ordinal] = deepcopy(after)
            changes.append({"state_id": sid, "unit_id": uid, "group": group, "before": deepcopy(before), "after": after,
                "unit_text": row["text"], "unit_text_sha256": row["text_sha256"], "fragment_ids": deepcopy(row["fragment_ids"]),
                "state_design": design, "historical_source_metadata": deepcopy(sources[uses[sid]["source_id"]]),
                "conservative_lineage_before": lineage, "conservative_lineage_after": lineage,
                "proposed_new_lineage_id": None, "composition_evidence": None,
                "state_duration_samples": None, "scheduled_start_sample": None, "scheduled_end_sample": None})
    _same([len(changes), len(preserved), len(affected_units)], [17, 83, 13], "exact reallocation candidate scope changed")
    # Materialized state data is not emitted: this is a detached before/after contract.
    result = {"kind": "PHASE6_COMPOSITION_REALLOCATION_CANDIDATE", "version": VERSION, "status": "CANDIDATE_ONLY",
        "channel_id": a["channel_id"], "video_id": a["video_id"], "source_bindings": deepcopy(SOURCE_BINDINGS),
        "recipes": {group: _recipe(group) for group in GROUPS}, "changes": changes,
        "counts": {"affected_units": 13, "affected_states": 17, "preserved_states": 83, "unbound_states": len(remaining)},
        "preservation": {"before_effective_rows_sha256": sha(canonical(p["effective_rows"])),
            "candidate_effective_rows_sha256": sha(canonical(candidate_rows)), "preserved_states_sha256": sha(canonical(preserved)),
            "narration_fragment_map_sha256": sha(canonical(a["narration_fragment_map"])),
            "unit_metadata_sha256": sha(canonical(a["units"])), "temporal_target_unit_ids": deepcopy(targets),
            "clock": deepcopy(a["clock"]), "duration": deepcopy(a["duration"]), "blockers": deepcopy(a["blockers"]),
            "style_bible_sha256": SOURCE_BINDINGS["bible"]["sha256"], "palette": deepcopy(bible["palette"]),
            "typography": deepcopy(bible["typography"]), "hooks_changed": False, "state_times_created": 0},
        "remaining_unbound_visual_state_ids": remaining, "omitted_unit_count": len(omitted),
        "lineage_preflight": _accounting(selected, affected_units),
        "non_share_gates": {"candidate_group_unit_occurrences": {group: len(numbers) for group, numbers in GROUPS.items()},
            "warning": "A_HAS_SIX_UNIT_OCCURRENCES;_C_CONTAINS_ADJACENT_UNITS;_STATE_IDS_DO_NOT_PROVE_DISTINCT_SOURCES_OR_FEASIBILITY",
            "checks": {name: "NOT_EVALUATED" for name in ("top_six_share", "maximum_asset_reuse_count",
                "rolling_60s_reuse", "adjacent_repetition", "previous_video_overlap", "minimum_twelve_sources")}},
        "authority": dict(AUTHORITY),
        "effects": {"pcm_reads": 0, "image_reads": 0, "decodes": 0, "ocr": 0, "renders": 0, "files_written": 0,
                    "timeline_mutations": 0, "new_lineage_decisions": 0, "technical_cost_brl": 0},
        "limitations": list(LIMITATIONS)}
    result["candidate_id"] = VERSION + "-" + sha(canonical(result))[:24]
    return result


def verify_candidate(candidate, raw_documents, *, source_bindings):
    """Reject altered literals, invented times/lineages and self-declared approvals."""
    expected = compile_candidate(raw_documents, source_bindings=source_bindings)
    _same(candidate, expected, "candidate differs from exact before/after, conservative lineage or arithmetic contract")
    return {"status": "CANDIDATE_ONLY", "candidate_id": expected["candidate_id"],
            "candidate_sha256": sha(canonical(expected)), "authority": dict(AUTHORITY),
            "observed_exposure_reduction_samples": 0, "technical_cost_brl": 0}


def _read(root, binding):
    if type(binding) is not dict or set(binding) != {"path", "sha256"}:
        raise ValueError("exact candidate input binding required")
    _same(binding, next((item for item in SOURCE_BINDINGS.values() if item == binding), None), "unrecognized source binding")
    path = root / binding["path"]
    def identity():
        for part in (path, *path.parents):
            info = part.lstat()
            if (stat.S_ISLNK(info.st_mode) or part.is_symlink() or getattr(part, "is_junction", lambda: False)()
                    or getattr(info, "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000)):
                raise ValueError("linked or nonresident candidate input")
        info = path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or not 0 < info.st_size <= CAP:
            raise ValueError("bounded regular candidate input required")
        return (info.st_dev, info.st_ino, info.st_nlink, info.st_size, info.st_mtime_ns)
    before = identity()
    stamp = lambda item: (item.st_dev, item.st_ino, item.st_nlink, item.st_size, item.st_mtime_ns)
    with path.open("rb") as stream:
        if stamp(os.fstat(stream.fileno())) != before:
            raise ValueError("candidate input handle changed")
        raw = stream.read(CAP + 1)
        if stamp(os.fstat(stream.fileno())) != before:
            raise ValueError("candidate input changed while reading")
    if identity() != before or len(raw) != before[3] or sha(raw) != binding["sha256"]:
        raise ValueError("candidate input bytes changed")
    return raw


def preflight(root, *, source_bindings):
    _same(source_bindings, SOURCE_BINDINGS, "closed source map required before reads")
    root = Path(root).absolute()
    if root != ROOT or root.resolve(strict=True) != ROOT:
        raise ValueError("fixed canonical project root required")
    raw = {role: _read(root, binding) for role, binding in SOURCE_BINDINGS.items()}
    result = compile_candidate(raw, source_bindings=source_bindings)
    for role, binding in SOURCE_BINDINGS.items():
        if _read(root, binding) != raw[role]:
            raise ValueError("candidate input changed before final return")
    return result
