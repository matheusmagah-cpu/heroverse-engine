from __future__ import annotations

import base64
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
import onnxruntime as ort
import soundfile as sf
from kokoro_onnx import Kokoro
from kokoro_onnx.config import EspeakConfig
from jsonschema import Draft202012Validator

from .pilot_phase5 import materialize_pilot_contracts


SAMPLE_RATE = 24_000
MAX_PHONEME_LENGTH = 510
ESPEAK_DATA_MARKERS = ("phontab", "phonindex", "phondata", "en_dict")
USER_HOME_ESPEAK_CANDIDATE = "USER_HOME_HEROVERSE"
APPDATA_ESPEAK_CANDIDATE = "APPDATA_HEROVERSE"
PACKAGE_ESPEAK_CANDIDATE = "ESPEAKNG_LOADER_PACKAGE"
_AUTO_DLL_DIRECTORY = object()


class LocalEspeakUnavailableError(RuntimeError):
    """Raised only after every deterministic local eSpeak candidate failed."""

    def __init__(self, attempts: list[dict[str, Any]]) -> None:
        self.attempts = attempts
        details = "; ".join(
            f"{item['candidate_id']}[{item['error_code'] or item['status']}]"
            f" library={item['library_path'] or 'UNAVAILABLE'}"
            f" data={item['data_path'] or 'UNAVAILABLE'}"
            for item in attempts
        )
        super().__init__(f"no verified local eSpeak binding: {details}")


@dataclass
class LocalEspeakBinding:
    candidate_id: str
    priority: int
    library_path: Path
    data_path: Path
    library_hash: str
    data_hash: str
    version: str
    loader_package_version: str | None
    fallback_used: bool
    directory_dlls: list[dict[str, Any]]
    candidate_attempts: list[dict[str, Any]]
    _dll_directory_handle: Any = field(default=None, repr=False)

    def close(self) -> None:
        handle, self._dll_directory_handle = self._dll_directory_handle, None
        if handle is not None and callable(getattr(handle, "close", None)):
            handle.close()

    def capacity_evidence(self) -> dict[str, Any]:
        return {
            "status": "PASS",
            "selected_candidate": self.candidate_id,
            "library_path": str(self.library_path),
            "data_path": str(self.data_path),
            "library_hash": self.library_hash,
            "data_hash": self.data_hash,
            "version": self.version,
            "loader_package_version": self.loader_package_version,
            "fallback_used": self.fallback_used,
            "directory_dlls": self.directory_dlls,
            "candidate_attempts": self.candidate_attempts,
            "error": None,
            "technical_cost_brl": 0,
        }

    def identity(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "library_path": str(self.library_path),
            "data_path": str(self.data_path),
            "library_hash": self.library_hash,
            "data_hash": self.data_hash,
            "version": self.version,
            "loader_package_version": self.loader_package_version,
            "fallback_used": self.fallback_used,
            "directory_dlls": self.directory_dlls,
        }

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


class _EspeakCandidateFailure(Exception):
    def __init__(self, code: str, *, error_type: str | None = None) -> None:
        self.code = code
        self.error_type = error_type
        super().__init__(code)


class KokoroFloatSpeed(Kokoro):
    """Compatibility adapter for Kokoro v1.0's float ``speed`` input.

    kokoro-onnx 0.4.9 sends int32 to newer exports even when ONNX declares a
    float tensor. The override is intentionally narrow and verified against the
    model's runtime input contract before synthesis.
    """

    def _create_audio(self, phonemes: str, voice: np.ndarray, speed: float) -> tuple[np.ndarray, int]:
        phonemes = phonemes[:MAX_PHONEME_LENGTH]
        tokens = np.asarray(self.tokenizer.tokenize(phonemes), dtype=np.int64)
        if len(tokens) > MAX_PHONEME_LENGTH:
            raise ValueError(f"phoneme token count exceeds {MAX_PHONEME_LENGTH}")
        selected_style = np.asarray(voice[len(tokens)], dtype=np.float32)
        if selected_style.ndim == 1:
            selected_style = selected_style[np.newaxis, :]
        inputs = {
            "input_ids": np.asarray([[0, *tokens.tolist(), 0]], dtype=np.int64),
            "style": selected_style,
            "speed": np.asarray([speed], dtype=np.float32),
        }
        audio = np.asarray(self.sess.run(None, inputs)[0], dtype=np.float32).reshape(-1)
        return audio, SAMPLE_RATE


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def hash_local_espeak_data(path: Path) -> str:
    """Hash every regular data file and its relative path in stable order."""

    base = path.resolve()
    if not base.is_dir():
        raise NotADirectoryError(base)
    files = sorted((item for item in base.rglob("*") if item.is_file()), key=lambda item: item.relative_to(base).as_posix())
    if not files:
        raise ValueError("eSpeak data directory is empty")
    digest = hashlib.sha256()
    for item in files:
        resolved = item.resolve()
        try:
            relative = resolved.relative_to(base).as_posix()
        except ValueError as exc:
            raise PermissionError("eSpeak data file resolves outside its candidate directory") from exc
        encoded = relative.encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        with resolved.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
    return "sha256:" + digest.hexdigest()


def _probe_espeak_data(library_path: Path, data_path: Path) -> str:
    """Load and initialize native eSpeak out of process, returning its version."""

    script = """
import base64
import ctypes
import os
import sys

library_path, data_path = sys.argv[1], sys.argv[2]
dll_handle = os.add_dll_directory(os.path.dirname(library_path)) if os.name == "nt" else None
library = ctypes.CDLL(library_path)
info = library.espeak_Info
info.argtypes = [ctypes.POINTER(ctypes.c_char_p)]
info.restype = ctypes.c_char_p
reported_data_path = ctypes.c_char_p()
raw_version = info(ctypes.byref(reported_data_path))
if not raw_version:
    raise SystemExit(19)
initialize = library.espeak_Initialize
initialize.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
initialize.restype = ctypes.c_int
terminate = library.espeak_Terminate
terminate.argtypes = []
terminate.restype = ctypes.c_int
initialized = initialize(0x02, 0, data_path.encode("utf-8"), 0) > 0
if not initialized:
    raise SystemExit(20)
set_voice = library.espeak_SetVoiceByName
set_voice.argtypes = [ctypes.c_char_p]
set_voice.restype = ctypes.c_int
voice_status = set_voice(b"en-us")
terminate()
if voice_status != 0:
    raise SystemExit(21)
print("HVER_ESPEAK_VERSION=" + base64.urlsafe_b64encode(raw_version).decode("ascii"))
"""
    try:
        completed = subprocess.run(
            [sys.executable, "-I", "-c", script, str(library_path), str(data_path)],
            capture_output=True,
            timeout=15,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise _EspeakCandidateFailure("DATA_PROBE_TIMEOUT", error_type=type(exc).__name__) from exc
    except Exception as exc:
        raise _EspeakCandidateFailure("DATA_PROBE_PROCESS_FAILED", error_type=type(exc).__name__) from exc
    if completed.returncode != 0:
        raise _EspeakCandidateFailure(f"DATA_PROBE_EXIT_{completed.returncode}")
    prefix = b"HVER_ESPEAK_VERSION="
    encoded = next((line[len(prefix):] for line in completed.stdout.splitlines() if line.startswith(prefix)), None)
    if not encoded:
        raise _EspeakCandidateFailure("VERSION_PROBE_MISSING")
    try:
        version = base64.urlsafe_b64decode(encoded).decode("utf-8", errors="strict").strip()
    except Exception as exc:
        raise _EspeakCandidateFailure("VERSION_PROBE_INVALID", error_type=type(exc).__name__) from exc
    if not version or len(version) > 128 or any(ord(character) < 32 for character in version):
        raise _EspeakCandidateFailure("VERSION_PROBE_INVALID")
    return version


def inventory_local_espeak_dlls(library_path: Path) -> list[dict[str, Any]]:
    # Preserve the Windows inventory contract; Linux candidates use ELF shared
    # libraries and cannot be authenticated by scanning for DLLs alone.
    posix_library = os.name == "posix" and re.search(r"\.so(?:\.\d+)*$", library_path.name) is not None
    if posix_library:
        with library_path.open("rb") as handle:
            if handle.read(4) != b"\x7fELF":
                raise RuntimeError("selected eSpeak shared library is not ELF")
    records = []
    for dll in sorted(
        (item for item in library_path.parent.iterdir() if item.is_file() and (
            re.search(r"\.so(?:\.\d+)*$", item.name) is not None
            if posix_library else item.suffix.casefold() == ".dll"
        )),
        key=lambda item: item.name.casefold(),
    ):
        if dll.stat().st_size <= 0:
            raise RuntimeError(f"empty DLL in selected eSpeak directory: {dll.name}")
        records.append({
            "name": dll.name,
            "path": str(dll.resolve()),
            "content_hash": _sha256(dll),
            "size_bytes": dll.stat().st_size,
        })
    if not any(Path(item["path"]) == library_path for item in records):
        raise RuntimeError("selected eSpeak library was absent from its DLL directory inventory")
    return records


def espeak_binding_identity(value: LocalEspeakBinding | dict[str, Any]) -> dict[str, Any]:
    if isinstance(value, LocalEspeakBinding):
        return value.identity()
    candidate_id = value.get("candidate_id", value.get("selected_candidate"))
    identity = {
        "candidate_id": candidate_id,
        "library_path": value.get("library_path"),
        "data_path": value.get("data_path"),
        "library_hash": value.get("library_hash"),
        "data_hash": value.get("data_hash"),
        "version": value.get("version"),
        "loader_package_version": value.get("loader_package_version"),
        "fallback_used": value.get("fallback_used"),
        "directory_dlls": value.get("directory_dlls"),
    }
    if (
        not isinstance(identity["candidate_id"], str)
        or not isinstance(identity["library_path"], str)
        or not isinstance(identity["data_path"], str)
        or not isinstance(identity["library_hash"], str)
        or not isinstance(identity["data_hash"], str)
        or not isinstance(identity["version"], str)
        or not isinstance(identity["fallback_used"], bool)
        or not isinstance(identity["directory_dlls"], list)
    ):
        raise ValueError("incomplete eSpeak binding identity")
    return identity


def revalidate_local_espeak_binding(
    binding: LocalEspeakBinding,
    *,
    expected_binding: dict[str, Any] | None = None,
) -> dict[str, Any]:
    current = binding.identity()
    if binding.library_hash != _sha256(binding.library_path):
        raise PermissionError("selected eSpeak library content changed")
    if binding.data_hash != hash_local_espeak_data(binding.data_path):
        raise PermissionError("selected eSpeak data content changed")
    if binding.directory_dlls != inventory_local_espeak_dlls(binding.library_path):
        raise PermissionError("selected eSpeak DLL directory inventory changed")
    if expected_binding is not None and current != espeak_binding_identity(expected_binding):
        raise PermissionError("selected eSpeak binding diverges from the capacity receipt")
    return current


def _candidate_attempt(
    candidate_id: str,
    priority: int,
    library_path: Path | None,
    data_path: Path | None,
    *,
    status: str,
    error_code: str | None,
    error_type: str | None,
) -> dict[str, Any]:
    return {
        "candidate_id": candidate_id,
        "priority": priority,
        "library_path": str(library_path.resolve()) if library_path is not None else None,
        "data_path": str(data_path.resolve()) if data_path is not None else None,
        "status": status,
        "error_code": error_code,
        "error_type": error_type,
    }


def _package_candidate_paths(loader_module: Any | None) -> tuple[Path, Path, str | None]:
    try:
        module = loader_module if loader_module is not None else importlib.import_module("espeakng_loader")
    except Exception as exc:
        raise _EspeakCandidateFailure("PACKAGE_LOADER_UNAVAILABLE", error_type=type(exc).__name__) from exc
    try:
        library_path = Path(module.get_library_path())
        data_path = Path(module.get_data_path())
    except Exception as exc:
        raise _EspeakCandidateFailure("PACKAGE_PATH_RESOLUTION_FAILED", error_type=type(exc).__name__) from exc
    package_version = getattr(module, "__version__", None)
    if not package_version and loader_module is None:
        try:
            package_version = importlib.metadata.version("espeakng-loader")
        except importlib.metadata.PackageNotFoundError:
            package_version = None
    if not package_version:
        raise _EspeakCandidateFailure("PACKAGE_VERSION_UNAVAILABLE")
    return library_path, data_path, str(package_version)


def _validate_espeak_candidate_files(library_path: Path, data_path: Path) -> None:
    if not library_path.is_file():
        raise _EspeakCandidateFailure("LIBRARY_NOT_FOUND")
    if library_path.stat().st_size <= 0:
        raise _EspeakCandidateFailure("LIBRARY_EMPTY")
    if not data_path.is_dir():
        raise _EspeakCandidateFailure("DATA_DIRECTORY_NOT_FOUND")
    for marker in ESPEAK_DATA_MARKERS:
        marker_path = data_path / marker
        if not marker_path.is_file():
            raise _EspeakCandidateFailure(f"DATA_MARKER_MISSING_{marker.upper()}")
        if marker_path.stat().st_size <= 0:
            raise _EspeakCandidateFailure(f"DATA_MARKER_EMPTY_{marker.upper()}")


def resolve_local_espeak_binding(
    *,
    home_path: Path | None = None,
    loader_module: Any | None = None,
    functional_probe: Callable[[Path, Path], str] = _probe_espeak_data,
    dll_directory_adder: Any = _AUTO_DLL_DIRECTORY,
) -> LocalEspeakBinding:
    """Resolve and load only deterministic, zero-cost local eSpeak candidates."""

    local_home = (home_path or Path.home()).resolve()
    user_home_root = local_home / ".heroverse" / "espeakng"
    appdata_root = local_home / "AppData" / "Local" / "HeroVerse" / "espeakng"
    candidates: list[tuple[str, int, bool]] = [
        (USER_HOME_ESPEAK_CANDIDATE, 1, False),
        (APPDATA_ESPEAK_CANDIDATE, 2, False),
        (PACKAGE_ESPEAK_CANDIDATE, 3, True),
    ]
    attempts: list[dict[str, Any]] = []
    for candidate_id, priority, fallback_used in candidates:
        library_path: Path | None = None
        data_path: Path | None = None
        loader_package_version: str | None = None
        dll_handle: Any = None
        try:
            if candidate_id == USER_HOME_ESPEAK_CANDIDATE:
                library_path = user_home_root / "espeak-ng.dll"
                data_path = user_home_root / "espeak-ng-data"
            elif candidate_id == APPDATA_ESPEAK_CANDIDATE:
                library_path = appdata_root / "espeak-ng.dll"
                data_path = appdata_root / "espeak-ng-data"
            else:
                library_path, data_path, loader_package_version = _package_candidate_paths(loader_module)
            library_path = library_path.resolve()
            data_path = data_path.resolve()
            if candidate_id == USER_HOME_ESPEAK_CANDIDATE and (not str(library_path).isascii() or not str(data_path).isascii()):
                raise _EspeakCandidateFailure("PORTABLE_PATH_NOT_ASCII")
            _validate_espeak_candidate_files(library_path, data_path)
            environment_library = os.environ.get("PHONEMIZER_ESPEAK_LIBRARY")
            if environment_library and Path(environment_library).resolve() != library_path:
                raise _EspeakCandidateFailure("ENV_LIBRARY_OVERRIDE_DIVERGES")
            adder = getattr(os, "add_dll_directory", None) if dll_directory_adder is _AUTO_DLL_DIRECTORY else dll_directory_adder
            if os.name == "nt" and not callable(adder):
                raise _EspeakCandidateFailure("DLL_DIRECTORY_BINDING_UNAVAILABLE")
            if callable(adder):
                dll_handle = adder(str(library_path.parent))
                if os.name == "nt" and not callable(getattr(dll_handle, "close", None)):
                    raise _EspeakCandidateFailure("DLL_DIRECTORY_HANDLE_INVALID")
            try:
                version = str(functional_probe(library_path, data_path)).strip()
            except _EspeakCandidateFailure:
                raise
            except Exception as exc:
                raise _EspeakCandidateFailure("DATA_FUNCTIONAL_PROBE_FAILED", error_type=type(exc).__name__) from exc
            if not version:
                raise _EspeakCandidateFailure("VERSION_PROBE_EMPTY")
            try:
                library_hash = _sha256(library_path)
                data_hash = hash_local_espeak_data(data_path)
                directory_dlls = inventory_local_espeak_dlls(library_path)
            except Exception as exc:
                raise _EspeakCandidateFailure("CONTENT_HASH_FAILED", error_type=type(exc).__name__) from exc
            binding = LocalEspeakBinding(
                candidate_id=candidate_id,
                priority=priority,
                library_path=library_path,
                data_path=data_path,
                library_hash=library_hash,
                data_hash=data_hash,
                version=version,
                loader_package_version=loader_package_version,
                fallback_used=fallback_used,
                directory_dlls=directory_dlls,
                candidate_attempts=[],
                _dll_directory_handle=dll_handle,
            )
            attempts.append(_candidate_attempt(
                candidate_id, priority, library_path, data_path,
                status="PASS", error_code=None, error_type=None,
            ))
            binding.candidate_attempts = list(attempts)
            return binding
        except _EspeakCandidateFailure as exc:
            if dll_handle is not None and callable(getattr(dll_handle, "close", None)):
                dll_handle.close()
            attempts.append(_candidate_attempt(
                candidate_id, priority, library_path, data_path,
                status="FAIL", error_code=exc.code, error_type=exc.error_type,
            ))
        except Exception as exc:
            if dll_handle is not None and callable(getattr(dll_handle, "close", None)):
                dll_handle.close()
            attempts.append(_candidate_attempt(
                candidate_id, priority, library_path, data_path,
                status="FAIL", error_code="UNEXPECTED_LOCAL_BINDING_ERROR", error_type=type(exc).__name__,
            ))
    raise LocalEspeakUnavailableError(attempts)


def build_local_voice(
    root: Path,
    *,
    home_path: Path | None = None,
    loader_module: Any | None = None,
    engine_factory: Callable[..., KokoroFloatSpeed] = KokoroFloatSpeed,
    functional_probe: Callable[[Path, Path], str] = _probe_espeak_data,
    dll_directory_adder: Any = _AUTO_DLL_DIRECTORY,
    expected_binding: dict[str, Any] | None = None,
) -> KokoroFloatSpeed:
    model_path = root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx"
    voices_path = root / "models" / "kokoro" / "voices-v1.0.bin"
    for required in (model_path, voices_path):
        if not required.is_file():
            raise FileNotFoundError(required)
    ort.set_default_logger_severity(4)

    binding = resolve_local_espeak_binding(
        home_path=home_path,
        loader_module=loader_module,
        functional_probe=functional_probe,
        dll_directory_adder=dll_directory_adder,
    )
    try:
        revalidate_local_espeak_binding(binding, expected_binding=expected_binding)
        environment_library = os.environ.get("PHONEMIZER_ESPEAK_LIBRARY")
        if environment_library and Path(environment_library).resolve() != binding.library_path:
            raise RuntimeError("PHONEMIZER_ESPEAK_LIBRARY diverges from the selected local binding")
        espeak_config = EspeakConfig(lib_path=str(binding.library_path), data_path=str(binding.data_path))
        voice = engine_factory(
            str(model_path),
            str(voices_path),
            espeak_config=espeak_config,
        )
        if Path(espeak_config.lib_path).resolve() != binding.library_path:
            raise RuntimeError("Kokoro replaced the selected eSpeak library binding")
        if Path(espeak_config.data_path).resolve() != binding.data_path:
            raise RuntimeError("Kokoro replaced the selected eSpeak data binding")
        input_types = {item.name: item.type for item in voice.sess.get_inputs()}
        expected = {"input_ids": "tensor(int64)", "style": "tensor(float)", "speed": "tensor(float)"}
        if input_types != expected:
            raise RuntimeError(f"unexpected Kokoro input contract: {input_types}")
        revalidate_local_espeak_binding(binding, expected_binding=expected_binding)
    except Exception:
        binding.close()
        raise
    setattr(voice, "_heroverse_espeak_binding", binding)
    return voice


def synthesize_voice_sample(
    engine: KokoroFloatSpeed,
    *,
    text: str,
    output_path: Path,
    voice_id: str = "am_michael",
    speed: float = 1.0,
) -> dict[str, Any]:
    if speed < 0.8 or speed > 1.25:
        raise ValueError("Phase 5 voice speed must remain between 0.8 and 1.25")
    started = time.perf_counter()
    samples, sample_rate = engine.create(text, voice=voice_id, speed=speed, lang="en-us", trim=True)
    elapsed = time.perf_counter() - started
    samples = np.asarray(samples, dtype=np.float32).reshape(-1)
    if not len(samples):
        raise RuntimeError("voice adapter produced empty audio")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(output_path, samples, sample_rate, subtype="PCM_16")
    duration = len(samples) / sample_rate
    peak = float(np.max(np.abs(samples)))
    return {
        "text": text,
        "voice_id": voice_id,
        "speed": speed,
        "sample_rate": sample_rate,
        "samples": len(samples),
        "duration_ms": round(duration * 1000),
        "render_seconds": round(elapsed, 6),
        "real_time_factor": round(elapsed / duration, 6) if duration else None,
        "peak_linear": round(peak, 6),
        "clipping": peak >= 1.0,
        "path": str(output_path.resolve()),
        "content_hash": _sha256(output_path),
    }


def benchmark_hook_voice(root: Path) -> dict[str, Any]:
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    script = json.loads((package_dir / "narrative_script.json").read_text(encoding="utf-8"))
    engine = build_local_voice(root)
    work_dir = package_dir / "audio" / "hook-benchmark"
    windows = []
    speeds = [1.20, 1.12, 1.06]
    for index, (window, speed) in enumerate(zip(script["hook_windows"][:3], speeds), start=1):
        report = synthesize_voice_sample(
            engine,
            text=window["narration"],
            output_path=work_dir / f"hook-{index:02d}.wav",
            speed=speed,
        )
        available_ms = int(window["end_ms"]) - int(window["start_ms"])
        report["window"] = window["window"]
        report["available_ms"] = available_ms
        report["fits_window"] = report["duration_ms"] <= available_ms
        windows.append(report)
    result = {
        "schema_version": "1.0.0",
        "adapter_id": "adapter-local-voice",
        "adapter_implementation": "KokoroFloatSpeed",
        "model": "kokoro-v1.0.fp16.onnx",
        "voice": "am_michael",
        "windows": windows,
        "all_fit": all(item["fits_window"] for item in windows),
        "publication_approved": False,
        "limitations": [
            "Pronunciation, emotion and voice identity require independent human review.",
            "A timing pass does not validate narration quality or commercial publication readiness.",
        ],
    }
    report_path = work_dir / "benchmark.json"
    report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def synthesize_pilot_narration(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    """Render every take, measure it, and rebuild the timeline from measured voice."""

    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    script = json.loads((package_dir / "narrative_script.json").read_text(encoding="utf-8"))
    plan = json.loads((package_dir / "take_plan.json").read_text(encoding="utf-8"))
    engine = build_local_voice(root)
    audio_dir = package_dir / "audio" / "takes"
    audio_dir.mkdir(parents=True, exist_ok=True)
    speeds = {"take-001": 1.20, "take-002": 1.12, "take-003": 1.06}
    records: list[dict[str, Any]] = []
    duration_overrides: dict[str, int] = {}
    for take in plan["takes"]:
        take_id = take["take_id"]
        text = take.get("narration")
        if not text:
            raise ValueError(f"{take_id} has no narration")
        speed = speeds.get(take_id, 1.0)
        rendered = synthesize_voice_sample(
            engine,
            text=text,
            output_path=audio_dir / f"{take_id}.wav",
            speed=speed,
        )
        if take_id in speeds:
            timeline_slot = int(take["end_ms"]) - int(take["start_ms"])
        else:
            timeline_slot = int(math.ceil(max(1600, rendered["duration_ms"] + 250) / 100.0) * 100)
            duration_overrides[take_id] = timeline_slot
        records.append(
            {
                "take_id": take_id,
                "text": text,
                "speed": speed,
                "duration_ms": rendered["duration_ms"],
                "timeline_slot_ms": timeline_slot,
                "fits_timeline_slot": rendered["duration_ms"] <= timeline_slot,
                "peak_linear": rendered["peak_linear"],
                "clipping": rendered["clipping"],
                "render_seconds": rendered["render_seconds"],
                "path": rendered["path"],
                "content_hash": rendered["content_hash"],
            }
        )
    hook_pass = all(item["fits_timeline_slot"] for item in records[:3])
    if not hook_pass:
        raise RuntimeError("measured hook narration does not fit the locked 0–1/1–3/3–8 windows")
    if any(item["clipping"] for item in records):
        raise RuntimeError("raw voice render clipped")

    rematerialized = materialize_pilot_contracts(
        root,
        created_at=timestamp,
        take_duration_overrides=duration_overrides,
    )
    timeline_duration_ms = int(rematerialized["timeline_duration_ms"])
    manifest = {
        "schema_version": "1.0.0",
        "voice_render_id": "voice-" + hashlib.sha256(f"{script['script_id']}|am_michael|{timestamp}".encode("utf-8")).hexdigest()[:20],
        "status": "COMPLETE",
        "video_id": "phase5-pilot-001",
        "script_id": script["script_id"],
        "script_version": script["version"],
        "adapter_id": "adapter-local-voice",
        "adapter_implementation": "KokoroFloatSpeed",
        "model": "models/kokoro/kokoro-v1.0.fp16.onnx",
        "model_hash": _sha256(root / "models" / "kokoro" / "kokoro-v1.0.fp16.onnx"),
        "voices_hash": _sha256(root / "models" / "kokoro" / "voices-v1.0.bin"),
        "voice_id": "am_michael",
        "sample_rate": SAMPLE_RATE,
        "take_count": len(records),
        "takes": records,
        "hook_timing_gate": "PASS",
        "total_audio_duration_ms": sum(item["duration_ms"] for item in records),
        "total_render_seconds": round(sum(item["render_seconds"] for item in records), 6),
        "timeline_duration_ms": timeline_duration_ms,
        "publication_approved": False,
        "limitations": [
            "Voice identity, pronunciation, pauses and emotion still require independent human review.",
            "The timeline is measured from synthesized takes; final mix and loudness are not yet validated.",
        ],
        "created_at": timestamp,
    }
    schema = json.loads((root / "schemas" / "voice_render_manifest.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(manifest)
    destination = package_dir / "audio" / "voice_render_manifest.json"
    destination.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest
