from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import subprocess
import tempfile
import time
import uuid
import ctypes
import sys
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker

from .render_creative_v2_phase5 import FFMPEG, FFPROBE, _font
from .phase6_asset_residency import verify_phase6_asset_residency
from .phase6_release import PRODUCTION_INPUT_RECEIPTS, verify_production_inputs_receipt
from .voice_phase5 import (
    ESPEAK_DATA_MARKERS,
    LocalEspeakBinding,
    LocalEspeakUnavailableError,
    hash_local_espeak_data,
    inventory_local_espeak_dlls,
    resolve_local_espeak_binding,
)


ROOT = Path(__file__).resolve().parents[1]
BASE = Path("output/production/phase6/video-002")


def verify_observed_ffmpeg_file_inputs(root: Path, command: list[str], declared: tuple[Path, ...]) -> None:
    """Bind every direct -i operand to observed local bytes before claiming capture.

    This deliberately does not parse filter graphs or concat members. Their
    dependencies still need separate evidence; no visual authority is granted.
    Non-file inputs are outside the existing witnessed render contract.
    """
    if not isinstance(command, list) or any(type(arg) is not str for arg in command):
        raise ValueError("observed direct input requires literal argv")
    root = root.resolve()
    bindings = {path.resolve() for path in declared}
    positions = [index for index, arg in enumerate(command[:-1]) if arg == "-i"]
    if not positions:
        raise ValueError("observed direct input is missing")
    for index in positions:
        if index + 1 >= len(command) - 1 or not command[index + 1]:
            raise ValueError("observed direct input operand is missing")
        path = Path(command[index + 1])
        if not path.is_absolute():
            raise ValueError("observed direct input must be an absolute local file")
        path = path.resolve()
        if not path.is_relative_to(root) or path not in bindings:
            raise ValueError("observed direct input is outside the declared file bindings")
LATEST = Path("output/operations/phase6/capacity/latest.json")
RECEIPTS = Path("output/operations/phase6/capacity/receipts")

GIB = 1024**3
MINIMUM_POST_RENDER_HEADROOM_BYTES = 5 * GIB
MINIMUM_SEPARATE_TEMP_FREE_BYTES = 1 * GIB
ESTIMATE_VERSION = "phase6-standard-storage-v1"
PALETTE_ESTIMATE_VERSION = "phase6-palette-qp1-storage-v1"
# Real 78-frame/2.6s QP1 control, 27,058,021 bytes; not a codec upper bound or QA.
# Measurement SHA 8038d88a586edb29538e5e7bcc0b9e6c1be163614da5209e133c7d0532e4fdf2.
# The existing 25% plan contingency and per-command re-admission still apply.
PALETTE_MEASURED_VIDEO_BITRATE_BPS = math.ceil(27_058_021 * 8 * 1000 / 2600)
PLAN_BINDING_VERSION = "phase6-exact-take-plan-sha256-v1"
INTERMEDIATE_VIDEO_BITRATE_BPS = 60_000_000
FINAL_VIDEO_BITRATE_BPS = 12_000_000
FINAL_AUDIO_BITRATE_BPS = 256_000
PCM_STEREO_48K_16_BIT_BPS = 48_000 * 2 * 16
RAW_VOICE_24K_MONO_16_BIT_BPS = 24_000 * 1 * 16

# Admission observations are NOT capacity receipts or quality approvals. The
# existing immutable receipt contract remains unchanged (including its pins).
ACTIVE_RESOURCE_VERSION = "phase6-active-resources-v1"
RESOURCE_RECHECK_SECONDS = 60
_HEAVY_TASK_SLOT = threading.Lock()


class ResourceWait(RuntimeError):
    def __init__(self, observation: dict[str, Any]) -> None:
        self.observation = observation
        super().__init__("RESOURCE_WAIT: " + ", ".join(observation["causes"]))


def measure_local_resources(root: Path) -> dict[str, Any]:
    """Bounded native observation; unknown is never treated as free capacity."""
    if sys.platform == "win32":
        class Memory(ctypes.Structure):
            _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
                (name, ctypes.c_ulonglong) for name in (
                    "total", "available", "total_page", "available_page",
                    "total_virtual", "available_virtual", "available_extended",
                )
            ]
        memory = Memory()
        memory.length = ctypes.sizeof(memory)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
            raise OSError("GlobalMemoryStatusEx unavailable")

        def cpu_times():
            values = [ctypes.c_ulonglong() for _ in range(3)]
            if not ctypes.windll.kernel32.GetSystemTimes(*(ctypes.byref(v) for v in values)):
                raise OSError("GetSystemTimes unavailable")
            return tuple(v.value for v in values)

        before = cpu_times()
        time.sleep(0.05)  # one bounded sample, not a polling/admission loop
        after = cpu_times()
        idle, kernel, user = (a - b for a, b in zip(after, before))
        if kernel + user <= 0 or min(idle, kernel, user) < 0:
            raise OSError("CPU sample unavailable")
        load = 100 * (1 - idle / (kernel + user))
        available, total = int(memory.available), int(memory.total)
        method = "GlobalMemoryStatusEx/GetSystemTimes"
    else:
        # Optional existing dependency; absence blocks, never installs anything.
        import psutil
        memory = psutil.virtual_memory()
        available, total = int(memory.available), int(memory.total)
        load = psutil.cpu_percent(interval=0.05)
        method = "psutil"
    return {
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "available_ram_bytes": available, "total_ram_bytes": total,
        "output_free_bytes": int(shutil.disk_usage(root).free),
        "temp_free_bytes": int(shutil.disk_usage(tempfile.gettempdir()).free),
        "cpu_load_percent": load, "logical_cpus": os.cpu_count(), "method": method,
    }


def verify_static_music_capacity_measurement(root: Path, measured: dict[str, Any], *,
        duration_ms: int, image: Path, audio: Path) -> int:
    """Reopen this invocation's codec witness; never turn it into quality authority."""
    root, image, audio = root.resolve(), image.resolve(), audio.resolve()
    if (type(duration_ms) is not int or duration_ms <= 30000
            or measured.get('version') != 'phase6-static-music-capacity-v1'
            or measured.get('duration_ms') != 30000
            or measured.get('quality_approval') is not False
            or measured.get('estimate_is_maximum') is not False):
        raise PermissionError('static capacity measurement contract differs')
    row = measured['execution']
    output = Path(row['output']['path']).resolve()
    if (not output.is_relative_to(root) or output.parent.name != 'capacity'
            or not output.name.startswith('static-capacity-') or output.suffix != '.mp4'
            or output in (image, audio) or image == audio
            or not image.is_relative_to(root) or not audio.is_relative_to(root)):
        raise PermissionError('static capacity witnessed paths differ')
    from .render_phase5 import _rest_render_command
    if (row.get('version') != 'phase6-observed-ffmpeg-execution-v1'
            or row.get('status') != 'COMPLETED' or type(row.get('exit_code')) is not int
            or row['exit_code'] != 0 or row.get('quality_approval') is not False
            or row.get('cwd') != str(root)
            or row.get('argv') != _rest_render_command(image, audio, output, 30000)
            or [b['path'] for b in row['inputs']] != [str(image),str(audio)]
            or row['executable']['path'] != row['argv'][0]):
        raise PermissionError('static capacity has no exact successful native execution')
    for bound in [row['executable'],*row['inputs'],row['output']]:
        path = Path(bound['path']).resolve()
        if (type(bound['size_bytes']) is not int or bound['size_bytes'] <= 0
                or path.stat().st_size != bound['size_bytes'] or _sha256(path) != bound['sha256']):
            raise PermissionError('static capacity bytes changed')
    probe = measured['probe']
    video = [s for s in probe['streams'] if s['codec_type'] == 'video']
    sound = [s for s in probe['streams'] if s['codec_type'] == 'audio']
    if (len(video) != 1 or len(sound) != 1
            or round(float(probe['format']['duration'])*1000) != 30000
            or int(probe['format']['size']) != row['output']['size_bytes']
            or (video[0]['codec_name'],int(video[0]['width']),int(video[0]['height']),
                video[0]['r_frame_rate']) != ('h264',1920,1080,'30/1')
            or (sound[0]['codec_name'],int(sound[0]['sample_rate']),int(sound[0]['channels']))
                != ('aac',48000,2)):
        raise PermissionError('static capacity observed duration/streams differ')
    projected = math.ceil(row['output']['size_bytes'] * duration_ms / 30000)
    return 12*1024**3 + math.ceil(projected * 2 * 1.25)


class Phase6ResourcePreparation:
    """One serial media call's admission and private, disposable capture handles.

    No directory scan, external cleanup callback, arbitrary path registration,
    process termination or deletion by pathname. Only our completed subprocess
    captures can become idle. Active captures stay outside that collection.
    Those anonymous/delete-on-close files never become media or evidence inputs.
    """

    def __init__(self, root: Path, *, probe=None, plan_path: Path | None = None,
                 music_package_relative: Path | None = None,
                 music_recipe_binding: dict[str, str] | None = None) -> None:
        self.root = root.resolve()
        self.plan_path = (plan_path or self.root / BASE / "production/take_plan.json").resolve()
        if not self.plan_path.is_relative_to(self.root):
            raise PermissionError("resource plan escaped its root")
        self.probe = probe or measure_local_resources
        self.observations: list[dict[str, Any]] = []
        self._idle_captures: list[Any] = []
        self._entered = False
        self._music_inputs = None
        self._static_capacity = None
        self._capacity_probe_command = None
        if music_package_relative is not None or music_recipe_binding is not None:
            if plan_path is not None or music_package_relative is None or music_recipe_binding is None:
                raise PermissionError('instrumental capacity requires its exact native inputs, not a take plan')
            from .creative_direction import read_christian_rest_music_inputs
            self._music_inputs = read_christian_rest_music_inputs(self.root,
                package_relative=music_package_relative, recipe_binding=music_recipe_binding)

    def _duration_ms(self) -> int:
        if self._music_inputs is not None:
            for row in self._music_inputs['inputs']:
                if _sha256(Path(row['path'])) != row['sha256']:
                    raise PermissionError('instrumental capacity inputs changed')
            return self._music_inputs['recipe']['duration_ms']
        return _storage_estimate(_read(self.plan_path))['duration_ms']

    def _unpaused(self) -> None:
        try:
            (self.root / "output/runtime/gestor-central/PAUSE").lstat()
        except FileNotFoundError:
            return
        except OSError as exc:
            raise ResourceWait({"causes": [f"PAUSE_STATE_UNKNOWN:{type(exc).__name__}"], "next_check_seconds": RESOURCE_RECHECK_SECONDS}) from exc
        raise ResourceWait({"causes": ["OWNER_PAUSE"], "next_check_seconds": None})

    def __enter__(self):
        self._unpaused()
        if not _HEAVY_TASK_SLOT.acquire(blocking=False):
            raise ResourceWait({"causes": ["OWN_HEAVY_TASK_ALREADY_ACTIVE"], "next_check_seconds": RESOURCE_RECHECK_SECONDS})
        self._entered = True
        return self

    def __exit__(self, *exc_info):
        try:
            self.release_idle()
        finally:
            self._static_capacity = None
            self._capacity_probe_command = None
            self._entered = False
            _HEAVY_TASK_SLOT.release()

    def release_idle(self) -> int:
        released = 0
        # Close only handles retained after subprocess.run has returned. Never
        # inspect old temp directories, follow paths or use age as ownership.
        while self._idle_captures:
            handle = self._idle_captures[0]
            handle.close()
            self._idle_captures.pop(0)
            released += 1
        return released

    def _requirements(self, stage: str) -> dict[str, Any]:
        if self._music_inputs is not None:
            if stage not in ('ffmpeg', 'ffmpeg:static-capacity'):
                raise PermissionError('instrumental render scope cannot admit voice or other stages')
            seconds = self._duration_ms() / 1000
            # One direct mux, no cinematic take files or fake narration. Reuse
            # the existing final-output working bitrate estimate, twice for
            # faststart relocation, with its 25% contingency. This is explicitly
            # a storage estimate, not a bitrate cap or quality concession.
            basis = 'existing final bitrate working estimate; direct mux + faststart + 25%, plus 12GiB'
            if stage == 'ffmpeg:static-capacity':
                if self._capacity_probe_command is None:
                    raise PermissionError('capacity probe is private to its producing invocation')
                seconds = min(seconds, 30)
            output = math.ceil((FINAL_VIDEO_BITRATE_BPS + FINAL_AUDIO_BITRATE_BPS) * seconds / 8)
            required = 12 * 1024**3 + math.ceil(output * 2 * 1.25)
            if stage == 'ffmpeg' and self._static_capacity is not None:
                measured = self._static_capacity
                required = verify_static_music_capacity_measurement(self.root, measured,
                    duration_ms=self._duration_ms(), image=Path(measured['execution']['inputs'][0]['path']),
                    audio=Path(measured['execution']['inputs'][1]['path']))
                basis = 'invocation-owned static codec measurement; linear working estimate (not maximum), faststart + 25%, plus 12GiB'
            same_volume = _volume_key(self.root) == _volume_key(Path(tempfile.gettempdir()))
            return {'required_ram_bytes':1536 * 1024**2,
                'ram_basis':'existing stable V7 minimum; serial instrumental mux, not a voice model',
                'required_output_free_bytes':required,
                'required_temp_free_bytes':required if same_volume else MINIMUM_SEPARATE_TEMP_FREE_BYTES,
                'disk_basis':basis,
                'own_concurrency':1,'ffmpeg_threads':'unchanged; serial admission'}
        plan = _read(self.plan_path)
        estimate = _storage_estimate(plan)
        # Reuse the existing 512MiB AV floor. This is a minimum, NOT an
        # experimentally measured render peak. Model loading additionally uses
        # the conservative formula from prove_phase6_narration_units.capacity_check.
        ram = 512 * 1024**2
        ram_basis = "existing AV minimum 512MiB; not measured peak"
        if stage == "voice:model":
            model = (self.root / "models/kokoro/kokoro-v1.0.fp16.onnx").stat().st_size
            voices = (self.root / "models/kokoro/voices-v1.0.bin").stat().st_size
            if model <= 0 or voices <= 0:
                raise ValueError("model/voice-bank sizes unavailable")
            ram += model * 4 + voices
            ram_basis = "existing narration estimate: model*4 + voices + 256MiB runtime + 256MiB reserve"
        same_volume = _volume_key(self.root) == _volume_key(Path(tempfile.gettempdir()))
        return {
            "required_ram_bytes": ram, "ram_basis": ram_basis,
            "required_output_free_bytes": estimate["required_free_bytes"],
            "required_temp_free_bytes": estimate["required_free_bytes"] if same_volume else MINIMUM_SEPARATE_TEMP_FREE_BYTES,
            "disk_basis": estimate["estimate_version"] + "; full-plan working estimate + 5GiB on every admission",
            "own_concurrency": 1, "ffmpeg_threads": "unchanged; serial admission",
        }

    def _sample(self) -> dict[str, Any]:
        sample = self.probe(self.root)
        for key in ("available_ram_bytes", "total_ram_bytes", "output_free_bytes", "temp_free_bytes", "logical_cpus"):
            if type(sample[key]) is not int or sample[key] < (1 if key in ("total_ram_bytes", "logical_cpus") else 0):
                raise ValueError(f"invalid resource observation: {key}")
        if sample["available_ram_bytes"] > sample["total_ram_bytes"]:
            raise ValueError("available RAM exceeds total")
        load = sample["cpu_load_percent"]
        if type(load) not in (float, int) or not math.isfinite(load) or not 0 <= load <= 100:
            raise ValueError("CPU load unavailable")
        return sample

    @staticmethod
    def _shortages(sample, requirements):
        return [cause for field, required, cause in (
            ("available_ram_bytes", "required_ram_bytes", "RAM_BELOW_STAGE_REQUIREMENT"),
            ("output_free_bytes", "required_output_free_bytes", "OUTPUT_DISK_RESERVE"),
            ("temp_free_bytes", "required_temp_free_bytes", "TEMP_DISK_RESERVE"),
        ) if sample[field] < requirements[required]]

    def prepare(self, stage: str) -> dict[str, Any]:
        if not self._entered:
            raise RuntimeError("resource preparation requires its live serial scope")
        self._unpaused()
        observation: dict[str, Any] = {
            "version": ACTIVE_RESOURCE_VERSION, "stage": stage, "status": "RESOURCE_WAIT",
            "causes": [], "recovery_passes": 0, "released_idle_handles": 0,
            "next_check_seconds": RESOURCE_RECHECK_SECONDS,
        }
        self.observations.append(observation)
        try:
            requirements = self._requirements(stage)
            observation["requirements"] = requirements
            observation["before"] = self._sample()
            causes = self._shortages(observation["before"], requirements)
            if causes:
                observation["recovery_passes"] = 1
                observation["released_idle_handles"] = self.release_idle()
                self._unpaused()
                from .compile_cache_retention import collect_completed_caches
                observation["disposable_cache_retention"] = collect_completed_caches(self.root)
                observation["after"] = self._sample()
                causes = self._shortages(observation["after"], requirements)
            else:
                # Normal finalization also releases the previous completed
                # command's private capture. No cache of idle resources grows.
                observation["released_idle_handles"] = self.release_idle()
            self._unpaused()
            observation["causes"] = causes
        except ResourceWait as exc:
            observation["causes"] = exc.observation["causes"]
            observation["next_check_seconds"] = exc.observation["next_check_seconds"]
        except Exception as exc:
            observation["causes"] = [f"RESOURCE_STATE_UNAVAILABLE:{type(exc).__name__}:{exc}"]
        if observation["causes"]:
            raise ResourceWait(observation)
        observation.update(status="ADMITTED", next_check_seconds=None)
        return observation

    @contextmanager
    def task(self, stage: str):
        observation = self.prepare(stage)
        started = time.perf_counter()
        try:
            yield observation
        finally:
            observation["elapsed_seconds"] = time.perf_counter() - started
            try:
                observation["after_task"] = self._sample()
            except Exception as exc:
                observation["after_task_probe_error"] = type(exc).__name__
            # This observation does not abort an active task or approve a later
            # one: every next task obtains its own fresh admission measurement.

    def measure_static_music_capacity(self, image: Path, audio: Path, output_directory: Path) -> None:
        """Measure the exact static codec inside this invocation, never accept a PASS/cache.

        The sample retains immutable bytes and the existing execution witness.
        It is a working estimate with the existing contingency, not a quality
        result or a codec size guarantee. Short deliveries keep the old path.
        """
        if not self._entered or self._music_inputs is None:
            raise PermissionError('static capacity needs its live instrumental scope')
        if self._static_capacity is not None or self._capacity_probe_command is not None:
            raise PermissionError('capacity measurement already started; no duplicate')
        self._unpaused()
        if self._duration_ms() <= 30000:
            return
        image, audio, directory = image.resolve(), audio.resolve(), output_directory.resolve()
        if (not directory.is_relative_to(self.root) or not image.is_relative_to(self.root)
                or not audio.is_relative_to(self.root) or image == audio):
            raise PermissionError('static capacity inputs/output escaped the invocation root')
        from .render_phase5 import _rest_render_command, _probe
        sample = directory / 'capacity' / ('static-capacity-' + uuid.uuid4().hex + '.mp4')
        command = _rest_render_command(image, audio, sample, 30000)
        self._capacity_probe_command = command
        try:
            # Two final observations before creating/running this bounded sample.
            requirements = self._requirements('ffmpeg:static-capacity')
            observations = [self._sample()]
            time.sleep(0.8)
            observations.append(self._sample())
            if any(self._shortages(s, requirements) for s in observations):
                raise ResourceWait({'causes':['STATIC_CAPACITY_SAMPLE_RESOURCES'],
                    'samples':observations,'requirements':requirements,'next_check_seconds':60})
            self._unpaused()
            sample.parent.mkdir(parents=True, exist_ok=True)
            self.run_ffmpeg(command, witness_output=sample, witness_inputs=(image, audio))
            execution = self.observations[-1]['execution']
            measured = {'version':'phase6-static-music-capacity-v1',
                'duration_ms':30000,'execution':execution,'probe':_probe(sample),
                'quality_approval':False,'estimate_is_maximum':False}
            verify_static_music_capacity_measurement(self.root, measured,
                duration_ms=self._duration_ms(), image=image, audio=audio)
            self.observations[-1]['static_capacity_measurement'] = measured
            self._static_capacity = measured
        finally:
            self._capacity_probe_command = None

    def run_ffmpeg(self, command: list[str], *, witness_output: Path | None = None,
                   witness_inputs: tuple[Path, ...] = ()) -> None:
        stage = ('ffmpeg:static-capacity' if self._capacity_probe_command is not None
                 and command == self._capacity_probe_command else 'ffmpeg')
        if stage == 'ffmpeg' and self._static_capacity is not None:
            from .render_phase5 import _rest_render_command
            inputs = self._static_capacity['execution']['inputs']
            image, audio = (Path(bound['path']) for bound in inputs)
            if (witness_output is None or tuple(p.resolve() for p in witness_inputs) != (image,audio)
                    or command != _rest_render_command(image,audio,witness_output,self._duration_ms())):
                raise PermissionError('measured static capacity cannot authorize a different final argv')
        with self.task(stage) as observation:
            # Serialize our heavy calls without changing the hash-bound codec,
            # filter/thread parameters, quality profile or existing cache recipe.
            timeout = 180 if stage == 'ffmpeg:static-capacity' else max(60, self._duration_ms() / 1000 * 120)
            execution = None
            if witness_output is not None:
                # Forward observation of this invocation, never reconstructed
                # from a recipe label or attached to a historical cache hit.
                if (not command or any(type(arg) is not str for arg in command)
                        or not Path(command[0]).is_absolute()):
                    raise ValueError("execution witness requires exact absolute executable argv")
                command = list(command)  # Do not run a caller-mutated argv after capturing it.
                output = witness_output.resolve()
                if not output.is_relative_to(self.root) or Path(command[-1]).resolve() != output:
                    raise ValueError("execution witness output differs from confined argv output")
                inputs = tuple(p.resolve() for p in witness_inputs)
                if (not inputs or len(set(inputs)) != len(inputs) or output in inputs
                        or any(not p.is_relative_to(self.root) for p in inputs)):
                    raise ValueError("execution witness requires distinct confined input files")
                verify_observed_ffmpeg_file_inputs(self.root, command, inputs)
                executable = Path(command[0]).resolve()
                def binding(path):
                    return {"path": str(path), "size_bytes": path.stat().st_size,
                            "sha256": _sha256(path)}
                execution = {
                    "version": "phase6-observed-ffmpeg-execution-v1", "status": "STARTING",
                    "argv": list(command), "cwd": str(self.root),
                    "executable": binding(executable), "inputs": [binding(p) for p in inputs],
                    "started_at": _stamp(), "exit_code": None,
                    "output": None, "quality_approval": False,
                    "scope": "OBSERVED_COMMAND_AND_DECLARED_FILE_BINDINGS_NOT_VISUAL_QUALITY",
                }
                observation["execution"] = execution
            # Created here, privately held and delete-on-close: not a user path,
            # reusable asset, receipt, failed render or application cache.
            with tempfile.TemporaryFile(dir=self.root, prefix="phase6-capture-") as stdout:
                stderr = tempfile.TemporaryFile(dir=self.root, prefix="phase6-capture-")
                try:
                    result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stdout,
                                            stderr=stderr, timeout=timeout, check=False,
                                            **({"cwd": self.root} if execution is not None else {}))
                    if execution is not None:
                        execution["exit_code"] = result.returncode
                    if result.returncode or "-n" in command:
                        stderr.seek(0, os.SEEK_END)
                        stderr.seek(max(0, stderr.tell() - 65536))
                        diagnostic = stderr.read().decode("utf-8", "replace")
                        # The pinned Windows FFmpeg can return 0 when -n refuses
                        # an existing output. Never witness that foreign file as
                        # newly produced solely because the process exited 0.
                        collision = ("-n" in command and
                                     f"File '{command[-1]}' already exists. Exiting." in diagnostic)
                        if result.returncode or collision:
                            raise RuntimeError(diagnostic)
                    if execution is not None:
                        if (binding(executable) != execution["executable"]
                                or [binding(p) for p in inputs] != execution["inputs"]):
                            raise PermissionError("FFmpeg executable/input changed during observed execution")
                        execution["output"] = binding(output)
                        if execution["output"]["size_bytes"] <= 0:
                            raise ValueError("FFmpeg produced no nonempty witnessed output")
                        execution["status"] = "COMPLETED"
                    self._idle_captures.append(stderr)
                except BaseException as exc:
                    if execution is not None:
                        execution["status"] = "FAILED"
                        execution["error_type"] = type(exc).__name__
                    raise
                finally:
                    try:
                        if execution is not None:
                            execution["finished_at"] = _stamp()
                            for name, stream in (("stdout", stdout), ("stderr", stderr)):
                                stream.flush()
                                stream.seek(0)
                                digest, size = hashlib.sha256(), 0
                                for block in iter(lambda: stream.read(1024 * 1024), b""):
                                    digest.update(block)
                                    size += len(block)
                                execution[name] = {"size_bytes": size, "sha256": "sha256:" + digest.hexdigest()}
                    except BaseException as exc:
                        if execution is not None:
                            execution.update(status="FAILED", error_type=type(exc).__name__)
                        if stderr in self._idle_captures:
                            self._idle_captures.remove(stderr)
                        raise
                    finally:
                        if stderr not in self._idle_captures:
                            stderr.close()


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _read_with_sha256(path: Path) -> tuple[dict[str, Any], str]:
    payload = path.read_bytes()
    value = json.loads(payload.decode("utf-8-sig"))
    return value, "sha256:" + hashlib.sha256(payload).hexdigest()


def _capacity_identity_payload(value: dict[str, Any]) -> str:
    content = dict(value)
    content.pop("receipt_id", None)
    return json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _failed_espeak_evidence(attempts: list[dict[str, Any]], error: str) -> dict[str, Any]:
    return {
        "status": "FAIL",
        "selected_candidate": None,
        "library_path": None,
        "data_path": None,
        "library_hash": None,
        "data_hash": None,
        "version": None,
        "loader_package_version": None,
        "fallback_used": None,
        "directory_dlls": [],
        "candidate_attempts": attempts,
        "error": error,
        "technical_cost_brl": 0,
    }


def verify_phase6_capacity_receipt(
    root: Path = ROOT,
    *,
    receipt_path: str | Path,
    expected_receipt_id: str | None = None,
    expected_sha256: str | None = None,
    require_pass: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    raw = Path(receipt_path)
    path = (raw if raw.is_absolute() else root / raw).resolve()
    if path.parent != (root / RECEIPTS).resolve() or not path.is_file():
        raise PermissionError("capacity receipt is outside its immutable directory or missing")
    value = _read(path)
    schema = _read(root / "schemas/phase6_local_capacity_preflight.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    expected_id = "capacity-phase6-" + hashlib.sha256(_capacity_identity_payload(value).encode("utf-8")).hexdigest()[:24]
    if value["receipt_id"] != expected_id or path.name != f"{expected_id}.json":
        raise PermissionError("capacity receipt identity does not match its measurements and checks")
    if expected_receipt_id is not None and value["receipt_id"] != expected_receipt_id:
        raise PermissionError("capacity receipt id differs from its checkpoint")
    observed_hash = _sha256(path)
    if expected_sha256 is not None and observed_hash != expected_sha256:
        raise PermissionError("capacity receipt hash differs from its checkpoint")
    if require_pass and value["status"] != "PASS":
        raise PermissionError("capacity receipt is not PASS")
    plan_binding_version = value.get("plan_binding_version")
    if require_pass and plan_binding_version != PLAN_BINDING_VERSION:
        raise PermissionError(
            "legacy capacity receipt lacks an exact TakePlan SHA-256 binding and is not reusable"
        )
    if plan_binding_version == PLAN_BINDING_VERSION:
        binding_checks = [
            item for item in value["checks"]
            if item["check_id"] == "CAP-TAKE-PLAN-BINDING"
        ]
        if len(binding_checks) != 1:
            raise PermissionError("capacity receipt lacks one exact TakePlan binding check")
        if value["scope"] == "PRODUCTION_PLAN":
            recorded_plan_path = Path(str(value.get("plan_path") or ""))
            if not recorded_plan_path.is_absolute():
                recorded_plan_path = root / recorded_plan_path
            recorded_plan_path = recorded_plan_path.resolve()
            if value.get("plan_path") != _relative(root, recorded_plan_path):
                raise PermissionError("capacity TakePlan path is not canonical")
            if not recorded_plan_path.is_file():
                raise PermissionError("capacity TakePlan is missing")
            recorded_plan_sha256 = str(value.get("plan_sha256") or "")
            if _sha256(recorded_plan_path) != recorded_plan_sha256:
                raise PermissionError("capacity TakePlan SHA-256 changed")
            try:
                current_plan = _read(recorded_plan_path)
            except Exception as exc:
                raise PermissionError(f"capacity TakePlan is unreadable: {type(exc).__name__}") from exc
            if current_plan.get("take_plan_id") != value.get("plan_id"):
                raise PermissionError("capacity TakePlan ID diverges from its bound bytes")
            if binding_checks[0]["status"] != "PASS":
                raise PermissionError("capacity TakePlan binding check is not PASS")
            if value["status"] == "PASS":
                try:
                    current_estimate = _storage_estimate(current_plan)
                except Exception as exc:
                    raise PermissionError(f"capacity TakePlan no longer supports its estimate: {exc}") from exc
                if (
                    current_estimate["duration_ms"] != value.get("duration_ms")
                    or current_estimate["take_count"] != value.get("take_count")
                ):
                    raise PermissionError("capacity TakePlan estimate metadata diverges from its bound bytes")
                if current_estimate["estimate_version"] != ESTIMATE_VERSION:
                    for field in ("estimate_version", "estimated_peak_new_bytes", "safety_reserve_bytes", "required_free_bytes"):
                        if value.get(field) != current_estimate[field]:
                            raise PermissionError("capacity forward render profile estimate diverges")
                    if value.get("storage_components") != current_estimate["components"]:
                        raise PermissionError("capacity forward storage components diverge")
        elif value.get("plan_sha256") is not None or binding_checks[0]["status"] != "WAITING":
            raise PermissionError("infrastructure-only capacity receipt has a contradictory TakePlan binding")
    failed = sorted(item["check_id"] for item in value["checks"] if item["status"] == "FAIL")
    if failed != sorted(value["blocking_reasons"]):
        raise PermissionError("capacity blocking reasons do not match its checks")
    for record in value["required_files"]:
        path_value = Path(record["path"])
        path_value = path_value if path_value.is_absolute() else root / path_value
        observed = record.get("observed_content_hash")
        if record["status"] == "PASS" and (not path_value.is_file() or (observed and _sha256(path_value) != observed)):
            raise PermissionError(f"capacity-required file changed: {record['file_id']}")
    if value["schema_version"] == "1.1.0":
        espeak = value["espeak"]
        if espeak["status"] == "PASS":
            library_path = Path(espeak["library_path"])
            data_path = Path(espeak["data_path"])
            if not library_path.is_absolute():
                library_path = root / library_path
            if not data_path.is_absolute():
                data_path = root / data_path
            library_path, data_path = library_path.resolve(), data_path.resolve()
            library_record = next((item for item in value["required_files"] if item["file_id"] == "espeak-library"), None)
            if library_record is None:
                raise PermissionError("capacity eSpeak library is not bound as a required file")
            recorded_library_path = Path(library_record["path"])
            if not recorded_library_path.is_absolute():
                recorded_library_path = root / recorded_library_path
            if recorded_library_path.resolve() != library_path:
                raise PermissionError("capacity eSpeak library required-file path diverges")
            if espeak["library_hash"] != _sha256(library_path):
                raise PermissionError("capacity eSpeak library hash changed")
            current_dlls = inventory_local_espeak_dlls(library_path)
            if current_dlls != espeak["directory_dlls"]:
                raise PermissionError("capacity eSpeak DLL directory inventory changed")
            required_hashes = {
                (Path(item["path"]).resolve(), item["observed_content_hash"])
                for item in value["required_files"]
                if item["file_id"] == "espeak-library" or item["file_id"].startswith("espeak-directory-dll-")
            }
            inventory_hashes = {(Path(item["path"]).resolve(), item["content_hash"]) for item in current_dlls}
            if required_hashes != inventory_hashes:
                raise PermissionError("capacity eSpeak DLL inventory is not fully bound as required files")
            for marker in ESPEAK_DATA_MARKERS:
                marker_path = data_path / marker
                if not marker_path.is_file() or marker_path.stat().st_size <= 0:
                    raise PermissionError(f"capacity eSpeak data marker is missing or empty: {marker}")
            if espeak["data_hash"] != hash_local_espeak_data(data_path):
                raise PermissionError("capacity eSpeak data hash changed")
            selected_attempts = [
                item for item in espeak["candidate_attempts"]
                if item["candidate_id"] == espeak["selected_candidate"] and item["status"] == "PASS"
            ]
            if len(selected_attempts) != 1:
                raise PermissionError("capacity eSpeak selected candidate lacks one exact PASS attempt")
        elif "CAP-ESPEAK" not in value["blocking_reasons"]:
            raise PermissionError("capacity eSpeak failure did not block the receipt")
    return value


def _volume_key(path: Path) -> str:
    resolved = path.resolve()
    return (resolved.drive or resolved.anchor or str(resolved)).casefold()


def _tool_check(
    tool_id: str,
    executable: str | Path,
    command_runner: Callable[..., Any],
) -> dict[str, Any]:
    path = Path(executable).resolve()
    version: str | None = None
    error: str | None = None
    status = "FAIL"
    if not path.is_file():
        error = "EXECUTABLE_NOT_FOUND"
    else:
        try:
            result = command_runner(
                [str(path), "-version"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=15,
            )
            output = str(getattr(result, "stdout", "") or "")
            version = output.splitlines()[0].strip() if output.splitlines() else None
            if int(getattr(result, "returncode", 1)) == 0 and version:
                status = "PASS"
            else:
                error = f"VERSION_COMMAND_EXIT_{getattr(result, 'returncode', 'UNKNOWN')}"
        except Exception as exc:  # evidence is serialized; the caller remains fail-closed
            error = f"{type(exc).__name__}:{exc}"
    return {
        "tool_id": tool_id,
        "path": str(path),
        "status": status,
        "version": version,
        "error": error,
        "technical_cost_brl": 0,
    }


def _writable_check(role: str, path: Path) -> dict[str, Any]:
    status, error = "FAIL", None
    probe: Path | None = None
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / f".capacity-probe-{os.getpid()}-{uuid.uuid4().hex}.tmp"
        probe.write_bytes(b"heroverse-capacity-probe")
        if probe.read_bytes() != b"heroverse-capacity-probe":
            raise OSError("writability probe content mismatch")
        status = "PASS"
    except Exception as exc:
        error = f"{type(exc).__name__}:{exc}"
    finally:
        if probe is not None:
            try:
                probe.unlink(missing_ok=True)
            except OSError:
                pass
    return {"role": role, "path": str(path.resolve()), "status": status, "error": error}


def _file_check(
    file_id: str,
    path: Path,
    *,
    expected_content_hash: str | None = None,
    rights_status: str | None = None,
    rights_evidence_ref: str | None = None,
) -> dict[str, Any]:
    exists = path.is_file()
    observed_hash: str | None = None
    error: str | None = None
    readable = False
    size = path.stat().st_size if exists else None
    if exists and size and size > 0:
        try:
            if expected_content_hash:
                observed_hash = _sha256(path)
            else:
                with path.open("rb") as stream:
                    readable = bool(stream.read(1))
            readable = True
        except Exception as exc:
            error = f"{type(exc).__name__}:{exc}"
    hash_matches = expected_content_hash is None or observed_hash == expected_content_hash
    passed = bool(exists and size and size > 0 and readable and hash_matches)
    if expected_content_hash and observed_hash and not hash_matches:
        error = "CONTENT_HASH_MISMATCH"
    return {
        "file_id": file_id,
        "path": str(path.resolve()),
        "status": "PASS" if passed else "FAIL",
        "size_bytes": size,
        "readable": readable,
        "expected_content_hash": expected_content_hash,
        "observed_content_hash": observed_hash,
        "rights_status": rights_status,
        "rights_evidence_ref": rights_evidence_ref,
        "error": error,
    }


def _component(name: str, bits_per_second: int, duration_seconds: float, multiplier: float, basis: str) -> dict[str, Any]:
    return {
        "component": name,
        "estimated_bytes": math.ceil(bits_per_second * duration_seconds / 8 * multiplier),
        "basis": basis,
    }


def _storage_estimate(plan: dict[str, Any]) -> dict[str, Any]:
    from .phase6_render_contract import plan_renderer, PALETTE_QP1_SEGMENT_RENDERER
    palette = plan_renderer(plan) == PALETTE_QP1_SEGMENT_RENDERER
    takes = plan.get("takes") or []
    if not takes:
        raise ValueError("take plan has no takes")
    cursor = 0
    for take in takes:
        start, end = int(take["start_ms"]), int(take["end_ms"])
        if start != cursor or end <= start:
            raise ValueError(f"take timeline is not contiguous at {take.get('take_id')}")
        if (end - start) * 30 % 1000 != 0:
            raise ValueError(f"take duration is not frame-exact at 30 fps: {take.get('take_id')}")
        cursor = end
    duration_ms = cursor
    duration_seconds = duration_ms / 1000
    components = [
        _component(
            "intermediate_video_segments",
            INTERMEDIATE_VIDEO_BITRATE_BPS,
            duration_seconds,
            1,
            "60 Mb/s conservative upper working estimate for CRF 18 1080p intermediates",
        ),
        _component(
            "silent_concatenated_video",
            INTERMEDIATE_VIDEO_BITRATE_BPS,
            duration_seconds,
            1,
            "second simultaneous copy of intermediate video during concat",
        ),
        _component(
            "final_muxed_output",
            FINAL_VIDEO_BITRATE_BPS + FINAL_AUDIO_BITRATE_BPS,
            duration_seconds,
            1,
            "configured 12 Mb/s video ceiling plus 256 kb/s AAC",
        ),
        _component(
            "processed_take_audio_and_concat",
            PCM_STEREO_48K_16_BIT_BPS,
            duration_seconds,
            2,
            "48 kHz stereo PCM16 take files plus concatenated narration",
        ),
        _component(
            "sfx_and_original_music",
            PCM_STEREO_48K_16_BIT_BPS,
            duration_seconds + 1,
            2,
            "two 48 kHz stereo PCM16 full-timeline beds; SFX includes one-second tail",
        ),
        _component(
            "raw_voice_takes",
            RAW_VOICE_24K_MONO_16_BIT_BPS,
            duration_seconds,
            1,
            "24 kHz mono PCM16 worst case across the full timeline",
        ),
        {
            "component": "thumbnails_and_metadata",
            "estimated_bytes": 3 * 2_097_152 + 64 * 1024**2,
            "basis": "three 2 MiB thumbnail ceilings plus 64 MiB for manifests, captions and concat lists",
        },
    ]
    if palette:
        # Forward mux reads the original concat list and stream-copies video.
        # It neither stores a redundant silent copy nor assumes the old 12Mb/s
        # lossy ceiling. No reduction in frame count, resolution or colour gate.
        components[:3] = [
            _component("intermediate_video_segments", PALETTE_MEASURED_VIDEO_BITRATE_BPS,
                       duration_seconds, 1,
                       "QP1 measured 27058021B/2600ms control; working estimate, not a maximum"),
            _component("final_muxed_output", PALETTE_MEASURED_VIDEO_BITRATE_BPS + FINAL_AUDIO_BITRATE_BPS,
                       duration_seconds, 1,
                       "same encoded video copied directly from concat; 256kb/s AAC"),
        ]
    subtotal = sum(item["estimated_bytes"] for item in components)
    contingency = math.ceil(subtotal * 0.25)
    components.append({
        "component": "filesystem_and_encoder_contingency",
        "estimated_bytes": contingency,
        "basis": "25% uncertainty margin for content-dependent CRF output and atomic writes",
    })
    return {
        "estimate_version": PALETTE_ESTIMATE_VERSION if palette else ESTIMATE_VERSION,
        "duration_ms": duration_ms,
        "take_count": len(takes),
        "components": components,
        "estimated_peak_new_bytes": subtotal + contingency,
        "safety_reserve_bytes": MINIMUM_POST_RENDER_HEADROOM_BYTES,
        "required_free_bytes": subtotal + contingency + MINIMUM_POST_RENDER_HEADROOM_BYTES,
    }


def run_phase6_capacity_preflight(
    root: Path = ROOT,
    *,
    plan_path: Path | None = None,
    now: datetime | None = None,
    disk_usage_provider: Callable[[str | os.PathLike[str]], Any] = shutil.disk_usage,
    command_runner: Callable[..., Any] = subprocess.run,
    ffmpeg_path: str | Path = FFMPEG,
    ffprobe_path: str | Path = FFPROBE,
    font_provider: Callable[[], Path] = _font,
    espeak_probe: Callable[[], LocalEspeakBinding] = resolve_local_espeak_binding,
    require_asset_residency: bool = False,
    materialize_latest: bool = True,
) -> dict[str, Any]:
    # A proposal can receive an immutable capacity observation without replacing
    # the resident manager's operational view. It acquires no execution rights.
    if type(materialize_latest) is not bool:
        raise TypeError("materialize_latest must be an explicit boolean")
    root = root.resolve()
    timestamp = _stamp(now)
    resolved_plan = (plan_path or (root / BASE / "production/take_plan.json")).resolve()
    plan: dict[str, Any] | None = None
    plan_sha256: str | None = None
    if resolved_plan.is_file():
        plan, plan_sha256 = _read_with_sha256(resolved_plan)
    scope = "PRODUCTION_PLAN" if plan is not None else "INFRASTRUCTURE_ONLY"

    tools = [
        _tool_check("ffmpeg-local", ffmpeg_path, command_runner),
        _tool_check("ffprobe-local", ffprobe_path, command_runner),
    ]
    try:
        font_path = font_provider().resolve()
    except Exception:
        font_path = root / "__missing_required_font__"
    espeak_binding: LocalEspeakBinding | None = None
    espeak_files: list[dict[str, Any]] = []
    try:
        espeak_binding = espeak_probe()
        espeak = espeak_binding.capacity_evidence()
        for index, dll in enumerate(espeak_binding.directory_dlls, start=1):
            dll_path = Path(dll["path"]).resolve()
            file_id = "espeak-library" if dll_path == espeak_binding.library_path else f"espeak-directory-dll-{index:02d}"
            espeak_files.append(_file_check(
                file_id,
                dll_path,
                expected_content_hash=dll["content_hash"],
            ))
        if not espeak_files or any(item["status"] != "PASS" for item in espeak_files):
            espeak = _failed_espeak_evidence(
                espeak_binding.candidate_attempts,
                "SELECTED_DLL_DIRECTORY_RECHECK_FAILED",
            )
            espeak_files = []
    except LocalEspeakUnavailableError as exc:
        espeak = _failed_espeak_evidence(exc.attempts, "NO_VERIFIED_LOCAL_ESPEAK_CANDIDATE")
    except Exception as exc:
        espeak = _failed_espeak_evidence(
            [{
                "candidate_id": "LOCAL_ESPEAK_PROBE",
                "priority": 0,
                "library_path": None,
                "data_path": None,
                "status": "FAIL",
                "error_code": "UNEXPECTED_PROBE_FAILURE",
                "error_type": type(exc).__name__,
            }],
            "LOCAL_ESPEAK_PROBE_FAILED",
        )
    finally:
        if espeak_binding is not None:
            espeak_binding.close()
    files = [
        _file_check("kokoro-model", root / "models/kokoro/kokoro-v1.0.fp16.onnx"),
        _file_check("kokoro-voices", root / "models/kokoro/voices-v1.0.bin"),
        _file_check("render-font", font_path),
    ]
    files.extend(espeak_files)
    source_span_errors: list[str] = []
    allocation_errors: list[str] = []
    residency_evidence: list[str] = []
    residency_status = "WAITING"
    if plan is not None:
        allocation_path = root / BASE / "production/asset_allocation.json"
        allocation: dict[str, Any] | None = None
        try:
            allocation = _read(allocation_path)
            allocation_by_take = {item["take_id"]: item for item in allocation.get("takes") or []}
        except Exception as exc:
            allocation_by_take = {}
            allocation_errors.append(f"allocation:{type(exc).__name__}:{exc}")
        seen_sources: dict[Path, dict[str, Any]] = {}
        for take in plan.get("takes") or []:
            try:
                origin, span = str(take["asset_origin"]).rsplit("#t=", 1)
                source_start, source_end = (float(value) for value in span.split(",", 1))
                source = Path(origin)
                if not source.is_absolute():
                    source = root / source
                source = source.resolve()
                timeline_seconds = (int(take["end_ms"]) - int(take["start_ms"])) / 1000
                if source_start < 0 or source_end <= source_start or source_end - source_start + 0.002 < timeline_seconds:
                    raise ValueError("source span is shorter than the timeline slot")
                allocation_item = allocation_by_take.get(take.get("take_id"))
                if not allocation_item:
                    raise ValueError("take is absent from the asset-allocation ledger")
                allocation_source = Path(str(allocation_item["source_path"]))
                if not allocation_source.is_absolute():
                    allocation_source = root / allocation_source
                if allocation_source.resolve() != source:
                    raise ValueError("take source diverges from the asset-allocation ledger")
                if abs(int(allocation_item["source_start_ms"]) / 1000 - source_start) > 0.001 or abs(int(allocation_item["source_end_ms"]) / 1000 - source_end) > 0.001:
                    raise ValueError("take span diverges from the asset-allocation ledger")
                if int(allocation_item["duration_ms"]) != int(take["end_ms"]) - int(take["start_ms"]):
                    raise ValueError("take duration diverges from the asset-allocation ledger")
                if allocation_item.get("rights_status") not in {"OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"}:
                    raise ValueError("take rights status is not production eligible")
                existing = seen_sources.get(source)
                if existing and existing["expected_content_hash"] != allocation_item["content_hash"]:
                    raise ValueError("one source has conflicting hashes in the asset-allocation ledger")
                seen_sources.setdefault(source, {
                    "file_id": f"source-{len(seen_sources) + 1:03d}",
                    "expected_content_hash": allocation_item["content_hash"],
                    "rights_status": allocation_item["rights_status"],
                    "rights_evidence_ref": allocation_item["rights_evidence_ref"],
                })
            except Exception as exc:
                source_span_errors.append(f"{take.get('take_id')}:{type(exc).__name__}:{exc}")
        files.extend(
            _file_check(
                record["file_id"],
                path,
                expected_content_hash=record["expected_content_hash"],
                rights_status=record["rights_status"],
                rights_evidence_ref=record["rights_evidence_ref"],
            )
            for path, record in seen_sources.items()
        )
        if require_asset_residency:
            try:
                input_receipt_path = root / "output/operations/phase6/release/latest-production-inputs-receipt.json"
                input_receipt = verify_production_inputs_receipt(
                    root,
                    receipt_path=input_receipt_path,
                    required_action="PREPARE_VIDEO_2_INPUTS",
                    ensure_immutable=True,
                    recheck_decode=False,
                )
                binding = input_receipt["asset_residency"]
                identity = verify_phase6_asset_residency(
                    root,
                    receipt_path=binding["receipt_path"],
                    expected_sha256=binding["sha256"],
                    expected_audit_id=binding["audit_id"],
                    required_asset_ids=[item["asset_id"] for item in (allocation or {}).get("takes") or []],
                    recheck_media=True,
                    recheck_decode=True,
                    command_runner=command_runner,
                )
                residency_status = "PASS"
                immutable_input = root / PRODUCTION_INPUT_RECEIPTS / f"{input_receipt['receipt_id']}.json"
                residency_evidence = [
                    f"production_input_id={input_receipt['receipt_id']}",
                    f"production_input_path={_relative(root, immutable_input)}",
                    f"production_input_sha256={_sha256(immutable_input)}",
                    identity["receipt_path"], identity["sha256"],
                    f"verified_assets={len(identity['verified_asset_ids'])}",
                ]
            except Exception as exc:
                residency_status = "FAIL"
                residency_evidence = [f"{type(exc).__name__}:{exc}"]
                allocation_errors.append(f"asset-residency:{type(exc).__name__}:{exc}")
    output_dir = root / BASE / "render-work"
    temp_dir = Path(tempfile.gettempdir()).resolve()
    writable_paths = [
        _writable_check("production_output", output_dir),
        _writable_check("system_temp", temp_dir),
    ]

    estimate: dict[str, Any] | None = None
    estimate_error: str | None = None
    if plan is not None:
        try:
            estimate = _storage_estimate(plan)
        except Exception as exc:
            estimate_error = f"{type(exc).__name__}:{exc}"

    output_required = estimate["required_free_bytes"] if estimate else MINIMUM_POST_RENDER_HEADROOM_BYTES
    same_volume = _volume_key(output_dir) == _volume_key(temp_dir)
    temp_required = output_required if same_volume else MINIMUM_SEPARATE_TEMP_FREE_BYTES
    volumes = []
    for role, path, required in (
        ("production_output", output_dir, output_required),
        ("system_temp", temp_dir, temp_required),
    ):
        try:
            usage = disk_usage_provider(path)
            free = int(usage.free)
            volumes.append({
                "role": role,
                "path": str(path),
                "volume_key": _volume_key(path),
                "total_bytes": int(usage.total),
                "free_bytes": free,
                "required_free_bytes": int(required),
                "headroom_bytes": free - int(required),
                "status": "PASS" if free >= required else "FAIL",
            })
        except Exception as exc:
            volumes.append({
                "role": role,
                "path": str(path),
                "volume_key": _volume_key(path),
                "total_bytes": 0,
                "free_bytes": 0,
                "required_free_bytes": int(required),
                "headroom_bytes": -int(required),
                "status": "FAIL",
                "error": f"{type(exc).__name__}:{exc}",
            })

    checks = [
        {
            "check_id": "CAP-TOOLS",
            "status": "PASS" if all(item["status"] == "PASS" for item in tools) else "FAIL",
            "evidence": [f"{item['tool_id']}:{item['status']}:{item['version'] or item['error']}" for item in tools],
        },
        {
            "check_id": "CAP-ESPEAK",
            "status": espeak["status"],
            "evidence": [
                f"selected={espeak['selected_candidate'] or 'NONE'}",
                f"version={espeak['version'] or 'UNAVAILABLE'}",
                f"fallback_used={espeak['fallback_used'] if espeak['fallback_used'] is not None else 'UNAVAILABLE'}",
                f"library_hash={espeak['library_hash'] or 'UNAVAILABLE'}",
                f"data_hash={espeak['data_hash'] or 'UNAVAILABLE'}",
                *[
                    f"candidate={item['priority']}:{item['candidate_id']}:{item['status']}:{item['error_code'] or 'VERIFIED'}"
                    for item in espeak["candidate_attempts"]
                ],
            ],
        },
        {
            "check_id": "CAP-REQUIRED-FILES",
            "status": "PASS" if all(item["status"] == "PASS" for item in files) else "FAIL",
            "evidence": [f"{item['file_id']}:{item['status']}:{item['size_bytes']}" for item in files],
        },
        {
            "check_id": "CAP-WRITABLE-PATHS",
            "status": "PASS" if all(item["status"] == "PASS" for item in writable_paths) else "FAIL",
            "evidence": [f"{item['role']}:{item['status']}:{item['path']}" for item in writable_paths],
        },
        {
            "check_id": "CAP-PRODUCTION-PLAN",
            "status": "PASS" if estimate and not source_span_errors and not allocation_errors else ("FAIL" if estimate_error or source_span_errors or allocation_errors else "WAITING"),
            "evidence": [
                f"plan={_relative(root, resolved_plan)}",
                f"allocation={_relative(root, root / BASE / 'production/asset_allocation.json')}",
                f"duration_ms={estimate['duration_ms']}" if estimate else (estimate_error or "plan_not_available"),
                *(allocation_errors + source_span_errors or [f"source_span_and_ledger_checks={len(plan.get('takes') or [])}" if plan else "source_span_and_ledger_checks=waiting"]),
            ],
        },
        {
            "check_id": "CAP-TAKE-PLAN-BINDING",
            "status": "PASS" if plan is not None else "WAITING",
            "evidence": [
                f"plan={_relative(root, resolved_plan)}",
                f"plan_sha256={plan_sha256}" if plan_sha256 else "plan_sha256=waiting",
            ],
        },
        {
            "check_id": "CAP-DISK-HEADROOM",
            "status": "PASS" if all(item["status"] == "PASS" for item in volumes) else "FAIL",
            "evidence": [f"{item['role']}:free={item['free_bytes']}:required={item['required_free_bytes']}:headroom={item['headroom_bytes']}" for item in volumes],
        },
    ]
    if require_asset_residency:
        checks.append({
            "check_id": "CAP-ASSET-RESIDENCY",
            "status": residency_status,
            "evidence": residency_evidence or ["asset-residency-binding-unavailable"],
        })
    failed = [item["check_id"] for item in checks if item["status"] == "FAIL"]
    status = "BLOCKED" if failed else ("PASS" if estimate else "WAITING_PLAN")
    value = {
        "schema_version": "1.1.0",
        "receipt_id": "capacity-phase6-pending",
        "phase": 6,
        "scope": scope,
        "status": status,
        "estimate_version": estimate["estimate_version"] if estimate else ESTIMATE_VERSION,
        "plan_binding_version": PLAN_BINDING_VERSION,
        "plan_path": _relative(root, resolved_plan) if plan else None,
        "plan_id": plan.get("take_plan_id") if plan else None,
        "plan_sha256": plan_sha256,
        "duration_ms": estimate["duration_ms"] if estimate else None,
        "take_count": estimate["take_count"] if estimate else None,
        "storage_components": estimate["components"] if estimate else [],
        "estimated_peak_new_bytes": estimate["estimated_peak_new_bytes"] if estimate else None,
        "safety_reserve_bytes": estimate["safety_reserve_bytes"] if estimate else MINIMUM_POST_RENDER_HEADROOM_BYTES,
        "required_free_bytes": estimate["required_free_bytes"] if estimate else None,
        "tools": tools,
        "espeak": espeak,
        "required_files": files,
        "writable_paths": writable_paths,
        "volumes": volumes,
        "checks": checks,
        "blocking_reasons": failed,
        "same_output_and_temp_volume": same_volume,
        "publication_authorized": False,
        "technical_cost_brl": 0,
        "created_at": timestamp,
    }
    if plan is not None and (not resolved_plan.is_file() or _sha256(resolved_plan) != plan_sha256):
        raise PermissionError("TakePlan changed while the capacity preflight was running")
    receipt_id = "capacity-phase6-" + hashlib.sha256(_capacity_identity_payload(value).encode("utf-8")).hexdigest()[:24]
    value["receipt_id"] = receipt_id
    schema = _read(root / "schemas/phase6_local_capacity_preflight.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    immutable = root / RECEIPTS / f"{receipt_id}.json"
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").replace("\n", os.linesep).encode("utf-8")
    if immutable.is_file() and immutable.read_bytes() != payload:
        raise PermissionError(f"immutable capacity receipt collision: {receipt_id}")
    if not immutable.is_file():
        immutable.parent.mkdir(parents=True, exist_ok=True)
        temporary = immutable.with_name(f".{immutable.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
        temporary.write_bytes(payload)
        try:
            try:
                os.link(temporary, immutable)
            except FileExistsError:
                if immutable.read_bytes() != payload:
                    raise PermissionError(f"immutable capacity receipt collision: {receipt_id}")
        finally:
            temporary.unlink(missing_ok=True)
    if materialize_latest:
        _write(root / LATEST, value)
        if (root / LATEST).read_bytes() != immutable.read_bytes():
            raise PermissionError("capacity latest diverged from its immutable receipt")
    verify_phase6_capacity_receipt(
        root,
        receipt_path=immutable,
        expected_receipt_id=receipt_id,
        expected_sha256=_sha256(immutable),
        require_pass=False,
    )
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_capacity_preflight(), ensure_ascii=False, indent=2))
