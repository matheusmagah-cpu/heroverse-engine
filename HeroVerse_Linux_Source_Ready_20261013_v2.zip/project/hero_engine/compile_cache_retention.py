"""Bounded retention of *explicitly sealed* disposable compilation caches.

T25's small increment, not a media garbage collector. Analysis sources, final
videos, frozen publication inputs and historical proof bytes remain mandatory.
Only the existing compilation launcher can create the completion manifest;
sealing its hash into an evidence index is a separate prerequisite. No age
heuristic, arbitrary removal path, background loop or automatic recompile.
"""
from __future__ import annotations

from contextlib import ExitStack, closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import threading
from datetime import datetime, timezone

RUNS = Path('output/runtime/gestor-central/maintenance-runs')
NAME = 'compile-cache-retention.json'
_SLOT = threading.Lock()


def _hash(raw):
    return hashlib.sha256(raw).hexdigest()


def _save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def _safe(root, path):
    if not path.is_absolute() or not path.is_relative_to(root):
        raise PermissionError('RETENTION_PATH_OUTSIDE_ROOT')
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise PermissionError('RETENTION_REPARSE_PATH')
        if item == root:
            break
    if path.resolve() != path:
        raise PermissionError('RETENTION_PATH_DIVERGED')


def _rows(root, cache):
    rows = []
    for directory, dirs, files in os.walk(cache, followlinks=False):
        _safe(root, Path(directory))
        for name in dirs:
            _safe(root, Path(directory) / name)
        for name in files:
            path = Path(directory) / name
            _safe(root, path)
            info = path.stat()
            if path.suffix != '.pyc' or info.st_nlink != 1:
                raise PermissionError('RETENTION_NOT_PRIVATE_BYTECODE')
            rows.append(dict(path=path.relative_to(cache).as_posix(), size=info.st_size,
                             identity=[info.st_dev, info.st_ino, info.st_mtime_ns],
                             sha256=_hash(path.read_bytes())))
            if len(rows) > 2048 or sum(row['size'] for row in rows) > 64 * 1024**2:
                raise PermissionError('RETENTION_BATCH_BOUND_EXCEEDED')
    return sorted(rows, key=lambda row: row['path'])


def record_completed_cache(root, run, process_result):
    """Called by the compiler owner after its child exits; never an approval.

    A failed/partial compilation cannot become disposable through this entry.
    Evidence sealing must later include this exact manifest while excluding the
    cache; no consumer may add a bytecode dependency to that sealed proof.
    """
    root, run = root.resolve(), run.resolve()
    _safe(root, run)
    if (run.parent != root / RUNS or type(process_result['exit_code']) is not int
            or process_result['exit_code'] != 0 or process_result['timed_out'] is not False
            or type(process_result['pid']) is not int or process_result['pid'] <= 0):
        raise PermissionError('RETENTION_COMPILE_NOT_COMPLETE')
    if process_result['command'] != 'compileall hero_engine tests; private compile-cache':
        raise PermissionError('RETENTION_COMPILE_RECIPE_UNKNOWN')
    # The caller records only its own just-finished compile child, not an
    # arbitrary historic PID or an asserted media job completion.
    value = dict(schema_version='1.0.0', kind='EXCLUDED_REPRODUCIBLE_BYTECODE',
                 created_at=datetime.now(timezone.utc).isoformat(), process=process_result,
                 files=_rows(root, run / 'compile-cache'))
    _save(run / NAME, value)
    return value


def _delete_exact(root, path, row):
    """Exclusive handle, exact identity, no path-based TOCTOU deletion."""
    from .maintenance_protocol import _PausedCancelPin
    _safe(root, path)
    with closing(_PausedCancelPin(path, deletable=True)) as pin:
        # The shared maintenance pin permits readers. Disposal of even an
        # excluded cache additionally requires NO open reader, including one
        # that opted into FILE_SHARE_DELETE. Reacquire with share=0 and recheck
        # the original identity/bytes; a replacement during the gap blocks.
        pin.close()
        handle = pin.kernel.CreateFileW(str(path), 0x80000000 | 0x10000, 0, None, 3, 0x200000, None)
        if handle == pin.ctypes.c_void_p(-1).value:
            raise PermissionError('RETENTION_FILE_IN_USE_OR_EXCLUSIVITY_UNAVAILABLE')
        pin.handle = handle
        pin.revalidate()
        info = path.stat()
        if ([info.st_dev, info.st_ino, info.st_mtime_ns] != row['identity'] or info.st_size != row['size']
                or info.st_nlink != 1 or _hash(pin.payload) != row['sha256']):
            raise PermissionError('RETENTION_FILE_REPLACED')
        if os.path.lexists(root / 'output/runtime/gestor-central/PAUSE'):
            raise PermissionError('OWNER_PAUSE')
        pin.remove()
    if path.exists():
        raise PermissionError('RETENTION_REMOVAL_UNCONFIRMED')


def collect_completed_caches(root):
    """One bounded pass in the existing heavy-work/completion entries.

    Missing manifests are unclassified, not garbage. Unknown/partial evidence
    is reported, never silently converted into disposal eligibility.
    """
    root = root.resolve()
    pause = root / 'output/runtime/gestor-central/PAUSE'
    if os.path.lexists(pause):
        return dict(status='OWNER_PAUSE', deleted_files=0)
    if os.name != 'nt' or not _SLOT.acquire(blocking=False):
        return dict(status='UNAVAILABLE_OR_BUSY', deleted_files=0)
    result = dict(status='BLOCKED_OR_PARTIAL', deleted_files=0, runs=[])
    try:
        before = shutil.disk_usage(root).free
        result = dict(status='COMPLETE', deleted_files=0, runs=[], before_free_bytes=before)
        parent = root / RUNS
        if not parent.exists():
            result['after_free_bytes'] = shutil.disk_usage(root).free
            return result
        _safe(root, parent)
        # Only direct maintenance records; no recursive machine/cache scan.
        runs = sorted(parent.iterdir())
        if len(runs) > 512:
            return dict(status='CATALOG_BOUND_EXCEEDED', deleted_files=0)
        admitted = 0
        for run in runs:
            if not run.is_dir() or not (run / NAME).is_file():
                continue
            if admitted == 2:
                break
            admitted += 1
            row_result = dict(run=run.name, status='BLOCKED')
            result['runs'].append(row_result)
            stack = ExitStack()
            try:
                from .maintenance_protocol import _PausedCancelPin, _paused_cancel_absent
                _safe(root, run / NAME)
                raw = stack.enter_context(closing(_PausedCancelPin(run / NAME))).payload
                descriptor = json.loads(raw)
                index_path = run / 'evidence-bindings.json'
                _safe(root, index_path)
                index = json.loads(stack.enter_context(closing(_PausedCancelPin(index_path))).payload)
                if index.get('excluded') != 'compile-cache (owned reproducible bytecode, retained)':
                    raise PermissionError('RETENTION_CACHE_NOT_EXCLUDED')
                refs = [item for item in index['files'] if item['path'] == NAME]
                if len(refs) != 1 or refs[0]['sha256'] != _hash(raw) or refs[0]['bytes'] != len(raw):
                    raise PermissionError('RETENTION_COMPLETION_NOT_SEALED')
                if any('compile-cache' in Path(item['path']).parts for item in index['files']):
                    raise PermissionError('RETENTION_ACTIVE_BYTE_DEPENDENCY')
                if (descriptor['schema_version'] != '1.0.0' or descriptor['kind'] != 'EXCLUDED_REPRODUCIBLE_BYTECODE'
                        or type(descriptor['process']['exit_code']) is not int or descriptor['process']['exit_code'] != 0
                        or descriptor['process']['timed_out'] is not False
                        or type(descriptor['process']['pid']) is not int or descriptor['process']['pid'] <= 0
                        or descriptor['process']['command'] != 'compileall hero_engine tests; private compile-cache'):
                    raise PermissionError('RETENTION_COMPLETION_INVALID')
                process_path = run / 'full-process-result.json'
                _safe(root, process_path)
                process_raw = stack.enter_context(closing(_PausedCancelPin(process_path))).payload
                process = json.loads(process_raw)
                process_refs = [item for item in index['files'] if item['path'] == process_path.name]
                if (len(process_refs) != 1 or process_refs[0]['sha256'] != _hash(process_raw)
                        or process_refs[0]['bytes'] != len(process_raw) or type(process['exit_code']) is not int
                        or process['exit_code'] != 0 or process['timed_out'] is not False
                        or type(process['test_pid']) is not int or process['test_pid'] <= 0):
                    raise PermissionError('RETENTION_REGRESSION_INCOMPLETE_OR_UNSEALED')
                _paused_cancel_absent(process['test_pid'], 'CACHE_REGRESSION_OWNER')
                _paused_cancel_absent(descriptor['process']['pid'], 'COMPILE_CACHE_OWNER')
                cache = run / 'compile-cache'
                terminal = run / 'compile-cache-discarded.json'
                if terminal.exists():
                    prior = json.loads(terminal.read_bytes())
                    if prior.get('manifest_sha256') != _hash(raw) or prior.get('state') != 'INTENTIONALLY_ABSENT_COMPILE_CACHE' or _rows(root, cache):
                        raise PermissionError('RETENTION_TOMBSTONE_DIVERGED_OR_REAPPEARED')
                    row_result['status'] = 'ALREADY_DISCARDED'
                    continue
                plan = run / 'compile-cache-discard-plan.json'
                if plan.exists():
                    raise PermissionError('RETENTION_INTERRUPTED_REQUIRES_RECONCILIATION')
                if _rows(root, cache) != descriptor['files'] or not descriptor['files']:
                    raise PermissionError('RETENTION_CACHE_CHANGED_OR_EMPTY')
                if os.path.lexists(pause):
                    raise PermissionError('OWNER_PAUSE')
                _save(plan, dict(state='PLANNED', manifest_sha256=_hash(raw), files=descriptor['files']))
                count = 0
                try:
                    for entry in descriptor['files']:
                        if os.path.lexists(pause) or (run / NAME).read_bytes() != raw:
                            raise PermissionError('RETENTION_PAUSED_OR_MANIFEST_CHANGED')
                        _delete_exact(root, cache / entry['path'], entry)
                        count += 1
                        result['deleted_files'] += 1
                    _save(terminal, dict(state='INTENTIONALLY_ABSENT_COMPILE_CACHE', manifest_sha256=_hash(raw),
                        deleted_files=count, media_deleted=False, recompile_required=False,
                        after_free_bytes=shutil.disk_usage(root).free))
                except Exception:
                    row_result['confirmed_deletions'] = count
                    raise
                row_result['status'] = 'DISCARDED'
            except Exception as exc:
                row_result['reason'] = type(exc).__name__ + ':' + str(exc)
                result['status'] = 'BLOCKED_OR_PARTIAL'
            finally:
                stack.close()
        result['after_free_bytes'] = shutil.disk_usage(root).free
        return result
    except Exception as exc:
        # A cleanup/probe failure must not rewrite a persisted COMPLETE analysis
        # as FAILED or repeat a public upload. The heavy entry still remeasures
        # and blocks its own admission if capacity has not been recovered.
        result.update(status='BLOCKED_OR_PARTIAL', reason=type(exc).__name__ + ':' + str(exc))
        return result
    finally:
        _SLOT.release()
