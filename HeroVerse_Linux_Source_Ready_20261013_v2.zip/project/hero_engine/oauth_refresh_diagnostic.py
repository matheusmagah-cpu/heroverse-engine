"""One-shot, redacted token-endpoint diagnosis; never replaces the OAuth proof.

No token, provider message, URL parameter, response body or exception text is
returned. This diagnostic cannot persist credentials, invoke YouTube, change the
monitor's retry schedule or claim channel identity/publication readiness.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import ssl
import stat
import time
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import build_opener, HTTPHandler, HTTPSHandler, HTTPRedirectHandler, Request

ENDPOINT = 'https://oauth2.googleapis.com/token'
ERROR_CODES = frozenset(('invalid_grant', 'invalid_client', 'unauthorized_client',
    'invalid_request', 'invalid_scope', 'access_denied', 'temporarily_unavailable',
    'server_error', 'internal_failure'))
EXCEPTION_NAMES = frozenset(('RefreshError', 'TransportError', 'ConnectionError',
    'Timeout', 'ReadTimeout', 'ConnectTimeout', 'SSLError', 'TimeoutError',
    'DiagnosticBoundaryError', 'ValueError', 'OSError'))
RESPONSE_LIMIT = 32768


class DiagnosticBoundaryError(ValueError):
    pass


def classify_failure(error):
    """Read only allowlisted scalar codes, never stringify arbitrary exceptions."""
    codes = set()
    # google-auth RefreshError's second argument is structured response data.
    for item in error.args:
        if type(item) is dict and type(item.get('error')) is str and item['error'] in ERROR_CODES:
            codes.add(item['error'])
    code = next(iter(codes)) if len(codes) == 1 else None
    name = type(error).__name__
    return {'exception_category': name if name in EXCEPTION_NAMES else 'OTHER_REDACTED',
        'oauth_error_code': code,
        'provider_retryable': getattr(error, 'retryable', None) if
            type(getattr(error, 'retryable', None)) is bool else None,
        'cause_precision': 'STRUCTURED_PROVIDER_ERROR' if code else 'NO_SPECIFIC_PROVIDER_CAUSE',
        'revocation_confirmed': False,
        'note': 'invalid_grant does not distinguish expiry, revocation, policy or other grant rejection.'}


def bounded_request(delegate, observations):
    def request(url, method='GET', body=None, headers=None, timeout=None, **kwargs):
        if url != ENDPOINT or method.upper() != 'POST' or observations['request_attempts'] != 0:
            raise DiagnosticBoundaryError('endpoint, method or one-request limit')
        if kwargs.get('allow_redirects') not in (None, False):
            raise DiagnosticBoundaryError('redirect not authorized')
        observations['request_attempts'] += 1
        response = delegate(url=url, method=method, body=body, headers=headers,
            timeout=30, allow_redirects=False)
        status = response.status
        observations['http_status'] = status if type(status) is int and 100 <= status <= 599 else None
        if type(status) is not int or 300 <= status < 400:
            raise DiagnosticBoundaryError('invalid HTTP status or redirect')
        return response
    return request


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _post_without_sdk_logging(*, url, method, body, headers, timeout, allow_redirects):
    # Private handlers force debuglevel=0 even if HTTPConnection has DEBUG set.
    # No google-auth request/response logger; response bytes remain in memory.
    opener = build_opener(HTTPHandler(debuglevel=0),
        HTTPSHandler(debuglevel=0, context=ssl.create_default_context()), _NoRedirect())
    request = Request(url, data=body, headers=headers or {}, method=method)
    try:
        response = opener.open(request, timeout=timeout)
    except HTTPError as error:
        response = error
    with response:
        raw = response.read(RESPONSE_LIMIT + 1)
        if len(raw) > RESPONSE_LIMIT:
            raise DiagnosticBoundaryError('token response too large')
        return SimpleNamespace(status=response.code, data=raw)


def evaluate_response(response):
    """Validate one official response; never emit its access token or text."""
    value = json.loads(response.data)
    if type(value) is not dict:
        raise DiagnosticBoundaryError('token response must be object')
    if response.status != 200:
        result = classify_failure(ValueError(value))
        result['provider_retryable'] = response.status in (429, 500, 502, 503, 504)
        return {'status': 'REFRESH_DIAGNOSED_NOT_RECOVERED', 'diagnosis': result}
    token, expires = value.get('access_token'), value.get('expires_in')
    if (type(token) is not str or not token.strip() or type(expires) is not int
            or not 0 < expires <= 86400 or value.get('token_type', '').lower() != 'bearer'):
        raise DiagnosticBoundaryError('malformed token success response')
    return {'status': 'TOKEN_REFRESH_SUCCEEDED_IN_MEMORY_ONLY', 'diagnosis': None}


def _resident_file(path, cap):
    path = Path(path).absolute()
    for item in (path, *path.parents):
        info = item.lstat()
        if (stat.S_ISLNK(info.st_mode) or item.is_junction()
                or getattr(info, 'st_file_attributes', 0) & (0x1000 | 0x40000 | 0x400000)):
            raise DiagnosticBoundaryError('linked or nonresident input')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or not 0 < info.st_size <= cap:
        raise DiagnosticBoundaryError('input shape')
    with path.open('rb') as stream:
        raw = stream.read(cap + 1)
    after = path.stat()
    if (len(raw) != info.st_size or len(raw) > cap or
        (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) !=
        (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)):
        raise DiagnosticBoundaryError('input changed')
    return raw


def _write_new(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2) + '\n').encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())


def diagnose(root, token_path, *, expected_token_sha256, expected_failure_sha256, output_name):
    """Explicit manual incident diagnosis, separate from scheduled retries.

    The existing failed receipt and token must be unchanged. This entry point
    is deliberately not a resident-manager fallback and never repairs its state.
    """
    from .youtube_integration import INTEGRATION_SCOPES
    root = Path(root).absolute()
    token_path = Path(token_path).absolute()
    if token_path.is_relative_to(root) or not output_name.isascii() or not output_name.replace('-', '').isalnum():
        raise DiagnosticBoundaryError('token must be external and output name simple')
    failed = root / 'output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json'
    fail_raw = _resident_file(failed, 16384)
    token_raw = _resident_file(token_path, 65536)
    digest = lambda raw: hashlib.sha256(raw).hexdigest()
    fail = json.loads(fail_raw)
    if (digest(fail_raw) != expected_failure_sha256 or digest(token_raw) != expected_token_sha256
            or fail['token_sha256'] != expected_token_sha256 or fail['status'] != 'FAIL'
            or fail['failure_code'] != 'REFRESH_FAILED'):
        raise DiagnosticBoundaryError('incident or token changed; do not retry this checkpoint')
    token = json.loads(token_raw.decode('utf-8-sig'))
    if (token.get('token_uri') != ENDPOINT or not token.get('refresh_token')
            or not set(INTEGRATION_SCOPES).issubset(token.get('scopes', []))):
        raise DiagnosticBoundaryError('official four-scope stored grant required')
    if any(type(token.get(field)) is not str or not token[field].strip()
           for field in ('refresh_token', 'client_id', 'client_secret')):
        raise DiagnosticBoundaryError('stored grant field missing or invalid')
    if token.get('rapt_token') is not None and (type(token['rapt_token']) is not str or not token['rapt_token']):
        raise DiagnosticBoundaryError('invalid optional stored grant field')
    destination = root / 'output/integrations/youtube/heroverse' / output_name
    destination.mkdir(exist_ok=False)
    report = {'version': 'oauth-one-shot-redacted-diagnostic-v1',
        'started_at': datetime.now(timezone.utc).isoformat(),
        'source_failure_sha256': expected_failure_sha256, 'source_token_sha256': expected_token_sha256,
        'implementation_sha256': digest(Path(__file__).read_bytes()),
        'request_attempts': 0, 'request_limit': 1, 'http_status': None,
        'socket_timeout_seconds': 30, 'response_byte_limit': RESPONSE_LIMIT,
        'transport_is_total_deadline': False,
        'technical_cost_brl': 0, 'youtube_api_calls': 0, 'token_written': False,
        'channel_identity_verified': False, 'monitor_state_changed': False,
        'publication_authorized': False, 'secret_logged': False}
    _write_new(destination / 'started.json', report)
    began = time.monotonic()
    try:
        fields = {'grant_type': 'refresh_token', 'refresh_token': token['refresh_token'],
            'client_id': token['client_id'], 'client_secret': token['client_secret'],
            'scope': ' '.join(INTEGRATION_SCOPES)}
        if token.get('rapt_token'):
            fields['rapt'] = token['rapt_token']
        body = urlencode(fields).encode('ascii')
        response = bounded_request(_post_without_sdk_logging, report)(ENDPOINT,
            method='POST', body=body, headers={'Content-Type': 'application/x-www-form-urlencoded'})
        report.update(evaluate_response(response))
    except Exception as error:
        report['status'] = 'REFRESH_DIAGNOSED_NOT_RECOVERED'
        report['diagnosis'] = classify_failure(error)
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    report['elapsed_seconds'] = time.monotonic() - began
    report['source_unchanged_at_end'] = (digest(_resident_file(token_path, 65536)) == expected_token_sha256
        and digest(_resident_file(failed, 16384)) == expected_failure_sha256)
    if not report['source_unchanged_at_end']:
        report['status'] = 'SOURCE_CHANGED_DIAGNOSTIC_NOT_CURRENT'
    _write_new(destination / 'report.json', report)
    return report
