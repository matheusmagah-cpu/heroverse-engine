from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any


GOOGLE_REQUEST_TIMEOUT_SECONDS = 30.0
GOOGLE_OPERATION_DEADLINE_SECONDS = 240.0


class GoogleOperationDeadlineExceeded(TimeoutError):
    """A bounded Google read exceeded the operation-wide wall-clock budget."""


class GoogleOperationDeadline:
    """Monotonic deadline shared by every request in one external-read stage."""

    def __init__(
        self,
        seconds: float = GOOGLE_OPERATION_DEADLINE_SECONDS,
        *,
        progress: Callable[[], Any] | None = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if seconds <= 0:
            raise ValueError("Google operation deadline must be positive")
        self._clock = clock
        self._deadline = clock() + float(seconds)
        self._progress = progress

    def remaining(self, stage: str) -> float:
        value = self._deadline - self._clock()
        if value <= 0:
            raise GoogleOperationDeadlineExceeded(
                f"Google operation deadline exhausted at {stage}"
            )
        return value

    def pulse(self, stage: str) -> float:
        self.remaining(stage)
        if self._progress is not None:
            self._progress()
        return self.remaining(stage)

    def request_timeout(self, stage: str) -> float:
        # Never grant a socket more time than remains in the operation.  A
        # one-second minimum could otherwise overrun a sub-second deadline.
        return min(GOOGLE_REQUEST_TIMEOUT_SECONDS, self.pulse(stage))


def _bound_request_transport(request: Any, timeout_seconds: float) -> None:
    """Best-effort bound for googleapiclient's nested httplib2 transport."""

    candidates = [getattr(request, "http", None), getattr(request, "_http", None)]
    for candidate in list(candidates):
        candidates.append(getattr(candidate, "http", None))
    for candidate in candidates:
        if candidate is not None and hasattr(candidate, "timeout"):
            try:
                candidate.timeout = min(float(candidate.timeout), timeout_seconds)
            except (TypeError, ValueError):
                candidate.timeout = timeout_seconds


def execute_google_request(
    request: Any,
    *,
    deadline: GoogleOperationDeadline,
    stage: str,
) -> dict[str, Any]:
    """Execute one request inside the shared deadline and pulse its lease guard."""

    remaining = deadline.pulse(f"{stage}:before")
    _bound_request_transport(
        request, min(GOOGLE_REQUEST_TIMEOUT_SECONDS, remaining)
    )
    response = request.execute()
    deadline.pulse(f"{stage}:after")
    if not isinstance(response, dict):
        raise TypeError(f"Google API response is not an object at {stage}")
    return response


def build_authorized_service(
    api: str,
    version: str,
    *,
    credentials: Any,
    request_timeout_seconds: float = GOOGLE_REQUEST_TIMEOUT_SECONDS,
) -> Any:
    """Build a Google discovery service with an actual socket timeout.

    ``googleapiclient.discovery.build(credentials=...)`` creates its own HTTP
    transport whose default timeout is outside this project's control.  An
    explicit AuthorizedHttp keeps normal refresh behaviour while bounding DNS,
    connect and read waits without using a paid service.
    """

    if request_timeout_seconds <= 0:
        raise ValueError("Google request timeout must be positive")
    import google_auth_httplib2  # type: ignore
    import httplib2  # type: ignore
    from googleapiclient.discovery import build  # type: ignore

    transport = httplib2.Http(timeout=float(request_timeout_seconds))
    authorized = google_auth_httplib2.AuthorizedHttp(credentials, http=transport)
    return build(api, version, http=authorized, cache_discovery=False)
