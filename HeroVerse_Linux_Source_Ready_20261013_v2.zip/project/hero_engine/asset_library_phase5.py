from __future__ import annotations

import hashlib
import html
import json
import re
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import requests


COMMONS_API = "https://commons.wikimedia.org/w/api.php"
USER_AGENT = "HeroVersePhase5/1.0 (local production pilot; no automated publishing)"
COMMONS_MAX_ATTEMPTS = 4
COMMONS_LOCAL_WAIT_BUDGET_SECONDS = 30.0
COMMONS_RETRYABLE_STATUSES = frozenset({429, 503})
ALLOWED_LICENSES = {
    "CC0": ("CC_COMMERCIAL", "CC0 1.0"),
    "CC BY 4.0": ("CC_COMMERCIAL", "CC BY 4.0"),
    "CC BY 3.0": ("CC_COMMERCIAL", "CC BY 3.0"),
    "Public domain": ("PUBLIC_DOMAIN_VERIFIED", None),
}
SEMANTIC_QUERIES = [
    ("tension", "storm clouds timelapse filetype:video"),
    ("stillness", "calm water nature filetype:video"),
    ("decision", "forest path walking filetype:video"),
    ("movement", "road journey landscape filetype:video"),
    ("pressure", "ocean waves rocks filetype:video"),
    ("reflection", "rain window nature filetype:video"),
    ("perspective", "mountain clouds timelapse filetype:video"),
    ("renewal", "sunrise timelapse landscape filetype:video"),
    ("progress", "river flowing landscape filetype:video"),
    ("payoff", "sun rays clouds timelapse filetype:video"),
]

# A permissive license is necessary but not sufficient. These terms identify
# technically eligible files that are semantically misleading for this pilot.
# The record stays on disk as search evidence but is never promoted to the
# production manifest.
SEMANTIC_EXCLUSION_PATTERNS = (
    re.compile(r"snowflake", re.I),
    re.compile(r"scientists?_create", re.I),
    re.compile(r"3[-_ ]?d_model", re.I),
    re.compile(r"wood[_ -]chopping", re.I),
    re.compile(r"waterski", re.I),
)


class CommonsProviderDeferred(RuntimeError):
    """Stop this build's Commons requests; this is not a cross-process cooldown."""

    def __init__(
        self, *, route: str, reason: str, status_code: int | None,
        attempt: int, retry_after_seconds: int | float | None,
        waited_seconds: float, failure: str | None = None,
    ) -> None:
        self.details = {
            "state": "DEFER", "provider": "Wikimedia Commons",
            "scope": "CURRENT_BUILD_ONLY", "route": route, "reason": reason,
            "status_code": status_code, "attempts": attempt + 1,
            "retry_after_seconds": retry_after_seconds,
            "local_waited_seconds": waited_seconds,
            "local_wait_budget_seconds": COMMONS_LOCAL_WAIT_BUDGET_SECONDS,
            "failure": failure, "provider_switched": False,
        }
        super().__init__(json.dumps(self.details, sort_keys=True, allow_nan=False))


def _commons_retry_after_seconds(
    value: str | None, response_date: str | None, now: datetime,
) -> int | float | None:
    """Parse the server minimum, conservatively accounting for its Date clock."""
    if value is None:
        return None
    value = value.strip()
    if re.fullmatch(r"[0-9]+", value):
        return int(value)
    retry_at = parsedate_to_datetime(value)
    if retry_at.tzinfo is None:
        raise ValueError("Retry-After HTTP date has no timezone")
    delay = max(0.0, (retry_at - now).total_seconds())
    if response_date:
        try:
            server_now = parsedate_to_datetime(response_date)
            if server_now.tzinfo is not None:
                # Waiting longer is safe; an ahead-of-server local clock must
                # never shorten an otherwise explicit server waiting period.
                delay = max(delay, (retry_at - server_now).total_seconds())
        except (ValueError, TypeError, OverflowError):
            pass  # A malformed optional Date does not replace the local clock.
    return delay


def _wait_for_commons_retry(
    *, route: str, attempt: int, waited_seconds: float,
    status_code: int | None = None, retry_after: str | None = None,
    response_date: str | None = None, failure: str | None = None,
) -> float:
    """Called only after the HTTP response is closed; never retries too early."""
    try:
        minimum = _commons_retry_after_seconds(retry_after, response_date, datetime.now(timezone.utc))
    except (ValueError, TypeError, OverflowError) as exc:
        raise CommonsProviderDeferred(
            route=route, reason="INVALID_RETRY_AFTER", status_code=status_code,
            attempt=attempt, retry_after_seconds=None, waited_seconds=waited_seconds,
            failure=type(exc).__name__,
        ) from exc
    reason = None
    if attempt + 1 >= COMMONS_MAX_ATTEMPTS:
        reason = "ATTEMPTS_EXHAUSTED"
    backoff = (5 if status_code in COMMONS_RETRYABLE_STATUSES else 2) * (attempt + 1)
    delay = max(backoff, minimum or 0)
    if reason is None and delay > COMMONS_LOCAL_WAIT_BUDGET_SECONDS - waited_seconds:
        reason = "LOCAL_WAIT_BUDGET_EXCEEDED"
    if reason:
        raise CommonsProviderDeferred(
            route=route, reason=reason, status_code=status_code,
            attempt=attempt, retry_after_seconds=minimum, waited_seconds=waited_seconds,
            failure=failure,
        )
    try:
        time.sleep(delay)
    except Exception as exc:
        # A wait interrupted by an ordinary error must not fall through to the
        # next query. BaseException cancellations still abort the build itself.
        raise CommonsProviderDeferred(
            route=route, reason="WAIT_INTERRUPTED", status_code=status_code,
            attempt=attempt, retry_after_seconds=minimum, waited_seconds=waited_seconds,
            failure=type(exc).__name__,
        ) from exc
    return waited_seconds + delay


def _clean_html(value: Any) -> str | None:
    if value is None:
        return None
    text = html.unescape(str(value))
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\s+", " ", text).strip() or None


def _plain_download_url(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))


def _stable_asset_id(title: str, url: str) -> str:
    return "asset-commons-" + hashlib.sha256(f"{title}|{url}".encode("utf-8")).hexdigest()[:18]


def _rights_status(license_short: str) -> tuple[str, str | None] | None:
    for prefix, decision in ALLOWED_LICENSES.items():
        if license_short == prefix or license_short.startswith(prefix + " "):
            return decision
    return None


def _semantically_excluded(*values: str | None) -> bool:
    haystack = " ".join(value or "" for value in values)
    return any(pattern.search(haystack) for pattern in SEMANTIC_EXCLUSION_PATTERNS)


def _manifest_record(
    selected: list[dict[str, Any]],
    errors: list[dict[str, str]],
    minimum_required: int,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "library_id": "phase5-wikimedia-commons-pilot-v1",
        "status": "COMPLETE" if len(selected) >= minimum_required else "PARTIAL",
        "provider": "Wikimedia Commons API",
        "provider_cost_usd": 0.0,
        "license_fee_usd": 0.0,
        "selected_count": len(selected),
        "minimum_required": minimum_required,
        "assets": selected,
        "errors": errors,
        "excluded_legacy_assets": [
            {
                "asset_or_video_id": "5-zdruoQKlM",
                "reason": "Conflicting local license records; most restrictive status applied under D-010.",
            }
        ],
        "limitations": [
            "This manifest is an operational rights record, not a legal opinion.",
            "Attribution requirements remain attached to every asset and publication package.",
            "License and source pages must be rechecked before a later publication.",
            "Semantic eligibility is evaluated separately from license eligibility.",
        ],
    }


def _write_manifest(path: Path, manifest: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def build_asset_catalog(
    package_dir: Path,
    max_candidates: int = 10,
    queries: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Record remote, rights-checked candidates without downloading media.

    Mining and creative modelling need source metadata, not local video bytes.
    This is therefore the only discovery entry allowed for new production
    candidates. It writes a compact, auditable catalog and a per-candidate
    rights snapshot, but deliberately omits a local URI and content hash.
    """
    queries = queries or SEMANTIC_QUERIES
    package_dir = package_dir.resolve()
    evidence_dir = package_dir / "rights_evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    catalog_path = package_dir / "asset_candidates.remote.json"
    selected: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    seen_pages: set[int] = set()
    seen_sources: set[str] = set()
    for semantic_role, query in queries:
        if len(selected) >= max_candidates:
            break
        try:
            candidates = search_commons_videos(query)
            time.sleep(1.1)
        except CommonsProviderDeferred as exc:
            errors.append({"query": query, "error": f"PROVIDER_DEFERRED:{exc}"})
            break
        except Exception as exc:
            errors.append({"query": query, "error": f"{type(exc).__name__}: {exc}"})
            continue
        candidate = next(
            (item for item in candidates if item["page_id"] not in seen_pages
             and item["description_url"] not in seen_sources),
            None,
        )
        if candidate is None:
            errors.append({"query": query, "error": "NO_ELIGIBLE_RESULT"})
            continue
        seen_pages.add(candidate["page_id"])
        seen_sources.add(candidate["description_url"])
        asset_id = _stable_asset_id(candidate["title"], candidate["download_url"])
        verified_at = datetime.now(timezone.utc).isoformat()
        attribution = None
        if candidate["attribution_required"]:
            attribution = (
                f"{candidate['title'].removeprefix('File:')} — "
                f"{candidate['creator'] or 'creator listed on source page'}; "
                f"{candidate['license_short']}; {candidate['description_url']}"
            )
        evidence_path = evidence_dir / f"{asset_id}.json"
        evidence = {
            "schema_version": "1.1.0", "asset_id": asset_id,
            "semantic_role": semantic_role, "search_query": query,
            "verified_at": verified_at, "source_api": COMMONS_API,
            "source_page": candidate["description_url"],
            "raw_selected_metadata": candidate,
            "decision": "CATALOGED_REMOTE_RIGHTS_ELIGIBLE",
            "decision_basis": (
                "Remote metadata passed license and semantic filters; no media "
                "bytes were downloaded or admitted for production."
            ),
        }
        evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        selected.append({
            "asset_id": asset_id, "semantic_role": semantic_role,
            "residency": "REMOTE_CATALOGED", "download_url": candidate["download_url"],
            "source": candidate["description_url"], "creator_or_holder": candidate["creator"],
            "rights_status": candidate["rights_status"], "license": candidate["license_short"],
            "license_version": candidate["license_version"], "commercial_use": True,
            "production_eligible": False,
            "production_blocker": "TAKE_ALLOCATION_AND_LOCAL_ACQUISITION_REQUIRED",
            "attribution": attribution,
            "restrictions": [candidate["restrictions"]] if candidate["restrictions"] else [],
            "rights_evidence_uri": str(evidence_path.resolve()), "verified_at": verified_at,
            "duration_seconds": round(candidate["duration_seconds"], 3),
            "width": candidate["width"], "height": candidate["height"],
            "size_bytes": candidate["size_bytes"], "commons_sha1": candidate.get("commons_sha1"),
        })
    result = {
        "schema_version": "1.0.0", "catalog_id": "phase5-wikimedia-commons-remote-catalog-v1",
        "status": "COMPLETE" if len(selected) >= min(max_candidates, len(queries)) else "PARTIAL",
        "provider": "Wikimedia Commons API", "technical_cost_brl": 0,
        "media_downloaded": False, "candidate_count": len(selected),
        "candidates": selected, "errors": errors,
        "limitations": [
            "Catalog entries are not production assets and cannot be rendered.",
            "A later take allocation must select an exact candidate before one local download.",
            "Remote metadata and licenses must be rechecked at acquisition and publication.",
        ],
    }
    _write_manifest(catalog_path, result)
    return result


def search_commons_videos(query: str, limit: int = 30) -> list[dict[str, Any]]:
    params = {
        "action": "query",
        "generator": "search",
        "gsrsearch": query,
        "gsrnamespace": 6,
        "gsrlimit": min(limit, 50),
        "prop": "imageinfo",
        "iiprop": "url|extmetadata|size|mime|sha1",
        "format": "json",
        "formatversion": 2,
    }
    waited_seconds = 0.0
    for attempt in range(COMMONS_MAX_ATTEMPTS):
        status_code = None
        retry_after = response_date = failure = None
        try:
            with requests.get(COMMONS_API, params=params, headers={"User-Agent": USER_AGENT}, timeout=60) as response:
                if response.status_code not in COMMONS_RETRYABLE_STATUSES:
                    response.raise_for_status()
                    payload = response.json()
                    break
                status_code = response.status_code
                retry_after = response.headers.get("Retry-After")
                response_date = response.headers.get("Date")
        except (requests.Timeout, requests.ConnectionError, requests.exceptions.ChunkedEncodingError) as exc:
            failure = f"{type(exc).__name__}: {exc}"
        waited_seconds = _wait_for_commons_retry(
            route="SEARCH", attempt=attempt, waited_seconds=waited_seconds,
            status_code=status_code, retry_after=retry_after,
            response_date=response_date, failure=failure,
        )
    pages = payload.get("query", {}).get("pages", [])
    results: list[dict[str, Any]] = []
    for page in pages:
        info = (page.get("imageinfo") or [{}])[0]
        meta = info.get("extmetadata") or {}
        license_short = _clean_html((meta.get("LicenseShortName") or {}).get("value"))
        allowed = _rights_status(license_short or "")
        width = int(info.get("width") or 0)
        height = int(info.get("height") or 0)
        duration = float(info.get("duration") or 0.0)
        size = int(info.get("size") or 0)
        mime = str(info.get("mime") or "")
        if not allowed or width < 1280 or height < 720 or width <= height or duration < 8.0:
            continue
        if size <= 0 or size > 120 * 1024 * 1024 or not mime.startswith("video/"):
            continue
        description = _clean_html((meta.get("ImageDescription") or {}).get("value"))
        if _semantically_excluded(page.get("title"), description, info.get("descriptionurl")):
            continue
        rights_status, license_version = allowed
        results.append(
            {
                "page_id": page["pageid"],
                "title": page["title"],
                "download_url": _plain_download_url(info["url"]),
                "description_url": info["descriptionurl"],
                "width": width,
                "height": height,
                "duration_seconds": duration,
                "size_bytes": size,
                "mime": mime,
                "commons_sha1": info.get("sha1"),
                "description": description,
                "creator": _clean_html((meta.get("Artist") or {}).get("value")),
                "credit": _clean_html((meta.get("Credit") or {}).get("value")),
                "license_short": license_short,
                "license_version": license_version,
                "license_url": _clean_html((meta.get("LicenseUrl") or {}).get("value")),
                "usage_terms": _clean_html((meta.get("UsageTerms") or {}).get("value")),
                "attribution_required": str((meta.get("AttributionRequired") or {}).get("value", "false")).lower() == "true",
                "rights_status": rights_status,
                "restrictions": _clean_html((meta.get("Restrictions") or {}).get("value")),
            }
        )
    results.sort(key=lambda item: (item["width"] * item["height"], min(item["duration_seconds"], 90), -item["size_bytes"]), reverse=True)
    return results


def _download_commons_file(candidate: dict[str, Any], destination: Path) -> None:
    """One Commons download with bounded retries and preserved completed files."""
    temporary = destination.with_suffix(destination.suffix + ".part")
    waited_seconds = 0.0
    for attempt in range(COMMONS_MAX_ATTEMPTS):
        status_code = None
        retry_after = response_date = failure = None
        try:
            with requests.get(candidate["download_url"], headers={"User-Agent": USER_AGENT}, timeout=180, stream=True) as response:
                if response.status_code in COMMONS_RETRYABLE_STATUSES:
                    status_code = response.status_code
                    retry_after = response.headers.get("Retry-After")
                    response_date = response.headers.get("Date")
                else:
                    response.raise_for_status()
                    with temporary.open("wb") as handle:
                        for chunk in response.iter_content(chunk_size=1024 * 1024):
                            if chunk:
                                handle.write(chunk)
            if status_code is None:
                if temporary.stat().st_size == candidate["size_bytes"]:
                    temporary.replace(destination)
                    return
                failure = "SIZE_MISMATCH"
        except (requests.Timeout, requests.ConnectionError, requests.exceptions.ChunkedEncodingError) as exc:
            failure = f"{type(exc).__name__}: {exc}"
        waited_seconds = _wait_for_commons_retry(
            route="DOWNLOAD", attempt=attempt, waited_seconds=waited_seconds,
            status_code=status_code, retry_after=retry_after,
            response_date=response_date, failure=failure,
        )


def build_and_download_asset_library(
    package_dir: Path,
    max_assets: int = 10,
    queries: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Build a zero-license-fee library from exact Commons file records.

    Search results are never accepted on their own; each selected file carries its
    description page, license fields, API evidence snapshot, hash, and local path.
    """
    queries = queries or SEMANTIC_QUERIES
    media_dir = package_dir / "assets"
    evidence_dir = package_dir / "rights_evidence"
    media_dir.mkdir(parents=True, exist_ok=True)
    evidence_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = package_dir / "asset_manifest.json"
    previous = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.is_file() else None
    prior_assets: list[dict[str, Any]] = list(previous.get("assets", [])) if previous else []
    selected = [
        asset for asset in prior_assets
        if not _semantically_excluded(asset.get("source"), asset.get("uri"))
        and Path(asset["uri"]).is_file()
    ]
    used_pages: set[int] = set()
    used_sources = {asset["source"] for asset in selected}
    errors: list[dict[str, str]] = list(previous.get("errors", [])) if previous else []
    for asset in prior_assets:
        if asset not in selected:
            errors.append({
                "query": f"prior_asset:{asset.get('asset_id', 'UNKNOWN')}",
                "error": "REMOVED_BY_SEMANTIC_OR_LOCAL_FILE_GATE",
            })
    for semantic_role, query in queries:
        if len(selected) >= max_assets:
            break
        try:
            candidates = search_commons_videos(query)
            time.sleep(1.1)
        except CommonsProviderDeferred as exc:
            errors.append({"query": query, "error": f"PROVIDER_DEFERRED:{exc}"})
            break  # No next query/asset may bypass this build's provider stop.
        except Exception as exc:  # network failure is an explicit library error
            errors.append({"query": query, "error": f"{type(exc).__name__}: {exc}"})
            continue
        candidate = next(
            (
                item for item in candidates
                if item["page_id"] not in used_pages and item["description_url"] not in used_sources
            ),
            None,
        )
        if not candidate:
            errors.append({"query": query, "error": "NO_ELIGIBLE_RESULT"})
            continue
        used_pages.add(candidate["page_id"])
        used_sources.add(candidate["description_url"])
        asset_id = _stable_asset_id(candidate["title"], candidate["download_url"])
        suffix = Path(urlsplit(candidate["download_url"]).path).suffix.lower() or ".webm"
        destination = media_dir / f"{asset_id}{suffix}"
        if not destination.exists() or destination.stat().st_size != candidate["size_bytes"]:
            try:
                _download_commons_file(candidate, destination)
            except CommonsProviderDeferred as exc:
                errors.append({"query": query, "error": f"PROVIDER_DEFERRED:{exc}"})
                break
            except Exception as exc:
                errors.append({"query": query, "error": f"DOWNLOAD_FAILED:{type(exc).__name__}: {exc}"})
                continue
        hasher = hashlib.sha256()
        with destination.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                hasher.update(block)
        digest = hasher.hexdigest()
        verified_at = datetime.now(timezone.utc).isoformat()
        attribution = None
        if candidate["attribution_required"]:
            attribution = (
                f"{candidate['title'].removeprefix('File:')} — {candidate['creator'] or 'creator listed on source page'}; "
                f"{candidate['license_short']}; {candidate['description_url']}"
            )
        evidence_record = {
            "schema_version": "1.0.0",
            "asset_id": asset_id,
            "semantic_role": semantic_role,
            "search_query": query,
            "verified_at": verified_at,
            "source_api": COMMONS_API,
            "source_page": candidate["description_url"],
            "raw_selected_metadata": candidate,
            "decision": "AUTO_ELIGIBLE_BY_VERIFIED_LICENSE",
            "decision_basis": "Exact Commons file metadata states an allowed commercial license or verified public-domain status.",
        }
        evidence_path = evidence_dir / f"{asset_id}.json"
        evidence_path.write_text(json.dumps(evidence_record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        selected.append(
            {
                "asset_id": asset_id,
                "semantic_role": semantic_role,
                "uri": str(destination.resolve()),
                "content_hash": f"sha256:{digest}",
                "source": candidate["description_url"],
                "creator_or_holder": candidate["creator"],
                "rights_status": candidate["rights_status"],
                "license": candidate["license_short"],
                "license_version": candidate["license_version"],
                "commercial_use": True,
                "production_eligible": True,
                "attribution": attribution,
                "restrictions": [candidate["restrictions"]] if candidate["restrictions"] else [],
                "rights_evidence_uri": str(evidence_path.resolve()),
                "verified_at": verified_at,
                "rights_decision": "AUTO_ELIGIBLE_BY_VERIFIED_LICENSE",
                "duration_seconds": round(candidate["duration_seconds"], 3),
                "width": candidate["width"],
                "height": candidate["height"],
                "used_ranges": [],
            }
        )
        # Checkpoint after every accepted asset so a later network error does not
        # erase completed, hashed and rights-verified work.
        _write_manifest(manifest_path, _manifest_record(selected, errors, max_assets))
    manifest = _manifest_record(selected, errors, max_assets)
    _write_manifest(manifest_path, manifest)
    return manifest
