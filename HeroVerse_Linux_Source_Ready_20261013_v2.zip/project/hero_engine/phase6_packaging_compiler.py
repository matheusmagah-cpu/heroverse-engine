from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


COMPILER_VERSION = "phase6-adaptive-packaging-compiler-v1"
SCORE_WEIGHTS = {
    "content_fidelity": 0.20,
    "hook_alignment": 0.14,
    "channel_dna": 0.12,
    "title_thumbnail_complementarity": 0.10,
    "baseline_novelty": 0.10,
    "candidate_distinctness": 0.10,
    "source_originality": 0.08,
    "legibility": 0.07,
    "policy_safety": 0.05,
    "treatment_integrity": 0.04,
}
REFERENCE_BOILERPLATE = {"christian", "motivation", "hd", "official", "video"}
BANNED = re.compile(r"\b(guaranteed|miracle|god told|will happen|instant|secret)\b", re.I)
ROUTES: list[dict[str, Any]] = [
    {
        "route_id": "package-fear-still-decides",
        "title": "YOU PRAYED—BUT FEAR IS STILL CHOOSING | Christian Motivation",
        "thumbnail_text": "FEAR STILL DECIDES?",
        "promise": "Recognize when fear, rather than faithful responsibility, is still choosing the next move after prayer.",
        "required_script_terms": ["prayer", "fear", "responsibility"],
        "source_name": "phone-down-original-v1.png", "line_one": "FEAR STILL", "line_two": "DECIDES?", "layout": "LEFT",
    },
    {
        "route_id": "package-test-before-action",
        "title": "BEFORE YOU ACT AFTER PRAYER, TEST THIS | Christian Motivation",
        "thumbnail_text": "TEST THE STEP",
        "promise": "Use the video's truth, responsibility and today checks before treating a post-prayer impulse as direction.",
        "required_script_terms": ["prayer", "test", "truth", "responsibility"],
        "source_name": "three-card-decision-original-v1.png", "line_one": "TEST THE", "line_two": "STEP", "layout": "BOTTOM",
    },
    {
        "route_id": "package-one-step-today",
        "title": "AFTER PRAYER, TAKE ONE RESPONSIBLE STEP TODAY | Christian Motivation",
        "thumbnail_text": "MOVE TODAY",
        "promise": "Choose one truthful and responsible action that can begin today without pretending the outcome is guaranteed.",
        "required_script_terms": ["prayer", "responsible", "action", "today"],
        "source_name": "action-plan-original-v1.png", "line_one": "MOVE", "line_two": "TODAY", "layout": "LEFT",
    },
    {
        "route_id": "package-impulse-boundary",
        "title": "NOT EVERY IMPULSE AFTER PRAYER IS GUIDANCE | Christian Motivation",
        "thumbnail_text": "TEST THE IMPULSE",
        "promise": "Separate anxious urgency from a bounded next step tested by truth, consequences and wise counsel.",
        "required_script_terms": ["prayer", "impulse", "truth", "counsel"],
        "source_name": "safe-boundaries-original-v1.png", "line_one": "TEST THE", "line_two": "IMPULSE", "layout": "LEFT",
    },
    {
        "route_id": "package-wisdom-then-action",
        "title": "PRAYER, WISDOM, THEN ACTION | Christian Motivation",
        "thumbnail_text": "HEAR. THEN DO.",
        "promise": "Connect prayer and biblical wisdom to accountable action instead of passive hearing.",
        "required_script_terms": ["prayer", "wisdom", "action", "hearing"],
        "source_name": "scriptural-mechanism-original-v1.png", "line_one": "HEAR.", "line_two": "THEN DO.", "layout": "BOTTOM",
    },
    {
        "route_id": "package-counsel-before-action",
        "title": "WHEN PRAYER NEEDS WISE COUNSEL BEFORE ACTION | Christian Motivation",
        "thumbnail_text": "ASK FOR COUNSEL",
        "promise": "Know when a next step should be checked with wise counsel and safe boundaries before action.",
        "required_script_terms": ["prayer", "counsel", "action", "boundaries"],
        "source_name": "trusted-counsel-original-v1.png", "line_one": "ASK FOR", "line_two": "COUNSEL", "layout": "LEFT",
    },
]


def _tokens(*values: Any) -> set[str]:
    return {
        token.casefold()
        for value in values
        for token in re.findall(r"[A-Za-z]+", str(value or ""))
        if len(token) > 1
    }


def _jaccard(left: set[str], right: set[str]) -> float:
    return len(left & right) / max(1, len(left | right))


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def _file_hash(path: Path) -> str:
    return f"sha256:{hashlib.sha256(path.read_bytes()).hexdigest()}"


def _stable_id(prefix: str, *parts: Any) -> str:
    return f"{prefix}-{hashlib.sha256('|'.join(str(part) for part in parts).encode()).hexdigest()[:24]}"


def _source(root: Path, name: str) -> Path:
    candidates = [
        root / "output/production/phase5/pilot-001/creative-v3/assets" / name,
        root / "output/production/phase5/pilot-001/creative-v2/assets" / name,
    ]
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(f"owned packaging source is unavailable: {name}")


def build_packaging_search(
    *,
    root: Path,
    order: dict[str, Any],
    candidate: dict[str, Any],
    signal: dict[str, Any],
    baseline_script: dict[str, Any],
    baseline_package: dict[str, Any],
    created_at: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if (order.get("treatment") or {}).get("variable") != "TITLE_THUMBNAIL_PROMISE":
        raise PermissionError("packaging search requires the exact preregistered packaging variable")
    if candidate.get("topic_cluster") != "prayer_obedience":
        raise PermissionError("canary packaging search must preserve the published prayer-obedience topic")
    if len(ROUTES) < 6 or len({item["route_id"] for item in ROUTES}) != len(ROUTES):
        raise PermissionError("packaging search requires at least six uniquely identified routes")
    record = order.get("market_candidate") or {}
    signal_path = root / "output/production/phase5/pilot-001/daily_signal_snapshot.json"
    if not signal_path.is_file() or _file_hash(signal_path) != record.get("source_snapshot_content_hash"):
        raise PermissionError("packaging search market snapshot is missing or changed")
    persisted_signal = json.loads(signal_path.read_text(encoding="utf-8-sig"))
    if persisted_signal != signal:
        raise PermissionError("packaging search did not receive the exact persisted market snapshot")
    if (
        signal.get("snapshot_id") != record.get("source_snapshot_id")
        or signal.get("score_version") != record.get("source_score_version")
    ):
        raise PermissionError("packaging search market snapshot identity or score version changed")
    matches = [
        item for item in signal.get("candidates") or []
        if item.get("candidate_id") == record.get("candidate_id")
    ]
    if len(matches) != 1 or matches[0] != candidate:
        raise PermissionError("packaging search market candidate is missing, duplicated or divergent")
    if _canonical_hash(candidate) != record.get("selected_candidate_content_hash"):
        raise PermissionError("packaging search market candidate content changed")

    script_tokens = _tokens(baseline_script.get("full_text"))
    hook_tokens = _tokens(*[item.get("narration") for item in baseline_script.get("hook_windows", [])[:3]])
    baseline_title = str((baseline_package.get("metadata") or {}).get("title") or "")
    baseline_thumb = str((baseline_package.get("thumbnail") or {}).get("text") or "")
    baseline_tokens = _tokens(baseline_title, baseline_thumb)
    source_titles = {
        str(item.get("video_id") or item.get("snapshot_id") or index): _tokens(item.get("title")) - REFERENCE_BOILERPLATE
        for index, item in enumerate(candidate.get("representative_sources") or [])
        if item.get("title")
    }
    material_tokens = {
        item["route_id"]: _tokens(item["title"], item["thumbnail_text"], item["promise"])
        for item in ROUTES
    }
    assessments: list[dict[str, Any]] = []
    for route in ROUTES:
        route_id = route["route_id"]
        tokens = material_tokens[route_id]
        title_tokens = _tokens(route["title"]) - REFERENCE_BOILERPLATE
        thumb_tokens = _tokens(route["thumbnail_text"])
        required = set(route["required_script_terms"])
        content_fidelity = len(required & script_tokens) / max(1, len(required))
        hook_alignment = min(1.0, len(tokens & hook_tokens) / 3)
        channel_dna = float(
            bool(title_tokens & {"prayer", "pray", "prayed", "praying", "amen", "faith"})
            and bool(tokens & {"action", "step", "truth", "responsibility", "responsible", "wisdom", "counsel", "fear"})
        )
        complementarity = 1.0 - _jaccard(title_tokens, thumb_tokens)
        baseline_novelty = 1.0 - _jaccard(tokens, baseline_tokens)
        other_similarities = [
            (other["route_id"], _jaccard(tokens, material_tokens[other["route_id"]]))
            for other in ROUTES if other["route_id"] != route_id
        ]
        closest_route, max_pairwise = max(other_similarities, key=lambda item: item[1])
        candidate_distinctness = 1.0 - max_pairwise
        source_similarities = [
            (source_id, _jaccard(tokens - REFERENCE_BOILERPLATE, source_tokens))
            for source_id, source_tokens in source_titles.items()
        ]
        closest_source, max_source_overlap = (
            max(source_similarities, key=lambda item: item[1])
            if source_similarities else ("NO_SOURCE_TITLE", 0.0)
        )
        source_originality = 1.0 - max_source_overlap
        thumb_words = re.findall(r"[A-Za-z]+", route["thumbnail_text"])
        legibility = (float(35 <= len(route["title"]) <= 100) + float(2 <= len(thumb_words) <= 5 and len(route["thumbnail_text"]) <= 40)) / 2
        policy_safety = float(BANNED.search(route["title"] + " " + route["thumbnail_text"] + " " + route["promise"]) is None)
        treatment_integrity = float(
            (order.get("treatment") or {}).get("change_only") == ["title", "thumbnail", "combined_promise_wording"]
        )
        components = {
            "content_fidelity": round(content_fidelity, 6),
            "hook_alignment": round(hook_alignment, 6),
            "channel_dna": round(channel_dna, 6),
            "title_thumbnail_complementarity": round(complementarity, 6),
            "baseline_novelty": round(baseline_novelty, 6),
            "candidate_distinctness": round(candidate_distinctness, 6),
            "source_originality": round(source_originality, 6),
            "legibility": round(legibility, 6),
            "policy_safety": round(policy_safety, 6),
            "treatment_integrity": round(treatment_integrity, 6),
        }
        score = round(sum(SCORE_WEIGHTS[key] * components[key] for key in SCORE_WEIGHTS), 6)
        source_path = _source(root, route["source_name"])
        checks = {
            "content_is_delivered_by_existing_video": content_fidelity == 1.0,
            "channel_dna_is_preserved": channel_dna == 1.0,
            "title_thumbnail_are_complementary": complementarity >= 0.65,
            "materially_differs_from_baseline": baseline_novelty >= 0.20,
            "alternative_is_materially_distinct": candidate_distinctness >= 0.20,
            "reference_wording_is_original": source_originality >= 0.50,
            "copy_is_legible": legibility == 1.0,
            "policy_language_is_safe": policy_safety == 1.0,
            "single_variable_integrity": treatment_integrity == 1.0,
            "owned_render_source_exists": source_path.is_file(),
        }
        rejection = [name for name, passed in checks.items() if not passed]
        assessments.append({
            "route_id": route_id,
            "title": route["title"], "thumbnail_text": route["thumbnail_text"], "promise": route["promise"],
            "eligible": not rejection,
            "score_components": components, "selection_score": score, "score_coverage": 1.0,
            "critical_checks": checks,
            "red_team": {
                "status": "PASS" if not rejection else "FAIL",
                "closest_route_id": closest_route,
                "maximum_route_similarity": round(max_pairwise, 6),
                "closest_reference_video_id": closest_source,
                "maximum_source_title_overlap": round(max_source_overlap, 6),
                "challenges": [
                    "Does the unchanged video explicitly deliver this exact title-thumbnail promise?",
                    "Does the thumbnail add information instead of repeating the title?",
                    "Would the route remain honest if distribution does not improve?",
                ],
            },
            "render_spec": {
                "source_path": source_path.relative_to(root).as_posix(),
                "source_sha256": _file_hash(source_path),
                "line_one": route["line_one"], "line_two": route["line_two"], "layout": route["layout"],
            },
            "rejection_reasons": rejection,
        })
    assessments.sort(key=lambda item: (-item["selection_score"], item["route_id"]))
    eligible = [item for item in assessments if item["eligible"]]
    if len(eligible) < 3:
        raise PermissionError("packaging search retained fewer than three evidence-safe finalists")
    finalists = eligible[:3]
    decision = {
        "schema_version": "1.0.0",
        "decision_id": _stable_id("phase6-packaging-search", order["order_id"], COMPILER_VERSION, *[item["route_id"] for item in finalists]),
        "compiler_version": COMPILER_VERSION,
        "order_id": order["order_id"], "channel_id": order["channel_id"], "video_id": "iK_5edYQtx8",
        "treatment_variable": "TITLE_THUMBNAIL_PROMISE",
        "market_binding": {
            "candidate_id": record["candidate_id"], "source_snapshot_id": record["source_snapshot_id"],
            "source_snapshot_content_hash": record["source_snapshot_content_hash"],
            "selected_candidate_content_hash": record["selected_candidate_content_hash"],
        },
        "baseline": {
            "title": baseline_title, "thumbnail_text": baseline_thumb,
            "script_id": baseline_script["script_id"], "video_sha256": baseline_package["video"]["sha256"],
        },
        "score_weights": SCORE_WEIGHTS,
        "creative_search": {
            "minimum_candidate_count": 6, "candidate_count": len(assessments),
            "eligible_candidate_count": len(eligible), "finalist_count": 3,
            "distinct_candidate_ids": len({item["route_id"] for item in assessments}) == len(assessments),
            "maximum_pairwise_similarity": round(max(item["red_team"]["maximum_route_similarity"] for item in assessments), 6),
            "maximum_source_title_overlap": round(max(item["red_team"]["maximum_source_title_overlap"] for item in assessments), 6),
            "red_team_status": "PASS",
        },
        "candidate_assessments": assessments,
        "finalist_route_ids": [item["route_id"] for item in finalists],
        "highest_ranked_route_id": finalists[0]["route_id"],
        "claim_boundary": [
            "The search changes only title, thumbnail and their combined wording; video bytes, description, narration and timeline remain locked.",
            "Every promise must already be delivered by the published canary.",
            "The score ranks packaging fitness and is not a CTR or virality prediction.",
            "A later evaluator must recompute the search before rendering a finalist.",
        ],
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": created_at,
    }
    variants = []
    for variant_id, finalist in zip(("A", "B", "C"), finalists):
        variants.append({
            "variant_id": variant_id, "route_id": finalist["route_id"],
            "title": finalist["title"], "thumbnail_text": finalist["thumbnail_text"],
            "promise": finalist["promise"], "selection_score": finalist["selection_score"],
            "render_spec": finalist["render_spec"],
        })
    bundle = {
        "schema_version": "1.0.0", "compiler_version": COMPILER_VERSION,
        "decision_id": decision["decision_id"], "order_id": order["order_id"],
        "baseline_video_id": "iK_5edYQtx8", "variants": variants,
        "selection_rule": "Search six evidence-safe routes, retain the three highest eligible finalists, then let the independent package evaluator select one exact pair after mechanical gates. Scores are not performance forecasts.",
        "rollback": "Preserve the current title and thumbnail hash and restore them on critical gate failure or material misleading-promise evidence.",
        "publication_authorized": False, "technical_cost_brl": 0,
    }
    return decision, bundle


def packaging_search_is_reproducible(
    decision: dict[str, Any], bundle: dict[str, Any], **inputs: Any,
) -> bool:
    expected_decision, expected_bundle = build_packaging_search(
        created_at=decision["created_at"], **inputs,
    )
    return decision == expected_decision and bundle == expected_bundle
