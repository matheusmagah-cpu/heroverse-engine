from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf
from jsonschema import Draft202012Validator


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"
OUTPUT_FPS = 30
PACKAGE = Path("output/production/phase5/pilot-001")
V2 = PACKAGE / "creative-v2"
FONT_CANDIDATES = [Path(r"C:\Windows\Fonts\bahnschrift.ttf"), Path(r"C:\Windows\Fonts\arialbd.ttf")]


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _segment_fingerprint(take: dict[str, Any], treatment: dict[str, Any]) -> str:
    payload = json.dumps({"take": take, "treatment": treatment, "renderer": "creative-v2.1"}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _run(command: list[str]) -> None:
    result = subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True)
    if result.returncode:
        raise RuntimeError("\n".join(result.stderr.splitlines()[-50:]))


def _probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels", "-of", "json", str(path)],
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=True,
    )
    return json.loads(result.stdout)


def _fps(value: str) -> float:
    numerator, denominator = value.split("/", 1)
    return float(numerator) / float(denominator)


def _frames(duration_ms: int) -> int:
    exact = duration_ms * OUTPUT_FPS / 1000
    rounded = round(exact)
    if not math.isclose(exact, rounded, abs_tol=1e-9):
        raise ValueError(f"duration is not frame exact at 30 fps: {duration_ms}")
    return int(rounded)


def _origin(value: str) -> tuple[Path, float, float]:
    path, span = value.rsplit("#t=", 1)
    start, end = span.split(",", 1)
    return Path(path), float(start), float(end)


def _asset_id(path: Path) -> str:
    match = re.search(r"(asset-(?:commons|owned)-[a-z0-9-]+)", path.name)
    return match.group(1) if match else path.stem


def _font() -> Path:
    for path in FONT_CANDIDATES:
        if path.is_file():
            return path
    raise FileNotFoundError("Bahnschrift/Arial Bold missing")


def _ffmpeg_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _concat_file(path: Path, files: list[Path]) -> None:
    path.write_text("\n".join("file '" + str(item.resolve()).replace("'", "''") + "'" for item in files) + "\n", encoding="utf-8")


def _text_filter(font: Path, text_path: Path, *, size: int, x: str, y: str, color: str = "0xE8EDF2") -> str:
    return (
        "drawtext="
        f"fontfile='{_ffmpeg_path(font)}':textfile='{_ffmpeg_path(text_path)}':"
        f"fontcolor={color}:fontsize={size}:borderw=2:bordercolor=0x081827@0.85:"
        f"x={x}:y={y}:line_spacing=12"
    )


def _visual_filters(
    take: dict[str, Any],
    treatment: dict[str, Any],
    *,
    font: Path,
    work_dir: Path,
) -> list[str]:
    vf = [
        "scale=1920:1080:force_original_aspect_ratio=increase:out_color_matrix=bt709:out_range=tv",
        "crop=1920:1080",
        "fps=30",
        "setsar=1",
        "eq=contrast=1.09:saturation=0.82:brightness=-0.018:gamma=0.98",
        "colorbalance=bs=0.018:gs=-0.006:rs=-0.008",
        "vignette=angle=PI/5.5",
    ]
    kind = treatment["treatment"]
    raw_text = take.get("on_screen_text")
    if raw_text is not None and not isinstance(raw_text, str):
        raise TypeError("take.on_screen_text must be a string or null")
    text = raw_text if raw_text is not None and raw_text.strip() else None
    if kind in {"HOOK_STAMP", "HOOK_QUESTION"} and text is not None:
        text_path = work_dir / f"{take['take_id']}.txt"
        text_path.write_text(text, encoding="utf-8")
        vf.extend(
            [
                "drawbox=x=0:y=0:w=900:h=1080:color=0x081827@0.30:t=fill",
                "drawbox=x=122:y=330:w=10:h=330:color=0xD7A94A@1.0:t=fill",
                _text_filter(font, text_path, size=116 if kind == "HOOK_STAMP" else 126, x="170", y="(h-text_h)/2", color="0xE8EDF2"),
            ]
        )
    elif kind == "HOOK_FRAMEWORK":
        label_paths = []
        for index, label in enumerate(("TRUTH", "RESPONSIBILITY", "TODAY"), start=1):
            path = work_dir / f"{take['take_id']}-framework-{index}.txt"
            path.write_text(label, encoding="utf-8")
            label_paths.append(path)
        vf.extend(
            [
                "drawbox=x=120:y=820:w=1680:h=150:color=0x081827@0.72:t=fill",
                "drawbox=x=120:y=820:w=1680:h=6:color=0xD7A94A@1.0:t=fill",
                _text_filter(font, label_paths[0], size=48, x="170", y="870", color="0xE8EDF2"),
                _text_filter(font, label_paths[1], size=48, x="700", y="870", color="0xD7A94A"),
                _text_filter(font, label_paths[2], size=48, x="1510", y="870", color="0xE8EDF2"),
            ]
        )
    elif kind == "SCRIPTURE_SEQUENCE":
        labels = []
        for index, label in enumerate(("ASK", "HEAR", "DO"), start=1):
            path = work_dir / f"{take['take_id']}-sequence-{index}.txt"
            path.write_text(label, encoding="utf-8")
            labels.append(path)
        vf.extend(
            [
                "drawbox=x=210:y=700:w=1500:h=190:color=0x081827@0.78:t=fill",
                "drawbox=x=210:y=700:w=1500:h=7:color=0xD7A94A@1.0:t=fill",
                _text_filter(font, labels[0], size=72, x="330", y="755", color="0xE8EDF2"),
                _text_filter(font, labels[1], size=72, x="820", y="755", color="0xE8EDF2"),
                _text_filter(font, labels[2], size=72, x="1345", y="755", color="0xD7A94A"),
                "drawbox=x=605:y=785:w=130:h=5:color=0xD7A94A@0.9:t=fill",
                "drawbox=x=1130:y=785:w=130:h=5:color=0xD7A94A@0.9:t=fill",
            ]
        )
    elif kind == "FRAMEWORK_STEP" and text:
        text_path = work_dir / f"{take['take_id']}.txt"
        text_path.write_text(text, encoding="utf-8")
        vf.extend(
            [
                "drawbox=x=90:y=690:w=1740:h=220:color=0x081827@0.78:t=fill",
                "drawbox=x=90:y=690:w=14:h=220:color=0xD7A94A@1.0:t=fill",
                _text_filter(font, text_path, size=66, x="160", y="765", color="0xE8EDF2"),
            ]
        )
    elif kind == "KEYWORD_PUNCH" and text:
        text_path = work_dir / f"{take['take_id']}.txt"
        text_path.write_text(text, encoding="utf-8")
        vf.extend(
            [
                "drawbox=x=180:y=350:w=1560:h=300:color=0x081827@0.72:t=fill",
                "drawbox=x=180:y=350:w=14:h=300:color=0xD7A94A@1.0:t=fill",
                _text_filter(font, text_path, size=72, x="(w-text_w)/2", y="(h-text_h)/2", color="0xE8EDF2"),
            ]
        )
    elif kind in {"SECTION_CARD", "PAYOFF_RESOLUTION"} and text:
        text_path = work_dir / f"{take['take_id']}.txt"
        text_path.write_text(text, encoding="utf-8")
        if kind == "PAYOFF_RESOLUTION":
            vf.extend(
                [
                    "drawbox=x=180:y=380:w=1560:h=260:color=0x081827@0.64:t=fill",
                    "drawbox=x=420:y=650:w=1080:h=7:color=0xD7A94A@1.0:t=fill",
                    _text_filter(font, text_path, size=76, x="(w-text_w)/2", y="(h-text_h)/2", color="0xE8EDF2"),
                ]
            )
        else:
            vf.extend(
                [
                    "drawbox=x=90:y=690:w=1450:h=220:color=0x081827@0.58:t=fill",
                    "drawbox=x=120:y=720:w=9:h=150:color=0xD7A94A@1.0:t=fill",
                    _text_filter(font, text_path, size=68, x="170", y="760", color="0xE8EDF2"),
                ]
            )
    if treatment["framework_state"] in {"TRUTH", "RESPONSIBILITY", "TODAY", "COMPLETE"} and kind != "HOOK_FRAMEWORK":
        state_path = work_dir / f"{take['take_id']}-state.txt"
        state_path.write_text(treatment["framework_state"], encoding="utf-8")
        vf.extend(
            [
                "drawbox=x=1540:y=70:w=300:h=74:color=0x081827@0.68:t=fill",
                _text_filter(font, state_path, size=30, x="1570", y="90", color="0xD7A94A"),
            ]
        )
    vf.extend(["format=yuv420p", "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709"])
    return vf


def _build_sfx(plan: dict[str, Any], treatment: dict[str, Any], path: Path) -> dict[str, Any]:
    sample_rate = 48_000
    duration = int(plan["takes"][-1]["end_ms"] / 1000 * sample_rate) + sample_rate
    track = np.zeros(duration, dtype=np.float32)
    rng = np.random.default_rng(74)
    treatment_by_take = {item["take_id"]: item for item in treatment["takes"]}
    event_count = 0
    for take in plan["takes"]:
        kind = treatment_by_take[take["take_id"]]["sfx"]
        if kind == "NONE":
            continue
        start = int(take["start_ms"] / 1000 * sample_rate)
        seconds = 0.20 if kind in {"PEN", "KEYS"} else 0.42
        count = int(seconds * sample_rate)
        t = np.arange(count, dtype=np.float32) / sample_rate
        if kind in {"IMPACT", "PULSE", "RESOLUTION"}:
            frequency = 62 if kind != "RESOLUTION" else 92
            wave = np.sin(2 * np.pi * frequency * t) * np.exp(-8 * t)
            wave += rng.normal(0, 0.06, count).astype(np.float32) * np.exp(-18 * t)
            gain = 0.24 if kind == "IMPACT" else 0.14
        elif kind == "WHOOSH":
            envelope = np.sin(np.pi * np.clip(t / seconds, 0, 1)) ** 2
            wave = rng.normal(0, 1, count).astype(np.float32) * envelope
            gain = 0.055
        else:
            clicks = rng.normal(0, 1, count).astype(np.float32) * np.exp(-30 * t)
            wave = clicks
            gain = 0.025
        end = min(start + count, len(track))
        track[start:end] += wave[: end - start] * gain
        event_count += 1
    stereo = np.column_stack([track, track])
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(path, stereo, sample_rate, subtype="PCM_16")
    return {"path": str(path.resolve()), "content_hash": _sha256(path), "event_count": event_count, "sample_rate": sample_rate}


def _render_thumbnail(root: Path, font: Path) -> dict[str, Any]:
    v2_dir = root / V2
    source = v2_dir / "assets" / "hero-threshold-original-v1.png"
    output = v2_dir / "thumbnail" / "after-you-pray-do-this-next-v2.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    first = output.parent / "thumbnail-01.txt"
    second = output.parent / "thumbnail-02.txt"
    first.write_text("DON'T", encoding="utf-8")
    second.write_text("JUST WAIT", encoding="utf-8")
    vf = ",".join(
        [
            "scale=1280:720:force_original_aspect_ratio=increase",
            "crop=1280:720",
            "eq=contrast=1.12:saturation=0.88:brightness=-0.025",
            "drawbox=x=0:y=0:w=650:h=720:color=0x081827@0.50:t=fill",
            "drawbox=x=72:y=155:w=10:h=410:color=0xD7A94A@1.0:t=fill",
            _text_filter(font, first, size=112, x="120", y="205", color="0xE8EDF2"),
            _text_filter(font, second, size=92, x="120", y="380", color="0xD7A94A"),
            "format=rgb24",
        ]
    )
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(source), "-vf", vf, "-frames:v", "1", str(output)])
    value = {
        "schema_version": "1.0.0",
        "title": "AFTER YOU PRAY, DO THIS NEXT | Christian Motivation",
        "thumbnail_text": "DON'T JUST WAIT",
        "path": str(output.resolve()),
        "content_hash": _sha256(output),
        "width": 1280,
        "height": 720,
        "source_asset": "hero-threshold-original-v1.png",
        "synthetic_content_disclosure": True,
    }
    _write(output.parent / "thumbnail_manifest.json", value)
    return value


def render_creative_v2(root: Path, *, created_at: str | None = None) -> dict[str, Any]:
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / PACKAGE
    v2_dir = root / V2
    plan = _read(v2_dir / "take_plan.json")
    bible = _read(v2_dir / "channel_style_bible.json")
    voice = _read(v2_dir / "audio" / "voice_render_manifest.json")
    treatment = _read(v2_dir / "creative_treatment_plan.json")
    assets = _read(package_dir / "asset_manifest.json")
    pipeline = _read(root / "config" / "macro_pipelines" / "pipeline-clips-longform-v1.json")
    if plan["quality_profile"] != "DRAFT" or voice["status"] != "COMPLETE":
        raise PermissionError("creative-v2 is limited to a complete DRAFT before human review")
    if any(take["rights"]["status"] in {"UNKNOWN", "RESTRICTED", "EDITORIAL_REVIEW_REQUIRED"} for take in plan["takes"]):
        raise PermissionError("creative-v2 take plan contains a rights-blocked asset")
    voice_by_take = {item["take_id"]: item for item in voice["takes"]}
    treatment_by_take = {item["take_id"]: item for item in treatment["takes"]}
    work = v2_dir / "render_work"
    video_dir = work / "video_segments"
    audio_dir = work / "audio_segments"
    video_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    font = _font()
    total_started = time.perf_counter()
    video_started = time.perf_counter()
    video_files: list[Path] = []
    asset_ids: list[str] = []
    timeline: list[dict[str, Any]] = []
    cursor = 0.0
    for take in plan["takes"]:
        take_id = take["take_id"]
        source, source_start, source_end = _origin(take["asset_origin"])
        duration_ms = int(take["end_ms"]) - int(take["start_ms"])
        frame_count = _frames(duration_ms)
        if source_end - source_start + 0.002 < duration_ms / 1000:
            raise ValueError(f"source span too short for {take_id}")
        asset_ids.append(_asset_id(source))
        output = video_dir / f"{take_id}.mp4"
        cache_record = video_dir / f"{take_id}.cache.json"
        fingerprint = _segment_fingerprint(take, treatment_by_take[take_id])
        vf = _visual_filters(take, treatment_by_take[take_id], font=font, work_dir=work)
        reusable = False
        if output.is_file() and cache_record.is_file():
            try:
                cache = _read(cache_record)
                reusable = cache.get("fingerprint") == fingerprint and abs(float(_probe(output)["format"]["duration"]) * 1000 - duration_ms) <= 1000 / OUTPUT_FPS / 2
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                reusable = False
        if not reusable:
            _run(
                [
                    FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{source_start:.3f}", "-i", str(source), "-an",
                    "-vf", ",".join(vf), "-frames:v", str(frame_count), "-r", "30", "-c:v", "libx264", "-profile:v", "high",
                    "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-g", "60", "-keyint_min", "30", "-sc_threshold", "0", "-movflags", "+faststart", str(output),
                ]
            )
            _write(cache_record, {"fingerprint": fingerprint, "take_id": take_id, "created_at": timestamp})
        actual = round(float(_probe(output)["format"]["duration"]) * 1000, 6)
        if abs(actual - duration_ms) > 1000 / OUTPUT_FPS / 2:
            raise RuntimeError(f"segment drift for {take_id}: {actual-duration_ms} ms")
        timeline.append(
            {
                "take_id": take_id,
                "planned_start_ms": int(take["start_ms"]),
                "planned_end_ms": int(take["end_ms"]),
                "actual_start_ms": round(cursor, 6),
                "actual_end_ms": round(cursor + actual, 6),
                "planned_duration_ms": duration_ms,
                "actual_duration_ms": actual,
                "frame_count": frame_count,
            }
        )
        cursor += actual
        video_files.append(output)
    video_seconds = time.perf_counter() - video_started
    audio_started = time.perf_counter()
    audio_files: list[Path] = []
    for take in plan["takes"]:
        take_id = take["take_id"]
        duration = (int(take["end_ms"]) - int(take["start_ms"])) / 1000
        output = audio_dir / f"{take_id}.wav"
        _run(
            [
                FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", voice_by_take[take_id]["path"], "-af",
                f"aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo,highpass=f=65,lowpass=f=15500,acompressor=threshold=0.15:ratio=2.2:attack=16:release=170:makeup=1.20,apad,atrim=0:{duration:.3f}",
                "-c:a", "pcm_s16le", str(output),
            ]
        )
        audio_files.append(output)
    video_list = work / "video-concat.txt"
    audio_list = work / "audio-concat.txt"
    _concat_file(video_list, video_files)
    _concat_file(audio_list, audio_files)
    silent_video = work / "video-concat.mp4"
    narration = work / "narration.wav"
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(video_list), "-c", "copy", str(silent_video)])
    _run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(audio_list), "-c:a", "pcm_s16le", str(narration)])
    sfx = _build_sfx(plan, treatment, work / "creative-sfx.wav")
    audio_seconds = time.perf_counter() - audio_started
    final_started = time.perf_counter()
    render_dir = v2_dir / "renders"
    render_dir.mkdir(parents=True, exist_ok=True)
    output = render_dir / "after-you-pray-do-this-next.phase5-creative-v2-1-draft.mp4"
    duration_seconds = int(plan["takes"][-1]["end_ms"]) / 1000
    _run(
        [
            FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(silent_video), "-i", str(narration), "-i", sfx["path"],
            "-f", "lavfi", "-t", f"{duration_seconds:.3f}", "-i", "anoisesrc=color=pink:amplitude=0.010:sample_rate=48000",
            "-f", "lavfi", "-t", f"{duration_seconds:.3f}", "-i", "sine=frequency=55:sample_rate=48000",
            "-filter_complex",
            "[1:a]volume=1.0[n];[2:a]volume=0.85[sfx];[3:a]highpass=f=90,lowpass=f=460,volume=0.045[amb];[4:a]lowpass=f=110,volume=0.0012[tone];[n][sfx][amb][tone]amix=inputs=4:duration=first:normalize=0,loudnorm=I=-16:LRA=7:TP=-1.3[aout]",
            "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2",
            "-t", f"{duration_seconds:.3f}", "-movflags", "+faststart", str(output),
        ]
    )
    final_seconds = time.perf_counter() - final_started
    total_seconds = time.perf_counter() - total_started
    thumbnail = _render_thumbnail(root, font)
    probe = _probe(output)
    video = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    measured_ms = round(float(probe["format"]["duration"]) * 1000)
    manifest_assets = {item["asset_id"]: item for item in assets["assets"]}
    attribution = v2_dir / "attribution.txt"
    lines = ["HeroVerse creative-v2 DRAFT — source attribution and synthetic-content record", "Publication requires the linked gate and YouTube synthetic-content disclosure.", ""]
    for asset_id in sorted(set(asset_ids)):
        item = manifest_assets[asset_id]
        lines.extend([asset_id, f"Source: {item['source']}", f"Creator/holder: {item.get('creator_or_holder')}", f"Rights: {item['rights_status']} / {item.get('license')}", f"Attribution: {item.get('attribution') or 'None recorded'}", f"Evidence: {item['rights_evidence_uri']}", ""])
    attribution.write_text("\n".join(lines), encoding="utf-8")
    manifest = {
        "schema_version": "1.0.0",
        "render_id": "render-v2-" + hashlib.sha256(f"{plan['take_plan_id']}|{_sha256(output)}".encode()).hexdigest()[:20],
        "status": "COMPLETE",
        "video_id": plan["video_id"],
        "quality_profile": "DRAFT",
        "pipeline_id": pipeline["pipeline_id"],
        "pipeline_version": pipeline["version"],
        "format_pack_id": plan["format_pack_id"],
        "format_pack_version": plan["format_pack_version"],
        "take_plan_id": plan["take_plan_id"],
        "style_bible_id": bible["style_bible_id"],
        "creative_treatment_plan_id": treatment["treatment_plan_id"],
        "creative_treatment_version": treatment["version"],
        "voice_render_id": voice["voice_render_id"],
        "adapter_versions": ["adapter-ffmpeg-local@runtime", "adapter-local-voice@KokoroFloatSpeed-1.0.0", "adapter-openai-imagegen-builtin@observed-2026-09-02"],
        "segment_count": len(video_files),
        "source_asset_ids": sorted(set(asset_ids)),
        "output": {"path": str(output.resolve()), "content_hash": _sha256(output), "container": "mp4", "video_codec": video["codec_name"], "audio_codec": audio["codec_name"], "width": int(video["width"]), "height": int(video["height"]), "fps": round(_fps(video["r_frame_rate"]), 6), "duration_ms": measured_ms, "size_bytes": output.stat().st_size},
        "measurements": {
            "total_wall_seconds": round(total_seconds, 6), "video_segment_render_seconds": round(video_seconds, 6), "audio_assembly_seconds": round(audio_seconds, 6), "final_mux_seconds": round(final_seconds, 6), "real_time_factor": round(total_seconds / (measured_ms / 1000), 6),
            "peak_working_set_mb": None, "peak_working_set_status": "UNAVAILABLE", "output_fps": OUTPUT_FPS, "expected_total_frames": sum(item["frame_count"] for item in timeline),
            "maximum_take_duration_error_ms": round(max(abs(item["planned_duration_ms"] - item["actual_duration_ms"]) for item in timeline), 6),
            "maximum_cumulative_drift_ms": round(max(abs(item["planned_end_ms"] - item["actual_end_ms"]) for item in timeline), 6),
        },
        "segment_timeline": timeline,
        "attribution_path": str(attribution.resolve()),
        "external_cost_usd": 0,
        "publication_approved": False,
        "limitations": ["creative-v2 DRAFT; independent human full-video review remains required", "photorealistic generated hook art requires YouTube synthetic-content disclosure", "local energy, labor and depreciation remain unavailable"],
        "created_at": timestamp,
    }
    Draft202012Validator(_read(root / "schemas" / "render_manifest.schema.json")).validate(manifest)
    _write(v2_dir / "render_manifest.json", manifest)
    _write(package_dir / "render_manifest.json", manifest)
    _write(v2_dir / "thumbnail" / "package_manifest.json", {"title": thumbnail["title"], "thumbnail": thumbnail, "synthetic_content_disclosure": True, "publication_status": "BLOCKED_PENDING_GATES"})
    return manifest
