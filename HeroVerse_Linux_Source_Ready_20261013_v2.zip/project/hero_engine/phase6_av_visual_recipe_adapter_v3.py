"""Active, receipt-bound successor of the frozen take-003 visual adapter.

Version 2 remains the immutable reader for the D-154 evidence set.  It must
never be repinned when a legitimate new production-input receipt is created.
This module is the separate active consumer: it binds the four mutable visual
documents to one explicit current production receipt, then reuses the pure v2
compiler under that bounded input contract.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from threading import RLock
from typing import Any

from . import phase6_av_visual_recipe_adapter as _v2
from . import phase6_visual_recipe as _visual_recipe


ADAPTER_VERSION = "phase6-av-take003-editorial-visual-adapter-v3"
PRODUCTION_RECEIPT_PATH = "output/production/phase6/video-002/production/production_inputs_receipt.json"
_ACTIVE_ROLES = {
    "take_plan": "output/production/phase6/video-002/production/take_plan.json",
    "treatment_plan": "output/production/phase6/video-002/production/creative_treatment_plan.json",
    "allocation": "output/production/phase6/video-002/production/asset_allocation.json",
    "style_bible": "output/production/phase6/video-002/production/channel_style_bible.json",
}
_LOCK = RLock()

AVVisualRecipeAdapterError = _v2.AVVisualRecipeAdapterError
CHANNEL_ID = _v2.CHANNEL_ID
VIDEO_ID = _v2.VIDEO_ID
EXPECTED_NARRATION = _v2.EXPECTED_NARRATION


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _root(root: Path) -> Path:
    return _v2._workspace_root(Path(root))


def _relative(root: Path, path: Path) -> str:
    return _v2._normalize_path(root, path)


def _read_receipt(root: Path, supplied: dict[str, Any] | None) -> tuple[dict[str, Any], dict[str, Any]]:
    if not isinstance(supplied, dict) or set(supplied) != {"path", "sha256", "size_bytes"}:
        raise AVVisualRecipeAdapterError("production_inputs_receipt: binding fields differ")
    path = (root / PRODUCTION_RECEIPT_PATH).resolve(strict=True)
    try:
        actual = (root / str(supplied["path"])).resolve(strict=True)
    except (TypeError, OSError) as exc:
        raise AVVisualRecipeAdapterError("production_inputs_receipt: path is invalid") from exc
    if actual != path:
        raise AVVisualRecipeAdapterError("production_inputs_receipt: path differs from active receipt")
    raw = actual.read_bytes()
    if type(supplied["size_bytes"]) is not int or supplied["size_bytes"] != len(raw) or supplied["sha256"] != _sha(raw):
        raise AVVisualRecipeAdapterError("production_inputs_receipt: bound bytes changed")
    try:
        value = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise AVVisualRecipeAdapterError("production_inputs_receipt: invalid JSON") from exc
    if not isinstance(value, dict) or value.get("status") != "COMPILED" or value.get("channel_id") != CHANNEL_ID:
        raise AVVisualRecipeAdapterError("production_inputs_receipt: active receipt contract differs")
    artifacts = value.get("artifacts")
    if not isinstance(artifacts, list):
        raise AVVisualRecipeAdapterError("production_inputs_receipt: artifacts are missing")
    by_path: dict[str, dict[str, Any]] = {}
    for row in artifacts:
        if not isinstance(row, dict) or set(row) != {"path", "sha256", "size_bytes"} or row["path"] in by_path:
            raise AVVisualRecipeAdapterError("production_inputs_receipt: artifact shape differs")
        by_path[row["path"]] = row
    if set(_ACTIVE_ROLES.values()) - set(by_path):
        raise AVVisualRecipeAdapterError("production_inputs_receipt: active visual artifacts differ")
    return value, {"path": PRODUCTION_RECEIPT_PATH, "sha256": _sha(raw), "size_bytes": len(raw)}


def _expected_from_receipt(root: Path, receipt: dict[str, Any]) -> dict[str, tuple[str, str]]:
    expected = copy.deepcopy(_v2._EXPECTED)
    artifacts = {row["path"]: row for row in receipt["artifacts"]}
    for role, path in _ACTIVE_ROLES.items():
        row = artifacts[path]
        if (not isinstance(row["sha256"], str) or not row["sha256"].startswith("sha256:")
                or type(row["size_bytes"]) is not int or row["size_bytes"] < 1):
            raise AVVisualRecipeAdapterError(f"production_inputs_receipt: {role} artifact pin is invalid")
        actual = (root / path).resolve(strict=True)
        raw = actual.read_bytes()
        if len(raw) != row["size_bytes"] or _sha(raw) != row["sha256"]:
            raise AVVisualRecipeAdapterError(f"production_inputs_receipt: {role} artifact bytes changed")
        expected[role] = (path, row["sha256"][7:])
    return expected


def active_bindings(root: Path) -> dict[str, dict[str, Any]]:
    """Return exact bindings for the active receipt; no authority is granted."""
    root = _root(root)
    receipt_path = root / PRODUCTION_RECEIPT_PATH
    receipt_raw = receipt_path.read_bytes()
    receipt, receipt_pin = _read_receipt(root, {
        "path": PRODUCTION_RECEIPT_PATH, "sha256": _sha(receipt_raw), "size_bytes": len(receipt_raw),
    })
    expected = _expected_from_receipt(root, receipt)
    result: dict[str, dict[str, Any]] = {"production_inputs_receipt": receipt_pin}
    for role, (name, digest) in expected.items():
        path = Path(name) if Path(name).is_absolute() else root / name
        raw = path.read_bytes()
        result[role] = {"path": _relative(root, path.resolve()), "sha256": _sha(raw), "size_bytes": len(raw)}
        if result[role]["sha256"] != "sha256:" + digest:
            raise AVVisualRecipeAdapterError(f"{role}: active binding does not match receipt or frozen dependency")
    return result


def _compile(root: Path, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    root = _root(root)
    required = set(_v2._EXPECTED) | {"production_inputs_receipt"}
    if not isinstance(bindings, dict) or set(bindings) != required:
        raise AVVisualRecipeAdapterError("external binding roles differ")
    receipt, receipt_pin = _read_receipt(root, bindings["production_inputs_receipt"])
    expected = _expected_from_receipt(root, receipt)
    # Reuse only v2's strict binding reader.  Its editor-hook compiler is
    # deliberately historical and cannot be made active by changing its pins.
    # The active semantic/layout compiler is phase6_visual_recipe v4.
    with _LOCK:
        original = _v2._EXPECTED
        _v2._EXPECTED = expected
        try:
            opened = {
                role: _v2._open_external_binding(root, role, bindings[role])
                for role in _v2._EXPECTED
            }
        finally:
            _v2._EXPECTED = original
    take_plan = _v2._json(opened["take_plan"][1], "take_plan")
    treatment_plan = _v2._json(opened["treatment_plan"][1], "treatment_plan")
    takes = [row for row in take_plan.get("takes", []) if isinstance(row, dict) and row.get("take_id") == _v2.TAKE_ID]
    treatments = [row for row in treatment_plan.get("takes", []) if isinstance(row, dict) and row.get("take_id") == _v2.TAKE_ID]
    if len(takes) != 1 or len(treatments) != 1:
        raise AVVisualRecipeAdapterError("active production receipt does not contain one take-003 treatment pair")
    take, treatment = takes[0], treatments[0]
    if take.get("narration") != EXPECTED_NARRATION:
        raise AVVisualRecipeAdapterError("active take-003 narration differs from the channel contract")
    layout = _visual_recipe.inspect_visual_layout(take, treatment, font=opened["font"][2])
    if not layout["all_text_safe"] or not layout["all_copy_preserved"]:
        raise AVVisualRecipeAdapterError("active visual layout did not preserve readable planned copy")
    if layout["minimum_font_size"] is not None and layout["minimum_font_size"] < _visual_recipe.MINIMUM_FONT_SIZE:
        raise AVVisualRecipeAdapterError("active visual layout font is below the Style Bible minimum")
    if treatment["treatment"] in _visual_recipe.TEXT_REQUIRED_TREATMENTS and not layout["main_overlay_present"]:
        raise AVVisualRecipeAdapterError("active required visual treatment is missing its planned text")
    if any(row["source_text"] != row["render_text"].replace("\n", " ") for row in layout["overlays"]):
        raise AVVisualRecipeAdapterError("active renderer text differs from planned text")
    generated_files = [{
        "role": row["role"], "relative_path": f"meta/visual/take-003/{row['filename']}",
        "sha256": _sha(row["render_text"].encode("utf-8")),
        "size_bytes": len(row["render_text"].encode("utf-8")), "content_utf8": row["render_text"],
    } for row in layout["overlays"]]
    font_path = str(opened["font"][2].resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
    filters = list(_visual_recipe.BASE_FILTERS) + list(layout["decorations"])
    for row in layout["overlays"]:
        logical = f"meta/visual/take-003/{row['filename']}"
        filters.append(
            "drawtext=" + f"fontfile='{font_path}':textfile='{logical}':expansion=none:"
            + f"fontcolor={row['color']}:fontsize={row['font_size']}:borderw={_visual_recipe.TEXT_BORDER}:"
            + f"bordercolor=0x081827@0.85:x={row['x']}:y={row['y']}:line_spacing={_visual_recipe.LINE_SPACING}"
        )
    filters.extend(_visual_recipe.OUTPUT_FILTERS)
    implementation_path = root / "hero_engine/phase6_av_visual_recipe_adapter_v3.py"
    visual_path = root / "hero_engine/phase6_visual_recipe.py"
    implementation = [
        {"path": _relative(root, implementation_path), "sha256": _sha(implementation_path.read_bytes()), "size_bytes": implementation_path.stat().st_size},
        {"path": _relative(root, visual_path), "sha256": _sha(visual_path.read_bytes()), "size_bytes": visual_path.stat().st_size},
    ]
    dependencies = [opened[role][0] for role in opened] + [receipt_pin] + implementation
    dependency_bindings = sorted(copy.deepcopy(dependencies), key=lambda row: (row["path"], row["sha256"]))
    dependency_roles = sorted(
        [{"role": role, "path": opened[role][0]["path"], "sha256": opened[role][0]["sha256"]} for role in opened]
        + [{"role": "active_production_receipt", "path": receipt_pin["path"], "sha256": receipt_pin["sha256"]}]
        + [{"role": "active_visual_recipe_implementation", "path": row["path"], "sha256": row["sha256"]} for row in implementation],
        key=lambda row: (row["role"], row["path"]),
    )
    start_ms, end_ms = take["start_ms"], take["end_ms"]
    if not isinstance(start_ms, int) or not isinstance(end_ms, int) or end_ms <= start_ms:
        raise AVVisualRecipeAdapterError("active take-003 span is invalid")
    local_frames = (end_ms - start_ms) * 30 // 1000
    spec: dict[str, Any] = {
        "schema_version": "1.0.0", "adapter_version": ADAPTER_VERSION,
        "status": "COMPILED_TAKE003_VISUAL_SPEC_NOT_ADMITTED",
        "scope": "TAKE003_ACTIVE_RECEIPT_BOUND_VISUAL_SPEC_ONLY",
        "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "take_id": _v2.TAKE_ID,
        "recipe_id": layout["recipe_id"], "plan_id": take_plan.get("take_plan_id"),
        "timeline_contract": _v2._strict_timeline_context(timeline),
        "source_binding": copy.deepcopy(opened["retained_source"][0]), "filtergraph": ",".join(filters),
        "generated_files": generated_files, "dependency_bindings": dependency_bindings,
        "dependency_roles": dependency_roles, "active_production_receipt_binding": receipt_pin,
        "supported_span": {"fps": 30, "global_start_frame": start_ms * 30 // 1000,
            "global_end_frame_exclusive": end_ms * 30 // 1000, "local_start_frame": 0,
            "local_end_frame_exclusive": local_frames, "source_start_frame": 0,
            "source_end_frame_exclusive": local_frames, "local_event_boundaries": [0, local_frames],
            "start_ms": start_ms, "end_ms": end_ms},
        "coverage": {"covered_take_ids": [_v2.TAKE_ID], "covered_frame_count": local_frames,
            "planned_total_frame_count": _v2._strict_timeline_context(timeline)["planned_total_frames"],
            "full_timeline_covered": False, "audio_covered": False, "captions_rendered": False,
            "semantics_approved": False, "motion_approved": False},
        "geometry_observation": {"status": "PASS_LAYOUT_MEASURED_ONLY", "layout": layout},
        "blockers": ["STAGE_A_VERIFICATION_AND_ADMISSION_REQUIRED", "TAKE003_ONLY_FULL_TIMELINE_COVERAGE_INCOMPLETE",
            "RIGHTS_PUBLICITY_MOTION_AUDIO_AND_FINAL_QUALITY_GATES_NOT_EVALUATED", "QUEUE_COMMIT_REQUIRED_BEFORE_MATERIALIZATION"],
        "authority": copy.deepcopy(_v2._FALSE_AUTHORITY), "technical_cost_brl": 0,
    }
    spec["visual_spec_id"] = "phase6-av-visual-spec-" + _v2._canonical_sha(copy.deepcopy(spec))[7:31]
    spec["canonical_sha256"] = _v2._canonical_sha(spec)
    return spec


def compile_take003_editorial_visual_spec(root: Path, *, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    return _compile(root, timeline, bindings)


def verify_take003_editorial_visual_spec(root: Path, candidate: dict[str, Any], *, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    expected = _compile(root, timeline, bindings)
    if _v2._canonical(candidate) != _v2._canonical(expected):
        raise AVVisualRecipeAdapterError("visual spec differs from pure recompilation")
    return copy.deepcopy(expected)
