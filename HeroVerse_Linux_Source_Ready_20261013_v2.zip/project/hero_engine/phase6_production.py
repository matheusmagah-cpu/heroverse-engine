from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .adaptive_editorial import BRIEF_STRATEGIES
from .phase6_creative_compiler import (
    COMPILER_VERSION,
    HOOK_SLOT_MS,
    VOICE_ID,
    VOICE_BODY_HEADROOM_MINIMUM_MS,
    VOICE_BODY_HEADROOM_RATIO,
    VOICE_DURATION_GRID_MS,
    VOICE_TIMING_EXECUTION_CONTRACT_VERSION,
    VOICE_TIMING_PROFILE_VERSION,
    build_creative_compiler_identity,
    estimate_spoken_duration_ms,
    planned_voice_speed,
    required_body_voice_headroom_ms,
    select_creative_concept,
    validate_planned_voice_slots,
)
from .phase6_packaging_compiler import build_packaging_search
from .phase5_integrity_successor_consumer import (
    SUCCESSOR_NAME as PHASE5_INTEGRITY_SUCCESSOR_NAME,
    IntegritySuccessorConsumerError,
    read_current_integrity_successor,
)


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
CHANNEL_HANDLE = "heroverse74"
CANARY_VIDEO_ID = "iK_5edYQtx8"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
BASE = Path("output/operations/phase6/production")
VIDEO2 = Path("output/production/phase6/video-002/preproduction")
PACKAGE_UPDATE = Path("output/production/phase6/canary-package-update/preproduction")
FORMAT_SCOPE = BASE / "format-scope-receipt.json"
PREPRODUCTION_RECEIPTS = BASE / "preproduction-receipts"
PREPRODUCTION_ARTIFACTS = BASE / "preproduction-artifacts"
MIN_MARKET_OPPORTUNITY_SCORE = 0.65
EVIDENCE_CLASS_RANK = {"METADATA_ONLY": 1, "OPENING_ONLY": 2, "FULL": 3}
MARKET_SELECTION_POLICY_VERSION = "phase6-market-selection-score-first-v1"
PREPRODUCTION_COMPILER_IDENTITY_VERSION = "phase6-preproduction-compiler-identity-v1"
PREPRODUCTION_RECIPE_VERSION = "phase6-preproduction-recipe-v3"


def load_checked_phase5_assets(root: Path) -> dict[str, Any]:
    """Load Phase 5 assets and enforce a committed current successor if present."""
    root = Path(root).resolve(strict=True)
    package = root / "output/production/phase5/pilot-001"
    assets_path = package / "asset_manifest.json"
    if (package / PHASE5_INTEGRITY_SUCCESSOR_NAME).is_file():
        try:
            successor = read_current_integrity_successor(root)
        except IntegritySuccessorConsumerError as exc:
            raise PermissionError("phase5 integrity successor blocks production inputs") from exc
        actual = hashlib.sha256(assets_path.read_bytes()).hexdigest()
        row = next((item for item in successor["entries"] if item["artifact"] == "asset_manifest.json"), None)
        if not isinstance(row, dict) or row.get("sha256") != actual or row.get("bytes") != assets_path.stat().st_size:
            raise PermissionError("phase5 current asset manifest differs from committed integrity successor")
    return _read(assets_path)


TREATMENT_RECIPES: dict[str, dict[str, Any]] = {
    "TOPIC_ANGLE": {
        "change_only": ["topic_cluster", "problem_angle", "promise_subject"],
        "implementation": [
            "Select the highest-ranked eligible non-prayer ChannelDNA-compatible candidate with recorded evidence depth.",
            "Write a new thesis and sequence from blank; inherit no wording, audio, edit sequence or branded identity from a reference.",
            "Keep the approved direct-anchor hook grammar, duration band, voice, FormatPack, quality profile and release gates locked.",
        ],
        "success_metric": "owned cumulative views at the preregistered comparable window",
        "failure_rule": "Below the exploratory view floor remains inconclusive; it never proves that the creative or topic failed.",
    },
    "TITLE_THUMBNAIL_PROMISE": {
        "change_only": ["title", "thumbnail", "combined_promise_wording"],
        "implementation": [
            "Search at least six distinct title-thumbnail routes, reject any promise not delivered by the existing canary, and retain exactly three evidence-safe finalists.",
            "Keep the public video, topic, hook, body, duration, voice, visual sequence and description unchanged.",
            "Run identity, legibility, policy, rights and promise-delivery gates before a metadata update; preserve the prior package for rollback.",
        ],
        "success_metric": "videoThumbnailImpressionsClickRate at a new comparable owned reach window",
        "failure_rule": "Do not declare uplift without comparable Reporting data; rollback on misleading-promise, identity or policy failure.",
    },
    "FIRST_8_SECONDS_MECHANISM": {
        "change_only": ["0_1S_contradiction", "1_3S_consequence", "3_8S_mechanism", "hook_visual_events", "hook_audio_events"],
        "implementation": [
            "Write and time a new 0–1/1–3/3–8 second sequence before rendering any body take.",
            "Use three distinct semantic sources, at least four visual events and a spoken promise that fits measured voice slots.",
            "Keep topic cluster, package grammar, body progression, duration band, voice, visual bible and release gates locked.",
        ],
        "success_metric": "intro30sAudienceWatchRatio at the preregistered comparable window",
        "failure_rule": "Fail preproduction if narration does not fit, the promise is not delivered, or visual proof is decorative.",
    },
    "BODY_PROGRESSIVE_DISCLOSURE": {
        "change_only": ["post_8s_information_order", "micro_payoff_spacing", "body_pattern_interrupts"],
        "implementation": [
            "Preserve the approved 0–8 second mechanism and reorganize only the body into question, test, example, boundary and payoff loops.",
            "Place an information-bearing payoff or reversal at least every 25 seconds; decorative cuts do not count.",
            "Keep topic, title-thumbnail grammar, duration band, voice, visual bible and release gates locked.",
        ],
        "success_metric": "averageViewPercentage at the preregistered comparable window",
        "failure_rule": "Fail preproduction if a body block withholds progress for more than 25 seconds or repeats a claim without new proof.",
    },
}

LOCKED_CONSTANTS = [
    "channel UCuMF6pJQkyMzaVoAxFL86yA and English Christian-motivation niche",
    "FormatPack fp-broll-cinematic-narration@1.1.0",
    "pipeline-clips-longform-v1",
    "STANDARD 1920x1080 30fps profile",
    "am_onyx local English voice identity",
    "HeroVerse Channel Style Bible palette and typography",
    "207750–286250 ms duration band for a new long-form treatment",
    "zero technical cost and no paid traffic",
    "rights, originality, channel-readiness and publication gates",
]


SPIRITUAL_WARFARE_SECTIONS = [
    {
        "section_id": "S1", "role": "TITLE_ALIGNED_STAKE", "narrative_function": "expose the first hidden battle",
        "text": "Pressure speaks before you answer it. A closed door becomes proof that you are forgotten. A delayed reply becomes proof that rejection is coming. A hard morning becomes proof that God has left. The event is real, but the name fear gives it is an interpretation. If you accept that name without testing it, panic begins making decisions before faith enters the room.",
        "intended_emotion": "recognition", "semantic_role": "tension", "retention_job": "make the invisible interpretation visible before thirty seconds", "source_refs": ["2 Corinthians 10:3-5", "channel-model:B1"], "on_screen_text": "PRESSURE IS NOT THE VERDICT",
    },
    {
        "section_id": "S2", "role": "PERSONAL_STAKES", "narrative_function": "separate fact from fearful meaning",
        "text": "Begin with two columns. In the first, write only what happened. In the second, write what fear says it means. The meeting changed is a fact. My future is ruined is a forecast. The person has not replied is a fact. I will always be abandoned is a sentence fear wrote about your identity. This separation does not deny pain. It stops pain from pretending to know the whole future.",
        "intended_emotion": "clarity", "semantic_role": "truth_test_infographic", "retention_job": "deliver a usable distinction and first micro-payoff", "source_refs": ["Philippians 4:8", "original-framework:fact-meaning"], "on_screen_text": "FACT  /  FEAR'S MEANING",
    },
    {
        "section_id": "S3", "role": "MECHANISM_AND_PROOF", "narrative_function": "test the interpretation",
        "text": "Now test the fearful meaning. Is it fully true, or only possible? Does it agree with the character you are called to practice? Does it produce a responsible action, or only urgency, isolation, revenge, and paralysis? Scripture describes a battle of thoughts that must be examined, not obeyed automatically. A thought can be loud without being wise. An emotion can be honest without becoming your commander.",
        "intended_emotion": "discernment", "semantic_role": "scriptural_mechanism", "retention_job": "connect belief to an observable decision test", "source_refs": ["2 Corinthians 10:5", "James 3:13-18"], "on_screen_text": "LOUD IS NOT TRUE",
    },
    {
        "section_id": "S4", "role": "REVERSAL_AND_ACTION", "narrative_function": "choose one grounded response",
        "text": "Replace the untested meaning with a response you can defend. I do not know the outcome, but I can prepare for the meeting. I cannot control the reply, but I can speak truthfully and keep my boundary. I cannot erase uncertainty tonight, but I can ask for counsel, complete the next task, and refuse the impulse that would create more damage. Faith is not pretending the pressure is small. It is refusing to let pressure write your identity or choose your behavior.",
        "intended_emotion": "agency", "semantic_role": "decision", "retention_job": "convert interpretation into bounded action", "source_refs": ["James 1:5", "channel-model:B4"], "on_screen_text": "CHOOSE THE RESPONSE",
    },
    {
        "section_id": "S5", "role": "MECHANISM_AND_PROOF", "narrative_function": "install a repeatable three-move practice",
        "text": "Use three moves when pressure rises. Name the fact without adding a prophecy. Test the meaning against truth, character, consequences, and wise counsel. Choose one faithful response that can be completed today. Then record what happened. That final record matters because fear edits its old predictions after the result. Written evidence helps you learn which warnings protected you and which stories only exhausted you.",
        "intended_emotion": "control", "semantic_role": "decision_cards", "retention_job": "make the method memorable and measurable", "source_refs": ["original-framework:name-test-choose", "channel-model:concrete_response"], "on_screen_text": "NAME. TEST. CHOOSE.",
    },
    {
        "section_id": "S6", "role": "REVERSAL_AND_ACTION", "narrative_function": "set safety and factual boundaries",
        "text": "This practice is not permission to ignore danger, professional advice, legal duties, or the rights of another person. If there is abuse, self-harm, medical danger, or immediate risk, do not reduce the situation to a private spiritual exercise. Contact appropriate emergency, medical, legal, pastoral, or safeguarding support. A grounded response can include leaving, documenting, reporting, or asking qualified people to stand with you.",
        "intended_emotion": "earned safety", "semantic_role": "safe_boundaries", "retention_job": "prevent reckless or guaranteed-outcome interpretation", "source_refs": ["channel-model:risk_controls", "editorial:safety-boundary"], "on_screen_text": "WISDOM DOES NOT HIDE DANGER",
    },
    {
        "section_id": "S7", "role": "PROMISE_RESOLUTION", "narrative_function": "resolve identity and action",
        "text": "The pressure may remain after the thought is tested. The door may still be closed. The answer may still be delayed. But the first battle changes when fear loses the right to define the moment. Name what happened. Test what it means. Choose what faithfulness requires today. Pressure can describe the weather around you. It does not get to name you, predict your whole future, or command your next move.",
        "intended_emotion": "quiet resolve", "semantic_role": "renewal", "retention_job": "close title, method and identity loop", "source_refs": ["brief:combined_promise", "channel-model:B5"], "on_screen_text": "PRESSURE DOESN'T NAME YOU",
    },
]


PRAYER_SECTIONS = [
    {
        "section_id": "S1", "role": "TITLE_ALIGNED_STAKE", "narrative_function": "surface the cost of waiting for complete certainty",
        "text": "You asked for clarity, but complete certainty did not arrive. So the apology stays unwritten, the application stays closed, and the hard conversation moves to another day. Waiting can look spiritual while fear quietly keeps control. The question is not whether you know the whole road. It is whether enough truth is already visible for one faithful and responsible step.",
        "intended_emotion": "recognition", "semantic_role": "contemplation", "retention_job": "turn the promise into a personal cost before thirty seconds", "source_refs": ["James 1:5", "channel-model:B1"], "on_screen_text": "WAITING FOR PERFECT CERTAINTY?",
    },
    {
        "section_id": "S2", "role": "MECHANISM_AND_PROOF", "narrative_function": "define sufficient clarity",
        "text": "Sufficient clarity is smaller than a prediction. It names what is true now, what responsibility belongs to you, and what action respects wise boundaries. It does not promise another person's response. It does not turn a feeling into God's guarantee. It gives you enough light to test one step without pretending that the final outcome is yours to control.",
        "intended_emotion": "clarity", "semantic_role": "truth_test_infographic", "retention_job": "deliver the operating definition", "source_refs": ["James 1:22-25", "original-framework:sufficient-clarity"], "on_screen_text": "ENOUGH LIGHT FOR ONE STEP",
    },
    {
        "section_id": "S3", "role": "PERSONAL_STAKES", "narrative_function": "contrast discernment and avoidance",
        "text": "Discernment tests a move. Avoidance keeps moving the test. Discernment asks what is true, who may be affected, which counsel is needed, and what consequence you can responsibly carry. Avoidance asks for a sign that removes every risk. One process produces a bounded decision. The other turns uncertainty into a permanent hiding place.",
        "intended_emotion": "sober honesty", "semantic_role": "trusted_counsel", "retention_job": "give the viewer a diagnostic contrast", "source_refs": ["James 3:13-18", "channel-model:B2"], "on_screen_text": "TESTING — OR HIDING?",
    },
    {
        "section_id": "S4", "role": "REVERSAL_AND_ACTION", "narrative_function": "apply the three tests",
        "text": "Test the step three times. Truth: does it require deception, revenge, or a promise that was never made? Responsibility: does it own your part without controlling someone else? Today: can it become a message, a question, a scheduled appointment, a completed task, or a boundary within the next twenty-four hours? If it fails one test, revise the step. If it passes, action can teach what waiting cannot.",
        "intended_emotion": "agency", "semantic_role": "decision_cards", "retention_job": "make the framework executable", "source_refs": ["James 1:22-25", "channel-model:B4"], "on_screen_text": "TRUTH. RESPONSIBILITY. TODAY.",
    },
    {
        "section_id": "S5", "role": "MECHANISM_AND_PROOF", "narrative_function": "show bounded examples",
        "text": "A relationship problem may call for an apology without demanding reconciliation. A career question may call for one application, one skill session, or one precise request for feedback. Anxiety may call for putting the phone down and contacting someone trustworthy. None of these actions guarantees an outcome. Each replaces passive uncertainty with evidence you can examine.",
        "intended_emotion": "practical hope", "semantic_role": "progress", "retention_job": "prove the framework across concrete situations", "source_refs": ["channel-model:concrete_response", "brief:payoff"], "on_screen_text": "MAKE THE STEP BOUNDED",
    },
    {
        "section_id": "S6", "role": "REVERSAL_AND_ACTION", "narrative_function": "set safety boundaries",
        "text": "A faithful step never requires you to ignore abuse, medical danger, legal duty, or professional advice. Serious risk needs qualified support, not a dramatic private interpretation. Wisdom may mean pausing, documenting, leaving, calling emergency services, or asking a trusted person to stand with you. Courage and caution can serve the same truth.",
        "intended_emotion": "earned safety", "semantic_role": "safe_boundaries", "retention_job": "block harmful certainty and impulsive action", "source_refs": ["channel-model:risk_controls", "editorial:safety-boundary"], "on_screen_text": "WISE BOUNDARIES ARE FAITHFUL",
    },
    {
        "section_id": "S7", "role": "PROMISE_RESOLUTION", "narrative_function": "resolve clarity through action",
        "text": "You may not receive the whole map today. You can still refuse the lie that uncertainty means paralysis. Name what is true. Accept what is yours. Choose the smallest faithful action that passes the tests, complete it, and record what it teaches. Clarity does not always arrive before movement. Sometimes honest movement reveals the next piece of clarity.",
        "intended_emotion": "quiet resolve", "semantic_role": "renewal", "retention_job": "close the question and deliver the promised action", "source_refs": ["brief:combined_promise", "channel-model:B5"], "on_screen_text": "TAKE THE TESTED STEP",
    },
]


def preproduction_recipe_identity_payload() -> dict[str, Any]:
    """Return declarative production inputs whose drift changes output bytes."""

    return {
        "recipe_version": PREPRODUCTION_RECIPE_VERSION,
        "treatment_recipes": deepcopy(TREATMENT_RECIPES),
        "locked_constants": deepcopy(LOCKED_CONSTANTS),
        "spiritual_warfare_sections": deepcopy(SPIRITUAL_WARFARE_SECTIONS),
        "prayer_sections": deepcopy(PRAYER_SECTIONS),
        "market_selection_policy_version": MARKET_SELECTION_POLICY_VERSION,
        "minimum_market_opportunity_score": MIN_MARKET_OPPORTUNITY_SCORE,
        "duration_band_ms": [207_750, 286_250],
        "body_chunk_maximum_words": 12,
        "body_take_duration_minimum_ms": 2_200,
        "body_take_duration_maximum_ms": 6_500,
        "format_pack": "fp-broll-cinematic-narration@1.1.0",
        "pipeline": "pipeline-clips-longform-v1",
        "quality_profile": "STANDARD",
    }


def build_preproduction_compiler_identity(
    *,
    creative_identity: dict[str, Any] | None = None,
    production_source_bytes: bytes | None = None,
    recipe_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Bind compiler code, declarative copy and the voice profile as one unit."""

    creative = (
        build_creative_compiler_identity()
        if creative_identity is None else deepcopy(creative_identity)
    )
    source = (
        Path(__file__).read_bytes()
        if production_source_bytes is None else production_source_bytes
    )
    recipe = (
        preproduction_recipe_identity_payload()
        if recipe_payload is None else deepcopy(recipe_payload)
    )
    identity = {
        "identity_version": PREPRODUCTION_COMPILER_IDENTITY_VERSION,
        "compiler_version": COMPILER_VERSION,
        "creative_identity_sha256": creative["identity_sha256"],
        "compiler_source_path": creative["source_path"],
        "compiler_code_sha256": creative["code_sha256"],
        "creative_recipe_content_sha256": creative["recipe_content_sha256"],
        "production_recipe_version": PREPRODUCTION_RECIPE_VERSION,
        "production_source_path": "hero_engine/phase6_production.py",
        "production_code_sha256": f"sha256:{hashlib.sha256(source).hexdigest()}",
        "production_recipe_content_sha256": _canonical_content_hash(recipe),
        "voice_id": VOICE_ID,
        "voice_profile_version": creative["voice_profile_version"],
        "voice_profile_content_sha256": creative["voice_profile_content_sha256"],
        "voice_execution_contract_version": VOICE_TIMING_EXECUTION_CONTRACT_VERSION,
    }
    identity["identity_sha256"] = _canonical_content_hash(identity)
    return identity


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _optional(path: Path) -> dict[str, Any]:
    try:
        return _read(path) if path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, *parts: Any) -> str:
    digest = hashlib.sha256("|".join(str(part) for part in parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical_content_hash(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def _verify_order_compiler_identity(order: dict[str, Any]) -> dict[str, Any]:
    """Reject an order made by different code, recipe copy or voice planning."""

    if order.get("schema_version") != "1.1.0":
        raise PermissionError(
            "legacy treatment order has no immutable compiler/content identity"
        )
    bound = order.get("compiler_identity")
    current = build_preproduction_compiler_identity()
    if bound != current:
        raise PermissionError(
            "treatment order compiler/code/recipe/voice identity changed"
        )
    return current


def _format_scope_substantive_payload(value: dict[str, Any]) -> dict[str, Any]:
    """Return the immutable scope contract without derived/volatile fields."""

    payload = deepcopy(value)
    payload.pop("receipt_id", None)
    payload.pop("created_at", None)
    return payload


def _format_scope_receipt_id(value: dict[str, Any]) -> str:
    """Bind the receipt identity to every substantive scope decision."""

    return _stable_id(
        "phase6-format-scope",
        "substantive-content-v1",
        _canonical_content_hash(_format_scope_substantive_payload(value)),
    )


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))
    temporary.unlink(missing_ok=True)


def _validate(root: Path, schema: str, value: dict[str, Any]) -> None:
    Draft202012Validator(
        _read(root / "schemas" / schema), format_checker=FormatChecker(),
    ).validate(value)


def _resolve_protocol(root: Path) -> tuple[Path, dict[str, Any], bool]:
    """Resolve the live preregistration to its immutable active twin.

    Waiting protocols remain mutable views by design. Once a protocol is
    PREREGISTERED, production may consume it only when active/latest are
    byte-identical and the active document uses the immutable-source contract.
    """

    latest = root / "output/operations/phase6/intelligence/experiments/latest.json"
    protocol = _optional(latest)
    if protocol.get("status") != "PREREGISTERED":
        return latest, protocol, True
    active = root / "output/operations/phase6/intelligence/experiments/active.json"
    try:
        if not active.is_file() or active.read_bytes() != latest.read_bytes():
            raise PermissionError("active/latest protocol divergence")
        protocol = _read(active)
        _validate(root, "phase6_experiment_protocol.schema.json", protocol)
        if protocol.get("schema_version") != "1.1.0":
            raise PermissionError("live preregistration does not pin immutable sources")
        return active, protocol, True
    except Exception:
        return latest, protocol, False


def _resolve_protocol_diagnosis(
    root: Path,
    protocol: dict[str, Any],
) -> tuple[Path, dict[str, Any], bool]:
    latest = root / "output/operations/phase6/intelligence/diagnoses/latest.json"
    if protocol.get("status") != "PREREGISTERED":
        return latest, _optional(latest), True
    try:
        reference = protocol.get("diagnosis") or {}
        diagnosis_id = str(reference.get("diagnosis_id") or "")
        relative = str(reference.get("path") or "")
        path = (root / relative).resolve()
        path.relative_to(
            (root / "output/operations/phase6/intelligence/diagnoses").resolve()
        )
        if not diagnosis_id or path.name != f"{diagnosis_id}.json" or path.name == "latest.json":
            raise PermissionError("protocol diagnosis identity is not immutable")
        diagnosis = _read(path)
        _validate(root, "phase6_diagnostic_decision.schema.json", diagnosis)
        if not (
            diagnosis.get("diagnosis_id") == diagnosis_id
            and diagnosis.get("channel_id") == CHANNEL_ID
            and diagnosis.get("status") == "DIAGNOSED"
        ):
            raise PermissionError("protocol diagnosis content does not match its identity")
        return path, diagnosis, True
    except Exception:
        return latest, _optional(latest), False


def _resolve_protocol_baseline_metrics(
    root: Path,
    protocol: dict[str, Any],
) -> tuple[Path, dict[str, Any], bool]:
    """Resolve production evidence without rebinding an active protocol to latest.

    Before preregistration, ``latest.json`` is the intended mutable view. Once a
    protocol is active, its named baseline snapshot is the only admissible source.
    A same-identity latest view must still be byte-identical to that immutable
    snapshot; a later snapshot is allowed to exist but cannot change this order.
    """

    metrics_root = (
        root / "output/operations/phase6/metrics" / CANARY_VIDEO_ID
    ).resolve()
    latest = metrics_root / "latest.json"
    if protocol.get("status") != "PREREGISTERED":
        return latest, _optional(latest), True

    reference = (protocol.get("baseline") or {}).get("snapshot_id")
    if not isinstance(reference, str) or not reference.strip():
        return latest, {}, False
    immutable = (metrics_root / f"{reference}.json").resolve()
    if immutable.parent != metrics_root or immutable.name != f"{reference}.json":
        return immutable, {}, False

    try:
        if not immutable.is_file():
            return immutable, {}, False
        value = _read(immutable)
        _validate(root, "own_channel_performance_snapshot.schema.json", value)
        if not (
            value.get("snapshot_id") == reference
            and value.get("channel_id") == CHANNEL_ID
            and value.get("video_id") == CANARY_VIDEO_ID
        ):
            return immutable, value, False
        if latest.is_file():
            latest_value = _read(latest)
            if (
                latest_value.get("snapshot_id") == reference
                and latest.read_bytes() != immutable.read_bytes()
            ):
                return immutable, value, False
        return immutable, value, True
    except Exception:
        return immutable, _optional(immutable), False


def _validate_bound_order_sources(order: dict[str, Any], root: Path) -> None:
    """Revalidate every immutable causal input immediately before compilation.

    A treatment order is append-only, but its referenced files still live on a
    filesystem.  This check prevents a valid-looking order from compiling after
    its diagnosis or active preregistration has been replaced, edited or rebound.
    """

    diagnosis_ref = order.get("diagnosis") or {}
    protocol_ref = order.get("protocol") or {}
    if diagnosis_ref.get("bound_immutable") is not True or protocol_ref.get("bound_immutable") is not True:
        raise PermissionError("treatment order sources are not immutable")

    diagnoses_root = (root / "output/operations/phase6/intelligence/diagnoses").resolve()
    experiments_root = (root / "output/operations/phase6/intelligence/experiments").resolve()
    try:
        diagnosis_path = (root / str(diagnosis_ref["path"])).resolve()
        protocol_path = (root / str(protocol_ref["path"])).resolve()
        diagnosis_path.relative_to(diagnoses_root)
        protocol_path.relative_to(experiments_root)
    except (KeyError, ValueError) as exc:
        raise PermissionError("treatment order source path escapes its authoritative directory") from exc

    diagnosis_id = str(diagnosis_ref.get("diagnosis_id") or "")
    if diagnosis_path.name != f"{diagnosis_id}.json" or diagnosis_path.name == "latest.json":
        raise PermissionError("treatment order diagnosis path is not immutable")
    if protocol_path.name != "active.json":
        raise PermissionError("treatment order protocol path is not the active preregistration")
    if not diagnosis_path.is_file() or not protocol_path.is_file():
        raise PermissionError("treatment order immutable source is missing")

    expected_diagnosis_hash = f"sha256:{_sha256(diagnosis_path)}"
    expected_protocol_hash = f"sha256:{_sha256(protocol_path)}"
    if diagnosis_ref.get("content_hash") != expected_diagnosis_hash:
        raise PermissionError("bound diagnosis content changed after order creation")
    if protocol_ref.get("content_hash") != expected_protocol_hash:
        raise PermissionError("bound protocol content changed after order creation")

    latest_protocol_path = experiments_root / "latest.json"
    if not latest_protocol_path.is_file() or latest_protocol_path.read_bytes() != protocol_path.read_bytes():
        raise PermissionError("active/latest protocol divergence before compilation")

    diagnosis = _read(diagnosis_path)
    protocol = _read(protocol_path)
    _validate(root, "phase6_diagnostic_decision.schema.json", diagnosis)
    _validate(root, "phase6_experiment_protocol.schema.json", protocol)
    protocol_diagnosis = protocol.get("diagnosis") or {}
    if not (
        protocol.get("schema_version") == "1.1.0"
        and protocol.get("status") == "PREREGISTERED"
        and protocol.get("protocol_id") == protocol_ref.get("protocol_id")
        and protocol_diagnosis.get("diagnosis_id") == diagnosis_id
        and protocol_diagnosis.get("path") == diagnosis_ref.get("path")
        and protocol_diagnosis.get("status") == "DIAGNOSED"
    ):
        raise PermissionError("active protocol does not bind the order diagnosis exactly")
    decision = diagnosis.get("decision") or {}
    treatment = protocol.get("treatment") or {}
    if not (
        diagnosis.get("diagnosis_id") == diagnosis_id
        and diagnosis.get("channel_id") == CHANNEL_ID
        and diagnosis.get("status") == "DIAGNOSED"
        and decision.get("production_may_start") is True
        and diagnosis.get("baseline", {}).get("snapshot_id") == order.get("baseline", {}).get("snapshot_id")
        and protocol.get("baseline", {}).get("snapshot_id") == order.get("baseline", {}).get("snapshot_id")
        and decision.get("dominant_bottleneck") == diagnosis_ref.get("dominant_bottleneck")
        and decision.get("treatment_variable") == diagnosis_ref.get("treatment_variable") == order.get("treatment", {}).get("variable")
        and decision.get("primary_metric") == diagnosis_ref.get("primary_metric")
        and treatment.get("variable") == protocol_ref.get("treatment_variable") == order.get("treatment", {}).get("variable")
        and treatment.get("video_id") == protocol_ref.get("treatment_video_id")
        and treatment.get("preregistered_before_production") is True
    ):
        raise PermissionError("treatment order no longer matches its bound causal sources")


def _gate(name: str, status: str, evidence: list[str], reason: str) -> dict[str, Any]:
    return {"gate": name, "status": status, "evidence": evidence, "reason": reason}


def _select_candidate(signal: dict[str, Any], variable: str) -> dict[str, Any] | None:
    eligible = [
        item for item in signal.get("candidates", [])
        if item.get("eligible") is True
        and item.get("topic_cluster") in BRIEF_STRATEGIES
        and float(item.get("score_observed_weight") or 0) >= 0.95
        and float(item.get("opportunity_score") or 0) >= MIN_MARKET_OPPORTUNITY_SCORE
        and item.get("evidence_class") in EVIDENCE_CLASS_RANK
    ]
    if variable == "TOPIC_ANGLE":
        eligible = [item for item in eligible if item.get("topic_cluster") != "prayer_obedience"]
    else:
        eligible = [item for item in eligible if item.get("topic_cluster") == "prayer_obedience"]
    # Evidence depth is already one component of opportunity_score. Reusing it
    # as the primary sort key would double-count depth and could make a much
    # weaker signal beat a stronger one. It is only a deterministic tie-break.
    ranked = sorted(
        eligible,
        key=lambda item: (
            -float(item.get("opportunity_score") or 0),
            -EVIDENCE_CLASS_RANK[str(item["evidence_class"])],
            -int((item.get("metrics") or {}).get("cross_channel_count") or 0),
            str(item.get("candidate_id") or ""),
        ),
    )
    return ranked[0] if ranked else None


def _resolve_bound_market_candidate(
    order: dict[str, Any], signal_path: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load exactly the market evidence frozen into a ready treatment order."""

    record = order.get("market_candidate")
    if not isinstance(record, dict) or not signal_path.is_file():
        raise PermissionError("ready treatment order has no bound market candidate snapshot")
    observed_file_hash = f"sha256:{_sha256(signal_path)}"
    if record.get("source_snapshot_content_hash") != observed_file_hash:
        raise PermissionError("market evidence file changed after treatment ordering")
    signal = _read(signal_path)
    if (
        record.get("source_snapshot_id") != signal.get("snapshot_id")
        or record.get("source_score_version") != signal.get("score_version")
    ):
        raise PermissionError("market evidence identity or score version changed after treatment ordering")
    matches = [
        item for item in signal.get("candidates", [])
        if item.get("candidate_id") == record.get("candidate_id")
    ]
    if len(matches) != 1:
        raise PermissionError("bound market candidate is missing or duplicated")
    selected = matches[0]
    if record.get("selected_candidate_content_hash") != _canonical_content_hash(selected):
        raise PermissionError("bound market candidate content changed after treatment ordering")
    recomputed = _select_candidate(signal, str((order.get("treatment") or {}).get("variable") or "NONE"))
    if not recomputed or recomputed.get("candidate_id") != selected.get("candidate_id"):
        raise PermissionError("bound market candidate is no longer the policy-selected candidate")
    return signal, selected


def _baseline_reassessment_pass(metrics: dict[str, Any], diagnosis: dict[str, Any]) -> bool:
    """Accept full creative evidence or one narrow, raw-data-verified lag fallback.

    The fallback is intentionally incapable of selecting packaging, hook or body
    treatments. It only permits TOPIC_ANGLE sample expansion when the exact
    video count is below the configured exploratory floor at or after 24 hours.
    """

    age = float(metrics.get("age_hours") or 0)
    if (
        age >= 24
        and metrics.get("status") == "OBSERVED"
        and metrics.get("decision_status") == "ELIGIBLE_FOR_COMPARISON"
    ):
        return True
    decision = diagnosis.get("decision") or {}
    baseline = diagnosis.get("baseline") or {}
    measured = diagnosis.get("metrics") or {}
    policy = diagnosis.get("policy") or {}
    if not (
        age >= 24
        and metrics.get("status") == "PARTIAL_DATA_LAG"
        and metrics.get("decision_status") in {"INSUFFICIENT_DATA", "OBSERVE_ONLY"}
        and diagnosis.get("status") == "DIAGNOSED"
        and baseline.get("snapshot_id") == metrics.get("snapshot_id")
        and baseline.get("eligibility_scope") == "DISTRIBUTION_ONLY_EXACT_COUNT"
        and decision.get("dominant_bottleneck") == "DISTRIBUTION_SAMPLE"
        and decision.get("treatment_variable") == "TOPIC_ANGLE"
        and decision.get("primary_metric") == "views"
        and decision.get("production_may_start") is True
    ):
        return False
    sample = measured.get("diagnostic_sample_views")
    floor = policy.get("minimum_diagnostic_views")
    if (
        not isinstance(sample, (int, float))
        or isinstance(sample, bool)
        or not isinstance(floor, int)
        or isinstance(floor, bool)
        or sample < 0
        or sample >= floor
    ):
        return False
    source = measured.get("diagnostic_sample_source")
    sources = metrics.get("sources") or {}
    if source == "YOUTUBE_ANALYTICS_EXACT_VIDEO":
        raw = (metrics.get("private_metrics") or {}).get("views")
        return raw == sample and (sources.get("youtube_analytics_api") or {}).get("status") == "PASS"
    if source == "YOUTUBE_DATA_API_PUBLIC_EXACT_VIDEO":
        raw = (metrics.get("public_metrics") or {}).get("viewCount")
        return raw == sample and (sources.get("youtube_data_api") or {}).get("status") == "PASS"
    return False


def build_format_scope_receipt(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    """Reassess the base LIMITED pack for one exact Phase 6 action.

    This overlay never promotes the FormatPack and never authorizes publication.
    It exists because the base v1.1 contract authorized only the first canary and
    explicitly required a post-canary reassessment before the next release.
    """

    root = root.resolve()
    now = _parse(created_at) if created_at else datetime.now(timezone.utc)
    timestamp = _stamp(now)
    protocol_path, protocol, protocol_binding = _resolve_protocol(root)
    diagnosis_path, diagnosis, diagnosis_binding = _resolve_protocol_diagnosis(root, protocol)
    metrics_path, bound_metrics, metrics_binding = _resolve_protocol_baseline_metrics(
        root, protocol,
    )
    paths = {
        "plan": root / "output/operations/phase6/pilot-plan.json",
        "metrics": metrics_path,
        "diagnosis": diagnosis_path,
        "protocol": protocol_path,
        "pack": root / "config/format_packs/fp-broll-cinematic-narration-v1.json",
        "pipeline": root / "config/macro_pipelines/pipeline-clips-longform-v1.json",
        "publication": root / "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json",
        "quality": root / "output/production/phase5/pilot-001/creative-v3/autonomous-review/autonomous_quality_evaluation.json",
        "queue": root / "output/operations/phase6/runtime/queue-snapshot.json",
    }
    values = {name: _optional(path) for name, path in paths.items()}
    plan, metrics = values["plan"], bound_metrics
    diagnosis, protocol = values["diagnosis"], values["protocol"]
    pack, pipeline = values["pack"], values["pipeline"]
    publication, quality, queue = values["publication"], values["quality"], values["queue"]
    variable = str((diagnosis.get("decision") or {}).get("treatment_variable") or "NONE")
    target = (protocol.get("treatment") or {}).get("video_id")
    if variable == "TITLE_THUMBNAIL_PROMISE":
        requested_action, expected_target, ordinal = "COMPILE_CANARY_PACKAGE_UPDATE", CANARY_VIDEO_ID, 1
    elif variable in TREATMENT_RECIPES:
        requested_action, expected_target, ordinal = "COMPILE_VIDEO_2", "phase6-video-2-prepublication", 2
    else:
        requested_action, expected_target, ordinal = "WAIT", None, None
    baseline_reassessment = metrics_binding and _baseline_reassessment_pass(metrics, diagnosis)
    waiting = (
        protocol.get("status") != "PREREGISTERED"
        and (
            requested_action == "WAIT"
            or float(metrics.get("age_hours") or 0) < 24
            or diagnosis.get("status") == "WAITING_FOR_ELIGIBLE_BASELINE"
        )
    )
    published = plan.get("lot", {}).get("published_video_ids") or []
    quality_hash = quality.get("artifact", {}).get("sha256")
    publication_hash = publication.get("artifact_hashes", {}).get("video")
    dead_letters = int((queue.get("counts") or {}).get("DEAD_LETTER") or 0)
    incident_root = root / "output/operations/phase6/incidents"
    open_critical_incidents = sorted(
        path.relative_to(root).as_posix()
        for path in incident_root.glob("*.json")
        if (item := _optional(path)).get("severity") == "CRITICAL" and item.get("status") not in {"RESOLVED", "CLOSED"}
    ) if incident_root.is_dir() else []
    gates = [
        _gate("CONTROLLED_LOT_SEQUENCE", "PASS" if plan.get("status") == "ACTIVE" and plan.get("lot", {}).get("maximum_long_videos") == 3 and published == [CANARY_VIDEO_ID] else "BLOCKED", [paths["plan"].relative_to(root).as_posix()], "The operation must contain exactly the published canary and target ordinal must remain inside the three-video lot."),
        _gate("BASE_FORMATPACK", "PASS" if pack.get("format_pack_id") == "fp-broll-cinematic-narration" and pack.get("version") == "1.1.0" and pack.get("capability_status") in {"LIMITED", "PRODUCTION_READY"} and pack.get("production_allowed") is True else "BLOCKED", [paths["pack"].relative_to(root).as_posix()], "The reassessment may extend only the exact validated base pack."),
        _gate("PIPELINE_PIN", "PASS" if pipeline.get("pipeline_id") == "pipeline-clips-longform-v1" and pipeline.get("version") == "1.0.0" and pipeline.get("status") in {"LIMITED", "PRODUCTION_READY"} else "BLOCKED", [paths["pipeline"].relative_to(root).as_posix()], "No pipeline or version drift is allowed."),
        _gate("PUBLIC_CANARY_CHAIN", "PASS" if publication.get("status") == "COMPLETE_PUBLIC" and publication.get("video_id") == CANARY_VIDEO_ID and publication.get("channel_id") == CHANNEL_ID and publication_hash and publication_hash == quality_hash else "BLOCKED", [paths["publication"].relative_to(root).as_posix(), paths["quality"].relative_to(root).as_posix()], "The public canary receipt and independent quality evaluation must identify the same exact artifact."),
        _gate("ACTIVE_PROTOCOL_BINDING", "PASS" if protocol_binding else "BLOCKED", [paths["protocol"].relative_to(root).as_posix(), "output/operations/phase6/intelligence/experiments/latest.json"], "A preregistered protocol must be consumed from active.json and remain byte-identical to latest.json."),
        _gate("IMMUTABLE_DIAGNOSIS_BINDING", "PASS" if diagnosis_binding else "BLOCKED", [paths["diagnosis"].relative_to(root).as_posix(), paths["protocol"].relative_to(root).as_posix()], "A preregistered protocol must name the exact immutable diagnosis file by diagnosis_id."),
        _gate("OWNED_24H_REASSESSMENT", "PASS" if baseline_reassessment else ("WAITING" if waiting else "BLOCKED"), [paths["metrics"].relative_to(root).as_posix(), paths["diagnosis"].relative_to(root).as_posix()], "The base pack requires either complete owned creative metrics or a raw-verified distribution-only exact count below the exploratory floor at the 24-hour checkpoint."),
        _gate("EXACT_TREATMENT_TARGET", "PASS" if requested_action != "WAIT" and target == expected_target else ("WAITING" if waiting else "BLOCKED"), [paths["diagnosis"].relative_to(root).as_posix(), paths["protocol"].relative_to(root).as_posix()], "The preregistered action must target the canary package or the exact prepublication Video 2 identity."),
        _gate("NO_CRITICAL_OPERATION_INCIDENT", "PASS" if dead_letters == 0 and not open_critical_incidents else "BLOCKED", [paths["queue"].relative_to(root).as_posix(), *(open_critical_incidents or ["output/operations/phase6/incidents#none-open-critical"])], "Dead-letter work or an unresolved critical incident blocks scope extension."),
        _gate("AUTONOMOUS_BASELINE_QUALITY", "PASS" if quality.get("decision") == "PASS_LIMITED_CANARY" and quality.get("publication_eligible") is True and not quality.get("blockers") else "BLOCKED", [paths["quality"].relative_to(root).as_posix()], "The pinned canary must retain the independent automatic PASS that created LIMITED capability."),
        _gate("ZERO_COST_AND_PUBLICATION_LOCK", "PASS" if publication.get("external_cost_brl") == 0 and plan.get("cost", {}).get("technical_cost_brl") == 0 else "BLOCKED", [paths["publication"].relative_to(root).as_posix(), paths["plan"].relative_to(root).as_posix()], "This scope overlay costs R$ 0.00 and authorizes compilation only."),
    ]
    blocked = any(item["status"] == "BLOCKED" for item in gates)
    status = "BLOCKED" if blocked else ("WAITING" if any(item["status"] == "WAITING" for item in gates) else "AUTHORIZED")
    baseline_id = metrics.get("snapshot_id")
    value = {
        "schema_version": "1.0.0", "receipt_id": "", "operation_id": OPERATION_ID,
        "channel_id": CHANNEL_ID, "status": status,
        "base_format_pack": {"format_pack_id": "fp-broll-cinematic-narration", "version": "1.1.0", "capability_status": str(pack.get("capability_status") or "LIMITED")},
        "scope_overlay": {
            "overlay_id": "fp-broll-cinematic-narration-phase6-controlled-lot", "version": "1.2.0", "capability_status": "LIMITED",
            "allowed_scope": ["HeroVerse channel only", "English Christian-motivation long-form only", "one evidence-bound action at a time", "same FormatPack/pipeline/profile/voice versions", "maximum three public long-form videos after per-release gates", "distribution-only exact count below the exploratory floor may release TOPIC_ANGLE during creative-metrics lag", "technical cost R$ 0.00"],
            "forbidden_scope": ["another channel, niche, format or pipeline", "publication from this receipt", "video 3 without the second checkpoint and mandatory sampled audit", "Ads, paid tools or any spend", "PRODUCTION_READY promotion"],
            "expires_after_video_ordinal": 3,
        },
        "baseline_snapshot_id": baseline_id, "requested_action": requested_action,
        "target_video_id": expected_target, "video_ordinal": ordinal, "gates": gates,
        "publication_authorized": False, "technical_cost_brl": 0,
        "evidence_refs": [path.relative_to(root).as_posix() for path in paths.values()],
        "claim_boundary": ["AUTHORIZED extends only the LIMITED operation scope; it does not promote the FormatPack.", "This receipt permits compilation, never render acceptance or publication.", "The 24-hour observation is an operational checkpoint, not proof of audience success.", "Every produced artifact must pass its own rights, originality, quality, channel, OAuth, quota and publication gates."],
        "created_at": timestamp,
    }
    value["receipt_id"] = _format_scope_receipt_id(value)
    return value


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write_immutable_bytes(path: Path, payload: bytes, *, label: str) -> None:
    """Create a byte-stable file and never replace an existing identity."""

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable {label} collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise PermissionError(f"immutable {label} collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)


def _write_immutable_json(path: Path, value: dict[str, Any], *, label: str) -> dict[str, Any]:
    payload = _json_bytes(value)
    _write_immutable_bytes(path, payload, label=label)
    return _read(path)


def _replace_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def materialize_format_scope_receipt(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    value = build_format_scope_receipt(root, created_at=created_at)
    _validate(root, "phase6_format_scope_receipt.schema.json", value)
    latest = root / FORMAT_SCOPE
    immutable = root / BASE / "format-scope-receipts" / f"{value['receipt_id']}.json"
    if immutable.is_file():
        prior = _read(immutable)
        _validate(root, "phase6_format_scope_receipt.schema.json", prior)
        if prior.get("receipt_id") != value["receipt_id"]:
            raise PermissionError(
                f"immutable FormatPack scope identity mismatch: {value['receipt_id']}"
            )
        if (
            _format_scope_substantive_payload(prior)
            != _format_scope_substantive_payload(value)
        ):
            raise PermissionError(f"immutable FormatPack scope receipt collision: {value['receipt_id']}")
        value = prior
    else:
        _write(immutable, value)
    _write(latest, value)
    return latest


def build_treatment_order(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    now = _parse(created_at) if created_at else datetime.now(timezone.utc)
    timestamp = _stamp(now)
    protocol_path, protocol, protocol_binding = _resolve_protocol(root)
    diagnosis_path, diagnosis, diagnosis_binding = _resolve_protocol_diagnosis(root, protocol)
    metrics_path, metrics, metrics_binding = _resolve_protocol_baseline_metrics(
        root, protocol,
    )
    plan_path = root / "output/operations/phase6/pilot-plan.json"
    pack_path = root / "config/format_packs/fp-broll-cinematic-narration-v1.json"
    pipeline_path = root / "config/macro_pipelines/pipeline-clips-longform-v1.json"
    signal_path = root / "output/production/phase5/pilot-001/daily_signal_snapshot.json"
    plan, pack, pipeline, signal = _optional(plan_path), _optional(pack_path), _optional(pipeline_path), _optional(signal_path)
    compiler_identity = build_preproduction_compiler_identity()
    decision = diagnosis.get("decision") or {}
    treatment = protocol.get("treatment") or {}
    variable = str(decision.get("treatment_variable") or "NONE")
    requested_action = "COMPILE_CANARY_PACKAGE_UPDATE" if variable == "TITLE_THUMBNAIL_PROMISE" else ("COMPILE_VIDEO_2" if variable in TREATMENT_RECIPES else "WAIT")
    scope_path = materialize_format_scope_receipt(root, created_at=created_at)
    scope = _read(scope_path)
    age = float(metrics.get("age_hours") or 0)
    baseline_id = metrics.get("snapshot_id")
    candidate = _select_candidate(signal, variable) if variable != "NONE" else None
    signal_cutoff = signal.get("cutoff_at")
    signal_content_hash = f"sha256:{_sha256(signal_path)}" if signal_path.is_file() else None
    candidate_content_hash = _canonical_content_hash(candidate) if candidate else None
    # Pin freshness to the owned evidence cutoff, not wall-clock execution. This
    # keeps one immutable order byte-stable across manager retries.
    evidence_cutoff = _parse(metrics["captured_at"]) if metrics.get("captured_at") else now
    signal_age = max(0.0, (evidence_cutoff - _parse(signal_cutoff)).total_seconds() / 3600) if signal_cutoff else None

    baseline_reassessment = metrics_binding and _baseline_reassessment_pass(metrics, diagnosis)
    waiting = protocol.get("status") != "PREREGISTERED" and (
        age < 24
        or diagnosis.get("status") == "WAITING_FOR_ELIGIBLE_BASELINE"
        or protocol.get("status") in {None, "WAITING_FOR_24H_BASELINE", "READY_TO_PREREGISTER"}
    )
    gates = [
        _gate("PHASE6_ACTIVE_PLAN", "PASS" if plan.get("status") == "ACTIVE" else "BLOCKED", [plan_path.relative_to(root).as_posix()], "The controlled Phase 6 plan must be ACTIVE."),
        _gate("EXACT_CHANNEL", "PASS" if metrics.get("channel_id") == CHANNEL_ID else ("WAITING" if waiting and not metrics.get("channel_id") else "BLOCKED"), [metrics_path.relative_to(root).as_posix()], "Owned evidence must identify the exact HeroVerse channel."),
        _gate("ACTIVE_PROTOCOL_BINDING", "PASS" if protocol_binding else "BLOCKED", [protocol_path.relative_to(root).as_posix(), "output/operations/phase6/intelligence/experiments/latest.json"], "A preregistered protocol must be the immutable active protocol and match the current view byte for byte."),
        _gate("IMMUTABLE_DIAGNOSIS_BINDING", "PASS" if diagnosis_binding else "BLOCKED", [diagnosis_path.relative_to(root).as_posix(), protocol_path.relative_to(root).as_posix()], "The protocol must bind the exact immutable diagnosis that selected this variable."),
        _gate("CANARY_24H_BASELINE", "PASS" if baseline_reassessment else ("WAITING" if waiting else "BLOCKED"), [metrics_path.relative_to(root).as_posix(), diagnosis_path.relative_to(root).as_posix()], "At or after 24 hours, full owned creative metrics are required for creative diagnosis; only an exact count below the exploratory floor may authorize TOPIC_ANGLE sample expansion during data lag."),
        _gate("DIAGNOSIS", "PASS" if diagnosis.get("status") == "DIAGNOSED" and decision.get("production_may_start") is True else ("WAITING" if waiting else "BLOCKED"), [diagnosis_path.relative_to(root).as_posix()], "The Gestor must select one measured bottleneck before treatment."),
        _gate("PREREGISTRATION", "PASS" if protocol.get("status") == "PREREGISTERED" and treatment.get("preregistered_before_production") is True else ("WAITING" if waiting else "BLOCKED"), [protocol_path.relative_to(root).as_posix()], "The treatment must be preregistered before compilation."),
        _gate("BASELINE_IDENTITY_CHAIN", "PASS" if baseline_id and diagnosis.get("baseline", {}).get("snapshot_id") == baseline_id and protocol.get("baseline", {}).get("snapshot_id") == baseline_id else ("WAITING" if waiting else "BLOCKED"), [metrics_path.relative_to(root).as_posix(), diagnosis_path.relative_to(root).as_posix(), protocol_path.relative_to(root).as_posix()], "Metrics, diagnosis and protocol must reference one exact snapshot."),
        _gate("SINGLE_VARIABLE", "PASS" if variable in TREATMENT_RECIPES and treatment.get("variable") == variable else ("WAITING" if waiting else "BLOCKED"), [diagnosis_path.relative_to(root).as_posix(), protocol_path.relative_to(root).as_posix()], "Diagnosis and protocol must agree on exactly one supported treatment variable."),
        _gate("FORMATPACK_CAPABILITY", "PASS" if pack.get("format_pack_id") == "fp-broll-cinematic-narration" and pack.get("version") == "1.1.0" and pack.get("capability_status") in {"LIMITED", "PRODUCTION_READY"} and pack.get("production_allowed") is True else "BLOCKED", [pack_path.relative_to(root).as_posix()], "Only the validated LIMITED scope may enter production."),
        _gate("FORMATPACK_LIMITATION_SCOPE", "PASS" if scope.get("status") == "AUTHORIZED" and scope.get("requested_action") == requested_action and scope.get("baseline_snapshot_id") == baseline_id else ("WAITING" if waiting and scope.get("status") == "WAITING" else "BLOCKED"), [scope_path.relative_to(root).as_posix()], "The post-canary LIMITED scope overlay must authorize this exact action and baseline."),
        _gate("PIPELINE_CAPABILITY", "PASS" if pipeline.get("pipeline_id") == "pipeline-clips-longform-v1" and pipeline.get("status") in {"LIMITED", "PRODUCTION_READY"} else "BLOCKED", [pipeline_path.relative_to(root).as_posix()], "The selected long-form clip pipeline must be production-capable in this scope."),
        _gate("MARKET_EVIDENCE", "PASS" if candidate and signal_age is not None and signal_age <= 168 and float(candidate.get("opportunity_score") or 0) >= MIN_MARKET_OPPORTUNITY_SCORE and float(candidate.get("score_observed_weight") or 0) >= 0.95 else ("WAITING" if waiting else "BLOCKED"), [signal_path.relative_to(root).as_posix()], f"A traceable eligible market candidate with opportunity_score>={MIN_MARKET_OPPORTUNITY_SCORE:.2f}, observed_weight>=0.95 and age<=168h is required; score ranks a hypothesis, not virality."),
        _gate("COMPILER_CONTENT_IDENTITY", "PASS", [compiler_identity["compiler_code_sha256"], compiler_identity["production_code_sha256"], compiler_identity["creative_recipe_content_sha256"], compiler_identity["production_recipe_content_sha256"], compiler_identity["voice_profile_content_sha256"]], "The order binds the exact compiler code, declarative recipe/copy and voice planning profile."),
        _gate("ZERO_COST", "PASS", ["config/engine.json#cost_policy", "docs/STATE.md#custo"], "Technical and media spend remain exactly R$ 0.00."),
        _gate("PUBLICATION_LOCK", "PASS", ["docs/01_EXECUTION_PROTOCOL.md", "docs/STATE.md"], "This order compiles preproduction only; publication remains false until all release gates pass."),
    ]
    hard_fail = any(item["status"] in {"FAIL", "BLOCKED"} for item in gates)
    status = "WAITING_FOR_ELIGIBLE_BASELINE" if waiting and not hard_fail else ("BLOCKED" if hard_fail else "READY_TO_COMPILE")
    if status != "READY_TO_COMPILE":
        action = "WAIT"
    elif variable == "TITLE_THUMBNAIL_PROMISE":
        action = "COMPILE_CANARY_PACKAGE_UPDATE"
    else:
        action = "COMPILE_VIDEO_2"
    recipe = TREATMENT_RECIPES.get(variable, {
        "change_only": [], "implementation": ["Wait for an eligible diagnosis."],
        "success_metric": "NONE", "failure_rule": "No treatment may begin without eligible owned evidence.",
    })
    candidate_record = None
    if candidate and signal_age is not None:
        candidate_record = {
            "candidate_id": candidate["candidate_id"], "topic_cluster": candidate["topic_cluster"],
            "opportunity_score": float(candidate["opportunity_score"]),
            "score_observed_weight": float(candidate["score_observed_weight"]),
            "evidence_class": candidate["evidence_class"], "source_snapshot_id": signal["snapshot_id"],
            "source_snapshot_content_hash": signal_content_hash,
            "source_score_version": signal["score_version"],
            "selected_candidate_content_hash": candidate_content_hash,
            "source_age_hours": round(signal_age, 6), "representative_sources": candidate["representative_sources"],
            "selection_policy_version": MARKET_SELECTION_POLICY_VERSION,
            "minimum_opportunity_score": MIN_MARKET_OPPORTUNITY_SCORE,
            "ranking_order": ["opportunity_score DESC", "evidence_class DESC on tie", "cross_channel_count DESC on tie", "candidate_id ASC on tie"],
        }
    order_id = _stable_id(
        "phase6-treatment-order", baseline_id or "waiting", variable, action,
        "scope-overlay-1.2.0", compiler_identity["identity_sha256"],
        diagnosis.get("diagnosis_id") or "no-diagnosis",
        f"sha256:{_sha256(diagnosis_path)}" if diagnosis_path.is_file() else "no-diagnosis-hash",
        protocol.get("protocol_id") or "no-protocol",
        f"sha256:{_sha256(protocol_path)}" if protocol_path.is_file() else "no-protocol-hash",
        MARKET_SELECTION_POLICY_VERSION, signal.get("snapshot_id") or "no-signal-snapshot",
        signal.get("score_version") or "no-score-version", signal_content_hash or "no-signal-hash",
        candidate["candidate_id"] if candidate else "no-candidate",
        candidate_content_hash or "no-candidate-hash",
        scope.get("receipt_id") or "no-scope-receipt",
    )
    output_base = PACKAGE_UPDATE if action == "COMPILE_CANARY_PACKAGE_UPDATE" else VIDEO2
    value = {
        "schema_version": "1.1.0", "order_id": order_id, "operation_id": OPERATION_ID,
        "phase": 6, "channel_id": CHANNEL_ID, "status": status, "action": action,
        "compiler_identity": compiler_identity,
        "baseline": {"video_id": CANARY_VIDEO_ID, "snapshot_id": baseline_id, "captured_at": metrics.get("captured_at"), "age_hours": age, "decision_status": str(metrics.get("decision_status") or "UNAVAILABLE")},
        "diagnosis": {"diagnosis_id": diagnosis.get("diagnosis_id"), "path": diagnosis_path.relative_to(root).as_posix(), "content_hash": f"sha256:{_sha256(diagnosis_path)}" if diagnosis_path.is_file() else None, "bound_immutable": diagnosis_binding and protocol.get("status") == "PREREGISTERED", "status": str(diagnosis.get("status") or "UNAVAILABLE"), "dominant_bottleneck": str(decision.get("dominant_bottleneck") or "UNDETERMINED"), "treatment_variable": variable, "primary_metric": str(decision.get("primary_metric") or "NONE"), "production_may_start": decision.get("production_may_start") is True},
        "protocol": {"protocol_id": protocol.get("protocol_id"), "path": protocol_path.relative_to(root).as_posix(), "content_hash": f"sha256:{_sha256(protocol_path)}" if protocol_path.is_file() else None, "bound_immutable": protocol_binding and protocol.get("status") == "PREREGISTERED", "status": str(protocol.get("status") or "UNAVAILABLE"), "baseline_snapshot_id": protocol.get("baseline", {}).get("snapshot_id"), "treatment_video_id": treatment.get("video_id"), "treatment_variable": str(treatment.get("variable") or "NONE"), "preregistered_before_production": treatment.get("preregistered_before_production") is True},
        "prerequisite_gates": gates,
        "treatment": {"variable": variable, "change_only": recipe["change_only"], "locked_constants": LOCKED_CONSTANTS, "implementation": recipe["implementation"], "success_metric": recipe["success_metric"], "failure_rule": recipe["failure_rule"]},
        "market_candidate": candidate_record,
        "execution_contract": {"format_pack_id": "fp-broll-cinematic-narration", "format_pack_version": "1.1.0", "capability_status": str(pack.get("capability_status") or "LIMITED"), "scope_receipt_id": scope.get("receipt_id"), "scope_overlay_version": "1.2.0", "pipeline_id": "pipeline-clips-longform-v1", "quality_profile": "STANDARD", "stages": ["freeze evidence identity", "compile treatment-specific editorial brief", "compile original narrative and hook windows", "compile semantic take blueprint and rights acquisition map", "run preproduction gates", "render locally only after preproduction PASS", "run full automated release gates before any external action"], "idempotency_key": f"{order_id}:compile", "maximum_attempts": 3},
        "outputs": [(output_base / name).as_posix() for name in ("treatment_contract.json", "creative_concept_decision.json", "editorial_brief.json", "narrative_script.json", "take_blueprint.json", "quality_gate_plan.json")],
        "publication_authorized": False,
        "cost": {"technical_cost_brl": 0, "media_spend_brl": 0, "paid_tools": False},
        "evidence_refs": [plan_path.relative_to(root).as_posix(), metrics_path.relative_to(root).as_posix(), diagnosis_path.relative_to(root).as_posix(), protocol_path.relative_to(root).as_posix(), pack_path.relative_to(root).as_posix(), pipeline_path.relative_to(root).as_posix(), signal_path.relative_to(root).as_posix(), scope_path.relative_to(root).as_posix(), "hero_engine/phase6_creative_compiler.py", "hero_engine/phase6_production.py", "output/modeling/phase4/channel-model-v1/channel_model.json", "output/production/phase5/pilot-001/creative-v3/release_gate.json"],
        "claim_boundary": ["The market score ranks an observed hypothesis and is not a probability of virality.", "A video-to-video comparison is exploratory and remains exposed to timing and topic confounding.", "Compilation is not render approval and never authorizes publication.", "The 30-day target drives urgency but cannot guarantee YPP approval or public response."],
        "created_at": timestamp,
    }
    return value


def _brief_from_candidate(
    order: dict[str, Any],
    root: Path,
    signal: dict[str, Any],
    selected: dict[str, Any],
    concept: dict[str, Any],
    concept_decision: dict[str, Any],
) -> dict[str, Any]:
    channel_model = _read(root / "output/modeling/phase4/channel-model-v1/channel_model.json")
    selected_id = order["market_candidate"]["candidate_id"]
    archetype = next(item for item in channel_model["format_archetypes"] if item["archetype_id"] == "A-LONG-DIRECT-SPIRITUAL-STAKES-V1")
    rule_evidence: dict[str, list[str]] = {}
    for family in ("packaging_rules", "hook_rules", "invariants", "variables", "prohibited"):
        for rule in archetype[family]:
            rule_evidence[rule["rule_id"]] = rule["evidence_refs"]
    hooks = []
    for hook in concept["hooks"]:
        rules = hook["archetype_rule_refs"]
        hooks.append({
            "window": hook["window"], "function": hook["function"],
            "original_text": hook["narration"], "visual_proof": hook["visual_proof"],
            "archetype_rule_refs": rules,
            "evidence_refs": sorted({ref for rule in rules for ref in rule_evidence.get(rule, [])}) or ["channel-model:archetype"],
            "gate_status": "PASS",
        })
    alternatives = []
    for item in signal["candidates"]:
        alternatives.append({"candidate_id": item["candidate_id"], "decision": "SELECTED" if item["candidate_id"] == selected_id else ("REJECTED" if not item["eligible"] else "HELD"), "reason": "Selected by the preregistered treatment order." if item["candidate_id"] == selected_id else ("; ".join(item["rejection_reasons"]) or "Held as a measured alternative.")})
    return {
        "schema_version": "1.0.0", "brief_id": _stable_id("brief-phase6", order["order_id"], selected_id, concept_decision["decision_id"]), "channel_id": CHANNEL_HANDLE,
        "signal_snapshot_id": signal["snapshot_id"], "archetype_id": archetype["archetype_id"],
        "niche_fit": {"boundary": signal["niche_boundary"], "status": "PASS", "evidence": ["model:channel_dna", *selected["evidence_ids"]]},
        "selected_candidate_id": selected_id,
        "selection_reason": f"The preregistered {order['treatment']['variable']} treatment selected {selected['topic_cluster']} at observed opportunity_score={selected['opportunity_score']} and evidence_class={selected['evidence_class']}; adaptive concept {concept['concept_id']} then won the versioned production-fit comparison. Neither score is a viral probability.",
        "alternatives": alternatives,
        "package": {"topic": concept["package"]["topic"], "angle": concept["package"]["angle"], "promise": concept["package"]["promise"], "title_concept": concept["package"]["titles"][0], "title_variants": concept["package"]["titles"], "thumbnail_concept": concept["package"]["thumbnail_concept"], "thumbnail_text_variants": concept["package"]["thumbnail"], "combined_promise": concept["package"]["combined"], "delivery_test": "PASS"},
        "hook_windows": hooks, "payoff": concept["package"]["payoff"],
        "originality_controls": {"new_thesis": True, "new_wording": True, "new_sequence": True, "new_visual_identity": True, "reference_copying_prohibited": True},
        "risks": ["Observed public metadata does not prove causality.", "The treatment comparison is non-randomized.", "No prepublication artifact guarantees a viral outcome."],
        "decision_status": "VIRAL_CANDIDATE",
    }


def _script(
    brief: dict[str, Any],
    variable: str,
    created_at: str,
    concept: dict[str, Any],
    prior_script: dict[str, Any],
    topic_cluster: str,
) -> dict[str, Any]:
    if variable == "TOPIC_ANGLE":
        sections = deepcopy(SPIRITUAL_WARFARE_SECTIONS if topic_cluster == "spiritual_warfare" else PRAYER_SECTIONS)
        hook = [item["narration"] for item in concept["hooks"][:3]]
        thesis = concept["thesis"]
        source_basis = [
            {"source_ref": ref, "use": "belief context and safe editorial reasoning", "handling": "original contextual paraphrase; no borrowed audio or reference wording"}
            for ref in ("James 1:5", "James 1:22-25", "2 Corinthians 10:3-5")
        ]
    elif variable == "FIRST_8_SECONDS_MECHANISM":
        sections = deepcopy(prior_script["sections"])
        hook = [item["narration"] for item in concept["hooks"][:3]]
        thesis = prior_script["original_thesis"]
        source_basis = deepcopy(prior_script["source_basis"])
    elif variable == "BODY_PROGRESSIVE_DISCLOSURE":
        prior_by_id = {item["section_id"]: item for item in prior_script["sections"]}
        sections = [deepcopy(prior_by_id[item]) for item in concept["section_order"]]
        hook = [item["narration"] for item in prior_script["hook_windows"][:3]]
        thesis = prior_script["original_thesis"]
        source_basis = deepcopy(prior_script["source_basis"])
    else:
        raise ValueError(f"unsupported video treatment variable: {variable}")
    full_text = " ".join([*hook, *[item["text"] for item in sections]])
    words = len(re.findall(r"\b[\w'’-]+\b", full_text))
    return {
        "schema_version": "1.0.0", "script_id": _stable_id("script-phase6", brief["brief_id"], variable, full_text), "version": "2.0.0",
        "channel_id": CHANNEL_HANDLE, "brief_id": brief["brief_id"], "language": "en-US", "title": brief["package"]["title_concept"], "original_thesis": thesis,
        "source_basis": source_basis,
        "hook_windows": [
            {"window": "0_1S", "start_ms": 0, "end_ms": 1000, "function": brief["hook_windows"][0]["function"], "narration": hook[0], "visual_job": brief["hook_windows"][0]["visual_proof"], "evidence_refs": brief["hook_windows"][0]["evidence_refs"]},
            {"window": "1_3S", "start_ms": 1000, "end_ms": 3000, "function": brief["hook_windows"][1]["function"], "narration": hook[1], "visual_job": brief["hook_windows"][1]["visual_proof"], "evidence_refs": brief["hook_windows"][1]["evidence_refs"]},
            {"window": "3_8S", "start_ms": 3000, "end_ms": 8000, "function": brief["hook_windows"][2]["function"], "narration": hook[2], "visual_job": brief["hook_windows"][2]["visual_proof"], "evidence_refs": brief["hook_windows"][2]["evidence_refs"]},
            {"window": "8_30S", "start_ms": 8000, "end_ms": 30000, "function": brief["hook_windows"][3]["function"], "narration": sections[0]["text"], "visual_job": brief["hook_windows"][3]["visual_proof"], "evidence_refs": brief["hook_windows"][3]["evidence_refs"]},
        ],
        "sections": sections, "full_text": full_text, "word_count": words, "estimated_duration_ms": int(round(words / 142 * 60_000)),
        "originality_controls": {"written_from_blank": True, "reference_wording_used": False, "borrowed_audio_used": False, "borrowed_sequence_used": False, "editorial_purpose": "Teach an original, bounded faith-and-action method using rights-eligible visuals, original English narration and a new sequence."},
        "created_at": created_at,
    }


def _split(text: str, maximum_words: int = 12) -> list[str]:
    clauses = [part.strip() for part in re.split(r"(?<=[.!?;:])\s+|(?<=,)\s+", text) if part.strip()]
    chunks: list[str] = []
    for clause in clauses:
        words = clause.split()
        chunks.extend(" ".join(words[index:index + maximum_words]) for index in range(0, len(words), maximum_words))
    return chunks


def _take_blueprint(script: dict[str, Any], order: dict[str, Any], concept: dict[str, Any]) -> dict[str, Any]:
    overlays = concept["hook_text_overlays"]
    if order["treatment"]["variable"] == "BODY_PROGRESSIVE_DISCLOSURE":
        overlays = ["PRAYER ISN'T THE FINISH", None, "TRUTH / RESPONSIBILITY / TODAY"]
    takes = [
        {"take_id": "take-001", "start_ms": 0, "end_ms": 1000, "narrative_function": "contradiction", "narration": script["hook_windows"][0]["narration"], "semantic_role": "hook_threshold", "visual_job": "contradict stillness with a threshold action", "on_screen_text": overlays[0], "retention_job": "state the rupture in one second"},
        {"take_id": "take-002", "start_ms": 1000, "end_ms": 3000, "narrative_function": "personal consequence", "narration": script["hook_windows"][1]["narration"], "semantic_role": "tension", "visual_job": "show consequence with a different source", "on_screen_text": None, "retention_job": "make the cost personal"},
        {"take_id": "take-003", "start_ms": 3000, "end_ms": 8000, "narrative_function": "mechanism", "narration": script["hook_windows"][2]["narration"], "semantic_role": "decision_cards", "visual_job": "show three physical information states", "on_screen_text": overlays[2], "retention_job": "deliver the usable method"},
    ]
    cursor, index = 8000, 4
    variable = order["treatment"]["variable"]
    for section in script["sections"]:
        for chunk_index, chunk in enumerate(_split(section["text"])):
            words = len(chunk.split())
            word_budget_ms = int(round(words / 2.45 * 1000 / 100) * 100)
            voice_budget_ms = estimate_spoken_duration_ms(
                chunk, speed=planned_voice_speed(index - 1),
            )
            voice_headroom_ms = (
                required_body_voice_headroom_ms(voice_budget_ms)
                if variable == "TOPIC_ANGLE" else 0
            )
            # A TOPIC_ANGLE treatment creates new body copy, so its timeline is
            # conservatively sized here.  Other treatments must preserve the
            # previously rendered body timing as an experimental constant; the
            # exact pinned-model preflight remains authoritative for both.
            duration = max(
                2200,
                word_budget_ms,
                voice_budget_ms + voice_headroom_ms
                if variable == "TOPIC_ANGLE" else 0,
            )
            if duration > 6500:
                raise ValueError(
                    f"narration chunk exceeds the maximum take duration after voice planning: "
                    f"take-{index:03d}:required={duration}"
                )
            takes.append({"take_id": f"take-{index:03d}", "start_ms": cursor, "end_ms": cursor + duration, "narrative_function": section["narrative_function"], "narration": chunk, "semantic_role": section["semantic_role"], "visual_job": f"prove {section['semantic_role']} without decorative filler", "on_screen_text": section["on_screen_text"] if chunk_index == 0 else None, "retention_job": section["retention_job"]})
            cursor += duration
            index += 1
    planning_scope = (
        takes if variable == "TOPIC_ANGLE"
        else takes[:3] if variable == "FIRST_8_SECONDS_MECHANISM"
        else []
    )
    voice_timing = validate_planned_voice_slots(planning_scope) if planning_scope else []
    body_voice_timing = voice_timing[len(HOOK_SLOT_MS):]
    return {
        "schema_version": "1.0.0", "blueprint_id": _stable_id("take-blueprint", script["script_id"], order["order_id"]),
        "video_id": "phase6-video-002-prepublication", "channel_id": CHANNEL_ID,
        "format_pack": "fp-broll-cinematic-narration@1.1.0", "pipeline": "pipeline-clips-longform-v1", "quality_profile": "STANDARD",
        "treatment_variable": order["treatment"]["variable"], "total_estimated_duration_ms": cursor,
        "hook_contract": {"windows": ["0_1S", "1_3S", "3_8S", "8_30S"], "distinct_sources_0_8_minimum": 3, "visual_events_0_8_minimum": 4, "body_information_gap_maximum_ms": 25000},
        "voice_timing_contract": {
            "profile_version": VOICE_TIMING_PROFILE_VERSION,
            # Planning eligibility is intentionally not called PASS.  In
            # particular, a line can sit exactly on the conservative planning
            # boundary.  Only synthesis with the pinned Kokoro/eSpeak/model
            # hashes may turn this into an executable voice proof.
            "status": "PLANNING_ELIGIBLE_EXACT_PREFLIGHT_REQUIRED" if voice_timing else "PRESERVED_RENDERED_BASELINE",
            "authoritative_gate": "EXACT_PINNED_MODEL_PREFLIGHT_BEFORE_QUEUE_ATTEMPT",
            "speed_ceiling": 1.25,
            "opportunistic_speedup_allowed": False,
            "take_count": len(takes),
            "planning_scope": (
                "ALL_TAKES" if variable == "TOPIC_ANGLE"
                else "CHANGED_HOOK_ONLY" if variable == "FIRST_8_SECONDS_MECHANISM"
                else "PRESERVED_RENDERED_BASELINE"
            ),
            "planning_evidence_class": "DETERMINISTIC_ESTIMATE_NOT_MEASURED_AUDIO",
            "body_headroom_policy": {
                "scope": "NEW_TOPIC_ANGLE_BODY_COPY",
                "minimum_ms": VOICE_BODY_HEADROOM_MINIMUM_MS,
                "ratio": VOICE_BODY_HEADROOM_RATIO,
                "rounding_grid_ms": VOICE_DURATION_GRID_MS,
                "formula": "ceil(max(400 ms, 10% of estimate) / 100 ms) * 100 ms",
                "authoritative_result": "EXACT_PINNED_MODEL_PREFLIGHT_ONLY",
            },
            "minimum_estimated_headroom_ms": (
                min(item["estimated_headroom_ms"] for item in voice_timing)
                if voice_timing else None
            ),
            "minimum_body_required_headroom_ms": (
                min(item["required_headroom_ms"] for item in body_voice_timing)
                if body_voice_timing else None
            ),
            "minimum_body_observed_planning_headroom_ms": (
                min(item["observed_headroom_ms"] for item in body_voice_timing)
                if body_voice_timing else None
            ),
            "hook_slots": voice_timing[:3],
            "body_slots": body_voice_timing,
        },
        "takes": takes,
        "allocation_requirements": {"rights_status": ["OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"], "non_overlapping_safe_ranges": True, "adjacent_asset_repeat": False, "single_asset_runtime_share_maximum": 0.10, "top_six_runtime_share_maximum": 0.55, "rolling_60s_same_asset_count_maximum": 3},
        "publication_authorized": False,
    }


def _quality_gate_plan(order: dict[str, Any]) -> dict[str, Any]:
    gates = ["strategy", "ChannelDNA", "narrative", "hook", "semantic coherence", "style", "continuity", "characters", "movement", "legibility", "audio", "technical", "rights", "advertising applicability", "originality editorial", "channel identity", "cost", "publication"]
    return {"schema_version": "1.0.0", "order_id": order["order_id"], "critical_policy": "ANY FAIL, BLOCKED OR NEEDS_REVIEW BLOCKS AUTOMATIC PUBLICATION", "gates": [{"gate": gate, "required_result": "PASS", "evidence_required": True} for gate in gates], "automatic_checks": ["timeline continuity", "hook timing", "asset rights identity", "asset concentration", "frame duplication and ghosting", "resolution and safe areas", "audio loudness and clipping", "script-render ASR agreement", "exact channel and OAuth identity", "zero-cost preflight"], "gold_standard_policy": "independent sampled calibration and mandatory exceptions; the generator cannot be the sole evaluator", "publication_authorized": False}


def _compile_package_update(
    order: dict[str, Any], root: Path, output: Path, created_at: str,
    signal: dict[str, Any], selected: dict[str, Any],
) -> list[Path]:
    existing = _read(root / "output/production/phase5/pilot-001/creative-v3/publication_package.json")
    render_manifest = _read(root / "output/production/phase5/pilot-001/creative-v3/render_manifest.json")
    baseline_script = _read(root / "output/production/phase5/pilot-001/creative-v3/narrative_script.json")
    baseline = existing.get("metadata") or existing.get("packaging") or {}
    concept_decision, variants = build_packaging_search(
        root=root, order=order, candidate=selected, signal=signal,
        baseline_script=baseline_script, baseline_package=existing,
        created_at=created_at,
    )
    _validate(root, "phase6_packaging_concept_decision.schema.json", concept_decision)
    _validate(root, "phase6_packaging_variants.schema.json", variants)
    artifacts: dict[str, Any] = {
        "treatment_contract.json": order["treatment"],
        "creative_concept_decision.json": concept_decision,
        "editorial_brief.json": {"video_id": CANARY_VIDEO_ID, "action": "PUBLIC_METADATA_UPDATE_PLAN_ONLY", "baseline_package": baseline, "change_only": order["treatment"]["change_only"], "locked_content_hash": render_manifest["output"]["content_hash"], "publication_authorized": False},
        "narrative_script.json": {"video_id": CANARY_VIDEO_ID, "content_change_allowed": False, "reason": "The packaging treatment holds narration, hook, edit and body constant."},
        "take_blueprint.json": {"video_id": CANARY_VIDEO_ID, "timeline_change_allowed": False, "reason": "No video take may change in a title-thumbnail treatment."},
        "quality_gate_plan.json": _quality_gate_plan(order),
        "packaging_variants.json": variants,
    }
    paths = []
    for name, value in artifacts.items():
        path = output / name
        _write(path, value)
        paths.append(path)
    return paths


def _compile_video(
    order: dict[str, Any], root: Path, output: Path, created_at: str,
    signal: dict[str, Any], selected: dict[str, Any],
) -> list[Path]:
    channel_model = _read(root / "output/modeling/phase4/channel-model-v1/channel_model.json")
    assets = load_checked_phase5_assets(root)
    prior_script = _read(root / "output/production/phase5/pilot-001/creative-v3/narrative_script.json")
    topic_sections = SPIRITUAL_WARFARE_SECTIONS if selected["topic_cluster"] == "spiritual_warfare" else PRAYER_SECTIONS
    concept_decision, concept = select_creative_concept(
        variable=order["treatment"]["variable"], order=order, candidate=selected,
        signal=signal, channel_model=channel_model, asset_manifest=assets,
        prior_script=prior_script, topic_sections=topic_sections, created_at=created_at,
    )
    _validate(root, "phase6_creative_concept_decision.schema.json", concept_decision)
    brief = _brief_from_candidate(order, root, signal, selected, concept, concept_decision)
    if order["treatment"]["variable"] != "TOPIC_ANGLE":
        prior = _read(root / "output/production/phase5/pilot-001/creative-v3/editorial_brief.json")
        brief["package"] = prior["package"]
        brief["hook_windows"] = prior["hook_windows"]
        brief["payoff"] = prior["payoff"]
        brief["brief_id"] = _stable_id("brief-phase6", order["order_id"], order["treatment"]["variable"])
        brief["selection_reason"] = f"The {order['treatment']['variable']} diagnosis holds the prayer-obedience topic and changes only the preregistered mechanism family."
        if order["treatment"]["variable"] == "FIRST_8_SECONDS_MECHANISM":
            for item, replacement in zip(brief["hook_windows"][:3], concept["hooks"][:3]):
                item["original_text"] = replacement["narration"]
                item["function"] = replacement["function"]
                item["visual_proof"] = replacement["visual_proof"]
                item["gate_status"] = "PASS"
        elif order["treatment"]["variable"] == "BODY_PROGRESSIVE_DISCLOSURE":
            brief["hook_windows"] = deepcopy(prior["hook_windows"])
    script = _script(
        brief, order["treatment"]["variable"], created_at, concept,
        prior_script, selected["topic_cluster"],
    )
    take_blueprint = _take_blueprint(script, order, concept)
    duration_ms = int(take_blueprint["total_estimated_duration_ms"])
    if not 207_750 <= duration_ms <= 286_250:
        raise ValueError(
            f"compiled treatment duration {duration_ms} ms violates the locked 207750–286250 ms band"
        )
    take_blueprint["duration_lock"] = {
        "minimum_ms": 207_750,
        "maximum_ms": 286_250,
        "observed_ms": duration_ms,
        "status": "PASS",
    }
    eligible_roles = sorted({item["semantic_role"] for item in assets["assets"] if item.get("production_eligible") is True and item.get("rights_status") in {"OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"}})
    required_roles = sorted({item["semantic_role"] for item in take_blueprint["takes"]})
    missing_roles = sorted(set(required_roles) - set(eligible_roles))
    if missing_roles:
        raise PermissionError(f"rights-eligible visual coverage missing for roles: {missing_roles}")
    artifacts = {
        "treatment_contract.json": order["treatment"], "creative_concept_decision.json": concept_decision, "editorial_brief.json": brief,
        "narrative_script.json": script, "take_blueprint.json": take_blueprint,
        "quality_gate_plan.json": _quality_gate_plan(order),
        "asset_acquisition_plan.json": {"library_id": assets["library_id"], "eligible_roles": eligible_roles, "required_roles": required_roles, "missing_roles": missing_roles, "allocation_rule": "Allocate only non-overlapping safe ranges after exact semantic-role and rights checks; never fill a missing role with unrelated footage.", "reuse_is_authorized": True, "reason": "The verified rights manifest permits commercial transformation; every new range remains independently tracked.", "technical_cost_brl": 0},
    }
    _validate(root, "editorial_brief.schema.json", brief)
    _validate(root, "narrative_script.schema.json", script)
    paths = []
    for name, value in artifacts.items():
        path = output / name
        _write(path, value)
        paths.append(path)
    return paths


def _preproduction_receipt_identity_payload(receipt: dict[str, Any]) -> dict[str, Any]:
    """Normalize only the fields that necessarily contain the resulting ID."""

    payload = deepcopy(receipt)
    payload.pop("receipt_id", None)
    for record in payload.get("artifacts") or []:
        record.pop("immutable_path", None)
    return payload


def _preproduction_receipt_id(receipt: dict[str, Any]) -> str:
    return _stable_id(
        "phase6-preproduction", "immutable-content-v3",
        _canonical_content_hash(_preproduction_receipt_identity_payload(receipt)),
    )


def _archive_current_preproduction_before_overwrite(
    root: Path, branch: Path,
) -> str | None:
    """Preserve the current receipt and each bound artifact before a new view.

    Legacy 1.0 receipts did not carry immutable artifact paths.  They are still
    archived byte-for-byte here; their bytes are never upgraded or rewritten.
    A missing/drifted artifact blocks the overwrite instead of silently losing
    the only evidence that an earlier successful job actually compiled.
    """

    current_path = root / branch / "preproduction_receipt.json"
    if not current_path.is_file():
        return None
    raw_receipt = current_path.read_bytes()
    receipt = json.loads(raw_receipt.decode("utf-8-sig"))
    _validate(root, "phase6_preproduction_receipt.schema.json", receipt)
    receipt_id = str(receipt.get("receipt_id") or "")
    if not receipt_id:
        raise PermissionError("current preproduction receipt has no immutable identity")
    latest = root / BASE / "latest-preproduction-receipt.json"
    if latest.is_file():
        latest_value = _read(latest)
        if latest_value.get("receipt_id") == receipt_id and latest.read_bytes() != raw_receipt:
            raise PermissionError("current preproduction receipt differs from its latest view")
    artifact_root = (root / PREPRODUCTION_ARTIFACTS / receipt_id).resolve()
    expected_branch = (root / branch).resolve()
    seen: set[str] = set()
    for record in receipt.get("artifacts") or []:
        source = (root / str(record.get("path") or "")).resolve()
        try:
            source.relative_to(expected_branch)
        except ValueError as exc:
            raise PermissionError("preproduction artifact escaped its exact branch") from exc
        if not source.is_file():
            raise FileNotFoundError(f"preproduction artifact missing before archive: {record.get('path')}")
        payload = source.read_bytes()
        digest = hashlib.sha256(payload).hexdigest()
        if digest != record.get("sha256") or len(payload) != record.get("size_bytes"):
            raise PermissionError(f"preproduction artifact drifted before archive: {record.get('path')}")
        if source.name in seen:
            raise PermissionError("preproduction receipt repeats an artifact filename")
        seen.add(source.name)
        target = artifact_root / source.name
        _write_immutable_bytes(target, payload, label="preproduction artifact archive")
    immutable_receipt = root / PREPRODUCTION_RECEIPTS / f"{receipt_id}.json"
    _write_immutable_bytes(
        immutable_receipt, raw_receipt, label="preproduction receipt archive",
    )
    return receipt_id


def verify_preproduction_receipt(
    root: Path = ROOT,
    *,
    receipt_path: str | Path | None = None,
    expected_order_id: str | None = None,
    expected_receipt_id: str | None = None,
    require_current_views: bool = True,
) -> dict[str, Any]:
    """Execution verification still requires the resident compiler identity."""
    return _verify_preproduction_receipt(
        root, receipt_path=receipt_path, expected_order_id=expected_order_id,
        expected_receipt_id=expected_receipt_id,
        require_current_views=require_current_views,
    )


def verify_historical_preproduction_receipt(
    root: Path,
    *,
    receipt_path: str | Path,
    expected_order_id: str,
    expected_receipt_id: str,
    expected_sha256: str,
) -> dict[str, Any]:
    """Authenticate pinned historical data, not compiler replay or execution.

    The anchor must come from the authenticated immutable work order. Current
    aliases and the resident compiler are deliberately not historical evidence.
    This function grants no compilation, queue, render or publication authority.
    """
    root = root.resolve()
    source = Path(receipt_path)
    source = (source if source.is_absolute() else root / source).resolve()
    expected = (root / PREPRODUCTION_RECEIPTS / f"{expected_receipt_id}.json").resolve()
    if source != expected or not expected_order_id or not expected_receipt_id:
        raise PermissionError("historical preproduction binding is not canonical")
    raw = source.read_bytes()
    if expected_sha256 != "sha256:" + hashlib.sha256(raw).hexdigest():
        raise PermissionError("historical preproduction receipt anchor diverged")
    result = _verify_preproduction_receipt(
        root, receipt_path=source, expected_order_id=expected_order_id,
        expected_receipt_id=expected_receipt_id, require_current_views=False,
        historical_receipt_bytes=raw,
    )
    if source.read_bytes() != raw:
        raise PermissionError("historical preproduction receipt changed during verification")
    return result


def _verify_preproduction_receipt(
    root: Path = ROOT,
    *,
    receipt_path: str | Path | None = None,
    expected_order_id: str | None = None,
    expected_receipt_id: str | None = None,
    require_current_views: bool = True,
    historical_receipt_bytes: bytes | None = None,
) -> dict[str, Any]:
    """Reopen the immutable order, receipt and every artifact hash."""

    root = root.resolve()
    latest = root / BASE / "latest-preproduction-receipt.json"
    source = Path(receipt_path) if receipt_path is not None else latest
    source = source if source.is_absolute() else root / source
    source = source.resolve()
    if not source.is_file():
        raise FileNotFoundError("preproduction receipt is missing")
    receipt = (_read(source) if historical_receipt_bytes is None
               else json.loads(historical_receipt_bytes.decode("utf-8-sig")))
    _validate(root, "phase6_preproduction_receipt.schema.json", receipt)
    if receipt.get("schema_version") != "1.1.0":
        raise PermissionError("legacy preproduction receipt lacks immutable compiler/artifact identity")
    receipt_id = str(receipt["receipt_id"])
    if expected_receipt_id is not None and receipt_id != expected_receipt_id:
        raise PermissionError("preproduction receipt identity mismatch")
    if expected_order_id is not None and receipt.get("order_id") != expected_order_id:
        raise PermissionError("preproduction receipt belongs to another treatment order")

    immutable_receipt = (root / PREPRODUCTION_RECEIPTS / f"{receipt_id}.json").resolve()
    if source != immutable_receipt:
        if not immutable_receipt.is_file() or immutable_receipt.read_bytes() != source.read_bytes():
            raise PermissionError("preproduction current view differs from its immutable receipt")
    elif not immutable_receipt.is_file():
        raise FileNotFoundError("immutable preproduction receipt is missing")

    order_path = (
        root / BASE / "orders" / f"{receipt['order_id']}.json"
    ).resolve()
    if not order_path.is_file():
        raise FileNotFoundError("immutable treatment order for preproduction is missing")
    order = _read(order_path)
    _validate(root, "phase6_treatment_order.schema.json", order)
    if order.get("order_id") != receipt.get("order_id"):
        raise PermissionError("preproduction order identity diverged")
    if _canonical_content_hash(order) != receipt.get("order_content_hash"):
        raise PermissionError("preproduction order content hash diverged")
    if order.get("compiler_identity") != receipt.get("compiler_identity"):
        raise PermissionError("preproduction compiler identity diverged from its order")
    if historical_receipt_bytes is None:
        _verify_order_compiler_identity(order)

    branch = PACKAGE_UPDATE if receipt["action"] == "COMPILE_CANARY_PACKAGE_UPDATE" else VIDEO2
    expected_branch = (root / branch).resolve()
    expected_immutable_root = (root / PREPRODUCTION_ARTIFACTS / receipt_id).resolve()
    artifact_hashes: list[str] = []
    names: set[str] = set()
    for record in receipt.get("artifacts") or []:
        current = (root / record["path"]).resolve()
        immutable = (root / record["immutable_path"]).resolve()
        try:
            current.relative_to(expected_branch)
            immutable.relative_to(expected_immutable_root)
        except ValueError as exc:
            raise PermissionError("preproduction artifact path escaped its receipt branch") from exc
        if immutable.parent != expected_immutable_root or immutable.name != current.name:
            raise PermissionError("preproduction immutable artifact path is not canonical")
        if current.name in names:
            raise PermissionError("preproduction receipt repeats an artifact filename")
        names.add(current.name)
        if not immutable.is_file():
            raise FileNotFoundError(f"immutable preproduction artifact missing: {record['immutable_path']}")
        immutable_bytes = immutable.read_bytes()
        digest = hashlib.sha256(immutable_bytes).hexdigest()
        if digest != record["sha256"] or len(immutable_bytes) != record["size_bytes"]:
            raise PermissionError(f"immutable preproduction artifact hash/size mismatch: {record['immutable_path']}")
        if require_current_views:
            if not current.is_file() or current.read_bytes() != immutable_bytes:
                raise PermissionError(f"preproduction current artifact differs from immutable bytes: {record['path']}")
        artifact_hashes.append(digest)

    expected_id = _preproduction_receipt_id(receipt)
    if receipt_id != expected_id:
        raise PermissionError("preproduction receipt_id does not match its bound hashes")
    return receipt


def compile_preproduction(order: dict[str, Any], root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    _validate(root, "phase6_treatment_order.schema.json", order)
    if order["status"] != "READY_TO_COMPILE" or order["action"] == "WAIT":
        raise PermissionError("treatment order is not ready to compile")
    compiler_identity = _verify_order_compiler_identity(order)
    _validate_bound_order_sources(order, root)
    # Compilation is a deterministic replay of the immutable order.  Wall-clock
    # retry time must not manufacture different bytes for the same identity.
    timestamp = str(order["created_at"])
    output = root / (PACKAGE_UPDATE if order["action"] == "COMPILE_CANARY_PACKAGE_UPDATE" else VIDEO2)
    signal_path = root / "output/production/phase5/pilot-001/daily_signal_snapshot.json"
    signal, selected = _resolve_bound_market_candidate(order, signal_path)
    order_path = root / BASE / "orders" / f"{order['order_id']}.json"
    stored_order = _write_immutable_json(
        order_path, order, label="treatment order",
    )
    order_content_hash = _canonical_content_hash(stored_order)
    with tempfile.TemporaryDirectory(prefix="phase6-preproduction-") as folder:
        staging = Path(folder)
        staged_paths = (
            _compile_package_update(order, root, staging, timestamp, signal, selected)
            if order["action"] == "COMPILE_CANARY_PACKAGE_UPDATE"
            else _compile_video(order, root, staging, timestamp, signal, selected)
        )
        staged = [
            (path.name, path.read_bytes()) for path in staged_paths
        ]
    artifact_hashes = [hashlib.sha256(payload).hexdigest() for _, payload in staged]
    artifact_records = []
    for (name, payload), digest in zip(staged, artifact_hashes):
        current_path = output / name
        artifact_records.append({
            "path": current_path.relative_to(root).as_posix(),
            "sha256": digest,
            "size_bytes": len(payload),
        })
    gates = [
        {"gate": "ORDER_IDENTITY", "status": "PASS", "evidence": [order["order_id"]]},
        {"gate": "COMPILER_CONTENT_IDENTITY", "status": "PASS", "evidence": [compiler_identity["identity_sha256"], compiler_identity["voice_profile_content_sha256"]]},
        {"gate": "MARKET_EVIDENCE_BINDING", "status": "PASS", "evidence": [order["market_candidate"]["source_snapshot_content_hash"], order["market_candidate"]["selected_candidate_content_hash"]]},
        {"gate": "SINGLE_VARIABLE_LOCK", "status": "PASS", "evidence": ["treatment_contract.json"]},
        {"gate": "ADAPTIVE_CREATIVE_CONCEPT", "status": "PASS", "evidence": ["creative_concept_decision.json", "packaging_variants.json"] if order["action"] == "COMPILE_CANARY_PACKAGE_UPDATE" else ["creative_concept_decision.json"]},
        {"gate": "PREPRODUCTION_ARTIFACTS", "status": "PASS", "evidence": [item["path"] for item in artifact_records]},
        {"gate": "ZERO_COST_AND_PUBLICATION_LOCK", "status": "PASS", "evidence": ["technical_cost_brl=0", "publication_authorized=false"]},
    ]
    receipt = {
        "schema_version": "1.1.0",
        "order_id": order["order_id"], "status": "COMPILED", "action": order["action"], "channel_id": CHANNEL_ID,
        "order_content_hash": order_content_hash,
        "compiler_identity": deepcopy(compiler_identity),
        "treatment_variable": order["treatment"]["variable"], "artifacts": artifact_records, "gates": gates,
        "next_action": "RUN_CANARY_PACKAGE_GATES" if order["action"] == "COMPILE_CANARY_PACKAGE_UPDATE" else "SYNTHESIZE_AND_RENDER_VIDEO_2",
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": timestamp,
    }
    receipt_id = _preproduction_receipt_id(receipt)
    receipt["receipt_id"] = receipt_id
    for record in receipt["artifacts"]:
        record["immutable_path"] = (
            PREPRODUCTION_ARTIFACTS / receipt_id / Path(record["path"]).name
        ).as_posix()
    _validate(root, "phase6_preproduction_receipt.schema.json", receipt)
    _archive_current_preproduction_before_overwrite(
        root,
        PACKAGE_UPDATE if order["action"] == "COMPILE_CANARY_PACKAGE_UPDATE" else VIDEO2,
    )
    for record, (_, payload) in zip(artifact_records, staged):
        _write_immutable_bytes(
            root / record["immutable_path"], payload,
            label="preproduction artifact",
        )
    immutable_receipt = root / PREPRODUCTION_RECEIPTS / f"{receipt_id}.json"
    receipt = _write_immutable_json(
        immutable_receipt, receipt, label="preproduction receipt",
    )
    for record in receipt["artifacts"]:
        _replace_bytes(
            root / record["path"], (root / record["immutable_path"]).read_bytes(),
        )
    _replace_bytes(output / "preproduction_receipt.json", immutable_receipt.read_bytes())
    _replace_bytes(
        root / BASE / "latest-preproduction-receipt.json",
        immutable_receipt.read_bytes(),
    )
    return verify_preproduction_receipt(
        root, receipt_path=immutable_receipt,
        expected_order_id=order["order_id"], expected_receipt_id=receipt_id,
    )


def materialize_treatment_order(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    value = build_treatment_order(root, created_at=created_at)
    _validate(root, "phase6_treatment_order.schema.json", value)
    latest = root / BASE / "latest-order.json"
    immutable = root / BASE / "orders" / f"{value['order_id']}.json"
    if immutable.is_file():
        prior = _read(immutable)
        before, after = dict(prior), dict(value)
        before.pop("created_at", None)
        after.pop("created_at", None)
        if before != after:
            raise PermissionError(f"immutable treatment order collision: {value['order_id']}")
        value = prior
    else:
        _write(immutable, value)
    _write(latest, value)
    return latest


def execute_ready_order(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any] | None:
    root = root.resolve()
    order_path = materialize_treatment_order(root, created_at=created_at)
    order = _read(order_path)
    if order["status"] != "READY_TO_COMPILE":
        return None
    return compile_preproduction(order, root, created_at=created_at)


if __name__ == "__main__":
    path = materialize_treatment_order(ROOT)
    print(path)
    result = execute_ready_order(ROOT)
    if result is not None:
        print(json.dumps(result, ensure_ascii=False, indent=2))
