"""Strict YuNet result semantics and pre-registered operational controls.

Pure validation, not a runtime, detector, calibration or legal approval. The
consumer must separately authenticate the actual worker and calibrated scope.
Nothing here imports OpenCV, reads files or runs inference.
"""
from __future__ import annotations

import math

VERSION = "phase6-av-yunet-operational-semantics-v1"
# Nonempty-input detect() returns 1 after forward/postProcess; 0 is the early
# empty-input branch. This primary source describes code semantics, not proof
# that a particular binary was built from that source or calibrated locally.
SOURCE = "https://raw.githubusercontent.com/opencv/opencv/5.0.0/modules/objdetect/src/face_detect.cpp"
SETTINGS = {"score_threshold": 0.80, "nms_threshold": 0.30, "top_k": 5000,
            "initial_size": [320, 320], "resize_max_width": 1280,
            "interpolation": "INTER_LINEAR", "pixel_order": "RGB24_TO_BGR_UINT8",
            "threads": 1, "opencl": False}
AUTHORITY = dict.fromkeys(("runtime_authenticated", "detector_calibrated", "human_gold",
                          "publicity_approved", "publication_authorized", "legal_clearance"), False)
POSITIVE_SHA = "sha256:88431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5"
NEGATIVE_SHA = "sha256:b693ff1684438d5e11e0d7cb3d9a067e03ea57e918a79d3afc08cf2a4ce840a0"


class DetectorSemanticsError(ValueError):
    pass


def _exact(value, expected):
    """Compare a shallow fixed recipe without coercion or arbitrary JSON encoding."""
    if type(value) is not type(expected):
        return False
    if type(expected) is dict:
        return (all(type(key) is str for key in value) and set(value) == set(expected)
                and all(_exact(value[key], item) for key, item in expected.items()))
    if type(expected) is list:
        return len(value) == len(expected) and all(_exact(a, b) for a, b in zip(value, expected))
    return value == expected


def _finite_number(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def validate_raw(raw, *, source_width, source_height, observed_opencv_version):
    """Validate numbers/return code; version must later come from verified worker.

The observed version argument is a comparison input, never authentication.
Only the fixed OpenCV5.0.0 core / installed5.0.0.93 distribution family is in
scope. False/zero/negative/error returns cannot be interpreted as no faces.
"""
    for number in (source_width, source_height):
        if type(number) is not int or not 0 < number <= 32768:
            raise DetectorSemanticsError("positive bounded integer source dimensions required")
    if source_width * source_height * 3 > 67108864:
        raise DetectorSemanticsError("RGB frame exceeds existing 64MiB capacity limit")
    if type(observed_opencv_version) is not str or observed_opencv_version not in ("5.0.0", "5.0.0.93"):
        raise DetectorSemanticsError("unreviewed OpenCV return-semantics version")
    expected = ([source_width, source_height] if source_width <= 1280 else
                [1280, max(1, round(source_height * (1280 / source_width)))])
    if (type(raw) is not dict or not all(type(key) is str for key in raw)
            or set(raw) != {"settings", "input_size", "opencv_version", "retval", "detections"}
            or not _exact(raw["settings"], SETTINGS) or not _exact(raw["input_size"], expected)
            or type(raw["opencv_version"]) is not str
            or raw["opencv_version"] != observed_opencv_version):
        raise DetectorSemanticsError("raw preprocessing or version does not match observation")
    if type(raw["retval"]) is not int or raw["retval"] != 1:
        raise DetectorSemanticsError("nonempty YuNet inference must return exact integer1")
    rows = raw["detections"]
    if rows is None:
        count = 0
    else:
        if type(rows) is not list or len(rows) > SETTINGS["top_k"]:
            raise DetectorSemanticsError("bounded raw detection rows required")
        for row in rows:
            if (type(row) is not list or len(row) != 15
                    or any(not _finite_number(n) for n in row)
                    or row[2] <= 0 or row[3] <= 0 or not 0.80 <= row[14] <= 1.0):
                raise DetectorSemanticsError("invalid raw YuNet geometry, confidence or numbers")
        count = len(rows)
    return {"version": VERSION, "status": "RAW_SEMANTICS_VALID_NOT_CALIBRATED",
            "face_count": count, "input_size": expected, "opencv_version": observed_opencv_version,
            "authority": dict(AUTHORITY), "source_semantics": SOURCE}


def evaluate_controls(observations):
    """Two exact controls, evaluated without refitting thresholds or choosing data.

Input observations are not authenticated here. The batch runner must pin source
bytes, preprocessing, model, runtime and raw output before this reducer. Even
PASS describes these two operational examples only, not domain sensitivity.
"""
    if type(observations) is not list or len(observations) != 2:
        raise DetectorSemanticsError("exact positive/negative control pair required")
    expected = (("frontal-astronaut", POSITIVE_SHA, 512, 512),
                ("project-procedural-no-face", NEGATIVE_SHA, 1920, 1080))
    results = []
    versions = set()
    for row, (identity, digest, width, height) in zip(observations, expected):
        if (type(row) is not dict or not all(type(key) is str for key in row)
                or set(row) != {"control_id", "source_sha256", "width", "height", "raw", "observed_opencv_version"}
                or type(row["control_id"]) is not str or type(row["source_sha256"]) is not str
                or row["control_id"] != identity or row["source_sha256"] != digest
                or type(row["width"]) is not int or type(row["height"]) is not int
                or (row["width"], row["height"]) != (width, height)):
            raise DetectorSemanticsError("control population or pinned identity differs")
        parsed = validate_raw(row["raw"], source_width=width, source_height=height,
                              observed_opencv_version=row["observed_opencv_version"])
        versions.add(parsed["opencv_version"])
        if identity == "frontal-astronaut":
            # Approximate face region observed by root BEFORE inference, not
            # a human bbox annotation or a statistical localization tolerance.
            detections = row["raw"]["detections"] or []
            within = len(detections) == 1 and (170 <= detections[0][0] + detections[0][2] / 2 <= 290
                                               and 60 <= detections[0][1] + detections[0][3] / 2 <= 190)
            passed = parsed["face_count"] == 1 and within
        else:
            passed = parsed["face_count"] == 0
        results.append({"control_id": identity, "face_count": parsed["face_count"], "status": "PASS" if passed else "FAIL"})
    if len(versions) != 1:
        raise DetectorSemanticsError("control batch changed runtime version")
    passed = all(row["status"] == "PASS" for row in results)
    return {"version": VERSION, "status": "PASS_OPERATIONAL_CONTROLS_ONLY" if passed else "FAIL_OPERATIONAL_CONTROLS",
            "controls": results, "authority": dict(AUTHORITY), "technical_cost_brl": 0,
            "limitations": ["TWO_OBSERVED_EXAMPLES_NOT_DOMAIN_CALIBRATION", "AI_OBSERVATION_NOT_HUMAN_GOLD",
                            "SOURCE_MODEL_RUNTIME_AND_RAW_BINDINGS_REQUIRED_BY_RUNNER", "NO_PUBLICITY_OR_LEGAL_CLEARANCE"]}
