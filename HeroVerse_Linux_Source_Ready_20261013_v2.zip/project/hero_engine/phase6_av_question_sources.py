"""Four question stills: fixed historical QA replay plus PNG container checks.

No image decoding, OCR, renderer or clock is executed by this reader. Pixel and
glyph observations remain the exact externally pinned historical measurements;
the new check verifies the PNG container, CRCs and absence of alpha/APNG. The
case projection is staged, not an active timeline or authority for publication.
"""
from __future__ import annotations

import copy
from pathlib import Path
import struct
import zlib

from . import phase6_av_static_sources as primitives

VERSION = "phase6-av-question-sources-v1"
TEMPLATE_ID = "test-questions-v1"
HERE = "output/qa/phase6/diagnostics/test-questions-v1"
STAGER = HERE + "/stage_case_amendment_v2.py"
STAGER_TEST = HERE + "/test_stage_case_amendment_v2.py"
STAGER_SHA = "8ed1b215f64da4dddd36eeabbd6b2b43772152cb5934bfc56d36fa8c48ce744f"
STAGER_TEST_SHA = "a2e591edf4b1764795b665bc4cc54a7b0c7e8d1b6e923a728415ec221ec80654"
STAGING_BINDING = {"path": HERE + "/question-case-amendment-v2-1e60348b0c51a9116c8177f9-receipt.json",
    "sha256": "3e22ff3998f04596ebbb22d8c0d1d0f69db0d5f8c2c01c5ab06c056cc7579761"}
CONFIG = {
    "directory": HERE + "/static-a4630336964863b442fdc027",
    "receipt_sha256": "f63ac629a6e9c76ba3485e5dd182123034d108fce515985fce632a71d716c622",
    "runner": HERE + "/recipe.py",
    "runner_sha256": "ea876e4f9ecc8f20f45e44b07002b738460edc813a966e105fb024d3f7cbc025",
    "state_ids": ["visual-u019-s00", "visual-u020-s00", "visual-u020-s01", "visual-u021-s00"],
    "lineage_id": "owned-four-criteria-panel-v1",
    "source_bindings": {
        "style_bible": {"path": "output/production/phase6/video-002/production/channel_style_bible.json", "sha256": "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049"},
        "take_plan": {"path": "output/production/phase6/video-002/production/take_plan.json", "sha256": "547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5"},
        "base_projection": {"path": "output/qa/phase6/diagnostics/two-column-compact-v1/staged-visual-v3-d629bce952153ea32c689ccb.json", "sha256": "d629bce952153ea32c689ccb5cea5f95d22faa6c3dad39111b0f0672e51acf32"},
        "static_reconciliation": {"path": HERE + "/reconciliation-f3904b4f063f15c87e2bfd9b/report.json", "sha256": "0ac7a3fbfbf14da0d0bb6bc15993a303fb03510d76cafcddcbf6369620770aff"},
        "case_amendment": {"path": HERE + "/question-case-amendment-v2-1e60348b0c51a9116c8177f9.json", "sha256": "b07bca4c9adc736ffe0abdfca49c341c2e114d9fa12cc269f6dc1aed8fbbadbf"},
        "visual_projection": {"path": HERE + "/staged-visual-v5-7fd136fe0bc4557433b24e46.json", "sha256": "7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92"},
        "case_staging": copy.deepcopy(STAGING_BINDING),
    },
}
AUTHORITY = {key: False for key in (
    "synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized",
    "quality_approved", "source_admitted", "timing_validated", "rights_approved", "publicity_approved")}
MODEL_PINS = {
    ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_det_small.onnx": ("090f04abcd9d9a7498bc4ebf677e4cb9bdce1fe4197ddb7e529f1ef44e1ff94f", 9929594),
    ".venv/Lib/site-packages/rapidocr/models/PP-OCRv6_rec_small.onnx": ("6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884", 21234383),
    ".venv/Lib/site-packages/rapidocr/models/ch_ppocr_mobile_v2.0_cls_mobile.onnx": ("e47acedf663230f8863ff1ab0e64dd2d82b838fceb5957146dab185a89d6215c", 585532),
}
EXPECTED = (
    ("visual-u019-s00", "narration-unit-019", "take-024", ["Test", "Loud is not true"]),
    ("visual-u020-s00", "narration-unit-020", "take-025", ["Fully true?"]),
    ("visual-u020-s01", "narration-unit-020", "take-026", ["Fully true?", "Or only possible?"]),
    ("visual-u021-s00", "narration-unit-021", "take-027", ["Character", "Is this how I should act?"]),
)


def _same(actual, expected, message):
    primitives._same(actual, expected, message)


def _requests(root, requests):
    if type(requests) is not list or not 1 <= len(requests) <= 4:
        raise ValueError("one to four explicit question sources required")
    seen = set()
    relative = CONFIG["directory"] + "/receipt.json"
    for row in requests:
        if type(row) is not dict or set(row) != {"template_id", "state_id", "receipt_binding"}:
            raise ValueError("question request fields differ")
        if (type(row["state_id"]) is not str or row["state_id"] not in CONFIG["state_ids"]
                or row["state_id"] in seen or row["template_id"] != TEMPLATE_ID):
            raise ValueError("unknown or duplicate question source")
        seen.add(row["state_id"])
        bound = row["receipt_binding"]
        if (type(bound) is not dict or set(bound) != {"path", "sha256"}
                or bound["path"] not in (relative, str(Path(root).absolute() / relative))
                or bound["sha256"] != CONFIG["receipt_sha256"]):
            raise ValueError("question generation external pin differs")


def _png_container(raw):
    """Strict bounded CRC check; does not decompress or simulate a decoder."""
    if type(raw) is not bytes or not 57 <= len(raw) <= 16 * 1024**2 or raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("bounded PNG signature required")
    offset, types, idat_bytes = 8, [], 0
    while offset < len(raw):
        if len(types) >= 512 or len(raw) - offset < 12:
            raise ValueError("PNG chunk envelope invalid")
        size = struct.unpack_from(">I", raw, offset)[0]
        kind = raw[offset + 4:offset + 8]
        end = offset + 12 + size
        if end > len(raw) or kind not in (b"IHDR", b"IDAT", b"IEND"):
            raise ValueError("PNG transparency, animation, metadata or unknown chunk is not allowed")
        payload = raw[offset + 8:offset + 8 + size]
        crc = struct.unpack_from(">I", raw, offset + 8 + size)[0]
        if zlib.crc32(kind + payload) & 0xffffffff != crc:
            raise ValueError("PNG chunk CRC mismatch")
        if kind == b"IHDR":
            if types or size != 13 or struct.unpack(">IIBBBBB", payload) != (1920, 1080, 8, 2, 0, 0, 0):
                raise ValueError("exact 1920x1080 noninterlaced 8bit RGB IHDR required")
        elif kind == b"IDAT":
            if not types or types[-1] not in (b"IHDR", b"IDAT") or size == 0:
                raise ValueError("nonempty consecutive IDAT required")
            idat_bytes += size
        elif size != 0 or not types or types[-1] != b"IDAT" or end != len(raw):
            raise ValueError("terminal zero-length IEND required after IDAT")
        types.append(kind)
        offset = end
    if not types or types[-1] != b"IEND" or idat_bytes == 0:
        raise ValueError("PNG terminal/image data missing")
    return {"check": "PNG_CONTAINER_CRC_IHDR_NO_ALPHA_APNG_OR_EXTRA_CHUNKS", "width": 1920, "height": 1080,
        "bit_depth": 8, "color_type": 2, "interlaced": False, "chunks": [kind.decode("ascii") for kind in types],
        "idat_bytes": idat_bytes, "decompressed": False}


def _contract(row, state, original):
    matches = [value for value in EXPECTED if value[0] == state.get("state_id")]
    if len(matches) != 1:
        raise ValueError("unknown question literal state")
    sid, uid, tid, copy_text = matches[0]
    _same([row["unit_id"], original["state_id"], original["unit_id"], original["take_id"], original["copy"]],
          [uid, sid, uid, tid, copy_text], "question source unit/take/copy differs")
    if tid not in row["fragment_ids"]:
        raise ValueError("question source take outside literal unit")
    _same(state["visual_content"]["literal_copy"], copy_text, "question effective copy differs")
    restored = copy.deepcopy(state)
    restored["visual_content"]["literal_copy"] = original["source_state"]["visual_content"]["literal_copy"]
    _same(restored, original["source_state"], "question changed more than explicit casing")
    lexical = sid == "visual-u020-s01"
    entry = ({"kind": "LEXICAL_START", "char_start": 18, "char_end": 35, "text": "or only possible?",
              "previous_state_id": "visual-u020-s00"} if lexical else
             {"kind": "UNIT_ENTRY", "char_start": None, "char_end": None, "text": None, "previous_state_id": None})
    _same([state["entry"], original["entry"]], [entry, entry], "question entry differs or invented timing")
    if lexical and row["text"][18:35] != entry["text"]:
        raise ValueError("lexical question range differs from narration")
    return {"state_id": sid, "unit_id": uid, "fragment_ids": [tid], "unit_fragment_ids": copy.deepcopy(row["fragment_ids"]),
        "literal_narration": row["text"], "literal_copy": copy.deepcopy(copy_text), "text_blocks": copy.deepcopy(copy_text),
        "entry": entry, "timing_kind": "CALIBRATED_LEXICAL_REQUIRED" if lexical else "UNIT_ENTRY_NOT_BOUND",
        "lexical_target": {"unit_id": uid, "fragment_id": tid, **{key: entry[key] for key in ("text", "char_start", "char_end")}} if lexical else None,
        "continuation_of_state_id": None, "visual_content": copy.deepcopy(state["visual_content"])}


def _preflight(root):
    reader = primitives._Reader(root)
    implementation = Path(__file__).absolute()
    if implementation != reader.root / "hero_engine/phase6_av_question_sources.py":
        raise ValueError("question inspector loaded from another root")
    # Freeze the executing source before the historical replay. Hashing only
    # after replay could advertise substituted bytes as the implementation used.
    reader.read_path(implementation, primitives._sha(primitives._resident(implementation).read_bytes()))
    # Fixed code only; no arbitrary executor loaded from source or receipt data.
    import importlib.util
    path = reader.path(STAGER)
    reader.read(STAGER, STAGER_SHA)
    reader.read(STAGER_TEST, STAGER_TEST_SHA)
    spec = importlib.util.spec_from_file_location("question_source_frozen_stager_v2", path)
    stager = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stager)
    guard_bindings = tuple(reader.bindings.values())
    if stager.ROOT != reader.root:
        raise ValueError("question evidence belongs to another canonical root")
    values = stager.prepare(STAGER_SHA, STAGER_TEST_SHA)
    reader = values["reader"]
    documents = stager.output_paths(values["body"], values["projection"])
    identifier = values["body"]["amendment_id"]
    claim = stager.HERE / (identifier + "-claim")
    claim_raw = primitives._canonical({"version": "question-case-claim-v2", "qa_replay": stager.RECON_BINDING,
        "amendment_id": identifier, "authority": values["body"]["authority"], "publication_authorized": False})
    reader.read_path(claim / "claim.json", primitives._sha(claim_raw))
    values["claim_directory"] = claim
    for path, raw in documents.items():
        reader.read_path(path, primitives._sha(raw))
    expected = {"version": stager.VERSION, "status": "STAGED_NOT_ACCEPTED_BY_A10", "runner_sha256": STAGER_SHA,
        "test_sha256": STAGER_TEST_SHA, "qa_replay": stager.RECON_BINDING, "original_failed_qa": values["recon"].ORIGINAL_QA,
        "historical_ink_scope": "EXTERNAL_PINNED_MEASUREMENT_REPLAY_NOT_REMEASURED",
        "artifacts": {path.relative_to(reader.root).as_posix(): primitives._sha(raw) for path, raw in documents.items()},
        "dependency_bindings": list(reader.bindings.values()), "technical_cost_brl": 0, "media_generation_calls": 0,
        "ocr_inference_calls": 0, "image_decode_calls": 0, "pixel_measurement_calls": 0,
        "authority": values["body"]["authority"], "publication_authorized": False}
    raw = reader.read(STAGING_BINDING["path"], STAGING_BINDING["sha256"])
    if raw != primitives._canonical(expected):
        raise ValueError("staging receipt does not independently recompose")
    for binding in CONFIG["source_bindings"].values():
        reader.read(binding["path"], binding["sha256"])
    for item in guard_bindings:
        reader.read_path(Path(item["path"]), item["sha256"])
    stager.recheck(values)
    return stager, values


def recheck_question_dependencies(root, proofs):
    """Same-call sink only; never a verifier of candidate-provided authority."""
    if type(proofs) is not list or not proofs:
        raise ValueError("question proof dependency sink required")
    reader = primitives._Reader(root)
    dependencies = {}
    for proof in proofs:
        items = proof.get("dependency_bindings") if type(proof) is dict else None
        if type(items) is not list or not items:
            raise ValueError("question dependencies missing")
        seen = set()
        for item in items:
            if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                    or type(item["path"]) is not str or item["path"] in seen
                    or type(item["size_bytes"]) is not int or item["size_bytes"] <= 0):
                raise ValueError("invalid question dependency")
            seen.add(item["path"])
            _same(dependencies.setdefault(item["path"], item), item, "conflicting question dependency")
        if not set(primitives.EXTERNAL_DEPENDENCY_PINS).issubset(seen):
            raise ValueError("question font/decoder pins missing")
    for path, item in sorted(dependencies.items()):
        selected = Path(path)
        if path in primitives.EXTERNAL_DEPENDENCY_PINS:
            _same(item["sha256"], primitives.EXTERNAL_DEPENDENCY_PINS[path], "question external pin differs")
        elif not selected.is_relative_to(reader.root):
            raise ValueError("question dependency escapes root")
        model = MODEL_PINS.get(selected.relative_to(reader.root).as_posix()) if selected.is_relative_to(reader.root) else None
        if model:
            _same([item["sha256"], item["size_bytes"]], list(model), "question model pin or size differs")
        raw = reader.read_path(selected, item["sha256"], limit=32 * 1024**2 if model else 16 * 1024**2)
        if len(raw) != item["size_bytes"]:
            raise ValueError("question dependency byte length changed")
    _recheck_inventories(reader, dependencies)
    return len(dependencies)


def _recheck_inventories(reader, dependencies):
    receipt_path = CONFIG["directory"] + "/receipt.json"
    receipt = primitives._json(reader.read(receipt_path, CONFIG["receipt_sha256"]))
    names = {sid + suffix for sid in CONFIG["state_ids"] for suffix in (".png", ".svg")} | {"layouts.json"}
    if set(receipt["artifact_sha256"]) != names:
        raise ValueError("question receipt inventory differs")
    inventories = {
        CONFIG["directory"]: names | {"receipt.json"},
        HERE + "/qa-ee4c24ad026d706976705dff": {"report.json", "started.json"} | {"ocr-" + sid + ".json" for sid in CONFIG["state_ids"]},
        HERE + "/reconciliation-f3904b4f063f15c87e2bfd9b": {"report.json", "started.json"},
        HERE + "/question-case-amendment-v2-1e60348b0c51a9116c8177f9-claim": {"claim.json"},
    }
    required = {str(reader.root / path) for path in (STAGER, STAGER_TEST, receipt_path, STAGING_BINDING["path"], *MODEL_PINS)}
    required.update(str(reader.root / bound["path"]) for bound in CONFIG["source_bindings"].values())
    for directory, expected in inventories.items():
        path = reader.path(directory)
        if {child.name for child in path.iterdir()} != expected:
            raise ValueError("question historical or source inventory drift")
        required.update(str(path / name) for name in expected)
    runtime = receipt["contract"]["runtime"]
    runtime_dir = reader.path(".venv/Lib/site-packages/PIL")
    if len(runtime) != 105 or {child.name for child in runtime_dir.iterdir() if child.suffix in (".py", ".pyd")} != set(runtime):
        raise ValueError("question Pillow inventory drift")
    for name, digest in runtime.items():
        path = str(runtime_dir / name)
        required.add(path)
        if dependencies.get(path, {}).get("sha256") != digest:
            raise ValueError("question Pillow dependency omitted or repinned")
    if not required.issubset(dependencies):
        raise ValueError("question mandatory evidence dependency omitted")


def inspect_question_sources(root, requests):
    _requests(root, requests)
    stager, values = _preflight(root)
    reader, receipt, projection = values["reader"], values["state"]["receipt"], values["projection"]
    states = {state["state_id"]: (row, state) for row in projection["effective_rows"] for state in row["states"]}
    originals = receipt["contract"]["design"]["states"]
    _same([state["state_id"] for state in originals], CONFIG["state_ids"], "question source population differs")
    bible_binding = CONFIG["source_bindings"]["style_bible"]
    bible = primitives._json(reader.read(bible_binding["path"], bible_binding["sha256"]))
    _same([bible["channel_id"], bible["palette"]["locked_hex"]], [primitives.CHANNEL, primitives.PALETTE], "question ChannelDNA/palette differs")
    measured, contracts = {}, {}
    for original in originals:
        sid = original["state_id"]
        contracts[sid] = _contract(*states[sid], original)
        measured[sid] = _png_container(values["state"]["artifacts"][sid + ".png"])
    stager.recheck(values)
    common = {"version": VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED", "template_id": TEMPLATE_ID,
        "media_kind": "STATIC_IMAGE", "width": 1920, "height": 1080, "mode": "RGB", "opacity": "OPAQUE",
        "source_frame_count": 1, "source_start_frame": 0, "source_end_frame": 1,
        "lineage_id": CONFIG["lineage_id"], "channel_id": primitives.CHANNEL, "style_bible_id": bible["style_bible_id"],
        "observed_sample": None, "video_frame": None, "source_technically_verified": True, "source_ready": False,
        "global_schedule_created": False, "calibrated_timing_available": False, "technical_cost_brl": 0,
        "authority": dict(AUTHORITY), "state_count": 4, "unique_content_count": 4, "lineage_count": 1,
        "receipt_binding": {"path": str(reader.root / CONFIG["directory"] / "receipt.json"), "sha256": CONFIG["receipt_sha256"]},
        "source_bindings": copy.deepcopy(CONFIG["source_bindings"]), "case_staging_binding": copy.deepcopy(STAGING_BINDING),
        "literal_reference_scope": "STAGED_CASE_V5_METADATA_NOT_ACTIVE_A10_OR_TIMING",
        "historical_qa_scope": "EXTERNAL_PINNED_PIXEL_OCR_INK_REPLAY_NOT_REEXECUTED",
        "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
        "claim_boundary": "Question PNG container/CRC/no-alpha plus exact historical pixel/OCR/ink and staged literal contracts; no timing, rights/publicity, audio, motion or final-video approval.",
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"])}
    result = {}
    for sid, qa_row in zip(CONFIG["state_ids"], values["report"]["states"], strict=True):
        asset = reader.bindings[str(reader.root / CONFIG["directory"] / (sid + ".png"))]
        _same([qa_row["state_id"], qa_row["png_sha256"]], [sid, asset["sha256"]], "question QA source differs")
        proof = {**common, **contracts[sid], "asset_binding": asset, "content_sha256": asset["sha256"],
            "equivalent_state_ids": [sid], "canonical_content_state_id": sid, "container_check": measured[sid],
            "layout_records": receipt["contract"]["layouts"][sid], "historical_static_qa": copy.deepcopy(qa_row)}
        proof["inspection_id"] = "question-source-" + primitives._sha(primitives._canonical(proof))[:24]
        result[sid] = proof
    if len({proof["content_sha256"] for proof in result.values()}) != 4:
        raise ValueError("question content identities unexpectedly coincide")
    selected = [result[request["state_id"]] for request in requests]
    recheck_question_dependencies(root, selected)
    stager.recheck(values)
    return primitives._json(primitives._canonical(selected))


def inspect_question_source(root, *, template_id, state_id, receipt_binding):
    return inspect_question_sources(root, [{"template_id": template_id, "state_id": state_id, "receipt_binding": receipt_binding}])[0]


def verify_question_source(candidate, root, **arguments):
    expected = inspect_question_source(root, **arguments)
    _same(candidate, expected, "question source proof replay differs")
    return expected
