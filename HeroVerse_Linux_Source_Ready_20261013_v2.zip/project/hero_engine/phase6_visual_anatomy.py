"""Local VBench/SimMIM anatomical anomaly observation, not release authority.

The independent, labelled upstream model measures intrinsic appearance, unlike
pose confidence or agreement with a possibly defective source. CPU FP32 only,
one declared ROI per invocation, no downloads, no training, no queue or media
effects. Published operating points retain their benchmark scope; coverage and
domain controls are required before a project QA gate can consume a verdict.

Forward operations follow the MIT-licensed Microsoft SimMIM VisionTransformer
used by Vchitect/VBench-2.0 (ViT-B/16, relative bias, mean pooling, eps 1e-6).
Checkpoint tensors are read with weights_only=True; arbitrary pickle execution
and architecture/configuration supplied by the caller are not supported.
"""
from __future__ import annotations

import hashlib
import io
import importlib.metadata
import json
import re
import time
from pathlib import Path

import numpy as np
from PIL import Image

from .phase6_visual_metrics import VisualMeasurementUnavailable


VERSION = "phase6-vbench-hand-anomaly-observation-v1"
DIRECTORY = Path("models/visual-reference/vbench-anatomy-v1")
HAND_MODEL = ("hand.pth", 346836124, "b13d4522f4b5441925e4e25983013c5a9a8643ff99753732c8a64f1917b6d6a8")
# Published by upstream detect.py. NOT a newly fitted HeroVerse acceptance gate.
BENCHMARK_HAND_ANOMALY_THRESHOLD = 0.3232
MODEL_REVISION = "ebdeff2bd48e113f76db9ad1d5b59c8df3456d8e"

# Author FaceExtraction e75d4a83a696bd7379128319244ef6e5e7885fc8:
# MIT-licensed FaceOcc ResNet18/Unet, ToTensor only, foreground logit > 0.
# Architecture checked against SMP v0.2.1 and torchvision v0.11.1; the author
# does not publish the exact training dependency versions. Not domain QA.
FACE_OCC_DIRECTORY = Path('models/visual-reference/faceocc-resnet18-v1')
FACE_OCC_MODEL = ('epoch_16_best.ckpt', 57430037,
                  '01d3c3939c28e47a45acb9a5ea8f8ee460e5ecf046c0caa8404e05915e10901b')
FACE_OCC_VERSION = 'phase6-faceocc-native-observation-v1'


def _faceocc_shapes():
    shapes = {}
    def bn(prefix, channels):
        for suffix in ('weight', 'bias', 'running_mean', 'running_var'):
            shapes[prefix+'.'+suffix] = (channels,)
        shapes[prefix+'.num_batches_tracked'] = ()
    shapes['encoder.conv1.weight'] = (64, 3, 7, 7)
    bn('encoder.bn1', 64)
    previous = 64
    for level, channels in enumerate((64, 128, 256, 512), 1):
        for block in range(2):
            prefix = f'encoder.layer{level}.{block}'
            shapes[prefix+'.conv1.weight'] = (channels, previous, 3, 3)
            shapes[prefix+'.conv2.weight'] = (channels, channels, 3, 3)
            bn(prefix+'.bn1', channels); bn(prefix+'.bn2', channels)
            if level > 1 and block == 0:
                shapes[prefix+'.downsample.0.weight'] = (channels, previous, 1, 1)
                bn(prefix+'.downsample.1', channels)
            previous = channels
    for block, (inputs, outputs) in enumerate(((768, 256), (384, 128), (192, 64), (128, 32), (32, 16))):
        for conv, channels in ((1, inputs), (2, outputs)):
            prefix = f'decoder.blocks.{block}.conv{conv}'
            shapes[prefix+'.0.weight'] = (outputs, channels, 3, 3)
            bn(prefix+'.1', outputs)
    shapes['segmentation_head.0.weight'] = (1, 16, 3, 3)
    shapes['segmentation_head.0.bias'] = (1,)
    return {'module.'+name: shape for name, shape in shapes.items()}


def _validate_faceocc_state(state, torch):
    expected = _faceocc_shapes()
    if not isinstance(state, dict) or set(state) != set(expected):
        raise VisualMeasurementUnavailable('faceocc tensor population differs')
    for name, shape in expected.items():
        tensor = state[name]
        counter = name.endswith('.num_batches_tracked')
        if (not torch.is_tensor(tensor) or tensor.device.type != 'cpu'
                or tensor.layout != torch.strided or tuple(tensor.shape) != shape
                or tensor.dtype != (torch.int64 if counter else torch.float32)):
            raise VisualMeasurementUnavailable('faceocc tensor contract differs: '+name)
        if not bool(torch.isfinite(tensor).all()):
            raise VisualMeasurementUnavailable('faceocc nonfinite tensor')
        if (counter or name.endswith('.running_var')) and bool((tensor < 0).any()):
            raise VisualMeasurementUnavailable('faceocc negative variance/counter')


def preprocess_faceocc(rgb, *, spatial_contract='published-native-256'):
    """ToTensor RGB, never select a crop from predictions or reference labels.

    Native 256 is the published evaluation size, not proof of domain/alignment.
    The explicit diagnostic successor permits other native sizes by zero padding
    ONLY bottom/right to stride 32. It preserves all input pixels and discards
    padding on return; neither padding nor a full-sized mask proves visibility.
    The original 1 Mi-pixel bound remains. The separately named Full HD
    diagnostic accepts ONLY native 1920x1080, padded to 1920x1088, not an
    arbitrary larger canvas. Neither contract is domain qualification.
    """
    value = np.asarray(rgb)
    if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3:
        raise VisualMeasurementUnavailable('faceocc needs native uint8 RGB')
    h, w = value.shape[:2]
    if spatial_contract == 'published-native-256':
        if (h, w) != (256, 256):
            raise VisualMeasurementUnavailable('published faceocc input must be native 256 square')
    elif spatial_contract == 'native-pad32-diagnostic':
        if min(h, w) < 32:
            raise VisualMeasurementUnavailable('faceocc native diagnostic side below stride')
    elif spatial_contract == 'native-fullhd-pad32-diagnostic':
        if (h, w) != (1080, 1920):
            raise VisualMeasurementUnavailable('faceocc Full HD diagnostic needs exact native 1920x1080')
    else:
        raise VisualMeasurementUnavailable('unknown faceocc spatial contract')
    height, width = ((h+31)//32)*32, ((w+31)//32)*32
    if height*width > 1048576 and spatial_contract != 'native-fullhd-pad32-diagnostic':
        raise VisualMeasurementUnavailable('faceocc bounded native workload exceeded')
    output = np.zeros((1, 3, height, width), np.float32)
    output[0, :, :h, :w] = value.transpose(2, 0, 1).astype(np.float32)/255
    return output, {'spatial_contract': spatial_contract, 'input_size': [w, h],
        'model_size': [width, height], 'padding_right_bottom': [width-w, height-h],
        'resize_or_crop': False, 'native_pixels_retained': True,
        'published_input_size': (h, w) == (256, 256), 'domain_or_alignment_qualified': False}


class FaceOcclusionObserver:
    """Prompt-free semantic region measurement, never an anatomical verdict."""
    def __init__(self, root: Path):
        self.root = root.resolve()
        name, size, digest = FACE_OCC_MODEL
        self.path = (self.root/FACE_OCC_DIRECTORY/name).resolve()
        if self.root not in self.path.parents:
            raise PermissionError('faceocc model escaped root')
        _binding(self.path, digest, size)
        # Hash and deserialize the SAME immutable buffer; no shared mmap after
        # binding and no arbitrary pickle/architecture/configuration execution.
        raw = self.path.read_bytes()
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
            raise PermissionError('faceocc model changed before loading')
        if importlib.metadata.version('torch') != '2.8.0+cpu':
            raise VisualMeasurementUnavailable('pinned faceocc CPU runtime unavailable')
        import torch
        self.torch = torch
        previous_threads = torch.get_num_threads()
        try:
            torch.set_num_threads(1)
            state = torch.load(io.BytesIO(raw), map_location='cpu', weights_only=True)
            _validate_faceocc_state(state, torch)
            self.state = {name.removeprefix('module.'): tensor for name, tensor in state.items()}
            _binding(self.path, digest, size)
        finally:
            torch.set_num_threads(previous_threads)

    def logits(self, tensor, *, spatial_contract='native-pad32-diagnostic'):
        torch, s = self.torch, self.state
        f = torch.nn.functional
        if (spatial_contract not in ('native-pad32-diagnostic', 'native-fullhd-pad32-diagnostic')
                or not torch.is_tensor(tensor) or tensor.device.type != 'cpu' or tensor.dtype != torch.float32
                or tensor.ndim != 4 or tuple(tensor.shape[:2]) != (1, 3)
                or min(tensor.shape[2:]) < 32 or any(side % 32 for side in tensor.shape[2:])
                or (spatial_contract == 'native-fullhd-pad32-diagnostic' and tuple(tensor.shape[2:]) != (1088,1920))
                or (spatial_contract != 'native-fullhd-pad32-diagnostic' and tensor.shape[2]*tensor.shape[3] > 1048576)
                or not bool(torch.isfinite(tensor).all()) or bool(((tensor < 0) | (tensor > 1)).any())):
            raise VisualMeasurementUnavailable('faceocc input tensor contract differs')
        def conv(x, prefix, stride=1, padding=1):
            return f.conv2d(x, s[prefix+'.weight'], s.get(prefix+'.bias'), stride=stride, padding=padding)
        def bn(x, prefix):
            return f.batch_norm(x, s[prefix+'.running_mean'], s[prefix+'.running_var'],
                s[prefix+'.weight'], s[prefix+'.bias'], training=False, eps=1e-5)
        threads = torch.get_num_threads()
        try:
            torch.set_num_threads(1)
            with torch.inference_mode():
                x = f.relu(bn(conv(tensor, 'encoder.conv1', 2, 3), 'encoder.bn1'))
                features = [x]
                x = f.max_pool2d(x, 3, stride=2, padding=1)
                for level in range(1, 5):
                    for block in range(2):
                        prefix = f'encoder.layer{level}.{block}'
                        stride = 2 if level > 1 and block == 0 else 1
                        identity = bn(conv(x, prefix+'.downsample.0', 2, 0), prefix+'.downsample.1') if stride == 2 else x
                        y = f.relu(bn(conv(x, prefix+'.conv1', stride), prefix+'.bn1'))
                        x = f.relu(bn(conv(y, prefix+'.conv2'), prefix+'.bn2')+identity)
                    features.append(x)
                for block in range(5):
                    x = f.interpolate(x, scale_factor=2, mode='nearest')
                    if block < 4:
                        x = torch.cat((x, features[3-block]), dim=1)
                    for number in (1, 2):
                        prefix = f'decoder.blocks.{block}.conv{number}'
                        x = f.relu(bn(conv(x, prefix+'.0'), prefix+'.1'))
                result = conv(x, 'segmentation_head.0')
                if tuple(result.shape) != (1, 1, *tensor.shape[2:]) or not bool(torch.isfinite(result).all()):
                    raise VisualMeasurementUnavailable('faceocc logits invalid')
                return result
        finally:
            torch.set_num_threads(threads)

    def observe(self, rgb, *, spatial_contract='published-native-256', face_observation=None):
        started = time.monotonic()
        # Seal the exact caller pixels before preprocessing/native execution.
        # Receipt and tensor must not refer to different versions of a buffer.
        pixels = np.array(rgb, copy=True, order='C')
        array, plan = preprocess_faceocc(pixels, spatial_contract=spatial_contract)
        if face_observation is not None:
            import copy
            from .phase6_visual_landmarks import compare_face_geometry, measure_face_region_membership
            face_observation = copy.deepcopy(face_observation)
            width, height = plan['input_size']
            geometry = compare_face_geometry(face_observation, face_observation, pixels, pixels,
                layout={'canvas': {'width': width, 'height': height}, 'decorations': [], 'overlays': []})
            if geometry['reference_face_count'] and not geometry['matches']:
                raise VisualMeasurementUnavailable('complete face geometry required before region inference')
        _binding(self.path, FACE_OCC_MODEL[2], FACE_OCC_MODEL[1])
        tensor = self.torch.from_numpy(array)
        logits = (self.logits(tensor, spatial_contract=spatial_contract)
                  if spatial_contract == 'native-fullhd-pad32-diagnostic'
                  else self.logits(tensor))[0, 0].numpy()
        w, h = plan['input_size']
        native_logits = np.ascontiguousarray(logits[:h, :w])
        mask = (native_logits > 0).astype(np.uint8)  # exact published threshold
        _binding(self.path, FACE_OCC_MODEL[2], FACE_OCC_MODEL[1])
        result = {'version': FACE_OCC_VERSION, 'status': 'SEMANTIC_FACE_REGION_OBSERVED_NOT_QUALIFIED',
            'model_sha256': 'sha256:'+FACE_OCC_MODEL[2], 'runtime': 'torch-2.8.0+cpu-fp32-one-thread',
            'plan': plan, 'input_rgb_sha256': 'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest(),
            'native_logits_sha256': 'sha256:'+hashlib.sha256(native_logits.tobytes()).hexdigest(),
            'mask_sha256': 'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
            'foreground_pixels': int(mask.sum()), 'foreground_rule': 'logit_strictly_greater_than_zero',
            'detector_or_reference_prompts': False, 'model_invocations': 1,
            'semantic_scope': 'FaceOcc visible facial attributes excluding occluders; not identity/anatomy',
            'complete_visibility_proved': False, 'project_domain_calibrated': False,
            'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False,
            'elapsed_seconds': time.monotonic()-started}
        if face_observation is not None:
            result['landmark_region_membership'] = measure_face_region_membership(
                pixels, face_observation, result, mask)
        return result, mask


def _binding(path: Path, digest: str, size: int | None = None):
    if not path.is_file() or (size is not None and path.stat().st_size != size):
        raise PermissionError("anatomy input missing/size changed")
    with path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != digest.removeprefix("sha256:"):
        raise PermissionError("anatomy input differs from external anchor")
    return actual


def preprocess_roi(rgb: np.ndarray) -> np.ndarray:
    """Exact published eval transform: bicubic 256 -> centre 224, ImageNet norm.

    Input is a declared ROI. Upstream held-out data includes a 65x64 ROI: use
    the published shortest-edge resize, never stretch a rectangle to a square.
    The model's intentional 224 centre crop is recorded, not full-hand coverage.
    """
    value = np.asarray(rgb)
    if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3 or min(value.shape[:2]) < 16:
        raise VisualMeasurementUnavailable("RGB uint8 ROI with at least 16 pixels per side required")
    h, w = value.shape[:2]
    new_w, new_h = (256, int(256*h/w)) if w <= h else (int(256*w/h), 256)
    left, top = int(round((new_w - 224) / 2.)), int(round((new_h - 224) / 2.))
    image = Image.fromarray(value).resize((new_w, new_h), Image.Resampling.BICUBIC).crop((left, top, left+224, top+224))
    result = np.asarray(image, dtype=np.float32) / 255
    result = (result - np.asarray([.485, .456, .406], np.float32)) / np.asarray([.229, .224, .225], np.float32)
    return np.ascontiguousarray(result.transpose(2, 0, 1)[None])


def _tensor_shapes():
    shapes = {"cls_token": (1, 1, 768), "patch_embed.proj.weight": (768, 3, 16, 16),
              "patch_embed.proj.bias": (768,), "fc_norm.weight": (768,), "fc_norm.bias": (768,),
              "head.weight": (2, 768), "head.bias": (2,)}
    for i in range(12):
        local = {"gamma_1": (768,), "gamma_2": (768,), "norm1.weight": (768,), "norm1.bias": (768,),
                 "norm2.weight": (768,), "norm2.bias": (768,), "attn.q_bias": (768,), "attn.v_bias": (768,),
                 "attn.qkv.weight": (2304, 768), "attn.proj.weight": (768, 768), "attn.proj.bias": (768,),
                 "attn.relative_position_bias_table": (732, 12), "attn.relative_position_index": (197, 197),
                 "mlp.fc1.weight": (3072, 768), "mlp.fc1.bias": (3072,), "mlp.fc2.weight": (768, 3072), "mlp.fc2.bias": (768,)}
        shapes.update({f"blocks.{i}.{name}": shape for name, shape in local.items()})
    return shapes


def full_roi_view_plan(width: int, height: int) -> dict:
    """Cover the published resized ROI, not an inferred complete hand.

    Keep the original 256-short-edge bicubic transform and 224 model window.
    A deterministic edge-anchored grid covers every resized pixel; no learned
    score, label or candidate selects a crop. Sixteen views is a workload bound,
    not a quality cutoff. Oversized workloads fail rather than omit a region.
    """
    if type(width) is not int or type(height) is not int or min(width, height) < 16:
        raise VisualMeasurementUnavailable('full ROI needs integer dimensions >=16')
    new_w, new_h = (256, int(256*height/width)) if width <= height else (int(256*width/height), 256)
    def starts(length):
        count = (length-224)//224+1
        if count > 16:
            raise VisualMeasurementUnavailable('complete ROI exceeds bounded window workload')
        values = list(range(0, length-224+1, 224))
        if values[-1] != length-224:
            values.append(length-224)
        return values
    xs, ys = starts(new_w), starts(new_h)
    if len(xs)*len(ys) > 16:
        raise VisualMeasurementUnavailable('complete ROI exceeds bounded window workload')
    windows = [[x, y, x+224, y+224] for y in ys for x in xs]
    left, top = round((new_w-224)/2), round((new_h-224)/2)
    return {'version': 'phase6-hand-complete-resized-roi-grid-v1',
            'input_size': [width, height], 'resized_size': [new_w, new_h],
            'windows_xyxy': windows, 'legacy_centre_xyxy': [left, top, left+224, top+224],
            'resized_pixels_outside_legacy_window': new_w*new_h-224*224,
            'complete_resized_roi_coverage': True, 'complete_hand_coverage_proved': False,
            'selection_uses_scores_or_labels': False, 'quality_authorized': False}


def full_roi_views(rgb: np.ndarray):
    """Yield existing-information windows; no padding, new detail or inference."""
    value = np.asarray(rgb)
    if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3:
        raise VisualMeasurementUnavailable('full ROI requires native uint8 RGB')
    plan = full_roi_view_plan(value.shape[1], value.shape[0])
    image = Image.fromarray(value).resize(tuple(plan['resized_size']), Image.Resampling.BICUBIC)
    for box in plan['windows_xyxy']:
        pixels = np.asarray(image.crop(tuple(box)), dtype=np.float32)/255
        pixels = (pixels-np.asarray([.485, .456, .406], np.float32))/np.asarray([.229, .224, .225], np.float32)
        yield box, np.ascontiguousarray(pixels.transpose(2, 0, 1)[None])


class HandAnomalyObserver:
    def __init__(self, root: Path):
        self.root = root.resolve()
        name, size, digest = HAND_MODEL
        self.path = (self.root / DIRECTORY / name).resolve()
        if self.root not in self.path.parents:
            raise PermissionError("anatomy model escaped root")
        _binding(self.path, digest, size)
        if importlib.metadata.version("torch") != "2.8.0+cpu":
            raise VisualMeasurementUnavailable("pinned CPU anatomy runtime is unavailable")
        import torch
        self.torch = torch
        # Serial limits, no CUDA/provider fallback or downloads. Memory map
        # avoids a duplicate 347 MB checkpoint buffer during initialization.
        torch.set_num_threads(1)
        loaded = torch.load(self.path, map_location="cpu", weights_only=True, mmap=True)
        state = loaded.get("model") if isinstance(loaded, dict) else None
        expected = _tensor_shapes()
        if not isinstance(state, dict) or set(state) != set(expected):
            raise VisualMeasurementUnavailable("anatomy checkpoint tensor population differs")
        for name, shape in expected.items():
            tensor = state[name]
            index = name.endswith("relative_position_index")
            if not torch.is_tensor(tensor) or tuple(tensor.shape) != shape or tensor.dtype != (torch.int64 if index else torch.float32):
                raise VisualMeasurementUnavailable("anatomy checkpoint tensor contract differs: " + name)
            if not index and not bool(torch.isfinite(tensor).all()):
                raise VisualMeasurementUnavailable("nonfinite anatomy tensor")
            if index and (int(tensor.min()) < 0 or int(tensor.max()) >= 732):
                raise VisualMeasurementUnavailable("invalid relative position index")
        self.state = state
        _binding(self.path, digest, size)

    def logits(self, tensor):
        """Direct published inference graph, no random parameters or training."""
        torch, s = self.torch, self.state
        f = torch.nn.functional
        if tuple(tensor.shape) != (1, 3, 224, 224) or tensor.dtype != torch.float32 or not bool(torch.isfinite(tensor).all()):
            raise VisualMeasurementUnavailable("anatomy input tensor contract differs")
        def linear(x, prefix):
            return f.linear(x, s[prefix + ".weight"], s[prefix + ".bias"])
        def norm(x, prefix):
            return f.layer_norm(x, (768,), s[prefix + ".weight"], s[prefix + ".bias"], 1e-6)
        with torch.inference_mode():
            x = f.conv2d(tensor, s["patch_embed.proj.weight"], s["patch_embed.proj.bias"], stride=16).flatten(2).transpose(1, 2)
            x = torch.cat((s["cls_token"], x), dim=1)
            for i in range(12):
                prefix = f"blocks.{i}."
                z = norm(x, prefix + "norm1")
                bias = torch.cat((s[prefix + "attn.q_bias"], torch.zeros_like(s[prefix + "attn.v_bias"]), s[prefix + "attn.v_bias"]))
                qkv = f.linear(z, s[prefix + "attn.qkv.weight"], bias).reshape(1, 197, 3, 12, 64).permute(2, 0, 3, 1, 4)
                q, k, v = qkv.unbind(0)
                attention = (q * (64 ** -.5)) @ k.transpose(-2, -1)
                table = s[prefix + "attn.relative_position_bias_table"]
                indices = s[prefix + "attn.relative_position_index"].reshape(-1)
                attention = (attention + table[indices].view(197, 197, 12).permute(2, 0, 1).unsqueeze(0)).softmax(-1)
                z = (attention @ v).transpose(1, 2).reshape(1, 197, 768)
                x = x + s[prefix + "gamma_1"] * linear(z, prefix + "attn.proj")
                z = norm(x, prefix + "norm2")
                z = linear(f.gelu(linear(z, prefix + "mlp.fc1")), prefix + "mlp.fc2")
                x = x + s[prefix + "gamma_2"] * z
            result = linear(norm(x[:, 1:, :].mean(1), "fc_norm"), "head")
        if tuple(result.shape) != (1, 2) or not bool(torch.isfinite(result).all()):
            raise VisualMeasurementUnavailable("anatomy logits are invalid")
        return result

    def observe(self, rgb: np.ndarray) -> dict:
        started = time.monotonic()
        array = preprocess_roi(rgb)
        probabilities = self.logits(self.torch.from_numpy(array)).softmax(-1)[0].tolist()
        score = float(probabilities[0])  # Upstream detect.py: class 0 = anomaly.
        _binding(self.path, HAND_MODEL[2], HAND_MODEL[1])
        return {"version": VERSION, "model_sha256": "sha256:" + HAND_MODEL[2],
                "runtime": "torch-2.8.0+cpu-fp32-one-thread", "class_order": ["anomaly", "normal"],
                "probabilities": probabilities, "anomaly_score": score,
                "benchmark_threshold": BENCHMARK_HAND_ANOMALY_THRESHOLD,
                "benchmark_classification": "ANOMALOUS" if score > BENCHMARK_HAND_ANOMALY_THRESHOLD else "NORMAL",
                "scope": "declared-ROI-aspect-preserving-resize-centre-crop-only", "project_domain_calibrated": False,
                "quality_authorized": False, "publication_authorized": False,
                "elapsed_seconds": time.monotonic() - started}

    def observe_full_roi(self, rgb: np.ndarray) -> dict:
        """Explicit diagnostic successor; never a silent replacement for observe.

        The benchmark's threshold was validated for a single centre crop, not a
        maximum over views. Report that maximum only as a diagnostic operating
        point. Spatial coverage does not itself qualify sensitivity/anatomy.
        """
        started = time.monotonic()
        value = np.asarray(rgb)
        if value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3:
            raise VisualMeasurementUnavailable('full ROI requires native uint8 RGB')
        plan = full_roi_view_plan(value.shape[1], value.shape[0])
        rows = []
        for box, tensor in full_roi_views(value):
            probabilities = self.logits(self.torch.from_numpy(tensor)).softmax(-1)[0].tolist()
            score = float(probabilities[0])
            rows.append({'window_xyxy': box, 'probabilities': probabilities,
                         'anomaly_score': score, 'above_original_threshold': score > BENCHMARK_HAND_ANOMALY_THRESHOLD,
                         'normalized_tensor_sha256': 'sha256:'+hashlib.sha256(tensor.tobytes()).hexdigest()})
        _binding(self.path, HAND_MODEL[2], HAND_MODEL[1])
        return {'version': 'phase6-vbench-complete-roi-observation-v1',
                'model_sha256': 'sha256:'+HAND_MODEL[2], 'runtime': 'torch-2.8.0+cpu-fp32-one-thread',
                'input_rgb_sha256': 'sha256:'+hashlib.sha256(value.tobytes()).hexdigest(),
                'plan': plan, 'windows': rows, 'model_invocations': len(rows),
                'minimum_score': min(r['anomaly_score'] for r in rows),
                'maximum_score': max(r['anomaly_score'] for r in rows),
                'window_decisions_agree': len({r['above_original_threshold'] for r in rows}) == 1,
                'benchmark_threshold_unchanged': BENCHMARK_HAND_ANOMALY_THRESHOLD,
                'multiwindow_operating_point_qualified': False, 'project_domain_calibrated': False,
                'native_information_recovered': False, 'quality_authorized': False,
                'render_authorized': False, 'publication_authorized': False,
                'elapsed_seconds': time.monotonic()-started}


def evaluate_labelled_controls(root: Path, *, acquisition_path: Path, expected_sha256: str) -> dict:
    """Real independent labels -> bytes -> inference -> confusion, no PASS input.

    A selected subset tests the instrument on those images. It cannot establish
    generalization to a channel/video domain or certify every hand in a video.
    Labels are upstream held-out data, never fitted to HeroVerse's candidate.
    """
    root = root.resolve()
    acquisition_path = acquisition_path.resolve()
    if root not in acquisition_path.parents:
        raise PermissionError("control acquisition escaped root")
    _binding(acquisition_path, expected_sha256)
    record_raw = acquisition_path.read_bytes()
    record = json.loads(record_raw)
    if record.get("status") != "LABELLED_SUBSET_ACQUIRED_NOT_CALIBRATED" or record.get("quality_authorized") is not False:
        raise PermissionError("independent acquisition contract differs")
    label_binding = record["labels"]
    label_path = (root / label_binding["path"]).resolve()
    if root not in label_path.parents:
        raise PermissionError("control labels escaped root")
    _binding(label_path, label_binding["sha256"], label_binding["size_bytes"])
    labels_raw = label_path.read_bytes()
    labels = [json.loads(line) for line in labels_raw.splitlines() if line.strip()]
    controls = record["controls"]
    expected_annotations = [r for label in (0, 1) for r in sorted((r for r in labels if r[1] == label), key=lambda r: r[0])[:4]]
    if len(expected_annotations) != 8 or [row["upstream_annotation"] for row in controls] != expected_annotations:
        raise PermissionError("control subset differs from preselected independent population")
    saved = [(acquisition_path, record_raw), (label_path, labels_raw)]
    for row in controls:
        path = (root / row["binding"]["path"]).resolve()
        if root not in path.parents:
            raise PermissionError("control pixels escaped root")
        _binding(path, row["binding"]["sha256"], row["binding"]["size_bytes"])
    observer = HandAnomalyObserver(root)
    observations = []
    confusion = {"true_anomaly": 0, "true_normal": 0, "false_anomaly": 0, "missed_anomaly": 0}
    for row in controls:
        path = (root / row["binding"]["path"]).resolve()
        raw = path.read_bytes()
        import io
        with Image.open(io.BytesIO(raw)) as image:
            pixels = np.asarray(image.convert("RGB"))
        observation = observer.observe(pixels)
        expected = "ANOMALOUS" if row["upstream_annotation"][1] == 0 else "NORMAL"
        actual = observation["benchmark_classification"]
        key = ("true_anomaly" if expected == "ANOMALOUS" else "true_normal") if expected == actual else ("false_anomaly" if actual == "ANOMALOUS" else "missed_anomaly")
        confusion[key] += 1
        observations.append({"input": row["binding"], "label": row["upstream_annotation"],
                             "expected_class": expected, "observation": observation, "matches": expected == actual})
        saved.append((path, raw))
    if any(path.read_bytes() != raw for path, raw in saved):
        raise PermissionError("control source changed during evaluation")
    return {"version": VERSION, "status": "INDEPENDENT_CONTROLS_MEASURED", "controls": observations,
            "confusion": confusion, "sample_count": len(observations), "full_benchmark_run": False,
            "candidate_used_for_selection_or_fitting": False, "project_domain_calibrated": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}


def origin_disjoint_control_plan(labels: list, previous_annotations: list) -> dict:
    """Sixteen bounded controls selected before scores, grouped by source video.

    Four examples/class/partition is an explicit acquisition budget, NOT a
    sufficient sample-size claim or quality threshold. Every previously seen
    video's group is excluded; known counterexamples remain historical.
    Sorting hashes of origin IDs avoids the old four-frames-from-one-video
    prefix selection. The input contains no score, target frame or threshold.
    """
    seen, by_name = set(), {}
    for row in labels:
        if (not isinstance(row, list) or len(row) != 3 or not isinstance(row[0], str)
                or not re.fullmatch(r"[0-9a-f]{32}_\d+_hand_\d+\.jpg", row[0])
                or type(row[1]) is not int or row[1] not in (0, 1)
                or type(row[2]) not in (int, float) or row[2] != 1.0 or row[0] in by_name):
            raise PermissionError("origin control annotations invalid or duplicated")
        by_name[row[0]] = row
    for row in previous_annotations:
        if not isinstance(row, list) or not row or by_name.get(row[0]) != row:
            raise PermissionError("previous control annotation differs from published labels")
        seen.add(row[0].split('_')[0])
    excluded = sorted(seen)
    rows = []
    for partition in ("development", "holdout"):
        for label in (0, 1):
            population = sorted((row for row in labels if row[1] == label),
                key=lambda row: (hashlib.sha256(row[0].split('_')[0].encode()).hexdigest(), row[0]))
            selected = 0
            for row in population:
                origin = row[0].split('_')[0]
                if origin in seen:
                    continue
                seen.add(origin)
                rows.append({"partition":partition,"origin_id":origin,"upstream_annotation":list(row)})
                selected += 1
                if selected == 4:
                    break
            if selected != 4:
                raise VisualMeasurementUnavailable("insufficient distinct unseen origins for balanced disjoint controls")
    return {"version":"phase6-hand-origin-disjoint-reference-v1", "controls":rows,
            "excluded_previously_observed_origins":excluded, "control_count":16, "origin_count":16,
            "selection_uses_candidate_or_scores":False, "quality_authorized":False}


def evaluate_origin_disjoint_controls(root: Path, *, acquisition_path: Path, expected_sha256: str) -> dict:
    """Reopen labelled references and test the unchanged published instrument.

    This does not lower a benchmark threshold or calibrate the channel. A
    proposed separation bound is derived on development origins, then checked
    on untouched holdout origins. Failed separation stays failed, not refitted.
    """
    root = root.resolve()
    saved = {}
    def read(binding):
        path = (root / binding["path"]).resolve()
        if root not in path.parents:
            raise PermissionError("origin control binding escaped root")
        _binding(path,binding["sha256"],binding.get("size_bytes"))
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != binding["sha256"].removeprefix('sha256:'):
            raise PermissionError("origin control changed before capture")
        saved[path] = raw
        return raw
    acquisition_path = acquisition_path.resolve()
    if root not in acquisition_path.parents:
        raise PermissionError("origin control acquisition escaped root")
    record = json.loads(read({"path":str(acquisition_path),"sha256":expected_sha256}))
    if record.get("version") != "phase6-hand-origin-disjoint-acquisition-v1" or record.get("quality_authorized") is not False:
        raise PermissionError("origin acquisition contract differs")
    labels = [json.loads(line) for line in read(record["labels"]).splitlines() if line.strip()]
    previous = json.loads(read(record["previous_acquisition"]))
    if previous.get("status") != "LABELLED_SUBSET_ACQUIRED_NOT_CALIBRATED" or previous.get("quality_authorized") is not False:
        raise PermissionError("previous acquisition authority differs")
    if previous["labels"] != record["labels"]:
        raise PermissionError("reference label revisions differ")
    plan = origin_disjoint_control_plan(labels,[row["upstream_annotation"] for row in previous["controls"]])
    encoded = lambda value: json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
    if encoded(record["plan"]) != encoded(plan) or len(record["controls"]) != 16:
        raise PermissionError("origin plan/population differs from deterministic selection")
    images = []
    pixel_sources = set()
    for row, expected in zip(record["controls"], plan["controls"]):
        if encoded(row["selection"]) != encoded(expected):
            raise PermissionError("origin selection changed/reordered")
        raw = read(row["binding"])
        digest = hashlib.sha256(raw).hexdigest()
        if digest in pixel_sources:
            raise PermissionError("duplicate pixels cannot count as independent origins")
        pixel_sources.add(digest)
        images.append(raw)
    # Initialise only after the entire selected population has authenticated.
    observer = HandAnomalyObserver(root)
    observations = []
    import io
    for row, raw in zip(record["controls"], images):
        with Image.open(io.BytesIO(raw)) as image:
            observation = observer.observe(np.asarray(image.convert("RGB")))
        expected = "ANOMALOUS" if row["selection"]["upstream_annotation"][1] == 0 else "NORMAL"
        observations.append({**row,"observation":observation,"expected_class":expected,
                             "matches":observation["benchmark_classification"] == expected})
    if any(path.read_bytes() != raw for path,raw in saved.items()):
        raise PermissionError("origin reference changed during evaluation")
    def scores(partition, label):
        return [row["observation"]["anomaly_score"] for row in observations
                if row["selection"]["partition"] == partition and row["selection"]["upstream_annotation"][1] == label]
    normal_bound = max(scores("development",1))
    separation = min(scores("development",0)) > normal_bound
    held_out = max(scores("holdout",1)) <= normal_bound and min(scores("holdout",0)) > normal_bound
    return {"version":"phase6-hand-origin-disjoint-observation-v1", "controls":observations,
            "sample_count":16,"independent_origin_count":16,"benchmark_threshold_unchanged":BENCHMARK_HAND_ANOMALY_THRESHOLD,
            "benchmark_correct":sum(row["matches"] for row in observations),
            "development_normal_upper_bound":normal_bound, "development_separates":separation,
            "holdout_separates_without_refitting":held_out,
            "status":"SEPARATES_SELECTED_ORIGINS_ONLY" if separation and held_out else "FAILED_ORIGIN_HOLDOUT_SEPARATION",
            "previous_counterexamples_overridden":False, "project_domain_calibrated":False,
            "quality_authorized":False,"render_authorized":False,"publication_authorized":False}


def evaluate_full_roi_controls(root: Path, *, acquisition_path: Path, expected_acquisition_sha256: str,
                               baseline_path: Path, expected_baseline_sha256: str) -> dict:
    """Test the geometric blind-region correction on the already seen controls.

    Reuses the anchored centre-crop scores, never repeats that inference. Both
    previous partitions are now diagnostic data, NOT a fresh independent test
    of the successor. The published single-crop threshold is not recalibrated.
    """
    import io
    import math
    root = root.resolve()
    saved = {}
    def read(binding):
        path = (root/binding['path']).resolve()
        if root not in path.parents or not re.fullmatch(r'(sha256:)?[0-9a-f]{64}', str(binding['sha256'])):
            raise PermissionError('full ROI control needs confined exact binding')
        _binding(path, binding['sha256'], binding.get('size_bytes'))
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != binding['sha256'].removeprefix('sha256:'):
            raise PermissionError('full ROI input changed before capture')
        saved[path] = raw
        return raw
    encoded = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
    acquisition = json.loads(read({'path': str(acquisition_path), 'sha256': expected_acquisition_sha256}))
    baseline = json.loads(read({'path': str(baseline_path), 'sha256': expected_baseline_sha256}))
    if (acquisition.get('version') != 'phase6-hand-origin-disjoint-acquisition-v1'
            or acquisition.get('quality_authorized') is not False
            or baseline.get('version') != 'phase6-hand-origin-disjoint-observation-v1'
            or any(baseline.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized'))
            or baseline.get('benchmark_threshold_unchanged') != BENCHMARK_HAND_ANOMALY_THRESHOLD):
        raise PermissionError('full ROI baseline/acquisition contract differs')
    labels = [json.loads(line) for line in read(acquisition['labels']).splitlines() if line.strip()]
    previous = json.loads(read(acquisition['previous_acquisition']))
    if (previous.get('status') != 'LABELLED_SUBSET_ACQUIRED_NOT_CALIBRATED'
            or previous.get('quality_authorized') is not False or previous['labels'] != acquisition['labels']):
        raise PermissionError('full ROI previous acquisition differs')
    plan = origin_disjoint_control_plan(labels, [r['upstream_annotation'] for r in previous['controls']])
    if (encoded(acquisition['plan']) != encoded(plan) or len(acquisition['controls']) != 16
            or len(baseline['controls']) != 16):
        raise PermissionError('full ROI diagnostic population differs')
    rows, digests = [], set()
    for control, original, selected in zip(acquisition['controls'], baseline['controls'], plan['controls']):
        if (encoded(control['selection']) != encoded(selected)
                or set(original) != set(control) | {'observation','expected_class','matches'}
                or encoded({k: original[k] for k in control}) != encoded(control)):
            raise PermissionError('full ROI original control binding differs')
        old = original['observation']
        score = old['anomaly_score']
        expected = 'ANOMALOUS' if selected['upstream_annotation'][1] == 0 else 'NORMAL'
        classification = 'ANOMALOUS' if score > BENCHMARK_HAND_ANOMALY_THRESHOLD else 'NORMAL'
        if (type(score) not in (int,float) or not math.isfinite(score) or not 0 <= score <= 1
                or old.get('model_sha256') != 'sha256:'+HAND_MODEL[2]
                or old.get('benchmark_threshold') != BENCHMARK_HAND_ANOMALY_THRESHOLD
                or old.get('benchmark_classification') != classification
                or original['expected_class'] != expected or original['matches'] is not (expected == classification)):
            raise PermissionError('full ROI baseline score/model/label differs')
        raw = read(control['binding'])
        digest = hashlib.sha256(raw).hexdigest()
        if digest in digests:
            raise PermissionError('full ROI duplicate control pixels')
        digests.add(digest)
        with Image.open(io.BytesIO(raw)) as image:
            rgb = np.asarray(image.convert('RGB'))
        # Plan the COMPLETE population before loading a native model. One
        # oversized ROI cannot yield a partial diagnostic presented as complete.
        view_plan = full_roi_view_plan(rgb.shape[1], rgb.shape[0])
        rows.append((control, original, rgb, view_plan))
    code = Path(__file__).resolve().read_bytes()
    observer = HandAnomalyObserver(root)
    measured = []
    for control, original, rgb, view_plan in rows:
        observation = observer.observe_full_roi(rgb)
        if encoded(observation['plan']) != encoded(view_plan):
            raise PermissionError('full ROI execution omitted/reordered planned windows')
        expected_windows = view_plan['windows_xyxy']
        if [r['window_xyxy'] for r in observation['windows']] != expected_windows:
            raise PermissionError('full ROI observed window population differs')
        classification = 'ANOMALOUS' if observation['maximum_score'] > BENCHMARK_HAND_ANOMALY_THRESHOLD else 'NORMAL'
        measured.append({**control, 'baseline_observation': original['observation'], 'observation': observation,
                         'expected_class': original['expected_class'],
                         'diagnostic_max_classification': classification,
                         'diagnostic_matches': classification == original['expected_class'],
                         'baseline_matches': original['matches']})
    if any(path.read_bytes() != raw for path, raw in saved.items()) or Path(__file__).resolve().read_bytes() != code:
        raise PermissionError('full ROI control/implementation changed during execution')
    return {'version': 'phase6-hand-full-roi-diagnostic-population-v1',
            'status': 'COMPLETE_RESIZED_ROI_OBSERVED_NOT_DOMAIN_QUALIFIED', 'controls': measured,
            'baseline_binding': {'path': str(baseline_path), 'sha256': expected_baseline_sha256},
            'acquisition_binding': {'path': str(acquisition_path), 'sha256': expected_acquisition_sha256},
            'model_sha256': 'sha256:'+HAND_MODEL[2], 'implementation_sha256': 'sha256:'+hashlib.sha256(code).hexdigest(),
            'model_invocations': sum(r['observation']['model_invocations'] for r in measured),
            'baseline_inference_repeated': False, 'original_threshold_unchanged': BENCHMARK_HAND_ANOMALY_THRESHOLD,
            'diagnostic_correct': sum(r['diagnostic_matches'] for r in measured),
            'recovered_old_misses': sum(not r['baseline_matches'] and r['diagnostic_matches'] for r in measured),
            'new_misses': sum(r['baseline_matches'] and not r['diagnostic_matches'] for r in measured),
            'fresh_independent_holdout': False, 'previous_counterexamples_overridden': False,
            'complete_hand_coverage_proved': False, 'multiwindow_operating_point_qualified': False,
            'project_domain_calibrated': False, 'quality_authorized': False,
            'render_authorized': False, 'publication_authorized': False}
