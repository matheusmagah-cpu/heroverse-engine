from __future__ import annotations

import copy
import hashlib
import re
from datetime import datetime, timezone
from typing import Any


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _asset_rank(asset: dict[str, Any], beat: dict[str, Any], index: int) -> tuple[int, int, int, str]:
    preferred_asset_id = beat.get("preferred_asset_id")
    preferred = 0 if preferred_asset_id and asset.get("asset_id") == preferred_asset_id else 1
    wanted = str(beat.get("semantic_role", "")).lower()
    actual = str(asset.get("semantic_role", "")).lower()
    exact = 0 if wanted and wanted == actual else 1
    return (preferred, exact, index, str(asset["asset_id"]))


def _allocate_source_range(
    asset: dict[str, Any],
    duration_ms: int,
    allocations: dict[str, list[tuple[int, int]]],
) -> tuple[int, int]:
    asset_id = str(asset["asset_id"])
    duration_limit = int(float(asset["duration_seconds"]) * 1000)
    margin = 250
    occupied = sorted(allocations.setdefault(asset_id, []))
    safe_ranges = asset.get("safe_ranges") or [{"start_ms": margin, "end_ms": duration_limit - margin}]
    for safe in safe_ranges:
        safe_start = max(int(safe["start_ms"]), margin)
        safe_end = min(int(safe["end_ms"]), duration_limit - margin)
        cursor = safe_start
        for start, end in occupied:
            if end <= safe_start or start >= safe_end:
                continue
            if cursor + duration_ms <= start:
                break
            cursor = max(cursor, end + margin)
        if cursor + duration_ms <= safe_end:
            allocated = (cursor, cursor + duration_ms)
            occupied.append(allocated)
            allocations[asset_id] = sorted(occupied)
            return allocated
    raise ValueError(f"asset {asset_id} has no non-overlapping safe range for {duration_ms} ms")


def _validate_beats(beats: list[dict[str, Any]], *, clip_duration_ceiling: bool = True) -> None:
    if not beats:
        raise ValueError("at least one narrative beat is required")
    expected_start = 0
    ids: set[str] = set()
    for beat in beats:
        beat_id = str(beat["beat_id"])
        if beat_id in ids:
            raise ValueError(f"duplicate beat_id: {beat_id}")
        ids.add(beat_id)
        start_ms = int(beat["start_ms"])
        end_ms = int(beat["end_ms"])
        if start_ms != expected_start:
            raise ValueError(f"timeline gap or overlap before {beat_id}: expected {expected_start}, got {start_ms}")
        if end_ms <= start_ms:
            raise ValueError(f"invalid duration for {beat_id}")
        if clip_duration_ceiling and end_ms - start_ms > 10_000:
            raise ValueError(f"beat {beat_id} exceeds the FormatPack 10-second exception ceiling")
        expected_start = end_ms


def build_take_plan(
    *,
    channel_id: str,
    video_id: str,
    creative_decision: dict[str, Any],
    style_bible: dict[str, Any],
    format_pack: dict[str, Any],
    asset_manifest: dict[str, Any],
    narrative_beats: list[dict[str, Any]],
    hook_windows: list[dict[str, Any]],
    created_at: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Create a contiguous take-level plan and an updated allocation manifest.

    The planner does not infer asset rights. Only manifest entries already marked
    production-eligible can be allocated, and every used range is persisted.
    """

    if creative_decision.get("decision") != "SELECT":
        raise PermissionError("no FormatPack was selected")
    purpose = creative_decision.get("purpose")
    if purpose not in {"PROTOTYPE", "PRODUCTION"}:
        raise ValueError("take planning requires an explicit PROTOTYPE or PRODUCTION decision")
    if purpose == "PROTOTYPE" and creative_decision.get("quality_profile") != "DRAFT":
        raise ValueError("prototype take planning requires the DRAFT quality profile")
    if purpose == "PRODUCTION" and creative_decision.get("quality_profile") == "DRAFT":
        raise ValueError("production take planning cannot use the DRAFT quality profile")
    if purpose == "PRODUCTION" and (
        format_pack.get("capability_status") not in {"LIMITED", "PRODUCTION_READY"}
        or format_pack.get("production_allowed") is not True
    ):
        raise PermissionError("FormatPack is not production-capable in the requested scope")
    static_audio = format_pack["format_pack_id"] == "fp-narrated-reflection-static"
    # The static Pack's explicit timing exception preserves measured narration;
    # it has no mandatory scene cuts. Contiguity/positive durations still apply.
    _validate_beats(narrative_beats, clip_duration_ceiling=not static_audio)

    selected = creative_decision["selected_format_pack"]
    if selected["format_pack_id"] != format_pack["format_pack_id"] or selected["version"] != format_pack["version"]:
        raise ValueError("FormatPack artifact does not match the CreativeDirectionDecision")


    assets = [
        asset for asset in asset_manifest.get("assets", [])
        if asset.get("production_eligible") is True
        and asset.get("content_quality_gate", "PASS") != "BLOCKED"
        and asset.get("rights_status") in {"OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"}
    ]
    if not assets:
        raise ValueError("no rights-eligible assets")
    if static_audio:
        assets = [asset for asset in assets if asset.get("rights_status") == "OWNED"
                  and asset.get("media_type") == "GENERATED_IMAGE"
                  and str(asset.get("uri", "")).lower().endswith((".png", ".jpg", ".jpeg"))]
        if len(assets) != 1:
            raise ValueError("static audio requires exactly one eligible owned composition")
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", str(assets[0].get("content_hash", ""))):
            raise ValueError("static composition requires an exact content hash")

    updated_manifest = copy.deepcopy(asset_manifest)
    allocations: dict[str, list[tuple[int, int]]] = {
        str(asset["asset_id"]): [
            (int(item["start_ms"]), int(item["end_ms"]))
            for item in asset.get("used_ranges", [])
            if isinstance(item, dict) and "start_ms" in item and "end_ms" in item
        ]
        for asset in assets
    }
    allocation_take_ids: dict[tuple[str, int, int], str] = {}
    takes: list[dict[str, Any]] = []
    previous_asset_id: str | None = None
    for index, beat in enumerate(narrative_beats):
        ordered = sorted(assets, key=lambda asset: _asset_rank(asset, beat, index))
        if not beat.get("allow_repeat_asset"):
            ordered = [asset for asset in ordered if asset["asset_id"] != previous_asset_id] + [asset for asset in ordered if asset["asset_id"] == previous_asset_id]
        duration_ms = int(beat["end_ms"]) - int(beat["start_ms"])
        chosen = None
        source_range = None
        if static_audio:
            chosen = assets[0]
            source_range = (0, 0)  # No source clock exists for a designed still.
        for asset in ordered:
            if static_audio:
                break
            try:
                source_range = _allocate_source_range(asset, duration_ms, allocations)
                chosen = asset
                break
            except ValueError:
                continue
        if chosen is None or source_range is None:
            raise ValueError(f"no asset capacity for beat {beat['beat_id']}")
        previous_asset_id = str(chosen["asset_id"])
        take_id = f"take-{index + 1:03d}"
        source_start, source_end = source_range
        if not static_audio:
            allocation_take_ids[(str(chosen["asset_id"]), source_start, source_end)] = take_id
        origin = f"{chosen['uri']}#t={source_start / 1000:.3f},{source_end / 1000:.3f}"
        if static_audio:
            origin = f"{chosen['uri']}#still={chosen['content_hash']}"
            if beat.get("on_screen_text") or beat.get("transition_in") or beat.get("transition_out"):
                raise ValueError("a fixed composition cannot introduce per-beat overlays or transitions")
        takes.append(
            {
                "take_id": take_id,
                "start_ms": int(beat["start_ms"]),
                "end_ms": int(beat["end_ms"]),
                "narrative_function": str(beat["narrative_function"]),
                "information": str(beat["information"]),
                "intended_emotion": str(beat["intended_emotion"]),
                "media_type": str(chosen.get("media_type", "CLIP")),
                "visual_format": format_pack["substyle"],
                "format_pack_id": format_pack["format_pack_id"],
                "composition": str(beat.get("composition", "single focal subject with protected negative space")),
                "camera": str(beat.get("camera", "wide contextual / 24–35 mm equivalent")),
                "movement": str(beat.get("movement", "source-native movement; no synthetic camera")),
                "lighting": str(beat.get("lighting", "cool tension progressing toward controlled warmth")),
                "character": beat.get("character"),
                "environment": beat.get("environment", "env-tension" if int(beat["end_ms"]) <= 30_000 else "env-clarity"),
                "action": str(beat["action"]),
                "on_screen_text": beat.get("on_screen_text"),
                "narration": beat.get("narration"),
                "music": beat.get("music", "original procedural ambience under narration"),
                "sound_effect": beat.get("sound_effect"),
                "transition_in": beat.get("transition_in", "hard cut" if index else None),
                "transition_out": beat.get("transition_out", "hard cut" if index < len(narrative_beats) - 1 else "fade final"),
                "asset_origin": origin,
                "rights": {"status": chosen["rights_status"], "evidence_ref": chosen["rights_evidence_uri"]},
                "tool_adapter_id": str(chosen.get("tool_adapter_id", "adapter-ffmpeg-local")),
                "tool_version": str(chosen.get("tool_version", "runtime-detected")),
                "cost": 0.0,
                "take_version": "1.0.0",
                "quality_criteria": [
                    "semantic job visible without relying on decorative filler",
                    "no critical artifact, deformation, flicker or unintended style change",
                    "locked palette, safe area and continuity rules pass",
                ],
                "semantic_alignment": f"asset role {chosen['semantic_role']} supports {beat['information']}",
                "retention_job": str(beat["retention_job"]),
                "continuity_refs": ["CONT-001", "CONT-002", "CONT-003", "CONT-005"],
            }
        )
        if static_audio:
            takes[-1].update(
                composition="One bound owned static composition throughout the original audio",
                camera="Not applicable: designed still", movement="Intentional fixed visual hold",
                lighting="Locked composition, no photographed-lighting claim", environment=None,
                transition_in=None, transition_out=None, music=beat.get("music"),
                quality_criteria=["Original audio carries the declared narrative job",
                                  "Exact bound still geometry, text and palette pass",
                                  "Audio intelligibility, timing, rights and output integrity pass"],
            )

    asset_map = {asset["asset_id"]: asset for asset in updated_manifest["assets"]}
    for asset_id, ranges in allocations.items():
        if asset_id in asset_map and not static_audio:
            asset_map[asset_id]["used_ranges"] = [
                {"start_ms": start, "end_ms": end, "take_id": allocation_take_ids.get((asset_id, start, end), "prior-allocation")}
                for start, end in ranges
            ]

    window_coverage = []
    for window in hook_windows:
        start_ms = int(window["start_ms"])
        end_ms = int(window["end_ms"])
        matching = [take["take_id"] for take in takes if take["start_ms"] < end_ms and take["end_ms"] > start_ms]
        if not matching:
            raise ValueError(f"hook window {window['window']} has no take coverage")
        window_coverage.append(
            {
                "window": window["window"],
                "take_ids": matching,
                "promise_function": window["promise_function"],
                "gate_status": "PASS",
                "evidence_refs": list(window["evidence_refs"]),
            }
        )

    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    plan_id = _stable_id("take-plan", video_id, creative_decision["decision_id"], style_bible["style_bible_id"])
    plan = {
            "schema_version": "1.0.0",
            "take_plan_id": plan_id,
            "channel_id": channel_id,
            "video_id": video_id,
            "creative_direction_decision_id": creative_decision["decision_id"],
            "format_pack_id": format_pack["format_pack_id"],
            "format_pack_version": format_pack["version"],
            "style_bible_id": style_bible["style_bible_id"],
            "quality_profile": creative_decision["quality_profile"],
            "takes": takes,
            "hook_window_coverage": window_coverage,
            "total_cost": {"currency": "USD", "external": 0.0, "local_status": "UNAVAILABLE"},
            "created_at": timestamp,
        }
    if static_audio:
        from .phase6_render_contract import PALETTE_QP1_SEGMENT_RENDERER
        plan["render_profile"] = PALETTE_QP1_SEGMENT_RENDERER
    return plan, updated_manifest
