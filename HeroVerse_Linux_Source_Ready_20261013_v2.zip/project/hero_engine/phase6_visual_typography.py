"""Independent pixel geometry of existing OCR evidence; never rerun OCR.

This instrument observes an uppercase word's enclosing detector rectangle and
actual light-ink occupancy. It does NOT equate an OCR box with a font's em size.
Its reference is the painted glyph extent of the Style Bible's allowed fonts
at the declared minimum. A counterexample is deliberately a limited geometry
observation, not a full style/anatomy verdict or publication authorization.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import subprocess
import tempfile
import time
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import ImageFont

from .phase6_visual_metrics import VisualMeasurementUnavailable

VERSION = "phase6-ocr-pixel-cap-height-v2"


def measure_successor_glyph_support(rgb: np.ndarray, layout: dict[str, Any]) -> dict[str, Any]:
    return _successor_glyph_evaluator(layout)(rgb)


def _successor_glyph_evaluator(layout: dict[str, Any]):
    """Necessary glyph-support conformance, not pixel-perfect lossy-video QA.

    Reference glyphs come from the authenticated canonical copy/font/positions,
    NOT from the candidate pixels or its OCR. Only opaque text interiors and
    known dark/transparent pixels are classified. Antialiased pixels remain
    explicitly unclassified. The separating value is the midpoint between the
    darkest declared text channel and brightest decorative-background channel;
    it is a palette-derived discriminator, not a perceptual quality tolerance.
    This proves neither exact encoded font size nor all-style/video quality.
    """
    from PIL import Image, ImageDraw
    from .procedural_infographics_phase5 import verify_typography_successor
    from .phase6_visual_recipe import LINE_SPACING, TEXT_BORDER
    layout = verify_typography_successor(layout)
    palette = layout['style_bible']['palette']['role_map']
    channels = lambda colour: tuple(int(colour[i:i+2], 16) for i in (1, 3, 5))
    text_floor = min(channels(palette['text']))
    background_ceiling = max(*channels(palette['dominant']), *channels(palette['support']))
    split = (text_floor + background_ceiling) / 2
    references = []
    reference_foreground = Image.new('RGBA',(1920,1080),(0,0,0,0))
    for row in layout['texts']:
        b = row['bounds']; left, top, right, bottom = (int(b[k]) for k in ('left','top','right','bottom'))
        # Independent reference raster for this exact canonical text cell; the
        # source producer's foreground PNG is not used as the golden answer.
        font = ImageFont.truetype(layout['font']['path'], size=row['font_size'])
        reference = Image.new('RGBA', (right-left, bottom-top), (0,0,0,0))
        draw = ImageDraw.Draw(reference)
        box = draw.multiline_textbbox((0,0), row['render_text'], font=font,
                                       spacing=LINE_SPACING, stroke_width=TEXT_BORDER)
        draw.multiline_text((-box[0],-box[1]), row['render_text'], font=font,
                            spacing=LINE_SPACING, fill=palette['text'],
                            stroke_width=TEXT_BORDER, stroke_fill=palette['dominant'])
        reference_foreground.paste(reference,(left,top))
        rgba = np.asarray(reference)
        core = (rgba[:,:,3] == 255) & np.all(rgba[:,:,:3] == channels(palette['text']), axis=2)
        dark = (rgba[:,:,3] == 0) | ((rgba[:,:,3] == 255) & (rgba[:,:,:3].max(axis=2) <= background_ceiling))
        if not core.any() or not dark.any():
            raise VisualMeasurementUnavailable('glyph reference has no opaque ink/background support')
        reference_row = {'role':row['role'], 'canonical_text':row['source_text'],
            'bounds':[left,top,right,bottom], 'declared_em_px':row['font_size'],
            'reference_rgba_sha256':'sha256:'+hashlib.sha256(rgba.tobytes()).hexdigest(),
            'opaque_ink_pixels':int(core.sum()), 'known_dark_pixels':int(dark.sum()),
            'antialias_pixels_unclassified':int(np.count_nonzero(~core & ~dark))}
        references.append((reference_row, core, dark))
    def evaluate(rgb):
        rgb = np.asarray(rgb)
        if rgb.shape != (1080,1920,3) or rgb.dtype != np.uint8:
            raise VisualMeasurementUnavailable('successor requires native RGB uint8 pixels')
        rows = []
        for reference_row, core, dark in references:
            left,top,right,bottom = reference_row['bounds']
            crop = rgb[top:bottom,left:right]
            observed_light = crop.min(axis=2) > split
            missing = int(np.count_nonzero(core & ~observed_light))
            unexpected = int(np.count_nonzero(dark & observed_light))
            rows.append({**reference_row,
                'crop_rgb_sha256':'sha256:'+hashlib.sha256(crop.tobytes()).hexdigest(),
                'missing_ink_pixels':missing,'unexpected_ink_pixels':unexpected,
                'status':'PASS' if missing == unexpected == 0 else 'FAIL'})
        return {'version':'phase6-successor-glyph-support-v1',
            'status':'PASS' if rows and all(r['status']=='PASS' for r in rows) else 'FAIL',
            'layout_id':layout['layout_id'],'palette_separator':split,
            'separator_origin':{'text_channel_floor':text_floor,'background_channel_ceiling':background_ceiling},
            'maximum_disagreements':0,'texts':rows,
            'font_em_proved_in_encoded_video':False,'full_style_covered':False,
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    evaluate.reference_foreground = reference_foreground
    return evaluate


def _appearance_evaluator(layout, *, full_canvas=False):
    """Use the existing Bible CIE76 limit, including glyph edges, without fitting."""
    from .phase6_visual_metrics import colour_measurements
    bible=layout['style_bible'];palette=bible['palette']
    limit=palette.get('tolerance_delta_e')
    if (type(limit) not in (float,int) or not math.isfinite(limit) or limit<=0
            or limit!=bible.get('divergence_policy',{}).get('thresholds',{}).get('palette_delta_e')
            or set(palette.get('locked_hex',[]))!=set(palette['role_map'].values())):
        raise PermissionError('appearance requires the exact Bible palette/tolerance contract')
    def evaluate(reference,candidate):
        if (np.asarray(reference).shape!=(1080,1920,3) or np.asarray(candidate).shape!=(1080,1920,3)
                or reference.dtype!=np.uint8 or candidate.dtype!=np.uint8):
            raise VisualMeasurementUnavailable('appearance requires paired native RGB frames')
        rows=[]
        for text in layout['texts']:
            b=text['bounds'];l,t,r,d=(int(b[k]) for k in ('left','top','right','bottom'))
            expected,actual=reference[t:d,l:r],candidate[t:d,l:r]
            measured=colour_measurements(expected,actual)
            rows.append({'role':text['role'],'bounds':[l,t,r,d],**measured,
                'tolerance_delta_e':limit,'status':'PASS' if measured['maximum_delta_e']<=limit else 'FAIL',
                'reference_rgb_sha256':'sha256:'+hashlib.sha256(expected.tobytes()).hexdigest(),
                'observed_rgb_sha256':'sha256:'+hashlib.sha256(actual.tobytes()).hexdigest()})
        result={'version':'phase6-source-typography-appearance-v1',
            'status':'PASS' if rows and all(r['status']=='PASS' for r in rows) else 'FAIL',
            'texts':rows,'tolerance_origin':'Style Bible palette.tolerance_delta_e and matching divergence policy',
            'covers_all_text_cell_pixels':True,'border_erosion_or_outliers_removed':False,
            'reference_fitted_to_candidate':False,'perceptual_readability_proved':False}
        if full_canvas:
            # Equality proves zero colour distance exactly; nonidentical input
            # still uses the same CIE76 tolerance, never pixel-perfect rejection.
            canvas=({'method':'CIE76-reference-conditioned-colour','mean_delta_e':0.0,
                     'maximum_delta_e':0.0,'compared_pixels':1920*1080}
                    if np.array_equal(reference,candidate) else colour_measurements(reference,candidate))
            result['canvas']={**canvas,'tolerance_delta_e':limit,
                'reference_rgb_sha256':'sha256:'+hashlib.sha256(reference.tobytes()).hexdigest(),
                'observed_rgb_sha256':'sha256:'+hashlib.sha256(candidate.tobytes()).hexdigest(),
                'status':'PASS' if canvas['maximum_delta_e']<=limit else 'FAIL'}
            if result['canvas']['status']!='PASS':result['status']='FAIL'
        return result
    return evaluate


def _read_reference_frame(capture,index):
    from fractions import Fraction
    from .phase6_visual_metrics import indexed_frame_clock
    if capture.get(cv2.CAP_PROP_POS_FRAMES)!=index:
        raise VisualMeasurementUnavailable('native reference frame identity differs')
    ok,bgr=capture.read()
    if not ok:raise VisualMeasurementUnavailable('native reference ended early')
    stamp=capture.get(cv2.CAP_PROP_POS_MSEC)
    expected,rounding=indexed_frame_clock(index,Fraction(30))
    if (capture.get(cv2.CAP_PROP_POS_FRAMES)!=index+1 or not math.isfinite(stamp)
            or abs(stamp-expected)>rounding):
        raise VisualMeasurementUnavailable('native reference clock differs')
    return cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)


@contextmanager
def _native_typography_reference(layout,evaluator,frame_count,directory):
    """Transient lossless *reference*, independently composed, never a channel asset.

    No candidate pixels enter the reference. NUT retains the exact 30fps clock;
    FFV1 preserves the native post-composition YUV samples. Both reference and
    candidate are decoded by the same existing OpenCV/FFmpeg colour path.
    Record commands, input/output hashes and exit; discard only own temporary
    carrier after use. Sources and evidence remain available for reproduction.
    """
    from PIL import Image, ImageDraw
    from .procedural_infographics_phase5 import FFMPEG, _sha256
    from .phase6_asset_residency import _write_immutable
    directory.mkdir(parents=True,exist_ok=False)
    binary=Path(FFMPEG).resolve();binary_hash=_sha256(binary)
    palette=layout['style_bible']['palette']['role_map']
    with tempfile.TemporaryDirectory(prefix='reference-',dir=directory) as temporary:
        folder=Path(temporary);back=folder/'background.png';front=folder/'foreground.png';video=folder/'reference.nut'
        background=Image.new('RGB',(1920,1080),palette['dominant']);draw=ImageDraw.Draw(background)
        for x in range(0,1920,64):draw.line((x,0,x,1080),fill=palette['support'],width=1)
        for y in range(0,1080,64):draw.line((0,y,1920,y),fill=palette['support'],width=1)
        background.save(back);evaluator.reference_foreground.save(front)
        inputs=[{'name':p.name,'sha256':_sha256(p)} for p in (back,front)]
        graph=("[0:v]scale=2048:1152:force_original_aspect_ratio=increase,"
            "crop=1920:1080:x='64+60*sin(t*1.70)':y='36+32*cos(t*1.30)'[background];"
            "[background][1:v]overlay=x=0:y=0:format=auto,"
            "fade=t=in:st=0:d=0.35,fade=t=out:st=17.45:d=0.55,format=yuv420p[out]")
        command=[str(binary),'-n','-nostdin','-hide_banner','-loglevel','error',
            '-loop','1','-framerate','30','-i',str(back),'-loop','1','-framerate','30','-i',str(front),
            '-filter_complex_threads','1','-filter_complex',graph,'-map','[out]',
            '-frames:v',str(frame_count),'-an','-c:v','ffv1','-level','3','-threads','1',
            '-fps_mode','passthrough','-f','nut',str(video)]
        _write_immutable(directory/'command.json',{'argv':command,'binary':{'path':str(binary),'sha256':binary_hash},
                         'layout_id':layout['layout_id'],'inputs':inputs,'candidate_used_as_reference':False})
        start=time.monotonic()
        try:
            with (directory/'stdout.log').open('xb') as out,(directory/'stderr.log').open('xb') as err:
                process=subprocess.run(command,stdout=out,stderr=err,timeout=180,
                        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            outcome={'exit_code':process.returncode,'elapsed_seconds':time.monotonic()-start,'timed_out':False}
        except subprocess.TimeoutExpired:
            outcome={'exit_code':None,'elapsed_seconds':time.monotonic()-start,'timed_out':True}
        _write_immutable(directory/'process-result.json',outcome)
        if outcome['exit_code']!=0:raise VisualMeasurementUnavailable('native reference process failed')
        reference_hash=_sha256(video)
        capture=cv2.VideoCapture(str(video),cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
        try:
            if not capture.isOpened():raise VisualMeasurementUnavailable('native reference decoder unavailable')
            yield lambda index:_read_reference_frame(capture,index)
            if capture.read()[0]:raise VisualMeasurementUnavailable('native reference population exceeds contract')
        finally:
            capture.release()
        if (_sha256(binary)!=binary_hash or _sha256(video)!=reference_hash
                or [{'name':p.name,'sha256':_sha256(p)} for p in (back,front)]!=inputs):
            raise PermissionError('native reference inputs changed during measurement')
        _write_immutable(directory/'reference.json',{'layout_id':layout['layout_id'],'frames':frame_count,
            'reference_carrier_sha256':reference_hash,'reference_carrier_retained':False,
            'lossless_codec':'FFV1','candidate_used_as_reference':False,
            'observed_eof':True,'command_sha256':_sha256(directory/'command.json'),
            'process_result_sha256':_sha256(directory/'process-result.json')})


def audit_typography_sources(root: Path, manifest_path: Path, *, expected_sha256: str,
                             output_directory: Path, appearance: bool = False,
                             content: bool = False) -> dict[str, Any]:
    """Bounded public source audit used by the existing catalogue registrar.

    Decode every frame once using the existing indexed decoder, with no PNG
    population/OCR/model inference. Conformance covers every steady (non-fade)
    frame of the producer's existing 30fps/18s-or-shorter profile. Fade pixels
    and anti-alias detail are NOT silently promoted to full quality approval.
    """
    from fractions import Fraction
    from .procedural_infographics_phase5 import read_typography_source_manifest, _sha256
    from .phase6_visual_metrics import extract_indexed_frames
    from .phase6_asset_residency import _write_immutable
    root = root.resolve(); destination = output_directory.resolve()
    if type(appearance) is not bool:raise ValueError('appearance selection must be boolean')
    if type(content) is not bool or content and not appearance:
        raise PermissionError('content conformance requires full appearance observation')
    if root not in destination.parents or destination.exists():
        raise PermissionError('typography audit requires a new confined directory')
    source = read_typography_source_manifest(root,manifest_path,expected_sha256=expected_sha256)
    from . import phase6_visual_metrics, procedural_infographics_phase5, phase6_visual_recipe
    implementations = [Path(p).resolve() for p in (__file__,phase6_visual_metrics.__file__,
                         procedural_infographics_phase5.__file__,phase6_visual_recipe.__file__)]
    code_hashes = {p:_sha256(p) for p in implementations}
    results = []
    for asset in source['manifest']['assets']:
        layout = source['layouts'][asset['layout_id']]
        duration = Fraction(str(asset['duration_seconds']))
        count = duration * 30
        if count.denominator != 1 or not 11 < count <= 540:
            raise VisualMeasurementUnavailable('source duration outside bounded 30fps typography profile')
        stop = min(int(count), 524)  # t < 17.45; first fully unfaded frame n=11.
        evaluate = _successor_glyph_evaluator(layout)  # invocation-local; no caller PASS/cache
        evaluate_appearance = _appearance_evaluator(layout,full_canvas=content) if appearance else None
        def observe(clock, pixels):
            if 11 <= clock['frame_index'] < stop:
                result=evaluate(pixels)
            else:result={'status':'EXCLUDED_DECLARED_FADE_NOT_QUALIFIED'}
            if appearance:
                reference=read_reference(clock['frame_index'])
                result['appearance']=evaluate_appearance(reference,pixels)
            return result
        context=(_native_typography_reference(layout,evaluate,int(count),destination/(asset['asset_id']+'-reference'))
                 if appearance else nullcontext(None))
        with context as read_reference:
            frames = extract_indexed_frames(Path(asset['video_path']),list(range(int(count))),
                destination/asset['asset_id'],fps=Fraction(30),timeout_seconds=180,
                frame_observer=observe,retain_pixels=False,require_eof=True)
        if set(frames) != set(range(int(count))):
            raise VisualMeasurementUnavailable('typography decoder population incomplete')
        measured = [frames[i]['observation'] for i in range(11,stop)]
        if not measured or any(r.get('version')!='phase6-successor-glyph-support-v1' for r in measured):
            raise VisualMeasurementUnavailable('typography steady-frame observations incomplete')
        result={'asset_id':asset['asset_id'],'take_id':asset['take_id'],
            'video':{'path':asset['video_path'],'sha256':asset['video_hash']},
            'layout_id':layout['layout_id'],'decoded_frame_count':len(frames),
            'checked_frame_start':11,'checked_frame_end_exclusive':stop,
            'status':'PASS' if all(r['status']=='PASS' for r in measured) and
                (not appearance or all(frames[i]['observation']['appearance']['status']=='PASS' for i in frames)) else 'FAIL',
            'frames':[frames[i] for i in range(int(count))]}
        if appearance:
            reference_path=destination/(asset['asset_id']+'-reference')/'reference.json'
            raw=reference_path.read_bytes()
            result['native_reference']={'path':str(reference_path),
                'sha256':'sha256:'+hashlib.sha256(raw).hexdigest(),'record':json.loads(raw)}
        results.append(result)
    # A decoder result never licenses a source swap during the observation.
    if (read_typography_source_manifest(root,manifest_path,expected_sha256=expected_sha256) != source
            or any(_sha256(p)!=digest for p,digest in code_hashes.items())):
        raise PermissionError('typography source or evaluator changed during audit')
    value = {'version':'phase6-produced-source-typography-audit-v1',
        'status':'PASS_SOURCE_GLYPH_SUPPORT' if results and all(r['status']=='PASS' for r in results) else 'FAIL_SOURCE_GLYPH_SUPPORT',
        'source_manifest':source['binding'],
        'implementations':[{'path':str(p),'sha256':digest} for p,digest in code_hashes.items()],
        'results':results,'criterion':'canonical opaque glyph interiors/background support, native positions and continuity in all steady frames',
        'unqualified':['fade intervals','antialiased boundary detail','encoded exact em size','all-style and final-video quality'],
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    if appearance:
        value.update(version='phase6-produced-source-typography-audit-v2',
            status='PASS_SOURCE_TYPOGRAPHY_TRANSFER' if all(r['status']=='PASS' for r in results) else 'FAIL_SOURCE_TYPOGRAPHY_TRANSFER',
            criterion='opaque glyph support plus all text-cell pixels, borders and declared fades against independent native composition within Style Bible CIE76 limit',
            unqualified=['encoded exact em size','perceptual reading comprehension','all-style and final-video quality'])
    if content:
        value.update(version='phase6-produced-source-content-audit-v3',
            status='PASS_SOURCE_CONTENT_CONFORMANCE' if results and all(r['status']=='PASS' for r in results) else 'FAIL_SOURCE_CONTENT_CONFORMANCE',
            criterion='Full canonical abstract typography composition in every native frame; not final-video quality',
            unqualified=['final-video editorial/timing/variety/quality and publication'])
    _write_immutable(destination/'audit.json',value)
    return value


def _content_v3_historical_implementations(root, historical, current):
    """Authenticate the exact additive audio evolution, never replay old code.

    Only the reviewed original producers and unchanged measurement definitions
    qualify. Archived executable bytes are evidence, not executable imports.
    """
    import ast
    if (not isinstance(current, list) or len(current) != 4
            or any(set(item) != {'path', 'sha256'}
                   or 'sha256:' + hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256']
                   for item in current)):
        raise PermissionError('current content evaluator bytes differ')
    pins = (
        'sha256:56c75c5bf3ce4a5c65bd48d7f318e13d66225e393ba05a1c5eb36277062c20e0',
        'sha256:2a7cf2cc5a2aa10c74e43079e70c1fdd0f8639ff3c50225b0b2c151fe8888a91',
        'sha256:c584dd98e4ef763028c75f651cb86f1da1548457ccf7c71d9c5bf99dbdb5883c',
        'sha256:924fb073fb1c8943429dd42a2da0e77b25ed903c41dcc6a76ed521727ee1d28f',
    )
    if (not isinstance(historical, list) or len(historical) != 4
            or historical != [{'path': item['path'], 'sha256': pin} for item, pin in zip(current, pins)]
            or current[1]['sha256'] != pins[1] or current[3]['sha256'] != pins[3]
            or current[2]['sha256'] != 'sha256:9ad619a09268bc06744b6438667afb6394264713b793b085ae273aac704e163d'):
        raise PermissionError('content evaluator identity differs')
    directory = root / 'output/operations/phase6/typography-source-provenance/v3-20260930'
    files = []
    for index in (0, 2):
        live = Path(current[index]['path'])
        archive = directory / live.name
        if archive.is_symlink() or archive.resolve().parent != directory.resolve():
            raise PermissionError('historical content source escaped provenance archive')
        raw = archive.read_bytes()
        if 'sha256:' + hashlib.sha256(raw).hexdigest() != pins[index]:
            raise PermissionError('historical content source bytes differ')
        old_tree = ast.parse(raw.decode('utf-8-sig'))
        new_tree = ast.parse(live.read_text(encoding='utf-8-sig'))
        if index == 0:
            # The only changed historical definition is this receipt reader.
            excluded = {'read_typography_content_audit', '_content_v3_historical_implementations'}
            bodies = [[n for n in tree.body if getattr(n, 'name', None) not in excluded]
                      for tree in (old_tree, new_tree)]
            if [ast.dump(n, include_attributes=False) for n in bodies[0]] != [ast.dump(n, include_attributes=False) for n in bodies[1]]:
                raise PermissionError('historical content measurement implementation changed')
        else:
            # Exact reviewed current bytes above; additionally prove that none
            # of the thirteen original definitions was replaced or shadowed.
            for old in old_tree.body:
                if isinstance(old, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    matches = [n for n in new_tree.body if getattr(n, 'name', None) == old.name]
                    if len(matches) != 1 or ast.dump(old) != ast.dump(matches[0]):
                        raise PermissionError('historical source producer changed')
        files.append({'path': str(archive.resolve()), 'sha256': pins[index]})
    return files


def read_typography_content_audit(root: Path, path: Path, *, expected_sha256: str) -> dict[str, Any]:
    """Reopen externally pinned observations without another decode or render.

    Scope is the exact project-authored abstract source, not the ten final-video
    attributes. An old glyph-only/appearance proof cannot grant source admission.
    """
    from fractions import Fraction
    from .procedural_infographics_phase5 import read_typography_source_manifest, _sha256
    from . import phase6_visual_metrics, procedural_infographics_phase5, phase6_visual_recipe
    root=root.resolve();path=path.resolve()
    if root not in path.parents:raise PermissionError('content proof outside project root')
    raw=path.read_bytes()
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=expected_sha256:
        raise PermissionError('content proof anchor differs')
    proof=json.loads(raw)
    if (proof.get('version')!='phase6-produced-source-content-audit-v3'
            or proof.get('status')!='PASS_SOURCE_CONTENT_CONFORMANCE'
            or any(proof.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('content proof is not a complete source-only observation')
    implementations=[Path(p).resolve() for p in (__file__,phase6_visual_metrics.__file__,
                         procedural_infographics_phase5.__file__,phase6_visual_recipe.__file__)]
    expected=[{'path':str(p),'sha256':_sha256(p)} for p in implementations]
    provenance = []
    if proof.get('implementations') != expected:
        provenance = _content_v3_historical_implementations(root, proof.get('implementations'), expected)
    binding=proof['source_manifest']
    source=read_typography_source_manifest(root,Path(binding['path']),expected_sha256=binding['sha256'])
    if source['binding']!=binding:raise PermissionError('content source binding differs')
    assets=source['manifest']['assets'];results=proof.get('results',[])
    if [r.get('asset_id') for r in results]!=[a['asset_id'] for a in assets]:
        raise PermissionError('content proof population differs')
    ranges={}
    observed_files={path:expected_sha256, **{Path(item['path']): item['sha256'] for item in provenance}}
    for asset,result in zip(assets,results):
        layout=source['layouts'][asset['layout_id']]
        limit=layout['style_bible']['palette']['tolerance_delta_e']
        _appearance_evaluator(layout)  # Existing Bible validation, no decoder.
        count=Fraction(str(asset['duration_seconds']))*30
        if count.denominator!=1 or not 11<count<=540:raise PermissionError('content duration differs')
        count=int(count);stop=min(count,524)
        if (result.get('status')!='PASS' or result.get('layout_id')!=layout['layout_id']
                or result.get('take_id')!=asset['take_id'] or result.get('decoded_frame_count')!=count
                or result.get('video')!={'path':asset['video_path'],'sha256':asset['video_hash']}
                or result.get('checked_frame_start')!=11 or result.get('checked_frame_end_exclusive')!=stop):
            raise PermissionError('content observation identity differs')
        frames=result.get('frames',[])
        if [f.get('frame_index') for f in frames]!=list(range(count)):
            raise PermissionError('content frame population incomplete')
        for frame in frames:
            observation=frame.get('observation',{});appearance=observation.get('appearance',{})
            canvas=appearance.get('canvas',{})
            measurements=[*appearance.get('texts',[]),canvas]
            if (appearance.get('status')!='PASS' or appearance.get('covers_all_text_cell_pixels') is not True
                    or appearance.get('border_erosion_or_outliers_removed') is not False
                    or appearance.get('reference_fitted_to_candidate') is not False
                    or canvas.get('compared_pixels')!=1920*1080
                    or len(measurements)!=len(layout['texts'])+1):
                raise PermissionError('content canvas/text coverage incomplete')
            for measured in measurements:
                value=measured.get('maximum_delta_e')
                if (type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=limit
                        or measured.get('tolerance_delta_e')!=limit or measured.get('status')!='PASS'):
                    raise PermissionError('content colour criterion failed')
            if 11<=frame['frame_index']<stop:
                if (observation.get('status')!='PASS' or len(observation.get('texts',[]))!=len(layout['texts'])
                        or any(r.get('missing_ink_pixels')!=0 or r.get('unexpected_ink_pixels')!=0 for r in observation['texts'])):
                    raise PermissionError('content glyph criterion failed')
        ref=result['native_reference'];refpath=Path(ref['path']).resolve()
        if path.parent not in refpath.parents:raise PermissionError('native reference escaped audit')
        refraw=refpath.read_bytes()
        if ('sha256:'+hashlib.sha256(refraw).hexdigest()!=ref['sha256'] or json.loads(refraw)!=ref['record']):
            raise PermissionError('native reference proof diverged')
        record=ref['record'];observed_files[refpath]=ref['sha256']
        if record.get('frames')!=count or record.get('observed_eof') is not True or record.get('candidate_used_as_reference') is not False:
            raise PermissionError('native reference coverage differs')
        for filename,key in (('command.json','command_sha256'),('process-result.json','process_result_sha256')):
            item=refpath.parent/filename;digest=record[key]
            if _sha256(item)!=digest:raise PermissionError('native reference process binding differs')
            observed_files[item]=digest
        process=json.loads((refpath.parent/'process-result.json').read_bytes())
        if process.get('exit_code')!=0 or process.get('timed_out') is not False:
            raise PermissionError('native reference process failed')
        # Half-open whole steady-frame interval, further clipped to the declared
        # fade-out onset. No fade or unobserved pixel is granted as a safe range.
        start_ms=math.ceil(Fraction(11_000,30))
        end_ms=min(math.floor(Fraction(stop*1000,30)),17450)
        ranges[asset['asset_id']]=[{'start_ms':start_ms,'end_ms':end_ms}]
    if (any(_sha256(p)!=digest for p,digest in observed_files.items())
            or read_typography_source_manifest(root,Path(binding['path']),expected_sha256=binding['sha256'])!=source
            or expected!=[{'path':str(p),'sha256':_sha256(p)} for p in implementations]):
        raise PermissionError('content evidence changed during verification')
    return {'source':source,'safe_ranges':ranges,'binding':{'path':str(path),'sha256':expected_sha256},
            'current_implementations': expected,
            'files':[{'path':str(p),'sha256':digest} for p,digest in observed_files.items()]}


def _glyph_topology(mask: np.ndarray) -> tuple[int, ...]:
    """Left-to-right connected glyphs and enclosed counters; no size threshold.

    No speckle is silently removed. A noisy/occluded foreground therefore fails
    to match the reference topology instead of becoming a certified word.
    """
    count, labels, stats, _ = cv2.connectedComponentsWithStats((mask != 0).astype(np.uint8), connectivity=8)
    components = []
    for index in range(1, count):
        x, y, width, height, _ = stats[index]
        item = (labels[y:y+height, x:x+width] == index).astype(np.uint8)*255
        _, hierarchy = cv2.findContours(item, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        holes = 0 if hierarchy is None else sum(int(row[3] >= 0) for row in hierarchy[0])
        components.append((int(x), int(y), holes))
    components.sort()
    return tuple(row[2] for row in components)


def qualify_owned_word_extent(rgb: np.ndarray, line: dict[str, Any], reference: dict[str, Any],
                             *, canonical_text: str) -> dict[str, Any]:
    """One-sided counterexample for an owned, expected, upright word.

    This does not identify an em size. It tests the necessary pixel extent of
    the declared allowed glyphs. A complete word that cannot fit their smallest
    minimum-size raster contradicts that contract. A larger word never proves
    all typography/style. Topology + independently recorded OCR are required;
    cropped/noisy/foreign text cannot be turned into an extent verdict.
    """
    if canonical_text != line.get("text") or canonical_text != reference.get("word"):
        raise PermissionError("word is not an exact canonical owned label")
    observation = measure_word_enclosure(rgb, line, reference)
    l, t, r, b = observation["crop_box"]
    gray = cv2.cvtColor(rgb[t:b, l:r], cv2.COLOR_RGB2GRAY)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    observed = _glyph_topology(mask)
    expected = []
    for row in reference["fonts"]:
        path = Path(row["path"])
        if "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise PermissionError("owned word font reference changed")
        font = ImageFont.truetype(str(path), size=row["minimum_em_px"])
        if row["named_instance"] != "static":
            font.set_variation_by_name(row["named_instance"].encode("ascii"))
        painted = font.getmask(canonical_text, mode="L")
        raster = np.asarray(painted, dtype=np.uint8).reshape(painted.size[1], painted.size[0])
        _, binary = cv2.threshold(raster, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        expected.append(_glyph_topology(binary))
    topology_matches = observed in expected and len(observed) == len(canonical_text)
    contradiction = topology_matches and observation["enclosure_below_reference_ink_height"]
    return {"version": "phase6-owned-word-extent-counterexample-v1", "measurement": observation,
            "canonical_text": canonical_text, "observed_glyph_topology": list(observed),
            "allowed_glyph_topologies": [list(row) for row in expected],
            "glyph_topology_matches": topology_matches,
            "extent_counterexample": contradiction,
            "status": "CANONICAL_WORD_EXTENT_COUNTEREXAMPLE" if contradiction else
                      ("NO_EXTENT_COUNTEREXAMPLE_NOT_STYLE_PASS" if topology_matches else "UNOBSERVABLE_GLYPH_ATTRIBUTION"),
            "actual_font_or_em_size_identified": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}


def observe_declared_source_word(svg: bytes, raster: bytes, *, word: str) -> dict[str, Any]:
    """Check a legacy owned glyph's declared size against its actual PNG ink.

    This is a narrowly versioned reconstruction of the existing v1.0.1 Pillow
    glyph primitive (mm anchor), NOT a replay of video, SVG CSS layout or QA.
    Exact pixels are appropriate to identify this deterministic source glyph;
    they are never demanded of the lossy final video or used as semantic QA.
    """
    import io
    import xml.etree.ElementTree as ET
    from PIL import Image, ImageDraw
    tree = ET.fromstring(svg)
    styles = "\n".join("".join(node.itertext()) for node in tree.iter("{http://www.w3.org/2000/svg}style"))
    match = re.search(r"\.step\{font:700 (\d+)px Arial,sans-serif;letter-spacing:1px;fill:(#[0-9A-Fa-f]{6})\}", styles)
    nodes = [node for node in tree.iter("{http://www.w3.org/2000/svg}text")
             if node.get("class") == "step" and "".join(node.itertext()).strip() == word]
    if match is None or len(nodes) != 1:
        raise VisualMeasurementUnavailable("source glyph primitive/label is outside v1.0.1 contract")
    node = nodes[0]
    size = int(match.group(1))
    if not 1 <= size <= 256 or not re.fullmatch(r"[A-Z]{3,}", word):
        raise VisualMeasurementUnavailable("source glyph word/size outside bounded domain")
    x, y = float(node.attrib["x"]), float(node.attrib["y"])
    if not x.is_integer() or not y.is_integer():
        raise VisualMeasurementUnavailable("source glyph placement is not integer-exact v1.0.1")
    x, y = int(x), int(y)
    font_path = Path(r"C:\Windows\Fonts\arialbd.ttf")
    font_raw = font_path.read_bytes()
    font = ImageFont.truetype(str(font_path), size)
    with Image.open(io.BytesIO(raster)) as image:
        source = image.convert("RGB")
    if source.size != (1920,1080):
        raise VisualMeasurementUnavailable("source glyph canvas differs")
    box = ImageDraw.Draw(source).textbbox((x,y), word, font=font, anchor="mm")
    left, top, right, bottom = box
    if not (0 <= left < right <= 1920 and 0 <= top < bottom <= 1080):
        raise VisualMeasurementUnavailable("source glyph leaves its canvas")
    # The canonical v1.0.1 cards own this solid interior, not an inferred
    # background colour sampled conveniently from the observed glyph.
    expected = Image.new("RGB", (right-left,bottom-top), "#10283D")
    ImageDraw.Draw(expected).text((x-left,y-top), word, font=font, fill=match.group(2), anchor="mm")
    observed = source.crop(box)
    actual_raw, expected_raw = observed.tobytes(), expected.tobytes()
    if font_path.read_bytes() != font_raw:
        raise PermissionError("source glyph font changed during measurement")
    return {"version":"phase6-canonical-source-glyph-replay-v1", "word":word,
            "declared_source_em_px":size, "source_glyph_pixels_match":actual_raw == expected_raw,
            "identified_source_em_px":size if actual_raw == expected_raw else None,
            "source_box":list(box), "source_crop_sha256":"sha256:"+hashlib.sha256(actual_raw).hexdigest(),
            "reference_crop_sha256":"sha256:"+hashlib.sha256(expected_raw).hexdigest(),
            "font":{"path":str(font_path),"sha256":"sha256:"+hashlib.sha256(font_raw).hexdigest()},
            "final_em_size_proved":False, "new_video_render":False, "quality_authorized":False}


def minimum_glyph_reference(text: str, font_paths: tuple[Path, ...], minimum_em_px: int) -> dict[str, Any]:
    """Use font metrics for this exact word, not a universal font/box conversion."""
    if not re.fullmatch(r"[A-Z]{3,}", text) or type(minimum_em_px) is not int or minimum_em_px <= 0 or not font_paths:
        raise VisualMeasurementUnavailable("declared uppercase word/fonts/minimum required")
    rows = []
    for path in font_paths:
        raw = path.read_bytes()
        font = ImageFont.truetype(str(path.resolve()), size=minimum_em_px)
        try:
            variations = [n for n in font.get_variation_names() if n.startswith((b"Bold", b"SemiBold"))]
            if not variations:
                raise VisualMeasurementUnavailable("variable font has no declared Bold/SemiBold face")
        except OSError:
            variations = [None]  # Static Arial Bold supplied by the public consumer.
        for variation in variations:
            # A fresh font avoids FreeType's relative named-instance selection
            # affecting subsequent faces. Narrow faces remain represented.
            face = ImageFont.truetype(str(path.resolve()), size=minimum_em_px)
            if variation is not None:
                face.set_variation_by_name(variation)
            mask = face.getmask(text, mode="L")
            box = mask.getbbox()
            if box is None or box[3] <= box[1]:
                raise VisualMeasurementUnavailable("reference glyph ink is absent")
            rows.append({"path": str(path.resolve()), "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(),
                         "named_instance": variation.decode("ascii") if variation is not None else "static",
                         "minimum_em_px": minimum_em_px, "ink_box": list(box), "ink_height_px": box[3]-box[1]})
        if path.read_bytes() != raw:
            raise PermissionError("font changed during reference construction")
    return {"word": text, "fonts": rows, "minimum_allowed_ink_height_px": min(r["ink_height_px"] for r in rows),
            "threshold_origin": "exact word rasterized at Style Bible minimum in each declared allowed font",
            "font_size_inferred_from_ocr_box": False}


def measure_word_enclosure(rgb: np.ndarray, line: dict[str, Any], reference: dict[str, Any]) -> dict[str, Any]:
    """Report pixels and conservative enclosure, not detector confidence as QA.

    Axis-aligned, bright uppercase text on a darker uniform border is the only
    supported polarity/domain. Rotated, clipped, border-touching or empty masks
    return an explicit missing variable. Otsu is an estimator, not a quality
    threshold. The full detector rectangle (larger than measured ink) is used
    as the conservative observed enclosure; glyph height is also retained.
    """
    rgb = np.asarray(rgb)
    if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise VisualMeasurementUnavailable("native RGB uint8 frame required")
    if line.get("text") != reference["word"]:
        raise PermissionError("OCR word differs from glyph reference")
    box = np.asarray(line.get("box"), dtype=float)
    if box.shape != (4, 2) or not np.isfinite(box).all():
        raise VisualMeasurementUnavailable("four finite OCR corners required")
    left, top = np.floor(box.min(axis=0)).astype(int)
    right, bottom = np.ceil(box.max(axis=0)).astype(int)
    expected = np.array([[left, top], [right, top], [right, bottom], [left, bottom]])
    if not np.array_equal(box, expected):
        raise VisualMeasurementUnavailable("rotated/subpixel OCR enclosure needs separate projection")
    if not (0 <= left < right <= rgb.shape[1] and 0 <= top < bottom <= rgb.shape[0]):
        raise VisualMeasurementUnavailable("OCR enclosure is clipped/outside frame")
    crop = rgb[top:bottom, left:right]
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    split, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if not mask.any() or np.all(mask):
        raise VisualMeasurementUnavailable("no separable text/background pixels")
    if any(np.any(side) for side in (mask[0], mask[-1], mask[:, 0], mask[:, -1])):
        raise VisualMeasurementUnavailable("foreground meets enclosure boundary; extent is not bounded")
    ys, xs = np.where(mask != 0)
    extent = [int(xs.min()), int(ys.min()), int(xs.max())+1, int(ys.max())+1]
    minimum = reference["minimum_allowed_ink_height_px"]
    if type(minimum) is not int or minimum <= 0:
        raise PermissionError("glyph reference minimum is invalid")
    enclosing_height = int(bottom-top)
    return {"version": VERSION, "word": reference["word"], "ocr_confidence": line.get("confidence"),
            "frame_rgb_sha256": "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest(),
            "crop_box": [int(left), int(top), int(right), int(bottom)],
            "crop_rgb_sha256": "sha256:" + hashlib.sha256(crop.tobytes()).hexdigest(),
            "otsu_split_gray": float(split), "ink_pixels": int(len(xs)), "ink_box_within_crop": extent,
            "foreground_attribution_to_glyphs_proved": False,
            "measured_ink_height_px": extent[3]-extent[1], "detector_enclosure_height_px": enclosing_height,
            "reference": reference, "enclosure_below_reference_ink_height": enclosing_height < minimum,
            "scope": "SAMPLED_UPPERCASE_BRIGHT_WORD_GEOMETRY; not proof of em size, all text, or semantic style",
            "final_font_size_proved": False, "quality_authorized": False, "publication_authorized": False}


def measure_existing_ocr_typography(root: Path, *, quality_path: str | Path,
                                    expected_quality_sha256: str, output_directory: Path) -> dict[str, Any]:
    """Public consumer of the exact existing QA/OCR/pixels, no new inference.

    Published/queued media is never touched. This returns geometry evidence,
    including counterexamples and unknowns. It cannot overrule the historical
    overlay PASS (a different scope) or promote these observations to all-style
    approval. The reference font is the existing project Arial Bold at the
    Bible's minimum; it is not asserted to identify every observed font.
    """
    from PIL import Image
    from .phase6_quality import BASE, _resolve, _relative, _sha, _write_immutable
    from .phase6_overlay_ocr import verify_overlay_ocr_measurement

    root = root.resolve()
    path = _resolve(root, str(quality_path))
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_quality_sha256) or _sha(path, prefixed=True) != expected_quality_sha256:
        raise PermissionError("typography QA anchor mismatch")
    original = path.read_bytes()
    report = json.loads(original)
    audit = verify_overlay_ocr_measurement(root, report["measurements"]["overlay_ocr"])
    video = _resolve(root, audit["video"]["path"])
    if video.stat().st_size != audit["video"]["size_bytes"] or _sha(video, prefixed=True) != audit["video"]["sha256"]:
        raise PermissionError("typography frozen video differs")
    style_binding = audit["sources"]["style_bible"]
    style_path = _resolve(root, style_binding["path"])
    style_raw = style_path.read_bytes()
    if "sha256:" + hashlib.sha256(style_raw).hexdigest() != style_binding["sha256"]:
        raise PermissionError("typography Bible differs from existing OCR evidence")
    style = json.loads(style_raw)
    if "Arial" not in style["typography"]["families"] or "Bold" not in style["typography"]["weights"]:
        raise VisualMeasurementUnavailable("this font-family/weight instrument is outside the current Bible")
    if set(style["typography"]["families"]) != {"Arial", "Bahnschrift"}:
        raise VisualMeasurementUnavailable("declared font family population differs")
    minimum = style["typography"]["minimum_sizes"]["1920x1080"]
    fonts = (Path(r"C:\Windows\Fonts\arialbd.ttf"), Path(r"C:\Windows\Fonts\bahnschrift.ttf"))
    font_bindings = [{"path": str(f), "sha256": _sha(f, prefixed=True)} for f in fonts]
    code = Path(__file__).resolve()
    code_hash = _sha(code, prefixed=True)
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("typography requires a new confined observation directory")
    rows, unavailable, frames, references = [], [], [], {}
    for item in audit["frames"]:
        selected = [line for line in item["observed_lines"] if re.fullmatch(r"[A-Z]{3,}", str(line.get("text", "")))]
        if not selected:
            continue
        frame_path = _resolve(root, item["frame_path"])
        if frame_path.stat().st_size != item["frame_size_bytes"] or _sha(frame_path, prefixed=True) != item["frame_sha256"]:
            raise PermissionError("existing OCR frame changed")
        raw = frame_path.read_bytes()
        import io
        with Image.open(io.BytesIO(raw)) as image:
            rgb = np.asarray(image.convert("RGB"))
        if rgb.shape != (1080, 1920, 3):
            raise VisualMeasurementUnavailable("typography reference is only defined at native 1920x1080")
        for line in selected:
            scope = {"take_id": item["take_id"], "timecode_ms": item["timecode_ms"], "frame_path": item["frame_path"],
                     "frame_sha256": item["frame_sha256"], "text": line["text"]}
            try:
                if line["text"] not in references:
                    references[line["text"]] = minimum_glyph_reference(line["text"], fonts, minimum)
                reference = references[line["text"]]
                rows.append({**scope, "measurement": measure_word_enclosure(rgb, line, reference)})
            except VisualMeasurementUnavailable as exc:
                unavailable.append({**scope, "status": "UNOBSERVABLE", "variable": str(exc)})
        if frame_path.read_bytes() != raw:
            raise PermissionError("OCR pixels changed during measurement")
        frames.append({"path": item["frame_path"], "sha256": item["frame_sha256"]})
    if (path.read_bytes() != original or style_path.read_bytes() != style_raw
            or any(_sha(Path(f["path"]), prefixed=True) != f["sha256"] for f in font_bindings)
            or _sha(code, prefixed=True) != code_hash
            or _sha(video, prefixed=True) != audit["video"]["sha256"]):
        raise PermissionError("typography inputs changed before receipt")
    verify_overlay_ocr_measurement(root, report["measurements"]["overlay_ocr"])
    value = {"version": VERSION, "status": "EXISTING_OCR_PIXELS_MEASURED_NOT_FULL_STYLE_QA",
             "quality_source": {"path": _relative(root, path), "sha256": expected_quality_sha256},
             "bible": style_binding, "fonts": font_bindings,
             "instrument": {"path": str(code), "sha256": code_hash}, "frames": frames,
             "measurements": rows, "unobservable": unavailable,
             "geometric_counterexamples": sum(r["measurement"]["enclosure_below_reference_ink_height"] for r in rows),
             "new_ocr_inferences": 0, "new_decodes": 0, "new_render": False,
             "all_text_covered": False, "actual_font_identified": False,
             "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", value)
    return value


def _build_owned_word_extents(root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
                              quality_path: str | Path, expected_quality_sha256: str,
                              design_manifest_path: str | Path, expected_design_sha256: str) -> dict[str, Any]:
    """Canonical SVG labels -> existing decoded pixels -> one-sided decision.

    The SVG establishes expected text, not the observed font size. The actual
    pixel extent/topology is measured in the immutable final-video frame.
    This closes a narrow automatic counterexample path, not full style QA.
    """
    import io
    import xml.etree.ElementTree as ET
    from PIL import Image
    from .phase6_quality import BASE, _resolve, _relative, _sha, _write_immutable, read_phase6_visual_reference
    from .phase6_overlay_ocr import verify_overlay_ocr_measurement

    root = root.resolve()
    producer_paths = (Path(__file__).resolve(), Path(__file__).resolve().with_name("phase6_quality.py"))
    producer_bindings = [{"path":str(path), "sha256":_sha(path,prefixed=True)} for path in producer_paths]
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    saved = {}
    def read(path, anchor):
        path = _resolve(root, str(path))
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", str(anchor)):
            raise PermissionError("owned typography requires exact external anchors")
        raw = path.read_bytes()
        if "sha256:"+hashlib.sha256(raw).hexdigest() != anchor:
            raise PermissionError("owned typography source drift: " + path.name)
        saved[path] = raw
        return raw
    quality = json.loads(read(quality_path, expected_quality_sha256))
    audit = verify_overlay_ocr_measurement(root, quality["measurements"]["overlay_ocr"])
    if audit["video"] != reference["target"]:
        raise PermissionError("owned typography OCR belongs to a different target")
    design = json.loads(read(design_manifest_path, expected_design_sha256))
    if design.get("schema_version") != "1.0.0" or design.get("generator") != "HeroVerseLocalVectorMotion@1.0.1":
        raise VisualMeasurementUnavailable("unrecognized canonical vector design contract")
    assets = {row["asset_id"]: row for row in design["assets"]}
    if len(assets) != len(design["assets"]):
        raise PermissionError("duplicate canonical typography asset")
    bible_binding = audit["sources"]["style_bible"]
    if bible_binding not in reference["intent_bindings"]:
        # OCR can omit size_bytes; compare path/hash, never replace the anchor.
        if not any(_resolve(root, b["path"]) == _resolve(root, bible_binding["path"])
                   and b["sha256"] == bible_binding["sha256"] for b in reference["intent_bindings"]):
            raise PermissionError("owned typography Bible differs from reference")
    bible = json.loads(read(bible_binding["path"], bible_binding["sha256"]))
    if (set(bible["typography"]["families"]) != {"Arial", "Bahnschrift"}
            or set(bible["typography"]["weights"]) != {"Bold", "Semibold"}):
        raise VisualMeasurementUnavailable("font-family/weight population outside qualified extent instrument")
    minimum = bible["typography"]["minimum_sizes"]["1920x1080"]
    fonts = (Path(r"C:\Windows\Fonts\arialbd.ttf"), Path(r"C:\Windows\Fonts\bahnschrift.ttf"))
    takes = {row["take_id"]: row for row in reference["takes"]}
    labels, design_bindings, source_glyphs = {}, [], {}
    for take in reference["takes"]:
        asset = assets.get(take["asset_id"])
        if asset is None:
            continue
        if (_resolve(root, asset["video_path"]) != _resolve(root, take["source"]["path"])
                or asset["video_hash"] != take["source"]["sha256"]):
            raise PermissionError("canonical typography design belongs to a different source")
        svg = read(asset["svg_path"], asset["svg_hash"])
        raster = read(asset["raster_path"], asset["raster_hash"])
        tree = ET.fromstring(svg)
        words = ["".join(node.itertext()).strip() for node in tree.iter("{http://www.w3.org/2000/svg}text")
                 if node.get("class") == "step"]
        if not words:
            raise VisualMeasurementUnavailable("canonical owned asset has no step labels")
        labels[take["take_id"]] = {word for word in words if re.fullmatch(r"[A-Z]{3,}", word)}
        for word in labels[take["take_id"]]:
            key = (asset["asset_id"], word)
            if key not in source_glyphs:
                try:
                    source_glyphs[key] = observe_declared_source_word(svg, raster, word=word)
                except VisualMeasurementUnavailable as exc:
                    source_glyphs[key] = {"status":"SOURCE_GLYPH_UNOBSERVABLE", "variable":str(exc)}
        design_bindings.append({"take_id": take["take_id"], "asset_id": take["asset_id"],
                                "svg": {"path": asset["svg_path"], "sha256": asset["svg_hash"]},
                                "raster": {"path": asset["raster_path"], "sha256": asset["raster_hash"]}})
    rows, unknown, font_references = [], [], {}
    for frame in audit["frames"]:
        take = takes.get(frame["take_id"])
        if take is None:
            raise PermissionError("OCR frame contains a foreign take")
        selected = [line for line in frame["observed_lines"] if line.get("text") in labels.get(frame["take_id"], set())]
        if not selected:
            continue
        fps = reference["fps"]["numerator"]/reference["fps"]["denominator"]
        if not take["target_start_frame"] <= frame["timecode_ms"]*fps/1000 < take["target_end_frame_exclusive"]:
            raise PermissionError("owned typography OCR timestamp outside canonical take")
        raw = read(frame["frame_path"], frame["frame_sha256"])
        with Image.open(io.BytesIO(raw)) as image:
            rgb = np.asarray(image.convert("RGB"))
        if rgb.shape != (1080,1920,3):
            raise VisualMeasurementUnavailable("owned typography requires the native canvas")
        for line in selected:
            word = line["text"]
            if word not in font_references:
                font_references[word] = minimum_glyph_reference(word, fonts, minimum)
            context = {"take_id": take["take_id"], "word": word, "timecode_ms": frame["timecode_ms"],
                       "frame": {"path": frame["frame_path"], "sha256": frame["frame_sha256"]}}
            try:
                rows.append({**context, "source_glyph":source_glyphs[(take["asset_id"],word)],
                             "result": qualify_owned_word_extent(rgb, line, font_references[word], canonical_text=word)})
            except VisualMeasurementUnavailable as exc:
                unknown.append({**context, "status": "UNOBSERVABLE", "variable": str(exc)})
    if any(path.read_bytes() != raw for path,raw in saved.items()):
        raise PermissionError("owned typography input changed during measurement")
    for binding in producer_bindings:
        if _sha(Path(binding["path"]),prefixed=True) != binding["sha256"]:
            raise PermissionError("owned typography implementation changed during measurement")
    for ref in font_references.values():
        for binding in ref["fonts"]:
            if _sha(Path(binding["path"]),prefixed=True) != binding["sha256"]:
                raise PermissionError("owned typography font changed before receipt")
    read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    failed = sum(row["result"]["extent_counterexample"] for row in rows)
    value = {"version": "phase6-owned-word-extent-population-v2",
             "status": "CANONICAL_WORD_EXTENT_COUNTEREXAMPLES_FOUND" if failed else "PARTIAL_WORD_EXTENTS_MEASURED",
             "criterion": "STYLE_DRIFT/owned-required-word-pixel-extent", "counterexample_count": failed,
             "reference": {"path": str(reference_path), "sha256": expected_reference_sha256},
             "quality_source": {"path": str(quality_path), "sha256": expected_quality_sha256},
             "design_manifest": {"path": str(design_manifest_path), "sha256": expected_design_sha256},
             "implementation_bindings":producer_bindings,
             "design_bindings": design_bindings, "bible_minimum_em_px": minimum,
             "measurements": rows, "unobservable": unknown, "new_ocr_inferences": 0, "new_decodes": 0,
             "full_style_covered": False, "font_size_inferred_from_ocr_box": False,
             "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    return value


def measure_owned_word_extents(root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
                              quality_path: str | Path, expected_quality_sha256: str,
                              design_manifest_path: str | Path, expected_design_sha256: str,
                              output_directory: Path) -> dict[str, Any]:
    """Persist a fresh observation; historical v1 observations stay immutable."""
    from .phase6_quality import BASE, _resolve, _write_immutable
    root = root.resolve()
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError("owned typography requires a new confined observation directory")
    value = _build_owned_word_extents(root, reference_path=reference_path,
        expected_reference_sha256=expected_reference_sha256, quality_path=quality_path,
        expected_quality_sha256=expected_quality_sha256, design_manifest_path=design_manifest_path,
        expected_design_sha256=expected_design_sha256)
    _write_immutable(directory / "measurement.json", value)
    return value


def verify_owned_word_extents(root: Path, *, receipt_path: str | Path,
                             expected_sha256: str) -> dict[str, Any]:
    """Recompute the cheap pixel decision, not OCR/video, before consumption.

    An external hash is an integrity anchor, not permission to trust a caller's
    PASS/counts. Historical v1 remains evidence, not current consumer authority.
    This reader has no writes, queue, decode, model inference or release effects.
    """
    from .phase6_quality import BASE, _resolve
    root = root.resolve()
    path = _resolve(root, str(receipt_path))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in path.parents or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(expected_sha256)):
        raise PermissionError("owned typography receipt path/anchor invalid")
    raw = path.read_bytes()
    if "sha256:"+hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("owned typography receipt anchor differs")
    value = json.loads(raw)
    if value.get("version") != "phase6-owned-word-extent-population-v2":
        raise PermissionError("owned typography receipt version is not a current decision")
    recomputed = _build_owned_word_extents(root,
        reference_path=value["reference"]["path"], expected_reference_sha256=value["reference"]["sha256"],
        quality_path=value["quality_source"]["path"], expected_quality_sha256=value["quality_source"]["sha256"],
        design_manifest_path=value["design_manifest"]["path"], expected_design_sha256=value["design_manifest"]["sha256"])
    if recomputed != value or path.read_bytes() != raw:
        raise PermissionError("owned typography measured decision or inputs differ")
    return value


def revalidate_owned_word_extents(root: Path, *, receipt_path: str | Path,
                                 expected_sha256: str) -> dict[str, Any]:
    """Current pixel recomputation, explicitly NOT historical code replay.

    Keep the v2 receipt/strict reader immutable. The external anchor identifies
    the historical document, not approval of its producer by today's code.
    Every measurement, input, font, decision and authority field must reproduce
    exactly. Only producer identity is compared in separate historical/current
    scopes. The old executable bytes are not claimed to have been re-executed.
    This never substitutes source bindings or accepts caller-provided results.
    """
    from .phase6_quality import BASE, _resolve
    root = root.resolve()
    path = _resolve(root, str(receipt_path))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in path.parents or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(expected_sha256)):
        raise PermissionError("owned typography revalidation path/anchor invalid")
    raw = path.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("owned typography revalidation anchor differs")
    historical = json.loads(raw)
    if historical.get("version") != "phase6-owned-word-extent-population-v2":
        raise PermissionError("unsupported historical typography observation contract")
    current = _build_owned_word_extents(root,
        reference_path=historical["reference"]["path"], expected_reference_sha256=historical["reference"]["sha256"],
        quality_path=historical["quality_source"]["path"], expected_quality_sha256=historical["quality_source"]["sha256"],
        design_manifest_path=historical["design_manifest"]["path"], expected_design_sha256=historical["design_manifest"]["sha256"])
    old_implementation = historical.get("implementation_bindings")
    new_implementation = current["implementation_bindings"]
    if not isinstance(old_implementation, list) or len(old_implementation) != len(new_implementation):
        raise PermissionError("historical producer population is incomplete")
    for old, new in zip(old_implementation, new_implementation):
        if (not isinstance(old, dict) or set(old) != {"path", "sha256"}
                or not isinstance(old["path"], str) or not Path(old["path"]).is_absolute()
                or Path(old["path"]).resolve() != Path(new["path"]).resolve()
                or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(old["sha256"]))):
            raise PermissionError("historical producer identity is malformed or belongs to another module")
    # No other field is excluded. An old PASS/count/hash cannot override current
    # pixels, and unknown additions/downgrades fail rather than silently vanish.
    historical_logic = {k: v for k, v in historical.items() if k != "implementation_bindings"}
    current_logic = {k: v for k, v in current.items() if k != "implementation_bindings"}
    # Python equality treats True == 1. A count or an authority bit may not
    # change type while claiming identical logical evidence.
    old_encoded, current_encoded = (json.dumps(v, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode("utf-8") for v in (historical_logic, current_logic))
    if old_encoded != current_encoded or path.read_bytes() != raw:
        raise PermissionError("owned typography revalidation measurements or inputs differ")
    logical_hash = "sha256:" + hashlib.sha256(current_encoded).hexdigest()
    return {"version": "phase6-owned-word-current-revalidation-v1",
            "status": "CURRENT_PIXELS_RECOMPUTED_EQUAL", "measurement": current,
            "historical_receipt": {"path": str(path), "sha256": expected_sha256},
            "historical_implementation_bindings": old_implementation,
            "current_implementation_bindings": new_implementation,
            "logical_measurement_sha256": logical_hash,
            "historical_code_replayed": False, "historical_code_bytes_attested": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
