"""Automatic, hash-bound hand observations; NOT an anatomy/quality verdict.

Pre/postprocessing follows the Apache-2.0 OpenCV Zoo MediaPipe model contract:
https://github.com/opencv/opencv_zoo/tree/main/models/handpose_estimation_mediapipe
https://github.com/opencv/opencv_zoo/tree/main/models/palm_detection_mediapipe
Adaptations: bytes-only model loading (Unicode-safe), finite/domain checks,
explicit xywh NMS boxes and complete provenance. The model ALWAYS estimates a
21-point template: that count cannot establish finger count or valid anatomy.
"""
from __future__ import annotations

import hashlib
import itertools
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .phase6_visual_metrics import VisualMeasurementUnavailable


VERSION = "phase6-mediapipe-fp32-hand-observations-v1"
MODEL_DIRECTORY = Path("models/visual-reference/mediapipe-hands-fp32-v1")
MODEL_BINDINGS = {
    "palm": ("palm_detection_mediapipe_2023feb.onnx", 3905734, "78ff51c38496b7fc8b8ebdb6cc8c1abb02fa6c38427c6848254cdaba57fcce7c"),
    "pose": ("handpose_estimation_mediapipe_2023feb.onnx", 4099621, "db0898ae717b76b075d9bf563af315b29562e11f8df5027a1ef07b02bef6d81c"),
}
# Upstream inference defaults, NOT project defect/acceptance tolerances.
PALM_CONFIDENCE = 0.5
PALM_NMS_IOU = 0.3
POSE_CONFIDENCE = 0.8

# Official Apache-2.0 EfficientSAM split ONNX, revision d525f622e6f640acf5a0fc37c7ca1f243da5bde0.
# These anchors were authenticated against that revision's Git blobs, not
# inferred from a caller-supplied model. No package installation or download here.
SEGMENT_DIRECTORY = Path('models/visual-reference/efficient-sam-tiny-onnx-v1')
SEGMENT_BINDINGS = {
    'encoder': ('efficient_sam_vitt_encoder.onnx', 24799761, '84ed466ffcc5c1f8d08409bc34a23bb364ab2c15e402cb12d4335a42be0e0951'),
    'decoder': ('efficient_sam_vitt_decoder.onnx', 16565728, 'a62f8fa5ea080447c0689418d69e58f1e83e0b7adf9c142e2bd9bcc8045c0b11'),
}


class FaceObserver:
    """Serial YuNet geometry, using the existing model/semantics, not identity QA.

    Publicity's immutable count-only history remains unchanged. Retain every
    raw row and its pixels so an evaluator can measure correspondence instead
    of confusing a detection count with facial continuity or absence.
    """

    def __init__(self, root: Path):
        from .phase6_publicity import YUNET_SHA256
        self.root = root.resolve()
        self.path = (self.root / 'models/yunet/face_detection_yunet_2026may.onnx').resolve()
        if self.root not in self.path.parents:
            raise PermissionError('face model escaped root')
        self.data = self.path.read_bytes()
        if len(self.data) != 229738 or hashlib.sha256(self.data).hexdigest() != YUNET_SHA256:
            raise PermissionError('face model differs from existing anchor')
        self.detector = cv2.FaceDetectorYN.create('onnx', np.frombuffer(self.data, np.uint8),
            np.frombuffer(b'', np.uint8), (320, 320), .80, .30, 5000)

    def observe(self, rgb: np.ndarray) -> dict:
        from .phase6_av_detector_semantics import SETTINGS, validate_raw
        rgb = _image(rgb)
        height, width = rgb.shape[:2]
        if rgb.nbytes > 67108864:
            raise VisualMeasurementUnavailable('face RGB exceeds existing 64MiB bound')
        if self.path.read_bytes() != self.data:
            raise PermissionError('face model changed before inference')
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        if width > SETTINGS['resize_max_width']:
            bgr = cv2.resize(bgr, (1280, max(1, round(height * 1280 / width))),
                             interpolation=cv2.INTER_LINEAR)
        old_threads, old_opencl = cv2.getNumThreads(), cv2.ocl.useOpenCL()
        try:
            cv2.setNumThreads(1)
            cv2.ocl.setUseOpenCL(False)
            self.detector.setInputSize((bgr.shape[1], bgr.shape[0]))
            retval, detections = self.detector.detect(bgr)
        finally:
            cv2.ocl.setUseOpenCL(old_opencl)
            cv2.setNumThreads(old_threads)
        raw = {'settings': dict(SETTINGS), 'input_size': [bgr.shape[1], bgr.shape[0]],
               'opencv_version': cv2.__version__, 'retval': retval,
               'detections': None if detections is None else detections.tolist()}
        parsed = validate_raw(raw, source_width=width, source_height=height,
                              observed_opencv_version=cv2.__version__)
        if self.path.read_bytes() != self.data:
            raise PermissionError('face model changed during inference')
        return {'version': 'phase6-yunet-face-geometry-v1', 'raw': raw,
                'width': width, 'height': height, 'face_count': parsed['face_count'],
                'decoded_rgb_sha256': 'sha256:'+hashlib.sha256(rgb.tobytes()).hexdigest(),
                'model_sha256': 'sha256:'+hashlib.sha256(self.data).hexdigest(),
                'identity_proved': False, 'zero_detections_proves_absence': False,
                'quality_authorized': False}


def measure_face_temporal_correspondence(observations, frames, *, frame_indices, fps, layout: dict,
        region_observations=None, region_masks=None) -> dict:
    """Adjacent pixel-supported face association, never biometric identity.

    Reuse the existing authenticated geometry and forward/backward LK reader.
    Every detection and point remains accounted for. No gap bridging, nearest
    face identity claim, quality threshold, resampling, or hidden point pruning.
    A reciprocal best association is a measurement, not evidence that its
    residual/round-trip error is acceptable or that the source is unoccluded.
    Optional independently inferred regions are additional abstention evidence,
    never ground truth: every origin AND actual transported endpoint must be
    foreground in its own frame. Missing inputs are not a partial fallback.
    """
    from fractions import Fraction
    from .phase6_visual_metrics import track_reference_points, declared_source_motion_support
    if (not isinstance(fps, Fraction) or fps <= 0 or not 2 <= len(frames) <= 3
            or len(observations) != len(frames) or len(frame_indices) != len(frames)
            or any(type(i) is not int or i < 0 for i in frame_indices)
            or any(b != a+1 for a, b in zip(frame_indices, frame_indices[1:]))):
        raise PermissionError('face temporal observation requires consecutive bounded exact frame clocks')
    rgb = [_image(frame) for frame in frames]
    if any(frame.shape != rgb[0].shape for frame in rgb):
        raise PermissionError('face temporal canvases differ')
    if layout.get('canvas') != {'width': rgb[0].shape[1], 'height': rgb[0].shape[0]}:
        raise PermissionError('face temporal layout canvas differs from pixels')
    memberships, region_support = [], []
    if (region_observations is None) != (region_masks is None):
        raise PermissionError('face temporal regions require both observations and masks')
    if region_observations is not None:
        import copy
        if (not isinstance(region_observations, (list, tuple))
                or not isinstance(region_masks, (list, tuple))
                or len(region_observations) != len(rgb) or len(region_masks) != len(rgb)):
            raise PermissionError('face temporal region population differs from frame clocks')
        # Own the entire invocation's buffers before validation/native callbacks.
        # The enclosing receipt reader authenticates the external source bytes.
        rgb = [frame.copy() for frame in rgb]
        observations = copy.deepcopy(observations)
        layout = copy.deepcopy(layout)
        frame_indices = list(frame_indices)
        regions = copy.deepcopy(region_observations)
        masks = [np.array(mask, copy=True) for mask in region_masks]
        for frame, face, region, mask in zip(rgb, observations, regions, masks):
            memberships.append(measure_face_region_membership(frame, face, region, mask, layout=layout))
            _, conditioned = measure_layout_conditioned_mask(mask, layout)
            region_support.append(conditioned == 1)
    # Self-comparison authenticates raw population, source pixels/model and
    # authority using the existing strict consumer, before any optical flow.
    validated = [compare_face_geometry(obs, obs, frame, frame, layout=layout)
                 for obs, frame in zip(observations, rgb)]
    support = None
    steps = []

    def supported(points, raster=None):
        # Same conservative subpixel rule as reference_motion_transfer:
        # every floor/ceil neighbour must carry observed window support.
        # Flooring alone can turn a fractional crossing into false support.
        raster = support if raster is None else raster
        answer = []
        for point in points:
            if point is None:
                answer.append(None)
                continue
            xy = np.asarray(point, np.float64)
            if xy.shape != (2,) or not np.isfinite(xy).all():
                raise PermissionError('face transport positions must be finite 2-D points')
            low, high = np.floor(xy).astype(int), np.ceil(xy).astype(int)
            inside = ((low >= 0).all() and high[0] < raster.shape[1]
                      and high[1] < raster.shape[0])
            answer.append(bool(inside and raster[low[1]:high[1]+1, low[0]:high[0]+1].all()))
        return answer

    def association(flow, destinations):
        if flow['observed_points'] != flow['requested_points']:
            return {'status': 'INCOMPLETE_PIXEL_TRANSPORT', 'permutation': None}
        xy = np.asarray([r['observed_xy'] for r in flow['rows']], np.float64).reshape(-1, 5, 2)
        costs = sorted((sum(float(np.mean(np.sum((xy[i]-destinations[j])**2, axis=1)))
            for i, j in enumerate(order)), order) for order in itertools.permutations(range(len(destinations))))
        best, order = costs[0]
        margin = costs[1][0]-best if len(costs) > 1 else None
        if margin is not None and margin <= np.spacing(max(1., abs(best)))*8:
            return {'status': 'AMBIGUOUS_PIXEL_ASSOCIATION', 'permutation': None,
                    'assignment_cost_px2': best, 'assignment_margin_px2': margin}
        return {'status': 'UNIQUE_MINIMUM_NOT_CALIBRATED', 'permutation': list(order),
                'assignment_cost_px2': best, 'assignment_margin_px2': margin}

    for index, (a, b) in enumerate(zip(validated, validated[1:])):
        step = {'from_frame_index': frame_indices[index], 'to_frame_index': frame_indices[index+1],
                'elapsed_seconds': float(1/fps), 'from_face_count': a['reference_face_count'],
                'to_face_count': b['reference_face_count'], 'links': [], 'identity_proved': False}
        steps.append(step)
        if not a['reference_face_count'] and not b['reference_face_count']:
            step['status'] = 'NO_FACE_PAIR_OBSERVED_NOT_ABSENCE'
            continue
        if a['reference_face_count'] != b['reference_face_count']:
            step['status'] = 'POPULATION_GAP_NO_BRIDGING'
            continue
        if not a['matches'] or not b['matches']:
            step.update(status='GEOMETRY_UNRESOLVED_NO_ASSOCIATION',
                        geometry_statuses=[a['status'], b['status']])
            continue
        aa = np.asarray([m['reference_landmarks_xy'] for m in a['matches']], np.float64)
        bb = np.asarray([m['reference_landmarks_xy'] for m in b['matches']], np.float64)
        if region_support:
            step['model_region_origin_support'] = {
                'from_points': supported(aa.reshape(-1, 2), region_support[index]),
                'to_points': supported(bb.reshape(-1, 2), region_support[index+1]),
                'landmark_visibility_proved': False}
            if not all(flag is True for key in ('from_points', 'to_points')
                       for flag in step['model_region_origin_support'][key]):
                step['status'] = 'UNSUPPORTED_MODEL_REGION_ORIGIN_NO_ASSOCIATION'
                continue
        if support is None:
            support, support_measurement = declared_source_motion_support(layout)
        step['declared_layout_window_support'] = {'from_points': supported(aa.reshape(-1, 2)),
            'to_points': supported(bb.reshape(-1, 2)), 'instrument_support': support_measurement,
            'support_raster_sha256': 'sha256:'+hashlib.sha256(support.tobytes()).hexdigest(),
            'subpixel_rule': 'ALL_FLOOR_CEIL_NEIGHBOURS',
            'intrinsic_occlusion_proved': False}
        # Do not spend flow on windows already known to include overlays,
        # transparency, potential text or unavailable frame support.
        if not all(step['declared_layout_window_support'][key][i]
                   for key in ('from_points','to_points') for i in range(aa.size//2)):
            step['status'] = 'UNOBSERVABLE_DECLARED_COMPOSITION_SUPPORT'
            continue
        old_threads, old_opencl = cv2.getNumThreads(), cv2.ocl.useOpenCL()
        try:
            cv2.setNumThreads(1); cv2.ocl.setUseOpenCL(False)
            forward = track_reference_points(rgb[index], rgb[index+1], aa.reshape(-1, 2))
            backward = track_reference_points(rgb[index+1], rgb[index], bb.reshape(-1, 2))
        finally:
            cv2.ocl.setUseOpenCL(old_opencl); cv2.setNumThreads(old_threads)
        # Detector destinations are not the pixels reached by LK. Retain the
        # actual transport and its unknown rows, but never form an association
        # using a destination whose window left declared composition support.
        step['transported_layout_window_support'] = {
            'forward_points': supported([row['observed_xy'] for row in forward['rows']]),
            'backward_points': supported([row['observed_xy'] for row in backward['rows']]),
            'intrinsic_visibility_proved': False, 'quality_authorized': False}
        f, r = association(forward, bb), association(backward, aa)
        step.update(forward_transport=forward, backward_transport=backward,
                    forward_association=f, backward_association=r)
        if region_support:
            step['model_region_transport_support'] = {
                'forward_points': supported([row['observed_xy'] for row in forward['rows']], region_support[index+1]),
                'backward_points': supported([row['observed_xy'] for row in backward['rows']], region_support[index]),
                'landmark_visibility_proved': False}
            if not all(flag is True for key in ('forward_points', 'backward_points')
                       for flag in step['model_region_transport_support'][key]):
                step['status'] = 'UNSUPPORTED_MODEL_REGION_TRANSPORT_NO_ASSOCIATION'
                continue
        if f['permutation'] is None or r['permutation'] is None:
            step['status'] = 'UNRESOLVED_PIXEL_ASSOCIATION'
            continue
        if not all(flag is True for key in ('forward_points', 'backward_points')
                   for flag in step['transported_layout_window_support'][key]):
            step['status'] = 'UNOBSERVABLE_TRANSPORTED_COMPOSITION_SUPPORT'
            continue
        if any(r['permutation'][j] != i for i, j in enumerate(f['permutation'])):
            step['status'] = 'NONRECIPROCAL_PIXEL_ASSOCIATION'
            continue
        for i, j in enumerate(f['permutation']):
            fr, br = forward['rows'][i*5:(i+1)*5], backward['rows'][j*5:(j+1)*5]
            step['links'].append({'from_face': i, 'to_face': j,
                'forward_detector_residual_px': np.linalg.norm(np.asarray([v['observed_xy'] for v in fr])-bb[j], axis=1).tolist(),
                'backward_detector_residual_px': np.linalg.norm(np.asarray([v['observed_xy'] for v in br])-aa[i], axis=1).tolist(),
                'forward_roundtrip_error_px': [v['forward_backward_error_px'] for v in fr],
                'backward_roundtrip_error_px': [v['forward_backward_error_px'] for v in br],
                'identity_proved': False, 'residual_acceptance_calibrated': False})
        step['status'] = 'RECIPROCAL_PIXEL_ASSOCIATION_MEASURED_NOT_IDENTITY'
    result = {'version': 'phase6-face-temporal-correspondence-v2',
        'frame_indices': list(frame_indices), 'fps': {'numerator':fps.numerator,'denominator':fps.denominator},
        'frame_rgb_hashes': [o['decoded_rgb_sha256'] for o in observations],
        'population_by_frame': [v['reference_face_count'] for v in validated], 'steps': steps,
        'declared_support_by_frame': [{'frame_index': frame_index, 'geometry_status': v['status'],
            'faces': [{'face_index': m['reference_face'],
                'fixed_reference_region_support': m['fixed_reference_region_support'],
                'landmark_indices_unmodified_by_declared_layout':
                    m['landmark_indices_unmodified_by_declared_layout']['reference']}
                for m in v['matches']]} for frame_index, v in zip(frame_indices, validated)],
        'requested_steps': len(steps),
        'reciprocal_association_steps': sum(s['status']=='RECIPROCAL_PIXEL_ASSOCIATION_MEASURED_NOT_IDENTITY' for s in steps),
        'identity_proved': False, 'intrinsic_visibility_proved': False, 'quality_authorized': False,
        'tolerance': None, 'zero_detections_proves_absence': False, 'full_duration_coverage': False}
    if region_support:
        result.update(version='phase6-face-temporal-correspondence-v3',
            model_region_membership_by_frame=[{'frame_index': index, 'measurement': membership}
                for index, membership in zip(frame_indices, memberships)],
            model_region_scope='ADDITIONAL_ABSTENTION_NOT_INTRINSIC_VISIBILITY_OR_IDENTITY',
            model_region_support_required=True)
    return result


def measure_face_region_support(box_xyxy, *, layout: dict) -> dict:
    """Measure every integer sample of a fixed reference box against layout.

    A box is NOT an anatomical mask. This describes only declared composition,
    never intrinsic occlusion in the source, visibility behind a hand, actual
    glyph ink, codec leakage or identity. Do not choose the candidate's box to
    hide a displacement. Existing layout semantics supply alpha/text coverage.
    """
    import json
    from .phase6_visual_metrics import layout_landmark_visibility
    canvas = layout.get('canvas', {})
    width, height = canvas.get('width'), canvas.get('height')
    if (type(width) is not int or type(height) is not int or min(width, height) < 16
            or width*height*3 > 67108864):
        raise VisualMeasurementUnavailable('face support needs bounded typed RGB canvas')
    box = np.asarray(box_xyxy, np.float64)
    if (box.shape != (4,) or not np.isfinite(box).all()
            or box[2] <= box[0] or box[3] <= box[1]):
        raise VisualMeasurementUnavailable('finite positive reference face rectangle required')
    left, top = int(np.floor(box[0])), int(np.floor(box[1]))
    right, bottom = int(np.ceil(box[2])), int(np.ceil(box[3]))
    x0, y0, x1, y1 = max(0, left), max(0, top), min(width, right), min(height, bottom)
    inside = max(0, x1-x0)*max(0, y1-y0)
    requested = (right-left)*(bottom-top)
    counts = dict(opaque_pixels=0, translucent_pixels=0, potential_text_pixels=0,
                  layout_affected_union_pixels=0, unchanged_by_declared_layout_pixels=0)
    transmission_sum = 0.
    # Validate all primitives even when this box is entirely outside the frame.
    layout_landmark_visibility(np.array([[0., 0.]]), layout)
    if inside:
        for start in range(y0, y1, 32):
            yy, xx = np.mgrid[start:min(y1,start+32), x0:x1]
            points = np.column_stack((xx.ravel(), yy.ravel()))
            observed = layout_landmark_visibility(points, layout)
            transmission = np.asarray(observed['declared_source_transmission'], np.float64)
            opaque = transmission == 0
            translucent = (transmission > 0) & (transmission < 1)
            text = np.zeros(len(points), bool)
            for region in observed['text_bound_regions']:
                text[region['potentially_occluded_indices']] = True
            affected = opaque | translucent | text
            counts['opaque_pixels'] += int(opaque.sum())
            counts['translucent_pixels'] += int(translucent.sum())
            counts['potential_text_pixels'] += int(text.sum())
            counts['layout_affected_union_pixels'] += int(affected.sum())
            counts['unchanged_by_declared_layout_pixels'] += int((~affected).sum())
            transmission_sum += float(transmission.sum())
    return {'version': 'phase6-fixed-face-box-layout-support-v1',
        'reference_box_xyxy': box.tolist(), 'integer_reference_box_xyxy': [left,top,right,bottom],
        'sampled_box_xyxy': [x0,y0,x1,y1] if inside else None,
        'requested_box_pixels': requested, 'inside_canvas_pixels': inside,
        'outside_canvas_pixels': requested-inside, **counts,
        'mean_declared_source_transmission': transmission_sum/inside if inside else None,
        'entire_box_unmodified_by_declared_layout': inside == requested and counts['layout_affected_union_pixels'] == 0,
        'layout_sha256': 'sha256:'+hashlib.sha256(json.dumps(layout, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode()).hexdigest(),
        'coordinate_scope': 'FIXED_REFERENCE_BOX_NOT_CANDIDATE_SELECTED',
        'box_is_anatomical_mask': False, 'text_bounds_are_ink': False,
        'intrinsic_source_occlusion_proved': False, 'full_face_visibility_proved': False,
        'identity_proved': False, 'quality_authorized': False}


def compare_face_geometry(reference: dict, candidate: dict, reference_rgb: np.ndarray,
                          candidate_rgb: np.ndarray, *, layout: dict) -> dict:
    """Measure paired composed frames; no biometric identification or fitting.

    The caller authenticates independent pre-mux and target frame clocks.
    Bijection uses absolute positions, not best shape/appearance. Appearance
    is measured at the reference's fixed ROI; resampling or a candidate-picked
    crop cannot conceal changes. Detector uncertainty is not a defect verdict.
    """
    from .phase6_av_detector_semantics import validate_raw
    from .phase6_publicity import YUNET_SHA256
    from .phase6_visual_metrics import landmark_shape_error, layout_landmark_visibility, spatial_measurements
    frames = [_image(reference_rgb), _image(candidate_rgb)]
    if frames[0].shape != frames[1].shape:
        raise VisualMeasurementUnavailable('paired composed face frames require the same canvas')
    height, width = frames[0].shape[:2]
    if layout['canvas'] != {'width': width, 'height': height}:
        raise VisualMeasurementUnavailable('face layout canvas differs')
    populations = []
    for observation, frame in zip((reference, candidate), frames):
        if (observation.get('version') != 'phase6-yunet-face-geometry-v1'
                or observation.get('model_sha256') != 'sha256:'+YUNET_SHA256
                or any(observation.get(k) is not False for k in
                       ('identity_proved', 'zero_detections_proves_absence', 'quality_authorized'))
                or observation.get('decoded_rgb_sha256') != 'sha256:'+hashlib.sha256(frame.tobytes()).hexdigest()
                or type(observation.get('width')) is not int or type(observation.get('height')) is not int
                or (observation['width'], observation['height']) != (width, height)):
            raise PermissionError('face observation pixels, model or authority differs')
        parsed = validate_raw(observation['raw'], source_width=width, source_height=height,
                              observed_opencv_version=cv2.__version__)
        if type(observation.get('face_count')) is not int or observation['face_count'] != parsed['face_count']:
            raise PermissionError('face population differs from raw output')
        scale = np.array([width, height]) / observation['raw']['input_size']
        population = []
        for row in observation['raw']['detections'] or []:
            population.append({'points': np.asarray(row[4:14]).reshape(5, 2) * scale,
                'box': np.asarray(row[:4]) * np.tile(scale, 2), 'confidence': row[14]})
        populations.append(population)
    ref, out = populations
    result = {'method': 'paired-composed-yunet-reference-geometry-v2',
        'reference_face_count': len(ref), 'candidate_face_count': len(out), 'matches': [],
        'identity_proved': False, 'zero_detections_proves_absence': False,
        'tolerance': None, 'quality_authorized': False,
        'scope': 'PAIRED_REFERENCE_TRANSFER_ONLY_NOT_INTRINSIC_FACE_OR_BIOMETRIC_IDENTITY'}
    if not ref and not out:
        return dict(result, status='NO_FACE_PAIR_OBSERVED_NOT_ABSENCE')
    if len(ref) != len(out):
        return dict(result, status='UNMATCHED_FACE_POPULATION')
    if len(ref) > 4:
        return dict(result, status='FACE_MATCHING_CAPACITY_EXCEEDED_NOT_SUBSAMPLED')
    assignments = sorted((sum(float(np.mean(np.sum((ref[i]['points']-out[j]['points'])**2, axis=1)))
        for i, j in enumerate(p)), p) for p in itertools.permutations(range(len(out))))
    best, order = assignments[0]
    margin = assignments[1][0] - best if len(assignments) > 1 else None
    if margin is not None and margin <= np.spacing(max(1., abs(best))) * 8:
        return dict(result, status='AMBIGUOUS_FACE_CORRESPONDENCE', assignment_margin_px2=margin)
    for i, j in enumerate(order):
        a, b = ref[i]['points'], out[j]['points']
        x, y, w, h = ref[i]['box']
        original = [int(np.floor(x)), int(np.floor(y)), int(np.ceil(x+w)), int(np.ceil(y+h))]
        bounds = [max(0, original[0]), max(0, original[1]), min(width, original[2]), min(height, original[3])]
        left, top, right, bottom = bounds
        support = measure_face_region_support(original, layout=layout)
        point_visibility = [layout_landmark_visibility(points, layout) for points in (a, b)]
        support_indices = []
        for visible in point_visibility:
            censored_by_text = {i for region in visible['text_bound_regions']
                                for i in region['potentially_occluded_indices']}
            support_indices.append([i for i, (inside, transmission) in enumerate(zip(
                visible['inside_frame'], visible['declared_source_transmission']))
                if inside and transmission == 1 and i not in censored_by_text])
        appearance = None
        if right-left >= 16 and bottom-top >= 16:
            appearance = spatial_measurements(frames[0][top:bottom,left:right], frames[1][top:bottom,left:right])
        result['matches'].append({'reference_face': i, 'candidate_face': j,
            'shape': landmark_shape_error(a, b),
            'absolute_position_rms_px': float(np.sqrt(np.mean(np.sum((a-b)**2, axis=1)))),
            'reference_landmarks_xy': a.tolist(), 'candidate_landmarks_xy': b.tolist(),
            'reference_visibility': point_visibility[0],
            'candidate_visibility': point_visibility[1],
            'fixed_reference_region_support': support,
            'landmark_indices_unmodified_by_declared_layout': {
                'reference': support_indices[0], 'candidate': support_indices[1]},
            'all_landmarks_supported_by_declared_layout': all(len(indices) == 5 for indices in support_indices),
            'geometry_and_appearance_are_diagnostic_only': True,
            'intrinsic_visibility_reference_available': False,
            'reference_roi_xyxy': original, 'observed_roi_xyxy': bounds,
            'roi_censored_by_frame': original != bounds, 'appearance': appearance,
            'appearance_is_identity_proof': False})
    return dict(result, status='FACE_TRANSFER_MEASURED_NOT_IDENTITY_APPROVAL', assignment_margin_px2=margin)


def measure_face_region_membership(rgb: np.ndarray, face_observation: dict,
        region_observation: dict, labels: np.ndarray, *, layout: dict | None = None) -> dict:
    """Bind independent FaceOcc regions to every authenticated YuNet point.

    A model's foreground is an observation, not landmark visibility ground
    truth. No region/point can calibrate its own correctness. Published masks
    are evaluated separately; neither they nor point coordinates prompt FaceOcc.
    The enclosing file reader must authenticate receipt bytes against its
    external anchor. This array consumer validates the pixel/geometry binding.
    """
    import json
    import re
    from .phase6_visual_anatomy import FACE_OCC_VERSION, FACE_OCC_MODEL, preprocess_faceocc
    pixels = np.array(_image(rgb), copy=True, order='C')
    mask = np.array(labels, copy=True, order='C')
    h, w = pixels.shape[:2]
    empty_layout = {'canvas': {'width': w, 'height': h}, 'decorations': [], 'overlays': []}
    geometry = compare_face_geometry(face_observation, face_observation, pixels, pixels,
                                     layout=empty_layout)
    if geometry['reference_face_count'] and not geometry['matches']:
        raise VisualMeasurementUnavailable('complete unambiguous face geometry required for region membership')
    _, plan = preprocess_faceocc(pixels, spatial_contract=region_observation.get('plan', {}).get('spatial_contract'))
    if (region_observation.get('version') != FACE_OCC_VERSION
            or region_observation.get('status') != 'SEMANTIC_FACE_REGION_OBSERVED_NOT_QUALIFIED'
            or region_observation.get('model_sha256') != 'sha256:'+FACE_OCC_MODEL[2]
            or region_observation.get('runtime') != 'torch-2.8.0+cpu-fp32-one-thread'
            or region_observation.get('plan') != plan
            or region_observation.get('input_rgb_sha256') != 'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest()
            or region_observation.get('foreground_rule') != 'logit_strictly_greater_than_zero'
            or region_observation.get('semantic_scope') != 'FaceOcc visible facial attributes excluding occluders; not identity/anatomy'
            or type(region_observation.get('model_invocations')) is not int or region_observation['model_invocations'] != 1
            or any(region_observation.get(key) is not False for key in
                ('detector_or_reference_prompts', 'complete_visibility_proved', 'project_domain_calibrated',
                 'quality_authorized', 'render_authorized', 'publication_authorized'))
            or mask.dtype != np.uint8 or mask.shape != (h, w) or not np.isin(mask, [0, 1]).all()
            or region_observation.get('mask_sha256') != 'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest()
            or type(region_observation.get('foreground_pixels')) is not int
            or region_observation['foreground_pixels'] != int(mask.sum())
            or not re.fullmatch(r'sha256:[0-9a-f]{64}', str(region_observation.get('native_logits_sha256')))):
        raise PermissionError('face region pixels, model, plan, mask or authority differs')
    conditioning, observed = (None, mask)
    if layout is not None:
        conditioning, observed = measure_layout_conditioned_mask(mask, layout)
    counts = {key: 0 for key in ('MODEL_FOREGROUND', 'MODEL_BACKGROUND', 'UNKNOWN_RASTER_SUPPORT', 'OUTSIDE_FRAME_UNKNOWN')}
    rows = []
    for match in geometry['matches']:
        for index, point in enumerate(match['reference_landmarks_xy']):
            xy = np.asarray(point, np.float64)
            low, high = np.floor(xy).astype(int), np.ceil(xy).astype(int)
            positions, original_labels, supported_labels = [], [], []
            inside = (low >= 0).all() and high[0] < w and high[1] < h
            status = 'OUTSIDE_FRAME_UNKNOWN'
            if inside:
                positions = sorted({(int(x), int(y)) for x in (low[0], high[0]) for y in (low[1], high[1])})
                original_labels = sorted({int(mask[y, x]) for x, y in positions})
                supported_labels = sorted({int(observed[y, x]) for x, y in positions})
                status = ('UNKNOWN_RASTER_SUPPORT' if len(supported_labels) != 1 or 2 in supported_labels
                          else 'MODEL_FOREGROUND' if supported_labels == [1] else 'MODEL_BACKGROUND')
            counts[status] += 1
            rows.append({'face_index': match['reference_face'], 'landmark_index': index,
                'xy_pixels': point, 'sample_support_xy': [list(p) for p in positions],
                'original_mask_labels': original_labels, 'conditioned_mask_labels': supported_labels,
                'status': status, 'landmark_visibility_proved': False})
    return {'version': 'phase6-face-region-landmark-membership-v1',
        'status': 'MODEL_REGION_MEMBERSHIP_MEASURED_NOT_VISIBILITY' if rows else 'NO_LANDMARKS_OBSERVED_NOT_ABSENCE',
        'frame_rgb_sha256': face_observation['decoded_rgb_sha256'],
        'face_observation_sha256': 'sha256:'+hashlib.sha256(json.dumps(face_observation, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode()).hexdigest(),
        'region_mask_sha256': region_observation['mask_sha256'],
        'region_model_sha256': region_observation['model_sha256'],
        'declared_layout_conditioning': conditioning, 'face_count': geometry['reference_face_count'],
        'requested_points': geometry['reference_face_count']*5, 'rows': rows, 'counts': counts,
        'sampling_rule': 'ALL_FLOOR_CEIL_LABELS_MUST_AGREE; UNKNOWN_IS_NOT_BACKGROUND',
        'independent_reference_used_as_prompt': False, 'tolerance': None,
        'identity_proved': False, 'landmark_visibility_proved': False,
        'zero_detections_proves_absence': False, 'quality_authorized': False,
        'render_authorized': False, 'publication_authorized': False}


def observe_labeled_face_presence(root: Path, *, metadata_receipt_path: Path,
                                 expected_metadata_sha256: str, image_id: str,
                                 image_path: Path, expected_image_sha256: str,
                                 point_metadata_receipt_path: Path | None = None,
                                 expected_point_metadata_sha256: str | None = None) -> dict:
    """Independent published presence label -> exact original -> real observer.

    Reuses the existing Open Images acquisition, without downloading or editing
    annotations. Overlapping boxes remain separate rows, not alleged people.
    A binary presence control cannot qualify count, identity or domain recall;
    a previously inspected image is never relabelled as an unseen holdout.
    """
    import base64
    import csv
    import io
    import json
    import re
    from .phase6_quality import _resolve
    root = root.resolve()
    saved = {}

    def read(path, anchor, limit):
        path = _resolve(root, str(path))
        if not isinstance(anchor, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', anchor):
            raise PermissionError('independent face reference needs external SHA256 anchors')
        if path.stat().st_size > limit:
            raise PermissionError('independent face reference exceeds bounded input')
        with path.open('rb') as stream:
            raw = stream.read(limit+1)
        if len(raw) > limit or 'sha256:'+hashlib.sha256(raw).hexdigest() != anchor:
            raise PermissionError('independent face reference bytes differ')
        saved[path] = raw
        return path, raw

    if not isinstance(image_id, str) or not re.fullmatch(r'[0-9a-f]{16}', image_id):
        raise ValueError('exact published image ID required')
    if (point_metadata_receipt_path is None) != (expected_point_metadata_sha256 is None):
        raise PermissionError('point reference requires both receipt and external anchor')
    receipt_path, raw = read(metadata_receipt_path, expected_metadata_sha256, 65536)
    receipt = json.loads(raw)
    if (receipt.get('status') != 'METADATA_ACQUIRED_NOT_CALIBRATION'
            or any(receipt.get(k) is not False for k in ('calibrated', 'production_authority', 'corpus_selected', 'all_images_licensed'))
            or receipt.get('scope', {}).get('version') != 'openimages-metadata-acquisition-v1'):
        raise PermissionError('independent metadata receipt scope differs')
    records = receipt['results']
    names = {'classes.csv', 'images.csv', 'boxes.csv', 'human-labels.csv'}
    if len(records) != 4 or {r.get('name') for r in records} != names:
        raise PermissionError('independent metadata population differs')
    files = {}
    for row in records:
        if type(row.get('bytes')) is not int or not 0 < row['bytes'] <= 32*1024*1024 or row.get('http_status') != 200:
            raise PermissionError('metadata size/status differs')
        _, content = read(receipt_path.parent/row['name'], 'sha256:'+row['sha256'], row['bytes'])
        if len(content) != row['bytes']:
            raise PermissionError('metadata byte count differs')
        files[row['name']] = content
    face_class = '/m/0dzct'
    classes = [row for row in csv.reader(io.StringIO(files['classes.csv'].decode('utf-8-sig'))) if row[0] == face_class]
    if classes != [[face_class, 'Human face']]:
        raise PermissionError('published face ontology differs')

    def rows(name):
        return csv.DictReader(io.StringIO(files[name].decode('utf-8-sig'), newline=''))

    metadata = [r for r in rows('images.csv') if r['ImageID'] == image_id]
    labels = [r for r in rows('human-labels.csv') if r['ImageID'] == image_id and r['LabelName'] == face_class]
    boxes = [r for r in rows('boxes.csv') if r['ImageID'] == image_id and r['LabelName'] == face_class]
    if len(metadata) != 1 or not labels:
        raise PermissionError('missing/ambiguous image or explicit human presence label')
    if (any(r['Source'] != 'verification' or r['Confidence'] not in ('0', '1') for r in labels)
            or len({r['Confidence'] for r in labels}) != 1):
        raise PermissionError('conflicting or non-human presence labels')
    expected_presence = labels[0]['Confidence'] == '1'
    if not expected_presence and boxes:
        raise PermissionError('negative presence conflicts with face box annotations')
    # Preserve all boxes/flags, including overlap/occlusion. This path does not
    # use their count as an oracle and does not silently repair any coordinate.
    for box in boxes:
        if box['Source'] != 'xclick' or box['Confidence'] != '1':
            raise PermissionError('unsupported annotation source')
        coordinates = np.asarray([box[k] for k in ('XMin', 'XMax', 'YMin', 'YMax')], np.float64)
        if (not np.isfinite(coordinates).all() or (coordinates < 0).any() or (coordinates > 1).any()
                or coordinates[0] >= coordinates[1] or coordinates[2] >= coordinates[3]
                or any(box[k] not in ('-1', '0', '1') for k in ('IsOccluded', 'IsTruncated', 'IsGroupOf', 'IsDepiction', 'IsInside'))):
            raise PermissionError('face annotation geometry/flags invalid')
    meta = metadata[0]
    if meta['Subset'] not in ('validation', 'test') or meta['Rotation'] not in ('', '0', '0.0'):
        raise PermissionError('unqualified subset/rotation cannot enter this reference control')
    path, image_raw = read(image_path, expected_image_sha256, 64*1024*1024)
    if (str(len(image_raw)) != meta['OriginalSize']
            or hashlib.md5(image_raw).digest() != base64.b64decode(meta['OriginalMD5'], validate=True)):
        raise PermissionError('image differs from independent published original digest')
    with Image.open(io.BytesIO(image_raw)) as image:
        if image.width * image.height * 3 > 67108864:
            raise VisualMeasurementUnavailable('reference decoded RGB exceeds existing capacity bound')
        rgb = np.asarray(image.convert('RGB'))
    point_reference = None
    if point_metadata_receipt_path is not None:
        # Optional, explicitly versioned extension. Old presence receipts keep
        # their original semantics. Sparse semantic points are neither a face
        # segmentation mask nor a truth label for the detector's five points.
        pp, pr = read(point_metadata_receipt_path, expected_point_metadata_sha256, 65536)
        point_receipt = json.loads(pr)
        if (point_receipt.get('url') != 'https://storage.googleapis.com/openimages/v7/oidv7-val-annotations-point-labels.csv'
                or point_receipt.get('http_status') != 200
                or point_receipt.get('scope') != 'METADATA_ONLY_NOT_CALIBRATION'
                or type(point_receipt.get('bytes')) is not int
                or not 0 < point_receipt['bytes'] <= 96*1024*1024
                or meta['Subset'] != 'validation'):
            raise PermissionError('point metadata source, subset or scope differs')
        point_path, point_raw = read(point_receipt['path'], point_receipt['sha256'], point_receipt['bytes'])
        if (len(point_raw) != point_receipt['bytes']
                or hashlib.md5(point_raw).digest() != base64.b64decode(point_receipt['published_md5'], validate=True)):
            raise PermissionError('point metadata differs from published body checksum')
        reader = csv.DictReader(io.StringIO(point_raw.decode('utf-8-sig'), newline=''))
        fields = ['ImageId','X','Y','Label','EstimatedYesNo','Source','YesVotes','NoVotes','UnsureVotes','TextLabel']
        if reader.fieldnames != fields:
            raise PermissionError('published point columns differ')
        points, seen = [], {}
        for row in reader:
            if row.get('ImageId') != image_id or row.get('Label') != face_class:
                continue
            if (set(row) != set(fields) or None in row.values()
                    or row['Source'] not in ('ih','cs') or row['TextLabel'] != ''
                    or row['EstimatedYesNo'] not in ('yes','no','unsure')):
                raise PermissionError('point is not an explicit canonical human face verification')
            coordinates = np.asarray([row['X'],row['Y']], np.float64)
            if not np.isfinite(coordinates).all() or (coordinates < 0).any() or (coordinates > 1).any():
                raise PermissionError('point reference coordinates invalid')
            vote_fields = ('YesVotes','NoVotes','UnsureVotes')
            if any(not re.fullmatch(r'0|[1-9][0-9]*', row[k]) for k in vote_fields):
                raise PermissionError('point reference votes invalid')
            votes = [int(row[k]) for k in vote_fields]
            if (sum(votes) == 0 or row['EstimatedYesNo'] == 'yes' and votes[0] == 0
                    or row['EstimatedYesNo'] == 'no' and votes[1] == 0):
                raise PermissionError('point estimate has no supporting votes')
            key = tuple(coordinates.tolist())
            if key in seen:
                raise PermissionError('duplicate or conflicting point reference coordinate')
            seen[key] = row['EstimatedYesNo']
            # Official normalized endpoints refer to first and last pixels,
            # not an enclosing width/height edge. Do not round to fake labels
            # for neighbouring pixels or extrapolate a dense visible region.
            points.append({'csv_line':reader.line_num, 'annotation':row,
                'xy_normalized':coordinates.tolist(),
                'xy_pixels':(coordinates*np.array([rgb.shape[1]-1,rgb.shape[0]-1])).tolist(),
                'face_membership':{'yes':True,'no':False,'unsure':None}[row['EstimatedYesNo']],
                'votes':dict(zip(vote_fields,votes))})
        if not points:
            raise PermissionError('no explicit face point references for this image; absence is unknown')
        point_reference = {'version':'phase6-published-sparse-face-points-v1',
            'receipt':{'path':pp.relative_to(root).as_posix(),'sha256':expected_point_metadata_sha256},
            'source':{'path':point_path.relative_to(root).as_posix(),'sha256':point_receipt['sha256']},
            'points':points, 'counts':{label:sum(p['annotation']['EstimatedYesNo']==label for p in points)
                                     for label in ('yes','no','unsure')},
            'reference_scope':'INDEPENDENT_HUMAN_SEMANTIC_POINTS_NOT_DENSE_VISIBILITY',
            'model_training_overlap':'UNKNOWN', 'dense_visibility_proved':False,
            'landmark_visibility_proved':False, 'identity_proved':False, 'quality_authorized':False}
    observer = FaceObserver(root)
    observed = observer.observe(rgb)
    if any(p.read_bytes() != data for p, data in saved.items()):
        raise PermissionError('independent reference changed during observation')
    matched = bool(observed['face_count']) == expected_presence
    result = {'version': 'phase6-published-face-presence-reference-v1',
        'status': 'MATCHED_DEVELOPMENT_PRESENCE_CONTROL_ONLY' if matched else 'FAILED_DEVELOPMENT_PRESENCE_CONTROL',
        'image_id': image_id, 'reference_label': expected_presence, 'observed_presence': bool(observed['face_count']),
        'matched': matched, 'presence_label_source': 'PUBLISHED_HUMAN_IMAGE_VERIFICATION',
        'label_rows': labels, 'box_annotation_rows': boxes, 'box_row_count_is_face_count': False,
        'reference_role': 'DEVELOPMENT_REFERENCE_NOT_UNSEEN_HOLDOUT', 'observation': observed,
        'metadata_receipt': {'path': receipt_path.relative_to(root).as_posix(), 'sha256': expected_metadata_sha256},
        'image': {'path': path.relative_to(root).as_posix(), 'sha256': expected_image_sha256,
                  'size_bytes': len(image_raw), 'published_original_md5': meta['OriginalMD5']},
        'evidence_bindings': [{'path': p.relative_to(root).as_posix(), 'sha256':'sha256:'+hashlib.sha256(data).hexdigest()}
                              for p, data in saved.items()],
        'model': {'path': observer.path.relative_to(root).as_posix(),
                  'sha256':'sha256:'+hashlib.sha256(observer.data).hexdigest()},
        'new_downloads': 0, 'new_human_annotations': 0, 'inferences': 1,
        'identity_proved': False, 'count_reference_qualified': False, 'detector_domain_calibrated': False,
        'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}
    if point_reference is not None:
        result['version'] = 'phase6-published-face-presence-reference-v2'
        result['point_reference'] = point_reference
    return result


def _model_bytes(root: Path, key: str) -> bytes:
    name, size, digest = MODEL_BINDINGS[key]
    path = (root / MODEL_DIRECTORY / name).resolve()
    if root.resolve() not in path.parents:
        raise PermissionError("hand model escaped project root")
    value = path.read_bytes()
    if len(value) != size or hashlib.sha256(value).hexdigest() != digest:
        raise PermissionError("hand model differs from published LFS anchor: " + key)
    return value


def palm_anchors() -> np.ndarray:
    """2016 fixed SSD centres: stride 8/two, stride 16/six per cell."""
    return np.array([[(x + .5) / cells, (y + .5) / cells]
                     for cells, repeats in ((24, 2), (12, 6))
                     for y in range(cells) for x in range(cells) for _ in range(repeats)], dtype=np.float32)


def _image(value):
    frame = np.asarray(value)
    if frame.dtype != np.uint8 or frame.ndim != 3 or frame.shape[2] != 3 or min(frame.shape[:2]) < 16:
        raise VisualMeasurementUnavailable("RGB uint8 image at least 16x16 required")
    return frame


def _crop_square(image, box, *, shift, enlarge, rotation_padding):
    box = np.asarray(box, dtype=np.float64).reshape(2, 2)
    size = box[1] - box[0]
    if not np.isfinite(box).all() or (size <= 0).any():
        raise VisualMeasurementUnavailable("invalid hand crop geometry")
    centre = box.mean(axis=0) + np.asarray(shift) * size
    bounds = np.array([centre - size * enlarge / 2, centre + size * enlarge / 2]).astype(np.int32)
    bounds[:, 0] = np.clip(bounds[:, 0], 0, image.shape[1])
    bounds[:, 1] = np.clip(bounds[:, 1], 0, image.shape[0])
    cropped = image[bounds[0, 1]:bounds[1, 1], bounds[0, 0]:bounds[1, 0]]
    if min(cropped.shape[:2]) == 0:
        raise VisualMeasurementUnavailable("hand crop outside observed frame")
    side = int(np.linalg.norm(cropped.shape[:2])) if rotation_padding else max(cropped.shape[:2])
    horizontal, vertical = side - cropped.shape[1], side - cropped.shape[0]
    left, top = horizontal // 2, vertical // 2
    padded = cv2.copyMakeBorder(cropped, top, vertical - top, left, horizontal - left, cv2.BORDER_CONSTANT, value=(0, 0, 0))
    return padded, bounds, bounds[0] - [left, top]


class HandObserver:
    """Private serial model instance; no network, cache, caller PASS or queue."""

    def __init__(self, root: Path):
        self.root = root.resolve()
        self.models = {}
        for key in MODEL_BINDINGS:
            data = _model_bytes(self.root, key)
            model = cv2.dnn.readNetFromONNX(np.frombuffer(data, np.uint8))
            model.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            model.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            self.models[key] = model
        self.anchors = palm_anchors()

    def _palms(self, rgb):
        height, width = rgb.shape[:2]
        ratio = 192 / max(height, width)
        resized_h, resized_w = (np.array([height, width]) * ratio).astype(np.int32)
        left, top = (192 - resized_w) // 2, (192 - resized_h) // 2
        resized = cv2.resize(rgb, (resized_w, resized_h))
        padded = cv2.copyMakeBorder(resized, top, 192 - resized_h - top, left, 192 - resized_w - left, cv2.BORDER_CONSTANT, value=(0, 0, 0))
        model = self.models["palm"]
        model.setInput(padded[np.newaxis].astype(np.float32) / 255)
        regression, logits = model.forward(model.getUnconnectedOutLayersNames())
        if regression.shape != (1, 2016, 18) or logits.shape != (1, 2016, 1) or not np.isfinite(regression).all() or not np.isfinite(logits).all():
            raise VisualMeasurementUnavailable("palm model output contract mismatch")
        # Numerically stable sigmoid; clipping avoids overflow, not acceptance.
        scores = 1 / (1 + np.exp(-np.clip(logits[0, :, 0].astype(np.float64), -700, 700)))
        centres = regression[0, :, :2] / 192 + self.anchors
        spans = regression[0, :, 2:4] / 192
        bias = np.asarray([left, top]) / ratio
        corners = (centres - spans / 2) * max(height, width) - bias
        lengths = spans * max(height, width)
        xywh = np.c_[corners, lengths]
        eligible = np.flatnonzero((scores >= PALM_CONFIDENCE) & (lengths > 0).all(axis=1))
        if not len(eligible):
            return []
        kept = cv2.dnn.NMSBoxes(xywh[eligible].tolist(), scores[eligible].tolist(), PALM_CONFIDENCE, PALM_NMS_IOU, top_k=5000)
        results = []
        for index in eligible[np.asarray(kept).ravel()]:
            points = (regression[0, index, 4:].reshape(7, 2) / 192 + self.anchors[index]) * max(height, width) - bias
            results.append({"box": np.array([corners[index], corners[index] + lengths[index]]), "points": points, "score": float(scores[index])})
        return results

    def _pose(self, rgb, palm):
        image, box, bias = _crop_square(rgb, palm["box"], shift=(0, 0), enlarge=4, rotation_padding=True)
        box = box - bias
        points = palm["points"] - bias
        delta = points[2] - points[0]
        if np.linalg.norm(delta) == 0:
            raise VisualMeasurementUnavailable("palm orientation is degenerate")
        radians = np.pi / 2 - np.arctan2(-delta[1], delta[0])
        radians -= 2 * np.pi * np.floor((radians + np.pi) / (2 * np.pi))
        angle = float(np.rad2deg(radians))
        rotation = cv2.getRotationMatrix2D(tuple(box.mean(axis=0)), angle, 1)
        rotated = cv2.warpAffine(image, rotation, (image.shape[1], image.shape[0]))
        rotated_points = np.c_[points, np.ones(7)] @ rotation.T
        tight = np.array([rotated_points.min(axis=0), rotated_points.max(axis=0)])
        crop, crop_box, _ = _crop_square(rotated, tight, shift=(0, -.4), enlarge=3, rotation_padding=False)
        blob = cv2.resize(crop, (224, 224), interpolation=cv2.INTER_AREA)[np.newaxis].astype(np.float32) / 255
        model = self.models["pose"]
        model.setInput(blob)
        outputs = model.forward(model.getUnconnectedOutLayersNames())
        if len(outputs) != 4 or tuple(item.size for item in outputs) != (63, 1, 1, 63) or any(not np.isfinite(item).all() for item in outputs):
            raise VisualMeasurementUnavailable("hand pose model output contract mismatch")
        landmarks, confidence, handedness, world = outputs
        score, side = float(confidence.ravel()[0]), float(handedness.ravel()[0])
        if not 0 <= score <= 1 or not 0 <= side <= 1:
            raise VisualMeasurementUnavailable("hand pose score outside probability domain")
        if score < POSE_CONFIDENCE:
            return {"status": "POSE_UNCERTAIN", "confidence": score, "quality_authorized": False}
        points = landmarks.reshape(21, 3).astype(np.float64).copy()
        scale = max((crop_box[1] - crop_box[0]) / 224)
        points[:, :2] = (points[:, :2] - 112) * scale
        points[:, 2] *= scale
        unrotate = cv2.getRotationMatrix2D((0, 0), angle, 1)[:, :2]
        inverse = cv2.invertAffineTransform(rotation)
        centre = np.r_[crop_box.mean(axis=0), 1] @ inverse.T
        points[:, :2] = points[:, :2] @ unrotate + centre + bias
        world_points = world.reshape(21, 3).astype(np.float64).copy()
        world_points[:, :2] = world_points[:, :2] @ unrotate
        return {"status": "LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL", "confidence": score, "handedness_right_probability": side,
                "screen_landmarks_xyz": points.tolist(), "estimated_world_landmarks_xyz": world_points.tolist(),
                "palm_confidence": palm["score"], "quality_authorized": False,
                "limitation": "Fixed 21-point model does not count visible fingers, establish anatomy or prove metric depth."}

    def observe(self, rgb):
        rgb = _image(rgb)
        started = time.monotonic()
        palms = self._palms(rgb)
        if len(palms) > 64:
            raise VisualMeasurementUnavailable("bounded hand workload exceeded; do not discard palms to claim coverage")
        observations = []
        for palm in palms:
            if time.monotonic() - started > 30:
                raise TimeoutError("hand observation deadline exceeded")
            observations.append(self._pose(rgb, palm))
        return {"version": VERSION, "status": "OBSERVATION_ONLY", "palms_detected": len(palms), "hands": observations,
                "zero_detections_proves_absence": False, "quality_authorized": False, "elapsed_seconds": time.monotonic() - started}


def observe_hand_frame(root: Path, frame_path: str | Path, *, expected_sha256: str) -> dict:
    """File-bound entry for the visual evaluator, preserving unknown/no detection."""
    root = root.resolve()
    frame = Path(frame_path)
    frame = (frame if frame.is_absolute() else root / frame).resolve()
    if root not in frame.parents:
        raise PermissionError("hand frame escaped project root")
    raw = frame.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("hand frame identity mismatch")
    import io
    with Image.open(io.BytesIO(raw)) as image:
        rgb = np.asarray(image.convert("RGB"))
    observation = HandObserver(root).observe(rgb)
    for key in MODEL_BINDINGS:
        _model_bytes(root, key)
    if frame.read_bytes() != raw:
        raise PermissionError("hand frame changed during observation")
    observation["input"] = {"path": str(frame.relative_to(root).as_posix()), "sha256": expected_sha256,
                            "decoded_rgb_sha256": "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest()}
    observation["models"] = {key: {"file": value[0], "size_bytes": value[1], "sha256": "sha256:" + value[2]} for key, value in MODEL_BINDINGS.items()}
    return observation


def extract_pose_seeded_hand_mask(rgb: np.ndarray, observation: dict) -> tuple[dict, np.ndarray]:
    """Automatic segmentation proposal from pixels and existing pose estimates.

    All seeds are *probable*, never hard truth or a fixed 21-point silhouette.
    Foreground may grow outside the hull or shrink inside it. Five GrabCut
    iterations follow the OpenCV example; this is an estimator setting, not a
    quality threshold. No skin-colour range, manual annotation, download or
    detector retry is used. Missing/uncertain poses fail rather than disappear.

    OpenCV RNG is thread-local: a short-lived, joined, single native worker
    gives reproducibility without changing the caller's RNG or thread settings.
    The caller waits; there is no second workflow or background continuation.
    """
    from concurrent.futures import ThreadPoolExecutor
    from .phase6_visual_metrics import visible_mask_geometry

    pixels = _image(rgb)
    h, w = pixels.shape[:2]
    if h*w > 2_097_152:
        raise VisualMeasurementUnavailable('mask proposal exceeds native graph workload; no implicit resize')
    if (not isinstance(observation, dict) or observation.get('version') != VERSION
            or observation.get('status') != 'OBSERVATION_ONLY' or observation.get('quality_authorized') is not False):
        raise VisualMeasurementUnavailable('unapproved typed pose observation required')
    hands = observation.get('hands')
    if (not isinstance(hands, list) or not 1 <= len(hands) <= 4
            or type(observation.get('palms_detected')) is not int
            or observation['palms_detected'] != len(hands)):
        raise VisualMeasurementUnavailable('one to four complete pose rows required; no absent-hand PASS')
    seeds = np.full((h, w), cv2.GC_PR_BGD, np.uint8)
    provenance = []
    for hand in hands:
        if not isinstance(hand, dict):
            raise VisualMeasurementUnavailable('invalid pose row')
        confidence = hand.get('confidence')
        if (hand.get('status') != 'LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL'
                or hand.get('quality_authorized') is not False
                or type(confidence) not in (float, int) or not np.isfinite(confidence)
                or not POSE_CONFIDENCE <= confidence <= 1):
            raise VisualMeasurementUnavailable('uncertain pose cannot seed segmentation')
        points = np.asarray(hand.get('screen_landmarks_xyz'), dtype=np.float64)
        if points.shape != (21, 3) or not np.isfinite(points).all():
            raise VisualMeasurementUnavailable('finite 21-point pose population required')
        xy = points[:, :2]
        if (np.abs(xy) > 4*max(h, w)).any():
            raise VisualMeasurementUnavailable('pose outside bounded image coordinate domain')
        inside = ((xy >= [0, 0]) & (xy < [w, h])).all(axis=1)
        if inside.sum() < 3 or np.linalg.matrix_rank(xy[inside]-xy[inside].mean(axis=0)) < 2:
            raise VisualMeasurementUnavailable('pose has no observable planar seed support')
        hull = cv2.convexHull(np.rint(xy).astype(np.int32))
        cv2.fillConvexPoly(seeds, hull, cv2.GC_PR_FGD)
        provenance.append({'confidence':float(confidence),'hull_xy':hull[:,0,:].tolist(),
                           'out_of_frame_indices':np.flatnonzero(~inside).astype(int).tolist()})
    seed_foreground = int(np.count_nonzero(seeds == cv2.GC_PR_FGD))
    # The native GMM has five components per class. This is an instrument
    # precondition, not permission to accept a tiny/missing hand as adequate.
    if min(seed_foreground, h*w-seed_foreground) < 5:
        raise VisualMeasurementUnavailable('both foreground/background need native GMM support')
    seed_digest = 'sha256:'+hashlib.sha256(seeds.tobytes()).hexdigest()
    started = time.monotonic()
    def native():
        cv2.setRNGSeed(0)
        labels = seeds.copy()
        cv2.grabCut(cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR), labels, None,
                    np.zeros((1,65),np.float64), np.zeros((1,65),np.float64), 5, cv2.GC_INIT_WITH_MASK)
        return labels
    with ThreadPoolExecutor(max_workers=1, thread_name_prefix='hero-mask-native') as worker:
        flags = worker.submit(native).result()
    if flags.shape != (h,w) or not np.isin(flags,[cv2.GC_PR_BGD,cv2.GC_PR_FGD]).all():
        raise VisualMeasurementUnavailable('native proposal violated probable-only seed contract')
    mask = (flags == cv2.GC_PR_FGD).astype(np.uint8)
    area = int(mask.sum())
    result = {'version':'phase6-pose-seeded-visible-mask-v1',
              'status':'MASK_PROPOSAL_NOT_QUALIFIED' if 0 < area < h*w else 'DEGENERATE_MASK_PROPOSAL',
              'algorithm':'OpenCV GrabCut probable-mask initialization', 'iterations':5, 'rng_seed':0,
              'elapsed_seconds':time.monotonic()-started, 'size_wh':[w,h],
              'decoded_rgb_sha256':'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest(),
              'pose_observation_sha256':None, 'pose_seeds':provenance,
              'seed_mask_sha256':seed_digest, 'probable_foreground_seed_px':seed_foreground,
              'foreground_outside_seed_px':int(np.count_nonzero((mask == 1) & (seeds == cv2.GC_PR_BGD))),
              'background_inside_seed_px':int(np.count_nonzero((mask == 0) & (seeds == cv2.GC_PR_FGD))),
              'proposal_geometry':visible_mask_geometry(mask),
              'opencv_version':cv2.__version__, 'new_detector_inferences':0,
              'semantic_labels_verified':False,'complete_hand_coverage_proved':False,
              'quality_authorized':False,'render_authorized':False,'publication_authorized':False,
              'scope':'AUTOMATIC_PIXEL_SEGMENTATION_PROPOSAL_NOT_GOLD_OR_INTRINSIC_ANATOMY'}
    return result, mask


def measure_layout_conditioned_mask(labels: np.ndarray, layout: dict) -> tuple[dict, np.ndarray]:
    """Preserve a proposal and expose its unobservable composition support.

    Reuse the renderer-layout visibility instrument; do not tune the segmenter,
    turn a decoration into anatomy, or call the remaining foreground correct.
    Label 2 means unknown underlying object, including conservative text bounds.
    The original positive claims inside opaque graphics remain counterevidence.
    This covers declared overlays, not codec leakage, fades or intrinsic anatomy.
    """
    from .phase6_visual_metrics import layout_landmark_visibility, visible_mask_geometry
    original = visible_mask_geometry(labels)  # existing typed 0/1/2 contract
    mask = np.asarray(labels)
    h, w = mask.shape
    if layout.get('canvas') != {'width': w, 'height': h}:
        raise VisualMeasurementUnavailable('mask/layout canvas differs')
    conditioned = mask.copy()
    counts = dict(opaque_pixels=0, translucent_pixels=0, potential_text_pixels=0,
                  original_foreground_in_opaque=0, newly_unobserved_pixels=0)
    for top in range(0, h, 32):
        bottom = min(h, top+32)
        yy, xx = np.mgrid[top:bottom, :w]
        points = np.column_stack((xx.ravel(), yy.ravel()))
        visibility = layout_landmark_visibility(points, layout)
        transmission = np.asarray(visibility['declared_source_transmission'], np.float64)
        opaque = transmission == 0
        translucent = (transmission > 0) & (transmission < 1)
        text = np.zeros(len(points), bool)
        for region in visibility['text_bound_regions']:
            text[region['potentially_occluded_indices']] = True
        unknown = opaque | translucent | text
        old = mask[top:bottom].reshape(-1)
        counts['opaque_pixels'] += int(opaque.sum())
        counts['translucent_pixels'] += int(translucent.sum())
        counts['potential_text_pixels'] += int(text.sum())
        counts['original_foreground_in_opaque'] += int(np.count_nonzero(opaque & (old == 1)))
        counts['newly_unobserved_pixels'] += int(np.count_nonzero(unknown & (old != 2)))
        conditioned[top:bottom].reshape(-1)[unknown] = 2
    result = {'version': 'phase6-declared-overlay-mask-support-v1',
              'scope': 'DECLARED_OVERLAY_SUPPORT_NOT_CORRECTED_SEGMENTATION',
              'layout_sha256': None, 'original_geometry': original,
              'conditioned_geometry': visible_mask_geometry(conditioned), **counts,
              'opaque_foreground_claims_contradicted': counts['original_foreground_in_opaque'] > 0,
              'opaque_claim_tolerance': 0, 'text_bounds_are_ink': False,
              'remaining_foreground_verified': False, 'complete_visibility_proved': False,
              'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}
    import json
    result['layout_sha256'] = 'sha256:'+hashlib.sha256(json.dumps(
        layout, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return result, conditioned


def measure_recorded_hand_visibility(root: Path, *, mask_receipt_path: Path,
                                     expected_mask_receipt_sha256: str,
                                     reference_path: Path, expected_reference_sha256: str,
                                     font: Path) -> tuple[dict, np.ndarray]:
    """Actual reader -> frozen frame/proposal -> canonical layout -> geometry.

    No re-inference, video decode, queue access or evidence write. The caller
    persists the returned *new* observation; the failed proposal stays intact.
    This narrow v1 consumes the recorded GrabCut proposal, not arbitrary labels.
    """
    import io
    import json
    import re
    from fractions import Fraction
    from . import phase6_quality as quality
    from .phase6_visual_recipe import inspect_visual_layout
    from .phase6_visual_metrics import indexed_frame_clock, layout_landmark_visibility

    root = root.resolve()
    saved = {}
    def read(path, anchor, limit=32*1024*1024):
        path = (root/path).resolve()
        if (not path.is_relative_to(root) or not re.fullmatch(r'sha256:[0-9a-f]{64}', str(anchor))
                or not path.is_file() or not 0 < path.stat().st_size <= limit):
            raise PermissionError('visibility requires bounded, confined, anchored input')
        raw = path.read_bytes()
        if len(raw) > limit or 'sha256:'+hashlib.sha256(raw).hexdigest() != anchor:
            raise PermissionError('visibility input hash differs')
        saved[path] = raw
        return raw

    reference = quality.read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    read(reference_path, expected_reference_sha256)
    receipt = json.loads(read(mask_receipt_path, expected_mask_receipt_sha256))
    if (receipt.get('version') != 'phase6-pose-seeded-visible-mask-v1'
            or receipt.get('status') != 'MASK_PROPOSAL_NOT_QUALIFIED'
            or any(receipt.get(key) is not False for key in
                   ('quality_authorized', 'render_authorized', 'publication_authorized', 'semantic_labels_verified'))):
        raise PermissionError('visibility needs the original non-authorizing mask proposal')
    observation = json.loads(read(receipt['pose_observation_path'], receipt['pose_observation_sha256']))
    if (observation.get('version') != VERSION or observation.get('status') != 'OBSERVATION_ONLY'
            or observation.get('quality_authorized') is not False
            or observation.get('reference_id') != reference['reference_id']
            or observation.get('input') != receipt['frame_binding']):
        raise PermissionError('visibility observation/reference binding differs')
    frame = observation['frame_observation']
    index = frame['frame_index']
    expected_pts, tolerance = indexed_frame_clock(index, Fraction(reference['fps']['numerator'], reference['fps']['denominator']))
    if (type(frame.get('verified_seek_frame')) is not int or frame['verified_seek_frame'] != index
            or frame.get('expected_pts_ms') != expected_pts or frame.get('pts_rounding_tolerance_ms') != tolerance
            or type(frame.get('pts_ms')) not in (int, float) or not np.isfinite(frame['pts_ms'])
            or abs(frame['pts_ms']-expected_pts) > tolerance
            or (root/frame['path']).resolve() != (root/receipt['frame_binding']['path']).resolve()
            or any(frame[k] != receipt['frame_binding'][k] for k in ('sha256', 'decoded_rgb_sha256'))):
        raise PermissionError('visibility frame clock or pixels differ')
    takes = [row for row in reference['takes'] if row['target_start_frame'] <= index < row['target_end_frame_exclusive']]
    if len(takes) != 1:
        raise PermissionError('visibility frame has no unique take')
    raw = read(frame['path'], frame['sha256'])
    with Image.open(io.BytesIO(raw)) as image:
        if image.mode != 'RGB' or image.size != (frame['width'], frame['height']) or image.width*image.height > 2_097_152:
            raise PermissionError('visibility native frame format differs')
        pixels = np.asarray(image)
    if 'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest() != frame['decoded_rgb_sha256']:
        raise PermissionError('visibility decoded RGB differs')
    binding = receipt['mask_binding']
    raw = read(binding['path'], binding['sha256'])
    if len(raw) != binding['size_bytes']:
        raise PermissionError('visibility mask size differs')
    with Image.open(io.BytesIO(raw)) as image:
        if image.mode != 'L' or image.format != 'PNG' or image.size != (frame['width'], frame['height']):
            raise PermissionError('visibility label format differs')
        labels = np.asarray(image).copy()
    if (not np.isin(labels, [0, 1]).all() or receipt['size_wh'] != [frame['width'], frame['height']]
            or receipt['proposal_geometry']['mask_sha256'] != 'sha256:'+hashlib.sha256(labels.tobytes()).hexdigest()):
        raise PermissionError('visibility original proposal geometry differs')
    docs = {}
    for binding in reference['intent_bindings']:
        name = Path(binding['path']).stem
        if name in ('take_plan', 'creative_treatment_plan'):
            if name in docs:
                raise PermissionError('visibility intent is ambiguous')
            docs[name] = json.loads(read(binding['path'], binding['sha256']))
    identity = takes[0]['take_id']
    selected = []
    for name in ('take_plan', 'creative_treatment_plan'):
        rows = [row for row in docs[name]['takes'] if row['take_id'] == identity]
        if len(rows) != 1:
            raise PermissionError('visibility plan/treatment take differs')
        selected.append(rows[0])
    code = {}
    for source in (Path(__file__), Path(quality.__file__), Path(inspect_visual_layout.__code__.co_filename),
                   Path(layout_landmark_visibility.__code__.co_filename)):
        source = source.resolve()
        resident = root/'hero_engine'/source.name
        raw = source.read_bytes()
        if resident.read_bytes() != raw:
            raise PermissionError('visibility resident instrument differs from executing source')
        saved[resident] = raw
        code[resident.relative_to(root).as_posix()] = 'sha256:'+hashlib.sha256(raw).hexdigest()
    font = font.resolve()
    font_raw = font.read_bytes()
    layout = inspect_visual_layout(*selected, font=font)
    result, conditioned = measure_layout_conditioned_mask(labels, layout)
    # Reopen all current bindings and the original evidence before returning.
    quality.read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    if any(path.read_bytes() != raw for path, raw in saved.items()) or font.read_bytes() != font_raw:
        raise PermissionError('visibility input changed during measurement')
    result.update(reference={'path':str(reference_path), 'sha256':expected_reference_sha256},
                  mask_receipt={'path':str(mask_receipt_path), 'sha256':expected_mask_receipt_sha256},
                  frame_binding=receipt['frame_binding'], frame_index=index, take_id=identity,
                  font={'path':str(font), 'sha256':'sha256:'+hashlib.sha256(font_raw).hexdigest()},
                  implementation_bindings=code, full_video_coverage=False,
                  new_video_decodes=0, new_model_inferences=0, new_channel_renders=0)
    return result, conditioned


def extract_hand_mask_from_observation(root: Path, observation_path: Path, *,
                                       expected_observation_sha256: str,
                                       method: str = 'grabcut-probable-v1') -> tuple[dict, np.ndarray]:
    """Reopen the exact historical observation/frame; never repeat pose inference.

    Authentication establishes which estimate seeded the proposal, not that its
    landmarks are anatomical ground truth. Original observation stays immutable.
    New mask is returned to the evidence writer, never to the production queue.
    """
    import io
    import json
    import re

    if method not in ('grabcut-probable-v1', 'efficient-sam-tiny-v1', 'efficient-sam-tiny-wrist-v2',
                      'yolo26-hand-semantic-v1', 'yolo26-hand-crops-v1'):
        raise VisualMeasurementUnavailable('unknown mask instrument; no fallback')
    root = root.resolve()
    path = (root / observation_path).resolve()
    if not path.is_relative_to(root) or not re.fullmatch(r'sha256:[0-9a-f]{64}',expected_observation_sha256):
        raise PermissionError('confined observation with exact external anchor required')
    if not path.is_file() or not 1 <= path.stat().st_size <= 2*1024*1024:
        raise PermissionError('observation outside byte workload')
    raw = path.read_bytes()
    if len(raw)>2*1024*1024 or 'sha256:'+hashlib.sha256(raw).hexdigest()!=expected_observation_sha256:
        raise PermissionError('observation identity mismatch')
    observation=json.loads(raw)
    frame_binding=observation.get('input',{})
    declared_path=frame_binding.get('path')
    if not isinstance(declared_path,str):
        raise PermissionError('frame binding missing')
    frame=(root/declared_path).resolve()
    if not frame.is_relative_to(root) or not frame.is_file() or not 1<=frame.stat().st_size<=32*1024*1024:
        raise PermissionError('frame outside confined workload')
    frame_raw=frame.read_bytes()
    if len(frame_raw)>32*1024*1024 or 'sha256:'+hashlib.sha256(frame_raw).hexdigest()!=frame_binding.get('sha256'):
        raise PermissionError('observation frame bytes changed')
    expected_models={key:{'file':v[0],'size_bytes':v[1],'sha256':'sha256:'+v[2]} for key,v in MODEL_BINDINGS.items()}
    if observation.get('models')!=expected_models:
        raise PermissionError('pose model population differs from anchored instrument')
    for key in MODEL_BINDINGS:
        _model_bytes(root,key)
    with Image.open(io.BytesIO(frame_raw)) as image:
        if image.width*image.height>2_097_152 or image.mode!='RGB':
            raise VisualMeasurementUnavailable('bounded native RGB frame required before decode')
        pixels=np.array(image)
    if 'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest()!=frame_binding.get('decoded_rgb_sha256'):
        raise PermissionError('decoded frame differs from observation')
    if method == 'grabcut-probable-v1':
        result,mask=extract_pose_seeded_hand_mask(pixels,observation)
    elif method == 'efficient-sam-tiny-v1':
        result,mask=extract_learned_hand_mask(root,pixels,observation)
    elif method == 'efficient-sam-tiny-wrist-v2':
        result,mask=extract_learned_hand_mask(root,pixels,observation,prompt_contract='wrist-tips-v2')
    else:
        # Pose bytes remain authenticated history, not prompts or a hand-count
        # oracle for this independent semantic detector. No silent fallback.
        if (observation.get('version')!=VERSION or observation.get('status')!='OBSERVATION_ONLY'
                or observation.get('quality_authorized') is not False):
            raise VisualMeasurementUnavailable('typed non-authorizing observation required')
        result,mask=extract_semantic_hand_mask(root,pixels,pose_crops=observation) if method=='yolo26-hand-crops-v1' else extract_semantic_hand_mask(root,pixels)
    for key in MODEL_BINDINGS:
        _model_bytes(root,key)
    if path.read_bytes()!=raw or frame.read_bytes()!=frame_raw:
        raise PermissionError('observation/frame changed during segmentation')
    result.update(pose_observation_sha256=expected_observation_sha256,
                  pose_observation_path=path.relative_to(root).as_posix(),frame_binding=frame_binding,
                  model_bindings=expected_models)
    return result,mask


SEMANTIC_MODEL_DIRECTORY = Path('models/visual-reference/yolo26-hand-semantic-v1')
SEMANTIC_MODEL_BINDING = ('yolo26m-seg-hand.onnx', 94223058,
    'c47fcf7bb66028003ffd828f746d83798f12037882701da5f61be0a90ed91b5f')


def _semantic_hand_model_bytes(root: Path) -> bytes:
    name,size,digest=SEMANTIC_MODEL_BINDING
    path=(root/SEMANTIC_MODEL_DIRECTORY/name).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file() or path.stat().st_size!=size:
        raise PermissionError('semantic model outside pinned population')
    data=path.read_bytes()
    if len(data)!=size or hashlib.sha256(data).hexdigest()!=digest:
        raise PermissionError('semantic model differs from published LFS anchor')
    return data


def _semantic_hand_tensor(rgb: np.ndarray) -> np.ndarray:
    """Exporter's RGB/255 contract; explicit full-frame 224x224 view.

    Upstream Ultralytics 8.4.83 predictor converts its BGR image to RGB.
    Our input already is RGB; the author's standalone BGR omission is NOT
    reproduced. No labels, favourable crops or candidate-dependent channels.
    Resizing is model input only and never changes the preserved source image.
    """
    value=_image(rgb)
    if value.shape[0]*value.shape[1]>2_097_152:
        raise VisualMeasurementUnavailable('semantic frame workload exceeded')
    resized=cv2.resize(value,(224,224),interpolation=cv2.INTER_LINEAR)
    return np.ascontiguousarray((resized.astype(np.float32)/255).transpose(2,0,1)[None])


def _decode_semantic_hand_masks(detections: np.ndarray, prototypes: np.ndarray,
                                shape: tuple[int,int]) -> tuple[np.ndarray,list[dict]]:
    """Versioned prototype-logit projection, no anatomical decision.

    Match the exporter consumer's prototype product, half-open crop and zero
    logit threshold. Upsample logits to its 224 input lattice, then transport
    the discrete mask to the original stretched view by nearest-neighbour.
    The 224 lattice is a limitation, not native-pixel segmentation precision.
    Confidence 0.5 is the author's operating point, NOT a QA threshold.
    """
    if (detections.shape!=(1,300,38) or prototypes.shape!=(1,32,56,56)
            or detections.dtype!=np.float32 or prototypes.dtype!=np.float32
            or not np.isfinite(detections).all() or not np.isfinite(prototypes).all()):
        raise VisualMeasurementUnavailable('semantic output contract mismatch')
    if len(shape)!=2 or any(type(x) is not int or x<16 for x in shape) or shape[0]*shape[1]>2_097_152:
        raise VisualMeasurementUnavailable('semantic output canvas outside workload')
    scores=detections[0,:,4]
    if np.any(scores<0) or np.any(scores>1):
        raise VisualMeasurementUnavailable('semantic confidence outside probability domain')
    selected=detections[0,scores>.5]
    if len(selected)>4:
        raise VisualMeasurementUnavailable('semantic population exceeds four; no silent subset')
    union=np.zeros(shape,dtype=np.uint8);rows=[]
    for row in selected:
        if row[5]!=0 or row[2]<=row[0] or row[3]<=row[1]:
            raise VisualMeasurementUnavailable('semantic class or box differs')
        raw_box=row[:4]
        box=np.clip(raw_box,0,224)
        if box[2]<=box[0] or box[3]<=box[1]:
            raise VisualMeasurementUnavailable('semantic box outside observed canvas')
        logits=(row[6:] @ prototypes[0].reshape(32,-1)).reshape(56,56)
        if not np.isfinite(logits).all():
            raise VisualMeasurementUnavailable('semantic prototype product overflow')
        xy=box/4
        support=((np.arange(56)[None,:]>=xy[0]) & (np.arange(56)[None,:]<xy[2]) &
                 (np.arange(56)[:,None]>=xy[1]) & (np.arange(56)[:,None]<xy[3]))
        lattice=(cv2.resize(logits*support,(224,224),interpolation=cv2.INTER_LINEAR)>0).astype(np.uint8)
        mask=cv2.resize(lattice,(shape[1],shape[0]),interpolation=cv2.INTER_NEAREST)
        union |= mask
        rows.append({'confidence':float(row[4]),'class_id':0,'model_box_xyxy':raw_box.tolist(),
                     'visible_box_xyxy':box.tolist(),'mask_sha256':'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
                     'foreground_pixels':int(mask.sum())})
    return union,rows


def _semantic_hand_views(rgb: np.ndarray, observation: dict) -> list[list[int]]:
    """Author's fixed 1.3 square pose crops; no gold masks or score selection."""
    h,w=rgb.shape[:2]
    _hand_point_prompts(observation,width=w,height=h)  # typed/finite pose validation only
    views=[]
    for hand in observation['hands']:
        points=np.asarray(hand['screen_landmarks_xyz'],np.float64)[:,:2]
        x1,y1=np.min(points,axis=0).astype(int);x2,y2=np.max(points,axis=0).astype(int)
        cx,cy=(x1+x2)/2,(y1+y2)/2
        half=max(x2-x1,y2-y1)*1.3/2
        bounds=[max(0,int(cx-half)),max(0,int(cy-half)),min(w,int(cx+half)),min(h,int(cy+half))]
        if min(bounds[2]-bounds[0],bounds[3]-bounds[1])<16:
            raise VisualMeasurementUnavailable('semantic crop too small or outside observed frame')
        if bounds in views:
            raise VisualMeasurementUnavailable('semantic crop identities ambiguous')
        views.append(bounds)
    return views


def extract_semantic_hand_mask(root: Path, rgb: np.ndarray, *, pose_crops: dict | None = None) -> tuple[dict,np.ndarray]:
    """One CPU-only semantic inference; no point/label input or QA authority.

    Optional AGPL-3.0 model, not selected by production. Independent evidence
    and licence/distribution review remain necessary before any adoption.
    """
    import onnxruntime as ort
    from .phase6_visual_metrics import visible_mask_geometry
    tensor=_semantic_hand_tensor(rgb)
    views=([[0,0,rgb.shape[1],rgb.shape[0]]] if pose_crops is None else _semantic_hand_views(rgb,pose_crops))
    data=_semantic_hand_model_bytes(root)
    options=ort.SessionOptions();options.intra_op_num_threads=1;options.inter_op_num_threads=1
    options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL;options.enable_cpu_mem_arena=False
    started=time.monotonic()
    session=ort.InferenceSession(data,sess_options=options,providers=['CPUExecutionProvider'])
    metadata=session.get_modelmeta().custom_metadata_map
    expected={'version':'8.4.83','task':'segment','names':"{0: 'hand'}",'imgsz':'[224, 224]','end2end':'True'}
    if any(metadata.get(k)!=v for k,v in expected.items()):
        raise PermissionError('semantic exporter identity differs')
    inputs=[(v.name,v.shape,v.type) for v in session.get_inputs()]
    outputs=[(v.name,v.shape,v.type) for v in session.get_outputs()]
    if inputs!=[('images',[1,3,224,224],'tensor(float)')] or outputs!=[
            ('output0',[1,300,38],'tensor(float)'),('output1',[1,32,56,56],'tensor(float)')]:
        raise PermissionError('semantic graph boundary differs')
    mask=np.zeros(rgb.shape[:2],np.uint8);rows=[];view_rows=[]
    for index,(left,top,right,bottom) in enumerate(views):
        crop=rgb[top:bottom,left:right]
        view_tensor=tensor if pose_crops is None else _semantic_hand_tensor(crop)
        detections,prototypes=session.run(['output0','output1'],{'images':view_tensor})
        part,detected=_decode_semantic_hand_masks(detections,prototypes,tuple(crop.shape[:2]))
        mask[top:bottom,left:right] |= part
        rows.extend(detected if pose_crops is None else [{**row,'view_index':index} for row in detected])
        view_rows.append({'view_index':index,'bounds_xyxy':[left,top,right,bottom],
                          'input_tensor_sha256':'sha256:'+hashlib.sha256(view_tensor.tobytes()).hexdigest(),
                          'detections':len(detected)})
    del session,data
    _semantic_hand_model_bytes(root)
    result={'version':('phase6-yolo26-semantic-hand-mask-v1' if pose_crops is None else 'phase6-yolo26-pose-cropped-hand-mask-v1'),
            'status':'MASK_PROPOSAL_NOT_QUALIFIED' if rows else 'NO_CONFIDENT_SEMANTIC_OBSERVATION',
            'scope':'SEMANTIC_HAND_MASK_ESTIMATE_NOT_ANATOMY_OR_QUALITY_APPROVAL',
            'instrument_revision':'4d7f8866146b40b4ad8db83e87022e7cafca91ef',
            'model_sha256':'sha256:'+SEMANTIC_MODEL_BINDING[2], 'model_license':'AGPL-3.0',
            'input_contract':'RGB_STRETCH_224_BCHW_DIV255',
            'mask_contract':'PROTO_HALF_OPEN_CROP_BILINEAR_224_LOGIT_GT0_NEAREST_NATIVE',
            'onnxruntime_version':ort.__version__,'execution':('CPU_SERIAL_ONE_INFERENCE' if pose_crops is None else 'CPU_SERIAL_AUTHOR_POSE_CROPS'),
            'confidence_operating_point':.5,'mask_logit_threshold':0.,
            'size_wh':[rgb.shape[1],rgb.shape[0]],'input_tensor_sha256':'sha256:'+hashlib.sha256(tensor.tobytes()).hexdigest(),
            'decoded_rgb_sha256':'sha256:'+hashlib.sha256(rgb.tobytes()).hexdigest(),
            'detections':rows,'proposal_geometry':visible_mask_geometry(mask),
            'elapsed_seconds':time.monotonic()-started,'new_detector_inferences':len(views),'new_pose_inferences':0,
            'zero_detections_proves_absence':False,'semantic_labels_verified':False,
            'complete_hand_coverage_proved':False,'quality_authorized':False,
            'render_authorized':False,'publication_authorized':False}
    if pose_crops is not None:
        result.update(views=view_rows,input_contract='RGB_AUTHOR_POSE_SQUARE_1_3_CROPS_STRETCH224_BCHW_DIV255')
        result.pop('input_tensor_sha256')
    return result,mask


def measure_face_hand_class_overlap(rgb: np.ndarray, face_observation: dict,
        hand_region: dict, labels: np.ndarray, *, pose_observation: dict | None = None) -> dict:
    """Measure competing model support, never relabel a face as a proven hand.

    File callers must authenticate both receipts. This reader reopens no model
    and performs no inference: it binds pixels, the author's exact preprocessing,
    mask geometry and every facial point. Empty/partial support cannot suppress
    a face candidate or establish absence. Pose crops are explicit, not fallback.
    """
    import json
    from .phase6_visual_metrics import visible_mask_geometry
    pixels=np.array(_image(rgb),copy=True,order='C');mask=np.array(labels,copy=True,order='C')
    h,w=pixels.shape[:2];digest='sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest()
    geometry=compare_face_geometry(face_observation,face_observation,pixels,pixels,
        layout={'canvas':{'width':w,'height':h},'decorations':[],'overlays':[]})
    if geometry['reference_face_count'] and not geometry['matches']:
        raise VisualMeasurementUnavailable('unambiguous face population required for class overlap')
    version=hand_region.get('version');cropped=version=='phase6-yolo26-pose-cropped-hand-mask-v1'
    detections=hand_region.get('detections')
    if (version not in ('phase6-yolo26-semantic-hand-mask-v1','phase6-yolo26-pose-cropped-hand-mask-v1')
            or hand_region.get('scope')!='SEMANTIC_HAND_MASK_ESTIMATE_NOT_ANATOMY_OR_QUALITY_APPROVAL'
            or hand_region.get('model_sha256')!='sha256:'+SEMANTIC_MODEL_BINDING[2]
            or hand_region.get('instrument_revision')!='4d7f8866146b40b4ad8db83e87022e7cafca91ef'
            or hand_region.get('decoded_rgb_sha256')!=digest or hand_region.get('size_wh')!=[w,h]
            or type(hand_region.get('confidence_operating_point')) not in (int,float) or hand_region['confidence_operating_point']!=.5
            or type(hand_region.get('mask_logit_threshold')) not in (int,float) or hand_region['mask_logit_threshold']!=0
            or hand_region.get('mask_contract')!='PROTO_HALF_OPEN_CROP_BILINEAR_224_LOGIT_GT0_NEAREST_NATIVE'
            or any(hand_region.get(k) is not False for k in ('zero_detections_proves_absence','semantic_labels_verified',
                'complete_hand_coverage_proved','quality_authorized','render_authorized','publication_authorized'))
            or mask.dtype!=np.uint8 or mask.shape!=(h,w) or not np.isin(mask,[0,1]).all()
            or hand_region.get('proposal_geometry')!=visible_mask_geometry(mask)
            or not isinstance(detections,list)):
        raise PermissionError('hand semantic pixels, mask, model or authority differs')
    if hand_region.get('status')!=('MASK_PROPOSAL_NOT_QUALIFIED' if detections else 'NO_CONFIDENT_SEMANTIC_OBSERVATION'):
        raise PermissionError('hand semantic population status differs')
    if not detections and mask.any():raise PermissionError('hand mask has foreground without observations')
    if cropped:
        if (not isinstance(pose_observation,dict) or pose_observation.get('input',{}).get('decoded_rgb_sha256')!=digest
                or pose_observation.get('models')!={k:{'file':v[0],'size_bytes':v[1],'sha256':'sha256:'+v[2]} for k,v in MODEL_BINDINGS.items()}):
            raise PermissionError('pose crop pixel/model binding differs')
        bounds=_semantic_hand_views(pixels,pose_observation)
        views=hand_region.get('views')
        if (not isinstance(views,list) or len(views)!=len(bounds)
                or hand_region.get('input_contract')!='RGB_AUTHOR_POSE_SQUARE_1_3_CROPS_STRETCH224_BCHW_DIV255'
                or hand_region.get('execution')!='CPU_SERIAL_AUTHOR_POSE_CROPS'):
            raise PermissionError('hand semantic crop contract differs')
        for i,(view,box) in enumerate(zip(views,bounds)):
            left,top,right,bottom=box
            tensor=_semantic_hand_tensor(pixels[top:bottom,left:right])
            if (type(view.get('view_index')) is not int or view['view_index']!=i or view.get('bounds_xyxy')!=box
                    or view.get('input_tensor_sha256')!='sha256:'+hashlib.sha256(tensor.tobytes()).hexdigest()
                    or type(view.get('detections')) is not int or view['detections']!=sum(d.get('view_index')==i for d in detections)):
                raise PermissionError('hand semantic view geometry/tensor/population differs')
    else:
        bounds=[[0,0,w,h]]
        tensor=_semantic_hand_tensor(pixels)
        if (pose_observation is not None or hand_region.get('input_contract')!='RGB_STRETCH_224_BCHW_DIV255'
                or hand_region.get('execution')!='CPU_SERIAL_ONE_INFERENCE'
                or hand_region.get('input_tensor_sha256')!='sha256:'+hashlib.sha256(tensor.tobytes()).hexdigest()):
            raise PermissionError('hand semantic full-frame contract differs')
    if type(hand_region.get('new_detector_inferences')) is not int or hand_region['new_detector_inferences']!=len(bounds):
        raise PermissionError('hand semantic invocation population differs')
    for detection in detections:
        if (type(detection.get('confidence')) not in (int,float) or not .5<detection['confidence']<=1
                or type(detection.get('class_id')) is not int or detection['class_id']!=0
                or cropped and (type(detection.get('view_index')) is not int or not 0<=detection['view_index']<len(bounds))):
            raise PermissionError('hand semantic detection class/score/view differs')
    rows=[];counts={k:0 for k in ('HAND_MODEL_FOREGROUND','HAND_MODEL_BACKGROUND','RASTER_BOUNDARY_UNKNOWN',
                                'OUTSIDE_FRAME_UNKNOWN','NO_CONFIDENT_HAND_OBSERVATION')}
    for match in geometry['matches']:
        for index,point in enumerate(match['reference_landmarks_xy']):
            lo=np.floor(point).astype(int);hi=np.ceil(point).astype(int);support=[];values=[]
            status='OUTSIDE_FRAME_UNKNOWN'
            if (lo>=0).all() and hi[0]<w and hi[1]<h:
                support=sorted({(int(x),int(y)) for x in (lo[0],hi[0]) for y in (lo[1],hi[1])})
                values=sorted({int(mask[y,x]) for x,y in support})
                status=('NO_CONFIDENT_HAND_OBSERVATION' if not detections else 'RASTER_BOUNDARY_UNKNOWN' if len(values)!=1
                        else 'HAND_MODEL_FOREGROUND' if values==[1] else 'HAND_MODEL_BACKGROUND')
            counts[status]+=1
            rows.append({'face_index':match['reference_face'],'landmark_index':index,'xy_pixels':point,
                         'support_xy':[list(p) for p in support],'labels':values,'status':status})
    return {'version':'phase6-face-hand-class-overlap-v1','status':
        'CROSS_MODEL_CLASS_CONFLICT_NOT_RESOLVED' if counts['HAND_MODEL_FOREGROUND'] else 'NO_CONFLICT_OBSERVED_NOT_FACE_VALIDATION',
        'frame_rgb_sha256':digest,'hand_region_version':version,'face_count':geometry['reference_face_count'],
        'requested_points':5*geometry['reference_face_count'],'rows':rows,'counts':counts,
        'mask_sha256':'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
        'face_observation_sha256':'sha256:'+hashlib.sha256(json.dumps(face_observation,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),
        'rule':'ALL_FLOOR_CEIL_LABELS_MUST_AGREE; MODEL_CONFLICT_IS_NOT_A_GROUND_TRUTH_CLASS',
        'class_proved':None,'face_candidates_suppressed':0,'new_inferences':0,'tolerance':None,
        'zero_detections_proves_absence':False,'quality_authorized':False,'render_authorized':False,'publication_authorized':False}


def _segment_model_bytes(root: Path, key: str) -> bytes:
    name,size,digest = SEGMENT_BINDINGS[key]
    path = (root/SEGMENT_DIRECTORY/name).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file() or path.stat().st_size != size:
        raise PermissionError('segmentation model outside pinned population')
    data = path.read_bytes()
    if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
        raise PermissionError('segmentation model differs from official anchor')
    return data


def _hand_point_prompts(observation: dict, *, width: int, height: int,
                        contract: str = 'palm-tips-v1') -> list[dict]:
    """Six automatic prompts per pose, never manual masks or anatomical truth.

    Legacy uses palm centre and five fingertip estimates. Explicit wrist v2
    covers the other hand extremity with wrist 0 and the same five tips, still
    exactly six prompts. Neither contract makes the pose ground truth.
    Off-frame estimates are ignored explicitly, not clamped onto the image.
    The model may include/exclude any pixel; prompts are not fixed silhouettes.
    """
    if contract not in ('palm-tips-v1', 'wrist-tips-v2'):
        raise VisualMeasurementUnavailable('unknown hand prompt contract; no fallback')
    if (not isinstance(observation,dict) or observation.get('version') != VERSION
            or observation.get('status') != 'OBSERVATION_ONLY' or observation.get('quality_authorized') is not False):
        raise VisualMeasurementUnavailable('typed non-authorizing hand observation required')
    hands=observation.get('hands')
    if (not isinstance(hands,list) or not 1 <= len(hands) <= 4
            or type(observation.get('palms_detected')) is not int or observation['palms_detected'] != len(hands)):
        raise VisualMeasurementUnavailable('complete one-to-four hand population required')
    result=[]
    for hand in hands:
        if (not isinstance(hand,dict) or hand.get('status') != 'LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL'
                or hand.get('quality_authorized') is not False or type(hand.get('confidence')) not in (int,float)
                or not np.isfinite(hand['confidence']) or not POSE_CONFIDENCE <= hand['confidence'] <= 1):
            raise VisualMeasurementUnavailable('uncertain hand cannot supply semantic prompts')
        points=np.asarray(hand.get('screen_landmarks_xyz'),dtype=np.float64)
        if points.shape != (21,3) or not np.isfinite(points).all() or (np.abs(points[:,:2])>4*max(width,height)).any():
            raise VisualMeasurementUnavailable('invalid hand prompt geometry')
        if contract == 'palm-tips-v1':
            xy=np.vstack((points[[0,5,9,13,17],:2].mean(axis=0),points[[4,8,12,16,20],:2])).astype(np.float32)
        else:
            xy=points[[0,4,8,12,16,20],:2].astype(np.float32)
        inside=((xy >= [0,0]) & (xy < [width,height])).all(axis=1)
        if not inside.any():
            raise VisualMeasurementUnavailable('no visible prompt support')
        labels=np.where(inside,1.,-1.).astype(np.float32)
        xy[~inside]=-1.
        result.append({'coords':xy,'labels':labels,'ignored_prompt_indices':np.flatnonzero(~inside).tolist(),
                       'pose_confidence':float(hand['confidence'])})
    return result


def extract_learned_hand_mask(root: Path, rgb: np.ndarray, observation: dict, *,
                              prompt_contract: str = 'palm-tips-v1') -> tuple[dict,np.ndarray]:
    """Prompted learned segmentation. Not a qualified anatomy/quality decision.

    Follows the official ONNX example: raw RGB BCHW /255, original-coordinate
    points, int64 original H/W, logits >=0. The graph owns resize/normalization.
    Keep all three alternatives' identities; argmax estimated IoU selects the
    proposal, not a ground-truth verdict. No inference cache or caller PASS.
    """
    pixels=_image(rgb)
    h,w=pixels.shape[:2]
    if h*w > 2_097_152:
        raise VisualMeasurementUnavailable('learned segmentation workload exceeded; no implicit resize')
    prompts=_hand_point_prompts(observation,width=w,height=h,contract=prompt_contract)
    return _extract_learned_prompt_mask(root,pixels,prompts,kind='hand',prompt_contract=prompt_contract)


def extract_learned_face_mask(root: Path, rgb: np.ndarray, observation: dict) -> tuple[dict,np.ndarray]:
    """Automatic YuNet prompts -> existing SAM engine; no reference labels.

    Five landmarks are model estimates, not claims that they are all visible.
    The independent point reference is deliberately NOT an argument. A face
    region proposal must be evaluated separately; no dense visibility/QA grant.
    """
    pixels=_image(rgb)
    h,w=pixels.shape[:2]
    if h*w > 2_097_152:
        raise VisualMeasurementUnavailable('learned segmentation workload exceeded; no implicit resize')
    compare_face_geometry(observation,observation,pixels,pixels,
        layout={'canvas':{'width':w,'height':h},'decorations':[],'overlays':[]})
    if not 1 <= observation['face_count'] <= 4:
        raise VisualMeasurementUnavailable('complete one-to-four face population required; zero is not absence')
    scale=np.array([w,h])/observation['raw']['input_size']
    prompts=[]
    for face in observation['raw']['detections']:
        xy=(np.asarray(face[4:14]).reshape(5,2)*scale).astype(np.float32)
        inside=((xy >= [0,0]) & (xy < [w,h])).all(axis=1)
        if not inside.any():
            raise VisualMeasurementUnavailable('no visible face prompt support')
        labels=np.where(inside,1.,-1.).astype(np.float32)
        xy[~inside]=-1.
        prompts.append({'coords':xy,'labels':labels,'ignored_prompt_indices':np.flatnonzero(~inside).tolist(),
                        'pose_confidence':float(face[14])})
    result,mask=_extract_learned_prompt_mask(root,pixels,prompts,kind='face',prompt_contract='yunet-five-v1')
    result.update(identity_proved=False,landmark_visibility_proved=False,
                  independent_reference_used_as_prompt=False)
    return result,mask


def _extract_learned_prompt_mask(root, pixels, prompts, *, kind, prompt_contract):
    """Existing serial ONNX engine shared by typed hand/face entry points."""
    from .phase6_visual_metrics import visible_mask_geometry
    allowed={'hand':('palm-tips-v1','wrist-tips-v2'),'face':('yunet-five-v1',)}
    if kind not in allowed or prompt_contract not in allowed[kind]:
        raise VisualMeasurementUnavailable('unknown learned region contract')
    h,w=pixels.shape[:2]
    # Authenticate both files before creating a native session, then again at
    # closure. CPU threads/allocators are instance-local, never global settings.
    for key in SEGMENT_BINDINGS:
        _segment_model_bytes(root,key)
    import onnxruntime as ort
    options=ort.SessionOptions()
    options.intra_op_num_threads=1
    options.inter_op_num_threads=1
    options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL
    options.enable_cpu_mem_arena=False
    options.enable_mem_pattern=False
    started=time.monotonic()
    encoder=ort.InferenceSession(_segment_model_bytes(root,'encoder'),sess_options=options,providers=['CPUExecutionProvider'])
    tensor=np.ascontiguousarray(pixels.transpose(2,0,1)[None],dtype=np.float32)/np.float32(255.)
    encoder_start=time.monotonic()
    embedding,=encoder.run(['image_embeddings'],{'batched_images':tensor})
    encoder_seconds=time.monotonic()-encoder_start
    del encoder,tensor
    if embedding.shape != (1,256,64,64) or embedding.dtype != np.float32 or not np.isfinite(embedding).all():
        raise VisualMeasurementUnavailable('encoder output contract mismatch')
    decoder=ort.InferenceSession(_segment_model_bytes(root,'decoder'),sess_options=options,providers=['CPUExecutionProvider'])
    union=np.zeros((h,w),np.uint8)
    rows=[]
    for index,prompt in enumerate(prompts):
        if time.monotonic()-started > 120:
            raise TimeoutError('learned segmentation deadline exceeded before next query')
        decoder_start=time.monotonic()
        logits,scores=decoder.run(['output_masks','iou_predictions'],{
            'image_embeddings':embedding,'batched_point_coords':prompt['coords'][None,None],
            'batched_point_labels':prompt['labels'][None,None],
            'orig_im_size':np.array([h,w],dtype=np.int64)})
        decoder_seconds=time.monotonic()-decoder_start
        if (logits.shape != (1,1,3,h,w) or scores.shape != (1,1,3)
                or logits.dtype != np.float32 or scores.dtype != np.float32
                or not np.isfinite(logits).all() or not np.isfinite(scores).all()):
            raise VisualMeasurementUnavailable('decoder output contract mismatch')
        alternatives=(logits[0,0]>=0).astype(np.uint8)
        chosen=int(np.argmax(scores[0,0]))
        tied=np.flatnonzero(scores[0,0]==scores[0,0,chosen]).tolist()
        # A tied, different silhouette cannot be resolved by array order.
        if any(not np.array_equal(alternatives[chosen],alternatives[i]) for i in tied):
            raise VisualMeasurementUnavailable('ambiguous mask ranking')
        union |= alternatives[chosen]
        rows.append({kind+'_index':index,'points_xy':prompt['coords'].tolist(),
                     'point_labels':prompt['labels'].tolist(),'ignored_prompt_indices':prompt['ignored_prompt_indices'],
                     'pose_confidence':prompt['pose_confidence'],'estimated_iou_scores':scores[0,0].tolist(),
                     'selected_alternative':chosen,'decoder_seconds':decoder_seconds,
                     'alternatives':[{'mask_sha256':'sha256:'+hashlib.sha256(mask.tobytes()).hexdigest(),
                                      'foreground_pixels':int(mask.sum())} for mask in alternatives]})
        del logits,scores,alternatives
    del decoder,embedding
    for key in SEGMENT_BINDINGS:
        _segment_model_bytes(root,key)
    result={'version':({'palm-tips-v1':'phase6-efficient-sam-tiny-visible-mask-v1',
                        'wrist-tips-v2':'phase6-efficient-sam-tiny-wrist-mask-v2',
                        'yunet-five-v1':'phase6-efficient-sam-tiny-face-mask-v1'}[prompt_contract]),'status':'MASK_PROPOSAL_NOT_QUALIFIED',
            'scope':'LEARNED_PROMPTED_SEGMENTATION_NOT_GOLD_OR_INTRINSIC_ANATOMY',
            'instrument_revision':'d525f622e6f640acf5a0fc37c7ca1f243da5bde0',
            'onnxruntime_version':ort.__version__,'execution':'CPU_SERIAL_ONE_ENCODER_THEN_'+kind.upper()+'_QUERIES',
            'encoder_seconds':encoder_seconds,'elapsed_seconds':time.monotonic()-started,
            'size_wh':[w,h],'decoded_rgb_sha256':'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest(),
            'prompt_contract':({'palm-tips-v1':'PALM_CENTRE_0_5_9_13_17_AND_TIPS_4_8_12_16_20_V1',
                                'wrist-tips-v2':'WRIST_0_AND_TIPS_4_8_12_16_20_V2',
                                'yunet-five-v1':'YUNET_FIVE_ESTIMATED_LANDMARKS_V1'}[prompt_contract]),
            'mask_logit_threshold':0.,kind+'_queries':rows,'proposal_geometry':visible_mask_geometry(union),
            'segmentation_models':{k:{'file':v[0],'size_bytes':v[1],'sha256':'sha256:'+v[2]} for k,v in SEGMENT_BINDINGS.items()},
            'new_detector_inferences':0,'segmentation_encoder_inferences':1,'segmentation_decoder_inferences':len(rows),
            'semantic_labels_verified':False,'complete_'+kind+'_coverage_proved':False,
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    return result,union


def evaluate_heldout_hand_segmentation(root: Path, acquisition_path: Path, *,
        expected_acquisition_sha256: str, heldout_archive_path: Path,
        expected_heldout_sha256: str) -> tuple[dict, dict[str, np.ndarray]]:
    """Automatic RGB -> pose -> segmentation -> independent visible-mask error.

    The four controls are selected by upstream held-out ID before inference.
    Labels never supply points, crops or thresholds to either model. Published
    binary masks are consumed directly, not recreated from polygon coordinates
    or thresholded JPEGs. Errors and unobservable cases remain in the population.
    This measures a reference set, not intrinsic anatomy or production authority.
    """
    import io
    import json
    import re
    import tarfile
    from .phase6_visual_metrics import compare_visible_masks

    root = root.resolve()
    captured = {}
    def bound(value, expected, limit):
        if not isinstance(value, (str, Path)) or not isinstance(expected, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', expected):
            raise PermissionError('exact confined reference anchor required')
        path = (root / value).resolve()
        if not path.is_relative_to(root) or not path.is_file() or not 1 <= path.stat().st_size <= limit:
            raise PermissionError('reference outside confined workload')
        raw = path.read_bytes()
        if len(raw) > limit or 'sha256:'+hashlib.sha256(raw).hexdigest() != expected:
            raise PermissionError('reference bytes differ from external anchor')
        if path in captured and captured[path] != raw:
            raise PermissionError('reference aliases disagree')
        captured[path] = raw
        return path, raw

    acquisition_path, raw = bound(acquisition_path, expected_acquisition_sha256, 2*1024*1024)
    acquisition = json.loads(raw)
    if (acquisition.get('source_url') != 'https://drive.google.com/open?id=1hHUvINGICvOGcaDgA5zMbzAIUv7ewDd3'
            or acquisition.get('quality_authorized') is not False
            or acquisition.get('production_rights_authorized') is not False):
        raise PermissionError('independent non-authorizing reference provenance required')
    archive_path, archive_raw = bound(heldout_archive_path, expected_heldout_sha256, 2*1024*1024)
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as archive:
        total = 0
        root_directory_seen = False
        for member in archive:
            if member.isdir():
                if member.name != 'testset' or member.size != 0 or root_directory_seen:
                    raise PermissionError('unexpected or duplicate held-out root directory')
                root_directory_seen = True
                continue
            total += member.size
            if (not member.isfile() or not re.fullmatch(r'testset/[1-9][0-9]*\.jpg', member.name)
                    or not 1 <= member.size <= 1024*1024 or total > 16*1024*1024
                    or len(members) >= 512 or member.name in members):
                raise PermissionError('held-out population is malformed or exceeds workload')
            members[member.name] = archive.extractfile(member).read(member.size+1)
            if len(members[member.name]) != member.size:
                raise PermissionError('held-out member truncated')
    ids = sorted(int(Path(name).stem) for name in members)[:4]
    if len(ids) != 4 or acquisition.get('selection', {}).get('ids') != ids:
        raise PermissionError('reference population is not the fixed first four held-out IDs')
    selected = acquisition.get('selected')
    if not isinstance(selected, list) or len(selected) != 4*len(ids):
        raise PermissionError('complete original/RGB/mask/annotation population required')
    expected_members = {f'hand_over_face/{folder}/{i}.{extension}' for i in ids
        for folder, extension in (('images_original_size','jpg'),('images_resized','jpg'),('masks','png'),('annotations','xml'))}
    if (any(not isinstance(row, dict) or not isinstance(row.get('member'), str) for row in selected)
            or len(selected) != len({row.get('member') for row in selected})
            or {row.get('member') for row in selected} != expected_members):
        raise PermissionError('reference member identity/coverage differs')
    by_member = {}
    paths = set()
    for row in selected:
        path, data = bound(row.get('path'), row.get('sha256'), 8*1024*1024)
        if path in paths or type(row.get('size_bytes')) is not int or len(data) != row['size_bytes']:
            raise PermissionError('reference size/path identity differs')
        paths.add(path)
        by_member[row['member']] = (path, data)
    inputs = []
    for i in ids:
        path, image_raw = by_member[f'hand_over_face/images_resized/{i}.jpg']
        _, mask_raw = by_member[f'hand_over_face/masks/{i}.png']
        if image_raw != members[f'testset/{i}.jpg']:
            raise PermissionError('RGB is not byte-identical to the independent held-out image')
        with Image.open(io.BytesIO(image_raw)) as image, Image.open(io.BytesIO(mask_raw)) as mask:
            if (image.mode != 'RGB' or image.format != 'JPEG' or mask.format != 'PNG' or mask.mode != '1'
                    or image.size != mask.size or min(image.size) < 16 or image.width*image.height > 2_097_152):
                raise VisualMeasurementUnavailable('matched native RGB/binary mask required; no resize or threshold')
            pixels = np.array(image)
            labels = np.asarray(mask, dtype=np.uint8)
        if not labels.any() or labels.all():
            raise VisualMeasurementUnavailable('reference must observe foreground and background')
        inputs.append((i, path, pixels, labels))
    # Authenticate the whole reference and model population before any native
    # inference. A changed later control cannot cause partial wasted inference.
    for key in MODEL_BINDINGS:
        _model_bytes(root, key)
    for key in SEGMENT_BINDINGS:
        _segment_model_bytes(root, key)
    def recheck():
        if any(path.read_bytes() != data for path, data in captured.items()):
            raise PermissionError('reference changed during held-out measurement')
    recheck()
    started = time.monotonic()
    rows, proposals = [], {}
    for i, path, pixels, labels in inputs:
        recheck()
        if time.monotonic()-started > 180:
            raise TimeoutError('held-out deadline exceeded before next control')
        pose = observe_hand_frame(root, path, expected_sha256='sha256:'+hashlib.sha256(captured[path]).hexdigest())
        row = {'control_id':str(i), 'pose_observation':pose,
               'reference_mask_sha256':'sha256:'+hashlib.sha256(labels.tobytes()).hexdigest(),
               'reference_foreground_px':int(labels.sum())}
        try:
            _hand_point_prompts(pose, width=pixels.shape[1], height=pixels.shape[0])
        except VisualMeasurementUnavailable as exc:
            row.update(status='UNOBSERVABLE_AUTOMATIC_PROMPTS', missing_variable=str(exc),
                       comparison=None, segmentation=None)
        else:
            observation, proposal = extract_learned_hand_mask(root, pixels, pose)
            row.update(status='HELD_OUT_MASK_ERROR_MEASURED', segmentation=observation,
                       comparison=compare_visible_masks(labels, proposal))
            proposals[str(i)] = proposal
        rows.append(row)
        recheck()
    for key in MODEL_BINDINGS:
        _model_bytes(root, key)
    for key in SEGMENT_BINDINGS:
        _segment_model_bytes(root, key)
    recheck()
    return {'version':'phase6-independent-hand-mask-evaluation-v1',
            'status':'HELD_OUT_REFERENCE_MEASURED_NOT_QUALITY_APPROVAL',
            'reference_acquisition':{'path':acquisition_path.relative_to(root).as_posix(),'sha256':expected_acquisition_sha256},
            'heldout_archive':{'path':archive_path.relative_to(root).as_posix(),'sha256':expected_heldout_sha256},
            'selection_ids':ids, 'controls':rows, 'selected_count':len(rows),
            'measured_mask_count':len(proposals), 'unobservable_count':len(rows)-len(proposals),
            'elapsed_seconds':time.monotonic()-started, 'reference_used_for_prompts':False,
            'tolerance':None, 'scope':'VISIBLE_MASK_ERROR_ON_FIXED_HELD_OUT_IMAGES_NOT_INTRINSIC_ANATOMY',
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}, proposals


def compare_hand_geometry(reference: dict, candidate: dict, *, reference_size: tuple[int, int],
                          candidate_size: tuple[int, int]) -> dict:
    """One-to-one matching under the recipe's scale-increase/central-crop map.

    Match by *absolute mapped positions*, not best-fitting each hand's shape.
    Report independent shape residuals afterwards. Never turn a missing pose,
    out-of-frame prediction or an ambiguous assignment into anatomy approval.
    Up to four hands are supported by this bounded exact assignment; larger
    populations explicitly lack a matching instrument (none are discarded).
    """
    from .phase6_visual_metrics import landmark_shape_error

    def points(value):
        hands = value["hands"]
        if value["palms_detected"] != len(hands) or not 1 <= len(hands) <= 4:
            raise VisualMeasurementUnavailable("hand matching needs one to four observed poses, not absence")
        result = []
        for hand in hands:
            if hand["status"] != "LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL":
                raise VisualMeasurementUnavailable("uncertain pose cannot become a matching reference")
            p = np.asarray(hand["screen_landmarks_xyz"], dtype=np.float64)
            if p.shape != (21, 3) or not np.isfinite(p).all():
                raise VisualMeasurementUnavailable("invalid hand landmark population")
            result.append(p[:, :2])
        return result

    if any(type(x) is not int or x <= 0 for x in (*reference_size, *candidate_size)):
        raise ValueError("positive integer image dimensions required")
    ref, out = points(reference), points(candidate)
    if len(ref) != len(out):
        raise VisualMeasurementUnavailable("source/candidate hand populations differ; no silent subset")
    source_wh, target_wh = np.asarray(reference_size), np.asarray(candidate_size)
    scale = float(max(target_wh / source_wh))
    offset = (source_wh * scale - target_wh) / 2
    mapped = [p * scale - offset for p in ref]
    assignments = sorted((sum(float(np.mean(np.sum((mapped[i] - out[j]) ** 2, axis=1)))
                              for i, j in enumerate(permutation)), permutation)
                         for permutation in itertools.permutations(range(len(out))))
    best, permutation = assignments[0]
    if len(assignments) > 1 and assignments[1][0] - best <= np.spacing(max(1., abs(best))) * 8:
        raise VisualMeasurementUnavailable("ambiguous hand correspondence; no arbitrary identity assignment")
    rows = []
    for i, j in enumerate(permutation):
        a, b = mapped[i], out[j]
        visible = ((a >= 0) & (a < target_wh)).all(axis=1) & ((b >= 0) & (b < target_wh)).all(axis=1)
        rows.append({"source_hand": i, "candidate_hand": j, "shape": landmark_shape_error(a, b),
                     "mapped_position_rms_px": float(np.sqrt(np.mean(np.sum((a - b) ** 2, axis=1)))),
                     "visible_landmark_indices": np.flatnonzero(visible).tolist(),
                     "out_of_frame_landmark_indices": np.flatnonzero(~visible).tolist(),
                     "all_landmarks_observed_inside_frame": bool(visible.all())})
    return {"method": "bounded-bijective-scale-crop-hand-geometry-v1", "matches": rows,
            "scale": scale, "crop_offset_xy": offset.tolist(), "best_assignment_cost_px2": best,
            "second_assignment_margin_px2": None if len(assignments) == 1 else assignments[1][0] - best,
            "tolerance": None, "quality_authorized": False,
            "limitation": "Reference-transfer measurement only; occlusion, intrinsic anatomy and instrument calibration remain separate."}
