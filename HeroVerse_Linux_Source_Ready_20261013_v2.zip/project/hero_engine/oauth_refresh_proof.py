from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker

from .youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
INTEGRATION_ID = "youtube-heroverse-v1"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _outside_workspace(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        return True
    return False


def _atomic_write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _write_json(path: Path, value: dict[str, Any]) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    _atomic_write(path, payload)


def _default_credential_loader(token_file: Path, scopes: list[str]) -> Any:
    from google.oauth2.credentials import Credentials  # type: ignore

    return Credentials.from_authorized_user_file(str(token_file), scopes)


def _default_request_factory() -> Any:
    from google.auth.transport.requests import Request  # type: ignore

    return Request()


def _default_youtube_builder(credentials: Any) -> Any:
    from googleapiclient.discovery import build  # type: ignore

    return build("youtube", "v3", credentials=credentials, cache_discovery=False)


def _scope_list(token: dict[str, Any]) -> list[str]:
    value = token.get("scopes") or []
    return sorted({item for item in value if isinstance(item, str)})


def _receipt(
    *,
    status: str,
    token_sha256: str,
    granted_scopes: list[str],
    refresh_success: bool,
    observed_channel_id: str | None,
    token_persisted: bool,
    failure_code: str | None,
    tested_at: str,
) -> dict[str, Any]:
    receipt_seed = f"{status}|{token_sha256}|{observed_channel_id}|{tested_at}"
    return {
        "schema_version": "1.0.0",
        "receipt_id": "oauth-refresh-" + hashlib.sha256(receipt_seed.encode()).hexdigest()[:20],
        "integration_id": INTEGRATION_ID,
        "status": status,
        "channel_id": CHANNEL_ID,
        "observed_channel_id": observed_channel_id,
        "token_sha256": token_sha256,
        "required_scopes": list(INTEGRATION_SCOPES),
        "granted_scopes": sorted(set(granted_scopes)),
        "refresh_success": refresh_success,
        "noninteractive": True,
        "identity_verified_after_refresh": observed_channel_id == CHANNEL_ID,
        "token_persisted": token_persisted,
        "atomic_replace": token_persisted,
        "failure_code": failure_code,
        "secret_logged": False,
        "technical_cost_brl": 0,
        "tested_at": tested_at,
    }


def prove_noninteractive_refresh(
    token_file: Path,
    receipt_file: Path,
    *,
    root: Path = ROOT,
    tested_at: str | None = None,
    credential_loader: Callable[[Path, list[str]], Any] | None = None,
    request_factory: Callable[[], Any] | None = None,
    youtube_builder: Callable[[Any], Any] | None = None,
    deadline: Any | None = None,
) -> dict[str, Any]:
    """Refresh an existing four-scope token and prove the owned channel without user interaction.

    Secret values and API response payloads are never persisted. The source token is replaced
    only after refresh, scope and exact-channel identity checks have all passed.
    """

    root = root.resolve()
    token_file = token_file.resolve()
    receipt_file = receipt_file.resolve()
    timestamp = tested_at or _now()
    original = b""
    token: dict[str, Any] = {}
    granted: list[str] = []
    refresh_success = False
    observed_channel_id: str | None = None
    failure_code: str | None = None

    if not token_file.is_file():
        failure_code = "TOKEN_FILE_MISSING"
    elif not _outside_workspace(token_file, root):
        failure_code = "TOKEN_OUTSIDE_WORKSPACE_REQUIRED"
    else:
        try:
            original = token_file.read_bytes()
            token = json.loads(original.decode("utf-8-sig"))
            if not isinstance(token, dict):
                raise ValueError("authorized-user token must be an object")
            granted = _scope_list(token)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
            failure_code = "TOKEN_INVALID_JSON"

    if failure_code is None and not token.get("refresh_token"):
        failure_code = "REFRESH_TOKEN_MISSING"
    if failure_code is None and not set(INTEGRATION_SCOPES).issubset(granted):
        failure_code = "REQUIRED_SCOPE_MISSING"

    credentials: Any | None = None
    if failure_code is None:
        try:
            if deadline is not None:
                deadline.pulse("oauth.credentials.load:before")
            loader = credential_loader or _default_credential_loader
            credentials = loader(token_file, list(INTEGRATION_SCOPES))
            if deadline is not None:
                deadline.pulse("oauth.credentials.load:after")
        except Exception:
            failure_code = "CREDENTIAL_LOAD_FAILED"

    if failure_code is None:
        try:
            request = (request_factory or _default_request_factory)()
            if deadline is not None:
                delegate = request

                def bounded_request(*args: Any, **kwargs: Any) -> Any:
                    remaining = deadline.request_timeout("oauth.token.refresh:http")
                    supplied = kwargs.get("timeout")
                    if isinstance(supplied, (int, float)) and not isinstance(supplied, bool):
                        remaining = min(remaining, float(supplied))
                    kwargs["timeout"] = remaining
                    return delegate(*args, **kwargs)

                request = bounded_request
                deadline.pulse("oauth.token.refresh:before")
            credentials.refresh(request)
            if deadline is not None:
                deadline.pulse("oauth.token.refresh:after")
            refresh_success = bool(credentials.valid)
            if not refresh_success:
                raise RuntimeError("credentials invalid after refresh")
            runtime_scopes = list(credentials.granted_scopes or credentials.scopes or [])
            granted = sorted(set(runtime_scopes))
            if not set(INTEGRATION_SCOPES).issubset(granted):
                failure_code = "REQUIRED_SCOPE_MISSING"
        except Exception:
            if failure_code is None:
                failure_code = "REFRESH_FAILED"

    if failure_code is None:
        try:
            if deadline is not None:
                deadline.pulse("oauth.channel-probe.discovery:before")
            if youtube_builder is not None:
                youtube = youtube_builder(credentials)
            elif deadline is not None:
                from .google_api_runtime import build_authorized_service

                youtube = build_authorized_service(
                    "youtube",
                    "v3",
                    credentials=credentials,
                    request_timeout_seconds=deadline.request_timeout(
                        "oauth.channel-probe.discovery:transport"
                    ),
                )
            else:
                youtube = _default_youtube_builder(credentials)
            probe = youtube.channels().list(part="id", mine=True)
            if deadline is not None:
                from .google_api_runtime import execute_google_request

                response = execute_google_request(
                    probe,
                    deadline=deadline,
                    stage="oauth.channels.list",
                )
            else:
                response = probe.execute()
            items = response.get("items") or []
            observed_channel_id = items[0].get("id") if len(items) == 1 else None
        except Exception:
            failure_code = "API_PROBE_FAILED"
    if failure_code is None and observed_channel_id != CHANNEL_ID:
        failure_code = "IDENTITY_MISMATCH"

    token_persisted = False
    if failure_code is None:
        try:
            refreshed = credentials.to_json().encode("utf-8")
            parsed_refreshed = json.loads(refreshed.decode("utf-8"))
            refreshed_scopes = _scope_list(parsed_refreshed)
            if not parsed_refreshed.get("refresh_token") or not set(INTEGRATION_SCOPES).issubset(refreshed_scopes):
                raise ValueError("refreshed token lost required fields")
            _atomic_write(token_file, refreshed)
            if token_file.read_bytes() != refreshed:
                raise OSError("post-write token verification failed")
            granted = refreshed_scopes
            token_persisted = True
        except Exception:
            failure_code = "TOKEN_PERSIST_FAILED"
            token_persisted = False

    current = token_file.read_bytes() if token_file.is_file() else original
    receipt = _receipt(
        status="PASS" if failure_code is None else "FAIL",
        token_sha256=_sha256(current),
        granted_scopes=granted,
        refresh_success=refresh_success,
        observed_channel_id=observed_channel_id,
        token_persisted=token_persisted,
        failure_code=failure_code,
        tested_at=timestamp,
    )
    schema = json.loads((root / "schemas/oauth_noninteractive_refresh_receipt.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(receipt)
    _write_json(receipt_file, receipt)
    return receipt
