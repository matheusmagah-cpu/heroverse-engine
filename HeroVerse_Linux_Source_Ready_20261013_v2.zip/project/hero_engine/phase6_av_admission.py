"""Fail-closed admission contract for the Phase-6 continuous AV successor.

This module is deliberately a *pre-transaction* verifier.  It reopens an
immutable request, raw Stage-A arguments, the pinned timeline and independent
capacity/rights/publicity evidence.  It then invokes the real Stage-A
``verify(..., require_complete=True)`` entry point.  A successful return means
only ``ELIGIBLE_FOR_TRANSACTION``.  It never writes a queue record, allocates a
generation namespace, renders media, supersedes a predecessor, or returns a
``COMMITTED`` state.

Minimum contract (all fail closed):

* raw arguments are independent immutable bytes, not copied from the candidate;
* the candidate is exactly recomposed by ``phase6_av_timeline.verify``;
* LIVE evidence, 51 units, 90 fragments, a derived plan and false timeline
  authorities are mandatory;
* the caller supplies the root/predecessor/tail/input context independently;
* capacity, rights and publicity remain separate evidence classes;
* the namespace is a policy-only parent until a later fenced transaction assigns
  a fresh child directory; no concrete path or overwrite is admitted here.

Fixtures may exercise Stage-A logic but are never admissible.  Rights/publicity
screening remains a risk-control boundary, not legal advice or a promise that no
unrecognised mark/person exists.
"""
from __future__ import annotations

import copy
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_asset_residency import verify_phase6_asset_residency
from .phase6_av_timeline import verify_phase6_av_timeline
from .phase6_narration_units import bytes_sha, canonical_sha
from .phase6_publicity import YUNET_SHA256
from .phase6_release import verify_production_inputs_receipt


SCHEMA = "schemas/phase6_av_admission.schema.json"
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "phase6-video-002-prepublication"
ACTION = "PREPARE_VIDEO_2_INPUTS"
MINIMUM_POST_RENDER_FREE_BYTES = 5 * 1024**3
GENERATION_PARENT = "output/production/phase6/video-002/render-generations"

REQUESTS = Path("output/operations/phase6/av-admission/requests")
ARGUMENTS = Path("output/operations/phase6/av-admission/arguments")
TIMELINES = Path("output/operations/phase6/av-admission/timelines")
CAPACITY = Path("output/operations/phase6/av-admission/evidence/capacity")
RIGHTS = Path("output/operations/phase6/av-admission/evidence/rights")
STATIC_RIGHTS_DOCUMENTS = Path("output/operations/phase6/av-admission/evidence/static-rights")
PUBLICITY = Path("output/operations/phase6/av-admission/evidence/publicity")
INPUT_RECEIPTS = Path("output/operations/phase6/release/production-input-receipts")

FALSE_AUTHORITY = {
    "queue_authorized": False,
    "render_authorized": False,
    "publication_authorized": False,
    "external_effect_authorized": False,
}


class AdmissionError(PermissionError):
    """The immutable evidence is not sufficient for a queue transaction."""


def _json_bytes(raw: bytes) -> dict[str, Any]:
    def pairs(values: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in values:
            if key in result:
                raise AdmissionError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    try:
        value = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=pairs,
                           parse_constant=lambda value: (_ for _ in ()).throw(
                               ValueError(f"non-finite JSON number: {value}")))
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise AdmissionError(f"invalid JSON evidence: {type(exc).__name__}:{exc}") from exc
    if not isinstance(value, dict):
        raise AdmissionError("evidence document must be an object")
    return value


def _schema() -> dict[str, Any]:
    return _json_bytes(Path(__file__).resolve().parents[1].joinpath(SCHEMA).read_bytes())


def _validate_schema(value: dict[str, Any]) -> None:
    errors = sorted(
        Draft202012Validator(_schema(), format_checker=FormatChecker()).iter_errors(value),
        key=lambda item: tuple(str(part) for part in item.absolute_path),
    )
    if errors:
        first = errors[0]
        location = "/".join(str(part) for part in first.absolute_path) or "$"
        raise AdmissionError(f"admission schema rejected {location}: {first.message}")


def _resolve_confined(root: Path, value: str, parent: Path) -> Path:
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise AdmissionError("immutable evidence path must be non-empty and project-relative")
    root = root.resolve(strict=True)
    allowed = (root / parent).resolve()
    unresolved = root / value
    cursor = root
    for part in Path(value).parts:
        cursor = cursor / part
        if cursor.exists() and (cursor.is_symlink() or bool(getattr(cursor, "is_junction", lambda: False)())):
            raise AdmissionError("symlink/junction is not accepted in immutable evidence path")
    try:
        path = unresolved.resolve(strict=True)
    except OSError as exc:
        raise AdmissionError(f"immutable evidence missing: {value}") from exc
    if path.parent != allowed:
        raise AdmissionError("immutable evidence escaped its exact directory")
    return path


def _load_binding(root: Path, binding: dict[str, Any], parent: Path) -> tuple[dict[str, Any], Path, bytes]:
    if (
        not isinstance(binding, dict)
        or not {"path", "sha256", "size_bytes"}.issubset(binding)
        or set(binding) - {"path", "sha256", "size_bytes", "document_id"}
    ):
        raise AdmissionError("exact path/hash/size binding required")
    path = _resolve_confined(root, binding["path"], parent)
    raw = path.read_bytes()
    if len(raw) != binding["size_bytes"] or bytes_sha(raw) != binding["sha256"]:
        raise AdmissionError("immutable evidence hash or size mismatch")
    return _json_bytes(raw), path, raw


def _check_identity(value: dict[str, Any], field: str, prefix: str, path: Path | None = None) -> None:
    payload = {key: item for key, item in value.items() if key != field}
    expected = prefix + canonical_sha(payload).split(":", 1)[1][:24]
    if value.get(field) != expected:
        raise AdmissionError(f"{field} does not match canonical document content")
    if path is not None and path.name != f"{expected}.json":
        raise AdmissionError(f"{field} does not match immutable filename")


def _aware(value: str, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as exc:
        raise AdmissionError(f"{label} is not an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise AdmissionError(f"{label} lacks an explicit UTC offset")
    return parsed.astimezone(timezone.utc)


def _exact(left: Any, right: Any, label: str) -> None:
    try:
        same = canonical_sha(left) == canonical_sha(right)
    except (TypeError, ValueError) as exc:
        raise AdmissionError(f"{label} is not finite canonical JSON") from exc
    if not same:
        raise AdmissionError(f"{label} differs")


def _sha_file(root: Path, value: str, expected: str) -> None:
    raw_path = Path(value)
    path = raw_path if raw_path.is_absolute() else root / raw_path
    try:
        resolved = path.resolve(strict=True)
    except OSError as exc:
        raise AdmissionError(f"pinned executable/model missing: {value}") from exc
    if not resolved.is_file() or bytes_sha(resolved.read_bytes()) != expected:
        raise AdmissionError(f"pinned executable/model hash mismatch: {value}")


def validate_timeline_for_admission(
    root: Path,
    timeline: dict[str, Any],
    raw_arguments: dict[str, Any],
    *,
    evidence_mode: str,
) -> dict[str, Any]:
    """Recompose Stage A; never turns a fixture or incomplete plan into authority."""
    arguments = raw_arguments.get("arguments") if raw_arguments.get("document_type") == "PHASE6_AV_RAW_ARGUMENTS" else raw_arguments
    if not isinstance(arguments, dict):
        raise AdmissionError("raw Stage-A arguments are missing")
    required = {
        "source_bindings", "pause_decisions", "render_spans", "visual_events",
        "caption_cues", "temporal_evidence_bindings", "temporal_policy_binding",
    }
    if set(arguments) != required:
        raise AdmissionError("raw Stage-A argument names differ")
    try:
        verified = verify_phase6_av_timeline(
            Path(root), timeline,
            arguments["source_bindings"], arguments["pause_decisions"],
            arguments["render_spans"], arguments["visual_events"],
            arguments["caption_cues"], arguments["temporal_evidence_bindings"],
            temporal_policy_binding=arguments["temporal_policy_binding"],
            require_complete=True,
        )
    except Exception as exc:
        raise AdmissionError(f"Stage-A recomposition failed: {type(exc).__name__}:{exc}") from exc
    if evidence_mode != "LIVE":
        raise AdmissionError("FIXTURE evidence cannot enter transactional admission")
    assessment = verified.get("temporal_evidence_assessment") or {}
    if (
        verified.get("status") != "TIMELINE_VALIDATED_NOT_ADMITTED"
        or verified.get("derived_take_plan") is None
        or verified.get("blockers") != []
        or len(verified.get("units") or []) != 51
        or len(verified.get("narration_fragment_map") or []) != 90
        or assessment.get("fixture_evidence_present") is not False
        or assessment.get("all_required_evidence_live") is not True
        or any(value is not False for value in (verified.get("authority") or {}).values())
    ):
        raise AdmissionError("complete LIVE Stage-A invariants are not satisfied")
    return verified


def _timeline_reference(binding: dict[str, Any], timeline: dict[str, Any]) -> dict[str, Any]:
    return {
        "timeline_id": timeline["timeline_id"],
        "sha256": binding["sha256"],
        "planned_total_samples": timeline["duration"]["planned_total_samples"],
    }


def _validate_capacity(
    root: Path,
    value: dict[str, Any],
    path: Path,
    timeline_ref: dict[str, Any],
    now: datetime,
) -> dict[str, Any]:
    _validate_schema(value)
    _check_identity(value, "evidence_id", "phase6-av-capacity-", path)
    if value["document_type"] != "PHASE6_AV_CAPACITY_EVIDENCE" or value["evidence_mode"] != "LIVE" or value["status"] != "PASS":
        raise AdmissionError("capacity evidence is not a LIVE PASS")
    _exact(value["timeline"], timeline_ref, "capacity timeline binding")
    measured, valid_until = _aware(value["measured_at"], "capacity measured_at"), _aware(value["valid_until"], "capacity valid_until")
    if measured > now or valid_until <= now or valid_until <= measured:
        raise AdmissionError("capacity evidence is future-dated or stale")
    peak = value["estimated_peak_new_bytes"]
    observed = value["observed_free_bytes"]
    if (
        value["minimum_post_render_free_bytes"] != MINIMUM_POST_RENDER_FREE_BYTES
        or value["required_free_bytes"] != peak + MINIMUM_POST_RENDER_FREE_BYTES
        or value["projected_post_render_free_bytes"] != observed - peak
        or observed < value["required_free_bytes"]
        or value["planned_total_samples"] != timeline_ref["planned_total_samples"]
    ):
        raise AdmissionError("capacity arithmetic or 5-GiB reserve differs")
    roles = [item["role"] for item in value["tools"]]
    if sorted(roles) != ["FFMPEG", "FFPROBE"] or len(set(roles)) != 2:
        raise AdmissionError("capacity evidence needs exactly FFmpeg and FFprobe")
    for tool in value["tools"]:
        _sha_file(root, tool["path"], tool["sha256"])
    return {"evidence_id": value["evidence_id"], "status": "PASS", "valid_until": value["valid_until"]}


def _span_assets(timeline: dict[str, Any]) -> list[dict[str, Any]]:
    seen: dict[tuple[str, str], list[dict[str, int | str]]] = {}
    types: dict[tuple[str, str], dict[str, Any]] = {}
    static_evidence = {row["span_id"]: row for row in timeline.get("static_source_evidence") or []}
    if len(static_evidence) != len(timeline.get("static_source_evidence") or []):
        raise AdmissionError("duplicate timeline static inspection")
    for span in timeline.get("render_spans") or []:
        binding = span.get("asset_binding") or {}
        key = (binding.get("path"), binding.get("sha256"))
        if not all(isinstance(part, str) and part for part in key):
            raise AdmissionError("timeline span lacks exact visual asset binding")
        kind = span.get("media_kind", "VIDEO_CFR")
        if kind not in {"STATIC_IMAGE", "VIDEO_CFR"}:
            raise AdmissionError("unknown timeline media kind")
        typed = {"media_kind": kind}
        if kind == "STATIC_IMAGE":
            if timeline.get("schema_version") not in {"1.4.0", "1.5.0", "1.6.0", "1.7.0", "1.8.0", "1.9.0", "1.10.0", "1.11.0"}:
                raise AdmissionError("legacy timeline cannot admit a static source")
            if (type(span.get("source_frame_count")) is not int or span["source_frame_count"] != 1
                    or type(span.get("source_start_frame")) is not int or span["source_start_frame"] != 0
                    or type(span.get("source_end_frame")) is not int or span["source_end_frame"] != 1):
                raise AdmissionError("static source must remain exactly one frame [0,1)")
            proof = static_evidence.get(span["span_id"])
            if proof is None or not isinstance(span.get("static_source"), dict):
                raise AdmissionError("static source lacks Stage-A inspection and recipe binding")
            typed.update(static_source=copy.deepcopy(span["static_source"]),
                         static_inspection={name: proof[name] for name in ("inspection_id", "inspection_sha256")})
        elif span.get("static_source") is not None or span["span_id"] in static_evidence:
            raise AdmissionError("video source cannot carry a static inspection")
        if key in types:
            _exact(types[key], typed, "repeated source media kind or static scope")
        types[key] = typed
        seen.setdefault(key, []).append({
            "span_id": span["span_id"],
            "source_start_frame": span["source_start_frame"],
            "source_end_frame": span["source_end_frame"],
        })
    if not seen:
        raise AdmissionError("timeline has no visual assets")
    return [{"path": path, "sha256": digest, **types[(path, digest)],
             "spans": sorted(spans, key=lambda item: item["span_id"])}
            for (path, digest), spans in sorted(seen.items())]


def _validate_static_rights_row(root: Path, row: dict[str, Any], required: dict[str, Any]) -> dict[str, Any]:
    """Reopen externally reviewed still rights; never borrow motion duration."""
    from .phase6_av_static_timeline import source_request
    from .phase6_static_asset_rights import inspect_static_asset_rights

    binding = row["static_rights"]
    try:
        request = source_request(required["static_source"])
        document_pins = {}
        for name in ("provenance_binding", "decision_binding"):
            pin = binding[name]
            # Documents, not models or user-controlled absolute paths outside root.
            _resolve_confined(root, pin["path"], STATIC_RIGHTS_DOCUMENTS)
            document_pins[name] = {"path": pin["path"], "sha256": pin["sha256"].split(":", 1)[1]}
        proof = inspect_static_asset_rights(root, **request, **document_pins, expected_evidence_mode="LIVE")
    except (ValueError, KeyError, OSError, TypeError) as exc:
        raise AdmissionError(f"static rights reinspection failed: {type(exc).__name__}:{exc}") from exc
    if (proof.get("status") != "PASS" or proof.get("evidence_mode") != "LIVE"
            or proof.get("scope") != "RIGHTS_BINDING_ONLY"
            or proof.get("rights_status") != "OWNED" or proof.get("commercial_use") is not True
            or proof.get("asset_id") != row["asset_id"]
            or proof.get("channel_id") != CHANNEL_ID
            or proof.get("source_ready") is not False
            or any(value is not False for value in (proof.get("authority") or {}).values())):
        raise AdmissionError("static rights are absent, blocked, fixture or outside the permitted scope")
    _exact(binding["inspection_id"], proof["inspection_id"], "static rights inspection identity")
    _exact(binding["inspection_sha256"], canonical_sha(proof), "static rights inspection bytes")
    for name, identity in (("provenance_binding", "provenance_id"), ("decision_binding", "decision_id")):
        if Path(binding[name]["path"]).name != proof[identity] + ".json":
            raise AdmissionError("static rights filename differs from immutable document identity")
    asset = proof["artifacts"]["png_binding"]
    try:
        asset_path = Path(asset["path"]).relative_to(root.absolute()).as_posix()
    except ValueError as exc:
        raise AdmissionError("static rights asset escaped root") from exc
    _exact([asset_path, "sha256:" + asset["sha256"]], [row["path"], row["sha256"]],
           "static rights PNG identity")
    expected = required["static_inspection"]
    _exact([proof["source_proof"]["inspection_id"], proof["source_proof"]["timeline_canonical_sha256"]],
           [expected["inspection_id"], expected["inspection_sha256"]], "static rights Stage-A source inspection")
    return proof


def _recheck_static_rights_dependencies(root: Path, proofs: list[dict[str, Any]]) -> None:
    """Recheck only proofs produced in this admission call, never a candidate.

    Rights proofs preserve the full inspector dependency set and add the external
    provenance/decision/note bindings. The same byte-only sink guard applies;
    decoding or responsible editorial review is not repeated here.
    """
    if not proofs:
        return
    from .phase6_av_static_sources import recheck_static_dependencies
    try:
        recheck_static_dependencies(root, proofs)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        raise AdmissionError(f"static rights changed during admission: {type(exc).__name__}:{exc}") from exc


def _asset_map(rows: list[dict[str, Any]], label: str) -> dict[tuple[str, str], dict[str, Any]]:
    mapped: dict[tuple[str, str], dict[str, Any]] = {}
    ids: set[str] = set()
    for row in rows:
        key = (row.get("path"), row.get("sha256"))
        if key in mapped or row.get("asset_id") in ids:
            raise AdmissionError(f"duplicate {label} asset identity")
        mapped[key] = row
        ids.add(row.get("asset_id"))
    return mapped


def _validate_rights(
    root: Path,
    value: dict[str, Any],
    path: Path,
    timeline_ref: dict[str, Any],
    required_assets: list[dict[str, Any]],
    *,
    _static_proof_sink: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    _validate_schema(value)
    _check_identity(value, "evidence_id", "phase6-av-rights-", path)
    if value["document_type"] != "PHASE6_AV_RIGHTS_EVIDENCE" or value["evidence_mode"] != "LIVE" or value["status"] != "PASS":
        raise AdmissionError("rights evidence is not a LIVE PASS")
    _exact(value["timeline"], timeline_ref, "rights timeline binding")
    rows = _asset_map(value["assets"], "rights")
    expected = {(item["path"], item["sha256"]) for item in required_assets}
    if set(rows) != expected:
        raise AdmissionError("rights evidence does not exactly cover timeline visual bytes")
    allowed = {"OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"}
    if any(row["status"] != "PASS" or row["rights_status"] not in allowed for row in rows.values()):
        raise AdmissionError("a timeline visual asset lacks permitted rights")
    required_by_key = {(item["path"], item["sha256"]): item for item in required_assets}
    videos = {}
    for key, row in rows.items():
        required = required_by_key[key]
        kind = required.get("media_kind", "VIDEO_CFR")
        if value["schema_version"] == "1.0.0":
            if kind != "VIDEO_CFR":
                raise AdmissionError("legacy rights evidence cannot cover static sources")
        else:
            if row["media_kind"] != kind:
                raise AdmissionError("rights media kind differs from Stage A")
        if kind == "STATIC_IMAGE":
            proof = _validate_static_rights_row(root, row, required)
            if _static_proof_sink is not None:
                _static_proof_sink.append(proof)
        elif kind == "VIDEO_CFR":
            videos[key] = row
        else:
            raise AdmissionError("unknown rights source media kind")
    residency = value["asset_residency"]
    try:
        verified = verify_phase6_asset_residency(
            root,
            receipt_path=residency["receipt_path"],
            expected_sha256=residency["sha256"],
            expected_audit_id=residency["audit_id"],
            # The legacy library audit and its pool floor remain mandatory.
            # Stills are independently resident/decoded by their typed verifier,
            # and are never inserted as video-duration rows to satisfy this audit.
            required_asset_ids=[row["asset_id"] for row in videos.values()],
            recheck_media=False,
            recheck_decode=False,
        )
    except Exception as exc:
        raise AdmissionError(f"asset-residency verification failed: {type(exc).__name__}:{exc}") from exc
    if verified["manifest_content_hash"] != residency["manifest_content_hash"]:
        raise AdmissionError("rights residency manifest binding differs")
    # Reopen rows to bind asset IDs to the exact path/hash selected by Stage A.
    receipt_binding = {"path": residency["receipt_path"], "sha256": residency["sha256"], "size_bytes": residency["size_bytes"]}
    receipt, _receipt_path, _raw = _load_binding(root, receipt_binding, Path(residency["receipt_path"]).parent)
    receipt_rows = {row["asset_id"]: row for row in receipt.get("assets") or []}
    for key, row in videos.items():
        sealed = receipt_rows.get(row["asset_id"])
        if (
            sealed is None or sealed.get("status") != "PASS"
            or sealed.get("path") != key[0]
            or sealed.get("observed_content_hash") != key[1]
            or sealed.get("rights_status") != row["rights_status"]
        ):
            raise AdmissionError("rights row differs from immutable residency evidence")
    return {"evidence_id": value["evidence_id"], "status": "PASS", "asset_count": len(rows)}


def _validate_publicity(
    root: Path,
    value: dict[str, Any],
    path: Path,
    timeline_ref: dict[str, Any],
    required_assets: list[dict[str, Any]],
) -> dict[str, Any]:
    _validate_schema(value)
    _check_identity(value, "evidence_id", "phase6-av-publicity-", path)
    if value["document_type"] != "PHASE6_AV_PUBLICITY_EVIDENCE" or value["evidence_mode"] != "LIVE" or value["status"] != "PASS":
        raise AdmissionError("publicity evidence is not a LIVE PASS")
    _exact(value["timeline"], timeline_ref, "publicity timeline binding")
    rows = _asset_map(value["assets"], "publicity")
    expected = {(item["path"], item["sha256"]) for item in required_assets}
    if set(rows) != expected:
        raise AdmissionError("publicity evidence does not exactly cover timeline visual bytes")
    for row in rows.values():
        if (
            row["status"] != "PASS" or row["sample_frame_count"] < 1
            or row["detected_face_count"] != 0 or row["metadata_risk_terms"]
            or row["decode_errors"]
        ):
            raise AdmissionError("publicity screen contains ambiguity, a person, a risk term or decode failure")
    required_by_key = {(item["path"], item["sha256"]): item["spans"] for item in required_assets}
    for key, row in rows.items():
        observed_spans = row["screened_spans"]
        observed_ids = [item["span_id"] for item in observed_spans]
        expected_spans = required_by_key[key]
        if len(set(observed_ids)) != len(observed_ids) or [
            {name: item[name] for name in ("span_id", "source_start_frame", "source_end_frame")}
            for item in observed_spans
        ] != expected_spans:
            raise AdmissionError("publicity screening does not bind every exact source span")
        sample_total = 0
        for item in observed_spans:
            start, end = item["source_start_frame"], item["source_end_frame"]
            required_samples = sorted({start, (start + end - 1) // 2, end - 1})
            samples = item["sampled_source_frames"]
            if start >= end or samples != sorted(set(samples)) or not set(required_samples).issubset(samples):
                raise AdmissionError("publicity screening lacks start/middle/end coverage for a source span")
            if any(sample < start or sample >= end for sample in samples):
                raise AdmissionError("publicity sample lies outside its exact source span")
            sample_total += len(samples)
        if row["sample_frame_count"] < sample_total:
            raise AdmissionError("publicity aggregate frame count is lower than bound span samples")
    detector = value["detector"]
    if detector["model_path"] != "models/yunet/face_detection_yunet_2026may.onnx" or detector["model_sha256"] != f"sha256:{YUNET_SHA256}":
        raise AdmissionError("publicity detector identity differs from the pinned local model")
    _sha_file(root, detector["implementation_path"], detector["implementation_sha256"])
    _sha_file(root, detector["model_path"], detector["model_sha256"])
    return {"evidence_id": value["evidence_id"], "status": "PASS", "asset_count": len(rows),
            "claim_boundary": value["claim_boundary"]}


def _validate_namespace(value: dict[str, Any]) -> None:
    if value != {
        "policy_id": "phase6-av-generation-namespace-v1",
        "generation_parent": GENERATION_PARENT,
        "assignment": "QUEUE_COMMIT_ONLY",
        "generation_id": None,
        "render_path": None,
        "requires_fresh_child_directory": True,
        "baseline_overwrite_allowed": False,
    }:
        raise AdmissionError("namespace policy is concrete, overlapping or otherwise divergent")


def _proof(
    request: dict[str, Any], request_binding: dict[str, Any], timeline: dict[str, Any],
    timeline_ref: dict[str, Any], input_receipt: dict[str, Any], controls: dict[str, Any], now: datetime,
) -> dict[str, Any]:
    value = {
        "schema_version": "1.0.0",
        "document_type": "PHASE6_AV_ADMISSION_PROOF",
        "status": "ELIGIBLE_FOR_TRANSACTION",
        "request": {**request_binding, "request_id": request["request_id"]},
        "context": copy.deepcopy(request["context"]),
        "timeline": timeline_ref,
        "input_receipt_id": input_receipt["receipt_id"],
        "controls": controls,
        "namespace_policy": copy.deepcopy(request["namespace_policy"]),
        "checks": [
            "RAW_ARGUMENTS_REOPENED", "TIMELINE_RECOMPOSED_REQUIRE_COMPLETE",
            "INPUT_RECEIPT_REOPENED", "CAPACITY_SEPARATELY_VERIFIED",
            "RIGHTS_SEPARATELY_VERIFIED", "PUBLICITY_SEPARATELY_VERIFIED",
            "NAMESPACE_UNASSIGNED_UNTIL_TRANSACTION",
        ],
        "transaction": {"state": "NOT_STARTED", "prepared": False, "committed": False,
                        "generation_namespace_assigned": False},
        "authority": copy.deepcopy(FALSE_AUTHORITY),
        "technical_cost_brl": 0,
        "publication_authorized": False,
        "created_at": now.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    value["proof_id"] = "phase6-av-admission-proof-" + canonical_sha(value).split(":", 1)[1][:24]
    _validate_schema(value)
    _check_identity(value, "proof_id", "phase6-av-admission-proof-")
    if value["transaction"]["committed"] or any(value["authority"].values()):
        raise AssertionError("pre-transaction proof attempted to grant authority")
    return value


def verify_phase6_av_admission(
    root: Path,
    request_binding: dict[str, Any],
    *,
    expected_context: dict[str, Any],
    input_receipt: dict[str, Any],
    now: datetime,
) -> dict[str, Any]:
    """Return a non-authoritative eligibility proof; perform no writes/effects."""
    if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
        raise AdmissionError("an explicit timezone-aware verification clock is required")
    if set(request_binding) != {"path", "sha256", "size_bytes"}:
        raise AdmissionError("request binding must be the exact immutable path/hash/size triple")
    now_utc = now.astimezone(timezone.utc)
    request, request_path, _raw = _load_binding(Path(root), request_binding, REQUESTS)
    _validate_schema(request)
    _check_identity(request, "request_id", "phase6-av-admission-request-", request_path)
    if request["evidence_mode"] != "LIVE":
        raise AdmissionError("FIXTURE request cannot enter transactional admission")
    _exact(request["context"], expected_context, "caller-supplied root/predecessor/tail/input context")
    if request["authority"] != FALSE_AUTHORITY or request["transaction_state"] != "NOT_STARTED":
        raise AdmissionError("request attempted to pre-authorize a transaction")
    context = request["context"]
    if (
        context["predecessor_state"] != "SUCCEEDED"
        or context["predecessor_lease_owner"] is not None
        or context["tail_job_id"] != context["predecessor_job_id"]
        or context["input_receipt_id"] != request["input_receipt"]["document_id"]
        or context["input_receipt_sha256"] != request["input_receipt"]["sha256"]
    ):
        raise AdmissionError("predecessor/tail/input context is not transaction-safe")
    _validate_namespace(request["namespace_policy"])

    args, args_path, _ = _load_binding(Path(root), request["raw_arguments"], ARGUMENTS)
    _validate_schema(args)
    _check_identity(args, "arguments_id", "phase6-av-arguments-", args_path)
    if args["evidence_mode"] != "LIVE":
        raise AdmissionError("raw arguments are not LIVE")
    timeline, timeline_path, _ = _load_binding(Path(root), request["timeline"], TIMELINES)
    if timeline_path.name != f"{timeline.get('timeline_id')}.json":
        raise AdmissionError("timeline identity does not match immutable filename")
    for field in ("channel_id", "video_id", "protocol_id"):
        if args[field] != timeline.get(field) or request[field] != timeline.get(field):
            raise AdmissionError(f"{field} differs across request, arguments and timeline")
    _exact(timeline.get("inputs"), args["arguments"], "timeline/raw arguments")
    timeline = validate_timeline_for_admission(Path(root), timeline, args, evidence_mode="LIVE")
    timeline_ref = _timeline_reference(request["timeline"], timeline)

    required_assets = _span_assets(timeline)
    capacity, capacity_path, _ = _load_binding(Path(root), request["capacity_evidence"], CAPACITY)
    rights, rights_path, _ = _load_binding(Path(root), request["rights_evidence"], RIGHTS)
    publicity, publicity_path, _ = _load_binding(Path(root), request["publicity_evidence"], PUBLICITY)
    static_proofs: list[dict[str, Any]] = []
    controls = {
        "capacity": _validate_capacity(Path(root), capacity, capacity_path, timeline_ref, now_utc),
        "rights": _validate_rights(Path(root), rights, rights_path, timeline_ref, required_assets,
                                  _static_proof_sink=static_proofs),
        "publicity": _validate_publicity(Path(root), publicity, publicity_path, timeline_ref, required_assets),
    }

    bound_input, input_path, input_raw = _load_binding(Path(root), request["input_receipt"], INPUT_RECEIPTS)
    if input_path.name != f"{bound_input.get('receipt_id')}.json":
        raise AdmissionError("input receipt identity does not match immutable filename")
    if request["input_receipt"]["document_id"] != bound_input.get("receipt_id"):
        raise AdmissionError("input receipt identity differs from the root/predecessor context")
    _exact(bound_input, input_receipt, "caller-supplied input receipt")
    try:
        verified_input = verify_production_inputs_receipt(
            Path(root), receipt_path=input_path, expected_receipt_id=bound_input["receipt_id"],
            required_action=ACTION, ensure_immutable=False, recheck_decode=False,
        )
    except Exception as exc:
        raise AdmissionError(f"production-input verification failed: {type(exc).__name__}:{exc}") from exc
    _exact(verified_input, bound_input, "production-input verifier result")
    if bound_input["channel_id"] != CHANNEL_ID or request["channel_id"] != CHANNEL_ID:
        raise AdmissionError("production input belongs to another channel")
    take_plan_rows = [row for row in bound_input["artifacts"] if Path(row["path"]).name == "take_plan.json"]
    if len(take_plan_rows) != 1 or take_plan_rows[0]["sha256"] != args["arguments"]["source_bindings"]["take_plan"]["sha256"]:
        raise AdmissionError("Stage-A TakePlan differs from the immutable production input")
    if len(input_raw) != request["input_receipt"]["size_bytes"]:
        raise AdmissionError("input receipt size changed during admission")

    # Final re-open closes the check/use window for the admission evidence itself.
    for binding, parent in (
        (request_binding, REQUESTS), (request["raw_arguments"], ARGUMENTS),
        (request["timeline"], TIMELINES), (request["capacity_evidence"], CAPACITY),
        (request["rights_evidence"], RIGHTS), (request["publicity_evidence"], PUBLICITY),
        (request["input_receipt"], INPUT_RECEIPTS),
    ):
        _load_binding(Path(root), binding, parent)
    _recheck_static_rights_dependencies(Path(root), static_proofs)
    return _proof(request, request_binding, timeline, timeline_ref, bound_input, controls, now_utc)


verify = verify_phase6_av_admission
