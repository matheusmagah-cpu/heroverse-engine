"""Observable, fail-closed preparation for current operational proofs.

The proof must hash every protected source immediately before and after the
isolated regression.  This helper deliberately does not cache or narrow that
population.  It only exposes bounded progress so a long legitimate hash pass
cannot be mistaken for an inactive proof process.
"""
from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from . import maintenance_paused_application as paused
from . import maintenance_protocol as protocol


ProgressSink = Callable[[dict[str, Any]], None]


def _emit(progress: ProgressSink | None, event: dict[str, Any]) -> None:
    """Telemetry is never allowed to invalidate the authenticated capture."""
    if progress is None:
        return
    try:
        progress(event)
    except Exception:
        # Progress is diagnostic only.  The complete before/after snapshots
        # remain the authoritative proof and must not be abandoned because a
        # Windows file rename for a status record is temporarily unavailable.
        return


def protected_paths(root: Path) -> list[Path]:
    """Return the exact existing proof population, in deterministic order."""
    return sorted(set(paused._operational_paths(root)) | set(protocol._paused_cancel_database_files(root)))


def capture_preservation(root: Path, *, progress: ProgressSink | None = None,
                         progress_every: int = 64) -> dict[str, Any]:
    """Reopen and hash every protected file while reporting non-authoritative progress."""
    root = Path(root).resolve()
    started = time.monotonic()
    host = paused._host_observation(root)
    # Keep capture deterministic even when an integration supplies a custom
    # population (for example, a test fixture or a future protocol adapter).
    paths = sorted(protected_paths(root))
    files: dict[str, str] = {}
    total = len(paths)
    _emit(progress, {"stage": "preservation", "state": "STARTED", "total_files": total})
    for index, relative in enumerate(paths, start=1):
        files[relative.as_posix()] = protocol.file_hash(root / relative)
        if index == total or index % progress_every == 0:
            _emit(progress, {"stage": "preservation", "state": "RUNNING", "completed_files": index,
                             "total_files": total, "elapsed_seconds": round(time.monotonic() - started, 3)})
    result = {
        "operation": "PAUSED", "task_enabled": host.get("task_enabled"),
        "automation_paused": host.get("automation_paused"), "files": files,
    }
    _emit(progress, {"stage": "preservation", "state": "COMPLETED", "total_files": total,
                     "elapsed_seconds": round(time.monotonic() - started, 3)})
    return result
