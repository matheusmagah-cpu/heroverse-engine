from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .creative_direction import choose_format_pack, load_format_packs
from .phase6_packaging_compiler import packaging_search_is_reproducible
from .phase6_production import verify_preproduction_receipt, verify_historical_preproduction_receipt

from .phase6_publicity import metadata_publicity_risks
from .phase6_asset_residency import verify_phase6_asset_residency
from .phase6_semantic_preflight import (
    require_semantic_contract,
    semantic_candidate_compatibility,
)
from .phase6_visual_preflight import require_visual_contract
from .phase6_render_contract import PALETTE_QP1_SEGMENT_RENDERER
from .asset_quality_phase5 import scoped_typography_reads


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
VIDEO2_ID = "phase6-video-002-prepublication"
VIDEO2_TREATMENT_TARGET_ID = "phase6-video-2-prepublication"
CANARY_VIDEO_ID = "iK_5edYQtx8"
BASE = Path("output/operations/phase6/release")
PRODUCTION_INPUT_RECEIPTS = BASE / "production-input-receipts"
PRODUCTION_ARTIFACT_ARCHIVES = BASE / "production-artifact-archives"
PRODUCTION_ARTIFACT_ARCHIVE_RECEIPTS = BASE / "production-artifact-archive-receipts"
VIDEO2_ROOT = Path("output/production/phase6/video-002")
PACKAGE_ROOT = Path("output/production/phase6/canary-package-update")
RIGHTS_OK = {
    "OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL",
    "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED",
}
RELEASE_CONTRACT_VERSION = "1.3.0"
EVIDENCE_ROLES = [
    "TREATMENT_ORDER", "FORMAT_SCOPE", "PREPRODUCTION_RECEIPT", "PILOT_PLAN",
    "FORMAT_PACK", "PIPELINE", "ASSET_LIBRARY",
]


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write_immutable(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    """Create a content-stable receipt without ever replacing an existing identity."""

    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").replace("\n", os.linesep).encode("utf-8")
    if path.is_file():
        if path.read_bytes() != encoded:
            raise PermissionError(f"immutable receipt collision: {path.name}")
        return _read(path)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(encoded)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != encoded:
                raise PermissionError(f"immutable receipt collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)
    return _read(path)


def _write_immutable_bytes(path: Path, payload: bytes, *, label: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable {label} collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise PermissionError(f"immutable {label} collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)


def _archive_current_production_inputs_before_overwrite(
    root: Path, *, created_at: str
) -> dict[str, Any] | None:
    """Preserve every byte bound to the current media command before recompilation."""

    latest = root / BASE / "latest-production-inputs-receipt.json"
    if not latest.is_file():
        return None
    current = _read(latest)
    _validate(root, "phase6_production_inputs_receipt.schema.json", current)
    if current.get("action") != "PREPARE_VIDEO_2_INPUTS":
        return None
    immutable_input = (
        root / PRODUCTION_INPUT_RECEIPTS / f"{current['receipt_id']}.json"
    ).resolve()
    if not immutable_input.is_file() or immutable_input.read_bytes() != latest.read_bytes():
        raise PermissionError(
            "current production inputs are not byte-identical to their immutable receipt"
        )
    expected_parent = (root / VIDEO2_ROOT / "production").resolve()
    expected_names = {
        "creative_direction_decision.json",
        "channel_style_bible.json",
        "creative_treatment_plan.json",
        "asset_allocation.json",
        "take_plan.json",
    }
    artifact_names = [
        Path(str(item.get("path") or "")).name
        for item in current.get("artifacts") or []
    ]
    if len(artifact_names) != len(expected_names) or set(artifact_names) != expected_names:
        raise PermissionError(
            "current production receipt does not bind the exact five production artifacts"
        )
    archived: list[dict[str, Any]] = []
    for item in current.get("artifacts") or []:
        source = (root / str(item.get("path") or "")).resolve()
        if source.parent != expected_parent or not source.is_file():
            raise PermissionError("current production artifact escaped its exact output root")
        payload = source.read_bytes()
        content_hash = "sha256:" + hashlib.sha256(payload).hexdigest()
        if (
            content_hash != item.get("sha256")
            or len(payload) != int(item.get("size_bytes") or -1)
        ):
            raise PermissionError(
                f"current production artifact drifted before archive: {source.name}"
            )
        target = (
            root
            / PRODUCTION_ARTIFACT_ARCHIVES
            / str(current["receipt_id"])
            / source.name
        )
        _write_immutable_bytes(target, payload, label="production artifact archive")
        if target.read_bytes() != payload:
            raise PermissionError(
                f"production artifact archive verification failed: {source.name}"
            )
        archived.append(
            {
                "original_path": _relative(root, source),
                "archive_path": _relative(root, target),
                "sha256": content_hash,
                "size_bytes": len(payload),
            }
        )
    source_sha256 = "sha256:" + _sha256(immutable_input)
    archive_id = _stable_id(
        "phase6-production-artifact-archive",
        str(current["receipt_id"]),
        source_sha256,
        *[item["sha256"] for item in archived],
    )
    receipt = {
        "schema_version": "1.0.0",
        "receipt_id": archive_id,
        "status": "ARCHIVED_BEFORE_OVERWRITE",
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "production_input_receipt": {
            "receipt_id": current["receipt_id"],
            "path": _relative(root, immutable_input),
            "sha256": source_sha256,
        },
        "artifacts": archived,
        "control": {
            "all_source_hashes_verified": True,
            "all_archive_bytes_verified": True,
            "overwrite_not_started": True,
            "publication_authorized": False,
            "technical_cost_brl": 0,
        },
        "created_at": created_at,
    }
    _validate(root, "phase6_production_artifact_archive_receipt.schema.json", receipt)
    receipt_path = root / PRODUCTION_ARTIFACT_ARCHIVE_RECEIPTS / f"{archive_id}.json"
    if receipt_path.is_file():
        existing = _read(receipt_path)
        _validate(
            root,
            "phase6_production_artifact_archive_receipt.schema.json",
            existing,
        )
        replay = dict(receipt)
        replay["created_at"] = existing["created_at"]
        if existing != replay:
            raise PermissionError(
                f"production artifact archive receipt replay diverged: {archive_id}"
            )
        return existing
    return _write_immutable(receipt_path, receipt)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _stable_id(prefix: str, *parts: str) -> str:
    payload = "|".join(parts)
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:20]}"


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _gate(name: str, status: str, evidence: list[str], reason: str) -> dict[str, Any]:
    return {"gate": name, "status": status, "evidence": evidence, "reason": reason}


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _confined(root: Path, path: Path, *, label: str) -> Path:
    resolved = path.resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"{label} escaped project root: {path}") from exc
    return resolved


def _content_id(prefix: str, value: dict[str, Any], *, id_key: str) -> str:
    content = dict(value)
    content.pop(id_key, None)
    content.pop("created_at", None)
    encoded = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}-{hashlib.sha256(encoded).hexdigest()[:24]}"


def _resolve_confined(root: Path, value: str, base: Path) -> Path:
    candidate = Path(value)
    candidate = candidate if candidate.is_absolute() else root / candidate
    resolved = candidate.resolve()
    try:
        resolved.relative_to((root / base).resolve())
    except ValueError as exc:
        raise PermissionError(f"production-input artifact escaped its branch: {value}") from exc
    return resolved


def _evidence_sources(root: Path) -> dict[str, Path]:
    return {
        "TREATMENT_ORDER": root / "output/operations/phase6/production/latest-order.json",
        "FORMAT_SCOPE": root / "output/operations/phase6/production/format-scope-receipt.json",
        "PREPRODUCTION_RECEIPT": root / "output/operations/phase6/production/latest-preproduction-receipt.json",
        "PILOT_PLAN": root / "output/operations/phase6/pilot-plan.json",
        "FORMAT_PACK": root / "config/format_packs/fp-broll-cinematic-narration-v1.json",
        "PIPELINE": root / "config/macro_pipelines/pipeline-clips-longform-v1.json",
        "ASSET_LIBRARY": root / "output/production/phase6/shared-assets/asset_manifest.json",
    }


def _evidence_identity(role: str, value: dict[str, Any]) -> str:
    keys = {
        "TREATMENT_ORDER": "order_id", "FORMAT_SCOPE": "receipt_id",
        "PREPRODUCTION_RECEIPT": "receipt_id", "PILOT_PLAN": "plan_id",
        "FORMAT_PACK": "format_pack_id", "PIPELINE": "pipeline_id",
        "ASSET_LIBRARY": "library_id",
    }
    return str(value.get(keys[role]) or "")


def _freeze_evidence_binding(root: Path, role: str, source: Path) -> dict[str, Any]:
    source = _confined(root, source, label=f"{role} source")
    if not source.is_file():
        raise FileNotFoundError(f"{role} source is missing: {_relative(root, source)}")
    raw = source.read_bytes()
    value = json.loads(raw.decode("utf-8-sig"))
    digest = hashlib.sha256(raw).hexdigest()
    if role == "TREATMENT_ORDER":
        immutable = root / "output/operations/phase6/production/orders" / f"{value.get('order_id')}.json"
        if not immutable.is_file() or immutable.read_bytes() != raw:
            raise PermissionError("latest treatment order differs from its immutable twin")
    elif role == "FORMAT_SCOPE":
        immutable = root / "output/operations/phase6/production/format-scope-receipts" / f"{value.get('receipt_id')}.json"
        if not immutable.is_file() or immutable.read_bytes() != raw:
            raise PermissionError("latest format scope differs from its immutable twin")
    elif role == "PREPRODUCTION_RECEIPT" and value.get("schema_version") == "1.1.0":
        immutable = root / "output/operations/phase6/production/preproduction-receipts" / f"{value.get('receipt_id')}.json"
        if not immutable.is_file() or immutable.read_bytes() != raw:
            raise PermissionError("latest preproduction receipt differs from its immutable twin")
    else:
        immutable = root / BASE / "evidence-snapshots" / f"{role.lower()}-{digest}.json"
        _write_immutable_bytes(immutable, raw, label=f"{role} evidence snapshot")
    immutable = _confined(root, immutable, label=f"{role} immutable evidence")
    if immutable.read_bytes() != raw:
        raise PermissionError(f"{role} immutable evidence is not byte-identical")
    identity = _evidence_identity(role, value)
    if not identity:
        raise PermissionError(f"{role} evidence has no stable identity")
    return {
        "role": role, "source_path": _relative(root, source),
        "immutable_path": _relative(root, immutable),
        "sha256": f"sha256:{digest}", "size_bytes": len(raw), "identity": identity,
    }


def _verify_release_evidence_bindings(
    root: Path,
    work_order: dict[str, Any],
    *,
    consume_frozen: bool = False,
    historical_identity_only: bool = False,
) -> dict[str, dict[str, Any]]:
    """Verify the work-order chain at creation or historical consumption.

    Creation still reopens each authoritative mutable source and requires it to
    equal the just-frozen immutable twin.  Once a production-input receipt has
    been created, later consumers use the path identity recorded for that
    source but validate content exclusively from the pinned immutable bytes.
    This keeps cumulative receipts usable after a legitimate ``latest`` view
    advances, without permitting path substitution or mutable fallback.
    """
    if historical_identity_only and not consume_frozen:
        raise PermissionError("historical identity verification requires frozen evidence")
    bindings = work_order.get("evidence_bindings") or []
    if [item.get("role") for item in bindings] != EVIDENCE_ROLES:
        raise PermissionError("release work order lacks the exact ordered evidence-binding chain")
    expected_sources = _evidence_sources(root)
    values: dict[str, dict[str, Any]] = {}
    schemas = {
        "TREATMENT_ORDER": "phase6_treatment_order.schema.json",
        "FORMAT_SCOPE": "phase6_format_scope_receipt.schema.json",
        "PREPRODUCTION_RECEIPT": "phase6_preproduction_receipt.schema.json",
        "PILOT_PLAN": "phase6_pilot_plan.schema.json",
        "FORMAT_PACK": "format_pack.schema.json",
        "PIPELINE": "macro_pipeline.schema.json",
    }
    for binding in bindings:
        role = binding["role"]
        expected_source_path = _relative(root, expected_sources[role])
        if binding.get("source_path") != expected_source_path:
            raise PermissionError(f"{role} evidence path is missing or not authoritative")
        source = _confined(root, root / binding["source_path"], label=f"{role} source")
        immutable = _confined(root, root / binding["immutable_path"], label=f"{role} immutable evidence")
        if source != expected_sources[role].resolve() or not immutable.is_file():
            raise PermissionError(f"{role} evidence path is missing or not authoritative")
        raw = immutable.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if f"sha256:{digest}" != binding["sha256"] or len(raw) != binding["size_bytes"]:
            raise PermissionError(f"{role} evidence bytes/hash/size diverged")
        if not consume_frozen:
            if not source.is_file() or source.read_bytes() != raw:
                raise PermissionError(f"{role} current source differs from its immutable twin")
        value = json.loads(raw.decode("utf-8-sig"))
        if role == "TREATMENT_ORDER":
            expected_immutable = root / "output/operations/phase6/production/orders" / f"{value.get('order_id')}.json"
        elif role == "FORMAT_SCOPE":
            expected_immutable = root / "output/operations/phase6/production/format-scope-receipts" / f"{value.get('receipt_id')}.json"
        elif role == "PREPRODUCTION_RECEIPT" and value.get("schema_version") == "1.1.0":
            expected_immutable = root / "output/operations/phase6/production/preproduction-receipts" / f"{value.get('receipt_id')}.json"
        else:
            expected_immutable = root / BASE / "evidence-snapshots" / f"{role.lower()}-{digest}.json"
        if immutable != expected_immutable.resolve():
            raise PermissionError(f"{role} immutable twin is outside its exact content-addressed location")
        if role in schemas:
            _validate(root, schemas[role], value)
        if _evidence_identity(role, value) != binding["identity"]:
            raise PermissionError(f"{role} evidence identity diverged")
        values[role] = value
    order, scope, preprod = values["TREATMENT_ORDER"], values["FORMAT_SCOPE"], values["PREPRODUCTION_RECEIPT"]
    plan, pack, pipeline, library = values["PILOT_PLAN"], values["FORMAT_PACK"], values["PIPELINE"], values["ASSET_LIBRARY"]
    if (
        order.get("status") != "READY_TO_COMPILE"
        or scope.get("status") != "AUTHORIZED"
        or preprod.get("status") != "COMPILED"
        or preprod.get("order_id") != order.get("order_id")
        or scope.get("receipt_id") != order.get("execution_contract", {}).get("scope_receipt_id")
        or plan.get("status") != "ACTIVE"
        or plan.get("channel", {}).get("channel_id") != CHANNEL_ID
        or pack.get("format_pack_id") != "fp-broll-cinematic-narration"
        or pack.get("version") != "1.1.0"
        or pack.get("capability_status") != "LIMITED"
        or pack.get("production_allowed") is not True
        or pipeline.get("pipeline_id") != "pipeline-clips-longform-v1"
        or pipeline.get("version") != "1.0.0"
        or pipeline.get("status") != "LIMITED"
        or library.get("library_id") != "phase6-heroverse-rights-library-v1"
    ):
        raise PermissionError("release evidence chain no longer authorizes compilation")
    if preprod.get("schema_version") == "1.1.0":
        preproduction_binding = next(
            item for item in bindings if item["role"] == "PREPRODUCTION_RECEIPT"
        )
        verifier = (verify_historical_preproduction_receipt
                    if historical_identity_only else verify_preproduction_receipt)
        options = ({"expected_sha256": preproduction_binding["sha256"]}
                   if historical_identity_only else {"require_current_views": not consume_frozen})
        verifier(
            root,
            receipt_path=preproduction_binding["immutable_path"],
            expected_order_id=str(order["order_id"]),
            expected_receipt_id=str(preprod["receipt_id"]),
            **options,
        )
    return values


def verify_production_inputs_receipt(
    root: Path = ROOT,
    *,
    receipt_path: str | Path | None = None,
    expected_receipt_id: str | None = None,
    required_action: str | None = None,
    ensure_immutable: bool = False,
    recheck_decode: bool = False,
) -> dict[str, Any]:
    """Recompute receipt identity and verify every bound input and source receipt.

    The optional migration flag may create the immutable twin only after the legacy
    latest view, all artifacts and asset-residency evidence have passed in full.
    """

    root = root.resolve()
    latest = root / BASE / "latest-production-inputs-receipt.json"
    source = Path(receipt_path) if receipt_path is not None else latest
    source = source if source.is_absolute() else root / source
    if not source.is_file():
        raise FileNotFoundError(f"production-input receipt missing: {_relative(root, source)}")
    receipt = _read(source)
    _validate(root, "phase6_production_inputs_receipt.schema.json", receipt)
    if expected_receipt_id is not None and receipt.get("receipt_id") != expected_receipt_id:
        raise PermissionError("production-input receipt identity mismatch")
    if required_action is not None and receipt.get("action") != required_action:
        raise PermissionError("production-input receipt belongs to another action")

    work_order_binding = receipt.get("work_order")
    bound_work_order: dict[str, Any] | None = None
    if receipt.get("schema_version") == "1.2.0":
        if not isinstance(work_order_binding, dict):
            raise PermissionError("production inputs lack an immutable release work-order binding")
        work_path = _resolve_confined(root, str(work_order_binding.get("path") or ""), BASE / "work-orders")
        if work_path.parent != (root / BASE / "work-orders").resolve() or work_path.name != f"{receipt['work_order_id']}.json" or not work_path.is_file():
            raise PermissionError("production inputs point outside the immutable work-order directory")
        if f"sha256:{_sha256(work_path)}" != work_order_binding.get("sha256") or work_path.stat().st_size != work_order_binding.get("size_bytes"):
            raise PermissionError("immutable release work-order hash/size mismatch")
        bound_work_order = _read(work_path)
        _validate(root, "phase6_release_work_order.schema.json", bound_work_order)
        if bound_work_order.get("work_order_id") != receipt["work_order_id"] or bound_work_order.get("status") != "READY_TO_PREPARE" or bound_work_order.get("action") != receipt["action"]:
            raise PermissionError("immutable release work order identity/status/action mismatch")
        _verify_release_evidence_bindings(root, bound_work_order, consume_frozen=True)
        if receipt.get("evidence_bindings") != bound_work_order.get("evidence_bindings"):
            raise PermissionError("production inputs do not preserve the work-order evidence chain")

    if receipt["action"] == "PREPARE_VIDEO_2_INPUTS":
        branch = VIDEO2_ROOT / "production"
        expected_names = [
            "creative_direction_decision.json",
            "channel_style_bible.json",
            "creative_treatment_plan.json",
            "asset_allocation.json",
            "take_plan.json",
        ]
    else:
        branch = PACKAGE_ROOT / "evaluation"
        expected_names = ["packaging_evaluation.json"]

    records = receipt.get("artifacts") or []
    names = [Path(str(item.get("path") or "")).name for item in records]
    if names != expected_names or len(names) != len(set(names)):
        raise PermissionError("production-input artifact set/order is not the exact release contract")
    resolved_by_name: dict[str, Path] = {}
    for record, name in zip(records, names):
        path = _resolve_confined(root, str(record["path"]), branch)
        if not path.is_file():
            raise FileNotFoundError(f"production-input artifact missing: {record['path']}")
        actual_hash = f"sha256:{_sha256(path)}"
        if actual_hash != record["sha256"] or path.stat().st_size != record["size_bytes"]:
            raise PermissionError(f"production-input integrity mismatch: {record['path']}")
        resolved_by_name[name] = path

    binding = receipt.get("asset_residency")
    if not isinstance(binding, dict):
        raise PermissionError("production inputs lack an immutable asset-residency binding")
    required_asset_ids: list[str] | None = None
    if receipt["action"] == "PREPARE_VIDEO_2_INPUTS":
        allocation = _read(resolved_by_name["asset_allocation.json"])
        required_asset_ids = [str(item["asset_id"]) for item in allocation.get("takes") or []]
        if not required_asset_ids or len(required_asset_ids) != len(allocation.get("takes") or []):
            raise PermissionError("production allocation contains no complete asset identity set")
    residency = verify_phase6_asset_residency(
        root,
        receipt_path=binding.get("receipt_path"),
        expected_sha256=binding.get("sha256"),
        expected_audit_id=binding.get("audit_id"),
        required_asset_ids=required_asset_ids,
        recheck_media=True,
        recheck_decode=recheck_decode,
    )
    if residency.get("manifest_content_hash") != binding.get("manifest_content_hash"):
        raise PermissionError("production-input residency manifest binding diverged")

    if receipt.get("schema_version") == "1.2.0":
        expected_id = _stable_id(
            "phase6-production-inputs", receipt["work_order_id"], work_order_binding["sha256"],
            binding["sha256"], *[item["sha256"] for item in receipt["evidence_bindings"]],
            *[item["sha256"] for item in records],
        )
    else:
        expected_id = _stable_id(
            "phase6-production-inputs", receipt["work_order_id"], binding["sha256"],
            *[item["sha256"] for item in records],
        )
    if receipt["receipt_id"] != expected_id:
        raise PermissionError("production-input receipt_id does not match its bound hashes")

    immutable = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt['receipt_id']}.json"
    if immutable.is_file():
        if immutable.read_bytes() != source.read_bytes():
            raise PermissionError("production-input latest view differs from its immutable twin")
    elif ensure_immutable:
        _write_immutable(immutable, receipt)
        if immutable.read_bytes() != source.read_bytes():
            raise PermissionError("production-input immutable migration was not byte-identical")
    else:
        raise FileNotFoundError("immutable production-input receipt is missing")
    return receipt


def _artifact_integrity(root: Path, receipt: dict[str, Any]) -> tuple[bool, list[str]]:
    evidence: list[str] = []
    for record in receipt.get("artifacts", []):
        path = root / record.get("path", "")
        if not path.is_file():
            return False, [f"missing:{record.get('path')}"]
        actual_hash = _sha256(path)
        actual_size = path.stat().st_size
        expected_hash = str(record.get("sha256", "")).removeprefix("sha256:")
        if actual_hash != expected_hash or actual_size != record.get("size_bytes"):
            return False, [f"integrity-mismatch:{record.get('path')}"]
        if receipt.get("schema_version") == "1.1.0":
            immutable = root / str(record.get("immutable_path") or "")
            if not immutable.is_file():
                return False, [f"missing:{record.get('immutable_path')}"]
            if (
                _sha256(immutable) != expected_hash
                or immutable.stat().st_size != record.get("size_bytes")
                or immutable.read_bytes() != path.read_bytes()
            ):
                return False, [f"immutable-integrity-mismatch:{record.get('immutable_path')}"]
            evidence.append(record["immutable_path"])
        evidence.append(record["path"])
    return bool(evidence), evidence or ["preproduction-receipt#no-artifacts"]


def _toolchain(root: Path) -> tuple[bool, list[str]]:
    candidates = {
        "ffmpeg": [root / "tools/ffmpeg/ffmpeg.exe", Path(r"C:\ffmpeg\bin\ffmpeg.exe")],
        "ffprobe": [root / "tools/ffmpeg/ffprobe.exe", Path(r"C:\ffmpeg\bin\ffprobe.exe")],
        "kokoro-model": [root / "models/kokoro/kokoro-v1.0.fp16.onnx"],
        "kokoro-voices": [root / "models/kokoro/voices-v1.0.bin"],
    }
    evidence: list[str] = []
    for name, paths in candidates.items():
        found = next((path for path in paths if path.is_file() and path.stat().st_size > 0), None)
        if found is None:
            return False, [f"missing-local-tool:{name}"]
        evidence.append(f"{name}:{_relative(root, found)}")
    return True, evidence


def _oauth_and_quota(root: Path) -> tuple[bool, list[str]]:
    health_path = root / "output/runtime/gestor-central/oauth-session-health.json"
    quota_path = root / "output/integrations/youtube/heroverse/quota-observation.json"
    if not health_path.is_file() or not quota_path.is_file():
        return False, [
            _relative(root, health_path), _relative(root, quota_path),
        ]
    health, quota = _read(health_path), _read(quota_path)
    ok = (
        health.get("status") in {"HEALTHY", "REFRESHED"}
        and health.get("noninteractive") is True
        and health.get("channel_id") == CHANNEL_ID
        and health.get("identity_verified") is True
        and health.get("user_intervention_required") is False
        and quota.get("status") == "PASS"
        and quota.get("billing_enabled") is False
    )
    return ok, [_relative(root, health_path), _relative(root, quota_path)]


def _library_path(root: Path) -> Path:
    expanded = root / "output/production/phase6/shared-assets/asset_manifest.json"
    receipt_path = root / "output/production/phase6/shared-assets/asset_library_expansion.json"
    if expanded.is_file() and receipt_path.is_file():
        try:
            receipt = _read(receipt_path)
            _validate(root, "phase6_asset_library_expansion.schema.json", receipt)
            if (
                receipt.get("status") == "COMPLETE"
                and receipt.get("manifest", {}).get("sha256") == "sha256:" + _sha256(expanded)
            ):
                return expanded
        except Exception as exc:
            raise PermissionError(f"phase6 expanded asset library is invalid: {type(exc).__name__}:{exc}") from exc
    raise FileNotFoundError("phase6 expanded asset library and its expansion receipt are required")


def _rights_library(root: Path) -> tuple[bool, list[str]]:
    try:
        path = _library_path(root)
    except Exception as exc:
        return False, [f"phase6-library:{type(exc).__name__}:{exc}"]
    if not path.is_file():
        return False, [_relative(root, path)]
    manifest = _read(path)
    assets = manifest.get("assets", [])
    eligible = [
        item for item in assets
        if item.get("production_eligible") is True
        and item.get("commercial_use") is True
        and item.get("rights_status") in RIGHTS_OK
        and item.get("content_quality_gate") == "PASS"
        and not metadata_publicity_risks(item)
    ]
    for asset in eligible:
        if str(asset.get('source','')).startswith('procedural://heroverse/typography/'):
            from .asset_quality_phase5 import verify_typography_asset_admission
            verify_typography_asset_admission(root,asset)
    return len(eligible) >= 12, [_relative(root, path), f"eligible-assets:{len(eligible)}"]


@scoped_typography_reads
def build_release_work_order(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    timestamp = created_at or _stamp()
    order_path = root / "output/operations/phase6/production/latest-order.json"
    scope_path = root / "output/operations/phase6/production/format-scope-receipt.json"
    receipt_path = root / "output/operations/phase6/production/latest-preproduction-receipt.json"
    plan_path = root / "output/operations/phase6/pilot-plan.json"
    pack_path = root / "config/format_packs/fp-broll-cinematic-narration-v1.json"
    pipeline_path = root / "config/macro_pipelines/pipeline-clips-longform-v1.json"
    expected_library_path = root / "output/production/phase6/shared-assets/asset_manifest.json"
    try:
        library_path = _library_path(root)
        library_error: str | None = None
    except Exception as exc:
        library_path = expected_library_path
        library_error = f"{type(exc).__name__}:{exc}"
    evidence_refs = [
        _relative(root, order_path), _relative(root, receipt_path), _relative(root, scope_path),
        _relative(root, plan_path), _relative(root, pack_path), _relative(root, pipeline_path),
        _relative(root, library_path), "output/runtime/gestor-central/oauth-session-health.json",
        "output/integrations/youtube/heroverse/quota-observation.json",
        "docs/01_EXECUTION_PROTOCOL.md",
    ]

    order: dict[str, Any] | None = None
    scope: dict[str, Any] | None = None
    receipt: dict[str, Any] | None = None
    order_error = scope_error = receipt_error = None
    try:
        order = _read(order_path)
        _validate(root, "phase6_treatment_order.schema.json", order)
    except Exception as exc:
        order_error = f"{type(exc).__name__}:{exc}"
    try:
        scope = _read(scope_path)
        _validate(root, "phase6_format_scope_receipt.schema.json", scope)
    except Exception as exc:
        scope_error = f"{type(exc).__name__}:{exc}"

    ready_order = order is not None and order.get("status") == "READY_TO_COMPILE"
    if ready_order and receipt_path.is_file():
        try:
            receipt = verify_preproduction_receipt(
                root,
                receipt_path=receipt_path,
                expected_order_id=str(order["order_id"]),
            )
        except Exception as exc:
            receipt_error = f"{type(exc).__name__}:{exc}"

    if order_error:
        order_gate = _gate("TREATMENT_ORDER", "BLOCKED", [_relative(root, order_path)], order_error)
    elif ready_order:
        order_gate = _gate("TREATMENT_ORDER", "PASS", [_relative(root, order_path)], "The exact treatment order is READY_TO_COMPILE.")
    else:
        order_gate = _gate("TREATMENT_ORDER", "WAITING", [_relative(root, order_path)], "The controlled operation has not authorized preproduction yet.")

    if not ready_order:
        receipt_gate = _gate("PREPRODUCTION_RECEIPT", "WAITING", [_relative(root, receipt_path)], "No post-preproduction action is allowed before a ready treatment order.")
        integrity_gate = _gate("PREPRODUCTION_INTEGRITY", "WAITING", [_relative(root, receipt_path)], "Artifact hashes are checked only after the exact preproduction receipt exists.")
    elif receipt_error:
        receipt_gate = _gate("PREPRODUCTION_RECEIPT", "BLOCKED", [_relative(root, receipt_path)], receipt_error)
        integrity_gate = _gate("PREPRODUCTION_INTEGRITY", "BLOCKED", [_relative(root, receipt_path)], "An invalid receipt cannot authorize downstream artifacts.")
    elif receipt is None:
        receipt_gate = _gate("PREPRODUCTION_RECEIPT", "WAITING", [_relative(root, receipt_path)], "The transactional preproduction compiler has not produced the receipt.")
        integrity_gate = _gate("PREPRODUCTION_INTEGRITY", "WAITING", [_relative(root, receipt_path)], "Wait for receipt-bound artifact hashes.")
    else:
        receipt_ok = receipt.get("status") == "COMPILED" and receipt.get("order_id") == order.get("order_id")
        receipt_gate = _gate("PREPRODUCTION_RECEIPT", "PASS" if receipt_ok else "BLOCKED", [_relative(root, receipt_path)], "Receipt matches the current treatment order." if receipt_ok else "Receipt is stale or does not match the current treatment order.")
        integrity_ok, integrity_evidence = _artifact_integrity(root, receipt)
        integrity_gate = _gate("PREPRODUCTION_INTEGRITY", "PASS" if integrity_ok else "BLOCKED", integrity_evidence, "Every preproduction artifact hash and size matches its receipt." if integrity_ok else "A receipt-bound preproduction artifact is missing or changed.")

    scope_ok = bool(
        ready_order and scope and order
        and scope.get("status") == "AUTHORIZED"
        and scope.get("receipt_id") == order.get("execution_contract", {}).get("scope_receipt_id")
        and scope.get("baseline_snapshot_id") == order.get("baseline", {}).get("snapshot_id")
    )
    if scope_error:
        scope_gate = _gate("FORMAT_SCOPE_EXACT", "BLOCKED", [_relative(root, scope_path)], scope_error)
    elif not ready_order:
        scope_gate = _gate("FORMAT_SCOPE_EXACT", "WAITING", [_relative(root, scope_path)], "The LIMITED overlay awaits the eligible 24-hour decision.")
    else:
        scope_gate = _gate("FORMAT_SCOPE_EXACT", "PASS" if scope_ok else "BLOCKED", [_relative(root, scope_path)], "The versioned LIMITED overlay authorizes this exact baseline and action." if scope_ok else "The LIMITED overlay is absent, stale or divergent.")

    action = "WAIT"
    output_root: str | None = None
    expected_outputs: list[str] = []
    target_ok = False
    if receipt and order:
        if receipt.get("action") == "COMPILE_VIDEO_2" and scope and scope.get("target_video_id") == VIDEO2_TREATMENT_TARGET_ID and scope.get("video_ordinal") == 2:
            action, target_ok = "PREPARE_VIDEO_2_INPUTS", True
            output_root = VIDEO2_ROOT.as_posix()
            expected_outputs = [
                f"{output_root}/production/creative_direction_decision.json",
                f"{output_root}/production/channel_style_bible.json",
                f"{output_root}/production/creative_treatment_plan.json",
                f"{output_root}/production/asset_allocation.json",
                f"{output_root}/production/take_plan.json",
                f"{output_root}/production/production_inputs_receipt.json",
            ]
        elif receipt.get("action") == "COMPILE_CANARY_PACKAGE_UPDATE" and scope and scope.get("target_video_id") == CANARY_VIDEO_ID and scope.get("video_ordinal") == 1:
            action, target_ok = "EVALUATE_CANARY_PACKAGE", True
            output_root = PACKAGE_ROOT.as_posix()
            expected_outputs = [
                f"{output_root}/evaluation/packaging_evaluation.json",
                f"{output_root}/evaluation/production_inputs_receipt.json",
            ]
    target_status = "PASS" if target_ok else ("WAITING" if receipt is None else "BLOCKED")
    target_gate = _gate("TARGET_AND_ACTION", target_status, [_relative(root, receipt_path), _relative(root, scope_path)], "Receipt, target identity and ordinal select exactly one downstream branch." if target_ok else "Wait for or repair the exact receipt/scope target identity.")

    try:
        plan, pack, pipeline = _read(plan_path), _read(pack_path), _read(pipeline_path)
        pin_ok = (
            plan.get("status") == "ACTIVE"
            and plan.get("channel", {}).get("channel_id") == CHANNEL_ID
            and pack.get("format_pack_id") == "fp-broll-cinematic-narration"
            and pack.get("version") == "1.1.0"
            and pack.get("capability_status") == "LIMITED"
            and pack.get("production_allowed") is True
            and pipeline.get("pipeline_id") == "pipeline-clips-longform-v1"
            and pipeline.get("version") == "1.0.0"
            and pipeline.get("status") == "LIMITED"
        )
    except Exception:
        pin_ok = False
    pin_gate = _gate("FORMATPACK_PIPELINE_PROFILE", "PASS" if pin_ok else "BLOCKED", [_relative(root, plan_path), _relative(root, pack_path), _relative(root, pipeline_path)], "Exact LIMITED pack, pipeline and STANDARD plan are pinned." if pin_ok else "Pack, pipeline or plan drift was detected.")

    rights_ok, rights_evidence = _rights_library(root)
    residency_binding: dict[str, Any] | None = None
    residency_error: str | None = None
    if library_error is None:
        try:
            residency = verify_phase6_asset_residency(root, recheck_media=ready_order)
            residency_binding = {
                key: residency[key]
                for key in ("audit_id", "receipt_path", "sha256", "manifest_content_hash")
            }
            rights_evidence.extend([
                residency_binding["receipt_path"],
                f"residency-sha256:{residency_binding['sha256']}",
            ])
        except Exception as exc:
            residency_error = f"{type(exc).__name__}:{exc}"
            rights_evidence.append(f"asset-residency:{residency_error}")
    else:
        residency_error = library_error
    rights_ready = rights_ok and residency_binding is not None
    rights_status = "PASS" if rights_ready else ("BLOCKED" if ready_order else "WAITING")
    rights_gate = _gate(
        "RIGHTS_LIBRARY",
        rights_status,
        rights_evidence,
        "The Phase 6 library and exact immutable residency receipt were revalidated before enqueue."
        if rights_ready
        else "The Phase 6 rights library or its immutable residency proof is unavailable or divergent.",
    )
    tools_ok, tool_evidence = _toolchain(root)
    tools_gate = _gate("LOCAL_TOOLCHAIN", "PASS" if tools_ok else "BLOCKED", tool_evidence, "FFmpeg, ffprobe and the local voice model are present." if tools_ok else "A mandatory free/local production component is missing.")
    oauth_ok, oauth_evidence = _oauth_and_quota(root)
    remote_status = "PASS" if oauth_ok else ("WAITING" if not ready_order else "BLOCKED")
    oauth_gate = _gate("OAUTH_CHANNEL_AND_FREE_QUOTA", remote_status, oauth_evidence, "Noninteractive exact-channel OAuth and a no-billing quota observation are healthy." if oauth_ok else "Exact-channel OAuth or the no-billing quota proof is not currently healthy.")
    zero_gate = _gate("ZERO_TECHNICAL_COST", "PASS", ["config/engine.json#cost_policy", "docs/STATE.md#custo"], "All work is local/free and technical cost is fixed at R$ 0.00.")
    publication_gate = _gate("PUBLICATION_LOCK", "PASS", ["docs/01_EXECUTION_PROTOCOL.md", "output/operations/phase6/pilot-plan.json"], "This work order prepares production inputs only; it cannot publish or spend.")
    originality_gate = _gate("ORIGINALITY_CHAIN", "PASS" if pin_ok else "BLOCKED", ["config/format_packs/fp-broll-cinematic-narration-v1.json", "output/modeling/phase4/channel-model-v1/channel_model.json"], "Original narration and a new semantic sequence are mandatory; reference identity and wording remain prohibited.")
    evidence_bindings: list[dict[str, Any]] = []
    binding_error: str | None = None
    if ready_order:
        try:
            sources = _evidence_sources(root)
            evidence_bindings = [_freeze_evidence_binding(root, role, sources[role]) for role in EVIDENCE_ROLES]
        except Exception as exc:
            binding_error = f"{type(exc).__name__}:{exc}"
            evidence_bindings = []
    binding_status = "PASS" if len(evidence_bindings) == len(EVIDENCE_ROLES) else ("BLOCKED" if ready_order else "WAITING")
    binding_gate = _gate(
        "IMMUTABLE_EVIDENCE_CHAIN", binding_status,
        [item["immutable_path"] for item in evidence_bindings] or [_relative(root, order_path)],
        "Order, scope, preproduction, plan, pack, pipeline and library are byte-identical to confined immutable snapshots."
        if binding_status == "PASS" else (binding_error or "The immutable evidence chain awaits an eligible order."),
    )
    gates = [order_gate, receipt_gate, integrity_gate, scope_gate, target_gate, pin_gate, rights_gate, tools_gate, oauth_gate, zero_gate, publication_gate, originality_gate, binding_gate]
    if any(item["status"] == "BLOCKED" for item in gates):
        status = "BLOCKED"
        action = "WAIT"
    elif any(item["status"] == "WAITING" for item in gates):
        status = "WAITING_FOR_PREPRODUCTION"
        action = "WAIT"
    else:
        status = "READY_TO_PREPARE"

    order_id = order.get("order_id") if order else None
    receipt_id = receipt.get("receipt_id") if receipt else None
    scope_id = scope.get("receipt_id") if scope else None
    work_order_id = _stable_id(
        "phase6-release-work-order", order_id or "waiting", receipt_id or "waiting",
        scope_id or "waiting", action, _relative(root, library_path),
        residency_binding["sha256"] if residency_binding else "residency-waiting",
        *[f"{item['role']}:{item['source_path']}:{item['immutable_path']}:{item['sha256']}:{item['identity']}" for item in evidence_bindings],
        RELEASE_CONTRACT_VERSION,
    )
    value = {
        "schema_version": "1.3.0", "contract_version": RELEASE_CONTRACT_VERSION,
        "work_order_id": work_order_id,
        "operation_id": OPERATION_ID, "phase": 6, "channel_id": CHANNEL_ID,
        "status": status, "action": action, "treatment_order_id": order_id,
        "preproduction_receipt_id": receipt_id, "format_scope_receipt_id": scope_id,
        "asset_residency": residency_binding,
        "evidence_bindings": evidence_bindings,
        "gates": gates,
        "execution_contract": {
            "idempotency_key": f"{work_order_id}:prepare", "maximum_attempts": 3,
            "stages": ["verify immutable evidence", "compile creative and continuity contracts", "allocate rights-bound source ranges", "validate and receipt production inputs"],
        },
        "output_root": output_root, "expected_outputs": expected_outputs,
        "publication_authorized": False, "technical_cost_brl": 0,
        "evidence_refs": evidence_refs, "created_at": timestamp,
    }
    _validate(root, "phase6_release_work_order.schema.json", value)
    return value


def materialize_release_work_order(root: Path = ROOT, *, created_at: str | None = None) -> Path:
    root = root.resolve()
    value = build_release_work_order(root, created_at=created_at)
    latest = root / BASE / "latest-work-order.json"
    immutable = root / BASE / "work-orders" / f"{value['work_order_id']}.json"
    if immutable.is_file():
        before, after = _read(immutable), dict(value)
        before.pop("created_at", None)
        after.pop("created_at", None)
        if before != after:
            raise PermissionError(f"immutable release work-order collision: {value['work_order_id']}")
        value = _read(immutable)
    else:
        _write_immutable(immutable, value)
    _write(latest, value)
    return latest


def _subtract(intervals: list[tuple[int, int]], exclusions: list[tuple[int, int]]) -> list[tuple[int, int]]:
    result = intervals
    for excluded_start, excluded_end in exclusions:
        next_result: list[tuple[int, int]] = []
        for start, end in result:
            if excluded_end <= start or excluded_start >= end:
                next_result.append((start, end))
            else:
                if start < excluded_start:
                    next_result.append((start, excluded_start))
                if excluded_end < end:
                    next_result.append((excluded_end, end))
        result = next_result
    return [(start, end) for start, end in result if end > start]


def _resolve_asset_path(root: Path, uri: str) -> Path:
    path = Path(uri)
    if path.is_file():
        return path
    anchors = ("output", "assets", "models")
    parts = list(path.parts)
    for anchor in anchors:
        if anchor in parts:
            candidate = root.joinpath(*parts[parts.index(anchor):])
            if candidate.is_file():
                return candidate
    return path


def _typography_allocation_preimage(root: Path, manifest: dict[str, Any], blueprint: dict[str, Any]) -> dict[str, Any] | None:
    """A take-scoped correction preserves the other frozen source intervals.

    Derive the preimage from authenticated source intent, never from an
    unpinned mutable allocation or caller-supplied PASS. Legacy catalogs retain
    their original full-allocation behavior.
    """
    if not manifest.get('typography_adoptions'):
        return None
    from .asset_quality_phase5 import _pinned_json
    from .procedural_infographics_phase5 import read_typography_source_manifest
    def pinned(binding):
        path = Path(binding['path'])
        return _pinned_json(root, path if path.is_absolute() else root/path, binding['sha256'])
    found = None
    seen = set()
    for admission in manifest['typography_adoptions']:
        offered = pinned(admission)
        ids = offered['typography_successor']['asset_ids']
        selected = [a for a in offered['assets'] if a['asset_id'] in ids]
        if not ids or [a['asset_id'] for a in selected] != ids:
            raise PermissionError('typography allocation admission population differs')
        for asset in selected:
            ref = asset['typography_content_admission']
            report = pinned(ref)
            rights = next(r for r in report['rights'] if r['asset_id'] == asset['asset_id'])
            evidence = pinned(rights)
            source_ref = evidence['source_manifest']
            key = (source_ref['path'], source_ref['sha256'])
            if key in seen:
                continue
            seen.add(key)
            source = read_typography_source_manifest(root, Path(key[0]), expected_sha256=key[1])
            original = str((root/VIDEO2_ROOT/'production/asset_allocation.json').resolve())
            matches = [r for r in source['manifest']['input_snapshots'] if r['original_path'] == original]
            if len(matches) != 1:
                raise PermissionError('typography frozen allocation absent or ambiguous')
            candidate = pinned(matches[0])
            if found is not None and found != candidate:
                raise PermissionError('typography frozen allocations disagree')
            found = candidate
    if found is None:
        raise PermissionError('typography frozen allocation missing')
    _validate(root, 'phase6_asset_allocation.schema.json', found)
    if (found['allocation_id'] != _stable_id('phase6-allocation', blueprint['blueprint_id'],
            *[f"{a['asset_id']}:{a['source_start_ms']}:{a['source_end_ms']}" for a in found['takes']])
            or [a['take_id'] for a in found['takes']] != [t['take_id'] for t in blueprint['takes']]
            or any(a['duration_ms'] != t['end_ms']-t['start_ms'] or a['required_role'] != t['semantic_role']
                   for a,t in zip(found['takes'],blueprint['takes']))):
        raise PermissionError('typography frozen allocation does not bind the current blueprint')
    return found


@scoped_typography_reads
def _allocate_assets(root: Path, blueprint: dict[str, Any], created_at: str,
                     *, preserved_allocation: dict[str, Any] | None = None) -> dict[str, Any]:
    manifest_path = _library_path(root)
    manifest = _read(manifest_path)
    assets = [
        item for item in manifest.get("assets", [])
        if item.get("production_eligible") is True
        and item.get("commercial_use") is True
        and item.get("rights_status") in RIGHTS_OK
        and item.get("content_quality_gate") == "PASS"
        and not metadata_publicity_risks(item)
    ]
    takes = blueprint["takes"]
    total_runtime = int(blueprint["total_estimated_duration_ms"])
    per_asset_cap = int(total_runtime * 0.089)
    pools: dict[str, list[tuple[int, int]]] = {}
    asset_paths: dict[str, Path] = {}
    verified: dict[str, str] = {}
    for asset in assets:
        asset_id = asset["asset_id"]
        safe = [(int(item["start_ms"]), int(item["end_ms"])) for item in asset.get("safe_ranges", [])]
        prior = [(int(item["start_ms"]), int(item["end_ms"])) for item in asset.get("used_ranges", [])]
        pools[asset_id] = _subtract(safe, prior)
        path = _resolve_asset_path(root, asset["uri"])
        if not path.is_file():
            continue
        actual = "sha256:" + _sha256(path)
        if actual != asset.get("content_hash"):
            raise PermissionError(f"asset hash mismatch: {asset_id}")
        rights_path = _resolve_asset_path(root, asset["rights_evidence_uri"])
        if not rights_path.is_file():
            raise PermissionError(f"rights evidence missing: {asset_id}")
        if str(asset.get('source','')).startswith('procedural://heroverse/typography/'):
            from .phase6_asset_residency import validate_phase6_rights_evidence
            validate_phase6_rights_evidence(root,asset,_read(rights_path),media_path=path)
        asset_paths[asset_id] = path
        verified[asset_id] = actual

    runtime_by_asset: Counter[str] = Counter()
    count_by_asset: Counter[str] = Counter()
    allocations: list[dict[str, Any]] = []
    by_id = {item["asset_id"]: item for item in assets}
    preserved = {a['take_id']: a for a in preserved_allocation['takes']} if preserved_allocation else {}
    for take in takes:
        duration = int(take["end_ms"]) - int(take["start_ms"])
        required = take["semantic_role"]
        # An admitted replacement is bound to this exact take. Capacity or a
        # missing file must fail closed, not silently select the old source.
        scoped=[item for item in assets if take['take_id'] in (item.get('take_scope') or [])]
        prior = preserved.get(take['take_id']) if not scoped else None
        semantic_candidates = [
            item
            for item in (scoped or assets)
            if item["asset_id"] in asset_paths
            and (prior is None or item['asset_id'] == prior['asset_id'])
            and (item.get('take_scope') is None or take['take_id'] in item['take_scope'])
            and semantic_candidate_compatibility(
                required, item["semantic_role"]
            )["eligible"]
        ]
        compatible = [
            item for item in semantic_candidates
            if runtime_by_asset[item["asset_id"]] + duration <= per_asset_cap
            and count_by_asset[item["asset_id"]] < 5
            and item["asset_id"] != (allocations[-1]["asset_id"] if allocations else None)
            and sum(1 for prior in allocations if prior["asset_id"] == item["asset_id"] and prior["timeline_start_ms"] >= int(take["start_ms"]) - 60_000) < 3
            and any(end - start >= duration and (prior is None or
                    start <= prior['source_start_ms'] < prior['source_end_ms'] <= end
                    and prior['source_end_ms']-prior['source_start_ms'] == duration)
                    for start, end in pools[item["asset_id"]])
        ]
        if not compatible:
            role_counts = Counter(str(item.get("semantic_role") or "<missing>") for item in assets)
            if semantic_candidates:
                policy_class = "SEMANTIC_ROLE_CAPACITY_EXHAUSTED"
                policy_statement = (
                    "eligible role identities exist but every candidate violates "
                    "a range, adjacency, reuse or runtime constraint"
                )
                candidate_diagnostic = [
                    f"{item['asset_id']}:{item['semantic_role']}:"
                    f"uses={count_by_asset[item['asset_id']]}:"
                    f"runtime={runtime_by_asset[item['asset_id']]}:"
                    f"max_range={max((end-start for start,end in pools[item['asset_id']]), default=0)}"
                    for item in semantic_candidates
                ]
            else:
                policy = semantic_candidate_compatibility(required, "<no-exact-role>")
                policy_class = str(policy["classification"])
                policy_statement = str(policy["statement"])
                candidate_diagnostic = []
            raise PermissionError(
                f"no rights-safe nonrepeating source range for {take['take_id']}:{required}; "
                f"semantic_policy={policy_class}:{policy_statement}; "
                f"eligible_candidates={candidate_diagnostic}; "
                f"available_role_counts={dict(sorted(role_counts.items()))}"
            )
        compatible.sort(key=lambda item: (
            0
            if semantic_candidate_compatibility(
                required, item["semantic_role"]
            )["classification"] == "EXACT_ROLE_IDENTITY"
            else 1,
            count_by_asset[item["asset_id"]], runtime_by_asset[item["asset_id"]], item["asset_id"],
        ))
        asset = compatible[0]
        asset_id = asset["asset_id"]
        interval_index, (source_start, source_limit) = next(
            (index, interval) for index, interval in enumerate(pools[asset_id])
            if interval[1] - interval[0] >= duration and (prior is None or
               interval[0] <= prior['source_start_ms'] < prior['source_end_ms'] <= interval[1])
        )
        interval_start = source_start
        if prior is not None:
            source_start = prior['source_start_ms']
        source_end = source_start + duration
        remainder = []
        if interval_start < source_start:
            remainder.append((interval_start, source_start))
        if source_end < source_limit:
            remainder.append((source_end, source_limit))
        pools[asset_id] = pools[asset_id][:interval_index] + remainder + pools[asset_id][interval_index + 1:]
        runtime_by_asset[asset_id] += duration
        count_by_asset[asset_id] += 1
        compatibility = semantic_candidate_compatibility(
            required, asset["semantic_role"]
        )["statement"]
        allocations.append({
            "take_id": take["take_id"], "required_role": required,
            "asset_id": asset_id, "asset_role": asset["semantic_role"],
            "compatibility": compatibility, "source_path": _relative(root, asset_paths[asset_id]),
            "source_start_ms": source_start, "source_end_ms": source_end,
            "duration_ms": duration, "content_hash": verified[asset_id],
            "rights_status": asset["rights_status"],
            "rights_evidence_ref": _relative(root, _resolve_asset_path(root, asset["rights_evidence_uri"])),
            "prior_episode_overlap_ms": 0,
            "timeline_start_ms": int(take["start_ms"]),
        })
        if prior is not None and {k:v for k,v in allocations[-1].items() if k != 'timeline_start_ms'} != prior:
            raise PermissionError('typography correction changed an unaffected allocation')

    shares = sorted((duration / total_runtime for duration in runtime_by_asset.values()), reverse=True)
    rolling_max = 1
    for current in allocations:
        rolling_max = max(rolling_max, sum(
            1 for prior in allocations
            if prior["asset_id"] == current["asset_id"]
            and current["timeline_start_ms"] - 60_000 <= prior["timeline_start_ms"] <= current["timeline_start_ms"]
        ))
    output_takes = [{key: value for key, value in item.items() if key != "timeline_start_ms"} for item in allocations]
    value = {
        "schema_version": "1.0.0",
        "allocation_id": _stable_id("phase6-allocation", blueprint["blueprint_id"], *[f"{item['asset_id']}:{item['source_start_ms']}:{item['source_end_ms']}" for item in output_takes]),
        "video_id": VIDEO2_ID, "source_library_id": manifest["library_id"], "takes": output_takes,
        "measurements": {
            "total_runtime_ms": total_runtime, "unique_asset_count": len(runtime_by_asset),
            "maximum_single_asset_runtime_share": round(max(shares), 6),
            "top_six_asset_runtime_share": round(sum(shares[:6]), 6),
            "maximum_asset_reuse_count": max(count_by_asset.values()),
            "maximum_rolling_60s_same_asset_count": rolling_max,
            "adjacent_repeat_count": 0, "prior_episode_overlap_ms": 0,
            "hash_verified_asset_count": len(verified),
        },
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": created_at,
    }
    if value["measurements"]["unique_asset_count"] < 12:
        raise PermissionError("long-form allocation did not achieve the required twelve-source diversity floor")
    _validate(root, "phase6_asset_allocation.schema.json", value)
    return value


def _creative_decision(root: Path, order: dict[str, Any], brief: dict[str, Any], script: dict[str, Any], work: dict[str, Any], created_at: str) -> dict[str, Any]:
    evidence = [
        "output/operations/phase6/production/format-scope-receipt.json",
        "config/format_packs/fp-broll-cinematic-narration-v1.json",
        "config/macro_pipelines/pipeline-clips-longform-v1.json",
        "output/modeling/phase4/channel-model-v1/channel_model.json",
        "output/production/phase6/video-002/preproduction/editorial_brief.json",
        "output/production/phase6/video-002/preproduction/narrative_script.json",
        "output/production/phase6/video-002/preproduction/creative_concept_decision.json",
    ]
    channel_model = _read(root / "output/modeling/phase4/channel-model-v1/channel_model.json")
    packs = load_format_packs(root / "config/format_packs", root / "schemas/format_pack.schema.json")
    decision = choose_format_pack(
        command={"command_id": work["work_order_id"], "objective_id": OPERATION_ID},
        policy_decision={"decision": "ALLOW"}, channel_model=channel_model,
        brief=brief, packs=packs, purpose="PRODUCTION",
        budget_envelope_id="zero-technical-cost-phase6-v1",
        quality_profile="STANDARD", created_at=created_at,
    )
    if decision["decision"] != "SELECT" or not decision["selected_format_pack"]:
        raise PermissionError("no evidence-scored FormatPack is eligible for Phase 6 Video 2")
    selected = decision["selected_format_pack"]
    if selected["format_pack_id"] != "fp-broll-cinematic-narration" or selected["version"] != "1.1.0":
        raise PermissionError("FormatPack selection drifted outside the exact Phase 6 LIMITED scope")
    decision["decision_id"] = _stable_id("phase6-creative-decision", order["order_id"], brief["brief_id"], script["script_id"])
    decision["central_command_id"] = work["work_order_id"]
    decision["channel_id"] = CHANNEL_ID
    decision["narrative_id"] = script["script_id"]
    decision["evidence_refs"] = sorted(set([*decision["evidence_refs"], *evidence]))
    decision["selected_format_pack"]["limitation_match"] = "Phase 6 Video 2 only after the exact 24-hour scope receipt; no capability promotion."
    decision["hypothesis"] = {
        "statement": order["treatment"]["success_metric"],
        "predicted_metric": order["treatment"]["success_metric"],
        "baseline_ref": order["baseline"]["snapshot_id"],
        "prediction_ref": "output/operations/phase6/intelligence/predictions/latest.json",
        "falsification_condition": order["treatment"]["failure_rule"],
    }
    decision["risks"] = sorted(set([
        *decision["risks"], "LIMITED capability", "single-video exploratory comparison",
        "public response and YPP decision are not controllable",
    ]))
    return decision


def _derive_style_bible(root: Path, decision: dict[str, Any], allocation: dict[str, Any], created_at: str) -> dict[str, Any]:
    source = _read(root / "output/production/phase5/pilot-001/creative-v3/channel_style_bible.json")
    source["style_bible_id"] = _stable_id("phase6-style-bible", source["style_bible_id"], decision["decision_id"], allocation["allocation_id"])
    source["channel_id"] = CHANNEL_ID
    source["version"] = "3.3.0-phase6-video2"
    source["decision_history"].append({
        "decision_id": decision["decision_id"],
        "change": "Pinned the v3.2 HeroVerse identity to the Phase 6 Video 2 allocation without changing palette, typography, lens, lighting or continuity grammar.",
        "reason": "The controlled experiment may change only the preregistered treatment variable; visual identity remains locked.",
        "evidence_refs": ["output/operations/phase6/release/latest-work-order.json", "output/production/phase6/video-002/production/asset_allocation.json"],
        "created_at": created_at,
    })
    selected = {item["asset_id"] for item in allocation["takes"]}
    manifest = _read(_library_path(root))
    source["reference_assets"] = [{
        "reference_id": item["asset_id"], "uri": _relative(root, _resolve_asset_path(root, item["uri"])),
        "hash": item["content_hash"], "rights_ref": _relative(root, _resolve_asset_path(root, item["rights_evidence_uri"])),
        "purpose": item["semantic_role"],
    } for item in manifest["assets"] if item["asset_id"] in selected]
    source["created_at"] = created_at
    return source


_FRAMEWORK_STATE_ORDER = {
    "HIDDEN": 0, "INTRODUCED": 1, "TRUTH": 2,
    "RESPONSIBILITY": 3, "TODAY": 4, "COMPLETE": 5,
}


def _framework_hint(index: int, take: dict[str, Any], total: int) -> str | None:
    """Return only an evidence-backed advancement of the video framework.

    Ordinary takes deliberately return ``None``: the prior state must remain
    visible rather than regressing to INTRODUCED between milestones.
    """
    if index == 0 or index == 1:
        return "HIDDEN"
    if index == 2:
        return "INTRODUCED"
    if index == total - 1:
        return "COMPLETE"
    role = str(take.get("semantic_role") or "")
    narration = str(take.get("narration") or "").casefold()
    if role == "truth_test_infographic":
        return "TRUTH"
    if role == "responsibility_map_infographic" or "responsible action" in narration:
        return "RESPONSIBILITY"
    if role == "today_timeline_infographic" or "completed today" in narration:
        return "TODAY"
    return None


def _treatment_for_take(index: int, take: dict[str, Any], total: int) -> tuple[str, str, str, bool, str | None]:
    if index == 0:
        return "HOOK_STAMP", "LEFT_HERO", "IMPACT", True, _framework_hint(index, take, total)
    if index == 1:
        return "HOOK_QUESTION", "LOWER_LEFT", "PULSE", True, _framework_hint(index, take, total)
    if index == 2:
        return "HOOK_FRAMEWORK", "FRAMEWORK_BAR", "WHOOSH", True, _framework_hint(index, take, total)
    if index == total - 1:
        return "PAYOFF_RESOLUTION", "CENTER_PAYOFF", "RESOLUTION", True, _framework_hint(index, take, total)
    role = take["semantic_role"]
    if "infographic" in role or role == "decision_cards":
        return "FRAMEWORK_STEP", "FRAMEWORK_BAR", "PEN", True, _framework_hint(index, take, total)
    if take.get("on_screen_text"):
        return "SECTION_CARD", "LOWER_LEFT", "IMPACT", True, _framework_hint(index, take, total)
    return "CINEMATIC_BODY", "NONE", "NONE", index % 6 == 0, _framework_hint(index, take, total)


def _creative_treatment(order: dict[str, Any], blueprint: dict[str, Any], created_at: str) -> dict[str, Any]:
    takes = []
    framework_state = "HIDDEN"
    for index, take in enumerate(blueprint["takes"]):
        treatment, layout, sfx, interrupt, hint = _treatment_for_take(index, take, len(blueprint["takes"]))
        if hint is not None:
            if _FRAMEWORK_STATE_ORDER[hint] < _FRAMEWORK_STATE_ORDER[framework_state]:
                raise PermissionError(
                    f"framework state regression in treatment producer at {take['take_id']}: "
                    f"{framework_state}->{hint}"
                )
            framework_state = hint
        takes.append({
            "take_id": take["take_id"], "treatment": treatment, "text_layout": layout,
            "visual_event_count": 2 if index < 3 else 1, "pattern_interrupt": interrupt,
            "framework_state": framework_state, "sfx": sfx, "synthetic_disclosure": False,
            "evidence_refs": ["output/production/phase6/video-002/preproduction/take_blueprint.json", f"take:{take['take_id']}:semantic_role={take['semantic_role']}"],
        })
    windows = []
    for window, start, end, visual_min, audio_min in (
        ("0_1S", 0, 1000, 1, 1), ("1_3S", 1000, 3000, 1, 1),
        ("3_8S", 3000, 8000, 2, 1), ("8_30S", 8000, 30000, 5, 2),
    ):
        ids = [item["take_id"] for item in blueprint["takes"] if item["start_ms"] < end and item["end_ms"] > start]
        windows.append({"window": window, "visual_events_minimum": visual_min, "audio_events_minimum": audio_min, "proof": f"Take-level narrative and semantic source coverage for {window}.", "take_ids": ids})
    return {
        "schema_version": "1.0.0", "treatment_plan_id": _stable_id("phase6-creative-treatment", order["order_id"], blueprint["blueprint_id"]),
        "version": "1.0.0", "video_id": VIDEO2_ID, "channel_id": CHANNEL_ID, "order_id": order["order_id"],
        "format_pack_id": "fp-broll-cinematic-narration", "format_pack_version": "1.1.0",
        "grammar": {
            "motif": "THRESHOLD_TO_STEP", "accent_hex": "#D7A94A", "framework": ["TRUTH", "RESPONSIBILITY", "TODAY"],
            "text_rule": "Use locked typography only at structural turns, maximum two lines inside the eight-percent safe area.",
            "semantic_rule": "Every source must prove the narrated claim or action; unrelated beauty footage is prohibited.",
            "rhythm_rule": "Four functional events in 0-8 seconds, five in 8-30 seconds and no information gap above 25 seconds.",
        },
        "hook_contract": windows, "takes": takes,
        "measurement_contract": {
            "minimum_hook_visual_events": 4, "minimum_8_30_visual_events": 5,
            "maximum_body_take_ms": 7000, "maximum_pattern_interrupt_gap_ms": 25000,
            "maximum_single_asset_runtime_share": 0.1, "maximum_top_six_asset_runtime_share": 0.55,
            "maximum_asset_reuse_count": 5, "maximum_rolling_60s_same_asset_count": 3,
            "concrete_claim_visual_coverage": 1.0,
        },
        "publication_authorized": False, "created_at": created_at,
    }


def _required_overlay_copy(source: dict[str, Any], treated: dict[str, Any], bible: dict[str, Any]) -> str | None:
    """Derive compact, deterministic copy for treatments that require text.

    TakePlan remains the authority for the primary text layer.  The locked
    Bible framework is rendered separately for the hook, so it must never
    overwrite the editorial NAME/TEST/CHOOSE promise.
    """
    existing = source.get("on_screen_text")
    if isinstance(existing, str) and existing.strip():
        return existing
    kind = treated["treatment"]
    if kind == "HOOK_FRAMEWORK":
        raise PermissionError("HOOK_FRAMEWORK requires explicit blueprint copy; it cannot be inferred from Style Bible")
    if kind == "PAYOFF_RESOLUTION":
        return "CHOOSE THE FAITHFUL MOVE"
    if kind != "FRAMEWORK_STEP":
        return None
    narration = str(source.get("narration") or "").lower()
    truth_cards = (
        ("in the first", "FIRST: FACT"), ("what happened", "FACT: WHAT HAPPENED"),
        ("in the second", "SECOND: MEANING"), ("fear says", "MEANING: FEAR'S STORY"),
        ("meeting changed", "FACT: MEETING CHANGED"), ("future is ruined", "FORECAST: FUTURE RUINED"),
        ("not replied", "FACT: NO REPLY YET"), ("always be abandoned", "FORECAST: ALWAYS ABANDONED"),
        ("does not deny pain", "TRUTH: PAIN IS REAL"), ("whole future", "TRUTH: FUTURE UNWRITTEN"),
    )
    decision_cards = (
        ("name the fact", "NAME THE FACT"), ("test the meaning", "TEST THE MEANING"),
        ("character", "TEST AGAINST CHARACTER"), ("consequences", "TEST CONSEQUENCES"),
        ("wise counsel", "ASK WISE COUNSEL"), ("choose one", "CHOOSE TODAY'S MOVE"),
        ("record what happened", "RECORD THE RESULT"), ("fear edits", "CHECK THE EVIDENCE"),
        ("only exhausted", "KEEP WHAT IS TRUE"),
    )
    for needle, copy in truth_cards + decision_cards:
        if needle in narration:
            return copy
    state = treated.get("framework_state")
    if state == "TRUTH":
        return "TRUTH: FACT OR FORECAST"
    if state == "RESPONSIBILITY":
        return "RESPONSIBILITY: ONE ACTION"
    if state == "TODAY":
        return "TODAY: CHOOSE ONE MOVE"
    return "NAME / TEST / CHOOSE"


def _take_plan(decision: dict[str, Any], bible: dict[str, Any], blueprint: dict[str, Any], allocation: dict[str, Any], treatment: dict[str, Any], created_at: str) -> dict[str, Any]:
    by_take = {item["take_id"]: item for item in allocation["takes"]}
    by_treatment = {item["take_id"]: item for item in treatment["takes"]}
    takes = []
    for source in blueprint["takes"]:
        allocated, treated = by_take[source["take_id"]], by_treatment[source["take_id"]]
        media_type = "INFOGRAPHIC" if "infographic" in allocated["asset_role"] or allocated["asset_role"] == "decision_cards" else "CLIP"
        takes.append({
            "take_id": source["take_id"], "start_ms": source["start_ms"], "end_ms": source["end_ms"],
            "narrative_function": source["narrative_function"], "information": source["visual_job"],
            "intended_emotion": "urgent clarity" if source["start_ms"] < 8000 else "earned agency",
            "media_type": media_type, "visual_format": "documentary-cinematic rights-bound clip",
            "format_pack_id": "fp-broll-cinematic-narration",
            "composition": "single focal subject with protected text-safe negative space",
            "camera": "source-native 24-50mm-equivalent framing; no synthetic camera claim",
            "movement": "motivated source movement or restrained local push-in",
            "lighting": "cool controlled tension progressing toward warm payoff",
            "character": None, "environment": "env-tension" if source["start_ms"] < 30000 else "env-clarity",
            "action": source["visual_job"], "on_screen_text": _required_overlay_copy(source, treated, bible),
            "narration": source.get("narration"), "music": "original-local-ambient-bed-v1",
            "sound_effect": None if treated["sfx"] == "NONE" else treated["sfx"].lower(),
            "transition_in": "cut" if source["start_ms"] else None,
            "transition_out": "fade" if source["end_ms"] == blueprint["total_estimated_duration_ms"] else "cut",
            "asset_origin": f"{allocated['source_path']}#t={allocated['source_start_ms'] / 1000:.3f},{allocated['source_end_ms'] / 1000:.3f}",
            "rights": {"status": allocated["rights_status"], "evidence_ref": allocated["rights_evidence_ref"]},
            "tool_adapter_id": "adapter-ffmpeg-local", "tool_version": "runtime-probed-before-render",
            "cost": 0, "take_version": "1.0.0",
            "quality_criteria": ["semantic proof", "continuity", "no critical artifact", "text safe area", "audio-image timing"],
            "semantic_alignment": allocated["compatibility"], "retention_job": source["retention_job"],
            "continuity_refs": [bible["style_bible_id"], "CONT-001", "CONT-002", "CONT-003", "CONT-005"],
        })
    coverage = [{
        "window": item["window"], "take_ids": item["take_ids"],
        "promise_function": item["proof"], "gate_status": "PASS",
        "evidence_refs": [f"creative-treatment:{treatment['treatment_plan_id']}", "preproduction:narrative_script.json"],
    } for item in treatment["hook_contract"]]
    return {
        "schema_version": "1.0.0", "take_plan_id": _stable_id("phase6-take-plan", decision["decision_id"], allocation["allocation_id"], PALETTE_QP1_SEGMENT_RENDERER),
        "render_profile": PALETTE_QP1_SEGMENT_RENDERER,
        "channel_id": CHANNEL_ID, "video_id": VIDEO2_ID,
        "creative_direction_decision_id": decision["decision_id"],
        "format_pack_id": "fp-broll-cinematic-narration", "format_pack_version": "1.1.0",
        "style_bible_id": bible["style_bible_id"], "quality_profile": "STANDARD",
        "takes": takes, "hook_window_coverage": coverage,
        "total_cost": {"currency": "BRL", "external": 0, "local_status": "UNAVAILABLE"},
        "created_at": created_at,
    }


def _evaluate_package(root: Path, work: dict[str, Any], receipt: dict[str, Any], order: dict[str, Any], created_at: str) -> tuple[list[Path], dict[str, Any]]:
    variants_path = root / PACKAGE_ROOT / "preproduction/packaging_variants.json"
    bundle = _read(variants_path)
    decision = _read(root / PACKAGE_ROOT / "preproduction/creative_concept_decision.json")
    _validate(root, "phase6_packaging_variants.schema.json", bundle)
    _validate(root, "phase6_packaging_concept_decision.schema.json", decision)
    signal = _read(root / "output/production/phase5/pilot-001/daily_signal_snapshot.json")
    matches = [
        item for item in signal.get("candidates") or []
        if item.get("candidate_id") == order["market_candidate"]["candidate_id"]
    ]
    if len(matches) != 1:
        raise PermissionError("packaging market candidate identity is not unique")
    reproducible = packaging_search_is_reproducible(
        decision, bundle, root=root, order=order, candidate=matches[0], signal=signal,
        baseline_script=_read(root / "output/production/phase5/pilot-001/creative-v3/narrative_script.json"),
        baseline_package=_read(root / "output/production/phase5/pilot-001/creative-v3/publication_package.json"),
    )
    if not reproducible:
        raise PermissionError("packaging creative search is not independently reproducible")
    variants = bundle["variants"]
    banned = re.compile(r"\b(guaranteed|miracle|god told|will happen|instant|secret)\b", re.I)
    promise_terms = {"action", "step", "test", "truth", "responsible", "today", "prayer", "amen"}
    evaluations = []
    for item in variants:
        title_words = set(re.findall(r"[a-z]+", item["title"].lower()))
        thumb_words = re.findall(r"[A-Za-z]+", item["thumbnail_text"])
        thumb_set = {word.lower() for word in thumb_words}
        promise_words = set(re.findall(r"[a-z]+", item["promise"].lower()))
        overlap = len(title_words & thumb_set) / max(1, len(title_words | thumb_set))
        action_terms = {"action", "step", "stop", "take", "move", "test", "today"}
        tension_terms = {"isn", "don", "until", "after", "complete", "stop"}
        spiritual_terms = {"prayer", "pray", "prayed", "praying", "amen", "faith", "christian"}
        checks = {
            "title_length": 35 <= len(item["title"]) <= 100,
            "thumbnail_word_count": 2 <= len(thumb_words) <= 5,
            "policy_language": banned.search(item["title"] + " " + item["thumbnail_text"] + " " + item["promise"]) is None,
            "promise_delivery": bool((title_words | set(word.lower() for word in thumb_words) | promise_words) & promise_terms),
        }
        creative_dimensions = {
            "complementary_title_thumbnail": overlap <= 0.20,
            "direct_action_signal": bool((title_words | thumb_set) & action_terms),
            "specific_spiritual_anchor": bool((title_words | thumb_set) & spiritual_terms),
            "honest_tension_or_open_loop": bool((title_words | thumb_set) & tension_terms),
        }
        pass_count = sum(checks.values())
        creative_score = sum(creative_dimensions.values())
        evaluations.append({
            "variant_id": item["variant_id"], "checks": checks,
            "creative_dimensions": creative_dimensions,
            "title_thumbnail_token_overlap": round(overlap, 6),
            "pass_count": pass_count, "total_checks": len(checks),
            "creative_score": creative_score, "creative_total": len(creative_dimensions),
            "preproduction_score": item["selection_score"],
            "status": "PASS" if pass_count == len(checks) else "FAIL",
        })
    passed = [item for item in evaluations if item["status"] == "PASS"]
    if not passed:
        raise PermissionError("no packaging variant passed accuracy, policy and legibility gates")
    selected = sorted(passed, key=lambda item: (-item["creative_score"], -item["preproduction_score"], item["title_thumbnail_token_overlap"], item["variant_id"]))[0]["variant_id"]
    evaluation = {
        "schema_version": "1.0.0", "evaluation_id": _stable_id("phase6-package-evaluation", work["work_order_id"], selected),
        "video_id": CANARY_VIDEO_ID, "baseline_preserved": True,
        "creative_concept_decision_id": decision["decision_id"], "search_reproducible": reproducible,
        "evaluations": evaluations,
        "selected_variant": selected, "selection_rule": "All mechanical gates must pass; then maximize complementary copy, direct action, spiritual specificity and honest tension, minimize title-thumbnail token duplication, and use variant id only as final deterministic tie-break. This is not a performance prediction.",
        "public_metadata_changed": False, "publication_authorized": False, "technical_cost_brl": 0,
        "created_at": created_at,
    }
    output = root / PACKAGE_ROOT / "evaluation/packaging_evaluation.json"
    _write(output, evaluation)
    return [output], evaluation


@scoped_typography_reads
def compile_release_inputs(work_order: dict[str, Any], root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    _validate(root, "phase6_release_work_order.schema.json", work_order)
    if work_order["status"] != "READY_TO_PREPARE" or work_order["action"] == "WAIT":
        raise PermissionError("release work order is not ready to prepare")
    residency_binding = work_order.get("asset_residency")
    if not isinstance(residency_binding, dict):
        raise PermissionError("release work order is not bound to an immutable asset-residency receipt")
    current_work_order = build_release_work_order(root, created_at=work_order["created_at"])
    if current_work_order != work_order:
        raise PermissionError("release work order no longer matches recomputed current gates and evidence")
    expected_work_order_id = _stable_id(
        "phase6-release-work-order",
        work_order.get("treatment_order_id") or "waiting",
        work_order.get("preproduction_receipt_id") or "waiting",
        work_order.get("format_scope_receipt_id") or "waiting",
        work_order["action"],
        _relative(root, _library_path(root)),
        residency_binding["sha256"],
        *[f"{item['role']}:{item['source_path']}:{item['immutable_path']}:{item['sha256']}:{item['identity']}" for item in work_order.get("evidence_bindings") or []],
        RELEASE_CONTRACT_VERSION,
    )
    if work_order.get("work_order_id") != expected_work_order_id:
        raise PermissionError("release work-order identity does not match its bound inputs")
    immutable_work_order = root / BASE / "work-orders" / f"{work_order['work_order_id']}.json"
    work_order = _write_immutable(immutable_work_order, work_order)
    _write(root / BASE / "latest-work-order.json", work_order)
    evidence_values = _verify_release_evidence_bindings(root, work_order)
    timestamp = created_at or _stamp()
    order = evidence_values["TREATMENT_ORDER"]
    preprod = evidence_values["PREPRODUCTION_RECEIPT"]
    integrity_ok, integrity_evidence = _artifact_integrity(root, preprod)
    if not integrity_ok or order["order_id"] != work_order["treatment_order_id"] or preprod["receipt_id"] != work_order["preproduction_receipt_id"]:
        raise PermissionError("immutable treatment/preproduction identity or artifact integrity failed")
    verified_residency = verify_phase6_asset_residency(
        root,
        receipt_path=residency_binding.get("receipt_path"),
        expected_sha256=residency_binding.get("sha256"),
        expected_audit_id=residency_binding.get("audit_id"),
        recheck_media=True,
    )
    if verified_residency.get("manifest_content_hash") != residency_binding.get("manifest_content_hash"):
        raise PermissionError("release asset-residency manifest binding diverged")

    paths: list[Path]
    measurements: dict[str, Any]
    if work_order["action"] == "PREPARE_VIDEO_2_INPUTS":
        pre = root / VIDEO2_ROOT / "preproduction"
        output = root / VIDEO2_ROOT / "production"
        brief, script, blueprint = _read(pre / "editorial_brief.json"), _read(pre / "narrative_script.json"), _read(pre / "take_blueprint.json")
        preservation = _typography_allocation_preimage(root, _read(_library_path(root)), blueprint)
        allocation = (_allocate_assets(root, blueprint, timestamp) if preservation is None else
                      _allocate_assets(root, blueprint, timestamp, preserved_allocation=preservation))
        decision = _creative_decision(root, order, brief, script, work_order, timestamp)
        bible = _derive_style_bible(root, decision, allocation, timestamp)
        treatment = _creative_treatment(order, blueprint, timestamp)
        take_plan = _take_plan(decision, bible, blueprint, allocation, treatment, timestamp)
        _validate(root, "creative_direction_decision.schema.json", decision)
        _validate(root, "visual_continuity_bible.schema.json", bible)
        _validate(root, "phase6_creative_treatment_plan.schema.json", treatment)
        _validate(root, "take_plan.schema.json", take_plan)
        # Recompute role/path/hash authority from blueprint, allocation and the
        # manifest.  A family label or compatibility sentence cannot prove a
        # concrete visual function.  This and the visual gate both run before
        # archiving/overwriting any input or authorizing expensive work.
        require_semantic_contract(
            blueprint,
            allocation,
            _read(_library_path(root)),
            treatment,
            root=root,
            created_at=timestamp,
        )
        require_visual_contract(take_plan, treatment, bible, evidence_root=root)
        values = {
            "creative_direction_decision.json": decision,
            "channel_style_bible.json": bible,
            "creative_treatment_plan.json": treatment,
            "asset_allocation.json": allocation,
            "take_plan.json": take_plan,
        }
        # The mutable production paths are referenced by the prior immutable
        # media command. Preserve and hash-bind those exact bytes before the
        # first overwrite; a drift or incomplete archive fails closed.
        _archive_current_production_inputs_before_overwrite(
            root,
            created_at=timestamp,
        )
        paths = []
        for name, value in values.items():
            path = output / name
            _write(path, value)
            paths.append(path)
        measurements = {
            "take_count": len(take_plan["takes"]),
            "unique_asset_count": allocation["measurements"]["unique_asset_count"],
            "maximum_single_asset_runtime_share": allocation["measurements"]["maximum_single_asset_runtime_share"],
            "top_six_asset_runtime_share": allocation["measurements"]["top_six_asset_runtime_share"],
            "selected_package_variant": None,
        }
        next_action = "SYNTHESIZE_VIDEO_2_VOICE"
        receipt_output = output / "production_inputs_receipt.json"
    else:
        paths, evaluation = _evaluate_package(root, work_order, preprod, order, timestamp)
        measurements = {"take_count": None, "unique_asset_count": None, "maximum_single_asset_runtime_share": None, "top_six_asset_runtime_share": None, "selected_package_variant": evaluation["selected_variant"]}
        next_action = "RENDER_SELECTED_CANARY_THUMBNAIL_SET"
        receipt_output = root / PACKAGE_ROOT / "evaluation/production_inputs_receipt.json"

    # Close the allocation/receipt TOCTOU window: assets and the manifest are
    # re-read after compilation and immediately before hashes become authority.
    required_asset_ids = None
    if work_order["action"] == "PREPARE_VIDEO_2_INPUTS":
        required_asset_ids = [item["asset_id"] for item in allocation.get("takes") or []]
    final_residency = verify_phase6_asset_residency(
        root,
        receipt_path=residency_binding.get("receipt_path"),
        expected_sha256=residency_binding.get("sha256"),
        expected_audit_id=residency_binding.get("audit_id"),
        required_asset_ids=required_asset_ids,
        recheck_media=True,
        recheck_decode=False,
    )
    if final_residency.get("manifest_content_hash") != residency_binding.get("manifest_content_hash"):
        raise PermissionError("release asset-residency binding changed during input compilation")
    records = [{"path": _relative(root, path), "sha256": "sha256:" + _sha256(path), "size_bytes": path.stat().st_size} for path in paths]
    receipt = {
        "schema_version": "1.2.0", "receipt_id": _stable_id(
            "phase6-production-inputs", work_order["work_order_id"], f"sha256:{_sha256(immutable_work_order)}",
            residency_binding["sha256"], *[item["sha256"] for item in work_order["evidence_bindings"]],
            *[item["sha256"] for item in records],
        ),
        "work_order_id": work_order["work_order_id"], "treatment_order_id": order["order_id"],
        "preproduction_receipt_id": preprod["receipt_id"], "action": work_order["action"],
        "status": "COMPILED", "channel_id": CHANNEL_ID, "artifacts": records,
        "asset_residency": residency_binding,
        "work_order": {"path": _relative(root, immutable_work_order), "sha256": f"sha256:{_sha256(immutable_work_order)}", "size_bytes": immutable_work_order.stat().st_size},
        "evidence_bindings": work_order["evidence_bindings"],
        "gates": [
            {"gate": "WORK_ORDER", "status": "PASS", "evidence": [work_order["work_order_id"]]},
            {"gate": "PREPRODUCTION_INTEGRITY", "status": "PASS", "evidence": integrity_evidence},
            {"gate": "FORMATPACK_PIPELINE_IDENTITY", "status": "PASS", "evidence": ["fp-broll-cinematic-narration@1.1.0", "pipeline-clips-longform-v1@1.0.0"]},
            {"gate": "RIGHTS_AND_ORIGINALITY", "status": "PASS", "evidence": [records[0]["path"], residency_binding["receipt_path"], residency_binding["sha256"], "output/operations/phase6/production/format-scope-receipt.json"]},
            {"gate": "ZERO_COST_AND_PUBLICATION_LOCK", "status": "PASS", "evidence": ["technical_cost_brl=0", "publication_authorized=false"]},
        ],
        "measurements": measurements, "next_action": next_action,
        "publication_authorized": False, "technical_cost_brl": 0, "created_at": timestamp,
    }
    _validate(root, "phase6_production_inputs_receipt.schema.json", receipt)
    immutable = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt['receipt_id']}.json"
    receipt = _write_immutable(immutable, receipt)
    _write(receipt_output, receipt)
    latest = root / BASE / "latest-production-inputs-receipt.json"
    _write(latest, receipt)
    verify_production_inputs_receipt(
        root,
        receipt_path=latest,
        expected_receipt_id=receipt["receipt_id"],
        required_action=work_order["action"],
        recheck_decode=False,
    )
    return receipt


def run_phase6_release_preparer(root: Path = ROOT, *, now: datetime | None = None) -> dict[str, Any]:
    from .queue_phase6 import TransactionalQueue

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    timestamp = _stamp(current)
    work_path = materialize_release_work_order(root, created_at=timestamp)
    work = _read(work_path)
    status = "WAITING"
    job_id: str | None = None
    job_state = "NOT_CREATED"
    receipt_path: str | None = None
    error: str | None = None
    next_action = "Wait for the exact treatment and preproduction gates."
    if work["status"] == "BLOCKED":
        status = "BLOCKED"
        next_action = "Repair the recorded critical gate without relaxing scope, rights, quality or cost controls."
    elif work["status"] == "READY_TO_PREPARE":
        queue = TransactionalQueue(root)
        job = queue.enqueue(
            idempotency_key=work["execution_contract"]["idempotency_key"],
            operation_id=OPERATION_ID, channel_id=CHANNEL_ID,
            task_type="PREPARE_PHASE6_RELEASE_INPUTS",
            payload={"work_order_id": work["work_order_id"], "work_order_path": _relative(root, work_path), "action": work["action"]},
            max_attempts=int(work["execution_contract"]["maximum_attempts"]), now=current,
        )
        job_id, job_state = job["job_id"], job["state"]
        if job_state == "SUCCEEDED":
            receipt_path = (job.get("checkpoint") or {}).get("production_inputs_receipt")
            status = "COMPLETED"
            next_action = (job.get("checkpoint") or {}).get("next_action", "Continue to the next quality-gated production stage.")
        else:
            claimed = queue.claim_job(job_id, worker_id=f"gestor-central-release-{os.getpid()}", expected_task_type="PREPARE_PHASE6_RELEASE_INPUTS", lease_seconds=300, now=current)
            if claimed is None:
                status = "RETRY_WAIT" if job_state == "RETRY_WAIT" else "WAITING"
                next_action = "The idempotent release-input job is leased or in its bounded retry window."
            elif claimed["job_id"] != job_id:
                error = f"PHASE6_RELEASE_QUEUE_IDENTITY_MISMATCH:{claimed['job_id']}"
                queue.fail(claimed["job_id"], worker_id=claimed["lease_owner"], error=error, now=current)
                status, next_action = "ERROR", "Preserve the mismatched job and retry only through its own idempotency key."
            else:
                try:
                    receipt = compile_release_inputs(work, root, created_at=work["created_at"])
                    receipt_path = _relative(root, root / BASE / "latest-production-inputs-receipt.json")
                    completed = queue.succeed(job_id, worker_id=claimed["lease_owner"], checkpoint={"production_inputs_receipt": receipt_path, "receipt_id": receipt["receipt_id"], "next_action": receipt["next_action"]}, now=current)
                    job_state, status, next_action = completed["state"], "COMPLETED", receipt["next_action"]
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    failed = queue.fail(job_id, worker_id=claimed["lease_owner"], error=error, checkpoint=claimed.get("checkpoint") or {}, now=current)
                    job_state = failed["state"]
                    status = "BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT"
                    next_action = "Correct the evidenced preparation failure and continue through the bounded transactional retry."
        queue.materialize_snapshot(captured_at=current)
    value = {
        "schema_version": "1.0.0", "executor_id": "heroverse-phase6-release-preparer-v1", "phase": 6,
        "status": status, "work_order_id": work.get("work_order_id"),
        "work_order_status": work.get("status", "UNAVAILABLE"), "action": work.get("action", "WAIT"),
        "job_id": job_id, "job_state": job_state, "receipt": receipt_path,
        "next_action": next_action, "error": error, "technical_cost_brl": 0, "updated_at": timestamp,
    }
    _validate(root, "phase6_release_preparer_runtime.schema.json", value)
    _write(root / BASE / "preparer-status.json", value)
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_release_preparer(ROOT), ensure_ascii=False, indent=2))
