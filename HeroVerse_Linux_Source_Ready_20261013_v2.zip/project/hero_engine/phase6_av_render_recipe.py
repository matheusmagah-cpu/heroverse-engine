"""Pure Stage-C AV command recipe compiler.

This module reads and binds inputs but never writes media, creates a queue job,
or grants execution/publication authority.  Every output path is relative to a
generation directory which may only be assigned by a committed queue
transaction.  The only graph this version can emit is explicitly fixture-only;
LIVE inputs remain blocked until the independent Stage-A proof and an
allowlisted visual-compiler receipt can be reopened.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import wave
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_av_timeline import verify_phase6_av_timeline
from .phase6_av_publicity import binding as _resident_binding, resolve as _resident_resolve
from .phase6_av_static_timeline import inspect_spans as _inspect_static_spans, STATIC_FILTER, VERSION as STATIC_RENDERER

SCHEMA_VERSION = "1.14.0"
RECIPE_VERSION = "phase6-av-render-recipe-v15"
BLUEPRINT_VERSION = "phase6-av-render-blueprint-v1"
SCHEMA_PATH = "schemas/phase6_av_render_recipe.schema.json"
ARGUMENTS_SCHEMA_PATH = "schemas/phase6_av_admission.schema.json"
ARGUMENTS_PARENT = "output/operations/phase6/av-admission/arguments"
STAGE_ORDER = ["SPAN_RENDER", "CONTINUOUS_AUDIO", "MIX", "MUX"]
FALSE_AUTHORITY = {
    "queue_authorized": False,
    "render_authorized": False,
    "publication_authorized": False,
    "external_effect_authorized": False,
}
NAMESPACE_POLICY = {
    "policy_id": "phase6-av-generation-namespace-v1",
    "generation_parent": "output/production/phase6/video-002/render-generations",
    "assignment": "QUEUE_COMMIT_ONLY",
    "generation_id": None,
    "render_path": None,
    "execution_cwd": "QUEUE_ASSIGNED_GENERATION_NAMESPACE",
    "requires_fresh_child_directory": True,
    "baseline_overwrite_allowed": False,
}
LIVE_TOOLS = {
    "ffmpeg": {
        "path": "C:/ffmpeg/bin/ffmpeg.exe",
        "sha256": "sha256:adc02bab9339422bbb6df60ff9a228f955cc32138bfd223eed10ff9d8cb18890",
    },
    "ffprobe": {
        "path": "C:/ffmpeg/bin/ffprobe.exe",
        "sha256": "sha256:bb84d49c6fe193f8eccc8c3875662ded14ff7da28eeb0ecf45da4a22d261d149",
    },
}
CLEAN_PLATE_VERIFIER_PATH = "hero_engine/phase6_av_clean_plate.py"
CLEAN_PLATE_VERIFIER_VERSION = "phase6-av-clean-plate-verifier-v1"
CLEAN_PLATE_STATUS = "SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED"
CLEAN_PLATE_CAPACITY = {
    "frame_count": 1800,
    "duration_seconds": 60,
    "width": 1920,
    "height": 1080,
    "fps": 30,
}
CLEAN_PLATE_AUTHORITY = {key: False for key in (
    "production_authorized", "render_authorized", "queue_authorized",
    "publication_authorized", "quality_approved", "publicity_approved",
    "legal_release", "retiming_authorized",
)}
MIX_POLICY = {
    "policy_id": "phase6-av-continuous-mix-v1",
    "narration_gain": 1.0,
    "sfx_gain": 0.82,
    "music_gain": 0.70,
    "sidechain_threshold": 0.035,
    "sidechain_ratio": 8.0,
    "sidechain_attack_ms": 18,
    "sidechain_release_ms": 380,
    "integrated_loudness_lufs": -16.0,
    "loudness_range_lu": 7.0,
    "true_peak_dbtp": -1.3,
}
_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_UNSAFE_FILTER = re.compile(
    r"(?i)(?:https?|ftp|tcp|udp|srt)://|(?:^|[,;])\s*(?:movie|amovie|zmq|sendcmd|asendcmd)\s*="
)


class AVRenderRecipeError(ValueError):
    pass


def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise AVRenderRecipeError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json(raw: bytes) -> Any:
    try:
        return json.loads(
            raw.decode("utf-8"), object_pairs_hook=_pairs,
            parse_constant=lambda value: (_ for _ in ()).throw(
                AVRenderRecipeError(f"non-finite JSON constant: {value}")
            ),
        )
    except AVRenderRecipeError:
        raise
    except Exception as exc:
        raise AVRenderRecipeError(f"invalid UTF-8 JSON: {exc}") from exc


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise AVRenderRecipeError(f"value is not canonical JSON: {exc}") from exc


def _sha_bytes(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical_sha(value: Any) -> str:
    return _sha_bytes(_canonical(value))


def _strict_keys(value: Any, keys: set[str], name: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise AVRenderRecipeError(f"{name} fields differ")
    return value


def _rooted(root: Path, value: str, *, must_exist: bool = True) -> Path:
    if not isinstance(value, str) or not value:
        raise AVRenderRecipeError("empty file path")
    raw = Path(value)
    target = (raw if raw.is_absolute() else root / raw).resolve(strict=must_exist)
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise AVRenderRecipeError("file path escaped workspace") from exc
    return target


def _relative(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def _binding(root: Path, value: dict[str, Any], name: str) -> tuple[dict[str, Any], bytes, Path]:
    _strict_keys(value, {"path", "sha256", "size_bytes"}, name)
    if not _DIGEST.fullmatch(value["sha256"] if isinstance(value["sha256"], str) else ""):
        raise AVRenderRecipeError(f"{name} digest is malformed")
    if type(value["size_bytes"]) is not int or value["size_bytes"] < 1:
        raise AVRenderRecipeError(f"{name} size is invalid")
    path = _rooted(root, value["path"])
    raw = path.read_bytes()
    if len(raw) != value["size_bytes"] or _sha_bytes(raw) != value["sha256"]:
        raise AVRenderRecipeError(f"{name} bytes differ from binding")
    return {"path": _relative(root, path), "sha256": value["sha256"],
            "size_bytes": len(raw)}, raw, path


def _loose_binding(root: Path, value: dict[str, Any], name: str) -> tuple[dict[str, Any], bytes, Path]:
    if not isinstance(value, dict) or set(value) != {"path", "sha256", "bytes"}:
        raise AVRenderRecipeError(f"{name} fields differ")
    normalized, raw, path = _binding(root, {
        "path": value["path"], "sha256": value["sha256"], "size_bytes": value["bytes"]
    }, name)
    return normalized, raw, path


def _clean_plate_binding(root: Path, value: dict[str, Any], name: str, *, allow_empty: bool = False) -> dict[str, Any]:
    """Reopen one verifier output pin, allowing only the two fixed local tools."""
    _strict_keys(value, {"path", "sha256", "size_bytes"}, name)
    path_text = value["path"] if isinstance(value["path"], str) else ""
    external_role = next((role for role, expected in LIVE_TOOLS.items()
                          if path_text.replace("\\", "/").lower() == expected["path"].lower()), None)
    if (not _DIGEST.fullmatch(value["sha256"] if isinstance(value["sha256"], str) else "")
            or type(value["size_bytes"]) is not int
            or value["size_bytes"] < (0 if allow_empty else 1)):
        raise AVRenderRecipeError(f"{name} binding is invalid")
    if external_role is not None:
        expected = LIVE_TOOLS[external_role]
        if value["sha256"] != expected["sha256"] or value["size_bytes"] < 1:
            raise AVRenderRecipeError(f"{name} external tool identity differs")
        path = _resident_resolve(root, expected["path"], confined=False)
        measured = _resident_binding(path)
        if measured["size_bytes"] != value["size_bytes"] or measured["sha256"] != expected["sha256"]:
            raise AVRenderRecipeError(f"{name} external tool bytes differ")
        return {"path": expected["path"], "sha256": expected["sha256"], "size_bytes": measured["size_bytes"]}
    try:
        path = _resident_resolve(root, value["path"], confined=True)
        measured = _resident_binding(path)
    except Exception as exc:
        raise AVRenderRecipeError(f"{name} is missing, linked or nonresident: {exc}") from exc
    if measured["size_bytes"] != value["size_bytes"] or measured["sha256"] != value["sha256"]:
        raise AVRenderRecipeError(f"{name} bytes differ from binding")
    return {"path": _relative(root, path), "sha256": value["sha256"], "size_bytes": measured["size_bytes"]}


def _clean_plate_proof(root: Path, value: Any, timeline: dict[str, Any]) -> dict[str, Any] | None:
    if value is None:
        return None
    keys = {"verifier_version", "status", "channel_id", "style_bible_id", "receipt_binding",
            "asset_binding", "lineage_id", "capacity", "source_take_plan_binding",
            "dependency_bindings", "dependency_roles", "authority", "technical_cost_brl"}
    _strict_keys(value, keys, "clean-plate proof")
    capacity = value["capacity"]
    if (not isinstance(capacity, dict) or set(capacity) != set(CLEAN_PLATE_CAPACITY)
            or any(type(capacity[key]) is not int for key in CLEAN_PLATE_CAPACITY)
            or _canonical(capacity) != _canonical(CLEAN_PLATE_CAPACITY)
            or value["verifier_version"] != CLEAN_PLATE_VERIFIER_VERSION
            or value["status"] != CLEAN_PLATE_STATUS
            or value["channel_id"] != timeline["channel_id"]
            or not isinstance(value["style_bible_id"], str) or not value["style_bible_id"]
            or value["lineage_id"] != "heroverse-owned-clean-plate-081827"
            or not isinstance(value["authority"], dict)
            or value["authority"] != CLEAN_PLATE_AUTHORITY
            or any(type(flag) is not bool for flag in value["authority"].values())
            or type(value["technical_cost_brl"]) is not int or value["technical_cost_brl"] != 0):
        raise AVRenderRecipeError("clean-plate identity, capacity, authority or cost differs")
    if not isinstance(value["dependency_bindings"], list) or not value["dependency_bindings"]:
        raise AVRenderRecipeError("clean-plate dependency bindings missing")
    raw_by_path: dict[str, dict[str, Any]] = {}
    for row in value["dependency_bindings"]:
        _strict_keys(row, {"path", "sha256", "size_bytes"}, "clean-plate dependency")
        if not isinstance(row["path"], str) or row["path"] in raw_by_path:
            raise AVRenderRecipeError("clean-plate dependency path duplicated")
        raw_by_path[row["path"]] = row
    if len(raw_by_path) != len(value["dependency_bindings"]):
        raise AVRenderRecipeError("clean-plate dependency path duplicated")
    if not isinstance(value["dependency_roles"], list) or len(value["dependency_roles"]) != len(raw_by_path):
        raise AVRenderRecipeError("clean-plate dependency role coverage differs")
    roles: list[dict[str, str]] = []
    seen_roles: set[str] = set()
    for row in value["dependency_roles"]:
        _strict_keys(row, {"role", "path", "sha256"}, "clean-plate dependency role")
        if (not isinstance(row["role"], str) or not _ID.fullmatch(row["role"])
                or row["role"] in seen_roles or row["path"] not in raw_by_path
                or row["sha256"] != raw_by_path[row["path"]]["sha256"]):
            raise AVRenderRecipeError("clean-plate dependency role differs")
        seen_roles.add(row["role"])
        roles.append(copy.deepcopy(row))
    if {row["path"] for row in roles} != set(raw_by_path):
        raise AVRenderRecipeError("clean-plate dependency role coverage differs")
    role_by_path = {row["path"]: row["role"] for row in roles}
    empty_path = "output/qa/phase6/diagnostics/two-column-clean-plate-v1-ef0d956239c512d0/render-stdout.bin"
    dependencies = []
    for row in value["dependency_bindings"]:
        role = role_by_path[row["path"]]
        allow_empty = role == "render_stdout" and row["path"] == empty_path
        normalized = _clean_plate_binding(root, row, "clean-plate dependency", allow_empty=allow_empty)
        if normalized["size_bytes"] == 0 and not allow_empty:
            raise AVRenderRecipeError("only the pinned render stdout dependency may be empty")
        dependencies.append(normalized)
    by_path = {row["path"]: row for row in dependencies}
    role_pins = {row["role"]: by_path[row["path"]] for row in roles}
    required_roles = {"take_plan", "clean_plate_receipt", "clean_plate_asset", "clean_plate_verifier",
                      "ffmpeg", "ffprobe"}
    if not required_roles.issubset(role_pins):
        raise AVRenderRecipeError("clean-plate critical dependency role missing")
    receipt = _clean_plate_binding(root, value["receipt_binding"], "clean-plate receipt")
    asset = _clean_plate_binding(root, value["asset_binding"], "clean-plate asset")
    take_plan = _clean_plate_binding(root, value["source_take_plan_binding"], "clean-plate take plan")
    if (receipt != role_pins["clean_plate_receipt"] or asset != role_pins["clean_plate_asset"]
            or take_plan != role_pins["take_plan"]
            or role_pins["clean_plate_verifier"]["path"] != CLEAN_PLATE_VERIFIER_PATH
            or role_pins["ffmpeg"]["path"] != LIVE_TOOLS["ffmpeg"]["path"]
            or role_pins["ffprobe"]["path"] != LIVE_TOOLS["ffprobe"]["path"]):
        raise AVRenderRecipeError("clean-plate receipt, asset, source or verifier binding differs")
    return {
        **{key: copy.deepcopy(value[key]) for key in (
            "verifier_version", "status", "channel_id", "style_bible_id", "lineage_id",
            "capacity", "authority", "technical_cost_brl")},
        "receipt_binding": receipt, "asset_binding": asset, "source_take_plan_binding": take_plan,
        "dependency_bindings": dependencies, "dependency_roles": roles,
    }


def _identity(value: dict[str, Any], field: str, prefix: str) -> str:
    payload = copy.deepcopy(value)
    payload.pop(field, None)
    return prefix + _canonical_sha(payload).split(":", 1)[1][:24]


def _recompose_timeline(root: Path, timeline: dict[str, Any],
                        binding: dict[str, Any] | None) -> dict[str, Any] | None:
    if binding is None:
        return None
    pin, raw, path = _binding(root, binding, "Stage-A arguments")
    value = _json(raw)
    schema = _json((Path(__file__).resolve().parents[1] / ARGUMENTS_SCHEMA_PATH).read_bytes())
    errors = list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(value))
    if errors:
        raise AVRenderRecipeError("Stage-A arguments schema failed")
    if value.get("document_type") != "PHASE6_AV_RAW_ARGUMENTS":
        raise AVRenderRecipeError("Stage-A arguments have the wrong document type")
    expected_id = _identity(value, "arguments_id", "phase6-av-arguments-")
    expected_path = f"{ARGUMENTS_PARENT}/{expected_id}.json"
    if value["arguments_id"] != expected_id or pin["path"] != expected_path or binding["path"] != expected_path:
        raise AVRenderRecipeError("Stage-A arguments identity or immutable path differs")
    for key in ("channel_id", "video_id", "protocol_id"):
        if value[key] != timeline[key]:
            raise AVRenderRecipeError(f"Stage-A arguments {key} differs from timeline")
    try:
        # Never source these arguments from timeline['inputs']. The immutable
        # caller binding is reopened and the domain recomputes every source.
        verified = verify_phase6_av_timeline(
            root, timeline, **value["arguments"], require_complete=False)
    except Exception as exc:
        raise AVRenderRecipeError(f"Stage-A independent recomposition failed: {exc}") from exc
    if path.read_bytes() != raw:
        raise AVRenderRecipeError("Stage-A arguments changed during recomposition")
    return {
        "binding": pin, "arguments_id": expected_id,
        "evidence_mode": value["evidence_mode"],
        "status": ("RECOMPOSED_COMPLETE_NOT_ADMITTED"
                   if verified["status"] == "TIMELINE_VALIDATED_NOT_ADMITTED"
                   else "RECOMPOSED_INCOMPLETE"),
        "timeline_canonical_sha256": _canonical_sha(verified),
        "scope": "REAL_STAGE_A_VERIFIER_FROM_INDEPENDENT_IMMUTABLE_ARGUMENTS",
    }


def _validate_timeline(root: Path, timeline: dict[str, Any],
                       arguments_binding: dict[str, Any] | None) -> tuple[dict[str, Any], list[str]]:
    schema = _json((Path(__file__).resolve().parents[1] / "schemas/phase6_av_timeline.schema.json").read_bytes())
    errors = sorted(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(timeline),
                    key=lambda row: list(row.absolute_path))
    if errors:
        raise AVRenderRecipeError("timeline schema failed: " + errors[0].message)
    if timeline.get("timeline_id") != _identity(timeline, "timeline_id", "phase6-av-timeline-"):
        raise AVRenderRecipeError("timeline canonical identity differs")
    if timeline.get("timeline_version") != "phase6-av-timeline-v12":
        raise AVRenderRecipeError("only current Stage-A timeline v12 may compile")
    if timeline.get("clock") != {
        "sample_rate": 24000, "fps_numerator": 30, "fps_denominator": 1,
        "samples_per_frame": 800, "slot_grid_samples": 2400,
    }:
        raise AVRenderRecipeError("timeline clock differs")
    duration = timeline["duration"]
    samples, frames = duration["planned_total_samples"], duration["planned_total_frames"]
    if type(samples) is not int or type(frames) is not int or samples <= 0 or samples % 800 or frames != samples // 800:
        raise AVRenderRecipeError("timeline samples/frames drift")
    if len(timeline["units"]) != 51 or len(timeline["narration_fragment_map"]) != 90:
        raise AVRenderRecipeError("exact 51 narration units and 90 fragments required")
    expected_units = [f"narration-unit-{i:03d}" for i in range(1, 52)]
    expected_takes = [f"take-{i:03d}" for i in range(1, 91)]
    if [row["unit_id"] for row in timeline["units"]] != expected_units:
        raise AVRenderRecipeError("narration unit order differs")
    if [row["take_id"] for row in timeline["narration_fragment_map"]] != expected_takes:
        raise AVRenderRecipeError("fragment order, omission or duplication")
    cursor = 0
    for unit in timeline["units"]:
        if (unit["slot_start_sample"] != cursor or unit["pcm_start_sample"] != cursor
                or not cursor < unit["pcm_end_sample_exclusive"] <= unit["slot_end_sample_exclusive"]):
            raise AVRenderRecipeError("narration slot continuity differs")
        cursor = unit["slot_end_sample_exclusive"]
    if cursor != samples:
        raise AVRenderRecipeError("narration slots do not cover the timeline")
    frame_cursor = 0
    stills = [span for span in timeline["render_spans"] if span.get("media_kind") == "STATIC_IMAGE"]
    static_proofs = dict(zip((span["span_id"] for span in stills), _inspect_static_spans(root, stills), strict=True))
    for span in timeline["render_spans"]:
        is_static = span.get("media_kind") == "STATIC_IMAGE"
        if (span["start_frame"] != frame_cursor or span["end_frame"] <= span["start_frame"]
                or (not is_static and span["source_end_frame"] - span["source_start_frame"] != span["end_frame"] - span["start_frame"])):
            raise AVRenderRecipeError("render span continuity or source duration differs")
        if is_static:
            proof = static_proofs[span["span_id"]]
            expected = {"span_id": span["span_id"], "inspection_id": proof["inspection_id"],
                        "inspection_sha256": _canonical_sha(proof)}
            observed = [row for row in timeline["static_source_evidence"] if row["span_id"] == span["span_id"]]
            if _canonical(observed) != _canonical([expected]):
                raise AVRenderRecipeError("static inspector identity differs from Stage A")
        source = _rooted(root, span["asset_binding"]["path"])
        if _sha_bytes(source.read_bytes()) != span["asset_binding"]["sha256"]:
            raise AVRenderRecipeError("render span source binding changed")
        frame_cursor = span["end_frame"]
    if timeline["render_spans"] and frame_cursor != frames:
        raise AVRenderRecipeError("render spans do not cover the timeline")
    source_bindings: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in timeline["source_file_bindings"]:
        path = _rooted(root, row["path"])
        raw = path.read_bytes()
        if _sha_bytes(raw) != row["sha256"]:
            raise AVRenderRecipeError("timeline source binding changed")
        normalized = {"path": _relative(root, path), "sha256": row["sha256"],
                      "size_bytes": len(raw)}
        if normalized["path"] in seen:
            raise AVRenderRecipeError("duplicate timeline source binding")
        seen.add(normalized["path"])
        source_bindings.append(normalized)
    recomposition = _recompose_timeline(root, timeline, arguments_binding)
    blockers: list[str] = []
    if recomposition is None:
        blockers.append("STAGE_A_INDEPENDENT_RECOMPOSITION_REQUIRED")
    elif recomposition["evidence_mode"] != "LIVE":
        blockers.append("FIXTURE_ARGUMENTS_NOT_PRODUCTION_EVIDENCE")
    if timeline["status"] != "TIMELINE_VALIDATED_NOT_ADMITTED" or timeline["derived_take_plan"] is None or timeline["blockers"]:
        blockers.append("STAGE_A_TIMELINE_INCOMPLETE")
    if (timeline.get("visual_amendment_evidence") is not None
            or timeline.get("question_case_amendment_evidence") is not None
            or timeline.get("body_case_amendment_evidence") is not None):
        # Neither compact nor case-only source proof is the legacy composition.
        # Do not silently render that old graphic for the amended literal plan.
        blockers.append("AMENDED_VISUAL_COMPOSITOR_NOT_IMPLEMENTED")
    assessment = timeline.get("temporal_evidence_assessment") or {}
    if assessment.get("scope_complete") is not True:
        blockers.append("STAGE_A_TEMPORAL_TARGET_SCOPE_INCOMPLETE")
    if assessment.get("fixture_evidence_present") is not False or assessment.get("all_required_evidence_live") is not True:
        blockers.append("STAGE_A_LIVE_TEMPORAL_EVIDENCE_MISSING")
    return {"timeline_id": timeline["timeline_id"], "canonical_sha256": _canonical_sha(timeline),
            "status": timeline["status"], "planned_total_samples": samples,
            "planned_total_frames": frames,
            "verification_scope": ("SOURCE_RECOMPOSITION_FROM_PINNED_ARGUMENTS" if recomposition
                                   else "SCHEMA_IDENTITY_SOURCE_REHASH_NOT_STAGE_A_RECOMPOSITION"),
            "independent_arguments": recomposition,
            "source_file_bindings": source_bindings}, blockers


def _wav(path: Path, *, channels: int, rate: int, width: int, frames: int, name: str) -> None:
    try:
        with wave.open(str(path), "rb") as stream:
            observed = (stream.getnchannels(), stream.getframerate(), stream.getsampwidth(),
                        stream.getnframes(), stream.getcomptype())
            payload = stream.readframes(stream.getnframes())
    except Exception as exc:
        raise AVRenderRecipeError(f"{name} is not readable WAV: {exc}") from exc
    if observed != (channels, rate, width, frames, "NONE"):
        raise AVRenderRecipeError(f"{name} PCM contract differs")
    if len(payload) != channels * width * frames:
        raise AVRenderRecipeError(f"{name} PCM payload is truncated")


def _master(root: Path, binding: dict[str, Any], expected_samples: int) -> tuple[dict[str, Any], Path, list[str]]:
    pin, raw, receipt_path = _binding(root, binding, "master receipt")
    value = _json(raw)
    required = {"status", "output", "assessment", "tail", "authority", "technical_cost_brl",
                "intent", "normalize_terminal", "measure_intent", "measure_terminal", "raw_output"}
    if not isinstance(value, dict) or not required.issubset(value):
        raise AVRenderRecipeError("master receipt contract is incomplete")
    if value["status"] != "NORMALIZATION_PASS_NOT_COMPLETE_AUDIO_APPROVAL":
        raise AVRenderRecipeError("unknown master receipt status")
    if value["technical_cost_brl"] != 0 or not isinstance(value["authority"], dict) or any(value["authority"].values()):
        raise AVRenderRecipeError("master receipt attempted authority or cost")
    nested: dict[str, dict[str, Any]] = {}
    for key in ("intent", "normalize_terminal", "measure_intent", "measure_terminal", "raw_output", "output"):
        nested[key], _, _ = _loose_binding(root, value[key], f"master {key}")
    output_path = _rooted(root, nested["output"]["path"])
    assessment = value["assessment"]
    expected_checks = {"exact_sample_count", "no_pcm_extremes", "integrated_loudness", "true_peak"}
    if (not isinstance(assessment, dict) or assessment.get("status") != "PASS"
            or set(assessment.get("checks") or {}) != expected_checks
            or any(flag is not True for flag in assessment["checks"].values())
            or assessment.get("scope") != "DURATION_LEVELS_PCM_EXTREMES_ONLY_NOT_PERCEPTUAL_OR_RELEASE_QA"):
        raise AVRenderRecipeError("master technical assessment differs")
    frames = assessment.get("frames")
    if type(frames) is not int or frames <= 0 or value.get("tail", {}).get("retained_samples") != frames:
        raise AVRenderRecipeError("master sample accounting differs")
    _wav(output_path, channels=1, rate=24000, width=2, frames=frames, name="master narration")
    blockers = ["MASTER_AUDIO_NOT_COMPLETE_AUDIO_APPROVAL"]
    if frames != expected_samples:
        blockers.append("MASTER_AUDIO_SAMPLE_COUNT_DIFFERS_FROM_TIMELINE")
    if "/output/qa/" in ("/" + pin["path"].lower().replace("\\", "/")):
        blockers.append("MASTER_RECEIPT_DIAGNOSTIC_ONLY")
    return {"receipt": pin, "receipt_status": value["status"], "audio": nested["output"],
            "sample_rate": 24000, "channels": 1, "sample_width_bytes": 2,
            "sample_count": frames, "assessment_scope": assessment["scope"],
            "verification_scope": "NORMALIZATION_LEVELS_AND_SAMPLE_COUNT_ONLY",
            "future_integration_requirement": "VERSIONED_COMPLETE_AUDIO_APPROVAL_REOPENED_BY_STAGE_B",
            "dependency_bindings": [nested[key] for key in ("intent", "normalize_terminal", "measure_intent", "measure_terminal", "raw_output")]}, output_path, blockers


def _tool_binding(root: Path, row: dict[str, Any], role: str, evidence_mode: str) -> tuple[dict[str, Any], Path]:
    _strict_keys(row, {"path", "sha256", "size_bytes", "version"}, role)
    if not isinstance(row["version"], str) or not row["version"]:
        raise AVRenderRecipeError("tool version missing")
    if evidence_mode != "LIVE":
        normalized, _, path = _binding(root, {key: row[key] for key in ("path", "sha256", "size_bytes")}, role)
        return {**normalized, "version": row["version"]}, path
    expected = LIVE_TOOLS[role]
    normalized_path = str(row["path"]).replace("\\", "/")
    if normalized_path.lower() != expected["path"].lower() or row["sha256"] != expected["sha256"]:
        raise AVRenderRecipeError(f"LIVE {role} identity is not the authorized external local tool")
    path = Path(expected["path"]).resolve(strict=True)
    raw = path.read_bytes()
    if len(raw) != row["size_bytes"] or _sha_bytes(raw) != expected["sha256"]:
        raise AVRenderRecipeError(f"LIVE {role} bytes differ from the authorized pin")
    return {"path": expected["path"], "sha256": expected["sha256"],
            "size_bytes": len(raw), "version": row["version"]}, path


def _blueprint(root: Path, binding: dict[str, Any], timeline: dict[str, Any], expected_samples: int) -> tuple[dict[str, Any], dict[str, Path], list[str]]:
    pin, raw, _ = _binding(root, binding, "render blueprint")
    value = _json(raw)
    keys = {"schema_version", "blueprint_version", "blueprint_id", "evidence_mode", "timeline_id",
            "tools", "visual_spans", "audio_beds", "mix_policy", "authority", "technical_cost_brl"}
    _strict_keys(value, keys, "render blueprint")
    if value["schema_version"] != "1.0.0" or value["blueprint_version"] != BLUEPRINT_VERSION:
        raise AVRenderRecipeError("render blueprint version differs")
    if value["blueprint_id"] != _identity(value, "blueprint_id", "phase6-av-render-blueprint-"):
        raise AVRenderRecipeError("render blueprint identity differs")
    if value["timeline_id"] != timeline["timeline_id"] or value["authority"] != FALSE_AUTHORITY or value["technical_cost_brl"] != 0:
        raise AVRenderRecipeError("render blueprint timeline, authority or cost differs")
    if value["evidence_mode"] not in {"FIXTURE", "LIVE"}:
        raise AVRenderRecipeError("render blueprint evidence mode differs")
    _strict_keys(value["tools"], {"ffmpeg", "ffprobe"}, "render tools")
    tools: dict[str, dict[str, Any]] = {}
    tool_paths: dict[str, Path] = {}
    for role in ("ffmpeg", "ffprobe"):
        row = value["tools"][role]
        tools[role], tool_paths[role] = _tool_binding(root, row, role, value["evidence_mode"])
    if value["mix_policy"] != MIX_POLICY:
        raise AVRenderRecipeError("mix policy differs")
    spans = timeline["render_spans"]
    if not spans:
        raise AVRenderRecipeError("render blueprint cannot bind an empty visual plan")
    by_id: dict[str, dict[str, Any]] = {}
    for row in value["visual_spans"]:
        _strict_keys(row, {"span_id", "renderer_version", "filtergraph", "dependency_bindings"}, "visual span blueprint")
        span_id = row["span_id"]
        if not isinstance(span_id, str) or not _ID.fullmatch(span_id) or span_id in by_id:
            raise AVRenderRecipeError("visual span identity is unsafe or duplicated")
        if not isinstance(row["renderer_version"], str) or not row["renderer_version"]:
            raise AVRenderRecipeError("renderer version missing")
        graph = row["filtergraph"]
        if not isinstance(graph, str) or not graph or len(graph) > 32768 or "\x00" in graph or "\n" in graph or "\r" in graph or _UNSAFE_FILTER.search(graph):
            raise AVRenderRecipeError("visual filtergraph is empty, multiline or unsafe")
        span = next((item for item in spans if item["span_id"] == span_id), None)
        if span is not None and span.get("media_kind") == "STATIC_IMAGE" and (
                row["renderer_version"] != STATIC_RENDERER or graph != STATIC_FILTER or row["dependency_bindings"] != []):
            raise AVRenderRecipeError("static render must use its exact bounded owned-image compiler")
        dependencies = []
        for dep in row["dependency_bindings"]:
            normalized, _, _ = _binding(root, dep, "visual filter dependency")
            dependencies.append(normalized)
        by_id[span_id] = {**copy.deepcopy(row), "dependency_bindings": dependencies}
    if set(by_id) != {row["span_id"] for row in spans}:
        raise AVRenderRecipeError("visual blueprint span coverage differs")
    beds: dict[str, dict[str, Any]] = {}
    bed_paths: dict[str, Path] = {}
    _strict_keys(value["audio_beds"], {"sfx", "music"}, "audio beds")
    expected_bed_frames = expected_samples * 2
    for role in ("sfx", "music"):
        row = value["audio_beds"][role]
        _strict_keys(row, {"role", "binding", "sample_rate", "channels", "sample_width_bytes", "frame_count"}, f"{role} bed")
        if row["role"] != role.upper() or (row["sample_rate"], row["channels"], row["sample_width_bytes"], row["frame_count"]) != (48000, 2, 2, expected_bed_frames):
            raise AVRenderRecipeError(f"{role} bed format or duration differs")
        normalized, _, path = _binding(root, row["binding"], f"{role} bed")
        _wav(path, channels=2, rate=48000, width=2, frames=expected_bed_frames, name=f"{role} bed")
        beds[role] = {**{k: row[k] for k in ("role", "sample_rate", "channels", "sample_width_bytes", "frame_count")}, "binding": normalized}
        bed_paths[role] = path
    blockers = ["TRANSACTIONAL_ADMISSION_REQUIRED", "EXTERNAL_QUALITY_GATES_REQUIRED"]
    if value["evidence_mode"] == "FIXTURE":
        blockers.append("FIXTURE_BLUEPRINT_NOT_PRODUCTION_EVIDENCE")
    else:
        # A future version must consume an allowlisted creative compiler receipt.
        # Opaque filter strings are never promoted to a LIVE executable graph.
        blockers.append("LIVE_VISUAL_FILTER_COMPILER_RECEIPT_NOT_SUPPORTED")
    return {"binding": pin, "blueprint_id": value["blueprint_id"], "blueprint_version": value["blueprint_version"],
            "evidence_mode": value["evidence_mode"], "tools": tools, "visual_spans": [by_id[row["span_id"]] for row in spans],
            "audio_beds": beds, "mix_policy": copy.deepcopy(MIX_POLICY)}, {**tool_paths, **bed_paths}, blockers


def _generated_file(path: str, content: str, role: str) -> dict[str, Any]:
    raw = content.encode("utf-8")
    return {"role": role, "relative_path": path, "sha256": _sha_bytes(raw),
            "size_bytes": len(raw), "content_utf8": content}


def _srt(timeline: dict[str, Any]) -> tuple[str, str]:
    rows, exact_rows = [], []
    for index, cue in enumerate(timeline["caption_cues"], 1):
        start, end = cue["start_sample"], cue["end_sample"]
        start_ms = start * 1000 // 24000
        end_ms = (end * 1000 + 23999) // 24000
        def stamp(ms: int) -> str:
            hours, rem = divmod(ms, 3_600_000)
            minutes, rem = divmod(rem, 60_000)
            seconds, millis = divmod(rem, 1000)
            return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"
        rows.append(f"{index}\n{stamp(start_ms)} --> {stamp(end_ms)}\n" + "\n".join(cue["lines"]) + "\n")
        exact_rows.append({"cue_id": cue["cue_id"], "start_sample": start, "end_sample": end,
                           "text": cue["text"], "srt_start_ms": start_ms, "srt_end_ms": end_ms,
                           "rounding": "START_FLOOR_END_CEIL_FROM_24KHZ"})
    return "\n".join(rows), _canonical({"sample_rate": 24000, "cues": exact_rows}).decode("utf-8") + "\n"


def _command(command_id: str, stage: str, executable: dict[str, Any], argv: list[str],
             inputs: list[str], outputs: list[str], timeout: int) -> dict[str, Any]:
    return {"command_id": command_id, "stage": stage, "executable": executable,
            "argv": argv, "cwd_policy": "QUEUE_ASSIGNED_GENERATION_NAMESPACE",
            "input_refs": inputs, "output_refs": outputs, "timeout_seconds": timeout,
            "effect_policy": "LOCAL_WRITE_ONLY_AFTER_COMMITTED_JOB_CLAIM"}


def _graph(root: Path, timeline: dict[str, Any], master: dict[str, Any], master_path: Path,
           blueprint: dict[str, Any], paths: dict[str, Path]) -> dict[str, Any]:
    ffmpeg = {**blueprint["tools"]["ffmpeg"], "role": "FFMPEG"}
    span_commands, artifacts, generated = [], [], []
    span_outputs = []
    for index, (span, spec) in enumerate(zip(timeline["render_spans"], blueprint["visual_spans"], strict=True), 1):
        source = _rooted(root, span["asset_binding"]["path"])
        if _sha_bytes(source.read_bytes()) != span["asset_binding"]["sha256"]:
            raise AVRenderRecipeError("render span source changed")
        name = f"{index:03d}-{span['span_id']}.mkv"
        output = f"video/spans/{name}"
        script_path = f"meta/filters/{index:03d}-{span['span_id']}.txt"
        is_static = span.get("media_kind") == "STATIC_IMAGE"
        select = (f"trim=end_frame={span['end_frame'] - span['start_frame']},setpts=N/(30*TB)" if is_static else
                  f"select='between(n\\,{span['source_start_frame']}\\,{span['source_end_frame'] - 1})',setpts=N/(30*TB)")
        filtergraph = select + "," + spec["filtergraph"] + ",fps=30,setsar=1,format=yuv420p"
        generated.append(_generated_file(script_path, filtergraph + "\n", "VIDEO_FILTER_SCRIPT"))
        artifact_id = f"span-video-{index:03d}"
        artifacts.append({"artifact_id": artifact_id, "kind": "VIDEO_SPAN", "relative_path": output,
                          "expected_frame_count": span["end_frame"] - span["start_frame"], "expected_sample_count": None})
        span_outputs.append(output)
        source_options = ["-loop", "1", "-framerate", "30"] if is_static else []
        argv = [str(paths["ffmpeg"]), "-n", "-nostdin", "-hide_banner", "-loglevel", "error",
                *source_options, "-i", str(source), "-an", "-filter_script:v", script_path,
                "-frames:v", str(span["end_frame"] - span["start_frame"]), "-r", "30",
                "-c:v", "libx264", "-profile:v", "high", "-preset", "medium", "-crf", "18",
                "-maxrate", "12M", "-bufsize", "24M", "-pix_fmt", "yuv420p", "-g", "60",
                "-keyint_min", "30", "-sc_threshold", "0", output]
        span_commands.append(_command(f"span-render-{index:03d}", "SPAN_RENDER", ffmpeg, argv,
                                      [f"timeline-span:{span['span_id']}", f"generated:{script_path}"], [artifact_id], 1800))
    concat_text = "".join("file '../" + path.replace("'", "'\\''") + "'\n" for path in span_outputs)
    generated.append(_generated_file("meta/video-concat.txt", concat_text, "VIDEO_CONCAT_LIST"))
    srt, exact_cues = _srt(timeline)
    generated.append(_generated_file("captions/en-US.srt", srt, "PLATFORM_CAPTIONS"))
    generated.append(_generated_file("captions/cues-sample-exact.json", exact_cues, "SAMPLE_EXACT_CAPTION_MAP"))
    samples, frames = timeline["duration"]["planned_total_samples"], timeline["duration"]["planned_total_frames"]
    artifacts.extend([
        {"artifact_id": "continuous-narration", "kind": "PCM_AUDIO", "relative_path": "audio/narration-48k-stereo.wav", "expected_frame_count": None, "expected_sample_count": samples * 2},
        {"artifact_id": "final-mix", "kind": "PCM_AUDIO", "relative_path": "audio/final-mix.wav", "expected_frame_count": None, "expected_sample_count": samples * 2},
        {"artifact_id": "silent-video", "kind": "VIDEO_CONCAT", "relative_path": "video/silent-concat.mkv", "expected_frame_count": frames, "expected_sample_count": None},
        {"artifact_id": "final-video", "kind": "FINAL_MP4", "relative_path": "final/video-002.mp4", "expected_frame_count": frames, "expected_sample_count": samples * 2},
        {"artifact_id": "captions-srt", "kind": "CAPTIONS", "relative_path": "captions/en-US.srt", "expected_frame_count": None, "expected_sample_count": None},
        {"artifact_id": "captions-sample-map", "kind": "CAPTION_MAP", "relative_path": "captions/cues-sample-exact.json", "expected_frame_count": None, "expected_sample_count": None},
    ])
    continuous = _command("continuous-audio-001", "CONTINUOUS_AUDIO", ffmpeg,
        [str(paths["ffmpeg"]), "-n", "-nostdin", "-hide_banner", "-loglevel", "error", "-i", str(master_path),
         "-map", "0:a:0", "-vn", "-af", "aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo",
         "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", "audio/narration-48k-stereo.wav"],
        ["mastered-narration"], ["continuous-narration"], 900)
    mix_filter = ("[0:a]volume=1.0,asplit=2[nmix][nkey];[1:a]volume=0.82[sfx];"
                  "[2:a]volume=0.70[m];[m][nkey]sidechaincompress=threshold=0.035:ratio=8:"
                  "attack=18:release=380[md];[nmix][sfx][md]amix=inputs=3:duration=first:normalize=0,"
                  "loudnorm=I=-16:LRA=7:TP=-1.3[aout]")
    mix = _command("mix-001", "MIX", ffmpeg,
        [str(paths["ffmpeg"]), "-n", "-nostdin", "-hide_banner", "-loglevel", "error",
         "-i", "audio/narration-48k-stereo.wav", "-i", str(paths["sfx"]), "-i", str(paths["music"]),
         "-filter_complex", mix_filter, "-map", "[aout]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", "audio/final-mix.wav"],
        ["continuous-narration", "sfx-bed", "music-bed"], ["final-mix"], 1200)
    mux_commands = [
        _command("mux-concat-001", "MUX", ffmpeg,
            [str(paths["ffmpeg"]), "-n", "-nostdin", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", "meta/video-concat.txt", "-c", "copy", "video/silent-concat.mkv"],
            [f"span-video-{i:03d}" for i in range(1, len(span_outputs) + 1)] + ["generated:meta/video-concat.txt"], ["silent-video"], 1200),
        _command("mux-final-002", "MUX", ffmpeg,
            [str(paths["ffmpeg"]), "-n", "-nostdin", "-hide_banner", "-loglevel", "error", "-i", "video/silent-concat.mkv", "-i", "audio/final-mix.wav", "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2", "-t", f"{samples / 24000:.6f}", "-movflags", "+faststart", "final/video-002.mp4"],
            ["silent-video", "final-mix"], ["final-video"], 1200),
    ]
    stages = [
        {"stage": "SPAN_RENDER", "depends_on": [], "commands": span_commands, "checkpoint_path": "checkpoints/span-render.json"},
        {"stage": "CONTINUOUS_AUDIO", "depends_on": [], "commands": [continuous], "checkpoint_path": "checkpoints/continuous-audio.json"},
        {"stage": "MIX", "depends_on": ["CONTINUOUS_AUDIO"], "commands": [mix], "checkpoint_path": "checkpoints/mix.json"},
        {"stage": "MUX", "depends_on": ["SPAN_RENDER", "MIX"], "commands": mux_commands, "checkpoint_path": "checkpoints/mux.json"},
    ]
    return {"stage_order": list(STAGE_ORDER), "generated_files": generated, "artifacts": artifacts,
            "stages": stages, "expected_total_frames": frames, "expected_total_samples_24k": samples,
            "audio_processing": {"continuous_master_input": True, "per_take_eq_restart": False,
                                 "per_take_trim_or_pad": False, "mix_once": True},
            "checkpoint_policy": "HASH_ALL_INPUTS_OUTPUTS_COMMAND_AND_PREVIOUS_CHECKPOINT"}


def _validate_output(value: dict[str, Any]) -> None:
    schema = _json((Path(__file__).resolve().parents[1] / SCHEMA_PATH).read_bytes())
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(value),
        key=lambda row: list(row.absolute_path),
    )
    if errors:
        raise AVRenderRecipeError("render recipe schema failed: " + errors[0].message)


def _editorial_visual_preparation(root: Path, timeline: dict[str, Any], timeline_ref: dict[str, Any],
                                  bindings: dict[str, Any] | None) -> dict[str, Any] | None:
    if bindings is None:
        return None
    if timeline_ref["independent_arguments"] is None:
        raise AVRenderRecipeError("visual preparation requires independent Stage-A recomposition first")
    from .phase6_av_visual_recipe_adapter import compile_take003_editorial_visual_spec
    spec = compile_take003_editorial_visual_spec(root, timeline=timeline, bindings=bindings)
    if (spec["status"] != "COMPILED_TAKE003_VISUAL_SPEC_NOT_ADMITTED"
            or any(spec["authority"].values()) or spec["coverage"]["full_timeline_covered"] is not False):
        raise AVRenderRecipeError("visual preparation attempted unsupported coverage or authority")
    return {
        "adapter_version": spec["adapter_version"], "recipe_id": spec["recipe_id"],
        "visual_spec_id": spec["visual_spec_id"], "spec_canonical_sha256": _canonical_sha(spec),
        "filtergraph": spec["filtergraph"], "source_binding": spec["source_binding"],
        "generated_files": copy.deepcopy(spec["generated_files"]),
        "dependency_bindings": spec["dependency_bindings"],
        "covered_frame_count": spec["coverage"]["covered_frame_count"],
        "planned_total_frame_count": spec["coverage"]["planned_total_frame_count"],
        "global_start_frame": spec["supported_span"]["global_start_frame"],
        "global_end_frame_exclusive": spec["supported_span"]["global_end_frame_exclusive"],
        "full_timeline_covered": False, "blockers": spec["blockers"],
        "authority": copy.deepcopy(FALSE_AUTHORITY),
    }


def _two_column_visual_preparation(root: Path, timeline: dict[str, Any], timeline_ref: dict[str, Any],
                                   bindings: dict[str, Any] | None) -> dict[str, Any] | None:
    if bindings is None:
        return None
    if timeline_ref["independent_arguments"] is None:
        raise AVRenderRecipeError("two-column preparation requires independent Stage-A recomposition first")
    from .phase6_av_two_column_adapter import compile_two_column_av_spec
    spec = compile_two_column_av_spec(root, timeline=timeline, bindings=bindings)
    clean_plate = _clean_plate_proof(root, spec.get("clean_plate"), timeline)
    if (spec["status"] not in {"PREPARED_TWO_COLUMN_SPEC_BLOCKED", "COMPILED_TWO_COLUMN_SPEC_NOT_ADMITTED"}
            or any(spec["authority"].values()) or spec["coverage"]["full_timeline_covered"] is not False
            or any(row["source_ready"] is not False or row["render_authorized"] is not False
                   for row in spec["render_spans"])):
        raise AVRenderRecipeError("two-column preparation attempted unsupported source or authority")
    for row in spec["render_spans"]:
        expected_verified = clean_plate is not None
        expected_evidence = clean_plate["receipt_binding"] if clean_plate is not None else None
        if (type(row.get("source_technically_verified")) is not bool
                or row["source_technically_verified"] is not expected_verified
                or _canonical(row.get("source_evidence_binding")) != _canonical(expected_evidence)):
            raise AVRenderRecipeError("two-column span clean-plate evidence differs")
        if clean_plate is not None and (
                _canonical(row["asset_binding"]) != _canonical(clean_plate["asset_binding"])
                or row["lineage_id"] != clean_plate["lineage_id"]
                or type(row["source_frame_count"]) is not int
                or type(row["source_start_frame"]) is not int
                or type(row["source_end_frame"]) is not int
                or row["source_frame_count"] != clean_plate["capacity"]["frame_count"]
                or row["source_start_frame"] < 0
                or row["source_end_frame"] > clean_plate["capacity"]["frame_count"]):
            raise AVRenderRecipeError("two-column span source differs from clean-plate proof")
    states = []
    for row in spec["states"]:
        states.append({
            **{key: row[key] for key in ("take_id", "narration", "focus", "left_text", "right_text",
                                          "example", "narrative_rationale", "interval", "continuation_of")},
            "layout_sha256": _canonical_sha(row["layout"]),
            "fragment_binding_sha256": _canonical_sha(row["fragment_binding"]),
            "event_binding_sha256": _canonical_sha(row["event_binding"]) if row["event_binding"] is not None else None,
        })
    return {
        "adapter_version": spec["adapter_version"], "recipe_id": spec["recipe_id"],
        "status": spec["status"], "visual_spec_id": spec["visual_spec_id"],
        "spec_canonical_sha256": _canonical_sha(spec),
        "timeline_contract_sha256": _canonical_sha(spec["timeline_contract"]),
        "states": states, "generated_files": copy.deepcopy(spec["generated_files"]),
        "render_spans": copy.deepcopy(spec["render_spans"]),
        "clean_plate": copy.deepcopy(clean_plate),
        "coverage": copy.deepcopy(spec["coverage"]),
        "dependency_bindings": copy.deepcopy(spec["dependency_bindings"]),
        "source_ready": False, "blockers": list(spec["blockers"]),
        "authority": copy.deepcopy(FALSE_AUTHORITY),
    }


def compile_phase6_av_render_recipe(root: Path, timeline: dict[str, Any], *,
                                    master_receipt_binding: dict[str, Any] | None,
                                    render_blueprint_binding: dict[str, Any] | None,
                                    timeline_arguments_binding: dict[str, Any] | None = None,
                                    editorial_visual_bindings: dict[str, Any] | None = None,
                                    two_column_visual_bindings: dict[str, Any] | None = None) -> dict[str, Any]:
    """Compile exact argv and relative outputs; perform no media or queue effect."""
    root = Path(root).resolve(strict=True)
    timeline_ref, blockers = _validate_timeline(root, timeline, timeline_arguments_binding)
    visual_preparation = _editorial_visual_preparation(root, timeline, timeline_ref, editorial_visual_bindings)
    if visual_preparation is not None:
        blockers.append("VISUAL_RECIPE_COVERAGE_INCOMPLETE")
        blockers.extend(visual_preparation["blockers"])
    two_column_preparation = _two_column_visual_preparation(root, timeline, timeline_ref, two_column_visual_bindings)
    if two_column_preparation is not None:
        blockers.extend(["TWO_COLUMN_SOURCE_AND_FULL_GRAPH_NOT_READY", *two_column_preparation["blockers"]])
    master = master_path = blueprint = paths = None
    if master_receipt_binding is None:
        blockers.append("MASTER_RECEIPT_BINDING_MISSING")
    else:
        master, master_path, found = _master(root, master_receipt_binding, timeline_ref["planned_total_samples"])
        blockers.extend(found)
    if render_blueprint_binding is None:
        blockers.append("RENDER_BLUEPRINT_BINDING_MISSING")
    else:
        blueprint, paths, found = _blueprint(root, render_blueprint_binding, timeline, timeline_ref["planned_total_samples"])
        blockers.extend(found)
    graph = None
    if (master is not None and blueprint is not None
            and master["sample_count"] == timeline_ref["planned_total_samples"]
            and timeline["render_spans"] and blueprint["evidence_mode"] == "FIXTURE"
            and two_column_preparation is None):
        graph = _graph(root, timeline, master, master_path, blueprint, paths)
    if graph is None:
        blockers.append("COMMAND_GRAPH_NOT_COMPILED")
    blockers = sorted(set(blockers))
    implementation = []
    code_root = Path(__file__).resolve().parents[1]
    implementation_paths = ["hero_engine/phase6_av_render_recipe.py", SCHEMA_PATH,
                            "hero_engine/phase6_av_timeline.py", "schemas/phase6_av_timeline.schema.json",
                            ARGUMENTS_SCHEMA_PATH, "hero_engine/phase6_av_static_timeline.py",
                            "hero_engine/phase6_av_static_sources.py"]
    if visual_preparation is not None:
        implementation_paths.append("hero_engine/phase6_av_visual_recipe_adapter.py")
    if two_column_preparation is not None:
        implementation_paths.append("hero_engine/phase6_av_two_column_adapter.py")
        if two_column_preparation["clean_plate"] is not None:
            implementation_paths.append(CLEAN_PLATE_VERIFIER_PATH)
    for path in implementation_paths:
        raw = (code_root / path).read_bytes()
        implementation.append({"path": path, "sha256": _sha_bytes(raw), "size_bytes": len(raw)})
    value = {
        "schema_version": SCHEMA_VERSION, "recipe_version": RECIPE_VERSION,
        "recipe_id": "phase6-av-render-recipe-pending",
        "status": "COMPILED_FIXTURE_NOT_EXECUTABLE" if graph is not None else "BLOCKED_INCOMPLETE",
        "claim_boundary": "PURE_COMMAND_COMPILATION_NO_EFFECT_NO_AUTHORITY",
        "channel_id": timeline["channel_id"], "video_id": timeline["video_id"],
        "protocol_id": timeline["protocol_id"], "timeline": timeline_ref,
        "inputs": {"master": master, "render_blueprint": blueprint, "visual_preparation": visual_preparation,
                   "two_column_visual_preparation": two_column_preparation},
        "namespace_policy": copy.deepcopy(NAMESPACE_POLICY), "command_graph": graph,
        "implementation_bindings": implementation, "blockers": blockers,
        "unproven_checks": ["STAGE_B_TRANSACTION_AND_FENCING", "SOURCE_DECODE_AND_FRAME_COUNT",
                            "RIGHTS_AND_PUBLICITY", "PERCEPTUAL_AUDIO", "FINAL_MEDIA_QUALITY_GATES",
                            "RELEASE_AND_PUBLICATION"],
        "authority": copy.deepcopy(FALSE_AUTHORITY), "technical_cost_brl": 0,
        "publication_authorized": False,
    }
    value["recipe_id"] = _identity(value, "recipe_id", "phase6-av-render-recipe-")
    _validate_output(value)
    return value


def verify_phase6_av_render_recipe(root: Path, candidate: dict[str, Any], timeline: dict[str, Any], *,
                                   master_receipt_binding: dict[str, Any] | None,
                                   render_blueprint_binding: dict[str, Any] | None,
                                   timeline_arguments_binding: dict[str, Any] | None = None,
                                   editorial_visual_bindings: dict[str, Any] | None = None,
                                   two_column_visual_bindings: dict[str, Any] | None = None,
                                   require_command_graph: bool = False) -> dict[str, Any]:
    _validate_output(candidate)
    expected = compile_phase6_av_render_recipe(
        root, timeline, master_receipt_binding=master_receipt_binding,
        render_blueprint_binding=render_blueprint_binding,
        timeline_arguments_binding=timeline_arguments_binding,
        editorial_visual_bindings=editorial_visual_bindings,
        two_column_visual_bindings=two_column_visual_bindings,
    )
    if _canonical(candidate) != _canonical(expected):
        raise AVRenderRecipeError("render recipe differs from independent recompilation")
    if require_command_graph and expected["command_graph"] is None:
        raise AVRenderRecipeError("render recipe has no command graph")
    if any(expected["authority"].values()) or expected["publication_authorized"]:
        raise AssertionError("pure render recipe attempted authority")
    return expected


compile = compile_phase6_av_render_recipe
verify = verify_phase6_av_render_recipe
