from __future__ import annotations

import hashlib
import subprocess
import json
import math
import os
import re
import statistics
import time
import uuid
from datetime import datetime, timezone
from contextvars import ContextVar
from fractions import Fraction
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .phase5_autonomous_quality import _asr, _edit_distance, _srt_text, _words
from .qa_phase5 import (
    FFMPEG,
    GATES,
    DEFECTS,
    _black_freeze_scan,
    _create_visual_evidence,
    _loudness,
    _originality_scan,
    _probe,
    _signal_scan,
    _timeline_scan,
)
from .queue_phase6 import TransactionalQueue
from .phase6_publicity import screen_publicity
from .phase6_asset_residency import validate_phase6_rights_evidence, verify_phase6_asset_residency
from .phase6_media import _verify_voice_manifest_contract, verify_phase6_segment_set
from .phase6_overlay_ocr import (
    materialize_overlay_ocr_audit,
    overlay_gate_value,
    verify_overlay_ocr_measurement,
)
from .phase6_release import PRODUCTION_INPUT_RECEIPTS, verify_production_inputs_receipt
from .production_capacity import verify_phase6_capacity_receipt
from .voice_phase5 import espeak_binding_identity


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "phase6-video-002-prepublication"
BASE = Path("output/production/phase6/video-002")
RUNTIME = Path("output/operations/phase6/quality-executor-status.json")
REPORT = BASE / "quality/independent_quality_evaluation.json"
QUALITY_EVALUATIONS = BASE / "quality/evaluations"
RIGHTS_OK = {"OWNED", "LICENSED_COMMERCIAL", "CC_COMMERCIAL", "PUBLIC_DOMAIN_VERIFIED", "PLATFORM_REMIX_AUTHORIZED"}
EVALUATOR_VERSION = "1.4.0"
PACKAGE_FIDELITY_REVIEW = Path("config/production_quality_profiles/package-fidelity-name-test-choose-v1.json")
# Explicit, reviewed NEW scope. This pin is not derived from a caller's input,
# does not repin any historical receipt, and cannot approve unknown wording.
PACKAGE_FIDELITY_REVIEW_SHA256 = "ce8b4eb4e655b0164668283ea39e31964f3f3c807c99dc7ceec605f0fe59d284"
# These exact producer branches still emit NEEDS_REVIEW. Admission must not
# lease a costly evaluation which is known unable to pass. This is a capability
# boundary, NOT a defect assertion or a waiver. A test binds the list to the
# producer's unobserved branches; implementations must supply real evidence.
UNIMPLEMENTED_VISUAL_MEASUREMENTS = (
    "OBJECT_DEFORMATION", "FACE_VARIATION", "HAND_DEFECT", "IMPOSSIBLE_MOTION",
    "UNINTENDED_CAMERA_INSTABILITY", "INCOHERENT_PHYSICS", "GHOSTING",
    "ARTIFICIAL_INTERPOLATION", "COMPRESSION_ARTIFACT", "STYLE_DRIFT",
)
# Reviewed counterevidence for an EXACT frozen output, not an inherited PASS.
# The current pixel reader still recomputes every measurement. New video bytes
# have no entry and cannot borrow this decision; missing/tampered inputs fail.
# Keeping the binding outside mutable receipts prevents self-anchored discovery.
REGISTERED_VISUAL_WORD_EVIDENCE = {
    "sha256:4ac18eda5812a86c33f4a4fed34f07cef70542e4faa2268eaa3dc5fde4003d8f": {
        "path": "output/production/phase6/video-002/quality/visual-measurements/owned-word-gate-consumption-v2-20260922/measurement.json",
        "sha256": "sha256:f98f36398a385f29cd901d3e8a1390138ee9b3b32c998be3e7988ae9f3ab92ac",
    },
}
# Independent source-composed reference frames, not synthetic codec controls.
# A one-sided negative is applicable only to these exact frozen video bytes.
REGISTERED_VISUAL_PALETTE_EVIDENCE = {
    "sha256:4ac18eda5812a86c33f4a4fed34f07cef70542e4faa2268eaa3dc5fde4003d8f": {
        "path": "output/production/phase6/video-002/quality/visual-measurements/clocked-palette-population-20260927/measurement.json",
        "sha256": "sha256:419fdb0625090c489bbe5a2b3295d2174d0aafb9b41b1e509eca308639b7a565",
    },
}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(8):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 7:
                raise
            time.sleep(min(0.5, 0.05 * (2 ** attempt)))


def _write_immutable(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").replace("\n", os.linesep).encode("utf-8")
    if path.is_file():
        if path.read_bytes() != encoded:
            raise PermissionError(f"immutable quality evaluation collision: {path.name}")
        return _read(path)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(encoded)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != encoded:
                raise PermissionError(f"immutable quality evaluation collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)
    return _read(path)


def _sha(path: Path, *, prefixed: bool = False) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    value = digest.hexdigest()
    return f"sha256:{value}" if prefixed else value


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


_VISUAL_INTENT_READ_SCOPE = ContextVar('phase6_visual_intent_read_scope', default=None)


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    resolved = (path if path.is_absolute() else root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"quality/media evidence escaped project root: {value}") from exc
    scope = _VISUAL_INTENT_READ_SCOPE.get()
    if scope is not None and scope[0] == root.resolve():
        bound = scope[1].get(resolved.relative_to(root.resolve()).as_posix())
        if bound is not None:
            archived = (root / bound['path']).resolve()
            if (not archived.is_relative_to(root.resolve()) or not archived.is_file()
                    or archived.stat().st_size != bound['size_bytes']
                    or _sha(archived, prefixed=True) != bound['sha256']):
                raise PermissionError('authenticated visual intent archive changed')
            return archived
    return resolved


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(
        _read(root / "schemas" / schema_name), format_checker=FormatChecker()
    ).validate(value)


def _gate(name: str, passed: bool | None, method: str, threshold: Any, observed: Any, evidence: list[str]) -> dict[str, Any]:
    return {
        "gate": name,
        "critical": True,
        "status": "BLOCKED" if passed is None else ("PASS" if passed else "FAIL"),
        "method": method,
        "threshold": threshold,
        "observed": observed,
        "evidence_refs": list(dict.fromkeys(evidence)),
    }


def _creative_concept_integrity(concept: dict[str, Any]) -> dict[str, Any]:
    """Recompute the generator's decision instead of trusting its labels."""

    rows = concept.get("candidate_assessments") or []
    weights = concept.get("score_weights") or {}
    search = concept.get("creative_search") or {}
    selected = concept.get("selected_concept") or {}
    ids = [str(item.get("concept_id") or "") for item in rows]
    score_rows_valid = True
    eligibility_rows_valid = True
    for item in rows:
        components = item.get("score_components") or {}
        try:
            recomputed = round(sum(float(weights[key]) * float(components[key]) for key in weights), 6)
            score_rows_valid = score_rows_valid and set(components) == set(weights) and recomputed == float(item.get("selection_score"))
        except (KeyError, TypeError, ValueError):
            score_rows_valid = False
        checks = item.get("critical_checks") or {}
        expected_eligible = bool(checks) and all(value is True for value in checks.values())
        red_team_status = (item.get("red_team") or {}).get("status")
        eligibility_rows_valid = eligibility_rows_valid and item.get("eligible") is expected_eligible and red_team_status == ("PASS" if expected_eligible else "FAIL")
    eligible = [item for item in rows if item.get("eligible") is True]
    selected_row = next((item for item in rows if item.get("concept_id") == selected.get("concept_id")), None)
    maximum_similarity = max((float((item.get("red_team") or {}).get("maximum_candidate_similarity") or 0) for item in rows), default=0.0)
    maximum_source_overlap = max((float((item.get("red_team") or {}).get("maximum_source_title_overlap") or 0) for item in rows), default=0.0)
    search_valid = bool(
        search.get("minimum_candidate_count") == 6
        and search.get("candidate_count") == len(rows)
        and search.get("eligible_candidate_count") == len(eligible)
        and search.get("distinct_candidate_ids") is True
        and len(ids) == len(set(ids))
        and all(ids)
        and float(search.get("maximum_pairwise_similarity", -1)) == round(maximum_similarity, 6)
        and float(search.get("maximum_source_title_overlap", -1)) == round(maximum_source_overlap, 6)
        and search.get("red_team_status") == "PASS"
    )
    winner_valid = bool(
        selected_row
        and selected_row.get("eligible") is True
        and eligible
        and float(selected_row.get("selection_score")) == max(float(item["selection_score"]) for item in eligible)
        and float(selected.get("selection_score")) == float(selected_row.get("selection_score"))
    )
    compiler_identity = concept.get("compiler_identity") or {}
    compiler_identity_payload = dict(compiler_identity)
    compiler_identity_hash = compiler_identity_payload.pop("identity_sha256", None)
    recomputed_compiler_identity_hash = "sha256:" + hashlib.sha256(
        json.dumps(
            compiler_identity_payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    checks = {
        "compiler_version": concept.get("compiler_version") == "phase6-adaptive-creative-compiler-v3",
        "schema_version": concept.get("schema_version") == "1.2.0",
        "compiler_identity": bool(
            compiler_identity.get("compiler_version") == concept.get("compiler_version")
            and compiler_identity.get("identity_version")
            == "phase6-preproduction-compiler-identity-v1"
            and compiler_identity_hash == recomputed_compiler_identity_hash
        ),
        "channel_identity": concept.get("channel_id") == CHANNEL_ID,
        "publication_locked": concept.get("publication_authorized") is False,
        "zero_cost": concept.get("technical_cost_brl") == 0,
        "minimum_search_breadth": len(rows) >= 6 and len(eligible) >= 3,
        "score_recomputation": score_rows_valid,
        "eligibility_recomputation": eligibility_rows_valid,
        "search_summary_recomputation": search_valid,
        "winner_recomputation": winner_valid,
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "candidate_count": len(rows),
        "eligible_candidate_count": len(eligible),
        "selected_concept_id": selected.get("concept_id"),
    }


def _defect(name: str, passed: bool | None, method: str, threshold: Any, observed: Any, evidence: list[str]) -> dict[str, Any]:
    return {
        "defect": name,
        "status": "NEEDS_REVIEW" if passed is None else ("PASS" if passed else "FAIL"),
        "method": method,
        "threshold": threshold,
        "observed": observed,
        "evidence_refs": list(dict.fromkeys(evidence)),
    }


def _visual_reference_from_verified_media(root: Path, media: dict[str, Any]) -> dict[str, Any]:
    """Bind canonical sources/intent to the exact target, without fitting it.

    This is the input producer for automatic visual measurements. It observes
    no anatomy/physics and grants no quality authority. In particular, the
    generated video cannot become its own pre-compression or semantic reference.
    Existing production/media verifiers own authorization; this adds an exact
    rational frame map and all five current production artifact bindings.
    """
    from .phase6_visual_metrics import VERSION, inventory

    manifest = media["manifest"]
    manifest_path = _resolve(root, str(media["manifest_path"]))
    manifest_raw = manifest_path.read_bytes()
    if json.loads(manifest_raw) != manifest:
        raise PermissionError("visual reference manifest changed before capture")
    target_path = _resolve(root, str(media["video"]))
    target_binding = {"path": _relative(root, target_path), "sha256": manifest["output"]["content_hash"],
                      "size_bytes": manifest["output"]["size_bytes"]}
    production = root / BASE / "production"
    paths = {name: production / f"{name}.json" for name in (
        "take_plan", "asset_allocation", "channel_style_bible", "creative_treatment_plan",
        "creative_direction_decision")}
    raw = {name: path.read_bytes() for name, path in paths.items()}
    values = {name: json.loads(data) for name, data in raw.items()}
    plan, allocation = values["take_plan"], values["asset_allocation"]
    integrity = _input_integrity(root, allocation)
    if not integrity["passed"]:
        raise PermissionError("canonical visual reference requires current production-input integrity")
    receipt_path = root / PRODUCTION_INPUT_RECEIPTS / (integrity["receipt_id"] + ".json")
    receipt_raw = receipt_path.read_bytes()
    receipt = json.loads(receipt_raw)
    declared = {item["path"]: item for item in receipt["artifacts"]}
    if len(declared) != len(receipt["artifacts"]):
        raise PermissionError("visual reference duplicate artifact binding")
    bindings = []
    for name, path in paths.items():
        relative = _relative(root, path)
        bound = {"path": relative, "sha256": "sha256:" + hashlib.sha256(raw[name]).hexdigest(), "size_bytes": len(raw[name])}
        if declared.get(relative) != bound:
            raise PermissionError("visual reference artifact differs from immutable production receipt: " + name)
        bindings.append(bound)
    if manifest["take_plan_id"] != plan["take_plan_id"] or manifest["style_bible_id"] != values["channel_style_bible"]["style_bible_id"]:
        raise PermissionError("visual reference intent belongs to another render")
    if manifest["creative_treatment_plan_id"] != values["creative_treatment_plan"]["treatment_plan_id"]:
        raise PermissionError("visual reference treatment identity differs")
    if len(allocation["takes"]) != len(plan["takes"]) or len(manifest["segment_timeline"]) != len(plan["takes"]):
        raise PermissionError("visual reference take population differs")
    allocated = {item["take_id"]: item for item in allocation["takes"]}
    treated = {item["take_id"] for item in values["creative_treatment_plan"]["takes"]}
    if len(allocated) != len(allocation["takes"]) or len(treated) != len(plan["takes"]) or len(values["creative_treatment_plan"]["takes"]) != len(plan["takes"]):
        raise PermissionError("visual reference duplicate/missing take")
    fps = Fraction(str(manifest["output"]["fps"]))
    if fps <= 0:
        raise PermissionError("invalid visual reference frame rate")
    cursor = 0
    sources: dict[str, dict[str, Any]] = {}
    rows = []
    for take, actual in zip(plan["takes"], manifest["segment_timeline"]):
        identity = take["take_id"]
        if identity != actual["take_id"] or identity not in allocated or identity not in treated:
            raise PermissionError("visual reference take order/coverage differs")
        start = Fraction(str(take["start_ms"])) * fps / 1000
        end = Fraction(str(take["end_ms"])) * fps / 1000
        if start.denominator != 1 or end.denominator != 1 or int(start) != cursor or end <= start:
            raise PermissionError("visual reference is not a contiguous frame-exact timeline")
        if actual["frame_count"] != int(end - start) or Fraction(str(actual["actual_start_ms"])) * fps / 1000 != start or Fraction(str(actual["actual_end_ms"])) * fps / 1000 != end:
            raise PermissionError("visual reference measured timeline differs from intent")
        source = allocated[identity]
        source_path = _resolve(root, source["source_path"])
        relative = _relative(root, source_path)
        if relative not in sources:
            sources[relative] = {"path": relative, "sha256": _sha(source_path, prefixed=True), "size_bytes": source_path.stat().st_size}
        if sources[relative]["sha256"] != source["content_hash"]:
            raise PermissionError("canonical visual source hash changed: " + identity)
        if source_path == target_path or sources[relative]["sha256"] == target_binding["sha256"]:
            raise PermissionError("candidate cannot be its own canonical visual source")
        origin, sep, span = str(take["asset_origin"]).partition("#t=")
        if not sep or _resolve(root, origin) != source_path:
            raise PermissionError("visual reference source/TakePlan origin differs")
        origin_start, origin_end = (Fraction(value) * 1000 for value in span.split(","))
        source_start, source_end = Fraction(str(source["source_start_ms"])), Fraction(str(source["source_end_ms"]))
        if origin_start != source_start or origin_end != source_end or source_start < 0 or source_end - source_start < Fraction(str(take["end_ms"])) - Fraction(str(take["start_ms"])):
            raise PermissionError("visual reference source span is inconsistent")
        rows.append({"take_id": identity, "asset_id": source["asset_id"], "target_start_frame": int(start), "target_end_frame_exclusive": int(end),
                     "frame_count": int(end - start), "source": sources[relative],
                     "source_start_ms": str(source_start), "source_end_ms": str(source_end),
                     "timestamp_rule": "source_start_ms + 1000*(target_frame-target_start_frame)/fps; decoder PTS must be observed, not assumed",
                     "camera_intent": take.get("camera"), "motion_intent": take.get("movement"), "environment": take.get("environment")})
        cursor = int(end)
    if len({item["take_id"] for item in rows}) != len(rows) or cursor != manifest["measurements"]["expected_total_frames"]:
        raise PermissionError("visual reference final frame population differs")
    # Reopen after collection: this is not a copy accepted merely by filename.
    for bound in bindings + list(sources.values()) + [target_binding]:
        path = _resolve(root, bound["path"])
        if path.stat().st_size != bound["size_bytes"] or _sha(path, prefixed=True) != bound["sha256"]:
            raise PermissionError("visual reference inputs changed during capture")
    if receipt_path.read_bytes() != receipt_raw:
        raise PermissionError("visual reference production receipt changed during capture")
    if manifest_path.read_bytes() != manifest_raw:
        raise PermissionError("visual reference manifest changed during capture")
    value = {"version": VERSION, "reference_id": "pending", "status": "CANONICAL_INPUTS_BOUND_MEASUREMENTS_PENDING",
             "render_id": manifest["render_id"], "target": target_binding,
             "render_manifest": {"path": _relative(root, manifest_path), "sha256": "sha256:" + hashlib.sha256(manifest_raw).hexdigest(), "size_bytes": len(manifest_raw)},
             "production_receipt": {"path": _relative(root, receipt_path), "sha256": "sha256:" + hashlib.sha256(receipt_raw).hexdigest()},
             "intent_bindings": sorted(bindings, key=lambda item: item["path"]), "sources": sorted(sources.values(), key=lambda item: item["path"]),
             "fps": {"numerator": fps.numerator, "denominator": fps.denominator}, "frame_count": cursor, "takes": rows,
             "required_measurements": inventory(), "reference_is_target": False,
             "semantic_source_quality_proved": False, "measurement_coverage_frames": 0,
             "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    value["reference_id"] = "phase6-visual-reference-" + hashlib.sha256(json.dumps({k:v for k,v in value.items() if k != "reference_id"}, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()[:32]
    return value


def build_phase6_visual_reference(root: Path = ROOT) -> dict[str, Any]:
    """Public read-only reference producer; no QA, queue, render or publication."""
    root = root.resolve()
    media, reason = _verified_media(root)
    if media is None:
        raise PermissionError(reason)
    return _visual_reference_from_verified_media(root, media)


def materialize_phase6_visual_reference(root: Path = ROOT) -> Path:
    reference = build_phase6_visual_reference(root)
    path = root / BASE / "quality/visual-references" / (reference["reference_id"] + ".json")
    _write_immutable(path, reference)
    return path


def _visual_reference_intent_storage(root: Path, reference: dict) -> tuple[dict, list]:
    """Resolve only receipt-bound intent history, never arbitrary stale inputs.

    The externally anchored reference retains its original logical bytes. A
    different, authenticated current command can move its five former intents
    to the archive created by the existing before-overwrite transaction. This
    grants no quality/production authority to either command.
    """
    intents = reference['intent_bindings']
    def intact(item):
        path = _resolve(root, item['path'])
        return (path.is_file() and ('size_bytes' not in item or path.stat().st_size == item['size_bytes'])
                and _sha(path, prefixed=True) == item['sha256'])
    if all(intact(item) for item in intents):
        return {}, []
    from . import phase6_media_authority as authority
    from .phase6_current_production_inputs import LATEST_VIEW, PRODUCTION_VIEW

    bound = reference['production_receipt']
    old_path = _resolve(root, bound['path'])
    old_raw = old_path.read_bytes()
    if 'sha256:' + hashlib.sha256(old_raw).hexdigest() != bound['sha256']:
        raise PermissionError('visual reference immutable input receipt drift')
    old = json.loads(old_raw)
    expected = root / PRODUCTION_INPUT_RECEIPTS / (old['receipt_id'] + '.json')
    if old_path != expected.resolve():
        raise PermissionError('visual reference input receipt is not canonical')
    def records(items):
        return sorted((item['path'], item['sha256'], item['size_bytes']) for item in items)
    if len(intents) != 5 or records(intents) != records(old['artifacts']):
        raise PermissionError('visual reference intents differ from immutable receipt')
    latest_path = root / LATEST_VIEW
    current_raw = latest_path.read_bytes()
    current = json.loads(current_raw)
    if current['receipt_id'] == old['receipt_id']:
        raise PermissionError('visual reference current intent drift is not a successor')
    current_path = root / PRODUCTION_INPUT_RECEIPTS / (current['receipt_id'] + '.json')
    if (current_path.resolve().parent != (root / PRODUCTION_INPUT_RECEIPTS).resolve()
            or current_path.read_bytes() != current_raw
            or (root / PRODUCTION_VIEW).read_bytes() != current_raw):
        raise PermissionError('visual reference current receipt aliases differ')
    checked, work, _ = authority._load_historical_input_envelope(root, current['receipt_id'])
    if checked != current:
        raise PermissionError('visual reference successor changed during authentication')
    _, current_lineage = authority._production_bundle(root, receipt=current, archived=False)
    _, old_lineage = authority._production_bundle(root, receipt=old, archived=True)
    by_name = {item['name']: item for item in old_lineage['production_artifacts']}
    storage = {item['path']: by_name[Path(item['path']).name] for item in intents}
    current_binding = {'sha256': 'sha256:' + hashlib.sha256(current_raw).hexdigest(),
                       'size_bytes': len(current_raw)}
    frozen_evidence = [{'path': item['immutable_path'], 'sha256': item['sha256'],
                        'size_bytes': item['size_bytes']} for item in current['evidence_bindings']]
    dependencies = [old_lineage['archive_receipt'], current_lineage['input_receipt'],
                    current['work_order'], *frozen_evidence,
                    *current_lineage['production_artifacts'],
                    *({'path': str(path).replace('\\', '/'), **current_binding}
                      for path in (LATEST_VIEW, PRODUCTION_VIEW))]
    if old_path.read_bytes() != old_raw or current_path.read_bytes() != current_raw:
        raise PermissionError('visual reference receipts changed during authentication')
    return storage, dependencies


def read_phase6_visual_reference(root: Path, path: str | Path, *, expected_sha256: str) -> dict[str, Any]:
    # Always authenticate real current aliases before resolving any historical
    # intent. The private read capability cannot authorize itself recursively.
    token = _VISUAL_INTENT_READ_SCOPE.set(None)
    try:
        return _read_phase6_visual_reference(root, path, expected_sha256=expected_sha256)
    finally:
        _VISUAL_INTENT_READ_SCOPE.reset(token)


def _read_phase6_visual_reference(root: Path, path: str | Path, *, expected_sha256: str) -> dict[str, Any]:
    """Read an externally bound reference; authenticate bytes, not a PASS label."""
    root = root.resolve()
    path = _resolve(root, str(path))
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_sha256):
        raise PermissionError("visual reference requires explicit SHA-256 anchor")
    raw = path.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("visual reference anchor mismatch")
    value = json.loads(raw)
    payload = {key: item for key, item in value.items() if key != "reference_id"}
    identity = "phase6-visual-reference-" + hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()[:32]
    if value["reference_id"] != identity or path.name != identity + ".json":
        raise PermissionError("visual reference identity mismatch")
    from .phase6_visual_metrics import VERSION, inventory
    if value["version"] != VERSION or value["required_measurements"] != inventory():
        raise PermissionError("visual reference measurement contract differs")
    if any(value[key] is not False for key in ("quality_authorized", "render_authorized", "publication_authorized", "semantic_source_quality_proved", "reference_is_target")):
        raise PermissionError("input reference cannot grant quality authority")
    storage, dependencies = _visual_reference_intent_storage(root, value)
    intents = [storage.get(item['path'], item) for item in value['intent_bindings']]
    for bound in intents + dependencies + value["sources"] + [value["target"], value["render_manifest"], value["production_receipt"]]:
        source = _resolve(root, bound["path"])
        if ("size_bytes" in bound and source.stat().st_size != bound["size_bytes"]) or _sha(source, prefixed=True) != bound["sha256"]:
            raise PermissionError("visual reference input drift: " + bound["path"])
    if path.read_bytes() != raw:
        raise PermissionError('visual reference changed during authentication')
    return value


def measure_phase6_mux_transfer(
    root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
    take_ids: tuple[str, ...], output_directory: Path,
) -> dict[str, Any]:
    """Observe final-encode transfer using authenticated pre-mux segments.

    This bounded diagnostic is a real pixel consumer, not quality approval.
    Pre-mux segments cannot certify defects already present in the source or
    first encode. A midpoint triplet does NOT imply full-duration coverage.
    No queue, render, existing QA receipt or operational state is changed.
    """
    from .phase6_visual_metrics import colour_measurements, spatial_measurements, temporal_mixture, VisualMeasurementUnavailable, extract_indexed_frames
    import numpy as np
    from PIL import Image

    root = root.resolve()
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("mux observation requires a new confined evidence directory")
    if not take_ids or len(take_ids) != len(set(take_ids)):
        raise ValueError("distinct nonempty take IDs required")
    selected = [row for row in reference["takes"] if row["take_id"] in take_ids]
    if len(selected) != len(take_ids) or any(row["frame_count"] < 3 for row in selected):
        raise ValueError("unknown take or insufficient temporal support")
    manifest = _read(_resolve(root, reference["render_manifest"]["path"]))
    segment_set = verify_phase6_segment_set(root, manifest["segment_receipt_set"])
    records = {row["take_id"]: row for row in segment_set["receipts"]}
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])
    frames = sorted({row["target_start_frame"] + row["frame_count"] // 2 + offset for row in selected for offset in (-1, 0, 1)})
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    target = _resolve(root, reference["target"]["path"])
    observations = extract_indexed_frames(target, frames, directory / "candidate", fps=fps)
    results = []
    for row in selected:
        record = records[row["take_id"]]
        receipt_path = _resolve(root, record["path"])
        receipt_raw = receipt_path.read_bytes()
        if "sha256:" + hashlib.sha256(receipt_raw).hexdigest() != record["sha256"]:
            raise PermissionError("segment receipt drift before observation")
        receipt = json.loads(receipt_raw)
        middle = row["frame_count"] // 2
        segment = _resolve(root, receipt["segment"]["path"])
        if _sha(segment, prefixed=True) != receipt["segment"]["sha256"] or segment == target:
            raise PermissionError("pre-mux segment mismatch/self reference")
        canonical = extract_indexed_frames(segment, [middle - 1, middle, middle + 1], directory / row["take_id"], fps=fps)
        def pixels(record):
            with Image.open(record["path"]) as image:
                return np.asarray(image.convert("RGB"))
        before, current, after = (pixels(canonical[index]) for index in (middle - 1, middle, middle + 1))
        observed = pixels(observations[row["target_start_frame"] + middle])
        measurements = {"spatial": spatial_measurements(current, observed), "colour": colour_measurements(current, observed)}
        try:
            measurements["temporal"] = temporal_mixture(before, current, after, observed)
        except VisualMeasurementUnavailable as exc:
            measurements["temporal"] = {"status": "UNOBSERVABLE", "variable": str(exc)}
        results.append({"take_id": row["take_id"], "target_frame": row["target_start_frame"] + middle,
                        "measurement": measurements, "reference_receipt": {"path": _relative(root, receipt_path), "sha256": record["sha256"]},
                        "reference_frames": list(canonical.values()),
                        "candidate_frames": [observations[row["target_start_frame"] + index] for index in (middle - 1, middle, middle + 1)]})
        if receipt_path.read_bytes() != receipt_raw or _sha(segment, prefixed=True) != receipt["segment"]["sha256"]:
            raise PermissionError("pre-mux source changed during observation")
    read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    result = {"version": "phase6-mux-transfer-observation-v1", "status": "MEASURED_PARTIAL_SCOPE_NOT_QUALITY_APPROVAL",
              "scope": "ADDED_AT_FINAL_MUX_ONLY; not first encode, intrinsic anatomy, physics or semantic style",
              "reference": {"path": _relative(root, _resolve(root, str(reference_path))), "sha256": expected_reference_sha256},
              "render_id": reference["render_id"], "reference_frame_count": reference["frame_count"],
              "decoded_candidate_observations": len(observations), "measured_centre_frames": len(results),
              "full_duration_coverage": False, "tolerance": None, "tolerance_reason": "Instrument controls/holdout must define this scope before verdict; no target-fitted threshold.",
              "measurements": results, "elapsed_seconds": time.monotonic() - started,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def measure_phase6_existing_temporal_identifiability(
    root: Path, *, receipt_path: str | Path, expected_sha256: str,
    output_directory: Path,
) -> dict[str, Any]:
    """New missing identifiability evidence from already decoded, bound pixels.

    No decode/OCR/inference or channel render is repeated. This consumer does
    not upgrade a post-mux sample to full-duration/intrinsic-source approval.
    The receipt anchor must come from the caller's previously preserved proof.
    """
    import io
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import temporal_noise_sensitivity, indexed_frame_clock, VisualMeasurementUnavailable

    root = root.resolve()
    path = _resolve(root, str(receipt_path))
    raw = path.read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("temporal observation receipt anchor differs")
    value = json.loads(raw)
    if (value.get("version") != "phase6-mux-transfer-observation-v1"
            or value.get("full_duration_coverage") is not False
            or value.get("quality_authorized") is not False):
        raise PermissionError("temporal observation scope is incompatible")
    reference = read_phase6_visual_reference(root, value["reference"]["path"],
        expected_sha256=value["reference"]["sha256"])
    if value["render_id"] != reference["render_id"] or value["reference_frame_count"] != reference["frame_count"]:
        raise PermissionError("temporal observation video identity differs")
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError("temporal observation needs a new confined evidence directory")
    seen, captured, rows = set(), {path: expected_sha256}, []
    takes = {row["take_id"]: row for row in reference["takes"]}
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])

    def pixels(frame):
        frame_path = _resolve(root, frame["path"])
        frame_raw = frame_path.read_bytes()
        sha = "sha256:" + hashlib.sha256(frame_raw).hexdigest()
        if sha != frame["sha256"]:
            raise PermissionError("temporal frame bytes differ")
        with Image.open(io.BytesIO(frame_raw)) as image:
            rgb = np.asarray(image.convert("RGB"))
        if (rgb.shape != (frame["height"], frame["width"], 3)
                or "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest() != frame["decoded_rgb_sha256"]):
            raise PermissionError("temporal decoded pixel identity differs")
        captured[frame_path] = sha
        return rgb

    for observation in value["measurements"]:
        take_id = observation["take_id"]
        if take_id in seen or take_id not in takes:
            raise PermissionError("temporal sample population is ambiguous")
        seen.add(take_id)
        take = takes[take_id]
        middle = take["frame_count"] // 2
        refs, outs = observation["reference_frames"], observation["candidate_frames"]
        if (observation["target_frame"] != take["target_start_frame"] + middle
                or [f["frame_index"] for f in refs] != list(range(middle-1, middle+2))
                or [f["frame_index"] for f in outs] != list(range(observation["target_frame"]-1, observation["target_frame"]+2))):
            raise PermissionError("temporal sample clock/indices differ")
        for frame in refs + outs:
            try:
                expected_ms, rounding = indexed_frame_clock(frame['frame_index'], fps)
            except VisualMeasurementUnavailable as exc:
                raise PermissionError('temporal frame clock is invalid') from exc
            fields = ('expected_pts_ms', 'pts_ms', 'pts_rounding_tolerance_ms')
            if (any(type(frame.get(name)) not in (float, int) or not math.isfinite(frame[name]) for name in fields)
                    or frame['pts_rounding_tolerance_ms'] != rounding
                    or frame['expected_pts_ms'] != expected_ms
                    or abs(frame['pts_ms']-expected_ms) > rounding):
                raise PermissionError("temporal presentation timestamp differs")
        frames = [pixels(f) for f in refs]
        candidate = [pixels(f) for f in outs]
        try:
            result = temporal_noise_sensitivity(*frames, candidate[1])
        except VisualMeasurementUnavailable as exc:
            result = {"status": "UNOBSERVABLE", "cause": str(exc), "quality_authorized": False}
        rows.append({"take_id": take_id, "target_frame": observation["target_frame"], "measurement": result})
    if not rows or len(rows) != value["measured_centre_frames"]:
        raise PermissionError("temporal sample population is incomplete")
    for item, sha in captured.items():
        if _sha(item, prefixed=True) != sha:
            raise PermissionError("temporal evidence changed during measurement")
    read_phase6_visual_reference(root, value["reference"]["path"], expected_sha256=value["reference"]["sha256"])
    result = {"version": "phase6-temporal-identifiability-v1", "status": "MEASURED_INSTRUMENT_LIMITS_NOT_QUALITY_APPROVAL",
              "input": {"path": _relative(root, path), "sha256": expected_sha256}, "target": reference["target"],
              "measurements": rows, "measured_centre_frames": len(rows), "expected_video_frames": reference["frame_count"],
              "evidence_bindings": [{"path": _relative(root, p), "sha256": sha} for p, sha in captured.items()],
              "full_duration_coverage": False, "scope": value["scope"],
              "new_decodes": 0, "new_ocr": 0, "new_channel_renders": 0,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def measure_composed_reference_states(references, candidate, *, expected_index: int):
    """Compare independently composed states without translating canvas effects.

    The squared-distance difference cancels common residual energy. Dividing
    by reference separation expresses the observation along each *declared*
    difference: zero at the expected state, one at the alternative. It is not
    an unrestricted displacement estimate or a perceptual acceptance limit.
    Identical reference states (including full fades) remain unobservable.
    Callers must authenticate the source, clock and composition of each state;
    an arbitrary array is not an independently authorized reference.
    """
    import numpy as np
    from .phase6_visual_metrics import VisualMeasurementUnavailable
    refs = [np.asarray(frame) for frame in references]
    out = np.asarray(candidate)
    if (not 2 <= len(refs) <= 30 or type(expected_index) is not int
            or not 0 <= expected_index < len(refs) or out.dtype != np.uint8
            or out.ndim != 3 or out.shape[-1] != 3 or min(out.shape[:2]) < 2
            or any(frame.dtype != np.uint8 or frame.shape != out.shape for frame in refs)):
        raise VisualMeasurementUnavailable('matched RGB composed states and exact expected index required')
    # Accumulate exact integer-code sums in float64; never round weak RGB to
    # uint8 luminance or resample/rectify the observed candidate.
    expected = refs[expected_index].astype(np.float64)
    residual = out.astype(np.float64) - expected
    squared = float(np.sum(residual * residual))
    comparisons, distances = [], []
    for index, frame in enumerate(refs):
        delta = frame.astype(np.float64) - expected
        separation = float(np.sum(delta * delta))
        projection = float(np.sum(residual * delta))
        mse = (squared + separation - 2 * projection) / out.size
        distances.append(mse)
        if index != expected_index:
            comparisons.append({'alternative_index': index,
                'reference_separation_mse': separation / out.size,
                'status': 'OBSERVED' if separation else 'UNOBSERVABLE_IDENTICAL_STATES',
                'difference_coordinate': projection / separation if separation else None,
                'normalized_margin': 1 - 2 * projection / separation if separation else None})
    minimum = min(distances)
    nearest = [index for index, distance in enumerate(distances) if distance == minimum]
    observable = all(row['difference_coordinate'] is not None for row in comparisons)
    return {'method': 'independently-composed-state-contrast-v1',
        'status': 'COMPOSED_STATES_OBSERVED' if observable else 'INCOMPLETE_REFERENCE_SEPARATION',
        'expected_index': expected_index, 'reference_count': len(refs),
        'nearest_reference_indices': nearest, 'squared_rgb_distances': distances,
        'comparisons': comparisons, 'all_alternatives_distinguishable': observable,
        'maximum_absolute_difference_coordinate': max(abs(r['difference_coordinate']) for r in comparisons) if observable else None,
        'candidate_image_resampled': False, 'unrestricted_motion_estimate': False,
        'tolerance': None, 'quality_authorized': False, 'render_authorized': False,
        'publication_authorized': False}


def _validate_population_face_observation(observation, frame):
    from .phase6_av_detector_semantics import validate_raw
    from .phase6_publicity import YUNET_SHA256
    import cv2
    if (observation.get('version')!='phase6-yunet-face-geometry-v1'
            or observation.get('model_sha256')!='sha256:'+YUNET_SHA256
            or any(observation.get(k) is not False for k in ('identity_proved','zero_detections_proves_absence','quality_authorized'))
            or observation.get('decoded_rgb_sha256')!=frame['decoded_rgb_sha256']
            or any(type(observation.get(k)) is not int or observation[k]!=frame[k] for k in ('width','height'))):
        raise PermissionError('face population observation pixels/model/authority differs')
    parsed=validate_raw(observation['raw'],source_width=frame['width'],source_height=frame['height'],
                        observed_opencv_version=cv2.__version__)
    if type(observation.get('face_count')) is not int or observation['face_count']!=parsed['face_count']:
        raise PermissionError('face population count differs from raw output')
    return parsed['face_count']


def _face_population_prior(root, binding, reference):
    if binding is None:return {},None
    if (not isinstance(binding,dict) or set(binding)!={'path','sha256'}
            or not re.fullmatch(r'sha256:[0-9a-f]{64}',str(binding['sha256']))):
        raise PermissionError('face population prior requires exact anchor')
    path=_resolve(root,binding['path']);raw=path.read_bytes()
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=binding['sha256']:
        raise PermissionError('face population prior anchor differs')
    prior=json.loads(raw)
    if (prior.get('version')!='phase6-mux-face-geometry-transfer-v1'
            or prior.get('target')!=reference['target'] or prior.get('point_population')!='face-geometry-v1'
            or prior.get('status')!='FACE_OBSERVATIONS_RECORDED_NOT_QUALITY_APPROVAL'
            or any(prior.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized',
                'identity_proved','zero_detections_proves_absence','full_duration_coverage',
                'intrinsic_face_quality_proved','temporal_identity_tracking_proved'))):
        raise PermissionError('face population prior scope differs')
    takes={row['take_id']:row for row in reference['takes']};result={};seen=set()
    for take in prior['measurements']:
        identity=take['take_id']
        if identity not in takes or identity in seen or len(take['measurements_by_frame'])!=3:
            raise PermissionError('face population prior take set differs')
        seen.add(identity);known=takes[identity];middle=known['target_start_frame']+known['frame_count']//2
        if take.get('target_frame')!=middle:raise PermissionError('face population prior centre differs')
        for offset,row in enumerate(take['measurements_by_frame']):
            index=row['candidate_frame_index']
            if type(index) is not int or index!=middle+offset-1 or index in result:
                raise PermissionError('face population prior frame index differs')
            result[index]=row['candidate_observation']
    if prior.get('measured_frame_pairs')!=len(result) or prior.get('measured_centre_frames')!=len(seen):
        raise PermissionError('face population prior counts differ')
    return result,(path,raw)


def measure_phase6_face_population(root: Path, *, reference_path: str | Path,
        expected_reference_sha256: str, output_directory: Path, prior_geometry: dict | None = None,
        timeout_seconds: float = 1800) -> dict[str,Any]:
    """Complete serial target census, not an absence/identity/quality verdict.

    Reuses the indexed decoder and YuNet observer. Keeps a journal of exact
    clocks/RGB hashes/raw observations, not thousands of PNGs. Prior target
    observations are reused only after byte-identical decoded RGB is checked.
    Partial journals survive failure but cannot produce a completed receipt.
    """
    import cv2
    from . import phase6_visual_metrics as metrics, phase6_visual_landmarks as landmarks
    from . import phase6_publicity as publicity, phase6_av_detector_semantics as semantics
    if type(timeout_seconds) not in (int,float) or not math.isfinite(timeout_seconds) or not 0<timeout_seconds<=1800:
        raise ValueError('face population requires a bounded deadline')
    root=root.resolve()
    reference=read_phase6_visual_reference(root,reference_path,expected_sha256=expected_reference_sha256)
    total=reference['frame_count'];fps=Fraction(reference['fps']['numerator'],reference['fps']['denominator'])
    if type(total) is not int or not 0<total<=108000:raise PermissionError('face population exceeds bounded horizon')
    directory=_resolve(root,str(output_directory))
    if (root/BASE/'quality/visual-measurements').resolve() not in directory.parents or directory.exists():
        raise PermissionError('face population requires new confined output')
    prior,prior_file=_face_population_prior(root,prior_geometry,reference)
    frame_takes=[]
    for take in reference['takes']:
        if take['target_start_frame']!=len(frame_takes) or take['target_end_frame_exclusive']-take['target_start_frame']!=take['frame_count']:
            raise PermissionError('face population timeline differs')
        frame_takes.extend([take['take_id']]*take['frame_count'])
    if len(frame_takes)!=total:raise PermissionError('face population timeline incomplete')
    modules=[Path(__file__),Path(metrics.__file__),Path(landmarks.__file__),Path(publicity.__file__),Path(semantics.__file__)]
    sources={root/'hero_engine'/path.name:path.read_bytes() for path in modules}
    if any(path.read_bytes()!=raw for path,raw in sources.items()):raise PermissionError('face population resident instrument differs')
    directory.mkdir(parents=True);(directory/'instrument').mkdir()
    snapshots=[]
    for path,raw in sources.items():
        snapshot=directory/'instrument'/path.name
        with snapshot.open('xb') as stream:stream.write(raw)
        snapshots.append({'source_path':_relative(root,path),'path':_relative(root,snapshot),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()})
    journal=directory/'frames.jsonl';observer=None;new_count=0;reused_count=0;started=time.monotonic();canvas=None
    with journal.open('x',encoding='utf-8',newline='\n') as stream:
        def observe(frame,rgb):
            nonlocal observer,new_count,reused_count,canvas
            index=frame['frame_index'];reuse=index in prior
            shape={'width':frame['width'],'height':frame['height']}
            if canvas is None:canvas=shape
            if canvas!=shape:raise PermissionError('face population canvas changed')
            if reuse:
                observation=prior[index];reused_count+=1
            else:
                if observer is None:observer=landmarks.FaceObserver(root)
                observation=observer.observe(rgb);new_count+=1
            _validate_population_face_observation(observation,frame)
            record={**frame,'take_id':frame_takes[index],'observation_origin':'REUSED_EXACT_TARGET_RGB' if reuse else 'NEW_NATIVE_OBSERVATION',
                    'observation':observation}
            stream.write(json.dumps(record,ensure_ascii=False,sort_keys=True,allow_nan=False,separators=(',',':'))+'\n');stream.flush()
            return observation
        try:
            frames=metrics.extract_indexed_frames(_resolve(root,reference['target']['path']),list(range(total)),directory/'decode',
                fps=fps,timeout_seconds=timeout_seconds,frame_observer=observe,retain_pixels=False,require_eof=True)
        except Exception as exc:
            _write_immutable(directory/'failure.json',{'type':type(exc).__name__,'error':str(exc),'new_observations':new_count,
                'reused_observations':reused_count,'elapsed_seconds':time.monotonic()-started,'quality_authorized':False})
            raise
    read_phase6_visual_reference(root,reference_path,expected_sha256=expected_reference_sha256)
    if (any(path.read_bytes()!=raw for path,raw in sources.items())
            or prior_file is not None and prior_file[0].read_bytes()!=prior_file[1]
            or observer is not None and observer.path.read_bytes()!=observer.data):
        raise PermissionError('face population inputs changed during measurement')
    counts=[frames[i]['observation']['face_count'] for i in range(total)]
    result={'version':'phase6-complete-face-population-v1','status':'OBSERVED_COMPLETE_POPULATION_NOT_ABSENCE_OR_IDENTITY',
        'reference':{'path':_relative(root,_resolve(root,str(reference_path))),'sha256':expected_reference_sha256},
        'target':reference['target'],'prior_geometry':prior_geometry,'frame_count':total,'fps':reference['fps'],'canvas':canvas,
        'journal':{'path':_relative(root,journal),'sha256':_sha(journal,prefixed=True),'size_bytes':journal.stat().st_size},
        'instrument_snapshots':snapshots,'opencv_version':cv2.__version__,'decoder':'OPENCV_FFMPEG_SERIAL_RGB24',
        'new_face_inferences':new_count,'reused_face_observations':reused_count,
        'frames_with_detections':sum(n>0 for n in counts),'face_instances':sum(counts),
        'observed_end_of_stream':True,'complete_frame_population_observed':True,'saved_frame_images':0,
        'elapsed_seconds':time.monotonic()-started,'zero_detections_proves_absence':False,'identity_proved':False,
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    return _write_immutable(directory/'measurement.json',result)


def read_phase6_face_population(root: Path, receipt_path: str | Path, *, expected_sha256: str) -> dict[str,Any]:
    """Authenticate a complete census without repeating decode or inference."""
    import cv2
    from .phase6_visual_metrics import indexed_frame_clock
    root=root.resolve();path=_resolve(root,str(receipt_path));raw=path.read_bytes()
    if not re.fullmatch(r'sha256:[0-9a-f]{64}',str(expected_sha256)) or 'sha256:'+hashlib.sha256(raw).hexdigest()!=expected_sha256:
        raise PermissionError('face population receipt anchor differs')
    value=json.loads(raw)
    if (value.get('version')!='phase6-complete-face-population-v1' or value.get('status')!='OBSERVED_COMPLETE_POPULATION_NOT_ABSENCE_OR_IDENTITY'
            or value.get('observed_end_of_stream') is not True or value.get('complete_frame_population_observed') is not True
            or value.get('opencv_version')!=cv2.__version__ or value.get('decoder')!='OPENCV_FFMPEG_SERIAL_RGB24'
            or any(value.get(k) is not False for k in ('zero_detections_proves_absence','identity_proved','quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('face population scope/authority differs')
    if any(type(value.get(k)) is not int or value[k]<0 for k in ('frame_count','new_face_inferences','reused_face_observations',
            'frames_with_detections','face_instances','saved_frame_images')):
        raise PermissionError('face population totals must be integer observations')
    ref=value['reference'];reference=read_phase6_visual_reference(root,ref['path'],expected_sha256=ref['sha256'])
    if value['target']!=reference['target'] or value['fps']!=reference['fps'] or value['frame_count']!=reference['frame_count']:
        raise PermissionError('face population target/clock differs')
    saved={path:raw}
    for item in value['instrument_snapshots']+[value['journal']]:
        source=_resolve(root,item['path']);data=source.read_bytes()
        if path.parent not in source.parents or 'sha256:'+hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise PermissionError('face population evidence differs')
        saved[source]=data
    names={'phase6_quality.py','phase6_visual_metrics.py','phase6_visual_landmarks.py','phase6_publicity.py','phase6_av_detector_semantics.py'}
    if (len(value['instrument_snapshots'])!=5 or {Path(x['source_path']).name for x in value['instrument_snapshots']}!=names
            or any(x['source_path']!='hero_engine/'+Path(x['source_path']).name
                or _resolve(root,x['path'])!=path.parent/'instrument'/Path(x['source_path']).name for x in value['instrument_snapshots'])):
        raise PermissionError('face population instrument set differs')
    prior,prior_file=_face_population_prior(root,value['prior_geometry'],reference)
    journal=_resolve(root,value['journal']['path']);data=saved[journal]
    if len(data)!=value['journal']['size_bytes'] or not data.endswith(b'\n'):raise PermissionError('face population journal incomplete')
    rows=data.splitlines();fps=Fraction(value['fps']['numerator'],value['fps']['denominator'])
    takes=[take['take_id'] for take in reference['takes'] for _ in range(take['frame_count'])]
    if len(rows)!=reference['frame_count'] or len(takes)!=len(rows):raise PermissionError('face population frame count differs')
    new=reused=faces=positive=0
    for index,line in enumerate(rows):
        row=json.loads(line);expected,tolerance=indexed_frame_clock(index,fps)
        if (type(row.get('frame_index')) is not int or row['frame_index']!=index or row['take_id']!=takes[index]
                or row['verified_seek_frame']!=0 or row['decoded_frames_to_observation']!=index+1
                or row['pixel_storage']!='HASH_ONLY_TARGET_REPLAY' or row['expected_pts_ms']!=expected
                or row['pts_rounding_tolerance_ms']!=tolerance or type(row['pts_ms']) not in (int,float)
                or not math.isfinite(row['pts_ms']) or abs(row['pts_ms']-expected)>tolerance
                or not re.fullmatch(r'sha256:[0-9a-f]{64}',str(row['decoded_rgb_sha256']))):
            raise PermissionError('face population frame identity/PTS differs')
        if any(type(row.get(k)) is not int or row[k]<=0 or row[k]!=value['canvas'][k] for k in ('width','height')):
            raise PermissionError('face population canvas differs')
        count=_validate_population_face_observation(row['observation'],row);faces+=count;positive+=count>0
        if row['observation_origin']=='REUSED_EXACT_TARGET_RGB':
            if row['observation']!=prior.get(index):raise PermissionError('face population reused observation differs')
            reused+=1
        elif row['observation_origin']=='NEW_NATIVE_OBSERVATION':new+=1
        else:raise PermissionError('face population observation origin unknown')
    if (value['new_face_inferences']!=new or value['reused_face_observations']!=reused or value['frames_with_detections']!=positive
            or value['face_instances']!=faces or value['saved_frame_images']!=0):raise PermissionError('face population totals differ')
    read_phase6_visual_reference(root,ref['path'],expected_sha256=ref['sha256'])
    if any(source.read_bytes()!=data for source,data in saved.items()) or prior_file is not None and prior_file[0].read_bytes()!=prior_file[1]:
        raise PermissionError('face population evidence changed during reading')
    return value


def measure_phase6_existing_motion_transfer(root: Path, *, receipt_path: str | Path,
        expected_sha256: str, output_directory: Path,
        point_population: str = 'composite',
        face_geometry_evidence: dict[str, str] | None = None) -> dict[str, Any]:
    """New trajectory observation on already authenticated mux triplets.

    No video decode, render or repetition of the temporal-mixture measurement.
    Face geometry performs YuNet inference; face-region-v1 instead reopens
    externally anchored prior geometry and adds only prompt-free regional
    inference where observed landmarks give it support. Empty authenticated
    populations explicitly abstain before loading the regional model; they
    never establish absence of faces. No historical metric or approval is inherited. This observes
    only change added by the final mux, not the
    source's motion, complete camera path, anatomy or full-video acceptance.
    """
    import io
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import reference_motion_transfer, indexed_frame_clock

    root = root.resolve()
    if point_population not in ('composite', 'declared-source-v1', 'composed-states-v1', 'face-geometry-v1', 'face-region-v1'):
        raise ValueError('unknown motion point population')
    if (point_population == 'face-region-v1') != (face_geometry_evidence is not None):
        raise PermissionError('regional motion requires exact prior geometry; other modes cannot consume it')
    path = _resolve(root, str(receipt_path))
    raw = path.read_bytes()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_sha256) or "sha256:" + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError("motion input receipt anchor differs")
    value = json.loads(raw)
    if (value.get("version") != "phase6-mux-transfer-observation-v1"
            or value.get("full_duration_coverage") is not False or value.get("quality_authorized") is not False
            or value.get("scope") != "ADDED_AT_FINAL_MUX_ONLY; not first encode, intrinsic anatomy, physics or semantic style"
            or type(value.get("measured_centre_frames")) is not int):
        raise PermissionError("motion input scope/authority invalid")
    reference = read_phase6_visual_reference(root, value["reference"]["path"], expected_sha256=value["reference"]["sha256"])
    if value["render_id"] != reference["render_id"] or value["reference_frame_count"] != reference["frame_count"]:
        raise PermissionError("motion target identity differs")
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError("motion observation requires new confined directory")
    saved, rows, seen = {path: raw}, [], set()
    prior_faces = None
    if face_geometry_evidence is not None:
        if (not isinstance(face_geometry_evidence, dict) or set(face_geometry_evidence) != {'path','sha256'}
                or not re.fullmatch(r'sha256:[0-9a-f]{64}', str(face_geometry_evidence['sha256']))):
            raise PermissionError('regional motion geometry anchor invalid')
        prior_path = _resolve(root, face_geometry_evidence['path'])
        prior_raw = prior_path.read_bytes()
        if 'sha256:'+hashlib.sha256(prior_raw).hexdigest() != face_geometry_evidence['sha256']:
            raise PermissionError('regional motion geometry bytes differ')
        prior = json.loads(prior_raw)
        if (prior.get('version') != 'phase6-mux-face-geometry-transfer-v1'
                or prior.get('point_population') != 'face-geometry-v1'
                or prior.get('status') != 'FACE_OBSERVATIONS_RECORDED_NOT_QUALITY_APPROVAL'
                or prior.get('target') != reference['target']
                or prior.get('input',{}).get('sha256') != expected_sha256
                or _resolve(root, prior.get('input',{}).get('path','')) != path
                or prior.get('measured_centre_frames') != value['measured_centre_frames']
                or prior.get('measured_frame_pairs') != value['measured_centre_frames']*3
                or any(prior.get(k) is not False for k in ('quality_authorized','render_authorized',
                    'publication_authorized','full_duration_coverage','identity_proved',
                    'intrinsic_face_quality_proved','temporal_identity_tracking_proved','zero_detections_proves_absence'))
                or not isinstance(prior.get('measurements'), list)
                or [r.get('take_id') for r in prior['measurements']] != [r['take_id'] for r in value['measurements']]):
            raise PermissionError('regional motion geometry lineage/population/authority differs')
        prior_faces = {r['take_id']:r for r in prior['measurements']}
        saved[prior_path] = prior_raw
    if point_population in ('composed-states-v1', 'face-geometry-v1', 'face-region-v1'):
        executing = Path(__file__).resolve()
        resident = root / 'hero_engine' / executing.name
        data = resident.read_bytes()
        if data != executing.read_bytes():
            raise PermissionError('composed state executing implementation differs')
        saved[resident] = data
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])
    takes = {row["take_id"]: row for row in reference["takes"]}
    layout_context = None
    face_observer = None
    region_observer, region_cache = None, {}
    if point_population in ('declared-source-v1', 'face-geometry-v1', 'face-region-v1'):
        from . import phase6_visual_recipe as recipe
        from . import phase6_visual_metrics as metrics
        from . import render_creative_v2_phase5 as renderer
        # Authenticate the executing instrument, not a different root's copy.
        instruments = [recipe, metrics, renderer]
        if point_population in ('face-geometry-v1', 'face-region-v1'):
            from . import phase6_visual_landmarks as landmarks
            from . import phase6_av_detector_semantics as semantics
            from . import phase6_publicity as publicity
            instruments.extend((landmarks, semantics, publicity))
            if point_population == 'face-region-v1':
                from . import phase6_visual_anatomy as anatomy
                instruments.append(anatomy)
        for module in instruments:
            executing = Path(module.__file__).resolve()
            resident = root / 'hero_engine' / executing.name
            data = resident.read_bytes()
            if data != executing.read_bytes():
                raise PermissionError('motion layout implementation being executed differs')
            saved[resident] = data
        font = renderer._font()
        saved[font] = font.read_bytes()
        docs = {}
        for binding in reference['intent_bindings']:
            source = _resolve(root, binding['path'])
            data = source.read_bytes()
            if 'sha256:'+hashlib.sha256(data).hexdigest() != binding['sha256']:
                raise PermissionError('motion layout intent changed before reading')
            saved[source] = data
            docs[source.stem] = json.loads(data)
        plans = {row['take_id']: row for row in docs['take_plan']['takes']}
        directions = {row['take_id']: row for row in docs['creative_treatment_plan']['takes']}
        if (len(plans) != len(docs['take_plan']['takes']) or len(directions) != len(docs['creative_treatment_plan']['takes'])
                or set(plans) != set(takes) or set(directions) != set(takes)):
            raise PermissionError('motion layout take population differs')
        layout_context = (recipe, font, plans, directions)

    def pixels(frame, index):
        expected_ms, tolerance = indexed_frame_clock(index, fps)
        if (type(frame.get("frame_index")) is not int or frame["frame_index"] != index
                or any(type(frame.get(k)) not in (int, float) or not math.isfinite(frame[k])
                       for k in ("expected_pts_ms", "pts_ms", "pts_rounding_tolerance_ms"))
                or frame["expected_pts_ms"] != expected_ms or frame["pts_rounding_tolerance_ms"] != tolerance
                or abs(frame["pts_ms"]-expected_ms) > tolerance):
            raise PermissionError("motion frame clock differs")
        source = _resolve(root, frame["path"])
        data = source.read_bytes()
        if "sha256:" + hashlib.sha256(data).hexdigest() != frame["sha256"]:
            raise PermissionError("motion frame bytes differ")
        with Image.open(io.BytesIO(data)) as image:
            rgb = np.asarray(image.convert("RGB"))
        if (rgb.shape != (frame["height"], frame["width"], 3)
                or "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest() != frame["decoded_rgb_sha256"]):
            raise PermissionError("motion decoded pixels differ")
        saved[source] = data
        return rgb

    for row in value["measurements"]:
        take_id = row["take_id"]
        if take_id in seen or take_id not in takes:
            raise PermissionError("motion take population ambiguous")
        seen.add(take_id)
        take = takes[take_id]
        middle = take["frame_count"] // 2
        target = take["target_start_frame"] + middle
        if (type(row["target_frame"]) is not int or row["target_frame"] != target
                or len(row["reference_frames"]) != 3 or len(row["candidate_frames"]) != 3):
            raise PermissionError("motion take frame population differs")
        refs = [pixels(f, middle+i-1) for i, f in enumerate(row["reference_frames"])]
        outs = [pixels(f, target+i-1) for i, f in enumerate(row["candidate_frames"])]
        times = [float(Fraction(i, 1)/fps) for i in range(3)]
        if point_population in ('face-geometry-v1', 'face-region-v1'):
            recipe, font, plans, directions = layout_context
            layout = recipe.inspect_visual_layout(plans[take_id], directions[take_id], font=font)
            if face_observer is None and prior_faces is None:
                face_observer = landmarks.FaceObserver(root)
                saved[face_observer.path] = face_observer.data
            if prior_faces is not None:
                prior_row = prior_faces[take_id]
                if (prior_row.get('target_frame') != target or prior_row.get('declared_layout') != layout
                        or len(prior_row.get('measurements_by_frame', [])) != 3):
                    raise PermissionError('regional motion prior frame population/layout differs')
            face_rows = []
            for index, (before, after) in enumerate(zip(refs, outs)):
                if prior_faces is None:
                    source_faces = face_observer.observe(before)
                    target_faces = face_observer.observe(after)
                else:
                    recorded = prior_row['measurements_by_frame'][index]
                    if (recorded.get('reference_frame_index') != middle+index-1
                            or recorded.get('candidate_frame_index') != target+index-1):
                        raise PermissionError('regional motion prior frame clock differs')
                    source_faces = recorded['reference_observation']
                    target_faces = recorded['candidate_observation']
                comparison = landmarks.compare_face_geometry(source_faces, target_faces, before, after, layout=layout)
                face_rows.append({'reference_frame_index': middle+index-1,
                    'candidate_frame_index': target+index-1,
                    'reference_observation': source_faces, 'candidate_observation': target_faces,
                    'comparison': comparison})
            regional_args = [{},{}]
            # Use the parsed/raw-validated populations, never caller counts or
            # the historical comparison. Without any landmarks in either
            # triplet there is no region/point relation to measure. Preserve
            # the empty geometry and explicit abstention instead of spending
            # an inference or supplying fabricated all-background masks.
            has_observed_face_support = any(
                pair['comparison']['reference_face_count'] or pair['comparison']['candidate_face_count']
                for pair in face_rows)
            if prior_faces is not None and has_observed_face_support:
                if region_observer is None:
                    region_observer = anatomy.FaceOcclusionObserver(root)
                    saved[region_observer.path] = region_observer.path.read_bytes()
                for side, frames in enumerate((refs, outs)):
                    observations, masks = [], []
                    for index, frame in enumerate(frames):
                        pixel_hash = 'sha256:'+hashlib.sha256(frame.tobytes()).hexdigest()
                        if pixel_hash not in region_cache:
                            measured, mask = region_observer.observe(frame,
                                spatial_contract='native-fullhd-pad32-diagnostic')
                            # Revalidate every proposal before retaining any mask.
                            faces = face_rows[index]['reference_observation' if side==0 else 'candidate_observation']
                            landmarks.measure_face_region_membership(frame,faces,measured,mask,layout=layout)
                            region_path = directory/'regions'/(pixel_hash.removeprefix('sha256:')+'.png')
                            region_path.parent.mkdir(parents=True,exist_ok=True)
                            with region_path.open('xb') as stream: Image.fromarray(mask).save(stream,format='PNG')
                            saved[region_path] = region_path.read_bytes()
                            binding = {'path':_relative(root,region_path),
                                'sha256':'sha256:'+hashlib.sha256(saved[region_path]).hexdigest()}
                            region_cache[pixel_hash] = (measured,mask,binding)
                        measured,mask,binding = region_cache[pixel_hash]
                        observations.append(measured);masks.append(mask)
                        face_rows[index]['reference_region' if side==0 else 'candidate_region'] = {
                            'observation':measured,'mask':binding}
                    regional_args[side] = {'region_observations':observations,'region_masks':masks}
            reference_tracks = landmarks.measure_face_temporal_correspondence(
                [item['reference_observation'] for item in face_rows], refs,
                frame_indices=[item['reference_frame_index'] for item in face_rows], fps=fps, layout=layout, **regional_args[0])
            candidate_tracks = landmarks.measure_face_temporal_correspondence(
                [item['candidate_observation'] for item in face_rows], outs,
                frame_indices=[item['candidate_frame_index'] for item in face_rows], fps=fps, layout=layout, **regional_args[1])
            commuting = []
            for index, (a, b) in enumerate(zip(reference_tracks['steps'], candidate_tracks['steps'])):
                status = 'RECIPROCAL_PIXEL_ASSOCIATION_MEASURED_NOT_IDENTITY'
                same_relation = None
                if a['status'] == status and b['status'] == status:
                    mapping_before = {m['reference_face']:m['candidate_face'] for m in face_rows[index]['comparison']['matches']}
                    mapping_after = {m['reference_face']:m['candidate_face'] for m in face_rows[index+1]['comparison']['matches']}
                    target_links = {m['from_face']:m['to_face'] for m in b['links']}
                    if len(mapping_before) == a['from_face_count'] and len(mapping_after) == a['to_face_count']:
                        same_relation = all(target_links.get(mapping_before[m['from_face']]) == mapping_after[m['to_face']]
                                    for m in a['links'])
                commuting.append({'reference_from_frame':a['from_frame_index'],
                    'candidate_from_frame':b['from_frame_index'], 'same_correspondence_relation':same_relation,
                    'identity_proved':False, 'quality_authorized':False})
            rows.append({'take_id': take_id, 'target_frame': target,
                         'measurements_by_frame': face_rows, 'declared_layout': layout,
                         'reference_temporal_correspondence':reference_tracks,
                         'candidate_temporal_correspondence':candidate_tracks,
                         'paired_temporal_correspondence':commuting})
            if prior_faces is not None:
                rows[-1]['regional_measurement_status'] = (
                    'MODEL_REGIONS_OBSERVED_NOT_VISIBILITY' if has_observed_face_support
                    else 'NO_OBSERVED_FACE_SUPPORT_NOT_ABSENCE')
        elif point_population == 'composed-states-v1':
            # The authenticated pre-mux triplet supplies independent complete
            # compositions, including fixed vignette/text. Never warp that field.
            result = [measure_composed_reference_states(refs, out, expected_index=i)
                      for i, out in enumerate(outs)]
            rows.append({'take_id': take_id, 'target_frame': target,
                         'measurements_by_frame': result,
                         'reference_state_frame_indices': [f['frame_index'] for f in row['reference_frames']]})
        elif layout_context is None:
            result = reference_motion_transfer(refs, outs, times)
            rows.append({"take_id": take_id, "target_frame": target, "measurement": result})
        else:
            recipe, font, plans, directions = layout_context
            layout = recipe.inspect_visual_layout(plans[take_id], directions[take_id], font=font)
            result = reference_motion_transfer(refs, outs, times, source_layout=layout)
            rows.append({'take_id': take_id, 'target_frame': target, 'measurement': result,
                         'declared_layout': layout, 'camera_intent': take.get('camera_intent'),
                         'motion_intent': take.get('motion_intent')})
    if not rows or len(rows) != value["measured_centre_frames"]:
        raise PermissionError("motion take population incomplete")
    if any(p.read_bytes() != data for p, data in saved.items()):
        raise PermissionError("motion input changed during measurement")
    read_phase6_visual_reference(root, value["reference"]["path"], expected_sha256=value["reference"]["sha256"])
    result = {"version": "phase6-mux-motion-transfer-v1", "status": "OBSERVED_PARTIAL_MOTION_NOT_QUALITY_APPROVAL",
              "input": {"path": _relative(root, path), "sha256": expected_sha256}, "target": reference["target"],
              "measurements": rows, "scope": value["scope"], "full_duration_coverage": False,
              "evidence_bindings": [{"path": _relative(root, p), "sha256": "sha256:"+hashlib.sha256(data).hexdigest()} for p, data in saved.items()],
              "measured_centre_frames": len(rows), "expected_video_frames": reference["frame_count"],
              "new_decodes": 0, "new_ocr": 0, "new_channel_renders": 0,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    if point_population == 'declared-source-v1':
        result.update(version='phase6-mux-source-region-motion-v1', point_population=point_population,
                      source_role='DECLARED_NON_OVERLAY_REGION_NOT_BACKGROUND_IDENTITY',
                      historical_command_witness=False)
    if point_population == 'composed-states-v1':
        result.update(version='phase6-mux-composed-state-transfer-v1', point_population=point_population,
                      reference_role='AUTHENTICATED_PRE_MUX_COMPOSITION_NOT_INTRINSIC_SOURCE_TRUTH',
                      unrestricted_motion_estimate=False, historical_command_witness=False)
    if point_population == 'face-geometry-v1':
        result.update(version='phase6-mux-face-geometry-transfer-v1', point_population=point_population,
            status='FACE_OBSERVATIONS_RECORDED_NOT_QUALITY_APPROVAL', measured_frame_pairs=len(rows)*3,
            face_inferences=len(rows)*6, identity_proved=False, zero_detections_proves_absence=False,
            intrinsic_face_quality_proved=False, temporal_identity_tracking_proved=False,
            reference_role='AUTHENTICATED_PRE_MUX_COMPOSITION_NOT_INTRINSIC_SOURCE_TRUTH')
    if point_population == 'face-region-v1':
        result.update(version='phase6-mux-face-regional-transfer-v2',point_population=point_population,
            status='REGIONAL_FACE_TRANSPORT_OBSERVED_NOT_QUALITY_APPROVAL',
            takes_without_observed_face_support=sum(
                row['regional_measurement_status']=='NO_OBSERVED_FACE_SUPPORT_NOT_ABSENCE' for row in rows),
            face_geometry_evidence=face_geometry_evidence,measured_frame_pairs=len(rows)*3,
            face_inferences=0,reused_face_observations=len(rows)*6,region_inferences=len(region_cache),
            region_cache_scope='EXACT_PIXEL_BYTES_THIS_INVOCATION_ONLY',
            historical_metrics_reused=False,identity_proved=False,zero_detections_proves_absence=False,
            intrinsic_face_quality_proved=False,temporal_identity_tracking_proved=False,
            reference_role='AUTHENTICATED_PRE_MUX_COMPOSITION_NOT_INTRINSIC_SOURCE_TRUTH')
    materialized = _write_immutable(directory / "measurement.json", result)
    # The new regional contract returns exactly what its file consumer reads
    # (LK contains tuple settings, whose JSON representation is a list).
    return materialized if point_population == 'face-region-v1' else result


def read_declared_planar_crop_trace(stderr: str) -> list[dict[str, Any]]:
    """Read the native crop's geometry, not coordinates inferred from a video.

    This contract is the existing 18-second, 30fps, 2048x1152 -> 1920x1080
    procedural path. Six printed decimals bound time rounding only; they are
    not a tolerance for visual quality or a historical execution witness.
    """
    pattern = re.compile(r'\[Parsed_crop_\d+ @ [^\]]+\] n:(\d+) t:(\d+\.\d{6}) x:(\d+) y:(\d+) x\+w:(\d+) y\+h:(\d+)')
    rows = []
    for match in pattern.finditer(stderr):
        n, stamp, x, y, right, bottom = match.groups()
        n, x, y, right, bottom = map(int, (n, x, y, right, bottom))
        if (n != len(rows) or abs(Fraction(stamp)-Fraction(n,30)) > Fraction(1,2000000)
                or not 0 <= x <= 128 or not 0 <= y <= 72 or x % 2 or y % 2
                or right-x != 1920 or bottom-y != 1080):
            raise PermissionError('declared crop trace clock/geometry differs')
        rows.append({'source_frame': n, 'time_seconds': str(Fraction(n,30)), 'crop_xy': [x,y]})
    if len(rows) != 540:
        raise PermissionError('declared crop trace population incomplete or ambiguous')
    return rows


def measure_phase6_declared_planar_motion(root: Path, *, motion_path: str | Path,
        expected_motion_sha256: str, asset_manifest_path: str | Path,
        expected_manifest_sha256: str, expected_producer_sha256: str,
        output_directory: Path, trace_receipt_path: str | Path | None = None,
        expected_trace_sha256: str | None = None) -> dict[str, Any]:
    """Compare retained tracks to independently observed declared crop geometry.

    The producer's current legacy declaration is a normative reference, not
    evidence that an old process executed that command. Assets without that
    exact declared raster lineage stay unqualified. No camera fit, threshold,
    inference, channel-media generation, or quality authority is introduced.
    """
    import ast
    import io
    import time
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import trajectory_error
    from .render_creative_v2_phase5 import _font
    root = root.resolve()
    if (trace_receipt_path is None) != (expected_trace_sha256 is None):
        raise ValueError('trace reuse requires a receipt and independent SHA-256 anchor')
    saved = {}
    def read(path, anchor):
        path = _resolve(root, str(path))
        raw = path.read_bytes()
        if (not re.fullmatch(r'sha256:[0-9a-f]{64}', str(anchor))
                or 'sha256:'+hashlib.sha256(raw).hexdigest() != anchor):
            raise PermissionError('planar motion reference anchor mismatch: '+path.name)
        saved[path] = raw
        return raw
    motion = json.loads(read(motion_path, expected_motion_sha256))
    if (motion.get('version') != 'phase6-mux-source-region-motion-v1'
            or motion.get('point_population') != 'declared-source-v1'
            or motion.get('historical_command_witness') is not False
            or motion.get('full_duration_coverage') is not False
            or any(motion.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('planar motion input scope invalid')
    for binding in motion['evidence_bindings']:
        path = Path(binding['path'])
        # A system font may be outside the project; it is read-only and remains
        # bound. All source/data paths use the confined reader above.
        if path.is_absolute() and not path.resolve().is_relative_to(root):
            if path.resolve() != _font().resolve():
                raise PermissionError('unknown external planar motion dependency')
            raw = path.read_bytes()
            if 'sha256:'+hashlib.sha256(raw).hexdigest() != binding['sha256']:
                raise PermissionError('planar motion external dependency drift')
            saved[path] = raw
        else:
            read(path, binding['sha256'])
    source = json.loads(read(motion['input']['path'], motion['input']['sha256']))
    reference = read_phase6_visual_reference(root, source['reference']['path'], expected_sha256=source['reference']['sha256'])
    if (motion['target'] != reference['target'] or source.get('version') != 'phase6-mux-transfer-observation-v1'
            or source.get('render_id') != reference['render_id']
            or source.get('reference_frame_count') != reference['frame_count']
            or source.get('full_duration_coverage') is not False or source.get('quality_authorized') is not False
            or source.get('scope') != 'ADDED_AT_FINAL_MUX_ONLY; not first encode, intrinsic anatomy, physics or semantic style'):
        raise PermissionError('planar motion target differs')
    producer = read('hero_engine/procedural_infographics_phase5.py', expected_producer_sha256)
    module = ast.parse(producer)
    function = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name=='_render')
    commands = [n.value for n in function.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id=='command' for t in n.targets)
                and isinstance(n.value, ast.List)]
    if len(commands) != 1:
        raise PermissionError('ambiguous declared procedural branch')
    tokens = [n.value if isinstance(n, ast.Constant) else None for n in commands[0].elts]
    graph = "scale=2048:1152:force_original_aspect_ratio=increase,crop=1920:1080:x='64+60*sin(t*1.70)':y='36+32*cos(t*1.30)',fade=t=in:st=0:d=0.35,fade=t=out:st=17.45:d=0.55,format=yuv420p"
    if (tokens.count('-vf') != 1 or tokens[tokens.index('-vf')+1] != graph
            or tokens[tokens.index('-framerate')+1] != '30' or tokens[tokens.index('-r')+1] != '30'):
        raise PermissionError('unsupported declared procedural motion contract')
    manifest = json.loads(read(asset_manifest_path, expected_manifest_sha256))
    if manifest.get('generator') != 'HeroVerseLocalVectorMotion@1.0.1':
        raise PermissionError('unsupported declared asset generator')
    assets = {a['asset_id']:a for a in manifest['assets']}
    if len(assets) != len(manifest['assets']):
        raise PermissionError('ambiguous declared asset population')
    takes = {t['take_id']:t for t in reference['takes']}
    seen, eligible = set(), {}
    for row in motion['measurements']:
        take_id = row['take_id']
        if take_id in seen or take_id not in takes:
            raise PermissionError('planar motion take population differs')
        seen.add(take_id)
        take = takes[take_id]
        if row['target_frame'] != take['target_start_frame']+take['frame_count']//2:
            raise PermissionError('planar motion frame identity differs')
        asset = assets.get(take['asset_id'])
        if asset is None:
            continue
        if (asset['generator'] != 'HeroVerseLocalVectorMotion@1.0.1+FFmpeg'
                or _resolve(root,asset['video_path']) != _resolve(root,take['source']['path'])
                or asset['video_hash'] != take['source']['sha256'] or asset['duration_seconds'] != 18
                or reference['fps'] != {'numerator':30,'denominator':1}
                or row['declared_layout']['canvas'] != {'width':1920,'height':1080}):
            raise PermissionError('declared planar source identity/geometry differs')
        read(asset['svg_path'],asset['svg_hash'])
        raster = read(asset['raster_path'],asset['raster_hash'])
        with Image.open(io.BytesIO(raster)) as image:
            if image.format != 'PNG' or image.size != (1920,1080) or getattr(image,'n_frames',1) != 1:
                raise PermissionError('declared source is not a single canonical raster')
        origin = Fraction(take['source_start_ms'])*30/1000 + take['frame_count']//2-1
        if origin.denominator != 1 or not 0 <= origin < 538:
            raise PermissionError('declared source clock outside reference domain')
        eligible[take_id] = int(origin)
    if not eligible:
        raise PermissionError('no declared planar asset in observed population')
    directory = _resolve(root, str(output_directory))
    allowed = (root/BASE/'quality/visual-measurements').resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError('planar motion requires new confined evidence directory')
    binary = Path(FFMPEG).resolve()
    binary_hash = _sha(binary, prefixed=True)
    command = [str(binary), '-nostdin', '-hide_banner', '-loglevel', 'trace', '-filter_threads','1',
        '-f','lavfi','-i','color=black:s=2048x1152:r=30:d=18,format=yuv420p',
        '-vf',graph.split(',')[1],'-frames:v','540','-an','-threads','1','-f','null','-']
    replay = None
    if trace_receipt_path is not None:
        trace_path = _resolve(root, str(trace_receipt_path))
        replay = json.loads(read(trace_path, expected_trace_sha256))
        if (replay.get('version') != 'phase6-declared-planar-motion-v1'
                or replay.get('reference_basis') != 'CURRENT_DECLARED_RASTER_TRANSFORM_NOT_HISTORICAL_EXECUTION'
                or replay.get('motion') != {'path':_relative(root,_resolve(root,str(motion_path))),
                                            'sha256':expected_motion_sha256}
                or replay.get('command') != command or type(replay.get('process_exit_code')) is not int
                or replay['process_exit_code'] != 0
                or replay.get('binary') != {'path':str(binary),'sha256':binary_hash}
                or any(replay.get(key) is not False for key in ('quality_authorized','render_authorized',
                    'publication_authorized','historical_command_witness','full_duration_visual_coverage'))):
            raise PermissionError('planar trace replay scope/identity differs')
        bound = {}
        for binding in replay['evidence_bindings']:
            path = Path(binding['path'])
            if path.is_absolute() and not path.resolve().is_relative_to(root):
                if path.resolve() != _font().resolve():
                    raise PermissionError('unknown external trace replay dependency')
                path = path.resolve()
                data = path.read_bytes()
                if _sha(path,prefixed=True) != binding['sha256']:
                    raise PermissionError('trace replay font drift')
                saved[path] = data
            else:
                path = _resolve(root,str(path))
                data = read(path,binding['sha256'])
            if path in bound:
                raise PermissionError('duplicate trace replay binding')
            bound[path] = data
        stderr_path = trace_path.parent/'crop.stderr.log'
        if stderr_path not in bound or trace_path.parent/'crop.stdout.log' not in bound:
            raise PermissionError('trace replay lacks bound native output')
        trace = read_declared_planar_crop_trace(bound[stderr_path].decode('utf-8',errors='strict'))
        if replay.get('trace') != trace:
            raise PermissionError('trace replay summary differs from native bytes')
        exit_code = replay['process_exit_code']
    else:
        directory.mkdir(parents=True,exist_ok=False)
        start = time.monotonic()
        timed_out = False
        try:
            process = subprocess.run(command, capture_output=True, timeout=30,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            stdout, stderr, exit_code = process.stdout, process.stderr, process.returncode
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, exit_code = exc.stdout or b'', exc.stderr or b'', None
            timed_out = True
        elapsed = time.monotonic()-start
        for name,data in (('crop.stdout.log',stdout),('crop.stderr.log',stderr)):
            path=directory/name
            with path.open('xb') as stream: stream.write(data)
            saved[path]=data
        _write_immutable(directory/'process-result.json', {'command':command,'exit_code':exit_code,'timed_out':timed_out,
            'elapsed_seconds':elapsed,'binary_sha256':binary_hash,'synthetic_geometry_only':True,
            'historical_command_witness':False,'channel_media_generated':False})
        if exit_code != 0:
            raise PermissionError('declared crop observation failed; preserve process evidence')
        trace = read_declared_planar_crop_trace(stderr.decode('utf-8',errors='strict'))
    results = []
    for row in motion['measurements']:
        take_id = row['take_id']
        if take_id not in eligible:
            results.append({'take_id':take_id,'status':'NO_DECLARED_PLANAR_SOURCE_REFERENCE','quality_authorized':False})
            continue
        clocks = trace[eligible[take_id]:eligible[take_id]+3]
        offsets = np.asarray([c['crop_xy'] for c in clocks],dtype=float)
        shift = offsets[0]-offsets
        times = [float(Fraction(c['time_seconds'])) for c in clocks]
        points = []
        for point in row['measurement']['rows']:
            result = {'point_index':point['point_index'],'status':point['status'], 'comparisons':None}
            if point['measurement'] is not None:
                comparisons = {}
                for key in ('reference_track','candidate_track'):
                    tracks = point[key]
                    if len(tracks)!=3 or any(t['status']!='PIXEL_TRACK_OBSERVED' for t in tracks):
                        raise PermissionError('declared motion observed track incomplete')
                    observed = np.asarray([t['observed_xy'] for t in tracks],dtype=float)
                    expected = observed[0]+shift
                    comparisons[key] = {**trajectory_error(times,expected,observed),
                        'position_residual_px':(observed-expected).tolist(),
                        'maximum_position_residual_px':float(np.linalg.norm(observed-expected,axis=1).max())}
                result['comparisons'] = comparisons
            points.append(result)
        if len(points)!=row['measurement']['selected_points']:
            raise PermissionError('declared motion selected population differs')
        results.append({'take_id':take_id,'status':'DECLARED_PLANAR_REFERENCE_COMPARED',
            'source_frame_clock':clocks,'expected_displacement_px':shift.tolist(),'points':points,
            'tolerance':None,'camera_quality_approved':False})
    coverage = None
    if replay is not None:
        # Enumerate the whole target timeline, not only the three existing
        # observations. Declared source clocks are NEVER pixel measurements.
        population, cursor, referenced_frames = [], 0, 0
        compared = {row['take_id']:row for row in results if 'points' in row}
        observed_frames = set()
        for take in reference['takes']:
            count = take['frame_count']
            if (type(count) is not int or count <= 0 or take['target_start_frame'] != cursor
                    or take['target_end_frame_exclusive'] != cursor+count):
                raise PermissionError('planar coverage target clock/population differs')
            row = {'take_id':take['take_id'],'asset_id':take['asset_id'],
                'target_start_frame':cursor,'target_end_frame_exclusive':cursor+count,
                'frame_count':count,'reference_frames':[],'pixel_observed_target_frames':[],
                'full_frame_visual_coverage':False,'quality_authorized':False}
            asset = assets.get(take['asset_id'])
            if asset is None:
                row['status'] = 'NO_DECLARED_PLANAR_SOURCE_REFERENCE'
            else:
                if (asset['generator'] != 'HeroVerseLocalVectorMotion@1.0.1+FFmpeg'
                        or _resolve(root,asset['video_path']) != _resolve(root,take['source']['path'])
                        or asset['video_hash'] != take['source']['sha256'] or asset['duration_seconds'] != 18):
                    raise PermissionError('planar coverage source identity differs')
                read(asset['svg_path'],asset['svg_hash'])
                raster = read(asset['raster_path'],asset['raster_hash'])
                with Image.open(io.BytesIO(raster)) as image:
                    if image.format!='PNG' or image.size!=(1920,1080) or getattr(image,'n_frames',1)!=1:
                        raise PermissionError('planar coverage raster geometry differs')
                origin = Fraction(take['source_start_ms'])*30/1000
                if (origin.denominator!=1 or origin<0 or origin+count>len(trace)
                        or Fraction(take['source_end_ms'])*30/1000<origin+count):
                    raise PermissionError('planar coverage source clock outside trace')
                row['status'] = 'DECLARED_CLOCK_BOUND_PIXEL_COVERAGE_PENDING'
                row['reference_frames'] = [{'target_frame':cursor+i, **trace[int(origin)+i]}
                                           for i in range(count)]
                referenced_frames += count
                observation = compared.get(take['take_id'])
                if observation is not None and any(p['comparisons'] is not None for p in observation['points']):
                    clocks = observation['source_frame_clock']
                    indices = [cursor+c['source_frame']-int(origin) for c in clocks]
                    if any(index<cursor or index>=cursor+count for index in indices):
                        raise PermissionError('planar pixel observation outside take')
                    row['pixel_observed_target_frames'] = indices
                    row['sampled_point_population_complete'] = all(p['comparisons'] is not None for p in observation['points'])
                    observed_frames.update(indices)
            population.append(row)
            cursor += count
        if cursor != reference['frame_count'] or len({row['take_id'] for row in population}) != len(population):
            raise PermissionError('planar coverage timeline incomplete/ambiguous')
        coverage = {'target_frame_count':cursor,'declared_reference_frame_count':referenced_frames,
            'frames_without_declared_planar_reference':cursor-referenced_frames,
            'pixel_observed_target_frame_count':len(observed_frames),
            'declared_frames_without_pixel_observation':referenced_frames-len(observed_frames),
            'takes':population,'full_duration_visual_coverage':False,
            'calibration_applied':False,'quality_authorized':False}
    if (any(p.read_bytes()!=data for p,data in saved.items()) or _sha(binary,prefixed=True)!=binary_hash):
        raise PermissionError('planar reference input changed during observation')
    read_phase6_visual_reference(root, source['reference']['path'], expected_sha256=source['reference']['sha256'])
    result = {'version':'phase6-declared-planar-motion-v1','status':'REFERENCE_COMPARED_NOT_INTRINSIC_QUALITY_APPROVAL',
        'motion':{'path':_relative(root,_resolve(root,str(motion_path))),'sha256':expected_motion_sha256},
        'reference_basis':'CURRENT_DECLARED_RASTER_TRANSFORM_NOT_HISTORICAL_EXECUTION',
        'trace':trace,'results':results,'command':command,'process_exit_code':exit_code,
        'binary':{'path':str(binary),'sha256':binary_hash},
        'evidence_bindings':[{'path':_relative(root,p),'sha256':'sha256:'+hashlib.sha256(data).hexdigest()} for p,data in saved.items()],
        'full_duration_visual_coverage':False,'new_video_decodes':0,'new_tracking':False,
        'historical_command_witness':False,'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    if coverage is not None:
        result.update(version='phase6-declared-planar-coverage-v1',coverage=coverage,
            trace_source={'path':_relative(root,trace_path),'sha256':expected_trace_sha256},
            native_process_executed_this_invocation=False)
    _write_immutable(directory/'measurement.json',result)
    return result


def _read_planar_pixel_inputs(root: Path, path: str | Path, anchor: str):
    """Authenticate the existing declaration/coverage before any pixel decoder.

    The external anchor authenticates a previous observation, not a caller's
    PASS. Reopen its dependencies, and independently reconstruct its clock map.
    Large videos are hashed incrementally, never held as a second RAM copy.
    """
    from .render_creative_v2_phase5 import _font
    saved = {}

    def bound(value, *, decode=False):
        source = Path(value['path'])
        if source.is_absolute() and not source.resolve().is_relative_to(root):
            if source.resolve() != _font().resolve():
                raise PermissionError('unknown external planar pixel dependency')
            source = source.resolve()
        else:
            source = _resolve(root, str(source))
        expected = value['sha256']
        if not re.fullmatch(r'sha256:[0-9a-f]{64}', str(expected)):
            raise PermissionError('planar pixel anchor required')
        raw = source.read_bytes() if decode else None
        actual = 'sha256:'+hashlib.sha256(raw).hexdigest() if decode else _sha(source, prefixed=True)
        if actual != expected or source in saved and saved[source] != expected:
            raise PermissionError('planar pixel input drift: '+source.name)
        saved[source] = expected
        return json.loads(raw) if decode else source

    coverage = bound({'path':str(path), 'sha256':anchor}, decode=True)
    if (coverage.get('version') != 'phase6-declared-planar-coverage-v1'
            or coverage.get('reference_basis') != 'CURRENT_DECLARED_RASTER_TRANSFORM_NOT_HISTORICAL_EXECUTION'
            or coverage.get('native_process_executed_this_invocation') is not False
            or any(coverage.get(k) is not False for k in ('quality_authorized','render_authorized',
                'publication_authorized','historical_command_witness','full_duration_visual_coverage'))):
        raise PermissionError('planar pixel coverage scope invalid')
    for item in coverage['evidence_bindings']:
        bound(item)
    motion = bound(coverage['motion'], decode=True)
    mux = bound(motion['input'], decode=True)
    reference = read_phase6_visual_reference(root, mux['reference']['path'], expected_sha256=mux['reference']['sha256'])
    for item in reference['intent_bindings'] + reference['sources'] + [reference['target'],
            reference['render_manifest'], reference['production_receipt'], mux['reference']]:
        bound(item)
    trace = bound(coverage['trace_source'], decode=True)
    if (trace['trace'] != coverage['trace'] or trace['motion'] != coverage['motion']
            or motion['target'] != reference['target'] or reference['fps'] != {'numerator':30,'denominator':1}):
        raise PermissionError('planar pixel declaration/target differs')
    for item in trace['evidence_bindings']:
        bound(item)
    stderr = [p for p in saved if p.name == 'crop.stderr.log']
    if len(stderr) != 1 or read_declared_planar_crop_trace(stderr[0].read_text(encoding='utf-8')) != trace['trace']:
        raise PermissionError('planar pixel native clock differs')
    # Executable is explicitly allowed only at the independently bound binary
    # path; it is not used to execute or regenerate a historical observation.
    if Path(FFMPEG).resolve() != Path(trace['binary']['path']).resolve() or _sha(Path(FFMPEG),prefixed=True) != trace['binary']['sha256']:
        raise PermissionError('planar pixel trace binary drift')
    population = coverage['coverage']['takes']
    if len(population) != len(reference['takes']):
        raise PermissionError('planar pixel coverage population differs')
    for row, take in zip(population,reference['takes']):
        for key in ('take_id','asset_id','target_start_frame','target_end_frame_exclusive','frame_count'):
            if row[key] != take[key]:
                raise PermissionError('planar pixel take binding differs')
        if row['reference_frames']:
            origin = Fraction(take['source_start_ms'])*30/1000
            if origin.denominator != 1 or origin < 0 or origin+take['frame_count'] > len(trace['trace']):
                raise PermissionError('planar pixel source clock invalid')
            expected = [{'target_frame':take['target_start_frame']+i, **trace['trace'][int(origin)+i]}
                        for i in range(take['frame_count'])]
            if row['reference_frames'] != expected:
                raise PermissionError('planar pixel declared frame map differs')
        if (len(set(row['pixel_observed_target_frames'])) != len(row['pixel_observed_target_frames'])
                or any(i < take['target_start_frame'] or i >= take['target_end_frame_exclusive']
                       for i in row['pixel_observed_target_frames'])):
            raise PermissionError('planar pixel prior coverage invalid')
    return coverage, reference, motion, mux, saved, bound


def _track_contrast_invariant_points(reference, candidate, points):
    """Measure local translation by ECC, never rectify the candidate image.

    Contrast normalization makes affine brightness changes a nuisance variable,
    not a geometric residual. Only translation is estimated; its full measured
    value is returned. The existing 21-pixel finest LK window bounds support.
    Convergence settings and correlation are not quality acceptance thresholds.
    """
    import cv2
    import numpy as np
    a=cv2.cvtColor(reference,cv2.COLOR_RGB2GRAY)
    b=cv2.cvtColor(candidate,cv2.COLOR_RGB2GRAY)
    radius=10
    criteria=(cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS,50,1e-6)
    rows=[]
    for identity,position in enumerate(points):
        row={'point_index':identity,'reference_xy':position.tolist(),
             'status':'UNOBSERVABLE_WINDOW_SUPPORT','observed_xy':None,
             'displacement_px':None,'forward_backward_error_px':None}
        rows.append(row)
        if min(*position,a.shape[1]-1-position[0],a.shape[0]-1-position[1]) < radius+1:
            continue
        centre=tuple(float(v) for v in position)
        ref=cv2.getRectSubPix(a,(21,21),centre).astype(np.float32)
        out=cv2.getRectSubPix(b,(21,21),centre).astype(np.float32)
        row['status']='UNOBSERVABLE_TEXTURE_OR_TRACK'
        if np.ptp(ref)==0 or np.ptp(out)==0:
            continue
        try:
            score,forward=cv2.findTransformECC(ref,out,np.eye(2,3,dtype=np.float32),
                cv2.MOTION_TRANSLATION,criteria,None,5)
            back_score,backward=cv2.findTransformECC(out,ref,np.eye(2,3,dtype=np.float32),
                cv2.MOTION_TRANSLATION,criteria,None,5)
        except cv2.error as error:
            # Native nonconvergence stays an explicit missing measurement.
            # An API/type/runtime failure is not silently reclassified.
            if error.code != cv2.Error.StsNoConv:
                raise
            row['native_nonconvergence']=True
            continue
        delta=forward[:,2].astype(float)
        inverse=backward[:,2].astype(float)
        if not np.isfinite([score,back_score,*delta,*inverse]).all():
            continue
        if (np.abs(delta)>radius).any() or (np.abs(inverse)>radius).any():
            row['status']='TRACK_LEFT_WINDOW_SUPPORT'
            continue
        observed=position+delta
        row.update(status='PIXEL_TRACK_OBSERVED',observed_xy=observed.tolist(),
            displacement_px=float(np.linalg.norm(delta)),
            forward_backward_error_px=float(np.linalg.norm(delta+inverse)),
            normalized_correlation=float(score),backward_normalized_correlation=float(back_score))
    return {'method':'reference-conditioned-local-ecc-translation-v1',
        'settings':{'window_size':[21,21],'motion':'TRANSLATION','gaussian_filter_size':5,
                    'maximum_iterations':50,'convergence_epsilon':1e-6},
        'rows':rows,'requested_points':len(points),
        'observed_points':sum(r['status']=='PIXEL_TRACK_OBSERVED' for r in rows),
        'tolerance':None,'quality_authorized':False,
        'limitation':'Contrast-invariant numeric displacement only; correlation is not a quality verdict.'}


def track_declared_planar_points(reference, candidate, points, declared_shift, *, correspondence='pyramidal-lk'):
    """Condition the existing LK measurement on an independent integer crop.

    The reference is shifted only by the independent declaration, never by a
    fit to the candidate. This brings known motion inside the local search
    domain. LK or explicit contrast-invariant ECC measures and reports all
    remaining displacement; neither warps the candidate to hide that motion.
    Integer nearest sampling does not interpolate the reference texture.
    This is a numerical instrument, not a camera-quality acceptance rule.
    """
    import cv2
    import numpy as np
    from .phase6_visual_metrics import track_reference_points, VisualMeasurementUnavailable
    ref,out,positions = np.asarray(reference),np.asarray(candidate),np.asarray(points,dtype=float)
    shift=np.asarray(declared_shift)
    if (ref.dtype!=np.uint8 or out.dtype!=np.uint8 or ref.ndim!=3 or ref.shape!=out.shape
            or ref.shape[-1]!=3 or positions.ndim!=2 or positions.shape[1]!=2 or not np.isfinite(positions).all()
            or shift.shape!=(2,) or shift.dtype.kind not in 'iu' or (np.abs(shift)>[128,72]).any()):
        raise VisualMeasurementUnavailable('declared integer crop and matched RGB/points required')
    transformed=cv2.warpAffine(ref,np.array([[1.,0.,float(shift[0])],[0.,1.,float(shift[1])]]),
        (ref.shape[1],ref.shape[0]),flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
    predicted=positions+shift
    if correspondence == 'pyramidal-lk':
        result=track_reference_points(transformed,out,predicted)
    elif correspondence == 'local-ecc-translation':
        result=_track_contrast_invariant_points(transformed,out,predicted)
    else:
        raise VisualMeasurementUnavailable('unknown declared planar correspondence')
    # Full three-level support including pyramid construction, same as the
    # existing source-region mask. Padding is not observed source content.
    radius=11*2**3+2*(1+2+4)
    for point,prediction,row in zip(positions,predicted,result['rows']):
        margin=min(*point,ref.shape[1]-1-point[0],ref.shape[0]-1-point[1],
                   *prediction,ref.shape[1]-1-prediction[0],ref.shape[0]-1-prediction[1])
        row['declared_translation_support']=bool(margin>=radius)
        row['unshifted_reference_xy']=point.tolist()
    result.update(reference_conditioning='INDEPENDENT_DECLARED_INTEGER_TRANSLATION',
        declared_shift_px=shift.tolist(),candidate_transform_fitted=False,
        full_duration_visual_coverage=False,render_authorized=False,publication_authorized=False)
    if correspondence != 'pyramidal-lk':
        result.update(candidate_transform_fitted=True,candidate_image_resampled=False,
            fitted_displacement_reported_not_removed=True,reference_fitted_to_candidate=False)
    return result


def _declared_rigid_region_boxes(support, declared_shift):
    """Choose one complete constant-row support rectangle, independently of pixels.

    The largest such rectangle is deterministic, not a claim of maximal coverage.
    Both coordinates exclude every masked pixel; no masking edge participates in
    correlation. Bounds are half-open and the translation comes from the plan.
    """
    import numpy as np
    from .phase6_visual_metrics import VisualMeasurementUnavailable
    mask, shift = np.asarray(support), np.asarray(declared_shift)
    if (mask.ndim != 2 or mask.dtype != np.uint8 or not np.isin(mask, [0, 1]).all()
            or shift.shape != (2,) or shift.dtype.kind not in 'iu'
            or (np.abs(shift) > [128, 72]).any()):
        raise VisualMeasurementUnavailable('binary independent support and integer crop required')
    height, width = mask.shape
    dx, dy = map(int, shift)
    x0, x1, y0, y1 = max(0, -dx), min(width, width-dx), max(0, -dy), min(height, height-dy)
    if x1-x0 < 3 or y1-y0 < 3:
        return None
    common = mask[y0:y1, x0:x1] & mask[y0+dy:y1+dy, x0+dx:x1+dx]
    edges = np.r_[0, np.flatnonzero(np.any(common[1:] != common[:-1], axis=1))+1, len(common)]
    options = []
    for low, high in zip(edges[:-1], edges[1:]):
        if high-low < 3:
            continue
        transitions = np.diff(np.r_[0, common[low].astype(int), 0])
        for left, right in zip(np.flatnonzero(transitions == 1), np.flatnonzero(transitions == -1)):
            if right-left >= 3:
                options.append((-(high-low)*(right-left), int(low), int(left), int(high), int(right)))
    if not options:
        return None
    _, low, left, high, right = min(options)
    reference = [x0+left, y0+low, x0+right, y0+high]
    candidate = [reference[0]+dx, reference[1]+dy, reference[2]+dx, reference[3]+dy]
    return {'reference_xyxy': reference, 'candidate_xyxy': candidate,
            'pixels': (right-left)*(high-low)}


def measure_declared_rigid_region(reference, candidate, support, declared_shift):
    """Measure one rigid-source residual, without claiming independent point tracks.

    Global Fourier support addresses the demonstrated local-aperture failure in
    quantized fades. It does not certify anatomy, local deformation, an artistic
    motion tolerance, or an unobserved region. Full residual is reported, never
    removed from candidate pixels. Black/constant regions stay unobservable.
    """
    import cv2
    import numpy as np
    from .phase6_visual_metrics import VisualMeasurementUnavailable
    ref, out, mask = np.asarray(reference), np.asarray(candidate), np.asarray(support)
    if (ref.dtype != np.uint8 or out.dtype != np.uint8 or ref.ndim != 3
            or ref.shape != out.shape or ref.shape[-1] != 3 or mask.shape != ref.shape[:2]):
        raise VisualMeasurementUnavailable('matched RGB bytes and independent source support required')
    boxes = _declared_rigid_region_boxes(mask, declared_shift)
    result = {'method': 'declared-rigid-region-phase-correlation-v1',
              'status': 'UNOBSERVABLE_REGION_SUPPORT', 'region': boxes,
              'declared_shift_px': [int(x) for x in declared_shift],
              'residual_xy_px': None, 'total_shift_xy_px': None,
              'residual_norm_px': None, 'forward_backward_error_px': None,
              'response': None, 'reverse_response': None,
              'window': 'HANNING', 'candidate_image_resampled': False,
              'independent_point_tracks': False, 'tolerance': None,
              'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}
    if boxes is None:
        return result
    x0, y0, x1, y1 = boxes['reference_xyxy']
    xx0, yy0, xx1, yy1 = boxes['candidate_xyxy']
    # Preserve fractional luminance from observed RGB codes. Converting uint8
    # first rounds weak red/blue texture to a constant before measurement.
    a = cv2.cvtColor(ref[y0:y1, x0:x1].astype(np.float32), cv2.COLOR_RGB2GRAY)
    b = cv2.cvtColor(out[yy0:yy1, xx0:xx1].astype(np.float32), cv2.COLOR_RGB2GRAY)
    result['gray_ranges'] = [[float(a.min()), float(a.max())], [float(b.min()), float(b.max())]]
    result['status'] = 'UNOBSERVABLE_REGION_TEXTURE'
    if np.ptp(a) == 0 or np.ptp(b) == 0:
        return result
    window = cv2.createHanningWindow((a.shape[1], a.shape[0]), cv2.CV_32F)
    # OpenCV may modify its input buffers when windowing; all are private copies.
    delta, response = cv2.phaseCorrelate(a.copy(), b.copy(), window.copy())
    inverse, reverse_response = cv2.phaseCorrelate(b.copy(), a.copy(), window.copy())
    if not np.isfinite([*delta, *inverse, response, reverse_response]).all():
        return result
    if (np.abs(delta) >= [a.shape[1]/2, a.shape[0]/2]).any():
        result['status'] = 'AMBIGUOUS_PERIODIC_DISPLACEMENT'
        return result
    result.update(status='RIGID_REGION_DISPLACEMENT_OBSERVED', residual_xy_px=list(delta),
                  total_shift_xy_px=(np.asarray(delta)+declared_shift).tolist(),
                  residual_norm_px=float(np.linalg.norm(delta)),
                  forward_backward_error_px=float(np.linalg.norm(np.asarray(delta)+inverse)),
                  response=float(response), reverse_response=float(reverse_response))
    return result


def _validate_declared_rigid_region(value, support, shift):
    """Validate the sealed numerical contract; not a repeat pixel measurement."""
    import numpy as np
    region = _declared_rigid_region_boxes(support, shift)
    if (value.get('method') != 'declared-rigid-region-phase-correlation-v1'
            or value.get('region') != region or value.get('declared_shift_px') != shift
            or value.get('window') != 'HANNING' or value.get('tolerance') is not None
            or any(value.get(k) is not False for k in ('quality_authorized','render_authorized',
                'publication_authorized','candidate_image_resampled','independent_point_tracks'))):
        raise PermissionError('rigid region scope/support differs')
    observed = value.get('status') == 'RIGID_REGION_DISPLACEMENT_OBSERVED'
    if observed:
        delta, total = value.get('residual_xy_px'), value.get('total_shift_xy_px')
        if (region is None or not isinstance(delta, list) or len(delta) != 2
                or any(type(x) not in (int, float) or not math.isfinite(x) for x in delta)
                or total != [delta[i]+shift[i] for i in range(2)]
                or value.get('residual_norm_px') != float(np.linalg.norm(delta))
                or any(type(value.get(k)) not in (int,float) or not math.isfinite(value[k])
                       for k in ('response','reverse_response','forward_backward_error_px'))
                or value['forward_backward_error_px'] < 0):
            raise PermissionError('rigid region numerical binding differs')
    elif (value.get('status') not in ('UNOBSERVABLE_REGION_SUPPORT','UNOBSERVABLE_REGION_TEXTURE',
                                     'AMBIGUOUS_PERIODIC_DISPLACEMENT')
          or any(value.get(k) is not None for k in ('residual_xy_px','total_shift_xy_px','residual_norm_px',
                          'forward_backward_error_px','response','reverse_response'))
          or (region is None) != (value['status'] == 'UNOBSERVABLE_REGION_SUPPORT')):
        raise PermissionError('rigid region missing observation differs')
    return observed


def measure_phase6_planar_pixel_motion(root: Path, *, coverage_path: str | Path,
        expected_coverage_sha256: str, output_directory: Path,
        take_ids: tuple[str, ...] | None = None, timeout_seconds: float = 1800,
        tracking_reference: str = 'fixed') -> dict[str, Any]:
    """Stream missing pixels of declared planar intervals, with bounded memory.

    A fixed independent pre-mux reference prevents chunk edges from concealing
    jumps. Previous exact observations are reused, not decoded/measured again.
    Only reference PNGs and clock/RGB-hash/track evidence are retained: the
    immutable input video is the replay source. Numerical measurements do not
    supply a quality tolerance, anatomical meaning or publication authority.
    """
    import cv2
    import numpy as np
    from PIL import Image
    from . import phase6_visual_metrics as metrics
    from . import phase6_visual_recipe as recipe
    from . import render_creative_v2_phase5 as renderer
    if type(timeout_seconds) not in (int,float) or not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 1800:
        raise ValueError('bounded planar measurement deadline required')
    if tracking_reference not in ('fixed','declared-integer-translation-v1','declared-ecc-translation-v1',
                                  'declared-rigid-region-phase-v1'):
        raise ValueError('unknown planar tracking reference')
    root = root.resolve()
    coverage, reference, motion, mux, saved, bound = _read_planar_pixel_inputs(root,coverage_path,expected_coverage_sha256)
    eligible = [r for r in coverage['coverage']['takes'] if r['reference_frames']]
    if take_ids is not None and (not take_ids or len(set(take_ids)) != len(take_ids)
            or not set(take_ids) <= {r['take_id'] for r in eligible}):
        raise ValueError('unknown/duplicate planar take population')
    selected = [r for r in eligible if take_ids is None or r['take_id'] in take_ids]
    directory = _resolve(root,str(output_directory))
    if (root/BASE/'quality/visual-measurements').resolve() not in directory.parents or directory.exists():
        raise PermissionError('planar pixels require new confined directory')
    for module in (metrics, recipe, renderer):
        executing = Path(module.__file__).resolve()
        bound({'path':str(root/'hero_engine'/executing.name),'sha256':_sha(executing,prefixed=True)})
    instrument = {'path':'hero_engine/phase6_quality.py', 'sha256':_sha(Path(__file__),prefixed=True)}
    bound(instrument)
    font = renderer._font()
    bound({'path':str(font),'sha256':_sha(font,prefixed=True)})
    documents = {Path(b['path']).stem: bound(b,decode=True) for b in reference['intent_bindings']}
    plans = {r['take_id']:r for r in documents['take_plan']['takes']}
    treatments = {r['take_id']:r for r in documents['creative_treatment_plan']['takes']}
    manifest = bound(reference['render_manifest'],decode=True)
    segments = verify_phase6_segment_set(root,manifest['segment_receipt_set'])
    records = {r['take_id']:r for r in segments['receipts']}
    if len(records) != len(segments['receipts']) or not {r['take_id'] for r in selected} <= set(records):
        raise PermissionError('planar segment population differs')
    source_records = {}
    for row in selected:
        receipt = bound(records[row['take_id']],decode=True)
        segment = bound(receipt['segment'])
        if segment == _resolve(root,reference['target']['path']):
            raise PermissionError('planar reference cannot be the target')
        source_records[row['take_id']] = segment
    prior_motion = {r['take_id']:r for r in motion['measurements']}
    prior_mux = {r['take_id']:r for r in mux.get('measurements',[])}
    fps = Fraction(30)
    features = {'maxCorners':32,'qualityLevel':.01,'minDistance':22,'blockSize':3}
    started, old_threads = time.monotonic(), cv2.getNumThreads()
    deadline = started+timeout_seconds
    directory.mkdir(parents=True,exist_ok=False)
    summaries = []
    cv2.setNumThreads(1)
    try:
        for row in selected:
            if time.monotonic() >= deadline:
                raise TimeoutError('planar pixel deadline before next take')
            take_id, frames = row['take_id'], row['reference_frames']
            take_started = time.monotonic()
            take_directory = directory/take_id
            take_directory.mkdir()
            layout = recipe.inspect_visual_layout(plans[take_id],treatments[take_id],font=font)
            support, support_evidence = metrics.declared_source_motion_support(layout)
            old_indices = row['pixel_observed_target_frames']
            base_index = row['frame_count']//2-1
            if old_indices:
                old = prior_mux[take_id]
                canonical = old['reference_frames'][0]
                if canonical['frame_index'] != base_index or old_indices != [r['frame_index'] for r in old['candidate_frames']]:
                    raise PermissionError('planar prior frame population differs')
                bound(canonical)
                positions = np.asarray([p['reference_origin_xy'] for p in prior_motion[take_id]['measurement']['rows']],dtype=float)
            else:
                canonical = metrics.extract_indexed_frames(source_records[take_id],[base_index],
                    take_directory/'reference',fps=fps,timeout_seconds=min(120,deadline-time.monotonic()))[base_index]
                corners = None
            with Image.open(_resolve(root,canonical['path'])) as image:
                rgb_reference = np.asarray(image.convert('RGB'))
            expected_ms, rounding = metrics.indexed_frame_clock(base_index,fps)
            if (rgb_reference.shape != (*support.shape,3)
                    or 'sha256:'+hashlib.sha256(rgb_reference.tobytes()).hexdigest() != canonical['decoded_rgb_sha256']
                    or canonical['expected_pts_ms'] != expected_ms or canonical['pts_rounding_tolerance_ms'] != rounding
                    or not math.isfinite(canonical['pts_ms']) or abs(canonical['pts_ms']-expected_ms) > rounding):
                raise PermissionError('planar reference pixels/clock differ')
            bound(canonical)
            if not old_indices:
                corners = cv2.goodFeaturesToTrack(cv2.cvtColor(rgb_reference,cv2.COLOR_RGB2GRAY),mask=support*255,**features)
                positions = corners.reshape(-1,2).astype(float) if corners is not None else np.empty((0,2))
            rows, newly_measured, reused = [], 0, 0
            capture = cv2.VideoCapture(str(_resolve(root,reference['target']['path'])),cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
            first = row['target_start_frame']
            try:
                if not capture.isOpened() or first and not capture.set(cv2.CAP_PROP_POS_FRAMES,first):
                    raise metrics.VisualMeasurementUnavailable('planar target decoder did not open/seek')
                if capture.get(cv2.CAP_PROP_POS_FRAMES) != first:
                    raise metrics.VisualMeasurementUnavailable('planar target seek differs')
                for index,clock in enumerate(frames):
                    if time.monotonic() >= deadline:
                        raise TimeoutError('planar pixel deadline during take')
                    target_index = clock['target_frame']
                    # grab advances the codec without retrieving/re-measuring
                    # a previously observed frame; its sealed pixels are reused.
                    previous = target_index in old_indices
                    ok = capture.grab()
                    if not ok or capture.get(cv2.CAP_PROP_POS_FRAMES) != target_index+1:
                        raise metrics.VisualMeasurementUnavailable('planar target frame sequence differs')
                    expected_ms, tolerance = metrics.indexed_frame_clock(target_index,fps)
                    pts = capture.get(cv2.CAP_PROP_POS_MSEC)
                    if not math.isfinite(pts) or abs(pts-expected_ms) > tolerance:
                        raise metrics.VisualMeasurementUnavailable('planar target PTS differs')
                    if previous:
                        ordinal = old_indices.index(target_index)
                        prior_frame = prior_mux[take_id]['candidate_frames'][ordinal]
                        bound(prior_frame)
                        pixel_hash = prior_frame['decoded_rgb_sha256']
                        tracks = [p['candidate_track'][ordinal] for p in prior_motion[take_id]['measurement']['rows']]
                        reused += 1
                    else:
                        ok,bgr = capture.retrieve()
                        if not ok:
                            raise metrics.VisualMeasurementUnavailable('planar target pixels unavailable')
                        rgb = cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
                        if rgb.shape != rgb_reference.shape:
                            raise metrics.VisualMeasurementUnavailable('planar target geometry differs')
                        pixel_hash = 'sha256:'+hashlib.sha256(rgb.tobytes()).hexdigest()
                        if tracking_reference == 'fixed':
                            tracks = metrics.track_reference_points(rgb_reference,rgb,positions)['rows'] if len(positions) else []
                        else:
                            shift = np.asarray(frames[base_index]['crop_xy'])-np.asarray(clock['crop_xy'])
                            correspondence = ('local-ecc-translation' if tracking_reference in
                                ('declared-ecc-translation-v1','declared-rigid-region-phase-v1') else 'pyramidal-lk')
                            tracks = track_declared_planar_points(rgb_reference,rgb,positions,shift,
                                correspondence=correspondence)['rows'] if len(positions) else []
                        newly_measured += 1
                    shift = np.asarray(frames[base_index]['crop_xy'])-np.asarray(clock['crop_xy'])
                    comparisons = []
                    for point,track in zip(positions,tracks):
                        xy = track['observed_xy']
                        expected_xy = point+shift
                        supported, residual = False,None
                        if xy is not None:
                            low,high = np.floor(xy).astype(int),np.ceil(xy).astype(int)
                            supported = bool((low>=0).all() and high[0]<support.shape[1] and high[1]<support.shape[0]
                                and support[low[1]:high[1]+1,low[0]:high[0]+1].all())
                            supported = supported and track.get('declared_translation_support',True)
                            residual = (np.asarray(xy)-expected_xy).tolist()
                        comparisons.append({'track':track,'expected_xy':expected_xy.tolist(),
                            'within_declared_support':supported,'position_residual_px':residual})
                    rows.append({'frame_index':target_index,'pts_ms':pts,'expected_pts_ms':expected_ms,
                        'pts_rounding_tolerance_ms':tolerance,'decoded_rgb_sha256':pixel_hash,
                        'pixel_evidence':'PREVIOUS_BOUND_PNG' if previous else 'SOURCE_REPLAYABLE_STREAM_HASH_ONLY',
                        'source_frame':clock['source_frame'],'expected_displacement_px':shift.tolist(),'points':comparisons})
                    if tracking_reference == 'declared-rigid-region-phase-v1':
                        if previous:
                            with Image.open(_resolve(root, prior_frame['path'])) as image:
                                rgb = np.asarray(image.convert('RGB'))
                            if 'sha256:'+hashlib.sha256(rgb.tobytes()).hexdigest() != pixel_hash:
                                raise PermissionError('reused planar pixels differ for rigid observation')
                        rows[-1]['rigid_region'] = measure_declared_rigid_region(rgb_reference,rgb,support,shift)
            finally:
                capture.release()
            if _sha(source_records[take_id],prefixed=True) != saved[source_records[take_id]]:
                raise PermissionError('planar segment changed during measurement')
            take_value = {'take_id':take_id,'reference_frame':canonical,'reference_receipt':records[take_id],
                'reference_points':positions.tolist(),'feature_settings':features,'support':support_evidence,
                'layout':layout,'frames':rows,'new_frames':newly_measured,'reused_frames':reused,
                'elapsed_seconds':time.monotonic()-take_started,'quality_authorized':False}
            _write_immutable(take_directory/'measurement.json',take_value)
            summaries.append({'take_id':take_id,'path':_relative(root,take_directory/'measurement.json'),
                'sha256':_sha(take_directory/'measurement.json',prefixed=True),'frames':len(rows),
                'new_frames':newly_measured,'reused_frames':reused,'selected_points':len(positions),
                'unobserved_point_frames':sum(p['track']['status']!='PIXEL_TRACK_OBSERVED' or not p['within_declared_support']
                    for r in rows for p in r['points'])})
        if any(_sha(p,prefixed=True)!=sha for p,sha in saved.items()):
            raise PermissionError('planar inputs changed during measurement')
        read_phase6_visual_reference(root,mux['reference']['path'],expected_sha256=mux['reference']['sha256'])
        result = {'version':'phase6-planar-pixel-stream-v1','status':'PIXEL_POPULATION_OBSERVED_NOT_QUALITY_APPROVAL',
            'coverage':{'path':_relative(root,_resolve(root,str(coverage_path))),'sha256':expected_coverage_sha256},
            'target':reference['target'],'takes':summaries,'observed_frames':sum(r['frames'] for r in summaries),
            'new_frames':sum(r['new_frames'] for r in summaries),'reused_frames':sum(r['reused_frames'] for r in summaries),
            'expected_declared_frames':sum(r['frame_count'] for r in eligible),'expected_video_frames':reference['frame_count'],
            'elapsed_seconds':time.monotonic()-started,'instrument':instrument,
            'bindings':[{'path':_relative(root,p),'sha256':sha} for p,sha in saved.items()],
            'decoder':{'opencv_version':cv2.__version__,'backend':'FFMPEG','threads':1},
            'tolerance':None,'full_duration_visual_coverage':False,'quality_authorized':False,
            'render_authorized':False,'publication_authorized':False,'new_channel_renders':0}
        if tracking_reference != 'fixed':
            result.update(version='phase6-planar-pixel-stream-v2',tracking_reference=tracking_reference,
                previous_points_reused_without_requalification=True)
            if tracking_reference=='declared-ecc-translation-v1':
                result['version']='phase6-planar-pixel-stream-v3'
            elif tracking_reference=='declared-rigid-region-phase-v1':
                result['version']='phase6-planar-pixel-stream-v4'
        _write_immutable(directory/'measurement.json',result)
        return result
    except Exception as exc:
        _write_immutable(directory/'failure.json',{'type':type(exc).__name__,'message':str(exc),
            'completed_takes':summaries,'elapsed_seconds':time.monotonic()-started,'quality_authorized':False})
        raise
    finally:
        cv2.setNumThreads(old_threads)


def read_phase6_planar_pixel_motion(root: Path, path: str | Path, *, expected_sha256: str,
        historical_instrument_path: str | Path | None = None) -> dict[str, Any]:
    """Reopen sealed pixel-population evidence, never turn it into QA approval."""
    from .phase6_visual_metrics import indexed_frame_clock
    root = root.resolve()
    path = _resolve(root,str(path))
    raw = path.read_bytes()
    if (not re.fullmatch(r'sha256:[0-9a-f]{64}',str(expected_sha256))
            or 'sha256:'+hashlib.sha256(raw).hexdigest() != expected_sha256):
        raise PermissionError('planar pixel result anchor differs')
    result = json.loads(raw)
    if (result.get('version') not in ('phase6-planar-pixel-stream-v1','phase6-planar-pixel-stream-v2',
                                    'phase6-planar-pixel-stream-v3','phase6-planar-pixel-stream-v4')
            or result.get('status') != 'PIXEL_POPULATION_OBSERVED_NOT_QUALITY_APPROVAL'
            or result.get('tolerance') is not None or result.get('new_channel_renders') != 0
            or any(result.get(k) is not False for k in ('quality_authorized','render_authorized',
                'publication_authorized','full_duration_visual_coverage'))):
        raise PermissionError('planar pixel result scope differs')
    conditioned=result['version']!='phase6-planar-pixel-stream-v1'
    expected_tracking={'phase6-planar-pixel-stream-v2':'declared-integer-translation-v1',
                       'phase6-planar-pixel-stream-v3':'declared-ecc-translation-v1',
                       'phase6-planar-pixel-stream-v4':'declared-rigid-region-phase-v1'}.get(result['version'])
    if conditioned and (result.get('tracking_reference')!=expected_tracking
            or result.get('previous_points_reused_without_requalification') is not True):
        raise PermissionError('planar pixel tracking reference differs')
    coverage,reference,motion,mux,saved,bound = _read_planar_pixel_inputs(root,result['coverage']['path'],result['coverage']['sha256'])
    if result['target'] != reference['target']:
        raise PermissionError('planar pixel result target differs')
    for item in result['bindings']:
        if historical_instrument_path is not None and item==result['instrument']:
            if item['path']!='hero_engine/phase6_quality.py':
                raise PermissionError('only the explicit historical measurement instrument may be archived')
            # Explicit exact-byte historical source, not a fallback, a new
            # expected hash, a replay of execution, or a new instrument PASS.
            archive=_resolve(root,str(historical_instrument_path))
            if archive==root/item['path']:
                raise PermissionError('historical instrument must be an immutable separate source')
            bound({'path':str(archive),'sha256':item['sha256']})
        else:
            bound(item)
    if result['instrument'] not in result['bindings']:
        raise PermissionError('planar pixel instrument binding missing')
    if result['version'] == 'phase6-planar-pixel-stream-v4':
        from . import phase6_visual_recipe as recipe
        from . import render_creative_v2_phase5 as renderer
        documents = {Path(b['path']).stem: bound(b,decode=True) for b in reference['intent_bindings']}
        rigid_plans = {r['take_id']:r for r in documents['take_plan']['takes']}
        rigid_treatments = {r['take_id']:r for r in documents['creative_treatment_plan']['takes']}
        rigid_font = renderer._font()
        # Only the existing bound reader authorizes the exact system font.
        # Reuse that authenticated identity; keep the media resolver confined.
        rigid_font_hash = saved.get(rigid_font.resolve())
        if (rigid_font_hash is None or
                {'path':_relative(root,rigid_font),'sha256':rigid_font_hash} not in result['bindings']):
            raise PermissionError('rigid region layout font binding missing')
    eligible = {r['take_id']:r for r in coverage['coverage']['takes'] if r['reference_frames']}
    totals = {'frames':0,'new_frames':0,'reused_frames':0}
    seen = set()
    maximum, missing, empty_frames = 0.,0,0
    rigid_observed, rigid_missing, rigid_maximum = 0,0,0.
    for record in result['takes']:
        take_id = record['take_id']
        if take_id in seen or take_id not in eligible:
            raise PermissionError('planar pixel result take population differs')
        seen.add(take_id)
        row = bound(record,decode=True)
        declared = eligible[take_id]
        if (row['take_id'] != take_id or row['quality_authorized'] is not False
                or len(row['frames']) != declared['frame_count'] or record['frames'] != len(row['frames'])
                or row['feature_settings'] != {'maxCorners':32,'qualityLevel':.01,'minDistance':22,'blockSize':3}):
            raise PermissionError('planar pixel take receipt differs')
        bound(row['reference_frame']); bound(row['reference_receipt'])
        positions = row['reference_points']
        if not 0 <= len(positions) <= 32 or len(positions) != record['selected_points']:
            raise PermissionError('planar pixel point population differs')
        baseline = declared['reference_frames'][declared['frame_count']//2-1]['crop_xy']
        if result['version'] == 'phase6-planar-pixel-stream-v4':
            from .phase6_visual_metrics import declared_source_motion_support
            if row['layout'] != recipe.inspect_visual_layout(rigid_plans[take_id],rigid_treatments[take_id],font=rigid_font):
                raise PermissionError('rigid region canonical layout differs')
            rigid_support, _ = declared_source_motion_support(row['layout'])
        count_reused, count_missing = 0,0
        for frame,clock in zip(row['frames'],declared['reference_frames']):
            expected_ms,tolerance = indexed_frame_clock(clock['target_frame'],Fraction(30))
            reused = clock['target_frame'] in declared['pixel_observed_target_frames']
            shift = [baseline[i]-clock['crop_xy'][i] for i in range(2)]
            if (frame['frame_index'] != clock['target_frame'] or frame['source_frame'] != clock['source_frame']
                    or frame['expected_pts_ms'] != expected_ms or frame['pts_rounding_tolerance_ms'] != tolerance
                    or not math.isfinite(frame['pts_ms']) or abs(frame['pts_ms']-expected_ms) > tolerance
                    or frame['expected_displacement_px'] != shift
                    or frame['pixel_evidence'] != ('PREVIOUS_BOUND_PNG' if reused else 'SOURCE_REPLAYABLE_STREAM_HASH_ONLY')
                    or not re.fullmatch(r'sha256:[0-9a-f]{64}',frame['decoded_rgb_sha256'])
                    or len(frame['points']) != len(positions)):
                raise PermissionError('planar pixel frame clock/population differs')
            count_reused += reused
            empty_frames += not positions
            if result['version'] == 'phase6-planar-pixel-stream-v4':
                if _validate_declared_rigid_region(frame.get('rigid_region',{}),rigid_support,shift):
                    rigid_observed += 1
                    rigid_maximum = max(rigid_maximum,frame['rigid_region']['residual_norm_px'])
                else:
                    rigid_missing += 1
            for position,p in zip(positions,frame['points']):
                expected_xy = [position[i]+shift[i] for i in range(2)]
                observed = p['track']['observed_xy']
                residual = None if observed is None else [observed[i]-expected_xy[i] for i in range(2)]
                if (p['expected_xy'] != expected_xy or p['position_residual_px'] != residual
                        or any(type(v) not in (int,float) or not math.isfinite(v) for v in position)
                        or residual is not None and any(not math.isfinite(v) for v in residual)
                        or type(p['within_declared_support']) is not bool):
                    raise PermissionError('planar pixel residual differs')
                if conditioned and not reused and (p['track'].get('unshifted_reference_xy')!=position
                        or p['track']['reference_xy']!=expected_xy
                        or type(p['track'].get('declared_translation_support')) is not bool
                        or p['within_declared_support'] and not p['track']['declared_translation_support']):
                    raise PermissionError('planar pixel conditioned point differs')
                unobserved = p['track']['status']!='PIXEL_TRACK_OBSERVED' or not p['within_declared_support']
                count_missing += unobserved
                if not unobserved and residual is not None:
                    maximum = max(maximum,math.hypot(*residual))
        if (count_reused != row['reused_frames'] or row['new_frames'] != len(row['frames'])-count_reused
                or record['unobserved_point_frames'] != count_missing):
            raise PermissionError('planar pixel counters differ')
        missing += count_missing
        for key in totals:
            expected = len(row['frames']) if key=='frames' else row[key]
            if record[key] != expected:
                raise PermissionError('planar pixel summary differs')
            totals[key] += expected
    if (not seen or result['observed_frames'] != totals['frames']
            or any(result[k] != totals[k] for k in ('new_frames','reused_frames'))
            or result['expected_declared_frames'] != sum(r['frame_count'] for r in eligible.values())
            or result['expected_video_frames'] != reference['frame_count']):
        raise PermissionError('planar pixel result totals differ')
    if path.read_bytes()!=raw or any(_sha(p,prefixed=True)!=sha for p,sha in saved.items()):
        raise PermissionError('planar pixel inputs changed during read')
    accepted = {'status':'AUTHENTICATED_PIXEL_POPULATION_NOT_QUALITY_APPROVAL','take_count':len(seen),
        **totals,'unobserved_point_frames':missing,'frames_without_selected_points':empty_frames,
        'maximum_supported_position_residual_px':maximum,'tolerance':None,
        'frames_without_this_declared_reference':reference['frame_count']-result['expected_declared_frames'],
        'declared_frames_not_in_this_observation':result['expected_declared_frames']-totals['frames'],
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    if result['version'] == 'phase6-planar-pixel-stream-v4':
        accepted['rigid_regions'] = {'observed_frames':rigid_observed,'unobservable_frames':rigid_missing,
            'maximum_residual_px':rigid_maximum,'independent_point_tracks':False,
            'full_frame_coverage':False,'quality_authorized':False}
    return accepted


def measure_phase6_existing_palette(root: Path, *, reference_path: str | Path,
                                   expected_reference_sha256: str, quality_path: str | Path,
                                   expected_quality_sha256: str, output_directory: Path,
                                   coverage: str = "centres") -> dict[str, Any]:
    """Read existing frozen frames and measure independent locked palette roles.

    No OCR, video decode or rendering. A sampled colour PASS cannot overrule
    typography failures or approve the remaining semantic style attributes.
    """
    import io
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import locked_palette_patches
    from .phase6_visual_recipe import inspect_visual_layout
    if coverage not in ("centres", "opaque_rectangles"):
        raise PermissionError("unknown palette observation coverage")
    root = root.resolve()
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError("palette requires a new confined observation directory")
    saved = {}
    def read(path, anchor):
        path = _resolve(root, str(path))
        raw = path.read_bytes()
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", str(anchor)) or "sha256:"+hashlib.sha256(raw).hexdigest() != anchor:
            raise PermissionError("palette input anchor differs: "+path.name)
        saved[path] = raw
        return raw
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    qa = json.loads(read(quality_path, expected_quality_sha256))
    audit = verify_overlay_ocr_measurement(root, qa["measurements"]["overlay_ocr"])
    if audit["video"] != reference["target"]:
        raise PermissionError("palette frames belong to another video")
    documents = {}
    for name in ("take_plan", "treatment", "style_bible"):
        binding = audit["sources"][name]
        if not any(_resolve(root,b["path"]) == _resolve(root,binding["path"]) and b["sha256"] == binding["sha256"] for b in reference["intent_bindings"]):
            raise PermissionError("palette intent differs from canonical reference")
        documents[name] = json.loads(read(binding["path"], binding["sha256"]))
    plan = {row["take_id"]:row for row in documents["take_plan"]["takes"]}
    treatment = {row["take_id"]:row for row in documents["treatment"]["takes"]}
    takes = {row["take_id"]:row for row in reference["takes"]}
    if (set(plan) != set(treatment) or set(plan) != set(takes)
            or len(plan) != len(documents["take_plan"]["takes"])
            or len(treatment) != len(documents["treatment"]["takes"])):
        raise PermissionError("palette take population differs")
    font = Path(r"C:\Windows\Fonts\arialbd.ttf")
    font_raw = font.read_bytes()
    implementations = [Path(__file__).resolve(), Path(inspect_visual_layout.__code__.co_filename).resolve(),
                       Path(locked_palette_patches.__code__.co_filename).resolve()]
    code_bindings = [{"path":_relative(root,path), "sha256":_sha(path,prefixed=True)} for path in implementations]
    seen, rows = set(), []
    for frame in audit["frames"]:
        identity, stamp = frame["take_id"], frame["timecode_ms"]
        if identity not in takes or type(stamp) not in (int,float) or not math.isfinite(stamp):
            raise PermissionError("palette frame identity/clock invalid")
        position = Fraction(str(stamp))*Fraction(reference["fps"]["numerator"],reference["fps"]["denominator"])/1000
        take = takes[identity]
        if not take["target_start_frame"] <= position < take["target_end_frame_exclusive"] or (identity,stamp) in seen:
            raise PermissionError("palette frame clock/population differs")
        seen.add((identity,stamp))
        raw = read(frame["frame_path"],frame["frame_sha256"])
        if len(raw) != frame["frame_size_bytes"]:
            raise PermissionError("palette frame size differs")
        with Image.open(io.BytesIO(raw)) as image:
            rgb = np.asarray(image.convert("RGB"))
        layout = inspect_visual_layout(plan[identity], treatment[identity],font=font)
        observed = (locked_palette_patches(rgb,layout,documents["style_bible"],coverage=coverage)
                    if coverage != "centres" else locked_palette_patches(rgb,layout,documents["style_bible"]))
        rows.append({"take_id":identity, "timecode_ms":stamp,
                     "frame":{"path":frame["frame_path"],"sha256":frame["frame_sha256"]},
                     "layout_sha256":"sha256:"+hashlib.sha256(json.dumps(layout,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),
                     "measurement":observed})
    if not rows:
        raise PermissionError("palette frame population is empty")
    if any(path.read_bytes() != raw for path,raw in saved.items()) or font.read_bytes() != font_raw:
        raise PermissionError("palette input changed during measurement")
    for path,binding in zip(implementations,code_bindings):
        if _sha(path,prefixed=True) != binding["sha256"]:
            raise PermissionError("palette implementation changed during measurement")
    read_phase6_visual_reference(root,reference_path,expected_sha256=expected_reference_sha256)
    verify_overlay_ocr_measurement(root,qa["measurements"]["overlay_ocr"])
    failed = sum(patch["status"] == "FAIL" for row in rows for patch in row["measurement"]["measurements"])
    value = {"version":"phase6-existing-palette-observation-v1", "criterion":"STYLE_DRIFT/opaque-decoration-colour",
             "status":"SAMPLED_PALETTE_COUNTEREXAMPLE" if failed else "SAMPLED_PALETTE_OBSERVED_NOT_FULL_STYLE_PASS",
             "reference":{"path":str(reference_path),"sha256":expected_reference_sha256},
             "quality_source":{"path":str(quality_path),"sha256":expected_quality_sha256},
             "video":reference["target"], "bible":audit["sources"]["style_bible"],
             "implementation_bindings":code_bindings,
             "font":{"path":str(font),"sha256":"sha256:"+hashlib.sha256(font_raw).hexdigest()},
             "measurements":rows, "failed_patches":failed,
             "sampled_frames":len(rows), "total_frames":reference["frame_count"],
             "new_ocr_inferences":0,"new_video_decodes":0,"full_style_covered":False,
             "quality_authorized":False,"render_authorized":False,"publication_authorized":False}
    if coverage == "opaque_rectangles":
        value.pop("failed_patches")
        value.update(version="phase6-existing-palette-observation-v3", coverage=coverage,
            status="OPAQUE_REGION_MEASUREMENTS_EDGE_REFERENCE_UNQUALIFIED",
            flat_reference_regions_outside_tolerance=sum(patch.get("flat_reference_within_tolerance") is False
                for row in rows for patch in row["measurement"]["measurements"]),
            boundary_reference_qualified=False, style_decision=None,
            measured_pixels=sum(patch.get("pixel_count",0) for row in rows for patch in row["measurement"]["measurements"]),
            full_duration_coverage=False)
    _write_immutable(directory / "measurement.json",value)
    return value


def observe_phase6_palette_frame_clocks(root: Path, *, reference_path: str | Path,
                                       expected_reference_sha256: str, quality_path: str | Path,
                                       expected_quality_sha256: str, take_ids: tuple[str,...],
                                       output_directory: Path) -> dict[str, Any]:
    """Bind existing colour samples to observed presentation clocks in one pass.

    No source composition, OCR, queue or video rendering. Already qualified
    takes may be omitted explicitly; this receipt reports only its population.
    """
    from .phase6_visual_metrics import verify_existing_ffmpeg_sample_clocks
    from .phase6_visual_recipe import CANVAS_WIDTH, CANVAS_HEIGHT
    root = root.resolve()
    directory = _resolve(root,str(output_directory))
    allowed = (root/BASE/'quality/visual-measurements').resolve()
    if allowed not in directory.parents or directory.exists():
        raise PermissionError('palette clocks require a new confined evidence directory')
    if not isinstance(take_ids,tuple) or not take_ids or len(set(take_ids)) != len(take_ids):
        raise PermissionError('palette clock population must be immutable and distinct')
    reference = read_phase6_visual_reference(root,reference_path,expected_sha256=expected_reference_sha256)
    qa_file = _resolve(root,str(quality_path))
    raw = qa_file.read_bytes()
    if not re.fullmatch(r'sha256:[0-9a-f]{64}',str(expected_quality_sha256)) or 'sha256:'+hashlib.sha256(raw).hexdigest() != expected_quality_sha256:
        raise PermissionError('palette clock quality anchor differs')
    qa = json.loads(raw)
    audit = verify_overlay_ocr_measurement(root,qa['measurements']['overlay_ocr'])
    if audit['video'] != reference['target']:
        raise PermissionError('palette clock audit belongs to another video')
    known = {t['take_id']:t for t in reference['takes']}
    selected = [f for f in audit['frames'] if f['take_id'] in take_ids]
    if tuple(f['take_id'] for f in selected) != take_ids or any(t not in known for t in take_ids):
        raise PermissionError('palette clock population differs from ordered audit')
    fps = Fraction(reference['fps']['numerator'],reference['fps']['denominator'])
    samples = []
    for f in selected:
        stamp = f['timecode_ms']
        if type(stamp) not in (int,float) or not math.isfinite(stamp):
            raise PermissionError('palette clock requires finite timestamps')
        index = math.ceil(Fraction(str(stamp))*fps/1000)
        take = known[f['take_id']]
        if not take['target_start_frame'] <= index < take['target_end_frame_exclusive']:
            raise PermissionError('palette sample proposal crosses the take boundary')
        samples.append({'path':str(_resolve(root,f['frame_path'])),'sha256':f['frame_sha256'],
                        'size_bytes':f['frame_size_bytes'],'requested_ms':stamp})
    code_paths = [Path(__file__).resolve(),Path(verify_existing_ffmpeg_sample_clocks.__code__.co_filename).resolve()]
    code = [{'path':_relative(root,p),'sha256':_sha(p,prefixed=True)} for p in code_paths]
    observed = verify_existing_ffmpeg_sample_clocks(_resolve(root,reference['target']['path']),samples,
        fps=fps,width=CANVAS_WIDTH,height=CANVAS_HEIGHT,ffmpeg=FFMPEG,directory=directory/'capture')
    read_phase6_visual_reference(root,reference_path,expected_sha256=expected_reference_sha256)
    verify_overlay_ocr_measurement(root,qa['measurements']['overlay_ocr'])
    if qa_file.read_bytes() != raw or any(_sha(p,prefixed=True) != b['sha256'] for p,b in zip(code_paths,code)):
        raise PermissionError('palette clock inputs/instrument changed during capture')
    value = {'version':'phase6-palette-frame-clock-observation-v1','status':'OBSERVED_EXACT_FRAME_BINDINGS',
             'reference':{'path':str(reference_path),'sha256':expected_reference_sha256},
             'quality':{'path':str(quality_path),'sha256':expected_quality_sha256},
             'video':reference['target'],'take_ids':list(take_ids),'implementation_bindings':code,
             'capture':{'path':_relative(root,directory/'capture/measurement.json'),
                        'sha256':_sha(directory/'capture/measurement.json',prefixed=True)},
             'observations':[{'take_id':t,**f} for t,f in zip(take_ids,observed['observations'])],
             'observed_frames':len(selected),'unselected_audit_frames':len(audit['frames'])-len(selected),
             'full_duration_coverage':False,'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    _write_immutable(directory/'measurement.json',value)
    return value


def measure_phase6_clocked_palette_population(root: Path, *, clock_path: str | Path,
                                             expected_clock_sha256: str,
                                             output_directory: Path) -> dict[str, Any]:
    """Compose only missing reference stills on authenticated observed clocks.

    Reuse target PNGs, original source/intent, the native decoder and qualified
    output-sync rule. No candidate fitting, channel encode, OCR or anatomy claim.
    A clock receipt authenticates observations, not a caller-supplied PASS.
    """
    import io
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import (read_sample_clock_statistics, decode_source_clock_frame,
        observe_renderer_output_sync, projected_palette_regions, locked_palette_patches)
    from .phase6_visual_recipe import inspect_visual_layout, visual_filters, RECIPE_ID
    from .render_creative_v2_phase5 import _font
    from .qa_phase5 import FFPROBE

    root = root.resolve()
    allowed = (root/BASE/'quality/visual-measurements').resolve()
    directory, clock_file = _resolve(root,str(output_directory)), _resolve(root,str(clock_path))
    if allowed not in directory.parents or directory.exists() or allowed not in clock_file.parents:
        raise PermissionError('clocked palette requires confined evidence and new output')
    saved = {}
    def read(path, anchor=None):
        path = _resolve(root,str(path))
        raw = path.read_bytes()
        if anchor is not None and (not re.fullmatch(r'sha256:[0-9a-f]{64}',str(anchor))
                or 'sha256:'+hashlib.sha256(raw).hexdigest() != anchor):
            raise PermissionError('clocked palette evidence anchor differs: '+path.name)
        saved[path] = raw
        return raw
    def binding(path):
        return {'path':_relative(root,path),'sha256':_sha(path,prefixed=True)}
    clock = json.loads(read(clock_file,expected_clock_sha256))
    if (clock.get('version') != 'phase6-palette-frame-clock-observation-v1'
            or clock.get('status') != 'OBSERVED_EXACT_FRAME_BINDINGS'
            or any(clock.get(k) is not False for k in ('quality_authorized','render_authorized',
                'publication_authorized','full_duration_coverage'))):
        raise PermissionError('clocked palette observation contract differs')
    ref_binding = clock['reference']
    reference = read_phase6_visual_reference(root,ref_binding['path'],expected_sha256=ref_binding['sha256'])
    qa = json.loads(read(clock['quality']['path'],clock['quality']['sha256']))
    audit = verify_overlay_ocr_measurement(root,qa['measurements']['overlay_ocr'])
    if clock['video'] != reference['target'] or audit['video'] != reference['target']:
        raise PermissionError('clocked palette target identity differs')
    capture_file = _resolve(root,clock['capture']['path'])
    if capture_file != clock_file.parent/'capture/measurement.json':
        raise PermissionError('clocked palette capture ownership differs')
    capture = json.loads(read(capture_file,clock['capture']['sha256']))
    takes, observations = clock['take_ids'], clock['observations']
    samples = [f for f in audit['frames'] if f['take_id'] in takes]
    if (not isinstance(takes,list) or not 1 <= len(takes) <= 100 or len(set(takes)) != len(takes)
            or takes != [f['take_id'] for f in samples] or takes != [r['take_id'] for r in observations]
            or type(clock['observed_frames']) is not int or clock['observed_frames'] != len(takes)
            or clock['unselected_audit_frames'] != len(audit['frames'])-len(takes)
            or capture.get('version') != 'phase6-existing-ffmpeg-frame-clocks-v1'
            or capture.get('status') != 'OBSERVED_EXACT_FRAME_BINDINGS'
            or capture.get('quality_authorized') is not False
            or capture['observations'] != [{k:v for k,v in r.items() if k != 'take_id'} for r in observations]):
        raise PermissionError('clocked palette complete population differs')
    process = json.loads(read(capture_file.parent/'process-result.json'))
    command = json.loads(read(capture_file.parent/'command.json'))
    stderr = read(capture_file.parent/'stderr.log').decode('utf-8')
    if (capture['process'] != process or type(process['exit_code']) is not int or process['exit_code'] != 0
            or process['timed_out'] is not False or len(capture['inputs']) != 2):
        raise PermissionError('clocked palette decoder process incomplete')
    for item, expected in zip(capture['inputs'],(_resolve(root,reference['target']['path']),Path(FFMPEG).resolve())):
        if (Path(item['path']).resolve() != expected or _sha(expected,prefixed=True) != item['sha256']
                or expected.stat().st_size != item['size_bytes']):
            raise PermissionError('clocked palette decoder/input binding differs')
    fps = Fraction(reference['fps']['numerator'],reference['fps']['denominator'])
    indices = [r['frame_index'] for r in observations]
    observed_clocks = read_sample_clock_statistics(stderr,indices,fps)
    graph = 'select='+'+'.join(f'eq(n\\,{i})' for i in indices)+',showinfo=checksum=0'
    expected_argv = [str(Path(FFMPEG).resolve()),'-nostdin','-hide_banner','-nostats','-loglevel','info',
        '-threads','1','-i',str(_resolve(root,reference['target']['path'])),'-map','0:v:0','-an','-sn','-dn',
        '-filter_threads','1','-vf',graph,'-frames:v',str(len(indices)),'-fps_mode','passthrough',
        '-pix_fmt','rgb24','-c:v','rawvideo','-threads','1','-f','rawvideo','-']
    if command['argv'] != expected_argv or command['inputs'] != capture['inputs']:
        raise PermissionError('clocked palette recorded decoder command differs')
    known = {t['take_id']:t for t in reference['takes']}
    rgb_digest, total_bytes = hashlib.sha256(), 0
    for sample, row, observed in zip(samples,observations,observed_clocks):
        index = row['frame_index']
        take = known[row['take_id']]
        if (row['rgb_identical'] is not True or any(row[k] != v for k,v in observed.items())
                or row['requested_ms'] != sample['timecode_ms'] or row['proposed_index'] != index
                or math.ceil(Fraction(str(sample['timecode_ms']))*fps/1000) != index
                or not take['target_start_frame'] <= index < take['target_end_frame_exclusive']
                or _resolve(root,row['path']) != _resolve(root,sample['frame_path'])
                or row['sha256'] != sample['frame_sha256'] or row['size_bytes'] != sample['frame_size_bytes']):
            raise PermissionError('clocked palette sample identity/clock differs')
        raw = read(row['path'],row['sha256'])
        with Image.open(io.BytesIO(raw)) as image:
            pixels = np.asarray(image.convert('RGB'))
        if len(raw) != row['size_bytes'] or 'sha256:'+hashlib.sha256(pixels.tobytes()).hexdigest() != row['observed_rgb_sha256']:
            raise PermissionError('clocked palette pixels differ')
        total_bytes += pixels.nbytes
        rgb_digest.update(pixels.tobytes())
    if total_bytes != process['stdout_bytes'] or 'sha256:'+rgb_digest.hexdigest() != capture['stdout_sha256']:
        raise PermissionError('clocked palette raw population differs')
    docs = {Path(b['path']).stem:json.loads(read(b['path'],b['sha256'])) for b in reference['intent_bindings']}
    planned = {r['take_id']:r for r in docs['take_plan']['takes']}
    directed = {r['take_id']:r for r in docs['creative_treatment_plan']['takes']}
    font = _font()
    font_sha = _sha(font,prefixed=True)
    code_paths = [Path(__file__).resolve(),Path(decode_source_clock_frame.__code__.co_filename).resolve(),
                  root/'hero_engine/phase6_visual_recipe.py']
    code = [binding(p) for p in code_paths]
    directory.mkdir(parents=True,exist_ok=False)
    rows = []
    for observed in observations:
        identity = observed['take_id']
        take = known[identity]
        layout = inspect_visual_layout(planned[identity],directed[identity],font=font)
        with Image.open(io.BytesIO(saved[_resolve(root,observed['path'])])) as image:
            actual = np.asarray(image.convert('RGB'))
        geometry = locked_palette_patches(actual,layout,docs['channel_style_bible'],coverage='opaque_rectangles')
        if not geometry['measured_patches']:
            rows.append({'take_id':identity,'status':'NO_UNOCCLUDED_OPAQUE_ROLE','geometry':geometry,
                         'new_reference_decode':False})
            continue
        subdir = directory/identity
        filters = visual_filters(planned[identity],directed[identity],font=font,work_dir=subdir/'text')
        sync = observe_renderer_output_sync(_resolve(root,take['source']['path']),ffmpeg=FFMPEG,ffprobe=FFPROBE)
        filters += sync['profile']['filters']
        expected, source_clock = decode_source_clock_frame(_resolve(root,take['source']['path']),ffmpeg=FFMPEG,
            start_ms=Fraction(take['source_start_ms']),frame_index=observed['frame_index']-take['target_start_frame'],
            fps=fps,composition_filters=tuple(filters))
        still = subdir/'reference.png'
        with still.open('xb') as stream:
            Image.fromarray(expected).save(stream,format='PNG')
        measurement = projected_palette_regions(expected,actual,layout,docs['channel_style_bible'])
        row = {'take_id':identity,'status':measurement['status'],'frame_index':observed['frame_index'],
               'source':take['source'],'source_clock':source_clock,'output_synchronization':sync,
               'reference_pixels':binding(still),'target_pixels':{k:observed[k] for k in ('path','sha256','observed_rgb_sha256')},
               'layout':layout,'filters':filters,'text_bindings':[binding(p) for p in sorted((subdir/'text').glob('*.txt'))],
               'measurement':measurement,'new_reference_decode':True}
        _write_immutable(subdir/'measurement.json',row)
        rows.append(row)
    read_phase6_visual_reference(root,ref_binding['path'],expected_sha256=ref_binding['sha256'])
    verify_overlay_ocr_measurement(root,qa['measurements']['overlay_ocr'])
    if (any(path.read_bytes() != raw for path,raw in saved.items()) or _sha(font,prefixed=True) != font_sha
            or any(_sha(p,prefixed=True) != b['sha256'] for p,b in zip(code_paths,code))):
        raise PermissionError('clocked palette input changed during measurement')
    evidence = [{'path':_relative(root,p),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()} for p,raw in saved.items()]
    measured = [r for r in rows if r['new_reference_decode']]
    result = {'version':'phase6-clocked-projected-palette-v1',
        'status':'FAIL_COMPONENT' if any(r['status']=='FAIL_COMPONENT' for r in measured) else
                 ('PASS_MEASURED_COMPONENTS_ONLY' if measured else 'INCOMPLETE'),
        'clock':{'path':_relative(root,clock_file),'sha256':expected_clock_sha256},'reference':ref_binding,
        'video':reference['target'],'recipe_id':RECIPE_ID,'font':{'path':str(font),'sha256':font_sha},
        'rows':rows,'evidence_bindings':evidence,'implementation_bindings':code,'observed_frames':len(rows),
        'measured_regions':sum(r['measurement']['measured_regions'] for r in measured),
        'measured_pixels':sum(r['measurement']['measured_pixels'] for r in measured),
        'new_source_stills':len(measured),'new_target_decodes':0,'new_ocr_inferences':0,'new_channel_renders':0,
        'reference_fitted_to_candidate':False,'historical_executable_identity_inferred':False,
        'full_style_covered':False,'full_duration_coverage':False,
        'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
    _write_immutable(directory/'measurement.json',result)
    return result


def read_phase6_clocked_palette_population(root: Path, *, receipt_path: str | Path,
                                         expected_sha256: str) -> dict[str, Any]:
    """Recompute bound palette pixels, without decoding or writing any artifact.

    Historical source-composition observations stay externally anchored. Current
    input bytes, intent, source/output clocks, composition and metrics must still
    agree. This is not replay/attestation of historical executable code and never
    upgrades sparse component coverage to a complete visual approval.
    """
    import io
    import numpy as np
    from PIL import Image
    from . import phase6_visual_recipe as recipe
    from .phase6_visual_metrics import (projected_palette_regions, locked_palette_patches,
        read_sample_clock_statistics, renderer_output_sync_profile)
    from .phase6_av_publicity_v2 import LIMITS
    from .render_creative_v2_phase5 import _font

    root = root.resolve()
    receipt = _resolve(root, str(receipt_path))
    allowed = (root / BASE / 'quality/visual-measurements').resolve()
    if allowed not in receipt.parents:
        raise PermissionError('palette reader receipt outside evidence scope')
    watched: dict[Path, str] = {}

    def bound(item, *, external=False):
        path = Path(item['path']).resolve() if external else _resolve(root, item['path'])
        anchor = item['sha256']
        if not isinstance(anchor, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', anchor):
            raise PermissionError('palette reader requires exact anchor')
        if _sha(path, prefixed=True) != anchor or (
                'size_bytes' in item and path.stat().st_size != item['size_bytes']):
            raise PermissionError('palette reader bound bytes differ: ' + path.name)
        if path in watched and watched[path] != anchor:
            raise PermissionError('palette reader conflicting input binding')
        watched[path] = anchor
        return path

    def document(item):
        path = bound(item)
        raw = path.read_bytes()
        if 'sha256:' + hashlib.sha256(raw).hexdigest() != item['sha256']:
            raise PermissionError('palette reader input changed during read')
        return json.loads(raw)

    def pixels(item):
        path = bound(item)
        raw = path.read_bytes()
        if 'sha256:' + hashlib.sha256(raw).hexdigest() != item['sha256']:
            raise PermissionError('palette reader pixels changed during read')
        with Image.open(io.BytesIO(raw)) as image:
            return np.asarray(image.convert('RGB'))

    def same(actual, expected, message):
        # JSON equality preserves types (True must not impersonate count 1).
        if json.dumps(actual, sort_keys=True, allow_nan=False) != json.dumps(expected, sort_keys=True, allow_nan=False):
            raise PermissionError('palette reader ' + message)

    value = document({'path': str(receipt), 'sha256': expected_sha256})
    watched[Path(__file__).resolve()] = _sha(Path(__file__), prefixed=True)
    watched[Path(recipe.__file__).resolve()] = _sha(Path(recipe.__file__), prefixed=True)
    metric_path = Path(projected_palette_regions.__code__.co_filename).resolve()
    watched[metric_path] = _sha(metric_path, prefixed=True)
    if value.get('version') != 'phase6-clocked-projected-palette-v1':
        raise PermissionError('palette reader unsupported measurement contract')
    for name in ('quality_authorized', 'render_authorized', 'publication_authorized',
                 'full_style_covered', 'full_duration_coverage', 'reference_fitted_to_candidate',
                 'historical_executable_identity_inferred'):
        if value.get(name) is not False:
            raise PermissionError('palette reader cannot inherit or grant authority')
    reference = read_phase6_visual_reference(root, value['reference']['path'],
                                            expected_sha256=value['reference']['sha256'])
    bound(value['reference'])
    for item in reference['intent_bindings'] + reference['sources'] + [
            reference['target'], reference['render_manifest'], reference['production_receipt']]:
        bound(item)
    same(value['video'], reference['target'], 'video identity differs')
    same(value['recipe_id'], recipe.RECIPE_ID, 'recipe contract differs')
    clock = document(value['clock'])
    same(clock.get('version'), 'phase6-palette-frame-clock-observation-v1', 'clock version differs')
    same(clock.get('status'), 'OBSERVED_EXACT_FRAME_BINDINGS', 'clock incomplete')
    same(clock['reference'], value['reference'], 'reference differs from clock')
    same(clock['video'], reference['target'], 'clock target differs')
    for name in ('quality_authorized', 'render_authorized', 'publication_authorized', 'full_duration_coverage'):
        same(clock.get(name), False, 'clock authority differs')
    # Reopen the original capture/QA/intent/frame bindings, never just its PASS.
    bindings = value['evidence_bindings']
    paths = [bound(item) for item in bindings]
    if len(paths) != len(set(paths)):
        raise PermissionError('palette reader duplicate evidence binding')
    qa = document(clock['quality'])
    audit = verify_overlay_ocr_measurement(root, qa['measurements']['overlay_ocr'])
    same(audit['video'], reference['target'], 'audit target differs')
    capture = document(clock['capture'])
    same(capture.get('status'), 'OBSERVED_EXACT_FRAME_BINDINGS', 'capture incomplete')
    observations = clock['observations']
    same(capture['observations'], [{k: v for k, v in r.items() if k != 'take_id'} for r in observations],
         'capture population differs')
    same(clock['take_ids'], [r['take_id'] for r in observations], 'clock take order differs')
    same([r['take_id'] for r in value['rows']], clock['take_ids'], 'measurement population differs')
    if len(set(clock['take_ids'])) != len(observations) or not 1 <= len(observations) <= 100:
        raise PermissionError('palette reader ambiguous population')
    same(clock['observed_frames'], len(observations), 'clock count differs')
    same(value['observed_frames'], len(observations), 'measurement count differs')
    samples = [f for f in audit['frames'] if f['take_id'] in clock['take_ids']]
    same([f['take_id'] for f in samples], clock['take_ids'], 'audit population differs')
    capture_dir = _resolve(root, clock['capture']['path']).parent
    if capture_dir != _resolve(root, value['clock']['path']).parent/'capture':
        raise PermissionError('palette reader capture ownership differs')
    for name in ('stderr.log', 'process-result.json', 'command.json'):
        if capture_dir/name not in paths:
            raise PermissionError('palette reader missing capture evidence')
    process = json.loads((capture_dir/'process-result.json').read_bytes())
    same(process, capture['process'], 'capture process differs')
    same(process['exit_code'], 0, 'capture process failed')
    same(process['timed_out'], False, 'capture process timed out')
    fps = Fraction(reference['fps']['numerator'], reference['fps']['denominator'])
    clocks = read_sample_clock_statistics((capture_dir/'stderr.log').read_text(encoding='utf-8'),
                                         [r['frame_index'] for r in observations], fps)
    docs = {Path(b['path']).stem: document(b) for b in reference['intent_bindings']}
    planned = {t['take_id']: t for t in docs['take_plan']['takes']}
    directed = {t['take_id']: t for t in docs['creative_treatment_plan']['takes']}
    takes = {t['take_id']: t for t in reference['takes']}
    font = _font().resolve()
    if Path(value['font']['path']).resolve() != font:
        raise PermissionError('palette reader font identity differs')
    bound(value['font'], external=True)
    measured, raw_hash, raw_bytes = [], hashlib.sha256(), 0
    for row, observation, sample, observed_clock in zip(value['rows'], observations, samples, clocks):
        take = takes[row['take_id']]
        index = observation['frame_index']
        same({k: observation[k] for k in observed_clock}, observed_clock, 'observed frame clock differs')
        if (type(index) is not int or not take['target_start_frame'] <= index < take['target_end_frame_exclusive']
                or math.ceil(Fraction(str(sample['timecode_ms']))*fps/1000) != index):
            raise PermissionError('palette reader frame outside canonical take')
        same(observation['rgb_identical'], True, 'pixels were not clock qualified')
        same(observation['sha256'], sample['frame_sha256'], 'sample hash differs')
        if _resolve(root, observation['path']) != _resolve(root, sample['frame_path']):
            raise PermissionError('palette reader sample path differs')
        actual = pixels(observation)
        same('sha256:'+hashlib.sha256(actual.tobytes()).hexdigest(), observation['observed_rgb_sha256'], 'RGB differs')
        raw_hash.update(actual.tobytes())
        raw_bytes += actual.nbytes
        layout = recipe.inspect_visual_layout(planned[row['take_id']], directed[row['take_id']], font=font)
        geometry = locked_palette_patches(actual, layout, docs['channel_style_bible'], coverage='opaque_rectangles')
        if not geometry['measured_patches']:
            same(row, {'take_id': row['take_id'], 'status': 'NO_UNOCCLUDED_OPAQUE_ROLE',
                       'geometry': geometry, 'new_reference_decode': False}, 'unobservable row differs')
            continue
        same(row['new_reference_decode'], True, 'reference observation missing')
        same(row['frame_index'], index, 'measurement clock differs')
        same(row['source'], take['source'], 'source lineage differs')
        same(row['layout'], layout, 'layout differs from canonical intent')
        same(row['target_pixels'], {k: observation[k] for k in ('path', 'sha256', 'observed_rgb_sha256')}, 'target binding differs')
        reference_file = receipt.parent/row['take_id']/'reference.png'
        if _resolve(root, row['reference_pixels']['path']) != reference_file:
            raise PermissionError('palette reader reference ownership differs')
        same(document({'path': str(reference_file.parent/'measurement.json'),
                       'sha256': _sha(reference_file.parent/'measurement.json', prefixed=True)}), row, 'row receipt differs')
        # The row bytes are authorized by the outer receipt; the hash above is
        # only a race check of that equal copy, never an independent authority.
        expected = pixels(row['reference_pixels'])
        source_clock = row['source_clock']
        same('sha256:'+hashlib.sha256(expected.tobytes()).hexdigest(), source_clock['decoded_rgb_sha256'], 'reference RGB differs')
        local_index = index - take['target_start_frame']
        source_pts = re.findall(r'\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:', source_clock['stderr'])
        bases = re.findall(r'config in time_base:\s*(\d+)/(\d+)', source_clock['stderr'])
        if (len(source_pts) != 1 or len(bases) != 1 or source_pts[0] != ('0', str(local_index))
                or Fraction(*map(int, bases[0])) != 1/fps):
            raise PermissionError('palette reader source clock differs')
        same(source_clock['exit_code'], 0, 'source observation failed')
        same(source_clock['resampled_frame_index'], local_index, 'source index differs')
        same(source_clock['source_seek_ms'], str(Fraction(take['source_start_ms'])), 'source seek differs')
        sync = row['output_synchronization']
        same(sync['profile'], renderer_output_sync_profile(sync['source_stream_probe'], sync['ffmpeg_version']), 'sync profile differs')
        for executable in sync['executable_bindings']:
            bound(executable, external=True)
        filters = list(recipe.BASE_FILTERS) + layout['decorations']
        text_files = []
        for overlay in layout['overlays']:
            text_path = reference_file.parent/'text'/overlay['filename']
            text_files.append({'path': _relative(root, text_path), 'sha256': 'sha256:'+hashlib.sha256(overlay['render_text'].encode('utf-8')).hexdigest()})
            filters.append(recipe._drawtext_filter(font, text_path, overlay))
        same(row['text_bindings'], sorted(text_files, key=lambda b: b['path']), 'text population differs')
        for item in text_files:
            bound(item)
        filters += list(recipe.OUTPUT_FILTERS) + sync['profile']['filters']
        same(row['filters'], filters, 'composition filters differ')
        seek = Fraction(take['source_start_ms'])
        if seek.denominator != 1:
            raise PermissionError('palette reader source seek not millisecond exact')
        command = [FFMPEG, '-nostdin', '-hide_banner', '-loglevel', 'info', '-threads', '1',
            '-ss', f'{seek.numerator//1000}.{seek.numerator%1000:03d}', '-i', str(_resolve(root,take['source']['path'])),
            '-map', '0:v:0', '-an', '-sn', '-dn', '-filter_threads', '1', '-vf',
            ','.join(filters)+f',select=eq(n\\,{local_index}),showinfo', '-frames:v', '1', '-fps_mode', 'passthrough',
            '-fs', str(LIMITS['maximum_frame_bytes']), '-pix_fmt', 'rgb24', '-c:v', 'ppm', '-f', 'image2pipe', '-']
        same(source_clock['command'], command, 'source composition command differs')
        result = projected_palette_regions(expected, actual, layout, docs['channel_style_bible'])
        same(row['measurement'], result, 'metric differs from bound pixels')
        same(row['status'], result['status'], 'row verdict differs')
        measured.append({'take_id': row['take_id'], 'frame_index': index, 'measurement': result})
    same(process['stdout_bytes'], raw_bytes, 'captured RGB size differs')
    same(capture['stdout_sha256'], 'sha256:'+raw_hash.hexdigest(), 'captured RGB population differs')
    status = ('FAIL_COMPONENT' if any(r['measurement']['status']=='FAIL_COMPONENT' for r in measured)
              else 'PASS_MEASURED_COMPONENTS_ONLY' if measured else 'INCOMPLETE')
    same(value['status'], status, 'aggregate verdict differs')
    for name in ('measured_pixels', 'measured_regions'):
        same(value[name], sum(r['measurement'][name] for r in measured), 'aggregate count differs')
    for path, anchor in watched.items():
        if _sha(path, prefixed=True) != anchor:
            raise PermissionError('palette reader input changed during revalidation')
    return {'status': 'CURRENT_PALETTE_PIXELS_RECOMPUTED_EQUAL', 'video': reference['target'],
            'receipt': {'path': _relative(root, receipt), 'sha256': expected_sha256}, 'rows': measured,
            'observed_frames': len(observations), 'measured_regions': value['measured_regions'],
            'measured_pixels': value['measured_pixels'], 'historical_code_replayed': False,
            'historical_implementation_bindings': value['implementation_bindings'],
            'current_reader_sha256': _sha(Path(__file__), prefixed=True),
            'full_style_covered': False, 'quality_authorized': False,
            'render_authorized': False, 'publication_authorized': False}


def measure_phase6_projected_palette(root: Path, *, control_path: str | Path,
                                    expected_control_sha256: str, quality_path: str | Path,
                                    expected_quality_sha256: str, output_directory: Path) -> dict[str, Any]:
    """Reuse a sealed native composition/frame pair; never decode or render.

    Only v2's source-native colour domain is admissible. Reopen its reference,
    exact frame/PTS, source, font, text, layout/filter recipe and pixel buffers.
    Compare the original FFmpeg PNG, not the OpenCV-converted RGB buffer of
    the hand detector: their colour conversions can differ for the SAME video
    frame. The independently captured index/PTS still binds the observation.
    This is a new interpretation of immutable observations, not retroactive
    historical executable attestation or semantic/full-video style approval.
    """
    import io
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import projected_palette_regions, indexed_frame_clock
    from .phase6_visual_recipe import inspect_visual_layout, _drawtext_filter, BASE_FILTERS, OUTPUT_FILTERS, RECIPE_ID
    from .phase6_visual_landmarks import VERSION as HAND_VERSION
    from .phase6_av_publicity_v2 import LIMITS

    root = root.resolve()
    directory = _resolve(root,str(output_directory))
    allowed = (root/BASE/"quality/visual-measurements").resolve()
    control_file = _resolve(root,str(control_path))
    if allowed not in directory.parents or directory.exists() or allowed not in control_file.parents:
        raise PermissionError("projected palette needs confined immutable inputs and a new output directory")
    saved = {}
    def read(path, anchor):
        path = _resolve(root,str(path))
        raw = path.read_bytes()
        if not re.fullmatch(r"sha256:[0-9a-f]{64}",str(anchor)) or "sha256:"+hashlib.sha256(raw).hexdigest() != anchor:
            raise PermissionError("projected palette input anchor differs: "+path.name)
        saved[path] = raw
        return raw
    control = json.loads(read(control_file,expected_control_sha256))
    if (control.get("version") != "phase6-hand-composition-control-v2"
            or control.get("composition_domain") != "native-decoder-before-rgb"
            or control.get("candidate_used_for_control_generation") is not False
            or any(control.get(k) is not False for k in ("quality_authorized","render_authorized","publication_authorized"))):
        raise PermissionError("projected palette reference must be native independent composition v2")
    transfer = json.loads(read(control["transfer"]["path"],control["transfer"]["sha256"]))
    if (transfer.get("version") != "phase6-source-hand-transfer-v1"
            or any(transfer.get(k) is not False for k in ("quality_authorized","render_authorized","publication_authorized"))):
        raise PermissionError("projected palette source lineage contract differs")
    binding = transfer["reference"]
    reference = read_phase6_visual_reference(root,binding["path"],expected_sha256=binding["sha256"])
    take = next((r for r in reference["takes"] if r["take_id"] == transfer["take_id"]),None)
    index = transfer["target_frame"]
    if (take is None or type(index) is not int or not take["target_start_frame"] <= index < take["target_end_frame_exclusive"]
            or transfer["source"] != take["source"]):
        raise PermissionError("projected palette take/source/frame lineage differs")
    target_binding = transfer["target_observation"]
    target = json.loads(read(target_binding["path"],target_binding["sha256"]))
    frame = target["frame_observation"]
    fps = Fraction(reference["fps"]["numerator"],reference["fps"]["denominator"])
    stamp, rounding = indexed_frame_clock(index,fps)
    if (target.get("version") != HAND_VERSION or target["reference_id"] != reference["reference_id"]
            or type(frame["frame_index"]) is not int or frame["frame_index"] != index
            or type(frame["pts_ms"]) not in (int,float) or not math.isfinite(frame["pts_ms"])
            or abs(frame["pts_ms"]-stamp) > rounding
            or frame["sha256"] != target["input"]["sha256"]
            or frame["decoded_rgb_sha256"] != target["input"]["decoded_rgb_sha256"]
            or _resolve(root,frame["path"]) != _resolve(root,target["input"]["path"])):
        raise PermissionError("projected palette target frame/observed clock differs")
    qa = json.loads(read(quality_path,expected_quality_sha256))
    audit = verify_overlay_ocr_measurement(root,qa["measurements"]["overlay_ocr"])
    if audit["video"] != reference["target"]:
        raise PermissionError("projected palette colour observation belongs to another video")
    matched = [f for f in audit["frames"] if f["take_id"] == take["take_id"]]
    if (len(matched) != 1 or type(matched[0]["timecode_ms"]) not in (int,float)
            or not math.isfinite(matched[0]["timecode_ms"])
            or Fraction(str(matched[0]["timecode_ms"]))*fps/1000 != index):
        raise PermissionError("projected palette FFmpeg observation needs the exact same frame clock")
    colour_frame = matched[0]
    for name in ("take_plan","treatment","style_bible"):
        b = audit["sources"][name]
        if not any(_resolve(root,b["path"]) == _resolve(root,x["path"]) and b["sha256"] == x["sha256"]
                   for x in reference["intent_bindings"]):
            raise PermissionError("projected palette colour observation intent differs")
    documents = {}
    for name in ("take_plan","creative_treatment_plan","channel_style_bible"):
        b = next(b for b in reference["intent_bindings"] if Path(b["path"]).stem == name)
        documents[name] = json.loads(read(b["path"],b["sha256"]))
    plan = next(t for t in documents["take_plan"]["takes"] if t["take_id"] == take["take_id"])
    treatment = next(t for t in documents["creative_treatment_plan"]["takes"] if t["take_id"] == take["take_id"])
    font = Path(control["font"]["path"]).resolve()
    if not (font.is_relative_to(root) or font.parent == Path(r"C:\Windows\Fonts").resolve()):
        raise PermissionError("projected palette font outside approved inputs")
    font_raw = font.read_bytes()
    if "sha256:"+hashlib.sha256(font_raw).hexdigest() != control["font"]["sha256"]:
        raise PermissionError("projected palette font changed")
    layout = inspect_visual_layout(plan,treatment,font=font)
    if layout != control["layout"] or control["recipe_id"] != RECIPE_ID:
        raise PermissionError("projected palette layout differs from canonical intent")
    filters = [*BASE_FILTERS,*layout["decorations"]]
    for overlay in layout["overlays"]:
        path = control_file.parent/"text"/overlay["filename"]
        if path.parent != control_file.parent/"text" or path.read_bytes() != overlay["render_text"].encode("utf-8"):
            raise PermissionError("projected palette archived copy differs")
        saved[path] = path.read_bytes()
        filters.append(_drawtext_filter(font,path,overlay))
    filters.extend(OUTPUT_FILTERS)
    clock = control["source_clock"]
    relative_index = index-take["target_start_frame"]
    if (filters != control["filters"] or clock.get("composition_domain") != "native-decoder-before-rgb"
            or type(clock["exit_code"]) is not int or clock["exit_code"] != 0
            or type(clock["observed_pts"]) is not int or clock["observed_pts"] != relative_index
            or type(clock["resampled_frame_index"]) is not int or clock["resampled_frame_index"] != relative_index
            or Fraction(clock["observed_time_base"]) != 1/fps
            or Fraction(clock["resampled_pts_ms"]) != relative_index*1000/fps
            or Fraction(clock["source_seek_ms"]) != Fraction(take["source_start_ms"])
            or Fraction(clock["mapped_source_time_ms"]) != Fraction(take["source_start_ms"])+relative_index*1000/fps):
        raise PermissionError("projected palette composition/clock differs")
    clocks = re.findall(r"config in time_base:\s*(\d+)/(\d+)",clock["stderr"])
    stamps = re.findall(r"\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:",clock["stderr"])
    if clocks != [(str(fps.denominator),str(fps.numerator))] or stamps != [("0",str(relative_index))]:
        raise PermissionError("projected palette raw observed clock differs")
    argv = clock["command"]
    seek = Fraction(take["source_start_ms"])
    expected_argv = [FFMPEG,"-nostdin","-hide_banner","-loglevel","info","-threads","1",
        "-ss",f"{seek.numerator//1000}.{seek.numerator%1000:03d}","-i",str(_resolve(root,take["source"]["path"])),
        "-map","0:v:0","-an","-sn","-dn","-filter_threads","1",
        "-vf",','.join(filters)+f",select=eq(n\\,{relative_index}),showinfo",
        "-frames:v","1","-fps_mode","passthrough","-fs",str(LIMITS["maximum_frame_bytes"]),
        "-pix_fmt","rgb24","-c:v","ppm","-f","image2pipe","-"]
    if control["command"] != argv or seek.denominator != 1 or argv != expected_argv:
        raise PermissionError("projected palette recorded composition command differs")
    def pixels(item):
        b = item["input"]
        with Image.open(io.BytesIO(read(b["path"],b["sha256"]))) as image:
            rgb = np.asarray(image.convert("RGB"))
        if "sha256:"+hashlib.sha256(rgb.tobytes()).hexdigest() != b["decoded_rgb_sha256"]:
            raise PermissionError("projected palette decoded pixels differ")
        return rgb
    composed = control["control_observation"]
    if (_resolve(root,composed["input"]["path"]) != control_file.parent/"composition-control.png"
            or _resolve(root,composed["input"]["path"]) == _resolve(root,target["input"]["path"])
            or clock["decoded_rgb_sha256"] != composed["input"]["decoded_rgb_sha256"]):
        raise PermissionError("projected palette reference pixel ownership differs")
    implementation_paths = [Path(__file__).resolve(),Path(projected_palette_regions.__code__.co_filename).resolve(),
                            Path(inspect_visual_layout.__code__.co_filename).resolve()]
    code = [{"path":_relative(root,p),"sha256":_sha(p,prefixed=True)} for p in implementation_paths]
    expected, indexed_observation = pixels(composed), pixels(target)
    raw = read(colour_frame["frame_path"],colour_frame["frame_sha256"])
    if len(raw) != colour_frame["frame_size_bytes"]:
        raise PermissionError("projected palette colour frame size differs")
    with Image.open(io.BytesIO(raw)) as image:
        actual = np.asarray(image.convert("RGB"))
    colour_input = {"path":colour_frame["frame_path"],"sha256":colour_frame["frame_sha256"],
                    "decoded_rgb_sha256":"sha256:"+hashlib.sha256(actual.tobytes()).hexdigest()}
    if ((frame["height"],frame["width"]) != actual.shape[:2] or indexed_observation.shape != actual.shape
            or (clock["height"],clock["width"]) != expected.shape[:2]):
        raise PermissionError("projected palette observed canvas differs")
    result = projected_palette_regions(expected,actual,layout,documents["channel_style_bible"])
    read_phase6_visual_reference(root,binding["path"],expected_sha256=binding["sha256"])
    verify_overlay_ocr_measurement(root,qa["measurements"]["overlay_ocr"])
    if (any(p.read_bytes() != raw for p,raw in saved.items()) or font.read_bytes() != font_raw
            or any(_sha(p,prefixed=True) != b["sha256"] for p,b in zip(implementation_paths,code))):
        raise PermissionError("projected palette input changed during measurement")
    value = {"version":"phase6-source-projected-palette-v2","status":result["status"],
             "control":{"path":_relative(root,control_file),"sha256":expected_control_sha256},
             "reference":binding,"video":reference["target"],"take_id":take["take_id"],"frame_index":index,
             "reference_pixels":composed["input"],"target_pixels":colour_input,
             "quality_observation":{"path":str(quality_path),"sha256":expected_quality_sha256},
             "indexed_frame_observation":target_binding,
             "comparison_domain":"FFmpeg native composition RGB versus existing FFmpeg PNG",
             "measurement":result,"implementation_bindings":code,"observed_frames":1,
             "total_frames":reference["frame_count"],"new_ocr_inferences":0,"new_video_decodes":0,
             "reference_fitted_to_candidate":False,"historical_executable_identity_inferred":False,
             "full_style_covered":False,"full_duration_coverage":False,
             "quality_authorized":False,"render_authorized":False,"publication_authorized":False}
    _write_immutable(directory/"measurement.json",value)
    return value


def measure_phase6_native_take_fidelity(
    root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
    take_ids: tuple[str, ...], output_directory: Path, canonical_output_sync: bool = False,
) -> dict[str, Any]:
    """Measure every selected take frame against independently compiled intent.

    This extends the existing FFmpeg SSIM measurement, not a historical render
    witness or an anatomy/physics oracle. No encode, queue, ASR, publication or
    operational state mutation. Incomplete coverage never becomes full QA.
    """
    from .phase6_visual_metrics import measure_ffmpeg_transfer, observe_renderer_output_sync
    from .qa_phase5 import FFPROBE
    from .phase6_visual_recipe import visual_filters, RECIPE_ID
    from .render_creative_v2_phase5 import _font

    root = root.resolve()
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    if not isinstance(take_ids, tuple) or not take_ids or len(take_ids) != len(set(take_ids)):
        raise ValueError("distinct nonempty immutable take population required")
    selected = [row for row in reference["takes"] if row["take_id"] in take_ids]
    if len(selected) != len(take_ids):
        raise ValueError("unknown take in fidelity population")
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("native fidelity requires a new confined evidence directory")
    plan = _read(root / BASE / "production/take_plan.json")
    treatment = _read(root / BASE / "production/creative_treatment_plan.json")
    planned = {row["take_id"]: row for row in plan["takes"]}
    directed = {row["take_id"]: row for row in treatment["takes"]}
    font = _font()
    font_hash = _sha(font, prefixed=True)
    code_paths = [root / "hero_engine/phase6_quality.py", root / "hero_engine/phase6_visual_metrics.py",
                  root / "hero_engine/phase6_visual_recipe.py", root / "hero_engine/render_creative_v2_phase5.py"]
    installed = Path(__file__).resolve().parent
    if any(p.read_bytes() != (installed / p.name).read_bytes() for p in code_paths):
        raise PermissionError("fidelity root instrument is not the implementation being executed")
    code = [{"path": _relative(root, p), "sha256": _sha(p, prefixed=True)} for p in code_paths]
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])
    target = _resolve(root, reference["target"]["path"])
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    results = []
    for row in selected:
        take = row["take_id"]
        filters = visual_filters(planned[take], directed[take], font=font, work_dir=directory / (take + "-text"))
        synchronization = None
        if canonical_output_sync:
            if fps != Fraction(30):
                raise PermissionError("canonical output sync requires the existing 30fps renderer")
            synchronization = observe_renderer_output_sync(_resolve(root,row["source"]["path"]),ffmpeg=FFMPEG,ffprobe=FFPROBE)
            filters += synchronization["profile"]["filters"]
        text_files = [{"path": _relative(root, p), "sha256": _sha(p, prefixed=True)}
                      for p in sorted((directory / (take + "-text")).glob("*.txt"))]
        measured = measure_ffmpeg_transfer(_resolve(root, row["source"]["path"]), target,
            ffmpeg=FFMPEG, directory=directory / take, frame_count=row["frame_count"], fps=fps,
            reference_seek_ms=Fraction(row["source_start_ms"]), candidate_start_frame=row["target_start_frame"],
            reference_filters=tuple(filters), observe_reference_origin=True)
        for binding in text_files + code:
            if _sha(_resolve(root, binding["path"]), prefixed=True) != binding["sha256"]:
                raise PermissionError("fidelity text/instrument changed during measurement")
        if _sha(font, prefixed=True) != font_hash:
            raise PermissionError("fidelity font changed during measurement")
        record = {"take_id": take, "target_start_frame": row["target_start_frame"],
                  "target_end_frame_exclusive": row["target_end_frame_exclusive"],
                  "recipe_id": RECIPE_ID, "filters": filters, "text_bindings": text_files, **measured}
        if synchronization is not None:
            record["version"] = "phase6-native-full-take-transfer-v3"
            record["output_synchronization"] = synchronization
        # Persist each completed take so a later failure never destroys useful
        # measurements. A partial run has NO aggregate success receipt.
        _write_immutable(directory / take / "measurement.json", record)
        results.append(record)
    read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    for binding in code:
        if _sha(_resolve(root, binding["path"]), prefixed=True) != binding["sha256"]:
            raise PermissionError("fidelity instrument changed before final receipt")
    total = sum(row["measurement"]["frame_count"] for row in results)
    result = {"version": "phase6-native-take-fidelity-v3" if canonical_output_sync else "phase6-native-take-fidelity-v2", "status": "MEASURED_NOT_FULL_VISUAL_QA",
              "reference": {"path": _relative(root, _resolve(root, str(reference_path))), "sha256": expected_reference_sha256},
              "render_id": reference["render_id"], "instrument_bindings": code,
              "font": {"path": str(font.resolve()), "sha256": font_hash},
              "takes": results, "measured_frames": total, "expected_frames": reference["frame_count"],
              "full_duration_coverage": total == reference["frame_count"],
              "mean_all": math.fsum(r["measurement"]["mean_all"] * r["measurement"]["frame_count"] for r in results) / total,
              "minimum_all": min(r["measurement"]["minimum_all"] for r in results),
              "tolerance": None, "tolerance_reason": "Measurement only; scalar encode fidelity is not a universal no-visible-artifact criterion.",
              "source_intrinsic_quality_proved": False, "historical_command_witness": False,
              "elapsed_seconds": time.monotonic() - started,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def read_phase6_native_fidelity_population(
    root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
    receipt_bindings: tuple[dict[str, str], ...],
) -> dict[str, Any]:
    """Reconcile existing per-frame observations without decoding them again.

    The externally anchored receipts authenticate raw logs, input identities,
    exit codes and clocks. Their scalar summaries are recomputed, never trusted
    as PASS. An observed nonzero pre-encoder origin does not prove the encoder's
    output synchronization: those takes remain explicitly unqualified for that
    comparison. No anatomy, physics or full visual-quality authority is issued.
    """
    from .phase6_visual_metrics import read_transfer_statistics, observe_renderer_output_sync
    from .qa_phase5 import FFPROBE

    root = root.resolve()
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    if not isinstance(receipt_bindings, tuple) or not receipt_bindings:
        raise ValueError("externally bound immutable measurement population required")
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])
    expected = {row["take_id"]: row for row in reference["takes"]}
    seen, rows, checked = set(), [], {}

    def check(binding: dict[str, Any], *, local: bool = True) -> Path:
        path = _resolve(root, binding["path"]) if local else Path(binding["path"]).resolve()
        anchor = binding["sha256"]
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", str(anchor)):
            raise PermissionError("fidelity population missing exact SHA-256")
        key = (str(path), anchor)
        if key not in checked:
            if _sha(path, prefixed=True) != anchor:
                raise PermissionError("fidelity evidence/input hash changed: " + str(path))
            checked[key] = path
        if "size_bytes" in binding and path.stat().st_size != binding["size_bytes"]:
            raise PermissionError("fidelity evidence/input size changed")
        return path

    for binding in receipt_bindings:
        path = check(binding)
        if allowed not in path.parents:
            raise PermissionError("fidelity receipt outside observation namespace")
        value = _read(path)
        take = value.get("take_id")
        if take not in expected or take in seen:
            raise PermissionError("fidelity population has duplicate/foreign take")
        seen.add(take)
        planned = expected[take]
        version = value.get("version")
        recovery = version == "phase6-reference-origin-recovery-v2"
        if version not in ("phase6-native-full-take-transfer-v1", "phase6-native-full-take-transfer-v2", "phase6-native-full-take-transfer-v3",
                           "phase6-reference-origin-recovery-v2"):
            raise PermissionError("unknown native fidelity measurement contract")
        inputs = value["input_bindings" if recovery else "inputs"]
        if len(inputs) != 3:
            raise PermissionError("fidelity input population differs")
        for actual, wanted in zip(inputs[:2], (planned["source"], reference["target"])):
            if (_resolve(root, actual["path"]) != _resolve(root, wanted["path"])
                    or actual["sha256"] != wanted["sha256"] or actual["size_bytes"] != wanted["size_bytes"]):
                raise PermissionError("fidelity take/source/target binding differs")
        check(inputs[2], local=False)  # FFmpeg is the sole permitted external input.
        if version == "phase6-native-full-take-transfer-v3":
            actual_sync = observe_renderer_output_sync(_resolve(root,planned["source"]["path"]),ffmpeg=inputs[2]["path"],ffprobe=FFPROBE)
            if value.get("output_synchronization") != actual_sync or fps != Fraction(30):
                raise PermissionError("fidelity output synchronization profile differs")
        artifacts = value["raw_bindings" if recovery else "artifacts"]
        files = {}
        for artifact in artifacts:
            item = check(artifact)
            if item.parent != path.parent or item.name in files:
                raise PermissionError("fidelity raw artifact ownership differs")
            files[item.name] = item
        required = {"command.json", "process-result.json", "stderr.log", "frame-ssim.log"}
        if not required <= set(files) or set(files) - required - {"stdout.log"}:
            raise PermissionError("fidelity raw artifacts incomplete/foreign")
        process = _read(files["process-result.json"])
        if type(process.get("exit_code")) is not int or process["exit_code"] != 0 or process.get("timed_out") is not False:
            raise PermissionError("fidelity decoder did not complete successfully")
        if not recovery and process != value["process"]:
            raise PermissionError("fidelity process receipt differs")
        command = _read(files["command.json"])
        if command.get("inputs") != inputs:
            raise PermissionError("fidelity recorded command inputs differ")
        argv = command.get("argv", [])
        def values(flag):
            return [argv[i+1] for i, token in enumerate(argv[:-1]) if token == flag]
        milliseconds = Fraction(planned["target_start_frame"] * 1000, 1) / fps
        def milliseconds_text(value):
            if value.denominator != 1:
                raise PermissionError("fidelity seek is not millisecond exact")
            return f"{value.numerator // 1000}.{value.numerator % 1000:03d}"
        if (values("-ss") != [milliseconds_text(Fraction(planned["source_start_ms"])), milliseconds_text(milliseconds)]
                or values("-frames:v") != [str(planned["frame_count"])]
                or [_resolve(root, p) for p in values("-i")] != [_resolve(root, i["path"]) for i in inputs[:2]]
                or values("-f") != ["null"] or not argv or argv[-1] != "-"
                or Path(argv[0]).resolve() != Path(inputs[2]["path"]).resolve()):
            raise PermissionError("fidelity command scope differs from exact take")
        if version == "phase6-native-full-take-transfer-v3":
            suffix = ",".join(actual_sync["profile"]["filters"]+["format=yuv420p",f"trim=end_frame={planned['frame_count']}","showinfo@reference=checksum=0","setpts=PTS-STARTPTS"])
            graphs = values("-filter_complex")
            if len(graphs)!=1 or suffix+"[ref];" not in graphs[0]:
                raise PermissionError("fidelity reference omitted the qualified output synchronization")
        measured = read_transfer_statistics(files["frame-ssim.log"].read_text(encoding="utf-8-sig"),
            files["stderr.log"].read_text(encoding="utf-8-sig", errors="strict"),
            frame_count=planned["frame_count"], fps=fps,
            observe_reference_origin=version != "phase6-native-full-take-transfer-v1")
        comparable = measured
        # Historical v1 recorded four clock fields. v2 added an explicit
        # origin. Recompute the raw v1 zero-origin contract first, then project
        # only these two derived fields; never rewrite the historical receipt.
        old_clock_fields = {"time_base", "frames", "first_pts", "last_pts"}
        stored_clocks = value["measurement"].get("clocks", {})
        if (version == "phase6-native-full-take-transfer-v1"
                and set(stored_clocks) == {"reference", "candidate"}
                and all(set(clock) == old_clock_fields for clock in stored_clocks.values())):
            comparable = {**measured, "clocks": {name: {k:v for k,v in clock.items() if k in old_clock_fields}
                                                 for name, clock in measured["clocks"].items()}}
        if comparable != value["measurement"]:
            raise PermissionError("fidelity summary differs from raw observations")
        if not recovery and (value["target_start_frame"] != planned["target_start_frame"]
                             or value["target_end_frame_exclusive"] != planned["target_end_frame_exclusive"]):
            raise PermissionError("fidelity declared timeline differs")
        rows.append({"take_id": take, "receipt": binding, "frames": planned["frame_count"],
                     "mean_all": measured["mean_all"], "minimum_all": measured["minimum_all"],
                     "observed_clocks": measured["clocks"],
                     "output_sync_witness_required": measured["clocks"]["reference"]["first_pts"] != 0})
    if seen != set(expected):
        raise PermissionError("fidelity population does not cover every canonical take")
    rows.sort(key=lambda row: expected[row["take_id"]]["target_start_frame"])
    count = sum(row["frames"] for row in rows)
    if count != reference["frame_count"]:
        raise PermissionError("fidelity full frame population differs")
    # No observation can be replaced between collection and final consumption.
    for (_, anchor), path in checked.items():
        if _sha(path, prefixed=True) != anchor:
            raise PermissionError("fidelity evidence changed during reconciliation")
    read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    return {"version": "phase6-native-fidelity-population-v1", "status": "RECONCILED_NOT_FULL_VISUAL_QA",
            "reference": {"path": _relative(root, _resolve(root, str(reference_path))), "sha256": expected_reference_sha256},
            "render_id": reference["render_id"], "target": reference["target"], "takes": rows,
            "measured_frames": count, "expected_frames": count, "full_duration_observed": True,
            "mean_all": math.fsum(row["mean_all"]*row["frames"] for row in rows)/count,
            "minimum_all": min(row["minimum_all"] for row in rows),
            "output_sync_unwitnessed_takes": [r["take_id"] for r in rows if r["output_sync_witness_required"]],
            "source_intrinsic_quality_proved": False, "semantic_quality_proved": False,
            "quality_authorized": False, "render_authorized": False, "publication_authorized": False}


def measure_phase6_source_hand_transfer(
    root: Path, *, reference_path: str | Path, expected_reference_sha256: str,
    observed_hand_path: str | Path, expected_observation_sha256: str, output_directory: Path,
) -> dict[str, Any]:
    """Public automatic source/candidate hand comparison, not final QA.

    Reuses an exact, externally bound target observation instead of repeating
    its decode/inference. Only the independent canonical source is decoded.
    No queue, voice, render, operational runtime or old receipt is modified.
    """
    import numpy as np
    from PIL import Image
    from .phase6_visual_metrics import decode_source_clock_frame, VisualMeasurementUnavailable
    from .phase6_visual_landmarks import VERSION, MODEL_BINDINGS, observe_hand_frame, compare_hand_geometry

    root = root.resolve()
    reference = read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    observed_path = _resolve(root, str(observed_hand_path))
    observed_raw = observed_path.read_bytes()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_observation_sha256) or "sha256:" + hashlib.sha256(observed_raw).hexdigest() != expected_observation_sha256:
        raise PermissionError("hand observation anchor mismatch")
    observed = json.loads(observed_raw)
    models = {key: {"file": row[0], "size_bytes": row[1], "sha256": "sha256:" + row[2]} for key, row in MODEL_BINDINGS.items()}
    if observed["version"] != VERSION or observed["models"] != models or observed["reference_id"] != reference["reference_id"] or observed["quality_authorized"] is not False:
        raise PermissionError("hand observation reference/model/authority differs")
    frame = observed["frame_observation"]
    index = frame["frame_index"]
    fps = Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"])
    if type(index) is not int or not 0 <= index < reference["frame_count"] or frame["pts_ms"] != float(Fraction(index * 1000, 1) / fps):
        raise PermissionError("hand observation frame/PTS differs from render clock")
    frame_path = _resolve(root, observed["input"]["path"])
    frame_raw = frame_path.read_bytes()
    if _resolve(root, frame["path"]) != frame_path or frame["sha256"] != observed["input"]["sha256"] or "sha256:" + hashlib.sha256(frame_raw).hexdigest() != frame["sha256"]:
        raise PermissionError("hand observation frame binding differs")
    import io
    with Image.open(io.BytesIO(frame_raw)) as image:
        pixels = np.asarray(image.convert("RGB"))
    if pixels.shape != (frame["height"], frame["width"], 3) or "sha256:" + hashlib.sha256(pixels.tobytes()).hexdigest() != frame["decoded_rgb_sha256"] or frame["decoded_rgb_sha256"] != observed["input"]["decoded_rgb_sha256"]:
        raise PermissionError("hand observation decoded pixels differ")
    selected = [row for row in reference["takes"] if row["target_start_frame"] <= index < row["target_end_frame_exclusive"]]
    if len(selected) != 1:
        raise PermissionError("hand observation has ambiguous take binding")
    take = selected[0]
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("hand transfer requires a new confined evidence directory")
    directory.mkdir(parents=True, exist_ok=False)
    source_path = _resolve(root, take["source"]["path"])
    canonical_pixels, clock = decode_source_clock_frame(source_path, ffmpeg=FFMPEG,
        start_ms=Fraction(take["source_start_ms"]), frame_index=index - take["target_start_frame"], fps=fps)
    source_frame = directory / "canonical-source.png"
    with source_frame.open("xb") as stream:
        Image.fromarray(canonical_pixels).save(stream, format="PNG")
    canonical = observe_hand_frame(root, source_frame, expected_sha256=_sha(source_frame, prefixed=True))
    canonical["frame_observation"] = clock
    try:
        comparison = compare_hand_geometry(canonical, observed,
            reference_size=(clock["width"], clock["height"]), candidate_size=(frame["width"], frame["height"]))
    except VisualMeasurementUnavailable as exc:
        comparison = {"status": "UNOBSERVABLE", "variable": str(exc), "quality_authorized": False}
    read_phase6_visual_reference(root, reference_path, expected_sha256=expected_reference_sha256)
    if observed_path.read_bytes() != observed_raw or frame_path.read_bytes() != frame_raw:
        raise PermissionError("bound target observation changed during source comparison")
    result = {"version": "phase6-source-hand-transfer-v1", "status": "MEASURED_REFERENCE_TRANSFER_NOT_ANATOMY_APPROVAL",
              "reference": {"path": _relative(root, _resolve(root, str(reference_path))), "sha256": expected_reference_sha256},
              "target_observation": {"path": _relative(root, observed_path), "sha256": expected_observation_sha256},
              "take_id": take["take_id"], "target_frame": index, "source": take["source"],
              "canonical_observation": canonical, "comparison": comparison,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def measure_phase6_hand_composition_control(
    root: Path, *, transfer_path: str | Path, expected_transfer_sha256: str, output_directory: Path,
) -> dict[str, Any]:
    """Apply declared composition in the source decoder's native colour domain.

    No temporal/video regeneration. A single uncompressed PNG separates the
    hand detector's response to authorized overlays/grading from actual shape
    changes. It does not claim to reproduce a historical command or establish
    anatomy. Previous source/target observations are reused without inference.
    """
    from .phase6_visual_landmarks import observe_hand_frame, compare_hand_geometry
    from .phase6_visual_metrics import layout_landmark_visibility, VisualMeasurementUnavailable, decode_source_clock_frame
    from .phase6_visual_recipe import inspect_visual_layout, visual_filters, RECIPE_ID
    from .render_creative_v2_phase5 import _font
    from PIL import Image
    import numpy as np

    root = root.resolve()
    transfer_path = _resolve(root, str(transfer_path))
    raw = transfer_path.read_bytes()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_transfer_sha256) or "sha256:" + hashlib.sha256(raw).hexdigest() != expected_transfer_sha256:
        raise PermissionError("source transfer anchor mismatch")
    transfer = json.loads(raw)
    if transfer["version"] != "phase6-source-hand-transfer-v1" or any(transfer[k] is not False for k in ("quality_authorized", "render_authorized", "publication_authorized")):
        raise PermissionError("source transfer contract/authority differs")
    binding = transfer["reference"]
    reference = read_phase6_visual_reference(root, binding["path"], expected_sha256=binding["sha256"])
    take_row = next(row for row in reference["takes"] if row["take_id"] == transfer["take_id"])
    if take_row["source"] != transfer["source"] or not take_row["target_start_frame"] <= transfer["target_frame"] < take_row["target_end_frame_exclusive"]:
        raise PermissionError("source transfer take/frame differs")
    target_binding = transfer["target_observation"]
    observed_path = _resolve(root, target_binding["path"])
    if _sha(observed_path, prefixed=True) != target_binding["sha256"]:
        raise PermissionError("target hand observation changed")
    target = _read(observed_path)
    if target["reference_id"] != reference["reference_id"] or target["frame_observation"]["frame_index"] != transfer["target_frame"]:
        raise PermissionError("target observation belongs to another frame/reference")
    source = transfer["canonical_observation"]
    source_path = _resolve(root, source["input"]["path"])
    if _sha(source_path, prefixed=True) != source["input"]["sha256"]:
        raise PermissionError("canonical hand source frame changed")
    target_frame = _resolve(root, target["input"]["path"])
    if _sha(target_frame, prefixed=True) != target["input"]["sha256"]:
        raise PermissionError("target hand pixels changed")
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("composition control requires a new confined evidence directory")
    directory.mkdir(parents=True, exist_ok=False)
    plan = _read(root / BASE / "production/take_plan.json")
    treatment = _read(root / BASE / "production/creative_treatment_plan.json")
    take = next(row for row in plan["takes"] if row["take_id"] == transfer["take_id"])
    direction = next(row for row in treatment["takes"] if row["take_id"] == transfer["take_id"])
    font = _font()
    font_hash = _sha(font, prefixed=True)
    layout = inspect_visual_layout(take, direction, font=font)
    filters = visual_filters(take, direction, font=font, work_dir=directory / "text")
    pixels, clock = decode_source_clock_frame(_resolve(root, take_row["source"]["path"]), ffmpeg=FFMPEG,
        start_ms=Fraction(take_row["source_start_ms"]), frame_index=transfer["target_frame"] - take_row["target_start_frame"],
        fps=Fraction(reference["fps"]["numerator"], reference["fps"]["denominator"]), composition_filters=tuple(filters))
    height, width = pixels.shape[:2]
    if (width, height) != (layout["canvas"]["width"], layout["canvas"]["height"]):
        raise PermissionError("composition control canvas differs from bound layout")
    control_frame = directory / "composition-control.png"
    with control_frame.open("xb") as stream:
        Image.fromarray(pixels).save(stream, format="PNG")
    control = observe_hand_frame(root, control_frame, expected_sha256=_sha(control_frame, prefixed=True))
    comparisons = {}
    for name, a, b, sizes in (
        ("source_to_control", source, control, ((source["frame_observation"]["width"], source["frame_observation"]["height"]), (width, height))),
        ("control_to_target", control, target, ((width, height), (target["frame_observation"]["width"], target["frame_observation"]["height"]))),
    ):
        try:
            comparisons[name] = compare_hand_geometry(a, b, reference_size=sizes[0], candidate_size=sizes[1])
        except VisualMeasurementUnavailable as exc:
            comparisons[name] = {"status": "UNOBSERVABLE", "variable": str(exc), "quality_authorized": False}
    visibility = []
    for hand in target["hands"]:
        if hand["status"] == "LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL":
            visibility.append(layout_landmark_visibility(np.asarray(hand["screen_landmarks_xyz"])[:, :2], layout))
        else:
            visibility.append({"status": "UNOBSERVABLE", "variable": "pose uncertain"})
    read_phase6_visual_reference(root, binding["path"], expected_sha256=binding["sha256"])
    if transfer_path.read_bytes() != raw or _sha(observed_path, prefixed=True) != target_binding["sha256"] or _sha(source_path, prefixed=True) != source["input"]["sha256"] or _sha(target_frame, prefixed=True) != target["input"]["sha256"] or _sha(font, prefixed=True) != font_hash:
        raise PermissionError("composition control input changed during measurement")
    result = {"version": "phase6-hand-composition-control-v2", "status": "COMPOSITION_CONTROL_MEASURED_NOT_QUALITY_APPROVAL",
              "transfer": {"path": _relative(root, transfer_path), "sha256": expected_transfer_sha256},
              "recipe_id": RECIPE_ID, "font": {"path": str(font), "sha256": font_hash},
              "filters": filters, "command": clock["command"], "source_clock": clock,
              "composition_domain": "native-decoder-before-rgb", "layout": layout, "control_observation": control,
              "comparisons": comparisons, "target_landmark_visibility": visibility,
              "historical_command_witness": False, "candidate_used_for_control_generation": False,
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def measure_phase6_hand_pixel_transport(
    root: Path, *, control_path: str | Path, expected_control_sha256: str, output_directory: Path,
) -> dict[str, Any]:
    """Reuse a composition control to observe source-projected hand pixels.

    A pose detector losing confidence under text cannot be fixed by lowering
    its cutoff. The known source projection supplies points to an independent
    image tracker instead; missing texture remains unknown, not valid anatomy.
    No previous decoding, neural inference or compositing is repeated.
    """
    from .phase6_visual_metrics import track_reference_points, spatial_measurements, layout_landmark_visibility
    from PIL import Image
    import io
    import numpy as np

    root = root.resolve()
    saved = []
    def bound_json(path, digest, version):
        path = _resolve(root, str(path))
        data = path.read_bytes()
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", digest) or "sha256:" + hashlib.sha256(data).hexdigest() != digest:
            raise PermissionError("hand transport evidence anchor mismatch")
        value = json.loads(data)
        if value["version"] not in ((version,) if isinstance(version, str) else version) or value["quality_authorized"] is not False:
            raise PermissionError("hand transport evidence contract/authority mismatch")
        saved.append((path, data))
        return value
    control = bound_json(control_path, expected_control_sha256, ("phase6-hand-composition-control-v1", "phase6-hand-composition-control-v2"))
    transfer = bound_json(control["transfer"]["path"], control["transfer"]["sha256"], "phase6-source-hand-transfer-v1")
    from .phase6_visual_landmarks import VERSION as HAND_VERSION
    target = bound_json(transfer["target_observation"]["path"], transfer["target_observation"]["sha256"], HAND_VERSION)
    binding = transfer["reference"]
    reference = read_phase6_visual_reference(root, binding["path"], expected_sha256=binding["sha256"])
    if target["reference_id"] != reference["reference_id"] or target["frame_observation"]["frame_index"] != transfer["target_frame"]:
        raise PermissionError("hand transport target belongs to another source clock")
    def pixels(observation):
        frame = _resolve(root, observation["input"]["path"])
        data = frame.read_bytes()
        if "sha256:" + hashlib.sha256(data).hexdigest() != observation["input"]["sha256"]:
            raise PermissionError("hand transport frame drift")
        with Image.open(io.BytesIO(data)) as image:
            rgb = np.asarray(image.convert("RGB"))
        if "sha256:" + hashlib.sha256(rgb.tobytes()).hexdigest() != observation["input"]["decoded_rgb_sha256"]:
            raise PermissionError("hand transport decoded pixel drift")
        saved.append((frame, data))
        return rgb
    original = transfer["canonical_observation"]
    source = pixels(original)
    expected = pixels(control["control_observation"])
    actual = pixels(target)
    if expected.shape != actual.shape:
        raise PermissionError("hand transport canvas differs")
    source_wh = np.asarray([source.shape[1], source.shape[0]])
    target_wh = np.asarray([expected.shape[1], expected.shape[0]])
    scale = float(max(target_wh / source_wh))
    crop = (source_wh * scale - target_wh) / 2
    rows = []
    for index, hand in enumerate(original["hands"]):
        if hand["status"] != "LANDMARKS_OBSERVED_NOT_ANATOMY_APPROVAL":
            rows.append({"hand_index": index, "status": "UNOBSERVABLE_SOURCE_POSE", "quality_authorized": False})
            continue
        positions = np.asarray(hand["screen_landmarks_xyz"], dtype=np.float64)[:, :2] * scale - crop
        rows.append({"hand_index": index, "pixel_transport": track_reference_points(expected, actual, positions),
                     "layout_visibility": layout_landmark_visibility(positions, control["layout"])})
    structural = spatial_measurements(expected, actual)
    read_phase6_visual_reference(root, binding["path"], expected_sha256=binding["sha256"])
    if any(path.read_bytes() != data for path, data in saved):
        raise PermissionError("hand transport evidence changed during measurement")
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("hand transport requires a new confined evidence directory")
    result = {"version": "phase6-hand-pixel-transport-v1", "status": "PIXEL_TRANSPORT_MEASURED_NOT_ANATOMY_APPROVAL",
              "control": {"path": _relative(root, _resolve(root, str(control_path))), "sha256": expected_control_sha256},
              "source_projection": {"scale": scale, "crop_offset_xy": crop.tolist()},
              "take_id": transfer["take_id"], "target_frame": transfer["target_frame"], "hands": rows,
              "full_frame_structural_transfer": structural, "tolerance": None,
              "reference_domain": control.get("composition_domain", "rgb-roundtrip-v1-diagnostic-only"),
              "quality_authorized": False, "render_authorized": False, "publication_authorized": False}
    _write_immutable(directory / "measurement.json", result)
    return result


def measure_phase6_anatomy_instrument(
    root: Path, *, acquisition_path: str | Path, expected_acquisition_sha256: str, output_directory: Path,
) -> dict[str, Any]:
    """Public QA acquisition -> independent labelled controls -> immutable audit.

    This deliberately cannot populate a video defect PASS. Instrument results
    are scoped to the selected held-out images, not all frames of a candidate.
    """
    from .phase6_visual_anatomy import evaluate_labelled_controls, HAND_MODEL, DIRECTORY

    root = root.resolve()
    directory = _resolve(root, str(output_directory))
    allowed = (root / BASE / "quality/visual-measurements").resolve()
    if directory == allowed or allowed not in directory.parents or directory.exists():
        raise PermissionError("anatomy instrument requires a new confined evidence directory")
    acquisition = _resolve(root, str(acquisition_path))
    implementations = [root / "hero_engine/phase6_quality.py", root / "hero_engine/phase6_visual_anatomy.py"]
    before = [{"path": _relative(root, path), "sha256": _sha(path, prefixed=True)} for path in implementations]
    result = evaluate_labelled_controls(root, acquisition_path=acquisition, expected_sha256=expected_acquisition_sha256)
    for row in before:
        if _sha(root / row["path"], prefixed=True) != row["sha256"]:
            raise PermissionError("anatomy instrument implementation changed during evaluation")
    result.update({"acquisition": {"path": _relative(root, acquisition), "sha256": expected_acquisition_sha256},
                   "implementation_bindings": before,
                   "model": {"path": (DIRECTORY / HAND_MODEL[0]).as_posix(), "sha256": "sha256:" + HAND_MODEL[2]}})
    _write_immutable(directory / "measurement.json", result)
    return result


def _verify_voice_for_quality(
    root: Path,
    voice: dict[str, Any],
    capacity: dict[str, Any],
    *,
    capacity_path: Path,
    capacity_sha256: str,
) -> dict[str, Any]:
    """Recompute the complete current voice proof at the quality boundary.

    Phase 6 voice schema 1.2 binds the exact TakePlan/script bytes, ordered
    copy, slots, speeds, model/voice/eSpeak identities and every measured WAV.
    A label-only comparison here would turn that stronger contract back into a
    weak receipt check, so quality deliberately invokes the producer-independent
    verifier again.
    Schema 1.3 additionally reopens its immutable codec-only voice predecessor;
    it never transfers that predecessor's render or quality authority.
    """

    if voice.get("schema_version") not in ("1.2.0", "1.3.0"):
        raise PermissionError(
            "Phase 6 quality requires the current schema-1.2 measured voice contract"
        )
    if capacity.get("schema_version") != "1.1.0":
        raise PermissionError(
            "Phase 6 quality requires the current schema-1.1 capacity contract"
        )
    expected_capacity_reference = {
        "receipt_id": capacity["receipt_id"],
        "receipt_path": _relative(root, capacity_path),
        "sha256": capacity_sha256,
    }
    return _verify_voice_manifest_contract(
        root,
        voice,
        expected_capacity_reference=expected_capacity_reference,
        expected_espeak=espeak_binding_identity(capacity["espeak"]),
    )


def _verified_media(root: Path) -> tuple[dict[str, Any] | None, str | None]:
    status_path = root / "output/operations/phase6/media-executor-status.json"
    if not status_path.is_file():
        return None, "The local media executor has not produced a status receipt."
    status = _read(status_path)
    _validate(root, "phase6_media_executor_runtime.schema.json", status)
    if status["status"] != "COMPLETED" or status["job_state"] != "SUCCEEDED":
        return None, f"Media executor is {status['status']}/{status['job_state']}."
    manifest_path = _resolve(root, str(status["render_manifest"]))
    voice_path = _resolve(root, str(status["voice_manifest"]))
    if not manifest_path.is_file() or not voice_path.is_file():
        raise FileNotFoundError("media executor points to a missing render or voice manifest")
    manifest = _read(manifest_path)
    _validate(root, "render_manifest.schema.json", manifest)
    immutable_render_dir = (root / BASE / "renders/manifests").resolve()
    if manifest_path.parent.resolve() != immutable_render_dir or manifest_path.name != f"{manifest.get('render_id')}.json":
        raise PermissionError("media executor does not point to the exact immutable render manifest")
    latest_render = root / BASE / "render_manifest.json"
    if not latest_render.is_file() or latest_render.read_bytes() != manifest_path.read_bytes():
        raise PermissionError("latest render manifest differs from its immutable twin")
    verify_phase6_segment_set(
        root, manifest.get("segment_receipt_set") or {},
        expected_input_receipt_id=status.get("input_receipt_id"),
    )
    voice = _read(voice_path)
    _validate(root, "voice_render_manifest.schema.json", voice)
    immutable_voice_dir = (root / BASE / "audio/manifests").resolve()
    if voice_path.parent.resolve() != immutable_voice_dir or voice_path.name != f"{voice.get('voice_render_id')}.json":
        raise PermissionError("media executor does not point to the exact immutable voice manifest")
    latest_voice = root / BASE / "audio/voice_render_manifest.json"
    if not latest_voice.is_file() or latest_voice.read_bytes() != voice_path.read_bytes():
        raise PermissionError("latest voice manifest differs from its immutable twin")
    for take in voice["takes"]:
        take_path = _resolve(root, take["path"])
        if not take_path.is_file() or _sha(take_path, prefixed=True) != take["content_hash"]:
            raise PermissionError(f"voice take changed after its immutable manifest: {take['take_id']}")
    if manifest.get("voice_render_id") != voice.get("voice_render_id"):
        raise PermissionError("render manifest and immutable voice manifest identity diverge")
    video = _resolve(root, manifest["output"]["path"])
    if not video.is_file() or _sha(video, prefixed=True) != manifest["output"]["content_hash"]:
        raise PermissionError("frozen Phase 6 render hash does not match the media receipt")
    if manifest.get("video_id") != VIDEO_ID or manifest.get("status") != "COMPLETE":
        raise PermissionError("media receipt belongs to a different video or is incomplete")
    capacity_path = _resolve(root, str(status.get("capacity_preflight_receipt") or ""))
    if not capacity_path.is_file():
        raise FileNotFoundError("media executor points to a missing immutable capacity receipt")
    capacity = verify_phase6_capacity_receipt(
        root,
        receipt_path=capacity_path,
        expected_sha256=status.get("capacity_preflight_sha256"),
        require_pass=True,
    )
    _verify_voice_for_quality(
        root,
        voice,
        capacity,
        capacity_path=capacity_path,
        capacity_sha256=str(status.get("capacity_preflight_sha256") or ""),
    )
    return {"status": status, "manifest": manifest, "manifest_path": manifest_path, "voice_path": voice_path, "video": video}, None


def _script_text(script: dict[str, Any]) -> str:
    if script.get("full_text"):
        return str(script["full_text"])
    hook = " ".join(str(item.get("narration") or item.get("original_text") or "") for item in script.get("hook_windows") or [])
    body = " ".join(str(item.get("text") or "") for item in script.get("sections") or [])
    return " ".join((hook, body)).strip()


def _captions(plan: dict[str, Any], path: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    expected = " ".join(str(item.get("narration") or "") for item in plan["takes"]).strip()
    observed = _srt_text(path)
    reference_words, observed_words = _words(expected), _words(observed)
    errors = _edit_distance(reference_words, observed_words)
    maximum = max((len(_words(line)) for line in path.read_text(encoding="utf-8-sig").splitlines() if line and "-->" not in line and not line.strip().isdigit()), default=0)
    return {
        "cue_count": int(manifest["captions"]["cue_count"]),
        "expected_cue_count": len(plan["takes"]),
        "coverage_ratio": float(manifest["captions"]["coverage_ratio"]),
        "maximum_words_per_cue": maximum,
        "script_word_error_count": errors,
        "script_word_error_rate": round(errors / max(1, len(reference_words)), 6),
        "hash_verified": _sha(path, prefixed=True) == manifest["captions"]["content_hash"],
        "passed": bool(errors == 0 and maximum <= 12 and len(plan["takes"]) == int(manifest["captions"]["cue_count"]) and float(manifest["captions"]["coverage_ratio"]) == 1.0),
    }


def _asr_measurement(video: Path, expected_text: str, supplied: dict[str, Any] | None) -> dict[str, Any]:
    transcript = dict(supplied or _asr(video))
    reference, observed = _words(expected_text), _words(str(transcript.get("text") or ""))
    errors = _edit_distance(reference, observed)
    wer = round(errors / max(1, len(reference)), 6)
    transcript.update({
        "reference_word_count": len(reference),
        "observed_word_count": len(observed),
        "word_error_count": errors,
        "word_error_rate": wer,
        "threshold_max_word_error_rate": 0.08,
        "passed": bool(wer <= 0.08 and str(transcript.get("language") or "").startswith("en") and float(transcript.get("language_probability") or 0) >= 0.75),
    })
    return transcript


def _rights(root: Path, allocation: dict[str, Any], library: dict[str, Any], attribution: Path) -> dict[str, Any]:
    assets = {item["asset_id"]: item for item in library["assets"]}
    failures: list[str] = []
    verified: set[str] = set()
    attribution_text = attribution.read_text(encoding="utf-8-sig") if attribution.is_file() else ""
    for record in allocation["takes"]:
        asset = assets.get(record["asset_id"])
        if asset is None:
            failures.append(f"{record['take_id']}:asset-not-in-library")
            continue
        media = _resolve(root, asset["uri"])
        evidence = _resolve(root, asset["rights_evidence_uri"])
        evidence_valid = False
        try:
            evidence_record = _read(evidence)
            validate_phase6_rights_evidence(root, asset, evidence_record, media_path=media)
            evidence_valid = True
        except Exception:
            evidence_valid = False
        checks = (
            asset.get("rights_status") in RIGHTS_OK,
            bool(asset.get("commercial_use")),
            bool(asset.get("production_eligible")),
            asset.get("content_quality_gate") == "PASS",
            media.is_file() and _sha(media, prefixed=True) == asset.get("content_hash") == record.get("content_hash"),
            evidence.is_file() and evidence_valid,
            record.get("rights_status") == asset.get("rights_status"),
            record["asset_id"] in attribution_text,
        )
        if not all(checks):
            failures.append(f"{record['take_id']}:{record['asset_id']}:rights-or-integrity-check")
        else:
            verified.add(record["asset_id"])
    return {
        "used_asset_count": len({item["asset_id"] for item in allocation["takes"]}),
        "verified_asset_count": len(verified),
        "failed_checks": failures,
        "all_rights_evidence_present": not failures,
        "commercial_use_only": not failures,
        "attribution_complete": not failures,
        "passed": not failures,
    }


def package_fidelity_measurement(
    root: Path, brief: dict[str, Any], script: dict[str, Any],
    plan: dict[str, Any], *, title: str, thumbnail_text: str,
) -> dict[str, Any]:
    """Reopen a bounded independent editorial review, not a word-overlap score.

    Matching individual words proves neither entailment nor its absence. The
    current LIMITED pack instead has an explicit non-human review of its exact
    promise, complete narrative and three paired packages. All unknown scopes
    remain NEEDS_REVIEW. This is no general semantic classifier or visual QA.
    The enclosing input/media/ASR verifiers still authenticate the actual edit.
    """
    path = root / PACKAGE_FIDELITY_REVIEW
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != PACKAGE_FIDELITY_REVIEW_SHA256:
        raise PermissionError("package fidelity review differs from its versioned pin")
    review = json.loads(raw)
    observed = {
        "package": brief.get("package"), "payoff": brief.get("payoff"),
        "language": script.get("language"),
        "original_thesis": script.get("original_thesis"),
        "full_text": script.get("full_text"), "sections": script.get("sections"),
    }
    matches = [item for item in review["candidates"]
               if item["title"] == title and item["thumbnail_text"] == thumbnail_text]
    narrated = " ".join(str(take.get("narration") or "") for take in plan.get("takes") or [])
    checks = {
        "reviewed_complete_scope": observed == review["reviewed_inputs"],
        "script_binds_brief": bool(brief.get("brief_id")) and script.get("brief_id") == brief["brief_id"],
        "exact_reviewed_pair": len(matches) == 1,
        "complete_narrative_in_take_plan": bool(narrated) and _words(narrated) == _words(str(script.get("full_text") or "")),
    }
    passed = all(checks.values())
    return {
        "method": "EXACT_VERSIONED_NON_HUMAN_EDITORIAL_REVIEW",
        "review_id": review["review_id"],
        "reviewer_type": review["reviewer_type"],
        "review_path": PACKAGE_FIDELITY_REVIEW.as_posix(),
        "review_sha256": "sha256:" + digest,
        "checks": checks, "passed": passed,
        "status": "PASS_EXACT_REVIEWED_SCOPE" if passed else "NEEDS_REVIEW",
        "support_sections": matches[0]["support_sections"] if passed else [],
        "rationale": matches[0]["rationale"] if passed else "The complete reviewed claim/narrative scope or exact package pairing changed.",
        "human_review_claimed": False, "visual_quality_authorized": False,
        "publication_authorized": False,
    }


def _thumbnail_measurements(root: Path, manifest: dict[str, Any], brief: dict[str, Any]) -> dict[str, Any]:
    from PIL import Image, ImageStat

    titles = list((brief.get("package") or {}).get("title_variants") or [])[:3]
    script = _read(root / BASE / "preproduction/narrative_script.json")
    plan = _read(root / BASE / "production/take_plan.json")
    banned = re.compile(r"\b(guaranteed|miracle|instant|secret|god told|will happen)\b", re.I)
    rows = []
    for index, item in enumerate(manifest["candidates"]):
        path = _resolve(root, item["path"])
        title = titles[index] if index < len(titles) else f"HeroVerse treatment {item['candidate_id']}"
        with Image.open(path) as image:
            grayscale = image.convert("L")
            extrema = grayscale.getextrema()
            contrast = round(float(ImageStat.Stat(grayscale).stddev[0]), 6)
            width, height = image.size
        text_words = _words(str(item["text"]))
        fidelity = package_fidelity_measurement(
            root, brief, script, plan, title=title, thumbnail_text=str(item["text"]),
        )
        checks = {
            "hash": _sha(path, prefixed=True) == item["content_hash"],
            "dimensions": width == 1280 and height == 720,
            "size": path.stat().st_size <= 2_097_152,
            "contrast": contrast >= 22 and extrema[1] - extrema[0] >= 140,
            "text_density": 2 <= len(text_words) <= 5,
            "title_length": 25 <= len(title) <= 100,
            "policy": banned.search(title + " " + str(item["text"])) is None,
            "promise_fidelity": fidelity["passed"],
        }
        score = sum(checks.values()) / len(checks)
        rows.append({
            "candidate_id": item["candidate_id"], "path": str(path.resolve()), "sha256": _sha(path),
            "title": title, "text": item["text"], "width": width, "height": height,
            "size_bytes": path.stat().st_size, "contrast_standard_deviation": contrast,
            "luminance_range": extrema[1] - extrema[0], "checks": checks,
            "score": round(score, 6), "passed": all(checks.values()),
            "fidelity_evidence": fidelity,
        })
    selected = max(rows, key=lambda row: (row["passed"], row["score"], -len(row["title"]), row["candidate_id"]), default=None)
    if selected is None:
        raise ValueError("thumbnail set contains no candidate")
    return {"candidates": rows, "all_candidates_pass": all(item["passed"] for item in rows), "selected": selected}


def _input_integrity(root: Path, allocation: dict[str, Any]) -> dict[str, Any]:
    receipt_path = root / "output/operations/phase6/release/latest-production-inputs-receipt.json"
    failures = []
    residency_error: str | None = None
    residency_identity: dict[str, Any] | None = None
    receipt: dict[str, Any] = {"receipt_id": None, "artifacts": []}
    try:
        receipt = verify_production_inputs_receipt(
            root,
            receipt_path=receipt_path,
            required_action="PREPARE_VIDEO_2_INPUTS",
            recheck_decode=True,
        )
        binding = receipt["asset_residency"]
        residency_identity = verify_phase6_asset_residency(
            root, receipt_path=binding["receipt_path"], expected_sha256=binding["sha256"],
            expected_audit_id=binding["audit_id"], required_asset_ids=[item["asset_id"] for item in allocation.get("takes") or []],
            recheck_media=True, recheck_decode=True,
        )
    except Exception as exc:
        residency_error = f"{type(exc).__name__}:{exc}"
        failures.append("production_inputs_or_asset_residency")
    return {
        "receipt_id": receipt["receipt_id"],
        "verified_count": len(receipt["artifacts"]) if not failures else 0,
        "failure_paths": failures,
        "asset_residency_audit_id": residency_identity.get("audit_id") if residency_identity else None,
        "asset_residency_receipt": residency_identity.get("receipt_path") if residency_identity else None,
        "asset_residency_sha256": residency_identity.get("sha256") if residency_identity else None,
        "asset_residency_error": residency_error,
        "passed": not failures,
    }


def _fingerprint(paths: list[Path], render_hash: str) -> str:
    digest = hashlib.sha256(render_hash.encode())
    for path in paths:
        digest.update(str(path).encode())
        digest.update(path.read_bytes() if path.is_file() else b"<MISSING>")
    return digest.hexdigest()


def _evaluation_identity(report: dict[str, Any]) -> str:
    content = dict(report)
    content.pop("evaluation_id", None)
    encoded = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "phase6-quality-" + hashlib.sha256(encoded).hexdigest()[:24]


def verify_phase6_quality_evaluation(
    root: Path = ROOT,
    *,
    report_path: str | Path | None = None,
    expected_evaluation_id: str | None = None,
) -> dict[str, Any]:
    """Verify evaluation identity, immutable twin and all live artifact bindings."""

    root = root.resolve()
    latest = root / REPORT
    source = Path(report_path) if report_path is not None else latest
    source = source if source.is_absolute() else root / source
    if not source.is_file():
        raise FileNotFoundError(f"quality evaluation missing: {_relative(root, source)}")
    report = _read(source)
    _validate(root, "phase6_quality_evaluation.schema.json", report)
    if report.get("evaluation_id") != _evaluation_identity(report):
        raise PermissionError("quality evaluation_id does not match its complete decision content")
    if expected_evaluation_id is not None and report["evaluation_id"] != expected_evaluation_id:
        raise PermissionError("quality evaluation identity differs from the expected queue checkpoint")

    immutable = root / QUALITY_EVALUATIONS / f"{report['evaluation_id']}.json"
    if not immutable.is_file() or immutable.read_bytes() != source.read_bytes():
        raise PermissionError("quality evaluation differs from or lacks its immutable twin")
    if not latest.is_file() or latest.read_bytes() != immutable.read_bytes():
        raise PermissionError("latest quality evaluation differs from its immutable twin")

    policy = report.get("audit_policy") or {}
    bindings = policy.get("evidence_bindings") or []
    binding_names = [str(item.get("path") or "") for item in bindings]
    if (
        report.get("evaluator", {}).get("version") != EVALUATOR_VERSION
        or policy.get("evidence_binding_version") != "phase6-quality-evidence-v3"
        or policy.get("decision_recomputation_required") is not True
        or policy.get("unobservable_defects_fail_closed") is not True
        or len(bindings) < 10
        or len(binding_names) != len(set(binding_names))
    ):
        raise PermissionError("quality evaluation has no complete unique evidence-hash binding")
    for item in bindings:
        path = _resolve(root, str(item.get("path") or "")).resolve()
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise PermissionError(f"quality evidence escaped the project root: {path}") from exc
        if not path.is_file() or _sha(path, prefixed=True) != item.get("sha256") or path.stat().st_size != item.get("size_bytes"):
            raise PermissionError(f"quality evidence hash/size mismatch: {item.get('path')}")

    media, reason = _verified_media(root)
    if media is None:
        raise PermissionError(reason or "quality evaluation has no verified media")
    video = media["video"]
    artifact = report["artifact"]
    if (
        report.get("video_id") != media["manifest"].get("video_id")
        or artifact.get("path") != _relative(root, video)
        or artifact.get("sha256") != _sha(video)
        or artifact.get("size_bytes") != video.stat().st_size
        or artifact.get("hash_verified") is not True
        or media["manifest"]["output"].get("content_hash") != f"sha256:{artifact['sha256']}"
    ):
        raise PermissionError("quality evaluation artifact identity/hash mismatch")

    overlay_ocr = verify_overlay_ocr_measurement(
        root, (report.get("measurements") or {}).get("overlay_ocr") or {}
    )
    if overlay_ocr.get("video", {}).get("sha256") != f"sha256:{artifact['sha256']}":
        raise PermissionError("overlay OCR audit does not bind the frozen quality video")

    allocation_path = root / BASE / "production/asset_allocation.json"
    input_integrity = _input_integrity(root, _read(allocation_path))
    if not input_integrity["passed"]:
        raise PermissionError("quality evaluation production inputs no longer match their receipt")
    immutable_input = root / PRODUCTION_INPUT_RECEIPTS / f"{input_integrity['receipt_id']}.json"
    capacity_path = _resolve(root, str(media["status"].get("capacity_preflight_receipt") or ""))
    residency_path = _resolve(root, str(input_integrity.get("asset_residency_receipt") or ""))
    mandatory_bindings = {
        _relative(root, media["manifest_path"]), _relative(root, media["voice_path"]),
        _relative(root, video), _relative(root, immutable_input),
        _relative(root, capacity_path), _relative(root, residency_path),
        str(overlay_ocr["audit_path"]),
        PACKAGE_FIDELITY_REVIEW.as_posix(),
    }
    mandatory_bindings.update(
        str(item["frame_path"])
        for item in overlay_ocr.get("frames") or []
        if item.get("frame_path")
    )
    mandatory_bindings.update(
        str(item["path"])
        for item in (overlay_ocr.get("auditor") or {}).get("models") or []
    )
    for registry in (REGISTERED_VISUAL_WORD_EVIDENCE, REGISTERED_VISUAL_PALETTE_EVIDENCE):
        binding = registry.get(media["manifest"]["output"]["content_hash"])
        if binding is not None:
            mandatory_bindings.add(_relative(root, _resolve(root, binding["path"])))
    if not mandatory_bindings.issubset(set(binding_names)):
        raise PermissionError("quality evaluation omitted a mandatory input/media/capacity/residency hash")

    selection = report["thumbnail_selection"]
    thumbnail = _resolve(root, selection["path"])
    if not thumbnail.is_file() or _sha(thumbnail) != selection["sha256"]:
        raise PermissionError("quality-selected thumbnail content hash mismatch")
    thumbnail_manifest_path = root / BASE / "thumbnail/thumbnail_set_manifest.json"
    thumbnail_manifest = _read(thumbnail_manifest_path)
    candidate = next((item for item in thumbnail_manifest.get("candidates") or [] if item.get("candidate_id") == selection["candidate_id"]), None)
    if not candidate or _resolve(root, candidate["path"]).resolve() != thumbnail.resolve() or candidate.get("content_hash") != f"sha256:{selection['sha256']}":
        raise PermissionError("quality thumbnail selection does not match its render manifest")

    if [item.get("gate") for item in report["gates"]] != GATES or [item.get("defect") for item in report["defect_evaluations"]] != DEFECTS:
        raise PermissionError("quality gate/defect identity or ordering mismatch")
    failures = [item["gate"] for item in report["gates"] if item["status"] != "PASS"]
    failures.extend(f"DEFECT:{item['defect']}" for item in report["defect_evaluations"] if item["status"] != "PASS")
    if not report["calibration"].get("gold_standard_pass"):
        failures.append("GOLD_STANDARD_CALIBRATION")
    if not report["calibration"].get("negative_control_detected"):
        failures.append("NEGATIVE_CONTROL_CALIBRATION")
    expected_blockers = sorted(set(failures))
    hard_failure = bool(
        any(item["status"] in {"FAIL", "BLOCKED"} for item in report["gates"] + report["defect_evaluations"])
        or not report["calibration"].get("gold_standard_pass")
        or not report["calibration"].get("negative_control_detected")
    )
    needs_review = any(item["status"] == "NEEDS_REVIEW" for item in report["gates"] + report["defect_evaluations"])
    all_pass = not expected_blockers
    expected_decision = "PASS_LIMITED_RELEASE" if all_pass else ("FAIL" if hard_failure else "NEEDS_REVIEW" if needs_review else "BLOCKED")
    if (
        report["blockers"] != expected_blockers
        or report["publication_eligible"] is not all_pass
        or report["decision"] != expected_decision
    ):
        raise PermissionError("quality decision is inconsistent with its critical gates and calibration")
    recomputed = build_phase6_quality_evaluation(
        root, asr_result=None, created_at=report["created_at"],
    )
    if recomputed != report:
        raise PermissionError("quality measurements/gates do not match independent recomputation from raw evidence")
    return report


def build_phase6_quality_evaluation(
    root: Path = ROOT,
    *,
    asr_result: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    verified, reason = _verified_media(root)
    if verified is None:
        raise PermissionError(reason)
    manifest, video = verified["manifest"], verified["video"]
    # The public report must consume the same authenticated counterevidence as
    # the cheap executor. A full report cannot silently downgrade a measured
    # failure to unobserved, or turn component-only absence of failure into PASS.
    style_observations: dict[str, Any] = {}
    style_bindings: list[dict[str, str]] = []
    for component, registry, reader in (
        ("typography", REGISTERED_VISUAL_WORD_EVIDENCE, evaluate_phase6_visual_word_evidence),
        ("palette", REGISTERED_VISUAL_PALETTE_EVIDENCE, evaluate_phase6_visual_palette_evidence),
    ):
        binding = registry.get(manifest["output"]["content_hash"])
        if binding is not None:
            style_observations[component] = reader(root, receipt_path=binding["path"],
                expected_sha256=binding["sha256"],
                expected_video_sha256=manifest["output"]["content_hash"])
            style_bindings.append(dict(binding))
    production, preproduction = root / BASE / "production", root / BASE / "preproduction"
    plan_path, script_path = production / "take_plan.json", preproduction / "narrative_script.json"
    brief_path, allocation_path = preproduction / "editorial_brief.json", production / "asset_allocation.json"
    treatment_path, decision_path = production / "creative_treatment_plan.json", production / "creative_direction_decision.json"
    concept_path = preproduction / "creative_concept_decision.json"
    bible_path = production / "channel_style_bible.json"
    library_path = root / "output/production/phase6/shared-assets/asset_manifest.json"
    thumbnails_path = root / BASE / "thumbnail/thumbnail_set_manifest.json"
    caption_path = _resolve(root, manifest["captions"]["path"])
    attribution_path = _resolve(root, manifest["attribution_path"])
    channel_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    oauth_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    scope_path = root / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
    gold_path = root / "data/gold_standard/validation_report.json"
    negative_path = root / "output/production/phase5/pilot-001/creative-v2/qa/market_readiness_review.json"
    zero_policy_path = root / "config/zero-cost-policy.json"
    required_paths = [plan_path, script_path, brief_path, concept_path, allocation_path, treatment_path, decision_path, bible_path, library_path, thumbnails_path, caption_path, attribution_path, channel_path, oauth_path, scope_path, gold_path, negative_path, zero_policy_path, root / PACKAGE_FIDELITY_REVIEW]
    missing = [str(path) for path in required_paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("quality evidence missing: " + ", ".join(missing))

    plan, script, brief, concept = _read(plan_path), _read(script_path), _read(brief_path), _read(concept_path)
    allocation, treatment, decision, bible = _read(allocation_path), _read(treatment_path), _read(decision_path), _read(bible_path)
    library, thumbnails = _read(library_path), _read(thumbnails_path)
    channel, oauth, scopes = _read(channel_path), _read(oauth_path), _read(scope_path)
    gold, negative, zero_policy = _read(gold_path), _read(negative_path), _read(zero_policy_path)
    input_integrity = _input_integrity(root, allocation)
    _validate(root, "phase6_creative_concept_decision.schema.json", concept)
    script_text = _script_text(script)
    expected_text = " ".join(str(item.get("narration") or "") for item in plan["takes"]).strip()
    transcript = _asr_measurement(video, expected_text, asr_result)
    captions = _captions(plan, caption_path, manifest)
    probe = _probe(video)
    video_stream = next(item for item in probe["streams"] if item["codec_type"] == "video")
    audio_stream = next(item for item in probe["streams"] if item["codec_type"] == "audio")
    fps_n, fps_d = video_stream["r_frame_rate"].split("/", 1)
    fps = float(fps_n) / float(fps_d)
    measured_ms = round(float(probe["format"]["duration"]) * 1000)
    loudness = _loudness(video)
    black_freeze = _black_freeze_scan(video)
    qa_dir = root / BASE / "quality"
    # Do not overwrite historical stderr evidence or bind process-dependent
    # diagnostics. Native metadata is immutable and scoped to this exact video.
    signal_path = qa_dir / "signalstats-metadata-v1" / (str(manifest["output"]["content_hash"]).removeprefix("sha256:") + ".txt")
    signal = _signal_scan(video, signal_path, plan, manifest, canonical_evidence=True)
    timeline = _timeline_scan(plan, manifest, measured_ms)
    visual_evidence = _create_visual_evidence(video, qa_dir / "frames")
    rights = _rights(root, allocation, library, attribution_path)
    rights.update({
        "asset_residency_audit_id": input_integrity["asset_residency_audit_id"],
        "asset_residency_receipt": input_integrity["asset_residency_receipt"],
        "asset_residency_sha256": input_integrity["asset_residency_sha256"],
        "asset_residency_error": input_integrity["asset_residency_error"],
    })
    rights["passed"] = bool(rights["passed"] and input_integrity["passed"])
    publicity = screen_publicity(root, allocation, library)
    publicity_path = qa_dir / "publicity_risk_screen.json"
    _write(publicity_path, publicity)
    originality = _originality_scan(root, {"full_text": script_text})
    originality["passed"] = bool(originality["comparison_count"] >= 4 and originality["maximum_target_trigram_overlap"] <= originality["threshold"])
    thumb_measurements = _thumbnail_measurements(root, thumbnails, brief)
    overlay_ocr = materialize_overlay_ocr_audit(
        root,
        video=video,
        plan=plan,
        treatment=treatment,
        style_bible=bible,
        render_manifest=manifest,
        take_plan_path=plan_path,
        treatment_path=treatment_path,
        style_bible_path=bible_path,
        output_root=qa_dir / "overlay-ocr",
    )

    technical = {
        "video_codec": video_stream["codec_name"], "audio_codec": audio_stream["codec_name"],
        "width": int(video_stream["width"]), "height": int(video_stream["height"]), "fps": round(fps, 6),
        "duration_ms": measured_ms, "size_bytes": video.stat().st_size,
        "passed": bool(video_stream["codec_name"] == "h264" and audio_stream["codec_name"] == "aac" and int(video_stream["width"]) == 1920 and int(video_stream["height"]) == 1080 and math.isclose(fps, 30.0, abs_tol=0.01) and timeline["absolute_duration_error_ms"] <= 150 and timeline["frame_locked"] and timeline["maximum_cumulative_drift_ms"] <= (1000 / fps) / 2),
    }
    timeline["passed"] = bool(timeline["contiguous"] and timeline["no_adjacent_source_repeat"] and timeline["absolute_duration_error_ms"] <= 150 and timeline["frame_locked"] and timeline["maximum_cumulative_drift_ms"] <= (1000 / fps) / 2)
    signal_pass = bool(signal.get("status") == "MEASURED" and signal.get("within_take_luminance_delta_p95", 999) <= 15 and signal.get("hard_transition_count", 1) == 0 and black_freeze["black_event_count"] == 0 and black_freeze["freeze_event_count"] == 0)
    signal["passed"] = signal_pass
    audio_pass = bool(transcript["passed"] and -17 <= loudness["integrated_lufs"] <= -15 and loudness["true_peak_dbtp"] <= -1 and 0.5 <= loudness["lra_lu"] <= 8)
    allocation_measurements = allocation["measurements"]
    variety_pass = bool(allocation_measurements["maximum_single_asset_runtime_share"] <= 0.10 and allocation_measurements["top_six_asset_runtime_share"] <= 0.55 and allocation_measurements["maximum_asset_reuse_count"] <= 5 and allocation_measurements["maximum_rolling_60s_same_asset_count"] <= 3 and allocation_measurements["adjacent_repeat_count"] == 0 and allocation_measurements["prior_episode_overlap_ms"] == 0 and allocation_measurements["unique_asset_count"] >= 12)
    variety = {**allocation_measurements, "passed": variety_pass}
    semantic_complete = [item for item in plan["takes"] if item.get("semantic_alignment") and item.get("information") and item.get("retention_job") and item.get("narration")]
    semantic_base_pass = bool(len(semantic_complete) == len(plan["takes"]) and len({item.get("narrative_function") for item in plan["takes"]}) >= 4)
    semantic = {"take_count": len(plan["takes"]), "complete_take_count": len(semantic_complete), "coverage_ratio": round(len(semantic_complete) / max(1, len(plan["takes"])), 6), "distinct_narrative_functions": len({item.get("narrative_function") for item in plan["takes"]}), "base_passed": semantic_base_pass, "overlay_ocr": overlay_ocr["summary"]}
    semantic_gate = overlay_gate_value(semantic_base_pass, overlay_ocr, "semantic_passed")
    semantic["passed"] = semantic_gate is True
    hook_takes = [item for item in plan["takes"] if item["start_ms"] < 8000]
    hook_treatment = [item for item in treatment["takes"] if item["take_id"] in {take["take_id"] for take in hook_takes}]
    hook_assets = [item["asset_id"] for item in allocation["takes"] if item["take_id"] in {take["take_id"] for take in hook_takes}]
    voice = _read(verified["voice_path"])
    voice_hook = voice["takes"][:3]
    hook = {
        "windows": [item["window"] for item in plan["hook_window_coverage"]],
        "window_statuses": [item["gate_status"] for item in plan["hook_window_coverage"]],
        "distinct_sources_0_8": len(set(hook_assets)),
        "visual_events_0_8": sum(int(item["visual_event_count"]) for item in hook_treatment),
        "voice_durations_ms": [int(item["duration_ms"]) for item in voice_hook],
        "timing_status": voice.get("hook_timing_gate"),
    }
    hook_base_pass = bool(hook["windows"] == ["0_1S", "1_3S", "3_8S", "8_30S"] and all(item == "PASS" for item in hook["window_statuses"]) and hook["distinct_sources_0_8"] >= 3 and hook["visual_events_0_8"] >= 4 and hook["timing_status"] == "PASS" and all(item.get("fits_timeline_slot") for item in voice_hook))
    hook_gate = overlay_gate_value(hook_base_pass, overlay_ocr, "hook_passed")
    hook["base_passed"] = hook_base_pass
    hook["overlay_ocr"] = overlay_ocr["summary"]
    hook["passed"] = hook_gate is True
    channel_measure = {"overall_status": channel.get("overall_status"), "channel_id": channel.get("channel_id"), "handle": channel.get("handle"), "critical_open_gates": (channel.get("publication_gate") or {}).get("critical_open_gates") or [], "auto_publish_permitted": (channel.get("publication_gate") or {}).get("auto_publish_permitted"), "passed": bool(channel.get("overall_status") == "PASS" and channel.get("channel_id") == CHANNEL_ID and str(channel.get("handle") or "").casefold() == "@heroverse74" and not ((channel.get("publication_gate") or {}).get("critical_open_gates") or []) and (channel.get("publication_gate") or {}).get("auto_publish_permitted") is True)}
    oauth_measure = {"continuous_operation_ready": oauth.get("continuous_operation_ready"), "durability_status": oauth.get("durability_status"), "upload_permitted": (oauth.get("publication_guard") or {}).get("upload_permitted"), "scope_status": scopes.get("status"), "missing_scopes": scopes.get("missing_scopes") or [], "passed": bool(oauth.get("continuous_operation_ready") is True and (oauth.get("publication_guard") or {}).get("upload_permitted") is True and scopes.get("status") == "PASS" and not (scopes.get("missing_scopes") or []))}
    paid_tools = any("api" in str(item).casefold() and "local" not in str(item).casefold() for item in manifest.get("adapter_versions") or [])
    cost_measure = {"configured_cost_brl": zero_policy.get("technical_cost_brl"), "render_external_cost_usd": manifest.get("external_cost_usd"), "plan_external_cost_brl": (plan.get("total_cost") or {}).get("external"), "paid_tools": paid_tools, "passed": bool(zero_policy.get("technical_cost_brl") == 0 and manifest.get("external_cost_usd") == 0 and (plan.get("total_cost") or {}).get("external") == 0 and not paid_tools)}
    calibration = {"gold_standard_pass": bool(gold.get("passed") and (gold.get("totals") or {}).get("videos") == 4), "negative_control_detected": bool(negative.get("verdict") == "REJECTED_FOR_PUBLICATION" and any(item.get("status") == "FAIL" for item in negative.get("gates") or [])), "scope": "Human-reviewed mining calibrates evidence structure; the independent automatic evaluator governs this exact LIMITED HeroVerse pack/profile and never guarantees audience response."}
    narrative_pass = bool(len(script_text.split()) >= 300 and len(script.get("hook_windows") or []) == 4 and len(script.get("sections") or []) >= 6 and (brief.get("package") or {}).get("delivery_test") == "PASS")
    concept_selected = concept.get("selected_concept") or {}
    concept_rows = concept.get("candidate_assessments") or []
    creative_search = concept.get("creative_search") or {}
    concept_integrity = _creative_concept_integrity(concept)
    concept_pass = bool(concept_integrity["passed"])
    selected_pack_row = next((item for item in decision.get("candidate_assessments") or [] if item.get("format_pack_id") == "fp-broll-cinematic-narration" and item.get("pack_version") == "1.1.0"), None)
    strategy_pass = bool(input_integrity["passed"] and concept_pass and decision.get("decision") == "SELECT" and decision.get("channel_id") == CHANNEL_ID)
    dna_pass = bool(
        plan.get("channel_id") == CHANNEL_ID
        and decision.get("channel_dna_version") == "heroverse-channel-model-v1"
        and bible.get("channel_id") == CHANNEL_ID
        and selected_pack_row
        and selected_pack_row.get("eligible") is True
        and float(selected_pack_row.get("selection_score") or 0) >= 0.75
    )
    style_pass = bool(variety_pass and plan.get("format_pack_id") == "fp-broll-cinematic-narration" and plan.get("format_pack_version") == "1.1.0" and plan.get("style_bible_id") == bible.get("style_bible_id"))
    legibility_base_pass = bool(captions["passed"] and all(len(_words(str(item.get("on_screen_text") or ""))) <= 8 for item in plan["takes"]) and thumb_measurements["all_candidates_pass"])
    legibility_gate = overlay_gate_value(legibility_base_pass, overlay_ocr, "legibility_passed")
    publication_prereq = bool(channel_measure["passed"] and oauth_measure["passed"] and cost_measure["passed"] and verified["status"].get("publication_authorized") is False)

    evidence = {
        "input": "output/operations/phase6/release/latest-production-inputs-receipt.json", "media": _relative(root, verified["manifest_path"]),
        "video": _relative(root, video), "plan": _relative(root, plan_path), "script": _relative(root, script_path),
        "brief": _relative(root, brief_path), "allocation": _relative(root, allocation_path), "treatment": _relative(root, treatment_path),
        "decision": _relative(root, decision_path), "concept": _relative(root, concept_path), "bible": _relative(root, bible_path), "library": _relative(root, library_path),
        "captions": _relative(root, caption_path), "thumbnails": _relative(root, thumbnails_path), "attribution": _relative(root, attribution_path),
        "channel": _relative(root, channel_path), "oauth": _relative(root, oauth_path), "scopes": _relative(root, scope_path),
        "gold": _relative(root, gold_path), "negative": _relative(root, negative_path), "signal": _relative(root, signal_path),
        "contact": _relative(root, Path(visual_evidence["contact_sheet"])), "publicity": _relative(root, publicity_path),
        "overlay_ocr": str(overlay_ocr["audit_path"]),
        "asset_residency": input_integrity.get("asset_residency_receipt") or "asset-residency-unavailable",
    }
    gates = [
        _gate("STRATEGY", strategy_pass, "exact post-preproduction input receipt plus independently recomputed creative search, red-team and FormatPack decisions", {"integrity": True, "concept": "highest of at least three eligible among six alternatives", "score_and_summary_recomputed": True, "red_team": "PASS", "decision": "SELECT"}, {"inputs": input_integrity, "concept_integrity": concept_integrity, "creative_search": creative_search, "selected_concept": concept_selected, "decision": decision.get("decision")}, [evidence["input"], evidence["concept"], evidence["decision"]]),
        _gate("CHANNEL_DNA", dna_pass, "pinned channel identity, DNA version and evidence-scored eligible FormatPack", {"channel": CHANNEL_ID, "selection_score_min": 0.75}, {"channel": plan.get("channel_id"), "dna": decision.get("channel_dna_version"), "selected_pack_assessment": selected_pack_row}, [evidence["decision"], evidence["bible"], evidence["plan"]]),
        _gate("NARRATIVE", narrative_pass, "original long-form script structure and package-delivery contract", {"words_min": 300, "hook_windows": 4, "sections_min": 6, "delivery": "PASS"}, {"words": len(script_text.split()), "hook_windows": len(script.get("hook_windows") or []), "sections": len(script.get("sections") or []), "delivery": (brief.get("package") or {}).get("delivery_test")}, [evidence["script"], evidence["brief"]]),
        _gate("HOOK", hook_gate, "frame-locked 0–1/1–3/3–8/8–30 contract plus source/event diversity and sampled rendered-pixel OCR", {"windows": 4, "sources_min": 3, "events_min": 4, "voice_fit": True, "rendered_hook_overlay_ocr": "PASS"}, hook, [evidence["plan"], evidence["treatment"], evidence["media"], evidence["overlay_ocr"]]),
        _gate("SEMANTIC_COHERENCE", semantic_gate, "take-level narration/information/asset/retention traceability plus rendered overlay fidelity to TakePlan and Style Bible", {"coverage": 1.0, "functions_min": 4, "rendered_overlay_semantics": "PASS"}, semantic, [evidence["plan"], evidence["allocation"], evidence["bible"], evidence["overlay_ocr"]]),
        _gate("STYLE", style_pass, "locked FormatPack/StyleBible plus measured source diversity", {"pack": "fp-broll-cinematic-narration@1.1.0", "variety": True}, {"pack": f"{plan.get('format_pack_id')}@{plan.get('format_pack_version')}", "variety": variety}, [evidence["plan"], evidence["bible"], evidence["allocation"]]),
        _gate("CONTINUITY", timeline["passed"], "measured segment timeline, contiguity, source adjacency and frame drift", {"duration_error_ms_max": 150, "drift_frames_max": 0.5, "adjacent_repeat": 0}, timeline, [evidence["media"], evidence["plan"], evidence["signal"]]),
        _gate("CHARACTERS", all(item.get("character") is None for item in plan["takes"]), "explicit no-recurring-character contract for this clip-based release", {"recurring_character_count": 0}, {"declared_character_takes": sum(item.get("character") is not None for item in plan["takes"])}, [evidence["plan"], evidence["bible"]]),
        _gate("MOVEMENT", signal_pass, "full-duration FFmpeg signalstats plus black/freeze/transition scan", {"flicker_p95_max": 15, "black": 0, "freeze": 0, "hard_transition": 0}, {"signal": signal, "black_freeze": black_freeze}, [evidence["signal"], evidence["contact"], evidence["media"]]),
        _gate("LEGIBILITY", legibility_gate, "caption density, thumbnail contrast and sampled rendered-overlay OCR with measured safe-area boxes", {"caption_words_max": 12, "overlay_words_max": 8, "thumbnail_contrast_min": 22, "rendered_overlay_ocr": "PASS", "safe_area": "PASS"}, {"captions": captions, "thumbnails": thumb_measurements, "overlay_ocr": overlay_ocr["summary"], "base_passed": legibility_base_pass}, [evidence["captions"], evidence["thumbnails"], evidence["plan"], evidence["overlay_ocr"]]),
        _gate("AUDIO", audio_pass, "independent local ASR plus measured LUFS/true-peak/LRA", {"wer_max": 0.08, "lufs": [-17, -15], "true_peak_max": -1, "lra": [0.5, 8]}, {"asr": transcript, "loudness": loudness}, [evidence["video"], evidence["media"], evidence["captions"]]),
        _gate("TECHNICAL", technical["passed"], "independent ffprobe and frame-locked manifest reconciliation", {"codec": "h264/aac", "size": "1920x1080", "fps": 30}, technical, [evidence["video"], evidence["media"]]),
        _gate("RIGHTS", rights["passed"], "per-take license, immutable residency, current local hash and evidence reconciliation", {"unknown": 0, "hash_mismatch": 0, "evidence_missing": 0, "residency_bound": True}, rights, [evidence["allocation"], evidence["library"], evidence["attribution"], evidence["asset_residency"]]),
        _gate("PUBLICITY", publicity["passed"], "independent source-metadata institutional-risk screen plus local face detection for every allocated source range", {"screened_share": 1.0, "faces": 0, "metadata_risks": 0, "decode_failures": 0}, publicity, [evidence["library"], evidence["allocation"], evidence["publicity"]]),
        _gate("EDITORIAL_ORIGINALITY", originality["passed"], "target-to-human-reviewed-corpus trigram overlap", {"comparisons_min": 4, "overlap_max": 0.02}, originality, [evidence["script"], evidence["gold"]]),
        _gate("CHANNEL_IDENTITY", channel_measure["passed"] and dna_pass and style_pass, "exact owned channel, current readiness audit and pinned visual/narrative identity", {"channel_id": CHANNEL_ID, "handle": "@heroverse74", "readiness": "PASS"}, {"channel": channel_measure, "dna": dna_pass, "style": style_pass}, [evidence["channel"], evidence["bible"], evidence["decision"]]),
        _gate("COST", cost_measure["passed"], "zero-cost policy plus render and TakePlan ledgers", {"technical_cost_brl": 0, "external_cost": 0}, cost_measure, ["config/zero-cost-policy.json", evidence["media"], evidence["plan"]]),
        _gate("PUBLICATION", publication_prereq, "private-first prerequisite, exact OAuth scopes, channel readiness and no billing", {"channel": True, "oauth": True, "cost": 0, "staging": "private"}, {"channel": channel_measure, "oauth": oauth_measure, "cost": cost_measure, "staging": "private"}, [evidence["channel"], evidence["oauth"], evidence["scopes"], "config/zero-cost-policy.json"]),
    ]
    if [item["gate"] for item in gates] != GATES:
        raise AssertionError("Phase 6 quality gate order drifted from the permanent 18-gate contract")

    ffmpeg_only_geometry = all(item.get("tool_adapter_id") == "adapter-ffmpeg-local" for item in plan["takes"])
    unobserved = {"status": "UNOBSERVABLE_WITH_CURRENT_AUTOMATIC_EVIDENCE", "adapter_only_is_not_proof": True}
    defects = [
        _defect("FLICKER", signal_pass, "within-take luminance delta p95", 15, signal.get("within_take_luminance_delta_p95"), [evidence["signal"]]),
        _defect("OBJECT_DEFORMATION", None, "independent full-motion visual assessment required; adapter declaration is not evidence", "no deformation in the rendered frames", unobserved, [evidence["video"], evidence["contact"]]),
        _defect("FACE_VARIATION", None, "independent full-duration face-consistency assessment required", "no involuntary face variation", unobserved, [evidence["video"], evidence["publicity"]]),
        _defect("HAND_DEFECT", None, "independent full-motion anatomy assessment required", "no defective hands in rendered frames", unobserved, [evidence["video"], evidence["contact"]]),
        _defect("CHARACTER_IDENTITY_DRIFT", all(item.get("character") is None for item in plan["takes"]), "no-recurring-character scope", 0, sum(item.get("character") is not None for item in plan["takes"]), [evidence["plan"]]),
        _defect("BACKGROUND_PULSING", signal_pass, "within-take signal scan", 15, signal.get("within_take_luminance_delta_p95"), [evidence["signal"]]),
        _defect("IMPOSSIBLE_MOTION", None, "independent rendered-motion assessment required; source license and adapter do not prove motion", "no impossible motion", unobserved, [evidence["video"], evidence["contact"]]),
        _defect("UNINTENDED_CAMERA_INSTABILITY", None, "camera-motion or optical-flow measurement is not implemented for the full render", "no unintended instability", unobserved, [evidence["video"], evidence["signal"]]),
        _defect("INCOHERENT_PHYSICS", None, "independent rendered-motion physics assessment required", "physically coherent motion", unobserved, [evidence["video"], evidence["contact"]]),
        _defect("DISCONTINUOUS_CUT", timeline["passed"] and signal.get("hard_transition_count") == 0, "timeline and transition-aware hard-change scan", 0, signal.get("hard_transition_count"), [evidence["signal"], evidence["media"]]),
        _defect("LIP_SYNC_ERROR", all(item.get("character") is None for item in plan["takes"]), "voice-over release with no speaking on-screen character", 0, 0, [evidence["plan"], evidence["media"]]),
        _defect("DUPLICATE_FRAMES", black_freeze["freeze_event_count"] == 0, "FFmpeg freezedetect", 0, black_freeze["freeze_event_count"], [evidence["media"]]),
        _defect("GHOSTING", None, "full-frame temporal ghosting detector is not implemented; FPS and adapter labels are insufficient", "no ghosting", unobserved, [evidence["video"], evidence["media"]]),
        _defect("ARTIFICIAL_INTERPOLATION", None, "render-command/frame provenance must prove interpolation absence", "no artificial interpolation", {**unobserved, "ffmpeg_only_geometry_declared": ffmpeg_only_geometry}, [evidence["video"], evidence["media"]]),
        _defect("INCONSISTENT_RESOLUTION", technical["passed"], "single-output ffprobe contract", "1920x1080", f"{technical['width']}x{technical['height']}", [evidence["media"]]),
        _defect("COMPRESSION_ARTIFACT", None, "bitrate floor does not objectively exclude visible compression artifacts", "no visible compression artifact", {**unobserved, "bytes_per_second": round(video.stat().st_size / max(1, measured_ms / 1000), 3)}, [evidence["video"], evidence["media"]]),
        _defect("STYLE_DRIFT", None, "independent take-to-take visual comparison against the Style Bible required", "no involuntary style drift", {**unobserved, "style_contract_passed": style_pass}, [evidence["video"], evidence["contact"], evidence["bible"]]),
        _defect("AUDIO_CLIPPING", loudness["true_peak_dbtp"] <= -1, "FFmpeg loudnorm true-peak measurement", "<= -1 dBTP", loudness["true_peak_dbtp"], [evidence["video"]]),
        _defect("LOUDNESS_OUT_OF_RANGE", -17 <= loudness["integrated_lufs"] <= -15, "FFmpeg loudnorm integrated measurement", "-16 ±1 LUFS", loudness["integrated_lufs"], [evidence["video"]]),
    ]
    if [item["defect"] for item in defects] != DEFECTS:
        raise AssertionError("Phase 6 defect order drifted from the permanent 19-defect contract")

    if style_observations:
        defects[DEFECTS.index("STYLE_DRIFT")] = _defect("STYLE_DRIFT",
            False if any(row["status"] == "FAIL" for row in style_observations.values()) else None,
            "independent registered pixel counterevidence; component coverage cannot approve full style",
            {name: row["threshold"] for name, row in style_observations.items()},
            {"components": style_observations, "full_style_covered": False,
             "style_contract_passed": style_pass, "quality_authorized": False,
             "publication_authorized": False},
            [ref for row in style_observations.values() for ref in row["evidence_refs"]])

    all_pass = bool(all(item["status"] == "PASS" for item in gates) and all(item["status"] == "PASS" for item in defects) and calibration["gold_standard_pass"] and calibration["negative_control_detected"])
    blockers = [item["gate"] for item in gates if item["status"] != "PASS"] + [f"DEFECT:{item['defect']}" for item in defects if item["status"] != "PASS"]
    if not calibration["gold_standard_pass"]:
        blockers.append("GOLD_STANDARD_CALIBRATION")
    if not calibration["negative_control_detected"]:
        blockers.append("NEGATIVE_CONTROL_CALIBRATION")
    render_hash = _sha(video)
    selected = thumb_measurements["selected"]
    immutable_input = root / PRODUCTION_INPUT_RECEIPTS / f"{input_integrity['receipt_id']}.json"
    capacity_path = _resolve(root, str(verified["status"].get("capacity_preflight_receipt") or ""))
    residency_path = _resolve(root, str(input_integrity.get("asset_residency_receipt") or ""))
    binding_candidates = required_paths + [
        verified["manifest_path"], verified["voice_path"], video,
        immutable_input, capacity_path, residency_path, publicity_path,
        signal_path, Path(visual_evidence["contact_sheet"]),
        _resolve(root, str(overlay_ocr["audit_path"])),
    ]
    binding_candidates.extend(
        _resolve(root, str(item["frame_path"]))
        for item in overlay_ocr.get("frames") or []
        if item.get("frame_path")
    )
    binding_candidates.extend(
        _resolve(root, str(item["path"]))
        for item in (overlay_ocr.get("auditor") or {}).get("models") or []
    )
    binding_candidates.extend(_resolve(root, item["path"]) for item in thumbnails.get("candidates") or [])
    voice_manifest = _read(verified["voice_path"])
    binding_candidates.extend(Path(item["path"]) for item in voice_manifest.get("takes") or [])
    binding_paths: dict[str, Path] = {}
    for binding in style_bindings:
        path = _resolve(root, binding["path"])
        if not path.is_file() or _sha(path, prefixed=True) != binding["sha256"]:
            raise PermissionError("registered visual evidence changed during quality evaluation")
        binding_candidates.append(path)
        evidence["registered_visual_" + str(len(evidence))] = _relative(root, path)
    for path in binding_candidates:
        resolved = path.resolve()
        if resolved.is_file():
            binding_paths[_relative(root, resolved)] = resolved
    evidence_bindings = [
        {"path": name, "sha256": _sha(path, prefixed=True), "size_bytes": path.stat().st_size}
        for name, path in sorted(binding_paths.items())
    ]
    hard_failure = bool(
        any(item["status"] in {"FAIL", "BLOCKED"} for item in gates + defects)
        or not calibration["gold_standard_pass"] or not calibration["negative_control_detected"]
    )
    needs_review = any(item["status"] == "NEEDS_REVIEW" for item in gates + defects)
    decision = "PASS_LIMITED_RELEASE" if all_pass else ("FAIL" if hard_failure else "NEEDS_REVIEW" if needs_review else "BLOCKED")
    result = {
        "schema_version": "1.0.0", "evaluation_id": "phase6-quality-pending",
        "video_id": VIDEO_ID, "channel_id": CHANNEL_ID, "quality_profile": "STANDARD",
        "evaluator": {"evaluator_id": "heroverse-phase6-independent-quality-assessor", "version": EVALUATOR_VERSION, "separate_from_generator": True, "human_reviewer_claimed": False, "methods": ["frozen-artifact-hash", "ffprobe-contract", "ffmpeg-loudness", "ffmpeg-black-freeze", "ffmpeg-signalstats", "faster-whisper-local-asr", "take-semantic-traceability", "rapidocr-pinned-rendered-overlay-audit", "rights-and-source-hash-reconciliation", "local-face-and-institutional-metadata-publicity-screen", "corpus-originality-scan", "thumbnail-contrast-and-exact-versioned-editorial-review", "negative-control-regression"]},
        "artifact": {"path": _relative(root, video), "sha256": render_hash, "size_bytes": video.stat().st_size, "duration_ms": measured_ms, "hash_verified": _sha(video, prefixed=True) == manifest["output"]["content_hash"]},
        "calibration": calibration,
        "measurements": {"asr": transcript, "captions": captions, "technical": technical, "loudness": loudness, "black_freeze": black_freeze, "visual_signal": signal, "timeline": timeline, "hook": hook, "overlay_ocr": overlay_ocr, "rights": rights, "publicity": publicity, "originality": originality, "semantic_traceability": semantic, "visual_variety": variety, "thumbnails": thumb_measurements, "channel_readiness": channel_measure, "oauth": oauth_measure, "zero_cost": cost_measure},
        "gates": gates, "defect_evaluations": defects,
        "thumbnail_selection": {"candidate_id": selected["candidate_id"], "path": selected["path"], "sha256": selected["sha256"], "title": selected["title"], "score": selected["score"], "all_candidates_pass": thumb_measurements["all_candidates_pass"], "selected": bool(selected["passed"])},
        "audit_policy": {"per_release_automatic_review": True, "routine_human_sample_rate": 0.10, "mandatory_exception_triggers": ["critical automatic uncertainty or failure", "new FormatPack, pipeline, voice or tool version", "rights or publicity ambiguity", "post-publication complaint or anomaly", "three-video LIMITED checkpoint"], "evidence_binding_version": "phase6-quality-evidence-v3", "evidence_bindings": evidence_bindings, "decision_recomputation_required": True, "unobservable_defects_fail_closed": True},
        "decision": decision, "publication_eligible": all_pass,
        "blockers": sorted(set(blockers)), "evidence_refs": list(dict.fromkeys(evidence.values())),
        "claim_boundary": ["PASS proves the measurable release contract for this frozen artifact; it does not guarantee virality, monetization, CTR, retention, views or YPP approval.", "The independent automatic assessor is not represented as a human reviewer; the human gold standard calibrates structure and exception sampling.", "Publication still requires a separate immutable release receipt, fresh live channel/OAuth/quota checks and private-first post-upload verification."],
        "technical_cost_brl": 0, "created_at": created_at or _stamp(),
    }
    result["evaluation_id"] = _evaluation_identity(result)
    _validate(root, "phase6_quality_evaluation.schema.json", result)
    return result


def materialize_phase6_quality(
    root: Path = ROOT,
    *,
    asr_result: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> Path:
    root = root.resolve()
    target = root / REPORT
    if asr_result is None and target.is_file():
        try:
            prior = _read(target)
            _validate(root, "phase6_quality_evaluation.schema.json", prior)
            immutable = root / QUALITY_EVALUATIONS / f"{prior['evaluation_id']}.json"
            media, _ = _verified_media(root)
            if (
                media
                and prior.get("evaluation_id") == _evaluation_identity(prior)
                and immutable.is_file()
                and immutable.read_bytes() == target.read_bytes()
                and prior.get("artifact", {}).get("sha256") == _sha(media["video"])
            ):
                asr_result = prior.get("measurements", {}).get("asr")
        except Exception:
            asr_result = None
    report = build_phase6_quality_evaluation(root, asr_result=asr_result, created_at=created_at)
    immutable = root / QUALITY_EVALUATIONS / f"{report['evaluation_id']}.json"
    if immutable.is_file():
        prior = _read(immutable)
        prior_semantic, report_semantic = dict(prior), dict(report)
        prior_semantic.pop("created_at", None)
        report_semantic.pop("created_at", None)
        if prior_semantic != report_semantic:
            raise PermissionError(f"immutable quality evaluation collision: {report['evaluation_id']}")
        report = prior
    else:
        report = _write_immutable(immutable, report)
    _write(target, report)
    verify_phase6_quality_evaluation(root, report_path=immutable, expected_evaluation_id=report["evaluation_id"])
    return immutable


def _post_application_retry_wait(root: Path, *, current: datetime) -> dict[str, Any] | None:
    """Consume the transaction-owned WAIT before reopening media or writing queue.

    As with the media executor's restart hold, D116 releases only to the normal
    verifier/QA path, never to a quality PASS or publication permission. The
    preserved retry job and immutable manifest are rechecked on every cycle.
    """
    path = root / RUNTIME
    if not path.is_file():
        return None
    prior = _read(path)
    if not str(prior.get("next_action", "")).startswith("CONTROLLED_QUALITY_REEVALUATION_PENDING:"):
        return None
    from .maintenance_protocol import _quality_retry_wait_candidate
    held, _ = _quality_retry_wait_candidate(root, observed=current, allow_held=True)
    if held is None:
        raise PermissionError("quality post-application hold contract differs")
    try:
        d116 = _read(root / "output/operations/phase6/post-maintenance-verification/latest.json")
        cycle = _read(root / "output/operations/phase6/control-cycle/latest.json")
        verified = datetime.fromisoformat(str(d116["verified_at"]).replace("Z", "+00:00"))
        previous = datetime.fromisoformat(str(prior["updated_at"]).replace("Z", "+00:00"))
        released = (
            d116.get("status") == "PASS"
            and (d116.get("runtime") or {}).get("manager_pid") == os.getpid()
            and bool(cycle.get("cycle_id"))
            and (d116.get("control_cycle") or {}).get("cycle_id") == cycle["cycle_id"]
            and previous < verified <= current
        )
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        released = False
    return None if released else held


def evaluate_phase6_visual_word_evidence(root: Path, *, receipt_path: str | Path,
                                        expected_sha256: str, expected_video_sha256: str) -> dict[str, Any]:
    """A verified one-sided style counterexample; never a full visual PASS.

    Both actual source glyph identity and final-video pixel extent are needed
    for an automatic negative. The rest of style/anatomy stays unproved. This
    cheap reader does not repeat the historical QA or mutate its verdict.
    """
    from .phase6_visual_typography import revalidate_owned_word_extents
    root = root.resolve()
    raw = _resolve(root, str(receipt_path)).read_bytes()
    if 'sha256:' + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError('visual word evidence receipt anchor differs')
    historical = json.loads(raw)
    reference = read_phase6_visual_reference(root, historical['reference']['path'],
        expected_sha256=historical['reference']['sha256'])
    storage, _ = _visual_reference_intent_storage(root, reference)
    # Only this invocation owns these freshly authenticated exact-byte reads.
    # Keep the qualified pixel instrument and its source-audit pins untouched.
    # No caller-supplied PASS/map, process-global cache or rewritten reference.
    token = _VISUAL_INTENT_READ_SCOPE.set((root, storage))
    try:
        revalidation = revalidate_owned_word_extents(root, receipt_path=receipt_path, expected_sha256=expected_sha256)
    finally:
        _VISUAL_INTENT_READ_SCOPE.reset(token)
    value = revalidation["measurement"]
    reference = read_phase6_visual_reference(root, value["reference"]["path"],
        expected_sha256=value["reference"]["sha256"])
    if reference["target"]["sha256"] != expected_video_sha256:
        raise PermissionError("visual word evidence belongs to a different frozen video")
    counterexamples = [row for row in value["measurements"]
        if row["result"]["extent_counterexample"]
        and row["source_glyph"].get("source_glyph_pixels_match") is True
        and type(row["source_glyph"].get("identified_source_em_px")) is int
        and row["source_glyph"]["identified_source_em_px"] < value["bible_minimum_em_px"]]
    return _defect("STYLE_DRIFT", False if counterexamples else None,
        "authenticated canonical glyph pixels plus final-frame word extent; one-sided counterexample only",
        {"minimum_em_px": value["bible_minimum_em_px"], "origin": "authenticated Style Bible",
         "tolerance": "exact source glyph; final enclosure below every allowed minimum-size glyph"},
        {"source_confirmed_counterexamples": len(counterexamples), "counterexamples": counterexamples,
         "unobservable_count": len(value["unobservable"]), "full_style_covered": False,
         "current_revalidation": {k: v for k, v in revalidation.items() if k != "measurement"},
         "quality_authorized": False, "publication_authorized": False},
        [f"{receipt_path}#{expected_sha256}"])


def evaluate_phase6_visual_palette_evidence(root: Path, *, receipt_path: str | Path,
                                           expected_sha256: str, expected_video_sha256: str) -> dict[str, Any]:
    value = read_phase6_clocked_palette_population(root, receipt_path=receipt_path,
                                                  expected_sha256=expected_sha256)
    if value['video']['sha256'] != expected_video_sha256:
        raise PermissionError('visual palette evidence belongs to a different frozen video')
    counterexamples = [row for row in value['rows'] if row['measurement']['status'] == 'FAIL_COMPONENT']
    return _defect('STYLE_DRIFT', False if counterexamples else None,
        'source-composed native RGB reference versus exact clock-qualified video pixels',
        {'origin': 'authenticated Style Bible palette and divergence_policy',
         'tolerance': 'per-pixel DeltaE from the bound Bible; never fitted to output'},
        {'counterexamples': counterexamples, 'current_revalidation': value,
         'full_style_covered': False, 'quality_authorized': False, 'publication_authorized': False},
        [f'{receipt_path}#{expected_sha256}'])


def run_phase6_quality_executor(root: Path = ROOT, *, now: datetime | None = None,
                               visual_word_evidence: dict[str, str] | None = None) -> dict[str, Any]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    timestamp = _stamp(current)
    held = _post_application_retry_wait(root, current=current)
    if held is not None:
        _validate(root, "phase6_quality_executor_runtime.schema.json", held)
        _write(root / RUNTIME, held)
        return held
    media, wait_reason = _verified_media(root)
    status, decision, job_state = "WAITING", "WAIT", "NOT_CREATED"
    render_id = media["manifest"]["render_id"] if media else None
    job_id: str | None = None
    evaluation_path: str | None = None
    publication_eligible = False
    error: str | None = None
    next_action = wait_reason or "Wait for a complete, frozen Phase 6 render."
    word_decision = None
    palette_decision = None
    palette_binding = None
    if media is not None:
        palette_binding = REGISTERED_VISUAL_PALETTE_EVIDENCE.get(media['manifest']['output']['content_hash'])
        if palette_binding is not None:
            palette_decision = evaluate_phase6_visual_palette_evidence(root,
                receipt_path=palette_binding['path'], expected_sha256=palette_binding['sha256'],
                expected_video_sha256=media['manifest']['output']['content_hash'])
        registered = REGISTERED_VISUAL_WORD_EVIDENCE.get(media["manifest"]["output"]["content_hash"])
        if registered is not None:
            # The normal manager entry has no explicit evidence argument. It
            # must not ignore a known counterexample or let an optional caller
            # hide it by supplying weaker evidence for the same frozen video.
            if visual_word_evidence is not None and (
                not isinstance(visual_word_evidence, dict)
                or set(visual_word_evidence) != {"path", "sha256"}
                or visual_word_evidence["sha256"] != registered["sha256"]
                or _resolve(root, str(visual_word_evidence["path"])) != _resolve(root, registered["path"])
            ):
                raise PermissionError("explicit evidence cannot replace registered frozen-video counterevidence")
            visual_word_evidence = dict(registered)
    if media is not None and visual_word_evidence is not None:
        if set(visual_word_evidence) != {"path", "sha256"}:
            raise PermissionError("visual word evidence requires only path and external hash")
        word_decision = evaluate_phase6_visual_word_evidence(root,
            receipt_path=visual_word_evidence["path"], expected_sha256=visual_word_evidence["sha256"],
            expected_video_sha256=media["manifest"]["output"]["content_hash"])
    if word_decision is not None and word_decision["status"] == "FAIL":
        status, decision = "BLOCKED", "FAIL"
        next_action = "REMEDIATE_CANONICAL_WORD_EXTENT:" + str(visual_word_evidence["path"]) + "#" + visual_word_evidence["sha256"]
    elif palette_decision is not None and palette_decision['status'] == 'FAIL':
        status, decision = 'BLOCKED', 'FAIL'
        next_action = 'REMEDIATE_CANONICAL_PALETTE:' + palette_binding['path'] + '#' + palette_binding['sha256']
    elif media is not None and UNIMPLEMENTED_VISUAL_MEASUREMENTS:
        status, decision = "BLOCKED", "NEEDS_REVIEW"
        next_action = "UNIMPLEMENTED_VISUAL_MEASUREMENTS:" + ",".join(UNIMPLEMENTED_VISUAL_MEASUREMENTS)
    elif media is not None:
        queue = TransactionalQueue(root)
        # A terminal evaluation belongs to its evaluator contract, not merely
        # to the video. Never reset/relabel an older job or borrow its PASS.
        contract = {"evaluator_version": EVALUATOR_VERSION,
                    "package_fidelity_review_sha256": PACKAGE_FIDELITY_REVIEW_SHA256}
        key = f"{render_id}:{media['manifest']['output']['content_hash']}:independent-quality-{EVALUATOR_VERSION}:{PACKAGE_FIDELITY_REVIEW_SHA256}"
        prior_jobs = queue.snapshot(captured_at=current)["jobs"]
        if any(job.get("task_type") == "EVALUATE_PHASE6_VIDEO2_QUALITY"
               and job.get("payload", {}).get("render_id") == render_id
               and job.get("idempotency_key") != key
               and (job.get("state") != "SUCCEEDED" or job.get("lease_owner") is not None
                    or job.get("lease_until") is not None)
               for job in prior_jobs):
            raise PermissionError("previous quality contract is not terminal; preserve its job before a successor")
        job = queue.enqueue(idempotency_key=key, operation_id="heroverse-phase6-controlled-longform-v1", channel_id=CHANNEL_ID, task_type="EVALUATE_PHASE6_VIDEO2_QUALITY", payload={"render_id": render_id, "render_hash": media["manifest"]["output"]["content_hash"], "evaluator_contract": contract}, max_attempts=3, now=current)
        job_id, job_state = job["job_id"], job["state"]
        if job_state == "SUCCEEDED":
            checkpoint = job.get("checkpoint") or {}
            evaluation_path = checkpoint.get("evaluation")
            try:
                report = verify_phase6_quality_evaluation(
                    root,
                    report_path=str(evaluation_path or ""),
                    expected_evaluation_id=checkpoint.get("evaluation_id"),
                )
                evaluation_file = _resolve(root, str(evaluation_path))
                if checkpoint.get("evaluation_sha256") != _sha(evaluation_file, prefixed=True):
                    raise PermissionError("quality queue checkpoint hash differs from its immutable evaluation")
                decision = report["decision"]
                publication_eligible = bool(report["publication_eligible"])
                status = "COMPLETED"
                next_action = checkpoint.get("next_action", "BUILD_PHASE6_RELEASE_GATE" if publication_eligible else "REMEDIATE_PHASE6_VIDEO2")
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                status, decision, publication_eligible = "BLOCKED", "BLOCKED", False
                next_action = "Repair or rebuild the immutable quality evaluation; do not release mutable evidence."
        else:
            claimed = queue.claim_job(job_id, worker_id=f"gestor-central-quality-{os.getpid()}", expected_task_type="EVALUATE_PHASE6_VIDEO2_QUALITY", lease_seconds=3600, now=current)
            if claimed is None:
                status = "RETRY_WAIT" if job_state == "RETRY_WAIT" else "WAITING"
                next_action = "Quality job is already leased or inside its bounded retry window."
            elif claimed["job_id"] != job_id:
                error = f"PHASE6_QUALITY_QUEUE_IDENTITY_MISMATCH:{claimed['job_id']}"
                queue.fail(claimed["job_id"], worker_id=claimed["lease_owner"], error=error, now=current)
                status, decision = "ERROR", "BLOCKED"
                next_action = "Preserve the mismatched job and retry only through its idempotency key."
            else:
                try:
                    path = materialize_phase6_quality(root, created_at=timestamp)
                    report = verify_phase6_quality_evaluation(root, report_path=path)
                    evaluation_path = _relative(root, path)
                    decision = report["decision"]
                    publication_eligible = bool(report["publication_eligible"])
                    next_action = "BUILD_PHASE6_RELEASE_GATE" if publication_eligible else "REMEDIATE_PHASE6_VIDEO2"
                    finished = queue.succeed(job_id, worker_id=claimed["lease_owner"], checkpoint={"evaluation": evaluation_path, "evaluation_id": report["evaluation_id"], "evaluation_sha256": _sha(path, prefixed=True), "decision": decision, "publication_eligible": publication_eligible, "next_action": next_action}, now=datetime.now(timezone.utc))
                    job_state, status = finished["state"], "COMPLETED"
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    failed = queue.fail(job_id, worker_id=claimed["lease_owner"], error=error, checkpoint=claimed.get("checkpoint") or {}, now=datetime.now(timezone.utc))
                    job_state = failed["state"]
                    status = "BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT"
                    decision = "BLOCKED"
                    next_action = "Correct the evidenced quality-evaluation failure and retry without relaxing a critical gate."
            queue.materialize_snapshot(captured_at=datetime.now(timezone.utc))
    value = {
        "schema_version": "1.0.0", "executor_id": "heroverse-phase6-quality-executor-v1", "phase": 6,
        "status": status, "media_render_id": render_id, "job_id": job_id, "job_state": job_state,
        "evaluation": evaluation_path, "decision": decision, "publication_eligible": publication_eligible,
        "next_action": next_action, "error": error, "technical_cost_brl": 0, "updated_at": timestamp,
    }
    _validate(root, "phase6_quality_executor_runtime.schema.json", value)
    _write(root / RUNTIME, value)
    return value


if __name__ == "__main__":
    print(json.dumps(run_phase6_quality_executor(ROOT), ensure_ascii=False, indent=2))
