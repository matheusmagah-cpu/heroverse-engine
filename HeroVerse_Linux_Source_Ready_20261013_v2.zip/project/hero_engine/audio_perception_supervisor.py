"""Bounded Windows execution of the frozen DNSMOS measurement adapter.

This is process containment and evidence recovery, NOT an audio/release gate.
Windows Job Objects impose a committed-memory ceiling, not a resident-RAM SLA.
References: https://learn.microsoft.com/windows/win32/procthread/job-objects
No worker starts before assignment to a kill-on-close, non-breakaway job.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes as w
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

VERSION = "audio-perception-supervisor-windows-v2"
CONTAINMENT_JOB_ENV = "HEROVERSE_AUDIO_CONTAINMENT_JOB"
CONTAINMENT_JOB_PREFIX = "Local\\HeroVerseAudio-"
FROZEN_RUNNER_SHA = "29a10ffdb93f817d0ddc71cf85608f1a6dc31a2787ecc07909d9622f511bd029"
MEASUREMENT_SCHEMA_SHA = "d3ad542deec619ab04cf2c98d3ae686d92b694738fdd41f1530318a583a61ff1"
ROOT = Path(__file__).absolute().parent.parent
MAX_RECEIPT_BYTES = 2 * 1024 * 1024


def _adapter():
    path = ROOT / "hero_engine/audio_perception.py"
    if hashlib.sha256(path.read_bytes()).hexdigest() != FROZEN_RUNNER_SHA:
        raise ValueError("frozen measurement adapter changed")
    from hero_engine import audio_perception
    audio_perception.read_pinned(path, FROZEN_RUNNER_SHA)
    return audio_perception


def _utc():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _positive(value, name, upper):
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 < value <= upper:
        raise ValueError(f"invalid {name}")
    return float(value)


def verify_cached(receipt: Path, receipt_sha: str, source_sha: str,
                  *, source: Path | None = None, ffmpeg_sha: str | None = None,
                  bundle: Path | None = None) -> dict:
    """Validate external identity, schema and frozen replay; never start inference."""
    adapter = _adapter()
    receipt = adapter.resident(receipt)
    if receipt.stat().st_size > MAX_RECEIPT_BYTES:
        raise ValueError("oversized measurement receipt")
    raw = adapter.read_pinned(receipt, receipt_sha)
    value = json.loads(raw)
    import jsonschema
    schema = json.loads(adapter.read_pinned(ROOT / "schemas/audio_perception.schema.json",
                                           MEASUREMENT_SCHEMA_SHA))
    jsonschema.Draft202012Validator(schema).validate(value)
    if source is not None and Path(value["source"]["path"]).absolute() != source.absolute():
        raise ValueError("cache belongs to a different source path")
    if ffmpeg_sha is not None and value["ffmpeg"]["sha256"] != ffmpeg_sha:
        raise ValueError("cache belongs to a different FFmpeg version")
    if bundle is not None and Path(value["artifacts"][0]["path"]).parent != bundle.absolute():
        raise ValueError("cache belongs to a different model bundle")
    replay = adapter.replay(receipt, receipt_sha, FROZEN_RUNNER_SHA, source_sha)
    return {"version": VERSION, "status": "CACHED_MEASUREMENT_VERIFIED",
            "receipt": {"path": str(receipt), "sha256": receipt_sha},
            "replay": replay, "new_inference_calls": 0, "worker_started": False,
            "release_authority": False, "audio_approved": False}


class _BasicLimits(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64), ("LimitFlags", w.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", w.DWORD), ("Affinity", ctypes.c_size_t),
                ("PriorityClass", w.DWORD), ("SchedulingClass", w.DWORD)]


class _IOCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
        "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _BasicLimits), ("IoInfo", _IOCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


class _Accounting(ctypes.Structure):
    _fields_ = [("TotalUserTime", ctypes.c_int64), ("TotalKernelTime", ctypes.c_int64),
                ("ThisPeriodTotalUserTime", ctypes.c_int64),
                ("ThisPeriodTotalKernelTime", ctypes.c_int64),
                ("TotalPageFaultCount", w.DWORD), ("TotalProcesses", w.DWORD),
                ("ActiveProcesses", w.DWORD), ("TotalTerminatedProcesses", w.DWORD)]


class _Startup(ctypes.Structure):
    _fields_ = [("cb", w.DWORD), ("lpReserved", w.LPWSTR), ("lpDesktop", w.LPWSTR),
                ("lpTitle", w.LPWSTR), *[(name, w.DWORD) for name in
                ("dwX", "dwY", "dwXSize", "dwYSize", "dwXCountChars", "dwYCountChars",
                 "dwFillAttribute", "dwFlags")],
                ("wShowWindow", w.WORD), ("cbReserved2", w.WORD),
                ("lpReserved2", ctypes.c_void_p), ("hStdInput", w.HANDLE),
                ("hStdOutput", w.HANDLE), ("hStdError", w.HANDLE)]


class _StartupEx(ctypes.Structure):
    _fields_ = [("StartupInfo", _Startup), ("lpAttributeList", ctypes.c_void_p)]


class _ProcessInfo(ctypes.Structure):
    _fields_ = [("hProcess", w.HANDLE), ("hThread", w.HANDLE),
                ("dwProcessId", w.DWORD), ("dwThreadId", w.DWORD)]


def _kernel():
    if os.name != "nt":
        raise RuntimeError("UNSUPPORTED_PLATFORM: Windows Job Object required; no unbounded fallback")
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    signatures = {
        "GetCurrentProcess": ([], w.HANDLE),
        "IsProcessInJob": ([w.HANDLE, w.HANDLE, ctypes.POINTER(w.BOOL)], w.BOOL),
        "CreateJobObjectW": ([ctypes.c_void_p, w.LPCWSTR], w.HANDLE),
        "OpenJobObjectW": ([w.DWORD, w.BOOL, w.LPCWSTR], w.HANDLE),
        "SetInformationJobObject": ([w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD], w.BOOL),
        "QueryInformationJobObject": ([w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD, ctypes.c_void_p], w.BOOL),
        "AssignProcessToJobObject": ([w.HANDLE, w.HANDLE], w.BOOL),
        "TerminateJobObject": ([w.HANDLE, w.UINT], w.BOOL),
        "TerminateProcess": ([w.HANDLE, w.UINT], w.BOOL),
        "ResumeThread": ([w.HANDLE], w.DWORD),
        "WaitForSingleObject": ([w.HANDLE, w.DWORD], w.DWORD),
        "GetExitCodeProcess": ([w.HANDLE, ctypes.POINTER(w.DWORD)], w.BOOL),
        "CloseHandle": ([w.HANDLE], w.BOOL),
        "InitializeProcThreadAttributeList": ([ctypes.c_void_p, w.DWORD, w.DWORD, ctypes.POINTER(ctypes.c_size_t)], w.BOOL),
        "UpdateProcThreadAttribute": ([ctypes.c_void_p, w.DWORD, ctypes.c_size_t, ctypes.c_void_p,
                                       ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p], w.BOOL),
        "DeleteProcThreadAttributeList": ([ctypes.c_void_p], None),
        "CreateProcessW": ([w.LPCWSTR, w.LPWSTR, ctypes.c_void_p, ctypes.c_void_p,
                            w.BOOL, w.DWORD, ctypes.c_void_p, w.LPCWSTR,
                            ctypes.POINTER(_StartupEx), ctypes.POINTER(_ProcessInfo)], w.BOOL),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(k, name)
        function.argtypes, function.restype = arguments, result
    return k


def _check(value):
    if not value:
        raise ctypes.WinError(ctypes.get_last_error())
    return value


def run_bounded(argv: list[str], *, cwd: Path, logs: Path, timeout_seconds=180,
                memory_bytes=2 * 1024 ** 3, max_log_bytes=1024 ** 2) -> dict:
    """Run a trusted local diagnostic command; contain its CreateProcess tree.

    No shell, WMI, breakaway permission, login, network job or manager process.
    Log-size polling is a diagnostic cap with overshoot, not a disk hard quota.
    Callers must not pass credentials in argv. API failures are fatal, not PASS.
    """
    timeout = _positive(timeout_seconds, "timeout", 600)
    if type(memory_bytes) is not int or not 64 * 1024 ** 2 <= memory_bytes <= 4 * 1024 ** 3:
        raise ValueError("committed-memory ceiling must be 64 MiB through 4 GiB")
    if type(max_log_bytes) is not int or not 1024 <= max_log_bytes <= 10 * 1024 ** 2:
        raise ValueError("invalid diagnostic log ceiling")
    if not argv or any(type(x) is not str or "\0" in x for x in argv):
        raise ValueError("explicit argument vector required")
    adapter = _adapter()
    executable = adapter.resident(Path(argv[0]))
    if not executable.is_file() or not executable.is_absolute():
        raise ValueError("absolute executable required")
    cwd = adapter.resident(cwd)
    adapter.resident(logs, must_exist=False)
    logs.mkdir(parents=True, exist_ok=False)
    adapter.resident(logs)
    k = _kernel()
    import msvcrt
    job, pi, attributes = None, _ProcessInfo(), None
    job_name = CONTAINMENT_JOB_PREFIX + uuid.uuid4().hex
    job_created_new = False
    limits_configured = False
    assigned = False
    started = time.monotonic()
    start_utc = _utc()
    status, error_code, exit_code = "SUPERVISOR_ERROR", None, None
    peak_commit, processes, remaining = 0, 0, None
    handles = []
    try:
        ctypes.set_last_error(0)
        job = _check(k.CreateJobObjectW(None, job_name))
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS: never reuse a foreign job.
            raise RuntimeError("exclusive containment Job Object already exists")
        job_created_new = True
        limits = _ExtendedLimits()
        # KILL_ON_JOB_CLOSE | PROCESS_MEMORY | JOB_MEMORY. No BREAKAWAY flags.
        limits.BasicLimitInformation.LimitFlags = 0x2000 | 0x100 | 0x200
        limits.ProcessMemoryLimit = limits.JobMemoryLimit = memory_bytes
        _check(k.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
        limits_configured = True
        with open(os.devnull, "rb") as stdin, (logs / "stdout.log").open("xb") as stdout, (logs / "stderr.log").open("xb") as stderr:
            handles = [msvcrt.get_osfhandle(f.fileno()) for f in (stdin, stdout, stderr)]
            size = ctypes.c_size_t()
            k.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
            if not size.value:
                raise RuntimeError("attribute-list allocation unavailable")
            attributes = ctypes.create_string_buffer(size.value)
            _check(k.InitializeProcThreadAttributeList(attributes, 1, 0, ctypes.byref(size)))
            inherited = (w.HANDLE * 3)(*handles)
            _check(k.UpdateProcThreadAttribute(attributes, 0, 0x20002, inherited,
                                                ctypes.sizeof(inherited), None, None))
            startup = _StartupEx()
            startup.StartupInfo.cb = ctypes.sizeof(startup)
            startup.StartupInfo.dwFlags = 0x100 | 0x1  # standard handles; SW_HIDE
            startup.StartupInfo.wShowWindow = 0
            startup.StartupInfo.hStdInput, startup.StartupInfo.hStdOutput, startup.StartupInfo.hStdError = handles
            startup.lpAttributeList = ctypes.cast(attributes, ctypes.c_void_p)
            for handle in handles:
                os.set_handle_inheritable(handle, True)
            try:
                command = ctypes.create_unicode_buffer(subprocess.list2cmdline(argv))
                # Use an explicit environment block, not process-global mutation.
                # A launcher may add its own nested job; descendants retain the
                # identity of OUR job and verify membership plus its exact limits.
                child_environment = {
                    key: value for key, value in os.environ.items()
                    if key.casefold() != CONTAINMENT_JOB_ENV.casefold()
                }
                child_environment[CONTAINMENT_JOB_ENV] = job_name
                environment = ctypes.create_unicode_buffer("\0".join(
                    key + "=" + child_environment[key]
                    for key in sorted(child_environment, key=str.casefold)
                ) + "\0\0")
                # CREATE_SUSPENDED | CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT
                # | CREATE_UNICODE_ENVIRONMENT. Only the three std handles inherit.
                _check(k.CreateProcessW(str(executable), command, None, None, True,
                                        0x4 | 0x08000000 | 0x80000 | 0x400,
                                        ctypes.cast(environment, ctypes.c_void_p), str(cwd),
                                        ctypes.byref(startup), ctypes.byref(pi)))
            finally:
                for handle in handles:
                    os.set_handle_inheritable(handle, False)
            _check(k.AssignProcessToJobObject(job, pi.hProcess))
            assigned = True
            if k.ResumeThread(pi.hThread) == 0xFFFFFFFF:
                raise ctypes.WinError(ctypes.get_last_error())
            while True:
                accounting = _Accounting()
                _check(k.QueryInformationJobObject(job, 1, ctypes.byref(accounting),
                                                   ctypes.sizeof(accounting), None))
                processes = int(accounting.TotalProcesses)
                remaining = int(accounting.ActiveProcesses)
                if sum(p.stat().st_size for p in (logs / "stdout.log", logs / "stderr.log")) > max_log_bytes:
                    status = "OUTPUT_LIMIT_EXCEEDED"
                    break
                if remaining == 0:
                    code = w.DWORD()
                    _check(k.GetExitCodeProcess(pi.hProcess, ctypes.byref(code)))
                    exit_code = int(code.value)
                    status = "SUCCEEDED" if exit_code == 0 else "CHILD_FAILED"
                    break
                if time.monotonic() - started >= timeout:
                    status = "TIMED_OUT"
                    break
                time.sleep(min(.025, max(.001, timeout - (time.monotonic() - started))))
            measured = _ExtendedLimits()
            _check(k.QueryInformationJobObject(job, 9, ctypes.byref(measured), ctypes.sizeof(measured), None))
            peak_commit = int(measured.PeakJobMemoryUsed)
    except Exception as exc:
        status = "SUPERVISOR_ERROR"
        error_code = {"type": type(exc).__name__, "winerror": getattr(exc, "winerror", None)}
    finally:
        if pi.hProcess:
            try:
                if assigned:
                    _check(k.TerminateJobObject(job, 0xD164))
                    deadline = time.monotonic() + 5
                    while True:
                        accounting = _Accounting()
                        _check(k.QueryInformationJobObject(job, 1, ctypes.byref(accounting), ctypes.sizeof(accounting), None))
                        remaining = int(accounting.ActiveProcesses)
                        if remaining == 0:
                            break
                        if time.monotonic() >= deadline:
                            raise RuntimeError("job termination could not be verified")
                        time.sleep(.01)
                else:
                    # Only our exact suspended child; never a PID guessed from runtime state.
                    _check(k.TerminateProcess(pi.hProcess, 0xD164))
                if k.WaitForSingleObject(pi.hProcess, 5000) != 0:
                    raise RuntimeError("child termination could not be verified")
            except Exception as exc:
                status = "TERMINATION_UNVERIFIED"
                error_code = {"type": type(exc).__name__, "winerror": getattr(exc, "winerror", None)}
        if attributes is not None:
            k.DeleteProcThreadAttributeList(attributes)
        for handle in (pi.hThread, pi.hProcess, job):
            if handle and not k.CloseHandle(handle):
                status = "HANDLE_CLOSE_FAILED"
                error_code = {"type": "WinError", "winerror": ctypes.get_last_error()}
    result = {"version": VERSION, "status": status, "started_at": start_utc,
              "finished_at": _utc(), "duration_seconds": round(time.monotonic() - started, 6),
              "timeout_seconds": timeout, "committed_memory_limit_bytes": memory_bytes,
              "peak_job_commit_bytes": peak_commit, "memory_limit_kind": "WINDOWS_JOB_COMMITTED_MEMORY",
              "process_count_observed": processes, "remaining_processes_verified": remaining,
              "child_pid": int(pi.dwProcessId) or None, "exit_code": exit_code,
              "error": error_code, "kill_on_close": limits_configured, "assigned_before_resume": assigned,
              "containment_job_name": job_name, "containment_job_created_new": job_created_new,
              "worker_job_binding": "EXPLICIT_NAMED_JOB_MEMBERSHIP_AND_LIMITS",
              "log_size_polling_cap_bytes": max_log_bytes, "release_authority": False,
              "audio_approved": False, "logs": []}
    for name in ("stdout.log", "stderr.log"):
        path = logs / name
        if path.exists():
            digest = hashlib.sha256()
            length = 0
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 ** 2), b""):
                    digest.update(chunk)
                    length += len(chunk)
            result["logs"].append({"path": str(path.absolute()), "size": length, "sha256": digest.hexdigest()})
    adapter.immutable_write(logs / "process-receipt.json", adapter.canonical(result))
    return result


def _commit_new(source: Path, destination: Path) -> None:
    """Windows rename is atomic and refuses replacement. Preserve interrupted attempts."""
    if os.name != "nt":
        raise RuntimeError("Windows non-replacing rename required")
    adapter = _adapter()
    adapter.resident(source)
    adapter.resident(destination, must_exist=False)
    destination.parent.mkdir(parents=True, exist_ok=True)
    adapter.resident(destination.parent)
    if destination.exists():
        raise ValueError("destination evidence already exists; require externally pinned replay")
    temporary = destination.parent / ("." + destination.name + "." + uuid.uuid4().hex + ".complete")
    raw = source.read_bytes()
    with temporary.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    # Keep a complete temporary on any failure; never replace or remove evidence.
    os.rename(temporary, destination)
    if destination.read_bytes() != raw:
        raise ValueError("committed receipt differs")


def supervise_measurement(*, source: Path, source_sha: str, bundle: Path, ffmpeg: Path,
                         ffmpeg_sha: str, receipt: Path, attempts: Path,
                         receipt_sha: str | None = None, recovery_receipt: Path | None = None,
                         recovery_sha: str | None = None, timeout_seconds=180,
                         memory_bytes=2 * 1024 ** 3) -> dict:
    """Cache first; new measurement only in a bounded worker and unique attempt.

    Retry is caller-controlled. Completed evidence is replayed, partial attempts
    remain untouched. A cache mismatch never silently initiates new inference.
    """
    adapter = _adapter()
    adapter.resident(receipt, must_exist=False)
    if receipt.exists() or receipt_sha is not None:
        if receipt_sha is None:
            raise ValueError("existing receipt requires external SHA-256; no inference fallback")
        return verify_cached(receipt, receipt_sha, source_sha, source=source,
                             ffmpeg_sha=ffmpeg_sha, bundle=bundle)
    if recovery_receipt is not None or recovery_sha is not None:
        if recovery_receipt is None or recovery_sha is None:
            raise ValueError("recovery requires complete receipt and external hash")
        result = verify_cached(recovery_receipt, recovery_sha, source_sha, source=source,
                               ffmpeg_sha=ffmpeg_sha, bundle=bundle)
        _commit_new(recovery_receipt, receipt)
        result.update(status="COMPLETED_MEASUREMENT_RECOVERED", recovered_to=str(receipt.absolute()))
        return result
    _positive(timeout_seconds, "timeout", 600)
    adapter.read_pinned(source, source_sha)
    adapter.read_pinned(ffmpeg, ffmpeg_sha)
    adapter.model_bundle(bundle)
    adapter.resident(attempts, must_exist=False)
    attempts.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(attempts).free < 5 * 1024 ** 3:
        raise ValueError("5 GiB free disk reserve required")
    attempt = attempts / ("attempt-" + uuid.uuid4().hex)
    attempt.mkdir(exist_ok=False)
    request = {"version": VERSION, "runner_sha256": FROZEN_RUNNER_SHA,
               "supervisor_sha256": adapter.sha(Path(__file__).read_bytes()),
               "source": str(source.absolute()), "source_sha256": source_sha,
               "bundle": str(bundle.absolute()), "ffmpeg": str(ffmpeg.absolute()),
               "ffmpeg_sha256": ffmpeg_sha, "memory_bytes": memory_bytes,
               "output": str((attempt / "measurement.json").absolute())}
    raw = adapter.canonical(request)
    request_path = attempt / "request.json"
    adapter.immutable_write(request_path, raw)
    try:
        run = run_bounded([sys.executable, "-B", "-m", "hero_engine.audio_perception_supervisor",
                           "worker", "--request", str(request_path.absolute()),
                           "--request-sha", adapter.sha(raw)], cwd=ROOT, logs=attempt / "process",
                          timeout_seconds=timeout_seconds, memory_bytes=memory_bytes)
    except Exception as exc:
        terminal = {"version": VERSION, "status": "SUPERVISOR_START_FAILED",
                    "attempt": str(attempt.absolute()), "request_sha256": adapter.sha(raw),
                    "error_type": type(exc).__name__, "release_authority": False, "audio_approved": False}
        adapter.immutable_write(attempt / "terminal.json", adapter.canonical(terminal))
        return terminal
    terminal = {"version": VERSION, "status": run["status"], "attempt": str(attempt.absolute()),
                "process_receipt": {"path": str((attempt / "process/process-receipt.json").absolute()),
                                    "sha256": adapter.sha(adapter.canonical(run))},
                "request_sha256": adapter.sha(raw), "release_authority": False, "audio_approved": False}
    if run["status"] == "SUCCEEDED":
        try:
            candidate = attempt / "measurement.json"
            candidate_sha = adapter.sha(candidate.read_bytes())
            verification = verify_cached(candidate, candidate_sha, source_sha, source=source,
                                          ffmpeg_sha=ffmpeg_sha, bundle=bundle)
            _commit_new(candidate, receipt)
            terminal.update(status="MEASUREMENT_COMMITTED_NOT_APPROVED",
                            receipt={"path": str(receipt.absolute()), "sha256": candidate_sha},
                            verification=verification)
        except Exception as exc:
            terminal.update(status="MEASUREMENT_COMMIT_FAILED", error_type=type(exc).__name__)
    adapter.immutable_write(attempt / "terminal.json", adapter.canonical(terminal))
    return terminal


def _worker(request_path: Path, request_sha: str):
    adapter = _adapter()
    raw = adapter.read_pinned(request_path, request_sha)
    request = json.loads(raw)
    keys = {"version", "runner_sha256", "supervisor_sha256", "source", "source_sha256",
            "bundle", "ffmpeg", "ffmpeg_sha256", "memory_bytes", "output"}
    if set(request) != keys or adapter.canonical(request) != raw or request["version"] != VERSION:
        raise ValueError("invalid worker request")
    if request["runner_sha256"] != FROZEN_RUNNER_SHA:
        raise ValueError("unrecognized adapter")
    adapter.read_pinned(Path(__file__), request["supervisor_sha256"])
    _require_worker_containment(request["memory_bytes"])
    adapter.read_pinned(Path(request["ffmpeg"]), request["ffmpeg_sha256"])
    target = Path(request["output"])
    if target.absolute() != request_path.absolute().parent / "measurement.json" or target.exists():
        raise ValueError("invalid/occupied attempt receipt")
    value = adapter.measure(Path(request["source"]), request["source_sha256"],
                            Path(request["bundle"]), Path(request["ffmpeg"]))
    adapter.immutable_write(target, adapter.canonical(value))


def _require_worker_containment(memory_bytes: int):
    """The internal CLI must not become an accidental unbounded bypass."""
    if type(memory_bytes) is not int or not 64 * 1024 ** 2 <= memory_bytes <= 4 * 1024 ** 3:
        raise ValueError("invalid worker memory ceiling")
    name = os.environ.get(CONTAINMENT_JOB_ENV, "")
    if not re.fullmatch(re.escape(CONTAINMENT_JOB_PREFIX) + r"[0-9a-f]{32}", name):
        raise RuntimeError("worker requires an explicit supervisor Job Object identity")
    k = _kernel()
    # QUERY only, not inheritable: the worker cannot reconfigure the supervisor's
    # limits or keep an inherited owner handle alive after supervisor failure.
    job = _check(k.OpenJobObjectW(0x0004, False, name))
    try:
        contained = w.BOOL()
        _check(k.IsProcessInJob(k.GetCurrentProcess(), job, ctypes.byref(contained)))
        if not contained.value:
            raise RuntimeError("worker is not a member of the explicit supervisor Job Object")
        limits = _ExtendedLimits()
        _check(k.QueryInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits), None))
        flags = limits.BasicLimitInformation.LimitFlags
        if flags & 0x2300 != 0x2300 or flags & 0x1800:
            raise RuntimeError("worker requires kill-on-close, memory ceilings and no breakaway")
        if limits.JobMemoryLimit != memory_bytes or limits.ProcessMemoryLimit != memory_bytes:
            raise RuntimeError("worker memory ceiling differs from request")
        return {"job_name": name, "membership_verified": True,
                "flags": int(flags), "job_memory_limit_bytes": int(limits.JobMemoryLimit),
                "process_memory_limit_bytes": int(limits.ProcessMemoryLimit)}
    finally:
        _check(k.CloseHandle(job))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("worker",))
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--request-sha", required=True)
    args = parser.parse_args()
    _worker(args.request, args.request_sha)
