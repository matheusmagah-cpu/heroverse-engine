"""Local, read-only DNSMOS P.835 measurements. Never a release authority.

Microsoft DNS-Challenge regular P.835 polynomials (MIT code), revision pinned
below. Model/docs CC BY 4.0 under the upstream license declaration. This
implementation uses FFmpeg resampling and adds a tail window: its aggregate
must NOT be represented as the unchanged upstream benchmark implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import stat
import subprocess
import time
import urllib.request
import wave

import numpy as np

VERSION = "dnsmos-p835-fullcoverage-ffmpeg-v1"
COMMIT = "591184a9fcb2cbdec02520fed81a32bbbf9d73ff"
BASE = f"https://raw.githubusercontent.com/microsoft/DNS-Challenge/{COMMIT}/"
UPSTREAM = {
    "LICENSE": (19047, "085c3ca0c4920beedbf179f7987e705aec84115b"),
    "LICENSE-CODE": (1162, "3d8b93bc7987d14c848448c089e2ae15311380d7"),
    "README.md": (16192, "31c5bd7f7d1cf744e513b63c8220c67e9b3c2bae"),
    "DNSMOS/README.md": (2239, "5b874478143e177dacc024ab3085f0aee7d32a78"),
    "DNSMOS/dnsmos_local.py": (6491, "e32032e97541fde9a98fdc12745d5c1e09e5c7f1"),
    "DNSMOS/DNSMOS/sig_bak_ovr.onnx": (1157965, "814b8dc6dafa729c0b821a64bef2e7156dc0c01a"),
}
MODEL = "DNSMOS/DNSMOS/sig_bak_ovr.onnx"
UPSTREAM_SHA256 = {
    "LICENSE": "d6239afa918961b465b07bf7411cbe34ff6685854f58553db7966f4881a0211f",
    "LICENSE-CODE": "9906940f61b1f0b533fa7d99baf55178b2808fbe113ea51dfbfad8572ccd5f2b",
    "README.md": "9fcf7120a9ef7a2f2892e04a4d94e3cd91fb4683eda284a5eb2a9f2a0ccabaef",
    "DNSMOS/README.md": "2d919ce628b72e2ba94b586654f3afa31930f7467ebe45bb4ddbb14a21226331",
    "DNSMOS/dnsmos_local.py": "1ab566afe006daab32ac7073296a5d0ef99f8b82f91c7266f3ccf26113d7a28b",
    MODEL: "269fbebdb513aa23cddfbb593542ecc540284a91849ac50516870e1ac78f6edd",
}
RATE, WINDOW, HOP = 16000, 144160, 16000
COEFFICIENTS = ((-.08397278, 1.22083953, .0052439),
                (-.13166888, 1.60915514, -.39604546),
                (-.06766283, 1.11546468, .04602535))
LIMITATIONS = ["UNVALIDATED_FOR_THIS_TTS_DOMAIN", "NO_WORD_PRONUNCIATION_VERDICT",
                "NO_EDITORIAL_PROSODY_VERDICT", "NO_TEMPORAL_CALIBRATION",
                "NO_HUMAN_GOLD", "NO_VIDEO_OR_RELEASE_APPROVAL"]


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def canonical(value) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       allow_nan=False, separators=(",", ":")) + "\n").encode("utf-8")


def resident(path: Path, *, must_exist: bool = True) -> Path:
    """Reject symlinks/junctions/cloud placeholders throughout the lexical path."""
    path = path.absolute()
    for item in reversed((path, *path.parents)):
        try:
            meta = item.lstat()
        except FileNotFoundError:
            if must_exist:
                raise ValueError(f"missing dependency: {item}") from None
            continue
        attrs = getattr(meta, "st_file_attributes", 0)
        if stat.S_ISLNK(meta.st_mode) or attrs & (0x400 | 0x1000 | 0x40000 | 0x400000):
            raise ValueError(f"linked/offline dependency: {item}")
    return path


def read_pinned(path: Path, expected: str) -> bytes:
    if not isinstance(expected, str) or len(expected) != 64:
        raise ValueError("external SHA-256 required")
    raw = resident(path).read_bytes()
    if not raw or sha(raw) != expected:
        raise ValueError("dependency hash mismatch")
    return raw


def immutable_write(path: Path, raw: bytes) -> None:
    resident(path, must_exist=False)
    path.parent.mkdir(parents=True, exist_ok=True)
    resident(path.parent)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("refusing to overwrite different evidence")
        return
    with path.open("xb") as handle:
        handle.write(raw)


def model_bundle(directory: Path, *, download: bool = False) -> list[dict]:
    """Only explicit setup downloads fixed official files; inference is offline."""
    result = []
    for name, (length, git_sha) in UPSTREAM.items():
        target = resident(directory / name, must_exist=False)
        if target.exists():
            raw = target.read_bytes()
        elif download:
            with urllib.request.urlopen(BASE + name, timeout=30) as response:
                if response.geturl() != BASE + name:
                    raise ValueError("unexpected download redirect")
                raw = response.read(length + 1)
        else:
            raise ValueError("offline model bundle incomplete; run explicit setup")
        blob = b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw
        if len(raw) != length or hashlib.sha1(blob).hexdigest() != git_sha or sha(raw) != UPSTREAM_SHA256[name]:
            raise ValueError("upstream artifact identity mismatch")
        if download:
            immutable_write(target, raw)
        result.append({"path": str(target), "size": length, "sha256": sha(raw),
                       "git_blob_sha1": git_sha, "url": BASE + name})
    return result


def window_starts(samples: int) -> list[int]:
    if type(samples) is not int or not WINDOW <= samples <= RATE * 600:
        raise ValueError("supported duration is 9.01 through 600 seconds; no repeating/padding")
    starts = list(range(0, samples - WINDOW + 1, HOP))
    if starts[-1] + WINDOW != samples:
        starts.append(samples - WINDOW)
    return starts


def quality_samples(samples: np.ndarray) -> dict:
    if samples.dtype != np.float32 or samples.ndim != 1 or not len(samples):
        raise ValueError("nonempty mono float32 required")
    if not np.isfinite(samples).all():
        raise ValueError("nonfinite PCM")
    peak = float(np.max(np.abs(samples)))
    rms = float(np.sqrt(np.mean(samples.astype(np.float64) ** 2)))
    return {"peak": peak, "rms": rms, "all_zero": peak == 0,
            "samples_at_or_above_full_scale": int(np.sum(np.abs(samples) >= 1))}


def calibrated(raw) -> list[float]:
    values = np.asarray(raw)
    if values.shape != (3,) or not np.isfinite(values).all():
        raise ValueError("unexpected/nonfinite P.835 output")
    # Do not clamp out-of-domain predictions to create a false passing score.
    if not all(0 <= float(v) <= 6 for v in values):
        raise ValueError("raw P.835 output outside diagnostic envelope")
    return [float((a * x + b) * x + c)
            for x, (a, b, c) in zip(map(float, values), COEFFICIENTS)]


def summarize(rows: list[dict], count: int) -> dict:
    starts = window_starts(count)
    if len(rows) != len(starts):
        raise ValueError("missing window coverage")
    for row, start in zip(rows, starts):
        if type(row["start_sample"]) is not int or type(row["end_sample"]) is not int:
            raise ValueError("exact integer sample boundaries required")
        if (row["start_sample"], row["end_sample"]) != (start, start + WINDOW):
            raise ValueError("window sequence/tail mismatch")
        if canonical(row["p835_estimate"]) != canonical(calibrated(row["raw_sig_bak_ovr"])):
            raise ValueError("calibration mismatch")
    scores = np.array([row["p835_estimate"] for row in rows], dtype=np.float64)
    # Upstream has an older truncated hop calculation. Report that subset too.
    upstream_count = int(math.floor(count / RATE) - 9.01) + 1
    result = {"window_count": len(rows), "covered_samples": count,
              "uncovered_samples": 0, "coverage_fraction": 1.0,
              "mean_sig_bak_ovr": scores.mean(axis=0).tolist(),
              "p10_sig_bak_ovr": np.percentile(scores, 10, axis=0).tolist(),
              "minimum_sig_bak_ovr": scores.min(axis=0).tolist(),
              "worst_overall_start_sample": rows[int(scores[:, 2].argmin())]["start_sample"],
              "upstream_lattice_window_count": upstream_count,
              "upstream_lattice_mean_same_ffmpeg_preprocessing": scores[:upstream_count].mean(axis=0).tolist(),
              "upstream_lattice_uncovered_samples": count - ((upstream_count - 1) * HOP + WINDOW)}
    return result


def evaluate_windows(samples: np.ndarray, infer) -> tuple[list[dict], dict]:
    quality_samples(samples)
    rows = []
    for start in window_starts(len(samples)):
        segment = samples[start:start + WINDOW]
        raw = np.asarray(infer(segment)).reshape(-1)
        estimates = calibrated(raw)
        rows.append({"start_sample": start, "end_sample": start + WINDOW,
                     "pcm_sha256": sha(segment.astype("<f4").tobytes()),
                     "raw_sig_bak_ovr": list(map(float, raw)),
                     "p835_estimate": estimates, "signal": quality_samples(segment)})
    return rows, summarize(rows, len(samples))


def decode(raw: bytes, ffmpeg: Path) -> tuple[np.ndarray, dict]:
    with wave.open(io.BytesIO(raw), "rb") as reader:
        if (reader.getnchannels(), reader.getsampwidth(), reader.getframerate(), reader.getcomptype()) != (1, 2, 24000, "NONE"):
            raise ValueError("this adapter version accepts mono24kPCM16 only")
        frames = reader.getnframes()
        if not 216240 <= frames <= 24000 * 600 or frames % 3:
            raise ValueError("unsupported duration or nonexact 24k-to-16k sample lattice")
        pcm = reader.readframes(frames)
        if len(pcm) != frames * 2:
            raise ValueError("truncated source PCM")
        original = np.frombuffer(pcm, dtype="<i2")
    command = [str(ffmpeg), "-nostdin", "-hide_banner", "-loglevel", "error", "-threads", "1",
               "-f", "wav", "-i", "pipe:0", "-map", "0:a:0", "-vn", "-filter_threads", "1",
               "-af", "aresample=16000:resampler=swr:filter_size=32:phase_shift=10:exact_rational=1",
               "-ac", "1", "-ar", "16000", "-f", "f32le", "pipe:1"]
    run = subprocess.run(command, input=raw, capture_output=True, timeout=120, check=True)
    if run.stderr or len(run.stdout) != (frames * 2 // 3) * 4:
        raise ValueError("unexpected resampler diagnostics or sample count")
    samples = np.frombuffer(run.stdout, dtype="<f4").copy()
    quality_samples(samples)
    return samples, {"command": command, "source_rate": 24000, "source_samples": frames,
                     "source_pcm_extreme_samples": int(np.sum((original == -32768) | (original == 32767))),
                     "output_rate": RATE, "output_samples": len(samples),
                     "output_pcm_sha256": sha(run.stdout), "stderr_sha256": sha(run.stderr),
                     "method_differs_from_upstream_librosa": True}


def control_measurements(samples: np.ndarray, infer) -> dict:
    # Fixed first complete speech window; synthetic counterexamples, not gold.
    base = samples[:WINDOW].copy()
    signal = quality_samples(base)
    if signal["rms"] <= 1e-6:
        raise ValueError("control base window has no usable signal")
    rng = np.random.default_rng(163)
    noise = rng.normal(size=WINDOW).astype(np.float32)
    noise *= signal["rms"] / float(np.sqrt(np.mean(noise.astype(np.float64) ** 2)))
    noisy = (base + noise).astype(np.float32)  # 0 dB RMS SNR before combination.
    noisy *= min(1., .95 / float(np.max(np.abs(noisy))))
    clipped = np.clip(base * 20, -1, 1).astype(np.float32)
    fixtures = {"baseline": base, "noise_0db": noisy, "silence": np.zeros(WINDOW, np.float32),
                "hard_clip_gain20": clipped}
    records = {}
    for name, value in fixtures.items():
        output = np.asarray(infer(value)).reshape(-1)
        records[name] = {"pcm_sha256": sha(value.astype("<f4").tobytes()),
                         "raw_sig_bak_ovr": list(map(float, output)),
                         "p835_estimate": calibrated(output), "signal": quality_samples(value)}
    checks = {
        "noise_background_estimate_lower": records["noise_0db"]["p835_estimate"][1] < records["baseline"]["p835_estimate"][1],
        "noise_overall_estimate_lower": records["noise_0db"]["p835_estimate"][2] < records["baseline"]["p835_estimate"][2],
        "silence_blocked_by_signal_not_mos": records["silence"]["signal"]["all_zero"],
        "clipping_blocked_by_pcm_not_mos": records["hard_clip_gain20"]["signal"]["samples_at_or_above_full_scale"] > 0,
    }
    return {"synthetic_not_human_gold": True, "seed": 163, "checks": checks,
            "status": "PASS_DIAGNOSTIC_CONTROLS" if all(checks.values()) else "FAIL_DIAGNOSTIC_CONTROLS",
            "records": records}


def measure(source: Path, source_sha: str, bundle: Path, ffmpeg: Path) -> dict:
    started = time.perf_counter()
    raw = read_pinned(source, source_sha)
    artifacts = model_bundle(bundle)
    binary = resident(ffmpeg).read_bytes()
    binary_hash = sha(binary)
    runner_hash = sha(resident(Path(__file__)).read_bytes())
    samples, preprocessing = decode(raw, ffmpeg)
    import onnxruntime as ort
    ort.disable_telemetry_events()
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    session = ort.InferenceSession((bundle / MODEL).read_bytes(), sess_options=options,
                                   providers=["CPUExecutionProvider"])
    inputs = session.get_inputs()
    if len(inputs) != 1 or inputs[0].name != "input_1" or inputs[0].type != "tensor(float)":
        raise ValueError("unexpected model input contract")

    def infer(segment):
        if time.perf_counter() - started > 180:
            raise TimeoutError("bounded diagnostic time budget exceeded")
        result = session.run(None, {"input_1": segment[None].astype(np.float32)})
        if len(result) != 1 or result[0].shape != (1, 3):
            raise ValueError("unexpected model output contract")
        return result[0][0]

    rows, summary = evaluate_windows(samples, infer)
    controls = control_measurements(samples, infer)
    result = {"version": VERSION, "state": "MEASURED_NOT_CALIBRATED", "release_authority": False,
              "human_review_performed": False, "limitations": LIMITATIONS,
              "source": {"path": str(source.absolute()), "sha256": source_sha, "size": len(raw)},
              "runner": {"path": str(Path(__file__).absolute()), "sha256": runner_hash},
              "ffmpeg": {"path": str(ffmpeg.absolute()), "sha256": binary_hash},
              "upstream_commit": COMMIT, "artifacts": artifacts,
              "dependencies": {"numpy": np.__version__, "onnxruntime": ort.__version__},
              "resources": {"intra_threads": 2, "inter_threads": 1, "provider": "CPUExecutionProvider",
                            "inference_api_calls": 0, "incremental_technical_cost_brl": 0},
              "preprocessing": preprocessing, "windows": rows, "summary": summary,
              "controls": controls, "duration_seconds": round(time.perf_counter() - started, 6)}
    # Detect any dependency change while measuring; no stale evidence is committed.
    read_pinned(source, source_sha)
    read_pinned(Path(__file__), runner_hash)
    read_pinned(ffmpeg, binary_hash)
    if canonical(model_bundle(bundle)) != canonical(artifacts):
        raise ValueError("model bundle changed while measuring")
    return result


def replay(receipt_path: Path, receipt_sha: str, runner_sha: str, source_sha: str) -> dict:
    """Integrity/aggregation replay only. It cannot reproduce or certify MOS inference."""
    raw = read_pinned(receipt_path, receipt_sha)
    result = json.loads(raw)
    if canonical(result) != raw:
        raise ValueError("noncanonical receipt")
    if result["version"] != VERSION or result["runner"]["sha256"] != runner_sha or result["source"]["sha256"] != source_sha:
        raise ValueError("external identity mismatch")
    if result["release_authority"] is not False or result["human_review_performed"] is not False:
        raise ValueError("unauthorized approval claim")
    if result["state"] != "MEASURED_NOT_CALIBRATED" or result["limitations"] != LIMITATIONS:
        raise ValueError("invalid scope")
    read_pinned(Path(__file__), runner_sha)
    for entry in [result["source"], result["runner"], result["ffmpeg"], *result["artifacts"]]:
        read_pinned(Path(entry["path"]), entry["sha256"])
    bundle = Path(result["artifacts"][0]["path"]).parent
    if canonical(model_bundle(bundle)) != canonical(result["artifacts"]):
        raise ValueError("upstream identity mismatch")
    summary = summarize(result["windows"], result["preprocessing"]["output_samples"])
    if canonical(summary) != canonical(result["summary"]):
        raise ValueError("aggregate mismatch")
    return {"status": "PASS_INTEGRITY_REPLAY_ONLY", "receipt_sha256": receipt_sha,
            "windows": summary["window_count"], "inference_calls": 0, "subprocesses": 0,
            "release_authority": False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("setup", "measure", "replay"))
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--source-sha")
    parser.add_argument("--ffmpeg", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--receipt-sha")
    parser.add_argument("--runner-sha")
    args = parser.parse_args()
    if args.mode == "setup":
        if args.bundle is None:
            parser.error("setup requires --bundle")
        result = {"artifacts": model_bundle(args.bundle, download=True)}
    elif args.mode == "replay":
        if not all((args.output, args.receipt_sha, args.runner_sha, args.source_sha)):
            parser.error("replay requires output and external receipt/runner/source hashes")
        result = replay(args.output, args.receipt_sha, args.runner_sha, args.source_sha)
    else:
        if not all((args.source, args.source_sha, args.bundle, args.ffmpeg, args.output)):
            parser.error("measure requires source/hash, bundle, ffmpeg and output")
        resident(args.output, must_exist=False)
        if args.output.exists():
            raise ValueError("receipt exists; use externally pinned replay, not inference")
        if shutil.disk_usage(args.source.parent).free < 5 * 1024 ** 3:
            raise ValueError("less than 5 GiB free disk reserve")
        result = measure(args.source, args.source_sha, args.bundle, args.ffmpeg)
        immutable_write(args.output, canonical(result))
        result = {"receipt": str(args.output), "sha256": sha(canonical(result)),
                  "state": result["state"], "summary": result["summary"],
                  "controls": result["controls"]["checks"], "duration_seconds": result["duration_seconds"]}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2))


if __name__ == "__main__":
    main()
