"""Externally anchored replay of the frozen V3 twenty-nine-use inspection.

Reconstitutes literal rows, the historical transaction and dependency population.
The old V3 inspector, PNG container/decoder, OCR, renderer and rights evaluator
are never called. Registered rights are historical bindings, not a new grant.
Only ``replay`` verifies an external cache; ``recheck`` is a same-call byte and
inventory guard for an already reconstituted Reader, not a candidate verifier.
"""
from __future__ import annotations

import copy
import math
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_static_sources as primitives
from . import phase6_av_static_asset_uses_v3 as previous

VERSION = "phase6-av-static-uses-v3-exact-replay-v2"
BASE = "output/operations/phase6/av-admission/static-asset-uses-v3"
ANCHOR = {"path": BASE + "/receipt.json", "sha256": "984b972d3454e8a14c8fbfc218564cda2a1eaf7478da1ea9cf89e6b2da1e0ddd"}
INPUT = {"path": BASE + "/input.json", "sha256": "3e74c984f2f76fb8d74071b0879f34fa71cd1aaa59f2ff3f84b1cf5b8e792ef9"}
INSPECTION = {"path": BASE + "/inspection.json", "sha256": "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30"}
CLAIM = {"path": BASE + "/claim.json", "sha256": "30da0cda71407f3e6afc5e16a6f26127d6e6d2b697b75da47a5d27b1b03333f7"}
CODE_PINS = {
    "hero_engine/phase6_av_asset_use_binding_v2.py": "80c7892fa7cde1492f1955a3691c99a202ecbffe8334a061a805d60b3221da1e",
    "hero_engine/phase6_av_static_asset_uses_v3.py": "4914222e71089357d557d6e1a64cb3f834d33b5971b6d4cb6bee8a72bfea7886",
    "hero_engine/phase6_av_static_sources.py": "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "output/qa/phase6/diagnostics/test-questions-v1/build_static_asset_uses_v3.py": "3e49ddac78a298d29d62aa7abf6721ec7ba2013ab5079fbea3650feb45361633",
    "schemas/phase6_av_static_asset_uses_v3.schema.json": "125478ba83bc9a8df6f75c932af4893563ddf5f5c9c23ae3b44deb0cb1a21bab",
    "tests/test_phase6_av_asset_use_binding_v2.py": "efb13f2bccdac4988517b01a4d364d8896b345f09a5296c717f607f5ae46dcc9",
    "tests/test_phase6_av_static_asset_uses_v3.py": "7978bf09f27bf93f27842dde738566fa4299ed629b4c2cf82306d70a1d07825d",
    "tests/test_phase6_av_static_asset_uses_v3_materialization.py": "ad4f02194bc32b063eafb7baf39f9a68c69ed0e9c0f03332efb07d35e9ae1e39",
}
# Frozen CODE_PINS remain the claim/receipt identity, never today's test pins.
# These two NON-runtime transaction references changed in the T10 isolation.
# Old source bytes are unavailable: the pinned receipt authenticates historical
# metadata, not availability of those bytes or a current test execution/PASS.
HISTORICAL_TEST_REFERENCES = {
    "tests/test_phase6_av_asset_use_binding_v2.py": {
        "sha256": "efb13f2bccdac4988517b01a4d364d8896b345f09a5296c717f607f5ae46dcc9", "size_bytes": 9520},
    "tests/test_phase6_av_static_asset_uses_v3.py": {
        "sha256": "7978bf09f27bf93f27842dde738566fa4299ed629b4c2cf82306d70a1d07825d", "size_bytes": 13549},
}
CURRENT_TEST_REFERENCES = {
    "tests/test_phase6_av_asset_use_binding_v2.py": {
        "sha256": "1b8a8426bb31e1f32a17892af73a25a4808a231879dfc9b6a5497b7bdac98a02", "size_bytes": 9621},
    "tests/test_phase6_av_static_asset_uses_v3.py": {
        "sha256": "7b683227a9bc0d1e9d6b4074c87b09caaa110bd3f50d7dd323be7c1b84e21e44", "size_bytes": 14308},
}
TEST_REFERENCE_SCOPE = {
    "historical": "AUTHENTICATED_RECEIPT_METADATA_OLD_TEST_SOURCE_BYTES_UNAVAILABLE",
    "current": "PINNED_TEST_SOURCES_NOT_A_TEST_EXECUTION_RESULT",
    "historical_pass_transferred": False,
    "current_tests_passed": False,
}
MATERIALIZER_VERSION = "phase6-static-asset-uses-v3-materialization-v1"
CLAIM_BOUNDARY = ("Twenty-nine untimed uses, twenty-seven state assets, twenty-six PNG identities and three lineages. "
    "Twenty-five prior uses replayed; four question source/right bindings reconstituted. No new editorial right, "
    "calibrated sample, span, publicity, quality, admission, render or publication.")


def _same(actual, expected, message):
    primitives._same(actual, expected, message)


def _validate_anchor(anchor, claim):
    identity = {"version": MATERIALIZER_VERSION, "input_binding": INPUT, "implementation_pins": CODE_PINS}
    identifier = "static-asset-uses-v3-materialization-" + primitives._sha(primitives._canonical(identity))[:24]
    started, completed = previous.rights._utc(anchor["started_at"]), previous.rights._utc(anchor["completed_at"])
    duration = anchor["duration_seconds"]
    if (completed < started or type(duration) not in (int, float)
            or not math.isfinite(duration) or duration < 0):
        raise ValueError("historical V3 execution dates or measured duration differ")
    common = {"kind": "PHASE6_STATIC_ASSET_USES_V3_MATERIALIZATION", "version": MATERIALIZER_VERSION,
        "materialization_id": identifier, "started_at": anchor["started_at"], "input_binding": INPUT,
        "implementation_pins": CODE_PINS, "authority": previous.AUTHORITY, "technical_cost_brl": 0}
    _same(claim, {**common, "status": "CLAIMED_NOT_MATERIALIZED"}, "historical V3 exclusive claim differs")
    expected = {**common, "status": "VERIFIED_PARTIAL_UNTIMED_BINDINGS_NOT_PRODUCTION_READY",
        "completed_at": anchor["completed_at"], "duration_seconds": duration,
        "inspection_binding": INSPECTION, "claim_binding": CLAIM, "source_count": 27, "use_count": 29,
        "unique_png_content_count": 26, "lineage_count": 3, "remaining_unbound_visual_state_count": 71,
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
        "inspection_calls": 1, "question_source_batch_count": 1, "image_decode_calls": 0,
        "ocr_inference_calls": 0, "render_calls": 0, "dependency_bindings": anchor["dependency_bindings"],
        "dependency_scope": "THROUGH_INSPECTION_BEFORE_RECEIPT_WRITE"}
    _same(anchor, expected, "historical V3 execution anchor scope differs")


def _validate_rows(document, inspected, literal, old, registry, source_receipt):
    """Recompose all rows from closed literal/source/right contracts, not labels."""
    originals = source_receipt["contract"]["design"]["states"]
    _same([row["state_id"] for row in originals], previous.question.CONFIG["state_ids"],
          "historical question source order differs")
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    if len(states) != 100 or sum(len(row["states"]) for row in literal["rows"]) != 100:
        raise ValueError("historical V5 state population differs")
    sources, uses = copy.deepcopy(old["inspection"]["sources"]), copy.deepcopy(old["inspection"]["uses"])
    for entry, registered, use, original in zip(document["sources"][23:], registry["rights_proofs"],
            document["uses"][25:], originals, strict=True):
        sid = entry["static_source"]["state_id"]
        row, state = states[sid]
        contract = previous.question._contract(row, state, original)
        _same([entry["source_id"], registered["template_id"], registered["state_id"], use["visual_state_id"],
               use["unit_id"], use["source_id"], use["literal_copy"]],
              [registered["asset_id"], previous.question.TEMPLATE_ID, sid, sid, contract["unit_id"],
               registered["asset_id"], contract["literal_copy"]], "historical question source/use association differs")
        asset = registered["artifacts"]["png_binding"]
        _same([Path(asset["path"]).name, asset["sha256"]],
              [sid + ".png", source_receipt["artifact_sha256"][sid + ".png"]], "historical question PNG differs")
        sources.append({"source_id": entry["source_id"], "asset_binding": copy.deepcopy(asset),
            "template_id": registered["template_id"], "state_id": sid, "lineage_id": registered["lineage_id"],
            "original_unit_id": contract["unit_id"], "original_fragment_ids": copy.deepcopy(contract["fragment_ids"]),
            "original_lexical_target": copy.deepcopy(contract["lexical_target"]),
            "source_inspection_id": registered["source_proof"]["inspection_id"],
            "source_inspection_sha256": registered["source_proof"]["sha256"],
            "rights_inspection_id": registered["inspection_id"],
            "rights_inspection_sha256": primitives._sha(primitives._canonical(registered))})
        uses.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]),
            "source_provenance_unit_id": contract["unit_id"], "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
    covered = {row["visual_state_id"] for row in uses}
    _same([len(sources), len(uses), len(covered), len({row["asset_binding"]["sha256"] for row in sources}),
           len({row["lineage_id"] for row in sources})], [27, 29, 29, 26, 3], "historical V3 population differs")
    expected = {"version": previous.VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
        "input_binding": INPUT, "source_bindings": document["source_bindings"], "channel_id": primitives.CHANNEL,
        "video_id": "video-002", "source_count": 27, "use_count": 29, "unique_png_content_count": 26,
        "lineage_count": 3, "sources": sources, "uses": uses,
        "remaining_unbound_visual_state_ids": sorted(set(states) - covered), "source_ready": False,
        "global_schedule_created": False, "calibrated_timing_available": False, "authority": previous.AUTHORITY,
        "technical_cost_brl": 0, "v2_replay_evidence": {"mode": "EXACT_CACHE_REPLAY",
            "anchor_binding": previous.previous.ANCHOR, "input_binding": previous.previous.INPUT,
            "inspection_binding": previous.previous.INSPECTION, "source_count": 23, "use_count": 25,
            "unique_png_content_count": 22, "lineage_count": 3, "image_decode_calls": 0, "rights_evaluation_calls": 0},
        "question_rights_replay_evidence": {"mode": "EXACT_CACHE_REPLAY", "registration_binding": previous.REGISTRATION,
            "request_binding": previous.REQUEST, "claim_binding": previous.CLAIM, "source_count": 4,
            "new_lineage_count": 0, "current_source_batch_count": 1, "new_editorial_decision_count": 0,
            "rights_binding_recomposition_count": 4, "scope": "HISTORICAL_RIGHTS_BINDINGS_NOT_NEW_APPROVAL"},
        "visual_amendment_evidence": {"adapter_version": previous.case.VERSION,
            "inspection_sha256": previous.canonical_sha(literal), "effective_rows_sha256": previous.canonical_sha(literal["rows"]),
            "changed_state_count": 2, "unmodified_state_count": 98,
            "prior_amendment_inspection_sha256": previous.canonical_sha(old["literal"]),
            "source_ready": False, "global_schedule_created": False},
        "image_decode_calls": 0, "ocr_inference_calls": 0, "render_calls": 0,
        "dependency_bindings": inspected["dependency_bindings"], "claim_boundary": CLAIM_BOUNDARY}
    expected["inspection_id"] = "static-asset-uses-v3-" + primitives._sha(primitives._canonical(expected))[:24]
    _same(inspected, expected, "historical V3 inspection does not literally recompose")


def _merge(*populations):
    result = {}
    for population in populations:
        for item in population:
            _same(result.setdefault(item["path"], copy.deepcopy(item)), item, "historical dependency identities conflict")
    return sorted(result.values(), key=lambda item: item["path"])


def _current_code_pins():
    allowed = {"tests/test_phase6_av_asset_use_binding_v2.py", "tests/test_phase6_av_static_asset_uses_v3.py"}
    if set(HISTORICAL_TEST_REFERENCES) != allowed or set(CURRENT_TEST_REFERENCES) != allowed:
        raise ValueError("only the two isolated test references may differ")
    for name in allowed:
        _same(HISTORICAL_TEST_REFERENCES[name]["sha256"], CODE_PINS.get(name), "historical test identity differs")
    return {**CODE_PINS, **{name: item["sha256"] for name, item in CURRENT_TEST_REFERENCES.items()}}


def _test_reference_binding(reader, name, references):
    return {"path": str(reader.root / name), **references[name]}


def _historical_transaction(guard):
    """Project metadata only, never counterfeit physical Reader bindings.

    The exact old SHA/size population is compared with the entire authenticated
    receipt. Runtime/schema/source/data dependencies are not projected.
    """
    _current_code_pins()
    projected = []
    for item in guard.bindings.values():
        if Path(item["path"]) == guard.root / ANCHOR["path"]:
            continue
        historical = item
        for name in CURRENT_TEST_REFERENCES:
            if item["path"] == str(guard.root / name):
                _same(item, _test_reference_binding(guard, name, CURRENT_TEST_REFERENCES),
                      "current isolated test binding differs")
                historical = _test_reference_binding(guard, name, HISTORICAL_TEST_REFERENCES)
                break
        projected.append(copy.deepcopy(historical))
    if len({item["path"] for item in projected}) != len(projected):
        raise ValueError("duplicate transaction dependency")
    return projected


def _validate_dependencies(reader, inspected, anchor, guard):
    # This Reader was populated by the closed V2/V5/registry readers, not by
    # iterating the candidate inspection's dependency list.
    _same(inspected["dependency_bindings"], sorted(reader.bindings.values(), key=lambda item: item["path"]),
          "historical V3 inspection dependency population does not independently recompose")
    transaction = _historical_transaction(guard)
    _same(anchor["dependency_bindings"], _merge(inspected["dependency_bindings"], transaction),
          "historical V3 transaction dependency population does not independently recompose")


def _inventory(reader):
    directory = reader.path(BASE)
    names = {"claim.json", "input.json", "inspection.json", "receipt.json"}
    if {path.name for path in directory.iterdir()} != names:
        raise ValueError("historical V3 transaction inventory drift")
    for name in names:
        path = primitives._resident(directory / name)
        if not path.is_file() or path.stat().st_nlink != 1:
            raise ValueError("historical V3 transaction requires resident single-link files")


def recheck(reader):
    """Same-call Reader/sink only; does not approve a serialized candidate.

    A downstream caller may rebuild this Reader from a result it obtained from
    ``replay`` in that same call. Never use this helper instead of ``replay``
    for an externally supplied or persisted inspection. The exact three OCR
    model pins retain their own 32MiB limit; no arbitrary large file is allowed.
    """
    if not isinstance(reader, primitives._Reader):
        raise ValueError("same-call V3 replay Reader required")
    for bound in (ANCHOR, INPUT, INSPECTION, CLAIM):
        _same(reader.bindings.get(str(reader.root / bound["path"]), {}).get("sha256"), bound["sha256"],
              "same-call V3 replay anchor missing")
    for name, digest in _current_code_pins().items():
        _same(reader.bindings.get(str(reader.root / name), {}).get("sha256"), digest, "current V3 implementation pin missing")
    for name in CURRENT_TEST_REFERENCES:
        _same(reader.bindings.get(str(reader.root / name)), _test_reference_binding(reader, name, CURRENT_TEST_REFERENCES),
              "current isolated test binding differs")
    previous.recheck_asset_use_dependencies(reader.root,
        [{"version": previous.VERSION, "authority": dict(previous.AUTHORITY),
          "dependency_bindings": list(reader.bindings.values())}])
    _inventory(reader)


def replay(root):
    guard = primitives._Reader(root)
    path = Path(__file__).absolute()
    if path != guard.root / "hero_engine/phase6_av_static_uses_v3_replay.py":
        raise ValueError("V3 replay implementation belongs to another root")
    own_digest = primitives._sha(primitives._resident(path).read_bytes())
    for name, digest in _current_code_pins().items():
        guard.read(name, digest)
    anchor, claim, inspected = (previous._json(guard, bound) for bound in (ANCHOR, CLAIM, INSPECTION))
    _validate_anchor(anchor, claim)
    _inventory(guard)
    reader, literal, old, registry = previous._envelope(root)
    document = previous._json(reader, INPUT)
    schema = primitives._json(reader.read(previous.SCHEMA, CODE_PINS[previous.SCHEMA]))
    Draft202012Validator(schema).validate(document)
    _same(document, previous._expected(literal, old["input"], registry), "historical V3 input does not recompose")
    config = previous.question.CONFIG
    receipt = previous._json(reader, {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]})
    # V5's reader already independently replays the full question staging,
    # original FAIL, scans, ink observations and its mandatory dependencies.
    # The registry cannot introduce a source-preflight file absent from that
    # independently reconstructed population.
    question_deps = {item["path"]: item for item in literal["question_replay_dependencies"]}
    for item in registry["request"]["source_preflight_dependencies"]:
        _same(question_deps.get(item["path"]), item, "question preflight dependency lacks independent V5 replay")
    _validate_rows(document, inspected, literal, old, registry, receipt)
    _validate_dependencies(reader, inspected, anchor, guard)
    previous._dependencies(reader, list(guard.bindings.values()))
    reader.read_path(path, own_digest)
    recheck(reader)
    return {"version": VERSION, "mode": "EXACT_CACHE_REPLAY", "anchor_binding": copy.deepcopy(ANCHOR),
        "input_binding": copy.deepcopy(INPUT), "inspection_binding": copy.deepcopy(INSPECTION), "claim_binding": copy.deepcopy(CLAIM),
        "input": document, "inspection": inspected, "literal": literal,
        "source_count": 27, "use_count": 29, "unique_png_content_count": 26, "lineage_count": 3,
        "remaining_unbound_visual_state_count": 71, "image_decode_calls": 0, "ocr_inference_calls": 0,
        "rights_evaluation_calls": 0, "source_inspection_calls": 0, "render_calls": 0,
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
        "authority": dict(previous.AUTHORITY), "technical_cost_brl": 0,
        "test_reference_scope": copy.deepcopy(TEST_REFERENCE_SCOPE),
        "historical_test_references": copy.deepcopy(HISTORICAL_TEST_REFERENCES),
        "current_test_references": copy.deepcopy(CURRENT_TEST_REFERENCES),
        "historical_effect_scope": "Nested inspection and receipt counters describe the historical transaction, not this replay.",
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"])}
