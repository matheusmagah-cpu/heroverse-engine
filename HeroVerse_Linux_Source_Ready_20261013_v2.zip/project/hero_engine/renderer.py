from __future__ import annotations

import json
import shutil
import subprocess
import textwrap
from pathlib import Path
from typing import Any

from .db import DEFAULT_DB, ROOT, connect, utc_now


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"
FONT = Path(r"C:\Windows\Fonts\georgiab.ttf")


def _run(command: list[str]) -> None:
    result = subprocess.run(
        command,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    if result.returncode:
        tail = "\n".join(result.stderr.splitlines()[-30:])
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(command[:4])}\n{tail}")


def _escape_drawtext(value: str) -> str:
    return (
        value.replace("\\", r"\\")
        .replace("'", "’")
        .replace(":", r"\:")
        .replace("%", r"\%")
        .replace(",", r"\,")
    )


def _wrap_screen_text(value: str, width: int = 24) -> str:
    return "\n".join(textwrap.wrap(value, width=width, break_long_words=False))


def _font_filter() -> str:
    return str(FONT).replace("\\", "/").replace(":", r"\:")


def synthesize_sapi(text: str, destination: Path, rate: int = 1) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    safe_text = text.replace("'", "''")
    safe_path = str(destination).replace("'", "''")
    script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s=[System.Speech.Synthesis.SpeechSynthesizer]::new(); "
        "$s.SelectVoice('Microsoft Zira Desktop'); "
        f"$s.Rate={rate}; $s.Volume=100; "
        f"$s.SetOutputToWaveFile('{safe_path}'); "
        f"$s.Speak('{safe_text}'); $s.Dispose()"
    )
    command = ["powershell", "-NoProfile", "-NonInteractive", "-Command", script]
    _run(command)
    return destination


def _probe_duration(path: Path) -> float:
    result = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    if result.returncode:
        raise RuntimeError(f"ffprobe failed for {path}: {result.stderr.strip()}")
    return float(result.stdout.strip())


def _render_voiceover(segment: dict[str, Any], work_dir: Path, index: int) -> Path:
    duration = float(segment.get("target_seconds", 8))
    wav = work_dir / f"voice_{index:02d}.wav"
    trimmed_wav = work_dir / f"voice_{index:02d}_trimmed.wav"
    mp4 = work_dir / f"segment_{index:02d}.mp4"
    synthesize_sapi(segment["text"], wav)
    _run(
        [
            FFMPEG, "-y", "-i", str(wav), "-af",
            (
                "silenceremove=start_periods=1:start_duration=0.02:start_threshold=-50dB:start_silence=0.02,"
                "areverse,"
                "silenceremove=start_periods=1:start_duration=0.02:start_threshold=-50dB:start_silence=0.12,"
                "areverse"
            ),
            str(trimmed_wav),
        ]
    )
    narration_duration = _probe_duration(trimmed_wav)
    tempo = narration_duration / duration
    if not 0.80 <= tempo <= 1.25:
        raise ValueError(
            f"Narration length gate failed in segment {index}: {narration_duration:.2f}s audio "
            f"for {duration:.2f}s target (atempo={tempo:.3f}). Rewrite the narration instead of padding silence."
        )
    role = segment.get("visual_role", "body")
    caption_size = 54 if role == "hook" else 50 if role == "payoff" else 46
    visual_filters = [
        "format=yuv420p",
        "vignette=angle=PI/5",
        "noise=alls=3:allf=t+u",
        "drawbox=x=54:y=72:w=612:h=2:color=0xF6D37A@0.45:t=fill",
        (
            f"drawtext=fontfile='{_font_filter()}':text='HERO VERSE':"
            "fontcolor=0xF6D37A@0.90:fontsize=22:"
            "x=(w-text_w)/2:y=92"
        ),
    ]
    beats = segment.get("caption_beats") or []
    if beats:
        for beat in beats:
            caption = _escape_drawtext(_wrap_screen_text(beat["text"].replace("\n", " "), width=20))
            start = float(beat["start"])
            end = float(beat["end"])
            fade = min(0.12, max(0.04, (end - start) / 5))
            alpha = (
                f"if(lt(t\\,{start + fade:.3f})\\,(t-{start:.3f})/{fade:.3f}\\,"
                f"if(lt(t\\,{end - fade:.3f})\\,1\\,( {end:.3f}-t)/{fade:.3f}))"
            ).replace("( ", "(")
            visual_filters.append(
                f"drawtext=fontfile='{_font_filter()}':text='{caption}':"
                f"fontcolor=0xF6D37A:fontsize={caption_size}:borderw=3:bordercolor=black@0.90:"
                "box=1:boxcolor=0x070A12@0.46:boxborderw=22:"
                "x=(w-text_w)/2:y=(h-text_h)/2:line_spacing=12:"
                f"alpha='{alpha}':"
                f"enable='between(t\\,{start:.3f}\\,{end:.3f})'"
            )
    else:
        screen = _escape_drawtext(_wrap_screen_text(segment.get("screen_text", "")))
        visual_filters.append(
            f"drawtext=fontfile='{_font_filter()}':text='{screen}':"
            "fontcolor=0xF6D37A:fontsize=42:borderw=2:bordercolor=black@0.8:"
            "x=(w-text_w)/2:y=(h-text_h)/2:line_spacing=10"
        )
    vf = ",".join(visual_filters)
    af = (
        f"atempo={tempo:.6f},loudnorm=I=-16:LRA=9:TP=-1.5,"
        f"apad=pad_dur=0.12,atrim=0:{duration}"
    )
    _run(
        [
            FFMPEG, "-y", "-f", "lavfi", "-i",
            (
                f"gradients=s=720x1280:r=30:c0=0x090A12:c1=0x1E2846:"
                f"c2=0x5B3514:n=3:type=radial:speed=0.012:d={duration}"
            ),
            "-i", str(trimmed_wav), "-vf", vf, "-af", af, "-t", str(duration),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart", str(mp4),
        ]
    )
    return mp4


def _render_source(segment: dict[str, Any], source_file: Path, work_dir: Path, index: int) -> Path:
    start = float(segment["start_seconds"])
    duration = float(segment["end_seconds"]) - start
    if duration <= 0:
        raise ValueError(f"Invalid source duration in segment {index}")
    mp4 = work_dir / f"segment_{index:02d}.mp4"
    screen = _escape_drawtext(_wrap_screen_text(segment.get("screen_text", "")))
    vf = (
        "scale=720:1280:force_original_aspect_ratio=increase,"
        "crop=720:1280,eq=contrast=1.08:saturation=0.82:brightness=-0.025,"
        f"drawtext=fontfile='{_font_filter()}':text='{screen}':"
        "fontcolor=white:fontsize=36:borderw=3:bordercolor=black@0.9:"
        "x=(w-text_w)/2:y=90:line_spacing=8"
    )
    af = "loudnorm=I=-16:LRA=9:TP=-1.5,afade=t=in:st=0:d=0.08,afade=t=out:st=" + str(max(0.1, duration - 0.12)) + ":d=0.12"
    _run(
        [
            FFMPEG, "-y", "-ss", str(start), "-t", str(duration), "-i", str(source_file),
            "-vf", vf, "-af", af, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart", str(mp4),
        ]
    )
    return mp4


def render_edl(edl_path: Path, source_overrides: dict[str, Path] | None = None, db_path: Path | None = None) -> Path:
    if not Path(FFMPEG).exists():
        raise RuntimeError("ffmpeg was not found")
    edl = json.loads(edl_path.read_text(encoding="utf-8"))
    slug = edl["slug"]
    work_dir = ROOT / "output" / "work" / slug
    render_dir = ROOT / "output" / "renders"
    work_dir.mkdir(parents=True, exist_ok=True)
    render_dir.mkdir(parents=True, exist_ok=True)
    source_overrides = source_overrides or {}
    rendered: list[Path] = []
    for index, segment in enumerate(edl["segments"]):
        if segment["type"] == "voiceover":
            rendered.append(_render_voiceover(segment, work_dir, index))
        elif segment["type"] == "source_clip":
            video_id = segment["video_id"]
            source = source_overrides.get(video_id) or ROOT / "data" / "downloads" / f"{video_id}.mp4"
            if not source.exists():
                raise FileNotFoundError(
                    f"Source file not found for {video_id}: {source}. "
                    f"Run `hero-engine download {video_id}` only after license verification."
                )
            rendered.append(_render_source(segment, source, work_dir, index))
        else:
            raise ValueError(f"Unknown EDL segment type: {segment['type']}")

    output = render_dir / f"{slug}.mp4"
    normalization_filters: list[str] = []
    concat_inputs: list[str] = []
    for index in range(len(rendered)):
        normalization_filters.extend(
            [
                f"[{index}:v]setpts=PTS-STARTPTS,fps=30,setsar=1,format=yuv420p[v{index}]",
                f"[{index}:a]asetpts=PTS-STARTPTS,aresample=48000:async=1:first_pts=0[a{index}]",
            ]
        )
        concat_inputs.extend([f"[v{index}]", f"[a{index}]"])
    normalization_filters.append(
        "".join(concat_inputs) + f"concat=n={len(rendered)}:v=1:a=1[vout][aout]"
    )
    input_args: list[str] = []
    for path in rendered:
        input_args.extend(["-i", str(path)])
    _run(
        [
            FFMPEG, "-y", *input_args,
            "-filter_complex", ";".join(normalization_filters),
            "-map", "[vout]", "-map", "[aout]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart", str(output),
        ]
    )
    with connect(db_path or DEFAULT_DB) as conn:
        conn.execute(
            "UPDATE productions SET status='rendered', render_path=?, updated_at=? WHERE slug=?",
            (str(output), utc_now(), slug),
        )
    return output
