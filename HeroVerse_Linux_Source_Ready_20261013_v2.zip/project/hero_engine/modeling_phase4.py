from __future__ import annotations

import hashlib
import json
import math
import re
import statistics
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .db import ROOT


PHASE3_RUN = ROOT / "output" / "observatory" / "phase3" / "phase3-2026-09-02-catalog-v2"
OUTPUT_DIR = ROOT / "output" / "modeling" / "phase4" / "channel-model-v1"
GOLD_IDS = ("hkf6nDyUfAM", "_sOy7htXJi8", "Pkede5acSFw", "huvUy3pJSp8")
WINNER_GOLD = ("hkf6nDyUfAM", "_sOy7htXJi8")
SPIRITUAL_ANCHORS = {
    "armor", "bible", "christ", "devil", "divine", "enemy", "faith", "father",
    "god", "gospel", "holy", "jesus", "king", "lord", "pray", "prayer",
    "scripture", "spirit", "victory",
}
WEAK_STARTS = (
    "and there may be", "happy or sad", "the thing is", "that god leaves",
    "if you just", "you know", "okay", "well",
)


def _read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _words(value: str) -> list[str]:
    return re.findall(r"[a-z']+", value.lower())


def _quantile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("quantile requires at least one value")
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[lower])
    return float(ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower))


def _rule(rule_id: str, description: str, evidence_refs: list[str], confidence: float) -> dict[str, Any]:
    return {
        "rule_id": rule_id,
        "description": description,
        "evidence_refs": evidence_refs,
        "confidence": confidence,
    }


def _beat(
    beat_id: str,
    role: str,
    start: tuple[float, float],
    end: tuple[float, float],
    objective: str,
    retention: str,
    variations: list[str],
) -> dict[str, Any]:
    return {
        "beat_id": beat_id,
        "role": role,
        "start_ratio_range": list(start),
        "end_ratio_range": list(end),
        "objective": objective,
        "retention_function": retention,
        "allowed_variations": variations,
    }


def _opening_features(record: dict[str, Any], title: str | None) -> dict[str, Any]:
    text = " ".join(window["transcript_text"] for window in record["windows"] if window["transcript_text"]).strip()
    words = _words(text)
    first_twenty = words[:20]
    lowered = " ".join(words[:8])
    return {
        "video_id": record["video_id"],
        "title": title,
        "first_speech_seconds": record["first_speech_seconds"],
        "cuts_0_30": sum(window["scene_cut_count"] for window in record["windows"]),
        "spoken_words_0_30": sum(window["spoken_word_count"] for window in record["windows"]),
        "spiritual_anchor_first_20_words": bool(set(first_twenty) & SPIRITUAL_ANCHORS),
        "weak_or_context_dependent_start": any(lowered.startswith(item) for item in WEAK_STARTS),
        "first_twenty_words": " ".join(first_twenty),
    }


def _case(video_id: str, cohort: str, explanation: str, supporting: list[str], contrary: list[str]) -> dict[str, Any]:
    return {
        "video_id": video_id,
        "cohort_kind": cohort,
        "explanation": explanation,
        "supporting_factors": supporting,
        "contrary_factors": contrary,
        "evidence_refs": [f"gold:{video_id}", f"snapshot:{video_id}"],
    }


def _claim(
    claim_id: str,
    statement: str,
    evidence_class: str,
    status: str,
    supporting: list[str],
    contradicting: list[str],
    sample_size: int,
    confidence: float,
    limitations: list[str],
) -> dict[str, Any]:
    return {
        "claim_id": claim_id,
        "statement": statement,
        "evidence_class": evidence_class,
        "knowledge_status": status,
        "supporting_evidence": supporting,
        "contradicting_evidence": contradicting,
        "sample_size": sample_size,
        "confidence": confidence,
        "limitations": limitations,
    }


def _inputs() -> dict[str, Any]:
    snapshots = _read(PHASE3_RUN / "public_snapshots.json")["snapshots"]
    cohorts = _read(PHASE3_RUN / "cohorts.json")
    openings = _read(PHASE3_RUN / "opening_observations.json")
    coverage = _read(PHASE3_RUN / "coverage.json")
    summary = _read(PHASE3_RUN / "phase3_summary.json")
    gold = {video_id: _read(ROOT / "data" / "gold_standard" / video_id / "video_mining.json") for video_id in GOLD_IDS}
    return {
        "snapshots": snapshots,
        "cohorts": cohorts,
        "openings": openings,
        "coverage": coverage,
        "summary": summary,
        "gold": gold,
    }


def build_channel_model() -> dict[str, Any]:
    data = _inputs()
    snapshots = data["snapshots"]
    channels = {
        item["channel_id"]: item["payload"]["handle_requested"]
        for item in snapshots if item["entity_type"] == "CHANNEL" and item["payload"]
    }
    channel_ids = {handle: channel_id for channel_id, handle in channels.items()}
    video_snapshots = {item["entity_id"]: item for item in snapshots if item["entity_type"] == "VIDEO" and item["payload"]}
    grace_videos = [
        item["payload"] for item in video_snapshots.values()
        if channels[item["channel_id"]] == "@GraceGritLove" and item["payload"]["content_format"] == "LONG"
    ]
    owned_videos = [
        item["payload"] for item in video_snapshots.values()
        if channels[item["channel_id"]] == "@heroverse74"
    ]
    if len(grace_videos) != 24 or len(owned_videos) != 21:
        raise RuntimeError(f"frozen Phase 3 population drifted: grace={len(grace_videos)}, owned={len(owned_videos)}")

    cohort_membership: dict[str, set[str]] = {}
    for cohort in data["cohorts"]["cohorts"]:
        for member in cohort["members"]:
            cohort_membership.setdefault(member["video_id"], set()).add(cohort["kind"])
    opening_features = []
    for record in data["openings"]["records"]:
        title = video_snapshots.get(record["video_id"], {}).get("payload", {}).get("title")
        feature = _opening_features(record, title)
        feature["cohorts"] = sorted(cohort_membership.get(record["video_id"], set()))
        feature["holdout_from_phase2"] = record["holdout_from_phase2"]
        opening_features.append(feature)

    def group(kind: str) -> list[dict[str, Any]]:
        return [item for item in opening_features if kind in item["cohorts"]]

    winner_openings, median_openings, weak_openings = group("WINNER"), group("MEDIAN"), group("WEAK")
    if not (len(winner_openings) == 6 and len(weak_openings) == 6):
        raise RuntimeError("opening cohort sample no longer matches frozen quartiles")

    duration_values = [float(item["duration_seconds"]) for item in grace_videos if item.get("duration_seconds")]
    title_suffix_rate = sum(str(item.get("title", "")).endswith("| Christian Motivation") for item in grace_videos) / len(grace_videos)
    duration_range_ms = [round(_quantile(duration_values, 0.25) * 1000), round(_quantile(duration_values, 0.75) * 1000)]
    winner_anchor_rate = sum(item["spiritual_anchor_first_20_words"] for item in winner_openings) / len(winner_openings)
    weak_anchor_rate = sum(item["spiritual_anchor_first_20_words"] for item in weak_openings) / len(weak_openings)
    winner_weak_start_rate = sum(item["weak_or_context_dependent_start"] for item in winner_openings) / len(winner_openings)
    weak_weak_start_rate = sum(item["weak_or_context_dependent_start"] for item in weak_openings) / len(weak_openings)
    winner_speech_median = statistics.median(item["first_speech_seconds"] for item in winner_openings)
    weak_speech_median = statistics.median(item["first_speech_seconds"] for item in weak_openings)
    winner_cuts_median = statistics.median(item["cuts_0_30"] for item in winner_openings)
    weak_cuts_median = statistics.median(item["cuts_0_30"] for item in weak_openings)
    opening_contrast = (
        max(0.0, winner_anchor_rate - weak_anchor_rate)
        + max(0.0, weak_weak_start_rate - winner_weak_start_rate)
    ) / 2
    core_duration_rate = sum(210 <= value <= 300 for value in duration_values) / len(duration_values)
    full_unique, opening_only_unique, metadata_only_unique = 4, 13, 7
    evidence_coverage_score = (
        full_unique * 1.0 + opening_only_unique * 0.55 + metadata_only_unique * 0.25
    ) / len(grace_videos)
    format_repeatability_score = (
        0.35 * title_suffix_rate
        + 0.25 * opening_contrast
        + 0.25 * 1.0
        + 0.15 * core_duration_rate
    )
    narrative_confidence = math.sqrt(len(GOLD_IDS) / len(grace_videos))
    opening_confidence = math.sqrt((len(winner_openings) + len(weak_openings)) / len(grace_videos)) * 0.75
    owned_packaging_confidence = 0.60

    base_refs = ["artifact:p3-snapshots", "artifact:p3-cohorts", "artifact:p3-coverage"]
    opening_refs = ["artifact:p3-openings", "cohort:grace-winner-q1", "cohort:grace-weak-q4"]
    full_refs = [f"gold:{video_id}" for video_id in GOLD_IDS]
    evidence_matrix = [
        _claim(
            "C-PACKAGING-REPEAT",
            f"The reference population repeatedly uses compact all-caps spiritual declarations plus a niche label (observed suffix rate {title_suffix_rate:.1%}).",
            "CALCULATED", "CALCULATED", ["artifact:p3-snapshots", "cohort:grace-winner-q1", "cohort:grace-weak-q4"], [], 24, 1.0,
            ["A repeatable reference convention is not permission to copy its exact suffix, typography, or identity."],
        ),
        _claim(
            "C-HOOK-SEMANTIC",
            f"Winner openings more often place a spiritual anchor inside the first 20 spoken words ({winner_anchor_rate:.1%}) than weak openings ({weak_anchor_rate:.1%}).",
            "CALCULATED", "CANDIDATE", opening_refs,
            ["opening:DoCCRjPTE6s", "opening:N2mdHZDRYB0"], 12, round(opening_confidence, 6),
            ["Opening labels are retrospective public cohorts; retention and causality are unavailable."],
        ),
        _claim(
            "C-HOOK-WEAK-START",
            f"Context-dependent/dialogue starts appear in {weak_weak_start_rate:.1%} of weak openings versus {winner_weak_start_rate:.1%} of winner openings under the frozen lexical rule.",
            "CALCULATED", "CANDIDATE", ["opening:huvUy3pJSp8", "opening:j2JqyYZzWwI", "cohort:grace-weak-q4"],
            ["opening:_sOy7htXJi8"], 12, round(opening_confidence, 6),
            ["The lexical rule is small-sample and cannot measure whether a viewer understood the opener."],
        ),
        _claim(
            "C-TIMING-NOT-SEPARATOR",
            f"First-speech timing is similar across winner and weak openings (median {winner_speech_median:.2f}s vs {weak_speech_median:.2f}s).",
            "CALCULATED", "CALCULATED", opening_refs, [], 12, round(opening_confidence, 6),
            ["This does not imply a silent bumper is optimal for HeroVerse; it only failed to separate these public cohorts."],
        ),
        _claim(
            "C-CUTS-NOT-SEPARATOR",
            f"Cut count through 30s does not cleanly separate winner and weak cohorts (median {winner_cuts_median:.1f} vs {weak_cuts_median:.1f}).",
            "CALCULATED", "CALCULATED", opening_refs, [], 12, round(opening_confidence, 6),
            ["Cut detection uses one threshold and does not capture shot meaning or audio transitions."],
        ),
        _claim(
            "C-NARRATIVE-PROGRESSION",
            "Across the four complete cases, the repeatable mechanism is progression from a spiritual stake to explanation/proof, then an action or identity payoff; exact beat counts vary from five to seven.",
            "INFERRED", "CANDIDATE", full_refs, ["gold:huvUy3pJSp8"], 4, round(narrative_confidence, 6),
            ["Only four complete narratives exist; the beat sheet is a pilot hypothesis, not a general rule."],
        ),
        _claim(
            "C-OWNED-IDENTITY",
            "HeroVerse public packaging currently emphasizes second-person identity, divine timing, warning, hidden preparation, spiritual warfare, and chosen-purpose language.",
            "INFERRED", "CANDIDATE", ["artifact:p3-snapshots"], [], 21, owned_packaging_confidence,
            ["Only titles and public metadata were analyzed for the 20 Shorts and one long-form; visual/audio identity is unverified."],
        ),
        _claim(
            "C-RPM-UNAVAILABLE",
            "Actual RPM, revenue, qualified watch hours, CTR, and retention are unavailable and cannot rank formats economically.",
            "UNAVAILABLE", "UNAVAILABLE", ["artifact:acquisition-baseline"], [], 0, 1.0,
            ["Any high-RPM statement before authenticated post-YPP data is a hypothesis, not a measurement."],
        ),
    ]

    beats = [
        _beat("B1", "title_aligned_spiritual_stake", (0.0, 0.0), (0.04, 0.08),
              "State a concrete spiritual conflict, consequence, or promise in the viewer's terms.",
              "Resolve packaging ambiguity and create one precise open loop.",
              ["warning", "contradiction", "identity pressure", "urgent declaration"]),
        _beat("B2", "personal_stakes", (0.04, 0.08), (0.18, 0.30),
              "Translate the spiritual thesis into a recognizable decision, fear, delay, or cost.",
              "Make the question personally consequential without adding a second thesis.",
              ["micro-story", "symptom sequence", "contrast", "specific scenario"]),
        _beat("B3", "mechanism_and_proof", (0.18, 0.30), (0.48, 0.62),
              "Explain how the pressure works and provide context-preserving authority or evidence.",
              "Pay off the first loop and open a practical one.",
              ["scripture explained", "licensed expert excerpt", "historical context", "analogy"]),
        _beat("B4", "reversal_and_action", (0.48, 0.62), (0.76, 0.88),
              "Replace the false response with a concrete faithful response.",
              "Convert interpretation into escalating action and micro-payoffs.",
              ["three-step response", "belief reversal", "decision ladder", "identity reframe"]),
        _beat("B5", "promise_resolution", (0.76, 0.88), (0.96, 1.0),
              "Resolve the exact title promise in a memorable original line and one next action.",
              "Deliver satisfaction; do not introduce an unrelated topic.",
              ["identity resolution", "prayer/action", "single reflective question", "brief CTA after payoff"]),
    ]
    archetype_refs = full_refs + opening_refs + ["claim:C-NARRATIVE-PROGRESSION", "claim:C-HOOK-SEMANTIC"]
    archetype = {
        "archetype_id": "A-LONG-DIRECT-SPIRITUAL-STAKES-V1",
        "name": "Direct Spiritual Stakes to Identity/Action Payoff",
        "function": "Turn an English Christian-motivation tension into a concrete spiritual mechanism, evidence, and an original action/identity resolution.",
        "audience_intent": "Belief-aligned viewers seeking meaning, courage, discernment, and a next faithful action during pressure or uncertainty.",
        "compatible_topics": ["spiritual warfare", "divine timing", "faith under pressure", "identity and calling", "God's silence", "obedience", "restoration"],
        "incompatible_topics": ["unsupported date prophecy", "fearbait without resolution", "generic chosen-one superiority", "political claim without evidence", "unlicensed sermon compilation"],
        "packaging_rules": [
            _rule("P1", "Define one tension + one spiritual consequence; title and thumbnail must form one promise, not two competing ideas.", ["claim:C-PACKAGING-REPEAT", "claim:C-OWNED-IDENTITY"], owned_packaging_confidence),
            _rule("P2", "Use HeroVerse-specific second-person identity/timing language only when the body can prove and resolve it; do not copy the reference suffix or typography.", ["claim:C-OWNED-IDENTITY"], owned_packaging_confidence),
            _rule("P3", "Thumbnail adds a consequence or contradiction in 1–4 original words and never repeats the exact title.", ["gold:hkf6nDyUfAM", "gold:_sOy7htXJi8", "gold:huvUy3pJSp8"], round(narrative_confidence, 6)),
        ],
        "hook_rules": [
            _rule("H1", "0–1s: state a concrete tension or contradiction; no greeting, logo-only bumper, or contextless dialogue.", ["claim:C-HOOK-WEAK-START", "gold:huvUy3pJSp8"], round(opening_confidence, 6)),
            _rule("H2", "1–3s: name the spiritual anchor and the personal consequence promised by the packaging.", ["claim:C-HOOK-SEMANTIC"], round(opening_confidence, 6)),
            _rule("H3", "3–8s: reveal the mechanism or proof direction and open one answerable loop.", ["artifact:p3-openings", "gold:hkf6nDyUfAM", "gold:_sOy7htXJi8"], round(opening_confidence, 6)),
            _rule("H4", "8–30s: pay off the first claim with context and stakes; do not delay the advertised topic behind cinematic dialogue.", ["gold:huvUy3pJSp8", "gold:Pkede5acSFw"], round(narrative_confidence, 6)),
            _rule("H5", "Treat cut density and speech-start time as production variables, not success invariants.", ["claim:C-TIMING-NOT-SEPARATOR", "claim:C-CUTS-NOT-SEPARATOR"], round(opening_confidence, 6)),
        ],
        "beat_sheet": beats,
        "invariants": [
            _rule("I1", "One packaging promise remains the controlling thesis from hook through payoff.", ["gold:hkf6nDyUfAM", "gold:_sOy7htXJi8", "gold:huvUy3pJSp8"], round(narrative_confidence, 6)),
            _rule("I2", "The first audible unit is self-contained and reaches a concrete spiritual anchor without borrowed context.", ["claim:C-HOOK-SEMANTIC", "claim:C-HOOK-WEAK-START"], round(opening_confidence, 6)),
            _rule("I3", "Progression includes stake, mechanism/proof, reversal/action, and title-aligned resolution.", ["claim:C-NARRATIVE-PROGRESSION"], round(narrative_confidence, 6)),
            _rule("I4", "Every third-party clip has a rights status, truthful context, provenance, and named narrative job.", ["artifact:p3-coverage"], 1.0),
        ],
        "variables": [
            _rule("V1", "Topic, angle, scripture, example, emotion, visual world, CTA, and proof source are replaceable slots.", full_refs, round(narrative_confidence, 6)),
            _rule("V2", "Beat duration may move inside observed ratio ranges; five to seven complete segments were observed.", full_refs, round(narrative_confidence, 6)),
            _rule("V3", "Original narration, licensed excerpt, public-domain image, motion graphic, self-shot footage, or typography may perform a beat when rights and context pass.", ["artifact:p3-coverage"], 1.0),
        ],
        "prohibited": [
            _rule("X1", "Do not reuse the reference channel's exact title suffix, logo, thumbnail composition, cinematic sequence, wording, voice, or music identity.", ["claim:C-PACKAGING-REPEAT", "artifact:p3-coverage"], 1.0),
            _rule("X2", "Do not reorder a source speech to reverse meaning, hide provenance, evade Content ID, or treat public availability as permission.", ["artifact:p3-coverage"], 1.0),
            _rule("X3", "Do not use a percentage-of-change rule as proof of originality or rights.", ["artifact:master-spec"], 1.0),
            _rule("X4", "Do not make prophecy dates, guaranteed divine claims, or monetization/RPM claims without evidence.", ["claim:C-RPM-UNAVAILABLE", "artifact:p3-snapshots"], 1.0),
        ],
        "visual_grammar": [
            _rule("VG1", "Assign each visual a semantic job (stake, evidence, contrast, mechanism, action, payoff) before sourcing it.", full_refs, round(narrative_confidence, 6)),
            _rule("VG2", "Build a HeroVerse-owned palette and composition system; similarity to medieval/battle imagery is optional, never an identity requirement.", ["claim:C-OWNED-IDENTITY", "artifact:p3-coverage"], owned_packaging_confidence),
            _rule("VG3", "Use on-screen text only at structural turns and keep it original, legible, and non-duplicative of the complete title.", ["gold:hkf6nDyUfAM", "gold:_sOy7htXJi8"], round(narrative_confidence, 6)),
        ],
        "audio_grammar": [
            _rule("AG1", "Use an authorized English narrator with clear, controlled escalation; voice cloning requires explicit rights and is otherwise prohibited.", ["artifact:p3-coverage"], 1.0),
            _rule("AG2", "Music supports beat transitions and payoff but must not mask speech; every track requires a reusable-rights record.", ["artifact:p3-coverage"], 1.0),
            _rule("AG3", "Third-party speech is evidence or contrast, not the entire narrative spine; preserve its context and identify its job.", full_refs, round(narrative_confidence, 6)),
        ],
        "examples": [
            {"video_id": "hkf6nDyUfAM", "reason": "Winner: concrete warfare packaging, armor-of-God anchor, escalating mechanism, daily resistance, and Christ-centered resolution.", "evidence_refs": ["gold:hkf6nDyUfAM", "cohort:grace-winner-q1"]},
            {"video_id": "_sOy7htXJi8", "reason": "Winner/recent: confrontation becomes urgency, prophecy, practical orders, and personal responsibility.", "evidence_refs": ["gold:_sOy7htXJi8", "cohort:grace-winner-q1"]},
        ],
        "counterexamples": [
            {"video_id": "huvUy3pJSp8", "reason": "Weak: title promises purpose, but contextless cinematic dialogue delays the religious premise to about 41 seconds.", "evidence_refs": ["gold:huvUy3pJSp8", "cohort:grace-weak-q4"]},
            {"video_id": "Pkede5acSFw", "reason": "Median: thesis starts clearly, but thumbnail/action-film world and final visual silence weaken proof/payoff alignment.", "evidence_refs": ["gold:Pkede5acSFw", "cohort:grace-median-q2-q3"]},
        ],
        "duration_range_ms": duration_range_ms,
        "production_complexity": "HIGH; clip-based rights review, semantic continuity, narration, sound design, and visual QA required.",
        "estimated_cost_range": None,
        "evidence_refs": archetype_refs,
        "confidence": round(narrative_confidence, 6),
    }

    generation_spec = {
        "generation_spec_id": "GS-LONG-DIRECT-SPIRITUAL-STAKES-V1",
        "archetype_id": archetype["archetype_id"],
        "readiness": "CANDIDATE_FOR_PILOT_REVIEW",
        "input_requirements": [
            "One English audience tension and one answerable spiritual/editorial question.",
            "One original thesis and title-payoff statement written for HeroVerse.",
            "A source manifest containing only owned, public-domain, licensed, or review-approved assets.",
            "At least one context-preserving proof source; scripture must be cited and interpreted in context.",
            "A rights status, provenance URI, intended narrative job, and timecode for every clip candidate.",
        ],
        "editorial_question": "What precise spiritual tension is the viewer facing, what mechanism explains it, and what truthful action/identity resolution can this video earn?",
        "packaging": {
            "sequence": ["audience tension", "single promise", "title variants", "thumbnail concepts", "combined-promise check"],
            "title_templates": [
                "Why [SPIRITUAL TENSION] Is Not [FEARED MEANING]",
                "The Battle Behind [RECOGNIZABLE STRUGGLE]",
                "Before You [REACTION], Understand [SPIRITUAL MECHANISM]",
            ],
            "thumbnail_rule": "1–4 original words that add consequence or contradiction; never copy the reference layout or repeat the whole title.",
            "reject_if": "The hook cannot name and start resolving the same promise in eight seconds.",
        },
        "hook": {
            "0_1_seconds": "Concrete tension/contradiction in the viewer's terms.",
            "1_3_seconds": "Spiritual anchor + personal consequence.",
            "3_8_seconds": "Mechanism/proof direction + one answerable open loop.",
            "8_30_seconds": "First payoff, context, stakes, and transition to the body.",
            "forbidden": ["greeting", "logo-only bumper", "contextless borrowed dialogue", "generic affirmation", "unearned prophecy", "more than one controlling promise"],
        },
        "narrative": beats,
        "clip_policy": {
            "primary_mode": "CLIP_BASED_WITH_ORIGINAL_NARRATIVE",
            "eligible_rights_status": ["OWNED", "PUBLIC_DOMAIN_VERIFIED", "LICENSE_VERIFIED", "EDITORIAL_LEGAL_REVIEW_APPROVED"],
            "requirements": ["truthful context", "provenance", "timecode", "named narrative job", "no watermark removal", "no Content-ID evasion"],
            "percentage_rule": "NONE; no modification percentage guarantees originality or rights.",
        },
        "originality_controls": [
            "Write thesis, sequence, transitions, payoff, title, thumbnail, narration, and visual concept for HeroVerse from a blank document.",
            "Use references only for mechanism evidence; never use one source video's order as the new timeline.",
            "Compare semantic sequence, wording, visual identity, audio identity, and source concentration against every reference before release.",
            "Require substantive new purpose/context for each excerpt and reject cosmetic transformations.",
        ],
        "quality_gates": [
            "Packaging contains one precise promise and hook matches it by 0–8s.",
            "All five functional beats exist, each with a micro-payoff and evidence refs.",
            "No segment exists solely as decorative footage or borrowed rhetoric.",
            "Final payoff answers the title without unsupported certainty.",
            "Rights manifest has no UNKNOWN or analysis-only asset in a production slot.",
            "Narration is intelligible; audio peaks, captions, black frames, and render settings pass technical QA.",
            "Model confidence and untested hypotheses remain visible in the production review.",
        ],
        "rejection_rules": [
            "Reject if the opening depends on missing source context or delays the advertised subject past eight seconds.",
            "Reject if title/thumbnail resembles a reference identity more than the HeroVerse concept.",
            "Reject if proof is absent, decontextualized, or replaced by fearbait/chosen-one superiority.",
            "Reject if any clip's rights or provenance is unresolved.",
            "Reject if the timeline reproduces a reference's distinctive take or rhetorical sequence.",
        ],
        "excluded_actions": ["render", "upload", "publish", "spend", "Ads", "rights exception", "voice cloning"],
        "evidence_refs": archetype_refs + ["artifact:acquisition-contract"],
    }

    cases = [
        _case("hkf6nDyUfAM", "WINNER", "Strong promise-to-body fit: warfare immediately becomes armor, threat, authority, daily resistance, and Christ-centered resolution.",
              ["concrete spiritual subject", "high opening alignment", "six-stage escalation", "title-aligned payoff"],
              ["silent/brand delay", "public cohort cannot reveal retention"]),
        _case("_sOy7htXJi8", "WINNER", "Confrontational opening, urgency, eschatological mechanism, ordered actions, and personal-responsibility close explain archetype fit.",
              ["action-oriented stakes", "progression to practical orders", "strong payoff"],
              ["title subject becomes explicit after the initial confrontation"]),
        _case("Pkede5acSFw", "MEDIAN", "The thesis starts clearly and progresses through protection/adversary logic, but visual fantasy/action mismatch and a long silent end weaken earned proof/payoff.",
              ["clear thesis", "mechanism and protection payoff"],
              ["thumbnail/body visual mismatch", "action montage does not prove theological claims", "long visual silence"]),
        _case("huvUy3pJSp8", "WEAK", "The eventual restoration thesis is coherent, but the opening spends about 41 seconds in abstract cinematic dialogue before defining the spiritual promise.",
              ["coherent late mechanism", "strong eventual resolution"],
              ["context-dependent dialogue", "low first-30s topic alignment", "late religious premise"]),
    ]

    scores = {
        "format_repeatability_score": {
            "value": round(format_repeatability_score, 6), "scale": "0-1 higher is more repeatable",
            "formula": "0.35*title_suffix_rate + 0.25*mean(max(0,winner_anchor-weak_anchor),max(0,weak_weak_start-winner_weak_start)) + 0.25*full_case_progression_rate + 0.15*share_duration_210_300s",
            "inputs": ["claim:C-PACKAGING-REPEAT", "claim:C-HOOK-SEMANTIC", "claim:C-NARRATIVE-PROGRESSION", "artifact:p3-snapshots"],
            "confidence": round(narrative_confidence, 6), "limitations": ["Only four complete narratives; score is a deterministic coverage/recurrence index, not a performance probability."],
        },
        "evidence_confidence_score": {
            "value": round(evidence_coverage_score, 6), "scale": "0-1 higher is deeper reference-video coverage",
            "formula": "(4 FULL*1.00 + 13 OPENING_ONLY*0.55 + 7 METADATA_ONLY*0.25) / 24 reference videos",
            "inputs": ["artifact:p3-coverage", "artifact:p3-openings", "artifact:p3-snapshots", "claim:C-RPM-UNAVAILABLE"],
            "confidence": 1.0, "limitations": ["Weights are frozen evidence-depth weights; score describes coverage, not statistical confidence or performance probability."],
        },
        "originality_control_coverage_score": {
            "value": 1.0, "scale": "0-1 share of six required originality-control slots specified",
            "formula": "specified original slots / 6: title, thumbnail, voice, rhetorical sequence, visual system, payoff",
            "inputs": ["claim:C-OWNED-IDENTITY", "artifact:p3-coverage"],
            "confidence": 1.0, "limitations": ["Control coverage does not prove that a future blueprint or render is original; both require independent audit."],
        },
        "policy_exposure_screen_score": {
            "value": 0.8, "scale": "0-1 share of five predefined policy exposure flags present",
            "formula": "4 present flags / 5 screened: clip-based reuse, unresolved reference rights, automation/repetition, prophecy-overclaim; voice-clone request absent",
            "inputs": ["artifact:p3-coverage", "artifact:acquisition-contract"],
            "confidence": 1.0, "limitations": ["This is a binary exposure screen, not a probability of policy action or legal conclusion."],
        },
        "cross_channel_validation_score": {
            "value": 0.0, "scale": "0-1 share of required independent channels with full mined confirmation",
            "formula": "0 independent channels with FULL_VALIDATED narrative confirmation / minimum target 3",
            "inputs": ["cohort:cross-channel-public-velocity", "artifact:p3-coverage"],
            "confidence": 1.0, "limitations": ["Cross-channel metadata exists but does not count as narrative-mechanism validation."],
        },
        "rpm_evidence_score": {
            "value": 0.0, "scale": "0-1 higher means actual owned RPM evidence",
            "formula": "1 if authenticated owned RPM series exists and is sufficient; otherwise 0",
            "inputs": ["claim:C-RPM-UNAVAILABLE"],
            "confidence": 1.0, "limitations": ["No economic ranking is permitted before owned post-YPP data."],
        },
    }

    hypotheses = [
        {
            "hypothesis_id": "H-HOOK-DIRECT-ANCHOR",
            "status": "CANDIDATE",
            "statement": "For HeroVerse long-form, a title-aligned spiritual anchor and personal consequence in the first eight seconds will outperform delayed/context-dependent dialogue on 30-second retention.",
            "falsification_condition": "Reject if, across at least six comparable owned long-form releases with age-matched measurement, direct-anchor openings do not improve 30-second retention versus the preregistered baseline beyond uncertainty.",
            "supporting_evidence": ["claim:C-HOOK-SEMANTIC", "claim:C-HOOK-WEAK-START", "gold:huvUy3pJSp8"],
            "contradicting_evidence": ["opening:DoCCRjPTE6s", "opening:N2mdHZDRYB0", "opening:_sOy7htXJi8"],
            "confidence": round(opening_confidence, 6),
            "test_design": "Preregister six long-form pilots; hold topic/length/age window as comparable as possible; vary only opener class; evaluate owned 30s retention with interval and baseline.",
        },
        {
            "hypothesis_id": "H-LONG-WATCH-HOUR-PATH",
            "status": "CANDIDATE",
            "statement": "Given HeroVerse's current 20-Short/1-long catalog and the evidence-sufficient long archetype, long-form is the primary test path for qualified watch hours; Shorts remain supporting discovery tests.",
            "falsification_condition": "Suspend if comparable owned long-form pilots fail watch-hours-per-production-hour and subscriber conversion stop rules while Shorts show materially stronger qualified organic progress.",
            "supporting_evidence": ["artifact:p3-snapshots", "artifact:acquisition-contract", "claim:C-NARRATIVE-PROGRESSION"],
            "contradicting_evidence": ["claim:C-RPM-UNAVAILABLE"],
            "confidence": round(narrative_confidence, 6),
            "test_design": "Measure owned long vs Short organic outcomes at fixed ages; exclude paid views/hours/subscribers; compare qualified watch hours, subscriber conversion, and production time with uncertainty.",
        },
        {
            "hypothesis_id": "H-SEMANTIC-VISUAL-JOB",
            "status": "CANDIDATE",
            "statement": "Assigning every clip a narrative job and semantic relation to the spoken beat will reduce promise/body mismatch versus generic cinematic montage.",
            "falsification_condition": "Reject if blind editorial review and owned retention diagnostics show no improvement in alignment or segment drop-off against the preregistered baseline.",
            "supporting_evidence": ["gold:hkf6nDyUfAM", "gold:Pkede5acSFw", "artifact:p3-coverage"],
            "contradicting_evidence": ["claim:C-CUTS-NOT-SEPARATOR"],
            "confidence": round(narrative_confidence, 6),
            "test_design": "Blind-score blueprint/render semantic alignment before publication; compare segment retention and reviewer agreement after publication.",
        },
        {
            "hypothesis_id": "H-RPM-LONG-VS-SHORT",
            "status": "CANDIDATE",
            "statement": "Long-form may produce higher owned RPM/value per qualified view than Shorts, but the direction and magnitude are unknown for HeroVerse.",
            "falsification_condition": "Replace with observed rule only after YPP and a sufficient owned series; reject the direction if age/topic-adjusted actual net value does not exceed Shorts.",
            "supporting_evidence": ["artifact:acquisition-contract"],
            "contradicting_evidence": ["claim:C-RPM-UNAVAILABLE"],
            "confidence": 0.0,
            "test_design": "After YPP, compare authenticated RPM, net contribution, watch hours and production cost by format; do not optimize on CPM proxies.",
        },
    ]

    model = {
        "schema_version": "1.0.0",
        "model_id": "heroverse-channel-model-v1",
        "created_at": data["summary"]["captured_at"],
        "channel_scope": {
            "primary_channel_ids": [channel_ids["@heroverse74"]],
            "comparison_channel_ids": [channel_id for channel_id, handle in channels.items() if handle != "@heroverse74"],
            "video_analysis_ids": [f"gold:{video_id}" for video_id in GOLD_IDS] + [f"opening:{item['video_id']}" for item in opening_features],
        },
        "cohorts": [
            {
                "cohort_id": cohort["cohort_id"], "kind": cohort["kind"],
                "selection_rule": cohort["selection_rule"],
                "video_analysis_ids": [member["video_id"] for member in cohort["members"]],
                "limitations": cohort["limitations"],
            }
            for cohort in data["cohorts"]["cohorts"]
        ],
        "channel_dna": {
            "audience": "English-speaking, belief-aligned Christian viewers facing uncertainty, delay, spiritual pressure, identity questions, or fear and seeking meaning plus a concrete faithful response.",
            "job_to_be_done": "Convert an emotionally charged struggle into a biblically framed mechanism, discernment, and one actionable identity/faith response without pretending certainty the evidence cannot support.",
            "core_desires": ["discernment", "courage", "divine meaning", "identity and calling", "hope under pressure", "a concrete next action"],
            "editorial_promise": "HeroVerse explains the spiritual tension behind a recognizable struggle and earns an original action/identity payoff in concise cinematic English storytelling.",
            "point_of_view": "Pressure is not automatically proof of rejection or chosen superiority; meaning must be argued with context, evidence, humility, and a faithful response.",
            "differentiation": [
                "Direct second-person tension from the existing HeroVerse packaging, but without generic chosen-one flattery.",
                "Mechanism and contextual proof before emotional crescendo.",
                "Clip-based cinematic language whose sources are rights-audited and semantically assigned, not copied from a reference identity.",
                "Explicit separation of observed evidence, hypothesis, and unavailable divine/platform/economic certainty.",
            ],
            "pillars": ["spiritual pressure and warfare", "divine timing and silence", "identity/calling with responsibility", "faithful action and obedience", "restoration and hope"],
            "topic_map": ["fear→faith", "delay→preparation", "silence→discernment", "attack→response", "brokenness→restoration", "calling→responsibility"],
            "identity": {
                "verbal": ["English", "direct second person", "concrete spiritual tension", "humble certainty boundaries", "original concise payoff"],
                "visual": ["CANDIDATE: HeroVerse-owned visual system must be created; reference medieval/battle identity is not inherited.", "Each visual is tagged by narrative job and rights status."],
                "audio": ["CANDIDATE: authorized English narrator with controlled escalation.", "No cloned reference voice; licensed music and intelligible speech are mandatory."],
            },
            "packaging_grammar": ["one tension + one consequence + one answerable promise", "second-person relevance when body evidence supports it", "thumbnail adds contradiction/consequence rather than copying title"],
            "retention_mechanisms": ["promise confirmation by 0–8s", "personal stakes", "mechanism/proof payoff", "one open loop at a time", "reversal into action", "title-aligned identity resolution"],
            "payoff_patterns": ["misinterpretation corrected", "spiritual mechanism clarified", "concrete response", "identity reframed without superiority claim", "brief action after earned resolution"],
            "risks": ["reused-content/YPP risk", "unresolved clip rights", "generic mass-produced repetition", "fearbait/prophecy overclaim", "chosen-one superiority", "copied reference identity", "RPM optimization without actual data"],
            "evidence_refs": ["claim:C-OWNED-IDENTITY", "claim:C-NARRATIVE-PROGRESSION", "claim:C-RPM-UNAVAILABLE"] + base_refs,
            "confidence": round(min(narrative_confidence, owned_packaging_confidence), 6),
        },
        "format_archetypes": [archetype],
        "scores": scores,
        "hypotheses": hypotheses,
        "evidence_matrix": evidence_matrix,
        "generation_specs": [generation_spec],
        "retrospective_validation": {
            "method": "Frozen public quartiles by views per complete day; four full cases explain narrative differences; 13 Phase-2 holdout opening files measure only 0–30s mechanics.",
            "development_sample_ids": [f"gold:{video_id}" for video_id in GOLD_IDS],
            "holdout_opening_ids": [f"opening:{item['video_id']}" for item in opening_features if item["holdout_from_phase2"]],
            "case_explanations": cases,
            "metrics": {
                "full_case_count": 4,
                "opening_case_count": 16,
                "opening_holdout_count": 13,
                "winner_spiritual_anchor_first_20_rate": winner_anchor_rate,
                "weak_spiritual_anchor_first_20_rate": weak_anchor_rate,
                "winner_weak_start_rate": winner_weak_start_rate,
                "weak_weak_start_rate": weak_weak_start_rate,
                "winner_first_speech_median_seconds": winner_speech_median,
                "weak_first_speech_median_seconds": weak_speech_median,
                "winner_cuts_0_30_median": winner_cuts_median,
                "weak_cuts_0_30_median": weak_cuts_median,
            },
            "causal_claims_permitted": False,
            "limitations": ["No retention/CTR/impressions.", "Only four full narratives.", "Holdout is relative to Phase 2 fixtures, not necessarily to all earlier heuristic development.", "Public views/day is age-normalized but not audience- or traffic-source-normalized."],
        },
        "knowledge_state": [
            {"knowledge_id": "K1", "status": "OBSERVED", "scope": "CHANNEL", "statement": "HeroVerse has 1 public long-form and 20 public Shorts in the frozen capture.", "evidence_refs": ["artifact:p3-snapshots"]},
            {"knowledge_id": "K2", "status": "CALCULATED", "scope": "ARCHETYPE", "statement": "Grace quartiles contain 6 winner, 12 median, and 6 weak videos by public views per complete day.", "evidence_refs": ["artifact:p3-cohorts"]},
            {"knowledge_id": "K3", "status": "CANDIDATE", "scope": "ARCHETYPE", "statement": "The long-form archetype is fit for a controlled pilot review, not for scale.", "evidence_refs": ["claim:C-NARRATIVE-PROGRESSION", "claim:C-HOOK-SEMANTIC"]},
            {"knowledge_id": "K4", "status": "INCONCLUSIVE", "scope": "TRANSFER", "statement": "Cross-channel metadata does not prove the archetype transfers across independent channels.", "evidence_refs": ["cohort:cross-channel-public-velocity"]},
            {"knowledge_id": "K5", "status": "UNAVAILABLE", "scope": "ECONOMICS", "statement": "Actual RPM, revenue, margin, and YPP probability are unavailable.", "evidence_refs": ["claim:C-RPM-UNAVAILABLE"]},
        ],
        "economics": {
            "actual_rpm": None,
            "actual_revenue": None,
            "observed_cost_usd": 0.0,
            "value_hypotheses": ["Long-form may create more qualified watch-hour value than the existing Short catalog.", "Actual format RPM ranking must wait for owned post-YPP data."],
            "decision_use_permitted": False,
            "evidence_refs": ["claim:C-RPM-UNAVAILABLE", "artifact:acquisition-baseline", "artifact:acquisition-contract"],
        },
        "limitations": [
            "The model explains correlations and editorial differences; it does not predict views or guarantee YPP.",
            "Only four videos have full validated narrative/take coverage.",
            "The 13 additional opening holdouts cannot support body/payoff rules.",
            "HeroVerse Shorts have metadata but no audiovisual mining; no Shorts archetype is claimed.",
            "No actual RPM, revenue, CTR, retention, watch hours, or subscriber conversion exists in the approved dataset.",
            "Reference assets, wording, voice, layout, sequence, and identity are analysis-only and not production inputs.",
        ],
        "review_status": "NOT_REVIEWED",
    }
    return {
        "model": model,
        "opening_feature_table": opening_features,
        "input_hashes": {
            "phase3_summary": _sha(PHASE3_RUN / "phase3_summary.json"),
            "snapshots": _sha(PHASE3_RUN / "public_snapshots.json"),
            "cohorts": _sha(PHASE3_RUN / "cohorts.json"),
            "coverage": _sha(PHASE3_RUN / "coverage.json"),
            "openings": _sha(PHASE3_RUN / "opening_observations.json"),
            **{f"gold_{video_id}": _sha(ROOT / "data" / "gold_standard" / video_id / "video_mining.json") for video_id in GOLD_IDS},
        },
    }


def evidence_ref_errors(model: dict[str, Any]) -> list[str]:
    data = _inputs()
    snapshot_video_ids = {item["entity_id"] for item in data["snapshots"] if item["entity_type"] == "VIDEO"}
    opening_ids = {item["video_id"] for item in data["openings"]["records"]}
    cohort_ids = {item["cohort_id"] for item in data["cohorts"]["cohorts"]}
    claim_ids = {item["claim_id"] for item in model["evidence_matrix"]}
    allowed_artifacts = {
        "artifact:p3-snapshots", "artifact:p3-cohorts", "artifact:p3-coverage", "artifact:p3-openings",
        "artifact:acquisition-baseline", "artifact:acquisition-contract", "artifact:master-spec",
    }

    refs: list[str] = []
    def visit(value: Any, key: str | None = None) -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                visit(child, child_key)
        elif isinstance(value, list):
            if key in {"evidence_refs", "supporting_evidence", "contradicting_evidence"}:
                refs.extend(item for item in value if isinstance(item, str))
            for child in value:
                visit(child, key)
    visit(model)
    errors = []
    for ref in sorted(set(refs)):
        if ref in allowed_artifacts:
            continue
        prefix, _, value = ref.partition(":")
        valid = (
            (prefix == "gold" and value in GOLD_IDS)
            or (prefix == "opening" and value in opening_ids)
            or (prefix == "cohort" and value in cohort_ids)
            or (prefix == "snapshot" and value in snapshot_video_ids)
            or (prefix == "claim" and value in claim_ids)
        )
        if not valid:
            errors.append(ref)
    return errors


def _markdown(model: dict[str, Any]) -> str:
    archetype = model["format_archetypes"][0]
    metrics = model["retrospective_validation"]["metrics"]
    lines = [
        "# HeroVerse — ChannelModel v1",
        "",
        f"Status: `{model['review_status']}`. Arquétipo: `{archetype['archetype_id']}`.",
        "",
        "## Decisão central",
        "",
        "O único arquétipo com evidência suficiente para piloto é long-form: promessa espiritual direta → mecanismo/prova → reversão/ação → payoff de identidade. Shorts permanecem hipótese porque só há metadados, sem mineração audiovisual.",
        "",
        "## Evidência que diferencia coortes",
        "",
        f"- Âncora espiritual nos primeiros 20 termos falados: {metrics['winner_spiritual_anchor_first_20_rate']:.0%} nos vencedores vs {metrics['weak_spiritual_anchor_first_20_rate']:.0%} nos fracos.",
        f"- Início fraco/dependente de contexto: {metrics['winner_weak_start_rate']:.0%} nos vencedores vs {metrics['weak_weak_start_rate']:.0%} nos fracos.",
        f"- Início da fala: {metrics['winner_first_speech_median_seconds']:.2f}s vs {metrics['weak_first_speech_median_seconds']:.2f}s; não separou desempenho.",
        f"- Cortes 0–30s: mediana {metrics['winner_cuts_0_30_median']:.1f} vs {metrics['weak_cuts_0_30_median']:.1f}; quantidade isolada não separou desempenho.",
        "",
        "## Arquétipo recomendado",
        "",
        f"**{archetype['name']}** — {archetype['function']}",
        "",
        "### Hook obrigatório",
        "",
    ]
    lines.extend(f"- {rule['description']}" for rule in archetype["hook_rules"])
    lines.extend(["", "### Progressão", ""])
    lines.extend(f"- `{beat['beat_id']}` {beat['role']}: {beat['objective']}" for beat in archetype["beat_sheet"])
    lines.extend(["", "### Proibições", ""])
    lines.extend(f"- {rule['description']}" for rule in archetype["prohibited"])
    lines.extend(["", "## Economia e previsibilidade", "", "RPM, receita, watch hours qualificadas, CTR e retenção continuam indisponíveis. Long-form é hipótese primária de teste, não promessa de monetização.", "", "## Condição de avanço", "", "O arquétipo está `CANDIDATE_FOR_PILOT_REVIEW`. Produção só pode começar após gate da Fase 4 e confirmação do arquétipo; direitos e publicação continuam protegidos."])
    return "\n".join(lines)


def materialize_channel_model(output_dir: Path = OUTPUT_DIR) -> dict[str, Any]:
    built = build_channel_model()
    model = built["model"]
    schema = _read(ROOT / "schemas" / "channel_model.schema.json")
    schema_errors = [
        f"{'/'.join(str(part) for part in error.absolute_path) or '<root>'}: {error.message}"
        for error in Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(model)
    ]
    ref_errors = evidence_ref_errors(model)
    if schema_errors or ref_errors:
        raise RuntimeError(json.dumps({"schema_errors": schema_errors, "reference_errors": ref_errors}, ensure_ascii=False))
    output_dir.mkdir(parents=True, exist_ok=True)
    _write(output_dir / "channel_model.json", model)
    _write(output_dir / "evidence_matrix.json", {
        "schema_version": "1.0.0",
        "model_id": model["model_id"],
        "claims": model["evidence_matrix"],
        "opening_feature_table": built["opening_feature_table"],
        "input_hashes": built["input_hashes"],
        "reference_errors": ref_errors,
    })
    (output_dir / "channel_model.md").write_text(_markdown(model), encoding="utf-8")
    entries = []
    for path in sorted(item for item in output_dir.iterdir() if item.is_file() and item.name != "integrity_manifest.json"):
        entries.append({"artifact": path.relative_to(ROOT).as_posix(), "size_bytes": path.stat().st_size, "sha256": _sha(path)})
    integrity = {"schema_version": "1.0.0", "algorithm": "SHA-256", "item_count": len(entries), "entries": entries}
    _write(output_dir / "integrity_manifest.json", integrity)
    return {
        "status": "AWAITING_REVIEW",
        "model_id": model["model_id"],
        "review_status": model["review_status"],
        "model": str(output_dir / "channel_model.json"),
        "evidence_matrix": str(output_dir / "evidence_matrix.json"),
        "report": str(output_dir / "channel_model.md"),
        "integrity": str(output_dir / "integrity_manifest.json"),
        "schema_errors": schema_errors,
        "reference_errors": ref_errors,
        "archetypes": [item["archetype_id"] for item in model["format_archetypes"]],
        "generation_specs": [item["generation_spec_id"] for item in model["generation_specs"]],
        "actual_rpm": model["economics"]["actual_rpm"],
        "external_api_cost_usd": 0.0,
        "protected_actions_executed": [],
    }
