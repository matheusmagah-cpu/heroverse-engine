from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path


ATOMIC_UTF8_WRITER_VERSION = "atomic-utf8-writer-v1"


def atomic_write_utf8(path: Path, content: str) -> None:
    """Atomically replace one UTF-8 view with bounded Windows-lock retries.

    The encoded payload is complete before the destination directory or an
    exclusive, writer-owned temporary file is created.  A failed call removes
    only that temporary file and never changes the prior destination bytes.
    """

    payload = content.encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent,
    )
    temporary = Path(name)
    owned_descriptor: int | None = descriptor
    try:
        stream = os.fdopen(descriptor, "wb")
        owned_descriptor = None
        with stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.05 * (attempt + 1))
    except BaseException as error:
        if owned_descriptor is not None:
            try:
                os.close(owned_descriptor)
            except OSError as close_error:
                error.add_note(
                    f"Could not close owned atomic-write temp descriptor: {close_error}"
                )
        try:
            temporary.unlink(missing_ok=True)
        except OSError as cleanup_error:
            error.add_note(
                f"Could not remove owned atomic-write temp {temporary}: {cleanup_error}"
            )
        raise
