from __future__ import annotations

import hashlib
import copy
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import Image, ImageDraw, ImageFont


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
V3 = Path("output/production/phase5/pilot-001/creative-v3")
DURATION_SECONDS = 18
TYPOGRAPHY_SUCCESSOR_VERSION = "HeroVerseLocalVectorMotion@2.0.0-layout"

SPECS = (
    {
        "asset_id": "asset-owned-truth-test-motion-v1",
        "semantic_role": "truth_test_infographic",
        "title": "THE TRUTH TEST",
        "subtitle": "Separate evidence from fear before choosing the next move.",
        "steps": ("WHAT I KNOW", "WHAT I ASSUME", "WHAT I CAN VERIFY"),
    },
    {
        "asset_id": "asset-owned-truth-evidence-motion-v1",
        "semantic_role": "truth_test_infographic",
        "title": "THE EVIDENCE LADDER",
        "subtitle": "Move from what happened to the next fact you can test.",
        "steps": ("OBSERVE", "VERIFY", "DECIDE"),
    },
    {
        "asset_id": "asset-owned-truth-meaning-motion-v1",
        "semantic_role": "truth_test_infographic",
        "title": "FACT BEFORE FEAR",
        "subtitle": "Keep an interpretation separate from the evidence it needs.",
        "steps": ("FACT", "MEANING", "NEXT TEST"),
    },
    {
        "asset_id": "asset-owned-truth-confirmation-motion-v1",
        "semantic_role": "truth_test_infographic",
        "title": "THE CONFIRMATION CHECK",
        "subtitle": "Test the claim before you let it direct your next move.",
        "steps": ("CHECK", "COMPARE", "ACT"),
    },
    {
        "asset_id": "asset-owned-responsibility-map-motion-v1",
        "semantic_role": "responsibility_map_infographic",
        "title": "THE RESPONSIBILITY MAP",
        "subtitle": "Own the action without pretending to control the outcome.",
        "steps": ("MINE TO OWN", "NOT MINE TO CONTROL", "ONE HONEST ACTION"),
    },
    {
        "asset_id": "asset-owned-today-timeline-motion-v1",
        "semantic_role": "today_timeline_infographic",
        "title": "THE NEXT 24 HOURS",
        "subtitle": "Make the faithful step small enough to finish.",
        "steps": ("NOW", "SCHEDULE", "COMPLETE"),
    },
    {
        "asset_id": "asset-owned-safety-network-motion-v1",
        "semantic_role": "safety_network_infographic",
        "title": "WISDOM DOESN'T FACE DANGER ALONE",
        "subtitle": "Serious risk calls for qualified support, not private drama.",
        "steps": ("EMERGENCY / MEDICAL", "LEGAL / SAFEGUARDING", "TRUSTED COUNSEL"),
    },
    {"asset_id": "asset-owned-scripture-context-motion-v1", "semantic_role": "scriptural_mechanism", "title": "READ THE CONTEXT", "subtitle": "Let the passage set the meaning before the feeling does.", "steps": ("READ", "CONTEXT", "RESPOND")},
    {"asset_id": "asset-owned-scripture-hear-motion-v1", "semantic_role": "scriptural_mechanism", "title": "ASK. HEAR. DO.", "subtitle": "Wisdom joins prayer, attention and one faithful response.", "steps": ("ASK", "HEAR", "DO")},
    {"asset_id": "asset-owned-scripture-practice-motion-v1", "semantic_role": "scriptural_mechanism", "title": "WISDOM BECOMES PRACTICE", "subtitle": "A tested truth becomes visible in the next honest action.", "steps": ("TRUTH", "PRACTICE", "FRUIT")},
    {"asset_id": "asset-owned-scripture-light-motion-v1", "semantic_role": "scriptural_mechanism", "title": "ENOUGH LIGHT", "subtitle": "You do not need perfect certainty to take one faithful step.", "steps": ("LIGHT", "STEP", "FOLLOW")},
    {"asset_id": "asset-owned-boundary-signal-motion-v1", "semantic_role": "safe_boundaries", "title": "NOTICE THE SIGNAL", "subtitle": "Name the risk before deciding what support is needed.", "steps": ("NOTICE", "NAME", "RESPOND")},
    {"asset_id": "asset-owned-boundary-support-motion-v1", "semantic_role": "safe_boundaries", "title": "BRING IN SUPPORT", "subtitle": "Wise boundaries make help specific and timely.", "steps": ("ASSESS", "CONTACT", "FOLLOW UP")},
    {"asset_id": "asset-owned-boundary-scope-motion-v1", "semantic_role": "safe_boundaries", "title": "KEEP THE BOUNDARY", "subtitle": "Care does not require you to carry what is not yours.", "steps": ("OWN", "LIMIT", "ESCALATE")},
    {"asset_id": "asset-owned-boundary-safety-motion-v1", "semantic_role": "safe_boundaries", "title": "SAFETY FIRST", "subtitle": "Urgent danger calls for qualified help, not private pressure.", "steps": ("RISK", "SAFETY", "HELP")},
    {"asset_id": "asset-owned-boundary-next-motion-v1", "semantic_role": "safe_boundaries", "title": "MAKE THE NEXT STEP SAFE", "subtitle": "Choose a response that protects people and tells the truth.", "steps": ("PAUSE", "PROTECT", "PROCEED")},
    {"asset_id": "asset-owned-cards-options-motion-v1", "semantic_role": "decision_cards", "title": "THREE HONEST OPTIONS", "subtitle": "Put the possible moves where you can test them.", "steps": ("OPTION", "EVIDENCE", "CHOICE")},
    {"asset_id": "asset-owned-cards-consequence-motion-v1", "semantic_role": "decision_cards", "title": "COUNT THE CONSEQUENCE", "subtitle": "A faithful choice considers its effect before its relief.", "steps": ("MOVE", "EFFECT", "RESPONSIBILITY")},
    {"asset_id": "asset-owned-cards-commit-motion-v1", "semantic_role": "decision_cards", "title": "CHOOSE ONE MOVE", "subtitle": "Turn the clearest faithful option into a concrete commitment.", "steps": ("CHOOSE", "SCHEDULE", "COMPLETE")},
    {"asset_id": "asset-owned-cards-review-motion-v1", "semantic_role": "decision_cards", "title": "REVIEW THE CHOICE", "subtitle": "Keep the decision visible long enough to test it honestly.", "steps": ("REVIEW", "TEST", "COMMIT")},
    {"asset_id": "asset-owned-decision-evidence-motion-v1", "semantic_role": "decision", "title": "DECIDE WITH EVIDENCE", "subtitle": "Let what is true lead before urgency does.", "steps": ("EVIDENCE", "CHARACTER", "ACTION")},
    {"asset_id": "asset-owned-decision-next-motion-v1", "semantic_role": "decision", "title": "THE NEXT FAITHFUL MOVE", "subtitle": "Small obedience is still a real decision.", "steps": ("NAME", "CHOOSE", "DO")},
    {"asset_id": "asset-owned-renewal-practice-motion-v1", "semantic_role": "renewal", "title": "RENEW THE PATTERN", "subtitle": "Repeat what is true until it becomes the practiced response.", "steps": ("REMEMBER", "REPEAT", "RENEW")},
    {"asset_id": "asset-owned-renewal-result-motion-v1", "semantic_role": "renewal", "title": "RECORD WHAT CHANGED", "subtitle": "A small faithful action creates evidence for the next one.", "steps": ("ACT", "RECORD", "GROW")},
    {"asset_id": "asset-owned-tension-pause-motion-v1", "semantic_role": "tension", "title": "PAUSE THE PRESSURE", "subtitle": "Urgency is not proof that a decision is wise.", "steps": ("PAUSE", "TEST", "RESPOND")},
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def compile_audio_static_composition(*, title: str, bible: dict, format_pack: dict,
                                     font: Path) -> dict:
    """Measure an original designed still; never inherit legacy motion approval."""
    from .phase6_visual_recipe import _Region, _place_copy, VisualRecipeContractError
    if (format_pack.get("format_pack_id") != "fp-narrated-reflection-static"
            or format_pack.get("version") != "1.0.0"
            or "format-pack:fp-narrated-reflection-static@1.0.0" not in
            bible.get("decision_history", [{}])[0].get("evidence_refs", [])):
        raise VisualRecipeContractError("static composition requires its exact Pack/Bible")
    typo = bible.get("typography", {})
    palette = dict(zip(("dominant", "accent", "text"),
                       format_pack["specification"]["palette"]["locked_hex"]))
    if (bible.get("palette", {}).get("role_map") != palette
            or typo.get("minimum_sizes", {}).get("1920x1080") != 54
            or typo.get("safe_area") != {"horizontal_percent": 8, "vertical_percent": 8}
            or "Arial" not in typo.get("families", [])
            or font.resolve() != (Path(r"C:\Windows\Fonts") / "arialbd.ttf").resolve()):
        raise VisualRecipeContractError("static composition diverges from declared typography/palette")
    text = _place_copy(role="audio-title", source=title, font_path=font,
                       preferred_size=80, region=_Region(180, 390, 1560, 240),
                       color=palette["text"], filename="audio-title.txt")
    value = {"version": "HeroVerseOwnedAudioStill@1.0.0", "title": title,
             "format_pack": copy.deepcopy(format_pack), "style_bible": copy.deepcopy(bible),
             "font": {"path": str(font.resolve()), "sha256": _sha256(font)},
             "canvas": {"width": 1920, "height": 1080}, "palette": palette,
             "texts": [text], "quality_authorized": False, "publication_authorized": False}
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    value["composition_id"] = "audio-still-" + hashlib.sha256(raw).hexdigest()
    return value


def _audio_static_pixels(layout: dict):
    """Shared deterministic pixels for producer and provenance reader."""
    from .phase6_visual_recipe import LINE_SPACING, TEXT_BORDER
    rebuilt = compile_audio_static_composition(title=layout["title"], bible=layout["style_bible"],
        format_pack=layout["format_pack"], font=Path(layout["font"]["path"]))
    if rebuilt != layout:
        raise PermissionError("static composition/font/input identity changed")
    image = Image.new("RGB", (1920, 1080), layout["palette"]["dominant"])
    draw = ImageDraw.Draw(image)
    draw.rectangle((180, 330, 1740, 338), fill=layout["palette"]["accent"])
    row = layout["texts"][0]
    face = ImageFont.truetype(layout["font"]["path"], size=row["font_size"])
    bbox = draw.multiline_textbbox((0, 0), row["render_text"], font=face,
                                  spacing=LINE_SPACING, stroke_width=TEXT_BORDER)
    draw.multiline_text((row["x"] - bbox[0], row["y"] - bbox[1]), row["render_text"],
        font=face, spacing=LINE_SPACING, fill=row["color"], stroke_width=TEXT_BORDER,
        stroke_fill=layout["palette"]["dominant"])
    # Pillow's textbbox includes glyph bearings/whitespace, not only painted
    # pixels. Observe the actual raster ink separately from the reserved box.
    from PIL import ImageChops
    region = image.crop((180, 390, 1740, 630))
    ink = ImageChops.difference(region, Image.new("RGB", region.size,
                               layout["palette"]["dominant"])).getbbox()
    if ink is None:
        raise PermissionError("static title produced no visible ink")
    observed = [ink[0] + 180, ink[1] + 390, ink[2] + 180, ink[3] + 390]
    bounds = row["bounds"]
    if not (bounds["left"] <= observed[0] < observed[2] <= bounds["right"]
            and bounds["top"] <= observed[1] < observed[3] <= bounds["bottom"]):
        raise PermissionError("static title ink leaves measured layout")
    return image, observed


def rasterize_audio_static_composition(layout: dict, output: Path) -> dict:
    """Existing procedural producer, explicit still branch, exclusive output."""
    image, observed = _audio_static_pixels(layout)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as stream:
        image.save(stream, format="PNG", optimize=True)
    return {"composition_id": layout["composition_id"], "raster": str(output.resolve()),
            "raster_hash": _sha256(output), "font_hash": layout["font"]["sha256"],
            "raster_bounds": observed,
            "quality_authorized": False, "publication_authorized": False}


def _audio_static_svg(layout: dict) -> bytes:
    # Vector source describes the same owned design. The reader independently
    # recomputes PNG pixels; it does not claim an SVG engine rendered the PNG.
    row = layout['texts'][0]
    lines = ''.join(f'<tspan x="{row["x"]}" dy="{0 if i == 0 else row["font_size"] + 12}">{escape(line)}</tspan>'
                    for i, line in enumerate(row['render_text'].split('\n')))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080">'
            f'<desc>{escape(layout["composition_id"])}</desc>'
            f'<rect width="1920" height="1080" fill="{layout["palette"]["dominant"]}"/>'
            f'<rect x="180" y="330" width="1561" height="9" fill="{layout["palette"]["accent"]}"/>'
            f'<text x="{row["x"]}" y="{row["y"] + row["font_size"]}" font-family="Arial" '
            f'font-weight="bold" font-size="{row["font_size"]}" fill="{row["color"]}">{lines}</text></svg>').encode('utf-8')


def build_audio_static_source(root: Path, directory: Path, *, layout: dict, verified_at: str) -> dict:
    """Produce a held source with verifiable provenance, not human review."""
    root, directory = root.resolve(), directory.resolve()
    if not directory.is_relative_to(root) or directory.exists():
        raise PermissionError('new static source needs an absent root-confined directory')
    _audio_static_pixels(layout)  # Validate before writes.
    directory.mkdir(parents=True)
    raster, vector = directory / 'composition.png', directory / 'composition.svg'
    produced = rasterize_audio_static_composition(layout, raster)
    with vector.open('xb') as stream: stream.write(_audio_static_svg(layout))
    generator = Path(__file__).resolve()
    manifest = {'version': layout['version'], 'layout': layout, 'produced': produced,
                'generator': {'path': str(generator), 'sha256': _sha256(generator)},
                'source_svg': str(vector), 'source_svg_hash': _sha256(vector)}
    manifest_path = directory / 'source-manifest.json'
    with manifest_path.open('x', encoding='utf-8') as stream:
        json.dump(manifest, stream, ensure_ascii=False, sort_keys=True, indent=2)
    evidence = {'schema_version': '1.0.0', 'asset_id': layout['composition_id'],
        'asset_type': 'PROJECT_OWNED_PROCEDURAL_STATIC', 'source_svg': str(vector),
        'source_svg_hash': _sha256(vector), 'raster': str(raster), 'raster_hash': _sha256(raster),
        'provider': layout['version'], 'ownership_basis': 'Locally generated geometric design and original supplied title; no third-party image, audio or photographed person.',
        'platform_disclosure': {'required': False, 'reason': 'Designed typography, not a realistic depiction of an event or person.'},
        'decision': 'AUTO_VERIFIED_PROCEDURAL_SOURCE', 'limitations': ['Source provenance only; no editorial, audio, quality or publication approval.'],
        'verified_at': verified_at, 'composition_manifest': {'path': str(manifest_path), 'sha256': _sha256(manifest_path)}}
    read_audio_static_source(root, manifest_path, expected_sha256=_sha256(manifest_path))
    with (directory / 'rights-evidence.json').open('x', encoding='utf-8') as stream:
        json.dump(evidence, stream, ensure_ascii=False, indent=2)
    return evidence


def read_audio_static_source(root: Path, path: Path, *, expected_sha256: str) -> dict:
    """Reopen bound source/font/generator, reproduce pixels, reject forged proof."""
    from io import BytesIO
    root = root.resolve()
    path = path.resolve()
    if not path.is_relative_to(root) or _sha256(path) != expected_sha256:
        raise PermissionError('static source manifest root/hash differs')
    raw = path.read_bytes()
    if 'sha256:' + hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise PermissionError('static manifest changed during capture')
    value = json.loads(raw)
    generator = value['generator']
    if Path(generator['path']).resolve() != Path(__file__).resolve() or _sha256(Path(__file__)) != generator['sha256']:
        raise PermissionError('static generator identity differs')
    image, observed = _audio_static_pixels(value['layout'])
    raster, vector = Path(value['produced']['raster']).resolve(), Path(value['source_svg']).resolve()
    captured = {}
    for target, expected in [(raster, value['produced']['raster_hash']), (vector, value['source_svg_hash'])]:
        if not target.is_relative_to(root): raise PermissionError('static source escaped root')
        content = target.read_bytes()
        if 'sha256:' + hashlib.sha256(content).hexdigest() != expected:
            raise PermissionError('static source bytes differ')
        captured[target] = content
    with Image.open(BytesIO(captured[raster])) as actual:
        if actual.mode != image.mode or actual.size != image.size or actual.tobytes() != image.tobytes():
            raise PermissionError('static raster not generated by bound layout')
    if (captured[vector] != _audio_static_svg(value['layout'])
            or value['produced']['composition_id'] != value['layout']['composition_id']
            or value['produced']['raster_bounds'] != observed):
        raise PermissionError('static source/layout correspondence differs')
    if (any(target.read_bytes() != content for target, content in captured.items()) or path.read_bytes() != raw
            or _sha256(Path(__file__)) != generator['sha256']
            or _sha256(Path(value['layout']['font']['path'])) != value['layout']['font']['sha256']):
        raise PermissionError('static source changed during verification')
    return value


def _svg(spec: dict[str, object]) -> str:
    title = escape(str(spec["title"]))
    subtitle = escape(str(spec["subtitle"]))
    steps = [escape(str(value)) for value in spec["steps"]]
    panels = []
    centers = (420, 960, 1500)
    for index, (center, label) in enumerate(zip(centers, steps), start=1):
        panels.append(
            f'<rect x="{center - 230}" y="505" width="460" height="250" rx="28" fill="#10283D" stroke="#D7A94A" stroke-width="4"/>'
            f'<circle cx="{center}" cy="555" r="28" fill="#D7A94A"/>'
            f'<text x="{center}" y="568" text-anchor="middle" class="number">{index}</text>'
            f'<text x="{center}" y="660" text-anchor="middle" class="step">{label}</text>'
        )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#06121F"/><stop offset="0.58" stop-color="#0B2033"/><stop offset="1" stop-color="#15344A"/></linearGradient>
  <pattern id="grid" width="64" height="64" patternUnits="userSpaceOnUse"><path d="M64 0H0V64" fill="none" stroke="#E8EDF2" stroke-opacity="0.035" stroke-width="2"/></pattern>
  <style>.title{{font:700 80px Arial,sans-serif;letter-spacing:3px;fill:#E8EDF2}}.subtitle{{font:400 34px Arial,sans-serif;fill:#B8C6D2}}.step{{font:700 28px Arial,sans-serif;letter-spacing:1px;fill:#E8EDF2}}.number{{font:700 28px Arial,sans-serif;fill:#081827}}</style>
</defs>
<rect width="1920" height="1080" fill="url(#bg)"/><rect width="1920" height="1080" fill="url(#grid)"/>
<rect x="150" y="172" width="18" height="184" rx="9" fill="#D7A94A"/>
<text x="215" y="245" class="title">{title}</text>
<text x="220" y="322" class="subtitle">{subtitle}</text>
<path d="M650 630H730M1190 630H1270" stroke="#D7A94A" stroke-width="8" stroke-linecap="round"/>
{''.join(panels)}
<rect x="190" y="850" width="1540" height="8" rx="4" fill="#203E54"/><rect x="190" y="850" width="1020" height="8" rx="4" fill="#D7A94A"/>
<text x="190" y="925" class="subtitle">TRUTH  /  RESPONSIBILITY  /  TODAY</text>
</svg>'''


def _font(size: int, *, bold: bool = False) -> ImageFont.FreeTypeFont:
    name = "arialbd.ttf" if bold else "arial.ttf"
    path = Path(r"C:\Windows\Fonts") / name
    if not path.is_file():
        raise FileNotFoundError(path)
    return ImageFont.truetype(str(path), size=size)


def _rasterize(spec: dict[str, object], output: Path) -> None:
    width, height = 1920, 1080
    image = Image.new("RGB", (width, height), "#06121F")
    draw = ImageDraw.Draw(image)
    for y in range(height):
        ratio = y / max(1, height - 1)
        start = (6, 18, 31)
        end = (21, 52, 74)
        color = tuple(round(start[index] * (1 - ratio) + end[index] * ratio) for index in range(3))
        draw.line((0, y, width, y), fill=color)
    for x in range(0, width, 64):
        draw.line((x, 0, x, height), fill="#10283D", width=1)
    for y in range(0, height, 64):
        draw.line((0, y, width, y), fill="#10283D", width=1)
    draw.rounded_rectangle((150, 172, 168, 356), radius=9, fill="#D7A94A")
    draw.text((215, 170), str(spec["title"]), font=_font(80, bold=True), fill="#E8EDF2")
    draw.text((220, 285), str(spec["subtitle"]), font=_font(34), fill="#B8C6D2")
    steps = [str(value) for value in spec["steps"]]
    centers = (420, 960, 1500)
    for index, (center, label) in enumerate(zip(centers, steps), start=1):
        draw.rounded_rectangle((center - 230, 505, center + 230, 755), radius=28, fill="#10283D", outline="#D7A94A", width=4)
        draw.ellipse((center - 28, 527, center + 28, 583), fill="#D7A94A")
        draw.text((center, 555), str(index), font=_font(28, bold=True), fill="#081827", anchor="mm")
        draw.text((center, 660), label, font=_font(28, bold=True), fill="#E8EDF2", anchor="mm")
    draw.line((650, 630, 730, 630), fill="#D7A94A", width=8)
    draw.line((1190, 630, 1270, 630), fill="#D7A94A", width=8)
    draw.rounded_rectangle((190, 850, 1730, 858), radius=4, fill="#203E54")
    draw.rounded_rectangle((190, 850, 1210, 858), radius=4, fill="#D7A94A")
    draw.text((190, 885), "TRUTH  /  RESPONSIBILITY  /  TODAY", font=_font(34), fill="#B8C6D2")
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output, format="PNG", optimize=True)


def compile_typography_successor(spec: dict, take: dict, treatment: dict, bible: dict,
                                 *, font: Path) -> dict:
    """Forward layout: preserve semantic copy, measure it before any media work.

    The legacy raster/clip is immutable. Its whole-canvas pan would move enlarged
    text into the take's overlays. In this successor text belongs to a stationary
    foreground; only the decorative background may move. This function grants
    no render/right/publication authority and does not alter the take recipe.
    """
    from .phase6_visual_recipe import (_Region, _place_copy, inspect_visual_layout,
        VisualRecipeContractError, VisualRecipeLayoutError)
    before = copy.deepcopy((spec,take,treatment,bible))
    canonical = [json.loads(json.dumps(row)) for row in SPECS]
    normalized_spec = json.loads(json.dumps(spec))
    if normalized_spec not in canonical:
        raise VisualRecipeContractError("successor must preserve an exact canonical source specification")
    typo = bible.get("typography",{})
    if (typo.get("minimum_sizes",{}).get("1920x1080") != 54
            or typo.get("safe_area") != {"horizontal_percent":8,"vertical_percent":8}
            or "Arial" not in typo.get("families",[]) or "Bold" not in typo.get("weights",[])):
        raise VisualRecipeContractError("typography Bible outside the measured successor profile")
    if bible.get('palette',{}).get('role_map') != {
            'dominant':'#081827','accent':'#D7A94A','text':'#E8EDF2','support':'#2C5364'}:
        raise VisualRecipeContractError('successor layers must match all canonical palette roles')
    if font.resolve() != (Path(r"C:\Windows\Fonts")/"arialbd.ttf").resolve():
        raise VisualRecipeContractError("successor requires the declared Arial Bold font")
    from .render_creative_v2_phase5 import _font as composition_font
    overlay_font = composition_font()
    composed = inspect_visual_layout(take,treatment,font=overlay_font)
    kind = treatment["treatment"]
    if kind not in {"HOOK_FRAMEWORK","FRAMEWORK_STEP","SECTION_CARD"}:
        raise VisualRecipeContractError("successor composition treatment not qualified")
    hook = kind == "HOOK_FRAMEWORK"
    texts=[]
    def put(role,text,region,size=54):
        texts.append(_place_copy(role=role,source=text,font_path=font,preferred_size=size,
            region=region,color="#E8EDF2",filename=role+'.txt'))
    put('source-title',spec['title'],_Region(180,140 if hook else 204,1540,80),64)
    put('source-subtitle',spec['subtitle'],_Region(180,226 if hook else 290,1540,144))
    for i,text in enumerate(spec['steps']):
        x=180+i*530
        put(f'number-{i+1}',str(i+1),_Region(x,514 if hook else 446,480,76))
        put(f'step-{i+1}',text,_Region(x,612 if hook else 538,480,144))
    footer = "TRUTH  /  RESPONSIBILITY  /  TODAY"
    delegation = None
    if hook:
        actual = [r['source_text'] for r in composed['overlays'] if r['role'].startswith('framework-')]
        if actual != ['TRUTH','RESPONSIBILITY','TODAY']:
            raise VisualRecipeContractError("framework footer cannot be silently removed")
        delegation={'source_text':footer,'tokens':actual,'consumer':'canonical HOOK_FRAMEWORK overlays',
                    'reason':'render once at the measured canonical positions, not twice'}
    else:
        put('source-footer',footer,_Region(180,918,1540,75))
    def intersects(a,b):
        return a['left']<b['right'] and a['right']>b['left'] and a['top']<b['bottom'] and a['bottom']>b['top']
    occupied=[row.get('background_bounds',row['bounds']) for row in composed['overlays']]
    for decoration in composed['decorations']:
        m=re.match(r'drawbox=x=(\d+):y=(\d+):w=(\d+):h=(\d+):',decoration)
        if not m:
            raise VisualRecipeContractError("unmeasured decoration in successor composition")
        x,y,w,h=map(int,m.groups())
        occupied.append({'left':x,'top':y,'right':x+w,'bottom':y+h})
    for i,row in enumerate(texts):
        if any(intersects(row['bounds'],other) for other in occupied):
            raise VisualRecipeLayoutError(row['role']+" overlaps canonical take composition")
        if any(intersects(row['bounds'],other['bounds']) for other in texts[:i]):
            raise VisualRecipeLayoutError(row['role']+" overlaps another source text")
    if before != (spec,take,treatment,bible):
        raise RuntimeError("typography compiler mutated canonical inputs")
    result={'version':TYPOGRAPHY_SUCCESSOR_VERSION,'asset_id':spec['asset_id'],
        'take_id':take['take_id'],'source_spec':normalized_spec,'take':copy.deepcopy(take),
        'treatment':copy.deepcopy(treatment),'style_bible':copy.deepcopy(bible),
        'font':{'path':str(font.resolve()),'sha256':_sha256(font)},
        'composition_font':{'path':str(overlay_font.resolve()),'sha256':_sha256(overlay_font)},
        'canvas':{'width':1920,'height':1080},'text_motion':'STATIONARY_FOREGROUND',
        'whole_canvas_legacy_pan_permitted':False,'texts':texts,'footer_delegation':delegation,
        'canonical_composition':composed,'minimum_font_size':min(r['font_size'] for r in texts),
        'all_required_copy_preserved':True,'no_text_overlap':True,
        'source_intrinsic_quality_proved':False,'quality_authorized':False,
        'render_authorized':False,'publication_authorized':False}
    raw=json.dumps(result,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    result['layout_id']='procedural-typography-'+hashlib.sha256(raw).hexdigest()
    return result


def verify_typography_successor(layout: dict) -> dict:
    """The consumer recomputes the layout; a caller's PASS/hash is not accepted."""
    rebuilt=compile_typography_successor(layout['source_spec'],layout['take'],layout['treatment'],
        layout['style_bible'],font=Path(layout['font']['path']))
    if rebuilt != layout:
        raise PermissionError('typography successor bytes/geometry/font identity differ')
    return rebuilt


def _typography_foreground(layout: dict):
    """One raster implementation shared by writer and renderer input verifier."""
    from .phase6_visual_recipe import LINE_SPACING,TEXT_BORDER
    layout=verify_typography_successor(layout)
    image=Image.new('RGBA',(1920,1080),(0,0,0,0))
    draw=ImageDraw.Draw(image)
    observed=[]
    for row in layout['texts']:
        font=ImageFont.truetype(layout['font']['path'],size=row['font_size'])
        bbox=draw.multiline_textbbox((0,0),row['render_text'],font=font,spacing=LINE_SPACING,stroke_width=TEXT_BORDER)
        x,y=row['x']-bbox[0],row['y']-bbox[1]
        draw.multiline_text((x,y),row['render_text'],font=font,spacing=LINE_SPACING,
            fill=row['color'],stroke_width=TEXT_BORDER,stroke_fill='#081827')
        observed.append({'role':row['role'],'raster_bounds':[row['x'],row['y'],
            row['x']+bbox[2]-bbox[0],row['y']+bbox[3]-bbox[1]]})
    return image,observed


def rasterize_typography_successor(layout: dict, output: Path) -> dict:
    """Emit only a transparent foreground, exclusively; never render a video."""
    image,observed=_typography_foreground(layout)
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as stream:
        image.save(stream,format='PNG',optimize=True)
    return {'version':TYPOGRAPHY_SUCCESSOR_VERSION,'layout_id':layout['layout_id'],
            'foreground':{'path':str(output.resolve()),'sha256':_sha256(output)},
            'rasterized_bounds':observed,'video_rendered':False,'quality_authorized':False}


def _typography_background() -> Image.Image:
    """Regenerable decorative pixels only: no text or photographic subjects."""
    image=Image.new('RGB',(1920,1080),'#081827')
    draw=ImageDraw.Draw(image)
    for x in range(0,1920,64):draw.line((x,0,x,1080),fill='#2C5364',width=1)
    for y in range(0,1080,64):draw.line((0,y,1920,y),fill='#2C5364',width=1)
    return image


def _render(image_path: Path, video_path: Path, *, typography_layout: dict | None = None,
            foreground_path: Path | None = None) -> None:
    """Legacy path unchanged; explicit successor verifies layers before effects.

    This is the asset renderer, not a release authority. Its successor must be
    adopted via the normal workflow; current real staging never calls it.
    """
    if typography_layout is not None:
        from io import BytesIO
        if foreground_path is None or video_path.exists():
            raise PermissionError('new typography requires exact foreground and an absent output')
        expected_foreground,_=_typography_foreground(typography_layout)
        expected_background=_typography_background()
        # Pixels and their binding must come from the same immutable buffer.
        # Hashing the pathname only after decoding could bind different bytes.
        captured={path:path.read_bytes() for path in (image_path,foreground_path)}
        bindings={path:'sha256:'+hashlib.sha256(raw).hexdigest() for path,raw in captured.items()}
        with Image.open(BytesIO(captured[image_path])) as image:
            if image.mode!='RGB' or image.size!=expected_background.size or image.tobytes()!=expected_background.tobytes():
                raise PermissionError('typography background differs; no legacy text may move underneath')
        with Image.open(BytesIO(captured[foreground_path])) as image:
            if image.mode!='RGBA' or image.size!=expected_foreground.size or image.tobytes()!=expected_foreground.tobytes():
                raise PermissionError('typography foreground differs from measured layout')
        if any(_sha256(path)!=digest for path,digest in bindings.items()):
            raise PermissionError('typography layers changed before composition')
        video_path.parent.mkdir(parents=True,exist_ok=True)
        graph=("[0:v]scale=2048:1152:force_original_aspect_ratio=increase,"
            "crop=1920:1080:x='64+60*sin(t*1.70)':y='36+32*cos(t*1.30)'[background];"
            "[background][1:v]overlay=x=0:y=0:format=auto,"
            "fade=t=in:st=0:d=0.35,fade=t=out:st=17.45:d=0.55,format=yuv420p[out]")
        command=[FFMPEG,'-n','-nostdin','-hide_banner','-loglevel','error',
            '-loop','1','-framerate','30','-i',str(image_path),
            '-loop','1','-framerate','30','-i',str(foreground_path),
            '-filter_complex_threads','1','-filter_complex',graph,'-map','[out]',
            '-t',str(DURATION_SECONDS),'-an','-r','30','-c:v','libx264',
            # This intermediate must preserve the independently composed text
            # edges/fades. CRF18 exceeded the Bible's existing CIE76 bound;
            # lossless x264 preserves native samples without relaxing QA.
            '-profile:v','high444','-preset','medium','-crf','0','-threads','1',
            '-g','60','-keyint_min','30','-sc_threshold','0','-movflags','+faststart',str(video_path)]
        result=subprocess.run(command,text=True,encoding='utf-8',errors='strict',capture_output=True,
            timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:
            raise RuntimeError('typography compositor failed: '+result.stderr[-2000:])
        if any(_sha256(path)!=digest for path,digest in bindings.items()):
            raise PermissionError('typography layers changed during composition; output is not accepted')
        verify_typography_successor(typography_layout)
        return
    if foreground_path is not None:
        raise PermissionError('foreground cannot enter the legacy whole-canvas renderer')
    video_path.parent.mkdir(parents=True, exist_ok=True)
    command = [
        FFMPEG,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-loop",
        "1",
        "-framerate",
        "30",
        "-i",
        str(image_path),
        "-t",
        str(DURATION_SECONDS),
        "-vf",
        "scale=2048:1152:force_original_aspect_ratio=increase,crop=1920:1080:x='64+60*sin(t*1.70)':y='36+32*cos(t*1.30)',fade=t=in:st=0:d=0.35,fade=t=out:st=17.45:d=0.55,format=yuv420p",
        "-an",
        "-r",
        "30",
        "-c:v",
        "libx264",
        "-profile:v",
        "high",
        "-preset",
        "medium",
        "-crf",
        "18",
        "-g",
        "60",
        "-keyint_min",
        "30",
        "-sc_threshold",
        "0",
        "-movflags",
        "+faststart",
        str(video_path),
    ]
    result = subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True)
    if result.returncode:
        raise RuntimeError("\n".join(result.stderr.splitlines()[-80:]))


def read_typography_successor_stage(root: Path, manifest_path: Path, *, expected_sha256: str) -> dict:
    """Read the anchored stage against current intent; grant no media authority.

    The saved layout is not its own authority. Its external anchor, current
    plans, exact canonical copy/fonts and original source must all still agree.
    This reader has no writes and never calls the legacy builder or renderer.
    """
    root = root.resolve()
    captured = {}

    def read(path):
        path = (path if path.is_absolute() else root / path).resolve()
        if root not in path.parents or not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
            raise PermissionError('typography input must be a confined, bounded file')
        raw = path.read_bytes()
        captured[path] = 'sha256:' + hashlib.sha256(raw).hexdigest()
        return path, json.loads(raw)

    if not isinstance(expected_sha256, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', expected_sha256):
        raise PermissionError('external typography stage anchor required')
    path, stage = read(Path(manifest_path))
    if captured[path] != expected_sha256:
        raise PermissionError('typography stage anchor differs')
    if (stage.get('schema_version') != '2.0.0' or stage.get('generator') != TYPOGRAPHY_SUCCESSOR_VERSION
            or stage.get('status') != 'STAGED_LAYOUTS_NOT_MEDIA'
            or any(stage.get(key) is not False for key in
                   ('quality_authorized', 'render_authorized', 'publication_authorized'))
            or not isinstance(stage.get('layouts'), list) or not stage['layouts']):
        raise PermissionError('typography stage contract/authority differs')
    base = root / 'output/production/phase6/video-002/production'
    _, plan = read(base / 'take_plan.json')
    _, treatment = read(base / 'creative_treatment_plan.json')
    _, bible = read(base / 'channel_style_bible.json')
    _, allocation = read(base / 'asset_allocation.json')
    takes = {row['take_id']: row for row in plan['takes']}
    treatments = {row['take_id']: row for row in treatment['takes']}
    allocated = {row['take_id']: row for row in allocation['takes']}
    if (len(takes) != len(plan['takes']) or len(treatments) != len(treatment['takes'])
            or len(allocated) != len(allocation['takes'])):
        raise PermissionError('duplicate current typography take identity')
    seen = set()
    for layout in stage['layouts']:
        verify_typography_successor(layout)
        take_id = layout['take_id']
        if (not re.fullmatch(r'[A-Za-z0-9_-]+', take_id) or take_id in seen
                or layout['take'] != takes.get(take_id)
                or layout['treatment'] != treatments.get(take_id)
                or layout['style_bible'] != bible):
            raise PermissionError('typography stage/current intent differs')
        seen.add(take_id)
        source = (root / V3 / 'assets' / (layout['asset_id'] + '.mp4')).resolve()
        origin = str(layout['take'].get('asset_origin', '')).split('#t=', 1)[0]
        if not origin or (root / origin).resolve() != source or root not in source.parents or not source.is_file():
            raise PermissionError('typography source lineage differs')
        source_row = allocated.get(take_id, {})
        expected_source = source_row.get('content_hash')
        if (source_row.get('asset_id') != layout['asset_id']
                or (root / str(source_row.get('source_path', ''))).resolve() != source
                or not isinstance(expected_source, str)
                or not re.fullmatch(r'sha256:[0-9a-f]{64}', expected_source)
                or _sha256(source) != expected_source):
            raise PermissionError('typography allocated source identity differs')
        captured[source] = expected_source
        for key in ('font', 'composition_font'):
            font = Path(layout[key]['path']).resolve()
            if _sha256(font) != layout[key]['sha256']:
                raise PermissionError('typography font differs')
            captured[font] = layout[key]['sha256']
    if any(_sha256(path) != digest for path, digest in captured.items()):
        raise PermissionError('typography inputs changed during reading')
    return {'stage': stage, 'manifest': {'path': str(path), 'sha256': expected_sha256},
            'bindings': [{'path': str(p), 'sha256': digest} for p, digest in captured.items()],
            'quality_authorized': False, 'render_authorized': False, 'publication_authorized': False}


def read_typography_source_manifest(root: Path, manifest_path: Path, *, expected_sha256: str) -> dict:
    """Authenticate produced sources and frozen intent, not mutable aliases/QA."""
    root=root.resolve()
    captured={}
    def bound(binding, *, font=False):
        path=Path(binding['path'])
        path=(path if path.is_absolute() else root/path).resolve()
        digest=binding['sha256']
        if (not isinstance(digest,str) or not re.fullmatch(r'sha256:[0-9a-f]{64}',digest)
                or not path.is_file() or (not font and root not in path.parents)
                or _sha256(path)!=digest):
            raise PermissionError('typography produced-source binding differs')
        captured[path]=digest
        return path
    path=bound({'path':str(manifest_path),'sha256':expected_sha256})
    value=json.loads(path.read_bytes())
    if (value.get('schema_version')!='2.1.0' or value.get('generator')!=TYPOGRAPHY_SUCCESSOR_VERSION
            or value.get('status')!='CANDIDATE_SOURCES_NOT_ADOPTED'
            or any(value.get(key) is not False for key in ('quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('typography produced-source contract/authority differs')
    originals={r['path']:r for r in value['input_bindings']}
    snapshots={r['original_path']:r for r in value['input_snapshots']}
    if len(originals)!=len(value['input_bindings']) or len(snapshots)!=len(value['input_snapshots']):
        raise PermissionError('duplicate typography source bindings')
    expected_json={p for p in originals if Path(p).suffix.lower()=='.json'}
    if set(snapshots)!=expected_json:
        raise PermissionError('typography frozen intent population differs')
    for original,snapshot in snapshots.items():
        if snapshot['sha256']!=originals[original]['sha256']:
            raise PermissionError('typography frozen intent anchor differs')
        bound(snapshot)
    stage_ref=value['stage']
    snapshot=snapshots.get(stage_ref['path'])
    if snapshot is None or snapshot['sha256']!=stage_ref['sha256']:
        raise PermissionError('typography source/stage binding differs')
    stage=json.loads(bound(snapshot).read_bytes())
    if (stage.get('generator')!=TYPOGRAPHY_SUCCESSOR_VERSION or stage.get('schema_version')!='2.0.0'
            or stage.get('status')!='STAGED_LAYOUTS_NOT_MEDIA'
            or any(stage.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('frozen typography stage contract differs')
    layouts={r['layout_id']:r for r in stage['layouts']}
    if not layouts or len(layouts)!=len(stage['layouts']):
        raise PermissionError('duplicate/empty typography layouts')
    frozen_values={}
    base=root/'output/production/phase6/video-002/production'
    for name in ('take_plan.json','creative_treatment_plan.json','channel_style_bible.json','asset_allocation.json'):
        frozen=snapshots.get(str((base/name).resolve()))
        if frozen is None:raise PermissionError('missing frozen typography intent')
        frozen_values[name]=json.loads(bound(frozen).read_bytes())
    frozen_takes={r['take_id']:r for r in frozen_values['take_plan.json']['takes']}
    frozen_treatments={r['take_id']:r for r in frozen_values['creative_treatment_plan.json']['takes']}
    frozen_assets={r['take_id']:r for r in frozen_values['asset_allocation.json']['takes']}
    allowed_fonts={r[k]['path']:r[k]['sha256'] for r in layouts.values() for k in ('font','composition_font')}
    for name,binding in originals.items():
        if name not in snapshots:
            if Path(name).resolve().is_relative_to(root):
                bound(binding)
            elif allowed_fonts.get(name)==binding['sha256']:
                bound(binding,font=True)
            else:
                raise PermissionError('foreign typography dependency')
    seen=set()
    for asset in value['assets']:
        layout=layouts.get(asset.get('layout_id'))
        if (layout is None or asset['layout_id'] in seen
                or asset.get('asset_id')!='asset-'+layout['layout_id']
                or asset.get('take_id')!=layout['take_id'] or asset.get('historical_asset_id')!=layout['asset_id']
                or asset.get('generator')!=TYPOGRAPHY_SUCCESSOR_VERSION+'+FFmpeg'
                or asset.get('requires_fresh_rights_registration') is not True):
            raise PermissionError('typography produced asset identity/population differs')
        verify_typography_successor(layout)
        allocation=frozen_assets.get(layout['take_id'],{})
        original_source=(root/str(allocation.get('source_path',''))).resolve()
        original_binding=originals.get(str(original_source),{})
        if (layout['take']!=frozen_takes.get(layout['take_id'])
                or layout['treatment']!=frozen_treatments.get(layout['take_id'])
                or layout['style_bible']!=frozen_values['channel_style_bible.json']
                or allocation.get('asset_id')!=layout['asset_id']
                or allocation.get('content_hash')!=original_binding.get('sha256')
                or (root/str(layout['take'].get('asset_origin','')).split('#t=',1)[0]).resolve()!=original_source):
            raise PermissionError('produced typography disagrees with frozen intent/source')
        seen.add(asset['layout_id'])
        bound({'path':asset['video_path'],'sha256':asset['video_hash']})
        bound(asset['foreground'])
    if seen!=set(layouts):
        raise PermissionError('typography produced sources are incomplete')
    bound(value['background'])
    if any(_sha256(p)!=digest for p,digest in captured.items()):
        raise PermissionError('typography source inputs changed during reading')
    return {'manifest':value,'layouts':layouts,'binding':{'path':str(path),'sha256':expected_sha256},
            'verified_bindings':[{'path':str(p),'sha256':digest} for p,digest in captured.items()],
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}


def build_procedural_infographics(root: Path, *, created_at: str | None = None,
                                  typography_contexts: list[dict] | None = None,
                                  typography_directory: Path | None = None,
                                  typography_source_manifest: Path | None = None,
                                  expected_typography_sha256: str | None = None) -> dict[str, object]:
    if typography_source_manifest is not None or expected_typography_sha256 is not None:
        # Explicit asset-production branch; never replace a historical asset or
        # change a TakePlan/allocation. Normal adoption/rights/QA remain separate.
        root = root.resolve()
        if (typography_source_manifest is None or expected_typography_sha256 is None
                or typography_contexts is not None or typography_directory is None):
            raise PermissionError('unambiguous anchored typography source request required')
        destination = typography_directory.resolve()
        legacy = (root / V3).resolve()
        if (root not in destination.parents or destination.exists()
                or destination == legacy or legacy in destination.parents):
            raise PermissionError('typography sources require a new nonhistorical confined directory')
        pause = root / 'output/runtime/gestor-central/PAUSE'
        if pause.exists():
            raise PermissionError('PAUSE prohibits typography source production')
        observed = read_typography_successor_stage(root, typography_source_manifest,
                                                   expected_sha256=expected_typography_sha256)

        def recheck():
            if pause.exists():
                raise PermissionError('PAUSE prohibits typography source production')
            if any(_sha256(Path(row['path'])) != row['sha256'] for row in observed['bindings']):
                raise PermissionError('typography inputs changed before completion')

        recheck()
        destination.mkdir(parents=True, exist_ok=False)
        snapshots=[]
        frozen=destination/'inputs'
        frozen.mkdir()
        for binding in observed['bindings']:
            source=Path(binding['path'])
            if source.suffix.lower()!='.json':
                continue
            raw=source.read_bytes()
            if 'sha256:'+hashlib.sha256(raw).hexdigest()!=binding['sha256']:
                raise PermissionError('typography intent changed before archive')
            archive=frozen/(str(len(snapshots))+'-'+source.name)
            with archive.open('xb') as stream:stream.write(raw)
            snapshots.append({'original_path':str(source),'path':str(archive),'sha256':binding['sha256']})
        background = destination / 'background.png'
        with background.open('xb') as stream:
            _typography_background().save(stream, format='PNG')
        background_hash = _sha256(background)
        records = []
        for layout in observed['stage']['layouts']:
            recheck()
            # Take-specific: the same old source can have distinct compositions.
            asset_id = 'asset-' + layout['layout_id']
            foreground = destination / (asset_id + '.png')
            video = destination / (asset_id + '.mp4')
            raster = rasterize_typography_successor(layout, foreground)
            recheck()
            _render(background, video, typography_layout=layout, foreground_path=foreground)
            recheck()
            if _sha256(background) != background_hash:
                raise PermissionError('typography background changed after composition')
            if not video.is_file() or video.stat().st_size == 0:
                raise PermissionError('typography compositor produced no source')
            records.append({'asset_id': asset_id, 'take_id': layout['take_id'],
                            'historical_asset_id': layout['asset_id'], 'layout_id': layout['layout_id'],
                            'generator': TYPOGRAPHY_SUCCESSOR_VERSION + '+FFmpeg',
                            'video_path': str(video), 'video_hash': _sha256(video),
                            'duration_seconds': DURATION_SECONDS, 'foreground': raster['foreground'],
                            'requires_fresh_rights_registration': True})
        recheck()
        if _sha256(background) != background_hash:
            raise PermissionError('typography background changed before manifest')
        for record in records:
            if (_sha256(Path(record['video_path'])) != record['video_hash']
                    or _sha256(Path(record['foreground']['path'])) != record['foreground']['sha256']):
                raise PermissionError('typography output changed before manifest')
        manifest = {'schema_version': '2.1.0', 'generator': TYPOGRAPHY_SUCCESSOR_VERSION,
                    'status': 'CANDIDATE_SOURCES_NOT_ADOPTED', 'assets': records,
                    'stage': observed['manifest'], 'input_bindings': observed['bindings'],
                    'input_snapshots':snapshots,
                    'background': {'path': str(background), 'sha256': background_hash},
                    'external_cost_brl': 0.0, 'quality_authorized': False,
                    'render_authorized': False, 'publication_authorized': False,
                    'created_at': created_at or datetime.now(timezone.utc).isoformat()}
        # Failure leaves its partial work intact and no successful manifest.
        with (destination / 'manifest.json').open('x', encoding='utf-8') as stream:
            json.dump(manifest, stream, indent=2, ensure_ascii=False)
        return manifest
    if typography_contexts is not None:
        # Explicit forward-only staging. The existing legacy producer remains
        # byte-compatible; no unadopted successor can cause a channel render.
        root=root.resolve()
        if not typography_contexts or typography_directory is None:
            raise ValueError('nonempty bound typography contexts and a new directory required')
        destination=typography_directory.resolve()
        if root not in destination.parents or destination.exists():
            raise PermissionError('typography stage requires a new confined directory')
        records=[]
        by_id={s['asset_id']:s for s in SPECS}
        seen=set()
        for context in typography_contexts:
            take=context['take']
            if take['take_id'] in seen:
                raise PermissionError('duplicate typography take')
            seen.add(take['take_id'])
            records.append(compile_typography_successor(by_id[context['asset_id']],take,
                context['treatment'],context['style_bible'],font=Path(r'C:\Windows\Fonts\arialbd.ttf')))
        result={'schema_version':'2.0.0','generator':TYPOGRAPHY_SUCCESSOR_VERSION,
            'status':'STAGED_LAYOUTS_NOT_MEDIA','layouts':records,'external_cost_brl':0.0,
            'quality_authorized':False,'render_authorized':False,'publication_authorized':False}
        destination.mkdir(parents=True,exist_ok=False)
        with (destination/'manifest.json').open('x',encoding='utf-8') as stream:
            json.dump(result,stream,indent=2,ensure_ascii=False)
        return result
    if typography_directory is not None:
        raise ValueError('typography directory cannot alter the legacy producer')
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    directory = root / V3 / "assets" / "procedural"
    directory.mkdir(parents=True, exist_ok=True)
    prior_manifest_path = directory / "manifest.json"
    prior_records: dict[str, dict[str, object]] = {}
    if prior_manifest_path.is_file():
        try:
            prior_records = {
                str(item["asset_id"]): item
                for item in json.loads(prior_manifest_path.read_text(encoding="utf-8-sig")).get("assets", [])
            }
        except (json.JSONDecodeError, KeyError, TypeError):
            # A malformed prior manifest is never trusted to skip rendering.
            prior_records = {}
    records = []
    for spec in SPECS:
        asset_id = str(spec["asset_id"])
        svg_path = directory / f"{asset_id}.svg"
        raster_path = directory / f"{asset_id}.png"
        video_path = root / V3 / "assets" / f"{asset_id}.mp4"
        svg = _svg(spec)
        prior = prior_records.get(asset_id, {})
        reusable = (
            svg_path.is_file() and raster_path.is_file() and video_path.is_file()
            and svg_path.read_text(encoding="utf-8") == svg
            and prior.get("svg_hash") == _sha256(svg_path)
            and prior.get("raster_hash") == _sha256(raster_path)
            and prior.get("video_hash") == _sha256(video_path)
        )
        if not reusable:
            svg_path.write_text(svg, encoding="utf-8")
            _rasterize(spec, raster_path)
            _render(raster_path, video_path)
        records.append(
            {
                "asset_id": asset_id,
                "semantic_role": spec["semantic_role"],
                "svg_path": str(svg_path.resolve()),
                "svg_hash": _sha256(svg_path),
                "raster_path": str(raster_path.resolve()),
                "raster_hash": _sha256(raster_path),
                "video_path": str(video_path.resolve()),
                "video_hash": _sha256(video_path),
                "duration_seconds": DURATION_SECONDS,
                "generator": "HeroVerseLocalVectorMotion@1.0.1+FFmpeg",
                "external_cost_brl": 0.0,
            }
        )
    manifest = {
        "schema_version": "1.0.0",
        "generator": "HeroVerseLocalVectorMotion@1.0.1",
        "assets": records,
        "external_cost_brl": 0.0,
        "created_at": timestamp,
    }
    (directory / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


if __name__ == "__main__":
    result = build_procedural_infographics(Path(__file__).resolve().parents[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
