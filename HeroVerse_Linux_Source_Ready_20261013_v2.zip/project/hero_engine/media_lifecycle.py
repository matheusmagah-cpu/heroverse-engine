"""Small, fail-closed lifecycle for externally sourced media bytes.

Remote discovery is deliberately separate from acquisition.  A local media
file may exist only after an approved take selects one catalog candidate.  A
completed public upload alone never authorizes deletion: a release clearance
must also prove that no queue, lease, renderer or evidence consumer still
requires the exact bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .asset_library_phase5 import _download_commons_file


STANDARD_ACQUISITION_ROOT = Path("output/operations/phase6/acquired-media")


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _write_new(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def _inside(root: Path, path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise PermissionError("MEDIA_LIFECYCLE_PATH_OUTSIDE_ROOT")
    return resolved


def acquire_catalog_candidate(
    root: Path,
    catalog_path: Path,
    *,
    asset_id: str,
    allocation_path: Path,
    acquisition_dir: Path,
) -> dict[str, Any]:
    """Download exactly one remote candidate for explicit approved takes.

    This does not mutate the remote catalog.  The receipt is a new immutable
    production record that binds the selected source, local content hash and
    every take that justified the download.
    """
    root = root.resolve()
    catalog_path = _inside(root, catalog_path)
    allocation_path = _inside(root, allocation_path)
    acquisition_dir = _inside(root, acquisition_dir)
    allocation_raw = allocation_path.read_bytes()
    allocation = json.loads(allocation_raw)
    approved_take_ids = [
        item.get("take_id") for item in allocation.get("takes", [])
        if isinstance(item, dict) and item.get("asset_id") == asset_id
    ]
    if not approved_take_ids or any(not isinstance(item, str) or not item for item in approved_take_ids):
        raise PermissionError("MEDIA_ACQUISITION_APPROVED_TAKES_REQUIRED")
    if len(set(approved_take_ids)) != len(approved_take_ids):
        raise PermissionError("MEDIA_ACQUISITION_DUPLICATE_TAKE")
    catalog_raw = catalog_path.read_bytes()
    catalog = json.loads(catalog_raw)
    if catalog.get("media_downloaded") is not False:
        raise PermissionError("MEDIA_ACQUISITION_CATALOG_NOT_REMOTE_ONLY")
    candidate = next((item for item in catalog.get("candidates", []) if item.get("asset_id") == asset_id), None)
    if not isinstance(candidate, dict) or candidate.get("residency") != "REMOTE_CATALOGED":
        raise PermissionError("MEDIA_ACQUISITION_CANDIDATE_NOT_REMOTE")
    if candidate.get("production_eligible") is not False:
        raise PermissionError("MEDIA_ACQUISITION_CANDIDATE_STATE_INVALID")
    evidence = _inside(root, Path(str(candidate.get("rights_evidence_uri") or "")))
    if not evidence.is_file():
        raise PermissionError("MEDIA_ACQUISITION_RIGHTS_EVIDENCE_MISSING")
    suffix = Path(urlsplit(str(candidate["download_url"])).path).suffix.lower() or ".webm"
    destination = acquisition_dir / "media" / f"{asset_id}{suffix}"
    receipt_path = acquisition_dir / "receipts" / f"{asset_id}.json"
    _inside(root, destination)
    _inside(root, receipt_path)
    if destination.exists() or receipt_path.exists():
        raise PermissionError("MEDIA_ACQUISITION_ALREADY_EXISTS_OR_PARTIAL")
    destination.parent.mkdir(parents=True, exist_ok=True)
    _download_commons_file(candidate, destination)
    if not destination.is_file() or destination.stat().st_size != int(candidate["size_bytes"]):
        raise PermissionError("MEDIA_ACQUISITION_DOWNLOAD_UNVERIFIED")
    receipt = {
        "schema_version": "1.0.0", "state": "RESIDENT_FOR_APPROVED_TAKES",
        "asset_id": asset_id, "approved_take_ids": sorted(approved_take_ids),
        "source": candidate["source"], "download_url": candidate["download_url"],
        "catalog": {"path": catalog_path.relative_to(root).as_posix(), "sha256": "sha256:" + hashlib.sha256(catalog_raw).hexdigest()},
        "allocation": {"path": allocation_path.relative_to(root).as_posix(), "sha256": "sha256:" + hashlib.sha256(allocation_raw).hexdigest()},
        "rights_evidence": {"path": evidence.relative_to(root).as_posix(), "sha256": _hash(evidence)},
        "media": {"path": destination.relative_to(root).as_posix(), "sha256": _hash(destination), "bytes": destination.stat().st_size},
        "publication_authorized": False,
    }
    _write_new(receipt_path, receipt)
    return receipt


def release_published_media(
    root: Path,
    acquisition_receipt_path: Path,
    release_clearance: dict[str, Any],
) -> dict[str, Any]:
    """Remove one acquired file only after a complete, exact clearance.

    The clearance is produced by the publication/queue owner, not inferred
    from age, free-space pressure or a caller supplied path.  Its explicit
    negative assertions keep this operation from deleting active or evidential
    media.  The immutable acquisition receipt is retained after release.
    """
    root = root.resolve()
    receipt_path = _inside(root, acquisition_receipt_path)
    receipt_raw = receipt_path.read_bytes()
    receipt = json.loads(receipt_raw)
    if receipt.get("state") != "RESIDENT_FOR_APPROVED_TAKES":
        raise PermissionError("MEDIA_RELEASE_ACQUISITION_STATE_INVALID")
    required_false = ("queue_open", "lease_open", "render_open", "evidence_dependency", "retention_required")
    if release_clearance.get("publication_status") != "COMPLETE_PUBLIC" or any(release_clearance.get(key) is not False for key in required_false):
        raise PermissionError("MEDIA_RELEASE_CLEARANCE_INCOMPLETE")
    if release_clearance.get("asset_id") != receipt.get("asset_id"):
        raise PermissionError("MEDIA_RELEASE_ASSET_MISMATCH")
    if release_clearance.get("acquisition_receipt_sha256") != "sha256:" + hashlib.sha256(receipt_raw).hexdigest():
        raise PermissionError("MEDIA_RELEASE_RECEIPT_BINDING_MISMATCH")
    media = _inside(root, root / receipt["media"]["path"])
    if not media.is_file() or _hash(media) != receipt["media"]["sha256"]:
        raise PermissionError("MEDIA_RELEASE_MEDIA_CHANGED_OR_MISSING")
    terminal = receipt_path.with_name(receipt_path.stem + ".released.json")
    if terminal.exists():
        raise PermissionError("MEDIA_RELEASE_ALREADY_RECORDED")
    plan = {
        "state": "RELEASE_PLANNED", "asset_id": receipt["asset_id"],
        "media": receipt["media"], "acquisition_receipt": receipt_path.relative_to(root).as_posix(),
    }
    plan_path = receipt_path.with_name(receipt_path.stem + ".release-plan.json")
    _write_new(plan_path, plan)
    if _hash(media) != receipt["media"]["sha256"]:
        raise PermissionError("MEDIA_RELEASE_MEDIA_CHANGED_AFTER_PLAN")
    media.unlink()
    if media.exists():
        raise PermissionError("MEDIA_RELEASE_REMOVAL_UNCONFIRMED")
    _write_new(terminal, {
        "state": "INTENTIONALLY_ABSENT_AFTER_COMPLETE_PUBLIC", "asset_id": receipt["asset_id"],
        "media": receipt["media"], "acquisition_receipt_sha256": "sha256:" + hashlib.sha256(receipt_raw).hexdigest(),
        "release_clearance": release_clearance,
    })
    return json.loads(terminal.read_text(encoding="utf-8"))


def collect_completed_public_media(root: Path, publication_receipt: dict[str, Any]) -> dict[str, Any]:
    """Run at the terminal publication boundary without guessing clearance.

    Each acquisition can opt into automated release by placing its independently
    generated clearance beside the immutable receipt.  An absent, malformed or
    stale clearance is intentionally a non-effect, never a reason to delete.
    """
    root = root.resolve()
    if publication_receipt.get("status") != "COMPLETE_PUBLIC":
        return {"status": "PUBLICATION_NOT_TERMINAL", "released": []}
    base = root / STANDARD_ACQUISITION_ROOT / "receipts"
    if not base.is_dir():
        return {"status": "NO_ACQUISITIONS", "released": []}
    released: list[str] = []
    blocked: list[dict[str, str]] = []
    for receipt_path in sorted(base.glob("*.json")):
        if receipt_path.name.endswith((".released.json", ".release-plan.json")):
            continue
        clearance_path = receipt_path.with_name(receipt_path.stem + ".release-clearance.json")
        if not clearance_path.is_file():
            blocked.append({"receipt": receipt_path.relative_to(root).as_posix(), "reason": "CLEARANCE_ABSENT"})
            continue
        try:
            clearance = json.loads(clearance_path.read_text(encoding="utf-8"))
            # The clearance must name this exact public publication rather than
            # claiming that any public video made the bytes disposable.
            if clearance.get("youtube_video_id") != publication_receipt.get("video_id"):
                raise PermissionError("MEDIA_RELEASE_PUBLICATION_MISMATCH")
            release_published_media(root, receipt_path, clearance)
            released.append(receipt_path.relative_to(root).as_posix())
        except Exception as exc:
            blocked.append({
                "receipt": receipt_path.relative_to(root).as_posix(),
                "reason": f"{type(exc).__name__}:{exc}",
            })
    return {"status": "COMPLETE", "released": released, "blocked": blocked}
