"""Isolated canonical-A preflight for a future PUBLICITY consumer, not installed.

The only public entry point prepares its own evidence and retains its recheck
closure privately for the duration of a context manager. No caller-supplied
prepared object, dependency list, verified flag, queue context or callback is
accepted. The yielded view is NOT a persistent receipt or admission proof.

Historical A12 and the T11 candidate body-case/V4 route have separate pins.
Historical metadata does not approve the current runtime or a rebuilt timeline.
Its actual incomplete
timeline fails before queue resolution, A.verify, PCM inspection or any effect.
A synthetic complete test is not evidence that this route can currently produce
a complete timeline. A future timeline implementation needs coordinated pins.

This adapter does not fix detector runtime, calibrated success or counterproof
replay, does not observe pixels, and never grants LIVE/publication authority.
"""
from __future__ import annotations

import copy
from contextlib import contextmanager
import hashlib
import importlib
import json
from pathlib import Path
import re
import stat
from types import MappingProxyType

from jsonschema import Draft202012Validator, FormatChecker

VERSION = "phase6-av-publicity-stage-a-v2"
CODE_ROOT = Path(__file__).absolute().parents[1]
MODULE = "hero_engine/phase6_av_publicity_stage_a.py"
TIMELINES = "output/operations/phase6/av-admission/timelines"
ARGUMENTS = "output/operations/phase6/av-admission/arguments"
INPUTS = "output/operations/phase6/release/production-input-receipts"
A_MODULE = "hero_engine/phase6_av_timeline.py"
A_SCHEMA = "schemas/phase6_av_timeline.schema.json"
ARGUMENTS_SCHEMA = "schemas/phase6_av_admission.schema.json"
TEXTWRAP = "C:/Users/mathe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/Lib/textwrap.py"
METADATA_LIMIT = 2 * 1024**2
FILE_LIMIT = 16 * 1024**2
ARGUMENT_KEYS = frozenset(("source_bindings", "pause_decisions", "render_spans", "visual_events",
                           "caption_cues", "temporal_evidence_bindings", "temporal_policy_binding"))
AUTHORITY = MappingProxyType({name: False for name in
    ("queue_authorized", "render_authorized", "publication_authorized", "legal_clearance")})
# Immutable historical A12 population; retained as metadata, not current approval.
HISTORICAL_A12_PINS = MappingProxyType({
    A_MODULE: "sha256:a113489a43a26d50f266808fb3bb06d6fa1de6092364c7d7aaedbbcb8bc5f5dd",
    A_SCHEMA: "sha256:3095b5f5b0daa68341ed565c6457d3eb96fb1cb356459ae3af1ebfaec624decb",
    "hero_engine/phase6_narration_audio_inventory.py": "sha256:11e56ca46d3f4928882ece936500b49a428caf7cbd1ff542069eceb47db4bde6",
    "hero_engine/phase6_narration_units.py": "sha256:737326797c9499cd341198ca43927a3e6447f5616563ceafc6b3bd8278c71fba",
    "hero_engine/phase6_av_static_timeline.py": "sha256:2778d2aa5d9e93a4bf07d4b480cc1c3218e25838ee3d60acb4f58ad821f02a9c",
    "hero_engine/phase6_av_static_sources.py": "sha256:a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "hero_engine/phase6_av_caption_intent.py": "sha256:36f7c2fd82b36ef824221dfe031c304794fde07042e761065df233311bb51763",
    "hero_engine/phase6_av_visual_intent.py": "sha256:9ea8fa3f1d465b6bb8a0aa5491d291ae592400c64e7445b17733190b7431c791",
    "schemas/phase6_av_untimed_visual_intent.schema.json": "sha256:706c1f5a62ba75790c0d8e7ab3ce31dca520c519f72f626ecce4f9f2c0caa9cc",
    "hero_engine/phase6_av_visual_amendment.py": "sha256:0205fe37622d4ea1bbef501d28a32a9e7c328d00129e33a994119161fa129085",
    "schemas/phase6_av_visual_amendment.schema.json": "sha256:a7fc96bcd6916504c08b7669cafbc430446ae0903ca6ba5dc1fa4f9918550cc1",
    "hero_engine/phase6_av_asset_use_binding.py": "sha256:f3cd3a30fb8a2d6ad26647d5c6143bd3ac93a7cdb433b44d02a5cc6278ad6cf6",
    "hero_engine/phase6_av_static_asset_uses_v2.py": "sha256:2c2b74a57f42f6e2fe58bf43152ed7f4be623ab257c2594ffed6791991353703",
    "schemas/phase6_av_static_asset_uses_v2.schema.json": "sha256:698d6bcc1cbc46b249101aa5cb535f5e230fce35c15c1ff2851144823211dd4c",
    "hero_engine/phase6_av_question_sources.py": "sha256:3ed0553ab253e81458f786aa9ba15862ef5a191157bcf9bfc6ebcc0922953ad2",
    "hero_engine/phase6_av_question_case_amendment.py": "sha256:2da7b523f2a3ad6b8c70727791649177c77aa4f2dd4434393d98bf62103b1509",
    "schemas/phase6_av_question_case_amendment.schema.json": "sha256:2fc8f9aefdcd8d30ddb6e6e0b90919e3199268c67931b791cfd6497dad8f8004",
    "hero_engine/phase6_av_asset_use_binding_v2.py": "sha256:80c7892fa7cde1492f1955a3691c99a202ecbffe8334a061a805d60b3221da1e",
    "hero_engine/phase6_av_static_asset_uses_v3.py": "sha256:4914222e71089357d557d6e1a64cb3f834d33b5971b6d4cb6bee8a72bfea7886",
    "schemas/phase6_av_static_asset_uses_v3.schema.json": "sha256:125478ba83bc9a8df6f75c932af4893563ddf5f5c9c23ae3b44deb0cb1a21bab",
    "tests/test_phase6_av_question_case_amendment.py": "sha256:9915fc1af1716eddd7815b343eb22e4866995902d75d940236b512689a1b8578",
    "output/qa/phase6/diagnostics/body-case-v1/stage_case_proposal.py": "sha256:2dfb858e8d49157e418c72b0ab81390b8fcf58695a4e6a4d6d8b9f983cb26086",
    "output/qa/phase6/diagnostics/body-case-v1/test_stage_case_proposal.py": "sha256:0dd2d3ea40b7dca1803281b43b2dd9ae52cd649b46bdf60cdff3d3434525c252",
    "output/qa/phase6/diagnostics/body-case-v1/case_proposal.py": "sha256:eeab6c1135ba9a259ff7f2fd3b0cf05ee07d0b2663c0724ff03ff748dbaa66b8",
    "output/qa/phase6/diagnostics/body-case-v1/test_case_proposal.py": "sha256:88423910a7409b8834f0239091010d56938e08dd68fdb3902f71e1e4f13b89ca",
    "output/qa/phase6/diagnostics/two-column-compact-v1/register_compact_rights.py": "sha256:386e09cb92ca2344fbd16ed963b19864bfd5ab70136d502d21d7c258e6c518f9",
    "hero_engine/phase6_av_body_case_amendment.py": "sha256:a175510b5d9326661069431d6b2ddf3d1bd04e59f45c6b6f66fe89bc6c3e001c",
    "tests/test_phase6_av_body_case_amendment.py": "sha256:bea0c5aa7f1ed8a0166577d2be47cecf3d1ccd8e80a5f729eaeaf854df7d0410",
    "hero_engine/phase6_av_body_sources.py": "sha256:e240c94ab4ceb0f767456c733ef200d65d4d8661d95256fc000dd8684a0d590b",
    "tests/test_phase6_av_body_sources.py": "sha256:e51b5b75aea40b624eb67aced5281e38700235108790e2c2aa3f79e40e518cc1",
    "hero_engine/phase6_body_asset_rights.py": "sha256:4ddfe87c01d75d6d412a7d2c61cafa88da49f07d9fb51886539854e85dbe06c7",
    "tests/test_phase6_body_asset_rights.py": "sha256:658b2e0784f4c31362e8d2d91ccb13e7d4bf4469f4d8271d225a1d35e7701083",
    "schemas/phase6_body_static_rights.schema.json": "sha256:107720e004776b554d8d234910a7abe87a79c44400d01a1d63b24aee5c07a541",
    "hero_engine/phase6_av_body_sources_replay.py": "sha256:7f9867ea5313f4cc20425b2c8b3c2063f229fc9bbe95baa8293739f0a5a61da0",
    "tests/test_phase6_av_body_sources_replay.py": "sha256:48d56c8ce521d53f9a69e71bbca620b264676e618b10211bf5dd6f28ee858757",
    "hero_engine/phase6_av_static_uses_v3_replay.py": "sha256:44e05f4580474d19b8ed68b24ee8f93171911f93e91ff332b7d50eb53029bb44",
    "tests/test_phase6_av_static_uses_v3_replay.py": "sha256:11231eef1ea9ea9b10db62e64a7dc9b6649297a26cc51fc1fcebc20ce0782ff6",
    "hero_engine/phase6_av_static_asset_uses_v4.py": "sha256:693016fa543353325fde4c486d9e6b70691d0c8e14b5635a499104db2a6319f6",
    "schemas/phase6_av_static_asset_uses_v4.schema.json": "sha256:6a5ae0fc0397c64c3fceb4918768e7dcc29ab41b65bf691a19ee8e255540589a",
    "hero_engine/phase6_av_asset_use_binding_v3.py": "sha256:c30562a2af5099f78f3f87adcbb99101fcc6fecff09228c324c53641c61c9d74",
    TEXTWRAP: "sha256:62867e40cdea6669b361f72af4d7daf0359f207c92cbeddfc7c7506397c1f31c",
})
# Explicit T11 candidate: only reviewed direct replay dependencies differ.
# These are fixed source pins, not results learned from executing tests.
# An old A12 timeline cannot inherit this current population or pass A.verify.
A_PINS = MappingProxyType({
    **HISTORICAL_A12_PINS,
    "hero_engine/phase6_av_static_uses_v3_replay.py": "sha256:b7d177a3b284c3c2b6d4330a94cc2468fe692cabd210de34fb5f3fde332c490a",
    "tests/test_phase6_av_static_uses_v3_replay.py": "sha256:81a5e4933591cd4ace07b449fafa7d4d12fbbf478967dabc69ab71040caa1465",
    "hero_engine/phase6_av_static_asset_uses_v4.py": "sha256:61d492cfd16669417f4b403453a041743ddc1c379afbd7a54bd03603a651c76a",
})
CONTEXT_PINS = MappingProxyType({
    "hero_engine/phase6_av_context.py": "sha256:100d332ec3e5416c21270310091e41877d35e4a4a78804f319872e63a681a454",
    "hero_engine/queue_phase6.py": "sha256:0b93848660451e78bb82478d6b56d7a38bbcbf3a94d07684e2d4e6038e4ea822",
    ARGUMENTS_SCHEMA: "sha256:58f8ef198ea4cd78b809556a01ab412a526c2ecc2caa0de0b2df9f692b2419f3",
    "schemas/phase6_production_inputs_receipt.schema.json": "sha256:a2087835c5851c2ec3857b96287881defd600e829ea5a46f5afe159e31febdb3",
    "schemas/phase6_media_job_supersession_receipt.schema.json": "sha256:e1dff1eadd27d7736fc0ec362571fc25a9a8739204cd7f7f02f73326d9125d50",
    "schemas/phase6_post_effect_media_job_supersession_receipt.schema.json": "sha256:1498694674057c94f111184dd59d695303398f99185cfa85ded44abeecbece39",
})


class StageAError(ValueError):
    """Canonical evidence is missing, incomplete, changed or outside this adapter."""


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _same(left, right, reason):
    if _canonical(left) != _canonical(right):
        raise StageAError(reason)


def _json(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result: raise StageAError("duplicate JSON key")
            result[key] = value
        return result
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(StageAError("nonfinite JSON")))
    if type(value) is not dict: raise StageAError("JSON object required")
    return value


def _resident(path):
    path = Path(path).absolute()
    if ".." in path.parts: raise StageAError("parent traversal forbidden")
    for part in (path, *path.parents):
        info = part.lstat()
        if (stat.S_ISLNK(info.st_mode) or part.is_symlink()
                or getattr(part, "is_junction", lambda: False)()
                or getattr(info, "st_file_attributes", 0) & (0x1000 | 0x40000 | 0x400000)):
            raise StageAError("linked or nonresident evidence forbidden")
    return path


class _Files:
    def __init__(self):
        self._records = {}

    def read(self, path, digest=None, *, limit=FILE_LIMIT):
        path = _resident(path)
        before = path.stat()
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or
                not 0 < before.st_size <= limit):
            raise StageAError("nonregular, linked, empty or oversized evidence")
        raw = path.read_bytes()
        after = _resident(path).stat()
        fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
        if tuple(getattr(before, k) for k in fields) != tuple(getattr(after, k) for k in fields):
            raise StageAError("evidence changed while reading")
        actual = _sha(raw)
        if len(raw) != before.st_size or (digest is not None and actual != digest):
            raise StageAError("evidence hash or size differs")
        record = (actual, len(raw), limit)
        if self._records.setdefault(path, record) != record:
            raise StageAError("evidence changed inside canonical-A operation")
        return raw

    def recheck(self):
        for path, (digest, size, limit) in tuple(self._records.items()):
            if len(self.read(path, digest, limit=limit)) != size:
                raise StageAError("evidence changed at final recheck")


def _binding_document(root, files, binding, parent):
    if (type(binding) is not dict or set(binding) != {"path", "sha256", "size_bytes"}
            or type(binding["path"]) is not str or type(binding["size_bytes"]) is not int
            or not 0 < binding["size_bytes"] <= METADATA_LIMIT
            or type(binding["sha256"]) is not str
            or re.fullmatch(r"sha256:[a-f0-9]{64}", binding["sha256"]) is None):
        raise StageAError("external immutable path/hash/size triple required")
    relative = binding["path"]
    if Path(relative).is_absolute() or ".." in Path(relative).parts or relative != Path(relative).as_posix():
        raise StageAError("canonical project-relative path required")
    if Path(relative).parent.as_posix() != parent:
        raise StageAError("immutable evidence outside its exact namespace")
    raw = files.read(root / relative, binding["sha256"], limit=METADATA_LIMIT)
    if len(raw) != binding["size_bytes"]: raise StageAError("external byte size differs")
    return _json(raw)


def _identity(value, field, prefix, binding):
    expected = prefix + _sha(_canonical({k: v for k, v in value.items() if k != field}))[7:31]
    if value.get(field) != expected or Path(binding["path"]).name != expected + ".json":
        raise StageAError("content-addressed identity or immutable filename differs")


def _schema(files, value, name):
    digest = A_PINS.get(name) or CONTEXT_PINS[name]
    schema = _json(files.read(CODE_ROOT / name, digest))
    error = next(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(value), None)
    if error is not None: raise StageAError("schema rejected canonical-A evidence: " + error.message)


def _implementation_population(timeline):
    expected = [{"path": path, "sha256": digest} for path, digest in A_PINS.items() if path != A_MODULE]
    _same(timeline.get("implementation"), {"path": A_MODULE, "sha256": A_PINS[A_MODULE]}, "unapproved Stage-A implementation")
    _same(timeline.get("implementation_dependencies"), expected, "Stage-A implementation population differs")


def _complete(timeline):
    assessment = timeline.get("temporal_evidence_assessment") or {}
    if (timeline.get("status") != "TIMELINE_VALIDATED_NOT_ADMITTED"
            or timeline.get("derived_take_plan") is None or timeline.get("blockers") != []
            or not timeline.get("render_spans") or len(timeline.get("units") or []) != 51
            or len(timeline.get("narration_fragment_map") or []) != 90
            or assessment.get("scope_complete") is not True
            or assessment.get("fixture_evidence_present") is not False
            or assessment.get("all_required_evidence_live") is not True
            or timeline.get("authority") != {k: False for k in
                ("synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized", "quality_approved")}
            or type(timeline.get("technical_cost_brl")) is not int or timeline["technical_cost_brl"] != 0):
        raise StageAError("STAGE_A_INCOMPLETE_NOT_SCREENABLE")


def _module(name, root=CODE_ROOT):
    module = importlib.import_module(name)
    if _resident(Path(module.__file__)) != root / (name.replace(".", "/") + ".py"):
        raise StageAError("loaded implementation origin differs")
    return module


def _resolve_context(root, root_id):
    # The queue resolver loads schemas relative to its data root. Pin those
    # actual files too, not only their installation-root counterparts.
    files = _Files()
    for name, digest in CONTEXT_PINS.items():
        if name.startswith("schemas/"): files.read(root / name, digest)
    result = _module("hero_engine.phase6_av_context").resolve_phase6_av_context(root, expected_root_job_id=root_id)
    files.recheck()
    return result


def _verify_timeline(root, timeline, arguments):
    return _module("hero_engine.phase6_av_timeline").verify(root, timeline, **arguments, require_complete=True)


def _context_input(root, files, observation, arguments, root_id):
    if (observation.get("context_version") != "phase6-av-observational-context-v1"
            or observation.get("status") != "OBSERVED_TERMINAL_CONTEXT_NOT_TRANSACTION_AUTHORITY"
            or observation.get("authority") != {k: False for k in
                ("admission", "successor_creation", "queue_claim", "render", "publication")}
            or observation.get("transaction_fencing_verified") is not False
            or observation.get("external_publication_lock_verified") is not False):
        raise StageAError("queue observation claimed unsupported authority")
    context = observation["context"]
    if (context["authority_root_job_id"] != root_id or context["predecessor_state"] != "SUCCEEDED"
            or context["predecessor_lease_owner"] is not None or context["tail_job_id"] != context["predecessor_job_id"]):
        raise StageAError("canonical queue tail differs")
    reference = observation["input_receipt"]
    if type(reference) is not dict or set(reference) != {"receipt_id", "path", "sha256", "size_bytes"}:
        raise StageAError("discovered input reference differs")
    binding = {k: reference[k] for k in ("path", "sha256", "size_bytes")}
    value = _binding_document(root, files, binding, INPUTS)
    _schema(files, value, "schemas/phase6_production_inputs_receipt.schema.json")
    if (reference["path"] != INPUTS + "/" + reference["receipt_id"] + ".json"
            or value["receipt_id"] != reference["receipt_id"]
            or context["input_receipt_id"] != reference["receipt_id"]
            or context["input_receipt_sha256"] != reference["sha256"]
            or value["channel_id"] != arguments["channel_id"]
            or value["action"] != "PREPARE_VIDEO_2_INPUTS"
            or value["publication_authorized"] is not False
            or type(value["technical_cost_brl"]) is not int or value["technical_cost_brl"] != 0):
        raise StageAError("discovered input identity/envelope differs")
    rows = [row for row in value["artifacts"] if Path(row["path"]).name == "take_plan.json"]
    take_binding = arguments["arguments"]["source_bindings"]["take_plan"]
    if len(rows) != 1 or rows[0]["sha256"] != take_binding["sha256"]:
        raise StageAError("Stage-A TakePlan differs from discovered canonical input")
    for relative in (rows[0]["path"], take_binding["path"]):
        if (type(relative) is not str or Path(relative).is_absolute() or ".." in Path(relative).parts
                or relative != Path(relative).as_posix()):
            raise StageAError("canonical input TakePlan must remain project-relative")
    if _resident(root / rows[0]["path"]) != _resident(root / take_binding["path"]):
        raise StageAError("Stage-A TakePlan path differs from canonical input")
    return copy.deepcopy(binding)


def _dependency_closure(root, verified):
    """Called ONLY on the result obtained from A.verify in this invocation."""
    primitives = _module("hero_engine.phase6_av_static_sources")
    uses = _module("hero_engine.phase6_av_static_asset_uses_v4")
    previous = _module("hero_engine.phase6_av_static_uses_v3_replay")
    body = _module("hero_engine.phase6_av_body_sources_replay")
    case = _module("hero_engine.phase6_av_body_case_amendment")
    reader = primitives._Reader(root)
    records, seen = [], set()
    for item in verified["source_file_bindings"]:
        if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
                or type(item["path"]) is not str or item["path"] in seen
                or type(item["sha256"]) is not str or re.fullmatch(r"sha256:[a-f0-9]{64}", item["sha256"]) is None):
            raise StageAError("genuine Stage-A dependency shape differs")
        seen.add(item["path"])
        path = Path(item["path"])
        if not path.is_absolute(): path = root / path
        records.append({"path": str(path), "sha256": item["sha256"][7:], "size_bytes": item["size_bytes"]})
    uses._dependencies(reader, records)  # No decoder, only exact bounded file reads.
    for name, digest in A_PINS.items():
        if name != TEXTWRAP: reader.read(name, digest[7:])

    def recheck():
        # These readers require their fixed anchors and reconstructed complete
        # inventories. No serialized candidate is ever passed as a proof sink.
        previous.recheck(reader)
        body.recheck(reader)
        case._inventory(root)

    return recheck


class _View:
    """Read-only access to independent copies, valid only inside its owner scope."""
    def __init__(self, session):
        self.__session = session

    @property
    def timeline(self):
        self.__session.active()
        return copy.deepcopy(self.__session.timeline)

    @property
    def evidence(self):
        self.__session.active()
        return copy.deepcopy(self.__session.evidence)

    def recheck(self):
        self.__session.recheck()


class _Session:
    def __init__(self, root, timeline_binding, arguments_binding, root_id):
        self.closed = False
        self.root = _resident(root)
        self.root_id = root_id
        self.files = _Files()
        if type(root_id) is not str or re.fullmatch(r"job-[a-f0-9]{24}", root_id) is None:
            raise StageAError("exact canonical root job selector required")
        # Capture this adapter before any external preparation. It is a change
        # detector, NOT approval of an arbitrary caller-selected implementation.
        self.files.read(CODE_ROOT / MODULE)
        timeline = _binding_document(self.root, self.files, timeline_binding, TIMELINES)
        arguments = _binding_document(self.root, self.files, arguments_binding, ARGUMENTS)
        _schema(self.files, timeline, A_SCHEMA)
        _schema(self.files, arguments, ARGUMENTS_SCHEMA)
        _identity(timeline, "timeline_id", "phase6-av-timeline-", timeline_binding)
        _identity(arguments, "arguments_id", "phase6-av-arguments-", arguments_binding)
        if (timeline["timeline_version"] != "phase6-av-timeline-v12" or timeline["schema_version"] != "1.11.0"
                or arguments["document_type"] != "PHASE6_AV_RAW_ARGUMENTS" or arguments["evidence_mode"] != "LIVE"
                or set(arguments["arguments"]) != ARGUMENT_KEYS):
            raise StageAError("unsupported timeline version or independent LIVE arguments")
        for key in ("channel_id", "video_id", "protocol_id"):
            _same(arguments[key], timeline[key], "Stage-A argument context differs")
        _same(timeline["inputs"], arguments["arguments"], "timeline differs from external arguments")
        _implementation_population(timeline)
        _complete(timeline)  # A12 real exits here: no PCM/A.verify/queue/effects.
        if not {"body_case_amendment", "body_case_evidence", "body_case_staging", "literal_asset_uses"} <= set(arguments["arguments"]["source_bindings"]):
            raise StageAError("adapter supports only the installed A12 body-case/V4 route")
        for name, digest in {**dict(A_PINS), **dict(CONTEXT_PINS)}.items():
            self.files.read(Path(name) if name == TEXTWRAP else CODE_ROOT / name, digest)
        self.observation = _resolve_context(self.root, root_id)
        self.input_binding = _context_input(self.root, self.files, self.observation, arguments, root_id)
        result = _verify_timeline(self.root, copy.deepcopy(timeline), copy.deepcopy(arguments["arguments"]))
        _same(result, timeline, "Stage-A verifier result differs from externally pinned candidate")
        _complete(result)
        self.timeline = copy.deepcopy(result)
        self._dependencies = _dependency_closure(self.root, result)
        self.evidence = {
            "version": VERSION, "status": "CANONICAL_STAGE_A_SCOPE_NOT_ADMITTED",
            "timeline": copy.deepcopy(timeline_binding), "arguments": copy.deepcopy(arguments_binding),
            "timeline_id": result["timeline_id"], "timeline_canonical_sha256": _sha(_canonical(result)),
            "queue_observation": copy.deepcopy(self.observation), "input_receipt": self.input_binding,
            "stage_a_verifier_calls": 1, "authority": dict(AUTHORITY), "technical_cost_brl": 0,
            "boundary": "SAME_CALL_ONLY_NOT_PERSISTED_PUBLICITY_OR_TRANSACTION_AUTHORITY",
        }
        self.recheck()

    def active(self):
        if self.closed: raise StageAError("canonical-A scope is already closed")

    def recheck(self):
        self.active()
        self.files.recheck()
        self._dependencies()
        current = _resolve_context(self.root, self.root_id)
        _same(current, self.observation, "canonical root/tail/input changed during publicity preparation")
        self.files.recheck()


@contextmanager
def verified_stage_a(root, *, timeline_binding, arguments_binding, expected_root_job_id):
    """Yield a non-authoritative view; reject if any private closure changes.

    Future PUBLICITY must create this scope internally and return success only
    after it closes. No public API accepts a view/receipt/dependency sink in lieu
    of preparation. One A.verify per scope; final rechecks never call it again.
    """
    session = _Session(root, copy.deepcopy(timeline_binding), copy.deepcopy(arguments_binding), expected_root_job_id)
    try:
        yield _View(session)
    finally:
        try:
            session.recheck()
        finally:
            session.closed = True
