from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .db import ROOT
from .phase5_human_review import (
    ATTESTATION,
    HUMAN_REVIEW_DIR,
    _read_json,
    _validate,
    _write_json_atomic,
    build_review_draft,
    evaluate_submission,
)


HOST = "127.0.0.1"
DEFAULT_PORT = 8765
V3 = Path("output/production/phase5/pilot-001/creative-v3")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _resolve(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _vtt_from_srt(value: str) -> bytes:
    body = re.sub(r"(\d{2}:\d{2}:\d{2}),(\d{3})", r"\1.\2", value.replace("\r\n", "\n"))
    return ("WEBVTT\n\n" + body.lstrip()).encode("utf-8")


def _startup_notice(status: dict[str, Any], access_path: Path) -> dict[str, Any]:
    return {
        "status": status["status"],
        "host": status["host"],
        "port": status["port"],
        "video_sha256": status["video_sha256"],
        "access_file": str(access_path),
        "token_sha256": status["token_sha256"],
    }


def review_context(root: Path = ROOT) -> dict[str, Any]:
    root = root.resolve()
    draft = build_review_draft(root)
    package = _read_json(root / V3 / "publication_package.json")
    thumbnails = _read_json(root / V3 / "thumbnail/thumbnail_set_manifest.json")
    video = _resolve(root, draft["artifact"]["path"])
    captions = _resolve(root, package["captions"]["path"])
    candidates = {
        item["candidate_id"]: {
            "path": _resolve(root, item["path"]),
            "text": item["text"],
            "hypothesis": item["hypothesis"],
        }
        for item in thumbnails["candidates"]
        if item["automated_status"] == "PASS"
    }
    if not video.is_file() or not captions.is_file() or set(candidates) != {"A", "B", "C"}:
        raise FileNotFoundError("Review console requires the frozen video, captions and all A/B/C candidates")
    return {
        "draft": draft,
        "package": package,
        "video": video,
        "captions": captions,
        "candidates": candidates,
    }


def render_console_html(context: dict[str, Any], token: str) -> bytes:
    draft = context["draft"]
    client = {
        "draft": draft,
        "title": context["package"]["metadata"]["title"],
        "token": token,
        "attestation": ATTESTATION,
        "candidateIds": sorted(context["candidates"]),
    }
    payload = json.dumps(client, ensure_ascii=False).replace("</", "<\\/")
    html = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>HeroVerse — Independent Review</title>
<style>
:root{color-scheme:dark;--bg:#07131f;--card:#0d2233;--line:#25445b;--gold:#d7a94a;--text:#edf3f7;--muted:#9eb2c0;--bad:#ff746c;--good:#66d09a}*{box-sizing:border-box}body{margin:0;background:linear-gradient(145deg,#06111c,#0b2132);font:15px/1.45 system-ui;color:var(--text)}main{max-width:1180px;margin:auto;padding:24px}.hero,.card{background:rgba(13,34,51,.96);border:1px solid var(--line);border-radius:15px;padding:18px;margin:14px 0;box-shadow:0 12px 30px #0005}h1,h2{margin:.2em 0;color:#fff}h1{font-size:clamp(26px,4vw,44px)}h2{font-size:20px}.eyebrow{color:var(--gold);font-weight:800;letter-spacing:.12em;text-transform:uppercase}.muted{color:var(--muted)}.hash{font:12px ui-monospace;overflow-wrap:anywhere}.video-shell{max-width:100%;margin:auto;transition:max-width .2s}video{width:100%;background:#000;border-radius:10px}.controls,.grid{display:grid;gap:12px}.controls{grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}.grid{grid-template-columns:repeat(auto-fit,minmax(300px,1fr))}.row{display:grid;grid-template-columns:140px 1fr;gap:10px;align-items:center;margin:9px 0}label{font-weight:650}input,select,textarea,button{width:100%;border-radius:8px;border:1px solid #36566d;background:#091a28;color:var(--text);padding:10px}textarea{min-height:70px;resize:vertical}button{cursor:pointer;background:#14364f;font-weight:750}button.primary{background:var(--gold);color:#101820;border:0;font-size:17px}button:disabled{opacity:.45;cursor:not-allowed}.review-item{border-left:4px solid var(--gold)}.thumbs{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.thumb{border:2px solid transparent;border-radius:12px;padding:8px;background:#081925}.thumb:has(input:checked){border-color:var(--gold)}.thumb img{width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:8px}.thumb .identity{display:none}.checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px}.check{display:flex;gap:8px;align-items:flex-start}.check input{width:auto;margin-top:4px}.status{padding:12px;border-radius:9px;background:#081925}.pass{color:var(--good)}.fail{color:var(--bad)}@media(max-width:700px){main{padding:10px}.row{grid-template-columns:1fr}.thumbs{grid-template-columns:1fr}}
</style></head><body><main>
<section class="hero"><div class="eyebrow">HeroVerse · hash-pinned human gate</div><h1 id="title"></h1><p>This console cannot approve itself. It records a real owner/designated-human review of the exact STANDARD file.</p><div class="hash" id="hash"></div></section>
<section class="card"><h2>1. Full sequential playback</h2><div id="videoShell" class="video-shell"><video id="video" controls preload="metadata" crossorigin="anonymous"><source id="videoSource" type="video/mp4"><track id="captionTrack" kind="captions" srclang="en" label="English" default></video></div><div class="controls"><div class="status">Media: <strong id="mediaStatus">Loading…</strong></div><div class="status">Coverage: <strong id="coverage">0%</strong></div><button id="mobile">Toggle 390 px mobile preview</button><div class="status">Playback rate: <strong id="rate">1.0×</strong></div></div><p class="muted">Play from start to finish at 1.0×. Coverage, rate changes, captions and the mobile-preview check are recorded locally.</p></section>
<section class="card"><h2>2. Reviewer</h2><div class="row"><label for="name">Full name</label><input id="name" autocomplete="name"></div><div class="row"><label for="reviewerId">Reviewer ID</label><input id="reviewerId" placeholder="owner-matheus or designated-human-id"></div><div class="row"><label for="role">Role</label><select id="role"><option value="OWNER_HUMAN">Owner human</option><option value="DESIGNATED_INDEPENDENT_HUMAN">Designated independent human</option></select></div><div class="row"><label for="conflict">Conflict disclosure</label><textarea id="conflict" placeholder="State your relationship to the project and any conflict."></textarea></div><div class="checks"><label class="check"><input type="checkbox" id="audio">I monitored voice, music and effects with audio enabled.</label><label class="check"><input type="checkbox" id="attest">I attest to the exact statement required by the review contract.</label></div></section>
<section><h2>3. Nine required time windows</h2><div class="grid" id="windows"></div></section>
<section><h2>4. Twelve human gates</h2><div class="grid" id="gates"></div></section>
<section class="card"><h2>5. Blind thumbnail selection</h2><p class="muted">Candidates are shuffled and their A/B/C identities remain hidden until the submission is evaluated.</p><div class="thumbs" id="thumbs"></div></section>
<section class="card"><h2>6. Submit to the Gestor Central</h2><p id="attestation" class="muted"></p><button class="primary" id="submit">Validate and submit review</button><pre id="result" class="status"></pre></section>
</main><script>
const C=__CLIENT__;const q='?token='+encodeURIComponent(C.token);document.getElementById('title').textContent=C.title;document.getElementById('hash').textContent='STANDARD SHA-256 '+C.draft.artifact.sha256;document.getElementById('attestation').textContent=C.attestation;
const video=document.getElementById('video'),covered=new Set();document.getElementById('videoSource').src='/media/video'+q;document.getElementById('captionTrack').src='/media/captions'+q;video.load();let rateOk=true,mobileSeen=false,captionSeen=false,startedAt=null,sequentialOk=true,endedSeen=false;
video.addEventListener('loadedmetadata',()=>{document.getElementById('mediaStatus').textContent='Ready · '+video.duration.toFixed(1)+' s'});video.addEventListener('error',()=>{let code=video.error?video.error.code:'unknown';document.getElementById('mediaStatus').textContent='ERROR '+code+' · reload the latest console';document.getElementById('mediaStatus').className='fail'});
video.addEventListener('play',()=>{if(!startedAt)startedAt=new Date().toISOString()});video.addEventListener('timeupdate',()=>{covered.add(Math.floor(video.currentTime));let pct=Math.min(100,covered.size/Math.ceil(video.duration||239)*100);document.getElementById('coverage').textContent=pct.toFixed(1)+'%';if(video.textTracks[0]&&video.textTracks[0].mode==='showing')captionSeen=true});video.addEventListener('seeking',()=>{if(startedAt&&!endedSeen)sequentialOk=false});video.addEventListener('ended',()=>{endedSeen=true});video.addEventListener('ratechange',()=>{document.getElementById('rate').textContent=video.playbackRate.toFixed(1)+'×';if(video.playbackRate!==1)rateOk=false});document.getElementById('mobile').onclick=()=>{let shell=document.getElementById('videoShell');shell.style.maxWidth=shell.style.maxWidth?'':'390px';mobileSeen=true};
function itemCard(item,index,type){let d=document.createElement('article');d.className='card review-item';let label=type==='window'?`${Math.floor(item.start_ms/1000)}–${(item.end_ms/1000).toFixed(item.end_ms%1000?1:0)} s`:item.gate;d.innerHTML=`<h2>${label}</h2><p>${item.criterion}</p>${type==='window'?'<button type="button" class="jump">Jump to window</button>':''}<div class="row"><label>Status</label><select class="item-status"><option value="">Choose…</option><option>PASS</option><option>FAIL</option><option>NEEDS_REVIEW</option></select></div><label>Observed evidence / defect</label><textarea class="note" placeholder="Describe what you actually heard and saw; do not write only OK."></textarea>`;if(type==='window')d.querySelector('.jump').onclick=()=>{video.currentTime=item.start_ms/1000;video.play()};return d}
C.draft.windows.forEach((x,i)=>document.getElementById('windows').append(itemCard(x,i,'window')));C.draft.human_gates.forEach((x,i)=>document.getElementById('gates').append(itemCard(x,i,'gate')));
const order=[...C.candidateIds].sort(()=>crypto.getRandomValues(new Uint32Array(1))[0]-.5);order.forEach((id,pos)=>{let l=document.createElement('label');l.className='thumb';l.innerHTML=`<input type="radio" name="thumb" value="${id}"><strong>Candidate ${pos+1}</strong><img src="/media/thumb/${id}${q}" alt="Blind thumbnail candidate ${pos+1}"><span class="identity">${id}</span>`;document.getElementById('thumbs').append(l)});
function filled(item,node){let status=node.querySelector('.item-status').value,note=node.querySelector('.note').value.trim();if(!status||!note)throw new Error('Every window and gate needs a status and an evidence note.');let defects=status==='PASS'?[]:[{start_ms:item.start_ms||0,end_ms:item.end_ms||C.draft.artifact.duration_ms,defect:note,expected_correction:'Correct the documented defect and submit a new independently reviewed candidate.'}];return {...item,status,evidence_note:note,defects}}
document.getElementById('submit').onclick=async()=>{let out=document.getElementById('result');try{let duration=Math.ceil(video.duration||C.draft.artifact.duration_ms/1000),coverage=covered.size/duration;let nodes=[...document.querySelectorAll('#windows .review-item')],gateNodes=[...document.querySelectorAll('#gates .review-item')];let windows=C.draft.windows.map((x,i)=>filled(x,nodes[i]));let gates=C.draft.human_gates.map((x,i)=>filled(x,gateNodes[i]));let thumb=document.querySelector('input[name=thumb]:checked')?.value;if(!thumb)throw new Error('Choose one blind thumbnail candidate.');let statuses=[...windows,...gates].map(x=>x.status);let verdict=statuses.includes('FAIL')?'FAIL':statuses.includes('NEEDS_REVIEW')?'NEEDS_REVIEW':'PASS';if(!endedSeen||!sequentialOk||coverage<.95)throw new Error('Complete one uninterrupted sequential playback from start to end.');if(!rateOk||video.playbackRate!==1)throw new Error('Playback must remain at 1.0×. Reload and review again.');if(!captionSeen)throw new Error('Enable and check the English caption track.');if(!mobileSeen)throw new Error('Use the 390 px mobile preview before submitting.');if(!document.getElementById('audio').checked)throw new Error('Confirm audio monitoring.');if(!document.getElementById('attest').checked)throw new Error('Confirm the required attestation.');let name=document.getElementById('name').value.trim(),rid=document.getElementById('reviewerId').value.trim(),conflict=document.getElementById('conflict').value.trim();if(!name||!rid||!conflict)throw new Error('Complete reviewer identity and conflict disclosure.');let now=new Date().toISOString();let submission={...C.draft,submission_status:'FINAL',reviewer:{reviewer_id:rid,reviewer_name:name,reviewer_role:document.getElementById('role').value,independent_from_generator:true,conflict_disclosure:conflict,reviewed_at:startedAt||now},review_protocol:{full_duration_reviewed:true,sequential_review:true,playback_speed:1,audio_monitoring:true,caption_track_checked:true,small_screen_legibility_checked:true,thumbnail_review_blinded:true},windows,human_gates:gates,thumbnail_selection:thumb,overall_verdict:verdict,attestation:{attested:true,statement:C.attestation},submitted_at:now};let response=await fetch('/api/review'+q,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(submission)});let body=await response.json();out.textContent=JSON.stringify(body,null,2);out.className='status '+(response.ok?'pass':'fail')}catch(e){out.textContent=e.message;out.className='status fail'}};
</script></body></html>'''.replace("__CLIENT__", payload)
    return html.encode("utf-8")


def _range(value: str | None, size: int) -> tuple[int, int] | None:
    if not value:
        return None
    match = re.fullmatch(r"bytes=(\d*)-(\d*)", value.strip())
    if not match or (not match.group(1) and not match.group(2)):
        raise ValueError("unsupported Range header")
    if match.group(1):
        start = int(match.group(1))
        end = int(match.group(2)) if match.group(2) else size - 1
    else:
        length = int(match.group(2))
        start, end = max(0, size - length), size - 1
    if start >= size or start > end:
        raise ValueError("range outside file")
    return start, min(end, size - 1)


def make_handler(root: Path, token: str, context: dict[str, Any]) -> type[BaseHTTPRequestHandler]:
    html = render_console_html(context, token)
    routes = {
        "/media/video": (context["video"], "video/mp4"),
        **{f"/media/thumb/{key}": (item["path"], "image/jpeg") for key, item in context["candidates"].items()},
    }

    class Handler(BaseHTTPRequestHandler):
        server_version = "HeroVerseReviewConsole/1.0"

        def log_message(self, fmt: str, *args: Any) -> None:
            return

        def _authorized(self) -> bool:
            supplied = parse_qs(urlparse(self.path).query).get("token", [""])[0]
            return secrets.compare_digest(supplied, token)

        def _json(self, status: int, value: Any) -> None:
            data = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self._write_body(data)

        def _write_body(self, content: bytes) -> bool:
            try:
                self.wfile.write(content)
                return True
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return False

        def _fixed_bytes(self, content: bytes, content_type: str) -> None:
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            if content_type.startswith("text/html"):
                self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; media-src 'self'; connect-src 'self'")
            self.end_headers()
            if self.command != "HEAD":
                self._write_body(content)

        def _file(self, path: Path, content_type: str) -> None:
            size = path.stat().st_size
            try:
                selected = _range(self.headers.get("Range"), size)
            except ValueError:
                self.send_error(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                return
            start, end = selected or (0, size - 1)
            self.send_response(HTTPStatus.PARTIAL_CONTENT if selected else HTTPStatus.OK)
            self.send_header("Content-Type", content_type)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            if selected:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command == "HEAD":
                return
            remaining = end - start + 1
            with path.open("rb") as stream:
                stream.seek(start)
                while remaining:
                    chunk = stream.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    if not self._write_body(chunk):
                        return
                    remaining -= len(chunk)

        def do_HEAD(self) -> None:
            self.do_GET()

        def do_GET(self) -> None:
            if not self._authorized():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            route = urlparse(self.path).path
            if route == "/":
                self._fixed_bytes(html, "text/html; charset=utf-8")
            elif route == "/media/captions":
                self._fixed_bytes(_vtt_from_srt(context["captions"].read_text(encoding="utf-8-sig")), "text/vtt; charset=utf-8")
            elif route in routes:
                self._file(*routes[route])
            else:
                self.send_error(HTTPStatus.NOT_FOUND)

        def do_POST(self) -> None:
            if not self._authorized() or urlparse(self.path).path != "/api/review":
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 250_000:
                    raise ValueError("review payload size is invalid")
                submission = json.loads(self.rfile.read(length).decode("utf-8"))
                submission["submitted_at"] = _utc_now()
                evaluation = evaluate_submission(submission, root)
                decision = evaluation["decision"]
                if decision == "NEEDS_REVIEW":
                    _write_json_atomic(root / HUMAN_REVIEW_DIR / "review_submission.attempt.json", submission)
                    _write_json_atomic(root / HUMAN_REVIEW_DIR / "review_evaluation.attempt.json", evaluation)
                    self._json(HTTPStatus.UNPROCESSABLE_ENTITY, {"status": decision, "saved_as_attempt": True, "evaluation": evaluation})
                    return
                final = root / HUMAN_REVIEW_DIR / "review_submission.json"
                if final.exists():
                    raise FileExistsError("A canonical final review already exists and was not overwritten")
                _write_json_atomic(final, submission)
                _write_json_atomic(root / HUMAN_REVIEW_DIR / "review_evaluation.json", evaluation)
                self._json(HTTPStatus.OK, {"status": decision, "canonical_submission": str(final), "evaluation": evaluation})
            except Exception as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"status": "REJECTED", "error": f"{type(exc).__name__}: {exc}"})

    return Handler


def serve(root: Path = ROOT, *, port: int = DEFAULT_PORT, token: str | None = None) -> None:
    root = root.resolve()
    context = review_context(root)
    token = token or secrets.token_urlsafe(24)
    server = ThreadingHTTPServer((HOST, port), make_handler(root, token, context))
    started_at = _utc_now()
    status_path = root / "output/runtime/gestor-central/review-console-status.json"
    status = {
        "schema_version": "1.0.0",
        "console_id": "phase5-independent-review-console-v1",
        "supervisor": "gestor-central-heroverse-phase5-v1",
        "status": "LISTENING",
        "host": HOST,
        "port": server.server_port,
        "process_id": os.getpid(),
        "video_sha256": context["draft"]["artifact"]["sha256"],
        "token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest(),
        "canonical_review_exists": (root / HUMAN_REVIEW_DIR / "review_submission.json").is_file(),
        "started_at": started_at,
        "stopped_at": None,
    }
    _validate(root, "phase5_review_console_runtime.schema.json", status)
    _write_json_atomic(status_path, status)
    url = f"http://{HOST}:{server.server_port}/?token={token}"
    access = {
        "schema_version": "1.0.0",
        "console_id": status["console_id"],
        "url": url,
        "host": HOST,
        "port": server.server_port,
        "token_sha256": status["token_sha256"],
        "local_only": True,
        "issued_at": started_at,
    }
    _validate(root, "phase5_review_console_access.schema.json", access)
    access_path = root / "output/runtime/gestor-central/review-console-access.json"
    _write_json_atomic(access_path, access)
    print(json.dumps(_startup_notice(status, access_path)), flush=True)
    try:
        server.serve_forever()
    finally:
        status["status"] = "STOPPED"
        status["canonical_review_exists"] = (root / HUMAN_REVIEW_DIR / "review_submission.json").is_file()
        status["stopped_at"] = _utc_now()
        _validate(root, "phase5_review_console_runtime.schema.json", status)
        _write_json_atomic(status_path, status)


def main() -> None:
    parser = argparse.ArgumentParser(description="Local, zero-cost independent review console for the frozen Phase 5 candidate")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    args = parser.parse_args()
    serve(args.root, port=args.port)


if __name__ == "__main__":
    main()
