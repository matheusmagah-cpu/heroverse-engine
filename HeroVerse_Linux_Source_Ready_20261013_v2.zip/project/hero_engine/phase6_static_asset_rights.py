"""Read-only binding of an externally reviewed OWNED decision to exact stills.

This does not grant copyright, assert human authorship, issue a legal opinion,
approve publicity or create an approval document. Motion rights are not reused.
Only the two frozen composition families and rasterized text use are in scope.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import re

from . import phase6_av_static_sources as sources
from .phase6_narration_units import canonical_sha

VERSION = "phase6-static-asset-rights-v2"
PRIMARY_NOTE = "docs/evidence/D171_STATIC_RIGHTS_PRIMARY_SOURCES.md"
PRIMARY_NOTE_SHA = "0f7f6c0d241fb50102d35bc90c288b2e259c8fbfb1dbbd1a07b39219e509e407"
PROVENANCE_KEYS = set("schema_version document_type provenance_id evidence_mode recorded_at asset_id channel_id template_id state_id lineage_id png_binding svg_binding recipe_binding generation_receipt_binding source_bindings composition_origin font_use technical_cost_brl".split())
DECISION_KEYS = set("schema_version document_type decision_id evidence_mode reviewed_at asset_id channel_id template_id state_id provenance_binding decision rights_status commercial_use reviewer decision_basis unresolved_questions output_scope platform_disclosure technical_cost_brl".split())
AUTHORITY = {name: False for name in ("selection_authorized", "source_admitted", "render_authorized",
    "queue_authorized", "publication_authorized", "publicity_approved", "quality_approved",
    "final_video_disclosure_approved", "human_review_performed", "legal_opinion_issued")}


class StaticRightsError(ValueError):
    pass


def _require(condition, code):
    if not condition:
        raise StaticRightsError(code)


def _exact(value, keys, code):
    _require(type(value) is dict and set(value) == keys, code)


def _same(actual, expected, code):
    _require(sources._canonical(actual) == sources._canonical(expected), code)


def _text(value, code):
    _require(type(value) is str and bool(value.strip()), code)


def _utc(value):
    _require(type(value) is str and value.endswith("Z"), "EXPLICIT_UTC_REQUIRED")
    instant = datetime.fromisoformat(value[:-1] + "+00:00")
    _require(instant.utcoffset() == timezone.utc.utcoffset(instant), "UTC_REQUIRED")
    _require(instant <= datetime.now(timezone.utc), "FUTURE_REVIEW_NOT_EVIDENCE")
    return instant


def _identity(document, field, prefix):
    payload = {key: value for key, value in document.items() if key != field}
    _same(document[field], prefix + sources._sha(sources._canonical(payload))[:24], "DOCUMENT_IDENTITY_DIFFERS")


def _pin(reader, binding, *, expected=None):
    _exact(binding, {"path", "sha256"}, "EXTERNAL_PIN_FIELDS_DIFFER")
    _require(type(binding["path"]) is str and type(binding["sha256"]) is str
             and re.fullmatch(r"[a-f0-9]{64}", binding["sha256"]) is not None, "EXPLICIT_RAW_SHA256_REQUIRED")
    path = Path(binding["path"])
    if path.is_absolute():
        _require(path.is_relative_to(reader.root), "RIGHTS_DOCUMENT_ESCAPES_ROOT")
        relative = path.relative_to(reader.root).as_posix()
    else:
        relative = binding["path"]
    path = reader.path(relative)
    if expected is not None:
        expected_path, digest = expected
        _same([str(path), binding["sha256"]], [str(reader.root / expected_path), digest], "RIGHTS_SOURCE_PIN_DIFFERS")
    raw = reader.read(relative, binding["sha256"], limit=2 * 1024**2)
    return {"path": str(path), "sha256": binding["sha256"]}, raw


def _document(reader, binding, keys, kind, field, prefix, mode):
    normalized, raw = _pin(reader, binding)
    _require(Path(normalized["path"]).suffix == ".json", "RIGHTS_DOCUMENT_MUST_BE_JSON")
    document = sources._json(raw)
    _require(sources._canonical(document) == raw, "RIGHTS_JSON_NOT_CANONICAL")
    _exact(document, keys, "RIGHTS_DOCUMENT_FIELDS_DIFFER")
    _same([document["schema_version"], document["document_type"], document["evidence_mode"]],
          ["1.0.0", kind, mode], "RIGHTS_DOCUMENT_KIND_OR_EVIDENCE_MODE_DIFFERS")
    _identity(document, field, prefix)
    return document, normalized


def _expected_scope(root, template_id, state_id, receipt_binding):
    _require(type(template_id) is str and template_id in sources.TEMPLATES, "UNSUPPORTED_STATIC_TEMPLATE")
    config = sources.TEMPLATES[template_id]
    _require(type(state_id) is str and state_id in config["state_ids"], "UNSUPPORTED_STATIC_STATE")
    _exact(receipt_binding, {"path", "sha256"}, "STATIC_GENERATION_PIN_REQUIRED")
    _require(receipt_binding["sha256"] == config["receipt_sha256"], "STATIC_GENERATION_PIN_DIFFERS")
    expected = Path(root).absolute() / config["directory"] / "receipt.json"
    _require(receipt_binding["path"] in (str(expected), config["directory"] + "/receipt.json"),
             "STATIC_GENERATION_PATH_DIFFERS")
    return config


def _validate(root, *, template_id, state_id, receipt_binding, provenance_binding,
              decision_binding, expected_evidence_mode):
    config = _expected_scope(root, template_id, state_id, receipt_binding)
    _require(expected_evidence_mode in {"LIVE", "FIXTURE"}, "EXPLICIT_EVIDENCE_MODE_REQUIRED")
    _require(provenance_binding is not None, "STATIC_OWNED_PROVENANCE_MISSING")
    _require(decision_binding is not None, "STATIC_RIGHTS_DECISION_MISSING")
    reader = sources._Reader(root)
    reader.read("hero_engine/phase6_static_asset_rights.py",
                sources._sha(sources._resident(Path(__file__).absolute()).read_bytes()))
    reader.read("hero_engine/phase6_narration_units.py",
                sources._sha(sources._resident(Path(__file__).absolute().with_name("phase6_narration_units.py")).read_bytes()))
    provenance, provenance_pin = _document(reader, provenance_binding, PROVENANCE_KEYS,
        "PHASE6_STATIC_OWNED_PROVENANCE", "provenance_id", "static-owned-provenance-", expected_evidence_mode)
    decision, decision_pin = _document(reader, decision_binding, DECISION_KEYS,
        "PHASE6_STATIC_RIGHTS_DECISION", "decision_id", "static-owned-decision-", expected_evidence_mode)
    _same(decision["provenance_binding"], provenance_pin, "DECISION_REFERENCES_ANOTHER_PROVENANCE")
    _require(_utc(provenance["recorded_at"]) <= _utc(decision["reviewed_at"]), "REVIEW_PRECEDES_PROVENANCE")
    for value in (provenance, decision):
        _same([value["channel_id"], value["template_id"], value["state_id"]],
              [sources.CHANNEL, template_id, state_id], "RIGHTS_CHANNEL_TEMPLATE_OR_STATE_DIFFERS")
        _text(value["asset_id"], "ASSET_ID_REQUIRED")
        _same(value["technical_cost_brl"], 0, "ZERO_TECHNICAL_COST_REQUIRED")
    _same(decision["asset_id"], provenance["asset_id"], "RIGHTS_ASSET_ID_DIFFERS")
    _same(provenance["lineage_id"], config["lineage_id"], "RIGHTS_LINEAGE_DIFFERS")
    _same([decision["decision"], decision["rights_status"], decision["commercial_use"], decision["output_scope"]],
          ["RESPONSIBLE_REVIEW_APPROVED", "OWNED", True, "RASTERIZED_STILL_IN_YOUTUBE_VIDEO"],
          "PERMITTED_OWNED_DECISION_REQUIRED")
    _same(decision["unresolved_questions"], [], "UNRESOLVED_RIGHTS_QUESTIONS")
    reviewer = decision["reviewer"]
    _exact(reviewer, {"id", "type", "human_review_claim", "legal_opinion_claim"}, "REVIEWER_FIELDS_DIFFER")
    _text(reviewer["id"], "RESPONSIBLE_REVIEWER_ID_REQUIRED")
    _same([reviewer["type"], reviewer["human_review_claim"], reviewer["legal_opinion_claim"]],
          ["AUTHORIZED_AUTOMATED_EDITORIAL", False, False], "UNSUPPORTED_REVIEW_AUTHORITY_CLAIM")
    _text(decision["decision_basis"], "RESPONSIBLE_REVIEW_BASIS_REQUIRED")
    origin = provenance["composition_origin"]
    _exact(origin, {"method", "basis", "human_authorship_claim", "exclusive_ai_rights_claim", "third_party_visual_assets"},
           "COMPOSITION_ORIGIN_FIELDS_DIFFER")
    _same([origin["method"], origin["human_authorship_claim"], origin["exclusive_ai_rights_claim"], origin["third_party_visual_assets"]],
          ["PROJECT_CODE_NATIVE_VECTOR", False, False, []], "OWNED_ORIGIN_OR_THIRD_PARTY_SCOPE_DIFFERS")
    _text(origin["basis"], "COMPOSITION_PROVENANCE_BASIS_REQUIRED")
    font = provenance["font_use"]
    _exact(font, {"font_binding", "usage", "font_file_embedded", "font_redistribution", "license_evidence_binding"},
           "FONT_USE_FIELDS_DIFFER")
    _same(font["font_binding"], {"path": str(sources.FONT), "sha256": sources.FONT_SHA}, "FONT_SOURCE_DIFFERS")
    _same([font["usage"], font["font_file_embedded"], font["font_redistribution"]],
          ["RASTERIZED_TEXT_IN_VIDEO", False, False], "FONT_DISTRIBUTION_NOT_AUTHORIZED")
    note, _ = _pin(reader, font["license_evidence_binding"], expected=(PRIMARY_NOTE, PRIMARY_NOTE_SHA))
    disclosure = decision["platform_disclosure"]
    _exact(disclosure, {"scope", "required", "reason", "policy_evidence_binding", "final_video_decision"},
           "STATIC_DISCLOSURE_FIELDS_DIFFER")
    _same([disclosure["scope"], disclosure["final_video_decision"]],
          ["STATIC_IMAGE_ONLY", "REQUIRES_AGGREGATE_VIDEO_GATE"], "DISCLOSURE_CANNOT_APPROVE_WHOLE_VIDEO")
    _require(type(disclosure["required"]) is bool, "EXPLICIT_IMAGE_DISCLOSURE_DECISION_REQUIRED")
    _text(disclosure["reason"], "IMAGE_DISCLOSURE_REASON_REQUIRED")
    _pin(reader, disclosure["policy_evidence_binding"], expected=(PRIMARY_NOTE, PRIMARY_NOTE_SHA))
    # External approval is necessary, never sufficient: independently reopen
    # exact source pixels/recipe/literal contracts rather than accepting labels.
    proof = sources.inspect_static_source(root, template_id=template_id, state_id=state_id,
                                          receipt_binding=receipt_binding)
    proof_files = {item["path"]: item for item in proof["dependency_bindings"]}
    asset = proof["asset_binding"]
    paths = {"png_binding": Path(asset["path"]), "svg_binding": Path(asset["path"]).with_suffix(".svg"),
             "recipe_binding": reader.root / config["runner"],
             "generation_receipt_binding": reader.root / config["directory"] / "receipt.json"}
    bound_artifacts = {}
    for field, path in paths.items():
        expected = proof_files[str(path)]
        _same(provenance[field], {"path": str(path), "sha256": expected["sha256"]}, "OWNED_ARTIFACT_BINDING_DIFFERS")
        pin, _ = _pin(reader, provenance[field])
        bound_artifacts[field] = {**pin, "size_bytes": expected["size_bytes"]}
    input_names = [sources.PLAN, sources.BIBLE] + ([sources.AUDIT] if template_id == "four-criteria-v1" else [])
    expected_inputs = [{"path": str(reader.root / name), "sha256": sources.INPUT_PINS[name]} for name in input_names]
    _same(provenance["source_bindings"], expected_inputs, "OWNED_RECIPE_INPUTS_DIFFER")
    for source in provenance["source_bindings"]:
        _pin(reader, source)
    # Only replay/read: no rights receipt, manifest row or admission is created.
    sources.recheck_static_dependencies(root, [proof])
    for item in tuple(reader.bindings.values()):
        raw = reader.read_path(Path(item["path"]), item["sha256"])
        _same(len(raw), item["size_bytes"], "RIGHTS_DEPENDENCY_SIZE_CHANGED")
    result = {"version": VERSION, "status": "PASS" if expected_evidence_mode == "LIVE" else "PASS_FIXTURE_NOT_LIVE",
        "scope": "RIGHTS_BINDING_ONLY", "evidence_mode": expected_evidence_mode,
        "asset_id": provenance["asset_id"], "channel_id": sources.CHANNEL,
        "template_id": template_id, "state_id": state_id, "lineage_id": config["lineage_id"],
        "media_kind": "STATIC_IMAGE", "source_frame_count": 1,
        "source_start_frame": 0, "source_end_frame": 1,
        "rights_status": "OWNED", "commercial_use": True, "source_ready": False,
        # Preserve the historical pretty-JSON byte pin; Stage A uses a distinct
        # compact canonical encoding, whose prefixed hash is bound explicitly.
        "source_proof": {"inspection_id": proof["inspection_id"], "sha256": sources._sha(sources._canonical(proof)),
                         "timeline_canonical_sha256": canonical_sha(proof)},
        "artifacts": bound_artifacts, "provenance_binding": provenance_pin, "decision_binding": decision_pin,
        "provenance_id": provenance["provenance_id"], "decision_id": decision["decision_id"],
        "platform_disclosure": disclosure, "primary_note_binding": note,
        "dependency_bindings": sorted({item["path"]: item for item in (
            *proof["dependency_bindings"], *reader.bindings.values())}.values(), key=lambda item: item["path"]),
        "technical_cost_brl": 0, "blockers": [], "authority": dict(AUTHORITY),
        "claim_boundary": "Reopened external editorial OWNED decision and exact static source chain only; no new copyright grant, human review, legal opinion, font redistribution, publicity or video approval."}
    result["inspection_id"] = "static-rights-" + sources._sha(sources._canonical(result))[:24]
    return result


def inspect_static_asset_rights(root, *, template_id, state_id, receipt_binding,
                               provenance_binding=None, decision_binding=None,
                               expected_evidence_mode="LIVE"):
    """External documents are required; absent/ambiguous evidence fails closed.

    The default requires LIVE documents. Tests must explicitly request FIXTURE;
    their return is never a LIVE PASS. This function performs no writes/effects.
    """
    try:
        return _validate(root, template_id=template_id, state_id=state_id, receipt_binding=receipt_binding,
                         provenance_binding=provenance_binding, decision_binding=decision_binding,
                         expected_evidence_mode=expected_evidence_mode)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        return {"version": VERSION, "status": "BLOCKED", "scope": "RIGHTS_BINDING_ONLY",
                "rights_status": None, "commercial_use": False, "source_ready": False,
                "technical_cost_brl": 0, "blockers": [str(exc) or type(exc).__name__],
                "authority": dict(AUTHORITY)}


def verify_static_asset_rights(candidate, root, **arguments):
    """Reopen caller-pinned originals, never candidate-selected authority."""
    expected = inspect_static_asset_rights(root, **arguments)
    _same(candidate, expected, "STATIC_RIGHTS_REPLAY_DIFFERS")
    return expected
