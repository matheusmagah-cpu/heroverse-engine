from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker

from .phase6_release import PRODUCTION_INPUT_RECEIPTS, verify_production_inputs_receipt
from .production_capacity import (
    RECEIPTS as CAPACITY_RECEIPTS,
    run_phase6_capacity_preflight,
    verify_phase6_capacity_receipt,
)
from .queue_phase6 import (
    CHANNEL_ID,
    MEDIA_REPAIR_EVIDENCE,
    TransactionalQueue,
)
from .voice_phase5 import (
    build_local_voice,
    espeak_binding_identity,
    revalidate_local_espeak_binding,
    synthesize_voice_sample,
)


ROOT = Path(__file__).resolve().parents[1]
MEDIA_TASK = "EXECUTE_PHASE6_VIDEO2_MEDIA"
MEDIA_ACTION = "SYNTHESIZE_AND_RENDER_VIDEO_2"
EXPECTED_PLAN = Path("output/production/phase6/video-002/production/take_plan.json")
SAMPLE_TEXT = "HeroVerse verifies the corrected local narration path."
JOB_ID_PATTERN = re.compile(r"^job-[a-f0-9]{24}$")
INPUT_RECEIPT_PATTERN = re.compile(r"^phase6-production-inputs-[A-Za-z0-9._-]{1,160}$")


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("available_at must include an explicit timezone")
    return parsed.astimezone(timezone.utc)


def _sha256_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _sha256_text(value: str) -> str:
    return _sha256_bytes(value.encode("utf-8"))


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise PermissionError(f"repair artifact escaped the project root: {path}") from exc


def _resolve_workspace_path(root: Path, value: str | Path) -> Path:
    raw = Path(value)
    candidate = raw if raw.is_absolute() else root / raw
    resolved = candidate.resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PermissionError(f"bound path escaped the project root: {value}") from exc
    return resolved


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema_path = root / "schemas" / schema_name
    if not schema_path.is_file():
        raise FileNotFoundError(f"required schema is unavailable: {schema_name}")
    schema = json.loads(schema_path.read_text(encoding="utf-8-sig"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _write_immutable_bytes(path: Path, payload: bytes, *, label: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if not path.is_file() or path.read_bytes() != payload:
            raise PermissionError(f"immutable {label} collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_bytes(payload)
        try:
            os.link(temporary, path)
        except FileExistsError:
            if not path.is_file() or path.read_bytes() != payload:
                raise PermissionError(f"immutable {label} collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)


def _commit_staged_file(staging: Path, target: Path, *, label: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if not target.is_file() or _sha256_file(target) != _sha256_file(staging):
            raise PermissionError(f"immutable {label} collision: {target.name}")
        staging.unlink(missing_ok=True)
        return
    try:
        os.link(staging, target)
    except FileExistsError:
        if not target.is_file() or _sha256_file(target) != _sha256_file(staging):
            raise PermissionError(f"immutable {label} collision: {target.name}")
    finally:
        staging.unlink(missing_ok=True)


def _job_by_id(queue: TransactionalQueue, job_id: str, moment: datetime) -> dict[str, Any]:
    if not isinstance(job_id, str) or JOB_ID_PATTERN.fullmatch(job_id) is None:
        raise ValueError("job_id must be the exact canonical job-<24 lowercase hex> identity")
    matches = [
        item
        for item in queue.snapshot(captured_at=moment).get("jobs", [])
        if item.get("job_id") == job_id
    ]
    if len(matches) != 1:
        raise LookupError("the exact Phase 6 queue job does not exist")
    job = matches[0]
    if job.get("channel_id") != CHANNEL_ID:
        raise PermissionError("the recovery job is outside the isolated HeroVerse channel")
    if job.get("task_type") != MEDIA_TASK:
        raise PermissionError("only the Phase 6 video-2 media job is recoverable")
    payload = job.get("payload") or {}
    if payload.get("action") != MEDIA_ACTION or not isinstance(
        payload.get("input_receipt_id"), str
    ):
        raise PermissionError("the media job payload is not the exact video-2 command")
    return job


def _recovery_key(job: dict[str, Any]) -> str:
    original_error = str(job.get("last_error") or "")
    if not original_error:
        raise PermissionError("the original dead-letter error is unavailable")
    attempt_count = int(job.get("attempt_count") or 0)
    if attempt_count < 1:
        raise PermissionError("the original dead-letter attempt count is unavailable")
    error_token = hashlib.sha256(original_error.encode("utf-8")).hexdigest()[:16]
    return f"phase6-media-recovery:{job['job_id']}:{attempt_count}:{error_token}"


def _replay_existing_recovery(
    queue: TransactionalQueue,
    *,
    root: Path,
    job: dict[str, Any],
    recovery_key: str,
    available_at: datetime | None,
    moment: datetime,
    capacity_verifier: Callable[..., dict[str, Any]],
) -> dict[str, Any] | None:
    journal = queue.get_dead_letter_recovery(recovery_key)
    if journal is None:
        return None
    receipt = journal["receipt"]
    if (
        journal.get("job_id") != job["job_id"]
        or journal.get("task_type") != MEDIA_TASK
        or receipt.get("job", {}).get("job_id") != job["job_id"]
        or receipt.get("prior_dead_letter", {}).get("state") != "DEAD_LETTER"
    ):
        raise PermissionError("stored recovery journal diverges from the exact media job")
    current_error = str(job.get("last_error") or "")
    original_error = str(receipt["prior_dead_letter"]["last_error"])
    if current_error and current_error != original_error:
        raise PermissionError("stored recovery journal diverges from the preserved failure")
    evidence_path = _resolve_workspace_path(root, receipt["repair_evidence"]["path"])
    if (
        not evidence_path.is_file()
        or _sha256_file(evidence_path) != receipt["repair_evidence"]["sha256"]
    ):
        raise PermissionError("stored recovery evidence bytes changed")
    evidence = json.loads(evidence_path.read_text(encoding="utf-8-sig"))
    _validate(root, "phase6_media_repair_evidence.schema.json", evidence)
    capacity_records = [
        item
        for item in evidence["verification"]["artifacts"]
        if "capacity receipt" in item["purpose"].casefold()
    ]
    if len(capacity_records) != 1:
        raise PermissionError("stored repair evidence lacks one exact capacity receipt")
    capacity_record = capacity_records[0]
    capacity_path = _resolve_workspace_path(root, capacity_record["path"])
    if not capacity_path.is_file() or _sha256_file(capacity_path) != capacity_record["sha256"]:
        raise PermissionError("stored recovery capacity receipt changed")
    capacity = json.loads(capacity_path.read_text(encoding="utf-8-sig"))
    capacity_verifier(
        root,
        receipt_path=capacity_path,
        expected_receipt_id=capacity.get("receipt_id"),
        expected_sha256=capacity_record["sha256"],
        require_pass=True,
    )
    result = queue.recover_media_dead_letter(
        job["job_id"],
        recovery_key=recovery_key,
        repair_evidence_path=receipt["repair_evidence"]["path"],
        repair_evidence_sha256=receipt["repair_evidence"]["sha256"],
        new_max_attempts=int(receipt["recovery"]["new_max_attempts"]),
        available_at=available_at,
        now=moment,
    )
    return result


def _load_exact_take_plan(
    root: Path,
    *,
    job: dict[str, Any],
    production_inputs_verifier: Callable[..., dict[str, Any]],
) -> tuple[dict[str, Any], Path, dict[str, Any], str]:
    receipt_id = str(job["payload"]["input_receipt_id"])
    if INPUT_RECEIPT_PATTERN.fullmatch(receipt_id) is None:
        raise PermissionError("media job contains a non-canonical production-input receipt id")
    checkpoint_id = (job.get("checkpoint") or {}).get("input_receipt_id")
    if checkpoint_id is not None and checkpoint_id != receipt_id:
        raise PermissionError("media checkpoint input identity diverges from the job payload")
    receipt_path = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json"
    receipt = production_inputs_verifier(
        root,
        receipt_path=receipt_path,
        expected_receipt_id=receipt_id,
        required_action="PREPARE_VIDEO_2_INPUTS",
        ensure_immutable=False,
        recheck_decode=True,
    )
    records = [
        item
        for item in receipt.get("artifacts", [])
        if Path(str(item.get("path") or "")).name == "take_plan.json"
    ]
    if len(records) != 1:
        raise PermissionError("production inputs lack one exact TakePlan binding")
    record = records[0]
    plan_path = _resolve_workspace_path(root, str(record["path"]))
    expected_plan = (root / EXPECTED_PLAN).resolve()
    if plan_path != expected_plan or not plan_path.is_file():
        raise PermissionError("the bound TakePlan is not the authoritative Phase 6 video-2 plan")
    plan_hash = _sha256_file(plan_path)
    if plan_hash != record.get("sha256") or plan_path.stat().st_size != record.get(
        "size_bytes"
    ):
        raise PermissionError("the exact TakePlan bytes differ from the input receipt")
    plan = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    _validate(root, "take_plan.schema.json", plan)
    if plan.get("channel_id") != CHANNEL_ID or not plan.get("take_plan_id"):
        raise PermissionError("the TakePlan identity/channel binding is invalid")
    return receipt, plan_path, plan, plan_hash


def _materialize_current_capacity(
    root: Path,
    *,
    plan_path: Path,
    plan: dict[str, Any],
    moment: datetime,
    capacity_runner: Callable[..., dict[str, Any]],
    capacity_verifier: Callable[..., dict[str, Any]],
) -> tuple[dict[str, Any], Path, str]:
    capacity = capacity_runner(
        root,
        plan_path=plan_path,
        now=moment,
        require_asset_residency=True,
    )
    if (
        capacity.get("schema_version") != "1.1.0"
        or capacity.get("scope") != "PRODUCTION_PLAN"
        or capacity.get("status") != "PASS"
        or capacity.get("plan_id") != plan["take_plan_id"]
        or int(capacity.get("take_count") or 0) != len(plan["takes"])
        or capacity.get("technical_cost_brl") != 0
        or capacity.get("publication_authorized") is not False
        or capacity.get("created_at") != _stamp(moment)
    ):
        raise PermissionError("a new schema-1.1 PASS capacity receipt for the exact TakePlan is required")
    capacity_plan = _resolve_workspace_path(root, str(capacity.get("plan_path") or ""))
    if capacity_plan != plan_path.resolve():
        raise PermissionError("capacity receipt belongs to another TakePlan path")
    if (capacity.get("espeak") or {}).get("status") != "PASS":
        raise PermissionError("capacity receipt lacks a verified local eSpeak binding")
    espeak_checks = [
        item
        for item in capacity.get("checks", [])
        if item.get("check_id") == "CAP-ESPEAK" and item.get("status") == "PASS"
    ]
    if len(espeak_checks) != 1:
        raise PermissionError("capacity receipt lacks one PASS CAP-ESPEAK gate")
    capacity_path = root / CAPACITY_RECEIPTS / f"{capacity['receipt_id']}.json"
    if not capacity_path.is_file():
        raise FileNotFoundError("the new immutable capacity receipt was not materialized")
    capacity_hash = _sha256_file(capacity_path)
    verified = capacity_verifier(
        root,
        receipt_path=capacity_path,
        expected_receipt_id=capacity["receipt_id"],
        expected_sha256=capacity_hash,
        require_pass=True,
    )
    if verified != capacity:
        raise PermissionError("capacity verifier returned bytes other than the new receipt")
    return capacity, capacity_path, capacity_hash


def _probe_wav(
    *,
    ffprobe_path: Path,
    ffprobe_version: str,
    sample_path: Path,
    sample_report: dict[str, Any],
    command_runner: Callable[..., Any],
) -> dict[str, Any]:
    result = command_runner(
        [
            str(ffprobe_path),
            "-v",
            "error",
            "-show_entries",
            "format=duration,size,format_name:stream=index,codec_type,codec_name,sample_rate,channels",
            "-of",
            "json",
            str(sample_path),
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=30,
    )
    if int(getattr(result, "returncode", 1)) != 0:
        raise RuntimeError(
            f"ffprobe rejected the local WAV: {str(getattr(result, 'stderr', '') or '').strip()}"
        )
    stdout = str(getattr(result, "stdout", "") or "")
    parsed = json.loads(stdout)
    streams = parsed.get("streams") or []
    audio = [item for item in streams if item.get("codec_type") == "audio"]
    if len(streams) != 1 or len(audio) != 1:
        raise RuntimeError("ffprobe did not find exactly one audio-only stream")
    stream = audio[0]
    sample_rate = int(stream.get("sample_rate") or 0)
    channels = int(stream.get("channels") or 0)
    format_record = parsed.get("format") or {}
    duration_seconds = float(format_record.get("duration") or 0)
    observed_size = int(format_record.get("size") or 0)
    if (
        stream.get("codec_name") != "pcm_s16le"
        or sample_rate != int(sample_report.get("sample_rate") or 0)
        or channels != 1
        or duration_seconds <= 0
        or observed_size != sample_path.stat().st_size
    ):
        raise RuntimeError("ffprobe WAV measurements do not match the synthesized PCM sample")
    reported_ms = int(sample_report.get("duration_ms") or 0)
    measured_ms = round(duration_seconds * 1000)
    if reported_ms <= 0 or abs(measured_ms - reported_ms) > 25:
        raise RuntimeError("ffprobe duration diverges from the synthesizer measurement")
    return {
        "executable_path": str(ffprobe_path),
        "version": ffprobe_version,
        "stdout_sha256": _sha256_text(stdout),
        "codec_name": "pcm_s16le",
        "sample_rate": sample_rate,
        "channels": channels,
        "duration_ms": measured_ms,
        "size_bytes": observed_size,
        "format_name": str(format_record.get("format_name") or "wav"),
    }


def _create_repair_evidence(
    root: Path,
    *,
    job: dict[str, Any],
    recovery_key: str,
    plan_path: Path,
    plan: dict[str, Any],
    plan_hash: str,
    capacity: dict[str, Any],
    capacity_path: Path,
    capacity_hash: str,
    moment: datetime,
    voice_builder: Callable[..., Any],
    sample_synthesizer: Callable[..., dict[str, Any]],
    binding_revalidator: Callable[..., dict[str, Any]],
    command_runner: Callable[..., Any],
) -> tuple[Path, str, dict[str, Any]]:
    run_token = hashlib.sha256(
        f"{recovery_key}|{plan_hash}|{capacity_hash}".encode("utf-8")
    ).hexdigest()[:24]
    allowed_evidence_dir = _resolve_workspace_path(root, MEDIA_REPAIR_EVIDENCE)
    artifacts_dir = (allowed_evidence_dir / "artifacts" / run_token).resolve()
    try:
        artifacts_dir.relative_to(allowed_evidence_dir)
    except ValueError as exc:
        raise PermissionError("media repair artifact directory escaped its immutable root") from exc
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    sample_path = artifacts_dir / "kokoro-espeak-smoke.wav"
    staging = artifacts_dir / f".kokoro-espeak-smoke.{uuid.uuid4().hex}.tmp.wav"
    engine: Any | None = None
    binding: Any | None = None
    try:
        expected_identity = espeak_binding_identity(capacity["espeak"])
        engine = voice_builder(root, expected_binding=capacity["espeak"])
        binding = getattr(engine, "_heroverse_espeak_binding", None)
        if binding is None:
            raise PermissionError("Kokoro omitted the capacity-bound eSpeak runtime")
        before_identity = binding_revalidator(
            binding, expected_binding=capacity["espeak"]
        )
        if before_identity != expected_identity:
            raise PermissionError("eSpeak binding diverged before the smoke synthesis")
        sample_report = sample_synthesizer(
            engine,
            text=SAMPLE_TEXT,
            output_path=staging,
            voice_id="am_onyx",
            speed=1.0,
        )
        if (
            not staging.is_file()
            or staging.stat().st_size <= 44
            or sample_report.get("content_hash") != _sha256_file(staging)
            or int(sample_report.get("duration_ms") or 0) <= 0
            or sample_report.get("clipping") is not False
        ):
            raise RuntimeError("Kokoro smoke synthesis did not produce a valid non-clipping sample")
        after_identity = binding_revalidator(
            binding, expected_binding=capacity["espeak"]
        )
        if after_identity != before_identity:
            raise PermissionError("eSpeak binding changed during the smoke synthesis")
        ffprobe_record = next(
            (
                item
                for item in capacity.get("tools", [])
                if item.get("tool_id") == "ffprobe-local" and item.get("status") == "PASS"
            ),
            None,
        )
        if ffprobe_record is None:
            raise PermissionError("capacity receipt lacks the PASS ffprobe executable")
        ffprobe_path = Path(str(ffprobe_record["path"])).resolve()
        if not ffprobe_path.is_file():
            raise FileNotFoundError("capacity-bound ffprobe executable is unavailable")
        probe = _probe_wav(
            ffprobe_path=ffprobe_path,
            ffprobe_version=str(ffprobe_record.get("version") or ""),
            sample_path=staging,
            sample_report=sample_report,
            command_runner=command_runner,
        )
        sample_hash = _sha256_file(staging)
        _commit_staged_file(staging, sample_path, label="Kokoro/eSpeak sample")
    finally:
        staging.unlink(missing_ok=True)
        if binding is not None and callable(getattr(binding, "close", None)):
            binding.close()

    probe_receipt = {
        "schema_version": "1.0.0",
        "receipt_id": "phase6-media-voice-probe-pending",
        "phase": 6,
        "status": "PASS",
        "job_id": job["job_id"],
        "take_plan": {
            "take_plan_id": plan["take_plan_id"],
            "path": _relative(root, plan_path),
            "sha256": plan_hash,
        },
        "capacity_receipt": {
            "receipt_id": capacity["receipt_id"],
            "path": _relative(root, capacity_path),
            "sha256": capacity_hash,
            "schema_version": "1.1.0",
            "status": "PASS",
        },
        "sample": {
            "path": _relative(root, sample_path),
            "sha256": sample_hash,
            "size_bytes": sample_path.stat().st_size,
            "text_sha256": _sha256_text(SAMPLE_TEXT),
            "voice_id": "am_onyx",
            "speed": 1.0,
            "synthesizer_duration_ms": int(sample_report["duration_ms"]),
        },
        "espeak_binding_before": before_identity,
        "espeak_binding_after": after_identity,
        "ffprobe": probe,
        "external_api_calls": 0,
        "publication_effects": 0,
        "technical_cost_brl": 0,
        "created_at": _stamp(moment),
    }
    probe_identity = dict(probe_receipt)
    probe_identity.pop("receipt_id")
    probe_receipt["receipt_id"] = "phase6-media-voice-probe-" + hashlib.sha256(
        _canonical_bytes(probe_identity)
    ).hexdigest()[:24]
    probe_path = artifacts_dir / f"{probe_receipt['receipt_id']}.json"
    _write_immutable_bytes(
        probe_path, _canonical_bytes(probe_receipt), label="media voice probe receipt"
    )
    probe_hash = _sha256_file(probe_path)

    evidence_id = "phase6-media-repair-" + hashlib.sha256(
        (
            f"{job['job_id']}|{_sha256_text(str(job['last_error']))}|{plan_hash}|"
            f"{capacity_hash}|{sample_hash}|{probe_hash}"
        ).encode("utf-8")
    ).hexdigest()[:24]
    evidence = {
        "schema_version": "1.0.0",
        "evidence_id": evidence_id,
        "phase": 6,
        "status": "PASS",
        "job_binding": {
            "job_id": job["job_id"],
            "task_type": MEDIA_TASK,
            "original_error": str(job["last_error"]),
            "original_error_sha256": _sha256_text(str(job["last_error"])),
        },
        "correction": {
            "component": "local-kokoro-espeak-media-runtime",
            "action": (
                "Rebuild the exact TakePlan capacity receipt and verify the corrected "
                "Kokoro/eSpeak binding with one local ffprobe-checked smoke sample."
            ),
            "changed_paths": [
                _relative(root, capacity_path),
                _relative(root, sample_path),
                _relative(root, probe_path),
            ],
        },
        "verification": {
            "status": "PASS",
            "checks": [
                {
                    "check_id": "MEDIA-REPAIR-DEAD-LETTER",
                    "status": "PASS",
                    "evidence": [
                        f"job_id={job['job_id']}",
                        f"attempt_count={job['attempt_count']}",
                        f"original_error_sha256={_sha256_text(str(job['last_error']))}",
                    ],
                },
                {
                    "check_id": "MEDIA-REPAIR-TAKEPLAN",
                    "status": "PASS",
                    "evidence": [
                        f"take_plan_id={plan['take_plan_id']}",
                        f"take_plan_sha256={plan_hash}",
                    ],
                },
                {
                    "check_id": "MEDIA-REPAIR-CAPACITY-11",
                    "status": "PASS",
                    "evidence": [
                        f"capacity_receipt_id={capacity['receipt_id']}",
                        f"capacity_receipt_sha256={capacity_hash}",
                    ],
                },
                {
                    "check_id": "MEDIA-REPAIR-ESPEAK-BINDING",
                    "status": "PASS",
                    "evidence": [
                        f"candidate_id={before_identity['candidate_id']}",
                        f"library_hash={before_identity['library_hash']}",
                        f"data_hash={before_identity['data_hash']}",
                        "binding_before_equals_after=true",
                    ],
                },
                {
                    "check_id": "MEDIA-REPAIR-VOICE-SMOKE",
                    "status": "PASS",
                    "evidence": [
                        f"sample_sha256={sample_hash}",
                        f"duration_ms={sample_report['duration_ms']}",
                        "clipping=false",
                    ],
                },
                {
                    "check_id": "MEDIA-REPAIR-FFPROBE",
                    "status": "PASS",
                    "evidence": [
                        f"probe_receipt_sha256={probe_hash}",
                        f"codec={probe['codec_name']}",
                        f"sample_rate={probe['sample_rate']}",
                    ],
                },
            ],
            "artifacts": [
                {
                    "path": _relative(root, capacity_path),
                    "sha256": capacity_hash,
                    "purpose": "New schema-1.1 PASS capacity receipt for the exact TakePlan",
                },
                {
                    "path": _relative(root, sample_path),
                    "sha256": sample_hash,
                    "purpose": "Short local Kokoro/eSpeak PCM WAV smoke sample",
                },
                {
                    "path": _relative(root, probe_path),
                    "sha256": probe_hash,
                    "purpose": "Hash-bound ffprobe and eSpeak before/after verification receipt",
                },
            ],
        },
        "external_api_calls": 0,
        "publication_effects": 0,
        "technical_cost_brl": 0,
        "created_at": _stamp(moment),
        "claim_boundary": [
            "This evidence authorizes only one additional local retry of the exact media job.",
            "It does not authorize render acceptance, quality approval, upload, publication, phase promotion, Ads or spend.",
        ],
    }
    _validate(root, "phase6_media_repair_evidence.schema.json", evidence)
    evidence_path = allowed_evidence_dir / f"{evidence_id}.json"
    _write_immutable_bytes(
        evidence_path, _canonical_bytes(evidence), label="media repair evidence"
    )
    evidence_hash = _sha256_file(evidence_path)
    if (
        _sha256_file(capacity_path) != capacity_hash
        or _sha256_file(sample_path) != sample_hash
        or _sha256_file(probe_path) != probe_hash
    ):
        raise PermissionError("repair artifact changed before queue recovery")
    return evidence_path, evidence_hash, evidence


def _result(value: dict[str, Any]) -> dict[str, Any]:
    job = value["job"]
    receipt = value["receipt"]
    return {
        "status": "RECOVERED",
        "job_id": job["job_id"],
        "job_state": job["state"],
        "attempt_count": job["attempt_count"],
        "max_attempts": job["max_attempts"],
        "budget_increment": receipt["recovery"]["budget_increment"],
        "available_at": receipt["recovery"]["available_at"],
        "original_error_sha256": receipt["prior_dead_letter"]["last_error_sha256"],
        "repair_evidence": receipt["repair_evidence"],
        "recovery_receipt": {
            "receipt_id": receipt["receipt_id"],
            "path": value["receipt_path"],
            "sha256": value["receipt_sha256"],
        },
        "replayed": value["replayed"],
        "external_api_calls": 0,
        "publication_effects": 0,
        "technical_cost_brl": 0,
    }


def recover_phase6_media_dead_letter(
    job_id: str,
    *,
    root: Path = ROOT,
    available_at: datetime | None = None,
    now: datetime | None = None,
    queue: TransactionalQueue | None = None,
    production_inputs_verifier: Callable[..., dict[str, Any]] = verify_production_inputs_receipt,
    capacity_runner: Callable[..., dict[str, Any]] = run_phase6_capacity_preflight,
    capacity_verifier: Callable[..., dict[str, Any]] = verify_phase6_capacity_receipt,
    voice_builder: Callable[..., Any] = build_local_voice,
    sample_synthesizer: Callable[..., dict[str, Any]] = synthesize_voice_sample,
    binding_revalidator: Callable[..., dict[str, Any]] = revalidate_local_espeak_binding,
    command_runner: Callable[..., Any] = subprocess.run,
) -> dict[str, Any]:
    """Prove and recover one exact Phase 6 media dead letter, fail-closed.

    No render, provider API, OAuth, upload, publication or paid operation is
    invoked here.  The only media effect is a short local PCM smoke sample.
    """

    project_root = root.resolve()
    moment = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if available_at is not None:
        if available_at.tzinfo is None:
            raise ValueError("available_at must be timezone-aware")
        available_at = available_at.astimezone(timezone.utc)
        if available_at < moment:
            raise ValueError("available_at cannot precede the recovery proof")
    queue = queue or TransactionalQueue(project_root)
    job = _job_by_id(queue, job_id, moment)
    key = _recovery_key(job)

    existing = _replay_existing_recovery(
        queue,
        root=project_root,
        job=job,
        recovery_key=key,
        available_at=available_at,
        moment=moment,
        capacity_verifier=capacity_verifier,
    )
    if existing is not None:
        queue.materialize_snapshot(captured_at=moment)
        return _result(existing)

    if (
        job.get("state") != "DEAD_LETTER"
        or job.get("lease_owner") is not None
        or job.get("lease_until") is not None
        or int(job.get("attempt_count") or 0) != int(job.get("max_attempts") or -1)
    ):
        raise PermissionError("an exact, unleased and internally consistent DEAD_LETTER is required")
    incidents = [
        item
        for item in queue.snapshot(captured_at=moment).get("incidents", [])
        if item.get("job_id") == job_id
        and item.get("incident_type") == "MAX_ATTEMPTS_EXCEEDED"
        and item.get("severity") == "CRITICAL"
    ]
    if not incidents:
        raise PermissionError("the terminal media failure has no preserved critical incident")

    _, plan_path, plan, plan_hash = _load_exact_take_plan(
        project_root,
        job=job,
        production_inputs_verifier=production_inputs_verifier,
    )
    capacity, capacity_path, capacity_hash = _materialize_current_capacity(
        project_root,
        plan_path=plan_path,
        plan=plan,
        moment=moment,
        capacity_runner=capacity_runner,
        capacity_verifier=capacity_verifier,
    )
    evidence_path, evidence_hash, _ = _create_repair_evidence(
        project_root,
        job=job,
        recovery_key=key,
        plan_path=plan_path,
        plan=plan,
        plan_hash=plan_hash,
        capacity=capacity,
        capacity_path=capacity_path,
        capacity_hash=capacity_hash,
        moment=moment,
        voice_builder=voice_builder,
        sample_synthesizer=sample_synthesizer,
        binding_revalidator=binding_revalidator,
        command_runner=command_runner,
    )
    # Final barriers immediately before the only queue mutation.
    capacity_verifier(
        project_root,
        receipt_path=capacity_path,
        expected_receipt_id=capacity["receipt_id"],
        expected_sha256=capacity_hash,
        require_pass=True,
    )
    if _sha256_file(evidence_path) != evidence_hash:
        raise PermissionError("media repair evidence changed before queue recovery")
    recovered = queue.recover_media_dead_letter(
        job_id,
        recovery_key=key,
        repair_evidence_path=_relative(project_root, evidence_path),
        repair_evidence_sha256=evidence_hash,
        new_max_attempts=int(job["max_attempts"]) + 1,
        available_at=available_at,
        now=moment,
    )
    queue.materialize_snapshot(captured_at=moment)
    return _result(recovered)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Recover one evidenced Phase 6 media dead letter with one local retry."
    )
    parser.add_argument("--job-id", required=True, help="Exact job-<24 lowercase hex> identity")
    parser.add_argument(
        "--available-at",
        help="Optional explicit timezone-aware ISO-8601 instant for the one retry",
    )
    args = parser.parse_args(argv)
    try:
        available = _parse_timestamp(args.available_at) if args.available_at else None
        value = recover_phase6_media_dead_letter(
            args.job_id,
            root=ROOT,
            available_at=available,
        )
    except Exception as exc:
        print(
            json.dumps(
                {
                    "status": "BLOCKED",
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "external_api_calls": 0,
                    "publication_effects": 0,
                    "technical_cost_brl": 0,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 2
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
