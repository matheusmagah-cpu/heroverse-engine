from __future__ import annotations

import hashlib
import json
import os
import re
import time
import uuid
from contextlib import ExitStack, closing, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .maintenance_unittest_result import UnittestResultError, _inventory_ids, verify_unittest_result
from .phase6_control_cycle import STAGES, stage_identity_hash


ROOT = Path(__file__).resolve().parents[1]
BASE = Path("output/operations/phase6/post-maintenance-verification")
MAINTENANCE_PATH = Path("output/runtime/gestor-central/daily-maintenance-regression-receipt.json")
AUTOSTART_PATH = Path("output/runtime/gestor-central/autostart-verification.json")
CYCLE_PATH = Path("output/operations/phase6/control-cycle/latest.json")
ACCEPTANCE_PATH = Path("output/operations/phase6/acceptance-report.json")
EXECUTIVE_PATH = Path("output/operations/phase6/executive-status.json")
EXPECTED_PENDING_CHECKS = {"GC-01", "GC-11", "GC-19"}
INTEGRAL_CYCLE_CHECKS = ("GC-07", "GC-20", "GC-22")


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _content_hash(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write(path: Path, value: dict[str, Any]) -> None:
    _write_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def _read_validated(root: Path, relative: Path, schema_name: str) -> tuple[dict[str, Any], bytes, str]:
    path = root / relative
    payload = path.read_bytes()
    value = json.loads(payload.decode("utf-8-sig"))
    Draft202012Validator(
        _read(root / "schemas" / schema_name),
        format_checker=FormatChecker(),
    ).validate(value)
    return value, payload, "sha256:" + hashlib.sha256(payload).hexdigest()


def _snapshot_path(verification_id: str, label: str) -> Path:
    return BASE / "source-snapshots" / verification_id / f"{label}.json"


def _confined(root: Path, relative: str, parent: Path) -> Path:
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to((root / parent).resolve())
    except ValueError as exc:
        raise PermissionError(f"source snapshot escapes its authoritative directory: {relative}") from exc
    return candidate


def _stage_status(value: dict[str, Any], *, stage: str) -> str:
    """Independently reconstruct the status representation for its source version.

    D-143 changed GOAL_TRAJECTORY 1.3 only. Historical 1.0/1.1/1.2 receipts
    retain their exact dict-string representation; accepting both for 1.3
    would conceal a mismatched producer or forged current cycle status.
    The caller validates the complete source schema before this projection.
    """
    if stage == "GOAL_TRAJECTORY" and value.get("schema_version") == "1.3.0":
        decision = value["decision"]
        production_block = decision["production_block"]
        if production_block is not None and production_block["status"] == "EVIDENCE_INVALID":
            return "BLOCKED"
        return decision["selected_action"]
    return str(value.get("status") or value.get("decision") or "UNAVAILABLE")


def verify_control_cycle_sources(root: Path, cycle: dict[str, Any]) -> None:
    """Recompute all twelve stage proofs from their immutable bytes."""
    if cycle.get('schema_version') in {'1.2.0','1.3.0'}:
        from .phase6_control_cycle import verify_audio_cycle_sources
        verify_audio_cycle_sources(root, cycle)
        return
    expected_order = [contract["stage"] for contract in STAGES]
    records = cycle.get("stages")
    if cycle.get("schema_version") != "1.1.0":
        raise PermissionError("post-maintenance control cycle must use the current 1.1 contract")
    if cycle.get("stage_order") != expected_order or not isinstance(records, list) or len(records) != len(STAGES):
        raise PermissionError("control-cycle stage order is incomplete or divergent")

    started = _parse(str(cycle["cycle_started_at"]))
    completed = _parse(str(cycle["cycle_completed_at"]))
    maintenance_revalidation = cycle.get("cycle_mode") == "MAINTENANCE_REVALIDATION"
    semantic: dict[str, Any] = {}
    cycle_id = str(cycle["cycle_id"])
    snapshot_parent = Path("output/operations/phase6/control-cycle/source-snapshots") / cycle_id
    for ordinal, (contract, record) in enumerate(zip(STAGES, records, strict=True), start=1):
        slug = str(contract["stage"]).lower().replace("_", "-")
        expected_snapshot = snapshot_parent / f"{ordinal:02d}-{slug}.json"
        goal_successor = (
            contract["stage"] == "GOAL_TRAJECTORY"
            and record.get("path") == "output/operations/phase6/goal-trajectory/current.json"
        )
        if not (
            record.get("ordinal") == ordinal
            and record.get("stage") == contract["stage"]
            and (record.get("path") == contract["path"] or goal_successor)
            and record.get("schema") == contract["schema"]
            and record.get("schema_status") == "PASS"
            and record.get("snapshot_path") == expected_snapshot.as_posix()
        ):
            raise PermissionError(f"control-cycle stage contract mismatch at ordinal {ordinal}")
        snapshot = _confined(root, str(record["snapshot_path"]), snapshot_parent)
        if not snapshot.is_file():
            raise PermissionError(f"control-cycle stage snapshot is missing: {contract['stage']}")
        raw = snapshot.read_bytes()
        if "sha256:" + hashlib.sha256(raw).hexdigest() != record.get("content_hash"):
            raise PermissionError(f"control-cycle stage snapshot hash mismatch: {contract['stage']}")
        try:
            value = json.loads(raw.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise PermissionError(f"control-cycle stage snapshot is unreadable: {contract['stage']}") from exc
        # The producer's explicit forward alias is not an arbitrary alternate
        # source. Bind its version to immutable snapshot bytes, never to the
        # later state/existence of either mutable alias. Legacy cycles survive.
        if goal_successor and value.get("schema_version") != "1.3.0":
            raise PermissionError("goal successor source version differs")
        Draft202012Validator(
            _read(root / "schemas" / contract["schema"]),
            format_checker=FormatChecker(),
        ).validate(value)
        source_observed_at = _parse(str(value[contract["time_field"]]))
        claimed_observed_at = _parse(str(record.get("observed_at")))
        if not (started <= claimed_observed_at <= completed):
            raise PermissionError(f"control-cycle stage is outside the cycle window: {contract['stage']}")
        if maintenance_revalidation:
            freshness_matches = (
                record.get("execution_kind") == "LOCAL_NO_EXTERNAL_EFFECT_REVALIDATION"
                and record.get("source_observed_at") == _stamp(source_observed_at)
            )
        else:
            freshness_matches = (
                claimed_observed_at == source_observed_at
                and record.get("execution_kind") in {None, "OPERATIONAL_STAGE"}
                and record.get("source_observed_at") in {None, _stamp(source_observed_at)}
            )
        if not freshness_matches or record.get("executed_in_cycle") is not True:
            raise PermissionError(f"control-cycle stage freshness claim diverged: {contract['stage']}")
        if record.get("status") != _stage_status(value, stage=contract["stage"]):
            raise PermissionError(f"control-cycle stage status diverged: {contract['stage']}")
        expected_identity = stage_identity_hash(contract["stage"], value)
        if record.get("identity_hash") != expected_identity:
            raise PermissionError(f"control-cycle stage identity mismatch: {contract['stage']}")
        semantic[contract["stage"]] = {
            field: value.get(field) for field in contract["identity_fields"]
        }
    if cycle.get("substantive_signature") != _canonical_hash(semantic):
        raise PermissionError("control-cycle substantive signature does not match its twelve stage snapshots")


def current_phase6_errors(root: Path) -> list[str]:
    """Enumerate current error views generically, never historical evidence."""
    base = root / "output/operations/phase6"
    if not base.is_dir():
        return []
    excluded_parts = {
        "archive", "archives", "history", "source-snapshots", "incidents",
        "predictions", "prediction-evaluations", "metrics", "jobs", "orders",
        "work-orders", "receipts", "evaluations",
    }
    result: list[str] = []
    for path in sorted(base.rglob("*.json")):
        relative = path.relative_to(base)
        if any(part.lower() in excluded_parts for part in relative.parts[:-1]):
            continue
        name = path.name.lower()
        is_current_view = (
            "error" in name
            or name == "latest.json"
            or name.endswith("-status.json")
            or name.endswith("-runtime.json")
            or name in {"acceptance-report.json", "executive-status.json"}
        )
        if not is_current_view:
            continue
        try:
            value = _read(path)
        except Exception:
            result.append(path.relative_to(root).as_posix())
            continue
        explicit_error_file = "error" in name
        runtime_error = value.get("status") == "ERROR" or value.get("decision") == "ERROR"
        if explicit_error_file or runtime_error:
            result.append(path.relative_to(root).as_posix())
    return result


def verify_local_migration_evidence(
    root: Path, *, request_id: str, migration: dict[str, Any], schema_version: str = "1.2.0",
    scope: str = "CURRENT_MAINTENANCE",
) -> None:
    """Shared migration-only verifier; NOT a regression or restart approval."""
    if schema_version not in {"1.1.0", "1.2.0"}:
        raise PermissionError("unsupported local migration evidence version")
    if scope not in {"CURRENT_MAINTENANCE", "PAUSED_APPLICATION_ARCHIVE"}:
        raise PermissionError("unsupported migration evidence scope")
    run_parent = Path("output/runtime/gestor-central/maintenance-runs") / request_id
    if schema_version in {"1.1.0", "1.2.0"}:
        if not isinstance(migration, dict):
            raise PermissionError("current maintenance regression omits its local runtime migration proof")
        exact_migration_values = {
            "status": "PASS",
            "mode": "LOCAL_DERIVED_VIEWS_ONLY",
            "stage_count": 12,
            "all_stage_schemas_valid": True,
            "stage_blockers": [],
            "external_api_calls": 0,
            "publication_effects": 0,
            "operational_queue_mutations": 0,
            "technical_cost_brl": 0,
        }
        if any(migration.get(key) != expected for key, expected in exact_migration_values.items()):
            raise PermissionError("local runtime migration proof is not a clean 12-stage zero-effect PASS")
        if migration.get("action") not in {"NO_CHANGE", "MIGRATED_LEGACY_PREDICTION_RUNTIME"}:
            raise PermissionError("local runtime migration action is not recognized")
        for before_key, after_key, label in (
            ("queue_jobs_hash_before", "queue_jobs_hash_after", "queue"),
            ("quota_ledger_hash_before", "quota_ledger_hash_after", "quota ledger"),
            ("operational_effects_hash_before", "operational_effects_hash_after", "operational effects"),
        ):
            before_hash = migration.get(before_key)
            after_hash = migration.get(after_key)
            if (
                not isinstance(before_hash, str)
                or not re.fullmatch(r"sha256:[0-9a-f]{64}", before_hash)
                or before_hash != after_hash
            ):
                raise PermissionError(f"local runtime migration changed the {label}")
        allowed_write_paths = migration.get("allowed_write_paths")
        if not isinstance(allowed_write_paths, list) or len(allowed_write_paths) != len(set(allowed_write_paths)):
            raise PermissionError("local runtime migration write manifest is missing or ambiguous")
        media_migration = migration.get("media_runtime_migration")
        quality_migration = migration.get("quality_runtime_migration")
        quality_path = "output/operations/phase6/quality-executor-status.json"
        permitted_live_paths = {
            "output/operations/phase6/intelligence/prediction-runtime.json",
            "output/operations/phase6/executive-status.json",
            "output/operations/phase6/EXECUTIVE_STATUS.md",
            "output/operations/phase6/control-cycle-error.json",
        }
        # The same atomic migration may re-evaluate the already-complete Phase5
        # canary. Its staged preimage/candidate and local decision are checked below.
        if schema_version == "1.2.0":
            permitted_live_paths.add("output/runtime/gestor-central/fingerprint.json")
        # A schema-1.2 transaction can derive exactly one forward-only goal
        # successor.  Its later journal/outcome checks below bind the fixed
        # path, authenticated preimage, schema-valid staged bytes, and exact manifest;
        # older evidence does not receive this exception.
        if schema_version == "1.2.0":
            permitted_live_paths.add(
                "output/operations/phase6/goal-trajectory/current.json"
            )
        if isinstance(media_migration, dict):
            permitted_live_paths.add(
                "output/operations/phase6/media-executor-status.json"
            )
        if isinstance(quality_migration, dict) and schema_version == "1.2.0":
            permitted_live_paths.add(quality_path)
        permitted_archive_prefix = "output/operations/phase6/control-cycle/errors/archive/"
        permitted_run_prefix = run_parent.as_posix().rstrip("/") + "/"
        for relative in allowed_write_paths:
            if not isinstance(relative, str):
                raise PermissionError("local runtime migration write manifest contains a non-path")
            candidate = (root / relative).resolve()
            try:
                candidate.relative_to(root.resolve())
            except ValueError as exc:
                raise PermissionError("local runtime migration write escaped the workspace") from exc
            normalized = Path(relative).as_posix()
            if not (
                normalized in permitted_live_paths
                or normalized.startswith(permitted_run_prefix)
                or normalized.startswith(permitted_archive_prefix)
            ):
                raise PermissionError(f"local runtime migration wrote an unauthorized path: {normalized}")

    def evidence(relative: str, expected_hash: str) -> bytes:
        path = _confined(root, relative, run_parent)
        payload = path.read_bytes()
        if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
            raise PermissionError(f"maintenance evidence hash mismatch: {relative}")
        return payload

    if schema_version == "1.2.0":
        journal = json.loads(
            evidence(
                str(migration["transaction_journal_path"]),
                str(migration["transaction_journal_hash"]),
            ).decode("utf-8-sig")
        )
        outcome = json.loads(
            evidence(
                str(migration["transaction_outcome_path"]),
                str(migration["transaction_outcome_hash"]),
            ).decode("utf-8-sig")
        )
        zero_effect = {
            "external_api_calls": 0,
            "publication_effects": 0,
            "operational_queue_mutations": 0,
            "technical_cost_brl": 0,
        }
        if not (
            journal.get("schema_version") == "1.0.0"
            and outcome.get("schema_version") == "1.0.0"
            and journal.get("record_type") == "PREPARED"
            and outcome.get("record_type") == "COMMITTED"
            and journal.get("request_id") == request_id
            and outcome.get("request_id") == request_id
            and outcome.get("journal_path") == migration["transaction_journal_path"]
            and outcome.get("journal_hash") == migration["transaction_journal_hash"]
            and all(journal.get(key) == value for key, value in zero_effect.items())
            and all(outcome.get(key) == value for key, value in zero_effect.items())
        ):
            raise PermissionError("local runtime migration transaction journal/outcome is not bound or zero-effect")
        targets = journal.get("targets")
        outcome_targets = outcome.get("target_hashes")
        if not isinstance(targets, list) or not isinstance(outcome_targets, list):
            raise PermissionError("local runtime migration transaction target manifest is absent")
        if (
            journal.get("target_count") != len(targets)
            or outcome.get("target_count") != len(targets)
            or len({item.get("path") for item in targets if isinstance(item, dict)}) != len(targets)
        ):
            raise PermissionError("local runtime migration transaction target count/identity diverged")
        if not (
            journal.get("queue_jobs_hash") == migration["queue_jobs_hash_before"]
            and journal.get("quota_ledger_hash") == migration["quota_ledger_hash_before"]
            and journal.get("operational_effects_hash") == migration["operational_effects_hash_before"]
            and journal.get("control_cycle_error_action")
            == migration["control_cycle_error"]["action"]
            == outcome.get("control_cycle_error_action")
        ):
            raise PermissionError("local runtime migration transaction is not bound to its state/error proof")

        target_by_path: dict[str, dict[str, Any]] = {}
        expected_allowed = {
            str(migration["transaction_journal_path"]),
            str(migration["transaction_outcome_path"]),
        }
        owner_pause_recovery = bool(
            isinstance(media_migration, dict)
            and media_migration.get("kind") == "EXACT_OWNER_PAUSE_NO_EFFECT_RECOVERY"
        )
        prestart_identity_recovery = bool(
            isinstance(media_migration, dict)
            and media_migration.get("kind")
            == "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT_RECOVERY"
        )
        forward_current_heartbeat = bool(
            isinstance(media_migration, dict)
            and media_migration.get("kind") == "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT"
        )
        forward_current_wait = bool(
            isinstance(media_migration, dict)
            and media_migration.get("kind") == "FORWARD_CURRENT_INPUT_WAIT_SUCCESSOR"
        )
        reserve_retry_hold = bool(isinstance(media_migration, dict)
                               and media_migration.get("kind") == "EXACT_RESOURCE_RESERVE_RESTART_HOLD")
        cache_retry_hold = bool(isinstance(media_migration, dict)
                               and media_migration.get("kind") in {
                                   "EXACT_CACHE_REJECTION_RESTART_HOLD", "EXACT_RESOURCE_RESERVE_RESTART_HOLD"})
        completed_cycle_recovery = bool(isinstance(media_migration, dict)
                               and media_migration.get("kind") == "EXACT_COMPLETED_MEDIA_CYCLE_RECOVERY")
        if completed_cycle_recovery:
            from . import maintenance_protocol as protocol
            keys = {"kind", "reason", "status", "media_runtime_path", "media_runtime_hash",
                "source_path", "source_sha256", "job", "queue_jobs", "queue_jobs_hash", "capacity",
                "production_authorized", "publication_authorized", "external_api_calls",
                "publication_effects", "operational_queue_mutations", "technical_cost_brl"}
            if not (set(media_migration) == keys
                    and media_migration["reason"] == media_migration["kind"]
                    and media_migration["status"] == "COMPLETED"
                    and media_migration["source_path"] == media_migration["media_runtime_path"]
                    == "output/operations/phase6/media-executor-status.json"
                    and media_migration["production_authorized"] is False
                    and media_migration["publication_authorized"] is False
                    and all(media_migration[k] == 0 for k in zero_effect)
                    and protocol.canonical_hash(media_migration["queue_jobs"])
                    == media_migration["queue_jobs_hash"] == migration["queue_jobs_hash_before"]
                    and len([j for j in media_migration["queue_jobs"] if j == media_migration["job"]]) == 1):
                raise PermissionError("completed media recovery queue/transaction binding differs")
        elif cache_retry_hold:
            expected_keys = {"kind", "status", "reason", "media_runtime_path", "media_runtime_hash",
                "source_path", "source_sha256", "source_status", "candidate_status", "input_receipt_id",
                "current_contract_sha256", "job_sha256", "original_error",
                "production_authorized", "publication_authorized", "external_api_calls",
                "publication_effects", "operational_queue_mutations", "technical_cost_brl"}
            reference_key = "resident_mux_witness" if reserve_retry_hold else "cache_event"
            expected_keys.add(reference_key)
            if (set(media_migration) != expected_keys
                    or media_migration["status"] != "WAITING"
                    or media_migration["candidate_status"] != "WAITING"
                    or media_migration["source_status"] not in {"WAITING", "RETRY_WAIT"}
                    or media_migration["source_path"] != "output/operations/phase6/media-executor-status.json"
                    or media_migration["media_runtime_path"] != media_migration["source_path"]
                    or media_migration["reason"] != "OWNER_PAUSE_RELEASE_REQUIRED: " + media_migration["original_error"]
                    or any(media_migration[key] != 0 for key in ("external_api_calls", "publication_effects",
                                                                "operational_queue_mutations", "technical_cost_brl"))
                    or media_migration["production_authorized"] is not False
                    or media_migration["publication_authorized"] is not False
                    or any(not isinstance(media_migration[key], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", media_migration[key])
                           for key in ("media_runtime_hash", "source_sha256", "current_contract_sha256", "job_sha256"))):
                raise PermissionError("cache retry hold migration binding differs")
            # Do not compare future queue attempts to old ones. Historical proof
            # is bound to the transaction's exact queue snapshot/hash and frozen
            # preimage; current media checks its live queue before holding/retry.
            reference = media_migration[reference_key]
            prefix = "PermissionError: segment cache recovery blocked before render: take-001:"
            if (not isinstance(reference, dict) or set(reference) != {"path", "sha256"}
                    or media_migration["original_error"] != (
                        "ResourceWait: RESOURCE_WAIT: OUTPUT_DISK_RESERVE, TEMP_DISK_RESERVE"
                        if reserve_retry_hold else prefix + reference["path"])):
                raise PermissionError("cache retry hold event binding differs")
            path = (root / reference["path"]).resolve()
            expected_parent = (root / "output/production/phase6/video-002").resolve()
            confined = (path.parent == expected_parent / "resource-preparation" and path.suffix == ".json") if reserve_retry_hold else (
                path.parent == expected_parent / "render-work/segment-cache-events")
            if not confined or path.is_symlink() or _content_hash(path) != reference["sha256"]:
                raise PermissionError("cache retry hold historical event diverged")
        elif owner_pause_recovery:
            expected_media_migration = {
                "kind": "EXACT_OWNER_PAUSE_NO_EFFECT_RECOVERY",
                "status": "WAITING",
                "reason": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: no media command, voice, render, or "
                    "publication effect occurred; resume only through the verified control cycle."
                ),
                "media_runtime_path": "output/operations/phase6/media-executor-status.json",
                "media_runtime_hash": media_migration.get("media_runtime_hash"),
                "source_path": "output/operations/phase6/media-executor-status.json",
                "source_sha256": media_migration.get("source_sha256"),
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
            if (
                media_migration != expected_media_migration
                or not isinstance(media_migration["media_runtime_hash"], str)
                or not isinstance(media_migration["source_sha256"], str)
            ):
                raise PermissionError("owner-pause media recovery binding is not exact")
        elif prestart_identity_recovery:
            expected_media_migration = {
                "kind": "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT_RECOVERY",
                "status": "WAITING",
                "reason": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
                "media_runtime_path": "output/operations/phase6/media-executor-status.json",
                "media_runtime_hash": media_migration.get("media_runtime_hash"),
                "source_path": "output/operations/phase6/media-executor-status.json",
                "source_sha256": media_migration.get("source_sha256"),
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "input_receipt_id": media_migration.get("input_receipt_id"),
                "current_contract_sha256": media_migration.get("current_contract_sha256"),
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
            hashes = (
                media_migration["media_runtime_hash"],
                media_migration["source_sha256"],
                media_migration["current_contract_sha256"],
            )
            if (
                media_migration != expected_media_migration
                or any(
                    not isinstance(value, str)
                    or re.fullmatch(r"sha256:[0-9a-f]{64}", value) is None
                    for value in hashes
                )
            ):
                raise PermissionError("prestart identity recovery binding is not exact")
            from .phase6_current_production_inputs import current_production_input_contract

            current = current_production_input_contract(root)
            if (
                current.get("receipt_id") != media_migration["input_receipt_id"]
                or _canonical_hash(current) != media_migration["current_contract_sha256"]
                or current.get("authority")
                != {
                    "queue": False, "voice": False, "render": False,
                    "quality": False, "publication": False,
                }
            ):
                raise PermissionError("prestart identity recovery contract diverged")
        elif forward_current_heartbeat:
            expected_media_migration = {
                "kind": "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT",
                "status": "WAITING",
                "reason": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
                "media_runtime_path": "output/operations/phase6/media-executor-status.json",
                "media_runtime_hash": media_migration.get("media_runtime_hash"),
                "source_path": "output/operations/phase6/media-executor-status.json",
                "source_sha256": media_migration.get("source_sha256"),
                "source_status": "WAITING",
                "candidate_status": "WAITING",
                "input_receipt_id": media_migration.get("input_receipt_id"),
                "current_contract_sha256": media_migration.get("current_contract_sha256"),
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
            hashes = (
                media_migration["media_runtime_hash"],
                media_migration["source_sha256"],
                media_migration["current_contract_sha256"],
            )
            if (
                media_migration != expected_media_migration
                or any(
                    not isinstance(value, str)
                    or re.fullmatch(r"sha256:[0-9a-f]{64}", value) is None
                    for value in hashes
                )
            ):
                raise PermissionError("forward current media heartbeat binding is not exact")
            from .phase6_current_production_inputs import current_production_input_contract

            current = current_production_input_contract(root)
            if (
                current.get("receipt_id") != media_migration["input_receipt_id"]
                or _canonical_hash(current) != media_migration["current_contract_sha256"]
                or current.get("authority")
                != {
                    "queue": False, "voice": False, "render": False,
                    "quality": False, "publication": False,
                }
            ):
                raise PermissionError("forward current media heartbeat contract diverged")
        elif forward_current_wait:
            expected_media_migration = {
                "kind": "FORWARD_CURRENT_INPUT_WAIT_SUCCESSOR",
                "status": "WAITING",
                "reason": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
                "media_runtime_path": "output/operations/phase6/media-executor-status.json",
                "media_runtime_hash": media_migration.get("media_runtime_hash"),
                "source_path": "output/operations/phase6/media-executor-status.json",
                "source_sha256": media_migration.get("source_sha256"),
                "source_status": "WAITING",
                "candidate_status": "WAITING",
                "historical_proof_path": media_migration.get("historical_proof_path"),
                "historical_proof_sha256": media_migration.get("historical_proof_sha256"),
                "historical_receipt_id": media_migration.get("historical_receipt_id"),
                "current_input_receipt_id": media_migration.get("current_input_receipt_id"),
                "forward_contract_sha256": media_migration.get("forward_contract_sha256"),
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
            hashes = (
                media_migration["media_runtime_hash"],
                media_migration["source_sha256"],
                media_migration["historical_proof_sha256"],
                media_migration["forward_contract_sha256"],
            )
            historical_path = (root / str(media_migration["historical_proof_path"])).resolve()
            if (
                media_migration != expected_media_migration
                or any(
                    not isinstance(value, str)
                    or re.fullmatch(r"sha256:[0-9a-f]{64}", value) is None
                    for value in hashes
                )
                or historical_path.is_symlink()
                or not historical_path.is_file()
                or _content_hash(historical_path)
                != media_migration["historical_proof_sha256"]
                or media_migration["historical_receipt_id"]
                == media_migration["current_input_receipt_id"]
            ):
                raise PermissionError("forward current media wait binding is not exact")
            proof = json.loads(historical_path.read_text(encoding="utf-8-sig"))
            expected_path = (
                root
                / "output/runtime/gestor-central/maintenance-runs"
                / str(proof.get("request_id"))
                / f"{proof.get('proof_id')}.json"
            ).resolve()
            Draft202012Validator(
                _read(root / "schemas/phase6_post_effect_visual_wait_proof.schema.json"),
                format_checker=FormatChecker(),
            ).validate(proof)
            if (
                historical_path != expected_path
                or proof["tail"]["input_receipt"]["receipt_id"]
                != media_migration["historical_receipt_id"]
            ):
                raise PermissionError("forward current media wait historical proof diverged")
            from .phase6_current_production_inputs import current_production_input_contract

            current = current_production_input_contract(root)
            if (
                current.get("receipt_id") != media_migration["current_input_receipt_id"]
                or _canonical_hash(current) != media_migration["forward_contract_sha256"]
                or current.get("authority")
                != {
                    "queue": False, "voice": False, "render": False,
                    "quality": False, "publication": False,
                }
            ):
                raise PermissionError("forward current media input contract diverged")
        elif isinstance(media_migration, dict):
            proof_relative = str(media_migration["proof_path"])
            proof_request = str(media_migration["proof_request_id"])
            expected_proof = (
                root
                / "output/runtime/gestor-central/maintenance-runs"
                / proof_request
                / f"{media_migration['proof_id']}.json"
            ).resolve()
            proof_path = (root / proof_relative).resolve()
            if proof_path != expected_proof or proof_path.is_symlink() or not proof_path.is_file():
                raise PermissionError("media wait proof left its exact immutable maintenance run")
            proof_payload = proof_path.read_bytes()
            if _content_hash(proof_path) != media_migration["proof_sha256"]:
                raise PermissionError("media wait proof hash diverged")
            proof = json.loads(proof_payload.decode("utf-8-sig"))
            Draft202012Validator(
                _read(root / "schemas/phase6_post_effect_visual_wait_proof.schema.json"),
                format_checker=FormatChecker(),
            ).validate(proof)
            if not (
                proof["proof_id"] == media_migration["proof_id"]
                and proof["request_id"] == proof_request
                and proof["status"] == "ELIGIBLE_FOR_WAITING_STATE"
                and proof["runtime_identity_sha256"]
                == media_migration["runtime_identity_sha256"]
                and proof["authority"]["root_job_id"]
                == media_migration["authority_root_job_id"]
                and proof["authority"]["tail_job_id"]
                == media_migration["authority_tail_job_id"]
                and proof["authority"]["chain_sha256"]
                == media_migration["chain_sha256"]
                and proof["tail"]["checkpoint_sha256"]
                == media_migration["checkpoint_sha256"]
                and proof["tail"]["input_receipt"]["receipt_id"]
                == media_migration["input_receipt_id"]
                and proof["record_type"] == "PREPARED_LOCAL_DERIVED_VIEW"
                and proof["production_authorized"] is False
                and proof["publication_authorized"] is False
            ):
                raise PermissionError("media wait proof/regression binding diverged")
            # ``proof_path`` is absolute while ``run_parent`` is deliberately
            # stored as a root-relative evidence identity.  Compare like for
            # like: otherwise a legitimate post-effect proof is omitted from
            # the recomposed write manifest and a clean maintenance recovery
            # fails after its regression has already passed.
            if proof_path.parent == (root / run_parent).resolve():
                expected_allowed.add(proof_relative)
        for ordinal, item in enumerate(targets, start=1):
            if not isinstance(item, dict) or item.get("ordinal") != ordinal:
                raise PermissionError("local runtime migration transaction target order is invalid")
            relative = str(item.get("path") or "")
            normalized = Path(relative).as_posix()
            if normalized != relative:
                raise PermissionError("local runtime migration transaction path is not canonical")
            if item.get("desired_exists") is True:
                candidate_path = item.get("candidate_path")
                candidate_hash = item.get("candidate_hash")
                candidate_size = item.get("candidate_size")
                if not isinstance(candidate_path, str) or not isinstance(candidate_hash, str):
                    raise PermissionError("local runtime migration candidate evidence is incomplete")
                candidate = evidence(candidate_path, candidate_hash)
                if len(candidate) != candidate_size:
                    raise PermissionError("local runtime migration candidate size diverged")
                expected_allowed.add(candidate_path)
            elif not (
                item.get("desired_exists") is False
                and item.get("candidate_path") is None
                and item.get("candidate_hash") is None
                and item.get("candidate_size") is None
            ):
                raise PermissionError("local runtime migration removal target is ambiguous")
            if item.get("existed_before") is True:
                before_path = item.get("before_path")
                before_hash = item.get("before_hash")
                before_size = item.get("before_size")
                if not isinstance(before_path, str) or not isinstance(before_hash, str):
                    raise PermissionError("local runtime migration preimage evidence is incomplete")
                preimage = evidence(before_path, before_hash)
                if len(preimage) != before_size:
                    raise PermissionError("local runtime migration preimage size diverged")
                expected_allowed.add(before_path)
            elif not (
                item.get("existed_before") is False
                and item.get("before_path") is None
                and item.get("before_hash") is None
                and item.get("before_size") is None
            ):
                raise PermissionError("local runtime migration absent preimage is ambiguous")
            expected_changed = (
                item.get("existed_before") != item.get("desired_exists")
                or (
                    item.get("existed_before") is True
                    and item.get("desired_exists") is True
                    and item.get("before_hash") != item.get("candidate_hash")
                )
            )
            if item.get("changed") is not expected_changed:
                raise PermissionError("local runtime migration changed flag is not byte-derived")
            if expected_changed:
                expected_allowed.add(relative)
            target_by_path[relative] = item

        outcome_by_path = {
            str(item.get("path")): item for item in outcome_targets if isinstance(item, dict)
        }
        if len(outcome_by_path) != len(outcome_targets) or set(outcome_by_path) != set(target_by_path):
            raise PermissionError("local runtime migration outcome target set diverged")
        for relative, item in target_by_path.items():
            committed = outcome_by_path[relative]
            if not (
                committed.get("exists") == item.get("desired_exists")
                and committed.get("content_hash")
                == (item.get("candidate_hash") if item.get("desired_exists") else None)
            ):
                raise PermissionError("local runtime migration outcome target hash diverged")
        if set(migration["allowed_write_paths"]) != expected_allowed:
            raise PermissionError("local runtime migration write manifest is not exact")

        fingerprint_target = target_by_path.get("output/runtime/gestor-central/fingerprint.json")
        fingerprint_evidence = journal.get("phase5_fingerprint_reconciliation")
        if fingerprint_target is not None or fingerprint_evidence is not None:
            from .central_manager_phase5 import INPUTS, FINGERPRINT_VERSION, _captured_fingerprint
            if not isinstance(fingerprint_target, dict) or not isinstance(fingerprint_evidence, dict):
                raise PermissionError("fingerprint reconciliation evidence is incomplete")
            f = fingerprint_evidence
            versions = {"PAUSED_COMPLETED_PHASE5_LOCAL_RECONCILIATION_V1": "phase5-inputs-v1",
                        "PAUSED_COMPLETED_PHASE5_LOCAL_RECONCILIATION_V2": FINGERPRINT_VERSION}
            if (f.get("kind") not in versions
                    or f.get("external_api_calls") != 0 or f.get("publication_effects") != 0
                    or [row[0] for row in f.get("input_bytes", [])] != [p.as_posix() for p in INPUTS]):
                raise PermissionError("fingerprint reconciliation contract differs")
            version = versions[f["kind"]]
            fingerprint = _captured_fingerprint(f["input_bytes"], version=version)
            captured = {}
            for name, raw in f["input_bytes"]:
                payload = bytes.fromhex(raw) if raw is not None else None
                captured[name] = payload
            before = json.loads(evidence(fingerprint_target["before_path"], fingerprint_target["before_hash"]))
            after = json.loads(evidence(fingerprint_target["candidate_path"], fingerprint_target["candidate_hash"]))
            expected_after = {"input_fingerprint": fingerprint, "updated_at": journal["observed_at"]}
            if version == FINGERPRINT_VERSION:
                expected_after.update(fingerprint_version=version,
                    observation_fingerprint=_captured_fingerprint(f["input_bytes"], version=version, observations=True))
            release, publication = f["release"], f["publication"]
            for schema, value in (("phase5_release_gate.schema.json", release),
                                  ("youtube_publication_receipt.schema.json", publication),
                                  ("youtube_operational_readiness.schema.json", f["readiness"])):
                Draft202012Validator(_read(root / "schemas" / schema)).validate(value)
            readiness_name = "output/integrations/youtube/heroverse/operational-readiness.json"
            for artifact in release["artifacts"].values():
                if artifact is None:
                    continue
                artifact_path = Path(artifact["path"]).resolve()
                if not artifact_path.is_relative_to(root):
                    raise PermissionError("fingerprint release artifact left the project")
                name = artifact_path.relative_to(root).as_posix()
                if name in captured and (captured[name] is None
                        or hashlib.sha256(captured[name]).hexdigest() != artifact["sha256"]):
                    raise PermissionError("fingerprint release artifact differs from captured input")
            if not (before["input_fingerprint"] == f["previous_fingerprint"]
                    and after == expected_after
                    and fingerprint == f["current_fingerprint"]
                    and release["decision"] == "READY_FOR_PUBLICATION_PIPELINE"
                    and release["publication_pipeline_permitted"] is True
                    and release["created_at"] == journal["observed_at"]
                    and all(gate["status"] == "PASS" for gate in release["gates"])
                    and f["readiness"]["continuous_operation_ready"] is True
                    and f["readiness"] == json.loads(captured[readiness_name])
                    and publication["status"] == "COMPLETE_PUBLIC"
                    and all(step["status"] == "PASS" for step in publication["steps"])
                    and publication["idempotency_key"] == release["idempotency_key"]
                    and publication["release_id"] == release["release_id"]
                    and publication["channel_id"] == release["channel_id"]
                    and publication["artifact_hashes"] == {name: release["artifacts"][name]["sha256"]
                                                          for name in ("video", "thumbnail", "captions")}):
                raise PermissionError("fingerprint reconciliation decision or bytes differ")
            if scope == "CURRENT_MAINTENANCE":
                live_fingerprint = root / "output/runtime/gestor-central/fingerprint.json"
                if (not live_fingerprint.is_file() or live_fingerprint.is_symlink()
                        or _content_hash(live_fingerprint) != fingerprint_target["candidate_hash"]):
                    raise PermissionError("fingerprint reconciliation live target diverged")

        for path_key, hash_key in (
            ("prediction_runtime_path", "prediction_runtime_hash"),
            ("executive_status_path", "executive_status_hash"),
        ):
            target = target_by_path.get(str(migration[path_key]))
            if target is None or target.get("candidate_hash") != migration[hash_key]:
                raise PermissionError(f"local runtime migration {path_key} is not bound to staged bytes")

        if isinstance(media_migration, dict):
            media_target = target_by_path.get(str(media_migration["media_runtime_path"]))
            if not (
                journal.get("media_runtime_migration") == media_migration
                and outcome.get("media_runtime_migration") == media_migration
                and media_target is not None
                and media_target.get("candidate_hash")
                == media_migration["media_runtime_hash"]
                and media_migration["production_authorized"] is False
                and media_migration["publication_authorized"] is False
            ):
                raise PermissionError("media runtime wait is not bound to the transaction")
            if completed_cycle_recovery:
                from . import maintenance_protocol as protocol
                candidate = json.loads(evidence(str(media_target["candidate_path"]), media_migration["media_runtime_hash"]))
                before = json.loads(evidence(str(media_target["before_path"]), media_migration["source_sha256"]))
                expected = protocol._completed_media_recovery_projection(before, media_migration["job"],
                    media_migration["capacity"], observed=protocol._parse(candidate["updated_at"]))
                if (media_target["before_hash"] != media_migration["source_sha256"] or candidate != expected):
                    raise PermissionError("completed media recovery changed fields outside its exact projection")
                protocol.validate(root, "phase6_media_executor_runtime.schema.json", candidate)
                if scope == "CURRENT_MAINTENANCE" and _content_hash(root / media_migration["media_runtime_path"]) != media_target["candidate_hash"]:
                    raise PermissionError("completed media recovery live view diverged")
            elif cache_retry_hold:
                candidate = json.loads(evidence(str(media_target["candidate_path"]), media_migration["media_runtime_hash"]))
                before = json.loads(evidence(str(media_target["before_path"]), media_migration["source_sha256"]))
                expected_candidate = {**before, "status": "WAITING", "error": None,
                                      "next_action": media_migration["reason"], "updated_at": candidate["updated_at"]}
                if (candidate != expected_candidate or before["status"] != media_migration["source_status"]
                        or candidate["job_state"] != "RETRY_WAIT" or not candidate["job_id"]
                        or candidate["render_manifest"] is not None
                        or candidate["input_receipt_id"] != media_migration["input_receipt_id"]
                        or media_target["before_hash"] != media_migration["source_sha256"]
                        or (before["status"] == "RETRY_WAIT" and before["error"] != media_migration["original_error"])
                        or (before["status"] == "WAITING" and (before["error"] is not None
                             or before["next_action"] != media_migration["reason"]))):
                    raise PermissionError("cache retry hold changed more than the exact derived status")
            elif owner_pause_recovery:
                candidate_path = str(media_target.get("candidate_path") or "")
                candidate = json.loads(evidence(candidate_path, media_migration["media_runtime_hash"]).decode("utf-8-sig"))
                if not (
                    media_target.get("before_hash") == media_migration["source_sha256"]
                    and candidate.get("status") == "WAITING"
                    and candidate.get("error") is None
                    and candidate.get("job_id") is None
                    and candidate.get("job_state") == "NOT_CREATED"
                    and candidate.get("voice_manifest") is None
                    and candidate.get("render_manifest") is None
                    and candidate.get("publication_authorized") is False
                    and candidate.get("technical_cost_brl") == 0
                    and candidate.get("next_action") == media_migration["reason"]
                ):
                    raise PermissionError("owner-pause media candidate is not the exact no-effect transition")
            elif prestart_identity_recovery:
                candidate_path = str(media_target.get("candidate_path") or "")
                candidate = json.loads(
                    evidence(candidate_path, media_migration["media_runtime_hash"]).decode("utf-8-sig")
                )
                if not (
                    media_target.get("before_hash") == media_migration["source_sha256"]
                    and candidate.get("schema_version") == "1.2.0"
                    and candidate.get("status") == "WAITING"
                    and candidate.get("input_receipt_id")
                    == media_migration["input_receipt_id"]
                    and candidate.get("error") is None
                    and candidate.get("job_id") is None
                    and candidate.get("job_state") == "NOT_CREATED"
                    and candidate.get("voice_manifest") is None
                    and candidate.get("render_manifest") is None
                    and candidate.get("publication_authorized") is False
                    and candidate.get("technical_cost_brl") == 0
                    and candidate.get("next_action") == media_migration["reason"]
                    and candidate.get("remediation_wait") is None
                ):
                    raise PermissionError("prestart identity recovery candidate is not exact")
            elif forward_current_heartbeat:
                candidate_path = str(media_target.get("candidate_path") or "")
                candidate = json.loads(
                    evidence(candidate_path, media_migration["media_runtime_hash"]).decode("utf-8-sig")
                )
                if not (
                    media_target.get("before_hash") == media_migration["source_sha256"]
                    and candidate.get("schema_version") == "1.2.0"
                    and candidate.get("status") == "WAITING"
                    and candidate.get("input_receipt_id")
                    == media_migration["input_receipt_id"]
                    and candidate.get("error") is None
                    and candidate.get("job_id") is None
                    and candidate.get("job_state") == "NOT_CREATED"
                    and candidate.get("voice_manifest") is None
                    and candidate.get("render_manifest") is None
                    and candidate.get("publication_authorized") is False
                    and candidate.get("technical_cost_brl") == 0
                    and candidate.get("next_action") == media_migration["reason"]
                    and candidate.get("remediation_wait") is None
                ):
                    raise PermissionError("forward current media heartbeat is not exact")
            elif forward_current_wait:
                candidate_path = str(media_target.get("candidate_path") or "")
                candidate = json.loads(
                    evidence(candidate_path, media_migration["media_runtime_hash"]).decode("utf-8-sig")
                )
                if not (
                    media_target.get("before_hash") == media_migration["source_sha256"]
                    and candidate.get("schema_version") == "1.2.0"
                    and candidate.get("status") == "WAITING"
                    and candidate.get("input_receipt_id")
                    == media_migration["current_input_receipt_id"]
                    and candidate.get("error") is None
                    and candidate.get("job_id") is None
                    and candidate.get("job_state") == "NOT_CREATED"
                    and candidate.get("voice_manifest") is None
                    and candidate.get("render_manifest") is None
                    and candidate.get("publication_authorized") is False
                    and candidate.get("technical_cost_brl") == 0
                    and candidate.get("next_action") == media_migration["reason"]
                    and candidate.get("remediation_wait") is None
                ):
                    raise PermissionError("forward current media candidate is not the exact inert transition")
            elif not (
                media_migration["status"] == "WAITING"
                and media_migration["reason"] == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
            ):
                raise PermissionError("media runtime wait reason is not recognized")

        goal_path = "output/operations/phase6/goal-trajectory/current.json"
        goal_target = target_by_path.get(goal_path)
        if goal_target is not None:
            if not (
                type(goal_target.get("existed_before")) is bool
                and goal_target.get("desired_exists") is True
                and goal_target.get("changed") is True
                and isinstance(goal_target.get("candidate_path"), str)
                and isinstance(goal_target.get("candidate_hash"), str)
            ):
                raise PermissionError("forward goal trajectory target is not an exact successor")
            goal_payload = evidence(
                str(goal_target["candidate_path"]), str(goal_target["candidate_hash"])
            )
            try:
                Draft202012Validator(
                    _read(root / "schemas/phase6_goal_trajectory.schema.json"),
                    format_checker=FormatChecker(),
                ).validate(json.loads(goal_payload.decode("utf-8-sig")))
            except Exception as exc:
                raise PermissionError("forward goal trajectory candidate is invalid") from exc
            # Existing targets are already authenticated by the generic
            # journal preimage/size/hash checks above. They are not permission
            # to accept a different live successor; archive replay alone is
            # independent of the mutable current pointer.
            if scope == "CURRENT_MAINTENANCE":
                live_goal = root / goal_path
                if (not live_goal.is_file() or live_goal.is_symlink()
                        or _content_hash(live_goal) != goal_target["candidate_hash"]):
                    raise PermissionError("forward goal trajectory live target diverged")

        if quality_migration is not None:
            from . import maintenance_protocol as protocol
            expected_keys = {"kind", "source_path", "source_sha256", "queue_jobs", "queue_jobs_hash",
                             "media", "render_manifest", "render_manifest_sha256", "candidate_sha256",
                             "quality_authorized", "render_authorized", "publication_authorized"}
            target = target_by_path.get(quality_path)
            if not (isinstance(quality_migration, dict) and set(quality_migration) == expected_keys
                    and quality_migration["kind"] == "EXACT_QUALITY_RECOMPUTATION_RETRY_HOLD"
                    and quality_migration["source_path"] == quality_path and target is not None
                    and journal.get("quality_runtime_migration") == quality_migration
                    and outcome.get("quality_runtime_migration") == quality_migration
                    and target["before_hash"] == quality_migration["source_sha256"]
                    and target["candidate_hash"] == quality_migration["candidate_sha256"]
                    and all(quality_migration[key] is False for key in
                            ("quality_authorized", "render_authorized", "publication_authorized"))
                    and protocol.canonical_hash(quality_migration["queue_jobs"])
                    == quality_migration["queue_jobs_hash"] == migration["queue_jobs_hash_before"]):
                raise PermissionError("quality retry hold is not bound to its transaction and queue")
            before = json.loads(evidence(target["before_path"], target["before_hash"]))
            candidate = json.loads(evidence(target["candidate_path"], target["candidate_hash"]))
            for value in (before, candidate):
                protocol.validate(root, "phase6_quality_executor_runtime.schema.json", value)
            expected = protocol._quality_retry_projection(
                before, quality_migration["queue_jobs"], quality_migration["media"],
                quality_migration["render_manifest"], quality_migration["render_manifest_sha256"],
                observed=protocol._parse(candidate["updated_at"]))
            if candidate != expected:
                raise PermissionError("quality retry hold candidate altered fields beyond its exact projection")
            if scope == "CURRENT_MAINTENANCE" and _content_hash(root / quality_path) != target["candidate_hash"]:
                raise PermissionError("quality retry hold live view diverged")

        error = migration["control_cycle_error"]
        base_target_paths = {
            "output/operations/phase6/intelligence/prediction-runtime.json",
            "output/operations/phase6/executive-status.json",
            "output/operations/phase6/EXECUTIVE_STATUS.md",
        }
        if goal_target is not None:
            base_target_paths.add(goal_path)
        if fingerprint_target is not None:
            base_target_paths.add("output/runtime/gestor-central/fingerprint.json")
        if quality_migration is not None:
            base_target_paths.add(quality_path)
        if isinstance(media_migration, dict):
            base_target_paths.add(
                "output/operations/phase6/media-executor-status.json"
            )
        expected_legacy_runtime_checks = {
            "exact_channel",
            "exact_observer",
            "exact_prediction_bound",
            "exact_queue_job_bound",
            "legacy_runtime_v1",
            "phase6_error_status",
            "prediction_schema_failure",
            "zero_cost_error",
        }
        expected_executive_replace_checks = {
            "exact_error_bytes",
            "exact_error_payload_schema",
            "exact_error_timestamp",
            "exact_error_target_pair",
            "exact_terminal_media_wait",
            "exact_media_proof_binding",
            "executive_atomic_writer_v2",
            "executive_json_stable_read",
            "executive_capture_after_error",
            "executive_reflects_exact_visual_block",
            "executive_json_markdown_reconciled",
            "fixed_legacy_tmp_absent",
        }
        archived_error_actions = {
            "ARCHIVED_CORRELATED_LEGACY_RUNTIME": expected_legacy_runtime_checks,
            "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE": expected_executive_replace_checks,
        }
        if error["action"] in archived_error_actions:
            source_hash = str(error["source_hash"])
            if error["action"] == "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE":
                if not (
                    source_hash
                    == "sha256:1184c5b3d869e30c1c012e4e5f59fdf4dea1ae5c9bd288be59bca3dc9b9fa6b3"
                    and isinstance(media_migration, dict)
                    and media_migration.get("authority_root_job_id")
                    == "job-ddc7d6b9605b194c44fd4f78"
                    and media_migration.get("authority_tail_job_id")
                    == "job-c516db5685acbbb423199bc1"
                    and media_migration.get("input_receipt_id")
                    == "phase6-production-inputs-79b3e183dd5df410fb3a"
                ):
                    raise PermissionError(
                        "executive writer error archive is not bound to the exact terminal media migration"
                    )
            expected_archive = (
                "output/operations/phase6/control-cycle/errors/archive/"
                + str(request_id)
                + "/control-cycle-error-"
                + source_hash.split(":", 1)[1][:16]
                + ".json"
            )
            archive_path = str(error["archive_path"])
            if not (
                archive_path == expected_archive
                and error["archive_hash"] == source_hash
                and set(error["correlation_checks"])
                == archived_error_actions[error["action"]]
                and archive_path in target_by_path
                and target_by_path[archive_path].get("candidate_hash") == source_hash
                and target_by_path.get(str(error["source_path"]), {}).get("desired_exists") is False
            ):
                raise PermissionError("correlated legacy control-cycle error archive proof diverged")
            archived = root / archive_path
            if not archived.is_file() or _content_hash(archived) != source_hash:
                raise PermissionError("correlated legacy control-cycle error archive bytes are absent")
            if scope == "CURRENT_MAINTENANCE" and (root / str(error["source_path"])).exists():
                raise PermissionError("correlated legacy control-cycle error remains current")
            if set(target_by_path) != base_target_paths | {archive_path, str(error["source_path"])}:
                raise PermissionError("correlated legacy migration target set is not exact")
        elif not (
            error["action"] == "NOT_PRESENT"
            and error["source_hash"] is None
            and error["archive_path"] is None
            and error["archive_hash"] is None
            and error["correlation_checks"] == []
            and str(error["source_path"]) not in target_by_path
            and (scope == "PAUSED_APPLICATION_ARCHIVE" or not (root / str(error["source_path"])).exists())
        ):
            raise PermissionError("absent control-cycle error proof diverged")
        elif set(target_by_path) != base_target_paths:
            raise PermissionError("local runtime migration base target set is not exact")




def verify_regression_evidence(root: Path, receipt: dict[str, Any]) -> None:
    """Verify the receipt's manifests/logs and zero-mutation queue proof."""
    schema_version = receipt.get("schema_version")
    if schema_version not in {"1.0.0", "1.1.0", "1.2.0"} or receipt.get("status") != "PASS":
        raise PermissionError("current maintenance regression receipt is not a PASS")
    if not (
        receipt.get("mode") == "LOCAL_VALIDATION_ONLY"
        and receipt.get("external_effects_permitted") is False
        and receipt.get("external_api_calls") == 0
        and receipt.get("publication_effects") == 0
        and receipt.get("operational_queue_mutations") == 0
    ):
        raise PermissionError("maintenance regression did not preserve its zero-effect boundary")
    run_parent = Path("output/runtime/gestor-central/maintenance-runs") / str(receipt["request_id"])

    if schema_version in {"1.1.0", "1.2.0"}:
        verify_local_migration_evidence(root, request_id=receipt["request_id"],
                                        migration=receipt.get("local_runtime_migration"),
                                        schema_version=schema_version)

    def evidence(relative: str, expected_hash: str) -> bytes:
        path = _confined(root, relative, run_parent)
        payload = path.read_bytes()
        if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
            raise PermissionError(f"maintenance evidence hash mismatch: {relative}")
        return payload

    if schema_version == "1.2.0":
        Draft202012Validator(
            _read(root / "schemas" / "daily_maintenance_regression_receipt.schema.json"),
            format_checker=FormatChecker(),
        ).validate(receipt)
        requested_at = _parse(str(receipt["requested_at"]))
        boundary_at = _parse(str(receipt["zero_effect_boundary_started_at"]))
        started_at = _parse(str(receipt["started_at"]))
        completed_at = _parse(str(receipt["regression_completed_at"]))
        if not (
            boundary_at == started_at <= completed_at
            and requested_at <= completed_at
            and abs((requested_at - boundary_at).total_seconds()) <= 300
        ):
            raise PermissionError("maintenance regression temporal boundary is inconsistent")
        stopped = receipt["stopped_state"]
        before = json.loads(
            evidence(str(stopped["before_path"]), str(stopped["before_hash"])).decode("utf-8-sig")
        )
        after = json.loads(
            evidence(str(stopped["after_path"]), str(stopped["after_hash"])).decode("utf-8-sig")
        )
        if not (
            before.get("request_id") == receipt["request_id"]
            and after.get("request_id") == receipt["request_id"]
            and before.get("role") == "PRE_REGRESSION"
            and after.get("role") == "POST_REGRESSION"
            and _parse(str(before["requested_at"])) == requested_at
            and _parse(str(after["requested_at"])) == requested_at
            and _parse(str(before["zero_effect_boundary_started_at"])) == boundary_at
            and _parse(str(after["zero_effect_boundary_started_at"])) == boundary_at
            and boundary_at <= _parse(str(before["observed_at"]))
            <= _parse(str(after["observed_at"])) <= completed_at
            and int(before.get("former_manager_pid") or 0) > 0
            and before.get("former_manager_pid") == after.get("former_manager_pid")
            and before.get("state_hash") == stopped["before_state_hash"]
            and after.get("state_hash") == stopped["after_state_hash"]
            and stopped["before_state_hash"] == stopped["after_state_hash"]
            and before.get("state") == after.get("state")
            and before.get("state_hash") == _canonical_hash(before.get("state"))
            and after.get("state_hash") == _canonical_hash(after.get("state"))
        ):
            raise PermissionError("stopped-regression full operational state changed")
        for snapshot in (before, after):
            canonical_state = json.loads(
                evidence(
                    str(snapshot["canonical_state_path"]),
                    str(snapshot["canonical_state_hash"]),
                ).decode("utf-8-sig")
            )
            if canonical_state != snapshot["state"] or _canonical_hash(canonical_state) != snapshot["state_hash"]:
                raise PermissionError("stopped-regression canonical state evidence diverged")
            inspection = json.loads(
                evidence(str(snapshot["inspection_path"]), str(snapshot["inspection_hash"])).decode(
                    "utf-8-sig"
                )
            )
            if (
                inspection.get("blockers") != []
                or int(inspection.get("manager_pid") or 0) != int(snapshot["former_manager_pid"])
                or not (
                    boundary_at
                    <= _parse(str(inspection["observed_at"]))
                    <= _parse(str(snapshot["observed_at"]))
                )
                or inspection.get("active_lease_job_ids")
                or (inspection.get("quota") or {}).get("reserved_ids")
                or (inspection.get("operational_effects") or {}).get("open_receipt_paths")
            ):
                raise PermissionError("stopped-regression inspection is not a clean bound quiescent state")
            state = snapshot["state"]
            if not (
                state.get("queue_jobs_hash") == (inspection.get("queue") or {}).get("jobs_hash")
                and state.get("queue_jobs") == (inspection.get("queue") or {}).get("jobs")
                and state.get("quota_ledger_state_hash")
                == (inspection.get("quota_ledger") or {}).get("state_hash")
                and state.get("quota_ledger_tables")
                == (inspection.get("quota_ledger") or {}).get("tables")
                and state.get("operational_effects_hash")
                == (inspection.get("operational_effects") or {}).get("receipts_hash")
                and state.get("operational_effect_receipts")
                == (inspection.get("operational_effects") or {}).get("receipts")
            ):
                raise PermissionError("stopped-regression snapshot diverges from its inspection")

            byte_evidence = snapshot.get("byte_evidence")
            if not isinstance(byte_evidence, dict):
                raise PermissionError("stopped-regression byte evidence is absent")
            state_groups = {
                "queue_store_files": state.get("queue_store_files"),
                "quota_store_files": state.get("quota_store_files"),
                "operational_effect_receipt_files": state.get("operational_effect_receipt_files"),
                "operational_effect_surface_files": state.get("operational_effect_surface_files"),
                "oauth_proof_files": state.get("oauth_proof_files"),
            }

            def projection(item: dict[str, Any]) -> dict[str, Any]:
                return {
                    "identity": item.get("identity"),
                    "path": item.get("path"),
                    "path_identity_hash": item.get("path_identity_hash"),
                    "present": item.get("present"),
                    "byte_count": item.get("byte_count"),
                    "content_hash": item.get("content_hash"),
                }

            for group, projected in state_groups.items():
                records = byte_evidence.get(group)
                if not isinstance(records, list) or projected != [projection(item) for item in records]:
                    raise PermissionError(f"stopped-regression {group} projection diverged")
                for item in records:
                    relative = item.get("path")
                    if not isinstance(relative, str):
                        raise PermissionError(f"stopped-regression {group} contains an unbound path")
                    live_path = (root / relative).resolve()
                    try:
                        live_path.relative_to(root.resolve())
                    except ValueError as exc:
                        raise PermissionError(f"stopped-regression {group} path escaped workspace") from exc
                    expected_path_identity = "sha256:" + hashlib.sha256(
                        str(live_path).lower().encode("utf-8")
                    ).hexdigest()
                    if item.get("path_identity_hash") != expected_path_identity:
                        raise PermissionError(f"stopped-regression {group} path identity diverged")
                    if item.get("present") is True:
                        raw = evidence(str(item["snapshot_path"]), str(item["snapshot_hash"]))
                        if not (
                            len(raw) == item.get("byte_count")
                            and "sha256:" + hashlib.sha256(raw).hexdigest() == item.get("content_hash")
                        ):
                            raise PermissionError(f"stopped-regression {group} byte evidence diverged")
                    elif not (
                        item.get("present") is False
                        and item.get("byte_count") is None
                        and item.get("content_hash") is None
                        and item.get("snapshot_path") is None
                        and item.get("snapshot_hash") is None
                    ):
                        raise PermissionError(f"stopped-regression {group} absence evidence diverged")

            expected_fixed_paths = {
                "queue_store_files": {
                    "output/operations/phase6/runtime/phase6-queue.sqlite3",
                    "output/operations/phase6/runtime/phase6-queue.sqlite3-wal",
                    "output/operations/phase6/runtime/phase6-queue.sqlite3-shm",
                },
                "quota_store_files": {
                    "output/operations/zero-cost/phase6-quota-ledger.sqlite3",
                    "output/operations/zero-cost/phase6-quota-ledger.sqlite3-wal",
                    "output/operations/zero-cost/phase6-quota-ledger.sqlite3-shm",
                },
                "operational_effect_surface_files": {
                    "output/operations/phase6/package-treatment-executor-status.json",
                    "output/operations/phase6/publication-controller-status.json",
                },
                "oauth_proof_files": {
                    "output/runtime/gestor-central/oauth-session-health.json",
                    "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json",
                    "output/runtime/gestor-central/oauth-reconsent-watcher.json",
                    "output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json",
                    "output/integrations/youtube/heroverse/connection-receipt.json",
                    "output/runtime/gestor-central/maintenance-capability.json",
                },
            }
            for group, paths in expected_fixed_paths.items():
                actual = {str(item.get("path")) for item in byte_evidence[group]}
                if actual != paths:
                    raise PermissionError(f"stopped-regression {group} scope diverged")
            expected_effect_paths = {
                str(item["path"])
                for item in (inspection.get("operational_effects") or {}).get("receipts", [])
            }
            actual_effect_paths = {
                str(item.get("path"))
                for item in byte_evidence["operational_effect_receipt_files"]
            }
            if actual_effect_paths != expected_effect_paths:
                raise PermissionError("stopped-regression effect receipt byte scope diverged")

            token = byte_evidence.get("oauth_runtime_token")
            if not isinstance(token, dict) or projection(token) != state.get("oauth_runtime_token"):
                raise PermissionError("stopped-regression external token projection diverged")
            if not (
                token.get("identity") == "OAUTH_RUNTIME_TOKEN_EXTERNAL"
                and token.get("path") is None
                and token.get("snapshot_path") is None
                and token.get("snapshot_hash") is None
                and token.get("present") is True
            ):
                raise PermissionError("stopped-regression external token evidence is not safely redacted")
            watcher_path = root / "output/runtime/gestor-central/oauth-reconsent-watcher.json"
            watcher = _read(watcher_path)
            Draft202012Validator(
                _read(root / "schemas" / "oauth_reconsent_watcher_runtime.schema.json"),
                format_checker=FormatChecker(),
            ).validate(watcher)
            token_path = Path(str(watcher["destination_path"])).resolve()
            try:
                token_path.relative_to(root.resolve())
            except ValueError:
                pass
            else:
                raise PermissionError("stopped-regression runtime token is inside the workspace")
            expected_destination_hash = hashlib.sha256(
                str(token_path).casefold().encode("utf-8")
            ).hexdigest()
            if not (
                watcher.get("destination_outside_workspace") is True
                and watcher.get("destination_exists") is True
                and watcher.get("destination_path_sha256") == expected_destination_hash
            ):
                raise PermissionError("stopped-regression runtime token destination proof diverged")
            token_raw = token_path.read_bytes()
            token_path_identity = "sha256:" + hashlib.sha256(
                str(token_path).lower().encode("utf-8")
            ).hexdigest()
            if not (
                token.get("path_identity_hash") == token_path_identity
                and token.get("byte_count") == len(token_raw)
                and token.get("content_hash")
                == "sha256:" + hashlib.sha256(token_raw).hexdigest()
            ):
                raise PermissionError("stopped-regression external token bytes changed")

    tests = receipt["tests"]
    test_manifest_bytes = evidence(tests["inventory_path"], tests["inventory_hash"])
    test_manifest = json.loads(test_manifest_bytes.decode("utf-8-sig"))
    try:
        test_ids = _inventory_ids(test_manifest)
    except UnittestResultError as exc:
        raise PermissionError(f"maintenance test inventory is inconsistent: {exc}") from exc
    if (
        test_manifest.get("test_count") != tests["test_count"]
        or test_manifest.get("file_count") != tests["file_count"]
        or test_manifest.get("tests_hash") != _canonical_hash(test_ids)
        or len(test_ids) != len(set(test_ids))
    ):
        raise PermissionError("maintenance test inventory count/identity is inconsistent")
    for item in test_manifest.get("files", []):
        path = _confined(root, str(item["path"]), Path("tests"))
        if _content_hash(path) != item.get("content_hash"):
            raise PermissionError(f"test source changed after inventory: {item.get('path')}")
    stdout_bytes = evidence(tests["stdout_log"], tests["stdout_hash"])
    stderr_bytes = evidence(tests["stderr_log"], tests["stderr_hash"])
    try:
        test_result = verify_unittest_result(
            inventory=test_manifest,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            process_exit_code=None,
        )
    except UnittestResultError as exc:
        raise PermissionError(
            f"maintenance unittest transcript does not prove the inventoried PASS: {exc}"
        ) from exc
    if test_result["test_count"] != tests["test_count"]:
        raise PermissionError("maintenance unittest receipt count diverges from verified transcript")

    compileall = receipt["compileall"]
    evidence(compileall["stdout_log"], compileall["stdout_hash"])
    evidence(compileall["stderr_log"], compileall["stderr_hash"])

    schemas = receipt["schemas"]
    schema_manifest = json.loads(
        evidence(schemas["inventory_path"], schemas["inventory_hash"]).decode("utf-8-sig")
    )
    schema_items = schema_manifest.get("schemas", [])
    if (
        schema_manifest.get("schema_count") != schemas["schema_count"]
        or schema_manifest.get("schemas_hash") != _canonical_hash(schema_items)
    ):
        raise PermissionError("maintenance schema inventory count/hash is inconsistent")
    for item in schema_items:
        path = _confined(root, str(item["path"]), Path("schemas"))
        if _content_hash(path) != item.get("content_hash"):
            raise PermissionError(f"schema source changed after inventory: {item.get('path')}")
        Draft202012Validator.check_schema(_read(path))

    queue = receipt["queue"]
    before = json.loads(evidence(queue["before_path"], queue["before_hash"]).decode("utf-8-sig"))
    after = json.loads(evidence(queue["after_path"], queue["after_hash"]).decode("utf-8-sig"))
    for value, claimed in ((before, queue["before_jobs_hash"]), (after, queue["after_jobs_hash"])):
        if value.get("jobs_hash") != claimed or claimed != _canonical_hash(value.get("jobs", [])):
            raise PermissionError("maintenance queue manifest does not match its job bytes")
        if value.get("active_lease_job_ids"):
            raise PermissionError("maintenance queue snapshot contains an active lease")
    if queue.get("unchanged") is not True or before.get("jobs") != after.get("jobs"):
        raise PermissionError("maintenance changed jobs, attempts, checkpoints, leases or due times")

    integrity = receipt["integrity"]
    integrity_path = _confined(root, integrity["manifest_path"], Path("output/production/phase5/pilot-001"))
    if _content_hash(integrity_path) != integrity["content_hash"]:
        raise PermissionError("maintenance integrity manifest changed after regression")
    integrity_value = _read(integrity_path)
    if (
        integrity_value.get("item_count") != integrity["item_count"]
        or integrity_value.get("total_bytes") != integrity["total_bytes"]
    ):
        raise PermissionError("maintenance integrity manifest totals diverged")


@contextmanager
def _paused_application_scope(root: Path, reference_path: Path, expected_hash: str):
    """Explicit anchored history reader; no restart, legacy fallback or SQL."""
    from . import maintenance_paused_application as a
    from . import maintenance_protocol as p
    from .current_operational_application_proof import (
        NotCurrentOperationalProof,
        read_current_operational_proof,
    )

    root = root.resolve()
    _source_specs(root, reference_path, expected_hash)
    with ExitStack() as stack:
        pins = []
        held = {}
        def hold(path):
            p._paused_cancel_safe_path(root, path) if path.is_relative_to(root) else None
            if path not in held:
                held[path] = stack.enter_context(closing(p._PausedCancelPin(path, capture=False)))
                pins.append(held[path])
            return held[path]

        def read(relative, digest):
            a.require(type(digest) is str and re.fullmatch(r"sha256:[0-9a-f]{64}", digest), "D116_ANCHOR_INVALID")
            path = a._path(root, relative)
            hold(path)
            raw = path.read_bytes()
            a.require(a._digest(raw) == digest, "D116_EVIDENCE_CHANGED")
            return a._json(raw)

        reference = read(reference_path.as_posix(), expected_hash)
        p.validate(root, "phase6_paused_application_reference.schema.json", reference)
        run = a._path(root, reference["commit_path"]).parent
        a.require(run.parent == root / a.RUNS and re.fullmatch(r"maintenance-request-[0-9]{8}T[0-9]{13}Z-[0-9a-f]{8}", run.name)
                  and reference["commit_path"] == (run / "committed.json").relative_to(root).as_posix(), "D116_RUN_INVALID")
        binding = {"root": str(root), "proof_path": reference["proof_path"],
                   "proof_hash": reference["proof_sha256"], "candidate_sha256": reference["candidate_sha256"]}
        receipt = read(reference["commit_path"], reference["commit_sha256"])
        a.require(receipt["binding"] == binding, "D116_BINDING_DIVERGED")
        # Keep exact immutable history and executed sources protected throughout
        # this invocation, not just until the expensive authentication returns.
        source_set = set(a.source_paths(root))
        dependency_set = set(a._dependency_paths())
        for path in sorted(source_set | dependency_set):
            hold(path)
        a.require(type(receipt.get("evidence")) is dict, "D116_EVIDENCE_INCOMPLETE")
        for relative in receipt["evidence"]:
            path = a._path(root, relative)
            a.require(path.is_relative_to(run), "D116_ARCHIVE_ORIGIN_INVALID")
            hold(path)
        archived = a.verify_archived_commit(root, run, binding)
        a.require(archived == receipt, "D116_COMMIT_CHANGED")
        # The controlled application accepts two explicit proof families.  Try
        # the forward-only current contract in an isolated pin scope so that a
        # legacy-purpose rejection releases its handle before the immutable
        # historical reader authenticates the same envelope.
        current_proof = None
        with ExitStack() as proof_stack:
            try:
                current_proof = read_current_operational_proof(
                    root,
                    Path(reference["proof_path"]),
                    reference["proof_sha256"],
                    reference["candidate_sha256"],
                    proof_stack,
                )
            except NotCurrentOperationalProof:
                pass
            else:
                stack.enter_context(proof_stack.pop_all())
        proof = current_proof or a.read_regression_proof(
            root,
            Path(reference["proof_path"]),
            reference["proof_sha256"],
            reference["candidate_sha256"],
            stack,
        )
        a.require(receipt["regression"] == proof["regression"], "D116_REGRESSION_DIVERGED")
        prepared = p._read(run / "prepared.json")
        capture = p._paused_cancel_verify_capture(run, binding, prepared["database_capture"])
        archived_hashes = dict(prepared["protected_hashes"])
        for item in capture["files"]:
            a.require(item["relative"] not in archived_hashes, "D116_DUPLICATE_SOURCE")
            archived_hashes[item["relative"]] = item["sha256"]
        a.require(archived_hashes == proof["protected_hashes"], "D116_PRESERVATION_DIVERGED")
        for relative, digest in prepared["protected_hashes"].items():
            target = a._path(root, (run / "protected-before" / relative).relative_to(root).as_posix())
            a.require(p.file_hash(target) == digest, "D116_ARCHIVED_SOURCE_DIVERGED")
        if reference["schema_version"] == "1.0.0":
            process = read(reference["process_path"], reference["process_sha256"])
            process_dir = a._path(root, reference["process_path"]).parent
            a.require(process_dir.parent == root / a.RUNS and process_dir != run, "D116_PROCESS_ORIGIN_INVALID")
            a.require(read((process_dir / "application.stdout.log").relative_to(root).as_posix(), reference["stdout_sha256"]) == receipt,
                      "D116_PROCESS_OUTPUT_DIVERGED")
            stderr = a._path(root, (process_dir / "application.stderr.log").relative_to(root).as_posix())
            pins.append(stack.enter_context(closing(p._PausedCancelPin(stderr, capture=False))))
            a.require(p.file_hash(stderr) == reference["stderr_sha256"] and stderr.read_bytes() == b"", "D116_PROCESS_STDERR")
            a.require(set(process) == {"command", "pid", "started_at", "finished_at", "wall_seconds", "exit_code",
                                       "automatic_retry", "supervisor_restart_authorized"}
                      and type(process["exit_code"]) is int and process["exit_code"] == 0
                      and type(process["pid"]) is int and process["pid"] > 0
                      and process["automatic_retry"] is False and process["supervisor_restart_authorized"] is False,
                      "D116_PROCESS_INVALID")
            command = process["command"]
            a.require(type(command) is list and len(command) == 13
                      and Path(command[0]).resolve() == root / ".venv/Scripts/python.exe"
                      and command[1:5] == ["-B", "-m", "hero_engine.maintenance_protocol", "--root"]
                      and Path(command[5]).resolve() == root
                      and command[6:] == ["apply-paused", "--proof-envelope", reference["proof_path"],
                        "--expected-proof-hash", reference["proof_sha256"], "--expected-candidate-hash", reference["candidate_sha256"]],
                      "D116_PROCESS_COMMAND_DIVERGED")
            started, finished = p._parse(process["started_at"]), p._parse(process["finished_at"])
            journal = p._read(run / "local-runtime-migration-journal.json")
            a.require(p._parse(proof["regression_finished_at"]) <= started <= p._parse(journal["observed_at"]) < finished
                      <= datetime.now(timezone.utc)
                      and type(process["wall_seconds"]) in (int, float) and 0 < process["wall_seconds"]
                      and abs((finished - started).total_seconds() - process["wall_seconds"]) <= 1,
                      "D116_APPLICATION_TIME_INVALID")
            completed_at = process["finished_at"]
        else:
            a.require(reference.get("reference_kind") == "DIRECT_PROTOCOL", "D116_DIRECT_REFERENCE_KIND_INVALID")
            expected = {
                "prepared_path": run / "prepared.json",
                "migration_journal_path": run / "local-runtime-migration-journal.json",
                "migration_outcome_path": run / "local-runtime-migration-outcome.json",
            }
            values = {}
            for name, path in expected.items():
                key = name.removesuffix("_path") + "_sha256"
                a.require(reference[name] == path.relative_to(root).as_posix(), "D116_DIRECT_REFERENCE_PATH_INVALID")
                values[name] = read(reference[name], reference[key])
            journal = values["migration_journal_path"]
            outcome = values["migration_outcome_path"]
            a.require(values["prepared_path"].get("binding") == binding
                      and journal.get("request_id") == run.name and outcome.get("request_id") == run.name
                      and outcome.get("record_type") == "COMMITTED"
                      and outcome.get("journal_hash") == reference["migration_journal_sha256"]
                      and receipt.get("migration") == p._read(run / "migration.json"),
                      "D116_DIRECT_TRANSACTION_DIVERGED")
            completed_at = journal.get("observed_at")
            a.require(type(completed_at) is str
                      and p._parse(proof["regression_finished_at"]) <= p._parse(completed_at) <= datetime.now(timezone.utc),
                      "D116_DIRECT_APPLICATION_TIME_INVALID")
        for pin in pins + proof["pins"]:
            pin.revalidate()
        result = {"reference": reference, "receipt": receipt, "application_id": run.name,
                "completed_at": completed_at, "regression_completed_at": proof["regression_finished_at"],
                "regression": proof["regression"], "reference_path": reference_path.as_posix(), "reference_hash": expected_hash}
        def check_history():
            for pin in pins + proof["pins"]:
                pin.revalidate()
            a.require(set(a.source_paths(root)) == source_set and set(a._dependency_paths()) == dependency_set,
                      "D116_SOURCE_POPULATION_CHANGED")
            a.require({path.relative_to(root).as_posix() for path in run.rglob("*")
                       if path.is_file() and path != run / "committed.json"} == set(receipt["evidence"]),
                      "D116_ARCHIVE_POPULATION_CHANGED")
        yield result, check_history
        check_history()


def verify_paused_application(root: Path, reference_path: Path, expected_hash: str) -> dict[str, Any]:
    """Public history-only check. Its returned dict is never accepted as authority."""
    with _paused_application_scope(root.resolve(), reference_path, expected_hash) as (result, check):
        check()
        return json.loads(json.dumps(result))


def _exact_media_restart_observation(root: Path, migration: dict[str, Any] | None,
                                     cycle: dict[str, Any], executive: dict[str, Any]) -> bool:
    """Match a live hold/completion to its authenticated immutable candidate.

    History authentication remains in the existing public entry. This adds no
    queue/render authority and tolerates only the view's refreshed timestamp.
    """
    media = (migration or {}).get("media_runtime_migration")
    kinds = {"EXACT_CACHE_REJECTION_RESTART_HOLD": ("WAITING", "RETRY_WAIT"),
             "EXACT_RESOURCE_RESERVE_RESTART_HOLD": ("WAITING", "RETRY_WAIT"),
             "EXACT_COMPLETED_MEDIA_CYCLE_RECOVERY": ("COMPLETED", "SUCCEEDED")}
    if not isinstance(media, dict) or media.get("kind") not in kinds:
        return False
    status, job_state = kinds[media["kind"]]
    if not (media.get("status") == status and media.get("production_authorized") is False
            and media.get("publication_authorized") is False
            and executive.get("status") == "ACTIVE_OBSERVING" and executive.get("attention_items") == []
            and (executive.get("release_control") or {}).get("publication_authorized") is False):
        return False
    journal_path = _confined(root, migration["transaction_journal_path"],
                            Path("output/runtime/gestor-central/maintenance-runs"))
    journal_raw = journal_path.read_bytes()
    if "sha256:" + hashlib.sha256(journal_raw).hexdigest() != migration["transaction_journal_hash"]:
        raise PermissionError("exact media restart observation journal diverged")
    targets = [item for item in json.loads(journal_raw)["targets"]
               if item["path"] == "output/operations/phase6/media-executor-status.json"]
    if len(targets) != 1 or targets[0]["candidate_hash"] != media["media_runtime_hash"]:
        raise PermissionError("exact media restart observation candidate binding diverged")
    candidate_path = _confined(root, targets[0]["candidate_path"], journal_path.parent.relative_to(root))
    candidate_raw = candidate_path.read_bytes()
    if "sha256:" + hashlib.sha256(candidate_raw).hexdigest() != targets[0]["candidate_hash"]:
        raise PermissionError("exact media restart observation candidate bytes diverged")
    record = next(item for item in cycle["stages"] if item["stage"] == "MEDIA")
    snapshot_parent = Path("output/operations/phase6/control-cycle/source-snapshots") / cycle["cycle_id"]
    snapshot_raw = _confined(root, record["snapshot_path"], snapshot_parent).read_bytes()
    if "sha256:" + hashlib.sha256(snapshot_raw).hexdigest() != record["content_hash"]:
        raise PermissionError("exact media restart observation snapshot diverged")
    candidate, live = json.loads(candidate_raw), json.loads(snapshot_raw)
    candidate.pop("updated_at"); live.pop("updated_at")
    if (live != candidate or live.get("status") != status or live.get("job_state") != job_state
            or live.get("error") is not None or live.get("publication_authorized") is not False):
        return False
    if media["kind"] in {"EXACT_CACHE_REJECTION_RESTART_HOLD", "EXACT_RESOURCE_RESERVE_RESTART_HOLD"}:
        if (live.get("input_receipt_id") != media["input_receipt_id"]
                or live.get("next_action") != media["reason"] or live.get("render_manifest") is not None):
            return False
    else:
        job = media.get("job") or {}
        checkpoint = job.get("checkpoint") or {}
        if not (job.get("state") == "SUCCEEDED" and live.get("job_id") == job.get("job_id")
                and job.get("lease_owner") is None and job.get("lease_until") is None
                and live.get("input_receipt_id") == checkpoint.get("input_receipt_id")
                and live.get("voice_manifest") == checkpoint.get("voice_manifest")
                and live.get("render_manifest") == checkpoint.get("render_manifest")
                and live.get("voice_manifest") and live.get("render_manifest")
                and live.get("next_action") == "RUN_PHASE6_VIDEO2_QUALITY_GATES"):
            return False
    projection = {key: live[key] for key in (
        "input_receipt_id", "action", "job_state", "voice_manifest", "render_manifest",
        "capacity_preflight_receipt", "capacity_status", "capacity_observed_free_bytes",
        "capacity_required_free_bytes", "capacity_headroom_bytes", "next_action", "publication_authorized")}
    projection["executor_status"] = live["status"]
    return executive.get("media_execution") == projection


class _ActiveCycleMismatch(PermissionError):
    """A live executive does not describe the selected immutable cycle."""


def _active_content_inputs(root: Path, cycle: dict, executive: dict):
    """Resolve a rejected-content observation only from its frozen cycle.

    Never substitute later mutable aliases for QUALITY/MEDIA/PUBLICATION.
    The reporting producer already authenticated those aliases at observation.
    """
    from .phase6_quality import REPORT
    from .phase6_reporting import BASE as report_base
    Draft202012Validator(_read(root / 'schemas/phase6_executive_status.schema.json'),
                        format_checker=FormatChecker()).validate(executive)
    verify_control_cycle_sources(root, cycle)
    stages = {item['stage']: item for item in cycle['stages']}
    frozen = _read(root / stages['EXECUTIVE_VIEW']['snapshot_path'])
    for field in ('schema_version', 'status', 'attention_items', 'quality_execution',
                  'media_execution', 'publication_execution', 'release_control', 'active_content_remediation'):
        if executive.get(field) != frozen.get(field):
            raise _ActiveCycleMismatch('active content observation differs from its control cycle')
    sources, values = {}, []
    for stage, filename in (('QUALITY', 'quality-executor-status.json'),
                            ('MEDIA', 'media-executor-status.json'),
                            ('PUBLICATION', 'publication-controller-status.json')):
        relative = Path(stages[stage]['snapshot_path'])
        sources[report_base / filename] = relative
        values.append(_read(root / relative))
    if values[0]['evaluation'] is not None:
        sources[REPORT] = Path(values[0]['evaluation'])
    return values, sources


def _exact_active_content_observation(root: Path, cycle: dict, executive: dict) -> bool:
    if executive.get('status') != 'ACTIVE_CONTENT_REMEDIATION':
        return False
    from .phase6_reporting import _terminal_rejected_content
    values, sources = _active_content_inputs(root, cycle, executive)
    witness = _terminal_rejected_content(root, *values, paused=False, _snapshot_sources=sources)
    if witness != executive['active_content_remediation']:
        raise PermissionError('active content rejection evidence differs')
    return True


def _evaluate_observed(
    root: Path,
    *,
    maintenance: dict[str, Any],
    autostart: dict[str, Any],
    cycle: dict[str, Any],
    acceptance: dict[str, Any],
    executive: dict[str, Any],
    verified_at: datetime,
    source_hashes: dict[Path, str] | None = None,
    paused_application_reference: Path | None = None,
    expected_reference_hash: str | None = None,
    application: dict[str, Any] | None = None,
    package_relative: Path | None = None,
) -> dict[str, Any]:
    selected = package_relative is not None
    cycle_path, acceptance_path, executive_path = _delivery_paths(root, package_relative)
    if selected:
        if application is None:
            raise PermissionError('current audio D116 requires authenticated paused application')
        from .phase6_control_cycle import verify_audio_cycle_sources
        verify_audio_cycle_sources(root, cycle, executive)
        candidate = application['reference']['candidate_sha256']
        if (cycle.get('schema_version') not in {'1.2.0','1.3.0'}
                or executive.get('schema_version') != '2.0.0'
                or acceptance.get('schema_version') != '1.2.0'
                or any(value.get('source_candidate_sha256') != candidate
                       for value in (cycle, executive, acceptance))
                or cycle.get('package_relative') != Path(package_relative).as_posix()
                or executive['current_delivery']['package_relative'] != Path(package_relative).as_posix()
                or acceptance.get('current_delivery') != executive['current_delivery']
                or acceptance.get('current_executive_evidence') != {
                    'path': executive_path.as_posix(), 'sha256': source_hashes[executive_path]}):
            raise PermissionError('current audio application/cycle/report/acceptance binding diverged')
    maintenance_path = paused_application_reference if application else MAINTENANCE_PATH
    maintenance_id = application["application_id"] if application else maintenance["receipt_id"]
    maintenance_completed = _parse(application["completed_at"] if application else str(maintenance.get("regression_completed_at") or maintenance["completed_at"]))
    cycle_started = _parse(str(cycle["cycle_started_at"]))
    cycle_completed = _parse(str(cycle["cycle_completed_at"]))
    runtime_verified = _parse(str(autostart["verified_at"]))
    acceptance_generated = _parse(str(acceptance["generated_at"]))
    executive_captured = _parse(str(executive["captured_at"]))

    maintenance_status = maintenance.get("status") or maintenance.get("regression_status")
    maintenance_test_count = (
        (maintenance.get("tests") or {}).get("test_count")
        if isinstance(maintenance.get("tests"), dict)
        else maintenance.get("test_count")
    )
    if application:
        maintenance_status = application["regression"]["status"]
        maintenance_test_count = application["regression"]["test_count"]
    if maintenance_status != "PASS":
        raise PermissionError("post-maintenance verification requires a passing regression receipt")
    if cycle_started < maintenance_completed:
        raise PermissionError("control cycle predates maintenance completion")
    if not (
        cycle.get("decision") in {"PASS_WAITING", "PASS_ADVANCED"}
        and cycle.get("stage_count") == 12
        and cycle.get("expected_stage_count") == 12
        and cycle.get("all_schemas_valid") is True
        and cycle.get("all_stages_executed_in_cycle") is True
        and cycle.get("blockers") == []
    ):
        raise PermissionError("post-maintenance control cycle is not an integral 12/12 PASS")
    verify_control_cycle_sources(root, cycle)
    if runtime_verified < maintenance_completed or autostart.get("operational_ready") is not True:
        raise PermissionError("runtime verification is stale or not operationally ready")
    if application:
        identity = autostart.get("process_identity") or {}
        if not (autostart.get("schema_version") == "1.1.0" and identity.get("stable_across_probe") is True
                and identity.get("pid") == autostart.get("manager_pid") == autostart.get("lock_holder_pid") == autostart.get("review_process_id")
                and autostart.get("manager_alive") is True and autostart.get("same_process_chain") is True
                and autostart.get("duplicate_probe_blocked") is True and autostart.get("continuous_awake") is True):
            raise PermissionError("paused application restart identity incomplete")
        process_started = _parse(identity["started_at"])
        if not (maintenance_completed < process_started <= cycle_started < cycle_completed <= verified_at
                and process_started <= runtime_verified <= verified_at
                and process_started <= _parse(autostart["lock_heartbeat_at"]) <= runtime_verified < _parse(autostart["lease_expires_at"])):
            raise PermissionError("paused application restart chronology diverged")
    if not (
        int(autostart.get("manager_pid") or 0) > 0
        and autostart.get("task_state") == "Running"
        and autostart.get("lock_state") == "HELD"
        and autostart.get("review_console_status") == "LISTENING"
        and autostart.get("duplicate_probe_exit_code") == 73
        and autostart.get("active_stderr_bytes") == 0
        and autostart.get("power_continuity_status") == "PASS"
    ):
        raise PermissionError("resident manager process-chain proof is incomplete")

    by_id = {item.get("check_id"): item for item in acceptance.get("checks", [])}
    cycle_statuses = {check_id: (by_id.get(check_id) or {}).get("status") for check_id in INTEGRAL_CYCLE_CHECKS}
    if any(status != "PASS_LIVE" for status in cycle_statuses.values()):
        raise PermissionError("acceptance does not consume an integral live control-cycle proof")
    blockers = set(acceptance.get("blocking_check_ids") or [])
    checks = acceptance.get("checks") or []
    pass_statuses = {"PASS_FIXTURE", "PASS_LIVE"}
    computed_blockers = {
        str(item.get("check_id"))
        for item in checks
        if item.get("required_for_phase6") is True
        and (
            item.get("status") != "PASS_LIVE"
            if item.get("minimum_evidence") == "LIVE"
            else item.get("status") not in pass_statuses
        )
    }
    if not blockers.issubset(EXPECTED_PENDING_CHECKS):
        raise PermissionError(f"acceptance has unexpected blockers: {sorted(blockers - EXPECTED_PENDING_CHECKS)}")
    if blockers != computed_blockers:
        raise PermissionError("acceptance blocker index does not match its required checks")
    if acceptance_generated < cycle_completed:
        raise PermissionError("acceptance report predates the fresh control cycle")
    if application and (
        acceptance.get("schema_version") != ("1.2.0" if selected else "1.1.0")
        or acceptance.get("control_cycle_evidence") != {
            "cycle_id": cycle["cycle_id"], "content_hash": source_hashes[cycle_path]
        }
    ):
        raise PermissionError("acceptance control-cycle binding diverged")
    if acceptance.get("current_phase_ready") is True:
        if blockers or acceptance.get("phase_decision") != "APPROVED":
            raise PermissionError("ready acceptance is internally inconsistent")
    elif acceptance.get("phase_decision") != "IN_PROGRESS":
        raise PermissionError("non-ready acceptance must remain IN_PROGRESS")

    executive_cycle = executive.get("control_cycle") or {}
    if selected:
        # This profile seals the report produced during the same cycle. It has
        # no legacy trajectory projection and never borrows the pilot's view.
        if not (cycle_started <= executive_captured <= cycle_completed
                and executive.get('status') == 'ACTIVE_OBSERVING'
                and executive.get('attention_items') == []
                and executive.get('cost', {}).get('technical_cost_brl') == 0):
            raise PermissionError('current audio executive chronology/status diverged')
        executive_cycle = cycle
    elif application:
        # The already-authenticated application above binds resident source
        # bytes and real completion time. Extend that SAME chain through the
        # exact cycle/trajectory/report/acceptance, not a historical signature.
        from .phase6_control_cycle import verify_completed_projection
        binding = verify_completed_projection(root, cycle, source_hashes[CYCLE_PATH], executive)
        if acceptance.get("executive_evidence") != {
            **binding, "executive_sha256": source_hashes[EXECUTIVE_PATH]
        }:
            raise PermissionError("CURRENT_CHAIN_ACCEPTANCE_EXECUTIVE_DIVERGED")
    migration_source = application["receipt"]["migration"] if application else maintenance.get("local_runtime_migration")
    media_migration = (
        (migration_source or {}).get(
            "media_runtime_migration"
        )
        if isinstance(migration_source, dict)
        else None
    )
    media_execution = executive.get("media_execution") or {}
    exact_production_blocked_observation = bool(
        isinstance(media_migration, dict)
        and media_migration.get("status") == "WAITING"
        and media_migration.get("reason")
        == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
        and media_migration.get("production_authorized") is False
        and media_migration.get("publication_authorized") is False
        and executive.get("status") == "ACTIVE_OBSERVING_PRODUCTION_BLOCKED"
        and executive.get("attention_items")
        == ["MEDIA_POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"]
        and media_execution.get("executor_status") == "WAITING"
        and media_execution.get("input_receipt_id")
        == media_migration.get("input_receipt_id")
        == "phase6-production-inputs-79b3e183dd5df410fb3a"
        and media_execution.get("job_state") == "SUCCEEDED"
        and media_execution.get("next_action")
        == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
        and media_execution.get("publication_authorized") is False
        and (executive.get("release_control") or {}).get(
            "next_video_authorized"
        )
        is False
        and (executive.get("release_control") or {}).get(
            "publication_authorized"
        )
        is False
    )
    ordinary_observation = bool(
        media_migration is None
        and executive.get("status") == "ACTIVE_OBSERVING"
        and executive.get("attention_items") == []
    )
    exact_owner_pause_observation = bool(
        isinstance(media_migration, dict)
        and media_migration.get("kind") == "EXACT_OWNER_PAUSE_NO_EFFECT_RECOVERY"
        and media_migration.get("status") == "WAITING"
        and media_migration.get("production_authorized") is False
        and media_migration.get("publication_authorized") is False
        and executive.get("status") == "ACTIVE_OBSERVING"
        and executive.get("attention_items") == []
        and media_execution.get("executor_status") == "WAITING"
        and media_execution.get("job_id") is None
        and media_execution.get("job_state") == "NOT_CREATED"
        and media_execution.get("publication_authorized") is False
    )
    if not selected and not (
        (
            ordinary_observation
            or exact_owner_pause_observation
            or exact_production_blocked_observation
            or _exact_media_restart_observation(root, migration_source, cycle, executive)
            or _exact_active_content_observation(root, cycle, executive)
        )
        and executive.get("cost", {}).get("technical_cost_brl") == 0
        and executive_cycle.get("cycle_id") == cycle.get("cycle_id")
        and executive_cycle.get("decision") == cycle.get("decision")
        and executive_captured >= cycle_completed
    ):
        raise PermissionError("executive view is not reconciled to the fresh control cycle")
    if verified_at < executive_captured:
        raise PermissionError("verification timestamp predates the reconciled executive view")

    current_errors = _delivery_errors(root, package_relative)
    if current_errors:
        raise PermissionError(f"current Phase 6 error files remain after recovery: {current_errors}")

    semantic = {
        "maintenance_receipt_id": maintenance_id,
        "manager_pid": autostart["manager_pid"],
        "cycle_id": cycle["cycle_id"],
        "acceptance_report_id": acceptance["report_id"],
        "executive_captured_at": executive["captured_at"],
    }
    if application:
        semantic["paused_application_reference_hash"] = expected_reference_hash
        semantic["manager_started_at"] = autostart["process_identity"]["started_at"]
    verification_id = "phase6-post-maintenance-" + _canonical_hash(semantic).split(":", 1)[1][:24]
    hashes = source_hashes or {
        path: _content_hash(root / path)
        for path in (maintenance_path, AUTOSTART_PATH, cycle_path, acceptance_path, executive_path)
    }
    result = {
        "schema_version": ("1.3.0" if selected else "1.2.0" if application and application["reference"].get("reference_kind") == "DIRECT_PROTOCOL"
                           else "1.1.0" if application else "1.0.0"),
        "verification_id": verification_id,
        "phase": 6,
        "status": "PASS",
        "maintenance": {
            "path": maintenance_path.as_posix(),
            "snapshot_path": _snapshot_path(verification_id, "maintenance").as_posix(),
            "receipt_id": maintenance_id,
            "completed_at": _stamp(maintenance_completed),
            "regression_status": maintenance_status,
            "test_count": maintenance_test_count,
            "content_hash": hashes[maintenance_path],
        },
        "runtime": {
            "path": AUTOSTART_PATH.as_posix(),
            "snapshot_path": _snapshot_path(verification_id, "runtime").as_posix(),
            "manager_pid": autostart["manager_pid"],
            "task_state": autostart["task_state"],
            "lock_state": autostart["lock_state"],
            "review_console_status": autostart["review_console_status"],
            "duplicate_probe_exit_code": autostart["duplicate_probe_exit_code"],
            "active_stderr_bytes": autostart["active_stderr_bytes"],
            "power_continuity_status": autostart["power_continuity_status"],
            "operational_ready": autostart["operational_ready"],
            "verified_at": autostart["verified_at"],
            "content_hash": hashes[AUTOSTART_PATH],
        },
        "control_cycle": {
            "path": cycle_path.as_posix(),
            "snapshot_path": _snapshot_path(verification_id, "control-cycle").as_posix(),
            "cycle_id": cycle["cycle_id"],
            "cycle_started_at": cycle["cycle_started_at"],
            "cycle_completed_at": cycle["cycle_completed_at"],
            "decision": cycle["decision"],
            "stage_count": cycle["stage_count"],
            "expected_stage_count": cycle["expected_stage_count"],
            "all_schemas_valid": cycle["all_schemas_valid"],
            "all_stages_executed_in_cycle": cycle["all_stages_executed_in_cycle"],
            "blockers": cycle["blockers"],
            "content_hash": hashes[cycle_path],
        },
        "acceptance": {
            "path": acceptance_path.as_posix(),
            "snapshot_path": _snapshot_path(verification_id, "acceptance").as_posix(),
            "report_id": acceptance["report_id"],
            "phase_decision": acceptance["phase_decision"],
            "current_phase_ready": acceptance["current_phase_ready"],
            "blocking_check_ids": sorted(blockers),
            "integral_cycle_check_statuses": cycle_statuses,
            "content_hash": hashes[acceptance_path],
        },
        "executive": {
            "path": executive_path.as_posix(),
            "snapshot_path": _snapshot_path(verification_id, "executive").as_posix(),
            "status": executive["status"],
            "captured_at": executive["captured_at"],
            "control_cycle_id": executive_cycle["cycle_id"],
            "control_cycle_decision": executive_cycle["decision"],
            "attention_items": executive["attention_items"],
            "technical_cost_brl": executive["cost"]["technical_cost_brl"],
            "content_hash": hashes[executive_path],
        },
        "current_error_files": [],
        "technical_cost_brl": 0,
        "claim_boundary": [
            "This receipt proves regression, resident-runtime recovery and a fresh integral Phase 6 control cycle after the same maintenance; it does not prove audience response.",
            "Only GC-01, GC-11 and GC-19 may remain pending in the current Phase 6 evidence window; a later approved report may have no blockers.",
            "A passing unit suite cannot replace this post-restart live reconciliation, and this receipt cannot authorize spend or bypass publication gates.",
        ],
        "verified_at": _stamp(verified_at),
    }
    if executive.get('status') == 'ACTIVE_CONTENT_REMEDIATION':
        result['executive'].update(quality_decision='FAIL', render_authorized=False, publication_authorized=False)
        if 'counterevidence' in executive['active_content_remediation']:
            result['executive']['counterevidence_observation'] = 'REGISTERED_WORD_COUNTEREVIDENCE_V1'
            result['claim_boundary'].append('A prequeue pixel counterexample remains FAIL without creating a QA job; this technical observation does not authorize rendering or publication.')
        else:
            result['claim_boundary'].append('A terminal content rejection remains FAIL: this technical observation does not authorize rendering or publication.')
    if application:
        public_reference_fields = {"reference_kind", "commit_path", "commit_sha256", "proof_path", "proof_sha256",
                                   "candidate_sha256", "process_path", "process_sha256",
                                   "stdout_sha256", "stderr_sha256"}
        result["maintenance"].update(evidence_type="PAUSED_APPLICATION", application_status="APPLIED_WHILE_PAUSED",
            regression_completed_at=application["regression_completed_at"],
            **{key: value for key, value in application["reference"].items() if key in public_reference_fields})
        result["runtime"]["process_identity"] = autostart["process_identity"]
    return result


def _delivery_paths(root, package_relative=None):
    if package_relative is None:
        return CYCLE_PATH, ACCEPTANCE_PATH, EXECUTIVE_PATH
    relative = Path(package_relative)
    directory = (root / relative).resolve()
    if (relative.is_absolute() or '..' in relative.parts
            or not directory.is_relative_to((root / 'output/production').resolve())
            or directory == (root / 'output/production').resolve()):
        raise PermissionError('current D116 package must be confined to production')
    base = relative / 'intelligence'
    return base/'control-cycle/latest.json', base/'acceptance-report.json', base/'executive-status.json'


def _delivery_errors(root, package_relative=None):
    if package_relative is None:
        return current_phase6_errors(root)
    # Never erase or reinterpret cinema errors as belonging to this delivery.
    base = root / package_relative / 'intelligence'
    return [path.relative_to(root).as_posix() for path in base.glob('*.error.json')]


def _source_specs(root, reference, anchor, package_relative=None):
    if (reference is None) != (anchor is None):
        raise PermissionError("ambiguous maintenance origin: reference and external anchor required together")
    if package_relative is not None and reference is None:
        raise PermissionError('current audio D116 requires authenticated paused application')
    cycle_path, acceptance_path, executive_path = _delivery_paths(root, package_relative)
    maintenance_path, schema = MAINTENANCE_PATH, "daily_maintenance_regression_receipt.schema.json"
    if reference is not None:
        from . import maintenance_paused_application as a
        path = a._path(root, Path(reference).as_posix())
        if path.parent.parent != root / a.RUNS or path.name != "paused-application-reference.json":
            raise PermissionError("paused application reference must have an exact run-scoped origin")
        maintenance_path, schema = Path(reference), "phase6_paused_application_reference.schema.json"
    return (("maintenance", maintenance_path, schema),
        ("runtime", AUTOSTART_PATH, "central_manager_autostart_verification.schema.json"),
        ("control-cycle", cycle_path, "phase6_control_cycle_receipt.schema.json"),
        ("acceptance", acceptance_path, "phase6_acceptance_report.schema.json"),
        ("executive", executive_path, "phase6_executive_status.schema.json"))


def evaluate(root: Path, *, maintenance, autostart, cycle, acceptance, executive,
             verified_at: datetime, source_hashes=None, paused_application_reference=None,
             expected_reference_hash=None, package_relative=None):
    """Public evaluation authenticates its inputs; no caller-supplied PASS."""
    if paused_application_reference is not None or expected_reference_hash is not None:
        offered = {"maintenance": maintenance, "runtime": autostart, "control-cycle": cycle,
                   "acceptance": acceptance, "executive": executive}
        with _observed_receipt(root.resolve(), verified_at=_stamp(verified_at),
                reference=paused_application_reference, anchor=expected_reference_hash,
                offered=offered, offered_hashes=source_hashes, package_relative=package_relative) as (value, _, _, check):
            check()
            return value
    if package_relative is not None:
        raise PermissionError('current audio D116 requires authenticated paused application')
    if isinstance(maintenance.get("tests"), dict):
        verify_regression_evidence(root, maintenance)
    return _evaluate_observed(root, maintenance=maintenance, autostart=autostart,
        cycle=cycle, acceptance=acceptance, executive=executive, verified_at=verified_at,
        source_hashes=source_hashes)


def _timestamp_refresh_in_progress(root, cycle, executive):
    """Recognize ONLY clock-only runtime refreshes; this never approves a set.

    The manager publishes the three runtimes and the executive before closing
    its next cycle. Old stage hashes and new alias hashes must each be exact,
    and all logical fields and non-runtime witness bindings must be unchanged.
    A different decision, source, job or identity remains an immediate failure.
    """
    stages = {item['stage']: item for item in cycle['stages']}
    frozen = _read(root / stages['EXECUTIVE_VIEW']['snapshot_path'])
    fields = ('schema_version', 'status', 'attention_items', 'quality_execution',
              'media_execution', 'publication_execution', 'release_control')
    if any(executive.get(key) != frozen.get(key) for key in fields):
        return False
    before = frozen.get('active_content_remediation', {})
    after = executive.get('active_content_remediation', {})
    if ({k: v for k, v in before.items() if k != 'sources'} !=
            {k: v for k, v in after.items() if k != 'sources'}):
        return False
    old = {s['path']: s['sha256'] for s in before.get('sources', [])}
    new = {s['path']: s['sha256'] for s in after.get('sources', [])}
    if (set(old) != set(new) or len(old) != len(before.get('sources', []))
            or len(new) != len(after.get('sources', []))):
        return False
    changed = {path for path in old if old[path] != new[path]}
    runtime_stages = {'output/operations/phase6/' + name: stage for stage, name in (
        ('QUALITY', 'quality-executor-status.json'), ('MEDIA', 'media-executor-status.json'),
        ('PUBLICATION', 'publication-controller-status.json'))}
    if not changed or not changed.issubset(runtime_stages):
        return False
    for relative in changed:
        stage = stages[runtime_stages[relative]]
        prior_raw = (root / stage['snapshot_path']).read_bytes()
        path = _confined(root, relative, Path('output/operations/phase6'))
        current_raw = path.read_bytes()
        digest = lambda raw: 'sha256:' + hashlib.sha256(raw).hexdigest()
        if digest(prior_raw) != old[relative] or digest(current_raw) != new[relative]:
            return False
        prior, current = json.loads(prior_raw), json.loads(current_raw)
        if ({k: v for k, v in prior.items() if k != 'updated_at'} !=
                {k: v for k, v in current.items() if k != 'updated_at'}):
            return False
        if not (_parse(cycle['cycle_completed_at']) < _parse(current['updated_at'])
                <= _parse(executive['captured_at'])):
            return False
        if path.read_bytes() != current_raw:
            return False
    return True


# Same bounded fresh-cycle window as the controlled-resume protocol. No
# repeated historical authentication and no extension of process/lease validity.
LIVE_CYCLE_WAIT_SECONDS = 420.0


def _wait_for_completed_cycle(root, cycle, deadline):
    """Wait for material publication, not retries of the same mismatched set."""
    while time.monotonic() < deadline:
        if (root / 'output/runtime/gestor-central/PAUSE').exists():
            raise PermissionError('owner pause appeared while waiting for completed cycle')
        if current_phase6_errors(root):
            raise PermissionError('current Phase 6 error appeared while waiting for completed cycle')
        current, raw, digest = _read_validated(root, CYCLE_PATH, 'phase6_control_cycle_receipt.schema.json')
        if current['cycle_id'] != cycle['cycle_id']:
            if _parse(current['cycle_started_at']) <= _parse(cycle['cycle_completed_at']):
                raise PermissionError('replacement control cycle chronology diverged')
            acceptance, acceptance_raw, _ = _read_validated(root, ACCEPTANCE_PATH, 'phase6_acceptance_report.schema.json')
            executive, executive_raw, executive_hash = _read_validated(root, EXECUTIVE_PATH, 'phase6_executive_status.schema.json')
            from .phase6_control_cycle import verify_completed_projection
            try:
                binding = verify_completed_projection(root, current, digest, executive)
            except PermissionError:
                binding = None  # Wait within this existing bound; no stale projection.
            if (acceptance.get('control_cycle_evidence') == {'cycle_id': current['cycle_id'], 'content_hash': digest}
                    and binding is not None
                    and acceptance.get('executive_evidence') == {**binding, 'executive_sha256': executive_hash}
                    and (root / CYCLE_PATH).read_bytes() == raw
                    and (root / EXECUTIVE_PATH).read_bytes() == executive_raw
                    and (root / ACCEPTANCE_PATH).read_bytes() == acceptance_raw):
                return
        time.sleep(min(0.5, max(0.0, deadline - time.monotonic())))
    raise PermissionError('no coherent completed cycle within bounded live capture window')


@contextmanager
def _capture_live_sources(root, specs):
    """Three bounded optimistic reads; pin immutable stage bytes, not latest.

    Mutable sources must be identical across the short capture. Later legitimate
    publication of another cycle is allowed after this observation is sealed.
    """
    from . import maintenance_protocol as p
    deadline = time.monotonic() + LIVE_CYCLE_WAIT_SECONDS
    for attempt in range(3):
        with ExitStack() as stack:
            values, payloads, hashes = {}, {}, {}
            for label, relative, schema in specs:
                values[label], payloads[label], hashes[relative] = _read_validated(root, relative, schema)
            cycle = values["control-cycle"]
            pins = []
            parent = specs[2][1].parent / 'source-snapshots' / cycle["cycle_id"]
            for stage in cycle["stages"]:
                path = _confined(root, stage["snapshot_path"], parent)
                p._paused_cancel_safe_path(root, path)
                pins.append(stack.enter_context(closing(p._PausedCancelPin(path, capture=False))))
            verify_control_cycle_sources(root, cycle)
            if values['executive'].get('status') == 'ACTIVE_CONTENT_REMEDIATION':
                try:
                    stage_values, _ = _active_content_inputs(root, cycle, values['executive'])
                except _ActiveCycleMismatch:
                    if attempt == 2 or not _timestamp_refresh_in_progress(root, cycle, values['executive']):
                        raise
                    _wait_for_completed_cycle(root, cycle, deadline)
                    continue
                quality, media, _ = stage_values
                witness = values['executive']['active_content_remediation']
                hashes_expected = {item['path']: item['sha256'] for item in witness['sources']}
                if 'counterevidence' in witness:
                    # Runtime aliases are already pinned as immutable cycle
                    # snapshots. All measured-content dependencies stay pinned
                    # through final revalidation and receipt archival.
                    runtime_paths = {'output/operations/phase6/' + name for name in (
                        'quality-executor-status.json', 'media-executor-status.json',
                        'publication-controller-status.json')}
                    dependencies = {path: digest for path, digest in hashes_expected.items()
                                    if path not in runtime_paths}
                else:
                    report = _read(root / quality['evaluation'])
                    dependencies = {
                        quality['evaluation']: hashes_expected[quality['evaluation']],
                        media['render_manifest']: hashes_expected[media['render_manifest']],
                        report['artifact']['path']: witness['artifact_sha256'],
                    }
                for relative, expected in dependencies.items():
                    path = root / relative
                    p._paused_cancel_safe_path(root, path)
                    pins.append(stack.enter_context(closing(p._PausedCancelPin(path, capture=False))))
                    with path.open('rb') as stream:
                        actual = 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest()
                    if actual != expected:
                        raise PermissionError('active content immutable dependency differs')
            if any((root / relative).read_bytes() != payloads[label] for label, relative, _ in specs):
                continue
            # Cross-source coherence is enforced by evaluation, not a retry that
            # silently accepts permanently incompatible data.
            observed = datetime.now(timezone.utc)
            def check():
                for pin in pins:
                    pin.revalidate()
                verify_control_cycle_sources(root, cycle)
                # Do not accept a newly malformed/error live view. A *valid*
                # newer latest need not equal the already sealed observation.
                for _, relative, schema in specs:
                    _read_validated(root, relative, schema)
                package = Path(cycle['package_relative']) if cycle.get('schema_version') in {'1.2.0','1.3.0'} else None
                errors = _delivery_errors(root, package)
                if errors:
                    raise PermissionError(f"current Phase 6 error files remain after recovery: {errors}")
                if (values['executive'].get('status') == 'ACTIVE_CONTENT_REMEDIATION'
                        and (root / 'output/runtime/gestor-central/PAUSE').exists()):
                    raise PermissionError('owner pause appeared after active content capture')
                if 'counterevidence' in values['executive'].get('active_content_remediation', {}):
                    _exact_active_content_observation(root, cycle, values['executive'])
            yield values, payloads, hashes, observed, check
            return
    raise PermissionError("live capture changed during all 3 bounded attempts")


@contextmanager
def _observed_receipt(root, *, verified_at=None, reference=None, anchor=None,
                      offered=None, offered_hashes=None, package_relative=None):
    specs = _source_specs(root, reference, anchor, package_relative)
    with ExitStack() as stack:
        # Authentication happens exactly once, BEFORE selecting the live cycle.
        application, check_history = (stack.enter_context(_paused_application_scope(root, reference, anchor))
                                      if reference is not None else (None, lambda: None))
        if application is None:
            from .maintenance_protocol import _PausedCancelPin
            legacy_pin = stack.enter_context(closing(_PausedCancelPin(root / specs[0][1])))
            legacy, legacy_raw, _ = _read_validated(root, specs[0][1], specs[0][2])
            check_history = legacy_pin.revalidate
            if isinstance(legacy.get("tests"), dict):
                verify_regression_evidence(root, legacy)
        values, payloads, hashes, observed, check_live = stack.enter_context(_capture_live_sources(root, specs))
        def check():
            check_history()
            check_live()
        if application is not None and (values["maintenance"] != application["reference"]
                                       or hashes[reference] != anchor):
            raise PermissionError("paused application reference snapshot/hash diverged")
        if application is None and payloads["maintenance"] != legacy_raw:
            raise PermissionError("legacy maintenance changed after authentication")
        if offered is not None and (offered != values or
                (offered_hashes is not None and offered_hashes != hashes)):
            raise PermissionError("offered live snapshot/source diverged")
        value = _evaluate_observed(root, maintenance=values["maintenance"], autostart=values["runtime"],
            cycle=values["control-cycle"], acceptance=values["acceptance"], executive=values["executive"],
            verified_at=_parse(verified_at) if verified_at else observed, source_hashes=hashes,
            paused_application_reference=reference, expected_reference_hash=anchor, application=application,
            package_relative=package_relative)
        Draft202012Validator(_read(root / "schemas/phase6_post_maintenance_verification.schema.json"),
                            format_checker=FormatChecker()).validate(value)
        yield value, payloads, specs, check


def build(root: Path = ROOT, *, verified_at: str | None = None,
          paused_application_reference: Path | None = None, expected_reference_hash: str | None = None,
          package_relative: Path | None = None) -> dict[str, Any]:
    with _observed_receipt(root.resolve(), verified_at=verified_at, reference=paused_application_reference,
                           anchor=expected_reference_hash, package_relative=package_relative) as (value, _, _, check):
        check()
        return value


def materialize(root: Path = ROOT, *, verified_at: str | None = None,
                paused_application_reference: Path | None = None, expected_reference_hash: str | None = None,
                package_relative: Path | None = None) -> Path:
    from .maintenance_snapshot import _publish
    root = root.resolve()
    with _observed_receipt(root, verified_at=verified_at, reference=paused_application_reference,
                           anchor=expected_reference_hash, package_relative=package_relative) as (value, payloads, specs, check):
        latest = root / BASE / "latest.json"
        history = root / BASE / "history" / f"{value['verification_id']}.json"
        check()
        for label, relative, _ in specs:
            snapshot = root / _snapshot_path(value["verification_id"], label)
            if snapshot.exists() and snapshot.read_bytes() != payloads[label]:
                raise PermissionError(f"immutable post-maintenance source collision: {label}")
        if history.is_file() and _read(history) != value:
            raise PermissionError("immutable post-maintenance verification collision")
        with ExitStack() as outputs:
            from .maintenance_protocol import _PausedCancelPin
            pins = []
            for label, relative, _ in specs:
                snapshot = root / _snapshot_path(value["verification_id"], label)
                _publish(snapshot, payloads[label])
                pins.append(outputs.enter_context(closing(_PausedCancelPin(snapshot))))
                if snapshot.read_bytes() != payloads[label]:
                    raise PermissionError(f"archived post-maintenance source hash mismatch: {label}")
            # Stage snapshots are still pinned through archive/history/latest.
            check()
            for pin in pins:
                pin.revalidate()
            _publish(history, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
            _write(latest, value)
        return latest


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description="D-116 evidence verification; never starts the manager")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--paused-application-reference", type=Path)
    parser.add_argument("--expected-reference-hash")
    parser.add_argument("--package-relative", type=Path)
    parser.add_argument("--verified-at")
    args = parser.parse_args(argv)
    print(materialize(args.root, verified_at=args.verified_at,
        paused_application_reference=args.paused_application_reference, expected_reference_hash=args.expected_reference_hash,
        package_relative=args.package_relative))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
