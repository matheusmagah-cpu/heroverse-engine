"""Stage, verify and commit a Phase 5 integrity-manifest successor safely.

The historical manifest is immutable evidence.  This module therefore never
edits it in place: it stages a successor bound to both the historical manifest
and the exact resident package snapshot.  Commit is intentionally a separate
controlled-maintenance action with a rollback preimage.
"""
from __future__ import annotations

import hashlib
import json
from contextlib import ExitStack
from pathlib import Path
from typing import Any

from .atomic_io import atomic_write_utf8

PACKAGE = Path("output/production/phase5/pilot-001")
HISTORICAL_NAME = "integrity_manifest.json"
SUCCESSOR_VERSION = "phase5-integrity-successor-v1"


class IntegrityMaintenanceError(ValueError):
    pass


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _entries(package: Path) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(package.iterdir()):
        if not path.is_file() or path.name in {HISTORICAL_NAME, "integrity_manifest_successor.json"}:
            continue
        raw = path.read_bytes()
        rows.append({"artifact": path.name, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
    if not rows:
        raise IntegrityMaintenanceError("pilot package has no resident files to inventory")
    return rows


def stage_successor(root: Path, *, stage: Path) -> dict[str, Any]:
    root = Path(root).resolve(strict=True)
    package = root / PACKAGE
    historical = package / HISTORICAL_NAME
    if not historical.is_file():
        raise IntegrityMaintenanceError("historical integrity manifest is absent")
    historical_raw = historical.read_bytes()
    try:
        old = json.loads(historical_raw.decode("utf-8-sig"))
    except Exception as exc:
        raise IntegrityMaintenanceError("historical integrity manifest is invalid") from exc
    if old.get("algorithm") != "SHA-256" or not isinstance(old.get("entries"), list):
        raise IntegrityMaintenanceError("historical integrity manifest contract differs")
    entries = _entries(package)
    current = {row["artifact"]: row for row in entries}
    old_rows = {row.get("artifact"): row for row in old["entries"] if isinstance(row, dict)}
    drift = [name for name, row in current.items() if old_rows.get(name) != row]
    if not drift:
        raise IntegrityMaintenanceError("historical integrity manifest is already current")
    stage = Path(stage).resolve()
    try:
        stage.relative_to(root)
    except ValueError as exc:
        raise PermissionError("integrity successor stage must remain in workspace") from exc
    value = {
        "version": SUCCESSOR_VERSION,
        "status": "STAGED_NOT_COMMITTED",
        "historical_manifest": {"path": (PACKAGE / HISTORICAL_NAME).as_posix(), "sha256": _sha(historical_raw), "size_bytes": len(historical_raw)},
        "resident_package": {"path": PACKAGE.as_posix(), "entries": entries, "total_bytes": sum(row["bytes"] for row in entries)},
        "drifted_artifacts": drift,
        "rollback": {"required": True, "preimage_sha256": _sha(historical_raw), "automatic_apply": False},
        "authority": {"commit": False, "publication": False},
    }
    value["successor_sha256"] = _sha(_canonical(value).encode())
    stage.mkdir(parents=True, exist_ok=False)
    target = stage / "integrity_manifest_successor.json"
    atomic_write_utf8(target, _canonical(value) + "\n")
    return value


def verify_staged_successor(root: Path, staged: dict[str, Any]) -> dict[str, Any]:
    if staged.get("version") != SUCCESSOR_VERSION or staged.get("status") != "STAGED_NOT_COMMITTED":
        raise IntegrityMaintenanceError("integrity successor state differs")
    stage_hash = staged.get("successor_sha256")
    expected = dict(staged)
    expected.pop("successor_sha256", None)
    if stage_hash != _sha(_canonical(expected).encode()):
        raise IntegrityMaintenanceError("integrity successor canonical hash differs")
    package = Path(root).resolve(strict=True) / PACKAGE
    current = _entries(package)
    if current != staged["resident_package"]["entries"]:
        raise IntegrityMaintenanceError("resident package changed after integrity successor staging")
    if staged["authority"] != {"commit": False, "publication": False}:
        raise IntegrityMaintenanceError("integrity successor attempted authority")
    return staged


def commit_staged_successor(root: Path, *, stage: Path, expected_successor_hash: str,
                            proof_envelope: Path, expected_proof_hash: str,
                            expected_candidate_hash: str) -> dict[str, Any]:
    """Publish only a successor view after an external paused transaction approves it.

    Authentication is delegated to the existing paused-application proof
    reader.  A forward-only focal proof cannot satisfy this contract; that
    prevents a caller-provided authorization object from becoming a bypass.
    The historical manifest is never a target.
    """
    root = Path(root).resolve(strict=True)
    stage = Path(stage).resolve(strict=True)
    try:
        stage.relative_to(root)
    except ValueError as exc:
        raise PermissionError("integrity successor stage must remain in workspace") from exc
    raw = (stage / "integrity_manifest_successor.json").read_bytes()
    staged = json.loads(raw.decode("utf-8"))
    verify_staged_successor(root, staged)
    if staged.get("successor_sha256") != expected_successor_hash:
        raise IntegrityMaintenanceError("expected successor hash differs")
    from . import maintenance_paused_application as paused
    from .phase5_integrity_successor_proof import read_integrity_successor_proof
    try:
        with ExitStack() as stack:
            if not (root / paused.p.RUNTIME / "PAUSE").is_file():
                raise IntegrityMaintenanceError("owner pause is absent")
            paused._check_host(root)
            proof = read_integrity_successor_proof(root, Path(proof_envelope), expected_proof_hash,
                                                    expected_candidate_hash, expected_successor_hash, stack)
            if proof["candidate"]["source_set_sha256"] != expected_candidate_hash or not proof["authority"]["integrity_successor_commit"]:
                raise IntegrityMaintenanceError("authenticated proof candidate differs")
            for pin in proof["pins"]:
                pin.revalidate()
    except IntegrityMaintenanceError:
        raise
    except Exception as exc:
        raise IntegrityMaintenanceError("authenticated paused proof is inadmissible") from exc
    package = root / PACKAGE
    target = package / "integrity_manifest_successor.json"
    rollback = stage / "rollback-preimage.json"
    if target.exists():
        raise IntegrityMaintenanceError("integrity successor target already exists")
    preimage = {"target": target.relative_to(root).as_posix(), "existed": False, "historical_manifest": staged["historical_manifest"]}
    atomic_write_utf8(rollback, _canonical(preimage) + "\n")
    atomic_write_utf8(target, _canonical(staged) + "\n")
    if target.read_bytes() != _canonical(staged).encode() + b"\n":
        raise IntegrityMaintenanceError("integrity successor commit bytes differ")
    return {"status": "COMMITTED_SUCCESSOR_VIEW_WHILE_PAUSED", "target": target.relative_to(root).as_posix(),
            "successor_sha256": expected_successor_hash, "rollback_preimage": rollback.relative_to(root).as_posix(),
            "historical_manifest_unchanged": True, "publication_authorized": False,
            "proof_envelope_sha256": expected_proof_hash, "candidate_sha256": expected_candidate_hash}


def rollback_committed_successor(root: Path, *, stage: Path, expected_successor_hash: str) -> None:
    """Rollback only the successor view owned by the matching staged transaction."""
    root = Path(root).resolve(strict=True)
    stage = Path(stage).resolve(strict=True)
    staged = json.loads((stage / "integrity_manifest_successor.json").read_text(encoding="utf-8"))
    if staged.get("successor_sha256") != expected_successor_hash:
        raise IntegrityMaintenanceError("rollback successor hash differs")
    target = root / PACKAGE / "integrity_manifest_successor.json"
    if not target.is_file() or target.read_bytes() != _canonical(staged).encode() + b"\n":
        raise IntegrityMaintenanceError("rollback target is not the owned successor view")
    target.unlink()
