"""Read one frozen visual amendment without activating media or creating a clock.

V2 is independently recomposed exactly once. Its historical decisions remain
historical; only the twelve explicit visual-content replacements are effective.
Physical artifact bytes are rechecked, not decoded. The bound static QA is
historical provenance, NOT a fresh pixel, runtime, rights or final-video gate.
The consumer must recheck all returned dependencies at its final return.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import re

from jsonschema import Draft202012Validator

from .phase6_av_caption_intent import _binding, _resident
from .phase6_av_visual_intent import (
    PLAN_BINDING, EDITORIAL_SUPPLEMENT_BINDING,
    _same, _state_entries, read_visual_intent,
)
from .phase6_narration_audio_inventory import _json
from .phase6_narration_units import bytes_sha, canonical_sha

VERSION = "phase6-av-visual-amendment-v1"
SCHEMA = "schemas/phase6_av_visual_amendment.schema.json"
DIRECTORY = "output/qa/phase6/diagnostics/two-column-compact-v1"
PROJECTION_BINDING = {
    "path": DIRECTORY + "/staged-visual-v3-d629bce952153ea32c689ccb.json",
    "sha256": "sha256:d629bce952153ea32c689ccb5cea5f95d22faa6c3dad39111b0f0672e51acf32",
}
AMENDMENT_BINDING = {
    "path": DIRECTORY + "/visual-amendment-87567b59f9e67c4715b7a6a9.json",
    "sha256": "sha256:fb2543b0afb8ff696204c72fb40800bdf67e7e8459563909a5b8f31fb4ba8a5e",
}
SOURCE_BINDINGS = {
    "successor_recipe": {"path": DIRECTORY + "/recipe.py",
        "sha256": "sha256:51a6c8d4bab2d4c6d953861093d84cf6ec25ecc16d4ebba53abe335521ec033c"},
    "static_receipt": {"path": DIRECTORY + "/static-5d42a585eacde074510f8f61/receipt.json",
        "sha256": "sha256:cf6aeb64489e6846acd510e5d771ee87db504f1118bbac0262770acbd784737b"},
    "static_qa_reconciliation": {"path": DIRECTORY + "/reconciliation-677fe3df1aa79b65c14109b6.json",
        "sha256": "sha256:677fe3df1aa79b65c14109b691ffe3e78a372579cb85bd628e36bc32b53ff9b3"},
}
DECISION_REFERENCE_SCOPE = "HISTORICAL_BASE_ONLY_USE_EXPLICIT_AMENDMENT_FOR_SUCCESSOR"
RECIPE_ID = "heroverse-fact-forecast-two-column-v3-compact-proposal"
AUTHORITY = {key: False for key in (
    "active_plan", "source_admission", "quality_final_video", "timing", "render", "publication")}
EXPECTED = (
    ("visual-u010-s00", "BOTH", "", ""),
    ("visual-u011-s00", "LEFT", "", ""),
    ("visual-u011-s01", "LEFT", "What happened", ""),
    ("visual-u012-s00", "RIGHT", "What happened", ""),
    ("visual-u012-s01", "RIGHT", "What happened", "Feared meaning"),
    ("visual-u013-s00", "LEFT", "Meeting changed", ""),
    ("visual-u014-s00", "RIGHT", "Meeting changed", "Future ruined"),
    ("visual-u015-s00", "LEFT", "No reply yet", ""),
    ("visual-u016-s00", "RIGHT", "No reply yet", "Always abandoned"),
    ("visual-u016-s01", "RIGHT", "No reply yet", "Always abandoned"),
    ("visual-u017-s00", "BOTH", "No reply yet", "Always abandoned"),
    ("visual-u018-s00", "BOTH", "What happened", "Fear predicts"),
)


def _serialized(value):
    """Historical stager serialization, distinct from timeline canonical_sha."""
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def _content(focus, left, right):
    return {
        "composition_id": RECIPE_ID,
        "literal_copy": ["Fact", "Fear's forecast", *([left] if left else []), *([right] if right else [])],
        "description": f"Compact successor, not the historical exact raster: Fact remains left and Fear's forecast right; focus {focus}; left value {left!r}; right value {right!r}. No persistent title/footer inside this exercise, two text rows and reserved caption lane. A feared verdict is never an unattributed fact; preserve the original entry or HOLD without invented timing.",
    }


def _validate_layout(records, left, right):
    """Check the frozen column-major metadata, not generated glyph pixels."""
    wanted = [("LEFT", 437, "HEADER", "Fact", 64)]
    if left:
        wanted.append(("LEFT", 612, "VALUE", left, 64))
    wanted.append(("RIGHT", 437, "HEADER", "Fear's forecast", 64))
    if right:
        wanted.append(("RIGHT", 612, "VALUE", right, 64))
    actual, words = [], 0
    if not isinstance(records, list):
        raise ValueError("layout records must be a list")
    for block in records:
        if (not isinstance(block, dict) or set(block) != {"text", "bounds", "baseline_y", "size", "words"}
                or not isinstance(block["text"], str) or not isinstance(block["bounds"], list)
                or len(block["bounds"]) != 4 or any(type(number) is not int for number in block["bounds"])
                or any(type(block[key]) is not int for key in ("baseline_y", "size", "words"))):
            raise ValueError("layout metadata fields/types differ")
        x0, y0, x1, y1 = block["bounds"]
        side = {190: "LEFT", 1028: "RIGHT"}.get(x0)
        role = {437: "HEADER", 612: "VALUE"}.get(block["baseline_y"])
        count = len(re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", block["text"].lower()))
        if (side is None or role is None or not 87 <= y0 < y1 < 864
                or not x0 < x1 <= (892 if side == "LEFT" else 1730) or block["words"] != count):
            raise ValueError("layout column, caption lane or word metadata differs")
        words += count
        actual.append((side, block["baseline_y"], role, block["text"], block["size"]))
    _same(actual, wanted, "layout column/baseline/role/copy differs")
    if words > 8:
        raise ValueError("layout simultaneous words exceed eight")


def _validate_documents(projection, amendment, schema):
    # Closed local definitions only: no external schema resolver/network.
    # The old reader independently validates V2 with its unchanged schema.
    for name, value in (("projection", projection), ("amendment", amendment)):
        canonical_sha(value)  # Also rejects overflowed non-finite JSON numbers.
        Draft202012Validator({"$ref": "#/$defs/" + name, "$defs": schema["$defs"]}).validate(value)
        _same(value["authority"], AUTHORITY, "amendment cannot confer authority")
        if type(value["technical_cost_brl"]) is not int or value["technical_cost_brl"] != 0:
            raise ValueError("amendment cost must be exact integer zero")
        _same(value["base_plan"], PLAN_BINDING, "amendment base is not the frozen V2 plan")
        _same(value["historical_supplement"], EDITORIAL_SUPPLEMENT_BINDING,
              "amendment cannot replace the historical supplement")
    _same(projection["amendment"], AMENDMENT_BINDING, "projection amendment binding differs")
    for name, expected in SOURCE_BINDINGS.items():
        _same(amendment[name], expected, "amendment static provenance differs")
    if type(amendment["unmodified_states_count"]) is not int:
        raise ValueError("unchanged state count must be an exact integer")
    unsigned = {key: value for key, value in amendment.items() if key != "amendment_id"}
    if amendment["amendment_id"] != "visual-amendment-" + bytes_sha(_serialized(unsigned))[7:31]:
        raise ValueError("amendment identity does not recompose")


def read_amended_visual_intent(reader, binding, units, caption_proof):
    """Return the effective literal rows and intact base proof; no media admission.

    Only the externally frozen projection is supported. Neither a re-pinned
    candidate nor a serialized base proof authorizes a new amendment. The base
    inspection returned here is historical V2, generated in this same call.
    """
    _binding(binding)
    _same(binding, PROJECTION_BINDING, "only the exact externally frozen projection is supported")
    dependencies = {}

    def read(bound):
        _binding(bound)
        _resident(reader.root, bound["path"])
        raw = reader.read(bound["path"], bound["sha256"])
        item = {**copy.deepcopy(bound), "size_bytes": len(raw)}
        if bound["path"] in dependencies:
            _same(item, dependencies[bound["path"]], "amendment dependency identity changed")
        dependencies[bound["path"]] = item
        return raw

    code_root = Path(__file__).resolve().parents[1]
    implementation, code_bytes = [], {}
    for name in ("hero_engine/phase6_av_visual_amendment.py", SCHEMA):
        _resident(code_root, name)
        raw = (code_root / name).read_bytes()
        code_bytes[name] = raw
        implementation.append({"path": name, "sha256": bytes_sha(raw), "size_bytes": len(raw)})
    schema = _json(code_bytes[SCHEMA])
    projection = _json(read(binding))
    amendment = _json(read(AMENDMENT_BINDING))
    _validate_documents(projection, amendment, schema)
    # The independently validated base is invoked once, never supplied as an
    # external assertion or modified to accept the successor's visual wording.
    base = read_visual_intent(reader, PLAN_BINDING, units, caption_proof)
    for item in base["dependency_bindings"]:
        dependencies[item["path"]] = copy.deepcopy(item)
    implementation = [*copy.deepcopy(base["implementation_dependencies"]), *implementation]
    supplement = _json(read(EDITORIAL_SUPPLEMENT_BINDING))
    _same(amendment["historical_decisions"], supplement["rows"], "historical D169/supplement decisions changed")
    read(SOURCE_BINDINGS["successor_recipe"])  # Bytes only; never import/execute.
    receipt = _json(read(SOURCE_BINDINGS["static_receipt"]))
    qa = _json(read(SOURCE_BINDINGS["static_qa_reconciliation"]))
    design = receipt["design"]
    _same(design["authority"], {key: False for key in (
        "production", "render_av", "quality", "rights", "timing", "publication")}, "static design authority differs")
    _same(qa["authority"], {key: False for key in (
        "production", "final_quality", "rights", "timing", "publication")}, "static QA authority differs")
    if (receipt["runner_sha256"] != SOURCE_BINDINGS["successor_recipe"]["sha256"][7:]
            or design["recipe_id"] != RECIPE_ID or type(design["technical_cost_brl"]) is not int
            or design["technical_cost_brl"] != 0 or qa["status"] != "PASS_STATIC_SCOPE_ONLY"
            or qa["source_receipt_sha256"] != SOURCE_BINDINGS["static_receipt"]["sha256"][7:]):
        raise ValueError("static historical scope or lineage differs")
    ids = [row[0] for row in EXPECTED]
    for values in (amendment["amendments"], design["states"], qa["states"]):
        if [row["state_id"] for row in values] != ids:
            raise ValueError("exact ordered twelve-state amendment required")
    folder = Path(SOURCE_BINDINGS["static_receipt"]["path"]).parent
    wanted_files = {sid + suffix for sid in ids for suffix in (".png", ".svg")} | {"layouts.json"}
    if set(receipt["artifact_sha256"]) != wanted_files:
        raise ValueError("static artifact inventory must contain the exact 25 files")
    if {path.name for path in (reader.root / folder).iterdir()} != wanted_files | {"receipt.json"}:
        raise ValueError("static physical inventory differs")
    artifacts = {}
    for name in sorted(wanted_files):
        bound = {"path": (folder / name).as_posix(), "sha256": "sha256:" + receipt["artifact_sha256"][name]}
        artifacts[name] = read(bound)
    layouts = _json(artifacts["layouts.json"])
    if set(layouts) != set(ids):
        raise ValueError("static layouts omit or add states")
    effective = copy.deepcopy(base["rows"])
    before = {state["state_id"]: (row, state) for row in base["rows"] for state in row["states"]}
    after = {state["state_id"]: state for row in effective for state in row["states"]}
    for expected, change, static, measured in zip(EXPECTED, amendment["amendments"], design["states"], qa["states"], strict=True):
        sid, focus, left, right = expected
        row, old = before[sid]
        content = _content(focus, left, right)
        wanted_change = {
            "state_id": sid, "unit_id": row["unit_id"],
            "before_visual_content": old["visual_content"], "after_visual_content": content,
            "preserved_entry": old["entry"],
            "static_source": {"path": (folder / (sid + ".png")).as_posix(),
                "sha256": "sha256:" + receipt["artifact_sha256"][sid + ".png"],
                "source_frame_interval": [0, 1], "media_kind": "STATIC_IMAGE"},
            "historical_exact_wording_is_not_pixel_equivalence": True,
        }
        _same(change, wanted_change, "amendment mapping/copy/entry/source differs")
        _same(static["original_state"], old, "static source original state differs")
        _same(static["entry"], old["entry"], "static source entry differs")
        _same(static["all_visible_copy"], content["literal_copy"], "static visible copy differs")
        if (static["unit_id"] != row["unit_id"] or static["unit_text"] != row["text"]
                or static["focus"] != focus or static["left"] != left or static["right"] != right
                or static["observed_sample"] is not None or static["video_frame"] is not None
                or measured["png_sha256"] != receipt["artifact_sha256"][sid + ".png"]
                or measured["ocr_recomposed"]["status"] != "PASS"
                or measured["focus_profile"]["status"] != "PASS_FOCUS_INTERIOR_ONLY"):
            raise ValueError("static copy, sample or historical evidence association differs")
        _validate_layout(layouts[sid], left, right)
        after[sid]["visual_content"] = content
    if artifacts["visual-u016-s00.png"] != artifacts["visual-u016-s01.png"]:
        raise ValueError("HOLD physical PNG bytes differ")
    unchanged = [state for row in base["rows"] for state in row["states"] if state["state_id"] not in ids]
    digest = bytes_sha(_serialized(unchanged))[7:]
    if (len(unchanged) != 88 or amendment["unmodified_states_sha256"] != digest
            or design["unmodified_states_sha256"] != digest):
        raise ValueError("88 unchanged historical states do not recompose")
    _same(amendment["affected_unit_ids"], [f"narration-unit-{index:03d}" for index in range(10, 19)],
          "amendment affected unit identity differs")
    _same(projection["effective_rows"], effective, "projection changes more than the twelve explicit visual contents")
    seen, lexical = set(), []
    for row in effective:
        lexical.extend(_state_entries(row, seen))
    _same(lexical, base["visual_lexical_ranges"], "amendment changes literal temporal population")
    # Explicitly keep old evidence separate from the effective literal result.
    result = {**copy.deepcopy(base), "adapter_version": VERSION,
        "status": "LITERAL_AMENDMENT_IDENTIFIED_SOURCES_AND_TIMING_PENDING",
        "source_binding": copy.deepcopy(binding), "rows": effective,
        "base_plan_binding": copy.deepcopy(PLAN_BINDING), "amendment_binding": copy.deepcopy(AMENDMENT_BINDING),
        "base_inspection": copy.deepcopy(base), "base_inspection_sha256": canonical_sha(base),
        "effective_rows_sha256": canonical_sha(effective), "decision_reference_scope": DECISION_REFERENCE_SCOPE,
        "changed_state_count": 12, "unmodified_state_count": 88,
        "static_proof_scope": "HASH_BOUND_STATIC_PROVENANCE_ONLY_NO_QA_REEXECUTION",
        "implementation_dependencies": implementation,
        "limitations": [*base["limitations"],
            "V2 exact/existing wording and decision references remain historical; the explicit amendment alone supplies successor copy.",
            "PNG/SVG/layout bytes are bound, not decoded here; historical static QA and its runtime are not reexecuted or promoted.",
            "No source use, rights, temporal scheduling, A admission or final-video quality is authorized."]}
    for item in list(dependencies.values()):
        read({key: item[key] for key in ("path", "sha256")})
    if {path.name for path in (reader.root / folder).iterdir()} != wanted_files | {"receipt.json"}:
        raise ValueError("static physical inventory changed during inspection")
    for item in implementation:
        _resident(code_root, item["path"])
        raw = (code_root / item["path"]).read_bytes()
        if bytes_sha(raw) != item["sha256"] or len(raw) != item["size_bytes"]:
            raise ValueError("amendment implementation changed during inspection")
    result["dependency_bindings"] = sorted(dependencies.values(), key=lambda item: item["path"])
    return result
