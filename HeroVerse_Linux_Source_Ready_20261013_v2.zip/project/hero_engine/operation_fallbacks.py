"""Read-only, evidence-bound recovery coverage; never a release authorizer.

The actual executors own retries and effects. This view deliberately distinguishes
recovery of identical work from provider replacement and from simply waiting.
Source presence is NOT a passing test or proof that a fallback was used live.
"""
from __future__ import annotations

import ast
import hashlib
import json
import stat
from collections import Counter
from pathlib import Path
from typing import Any

VERSION = "operation-fallback-coverage-v1"
KINDS = ("PROVIDER_SWITCH", "EXACT_CACHE_REPLAY", "CHECKPOINT_RECOVERY", "RETRY_SAME_PROVIDER", "DEFER", "BLOCKED")


def _route(identifier: str, domain: str, kind: str, handler: str, trigger: str,
           recovery: str, limit: str, gap: str, *, phase: int = 6) -> dict[str, Any]:
    return dict(route_id=identifier, domain=domain, kind=kind, handler=handler,
                trigger=trigger, recovery=recovery, limit=limit, gap=gap, phase=phase)


# Curated links to real executors, not dynamically imported/called by the panel.
# Limits describe the executor's contract; they do not create new authority.
ROUTES = (
    _route("oauth-refresh", "AUTHENTICATION", "CHECKPOINT_RECOVERY",
           "hero_engine/oauth_refresh_proof.py:prove_noninteractive_refresh",
           "Access token expired; isolated refresh token and exact channel available.",
           "Refresh through the official provider, validate identity and atomically preserve token.",
           "No automated personal login/consent; revoked or absent refresh requires owner action.",
           "No substitute provider can authorize the YouTube channel."),
    _route("mining-cache", "MINING", "EXACT_CACHE_REPLAY",
           "hero_engine/mining/pipeline.py:_cache_valid",
           "The Phase 2 fixture miner encounters an existing completed cache for its exact input/configuration.",
           "Check inventory through the fixture cache validator before considering reuse.",
           "This is not a live market-mining provider or a fresh market observation; no new rights.",
           "Partial jobs lack a proven recovery contract and stay preserved/blocked; no alternate ASR/OCR validated."),
    _route("asset-download", "ASSET_ACQUISITION", "RETRY_SAME_PROVIDER",
           "hero_engine/asset_library_phase5.py:build_and_download_asset_library",
           "Approved Commons asset transfer fails transiently.",
           "Bounded retry and partial download before final local replacement.",
           "At most four attempts; Retry-After seconds/date respected; 30s cumulative local waits per logical request; otherwise DEFER.",
           "DEFER stops this build only; no persistent cross-process cooldown or alternate provider."),
    _route("asset-residency", "ASSET_ACQUISITION", "BLOCKED",
           "hero_engine/phase6_asset_residency.py:run_phase6_asset_residency_audit",
           "Asset is missing, nonresident, linked, divergent or lacks usable safe capacity.",
           "Reject allocation and continue independent observation stages.",
           "Never download/relabel a substitute as the same asset or skip rights/publicity.",
           "Alternate asset requires a new evidence-bound selection and quality review."),
    _route("creative-selection", "CREATIVE_DIRECTION", "BLOCKED",
           "hero_engine/phase6_creative_compiler.py:select_creative_concept",
           "No eligible, sufficiently distinct, evidence-bound creative route wins.",
           "Keep the frozen experiment/ChannelDNA and reject this production entry.",
           "No universal template or silent hook/body/FormatPack substitution.",
           "Changing creative route is a new decision, not transparent technical failover."),
    _route("voice-dependency", "VOICE", "CHECKPOINT_RECOVERY",
           "hero_engine/production_capacity.py:run_phase6_capacity_preflight",
           "Preferred local eSpeak dependency location is not usable.",
           "Probe the allowlisted local dependency candidates and bind exact library/data hashes.",
           "Preserve the Kokoro model, voice identity and speed; dependency path is not a new voice.",
           "No second production voice is validated for the current frozen narration."),
    _route("segment-cache", "VIDEO_RENDER", "EXACT_CACHE_REPLAY",
           "hero_engine/phase6_media.py:render_video2",
           "Segment exists but its mutable cache pointer is missing.",
           "Recover only from the exact immutable recipe anchor/receipt and current source/output hashes.",
           "Divergence blocks before FFmpeg overwrite; no render or gate approval from recovery alone.",
           "Legacy per-take renderer is not the unfinished continuous-narration AV successor."),
    _route("media-checkpoint", "VIDEO_RENDER", "CHECKPOINT_RECOVERY",
           "hero_engine/phase6_media_recovery.py:recover_phase6_media_dead_letter",
           "Exact failed media job has independently verified repair evidence.",
           "Issue the bounded recovery receipt for the same transactional job.",
           "One additional local retry; never reopen a succeeded job or silently replace its assets.",
           "A visual/semantic defect still needs a new allowed correction and all quality gates."),
    _route("audio-measurement-cache", "AUDIO_QA", "EXACT_CACHE_REPLAY",
           "hero_engine/audio_perception_supervisor.py:verify_cached",
           "Independent auxiliary measurement already has complete pinned evidence.",
           "Read-only revalidation before any new local inference.",
           "Auxiliary measurement only; no human-gold, pronunciation or audiovisual approval claim.",
           "Supervisor is tested separately; not yet deployed as the final AV audio gate."),
    _route("quality-fail-closed", "VIDEO_QA", "BLOCKED",
           "hero_engine/phase6_quality.py:run_phase6_quality_executor",
           "Any critical gate is failed, unavailable or ambiguous.",
           "Persist decision and withhold publication; other eligible stages continue.",
           "No model vote, mean score or cached PASS can replace proof for changed bytes.",
           "No equivalent calibrated alternate motion/perceptual evaluator is ready."),
    _route("storage-capacity", "LOCAL_CAPACITY", "DEFER",
           "hero_engine/production_capacity.py:run_phase6_capacity_preflight",
           "Available disk, resident assets or local dependency capability is insufficient.",
           "Stop this production before effects and preserve the checkpoint.",
           "No cloud billing, automatic broad cleanup, lower quality or unbounded processing.",
           "Waiting for capacity is not an alternate compute provider."),
    _route("atomic-storage", "PERSISTENCE", "RETRY_SAME_PROVIDER",
           "hero_engine/atomic_io.py:atomic_write_utf8",
           "Windows temporarily denies atomic replacement of a complete temporary file.",
           "Retry replacement of only the writer-owned file while preserving the old target.",
           "Six attempts, five bounded waits; other OS errors are not blindly retried.",
           "No full-disk or physical-drive failover; independent backups remain necessary."),
    _route("queue-lease", "ORCHESTRATION", "CHECKPOINT_RECOVERY",
           "hero_engine/queue_phase6.py:TransactionalQueue",
           "Worker exits or a verifiably owned lease expires.",
           "Resume through transactional state, idempotency key and persisted checkpoints.",
           "Preserve terminal jobs and external effect receipts; use explicit recovery contracts.",
           "Queue heartbeat cannot terminate an arbitrary hung third-party native call."),
    _route("maintenance-recovery", "ORCHESTRATION", "CHECKPOINT_RECOVERY",
           "scripts/daily.ps1:<SCRIPT>",
           "Scoped maintenance finishes or a regression test fails.",
           "D116 protocol restores the verified manager chain and proves a fresh ordered cycle.",
           "Stop exact PID/start/lock chain only; finally recovery; no fabricated 12-stage PASS.",
           "Host shutdown or absence of the scheduled task is an external availability limit."),
    _route("publication-resume", "PUBLICATION", "CHECKPOINT_RECOVERY",
           "hero_engine/phase6_publication.py:run_phase6_publication_controller",
           "Interrupted or ambiguous private-first upload/publication has an effect journal.",
           "Reconcile the same YouTube video ID and resume the pending exact effect.",
           "Never create another video on an ambiguous response; no blind mutation retries.",
           "Some publication service calls still lack the shared read-stage deadline."),
    _route("packaging-rollback", "CHANNEL_PACKAGING", "CHECKPOINT_RECOVERY",
           "hero_engine/phase6_package_treatment.py:execute_public_package_update",
           "Authorized preregistered title-thumbnail pair fails API/CDN confirmation.",
           "Restore both original public fields from the frozen rollback package.",
           "Same video and pair; reserve quota; no invented replacement title or thumbnail.",
           "Rollback depends on functioning official write access; it is not guaranteed during outage."),
    _route("official-channel-read", "ANALYTICS", "RETRY_SAME_PROVIDER",
           "hero_engine/phase6_channel_goal_observer.py:run_daily_channel_goal_observer",
           "Official daily channel observation times out or fails transiently.",
           "Shared bounded transport deadline, persisted retry and exact official-source cache reuse.",
           "One reserved unit/attempt; retry 30 min, at most six hours/12 slots; hidden counts stay null.",
           "Public estimates never replace private YPP progress or missing official subscribers."),
    _route("learning-checkpoint", "LEARNING", "CHECKPOINT_RECOVERY",
           "hero_engine/phase6_learning_runtime.py:run_phase6_learning_observer",
           "Reporting data is delayed or a checkpointed evaluation is interrupted.",
           "Reopen pinned snapshots and protocol; schedule the next eligible observation.",
           "No fabricated outcome; no change of experiment variable or population on retry.",
           "Phase 7 rule promotion/application remains gated; observation alone is not learned improvement."),
    _route("quota-floor", "ZERO_COST", "DEFER",
           "hero_engine/zero_cost_guard.py:evaluate_zero_cost",
           "Observed free quota is unknown or would cross its preventive floor.",
           "Block the external call before debit; preserve work for the next legitimate window.",
           "R$0 technical cost; never enable billing or label a declared fallback as an executor.",
           "YouTube official operations have no interchangeable provider; defer is not provider switching."),
    _route("codex-reserve", "DEVELOPMENT_CAPACITY", "DEFER",
           "hero_engine/codex_usage_governance.py:materialize_observation",
           "Official account observation reaches the reserve or needs a real renewal rebase.",
           "Preserve quality/checkpoints and local operation; prioritize authorized critical work.",
           "No unapproved reset, purchase, weaker model, duplicate polling or infinite-credit claim.",
           "Local operational continuity does not imply unlimited development-agent capacity."),
)


def _source(root: Path, handler: str) -> dict[str, Any]:
    relative, symbol = handler.split(":", 1)
    path = root / relative
    value = {"path": relative, "symbol": symbol, "sha256": None, "status": "UNAVAILABLE"}
    try:
        if path.resolve() != path.absolute() or not path.resolve().is_relative_to(root):
            raise ValueError("linked source")
        for item in (path, *path.parents):
            if item == root:
                break
            info = item.lstat()
            if getattr(info, "st_file_attributes", 0) & (0x400 | 0x1000 | 0x40000 | 0x400000):
                raise ValueError("nonresident or reparse source")
        info = path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > 2_000_000:
            raise ValueError("source is not bounded regular text")
        data = path.read_bytes()
        value["sha256"] = hashlib.sha256(data).hexdigest()
        if path.suffix == ".ps1" and symbol == "<SCRIPT>":
            data.decode("utf-8-sig")
            value["status"] = "SOURCE_BOUND_NOT_EXECUTION_PROOF"
            return value
        tree = ast.parse(data.decode("utf-8-sig"))
        value["status"] = ("SOURCE_BOUND_NOT_EXECUTION_PROOF"
                           if any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                                  and n.name == symbol for n in tree.body)
                           else "HANDLER_NOT_FOUND")
    except (OSError, ValueError, UnicodeError, SyntaxError):
        pass
    return value


def build_coverage(root: Path, *, active_phase: int = 6) -> dict[str, Any]:
    """Inspect bounded source files only: no subprocess, API, model or state write."""
    root = root.resolve()
    if type(active_phase) is not int or active_phase not in (5, 6, 7, 8):
        raise ValueError("unsupported active phase")
    rows = []
    for recipe in ROUTES:
        row = {**recipe, "source": _source(root, recipe["handler"])}
        row["implementation_state"] = (
            "OUT_OF_ACTIVE_PHASE" if recipe["phase"] > active_phase else
            "SOURCE_BOUND_NOT_EXECUTION_PROOF" if row["source"]["status"] == "SOURCE_BOUND_NOT_EXECUTION_PROOF"
            else "UNAVAILABLE"
        )
        row["validation_state"] = "NOT_ATTESTED_BY_THIS_VIEW"
        row["technical_cost_brl"] = 0
        rows.append(row)
    counts = Counter(row["kind"] for row in rows)
    payload = {
        "version": VERSION, "active_phase": active_phase, "status": "COVERAGE_GAPS",
        "route_count": len(rows), "domain_count": len({r["domain"] for r in rows}),
        "kind_counts": {kind: counts[kind] for kind in KINDS},
        "source_bound_count": sum(r["implementation_state"] == "SOURCE_BOUND_NOT_EXECUTION_PROOF" for r in rows),
        "validated_provider_switch_count": 0,
        "publication_authorized": False, "technical_cost_brl": 0,
        "routes": rows,
        "claim_boundary": "Source hashes bind the coverage description, not test success, current runtime capability, observed recovery or release permission. DEFER/BLOCKED are not functional recovery. Each executor retains its own gates, evidence and quota. No equivalent alternate provider is claimed validated.",
    }
    payload["coverage_sha256"] = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return payload


def markdown_coverage(value: dict[str, Any]) -> list[str]:
    lines = ["## Fallbacks por toda a operação", "",
             f"{value['domain_count']} domínios / {value['route_count']} rotas mapeadas; {value['source_bound_count']} com handler localizado e hash. **Isto não é contagem de testes aprovados.**", "",
             "Troca equivalente de fornecedor validada: **0**. Espera e bloqueio não são recuperação funcional. As lacunas abaixo permanecem explícitas.", "",
             "| Domínio | Mecanismo | Implementação observada | Limite / lacuna |",
             "|---|---|---|---|"]
    for row in value["routes"]:
        lines.append(f"| {row['domain']} | {row['kind']} | {row['implementation_state']} | {row['limit']} {row['gap']} |")
    lines.extend(["", "Custo técnico obrigatório: R$ 0,00. Nenhum fallback aprova mídia, troca a identidade ou dispensa um gate crítico.", ""])
    return lines
