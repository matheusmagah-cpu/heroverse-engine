"""Explicit, non-authoritative validation plan for the current Phase 6 path.

The historical A9 replay cannot be reproduced because one pinned source byte is
absent.  This module does not hide that fact with ``skip`` or a global reader
fallback.  Instead it creates a small, separately labelled plan for the
currently active visual consumer.  It is deliberately *not* an application
regression proof: callers must not pass its output to ``apply-paused``.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .phase6_forward_only_boundary import HISTORICAL_GAPS, build_forward_only_boundary
from .maintenance_unittest_result import verify_unittest_result

VERSION = "phase6-forward-only-regression-plan-v1"

# These test ids exercise only current, versioned code and the current visual
# preflight.  Historical replay suites are intentionally absent; their absence
# is explained by HISTORICAL_GAPS rather than represented as unittest skips.
CURRENT_TEST_PREFIXES = (
    "tests.test_phase5_integrity_maintenance.",
    "tests.test_phase5_integrity_successor_proof.",
    "tests.test_phase5_integrity_successor_consumer.",
    "tests.test_phase6_integrity_successor_input_gate.",
    "tests.test_phase6_caption_intent_v3.",
    "tests.test_phase6_forward_only_boundary.",
    "tests.test_phase6_visual_preflight.",
    "tests.test_phase6_av_visual_recipe_adapter.Phase6AVVisualRecipeActiveConsumerTests.",
)


def _canonical(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def build_forward_only_validation_plan(root: Path, inventory: dict[str, Any]) -> dict[str, Any]:
    """Bind a current-only focal plan to an already-authenticated inventory.

    The inventory is supplied by the existing maintenance producer.  We never
    discover/import a test module here, and every selected id must be present
    in that immutable inventory.  A plan with an unclassified exclusion is
    rejected by construction: it has no authority and identifies its sole
    historical gap explicitly.
    """
    root = Path(root).resolve(strict=True)
    if inventory.get("schema_version") != "1.1.0":
        raise ValueError("forward-only plan requires the current authenticated inventory schema")
    files = inventory.get("files")
    if not isinstance(files, list):
        raise ValueError("forward-only plan inventory has no files")
    available = [test_id for item in files for test_id in item.get("test_ids", [])]
    if len(available) != len(set(available)):
        raise ValueError("forward-only plan inventory has duplicate test identities")
    selected = [test_id for test_id in available if test_id.startswith(CURRENT_TEST_PREFIXES)]
    if not selected:
        raise ValueError("forward-only plan selected no current tests")
    if any(test_id not in available for test_id in selected):
        raise ValueError("forward-only plan selected an uninventoried test")
    boundary = build_forward_only_boundary(root)
    value = {
        "version": VERSION,
        "candidate": boundary["candidate"],
        "boundary_sha256": boundary["boundary_sha256"],
        "inventory_schema_version": inventory["schema_version"],
        "inventory_identity_sha256": _canonical(inventory),
        "selected_test_ids": selected,
        "historical_gaps": list(HISTORICAL_GAPS),
        "authority": {
            "application_regression": False,
            "apply_authorized": False,
            "render_authorized": False,
            "publication_authorized": False,
        },
    }
    value["plan_sha256"] = _canonical(value)
    return value


def build_forward_only_inventory(root: Path, inventory: dict[str, Any]) -> dict[str, Any]:
    """Derive a verifier-compatible inventory for the explicit current plan.

    This is not a filtered discovery command: the selected identities are
    derived from the fixed prefixes above and the full source-hashed inventory
    supplied by the maintenance producer.  The result has a distinct schema
    and purpose so it cannot be confused with an installation regression.
    """
    plan = build_forward_only_validation_plan(root, inventory)
    selected = set(plan["selected_test_ids"])
    files = []
    for item in inventory["files"]:
        ids = [test_id for test_id in item["test_ids"] if test_id in selected]
        if ids:
            files.append({"path": item["path"], "content_hash": item["content_hash"], "test_ids": ids})
    selected_ids = [test_id for item in files for test_id in item["test_ids"]]
    if set(selected_ids) != selected or len(selected_ids) != len(selected):
        raise ValueError("forward-only inventory lost or duplicated a selected identity")
    # No selected file declares load_tests.  If that changes, this contract
    # must be versioned rather than silently omitting executable aliases.
    if any(item["path"] == "tests/test_maintenance_abandoned_request.py" for item in files):
        raise ValueError("forward-only inventory requires an explicit alias contract revision")
    result = {
        "schema_version": "1.1.0",
        "discovery_pattern": "EXPLICIT_FORWARD_ONLY_CURRENT_CONSUMERS_V1",
        "file_count": len(files),
        "method_count": len(selected_ids),
        "alias_count": 0,
        "test_count": len(selected_ids),
        "tests_hash": _canonical(selected_ids),
        "load_tests_aliases": [],
        "aliases_hash": _canonical([]),
        "files": files,
        "forward_only_plan_sha256": plan["plan_sha256"],
        "authority": plan["authority"],
    }
    result["inventory_sha256"] = _canonical(result)
    return result


def verify_forward_only_result(*, root: Path, full_inventory: dict[str, Any], plan: dict[str, Any],
                               inventory: dict[str, Any], stdout_bytes: bytes, stderr_bytes: bytes,
                               process_exit_code: int) -> dict[str, Any]:
    """Verify a real focal transcript without granting maintenance authority."""
    expected_plan = verify_forward_only_validation_plan(root, full_inventory, plan)
    expected_inventory = build_forward_only_inventory(root, full_inventory)
    if _canonical(inventory) != _canonical(expected_inventory):
        raise ValueError("forward-only execution inventory differs from the fixed current plan")
    # The generic parser rejects the extra forward-only metadata; pass only its
    # native schema fields, then bind that result back to this plan.
    parser_inventory = {key: inventory[key] for key in (
        "schema_version", "discovery_pattern", "file_count", "method_count", "alias_count", "test_count",
        "tests_hash", "load_tests_aliases", "aliases_hash", "files",
    )}
    verified = verify_unittest_result(
        inventory=parser_inventory, stdout_bytes=stdout_bytes, stderr_bytes=stderr_bytes,
        process_exit_code=process_exit_code,
    )
    return {
        "status": "PASS_FORWARD_ONLY_CURRENT_CONSUMERS",
        "candidate": expected_plan["candidate"],
        "plan_sha256": expected_plan["plan_sha256"],
        "inventory_sha256": inventory["inventory_sha256"],
        "test_count": verified["test_count"],
        "skipped_count": verified["skipped_count"],
        "historical_gaps": expected_plan["historical_gaps"],
        "authority": expected_plan["authority"],
    }


def verify_forward_only_validation_plan(root: Path, inventory: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    expected = build_forward_only_validation_plan(root, inventory)
    if _canonical(candidate) != _canonical(expected):
        raise ValueError("forward-only validation plan differs from current authenticated state")
    if candidate["authority"]["application_regression"]:
        raise ValueError("forward-only validation plan cannot become an application proof")
    return expected
