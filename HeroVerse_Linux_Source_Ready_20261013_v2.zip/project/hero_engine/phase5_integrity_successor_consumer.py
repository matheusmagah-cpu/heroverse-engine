"""Read the committed Phase 5 integrity successor without rewriting history.

The original manifest remains a historical receipt.  A current consumer must
select the committed successor explicitly and validate both its historical
preimage and the resident package before trusting it.  This reader grants no
render, publication, or restart authority.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .phase5_integrity_maintenance import (
    HISTORICAL_NAME, PACKAGE, SUCCESSOR_VERSION, _canonical, _entries, _sha,
)

SUCCESSOR_NAME = "integrity_manifest_successor.json"


class IntegritySuccessorConsumerError(ValueError):
    pass


def read_current_integrity_successor(root: Path) -> dict[str, Any]:
    """Return only an exact committed successor bound to immutable history."""
    root = Path(root).resolve(strict=True)
    package = root / PACKAGE
    historical = package / HISTORICAL_NAME
    successor = package / SUCCESSOR_NAME
    if not historical.is_file() or not successor.is_file():
        raise IntegritySuccessorConsumerError("integrity successor is not committed")
    historical_raw = historical.read_bytes()
    try:
        value = json.loads(successor.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise IntegritySuccessorConsumerError("integrity successor is invalid JSON") from exc
    if not isinstance(value, dict) or value.get("version") != SUCCESSOR_VERSION or value.get("status") != "STAGED_NOT_COMMITTED":
        raise IntegritySuccessorConsumerError("integrity successor contract differs")
    expected = dict(value); successor_hash = expected.pop("successor_sha256", None)
    if successor_hash != _sha(_canonical(expected).encode("utf-8")):
        raise IntegritySuccessorConsumerError("integrity successor canonical hash differs")
    historical_pin = value.get("historical_manifest", {})
    if historical_pin != {"path": (PACKAGE / HISTORICAL_NAME).as_posix(), "sha256": _sha(historical_raw), "size_bytes": len(historical_raw)}:
        raise IntegritySuccessorConsumerError("integrity successor historical preimage differs")
    resident = value.get("resident_package", {})
    if resident.get("path") != PACKAGE.as_posix() or resident.get("entries") != _entries(package):
        raise IntegritySuccessorConsumerError("integrity successor resident package differs")
    authority = value.get("authority")
    if authority != {"commit": False, "publication": False}:
        raise IntegritySuccessorConsumerError("integrity successor authority differs")
    return {"version": "phase5-integrity-successor-consumer-v1", "source": SUCCESSOR_NAME,
            "successor_sha256": successor_hash, "entries": resident["entries"],
            "authority": {"render": False, "publication": False, "restart": False}}
