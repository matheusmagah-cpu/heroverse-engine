from __future__ import annotations

import hashlib
import re
from collections import Counter
from datetime import datetime, timezone
from typing import Any


def _normalized_title(value: str) -> str:
    value = re.sub(r"#[\w-]+", "", value.lower())
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def build_legacy_catalog_audit(snapshot: dict[str, Any], *, created_at: str | None = None) -> dict[str, Any]:
    created = created_at or datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    videos = snapshot["catalog"]["public_videos"]
    normalized = [_normalized_title(item["title"]) for item in videos]
    counts = Counter(normalized)
    performance = {item.get("video"): item for item in snapshot["analytics_90d"]["public_video_rows"]}
    sensational_terms = ["prophecy", "what they are hiding", "too late", "secret", "nobody understands"]
    legacy_identity_terms = ["#marvel", "#theflash", "superhero", "movie shorts", "ai generated"]
    records = []
    for video in videos:
        title_lower = video["title"].lower()
        duplicate = counts[_normalized_title(video["title"])] > 1
        claim_terms = [term for term in sensational_terms if term in title_lower]
        legacy_terms = [term for term in legacy_identity_terms if term in title_lower]
        hashtag_count = len(re.findall(r"#[\w-]+", video["title"]))
        score = (4 if duplicate else 0) + (3 * len(claim_terms)) + (4 * len(legacy_terms)) + (2 if hashtag_count >= 4 else 0)
        observed = performance.get(video["video_id"], {})
        records.append({
            "video_id": video["video_id"],
            "title": video["title"],
            "published_at": video["published_at"],
            "duration_seconds": video["duration_seconds"],
            "public_views_api": video["views"],
            "analytics_views_90d": observed.get("views"),
            "analytics_average_view_percentage_90d": observed.get("averageViewPercentage"),
            "packaging_flags": {
                "normalized_duplicate": duplicate,
                "sensational_claim_terms": claim_terms,
                "legacy_identity_terms": legacy_terms,
                "hashtags_in_title": hashtag_count,
            },
            "rights_evidence": "UNAVAILABLE",
            "substantive_originality_evidence": "UNAVAILABLE",
            "review_priority_score": score,
            "status": "BLOCKED_PENDING_EDITORIAL_RIGHTS_REVIEW",
            "required_evidence": [
                "asset-level source and rights record",
                "timecoded proof of original narration/commentary",
                "timecoded proof of substantive narrative transformation",
                "thumbnail/title promise-to-content match",
                "reused-content and repetitive-template review",
            ],
        })
    records.sort(key=lambda item: (-item["review_priority_score"], item["public_views_api"], item["video_id"]))
    return {
        "schema_version": "1.0.0",
        "audit_id": "legacy-catalog-" + hashlib.sha256((snapshot["snapshot_id"] + created).encode()).hexdigest()[:16],
        "channel_id": snapshot["channel_id"],
        "snapshot_ref": "output/audits/channel/heroverse/channel-snapshot.json",
        "created_at": created,
        "scope": "PUBLIC_LEGACY_CATALOG_METADATA_AND_PRIVATE_90D_ANALYTICS",
        "summary": {
            "public_videos": len(records),
            "videos_approved": 0,
            "videos_blocked_pending_review": len(records),
            "duplicate_packaging_count": sum(1 for item in records if item["packaging_flags"]["normalized_duplicate"]),
            "sensational_claim_count": sum(1 for item in records if item["packaging_flags"]["sensational_claim_terms"]),
            "legacy_identity_count": sum(1 for item in records if item["packaging_flags"]["legacy_identity_terms"]),
            "unlisted_upload_count_observed": snapshot["catalog"]["privacy_counts_in_uploads_playlist"].get("unlisted", 0),
        },
        "records": records,
        "decision": "NO_AUTOMATIC_UNLIST_DELETE_OR_YPP_APPROVAL",
        "reason": "Metadata and performance do not prove rights or substantive transformation. Each legacy public video requires evidence-based editorial review before YPP application.",
        "external_cost_usd": 0,
    }
