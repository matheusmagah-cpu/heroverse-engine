from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[1]
BASE = Path("output/operations/phase6/control-cycle")
STAGES: tuple[dict[str, Any], ...] = (
    {"stage": "OWNED_OBSERVER", "path": "output/operations/phase6/observer-status.json", "schema": "phase6_observer_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "latest_snapshot", "next_observation_at", "error"]},
    {"stage": "PREDICTION_OUTCOME", "path": "output/operations/phase6/intelligence/prediction-runtime.json", "schema": "phase6_prediction_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "prediction_id", "job_id", "job_state", "outcome_snapshot", "outcome_snapshot_hash", "outcome_snapshot_schema", "evaluation", "error"]},
    {"stage": "TREATMENT_COMPILER", "path": "output/operations/phase6/production/executor-status.json", "schema": "phase6_treatment_executor_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "order_id", "order_status", "job_id", "job_state", "receipt", "error"]},
    {"stage": "RELEASE_PREPARER", "path": "output/operations/phase6/release/preparer-status.json", "schema": "phase6_release_preparer_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "work_order_id", "work_order_status", "action", "job_id", "job_state", "receipt", "error"]},
    {"stage": "PACKAGE_TREATMENT", "path": "output/operations/phase6/package-treatment-executor-status.json", "schema": "phase6_package_executor_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "protocol_id", "candidate", "quality_evaluation", "release_gate", "publication_receipt", "error"]},
    {"stage": "MEDIA", "path": "output/operations/phase6/media-executor-status.json", "schema": "phase6_media_executor_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "input_receipt_id", "action", "job_id", "job_state", "voice_manifest", "render_manifest", "error"]},
    {"stage": "QUALITY", "path": "output/operations/phase6/quality-executor-status.json", "schema": "phase6_quality_executor_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "media_render_id", "job_id", "job_state", "evaluation", "decision", "publication_eligible", "error"]},
    {"stage": "PUBLICATION", "path": "output/operations/phase6/publication-controller-status.json", "schema": "phase6_publication_controller_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "quality_evaluation_id", "package", "release", "release_decision", "publication_receipt", "youtube_video_id", "privacy_status", "error"]},
    {"stage": "LEARNING", "path": "output/operations/phase6/intelligence/learning-runtime.json", "schema": "phase6_learning_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "protocol_id", "treatment_variable", "target_video_id", "job_id", "job_state", "evaluation", "classification", "error"]},
    {"stage": "GOAL_TRAJECTORY", "path": "output/operations/phase6/goal-trajectory/latest.json", "schema": "phase6_goal_trajectory.schema.json", "time_field": "evaluated_at", "identity_fields": ["trajectory_id", "substantive_signature", "technical_cost_brl"]},
    {"stage": "PHASE_TRANSITION", "path": "output/operations/phase6/phase-transition-runtime.json", "schema": "phase6_transition_runtime.schema.json", "time_field": "updated_at", "identity_fields": ["status", "acceptance_report_id", "blocking_check_ids", "transition_receipt", "error"]},
    {"stage": "EXECUTIVE_VIEW", "path": "output/operations/phase6/executive-status.json", "schema": "phase6_executive_status.schema.json", "time_field": "captured_at", "identity_fields": ["status", "next_action", "attention_items", "release_control", "phase_transition"]},
)
BLOCKING_STATUSES = {"ERROR", "BLOCKED", "DEAD_LETTER", "ATTENTION_REQUIRED"}
AUDIO_STAGES = (
    ('NARRATIVE_SCRIPT', 'narrative_script.json', 'narrative_script.schema.json'),
    ('TAKE_PLAN', 'take_plan.json', 'take_plan.schema.json'),
    ('VOICE', 'audio/voice_render_manifest.json', 'voice_render_manifest.schema.json'),
    ('FORMAT_PACK', 'config/format_packs/fp-narrated-reflection-static-v1.json', 'format_pack.schema.json'),
    ('CREATIVE', 'creative_direction_decision.json', 'creative_direction_decision.schema.json'),
    ('RENDER', 'render_manifest.json', 'render_manifest.schema.json'),
    ('QUALITY', 'qa/creative_quality_gate_report.json', 'creative_quality_gate_report.schema.json'),
    ('PUBLICATION_PACKAGE', 'publication_package.json', 'publication_package.schema.json'),
    ('RELEASE', 'release_gate.json', 'phase5_release_gate.schema.json'),
    ('PUBLICATION', 'youtube-publication-receipt.json', 'youtube_publication_receipt.schema.json'),
    ('OWNED_OBSERVER', 'observer-status.json', 'phase6_observer_runtime.schema.json'),
    ('EXECUTIVE_VIEW', 'intelligence/executive-status.json', 'phase6_executive_status.schema.json'),
)
ADVANCING_STATUSES = {
    "COLLECTED", "COMPLETED", "COMPLETE", "COMPLETE_PUBLIC",
    "COMPLETE_PUBLIC_PACKAGE", "EVALUATED", "APPROVED",
}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def stage_execution_outcome(stage: str, value: dict[str, Any]) -> tuple[str, Any]:
    """Project schema-validated source state for execution and pre-stop preview.

    Goal v1.3 introduced an explicit production block and scalar action. Keep
    legacy goal sources byte-compatible with their historical cycle status;
    post-maintenance verification recomputes this contract independently.
    """
    status = str(value.get("status") or value.get("decision") or "UNAVAILABLE")
    error = value.get("error")
    if stage == "GOAL_TRAJECTORY" and value.get("schema_version") == "1.3.0":
        status = str(value["decision"]["selected_action"])
        block = value["decision"].get("production_block") or {}
        if block.get("status") == "EVIDENCE_INVALID":
            return "BLOCKED", block["reason"]
    return status, error


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _hash_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _hash_bytes(payload)


def stage_identity_hash(stage: str, value: dict[str, Any]) -> str:
    """Recompute the exact semantic identity frozen for one control stage."""
    try:
        contract = next(item for item in STAGES if item["stage"] == stage)
    except StopIteration as exc:
        raise ValueError(f"unknown Phase 6 control stage: {stage}") from exc
    identity = {field: value.get(field) for field in contract["identity_fields"]}
    return _canonical_hash(identity)


def _stage_path(root: Path, contract: dict[str, Any]) -> Path:
    path = root / contract["path"]
    if contract["stage"] == "GOAL_TRAJECTORY":
        from .phase6_goal_trajectory import current_path
        return current_path(root)
    return path


def completed_projection_binding(cycle: dict[str, Any], cycle_hash: str,
                                 goal: dict[str, Any], goal_hash: str) -> dict[str, str]:
    """Bind a completed cycle to its exact trajectory, not a prior signature.

    This is a projection of the existing immutable stage receipt, not an
    independent approval. Consumers still authenticate the twelve snapshots.
    """
    records = [item for item in cycle.get("stages", []) if item.get("stage") == "GOAL_TRAJECTORY"]
    if (cycle.get("stage_count") != 12 or not cycle.get("all_stages_executed_in_cycle")
            or cycle.get("decision") not in {"PASS_WAITING", "PASS_ADVANCED"}
            or cycle.get("blockers") or len(records) != 1
            or records[0].get("content_hash") != goal_hash
            or records[0].get("identity_hash") != stage_identity_hash("GOAL_TRAJECTORY", goal)):
        raise PermissionError("CURRENT_CHAIN_TRAJECTORY_OR_PRODUCER_INCOMPLETE")
    return {"cycle_id": cycle["cycle_id"], "cycle_sha256": cycle_hash,
            "trajectory_id": goal["trajectory_id"], "trajectory_sha256": goal_hash}


def verify_completed_projection(root: Path, cycle: dict[str, Any], cycle_hash: str,
                                executive: dict[str, Any]) -> dict[str, str]:
    """Require a report from this completed cycle and its sealed trajectory."""
    from .phase6_maintenance_verification import verify_control_cycle_sources
    verify_control_cycle_sources(root, cycle)
    record = next(item for item in cycle["stages"] if item["stage"] == "GOAL_TRAJECTORY")
    raw = (root / record["snapshot_path"]).read_bytes()
    goal = json.loads(raw.decode("utf-8-sig"))
    binding = completed_projection_binding(cycle, cycle_hash, goal, _hash_bytes(raw))
    summary = executive.get("control_cycle") or {}
    if (executive.get("producer_binding") != binding
            or summary.get("cycle_id") != cycle["cycle_id"]
            or summary.get("substantive_signature") != cycle["substantive_signature"]
            or (executive.get("goal_trajectory") or {}).get("trajectory_id") != goal["trajectory_id"]
            or _parse(executive["captured_at"]) < _parse(cycle["cycle_completed_at"])):
        raise PermissionError("CURRENT_CHAIN_EXECUTIVE_DIVERGED")
    return binding


def _audio_stage_identity(value):
    return _canonical_hash({key:item for key,item in value.items()
        if key not in {'captured_at','updated_at','created_at','generated_at','evaluated_at'}})


def _audio_contracts(executive, *, instrumental=False):
    if not instrumental:
        return AUDIO_STAGES
    refs=executive['producer_receipts']
    raw_schema='rest_music_cycle_source.schema.json'
    rows=(('MUSIC_RECIPE','music_recipe',raw_schema),('MUSIC_SOURCE','music_source',raw_schema),
        ('STATIC_ASSET','music_asset',raw_schema),('FORMAT_PACK','format_pack','format_pack.schema.json'),
        ('MUSIC_REFERENCE','aesthetic_reference',raw_schema),('RENDER','render','render_manifest.schema.json'),
        ('QUALITY','quality_report',raw_schema),('PUBLICATION_PACKAGE','publication_package','publication_package.schema.json'))
    if any(label not in refs for _,label,_ in rows):
        raise PermissionError('Instrumental cycle needs all completed native producer receipts')
    return tuple((name,refs[label]['path'],schema) for name,label,schema in rows)+AUDIO_STAGES[-4:]


def _audio_source(root,directory,name,relative, *, instrumental=False):
    return root/relative if name=='FORMAT_PACK' or (instrumental and name not in
        {'RELEASE','PUBLICATION','OWNED_OBSERVER','EXECUTIVE_VIEW'}) else directory/relative


def verify_audio_cycle_sources(root: Path, cycle: dict[str, Any], executive: dict[str, Any] | None = None) -> None:
    """Authenticate the selected profile's sealed bytes, not a legacy cycle.

    These are twelve local producer-output validations. Neither an absent
    publication nor a schema/hash check claims execution of an external effect.
    """
    Draft202012Validator(_read(root/'schemas/phase6_control_cycle_receipt.schema.json'),
                        format_checker=FormatChecker()).validate(cycle)
    directory = (root / cycle['package_relative']).resolve()
    instrumental=cycle['schema_version']=='1.3.0'
    if cycle['schema_version'] not in {'1.2.0','1.3.0'}:
        raise PermissionError('Current audio cycle version differs')
    preliminary_record=cycle['stages'][-1]
    preliminary_raw=(root/preliminary_record['snapshot_path']).read_bytes()
    if _hash_bytes(preliminary_raw)!=preliminary_record['content_hash']:
        raise PermissionError('Current audio executive snapshot changed')
    contracts=_audio_contracts(json.loads(preliminary_raw.decode('utf-8-sig')),instrumental=instrumental)
    if (Path(cycle['package_relative']).is_absolute()
            or '..' in Path(cycle['package_relative']).parts or not directory.is_relative_to(root/'output/production')
            or cycle['stage_order'] != [row[0] for row in contracts]
            or len(cycle['stages']) != 12):
        raise PermissionError('Current audio cycle profile or origin differs')
    parent = directory/'intelligence/control-cycle/source-snapshots'/cycle['cycle_id']
    semantic = {}
    sealed_executive = None
    sealed_values = {}
    for ordinal, (contract, record) in enumerate(zip(contracts, cycle['stages'], strict=True), 1):
        name, relative, schema = contract
        expected = parent / f'{ordinal:02d}-{name.lower().replace("_","-")}.json'
        path = (root / record['snapshot_path']).resolve()
        waiting = record['status'] == 'WAITING_NATIVE_PRODUCER'
        if waiting and name not in {'PUBLICATION', 'OWNED_OBSERVER'}:
            raise PermissionError('Current audio required producer cannot be absent')
        source = (directory/'intelligence/executive-status.json' if waiting else
            _audio_source(root,directory,name,relative,instrumental=instrumental))
        source_schema = 'phase6_executive_status.schema.json' if waiting else schema
        if (record['ordinal'] != ordinal or record['stage'] != name or path != expected
                or record['path'] != source.relative_to(root).as_posix()
                or record['schema'] != source_schema
                or record['execution_kind'] != 'READ_ONLY_REVALIDATION'
                or record['executed_in_cycle'] is not True
                or not _parse(cycle['cycle_started_at']) <= _parse(record['observed_at']) <= _parse(cycle['cycle_completed_at'])):
            raise PermissionError('Current audio stage identity or time differs')
        raw = path.read_bytes()
        if _hash_bytes(raw) != record['content_hash']:
            raise PermissionError('Current audio immutable snapshot changed')
        value = json.loads(raw.decode('utf-8-sig'))
        Draft202012Validator(_read(root/'schemas'/source_schema), format_checker=FormatChecker()).validate(value)
        if _audio_stage_identity(value) != record['identity_hash']:
            raise PermissionError('Current audio snapshot semantic identity differs')
        expected_status = 'WAITING_NATIVE_PRODUCER' if waiting else str(value.get('status') or value.get('decision') or 'VALIDATED')
        if record['status'] != expected_status:
            raise PermissionError('Current audio producer status differs')
        if waiting:
            field = 'publication_status' if name == 'PUBLICATION' else 'observer_status'
            if value.get('schema_version') != '2.0.0' or value['current_delivery'][field] != 'NOT_STARTED':
                raise PermissionError('Current audio missing producer was falsely claimed')
        if name == 'EXECUTIVE_VIEW':
            sealed_executive = value
        sealed_values[name]=(record,value)
        semantic[name] = record['identity_hash']
    if (_canonical_hash(semantic) != cycle['substantive_signature'] or sealed_executive is None
            or sealed_executive['source_candidate_sha256'] != cycle['source_candidate_sha256']
            or sealed_executive['current_delivery']['package_relative'] != cycle['package_relative']
            or (executive is not None and executive != sealed_executive)):
        raise PermissionError('Current audio report/candidate/cycle binding differs')
    blockers=sorted(set(sealed_executive['attention_items']))
    if (cycle['blockers'] != blockers or cycle['decision'] != ('BLOCKED' if blockers else 'PASS_WAITING')
            or cycle['all_stages_executed_in_cycle'] is not True):
        raise PermissionError('Current audio cycle outcome differs from its producers')
    refs=sealed_executive['producer_receipts']
    for name,label in (('QUALITY','quality_report'),('PUBLICATION_PACKAGE','publication_package'),
                       ('RELEASE','release'),('PUBLICATION','publication'),('OWNED_OBSERVER','observer'),('FORMAT_PACK','format_pack')) + (
                       (('MUSIC_RECIPE','music_recipe'),('MUSIC_SOURCE','music_source'),('STATIC_ASSET','music_asset'),
                        ('MUSIC_REFERENCE','aesthetic_reference'),('RENDER','render')) if instrumental else ()):
        record, value=sealed_values[name]
        if record['status']=='WAITING_NATIVE_PRODUCER':continue
        if label not in refs or refs[label] != {'path':record['path'],'sha256':record['content_hash']}:
            raise PermissionError('Current audio stage/report producer binding differs')
        if name in {'PUBLICATION','OWNED_OBSERVER'} and value.get('video_id') != sealed_executive['current_delivery']['video_id']:
            raise PermissionError('Current audio producer belongs to another video')


def _materialize_audio_cycle(root, relative, bindings, release_hash, started):
    from .phase6_reporting import build_status
    from .maintenance_paused_application import candidate_identity
    directory = (root / relative).resolve()
    report_path = directory/'intelligence/executive-status.json'
    report_raw = report_path.read_bytes()
    report = json.loads(report_raw.decode('utf-8-sig'))
    if report != build_status(root, package_relative=relative, current_bindings=bindings,
            expected_release_hash=release_hash, captured_at=report['captured_at']):
        raise PermissionError('Current audio cycle report has incomplete or divergent producers')
    instrumental='music_inputs' in bindings
    contracts=_audio_contracts(report,instrumental=instrumental)
    records, payloads, semantic, pins = [], [], {}, {report_path: report_raw}
    for ordinal, (name, source_relative, source_schema) in enumerate(contracts, 1):
        path = _audio_source(root,directory,name,source_relative,instrumental=instrumental)
        waiting = not path.exists() and name in {'PUBLICATION', 'OWNED_OBSERVER'}
        if waiting:
            path, source_schema = report_path, 'phase6_executive_status.schema.json'
        raw = path.read_bytes()
        value = json.loads(raw.decode('utf-8-sig'))
        Draft202012Validator(_read(root/'schemas'/source_schema), format_checker=FormatChecker()).validate(value)
        status = 'WAITING_NATIVE_PRODUCER' if waiting else str(value.get('status') or value.get('decision') or 'VALIDATED')
        observed = _stamp(datetime.now(timezone.utc))
        identity = _audio_stage_identity(value)
        semantic[name] = identity
        records.append({'ordinal':ordinal, 'stage':name, 'path':path.relative_to(root).as_posix(),
            'schema':source_schema, 'schema_status':'PASS', 'status':status,
            'observed_at':observed, 'source_observed_at':None, 'execution_kind':'READ_ONLY_REVALIDATION',
            'executed_in_cycle':True, 'content_hash':_hash_bytes(raw), 'identity_hash':identity})
        payloads.append(raw);pins[path]=raw
    completed = datetime.now(timezone.utc)
    if completed < started or any(path.read_bytes() != raw for path,raw in pins.items()):
        raise PermissionError('Current audio cycle changed during capture')
    signature = _canonical_hash(semantic)
    base = Path(relative)/'intelligence/control-cycle'
    previous = _read(root/base/'latest.json') if (root/base/'latest.json').exists() else None
    change = 'INITIAL' if previous is None else ('HEARTBEAT_ONLY' if previous['substantive_signature']==signature else 'STATE_CHANGED')
    cycle_id = 'phase6-control-cycle-'+hashlib.sha256(f'{_stamp(started)}|{_stamp(completed)}|{signature}'.encode()).hexdigest()[:24]
    blockers = list(report['attention_items'])
    value = {'schema_version':'1.3.0' if instrumental else '1.2.0', 'cycle_mode':'OPERATIONAL', 'maintenance_window_id':None,
        'package_relative':Path(relative).as_posix(), 'source_candidate_sha256':report['source_candidate_sha256'],
        'cycle_id':cycle_id,'phase':6,'channel_id':'UCuMF6pJQkyMzaVoAxFL86yA',
        'cycle_started_at':_stamp(started),'cycle_completed_at':_stamp(completed),
        'duration_seconds':round((completed-started).total_seconds(),6),
        'stage_count':12,'expected_stage_count':12,'stage_order':[row[0] for row in contracts],
        'stages':records,'all_schemas_valid':True,'all_stages_executed_in_cycle':True,
        'substantive_signature':signature,'previous_substantive_signature':(previous or {}).get('substantive_signature'),
        'change_class':change,'decision':'BLOCKED' if blockers else 'PASS_WAITING',
        'blockers':sorted(set(blockers)),'history_archived':change!='HEARTBEAT_ONLY',
        'technical_cost_brl':0,'claim_boundary':[
            'The selected audio profile validates twelve real producer-output slots in one bounded invocation.',
            'READ_ONLY_REVALIDATION records current local readers, not a repeated render, publication or external observation.',
            'Absent publication/observer slots are explicitly waiting; no historical canary supplies these bytes.',
            'This cycle cannot approve phase completion, adoption, D116, learning, revenue or effect authority.',
        ]}
    for record, raw in zip(records, payloads, strict=True):
        snapshot = base/'source-snapshots'/cycle_id/f'{record["ordinal"]:02d}-{record["stage"].lower().replace("_","-")}.json'
        target = root/snapshot
        if target.exists() and target.read_bytes()!=raw:
            raise PermissionError('Current audio immutable cycle collision')
        if not target.exists():_write_bytes(target,raw)
        record['snapshot_path']=snapshot.as_posix()
    verify_audio_cycle_sources(root,value,report)
    if (any(path.read_bytes()!=raw for path,raw in pins.items())
            or candidate_identity(root)['source_set_sha256'] != report['source_candidate_sha256']):
        raise PermissionError('Current audio cycle sources changed before receipt commit')
    _write(root/base/'latest.json',value)
    if value['history_archived']:_write(root/base/'history'/f'{cycle_id}.json',value)
    return value


def materialize(
    root: Path = ROOT,
    *,
    cycle_started_at: datetime,
    cycle_completed_at: datetime | None,
    maintenance_revalidation: bool = False,
    maintenance_window_id: str | None = None,
    package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None,
    expected_release_hash: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    started = cycle_started_at.astimezone(timezone.utc)
    if any(item is not None for item in (package_relative,current_bindings,expected_release_hash)):
        if any(item is None for item in (package_relative,current_bindings,expected_release_hash)) or maintenance_revalidation:
            raise PermissionError('Current audio cycle requires complete explicit operational selection')
        return _materialize_audio_cycle(root,Path(package_relative),current_bindings,expected_release_hash,started)
    completed = (cycle_completed_at or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if completed < started:
        raise ValueError("control cycle completion precedes its start")

    stage_records: list[dict[str, Any]] = []
    stage_payloads: list[bytes] = []
    semantic: dict[str, Any] = {}
    blockers: list[str] = []
    for index, contract in enumerate(STAGES, start=1):
        path = _stage_path(root, contract)
        if not path.is_file():
            raise FileNotFoundError(f"control cycle stage is missing: {contract['stage']}")
        raw = path.read_bytes()
        stage_payloads.append(raw)
        value = json.loads(raw.decode("utf-8-sig"))
        schema = _read(root / "schemas" / contract["schema"])
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
        observed_at = _parse(str(value[contract["time_field"]]))
        validation_observed_at = datetime.now(timezone.utc) if maintenance_revalidation else observed_at
        fresh = started <= validation_observed_at <= completed if not maintenance_revalidation else True
        status, error = stage_execution_outcome(contract["stage"], value)
        if not fresh:
            blockers.append(f"{contract['stage']}:NOT_EXECUTED_IN_CYCLE")
        producer_error = {
            "GOAL_TRAJECTORY": "goal-trajectory-error.json",
            "EXECUTIVE_VIEW": "executive-status-error.json",
        }.get(contract["stage"])
        if producer_error and (root / "output/operations/phase6" / producer_error).exists():
            # A valid old output is not completion of the failed producer.
            # Its producer must archive its own error on genuine success.
            blockers.append(f"{contract['stage']}:PRODUCER_INCOMPLETE")
        # The transition controller deliberately reports BLOCKED while the
        # current phase still lacks real acceptance evidence. That is a
        # business-gate result, not a failure to execute this control stage.
        # Its exact GC blockers remain frozen in the stage identity and source
        # hash; ERROR or a populated error field still blocks the cycle.
        expected_transition_wait = (
            contract["stage"] == "PHASE_TRANSITION"
            and status == "BLOCKED"
            and error in {None, "PHASE6_ACCEPTANCE_BLOCKED"}
            and bool(value.get("blocking_check_ids"))
        )
        expected_content_wait = False
        if contract['stage'] == 'QUALITY':
            from .phase6_reporting import authenticated_prequeue_wait
            expected_content_wait = authenticated_prequeue_wait(root, value)
        if (status in BLOCKING_STATUSES and not (expected_transition_wait or expected_content_wait)) or (error is not None and not expected_transition_wait):
            blockers.append(f"{contract['stage']}:{status}")
        identity = {field: value.get(field) for field in contract["identity_fields"]}
        semantic[contract["stage"]] = identity
        stage_records.append({
            "ordinal": index,
            "stage": contract["stage"],
            "path": path.relative_to(root).as_posix(),
            "schema": contract["schema"],
            "schema_status": "PASS",
            "status": status,
            "observed_at": _stamp(validation_observed_at),
            "source_observed_at": _stamp(observed_at) if maintenance_revalidation else None,
            "execution_kind": "LOCAL_NO_EXTERNAL_EFFECT_REVALIDATION" if maintenance_revalidation else "OPERATIONAL_STAGE",
            "executed_in_cycle": fresh,
            "content_hash": _hash_bytes(raw),
            "identity_hash": stage_identity_hash(contract["stage"], value),
        })

    if maintenance_revalidation:
        completed = datetime.now(timezone.utc)
    signature = _canonical_hash(semantic)
    latest_path = root / BASE / "latest.json"
    previous = _read(latest_path) if latest_path.is_file() else None
    previous_signature = (previous or {}).get("substantive_signature")
    change_class = "INITIAL" if previous is None else ("STATE_CHANGED" if signature != previous_signature else "HEARTBEAT_ONLY")
    any_advancing = any(record["status"] in ADVANCING_STATUSES for record in stage_records)
    decision = "BLOCKED" if blockers else ("PASS_ADVANCED" if change_class != "HEARTBEAT_ONLY" and any_advancing else "PASS_WAITING")
    archived = change_class in {"INITIAL", "STATE_CHANGED"}
    cycle_id = "phase6-control-cycle-" + hashlib.sha256(
        f"{_stamp(started)}|{_stamp(completed)}|{signature}".encode("utf-8")
    ).hexdigest()[:24]
    snapshot_dir = BASE / "source-snapshots" / cycle_id
    for record, raw in zip(stage_records, stage_payloads, strict=True):
        slug = str(record["stage"]).lower().replace("_", "-")
        snapshot_relative = snapshot_dir / f"{int(record['ordinal']):02d}-{slug}.json"
        snapshot = root / snapshot_relative
        if snapshot.is_file() and snapshot.read_bytes() != raw:
            raise PermissionError(f"immutable control-cycle stage collision: {record['stage']}")
        if not snapshot.is_file():
            _write_bytes(snapshot, raw)
        if _hash_bytes(snapshot.read_bytes()) != record["content_hash"]:
            raise PermissionError(f"control-cycle stage snapshot hash mismatch: {record['stage']}")
        record["snapshot_path"] = snapshot_relative.as_posix()
    value = {
        "schema_version": "1.1.0",
        "cycle_mode": "MAINTENANCE_REVALIDATION" if maintenance_revalidation else "OPERATIONAL",
        "maintenance_window_id": maintenance_window_id if maintenance_revalidation else None,
        "cycle_id": cycle_id,
        "phase": 6,
        "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
        "cycle_started_at": _stamp(started),
        "cycle_completed_at": _stamp(completed),
        "duration_seconds": round((completed - started).total_seconds(), 6),
        "stage_count": len(stage_records),
        "expected_stage_count": len(STAGES),
        "stage_order": [record["stage"] for record in stage_records],
        "stages": stage_records,
        "all_schemas_valid": True,
        "all_stages_executed_in_cycle": all(record["executed_in_cycle"] for record in stage_records),
        "substantive_signature": signature,
        "previous_substantive_signature": previous_signature,
        "change_class": change_class,
        "decision": decision,
        "blockers": sorted(set(blockers)),
        "history_archived": archived,
        "claim_boundary": [
            "This receipt proves execution order, schema validity, freshness and identity for one local control cycle; it does not prove audience response.",
            "PASS_ADVANCED records a material control-state transition, not monetization, virality or YPP approval.",
            "A missing, invalid, stale or error-stage blocks the cycle receipt even when another stage passed.",
            "Each stage is frozen byte-for-byte under this cycle id; later verification recomputes its schema, order, time, content and semantic identity.",
            "MAINTENANCE_REVALIDATION executes only ordered local schema/hash/identity checks and never runs an operational executor or external effect.",
            "Its only permitted writes are this control-cycle latest receipt, its immutable source snapshots and, for a material identity change, its immutable history twin.",
            "HEARTBEAT_ONLY replaces latest.json but is not archived as a new material decision.",
        ],
        "technical_cost_brl": 0,
    }
    Draft202012Validator(
        _read(root / "schemas/phase6_control_cycle_receipt.schema.json"),
        format_checker=FormatChecker(),
    ).validate(value)
    _write(latest_path, value)
    if archived:
        _write(root / BASE / "history" / f"{cycle_id}.json", value)
    # Once every current stage passed, any separate *error*.json view is by
    # definition stale. Archive it generically without touching immutable
    # history/source snapshots. A blocked cycle preserves the current errors.
    if not blockers and not maintenance_revalidation:
        operations = root / "output/operations/phase6"
        excluded = {"archive", "archives", "history", "source-snapshots", "incidents"}
        for stale_error in sorted(operations.rglob("*error*.json")):
            relative = stale_error.relative_to(operations)
            if any(part.lower() in excluded for part in relative.parts[:-1]):
                continue
            error_bytes = stale_error.read_bytes()
            error_hash = hashlib.sha256(error_bytes).hexdigest()
            encoded = "__".join(relative.parts)
            error_archive = root / BASE / "errors/archive" / cycle_id / f"{encoded}-{error_hash[:16]}.json"
            error_archive.parent.mkdir(parents=True, exist_ok=True)
            if error_archive.is_file():
                if error_archive.read_bytes() != error_bytes:
                    raise RuntimeError(f"control-cycle error archive collision: {relative.as_posix()}")
                stale_error.unlink()
            else:
                os.replace(stale_error, error_archive)
    return value


if __name__ == "__main__":
    raise SystemExit(
        "phase6_control_cycle must be called by the resident manager with real cycle boundaries"
    )
