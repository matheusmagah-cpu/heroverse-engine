from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .phase6_release import (
    BASE as RELEASE_BASE,
    PRODUCTION_ARTIFACT_ARCHIVES,
    PRODUCTION_ARTIFACT_ARCHIVE_RECEIPTS,
    PRODUCTION_INPUT_RECEIPTS,
    RIGHTS_OK,
    VIDEO2_ROOT,
    _allocate_assets,
    _creative_decision,
    _creative_treatment,
    _derive_style_bible,
    _read,
    _resolve_asset_path,
    _stable_id,
    _take_plan,
    _validate,
    _verify_release_evidence_bindings,
    metadata_publicity_risks,
    verify_production_inputs_receipt,
)
from .phase6_creative_compiler import (
    HOOK_SLOT_MS,
    VOICE_SPEED_BY_TAKE_INDEX,
    VOICE_TIMING_PROFILE_VERSION,
)
from .queue_phase6 import CHANNEL_ID, QueueConflict, TransactionalQueue


ROOT = Path(__file__).resolve().parents[1]
MEDIA_TASK = "EXECUTE_PHASE6_VIDEO2_MEDIA"
MEDIA_ACTION = "SYNTHESIZE_AND_RENDER_VIDEO_2"
INPUT_PATTERN = "phase6-production-inputs-"
REMEDIATION_POLICY_VERSION = "phase6-media-identity-remediation-whitelist-v1"
PRE_EFFECT_REMEDIATION_POLICY_VERSION = (
    "phase6-media-pre-effect-compiler-voice-remediation-whitelist-v1"
)
PRE_EFFECT_SUPERSESSION_CLASS = "PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION"
VOICE_EXECUTION_CONTRACT_VERSION = "phase6-pinned-voice-slot-v2"
EXPECTED_FORMAT_PACK = {"format_pack_id": "fp-broll-cinematic-narration", "version": "1.1.0"}
EXPECTED_PIPELINE = {"pipeline_id": "pipeline-clips-longform-v1", "version": "1.0.0"}
EXPECTED_DURATION_BAND = {"minimum_ms": 207_750, "maximum_ms": 286_250}
EXPECTED_LOCKED_CONSTANTS = {
    "FormatPack fp-broll-cinematic-narration@1.1.0",
    "pipeline-clips-longform-v1",
    "STANDARD 1920x1080 30fps profile",
    "am_onyx local English voice identity",
    "207750–286250 ms duration band for a new long-form treatment",
}
PREPRODUCTION_NAMES = (
    "treatment_contract.json",
    "creative_concept_decision.json",
    "editorial_brief.json",
    "narrative_script.json",
    "take_blueprint.json",
    "quality_gate_plan.json",
    "asset_acquisition_plan.json",
)
PRODUCTION_NAMES = (
    "creative_direction_decision.json",
    "channel_style_bible.json",
    "creative_treatment_plan.json",
    "asset_allocation.json",
    "take_plan.json",
)
COMPILER_DERIVED_PREPRODUCTION_NAMES = {
    "creative_concept_decision.json",
    "editorial_brief.json",
    "narrative_script.json",
    "take_blueprint.json",
    "quality_gate_plan.json",
}
COMPILER_IDENTITY_STABLE_FIELDS = {
    "compiler_source_path",
    "compiler_version",
    "creative_recipe_content_sha256",
    "identity_version",
    "production_recipe_content_sha256",
    "production_recipe_version",
    "production_source_path",
    "voice_execution_contract_version",
    "voice_id",
}
COMPILER_IDENTITY_MUTABLE_FIELDS = {
    "compiler_code_sha256",
    "creative_identity_sha256",
    "identity_sha256",
    "production_code_sha256",
    "voice_profile_content_sha256",
    "voice_profile_version",
}


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha256_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _content_hash(value: Any) -> str:
    return _sha256_bytes(_canonical(value).encode("utf-8"))


def _replace_strings(value: Any, replacements: dict[str, str]) -> Any:
    """Apply an explicit token map without permitting structural edits."""

    if isinstance(value, str):
        result = value
        for before, after in sorted(
            replacements.items(), key=lambda item: len(item[0]), reverse=True
        ):
            if before and before != after:
                result = result.replace(before, after)
        return result
    if isinstance(value, list):
        return [_replace_strings(item, replacements) for item in value]
    if isinstance(value, dict):
        return {
            key: _replace_strings(item, replacements)
            for key, item in value.items()
        }
    return value


def _diff_paths(before: Any, after: Any, path: str = "$") -> list[str]:
    if type(before) is not type(after):
        return [path]
    if isinstance(before, dict):
        paths: list[str] = []
        for key in sorted(set(before) | set(after)):
            child = f"{path}.{key}"
            if key not in before or key not in after:
                paths.append(child)
            else:
                paths.extend(_diff_paths(before[key], after[key], child))
        return paths
    if isinstance(before, list):
        if len(before) != len(after):
            return [path]
        paths = []
        for index, (left, right) in enumerate(zip(before, after)):
            paths.extend(_diff_paths(left, right, f"{path}[{index}]"))
        return paths
    return [] if before == after else [path]


def _normalized_exact(
    label: str,
    before: dict[str, Any],
    after: dict[str, Any],
    *,
    before_replacements: dict[str, str],
    after_replacements: dict[str, str],
) -> dict[str, Any]:
    normalized_before = _replace_strings(deepcopy(before), before_replacements)
    normalized_after = _replace_strings(deepcopy(after), after_replacements)
    if normalized_before != normalized_after:
        drift = _diff_paths(normalized_before, normalized_after)
        raise PermissionError(
            f"{label} changed outside the identity-remediation whitelist: "
            + ",".join(drift[:12])
        )
    changes = _diff_paths(before, after)
    if not changes:
        raise PermissionError(f"{label} contains no identity remediation to prove")
    return {
        "document": label,
        "changed_paths": changes,
        "normalized_content_hash": _content_hash(normalized_after),
        "status": "PASS",
    }


def _artifact_records(
    receipt: dict[str, Any], expected_names: tuple[str, ...], *, label: str
) -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    for item in receipt.get("artifacts") or []:
        name = Path(str(item.get("path") or "")).name
        if name in records:
            raise PermissionError(f"{label} repeats artifact {name}")
        records[name] = item
    if set(records) != set(expected_names):
        raise PermissionError(f"{label} artifact set changed")
    return records


def _serialized_like(path: Path, value: dict[str, Any]) -> bytes:
    raw = path.read_bytes()
    line_break = "\r\n" if b"\r\n" in raw else "\n"
    text = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    if line_break == "\r\n":
        text = text.replace("\n", "\r\n")
    return text.encode("utf-8")


def _as_sha256(value: Any) -> str:
    text = str(value or "")
    return text if text.startswith("sha256:") else f"sha256:{text}"


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _read_bound_json(
    root: Path,
    *,
    path: Path,
    expected_sha256: str,
    expected_size: int,
    expected_parent: Path,
    label: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    resolved = path.resolve()
    parent = expected_parent.resolve()
    if resolved.parent != parent or not resolved.is_file():
        raise PermissionError(f"{label} escaped its exact immutable directory")
    raw = resolved.read_bytes()
    digest = _sha256_bytes(raw)
    if digest != _as_sha256(expected_sha256) or len(raw) != int(expected_size):
        raise PermissionError(f"{label} bytes/hash/size diverged")
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PermissionError(f"{label} is not valid UTF-8 JSON") from exc
    return value, {
        "path": _relative(root, resolved),
        "sha256": digest,
        "size_bytes": len(raw),
    }


def _production_bundle(
    root: Path,
    *,
    receipt: dict[str, Any],
    archived: bool,
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Load five exact production documents from current bytes or their archive."""

    records = _artifact_records(receipt, PRODUCTION_NAMES, label="production")
    input_ref = _input_reference(root, str(receipt["receipt_id"]))
    documents: dict[str, dict[str, Any]] = {}
    artifact_lineage: list[dict[str, Any]] = []
    archive_binding: dict[str, Any] | None = None
    if archived:
        matches: list[tuple[Path, dict[str, Any]]] = []
        directory = (root / PRODUCTION_ARTIFACT_ARCHIVE_RECEIPTS).resolve()
        for candidate in sorted(directory.glob("*.json")) if directory.is_dir() else []:
            value = _read(candidate)
            if (value.get("production_input_receipt") or {}).get("receipt_id") == receipt["receipt_id"]:
                matches.append((candidate, value))
        if len(matches) != 1:
            raise PermissionError(
                "historical production inputs require exactly one immutable artifact archive"
            )
        archive_path, archive = matches[0]
        _validate(root, "phase6_production_artifact_archive_receipt.schema.json", archive)
        if archive.get("production_input_receipt") != input_ref:
            raise PermissionError("production archive binds a different input receipt")
        archive_records = {
            Path(str(item.get("original_path") or "")).name: item
            for item in archive.get("artifacts") or []
        }
        if set(archive_records) != set(PRODUCTION_NAMES) or len(archive_records) != len(
            PRODUCTION_NAMES
        ):
            raise PermissionError("production archive artifact set is incomplete or repeated")
        ordered_hashes: list[str] = []
        for name in PRODUCTION_NAMES:
            source_record = records[name]
            archive_record = archive_records[name]
            if (
                archive_record.get("original_path") != source_record.get("path")
                or _as_sha256(archive_record.get("sha256"))
                != _as_sha256(source_record.get("sha256"))
                or int(archive_record.get("size_bytes") or -1)
                != int(source_record.get("size_bytes") or -2)
            ):
                raise PermissionError(f"production archive/input mismatch for {name}")
            expected = (
                root
                / PRODUCTION_ARTIFACT_ARCHIVES
                / str(receipt["receipt_id"])
                / name
            )
            value, binding = _read_bound_json(
                root,
                path=root / str(archive_record["archive_path"]),
                expected_sha256=str(archive_record["sha256"]),
                expected_size=int(archive_record["size_bytes"]),
                expected_parent=expected.parent,
                label=f"archived production artifact {name}",
            )
            if (root / str(archive_record["archive_path"])).resolve() != expected.resolve():
                raise PermissionError(f"production archive path is not canonical for {name}")
            binding["name"] = name
            documents[name] = value
            artifact_lineage.append(binding)
            ordered_hashes.append(binding["sha256"])
        expected_archive_id = _stable_id(
            "phase6-production-artifact-archive",
            str(receipt["receipt_id"]),
            input_ref["sha256"],
            *ordered_hashes,
        )
        if archive.get("receipt_id") != expected_archive_id or archive_path.name != f"{expected_archive_id}.json":
            raise PermissionError("production archive identity is not hash-derived")
        archive_binding = {
            "receipt_id": expected_archive_id,
            "path": _relative(root, archive_path),
            "sha256": _sha256_file(archive_path),
            "size_bytes": archive_path.stat().st_size,
        }
    else:
        latest = (root / RELEASE_BASE / "latest-production-inputs-receipt.json").resolve()
        immutable = (root / input_ref["path"]).resolve()
        if not latest.is_file() or latest.read_bytes() != immutable.read_bytes():
            raise PermissionError("authoritative input receipt is not the byte-exact latest view")
        expected_parent = (root / VIDEO2_ROOT / "production").resolve()
        for name in PRODUCTION_NAMES:
            record = records[name]
            expected = expected_parent / name
            actual = (root / str(record["path"])).resolve()
            if actual != expected:
                raise PermissionError(f"authoritative production path is not canonical for {name}")
            value, binding = _read_bound_json(
                root,
                path=actual,
                expected_sha256=str(record["sha256"]),
                expected_size=int(record["size_bytes"]),
                expected_parent=expected_parent,
                label=f"authoritative production artifact {name}",
            )
            binding["name"] = name
            documents[name] = value
            artifact_lineage.append(binding)
    return documents, {
        "mode": "IMMUTABLE_ARCHIVE" if archived else "CURRENT_RECEIPT_BOUND",
        "input_receipt": input_ref,
        "archive_receipt": archive_binding,
        "production_artifacts": artifact_lineage,
    }


def _compiler_transition(
    old_order: dict[str, Any], new_order: dict[str, Any]
) -> dict[str, Any]:
    old_identity = old_order.get("compiler_identity")
    new_identity = new_order.get("compiler_identity")
    if not isinstance(new_identity, dict):
        raise PermissionError("authoritative compiler/voice identity is absent")
    new_payload = dict(new_identity)
    new_hash = str(new_payload.pop("identity_sha256", ""))
    if new_hash != _content_hash(new_payload):
        raise PermissionError("authoritative compiler identity hash is invalid")
    if (
        new_identity.get("voice_id") != "am_onyx"
        or new_identity.get("voice_execution_contract_version")
        != VOICE_EXECUTION_CONTRACT_VERSION
        or new_identity.get("voice_profile_version") != VOICE_TIMING_PROFILE_VERSION
    ):
        raise PermissionError("authoritative voice identity is not the current pinned contract")

    if old_identity is None:
        if old_order.get("schema_version") != "1.0.0" or new_order.get("schema_version") != "1.1.0":
            raise PermissionError("missing compiler identity is not a recognized legacy binding")
        changed_fields = ["LEGACY_COMPILER_IDENTITY_ABSENT", *sorted(new_identity)]
        transition = "LEGACY_UNBOUND_TO_HASH_BOUND"
        old_hash: str | None = None
        old_profile: str | None = None
    else:
        if not isinstance(old_identity, dict):
            raise PermissionError("historical compiler identity has an invalid type")
        old_payload = dict(old_identity)
        old_hash = str(old_payload.pop("identity_sha256", ""))
        if old_hash != _content_hash(old_payload):
            raise PermissionError("historical compiler identity hash is invalid")
        missing = (COMPILER_IDENTITY_STABLE_FIELDS | COMPILER_IDENTITY_MUTABLE_FIELDS) - set(
            old_identity
        )
        if missing:
            raise PermissionError("historical compiler identity is structurally incomplete")
        if any(old_identity[field] != new_identity.get(field) for field in COMPILER_IDENTITY_STABLE_FIELDS):
            raise PermissionError("compiler transition changed a stable recipe/voice identity field")
        changed_fields = sorted(
            field
            for field in set(old_identity) | set(new_identity)
            if old_identity.get(field) != new_identity.get(field)
        )
        if not changed_fields or not set(changed_fields).issubset(COMPILER_IDENTITY_MUTABLE_FIELDS):
            raise PermissionError("compiler transition contains a non-whitelisted identity change")
        if not {
            "compiler_code_sha256",
            "production_code_sha256",
            "voice_profile_content_sha256",
            "voice_profile_version",
        }.intersection(changed_fields):
            raise PermissionError("compiler transition does not contain a compiler/voice remediation")
        transition = "HASH_BOUND_COMPILER_VOICE_REVISION"
        old_profile = str(old_identity.get("voice_profile_version") or "")
        if old_profile not in {
            "am-onyx-kokoro-planning-v1",
            "am-onyx-kokoro-planning-v2",
        }:
            raise PermissionError("historical voice planning profile is outside the supported lineage")
    return {
        "transition": transition,
        "historical_identity_sha256": old_hash,
        "authoritative_identity_sha256": new_hash,
        "historical_voice_profile_version": old_profile,
        "authoritative_voice_profile_version": str(new_identity["voice_profile_version"]),
        "changed_fields": changed_fields,
        "stable_fields_sha256": _content_hash(
            {field: new_identity[field] for field in sorted(COMPILER_IDENTITY_STABLE_FIELDS)}
        ),
    }


def _without_compiler_gate(gates: Any, *, normalize_order: bool = False) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for source in gates or []:
        if source.get("gate") == "COMPILER_CONTENT_IDENTITY":
            continue
        item = deepcopy(source)
        if normalize_order and item.get("gate") == "ORDER_IDENTITY":
            item["evidence"] = ["<TREATMENT_ORDER_ID>"]
        result.append(item)
    return result


def _lineage_contract_documents(
    old: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
    new: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
) -> list[dict[str, Any]]:
    old_receipt, old_work, old_evidence = old
    new_receipt, new_work, new_evidence = new
    old_order, new_order = old_evidence["TREATMENT_ORDER"], new_evidence["TREATMENT_ORDER"]
    if old_evidence["FORMAT_SCOPE"] != new_evidence["FORMAT_SCOPE"]:
        raise PermissionError("format-scope contract changed during compiler/voice remediation")

    normalized_orders = []
    for order in (old_order, new_order):
        value = deepcopy(order)
        for field in ("schema_version", "order_id", "created_at", "compiler_identity"):
            value.pop(field, None)
        value["evidence_refs"] = [
            item
            for item in value.get("evidence_refs") or []
            if item not in {
                "hero_engine/phase6_creative_compiler.py",
                "hero_engine/phase6_production.py",
            }
        ]
        value["prerequisite_gates"] = _without_compiler_gate(
            value.get("prerequisite_gates")
        )
        (value.get("execution_contract") or {})["idempotency_key"] = "<DERIVED>"
        normalized_orders.append(value)
    if normalized_orders[0] != normalized_orders[1]:
        raise PermissionError(
            "treatment order changed outside compiler identity and derived idempotency"
        )

    old_preprod = old_evidence["PREPRODUCTION_RECEIPT"]
    new_preprod = new_evidence["PREPRODUCTION_RECEIPT"]
    old_records = _artifact_records(old_preprod, PREPRODUCTION_NAMES, label="preproduction")
    new_records = _artifact_records(new_preprod, PREPRODUCTION_NAMES, label="preproduction")
    for name in PREPRODUCTION_NAMES:
        left, right = old_records[name], new_records[name]
        if left.get("path") != right.get("path"):
            raise PermissionError(f"preproduction source path changed for {name}")
        content_changed = (
            _as_sha256(left.get("sha256")) != _as_sha256(right.get("sha256"))
            or int(left.get("size_bytes") or -1) != int(right.get("size_bytes") or -2)
        )
        if content_changed and name not in COMPILER_DERIVED_PREPRODUCTION_NAMES:
            raise PermissionError(
                f"non-compiler preproduction artifact changed during remediation: {name}"
            )
    if _without_compiler_gate(old_preprod.get("gates"), normalize_order=True) != _without_compiler_gate(
        new_preprod.get("gates"), normalize_order=True
    ):
        raise PermissionError("preproduction gates changed outside compiler identity")
    for value in (old_preprod, new_preprod):
        if value.get("publication_authorized") is not False or value.get("technical_cost_brl") != 0:
            raise PermissionError("preproduction left the zero-cost unpublished envelope")

    def stable_work(value: dict[str, Any]) -> dict[str, Any]:
        result = deepcopy(value)
        for field in (
            "work_order_id",
            "treatment_order_id",
            "preproduction_receipt_id",
            "created_at",
        ):
            result.pop(field, None)
        (result.get("execution_contract") or {})["idempotency_key"] = "<DERIVED>"
        normalized_bindings = []
        for binding in result.get("evidence_bindings") or []:
            if binding.get("role") in {"TREATMENT_ORDER", "PREPRODUCTION_RECEIPT"}:
                normalized_bindings.append(
                    {"role": binding["role"], "source_path": binding["source_path"]}
                )
            else:
                normalized_bindings.append(binding)
        result["evidence_bindings"] = normalized_bindings
        result["gates"] = [
            {key: item[key] for key in ("gate", "status", "reason") if key in item}
            for item in result.get("gates") or []
        ]
        return result

    if stable_work(old_work) != stable_work(new_work):
        raise PermissionError("release work order changed outside compiler-derived lineage")

    def stable_input(value: dict[str, Any]) -> dict[str, Any]:
        result = deepcopy(value)
        for field in (
            "receipt_id",
            "work_order_id",
            "treatment_order_id",
            "preproduction_receipt_id",
            "created_at",
        ):
            result.pop(field, None)
        result["artifacts"] = [item["path"] for item in result.get("artifacts") or []]
        result["work_order"] = "<HASH_BOUND_WORK_ORDER>"
        normalized_bindings = []
        for binding in result.get("evidence_bindings") or []:
            if binding.get("role") in {"TREATMENT_ORDER", "PREPRODUCTION_RECEIPT"}:
                normalized_bindings.append(
                    {"role": binding["role"], "source_path": binding["source_path"]}
                )
            else:
                normalized_bindings.append(binding)
        result["evidence_bindings"] = normalized_bindings
        measurements = result.get("measurements") or {}
        for field in (
            "maximum_single_asset_runtime_share",
            "top_six_asset_runtime_share",
        ):
            measurements.pop(field, None)
        result["gates"] = [item.get("gate") for item in result.get("gates") or []]
        return result

    if stable_input(old_receipt) != stable_input(new_receipt):
        raise PermissionError("production input contract changed outside compiler/timeline lineage")

    values = {
        "TREATMENT_ORDER": (old_order, new_order),
        "FORMAT_SCOPE": (old_evidence["FORMAT_SCOPE"], new_evidence["FORMAT_SCOPE"]),
        "PREPRODUCTION_RECEIPT": (old_preprod, new_preprod),
        "RELEASE_WORK_ORDER": (old_work, new_work),
        "PRODUCTION_INPUT_RECEIPT": (old_receipt, new_receipt),
    }
    return [
        {
            "document": label,
            "historical_content_sha256": _content_hash(before),
            "authoritative_content_sha256": _content_hash(after),
            "changed_paths": _diff_paths(before, after),
            "allowed_change_classes": [
                "COMPILER_IDENTITY",
                "VOICE_SLOT_TIMING",
                "HASH_DERIVED_LINEAGE",
                "TIMELINE_DERIVED_MEASUREMENT",
            ],
            "status": "PASS",
        }
        for label, (before, after) in values.items()
    ]


def _derived_token_map(
    order: dict[str, Any],
    work: dict[str, Any],
    receipt: dict[str, Any],
    documents: dict[str, dict[str, Any]],
) -> dict[str, str]:
    tokens: dict[str, str] = {}
    explicit = {
        "order_id": order.get("order_id"),
        "work_order_id": work.get("work_order_id"),
        "preproduction_receipt_id": receipt.get("preproduction_receipt_id"),
        "production_input_receipt_id": receipt.get("receipt_id"),
    }
    for name, document in documents.items():
        for key in (
            "decision_id",
            "brief_id",
            "narrative_id",
            "style_bible_id",
            "treatment_plan_id",
            "allocation_id",
            "take_plan_id",
            "creative_direction_decision_id",
        ):
            if document.get(key):
                explicit[f"{name}:{key}"] = document[key]
    for label, value in explicit.items():
        if value:
            tokens[str(value)] = f"<DERIVED:{label}>"
    for document in documents.values():
        if document.get("created_at"):
            tokens[str(document["created_at"])] = "<DERIVED:created_at>"
    return tokens


def _validate_rights_and_timeline(
    root: Path,
    *,
    documents: dict[str, dict[str, Any]],
    library: dict[str, Any],
) -> dict[str, Any]:
    allocation = documents["asset_allocation.json"]
    take_plan = documents["take_plan.json"]
    allocations = allocation.get("takes") or []
    takes = take_plan.get("takes") or []
    if not allocations or len(allocations) != len(takes):
        raise PermissionError("production allocation/take-plan cardinality diverged")
    assets = {item.get("asset_id"): item for item in library.get("assets") or []}
    if len(assets) != len(library.get("assets") or []):
        raise PermissionError("asset library contains duplicate identities")
    prior_end = 0
    used_assets: set[str] = set()
    for index, (allocated, take) in enumerate(zip(allocations, takes)):
        start, end = int(take.get("start_ms", -1)), int(take.get("end_ms", -1))
        duration = end - start
        if (
            take.get("take_id") != allocated.get("take_id")
            or start != prior_end
            or duration <= 0
            or int(allocated.get("duration_ms") or -1) != duration
            or allocated.get("source_start_ms") is None
            or allocated.get("source_end_ms") is None
            or int(allocated["source_end_ms"])
            - int(allocated["source_start_ms"])
            != duration
            or take.get("cost") != 0
        ):
            raise PermissionError(f"timeline/allocation mismatch at take index {index}")
        if index < 3:
            expected_start = sum(HOOK_SLOT_MS[:index])
            expected_end = sum(HOOK_SLOT_MS[: index + 1])
            if start != expected_start or end != expected_end:
                raise PermissionError("the protected 0-1/1-3/3-8 second slots changed")
        asset = assets.get(allocated.get("asset_id"))
        if not isinstance(asset, dict):
            raise PermissionError(f"allocation references an unknown asset at take index {index}")
        source_path = _resolve_asset_path(root, str(asset.get("uri") or "")).resolve()
        rights_path = _resolve_asset_path(root, str(asset.get("rights_evidence_uri") or "")).resolve()
        if (
            asset.get("production_eligible") is not True
            or asset.get("commercial_use") is not True
            or asset.get("content_quality_gate") != "PASS"
            or asset.get("rights_status") not in RIGHTS_OK
            or metadata_publicity_risks(asset)
            or allocated.get("asset_role") != asset.get("semantic_role")
            or allocated.get("content_hash") != asset.get("content_hash")
            or allocated.get("rights_status") != asset.get("rights_status")
            or (root / str(allocated.get("source_path") or "")).resolve() != source_path
            or (root / str(allocated.get("rights_evidence_ref") or "")).resolve()
            != rights_path
            or (take.get("rights") or {}).get("status") != allocated.get("rights_status")
            or (root / str((take.get("rights") or {}).get("evidence_ref") or "")).resolve()
            != rights_path
        ):
            raise PermissionError(f"rights/library binding diverged at take index {index}")
        # ``0`` is a valid and frequent media offset (notably for the first
        # hook take).  Do not use truthiness while validating numeric offsets:
        # it silently rewrites a legitimate zero to the ``-1`` sentinel and
        # falsely reports a timeline/allocation mismatch.
        source_start, source_end = int(allocated["source_start_ms"]), int(
            allocated["source_end_ms"]
        )
        if not any(
            int(item["start_ms"]) <= source_start < source_end <= int(item["end_ms"])
            for item in asset.get("safe_ranges") or []
        ):
            raise PermissionError(f"allocation escaped a rights-safe range at take index {index}")
        expected_origin = (
            f"{allocated['source_path']}#t={source_start / 1000:.3f},{source_end / 1000:.3f}"
        )
        if take.get("asset_origin") != expected_origin:
            raise PermissionError(f"take origin is not derived from allocation at index {index}")
        prior_end = end
        used_assets.add(str(allocated["asset_id"]))
    if allocation.get("publication_authorized") is not False or allocation.get(
        "technical_cost_brl"
    ) != 0:
        raise PermissionError("asset allocation left the zero-cost unpublished envelope")
    total_cost = take_plan.get("total_cost") or {}
    if total_cost.get("currency") != "BRL" or total_cost.get("external") != 0:
        raise PermissionError("take plan contains non-zero external cost")
    return {
        "take_count": len(takes),
        "unique_asset_count": len(used_assets),
        "timeline_end_ms": prior_end,
        "allocation_takes_sha256": _content_hash(allocations),
        "take_plan_takes_sha256": _content_hash(takes),
    }


def _production_contract_transition(
    *,
    old_order: dict[str, Any],
    old_work: dict[str, Any],
    old_receipt: dict[str, Any],
    old_documents: dict[str, dict[str, Any]],
    new_order: dict[str, Any],
    new_work: dict[str, Any],
    new_receipt: dict[str, Any],
    new_documents: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    old_tokens = _derived_token_map(old_order, old_work, old_receipt, old_documents)
    new_tokens = _derived_token_map(new_order, new_work, new_receipt, new_documents)
    for name in (
        "creative_direction_decision.json",
        "channel_style_bible.json",
        "creative_treatment_plan.json",
    ):
        before = _replace_strings(deepcopy(old_documents[name]), old_tokens)
        after = _replace_strings(deepcopy(new_documents[name]), new_tokens)
        if before != after:
            raise PermissionError(f"{name} changed outside hash-derived compiler lineage")

    old_allocation = old_documents["asset_allocation.json"]
    new_allocation = new_documents["asset_allocation.json"]
    old_signature = [
        (item.get("take_id"), item.get("required_role"), item.get("prior_episode_overlap_ms"))
        for item in old_allocation.get("takes") or []
    ]
    new_signature = [
        (item.get("take_id"), item.get("required_role"), item.get("prior_episode_overlap_ms"))
        for item in new_allocation.get("takes") or []
    ]
    if old_signature != new_signature:
        raise PermissionError("asset allocation changed take identity, semantic role or rights overlap")

    old_plan = _replace_strings(deepcopy(old_documents["take_plan.json"]), old_tokens)
    new_plan = _replace_strings(deepcopy(new_documents["take_plan.json"]), new_tokens)
    for plan in (old_plan, new_plan):
        plan.pop("created_at", None)
        plan.pop("take_plan_id", None)
        plan.pop("style_bible_id", None)
        plan.pop("creative_direction_decision_id", None)
        for index, take in enumerate(plan.get("takes") or []):
            for field in (
                "start_ms",
                "end_ms",
                "intended_emotion",
                "media_type",
                "environment",
                "asset_origin",
                "rights",
                "semantic_alignment",
            ):
                take.pop(field, None)
            if index < 2:
                take["narration"] = "<COMPILER_VOICE_SLOT_COPY>"
    if old_plan != new_plan:
        raise PermissionError("take plan changed outside voice slots, timeline or allocation derivation")
    old_takes = old_documents["take_plan.json"].get("takes") or []
    new_takes = new_documents["take_plan.json"].get("takes") or []
    if [item.get("narration") for item in old_takes[2:]] != [
        item.get("narration") for item in new_takes[2:]
    ]:
        raise PermissionError("body narration changed during compiler/voice-slot remediation")

    records: list[dict[str, Any]] = []
    for name in PRODUCTION_NAMES:
        records.append(
            {
                "document": name,
                "historical_content_sha256": _content_hash(old_documents[name]),
                "authoritative_content_sha256": _content_hash(new_documents[name]),
                "changed_paths": _diff_paths(old_documents[name], new_documents[name]),
                "allowed_change_classes": [
                    "HASH_DERIVED_LINEAGE",
                    "VOICE_SLOT_TIMING",
                    "TIMELINE_DERIVATION",
                    "DETERMINISTIC_RIGHTS_SAFE_ALLOCATION",
                ],
                "status": "PASS",
            }
        )
    return records


def _verify_authoritative_production_rebuild(
    root: Path,
    *,
    receipt: dict[str, Any],
    work_order: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
    documents: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    preprod = evidence["PREPRODUCTION_RECEIPT"]
    records = _artifact_records(preprod, PREPRODUCTION_NAMES, label="preproduction")
    values: dict[str, dict[str, Any]] = {}
    expected_parent = (
        root
        / "output/operations/phase6/production/preproduction-artifacts"
        / str(preprod["receipt_id"])
    ).resolve()
    for name in PREPRODUCTION_NAMES:
        record = records[name]
        immutable_path = record.get("immutable_path")
        if not immutable_path:
            raise PermissionError("authoritative preproduction lacks immutable artifact bytes")
        expected = expected_parent / name
        actual = (root / str(immutable_path)).resolve()
        if actual != expected:
            raise PermissionError(f"authoritative preproduction path is not canonical for {name}")
        value, _ = _read_bound_json(
            root,
            path=actual,
            expected_sha256=str(record["sha256"]),
            expected_size=int(record["size_bytes"]),
            expected_parent=expected_parent,
            label=f"authoritative preproduction artifact {name}",
        )
        values[name] = value
    timestamp = str(receipt["created_at"])
    order = evidence["TREATMENT_ORDER"]
    blueprint = values["take_blueprint.json"]
    allocation = _allocate_assets(root, blueprint, timestamp)
    decision = _creative_decision(
        root,
        order,
        values["editorial_brief.json"],
        values["narrative_script.json"],
        work_order,
        timestamp,
    )
    bible = _derive_style_bible(root, decision, allocation, timestamp)
    treatment = _creative_treatment(order, blueprint, timestamp)
    rebuilt = {
        "creative_direction_decision.json": decision,
        "channel_style_bible.json": bible,
        "creative_treatment_plan.json": treatment,
        "asset_allocation.json": allocation,
        "take_plan.json": _take_plan(
            decision, bible, blueprint, allocation, treatment, timestamp
        ),
    }
    mismatches = [name for name in PRODUCTION_NAMES if rebuilt[name] != documents[name]]
    if mismatches:
        raise PermissionError(
            "authoritative production does not reproduce from its exact compiler inputs: "
            + ",".join(mismatches)
        )
    return {
        "status": "PASS",
        "preproduction_receipt_id": str(preprod["receipt_id"]),
        "rebuilt_documents": list(PRODUCTION_NAMES),
        "rebuilt_bundle_sha256": _content_hash(rebuilt),
    }


def _lineage_side(
    root: Path,
    *,
    receipt: dict[str, Any],
    work_order: dict[str, Any],
    production_lineage: dict[str, Any],
) -> dict[str, Any]:
    work_binding = receipt.get("work_order") or {}
    return {
        **production_lineage,
        "work_order": {
            "identity": str(work_order["work_order_id"]),
            "path": str(work_binding["path"]),
            "sha256": str(work_binding["sha256"]),
            "size_bytes": int(work_binding["size_bytes"]),
        },
        "evidence_bindings": deepcopy(work_order.get("evidence_bindings") or []),
    }


def _prove_pre_effect_compiler_voice_remediation(
    root: Path,
    *,
    historical: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
    authoritative: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
    media_unit: dict[str, Any],
) -> dict[str, Any]:
    old_receipt, old_work, old_evidence = historical
    new_receipt, new_work, new_evidence = authoritative
    transition = _compiler_transition(
        old_evidence["TREATMENT_ORDER"], new_evidence["TREATMENT_ORDER"]
    )
    lineage_diffs = _lineage_contract_documents(historical, authoritative)
    if old_receipt.get("asset_residency") != new_receipt.get("asset_residency"):
        raise PermissionError("asset-residency authority changed during compiler remediation")
    old_library_binding = next(
        item for item in old_work["evidence_bindings"] if item["role"] == "ASSET_LIBRARY"
    )
    new_library_binding = next(
        item for item in new_work["evidence_bindings"] if item["role"] == "ASSET_LIBRARY"
    )
    if old_library_binding != new_library_binding:
        raise PermissionError("rights-library authority changed during compiler remediation")
    old_documents, old_production_lineage = _production_bundle(
        root, receipt=old_receipt, archived=True
    )
    new_documents, new_production_lineage = _production_bundle(
        root, receipt=new_receipt, archived=False
    )
    old_timeline = _validate_rights_and_timeline(
        root, documents=old_documents, library=old_evidence["ASSET_LIBRARY"]
    )
    new_timeline = _validate_rights_and_timeline(
        root, documents=new_documents, library=new_evidence["ASSET_LIBRARY"]
    )
    if old_timeline["take_count"] != new_timeline["take_count"]:
        raise PermissionError("compiler remediation changed the take count")
    production_diffs = _production_contract_transition(
        old_order=old_evidence["TREATMENT_ORDER"],
        old_work=old_work,
        old_receipt=old_receipt,
        old_documents=old_documents,
        new_order=new_evidence["TREATMENT_ORDER"],
        new_work=new_work,
        new_receipt=new_receipt,
        new_documents=new_documents,
    )
    deterministic_rebuild = _verify_authoritative_production_rebuild(
        root,
        receipt=new_receipt,
        work_order=new_work,
        evidence=new_evidence,
        documents=new_documents,
    )
    changed_path_count = sum(
        len(item["changed_paths"]) for item in lineage_diffs + production_diffs
    )
    if changed_path_count == 0:
        raise PermissionError("pre-effect compiler remediation contains no recorded change")
    rights_authority = {
        "asset_residency_sha256": str(new_receipt["asset_residency"]["sha256"]),
        "asset_library_sha256": str(new_library_binding["sha256"]),
    }
    proof: dict[str, Any] = {
        "schema_version": "1.0.0",
        "policy_version": PRE_EFFECT_REMEDIATION_POLICY_VERSION,
        "supersession_class": PRE_EFFECT_SUPERSESSION_CLASS,
        "status": "PASS",
        "media_unit_key": str(media_unit["media_unit_key"]),
        "superseded_input_receipt_id": str(old_receipt["receipt_id"]),
        "authoritative_input_receipt_id": str(new_receipt["receipt_id"]),
        "allowed_change_classes": [
            "COMPILER_IDENTITY",
            "VOICE_SLOT_TIMING",
            "HASH_DERIVED_LINEAGE",
            "TIMELINE_DERIVATION",
            "DETERMINISTIC_RIGHTS_SAFE_ALLOCATION",
        ],
        "stable_contract": {
            "operation_id": media_unit["operation_id"],
            "channel_id": media_unit["channel_id"],
            "diagnosis": media_unit["diagnosis"],
            "protocol": media_unit["protocol"],
            "treatment_variable": media_unit["treatment_variable"],
            "candidate": media_unit["candidate"],
            "format_pack": media_unit["format_pack"],
            "pipeline": media_unit["pipeline"],
            "quality_profile": media_unit["quality_profile"],
            "rights_authority": rights_authority,
            "publication_authorized": False,
            "technical_cost_brl": 0,
        },
        "compiler_transition": transition,
        "lineage": {
            "superseded": _lineage_side(
                root,
                receipt=old_receipt,
                work_order=old_work,
                production_lineage=old_production_lineage,
            ),
            "authoritative": _lineage_side(
                root,
                receipt=new_receipt,
                work_order=new_work,
                production_lineage=new_production_lineage,
            ),
        },
        "document_diffs": lineage_diffs + production_diffs,
        "timeline": {"superseded": old_timeline, "authoritative": new_timeline},
        "validation": {
            "same_semantic_media_unit": True,
            "same_operation_channel_protocol_variable_candidate": True,
            "same_rights_authority": True,
            "zero_cost_preserved": True,
            "publication_lock_preserved": True,
            "historical_production_archive_verified": True,
            "authoritative_production_rebuilt_exactly": True,
            "only_allowlisted_differences": True,
            "external_api_calls": 0,
            "publication_effects": 0,
            "technical_cost_brl": 0,
        },
        "deterministic_rebuild": deterministic_rebuild,
    }
    proof["proof_sha256"] = _content_hash(proof)
    return proof


def _exact_rebuild_records(
    root: Path,
    *,
    historical_receipt: dict[str, Any],
    current_receipt: dict[str, Any],
    expected_names: tuple[str, ...],
    replacements: dict[str, str],
    label: str,
) -> list[dict[str, Any]]:
    historical = _artifact_records(historical_receipt, expected_names, label=label)
    current = _artifact_records(current_receipt, expected_names, label=label)
    proof: list[dict[str, Any]] = []
    for name in expected_names:
        old_record, new_record = historical[name], current[name]
        if (
            old_record.get("path") != new_record.get("path")
            or old_record.get("size_bytes") != new_record.get("size_bytes")
        ):
            raise PermissionError(f"{label} path/size changed for {name}")
        path = (root / str(new_record["path"])).resolve()
        if not path.is_file() or _sha256_file(path) != _as_sha256(new_record["sha256"]):
            raise PermissionError(f"current {label} artifact is not receipt-bound: {name}")
        current_value = _read(path)
        rebuilt = _replace_strings(deepcopy(current_value), replacements)
        rebuilt_hash = _sha256_bytes(_serialized_like(path, rebuilt))
        if rebuilt_hash != _as_sha256(old_record["sha256"]):
            raise PermissionError(
                f"{label} {name} cannot be rebuilt byte-exactly with allowed identity tokens"
            )
        proof.append(
            {
                "path": str(new_record["path"]),
                "historical_sha256": _as_sha256(old_record["sha256"]),
                "authoritative_sha256": _as_sha256(new_record["sha256"]),
                "historical_rebuild_sha256": rebuilt_hash,
                "size_bytes": int(new_record["size_bytes"]),
                "status": "PASS",
            }
        )
    return proof


def _normalize_evidence_bindings(
    value: dict[str, Any], dynamic_roles: set[str]
) -> dict[str, Any]:
    normalized = deepcopy(value)
    bindings = normalized.get("evidence_bindings") or []
    for item in bindings:
        role = str(item.get("role") or "")
        if role in dynamic_roles:
            item["identity"] = f"<IDENTITY:{role}>"
            item["immutable_path"] = f"<IMMUTABLE_PATH:{role}>"
            item["sha256"] = f"<SHA256:{role}>"
            item["size_bytes"] = f"<SIZE:{role}>"
    return normalized


def _normalize_artifact_hashes(value: dict[str, Any]) -> dict[str, Any]:
    normalized = deepcopy(value)
    for item in normalized.get("artifacts") or []:
        name = Path(str(item.get("path") or "")).name
        item["sha256"] = f"<ARTIFACT_SHA256:{name}>"
    return normalized


def _evidence_by_role(evidence: dict[str, dict[str, Any]], role: str) -> dict[str, Any]:
    value = evidence.get(role)
    if not isinstance(value, dict):
        raise PermissionError(f"frozen evidence is missing role {role}")
    return value


def _prove_identity_only_remediation(
    root: Path,
    *,
    historical: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
    authoritative: tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]],
    media_unit: dict[str, Any],
) -> dict[str, Any]:
    """Prove the old/new commands differ only by the baseline-path correction.

    Historical mutable artifacts were not archived by the legacy compiler.  To
    avoid treating matching high-level labels as equivalence, this proof takes
    the currently receipt-bound JSON and applies only the hash-derived ID and
    timestamp substitutions implied by the two immutable chains.  Every
    reconstructed byte stream must match the historical receipt hash exactly.
    Any copy, timing, asset, style, voice, profile or pipeline change therefore
    fails closed.
    """

    old_receipt, old_work, old_evidence = historical
    new_receipt, new_work, new_evidence = authoritative
    old_order = _evidence_by_role(old_evidence, "TREATMENT_ORDER")
    new_order = _evidence_by_role(new_evidence, "TREATMENT_ORDER")
    old_scope = _evidence_by_role(old_evidence, "FORMAT_SCOPE")
    new_scope = _evidence_by_role(new_evidence, "FORMAT_SCOPE")
    old_preprod = _evidence_by_role(old_evidence, "PREPRODUCTION_RECEIPT")
    new_preprod = _evidence_by_role(new_evidence, "PREPRODUCTION_RECEIPT")

    snapshot_id = str((new_order.get("baseline") or {}).get("snapshot_id") or "")
    video_id = str((new_order.get("baseline") or {}).get("video_id") or "")
    immutable_baseline = (
        f"output/operations/phase6/metrics/{video_id}/{snapshot_id}.json"
    )
    legacy_baseline = f"output/operations/phase6/metrics/{video_id}/latest.json"
    if (
        not snapshot_id
        or not video_id
        or legacy_baseline not in _canonical(old_order)
        or immutable_baseline not in _canonical(new_order)
        or legacy_baseline not in _canonical(old_scope)
        or immutable_baseline not in _canonical(new_scope)
    ):
        raise PermissionError(
            "identity remediation is not the exact latest-to-immutable baseline correction"
        )

    old_tokens = {
        str(old_order["order_id"]): "<TREATMENT_ORDER_ID>",
        str(old_scope["receipt_id"]): "<FORMAT_SCOPE_ID>",
        str(old_preprod["receipt_id"]): "<PREPRODUCTION_ID>",
        str(old_work["work_order_id"]): "<WORK_ORDER_ID>",
        str(old_receipt["receipt_id"]): "<PRODUCTION_INPUT_ID>",
        str(old_order["created_at"]): "<ORDER_CREATED_AT>",
        str(old_scope["created_at"]): "<SCOPE_CREATED_AT>",
        str(old_preprod["created_at"]): "<PREPRODUCTION_CREATED_AT>",
        str(old_work["created_at"]): "<WORK_CREATED_AT>",
        str(old_receipt["created_at"]): "<INPUT_CREATED_AT>",
        legacy_baseline: "<IMMUTABLE_BASELINE_PATH>",
    }
    new_tokens = {
        str(new_order["order_id"]): "<TREATMENT_ORDER_ID>",
        str(new_scope["receipt_id"]): "<FORMAT_SCOPE_ID>",
        str(new_preprod["receipt_id"]): "<PREPRODUCTION_ID>",
        str(new_work["work_order_id"]): "<WORK_ORDER_ID>",
        str(new_receipt["receipt_id"]): "<PRODUCTION_INPUT_ID>",
        str(new_order["created_at"]): "<ORDER_CREATED_AT>",
        str(new_scope["created_at"]): "<SCOPE_CREATED_AT>",
        str(new_preprod["created_at"]): "<PREPRODUCTION_CREATED_AT>",
        str(new_work["created_at"]): "<WORK_CREATED_AT>",
        str(new_receipt["created_at"]): "<INPUT_CREATED_AT>",
        immutable_baseline: "<IMMUTABLE_BASELINE_PATH>",
    }
    for role in ("TREATMENT_ORDER", "FORMAT_SCOPE", "PREPRODUCTION_RECEIPT"):
        old_binding = next(
            item for item in old_work["evidence_bindings"] if item["role"] == role
        )
        new_binding = next(
            item for item in new_work["evidence_bindings"] if item["role"] == role
        )
        for field in ("identity", "immutable_path", "sha256"):
            old_tokens[str(old_binding[field])] = f"<{role}:{field}>"
            new_tokens[str(new_binding[field])] = f"<{role}:{field}>"

    comparisons = [
        _normalized_exact(
            "TREATMENT_ORDER",
            old_order,
            new_order,
            before_replacements=old_tokens,
            after_replacements=new_tokens,
        ),
        _normalized_exact(
            "FORMAT_SCOPE",
            old_scope,
            new_scope,
            before_replacements=old_tokens,
            after_replacements=new_tokens,
        ),
    ]

    normalized_old_preprod = _normalize_artifact_hashes(old_preprod)
    normalized_new_preprod = _normalize_artifact_hashes(new_preprod)
    comparisons.append(
        _normalized_exact(
            "PREPRODUCTION_RECEIPT",
            normalized_old_preprod,
            normalized_new_preprod,
            before_replacements=old_tokens,
            after_replacements=new_tokens,
        )
    )

    dynamic_roles = {"TREATMENT_ORDER", "FORMAT_SCOPE", "PREPRODUCTION_RECEIPT"}
    normalized_old_work = _normalize_evidence_bindings(old_work, dynamic_roles)
    normalized_new_work = _normalize_evidence_bindings(new_work, dynamic_roles)
    comparisons.append(
        _normalized_exact(
            "RELEASE_WORK_ORDER",
            normalized_old_work,
            normalized_new_work,
            before_replacements=old_tokens,
            after_replacements=new_tokens,
        )
    )

    normalized_old_input = _normalize_artifact_hashes(
        _normalize_evidence_bindings(old_receipt, dynamic_roles)
    )
    normalized_new_input = _normalize_artifact_hashes(
        _normalize_evidence_bindings(new_receipt, dynamic_roles)
    )
    for value in (normalized_old_input, normalized_new_input):
        binding = value.get("work_order") or {}
        binding["path"] = "<WORK_ORDER_PATH>"
        binding["sha256"] = "<WORK_ORDER_SHA256>"
        binding["size_bytes"] = "<WORK_ORDER_SIZE>"
    comparisons.append(
        _normalized_exact(
            "PRODUCTION_INPUT_RECEIPT",
            normalized_old_input,
            normalized_new_input,
            before_replacements=old_tokens,
            after_replacements=new_tokens,
        )
    )

    preprod_records = _artifact_records(
        new_preprod, PREPRODUCTION_NAMES, label="preproduction"
    )
    preprod_values = {
        name: _read(root / str(preprod_records[name]["path"]))
        for name in PREPRODUCTION_NAMES
    }
    concept = preprod_values["creative_concept_decision.json"]
    brief = preprod_values["editorial_brief.json"]
    script = preprod_values["narrative_script.json"]
    blueprint = preprod_values["take_blueprint.json"]

    current_concept_id = _stable_id(
        "phase6-creative-concept",
        str(new_order["order_id"]),
        str(concept["signal_snapshot_id"]),
        str(concept["compiler_version"]),
        str((concept.get("selected_concept") or {})["concept_id"]),
    )
    historical_concept_id = _stable_id(
        "phase6-creative-concept",
        str(old_order["order_id"]),
        str(concept["signal_snapshot_id"]),
        str(concept["compiler_version"]),
        str((concept.get("selected_concept") or {})["concept_id"]),
    )
    current_brief_id = _stable_id(
        "brief-phase6",
        str(new_order["order_id"]),
        str((new_order.get("market_candidate") or {})["candidate_id"]),
        current_concept_id,
    )
    historical_brief_id = _stable_id(
        "brief-phase6",
        str(old_order["order_id"]),
        str((old_order.get("market_candidate") or {})["candidate_id"]),
        historical_concept_id,
    )
    current_script_id = _stable_id(
        "script-phase6",
        current_brief_id,
        str((new_order.get("treatment") or {})["variable"]),
        str(script["full_text"]),
    )
    historical_script_id = _stable_id(
        "script-phase6",
        historical_brief_id,
        str((old_order.get("treatment") or {})["variable"]),
        str(script["full_text"]),
    )
    current_blueprint_id = _stable_id(
        "take-blueprint", current_script_id, str(new_order["order_id"])
    )
    historical_blueprint_id = _stable_id(
        "take-blueprint", historical_script_id, str(old_order["order_id"])
    )
    if (
        concept.get("decision_id") != current_concept_id
        or brief.get("brief_id") != current_brief_id
        or script.get("script_id") != current_script_id
        or blueprint.get("blueprint_id") != current_blueprint_id
    ):
        raise PermissionError("current preproduction IDs are not hash-derived")

    rebuild_tokens = {
        str(new_order["order_id"]): str(old_order["order_id"]),
        current_concept_id: historical_concept_id,
        current_brief_id: historical_brief_id,
        current_script_id: historical_script_id,
        current_blueprint_id: historical_blueprint_id,
        str(new_preprod["created_at"]): str(old_preprod["created_at"]),
    }
    rebuilt_preproduction = _exact_rebuild_records(
        root,
        historical_receipt=old_preprod,
        current_receipt=new_preprod,
        expected_names=PREPRODUCTION_NAMES,
        replacements=rebuild_tokens,
        label="preproduction",
    )

    production_records = _artifact_records(
        new_receipt, PRODUCTION_NAMES, label="production"
    )
    production_values = {
        name: _read(root / str(production_records[name]["path"]))
        for name in PRODUCTION_NAMES
    }
    allocation = production_values["asset_allocation.json"]
    decision = production_values["creative_direction_decision.json"]
    bible = production_values["channel_style_bible.json"]
    treatment = production_values["creative_treatment_plan.json"]
    take_plan = production_values["take_plan.json"]
    allocation_parts = [
        f"{item['asset_id']}:{item['source_start_ms']}:{item['source_end_ms']}"
        for item in allocation.get("takes") or []
    ]
    current_allocation_id = _stable_id(
        "phase6-allocation", current_blueprint_id, *allocation_parts
    )
    historical_allocation_id = _stable_id(
        "phase6-allocation", historical_blueprint_id, *allocation_parts
    )
    current_decision_id = _stable_id(
        "phase6-creative-decision",
        str(new_order["order_id"]),
        current_brief_id,
        current_script_id,
    )
    historical_decision_id = _stable_id(
        "phase6-creative-decision",
        str(old_order["order_id"]),
        historical_brief_id,
        historical_script_id,
    )
    source_bible = _read(
        root
        / "output/production/phase5/pilot-001/creative-v3/channel_style_bible.json"
    )
    current_bible_id = _stable_id(
        "phase6-style-bible",
        str(source_bible["style_bible_id"]),
        current_decision_id,
        current_allocation_id,
    )
    historical_bible_id = _stable_id(
        "phase6-style-bible",
        str(source_bible["style_bible_id"]),
        historical_decision_id,
        historical_allocation_id,
    )
    current_treatment_id = _stable_id(
        "phase6-creative-treatment",
        str(new_order["order_id"]),
        current_blueprint_id,
    )
    historical_treatment_id = _stable_id(
        "phase6-creative-treatment",
        str(old_order["order_id"]),
        historical_blueprint_id,
    )
    current_take_plan_id = _stable_id(
        "phase6-take-plan", current_decision_id, current_allocation_id
    )
    historical_take_plan_id = _stable_id(
        "phase6-take-plan", historical_decision_id, historical_allocation_id
    )
    if (
        allocation.get("allocation_id") != current_allocation_id
        or decision.get("decision_id") != current_decision_id
        or bible.get("style_bible_id") != current_bible_id
        or treatment.get("treatment_plan_id") != current_treatment_id
        or take_plan.get("take_plan_id") != current_take_plan_id
    ):
        raise PermissionError("current production IDs are not hash-derived")

    production_rebuild_tokens = {
        **rebuild_tokens,
        str(new_work["work_order_id"]): str(old_work["work_order_id"]),
        current_allocation_id: historical_allocation_id,
        current_decision_id: historical_decision_id,
        current_bible_id: historical_bible_id,
        current_treatment_id: historical_treatment_id,
        current_take_plan_id: historical_take_plan_id,
        str(new_receipt["created_at"]): str(old_receipt["created_at"]),
    }
    rebuilt_production = _exact_rebuild_records(
        root,
        historical_receipt=old_receipt,
        current_receipt=new_receipt,
        expected_names=PRODUCTION_NAMES,
        replacements=production_rebuild_tokens,
        label="production",
    )

    first_blueprint = (blueprint.get("takes") or [{}])[0]
    first_take = (take_plan.get("takes") or [{}])[0]
    duration = int(blueprint.get("total_estimated_duration_ms") or 0)
    duration_lock = blueprint.get("duration_lock") or {}
    locked = set((new_order.get("treatment") or {}).get("locked_constants") or [])
    pipeline = _evidence_by_role(new_evidence, "PIPELINE")
    if (
        str((new_order.get("treatment") or {}).get("variable")) != "TOPIC_ANGLE"
        or not EXPECTED_LOCKED_CONSTANTS.issubset(locked)
        or media_unit.get("format_pack") != EXPECTED_FORMAT_PACK
        or media_unit.get("pipeline") != EXPECTED_PIPELINE
        or media_unit.get("quality_profile") != "STANDARD"
        or pipeline.get("pipeline_id") != EXPECTED_PIPELINE["pipeline_id"]
        or pipeline.get("version") != EXPECTED_PIPELINE["version"]
        or int(first_blueprint.get("start_ms", -1)) != 0
        or int(first_blueprint.get("end_ms", -1)) != 1_000
        or first_take.get("start_ms") != first_blueprint.get("start_ms")
        or first_take.get("end_ms") != first_blueprint.get("end_ms")
        or first_take.get("narration") != first_blueprint.get("narration")
        or str(first_blueprint.get("narration") or "") != "Pause before panic."
        or duration_lock.get("minimum_ms") != EXPECTED_DURATION_BAND["minimum_ms"]
        or duration_lock.get("maximum_ms") != EXPECTED_DURATION_BAND["maximum_ms"]
        or duration_lock.get("observed_ms") != duration
        or duration_lock.get("status") != "PASS"
        or not EXPECTED_DURATION_BAND["minimum_ms"] <= duration <= EXPECTED_DURATION_BAND["maximum_ms"]
        or int((take_plan.get("takes") or [{}])[-1].get("end_ms", -1)) != duration
        or tuple(HOOK_SLOT_MS) != (1_000, 2_000, 5_000)
        or tuple(VOICE_SPEED_BY_TAKE_INDEX) != (1.20, 1.12, 1.06)
    ):
        raise PermissionError("preserved media execution contract is incomplete or drifted")
    if old_receipt.get("asset_residency") != new_receipt.get("asset_residency"):
        raise PermissionError("asset-residency authority changed during identity remediation")
    old_library = next(
        item for item in old_receipt["evidence_bindings"] if item["role"] == "ASSET_LIBRARY"
    )
    new_library = next(
        item for item in new_receipt["evidence_bindings"] if item["role"] == "ASSET_LIBRARY"
    )
    if old_library != new_library:
        raise PermissionError("asset-library binding changed during identity remediation")

    proof: dict[str, Any] = {
        "schema_version": "1.0.0",
        "policy_version": REMEDIATION_POLICY_VERSION,
        "status": "PASS",
        "media_unit_key": str(media_unit["media_unit_key"]),
        "superseded_input_receipt_id": str(old_receipt["receipt_id"]),
        "authoritative_input_receipt_id": str(new_receipt["receipt_id"]),
        "allowed_change_classes": [
            "IMMUTABLE_BASELINE_PATH_PIN",
            "HASH_DERIVED_ID_RECOMPUTATION",
            "ARTIFACT_CREATED_AT_RECOMPUTATION",
        ],
        "document_comparisons": comparisons,
        "preserved_contract": {
            "treatment_variable": "TOPIC_ANGLE",
            "diagnosis": media_unit["diagnosis"],
            "protocol": media_unit["protocol"],
            "candidate": media_unit["candidate"],
            "hook_0_1s": {
                "take_id": str(first_take["take_id"]),
                "start_ms": 0,
                "end_ms": 1_000,
                "narration_sha256": _content_hash(str(first_take["narration"])),
                "narration": str(first_take["narration"]),
            },
            "voice": {
                "voice_id": "am_onyx",
                "planning_profile_version": VOICE_TIMING_PROFILE_VERSION,
                "execution_contract_version": VOICE_EXECUTION_CONTRACT_VERSION,
                "speed_by_take_index": list(VOICE_SPEED_BY_TAKE_INDEX),
                "speed_ceiling": 1.25,
                "opportunistic_speedup_allowed": False,
            },
            "quality_profile": "STANDARD",
            "duration_band": {
                **EXPECTED_DURATION_BAND,
                "observed_ms": duration,
            },
            "format_pack": media_unit["format_pack"],
            "pipeline": media_unit["pipeline"],
            "asset_allocation": {
                "allocation_id": str(allocation["allocation_id"]),
                "take_count": len(allocation.get("takes") or []),
                "unique_asset_count": len(
                    {item["asset_id"] for item in allocation.get("takes") or []}
                ),
                "takes_content_hash": _content_hash(allocation.get("takes") or []),
                "asset_residency_sha256": str(
                    new_receipt["asset_residency"]["sha256"]
                ),
                "asset_library_sha256": str(new_library["sha256"]),
            },
            "publication_authorized": False,
            "technical_cost_brl": 0,
        },
        "exact_rebuild": {
            "preproduction": rebuilt_preproduction,
            "production": rebuilt_production,
            "all_historical_hashes_match": True,
        },
    }
    proof["proof_sha256"] = _content_hash(proof)
    return proof


def verify_media_supersession_decision(
    root: Path,
    *,
    superseded_input_receipt_id: str,
    authoritative_input_receipt_id: str,
) -> dict[str, Any]:
    """Recompute the complete unit and whitelist proof for the queue boundary."""

    project_root = root.resolve()
    historical = _load_historical_input_envelope(
        project_root, superseded_input_receipt_id
    )
    authoritative = _load_historical_input_envelope(
        project_root, authoritative_input_receipt_id
    )
    historical_unit = _media_unit(
        receipt=historical[0], work_order=historical[1], evidence=historical[2]
    )
    authoritative_unit = _media_unit(
        receipt=authoritative[0],
        work_order=authoritative[1],
        evidence=authoritative[2],
    )
    if historical_unit != authoritative_unit:
        raise PermissionError(
            "production inputs identify different semantic media units"
        )
    try:
        proof = _prove_identity_only_remediation(
            project_root,
            historical=historical,
            authoritative=authoritative,
            media_unit=authoritative_unit,
        )
    except PermissionError as identity_only_error:
        pre_effect = _prove_pre_effect_compiler_voice_remediation(
            project_root,
            historical=historical,
            authoritative=authoritative,
            media_unit=authoritative_unit,
        )
        return {
            "media_unit": authoritative_unit,
            "supersession_class": PRE_EFFECT_SUPERSESSION_CLASS,
            "pre_effect_remediation": pre_effect,
            "identity_only_rejection": str(identity_only_error),
        }
    return {"media_unit": authoritative_unit, "identity_remediation": proof}


def _input_reference(root: Path, receipt_id: str) -> dict[str, Any]:
    path = root / PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json"
    if not path.is_file():
        raise FileNotFoundError(f"immutable production-input receipt is missing: {receipt_id}")
    return {
        "receipt_id": receipt_id,
        "path": path.relative_to(root).as_posix(),
        "sha256": _sha256_file(path),
    }


def _load_historical_input_envelope(
    root: Path,
    receipt_id: str,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]]:
    """Validate frozen command evidence without reviving stale mutable artifacts."""

    if not receipt_id.startswith(INPUT_PATTERN):
        raise PermissionError("media job contains a non-canonical production-input identity")
    path = (root / PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json").resolve()
    if path.parent != (root / PRODUCTION_INPUT_RECEIPTS).resolve() or not path.is_file():
        raise PermissionError("historical production inputs escaped the immutable directory")
    receipt = _read(path)
    _validate(root, "phase6_production_inputs_receipt.schema.json", receipt)
    if (
        receipt.get("receipt_id") != receipt_id
        or receipt.get("schema_version") != "1.2.0"
        or receipt.get("action") != "PREPARE_VIDEO_2_INPUTS"
        or receipt.get("status") != "COMPILED"
        or receipt.get("channel_id") != CHANNEL_ID
        or receipt.get("next_action") != "SYNTHESIZE_VIDEO_2_VOICE"
        or receipt.get("publication_authorized") is not False
        or receipt.get("technical_cost_brl") != 0
    ):
        raise PermissionError("historical production-input envelope is not executable lineage")

    binding = receipt.get("work_order") or {}
    expected_work_path = (
        root
        / RELEASE_BASE
        / "work-orders"
        / f"{receipt.get('work_order_id')}.json"
    ).resolve()
    work_path = (root / str(binding.get("path") or "")).resolve()
    if (
        work_path != expected_work_path
        or not work_path.is_file()
        or _sha256_file(work_path) != binding.get("sha256")
        or work_path.stat().st_size != binding.get("size_bytes")
    ):
        raise PermissionError("historical production inputs lost the immutable work order")
    work_order = _read(work_path)
    _validate(root, "phase6_release_work_order.schema.json", work_order)
    if (
        work_order.get("work_order_id") != receipt["work_order_id"]
        or work_order.get("status") != "READY_TO_PREPARE"
        or work_order.get("action") != receipt["action"]
        or work_order.get("channel_id") != CHANNEL_ID
        or work_order.get("publication_authorized") is not False
        or work_order.get("technical_cost_brl") != 0
    ):
        raise PermissionError("historical work order no longer binds the media command")
    evidence = _verify_release_evidence_bindings(
        root, work_order, consume_frozen=True, historical_identity_only=True
    )
    if receipt.get("evidence_bindings") != work_order.get("evidence_bindings"):
        raise PermissionError("historical production inputs changed the frozen evidence chain")
    expected_receipt_id = _stable_id(
        "phase6-production-inputs",
        receipt["work_order_id"],
        binding["sha256"],
        receipt["asset_residency"]["sha256"],
        *[item["sha256"] for item in receipt["evidence_bindings"]],
        *[item["sha256"] for item in receipt["artifacts"]],
    )
    if expected_receipt_id != receipt_id:
        raise PermissionError("historical production-input identity is not hash-derived")
    return receipt, work_order, evidence


def _media_unit(
    *,
    receipt: dict[str, Any],
    work_order: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    order = evidence["TREATMENT_ORDER"]
    pipeline = evidence["PIPELINE"]
    protocol = order.get("protocol") or {}
    diagnosis = order.get("diagnosis") or {}
    candidate = order.get("market_candidate") or {}
    execution = order.get("execution_contract") or {}
    content = {
        "operation_id": str(order.get("operation_id") or ""),
        "channel_id": str(order.get("channel_id") or ""),
        "task_type": MEDIA_TASK,
        "production_action": MEDIA_ACTION,
        "treatment_action": str(order.get("action") or ""),
        "target_id": str(protocol.get("treatment_video_id") or ""),
        "baseline_snapshot_id": str((order.get("baseline") or {}).get("snapshot_id") or ""),
        "diagnosis": {
            "diagnosis_id": str(diagnosis.get("diagnosis_id") or ""),
            "content_hash": str(diagnosis.get("content_hash") or ""),
        },
        "protocol": {
            "protocol_id": str(protocol.get("protocol_id") or ""),
            "content_hash": str(protocol.get("content_hash") or ""),
        },
        "treatment_variable": str((order.get("treatment") or {}).get("variable") or ""),
        "candidate": {
            "candidate_id": str(candidate.get("candidate_id") or ""),
            "content_hash": str(candidate.get("selected_candidate_content_hash") or ""),
        },
        "format_pack": {
            "format_pack_id": str(execution.get("format_pack_id") or ""),
            "version": str(execution.get("format_pack_version") or ""),
        },
        "pipeline": {
            "pipeline_id": str(execution.get("pipeline_id") or ""),
            "version": str(pipeline.get("version") or ""),
        },
        "quality_profile": str(execution.get("quality_profile") or ""),
        "outputs_hash": _sha256_bytes(_canonical(order.get("outputs") or []).encode("utf-8")),
    }
    if (
        content["operation_id"] != work_order.get("operation_id")
        or content["channel_id"] != receipt.get("channel_id")
        or content["treatment_action"] != "COMPILE_VIDEO_2"
        or content["target_id"] != "phase6-video-2-prepublication"
        or not all(
            (
                content["baseline_snapshot_id"],
                content["diagnosis"]["diagnosis_id"],
                content["diagnosis"]["content_hash"],
                content["protocol"]["protocol_id"],
                content["protocol"]["content_hash"],
                content["treatment_variable"],
                content["candidate"]["candidate_id"],
                content["candidate"]["content_hash"],
                content["format_pack"]["format_pack_id"],
                content["format_pack"]["version"],
                content["pipeline"]["pipeline_id"],
                content["pipeline"]["version"],
                content["quality_profile"],
            )
        )
    ):
        raise PermissionError("production inputs do not identify one complete media unit")
    key = "phase6-media-unit-" + hashlib.sha256(
        _canonical(content).encode("utf-8")
    ).hexdigest()[:24]
    return {"media_unit_key": key, **content}


def verify_completed_phase6_media_authority(
    root: Path, *, authoritative_job_id: str, queue: TransactionalQueue,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Observe an exact completed tail; never elect, supersede or retry a job.

    The pre-effect reconciler intentionally accepts unfinished commands only.
    Completion must instead reopen the immutable graph from its canonical
    roots and prove that no other tail remains executable for this operation.
    """
    project_root = root.resolve()
    moment = now or datetime.now(timezone.utc)
    latest_path = project_root / RELEASE_BASE / "latest-production-inputs-receipt.json"
    latest_bytes = latest_path.read_bytes()
    latest = json.loads(latest_bytes.decode("utf-8-sig"))
    verify_production_inputs_receipt(
        project_root, receipt_path=latest_path,
        expected_receipt_id=latest.get("receipt_id"),
        required_action="PREPARE_VIDEO_2_INPUTS", recheck_decode=False,
    )
    receipt, work, evidence = _load_historical_input_envelope(project_root, latest["receipt_id"])
    unit = _media_unit(receipt=receipt, work_order=work, evidence=evidence)
    before = queue.snapshot(captured_at=moment)
    jobs = [job for job in before["jobs"] if job["task_type"] == MEDIA_TASK]
    edges = before.get("media_job_supersessions", [])
    ids = {job["job_id"] for job in jobs}
    if any(edge["state"] != "COMMITTED" or edge["superseded_job_id"] not in ids
           or edge["authoritative_job_id"] not in ids for edge in edges):
        raise QueueConflict("completed media graph has an uncommitted or foreign edge")
    if any(job.get("lease_owner") is not None or job.get("lease_until") is not None for job in jobs):
        raise QueueConflict("completed media graph retains a lease")
    key = f"{receipt['receipt_id']}:synthesize-render-standard-v2"
    matches = [job for job in jobs if job["idempotency_key"] == key]
    if len(matches) != 1:
        raise QueueConflict("completed media inputs do not have one exact job")
    job = matches[0]
    if not (
        job["job_id"] == authoritative_job_id == "job-" + hashlib.sha256(key.encode()).hexdigest()[:24]
        and job["operation_id"] == unit["operation_id"] and job["channel_id"] == CHANNEL_ID
        and job["payload"] == {"input_receipt_id": receipt["receipt_id"], "action": MEDIA_ACTION}
        and job["state"] == "SUCCEEDED" and job.get("last_error") is None
        and type(job.get("attempt_count")) is int and type(job.get("max_attempts")) is int
        and 0 < job["attempt_count"] <= job["max_attempts"]
        and isinstance(job.get("checkpoint"), dict) and bool(job["checkpoint"])
    ):
        raise QueueConflict("completed media job diverges from the exact current command")
    inbound = {edge["authoritative_job_id"] for edge in edges}
    visited: set[str] = set()
    found = 0
    for base in (item for item in jobs if item["job_id"] not in inbound):
        resolved = queue.resolve_media_job_authority(
            base["job_id"], expected_operation_id=unit["operation_id"],
            expected_channel_id=CHANNEL_ID, expected_task_type=MEDIA_TASK,
            require_canonical_root=True,
        )
        visited.add(base["job_id"])
        visited.update(edge["authoritative_job_id"] for edge in resolved["chain"])
        tail = resolved["authority_job"]
        if tail["job_id"] == job["job_id"]:
            if tail != job or (resolved["media_unit"] is not None and resolved["media_unit"] != unit):
                raise QueueConflict("completed media tail/semantic identity diverged")
            found += 1
            continue
        if tail["state"] not in {"SUCCEEDED", "DEAD_LETTER"}:
            raise QueueConflict("another media authority remains executable")
        historical = _load_historical_input_envelope(project_root, tail["payload"]["input_receipt_id"])
        other_unit = _media_unit(receipt=historical[0], work_order=historical[1], evidence=historical[2])
        if tail["state"] == "SUCCEEDED" and other_unit == unit:
            raise QueueConflict("another completed same-unit authority is not superseded")
    if found != 1 or visited != ids:
        raise QueueConflict("completed media authority graph is ambiguous or disconnected")
    after = queue.snapshot(captured_at=moment)
    if (any(before[key] != after[key] for key in ("jobs", "media_job_supersessions"))
            or latest_path.read_bytes() != latest_bytes):
        raise QueueConflict("completed media authority changed during verification")
    return job


def reconcile_phase6_media_authority(
    root: Path = ROOT,
    *,
    authoritative_job_id: str | None = None,
    now: datetime | None = None,
    queue: TransactionalQueue | None = None,
    current_verifier: Callable[..., dict[str, Any]] = verify_production_inputs_receipt,
) -> dict[str, Any]:
    """Elect the current input lineage and supersede same-unit stale commands."""

    project_root = root.resolve()
    moment = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    latest_path = project_root / RELEASE_BASE / "latest-production-inputs-receipt.json"
    if not latest_path.is_file():
        raise FileNotFoundError("current production-input receipt is unavailable")
    latest = _read(latest_path)
    current_verifier(
        project_root,
        receipt_path=latest_path,
        expected_receipt_id=latest.get("receipt_id"),
        required_action="PREPARE_VIDEO_2_INPUTS",
        recheck_decode=False,
    )
    current_receipt, current_work, current_evidence = _load_historical_input_envelope(
        project_root, str(latest["receipt_id"])
    )
    unit = _media_unit(
        receipt=current_receipt,
        work_order=current_work,
        evidence=current_evidence,
    )
    queue = queue or TransactionalQueue(project_root)
    jobs = queue.snapshot(captured_at=moment)["jobs"]
    expected_key = f"{current_receipt['receipt_id']}:synthesize-render-standard-v2"
    authorities = [
        item
        for item in jobs
        if item.get("idempotency_key") == expected_key
        and item.get("task_type") == MEDIA_TASK
    ]
    if len(authorities) != 1:
        raise QueueConflict("the current production inputs do not have one exact media job")
    authority = authorities[0]
    if authoritative_job_id is not None and authority["job_id"] != authoritative_job_id:
        raise QueueConflict("requested authoritative job differs from current inputs")
    if authority["state"] not in {"PENDING", "RETRY_WAIT"}:
        raise QueueConflict("current media job is not an unfinished executable candidate")
    expected_payload = {
        "input_receipt_id": current_receipt["receipt_id"],
        "action": MEDIA_ACTION,
    }
    expected_job_id = "job-" + hashlib.sha256(expected_key.encode("utf-8")).hexdigest()[:24]
    if (
        authority.get("job_id") != expected_job_id
        or authority.get("operation_id") != unit["operation_id"]
        or authority.get("channel_id") != CHANNEL_ID
        or authority.get("payload") != expected_payload
        or authority.get("lease_owner") is not None
        or authority.get("lease_until") is not None
    ):
        raise QueueConflict(
            "current media authority does not recompute from latest immutable inputs"
        )
    if queue.get_media_job_supersession(authority["job_id"]) is not None:
        raise QueueConflict("current latest points to an already superseded media job")

    authoritative_ref = _input_reference(project_root, current_receipt["receipt_id"])
    superseded: list[dict[str, Any]] = []
    terminal_different_units: list[dict[str, str]] = []
    compared = 0
    for job in jobs:
        if job["job_id"] == authority["job_id"] or job.get("task_type") != MEDIA_TASK:
            continue
        prior_supersession = queue.get_media_job_supersession(job["job_id"])
        if prior_supersession is not None:
            if prior_supersession["state"] != "COMMITTED":
                raise QueueConflict("media supersession has not committed")
            continue
        payload = job.get("payload") or {}
        receipt_id = str(payload.get("input_receipt_id") or "")
        historical = _load_historical_input_envelope(project_root, receipt_id)
        historical_unit = _media_unit(
            receipt=historical[0], work_order=historical[1], evidence=historical[2]
        )
        # A completed command for a genuinely different editorial unit cannot
        # claim again.  It must remain historical evidence, not be forced
        # through a same-unit remediation proof that would misdescribe it.
        # Unfinished different units remain a hard block: they require their
        # own controlled retirement, never an implicit skip here.
        if historical_unit != unit:
            if job["state"] in {"SUCCEEDED", "DEAD_LETTER"}:
                if job.get("lease_owner") is not None or job.get("lease_until") is not None:
                    raise QueueConflict("terminal different media unit retains a lease")
                terminal_different_units.append(
                    {"job_id": job["job_id"], "state": job["state"], "input_receipt_id": receipt_id}
                )
                continue
            if job["state"] in {"PENDING", "RETRY_WAIT", "LEASED"}:
                raise QueueConflict("a different Phase 6 media unit remains executable")
            raise QueueConflict("different Phase 6 media unit has an unsupported state")
        decision = verify_media_supersession_decision(
            project_root,
            superseded_input_receipt_id=receipt_id,
            authoritative_input_receipt_id=current_receipt["receipt_id"],
        )
        compared += 1
        if decision["media_unit"] != unit:
            raise PermissionError("same-unit remediation proof changed the evaluated media unit")
        if job["state"] in {"LEASED", "SUCCEEDED"}:
            raise QueueConflict(
                "a same-unit stale media job is already leased or completed"
            )
        if job["state"] == "DEAD_LETTER":
            continue
        if job["state"] not in {"PENDING", "RETRY_WAIT"}:
            raise QueueConflict("same-unit stale media job has an unsupported state")
        supersession_key = (
            "phase6-media-supersession:"
            f"{unit['media_unit_key']}:{job['job_id']}:{authority['job_id']}"
        )
        proof_arguments = (
            {"identity_remediation": decision["identity_remediation"]}
            if "identity_remediation" in decision
            else {"pre_effect_remediation": decision["pre_effect_remediation"]}
        )
        result = queue.supersede_media_job(
            job["job_id"],
            authoritative_job_id=authority["job_id"],
            supersession_key=supersession_key,
            media_unit=unit,
            superseded_input_receipt=_input_reference(project_root, receipt_id),
            authoritative_input_receipt=authoritative_ref,
            now=moment,
            **proof_arguments,
        )
        superseded.append(
            {
                "job_id": job["job_id"],
                "receipt_path": result["receipt_path"],
                "receipt_sha256": result["receipt_sha256"],
                "replayed": result["replayed"],
                "supersession_class": decision.get(
                    "supersession_class", "IDENTITY_ONLY"
                ),
            }
        )

    for job in jobs:
        if job["job_id"] == authority["job_id"]:
            continue
        if job.get("task_type") != MEDIA_TASK:
            continue
        payload = job.get("payload") or {}
        if not str(payload.get("input_receipt_id") or "").startswith(INPUT_PATTERN):
            continue
        prior = queue.get_media_job_supersession(job["job_id"])
        if prior is not None and prior["state"] != "COMMITTED":
            raise QueueConflict("media supersession has not committed")

    queue.materialize_snapshot(captured_at=moment)
    fresh = queue.snapshot(captured_at=moment)
    superseded_ids = {
        item["superseded_job_id"]
        for item in fresh.get("media_job_supersessions") or []
        if item["state"] in {"PREPARED", "COMMITTED"}
    }
    physical_media_jobs = [
        item for item in fresh["jobs"] if item.get("task_type") == MEDIA_TASK
    ]
    executable_media_jobs = [
        item
        for item in physical_media_jobs
        if item["state"] in {"PENDING", "RETRY_WAIT", "LEASED"}
        and item["job_id"] not in superseded_ids
    ]
    if (
        len(executable_media_jobs) != 1
        or executable_media_jobs[0]["job_id"] != authority["job_id"]
    ):
        raise QueueConflict(
            "media authority reconciliation did not leave exactly one executable command"
        )
    return {
        "status": "RECONCILED",
        "media_unit_key": unit["media_unit_key"],
        "authoritative_job_id": authority["job_id"],
        "authoritative_input_receipt": authoritative_ref,
        "compared_media_jobs": compared,
        "superseded_jobs": superseded,
        "terminal_different_units": terminal_different_units,
        "physical_media_jobs": len(physical_media_jobs),
        "executable_media_jobs": len(executable_media_jobs),
        "external_api_calls": 0,
        "publication_effects": 0,
        "technical_cost_brl": 0,
        "recorded_at": moment.isoformat().replace("+00:00", "Z"),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Reconcile one authoritative Phase 6 video-2 media command."
    )
    parser.add_argument("--authoritative-job-id", required=True)
    args = parser.parse_args(argv)
    try:
        result = reconcile_phase6_media_authority(
            ROOT, authoritative_job_id=args.authoritative_job_id
        )
    except Exception as exc:
        print(
            json.dumps(
                {
                    "status": "BLOCKED",
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "external_api_calls": 0,
                    "publication_effects": 0,
                    "technical_cost_brl": 0,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
