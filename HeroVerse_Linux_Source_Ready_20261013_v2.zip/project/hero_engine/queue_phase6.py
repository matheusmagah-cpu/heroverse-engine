from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
QUEUE_PATH = Path("output/operations/phase6/runtime/phase6-queue.sqlite3")
SNAPSHOT_PATH = Path("output/operations/phase6/runtime/queue-snapshot.json")
DEAD_LETTER_RECOVERY_RECEIPTS = Path(
    "output/operations/phase6/runtime/dead-letter-recovery-receipts"
)
RECOVERED_MEDIA_DEFERRAL_RECEIPTS = Path(
    "output/operations/phase6/runtime/recovered-media-deferral-receipts"
)
MEDIA_JOB_SUPERSESSION_RECEIPTS = Path(
    "output/operations/phase6/runtime/media-job-supersession-receipts"
)
POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS = Path(
    "output/operations/phase6/runtime/post-effect-visual-eligibility-receipts"
)
PRODUCTION_INPUT_RECEIPTS = Path(
    "output/operations/phase6/release/production-input-receipts"
)
LATEST_PRODUCTION_INPUT_RECEIPT = Path(
    "output/operations/phase6/release/latest-production-inputs-receipt.json"
)
MEDIA_REPAIR_EVIDENCE = Path(
    "output/operations/phase6/runtime/media-repair-evidence"
)
RECOVERED_MEDIA_PRE_EFFECT_REASON = (
    "PRE_EFFECT_POST_RECOVERY_RUNTIME_RECONCILIATION_PENDING"
)
STATES = ("PENDING", "LEASED", "RETRY_WAIT", "SUCCEEDED", "DEAD_LETTER")


SCHEMA = """
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS jobs (
    job_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    operation_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    task_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('PENDING','LEASED','RETRY_WAIT','SUCCEEDED','DEAD_LETTER')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL CHECK(max_attempts >= 1),
    available_at TEXT NOT NULL,
    lease_owner TEXT,
    lease_until TEXT,
    checkpoint_json TEXT NOT NULL DEFAULT '{}',
    last_error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jobs_claim ON jobs(state, task_type, available_at, created_at);
CREATE TABLE IF NOT EXISTS incidents (
    incident_id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL,
    incident_type TEXT NOT NULL CHECK(incident_type IN ('LEASE_EXPIRED','MAX_ATTEMPTS_EXCEEDED')),
    severity TEXT NOT NULL CHECK(severity IN ('WARNING','CRITICAL')),
    detail TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(job_id) REFERENCES jobs(job_id)
);
CREATE TABLE IF NOT EXISTS dead_letter_recoveries (
    recovery_id TEXT PRIMARY KEY,
    recovery_key TEXT NOT NULL UNIQUE,
    job_id TEXT NOT NULL,
    task_type TEXT NOT NULL,
    repair_evidence_path TEXT NOT NULL,
    repair_evidence_sha256 TEXT NOT NULL,
    prior_attempt_count INTEGER NOT NULL CHECK(prior_attempt_count >= 1),
    prior_max_attempts INTEGER NOT NULL CHECK(prior_max_attempts >= 1),
    new_max_attempts INTEGER NOT NULL CHECK(new_max_attempts > prior_max_attempts),
    state TEXT NOT NULL CHECK(state IN ('PREPARED','COMMITTED')),
    recovered_at TEXT NOT NULL,
    committed_at TEXT,
    receipt_json TEXT NOT NULL,
    receipt_sha256 TEXT NOT NULL,
    FOREIGN KEY(job_id) REFERENCES jobs(job_id)
);
CREATE INDEX IF NOT EXISTS idx_dead_letter_recoveries_job
    ON dead_letter_recoveries(job_id,recovered_at,recovery_id);
CREATE TABLE IF NOT EXISTS recovered_media_deferrals (
    deferral_id TEXT PRIMARY KEY,
    deferral_key TEXT NOT NULL UNIQUE,
    recovery_id TEXT NOT NULL,
    job_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL CHECK(ordinal >= 1),
    mode TEXT NOT NULL CHECK(mode IN ('TRANSACTIONAL','RECONCILED_EXISTING_STATE')),
    state TEXT NOT NULL CHECK(state IN ('PREPARED','COMMITTED')),
    deferred_at TEXT NOT NULL,
    committed_at TEXT,
    receipt_json TEXT NOT NULL,
    receipt_sha256 TEXT NOT NULL,
    UNIQUE(job_id,ordinal),
    FOREIGN KEY(recovery_id) REFERENCES dead_letter_recoveries(recovery_id),
    FOREIGN KEY(job_id) REFERENCES jobs(job_id)
);
CREATE INDEX IF NOT EXISTS idx_recovered_media_deferrals_job
    ON recovered_media_deferrals(job_id,ordinal,deferral_id);
CREATE TABLE IF NOT EXISTS media_job_supersessions (
    supersession_id TEXT PRIMARY KEY,
    supersession_key TEXT NOT NULL UNIQUE,
    media_unit_key TEXT NOT NULL,
    superseded_job_id TEXT NOT NULL UNIQUE,
    authoritative_job_id TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('PREPARED','COMMITTED')),
    recorded_at TEXT NOT NULL,
    committed_at TEXT,
    receipt_json TEXT NOT NULL,
    receipt_sha256 TEXT NOT NULL,
    FOREIGN KEY(superseded_job_id) REFERENCES jobs(job_id),
    FOREIGN KEY(authoritative_job_id) REFERENCES jobs(job_id)
);
CREATE INDEX IF NOT EXISTS idx_media_job_supersessions_unit
    ON media_job_supersessions(media_unit_key,state,authoritative_job_id);
"""


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _canonical(value: dict[str, Any]) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha256_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _sha256_text(value: str) -> str:
    return _sha256_bytes(value.encode("utf-8"))


class QueueConflict(RuntimeError):
    pass


class LeaseConflict(RuntimeError):
    pass


class TransactionalQueue:
    def __init__(self, root: Path = ROOT, *, path: Path | None = None, read_only: bool = False,
                 immutable: bool = False) -> None:
        self.root = root.resolve()
        self.path = (path or (self.root / QUEUE_PATH)).resolve()
        self.read_only = bool(read_only)
        self.immutable = bool(immutable)
        if self.immutable and not self.read_only:
            raise ValueError("immutable queue access must be read-only")
        if self.read_only:
            # A planning/verification caller must never create a directory,
            # initialize the schema, or cause WAL/SHM sidecars on the live
            # queue.  The paused-application capture pins this exact set.
            if not self.path.is_file():
                raise FileNotFoundError(f"read-only queue is unavailable: {self.path}")
        else:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._connection() as connection:
                connection.executescript(SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        if self.read_only:
            query = "mode=ro&cache=private"
            # ``mode=ro`` alone may still create the WAL/SHM index pair when
            # the database was last opened in WAL mode.  Immutable is reserved
            # for an already-pinned capture or other caller-owned stable bytes.
            if self.immutable:
                query += "&immutable=1"
            uri = f"file:{quote(self.path.as_posix(), safe='/:')}?{query}"
            connection = sqlite3.connect(uri, uri=True, timeout=5, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA query_only=ON")
            connection.execute("PRAGMA busy_timeout=5000")
            return connection
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        connection.row_factory = sqlite3.Row
        # A fresh commit connection must state its capability explicitly.  The
        # paused-application proof uses read-only SQLite views in the same
        # process; a queued forward commit is the one narrow boundary which
        # must never inherit ``query_only`` from a verification connection.
        # This does not bypass filesystem permissions: a physically read-only
        # database still fails closed at BEGIN/WRITE.
        connection.execute("PRAGMA query_only=OFF")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    @contextmanager
    def _connection(self):
        connection = self._connect()
        try:
            yield connection
        finally:
            connection.close()

    @staticmethod
    def _job(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value["payload"] = json.loads(value.pop("payload_json"))
        value["checkpoint"] = json.loads(value.pop("checkpoint_json"))
        return value

    def _validate_document(self, schema_name: str, value: dict[str, Any]) -> None:
        schema_path = self.root / "schemas" / schema_name
        if not schema_path.is_file():
            raise FileNotFoundError(f"required queue schema is unavailable: {schema_name}")
        schema = json.loads(schema_path.read_text(encoding="utf-8-sig"))
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)

    def _load_media_repair_evidence(
        self,
        *,
        path: str | Path,
        expected_sha256: str,
    ) -> tuple[Path, str, dict[str, Any]]:
        raw = Path(path)
        if raw.is_absolute():
            raise PermissionError("media repair evidence path must be workspace-relative")
        allowed = (self.root / MEDIA_REPAIR_EVIDENCE).resolve()
        candidate = (self.root / raw).resolve()
        try:
            candidate.relative_to(allowed)
        except ValueError as exc:
            raise PermissionError("media repair evidence is outside its immutable directory") from exc
        if not candidate.is_file():
            raise FileNotFoundError("media repair evidence is unavailable")
        observed_hash = _sha256_file(candidate)
        if observed_hash != expected_sha256:
            raise PermissionError("media repair evidence hash mismatch")
        evidence = json.loads(candidate.read_text(encoding="utf-8-sig"))
        self._validate_document("phase6_media_repair_evidence.schema.json", evidence)
        if candidate.name != f"{evidence['evidence_id']}.json":
            raise PermissionError("media repair evidence filename does not match its identity")
        for artifact in evidence["verification"]["artifacts"]:
            artifact_path = Path(artifact["path"])
            if not artifact_path.is_absolute():
                artifact_path = self.root / artifact_path
            artifact_path = artifact_path.resolve()
            if not artifact_path.is_file():
                raise FileNotFoundError(
                    f"technical repair verification artifact is unavailable: {artifact['path']}"
                )
            if _sha256_file(artifact_path) != artifact["sha256"]:
                raise PermissionError(
                    f"technical repair verification artifact hash mismatch: {artifact['path']}"
                )
        relative = candidate.relative_to(self.root).as_posix()
        return candidate, relative, evidence

    def _materialize_dead_letter_recovery_receipt(
        self,
        *,
        receipt: dict[str, Any],
        expected_sha256: str,
    ) -> Path:
        self._validate_document("phase6_dead_letter_recovery_receipt.schema.json", receipt)
        target = self.root / DEAD_LETTER_RECOVERY_RECEIPTS / f"{receipt['receipt_id']}.json"
        payload = (_canonical(receipt) + "\n").encode("utf-8")
        if _sha256_bytes(payload) != expected_sha256:
            raise PermissionError("stored dead-letter recovery receipt hash is inconsistent")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not target.is_file() or target.read_bytes() != payload:
                raise PermissionError("immutable dead-letter recovery receipt collision")
            return target
        temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_bytes(payload)
            try:
                os.link(temporary, target)
            except FileExistsError:
                if not target.is_file() or target.read_bytes() != payload:
                    raise PermissionError("immutable dead-letter recovery receipt collision")
        finally:
            temporary.unlink(missing_ok=True)
        return target

    def _materialize_recovered_media_deferral_receipt(
        self,
        *,
        receipt: dict[str, Any],
        expected_sha256: str,
    ) -> Path:
        self._validate_document(
            "phase6_recovered_media_deferral_receipt.schema.json", receipt
        )
        target = (
            self.root
            / RECOVERED_MEDIA_DEFERRAL_RECEIPTS
            / f"{receipt['receipt_id']}.json"
        )
        payload = (_canonical(receipt) + "\n").encode("utf-8")
        if _sha256_bytes(payload) != expected_sha256:
            raise PermissionError(
                "stored recovered-media deferral receipt hash is inconsistent"
            )
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not target.is_file() or target.read_bytes() != payload:
                raise PermissionError(
                    "immutable recovered-media deferral receipt collision"
                )
            return target
        temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_bytes(payload)
            try:
                os.link(temporary, target)
            except FileExistsError:
                if not target.is_file() or target.read_bytes() != payload:
                    raise PermissionError(
                        "immutable recovered-media deferral receipt collision"
                    )
        finally:
            temporary.unlink(missing_ok=True)
        return target

    def _materialize_media_job_supersession_receipt(
        self,
        *,
        receipt: dict[str, Any],
        expected_sha256: str,
    ) -> Path:
        schema_name = self._media_job_supersession_schema_name(receipt)
        self._validate_document(schema_name, receipt)
        target = (
            self.root
            / MEDIA_JOB_SUPERSESSION_RECEIPTS
            / f"{receipt['receipt_id']}.json"
        )
        payload = (_canonical(receipt) + "\n").encode("utf-8")
        if _sha256_bytes(payload) != expected_sha256:
            raise PermissionError(
                "stored media-job supersession receipt hash is inconsistent"
            )
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not target.is_file() or target.read_bytes() != payload:
                raise PermissionError(
                    "immutable media-job supersession receipt collision"
                )
            return target
        temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_bytes(payload)
            try:
                os.link(temporary, target)
            except FileExistsError:
                if not target.is_file() or target.read_bytes() != payload:
                    raise PermissionError(
                        "immutable media-job supersession receipt collision"
                    )
        finally:
            temporary.unlink(missing_ok=True)
        return target

    @staticmethod
    def _media_job_supersession_schema_name(receipt: dict[str, Any]) -> str:
        """Dispatch without widening either immutable supersession contract."""

        if (
            receipt.get("schema_version") == "1.0.0"
            and receipt.get("status") == "SUPERSEDED_POST_EFFECT_LOCAL"
            and receipt.get("supersession_class")
            == "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"
        ):
            return "phase6_post_effect_media_job_supersession_receipt.schema.json"
        if (
            receipt.get("schema_version") == "1.0.0"
            and receipt.get("status") == "SUPERSEDED_FORWARD_POST_EFFECT_CURRENT"
            and receipt.get("supersession_class")
            == "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION"
        ):
            return "phase6_forward_post_effect_media_job_supersession_receipt.schema.json"
        return "phase6_media_job_supersession_receipt.schema.json"

    @staticmethod
    def _is_local_post_effect(receipt: dict[str, Any]) -> bool:
        return receipt.get("supersession_class") in {
            "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION",
            "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION",
        }

    def _load_post_effect_visual_eligibility_reference(
        self,
        reference: dict[str, Any],
    ) -> tuple[Path, dict[str, Any]]:
        """Reopen the exact immutable eligibility evidence, without approving it.

        Semantic approval belongs to the injected verifier.  This queue boundary
        only confines the path and proves the exact bytes supplied to that
        verifier.  Keeping these responsibilities separate prevents the queue
        from claiming that an external-effect guard passed merely because a JSON
        file exists.
        """

        if not isinstance(reference, dict):
            raise PermissionError("post-effect eligibility receipt reference is required")
        receipt_id = str(reference.get("receipt_id") or "")
        relative = str(reference.get("path") or "")
        expected_hash = str(reference.get("sha256") or "")
        expected_path = POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS / f"{receipt_id}.json"
        if relative != expected_path.as_posix():
            raise PermissionError(
                "post-effect eligibility receipt is outside its exact immutable path"
            )
        path = (self.root / expected_path).resolve()
        allowed = (self.root / POST_EFFECT_VISUAL_ELIGIBILITY_RECEIPTS).resolve()
        if path.parent != allowed:
            raise PermissionError("post-effect eligibility receipt escaped its directory")
        if not path.is_file() or _sha256_file(path) != expected_hash:
            raise PermissionError("post-effect eligibility receipt hash mismatch")
        document = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(document, dict) or document.get("receipt_id") != receipt_id:
            raise PermissionError("post-effect eligibility receipt identity mismatch")
        return path, document

    def _verify_post_effect_visual_eligibility(
        self,
        *,
        verifier: Any,
        reference: dict[str, Any],
        authority_root_job: dict[str, Any],
        predecessor_job: dict[str, Any],
        media_unit: dict[str, Any],
        input_receipt: dict[str, Any],
    ) -> dict[str, Any]:
        if verifier is None or not callable(verifier):
            raise PermissionError(
                "post-effect visual remediation requires an explicit eligibility verifier"
            )
        path, document = self._load_post_effect_visual_eligibility_reference(reference)
        result = verifier(
            root=self.root,
            eligibility_path=path,
            eligibility_document=document,
            eligibility_receipt=dict(reference),
            authority_root_job=authority_root_job,
            predecessor_job=predecessor_job,
            media_unit=media_unit,
            input_receipt=input_receipt,
        )
        if not isinstance(result, dict):
            raise PermissionError("post-effect eligibility verifier returned no proof")
        expected_keys = {
            "schema_version",
            "policy_version",
            "status",
            "supersession_class",
            "eligibility_receipt",
            "authority_root_job_id",
            "predecessor_job_id",
            "media_unit_key",
            "input_receipt_id",
            "predecessor_payload_sha256",
            "predecessor_checkpoint_sha256",
            "publication_authorized",
            "technical_cost_brl",
            "proof_sha256",
        }
        if set(result) != expected_keys:
            raise PermissionError(
                "post-effect eligibility verifier returned a divergent proof contract"
            )
        proof = dict(result)
        proof_sha256 = str(proof.pop("proof_sha256", ""))
        stable = (
            result.get("schema_version") == "1.0.0"
            and result.get("policy_version")
            == "phase6-post-effect-local-visual-contract-eligibility-v1"
            and result.get("status") == "PASS"
            and result.get("supersession_class")
            == "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"
            and result.get("eligibility_receipt") == reference
            and result.get("authority_root_job_id")
            == authority_root_job.get("job_id")
            and result.get("predecessor_job_id") == predecessor_job.get("job_id")
            and result.get("media_unit_key") == media_unit.get("media_unit_key")
            and result.get("input_receipt_id") == input_receipt.get("receipt_id")
            and result.get("predecessor_payload_sha256")
            == _sha256_text(_canonical(predecessor_job.get("payload") or {}))
            and result.get("predecessor_checkpoint_sha256")
            == _sha256_text(_canonical(predecessor_job.get("checkpoint") or {}))
            and result.get("publication_authorized") is False
            and result.get("technical_cost_brl") == 0
            and proof_sha256 == _sha256_bytes(_canonical(proof).encode("utf-8"))
        )
        if not stable:
            raise PermissionError(
                "post-effect eligibility proof is not bound to the exact queue lineage"
            )
        return result

    def _verify_forward_post_effect_current_eligibility(
        self,
        *,
        verifier: Any,
        reference: dict[str, Any],
        authority_root_job: dict[str, Any],
        predecessor_job: dict[str, Any],
        successor_job: dict[str, Any],
        media_unit: dict[str, Any],
        historical_input: dict[str, Any],
        current_input: dict[str, Any],
    ) -> dict[str, Any]:
        """Bind a forward-only adoption to both immutable input generations.

        This is deliberately separate from the legacy post-effect verifier: the
        historical input remains evidence only, while the already-existing
        current queue job is the sole future executable command.
        """
        if not callable(verifier):
            raise PermissionError("forward post-effect remediation requires an explicit eligibility verifier")
        path, document = self._load_post_effect_visual_eligibility_reference(reference)
        result = verifier(
            root=self.root, eligibility_path=path, eligibility_document=document,
            eligibility_receipt=dict(reference), authority_root_job=authority_root_job,
            predecessor_job=predecessor_job, successor_job=successor_job,
            media_unit=media_unit, historical_input=historical_input,
            current_input=current_input,
        )
        expected = {
            "schema_version", "policy_version", "status", "supersession_class",
            "eligibility_receipt", "authority_root_job_id", "predecessor_job_id",
            "successor_job_id", "media_unit_key", "historical_input_receipt_id",
            "current_input_receipt_id", "predecessor_payload_sha256",
            "predecessor_checkpoint_sha256", "successor_payload_sha256",
            "successor_checkpoint_sha256", "publication_authorized",
            "technical_cost_brl", "proof_sha256",
        }
        if not isinstance(result, dict) or set(result) != expected:
            raise PermissionError("forward post-effect eligibility verifier returned a divergent proof contract")
        proof = dict(result)
        proof_sha256 = str(proof.pop("proof_sha256", ""))
        stable = (
            result["schema_version"] == "1.0.0"
            and result["policy_version"] == "phase6-forward-post-effect-current-input-eligibility-v1"
            and result["status"] == "PASS"
            and result["supersession_class"] == "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION"
            and result["eligibility_receipt"] == reference
            and result["authority_root_job_id"] == authority_root_job["job_id"]
            and result["predecessor_job_id"] == predecessor_job["job_id"]
            and result["successor_job_id"] == successor_job["job_id"]
            and result["media_unit_key"] == media_unit["media_unit_key"]
            and result["historical_input_receipt_id"] == historical_input["receipt_id"]
            and result["current_input_receipt_id"] == current_input["receipt_id"]
            and result["predecessor_payload_sha256"] == _sha256_text(_canonical(predecessor_job["payload"]))
            and result["predecessor_checkpoint_sha256"] == _sha256_text(_canonical(predecessor_job["checkpoint"]))
            and result["successor_payload_sha256"] == _sha256_text(_canonical(successor_job["payload"]))
            and result["successor_checkpoint_sha256"] == _sha256_text(_canonical(successor_job["checkpoint"]))
            and result["publication_authorized"] is False
            and result["technical_cost_brl"] == 0
            and proof_sha256 == _sha256_bytes(_canonical(proof).encode("utf-8"))
        )
        if not stable:
            raise PermissionError("forward post-effect eligibility proof is not bound to the exact queue lineage")
        return result

    @staticmethod
    def _queue_state(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
        return {
            "state": str(row["state"]),
            "attempt_count": int(row["attempt_count"]),
            "max_attempts": int(row["max_attempts"]),
            "available_at": str(row["available_at"]),
            "last_error": str(row["last_error"] or ""),
            "lease_owner": row["lease_owner"],
            "lease_until": row["lease_until"],
        }

    @staticmethod
    def _is_recovered_media_job(
        connection: sqlite3.Connection, job_id: str
    ) -> bool:
        return connection.execute(
            "SELECT 1 FROM dead_letter_recoveries "
            "WHERE job_id=? AND state='COMMITTED' LIMIT 1",
            (job_id,),
        ).fetchone() is not None

    @staticmethod
    def _is_superseded_media_job(
        connection: sqlite3.Connection, job_id: str
    ) -> bool:
        """Treat PREPARED as non-runnable so receipt failures stay fail-closed."""

        return connection.execute(
            "SELECT 1 FROM media_job_supersessions "
            "WHERE superseded_job_id=? AND state IN ('PREPARED','COMMITTED') LIMIT 1",
            (job_id,),
        ).fetchone() is not None

    @staticmethod
    def _is_prepared_authoritative_media_job(
        connection: sqlite3.Connection, job_id: str
    ) -> bool:
        """Block a proposed authority until its immutable receipt commits.

        A supersession row is persisted as PREPARED before its receipt reaches
        immutable storage.  The predecessor was already excluded from claims,
        but the proposed authority must also remain unclaimable during that
        interval; otherwise a concurrent worker could execute evidence that
        has not committed yet.
        """

        return connection.execute(
            "SELECT 1 FROM media_job_supersessions "
            "WHERE authoritative_job_id=? AND state='PREPARED' LIMIT 1",
            (job_id,),
        ).fetchone() is not None

    def _load_media_input_reference(
        self,
        reference: dict[str, Any],
    ) -> tuple[Path, dict[str, Any]]:
        receipt_id = str(reference.get("receipt_id") or "")
        relative = str(reference.get("path") or "")
        expected_hash = str(reference.get("sha256") or "")
        expected_path = PRODUCTION_INPUT_RECEIPTS / f"{receipt_id}.json"
        if relative != expected_path.as_posix():
            raise PermissionError(
                "media supersession input receipt is outside its exact immutable path"
            )
        path = (self.root / expected_path).resolve()
        if path.parent != (self.root / PRODUCTION_INPUT_RECEIPTS).resolve():
            raise PermissionError("media supersession input receipt escaped its directory")
        if not path.is_file() or _sha256_file(path) != expected_hash:
            raise PermissionError("media supersession input receipt hash mismatch")
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        self._validate_document("phase6_production_inputs_receipt.schema.json", value)
        if value.get("receipt_id") != receipt_id:
            raise PermissionError("media supersession input receipt identity mismatch")
        return path, value

    def enqueue(
        self,
        *,
        idempotency_key: str,
        operation_id: str,
        channel_id: str,
        task_type: str,
        payload: dict[str, Any],
        max_attempts: int = 3,
        available_at: datetime | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        if channel_id != CHANNEL_ID:
            raise PermissionError("Phase 6 queue is isolated to the HeroVerse channel")
        if max_attempts < 1:
            raise ValueError("max_attempts must be positive")
        moment = now or _now()
        timestamp = _stamp(moment)
        available_timestamp = _stamp(available_at or moment)
        payload_json = _canonical(payload)
        job_id = "job-" + hashlib.sha256(idempotency_key.encode("utf-8")).hexdigest()[:24]
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT * FROM jobs WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if existing is not None:
                stable = (
                    existing["operation_id"] == operation_id
                    and existing["channel_id"] == channel_id
                    and existing["task_type"] == task_type
                    and existing["payload_json"] == payload_json
                    and existing["max_attempts"] == max_attempts
                )
                if not stable:
                    connection.rollback()
                    raise QueueConflict("idempotency key reused with divergent command")
                connection.commit()
                return self._job(existing)
            connection.execute(
                """INSERT INTO jobs
                (job_id,idempotency_key,operation_id,channel_id,task_type,payload_json,state,
                 attempt_count,max_attempts,available_at,lease_owner,lease_until,checkpoint_json,
                 last_error,created_at,updated_at)
                VALUES (?,?,?,?,?,?,'PENDING',0,?,?,NULL,NULL,'{}',NULL,?,?)""",
                (job_id, idempotency_key, operation_id, channel_id, task_type, payload_json,
                 max_attempts, available_timestamp, timestamp, timestamp),
            )
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(row)

    def _recover_expired(self, connection: sqlite3.Connection, moment: datetime) -> None:
        timestamp = _stamp(moment)
        expired = connection.execute(
            "SELECT * FROM jobs WHERE state='LEASED' AND lease_until IS NOT NULL "
            "AND julianday(lease_until)<=julianday(?)",
            (timestamp,),
        ).fetchall()
        for row in expired:
            connection.execute(
                "INSERT INTO incidents(job_id,incident_type,severity,detail,created_at) VALUES (?,'LEASE_EXPIRED','WARNING',?,?)",
                (row["job_id"], f"Lease held by {row['lease_owner']} expired at {row['lease_until']}", timestamp),
            )
            if row["attempt_count"] >= row["max_attempts"]:
                connection.execute(
                    "UPDATE jobs SET state='DEAD_LETTER',lease_owner=NULL,lease_until=NULL,last_error='LEASE_EXPIRED_MAX_ATTEMPTS',updated_at=? WHERE job_id=?",
                    (timestamp, row["job_id"]),
                )
                connection.execute(
                    "INSERT INTO incidents(job_id,incident_type,severity,detail,created_at) VALUES (?,'MAX_ATTEMPTS_EXCEEDED','CRITICAL','Expired lease exhausted retry budget',?)",
                    (row["job_id"], timestamp),
                )
            else:
                connection.execute(
                    "UPDATE jobs SET state='RETRY_WAIT',available_at=?,lease_owner=NULL,lease_until=NULL,last_error='LEASE_EXPIRED',updated_at=? WHERE job_id=?",
                    (timestamp, timestamp, row["job_id"]),
                )

    def claim(
        self,
        *,
        worker_id: str,
        task_type: str | None = None,
        lease_seconds: int = 180,
        now: datetime | None = None,
    ) -> dict[str, Any] | None:
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be positive")
        moment = now or _now()
        timestamp = _stamp(moment)
        lease_until = _stamp(moment + timedelta(seconds=lease_seconds))
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._recover_expired(connection, moment)
            params: list[Any] = [timestamp]
            query = (
                "SELECT * FROM jobs WHERE state IN ('PENDING','RETRY_WAIT') "
                "AND julianday(available_at)<=julianday(?) "
                "AND NOT EXISTS (SELECT 1 FROM media_job_supersessions s "
                "WHERE (s.superseded_job_id=jobs.job_id "
                "AND s.state IN ('PREPARED','COMMITTED')) "
                "OR (s.authoritative_job_id=jobs.job_id "
                "AND s.state='PREPARED'))"
            )
            if task_type is not None:
                query += " AND task_type=?"
                params.append(task_type)
            query += " ORDER BY julianday(available_at),julianday(created_at),job_id LIMIT 1"
            row = connection.execute(query, params).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                "UPDATE jobs SET state='LEASED',attempt_count=attempt_count+1,lease_owner=?,lease_until=?,updated_at=? WHERE job_id=?",
                (worker_id, lease_until, timestamp, row["job_id"]),
            )
            claimed = connection.execute("SELECT * FROM jobs WHERE job_id=?", (row["job_id"],)).fetchone()
            connection.commit()
            return self._job(claimed)

    def claim_job(
        self,
        job_id: str,
        *,
        worker_id: str,
        expected_task_type: str | None = None,
        lease_seconds: int = 180,
        now: datetime | None = None,
    ) -> dict[str, Any] | None:
        """Lease one exact job without touching an eligible sibling.

        Executors that have just enqueued or resolved an idempotent command know
        its ``job_id``.  Claiming only by task type could lease an older sibling,
        spend its retry budget and starve the intended command.  This method
        makes the identity check part of the same SQLite transaction as leasing.
        """

        if not isinstance(job_id, str) or not job_id.startswith("job-"):
            raise ValueError("an exact queue job id is required")
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be positive")
        moment = now or _now()
        timestamp = _stamp(moment)
        lease_until = _stamp(moment + timedelta(seconds=lease_seconds))
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._recover_expired(connection, moment)
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if row is None:
                connection.rollback()
                raise QueueConflict("exact job does not exist")
            if expected_task_type is not None and row["task_type"] != expected_task_type:
                connection.rollback()
                raise QueueConflict("exact job task type diverges from executor contract")
            if self._is_superseded_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict("exact media job is superseded and cannot be leased")
            if self._is_prepared_authoritative_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict(
                    "exact media job is a PREPARED authority and cannot be leased"
                )
            if (
                row["state"] not in {"PENDING", "RETRY_WAIT"}
                or _parse(row["available_at"]) > moment.astimezone(timezone.utc)
            ):
                connection.commit()
                return None
            connection.execute(
                "UPDATE jobs SET state='LEASED',attempt_count=attempt_count+1,lease_owner=?,lease_until=?,updated_at=? WHERE job_id=?",
                (worker_id, lease_until, timestamp, job_id),
            )
            claimed = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(claimed)

    def checkpoint(self, job_id: str, *, worker_id: str, value: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
        return self._finish_update(job_id, worker_id=worker_id, checkpoint=value, final_state=None, error=None, now=now)

    def renew_lease(
        self,
        job_id: str,
        *,
        worker_id: str,
        lease_seconds: int,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Extend the exact live lease without changing its attempt or checkpoint.

        The update is owner-checked and transactional.  It never shortens an
        existing lease, which also keeps deterministic tests and recovered
        logical clocks from moving a valid deadline backwards.
        """

        if lease_seconds < 1:
            raise ValueError("lease_seconds must be positive")
        moment = now or _now()
        timestamp = _stamp(moment)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if (
                row is None
                or row["state"] != "LEASED"
                or row["lease_owner"] != worker_id
                or not row["lease_until"]
                or _parse(row["lease_until"]) <= moment
            ):
                connection.rollback()
                raise LeaseConflict("active lease ownership is required to renew a job")
            extended = max(
                _parse(row["lease_until"]),
                moment + timedelta(seconds=lease_seconds),
            )
            updated_at = max(_parse(row["updated_at"]), moment)
            connection.execute(
                "UPDATE jobs SET lease_until=?,updated_at=? WHERE job_id=?",
                (_stamp(extended), _stamp(updated_at), job_id),
            )
            updated = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(updated)

    def defer(
        self,
        job_id: str,
        *,
        available_at: datetime,
        reason: str,
        checkpoint: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Postpone an unclaimed job without consuming its retry budget."""

        moment = now or _now()
        timestamp = _stamp(moment)
        next_timestamp = _stamp(available_at)
        if available_at <= moment:
            raise ValueError("deferred availability must be in the future")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if row is None or row["state"] not in {"PENDING", "RETRY_WAIT"}:
                connection.rollback()
                raise LeaseConflict("only an unclaimed pending/retry job can be deferred")
            if self._is_superseded_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict("superseded media cannot be deferred")
            if self._is_recovered_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict(
                    "recovered media requires an immutable pre-effect deferral receipt"
                )
            stored = json.loads(row["checkpoint_json"])
            value = checkpoint if checkpoint is not None else stored
            connection.execute(
                "UPDATE jobs SET state='RETRY_WAIT',available_at=?,checkpoint_json=?,last_error=?,updated_at=? WHERE job_id=?",
                (next_timestamp, _canonical(value), reason, timestamp, job_id),
            )
            updated = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(updated)

    def defer_claimed(
        self,
        job_id: str,
        *,
        worker_id: str,
        available_at: datetime,
        reason: str,
        checkpoint: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Release an active lease without consuming retry budget.

        This transition is reserved for a pre-effect control decision such as a
        zero-cost/quota guard.  Lease ownership is mandatory and the claim's
        attempt increment is reversed atomically so repeated quota waits cannot
        exhaust a job that never contacted an external service.
        """

        moment = now or _now()
        timestamp = _stamp(moment)
        next_timestamp = _stamp(available_at)
        if available_at <= moment:
            raise ValueError("deferred availability must be in the future")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if (
                row is None
                or row["state"] != "LEASED"
                or row["lease_owner"] != worker_id
                or not row["lease_until"]
                or _parse(row["lease_until"]) <= moment.astimezone(timezone.utc)
            ):
                connection.rollback()
                raise LeaseConflict("active lease ownership is required to defer a claimed job")
            if self._is_superseded_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict("superseded media cannot be deferred")
            if self._is_recovered_media_job(connection, job_id):
                connection.rollback()
                raise QueueConflict(
                    "recovered media requires an immutable pre-effect deferral receipt"
                )
            stored = json.loads(row["checkpoint_json"])
            value = checkpoint if checkpoint is not None else stored
            connection.execute(
                """UPDATE jobs
                   SET state='RETRY_WAIT',attempt_count=MAX(0,attempt_count-1),available_at=?,
                       lease_owner=NULL,lease_until=NULL,checkpoint_json=?,last_error=?,updated_at=?
                   WHERE job_id=?""",
                (next_timestamp, _canonical(value), reason, timestamp, job_id),
            )
            updated = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(updated)

    def succeed(self, job_id: str, *, worker_id: str, checkpoint: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
        return self._finish_update(job_id, worker_id=worker_id, checkpoint=checkpoint, final_state="SUCCEEDED", error=None, now=now)

    def _finish_update(
        self,
        job_id: str,
        *,
        worker_id: str,
        checkpoint: dict[str, Any],
        final_state: str | None,
        error: str | None,
        now: datetime | None,
    ) -> dict[str, Any]:
        moment = now or _now()
        timestamp = _stamp(moment)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if (
                row is None
                or row["state"] != "LEASED"
                or row["lease_owner"] != worker_id
                or not row["lease_until"]
                or _parse(row["lease_until"]) <= moment.astimezone(timezone.utc)
            ):
                connection.rollback()
                raise LeaseConflict("active lease ownership is required")
            state = final_state or "LEASED"
            lease_owner = None if final_state else worker_id
            lease_until = None if final_state else row["lease_until"]
            connection.execute(
                "UPDATE jobs SET state=?,checkpoint_json=?,lease_owner=?,lease_until=?,last_error=?,updated_at=? WHERE job_id=?",
                (state, _canonical(checkpoint), lease_owner, lease_until, error, timestamp, job_id),
            )
            updated = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(updated)

    def fail(
        self,
        job_id: str,
        *,
        worker_id: str,
        error: str,
        checkpoint: dict[str, Any] | None = None,
        base_backoff_seconds: int = 30,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        moment = now or _now()
        timestamp = _stamp(moment)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            if (
                row is None
                or row["state"] != "LEASED"
                or row["lease_owner"] != worker_id
                or not row["lease_until"]
                or _parse(row["lease_until"]) <= moment.astimezone(timezone.utc)
            ):
                connection.rollback()
                raise LeaseConflict("active lease ownership is required to fail a job")
            if row["attempt_count"] >= row["max_attempts"]:
                state, available_at = "DEAD_LETTER", timestamp
                connection.execute(
                    "INSERT INTO incidents(job_id,incident_type,severity,detail,created_at) VALUES (?,'MAX_ATTEMPTS_EXCEEDED','CRITICAL',?,?)",
                    (job_id, error, timestamp),
                )
            else:
                state = "RETRY_WAIT"
                delay = base_backoff_seconds * (2 ** max(0, row["attempt_count"] - 1))
                available_at = _stamp(moment + timedelta(seconds=delay))
            connection.execute(
                "UPDATE jobs SET state=?,available_at=?,lease_owner=NULL,lease_until=NULL,checkpoint_json=?,last_error=?,updated_at=? WHERE job_id=?",
                (state, available_at, _canonical(checkpoint or json.loads(row["checkpoint_json"])), error, timestamp, job_id),
            )
            updated = connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
            connection.commit()
            return self._job(updated)

    def recover_media_dead_letter(
        self,
        job_id: str,
        *,
        recovery_key: str,
        repair_evidence_path: str | Path,
        repair_evidence_sha256: str,
        new_max_attempts: int,
        available_at: datetime | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Recover one evidenced media dead letter without replacing its job.

        This is a bounded administrative state transition, not an executor. It
        never invokes media, OAuth, a provider API or publication. The existing
        job, idempotency key, payload, checkpoint, attempt count, failure and
        incidents remain intact; exactly one new attempt is authorized only
        after a schema-valid, byte-pinned technical repair proof passes.

        Recovery is two-stage so a crash cannot expose a claimable job without
        its immutable receipt: PREPARED keeps the job in DEAD_LETTER, the
        receipt is materialized, then COMMITTED and RETRY_WAIT are written in
        one SQLite transaction. Replaying the same recovery key completes or
        returns that exact transition without adding another attempt budget.
        """

        if not isinstance(job_id, str) or not job_id.startswith("job-"):
            raise ValueError("an exact dead-letter job id is required")
        allowed_key_characters = set(
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._:-"
        )
        if (
            not isinstance(recovery_key, str)
            or not recovery_key.startswith("phase6-media-recovery:")
            or len(recovery_key) > 214
            or any(character not in allowed_key_characters for character in recovery_key)
        ):
            raise ValueError("a stable phase6-media-recovery key is required")
        if isinstance(new_max_attempts, bool) or not isinstance(new_max_attempts, int):
            raise ValueError("new_max_attempts must be an explicit integer")
        moment = (now or _now()).astimezone(timezone.utc)
        if available_at is not None and available_at.tzinfo is None:
            raise ValueError("recovery availability must be timezone-aware")
        requested_available_at = available_at.astimezone(timezone.utc) if available_at else None
        if requested_available_at is not None and requested_available_at < moment:
            raise ValueError("recovery availability cannot precede the recovery proof")

        _, evidence_relative, evidence = self._load_media_repair_evidence(
            path=repair_evidence_path,
            expected_sha256=repair_evidence_sha256,
        )
        recovery_id = "phase6-dead-letter-recovery-" + hashlib.sha256(
            recovery_key.encode("utf-8")
        ).hexdigest()[:24]
        receipt: dict[str, Any]
        stored_state: str
        prepared_now = False

        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing_recovery = connection.execute(
                "SELECT * FROM dead_letter_recoveries WHERE recovery_key=?",
                (recovery_key,),
            ).fetchone()
            if existing_recovery is not None:
                stable = (
                    existing_recovery["recovery_id"] == recovery_id
                    and existing_recovery["job_id"] == job_id
                    and existing_recovery["task_type"] == "EXECUTE_PHASE6_VIDEO2_MEDIA"
                    and existing_recovery["repair_evidence_path"] == evidence_relative
                    and existing_recovery["repair_evidence_sha256"] == repair_evidence_sha256
                    and int(existing_recovery["new_max_attempts"]) == new_max_attempts
                )
                receipt = json.loads(existing_recovery["receipt_json"])
                if requested_available_at is not None:
                    stable = stable and receipt["recovery"]["available_at"] == _stamp(
                        requested_available_at
                    )
                if not stable:
                    connection.rollback()
                    raise QueueConflict("recovery key reused with divergent dead-letter command")
                stored_state = str(existing_recovery["state"])
                connection.commit()
            else:
                job = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (job_id,)
                ).fetchone()
                if job is None:
                    connection.rollback()
                    raise QueueConflict("exact recovery job does not exist")
                if job["channel_id"] != CHANNEL_ID:
                    connection.rollback()
                    raise PermissionError("dead-letter recovery is outside the HeroVerse channel")
                if job["task_type"] != "EXECUTE_PHASE6_VIDEO2_MEDIA":
                    connection.rollback()
                    raise QueueConflict("only the Phase 6 video-2 media task is recoverable here")
                if job["state"] != "DEAD_LETTER" or job["lease_owner"] is not None or job["lease_until"] is not None:
                    connection.rollback()
                    raise LeaseConflict("an unleased DEAD_LETTER job is required for recovery")
                prior_attempt_count = int(job["attempt_count"])
                prior_max_attempts = int(job["max_attempts"])
                if prior_attempt_count != prior_max_attempts:
                    connection.rollback()
                    raise QueueConflict("dead-letter retry budget is internally inconsistent")
                if new_max_attempts != prior_attempt_count + 1:
                    connection.rollback()
                    raise ValueError(
                        "media dead-letter recovery authorizes exactly one explicit additional attempt"
                    )
                original_error = str(job["last_error"] or "")
                if not original_error:
                    connection.rollback()
                    raise QueueConflict("dead-letter recovery requires the preserved original failure")
                binding = evidence["job_binding"]
                if (
                    binding["job_id"] != job_id
                    or binding["task_type"] != job["task_type"]
                    or binding["original_error"] != original_error
                    or binding["original_error_sha256"] != _sha256_text(original_error)
                ):
                    connection.rollback()
                    raise PermissionError("technical repair evidence is not bound to the exact failure")
                incidents = [
                    dict(item)
                    for item in connection.execute(
                        "SELECT incident_id,incident_type,severity,detail,created_at "
                        "FROM incidents WHERE job_id=? ORDER BY incident_id",
                        (job_id,),
                    ).fetchall()
                ]
                if not any(
                    item.get("incident_type") == "MAX_ATTEMPTS_EXCEEDED"
                    and item.get("severity") == "CRITICAL"
                    for item in incidents
                ):
                    connection.rollback()
                    raise QueueConflict("terminal dead-letter incident history is unavailable")
                recovery_available = requested_available_at or moment
                recovered_at = _stamp(moment)
                receipt = {
                    "schema_version": "1.0.0",
                    "receipt_id": recovery_id,
                    "recovery_key": recovery_key,
                    "phase": 6,
                    "status": "RECOVERED",
                    "queue_id": "heroverse-phase6-transactional-queue-v1",
                    "job": {
                        "job_id": job["job_id"],
                        "idempotency_key": job["idempotency_key"],
                        "operation_id": job["operation_id"],
                        "channel_id": job["channel_id"],
                        "task_type": job["task_type"],
                        "payload_sha256": _sha256_text(job["payload_json"]),
                        "checkpoint_sha256": _sha256_text(job["checkpoint_json"]),
                    },
                    "prior_dead_letter": {
                        "state": "DEAD_LETTER",
                        "attempt_count": prior_attempt_count,
                        "max_attempts": prior_max_attempts,
                        "available_at": job["available_at"],
                        "last_error": original_error,
                        "last_error_sha256": _sha256_text(original_error),
                        "incidents": incidents,
                        "history_mode": "PRESERVED_AGGREGATE_AND_INCIDENTS",
                    },
                    "repair_evidence": {
                        "evidence_id": evidence["evidence_id"],
                        "path": evidence_relative,
                        "sha256": repair_evidence_sha256,
                        "schema_version": evidence["schema_version"],
                        "status": evidence["status"],
                    },
                    "recovery": {
                        "state": "RETRY_WAIT",
                        "attempt_count": prior_attempt_count,
                        "prior_max_attempts": prior_max_attempts,
                        "new_max_attempts": new_max_attempts,
                        "budget_increment": 1,
                        "available_at": _stamp(recovery_available),
                        "last_error_preserved": True,
                        "checkpoint_preserved": True,
                        "external_steps_reexecuted": False,
                    },
                    "preservation": {
                        "job_id": True,
                        "idempotency_key": True,
                        "payload": True,
                        "checkpoint": True,
                        "attempt_count": True,
                        "incident_history": True,
                        "original_failure": True,
                    },
                    "external_api_calls": 0,
                    "publication_effects": 0,
                    "technical_cost_brl": 0,
                    "recovered_at": recovered_at,
                    "claim_boundary": [
                        "This receipt authorizes one local media retry only after exact technical repair evidence; it does not execute media or any external effect.",
                        "Recovery does not authorize quality approval, publication, spend, phase promotion or another retry budget extension.",
                    ],
                }
                self._validate_document(
                    "phase6_dead_letter_recovery_receipt.schema.json", receipt
                )
                receipt_json = _canonical(receipt)
                receipt_sha256 = _sha256_bytes((receipt_json + "\n").encode("utf-8"))
                connection.execute(
                    """INSERT INTO dead_letter_recoveries
                       (recovery_id,recovery_key,job_id,task_type,repair_evidence_path,
                        repair_evidence_sha256,prior_attempt_count,prior_max_attempts,
                        new_max_attempts,state,recovered_at,committed_at,receipt_json,
                        receipt_sha256)
                       VALUES (?,?,?,?,?,?,?,?,?,'PREPARED',?,NULL,?,?)""",
                    (
                        recovery_id,
                        recovery_key,
                        job_id,
                        job["task_type"],
                        evidence_relative,
                        repair_evidence_sha256,
                        prior_attempt_count,
                        prior_max_attempts,
                        new_max_attempts,
                        recovered_at,
                        receipt_json,
                        receipt_sha256,
                    ),
                )
                connection.commit()
                stored_state = "PREPARED"
                prepared_now = True

        with self._connection() as connection:
            stored = connection.execute(
                "SELECT * FROM dead_letter_recoveries WHERE recovery_key=?",
                (recovery_key,),
            ).fetchone()
            if stored is None:
                raise QueueConflict("prepared dead-letter recovery disappeared")
            receipt = json.loads(stored["receipt_json"])
            receipt_sha256 = str(stored["receipt_sha256"])
        if moment < _parse(receipt["recovered_at"]):
            raise ValueError("recovery replay time cannot precede its immutable preparation")
        receipt_path = self._materialize_dead_letter_recovery_receipt(
            receipt=receipt,
            expected_sha256=receipt_sha256,
        )

        if stored_state == "PREPARED":
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                recovery = connection.execute(
                    "SELECT * FROM dead_letter_recoveries WHERE recovery_key=?",
                    (recovery_key,),
                ).fetchone()
                job = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (job_id,)
                ).fetchone()
                if recovery is None or job is None:
                    connection.rollback()
                    raise QueueConflict("prepared recovery lost its queue binding")
                if recovery["state"] == "PREPARED":
                    preserved = (
                        job["state"] == "DEAD_LETTER"
                        and job["lease_owner"] is None
                        and job["lease_until"] is None
                        and int(job["attempt_count"])
                        == int(receipt["prior_dead_letter"]["attempt_count"])
                        and int(job["max_attempts"])
                        == int(receipt["prior_dead_letter"]["max_attempts"])
                        and job["last_error"] == receipt["prior_dead_letter"]["last_error"]
                        and _sha256_text(job["payload_json"])
                        == receipt["job"]["payload_sha256"]
                        and _sha256_text(job["checkpoint_json"])
                        == receipt["job"]["checkpoint_sha256"]
                    )
                    if not preserved:
                        connection.rollback()
                        raise QueueConflict(
                            "dead-letter job changed after recovery preparation"
                        )
                    committed_at = _stamp(moment)
                    updated = connection.execute(
                        """UPDATE jobs
                           SET state='RETRY_WAIT',max_attempts=?,available_at=?,
                               lease_owner=NULL,lease_until=NULL,updated_at=?
                           WHERE job_id=? AND state='DEAD_LETTER'""",
                        (
                            int(receipt["recovery"]["new_max_attempts"]),
                            receipt["recovery"]["available_at"],
                            committed_at,
                            job_id,
                        ),
                    )
                    if updated.rowcount != 1:
                        connection.rollback()
                        raise QueueConflict("dead-letter recovery compare-and-swap failed")
                    connection.execute(
                        "UPDATE dead_letter_recoveries SET state='COMMITTED',committed_at=? "
                        "WHERE recovery_key=? AND state='PREPARED'",
                        (committed_at, recovery_key),
                    )
                elif recovery["state"] != "COMMITTED":
                    connection.rollback()
                    raise QueueConflict("dead-letter recovery has an unknown journal state")
                final_job = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (job_id,)
                ).fetchone()
                connection.commit()
        else:
            with self._connection() as connection:
                final_job = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (job_id,)
                ).fetchone()
        if final_job is None:
            raise QueueConflict("recovered job disappeared")
        return {
            "job": self._job(final_job),
            "receipt": receipt,
            "receipt_path": receipt_path.relative_to(self.root).as_posix(),
            "receipt_sha256": receipt_sha256,
            "replayed": not prepared_now,
        }

    def get_by_idempotency_key(self, key: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            row = connection.execute("SELECT * FROM jobs WHERE idempotency_key=?", (key,)).fetchone()
            return self._job(row) if row is not None else None

    def get_dead_letter_recovery(self, recovery_key: str) -> dict[str, Any] | None:
        """Return one recovery-journal record without changing queue state.

        The accessor intentionally exposes only the persisted recovery contract
        and its integrity metadata.  It is used by the administrative recovery
        CLI to finish a PREPARED transaction after a crash, or to replay a
        COMMITTED transition idempotently through ``recover_media_dead_letter``.
        """

        if not isinstance(recovery_key, str) or not recovery_key:
            raise ValueError("a non-empty recovery key is required")
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM dead_letter_recoveries WHERE recovery_key=?",
                (recovery_key,),
            ).fetchone()
        if row is None:
            return None
        stored = dict(row)
        receipt = json.loads(str(stored.pop("receipt_json")))
        self._validate_document(
            "phase6_dead_letter_recovery_receipt.schema.json", receipt
        )
        observed_hash = _sha256_bytes((_canonical(receipt) + "\n").encode("utf-8"))
        if observed_hash != stored["receipt_sha256"]:
            raise PermissionError("dead-letter recovery journal receipt hash mismatch")
        stored["receipt"] = receipt
        return stored

    def _verified_recovered_media_deferral_chain(
        self,
        *,
        job: sqlite3.Row,
        recovery: dict[str, Any],
        recovery_receipt: dict[str, Any],
        original_max_attempts: int,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        with self._connection() as connection:
            rows = [
                dict(item)
                for item in connection.execute(
                    "SELECT * FROM recovered_media_deferrals "
                    "WHERE job_id=? ORDER BY ordinal,deferral_id",
                    (job["job_id"],),
                ).fetchall()
            ]
        expected = {
            "state": "RETRY_WAIT",
            "attempt_count": original_max_attempts,
            "max_attempts": original_max_attempts + 1,
            "available_at": recovery_receipt["recovery"]["available_at"],
            "last_error": recovery_receipt["prior_dead_letter"]["last_error"],
            "lease_owner": None,
            "lease_until": None,
        }
        previous_sha256 = str(recovery["receipt_sha256"])
        verified: list[dict[str, Any]] = []
        for ordinal, row in enumerate(rows, start=1):
            if row["state"] != "COMMITTED" or not row.get("committed_at"):
                raise QueueConflict(
                    "recovered-media deferral journal is not fully committed"
                )
            try:
                receipt = json.loads(str(row["receipt_json"]))
            except (TypeError, json.JSONDecodeError) as exc:
                raise PermissionError(
                    "recovered-media deferral journal receipt is unreadable"
                ) from exc
            self._validate_document(
                "phase6_recovered_media_deferral_receipt.schema.json", receipt
            )
            payload = (_canonical(receipt) + "\n").encode("utf-8")
            receipt_sha256 = _sha256_bytes(payload)
            receipt_path = (
                self.root
                / RECOVERED_MEDIA_DEFERRAL_RECEIPTS
                / f"{receipt['receipt_id']}.json"
            ).resolve()
            expected_id = "phase6-recovered-media-deferral-" + hashlib.sha256(
                str(row["deferral_key"]).encode("utf-8")
            ).hexdigest()[:24]
            if (
                int(row["ordinal"]) != ordinal
                or row["deferral_id"] != expected_id
                or receipt["receipt_id"] != expected_id
                or receipt["deferral_key"] != row["deferral_key"]
                or receipt["mode"] != row["mode"]
                or receipt["deferred_at"] != row["deferred_at"]
                or receipt_sha256 != row["receipt_sha256"]
                or receipt_path.parent
                != (self.root / RECOVERED_MEDIA_DEFERRAL_RECEIPTS).resolve()
                or not receipt_path.is_file()
                or receipt_path.read_bytes() != payload
            ):
                raise PermissionError(
                    "immutable recovered-media deferral receipt hash/identity diverged"
                )
            receipt_job = receipt["job"]
            grant = receipt["recovery_grant"]
            if (
                row["recovery_id"] != recovery["recovery_id"]
                or row["job_id"] != job["job_id"]
                or receipt_job["job_id"] != job["job_id"]
                or receipt_job["idempotency_key"] != job["idempotency_key"]
                or receipt_job["operation_id"] != job["operation_id"]
                or receipt_job["channel_id"] != job["channel_id"]
                or receipt_job["task_type"] != job["task_type"]
                or receipt_job["payload_sha256"]
                != _sha256_text(job["payload_json"])
                or receipt_job["checkpoint_sha256"]
                != recovery_receipt["job"]["checkpoint_sha256"]
                or grant["recovery_id"] != recovery["recovery_id"]
                or grant["recovery_key"] != recovery["recovery_key"]
                or grant["receipt_sha256"] != recovery["receipt_sha256"]
                or grant["receipt_path"]
                != (
                    DEAD_LETTER_RECOVERY_RECEIPTS
                    / f"{recovery['recovery_id']}.json"
                ).as_posix()
                or receipt["chain"]["ordinal"] != ordinal
                or receipt["chain"]["previous_receipt_sha256"]
                != previous_sha256
            ):
                raise PermissionError(
                    "recovered-media deferral is not bound to the immutable grant/command"
                )
            before = receipt["before"]
            claimed_before = {
                **expected,
                "state": "LEASED",
                "attempt_count": original_max_attempts + 1,
                "lease_owner": before.get("lease_owner"),
                "lease_until": before.get("lease_until"),
            }
            if receipt["mode"] == "RECONCILED_EXISTING_STATE":
                before_valid = ordinal == 1 and before == expected
            else:
                before_valid = before == expected or (
                    before == claimed_before
                    and isinstance(before.get("lease_owner"), str)
                    and bool(before["lease_owner"])
                    and isinstance(before.get("lease_until"), str)
                )
            after = receipt["after"]
            if (
                not before_valid
                or after["state"] != "RETRY_WAIT"
                or int(after["attempt_count"]) != original_max_attempts
                or int(after["max_attempts"]) != original_max_attempts + 1
                or after["last_error"] != RECOVERED_MEDIA_PRE_EFFECT_REASON
                or after["lease_owner"] is not None
                or after["lease_until"] is not None
                or _parse(after["available_at"]) <= _parse(before["available_at"])
                or _parse(after["available_at"]) <= _parse(receipt["deferred_at"])
                or _parse(receipt["recorded_at"]) < _parse(receipt["deferred_at"])
            ):
                raise PermissionError(
                    "recovered-media pre-effect deferral chain is inconsistent"
                )
            expected = after
            previous_sha256 = receipt_sha256
            verified.append(receipt)
        return expected, verified

    def get_verified_recovered_media_job(
        self,
        *,
        idempotency_key: str,
        operation_id: str,
        channel_id: str,
        task_type: str,
        payload: dict[str, Any],
        original_max_attempts: int = 3,
        _allow_unjournaled_pre_effect_deferral: bool = False,
    ) -> dict[str, Any] | None:
        """Resolve the one recovered media command without relaxing ``enqueue``.

        A normal command, including an existing command with its original retry
        budget, returns ``None`` and remains subject to the generic enqueue
        comparison.  A raised budget is accepted only for the exact Phase 6
        media job and only when one COMMITTED 3->4 recovery journal, its
        immutable receipt, repair evidence, original failure and incident
        history all revalidate.  This method is read-only.
        """

        if channel_id != CHANNEL_ID:
            raise PermissionError("Phase 6 queue is isolated to the HeroVerse channel")
        if task_type != "EXECUTE_PHASE6_VIDEO2_MEDIA":
            raise QueueConflict("recovered-job resolution is restricted to Phase 6 video-2 media")
        if original_max_attempts != 3:
            raise ValueError("the Phase 6 media executor original retry budget must be exactly 3")
        payload_json = _canonical(payload)
        expected_job_id = "job-" + hashlib.sha256(
            idempotency_key.encode("utf-8")
        ).hexdigest()[:24]
        with self._connection() as connection:
            job = connection.execute(
                "SELECT * FROM jobs WHERE idempotency_key=?", (idempotency_key,)
            ).fetchone()
            if job is None:
                return None
            if self._is_superseded_media_job(connection, job["job_id"]):
                raise QueueConflict(
                    "recovered media grant was superseded and is no longer executable"
                )
            recoveries = connection.execute(
                "SELECT * FROM dead_letter_recoveries WHERE job_id=? ORDER BY recovered_at,recovery_id",
                (job["job_id"],),
            ).fetchall()
            incidents = [
                dict(item)
                for item in connection.execute(
                    "SELECT incident_id,incident_type,severity,detail,created_at "
                    "FROM incidents WHERE job_id=? ORDER BY incident_id",
                    (job["job_id"],),
                ).fetchall()
            ]

        if (
            job["job_id"] != expected_job_id
            or job["operation_id"] != operation_id
            or job["channel_id"] != channel_id
            or job["task_type"] != task_type
            or job["payload_json"] != payload_json
        ):
            raise QueueConflict("recovered media job diverges from the exact executor command")
        if not recoveries:
            if int(job["max_attempts"]) != original_max_attempts:
                raise QueueConflict(
                    "media retry budget diverged without an official committed recovery"
                )
            return None
        if len(recoveries) != 1:
            raise QueueConflict("media job does not have exactly one recovery authorization")

        recovery = dict(recoveries[0])
        if (
            recovery["state"] != "COMMITTED"
            or not recovery.get("committed_at")
            or recovery["job_id"] != job["job_id"]
            or recovery["task_type"] != task_type
            or int(recovery["prior_attempt_count"]) != original_max_attempts
            or int(recovery["prior_max_attempts"]) != original_max_attempts
            or int(recovery["new_max_attempts"]) != original_max_attempts + 1
        ):
            raise QueueConflict("media recovery journal is not the exact committed 3-to-4 grant")

        try:
            receipt = json.loads(str(recovery["receipt_json"]))
        except (TypeError, json.JSONDecodeError) as exc:
            raise PermissionError("media recovery journal receipt is unreadable") from exc
        self._validate_document(
            "phase6_dead_letter_recovery_receipt.schema.json", receipt
        )
        receipt_payload = (_canonical(receipt) + "\n").encode("utf-8")
        receipt_hash = _sha256_bytes(receipt_payload)
        receipt_path = (
            self.root
            / DEAD_LETTER_RECOVERY_RECEIPTS
            / f"{receipt['receipt_id']}.json"
        ).resolve()
        if (
            receipt_hash != recovery["receipt_sha256"]
            or receipt_path.parent
            != (self.root / DEAD_LETTER_RECOVERY_RECEIPTS).resolve()
            or not receipt_path.is_file()
            or receipt_path.read_bytes() != receipt_payload
        ):
            raise PermissionError("immutable media recovery receipt hash/bytes diverged")

        expected_recovery_id = "phase6-dead-letter-recovery-" + hashlib.sha256(
            recovery["recovery_key"].encode("utf-8")
        ).hexdigest()[:24]
        receipt_job = receipt["job"]
        prior = receipt["prior_dead_letter"]
        grant = receipt["recovery"]
        if (
            recovery["recovery_id"] != expected_recovery_id
            or receipt["receipt_id"] != recovery["recovery_id"]
            or receipt["recovery_key"] != recovery["recovery_key"]
            or receipt_job["job_id"] != job["job_id"]
            or receipt_job["idempotency_key"] != idempotency_key
            or receipt_job["operation_id"] != operation_id
            or receipt_job["channel_id"] != channel_id
            or receipt_job["task_type"] != task_type
            or receipt_job["payload_sha256"] != _sha256_text(payload_json)
            or prior["state"] != "DEAD_LETTER"
            or int(prior["attempt_count"]) != original_max_attempts
            or int(prior["max_attempts"]) != original_max_attempts
            or prior["last_error_sha256"] != _sha256_text(prior["last_error"])
            or int(grant["attempt_count"]) != original_max_attempts
            or int(grant["prior_max_attempts"]) != original_max_attempts
            or int(grant["new_max_attempts"]) != original_max_attempts + 1
            or grant["budget_increment"] != 1
            or int(job["max_attempts"]) != original_max_attempts + 1
        ):
            raise PermissionError("immutable media recovery receipt does not bind the exact command")
        if incidents[: len(prior["incidents"])] != prior["incidents"]:
            raise PermissionError("preserved media dead-letter incident history diverged")

        _, evidence_relative, evidence = self._load_media_repair_evidence(
            path=recovery["repair_evidence_path"],
            expected_sha256=recovery["repair_evidence_sha256"],
        )
        evidence_binding = evidence["job_binding"]
        if (
            evidence_relative != receipt["repair_evidence"]["path"]
            or recovery["repair_evidence_sha256"]
            != receipt["repair_evidence"]["sha256"]
            or evidence["evidence_id"] != receipt["repair_evidence"]["evidence_id"]
            or evidence_binding["job_id"] != job["job_id"]
            or evidence_binding["task_type"] != task_type
            or evidence_binding["original_error"] != prior["last_error"]
            or evidence_binding["original_error_sha256"]
            != prior["last_error_sha256"]
        ):
            raise PermissionError("media repair evidence diverges from the recovered failure")

        expected_wait, deferrals = self._verified_recovered_media_deferral_chain(
            job=job,
            recovery=recovery,
            recovery_receipt=receipt,
            original_max_attempts=original_max_attempts,
        )

        attempt_count = int(job["attempt_count"])
        if attempt_count == original_max_attempts:
            exact_wait = (
                job["state"] != "RETRY_WAIT"
                or job["lease_owner"] is not None
                or job["lease_until"] is not None
                or job["available_at"] != expected_wait["available_at"]
                or job["last_error"] != expected_wait["last_error"]
                or _sha256_text(job["checkpoint_json"])
                != receipt_job["checkpoint_sha256"]
            )
            adoptable_unjournaled_wait = (
                _allow_unjournaled_pre_effect_deferral
                and not deferrals
                and job["state"] == "RETRY_WAIT"
                and job["lease_owner"] is None
                and job["lease_until"] is None
                and job["last_error"] == RECOVERED_MEDIA_PRE_EFFECT_REASON
                and _sha256_text(job["checkpoint_json"])
                == receipt_job["checkpoint_sha256"]
                and _parse(job["available_at"]) > _parse(grant["available_at"])
                and _parse(job["available_at"]) > _parse(job["updated_at"])
                and _parse(job["updated_at"]) >= _parse(recovery["committed_at"])
            )
            if exact_wait and not adoptable_unjournaled_wait:
                raise QueueConflict("recovered media job changed before its one authorized retry")
        elif attempt_count == original_max_attempts + 1:
            if job["state"] not in {"LEASED", "SUCCEEDED", "DEAD_LETTER"}:
                raise QueueConflict("recovered media retry has an impossible queue state")
            if job["state"] == "LEASED" and (
                not job["lease_owner"]
                or not job["lease_until"]
                or job["available_at"] != expected_wait["available_at"]
                or job["last_error"] != expected_wait["last_error"]
                or _sha256_text(job["checkpoint_json"])
                != receipt_job["checkpoint_sha256"]
            ):
                raise QueueConflict(
                    "leased recovered media retry diverges from its audited wait"
                )
        else:
            raise QueueConflict("recovered media job consumed an unauthorized attempt count")
        return self._job(job)

    def _commit_recovered_media_deferral(
        self,
        *,
        deferral_key: str,
        now: datetime,
    ) -> dict[str, Any]:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM recovered_media_deferrals WHERE deferral_key=?",
                (deferral_key,),
            ).fetchone()
        if row is None:
            raise QueueConflict("prepared recovered-media deferral disappeared")
        stored = dict(row)
        with self._connection() as connection:
            if self._is_superseded_media_job(connection, str(stored["job_id"])):
                raise QueueConflict(
                    "superseded recovered media job cannot commit a deferral"
                )
        receipt = json.loads(str(stored["receipt_json"]))
        receipt_path = self._materialize_recovered_media_deferral_receipt(
            receipt=receipt,
            expected_sha256=str(stored["receipt_sha256"]),
        )
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            journal = connection.execute(
                "SELECT * FROM recovered_media_deferrals WHERE deferral_key=?",
                (deferral_key,),
            ).fetchone()
            job = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (stored["job_id"],)
            ).fetchone()
            if journal is None or job is None:
                connection.rollback()
                raise QueueConflict(
                    "prepared recovered-media deferral lost its queue binding"
                )
            if self._is_superseded_media_job(connection, str(job["job_id"])):
                connection.rollback()
                raise QueueConflict(
                    "superseded recovered media job cannot commit a deferral"
                )
            if journal["state"] == "PREPARED":
                if (
                    _sha256_text(job["payload_json"])
                    != receipt["job"]["payload_sha256"]
                    or _sha256_text(job["checkpoint_json"])
                    != receipt["job"]["checkpoint_sha256"]
                ):
                    connection.rollback()
                    raise QueueConflict(
                        "recovered-media job content changed after deferral preparation"
                    )
                if receipt["mode"] == "TRANSACTIONAL":
                    if self._queue_state(job) != receipt["before"]:
                        connection.rollback()
                        raise QueueConflict(
                            "recovered-media job changed after deferral preparation"
                        )
                    if (
                        job["state"] == "LEASED"
                        and _parse(str(job["lease_until"]))
                        <= _parse(receipt["deferred_at"])
                    ):
                        connection.rollback()
                        raise LeaseConflict(
                            "recovered-media lease expired before pre-effect deferral"
                        )
                    after = receipt["after"]
                    updated = connection.execute(
                        """UPDATE jobs
                           SET state='RETRY_WAIT',attempt_count=?,available_at=?,
                               lease_owner=NULL,lease_until=NULL,last_error=?,updated_at=?
                           WHERE job_id=?""",
                        (
                            int(after["attempt_count"]),
                            after["available_at"],
                            after["last_error"],
                            receipt["deferred_at"],
                            job["job_id"],
                        ),
                    )
                    if updated.rowcount != 1:
                        connection.rollback()
                        raise QueueConflict(
                            "recovered-media deferral compare-and-swap failed"
                        )
                else:
                    if (
                        self._queue_state(job) != receipt["after"]
                        or job["updated_at"] != receipt["deferred_at"]
                    ):
                        connection.rollback()
                        raise QueueConflict(
                            "existing recovered-media deferral state changed before reconciliation"
                        )
                committed_at = _stamp(now)
                updated = connection.execute(
                    "UPDATE recovered_media_deferrals "
                    "SET state='COMMITTED',committed_at=? "
                    "WHERE deferral_key=? AND state='PREPARED'",
                    (committed_at, deferral_key),
                )
                if updated.rowcount != 1:
                    connection.rollback()
                    raise QueueConflict(
                        "recovered-media deferral journal commit failed"
                    )
            elif journal["state"] != "COMMITTED":
                connection.rollback()
                raise QueueConflict(
                    "recovered-media deferral has an unknown journal state"
                )
            final_job = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (stored["job_id"],)
            ).fetchone()
            final_journal = connection.execute(
                "SELECT * FROM recovered_media_deferrals WHERE deferral_key=?",
                (deferral_key,),
            ).fetchone()
            connection.commit()
        return {
            "job": self._job(final_job),
            "receipt": receipt,
            "receipt_path": receipt_path.relative_to(self.root).as_posix(),
            "receipt_sha256": str(final_journal["receipt_sha256"]),
            "replayed": stored["state"] == "COMMITTED",
        }

    def defer_recovered_media_pre_effect(
        self,
        job_id: str,
        *,
        deferral_key: str,
        available_at: datetime,
        reason: str,
        worker_id: str | None = None,
        reconcile_existing: bool = False,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Defer the exact recovered media grant with an immutable audit chain.

        ``TRANSACTIONAL`` mode writes PREPARED, materializes the immutable
        receipt, and only then changes the queue state and commits the journal.
        ``RECONCILED_EXISTING_STATE`` is deliberately narrower: it may adopt
        the one legacy/manual wait already present only when attempt, max,
        payload, checkpoint, lease state and recovery grant remain exact.
        Neither mode executes media or increases the recovery budget.
        """

        allowed = set(
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._:-"
        )
        if (
            not isinstance(deferral_key, str)
            or not deferral_key.startswith("phase6-recovered-media-deferral:")
            or len(deferral_key) > 224
            or any(character not in allowed for character in deferral_key)
        ):
            raise ValueError("a stable recovered-media deferral key is required")
        if reason != RECOVERED_MEDIA_PRE_EFFECT_REASON:
            raise ValueError("unsupported recovered-media pre-effect deferral reason")
        if available_at.tzinfo is None:
            raise ValueError("recovered-media deferral availability must be timezone-aware")
        moment = (now or _now()).astimezone(timezone.utc)
        target_available_at = available_at.astimezone(timezone.utc)
        requested_mode = (
            "RECONCILED_EXISTING_STATE" if reconcile_existing else "TRANSACTIONAL"
        )

        with self._connection() as connection:
            existing = connection.execute(
                "SELECT * FROM recovered_media_deferrals WHERE deferral_key=?",
                (deferral_key,),
            ).fetchone()
        if existing is not None:
            prior_receipt = json.loads(str(existing["receipt_json"]))
            if (
                existing["job_id"] != job_id
                or prior_receipt["mode"] != requested_mode
                or prior_receipt["after"]["available_at"]
                != _stamp(target_available_at)
                or prior_receipt["control"]["reason"] != reason
            ):
                raise QueueConflict(
                    "deferral key reused with divergent recovered-media command"
                )
            if moment < _parse(prior_receipt["recorded_at"]):
                raise ValueError(
                    "deferral replay time cannot precede its immutable preparation"
                )
            return self._commit_recovered_media_deferral(
                deferral_key=deferral_key, now=moment
            )
        if target_available_at <= moment:
            raise ValueError("recovered-media deferral availability must be in the future")

        with self._connection() as connection:
            raw_job = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (job_id,)
            ).fetchone()
            superseded = self._is_superseded_media_job(connection, job_id)
        if raw_job is None:
            raise QueueConflict("exact recovered-media job does not exist")
        if superseded:
            raise QueueConflict(
                "superseded recovered media job cannot be deferred"
            )
        job = self.get_verified_recovered_media_job(
            idempotency_key=raw_job["idempotency_key"],
            operation_id=raw_job["operation_id"],
            channel_id=raw_job["channel_id"],
            task_type=raw_job["task_type"],
            payload=json.loads(raw_job["payload_json"]),
            original_max_attempts=3,
            _allow_unjournaled_pre_effect_deferral=reconcile_existing,
        )
        if job is None:
            raise QueueConflict("job has no exact committed recovered-media grant")

        with self._connection() as connection:
            recovery_row = connection.execute(
                "SELECT * FROM dead_letter_recoveries WHERE job_id=?",
                (job_id,),
            ).fetchone()
            deferral_rows = connection.execute(
                "SELECT * FROM recovered_media_deferrals "
                "WHERE job_id=? ORDER BY ordinal,deferral_id",
                (job_id,),
            ).fetchall()
        if recovery_row is None or recovery_row["state"] != "COMMITTED":
            raise QueueConflict("recovered-media grant is not committed")
        recovery = dict(recovery_row)
        recovery_receipt = json.loads(str(recovery["receipt_json"]))
        expected_before, verified_deferrals = self._verified_recovered_media_deferral_chain(
            job=raw_job,
            recovery=recovery,
            recovery_receipt=recovery_receipt,
            original_max_attempts=3,
        )
        if len(deferral_rows) != len(verified_deferrals):
            raise QueueConflict("recovered-media deferral journal changed during verification")

        observed = self._queue_state(raw_job)
        if moment < _parse(str(raw_job["updated_at"])):
            raise ValueError("deferral time cannot precede the current queue state")
        if reconcile_existing:
            if deferral_rows or worker_id is not None:
                raise QueueConflict(
                    "only the first unleased legacy deferral may be reconciled"
                )
            expected_after = {
                **expected_before,
                "available_at": _stamp(target_available_at),
                "last_error": reason,
            }
            if observed != expected_after:
                raise QueueConflict(
                    "existing recovered-media state is not the exact adoptable deferral"
                )
            before = expected_before
            deferred_at = str(raw_job["updated_at"])
        else:
            if _parse(observed["available_at"]) >= target_available_at:
                raise ValueError("recovered-media deferral must extend the current wait")
            if observed["state"] == "LEASED":
                if (
                    not worker_id
                    or observed["lease_owner"] != worker_id
                    or not observed["lease_until"]
                    or _parse(str(observed["lease_until"])) <= moment
                ):
                    raise LeaseConflict(
                        "active recovered-media lease ownership is required"
                    )
            elif observed["state"] == "RETRY_WAIT":
                if worker_id is not None:
                    raise LeaseConflict(
                        "an unclaimed recovered-media deferral must not name a worker"
                    )
            else:
                raise LeaseConflict(
                    "only a waiting or actively leased recovered-media job can be deferred"
                )
            before = observed
            deferred_at = _stamp(moment)
        after = {
            "state": "RETRY_WAIT",
            "attempt_count": 3,
            "max_attempts": 4,
            "available_at": _stamp(target_available_at),
            "last_error": reason,
            "lease_owner": None,
            "lease_until": None,
        }
        ordinal = len(deferral_rows) + 1
        previous_sha256 = (
            str(deferral_rows[-1]["receipt_sha256"])
            if deferral_rows
            else str(recovery["receipt_sha256"])
        )
        deferral_id = "phase6-recovered-media-deferral-" + hashlib.sha256(
            deferral_key.encode("utf-8")
        ).hexdigest()[:24]
        receipt = {
            "schema_version": "1.0.0",
            "receipt_id": deferral_id,
            "deferral_key": deferral_key,
            "phase": 6,
            "status": "DEFERRED_PRE_EFFECT",
            "queue_id": "heroverse-phase6-transactional-queue-v1",
            "mode": requested_mode,
            "job": {
                "job_id": raw_job["job_id"],
                "idempotency_key": raw_job["idempotency_key"],
                "operation_id": raw_job["operation_id"],
                "channel_id": raw_job["channel_id"],
                "task_type": raw_job["task_type"],
                "payload_sha256": _sha256_text(raw_job["payload_json"]),
                "checkpoint_sha256": recovery_receipt["job"]["checkpoint_sha256"],
            },
            "recovery_grant": {
                "recovery_id": recovery["recovery_id"],
                "recovery_key": recovery["recovery_key"],
                "receipt_path": (
                    DEAD_LETTER_RECOVERY_RECEIPTS
                    / f"{recovery['recovery_id']}.json"
                ).as_posix(),
                "receipt_sha256": recovery["receipt_sha256"],
                "attempt_count": 3,
                "new_max_attempts": 4,
                "budget_increment": 1,
            },
            "chain": {
                "ordinal": ordinal,
                "previous_receipt_sha256": previous_sha256,
            },
            "before": before,
            "after": after,
            "control": {
                "reason": reason,
                "pre_effect_verified": True,
                "checkpoint_preserved": True,
                "attempt_grant_preserved": True,
                "external_steps_executed": False,
            },
            "external_api_calls": 0,
            "publication_effects": 0,
            "technical_cost_brl": 0,
            "deferred_at": deferred_at,
            "recorded_at": _stamp(moment),
            "claim_boundary": [
                "This receipt defers only the exact recovered local-media grant before any media or external effect.",
                "The deferral preserves the original checkpoint and single 3-to-4 attempt grant; it authorizes no additional retry, publication or spend.",
            ],
        }
        self._validate_document(
            "phase6_recovered_media_deferral_receipt.schema.json", receipt
        )
        receipt_json = _canonical(receipt)
        receipt_sha256 = _sha256_bytes((receipt_json + "\n").encode("utf-8"))

        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (job_id,)
            ).fetchone()
            current_count = connection.execute(
                "SELECT COUNT(*) FROM recovered_media_deferrals WHERE job_id=?",
                (job_id,),
            ).fetchone()[0]
            if (
                current is None
                or self._is_superseded_media_job(connection, job_id)
                or int(current_count) != len(deferral_rows)
                or self._queue_state(current) != observed
                or current["updated_at"] != raw_job["updated_at"]
                or current["payload_json"] != raw_job["payload_json"]
                or current["checkpoint_json"] != raw_job["checkpoint_json"]
            ):
                connection.rollback()
                raise QueueConflict(
                    "recovered-media job changed before deferral preparation"
                )
            connection.execute(
                """INSERT INTO recovered_media_deferrals
                   (deferral_id,deferral_key,recovery_id,job_id,ordinal,mode,state,
                    deferred_at,committed_at,receipt_json,receipt_sha256)
                   VALUES (?,?,?,?,?,?,'PREPARED',?,NULL,?,?)""",
                (
                    deferral_id,
                    deferral_key,
                    recovery["recovery_id"],
                    job_id,
                    ordinal,
                    requested_mode,
                    deferred_at,
                    receipt_json,
                    receipt_sha256,
                ),
            )
            connection.commit()
        return self._commit_recovered_media_deferral(
            deferral_key=deferral_key, now=moment
        )

    def _commit_media_job_supersession(
        self,
        *,
        supersession_key: str,
        now: datetime,
        post_effect_eligibility_verifier: Any = None,
    ) -> dict[str, Any]:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM media_job_supersessions WHERE supersession_key=?",
                (supersession_key,),
            ).fetchone()
        if row is None:
            raise QueueConflict("prepared media-job supersession disappeared")
        stored = dict(row)
        verified_stored = self._verified_media_job_supersession_row(
            stored, require_materialized=False
        )
        receipt = verified_stored["receipt"]
        is_post_effect = self._is_local_post_effect(receipt)
        is_forward_post_effect = (
            receipt.get("supersession_class")
            == "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION"
        )
        if is_post_effect and not callable(post_effect_eligibility_verifier):
            raise PermissionError(
                "post-effect supersession cannot commit without its eligibility verifier"
            )
        receipt_path = self._materialize_media_job_supersession_receipt(
            receipt=receipt,
            expected_sha256=str(stored["receipt_sha256"]),
        )
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            journal = connection.execute(
                "SELECT * FROM media_job_supersessions WHERE supersession_key=?",
                (supersession_key,),
            ).fetchone()
            stale = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?",
                (stored["superseded_job_id"],),
            ).fetchone()
            authority = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?",
                (stored["authoritative_job_id"],),
            ).fetchone()
            if journal is None or stale is None or authority is None:
                connection.rollback()
                raise QueueConflict("prepared media-job supersession lost its queue binding")
            if journal["state"] == "PREPARED":
                if (
                    self._queue_state(stale) != receipt["superseded_job"]["queue_state"]
                    or self._queue_state(authority)
                    != receipt["authoritative_job"]["queue_state"]
                    or _sha256_text(stale["payload_json"])
                    != receipt["superseded_job"]["payload_sha256"]
                    or _sha256_text(stale["checkpoint_json"])
                    != receipt["superseded_job"]["checkpoint_sha256"]
                    or _sha256_text(authority["payload_json"])
                    != receipt["authoritative_job"]["payload_sha256"]
                    or _sha256_text(authority["checkpoint_json"])
                    != receipt["authoritative_job"]["checkpoint_sha256"]
                ):
                    connection.rollback()
                    raise QueueConflict(
                        "media jobs changed after supersession preparation"
                    )
                if is_post_effect:
                    resolution = self._resolve_media_job_authority_in_connection(
                        connection,
                        receipt["lineage"]["authority_root_job_id"],
                        expected_operation_id=receipt["media_unit"]["operation_id"],
                        expected_channel_id=receipt["media_unit"]["channel_id"],
                        expected_task_type=receipt["media_unit"]["task_type"],
                        require_canonical_root=True,
                        ignored_supersession_id=str(journal["supersession_id"]),
                    )
                    if (
                        resolution["authoritative_job_id"] != stale["job_id"]
                        or resolution["authority_state"] != "SUCCEEDED"
                        or (
                            resolution["media_unit"] is not None
                            and resolution["media_unit"] != receipt["media_unit"]
                        )
                        or stale["lease_owner"] is not None
                        or stale["lease_until"] is not None
                        or json.loads(stale["checkpoint_json"]) == {}
                        or authority["state"] != "PENDING"
                        or int(authority["attempt_count"]) != 0
                        or authority["lease_owner"] is not None
                        or authority["lease_until"] is not None
                        or json.loads(authority["checkpoint_json"]) != {}
                    ):
                        connection.rollback()
                        raise QueueConflict(
                            "post-effect predecessor/successor changed before commit"
                        )
                    _, historical_input = self._load_media_input_reference(receipt["superseded_input_receipt"])
                    if is_forward_post_effect:
                        _, current_input = self._load_media_input_reference(receipt["authoritative_input_receipt"])
                        eligibility = self._verify_forward_post_effect_current_eligibility(
                            verifier=post_effect_eligibility_verifier,
                            reference=receipt["forward_post_effect_eligibility"]["eligibility_receipt"],
                            authority_root_job=resolution["root_job"],
                            predecessor_job=self._job(stale), successor_job=self._job(authority),
                            media_unit=receipt["media_unit"], historical_input=historical_input,
                            current_input=current_input,
                        )
                        expected_eligibility = receipt["forward_post_effect_eligibility"]
                    else:
                        eligibility = self._verify_post_effect_visual_eligibility(
                            verifier=post_effect_eligibility_verifier,
                            reference=receipt["post_effect_eligibility"]["eligibility_receipt"],
                            authority_root_job=resolution["root_job"],
                            predecessor_job=self._job(stale), media_unit=receipt["media_unit"],
                            input_receipt=historical_input,
                        )
                        expected_eligibility = receipt["post_effect_eligibility"]
                    if eligibility != expected_eligibility:
                        connection.rollback()
                        raise PermissionError(
                            "post-effect eligibility changed before supersession commit"
                        )
                else:
                    latest = (self.root / LATEST_PRODUCTION_INPUT_RECEIPT).resolve()
                    authoritative_path = (
                        self.root / receipt["authoritative_input_receipt"]["path"]
                    ).resolve()
                    if (
                        not latest.is_file()
                        or latest.read_bytes() != authoritative_path.read_bytes()
                    ):
                        connection.rollback()
                        raise PermissionError(
                            "authoritative production-input receipt changed before supersession commit"
                        )
                authority_superseded = connection.execute(
                    "SELECT 1 FROM media_job_supersessions "
                    "WHERE superseded_job_id=? AND supersession_id<>? "
                    "AND state IN ('PREPARED','COMMITTED') LIMIT 1",
                    (authority["job_id"], journal["supersession_id"]),
                ).fetchone()
                if authority_superseded is not None:
                    connection.rollback()
                    raise QueueConflict(
                        "proposed authoritative media job is itself superseded"
                    )
                committed_at = _stamp(now)
                updated = connection.execute(
                    "UPDATE media_job_supersessions SET state='COMMITTED',committed_at=? "
                    "WHERE supersession_key=? AND state='PREPARED'",
                    (committed_at, supersession_key),
                )
                if updated.rowcount != 1:
                    connection.rollback()
                    raise QueueConflict("media-job supersession journal commit failed")
            elif journal["state"] != "COMMITTED":
                connection.rollback()
                raise QueueConflict("media-job supersession has an unknown journal state")
            elif is_post_effect:
                resolution = self._resolve_media_job_authority_in_connection(
                    connection,
                    receipt["lineage"]["authority_root_job_id"],
                    expected_media_unit_key=receipt["media_unit"]["media_unit_key"],
                    expected_operation_id=receipt["media_unit"]["operation_id"],
                    expected_channel_id=receipt["media_unit"]["channel_id"],
                    expected_task_type=receipt["media_unit"]["task_type"],
                    require_canonical_root=True,
                )
                committed_edge_is_bound = any(
                    edge["supersession_id"] == receipt["receipt_id"]
                    and edge["superseded_job_id"] == stale["job_id"]
                    and edge["authoritative_job_id"] == authority["job_id"]
                    for edge in resolution["chain"]
                )
                if not committed_edge_is_bound:
                    connection.rollback()
                    raise QueueConflict(
                        "committed post-effect supersession left its canonical authority chain"
                    )
                _, historical_input = self._load_media_input_reference(receipt["superseded_input_receipt"])
                if is_forward_post_effect:
                    _, current_input = self._load_media_input_reference(receipt["authoritative_input_receipt"])
                    eligibility = self._verify_forward_post_effect_current_eligibility(
                        verifier=post_effect_eligibility_verifier,
                        reference=receipt["forward_post_effect_eligibility"]["eligibility_receipt"],
                        authority_root_job=resolution["root_job"], predecessor_job=self._job(stale),
                        successor_job=self._job(authority), media_unit=receipt["media_unit"],
                        historical_input=historical_input, current_input=current_input,
                    )
                    expected_eligibility = receipt["forward_post_effect_eligibility"]
                else:
                    eligibility = self._verify_post_effect_visual_eligibility(
                        verifier=post_effect_eligibility_verifier,
                        reference=receipt["post_effect_eligibility"]["eligibility_receipt"],
                        authority_root_job=resolution["root_job"], predecessor_job=self._job(stale),
                        media_unit=receipt["media_unit"], input_receipt=historical_input,
                    )
                    expected_eligibility = receipt["post_effect_eligibility"]
                if eligibility != expected_eligibility:
                    connection.rollback()
                    raise PermissionError(
                        "committed post-effect eligibility proof diverged on replay"
                    )
            final = connection.execute(
                "SELECT * FROM media_job_supersessions WHERE supersession_key=?",
                (supersession_key,),
            ).fetchone()
            connection.commit()
        return {
            "receipt": receipt,
            "receipt_path": receipt_path.relative_to(self.root).as_posix(),
            "receipt_sha256": str(final["receipt_sha256"]),
            "state": str(final["state"]),
            "replayed": stored["state"] == "COMMITTED",
        }

    def supersede_media_job(
        self,
        superseded_job_id: str,
        *,
        authoritative_job_id: str,
        supersession_key: str,
        media_unit: dict[str, Any],
        superseded_input_receipt: dict[str, Any],
        authoritative_input_receipt: dict[str, Any],
        identity_remediation: dict[str, Any] | None = None,
        pre_effect_remediation: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Disable one stale media command without rewriting queue history.

        The physical job state and any dead-letter/recovery receipts remain
        unchanged.  A PREPARED journal row immediately removes the stale job
        from every claim path; an immutable receipt is then materialized and
        the row becomes COMMITTED.  This gives storage faults a fail-closed
        outcome and avoids a misleading ``SUCCEEDED``/``DEAD_LETTER`` state.
        """

        allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._:-")
        if (
            not isinstance(supersession_key, str)
            or not supersession_key.startswith("phase6-media-supersession:")
            or len(supersession_key) > 240
            or any(character not in allowed for character in supersession_key)
        ):
            raise ValueError("a stable Phase 6 media supersession key is required")
        if superseded_job_id == authoritative_job_id:
            raise ValueError("a media job cannot supersede itself")
        moment = (now or _now()).astimezone(timezone.utc)

        unit = dict(media_unit)
        media_unit_key = str(unit.pop("media_unit_key", ""))
        expected_unit_key = "phase6-media-unit-" + hashlib.sha256(
            _canonical(unit).encode("utf-8")
        ).hexdigest()[:24]
        if media_unit_key != expected_unit_key:
            raise PermissionError("media-unit identity does not match its semantic contract")
        if (identity_remediation is None) == (pre_effect_remediation is None):
            raise PermissionError(
                "media-job supersession requires exactly one remediation proof class"
            )
        proof_name: str
        supplied_proof: dict[str, Any]
        supersession_class: str
        if identity_remediation is not None:
            proof_name = "identity_remediation"
            supplied_proof = identity_remediation
            supersession_class = "IDENTITY_ONLY"
        else:
            proof_name = "pre_effect_remediation"
            supplied_proof = pre_effect_remediation or {}
            supersession_class = "PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION"
        proof = dict(supplied_proof)
        proof_sha256 = str(proof.pop("proof_sha256", ""))
        identity_proof_valid = (
            supersession_class == "IDENTITY_ONLY"
            and supplied_proof.get("schema_version") == "1.0.0"
            and supplied_proof.get("policy_version")
            == "phase6-media-identity-remediation-whitelist-v1"
            and supplied_proof.get("status") == "PASS"
            and supplied_proof.get("media_unit_key") == media_unit_key
        )
        pre_effect_proof_valid = (
            supersession_class
            == "PRE_EFFECT_COMPILER_VOICE_TIMING_REMEDIATION"
            and supplied_proof.get("schema_version") == "1.0.0"
            and supplied_proof.get("policy_version")
            == "phase6-media-pre-effect-compiler-voice-remediation-whitelist-v1"
            and supplied_proof.get("supersession_class") == supersession_class
            and supplied_proof.get("status") == "PASS"
            and supplied_proof.get("media_unit_key") == media_unit_key
        )
        if not (identity_proof_valid or pre_effect_proof_valid) or proof_sha256 != _sha256_bytes(
            _canonical(proof).encode("utf-8")
        ):
            raise PermissionError(
                "media-job supersession lacks an intact whitelist remediation proof"
            )

        stale_path, stale_input = self._load_media_input_reference(
            superseded_input_receipt
        )
        authority_path, authority_input = self._load_media_input_reference(
            authoritative_input_receipt
        )
        if (
            supplied_proof.get("superseded_input_receipt_id")
            != stale_input["receipt_id"]
            or supplied_proof.get("authoritative_input_receipt_id")
            != authority_input["receipt_id"]
        ):
            raise PermissionError(
                "whitelist remediation proof is bound to different production inputs"
            )
        # Recompute at the queue boundary.  A caller cannot authorize a
        # supersession by fabricating a self-consistent high-level unit/proof.
        from .phase6_media_authority import verify_media_supersession_decision

        verified_decision = verify_media_supersession_decision(
            self.root,
            superseded_input_receipt_id=stale_input["receipt_id"],
            authoritative_input_receipt_id=authority_input["receipt_id"],
        )
        if (
            verified_decision.get("media_unit") != media_unit
            or verified_decision.get(proof_name) != supplied_proof
            or (
                supersession_class != "IDENTITY_ONLY"
                and verified_decision.get("supersession_class") != supersession_class
            )
        ):
            raise PermissionError(
                "media supersession unit/proof differs from independently recomputed evidence"
            )
        latest = (self.root / LATEST_PRODUCTION_INPUT_RECEIPT).resolve()
        if not latest.is_file() or latest.read_bytes() != authority_path.read_bytes():
            raise PermissionError(
                "authoritative media job is not bound to the current production inputs"
            )
        if stale_path == authority_path:
            raise PermissionError("media supersession requires two distinct input receipts")

        with self._connection() as connection:
            existing = connection.execute(
                "SELECT * FROM media_job_supersessions WHERE supersession_key=?",
                (supersession_key,),
            ).fetchone()
        if existing is not None:
            prior = json.loads(str(existing["receipt_json"]))
            if (
                existing["superseded_job_id"] != superseded_job_id
                or existing["authoritative_job_id"] != authoritative_job_id
                or existing["media_unit_key"] != media_unit_key
                or prior["superseded_input_receipt"] != superseded_input_receipt
                or prior["authoritative_input_receipt"]
                != authoritative_input_receipt
                or prior.get(proof_name) != supplied_proof
                or (
                    supersession_class == "IDENTITY_ONLY"
                    and "pre_effect_remediation" in prior
                )
                or (
                    supersession_class != "IDENTITY_ONLY"
                    and prior.get("supersession_class") != supersession_class
                )
            ):
                raise QueueConflict(
                    "supersession key reused with a divergent media authority decision"
                )
            if moment < _parse(prior["recorded_at"]):
                raise ValueError("supersession replay time precedes its preparation")
            return self._commit_media_job_supersession(
                supersession_key=supersession_key,
                now=moment,
            )

        with self._connection() as connection:
            stale = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (superseded_job_id,)
            ).fetchone()
            authority = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (authoritative_job_id,)
            ).fetchone()
            authority_is_superseded = (
                authority is not None
                and self._is_superseded_media_job(connection, authoritative_job_id)
            )
        if stale is None or authority is None:
            raise QueueConflict("both exact media jobs must exist before supersession")
        expected_task = "EXECUTE_PHASE6_VIDEO2_MEDIA"
        stale_payload = json.loads(stale["payload_json"])
        authority_payload = json.loads(authority["payload_json"])
        if (
            stale["task_type"] != expected_task
            or authority["task_type"] != expected_task
            or stale["operation_id"] != authority["operation_id"]
            or stale["channel_id"] != authority["channel_id"]
            or stale["channel_id"] != CHANNEL_ID
            or stale_payload.get("action") != "SYNTHESIZE_AND_RENDER_VIDEO_2"
            or authority_payload.get("action") != "SYNTHESIZE_AND_RENDER_VIDEO_2"
            or stale_payload.get("input_receipt_id") != stale_input["receipt_id"]
            or authority_payload.get("input_receipt_id")
            != authority_input["receipt_id"]
            or unit.get("operation_id") != authority["operation_id"]
            or unit.get("channel_id") != CHANNEL_ID
            or unit.get("task_type") != expected_task
        ):
            raise PermissionError(
                "media supersession jobs, receipts and semantic unit do not bind"
            )
        for label, row in (("superseded", stale), ("authoritative", authority)):
            if (
                row["state"] not in {"PENDING", "RETRY_WAIT"}
                or row["lease_owner"] is not None
                or row["lease_until"] is not None
            ):
                raise LeaseConflict(
                    f"{label} media job must be unleased and unfinished"
                )
            checkpoint = json.loads(row["checkpoint_json"])
            if supersession_class != "IDENTITY_ONLY" and checkpoint != {}:
                raise PermissionError(
                    f"{label} media job checkpoint must be exactly empty for PRE_EFFECT supersession"
                )
            if any(
                checkpoint.get(key)
                for key in (
                    "voice_manifest", "render_manifest", "render_id",
                    "publication_receipt", "video_id",
                )
            ):
                raise PermissionError(
                    f"{label} media job already contains a completed/external effect"
                )
        if authority_is_superseded:
            raise QueueConflict("proposed authoritative media job is itself superseded")

        supersession_id = "phase6-media-supersession-" + hashlib.sha256(
            supersession_key.encode("utf-8")
        ).hexdigest()[:24]
        receipt = {
            "schema_version": (
                "1.0.0" if supersession_class == "IDENTITY_ONLY" else "1.1.0"
            ),
            "receipt_id": supersession_id,
            "supersession_key": supersession_key,
            "phase": 6,
            "status": "SUPERSEDED_PRE_EFFECT",
            "queue_id": "heroverse-phase6-transactional-queue-v1",
            "media_unit": media_unit,
            "superseded_job": {
                "job_id": stale["job_id"],
                "idempotency_key": stale["idempotency_key"],
                "payload_sha256": _sha256_text(stale["payload_json"]),
                "checkpoint_sha256": _sha256_text(stale["checkpoint_json"]),
                "queue_state": self._queue_state(stale),
            },
            "authoritative_job": {
                "job_id": authority["job_id"],
                "idempotency_key": authority["idempotency_key"],
                "payload_sha256": _sha256_text(authority["payload_json"]),
                "checkpoint_sha256": _sha256_text(authority["checkpoint_json"]),
                "queue_state": self._queue_state(authority),
            },
            "superseded_input_receipt": superseded_input_receipt,
            "authoritative_input_receipt": authoritative_input_receipt,
            "control": {
                "authoritative_is_current_latest": True,
                "both_jobs_unleased": True,
                "both_jobs_incomplete": True,
                "superseded_claims_blocked": True,
                "history_preserved": True,
                "external_api_calls": 0,
                "publication_effects": 0,
                "technical_cost_brl": 0,
            },
            "recorded_at": _stamp(moment),
            "claim_boundary": [
                "This receipt disables only the stale local media command for the same immutable semantic unit.",
                "It preserves both physical queue jobs and every recovery/incident receipt; it creates no render, upload, publication, API call or spend.",
                "Only the current production-input receipt remains executable, and it still requires all downstream quality and release gates.",
            ],
        }
        if supersession_class == "IDENTITY_ONLY":
            receipt["identity_remediation"] = supplied_proof
            receipt["control"]["same_semantic_media_unit"] = True
        else:
            receipt["supersession_class"] = supersession_class
            receipt["pre_effect_remediation"] = supplied_proof
            receipt["control"]["same_stable_media_contract"] = True
            receipt["control"]["both_checkpoints_empty"] = True
            receipt["claim_boundary"] = [
                "This receipt disables only one stale local media command before render, upload, publication, API call or spend.",
                "The operation, channel, protocol, treatment variable, candidate, rights authority and zero-cost contract remain hash-bound and identical.",
                "Only compiler identity, pinned voice-slot timing, hash-derived lineage, timeline derivation and deterministic rights-safe allocation may differ.",
                "The current production-input receipt remains subject to every downstream quality and release gate.",
            ]
        self._validate_document(
            "phase6_media_job_supersession_receipt.schema.json", receipt
        )
        receipt_json = _canonical(receipt)
        receipt_sha256 = _sha256_bytes((receipt_json + "\n").encode("utf-8"))
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current_stale = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (superseded_job_id,)
            ).fetchone()
            current_authority = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (authoritative_job_id,)
            ).fetchone()
            if (
                current_stale is None
                or current_authority is None
                or self._queue_state(current_stale) != self._queue_state(stale)
                or self._queue_state(current_authority) != self._queue_state(authority)
                or current_stale["payload_json"] != stale["payload_json"]
                or current_stale["checkpoint_json"] != stale["checkpoint_json"]
                or current_authority["payload_json"] != authority["payload_json"]
                or current_authority["checkpoint_json"] != authority["checkpoint_json"]
            ):
                connection.rollback()
                raise QueueConflict("media jobs changed before supersession preparation")
            connection.execute(
                """INSERT INTO media_job_supersessions
                   (supersession_id,supersession_key,media_unit_key,
                    superseded_job_id,authoritative_job_id,state,recorded_at,
                    committed_at,receipt_json,receipt_sha256)
                   VALUES (?,?,?,?,?,'PREPARED',?,NULL,?,?)""",
                (
                    supersession_id,
                    supersession_key,
                    media_unit_key,
                    superseded_job_id,
                    authoritative_job_id,
                    receipt["recorded_at"],
                    receipt_json,
                    receipt_sha256,
                ),
            )
            connection.commit()
        return self._commit_media_job_supersession(
            supersession_key=supersession_key,
            now=moment,
        )

    def create_post_effect_visual_contract_successor(
        self,
        authority_root_job_id: str,
        *,
        predecessor_job_id: str,
        media_unit: dict[str, Any],
        input_receipt: dict[str, Any],
        eligibility_receipt: dict[str, Any],
        eligibility_verifier: Any = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Create one local-only post-effect generation without reopening history.

        The semantic eligibility verifier is deliberately injected and mandatory:
        until the dedicated verifier exists, production calls fail closed.  Tests
        may supply a fixture verifier, but the queue still reopens the immutable
        evidence and binds its result in both the PREPARED and COMMITTED
        transactions.
        """

        if not callable(eligibility_verifier):
            raise PermissionError(
                "post-effect visual remediation requires an explicit eligibility verifier"
            )
        for label, job_id in (
            ("authority root", authority_root_job_id),
            ("predecessor", predecessor_job_id),
        ):
            if not isinstance(job_id, str) or not job_id.startswith("job-"):
                raise ValueError(f"an exact {label} media job id is required")
        moment = (now or _now()).astimezone(timezone.utc)
        timestamp = _stamp(moment)
        unit = dict(media_unit)
        media_unit_key = str(unit.pop("media_unit_key", ""))
        expected_media_unit_key = "phase6-media-unit-" + hashlib.sha256(
            _canonical(unit).encode("utf-8")
        ).hexdigest()[:24]
        if media_unit_key != expected_media_unit_key:
            raise PermissionError("media-unit identity does not match its semantic contract")
        expected_task = "EXECUTE_PHASE6_VIDEO2_MEDIA"
        if (
            unit.get("operation_id") != "heroverse-phase6-controlled-longform-v1"
            or unit.get("channel_id") != CHANNEL_ID
            or unit.get("task_type") != expected_task
            or unit.get("production_action") != "SYNTHESIZE_AND_RENDER_VIDEO_2"
        ):
            raise PermissionError(
                "post-effect media unit is outside the Phase 6 Video 2 contract"
            )

        # This seed contains only immutable caller references.  The verifier's
        # proof hash is added after it has been recomputed under BEGIN IMMEDIATE.
        decision_seed = {
            "supersession_class": "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION",
            "authority_root_job_id": authority_root_job_id,
            "predecessor_job_id": predecessor_job_id,
            "media_unit_key": media_unit_key,
            "input_receipt": input_receipt,
            "eligibility_receipt": eligibility_receipt,
        }

        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                root_row = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (authority_root_job_id,)
                ).fetchone()
                predecessor_row = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (predecessor_job_id,)
                ).fetchone()
                if root_row is None or predecessor_row is None:
                    raise QueueConflict(
                        "post-effect authority root and predecessor must both exist"
                    )
                root_job = self._job(root_row)
                predecessor_job = self._job(predecessor_row)
                _, loaded_input = self._load_media_input_reference(input_receipt)
                if (
                    predecessor_job["state"] != "SUCCEEDED"
                    or predecessor_job["lease_owner"] is not None
                    or predecessor_job["lease_until"] is not None
                    or predecessor_job["checkpoint"] == {}
                ):
                    raise LeaseConflict(
                        "post-effect predecessor must be SUCCEEDED, unleased and checkpointed"
                    )
                if moment < _parse(predecessor_job["updated_at"]):
                    raise ValueError(
                        "post-effect remediation time precedes predecessor completion"
                    )
                if (
                    root_job["operation_id"] != unit["operation_id"]
                    or root_job["channel_id"] != CHANNEL_ID
                    or root_job["task_type"] != expected_task
                    or predecessor_job["operation_id"] != unit["operation_id"]
                    or predecessor_job["channel_id"] != CHANNEL_ID
                    or predecessor_job["task_type"] != expected_task
                    or predecessor_job["payload"].get("action")
                    != "SYNTHESIZE_AND_RENDER_VIDEO_2"
                    or predecessor_job["payload"].get("input_receipt_id")
                    != loaded_input["receipt_id"]
                    or loaded_input.get("publication_authorized") is not False
                    or loaded_input.get("technical_cost_brl") != 0
                ):
                    raise PermissionError(
                        "post-effect predecessor/input diverges from the stable media contract"
                    )
                eligibility = self._verify_post_effect_visual_eligibility(
                    verifier=eligibility_verifier,
                    reference=eligibility_receipt,
                    authority_root_job=root_job,
                    predecessor_job=predecessor_job,
                    media_unit=media_unit,
                    input_receipt=loaded_input,
                )
                identity = {
                    **decision_seed,
                    "eligibility_proof_sha256": eligibility["proof_sha256"],
                }
                decision_digest = hashlib.sha256(
                    _canonical(identity).encode("utf-8")
                ).hexdigest()
                supersession_key = (
                    "phase6-media-supersession:post-effect-visual:"
                    + decision_digest[:40]
                )
                supersession_id = "phase6-media-supersession-" + hashlib.sha256(
                    supersession_key.encode("utf-8")
                ).hexdigest()[:24]
                idempotency_key = (
                    "phase6:post-effect-visual-contract:" + decision_digest
                )
                successor_job_id = "job-" + hashlib.sha256(
                    idempotency_key.encode("utf-8")
                ).hexdigest()[:24]
                generation_id = "phase6-render-generation-" + decision_digest[:24]
                generation_namespace = (
                    "output/production/phase6/video-002/render-generations/"
                    + successor_job_id
                )

                existing = connection.execute(
                    "SELECT * FROM media_job_supersessions WHERE supersession_key=?",
                    (supersession_key,),
                ).fetchone()
                ignored_id = str(existing["supersession_id"]) if existing else None
                resolution = self._resolve_media_job_authority_in_connection(
                    connection,
                    authority_root_job_id,
                    expected_operation_id=unit["operation_id"],
                    expected_channel_id=CHANNEL_ID,
                    expected_task_type=expected_task,
                    require_canonical_root=True,
                    ignored_supersession_id=ignored_id,
                )
                if (
                    resolution["authoritative_job_id"] != predecessor_job_id
                    or resolution["authority_state"] != "SUCCEEDED"
                    or (
                        resolution["media_unit"] is not None
                        and resolution["media_unit"] != media_unit
                    )
                ):
                    raise QueueConflict(
                        "post-effect predecessor is not the exact canonical SUCCEEDED tail"
                    )
                prior_chain = resolution["chain"]
                prior_chain_sha256 = _sha256_text(_canonical(prior_chain))
                successor_payload = {
                    "input_receipt_id": loaded_input["receipt_id"],
                    "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
                    "execution_mode": (
                        "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"
                    ),
                    "authority_root_job_id": authority_root_job_id,
                    "predecessor_job_id": predecessor_job_id,
                    "media_unit_key": media_unit_key,
                    "eligibility_receipt_id": eligibility_receipt["receipt_id"],
                    "eligibility_receipt_sha256": eligibility_receipt["sha256"],
                    "eligibility_proof_sha256": eligibility["proof_sha256"],
                    "render_generation_id": generation_id,
                    "render_namespace": generation_namespace,
                }
                successor_payload_json = _canonical(successor_payload)

                if existing is not None:
                    verified = self._verified_media_job_supersession_row(
                        existing, require_materialized=False
                    )
                    prior = verified["receipt"]
                    if moment < _parse(prior["recorded_at"]):
                        raise ValueError(
                            "post-effect supersession replay time precedes preparation"
                        )
                    successor_row = connection.execute(
                        "SELECT * FROM jobs WHERE job_id=?", (successor_job_id,)
                    ).fetchone()
                    stable = (
                        existing["superseded_job_id"] == predecessor_job_id
                        and existing["authoritative_job_id"] == successor_job_id
                        and existing["media_unit_key"] == media_unit_key
                        and prior.get("supersession_class")
                        == "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"
                        and prior.get("media_unit") == media_unit
                        and prior.get("superseded_input_receipt") == input_receipt
                        and prior.get("authoritative_input_receipt") == input_receipt
                        and prior.get("post_effect_eligibility") == eligibility
                        and prior.get("lineage", {}).get("authority_root_job_id")
                        == authority_root_job_id
                        and prior.get("lineage", {}).get("predecessor_job_id")
                        == predecessor_job_id
                        and prior.get("lineage", {}).get("prior_chain") == prior_chain
                        and prior.get("lineage", {}).get("prior_chain_sha256")
                        == prior_chain_sha256
                        and prior.get("lineage", {}).get("render_generation_id")
                        == generation_id
                        and prior.get("lineage", {}).get("render_namespace")
                        == generation_namespace
                        and successor_row is not None
                        and successor_row["idempotency_key"] == idempotency_key
                        and successor_row["payload_json"] == successor_payload_json
                    )
                    if not stable:
                        raise QueueConflict(
                            "post-effect supersession replay diverges from its immutable decision"
                        )
                    connection.commit()
                    return self._commit_media_job_supersession(
                        supersession_key=supersession_key,
                        now=moment,
                        post_effect_eligibility_verifier=eligibility_verifier,
                    )

                conflicting_job = connection.execute(
                    "SELECT * FROM jobs WHERE idempotency_key=? OR job_id=?",
                    (idempotency_key, successor_job_id),
                ).fetchone()
                if conflicting_job is not None:
                    raise QueueConflict(
                        "post-effect successor identity collides with another queue job"
                    )
                connection.execute(
                    """INSERT INTO jobs
                    (job_id,idempotency_key,operation_id,channel_id,task_type,payload_json,
                     state,attempt_count,max_attempts,available_at,lease_owner,lease_until,
                     checkpoint_json,last_error,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,'PENDING',0,?,?,NULL,NULL,'{}',NULL,?,?)""",
                    (
                        successor_job_id,
                        idempotency_key,
                        predecessor_job["operation_id"],
                        predecessor_job["channel_id"],
                        predecessor_job["task_type"],
                        successor_payload_json,
                        int(predecessor_job["max_attempts"]),
                        timestamp,
                        timestamp,
                        timestamp,
                    ),
                )
                successor_row = connection.execute(
                    "SELECT * FROM jobs WHERE job_id=?", (successor_job_id,)
                ).fetchone()
                receipt = {
                    "schema_version": "1.0.0",
                    "receipt_id": supersession_id,
                    "supersession_key": supersession_key,
                    "phase": 6,
                    "status": "SUPERSEDED_POST_EFFECT_LOCAL",
                    "queue_id": "heroverse-phase6-transactional-queue-v1",
                    "supersession_class": (
                        "POST_EFFECT_LOCAL_VISUAL_CONTRACT_REMEDIATION"
                    ),
                    "media_unit": media_unit,
                    "root_job": {
                        "job_id": root_row["job_id"],
                        "idempotency_key": root_row["idempotency_key"],
                        "payload_sha256": _sha256_text(root_row["payload_json"]),
                        "checkpoint_sha256": _sha256_text(root_row["checkpoint_json"]),
                        "queue_state": self._queue_state(root_row),
                    },
                    "superseded_job": {
                        "job_id": predecessor_row["job_id"],
                        "idempotency_key": predecessor_row["idempotency_key"],
                        "payload_sha256": _sha256_text(predecessor_row["payload_json"]),
                        "checkpoint_sha256": _sha256_text(
                            predecessor_row["checkpoint_json"]
                        ),
                        "queue_state": self._queue_state(predecessor_row),
                    },
                    "authoritative_job": {
                        "job_id": successor_row["job_id"],
                        "idempotency_key": successor_row["idempotency_key"],
                        "payload_sha256": _sha256_text(successor_row["payload_json"]),
                        "checkpoint_sha256": _sha256_text(
                            successor_row["checkpoint_json"]
                        ),
                        "queue_state": self._queue_state(successor_row),
                    },
                    "superseded_input_receipt": input_receipt,
                    "authoritative_input_receipt": input_receipt,
                    "post_effect_eligibility": eligibility,
                    "lineage": {
                        "authority_root_job_id": authority_root_job_id,
                        "predecessor_job_id": predecessor_job_id,
                        "prior_chain": prior_chain,
                        "prior_chain_sha256": prior_chain_sha256,
                        "render_generation_id": generation_id,
                        "render_namespace": generation_namespace,
                    },
                    "control": {
                        "same_input_receipt": True,
                        "predecessor_terminal_succeeded": True,
                        "predecessor_unleased": True,
                        "predecessor_checkpoint_preserved": True,
                        "successor_pre_effect": True,
                        "successor_attempt_count": 0,
                        "successor_checkpoint_empty": True,
                        "successor_claims_blocked_until_commit": True,
                        "predecessor_claims_blocked": True,
                        "history_preserved": True,
                        "publication_authorized": False,
                        "external_effects_authorized": False,
                        "technical_cost_brl": 0,
                    },
                    "recorded_at": timestamp,
                    "claim_boundary": [
                        "This receipt replaces only a completed local visual generation contract; it never reopens or rewrites the predecessor.",
                        "The experiment, opportunity candidate, copy, voice timing, timeline, assets, rights, cost and frozen Style Bible remain eligibility-proof-bound.",
                        "The successor is local-only and remains subject to independent semantic, visual, quality, release and publication gates.",
                    ],
                }
                self._validate_document(
                    "phase6_post_effect_media_job_supersession_receipt.schema.json",
                    receipt,
                )
                receipt_json = _canonical(receipt)
                receipt_sha256 = _sha256_bytes(
                    (receipt_json + "\n").encode("utf-8")
                )
                connection.execute(
                    """INSERT INTO media_job_supersessions
                       (supersession_id,supersession_key,media_unit_key,
                        superseded_job_id,authoritative_job_id,state,recorded_at,
                        committed_at,receipt_json,receipt_sha256)
                       VALUES (?,?,?,?,?,'PREPARED',?,NULL,?,?)""",
                    (
                        supersession_id,
                        supersession_key,
                        media_unit_key,
                        predecessor_job_id,
                        successor_job_id,
                        timestamp,
                        receipt_json,
                        receipt_sha256,
                    ),
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise

        return self._commit_media_job_supersession(
            supersession_key=supersession_key,
            now=moment,
            post_effect_eligibility_verifier=eligibility_verifier,
        )

    def adopt_forward_post_effect_current_input(
        self,
        authority_root_job_id: str,
        *,
        predecessor_job_id: str,
        successor_job_id: str,
        media_unit: dict[str, Any],
        historical_input_receipt: dict[str, Any],
        current_input_receipt: dict[str, Any],
        eligibility_receipt: dict[str, Any],
        eligibility_verifier: Any = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Atomically adopt an existing current job after terminal local history.

        Unlike the legacy post-effect path, this never creates a replacement
        job and never treats an old input receipt as current.  It only records
        a one-way, reviewed authority edge when an injected verifier binds the
        terminal historical work to the current zero-effect queue command.
        """
        if not callable(eligibility_verifier):
            raise PermissionError("forward post-effect remediation requires an explicit eligibility verifier")
        for label, job_id in (("authority root", authority_root_job_id), ("predecessor", predecessor_job_id), ("successor", successor_job_id)):
            if not isinstance(job_id, str) or not job_id.startswith("job-"):
                raise ValueError(f"an exact {label} media job id is required")
        moment = (now or _now()).astimezone(timezone.utc)
        unit = dict(media_unit)
        media_unit_key = str(unit.pop("media_unit_key", ""))
        if media_unit_key != "phase6-media-unit-" + hashlib.sha256(_canonical(unit).encode("utf-8")).hexdigest()[:24]:
            raise PermissionError("media-unit identity does not match its semantic contract")
        if unit.get("channel_id") != CHANNEL_ID or unit.get("task_type") != "EXECUTE_PHASE6_VIDEO2_MEDIA" or unit.get("production_action") != "SYNTHESIZE_AND_RENDER_VIDEO_2":
            raise PermissionError("forward post-effect media unit is outside the Phase 6 Video 2 contract")
        historical_path, historical_input = self._load_media_input_reference(historical_input_receipt)
        current_path, current_input = self._load_media_input_reference(current_input_receipt)
        latest = (self.root / LATEST_PRODUCTION_INPUT_RECEIPT).resolve()
        if historical_path == current_path or not latest.is_file() or latest.read_bytes() != current_path.read_bytes():
            raise PermissionError("forward post-effect adoption requires an exact distinct current production input")
        seed = {
            "supersession_class": "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION",
            "authority_root_job_id": authority_root_job_id,
            "predecessor_job_id": predecessor_job_id,
            "successor_job_id": successor_job_id,
            "media_unit_key": media_unit_key,
            "historical_input_receipt": historical_input_receipt,
            "current_input_receipt": current_input_receipt,
            "eligibility_receipt": eligibility_receipt,
        }
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                root_row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (authority_root_job_id,)).fetchone()
                predecessor_row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (predecessor_job_id,)).fetchone()
                successor_row = connection.execute("SELECT * FROM jobs WHERE job_id=?", (successor_job_id,)).fetchone()
                if root_row is None or predecessor_row is None or successor_row is None:
                    raise QueueConflict("forward post-effect root, predecessor and successor must all exist")
                root_job, predecessor, successor = self._job(root_row), self._job(predecessor_row), self._job(successor_row)
                if (
                    predecessor["state"] != "SUCCEEDED" or predecessor["lease_owner"] is not None or predecessor["lease_until"] is not None or predecessor["checkpoint"] == {}
                    or successor["state"] != "PENDING" or successor["attempt_count"] != 0 or successor["lease_owner"] is not None or successor["lease_until"] is not None or successor["checkpoint"] != {}
                    or predecessor["payload"].get("input_receipt_id") != historical_input["receipt_id"]
                    or successor["payload"].get("input_receipt_id") != current_input["receipt_id"]
                    or any(job["operation_id"] != unit["operation_id"] or job["channel_id"] != CHANNEL_ID or job["task_type"] != "EXECUTE_PHASE6_VIDEO2_MEDIA" or job["payload"].get("action") != "SYNTHESIZE_AND_RENDER_VIDEO_2" for job in (root_job, predecessor, successor))
                    or historical_input.get("publication_authorized") is not False or current_input.get("publication_authorized") is not False
                    or historical_input.get("technical_cost_brl") != 0 or current_input.get("technical_cost_brl") != 0
                ):
                    raise QueueConflict("forward post-effect predecessor/current successor is not a safe zero-effect transition")
                eligibility = self._verify_forward_post_effect_current_eligibility(
                    verifier=eligibility_verifier, reference=eligibility_receipt,
                    authority_root_job=root_job, predecessor_job=predecessor,
                    successor_job=successor, media_unit=media_unit,
                    historical_input=historical_input, current_input=current_input,
                )
                identity = {**seed, "eligibility_proof_sha256": eligibility["proof_sha256"]}
                digest = hashlib.sha256(_canonical(identity).encode("utf-8")).hexdigest()
                supersession_key = "phase6-media-supersession:forward-post-effect:" + digest[:40]
                supersession_id = "phase6-media-supersession-" + hashlib.sha256(supersession_key.encode("utf-8")).hexdigest()[:24]
                existing = connection.execute("SELECT * FROM media_job_supersessions WHERE supersession_key=?", (supersession_key,)).fetchone()
                if existing is not None:
                    prior = self._verified_media_job_supersession_row(existing, require_materialized=False)["receipt"]
                    stable = (prior.get("supersession_class") == seed["supersession_class"] and prior.get("superseded_job", {}).get("job_id") == predecessor_job_id and prior.get("authoritative_job", {}).get("job_id") == successor_job_id and prior.get("media_unit") == media_unit and prior.get("superseded_input_receipt") == historical_input_receipt and prior.get("authoritative_input_receipt") == current_input_receipt and prior.get("forward_post_effect_eligibility") == eligibility)
                    if not stable:
                        raise QueueConflict("forward post-effect key reused with divergent authority evidence")
                    connection.commit()
                    return self._commit_media_job_supersession(supersession_key=supersession_key, now=moment, post_effect_eligibility_verifier=eligibility_verifier)
                resolution = self._resolve_media_job_authority_in_connection(connection, authority_root_job_id, expected_operation_id=unit["operation_id"], expected_channel_id=CHANNEL_ID, expected_task_type="EXECUTE_PHASE6_VIDEO2_MEDIA", require_canonical_root=True)
                if resolution["authoritative_job_id"] != predecessor_job_id or resolution["authority_state"] != "SUCCEEDED" or (resolution["media_unit"] is not None and resolution["media_unit"] != media_unit):
                    raise QueueConflict("forward post-effect predecessor is not the exact canonical SUCCEEDED tail")
                prior_chain = resolution["chain"]
                receipt = {
                    "schema_version": "1.0.0", "receipt_id": supersession_id, "supersession_key": supersession_key, "phase": 6,
                    "status": "SUPERSEDED_FORWARD_POST_EFFECT_CURRENT", "queue_id": "heroverse-phase6-transactional-queue-v1",
                    "supersession_class": "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION", "media_unit": media_unit,
                    "root_job": {"job_id": root_row["job_id"], "idempotency_key": root_row["idempotency_key"], "payload_sha256": _sha256_text(root_row["payload_json"]), "checkpoint_sha256": _sha256_text(root_row["checkpoint_json"]), "queue_state": self._queue_state(root_row)},
                    "superseded_job": {"job_id": predecessor_row["job_id"], "idempotency_key": predecessor_row["idempotency_key"], "payload_sha256": _sha256_text(predecessor_row["payload_json"]), "checkpoint_sha256": _sha256_text(predecessor_row["checkpoint_json"]), "queue_state": self._queue_state(predecessor_row)},
                    "authoritative_job": {"job_id": successor_row["job_id"], "idempotency_key": successor_row["idempotency_key"], "payload_sha256": _sha256_text(successor_row["payload_json"]), "checkpoint_sha256": _sha256_text(successor_row["checkpoint_json"]), "queue_state": self._queue_state(successor_row)},
                    "superseded_input_receipt": historical_input_receipt, "authoritative_input_receipt": current_input_receipt,
                    "forward_post_effect_eligibility": eligibility,
                    "lineage": {"authority_root_job_id": authority_root_job_id, "predecessor_job_id": predecessor_job_id, "successor_job_id": successor_job_id, "prior_chain": prior_chain, "prior_chain_sha256": _sha256_text(_canonical(prior_chain))},
                    "control": {"same_semantic_media_unit": True, "historical_predecessor_terminal_succeeded": True, "historical_predecessor_unleased": True, "historical_checkpoint_preserved": True, "current_successor_pre_effect": True, "current_successor_unleased": True, "current_successor_checkpoint_empty": True, "successor_claims_blocked_until_commit": True, "history_preserved": True, "publication_authorized": False, "external_effects_authorized": False, "technical_cost_brl": 0},
                    "recorded_at": _stamp(moment),
                    "claim_boundary": ["This receipt preserves the historical terminal job and does not rewrite its input or checkpoint.", "It authorizes only the already-existing current pre-effect job for the same hash-bound semantic media unit.", "It performs no voice, render, upload, publication, API call or spend; every downstream gate remains independent."],
                }
                self._validate_document("phase6_forward_post_effect_media_job_supersession_receipt.schema.json", receipt)
                receipt_json = _canonical(receipt)
                connection.execute("INSERT INTO media_job_supersessions (supersession_id,supersession_key,media_unit_key,superseded_job_id,authoritative_job_id,state,recorded_at,committed_at,receipt_json,receipt_sha256) VALUES (?,?,?,?,?,'PREPARED',?,NULL,?,?)", (supersession_id, supersession_key, media_unit_key, predecessor_job_id, successor_job_id, receipt["recorded_at"], receipt_json, _sha256_bytes((receipt_json + "\n").encode("utf-8"))))
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self._commit_media_job_supersession(supersession_key=supersession_key, now=moment, post_effect_eligibility_verifier=eligibility_verifier)

    def get_media_job_supersession(
        self, superseded_job_id: str
    ) -> dict[str, Any] | None:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM media_job_supersessions WHERE superseded_job_id=?",
                (superseded_job_id,),
            ).fetchone()
        if row is None:
            return None
        return self._verified_media_job_supersession_row(row)

    def _verified_media_job_supersession_row(
        self,
        row: sqlite3.Row | dict[str, Any],
        *,
        require_materialized: bool = True,
    ) -> dict[str, Any]:
        """Validate one journal row through the immutable receipt primitive."""

        value = dict(row)
        receipt = json.loads(str(value["receipt_json"]))
        schema_name = self._media_job_supersession_schema_name(receipt)
        self._validate_document(schema_name, receipt)
        unit = dict(receipt["media_unit"])
        unit_key = str(unit.pop("media_unit_key", ""))
        expected_unit_key = "phase6-media-unit-" + hashlib.sha256(
            _canonical(unit).encode("utf-8")
        ).hexdigest()[:24]
        if (
            receipt.get("receipt_id") != value["supersession_id"]
            or receipt.get("supersession_key") != value["supersession_key"]
            or unit_key != value["media_unit_key"]
            or unit_key != expected_unit_key
            or (receipt.get("superseded_job") or {}).get("job_id")
            != value["superseded_job_id"]
            or (receipt.get("authoritative_job") or {}).get("job_id")
            != value["authoritative_job_id"]
            or receipt.get("recorded_at") != value["recorded_at"]
        ):
            raise PermissionError(
                "media-job supersession journal/receipt identity diverged"
            )
        payload = (_canonical(receipt) + "\n").encode("utf-8")
        path = (
            self.root
            / MEDIA_JOB_SUPERSESSION_RECEIPTS
            / f"{receipt['receipt_id']}.json"
        )
        if value["receipt_sha256"] != _sha256_bytes(payload):
            raise PermissionError("media-job supersession receipt hash/bytes diverged")
        is_post_effect = self._is_local_post_effect(receipt)
        is_forward_post_effect = (
            receipt.get("supersession_class")
            == "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION"
        )
        if is_post_effect:
            lineage = receipt["lineage"]
            eligibility = receipt[
                "forward_post_effect_eligibility"
                if is_forward_post_effect else "post_effect_eligibility"
            ]
            eligibility_proof = dict(eligibility)
            eligibility_proof_sha256 = str(
                eligibility_proof.pop("proof_sha256", "")
            )
            prior_chain = lineage["prior_chain"]
            internally_bound = (
                receipt["root_job"]["job_id"]
                == lineage["authority_root_job_id"]
                and receipt["superseded_job"]["job_id"]
                == lineage["predecessor_job_id"]
                and (
                    receipt["superseded_input_receipt"]
                    != receipt["authoritative_input_receipt"]
                    if is_forward_post_effect else receipt["superseded_input_receipt"]
                    == receipt["authoritative_input_receipt"]
                )
                and eligibility["authority_root_job_id"]
                == lineage["authority_root_job_id"]
                and eligibility["predecessor_job_id"]
                == lineage["predecessor_job_id"]
                and eligibility["media_unit_key"] == unit_key
                and (
                    eligibility["historical_input_receipt_id"]
                    == receipt["superseded_input_receipt"]["receipt_id"]
                    and eligibility["current_input_receipt_id"]
                    == receipt["authoritative_input_receipt"]["receipt_id"]
                    and eligibility["successor_job_id"]
                    == receipt["authoritative_job"]["job_id"]
                    if is_forward_post_effect else eligibility["input_receipt_id"]
                    == receipt["superseded_input_receipt"]["receipt_id"]
                )
                and eligibility["predecessor_payload_sha256"]
                == receipt["superseded_job"]["payload_sha256"]
                and eligibility["predecessor_checkpoint_sha256"]
                == receipt["superseded_job"]["checkpoint_sha256"]
                and (
                    eligibility["successor_payload_sha256"]
                    == receipt["authoritative_job"]["payload_sha256"]
                    and eligibility["successor_checkpoint_sha256"]
                    == receipt["authoritative_job"]["checkpoint_sha256"]
                    and lineage["successor_job_id"]
                    == receipt["authoritative_job"]["job_id"]
                    if is_forward_post_effect else True
                )
                and eligibility_proof_sha256
                == _sha256_bytes(_canonical(eligibility_proof).encode("utf-8"))
                and lineage["prior_chain_sha256"]
                == _sha256_text(_canonical(prior_chain))
                and (
                    True if is_forward_post_effect else lineage["render_namespace"].endswith(
                        "/" + receipt["authoritative_job"]["job_id"]
                    )
                )
            )
            if not internally_bound:
                raise PermissionError(
                    "post-effect supersession receipt lineage is internally divergent"
                )
            self._load_post_effect_visual_eligibility_reference(eligibility["eligibility_receipt"])
        state = str(value["state"])
        committed_at = value.get("committed_at")
        if state == "PREPARED":
            if committed_at is not None:
                raise PermissionError(
                    "PREPARED media-job supersession has a committed timestamp"
                )
        elif state == "COMMITTED":
            if committed_at is None or _parse(str(committed_at)) < _parse(
                str(value["recorded_at"])
            ):
                raise PermissionError(
                    "COMMITTED media-job supersession has an invalid timestamp"
                )
        else:
            raise PermissionError("media-job supersession journal state is unsupported")
        if require_materialized and (
            not path.is_file() or path.read_bytes() != payload
        ):
            raise PermissionError("media-job supersession receipt hash/bytes diverged")
        return {
            "state": state,
            "schema_name": schema_name,
            "receipt": receipt,
            "receipt_path": path.relative_to(self.root).as_posix(),
            "receipt_sha256": value["receipt_sha256"],
        }

    def _resolve_media_job_authority_in_connection(
        self,
        connection: sqlite3.Connection,
        base_job_id: str,
        *,
        expected_media_unit_key: str | None = None,
        expected_operation_id: str | None = None,
        expected_channel_id: str | None = None,
        expected_task_type: str | None = None,
        require_canonical_root: bool = False,
        ignored_supersession_id: str | None = None,
    ) -> dict[str, Any]:
        if not isinstance(base_job_id, str) or not base_job_id.startswith("job-"):
            raise ValueError("an exact base media job id is required")
        base_row = connection.execute(
            "SELECT * FROM jobs WHERE job_id=?", (base_job_id,)
        ).fetchone()
        if base_row is None:
            raise QueueConflict("base media authority job does not exist")
        base = self._job(base_row)
        operation_id = expected_operation_id or str(base["operation_id"])
        channel_id = expected_channel_id or str(base["channel_id"])
        task_type = expected_task_type or str(base["task_type"])
        if (
            base["operation_id"] != operation_id
            or base["channel_id"] != channel_id
            or base["task_type"] != task_type
        ):
            raise QueueConflict(
                "base media job diverges from the requested authority contract"
            )
        if require_canonical_root:
            inbound = connection.execute(
                "SELECT supersession_id FROM media_job_supersessions "
                "WHERE authoritative_job_id=? AND state IN ('PREPARED','COMMITTED') "
                "ORDER BY supersession_id",
                (base_job_id,),
            ).fetchall()
            if inbound:
                raise QueueConflict(
                    "base media job is not the canonical authority root"
                )

        current_row = base_row
        current = base
        visited = {base_job_id}
        chain: list[dict[str, Any]] = []
        media_unit: dict[str, Any] | None = None
        expected_inbound_id: str | None = None

        while True:
            prepared_inbound = connection.execute(
                "SELECT supersession_id FROM media_job_supersessions "
                "WHERE authoritative_job_id=? AND state='PREPARED' "
                "ORDER BY supersession_id",
                (current["job_id"],),
            ).fetchall()
            prepared_inbound = [
                row
                for row in prepared_inbound
                if row["supersession_id"] != ignored_supersession_id
            ]
            if prepared_inbound:
                raise QueueConflict(
                    "media authority is the target of an uncommitted PREPARED supersession"
                )
            if expected_inbound_id is not None:
                inbound = connection.execute(
                    "SELECT supersession_id FROM media_job_supersessions "
                    "WHERE authoritative_job_id=? AND state IN ('PREPARED','COMMITTED') "
                    "ORDER BY supersession_id",
                    (current["job_id"],),
                ).fetchall()
                inbound_ids = [
                    str(row["supersession_id"])
                    for row in inbound
                    if row["supersession_id"] != ignored_supersession_id
                ]
                if inbound_ids != [expected_inbound_id]:
                    raise QueueConflict(
                        "media authority graph contains an inbound fork/divergence"
                    )

            outgoing = connection.execute(
                "SELECT * FROM media_job_supersessions "
                "WHERE superseded_job_id=? ORDER BY recorded_at,supersession_id",
                (current["job_id"],),
            ).fetchall()
            outgoing = [
                row
                for row in outgoing
                if row["supersession_id"] != ignored_supersession_id
            ]
            if len(outgoing) > 1:
                raise QueueConflict("media authority graph contains a fork")
            if not outgoing:
                break

            edge = outgoing[0]
            if edge["state"] == "PREPARED":
                raise QueueConflict(
                    "media authority chain contains an uncommitted PREPARED supersession"
                )
            if edge["state"] != "COMMITTED":
                raise QueueConflict("media authority chain contains an unknown state")
            target_id = str(edge["authoritative_job_id"])
            if target_id in visited:
                raise QueueConflict("media authority graph contains a cycle")

            verified = self._verified_media_job_supersession_row(edge)
            receipt = verified["receipt"]
            if self._is_local_post_effect(receipt):
                root_binding = receipt["root_job"]
                if (
                    receipt["lineage"]["authority_root_job_id"] != base_job_id
                    or receipt["lineage"]["prior_chain"] != chain
                    or root_binding["job_id"] != base_job_id
                    or root_binding["idempotency_key"] != base["idempotency_key"]
                    or root_binding["payload_sha256"]
                    != _sha256_text(_canonical(base["payload"]))
                    or root_binding["checkpoint_sha256"]
                    != _sha256_text(_canonical(base["checkpoint"]))
                    or root_binding["queue_state"] != self._queue_state(base_row)
                ):
                    raise PermissionError(
                        "post-effect authority must resolve from its hash-bound canonical root"
                    )
            receipt_unit = receipt["media_unit"]
            if media_unit is None:
                media_unit = receipt_unit
            elif receipt_unit != media_unit:
                raise QueueConflict(
                    "media authority chain diverges across semantic media units"
                )
            if (
                expected_media_unit_key is not None
                and receipt_unit["media_unit_key"] != expected_media_unit_key
            ):
                raise QueueConflict(
                    "media authority chain differs from the requested media unit"
                )
            if (
                receipt_unit.get("operation_id") != operation_id
                or receipt_unit.get("channel_id") != channel_id
                or receipt_unit.get("task_type") != task_type
            ):
                raise QueueConflict(
                    "media authority receipt diverges from operation/channel/task"
                )

            target_row = connection.execute(
                "SELECT * FROM jobs WHERE job_id=?", (target_id,)
            ).fetchone()
            if target_row is None:
                raise QueueConflict("media authority target job disappeared")
            target = self._job(target_row)
            if any(
                job["operation_id"] != operation_id
                or job["channel_id"] != channel_id
                or job["task_type"] != task_type
                for job in (current, target)
            ):
                raise QueueConflict(
                    "media authority jobs diverge from operation/channel/task"
                )

            superseded_binding = receipt["superseded_job"]
            authority_binding = receipt["authoritative_job"]
            if (
                superseded_binding["idempotency_key"]
                != current["idempotency_key"]
                or superseded_binding["payload_sha256"]
                != _sha256_text(_canonical(current["payload"]))
                or superseded_binding["checkpoint_sha256"]
                != _sha256_text(_canonical(current["checkpoint"]))
                or superseded_binding["queue_state"]
                != self._queue_state(current_row)
                or authority_binding["idempotency_key"]
                != target["idempotency_key"]
                or authority_binding["payload_sha256"]
                != _sha256_text(_canonical(target["payload"]))
                or current["payload"].get("input_receipt_id")
                != receipt["superseded_input_receipt"]["receipt_id"]
                or target["payload"].get("input_receipt_id")
                != receipt["authoritative_input_receipt"]["receipt_id"]
            ):
                raise PermissionError(
                    "media authority job/receipt lineage identity diverged"
                )

            chain.append(
                {
                    "supersession_id": receipt["receipt_id"],
                    "supersession_class": receipt.get(
                        "supersession_class", "IDENTITY_ONLY"
                    ),
                    "superseded_job_id": current["job_id"],
                    "authoritative_job_id": target["job_id"],
                    "media_unit_key": receipt_unit["media_unit_key"],
                    "receipt_path": verified["receipt_path"],
                    "receipt_sha256": verified["receipt_sha256"],
                }
            )
            visited.add(target_id)
            expected_inbound_id = str(edge["supersession_id"])
            current_row = target_row
            current = target

        if expected_media_unit_key is not None and media_unit is None:
            raise QueueConflict(
                "an expected media unit cannot be proven without a committed receipt"
            )
        state = str(current["state"])
        executable = state in {"PENDING", "RETRY_WAIT", "LEASED"}
        terminal = state in {"SUCCEEDED", "DEAD_LETTER"}
        authority_kind = {
            "PENDING": "EXECUTABLE",
            "RETRY_WAIT": "EXECUTABLE",
            "LEASED": "ACTIVE_LEASE",
            "SUCCEEDED": "TERMINAL_SUCCEEDED",
            "DEAD_LETTER": "TERMINAL_FAILED",
        }.get(state)
        if authority_kind is None:
            raise QueueConflict("media authority tail has an unsupported job state")
        return {
            "status": "RESOLVED",
            "base_job_id": base_job_id,
            "root_job": base,
            "authoritative_job_id": current["job_id"],
            "authority_state": state,
            "authority_kind": authority_kind,
            "authority_job": current,
            "media_unit": media_unit,
            "media_unit_key": (
                media_unit["media_unit_key"] if media_unit is not None else None
            ),
            "chain": chain,
            "chain_length": len(chain),
            "executable": executable,
            "executable_job_id": current["job_id"] if executable else None,
            "terminal": terminal,
            "terminal_authority_job_id": current["job_id"] if terminal else None,
            "predecessor_fallback_permitted": False,
            "canonical_root_required": require_canonical_root,
            "read_only": True,
        }

    def resolve_media_job_authority(
        self,
        base_job_id: str,
        *,
        expected_media_unit_key: str | None = None,
        expected_operation_id: str | None = None,
        expected_channel_id: str | None = None,
        expected_task_type: str | None = None,
        require_canonical_root: bool = False,
    ) -> dict[str, Any]:
        """Resolve a mixed immutable COMMITTED chain without mutation.

        ``require_canonical_root`` is opt-in for historical callers and mandatory
        at the post-effect creation boundary.  PREPARED blocks both sides and a
        failed tail never revives a predecessor.
        """

        with self._connection() as connection:
            connection.execute("PRAGMA query_only=ON")
            connection.execute("BEGIN")
            try:
                return self._resolve_media_job_authority_in_connection(
                    connection,
                    base_job_id,
                    expected_media_unit_key=expected_media_unit_key,
                    expected_operation_id=expected_operation_id,
                    expected_channel_id=expected_channel_id,
                    expected_task_type=expected_task_type,
                    require_canonical_root=require_canonical_root,
                )
            finally:
                connection.rollback()

    def snapshot(self, *, captured_at: datetime | None = None) -> dict[str, Any]:
        moment = captured_at or _now()
        with self._connection() as connection:
            jobs = [self._job(row) for row in connection.execute("SELECT * FROM jobs ORDER BY created_at,job_id").fetchall()]
            incidents = [dict(row) for row in connection.execute("SELECT * FROM incidents ORDER BY incident_id").fetchall()]
            supersessions = [
                {
                    "supersession_id": str(row["supersession_id"]),
                    "media_unit_key": str(row["media_unit_key"]),
                    "superseded_job_id": str(row["superseded_job_id"]),
                    "authoritative_job_id": str(row["authoritative_job_id"]),
                    "state": str(row["state"]),
                    "receipt_path": (
                        MEDIA_JOB_SUPERSESSION_RECEIPTS
                        / f"{row['supersession_id']}.json"
                    ).as_posix(),
                    "receipt_sha256": str(row["receipt_sha256"]),
                    "recorded_at": str(row["recorded_at"]),
                    "committed_at": row["committed_at"],
                }
                for row in connection.execute(
                    "SELECT * FROM media_job_supersessions "
                    "ORDER BY recorded_at,supersession_id"
                ).fetchall()
            ]
        counts = {state: sum(1 for job in jobs if job["state"] == state) for state in STATES}
        superseded_ids = {
            item["superseded_job_id"]
            for item in supersessions
            if item["state"] in {"PREPARED", "COMMITTED"}
        }
        prepared_authority_ids = {
            item["authoritative_job_id"]
            for item in supersessions
            if item["state"] == "PREPARED"
        }
        claim_blocked_ids = superseded_ids | prepared_authority_ids
        executable_counts = {
            state: sum(
                1
                for job in jobs
                if job["state"] == state and job["job_id"] not in claim_blocked_ids
            )
            for state in STATES
        }
        return {
            "schema_version": "1.0.0", "queue_id": "heroverse-phase6-transactional-queue-v1",
            "phase": 6,
            "status": "ATTENTION_REQUIRED"
            if counts["DEAD_LETTER"]
            or any(item["state"] == "PREPARED" for item in supersessions)
            else "HEALTHY",
            "database_path": QUEUE_PATH.as_posix(), "counts": counts,
            "executable_counts": executable_counts, "jobs": jobs,
            "media_job_supersessions": supersessions,
            "incidents": incidents, "technical_cost_brl": 0, "captured_at": _stamp(moment),
        }

    def materialize_snapshot(self, *, captured_at: datetime | None = None) -> Path:
        value = self.snapshot(captured_at=captured_at)
        schema = json.loads((self.root / "schemas/phase6_queue_snapshot.schema.json").read_text(encoding="utf-8-sig"))
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
        target = self.root / SNAPSHOT_PATH
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(target)
        return target
