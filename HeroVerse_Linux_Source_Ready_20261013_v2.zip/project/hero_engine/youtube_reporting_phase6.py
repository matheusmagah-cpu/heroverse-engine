from __future__ import annotations

import argparse
import csv
import json
import io
import hashlib
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker

from .google_api_runtime import (
    GOOGLE_OPERATION_DEADLINE_SECONDS,
    GoogleOperationDeadline,
    GoogleOperationDeadlineExceeded,
    build_authorized_service,
    execute_google_request,
)
from .phase6_pilot import resolve_runtime_token
from .youtube_integration import INTEGRATION_SCOPES


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
ANALYTICS_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
REPORT_TYPES = ("channel_basic_a3", "channel_reach_basic_a1")
JOB_NAMES = {
    "channel_basic_a3": "HeroVerse daily owned activity v1",
    "channel_reach_basic_a1": "HeroVerse daily owned reach v1",
}
REGISTRY_PATH = Path("output/operations/phase6/reporting/job-registry.json")
REACH_FOLDER = Path("output/operations/phase6/reporting/reach/iK_5edYQtx8")
PUBLICATION_RECEIPT = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
VIDEO_ID = "iK_5edYQtx8"
MAX_PAGINATED_ITEMS = 10_000
MAX_REPORT_DOWNLOAD_BYTES = 64 * 1024 * 1024
MAX_REPORT_ROWS = 1_000_000


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _write_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise PermissionError(f"raw Reporting asset cannot be a symbolic link: {path.name}")
    if path.is_file():
        if path.read_bytes() != value:
            raise PermissionError(f"immutable Reporting raw asset collision: {path.name}")
        return
    try:
        with path.open("xb") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        if path.read_bytes() != value:
            raise PermissionError(f"immutable Reporting raw asset collision: {path.name}")


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _target_video_id(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", value):
        raise ValueError("invalid YouTube video id")
    return value


def _receipt_path(root: Path, value: Path) -> Path:
    candidate = (root / value).resolve() if not value.is_absolute() else value.resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise PermissionError("publication receipt must remain inside the workspace") from exc
    return candidate


def _pages(
    request_factory: Any,
    key: str,
    *,
    deadline: GoogleOperationDeadline | None = None,
    stage: str = "youtubeReporting.list",
) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    page_token: str | None = None
    seen_tokens: set[str] = set()
    operation_deadline = deadline or GoogleOperationDeadline()
    for _page_number in range(100):
        response = execute_google_request(
            request_factory(page_token),
            deadline=operation_deadline,
            stage=f"{stage}:page-{_page_number + 1}",
        )
        values.extend(item for item in response.get(key) or [] if isinstance(item, dict))
        if len(values) > MAX_PAGINATED_ITEMS:
            raise RuntimeError("Reporting API pagination exceeded the item safety bound")
        next_token = response.get("nextPageToken")
        if not next_token:
            return values
        if not isinstance(next_token, str) or next_token in seen_tokens:
            raise RuntimeError("Reporting API pagination token repeated or invalid")
        seen_tokens.add(next_token)
        page_token = next_token
    raise RuntimeError("Reporting API pagination exceeded the 100-page safety bound")


def build_job_registry(
    service: Any,
    root: Path = ROOT,
    *,
    observed_at: str | None = None,
    deadline: GoogleOperationDeadline | None = None,
) -> dict[str, Any]:
    """Ensure the two zero-cost daily reporting jobs exist and inventory reports.

    Job creation is idempotent by report type. No report is represented as available
    until jobs.reports.list returns actual report resources.
    """

    root = root.resolve()
    timestamp = observed_at or _now()
    operation_deadline = deadline or GoogleOperationDeadline()
    available: set[str] = set()
    jobs: list[dict[str, Any]] = []
    fatal: str | None = None
    try:
        report_types = _pages(
            lambda token: service.reportTypes().list(
                includeSystemManaged=False, pageToken=token
            ),
            "reportTypes",
            deadline=operation_deadline,
            stage="youtubeReporting.reportTypes.list",
        )
        available = {str(item.get("id")) for item in report_types if item.get("id")}
        existing = _pages(
            lambda token: service.jobs().list(
                includeSystemManaged=False, pageToken=token
            ),
            "jobs",
            deadline=operation_deadline,
            stage="youtubeReporting.jobs.list",
        )
    except GoogleOperationDeadlineExceeded:
        raise
    except Exception as exc:
        fatal = f"{type(exc).__name__}: {exc}"
        existing = []

    for report_type in REPORT_TYPES:
        entry = {
            "report_type_id": report_type,
            "name": JOB_NAMES[report_type],
            "job_id": None,
            "create_time": None,
            "state": "FAILED" if fatal else "UNAVAILABLE",
            "report_count": 0,
            "latest_report_create_time": None,
            "error": fatal,
        }
        if fatal is None and report_type not in available:
            entry["error"] = "REPORT_TYPE_NOT_AVAILABLE_FOR_AUTHORIZED_CHANNEL"
        elif fatal is None:
            matching = [item for item in existing if item.get("reportTypeId") == report_type]
            selected = sorted(matching, key=lambda item: (item.get("createTime") or "", item.get("id") or ""))[-1] if matching else None
            try:
                if selected is None:
                    selected = execute_google_request(
                        service.jobs().create(body={"reportTypeId": report_type, "name": JOB_NAMES[report_type]}),
                        deadline=operation_deadline,
                        stage=f"youtubeReporting.jobs.create:{report_type}",
                    )
                    state = "CREATED"
                else:
                    state = "REUSED"
                job_id = selected.get("id")
                if not job_id:
                    raise ValueError("Reporting job response has no id")
                reports = _pages(
                    lambda token: service.jobs().reports().list(
                        jobId=job_id, pageSize=100, pageToken=token
                    ),
                    "reports",
                    deadline=operation_deadline,
                    stage=f"youtubeReporting.jobs.reports.list:{job_id}",
                )
                create_times = sorted(str(item.get("createTime")) for item in reports if item.get("createTime"))
                entry.update({
                    "job_id": str(job_id),
                    "create_time": selected.get("createTime"),
                    "state": state,
                    "report_count": len(reports),
                    "latest_report_create_time": create_times[-1] if create_times else None,
                    "error": None,
                })
            except GoogleOperationDeadlineExceeded:
                raise
            except Exception as exc:
                entry["state"] = "FAILED"
                entry["error"] = f"{type(exc).__name__}: {exc}"
        jobs.append(entry)

    active = [item for item in jobs if item["state"] in {"REUSED", "CREATED"}]
    report_count = sum(item["report_count"] for item in active)
    if fatal:
        status = "ERROR"
    elif len(active) == len(REPORT_TYPES):
        status = "ACTIVE_REPORTS_AVAILABLE" if report_count else "ACTIVE_AWAITING_FIRST_REPORT"
    elif active:
        status = "PARTIAL"
    else:
        status = "BLOCKED"
    value = {
        "schema_version": "1.0.0",
        "registry_id": "heroverse-youtube-reporting-jobs-v1",
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "status": status,
        "requested_report_types": list(REPORT_TYPES),
        "available_report_types": sorted(available),
        "jobs": jobs,
        "oauth_scope": ANALYTICS_SCOPE,
        "billing_required": False,
        "technical_cost_brl": 0,
        "observed_at": timestamp,
        "claim_boundary": [
            "A created job does not mean a report or metric is already available.",
            "Daily bulk reports can arrive after the 24-hour content checkpoint and are merged only by exact channel/video/date.",
            "Reach metrics remain null until an actual owned report row is downloaded and validated.",
        ],
    }
    schema = _read(root / "schemas/youtube_reporting_job_registry.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    return value


def materialize_job_registry(
    service: Any,
    root: Path = ROOT,
    *,
    observed_at: str | None = None,
    deadline: GoogleOperationDeadline | None = None,
) -> Path:
    root = root.resolve()
    value = build_job_registry(service, root, observed_at=observed_at, deadline=deadline)
    path = root / REGISTRY_PATH
    _write(path, value)
    return path


def _latest_report_versions(reports: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep only the newest report resource for each provider reporting period."""

    selected: dict[tuple[str, str], dict[str, Any]] = {}
    for report in reports:
        required = ("id", "jobId", "startTime", "endTime", "createTime", "downloadUrl")
        if not all(isinstance(report.get(name), str) and report[name] for name in required):
            continue
        key = (report["startTime"], report["endTime"])
        prior = selected.get(key)
        if prior is None or (report["createTime"], report["id"]) > (prior["createTime"], prior["id"]):
            selected[key] = report
    return sorted(selected.values(), key=lambda item: (item["createTime"], item["id"]))


def build_reach_snapshot(
    service: Any,
    download: Callable[[str], bytes],
    root: Path = ROOT,
    *,
    registry: dict[str, Any] | None = None,
    video_id: str = VIDEO_ID,
    publication_receipt: Path = PUBLICATION_RECEIPT,
    captured_at: str | None = None,
    deadline: GoogleOperationDeadline | None = None,
) -> dict[str, Any]:
    """Download and isolate owned reach rows for one exact public video.

    The bulk CSV is channel-wide. Rows from another channel, another video or a
    date outside the observation window are explicitly counted and excluded.
    Overlapping provider report versions are resolved by newest createTime.
    """

    root = root.resolve()
    target_video_id = _target_video_id(video_id)
    operation_deadline = deadline or GoogleOperationDeadline()
    reach_folder = Path("output/operations/phase6/reporting/reach") / target_video_id
    timestamp = captured_at or _now()
    captured = _parse(timestamp)
    registry_path = root / REGISTRY_PATH
    registry_value = registry or (_read(registry_path) if registry_path.is_file() else None)
    if registry_value is None:
        raise FileNotFoundError("Reporting API job registry is required before reach collection")
    receipt_path = _receipt_path(root, publication_receipt)
    receipt = _read(receipt_path)
    if (
        receipt.get("status") != "COMPLETE_PUBLIC"
        or receipt.get("video_id") != target_video_id
        or receipt.get("channel_id") != CHANNEL_ID
    ):
        raise PermissionError("The exact completed public-video receipt is required")
    published = _parse(str(receipt.get("updated_at") or receipt["created_at"]))
    start_date, end_date = published.date().isoformat(), captured.date().isoformat()
    reach_jobs = [
        item for item in registry_value.get("jobs") or []
        if item.get("report_type_id") == "channel_reach_basic_a1" and item.get("job_id")
    ]
    errors: list[str] = []
    reports: list[dict[str, Any]] = []
    if len(reach_jobs) != 1:
        errors.append("EXACT_REACH_JOB_UNAVAILABLE")
    else:
        try:
            reports = _pages(
                lambda token: service.jobs().reports().list(
                    jobId=reach_jobs[0]["job_id"], pageSize=100, pageToken=token
                ),
                "reports",
                deadline=operation_deadline,
                stage=f"youtubeReporting.jobs.reports.list:{reach_jobs[0]['job_id']}",
            )
        except GoogleOperationDeadlineExceeded:
            raise
        except Exception as exc:
            errors.append(f"REPORT_LIST:{type(exc).__name__}:{exc}")
    selected = _latest_report_versions(reports)
    selected_meta = [
        {
            "report_id": item["id"], "job_id": item["jobId"],
            "start_time": item["startTime"], "end_time": item["endTime"],
            "create_time": item["createTime"],
        }
        for item in selected
    ]
    accounting = {
        "rows_total": 0, "rows_matching": 0, "rows_other_channel": 0,
        "rows_other_video": 0, "rows_outside_window": 0,
        "duplicate_dates_replaced": 0,
    }
    raw_assets: list[dict[str, Any]] = []
    rows_by_date: dict[str, tuple[str, int, float]] = {}
    required_columns = {
        "date", "channel_id", "video_id", "video_thumbnail_impressions",
        "video_thumbnail_impressions_ctr",
    }
    for report in selected:
        report_id = report["id"]
        try:
            operation_deadline.pulse(f"youtubeReporting.report.download:{report_id}:before")
            payload = download(report["downloadUrl"])
            operation_deadline.pulse(f"youtubeReporting.report.download:{report_id}:after")
            if not payload:
                raise ValueError("empty report payload")
            if len(payload) > MAX_REPORT_DOWNLOAD_BYTES:
                raise ValueError("report payload exceeds the 64 MiB safety bound")
            report_identity = "\0".join(
                [report_id, str(report["jobId"]), str(report["createTime"])]
            )
            identity_hash = hashlib.sha256(report_identity.encode("utf-8")).hexdigest()
            raw_path = root / reach_folder / "raw" / f"report-{identity_hash}.csv"
            _write_bytes(raw_path, payload)
            if _hash(raw_path) != hashlib.sha256(payload).hexdigest():
                raise PermissionError("raw Reporting asset hash verification failed")
            reader = csv.DictReader(io.StringIO(payload.decode("utf-8-sig")))
            if not required_columns.issubset(set(reader.fieldnames or [])):
                missing = sorted(required_columns - set(reader.fieldnames or []))
                raise ValueError(f"missing required CSV columns: {missing}")
            report_rows_total = 0
            report_rows_matching = 0
            for row in reader:
                report_rows_total += 1
                accounting["rows_total"] += 1
                if report_rows_total > MAX_REPORT_ROWS:
                    raise ValueError("report CSV exceeds the row safety bound")
                if report_rows_total % 1000 == 0:
                    operation_deadline.pulse(
                        f"youtubeReporting.report.parse:{report_id}:row-{report_rows_total}"
                    )
                if row.get("channel_id") != CHANNEL_ID:
                    accounting["rows_other_channel"] += 1
                    continue
                if row.get("video_id") != target_video_id:
                    accounting["rows_other_video"] += 1
                    continue
                row_date = str(row.get("date") or "")
                if not (start_date <= row_date <= end_date):
                    accounting["rows_outside_window"] += 1
                    continue
                impressions = int(str(row["video_thumbnail_impressions"]))
                ctr = float(str(row["video_thumbnail_impressions_ctr"]))
                if impressions < 0 or ctr < 0:
                    raise ValueError("negative reach metric")
                report_rows_matching += 1
                accounting["rows_matching"] += 1
                if row_date in rows_by_date:
                    accounting["duplicate_dates_replaced"] += 1
                rows_by_date[row_date] = (report["createTime"], impressions, ctr)
            raw_assets.append({
                "report_id": report_id,
                "path": raw_path.relative_to(root).as_posix(),
                "sha256": _hash(raw_path), "bytes": len(payload),
                "rows_total": report_rows_total, "rows_matching": report_rows_matching,
            })
        except GoogleOperationDeadlineExceeded:
            raise
        except Exception as exc:
            errors.append(f"REPORT_DOWNLOAD_OR_PARSE:{report_id}:{type(exc).__name__}:{exc}")

    covered_dates = sorted(rows_by_date)
    if covered_dates:
        impressions = sum(rows_by_date[date][1] for date in covered_dates)
        ctr = (
            sum(rows_by_date[date][1] * rows_by_date[date][2] for date in covered_dates) / impressions
            if impressions else None
        )
        status = "PARTIAL" if errors else "OBSERVED"
        source_status = "PARTIAL" if errors else "PASS"
        missing_reason = "PARTIAL_REPORT_FAILURE" if errors else None
    else:
        impressions = None
        ctr = None
        if errors:
            status, source_status = "FAILED", "FAILED"
            missing_reason = "REPORT_COLLECTION_FAILED"
        else:
            status, source_status = "AWAITING_REPORT", "EMPTY"
            missing_reason = "NO_MATCHING_OWNED_REACH_ROW_AVAILABLE_YET"
    value = {
        "schema_version": "1.0.0",
        "snapshot_id": f"owned-reach-{target_video_id}-{captured.strftime('%Y%m%dT%H%M%SZ')}",
        "phase": 6, "channel_id": CHANNEL_ID, "video_id": target_video_id,
        "report_type_id": "channel_reach_basic_a1", "status": status,
        "captured_at": timestamp,
        "observation_window": {"start_date": start_date, "end_date": end_date},
        "source": {
            "status": source_status,
            "method": "YouTube Reporting API jobs.reports.list plus authenticated downloadUrl CSV",
            "error": " | ".join(errors) if errors else None,
        },
        "selected_reports": selected_meta, "raw_assets": raw_assets,
        "row_accounting": accounting,
        "metrics": {
            "videoThumbnailImpressions": impressions,
            "videoThumbnailImpressionsClickRate": round(ctr, 12) if ctr is not None else None,
            "ctr_unit": "provider_reported_percentage_value",
            "covered_dates": covered_dates,
        },
        "daily_metrics": [
            {
                "date": date,
                "videoThumbnailImpressions": rows_by_date[date][1],
                "videoThumbnailImpressionsClickRate": rows_by_date[date][2],
                "ctr_unit": "provider_reported_percentage_value",
            }
            for date in covered_dates
        ],
        "missing_reason": missing_reason,
        "registry": {
            "path": REGISTRY_PATH.as_posix(), "sha256": _hash(registry_path),
            "status": registry_value["status"],
        },
        "technical_cost_brl": 0,
        "claim_boundary": [
            "Only rows matching the exact authorized channel and exact public video are aggregated.",
            "Null means the provider has not delivered a matching row; it is never converted to zero.",
            "CTR is preserved in the provider-reported percentage value and weighted by impressions across dates.",
            "A Reporting API row is owned performance evidence, not proof of causality or future monetization.",
        ],
    }
    schema = _read(root / "schemas/youtube_reach_snapshot.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    return value


def materialize_reach_snapshot(
    service: Any,
    download: Callable[[str], bytes],
    root: Path = ROOT,
    *,
    registry: dict[str, Any] | None = None,
    video_id: str = VIDEO_ID,
    publication_receipt: Path = PUBLICATION_RECEIPT,
    captured_at: str | None = None,
    deadline: GoogleOperationDeadline | None = None,
) -> Path:
    root = root.resolve()
    value = build_reach_snapshot(
        service,
        download,
        root,
        registry=registry,
        video_id=video_id,
        publication_receipt=publication_receipt,
        captured_at=captured_at,
        deadline=deadline,
    )
    folder = root / "output/operations/phase6/reporting/reach" / value["video_id"]
    path = folder / f"{value['snapshot_id']}.json"
    _write(path, value)
    _write(folder / "latest.json", value)
    return path


def _credentials(token_path: Path) -> Any:
    from google.oauth2.credentials import Credentials  # type: ignore

    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("OAuth access token must be refreshed by the Central Manager before Reporting API use")
    return credentials


def _service(credentials: Any, *, request_timeout_seconds: float = 30.0) -> Any:
    return build_authorized_service(
        "youtubereporting", "v1", credentials=credentials,
        request_timeout_seconds=request_timeout_seconds,
    )


def materialize_live(
    root: Path = ROOT,
    *,
    token_path: Path | None = None,
    video_id: str = VIDEO_ID,
    publication_receipt: Path = PUBLICATION_RECEIPT,
    captured_at: str | None = None,
    progress: Callable[[], Any] | None = None,
    deadline_seconds: float = GOOGLE_OPERATION_DEADLINE_SECONDS,
    reuse_registry_path: Path | None = None,
    reuse_registry_sha256: str | None = None,
) -> Path:
    root = root.resolve()
    deadline = GoogleOperationDeadline(deadline_seconds, progress=progress)
    receipt_path = _receipt_path(root, publication_receipt)
    receipt = _read(receipt_path)
    if not (
        receipt.get("status") == "COMPLETE_PUBLIC"
        and receipt.get("video_id") == _target_video_id(video_id)
        and receipt.get("channel_id") == CHANNEL_ID
    ):
        raise PermissionError("The exact completed public-video receipt is required before OAuth")
    token = token_path.resolve() if token_path is not None else resolve_runtime_token(root)
    from .central_manager_phase5 import ensure_oauth_session_health

    deadline.pulse("oauth.youtubeReporting:before")
    health = ensure_oauth_session_health(root, token, deadline=deadline)
    deadline.pulse("oauth.youtubeReporting:after")
    if health["status"] not in {"HEALTHY", "REFRESHED"}:
        raise PermissionError(f"OAuth health blocks Reporting API use: {health['status']}")
    credentials = _credentials(token)
    deadline.pulse("google.discovery.youtubeReporting:before")
    service = _service(
        credentials,
        request_timeout_seconds=deadline.request_timeout(
            "google.discovery.youtubeReporting:transport"
        ),
    )
    deadline.pulse("google.discovery.youtubeReporting:after")
    if reuse_registry_path is None:
        registry_path = materialize_job_registry(
            service, root, observed_at=captured_at, deadline=deadline,
        )
    else:
        registry_path = reuse_registry_path.resolve()
        if registry_path != (root / REGISTRY_PATH).resolve() or not registry_path.is_file():
            raise PermissionError("reused Reporting registry is outside the authoritative path")
        observed_hash = _hash(registry_path)
        if reuse_registry_sha256 != observed_hash:
            raise PermissionError("reused Reporting registry hash diverged")
        reused = _read(registry_path)
        Draft202012Validator(
            _read(root / "schemas/youtube_reporting_job_registry.schema.json"),
            format_checker=FormatChecker(),
        ).validate(reused)
        if reused.get("channel_id") != CHANNEL_ID:
            raise PermissionError("reused Reporting registry channel diverged")
    registry = _read(registry_path)

    def download(url: str) -> bytes:
        from google.auth.transport.requests import AuthorizedSession  # type: ignore

        response = AuthorizedSession(credentials).get(
            url,
            headers={"Accept-Encoding": "gzip"},
            timeout=deadline.request_timeout("youtubeReporting.report.download:http"),
            stream=True,
        )
        response.raise_for_status()
        content_length = response.headers.get("Content-Length") if hasattr(response, "headers") else None
        if content_length is not None and int(content_length) > MAX_REPORT_DOWNLOAD_BYTES:
            raise ValueError("report Content-Length exceeds the 64 MiB safety bound")
        payload = bytearray()
        if hasattr(response, "iter_content"):
            for index, chunk in enumerate(response.iter_content(chunk_size=1024 * 1024), start=1):
                if not chunk:
                    continue
                payload.extend(chunk)
                if len(payload) > MAX_REPORT_DOWNLOAD_BYTES:
                    raise ValueError("report stream exceeds the 64 MiB safety bound")
                deadline.pulse(f"youtubeReporting.report.download:chunk-{index}")
        else:
            payload.extend(bytes(response.content))
            if len(payload) > MAX_REPORT_DOWNLOAD_BYTES:
                raise ValueError("report payload exceeds the 64 MiB safety bound")
        return bytes(payload)

    materialize_reach_snapshot(
        service,
        download,
        root,
        registry=registry,
        video_id=video_id,
        publication_receipt=publication_receipt,
        captured_at=captured_at,
        deadline=deadline,
    )
    return registry_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Ensure zero-cost HeroVerse YouTube Reporting API jobs")
    parser.parse_args()
    print(materialize_live(ROOT))
    print((ROOT / REACH_FOLDER / "latest.json").resolve())


if __name__ == "__main__":
    main()
