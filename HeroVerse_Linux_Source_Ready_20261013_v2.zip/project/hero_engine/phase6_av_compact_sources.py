"""Inspect the frozen compact two-column PNGs, never render or time their use.

The old static inspector remains unchanged. A9 is reopened as a historical
literal-reference document, not rebuilt or used as new PCM evidence. Caption
and amendment readers recompose that literal contract. Historical OCR/QA is
provenance only; the present measurement is a pinned PNG integrity/pixel decode.
"""
from __future__ import annotations

import copy
from pathlib import Path
import re
from xml.etree import ElementTree

from . import phase6_av_static_sources as primitives
from . import phase6_av_visual_amendment as amendment
from . import phase6_av_caption_intent as captions
from .phase6_narration_audio_inventory import Reader as MetadataReader
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-compact-sources-v1"
TEMPLATE_ID = "two-column-compact-v1"
HERE = "output/qa/phase6/diagnostics/two-column-compact-v1"
REFERENCE = {
    "path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-08c58eb7551e72f958fa3f09.json",
    "sha256": "5105f3a4c09cc632667088b7a8d50cdd49d46006b33af2f98c21fb843f37f6c0",
}
IMPLEMENTATION_PINS = {
    "hero_engine/phase6_av_static_sources.py": "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "hero_engine/phase6_av_visual_amendment.py": "0205fe37622d4ea1bbef501d28a32a9e7c328d00129e33a994119161fa129085",
    "schemas/phase6_av_visual_amendment.schema.json": "a7fc96bcd6916504c08b7669cafbc430446ae0903ca6ba5dc1fa4f9918550cc1",
    "hero_engine/phase6_av_caption_intent.py": "36f7c2fd82b36ef824221dfe031c304794fde07042e761065df233311bb51763",
    "hero_engine/phase6_av_visual_intent.py": "9ea8fa3f1d465b6bb8a0aa5491d291ae592400c64e7445b17733190b7431c791",
    "schemas/phase6_av_untimed_visual_intent.schema.json": "706c1f5a62ba75790c0d8e7ab3ce31dca520c519f72f626ecce4f9f2c0caa9cc",
    "hero_engine/phase6_narration_audio_inventory.py": "11e56ca46d3f4928882ece936500b49a428caf7cbd1ff542069eceb47db4bde6",
    "hero_engine/phase6_narration_units.py": "737326797c9499cd341198ca43927a3e6447f5616563ceafc6b3bd8278c71fba",
}
CONFIG = {
    "directory": HERE + "/static-5d42a585eacde074510f8f61",
    "receipt_sha256": "cf6aeb64489e6846acd510e5d771ee87db504f1118bbac0262770acbd784737b",
    "runner": HERE + "/recipe.py",
    "runner_sha256": "51a6c8d4bab2d4c6d953861093d84cf6ec25ecc16d4ebba53abe335521ec033c",
    "tests": HERE + "/test_recipe.py",
    "tests_sha256": "5a1275db9edfeb7b4909a3d1d7d108dbe4cdd5c3fa0bd181b6734af31f667556",
    "lineage_id": "heroverse-owned-two-column-composition",
    "state_ids": [row[0] for row in amendment.EXPECTED],
    "source_bindings": {
        "literal_reference": copy.deepcopy(REFERENCE),
        "visual_projection": {"path": amendment.PROJECTION_BINDING["path"], "sha256": amendment.PROJECTION_BINDING["sha256"][7:]},
        "visual_amendment": {"path": amendment.AMENDMENT_BINDING["path"], "sha256": amendment.AMENDMENT_BINDING["sha256"][7:]},
        "caption_intent": {"path": captions.PLAN_BINDING["path"], "sha256": captions.PLAN_BINDING["sha256"][7:]},
        "take_plan": {"path": primitives.PLAN, "sha256": primitives.INPUT_PINS[primitives.PLAN]},
        "style_bible": {"path": primitives.BIBLE, "sha256": primitives.INPUT_PINS[primitives.BIBLE]},
        "historical_qa": {"path": amendment.SOURCE_BINDINGS["static_qa_reconciliation"]["path"],
            "sha256": amendment.SOURCE_BINDINGS["static_qa_reconciliation"]["sha256"][7:]},
    },
}
AUTHORITY = {key: False for key in (
    "synthesis_authorized", "render_authorized", "queue_authorized", "publication_authorized",
    "quality_approved", "source_admitted", "timing_validated", "rights_approved", "publicity_approved")}
EXTERNAL_DEPENDENCY_PINS = primitives.EXTERNAL_DEPENDENCY_PINS


def _same(actual, expected, message):
    primitives._same(actual, expected, message)


def _requests(root, requests):
    if type(requests) is not list or not 1 <= len(requests) <= 256:
        raise ValueError("bounded nonempty compact source requests required")
    relative = CONFIG["directory"] + "/receipt.json"
    absolute = str(Path(root).absolute() / relative)
    for request in requests:
        if type(request) is not dict or set(request) != {"template_id", "state_id", "receipt_binding"}:
            raise ValueError("compact request fields differ")
        if (type(request["template_id"]) is not str or type(request["state_id"]) is not str
                or request["template_id"] != TEMPLATE_ID or request["state_id"] not in CONFIG["state_ids"]):
            raise ValueError("unknown compact template or state")
        binding = request["receipt_binding"]
        if (type(binding) is not dict or set(binding) != {"path", "sha256"}
                or type(binding["path"]) is not str or binding["path"] not in (relative, absolute)
                or type(binding["sha256"]) is not str or binding["sha256"] != CONFIG["receipt_sha256"]):
            raise ValueError("exact external compact receipt pin required")


def _read_json(reader, bound):
    raw = reader.read(bound["path"], bound["sha256"])
    value = primitives._json(raw)
    primitives._canonical(value)  # Reject overflow to infinity as well as NaN.
    return value


def _preflight(root):
    reader = primitives._Reader(root)
    for name, digest in IMPLEMENTATION_PINS.items():
        reader.read(name, digest)
    name = "hero_engine/phase6_av_compact_sources.py"
    reader.read(name, primitives._sha(primitives._resident(Path(__file__).absolute()).read_bytes()))
    reference = _read_json(reader, REFERENCE)
    _same([reference["schema_version"], reference["timeline_version"], reference["status"]],
          ["1.8.0", "phase6-av-timeline-v9", "BLOCKED_INCOMPLETE"], "historical A9 identity/scope differs")
    _same(reference["inputs"]["source_bindings"]["visual_amendment"], amendment.PROJECTION_BINDING,
          "historical A9 does not bind this amendment")
    metadata = MetadataReader(reader.root)
    caption = captions.read_caption_intent(metadata, captions.PLAN_BINDING, reference["units"])
    literal = amendment.read_amended_visual_intent(metadata, amendment.PROJECTION_BINDING, reference["units"], caption)
    _same(reference["visual_amendment_evidence"]["inspection_sha256"], canonical_sha(literal),
          "amended literal inspection differs from frozen A9 reference")
    for item in literal["dependency_bindings"]:
        raw = reader.read(item["path"], item["sha256"][7:])
        if len(raw) != item["size_bytes"]:
            raise ValueError("literal dependency size differs")
    for item in literal["implementation_dependencies"]:
        if IMPLEMENTATION_PINS.get(item["path"]) != item["sha256"][7:]:
            raise ValueError("literal implementation outside frozen compact envelope")
    receipt_path = CONFIG["directory"] + "/receipt.json"
    raw_receipt = reader.read(receipt_path, CONFIG["receipt_sha256"])
    receipt = primitives._json(raw_receipt)
    if primitives._canonical(receipt) != raw_receipt:
        raise ValueError("compact receipt canonical byte identity differs")
    reader.read(CONFIG["runner"], CONFIG["runner_sha256"])
    reader.read(CONFIG["tests"], CONFIG["tests_sha256"])
    for bound in CONFIG["source_bindings"].values():
        reader.read(bound["path"], bound["sha256"])
    design = receipt["design"]
    _same([receipt["status"], receipt["runner_sha256"], receipt["test_sha256"], receipt["pillow_version"],
           design["lineage_id"], design["canvas"], receipt["unique_raster_calls"]],
          ["STATIC_REMEDIATION_RENDERED_NOT_ADMITTED", CONFIG["runner_sha256"], CONFIG["tests_sha256"],
           primitives.DECODER_VERSION, CONFIG["lineage_id"], [1920, 1080], 11], "compact generation identity differs")
    identity = primitives._sha(primitives._canonical({"design": design, "runner": CONFIG["runner_sha256"],
        "tests": CONFIG["tests_sha256"], "pillow": receipt["pillow_file_sha256"]}))[:24]
    if Path(CONFIG["directory"]).name != "static-" + identity:
        raise ValueError("compact generation identity does not recompose")
    _same(design["font"], {"path": str(primitives.FONT), "sha256": primitives.FONT_SHA}, "compact font differs")
    reader.read_path(primitives.FONT, primitives.FONT_SHA)
    bible = _read_json(reader, CONFIG["source_bindings"]["style_bible"])
    _same([bible["channel_id"], bible["palette"]["locked_hex"]], [primitives.CHANNEL, primitives.PALETTE],
          "compact ChannelDNA/palette differs")
    layouts = _read_json(reader, {"path": CONFIG["directory"] + "/layouts.json",
        "sha256": receipt["artifact_sha256"]["layouts.json"]})
    return reader, literal, receipt, bible, layouts


def _svg(raw, layout):
    """Typed rect/text SVG only; column-major text is not a two-string overlay."""
    if b"<!" in raw or b"<?" in raw:
        raise ValueError("SVG declarations/entities are forbidden")
    value = ElementTree.fromstring(raw)
    ns = "{http://www.w3.org/2000/svg}"
    _same(value.attrib, {"width": "1920", "height": "1080", "viewBox": "0 0 1920 1080"}, "SVG canvas differs")
    if value.tag != ns + "svg" or any(node.tag not in {ns + "svg", ns + "rect", ns + "text"} for node in value.iter()):
        raise ValueError("compact SVG contains an unrecognized element")
    if any(list(node) or node.tag == ns + "svg" for node in value):
        raise ValueError("nested SVG content is forbidden")
    rectangles = [node for node in value if node.tag == ns + "rect"]
    if len(rectangles) != 7:
        raise ValueError("compact panel rectangle population differs")
    for node in rectangles:
        if (set(node.attrib) != {"x", "y", "width", "height", "fill"}
                or node.attrib["fill"] not in primitives.PALETTE
                or any(re.fullmatch(r"0|[1-9][0-9]*", node.attrib[key]) is None
                       for key in ("x", "y", "width", "height"))
                or node.text is not None):
            raise ValueError("compact rectangle attributes differ")
        x, y, width, height = (int(node.attrib[key]) for key in ("x", "y", "width", "height"))
        if not (width > 0 and height > 0 and x + width <= 1920 and y + height <= 1080):
            raise ValueError("compact rectangle geometry is outside canvas")
    texts = [node for node in value if node.tag == ns + "text"]
    if len(texts) != len(layout):
        raise ValueError("compact SVG text block population differs")
    for node, block in zip(texts, layout, strict=True):
        if list(node):
            raise ValueError("nested SVG text content is forbidden")
        _same(node.text, block["text"], "SVG copy differs from exact layout")
        _same(node.attrib, {"x": str(block["bounds"][0]), "y": str(block["baseline_y"]),
            "fill": "#D7A94A" if block["baseline_y"] == 437 else "#E8EDF2",
            "font-family": "Arial", "font-weight": "700", "font-size": "64"}, "SVG typography/column differs")


def _inventory(reader, receipt):
    names = {sid + extension for sid in CONFIG["state_ids"] for extension in (".png", ".svg")} | {"layouts.json"}
    if set(receipt["artifact_sha256"]) != names:
        raise ValueError("compact receipt requires the exact 25 artifacts")
    directory = reader.path(CONFIG["directory"])
    if {item.name for item in directory.iterdir()} != names | {"receipt.json"}:
        raise ValueError("compact physical artifact inventory differs")
    data = {name: reader.read(CONFIG["directory"] + "/" + name, receipt["artifact_sha256"][name])
            for name in sorted(names)}
    if data["visual-u016-s00.png"] != data["visual-u016-s01.png"]:
        raise ValueError("compact HOLD source pixels changed")
    if len({primitives._sha(data[sid + ".png"]) for sid in CONFIG["state_ids"]}) != 11:
        raise ValueError("compact content population must be 12 paths and 11 byte identities")
    return data, names


def _contract(row, state, original):
    entry = state["entry"]
    if type(entry) is not dict or set(entry) != {"kind", "char_start", "char_end", "text", "previous_state_id"}:
        raise ValueError("compact entry fields differ")
    kind = entry["kind"]
    if (original["state_id"] != state["state_id"] or original["unit_id"] != row["unit_id"]
            or original["take_id"] not in row["fragment_ids"]):
        raise ValueError("compact source origin fragment differs")
    _same(original["entry"], entry, "compact source lexical/HOLD entry differs")
    _same(original["all_visible_copy"], state["visual_content"]["literal_copy"], "compact source literal copy differs")
    _same(original["unit_text"], row["text"], "compact source literal narration differs")
    lexical = None
    if kind == "LEXICAL_START":
        if (type(entry["char_start"]) is not int or type(entry["char_end"]) is not int
                or type(entry["text"]) is not str or entry["previous_state_id"] != state["state_id"][:-1] + "0"):
            raise ValueError("compact lexical entry types/previous state differ")
        if (row["unit_id"], entry["char_start"], entry["char_end"], entry["text"]) not in (
                ("narration-unit-011", 14, 19, "write"), ("narration-unit-012", 15, 20, "write")):
            raise ValueError("only the two preserved write anchors are supported")
        lexical = {"unit_id": row["unit_id"], "fragment_id": original["take_id"],
                   **{key: entry[key] for key in ("text", "char_start", "char_end")}}
        timing = "CALIBRATED_LEXICAL_REQUIRED"
    elif kind == "CONTINUE_STATE":
        if state["state_id"] != "visual-u016-s01" or entry["previous_state_id"] != "visual-u016-s00":
            raise ValueError("only the exact u016 continuation is supported")
        if any(entry[key] is not None for key in ("char_start", "char_end", "text")):
            raise ValueError("HOLD continuation cannot invent a lexical anchor")
        timing = "HOLD_CONTINUATION_NOT_TIMED"
    elif kind == "UNIT_ENTRY":
        if any(entry[key] is not None for key in ("char_start", "char_end", "text", "previous_state_id")):
            raise ValueError("unit entry is untimed and cannot invent a lexical anchor")
        timing = "UNIT_ENTRY_NOT_BOUND"
    else:
        raise ValueError("compact entry class differs")
    return {"unit_id": row["unit_id"], "fragment_ids": [original["take_id"]],
        "unit_fragment_ids": copy.deepcopy(row["fragment_ids"]), "literal_narration": row["text"],
        "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"]),
        "text_blocks": copy.deepcopy(state["visual_content"]["literal_copy"]),
        "entry": copy.deepcopy(entry), "timing_kind": timing, "lexical_target": lexical,
        "continuation_of_state_id": entry["previous_state_id"] if kind == "CONTINUE_STATE" else None,
        "visual_content": copy.deepcopy(state["visual_content"])}


def inspect_compact_sources(root, requests):
    """Batch read/decode once per byte-identical PNG, with same-call rechecks.

    This is a source measurement, not an asset-use, rights, publicity, scheduling
    or publication gate. All twelve physical states are inspected even when a
    caller requests only one; no persistent cache or caller-selected recipe.
    """
    _requests(root, requests)  # Invalid requests fail before metadata or decoder.
    reader, literal, receipt, bible, layouts = _preflight(root)
    data, names = _inventory(reader, receipt)
    by_state = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    originals = receipt["design"]["states"]
    if [row["state_id"] for row in originals] != CONFIG["state_ids"] or set(layouts) != set(CONFIG["state_ids"]):
        raise ValueError("compact states/layouts population differs")
    contracts = {}
    for original in originals:
        sid = original["state_id"]
        row, state = by_state[sid]
        contracts[sid] = _contract(row, state, original)
        amendment._validate_layout(layouts[sid], original["left"], original["right"])
        _svg(data[sid + ".svg"], layouts[sid])
    decoder = primitives._verify_decoder(reader)
    measurements, groups = {}, {}
    for sid in CONFIG["state_ids"]:
        raw = data[sid + ".png"]
        digest = primitives._sha(raw)
        groups.setdefault(digest, []).append(sid)
        if digest not in measurements:
            measurements[digest] = primitives._png(raw, [1920, 1080])
    common = {"version": VERSION, "status": "STATIC_SOURCE_VERIFIED_NOT_ADMITTED",
        "template_id": TEMPLATE_ID, "media_kind": "STATIC_IMAGE", "source_start_frame": 0, "source_end_frame": 1,
        "lineage_id": CONFIG["lineage_id"], "channel_id": primitives.CHANNEL,
        "style_bible_id": bible["style_bible_id"], "observed_sample": None, "video_frame": None,
        "receipt_binding": {"path": str(reader.path(CONFIG["directory"] + "/receipt.json")), "sha256": CONFIG["receipt_sha256"]},
        "literal_reference_binding": copy.deepcopy(REFERENCE), "literal_reference_scope": "HISTORICAL_A9_METADATA_NOT_NEW_PCM_VERIFICATION",
        "amendment_inspection_sha256": canonical_sha(literal), "source_bindings": copy.deepcopy(CONFIG["source_bindings"]),
        "source_technically_verified": True, "source_ready": False, "global_schedule_created": False,
        "calibrated_timing_available": False, "technical_cost_brl": 0, "authority": dict(AUTHORITY),
        "decoder": decoder, "state_count": 12, "unique_content_count": len(measurements), "lineage_count": 1,
        "claim_boundary": "Pinned PNG integrity/opacity/dimensions and literal source contract only. Historical OCR/QA is not reexecuted; no timing, rights/publicity, perceptual or final-video approval.",
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"])}
    results = {}
    for sid in CONFIG["state_ids"]:
        digest = primitives._sha(data[sid + ".png"])
        proof = {**common, "state_id": sid, **contracts[sid], **measurements[digest],
            "asset_binding": reader.bindings[str(reader.path(CONFIG["directory"] + "/" + sid + ".png"))],
            "content_sha256": digest, "equivalent_state_ids": groups[digest],
            "canonical_content_state_id": groups[digest][0], "layout_records": layouts[sid]}
        proof["inspection_id"] = "compact-source-" + primitives._sha(primitives._canonical(proof))[:24]
        results[sid] = proof
    selected = [results[request["state_id"]] for request in requests]
    primitives.recheck_static_dependencies(root, selected)
    if {item.name for item in reader.path(CONFIG["directory"]).iterdir()} != names | {"receipt.json"}:
        raise ValueError("compact inventory changed during inspection")
    return primitives._json(primitives._canonical(selected))  # Detached proofs.


def inspect_compact_source(root, *, template_id, state_id, receipt_binding):
    return inspect_compact_sources(root, [{"template_id": template_id, "state_id": state_id, "receipt_binding": receipt_binding}])[0]


def verify_compact_source(candidate, root, *, template_id, state_id, receipt_binding):
    expected = inspect_compact_source(root, template_id=template_id, state_id=state_id, receipt_binding=receipt_binding)
    _same(candidate, expected, "compact source differs from independent inspection")
    return expected
