"""Read-only recomposition of one pinned, technically verified QA clean plate.

This is not source admission, a rights-ledger registration, or a video gate.
The completed native journals are replayed; no native effect can be requested.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import re
from types import ModuleType, SimpleNamespace

from .phase6_av_publicity import binding as _resident_binding, resolve as _resolve

VERIFIER_VERSION = "phase6-av-clean-plate-verifier-v1"
ROOT = Path(__file__).resolve().parents[1]
QA = "output/qa/phase6/diagnostics"
RUNNER = QA + "/materialize_two_column_clean_plate_v1.py"
RUNNER_SHA = "ef0d956239c512d08e5fc9559e676225129fe907f6947c45a6134a678831eec2"
HELPER = QA + "/run_pocketsphinx_estimates_v1.py"
HELPER_SHA = "490f893bc13921ada77e1cd73bfe74c4fdb8536888334a65c92286e6d0386f2d"
FOLDER = QA + "/two-column-clean-plate-v1-ef0d956239c512d0"
RECEIPT = FOLDER + "/receipt.json"
RECEIPT_SHA = "25fe4e9047971a8f88d86ce5de07f8ea15b042831ab5fa96b2e277689811ac7a"
RECEIPT_SIZE = 113890
ASSET_SHA = "7031f3abc85881e10e2c8b78875b935fa07705a1844dfbeb98b1513cc7529471"
ASSET_SIZE = 9498584
LINEAGE = "heroverse-owned-clean-plate-081827"
STATUS = "SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED"
AUTHORITY = {key: False for key in (
    "production_authorized", "render_authorized", "queue_authorized",
    "publication_authorized", "quality_approved", "publicity_approved",
    "legal_release", "retiming_authorized",
)}
CAPACITY = {"frame_count": 1800, "duration_seconds": 60, "width": 1920, "height": 1080, "fps": 30}
_EXTERNAL = {
    "C:/ffmpeg/bin/ffmpeg.exe": "adc02bab9339422bbb6df60ff9a228f955cc32138bfd223eed10ff9d8cb18890",
    "C:/ffmpeg/bin/ffprobe.exe": "bb84d49c6fe193f8eccc8c3875662ded14ff7da28eeb0ecf45da4a22d261d149",
}
_RESIDENT_HELPER = ("hero_engine/phase6_av_publicity.py",
    "b20ffd38a8f737fffce75e5625c8dbda2f463841665350acf3950874b39fc567")


class CleanPlateError(ValueError):
    pass


def _digest(value):
    if not isinstance(value, str) or not re.fullmatch(r"(?:sha256:)?[0-9a-f]{64}", value):
        raise CleanPlateError("invalid SHA-256")
    return "sha256:" + value.removeprefix("sha256:")


def _open(root, value, expected_path, digest, size=None):
    """Use the project's resident/confined reader before opening any bytes."""
    expected = _resolve(root, expected_path)
    external = not expected.is_relative_to(root)
    if external and _EXTERNAL.get(expected.as_posix()) != _digest(digest)[7:]:
        raise CleanPlateError("external dependency is not an exact fixed tool")
    source = _resolve(root, value, confined=not external)
    if source != expected:
        raise CleanPlateError("source path differs from pinned namespace")
    actual = _resident_binding(source)
    if actual["sha256"] != _digest(digest):
        raise CleanPlateError("source hash changed")
    if size is not None and (type(size) is not int or size < 0 or actual["size_bytes"] != size):
        raise CleanPlateError("source size changed")
    actual["path"] = source.as_posix() if external else source.relative_to(root).as_posix()
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != actual["sha256"][7:] or len(raw) != actual["size_bytes"]:
        raise CleanPlateError("source changed during read")
    return actual, raw


def _load_bytes(root, relative, digest, name):
    pin, raw = _open(root, relative, relative, digest)
    module = ModuleType(name)
    module.__file__ = str(root / relative)
    # Compile the exact bytes just verified, not a second loader read or pyc.
    exec(compile(raw, module.__file__, "exec"), module.__dict__)
    return module, pin


def _deny_effect(*args, **kwargs):
    raise CleanPlateError("read-only verifier cannot write or execute native effects")


def _checked_result(h, replay, contract, receipt):
    if h.canonical(replay) != h.canonical(receipt):
        raise CleanPlateError("replay differs from caller-pinned receipt")
    if (replay["status"] != STATUS or replay["evidence_mode"] != "LIVE_QA"
            or replay["lineage_id"] != LINEAGE or contract["lineage_id"] != LINEAGE
            or replay["authority"] != AUTHORITY
            or any(type(value) is not bool for value in replay["authority"].values())
            or type(replay["technical_cost_brl"]) is not int or replay["technical_cost_brl"] != 0
            or replay["narrative_timing_approved"] is not False
            or contract["origin"]["rights_ledger_registered"] is not False
            or contract["origin"]["publicity_approval"] is not False):
        raise CleanPlateError("QA source identity/authority differs")
    for key, actual in {"width": replay["width"], "height": replay["height"], "fps": replay["fps"],
                       "frame_count": replay["capacity_frame_count"],
                       "duration_seconds": replay["capacity_duration_seconds"]}.items():
        if type(actual) is not int or actual != CAPACITY[key]:
            raise CleanPlateError("source capacity differs")


def verify_clean_plate(root: Path, receipt_binding: dict) -> dict:
    """Reopen the frozen real receipt and its entire source/effect provenance."""
    root = _resolve(Path(root), root, confined=True)
    if root != ROOT or not isinstance(receipt_binding, dict) or set(receipt_binding) != {"path", "sha256", "size_bytes"}:
        raise CleanPlateError("exact workspace and receipt binding required")
    if (_digest(receipt_binding["sha256"]) != _digest(RECEIPT_SHA)
            or type(receipt_binding["size_bytes"]) is not int or receipt_binding["size_bytes"] != RECEIPT_SIZE):
        raise CleanPlateError("only the pinned real receipt is supported")
    receipt_pin, receipt_raw = _open(root, receipt_binding["path"], RECEIPT, RECEIPT_SHA, RECEIPT_SIZE)
    resident_pin, _ = _open(root, _RESIDENT_HELPER[0], *_RESIDENT_HELPER)
    runner, _ = _load_bytes(root, RUNNER, RUNNER_SHA, "_clean_plate_runner_frozen")
    helper, _ = _load_bytes(root, HELPER, HELPER_SHA, "_clean_plate_replay_helper_frozen")
    if runner.ROOT != root or helper.ROOT != root or runner.HELPER_SHA != HELPER_SHA:
        raise CleanPlateError("loaded code belongs to a different workspace/helper")
    # Supply only pure functions to the frozen runner. No global monkeypatch.
    names = ("path", "pinned", "read", "bind", "verify", "canonical", "utc")
    h = SimpleNamespace(**{name: getattr(helper, name) for name in names},
        atomic=_deny_effect, save=_deny_effect, owned=_deny_effect, capacity=_deny_effect)
    folder = _resolve(root, FOLDER, confined=True)
    expected_names = {"receipt.json", "recipe.json", "clean-plate.mkv"}
    expected_names.update(f"{stage}-{kind}.{suffix}" for stage in runner.STAGES
                          for kind, suffix in (("intent", "json"), ("terminal", "json"), ("stdout", "bin")))
    if {item.name for item in folder.iterdir()} != expected_names:
        raise CleanPlateError("incomplete, active or unexpected QA namespace")
    contract = runner.source_contract(h)
    replay = runner.execute(h, folder, contract, replay=True)
    _checked_result(h, replay, contract, runner.strict_json(receipt_raw))
    dependencies, roles = [], []
    def add(role, pin):
        if any(row["role"] == role for row in roles):
            raise CleanPlateError("duplicate dependency role")
        dependencies.append(pin)
        roles.append({"role": role, "path": pin["path"], "sha256": pin["sha256"]})
    for row in contract["source_bindings"]:
        item = row["file"]
        expected = RUNNER if row["role"] == "runner" else HELPER if row["role"] == "helper" else (
            runner.FFMPEG[0] if row["role"] == "ffmpeg" else runner.FFPROBE[0] if row["role"] == "ffprobe" else runner.PINS[row["role"]][0])
        pin, _ = _open(root, item["path"], expected, item["sha256"], item["bytes"])
        add(row["role"], pin)
    add("clean_plate_receipt", receipt_pin)
    for role, path in [("clean_plate_recipe", folder / "recipe.json")] + [
            (f"{stage}_{kind}", folder / f"{stage}-{kind}.{suffix}")
            for stage in runner.STAGES for kind, suffix in (("intent", "json"), ("terminal", "json"), ("stdout", "bin"))]:
        item = h.bind(path)
        pin, _ = _open(root, path, path, item["sha256"], item["bytes"])
        add(role, pin)
    asset_pin, _ = _open(root, replay["asset"]["path"], FOLDER + "/clean-plate.mkv", ASSET_SHA, ASSET_SIZE)
    add("clean_plate_asset", asset_pin)
    add("resident_source_helpers", resident_pin)
    own = _resident_binding(Path(__file__))
    own_pin, _ = _open(root, __file__, "hero_engine/phase6_av_clean_plate.py", own["sha256"], own["size_bytes"])
    add("clean_plate_verifier", own_pin)
    # Final caller-pinned recheck detects mutation during the replay itself.
    _open(root, receipt_binding["path"], RECEIPT, RECEIPT_SHA, RECEIPT_SIZE)
    return {"verifier_version": VERIFIER_VERSION, "status": STATUS,
        "channel_id": contract["channel_id"], "style_bible_id": contract["style_bible_id"],
        "receipt_binding": receipt_pin, "asset_binding": asset_pin, "lineage_id": LINEAGE,
        "capacity": dict(CAPACITY),
        "source_take_plan_binding": dependencies[next(i for i, row in enumerate(roles) if row["role"] == "take_plan")],
        "dependency_bindings": dependencies, "dependency_roles": roles,
        "authority": dict(AUTHORITY), "technical_cost_brl": 0}
