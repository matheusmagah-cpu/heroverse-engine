"""Bounded layered-hook recipe for the current Phase 6 take-003.

This is a versioned sidecar contract, not a TakePlan mutation, a general hook
generator, a production admission, or a publication authority.  It preserves
the spoken NAME / TEST / CHOOSE mechanism as the primary information layer and
keeps TRUTH / RESPONSIBILITY / TODAY as a separately labelled channel-system
signature.  Geometry is measurable before FFmpeg; pixels and motion still need
an independent rendered-sample review.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .phase6_visual_recipe import (
    BASE_FILTERS,
    OUTPUT_FILTERS,
    _Region,
    _drawtext_filter,
    _place_copy,
    _safe_area,
    _write_text_atomic,
)


RECIPE_ID = "heroverse-take003-layered-hook-v3"
SCHEMA_VERSION = "1.0.0"
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "phase6-video-002-prepublication"
TAKE_ID = "take-003"
TAKE_PLAN_ID = "phase6-take-plan-bc3f25d5090c1087b1c8"
TREATMENT_PLAN_ID = "phase6-creative-treatment-cf293983991713e08165"
ALLOCATION_ID = "phase6-allocation-3f748201a49c7259a1e2"
STYLE_BIBLE_ID = "phase6-style-bible-52ee5ad9f326c9cf0abb"
STYLE_BIBLE_VERSION = "3.3.0-phase6-video2"
FORMAT_PACK_ID = "fp-broll-cinematic-narration"
FORMAT_PACK_VERSION = "1.1.0"

START_MS = 3_000
END_MS = 8_000
DURATION_MS = 5_000
NARRATION = "Name the pressure, test its story, then choose the faithful move."
PRIMARY_COPY = "NAME / TEST / CHOOSE"
PRIMARY_TOKENS = ("NAME", "TEST", "CHOOSE")
SYSTEM_COPY = "TRUTH / RESPONSIBILITY / TODAY"
SYSTEM_TOKENS = ("TRUTH", "RESPONSIBILITY", "TODAY")
SYSTEM_RENDER_COPY = "SYSTEM: " + SYSTEM_COPY

ASSET_ID = "asset-owned-three-card-decision-v1"
ASSET_ROLE = "decision_cards"
ASSET_PATH = (
    "output/production/phase5/pilot-001/creative-v3/assets/"
    "asset-owned-three-card-decision-v1.mp4"
)
ASSET_SHA256 = "sha256:417046cd4e2a7c199d574b45fb405cd5278d1e0cc53529a8001add60b9a2f23e"
ASSET_START_MS = 18_300
ASSET_END_MS = 23_300

PALETTE = {
    "dominant": "#081827",
    "accent": "#D7A94A",
    "text": "#E8EDF2",
    "support": "#2C5364",
}

# These are stable overlay zones inside the three blank card surfaces seen in
# the exact bound source.  They deliberately avoid the hand/card contact and
# the card edges/gaps that make the source's three-state function legible.
LABEL_ZONES = (
    {"region_id": "left-card-label", "left": 180, "top": 620, "right": 540, "bottom": 750},
    {"region_id": "middle-card-label", "left": 760, "top": 620, "right": 1_160, "bottom": 750},
    {"region_id": "right-card-label", "left": 1_388, "top": 620, "right": 1_766, "bottom": 750},
)

# V2 placed the right label at x=1340 and its 347px backing began at x=1366.
# The exact first source frame showed the backing outside the right-card paper.
# V3 moves only that label 48px right and requires full backing containment,
# with measured clearance, on every one of the 150 source frames.
FULL_SPAN_GEOMETRY_POLICY = {
    "required_frame_count": 150,
    "minimum_assigned_card_hull_fraction": 1.0,
    "minimum_assigned_card_corner_clearance_pixels": 8.0,
    "minimum_photometric_card_fraction": 0.85,
    "right_label_shift_from_v2_pixels": 48,
}

# Conservative visible card surfaces at the reviewed 1920x1080 crop.  The
# coverage ratio is calculated against these surfaces, while LABEL_ZONES remain
# the much tighter placement constraint.
CARD_SURFACE_REGIONS = (
    {"region_id": "left-card-surface", "left": 154, "top": 500, "right": 600, "bottom": 850},
    {"region_id": "middle-card-surface", "left": 650, "top": 455, "right": 1_240, "bottom": 875},
    {"region_id": "right-card-surface", "left": 1_280, "top": 500, "right": 1_766, "bottom": 850},
)

# Conservative regions that the overlay recipe must never cover.  This is a
# geometric preflight only; a future proof render must confirm these bounds
# remain valid across the moving five-second source span.
PROTECTED_REGIONS = (
    {"region_id": "hand-card-contact", "left": 800, "top": 87, "right": 1_380, "bottom": 585},
    {"region_id": "three-card-topology", "left": 154, "top": 440, "right": 1_766, "bottom": 595},
    {"region_id": "left-middle-card-gap", "left": 540, "top": 500, "right": 710, "bottom": 930},
    {"region_id": "middle-right-card-gap", "left": 1_225, "top": 500, "right": 1_335, "bottom": 930},
    {"region_id": "three-card-lower-edges", "left": 154, "top": 780, "right": 1_766, "bottom": 930},
)

PRIMARY_EVENT = {
    "event_id": "primary-spoken-mechanism",
    "start_offset_ms": 0,
    "end_offset_ms": 5_000,
    "semantic_role": "SPOKEN_MECHANISM",
}
SECONDARY_EVENT = {
    "event_id": "secondary-channel-system",
    "start_offset_ms": 2_500,
    "end_offset_ms": 5_000,
    "semantic_role": "CHANNEL_IDENTITY_SYSTEM",
}


class LayeredHookContractError(ValueError):
    """The exact take/source/style contract no longer matches this sidecar."""


class LayeredHookLayoutError(ValueError):
    """The two-layer hook cannot be represented inside its measured bounds."""


def canonical_sha(value: Any) -> str:
    encoded = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _one(items: Any, *, take_id: str, label: str) -> dict[str, Any]:
    if not isinstance(items, list):
        raise LayeredHookContractError(f"{label} take collection is missing")
    ids = [item.get("take_id") for item in items if isinstance(item, dict)]
    if len(ids) != len(items) or len(ids) != len(set(ids)):
        raise LayeredHookContractError(f"{label} take identities are invalid or duplicated")
    matches = [item for item in items if item.get("take_id") == take_id]
    if len(matches) != 1:
        raise LayeredHookContractError(f"{label} must contain exactly one {take_id}")
    return matches[0]


def _require_subset(actual: dict[str, Any], expected: dict[str, Any], label: str) -> None:
    for key, value in expected.items():
        if actual.get(key) != value:
            raise LayeredHookContractError(
                f"{label}.{key} differs from the reviewed take-003 contract"
            )


def _validate_source_documents(
    take_plan: dict[str, Any],
    treatment_plan: dict[str, Any],
    allocation: dict[str, Any],
    style_bible: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    _require_subset(take_plan, {
        "schema_version": "1.0.0", "take_plan_id": TAKE_PLAN_ID,
        "channel_id": CHANNEL_ID, "video_id": VIDEO_ID,
        "format_pack_id": FORMAT_PACK_ID, "format_pack_version": FORMAT_PACK_VERSION,
        "style_bible_id": STYLE_BIBLE_ID,
    }, "take_plan")
    take = _one(take_plan.get("takes"), take_id=TAKE_ID, label="take_plan")
    _require_subset(take, {
        "start_ms": START_MS, "end_ms": END_MS,
        "narrative_function": "mechanism",
        "information": "show three physical information states",
        "media_type": "INFOGRAPHIC", "on_screen_text": PRIMARY_COPY,
        "narration": NARRATION, "asset_origin": f"{ASSET_PATH}#t=18.300,23.300",
        "semantic_alignment": "exact semantic role decision_cards",
        "retention_job": "deliver the usable method",
    }, TAKE_ID)

    _require_subset(treatment_plan, {
        "schema_version": "1.0.0", "treatment_plan_id": TREATMENT_PLAN_ID,
        "channel_id": CHANNEL_ID, "video_id": VIDEO_ID,
        "format_pack_id": FORMAT_PACK_ID, "format_pack_version": FORMAT_PACK_VERSION,
    }, "treatment_plan")
    treatment = _one(
        treatment_plan.get("takes") or treatment_plan.get("treatments"),
        take_id=TAKE_ID,
        label="treatment_plan",
    )
    _require_subset(treatment, {
        "treatment": "HOOK_FRAMEWORK", "text_layout": "FRAMEWORK_BAR",
        "visual_event_count": 2, "pattern_interrupt": True,
        "framework_state": "INTRODUCED", "sfx": "WHOOSH",
    }, f"treatment.{TAKE_ID}")
    grammar = treatment_plan.get("grammar") or {}
    if grammar.get("framework") != list(SYSTEM_TOKENS):
        raise LayeredHookContractError("treatment framework is not the locked channel system")

    _require_subset(allocation, {
        "schema_version": "1.0.0", "allocation_id": ALLOCATION_ID,
        "video_id": VIDEO_ID, "publication_authorized": False,
    }, "allocation")
    allocated = _one(
        allocation.get("allocations") or allocation.get("takes") or allocation.get("items"),
        take_id=TAKE_ID,
        label="allocation",
    )
    _require_subset(allocated, {
        "required_role": ASSET_ROLE, "asset_id": ASSET_ID, "asset_role": ASSET_ROLE,
        "source_path": ASSET_PATH, "source_start_ms": ASSET_START_MS,
        "source_end_ms": ASSET_END_MS, "duration_ms": DURATION_MS,
        "content_hash": ASSET_SHA256, "rights_status": "OWNED",
    }, f"allocation.{TAKE_ID}")

    _require_subset(style_bible, {
        "schema_version": "1.0.0", "style_bible_id": STYLE_BIBLE_ID,
        "channel_id": CHANNEL_ID, "version": STYLE_BIBLE_VERSION,
    }, "style_bible")
    role_map = ((style_bible.get("palette") or {}).get("role_map") or {})
    if role_map != PALETTE:
        raise LayeredHookContractError("style-bible palette roles changed")
    typography = style_bible.get("typography") or {}
    if typography.get("families") != ["Bahnschrift", "Arial"]:
        raise LayeredHookContractError("style-bible font family changed")
    if ((typography.get("safe_area") or {}).get("horizontal_percent"),
            (typography.get("safe_area") or {}).get("vertical_percent")) != (8, 8):
        raise LayeredHookContractError("style-bible safe area changed")
    if (typography.get("minimum_sizes") or {}).get("1920x1080") != 54:
        raise LayeredHookContractError("style-bible minimum font size changed")
    principles = ((style_bible.get("identity") or {}).get("principles") or [])
    if "TRUTH / RESPONSIBILITY / TODAY remains the locked information system" not in principles:
        raise LayeredHookContractError("locked channel-system principle is absent")
    references = {
        item.get("reference_id"): item
        for item in style_bible.get("reference_assets") or []
        if isinstance(item, dict)
    }
    reference = references.get(ASSET_ID) or {}
    if (reference.get("hash"), reference.get("purpose")) != (ASSET_SHA256, ASSET_ROLE):
        raise LayeredHookContractError("style-bible source reference no longer matches allocation")
    return take, treatment, allocated


def build_layered_hook_plan(
    take_plan: dict[str, Any],
    treatment_plan: dict[str, Any],
    allocation: dict[str, Any],
    style_bible: dict[str, Any],
) -> dict[str, Any]:
    """Build a deterministic sidecar bound to the four exact source documents."""

    before = tuple(copy.deepcopy(item) for item in (
        take_plan, treatment_plan, allocation, style_bible
    ))
    _validate_source_documents(take_plan, treatment_plan, allocation, style_bible)
    plan: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "recipe_id": RECIPE_ID,
        "recipe_version": "3.0.0",
        "scope": "ISOLATED_LAYERED_HOOK_PROTOTYPE_NOT_PRODUCTION",
        "status": "PROTOTYPE_LAYOUT_CONTRACT_ONLY",
        "channel_id": CHANNEL_ID,
        "video_id": VIDEO_ID,
        "take_id": TAKE_ID,
        "start_ms": START_MS,
        "end_ms": END_MS,
        "duration_ms": DURATION_MS,
        "source_bindings": {
            "take_plan": {"id": TAKE_PLAN_ID, "sha256": canonical_sha(take_plan)},
            "treatment_plan": {"id": TREATMENT_PLAN_ID, "sha256": canonical_sha(treatment_plan)},
            "allocation": {"id": ALLOCATION_ID, "sha256": canonical_sha(allocation)},
            "style_bible": {"id": STYLE_BIBLE_ID, "sha256": canonical_sha(style_bible)},
        },
        "source_asset": {
            "asset_id": ASSET_ID,
            "role": ASSET_ROLE,
            "path": ASSET_PATH,
            "sha256": ASSET_SHA256,
            "source_start_ms": ASSET_START_MS,
            "source_end_ms": ASSET_END_MS,
            "declared_rights_status": "OWNED",
            "rights_assessment_by_sidecar": "NOT_PERFORMED",
        },
        "narration": NARRATION,
        "voice_policy": {
            "action": "NONE_PRESERVE_EXISTING_VOICE",
            "copy_change_allowed": False,
            "speed_change_allowed": False,
            "truncation_allowed": False,
        },
        "primary_layer": {
            "copy": PRIMARY_COPY,
            "tokens": list(PRIMARY_TOKENS),
            "priority": "PRIMARY",
            "semantic_relation": "SPOKEN_ORDERED_MECHANISM",
            "presentation": "THREE_ORDERED_CARD_LABELS",
            "event_id": PRIMARY_EVENT["event_id"],
        },
        "secondary_layer": {
            "copy": SYSTEM_COPY,
            "render_copy": SYSTEM_RENDER_COPY,
            "tokens": list(SYSTEM_TOKENS),
            "priority": "SECONDARY",
            "semantic_relation": "CHANNEL_IDENTITY_SYSTEM_NOT_STEP_MAPPING",
            "presentation": "ONE_COMPACT_TOP_LEFT_SYSTEM_GROUP",
            "one_to_one_card_mapping_allowed": False,
            "event_id": SECONDARY_EVENT["event_id"],
        },
        "visual_events": [dict(PRIMARY_EVENT), dict(SECONDARY_EVENT)],
        "style_contract": {
            "style_bible_id": STYLE_BIBLE_ID,
            "style_bible_version": STYLE_BIBLE_VERSION,
            "format_pack_id": FORMAT_PACK_ID,
            "format_pack_version": FORMAT_PACK_VERSION,
            "palette": dict(PALETTE),
            "font_families": ["Bahnschrift", "Arial"],
            "minimum_font_size": 54,
            "safe_area_percent": 8,
            "maximum_lines_per_text": 2,
        },
        "source_function_contract": {
            "declared_information": "show three physical information states",
            "visual_role": ASSET_ROLE,
            "label_zones": [dict(item) for item in LABEL_ZONES],
            "card_surface_regions": [dict(item) for item in CARD_SURFACE_REGIONS],
            "protected_regions": [dict(item) for item in PROTECTED_REGIONS],
            "maximum_primary_backing_surface_ratio": 0.18,
            "full_span_geometry_policy": dict(FULL_SPAN_GEOMETRY_POLICY),
            "full_span_source_function_status": "UNVERIFIED_PENDING_PIXEL_MOTION_PROOF",
            "motion_and_pixel_review_required": True,
        },
        "quality_limits": {
            "minimum_contrast_ratio": 4.5,
            "primary_preferred_font_size": 84,
            "secondary_font_size": 54,
            "maximum_visible_text_layers": 2,
            "maximum_visual_events": 2,
            "maximum_secondary_reading_words_per_minute": 180,
        },
        "authority": {
            "take_plan_mutation_authorized": False,
            "asset_mutation_authorized": False,
            "render_authorized": False,
            "queue_authorized": False,
            "production_admission_authorized": False,
            "publication_authorized": False,
        },
        "technical_cost_brl": 0,
    }
    plan["plan_id"] = "layered-hook-plan-" + canonical_sha(plan).split(":", 1)[1][:24]
    if (take_plan, treatment_plan, allocation, style_bible) != before:
        raise RuntimeError("layered-hook builder mutated a source document")
    validate_layered_hook_plan(plan)
    return plan


def _schema() -> dict[str, Any]:
    path = Path(__file__).resolve().parents[1] / "schemas/phase6_layered_hook_plan.schema.json"
    return json.loads(path.read_text(encoding="utf-8"))


def validate_layered_hook_plan(plan: dict[str, Any]) -> None:
    Draft202012Validator(_schema()).validate(plan)
    body = {key: value for key, value in plan.items() if key != "plan_id"}
    expected_id = "layered-hook-plan-" + canonical_sha(body).split(":", 1)[1][:24]
    if plan.get("plan_id") != expected_id:
        raise LayeredHookContractError("sidecar identity no longer matches its content")
    if plan.get("narration") != NARRATION:
        raise LayeredHookContractError("sidecar changed the current take narration")
    primary = plan.get("primary_layer") or {}
    secondary = plan.get("secondary_layer") or {}
    if primary.get("copy") != PRIMARY_COPY or tuple(primary.get("tokens") or ()) != PRIMARY_TOKENS:
        raise LayeredHookContractError("primary mechanism copy/order changed")
    if " / ".join(primary["tokens"]) != primary["copy"]:
        raise LayeredHookContractError("primary card labels no longer sum to approved copy")
    if (secondary.get("copy") != SYSTEM_COPY
            or tuple(secondary.get("tokens") or ()) != SYSTEM_TOKENS
            or secondary.get("render_copy") != SYSTEM_RENDER_COPY):
        raise LayeredHookContractError("secondary channel-system copy/order changed")
    if " / ".join(secondary["tokens"]) != secondary["copy"]:
        raise LayeredHookContractError("secondary tokens no longer sum to locked system copy")
    if (secondary.get("semantic_relation") != "CHANNEL_IDENTITY_SYSTEM_NOT_STEP_MAPPING"
            or secondary.get("presentation") != "ONE_COMPACT_TOP_LEFT_SYSTEM_GROUP"
            or secondary.get("one_to_one_card_mapping_allowed") is not False):
        raise LayeredHookContractError("secondary system was converted into a false card mapping")
    if plan.get("visual_events") != [PRIMARY_EVENT, SECONDARY_EVENT]:
        raise LayeredHookContractError("the reviewed two-event ordering/timing changed")
    function = plan.get("source_function_contract") or {}
    if (function.get("label_zones") != list(LABEL_ZONES)
            or function.get("card_surface_regions") != list(CARD_SURFACE_REGIONS)
            or function.get("protected_regions") != list(PROTECTED_REGIONS)
            or function.get("full_span_geometry_policy") != FULL_SPAN_GEOMETRY_POLICY):
        raise LayeredHookContractError("reviewed source-function geometry changed")
    if plan.get("end_ms") - plan.get("start_ms") != DURATION_MS:
        raise LayeredHookContractError("take duration changed")
    if any(value is not False for value in (plan.get("authority") or {}).values()):
        raise LayeredHookContractError("prototype sidecar cannot grant operational authority")


def reconcile_layered_hook_sources(
    plan: dict[str, Any],
    take_plan: dict[str, Any],
    treatment_plan: dict[str, Any],
    allocation: dict[str, Any],
    style_bible: dict[str, Any],
) -> None:
    """Fail closed unless the sidecar still equals a fresh exact-source build."""

    validate_layered_hook_plan(plan)
    expected = build_layered_hook_plan(take_plan, treatment_plan, allocation, style_bible)
    if plan != expected:
        raise LayeredHookContractError("sidecar is not bound to the current source documents")


def verify_source_asset_file(plan: dict[str, Any], *, project_root: Path) -> dict[str, Any]:
    """Read-only exact-file check; it is not rights or visual approval."""

    validate_layered_hook_plan(plan)
    root = project_root.resolve()
    source = (root / plan["source_asset"]["path"]).resolve()
    try:
        source.relative_to(root)
    except ValueError as exc:
        raise LayeredHookContractError("source asset leaves project root") from exc
    if not source.is_file():
        raise FileNotFoundError(f"bound source asset is unavailable: {source}")
    digest = hashlib.sha256()
    with source.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    observed = "sha256:" + digest.hexdigest()
    if observed != plan["source_asset"]["sha256"]:
        raise LayeredHookContractError("bound source asset hash changed")
    return {
        "path": str(source),
        "sha256": observed,
        "bytes": source.stat().st_size,
        "identity_pass": True,
        "rights_or_visual_approval": False,
    }


def _hex_luminance(value: str) -> float:
    raw = value.removeprefix("#")
    if len(raw) != 6:
        raise LayeredHookLayoutError("contrast color must be a six-digit hex value")
    channels = [int(raw[index:index + 2], 16) / 255 for index in (0, 2, 4)]
    linear = [channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4
              for channel in channels]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def _contrast_ratio(first: str, second: str) -> float:
    high, low = sorted((_hex_luminance(first), _hex_luminance(second)), reverse=True)
    return (high + 0.05) / (low + 0.05)


def _inside(bounds: dict[str, int], region: dict[str, Any]) -> bool:
    return (
        bounds["left"] >= region["left"] and bounds["top"] >= region["top"]
        and bounds["right"] <= region["right"] and bounds["bottom"] <= region["bottom"]
    )


def _intersects(first: dict[str, int], second: dict[str, Any]) -> bool:
    return not (
        first["right"] <= second["left"] or first["left"] >= second["right"]
        or first["bottom"] <= second["top"] or first["top"] >= second["bottom"]
    )


def inspect_layered_hook_layout(plan: dict[str, Any], *, font: Path) -> dict[str, Any]:
    """Measure text/backings and semantic protection without writing or rendering."""

    validate_layered_hook_plan(plan)
    if not font.is_file():
        raise FileNotFoundError(f"layered-hook font does not exist: {font}")
    overlays: list[dict[str, Any]] = []
    decoration_records: list[dict[str, str]] = []
    card_regions = (
        _Region(180, 620, 360, 130),
        _Region(760, 620, 400, 130),
        _Region(1_410, 620, 356, 130),
    )
    primary_backgrounds: list[dict[str, int]] = []
    for index, (token, region, zone) in enumerate(
        zip(PRIMARY_TOKENS, card_regions, LABEL_ZONES, strict=True), start=1
    ):
        overlay = _place_copy(
            role=f"primary-{token.lower()}", source=token, font_path=font,
            preferred_size=84, region=region, color="0x081827",
            filename=f"{TAKE_ID}-primary-{index}.txt", allow_wrap=False,
        )
        overlay["event_id"] = PRIMARY_EVENT["event_id"]
        overlay["semantic_layer"] = "PRIMARY_SPOKEN_MECHANISM"
        bounds = overlay["bounds"]
        backing = {
            "left": bounds["left"] - 12, "top": bounds["top"] - 8,
            "right": bounds["right"] + 12, "bottom": bounds["bottom"] + 8,
        }
        backing["width"] = backing["right"] - backing["left"]
        backing["height"] = backing["bottom"] - backing["top"]
        if not _inside(backing, zone):
            raise LayeredHookLayoutError(f"{token} backing leaves its reviewed card label zone")
        primary_backgrounds.append(backing)
        decoration_records.append({
            "event_id": PRIMARY_EVENT["event_id"],
            "filter": (
                f"drawbox=x={backing['left']}:y={backing['top']}:w={backing['width']}:"
                f"h={backing['height']}:color=0xE8EDF2@1.0:t=fill"
            ),
        })
        overlays.append(overlay)

    secondary = _place_copy(
        role="secondary-channel-system", source=SYSTEM_RENDER_COPY, font_path=font,
        preferred_size=54, region=_Region(166, 100, 620, 150, horizontal="left"),
        color="0xE8EDF2", filename=f"{TAKE_ID}-channel-system.txt", allow_wrap=True,
    )
    secondary["event_id"] = SECONDARY_EVENT["event_id"]
    secondary["semantic_layer"] = "SECONDARY_CHANNEL_IDENTITY_SYSTEM"
    overlays.append(secondary)
    secondary_panel = {"left": 154, "top": 95, "right": 791, "bottom": 255}
    secondary_panel["width"] = secondary_panel["right"] - secondary_panel["left"]
    secondary_panel["height"] = secondary_panel["bottom"] - secondary_panel["top"]
    decoration_records.extend([
        {
            "event_id": SECONDARY_EVENT["event_id"],
            "filter": "drawbox=x=154:y=95:w=637:h=160:color=0x081827@1.0:t=fill",
        },
        {
            "event_id": SECONDARY_EVENT["event_id"],
            "filter": "drawbox=x=154:y=95:w=637:h=4:color=0xD7A94A@1.0:t=fill",
        },
    ])

    all_backings = primary_backgrounds + [secondary_panel]
    safe = _safe_area()
    safe_region = {
        "left": safe["left"], "top": safe["top"],
        "right": safe["right"], "bottom": safe["bottom"],
    }
    all_backings_safe = all(_inside(item, safe_region) for item in all_backings)
    protected_intersections = [
        {"backing_index": index, "protected_region_id": region["region_id"]}
        for index, backing in enumerate(all_backings)
        for region in PROTECTED_REGIONS
        if _intersects(backing, region)
    ]
    primary_surface_area = sum(item["width"] * item["height"] for item in primary_backgrounds)
    visible_card_surface_area = sum(
        (item["right"] - item["left"]) * (item["bottom"] - item["top"])
        for item in CARD_SURFACE_REGIONS
    )
    backing_ratio = primary_surface_area / visible_card_surface_area
    primary_contrast = _contrast_ratio(PALETTE["dominant"], PALETTE["text"])
    secondary_contrast = _contrast_ratio(PALETTE["text"], PALETTE["dominant"])
    minimum_contrast = min(primary_contrast, secondary_contrast)
    secondary_exposure_ms = SECONDARY_EVENT["end_offset_ms"] - SECONDARY_EVENT["start_offset_ms"]
    secondary_word_count = len(re.findall(r"[A-Za-z0-9]+", SYSTEM_RENDER_COPY))
    secondary_reading_wpm = secondary_word_count * 60_000 / secondary_exposure_ms
    visible_primary = " / ".join(
        item["source_text"] for item in overlays if item["semantic_layer"] == "PRIMARY_SPOKEN_MECHANISM"
    )
    result = {
        "recipe_id": RECIPE_ID,
        "plan_id": plan["plan_id"],
        "take_id": TAKE_ID,
        "canvas": {"width": 1_920, "height": 1_080},
        "safe_area": safe,
        "visual_events": copy.deepcopy(plan["visual_events"]),
        "decorations": decoration_records,
        "overlays": overlays,
        "primary_visible_sequence": visible_primary,
        "secondary_visible_copy": secondary["source_text"],
        "primary_backgrounds": primary_backgrounds,
        "secondary_panel": secondary_panel,
        "protected_intersections": protected_intersections,
        "primary_backing_surface_ratio": backing_ratio,
        "minimum_contrast_ratio": minimum_contrast,
        "secondary_word_count": secondary_word_count,
        "secondary_exposure_ms": secondary_exposure_ms,
        "secondary_reading_words_per_minute": secondary_reading_wpm,
        "all_text_safe": all(item["safe_area_pass"] for item in overlays),
        "all_backings_safe": all_backings_safe,
        "all_copy_preserved": all(item["copy_preserved"] for item in overlays),
        "minimum_font_size": min(item["font_size"] for item in overlays),
        "maximum_line_count": max(item["line_count"] for item in overlays),
        "proposed_bounds_geometry_pass": (
            not protected_intersections
            and backing_ratio <= plan["source_function_contract"]["maximum_primary_backing_surface_ratio"]
        ),
        "full_span_source_function_status": plan["source_function_contract"][
            "full_span_source_function_status"
        ],
        "false_one_to_one_system_mapping_absent": (
            secondary["semantic_layer"] == "SECONDARY_CHANNEL_IDENTITY_SYSTEM"
            and plan["secondary_layer"]["presentation"] == "ONE_COMPACT_TOP_LEFT_SYSTEM_GROUP"
            and len([item for item in overlays if item["semantic_layer"] == "SECONDARY_CHANNEL_IDENTITY_SYSTEM"]) == 1
        ),
        "motion_and_pixel_review_required": True,
        "production_or_publication_approval": False,
    }
    if not all((
        result["all_text_safe"], result["all_backings_safe"], result["all_copy_preserved"],
        result["proposed_bounds_geometry_pass"], result["false_one_to_one_system_mapping_absent"],
        result["minimum_font_size"] >= 54, result["maximum_line_count"] <= 2,
        result["minimum_contrast_ratio"] >= plan["quality_limits"]["minimum_contrast_ratio"],
        result["secondary_reading_words_per_minute"]
        <= plan["quality_limits"]["maximum_secondary_reading_words_per_minute"],
        result["primary_visible_sequence"] == PRIMARY_COPY,
        result["secondary_visible_copy"] == SYSTEM_RENDER_COPY,
    )):
        raise LayeredHookLayoutError("layered-hook layout failed a bounded quality contract")
    return result


def _enable(event: dict[str, Any]) -> str:
    return (
        f":enable='gte(t,{event['start_offset_ms'] / 1000:.3f})*"
        f"lt(t,{event['end_offset_ms'] / 1000:.3f})'"
    )


def compile_layered_hook_filters(
    plan: dict[str, Any],
    take_plan: dict[str, Any],
    treatment_plan: dict[str, Any],
    allocation: dict[str, Any],
    style_bible: dict[str, Any],
    *,
    font: Path,
    work_dir: Path,
) -> list[str]:
    """Compile filters only; this function never invokes FFmpeg or grants authority."""

    reconcile_layered_hook_sources(
        plan, take_plan, treatment_plan, allocation, style_bible
    )
    layout = inspect_layered_hook_layout(plan, font=font)
    event_by_id = {item["event_id"]: item for item in plan["visual_events"]}
    # Every semantic and geometric check has passed before any file is written.
    work_dir.mkdir(parents=True, exist_ok=True)
    filters = list(BASE_FILTERS)
    for item in layout["decorations"]:
        filters.append(item["filter"] + _enable(event_by_id[item["event_id"]]))
    for overlay in layout["overlays"]:
        text_path = work_dir / overlay["filename"]
        _write_text_atomic(text_path, overlay["render_text"])
        filters.append(
            _drawtext_filter(font, text_path, overlay)
            + _enable(event_by_id[overlay["event_id"]])
        )
    filters.extend(OUTPUT_FILTERS)
    return filters


__all__ = [
    "RECIPE_ID", "PRIMARY_COPY", "SYSTEM_COPY", "SYSTEM_RENDER_COPY",
    "LayeredHookContractError", "LayeredHookLayoutError",
    "build_layered_hook_plan", "validate_layered_hook_plan",
    "reconcile_layered_hook_sources", "verify_source_asset_file",
    "inspect_layered_hook_layout", "compile_layered_hook_filters",
]
