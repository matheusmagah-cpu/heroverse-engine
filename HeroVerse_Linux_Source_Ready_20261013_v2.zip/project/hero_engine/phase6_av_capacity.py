"""Projected, read-only-at-media Phase-6 continuous AV capacity contract.

The storage peak is derived from the exact complete AV timeline and the fixed
storage projection below.  Callers cannot submit an estimated peak.  The
preflight executes and hash-pins FFmpeg/FFprobe, reopens every required model,
font, narration WAV and visual source, probes writability, and observes the
actual filesystem volume.  Its verifier repeats those observations without
rendering, synthesising, queueing or publishing anything.

Stage C does not yet have an executable command recipe or source-decode/frame
count proof.  Consequently every receipt is ``BLOCKED`` by
``AVC-EXECUTABLE-RECIPE``.  A caller-controlled probe override also forces
fixture evidence.  No receipt from this version can be a LIVE capacity PASS or
grant transaction/media authority.
"""
from __future__ import annotations

import copy
import json
import math
import os
import re
import shutil
import subprocess
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker
from PIL import ImageFont

from .atomic_io import atomic_write_utf8
from .phase6_av_timeline import verify_phase6_av_timeline
from .phase6_narration_audio_inventory import inspect_pcm
from .phase6_narration_units import bytes_sha, canonical_sha
from .production_capacity import (
    FFMPEG,
    FFPROBE,
    FINAL_AUDIO_BITRATE_BPS,
    FINAL_VIDEO_BITRATE_BPS,
    INTERMEDIATE_VIDEO_BITRATE_BPS,
    MINIMUM_POST_RENDER_HEADROOM_BYTES,
    PCM_STEREO_48K_16_BIT_BPS,
    _tool_check,
    _volume_key,
)
from .render_creative_v2_phase5 import _font


ROOT = Path(__file__).resolve().parents[1]
SCHEMA = "schemas/phase6_av_capacity.schema.json"
ADMISSION_SCHEMA = "schemas/phase6_av_admission.schema.json"
RECEIPTS = Path("output/operations/phase6/av-capacity/receipts")
ARGUMENTS = Path("output/operations/phase6/av-admission/arguments")
TIMELINES = Path("output/operations/phase6/av-admission/timelines")
OUTPUT_DIR = Path("output/production/phase6/video-002/render-generations")
TEMP_DIR = Path("output/operations/phase6/av-capacity/tmp")

VERSION = "phase6-av-capacity-v1.1"
SCHEMA_VERSION = "1.1.0"
RECIPE_ID = "phase6-av-continuous-storage-projection-v2"
ESTIMATE_ID = "phase6-av-continuous-storage-peak-v2"
RECIPE_CLASSIFICATION = "PROJECTED_UNBOUND_TO_EXECUTOR"
EXECUTABLE_RECIPE_BLOCKERS = [
    "C_STAGE_COMMAND_RECIPE_NOT_IMPLEMENTED",
    "VISUAL_SOURCE_DECODE_AND_FRAME_COUNT_NOT_VERIFIED",
]
TTL_SECONDS = 300
METADATA_BYTES = 128 * 1024**2
CONTINGENCY_NUMERATOR = 25
CONTINGENCY_DENOMINATOR = 100
RATE = 24_000
SAMPLES_PER_FRAME = 800
FALSE_AUTHORITY = {
    "queue_authorized": False,
    "render_authorized": False,
    "publication_authorized": False,
    "external_effect_authorized": False,
}


class AVCapacityError(PermissionError):
    """Capacity evidence is missing, stale, divergent, or non-executable."""


def _json(raw: bytes) -> dict[str, Any]:
    def pairs(values: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in values:
            if key in result:
                raise AVCapacityError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    try:
        value = json.loads(
            raw.decode("utf-8-sig"), object_pairs_hook=pairs,
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise AVCapacityError(f"invalid JSON: {type(exc).__name__}:{exc}") from exc
    if not isinstance(value, dict):
        raise AVCapacityError("JSON evidence must be an object")
    return value


def _validator(name: str) -> Draft202012Validator:
    schema = _json(ROOT.joinpath(name).read_bytes())
    return Draft202012Validator(schema, format_checker=FormatChecker())


def _validate(value: dict[str, Any], schema: str = SCHEMA) -> None:
    errors = sorted(
        _validator(schema).iter_errors(value),
        key=lambda error: tuple(str(item) for item in error.absolute_path),
    )
    if errors:
        error = errors[0]
        location = "/".join(str(item) for item in error.absolute_path) or "$"
        raise AVCapacityError(f"schema rejected {location}: {error.message}")


def _aware(value: datetime | str, label: str) -> datetime:
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as exc:
        raise AVCapacityError(f"{label} is not ISO-8601") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise AVCapacityError(f"{label} requires an explicit UTC offset")
    return parsed.astimezone(timezone.utc)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _resolve_bound(root: Path, value: str, parent: Path | None = None) -> Path:
    raw = Path(value)
    if raw.is_absolute():
        path = raw.resolve(strict=True)
        if parent is not None:
            raise AVCapacityError("contract document paths must be project-relative")
        return path
    cursor = root.resolve(strict=True)
    for part in raw.parts:
        cursor = cursor / part
        if cursor.exists() and (cursor.is_symlink() or bool(getattr(cursor, "is_junction", lambda: False)())):
            raise AVCapacityError("symlink/junction is not accepted in a capacity binding")
    try:
        path = (root / raw).resolve(strict=True)
    except OSError as exc:
        raise AVCapacityError(f"bound file missing: {value}") from exc
    if parent is not None and path.parent != (root / parent).resolve():
        raise AVCapacityError("contract document escaped its immutable directory")
    return path


def _sha(path: Path) -> str:
    digest = __import__("hashlib").sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _load_pin(root: Path, binding: dict[str, Any], parent: Path) -> tuple[dict[str, Any], Path]:
    if not isinstance(binding, dict) or set(binding) != {"path", "sha256", "size_bytes"}:
        raise AVCapacityError("exact path/hash/size binding required")
    path = _resolve_bound(root, binding["path"], parent)
    raw = path.read_bytes()
    if len(raw) != binding["size_bytes"] or bytes_sha(raw) != binding["sha256"]:
        raise AVCapacityError("contract binding hash/size mismatch")
    return _json(raw), path


def _identity(value: dict[str, Any]) -> str:
    payload = {key: item for key, item in value.items() if key != "receipt_id"}
    return "phase6-av-capacity-" + canonical_sha(payload).split(":", 1)[1][:24]


def _ceil_ratio(numerator: int, denominator: int) -> int:
    if type(numerator) is not int or type(denominator) is not int or numerator < 0 or denominator <= 0:
        raise ValueError("non-negative integer ratio required")
    return (numerator + denominator - 1) // denominator


def _bytes_at_bitrate(bits_per_second: int, samples: int) -> int:
    return _ceil_ratio(bits_per_second * samples, 8 * RATE)


def build_phase6_av_capacity_recipe(timeline: dict[str, Any]) -> dict[str, Any]:
    """Derive a C-stage storage projection, not an executable command recipe."""
    duration = timeline.get("duration") or {}
    samples = duration.get("planned_total_samples")
    frames = duration.get("planned_total_frames")
    if type(samples) is not int or samples <= 0 or samples % SAMPLES_PER_FRAME:
        raise AVCapacityError("timeline duration is not positive and frame-exact at 24k/30fps")
    if frames != samples // SAMPLES_PER_FRAME:
        raise AVCapacityError("timeline sample/frame totals diverge")
    if len(timeline.get("units") or []) != 51 or len(timeline.get("narration_fragment_map") or []) != 90:
        raise AVCapacityError("capacity recipe requires exact 51-unit/90-fragment timeline")

    video_spans = _bytes_at_bitrate(INTERMEDIATE_VIDEO_BITRATE_BPS, samples)
    silent_concat = video_spans
    narration = _ceil_ratio(PCM_STEREO_48K_16_BIT_BPS * samples, 8 * RATE)
    sfx = _ceil_ratio(PCM_STEREO_48K_16_BIT_BPS * (samples + RATE), 8 * RATE)
    music = narration
    final_mux = _bytes_at_bitrate(FINAL_VIDEO_BITRATE_BPS + FINAL_AUDIO_BITRATE_BPS, samples)
    components = [
        {"component": "visual_span_intermediates", "estimated_bytes": video_spans,
         "basis": "all 1080p30 span intermediates projected at a conservative 60 Mb/s accounting assumption; CRF18 is variable-rate and this is not an encoder ceiling"},
        {"component": "silent_concatenated_video", "estimated_bytes": silent_concat,
         "basis": "one simultaneous concat copy at the same 60 Mb/s accounting assumption; no command graph is bound"},
        {"component": "continuous_narration_pcm", "estimated_bytes": narration,
         "basis": "one uninterrupted 48 kHz stereo PCM16 narration assembly; no per-take EQ files"},
        {"component": "sfx_pcm_bed", "estimated_bytes": sfx,
         "basis": "48 kHz stereo PCM16 full timeline plus one-second effects tail"},
        {"component": "music_pcm_bed", "estimated_bytes": music,
         "basis": "48 kHz stereo PCM16 full-timeline music bed"},
        {"component": "final_muxed_output", "estimated_bytes": final_mux,
         "basis": "12 Mb/s final-video accounting assumption plus 256 kb/s AAC; not an encoder ceiling"},
        {"component": "captions_manifests_and_checkpoints", "estimated_bytes": METADATA_BYTES,
         "basis": "fixed 128 MiB bound for captions, manifests, concat lists, logs and checkpoint JSON"},
    ]
    retained = sum(item["estimated_bytes"] for item in components)
    atomic_duplicate = max(video_spans, silent_concat, final_mux)
    pre_contingency = retained + atomic_duplicate
    contingency = _ceil_ratio(pre_contingency * CONTINGENCY_NUMERATOR, CONTINGENCY_DENOMINATOR)
    peak = pre_contingency + contingency
    stage_peaks = [
        {"stage": "SPAN_RENDER", "estimated_bytes": video_spans + METADATA_BYTES,
         "retained_components": ["visual_span_intermediates", "captions_manifests_and_checkpoints"]},
        {"stage": "CONCAT_ATOMIC_CHECKPOINT", "estimated_bytes": video_spans + silent_concat + atomic_duplicate + METADATA_BYTES,
         "retained_components": ["visual_span_intermediates", "silent_concatenated_video", "atomic_duplicate", "captions_manifests_and_checkpoints"]},
        {"stage": "FINAL_BEFORE_CLEANUP", "estimated_bytes": pre_contingency,
         "retained_components": [item["component"] for item in components] + ["atomic_duplicate"]},
        {"stage": "CONTINGENCY_ENVELOPE", "estimated_bytes": peak,
         "retained_components": ["FINAL_BEFORE_CLEANUP", "filesystem_and_encoder_contingency"]},
    ]
    return {
        "recipe_id": RECIPE_ID,
        "estimate_id": ESTIMATE_ID,
        "classification": RECIPE_CLASSIFICATION,
        "video": {"width": 1920, "height": 1080, "fps_numerator": 30, "fps_denominator": 1,
                  "codec_intent": "libx264-crf18",
                  "working_bitrate_accounting_assumption_bps": INTERMEDIATE_VIDEO_BITRATE_BPS,
                  "final_video_bitrate_accounting_assumption_bps": FINAL_VIDEO_BITRATE_BPS},
        "audio": {"timeline_sample_rate": RATE, "mix_sample_rate": 48000, "channels": 2,
                  "sample_width_bytes": 2, "final_codec": "aac", "final_audio_bitrate_bps": FINAL_AUDIO_BITRATE_BPS,
                  "continuous_eq_compression": True, "per_take_eq_restart": False},
        "retention": {"large_artifacts_confined_to_generation_namespace": True,
                      "intermediates_retained_until_final_checkpoint": True,
                      "one_largest_atomic_duplicate_reserved": True},
        "duration": {"planned_total_samples": samples, "planned_total_frames": frames,
                     "planned_duration_ms": samples // 24},
        "storage_components": components,
        "stage_peaks": stage_peaks,
        "retained_component_bytes": retained,
        "atomic_duplicate_bytes": atomic_duplicate,
        "contingency_percent": 25,
        "contingency_bytes": contingency,
        "estimated_peak_new_bytes": peak,
        "minimum_post_render_free_bytes": MINIMUM_POST_RENDER_HEADROOM_BYTES,
        "required_free_bytes": peak + MINIMUM_POST_RENDER_HEADROOM_BYTES,
    }


def _stage_a(root: Path, timeline_binding: dict[str, Any], arguments_binding: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    timeline, timeline_path = _load_pin(root, timeline_binding, TIMELINES)
    arguments, arguments_path = _load_pin(root, arguments_binding, ARGUMENTS)
    _validate(arguments, ADMISSION_SCHEMA)
    if arguments.get("document_type") != "PHASE6_AV_RAW_ARGUMENTS":
        raise AVCapacityError("raw-arguments document type differs")
    expected_arguments_id = "phase6-av-arguments-" + canonical_sha(
        {key: item for key, item in arguments.items() if key != "arguments_id"}
    ).split(":", 1)[1][:24]
    if arguments.get("arguments_id") != expected_arguments_id or arguments_path.name != f"{expected_arguments_id}.json":
        raise AVCapacityError("raw-arguments identity differs")
    if timeline_path.name != f"{timeline.get('timeline_id')}.json":
        raise AVCapacityError("timeline immutable filename differs")
    args = arguments["arguments"]
    try:
        verified = verify_phase6_av_timeline(
            root, timeline, args["source_bindings"], args["pause_decisions"], args["render_spans"],
            args["visual_events"], args["caption_cues"], args["temporal_evidence_bindings"],
            temporal_policy_binding=args["temporal_policy_binding"], require_complete=True,
        )
    except Exception as exc:
        raise AVCapacityError(f"complete Stage-A timeline required before capacity probes: {type(exc).__name__}:{exc}") from exc
    if (
        verified.get("derived_take_plan") is None or verified.get("blockers") != []
        or any(value is not False for value in (verified.get("authority") or {}).values())
        or arguments.get("channel_id") != verified.get("channel_id")
        or arguments.get("video_id") != verified.get("video_id")
        or arguments.get("protocol_id") != verified.get("protocol_id")
    ):
        raise AVCapacityError("Stage-A timeline lacks complete non-authoritative invariants")
    return verified, arguments


def _stage_a_evidence_mode(verified: dict[str, Any]) -> str:
    """Derive evidence class from verified Stage A, never from a caller label."""
    assessment = verified.get("temporal_evidence_assessment")
    if not isinstance(assessment, dict):
        return "FIXTURE"
    live = (
        assessment.get("all_required_evidence_live") is True
        and assessment.get("fixture_evidence_present") is False
        and assessment.get("evidence_classes") == ["LIVE"]
    )
    return "LIVE" if live else "FIXTURE"


def _effective_evidence(
    verified: dict[str, Any], arguments: dict[str, Any], probe_overrides: list[str]
) -> tuple[str, dict[str, Any]]:
    stage_a_mode = _stage_a_evidence_mode(verified)
    effective = "LIVE" if stage_a_mode == "LIVE" and not probe_overrides else "FIXTURE"
    return effective, {
        "stage_a_verified_mode": stage_a_mode,
        "raw_arguments_claim_ignored": arguments.get("evidence_mode"),
        "probe_mode": "DEFAULT_LOCAL" if not probe_overrides else "CALLER_OVERRIDES_FIXTURE_ONLY",
        "probe_overrides": sorted(probe_overrides),
    }


def _tool_records(
    ffmpeg_path: str | Path, ffprobe_path: str | Path,
    command_runner: Callable[..., Any],
) -> list[dict[str, Any]]:
    records = []
    for role, executable in (("FFMPEG", ffmpeg_path), ("FFPROBE", ffprobe_path)):
        base = _tool_check(role.lower(), executable, command_runner)
        path = Path(base["path"])
        digest = _sha(path) if path.is_file() else None
        codecs: list[str] = []
        capability_error = base["error"]
        if role == "FFMPEG" and base["status"] == "PASS":
            try:
                result = command_runner(
                    [str(path), "-hide_banner", "-encoders"], capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=20,
                )
                output = str(getattr(result, "stdout", "") or "") + str(getattr(result, "stderr", "") or "")
                # `ffmpeg -encoders` emits one encoder per row as
                # ``FLAGS NAME DESCRIPTION``.  Exact token parsing prevents a
                # banner/description/near-collision such as ``libx264rgb``
                # from satisfying the executable capability contract.
                encoder_names = {
                    match.group(1)
                    for line in output.splitlines()
                    if (match := re.match(r"^\s*[VAS][A-Z\.]{5}\s+(\S+)\s+", line))
                }
                codecs = sorted({"libx264", "aac", "pcm_s16le"} & encoder_names)
                if int(getattr(result, "returncode", 1)) != 0 or codecs != ["aac", "libx264", "pcm_s16le"]:
                    capability_error = "REQUIRED_ENCODERS_UNAVAILABLE"
            except Exception as exc:
                capability_error = f"{type(exc).__name__}:{exc}"
        passed = bool(base["status"] == "PASS" and digest and (role == "FFPROBE" or not capability_error))
        records.append({
            "role": role, "path": str(path), "sha256": digest,
            "version": base["version"], "required_codecs": codecs,
            "status": "PASS" if passed else "FAIL", "error": None if passed else capability_error,
        })
    return records


def _file_record(file_id: str, role: str, path: Path, expected: str, *, pcm: dict[str, Any] | None = None) -> dict[str, Any]:
    status, error, size, observed = "FAIL", None, None, None
    try:
        path = path.resolve(strict=True)
        raw = path.read_bytes()
        size, observed = len(raw), bytes_sha(raw)
        if observed != expected or size <= 0:
            raise ValueError("CONTENT_HASH_OR_SIZE_MISMATCH")
        if pcm is not None:
            measured = inspect_pcm(raw)
            for key in ("frame_count", "sample_rate", "channels", "sample_width_bytes", "pcm_sha256", "sha256"):
                if measured[key] != pcm[key]:
                    raise ValueError(f"PCM_{key.upper()}_MISMATCH")
        status = "PASS"
    except Exception as exc:
        error = f"{type(exc).__name__}:{exc}"
    return {"file_id": file_id, "role": role, "path": str(path.resolve()),
            "expected_sha256": expected, "observed_sha256": observed,
            "size_bytes": size, "status": status, "error": error}


def _required_files(root: Path, timeline: dict[str, Any], arguments: dict[str, Any], font_path: Path) -> list[dict[str, Any]]:
    inventory_binding = arguments["arguments"]["source_bindings"]["inventory"]
    inventory_path = _resolve_bound(root, inventory_binding["path"])
    if _sha(inventory_path) != inventory_binding["sha256"]:
        raise AVCapacityError("voice inventory hash changed")
    inventory = _json(inventory_path.read_bytes())
    voice = inventory["voice_contract"]
    records = [
        _file_record("kokoro-model", "MODEL", _resolve_bound(root, voice["model"]), voice["model_hash"]),
        _file_record("kokoro-voices", "MODEL", _resolve_bound(root, "models/kokoro/voices-v1.0.bin"), voice["voices_hash"]),
    ]
    try:
        ImageFont.truetype(str(font_path), 54)
        font_error = None
    except Exception as exc:
        font_error = f"{type(exc).__name__}:{exc}"
    font_record = _file_record("render-font", "FONT", font_path, _sha(font_path) if font_path.is_file() else "sha256:" + "0" * 64)
    if font_error is not None:
        font_record.update(status="FAIL", error=font_error)
    records.append(font_record)
    for unit in timeline["units"]:
        records.append(_file_record(unit["unit_id"], "NARRATION_PCM", _resolve_bound(root, unit["path"]),
                                    unit["sha256"], pcm=unit))
    visual: dict[tuple[str, str], None] = {}
    for span in timeline["render_spans"]:
        binding = span["asset_binding"]
        visual[(binding["path"], binding["sha256"])] = None
    for ordinal, (path, digest) in enumerate(sorted(visual), 1):
        records.append(_file_record(f"visual-source-{ordinal:03d}", "VISUAL_SOURCE",
                                    _resolve_bound(root, path), digest))
    return records


def _volume_records(
    root: Path, recipe: dict[str, Any],
    disk_usage_provider: Callable[[str | os.PathLike[str]], Any],
) -> tuple[list[dict[str, Any]], bool]:
    output, temporary = (root / OUTPUT_DIR).resolve(), (root / TEMP_DIR).resolve()
    same = _volume_key(output) == _volume_key(temporary)
    records = []
    for role, path in (("GENERATION_OUTPUT", output), ("LOCAL_TEMP", temporary)):
        required = recipe["required_free_bytes"]
        try:
            usage = disk_usage_provider(path)
            total, free = int(usage.total), int(usage.free)
            if total <= 0 or free < 0 or free > total:
                raise ValueError("invalid disk-usage observation")
            records.append({"role": role, "path": str(path), "volume_key": _volume_key(path),
                            "total_bytes": total, "free_bytes": free, "required_free_bytes": required,
                            "projected_post_peak_free_bytes": free - recipe["estimated_peak_new_bytes"],
                            "status": "PASS" if free >= required else "FAIL", "error": None})
        except Exception as exc:
            records.append({"role": role, "path": str(path), "volume_key": _volume_key(path),
                            "total_bytes": 0, "free_bytes": 0, "required_free_bytes": required,
                            "projected_post_peak_free_bytes": -recipe["estimated_peak_new_bytes"],
                            "status": "FAIL", "error": f"{type(exc).__name__}:{exc}"})
    return records, same


def _strict_writable_check(role: str, path: Path) -> dict[str, Any]:
    """Probe write/read/delete and fail when cleanup itself is not proved."""
    status, error = "FAIL", None
    probe: Path | None = None
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / f".capacity-probe-{os.getpid()}-{uuid.uuid4().hex}.tmp"
        payload = b"heroverse-av-capacity-probe"
        probe.write_bytes(payload)
        if probe.read_bytes() != payload:
            raise OSError("writability probe content mismatch")
        try:
            probe.unlink()
        except OSError as exc:
            raise OSError(f"writability probe cleanup failed: {type(exc).__name__}:{exc}") from exc
        if probe.exists():
            raise OSError("writability probe cleanup was not durable")
        status = "PASS"
    except Exception as exc:
        error = f"{type(exc).__name__}:{exc}"
    finally:
        if probe is not None and probe.exists():
            try:
                probe.unlink()
            except OSError:
                # The recorded FAIL above remains visible; a second cleanup
                # attempt must never turn an unproved delete into PASS.
                pass
    return {"role": role, "path": str(path.resolve()), "status": status, "error": error}


def _implementation_bindings() -> list[dict[str, Any]]:
    result = []
    for relative in (SCHEMA, "hero_engine/phase6_av_capacity.py", "hero_engine/production_capacity.py", "hero_engine/atomic_io.py"):
        path = ROOT / relative
        result.append({"path": relative, "sha256": _sha(path), "size_bytes": path.stat().st_size})
    return result


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_text(encoding="utf-8") != payload:
            raise AVCapacityError("immutable capacity receipt collision")
        return
    staged = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.stage")
    atomic_write_utf8(staged, payload)
    try:
        try:
            os.link(staged, path)
        except FileExistsError:
            if path.read_text(encoding="utf-8") != payload:
                raise AVCapacityError("immutable capacity receipt collision")
    finally:
        staged.unlink(missing_ok=True)


def run_phase6_av_capacity_preflight(
    root: Path,
    *,
    timeline_binding: dict[str, Any],
    arguments_binding: dict[str, Any],
    now: datetime | None = None,
    disk_usage_provider: Callable[[str | os.PathLike[str]], Any] | None = None,
    command_runner: Callable[..., Any] | None = None,
    ffmpeg_path: str | Path | None = None,
    ffprobe_path: str | Path | None = None,
    font_provider: Callable[[], Path] | None = None,
) -> dict[str, Any]:
    """Run bounded local probes and persist one immutable capacity observation."""
    root = Path(root).resolve(strict=True)
    probe_overrides = sorted(name for name, supplied in (
        ("NOW", now is not None),
        ("DISK_USAGE_PROVIDER", disk_usage_provider is not None),
        ("COMMAND_RUNNER", command_runner is not None),
        ("FFMPEG_PATH", ffmpeg_path is not None),
        ("FFPROBE_PATH", ffprobe_path is not None),
        ("FONT_PROVIDER", font_provider is not None),
    ) if supplied)
    disk_usage_provider = disk_usage_provider or shutil.disk_usage
    command_runner = command_runner or subprocess.run
    ffmpeg_path = FFMPEG if ffmpeg_path is None else ffmpeg_path
    ffprobe_path = FFPROBE if ffprobe_path is None else ffprobe_path
    font_provider = _font if font_provider is None else font_provider
    # Stage A is recomposed before tool, directory, disk, or receipt effects.
    timeline, arguments = _stage_a(root, timeline_binding, arguments_binding)
    evidence_mode, evidence_basis = _effective_evidence(timeline, arguments, probe_overrides)
    recipe = build_phase6_av_capacity_recipe(timeline)
    tools = _tool_records(ffmpeg_path, ffprobe_path, command_runner)
    try:
        font_path = Path(font_provider()).resolve(strict=True)
    except Exception as exc:
        font_path = root / "__missing_render_font__"
        font_error = f"{type(exc).__name__}:{exc}"
    else:
        font_error = None
    # A missing/invalid font is a capacity blocker, not a reason to discard the
    # independently observable model/WAV/visual inventory from the receipt.
    # `_required_files` records the font failure and continues the remaining
    # hash/PCM observations, keeping a BLOCKED receipt schema-complete.
    files = _required_files(root, timeline, arguments, font_path)
    if font_error is not None:
        font_rows = [row for row in files if row["file_id"] == "render-font"]
        if len(font_rows) != 1:
            raise AVCapacityError("capacity inventory did not produce exactly one render-font row")
        font_rows[0].update(status="FAIL", error=font_error)
    writable = [
        _strict_writable_check("GENERATION_OUTPUT", root / OUTPUT_DIR),
        _strict_writable_check("LOCAL_TEMP", root / TEMP_DIR),
    ]
    volumes, same_volume = _volume_records(root, recipe, disk_usage_provider)
    checks = [
        {"check_id": "AVC-STAGE-A", "status": "PASS", "detail": "real verifier require_complete=True"},
        {"check_id": "AVC-RECIPE", "status": "PASS", "detail": f"PROJECTED_STORAGE_ARITHMETIC_ONLY:{RECIPE_ID}"},
        {"check_id": "AVC-TOOLS", "status": "PASS" if all(row["status"] == "PASS" for row in tools) else "FAIL", "detail": "version, hash and required encoders"},
        {"check_id": "AVC-FILES", "status": "PASS" if files and all(row["status"] == "PASS" for row in files) else "FAIL", "detail": "models, font, 51 PCM and visual bytes"},
        {"check_id": "AVC-WRITABLE", "status": "PASS" if all(row["status"] == "PASS" for row in writable) else "FAIL", "detail": "write/read/delete probe"},
        {"check_id": "AVC-DISK", "status": "PASS" if all(row["status"] == "PASS" for row in volumes) else "FAIL", "detail": "derived peak plus 5 GiB"},
        {"check_id": "AVC-TTL", "status": "PASS", "detail": f"fixed maximum {TTL_SECONDS}s"},
        {"check_id": "AVC-EXECUTABLE-RECIPE", "status": "FAIL", "detail": RECIPE_CLASSIFICATION},
    ]
    blockers = [row["check_id"] for row in checks if row["status"] != "PASS"]
    status = "BLOCKED"
    # TTL starts after every local probe has finished.  A supplied clock value
    # is a fixture override and was already recorded above.
    observed_at = _aware(now, "now") if now is not None else _utc_now()
    timeline_ref = {**timeline_binding, "timeline_id": timeline["timeline_id"]}
    arguments_ref = {**arguments_binding, "arguments_id": arguments["arguments_id"]}
    value = {
        "schema_version": SCHEMA_VERSION, "capacity_version": VERSION,
        "receipt_id": "phase6-av-capacity-pending", "evidence_mode": evidence_mode,
        "evidence_basis": evidence_basis,
        "status": status, "channel_id": timeline["channel_id"], "video_id": timeline["video_id"],
        "protocol_id": timeline["protocol_id"], "timeline": timeline_ref,
        "raw_arguments": arguments_ref, "recipe": recipe, "tools": tools,
        "required_files": files, "writable_paths": writable, "volumes": volumes,
        "same_output_and_temp_volume": same_volume, "checks": checks,
        "blocking_reasons": blockers, "policy": {
            "ttl_seconds": TTL_SECONDS,
            "minimum_post_render_free_bytes": MINIMUM_POST_RENDER_HEADROOM_BYTES,
            "reobserve_before_use": True,
        },
        "execution_readiness": {
            "status": RECIPE_CLASSIFICATION,
            "command_recipe_bound": False,
            "visual_source_decode_and_frame_count_verified": False,
            "blocking_capabilities": list(EXECUTABLE_RECIPE_BLOCKERS),
        },
        "implementation_bindings": _implementation_bindings(),
        "observed_at": observed_at.isoformat().replace("+00:00", "Z"),
        "valid_until": (observed_at + timedelta(seconds=TTL_SECONDS)).isoformat().replace("+00:00", "Z"),
        "authority": copy.deepcopy(FALSE_AUTHORITY), "publication_authorized": False,
        "technical_cost_brl": 0,
    }
    value["receipt_id"] = _identity(value)
    _validate(value)
    receipt_path = root / RECEIPTS / f"{value['receipt_id']}.json"
    _write_immutable(receipt_path, value)
    expected = _sha(receipt_path)
    # Re-open structure/identity without duplicating all probes in the producer.
    verify_phase6_av_capacity_receipt(
        root, receipt_path=receipt_path, expected_receipt_id=value["receipt_id"],
        expected_sha256=expected, now=observed_at, require_live=False,
        reobserve=False, disk_usage_provider=disk_usage_provider,
        command_runner=command_runner,
    )
    return value


def verify_phase6_av_capacity_receipt(
    root: Path,
    *,
    receipt_path: str | Path,
    expected_receipt_id: str,
    expected_sha256: str,
    now: datetime,
    require_live: bool = True,
    reobserve: bool = True,
    disk_usage_provider: Callable[[str | os.PathLike[str]], Any] = shutil.disk_usage,
    command_runner: Callable[..., Any] = subprocess.run,
) -> dict[str, Any]:
    """Recompose receipt and optionally repeat every mutable local observation."""
    if require_live and not reobserve:
        raise AVCapacityError("LIVE capacity verification requires full reobservation")
    root, current = Path(root).resolve(strict=True), _aware(now, "now")
    raw_path = Path(receipt_path)
    path = raw_path if raw_path.is_absolute() else root / raw_path
    path = path.resolve(strict=True)
    if path.parent != (root / RECEIPTS).resolve() or path.name != f"{expected_receipt_id}.json":
        raise AVCapacityError("capacity receipt escaped its immutable directory")
    raw = path.read_bytes()
    if bytes_sha(raw) != expected_sha256:
        raise AVCapacityError("capacity receipt hash differs")
    value = _json(raw)
    _validate(value)
    if value["receipt_id"] != expected_receipt_id or value["receipt_id"] != _identity(value):
        raise AVCapacityError("capacity receipt canonical identity differs")
    observed, expiry = _aware(value["observed_at"], "observed_at"), _aware(value["valid_until"], "valid_until")
    if expiry - observed != timedelta(seconds=TTL_SECONDS) or current < observed or current >= expiry:
        raise AVCapacityError("capacity receipt is future-dated, stale, or exceeds fixed TTL")
    if value["policy"] != {"ttl_seconds": TTL_SECONDS,
                            "minimum_post_render_free_bytes": MINIMUM_POST_RENDER_HEADROOM_BYTES,
                            "reobserve_before_use": True}:
        raise AVCapacityError("capacity policy differs")
    if value["authority"] != FALSE_AUTHORITY or value["publication_authorized"] or value["technical_cost_brl"] != 0:
        raise AVCapacityError("capacity receipt attempted to grant authority or cost")
    expected_readiness = {
        "status": RECIPE_CLASSIFICATION,
        "command_recipe_bound": False,
        "visual_source_decode_and_frame_count_verified": False,
        "blocking_capabilities": list(EXECUTABLE_RECIPE_BLOCKERS),
    }
    if value["execution_readiness"] != expected_readiness:
        raise AVCapacityError("capacity executable-recipe blockers differ")
    if sorted(value["blocking_reasons"]) != sorted(row["check_id"] for row in value["checks"] if row["status"] != "PASS"):
        raise AVCapacityError("capacity blockers do not match checks")
    if require_live and (value["evidence_mode"] != "LIVE" or value["status"] != "PASS" or value["blocking_reasons"]):
        raise AVCapacityError("capacity receipt is not a LIVE PASS")
    if value["evidence_mode"] == "FIXTURE" and value["status"] == "PASS":
        raise AVCapacityError("fixture receipt falsely claims LIVE PASS")

    timeline_binding = {key: value["timeline"][key] for key in ("path", "sha256", "size_bytes")}
    arguments_binding = {key: value["raw_arguments"][key] for key in ("path", "sha256", "size_bytes")}
    timeline, arguments = _stage_a(root, timeline_binding, arguments_binding)
    if timeline["timeline_id"] != value["timeline"]["timeline_id"] or arguments["arguments_id"] != value["raw_arguments"]["arguments_id"]:
        raise AVCapacityError("capacity receipt Stage-A identities differ")
    recomputed = build_phase6_av_capacity_recipe(timeline)
    if canonical_sha(recomputed) != canonical_sha(value["recipe"]):
        raise AVCapacityError("capacity recipe/peak does not recompose")
    if value["channel_id"] != timeline["channel_id"] or value["video_id"] != timeline["video_id"] or value["protocol_id"] != timeline["protocol_id"]:
        raise AVCapacityError("capacity receipt belongs to another timeline identity")
    recorded_overrides = value["evidence_basis"]["probe_overrides"]
    expected_mode, expected_basis = _effective_evidence(timeline, arguments, recorded_overrides)
    if value["evidence_mode"] != expected_mode or value["evidence_basis"] != expected_basis:
        raise AVCapacityError("capacity evidence derivation differs")
    for binding in value["implementation_bindings"]:
        code_path = _resolve_bound(root, binding["path"])
        if _sha(code_path) != binding["sha256"] or code_path.stat().st_size != binding["size_bytes"]:
            raise AVCapacityError("capacity implementation binding changed")

    reobserved: dict[str, Any] = {"performed": False, "tools": [], "required_files": [],
                                 "writable_paths": [], "volumes": []}
    if reobserve:
        tools = _tool_records(value["tools"][0]["path"], value["tools"][1]["path"], command_runner)
        if canonical_sha(tools) != canonical_sha(value["tools"]):
            raise AVCapacityError("tool version/hash/capability reobservation differs")
        font_rows = [row for row in value["required_files"] if row["role"] == "FONT"]
        if len(font_rows) != 1:
            raise AVCapacityError("exactly one render font is required")
        files = _required_files(root, timeline, arguments, Path(font_rows[0]["path"]))
        if canonical_sha(files) != canonical_sha(value["required_files"]):
            raise AVCapacityError("required file reobservation differs")
        writable = [_strict_writable_check(row["role"], Path(row["path"])) for row in value["writable_paths"]]
        if any(row["status"] != "PASS" for row in writable):
            raise AVCapacityError("a capacity directory is no longer writable")
        volumes, same = _volume_records(root, recomputed, disk_usage_provider)
        if same != value["same_output_and_temp_volume"] or any(row["status"] != "PASS" for row in volumes):
            raise AVCapacityError("current volume capacity no longer preserves peak plus 5 GiB")
        if [(row["role"], row["path"], row["volume_key"], row["required_free_bytes"]) for row in volumes] != [
            (row["role"], row["path"], row["volume_key"], row["required_free_bytes"]) for row in value["volumes"]
        ]:
            raise AVCapacityError("volume identity or required peak differs")
        reobserved = {"performed": True, "tools": tools, "required_files": files,
                      "writable_paths": writable, "volumes": volumes}
    return {"receipt": value, "receipt_path": _relative(root, path),
            "receipt_sha256": expected_sha256, "reobserved_at": current.isoformat().replace("+00:00", "Z"),
            "reobservation": reobserved, "authority": copy.deepcopy(FALSE_AUTHORITY)}


verify = verify_phase6_av_capacity_receipt
