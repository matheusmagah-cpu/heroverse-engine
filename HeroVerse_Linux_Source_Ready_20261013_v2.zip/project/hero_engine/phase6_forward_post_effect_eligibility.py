"""Authenticated eligibility for forward post-effect media adoption.

This module is intentionally a proof producer, not a queue mutator.  It lets
controlled maintenance prove that a completed historical media job and the
existing current pre-effect job describe the same creative unit.  Rendering,
publication and queue authority remain outside this boundary.
"""
from __future__ import annotations

import hashlib
import json
import os
import uuid
from pathlib import Path
from typing import Any

from .phase6_current_production_inputs import current_production_input_contract
from .phase6_media_authority import _input_reference, _load_historical_input_envelope, _media_unit
from .phase6_visual_preflight import require_visual_contract
from .queue_phase6 import TransactionalQueue


ELIGIBILITY_ROOT = Path("output/operations/phase6/runtime/post-effect-visual-eligibility-receipts")
CLASS = "FORWARD_POST_EFFECT_CURRENT_INPUT_REMEDIATION"
POLICY = "phase6-forward-post-effect-current-input-eligibility-v1"


def _committed_ancestry(job_id: str, edges: list) -> tuple[str, frozenset[str]]:
    """Locate a candidate in the captured graph; the queue authenticates it below."""
    root_id = job_id
    seen = {root_id}
    while True:
        inbound = [edge for edge in edges if isinstance(edge, dict)
                   and edge.get("authoritative_job_id") == root_id]
        if len(inbound) > 1:
            raise PermissionError("forward eligibility authority graph has an inbound fork")
        if not inbound:
            return root_id, frozenset(seen)
        edge = inbound[0]
        if edge.get("state") != "COMMITTED" or not isinstance(edge.get("superseded_job_id"), str):
            raise PermissionError("forward eligibility authority graph is not committed")
        root_id = edge["superseded_job_id"]
        if root_id in seen:
            raise PermissionError("forward eligibility authority graph has a cycle")
        seen.add(root_id)


def derive_forward_post_effect_current_plan(root: Path) -> dict[str, Any]:
    """Derive the sole zero-effect forward transition from current bytes.

    This is read-only.  It intentionally refuses ambiguous historical tails
    instead of accepting IDs supplied by an application caller.
    """
    project_root = Path(root).resolve(strict=True)
    current_contract = current_production_input_contract(project_root)
    current_ref = _input_reference(project_root, current_contract["receipt_id"])
    current_receipt, current_work, current_evidence = _load_historical_input_envelope(
        project_root, current_contract["receipt_id"]
    )
    media_unit = _media_unit(receipt=current_receipt, work_order=current_work,
                             evidence=current_evidence)
    # The derivation runs inside the paused application's protected capture.
    # It is evidence preparation, never a schema initializer: opening the
    # live queue in the default writable mode would create WAL/SHM sidecars
    # after the capture and falsely look like a foreign database mutation.
    queue = TransactionalQueue(project_root, read_only=True, immutable=True)
    snapshot = queue.snapshot()
    jobs = snapshot["jobs"]
    # A paused manager may legitimately compile a new, fully inert production
    # receipt before it is allowed to enqueue media work.  Treat that exact
    # absence as an explicit preimage, not as an invitation to choose a job
    # later.  The paused application can then create precisely the deterministic
    # command inside its one protected queue transaction.  Any *other* current
    # job shape remains a hard block.
    expected_key = f"{current_contract['receipt_id']}:synthesize-render-standard-v2"
    expected_payload = {
        "input_receipt_id": current_contract["receipt_id"],
        "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
    }
    expected_job_id = "job-" + hashlib.sha256(expected_key.encode("utf-8")).hexdigest()[:24]
    bound_current = [
        job for job in jobs
        if job.get("payload", {}).get("input_receipt_id") == current_contract["receipt_id"]
    ]
    if len(bound_current) > 1:
        raise PermissionError("forward eligibility current media job is ambiguous")
    if bound_current:
        successor = bound_current[0]
        completed = (successor.get("state") == "SUCCEEDED"
                     and type(successor.get("attempt_count")) is int
                     and type(successor.get("max_attempts")) is int
                     and 0 < successor["attempt_count"] <= successor["max_attempts"]
                     and successor.get("last_error") is None
                     and isinstance(successor.get("checkpoint"), dict)
                     and bool(successor["checkpoint"]))
        untouched = (
            successor.get("job_id") == expected_job_id
            and successor.get("idempotency_key") == expected_key
            and successor.get("operation_id") == media_unit["operation_id"]
            and successor.get("channel_id") == media_unit["channel_id"]
            and successor.get("task_type") == media_unit["task_type"]
            and successor.get("payload") == expected_payload
            and ((successor.get("state") == "PENDING" and successor.get("attempt_count") == 0)
                 or (successor.get("state") == "RETRY_WAIT"
                     and type(successor.get("attempt_count")) is int
                     and successor["attempt_count"] > 0)
                 or completed)
            and successor.get("lease_owner") is None
            and successor.get("lease_until") is None
            and (successor.get("checkpoint") == {} or completed)
        )
        if not untouched:
            raise PermissionError("forward eligibility current media job is not untouched")
        successor_preimage = {
            "exists": True,
            "job_id": expected_job_id,
            "idempotency_key": expected_key,
            "payload_sha256": _sha(_canonical(expected_payload).encode("utf-8")),
            "checkpoint_sha256": _sha(_canonical(successor["checkpoint"]).encode("utf-8")),
        }
    else:
        successor = {
            "job_id": expected_job_id,
            "idempotency_key": expected_key,
            "operation_id": media_unit["operation_id"],
            "channel_id": media_unit["channel_id"],
            "task_type": media_unit["task_type"],
            "payload": expected_payload,
            "state": "PENDING",
            "attempt_count": 0,
            "lease_owner": None,
            "lease_until": None,
            "checkpoint": {},
        }
        successor_preimage = {
            "exists": False,
            "job_id": expected_job_id,
            "idempotency_key": expected_key,
            "payload_sha256": _sha(_canonical(expected_payload).encode("utf-8")),
            "checkpoint_sha256": _sha(_canonical({}).encode("utf-8")),
        }
    historical = []
    for job in jobs:
        receipt_id = str(job.get("payload", {}).get("input_receipt_id") or "")
        if not receipt_id or receipt_id == current_contract["receipt_id"] or job.get("state") != "SUCCEEDED":
            continue
        if job.get("lease_owner") is not None or job.get("lease_until") is not None or not job.get("checkpoint"):
            continue
        receipt, work, evidence = _load_historical_input_envelope(project_root, receipt_id)
        if _media_unit(receipt=receipt, work_order=work, evidence=evidence) == media_unit:
            historical.append((job, _input_reference(project_root, receipt_id)))
    edges = snapshot.get("media_job_supersessions")
    if not isinstance(edges, list):
        raise PermissionError("forward eligibility supersession graph is unavailable")
    # Completed ancestors are retained evidence, not competing authorities.
    # Select the unique maximal completed node of ONE committed lineage, never
    # by time/ID/list order. Unrelated terminal jobs remain ambiguous. The real
    # resolver then authenticates every receipt, job binding and fork from the
    # canonical root before this selection can authorize even a journal.
    ancestry = {job["job_id"]: _committed_ancestry(job["job_id"], edges)
                for job, _reference in historical}
    terminal = [(job, reference) for job, reference in historical
                if not any(job["job_id"] in chain
                           for other_id, (_root_id, chain) in ancestry.items()
                           if other_id != job["job_id"])]
    if len({root_id for root_id, _chain in ancestry.values()}) != 1 or len(terminal) != 1:
        raise PermissionError("forward eligibility requires one exact terminal historical media job")
    predecessor, historical_ref = terminal[0]
    root_id, ancestors = ancestry[predecessor["job_id"]]
    if not set(ancestry).issubset(ancestors):
        raise PermissionError("forward eligibility requires one exact terminal historical media job")
    resolution = queue.resolve_media_job_authority(
        root_id, expected_media_unit_key=media_unit["media_unit_key"],
        expected_operation_id=media_unit["operation_id"],
        expected_channel_id=media_unit["channel_id"],
        expected_task_type=media_unit["task_type"], require_canonical_root=True,
    )
    # A prior interrupted paused application may have committed precisely this
    # queue edge before its derived-view finalization failed.  Re-opening that
    # exact, committed predecessor->current edge is an idempotent replay; it
    # is not permission to select some other tail or successor.
    exact_forward = [edge for edge in edges if isinstance(edge, dict)
                     and edge.get("superseded_job_id") == predecessor["job_id"]
                     and edge.get("authoritative_job_id") == successor["job_id"]
                     and edge.get("state") == "COMMITTED"]
    if len(exact_forward) > 1:
        raise PermissionError("forward eligibility exact replay is ambiguous")
    # A prior maintenance run can leave the *canonical* authority at an
    # untouched pending command.  That is not an error to be bypassed by a
    # historical SUCCEEDED job: it is the one command that must be rebased.
    # The queue's normal reconciliation still performs the actual supersession
    # and independently recomputes its remediation proof.  Here we merely
    # freeze the exact, inert tail it is allowed to consume.
    pending_tail_rebase = False
    # A completed-predecessor edge is just as immutable as an already rebased
    # pending-tail edge. Both must enter the read-only replay branch, including
    # when the current successor has not attempted work yet.
    committed_forward_replay = bool(exact_forward)
    canonical_tail_id = str(resolution.get("authoritative_job_id") or "")
    if not exact_forward and canonical_tail_id == successor["job_id"]:
        # An interrupted paused application can have committed its *exact*
        # pending-tail -> current edge before an outer derived-view transaction
        # rolled back.  Re-open only that immutable edge.  In particular, do
        # not accept a canonical current job merely because it has the expected
        # ID: its one incoming COMMITTED edge, predecessor, media unit and
        # receipt binding must all still be independently valid.
        incoming = [edge for edge in edges if isinstance(edge, dict)
                    and edge.get("authoritative_job_id") == successor["job_id"]]
        if len(incoming) != 1 or incoming[0].get("state") != "COMMITTED":
            raise PermissionError("forward eligibility canonical authority tail diverged")
        replay_predecessor = next(
            (job for job in jobs if job.get("job_id") == incoming[0].get("superseded_job_id")),
            None,
        )
        if not isinstance(replay_predecessor, dict) or not (
            replay_predecessor.get("state") == "PENDING"
            and replay_predecessor.get("attempt_count") == 0
            and replay_predecessor.get("lease_owner") is None
            and replay_predecessor.get("lease_until") is None
            and replay_predecessor.get("checkpoint") == {}
            and replay_predecessor.get("operation_id") == media_unit["operation_id"]
            and replay_predecessor.get("channel_id") == media_unit["channel_id"]
            and replay_predecessor.get("task_type") == media_unit["task_type"]
            and replay_predecessor.get("payload", {}).get("action")
            == "SYNTHESIZE_AND_RENDER_VIDEO_2"
        ):
            raise PermissionError("forward eligibility committed replay predecessor is not inert")
        replay_receipt_id = str(replay_predecessor.get("payload", {}).get("input_receipt_id") or "")
        replay_receipt, replay_work, replay_evidence = _load_historical_input_envelope(
            project_root, replay_receipt_id
        )
        if _media_unit(receipt=replay_receipt, work_order=replay_work,
                       evidence=replay_evidence) != media_unit:
            raise PermissionError("forward eligibility committed replay changes media unit")
        predecessor = replay_predecessor
        historical_ref = _input_reference(project_root, replay_receipt_id)
        exact_forward = incoming
        committed_forward_replay = True
    if not exact_forward and canonical_tail_id != predecessor["job_id"]:
        tail = next((job for job in jobs if job.get("job_id") == canonical_tail_id), None)
        if not isinstance(tail, dict) or not (
            resolution.get("authority_state") == "PENDING"
            and tail.get("state") == "PENDING"
            and tail.get("attempt_count") == 0
            and tail.get("lease_owner") is None
            and tail.get("lease_until") is None
            and tail.get("checkpoint") == {}
            and tail.get("operation_id") == media_unit["operation_id"]
            and tail.get("channel_id") == media_unit["channel_id"]
            and tail.get("task_type") == media_unit["task_type"]
            and tail.get("payload", {}).get("action")
            == "SYNTHESIZE_AND_RENDER_VIDEO_2"
        ):
            raise PermissionError("forward eligibility canonical pending authority tail is not inert")
        tail_receipt_id = str(tail.get("payload", {}).get("input_receipt_id") or "")
        tail_receipt, tail_work, tail_evidence = _load_historical_input_envelope(
            project_root, tail_receipt_id
        )
        if _media_unit(receipt=tail_receipt, work_order=tail_work, evidence=tail_evidence) != media_unit:
            raise PermissionError("forward eligibility canonical pending authority tail changes media unit")
        predecessor = tail
        historical_ref = _input_reference(project_root, tail_receipt_id)
        pending_tail_rebase = True
        exact_forward = [edge for edge in edges if isinstance(edge, dict)
                         and edge.get("superseded_job_id") == predecessor["job_id"]
                         and edge.get("authoritative_job_id") == successor["job_id"]
                         and edge.get("state") == "COMMITTED"]
        if len(exact_forward) > 1:
            raise PermissionError("forward eligibility exact pending-tail replay is ambiguous")
    expected_authority = successor["job_id"] if exact_forward else predecessor["job_id"]
    progressed_replay = successor.get("state") in {"RETRY_WAIT", "SUCCEEDED"}
    if progressed_replay and not committed_forward_replay:
        raise PermissionError("forward eligibility progressed successor has no committed replay")
    expected_state = successor["state"] if exact_forward else ("PENDING" if pending_tail_rebase else "SUCCEEDED")
    if (resolution.get("authoritative_job_id") != expected_authority
            or resolution.get("authority_state") != expected_state
            or resolution.get("root_job", {}).get("job_id") != root_id):
        raise PermissionError("forward eligibility canonical authority tail diverged")
    plan = {"authority_root_job_id": root_id, "predecessor_job_id": predecessor["job_id"],
            "successor_job_id": successor["job_id"], "authority_root_job": resolution["root_job"], "predecessor_job": predecessor,
            "successor_job": successor, "media_unit": media_unit,
            "historical_input_receipt": historical_ref, "current_input_receipt": current_ref,
            "successor_queue_preimage": successor_preimage,
            "pending_tail_rebase": pending_tail_rebase,
            "committed_forward_replay": committed_forward_replay}
    if progressed_replay or committed_forward_replay:
        # Observe an existing authority, never re-certify it as untouched or
        # manufacture a fresh eligibility proof after an attempt. The queue
        # reader authenticates the immutable edge; this observation pins every
        # current job field so preparation/commit reject any intervening change.
        edge = queue.get_media_job_supersession(predecessor["job_id"])
        document = edge.get("receipt", {}) if isinstance(edge, dict) else {}
        eligibility_successor = successor
        if successor.get("state") == "SUCCEEDED":
            # Reopen the *historical* empty checkpoint only when the immutable
            # committed edge attests that exact preimage. Never certify a
            # completed job as a new pre-effect job or rewrite its old receipt.
            original = document.get("authoritative_job", {})
            original_state = original.get("queue_state", {})
            if not (original.get("job_id") == successor["job_id"]
                    and original.get("idempotency_key") == expected_key
                    and original.get("payload_sha256") == _sha(_canonical(expected_payload).encode("utf-8"))
                    and original.get("checkpoint_sha256") == _sha(_canonical({}).encode("utf-8"))
                    and original_state.get("state") == "PENDING"
                    and original_state.get("attempt_count") == 0
                    and original_state.get("lease_owner") is None
                    and original_state.get("lease_until") is None
                    and document.get("authoritative_input_receipt") == current_ref):
                raise PermissionError("forward eligibility completed job historical preimage diverged")
            eligibility_successor = {**successor, "checkpoint": {}}
        expected = expected_forward_post_effect_eligibility_receipt(
            authority_root_job=plan["authority_root_job"], predecessor_job=predecessor,
            successor_job=eligibility_successor, media_unit=media_unit,
            historical_input=historical_ref, current_input=current_ref)
        proof_path = project_root / expected["path"]
        if not proof_path.is_file() or _sha(proof_path.read_bytes()) != expected["sha256"]:
            raise PermissionError("forward eligibility committed receipt diverged")
        if not (edge and edge.get("state") == "COMMITTED"
                and document.get("superseded_job", {}).get("job_id") == predecessor["job_id"]
                and document.get("authoritative_job", {}).get("job_id") == successor["job_id"]
                and document.get("media_unit") == media_unit):
            raise PermissionError("forward eligibility committed edge diverged")
        plan["committed_successor_observation"] = {
            "job_sha256": _sha(_canonical(successor).encode("utf-8")),
            "edge_path": edge["receipt_path"], "edge_sha256": edge["receipt_sha256"],
        }
        if successor.get("state") == "SUCCEEDED":
            from .phase6_media import _verify_completed_media_checkpoint
            _verify_completed_media_checkpoint(project_root, successor["checkpoint"], current_receipt)
            plan["committed_successor_observation"]["eligibility_receipt"] = expected
    return plan


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _job_binding(job: dict[str, Any], *, label: str) -> None:
    if not isinstance(job, dict) or not isinstance(job.get("job_id"), str):
        raise PermissionError(f"forward eligibility {label} job is unavailable")
    if not isinstance(job.get("payload"), dict) or not isinstance(job.get("checkpoint"), dict):
        raise PermissionError(f"forward eligibility {label} job is not decoded")


def _immutable_input_binding(root: Path, supplied: dict[str, Any], *, label: str) -> dict[str, Any]:
    """Recover the one immutable receipt reference from either public shape.

    The public queue boundary deliberately passes the receipt document it has
    just reopened from its immutable path.  The planner, in contrast, carries
    the compact ``receipt_id/path/sha256`` reference.  They are not equal JSON
    objects, but they must identify the same immutable bytes.  Normalize both
    forms here instead of weakening the comparison at the queue boundary.
    """
    if not isinstance(supplied, dict) or not isinstance(supplied.get("receipt_id"), str):
        raise PermissionError(f"forward eligibility {label} input is unavailable")
    reference = _input_reference(root, supplied["receipt_id"])
    reference_keys = {"receipt_id", "path", "sha256"}
    if set(supplied) == reference_keys:
        if supplied != reference:
            raise PermissionError(f"forward eligibility {label} input reference is not exact immutable binding")
        return reference
    receipt, _work_order, _evidence = _load_historical_input_envelope(root, supplied["receipt_id"])
    if supplied != receipt:
        raise PermissionError(f"forward eligibility {label} input document is not exact immutable binding")
    return reference


def _evidence_document(
    *, authority_root_job: dict[str, Any], predecessor_job: dict[str, Any],
    successor_job: dict[str, Any], media_unit: dict[str, Any],
    historical_input: dict[str, Any], current_input: dict[str, Any],
) -> dict[str, Any]:
    seed = {
        "schema_version": "1.0.0", "policy_version": POLICY, "status": "PASS",
        "supersession_class": CLASS, "authority_root_job_id": authority_root_job["job_id"],
        "predecessor_job_id": predecessor_job["job_id"], "successor_job_id": successor_job["job_id"],
        "media_unit_key": media_unit["media_unit_key"],
        "historical_input_receipt_id": historical_input["receipt_id"],
        "current_input_receipt_id": current_input["receipt_id"],
        "predecessor_payload_sha256": _sha(_canonical(predecessor_job["payload"]).encode()),
        "predecessor_checkpoint_sha256": _sha(_canonical(predecessor_job["checkpoint"]).encode()),
        "successor_payload_sha256": _sha(_canonical(successor_job["payload"]).encode()),
        "successor_checkpoint_sha256": _sha(_canonical(successor_job["checkpoint"]).encode()),
        "publication_authorized": False, "technical_cost_brl": 0,
    }
    receipt_id = "phase6-post-effect-visual-eligibility-" + hashlib.sha256(
        _canonical(seed).encode("utf-8")
    ).hexdigest()[:24]
    return {"receipt_id": receipt_id, **seed}


def expected_forward_post_effect_eligibility_receipt(
    *, authority_root_job: dict[str, Any], predecessor_job: dict[str, Any],
    successor_job: dict[str, Any], media_unit: dict[str, Any],
    historical_input: dict[str, Any], current_input: dict[str, Any],
) -> dict[str, Any]:
    """Return the exact immutable receipt identity before any write occurs."""
    document = _evidence_document(
        authority_root_job=authority_root_job, predecessor_job=predecessor_job,
        successor_job=successor_job, media_unit=media_unit,
        historical_input=historical_input, current_input=current_input,
    )
    raw = (_canonical(document) + "\n").encode("utf-8")
    receipt_id = str(document["receipt_id"])
    return {"receipt_id": receipt_id,
            "path": (ELIGIBILITY_ROOT / f"{receipt_id}.json").as_posix(),
            "sha256": _sha(raw)}


def forward_post_effect_journal_contract(plan: dict[str, Any]) -> dict[str, Any]:
    """Freeze the only admissible forward edge before its first write.

    The paused application persists this value before materializing eligibility
    or touching the queue.  It is intentionally complete enough to distinguish
    a resumable own PREPARED edge from a foreign/stale edge after interruption.
    """
    required = {
        "authority_root_job_id", "predecessor_job_id", "successor_job_id", "authority_root_job",
        "predecessor_job", "successor_job", "media_unit",
        "historical_input_receipt", "current_input_receipt",
    }
    allowed = required | {"successor_queue_preimage", "pending_tail_rebase", "committed_forward_replay",
                          "committed_successor_observation"}
    if not isinstance(plan, dict) or not required.issubset(plan) or set(plan) - allowed:
        raise PermissionError("forward journal plan contract differs")
    if (
        plan["authority_root_job"].get("job_id") != plan["authority_root_job_id"]
        or plan["predecessor_job"].get("job_id") != plan["predecessor_job_id"]
        or plan["successor_job"].get("job_id") != plan["successor_job_id"]
    ):
        raise PermissionError("forward journal plan contract differs")
    observation = plan.get("committed_successor_observation", {})
    completed_observation = (plan["successor_job"].get("state") == "SUCCEEDED"
                             and "eligibility_receipt" in observation)
    eligibility_successor = ({**plan["successor_job"], "checkpoint": {}}
                             if completed_observation else plan["successor_job"])
    expected = expected_forward_post_effect_eligibility_receipt(
        authority_root_job=plan["authority_root_job"], predecessor_job=plan["predecessor_job"],
        successor_job=eligibility_successor, media_unit=plan["media_unit"],
        historical_input=plan["historical_input_receipt"], current_input=plan["current_input_receipt"],
    )
    journal = {
        "schema_version": "1.0.0",
        "record_type": "PREPARED_FORWARD_POST_EFFECT_CURRENT_INPUT",
        "authority_root_job_id": plan["authority_root_job_id"],
        "predecessor_job_id": plan["predecessor_job_id"],
        "successor_job_id": plan["successor_job_id"],
        "media_unit": plan["media_unit"],
        "historical_input_receipt": plan["historical_input_receipt"],
        "current_input_receipt": plan["current_input_receipt"],
        "eligibility_receipt_expected": expected,
        "publication_authorized": False,
        "technical_cost_brl": 0,
    }
    if plan.get("pending_tail_rebase") is True:
        journal["pending_tail_rebase"] = True
    elif plan.get("pending_tail_rebase") not in {None, False}:
        raise PermissionError("forward journal pending-tail mode differs")
    if plan.get("committed_forward_replay") is True:
        journal["committed_forward_replay"] = True
    elif plan.get("committed_forward_replay") not in {None, False}:
        raise PermissionError("forward journal committed-replay mode differs")
    if "committed_successor_observation" in plan:
        observation = plan["committed_successor_observation"]
        fields = {"job_sha256", "edge_path", "edge_sha256"}
        if completed_observation:
            fields.add("eligibility_receipt")
            if observation["eligibility_receipt"] != expected:
                raise PermissionError("forward journal completed eligibility identity differs")
        if (plan.get("committed_forward_replay") is not True
                or set(observation) != fields
                or observation["job_sha256"] != _sha(_canonical(plan["successor_job"]).encode("utf-8"))):
            raise PermissionError("forward journal committed observation differs")
        journal["committed_successor_observation"] = observation
    preimage = plan.get("successor_queue_preimage")
    if preimage is not None:
        expected_preimage = {
            "exists": preimage.get("exists"),
            "job_id": plan["successor_job_id"],
            "idempotency_key": plan["successor_job"].get("idempotency_key"),
            "payload_sha256": _sha(_canonical(plan["successor_job"]["payload"]).encode("utf-8")),
            "checkpoint_sha256": _sha(_canonical(plan["successor_job"]["checkpoint"]).encode("utf-8")),
        }
        if (
            type(preimage.get("exists")) is not bool
            or preimage != expected_preimage
        ):
            raise PermissionError("forward journal successor preimage differs")
        journal["successor_queue_preimage"] = preimage
    return journal


def materialize_forward_post_effect_eligibility(
    root: Path, *, authority_root_job: dict[str, Any], predecessor_job: dict[str, Any],
    successor_job: dict[str, Any], media_unit: dict[str, Any],
    historical_input: dict[str, Any], current_input: dict[str, Any],
) -> dict[str, Any]:
    """Persist deterministic evidence only after its live inputs are checked."""
    validated = verify_forward_post_effect_current_eligibility(
        root=root, eligibility_path=None, eligibility_document=None,
        eligibility_receipt=None, authority_root_job=authority_root_job,
        predecessor_job=predecessor_job, successor_job=successor_job,
        media_unit=media_unit, historical_input=historical_input,
        current_input=current_input,
    )
    document = _evidence_document(
        authority_root_job=authority_root_job, predecessor_job=predecessor_job,
        successor_job=successor_job, media_unit=media_unit,
        historical_input=historical_input, current_input=current_input,
    )
    reference = expected_forward_post_effect_eligibility_receipt(
        authority_root_job=authority_root_job, predecessor_job=predecessor_job,
        successor_job=successor_job, media_unit=media_unit,
        historical_input=historical_input, current_input=current_input,
    )
    receipt_id = str(reference["receipt_id"])
    target = Path(root).resolve() / reference["path"]
    raw = (_canonical(document) + "\n").encode("utf-8")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if target.read_bytes() != raw:
            raise PermissionError("forward eligibility immutable receipt collision")
    else:
        temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_bytes(raw)
            os.link(temporary, target)
        except FileExistsError:
            if target.read_bytes() != raw:
                raise PermissionError("forward eligibility immutable receipt collision")
        finally:
            temporary.unlink(missing_ok=True)
    return reference


def verify_forward_post_effect_current_eligibility(
    *, root: Path, eligibility_path: Path | None, eligibility_document: dict[str, Any] | None,
    eligibility_receipt: dict[str, Any] | None, authority_root_job: dict[str, Any],
    predecessor_job: dict[str, Any], successor_job: dict[str, Any], media_unit: dict[str, Any],
    historical_input: dict[str, Any], current_input: dict[str, Any],
) -> dict[str, Any]:
    """Independently derive the exact queue proof, failing closed on drift."""
    project_root = Path(root).resolve(strict=True)
    for label, job in (("root", authority_root_job), ("predecessor", predecessor_job), ("successor", successor_job)):
        _job_binding(job, label=label)
    pending_tail_rebase = predecessor_job.get("state") == "PENDING"
    if (
        (not pending_tail_rebase and (
            predecessor_job.get("state") != "SUCCEEDED" or predecessor_job.get("lease_owner") is not None
            or predecessor_job.get("lease_until") is not None or not predecessor_job["checkpoint"]
        ))
        or (pending_tail_rebase and (
            predecessor_job.get("attempt_count") != 0 or predecessor_job.get("lease_owner") is not None
            or predecessor_job.get("lease_until") is not None or predecessor_job["checkpoint"] != {}
        ))
        or successor_job.get("state") != "PENDING" or successor_job.get("attempt_count") != 0
        or successor_job.get("lease_owner") is not None or successor_job.get("lease_until") is not None
        or successor_job["checkpoint"] != {}
    ):
        raise PermissionError("forward eligibility requires terminal history or an inert canonical tail and an untouched current successor")
    current_contract = current_production_input_contract(project_root)
    if current_contract.get("receipt_id") != current_input.get("receipt_id") or any(current_contract.get("authority", {}).values()):
        raise PermissionError("forward eligibility current production inputs are not current no-authority evidence")
    historical_ref = _immutable_input_binding(project_root, historical_input, label="historical")
    current_ref = _immutable_input_binding(project_root, current_input, label="current")
    if historical_ref == current_ref:
        raise PermissionError("forward eligibility input references are not exact immutable bindings")
    historical = _load_historical_input_envelope(project_root, historical_ref["receipt_id"])
    current = _load_historical_input_envelope(project_root, current_ref["receipt_id"])
    historical_unit = _media_unit(receipt=historical[0], work_order=historical[1], evidence=historical[2])
    current_unit = _media_unit(receipt=current[0], work_order=current[1], evidence=current[2])
    if historical_unit != media_unit or current_unit != media_unit:
        raise PermissionError("forward eligibility inputs do not describe the exact same semantic media unit")
    if pending_tail_rebase:
        # The canonical queue reconciler will independently consume this exact
        # proof before it writes an edge.  Keeping that recomputation here
        # binds the paused journal to the same pre-effect contract rather than
        # treating a pending tail as a caller-approved shortcut.
        from .phase6_media_authority import verify_media_supersession_decision
        decision = verify_media_supersession_decision(
            project_root,
            superseded_input_receipt_id=historical_ref["receipt_id"],
            authoritative_input_receipt_id=current_ref["receipt_id"],
        )
        if decision.get("media_unit") != media_unit or "pre_effect_remediation" not in decision:
            raise PermissionError("forward eligibility pending tail lacks exact pre-effect remediation")
    artifacts = {Path(row["path"]).name: row["path"] for row in current[0]["artifacts"]}
    required = {"take_plan.json", "creative_treatment_plan.json", "channel_style_bible.json"}
    if set(artifacts) & required != required:
        raise PermissionError("forward eligibility current visual contract artifacts are incomplete")
    documents = {name: json.loads((project_root / artifacts[name]).read_text(encoding="utf-8-sig")) for name in required}
    require_visual_contract(documents["take_plan.json"], documents["creative_treatment_plan.json"], documents["channel_style_bible.json"])
    expected = _evidence_document(authority_root_job=authority_root_job, predecessor_job=predecessor_job, successor_job=successor_job, media_unit=media_unit, historical_input=historical_ref, current_input=current_ref)
    if eligibility_document is not None and eligibility_document != expected:
        raise PermissionError("forward eligibility immutable evidence diverged")
    if eligibility_receipt is not None:
        if eligibility_path is None or eligibility_receipt.get("receipt_id") != expected["receipt_id"]:
            raise PermissionError("forward eligibility reference identity diverged")
    proof = dict(expected)
    proof.pop("receipt_id")
    proof["eligibility_receipt"] = eligibility_receipt or {"receipt_id": expected["receipt_id"], "path": (ELIGIBILITY_ROOT / f"{expected['receipt_id']}.json").as_posix(), "sha256": "sha256:" + "0" * 64}
    proof["proof_sha256"] = _sha(_canonical(proof).encode("utf-8"))
    return proof
