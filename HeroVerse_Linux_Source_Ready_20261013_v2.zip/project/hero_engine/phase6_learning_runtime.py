from __future__ import annotations

import json
import math
import os
import hashlib
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from jsonschema import Draft202012Validator, FormatChecker

from .atomic_io import atomic_write_utf8
from .phase6_intelligence import evaluate_learning
from .phase6_pilot import materialize_video_live, resolve_runtime_token
from .queue_phase6 import TransactionalQueue
from .youtube_reporting_phase6 import materialize_live as materialize_reporting
from .zero_cost_guard import evaluate_zero_cost


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
CANARY_VIDEO_ID = "iK_5edYQtx8"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
PROTOCOL = Path("output/operations/phase6/intelligence/experiments/latest.json")
ACTIVE_PROTOCOL = Path("output/operations/phase6/intelligence/experiments/active.json")
VIDEO2_PUBLICATION = Path("output/production/phase6/video-002/publication/youtube-publication-receipt.json")
PACKAGE_PUBLICATION = Path("output/production/phase6/canary-package-update/publication/youtube-package-update-receipt.json")
CANARY_PUBLICATION = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
RUNTIME = Path("output/operations/phase6/intelligence/learning-runtime.json")
LEARNING = Path("output/operations/phase6/intelligence/learning")
METRICS = Path("output/operations/phase6/metrics")
TASK_TYPE = "PHASE6_TREATMENT_METRICS_CHECKPOINT"
COMPARABLE_WINDOW_HOURS = 24
COMPARABLE_TOLERANCE_HOURS = 7
DATA_LAG_RETRY_HOURS = 2
PACIFIC = ZoneInfo("America/Los_Angeles")
PREFLIGHT_LATEST = Path("output/operations/zero-cost/phase6-treatment-metrics-preflight.json")
PREFLIGHT_HISTORY = Path("output/operations/zero-cost/phase6-treatment-metrics-preflights")
EXTERNAL_CHECKPOINTS = Path("output/operations/phase6/intelligence/external-read-checkpoints")
QUOTA_RECHECK_INTERVAL = timedelta(minutes=5)
PRE_PREREGISTRATION_STATUSES = {"WAITING_FOR_24H_BASELINE", "READY_TO_PREREGISTER"}


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _write_mutable_view(path: Path, value: dict[str, Any]) -> None:
    atomic_write_utf8(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _canonical(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable learning checkpoint collision: {path.name}")
        return
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(payload)
    temporary.replace(path)


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _active_protocol(root: Path) -> tuple[Path, dict[str, Any]]:
    latest = root / PROTOCOL
    active = root / ACTIVE_PROTOCOL
    if not latest.is_file() or not active.is_file():
        raise FileNotFoundError("active preregistered protocol is unavailable")
    if latest.read_bytes() != active.read_bytes():
        raise PermissionError("active/latest protocol divergence")
    protocol = _read(active)
    _validate(root, "phase6_experiment_protocol.schema.json", protocol)
    if protocol.get("status") != "PREREGISTERED":
        raise PermissionError("active protocol is not preregistered")
    return active, protocol


def _is_legitimate_pre_preregistration(protocol: dict[str, Any]) -> bool:
    status = protocol.get("status")
    baseline = protocol.get("baseline") or {}
    treatment = protocol.get("treatment") or {}
    if (
        status not in PRE_PREREGISTRATION_STATUSES
        or protocol.get("diagnosis") is not None
        or treatment.get("video_id") is not None
        or treatment.get("variable") != "NONE"
        or treatment.get("preregistered_before_production") is not False
        or protocol.get("primary_metric") != "NONE"
    ):
        return False
    snapshot_id = baseline.get("snapshot_id")
    if status == "WAITING_FOR_24H_BASELINE":
        return snapshot_id is None
    return isinstance(snapshot_id, str) and bool(snapshot_id.strip())


def _observed_youtube_usage(root: Path) -> dict[str, int] | None:
    from .phase6_quota import effective_observation_quota_usage

    return effective_observation_quota_usage(root)


def _materialize_quota_preflight(
    root: Path,
    *,
    job_id: str,
    observed_usage: dict[str, int] | None,
    current: datetime,
) -> tuple[dict[str, Any], str, str]:
    value = evaluate_zero_cost(
        root,
        operation="phase6_treatment_metrics_checkpoint",
        observed_usage=observed_usage,
        created_at=_stamp(current),
    )
    payload = _canonical(value)
    digest = hashlib.sha256(payload).hexdigest()
    history = root / PREFLIGHT_HISTORY / job_id / f"preflight-{digest[:24]}.json"
    _write_immutable_bytes(history, payload)
    _write_mutable_view(root / PREFLIGHT_LATEST, value)
    return value, _relative(root, history), "sha256:" + digest


def _validate_checkpointed_quota_preflight(
    root: Path,
    *,
    job_id: str,
    checkpoint: dict[str, Any],
) -> None:
    reference = checkpoint.get("quota_preflight")
    expected_hash = checkpoint.get("quota_preflight_hash")
    if not (
        isinstance(reference, str)
        and isinstance(expected_hash, str)
        and expected_hash.startswith("sha256:")
        and len(expected_hash) == 71
    ):
        raise PermissionError("learning checkpoint is missing its quota-preflight identity")
    path = (root / reference).resolve()
    expected_parent = (root / PREFLIGHT_HISTORY / job_id).resolve()
    if path.parent != expected_parent or path.name != f"preflight-{expected_hash.split(':', 1)[1][:24]}.json":
        raise PermissionError("learning quota-preflight is outside the exact job history")
    payload = path.read_bytes()
    if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
        raise PermissionError("learning quota-preflight hash mismatch")
    value = json.loads(payload.decode("utf-8-sig"))
    _validate(root, "zero_cost_guard.schema.json", value)
    general = next(
        (item for item in value.get("resources", []) if item.get("resource_id") == "youtube-general-units-daily"),
        None,
    )
    if not (
        value.get("operation") == "phase6_treatment_metrics_checkpoint"
        and value.get("execution_permitted") is True
        and value.get("quota_status") == "PASS"
        and value.get("technical_cost_brl") == 0
        and isinstance(general, dict)
        and general.get("quota_reserved") == 2
        and general.get("preventive_floor") == 12
    ):
        raise PermissionError("learning quota-preflight did not authorize the exact collection")


def _snapshot_external_artifact(root: Path, *, job_id: str, label: str, source: Path) -> tuple[str, str]:
    payload = source.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    target = root / EXTERNAL_CHECKPOINTS / job_id / f"{label}-{digest[:24]}.json"
    _write_immutable_bytes(target, payload)
    return _relative(root, target), "sha256:" + digest


def _read_checkpointed_artifact(
    root: Path,
    *,
    job_id: str,
    label: str,
    reference: Any,
    expected_hash: Any,
    schema_name: str | None = None,
) -> tuple[Path, dict[str, Any]]:
    if not (
        isinstance(reference, str)
        and isinstance(expected_hash, str)
        and expected_hash.startswith("sha256:")
        and len(expected_hash) == 71
    ):
        raise PermissionError(f"checkpointed {label} identity is incomplete")
    path = (root / reference).resolve()
    expected_parent = (root / EXTERNAL_CHECKPOINTS / job_id).resolve()
    if path.parent != expected_parent or path.name != f"{label}-{expected_hash.split(':', 1)[1][:24]}.json":
        raise PermissionError(f"checkpointed {label} is outside the exact job history")
    payload = path.read_bytes()
    if "sha256:" + hashlib.sha256(payload).hexdigest() != expected_hash:
        raise PermissionError(f"checkpointed {label} hash mismatch")
    value = json.loads(payload.decode("utf-8-sig"))
    if schema_name:
        _validate(root, schema_name, value)
    return path, value


def _runtime_value(
    *,
    now: datetime,
    status: str,
    protocol: dict[str, Any] | None = None,
    target_video_id: str | None = None,
    publication_receipt: str | None = None,
    baseline_snapshot: str | None = None,
    latest_treatment_snapshot: str | None = None,
    scheduled_window_at: str | None = None,
    next_observation_at: str | None = None,
    job_id: str | None = None,
    job_state: str = "NOT_CREATED",
    evaluation: str | None = None,
    classification: str | None = None,
    next_action: str,
    error: str | None = None,
) -> dict[str, Any]:
    treatment = (protocol or {}).get("treatment") or {}
    return {
        "schema_version": "1.0.0",
        "observer_id": "heroverse-phase6-treatment-learning-v1",
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "status": status,
        "protocol_id": (protocol or {}).get("protocol_id"),
        "treatment_variable": treatment.get("variable"),
        "target_video_id": target_video_id,
        "publication_receipt": publication_receipt,
        "baseline_snapshot": baseline_snapshot,
        "latest_treatment_snapshot": latest_treatment_snapshot,
        "scheduled_window_at": scheduled_window_at,
        "next_observation_at": next_observation_at,
        "job_id": job_id,
        "job_state": job_state,
        "evaluation": evaluation,
        "classification": classification,
        "next_action": next_action,
        "error": error,
        "technical_cost_brl": 0,
        "updated_at": _stamp(now),
    }


def _persist_runtime(root: Path, value: dict[str, Any]) -> dict[str, Any]:
    _validate(root, "phase6_learning_runtime.schema.json", value)
    _write_mutable_view(root / RUNTIME, value)
    return value


def _baseline_snapshot(root: Path, protocol: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    reference = (protocol.get("baseline") or {}).get("snapshot_id")
    if not isinstance(reference, str) or not reference:
        raise PermissionError("preregistered protocol has no immutable baseline snapshot id")
    path = root / METRICS / CANARY_VIDEO_ID / f"{reference}.json"
    if not path.is_file():
        raise FileNotFoundError(f"immutable baseline snapshot is missing: {reference}")
    value = _read(path)
    _validate(root, "own_channel_performance_snapshot.schema.json", value)
    if value.get("snapshot_id") != reference or value.get("video_id") != CANARY_VIDEO_ID:
        raise PermissionError("baseline snapshot identity mismatch")
    return path, value


def _metric_arm(snapshot: dict[str, Any], metric: str) -> dict[str, Any]:
    metrics = snapshot.get("private_metrics") or {}
    raw = metrics.get(metric)
    views = int(metrics.get("views") or 0)
    mean = float(raw) if isinstance(raw, (int, float)) else None
    standard_error: float | None = None
    sample_size = views
    if metric == "videoThumbnailImpressionsClickRate":
        impressions = int(metrics.get("videoThumbnailImpressions") or 0)
        sample_size = impressions
        if mean is not None and impressions > 0:
            # The bulk Reporting contract preserves YouTube's percentage-value unit.
            probability = mean / 100.0
            if 0 <= probability <= 1:
                standard_error = math.sqrt(probability * (1 - probability) / impressions) * 100.0
    return {"mean": mean, "standard_error": standard_error, "sample_size": sample_size}


def _same_comparable_window(baseline: dict[str, Any], treatment: dict[str, Any]) -> bool:
    baseline_age = float(baseline.get("age_hours") or 0)
    treatment_age = float(treatment.get("age_hours") or 0)
    low = COMPARABLE_WINDOW_HOURS
    high = COMPARABLE_WINDOW_HOURS + COMPARABLE_TOLERANCE_HOURS
    return low <= baseline_age <= high and low <= treatment_age <= high and abs(baseline_age - treatment_age) <= COMPARABLE_TOLERANCE_HOURS


def _materialize_evaluation(
    root: Path,
    *,
    protocol: dict[str, Any],
    receipt: dict[str, Any],
    baseline: dict[str, Any],
    treatment: dict[str, Any],
) -> tuple[Path, dict[str, Any]]:
    metric = str(protocol["primary_metric"])
    baseline_arm = _metric_arm(baseline, metric)
    treatment_arm = _metric_arm(treatment, metric)
    minimum = int((protocol.get("sample") or {}).get("minimum_views_per_arm") or 1)
    variable = (protocol.get("treatment") or {}).get("variable")
    validity = {
        "preregistered": protocol.get("status") == "PREREGISTERED" and (protocol.get("treatment") or {}).get("preregistered_before_production") is True,
        "same_window": _same_comparable_window(baseline, treatment),
        "single_variable": variable in {"TOPIC_ANGLE", "FIRST_8_SECONDS_MECHANISM", "BODY_PROGRESSIVE_DISCLOSURE"},
        "minimum_sample_met": baseline_arm["sample_size"] >= minimum and treatment_arm["sample_size"] >= minimum,
        "critical_incident": receipt.get("status") != "COMPLETE_PUBLIC" or receipt.get("privacy_status", "public") != "public",
        "confounders": [],
    }
    evidence_ids = list(dict.fromkeys([
        str(protocol["protocol_id"]),
        str(baseline["snapshot_id"]),
        str(treatment["snapshot_id"]),
        str(receipt.get("receipt_id") or f"publication-{receipt['video_id']}"),
    ]))
    value = evaluate_learning(
        experiment_id=f"{protocol['protocol_id']}-{receipt['video_id']}",
        metric=metric,
        baseline=baseline_arm,
        treatment=treatment_arm,
        validity=validity,
        evidence_ids=evidence_ids,
        evaluated_at=str(treatment["captured_at"]),
    )
    _validate(root, "phase6_learning_evaluation.schema.json", value)
    path = root / LEARNING / f"{value['evaluation_id']}.json"
    if path.is_file():
        prior = _read(path)
        if prior != value:
            raise PermissionError(f"immutable learning evaluation collision: {path.name}")
        value = prior
    else:
        _write(path, value)
    _write(root / LEARNING / "latest.json", value)
    return path, value


def _daily_ctr_arm(row: dict[str, Any] | None) -> dict[str, Any]:
    if row is None:
        return {"mean": None, "standard_error": None, "sample_size": 0}
    impressions = int(row.get("videoThumbnailImpressions") or 0)
    mean = row.get("videoThumbnailImpressionsClickRate")
    mean_value = float(mean) if isinstance(mean, (int, float)) else None
    standard_error = None
    if mean_value is not None and impressions > 0:
        probability = mean_value / 100.0
        if 0 <= probability <= 1:
            standard_error = math.sqrt(probability * (1 - probability) / impressions) * 100.0
    return {"mean": mean_value, "standard_error": standard_error, "sample_size": impressions}


def _package_window(receipt: dict[str, Any]) -> tuple[datetime, datetime]:
    start_date = datetime.strptime(receipt["treatment_start_date_pt"], "%Y-%m-%d").date()
    start_local = datetime(start_date.year, start_date.month, start_date.day, tzinfo=PACIFIC)
    first_due = (start_local + timedelta(days=1)).astimezone(timezone.utc)
    anchor = _parse(str(receipt.get("mutation_started_at") or receipt["updated_at"]))
    return first_due, anchor + timedelta(hours=168)


def _package_evaluation(
    root: Path,
    *,
    protocol: dict[str, Any],
    receipt: dict[str, Any],
    baseline_snapshot: dict[str, Any],
    reach: dict[str, Any],
) -> tuple[Path, dict[str, Any]]:
    by_date = {item["date"]: item for item in reach.get("daily_metrics") or []}
    baseline_row = by_date.get(receipt["baseline_end_date_pt"])
    treatment_row = by_date.get(receipt["treatment_start_date_pt"])
    baseline_arm = _daily_ctr_arm(baseline_row)
    treatment_arm = _daily_ctr_arm(treatment_row)
    minimum = int((protocol.get("sample") or {}).get("minimum_views_per_arm") or 1)
    validity = {
        "preregistered": protocol.get("status") == "PREREGISTERED" and protocol.get("treatment", {}).get("preregistered_before_production") is True,
        "same_window": baseline_row is not None and treatment_row is not None,
        "single_variable": protocol.get("treatment", {}).get("variable") == "TITLE_THUMBNAIL_PROMISE",
        "minimum_sample_met": baseline_arm["sample_size"] >= minimum and treatment_arm["sample_size"] >= minimum,
        "critical_incident": receipt.get("status") != "COMPLETE_PUBLIC_PACKAGE",
        "confounders": [],
    }
    evidence_ids = list(dict.fromkeys([
        str(protocol["protocol_id"]), str(baseline_snapshot["snapshot_id"]),
        str(reach["snapshot_id"]), str(receipt["receipt_id"]),
        f"baseline-day:{receipt['baseline_end_date_pt']}", f"treatment-day:{receipt['treatment_start_date_pt']}",
        f"pacific-boundary-offset-seconds:{float(receipt.get('boundary_offset_seconds') or 0):.6f}",
    ]))
    value = evaluate_learning(
        experiment_id=f"{protocol['protocol_id']}-{CANARY_VIDEO_ID}-package-{receipt['treatment_start_date_pt']}",
        metric="videoThumbnailImpressionsClickRate", baseline=baseline_arm, treatment=treatment_arm,
        validity=validity, evidence_ids=evidence_ids, evaluated_at=reach["captured_at"],
    )
    _validate(root, "phase6_learning_evaluation.schema.json", value)
    path = root / LEARNING / f"{value['evaluation_id']}.json"
    if path.is_file() and _read(path) != value:
        raise PermissionError(f"immutable learning evaluation collision: {path.name}")
    if not path.is_file():
        _write(path, value)
    _write(root / LEARNING / "latest.json", value)
    return path, value


def _run_package_learning(
    root: Path,
    *,
    protocol: dict[str, Any],
    baseline: dict[str, Any],
    baseline_ref: str,
    token_path: Path | None,
    observed_usage: dict[str, int] | None,
    current: datetime,
) -> dict[str, Any]:
    receipt_path = root / PACKAGE_PUBLICATION
    if not receipt_path.is_file():
        return _persist_runtime(root, _runtime_value(
            now=current, status="WAITING_FOR_TREATMENT_EXECUTION", protocol=protocol,
            target_video_id=CANARY_VIDEO_ID, baseline_snapshot=baseline_ref,
            next_action="Wait for the gated title-thumbnail transaction, its public verification receipt and the non-overlapping measurement window.",
        ))
    receipt = _read(receipt_path)
    receipt_ref = _relative(root, receipt_path)
    if receipt.get("status") != "COMPLETE_PUBLIC_PACKAGE" or receipt.get("video_id") != CANARY_VIDEO_ID or receipt.get("channel_id") != CHANNEL_ID:
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            next_action="Preserve the public baseline or completed rollback; do not evaluate a failed package mutation.",
            error=f"PACKAGE_TREATMENT_RECEIPT_{receipt.get('status', 'INVALID')}",
        ))
    prior = _read(root / RUNTIME) if (root / RUNTIME).is_file() else None
    if prior and prior.get("publication_receipt") == receipt_ref and prior.get("status") == "EVALUATED":
        evaluation_ref = prior.get("evaluation")
        if isinstance(evaluation_ref, str) and (root / evaluation_ref).is_file():
            return _persist_runtime(root, {**prior, "updated_at": _stamp(current)})
    first_window, deadline = _package_window(receipt)
    scheduled = first_window
    if prior and prior.get("publication_receipt") == receipt_ref:
        candidate = prior.get("next_observation_at") or prior.get("scheduled_window_at")
        if candidate and _parse(str(candidate)) >= first_window:
            scheduled = _parse(str(candidate))
    queue = TransactionalQueue(root)
    task_type = f"{TASK_TYPE}:PACKAGE:{CANARY_VIDEO_ID}"
    key = f"phase6-package-metrics:{CANARY_VIDEO_ID}:{_stamp(scheduled)}"
    job = queue.enqueue(
        idempotency_key=key, operation_id=OPERATION_ID, channel_id=CHANNEL_ID, task_type=task_type,
        payload={"video_id": CANARY_VIDEO_ID, "protocol_id": protocol["protocol_id"], "scheduled_window_at": _stamp(scheduled), "publication_receipt": receipt_ref},
        max_attempts=3, available_at=scheduled, now=current,
    )
    if current < scheduled:
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="NOT_DUE", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(scheduled),
            job_id=job["job_id"], job_state=job["state"], classification="NO_NEW_EVIDENCE",
            next_action="Keep the public package frozen until one complete treatment calendar day has ended.",
        ))
    if job["state"] == "SUCCEEDED":
        checkpoint = job.get("checkpoint") or {}
        evaluation_ref = checkpoint.get("evaluation")
        if evaluation_ref and (root / evaluation_ref).is_file():
            evaluation = _read(root / evaluation_ref)
            return _persist_runtime(root, _runtime_value(
                now=current, status="EVALUATED", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
                latest_treatment_snapshot=checkpoint.get("metrics_snapshot"), scheduled_window_at=_stamp(scheduled),
                job_id=job["job_id"], job_state="SUCCEEDED", evaluation=evaluation_ref,
                classification=evaluation["classification"],
                next_action="Preserve the channel-local package result; no general rule is promoted in Phase 6.",
            ))
        next_at = checkpoint.get("next_observation_at")
        if checkpoint.get("outcome") == "PARTIAL_DATA_LAG" and isinstance(next_at, str):
            next_time = _parse(next_at)
            next_job = queue.enqueue(
                idempotency_key=f"phase6-package-metrics:{CANARY_VIDEO_ID}:{_stamp(next_time)}",
                operation_id=OPERATION_ID, channel_id=CHANNEL_ID, task_type=task_type,
                payload={"video_id": CANARY_VIDEO_ID, "protocol_id": protocol["protocol_id"], "scheduled_window_at": _stamp(next_time), "publication_receipt": receipt_ref},
                max_attempts=3, available_at=next_time, now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="COLLECTED_PARTIAL", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
                latest_treatment_snapshot=checkpoint.get("metrics_snapshot"), scheduled_window_at=_stamp(scheduled),
                next_observation_at=_stamp(next_time), job_id=next_job["job_id"], job_state=next_job["state"],
                classification="NO_NEW_EVIDENCE", next_action="Wait for the provider's exact daily reach rows; null is not zero.",
            ))
    checkpoint = job.get("checkpoint") or {}
    checkpointed_snapshot = isinstance(checkpoint.get("metrics_snapshot"), str)
    if checkpointed_snapshot:
        try:
            _validate_checkpointed_quota_preflight(root, job_id=job["job_id"], checkpoint=checkpoint)
            _read_checkpointed_artifact(
                root, job_id=job["job_id"], label="reach-snapshot",
                reference=checkpoint.get("metrics_snapshot"), expected_hash=checkpoint.get("metrics_snapshot_hash"),
                schema_name="youtube_reach_snapshot.schema.json",
            )
        except Exception as exc:
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
                scheduled_window_at=_stamp(scheduled), job_id=job["job_id"], job_state=job["state"],
                classification="NO_NEW_EVIDENCE",
                next_action="Restore the exact immutable quota and reach evidence; do not recollect or bypass the guard.",
                error=f"TREATMENT_METRICS_PROOF_INVALID:{type(exc).__name__}:{exc}",
            ))
        token = None
        preflight_ref = checkpoint["quota_preflight"]
        preflight_hash = checkpoint["quota_preflight_hash"]
    else:
        preflight, preflight_ref, preflight_hash = _materialize_quota_preflight(
            root, job_id=job["job_id"], observed_usage=observed_usage, current=current,
        )
        if preflight.get("execution_permitted") is not True:
            retry_at = current + QUOTA_RECHECK_INTERVAL
            job = queue.defer(
                job["job_id"], available_at=retry_at,
                reason="TREATMENT_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
                checkpoint={**checkpoint, "quota_preflight": preflight_ref, "quota_preflight_hash": preflight_hash},
                now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="RETRY_WAIT", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
                scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(retry_at),
                job_id=job["job_id"], job_state=job["state"], classification="NO_NEW_EVIDENCE",
                next_action="Wait for the recorded free-quota recheck; no API call was made.",
                error="TREATMENT_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
            ))
        try:
            token = token_path.resolve() if token_path is not None else resolve_runtime_token(root)
            if not token.is_file():
                raise FileNotFoundError("external runtime OAuth token is unavailable")
        except Exception as exc:
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
                scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(scheduled),
                job_id=job["job_id"], job_state=job["state"], classification="NO_NEW_EVIDENCE",
                next_action="Restore the existing external OAuth token; no new consent is launched.", error=f"{type(exc).__name__}: {exc}",
            ))
    claimed = queue.claim_job(job["job_id"], worker_id=f"gestor-central-package-learning-{os.getpid()}", expected_task_type=task_type, lease_seconds=600, now=current)
    if claimed is None or claimed["job_id"] != job["job_id"]:
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="RETRY_WAIT", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(current + timedelta(minutes=10)),
            job_id=job["job_id"], job_state=job["state"], classification="NO_NEW_EVIDENCE",
            next_action="Allow the active package-learning lease to finish or expire; do not duplicate collection.",
            error=None if claimed is None else f"QUEUE_JOB_IDENTITY_MISMATCH:{claimed['job_id']}",
        ))
    try:
        claimed = queue.checkpoint(
            claimed["job_id"], worker_id=claimed["lease_owner"],
            value={**(claimed.get("checkpoint") or {}), "quota_preflight": preflight_ref, "quota_preflight_hash": preflight_hash},
            now=current,
        )
        if checkpointed_snapshot:
            _, reach = _read_checkpointed_artifact(
                root, job_id=claimed["job_id"], label="reach-snapshot",
                reference=claimed["checkpoint"].get("metrics_snapshot"),
                expected_hash=claimed["checkpoint"].get("metrics_snapshot_hash"),
                schema_name="youtube_reach_snapshot.schema.json",
            )
            reach_ref = claimed["checkpoint"]["metrics_snapshot"]
            registry_ref = claimed["checkpoint"].get("reporting_registry")
        else:
            assert token is not None
            registry_path = materialize_reporting(
                root, token_path=token, video_id=CANARY_VIDEO_ID,
                publication_receipt=CANARY_PUBLICATION, captured_at=_stamp(current),
            )
            reach_latest = root / "output/operations/phase6/reporting/reach" / CANARY_VIDEO_ID / "latest.json"
            reach = _read(reach_latest)
            _validate(root, "youtube_reach_snapshot.schema.json", reach)
            reach_path = reach_latest.parent / f"{reach['snapshot_id']}.json"
            reach_ref, reach_hash = _snapshot_external_artifact(
                root, job_id=claimed["job_id"], label="reach-snapshot", source=reach_path,
            )
            registry_ref, registry_hash = _snapshot_external_artifact(
                root, job_id=claimed["job_id"], label="reporting-registry", source=registry_path,
            )
            claimed = queue.checkpoint(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                value={
                    **(claimed.get("checkpoint") or {}),
                    "metrics_snapshot": reach_ref, "metrics_snapshot_hash": reach_hash,
                    "reporting_registry": registry_ref, "reporting_registry_hash": registry_hash,
                }, now=current,
            )
        dates = {item["date"] for item in reach.get("daily_metrics") or []}
        complete = receipt["baseline_end_date_pt"] in dates and receipt["treatment_start_date_pt"] in dates
        if not complete and current < deadline:
            next_time = min(current + timedelta(hours=DATA_LAG_RETRY_HOURS), deadline)
            queue.succeed(claimed["job_id"], worker_id=claimed["lease_owner"], checkpoint={**(claimed.get("checkpoint") or {}), "outcome": "PARTIAL_DATA_LAG", "metrics_snapshot": reach_ref, "reporting_registry": registry_ref, "next_observation_at": _stamp(next_time)}, now=current)
            next_job = queue.enqueue(
                idempotency_key=f"phase6-package-metrics:{CANARY_VIDEO_ID}:{_stamp(next_time)}", operation_id=OPERATION_ID,
                channel_id=CHANNEL_ID, task_type=task_type,
                payload={"video_id": CANARY_VIDEO_ID, "protocol_id": protocol["protocol_id"], "scheduled_window_at": _stamp(next_time), "publication_receipt": receipt_ref},
                max_attempts=3, available_at=next_time, now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="COLLECTED_PARTIAL", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
                publication_receipt=receipt_ref, baseline_snapshot=baseline_ref, latest_treatment_snapshot=reach_ref,
                scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(next_time),
                job_id=next_job["job_id"], job_state=next_job["state"], classification="NO_NEW_EVIDENCE",
                next_action="Retry after provider lag; compare only the two preregistered nonoverlapping calendar days.",
            ))
        evaluation_path, evaluation = _package_evaluation(root, protocol=protocol, receipt=receipt, baseline_snapshot=baseline, reach=reach)
        evaluation_ref = _relative(root, evaluation_path)
        finished = queue.succeed(claimed["job_id"], worker_id=claimed["lease_owner"], checkpoint={**(claimed.get("checkpoint") or {}), "outcome": "EVALUATED", "metrics_snapshot": reach_ref, "reporting_registry": registry_ref, "evaluation": evaluation_ref, "classification": evaluation["classification"]}, now=current)
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="EVALUATED", protocol=protocol, target_video_id=CANARY_VIDEO_ID,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref, latest_treatment_snapshot=reach_ref,
            scheduled_window_at=_stamp(scheduled), job_id=finished["job_id"], job_state=finished["state"],
            evaluation=evaluation_ref, classification=evaluation["classification"],
            next_action="Preserve the channel-local package result; rule promotion remains gated to a later learning phase.",
        ))
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        try:
            failed = queue.fail(claimed["job_id"], worker_id=claimed["lease_owner"], error=error, checkpoint=claimed.get("checkpoint") or {}, now=current)
            job_state = failed["state"]
        except Exception as queue_exc:
            job_state = "DEAD_LETTER"
            error += f" | QUEUE_FAILURE:{type(queue_exc).__name__}:{queue_exc}"
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT", protocol=protocol,
            target_video_id=CANARY_VIDEO_ID, publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            scheduled_window_at=_stamp(scheduled), next_observation_at=None if job_state == "DEAD_LETTER" else _stamp(current + timedelta(minutes=2)),
            job_id=claimed["job_id"], job_state=job_state, classification="NO_NEW_EVIDENCE",
            next_action="Correct the evidenced package-learning failure and retry without changing the public treatment.", error=error,
        ))


def run_phase6_learning_observer(
    root: Path = ROOT,
    *,
    token_path: Path | None = None,
    observed_usage: dict[str, int] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Observe the public Phase 6 treatment and close its preregistered loop.

    Normal YouTube data latency completes a queue job as a partial observation and
    schedules a fresh idempotent job. It never consumes the technical-failure retry
    budget or silently changes the preregistered comparison window.
    """

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    protocol_path = root / PROTOCOL
    active_protocol_path = root / ACTIVE_PROTOCOL
    if not protocol_path.is_file() and not active_protocol_path.is_file():
        return _persist_runtime(root, _runtime_value(
            now=current, status="WAITING_FOR_PREREGISTRATION",
            classification="NO_NEW_EVIDENCE",
            next_action="Wait for the eligible canary checkpoint and a schema-valid preregistered treatment protocol.",
        ))
    if protocol_path.is_file() and not active_protocol_path.is_file():
        latest_protocol: dict[str, Any] | None = None
        try:
            candidate_protocol = _read(protocol_path)
            _validate(root, "phase6_experiment_protocol.schema.json", candidate_protocol)
            latest_protocol = candidate_protocol
            latest_status = latest_protocol.get("status")
            if _is_legitimate_pre_preregistration(latest_protocol):
                snapshot_id = (latest_protocol.get("baseline") or {}).get("snapshot_id")
                baseline_ref = (
                    f"output/operations/phase6/metrics/{CANARY_VIDEO_ID}/{snapshot_id}.json"
                    if isinstance(snapshot_id, str) and snapshot_id
                    else None
                )
                return _persist_runtime(root, _runtime_value(
                    now=current, status="WAITING_FOR_PREREGISTRATION",
                    protocol=latest_protocol, baseline_snapshot=baseline_ref,
                    classification="NO_NEW_EVIDENCE",
                    next_action="Wait for the eligible canary checkpoint and committed preregistration; do not create active.json in the learning observer.",
                ))
            raise PermissionError(
                f"latest protocol state {latest_status!r} is not a legitimate pre-preregistration wait"
            )
        except Exception as exc:
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", protocol=latest_protocol,
                next_action="Restore the byte-identical active/latest preregistration; do not evaluate a mutable protocol.",
                error=f"{type(exc).__name__}: {exc}",
            ))
    try:
        protocol_path, protocol = _active_protocol(root)
    except Exception as exc:
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED",
            next_action="Restore the byte-identical active/latest preregistration; do not evaluate a mutable protocol.",
            error=f"{type(exc).__name__}: {exc}",
        ))
    baseline_ref = None
    baseline_path: Path | None = None
    if (protocol.get("baseline") or {}).get("snapshot_id"):
        baseline_ref = f"output/operations/phase6/metrics/{CANARY_VIDEO_ID}/{protocol['baseline']['snapshot_id']}.json"
    if protocol.get("status") != "PREREGISTERED":
        return _persist_runtime(root, _runtime_value(
            now=current, status="WAITING_FOR_PREREGISTRATION", protocol=protocol,
            baseline_snapshot=baseline_ref,
            next_action="Do not produce or evaluate a treatment before the 24-hour owned baseline is eligible and preregistered.",
        ))
    try:
        baseline_path, baseline = _baseline_snapshot(root, protocol)
        baseline_ref = _relative(root, baseline_path)
    except Exception as exc:
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", protocol=protocol, baseline_snapshot=baseline_ref,
            next_action="Restore the exact immutable baseline evidence; never substitute latest.json or a later observation.",
            error=f"{type(exc).__name__}: {exc}",
        ))

    variable = str((protocol.get("treatment") or {}).get("variable"))
    if variable == "TITLE_THUMBNAIL_PROMISE":
        return _run_package_learning(
            root, protocol=protocol, baseline=baseline, baseline_ref=baseline_ref,
            token_path=token_path, observed_usage=observed_usage, current=current,
        )

    receipt_path = root / VIDEO2_PUBLICATION
    if not receipt_path.is_file():
        return _persist_runtime(root, _runtime_value(
            now=current, status="WAITING_FOR_TREATMENT_PUBLICATION", protocol=protocol,
            baseline_snapshot=baseline_ref,
            next_action="Continue the gated Video 2 pipeline; collection begins only after the exact public publication receipt exists.",
        ))
    receipt = _read(receipt_path)
    preliminary_video_id = receipt.get("video_id")
    if (
        receipt.get("status") != "COMPLETE_PUBLIC"
        or receipt.get("channel_id") != CHANNEL_ID
        or not isinstance(preliminary_video_id, str)
        or not preliminary_video_id
        or preliminary_video_id == CANARY_VIDEO_ID
        or (protocol.get("treatment") or {}).get("video_id")
        not in {"phase6-video-2-prepublication", preliminary_video_id}
    ):
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", protocol=protocol,
            target_video_id=preliminary_video_id if isinstance(preliminary_video_id, str) else None,
            publication_receipt=_relative(root, receipt_path), baseline_snapshot=baseline_ref,
            next_action="Repair the exact protocol-to-publication identity chain; do not collect or compare a different video.",
            error="PHASE6_TREATMENT_PUBLICATION_IDENTITY_MISMATCH",
        ))
    try:
        from .phase6_publication import verify_phase6_publication_receipt

        receipt = verify_phase6_publication_receipt(
            root,
            receipt_path=VIDEO2_PUBLICATION,
            require_complete=True,
        )
    except Exception as exc:
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", protocol=protocol,
            baseline_snapshot=baseline_ref,
            publication_receipt=_relative(root, receipt_path),
            next_action="Restore the hardened immutable publication receipt chain before collecting treatment metrics.",
            error=f"PHASE6_PUBLICATION_RECEIPT_SEMANTIC_INVALID:{type(exc).__name__}:{exc}",
        ))
    target_video_id = receipt.get("video_id")
    receipt_ref = _relative(root, receipt_path)
    if (
        receipt.get("status") != "COMPLETE_PUBLIC"
        or receipt.get("channel_id") != CHANNEL_ID
        or not isinstance(target_video_id, str)
        or not target_video_id
        or target_video_id == CANARY_VIDEO_ID
        or (protocol.get("treatment") or {}).get("video_id") not in {"phase6-video-2-prepublication", target_video_id}
    ):
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED", protocol=protocol,
            target_video_id=target_video_id if isinstance(target_video_id, str) else None,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            next_action="Repair the exact protocol-to-publication identity chain; do not collect or compare a different video.",
            error="PHASE6_TREATMENT_PUBLICATION_IDENTITY_MISMATCH",
        ))

    prior = _read(root / RUNTIME) if (root / RUNTIME).is_file() else None
    if prior and prior.get("target_video_id") == target_video_id and prior.get("status") == "EVALUATED":
        evaluation_ref = prior.get("evaluation")
        if isinstance(evaluation_ref, str) and (root / evaluation_ref).is_file():
            return _persist_runtime(root, {**prior, "updated_at": _stamp(current)})

    anchor = _parse(str(receipt.get("updated_at") or receipt["created_at"]))
    first_window = anchor + timedelta(hours=COMPARABLE_WINDOW_HOURS)
    deadline = anchor + timedelta(hours=COMPARABLE_WINDOW_HOURS + COMPARABLE_TOLERANCE_HOURS)
    scheduled = first_window
    if prior and prior.get("target_video_id") == target_video_id:
        schedule_field = (
            "next_observation_at"
            if prior.get("status") in {"NOT_DUE", "COLLECTED_PARTIAL"}
            else "scheduled_window_at"
        )
        if prior.get(schedule_field):
            candidate = _parse(str(prior[schedule_field]))
            if candidate >= first_window:
                scheduled = candidate

    queue = TransactionalQueue(root)
    task_type = f"{TASK_TYPE}:{target_video_id}"
    key = f"phase6-treatment-metrics:{target_video_id}:{_stamp(scheduled)}"
    job = queue.enqueue(
        idempotency_key=key,
        operation_id=OPERATION_ID,
        channel_id=CHANNEL_ID,
        task_type=task_type,
        payload={
            "video_id": target_video_id,
            "protocol_id": protocol["protocol_id"],
            "scheduled_window_at": _stamp(scheduled),
            "publication_receipt": receipt_ref,
        },
        max_attempts=3,
        available_at=scheduled,
        now=current,
    )
    if current < scheduled:
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="NOT_DUE", protocol=protocol,
            target_video_id=target_video_id, publication_receipt=receipt_ref,
            baseline_snapshot=baseline_ref, scheduled_window_at=_stamp(scheduled),
            next_observation_at=_stamp(scheduled), job_id=job["job_id"], job_state=job["state"],
            classification="NO_NEW_EVIDENCE",
            next_action="Wait silently for the preregistered comparable window; do not spend quota early.",
        ))

    if job["state"] == "SUCCEEDED":
        checkpoint = job.get("checkpoint") or {}
        evaluation_ref = checkpoint.get("evaluation")
        if evaluation_ref and (root / evaluation_ref).is_file():
            evaluation = _read(root / evaluation_ref)
            return _persist_runtime(root, _runtime_value(
                now=current, status="EVALUATED", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref,
                latest_treatment_snapshot=checkpoint.get("metrics_snapshot"),
                scheduled_window_at=_stamp(scheduled), next_observation_at=None,
                job_id=job["job_id"], job_state="SUCCEEDED", evaluation=evaluation_ref,
                classification=evaluation["classification"],
                next_action="Preserve the Phase 6 result; rule promotion remains gated to the later learning phase.",
            ))
        next_at = checkpoint.get("next_observation_at")
        if checkpoint.get("outcome") == "PARTIAL_DATA_LAG" and isinstance(next_at, str):
            next_time = _parse(next_at)
            next_key = f"phase6-treatment-metrics:{target_video_id}:{_stamp(next_time)}"
            next_job = queue.enqueue(
                idempotency_key=next_key, operation_id=OPERATION_ID, channel_id=CHANNEL_ID,
                task_type=task_type,
                payload={
                    "video_id": target_video_id, "protocol_id": protocol["protocol_id"],
                    "scheduled_window_at": _stamp(next_time), "publication_receipt": receipt_ref,
                },
                max_attempts=3, available_at=next_time, now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="COLLECTED_PARTIAL", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref,
                latest_treatment_snapshot=checkpoint.get("metrics_snapshot"),
                scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(next_time),
                job_id=next_job["job_id"], job_state=next_job["state"],
                classification="NO_NEW_EVIDENCE",
                next_action="Resume the persisted data-lag schedule without repeating the completed collection.",
            ))

    checkpoint = job.get("checkpoint") or {}
    checkpointed_snapshot = isinstance(checkpoint.get("metrics_snapshot"), str)
    if checkpointed_snapshot:
        try:
            _validate_checkpointed_quota_preflight(root, job_id=job["job_id"], checkpoint=checkpoint)
            _read_checkpointed_artifact(
                root, job_id=job["job_id"], label="metrics-snapshot",
                reference=checkpoint.get("metrics_snapshot"), expected_hash=checkpoint.get("metrics_snapshot_hash"),
                schema_name="own_channel_performance_snapshot.schema.json",
            )
        except Exception as exc:
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref, scheduled_window_at=_stamp(scheduled),
                job_id=job["job_id"], job_state=job["state"], classification="NO_NEW_EVIDENCE",
                next_action="Restore the exact immutable quota and metric evidence; do not recollect or bypass the guard.",
                error=f"TREATMENT_METRICS_PROOF_INVALID:{type(exc).__name__}:{exc}",
            ))
        token = None
        preflight_ref = checkpoint["quota_preflight"]
        preflight_hash = checkpoint["quota_preflight_hash"]
    else:
        preflight, preflight_ref, preflight_hash = _materialize_quota_preflight(
            root, job_id=job["job_id"], observed_usage=observed_usage, current=current,
        )
        if preflight.get("execution_permitted") is not True:
            retry_at = current + QUOTA_RECHECK_INTERVAL
            job = queue.defer(
                job["job_id"], available_at=retry_at,
                reason="TREATMENT_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
                checkpoint={**checkpoint, "quota_preflight": preflight_ref, "quota_preflight_hash": preflight_hash},
                now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="RETRY_WAIT", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref, scheduled_window_at=_stamp(scheduled),
                next_observation_at=_stamp(retry_at), job_id=job["job_id"], job_state=job["state"],
                classification="NO_NEW_EVIDENCE",
                next_action="Wait for the recorded free-quota recheck; no API call was made.",
                error="TREATMENT_METRICS_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
            ))
        try:
            token = token_path.resolve() if token_path is not None else resolve_runtime_token(root)
            if not token.is_file():
                raise FileNotFoundError("external runtime OAuth token is unavailable")
        except Exception as exc:
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="BLOCKED", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref, scheduled_window_at=_stamp(scheduled),
                next_observation_at=_stamp(scheduled), job_id=job["job_id"], job_state=job["state"],
                classification="NO_NEW_EVIDENCE",
                next_action="Restore the existing external OAuth credential; no browser consent or duplicate collection is started automatically.",
                error=f"{type(exc).__name__}: {exc}",
            ))

    claimed = queue.claim_job(
        job["job_id"],
        worker_id=f"gestor-central-learning-{os.getpid()}",
        expected_task_type=task_type,
        lease_seconds=600,
        now=current,
    )
    if claimed is None or claimed["job_id"] != job["job_id"]:
        queue.materialize_snapshot(captured_at=current)
        state = job["state"]
        return _persist_runtime(root, _runtime_value(
            now=current, status="RETRY_WAIT", protocol=protocol,
            target_video_id=target_video_id, publication_receipt=receipt_ref,
            baseline_snapshot=baseline_ref, scheduled_window_at=_stamp(scheduled),
            next_observation_at=_stamp(current + timedelta(minutes=10)),
            job_id=job["job_id"], job_state=state,
            classification="NO_NEW_EVIDENCE",
            next_action="Allow the active lease to finish or expire; do not duplicate collection.",
            error=None if claimed is None else f"QUEUE_JOB_IDENTITY_MISMATCH:{claimed['job_id']}",
        ))

    try:
        claimed = queue.checkpoint(
            claimed["job_id"], worker_id=claimed["lease_owner"],
            value={**(claimed.get("checkpoint") or {}), "quota_preflight": preflight_ref, "quota_preflight_hash": preflight_hash},
            now=current,
        )
        reporting_ref = claimed["checkpoint"].get("reporting_registry")
        reporting_hash = claimed["checkpoint"].get("reporting_registry_hash")
        if isinstance(reporting_ref, str):
            _read_checkpointed_artifact(
                root, job_id=claimed["job_id"], label="reporting-registry",
                reference=reporting_ref, expected_hash=reporting_hash,
            )
        else:
            assert token is not None
            reporting_path = materialize_reporting(
                root, token_path=token, video_id=target_video_id,
                publication_receipt=VIDEO2_PUBLICATION, captured_at=_stamp(current),
            )
            reporting_ref, reporting_hash = _snapshot_external_artifact(
                root, job_id=claimed["job_id"], label="reporting-registry", source=reporting_path,
            )
            claimed = queue.checkpoint(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                value={**(claimed.get("checkpoint") or {}), "reporting_registry": reporting_ref, "reporting_registry_hash": reporting_hash},
                now=current,
            )
        if checkpointed_snapshot:
            _, treatment = _read_checkpointed_artifact(
                root, job_id=claimed["job_id"], label="metrics-snapshot",
                reference=claimed["checkpoint"].get("metrics_snapshot"),
                expected_hash=claimed["checkpoint"].get("metrics_snapshot_hash"),
                schema_name="own_channel_performance_snapshot.schema.json",
            )
            metrics_ref = claimed["checkpoint"]["metrics_snapshot"]
        else:
            assert token is not None
            metrics_path = materialize_video_live(
                root, token_path=token, video_id=target_video_id,
                publication_receipt=VIDEO2_PUBLICATION, captured_at=_stamp(current),
            )
            treatment = _read(metrics_path)
            _validate(root, "own_channel_performance_snapshot.schema.json", treatment)
            metrics_ref, metrics_hash = _snapshot_external_artifact(
                root, job_id=claimed["job_id"], label="metrics-snapshot", source=metrics_path,
            )
            claimed = queue.checkpoint(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                value={**(claimed.get("checkpoint") or {}), "metrics_snapshot": metrics_ref, "metrics_snapshot_hash": metrics_hash},
                now=current,
            )
        metric = str(protocol["primary_metric"])
        primary_observed = isinstance((treatment.get("private_metrics") or {}).get(metric), (int, float))
        views_observed = isinstance((treatment.get("private_metrics") or {}).get("views"), (int, float))
        comparable_age = float(treatment.get("age_hours") or 0) >= COMPARABLE_WINDOW_HOURS
        if not (primary_observed and views_observed and comparable_age) and current < deadline:
            next_time = min(current + timedelta(hours=DATA_LAG_RETRY_HOURS), deadline)
            finished = queue.succeed(
                claimed["job_id"], worker_id=claimed["lease_owner"],
                checkpoint={
                    **(claimed.get("checkpoint") or {}),
                    "outcome": "PARTIAL_DATA_LAG", "metrics_snapshot": metrics_ref,
                    "reporting_registry": reporting_ref,
                    "next_observation_at": _stamp(next_time),
                },
                now=current,
            )
            next_key = f"phase6-treatment-metrics:{target_video_id}:{_stamp(next_time)}"
            next_job = queue.enqueue(
                idempotency_key=next_key, operation_id=OPERATION_ID, channel_id=CHANNEL_ID,
                task_type=task_type,
                payload={
                    "video_id": target_video_id, "protocol_id": protocol["protocol_id"],
                    "scheduled_window_at": _stamp(next_time), "publication_receipt": receipt_ref,
                },
                max_attempts=3, available_at=next_time, now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _persist_runtime(root, _runtime_value(
                now=current, status="COLLECTED_PARTIAL", protocol=protocol,
                target_video_id=target_video_id, publication_receipt=receipt_ref,
                baseline_snapshot=baseline_ref, latest_treatment_snapshot=metrics_ref,
                scheduled_window_at=_stamp(scheduled), next_observation_at=_stamp(next_time),
                job_id=next_job["job_id"], job_state=next_job["state"],
                classification="NO_NEW_EVIDENCE",
                next_action="Retry at the recorded zero-cost lag window; null remains unknown and no rule changes.",
            ))

        evaluation_path, evaluation = _materialize_evaluation(
            root, protocol=protocol, receipt=receipt,
            baseline=baseline, treatment=treatment,
        )
        evaluation_ref = _relative(root, evaluation_path)
        finished = queue.succeed(
            claimed["job_id"], worker_id=claimed["lease_owner"],
            checkpoint={
                **(claimed.get("checkpoint") or {}),
                "outcome": "EVALUATED", "metrics_snapshot": metrics_ref,
                "reporting_registry": reporting_ref,
                "evaluation": evaluation_ref, "classification": evaluation["classification"],
            },
            now=current,
        )
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="EVALUATED", protocol=protocol,
            target_video_id=target_video_id, publication_receipt=receipt_ref,
            baseline_snapshot=baseline_ref, latest_treatment_snapshot=metrics_ref,
            scheduled_window_at=_stamp(scheduled), next_observation_at=None,
            job_id=finished["job_id"], job_state=finished["state"],
            evaluation=evaluation_ref, classification=evaluation["classification"],
            next_action="Preserve the Phase 6 result; rule promotion remains gated to the later learning phase.",
        ))
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        try:
            failed = queue.fail(
                claimed["job_id"], worker_id=claimed["lease_owner"], error=error,
                checkpoint=claimed.get("checkpoint") or {}, now=current,
            )
            job_state = failed["state"]
        except Exception as queue_exc:
            job_state = "DEAD_LETTER"
            error += f" | QUEUE_FAILURE:{type(queue_exc).__name__}:{queue_exc}"
        queue.materialize_snapshot(captured_at=current)
        return _persist_runtime(root, _runtime_value(
            now=current, status="BLOCKED" if job_state == "DEAD_LETTER" else "RETRY_WAIT",
            protocol=protocol, target_video_id=target_video_id,
            publication_receipt=receipt_ref, baseline_snapshot=baseline_ref,
            scheduled_window_at=_stamp(scheduled),
            next_observation_at=None if job_state == "DEAD_LETTER" else _stamp(current + timedelta(minutes=2)),
            job_id=claimed["job_id"], job_state=job_state,
            classification="NO_NEW_EVIDENCE",
            next_action="Correct the evidenced technical failure and retry transactionally without changing the protocol.",
            error=error,
        ))


if __name__ == "__main__":
    print(json.dumps(
        run_phase6_learning_observer(ROOT, observed_usage=_observed_youtube_usage(ROOT)),
        ensure_ascii=False,
        indent=2,
    ))
