from __future__ import annotations

import ctypes
import hashlib
import inspect
import json
import os
import re
import subprocess
import unicodedata
import uuid
from importlib.metadata import version as package_version
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker
from rapidocr import RapidOCR

from .mining.adapters import OcrAdapter
from .qa_phase5 import FFMPEG


AUDITOR_ID = "heroverse-phase6-rendered-overlay-ocr"
AUDITOR_VERSION = "1.1.0"
HOOK_WINDOWS = ("0_1S", "1_3S", "3_8S")
PLACEHOLDER_SENTINELS = {"none", "null", "undefined"}
MINIMUM_FREE_MEMORY_PERCENT = 5.0
MODEL_HASHES = {
    "PP-OCRv6_det_small.onnx": "090f04abcd9d9a7498bc4ebf677e4cb9bdce1fe4197ddb7e529f1ef44e1ff94f",
    "PP-OCRv6_rec_small.onnx": "6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884",
    "ch_ppocr_mobile_v2.0_cls_mobile.onnx": "e47acedf663230f8863ff1ab0e64dd2d82b838fceb5957146dab185a89d6215c",
}


class OverlayOcrUnavailable(RuntimeError):
    """Raised when the pinned local OCR proof cannot be executed safely."""


def _sha256(path: Path, *, prefixed: bool = True) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    value = digest.hexdigest()
    return f"sha256:{value}" if prefixed else value


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _normalised_tokens(value: Any) -> list[str]:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    text = text.replace("’", "'").replace("'", "")
    return re.findall(r"[a-z0-9]+", text)


def _contains_token_sequence(observed: list[str], expected: list[str]) -> bool:
    if not expected or len(expected) > len(observed):
        return False
    width = len(expected)
    return any(observed[index:index + width] == expected for index in range(len(observed) - width + 1))


def _solitary_placeholder(observed_tokens: list[str], expected_tokens: list[str]) -> str | None:
    if len(observed_tokens) != 1:
        return None
    token = observed_tokens[0]
    if token in PLACEHOLDER_SENTINELS and token not in expected_tokens:
        return token
    return None


def _free_memory_percent() -> float | None:
    if os.name != "nt":
        return None

    class MemoryStatusEx(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    status = MemoryStatusEx()
    status.dwLength = ctypes.sizeof(status)
    try:
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return None
    except (AttributeError, OSError):
        return None
    if not status.ullTotalPhys:
        return None
    return round(100.0 * status.ullAvailPhys / status.ullTotalPhys, 3)


class PinnedLocalOverlayOcrAdapter(OcrAdapter):
    """RapidOCR adapter pinned to local model bytes and one inference thread."""

    def __init__(
        self,
        *,
        minimum_confidence: float = 0.70,
        model_root: Path | None = None,
        expected_hashes: dict[str, str] | None = None,
    ) -> None:
        super().__init__(minimum_confidence=minimum_confidence)
        package_root = Path(inspect.getfile(RapidOCR)).resolve().parent
        self.model_root = (model_root or package_root / "models").resolve()
        self.expected_hashes = dict(expected_hashes or MODEL_HASHES)

    def contract(self, root: Path) -> dict[str, Any]:
        free_percent = _free_memory_percent()
        if free_percent is not None and free_percent < MINIMUM_FREE_MEMORY_PERCENT:
            raise OverlayOcrUnavailable(
                f"OCR_MEMORY_FLOOR:{free_percent:.3f}<{MINIMUM_FREE_MEMORY_PERCENT:.3f}"
            )
        models: list[dict[str, Any]] = []
        for name, expected in sorted(self.expected_hashes.items()):
            path = (self.model_root / name).resolve()
            if not path.is_file():
                raise OverlayOcrUnavailable(f"OCR_MODEL_MISSING:{name}")
            observed = _sha256(path, prefixed=False)
            if observed != expected:
                raise OverlayOcrUnavailable(f"OCR_MODEL_HASH_MISMATCH:{name}")
            models.append({
                "name": name,
                "path": _relative(root, path),
                "sha256": f"sha256:{observed}",
                "size_bytes": path.stat().st_size,
            })
        return {
            "provider": self.provider,
            "provider_version": package_version("rapidocr"),
            "minimum_confidence": self.minimum_confidence,
            "intra_op_num_threads": 1,
            "inter_op_num_threads": 1,
            "network_used": False,
            "technical_cost_brl": 0,
            "free_memory_percent_before_load": free_percent,
            "models": models,
        }

    @property
    def engine(self) -> RapidOCR:
        if self._engine is None:
            self.contract(Path.cwd().resolve())
            paths = {name: str((self.model_root / name).resolve()) for name in MODEL_HASHES}
            self._engine = RapidOCR(params={
                "Global.model_root_dir": str(self.model_root),
                "Global.log_level": "error",
                "EngineConfig.onnxruntime.intra_op_num_threads": 1,
                "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                "EngineConfig.onnxruntime.enable_cpu_mem_arena": False,
                "Det.model_path": paths["PP-OCRv6_det_small.onnx"],
                "Rec.model_path": paths["PP-OCRv6_rec_small.onnx"],
                "Cls.model_path": paths["ch_ppocr_mobile_v2.0_cls_mobile.onnx"],
            })
        return self._engine


def _locked_framework_tokens(style_bible: dict[str, Any]) -> list[str]:
    principles = ((style_bible.get("identity") or {}).get("principles") or [])
    for principle in principles:
        match = re.match(
            r"^(.+?)\s+remains\s+the\s+locked\s+information\s+system\b",
            str(principle).strip(),
            flags=re.IGNORECASE,
        )
        if match:
            return _normalised_tokens(match.group(1))
    return []


def _sequence_lines(lines: list[dict[str, Any]], expected: list[str]) -> list[dict[str, Any]]:
    """All boxes contributing to every complete, ordered token occurrence.

    A shared word is not evidence that background text is the planned overlay.
    Conversely, an unsafe duplicate of the complete overlay cannot be ignored.
    """
    tokens: list[str] = []
    owners: list[int] = []
    for index, line in enumerate(lines):
        words = _normalised_tokens(line.get("text"))
        tokens.extend(words)
        owners.extend([index] * len(words))
    matched: set[int] = set()
    if expected:
        for start in range(len(tokens) - len(expected) + 1):
            if tokens[start:start + len(expected)] == expected:
                matched.update(owners[start:start + len(expected)])
    return [line for index, line in enumerate(lines) if index in matched]


def _inside_safe_area(line: dict[str, Any], horizontal: float, vertical: float) -> bool | None:
    position = line.get("relative_position") or {}
    try:
        x = float(position["x"])
        y = float(position["y"])
        width = float(position["width"])
        height = float(position["height"])
    except (KeyError, TypeError, ValueError):
        return None
    return bool(
        x >= horizontal
        and y >= vertical
        and x + width <= 1.0 - horizontal
        and y + height <= 1.0 - vertical
    )


def evaluate_overlay_frame(
    *,
    frame_path: Path,
    take_id: str,
    timecode_ms: int,
    expected_overlay: str | None,
    hook_windows: list[str],
    safe_area_horizontal: float,
    safe_area_vertical: float,
    ocr_adapter: OcrAdapter,
) -> dict[str, Any]:
    """Compare rendered pixels with the exact TakePlan overlay contract."""

    expected_tokens = _normalised_tokens(expected_overlay)
    base = {
        "take_id": take_id,
        "timecode_ms": int(timecode_ms),
        "hook_windows": list(hook_windows),
        "frame_path": str(frame_path),
        "frame_sha256": _sha256(frame_path),
        "frame_size_bytes": frame_path.stat().st_size,
        "expected_overlay": expected_overlay,
        "expected_tokens": expected_tokens,
    }
    try:
        scan = ocr_adapter.scan(frame_path)
    except Exception as exc:
        return {
            **base,
            "status": "BLOCKED",
            "observed_text": None,
            "observed_tokens": [],
            "observed_lines": [],
            "rejected_lines": [],
            "placeholder_sentinel": None,
            "expected_sequence_present": False if expected_tokens else None,
            "safe_area_status": "UNKNOWN",
            "failures": [f"OCR_LOCAL_UNAVAILABLE:{type(exc).__name__}:{exc}"],
        }

    lines = list(scan.get("lines") or [])
    rejected = list(scan.get("rejected_lines") or [])
    observed_text = " ".join(str(line.get("text") or "").strip() for line in lines).strip()
    observed_tokens = _normalised_tokens(observed_text)
    placeholder = _solitary_placeholder(observed_tokens, expected_tokens)
    sequence_present = _contains_token_sequence(observed_tokens, expected_tokens) if expected_tokens else None
    contributing = _sequence_lines(lines, expected_tokens)
    positions = [
        _inside_safe_area(line, safe_area_horizontal, safe_area_vertical)
        for line in contributing
    ]
    failures: list[str] = []
    status = "PASS"
    safe_area_status = "NOT_APPLICABLE" if not expected_tokens else "PASS"
    if placeholder is not None:
        status = "FAIL"
        failures.append(f"UNPLANNED_PLACEHOLDER_SENTINEL:{placeholder}")
    if expected_tokens:
        if not lines:
            if rejected:
                status = "BLOCKED"
                failures.append("PLANNED_OVERLAY_OCR_UNREADABLE")
            else:
                status = "FAIL"
                failures.append("PLANNED_OVERLAY_NOT_OBSERVED")
        elif sequence_present is not True:
            status = "FAIL"
            failures.append("PLANNED_OVERLAY_MISSING_OR_SUBSTITUTED")
        if sequence_present is True:
            if not contributing or any(value is None for value in positions):
                status = "BLOCKED"
                safe_area_status = "UNKNOWN"
                failures.append("OVERLAY_SAFE_AREA_GEOMETRY_UNAVAILABLE")
            elif not all(positions):
                status = "FAIL"
                safe_area_status = "FAIL"
                failures.append("PLANNED_OVERLAY_OUTSIDE_SAFE_AREA")
    return {
        **base,
        "status": status,
        "observed_text": observed_text,
        "observed_tokens": observed_tokens,
        "observed_lines": lines,
        "rejected_lines": rejected,
        "placeholder_sentinel": placeholder,
        "expected_sequence_present": sequence_present,
        "safe_area_status": safe_area_status,
        "failures": list(dict.fromkeys(failures)),
    }


FrameExtractor = Callable[[Path, int, Path], None]


def _extract_frame(video: Path, timecode_ms: int, output: Path) -> None:
    result = subprocess.run(
        [
            FFMPEG,
            "-hide_banner", "-loglevel", "error", "-filter_threads", "1",
            "-i", str(video), "-ss", f"{timecode_ms / 1000:.6f}",
            "-map", "0:v:0", "-frames:v", "1", "-an", "-threads", "1",
            "-c:v", "png", "-y", str(output),
        ],
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=60,
    )
    if result.returncode or not output.is_file() or output.stat().st_size == 0:
        raise OverlayOcrUnavailable(
            "FRAME_EXTRACTION_FAILED:" + (result.stderr.strip()[-500:] or str(result.returncode))
        )


def _immutable_extracted_frame(
    *,
    video: Path,
    take_id: str,
    timecode_ms: int,
    directory: Path,
    extractor: FrameExtractor,
) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    temporary = directory / f".{take_id}-{timecode_ms}-{os.getpid()}-{uuid.uuid4().hex}.png"
    try:
        extractor(video, timecode_ms, temporary)
        digest = _sha256(temporary, prefixed=False)
        target = directory / f"{take_id}-at-{timecode_ms}ms-{digest[:16]}.png"
        if target.is_file():
            if _sha256(target, prefixed=False) != digest:
                raise PermissionError(f"immutable OCR frame collision: {target.name}")
        else:
            try:
                os.link(temporary, target)
            except FileExistsError:
                if _sha256(target, prefixed=False) != digest:
                    raise PermissionError(f"immutable OCR frame collision: {target.name}")
        return target
    finally:
        temporary.unlink(missing_ok=True)


def _actual_windows(plan: dict[str, Any], render_manifest: dict[str, Any]) -> dict[str, tuple[int, int]]:
    rendered = render_manifest.get("segment_timeline") or []
    rendered_by_id = {str(item.get("take_id")): item for item in rendered}
    windows: dict[str, tuple[int, int]] = {}
    for take in plan.get("takes") or []:
        take_id = str(take.get("take_id"))
        actual = rendered_by_id.get(take_id) or {}
        start = int(round(float(actual.get("actual_start_ms", take.get("start_ms")))))
        end = int(round(float(actual.get("actual_end_ms", take.get("end_ms")))))
        if end <= start:
            raise ValueError(f"invalid rendered window for overlay OCR: {take_id}")
        windows[take_id] = (start, end)
    return windows


def _build_audit_id(audit: dict[str, Any]) -> str:
    material = dict(audit)
    material.pop("audit_id", None)
    encoded = json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "phase6-overlay-ocr-" + hashlib.sha256(encoded).hexdigest()[:24]


def build_overlay_ocr_audit(
    root: Path,
    *,
    video: Path,
    plan: dict[str, Any],
    treatment: dict[str, Any],
    style_bible: dict[str, Any],
    render_manifest: dict[str, Any],
    take_plan_path: Path,
    treatment_path: Path,
    style_bible_path: Path,
    output_root: Path,
    ocr_adapter: OcrAdapter | None = None,
    frame_extractor: FrameExtractor | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    video = video.resolve()
    adapter = ocr_adapter or PinnedLocalOverlayOcrAdapter()
    extractor = frame_extractor or _extract_frame
    hooks_by_take: dict[str, list[str]] = {}
    for window in plan.get("hook_window_coverage") or []:
        name = str(window.get("window"))
        if name not in HOOK_WINDOWS:
            continue
        for take_id in window.get("take_ids") or []:
            hooks_by_take.setdefault(str(take_id), []).append(name)
    plan_takes = {str(item.get("take_id")): item for item in plan.get("takes") or []}
    overlay_ids = {
        take_id for take_id, take in plan_takes.items()
        if isinstance(take.get("on_screen_text"), str) and take["on_screen_text"].strip()
    }
    required_ids = set(hooks_by_take) | overlay_ids
    ordered_ids = [str(item.get("take_id")) for item in plan.get("takes") or [] if str(item.get("take_id")) in required_ids]
    windows = _actual_windows(plan, render_manifest)
    safe_area = (style_bible.get("typography") or {}).get("safe_area") or {}
    horizontal = float(safe_area.get("horizontal_percent", 0)) / 100.0
    vertical = float(safe_area.get("vertical_percent", 0)) / 100.0

    contract_error: str | None = None
    try:
        adapter_contract = adapter.contract(root) if hasattr(adapter, "contract") else {
            "provider": getattr(adapter, "provider", "UNKNOWN"),
            "provider_version": "UNKNOWN",
            "minimum_confidence": getattr(adapter, "minimum_confidence", None),
            "intra_op_num_threads": 1,
            "inter_op_num_threads": 1,
            "network_used": False,
            "technical_cost_brl": 0,
            "free_memory_percent_before_load": None,
            "models": [],
        }
    except Exception as exc:
        contract_error = f"OCR_CONTRACT_UNAVAILABLE:{type(exc).__name__}:{exc}"
        adapter_contract = {
            "provider": getattr(adapter, "provider", "rapidocr"),
            "provider_version": "UNKNOWN",
            "minimum_confidence": getattr(adapter, "minimum_confidence", None),
            "intra_op_num_threads": 1,
            "inter_op_num_threads": 1,
            "network_used": False,
            "technical_cost_brl": 0,
            "free_memory_percent_before_load": _free_memory_percent(),
            "models": [],
        }

    # RAM is an invocation/admission fact, not a pixel or evaluator identity.
    # Keep its actual value immutably outside the recomputable measurement;
    # never copy an earlier invocation's value to manufacture equal audits.
    video_hash = _sha256(video, prefixed=False)
    observation = {
        "auditor_id": AUDITOR_ID, "auditor_version": AUDITOR_VERSION,
        "video_sha256": "sha256:" + video_hash,
        "free_memory_percent_before_load": adapter_contract.get("free_memory_percent_before_load"),
        "minimum_free_memory_percent": MINIMUM_FREE_MEMORY_PERCENT,
        "contract_error": contract_error,
        "publication_authorized": False,
    }
    observation_hash = hashlib.sha256(_encoded(observation)).hexdigest()
    _write_immutable_json(output_root / "resource-observations" / f"{observation_hash}.json", observation)
    adapter_contract = {**adapter_contract, "free_memory_percent_before_load": None}
    frame_directory = output_root / "frames" / video_hash[:16]
    records: list[dict[str, Any]] = []
    for take_id in ordered_ids:
        take = plan_takes[take_id]
        start, end = windows[take_id]
        timecode_ms = int(round((start + end) / 2))
        try:
            frame = _immutable_extracted_frame(
                video=video,
                take_id=take_id,
                timecode_ms=timecode_ms,
                directory=frame_directory,
                extractor=extractor,
            )
            if contract_error:
                record = {
                    "take_id": take_id,
                    "timecode_ms": timecode_ms,
                    "hook_windows": hooks_by_take.get(take_id, []),
                    "frame_path": _relative(root, frame),
                    "frame_sha256": _sha256(frame),
                    "frame_size_bytes": frame.stat().st_size,
                    "expected_overlay": take.get("on_screen_text"),
                    "expected_tokens": _normalised_tokens(take.get("on_screen_text")),
                    "status": "BLOCKED",
                    "observed_text": None,
                    "observed_tokens": [],
                    "observed_lines": [],
                    "rejected_lines": [],
                    "placeholder_sentinel": None,
                    "expected_sequence_present": None,
                    "safe_area_status": "UNKNOWN",
                    "failures": [contract_error],
                }
            else:
                record = evaluate_overlay_frame(
                    frame_path=frame,
                    take_id=take_id,
                    timecode_ms=timecode_ms,
                    expected_overlay=take.get("on_screen_text"),
                    hook_windows=hooks_by_take.get(take_id, []),
                    safe_area_horizontal=horizontal,
                    safe_area_vertical=vertical,
                    ocr_adapter=adapter,
                )
                record["frame_path"] = _relative(root, frame)
        except Exception as exc:
            record = {
                "take_id": take_id,
                "timecode_ms": timecode_ms,
                "hook_windows": hooks_by_take.get(take_id, []),
                "frame_path": None,
                "frame_sha256": None,
                "frame_size_bytes": None,
                "expected_overlay": take.get("on_screen_text"),
                "expected_tokens": _normalised_tokens(take.get("on_screen_text")),
                "status": "BLOCKED",
                "observed_text": None,
                "observed_tokens": [],
                "observed_lines": [],
                "rejected_lines": [],
                "placeholder_sentinel": None,
                "expected_sequence_present": None,
                "safe_area_status": "UNKNOWN",
                "failures": [f"FRAME_OR_OCR_UNAVAILABLE:{type(exc).__name__}:{exc}"],
            }
        record["planned_start_ms"] = int(take["start_ms"])
        record["planned_end_ms"] = int(take["end_ms"])
        record["actual_start_ms"] = start
        record["actual_end_ms"] = end
        records.append(record)

    treatment_by_id = {str(item.get("take_id")): item for item in treatment.get("takes") or []}
    locked_tokens = _locked_framework_tokens(style_bible)
    records_by_id = {record["take_id"]: record for record in records}
    conflicts: list[dict[str, Any]] = []
    for take_id, treatment_take in treatment_by_id.items():
        if treatment_take.get("treatment") != "HOOK_FRAMEWORK":
            continue
        planned_tokens = _normalised_tokens((plan_takes.get(take_id) or {}).get("on_screen_text"))
        if not locked_tokens:
            conflicts.append({
                "take_id": take_id,
                "defect": "STYLE_BIBLE_LOCKED_FRAMEWORK_UNAVAILABLE",
                "planned_tokens": planned_tokens,
                "style_bible_tokens": [],
            })
        # The current recipe deliberately preserves distinct editorial and
        # channel-identity layers. Verify the latter in the observed pixels,
        # not by requiring TakePlan to replace its spoken-mechanism copy.
        # Editorial presence/geometry is independently checked above.
        elif not (system_lines := _sequence_lines(
            (records_by_id.get(take_id) or {}).get("observed_lines") or [], locked_tokens,
        )):
            conflicts.append({
                "take_id": take_id,
                "defect": "TAKE_PLAN_STYLE_BIBLE_OVERLAY_CONFLICT",
                "planned_tokens": planned_tokens,
                "style_bible_tokens": locked_tokens,
            })
        elif not all(_inside_safe_area(line, horizontal, vertical) is True for line in system_lines):
            conflicts.append({
                "take_id": take_id,
                "defect": "STYLE_BIBLE_OBSERVED_SYSTEM_UNSAFE_OR_UNKNOWN",
                "planned_tokens": planned_tokens,
                "style_bible_tokens": locked_tokens,
            })

    statuses = [record["status"] for record in records]
    sampling_complete = bool(ordered_ids and len(records) == len(required_ids) and set(ordered_ids) == required_ids)
    hook_records = [record for record in records if record["hook_windows"]]
    observed_hook_windows = {
        window for record in hook_records for window in record["hook_windows"]
    }
    status = "BLOCKED" if (contract_error or not sampling_complete or "BLOCKED" in statuses) else "FAIL" if (conflicts or "FAIL" in statuses) else "PASS"
    hook_passed = bool(
        observed_hook_windows == set(HOOK_WINDOWS)
        and all(record["status"] == "PASS" for record in hook_records)
        and not any(conflict["take_id"] in hooks_by_take for conflict in conflicts)
    )
    overlay_records = [record for record in records if record["take_id"] in overlay_ids]
    legibility_passed = bool(
        len(overlay_records) == len(overlay_ids)
        and all(
            record["status"] == "PASS"
            and record["expected_sequence_present"] is True
            and record["safe_area_status"] == "PASS"
            for record in overlay_records
        )
    )
    semantic_passed = bool(
        not conflicts
        and all(record["placeholder_sentinel"] is None for record in records)
        and all(
            record["expected_sequence_present"] is True
            for record in overlay_records
        )
    )
    audit: dict[str, Any] = {
        "schema_version": "1.0.0",
        "audit_id": "phase6-overlay-ocr-pending",
        "auditor": {
            "auditor_id": AUDITOR_ID,
            "version": AUDITOR_VERSION,
            **adapter_contract,
        },
        "video": {
            "path": _relative(root, video),
            "sha256": _sha256(video),
            "size_bytes": video.stat().st_size,
        },
        "sources": {
            "take_plan": {"path": _relative(root, take_plan_path), "sha256": _sha256(take_plan_path)},
            "treatment": {"path": _relative(root, treatment_path), "sha256": _sha256(treatment_path)},
            "style_bible": {"path": _relative(root, style_bible_path), "sha256": _sha256(style_bible_path)},
        },
        "sampling": {
            "policy": "one representative midpoint frame for every 0-1/1-3/3-8 hook take and every TakePlan overlay take",
            "hook_windows_required": list(HOOK_WINDOWS),
            "hook_windows_observed": sorted(observed_hook_windows),
            "required_take_ids": ordered_ids,
            "overlay_take_ids": [take_id for take_id in ordered_ids if take_id in overlay_ids],
            "sampled_take_ids": [record["take_id"] for record in records],
            "sampling_complete": sampling_complete,
            "all_planned_overlay_takes_sampled": set(record["take_id"] for record in overlay_records) == overlay_ids,
            "full_render_temporal_ocr_exhaustive": False,
        },
        "style_bible_contract": {
            "locked_framework_tokens": locked_tokens,
            "conflicts": conflicts,
            "passed": bool(locked_tokens and not conflicts),
        },
        "frames": records,
        "summary": {
            "frame_count": len(records),
            "overlay_frame_count": len(overlay_records),
            "hook_frame_count": len(hook_records),
            "pass_count": statuses.count("PASS"),
            "fail_count": statuses.count("FAIL"),
            "blocked_count": statuses.count("BLOCKED"),
            "placeholder_count": sum(record["placeholder_sentinel"] is not None for record in records),
            "style_bible_conflict_count": len(conflicts),
            "hook_passed": hook_passed,
            "legibility_passed": legibility_passed,
            "semantic_passed": semantic_passed,
        },
        "status": status,
        "passed": status == "PASS" and hook_passed and legibility_passed and semantic_passed,
        "limitations": [
            "Runtime RAM is measured and archived separately in resource-observations; its null audit field is intentionally excluded from pixel identity, not an exemption from the memory gate.",
            "This OCR audit samples one representative frame per required take; it does not claim full-frame or full-duration visual review.",
            "RapidOCR is an automatic local observer, not the human gold-standard reviewer.",
            "OCR failure or missing geometry blocks the affected critical gate instead of being treated as PASS.",
        ],
    }
    audit["audit_id"] = _build_audit_id(audit)
    return audit


def _encoded(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _write_immutable_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = _encoded(value)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable overlay OCR audit collision: {path.name}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    try:
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.read_bytes() != payload:
                raise PermissionError(f"immutable overlay OCR audit collision: {path.name}")
    finally:
        temporary.unlink(missing_ok=True)


def materialize_overlay_ocr_audit(
    root: Path,
    **kwargs: Any,
) -> dict[str, Any]:
    root = root.resolve()
    output_root = Path(kwargs["output_root"])
    audit = build_overlay_ocr_audit(root, **kwargs)
    schema = json.loads((root / "schemas/phase6_overlay_ocr_audit.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(audit)
    immutable = output_root / "audits" / f"{audit['audit_id']}.json"
    latest = output_root / "latest.json"
    _write_immutable_json(immutable, audit)
    latest.parent.mkdir(parents=True, exist_ok=True)
    temporary = latest.with_name(f".{latest.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(_encoded(audit))
    os.replace(temporary, latest)
    return {
        **audit,
        "audit_path": _relative(root, immutable),
        "audit_sha256": _sha256(immutable),
        "audit_size_bytes": immutable.stat().st_size,
    }


def verify_overlay_ocr_measurement(root: Path, measurement: dict[str, Any]) -> dict[str, Any]:
    root = root.resolve()
    audit_path = (root / str(measurement.get("audit_path") or "")).resolve()
    expected_parent = (root / "output/production/phase6/video-002/quality/overlay-ocr/audits").resolve()
    if audit_path.parent != expected_parent or audit_path.name != f"{measurement.get('audit_id')}.json":
        raise PermissionError("overlay OCR audit path escaped its immutable identity")
    if not audit_path.is_file():
        raise FileNotFoundError("immutable overlay OCR audit is missing")
    if (
        _sha256(audit_path) != measurement.get("audit_sha256")
        or audit_path.stat().st_size != measurement.get("audit_size_bytes")
    ):
        raise PermissionError("overlay OCR audit hash or size changed")
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    schema = json.loads((root / "schemas/phase6_overlay_ocr_audit.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(audit)
    expected_measurement = {
        **audit,
        "audit_path": measurement["audit_path"],
        "audit_sha256": measurement["audit_sha256"],
        "audit_size_bytes": measurement["audit_size_bytes"],
    }
    if expected_measurement != measurement:
        raise PermissionError("embedded overlay OCR measurement differs from immutable audit")
    latest = expected_parent.parent / "latest.json"
    if not latest.is_file() or latest.read_bytes() != audit_path.read_bytes():
        raise PermissionError("latest overlay OCR audit differs from its immutable twin")
    if measurement.get("auditor", {}).get("version") != AUDITOR_VERSION:
        raise PermissionError("legacy overlay OCR auditor cannot satisfy the current quality gate")
    if measurement.get("video", {}).get("sha256") is None:
        raise PermissionError("overlay OCR audit lacks frozen-video binding")
    return measurement


def overlay_gate_value(base_passed: bool, audit: dict[str, Any], aspect: str) -> bool | None:
    if audit.get("status") == "BLOCKED":
        return None
    return bool(base_passed and (audit.get("summary") or {}).get(aspect) is True)
