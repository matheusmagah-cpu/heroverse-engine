"""Read the frozen 51-unit visual intention without creating a clock or media.

The caller supplies A-verified units and its same-call caption proof. This
reader reopens their literal caption input independently, not their PCM. It
identifies lexical targets; source suitability, scheduling, calibration and
admission remain separate and false. No planner/recipe code is executed.
"""
from __future__ import annotations

import copy
from pathlib import Path

from jsonschema import Draft202012Validator

from .phase6_av_caption_intent import (
    PLAN_BINDING as CAPTION_PLAN, SOURCE as UNIT_MAP,
    _binding, _resident, read_caption_intent,
)
from .phase6_narration_audio_inventory import _json
from .phase6_narration_units import bytes_sha, canonical_sha

VERSION = "phase6-av-untimed-visual-intent-v1"
SCHEMA = "schemas/phase6_av_untimed_visual_intent.schema.json"
# LIMITED to the externally reviewed v2 literal plan. New editorial decisions
# require a new version/pin; a candidate cannot authorize its own edited hash.
PLAN_BINDING = {
    "path": "output/operations/phase6/av-admission/visual-intents/untimed-visual-intent-v2.json",
    "sha256": "sha256:d8504875d441ec62549d36ceda84d5aab8bce56c094d3a9f76686015b8697b15",
}
EDITORIAL_SUPPLEMENT_BINDING = {
    "path": "output/operations/phase6/av-admission/visual-intents/untimed-editorial-supplement-v2.json",
    "sha256": "sha256:3c2485ef2b250210919c9c4b6e7189fe7232e7fb59ebc56832e0b67e9908b1da",
}
SOURCE_BINDINGS = {
    "d169": {"path": "output/qa/phase6/diagnostics/remaining-intent-observation-v1/remaining-editorial-intent-v1.json",
        "sha256": "sha256:3ce6d7844800c608951f30ae690f0ddfb552fda47143ee74479d9a32c2eebfd4"},
    "audit": {"path": "output/qa/phase6/diagnostics/temporal-scope-audit-3a6aa9e15887bd7998b2bc3d.json",
        "sha256": "sha256:6ba997f4d6d72fff549861abd3e5e4c50193cdfb39898d6d45aedb8b5ad489fe"},
    "take_plan": {"path": "output/production/phase6/video-002/production/take_plan.json",
        "sha256": "sha256:547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5"},
    "narrative_script": {"path": "output/production/phase6/video-002/preproduction/narrative_script.json",
        "sha256": "sha256:6f8686c2bbfdcb8524eb26e3f94729efec13c17b30ed4f8c59dd223ff2d24e1d"},
    "caption_plan": CAPTION_PLAN,
}
SUPPLEMENT_SOURCE_BINDINGS = {
    "two_column_recipe": {"path": "hero_engine/phase6_two_column_recipe.py",
        "sha256": "sha256:bc70f57d347093ba2df38eb90e312913c0ebcf5cab2d3f23312f2ec9906fce73"},
    "static_intent": {"path": "output/operations/phase6/av-admission/visual-intents/static-visual-intent-82df010c45b04bcde544ed38.json",
        "sha256": "sha256:336a94cba4c92b9f3fb0c75df28389295cdca9c8ccb96ad0ecf6afae2f0eae1f"},
    "hook_recipe": {"path": "hero_engine/phase6_editorial_hook_recipe.py",
        "sha256": "sha256:610bd1d55e3273c22a1436e928990c34567c2d15d9b2017c87a970f00962d7ab"},
    "style_bible": {"path": "output/production/phase6/video-002/production/channel_style_bible.json",
        "sha256": "sha256:c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049"},
    "unit_map": UNIT_MAP,
}
AUTHORITY = {key: False for key in ("timing", "source", "quality", "render", "admission", "publication")}
REQUIRED_VISUAL_IDS = {f"narration-unit-{number:03d}" for number in (5, 6, 7, 11, 12, 20, 26, 34, 41)}
ADDITIONAL_EDITORIAL_IDS = {f"narration-unit-{number:03d}" for number in (8, 9, 22, 23, 27, 28, 29, 31, 37, 38, 39, 40, 42, 46, 51)}


def _same(actual, expected, message):
    if canonical_sha(actual) != canonical_sha(expected):
        raise ValueError(message)


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name}: exact integer required")
    return value


def _reference(reference, binding, field, index):
    _same(reference, {"binding": binding, "selector": f"/{field}/{index}"},
          "decision must reference the exact frozen row; arbitrary selectors are forbidden")


def _state_entries(row, seen_ids):
    states, text, lexical = row["states"], row["text"], []
    previous, last_end = None, 0
    for index, state in enumerate(states):
        sid, entry = state["state_id"], state["entry"]
        if sid in seen_ids:
            raise ValueError("duplicate visual state identity")
        seen_ids.add(sid)
        if not state["narrative_function"].strip() or not state["continuity_rule"].strip():
            raise ValueError("visual narrative/continuity decision is empty")
        content = state["visual_content"]
        if not content["composition_id"].strip() or not content["description"].strip():
            raise ValueError("visual content decision is empty")
        if index == 0:
            _same(entry, {"kind": "UNIT_ENTRY", "char_start": None, "char_end": None,
                          "text": None, "previous_state_id": None}, "first state must enter the whole unit without word timing")
        else:
            if entry["previous_state_id"] != previous["state_id"]:
                raise ValueError("visual state must follow its immediate predecessor")
            if entry["kind"] == "LEXICAL_START":
                start = _integer(entry["char_start"], "visual lexical start")
                end = _integer(entry["char_end"], "visual lexical end", 1)
                if not last_end <= start < end <= len(text) or text[start:end] != entry["text"]:
                    raise ValueError("visual lexical range/order differs from literal unit")
                last_end = end
                lexical.append({"unit_id": row["unit_id"], "state_id": sid,
                    "char_start": start, "char_end": end, "text": entry["text"], "kind": "LEXICAL_START"})
            elif entry["kind"] == "CONTINUE_STATE":
                if row["unit_id"] != "narration-unit-016" or any(entry[key] is not None for key in ("char_start", "char_end", "text")):
                    raise ValueError("only the frozen u016 continuation is supported without lexical timing")
                _same(content, previous["visual_content"], "HOLD cannot change composition or visible content")
            else:
                raise ValueError("internal visual state cannot impersonate a whole-unit entry")
        previous = state
    return lexical


def _required_anchors(by_unit, d169, static_intent, audit):
    for decision in d169["decisions"]:
        requirement = decision["lexical_requirement"]
        if requirement is None:
            continue
        wanted = (requirement["char_start"], requirement["char_end"], requirement["text"])
        actual = [(item["char_start"], item["char_end"], item["text"]) for item in by_unit[decision["unit_id"]]]
        if actual != [wanted]:
            raise ValueError("D169 required lexical reveal changed or disappeared")
    static = {}
    for requirement in static_intent["event_requirements"]:
        if requirement["kind"] == "SEMANTIC_CHANGE":
            static.setdefault(requirement["unit_id"], []).append((requirement["char_start"], requirement["char_end"]))
    for uid, wanted in static.items():
        if [(item["char_start"], item["char_end"]) for item in by_unit[uid]] != wanted:
            raise ValueError("existing static lexical state sequence changed")
    for uid, start in (("narration-unit-011", 14), ("narration-unit-012", 15)):
        items = by_unit[uid]
        fragment = audit["rows"][int(uid[-3:]) - 1]["fragments"][1]
        if (len(items) != 1 or items[0]["char_start"] != start
                or not items[0]["text"].startswith("write") or items[0]["char_end"] > fragment["char_end"]):
            raise ValueError("two-column write reveal cannot become a unit boundary")
    contrast = by_unit["narration-unit-020"]
    if len(contrast) != 1 or not 18 <= contrast[0]["char_start"] < contrast[0]["char_end"] <= 35:
        raise ValueError("u020 must reveal the spoken alternative, not the initial proposition")
    support = by_unit["narration-unit-041"]
    if [item["text"] for item in support] != ["emergency", "medical", "legal", "pastoral", "safeguarding"]:
        raise ValueError("u041 requires the five distinct literal support categories")


def read_visual_intent(reader, binding, units, caption_proof):
    """Metadata-only literal classification, not a source or calibration gate.

    The return value may inform a future A consumer only after the consumer pins
    this version and rechecks dependencies at its final return. Serialized flags
    cannot replace this independent read. SOURCE_PENDING never means source ready.
    """
    if not PLAN_BINDING or not EDITORIAL_SUPPLEMENT_BINDING:
        raise ValueError("BLOCKED: no frozen reviewed visual intent is registered")
    _binding(binding)
    _same(binding, PLAN_BINDING, "only the exact externally frozen visual plan is supported")
    dependencies = {}

    def read(bound):
        _binding(bound)
        _resident(reader.root, bound["path"])
        raw = reader.read(bound["path"], bound["sha256"])
        dependencies[bound["path"]] = {**copy.deepcopy(bound), "size_bytes": len(raw)}
        return raw

    code_root = Path(__file__).resolve().parents[1]
    code_dependencies = []
    for name in ("hero_engine/phase6_av_visual_intent.py", SCHEMA,
                 "hero_engine/phase6_av_caption_intent.py", "hero_engine/phase6_narration_audio_inventory.py",
                 "hero_engine/phase6_narration_units.py"):
        _resident(code_root, name)
        raw = (code_root / name).read_bytes()
        code_dependencies.append({"path": name, "sha256": bytes_sha(raw), "size_bytes": len(raw)})
    schema = _json((code_root / SCHEMA).read_bytes())
    plan = _json(read(binding))
    Draft202012Validator(schema).validate(plan)
    _same(plan["source_bindings"], {**SOURCE_BINDINGS, "editorial_supplement": EDITORIAL_SUPPLEMENT_BINDING},
          "visual plan source dependencies differ from the reviewed envelope")
    data = {key: _json(read(value)) for key, value in plan["source_bindings"].items()}
    supplement = data["editorial_supplement"]
    Draft202012Validator({"$ref": "#/$defs/supplement", "$defs": schema["$defs"]}).validate(supplement)
    _same(supplement["source_bindings"], SUPPLEMENT_SOURCE_BINDINGS, "editorial supplement source pins differ")
    supplement_sources = {}
    for key, value in supplement["source_bindings"].items():
        raw = read(value)
        if not value["path"].endswith(".py"):
            supplement_sources[key] = _json(raw)
    for value in (plan, supplement):
        _same(value["authority"], AUTHORITY, "literal plan cannot grant authority")
        if _integer(value["technical_cost_brl"], "cost") != 0:
            raise ValueError("literal inspection requires zero cost")
    expected_ids = [f"narration-unit-{index:03d}" for index in range(1, 52)]
    if (not isinstance(units, list) or len(units) != 51
            or [item.get("unit_id") for item in units] != expected_ids
            or [item["unit_id"] for item in plan["rows"]] != expected_ids
            or [item["unit_id"] for item in supplement["rows"]] != expected_ids):
        raise ValueError("exact ordered 51-unit population required")
    recomposed_caption = read_caption_intent(reader, CAPTION_PLAN, units)
    _same(caption_proof, recomposed_caption, "caption proof must recompose from the exact frozen literal source")
    for item in recomposed_caption["dependency_bindings"]:
        read({key: item[key] for key in ("path", "sha256")})
    d169, audit, take_plan = data["d169"], data["audit"], data["take_plan"]
    if len(audit["rows"]) != 51 or [item["unit_id"] for item in audit["rows"]] != expected_ids:
        raise ValueError("audit population differs")
    prior = {item["unit_id"]: (index, item) for index, item in enumerate(d169["decisions"])}
    if len(prior) != 29:
        raise ValueError("D169 decision population differs")
    negative = {uid for uid, (_, item) in prior.items() if item["lexical_requirement"] is None}
    if len(negative) != 25:
        raise ValueError("D169 nonlexical population differs")
    takes = {item["take_id"]: item for item in take_plan["takes"]}
    seen_states, fragments, lexical, by_unit = set(), [], [], {}
    for index, (row, decision, unit) in enumerate(zip(plan["rows"], supplement["rows"], units, strict=True)):
        uid = row["unit_id"]
        if (row["text"] != unit["text"] or row["text_sha256"] != unit["text_sha256"]
                or row["text_sha256"] != bytes_sha(row["text"].encode("utf-8"))):
            raise ValueError("visual unit text/hash differs from A")
        _same(row["fragment_ids"], unit["take_ids"], "visual unit fragment identity/order differs")
        if " ".join(takes[tid]["narration"] for tid in row["fragment_ids"]) != row["text"]:
            raise ValueError("visual unit does not preserve the complete literal fragment text")
        _reference(row["decision_reference"], EDITORIAL_SUPPLEMENT_BINDING, "rows", index)
        _same(row["states"], decision["states"], "visual states differ from the independently bound editorial supplement")
        reference = decision["prior_decision_reference"]
        if uid in prior:
            prior_index, old = prior[uid]
            _reference(reference, SOURCE_BINDINGS["d169"], "decisions", prior_index)
            if uid in negative:
                if decision["editorial_decision"] != old["editorial_decision"] or len(row["states"]) != 1:
                    raise ValueError("D169 negative decision cannot be rewritten or acquire internal reveals")
        elif reference is not None:
            _reference(reference, SOURCE_BINDINGS["audit"], "rows", index)
        if row["source_status"] != "SOURCE_PENDING" or row["quality_approved"] is not False:
            raise ValueError("literal intention cannot promote a visual source")
        fragments.extend(row["fragment_ids"])
        items = _state_entries(row, seen_states)
        by_unit[uid] = items
        lexical.extend(items)
        if uid == "narration-unit-003" and len(row["states"]) != 1:
            raise ValueError("the frozen hook is one composed source, not new lexical visual onsets")
        if uid == "narration-unit-016":
            if (row["fragment_ids"] != ["take-020", "take-021"] or len(row["states"]) != 2
                    or row["states"][1]["entry"]["kind"] != "CONTINUE_STATE"):
                raise ValueError("u016 must preserve the exact take020/021 unchanged continuation")
    if fragments != [f"take-{index:03d}" for index in range(1, 91)]:
        raise ValueError("all 90 fragments must occur exactly once in order")
    if " ".join(row["text"] for row in plan["rows"]) != data["narrative_script"]["full_text"]:
        raise ValueError("visual plan does not preserve the complete narrative script")
    _required_anchors(by_unit, d169, supplement_sources["static_intent"], audit)
    visual_ids = sorted(uid for uid, items in by_unit.items() if items)
    if not (REQUIRED_VISUAL_IDS | ADDITIONAL_EDITORIAL_IDS) <= set(visual_ids) or set(visual_ids) & negative:
        raise ValueError("known positive or negative visual lexical decisions disappeared")
    union = sorted(set(visual_ids) | set(recomposed_caption["lexical_unit_ids"]))
    # Historical lower bound is reopened, never treated as a completeness flag.
    if not set(d169["known_target_union_lower_bound"]) <= set(union):
        raise ValueError("visual/caption union cannot omit a historical D169 target")
    result = {
        "adapter_version": VERSION, "status": "LITERAL_INTENT_IDENTIFIED_SOURCES_AND_TIMING_PENDING",
        "source_binding": copy.deepcopy(binding), "editorial_supplement_binding": copy.deepcopy(EDITORIAL_SUPPLEMENT_BINDING),
        "caption_inspection_sha256": canonical_sha(recomposed_caption),
        "unit_count": 51, "fragment_count": len(fragments), "state_count": len(seen_states),
        "visual_lexical_unit_ids": visual_ids, "visual_lexical_ranges": lexical,
        "caption_lexical_unit_ids": copy.deepcopy(recomposed_caption["lexical_unit_ids"]),
        "temporal_target_unit_ids": union, "d169_negative_unit_ids": sorted(negative),
        "literal_visual_coverage_complete": True, "unknown_intent_unit_ids": [],
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
        "authority": copy.deepcopy(AUTHORITY), "technical_cost_brl": 0,
        "rows": copy.deepcopy(plan["rows"]), "implementation_dependencies": code_dependencies,
        "limitations": ["Literal planning does not validate source media, duration, movement, semantics in rendered frames or rights.",
            "No sample/frame/word time is created; calibration and scheduling remain separate.",
            "The former cohort30 is not repaired by identifying this target population."]}
    for item in list(dependencies.values()):
        raw = read({key: item[key] for key in ("path", "sha256")})
        if len(raw) != item["size_bytes"]:
            raise ValueError("visual intent dependency changed during inspection")
    for item in code_dependencies:
        _resident(code_root, item["path"])
        raw = (code_root / item["path"]).read_bytes()
        if bytes_sha(raw) != item["sha256"] or len(raw) != item["size_bytes"]:
            raise ValueError("visual intent implementation changed during inspection")
    result["dependency_bindings"] = sorted(dependencies.values(), key=lambda item: item["path"])
    return result
