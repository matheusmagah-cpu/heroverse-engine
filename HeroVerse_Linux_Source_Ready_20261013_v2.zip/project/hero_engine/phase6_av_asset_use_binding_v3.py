"""Join the fixed 41 untimed asset uses to independently recomposed V6 rows.

No temporal spans, word onsets or Stage-B admission follow from this mapping.
The previous V5 joiner is preserved and continues rejecting the new contract.
"""
from __future__ import annotations

import copy
from pathlib import Path
import re

from . import phase6_av_static_sources as sources
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-asset-use-binding-v3"
PATH = "hero_engine/phase6_av_asset_use_binding_v3.py"
COVERED = tuple(sorted(
    [f"visual-u{unit}-s{index:02d}" for unit in ("005", "006", "007") for index in (0, 1)]
    + [f"visual-u034-s{index:02d}" for index in range(5)]
    + ["visual-u044-s00", "visual-u045-s00", "visual-u010-s00", "visual-u011-s00", "visual-u011-s01",
       "visual-u012-s00", "visual-u012-s01", "visual-u013-s00", "visual-u014-s00", "visual-u015-s00",
       "visual-u016-s00", "visual-u016-s01", "visual-u017-s00", "visual-u018-s00",
       "visual-u019-s00", "visual-u020-s00", "visual-u020-s01", "visual-u021-s00",
       "visual-u032-s00", "visual-u033-s00", "visual-u035-s00", "visual-u047-s00", "visual-u048-s00", "visual-u049-s00",
       "visual-u036-s00", "visual-u037-s00", "visual-u037-s01", "visual-u038-s00", "visual-u038-s01", "visual-u038-s02"]))
AUTHORITY = dict.fromkeys(("timing", "source_admitted", "quality", "publicity", "render", "queue", "publication"), False)
_same = sources._same


def validate_binding(binding):
    if (type(binding) is not dict or set(binding) != {"path", "sha256"} or
            type(binding["path"]) is not str or not binding["path"] or "\\" in binding["path"] or ":" in binding["path"] or
            any(part in ("", ".", "..") for part in binding["path"].split("/")) or
            type(binding["sha256"]) is not str or re.fullmatch(r"sha256:[a-f0-9]{64}", binding["sha256"]) is None or
            Path(binding["path"]).drive or Path(binding["path"]).root):
        raise ValueError("caller-pinned root-relative literal asset-use binding required")


def amendment_evidence(literal):
    if type(literal) is not dict or literal.get("adapter_version") != "phase6-av-body-case-amendment-v1":
        raise ValueError("literal asset uses require independently amended V6 visual intent")
    return {"adapter_version": literal["adapter_version"], "inspection_sha256": canonical_sha(literal),
        "effective_rows_sha256": canonical_sha(literal["rows"]), "changed_state_count": 21, "changed_string_count": 24,
        "unmodified_state_count": 79, "prior_case_inspection_sha256": canonical_sha(literal["prior_case_inspection"]),
        "source_ready": False, "global_schedule_created": False}


def prior_amendment_evidence(literal):
    prior = literal["prior_case_inspection"]
    if prior.get("adapter_version") != "phase6-av-question-case-amendment-v1":
        raise ValueError("historical V5 inspection required separately from V6")
    return {"adapter_version": prior["adapter_version"], "inspection_sha256": canonical_sha(prior),
        "effective_rows_sha256": canonical_sha(prior["rows"]), "changed_state_count": 2, "unmodified_state_count": 98,
        "prior_amendment_inspection_sha256": canonical_sha(prior["prior_amendment_inspection"]),
        "source_ready": False, "global_schedule_created": False}


def join(proof, binding, literal):
    """Pure join only; the caller must obtain proof through the V4 inspector."""
    validate_binding(binding)
    current = amendment_evidence(literal)
    _same([proof[key] for key in ("version", "status", "channel_id", "video_id", "source_count", "use_count",
        "unique_png_content_count", "lineage_count", "source_ready", "global_schedule_created", "calibrated_timing_available",
        "authority", "technical_cost_brl")],
        ["phase6-av-static-asset-uses-v4", "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY", sources.CHANNEL,
         "video-002", 39, 41, 37, 3, False, False, False, AUTHORITY, 0], "literal asset-use scope or authority differs")
    _same(proof["input_binding"], {"path": binding["path"], "sha256": binding["sha256"][7:]}, "literal use input differs")
    _same(proof["visual_amendment_evidence"], current, "current V6 amendment evidence differs")
    _same(proof["prior_visual_amendment_evidence"], prior_amendment_evidence(literal), "historical V5 amendment evidence differs")
    indexed = {}
    for row in literal["rows"]:
        for state in row["states"]:
            if state["state_id"] in indexed:
                raise ValueError("duplicate literal visual state")
            indexed[state["state_id"]] = (row, state)
    if len(indexed) != 100 or type(proof["uses"]) is not list:
        raise ValueError("exact literal visual population required")
    if type(proof["sources"]) is not list or len(proof["sources"]) != 39:
        raise ValueError("exact39 source rows required")
    source_map = {row["source_id"]: row for row in proof["sources"]}
    _same([len(source_map), len({row["asset_binding"]["sha256"] for row in proof["sources"]}),
        len({row["lineage_id"] for row in proof["sources"]})], [39, 37, 3], "source identities or lineages differ")
    _same(sorted(use["visual_state_id"] for use in proof["uses"]), list(COVERED), "literal use coverage differs")
    for use in proof["uses"]:
        row, state = indexed[use["visual_state_id"]]
        _same([use["unit_id"], use["literal_copy"], use["entry"]],
            [row["unit_id"], state["visual_content"]["literal_copy"], state["entry"]], "literal use entry, copy or unit differs from Stage A")
        if use["source_id"] not in source_map:
            raise ValueError("use refers to an unbound source")
        _same(use["source_provenance_unit_id"], source_map[use["source_id"]]["original_unit_id"], "use source provenance unit differs")
    remaining = sorted(set(indexed) - set(COVERED))
    _same(proof["remaining_unbound_visual_state_ids"], remaining, "unbound visual states disappeared")
    if len(remaining) != 59:
        raise ValueError("exact fifty-nine unbound states required")
    return {"adapter_version": VERSION, "scope": "UNTIMED_ASSET_USE_METADATA_ONLY",
        "source_binding": copy.deepcopy(binding), "inspection_sha256": canonical_sha(proof),
        "use_rows_sha256": canonical_sha(proof["uses"]), "effective_rows_sha256": canonical_sha(literal["rows"]),
        "source_count": 39, "use_count": 41, "unique_png_content_count": 37, "lineage_count": 3,
        "visual_state_count": 100, "bound_visual_state_ids": list(COVERED), "remaining_unbound_visual_state_ids": remaining,
        "source_ready": False, "global_schedule_created": False, "calibrated_timing_available": False,
        "authority": dict(AUTHORITY), "technical_cost_brl": 0}


def read_asset_use_binding(reader, binding, literal, *, proof_sink):
    """Fresh same-call sink only; no serialized proof input or hidden retry."""
    validate_binding(binding)
    if type(proof_sink) is not list or proof_sink:
        raise ValueError("fresh same-call asset-use proof sink required")
    amendment_evidence(literal)
    from . import phase6_av_static_asset_uses_v4 as uses
    sources._resident(reader.root / binding["path"])
    reader.read(binding["path"], binding["sha256"])
    proof = uses.inspect_static_asset_uses(reader.root, binding={"path": binding["path"], "sha256": binding["sha256"][7:]})
    result = join(proof, binding, literal)
    for item in proof["dependency_bindings"]:
        path = Path(item["path"])
        if path.is_relative_to(reader.root):
            sources._resident(path)
            raw = reader.read(path.relative_to(reader.root).as_posix(), "sha256:" + item["sha256"])
            if len(raw) != item["size_bytes"]:
                raise ValueError("literal use dependency size changed")
    uses.recheck_asset_use_dependencies(reader.root, [proof])
    proof_sink.append(proof)
    return result
