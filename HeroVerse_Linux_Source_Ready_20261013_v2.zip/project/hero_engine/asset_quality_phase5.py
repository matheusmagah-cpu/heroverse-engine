from __future__ import annotations

import hashlib
import copy
import json
import re
import shutil
import subprocess
import inspect
import threading
from contextlib import ExitStack, closing, contextmanager
from contextvars import ContextVar
from functools import wraps
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe"
BLOCKED_BY_VISUAL_REVIEW = {
    "asset-commons-5e179ec59754f50784": "Embedded documentary text/static satellite sequence conflicts with the original narrative and produced long freeze events.",
}

# Only an invocation may reuse an authenticated parse. Native read handles
# prevent writes/deletes until that invocation finishes; no caller supplies a
# PASS, and no proof survives the scope or crosses a thread/root boundary.
_typography_scope = ContextVar('hero_typography_read_scope', default=None)


@contextmanager
def typography_read_scope(root: Path):
    root = root.resolve()
    prior = _typography_scope.get()
    if prior is not None and prior['root'] == root:
        if not prior['active'] or prior['thread'] != threading.get_ident():
            raise PermissionError('typography read scope is expired or foreign')
        yield
        return
    with ExitStack() as stack:
        state = {'root': root, 'thread': threading.get_ident(), 'active': True,
                 'stack': stack, 'proofs': {}, 'revalidate': []}
        token = _typography_scope.set(state)
        try:
            yield
            for check in state['revalidate']:
                check()
        finally:
            state['active'] = False
            state['proofs'].clear()
            _typography_scope.reset(token)


def scoped_typography_reads(function):
    """Batch the existing reader only for the duration of this consumer."""
    signature = inspect.signature(function)
    @wraps(function)
    def invoke(*args, **kwargs):
        arguments = signature.bind(*args, **kwargs)
        arguments.apply_defaults()
        with typography_read_scope(arguments.arguments['root']):
            return function(*args, **kwargs)
    return invoke


def _read_typography_content(root: Path, path: Path, expected_hash: str):
    from .phase6_visual_typography import read_typography_content_audit
    state = _typography_scope.get()
    root, path = root.resolve(), path.resolve()
    if state is None:
        return read_typography_content_audit(root, path, expected_sha256=expected_hash)
    if not state['active'] or state['root'] != root or state['thread'] != threading.get_ident():
        raise PermissionError('typography read scope is expired or foreign')
    key = (path, expected_hash)
    if key in state['proofs']:
        for check in state['revalidate']:
            check()
        return state['proofs'][key]
    checked = read_typography_content_audit(root, path, expected_sha256=expected_hash)
    from . import maintenance_protocol as protocol
    from .phase6_assets import _protected_font_dependency
    # Pin the audit before obtaining its implementation bindings. The canonical
    # reader already validated their exact identities; the anchored bytes below
    # bind the same implementations, not newly accepted hashes.
    protocol._paused_cancel_safe_path(root, path)
    audit_pin = state['stack'].enter_context(closing(protocol._PausedCancelPin(path, capture=False)))
    if _sha256(path) != expected_hash:
        raise PermissionError('typography audit changed before protection')
    # The official reader separates authenticated historical producers from
    # current code. Pin its current population plus the archived source files;
    # never apply historical hashes to evolved live executable paths.
    implementations = checked['current_implementations']
    from . import phase6_visual_typography, phase6_visual_metrics, procedural_infographics_phase5, phase6_visual_recipe
    code_paths = {Path(module.__file__).resolve() for module in
                  (phase6_visual_typography, phase6_visual_metrics, procedural_infographics_phase5, phase6_visual_recipe)}
    if {Path(item['path']).resolve() for item in implementations} != code_paths:
        raise PermissionError('typography evaluator population differs')
    state['revalidate'].append(audit_pin.revalidate)
    fonts = {Path(layout[k]['path']).resolve() for layout in checked['source']['layouts'].values()
             for k in ('font', 'composition_font')}
    files = {}
    for binding in [*checked['files'], *checked['source']['verified_bindings'], *implementations]:
        target = Path(binding['path']).resolve()
        if target in files and files[target] != binding['sha256']:
            raise PermissionError('typography protected bindings conflict')
        files[target] = binding['sha256']
    for target, digest in files.items():
        if target == path:
            if digest != expected_hash:
                raise PermissionError('typography audit binding conflicts')
            continue
        if target.is_relative_to(root) or target in code_paths:
            if target.is_relative_to(root):
                protocol._paused_cancel_safe_path(root, target)
            pin = state['stack'].enter_context(closing(protocol._PausedCancelPin(target, capture=False)))
            if _sha256(target) != digest:
                raise PermissionError('typography dependency changed before protection')
            state['revalidate'].append(pin.revalidate)
        elif target in fonts:
            state['revalidate'].append(state['stack'].enter_context(_protected_font_dependency(target, digest)))
        else:
            raise PermissionError('typography read scope has a foreign dependency')
    for check in state['revalidate']:
        check()
    state['proofs'][key] = checked
    return checked


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration:stream=width,height", "-of", "json", str(path)],
        text=True, encoding="utf-8", errors="replace", capture_output=True,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    return json.loads(result.stdout)


def _scan(path: Path) -> dict[str, Any]:
    result = subprocess.run(
        [
            FFMPEG, "-hide_banner", "-nostats", "-i", str(path), "-vf",
            "scale=480:-2,blackdetect=d=0.20:pix_th=0.08,freezedetect=n=-45dB:d=0.75",
            "-an", "-f", "null", "NUL",
        ],
        text=True, encoding="utf-8", errors="replace", capture_output=True,
    )
    if result.returncode:
        raise RuntimeError(result.stderr[-2000:])
    black = [
        (float(start), float(end))
        for start, end in re.findall(r"black_start:([0-9.]+) black_end:([0-9.]+)", result.stderr)
    ]
    freeze_starts = [float(value) for value in re.findall(r"lavfi\.freezedetect\.freeze_start: ([0-9.]+)", result.stderr)]
    freeze_ends = [float(value) for value in re.findall(r"lavfi\.freezedetect\.freeze_end: ([0-9.]+)", result.stderr)]
    freeze = list(zip(freeze_starts, freeze_ends))
    scene_threshold = 0.25
    scene_result = subprocess.run(
        [
            FFMPEG, "-hide_banner", "-nostats", "-filter_threads", "1", "-i", str(path),
            "-vf", f"scale=480:-2,select='gt(scene,{scene_threshold})',showinfo",
            "-an", "-f", "null", "NUL",
        ],
        text=True, encoding="utf-8", errors="replace", capture_output=True,
    )
    if scene_result.returncode:
        raise RuntimeError(scene_result.stderr[-2000:])
    scene_boundaries = sorted(
        {
            round(float(value), 3)
            for value in re.findall(r"pts_time:([0-9.]+)", scene_result.stderr)
            if float(value) > 0.0
        }
    )
    return {
        "black_intervals_seconds": black,
        "freeze_intervals_seconds": freeze,
        "scene_boundary_seconds": scene_boundaries,
        "scene_detection_threshold": scene_threshold,
    }


def _merge(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
    merged: list[tuple[float, float]] = []
    for start, end in sorted(intervals):
        if not merged or start > merged[-1][1]:
            merged.append((start, end))
        else:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
    return merged


def _safe_ranges(duration: float, scan: dict[str, Any]) -> list[dict[str, int]]:
    exclusions = []
    for start, end in [*scan["black_intervals_seconds"], *scan["freeze_intervals_seconds"]]:
        exclusions.append((max(0.0, start - 0.35), min(duration, end + 0.35)))
    for boundary in scan.get("scene_boundary_seconds", []):
        # A take is one continuous shot. The padding prevents an imprecise seek
        # from landing on either side of an edit already present in the source.
        exclusions.append((max(0.0, boundary - 0.25), min(duration, boundary + 0.25)))
    exclusions = _merge(exclusions)
    cursor = min(2.0, max(0.0, duration - 0.5))
    safe: list[dict[str, int]] = []
    for start, end in exclusions:
        if start - cursor >= 2.0:
            safe.append({"start_ms": round(cursor * 1000), "end_ms": round(start * 1000)})
        cursor = max(cursor, end)
    if duration - 0.5 - cursor >= 2.0:
        safe.append({"start_ms": round(cursor * 1000), "end_ms": round((duration - 0.5) * 1000)})
    return safe


def _candidate_record(package_dir: Path, asset_id: str) -> dict[str, Any]:
    evidence_path = package_dir / "rights_evidence" / f"{asset_id}.json"
    evidence = _read_json(evidence_path)
    meta = evidence["raw_selected_metadata"]
    media_path = package_dir / "assets" / f"{asset_id}.webm"
    probe = _probe(media_path)
    stream = probe["streams"][0]
    attribution = None
    if meta.get("attribution_required"):
        attribution = f"{meta['title'].removeprefix('File:')} — {meta.get('creator') or 'Unknown creator'}; {meta['license_short']}; {meta['description_url']}"
    return {
        "asset_id": asset_id,
        "semantic_role": evidence["semantic_role"],
        "uri": str(media_path.resolve()),
        "content_hash": _sha256(media_path),
        "source": evidence["source_page"],
        "creator_or_holder": meta.get("creator") or "Unknown",
        "rights_status": meta["rights_status"],
        "license": meta["license_short"],
        "license_version": meta.get("license_version"),
        "commercial_use": True,
        "production_eligible": True,
        "attribution": attribution,
        "restrictions": [],
        "rights_evidence_uri": str(evidence_path.resolve()),
        "verified_at": evidence["verified_at"],
        "rights_decision": evidence["decision"],
        "duration_seconds": round(float(probe["format"]["duration"]), 3),
        "width": int(stream["width"]),
        "height": int(stream["height"]),
        "used_ranges": [],
    }


def _pinned_json(root: Path, path: Path, expected: str) -> dict[str, Any]:
    path=path.resolve()
    if root.resolve() not in path.parents:raise PermissionError('quality evidence outside project root')
    raw=path.read_bytes()
    if 'sha256:'+hashlib.sha256(raw).hexdigest()!=expected:
        raise PermissionError('quality evidence anchor differs')
    return json.loads(raw)


def _content_admitted_asset(asset, *, safe_ranges, report_path, report_hash):
    updated=copy.deepcopy(asset)
    updated.update(production_eligible=True,content_quality_gate='PASS',safe_ranges=safe_ranges,
        content_quality_evidence=str(report_path),
        typography_content_admission={'path':str(report_path),'sha256':report_hash},
        restrictions=['Source conformance only; use only the bound take and observed steady ranges. Final-video gates remain required.'])
    return updated


def _static_source_observation(source):
    layout = source['layout']
    return {'composition_id': layout['composition_id'],
            'minimum_font_size': min(row['font_size'] for row in layout['texts']),
            'safe_area_pass': all(row['safe_area_pass'] for row in layout['texts']),
            'copy_preserved': all(row['copy_preserved'] for row in layout['texts']),
            'raster_bounds': source['produced']['raster_bounds'],
            'palette': layout['palette'], 'canvas': layout['canvas']}


def _admitted_static_asset(asset, path, digest):
    value = copy.deepcopy(asset)
    value.update(production_eligible=True, content_quality_gate='PASS',
        static_content_admission={'path': str(path), 'sha256': digest},
        restrictions=['Owned static source conformance only; final audio/video QA and release gates still required.'])
    return value


def admit_audio_static_source(root: Path, *, asset_path: Path, expected_asset_hash: str,
                             destination: Path, created_at: str) -> dict:
    """Existing source-admission layer, explicit static scope, no release PASS."""
    from .phase6_asset_residency import validate_phase6_rights_evidence, _write_immutable
    from .procedural_infographics_phase5 import read_audio_static_source
    root, destination = root.resolve(), destination.resolve()
    if not destination.is_relative_to(root) or destination.exists():
        raise PermissionError('static admission requires a new confined output')
    asset = _pinned_json(root, asset_path.resolve(), expected_asset_hash)
    if (asset.get('production_eligible') is not False or asset.get('content_quality_gate') != 'BLOCKED'
            or any(asset.get(k) is not False for k in ('quality_authorized','render_authorized','publication_authorized'))):
        raise PermissionError('static source must start held with release authorities false')
    rights_path = Path(asset['rights_evidence_uri']).resolve()
    rights_hash = _sha256(rights_path)
    evidence = _pinned_json(root, rights_path, rights_hash)
    if evidence.get('decision') != 'AUTO_VERIFIED_PROCEDURAL_SOURCE':
        raise PermissionError('static admission requires reproducible procedural provenance')
    validate_phase6_rights_evidence(root, asset, evidence, media_path=Path(asset['uri']))
    ref = evidence['composition_manifest']
    source = read_audio_static_source(root, Path(ref['path']), expected_sha256=ref['sha256'])
    observation = _static_source_observation(source)
    if (observation['minimum_font_size'] < 54 or not observation['safe_area_pass']
            or not observation['copy_preserved'] or observation['canvas'] != {'width':1920,'height':1080}):
        raise PermissionError('static source layout conformance failed')
    report = {'version':'audio-static-source-admission-v1','status':'PASS_SOURCE_ALLOCATION_SCOPE',
        'base_asset':{'path':str(asset_path.resolve()),'sha256':expected_asset_hash},
        'rights':{'path':str(rights_path),'sha256':rights_hash},
        'source_manifest':ref,'observation':observation,'created_at':created_at,
        'render_authorized':False,'publication_authorized':False,'final_video_quality_authorized':False}
    if _sha256(asset_path) != expected_asset_hash or _sha256(rights_path) != rights_hash:
        raise PermissionError('static admission inputs changed before publication')
    _write_immutable(destination, report)
    admitted = _admitted_static_asset(asset, destination, _sha256(destination))
    verify_audio_static_asset_admission(root, admitted)
    return admitted


def verify_audio_static_asset_admission(root: Path, asset: dict) -> dict:
    from .procedural_infographics_phase5 import read_audio_static_source
    binding = asset.get('static_content_admission') or {}
    report = _pinned_json(root, Path(binding.get('path','')).resolve(), binding.get('sha256',''))
    if (report.get('version') != 'audio-static-source-admission-v1'
            or report.get('status') != 'PASS_SOURCE_ALLOCATION_SCOPE'
            or any(report.get(k) is not False for k in
                   ('render_authorized','publication_authorized','final_video_quality_authorized'))):
        raise PermissionError('static source admission scope differs')
    base = report['base_asset']
    original = _pinned_json(root, Path(base['path']), base['sha256'])
    rights = report['rights']
    evidence = _pinned_json(root, Path(rights['path']), rights['sha256'])
    if (original['rights_evidence_uri'] != rights['path']
            or evidence.get('decision') != 'AUTO_VERIFIED_PROCEDURAL_SOURCE'
            or evidence.get('asset_id') != original['asset_id']
            or evidence['composition_manifest'] != report['source_manifest']):
        raise PermissionError('static admission provenance differs')
    ref = report['source_manifest']
    source = read_audio_static_source(root, Path(ref['path']), expected_sha256=ref['sha256'])
    observed = _static_source_observation(source)
    if (observed != report['observation'] or observed['minimum_font_size'] < 54
            or not observed['copy_preserved'] or not observed['safe_area_pass']
            or source['produced']['raster_hash'] != original['content_hash']
            or Path(source['produced']['raster']).resolve() != Path(original['uri']).resolve()):
        raise PermissionError('static admission measurement/source differs')
    expected = _admitted_static_asset(original, Path(binding['path']), binding['sha256'])
    if asset != expected: raise PermissionError('static admitted asset altered')
    if _sha256(Path(binding['path'])) != binding['sha256'] or _sha256(Path(base['path'])) != base['sha256']:
        raise PermissionError('static admission changed during verification')
    return {'status':'PASS_SOURCE_ALLOCATION_SCOPE','observation':observed,
            'render_authorized':False,'publication_authorized':False}


def verify_typography_asset_admission(root: Path, asset: dict[str, Any]) -> dict[str, Any]:
    """Read source-only admission at allocation/residency, without new media work."""
    binding=asset.get('typography_content_admission') or {}
    report_path=Path(binding.get('path','')).resolve()
    report=_pinned_json(root,report_path,binding.get('sha256',''))
    if (report.get('version')!='phase6-typography-source-admission-v1'
            or report.get('status')!='PASS_SOURCE_ALLOCATION_SCOPE'
            or report.get('render_authorized') is not False or report.get('publication_authorized') is not False
            or report.get('final_video_quality_authorized') is not False):
        raise PermissionError('source admission scope invalid')
    base=report['base_catalogue'];catalogue=_pinned_json(root,Path(base['path']),base['sha256'])
    targets=catalogue.get('typography_successor',{}).get('asset_ids',[])
    if not targets or report.get('asset_ids')!=targets or asset['asset_id'] not in targets:
        raise PermissionError('source admission population differs')
    original=[row for row in catalogue['assets'] if row['asset_id']==asset['asset_id']]
    if len(original)!=1:raise PermissionError('source admission identity missing/duplicated')
    original=original[0];proof=report['content_audit']
    if original.get('typography_quality_evidence')!={**proof,'scope':'SOURCE_CONTENT_CONFORMANCE_NOT_FINAL_VIDEO_QA'}:
        raise PermissionError('source admission audit differs from registered evidence')
    checked=_read_typography_content(root,Path(proof['path']),proof['sha256'])
    rights=[r for r in report.get('rights',[]) if r.get('asset_id')==asset['asset_id']]
    if (len(rights)!=1 or rights[0]['path']!=original['rights_evidence_uri']
            or _sha256(Path(rights[0]['path']))!=rights[0]['sha256']):
        raise PermissionError('source admission rights bytes differ')
    ranges=checked['safe_ranges'][asset['asset_id']]
    if sum(r['end_ms']-r['start_ms'] for r in ranges)<8000:
        raise PermissionError('source admission has less than existing eight-second capacity floor')
    expected=_content_admitted_asset(original,safe_ranges=ranges,report_path=report_path,report_hash=binding['sha256'])
    # Consumption may legitimately add bounded used ranges, never expand the
    # immutable admission, change its take, bytes, source or rights.
    used=asset.get('used_ranges',[])
    for item in used:
        if (set(item)!={'start_ms','end_ms'} or any(type(item[k]) is not int for k in item)
                or not any(r['start_ms']<=item['start_ms']<item['end_ms']<=r['end_ms'] for r in ranges)):
            raise PermissionError('source consumed range outside admission')
    expected['used_ranges']=used
    if asset!=expected:raise PermissionError('source admission record altered')
    if _sha256(report_path)!=binding['sha256'] or _sha256(Path(base['path']))!=base['sha256']:
        raise PermissionError('source admission changed during verification')
    # The authenticated scope owns its ranges; a caller must not mutate the
    # reference against which subsequent admissions are compared.
    return {'status':'PASS_SOURCE_ALLOCATION_SCOPE','take_scope':expected['take_scope'],
            'safe_ranges':copy.deepcopy(ranges)}


def _admit_typography_catalogue(root, *, catalogue_path, catalogue_hash, destination, created_at):
    from .phase6_asset_residency import _write_immutable, validate_phase6_rights_evidence
    from .phase6_visual_typography import read_typography_content_audit
    root=root.resolve();destination=destination.resolve();catalogue_path=catalogue_path.resolve()
    if root not in destination.parents or destination.exists():
        raise PermissionError('source admission requires a new confined output')
    baseline=_pinned_json(root,catalogue_path,catalogue_hash)
    targets=baseline.get('typography_successor',{}).get('asset_ids',[])
    selected=[a for a in baseline['assets'] if a['asset_id'] in targets]
    if not targets or len(set(targets))!=len(targets) or [a['asset_id'] for a in selected]!=targets:
        raise PermissionError('source admission requires exact successor population')
    refs=[a.get('typography_quality_evidence') or {} for a in selected]
    if any(r!=refs[0] for r in refs) or refs[0].get('scope')!='SOURCE_CONTENT_CONFORMANCE_NOT_FINAL_VIDEO_QA':
        raise PermissionError('source admission requires anchored full-content observation')
    proof={k:refs[0][k] for k in ('path','sha256')}
    checked=read_typography_content_audit(root,Path(proof['path']),expected_sha256=proof['sha256'])
    if [a['asset_id'] for a in checked['source']['manifest']['assets']]!=targets:
        raise PermissionError('source admission proof population differs')
    rights=[]
    for asset in selected:
        if (asset.get('production_eligible') is not False or asset.get('content_quality_gate')!='BLOCKED'
                or asset.get('safe_ranges')!=[] or asset.get('used_ranges')!=[]):
            raise PermissionError('only unconsumed held successor sources can be admitted')
        path=Path(asset['rights_evidence_uri']);raw=path.read_bytes();evidence=json.loads(raw)
        validate_phase6_rights_evidence(root,asset,evidence,media_path=Path(asset['uri']))
        ranges=checked['safe_ranges'][asset['asset_id']]
        if sum(r['end_ms']-r['start_ms'] for r in ranges)<8000:
            raise PermissionError('source admission has less than existing eight-second capacity floor')
        rights.append({'asset_id':asset['asset_id'],'path':str(path),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()})
    report={'version':'phase6-typography-source-admission-v1','status':'PASS_SOURCE_ALLOCATION_SCOPE',
        'base_catalogue':{'path':str(catalogue_path),'sha256':catalogue_hash},'content_audit':proof,
        'asset_ids':targets,'rights':rights,'created_at':created_at,
        'render_authorized':False,'publication_authorized':False,'final_video_quality_authorized':False}
    destination.mkdir(parents=True,exist_ok=False)
    report_path=destination/'asset_quality_report.json'
    raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    report_hash='sha256:'+hashlib.sha256(raw).hexdigest()
    _write_immutable(report_path,report)
    if report_path.read_bytes()!=raw:raise PermissionError('source admission report changed before binding')
    manifest=copy.deepcopy(baseline)
    manifest['assets']=[_content_admitted_asset(a,safe_ranges=checked['safe_ranges'][a['asset_id']],
        report_path=report_path,report_hash=report_hash) if a['asset_id'] in targets else a for a in manifest['assets']]
    for asset in manifest['assets']:
        if asset['asset_id'] in targets:verify_typography_asset_admission(root,asset)
    if _sha256(catalogue_path)!=catalogue_hash:raise PermissionError('source catalogue changed before commit')
    _write_immutable(destination/'asset_manifest.json',manifest)
    return manifest


def scan_and_update_asset_manifest(root: Path, *, created_at: str | None = None,
        typography_catalogue: Path | None = None, expected_catalogue_sha256: str | None = None,
        successor_directory: Path | None = None) -> dict[str, Any]:
    if any(v is not None for v in (typography_catalogue,expected_catalogue_sha256,successor_directory)):
        if any(v is None for v in (typography_catalogue,expected_catalogue_sha256,successor_directory)):
            raise PermissionError('complete anchored source-admission request required')
        return _admit_typography_catalogue(root,catalogue_path=typography_catalogue,
            catalogue_hash=expected_catalogue_sha256,destination=successor_directory,
            created_at=created_at or datetime.now(timezone.utc).isoformat())
    timestamp = created_at or datetime.now(timezone.utc).isoformat()
    package_dir = root / "output" / "production" / "phase5" / "pilot-001"
    manifest_path = package_dir / "asset_manifest.json"
    manifest = _read_json(manifest_path)
    assets = {item["asset_id"]: item for item in manifest["assets"]}
    replacement_id = "asset-commons-7a427e1f1a265f0631"
    if replacement_id not in assets:
        assets[replacement_id] = _candidate_record(package_dir, replacement_id)
    reports = []
    for asset_id, asset in sorted(assets.items()):
        media_path = Path(asset["uri"])
        scan = _scan(media_path)
        safe_ranges = _safe_ranges(float(asset["duration_seconds"]), scan)
        safe_capacity_ms = sum(item["end_ms"] - item["start_ms"] for item in safe_ranges)
        blocked_reason = BLOCKED_BY_VISUAL_REVIEW.get(asset_id)
        status = "BLOCKED" if blocked_reason else "PASS" if safe_capacity_ms >= 8_000 else "LIMITED"
        asset["content_quality_gate"] = status
        asset["safe_ranges"] = safe_ranges
        asset["content_quality_evidence"] = "output/production/phase5/pilot-001/asset_quality_report.json"
        reports.append(
            {
                "asset_id": asset_id,
                "status": status,
                "forced_block_reason": blocked_reason,
                "safe_ranges": safe_ranges,
                "safe_capacity_ms": safe_capacity_ms,
                **scan,
            }
        )
    blocked_id = "asset-commons-5e179ec59754f50784"
    assets.pop(blocked_id, None)
    manifest["assets"] = [assets[key] for key in sorted(assets)]
    manifest["selected_count"] = len(manifest["assets"])
    prior_error = {"query": f"prior_asset:{blocked_id}", "error": "BLOCKED_BY_PROTOTYPE_VISUAL_AND_FREEZE_GATE; replaced by rights-audited waterfall asset"}
    manifest["errors"] = [item for item in manifest["errors"] if item.get("query") != prior_error["query"]]
    manifest["errors"].append(prior_error)
    temporary = manifest_path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(manifest_path)
    report = {
        "schema_version": "1.0.0",
        "report_id": "asset-quality-phase5-v1",
        "created_at": timestamp,
        "scanner": "ffmpeg-blackdetect-freezedetect-scene@0.25 + visual review finding",
        "asset_count": len(reports),
        "active_manifest_count": len(manifest["assets"]),
        "results": reports,
        "decision": {
            "blocked_asset_id": blocked_id,
            "replacement_asset_id": replacement_id,
            "reason": BLOCKED_BY_VISUAL_REVIEW[blocked_id],
        },
    }
    (package_dir / "asset_quality_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report
