from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import Any
from urllib.parse import unquote


# This list is deliberately conservative and only used to stop automatic
# publication. It is not a claim that every occurrence infringes a right.
INSTITUTIONAL_RISK_TERMS = (
    "adidas",
    "amazon",
    "apple inc",
    "artemis",
    "coca-cola",
    "coca cola",
    "disney",
    "marvel",
    "meta platforms",
    "microsoft",
    "nasa",
    "national aeronautics and space administration",
    "nike",
    "orion spacecraft",
    "pepsi",
    "space launch system",
    "spacex",
    "starbucks",
    "tesla",
)
YUNET_SHA256 = "ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0"


def metadata_publicity_risks(asset: dict[str, Any]) -> list[str]:
    """Return known institutional/endorsement risks visible in source metadata.

    Copyright status and publicity/trademark status are separate. A match blocks
    autonomous use until there is explicit scope-specific clearance or the asset
    is replaced; it never asserts infringement.
    """

    text = " ".join(
        unquote(str(asset.get(field) or ""))
        for field in ("source", "creator_or_holder")
    ).casefold()
    return sorted({term for term in INSTITUTIONAL_RISK_TERMS if term in text})


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    if path.is_file():
        return path
    parts = list(path.parts)
    for anchor in ("output", "assets", "models"):
        if anchor in parts:
            candidate = root.joinpath(*parts[parts.index(anchor) :])
            if candidate.is_file():
                return candidate
    return path if path.is_absolute() else root / path


def _sample_times(records: list[dict[str, Any]]) -> list[int]:
    times: list[int] = []
    for item in records:
        start = int(item.get("source_start_ms") or 0)
        end = int(item.get("source_end_ms") or start)
        if end > start:
            times.extend((start + 50, start + (end - start) // 2, max(start, end - 50)))
    return sorted(set(max(0, value) for value in times))[:9]


def _timestamp_frame(path: Path, time_ms: int) -> tuple[Any, dict[str, Any]]:
    """Bounded native timestamp decode only after OpenCV refused a sample."""
    import numpy as np
    from hero_engine.qa_phase5 import FFMPEG
    # Reuse the existing owned-child lifetime and strict PPM parser. This does
    # not reuse a detector attestation or confer that protocol's LIVE authority.
    from hero_engine.phase6_av_publicity_v2 import LIMITS, owned, ppm

    command = [
        FFMPEG, "-nostdin", "-v", "error", "-threads", "1",
        "-ss", f"{time_ms / 1000:.6f}", "-i", str(path), "-map", "0:v:0",
        "-an", "-sn", "-dn", "-filter_threads", "1", "-frames:v", "1",
        "-fps_mode", "passthrough", "-fs", str(LIMITS["maximum_frame_bytes"]),
        "-pix_fmt", "rgb24", "-c:v", "ppm", "-f", "image2pipe", "-",
    ]
    raw = owned(command, LIMITS["decode_timeout_seconds"])
    width, height, pixels = ppm(raw)
    image = np.frombuffer(pixels, np.uint8).reshape(height, width, 3)[:, :, ::-1].copy()
    return image, {
        "decoder": "FFMPEG_NATIVE_TIMESTAMP_PPM_V1", "timecode_ms": time_ms,
        "width": width, "height": height, "pixel_order": "RGB24",
        "pixel_sha256": hashlib.sha256(pixels).hexdigest(),
        "command": command, "timeout_seconds": LIMITS["decode_timeout_seconds"],
    }


def _frames_and_faces(
    root: Path, path: Path, sample_times_ms: list[int],
    *, decode_observations: list[dict[str, Any]] | None = None,
) -> tuple[int, int, list[str]]:
    import cv2
    import numpy as np

    model = root / "models/yunet/face_detection_yunet_2026may.onnx"
    if not model.is_file():
        return 0, 0, ["LOCAL_FACE_DETECTOR_UNAVAILABLE"]
    model_bytes = model.read_bytes()
    if hashlib.sha256(model_bytes).hexdigest() != YUNET_SHA256:
        return 0, 0, ["LOCAL_FACE_DETECTOR_HASH_MISMATCH"]

    frames = 0
    faces = 0
    errors: list[str] = []
    if path.suffix.casefold() in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
        image = cv2.imread(str(path))
        candidates = [image] if image is not None else []
    else:
        capture = cv2.VideoCapture(str(path))
        candidates = []
        try:
            for value in sample_times_ms or [0]:
                reason = "MEDIA_DECODE_OPEN_FAILED"
                ok, image = False, None
                if capture.isOpened():
                    capture.set(cv2.CAP_PROP_POS_MSEC, float(value))
                    ok, image = capture.read()
                    reason = f"FRAME_DECODE_FAILED_AT_{value}MS"
                if ok and image is not None:
                    candidates.append(image)
                else:
                    try:
                        image, observation = _timestamp_frame(path, value)
                    except (OSError, ValueError, RuntimeError) as exc:
                        errors.extend([reason, f"NATIVE_FRAME_DECODE_FAILED_AT_{value}MS:{type(exc).__name__}"])
                    else:
                        candidates.append(image)
                        if decode_observations is not None:
                            decode_observations.append({**observation, "fallback_reason": reason})
        finally:
            capture.release()

    if not candidates and not errors:
        errors.append("NO_DECODABLE_FRAME")
    if not candidates:
        return 0, 0, errors
    try:
        detector = cv2.FaceDetectorYN.create(
            "onnx",
            np.frombuffer(model_bytes, np.uint8),
            np.frombuffer(b"", np.uint8),
            (320, 320),
            0.80,
            0.30,
            5000,
        )
    except cv2.error as exc:
        return 0, 0, [f"LOCAL_FACE_DETECTOR_LOAD_FAILED:{exc.code}"]
    for image in candidates:
        height, width = image.shape[:2]
        if width > 1280:
            scale = 1280 / width
            image = cv2.resize(image, (1280, max(1, round(height * scale))))
        height, width = image.shape[:2]
        try:
            detector.setInputSize((width, height))
            _retval, detected = detector.detect(image)
        except cv2.error as exc:
            errors.append(f"FACE_DETECTION_FAILED:{exc.code}")
            continue
        frames += 1
        faces += 0 if detected is None else len(detected)
    return frames, faces, errors


def screen_publicity(
    root: Path,
    allocation: dict[str, Any],
    library: dict[str, Any],
) -> dict[str, Any]:
    """Fail-closed prepublication screen for people and institutional marks.

    This is a measurable risk screen, not legal advice and not an exhaustive logo
    recognizer. Automatic release is restricted to assets with decodable samples,
    no detected face, and no known institutional risk in source metadata.
    """

    root = root.resolve()
    assets = {item["asset_id"]: item for item in library.get("assets") or []}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for item in allocation.get("takes") or []:
        grouped.setdefault(str(item["asset_id"]), []).append(item)

    rows: list[dict[str, Any]] = []
    for asset_id, records in sorted(grouped.items()):
        asset = assets.get(asset_id)
        if asset is None:
            rows.append({
                "asset_id": asset_id,
                "status": "FAIL",
                "metadata_risk_terms": [],
                "sample_frame_count": 0,
                "detected_face_count": 0,
                "decode_errors": ["ASSET_NOT_IN_LIBRARY"],
                "clearance_basis": "NONE",
            })
            continue
        media = _resolve(root, str(asset.get("uri") or records[0].get("source_path") or ""))
        risks = metadata_publicity_risks(asset)
        decode_observations: list[dict[str, Any]] = []
        frames, faces, errors = _frames_and_faces(
            root, media, _sample_times(records), decode_observations=decode_observations,
        )
        evidence_path = _resolve(root, str(asset.get("rights_evidence_uri") or ""))
        evidence: dict[str, Any] = {}
        if evidence_path.is_file():
            try:
                evidence = json.loads(evidence_path.read_text(encoding="utf-8-sig"))
            except (OSError, json.JSONDecodeError):
                errors.append("RIGHTS_EVIDENCE_UNREADABLE")
        prompt_scope = str(evidence.get("prompt_scope") or "").casefold()
        original_controlled = bool(
            asset_id.startswith("asset-owned-")
            and (
                "no " in prompt_scope
                or str(asset.get("license") or "").casefold() == "project-owned original procedural work"
            )
        )
        passed = bool(frames > 0 and faces == 0 and not risks and not errors)
        rows.append({
            "asset_id": asset_id,
            "status": "PASS" if passed else "FAIL",
            "metadata_risk_terms": risks,
            "sample_frame_count": frames,
            "detected_face_count": faces,
            "decode_errors": errors,
            "native_decode_fallbacks": decode_observations,
            "clearance_basis": "CONTROLLED_ORIGINAL_PLUS_VISUAL_SCREEN" if original_controlled else "LOW_RISK_SOURCE_PLUS_VISUAL_SCREEN",
        })

    failed = [item["asset_id"] for item in rows if item["status"] != "PASS"]
    return {
        "method": "source-metadata institutional-risk denylist plus local OpenCV FaceDetectorYN/YuNet scan over every allocated source range",
        "used_asset_count": len(grouped),
        "screened_asset_count": len(rows),
        "sample_frame_count": sum(item["sample_frame_count"] for item in rows),
        "detected_face_count": sum(item["detected_face_count"] for item in rows),
        "metadata_risk_asset_count": sum(bool(item["metadata_risk_terms"]) for item in rows),
        "decode_failure_asset_count": sum(bool(item["decode_errors"]) for item in rows),
        "failed_asset_ids": failed,
        "assets": rows,
        "passed": bool(rows and not failed),
        "claim_boundary": "This automated screen reduces release risk but does not prove the absence of every logo, likeness, property right or jurisdiction-specific claim. Any detected person, institution or ambiguity blocks autonomous publication and triggers replacement or documented external review.",
    }
