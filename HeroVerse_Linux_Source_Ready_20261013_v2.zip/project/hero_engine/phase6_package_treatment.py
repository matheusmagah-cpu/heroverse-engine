from __future__ import annotations

import hashlib
import io
import json
import os
import re
import time
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

from jsonschema import Draft202012Validator, FormatChecker
from PIL import Image, ImageStat

from .atomic_io import atomic_write_utf8
from .phase6_publication import refresh_channel_readiness
from .render_creative_v3_phase5 import _render_thumbnail
from .render_creative_v2_phase5 import _font
from .youtube_integration import INTEGRATION_SCOPES
from .zero_cost_guard import evaluate_zero_cost


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
PROTOCOL = Path("output/operations/phase6/intelligence/experiments/latest.json")
ACTIVE_PROTOCOL = Path("output/operations/phase6/intelligence/experiments/active.json")
INPUTS = Path("output/operations/phase6/release/latest-production-inputs-receipt.json")
PACKAGING_EVALUATION = Path("output/production/phase6/canary-package-update/evaluation/packaging_evaluation.json")
VARIANTS = Path("output/production/phase6/canary-package-update/preproduction/packaging_variants.json")
BASELINE_PACKAGE = Path("output/production/phase5/pilot-001/creative-v3/publication_package.json")
BASELINE_RECEIPT = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
CHANNEL_DNA = Path("output/modeling/phase4/channel-model-v1/channel_model.json")
PACKAGE_ROOT = Path("output/production/phase6/canary-package-update")
CANDIDATE = PACKAGE_ROOT / "render/package_candidate.json"
QUALITY = PACKAGE_ROOT / "quality/independent_package_quality_evaluation.json"
RELEASE = PACKAGE_ROOT / "publication/package_release_gate.json"
PUBLICATION_RECEIPT = PACKAGE_ROOT / "publication/youtube-package-update-receipt.json"
RUNTIME = Path("output/operations/phase6/package-treatment-executor-status.json")
QUOTA_ACCOUNTING = Path("output/operations/zero-cost/phase6-canary-package-quota-accounting.json")
QUOTA_PREFLIGHT = Path("output/operations/zero-cost/phase6-canary-package-update-preflight.json")
AUTHORIZED_METHODS = {"channels.list", "videos.list", "videos.update(snippet)", "thumbnails.set"}
PACIFIC = ZoneInfo("America/Los_Angeles")
BOUNDARY_TOLERANCE_SECONDS = 180
PRE_PREREGISTRATION_STATUSES = {"WAITING_FOR_24H_BASELINE", "READY_TO_PREREGISTER"}


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def _write_runtime_view(path: Path, value: dict[str, Any]) -> None:
    atomic_write_utf8(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _resolve(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    Draft202012Validator(
        _read(root / "schemas" / schema_name), format_checker=FormatChecker()
    ).validate(value)


def _active_protocol(root: Path) -> dict[str, Any]:
    latest = root / PROTOCOL
    active = root / ACTIVE_PROTOCOL
    if not latest.is_file() or not active.is_file():
        raise FileNotFoundError("active preregistered protocol is unavailable")
    if latest.read_bytes() != active.read_bytes():
        raise PermissionError("active/latest protocol divergence")
    protocol = _read(active)
    _validate(root, "phase6_experiment_protocol.schema.json", protocol)
    if protocol.get("status") != "PREREGISTERED":
        raise PermissionError("active protocol is not preregistered")
    return protocol


def _is_legitimate_pre_preregistration(protocol: dict[str, Any]) -> bool:
    status = protocol.get("status")
    baseline = protocol.get("baseline") or {}
    treatment = protocol.get("treatment") or {}
    if (
        status not in PRE_PREREGISTRATION_STATUSES
        or protocol.get("diagnosis") is not None
        or treatment.get("video_id") is not None
        or treatment.get("variable") != "NONE"
        or treatment.get("preregistered_before_production") is not False
        or protocol.get("primary_metric") != "NONE"
    ):
        return False
    snapshot_id = baseline.get("snapshot_id")
    if status == "WAITING_FOR_24H_BASELINE":
        return snapshot_id is None
    return isinstance(snapshot_id, str) and bool(snapshot_id.strip())


def _artifact(root: Path, path: Path) -> dict[str, Any]:
    absolute = path if path.is_absolute() else root / path
    return {"path": _relative(root, absolute), "sha256": _sha(absolute), "size_bytes": absolute.stat().st_size}


def _dhash(image: Image.Image) -> int:
    gray = image.convert("L").resize((9, 8), Image.Resampling.LANCZOS)
    pixels = list(gray.tobytes())
    value = 0
    for y in range(8):
        for x in range(8):
            value = (value << 1) | int(pixels[y * 9 + x] > pixels[y * 9 + x + 1])
    return value


def _similarity(left: Image.Image, right: Image.Image) -> float:
    distance = (_dhash(left) ^ _dhash(right)).bit_count()
    shape_similarity = 1.0 - distance / 64.0
    left_rgb = left.convert("RGB").resize((1, 1), Image.Resampling.LANCZOS).getpixel((0, 0))
    right_rgb = right.convert("RGB").resize((1, 1), Image.Resampling.LANCZOS).getpixel((0, 0))
    color_similarity = 1.0 - sum(abs(int(a) - int(b)) for a, b in zip(left_rgb, right_rgb, strict=True)) / 765.0
    return round(0.4 * shape_similarity + 0.6 * color_similarity, 6)


def _image_metrics(candidate_path: Path, baseline_path: Path, layout: str) -> dict[str, Any]:
    with Image.open(candidate_path) as raw_candidate, Image.open(baseline_path) as raw_baseline:
        candidate = raw_candidate.convert("RGB")
        baseline = raw_baseline.convert("RGB")
        width, height = candidate.size
        region = candidate.crop((0, 0, 720, 720) if layout == "LEFT" else (0, 440, 1280, 720)).convert("L")
        low, high = region.getextrema()
        return {
            "format": str(raw_candidate.format or "").upper(),
            "width": width,
            "height": height,
            "entropy": round(float(candidate.convert("L").entropy()), 6),
            "region_span": float(high - low),
            "region_stddev": round(float(ImageStat.Stat(region).stddev[0]), 6),
            "baseline_similarity": _similarity(candidate, baseline),
        }


def _selected_inputs(root: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    protocol = _active_protocol(root)
    inputs = _read(root / INPUTS)
    evaluation = _read(root / PACKAGING_EVALUATION)
    variants = _read(root / VARIANTS)
    baseline_package = _read(root / BASELINE_PACKAGE)
    _validate(root, "phase6_experiment_protocol.schema.json", protocol)
    _validate(root, "phase6_production_inputs_receipt.schema.json", inputs)
    _validate(root, "phase6_packaging_variants.schema.json", variants)
    if protocol.get("status") != "PREREGISTERED" or (protocol.get("treatment") or {}).get("variable") != "TITLE_THUMBNAIL_PROMISE":
        raise PermissionError("exact title-thumbnail treatment is not preregistered")
    if (protocol.get("treatment") or {}).get("video_id") != VIDEO_ID:
        raise PermissionError("package treatment targets a different video")
    if inputs.get("action") != "EVALUATE_CANARY_PACKAGE" or inputs.get("next_action") != "RENDER_SELECTED_CANARY_THUMBNAIL_SET":
        raise PermissionError("package production-input receipt is not ready")
    for record in inputs["artifacts"]:
        path = root / record["path"]
        if not path.is_file() or "sha256:" + _sha(path) != record["sha256"] or path.stat().st_size != record["size_bytes"]:
            raise PermissionError(f"production input changed or disappeared: {record['path']}")
    selected = evaluation.get("selected_variant")
    if selected != inputs["measurements"].get("selected_package_variant"):
        raise PermissionError("selected package identity mismatch")
    matches = [item for item in variants.get("variants") or [] if item.get("variant_id") == selected]
    if len(matches) != 1:
        raise PermissionError("selected package variant is not unique")
    return protocol, inputs, evaluation, matches[0], baseline_package


def materialize_candidate_and_quality(root: Path = ROOT, *, created_at: str | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    timestamp = created_at or _stamp()
    protocol, inputs, evaluation, variant, baseline_package = _selected_inputs(root)
    baseline_receipt = _read(root / BASELINE_RECEIPT)
    if baseline_receipt.get("status") != "COMPLETE_PUBLIC" or baseline_receipt.get("video_id") != VIDEO_ID or baseline_receipt.get("channel_id") != CHANNEL_ID:
        raise PermissionError("exact public canary baseline receipt is invalid")
    baseline_thumb = _resolve(root, baseline_package["thumbnail"]["path"])
    baseline_video = _resolve(root, baseline_package["video"]["path"])
    if _sha(baseline_thumb) != baseline_package["thumbnail"]["sha256"] or _sha(baseline_video) != baseline_package["video"]["sha256"]:
        raise PermissionError("frozen baseline media changed")

    variant_id = variant["variant_id"]
    render_spec = variant["render_spec"]
    source = root / render_spec["source_path"]
    line_one, line_two, layout = render_spec["line_one"], render_spec["line_two"], render_spec["layout"]
    if not source.is_file() or "sha256:" + _sha(source) != render_spec["source_sha256"]:
        raise PermissionError("selected owned package source is missing or changed")
    output = root / PACKAGE_ROOT / "render" / f"variant-{variant_id.casefold()}.jpg"
    _render_thumbnail(root, font=_font(), source=source, output=output, line_one=line_one, line_two=line_two, layout=layout)
    metrics = _image_metrics(output, baseline_thumb, layout)
    candidate_identity = f"{protocol['protocol_id']}|{inputs['receipt_id']}|{evaluation['evaluation_id']}|{variant_id}|{_sha(output)}|{variant['title']}"
    candidate = {
        "schema_version": "1.0.0",
        "candidate_id": "phase6-package-candidate-" + hashlib.sha256(candidate_identity.encode()).hexdigest()[:24],
        "protocol_id": protocol["protocol_id"], "production_inputs_receipt_id": inputs["receipt_id"],
        "packaging_evaluation_id": evaluation["evaluation_id"], "channel_id": CHANNEL_ID, "video_id": VIDEO_ID,
        "variant_id": variant_id, "title": variant["title"], "thumbnail_text": variant["thumbnail_text"], "promise": variant["promise"],
        "thumbnail": {
            "path": _relative(root, output), "sha256": _sha(output), "size_bytes": output.stat().st_size,
            "width": metrics["width"], "height": metrics["height"], "format": metrics["format"],
            "source_path": _relative(root, source), "source_sha256": _sha(source), "layout": layout,
            "line_one": line_one, "line_two": line_two,
        },
        "baseline": {
            "title": baseline_package["metadata"]["title"], "thumbnail_path": _relative(root, baseline_thumb),
            "thumbnail_sha256": _sha(baseline_thumb), "video_path": _relative(root, baseline_video),
            "video_sha256": _sha(baseline_video), "publication_receipt_id": baseline_receipt["receipt_id"],
        },
        "control_lock": ["video_bytes", "description", "tags", "category", "privacy", "captions", "narrative", "audio", "format_pack", "channel_identity"],
        "change_scope": ["title", "thumbnail"],
        "rights": {"status": "PASS_OWNED", "source_class": "PROJECT_OWNED_ORIGINAL", "evidence": [_relative(root, source), _relative(root, root / BASELINE_PACKAGE)]},
        "technical_cost_brl": 0, "created_at": timestamp,
    }
    _validate(root, "phase6_package_candidate.schema.json", candidate)
    candidate_path = root / CANDIDATE
    _write(candidate_path, candidate)

    title_words = set(re.findall(r"[a-z]+", candidate["title"].casefold()))
    thumb_words = re.findall(r"[A-Za-z]+", candidate["thumbnail_text"])
    promise_words = set(re.findall(r"[a-z]+", candidate["promise"].casefold()))
    semantic_terms = {"prayer", "amen", "action", "step", "test", "truth", "responsible", "today"}
    banned = re.compile(r"\b(guaranteed|miracle|god told|will happen|instant|secret)\b", re.I)
    dna = _read(root / CHANNEL_DNA)
    checks = [
        ("PREREGISTRATION_IDENTITY", protocol["status"] == "PREREGISTERED" and protocol["treatment"]["preregistered_before_production"] is True, [protocol["protocol_id"]]),
        ("PRODUCTION_INPUT_INTEGRITY", True, [inputs["receipt_id"], evaluation["evaluation_id"]]),
        ("EXACT_PUBLIC_TARGET", baseline_receipt["video_id"] == VIDEO_ID and baseline_receipt["channel_id"] == CHANNEL_ID, [baseline_receipt["receipt_id"]]),
        ("SINGLE_VARIABLE_SCOPE", candidate["change_scope"] == ["title", "thumbnail"], candidate["control_lock"]),
        ("TITLE_LENGTH", 35 <= len(candidate["title"]) <= 100, [f"characters={len(candidate['title'])}"]),
        ("THUMBNAIL_COPY", 2 <= len(thumb_words) <= 5 and len(candidate["thumbnail_text"]) <= 40, [f"words={len(thumb_words)}"]),
        ("POLICY_LANGUAGE", banned.search(candidate["title"] + " " + candidate["thumbnail_text"] + " " + candidate["promise"]) is None, ["no prohibited certainty/fearbait term"]),
        ("PROMISE_DELIVERY", bool((title_words | set(word.casefold() for word in thumb_words) | promise_words) & semantic_terms), [candidate["promise"]]),
        ("CHANNEL_DNA", "Christian" in candidate["title"] and bool((dna.get("channel_dna") or {}).get("editorial_promise")), [_relative(root, root / CHANNEL_DNA)]),
        ("IMAGE_SPEC", metrics["format"] == "JPEG" and metrics["width"] == 1280 and metrics["height"] == 720 and output.stat().st_size <= 2_097_152, [f"{metrics['width']}x{metrics['height']};bytes={output.stat().st_size}"]),
        ("SAFE_AREA", layout in {"LEFT", "BOTTOM"} and len(line_one) <= 12 and len(line_two) <= 12, [f"locked-layout={layout}"]),
        ("VISUAL_INFORMATION", metrics["entropy"] >= 4.0 and metrics["region_span"] >= 120 and metrics["region_stddev"] >= 20, [f"entropy={metrics['entropy']};span={metrics['region_span']};stddev={metrics['region_stddev']}"]),
        ("MEANINGFUL_VISUAL_CHANGE", metrics["baseline_similarity"] <= 0.92, [f"dhash_similarity={metrics['baseline_similarity']}"]),
        ("OWNED_SOURCE_RIGHTS", candidate["rights"]["status"] == "PASS_OWNED" and source.is_file(), [_relative(root, source), _sha(source)]),
        ("BASELINE_ROLLBACK", baseline_thumb.is_file() and _sha(baseline_thumb) == candidate["baseline"]["thumbnail_sha256"], [_relative(root, baseline_thumb)]),
        ("VIDEO_CONTENT_LOCK", baseline_video.is_file() and _sha(baseline_video) == candidate["baseline"]["video_sha256"], [_relative(root, baseline_video), candidate["baseline"]["video_sha256"]]),
        ("ZERO_TECHNICAL_COST", candidate["technical_cost_brl"] == 0, ["technical_cost_brl=0"]),
    ]
    gates = [{"gate": name, "critical": True, "status": "PASS" if passed else "BLOCKED", "evidence": evidence} for name, passed, evidence in checks]
    blockers = [item["gate"] for item in gates if item["status"] != "PASS"]
    quality = {
        "schema_version": "1.0.0", "evaluation_id": "phase6-package-quality-" + hashlib.sha256(f"{candidate['candidate_id']}|{gates}".encode()).hexdigest()[:24],
        "candidate_id": candidate["candidate_id"], "channel_id": CHANNEL_ID, "video_id": VIDEO_ID,
        "decision": "PASS_LIMITED_PACKAGE_TREATMENT" if not blockers else "BLOCKED", "publication_eligible": not blockers,
        "gates": gates,
        "measurements": {"title_characters": len(candidate["title"]), "thumbnail_words": len(thumb_words), "image_width": metrics["width"], "image_height": metrics["height"], "image_bytes": output.stat().st_size, "image_entropy": metrics["entropy"], "text_region_luma_span": metrics["region_span"], "baseline_perceptual_similarity": metrics["baseline_similarity"], "video_hash_unchanged": _sha(baseline_video) == candidate["baseline"]["video_sha256"]},
        "blockers": blockers, "candidate": {"path": _relative(root, candidate_path), "sha256": _sha(candidate_path)},
        "baseline": {"thumbnail_path": _relative(root, baseline_thumb), "thumbnail_sha256": _sha(baseline_thumb), "video_sha256": _sha(baseline_video)},
        "claim_boundary": ["Automatic visual checks qualify this exact candidate only.", "A quality pass is not a performance prediction.", "Public mutation still requires channel, OAuth, quota, schedule and rollback gates."],
        "technical_cost_brl": 0, "created_at": timestamp,
    }
    _validate(root, "phase6_package_quality_evaluation.schema.json", quality)
    quality_path = root / QUALITY
    _write(quality_path, quality)
    return candidate_path, quality_path


def _quota_day(now: datetime) -> tuple[datetime, datetime]:
    local = now.astimezone(PACIFIC)
    start = local.replace(hour=0, minute=0, second=0, microsecond=0)
    return start.astimezone(timezone.utc), (start + timedelta(days=1)).astimezone(timezone.utc)


def materialize_package_quota_preflight(root: Path = ROOT, *, now: datetime | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    start, end = _quota_day(current)
    observation_path = root / "output/integrations/youtube/heroverse/quota-observation.json"
    observation = _read(observation_path)
    _validate(root, "youtube_quota_observation.schema.json", observation)
    same_day = start <= _parse(observation["observed_at"]) < end
    base_uploads = int(observation["observed_usage"]["youtube-videos-insert-daily"]) if same_day else 0
    base_general = int(observation["observed_usage"]["youtube-general-units-daily"]) if same_day else 0
    effective = {"youtube-videos-insert-daily": base_uploads, "youtube-general-units-daily": min(10_000, base_general + 2000)}
    accounting = {
        "schema_version": "1.0.0", "accounting_id": "phase6-package-quota-" + hashlib.sha256(f"{start.isoformat()}|{effective}".encode()).hexdigest()[:20],
        "quota_day_start": _stamp(start), "quota_day_end": _stamp(end), "source_observation": _relative(root, observation_path),
        "same_quota_day": same_day, "confirmed_upload_receipts": 0, "conservative_untracked_general_unit_reserve": 2000,
        "effective_consumption_for_gate": effective, "limits": {"youtube-videos-insert-daily": 100, "youtube-general-units-daily": 10000},
        "billing_enabled": False, "risk_of_billing": "BLOCKED_BY_NO_BILLING_ACCOUNT_AND_PREVENTIVE_QUOTA_FLOOR",
        "fallback": "DEFER_PACKAGE_UPDATE_UNTIL_NEXT_FREE_QUOTA_DAY", "technical_cost_brl": 0, "created_at": _stamp(current),
    }
    _validate(root, "phase6_quota_accounting.schema.json", accounting)
    accounting_path = root / QUOTA_ACCOUNTING
    _write(accounting_path, accounting)
    preflight = evaluate_zero_cost(root, operation="phase6_canary_package_update", observed_usage=effective, created_at=_stamp(current))
    preflight_path = root / QUOTA_PREFLIGHT
    _write(preflight_path, preflight)
    return accounting_path, preflight_path


def _next_boundary(now: datetime) -> datetime:
    local = now.astimezone(PACIFIC)
    next_date = local.date() + timedelta(days=1)
    return datetime(next_date.year, next_date.month, next_date.day, tzinfo=PACIFIC).astimezone(timezone.utc)


def build_package_release_gate(root: Path, *, scheduled_for: datetime, now: datetime) -> dict[str, Any]:
    root = root.resolve()
    candidate_path, quality_path = root / CANDIDATE, root / QUALITY
    candidate, quality = _read(candidate_path), _read(quality_path)
    protocol, inputs, evaluation, _, _ = _selected_inputs(root)
    _validate(root, "phase6_package_candidate.schema.json", candidate)
    _validate(root, "phase6_package_quality_evaluation.schema.json", quality)
    snapshot_path = root / "output/audits/channel/heroverse/channel-snapshot.json"
    audit_path = root / "output/audits/channel/heroverse/channel-readiness-audit.json"
    oauth_path = root / "output/integrations/youtube/heroverse/operational-readiness.json"
    scopes_path = root / "output/integrations/youtube/heroverse/oauth-runtime-scope-requirement.json"
    preflight_path = root / QUOTA_PREFLIGHT
    evidence_paths = [snapshot_path, audit_path, oauth_path, scopes_path, preflight_path]
    if any(not item.is_file() for item in evidence_paths):
        raise FileNotFoundError("package release evidence is incomplete")
    snapshot, audit, oauth, scopes, preflight = map(_read, evidence_paths)
    age_hours = max(0.0, (now - _parse(snapshot["observed_at"])).total_seconds() / 3600)
    package_capability = next((item for item in scopes.get("capabilities") or [] if item.get("capability") == "CANARY_PACKAGE_TREATMENT"), None)
    boundary_offset = max(0.0, (now - scheduled_for).total_seconds())
    local_date = scheduled_for.astimezone(PACIFIC).date()
    baseline_date = local_date - timedelta(days=1)
    existing = _read(root / PUBLICATION_RECEIPT) if (root / PUBLICATION_RECEIPT).is_file() else None
    receipt_ok = existing is None or (existing.get("idempotency_key") == hashlib.sha256(f"{candidate['candidate_id']}|{scheduled_for.isoformat()}".encode()).hexdigest() and existing.get("status") == "FAILED_PRE_MUTATION" and int(existing.get("attempt_count") or 0) < 3)
    checks = [
        ("PREREGISTERED_PROTOCOL", protocol["status"] == "PREREGISTERED" and protocol["treatment"]["variable"] == "TITLE_THUMBNAIL_PROMISE", [protocol["protocol_id"]]),
        ("EXACT_PRODUCTION_INPUT", inputs["receipt_id"] == candidate["production_inputs_receipt_id"] and evaluation["evaluation_id"] == candidate["packaging_evaluation_id"], [inputs["receipt_id"], evaluation["evaluation_id"]]),
        ("INDEPENDENT_PACKAGE_QUALITY", quality["publication_eligible"] and quality["decision"] == "PASS_LIMITED_PACKAGE_TREATMENT" and not quality["blockers"], [_relative(root, quality_path)]),
        ("CANDIDATE_INTEGRITY", _sha(candidate_path) == quality["candidate"]["sha256"] and _sha(root / candidate["thumbnail"]["path"]) == candidate["thumbnail"]["sha256"], [_relative(root, candidate_path), candidate["thumbnail"]["sha256"]]),
        ("BASELINE_ROLLBACK_INTEGRITY", _sha(root / candidate["baseline"]["thumbnail_path"]) == candidate["baseline"]["thumbnail_sha256"], [candidate["baseline"]["thumbnail_path"]]),
        ("VIDEO_CONTENT_LOCK", _sha(root / candidate["baseline"]["video_path"]) == candidate["baseline"]["video_sha256"], [candidate["baseline"]["video_sha256"]]),
        ("FRESH_CHANNEL_READINESS", snapshot.get("channel_id") == CHANNEL_ID and age_hours <= 1 and audit.get("overall_status") == "PASS" and not (audit.get("publication_gate") or {}).get("critical_open_gates"), [_relative(root, snapshot_path), f"age_hours={age_hours:.6f}"]),
        ("OAUTH_DURABILITY", oauth.get("continuous_operation_ready") is True and (oauth.get("publication_guard") or {}).get("upload_permitted") is True, [_relative(root, oauth_path)]),
        ("LEAST_USE_SCOPE", scopes.get("status") == "PASS" and package_capability is not None and package_capability.get("granted_now") is True, [_relative(root, scopes_path), "videos.update(snippet)+thumbnails.set only"]),
        ("FREE_QUOTA", preflight.get("execution_permitted") is True and preflight.get("quota_status") == "PASS" and preflight.get("technical_cost_brl") == 0, [_relative(root, preflight_path), _relative(root, root / QUOTA_ACCOUNTING)]),
        ("PACIFIC_DAY_BOUNDARY", 0 <= boundary_offset <= BOUNDARY_TOLERANCE_SECONDS, [_stamp(scheduled_for), f"offset_seconds={boundary_offset:.3f}"]),
        ("NONOVERLAPPING_WINDOWS", baseline_date < local_date, [baseline_date.isoformat(), local_date.isoformat()]),
        ("PUBLIC_ACTION_ENVELOPE", "D-047" in (root / "docs/DECISIONS.md").read_text(encoding="utf-8-sig") and "Nenhum upload, publicação ou gasto externo" in (root / "AGENTS.md").read_text(encoding="utf-8-sig"), ["docs/DECISIONS.md#D-047", "AGENTS.md#Regras-imutáveis"]),
        ("IDEMPOTENT_RECEIPT", receipt_ok, [_relative(root, root / PUBLICATION_RECEIPT) if existing else "no-existing-receipt"]),
        ("ZERO_TECHNICAL_COST", candidate["technical_cost_brl"] == 0 and quality["technical_cost_brl"] == 0, ["technical_cost_brl=0"]),
    ]
    gates = [{"gate": name, "critical": True, "status": "PASS" if passed else "BLOCKED", "evidence": evidence} for name, passed, evidence in checks]
    blockers = [item["gate"] for item in gates if item["status"] != "PASS"]
    idempotency = hashlib.sha256(f"{candidate['candidate_id']}|{scheduled_for.isoformat()}".encode()).hexdigest()
    artifacts = {"candidate": _artifact(root, candidate_path), "quality": _artifact(root, quality_path), "production_inputs": _artifact(root, root / INPUTS), "protocol": _artifact(root, root / PROTOCOL), "baseline_receipt": _artifact(root, root / BASELINE_RECEIPT), "quota_preflight": _artifact(root, preflight_path)}
    value = {
        "schema_version": "1.0.0", "release_id": "phase6-package-release-" + idempotency[:24], "idempotency_key": idempotency,
        "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "candidate_id": candidate["candidate_id"],
        "decision": "READY_FOR_PUBLIC_PACKAGE_UPDATE" if not blockers else "BLOCKED", "publication_permitted": not blockers,
        "scheduled_for": _stamp(scheduled_for), "boundary_offset_seconds": round(boundary_offset, 6),
        "treatment_start_date_pt": local_date.isoformat(), "baseline_end_date_pt": baseline_date.isoformat(),
        "authorized_api_methods": sorted(AUTHORIZED_METHODS) if not blockers else [], "gates": gates, "blockers": blockers,
        "artifacts": artifacts, "quota_cost_units": {"videos.update": 50, "thumbnails.set": 50, "total": 100},
        "claim_boundary": "READY authorizes only the exact preregistered title-thumbnail pair on the exact existing public canary at the Pacific-day boundary, with rollback. It authorizes no video-byte change, Ads, paid service, deletion, unrelated metadata change or audience guarantee.",
        "technical_cost_brl": 0, "created_at": _stamp(now),
    }
    _validate(root, "phase6_package_release_gate.schema.json", value)
    return value


def _rollback_snippet(snippet: dict[str, Any]) -> dict[str, Any]:
    allowed = ("title", "description", "tags", "categoryId", "defaultLanguage", "defaultAudioLanguage")
    value = {key: snippet[key] for key in allowed if key in snippet}
    if not value.get("title") or not value.get("description") or not value.get("categoryId"):
        raise PermissionError("API baseline snippet lacks rollback-critical fields")
    return value


def _fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "HeroVersePackageVerifier/1.0", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310 - exact provider URL returned by YouTube API
        return bytes(response.read())


def execute_public_package_update(
    youtube: Any,
    media_factory: Callable[..., Any],
    root: Path = ROOT,
    *,
    thumbnail_fetch: Callable[[str], bytes] = _fetch,
    created_at: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    release, candidate = _read(root / RELEASE), _read(root / CANDIDATE)
    _validate(root, "phase6_package_release_gate.schema.json", release)
    _validate(root, "phase6_package_candidate.schema.json", candidate)
    if release["decision"] != "READY_FOR_PUBLIC_PACKAGE_UPDATE" or not release["publication_permitted"] or set(release["authorized_api_methods"]) != AUTHORIZED_METHODS:
        raise PermissionError("public package release is not ready")
    for artifact in release["artifacts"].values():
        path = root / artifact["path"]
        if not path.is_file() or _sha(path) != artifact["sha256"] or path.stat().st_size != artifact["size_bytes"]:
            raise PermissionError(f"release artifact changed: {artifact['path']}")
    receipt_path = root / PUBLICATION_RECEIPT
    existing = _read(receipt_path) if receipt_path.is_file() else None
    if existing and existing.get("idempotency_key") != release["idempotency_key"]:
        raise PermissionError("a different package transaction receipt exists")
    if existing and existing.get("status") in {"COMPLETE_PUBLIC_PACKAGE", "ROLLED_BACK", "PARTIAL_ROLLBACK_REQUIRED"}:
        return existing
    attempt = int((existing or {}).get("attempt_count") or 0) + 1
    if attempt > 3:
        return existing
    timestamp = created_at or _stamp()
    steps = list((existing or {}).get("steps") or [])
    baseline_snippet = ((existing or {}).get("baseline") or {}).get("rollback_snippet")
    mutation_started = (existing or {}).get("mutation_started_at")
    verification = {"channel_match": None, "video_public": None, "title_match": None, "thumbnail_api_confirmed": None, "public_thumbnail_similarity": None}
    rollback = {"required": False, "title_restored": None, "thumbnail_restored": None, "verified": None}

    def completed(name: str) -> bool:
        return any(item["step"] == name and item["status"] == "PASS" for item in steps)

    def add(name: str, status: str, evidence: str) -> None:
        if status == "PASS" and completed(name):
            return
        steps.append({"step": name, "status": status, "evidence": evidence})

    def persist(status: str, *, error: str | None = None, completed_at: str | None = None) -> dict[str, Any]:
        receipt = {
            "schema_version": "1.0.0", "receipt_id": "youtube-package-update-" + release["idempotency_key"][:20], "release_id": release["release_id"],
            "idempotency_key": release["idempotency_key"], "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "status": status, "attempt_count": attempt,
            "baseline": {"title": candidate["baseline"]["title"], "thumbnail_path": candidate["baseline"]["thumbnail_path"], "thumbnail_sha256": candidate["baseline"]["thumbnail_sha256"], "video_sha256": candidate["baseline"]["video_sha256"], "rollback_snippet": baseline_snippet or {"title": candidate["baseline"]["title"], "description": "unavailable", "categoryId": "27"}},
            "treatment": {"candidate_id": candidate["candidate_id"], "variant_id": candidate["variant_id"], "title": candidate["title"], "thumbnail_path": candidate["thumbnail"]["path"], "thumbnail_sha256": candidate["thumbnail"]["sha256"]},
            "treatment_start_date_pt": release["treatment_start_date_pt"], "baseline_end_date_pt": release["baseline_end_date_pt"],
            "boundary_offset_seconds": release["boundary_offset_seconds"],
            "steps": steps or [{"step": "INITIALIZE", "status": "NOT_RUN", "evidence": "transaction initialized"}], "verification": verification, "rollback": rollback,
            "mutation_started_at": mutation_started, "completed_at": completed_at, "error": error, "external_cost_brl": 0, "updated_at": timestamp,
        }
        _validate(root, "youtube_package_update_receipt.schema.json", receipt)
        _write(receipt_path, receipt)
        return receipt

    mutation_happened = completed("TITLE_UPDATE") or completed("THUMBNAIL_SET")
    try:
        owned = youtube.channels().list(part="id", mine=True, fields="items(id)").execute().get("items") or []
        if len(owned) != 1 or owned[0].get("id") != CHANNEL_ID:
            raise PermissionError("owned channel identity mismatch")
        add("CHANNEL_IDENTITY", "PASS", CHANNEL_ID)
        observed = youtube.videos().list(part="id,snippet,status", id=VIDEO_ID).execute().get("items") or []
        if len(observed) != 1:
            raise PermissionError("exact canary could not be read")
        item = observed[0]
        snippet, status = item.get("snippet") or {}, item.get("status") or {}
        if snippet.get("channelId") != CHANNEL_ID or status.get("privacyStatus") != "public":
            raise PermissionError("canary is not public on the pinned channel")
        current_title = snippet.get("title")
        if current_title not in {candidate["baseline"]["title"], candidate["title"]}:
            raise PermissionError("public title differs from both frozen baseline and exact treatment")
        if baseline_snippet is None:
            if current_title != candidate["baseline"]["title"]:
                raise PermissionError("cannot recover candidate-title state without a persisted rollback snippet")
            baseline_snippet = _rollback_snippet(snippet)
        add("PUBLIC_BASELINE_VERIFY", "PASS", f"videoId={VIDEO_ID};privacy=public;title={current_title}")
        persist("IN_PROGRESS")
        treatment_snippet = dict(baseline_snippet)
        treatment_snippet["title"] = candidate["title"]
        if not completed("TITLE_UPDATE"):
            mutation_started = timestamp
            youtube.videos().update(part="snippet", body={"id": VIDEO_ID, "snippet": treatment_snippet}).execute()
            mutation_happened = True
            add("TITLE_UPDATE", "PASS", candidate["title"])
            persist("IN_PROGRESS")
        if not completed("THUMBNAIL_SET"):
            response = youtube.thumbnails().set(videoId=VIDEO_ID, media_body=media_factory(str(root / candidate["thumbnail"]["path"]), mimetype="image/jpeg", resumable=False)).execute()
            if not response:
                raise RuntimeError("thumbnails.set returned no confirmation resource")
            mutation_happened = True
            add("THUMBNAIL_SET", "PASS", candidate["thumbnail"]["sha256"])
            verification["thumbnail_api_confirmed"] = True
            persist("IN_PROGRESS")
        final = youtube.videos().list(part="id,snippet,status", id=VIDEO_ID).execute().get("items") or []
        if len(final) != 1:
            raise RuntimeError("final public package could not be read")
        final_item = final[0]
        final_snippet, final_status = final_item.get("snippet") or {}, final_item.get("status") or {}
        verification["channel_match"] = final_snippet.get("channelId") == CHANNEL_ID
        verification["video_public"] = final_status.get("privacyStatus") == "public"
        verification["title_match"] = final_snippet.get("title") == candidate["title"]
        thumbnails = final_snippet.get("thumbnails") or {}
        ordered = [thumbnails.get(name) or {} for name in ("maxres", "standard", "high", "medium", "default")]
        public_url = next((entry.get("url") for entry in ordered if entry.get("url")), None)
        if not public_url:
            raise RuntimeError("public thumbnail URL is unavailable after update")
        similarities: list[float] = []
        for verification_attempt in range(3):
            separator = "&" if "?" in str(public_url) else "?"
            public_bytes = thumbnail_fetch(f"{public_url}{separator}heroverse_verify={verification_attempt}")
            with Image.open(io.BytesIO(public_bytes)) as public_image, Image.open(root / candidate["thumbnail"]["path"]) as local_image:
                similarities.append(_similarity(public_image, local_image))
            if similarities[-1] >= 0.75:
                break
            if verification_attempt < 2:
                time.sleep(2)
        verification["public_thumbnail_similarity"] = max(similarities)
        if verification["public_thumbnail_similarity"] < 0.75:
            raise RuntimeError(f"public thumbnail verification similarity too low: {verification['public_thumbnail_similarity']}")
        if not all((verification["channel_match"], verification["video_public"], verification["title_match"], verification["thumbnail_api_confirmed"])):
            raise RuntimeError("final public package verification failed")
        add("PUBLIC_PACKAGE_VERIFY", "PASS", f"title_match=true;thumbnail_similarity={verification['public_thumbnail_similarity']}")
        return persist("COMPLETE_PUBLIC_PACKAGE", completed_at=timestamp)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        add("FAILURE", "FAIL", error)
        if not mutation_happened:
            return persist("FAILED_PRE_MUTATION", error=error)
        rollback["required"] = True
        try:
            youtube.videos().update(part="snippet", body={"id": VIDEO_ID, "snippet": baseline_snippet}).execute()
            rollback["title_restored"] = True
            add("ROLLBACK_TITLE", "PASS", candidate["baseline"]["title"])
        except Exception as rollback_exc:
            rollback["title_restored"] = False
            add("ROLLBACK_TITLE", "FAIL", f"{type(rollback_exc).__name__}: {rollback_exc}")
        try:
            youtube.thumbnails().set(videoId=VIDEO_ID, media_body=media_factory(str(root / candidate["baseline"]["thumbnail_path"]), mimetype="image/jpeg", resumable=False)).execute()
            rollback["thumbnail_restored"] = True
            add("ROLLBACK_THUMBNAIL", "PASS", candidate["baseline"]["thumbnail_sha256"])
        except Exception as rollback_exc:
            rollback["thumbnail_restored"] = False
            add("ROLLBACK_THUMBNAIL", "FAIL", f"{type(rollback_exc).__name__}: {rollback_exc}")
        try:
            check = youtube.videos().list(part="id,snippet,status", id=VIDEO_ID).execute().get("items") or []
            rollback["verified"] = bool(len(check) == 1 and check[0].get("snippet", {}).get("title") == candidate["baseline"]["title"] and check[0].get("status", {}).get("privacyStatus") == "public")
        except Exception:
            rollback["verified"] = False
        rolled_back = rollback["title_restored"] is True and rollback["thumbnail_restored"] is True and rollback["verified"] is True
        return persist("ROLLED_BACK" if rolled_back else "PARTIAL_ROLLBACK_REQUIRED", error=error, completed_at=timestamp)


def _build_live_service(token_path: Path) -> tuple[Any, Callable[..., Any]]:
    from google.oauth2.credentials import Credentials  # type: ignore
    from googleapiclient.discovery import build  # type: ignore
    from googleapiclient.http import MediaFileUpload  # type: ignore

    credentials = Credentials.from_authorized_user_file(str(token_path), INTEGRATION_SCOPES)
    if not credentials.valid:
        raise PermissionError("production OAuth token is invalid at package-update boundary")
    return build("youtube", "v3", credentials=credentials, cache_discovery=False), MediaFileUpload


def _runtime(root: Path, *, now: datetime, status: str, protocol_id: str | None, candidate: str | None = None, quality: str | None = None, release: str | None = None, receipt: str | None = None, scheduled_for: str | None = None, next_action: str, blockers: list[str] | None = None, error: str | None = None) -> dict[str, Any]:
    value = {"schema_version": "1.0.0", "executor_id": "heroverse-phase6-package-treatment-executor-v1", "phase": 6, "channel_id": CHANNEL_ID, "video_id": VIDEO_ID, "status": status, "protocol_id": protocol_id, "candidate": candidate, "quality_evaluation": quality, "release_gate": release, "publication_receipt": receipt, "scheduled_for": scheduled_for, "next_action": next_action, "blockers": sorted(set(blockers or [])), "error": error, "technical_cost_brl": 0, "updated_at": _stamp(now)}
    _validate(root, "phase6_package_executor_runtime.schema.json", value)
    _write_runtime_view(root / RUNTIME, value)
    return value


def run_phase6_package_treatment_executor(root: Path = ROOT, *, token_path: Path | None = None, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    latest_path = root / PROTOCOL
    active_path = root / ACTIVE_PROTOCOL
    if not latest_path.is_file() and not active_path.is_file():
        return _runtime(root, now=current, status="WAITING_FOR_PREREGISTRATION", protocol_id=None, next_action="Wait for the exact 24-hour diagnosis and preregistration.")
    if latest_path.is_file() and not active_path.is_file():
        try:
            latest_protocol = _read(latest_path)
            _validate(root, "phase6_experiment_protocol.schema.json", latest_protocol)
            latest_status = latest_protocol.get("status")
            if _is_legitimate_pre_preregistration(latest_protocol):
                return _runtime(
                    root,
                    now=current,
                    status="WAITING_FOR_PREREGISTRATION",
                    protocol_id=latest_protocol.get("protocol_id"),
                    next_action="Wait for the exact 24-hour diagnosis and committed preregistration; do not create active.json here.",
                )
            raise PermissionError(f"latest protocol state {latest_status!r} is not a legitimate pre-preregistration wait")
        except Exception as exc:
            return _runtime(
                root, now=current, status="BLOCKED", protocol_id=None,
                next_action="Restore the byte-identical active/latest preregistration before any public package mutation.",
                blockers=["ACTIVE_PROTOCOL_BINDING"], error=f"{type(exc).__name__}: {exc}",
            )
    try:
        protocol = _active_protocol(root)
    except Exception as exc:
        return _runtime(
            root, now=current, status="BLOCKED", protocol_id=None,
            next_action="Restore the byte-identical active/latest preregistration before any public package mutation.",
            blockers=["ACTIVE_PROTOCOL_BINDING"], error=f"{type(exc).__name__}: {exc}",
        )
    if protocol.get("status") != "PREREGISTERED" or (protocol.get("treatment") or {}).get("variable") != "TITLE_THUMBNAIL_PROMISE":
        return _runtime(root, now=current, status="WAITING_FOR_PREREGISTRATION", protocol_id=protocol.get("protocol_id"), next_action="No public package treatment is selected; preserve the baseline package.")
    required = [root / INPUTS, root / PACKAGING_EVALUATION, root / VARIANTS]
    if any(not item.is_file() for item in required):
        return _runtime(root, now=current, status="WAITING_FOR_INPUTS", protocol_id=protocol["protocol_id"], next_action="Allow the treatment and release-input executors to compile the selected package evidence.")
    try:
        candidate_path, quality_path = materialize_candidate_and_quality(root, created_at=_stamp(current))
        candidate, quality = _read(candidate_path), _read(quality_path)
        candidate_ref, quality_ref = _relative(root, candidate_path), _relative(root, quality_path)
        if not quality["publication_eligible"]:
            return _runtime(root, now=current, status="BLOCKED", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, next_action="Correct the exact failed package-quality evidence; do not mutate the public video.", blockers=quality["blockers"])
        receipt_path = root / PUBLICATION_RECEIPT
        if receipt_path.is_file():
            receipt = _read(receipt_path)
            if receipt.get("status") == "COMPLETE_PUBLIC_PACKAGE":
                return _runtime(root, now=current, status="COMPLETE_PUBLIC_PACKAGE", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, release=_relative(root, root / RELEASE) if (root / RELEASE).is_file() else None, receipt=_relative(root, receipt_path), scheduled_for=(receipt.get("mutation_started_at") or receipt.get("updated_at")), next_action="Observe the fixed baseline and treatment calendar days; do not change the package again during measurement.")
            if receipt.get("status") in {"ROLLED_BACK", "PARTIAL_ROLLBACK_REQUIRED"}:
                return _runtime(root, now=current, status="ROLLED_BACK" if receipt["status"] == "ROLLED_BACK" else "BLOCKED", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, receipt=_relative(root, receipt_path), scheduled_for=receipt.get("mutation_started_at"), next_action="Preserve the rollback evidence and diagnose the failed public verification before any new treatment.", blockers=[receipt["status"]], error=receipt.get("error"))
        prior = _read(root / RUNTIME) if (root / RUNTIME).is_file() else None
        scheduled = _parse(prior["scheduled_for"]) if prior and prior.get("protocol_id") == protocol["protocol_id"] and prior.get("candidate") == candidate_ref and prior.get("scheduled_for") else _next_boundary(current)
        if current > scheduled + timedelta(seconds=BOUNDARY_TOLERANCE_SECONDS):
            scheduled = _next_boundary(current)
        if current < scheduled:
            return _runtime(root, now=current, status="NOT_DUE", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, scheduled_for=_stamp(scheduled), next_action="Wait silently for the Pacific-day boundary; no API mutation or quota is used early.")
        token = token_path or (Path(os.environ["HERO_YT_TOKEN_PATH"]) if os.environ.get("HERO_YT_TOKEN_PATH") else None)
        if token is None or not token.is_file():
            return _runtime(root, now=current, status="BLOCKED", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, scheduled_for=_stamp(scheduled), next_action="Restore the existing external OAuth token path; do not start interactive consent.", blockers=["HERO_YT_TOKEN_PATH_UNAVAILABLE"])
        refresh_channel_readiness(root, token, force=True, now=current)
        materialize_package_quota_preflight(root, now=current)
        release = build_package_release_gate(root, scheduled_for=scheduled, now=current)
        release_path = root / RELEASE
        _write(release_path, release)
        release_ref = _relative(root, release_path)
        if not release["publication_permitted"]:
            return _runtime(root, now=current, status="BLOCKED", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, release=release_ref, scheduled_for=_stamp(scheduled), next_action="Correct the exact release-gate blocker; never bypass or publish a partial package.", blockers=release["blockers"])
        youtube, media_factory = _build_live_service(token)
        receipt = execute_public_package_update(youtube, media_factory, root, created_at=_stamp(current))
        receipt_ref = _relative(root, root / PUBLICATION_RECEIPT)
        if receipt["status"] == "COMPLETE_PUBLIC_PACKAGE":
            return _runtime(root, now=current, status="COMPLETE_PUBLIC_PACKAGE", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, release=release_ref, receipt=receipt_ref, scheduled_for=_stamp(scheduled), next_action="Observe one complete baseline day and one complete treatment day; freeze the package during measurement.")
        if receipt["status"] == "ROLLED_BACK":
            return _runtime(root, now=current, status="ROLLED_BACK", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, release=release_ref, receipt=receipt_ref, scheduled_for=_stamp(scheduled), next_action="Public verification failed and the baseline was restored; preserve evidence and diagnose before another treatment.", blockers=["PUBLIC_PACKAGE_VERIFICATION_FAILED_ROLLBACK_COMPLETE"], error=receipt.get("error"))
        return _runtime(root, now=current, status="BLOCKED", protocol_id=protocol["protocol_id"], candidate=candidate_ref, quality=quality_ref, release=release_ref, receipt=receipt_ref, scheduled_for=_stamp(scheduled), next_action="Repair the partial rollback externally only if the API evidence confirms it remains incomplete.", blockers=[receipt["status"]], error=receipt.get("error"))
    except Exception as exc:
        return _runtime(root, now=current, status="ERROR", protocol_id=protocol.get("protocol_id"), candidate=_relative(root, root / CANDIDATE) if (root / CANDIDATE).is_file() else None, quality=_relative(root, root / QUALITY) if (root / QUALITY).is_file() else None, release=_relative(root, root / RELEASE) if (root / RELEASE).is_file() else None, receipt=_relative(root, root / PUBLICATION_RECEIPT) if (root / PUBLICATION_RECEIPT).is_file() else None, next_action="Correct the evidenced technical failure and retry without changing the preregistered treatment.", error=f"{type(exc).__name__}: {exc}")


if __name__ == "__main__":
    print(json.dumps(run_phase6_package_treatment_executor(ROOT), ensure_ascii=False, indent=2))
