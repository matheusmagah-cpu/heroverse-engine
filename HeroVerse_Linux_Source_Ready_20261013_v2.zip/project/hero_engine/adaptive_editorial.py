from __future__ import annotations

import hashlib
import json
import math
import re
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


SCORE_VERSION = "viral-opportunity-v1"
NICHE_BOUNDARY = (
    "English Christian motivation: faith under pressure, prayer, obedience, "
    "spiritual warfare, discernment, identity/calling, restoration, and divine timing."
)
WEIGHTS = {
    "relative_velocity": 0.28,
    "robust_outlier": 0.16,
    "engagement": 0.12,
    "cross_channel": 0.12,
    "freshness": 0.10,
    "novelty": 0.10,
    "evidence_depth": 0.07,
    "rights_feasibility": 0.05,
}
STOPWORDS = {
    "a", "about", "after", "all", "an", "and", "are", "as", "at", "be", "before",
    "but", "by", "do", "for", "from", "has", "have", "he", "how", "if", "in", "is",
    "it", "its", "of", "on", "or", "that", "the", "this", "to", "what", "when", "will",
    "with", "you", "your",
}
CLUSTERS = {
    "prayer_obedience": {
        "keywords": {"pray", "prayer", "amen", "obey", "obedience", "faith", "doubt", "healing"},
        "mechanism": "prayer becomes concrete through the next faithful response",
    },
    "spiritual_warfare": {
        "keywords": {"war", "warfare", "enemy", "devil", "attack", "battle", "armor", "stronghold", "demonic"},
        "mechanism": "name the pressure, expose its mechanism, and replace panic with a faithful response",
    },
    "identity_calling": {
        "keywords": {"chosen", "calling", "called", "purpose", "destiny", "identity", "appointed", "separated"},
        "mechanism": "pressure on identity changes how the viewer carries a calling",
    },
    "timing_restoration": {
        "keywords": {"wait", "waiting", "delay", "timing", "season", "restore", "restoration", "silence", "hidden"},
        "mechanism": "reinterpret delay without promising a date and give one faithful next step",
    },
    "discernment_warning": {
        "keywords": {"discern", "discernment", "warning", "voice", "sign", "signs", "speak", "deception", "manipulation"},
        "mechanism": "separate fear-driven urgency from a testable, belief-aligned decision",
    },
    "scripture_daily_faith": {
        "keywords": {"god", "jesus", "christ", "bible", "scripture", "spirit", "morning", "sin", "power"},
        "mechanism": "connect a concrete daily pressure to a specific belief and action",
    },
}
HAZARD_PATTERNS = {
    "unsupported_date_prophecy": re.compile(r"\b(20\d{2}|tomorrow|24 hours|date prophecy|antichrist|mark of the beast|nephilim)\b", re.I),
    "guaranteed_money_or_status": re.compile(r"\b(money|mansion|millionaire|luxury|wealth|rich|released)\b", re.I),
    "romantic_certainty": re.compile(r"\b(soulmate|this person|name is|younger)\b", re.I),
    "current_event_fearbait": re.compile(r"\b(hollywood|scientists are warning|worldwide|euphrates|island giants)\b", re.I),
}


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _tokens(text: str) -> set[str]:
    return {
        token for token in re.findall(r"[a-z']+", text.lower())
        if len(token) > 2 and token not in STOPWORDS
    }


def _parse_cutoff(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _parse_upload_date(value: str) -> datetime:
    return datetime.strptime(value, "%Y%m%d").replace(tzinfo=timezone.utc)


def _age_band(age_days: float) -> str:
    if age_days <= 7:
        return "0_7D"
    if age_days <= 30:
        return "8_30D"
    if age_days <= 90:
        return "31_90D"
    if age_days <= 365:
        return "91_365D"
    return "366D_PLUS"


def _percentile(value: float | None, population: Iterable[float | None]) -> float | None:
    if value is None:
        return None
    values = sorted(float(item) for item in population if item is not None)
    if not values:
        return None
    if len(values) == 1:
        return 0.5
    below = sum(1 for item in values if item < value)
    equal = sum(1 for item in values if item == value)
    return round((below + 0.5 * equal) / len(values), 6)


def _median(values: Iterable[float]) -> float | None:
    materialized = [float(value) for value in values]
    return statistics.median(materialized) if materialized else None


def _robust_z(value: float, population: Iterable[float]) -> float | None:
    values = [math.log1p(max(float(item), 0.0)) for item in population]
    if len(values) < 3:
        return None
    center = statistics.median(values)
    mad = statistics.median(abs(item - center) for item in values)
    if mad == 0:
        return None
    return (math.log1p(max(value, 0.0)) - center) / (1.4826 * mad)


def _cluster_title(title: str) -> tuple[str | None, str | None]:
    tokens = _tokens(title)
    ranked = sorted(
        (
            (len(tokens & definition["keywords"]), cluster_id, definition["mechanism"])
            for cluster_id, definition in CLUSTERS.items()
        ),
        reverse=True,
    )
    if not ranked or ranked[0][0] == 0:
        return None, None
    return ranked[0][1], ranked[0][2]


def _hazards(title: str) -> list[str]:
    return [name for name, pattern in HAZARD_PATTERNS.items() if pattern.search(title)]


def _jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 0.0


def _evidence_depth(levels: Iterable[str]) -> tuple[str, float]:
    observed = set(levels)
    if "FULL_VALIDATED" in observed:
        return "FULL", 1.0
    if "OPENING_ONLY" in observed:
        return "OPENING_ONLY", 0.55
    return "METADATA_ONLY", 0.20


def build_daily_signal_snapshot(
    snapshots_path: Path,
    coverage_path: Path,
    output_path: Path | None = None,
    asset_manifest_path: Path | None = None,
) -> dict[str, Any]:
    """Build an immutable, evidence-linked ranking from public observations.

    This ranks hypotheses. It does not predict or guarantee a viral outcome.
    """
    snapshot_doc = _read_json(snapshots_path)
    coverage_doc = _read_json(coverage_path)
    cutoff = _parse_cutoff(str(snapshot_doc["captured_at"]))
    channel_meta: dict[str, dict[str, Any]] = {}
    videos: list[dict[str, Any]] = []
    for record in snapshot_doc["snapshots"]:
        if record["entity_type"] == "CHANNEL":
            channel_meta[record["channel_id"]] = record["payload"]
        elif record["entity_type"] == "VIDEO" and record["collection_status"] == "COMPLETE":
            payload = record["payload"]
            if not payload.get("upload_date") or payload.get("view_count") is None:
                continue
            upload = _parse_upload_date(str(payload["upload_date"]))
            age_days = max((cutoff.astimezone(timezone.utc) - upload).total_seconds() / 86400.0, 1.0)
            views = int(payload["view_count"])
            likes = payload.get("like_count")
            comments = payload.get("comment_count")
            videos.append(
                {
                    "snapshot_id": record["snapshot_id"],
                    "channel_id": record["channel_id"],
                    "channel_role": payload.get("catalog_role"),
                    "channel_name": channel_meta.get(record["channel_id"], {}).get("channel_name_public", record["channel_id"]),
                    "video_id": payload["video_id"],
                    "title": payload["title"],
                    "source_uri": record["source_uri"],
                    "captured_at": record["captured_at"],
                    "format": payload.get("content_format", "LONG"),
                    "age_days": age_days,
                    "age_band": _age_band(age_days),
                    "views": views,
                    "views_per_day": views / age_days,
                    "like_rate": (1000.0 * int(likes) / views) if likes is not None and views > 0 else None,
                    "comment_rate": (1000.0 * int(comments) / views) if comments is not None and views > 0 else None,
                }
            )

    grouped: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    fallback: dict[tuple[str, str], list[float]] = defaultdict(list)
    for video in videos:
        grouped[(video["channel_id"], video["format"], video["age_band"])].append(video["views_per_day"])
        fallback[(video["channel_id"], video["format"])].append(video["views_per_day"])
    for video in videos:
        exact = grouped[(video["channel_id"], video["format"], video["age_band"])]
        population = exact if len(exact) >= 3 else fallback[(video["channel_id"], video["format"])]
        baseline = _median(population)
        video["baseline"] = baseline
        video["relative_velocity"] = video["views_per_day"] / baseline if baseline and baseline > 0 else None
        video["robust_z"] = _robust_z(video["views_per_day"], population)
        video["engagement_combined"] = (
            (video["like_rate"] or 0.0) + 2.0 * (video["comment_rate"] or 0.0)
            if video["like_rate"] is not None or video["comment_rate"] is not None
            else None
        )

    external_longs = [video for video in videos if video["channel_role"] != "OWNED" and video["format"] == "LONG"]
    owned_titles = [_tokens(video["title"]) for video in videos if video["channel_role"] == "OWNED"]
    coverage_rank = {"METADATA_ONLY": 0, "OPENING_ONLY": 1, "FULL_VALIDATED": 2}
    coverage_by_video: dict[str, str] = {}
    for record in coverage_doc["records"]:
        video_id = record["video_id"]
        level = record["coverage_level"]
        previous = coverage_by_video.get(video_id)
        if previous is None or coverage_rank.get(level, -1) > coverage_rank.get(previous, -1):
            coverage_by_video[video_id] = level
    rights_feasibility: float | None = None
    if asset_manifest_path and asset_manifest_path.is_file():
        asset_manifest = _read_json(asset_manifest_path)
        if (
            asset_manifest.get("status") == "COMPLETE"
            and int(asset_manifest.get("selected_count", 0)) >= int(asset_manifest.get("minimum_required", 1))
            and all(asset.get("production_eligible") is True for asset in asset_manifest.get("assets", []))
        ):
            rights_feasibility = 1.0
    clustered: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for video in external_longs:
        cluster_id, mechanism = _cluster_title(video["title"])
        if cluster_id:
            video["cluster_id"] = cluster_id
            video["mechanism"] = mechanism
            video["hazards"] = _hazards(video["title"])
            video["novelty"] = 1.0 - max((_jaccard(_tokens(video["title"]), title) for title in owned_titles), default=0.0)
            clustered[cluster_id].append(video)

    relative_population = [video["relative_velocity"] for video in external_longs]
    robust_population = [video["robust_z"] for video in external_longs]
    engagement_population = [video["engagement_combined"] for video in external_longs]
    freshness_population = [-video["age_days"] for video in external_longs]
    max_channels = max((len({video["channel_id"] for video in group}) for group in clustered.values()), default=1)
    owned_cluster_counts: dict[str, int] = defaultdict(int)
    for video in videos:
        if video["channel_role"] == "OWNED":
            cluster_id, _ = _cluster_title(video["title"])
            if cluster_id:
                owned_cluster_counts[cluster_id] += 1

    candidates: list[dict[str, Any]] = []
    for cluster_id, group in clustered.items():
        group.sort(key=lambda item: (item["relative_velocity"] or 0.0, item["views_per_day"]), reverse=True)
        representative = group[0]
        top = group[:3]
        channels = {item["channel_id"] for item in group}
        evidence_class, evidence_score = _evidence_depth(coverage_by_video.get(item["video_id"], "METADATA_ONLY") for item in group)
        components: dict[str, float | None] = {
            "relative_velocity": _percentile(representative["relative_velocity"], relative_population),
            "robust_outlier": _percentile(representative["robust_z"], robust_population),
            "engagement": _percentile(representative["engagement_combined"], engagement_population),
            "cross_channel": round(len(channels) / max_channels, 6),
            "freshness": _percentile(-representative["age_days"], freshness_population),
            "novelty": round(representative["novelty"], 6),
            "evidence_depth": evidence_score,
            "rights_feasibility": rights_feasibility,
        }
        penalties: list[dict[str, Any]] = []
        saturation = min(0.12, 0.02 * owned_cluster_counts.get(cluster_id, 0))
        if saturation:
            penalties.append({"reason": "owned_channel_saturation", "value": round(saturation, 6)})
        hazard_set = sorted({hazard for item in group for hazard in item["hazards"]})
        if hazard_set:
            penalties.append({"reason": "policy_or_factual_hazard", "value": 0.35})
        observed_weight = sum(WEIGHTS[name] for name, value in components.items() if value is not None)
        score = sum(WEIGHTS[name] * float(value) for name, value in components.items() if value is not None)
        score -= sum(item["value"] for item in penalties)
        eligible = not hazard_set and observed_weight >= 0.60
        rejection_reasons = [f"hazard:{hazard}" for hazard in hazard_set]
        if observed_weight < 0.60:
            rejection_reasons.append("score_coverage_below_0.60")
        candidate_id = _stable_id("cand", snapshot_doc["operation_id"], cluster_id)
        candidates.append(
            {
                "candidate_id": candidate_id,
                "topic_cluster": cluster_id,
                "mechanism": representative["mechanism"],
                "format": "LONG",
                "evidence_class": evidence_class,
                "evidence_ids": [item["snapshot_id"] for item in top],
                "representative_sources": [
                    {
                        "snapshot_id": item["snapshot_id"],
                        "channel_id": item["channel_id"],
                        "video_id": item["video_id"],
                        "title": item["title"],
                        "source_uri": item["source_uri"],
                        "captured_at": item["captured_at"],
                    }
                    for item in top
                ],
                "metrics": {
                    "age_days": round(representative["age_days"], 6),
                    "views": representative["views"],
                    "views_per_day": round(representative["views_per_day"], 6),
                    "channel_baseline_views_per_day": round(representative["baseline"], 6) if representative["baseline"] is not None else None,
                    "relative_velocity": round(representative["relative_velocity"], 6) if representative["relative_velocity"] is not None else None,
                    "like_rate_per_1000": round(representative["like_rate"], 6) if representative["like_rate"] is not None else None,
                    "comment_rate_per_1000": round(representative["comment_rate"], 6) if representative["comment_rate"] is not None else None,
                    "cross_channel_count": len(channels),
                },
                "components": components,
                "penalties": penalties,
                "opportunity_score": round(max(0.0, min(1.0, score)), 6),
                "score_observed_weight": round(observed_weight, 6),
                "eligible": eligible,
                "rejection_reasons": rejection_reasons,
            }
        )

    candidates.sort(key=lambda item: (item["eligible"], item["opportunity_score"]), reverse=True)
    if len(candidates) < 3:
        raise ValueError("At least three evidence-backed candidates are required for an adaptive decision")
    all_sources = sorted({evidence_id for candidate in candidates for evidence_id in candidate["evidence_ids"]})
    snapshot_id = _stable_id("daily-signal", snapshot_doc["operation_id"], snapshot_doc["captured_at"], SCORE_VERSION)
    result = {
        "schema_version": "1.0.0",
        "snapshot_id": snapshot_id,
        "operation_id": f"phase5-{snapshot_doc['operation_id']}",
        "channel_id": "heroverse74",
        "cutoff_at": cutoff.isoformat(),
        "score_version": SCORE_VERSION,
        "niche_boundary": NICHE_BOUNDARY,
        "source_snapshot_ids": all_sources,
        "candidates": candidates,
        "data_availability": {
            "public_views": "AVAILABLE",
            "public_engagement": "PARTIAL",
            "private_ctr": "UNAVAILABLE",
            "private_retention": "UNAVAILABLE",
            "rpm": "UNAVAILABLE",
            "limitations": [
                "Public views are observational and do not prove causality.",
                "Age normalization uses available upload dates and public snapshots.",
                "Metadata-only evidence can select a topic signal but cannot define hook or narrative mechanics.",
                "No pre-publication ranking guarantees a viral outcome.",
            ],
        },
        "status": "NEW_EVIDENCE",
    }
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


BRIEF_STRATEGIES: dict[str, dict[str, Any]] = {
    "prayer_obedience": {
        "topic": "what must happen after prayer",
        "angle": "prayer is not a substitute for the next faithful act; it prepares it",
        "promise": "show why clarity often follows obedience instead of preceding it",
        "titles": [
            "MOVE AFTER AMEN | Christian Motivation",
            "YOUR NEXT STEP AFTER PRAYER | Christian Motivation",
            "PRAYER PREPARES THE MOVE | Christian Motivation",
        ],
        "thumbnail": ["AFTER AMEN", "MOVE WITH FAITH", "THE NEXT STEP"],
        "thumbnail_concept": "A lone figure leaving shadow toward a narrow dawn path; three-word text, gold on deep navy.",
        "combined": "Prayer prepares the viewer to recognize and take one faithful next step.",
        "hooks": [
            ("0_1S", "contradiction", "Prayer does not end at amen.", "Hard cut from stillness to forward motion.", ["H1", "I2"]),
            ("1_3S", "personal consequence", "Your next move reveals it.", "A path appears under the first step; no logo or greeting.", ["H2", "I1"]),
            ("3_8S", "mechanism and first micro-payoff", "Do not wait for confidence. It often arrives after the first faithful step.", "Three visual beats: waiting, decision, forward motion.", ["H3", "I3"]),
            ("8_30S", "title-aligned proof direction", "Prayer changes your posture before it changes your circumstances. It quiets panic, exposes the next obedient action, and gives that action a reason larger than fear.", "Storm to still water to sunrise, each assigned a narrative job.", ["H4", "I3"]),
        ],
        "payoff": "Do not measure your prayer only by what changed around you. Measure it by the faithful step you can finally take.",
    },
    "spiritual_warfare": {
        "topic": "the moment pressure tries to name the viewer",
        "angle": "the first battle is over interpretation, before it becomes behavior",
        "promise": "expose the pressure-to-panic mechanism and replace it with one grounded response",
        "titles": ["THE BATTLE BEFORE THE BATTLE | Christian Motivation", "DON'T LET PRESSURE NAME YOU | Christian Motivation", "WHEN PRESSURE LIES | Christian Motivation"],
        "thumbnail": ["NAME THE LIE", "PRESSURE ISN'T TRUTH", "STAND FIRST"],
        "thumbnail_concept": "A figure steady in wind while debris moves around them; high contrast navy and amber.",
        "combined": "Expose how pressure rewrites identity before it changes action, then show how to interrupt it.",
        "hooks": [
            ("0_1S", "concrete tension", "The first battle is over what this pressure means.", "Immediate storm motion around a still subject.", ["H1", "I2"]),
            ("1_3S", "spiritual anchor", "If fear names the moment, panic will choose your next move.", "Fast contrast from blurred motion to a fixed horizon.", ["H2", "I1"]),
            ("3_8S", "mechanism", "Pressure becomes dangerous when it turns a feeling into an identity. Name the lie before it becomes a decision.", "Three semantic cuts: pressure, false label, deliberate choice.", ["H3", "I3"]),
            ("8_30S", "proof direction", "You do not defeat confusion by moving faster. You slow the interpretation, test it, and choose the response that agrees with faith instead of fear.", "Visual pace decelerates as the mechanism becomes clear.", ["H4", "I3"]),
        ],
        "payoff": "Pressure may describe the moment, but it does not get to name you or choose your next faithful action.",
    },
}


def build_editorial_brief(
    signal_snapshot: dict[str, Any],
    channel_model: dict[str, Any],
    output_path: Path | None = None,
) -> dict[str, Any]:
    selected = next(
        (
            item for item in signal_snapshot["candidates"]
            if item["eligible"]
            and item["topic_cluster"] in BRIEF_STRATEGIES
            and item["opportunity_score"] >= 0.75
            and item["score_observed_weight"] >= 0.95
        ),
        None,
    )
    if selected is None:
        raise ValueError(
            "No candidate passes the strict opportunity gate (score>=0.75 and observed_weight>=0.95); "
            "collect deeper evidence or complete rights feasibility instead of inflating the score"
        )
    strategy = BRIEF_STRATEGIES[selected["topic_cluster"]]
    archetype = next(
        item for item in channel_model["format_archetypes"]
        if item["archetype_id"] == "A-LONG-DIRECT-SPIRITUAL-STAKES-V1"
    )
    rule_evidence: dict[str, list[str]] = {}
    for family in ("packaging_rules", "hook_rules", "invariants", "variables", "prohibited"):
        for rule in archetype[family]:
            rule_evidence[rule["rule_id"]] = rule["evidence_refs"]
    hook_windows = []
    for window, function, text, visual, rules in strategy["hooks"]:
        hook_windows.append(
            {
                "window": window,
                "function": function,
                "original_text": text,
                "visual_proof": visual,
                "archetype_rule_refs": rules,
                "evidence_refs": sorted({ref for rule in rules for ref in rule_evidence.get(rule, [])}),
                "gate_status": "PASS",
            }
        )
    alternatives = []
    for candidate in signal_snapshot["candidates"]:
        if candidate["candidate_id"] == selected["candidate_id"]:
            alternatives.append({"candidate_id": candidate["candidate_id"], "decision": "SELECTED", "reason": "Highest eligible score with an approved long-form strategy and no policy hazard."})
        else:
            decision = "REJECTED" if not candidate["eligible"] else "HELD"
            reason = "; ".join(candidate["rejection_reasons"]) if candidate["rejection_reasons"] else "Lower opportunity score; retained as a future challenger, not silently discarded."
            alternatives.append({"candidate_id": candidate["candidate_id"], "decision": decision, "reason": reason})
    brief_id = _stable_id("brief", signal_snapshot["snapshot_id"], selected["candidate_id"], archetype["archetype_id"])
    result = {
        "schema_version": "1.0.0",
        "brief_id": brief_id,
        "channel_id": signal_snapshot["channel_id"],
        "signal_snapshot_id": signal_snapshot["snapshot_id"],
        "archetype_id": archetype["archetype_id"],
        "niche_fit": {"boundary": signal_snapshot["niche_boundary"], "status": "PASS", "evidence": ["model:channel_dna", "archetype:audience_intent", *selected["evidence_ids"]]},
        "selected_candidate_id": selected["candidate_id"],
        "selection_reason": (
            f"Selected {selected['topic_cluster']} at opportunity_score={selected['opportunity_score']} "
            f"with observed_weight={selected['score_observed_weight']}; signal controls topic only, "
            "while hook and narrative mechanics come from the approved archetype."
        ),
        "alternatives": alternatives,
        "package": {
            "topic": strategy["topic"],
            "angle": strategy["angle"],
            "promise": strategy["promise"],
            "title_concept": strategy["titles"][0],
            "title_variants": strategy["titles"],
            "thumbnail_concept": strategy["thumbnail_concept"],
            "thumbnail_text_variants": strategy["thumbnail"],
            "combined_promise": strategy["combined"],
            "delivery_test": "PASS",
        },
        "hook_windows": hook_windows,
        "payoff": strategy["payoff"],
        "originality_controls": {"new_thesis": True, "new_wording": True, "new_sequence": True, "new_visual_identity": True, "reference_copying_prohibited": True},
        "risks": [
            "The trend signal is public metadata, not causal proof.",
            "The selected archetype confidence is 0.408248 and is approved only for a controlled pilot.",
            "Result cannot be called viral before publication and measurement.",
        ],
        "decision_status": "VIRAL_CANDIDATE",
    }
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result
