"""Bind thirteen literal uses to eleven existing stills, never to a clock.

This LIMITED contract preserves each source's original narrative provenance.
The two callbacks are new uses of the original door/reply pixels, not renamed
source proofs, independent lineages, temporal evidence or production approval.
"""
from __future__ import annotations

import copy
from pathlib import Path

from jsonschema import Draft202012Validator

from . import phase6_av_static_sources as sources
from . import phase6_static_asset_rights as rights

VERSION = "phase6-av-static-asset-uses-v1"
SCHEMA = "schemas/phase6_av_static_asset_uses.schema.json"
PLAN = {
    "path": "output/operations/phase6/av-admission/visual-intents/untimed-visual-intent-v2.json",
    "sha256": "d8504875d441ec62549d36ceda84d5aab8bce56c094d3a9f76686015b8697b15",
}
BIBLE = {"path": sources.BIBLE, "sha256": sources.INPUT_PINS[sources.BIBLE]}
REGISTRATION = {
    "path": "output/operations/phase6/av-admission/evidence/static-rights-registrations/d171-static-rights-registration-03fbe1403d7f7252019f42ec.json",
    "sha256": "36857c5ba11f8b6d37530a77b694adc46167706ebb3c6e5946a9b69a60d01fab",
}
DEPENDENCY_PINS = {
    "hero_engine/phase6_av_static_sources.py": "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "hero_engine/phase6_static_asset_rights.py": "11f89775cb18ebd54c29f6f6dda861f6e7975a1cb413345dc496a7510a44d828",
}
# visual state / unit / original template / original state. Order is semantic:
# all eleven original states, then the two exact callbacks, never new reveals.
USES = tuple(
    (f"visual-u{unit}-s{index:02d}", f"narration-unit-{unit}", "fear-examples-v1", f"{subject}-{index}")
    for unit, subject in (("005", "door"), ("006", "reply"), ("007", "morning"))
    for index in (0, 1)
) + tuple(
    (f"visual-u034-s{index:02d}", "narration-unit-034", "four-criteria-v1", f"state-{index}")
    for index in range(5)
) + (
    ("visual-u044-s00", "narration-unit-044", "fear-examples-v1", "door-0"),
    ("visual-u045-s00", "narration-unit-045", "fear-examples-v1", "reply-0"),
)
AUTHORITY = {key: False for key in (
    "timing", "source_admitted", "quality", "publicity", "render", "queue", "publication")}


def _same(actual, expected, message):
    sources._same(actual, expected, message)


def _envelope(root):
    reader = sources._Reader(root)
    for name, digest in DEPENDENCY_PINS.items():
        reader.read(name, digest)
    for name in ("hero_engine/phase6_av_static_asset_uses.py", SCHEMA):
        path = reader.path(name)
        reader.read(name, sources._sha(path.read_bytes()))
    plan = sources._json(reader.read(PLAN["path"], PLAN["sha256"]))
    bible = sources._json(reader.read(BIBLE["path"], BIBLE["sha256"]))
    registration = sources._json(reader.read(REGISTRATION["path"], REGISTRATION["sha256"]))
    _same([plan["channel_id"], bible["channel_id"]], [sources.CHANNEL] * 2, "channel identity differs")
    _same(registration["status"], "REGISTERED_RIGHTS_ONLY_NOT_ADMITTED", "rights registry scope differs")
    _same([registration["state_count"], registration["lineage_count"]], [11, 2], "rights inventory differs")
    _same(registration["authority"], rights.AUTHORITY, "rights registration cannot grant authority")
    return reader, plan, registration


def _expected(plan, registration):
    rows = {row["unit_id"]: row for row in plan["rows"]}
    registered = registration["request"]["states"]
    source_rows = []
    for entry in registered:
        args = entry["arguments"]
        source_rows.append({"source_id": entry["asset_id"],
            "static_source": {name: copy.deepcopy(args[name]) for name in ("template_id", "state_id", "receipt_binding")},
            "rights_evidence": {name: copy.deepcopy(args[name]) for name in ("provenance_binding", "decision_binding")}})
    by_source = {(entry["static_source"]["template_id"], entry["static_source"]["state_id"]): entry
                 for entry in source_rows}
    if len(source_rows) != 11 or len(by_source) != 11:
        raise ValueError("eleven unique original sources required")
    uses = []
    for visual_id, unit_id, template, state_id in USES:
        row = rows[unit_id]
        state = next(state for state in row["states"] if state["state_id"] == visual_id)
        uses.append({"use_id": "static-use-" + visual_id, "visual_state_id": visual_id,
            "unit_id": unit_id, "source_id": by_source[(template, state_id)]["source_id"],
            "literal_copy": copy.deepcopy(state["visual_content"]["literal_copy"])})
    return {"kind": "PHASE6_STATIC_ASSET_USES", "schema_version": "1.0.0",
        "channel_id": sources.CHANNEL, "video_id": "video-002",
        "source_bindings": {"untimed_visual_intent": copy.deepcopy(PLAN), "style_bible": copy.deepcopy(BIBLE),
                            "rights_registration": copy.deepcopy(REGISTRATION)},
        "sources": source_rows, "uses": uses, "technical_cost_brl": 0}


def proposed_static_asset_uses(root):
    """Prepare literal input only; it must pass inspect_static_asset_uses separately."""
    _, plan, registration = _envelope(root)
    return _expected(plan, registration)


def inspect_static_asset_uses(root, *, binding):
    """Reopen exact pixels and LIVE rights. No writes, recipes, network or timing."""
    reader, plan, registration = _envelope(root)
    if type(binding) is not dict or set(binding) != {"path", "sha256"}:
        raise ValueError("external source-use document pin required")
    raw = reader.read(binding["path"], binding["sha256"])
    document = sources._json(raw)
    if sources._canonical(document) != raw:
        raise ValueError("source-use document must have canonical byte identity")
    schema = sources._json(reader.read_path(reader.path(SCHEMA), reader.bindings[str(reader.path(SCHEMA))]["sha256"]))
    Draft202012Validator(schema).validate(document)
    _same(document, _expected(plan, registration), "source uses differ from the exact thirteen-use envelope")
    original_sources = document["sources"]
    # Reject absent/corrupted/nonresident provenance before pixel work. This is
    # only a transport preflight; the rights evaluator still recomposes every
    # decision and source below, and the final dependency pass rechecks bytes.
    for entry in original_sources:
        for bound in entry["rights_evidence"].values():
            rights._pin(reader, bound)
    proofs = sources.inspect_static_sources(root, requests=[entry["static_source"] for entry in original_sources])
    by_id, rights_proofs, source_results = {}, [], []
    for entry, proof in zip(original_sources, proofs, strict=True):
        proof_rights = rights.inspect_static_asset_rights(root, **entry["static_source"],
            **entry["rights_evidence"], expected_evidence_mode="LIVE")
        _same([proof_rights.get("status"), proof_rights.get("scope"), proof_rights.get("evidence_mode")],
              ["PASS", "RIGHTS_BINDING_ONLY", "LIVE"], "current source rights did not pass")
        _same(proof_rights["source_proof"]["sha256"], sources._sha(sources._canonical(proof)),
              "rights and independently inspected source do not match")
        _same(proof_rights["asset_id"], entry["source_id"], "rights asset identity differs")
        by_id[entry["source_id"]] = proof
        rights_proofs.append(proof_rights)
        source_results.append({"source_id": entry["source_id"], "asset_binding": copy.deepcopy(proof["asset_binding"]),
            "template_id": proof["template_id"], "state_id": proof["state_id"], "lineage_id": proof["lineage_id"],
            "original_unit_id": proof["unit_id"], "original_fragment_ids": copy.deepcopy(proof["fragment_ids"]),
            "original_lexical_target": copy.deepcopy(proof["lexical_target"]),
            "source_inspection_id": proof["inspection_id"], "source_inspection_sha256": sources._sha(sources._canonical(proof)),
            "rights_inspection_id": proof_rights["inspection_id"],
            "rights_inspection_sha256": sources._sha(sources._canonical(proof_rights))})
    rows = {row["unit_id"]: row for row in plan["rows"]}
    results = []
    for use in document["uses"]:
        proof = by_id[use["source_id"]]
        row = rows[use["unit_id"]]
        state = next(state for state in row["states"] if state["state_id"] == use["visual_state_id"])
        _same(use["literal_copy"], proof["text_lines"], "new use visible copy does not match original pixels")
        if use["unit_id"] == proof["unit_id"]:
            _same(row["text"], proof["literal_narration"], "original narration changed")
            target = proof["lexical_target"]
            if target is not None:
                _same({key: state["entry"][key] for key in ("char_start", "char_end", "text")},
                      {key: target[key] for key in ("char_start", "char_end", "text")}, "original reveal changed")
                _same(state["entry"]["kind"], "LEXICAL_START", "lexical reveal cannot become a unit entry")
        else:
            # The only two new uses are observation-only callbacks, never their
            # attributed fear verdict. Preserve original source proof IDs/text.
            _same(state["entry"]["kind"], "UNIT_ENTRY", "callback cannot introduce an internal reveal")
            _same(proof["lexical_target"], None, "callback cannot inherit a fear verdict reveal")
        results.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]),
            "source_provenance_unit_id": proof["unit_id"],
            "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
    sources.recheck_static_dependencies(root, proofs)
    # Recheck every same-call source/rights/input/code dependency. No cached
    # authority is accepted and a concurrent mutation does not trigger overwrite.
    dependency_map = dict(reader.bindings)
    for proof in rights_proofs:
        for item in proof["dependency_bindings"]:
            previous = dependency_map.setdefault(item["path"], item)
            _same(previous, item, "conflicting dependency identities")
    for path, item in sorted(dependency_map.items()):
        if not Path(path).is_relative_to(reader.root) and sources.EXTERNAL_DEPENDENCY_PINS.get(path) != item["sha256"]:
            raise ValueError("source-use dependency escapes the external allowlist")
        if len(reader.read_path(Path(path), item["sha256"])) != item["size_bytes"]:
            raise ValueError("source-use dependency size changed")
    covered = {use["visual_state_id"] for use in results}
    all_states = {state["state_id"] for row in plan["rows"] for state in row["states"]}
    value = {"version": VERSION, "status": "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY",
        "input_binding": copy.deepcopy(binding), "source_bindings": copy.deepcopy(document["source_bindings"]),
        "channel_id": sources.CHANNEL, "video_id": "video-002", "source_count": len(source_results),
        "use_count": len(results), "lineage_count": len({item["lineage_id"] for item in source_results}),
        "sources": source_results, "uses": results, "remaining_unbound_visual_state_ids": sorted(all_states - covered),
        "source_ready": False, "global_schedule_created": False, "authority": dict(AUTHORITY),
        "technical_cost_brl": 0, "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"]),
        "claim_boundary": "Thirteen literal uses, eleven existing stills, two lineages. No calibrated times, production spans, publicity, perceptual quality, B admission, render or publication."}
    value["inspection_id"] = "static-asset-uses-" + sources._sha(sources._canonical(value))[:24]
    return value


def verify_static_asset_uses(candidate, root, *, binding):
    expected = inspect_static_asset_uses(root, binding=binding)
    _same(candidate, expected, "source-use inspection replay differs")
    return expected
