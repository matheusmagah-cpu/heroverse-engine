"""Idempotent Phase 2 miner for the four approved gold-standard fixtures."""

from __future__ import annotations

import json
import os
import re
import shutil
import stat
import sys
import time
import traceback
import tracemalloc
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from hero_engine.contracts.analysis import canonical_hash, file_sha256, validate_analysis
from hero_engine.mining.adapters import (
    FrameExtractionAdapter,
    MediaProbeAdapter,
    OcrAdapter,
    SceneDetectionAdapter,
    TranscriptAdapter,
    take_frame_times,
    tool_versions,
    visual_measurements,
)
from hero_engine.mining.semantics import build_analysis, normalize_boundaries, relpath


ROOT = Path(__file__).resolve().parents[2]
GOLD_ROOT = ROOT / "data" / "gold_standard"
SOURCE_ROOT = ROOT / "data" / "modeling" / "grace-grit-love" / "full"
OUTPUT_ROOT = ROOT / "output" / "mining" / "phase2"
FIXTURE_IDS = ("hkf6nDyUfAM", "_sOy7htXJi8", "Pkede5acSFw", "huvUy3pJSp8")
IMPLEMENTATION_FILES = (
    ROOT / "hero_engine" / "contracts" / "analysis.py",
    ROOT / "hero_engine" / "mining" / "adapters.py",
    ROOT / "hero_engine" / "mining" / "narrative.py",
    ROOT / "hero_engine" / "mining" / "semantics.py",
    ROOT / "hero_engine" / "mining" / "pipeline.py",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


@dataclass(frozen=True)
class MinerConfig:
    pipeline_version: str = "miner-local-0.2.0"
    transcription_model: str = "base.en"
    transcription_language: str = "en"
    transcription_device: str = "cpu"
    transcription_compute_type: str = "int8"
    transcription_beam_size: int = 5
    transcription_vad_filter: bool = True
    scene_threshold: float = 0.25
    ocr_minimum_confidence: float = 0.70
    keyframe_width: int = 640

    def normalized(self) -> dict[str, Any]:
        return asdict(self)


def fixture_catalog() -> dict[str, dict[str, Any]]:
    manifest = read_json(GOLD_ROOT / "manifest.json")
    return {item["video_id"]: item for item in manifest["videos"]}


def implementation_hash() -> str:
    return canonical_hash({relpath(path, ROOT): file_sha256(path) for path in IMPLEMENTATION_FILES})


def job_key_for(source_hash: str, config: MinerConfig) -> str:
    return canonical_hash({
        "source_hash": source_hash,
        "pipeline_version": config.pipeline_version,
        "implementation_hash": implementation_hash(),
        "parameters": config.normalized(),
    })


def _artifact_inventory(job_dir: Path) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for path in sorted(job_dir.rglob("*")):
        if path.is_file() and path.name != "run_manifest.json":
            items.append({
                "path": relpath(path, ROOT),
                "sha256": file_sha256(path),
                "bytes": path.stat().st_size,
            })
    return items


class CacheIntegrityError(ValueError):
    """An existing fixture job is preserved; automatic reconstruction is forbidden."""

    code = "CACHE_INTEGRITY_BLOCKED"


class CacheRecoveryProofRequired(CacheIntegrityError):
    """Partial/failed checkpoints have no verified resume contract in this version."""

    code = "CACHE_RECOVERY_PROOF_REQUIRED"


def _cache_json(path: Path) -> Any:
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result

    def finite_only(value):
        raise ValueError(f"nonfinite JSON value: {value}")

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_pairs,
                      parse_constant=finite_only)


def _cache_unlinked(path: Path, *, directory: bool) -> None:
    info = path.lstat()
    forbidden = (getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
                 | getattr(stat, "FILE_ATTRIBUTE_OFFLINE", 0x1000)
                 | getattr(stat, "FILE_ATTRIBUTE_RECALL_ON_OPEN", 0x40000)
                 | getattr(stat, "FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS", 0x400000))
    if (getattr(info, "st_file_attributes", 0) & forbidden
            or (not stat.S_ISDIR(info.st_mode) if directory else not stat.S_ISREG(info.st_mode))
            or (not directory and info.st_nlink != 1)):
        raise ValueError("linked, offline or nonregular cache entry")


def _cache_files(job_dir: Path) -> set[str]:
    # Inspect ancestors too: checking only the leaf does not detect a junction.
    for path in (job_dir, *job_dir.parents):
        _cache_unlinked(path, directory=True)
    files: set[str] = set()
    pending = [job_dir]
    while pending:
        for path in pending.pop().iterdir():
            info = path.lstat()
            directory = stat.S_ISDIR(info.st_mode)
            _cache_unlinked(path, directory=directory)
            if directory:
                pending.append(path)
            else:
                files.add(path.relative_to(job_dir).as_posix())
    return files


def _expected_cache_files(job_dir: Path, manifest: dict[str, Any], actual: set[str]) -> set[str]:
    """Reconstruct the two historical recipes, never trust a shortened inventory."""
    version = manifest["pipeline_version"]
    if version not in ("miner-local-0.1.0", "miner-local-0.2.0"):
        raise ValueError("unknown fixture cache recipe")
    expected = {
        "events.jsonl", "transcript.raw.json", "scene_boundaries.json", "ocr_manifest.json",
        "take_candidates.json", "video_mining.json", "resource_usage.json", "ocr/thumbnail.json",
    }
    candidates = _cache_json(job_dir / "take_candidates.json")
    duration = candidates["duration_ms"]
    takes = candidates["takes"]
    if (type(duration) is not int or duration <= 0 or not isinstance(takes, list) or not takes
            or type(candidates["take_count"]) is not int or candidates["take_count"] != len(takes)):
        raise ValueError("invalid take inventory")
    previous_end, ocr_count = 0, 1
    for index, take in enumerate(takes, 1):
        take_id = f"take-{index:03d}"
        start, end = take["start_ms"], take["end_ms"]
        if (take["take_id"] != take_id or type(start) is not int or type(end) is not int
                or start != previous_end or end <= start or end > duration
                or type(take["duration_ms"]) is not int or take["duration_ms"] != end - start):
            raise ValueError("noncontiguous or incomplete take inventory")
        frames = [f"keyframes/{take_id}-{label}.jpg" for label in ("start", "mid", "end")]
        if take["keyframes"] != [relpath(job_dir / name, ROOT) for name in frames]:
            raise ValueError("keyframe identity mismatch")
        expected.update(frames)
        if version == "miner-local-0.1.0":
            expected.add(f"ocr/{take_id}.json")
            ocr_count += 1
        else:
            labels = ("start", "mid", "end") if start < 8000 or end > max(0, duration - 8000) else ("mid",)
            expected.update(f"ocr/{take_id}-{label}.json" for label in labels)
            ocr_count += len(labels)
        previous_end = end
    if previous_end != duration:
        raise ValueError("take inventory does not cover duration")
    resources = _cache_json(job_dir / "resource_usage.json")
    if canonical_hash(resources) != canonical_hash(manifest["resources"]):
        raise ValueError("resource receipt mismatch")
    for key, value in (("take_count", len(takes)), ("keyframe_count", 3 * len(takes)), ("ocr_image_count", ocr_count)):
        if type(resources[key]) is not int or resources[key] != value:
            raise ValueError("resource inventory count mismatch")
    # Only real FAILED receipts from the existing recovery contract are optional.
    attempts = {name for name in actual if name.startswith("attempts/")}
    if type(resources["prior_failed_attempt_count"]) is not int or resources["prior_failed_attempt_count"] != len(attempts):
        raise ValueError("failure history count mismatch")
    for name in attempts:
        failure = _cache_json(job_dir / name)
        if (failure.get("status") != "FAILED"
                or any(failure.get(key) != manifest[key] for key in ("video_id", "job_key", "source_hash", "pipeline_version"))
                or name != f"attempts/failure-{str(failure.get('failed_at') or 'unknown').replace(':', '-')}.json"):
            raise ValueError("unbound failure history")
    expected.update(attempts)
    analysis = _cache_json(job_dir / "video_mining.json")
    if (canonical_hash(analysis) != manifest["semantic_hash"]
            or analysis["source"]["video_id"] != manifest["video_id"]
            or analysis["source"]["content_hash"] != manifest["source_hash"]
            or type(analysis["source"]["duration_ms"]) is not int or analysis["source"]["duration_ms"] != duration):
        raise ValueError("analysis identity mismatch")
    if _cache_json(job_dir / "scene_boundaries.json")["source_hash"] != manifest["source_hash"]:
        raise ValueError("scene source mismatch")
    if _cache_json(job_dir / "transcript.raw.json")["video_id"] != manifest["video_id"]:
        raise ValueError("transcript source mismatch")
    return expected


def _cache_valid(job_dir: Path, *, source_hash: str | None = None) -> bool:
    """Read-only integrity of Phase 2 fixtures, not live-market or rights approval."""
    try:
        job_dir = Path(job_dir).absolute()
        relative = job_dir.relative_to(OUTPUT_ROOT.absolute())
        if (len(relative.parts) != 2 or relative.parts[0] not in FIXTURE_IDS
                or not re.fullmatch(r"[0-9a-f]{64}", relative.parts[1])):
            return False
        actual = _cache_files(job_dir)
        manifest = _cache_json(job_dir / "run_manifest.json")
        if (manifest["status"] != "COMPLETE" or manifest["video_id"] != relative.parts[0]
                or manifest["job_key"] != relative.parts[1]
                or not re.fullmatch(r"[0-9a-f]{64}", manifest["source_hash"])
                or (source_hash is not None and manifest["source_hash"] != source_hash)):
            return False
        artifacts = manifest["artifacts"]
        if (not isinstance(artifacts, list) or not artifacts
                or type(manifest["artifact_count"]) is not int or manifest["artifact_count"] != len(artifacts)
                or type(manifest["artifact_bytes"]) is not int):
            return False
        inventory: set[str] = set()
        byte_count = 0
        prefix = relpath(job_dir, ROOT) + "/"
        for item in artifacts:
            if not isinstance(item, dict) or set(item) != {"path", "sha256", "bytes"}:
                return False
            name = item["path"]
            if not isinstance(name, str) or not name.startswith(prefix):
                return False
            name = name[len(prefix):]
            if (not name or any(part in ("", ".", "..") for part in name.split("/"))
                    or "\\" in name or ":" in name or name in inventory or name == "run_manifest.json"
                    or name not in actual or type(item["bytes"]) is not int or item["bytes"] <= 0
                    or not isinstance(item["sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", item["sha256"])):
                return False
            path = job_dir / name
            if path.stat().st_size != item["bytes"] or file_sha256(path) != item["sha256"]:
                return False
            inventory.add(name)
            byte_count += item["bytes"]
        return bool(
            byte_count == manifest["artifact_bytes"]
            and inventory == actual - {"run_manifest.json"}
            and inventory == _expected_cache_files(job_dir, manifest, actual)
        )
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
        return False


def _existing_cache_error(job_dir: Path) -> CacheIntegrityError:
    """Classify only resident metadata; never follow a failed cache's links."""
    error_type = CacheIntegrityError
    try:
        for path in (job_dir, *job_dir.parents):
            _cache_unlinked(path, directory=True)
        manifest_path = job_dir / "run_manifest.json"
        if not os.path.lexists(manifest_path):
            error_type = CacheRecoveryProofRequired
        else:
            _cache_unlinked(manifest_path, directory=False)
            if _cache_json(manifest_path).get("status") in ("FAILED", "RUNNING"):
                error_type = CacheRecoveryProofRequired
    except (OSError, ValueError, TypeError, AttributeError, RecursionError):
        pass
    return error_type(f"{error_type.code}: existing fixture job preserved without provider calls: {job_dir}")


def merge_ocr_scans(scans: list[tuple[str, dict[str, Any]]]) -> dict[str, Any]:
    """Deduplicate literal OCR across selected frames while retaining provenance."""
    by_text: dict[str, dict[str, Any]] = {}
    rejected: list[dict[str, Any]] = []
    for label, scan in scans:
        for line in scan.get("lines", []):
            text = line["text"]
            provenance = {"frame_label": label, "artifact": scan["image"]}
            if text not in by_text or float(line["confidence"]) > float(by_text[text]["confidence"]):
                prior_provenance = by_text.get(text, {}).get("frame_provenance", [])
                replacement = dict(line)
                replacement["frame_provenance"] = [*prior_provenance, provenance]
                by_text[text] = replacement
            else:
                by_text[text].setdefault("frame_provenance", []).append(provenance)
        for line in scan.get("rejected_lines", []):
            rejected.append({**line, "frame_label": label, "artifact": scan["image"]})
    lines = list(by_text.values())
    return {
        "provider": scans[0][1]["provider"] if scans else None,
        "provider_version": scans[0][1]["provider_version"] if scans else None,
        "minimum_confidence": scans[0][1]["minimum_confidence"] if scans else None,
        "images": [scan["image"] for _, scan in scans],
        "scan_count": len(scans),
        "lines": lines,
        "rejected_lines": rejected,
        "text": " ".join(line["text"] for line in lines),
        "mean_confidence": (
            round(sum(float(line["confidence"]) for line in lines) / len(lines), 5)
            if lines else None
        ),
    }


class MiningPipeline:
    """A local executor with replaceable providers and fail-closed outputs."""

    def __init__(self, config: MinerConfig | None = None, *,
                 progress: Callable[[str], None] | None = None):
        self.config = config or MinerConfig()
        self.progress = progress or (lambda message: print(message, file=sys.stderr, flush=True))
        self.probe = MediaProbeAdapter()
        self.scenes = SceneDetectionAdapter()
        self.frames = FrameExtractionAdapter()
        self.transcript = TranscriptAdapter(
            self.config.transcription_model,
            language=self.config.transcription_language,
            device=self.config.transcription_device,
            compute_type=self.config.transcription_compute_type,
        )
        self.ocr = OcrAdapter(minimum_confidence=self.config.ocr_minimum_confidence)
        self._tools: dict[str, str] | None = None

    @property
    def tools(self) -> dict[str, str]:
        if self._tools is None:
            self._tools = tool_versions()
        return self._tools

    def _event(self, job_dir: Path, video_id: str, stage: str, **fields: Any) -> None:
        event = {"at": utc_now(), "video_id": video_id, "stage": stage, **fields}
        job_dir.mkdir(parents=True, exist_ok=True)
        with (job_dir / "events.jsonl").open("a", encoding="utf-8") as target:
            target.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
        self.progress(f"[{video_id}] {stage}")

    def _compatible_donor(self, video_id: str, source_hash: str, current_job_dir: Path) -> Path | None:
        comparable = (
            "transcription_model", "transcription_language", "transcription_device",
            "transcription_compute_type", "transcription_beam_size",
            "transcription_vad_filter", "scene_threshold", "keyframe_width",
        )
        source_dir = OUTPUT_ROOT / video_id
        if not source_dir.is_dir():
            return None
        for candidate in sorted(source_dir.iterdir(), key=lambda path: path.name):
            if candidate == current_job_dir or not candidate.is_dir() or not _cache_valid(candidate):
                continue
            manifest = read_json(candidate / "run_manifest.json")
            parameters = manifest.get("parameters", {})
            if manifest.get("source_hash") != source_hash:
                continue
            if all(parameters.get(field) == getattr(self.config, field) for field in comparable):
                if (candidate / "transcript.raw.json").is_file() and (candidate / "scene_boundaries.json").is_file():
                    return candidate
        return None

    def mine(self, video_id: str) -> dict[str, Any]:
        if video_id not in FIXTURE_IDS:
            raise ValueError(f"Phase 2 accepts only approved fixtures: {', '.join(FIXTURE_IDS)}")
        item = fixture_catalog()[video_id]
        source_path = SOURCE_ROOT / f"{video_id}.mp4"
        info_path = SOURCE_ROOT / f"{video_id}.info.json"
        thumbnail_path = SOURCE_ROOT / f"{video_id}.jpg"
        missing = [str(path) for path in (source_path, info_path, thumbnail_path) if not path.is_file()]
        if missing:
            raise FileNotFoundError("missing required fixture artifacts: " + ", ".join(missing))
        source_hash = file_sha256(source_path)
        if source_hash != item["content_sha256"]:
            raise ValueError(
                f"fixture hash mismatch for {video_id}: manifest={item['content_sha256']} actual={source_hash}"
            )
        job_key = job_key_for(source_hash, self.config)
        code_hash = implementation_hash()
        job_dir = OUTPUT_ROOT / video_id / job_key
        if _cache_valid(job_dir, source_hash=source_hash):
            manifest = read_json(job_dir / "run_manifest.json")
            from hero_engine.compile_cache_retention import collect_completed_caches
            collect_completed_caches(ROOT)
            self.progress(f"[{video_id}] CACHE_HIT {job_key[:16]}")
            return {
                "video_id": video_id,
                "job_key": job_key,
                "cache_hit": True,
                "job_dir": str(job_dir),
                "analysis": str(job_dir / "video_mining.json"),
                "semantic_hash": manifest["semantic_hash"],
                "manifest": str(job_dir / "run_manifest.json"),
            }

        if os.path.lexists(job_dir):
            raise _existing_cache_error(job_dir)
        job_dir.mkdir(parents=True, exist_ok=False)
        donor_dir = self._compatible_donor(video_id, source_hash, job_dir)
        started_at = utc_now()
        write_json(job_dir / "run_manifest.json", {
            "schema_version": "1.0.0", "status": "RUNNING", "video_id": video_id,
            "job_key": job_key, "source_hash": source_hash, "pipeline_version": self.config.pipeline_version,
            "implementation_hash": code_hash, "parameters": self.config.normalized(), "started_at": started_at,
        })
        wall_start, cpu_start = time.perf_counter(), time.process_time()
        tracemalloc.start()
        try:
            self._event(job_dir, video_id, "INSPECTING_MEDIA")
            probe = self.probe.inspect(source_path)
            duration_ms = round(float(probe["format"]["duration"]) * 1000)
            video_stream = next(stream for stream in probe["streams"] if stream.get("codec_type") == "video")
            visual_duration_seconds = float(video_stream.get("duration") or probe["format"]["duration"])

            self._event(job_dir, video_id, "TRANSCRIBING")
            transcript_path = job_dir / "transcript.raw.json"
            if not transcript_path.is_file() and donor_dir is not None:
                shutil.copy2(donor_dir / "transcript.raw.json", transcript_path)
                self._event(
                    job_dir, video_id, "TRANSCRIPT_DONOR_REUSED",
                    donor=relpath(donor_dir / "transcript.raw.json", ROOT),
                )
            if transcript_path.is_file():
                transcript_candidate = read_json(transcript_path)
                transcript_reusable = bool(
                    transcript_candidate.get("video_id") == video_id
                    and transcript_candidate.get("model") == self.config.transcription_model
                    and transcript_candidate.get("provider") == self.transcript.provider
                )
            else:
                transcript_reusable = False
            if transcript_reusable:
                transcript = transcript_candidate
                self._event(job_dir, video_id, "TRANSCRIPT_CHECKPOINT_HIT")
            else:
                transcript = self.transcript.transcribe(
                    source_path, video_id,
                    beam_size=self.config.transcription_beam_size,
                    vad_filter=self.config.transcription_vad_filter,
                )
                write_json(transcript_path, transcript)

            self._event(job_dir, video_id, "DETECTING_TAKES")
            scene_checkpoint_path = job_dir / "scene_boundaries.json"
            if not scene_checkpoint_path.is_file() and donor_dir is not None:
                shutil.copy2(donor_dir / "scene_boundaries.json", scene_checkpoint_path)
                self._event(
                    job_dir, video_id, "SCENE_DONOR_REUSED",
                    donor=relpath(donor_dir / "scene_boundaries.json", ROOT),
                )
            if scene_checkpoint_path.is_file():
                scene_checkpoint = read_json(scene_checkpoint_path)
                scene_reusable = bool(
                    scene_checkpoint.get("source_hash") == source_hash
                    and scene_checkpoint.get("threshold") == self.config.scene_threshold
                )
            else:
                scene_reusable = False
            if scene_reusable:
                scene_seconds = scene_checkpoint["boundaries_seconds"]
                self._event(job_dir, video_id, "SCENE_CHECKPOINT_HIT")
            else:
                scene_seconds = self.scenes.detect(
                    source_path, duration_ms / 1000, self.config.scene_threshold,
                )
                write_json(scene_checkpoint_path, {
                    "source_hash": source_hash,
                    "provider": self.scenes.provider,
                    "threshold": self.config.scene_threshold,
                    "boundaries_seconds": scene_seconds,
                })
            boundaries_ms = normalize_boundaries(scene_seconds, duration_ms)

            frame_paths: dict[str, list[Path]] = {}
            frame_requests: list[tuple[float, Path]] = []
            take_rows: list[dict[str, Any]] = []
            for index, (start_ms, end_ms) in enumerate(zip(boundaries_ms, boundaries_ms[1:]), 1):
                take_id = f"take-{index:03d}"
                times = tuple(
                    min(value, max(start_ms / 1000, visual_duration_seconds - 0.10))
                    for value in take_frame_times(start_ms / 1000, end_ms / 1000)
                )
                labels = ("start", "mid", "end")
                paths = [job_dir / "keyframes" / f"{take_id}-{label}.jpg" for label in labels]
                frame_paths[take_id] = paths
                frame_requests.extend(zip(times, paths))
                take_rows.append({
                    "take_id": take_id, "start_ms": start_ms, "end_ms": end_ms,
                    "duration_ms": end_ms - start_ms,
                    "frame_times_ms": [round(value * 1000) for value in times],
                    "keyframes": [relpath(path, ROOT) for path in paths],
                })

            self._event(job_dir, video_id, "EXTRACTING_KEYFRAMES", count=len(frame_requests))
            self.frames.extract(source_path, frame_requests, width=self.config.keyframe_width)

            self._event(job_dir, video_id, "RUNNING_OCR", takes=len(take_rows))
            ocr_by_take: dict[str, dict[str, Any]] = {}
            visual_by_take: dict[str, dict[str, Any]] = {}
            ocr_image_count = 0
            for row in take_rows:
                take_id = row["take_id"]
                middle = frame_paths[take_id][1]
                intersects_priority_window = bool(
                    int(row["start_ms"]) < 8000
                    or int(row["end_ms"]) > max(0, duration_ms - 8000)
                )
                selected_indices = (0, 1, 2) if intersects_priority_window else (1,)
                scans: list[tuple[str, dict[str, Any]]] = []
                for frame_index in selected_indices:
                    label = ("start", "mid", "end")[frame_index]
                    image_path = frame_paths[take_id][frame_index]
                    ocr_checkpoint = job_dir / "ocr" / f"{take_id}-{label}.json"
                    if ocr_checkpoint.is_file():
                        ocr_candidate = read_json(ocr_checkpoint)
                        ocr_reusable = bool(
                            ocr_candidate.get("provider") == self.ocr.provider
                            and ocr_candidate.get("minimum_confidence") == self.config.ocr_minimum_confidence
                            and ocr_candidate.get("image") == str(image_path)
                        )
                    else:
                        ocr_reusable = False
                    if not ocr_reusable:
                        ocr_candidate = self.ocr.scan(image_path)
                        write_json(ocr_checkpoint, ocr_candidate)
                    scans.append((label, ocr_candidate))
                ocr_by_take[take_id] = merge_ocr_scans(scans)
                ocr_image_count += len(scans)
                visual_by_take[take_id] = visual_measurements(middle)
                row["ocr"] = ocr_by_take[take_id]
                row["visual_measurements"] = visual_by_take[take_id]
            thumbnail_ocr_path = job_dir / "ocr" / "thumbnail.json"
            if thumbnail_ocr_path.is_file():
                thumbnail_candidate = read_json(thumbnail_ocr_path)
                thumbnail_reusable = bool(
                    thumbnail_candidate.get("provider") == self.ocr.provider
                    and thumbnail_candidate.get("minimum_confidence") == self.config.ocr_minimum_confidence
                    and thumbnail_candidate.get("image") == str(thumbnail_path)
                )
            else:
                thumbnail_reusable = False
            if thumbnail_reusable:
                thumbnail_ocr = thumbnail_candidate
            else:
                thumbnail_ocr = self.ocr.scan(thumbnail_path)
                write_json(thumbnail_ocr_path, thumbnail_ocr)
            ocr_image_count += 1
            thumbnail_visual = visual_measurements(thumbnail_path)
            write_json(job_dir / "ocr_manifest.json", {
                "provider": self.ocr.provider,
                "minimum_confidence": self.config.ocr_minimum_confidence,
                "thumbnail": thumbnail_ocr,
                "takes": ocr_by_take,
            })
            take_artifact_path = job_dir / "take_candidates.json"
            write_json(take_artifact_path, {
                "provider": self.scenes.provider,
                "threshold": self.config.scene_threshold,
                "duration_ms": duration_ms,
                "take_count": len(take_rows),
                "takes": take_rows,
            })

            self._event(job_dir, video_id, "ASSEMBLING_ANALYSIS")
            info = read_json(info_path)
            analysis_id = f"phase2-{video_id}-{job_key[:16]}"
            analysis = build_analysis(
                root=ROOT, video_id=video_id, source_hash=source_hash,
                source_path=source_path, info_path=info_path, thumbnail_path=thumbnail_path,
                info=info, probe=probe, transcript=transcript, transcript_path=transcript_path,
                take_artifact_path=take_artifact_path, boundaries_ms=boundaries_ms,
                frame_paths=frame_paths, ocr_by_take=ocr_by_take, visual_by_take=visual_by_take,
                thumbnail_ocr=thumbnail_ocr, thumbnail_visual=thumbnail_visual,
                analysis_id=analysis_id, captured_at=started_at, tools=self.tools,
            )
            first_validation = validate_analysis(analysis, root=ROOT)
            analysis["quality"]["schema_valid"] = first_validation.schema_valid
            analysis["quality"]["evidence_resolvable"] = first_validation.evidence_resolvable
            if first_validation.errors:
                analysis["quality"]["issues"].extend(first_validation.errors)
            final_validation = validate_analysis(analysis, root=ROOT, raise_on_error=True)
            analysis_path = job_dir / "video_mining.json"
            write_json(analysis_path, analysis)

            peak_memory = tracemalloc.get_traced_memory()[1]
            tracemalloc.stop()
            current_wall_seconds = round(time.perf_counter() - wall_start, 4)
            prior_attempt_wall_seconds = sum(
                float(read_json(path).get("wall_seconds", 0.0))
                for path in (job_dir / "attempts").glob("failure-*.json")
            ) if (job_dir / "attempts").is_dir() else 0.0
            resource_usage = {
                "wall_seconds": round(current_wall_seconds + prior_attempt_wall_seconds, 4),
                "wall_seconds_current_attempt": current_wall_seconds,
                "wall_seconds_prior_failed_attempts": round(prior_attempt_wall_seconds, 4),
                "prior_failed_attempt_count": len(list((job_dir / "attempts").glob("failure-*.json"))) if (job_dir / "attempts").is_dir() else 0,
                "cpu_seconds_python_process": round(time.process_time() - cpu_start, 4),
                "python_tracemalloc_peak_bytes": peak_memory,
                "external_api_cost_usd": 0.0,
                "source_bytes": source_path.stat().st_size,
                "take_count": len(take_rows),
                "keyframe_count": len(frame_requests),
                "ocr_image_count": ocr_image_count,
                "asr_word_count": transcript["measurements"]["word_count"],
                "measurement_limitations": [
                    "tracemalloc measures Python allocations, not full native-library RSS.",
                    "CPU process time excludes work performed in external ffmpeg/ffprobe processes.",
                    "External API cost is zero because all providers executed locally; electricity/hardware depreciation are not priced.",
                ],
            }
            write_json(job_dir / "resource_usage.json", resource_usage)
            self._event(job_dir, video_id, "VALIDATED", evidence_ids=len(final_validation.evidence_ids))
            artifacts = _artifact_inventory(job_dir)
            semantic_hash = canonical_hash(analysis)
            completed_at = utc_now()
            manifest = {
                "schema_version": "1.0.0",
                "status": "COMPLETE",
                "video_id": video_id,
                "job_key": job_key,
                "source_hash": source_hash,
                "pipeline_version": self.config.pipeline_version,
                "implementation_hash": code_hash,
                "parameters": self.config.normalized(),
                "tools": self.tools,
                "started_at": started_at,
                "completed_at": completed_at,
                "semantic_hash": semantic_hash,
                "validation": {
                    "schema_valid": final_validation.schema_valid,
                    "evidence_resolvable": final_validation.evidence_resolvable,
                    "evidence_id_count": len(final_validation.evidence_ids),
                },
                "resources": resource_usage,
                "artifacts": artifacts,
                "artifact_count": len(artifacts),
                "artifact_bytes": sum(item["bytes"] for item in artifacts),
            }
            write_json(job_dir / "run_manifest.json", manifest)
            # Only sealed disposable compiler caches are eligible in T25.
            # Gold sources and analysis artifacts remain byte-bound dependencies.
            from hero_engine.compile_cache_retention import collect_completed_caches
            collect_completed_caches(ROOT)
            self.progress(f"[{video_id}] COMPLETE {job_key[:16]} {resource_usage['wall_seconds']}s")
            return {
                "video_id": video_id,
                "job_key": job_key,
                "cache_hit": False,
                "job_dir": str(job_dir),
                "analysis": str(analysis_path),
                "semantic_hash": semantic_hash,
                "manifest": str(job_dir / "run_manifest.json"),
                "resources": resource_usage,
            }
        except Exception as exc:
            if tracemalloc.is_tracing():
                peak_memory = tracemalloc.get_traced_memory()[1]
                tracemalloc.stop()
            else:
                peak_memory = None
            failure = {
                "schema_version": "1.0.0", "status": "FAILED", "video_id": video_id,
                "job_key": job_key, "source_hash": source_hash,
                "pipeline_version": self.config.pipeline_version,
                "implementation_hash": code_hash,
                "parameters": self.config.normalized(), "started_at": started_at,
                "failed_at": utc_now(), "error_type": type(exc).__name__, "error": str(exc),
                "wall_seconds": round(time.perf_counter() - wall_start, 4),
                "python_tracemalloc_peak_bytes": peak_memory,
                "traceback": traceback.format_exc(limit=20),
                "silent_fallback_used": False,
            }
            write_json(job_dir / "run_manifest.json", failure)
            self.progress(f"[{video_id}] FAILED {type(exc).__name__}: {exc}")
            raise


def mine_fixtures(config: MinerConfig | None = None) -> list[dict[str, Any]]:
    pipeline = MiningPipeline(config)
    return [pipeline.mine(video_id) for video_id in FIXTURE_IDS]
