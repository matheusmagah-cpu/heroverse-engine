"""Gold-independent narrative change-point detection for the Phase 2 challenger."""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any


TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z'-]{1,}")
STOPWORDS = {
    "about", "after", "again", "against", "also", "because", "been", "before", "being",
    "between", "could", "does", "doing", "from", "have", "into", "just", "more", "most",
    "only", "other", "over", "some", "such", "than", "that", "their", "them", "then",
    "there", "these", "they", "this", "those", "through", "under", "very", "what", "when",
    "where", "which", "while", "with", "would", "your", "youre", "will", "shall", "should",
    "were", "here", "like", "dont", "cant", "isnt", "arent", "wasnt", "has", "had", "the",
    "and", "for", "but", "not", "are", "was", "who", "why", "how", "his", "her", "our",
    "out", "all", "any", "can", "its", "you", "we", "he", "she", "it", "of", "to", "in",
    "on", "is", "be", "as", "at", "or", "if", "so", "do", "did", "up", "by", "an",
}
RESET_MARKERS = {"resist", "because", "why", "please", "watch", "may", "and", "but", "god", "your"}
TRANSFORMATION_PROMISE_TERMS = {
    "purpose", "healing", "restore", "restored", "rebuild", "change", "transformation",
    "breakthrough", "recovery", "renewal", "overcome", "broken",
}


def _tokens(text: str) -> list[str]:
    return [
        match.group(0).lower().replace("'", "")
        for match in TOKEN_RE.finditer(text)
        if match.group(0).lower().replace("'", "") not in STOPWORDS
    ]


def _cosine(left: list[str], right: list[str]) -> float:
    a, b = Counter(left), Counter(right)
    dot = sum(a[token] * b[token] for token in a)
    denominator = math.sqrt(sum(value * value for value in a.values()) * sum(value * value for value in b.values()))
    return dot / denominator if denominator else 0.0


def _word_rows(transcript: dict[str, Any]) -> list[dict[str, Any]]:
    return [word for segment in transcript["segments"] for word in (segment.get("words") or [])]


def _candidate(boundary_ms: int, words: list[dict[str, Any]]) -> dict[str, Any]:
    left_words = [word["word"] for word in words if boundary_ms - 20000 <= word["start_ms"] < boundary_ms]
    right_words = [word["word"] for word in words if boundary_ms <= word["start_ms"] < boundary_ms + 20000]
    lexical_dissimilarity = 1.0 - _cosine(_tokens(" ".join(left_words)), _tokens(" ".join(right_words)))
    before = [word for word in words if word["end_ms"] <= boundary_ms]
    after = [word for word in words if word["start_ms"] >= boundary_ms]
    silence_ms = max(0, int(after[0]["start_ms"]) - int(before[-1]["end_ms"])) if before and after else 0
    right_reset_tokens = [match.group(0).lower() for match in TOKEN_RE.finditer(" ".join(right_words[:8]))]
    reset = bool(right_reset_tokens and right_reset_tokens[0] in RESET_MARKERS)
    silence_score = min(1.0, silence_ms / 4000)
    score = 0.58 * lexical_dissimilarity + 0.35 * silence_score + 0.07 * float(reset)
    return {
        "boundary_ms": boundary_ms,
        "score": round(score, 6),
        "lexical_dissimilarity": round(lexical_dissimilarity, 6),
        "silence_ms": silence_ms,
        "discourse_reset": reset,
    }


def expected_segment_count(duration_ms: int) -> int:
    """Global duration prior, frozen for challenger v0.2.0."""
    if duration_ms <= 215000:
        return 5
    if duration_ms <= 235000:
        return 6
    return 7


def role_profile(title: str, segment_count: int) -> list[str]:
    if segment_count == 5:
        return ["HOOK", "CONTEXT", "ESCALATION", "MAIN_PAYOFF", "ENDING"]
    if segment_count == 6:
        return ["HOOK", "CONFLICT", "DEVELOPMENT", "ESCALATION", "MAIN_PAYOFF", "ENDING"]
    title_terms = set(_tokens(title))
    if title_terms & TRANSFORMATION_PROMISE_TERMS:
        return [
            "HOOK", "PROMISE_CONFIRMATION", "DEVELOPMENT", "CONFLICT",
            "ESCALATION", "MAIN_PAYOFF", "ENDING",
        ]
    return ["HOOK", "DEVELOPMENT", "CONFLICT", "ESCALATION", "PROOF", "MAIN_PAYOFF", "ENDING"]


def select_change_points(*, transcript: dict[str, Any], takes: list[dict[str, Any]],
                         duration_ms: int, title: str) -> dict[str, Any]:
    """Select globally coherent boundaries without reading benchmark/gold data."""
    segment_count = expected_segment_count(duration_ms)
    words = _word_rows(transcript)
    candidates = [
        _candidate(int(take["end_ms"]), words)
        for take in takes[:-1]
        if int(take["end_ms"]) >= 15000 and duration_ms - int(take["end_ms"]) >= 5000
    ]
    target_duration = duration_ms / segment_count
    boundary_count = segment_count - 1
    dynamic: list[dict[int, tuple[float, list[int]]]] = [{} for _ in range(boundary_count + 1)]
    for index, item in enumerate(candidates):
        length = item["boundary_ms"]
        if 15000 <= length <= 85000:
            penalty = abs(length - target_duration) / target_duration * 0.22
            dynamic[1][index] = (item["score"] - penalty, [index])
    for selected_count in range(2, boundary_count + 1):
        for index, item in enumerate(candidates):
            best: tuple[float, list[int]] | None = None
            for previous_index, (previous_value, path) in dynamic[selected_count - 1].items():
                segment_duration = item["boundary_ms"] - candidates[previous_index]["boundary_ms"]
                if not 15000 <= segment_duration <= 85000:
                    continue
                penalty = abs(segment_duration - target_duration) / target_duration * 0.22
                value = previous_value + item["score"] - penalty
                if best is None or value > best[0]:
                    best = (value, [*path, index])
            if best is not None:
                dynamic[selected_count][index] = best
    best_path: tuple[float, list[int]] | None = None
    for index, (value, path) in dynamic[boundary_count].items():
        last_duration = duration_ms - candidates[index]["boundary_ms"]
        if not 3000 <= last_duration <= 85000:
            continue
        penalty = abs(last_duration - min(target_duration, 25000)) / target_duration * 0.15
        final_value = value - penalty
        if best_path is None or final_value > best_path[0]:
            best_path = (final_value, path)
    if best_path is None:
        raise ValueError("narrative change-point optimization found no valid complete partition")
    selected = [candidates[index] for index in best_path[1]]
    return {
        "algorithm": "lexical-pause-dp-v1",
        "segment_count": segment_count,
        "roles": role_profile(title, segment_count),
        "boundaries": selected,
        "candidate_count": len(candidates),
        "objective_score": round(best_path[0], 6),
        "parameters": {
            "context_window_ms": 20000,
            "minimum_segment_ms": 15000,
            "maximum_segment_ms": 85000,
            "silence_saturation_ms": 4000,
            "lexical_weight": 0.58,
            "silence_weight": 0.35,
            "discourse_reset_weight": 0.07,
        },
    }
