"""Deterministic, evidence-backed semantic assembly for Phase 2.

The functions in this module only describe signals produced by the local
adapters.  They deliberately avoid naming people or objects that were not
measured by ASR, OCR, metadata, or basic image statistics.
"""

from __future__ import annotations

import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from hero_engine.mining.narrative import select_change_points


TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z'-]{1,}")
STOPWORDS = {
    "about", "after", "again", "against", "also", "because", "been", "before", "being",
    "between", "could", "does", "doing", "from", "have", "into", "just", "more", "most",
    "only", "other", "over", "some", "such", "than", "that", "their", "them", "then",
    "there", "these", "they", "this", "those", "through", "under", "very", "what", "when",
    "where", "which", "while", "with", "would", "your", "youre", "christian", "motivation",
    "grace", "grit", "love", "video", "will", "shall", "should", "were", "here", "like",
    "dont", "cant", "isnt", "arent", "wasnt", "has", "had", "the", "and", "for", "but",
    "not", "are", "was", "who", "why", "how", "his", "her", "our", "out", "all", "any",
    "can", "its", "you", "your", "we", "they", "he", "she", "it", "of", "to", "in", "on",
    "a", "an", "is", "be", "as", "at", "or", "if", "so", "do", "did", "up", "by",
}

EMOTION_LEXICONS = {
    "conflict": {"war", "warfare", "battle", "fight", "enemy", "attack", "vengeance", "broken"},
    "hope": {"hope", "faith", "promise", "renew", "restore", "victory", "purpose", "coming"},
    "urgency": {"now", "must", "today", "ready", "soon", "never", "always", "immediately"},
    "reverence": {"god", "jesus", "christ", "lord", "holy", "spirit", "king", "pray"},
}


def relpath(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def tokens(text: str | None) -> list[str]:
    return [match.group(0).lower().replace("'", "") for match in TOKEN_RE.finditer(text or "")]


def content_tokens(text: str | None) -> list[str]:
    return [token for token in tokens(text) if token not in STOPWORDS and len(token) > 2]


def top_keywords(text: str, limit: int = 8) -> list[str]:
    return [token for token, _ in Counter(content_tokens(text)).most_common(limit)]


def overlap_score(left: str | None, right: str | None) -> float:
    left_set, right_set = set(content_tokens(left)), set(content_tokens(right))
    if not left_set or not right_set:
        return 0.0
    return round(len(left_set & right_set) / len(left_set | right_set), 4)


def sentence_excerpt(text: str, *, limit: int = 220) -> str:
    cleaned = re.sub(r"\s+", " ", text).strip()
    if not cleaned:
        return "No intelligible speech detected."
    sentence = re.split(r"(?<=[.!?])\s+", cleaned, maxsplit=1)[0]
    return sentence if len(sentence) <= limit else sentence[: limit - 1].rstrip() + "…"


def spoken_between(transcript: dict[str, Any], start_ms: int, end_ms: int) -> str | None:
    selected: list[str] = []
    for segment in transcript["segments"]:
        words = segment.get("words") or []
        if words:
            selected.extend(
                word["word"] for word in words
                if int(word["end_ms"]) > start_ms and int(word["start_ms"]) < end_ms
            )
        elif int(segment["end_ms"]) > start_ms and int(segment["start_ms"]) < end_ms:
            selected.append(segment["raw_text"])
    value = re.sub(r"\s+", " ", " ".join(selected)).strip()
    return value or None


def confidence_for_range(transcript: dict[str, Any], start_ms: int, end_ms: int) -> float:
    values = [
        float(segment["confidence"])
        for segment in transcript["segments"]
        if int(segment["end_ms"]) > start_ms and int(segment["start_ms"]) < end_ms
    ]
    return round(sum(values) / len(values), 4) if values else 0.8


def claim(value: Any, evidence_refs: list[str], *, evidence_class: str = "CALCULATED",
          confidence: float = 0.9, reasoning: str | None = None) -> dict[str, Any]:
    return {
        "value": value,
        "class": evidence_class,
        "confidence": round(max(0.0, min(1.0, confidence)), 4),
        "reasoning_summary": reasoning,
        "evidence_refs": evidence_refs,
    }


def evidence(evidence_id: str, evidence_class: str, artifact: str, description: str,
             start_ms: int | None = None, end_ms: int | None = None) -> dict[str, Any]:
    item: dict[str, Any] = {
        "evidence_id": evidence_id,
        "class": evidence_class,
        "artifact": artifact,
        "description": description,
    }
    if start_ms is not None:
        item["start_ms"] = start_ms
    if end_ms is not None:
        item["end_ms"] = end_ms
    return item


def parse_rate(value: str | None) -> float:
    if not value or value == "0/0":
        return 0.0
    numerator, denominator = value.split("/", 1)
    return float(numerator) / float(denominator)


def technical_from_probe(probe: dict[str, Any]) -> dict[str, Any]:
    video = next((stream for stream in probe["streams"] if stream.get("codec_type") == "video"), None)
    audio = next((stream for stream in probe["streams"] if stream.get("codec_type") == "audio"), None)
    if video is None:
        raise ValueError("media has no video stream")
    fmt = probe["format"]
    return {
        "container": fmt.get("format_name"),
        "video_codec": video.get("codec_name"),
        "audio_codec": audio.get("codec_name") if audio else None,
        "width": int(video["width"]),
        "height": int(video["height"]),
        "fps": round(parse_rate(video.get("avg_frame_rate") or video.get("r_frame_rate")), 4),
        "bitrate": int(fmt["bit_rate"]) if fmt.get("bit_rate") else None,
        "audio_present": audio is not None,
        "audio_sample_rate": int(audio["sample_rate"]) if audio and audio.get("sample_rate") else None,
        "integrity_status": "PASS",
        "issues": [],
    }


def normalize_boundaries(boundaries_seconds: Iterable[float], duration_ms: int) -> list[int]:
    values = sorted({max(0, min(duration_ms, round(value * 1000))) for value in boundaries_seconds})
    values = [0, *[value for value in values if 0 < value < duration_ms], duration_ms]
    return [value for index, value in enumerate(values) if index == 0 or value > values[index - 1]]


def build_takes(
    *, root: Path, video_id: str, source_artifact: str, transcript_artifact: str,
    transcript: dict[str, Any], boundaries_ms: list[int], frame_paths: dict[str, list[Path]],
    ocr_by_take: dict[str, dict[str, Any]], visual_by_take: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    takes: list[dict[str, Any]] = []
    total = len(boundaries_ms) - 1
    for index, (start_ms, end_ms) in enumerate(zip(boundaries_ms, boundaries_ms[1:]), 1):
        take_id = f"take-{index:03d}"
        screen_text = [line["text"] for line in ocr_by_take[take_id]["lines"]]
        spoken = spoken_between(transcript, start_ms, end_ms)
        visual = visual_by_take[take_id]
        frame_refs = [relpath(path, root) for path in frame_paths[take_id]]
        description = (
            f"Measured midpoint is {visual['light_label']} with {visual['dominant_channel']} as the "
            f"largest mean RGB channel; contrast={visual['contrast']}, edge_density={visual['edge_density']}."
        )
        if screen_text:
            description += f" OCR detected {len(screen_text)} text line(s)."
        position = (index - 1) / max(1, total - 1)
        if position < 0.08:
            narrative_function = "OPENING_VISUAL"
        elif position > 0.9:
            narrative_function = "ENDING_VISUAL"
        else:
            narrative_function = "SUPPORTING_VISUAL"
        evidence_id = f"E-{video_id}-TAKE-{index:03d}"
        takes.append({
            "take_id": take_id,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "duration_ms": end_ms - start_ms,
            "keyframes": frame_refs,
            "objective_description": description,
            "subjects": [],
            "objects": screen_text,
            "environment": None,
            "action": None,
            "shot_scale": None,
            "camera_motion": None,
            "screen_text": screen_text,
            "spoken_text": spoken,
            "audio_events": ["speech_detected"] if spoken else ["audio_present_unclassified"],
            "transition_in": "video_start" if index == 1 else "scene_boundary_candidate",
            "transition_out": "video_end" if index == total else "scene_boundary_candidate",
            "narrative_function": narrative_function,
            "retention_function": "visual_refresh_candidate" if index > 1 else "establish_opening",
            "source_asset_ref": source_artifact,
            "evidence": [evidence(
                evidence_id, "CALCULATED", frame_refs[1],
                "Midpoint keyframe, OCR, and image statistics produced by local adapters.",
                start_ms, end_ms,
            )],
            "confidence": round(min(0.98, 0.72 + confidence_for_range(transcript, start_ms, end_ms) * 0.2), 4),
        })
    return takes


def _take_indices_for_window(takes: list[dict[str, Any]], start_ms: int, end_ms: int) -> list[int]:
    return [
        index for index, take in enumerate(takes)
        if int(take["end_ms"]) > start_ms and int(take["start_ms"]) < end_ms
    ]


def build_hooks(*, video_id: str, source_artifact: str, title: str,
                transcript: dict[str, Any], takes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    specs = [("0_1S", 0, 1000), ("1_3S", 1000, 3000), ("3_8S", 3000, 8000), ("8_30S", 8000, 30000)]
    hooks: list[dict[str, Any]] = []
    title_terms = top_keywords(title, 5)
    for label, start_ms, end_ms in specs:
        indices = _take_indices_for_window(takes, start_ms, end_ms)
        screen_text: list[str] = []
        visual_labels: list[str] = []
        for index in indices:
            screen_text.extend(takes[index]["screen_text"])
            visual_labels.append(takes[index]["objective_description"])
        screen_text = list(dict.fromkeys(screen_text))
        spoken = spoken_between(transcript, start_ms, end_ms)
        changes = max(0, len(indices) - 1)
        has_information = bool(spoken or screen_text)
        if spoken:
            function = "SPOKEN_OPENING"
            promise = sentence_excerpt(spoken)
            continuation = "The spoken statement remains incomplete or invites its supporting argument."
        elif screen_text:
            function = "ON_SCREEN_OPENING"
            promise = " ".join(screen_text[:3])
            continuation = "On-screen text establishes a visual cue before the spoken argument."
        else:
            function = "NONVERBAL_OPENING"
            promise = None
            continuation = "Only audiovisual setup is observed in this interval."
        overlap = overlap_score(" ".join(title_terms), f"{spoken or ''} {' '.join(screen_text)}")
        hooks.append({
            "window": label,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "spoken_text": spoken,
            "screen_text": screen_text,
            "visual_description": " ".join(visual_labels[:2]) or "No midpoint scene candidate overlaps the window.",
            "audio_description": "Intelligible speech detected." if spoken else "No intelligible speech detected by local ASR.",
            "visual_change_count": changes,
            "promise": promise,
            "curiosity_gap": "Supporting explanation is not complete inside this window." if has_information else None,
            "emotion": dominant_emotion(f"{spoken or ''} {' '.join(screen_text)}"),
            "pattern_interrupts": ["scene_boundary_candidate"] * min(changes, 5),
            "information_delivered": top_keywords(f"{spoken or ''} {' '.join(screen_text)}", 5),
            "information_withheld": ["supporting argument"] if spoken else [],
            "narrative_function": function,
            "continuation_reason": continuation,
            "promise_break_risk": (
                f"Title/opening lexical overlap is {overlap:.2f}; semantic alignment requires human review."
            ),
            "evidence": [evidence(
                f"E-{video_id}-HOOK-{label}", "CALCULATED", source_artifact,
                "Exact hook window analyzed from ASR, OCR, and take-boundary candidates.", start_ms, end_ms,
            )],
            "confidence": round(min(0.96, 0.76 + confidence_for_range(transcript, start_ms, end_ms) * 0.2), 4),
        })
    return hooks


def build_narrative(*, video_id: str, transcript_artifact: str,
                    transcript: dict[str, Any], takes: list[dict[str, Any]],
                    duration_ms: int, title: str) -> list[dict[str, Any]]:
    model = select_change_points(
        transcript=transcript, takes=takes, duration_ms=duration_ms, title=title,
    )
    endpoints = [0, *[int(item["boundary_ms"]) for item in model["boundaries"]], duration_ms]
    retention_functions = {
        "HOOK": "initiate argument",
        "PROMISE_CONFIRMATION": "confirm the opening promise",
        "CONTEXT": "supply context",
        "CONFLICT": "surface the central tension",
        "DEVELOPMENT": "develop supporting points",
        "PROOF": "support the central claim",
        "ESCALATION": "increase thematic intensity",
        "MAIN_PAYOFF": "deliver late-stage conclusion",
        "ENDING": "close the argument",
    }
    segments: list[dict[str, Any]] = []
    for index, (start_ms, end_ms, role) in enumerate(
        zip(endpoints, endpoints[1:], model["roles"]), 1,
    ):
        group = [
            take for take in takes
            if int(take["end_ms"]) > start_ms and int(take["start_ms"]) < end_ms
        ]
        spoken = spoken_between(transcript, start_ms, end_ms) or ""
        keywords = top_keywords(spoken, 6)
        evidence_id = f"E-{video_id}-NARRATIVE-{index:02d}"
        if index == 1:
            transition = "video_start"
            boundary_description = "Initial boundary is the observed video start."
        else:
            boundary = model["boundaries"][index - 2]
            transition = "lexical-pause change-point"
            boundary_description = (
                f"{model['algorithm']} selected {boundary['boundary_ms']} ms: "
                f"lexical_dissimilarity={boundary['lexical_dissimilarity']}, "
                f"silence_ms={boundary['silence_ms']}, "
                f"discourse_reset={boundary['discourse_reset']}."
            )
        segments.append({
            "segment_id": f"segment-{index:02d}",
            "role": role,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "objective": (
                f"Automatic {role.lower()} hypothesis from a globally optimized, "
                "gold-independent lexical/pause change-point model."
            ),
            "information": keywords,
            "emotion": dominant_emotion(spoken),
            "open_question": "What supporting point follows?" if role not in {"MAIN_PAYOFF", "ENDING"} else None,
            "proof": [sentence_excerpt(spoken)] if spoken else [],
            "transition": transition,
            "retention_function": retention_functions[role],
            "take_refs": [take["take_id"] for take in group],
            "evidence": [evidence(
                evidence_id, "INFERRED", transcript_artifact,
                boundary_description,
                start_ms, end_ms,
            )],
        })
    return segments


def dominant_emotion(text: str) -> str | None:
    observed = Counter(tokens(text))
    scores = {name: sum(observed[word] for word in words) for name, words in EMOTION_LEXICONS.items()}
    if not any(scores.values()):
        return None
    return max(scores, key=lambda name: (scores[name], name))


def build_packaging(*, video_id: str, info: dict[str, Any], info_artifact: str,
                    thumbnail_artifact: str, thumbnail_ocr: dict[str, Any],
                    thumbnail_visual: dict[str, Any], transcript: dict[str, Any],
                    duration_ms: int) -> dict[str, Any]:
    title = str(info.get("title") or "")
    full_speech = " ".join(segment["raw_text"] for segment in transcript["segments"])
    opening = spoken_between(transcript, 0, 30000) or ""
    ending = spoken_between(transcript, max(0, duration_ms - 60000), duration_ms) or ""
    title_terms = top_keywords(title, 8)
    thumb_text = thumbnail_ocr.get("text") or ""
    promise = " ".join(title_terms[:5]) or title
    evidence_ids = {
        "title": f"E-{video_id}-PACK-TITLE",
        "thumb": f"E-{video_id}-PACK-THUMB",
        "opening": f"E-{video_id}-PACK-OPENING",
        "ending": f"E-{video_id}-PACK-ENDING",
    }
    return {
        "title_analysis": claim(
            {"title": title, "content_terms": title_terms}, [evidence_ids["title"]],
            evidence_class="OBSERVED", confidence=1.0,
        ),
        "thumbnail_analysis": claim(
            {"ocr_text": thumb_text, "visual_measurements": thumbnail_visual}, [evidence_ids["thumb"]],
            evidence_class="CALCULATED", confidence=thumbnail_ocr.get("mean_confidence") or 0.75,
        ),
        "combined_promise": claim(
            promise, [evidence_ids["title"], evidence_ids["thumb"]],
            evidence_class="INFERRED", confidence=0.75,
            reasoning="Content terms from public title combined with thumbnail OCR; semantic intent needs human review.",
        ),
        "revealed_information": list(dict.fromkeys([*title_terms, *top_keywords(thumb_text, 5)])),
        "withheld_information": ["supporting argument", "source identity of excerpts"],
        "opening_alignment": claim(
            {"token_jaccard": overlap_score(title, opening), "opening_excerpt": sentence_excerpt(opening)},
            [evidence_ids["opening"]], confidence=0.9,
        ),
        "payoff_alignment": claim(
            {"token_jaccard": overlap_score(title, ending), "ending_excerpt": sentence_excerpt(ending)},
            [evidence_ids["ending"]], confidence=0.9,
        ),
        "evidence": [
            evidence(evidence_ids["title"], "OBSERVED", info_artifact, "Title and public metadata."),
            evidence(evidence_ids["thumb"], "CALCULATED", thumbnail_artifact, "Thumbnail OCR and image statistics."),
            evidence(evidence_ids["opening"], "CALCULATED", info_artifact,
                     "Opening/title token overlap calculated from local ASR and metadata.", 0, min(30000, duration_ms)),
            evidence(evidence_ids["ending"], "CALCULATED", info_artifact,
                     "Ending/title token overlap calculated from local ASR and metadata.", max(0, duration_ms - 60000), duration_ms),
        ],
    }


def build_content_analysis(*, video_id: str, title: str, info_artifact: str,
                           transcript_artifact: str, take_artifact: str,
                           transcript: dict[str, Any], takes: list[dict[str, Any]],
                           duration_ms: int) -> dict[str, Any]:
    full_text = " ".join(segment["raw_text"] for segment in transcript["segments"])
    combined = f"{title} {full_text}"
    keywords = top_keywords(combined, 10)
    words = tokens(full_text)
    duration_minutes = duration_ms / 60000
    speech_minutes = transcript["measurements"]["speech_duration_ms"] / 60000
    cuts_per_minute = max(0, len(takes) - 1) / duration_minutes
    second_person = sum(Counter(tokens(full_text))[word] for word in ("you", "your", "yours"))
    cta_terms = [term for term in ("subscribe", "comment", "share", "like", "follow") if term in tokens(full_text)]
    emotion = dominant_emotion(combined)
    scene_types = list(dict.fromkeys(
        f"{take['objective_description'].split(' with ')[0].replace('Measured midpoint is ', '')} midpoint"
        for take in takes
    ))[:8]
    e_meta = f"E-{video_id}-CONTENT-META"
    e_asr = f"E-{video_id}-CONTENT-ASR"
    e_takes = f"E-{video_id}-CONTENT-TAKES"
    common_refs = [e_asr, e_takes]
    return {
        "topic": claim(keywords[:5], [e_meta, e_asr], evidence_class="INFERRED", confidence=0.82),
        "subtopics": keywords[5:10],
        "angle": claim(
            "direct second-person exhortation" if second_person >= 5 else "declarative thematic exposition",
            [e_asr], evidence_class="INFERRED", confidence=0.78,
        ),
        "thesis": claim(sentence_excerpt(full_text), [e_asr], evidence_class="INFERRED", confidence=0.75),
        "likely_audience": claim(
            "English-speaking Christian-motivation viewers" if "christian" in title.lower() else "English-speaking motivation viewers",
            [e_meta], evidence_class="INFERRED", confidence=0.85,
        ),
        "awareness_level": "topic-aware",
        "narrative_type": claim("motivational sermon montage", common_refs, evidence_class="INFERRED", confidence=0.75),
        "main_emotion": claim(emotion or "not classified", [e_asr], evidence_class="CALCULATED", confidence=0.72),
        "information_density": claim({
            "words": len(words),
            "words_per_video_minute": round(len(words) / duration_minutes, 3),
            "words_per_speech_minute": round(len(words) / speech_minutes, 3) if speech_minutes else 0,
        }, [e_asr], confidence=0.94),
        "editing_rhythm": claim({
            "take_count": len(takes),
            "cuts_per_minute": round(cuts_per_minute, 3),
            "median_take_ms": sorted(take["duration_ms"] for take in takes)[len(takes) // 2],
        }, [e_takes], confidence=0.96),
        "scene_types": scene_types,
        "cta": claim({"detected_terms": cta_terms, "present": bool(cta_terms)}, [e_asr], confidence=0.93),
        "production_complexity": claim(
            "high" if cuts_per_minute >= 15 else "medium" if cuts_per_minute >= 6 else "low",
            [e_takes], confidence=0.9,
        ),
        "evidence": [
            evidence(e_meta, "OBSERVED", info_artifact, "Public title, channel, and performance metadata."),
            evidence(e_asr, "CALCULATED", transcript_artifact, "Local ASR transcript and word timestamps."),
            evidence(e_takes, "CALCULATED", take_artifact, "Local scene-boundary candidates and visual measurements."),
        ],
    }


def published_at(info: dict[str, Any]) -> str | None:
    timestamp = info.get("timestamp")
    if timestamp is not None:
        return datetime.fromtimestamp(float(timestamp), tz=timezone.utc).isoformat(timespec="seconds")
    date = info.get("upload_date")
    if isinstance(date, str) and len(date) == 8:
        return datetime.strptime(date, "%Y%m%d").replace(tzinfo=timezone.utc).isoformat(timespec="seconds")
    return None


def public_performance(info: dict[str, Any], captured_at: str, metadata_evidence_id: str) -> dict[str, Any]:
    views = info.get("view_count")
    likes = info.get("like_count")
    comments = info.get("comment_count")
    published = published_at(info)
    age_hours: float | None = None
    if published:
        age_hours = max(0.0, (
            datetime.fromisoformat(captured_at) - datetime.fromisoformat(published)
        ).total_seconds() / 3600)
    snapshots = [{
        "captured_at": captured_at,
        "video_age_hours": round(age_hours, 3) if age_hours is not None else None,
        "views": int(views) if views is not None else None,
        "likes": int(likes) if likes is not None else None,
        "comments": int(comments) if comments is not None else None,
        "channel_subscribers": int(info["channel_follower_count"]) if info.get("channel_follower_count") is not None else None,
    }]
    derived: dict[str, Any] = {}
    if views is not None and age_hours and age_hours > 0:
        derived["views_per_day"] = claim(
            round(float(views) / (age_hours / 24), 4), [metadata_evidence_id], confidence=1.0,
        )
    if views and likes is not None:
        derived["likes_per_1000_views"] = claim(
            round(float(likes) * 1000 / float(views), 4), [metadata_evidence_id], confidence=1.0,
        )
    return {"snapshots": snapshots, "derived_metrics": derived, "private_metrics_claimed": False}


def risks(video_id: str) -> list[dict[str, Any]]:
    return [
        {
            "risk_id": f"R-{video_id}-RIGHTS", "category": "RIGHTS", "severity": "CRITICAL",
            "description": "Public availability and a fair-use disclaimer do not establish reusable commercial rights.",
            "mitigation": "Require recorded editorial/legal review or verified license before any production use.",
            "status": "BLOCKING",
        },
        {
            "risk_id": f"R-{video_id}-REUSED", "category": "REUSED_CONTENT", "severity": "HIGH",
            "description": "Source is analyzed for mechanisms only; direct reuse may trigger reused-content concerns.",
            "mitigation": "Create substantive original narrative and document provenance and editorial transformation.",
            "status": "OPEN",
        },
        {
            "risk_id": f"R-{video_id}-SEMANTIC", "category": "FACTUAL", "severity": "MEDIUM",
            "description": "Automatic semantic labels are unreviewed hypotheses, not human-confirmed meaning.",
            "mitigation": "Human reviewer must approve hooks, take functions, narrative roles, and packaging interpretation.",
            "status": "OPEN",
        },
    ]


def build_analysis(
    *, root: Path, video_id: str, source_hash: str, source_path: Path, info_path: Path,
    thumbnail_path: Path, info: dict[str, Any], probe: dict[str, Any], transcript: dict[str, Any],
    transcript_path: Path, take_artifact_path: Path, boundaries_ms: list[int],
    frame_paths: dict[str, list[Path]], ocr_by_take: dict[str, dict[str, Any]],
    visual_by_take: dict[str, dict[str, Any]], thumbnail_ocr: dict[str, Any],
    thumbnail_visual: dict[str, Any], analysis_id: str, captured_at: str,
    tools: dict[str, str],
) -> dict[str, Any]:
    source_artifact = relpath(source_path, root)
    info_artifact = relpath(info_path, root)
    thumb_artifact = relpath(thumbnail_path, root)
    transcript_artifact = relpath(transcript_path, root)
    take_artifact = relpath(take_artifact_path, root)
    duration_ms = boundaries_ms[-1]
    title = str(info.get("title") or "")
    takes = build_takes(
        root=root, video_id=video_id, source_artifact=source_artifact,
        transcript_artifact=transcript_artifact, transcript=transcript,
        boundaries_ms=boundaries_ms, frame_paths=frame_paths, ocr_by_take=ocr_by_take,
        visual_by_take=visual_by_take,
    )
    content = build_content_analysis(
        video_id=video_id, title=title, info_artifact=info_artifact,
        transcript_artifact=transcript_artifact, take_artifact=take_artifact,
        transcript=transcript, takes=takes, duration_ms=duration_ms,
    )
    metadata_evidence_id = f"E-{video_id}-CONTENT-META"
    return {
        "schema_version": "1.0.0",
        "analysis_id": analysis_id,
        "source": {
            "platform": "YouTube",
            "video_id": video_id,
            "channel_id": info.get("channel_id"),
            "channel_name": info.get("channel"),
            "url": info.get("webpage_url") or info.get("original_url"),
            "title": title,
            "description": info.get("description"),
            "thumbnail_uri": thumb_artifact,
            "published_at": published_at(info),
            "duration_ms": duration_ms,
            "language": transcript.get("language") or info.get("language"),
            "content_hash": source_hash,
        },
        "collection": {
            "captured_at": captured_at,
            "methods": [
                "ffprobe stream inspection", "faster-whisper CPU int8 ASR with word timestamps",
                "ffmpeg scene-score candidates", "OpenCV start/mid/end keyframes and measurements",
                "RapidOCR local OCR", "deterministic rule-based semantic assembly",
            ],
            "input_artifact": source_artifact,
            "notes": "Phase 2 challenger; automatic hypotheses remain NOT_REVIEWED and assets remain production-blocked.",
        },
        "technical": technical_from_probe(probe),
        "packaging": build_packaging(
            video_id=video_id, info=info, info_artifact=info_artifact,
            thumbnail_artifact=thumb_artifact, thumbnail_ocr=thumbnail_ocr,
            thumbnail_visual=thumbnail_visual, transcript=transcript, duration_ms=duration_ms,
        ),
        "hooks": build_hooks(
            video_id=video_id, source_artifact=source_artifact, title=title,
            transcript=transcript, takes=takes,
        ),
        "transcript": {
            "raw_artifact": transcript_artifact,
            "reviewed_artifact": None,
            "language": transcript.get("language"),
            "segments": transcript["segments"],
            "confidence": round(sum(row["confidence"] for row in transcript["segments"]) / max(1, len(transcript["segments"])), 4),
            "uncertain_ranges": [
                {"start_ms": row["start_ms"], "end_ms": row["end_ms"], "reason": "ASR confidence below 0.70"}
                for row in transcript["segments"] if row["confidence"] < 0.7
            ],
        },
        "takes": takes,
        "narrative_segments": build_narrative(
            video_id=video_id, transcript_artifact=transcript_artifact,
            transcript=transcript, takes=takes, duration_ms=duration_ms, title=title,
        ),
        "content_analysis": content,
        "public_performance": public_performance(info, captured_at, metadata_evidence_id),
        "rights": {
            "status": "EDITORIAL_REVIEW_REQUIRED",
            "license": info.get("license"),
            "rights_holder": None,
            "commercial_use": None,
            "production_eligible": False,
            "attribution_required": None,
            "attribution_text": None,
            "verified_at": captured_at,
            "evidence_artifacts": [info_artifact],
            "restrictions": [
                "Analysis only; public availability is not a reusable license.",
                "Editorial/legal review is mandatory before any clip enters production.",
            ],
        },
        "risks": risks(video_id),
        "quality": {
            "schema_valid": False,
            "evidence_resolvable": False,
            "manual_review_status": "NOT_REVIEWED",
            "issues": [
                "Scene boundaries, OCR, transcript, take functions, narrative roles, and packaging meaning are automatic hypotheses.",
                "Fade detection is not separately classified; scene-score candidates can miss gradual transitions.",
                "No person/object recognition is performed, preventing unsupported visual identities.",
            ],
            "tool_versions": tools,
        },
    }
