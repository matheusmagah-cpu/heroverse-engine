"""Replaceable local adapters for the Phase 2 miner."""

from __future__ import annotations

import importlib.metadata
import json
import math
import os
import re
import shutil
import subprocess
import sys
import unicodedata
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np
from faster_whisper import WhisperModel
from PIL import Image, ImageStat
from rapidocr import RapidOCR


FFMPEG = Path(shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe")
FFPROBE = Path(shutil.which("ffprobe") or r"C:\ffmpeg\bin\ffprobe.exe")


class AdapterError(RuntimeError):
    """A local provider failed and no silent fallback is allowed."""


def package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "MISSING"


def run_command(command: list[str], *, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise AdapterError(f"command timeout after {timeout}s: {command[0]}") from exc
    if result.returncode:
        message = result.stderr.strip() or result.stdout.strip() or f"exit={result.returncode}"
        raise AdapterError(f"command failed: {command[0]}: {message[-2000:]}")
    return result


class MediaProbeAdapter:
    provider = "ffprobe"

    def __init__(self, executable: Path = FFPROBE):
        if not executable.is_file():
            raise AdapterError(f"ffprobe missing: {executable}")
        self.executable = executable

    def inspect(self, video: Path) -> dict[str, Any]:
        if not video.is_file():
            raise FileNotFoundError(video)
        result = run_command([
            str(self.executable), "-v", "error", "-show_format", "-show_streams", "-of", "json", str(video)
        ])
        payload = json.loads(result.stdout)
        if not payload.get("format", {}).get("duration"):
            raise AdapterError(f"ffprobe did not return duration for {video}")
        return payload


class SceneDetectionAdapter:
    provider = "ffmpeg-scene-score"

    def __init__(self, executable: Path = FFMPEG):
        if not executable.is_file():
            raise AdapterError(f"ffmpeg missing: {executable}")
        self.executable = executable

    def detect(self, video: Path, duration_seconds: float, threshold: float) -> list[float]:
        if not 0 < threshold < 1:
            raise ValueError("scene threshold must be between 0 and 1")
        result = run_command([
            str(self.executable), "-hide_banner", "-i", str(video),
            "-vf", f"select='gt(scene,{threshold})',showinfo", "-an", "-f", "null", os.devnull,
        ])
        values = [float(value) for value in re.findall(r"pts_time:([0-9.]+)", result.stderr)]
        boundaries = sorted({round(value, 6) for value in values if 0 < value < duration_seconds})
        return [0.0, *boundaries, round(duration_seconds, 6)]


class FrameExtractionAdapter:
    provider = "opencv-videoio"

    def extract(self, video: Path, requests: Iterable[tuple[float, Path]], *, width: int = 640) -> list[Path]:
        ordered = sorted(requests, key=lambda item: item[0])
        capture = cv2.VideoCapture(str(video))
        if not capture.isOpened():
            raise AdapterError(f"OpenCV could not open media: {video}")
        outputs: list[Path] = []

        def existing_is_valid(destination: Path) -> bool:
            if not destination.is_file():
                return False
            encoded_existing = np.frombuffer(destination.read_bytes(), dtype=np.uint8)
            decoded_existing = cv2.imdecode(encoded_existing, cv2.IMREAD_COLOR)
            return decoded_existing is not None and bool(decoded_existing.size)

        def write_frame(frame: np.ndarray, destination: Path) -> None:
            if width and frame.shape[1] != width:
                height = max(2, round(frame.shape[0] * width / frame.shape[1]))
                frame = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
            destination.parent.mkdir(parents=True, exist_ok=True)
            encoded, buffer = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
            if not encoded:
                raise AdapterError(f"could not encode frame: {destination}")
            destination.write_bytes(buffer.tobytes())

        try:
            missing = [(seconds, destination) for seconds, destination in ordered if not existing_is_valid(destination)]
            outputs.extend(destination for _, destination in ordered if existing_is_valid(destination))
            if len(missing) > 10:
                fps = float(capture.get(cv2.CAP_PROP_FPS))
                if fps <= 0:
                    raise AdapterError(f"OpenCV did not expose FPS for sequential decode: {video}")
                current_index = -1
                frame: np.ndarray | None = None
                for seconds, destination in missing:
                    target_index = max(0, round(seconds * fps))
                    while current_index < target_index:
                        ok, frame = capture.read()
                        current_index += 1
                        if not ok or frame is None:
                            raise AdapterError(f"sequential frame extraction failed at {seconds:.6f}s for {video.name}")
                    write_frame(frame, destination)
                    outputs.append(destination)
            else:
                for seconds, destination in missing:
                    capture.set(cv2.CAP_PROP_POS_MSEC, max(0.0, seconds) * 1000)
                    ok, frame = capture.read()
                    if not ok or frame is None:
                        raise AdapterError(f"frame extraction failed at {seconds:.6f}s for {video.name}")
                    write_frame(frame, destination)
                    outputs.append(destination)
        finally:
            capture.release()
        return outputs


class TranscriptAdapter:
    provider = "faster-whisper"

    def __init__(self, model_name: str, *, language: str = "en", device: str = "cpu", compute_type: str = "int8"):
        self.model_name = model_name
        self.language = language
        self.device = device
        self.compute_type = compute_type
        self._model: WhisperModel | None = None

    @property
    def model(self) -> WhisperModel:
        if self._model is None:
            self._model = WhisperModel(self.model_name, device=self.device, compute_type=self.compute_type)
        return self._model

    def transcribe(self, video: Path, video_id: str, *, beam_size: int, vad_filter: bool) -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        segments, info = self.model.transcribe(
            str(video), language=self.language, beam_size=beam_size,
            vad_filter=vad_filter, word_timestamps=True,
        )
        for segment in segments:
            words = [word for word in (segment.words or []) if word.word and word.word.strip()]
            text = segment.text.strip()
            if not text:
                continue
            confidence = sum(float(word.probability) for word in words) / len(words) if words else 0.0
            rows.append({
                "start_ms": round(segment.start * 1000),
                "end_ms": round(segment.end * 1000),
                "speaker": None,
                "raw_text": text,
                "reviewed_text": None,
                "confidence": round(max(0.0, min(1.0, confidence)), 4),
                "words": [{
                    "word": word.word.strip(),
                    "start_ms": round(word.start * 1000) if word.start is not None else round(segment.start * 1000),
                    "end_ms": round(word.end * 1000) if word.end is not None else round(segment.end * 1000),
                    "confidence": round(float(word.probability), 4),
                } for word in words],
            })
        word_count = sum(len(row["words"]) for row in rows)
        speech_ms = sum(max(0, row["end_ms"] - row["start_ms"]) for row in rows)
        return {
            "provider": self.provider,
            "provider_version": package_version("faster-whisper"),
            "model": self.model_name,
            "language": info.language,
            "language_probability": round(float(info.language_probability), 4),
            "duration_seconds": round(float(info.duration), 3),
            "review_status": "NOT_REVIEWED",
            "video_id": video_id,
            "segments": rows,
            "measurements": {
                "word_count": word_count,
                "speech_duration_ms": speech_ms,
                "words_per_minute_of_speech": round(word_count / (speech_ms / 60000), 3) if speech_ms else None,
            },
        }


class OcrAdapter:
    provider = "rapidocr"

    def __init__(self, *, minimum_confidence: float = 0.70):
        if not 0 <= minimum_confidence <= 1:
            raise ValueError("OCR confidence must be between 0 and 1")
        self.minimum_confidence = minimum_confidence
        self._engine: RapidOCR | None = None

    @property
    def engine(self) -> RapidOCR:
        if self._engine is None:
            self._engine = RapidOCR()
        return self._engine

    def scan(self, image: Path) -> dict[str, Any]:
        result = self.engine(str(image))
        with Image.open(image) as source:
            width, height = source.size
        lines = []
        rejected_lines = []
        boxes = result.boxes if result.boxes is not None else []
        texts = result.txts if result.txts is not None else []
        scores = result.scores if result.scores is not None else []
        for box, text, score in zip(boxes, texts, scores):
            confidence = float(score)
            raw_text = str(text).strip()
            normalized_text, rejection_reason = normalize_ocr_text(raw_text)
            if confidence < self.minimum_confidence:
                rejected_lines.append({
                    "raw_text": raw_text,
                    "confidence": round(confidence, 5),
                    "reason": "below_minimum_confidence",
                })
                continue
            if rejection_reason:
                rejected_lines.append({
                    "raw_text": raw_text,
                    "confidence": round(confidence, 5),
                    "reason": rejection_reason,
                })
                continue
            points = [[round(float(x), 2), round(float(y), 2)] for x, y in box]
            xs = [point[0] for point in points]
            ys = [point[1] for point in points]
            lines.append({
                "raw_text": raw_text,
                "text": normalized_text,
                "confidence": round(confidence, 5),
                "box": points,
                "relative_position": {
                    "x": round(min(xs) / width, 5), "y": round(min(ys) / height, 5),
                    "width": round((max(xs) - min(xs)) / width, 5),
                    "height": round((max(ys) - min(ys)) / height, 5),
                },
            })
        return {
            "provider": self.provider,
            "provider_version": package_version("rapidocr"),
            "minimum_confidence": self.minimum_confidence,
            "image": str(image),
            "lines": lines,
            "rejected_lines": rejected_lines,
            "text": " ".join(line["text"] for line in lines),
            "mean_confidence": round(sum(line["confidence"] for line in lines) / len(lines), 5) if lines else None,
        }


def normalize_ocr_text(value: str) -> tuple[str, str | None]:
    """Return a conservative literal OCR value plus an auditable rejection reason."""
    normalized = unicodedata.normalize("NFKC", value or "")
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if not normalized:
        return "", "empty"
    if any(ord(character) > 127 for character in normalized):
        return "", "non_ascii"
    latin_count = len(re.findall(r"[A-Za-z]", normalized))
    if latin_count < 3:
        return "", "fewer_than_three_latin_letters"
    contains_digit = bool(re.search(r"\d", normalized))
    url_like = bool(re.search(r"(?:www\.|https?://|\.[A-Za-z]{2,})(?:\s|$)", normalized, re.IGNORECASE))
    if contains_digit and not url_like:
        return "", "mixed_alphanumeric_not_url"
    if not re.fullmatch(r"[A-Za-z0-9&'.,:;!?/()@#%+_\- ]+", normalized):
        return "", "unsupported_symbols"
    return normalized, None


def visual_measurements(image: Path) -> dict[str, Any]:
    with Image.open(image) as source:
        rgb = source.convert("RGB")
        reduced = rgb.resize((64, 64))
        stat = ImageStat.Stat(reduced)
        gray = reduced.convert("L")
        gray_stat = ImageStat.Stat(gray)
        array = np.asarray(gray, dtype=np.float32)
        edges = cv2.Canny(array.astype(np.uint8), 80, 160)
        mean_rgb = tuple(round(channel, 2) for channel in stat.mean)
        luminance = round(float(gray_stat.mean[0]), 2)
        contrast = round(float(gray_stat.stddev[0]), 2)
        edge_density = round(float(np.count_nonzero(edges)) / edges.size, 5)
        if luminance < 55:
            light_label = "very dark"
        elif luminance < 105:
            light_label = "dark"
        elif luminance < 175:
            light_label = "mid-tone"
        else:
            light_label = "bright"
        dominant_channel = ("red", "green", "blue")[int(np.argmax(mean_rgb))]
        return {
            "width": rgb.width,
            "height": rgb.height,
            "mean_rgb": list(mean_rgb),
            "luminance": luminance,
            "contrast": contrast,
            "edge_density": edge_density,
            "light_label": light_label,
            "dominant_channel": dominant_channel,
        }


def tool_versions() -> dict[str, str]:
    return {
        "python": sys.version.split()[0],
        "ffmpeg": run_command([str(FFMPEG), "-version"]).stdout.splitlines()[0],
        "ffprobe": run_command([str(FFPROBE), "-version"]).stdout.splitlines()[0],
        "faster-whisper": package_version("faster-whisper"),
        "rapidocr": package_version("rapidocr"),
        "onnxruntime": package_version("onnxruntime"),
        "opencv-python": package_version("opencv-python"),
        "Pillow": package_version("Pillow"),
        "jsonschema": package_version("jsonschema"),
    }


def take_frame_times(start: float, end: float) -> tuple[float, float, float]:
    duration = max(0.000001, end - start)
    inset = min(0.04, duration * 0.2)
    first = start + inset
    middle = start + duration / 2
    last = max(first, end - inset)
    return first, middle, last
