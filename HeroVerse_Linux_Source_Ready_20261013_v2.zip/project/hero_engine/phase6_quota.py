from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[1]
OBSERVATION = Path("output/integrations/youtube/heroverse/quota-observation.json")
ACCOUNTING = Path("output/operations/zero-cost/phase6-observation-quota-accounting.json")
LEDGER = Path("output/operations/zero-cost/phase6-quota-ledger.sqlite3")
DEBIT_RECEIPTS = Path("output/operations/zero-cost/phase6-quota-debits")
DEBIT_RECEIPT_SCHEMA = "phase6_quota_debit_receipt.schema.json"
GENERAL_LIMIT = 10_000
UPLOAD_LIMIT = 100
UNTRACKED_GENERAL_RESERVE = 2_000
MAX_QUOTA_OBSERVATION_AGE = timedelta(hours=6)
PACIFIC = ZoneInfo("America/Los_Angeles")
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"

LEDGER_SCHEMA = """
CREATE TABLE IF NOT EXISTS general_quota_debits (
    debit_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    operation_id TEXT NOT NULL,
    job_id TEXT NOT NULL,
    attempt_count INTEGER NOT NULL CHECK(attempt_count >= 1),
    channel_id TEXT NOT NULL,
    units INTEGER NOT NULL CHECK(units > 0),
    state TEXT NOT NULL CHECK(state IN ('RESERVED','CONSUMED')),
    quota_day_start TEXT NOT NULL,
    quota_day_end TEXT NOT NULL,
    requested_effective_before INTEGER NOT NULL DEFAULT 0 CHECK(requested_effective_before >= 0),
    preventive_floor INTEGER NOT NULL DEFAULT 12 CHECK(preventive_floor >= 0),
    effective_before INTEGER NOT NULL CHECK(effective_before >= 0),
    effective_after INTEGER NOT NULL CHECK(effective_after >= 0),
    reserved_at TEXT NOT NULL,
    consumed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_general_quota_day
ON general_quota_debits(quota_day_start, quota_day_end, reserved_at);
CREATE TABLE IF NOT EXISTS upload_quota_debits (
    debit_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    effect_id TEXT NOT NULL,
    attempt_count INTEGER NOT NULL CHECK(attempt_count >= 1),
    channel_id TEXT NOT NULL,
    release_id TEXT NOT NULL,
    units INTEGER NOT NULL CHECK(units = 1),
    state TEXT NOT NULL CHECK(state IN ('RESERVED','CONSUMED')),
    quota_day_start TEXT NOT NULL,
    quota_day_end TEXT NOT NULL,
    effective_before INTEGER NOT NULL CHECK(effective_before >= 0),
    effective_after INTEGER NOT NULL CHECK(effective_after >= 0),
    observation_sha256 TEXT NOT NULL,
    observation_observed_at TEXT NOT NULL,
    reserved_at TEXT NOT NULL,
    consumed_at TEXT,
    confirmation_id TEXT,
    confirmation_sha256 TEXT
);
CREATE INDEX IF NOT EXISTS idx_upload_quota_day
ON upload_quota_debits(quota_day_start, quota_day_end, reserved_at);
CREATE TABLE IF NOT EXISTS composed_quota_reservations (
    reservation_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    effect_id TEXT NOT NULL,
    attempt_count INTEGER NOT NULL CHECK(attempt_count >= 1),
    channel_id TEXT NOT NULL,
    release_id TEXT NOT NULL,
    general_units INTEGER NOT NULL CHECK(general_units > 0),
    general_preventive_floor INTEGER NOT NULL CHECK(general_preventive_floor >= 0),
    upload_preventive_floor INTEGER NOT NULL CHECK(upload_preventive_floor >= 0),
    general_debit_id TEXT NOT NULL UNIQUE,
    upload_debit_id TEXT NOT NULL UNIQUE,
    state TEXT NOT NULL CHECK(state IN ('RESERVED','CONSUMED')),
    quota_day_start TEXT NOT NULL,
    quota_day_end TEXT NOT NULL,
    observation_archive_path TEXT NOT NULL,
    observation_sha256 TEXT NOT NULL,
    observation_id TEXT NOT NULL,
    observation_observed_at TEXT NOT NULL,
    reserved_at TEXT NOT NULL,
    effect_started_at TEXT,
    consumed_at TEXT,
    confirmation_id TEXT,
    confirmation_sha256 TEXT
);
CREATE INDEX IF NOT EXISTS idx_composed_quota_day
ON composed_quota_reservations(quota_day_start, quota_day_end, reserved_at);
"""


class QuotaReservationBlocked(PermissionError):
    pass


_LEDGER_THREAD_LOCKS_GUARD = threading.Lock()
_LEDGER_THREAD_LOCKS: dict[str, threading.Lock] = {}
_LEDGER_THREAD_OWNERS = threading.local()


class _LedgerLock:
    """Bounded thread/process mutex for ledger setup and transactions.

    SQLite's busy timeout does not reliably serialize concurrent
    ``PRAGMA journal_mode``/DDL bootstrap on Windows. Every project-local
    quota operation therefore owns this crash-released OS lock for the whole
    connection lifetime. SQLite remains the durable source of truth; this
    lock only prevents startup/migration races from escaping as transient
    ``database is locked`` failures.
    """

    def __init__(self, path: Path, *, timeout_seconds: float = 30.0) -> None:
        self.path = path.resolve()
        self.timeout_seconds = timeout_seconds
        self.handle = None
        self.key = os.path.normcase(str(self.path))
        with _LEDGER_THREAD_LOCKS_GUARD:
            self.thread_lock = _LEDGER_THREAD_LOCKS.setdefault(self.key, threading.Lock())

    def __enter__(self) -> "_LedgerLock":
        held = getattr(_LEDGER_THREAD_OWNERS, "paths", set())
        if self.key in held:
            raise RuntimeError("quota ledger lock is intentionally non-reentrant")
        deadline = time.monotonic() + self.timeout_seconds
        if not self.thread_lock.acquire(timeout=max(0.0, deadline - time.monotonic())):
            raise sqlite3.OperationalError("quota ledger thread lock timed out")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.handle = self.path.open("a+b")
            self.handle.seek(0, os.SEEK_END)
            if self.handle.tell() == 0:
                self.handle.write(b"0")
                self.handle.flush()
                os.fsync(self.handle.fileno())
            while True:
                try:
                    self.handle.seek(0)
                    if os.name == "nt":
                        import msvcrt

                        msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(
                            self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB
                        )
                    owners = set(held)
                    owners.add(self.key)
                    _LEDGER_THREAD_OWNERS.paths = owners
                    return self
                except (OSError, BlockingIOError):
                    if time.monotonic() >= deadline:
                        raise sqlite3.OperationalError(
                            "quota ledger interprocess lock timed out"
                        )
                    time.sleep(0.025)
        except BaseException:
            try:
                if self.handle is not None:
                    self.handle.close()
            finally:
                self.handle = None
                self.thread_lock.release()
            raise

    def __exit__(self, exc_type, exc, tb) -> None:
        cleanup_error: BaseException | None = None
        try:
            if self.handle is not None:
                try:
                    self.handle.seek(0)
                    if os.name == "nt":
                        import msvcrt

                        msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
                except BaseException as error:
                    cleanup_error = error
                finally:
                    try:
                        self.handle.close()
                    except BaseException as error:
                        cleanup_error = cleanup_error or error
                    finally:
                        self.handle = None
        finally:
            owners = getattr(_LEDGER_THREAD_OWNERS, "paths", set())
            owners.discard(self.key)
            _LEDGER_THREAD_OWNERS.paths = owners
            self.thread_lock.release()
        if cleanup_error is not None and exc_type is None:
            raise cleanup_error


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _quota_day(now: datetime) -> tuple[datetime, datetime]:
    local = now.astimezone(PACIFIC)
    start_local = local.replace(hour=0, minute=0, second=0, microsecond=0)
    return (
        start_local.astimezone(timezone.utc),
        (start_local + timedelta(days=1)).astimezone(timezone.utc),
    )


def _write_atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


@contextmanager
def _ledger_connection(root: Path):
    path = root.resolve() / LEDGER
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix(path.suffix + ".lock")
    with _LedgerLock(lock_path):
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(path, timeout=30, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA busy_timeout=30000")
            # WAL is persistent for the database and is set only while the
            # interprocess ledger lock excludes active quota transactions.
            connection.execute("PRAGMA journal_mode=WAL")
            connection.executescript(LEDGER_SCHEMA)
            columns = {
                str(row["name"])
                for row in connection.execute(
                    "PRAGMA table_info(general_quota_debits)"
                ).fetchall()
            }
            if "requested_effective_before" not in columns:
                connection.execute(
                    "ALTER TABLE general_quota_debits ADD COLUMN requested_effective_before INTEGER NOT NULL DEFAULT 0"
                )
            if "preventive_floor" not in columns:
                connection.execute(
                    "ALTER TABLE general_quota_debits ADD COLUMN preventive_floor INTEGER NOT NULL DEFAULT 12"
                )
            composed_columns = {
                str(row["name"])
                for row in connection.execute(
                    "PRAGMA table_info(composed_quota_reservations)"
                ).fetchall()
            }
            if "effect_started_at" not in composed_columns:
                connection.execute(
                    "ALTER TABLE composed_quota_reservations ADD COLUMN effect_started_at TEXT"
                )
            yield connection
        finally:
            if connection is not None:
                connection.close()


def _debit(row: sqlite3.Row) -> dict[str, Any]:
    return dict(row)


def reserve_general_quota(
    root: Path = ROOT,
    *,
    idempotency_key: str,
    operation_id: str,
    job_id: str,
    attempt_count: int,
    effective_general_before: int,
    units: int,
    preventive_floor: int = 12,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Atomically reserve free Data API units for one exact external attempt.

    The same key is a no-op replay.  A new retry attempt receives a new key and
    therefore accounts conservatively for calls that may have happened before
    a crash.  Admission is serialized against the largest committed basis in
    the current Pacific quota day, preventing concurrent preflights from both
    spending the same remaining margin.
    """

    if not idempotency_key or not operation_id or not job_id:
        raise ValueError("quota debit identity is incomplete")
    if attempt_count < 1 or units < 1 or preventive_floor < 0:
        raise ValueError("quota debit attempt, units and floor must be valid")
    if (
        isinstance(effective_general_before, bool)
        or not isinstance(effective_general_before, int)
        or effective_general_before < 0
    ):
        raise ValueError("effective quota basis must be a non-negative integer")
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    start, end = _quota_day(current)
    start_stamp, end_stamp, timestamp = _stamp(start), _stamp(end), _stamp(current)
    debit_id = "quota-debit-" + hashlib.sha256(idempotency_key.encode("utf-8")).hexdigest()[:24]
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT * FROM general_quota_debits WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if existing is not None:
            stable = (
                existing["debit_id"] == debit_id
                and existing["operation_id"] == operation_id
                and existing["job_id"] == job_id
                and existing["attempt_count"] == attempt_count
                and existing["channel_id"] == CHANNEL_ID
                and existing["units"] == units
                and existing["requested_effective_before"] == effective_general_before
                and existing["preventive_floor"] == preventive_floor
                and existing["quota_day_start"] == start_stamp
                and existing["quota_day_end"] == end_stamp
            )
            if not stable:
                connection.rollback()
                raise QuotaReservationBlocked("quota idempotency key was reused with divergent identity")
            row = connection.execute(
                "SELECT MAX(effective_after) AS maximum FROM general_quota_debits "
                "WHERE quota_day_start=? AND quota_day_end=?",
                (start_stamp, end_stamp),
            ).fetchone()
            current_basis = int(row["maximum"] or existing["effective_after"])
            if current_basis > GENERAL_LIMIT or GENERAL_LIMIT - current_basis < preventive_floor:
                connection.rollback()
                raise QuotaReservationBlocked(
                    "current free quota no longer satisfies the replayed preventive floor"
                )
            connection.commit()
            return _debit(existing)
        row = connection.execute(
            "SELECT MAX(effective_after) AS maximum FROM general_quota_debits "
            "WHERE quota_day_start=? AND quota_day_end=?",
            (start_stamp, end_stamp),
        ).fetchone()
        ledger_basis = int(row["maximum"] or 0)
        basis = max(effective_general_before, ledger_basis)
        after = basis + units
        if after > GENERAL_LIMIT or GENERAL_LIMIT - after < preventive_floor:
            connection.rollback()
            raise QuotaReservationBlocked("free quota preventive floor blocks the atomic reservation")
        connection.execute(
            """INSERT INTO general_quota_debits
               (debit_id,idempotency_key,operation_id,job_id,attempt_count,channel_id,
                units,state,quota_day_start,quota_day_end,effective_before,effective_after,
                requested_effective_before,preventive_floor,reserved_at,consumed_at)
               VALUES (?,?,?,?,?,?,?,'RESERVED',?,?,?,?,?,?,?,NULL)""",
            (
                debit_id, idempotency_key, operation_id, job_id, attempt_count,
                CHANNEL_ID, units, start_stamp, end_stamp, basis, after,
                effective_general_before, preventive_floor, timestamp,
            ),
        )
        created = connection.execute(
            "SELECT * FROM general_quota_debits WHERE debit_id=?", (debit_id,)
        ).fetchone()
        connection.commit()
        return _debit(created)


def consume_general_quota(
    root: Path = ROOT,
    *,
    idempotency_key: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Commit one prior reservation; replay never changes units or timestamp."""

    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT * FROM general_quota_debits WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if row is None:
            connection.rollback()
            raise QuotaReservationBlocked("quota consumption has no prior reservation")
        if row["state"] == "RESERVED":
            connection.execute(
                "UPDATE general_quota_debits SET state='CONSUMED',consumed_at=? WHERE debit_id=?",
                (_stamp(current), row["debit_id"]),
            )
            row = connection.execute(
                "SELECT * FROM general_quota_debits WHERE debit_id=?", (row["debit_id"],)
            ).fetchone()
        connection.commit()
        return _debit(row)


def get_general_quota_debit(root: Path = ROOT, *, idempotency_key: str) -> dict[str, Any] | None:
    with _ledger_connection(root) as connection:
        row = connection.execute(
            "SELECT * FROM general_quota_debits WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        return _debit(row) if row is not None else None


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _required_identity(name: str, value: Any) -> str:
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value) > 256
        or any(ord(character) < 32 for character in value)
    ):
        raise ValueError(f"{name} must be a non-empty bounded identifier")
    return value


def _required_digest(name: str, value: Any) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")
    return value


def _aware_utc(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("quota time must be timezone-aware")
    return value.astimezone(timezone.utc)


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    """Create an immutable artifact without replacing an existing path."""

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if not path.is_file() or path.read_bytes() != payload:
            raise QuotaReservationBlocked(f"immutable quota artifact diverged: {path}")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if not path.is_file() or path.read_bytes() != payload:
                raise QuotaReservationBlocked(f"immutable quota artifact diverged: {path}")
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _load_live_quota_observation(
    root: Path,
    *,
    current: datetime,
) -> dict[str, Any]:
    observation_path = root / OBSERVATION
    if not observation_path.is_file():
        raise QuotaReservationBlocked("official quota observation is unavailable")
    try:
        raw = observation_path.read_bytes()
        observation = json.loads(raw.decode("utf-8-sig"))
        Draft202012Validator(
            _read(root / "schemas/youtube_quota_observation.schema.json"),
            format_checker=FormatChecker(),
        ).validate(observation)
        observed_at = _parse(str(observation["observed_at"]))
        usage = observation["observed_usage"]
    except Exception as exc:
        raise QuotaReservationBlocked("official quota observation is malformed") from exc
    start, end = _quota_day(current)
    if observation.get("status") != "PASS" or observation.get("billing_enabled") is not False:
        raise QuotaReservationBlocked("official quota status is unknown or billing is not closed")
    if not start <= observed_at < end:
        raise QuotaReservationBlocked("official quota observation belongs to another Pacific day")
    age = current - observed_at
    if age < timedelta(0) or age > MAX_QUOTA_OBSERVATION_AGE:
        raise QuotaReservationBlocked("official quota observation is stale or from the future")
    if any(
        isinstance(usage.get(resource), bool)
        or not isinstance(usage.get(resource), int)
        for resource in ("youtube-videos-insert-daily", "youtube-general-units-daily")
    ):
        raise QuotaReservationBlocked("official quota consumption is unknown")
    return {
        "value": observation,
        "raw": raw,
        "sha256": _sha256_bytes(raw),
        "observed_at": observed_at,
        "start": start,
        "end": end,
        "upload_base": int(usage["youtube-videos-insert-daily"]),
        "general_base": int(usage["youtube-general-units-daily"]),
    }


def _confirmed_upload_records(
    root: Path,
    start: datetime,
    end: datetime,
    *,
    after: datetime | None = None,
) -> list[dict[str, str]]:
    by_video: dict[str, dict[str, str]] = {}
    schema_path = root / "schemas/youtube_publication_receipt.schema.json"
    for path in (root / "output/production").glob("phase*/**/youtube-publication-receipt.json"):
        try:
            receipt = _read(path)
            if not schema_path.is_file():
                raise QuotaReservationBlocked("publication receipt schema is unavailable")
            Draft202012Validator(
                _read(schema_path), format_checker=FormatChecker()
            ).validate(receipt)
            if receipt.get("channel_id") != CHANNEL_ID:
                raise QuotaReservationBlocked("publication receipt channel identity diverged")
            tracked_status = receipt.get("status") in {
                "COMPLETE_PUBLIC",
                "PUBLIC_AWAITING_VERIFICATION",
                "STAGED_PRIVATE_AWAITING_PROCESSING",
                "PARTIAL_PRIVATE_VIDEO",
            }
            if not tracked_status:
                continue
            video_id = receipt.get("video_id")
            if not isinstance(video_id, str) or not video_id:
                raise QuotaReservationBlocked("confirmed publication receipt has no video identity")
            journal = receipt.get("effect_journal")
            if isinstance(journal, list):
                confirmed_effects = [
                    entry
                    for entry in journal
                    if entry.get("effect_id") == "VIDEO_PRIVATE_UPLOAD"
                    and entry.get("api_method") == "videos.insert"
                    and entry.get("checkpoint") == "AFTER"
                    and entry.get("outcome") in {"CONFIRMED", "RECOVERED"}
                    and entry.get("remote_resource_id") == video_id
                ]
                if len(confirmed_effects) != 1:
                    raise QuotaReservationBlocked(
                        "publication receipt has no unique confirmed upload effect"
                    )
                effect_at = _parse(str(confirmed_effects[0]["checkpointed_at"]))
            else:
                # Historical phase-5 receipts predate the effect journal.  They
                # remain countable only with their exact PASS upload step.
                upload_steps = [
                    entry
                    for entry in (receipt.get("steps") or [])
                    if entry.get("step") == "VIDEO_PRIVATE_UPLOAD"
                    and entry.get("status") == "PASS"
                    and entry.get("evidence") == video_id
                ]
                if len(upload_steps) != 1:
                    raise QuotaReservationBlocked(
                        "legacy publication receipt has no unique upload proof"
                    )
                effect_at = _parse(str(receipt["created_at"]))
            if (
                start <= effect_at < end
                and (after is None or effect_at >= after)
            ):
                by_video[video_id] = {
                    "video_id": video_id,
                    "release_id": str(receipt.get("release_id") or ""),
                    "effect_at": _stamp(effect_at),
                }
        except QuotaReservationBlocked:
            raise
        except Exception as exc:
            raise QuotaReservationBlocked(
                f"publication receipt is malformed: {path.as_posix()}"
            ) from exc
    return list(by_video.values())


def _quota_basis_in_transaction(
    connection: sqlite3.Connection,
    root: Path,
    observation: dict[str, Any],
) -> dict[str, int]:
    start_stamp = _stamp(observation["start"])
    end_stamp = _stamp(observation["end"])
    cutoff_stamp = _stamp(observation["observed_at"])
    general = connection.execute(
        """SELECT COALESCE(SUM(units),0) AS units
           FROM general_quota_debits
           WHERE quota_day_start=? AND quota_day_end=?
             AND (state='RESERVED' OR consumed_at IS NULL OR consumed_at>=?)""",
        (start_stamp, end_stamp, cutoff_stamp),
    ).fetchone()
    uploads = connection.execute(
        """SELECT COALESCE(SUM(units),0) AS units
           FROM upload_quota_debits
           WHERE quota_day_start=? AND quota_day_end=?
             AND (state='RESERVED' OR consumed_at IS NULL OR consumed_at>=?)""",
        (start_stamp, end_stamp, cutoff_stamp),
    ).fetchone()
    ledgered_releases = {
        str(row["release_id"])
        for row in connection.execute(
            "SELECT release_id FROM upload_quota_debits WHERE quota_day_start=? AND quota_day_end=?",
            (start_stamp, end_stamp),
        ).fetchall()
    }
    unmatched_receipts = sum(
        1
        for item in _confirmed_upload_records(
            root, observation["start"], observation["end"], after=observation["observed_at"]
        )
        if not item["release_id"] or item["release_id"] not in ledgered_releases
    )
    return {
        "general": observation["general_base"]
        + UNTRACKED_GENERAL_RESERVE
        + int(general["units"]),
        "upload": observation["upload_base"] + int(uploads["units"]) + unmatched_receipts,
    }


def _composed_ids(idempotency_key: str) -> tuple[str, str, str]:
    reservation_id = "phase6-quota-reservation-" + hashlib.sha256(
        idempotency_key.encode("utf-8")
    ).hexdigest()[:24]
    general_key = f"{idempotency_key}:youtube-general-units-daily"
    upload_key = f"{idempotency_key}:youtube-videos-insert-daily"
    return reservation_id, general_key, upload_key


def _load_composed_rows(
    connection: sqlite3.Connection,
    *,
    reservation_id: str,
) -> tuple[sqlite3.Row, sqlite3.Row, sqlite3.Row]:
    reservation = connection.execute(
        "SELECT * FROM composed_quota_reservations WHERE reservation_id=?",
        (reservation_id,),
    ).fetchone()
    if reservation is None:
        raise QuotaReservationBlocked("composed quota reservation is missing")
    general = connection.execute(
        "SELECT * FROM general_quota_debits WHERE debit_id=?",
        (reservation["general_debit_id"],),
    ).fetchone()
    upload = connection.execute(
        "SELECT * FROM upload_quota_debits WHERE debit_id=?",
        (reservation["upload_debit_id"],),
    ).fetchone()
    if general is None or upload is None:
        raise QuotaReservationBlocked("composed quota reservation has an orphaned bucket debit")
    states = {reservation["state"], general["state"], upload["state"]}
    stable = (
        len(states) == 1
        and general["units"] == reservation["general_units"]
        and general["channel_id"] == reservation["channel_id"]
        and general["attempt_count"] == reservation["attempt_count"]
        and general["quota_day_start"] == reservation["quota_day_start"]
        and general["quota_day_end"] == reservation["quota_day_end"]
        and upload["units"] == 1
        and upload["channel_id"] == reservation["channel_id"]
        and upload["attempt_count"] == reservation["attempt_count"]
        and upload["effect_id"] == reservation["effect_id"]
        and upload["release_id"] == reservation["release_id"]
        and upload["quota_day_start"] == reservation["quota_day_start"]
        and upload["quota_day_end"] == reservation["quota_day_end"]
        and upload["observation_sha256"] == reservation["observation_sha256"]
        and upload["observation_observed_at"] == reservation["observation_observed_at"]
    )
    if not stable:
        raise QuotaReservationBlocked("composed quota ledger identity diverged")
    return reservation, general, upload


def _receipt_value(
    root: Path,
    reservation: sqlite3.Row,
    general: sqlite3.Row,
    upload: sqlite3.Row,
) -> dict[str, Any]:
    archive_path = root / str(reservation["observation_archive_path"])
    if not archive_path.is_file():
        raise QuotaReservationBlocked("pinned quota observation archive is missing")
    archive_raw = archive_path.read_bytes()
    if _sha256_bytes(archive_raw) != reservation["observation_sha256"]:
        raise QuotaReservationBlocked("pinned quota observation archive hash diverged")
    state = str(reservation["state"])
    confirmation = None
    if state == "CONSUMED":
        confirmation = {
            "confirmation_id": str(reservation["confirmation_id"]),
            "confirmation_sha256": str(reservation["confirmation_sha256"]),
        }
    value: dict[str, Any] = {
        "schema_version": "1.0.0",
        "receipt_id": "PENDING",
        "reservation_id": str(reservation["reservation_id"]),
        "idempotency_key": str(reservation["idempotency_key"]),
        "effect_id": str(reservation["effect_id"]),
        "attempt_count": int(reservation["attempt_count"]),
        "channel_id": str(reservation["channel_id"]),
        "release_id": str(reservation["release_id"]),
        "state": state,
        "quota_day_start": str(reservation["quota_day_start"]),
        "quota_day_end": str(reservation["quota_day_end"]),
        "source_observation": {
            "live_path": OBSERVATION.as_posix(),
            "archive_path": str(reservation["observation_archive_path"]),
            "sha256": str(reservation["observation_sha256"]),
            "observation_id": str(reservation["observation_id"]),
            "observed_at": str(reservation["observation_observed_at"]),
        },
        "buckets": {
            "youtube-videos-insert-daily": {
                "debit_id": str(upload["debit_id"]),
                "units": 1,
                "state": str(upload["state"]),
                "effective_before": int(upload["effective_before"]),
                "effective_after": int(upload["effective_after"]),
                "limit": UPLOAD_LIMIT,
                "preventive_floor": int(reservation["upload_preventive_floor"]),
            },
            "youtube-general-units-daily": {
                "debit_id": str(general["debit_id"]),
                "units": int(general["units"]),
                "state": str(general["state"]),
                "effective_before": int(general["effective_before"]),
                "effective_after": int(general["effective_after"]),
                "limit": GENERAL_LIMIT,
                "preventive_floor": int(reservation["general_preventive_floor"]),
                "conservative_untracked_reserve": UNTRACKED_GENERAL_RESERVE,
            },
        },
        "confirmation": confirmation,
        "billing_enabled": False,
        "technical_cost_brl": 0,
        "reserved_at": str(reservation["reserved_at"]),
        "effect_started_at": reservation["effect_started_at"],
        "consumed_at": reservation["consumed_at"],
        "content_sha256": "PENDING",
        "claim_boundary": [
            "RESERVED is never proof that the external upload happened.",
            "An ambiguous or orphaned reservation remains charged conservatively and cannot be released.",
            "Only a hash-bound external confirmation can transition both buckets to CONSUMED.",
        ],
    }
    material = {key: item for key, item in value.items() if key not in {"receipt_id", "content_sha256"}}
    digest = _sha256_bytes(_canonical_bytes(material))
    value["receipt_id"] = f"phase6-quota-debit-{state.lower()}-{digest[:24]}"
    value["content_sha256"] = digest
    Draft202012Validator(
        _read(root / "schemas" / DEBIT_RECEIPT_SCHEMA),
        format_checker=FormatChecker(),
    ).validate(value)
    return value


def _materialize_composed_receipt(
    root: Path,
    reservation: sqlite3.Row,
    general: sqlite3.Row,
    upload: sqlite3.Row,
) -> dict[str, Any]:
    value = _receipt_value(root, reservation, general, upload)
    relative = DEBIT_RECEIPTS / value["reservation_id"] / (
        f"{value['state'].lower()}-{value['content_sha256'][:24]}.json"
    )
    payload = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    _write_immutable_bytes(root / relative, payload)
    return {"path": relative.as_posix(), "sha256": _sha256_bytes(payload), "receipt": value}


def _load_composed_receipt_binding(
    root: Path,
    *,
    receipt_path: str | Path,
    receipt_sha256: str,
) -> dict[str, Any]:
    expected_sha = _required_digest("receipt_sha256", receipt_sha256)
    relative = Path(receipt_path)
    absolute = relative if relative.is_absolute() else root / relative
    absolute = absolute.resolve()
    receipts_root = (root / DEBIT_RECEIPTS).resolve()
    try:
        absolute.relative_to(receipts_root)
    except ValueError as exc:
        raise QuotaReservationBlocked("quota receipt path escapes its authoritative directory") from exc
    if not absolute.is_file():
        raise QuotaReservationBlocked("quota receipt is missing")
    payload = absolute.read_bytes()
    if _sha256_bytes(payload) != expected_sha:
        raise QuotaReservationBlocked("quota receipt file hash diverged")
    try:
        value = json.loads(payload.decode("utf-8-sig"))
        Draft202012Validator(
            _read(root / "schemas" / DEBIT_RECEIPT_SCHEMA),
            format_checker=FormatChecker(),
        ).validate(value)
    except Exception as exc:
        raise QuotaReservationBlocked("quota receipt is malformed") from exc
    material = {
        key: item for key, item in value.items() if key not in {"receipt_id", "content_sha256"}
    }
    digest = _sha256_bytes(_canonical_bytes(material))
    expected_id = f"phase6-quota-debit-{value['state'].lower()}-{digest[:24]}"
    expected_relative = DEBIT_RECEIPTS / value["reservation_id"] / (
        f"{value['state'].lower()}-{digest[:24]}.json"
    )
    if (
        digest != value["content_sha256"]
        or expected_id != value["receipt_id"]
        or absolute != (root / expected_relative).resolve()
    ):
        raise QuotaReservationBlocked("quota receipt content identity diverged")
    source = value["source_observation"]
    archive = (root / source["archive_path"]).resolve()
    try:
        archive.relative_to(receipts_root)
    except ValueError as exc:
        raise QuotaReservationBlocked("quota observation archive escapes its authoritative directory") from exc
    if not archive.is_file() or _sha256_bytes(archive.read_bytes()) != source["sha256"]:
        raise QuotaReservationBlocked("quota observation archive is missing or altered")
    return value


def validate_composed_quota_receipt_binding(
    root: Path = ROOT,
    *,
    receipt_path: str | Path,
    receipt_sha256: str,
) -> dict[str, Any]:
    """Validate immutable historical receipt bytes without applying a live-day gate."""

    return _load_composed_receipt_binding(
        root.resolve(), receipt_path=receipt_path, receipt_sha256=receipt_sha256
    )


def reserve_composed_quota(
    root: Path = ROOT,
    *,
    idempotency_key: str,
    effect_id: str,
    attempt_count: int,
    channel_id: str,
    release_id: str,
    general_units: int,
    now: datetime | None = None,
    general_preventive_floor: int = 12,
    upload_preventive_floor: int = 1,
) -> dict[str, Any]:
    """Reserve one upload slot and its general units in one SQLite transaction."""

    root = root.resolve()
    idempotency_key = _required_identity("idempotency_key", idempotency_key)
    effect_id = _required_identity("effect_id", effect_id)
    release_id = _required_identity("release_id", release_id)
    if channel_id != CHANNEL_ID:
        raise ValueError("channel_id is not the exact authorized HeroVerse channel")
    if (
        isinstance(attempt_count, bool)
        or not isinstance(attempt_count, int)
        or attempt_count < 1
        or isinstance(general_units, bool)
        or not isinstance(general_units, int)
        or general_units < 1
        or isinstance(general_preventive_floor, bool)
        or not isinstance(general_preventive_floor, int)
        or general_preventive_floor < 0
        or isinstance(upload_preventive_floor, bool)
        or not isinstance(upload_preventive_floor, int)
        or upload_preventive_floor < 0
    ):
        raise ValueError("quota units, floors and attempt must be non-negative integers")
    current = _aware_utc(now or datetime.now(timezone.utc))
    observation = _load_live_quota_observation(root, current=current)
    reservation_id, general_key, upload_key = _composed_ids(idempotency_key)
    archive_relative = DEBIT_RECEIPTS / reservation_id / (
        f"source-observation-{observation['sha256'][:24]}.json"
    )
    _write_immutable_bytes(root / archive_relative, observation["raw"])
    general_debit_id = "quota-debit-" + hashlib.sha256(general_key.encode("utf-8")).hexdigest()[:24]
    upload_debit_id = "upload-quota-debit-" + hashlib.sha256(upload_key.encode("utf-8")).hexdigest()[:24]
    start_stamp = _stamp(observation["start"])
    end_stamp = _stamp(observation["end"])
    reserved_at = _stamp(current)
    replay = False
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT * FROM composed_quota_reservations WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if existing is not None:
            stable = (
                existing["reservation_id"] == reservation_id
                and existing["effect_id"] == effect_id
                and existing["attempt_count"] == attempt_count
                and existing["channel_id"] == channel_id
                and existing["release_id"] == release_id
                and existing["general_units"] == general_units
                and existing["general_preventive_floor"] == general_preventive_floor
                and existing["upload_preventive_floor"] == upload_preventive_floor
                and existing["quota_day_start"] == start_stamp
                and existing["quota_day_end"] == end_stamp
            )
            if not stable:
                connection.rollback()
                raise QuotaReservationBlocked(
                    "composed quota idempotency key was reused with divergent identity or policy"
                )
            reservation, general, upload = _load_composed_rows(
                connection, reservation_id=reservation_id
            )
            connection.commit()
            replay = True
        else:
            orphan_general = connection.execute(
                "SELECT 1 FROM general_quota_debits WHERE idempotency_key=?", (general_key,)
            ).fetchone()
            orphan_upload = connection.execute(
                "SELECT 1 FROM upload_quota_debits WHERE idempotency_key=?", (upload_key,)
            ).fetchone()
            if orphan_general is not None or orphan_upload is not None:
                connection.rollback()
                raise QuotaReservationBlocked("orphaned composed bucket debit blocks reuse")
            basis = _quota_basis_in_transaction(connection, root, observation)
            general_after = basis["general"] + general_units
            upload_after = basis["upload"] + 1
            if (
                general_after > GENERAL_LIMIT
                or GENERAL_LIMIT - general_after < general_preventive_floor
                or upload_after > UPLOAD_LIMIT
                or UPLOAD_LIMIT - upload_after < upload_preventive_floor
            ):
                connection.rollback()
                raise QuotaReservationBlocked(
                    "free general or upload quota preventive floor blocks the atomic reservation"
                )
            connection.execute(
                """INSERT INTO general_quota_debits
                   (debit_id,idempotency_key,operation_id,job_id,attempt_count,channel_id,
                    units,state,quota_day_start,quota_day_end,effective_before,effective_after,
                    reserved_at,consumed_at)
                   VALUES (?,?,?,?,?,?,?,'RESERVED',?,?,?,?,?,NULL)""",
                (
                    general_debit_id, general_key, "phase6_composed_publication_quota",
                    effect_id, attempt_count, channel_id, general_units, start_stamp,
                    end_stamp, basis["general"], general_after, reserved_at,
                ),
            )
            connection.execute(
                """INSERT INTO upload_quota_debits
                   (debit_id,idempotency_key,effect_id,attempt_count,channel_id,release_id,
                    units,state,quota_day_start,quota_day_end,effective_before,effective_after,
                    observation_sha256,observation_observed_at,reserved_at,consumed_at,
                    confirmation_id,confirmation_sha256)
                   VALUES (?,?,?,?,?,?,1,'RESERVED',?,?,?,?,?,?,?,NULL,NULL,NULL)""",
                (
                    upload_debit_id, upload_key, effect_id, attempt_count, channel_id,
                    release_id, start_stamp, end_stamp, basis["upload"], upload_after,
                    observation["sha256"], _stamp(observation["observed_at"]), reserved_at,
                ),
            )
            connection.execute(
                """INSERT INTO composed_quota_reservations
                   (reservation_id,idempotency_key,effect_id,attempt_count,channel_id,release_id,
                    general_units,general_preventive_floor,upload_preventive_floor,
                    general_debit_id,upload_debit_id,state,quota_day_start,quota_day_end,
                    observation_archive_path,observation_sha256,observation_id,
                    observation_observed_at,reserved_at,consumed_at,confirmation_id,
                    confirmation_sha256,effect_started_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,'RESERVED',?,?,?,?,?,?,?,NULL,NULL,NULL,NULL)""",
                (
                    reservation_id, idempotency_key, effect_id, attempt_count, channel_id,
                    release_id, general_units, general_preventive_floor,
                    upload_preventive_floor, general_debit_id, upload_debit_id,
                    start_stamp, end_stamp, archive_relative.as_posix(),
                    observation["sha256"], observation["value"]["observation_id"],
                    _stamp(observation["observed_at"]), reserved_at,
                ),
            )
            reservation, general, upload = _load_composed_rows(
                connection, reservation_id=reservation_id
            )
            connection.commit()
    binding = _materialize_composed_receipt(root, reservation, general, upload)
    if replay:
        return revalidate_composed_quota(
            root,
            receipt_path=binding["path"],
            receipt_sha256=binding["sha256"],
            now=current,
        )
    return binding


def revalidate_composed_quota(
    root: Path = ROOT,
    *,
    receipt_path: str | Path,
    receipt_sha256: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Recheck binding, Pacific day, fresh evidence and both atomic floors."""

    root = root.resolve()
    current = _aware_utc(now or datetime.now(timezone.utc))
    receipt = _load_composed_receipt_binding(
        root, receipt_path=receipt_path, receipt_sha256=receipt_sha256
    )
    observation = _load_live_quota_observation(root, current=current)
    if (
        receipt["quota_day_start"] != _stamp(observation["start"])
        or receipt["quota_day_end"] != _stamp(observation["end"])
    ):
        raise QuotaReservationBlocked("quota reservation cannot cross the Pacific reset")
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=receipt["reservation_id"]
        )
        if receipt["state"] == "CONSUMED" and reservation["state"] != "CONSUMED":
            connection.rollback()
            raise QuotaReservationBlocked("consumed receipt conflicts with a reserved ledger")
        basis = _quota_basis_in_transaction(connection, root, observation)
        if (
            basis["general"] > GENERAL_LIMIT
            or GENERAL_LIMIT - basis["general"] < reservation["general_preventive_floor"]
            or basis["upload"] > UPLOAD_LIMIT
            or UPLOAD_LIMIT - basis["upload"] < reservation["upload_preventive_floor"]
        ):
            connection.rollback()
            raise QuotaReservationBlocked("current free quota no longer satisfies the reserved floors")
        connection.commit()
    return _materialize_composed_receipt(root, reservation, general, upload)


def mark_composed_quota_effect_started(
    root: Path = ROOT,
    *,
    receipt_path: str | Path,
    receipt_sha256: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Persist the exact pre-effect instant without consuming either bucket."""

    root = root.resolve()
    current = _aware_utc(now or datetime.now(timezone.utc))
    checked = revalidate_composed_quota(
        root,
        receipt_path=receipt_path,
        receipt_sha256=receipt_sha256,
        now=current,
    )
    if checked["receipt"]["state"] != "RESERVED":
        return checked
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=checked["receipt"]["reservation_id"]
        )
        if reservation["effect_started_at"] is None:
            connection.execute(
                "UPDATE composed_quota_reservations SET effect_started_at=? WHERE reservation_id=?",
                (_stamp(current), reservation["reservation_id"]),
            )
        elif reservation["effect_started_at"] != _stamp(current):
            # A retry must reuse the first immutable effect boundary; it may
            # never move an ambiguous external attempt into another quota day.
            existing = _parse(str(reservation["effect_started_at"]))
            start = _parse(str(reservation["quota_day_start"]))
            end = _parse(str(reservation["quota_day_end"]))
            if not start <= existing < end:
                connection.rollback()
                raise QuotaReservationBlocked("stored effect-start boundary is invalid")
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=reservation["reservation_id"]
        )
        connection.commit()
    return _materialize_composed_receipt(root, reservation, general, upload)


def consume_composed_quota(
    root: Path = ROOT,
    *,
    receipt_path: str | Path,
    receipt_sha256: str,
    confirmation_id: str,
    confirmation_sha256: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Consume both reserved buckets after one exact external-effect confirmation."""

    root = root.resolve()
    confirmation_id = _required_identity("confirmation_id", confirmation_id)
    confirmation_sha256 = _required_digest("confirmation_sha256", confirmation_sha256)
    current = _aware_utc(now or datetime.now(timezone.utc))
    receipt = _load_composed_receipt_binding(
        root, receipt_path=receipt_path, receipt_sha256=receipt_sha256
    )
    current_start, current_end = _quota_day(current)
    same_quota_day = (
        receipt["quota_day_start"] == _stamp(current_start)
        and receipt["quota_day_end"] == _stamp(current_end)
    )
    observation = (
        _load_live_quota_observation(root, current=current) if same_quota_day else None
    )
    consumed_at = _stamp(current)
    with _ledger_connection(root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=receipt["reservation_id"]
        )
        effect_started_at = (
            _parse(str(reservation["effect_started_at"]))
            if reservation["effect_started_at"] is not None
            else None
        )
        reserved_start = _parse(str(reservation["quota_day_start"]))
        reserved_end = _parse(str(reservation["quota_day_end"]))
        if effect_started_at is None or not reserved_start <= effect_started_at < reserved_end:
            connection.rollback()
            raise QuotaReservationBlocked(
                "quota consumption requires an immutable in-day effect-start boundary"
            )
        basis = (
            _quota_basis_in_transaction(connection, root, observation)
            if observation is not None
            else None
        )
        if basis is not None and (
            basis["general"] > GENERAL_LIMIT
            or GENERAL_LIMIT - basis["general"] < reservation["general_preventive_floor"]
            or basis["upload"] > UPLOAD_LIMIT
            or UPLOAD_LIMIT - basis["upload"] < reservation["upload_preventive_floor"]
        ):
            connection.rollback()
            raise QuotaReservationBlocked("current free quota no longer satisfies the reserved floors")
        if not same_quota_day and effect_started_at >= reserved_end:
            connection.rollback()
            raise QuotaReservationBlocked("quota consumption crossed the Pacific reset before effect start")
        if reservation["state"] == "CONSUMED":
            if (
                reservation["confirmation_id"] != confirmation_id
                or reservation["confirmation_sha256"] != confirmation_sha256
            ):
                connection.rollback()
                raise QuotaReservationBlocked(
                    "quota consumption replay carries a divergent external confirmation"
                )
        else:
            connection.execute(
                """UPDATE composed_quota_reservations
                   SET state='CONSUMED',consumed_at=?,confirmation_id=?,confirmation_sha256=?
                   WHERE reservation_id=? AND state='RESERVED'""",
                (consumed_at, confirmation_id, confirmation_sha256, reservation["reservation_id"]),
            )
            connection.execute(
                "UPDATE general_quota_debits SET state='CONSUMED',consumed_at=? WHERE debit_id=? AND state='RESERVED'",
                (consumed_at, general["debit_id"]),
            )
            connection.execute(
                """UPDATE upload_quota_debits
                   SET state='CONSUMED',consumed_at=?,confirmation_id=?,confirmation_sha256=?
                   WHERE debit_id=? AND state='RESERVED'""",
                (consumed_at, confirmation_id, confirmation_sha256, upload["debit_id"]),
            )
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=reservation["reservation_id"]
        )
        connection.commit()
    return _materialize_composed_receipt(root, reservation, general, upload)


def get_composed_quota_reservation(
    root: Path = ROOT,
    *,
    idempotency_key: str,
) -> dict[str, Any] | None:
    with _ledger_connection(root.resolve()) as connection:
        reservation = connection.execute(
            "SELECT * FROM composed_quota_reservations WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if reservation is None:
            return None
        reservation, general, upload = _load_composed_rows(
            connection, reservation_id=reservation["reservation_id"]
        )
        return {
            "reservation": _debit(reservation),
            "general": _debit(general),
            "upload": _debit(upload),
        }


def _tracked_general_units(
    root: Path,
    *,
    start: datetime,
    end: datetime,
    after: datetime,
) -> tuple[int, int]:
    with _ledger_connection(root) as connection:
        row = connection.execute(
            """SELECT COALESCE(SUM(units),0) AS units, COUNT(*) AS entries
               FROM general_quota_debits
               WHERE quota_day_start=? AND quota_day_end=? AND reserved_at>?""",
            (_stamp(start), _stamp(end), _stamp(after)),
        ).fetchone()
        return int(row["units"]), int(row["entries"])


def _confirmed_uploads(root: Path, start: datetime, end: datetime) -> int:
    return len(_confirmed_upload_records(root, start, end))


def effective_observation_quota_usage(
    root: Path = ROOT,
    *,
    now: datetime | None = None,
) -> dict[str, int] | None:
    """Return a fail-safe quota basis for read-only Phase 6 operations.

    The Google Cloud console snapshot is authoritative only inside its Pacific
    quota day. We add a fixed 2,000-unit reserve for calls not individually
    accounted by the local runtime. If another actor exhausts the dedicated
    project beyond that reserve, YouTube rejects the request without billing
    and the existing bounded retry path remains closed to inference.
    """

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    observation_path = root / OBSERVATION
    if not observation_path.is_file():
        return None
    try:
        observation = _read(observation_path)
        Draft202012Validator(
            _read(root / "schemas/youtube_quota_observation.schema.json"),
            format_checker=FormatChecker(),
        ).validate(observation)
    except Exception:
        return None
    usage = observation.get("observed_usage") or {}
    if not (
        observation.get("status") == "PASS"
        and observation.get("billing_enabled") is False
        and all(
            isinstance(usage.get(key), int)
            and not isinstance(usage.get(key), bool)
            and usage.get(key) >= 0
            for key in ("youtube-videos-insert-daily", "youtube-general-units-daily")
        )
    ):
        return None

    start, end = _quota_day(current)
    same_day = start <= _parse(str(observation["observed_at"])) < end
    base_uploads = int(usage["youtube-videos-insert-daily"]) if same_day else 0
    base_general = int(usage["youtube-general-units-daily"]) if same_day else 0
    ledger_cutoff = _parse(str(observation["observed_at"])) if same_day else start
    tracked_general, tracked_entries = _tracked_general_units(
        root, start=start, end=end, after=ledger_cutoff,
    )
    confirmed_uploads = _confirmed_uploads(root, start, end)
    effective = {
        "youtube-videos-insert-daily": min(
            UPLOAD_LIMIT, max(base_uploads, confirmed_uploads)
        ),
        "youtube-general-units-daily": min(
            GENERAL_LIMIT, base_general + UNTRACKED_GENERAL_RESERVE + tracked_general
        ),
    }
    identity = f"{_stamp(start)}|{_stamp(end)}|{same_day}|{tracked_general}|{tracked_entries}|{effective}"
    accounting = {
        "schema_version": "1.1.0",
        "accounting_id": "phase6-observation-quota-"
        + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20],
        "quota_day_start": _stamp(start),
        "quota_day_end": _stamp(end),
        "source_observation": OBSERVATION.as_posix(),
        "same_quota_day": same_day,
        "confirmed_upload_receipts": confirmed_uploads,
        "conservative_untracked_general_unit_reserve": UNTRACKED_GENERAL_RESERVE,
        "tracked_local_general_units": tracked_general,
        "tracked_local_entry_count": tracked_entries,
        "ledger_path": LEDGER.as_posix(),
        "ledger_cutoff_at": _stamp(ledger_cutoff),
        "effective_consumption_for_gate": effective,
        "limits": {
            "youtube-videos-insert-daily": UPLOAD_LIMIT,
            "youtube-general-units-daily": GENERAL_LIMIT,
        },
        "billing_enabled": False,
        "risk_of_billing": "BLOCKED_BY_NO_BILLING_ACCOUNT_AND_PREVENTIVE_QUOTA_FLOOR",
        "fallback": "DEFER_OBSERVATION_UNTIL_NEXT_FREE_QUOTA_DAY",
        "technical_cost_brl": 0,
        "created_at": _stamp(current),
    }
    Draft202012Validator(
        _read(root / "schemas/phase6_quota_accounting.schema.json"),
        format_checker=FormatChecker(),
    ).validate(accounting)
    _write_atomic(root / ACCOUNTING, accounting)
    return effective


if __name__ == "__main__":
    print(json.dumps(effective_observation_quota_usage(ROOT), ensure_ascii=False, indent=2))
