from __future__ import annotations

import copy
import math
import re
import uuid
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


RECIPE_ID = "phase6-cinematic-clip-visual-v4"
CANVAS_WIDTH = 1_920
CANVAS_HEIGHT = 1_080
SAFE_AREA_RATIO = 0.08
MINIMUM_FONT_SIZE = 54
LINE_SPACING = 12
TEXT_BORDER = 2

BASE_FILTERS = (
    "scale=1920:1080:force_original_aspect_ratio=increase:out_color_matrix=bt709:out_range=tv",
    "crop=1920:1080",
    "fps=30",
    "setsar=1",
    "eq=contrast=1.09:saturation=0.82:brightness=-0.018:gamma=0.98",
    "colorbalance=bs=0.018:gs=-0.006:rs=-0.008",
    "vignette=angle=PI/5.5",
)
OUTPUT_FILTERS = (
    "format=yuv420p",
    "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709",
)

TEXT_REQUIRED_TREATMENTS = frozenset({
    "HOOK_STAMP",
    "FRAMEWORK_STEP",
    "KEYWORD_PUNCH",
    "SECTION_CARD",
    "PAYOFF_RESOLUTION",
})
NO_MAIN_OVERLAY_TREATMENTS = frozenset({"CINEMATIC_BODY", "ACTION_EVIDENCE"})
FIXED_SYSTEM_TEXT = {
    "HOOK_FRAMEWORK": ("TRUTH", "RESPONSIBILITY", "TODAY"),
    "SCRIPTURE_SEQUENCE": ("ASK", "HEAR", "DO"),
}
FIXED_CANONICAL_COPY = {
    "SCRIPTURE_SEQUENCE": "ASK / HEAR / DO",
}
SUPPORTED_TREATMENTS = frozenset(
    set(TEXT_REQUIRED_TREATMENTS)
    | set(NO_MAIN_OVERLAY_TREATMENTS)
    | set(FIXED_SYSTEM_TEXT)
    | {"HOOK_QUESTION"}
)
BADGE_STATES = frozenset({"TRUTH", "RESPONSIBILITY", "TODAY", "COMPLETE"})
KNOWN_FRAMEWORK_STATES = BADGE_STATES | {"HIDDEN", "INTRODUCED"}


class VisualRecipeContractError(ValueError):
    """The take/treatment contract cannot be represented without data loss."""


class VisualRecipeLayoutError(ValueError):
    """The exact approved copy cannot fit the measured safe layout."""


@dataclass(frozen=True)
class _Region:
    x: int
    y: int
    width: int
    height: int
    horizontal: str = "center"
    vertical: str = "center"


def _safe_area() -> dict[str, int | float]:
    horizontal = math.ceil(CANVAS_WIDTH * SAFE_AREA_RATIO)
    vertical = math.ceil(CANVAS_HEIGHT * SAFE_AREA_RATIO)
    return {
        "ratio": SAFE_AREA_RATIO,
        "left": horizontal,
        "top": vertical,
        "right": CANVAS_WIDTH - horizontal,
        "bottom": CANVAS_HEIGHT - vertical,
        "width": CANVAS_WIDTH - (2 * horizontal),
        "height": CANVAS_HEIGHT - (2 * vertical),
    }


@lru_cache(maxsize=128)
def _font_at(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def _measure(font_path: Path, text: str, size: int) -> dict[str, Any]:
    lines = text.split("\n")
    if not 1 <= len(lines) <= 2 or any(line == "" for line in lines):
        raise VisualRecipeLayoutError("visual copy must contain one or two non-empty lines")
    font = _font_at(str(font_path.resolve()), size)
    canvas = Image.new("L", (1, 1), color=0)
    draw = ImageDraw.Draw(canvas)
    bbox = draw.multiline_textbbox(
        (0, 0), text, font=font, spacing=LINE_SPACING,
        stroke_width=TEXT_BORDER,
    )
    ascent, descent = font.getmetrics()
    line_widths = [math.ceil(draw.textlength(line, font=font)) for line in lines]
    metric_height = len(lines) * (ascent + descent) + (len(lines) - 1) * LINE_SPACING
    return {
        "width": max(math.ceil(bbox[2] - bbox[0]), max(line_widths) + 2 * TEXT_BORDER),
        "height": max(math.ceil(bbox[3] - bbox[1]), metric_height + 2 * TEXT_BORDER),
        "line_widths": line_widths,
        "pillow_bbox": [int(value) for value in bbox],
        "ascent": int(ascent),
        "descent": int(descent),
    }


def _layout_candidates(source: str, *, allow_wrap: bool) -> list[tuple[str, int | None]]:
    if "\r" in source:
        raise VisualRecipeContractError("carriage returns are not valid visual copy")
    newline_count = source.count("\n")
    if newline_count > 1:
        raise VisualRecipeLayoutError("visual copy exceeds the two-line contract")
    if newline_count == 1:
        return [(source, None)]
    candidates: list[tuple[str, int | None]] = [(source, None)]
    if allow_wrap:
        for index, character in enumerate(source):
            if character == " " and index > 0 and index < len(source) - 1:
                candidates.append((source[:index] + "\n" + source[index + 1 :], index))
    return candidates


def _restore_layout_break(render_text: str, break_index: int | None) -> str:
    if break_index is None:
        return render_text
    return render_text[:break_index] + " " + render_text[break_index + 1 :]


def _place_copy(
    *,
    role: str,
    source: str,
    font_path: Path,
    preferred_size: int,
    region: _Region,
    color: str,
    filename: str,
    allow_wrap: bool = True,
) -> dict[str, Any]:
    if preferred_size < MINIMUM_FONT_SIZE:
        raise VisualRecipeContractError("preferred font size is below the recipe minimum")
    if not source or not source.strip():
        raise VisualRecipeContractError(f"{role} requires non-empty visual copy")
    safe = _safe_area()
    if (
        region.x < safe["left"]
        or region.y < safe["top"]
        or region.x + region.width > safe["right"]
        or region.y + region.height > safe["bottom"]
    ):
        raise VisualRecipeLayoutError(f"{role} region leaves the 8% safe area")

    chosen: tuple[str, int | None, int, dict[str, Any]] | None = None
    candidates = _layout_candidates(source, allow_wrap=allow_wrap)
    for size in range(preferred_size, MINIMUM_FONT_SIZE - 1, -1):
        eligible: list[tuple[str, int | None, dict[str, Any]]] = []
        for rendered, break_index in candidates:
            measured = _measure(font_path, rendered, size)
            if measured["width"] <= region.width and measured["height"] <= region.height:
                eligible.append((rendered, break_index, measured))
        if eligible:
            eligible.sort(
                key=lambda item: (
                    item[0].count("\n"),
                    max(item[2]["line_widths"]),
                    abs(item[2]["line_widths"][0] - item[2]["line_widths"][-1]),
                )
            )
            rendered, break_index, measured = eligible[0]
            chosen = rendered, break_index, size, measured
            break
    if chosen is None:
        raise VisualRecipeLayoutError(
            f"{role} cannot fit at >= {MINIMUM_FONT_SIZE}px inside the measured two-line region"
        )

    rendered, break_index, size, measured = chosen
    if region.horizontal == "left":
        x = region.x
    elif region.horizontal == "right":
        x = region.x + region.width - measured["width"]
    else:
        x = region.x + (region.width - measured["width"]) // 2
    if region.vertical == "top":
        y = region.y
    elif region.vertical == "bottom":
        y = region.y + region.height - measured["height"]
    else:
        y = region.y + (region.height - measured["height"]) // 2
    bounds = {
        "left": int(x),
        "top": int(y),
        "right": int(x + measured["width"]),
        "bottom": int(y + measured["height"]),
        "width": int(measured["width"]),
        "height": int(measured["height"]),
    }
    safe_pass = (
        bounds["left"] >= safe["left"]
        and bounds["top"] >= safe["top"]
        and bounds["right"] <= safe["right"]
        and bounds["bottom"] <= safe["bottom"]
    )
    copy_preserved = _restore_layout_break(rendered, break_index) == source
    if not safe_pass or not copy_preserved or rendered.count("\n") > 1:
        raise VisualRecipeLayoutError(f"{role} failed safe-area/copy/line validation")
    return {
        "role": role,
        "source_text": source,
        "render_text": rendered,
        "layout_break_replaces_space_at": break_index,
        "copy_preserved": copy_preserved,
        "line_count": rendered.count("\n") + 1,
        "font_size": size,
        "font_path": str(font_path.resolve()),
        "color": color,
        "x": int(x),
        "y": int(y),
        "bounds": bounds,
        "measurement": measured,
        "safe_area_pass": safe_pass,
        "filename": filename,
    }


def _validated_contract(
    take: dict[str, Any], treatment: dict[str, Any]
) -> tuple[str, str, str | None, str]:
    take_id = take.get("take_id")
    if not isinstance(take_id, str) or re.fullmatch(r"[A-Za-z0-9_-]+", take_id) is None:
        raise VisualRecipeContractError("take_id is required and must be path-safe")
    kind = treatment.get("treatment")
    if kind not in SUPPORTED_TREATMENTS:
        raise VisualRecipeContractError(
            f"{kind!r} is outside the single cinematic clip-based recipe"
        )
    raw_text = take.get("on_screen_text")
    if raw_text is not None and not isinstance(raw_text, str):
        raise TypeError("take.on_screen_text must be a string or null")
    text = raw_text if isinstance(raw_text, str) and raw_text.strip() else None
    state = treatment.get("framework_state", "HIDDEN")
    if state not in KNOWN_FRAMEWORK_STATES:
        raise VisualRecipeContractError(f"unsupported framework_state: {state!r}")

    if kind in TEXT_REQUIRED_TREATMENTS and text is None:
        raise VisualRecipeContractError(f"{kind} requires on_screen_text")
    if kind in NO_MAIN_OVERLAY_TREATMENTS and raw_text is not None:
        raise VisualRecipeContractError(f"{kind} forbids a main text overlay")
    if kind in FIXED_SYSTEM_TEXT and text is None:
        raise VisualRecipeContractError(f"{kind} requires on_screen_text")
    # HOOK_FRAMEWORK has two intentional text layers: editorial copy owned by
    # TakePlan and the locked channel-system signature owned by Style Bible.
    # Treating the signature as the primary copy caused the renderer to erase
    # the planned hook while still appearing visually plausible.
    if kind in FIXED_SYSTEM_TEXT and kind != "HOOK_FRAMEWORK":
        expected = FIXED_CANONICAL_COPY[kind]
        if text != expected:
            raise VisualRecipeContractError(
                f"{kind} may only declare the locked copy {expected!r}"
            )
    return take_id, kind, text, state


def inspect_visual_layout(
    take: dict[str, Any],
    treatment: dict[str, Any],
    *,
    font: Path,
) -> dict[str, Any]:
    """Return measured geometry without writing files or invoking FFmpeg."""

    if not font.is_file():
        raise FileNotFoundError(f"visual recipe font does not exist: {font}")
    take_before, treatment_before = copy.deepcopy(take), copy.deepcopy(treatment)
    take_id, kind, text, state = _validated_contract(take, treatment)
    overlays: list[dict[str, Any]] = []
    decorations: list[str] = []

    if kind in {"HOOK_STAMP", "HOOK_QUESTION"} and text is not None:
        decorations.extend([
            "drawbox=x=0:y=0:w=900:h=1080:color=0x081827@0.30:t=fill",
            "drawbox=x=154:y=330:w=10:h=330:color=0xD7A94A@1.0:t=fill",
        ])
        overlays.append(_place_copy(
            role="main", source=text, font_path=font,
            preferred_size=116 if kind == "HOOK_STAMP" else 112,
            region=_Region(180, 250, 680, 560, horizontal="left"),
            color="0xE8EDF2", filename=f"{take_id}.txt",
        ))
    elif kind == "HOOK_FRAMEWORK":
        overlays.append(_place_copy(
            role="main", source=text or "", font_path=font,
            preferred_size=96,
            region=_Region(180, 250, 1500, 360, horizontal="left"),
            color="0xE8EDF2", filename=f"{take_id}.txt",
        ))
        decorations.extend([
            "drawbox=x=154:y=820:w=1612:h=150:color=0x081827@0.72:t=fill",
            "drawbox=x=154:y=820:w=1612:h=6:color=0xD7A94A@1.0:t=fill",
        ])
        safe = _safe_area()
        cell_width = int(safe["width"]) // 3
        colors = ("0xE8EDF2", "0xD7A94A", "0xE8EDF2")
        for index, (label, color) in enumerate(zip(FIXED_SYSTEM_TEXT[kind], colors), start=0):
            overlays.append(_place_copy(
                role=f"framework-{label.lower()}", source=label, font_path=font,
                preferred_size=54,
                region=_Region(int(safe["left"]) + index * cell_width, 842, cell_width, 108),
                color=color, filename=f"{take_id}-system-{index + 1}.txt",
                allow_wrap=False,
            ))
    elif kind == "SCRIPTURE_SEQUENCE":
        decorations.extend([
            "drawbox=x=210:y=700:w=1500:h=190:color=0x081827@0.78:t=fill",
            "drawbox=x=210:y=700:w=1500:h=7:color=0xD7A94A@1.0:t=fill",
            "drawbox=x=605:y=785:w=130:h=5:color=0xD7A94A@0.9:t=fill",
            "drawbox=x=1130:y=785:w=130:h=5:color=0xD7A94A@0.9:t=fill",
        ])
        colors = ("0xE8EDF2", "0xE8EDF2", "0xD7A94A")
        for index, (label, color) in enumerate(zip(FIXED_SYSTEM_TEXT[kind], colors), start=0):
            overlays.append(_place_copy(
                role=f"scripture-{label.lower()}", source=label, font_path=font,
                preferred_size=72,
                region=_Region(250 + index * 490, 730, 450, 130),
                color=color, filename=f"{take_id}-sequence-{index + 1}.txt",
                allow_wrap=False,
            ))
    elif kind == "FRAMEWORK_STEP":
        decorations.extend([
            "drawbox=x=154:y=690:w=1612:h=220:color=0x081827@0.78:t=fill",
            "drawbox=x=154:y=690:w=14:h=220:color=0xD7A94A@1.0:t=fill",
        ])
        overlays.append(_place_copy(
            role="main", source=text or "", font_path=font, preferred_size=66,
            region=_Region(190, 718, 1500, 166, horizontal="left"),
            color="0xE8EDF2", filename=f"{take_id}.txt",
        ))
    elif kind == "KEYWORD_PUNCH":
        decorations.extend([
            "drawbox=x=180:y=350:w=1560:h=300:color=0x081827@0.72:t=fill",
            "drawbox=x=180:y=350:w=14:h=300:color=0xD7A94A@1.0:t=fill",
        ])
        overlays.append(_place_copy(
            role="main", source=text or "", font_path=font, preferred_size=72,
            region=_Region(220, 390, 1480, 220), color="0xE8EDF2",
            filename=f"{take_id}.txt",
        ))
    elif kind == "SECTION_CARD":
        decorations.extend([
            "drawbox=x=154:y=690:w=1450:h=220:color=0x081827@0.58:t=fill",
            "drawbox=x=174:y=720:w=9:h=150:color=0xD7A94A@1.0:t=fill",
        ])
        overlays.append(_place_copy(
            role="main", source=text or "", font_path=font, preferred_size=68,
            region=_Region(210, 718, 1320, 166, horizontal="left"),
            color="0xE8EDF2", filename=f"{take_id}.txt",
        ))
    elif kind == "PAYOFF_RESOLUTION":
        decorations.extend([
            "drawbox=x=180:y=380:w=1560:h=260:color=0x081827@0.64:t=fill",
            "drawbox=x=420:y=650:w=1080:h=7:color=0xD7A94A@1.0:t=fill",
        ])
        overlays.append(_place_copy(
            role="main", source=text or "", font_path=font, preferred_size=76,
            region=_Region(240, 410, 1440, 200), color="0xE8EDF2",
            filename=f"{take_id}.txt",
        ))

    if state in BADGE_STATES and kind != "HOOK_FRAMEWORK":
        padding_x, padding_y = 18, 10
        badge = _place_copy(
            role="state-badge", source=state, font_path=font, preferred_size=54,
            region=_Region(1_208, 100, 540, 90, horizontal="right"),
            color="0xD7A94A", filename=f"{take_id}-state.txt",
            allow_wrap=False,
        )
        bounds = badge["bounds"]
        background_bounds = {
            "left": bounds["left"] - padding_x,
            "top": bounds["top"] - padding_y,
            "right": bounds["right"] + padding_x,
            "bottom": bounds["bottom"] + padding_y,
            "width": bounds["width"] + 2 * padding_x,
            "height": bounds["height"] + 2 * padding_y,
        }
        safe = _safe_area()
        if not (
            background_bounds["left"] >= safe["left"]
            and background_bounds["top"] >= safe["top"]
            and background_bounds["right"] <= safe["right"]
            and background_bounds["bottom"] <= safe["bottom"]
        ):
            raise VisualRecipeLayoutError("state badge background leaves the 8% safe area")
        badge["background_bounds"] = background_bounds
        decorations.append(
            "drawbox="
            f"x={background_bounds['left']}:y={background_bounds['top']}:"
            f"w={background_bounds['width']}:h={background_bounds['height']}:"
            "color=0x081827@0.68:t=fill"
        )
        overlays.append(badge)

    if take != take_before or treatment != treatment_before:
        raise RuntimeError("visual recipe mutated its take or treatment input")
    return {
        "recipe_id": RECIPE_ID,
        "scope": "EXISTING_CINEMATIC_CLIP_BASED_FORMAT_ONLY",
        "canvas": {"width": CANVAS_WIDTH, "height": CANVAS_HEIGHT},
        "safe_area": _safe_area(),
        "take_id": take_id,
        "treatment": kind,
        "framework_state": state,
        "main_overlay_present": any(item["role"] == "main" for item in overlays),
        "decorations": decorations,
        "overlays": overlays,
        "all_text_safe": all(item["safe_area_pass"] for item in overlays),
        "all_copy_preserved": all(item["copy_preserved"] for item in overlays),
        "maximum_line_count": max((item["line_count"] for item in overlays), default=0),
        "minimum_font_size": min((item["font_size"] for item in overlays), default=None),
    }


def _ffmpeg_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _drawtext_filter(font: Path, text_path: Path, overlay: dict[str, Any]) -> str:
    return (
        "drawtext="
        f"fontfile='{_ffmpeg_path(font)}':textfile='{_ffmpeg_path(text_path)}':"
        "expansion=none:"
        f"fontcolor={overlay['color']}:fontsize={overlay['font_size']}:"
        f"borderw={TEXT_BORDER}:bordercolor=0x081827@0.85:"
        f"x={overlay['x']}:y={overlay['y']}:line_spacing={LINE_SPACING}"
    )


def _write_text_atomic(path: Path, text: str) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        # Windows text-mode translation changes LF into CRLF. FFmpeg drawtext
        # can treat CR and LF as separate advances, unlike the measured layout.
        temporary.write_bytes(text.encode("utf-8"))
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def visual_filters(
    take: dict[str, Any],
    treatment: dict[str, Any],
    *,
    font: Path,
    work_dir: Path,
) -> list[str]:
    """Compile real FFmpeg filters for the existing Phase 6 visual recipe."""

    layout = inspect_visual_layout(take, treatment, font=font)
    work_dir.mkdir(parents=True, exist_ok=True)
    filters = list(BASE_FILTERS)
    filters.extend(layout["decorations"])
    for overlay in layout["overlays"]:
        text_path = work_dir / overlay["filename"]
        _write_text_atomic(text_path, overlay["render_text"])
        filters.append(_drawtext_filter(font, text_path, overlay))
    filters.extend(OUTPUT_FILTERS)
    return filters


__all__ = [
    "MINIMUM_FONT_SIZE",
    "RECIPE_ID",
    "VisualRecipeContractError",
    "VisualRecipeLayoutError",
    "inspect_visual_layout",
    "visual_filters",
]
