from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker, ValidationError

from .atomic_io import atomic_write_utf8
from .operation_fallbacks import build_coverage, markdown_coverage


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
PUBLICATION = Path("output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json")
BASE = Path("output/operations/phase6")


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _optional(path: Path) -> dict[str, Any]:
    try:
        return _read(path) if path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _paused_rejected_content(root: Path, quality: dict, media: dict, publication: dict) -> dict:
    """Authenticate a terminal rejection for maintenance, never a quality PASS.

    This observation exists only while the owner's exact PAUSE is present.
    It neither rewrites QUALITY nor makes a live/D116 observation admissible.
    All reads use the normal read-only queue snapshot, including protected
    database copies when called by the paused transaction.
    """
    return _terminal_rejected_content(root, quality, media, publication, paused=True)


def _terminal_rejected_content(root: Path, quality: dict, media: dict, publication: dict,
                               *, paused: bool, _snapshot_sources: dict | None = None) -> dict:
    """One rejection validator, with separate paused and observational contracts.

    Only D-116 supplies the exact immutable cycle snapshots for the three
    runtime aliases and the immutable evaluation for REPORT. No approval is
    accepted from a caller. Current producer reads always reopen the aliases.
    """
    if quality.get('job_state') == 'NOT_CREATED':
        return _prequeue_rejected_content(root, quality, media, publication,
                                         paused=paused, _snapshot_sources=_snapshot_sources)
    from .maintenance_protocol import queue_snapshot, canonical_hash
    from .phase6_quality import _evaluation_identity, REPORT, QUALITY_EVALUATIONS

    root = root.resolve()
    captured: dict[Path, bytes] = {}
    paths: dict[Path, Path] = {}
    sources = _snapshot_sources or {}
    permitted = {BASE / name for name in ('quality-executor-status.json',
                 'media-executor-status.json', 'publication-controller-status.json')} | {REPORT}
    if sources and (paused or set(sources) != permitted or sources[REPORT] != Path(quality['evaluation'])):
        raise PermissionError('terminal rejection snapshot source contract differs')
    pause_path = root / 'output/runtime/gestor-central/PAUSE'
    if not paused and pause_path.exists():
        raise PermissionError('active content observation requires owner pause absent')

    def capture(relative: str | Path) -> bytes:
        logical = root / relative
        path = root / sources.get(Path(relative), Path(relative))
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            raise PermissionError('paused content observation source is not confined')
        raw = path.read_bytes()
        captured[logical] = raw
        paths[logical] = path
        return raw

    def digest(raw: bytes) -> str:
        return 'sha256:' + hashlib.sha256(raw).hexdigest()

    if paused and not capture('output/runtime/gestor-central/PAUSE'):
        raise PermissionError('owner pause is empty')
    for name, value, schema in (
        ('quality-executor-status.json', quality, 'phase6_quality_executor_runtime.schema.json'),
        ('media-executor-status.json', media, 'phase6_media_executor_runtime.schema.json'),
        ('publication-controller-status.json', publication, 'phase6_publication_controller_runtime.schema.json'),
    ):
        if json.loads(capture(BASE / name)) != value:
            raise PermissionError('paused content observation cannot use a projected source')
        Draft202012Validator(_read(root / 'schemas' / schema), format_checker=FormatChecker()).validate(value)
    if not (quality['status'] == 'COMPLETED' and quality['job_state'] == 'SUCCEEDED'
            and quality['decision'] == 'FAIL' and quality['publication_eligible'] is False
            and quality['error'] is None and quality['next_action'] == 'REMEDIATE_PHASE6_VIDEO2'
            and media['status'] == 'COMPLETED' and media['job_state'] == 'SUCCEEDED'
            and media['error'] is None and media['publication_authorized'] is False
            and publication.get('status') == 'WAITING'
            and publication.get('error') is None
            and publication.get('privacy_status') == 'none'
            and publication.get('youtube_video_id') is None):
        raise PermissionError('paused content observation is not an inert terminal rejection')
    raw = capture(quality['evaluation'])
    report = json.loads(raw)
    Draft202012Validator(_read(root / 'schemas/phase6_quality_evaluation.schema.json'),
                        format_checker=FormatChecker()).validate(report)
    expected_path = QUALITY_EVALUATIONS / (report['evaluation_id'] + '.json')
    if not (Path(quality['evaluation']) == expected_path and capture(REPORT) == raw
            and report['evaluation_id'] == _evaluation_identity(report)
            and report['decision'] == 'FAIL' and report['publication_eligible'] is False
            and report['channel_id'] == CHANNEL_ID and report['blockers']):
        raise PermissionError('terminal quality rejection identity/alias differs')
    manifest = json.loads(capture(media['render_manifest']))
    artifact = report['artifact']
    if not (manifest['render_id'] == quality['media_render_id']
            and manifest['status'] == 'COMPLETE' and manifest['video_id'] == report['video_id']
            and manifest['output']['content_hash'] == 'sha256:' + artifact['sha256']):
        raise PermissionError('terminal quality rejection render binding differs')
    video = root / artifact['path']
    if video.is_symlink() or not video.resolve().is_relative_to(root) or not video.is_file():
        raise PermissionError('rejected media is not confined')
    video_stat = video.stat()
    with video.open('rb') as stream:
        video_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    if video_hash != artifact['sha256'] or video_stat.st_size != artifact['size_bytes']:
        raise PermissionError('rejected media bytes differ')
    queue = queue_snapshot(root, now=datetime.now(timezone.utc))
    jobs = queue['jobs']
    matches = [job for job in jobs if job['job_id'] == quality['job_id']]
    media_jobs = [job for job in jobs if job['job_id'] == media['job_id']]
    if (len(matches) != 1 or len(media_jobs) != 1
            or any(job.get('state') == 'LEASED' or job.get('lease_owner') is not None
                   or job.get('lease_until') is not None for job in jobs)):
        raise PermissionError('terminal quality rejection queue is active or ambiguous')
    job, media_job = matches[0], media_jobs[0]
    checkpoint = job.get('checkpoint', {})
    if not (job['state'] == media_job['state'] == 'SUCCEEDED'
            and job['task_type'] == 'EVALUATE_PHASE6_VIDEO2_QUALITY'
            and media_job['task_type'] == 'EXECUTE_PHASE6_VIDEO2_MEDIA'
            and job['channel_id'] == media_job['channel_id'] == CHANNEL_ID
            and job['operation_id'] == media_job['operation_id'] == 'heroverse-phase6-controlled-longform-v1'
            and job['payload']['render_id'] == manifest['render_id']
            and job['payload']['render_hash'] == 'sha256:' + artifact['sha256']
            and checkpoint.get('evaluation') == quality['evaluation']
            and checkpoint.get('evaluation_id') == report['evaluation_id']
            and checkpoint.get('evaluation_sha256') == digest(raw)
            and checkpoint.get('decision') == 'FAIL'
            and checkpoint.get('publication_eligible') is False
            and media_job['checkpoint'].get('render_manifest') == media['render_manifest']
            and media_job['checkpoint'].get('render_manifest_sha256') == digest(captured[root / media['render_manifest']])):
        raise PermissionError('terminal quality rejection checkpoint differs')
    after_stat = video.stat()
    if (queue_snapshot(root, now=datetime.now(timezone.utc))['jobs'] != jobs
            or any(paths[path].read_bytes() != content for path, content in captured.items())
            or (not paused and pause_path.exists())
            or (after_stat.st_size, after_stat.st_mtime_ns, after_stat.st_ino)
            != (video_stat.st_size, video_stat.st_mtime_ns, video_stat.st_ino)):
        raise PermissionError('paused content observation changed during capture')
    return {'kind': ('PAUSED_TERMINAL_QUALITY_REJECTION_V1' if paused
                     else 'ACTIVE_TERMINAL_QUALITY_REJECTION_V1'),
            'sources': [{'path': path.relative_to(root).as_posix(), 'sha256': digest(content)}
                        for path, content in sorted(captured.items())],
            ('queue_jobs_sha256' if paused else 'terminal_jobs_sha256'):
                canonical_hash(jobs if paused else sorted([job, media_job], key=lambda item: item['job_id'])),
            'evaluation_id': report['evaluation_id'],
            'artifact_sha256': 'sha256:' + video_hash,
            'restart_authorized': False, 'render_authorized': False, 'publication_authorized': False}


def _prequeue_rejected_content(root: Path, quality: dict, media: dict, publication: dict,
                               *, paused: bool, _snapshot_sources: dict | None = None) -> dict:
    """Authenticate the registered one-sided pixel FAIL, not a completed QA job.

    This explicit forward observation never relabels the historical evaluator,
    calls the queue writer, or supplies content/restart authority. Unknown,
    unimplemented, unregistered or inconclusive observations remain blocked.
    """
    from . import phase6_quality as q
    from .maintenance_protocol import canonical_hash, queue_snapshot
    root = root.resolve()
    sources = _snapshot_sources or {}
    runtime_paths = {BASE / name for name in ('quality-executor-status.json',
                     'media-executor-status.json', 'publication-controller-status.json')}
    if sources and (paused or set(sources) != runtime_paths):
        raise PermissionError('prequeue rejection snapshot source contract differs')
    pause = root / 'output/runtime/gestor-central/PAUSE'
    if pause.exists() != paused:
        raise PermissionError('prequeue observation owner pause differs')
    captured, actual_paths, identities = {}, {}, {}
    intent_storage = {}

    def capture(relative, expected=None):
        logical = q._resolve(root, str(relative))
        if not logical.is_relative_to(root):
            raise PermissionError('prequeue dependency is outside the project')
        key = logical.relative_to(root)
        path = q._resolve(root, str(sources.get(key, key)))
        archived = intent_storage.get(key.as_posix())
        if archived is not None and expected == archived['sha256']:
            path = q._resolve(root, archived['path'])
            key = path.relative_to(root)
        if path.is_symlink() or not path.is_file() or not path.is_relative_to(root):
            raise PermissionError('prequeue dependency is not confined')
        before = path.stat()
        with path.open('rb') as stream:
            digest = 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest()
        after = path.stat()
        identity = lambda s: (s.st_size, s.st_mtime_ns, s.st_ino)
        if identity(before) != identity(after) or (expected is not None and digest != expected):
            raise PermissionError('prequeue dependency bytes differ')
        name = key.as_posix()
        if name in captured and captured[name] != digest:
            raise PermissionError('prequeue dependency changed during capture')
        captured[name], actual_paths[name], identities[name] = digest, path, identity(after)
        return path

    if paused and not capture('output/runtime/gestor-central/PAUSE').read_bytes():
        raise PermissionError('owner pause is empty')
    for name, value, schema in (
        ('quality-executor-status.json', quality, 'phase6_quality_executor_runtime.schema.json'),
        ('media-executor-status.json', media, 'phase6_media_executor_runtime.schema.json'),
        ('publication-controller-status.json', publication, 'phase6_publication_controller_runtime.schema.json'),
    ):
        if _read(capture(BASE / name)) != value:
            raise PermissionError('prequeue observation cannot use a projected source')
        Draft202012Validator(_read(root / 'schemas' / schema), format_checker=FormatChecker()).validate(value)
    if not (quality['status'] == 'BLOCKED' and quality['decision'] == 'FAIL'
            and quality['job_state'] == 'NOT_CREATED' and quality['job_id'] is None
            and quality['evaluation'] is None and quality['publication_eligible'] is False
            and quality['error'] is None
            and media['status'] == 'COMPLETED' and media['job_state'] == 'SUCCEEDED'
            and media['error'] is None and media['publication_authorized'] is False
            and publication['status'] == 'WAITING' and publication['error'] is None
            and publication['privacy_status'] == 'none' and publication['youtube_video_id'] is None):
        raise PermissionError('prequeue observation is not an inert content rejection')
    manifest = _read(capture(media['render_manifest']))
    video_hash = manifest['output']['content_hash']
    binding = q.REGISTERED_VISUAL_WORD_EVIDENCE.get(video_hash)
    if not (manifest['status'] == 'COMPLETE' and manifest['render_id'] == quality['media_render_id']
            and binding and quality['next_action'] ==
            'REMEDIATE_CANONICAL_WORD_EXTENT:' + binding['path'] + '#' + binding['sha256']):
        raise PermissionError('prequeue rejection is not the registered render/counterevidence')
    measured = _read(capture(binding['path'], binding['sha256']))
    reference = q.read_phase6_visual_reference(root, measured['reference']['path'],
                                               expected_sha256=measured['reference']['sha256'])
    if reference['target']['sha256'] != video_hash:
        raise PermissionError('prequeue counterevidence target differs')
    archived_intents, intent_dependencies = q._visual_reference_intent_storage(root, reference)
    # Freeze the actual authenticated inputs, including archived QA, frames and
    # vector/raster sources. Historical implementation pins are deliberately
    # not presented as current executable bytes.
    def bindings(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
                capture(value['path'], value['sha256'])
            if 'frame_path' in value and 'frame_sha256' in value:
                capture(value['frame_path'], value['frame_sha256'])
            for key, item in value.items():
                if key != 'implementation_bindings':
                    bindings(item)
        elif isinstance(value, list):
            for item in value:
                bindings(item)
    bindings(intent_dependencies)
    intent_storage = archived_intents
    bindings(reference)
    for field in ('reference', 'quality_source', 'design_manifest', 'design_bindings'):
        bindings(measured[field])
    historical = _read(capture(measured['quality_source']['path'], measured['quality_source']['sha256']))
    bindings(historical['measurements']['overlay_ocr'])
    decision = q.evaluate_phase6_visual_word_evidence(root, receipt_path=binding['path'],
        expected_sha256=binding['sha256'], expected_video_sha256=video_hash)
    if decision['status'] != 'FAIL' or decision['observed']['source_confirmed_counterexamples'] < 1:
        raise PermissionError('prequeue counterevidence no longer proves a content failure')
    jobs = queue_snapshot(root, now=datetime.now(timezone.utc))['jobs']
    media_jobs = [job for job in jobs if job['job_id'] == media['job_id']]
    if (len(media_jobs) != 1 or any(job.get('state') == 'LEASED'
            or job.get('lease_owner') is not None or job.get('lease_until') is not None for job in jobs)):
        raise PermissionError('prequeue rejection queue is active or ambiguous')
    job = media_jobs[0]
    if not (job['state'] == 'SUCCEEDED' and job['task_type'] == 'EXECUTE_PHASE6_VIDEO2_MEDIA'
            and job['channel_id'] == CHANNEL_ID
            and job['operation_id'] == 'heroverse-phase6-controlled-longform-v1'
            and job['checkpoint'].get('render_manifest') == media['render_manifest']
            and job['checkpoint'].get('render_manifest_sha256') == captured[Path(media['render_manifest']).as_posix()]):
        raise PermissionError('prequeue media checkpoint differs')
    if any(job.get('task_type') == 'EVALUATE_PHASE6_VIDEO2_QUALITY'
           and job.get('state') != 'SUCCEEDED' for job in jobs):
        raise PermissionError('prequeue rejection has an unfinished quality job')
    if queue_snapshot(root, now=datetime.now(timezone.utc))['jobs'] != jobs or pause.exists() != paused:
        raise PermissionError('prequeue observation changed during capture')
    for name, path in actual_paths.items():
        stat = path.stat()
        if (stat.st_size, stat.st_mtime_ns, stat.st_ino) != identities[name]:
            raise PermissionError('prequeue source changed during capture')
        with path.open('rb') as stream:
            if 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest() != captured[name]:
                raise PermissionError('prequeue source bytes changed during capture')
    return {'kind': ('PAUSED_WORD_COUNTEREVIDENCE_V1' if paused else 'ACTIVE_WORD_COUNTEREVIDENCE_V1'),
            'sources': [{'path': name, 'sha256': digest} for name, digest in sorted(captured.items())],
            ('queue_jobs_sha256' if paused else 'terminal_jobs_sha256'):
                canonical_hash(jobs if paused else [job]),
            'evaluation_id': None, 'artifact_sha256': video_hash,
            'counterevidence': {**binding, 'logical_sha256':
                decision['observed']['current_revalidation']['logical_measurement_sha256']},
            'restart_authorized': False, 'render_authorized': False, 'publication_authorized': False}


def authenticated_prequeue_wait(root: Path, quality: dict) -> bool:
    """Narrow business-stop recognition shared by cycle and paused preview."""
    if quality.get('status') != 'BLOCKED' or quality.get('decision') != 'FAIL' or quality.get('job_state') != 'NOT_CREATED':
        return False
    try:
        _prequeue_rejected_content(root, quality, _read(root / BASE / 'media-executor-status.json'),
            _read(root / BASE / 'publication-controller-status.json'),
            paused=(root / 'output/runtime/gestor-central/PAUSE').exists())
    except (OSError, ValueError, KeyError, TypeError, ValidationError, PermissionError):
        return False
    return True


def _build_audio_status(root, relative, bindings, release_hash, captured_at):
    """Current native producers only; never promote a historical canary view."""
    from .phase5_release_gate import build_release_gate
    from .phase5_youtube_publisher import execute_publication_pipeline
    from .phase6_intelligence import materialize_current
    from .maintenance_paused_application import candidate_identity
    relative = Path(relative)
    directory = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not directory.is_relative_to(root / 'output/production'):
        raise PermissionError('Current executive package must be confined to production')
    release_path = directory / 'release_gate.json'
    def digest(path):
        return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()
    if digest(release_path) != release_hash:
        raise PermissionError('Current executive release external anchor diverged')
    release = _read(release_path)
    if release != build_release_gate(root, package_relative=relative, current_bindings=bindings,
                                     created_at=release['created_at']):
        raise PermissionError('Current executive release differs from its native producers')
    pins = {release_path: release_hash}
    producer_receipts = {'release': {'path': release_path.relative_to(root).as_posix(), 'sha256':release_hash}}
    instrumental = 'music_inputs' in bindings
    pack_file=('fp-christian-reflection-rest-static-v1.json' if release['schema_version']=='1.3.0' else
               'fp-christian-rest-instrumental-static-v1.json') if instrumental else 'fp-narrated-reflection-static-v1.json'
    pack_path = root/'config/format_packs'/pack_file
    pins[pack_path] = digest(pack_path)
    producer_receipts['format_pack'] = {'path':pack_path.relative_to(root).as_posix(), 'sha256':pins[pack_path]}
    selected = dict(bindings)
    if instrumental:
        music = selected.pop('music_inputs')
        qualification = selected.pop('qualification_inputs')
        selected.update({'music_'+label:ref for label,ref in music.items()})
        selected.update({'quality_report' if label=='qualification' else label:ref
                         for label,ref in qualification.items()})
    for label, binding in selected.items():
        source = Path(binding['path'])
        source = source.resolve() if source.is_absolute() else (root/source).resolve()
        if not source.is_relative_to(root) or digest(source) != binding['sha256']:
            raise PermissionError('Current executive producer binding diverged')
        pins[source] = binding['sha256']
        producer_receipts[label] = {'path':source.relative_to(root).as_posix(), 'sha256':binding['sha256']}
    publication_path = directory / 'youtube-publication-receipt.json'
    publication = _read(publication_path) if publication_path.is_file() else {}
    if publication:
        pins[publication_path] = digest(publication_path)
        producer_receipts['publication'] = {'path':publication_path.relative_to(root).as_posix(), 'sha256':pins[publication_path]}
        if publication.get('status') == 'COMPLETE_PUBLIC':
            publication = execute_publication_pipeline(None, None, root, package_relative=relative,
                current_bindings=bindings, expected_release_hash=release_hash)
    observer_path = directory/'observer-status.json'
    observer = _read(observer_path) if observer_path.is_file() else {}
    if observer:
        Draft202012Validator(_read(root/'schemas/phase6_observer_runtime.schema.json'), format_checker=FormatChecker()).validate(observer)
        if publication.get('status') != 'COMPLETE_PUBLIC' or observer['video_id'] != publication['video_id']:
            raise PermissionError('Current executive observer belongs to another or incomplete delivery')
        pins[observer_path] = digest(observer_path)
        producer_receipts['observer'] = {'path':observer_path.relative_to(root).as_posix(), 'sha256':pins[observer_path]}
    prediction, diagnosis, protocol = {}, {}, {}
    if observer.get('status') in {'COLLECTED', 'NOT_DUE'} and observer.get('latest_snapshot'):
        paths = materialize_current(root, package_relative=relative, current_bindings=bindings,
            expected_release_hash=release_hash, snapshot_reference=observer['latest_snapshot'])
        prediction, diagnosis, protocol = [_read(p) for p in paths]
        for label, source in zip(('prediction','diagnosis','experiment'), paths):
            pins[source] = digest(source)
            producer_receipts[label] = {'path':source.relative_to(root).as_posix(), 'sha256':pins[source]}
        snapshot_path = root/observer['latest_snapshot']
        pins[snapshot_path] = digest(snapshot_path)
        producer_receipts['owned_snapshot'] = {'path':observer['latest_snapshot'], 'sha256':pins[snapshot_path]}
    blockers = list(release['blockers'])
    if publication and publication.get('status') != 'COMPLETE_PUBLIC':
        blockers.append('CURRENT_PUBLICATION_INCOMPLETE')
    if observer.get('error') or observer.get('status') == 'ERROR':
        blockers.append('CURRENT_OBSERVER_ERROR')
    if diagnosis.get('status') == 'BLOCKED_INVALID_BASELINE':
        blockers.append('CURRENT_BASELINE_INVALID')
    candidate = candidate_identity(root)['source_set_sha256']
    value = {
        'schema_version':'2.0.0','status_id':'heroverse-phase6-executive-v1','phase':6,
        'status':'ATTENTION_REQUIRED' if blockers else 'ACTIVE_OBSERVING',
        'captured_at':captured_at or _stamp(datetime.now(timezone.utc)),
        'source_candidate_sha256':candidate,
        'current_delivery':{
            'package_relative':relative.as_posix(),'operation_id':'heroverse-audio-static-longform-v1',
            'video_id':publication.get('video_id'), 'release_decision':release['decision'],
            'publication_status':('COMPLETE_PUBLIC' if publication.get('status')=='COMPLETE_PUBLIC'
                                  else ('INCOMPLETE' if publication else 'NOT_STARTED')),
            'observer_status':observer.get('status','NOT_STARTED'),
            'next_observation_at':observer.get('next_observation_at'),
            'prediction_status':prediction.get('status','UNAVAILABLE'),
            'diagnosis_status':diagnosis.get('status','UNAVAILABLE'),
            'treatment_variable':(diagnosis.get('decision') or {}).get('treatment_variable','NONE'),
            'experiment_status':protocol.get('status','UNAVAILABLE'),
        },
        'producer_receipts':producer_receipts,
        'cost':{'technical_cost_brl':0,'media_spend_brl':0,'paid_tools':False},
        'next_action':{'action':('RESOLVE_CURRENT_GATES' if blockers else
            ('OBSERVE_CURRENT_DELIVERY' if publication else 'CONSUME_CURRENT_RELEASE_GATES')),
            'scheduled_at':observer.get('next_observation_at'),'automatic':True},
        'attention_items':sorted(set(blockers)),
        'evidence':list(dict.fromkeys(item['path'] for item in producer_receipts.values())),
        'claim_boundary':[
            'Current report is not acceptance, a completed twelve-stage cycle, adoption or D116.',
            'Source candidate identity is observed code, not an assertion that these bytes were applied.',
            'No legacy canary or active historical experiment supplies current delivery evidence.',
            'Withheld calibration and staged experiments do not claim causal learning, revenue, RPM or profit.',
            'Rights, policy, release, capacity and operational gates remain mandatory; a report grants no effect authority.',
        ],
    }
    Draft202012Validator(_read(root/'schemas/phase6_executive_status.schema.json'), format_checker=FormatChecker()).validate(value)
    if any(digest(source) != expected for source,expected in pins.items()) or candidate_identity(root)['source_set_sha256'] != candidate:
        raise PermissionError('Current executive producers changed during capture')
    return value


def build_status(
    root: Path = ROOT,
    *,
    captured_at: str | None = None,
    prediction_runtime_override: dict[str, Any] | None = None,
    media_executor_override: dict[str, Any] | None = None,
    goal_trajectory_override: dict[str, Any] | None = None,
    quality_executor_override: dict[str, Any] | None = None,
    package_relative: Path | None = None,
    current_bindings: dict[str, Any] | None = None,
    expected_release_hash: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    if any(item is not None for item in (package_relative,current_bindings,expected_release_hash)):
        if any(item is None for item in (package_relative,current_bindings,expected_release_hash)):
            raise PermissionError('Current executive requires complete explicit delivery selection')
        if any(item is not None for item in (prediction_runtime_override,media_executor_override,goal_trajectory_override,quality_executor_override)):
            raise PermissionError('Current executive does not accept legacy producer overrides')
        return _build_audio_status(root, package_relative, current_bindings, expected_release_hash, captured_at)
    now = _parse(captured_at) if captured_at else datetime.now(timezone.utc)
    publication = _read(root / PUBLICATION)
    if publication.get("status") != "COMPLETE_PUBLIC" or publication.get("video_id") != VIDEO_ID:
        raise PermissionError("executive Phase 6 status requires exact public canary receipt")
    metrics_path = root / BASE / "metrics" / VIDEO_ID / "latest.json"
    reporting_path = root / BASE / "reporting/job-registry.json"
    reach_path = root / BASE / "reporting/reach" / VIDEO_ID / "latest.json"
    queue_path = root / BASE / "runtime/queue-snapshot.json"
    prediction_path = root / BASE / "intelligence/predictions/latest.json"
    prediction_runtime_path = root / BASE / "intelligence/prediction-runtime.json"
    diagnosis_path = root / BASE / "intelligence/diagnoses/latest.json"
    experiment_path = root / BASE / "intelligence/experiments/latest.json"
    learning_runtime_path = root / BASE / "intelligence/learning-runtime.json"
    treatment_order_path = root / BASE / "production/latest-order.json"
    treatment_executor_path = root / BASE / "production/executor-status.json"
    format_scope_path = root / BASE / "production/format-scope-receipt.json"
    release_work_order_path = root / BASE / "release/latest-work-order.json"
    release_preparer_path = root / BASE / "release/preparer-status.json"
    package_executor_path = root / BASE / "package-treatment-executor-status.json"
    media_executor_path = root / BASE / "media-executor-status.json"
    asset_residency_path = root / BASE / "capacity/asset-library-residency.json"
    quality_executor_path = root / BASE / "quality-executor-status.json"
    publication_controller_path = root / BASE / "publication-controller-status.json"
    phase_transition_path = root / BASE / "phase-transition-runtime.json"
    control_cycle_path = root / BASE / "control-cycle/latest.json"
    from .phase6_goal_trajectory import current_path as current_goal_trajectory_path
    goal_trajectory_path = current_goal_trajectory_path(root)
    channel_goal_runtime_path = root / BASE / "channel-goal-observer/status.json"
    channel_goal_observation_path = root / BASE / "channel-goal-observer/latest.json"
    observer_path = root / BASE / "observer-status.json"
    channel_snapshot_path = root / "output/audits/channel/heroverse/channel-snapshot.json"
    metrics = _optional(metrics_path)
    started = _parse(str(metrics.get("published_at") or publication["created_at"]))
    deadline = started + timedelta(days=30)
    reporting = _optional(reporting_path)
    reach = _optional(reach_path)
    queue = _optional(queue_path)
    prediction = _optional(prediction_path)
    prediction_runtime = (
        prediction_runtime_override
        if prediction_runtime_override is not None
        else _optional(prediction_runtime_path)
    )
    diagnosis = _optional(diagnosis_path)
    experiment = _optional(experiment_path)
    learning_runtime = _optional(learning_runtime_path)
    treatment_order = _optional(treatment_order_path)
    treatment_executor = _optional(treatment_executor_path)
    format_scope = _optional(format_scope_path)
    release_work_order = _optional(release_work_order_path)
    release_preparer = _optional(release_preparer_path)
    package_executor = _optional(package_executor_path)
    media_executor = (
        media_executor_override
        if media_executor_override is not None
        else _optional(media_executor_path)
    )
    asset_residency = _optional(asset_residency_path)
    quality_executor = (quality_executor_override if quality_executor_override is not None
                        else _optional(quality_executor_path))
    publication_controller = _optional(publication_controller_path)
    phase_transition = _optional(phase_transition_path)
    cycle_raw = control_cycle_path.read_bytes() if control_cycle_path.is_file() else None
    control_cycle = json.loads(cycle_raw.decode("utf-8-sig")) if cycle_raw else {}
    goal_raw = (goal_trajectory_path.read_bytes()
                if goal_trajectory_override is None and goal_trajectory_path.is_file() else None)
    goal_trajectory = (
        goal_trajectory_override
        if goal_trajectory_override is not None
        else json.loads(goal_raw.decode("utf-8-sig")) if goal_raw else {}
    )
    goal_trajectory_from_disk = (
        goal_trajectory_override is None and bool(goal_trajectory)
    )
    channel_goal_runtime = _optional(channel_goal_runtime_path)
    if goal_trajectory_from_disk:
        measurement = goal_trajectory.get("measurement") or {}
        if (measurement.get("daily_observer_status", "UNAVAILABLE") != channel_goal_runtime.get("status", "UNAVAILABLE")
                or measurement.get("daily_observer_next_at") != channel_goal_runtime.get("next_observation_at")):
            raise PermissionError("persisted goal trajectory differs from current observer runtime")
    observer = _optional(observer_path)
    channel_snapshot = _optional(channel_snapshot_path)
    public = metrics.get("public_metrics") or {}
    private = metrics.get("private_metrics") or {}
    metrics_snapshot_age = metrics.get("age_hours")
    current_age = round(max(0.0, (now - started).total_seconds() / 3600), 6)
    critical_attention: list[str] = []
    post_effect_visual_remediation_required = False
    if (
        media_executor.get("schema_version") == "1.3.0"
        or media_executor.get("remediation_wait") is not None
    ):
        try:
            Draft202012Validator(
                _read(root / "schemas/phase6_media_executor_runtime.schema.json"),
                format_checker=FormatChecker(),
            ).validate(media_executor)
            binding = media_executor.get("remediation_wait")
            post_effect_visual_remediation_required = bool(
                media_executor.get("schema_version") == "1.3.0"
                and media_executor.get("status") == "WAITING"
                and media_executor.get("job_state") == "SUCCEEDED"
                and media_executor.get("next_action")
                == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
                and media_executor.get("publication_authorized") is False
                and isinstance(binding, dict)
                and binding.get("status") == "ELIGIBLE_FOR_WAITING_STATE"
                and binding.get("reason")
                == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
            )
        except (OSError, json.JSONDecodeError, ValidationError):
            critical_attention.append("MEDIA_EXECUTOR_INVALID")
    if post_effect_visual_remediation_required:
        critical_attention.append("MEDIA_POST_EFFECT_VISUAL_REMEDIATION_REQUIRED")
    control_cycle_summary: dict[str, Any] | None = None
    if control_cycle:
        try:
            Draft202012Validator(
                _read(root / "schemas/phase6_control_cycle_receipt.schema.json"),
                format_checker=FormatChecker(),
            ).validate(control_cycle)
            # Schema 1.0 remains valid only as immutable history. A mutable
            # executive view on the 12-stage contract must not embed the
            # legacy 11-stage summary, or the first upgraded cycle could not
            # validate its EXECUTIVE_VIEW stage. It is temporarily omitted;
            # the same loop then creates 1.1/12 and refreshes the panel.
            if control_cycle.get("schema_version") == "1.1.0" and control_cycle.get("stage_count") == 12:
                control_cycle_summary = {
                    "cycle_id": control_cycle["cycle_id"],
                    "decision": control_cycle["decision"],
                    "change_class": control_cycle["change_class"],
                    "stage_count": control_cycle["stage_count"],
                    "all_schemas_valid": control_cycle["all_schemas_valid"],
                    "all_stages_executed_in_cycle": control_cycle["all_stages_executed_in_cycle"],
                    "blockers": control_cycle["blockers"],
                    "cycle_completed_at": control_cycle["cycle_completed_at"],
                    "substantive_signature": control_cycle["substantive_signature"],
                }
        except (OSError, json.JSONDecodeError, KeyError, ValidationError):
            critical_attention.append("CONTROL_CYCLE_INVALID")
    try:
        if not goal_trajectory:
            from .phase6_goal_trajectory import build_goal_trajectory

            goal_trajectory = build_goal_trajectory(
                root, evaluated_at=_stamp(now), media_override=media_executor_override
            )
        Draft202012Validator(
            _read(root / "schemas/phase6_goal_trajectory.schema.json"),
            format_checker=FormatChecker(),
        ).validate(goal_trajectory)
        if (goal_trajectory["decision"].get("production_block") or {}).get("status") == "EVIDENCE_INVALID":
            critical_attention.append("GOAL_TRAJECTORY_MEDIA_EVIDENCE_INVALID")
        elif goal_trajectory_from_disk or goal_trajectory_override is not None:
            # A persisted decision cannot prove its dependencies are still intact.
            # Reopen them once at this consumer boundary. An explicit maintenance
            # override is only a proposed view; its proof is checked by the
            # migration protocol, not declared here as a live deployment.
            from .phase6_goal_trajectory import MEDIA_BLOCK_IDENTITY_FIELDS, _media_decision_context

            _, current_block = _media_decision_context(root, media_override=media_executor_override)
            previous_block = goal_trajectory["decision"].get("production_block")
            block_identity = lambda block: (
                {key: block[key] for key in MEDIA_BLOCK_IDENTITY_FIELDS} if block else None
            )
            if (
                (current_block or {}).get("status") == "EVIDENCE_INVALID"
                or block_identity(current_block) != block_identity(previous_block)
            ):
                critical_attention.append("GOAL_TRAJECTORY_MEDIA_EVIDENCE_INVALID")
    except (OSError, json.JSONDecodeError, KeyError, ValueError, PermissionError, ValidationError):
        critical_attention.append("GOAL_TRAJECTORY_INVALID")
        raise
    format_scope_schema_valid = False
    if format_scope:
        try:
            Draft202012Validator(
                _read(root / "schemas/phase6_format_scope_receipt.schema.json"),
                format_checker=FormatChecker(),
            ).validate(format_scope)
            format_scope_schema_valid = True
        except (OSError, json.JSONDecodeError, ValidationError):
            critical_attention.append("FORMAT_SCOPE_INVALID")
    if reporting.get("status") in {"ERROR", "BLOCKED", "PARTIAL"}:
        critical_attention.append(f"REPORTING_{reporting.get('status')}")
    if queue.get("status") == "ATTENTION_REQUIRED":
        critical_attention.append("QUEUE_DEAD_LETTER")
    if observer.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"OBSERVER_{observer.get('status')}")
    if channel_goal_runtime:
        try:
            Draft202012Validator(
                _read(root / "schemas/phase6_channel_goal_observer_runtime.schema.json"),
                format_checker=FormatChecker(),
            ).validate(channel_goal_runtime)
        except (OSError, json.JSONDecodeError, ValidationError):
            critical_attention.append("CHANNEL_GOAL_OBSERVER_INVALID")
    if channel_goal_runtime.get("status") in {"ERROR", "BLOCKED"}:
        from .phase6_channel_goal_observer import is_closed_failed_window

        try:
            closed_history = is_closed_failed_window(root, channel_goal_runtime, now=now)
        except (OSError, ValueError, KeyError, TypeError, PermissionError, ValidationError):
            closed_history = False
        if not closed_history:
            critical_attention.append(f"CHANNEL_GOAL_OBSERVER_{channel_goal_runtime.get('status')}")
    retry = metrics.get("observation_schedule", {}).get("retry", {})
    if metrics.get("status") == "FAILED" and retry.get("enabled") is not True:
        critical_attention.append("OWNED_METRICS_FAILED_RETRY_EXHAUSTED")
    if (metrics.get("goal_measurement") or {}).get("status") == "SOURCE_FAILURE_RETRY_EXHAUSTED":
        critical_attention.append("SUBSCRIBER_TRAJECTORY_SOURCE_RETRY_EXHAUSTED")
    if treatment_order.get("status") == "BLOCKED":
        critical_attention.append("TREATMENT_ORDER_BLOCKED")
    if treatment_executor.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"TREATMENT_EXECUTOR_{treatment_executor.get('status')}")
    if format_scope.get("status") == "BLOCKED":
        critical_attention.append("FORMAT_SCOPE_BLOCKED")
    if release_work_order.get("status") == "BLOCKED":
        critical_attention.append("RELEASE_WORK_ORDER_BLOCKED")
    if release_preparer.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"RELEASE_PREPARER_{release_preparer.get('status')}")
    if package_executor.get("status") in {"ERROR", "BLOCKED", "ROLLED_BACK"}:
        critical_attention.append(f"PACKAGE_EXECUTOR_{package_executor.get('status')}")
    if media_executor.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"MEDIA_EXECUTOR_{media_executor.get('status')}")
    if media_executor.get("capacity_status") == "BLOCKED":
        critical_attention.append("LOCAL_CAPACITY_BLOCKED")
    if asset_residency.get("status") == "BLOCKED":
        critical_attention.append("ASSET_RESIDENCY_BLOCKED")
    if quality_executor.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"QUALITY_EXECUTOR_{quality_executor.get('status')}")
    if quality_executor.get("status") == "COMPLETED" and quality_executor.get("decision") in {"FAIL", "NEEDS_REVIEW"}:
        critical_attention.append(f"QUALITY_DECISION_{quality_executor.get('decision')}")
    if publication_controller.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"PUBLICATION_CONTROLLER_{publication_controller.get('status')}")
    if learning_runtime.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"LEARNING_RUNTIME_{learning_runtime.get('status')}")
    if prediction_runtime.get("status") in {"ERROR", "BLOCKED_CREDENTIAL"}:
        critical_attention.append(f"PREDICTION_RUNTIME_{prediction_runtime.get('status')}")
    if phase_transition.get("status") in {"ERROR", "BLOCKED"}:
        critical_attention.append(f"PHASE_TRANSITION_{phase_transition.get('status')}")
    diagnosis_decision = diagnosis.get("decision") or {}
    expected_scope_action = (
        "COMPILE_CANARY_PACKAGE_UPDATE"
        if diagnosis_decision.get("treatment_variable") == "TITLE_THUMBNAIL_PROMISE"
        else "COMPILE_VIDEO_2"
    )
    expected_scope_target = (
        VIDEO_ID
        if expected_scope_action == "COMPILE_CANARY_PACKAGE_UPDATE"
        else "phase6-video-2-prepublication"
    )
    expected_scope_ordinal = 1 if expected_scope_action == "COMPILE_CANARY_PACKAGE_UPDATE" else 2
    scope_gates = format_scope.get("gates") or []
    scope_counts = {
        state: sum(1 for gate in scope_gates if gate.get("status") == state)
        for state in ("PASS", "WAITING", "BLOCKED")
    }
    scope_authorized = (
        format_scope_schema_valid
        and format_scope.get("status") == "AUTHORIZED"
        and format_scope.get("requested_action") == expected_scope_action
        and format_scope.get("target_video_id") == expected_scope_target
        and format_scope.get("video_ordinal") == expected_scope_ordinal
        and format_scope.get("publication_authorized") is False
        and format_scope.get("technical_cost_brl") == 0
        and scope_counts["WAITING"] == 0
        and scope_counts["BLOCKED"] == 0
    )
    readiness = (
        isinstance(metrics_snapshot_age, (int, float)) and metrics_snapshot_age >= 24
        and metrics.get("decision_status") == "ELIGIBLE_FOR_COMPARISON"
        and diagnosis.get("status") == "DIAGNOSED"
        and diagnosis_decision.get("production_may_start") is True
        and experiment.get("status") in {"PREREGISTERED", "RUNNING"}
        and scope_authorized
        and not critical_attention
    )
    next_candidates = [
        value
        for value in (
            learning_runtime.get("next_observation_at"),
            package_executor.get("scheduled_for"),
            prediction_runtime.get("next_observation_at"),
            observer.get("next_observation_at"),
            channel_goal_runtime.get("next_observation_at"),
            metrics.get("next_observation_at"),
        )
        if isinstance(value, str) and value
    ]
    next_at = min(next_candidates, key=_parse) if next_candidates else None
    status = (
        "ACTIVE_OBSERVING_PRODUCTION_BLOCKED"
        if critical_attention == ["MEDIA_POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"]
        else ("ATTENTION_REQUIRED" if critical_attention else "ACTIVE_OBSERVING")
    )
    paused_content = active_content = None
    if (critical_attention == ['QUALITY_DECISION_FAIL'] or
            (critical_attention == ['QUALITY_EXECUTOR_BLOCKED'] and quality_executor.get('decision') == 'FAIL'
             and quality_executor.get('job_state') == 'NOT_CREATED')):
        owner_paused = (root / 'output/runtime/gestor-central/PAUSE').exists()
        try:
            content = _terminal_rejected_content(root, quality_executor, media_executor,
                                                publication_controller, paused=owner_paused)
        except (OSError, ValueError, KeyError, TypeError, ValidationError, PermissionError):
            # Unknown or changed evidence remains ATTENTION_REQUIRED. This is
            # not an exception to quality, release, queue, or restart gates.
            critical_attention.append(('PAUSED' if owner_paused else 'ACTIVE') + '_QUALITY_REJECTION_EVIDENCE_INVALID')
        else:
            if owner_paused:
                paused_content, status = content, 'PAUSED_CONTENT_REMEDIATION'
            else:
                active_content, status = content, 'ACTIVE_CONTENT_REMEDIATION'
    subscriber_trajectory = goal_trajectory["subscriber_trajectory"]
    subscriber_measurement = goal_trajectory["measurement"]
    current_subscribers_observed = subscriber_measurement["current_subscribers_observed"] is True
    current_subscribers = (
        subscriber_trajectory["current_subscribers"]
        if current_subscribers_observed
        else None
    )
    baseline_precedes_goal_start_hours = subscriber_trajectory.get("baseline_precedes_goal_start_hours")
    if not isinstance(baseline_precedes_goal_start_hours, (int, float)):
        baseline_precedes_goal_start_hours = round(
            max(
                0.0,
                (
                    started - _parse(str(subscriber_trajectory["baseline_observed_at"]))
                ).total_seconds()
                / 3600,
            ),
            6,
        )
    pace_status = subscriber_trajectory.get("pace_status")
    if pace_status not in {
        "UNAVAILABLE_NO_CURRENT_OBSERVATION",
        "WAITING_SECOND_DISTINCT_IN_WINDOW_OBSERVATION",
        "MEASURED_FROM_IN_WINDOW_ANCHOR",
    }:
        pace_status = (
            "WAITING_SECOND_DISTINCT_IN_WINDOW_OBSERVATION"
            if current_subscribers_observed
            else "UNAVAILABLE_NO_CURRENT_OBSERVATION"
        )
    pace_anchor_subscribers = subscriber_trajectory.get("pace_anchor_subscribers")
    pace_anchor_observed_at = subscriber_trajectory.get("pace_anchor_observed_at")
    pace_comparable_observation_count = subscriber_trajectory.get("pace_comparable_observation_count")
    if not isinstance(pace_comparable_observation_count, int):
        pace_comparable_observation_count = 1 if current_subscribers_observed else 0
    value = {
        "schema_version": "1.5.0", "status_id": "heroverse-phase6-executive-v1",
        "phase": 6, "status": status, "captured_at": _stamp(now),
        "goal_window": {
            "started_at": _stamp(started), "deadline_at": _stamp(deadline),
            "elapsed_hours": current_age,
            "remaining_hours": round(max(0.0, (deadline - now).total_seconds() / 3600), 6),
            "target_days": 30, "result_guaranteed": False,
        },
        "channel": {
            "channel_id": CHANNEL_ID, "handle": "@heroverse74",
            # Kept as a compatibility alias. From schema 1.2 onward it means
            # current official observation only; a historical baseline may
            # never be substituted here.
            "observed_subscribers": current_subscribers,
            "baseline_subscribers": subscriber_trajectory["baseline_subscribers"],
            "baseline_observed_at": subscriber_trajectory["baseline_observed_at"],
            "baseline_precedes_goal_start_hours": baseline_precedes_goal_start_hours,
            "current_subscribers": current_subscribers,
            "current_subscribers_observed": current_subscribers_observed,
            "current_subscribers_captured_at": (
                subscriber_measurement["source_captured_at"]
                if current_subscribers_observed
                else None
            ),
            "subscriber_source_kind": subscriber_measurement["subscriber_source_kind"],
            "ypp_valid_watch_hours": None,
            "ypp_status": "UNAVAILABLE",
        },
        "canary": {
            "video_id": VIDEO_ID, "url": f"https://www.youtube.com/watch?v={VIDEO_ID}",
            "published": True, "age_hours": current_age,
            "metrics_captured_at": metrics.get("captured_at"),
            "metrics_snapshot_age_hours": metrics_snapshot_age,
            "public_views": public.get("viewCount"), "public_likes": public.get("likeCount"),
            "public_comments": public.get("commentCount"),
            "owned_views": private.get("views"), "watch_minutes": private.get("estimatedMinutesWatched"),
            "average_view_percentage": private.get("averageViewPercentage"),
            "intro_30s_ratio": private.get("intro30sAudienceWatchRatio"),
            "thumbnail_impressions": private.get("videoThumbnailImpressions"),
            "thumbnail_ctr": private.get("videoThumbnailImpressionsClickRate"),
            "metrics_status": metrics.get("status", "UNAVAILABLE"),
        },
        "reporting": {
            "jobs_status": reporting.get("status", "UNAVAILABLE"),
            "reach_status": reach.get("status", "UNAVAILABLE"),
            "requested_types": reporting.get("requested_report_types") or [],
        },
        "queue": {
            "status": queue.get("status", "UNAVAILABLE"), "counts": queue.get("counts") or {},
            "next_checkpoint_at": next_at,
        },
        "intelligence": {
            "prediction_status": prediction.get("status", "UNAVAILABLE"),
            "prediction_id": prediction.get("prediction_id"),
            "prediction_evaluation_status": prediction_runtime.get("status", "UNAVAILABLE"),
            "prediction_evaluation": prediction_runtime.get("evaluation"),
            "prediction_next_observation_at": prediction_runtime.get("next_observation_at"),
            "diagnosis_status": diagnosis.get("status", "UNAVAILABLE"),
            "dominant_bottleneck": diagnosis_decision.get("dominant_bottleneck", "UNDETERMINED"),
            "treatment_variable": diagnosis_decision.get("treatment_variable", "NONE"),
            "primary_metric": diagnosis_decision.get("primary_metric", "NONE"),
            "experiment_status": experiment.get("status", "UNAVAILABLE"),
            "learning_status": learning_runtime.get("status", "UNAVAILABLE"),
            "learning_classification": learning_runtime.get("classification") or "NO_NEW_EVIDENCE",
            "learning_evaluation": learning_runtime.get("evaluation"),
            "learning_target_video_id": learning_runtime.get("target_video_id"),
            "learning_next_observation_at": learning_runtime.get("next_observation_at"),
        },
        "treatment_execution": {
            "order_status": treatment_order.get("status", "UNAVAILABLE"),
            "order_id": treatment_order.get("order_id"),
            "executor_status": treatment_executor.get("status", "UNAVAILABLE"),
            "job_state": treatment_executor.get("job_state", "UNAVAILABLE"),
            "receipt": treatment_executor.get("receipt"),
            "next_action": treatment_executor.get("next_action", "Wait for an evidence-bound treatment order."),
        },
        "format_scope": {
            "receipt_id": format_scope.get("receipt_id"),
            "status": format_scope.get("status", "UNAVAILABLE"),
            "requested_action": format_scope.get("requested_action", "WAIT"),
            "target_video_id": format_scope.get("target_video_id"),
            "video_ordinal": format_scope.get("video_ordinal"),
            "scope_overlay_id": (format_scope.get("scope_overlay") or {}).get("overlay_id"),
            "scope_overlay_version": (format_scope.get("scope_overlay") or {}).get("version"),
            "gate_counts": scope_counts,
            "schema_valid": format_scope_schema_valid,
            "compilation_authorized": bool(scope_authorized),
            "publication_authorized": False,
        },
        "release_preparation": {
            "work_order_status": release_work_order.get("status", "UNAVAILABLE"),
            "work_order_id": release_work_order.get("work_order_id"),
            "action": release_work_order.get("action", "WAIT"),
            "executor_status": release_preparer.get("status", "UNAVAILABLE"),
            "job_state": release_preparer.get("job_state", "UNAVAILABLE"),
            "receipt": release_preparer.get("receipt"),
            "production_inputs_ready": bool(
                release_preparer.get("status") == "COMPLETED"
                and release_preparer.get("job_state") == "SUCCEEDED"
                and release_preparer.get("receipt")
            ),
            "next_action": release_preparer.get("next_action", "Wait for an evidence-bound preproduction receipt."),
            "publication_authorized": False,
        },
        "package_execution": {
            "executor_status": package_executor.get("status", "UNAVAILABLE"),
            "candidate": package_executor.get("candidate"),
            "quality_evaluation": package_executor.get("quality_evaluation"),
            "release_gate": package_executor.get("release_gate"),
            "publication_receipt": package_executor.get("publication_receipt"),
            "scheduled_for": package_executor.get("scheduled_for"),
            "next_action": package_executor.get("next_action", "Wait for a preregistered title-thumbnail treatment."),
            "public_package_changed": package_executor.get("status") == "COMPLETE_PUBLIC_PACKAGE",
            "technical_cost_brl": 0,
        },
        "media_execution": {
            "executor_status": media_executor.get("status", "UNAVAILABLE"),
            "input_receipt_id": media_executor.get("input_receipt_id"),
            "action": media_executor.get("action", "WAIT"),
            "job_state": media_executor.get("job_state", "UNAVAILABLE"),
            "voice_manifest": media_executor.get("voice_manifest"),
            "render_manifest": media_executor.get("render_manifest"),
            "capacity_preflight_receipt": media_executor.get("capacity_preflight_receipt"),
            "capacity_status": media_executor.get("capacity_status", "UNAVAILABLE"),
            "capacity_observed_free_bytes": media_executor.get("capacity_observed_free_bytes"),
            "capacity_required_free_bytes": media_executor.get("capacity_required_free_bytes"),
            "capacity_headroom_bytes": media_executor.get("capacity_headroom_bytes"),
            "next_action": media_executor.get("next_action", "Wait for verified production inputs."),
            "publication_authorized": False,
        },
        "asset_residency": {
            "status": asset_residency.get("status", "UNAVAILABLE"),
            "audit_id": asset_residency.get("audit_id"),
            "eligible_asset_count": asset_residency.get("eligible_asset_count"),
            "verified_asset_count": asset_residency.get("verified_asset_count"),
            "blocked_asset_ids": asset_residency.get("blocked_asset_ids") or [],
            "total_verified_bytes": asset_residency.get("total_verified_bytes"),
            "total_safe_capacity_ms": asset_residency.get("total_safe_capacity_ms"),
            "selection_authorized": bool(asset_residency.get("selection_authorized")),
            "technical_cost_brl": 0,
        },
        "quality_execution": {
            "executor_status": quality_executor.get("status", "UNAVAILABLE"),
            "media_render_id": quality_executor.get("media_render_id"),
            "job_state": quality_executor.get("job_state", "UNAVAILABLE"),
            "evaluation": quality_executor.get("evaluation"),
            "decision": quality_executor.get("decision", "UNAVAILABLE"),
            "publication_eligible": bool(quality_executor.get("publication_eligible")),
            "next_action": quality_executor.get("next_action", "Wait for a frozen media candidate."),
        },
        "publication_execution": {
            "controller_status": publication_controller.get("status", "UNAVAILABLE"),
            "quality_evaluation_id": publication_controller.get("quality_evaluation_id"),
            "package": publication_controller.get("package"),
            "release": publication_controller.get("release"),
            "release_decision": publication_controller.get("release_decision", "UNAVAILABLE"),
            "publication_receipt": publication_controller.get("publication_receipt"),
            "youtube_video_id": publication_controller.get("youtube_video_id"),
            "privacy_status": publication_controller.get("privacy_status", "none"),
            "next_action": publication_controller.get("next_action", "Wait for all publication prerequisites."),
            "technical_cost_brl": 0,
            "media_spend_brl": 0,
        },
        "phase_transition": {
            "controller_status": phase_transition.get("status", "UNAVAILABLE"),
            "acceptance_report_id": phase_transition.get("acceptance_report_id"),
            "blocking_check_ids": phase_transition.get("blocking_check_ids") or [],
            "transition_receipt": phase_transition.get("transition_receipt"),
            "next_action": phase_transition.get("next_action", "Wait for the complete Phase 6 acceptance gate."),
        },
        "control_cycle": control_cycle_summary,
        "goal_trajectory": {
            "trajectory_id": goal_trajectory["trajectory_id"],
            "subscriber_status": goal_trajectory["subscriber_trajectory"]["status"],
            "current_subscribers": goal_trajectory["subscriber_trajectory"]["current_subscribers"],
            "remaining_subscriber_gap": goal_trajectory["subscriber_trajectory"]["remaining_gap"],
            "required_net_subscribers_per_remaining_day": goal_trajectory["subscriber_trajectory"]["required_net_subscribers_per_remaining_day"],
            "pace_ratio_to_linear_target": goal_trajectory["subscriber_trajectory"]["pace_ratio_to_linear_target"],
            "pace_status": pace_status,
            "pace_anchor_subscribers": pace_anchor_subscribers,
            "pace_anchor_observed_at": pace_anchor_observed_at,
            "pace_comparable_observation_count": pace_comparable_observation_count,
            "subscriber_source_kind": goal_trajectory["measurement"].get("subscriber_source_kind", "UNAVAILABLE"),
            "subscriber_source_id": goal_trajectory["measurement"].get("subscriber_source_id"),
            "subscriber_source_path": goal_trajectory["measurement"].get("subscriber_source_path"),
            "daily_observer_status": goal_trajectory["measurement"].get("daily_observer_status", "UNAVAILABLE"),
            "daily_observer_next_at": goal_trajectory["measurement"].get("daily_observer_next_at"),
            "watch_hours_status": goal_trajectory["watch_hour_trajectory"]["status"],
            "pressure_level": goal_trajectory["decision"]["pressure_level"],
            "selected_action": goal_trajectory["decision"]["selected_action"],
            "blocking_gates": goal_trajectory["decision"]["blocking_gates"],
            "scheduled_at": goal_trajectory["decision"]["scheduled_at"],
            "evidence_path": goal_trajectory_path.relative_to(root).as_posix() if goal_trajectory_path.is_file() else None,
        },
        "release_control": {
            "treatment_compilation_authorized": bool(readiness),
            "treatment_action": (
                "UPDATE_CANARY_PACKAGE"
                if readiness and diagnosis_decision.get("treatment_variable") == "TITLE_THUMBNAIL_PROMISE"
                else ("BUILD_VIDEO_2" if readiness else "NONE")
            ),
            "next_video_authorized": bool(
                readiness and diagnosis_decision.get("treatment_variable") != "TITLE_THUMBNAIL_PROMISE"
            ),
            "metadata_update_authorized": package_executor.get("status") == "COMPLETE_PUBLIC_PACKAGE",
            "authorization_scope": "PRODUCTION_ENTRY_ONLY" if readiness else "NONE",
            "publication_authorized": False,
            "reason": "BASELINE_DIAGNOSIS_AND_PREREGISTRATION_PASS_PRODUCTION_ENTRY_ONLY" if readiness else "WAIT_FOR_24H_OWNED_BASELINE_AND_PREREGISTERED_TREATMENT",
            "controlled_lot_maximum": 3,
        },
        "cost": {"technical_cost_brl": 0, "media_spend_brl": 0, "paid_tools": False},
        "fallbacks": build_coverage(root, active_phase=6),
        "next_action": {
            "action": (
                phase_transition["next_action"]
                if phase_transition.get("status") == "TRANSITIONED"
                else package_executor["next_action"]
                if diagnosis_decision.get("treatment_variable") == "TITLE_THUMBNAIL_PROMISE" and package_executor.get("status") in {"WAITING_FOR_INPUTS", "NOT_DUE", "READY", "COMPLETE_PUBLIC_PACKAGE", "ROLLED_BACK", "BLOCKED", "ERROR"}
                else
                publication_controller["next_action"]
                if publication_controller.get("status") in {"READY", "STAGED_PRIVATE", "BLOCKED", "ERROR"}
                else media_executor["next_action"]
                if post_effect_visual_remediation_required
                else publication_controller["next_action"]
                if publication_controller.get("status") == "COMPLETE_PUBLIC"
                else quality_executor["next_action"]
                if quality_executor.get("status") == "COMPLETED" or paused_content is not None or active_content is not None
                else media_executor["next_action"]
                if media_executor.get("status") == "COMPLETED"
                else release_preparer["next_action"]
                if release_preparer.get("status") == "COMPLETED"
                else treatment_executor["next_action"]
                if treatment_executor.get("status") == "COMPLETED"
                else (
                    "COMPILE_CANARY_PACKAGE_UPDATE"
                    if readiness and diagnosis_decision.get("treatment_variable") == "TITLE_THUMBNAIL_PROMISE"
                    else ("COMPILE_VIDEO_2_CONTROLLED_TREATMENT" if readiness else "COLLECT_OWNED_24H_CHECKPOINT")
                )
            ),
            "scheduled_at": (
                None
                if phase_transition.get("status") == "TRANSITIONED"
                else package_executor.get("scheduled_for")
                if diagnosis_decision.get("treatment_variable") == "TITLE_THUMBNAIL_PROMISE"
                else None
                if post_effect_visual_remediation_required
                else (None if readiness else next_at)
            ),
            "automatic": True,
        },
        "attention_items": critical_attention,
        "evidence": [
            PUBLICATION.as_posix(), metrics_path.relative_to(root).as_posix(), reporting_path.relative_to(root).as_posix(),
            reach_path.relative_to(root).as_posix(), queue_path.relative_to(root).as_posix(),
            prediction_path.relative_to(root).as_posix(), diagnosis_path.relative_to(root).as_posix(),
            prediction_runtime_path.relative_to(root).as_posix(),
            experiment_path.relative_to(root).as_posix(),
            learning_runtime_path.relative_to(root).as_posix(),
            treatment_order_path.relative_to(root).as_posix(), treatment_executor_path.relative_to(root).as_posix(),
            format_scope_path.relative_to(root).as_posix(),
            release_work_order_path.relative_to(root).as_posix(), release_preparer_path.relative_to(root).as_posix(),
            package_executor_path.relative_to(root).as_posix(),
            media_executor_path.relative_to(root).as_posix(),
            asset_residency_path.relative_to(root).as_posix(),
            quality_executor_path.relative_to(root).as_posix(),
            publication_controller_path.relative_to(root).as_posix(),
            phase_transition_path.relative_to(root).as_posix(),
            channel_snapshot_path.relative_to(root).as_posix(),
        ] + ([control_cycle_path.relative_to(root).as_posix()] if control_cycle_summary else []) + ([goal_trajectory_path.relative_to(root).as_posix()] if goal_trajectory_path.is_file() else []) + ([channel_goal_runtime_path.relative_to(root).as_posix()] if channel_goal_runtime_path.is_file() else []) + ([channel_goal_observation_path.relative_to(root).as_posix()] if channel_goal_observation_path.is_file() else []),
        "claim_boundary": [
            "The 30-day target drives cadence and corrective action but does not guarantee YPP approval.",
            "YPP-valid watch hours remain unavailable until an official eligible-progress source is observed.",
            "A diagnosis can authorize production entry only; publication remains false until every release gate passes.",
            "No second release can bypass the 24-hour owned baseline, rights, policy, quality or cost gates.",
            "A LIMITED FormatPack can advance only through the exact versioned scope receipt shown here.",
            "A historical subscriber baseline is never substituted for a current official measurement.",
        ],
    }
    if paused_content is not None:
        value['schema_version'] = '1.9.0' if 'counterevidence' in paused_content else '1.6.0'
        value['paused_content_remediation'] = paused_content
    if active_content is not None:
        value['schema_version'] = '1.8.0' if 'counterevidence' in active_content else '1.7.0'
        value['active_content_remediation'] = active_content
    # A preliminary stage report is not the completed-cycle report. It can be
    # frozen by the cycle producer, but cannot satisfy acceptance/D116. Never
    # borrow the preceding cycle just because its substantive signature agrees.
    value["producer_binding"] = None
    if cycle_raw is not None and goal_raw is not None and not any(
        item is not None for item in (prediction_runtime_override, media_executor_override,
                                     goal_trajectory_override, quality_executor_override)
    ):
        from .phase6_control_cycle import completed_projection_binding
        try:
            binding = completed_projection_binding(
                control_cycle, "sha256:" + hashlib.sha256(cycle_raw).hexdigest(),
                goal_trajectory, "sha256:" + hashlib.sha256(goal_raw).hexdigest())
            if _parse(control_cycle["cycle_completed_at"]) <= now:
                value["producer_binding"] = binding
        except PermissionError:
            pass  # Incomplete projection is explicit null, never historical PASS.
    for source, raw in ((control_cycle_path, cycle_raw), (goal_trajectory_path, goal_raw)):
        if raw is not None and source.read_bytes() != raw:
            raise PermissionError("CURRENT_CHAIN_SOURCE_CHANGED_DURING_REPORT")
    schema = _read(root / "schemas/phase6_executive_status.schema.json")
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    return value


def _markdown(value: dict[str, Any]) -> str:
    canary, intelligence, release = value["canary"], value["intelligence"], value["release_control"]
    treatment = value["treatment_execution"]
    scope = value["format_scope"]
    preparation = value["release_preparation"]
    package = value["package_execution"]
    media = value["media_execution"]
    residency = value["asset_residency"]
    quality = value["quality_execution"]
    publication = value["publication_execution"]
    transition = value["phase_transition"]
    control_cycle = value["control_cycle"]
    trajectory = value["goal_trajectory"]
    channel = value["channel"]
    return "\n".join([
        "# HeroVerse — status executivo da Fase 6", "",
        f"Atualizado em: `{value['captured_at']}`", "",
        f"Estado: **{value['status']}**", "",
        f"Janela: {value['goal_window']['elapsed_hours']:.2f} h decorridas; {value['goal_window']['remaining_hours']:.2f} h restantes.", "",
        "## Canário público", "",
        f"- Vídeo: https://www.youtube.com/watch?v={canary['video_id']}",
        f"- Idade atual: `{canary['age_hours']}` h; views públicas: `{canary['public_views']}`; likes: `{canary['public_likes']}`; comentários: `{canary['public_comments']}`.",
        f"- Snapshot de métricas: `{canary['metrics_captured_at']}`; idade do vídeo no snapshot: `{canary['metrics_snapshot_age_hours']}` h.",
        f"- Métricas próprias: `{canary['metrics_status']}`; retenção 30 s: `{canary['intro_30s_ratio']}`; impressões: `{canary['thumbnail_impressions']}`; CTR: `{canary['thumbnail_ctr']}`.", "",
        "## Controle", "",
        f"- Inscritos: referência histórica `{channel['baseline_subscribers']}` em `{channel['baseline_observed_at']}` ({channel['baseline_precedes_goal_start_hours']} h antes da largada); atual `{channel['current_subscribers']}`; observado: `{channel['current_subscribers_observed']}`; fonte: `{channel['subscriber_source_kind']}` em `{channel['current_subscribers_captured_at']}`.",
        f"- Reporting: `{value['reporting']['jobs_status']}`; reach: `{value['reporting']['reach_status']}`.",
        f"- Fila: `{value['queue']['status']}`; próximo checkpoint: `{value['queue']['next_checkpoint_at']}`.",
        f"- Previsão: `{intelligence['prediction_status']}`; avaliação: `{intelligence['prediction_evaluation_status']}` / `{intelligence['prediction_evaluation']}`; horizonte: `{intelligence['prediction_next_observation_at']}`.",
        f"- Diagnóstico: `{intelligence['diagnosis_status']}` / `{intelligence['dominant_bottleneck']}`; experimento: `{intelligence['experiment_status']}`.",
        f"- Variável de tratamento: `{intelligence['treatment_variable']}`; métrica primária: `{intelligence['primary_metric']}`; aprendizado: `{intelligence['learning_status']}` / `{intelligence['learning_classification']}`.",
        f"- Tratamento observado: `{intelligence['learning_target_video_id']}`; avaliação: `{intelligence['learning_evaluation']}`; próxima observação: `{intelligence['learning_next_observation_at']}`.",
        f"- Ordem de tratamento: `{treatment['order_status']}` / `{treatment['order_id']}`; executor: `{treatment['executor_status']}` / `{treatment['job_state']}`.",
        f"- Escopo LIMITED: `{scope['status']}` / `{scope['receipt_id']}`; schema: `{scope['schema_valid']}`; ação: `{scope['requested_action']}`; gates PASS/WAITING/BLOCKED: `{scope['gate_counts']['PASS']}/{scope['gate_counts']['WAITING']}/{scope['gate_counts']['BLOCKED']}`.",
        f"- Preparação pós-pré-produção: `{preparation['work_order_status']}` / `{preparation['executor_status']}` / `{preparation['job_state']}`; inputs prontos: `{preparation['production_inputs_ready']}`; próxima: `{preparation['next_action']}`.",
        f"- Tratamento público de embalagem: `{package['executor_status']}`; candidato: `{package['candidate']}`; mudança confirmada: `{package['public_package_changed']}`; agendado: `{package['scheduled_for']}`; próxima: `{package['next_action']}`.",
        f"- Execução de mídia: `{media['executor_status']}` / `{media['job_state']}`; voz: `{media['voice_manifest']}`; render: `{media['render_manifest']}`; próxima: `{media['next_action']}`.",
        f"- Capacidade local: `{media['capacity_status']}`; livre: `{media['capacity_observed_free_bytes']}` bytes; exigido: `{media['capacity_required_free_bytes']}`; margem: `{media['capacity_headroom_bytes']}`; receipt: `{media['capacity_preflight_receipt']}`.",
        f"- Residência dos ativos: `{residency['status']}`; verificados: `{residency['verified_asset_count']}/{residency['eligible_asset_count']}`; bytes locais: `{residency['total_verified_bytes']}`; capacidade segura: `{residency['total_safe_capacity_ms']}` ms; bloqueados: `{', '.join(residency['blocked_asset_ids']) or 'nenhum'}`.",
        f"- Qualidade independente: `{quality['executor_status']}` / `{quality['job_state']}` / `{quality['decision']}`; elegível: `{quality['publication_eligible']}`; próxima: `{quality['next_action']}`.",
        f"- Publicação Vídeo 2: `{publication['controller_status']}` / `{publication['release_decision']}`; YouTube ID: `{publication['youtube_video_id']}`; privacidade: `{publication['privacy_status']}`; próxima: `{publication['next_action']}`.",
        f"- Transição Fase 6 → 7: `{transition['controller_status']}`; bloqueios: `{', '.join(transition['blocking_check_ids']) or 'nenhum'}`; receipt: `{transition['transition_receipt']}`; próxima: `{transition['next_action']}`.",
        f"- Trajetória 30 dias: `{trajectory['subscriber_status']}`; inscritos atuais: `{trajectory['current_subscribers']}`; gap: `{trajectory['remaining_subscriber_gap']}`; exigidos/dia restante: `{trajectory['required_net_subscribers_per_remaining_day']}`; ritmo: `{trajectory['pace_status']}` com `{trajectory['pace_comparable_observation_count']}` observação(ões) oficial(is), âncora `{trajectory['pace_anchor_subscribers']}` em `{trajectory['pace_anchor_observed_at']}` e razão `{trajectory['pace_ratio_to_linear_target']}`.",
        f"- Fonte diária de inscritos: `{trajectory['subscriber_source_kind']}` / `{trajectory['subscriber_source_id']}`; observador: `{trajectory['daily_observer_status']}`; próxima coleta: `{trajectory['daily_observer_next_at']}`.",
        f"- Pressão operacional: `{trajectory['pressure_level']}`; próxima ação permitida: `{trajectory['selected_action']}` em `{trajectory['scheduled_at']}`; horas YPP: `{trajectory['watch_hours_status']}`.",
        *([
            f"- Impedimentos da prioridade: `{', '.join(trajectory['blocking_gates']) or 'nenhum'}`; prioridade não autoriza render nem publicação."
        ] if "blocking_gates" in trajectory else []),
        (
            f"- Ciclo integral: `{control_cycle['decision']}` / `{control_cycle['change_class']}`; "
            f"estágios no ciclo: `{control_cycle['stage_count']}/12`; schemas: `{control_cycle['all_schemas_valid']}`; "
            f"execução integral: `{control_cycle['all_stages_executed_in_cycle']}`; bloqueios: "
            f"`{', '.join(control_cycle['blockers']) or 'nenhum'}`; concluído: `{control_cycle['cycle_completed_at']}`."
            if control_cycle
            else "- Ciclo integral: `UNAVAILABLE` — o primeiro receipt autoritativo ainda não foi materializado."
        ),
        f"- Entrada do próximo vídeo em produção: `{release['next_video_authorized']}` (`{release['authorization_scope']}`); publicação: `{release['publication_authorized']}` — {release['reason']}.",
        f"- Tratamento autorizado para compilação: `{release['treatment_compilation_authorized']}` / `{release['treatment_action']}`; atualização pública de metadados: `{release['metadata_update_authorized']}`.",
        f"- Próxima ação: `{value['next_action']['action']}` em `{value['next_action']['scheduled_at']}`.", "",
        *(markdown_coverage(value["fallbacks"]) if "fallbacks" in value else []),
        "## Custo e limite", "",
        "- Custo técnico: **R$ 0,00**; mídia: **R$ 0,00**; ferramentas pagas: **não**.",
        "- A meta de 30 dias governa a execução, mas o status não apresenta monetização, views ou aprovação do YPP como garantia.", "",
    ])


EXECUTIVE_ATOMIC_WRITER_VERSION = "phase6-executive-atomic-writer-v2"


def _atomic_write_utf8(path: Path, content: str) -> None:
    """Compatibility wrapper for the versioned executive writer contract."""

    atomic_write_utf8(path, content)


def materialize(root: Path = ROOT, *, captured_at: str | None = None,
                package_relative: Path | None = None, current_bindings: dict[str, Any] | None = None,
                expected_release_hash: str | None = None) -> tuple[Path, Path]:
    root = root.resolve()
    value = build_status(root, captured_at=captured_at,package_relative=package_relative,
                         current_bindings=current_bindings,expected_release_hash=expected_release_hash)
    if value['schema_version'] == '2.0.0':
        directory = root/Path(package_relative)/'intelligence'
        json_path,md_path = directory/'executive-status.json',directory/'EXECUTIVE_STATUS.md'
        rows=['# Operação atual — áudio original', '',
            f"Estado: {value['status']}",f"Candidata observada: {value['source_candidate_sha256']}",
            '', '## Entrega atual']
        rows.extend(f'- {key}: {item}' for key,item in value['current_delivery'].items())
        rows.extend(['','## Pendências',*['- '+item for item in value['attention_items']],
                     '', '## Limites',*['- '+item for item in value['claim_boundary']]])
        _atomic_write_utf8(json_path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
        _atomic_write_utf8(md_path,'\n'.join(rows)+'\n')
        return json_path,md_path
    json_path = root / BASE / "executive-status.json"
    md_path = root / BASE / "EXECUTIVE_STATUS.md"
    # Finish both payloads before replacing either output. Each file is atomic,
    # not the pair: a later MD failure remains explicit and preserves the alert.
    payloads = (
        (json_path, json.dumps(value, ensure_ascii=False, indent=2) + "\n"),
        (md_path, _markdown(value)),
    )
    for path, content in payloads:
        _atomic_write_utf8(path, content)
    # A previously recorded reporting failure is no longer actionable after a
    # complete, schema-valid materialization. Archive the exact bytes before
    # clearing the current-alert path so failure evidence remains auditable.
    stale_error = root / BASE / "executive-status-error.json"
    if stale_error.exists():
        content = stale_error.read_bytes()
        digest = hashlib.sha256(content).hexdigest()[:16]
        archive = root / BASE / "errors/archive" / f"executive-status-error-{digest}.json"
        archive.parent.mkdir(parents=True, exist_ok=True)
        if archive.exists() and archive.read_bytes() != content:
            raise FileExistsError(f"immutable Phase 6 error archive collision: {archive}")
        if not archive.exists():
            archive.write_bytes(content)
        stale_error.unlink()
    return json_path, md_path


if __name__ == "__main__":
    for artifact in materialize(ROOT):
        print(artifact)
