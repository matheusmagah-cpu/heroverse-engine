from __future__ import annotations

import json
import os
import hashlib
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from .atomic_io import atomic_write_utf8
from .phase6_intelligence import evaluate_prediction
from .phase6_pilot import materialize_video_live
from .queue_phase6 import TransactionalQueue
from .zero_cost_guard import evaluate_zero_cost


ROOT = Path(__file__).resolve().parents[1]
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "iK_5edYQtx8"
OPERATION_ID = "heroverse-phase6-controlled-longform-v1"
PREDICTIONS = Path("output/operations/phase6/intelligence/predictions")
EVALUATIONS = Path("output/operations/phase6/intelligence/prediction-evaluations")
OUTCOME_HISTORY = Path("output/operations/phase6/intelligence/prediction-outcomes")
RUNTIME = Path("output/operations/phase6/intelligence/prediction-runtime.json")
PUBLICATION_RECEIPT = Path(
    "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
)
TASK_TYPE = "PREDICTION_OUTCOME_CHECKPOINT"
PREFLIGHT_LATEST = Path("output/operations/zero-cost/phase6-prediction-outcome-preflight.json")
PREFLIGHT_HISTORY = Path("output/operations/zero-cost/phase6-prediction-outcome-preflights")
QUOTA_RECHECK_INTERVAL = timedelta(minutes=5)
OUTCOME_SCHEMA = "own_channel_performance_snapshot.schema.json"
OUTCOME_BINDING_SCHEMA = "phase6_prediction_outcome_binding.schema.json"


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _validate(root: Path, schema_name: str, value: dict[str, Any]) -> None:
    schema = _read(root / "schemas" / schema_name)
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)


def _write_atomic(path: Path, value: dict[str, Any]) -> None:
    atomic_write_utf8(path, _canonical(value).decode("utf-8"))


def _write_immutable(path: Path, value: dict[str, Any]) -> None:
    payload = _canonical(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable prediction evaluation collision: {path.name}")
        return
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(payload)
    temporary.replace(path)


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    """Create a job-owned snapshot without ever replacing prior bytes."""

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable prediction outcome collision: {path.name}")
        return
    try:
        with path.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable prediction outcome collision: {path.name}")


def _relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _job_outcome_path(root: Path, job_id: str) -> Path:
    workspace = root.resolve()
    base = (workspace / OUTCOME_HISTORY).resolve()
    try:
        base.relative_to(workspace)
    except ValueError as exc:
        raise PermissionError("prediction outcome history escapes the workspace") from exc
    job_directory = (base / job_id).resolve()
    if job_directory.parent != base:
        raise PermissionError("prediction outcome job directory escapes its history root")
    target = job_directory / "snapshot.json"
    if target.is_symlink():
        raise PermissionError("prediction outcome snapshot cannot be a symbolic link")
    return target


def _validated_outcome_payload(
    root: Path,
    *,
    prediction: dict[str, Any],
    payload: bytes,
) -> tuple[dict[str, Any], str]:
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    snapshot = json.loads(payload.decode("utf-8-sig"))
    _validate(root, OUTCOME_SCHEMA, snapshot)
    if snapshot.get("channel_id") != CHANNEL_ID or snapshot.get("video_id") != VIDEO_ID:
        raise PermissionError("OUTCOME_SNAPSHOT_IDENTITY_MISMATCH")
    if _parse(snapshot["captured_at"]) < _parse(prediction["horizon"]["ends_at"]):
        raise RuntimeError("OUTCOME_SNAPSHOT_PRECEDES_PREDICTION_HORIZON")
    if snapshot.get("status") == "FAILED":
        raise RuntimeError("OUTCOME_SNAPSHOT_COLLECTION_FAILED")
    outcome = snapshot.get("public_metrics", {}).get("viewCount")
    if not isinstance(outcome, int) or isinstance(outcome, bool) or outcome < 0:
        raise RuntimeError("PUBLIC_VIEW_OUTCOME_UNAVAILABLE")
    return snapshot, digest


def _outcome_binding(
    root: Path,
    *,
    job_id: str,
    prediction: dict[str, Any],
    path: Path,
    snapshot: dict[str, Any],
    digest: str,
) -> dict[str, Any]:
    value = {
        "schema_version": "1.0.0",
        "operation": "phase6_prediction_outcome_checkpoint",
        "job_id": job_id,
        "prediction_id": prediction["prediction_id"],
        "channel_id": CHANNEL_ID,
        "video_id": VIDEO_ID,
        "horizon_ends_at": prediction["horizon"]["ends_at"],
        "snapshot": {
            "path": _relative(root, path),
            "sha256": digest,
            "schema": OUTCOME_SCHEMA,
            "schema_version": snapshot["schema_version"],
            "snapshot_id": snapshot["snapshot_id"],
            "captured_at": snapshot["captured_at"],
        },
    }
    _validate(root, OUTCOME_BINDING_SCHEMA, value)
    return value


def _freeze_outcome_snapshot(
    root: Path,
    *,
    job_id: str,
    prediction: dict[str, Any],
    source: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    payload = source.resolve().read_bytes()
    snapshot, digest = _validated_outcome_payload(root, prediction=prediction, payload=payload)
    target = _job_outcome_path(root, job_id)
    _write_immutable_bytes(target, payload)
    binding = _outcome_binding(
        root,
        job_id=job_id,
        prediction=prediction,
        path=target,
        snapshot=snapshot,
        digest=digest,
    )
    return binding, snapshot


def _validate_checkpointed_outcome(
    root: Path,
    *,
    job_id: str,
    prediction: dict[str, Any],
    checkpoint: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    binding = checkpoint.get("outcome_binding")
    if not isinstance(binding, dict):
        raise PermissionError("checkpointed outcome binding is missing")
    _validate(root, OUTCOME_BINDING_SCHEMA, binding)
    expected_path = _job_outcome_path(root, job_id)
    snapshot_binding = binding["snapshot"]
    path = (root / snapshot_binding["path"]).resolve()
    if path != expected_path or path.parent != (root / OUTCOME_HISTORY / job_id).resolve():
        raise PermissionError("checkpointed outcome is outside the exact prediction job")
    if not (
        binding.get("job_id") == job_id
        and binding.get("operation") == "phase6_prediction_outcome_checkpoint"
        and binding.get("prediction_id") == prediction.get("prediction_id")
        and binding.get("channel_id") == CHANNEL_ID
        and binding.get("video_id") == VIDEO_ID
        and binding.get("horizon_ends_at") == prediction.get("horizon", {}).get("ends_at")
        and checkpoint.get("outcome_snapshot") == snapshot_binding.get("path")
        and checkpoint.get("outcome_snapshot_hash") == snapshot_binding.get("sha256")
        and checkpoint.get("outcome_snapshot_schema") == OUTCOME_SCHEMA
    ):
        raise PermissionError("checkpointed outcome identity is divergent")
    payload = path.read_bytes()
    snapshot, digest = _validated_outcome_payload(root, prediction=prediction, payload=payload)
    if digest != snapshot_binding["sha256"]:
        raise PermissionError("checkpointed outcome hash mismatch")
    recomputed = _outcome_binding(
        root,
        job_id=job_id,
        prediction=prediction,
        path=path,
        snapshot=snapshot,
        digest=digest,
    )
    if recomputed != binding:
        raise PermissionError("checkpointed outcome binding does not match frozen bytes")
    return binding, snapshot


def _observed_youtube_usage(root: Path) -> dict[str, int] | None:
    from .phase6_quota import effective_observation_quota_usage

    return effective_observation_quota_usage(root)


def _materialize_quota_preflight(
    root: Path,
    *,
    job_id: str,
    observed_usage: dict[str, int] | None,
    current: datetime,
) -> tuple[dict[str, Any], str, str]:
    value = evaluate_zero_cost(
        root,
        operation="phase6_prediction_outcome_checkpoint",
        observed_usage=observed_usage,
        created_at=_stamp(current),
    )
    payload = _canonical(value)
    digest = hashlib.sha256(payload).hexdigest()
    history = root / PREFLIGHT_HISTORY / job_id / f"preflight-{digest[:24]}.json"
    if history.is_file() and history.read_bytes() != payload:
        raise PermissionError("immutable prediction quota-preflight collision")
    if not history.is_file():
        history.parent.mkdir(parents=True, exist_ok=True)
        temporary = history.with_suffix(history.suffix + ".tmp")
        temporary.write_bytes(payload)
        temporary.replace(history)
    _write_atomic(root / PREFLIGHT_LATEST, value)
    return value, _relative(root, history), "sha256:" + digest


def _validate_checkpointed_quota_preflight(
    root: Path,
    *,
    job_id: str,
    checkpoint: dict[str, Any],
) -> tuple[str, str]:
    reference = checkpoint.get("quota_preflight")
    expected_hash = checkpoint.get("quota_preflight_hash")
    if not (
        isinstance(reference, str)
        and isinstance(expected_hash, str)
        and expected_hash.startswith("sha256:")
        and len(expected_hash) == 71
    ):
        raise PermissionError("checkpointed outcome is missing its quota-preflight identity")
    path = (root / reference).resolve()
    expected_parent = (root / PREFLIGHT_HISTORY / job_id).resolve()
    if path.parent != expected_parent or path.name != f"preflight-{expected_hash.split(':', 1)[1][:24]}.json":
        raise PermissionError("checkpointed quota-preflight path is outside the exact job history")
    payload = path.read_bytes()
    observed_hash = "sha256:" + hashlib.sha256(payload).hexdigest()
    if observed_hash != expected_hash:
        raise PermissionError("checkpointed quota-preflight hash mismatch")
    value = json.loads(payload.decode("utf-8-sig"))
    _validate(root, "zero_cost_guard.schema.json", value)
    general = next(
        (item for item in value.get("resources", []) if item.get("resource_id") == "youtube-general-units-daily"),
        None,
    )
    if not (
        value.get("operation") == "phase6_prediction_outcome_checkpoint"
        and value.get("execution_permitted") is True
        and value.get("quota_status") == "PASS"
        and value.get("technical_cost_brl") == 0
        and isinstance(general, dict)
        and general.get("quota_reserved") == 2
        and general.get("preventive_floor") == 12
    ):
        raise PermissionError("checkpointed quota-preflight did not authorize the exact outcome collection")
    return reference, expected_hash


def _evaluation_path(root: Path, prediction: dict[str, Any]) -> Path:
    horizon_key = _parse(prediction["horizon"]["ends_at"]).strftime("%Y%m%dT%H%M%SZ")
    return root / EVALUATIONS / f"evaluation-{prediction['prediction_id']}-{horizon_key}.json"


def _validate_evaluation_binding(
    prediction: dict[str, Any],
    evaluation: dict[str, Any],
    snapshot: dict[str, Any],
) -> None:
    outcome = evaluation.get("outcome") or {}
    if not (
        evaluation.get("prediction_id") == prediction.get("prediction_id")
        and evaluation.get("out_of_sample") is True
        and outcome.get("source_id") == snapshot.get("snapshot_id")
        and outcome.get("observed_at") == snapshot.get("captured_at")
        and outcome.get("value") == snapshot.get("public_metrics", {}).get("viewCount")
    ):
        raise PermissionError("prediction evaluation is not bound to the frozen outcome")


def _status(
    root: Path,
    *,
    status: str,
    prediction: dict[str, Any] | None,
    now: datetime,
    job: dict[str, Any] | None = None,
    outcome_snapshot: str | None = None,
    outcome_snapshot_hash: str | None = None,
    outcome_snapshot_schema: str | None = None,
    evaluation: str | None = None,
    error: str | None = None,
    next_observation_at: str | None = None,
) -> dict[str, Any]:
    horizon = prediction.get("horizon", {}).get("ends_at") if prediction else None
    checkpoint = (job or {}).get("checkpoint") or {}
    binding_snapshot = (checkpoint.get("outcome_binding") or {}).get("snapshot") or {}
    outcome_snapshot = outcome_snapshot or checkpoint.get("outcome_snapshot")
    outcome_snapshot_hash = outcome_snapshot_hash or checkpoint.get("outcome_snapshot_hash")
    outcome_snapshot_schema = outcome_snapshot_schema or checkpoint.get("outcome_snapshot_schema")
    if outcome_snapshot is None and isinstance(binding_snapshot, dict):
        outcome_snapshot = binding_snapshot.get("path")
    if outcome_snapshot_hash is None and isinstance(binding_snapshot, dict):
        outcome_snapshot_hash = binding_snapshot.get("sha256")
    if outcome_snapshot_schema is None and isinstance(binding_snapshot, dict):
        outcome_snapshot_schema = binding_snapshot.get("schema")
    value = {
        "schema_version": "1.1.0",
        "observer_id": "heroverse-phase6-prediction-outcome-v1",
        "phase": 6,
        "channel_id": CHANNEL_ID,
        "status": status,
        "prediction_id": prediction.get("prediction_id") if prediction else None,
        "prediction_status": prediction.get("status") if prediction else None,
        "horizon_ends_at": horizon,
        "next_observation_at": (
            next_observation_at
            if next_observation_at is not None
            else (horizon if status == "WAITING_FOR_HORIZON" else None)
        ),
        "job_id": job.get("job_id") if job else None,
        "job_state": job.get("state") if job else "NOT_CREATED",
        "outcome_snapshot": outcome_snapshot,
        "outcome_snapshot_hash": outcome_snapshot_hash,
        "outcome_snapshot_schema": outcome_snapshot_schema,
        "evaluation": evaluation,
        "error": error,
        "technical_cost_brl": 0,
        "updated_at": _stamp(now),
    }
    _validate(root, "phase6_prediction_runtime.schema.json", value)
    _write_atomic(root / RUNTIME, value)
    return value


def _predictions(root: Path) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for path in sorted((root / PREDICTIONS).glob("prediction-*.json")):
        value = _read(path)
        _validate(root, "prediction_record.schema.json", value)
        if value.get("channel_id") == CHANNEL_ID and value.get("video_id") == VIDEO_ID:
            values.append(value)
    return sorted(values, key=lambda value: (_parse(value["horizon"]["ends_at"]), value["prediction_id"]))


def run_prediction_observer(
    root: Path = ROOT,
    *,
    token_path: Path | None = None,
    observed_usage: dict[str, int] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Evaluate preregistered predictions once their exact horizon is due.

    The queue owns retry/idempotency. A withheld prediction is still evaluated
    against a real outcome, but it never becomes a fabricated forecast.
    """

    root = root.resolve()
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    predictions = _predictions(root)
    if not predictions:
        return _status(root, status="NO_PREDICTION", prediction=None, now=current)

    pending: tuple[dict[str, Any], Path] | None = None
    latest_complete: tuple[dict[str, Any], Path, dict[str, Any]] | None = None
    for prediction in predictions:
        evaluation_path = _evaluation_path(root, prediction)
        if evaluation_path.is_file():
            evaluation = _read(evaluation_path)
            _validate(root, "prediction_evaluation.schema.json", evaluation)
            latest_complete = (prediction, evaluation_path, evaluation)
        elif pending is None:
            pending = (prediction, evaluation_path)

    if pending is None and latest_complete is not None:
        prediction, evaluation_path, evaluation = latest_complete
        key = f"phase6-prediction-outcome:{prediction['prediction_id']}:{prediction['horizon']['ends_at']}"
        queue = TransactionalQueue(root)
        job = queue.get_by_idempotency_key(key)
        try:
            if job is None or job.get("state") != "SUCCEEDED":
                raise PermissionError("prediction evaluation has no succeeded job")
            _validate_checkpointed_quota_preflight(
                root,
                job_id=job["job_id"],
                checkpoint=job.get("checkpoint") or {},
            )
            _, snapshot = _validate_checkpointed_outcome(
                root,
                job_id=job["job_id"],
                prediction=prediction,
                checkpoint=job.get("checkpoint") or {},
            )
            _validate_evaluation_binding(prediction, evaluation, snapshot)
        except Exception as exc:
            return _status(
                root,
                status="ERROR",
                prediction=prediction,
                now=current,
                job=job,
                evaluation=_relative(root, evaluation_path),
                error=f"PREDICTION_OUTCOME_BINDING_INVALID:{type(exc).__name__}:{exc}",
            )
        return _status(
            root,
            status=evaluation["status"],
            prediction=prediction,
            now=current,
            job=job,
            outcome_snapshot=(job or {}).get("checkpoint", {}).get("outcome_snapshot"),
            evaluation=_relative(root, evaluation_path),
        )

    assert pending is not None
    prediction, evaluation_path = pending
    horizon = _parse(prediction["horizon"]["ends_at"])
    key = f"phase6-prediction-outcome:{prediction['prediction_id']}:{prediction['horizon']['ends_at']}"
    queue = TransactionalQueue(root)
    job = queue.enqueue(
        idempotency_key=key,
        operation_id=OPERATION_ID,
        channel_id=CHANNEL_ID,
        task_type=TASK_TYPE,
        payload={
            "prediction_id": prediction["prediction_id"],
            "video_id": VIDEO_ID,
            "horizon_ends_at": prediction["horizon"]["ends_at"],
        },
        max_attempts=3,
        available_at=horizon,
        now=current,
    )
    queue.materialize_snapshot(captured_at=current)

    if current < horizon:
        return _status(root, status="WAITING_FOR_HORIZON", prediction=prediction, now=current, job=job)
    if job["state"] == "SUCCEEDED":
        evaluation_ref = job.get("checkpoint", {}).get("evaluation")
        if not isinstance(evaluation_ref, str) or not (root / evaluation_ref).is_file():
            return _status(root, status="ERROR", prediction=prediction, now=current, job=job, error="SUCCEEDED_JOB_MISSING_EVALUATION")
        try:
            evaluation = _read(root / evaluation_ref)
            _validate(root, "prediction_evaluation.schema.json", evaluation)
            _validate_checkpointed_quota_preflight(
                root,
                job_id=job["job_id"],
                checkpoint=job.get("checkpoint") or {},
            )
            _, snapshot = _validate_checkpointed_outcome(
                root,
                job_id=job["job_id"],
                prediction=prediction,
                checkpoint=job.get("checkpoint") or {},
            )
            _validate_evaluation_binding(prediction, evaluation, snapshot)
        except Exception as exc:
            return _status(
                root,
                status="ERROR",
                prediction=prediction,
                now=current,
                job=job,
                evaluation=evaluation_ref,
                error=f"PREDICTION_OUTCOME_BINDING_INVALID:{type(exc).__name__}:{exc}",
            )
        return _status(
            root,
            status=evaluation["status"],
            prediction=prediction,
            now=current,
            job=job,
            outcome_snapshot=job.get("checkpoint", {}).get("outcome_snapshot"),
            evaluation=evaluation_ref,
        )
    if job["state"] == "DEAD_LETTER":
        return _status(root, status="ERROR", prediction=prediction, now=current, job=job, error=job.get("last_error") or "PREDICTION_JOB_DEAD_LETTER")
    if job["state"] == "RETRY_WAIT" and current < _parse(job["available_at"]):
        return _status(
            root,
            status="WAITING_FOR_RETRY",
            prediction=prediction,
            now=current,
            job=job,
            error=job.get("last_error"),
            next_observation_at=job["available_at"],
        )
    if job["state"] == "LEASED":
        return _status(
            root,
            status="IN_PROGRESS",
            prediction=prediction,
            now=current,
            job=job,
            outcome_snapshot=job.get("checkpoint", {}).get("outcome_snapshot"),
            next_observation_at=job.get("lease_until"),
        )
    checkpoint = job.get("checkpoint") or {}
    frozen_path = _job_outcome_path(root, job["job_id"])
    checkpointed_snapshot = isinstance(checkpoint.get("outcome_binding"), dict)
    orphaned_frozen_snapshot = frozen_path.is_file() and not checkpointed_snapshot
    unbound_snapshot_reference = any(
        checkpoint.get(name) is not None
        for name in ("outcome_snapshot", "outcome_snapshot_hash", "outcome_snapshot_schema")
    ) and not checkpointed_snapshot
    if unbound_snapshot_reference:
        return _status(
            root,
            status="ERROR",
            prediction=prediction,
            now=current,
            job=job,
            error="PREDICTION_OUTCOME_CHECKPOINT_INVALID:UNBOUND_SNAPSHOT_REFERENCE",
        )
    recovered_binding: dict[str, Any] | None = None
    preflight_ref = checkpoint.get("quota_preflight")
    preflight_hash = checkpoint.get("quota_preflight_hash")
    if checkpointed_snapshot or orphaned_frozen_snapshot:
        try:
            preflight_ref, preflight_hash = _validate_checkpointed_quota_preflight(
                root,
                job_id=job["job_id"],
                checkpoint=checkpoint,
            )
            if checkpointed_snapshot:
                _validate_checkpointed_outcome(
                    root,
                    job_id=job["job_id"],
                    prediction=prediction,
                    checkpoint=checkpoint,
                )
            else:
                recovered_binding, _ = _freeze_outcome_snapshot(
                    root,
                    job_id=job["job_id"],
                    prediction=prediction,
                    source=frozen_path,
                )
        except Exception as exc:
            return _status(
                root,
                status="ERROR",
                prediction=prediction,
                now=current,
                job=job,
                error=f"PREDICTION_OUTCOME_CHECKPOINT_INVALID:{type(exc).__name__}:{exc}",
            )
    else:
        if token_path is None or not token_path.is_file():
            return _status(root, status="BLOCKED_CREDENTIAL", prediction=prediction, now=current, job=job, error="EXTERNAL_RUNTIME_TOKEN_UNAVAILABLE")
        preflight, preflight_ref, preflight_hash = _materialize_quota_preflight(
            root,
            job_id=job["job_id"],
            observed_usage=observed_usage,
            current=current,
        )
        if preflight.get("execution_permitted") is not True:
            retry_at = current + QUOTA_RECHECK_INTERVAL
            job = queue.defer(
                job["job_id"],
                available_at=retry_at,
                reason="PREDICTION_OUTCOME_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
                checkpoint={
                    **checkpoint,
                    "quota_preflight": preflight_ref,
                    "quota_preflight_hash": preflight_hash,
                },
                now=current,
            )
            queue.materialize_snapshot(captured_at=current)
            return _status(
                root,
                status="WAITING_FOR_RETRY",
                prediction=prediction,
                now=current,
                job=job,
                error="PREDICTION_OUTCOME_ZERO_COST_OR_FREE_QUOTA_BLOCKED",
                next_observation_at=_stamp(retry_at),
            )

    claimed = queue.claim_job(
        job["job_id"],
        worker_id=f"gestor-central-prediction-{os.getpid()}",
        expected_task_type=TASK_TYPE,
        lease_seconds=600,
        now=current,
    )
    if claimed is None or claimed["job_id"] != job["job_id"]:
        refreshed = queue.get_by_idempotency_key(key) or job
        return _status(root, status="ERROR", prediction=prediction, now=current, job=refreshed, error="PREDICTION_JOB_NOT_CLAIMABLE")

    try:
        checkpoint = claimed.get("checkpoint") or {}
        if not checkpoint.get("quota_preflight"):
            checkpoint = {
                **checkpoint,
                "quota_preflight": preflight_ref,
                "quota_preflight_hash": preflight_hash,
            }
            claimed = queue.checkpoint(
                claimed["job_id"],
                worker_id=claimed["lease_owner"],
                value=checkpoint,
                now=current,
            )
        if checkpointed_snapshot:
            binding, snapshot = _validate_checkpointed_outcome(
                root,
                job_id=claimed["job_id"],
                prediction=prediction,
                checkpoint=claimed.get("checkpoint") or {},
            )
        elif recovered_binding is not None:
            binding = recovered_binding
            snapshot_fields = binding["snapshot"]
            claimed = queue.checkpoint(
                claimed["job_id"],
                worker_id=claimed["lease_owner"],
                value={
                    **(claimed.get("checkpoint") or {}),
                    "outcome_snapshot": snapshot_fields["path"],
                    "outcome_snapshot_hash": snapshot_fields["sha256"],
                    "outcome_snapshot_schema": snapshot_fields["schema"],
                    "outcome_binding": binding,
                },
                now=current,
            )
            binding, snapshot = _validate_checkpointed_outcome(
                root,
                job_id=claimed["job_id"],
                prediction=prediction,
                checkpoint=claimed.get("checkpoint") or {},
            )
        else:
            assert token_path is not None
            source_snapshot = materialize_video_live(
                root,
                token_path=token_path.resolve(),
                video_id=VIDEO_ID,
                publication_receipt=PUBLICATION_RECEIPT,
                captured_at=_stamp(current),
                immutable_destination=_job_outcome_path(root, claimed["job_id"]),
            )
            binding, snapshot = _freeze_outcome_snapshot(
                root,
                job_id=claimed["job_id"],
                prediction=prediction,
                source=source_snapshot,
            )
            snapshot_fields = binding["snapshot"]
            claimed = queue.checkpoint(
                claimed["job_id"],
                worker_id=claimed["lease_owner"],
                value={
                    **(claimed.get("checkpoint") or {}),
                    "outcome_snapshot": snapshot_fields["path"],
                    "outcome_snapshot_hash": snapshot_fields["sha256"],
                    "outcome_snapshot_schema": snapshot_fields["schema"],
                    "outcome_binding": binding,
                },
                now=current,
            )
            binding, snapshot = _validate_checkpointed_outcome(
                root,
                job_id=claimed["job_id"],
                prediction=prediction,
                checkpoint=claimed.get("checkpoint") or {},
            )
        outcome = snapshot.get("public_metrics", {}).get("viewCount")
        evaluation = evaluate_prediction(
            prediction,
            outcome_value=float(outcome),
            observed_at=snapshot["captured_at"],
            outcome_source_id=snapshot["snapshot_id"],
        )
        _validate(root, "prediction_evaluation.schema.json", evaluation)
        _validate_evaluation_binding(prediction, evaluation, snapshot)
        _write_immutable(evaluation_path, evaluation)
        _write_atomic(root / EVALUATIONS / "latest.json", evaluation)
        evaluation_ref = _relative(root, evaluation_path)
        finished = queue.succeed(
            claimed["job_id"],
            worker_id=claimed["lease_owner"],
            checkpoint={
                **(claimed.get("checkpoint") or {}),
                "evaluation": evaluation_ref,
            },
            now=current,
        )
        queue.materialize_snapshot(captured_at=current)
        return _status(
            root,
            status=evaluation["status"],
            prediction=prediction,
            now=current,
            job=finished,
            evaluation=evaluation_ref,
        )
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        failed = queue.fail(
            claimed["job_id"],
            worker_id=claimed["lease_owner"],
            error=error,
            checkpoint=claimed.get("checkpoint") or {},
            now=current,
        )
        queue.materialize_snapshot(captured_at=current)
        return _status(root, status="ERROR", prediction=prediction, now=current, job=failed, error=error)


def main() -> None:
    token_value = os.environ.get("HERO_YT_TOKEN_PATH")
    token = Path(token_value).resolve() if token_value else None
    print(json.dumps(
        run_prediction_observer(ROOT, token_path=token, observed_usage=_observed_youtube_usage(ROOT)),
        ensure_ascii=False,
        indent=2,
    ))


if __name__ == "__main__":
    main()
