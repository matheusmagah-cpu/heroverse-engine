"""Pure, frame-exact AV variety diagnostics; NOT a media observer or QA gate.

The historical take allocator is not changed. Declared component exposure and
proposed continuous occurrences remain hypotheses, including when the caller
supplies typed observation references. No verifier of those external reports is
implemented here; consequently this module can never issue QA PASS or authority.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
import re


VERSION = "phase6-av-variety-contract-v1"
INPUT_KIND = "PHASE6_AV_VARIETY_DECLARATION"
AUTHORITY = {key: False for key in ("qa", "timeline_admission", "lineage_admission", "render", "publication")}
THRESHOLDS = {
    "maximum_single_lineage_runtime_share": ("LE", Fraction(1, 10)),
    "top_six_lineage_runtime_share": ("LE", Fraction(11, 20)),
    "maximum_lineage_reuse_count": ("LE", 5),
    "maximum_rolling_60s_same_lineage_count": ("LE", 3),
    "adjacent_repeat_count": ("EQ", 0),
    "prior_episode_overlap_frames": ("EQ", 0),
    "minimum_distinct_source_lineages": ("GE", 12),
}
OBSERVATION_KINDS = {"COMPONENT_EXPOSURE", "CONTINUITY", "SOURCE_ANCESTRY", "PRIOR_EPISODE_COMPARISON"}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _keys(value, names, label):
    if type(value) is not dict or set(value) != set(names.split()):
        raise ValueError(label + ": closed fields required")


def _name(value, label):
    if type(value) is not str or not value.strip() or len(value) > 2048:
        raise ValueError(label + ": nonempty bounded string required")
    return value


def _integer(value, label, minimum=0):
    if type(value) is not int or not minimum <= value <= 2**53:
        raise ValueError(label + ": exact bounded integer required")
    return value


def _list(value, label):
    if type(value) is not list:
        raise ValueError(label + ": array required")
    return value


def _names(value, label):
    values = [_name(item, label) for item in _list(value, label)]
    if not values or len(values) != len(set(values)):
        raise ValueError(label + ": nonempty unique names required")
    return values


def _binding(value, label):
    _keys(value, "path sha256", label)
    _name(value["path"], label)
    if type(value["sha256"]) is not str or not re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
        raise ValueError(label + ": SHA-256 required")
    return value


def _interval(value, total, label):
    _keys(value, "start_frame end_frame", label)
    a, b = (_integer(value[key], label) for key in ("start_frame", "end_frame"))
    if not a < b <= total:
        raise ValueError(label + ": positive half-open interval required")
    return a, b


def _union(intervals):
    result = []
    for a, b in sorted(intervals):
        if result and a <= result[-1][1]:
            result[-1] = (result[-1][0], max(b, result[-1][1]))
        else:
            result.append((a, b))
    return result


def _length(intervals):
    return sum(b - a for a, b in _union(intervals))


def _intersection(left, right):
    return _union((max(a, c), min(b, d)) for a, b in left for c, d in right if max(a, c) < min(b, d))


def _fraction(value):
    value = Fraction(value)
    return {"numerator": value.numerator, "denominator": value.denominator}


def _partition(rows, total, label):
    cursor = 0
    for row in rows:
        start, end = _interval({key: row[key] for key in ("start_frame", "end_frame")}, total, label)
        if start != cursor:
            raise ValueError(label + ": gap, overlap or reordering")
        cursor = end
    if cursor != total:
        raise ValueError(label + ": incomplete coverage")


def _rolling(rows, key):
    # Preserve the historical closed start-time window: [start - 60s, start].
    return max((sum(other[key] == row[key] and row["start_frame"] - 1800 <= other["start_frame"] <= row["start_frame"]
                    for other in rows) for row in rows), default=0)


def _legacy(rows, sources, total):
    _list(rows, "legacy takes")
    if not rows:
        return {"status": "NOT_PROVIDED", "measurements": None}
    normalized, ids, runtime, counts = [], set(), Counter(), Counter()
    for row in rows:
        _keys(row, "take_id source_id start_frame end_frame", "legacy take")
        tid = _name(row["take_id"], "take id")
        if tid in ids or row["source_id"] not in sources:
            raise ValueError("duplicate legacy take or unknown source")
        ids.add(tid)
        source = sources[row["source_id"]]
        a, b = _interval({key: row[key] for key in ("start_frame", "end_frame")}, total, "legacy take")
        runtime[source["asset_id"]] += b - a
        counts[source["asset_id"]] += 1
        normalized.append({**row, "asset_id": source["asset_id"], "origin": source["asset_origin"].split("#t=", 1)[0]})
    _partition(rows, total, "legacy takes")
    shares = sorted((Fraction(value, total) for value in runtime.values()), reverse=True)
    return {"status": "DECLARED_LEGACY_TAKES_NOT_REPLAYED", "measurements": {
        "take_count": len(rows), "unique_asset_count": len(counts),
        "maximum_single_asset_runtime_share": _fraction(shares[0]),
        "top_six_asset_runtime_share": _fraction(sum(shares[:6])),
        "maximum_asset_reuse_count": max(counts.values()),
        "maximum_rolling_60s_same_asset_count": _rolling(normalized, "asset_id"),
        "adjacent_same_asset_count": sum(a["asset_id"] == b["asset_id"] for a, b in zip(normalized, normalized[1:])),
        "adjacent_same_origin_count": sum(a["origin"] == b["origin"] for a, b in zip(normalized, normalized[1:])),
        "prior_episode_overlap_frames": None}}


def calculate_variety(document, *, expected_sha256):
    """Validate declarations and compute exact hypotheses without external I/O.

    expected_sha256 pins the caller's document, not the truth of media or claims.
    An observation reference specifies media/report/observer/generator/calibration
    pins and exact frame/lineage scope. It is never a boolean approval, and none
    of those files is reopened by this pure calculator.
    """
    if type(expected_sha256) is not str or not re.fullmatch(r"[0-9a-f]{64}", expected_sha256) or digest(document) != expected_sha256:
        raise ValueError("external declaration pin differs")
    _keys(document, "kind version clock total_frames media_binding sources segments pause_intervals boundaries proposed_occurrences legacy_takes observation_references", "declaration")
    if document["kind"] != INPUT_KIND or document["version"] != VERSION or document["clock"] != {"fps": 30, "sample_rate": 24000, "samples_per_frame": 800}:
        raise ValueError("version or fixed AV clock differs")
    # Equality alone accepts True as 1; insist on exact types for the clock too.
    if any(type(value) is not int for value in document["clock"].values()):
        raise ValueError("clock integers required")
    total = _integer(document["total_frames"], "total frames", 1)
    _binding(document["media_binding"], "media")
    sources, by_hash, by_asset, by_path = {}, {}, {}, {}
    for source in _list(document["sources"], "sources"):
        _keys(source, "source_id asset_id asset_origin binding ancestor_lineage_ids", "source")
        sid = _name(source["source_id"], "source id")
        asset = _name(source["asset_id"], "asset id")
        _name(source["asset_origin"], "asset origin")
        binding = _binding(source["binding"], "source binding")
        ancestry = tuple(sorted(_names(source["ancestor_lineage_ids"], "ancestry")))
        if sid in sources or (binding["sha256"] in by_hash and by_hash[binding["sha256"]] != ancestry):
            raise ValueError("duplicate source or identical bytes assigned conflicting ancestry")
        if binding["path"] in by_path and by_path[binding["path"]] != binding["sha256"]:
            raise ValueError("same source path declares different bytes")
        identity = (binding["sha256"], ancestry, source["asset_origin"].split("#t=", 1)[0])
        if asset in by_asset and by_asset[asset] != identity:
            raise ValueError("asset identity conflicts across aliases")
        sources[sid], by_hash[binding["sha256"]], by_asset[asset] = source, ancestry, identity
        by_path[binding["path"]] = binding["sha256"]
    if not sources:
        raise ValueError("sources required")
    segments = _list(document["segments"], "segments")
    exposure, segment_ids, component_ids = defaultdict(list), set(), set()
    segment_boundaries = set()
    for segment in segments:
        _keys(segment, "segment_id start_frame end_frame components", "segment")
        sid = _name(segment["segment_id"], "segment id")
        if sid in segment_ids:
            raise ValueError("duplicate physical segment")
        segment_ids.add(sid)
        a, b = _interval({key: segment[key] for key in ("start_frame", "end_frame")}, total, "segment")
        if a:
            segment_boundaries.add(a)
        bases = 0
        for component in _list(segment["components"], "components"):
            _keys(component, "component_id source_id role exposure_intervals", "component")
            cid = _name(component["component_id"], "component id")
            if cid in component_ids or component["source_id"] not in sources or component["role"] not in {"BASE", "OVERLAY"}:
                raise ValueError("duplicate component, unknown source or component role")
            component_ids.add(cid)
            intervals = [_interval(item, total, "component exposure") for item in _list(component["exposure_intervals"], "component exposure")]
            if not intervals or intervals != _union(intervals) or any(not a <= c < d <= b for c, d in intervals):
                raise ValueError("component exposure missing, overlapping or outside segment")
            if component["role"] == "BASE":
                bases += 1
                if intervals != [(a, b)]:
                    raise ValueError("base exposure cannot be hidden by an overlay or pause")
            for lineage in sources[component["source_id"]]["ancestor_lineage_ids"]:
                exposure[lineage].extend(intervals)
        if bases != 1:
            raise ValueError("exactly one fully counted base required per physical segment")
    _partition(segments, total, "physical segments")
    exposure = {key: _union(value) for key, value in sorted(exposure.items())}
    pauses = [_interval(row, total, "pause") for row in _list(document["pause_intervals"], "pauses")]
    if pauses != _union(pauses):
        raise ValueError("pause intervals overlap or are reordered")
    references = {}
    for reference in _list(document["observation_references"], "observation references"):
        _keys(reference, "evidence_id kind media_binding report_binding observer_binding generator_binding calibration_binding start_frame end_frame lineage_ids", "observation reference")
        eid = _name(reference["evidence_id"], "evidence id")
        if eid in references or reference["kind"] not in OBSERVATION_KINDS:
            raise ValueError("duplicate or unknown observation reference")
        for key in ("media_binding", "report_binding", "observer_binding", "generator_binding", "calibration_binding"):
            _binding(reference[key], key)
        if reference["media_binding"] != document["media_binding"] or reference["observer_binding"]["sha256"] == reference["generator_binding"]["sha256"]:
            raise ValueError("observation media differs or observer is the generator")
        _interval({key: reference[key] for key in ("start_frame", "end_frame")}, total, "observation scope")
        if not set(_names(reference["lineage_ids"], "observed lineage scope")) <= set(exposure):
            raise ValueError("observation lineage scope differs")
        references[eid] = reference
    boundaries, boundary_frames = [], set()
    for boundary in _list(document["boundaries"], "boundaries"):
        _keys(boundary, "frame kind lineage_ids evidence_id", "boundary")
        frame = _integer(boundary["frame"], "boundary frame", 1)
        if frame >= total or frame in boundary_frames or boundary["kind"] not in {"CONTINUOUS", "CUT", "RESTART", "UNKNOWN"}:
            raise ValueError("boundary frame, identity or kind differs")
        lineage_ids = _names(boundary["lineage_ids"], "boundary lineages")
        if not set(lineage_ids) <= set(exposure):
            raise ValueError("unknown boundary lineage")
        active = {key for key, spans in exposure.items() if any(a <= frame - 1 < b or a <= frame < b for a, b in spans)}
        if set(lineage_ids) != active:
            raise ValueError("boundary omits or invents adjacent exposed ancestry")
        eid = boundary["evidence_id"]
        if eid is not None:
            reference = references.get(eid)
            if (reference is None or reference["kind"] != "CONTINUITY" or not reference["start_frame"] <= frame - 1 < frame < reference["end_frame"]
                    or not set(lineage_ids) <= set(reference["lineage_ids"])):
                raise ValueError("boundary observation reference scope differs")
        boundary_frames.add(frame)
        boundaries.append(boundary)
    if not segment_boundaries <= boundary_frames:
        raise ValueError("physical segment boundary omitted")
    proposals, proposal_ids, proposed_exposure = [], set(), defaultdict(list)
    for row in _list(document["proposed_occurrences"], "proposed occurrences"):
        _keys(row, "proposal_id lineage_id start_frame end_frame", "proposed occurrence")
        pid = _name(row["proposal_id"], "proposal id")
        lineage = row["lineage_id"]
        if pid in proposal_ids or lineage not in exposure:
            raise ValueError("duplicate occurrence proposal or unknown lineage")
        proposal_ids.add(pid)
        a, b = _interval({key: row[key] for key in ("start_frame", "end_frame")}, total, "occurrence proposal")
        if _intersection(exposure[lineage], [(a, b)]) != [(a, b)]:
            raise ValueError("occurrence proposal bridges an unexposed gap")
        if any(a < item["frame"] < b and lineage in item["lineage_ids"] and item["kind"] in {"CUT", "RESTART"} for item in boundaries):
            raise ValueError("occurrence proposal falsely merges a declared cut or restart")
        proposed_exposure[lineage].append((a, b))
        proposals.append(row)
    if proposals:
        if set(proposed_exposure) != set(exposure):
            raise ValueError("occurrence proposals omit exposed lineage")
        for lineage, intervals in proposed_exposure.items():
            ordered = sorted(intervals)
            if any(a[1] > b[0] for a, b in zip(ordered, ordered[1:])) or _union(intervals) != exposure[lineage]:
                raise ValueError("occurrence proposals overlap or omit exposure")
    counts = Counter(row["lineage_id"] for row in proposals)
    shares = sorted((Fraction(_length(value), total) for value in exposure.values()), reverse=True)
    adjacent = sum(left["lineage_id"] == right["lineage_id"] and left["end_frame"] == right["start_frame"]
                   for left in proposals for right in proposals)
    measures = {
        "maximum_single_lineage_runtime_share": shares[0],
        "top_six_lineage_runtime_share": sum(shares[:6], Fraction(0)),
        "maximum_lineage_reuse_count": max(counts.values()) if proposals else None,
        "maximum_rolling_60s_same_lineage_count": _rolling(proposals, "lineage_id") if proposals else None,
        "adjacent_repeat_count": adjacent if proposals else None,
        "prior_episode_overlap_frames": None,
        "minimum_distinct_source_lineages": len(exposure),
    }
    gates = {}
    for name, (operator, threshold) in THRESHOLDS.items():
        value = measures[name]
        condition = None if value is None else {"LE": value <= threshold, "GE": value >= threshold, "EQ": value == threshold}[operator]
        gates[name] = {"status": "NOT_EVALUATED", "comparison": operator, "threshold": _fraction(threshold),
                       "declared_value": _fraction(value) if value is not None else None, "arithmetic_condition_only": condition}
    gaps = ["DECLARED_MEDIA_NOT_REOPENED_OR_OBSERVED", "COMPONENT_LEDGER_COMPLETENESS_NOT_OBSERVED",
            "SOURCE_ANCESTRY_NOT_VERIFIED", "CONTINUITY_AND_INTERNAL_CUTS_NOT_OBSERVED",
            "OCCURRENCE_OBSERVER_AND_VERIFIER_NOT_IMPLEMENTED", "PAUSE_NARRATIVE_JUSTIFICATION_NOT_VERIFIED",
            "PRIOR_EPISODE_CONTENT_OVERLAP_NOT_MEASURED", "LEGACY_QUALITY_DISPATCH_NOT_REPLACED",
            "FINAL_AUDIOVISUAL_QUALITY_NOT_EVALUATED"]
    if references:
        gaps.append("TYPED_OBSERVATION_REFERENCES_NOT_REOPENED_OR_AUTHENTICATED")
    if not proposals:
        gaps.append("OCCURRENCE_HYPOTHESIS_NOT_PROVIDED")
    result = {
        "kind": "PHASE6_AV_VARIETY_DIAGNOSTIC", "version": VERSION, "status": "DIAGNOSTIC_ONLY",
        "declaration_sha256": expected_sha256, "clock": dict(document["clock"]), "total_frames": total,
        "legacy_take_diagnostic": _legacy(document["legacy_takes"], sources, total),
        "declared_exposure": [{"lineage_id": key, "intervals": [{"start_frame": a, "end_frame": b} for a, b in value],
            "visible_frames": _length(value), "visible_pause_frames": _length(_intersection(value, pauses)),
            "runtime_share": _fraction(Fraction(_length(value), total))} for key, value in exposure.items()],
        "occurrences": {"status": "UNVERIFIED_HYPOTHESIS" if proposals else "NOT_PROVIDED",
            "proposed_counts_by_lineage": dict(sorted(counts.items())), "observed_counts_by_lineage": None,
            "accepted_counts_by_lineage": None},
        "gates": gates, "observation_reference_ids": sorted(references), "gaps": gaps,
        "authority": dict(AUTHORITY), "qa_pass": False, "technical_cost_brl": 0,
        "effect_boundary": "PURE_DECLARATION_ARITHMETIC_NO_FILE_MEDIA_OR_NETWORK_IO",
        "limitations": ["Shares count every exposed ancestor; simultaneous components are not normalized to 100%.",
            "Lineage floor is a declared ancestor count, not twelve verified independent source assets.",
            "Proposed occurrence arithmetic never replaces historical take counts or observed continuity.",
            "Identical hashes, filenames, IDs or typed evidence references never prove continuity."]}
    result["diagnostic_id"] = VERSION + "-" + digest(result)[:24]
    return result


def verify_diagnostic(candidate, document, *, expected_sha256):
    expected = calculate_variety(document, expected_sha256=expected_sha256)
    if canonical(candidate) != canonical(expected):
        raise ValueError("diagnostic differs from pinned declarations and exact arithmetic")
    return {"status": "DIAGNOSTIC_ONLY", "diagnostic_id": expected["diagnostic_id"],
            "authority": dict(AUTHORITY), "qa_pass": False}
