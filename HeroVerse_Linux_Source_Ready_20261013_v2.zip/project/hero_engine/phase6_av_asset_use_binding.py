"""Join independently reopened untimed source uses to the exact Stage-A rows.

This is not the temporal static-source adapter. Neither the 25 bound uses nor
the OWNED metadata creates a render span, word timestamp or Stage-B admission.
"""
from __future__ import annotations

import copy
from pathlib import Path
import re

from . import phase6_av_static_sources as sources
from .phase6_narration_units import canonical_sha

VERSION = "phase6-av-asset-use-binding-v1"
PATH = "hero_engine/phase6_av_asset_use_binding.py"
COVERED = tuple(sorted(
    [f"visual-u{unit}-s{index:02d}" for unit in ("005", "006", "007") for index in (0, 1)]
    + [f"visual-u034-s{index:02d}" for index in range(5)]
    + ["visual-u044-s00", "visual-u045-s00", "visual-u010-s00", "visual-u011-s00", "visual-u011-s01",
       "visual-u012-s00", "visual-u012-s01", "visual-u013-s00", "visual-u014-s00", "visual-u015-s00",
       "visual-u016-s00", "visual-u016-s01", "visual-u017-s00", "visual-u018-s00"]))
AUTHORITY = {key: False for key in ("timing", "source_admitted", "quality", "publicity", "render", "queue", "publication")}


def _same(a, b, message):
    sources._same(a, b, message)


def validate_binding(binding):
    if (type(binding) is not dict or set(binding) != {"path", "sha256"}
            or type(binding["path"]) is not str or not binding["path"]
            or type(binding["sha256"]) is not str
            or re.fullmatch(r"sha256:[a-f0-9]{64}", binding["sha256"]) is None
            or Path(binding["path"]).drive or Path(binding["path"]).root or ".." in Path(binding["path"]).parts):
        raise ValueError("caller-pinned root-relative literal asset-use binding required")


def join(proof, binding, literal):
    """Pure cross-surface check; caller must obtain proof from the inspector."""
    validate_binding(binding)
    if literal is None or literal.get("adapter_version") != "phase6-av-visual-amendment-v1":
        raise ValueError("literal asset uses require independently amended visual intent")
    _same([proof["version"], proof["status"], proof["channel_id"], proof["video_id"],
           proof["source_count"], proof["use_count"], proof["unique_png_content_count"], proof["lineage_count"],
           proof["source_ready"], proof["global_schedule_created"], proof["calibrated_timing_available"],
           proof["authority"], proof["technical_cost_brl"]],
          ["phase6-av-static-asset-uses-v2", "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY", sources.CHANNEL,
           "video-002", 23, 25, 22, 3, False, False, False, AUTHORITY, 0], "literal asset-use scope or authority differs")
    _same(proof["input_binding"], {"path": binding["path"], "sha256": binding["sha256"][7:]}, "literal use input differs")
    _same(proof["visual_amendment_evidence"], {
        "inspection_sha256": canonical_sha(literal), "effective_rows_sha256": canonical_sha(literal["rows"]),
        "changed_state_count": 12, "unmodified_state_count": 88, "source_ready": False, "global_schedule_created": False},
        "literal use evidence belongs to another visual amendment")
    indexed = {}
    for row in literal["rows"]:
        for state in row["states"]:
            if state["state_id"] in indexed:
                raise ValueError("literal visual population contains duplicate states")
            indexed[state["state_id"]] = (row, state)
    if len(indexed) != 100 or type(proof["uses"]) is not list:
        raise ValueError("exact literal visual population required")
    _same(sorted(use["visual_state_id"] for use in proof["uses"]), list(COVERED), "literal use coverage differs")
    for use in proof["uses"]:
        row, state = indexed[use["visual_state_id"]]
        _same([use["unit_id"], use["literal_copy"], use["entry"]],
              [row["unit_id"], state["visual_content"]["literal_copy"], state["entry"]],
              "literal use entry, copy or unit does not match Stage A")
    remaining = sorted(set(indexed) - set(COVERED))
    _same(proof["remaining_unbound_visual_state_ids"], remaining, "unbound states cannot disappear")
    if len(remaining) != 75:
        raise ValueError("exact seventy-five unbound states required")
    return {"adapter_version": VERSION, "scope": "UNTIMED_ASSET_USE_METADATA_ONLY",
        "source_binding": copy.deepcopy(binding), "inspection_sha256": canonical_sha(proof),
        "use_rows_sha256": canonical_sha(proof["uses"]), "effective_rows_sha256": canonical_sha(literal["rows"]),
        "source_count": 23, "use_count": 25, "unique_png_content_count": 22, "lineage_count": 3,
        "visual_state_count": 100, "bound_visual_state_ids": list(COVERED),
        "remaining_unbound_visual_state_ids": remaining, "source_ready": False, "global_schedule_created": False,
        "calibrated_timing_available": False, "authority": dict(AUTHORITY), "technical_cost_brl": 0}


def read_asset_use_binding(reader, binding, literal, *, proof_sink):
    """Recompose from external pins, attach internal bytes, preserve external sink.

    proof_sink is populated internally for final same-build dependency checks.
    It is never an input proof cache or a public admission/approval interface.
    """
    validate_binding(binding)
    if not isinstance(proof_sink, list) or proof_sink:
        raise ValueError("fresh same-call asset-use proof sink required")
    from . import phase6_av_static_asset_uses_v2 as uses
    path = sources._resident(reader.root / binding["path"])
    reader.read(binding["path"], binding["sha256"])
    proof = uses.inspect_static_asset_uses(reader.root, binding={"path": binding["path"], "sha256": binding["sha256"][7:]})
    result = join(proof, binding, literal)
    for item in proof["dependency_bindings"]:
        dependency = Path(item["path"])
        if dependency.is_relative_to(reader.root):
            sources._resident(dependency)
            raw = reader.read(dependency.relative_to(reader.root).as_posix(), "sha256:" + item["sha256"])
            if len(raw) != item["size_bytes"]:
                raise ValueError("literal use dependency size changed")
    # This also verifies fixed external font/decoder identities, which Stage A's
    # generic root-confined reader must not silently broaden its namespace for.
    sources.recheck_static_dependencies(reader.root, [proof])
    proof_sink.append(proof)
    return result
