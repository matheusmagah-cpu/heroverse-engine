"""Forward-only validation boundary for current Phase 6 consumers.

This module deliberately does not replay historical A9 receipts whose exact
source byte has been lost.  It records that gap, then authenticates only the
current candidate and active visual contract.  It grants no apply, render or
publication authority.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .maintenance_paused_application import candidate_identity
from .phase6_visual_preflight import materialize_current_visual_preflight, verify_visual_preflight

VERSION = "phase6-forward-only-boundary-v1"
HISTORICAL_GAPS = ({
    "gap_id": "A9_READER_SOURCE_UNAVAILABLE",
    "path": "hero_engine/phase6_narration_audio_inventory.py",
    "required_sha256": "sha256:11e56ca46d3f4928882ece936500b49a428caf7cbd1ff542069eceb47db4bde6",
    "status": "HISTORICAL_PROVENANCE_GAP",
    "scope": "HISTORICAL_REPLAY_ONLY",
},)
ACTIVE_IMPLEMENTATIONS = (
    "hero_engine/phase6_av_visual_recipe_adapter_v3.py",
    "hero_engine/phase6_av_render_recipe_v3.py",
)


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical(value: Any) -> str:
    return _sha(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode())


def build_forward_only_boundary(root: Path) -> dict[str, Any]:
    root = Path(root).resolve(strict=True)
    candidate = candidate_identity(root)
    visual = materialize_current_visual_preflight(root)
    verify_visual_preflight(root, visual, require_pass=True)
    implementations = []
    for relative in ACTIVE_IMPLEMENTATIONS:
        raw = (root / relative).read_bytes()
        implementations.append({"path": relative, "sha256": _sha(raw), "size_bytes": len(raw)})
    value = {
        "version": VERSION,
        "candidate": {"source_set_sha256": candidate["source_set_sha256"], "file_count": candidate["file_count"]},
        "visual_preflight": {key: visual[key] for key in ("audit_id", "path", "sha256", "status")},
        "active_implementations": implementations,
        "historical_gaps": list(HISTORICAL_GAPS),
        "authority": {"apply_authorized": False, "render_authorized": False, "publication_authorized": False},
    }
    value["boundary_sha256"] = _canonical(value)
    return value


def verify_forward_only_boundary(root: Path, candidate: dict[str, Any]) -> dict[str, Any]:
    expected = build_forward_only_boundary(root)
    if _canonical(candidate) != _canonical(expected):
        raise ValueError("forward-only boundary differs from current authenticated state")
    return expected
