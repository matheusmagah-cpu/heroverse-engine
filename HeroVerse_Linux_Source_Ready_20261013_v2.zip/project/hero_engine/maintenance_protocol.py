from __future__ import annotations

import argparse
import ast
import errno
import hashlib
import json
import os
import sqlite3
import sys
import time
import uuid
from contextlib import ExitStack, closing, contextmanager
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Iterable
from urllib.parse import quote

from jsonschema import Draft202012Validator, FormatChecker, ValidationError


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path("output/runtime/gestor-central")
REQUEST_PATH = RUNTIME / "maintenance-request.json"
ACK_PATH = RUNTIME / "maintenance-ack.json"
CAPABILITY_PATH = RUNTIME / "maintenance-capability.json"
RECOVERY_WINDOW_PATH = RUNTIME / "maintenance-recovery-window.json"
QUEUE_PATH = Path("output/operations/phase6/runtime/phase6-queue.sqlite3")
QUOTA_LEDGER_PATH = Path("output/operations/zero-cost/phase6-quota-ledger.sqlite3")
PREDICTION_RUNTIME_PATH = Path("output/operations/phase6/intelligence/prediction-runtime.json")
PREDICTIONS_PATH = Path("output/operations/phase6/intelligence/predictions")
PREDICTION_EVALUATIONS_PATH = Path(
    "output/operations/phase6/intelligence/prediction-evaluations"
)
EXECUTIVE_STATUS_PATH = Path("output/operations/phase6/executive-status.json")
EXECUTIVE_STATUS_MARKDOWN_PATH = Path("output/operations/phase6/EXECUTIVE_STATUS.md")
MEDIA_EXECUTOR_STATUS_PATH = Path("output/operations/phase6/media-executor-status.json")
QUALITY_EXECUTOR_STATUS_PATH = Path("output/operations/phase6/quality-executor-status.json")
QUALITY_RECOMPUTATION_ERROR = (
    "PermissionError: quality measurements/gates do not match independent recomputation from raw evidence"
)
QUALITY_RETRY_HOLD = (
    "CONTROLLED_QUALITY_REEVALUATION_PENDING: original failure preserved in the unchanged queue "
    "and maintenance preimage; no quality, render or publication approval."
)
GOAL_TRAJECTORY_PATH = Path("output/operations/phase6/goal-trajectory/current.json")
GOAL_TRAJECTORY_LEGACY_PATH = Path("output/operations/phase6/goal-trajectory/latest.json")
CONTROL_CYCLE_ERROR_PATH = Path("output/operations/phase6/control-cycle-error.json")
CONTROL_CYCLE_ERROR_ARCHIVE = Path("output/operations/phase6/control-cycle/errors/archive")
LEGACY_EXECUTIVE_REPLACE_ERROR_SHA256 = (
    "sha256:1184c5b3d869e30c1c012e4e5f59fdf4dea1ae5c9bd288be59bca3dc9b9fa6b3"
)
LEGACY_EXECUTIVE_REPLACE_ERROR_UPDATED_AT = "2026-09-06T02:49:22.292999Z"
EXECUTIVE_ATOMIC_WRITER_REQUIRED = "phase6-executive-atomic-writer-v2"
EXACT_VISUAL_BLOCKED_ERROR = (
    "VisualContractError: VISUAL_CONTRACT_PREFLIGHT_BLOCKED:"
    "FONT_BELOW_STYLE_BIBLE_MINIMUM,PLANNED_VS_RENDERER_TEXT_MISMATCH,"
    "PLAN_STYLE_BIBLE_FRAMEWORK_MISMATCH,REQUIRED_TEXT_MISSING;"
    "evidence=output/operations/phase6/visual-preflight/audits/"
    "visual-preflight-394d5a2f84d56d4a3570519f.json"
)
EXACT_VISUAL_BLOCKED_NEXT_ACTION = (
    "Resolve the visual contract before capacity, queue, synthesis or render; "
    "historical jobs and media are untouched."
)

PROTECTED_TASK_PREFIXES = (
    "OWNED_METRICS_CHECKPOINT",
    "PREDICTION_OUTCOME_CHECKPOINT",
    "GOAL_CHANNEL_CHECKPOINT",
    "PHASE6_TREATMENT_METRICS_CHECKPOINT",
)

OAUTH_HEALTH_PATH = RUNTIME / "oauth-session-health.json"
OAUTH_REFRESH_PATH = Path(
    "output/integrations/youtube/heroverse/oauth-noninteractive-refresh-receipt.json"
)
OAUTH_WATCHER_PATH = RUNTIME / "oauth-reconsent-watcher.json"
OAUTH_MIRROR_PATH = Path("output/integrations/youtube/heroverse/oauth-token-mirror-receipt.json")
OAUTH_CONNECTION_PATH = Path("output/integrations/youtube/heroverse/connection-receipt.json")
OAUTH_SCOPES = {
    "https://www.googleapis.com/auth/youtube.readonly",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.force-ssl",
}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _stamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def committed_application_stdout(root: Path, receipt: dict[str, Any]) -> bytes:
    """Return the exact committed receipt bytes for the apply-paused CLI.

    The paused-application reference intentionally binds the child process
    stdout to ``committed.json`` byte-for-byte.  Re-serializing a logically
    equal mapping changes whitespace/key order and silently makes D-116
    unverifiable, so this helper reopens the committed artifact and fails
    closed if it is not precisely the result returned by the transaction.
    """
    application_id = receipt.get("application_id")
    if not isinstance(application_id, str) or not application_id:
        raise PermissionError("paused application receipt has no application identity")
    path = root / RUNTIME / "maintenance-runs" / application_id / "committed.json"
    if not path.is_file():
        raise PermissionError("paused application committed receipt is unavailable")
    raw = path.read_bytes()
    if _read(path) != receipt:
        raise PermissionError("paused application committed receipt differs from transaction result")
    return raw


def oauth_refresh_due_at(tested_at: str, *, interval_seconds: int) -> datetime:
    """Single clock used by both the manager and maintenance boundary."""
    return _parse(tested_at) + timedelta(seconds=interval_seconds)


def oauth_source_change_pending(
    source: Path,
    destination: Path,
    *,
    mirrored_source_sha256: str | None,
) -> bool:
    """Return True only when the durable OAuth grant changed.

    Access-token and expiry rotation in the consent source are normal and must
    not force another mirror/identity probe when its refresh grant, client and
    scope set are identical to the already healthy runtime token.
    """

    if not source.is_file():
        return False
    from .oauth_token_mirror import inspect_authorized_user_token

    source_info = inspect_authorized_user_token(source)
    if source_info["sha256"] == mirrored_source_sha256:
        return False
    destination_info = inspect_authorized_user_token(destination)
    return source_info["grant_sha256"] != destination_info["grant_sha256"]


def _parse_token_expiry(value: str) -> datetime:
    try:
        return _parse(value)
    except ValueError:
        # Some historical Google credential serializations used the invariant
        # US slash form without an offset.  Treat it explicitly as UTC; never
        # let host culture decide whether 09/05 means May or September.
        return datetime.strptime(value, "%m/%d/%Y %H:%M:%S").replace(tzinfo=timezone.utc)


def _hash_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def canonical_hash(value: Any) -> str:
    return _hash_bytes(_canonical_bytes(value))


def file_hash(path: Path) -> str:
    return _hash_bytes(path.read_bytes())


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _write_immutable_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable maintenance evidence collision: {path}")
        return
    try:
        with path.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        if path.read_bytes() != payload:
            raise PermissionError(f"immutable maintenance evidence collision: {path}")


_MIGRATION_REPLACE_RETRY_DELAYS_SECONDS = (
    0.05,
    0.10,
    0.25,
    0.50,
    1.0,
    2.0,
    4.0,
    8.0,
    12.0,
)


def _replace_bytes(path: Path, payload: bytes, *, recheck=None) -> None:
    """Atomically replace one derived view with a bounded sharing-lock retry.

    A local runtime migration owns a mutex and has already pinned every target
    preimage.  Windows cloud/indexing readers can nevertheless hold the exact
    destination briefly between those checks and ``os.replace``.  Retrying the
    *same private temporary file* is safe; accepting a different destination,
    skipping the replacement, or extending the transaction indefinitely is not.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(payload)
    for attempt, delay in enumerate(_MIGRATION_REPLACE_RETRY_DELAYS_SECONDS):
        if recheck is not None:
            recheck()
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == len(_MIGRATION_REPLACE_RETRY_DELAYS_SECONDS) - 1:
                raise
            time.sleep(delay)


def _commit_migration_replacement(path: Path, payload: bytes) -> None:
    """Commit one prepared derived view.

    Kept as a narrow boundary so the all-or-nothing migration contract can be
    fault-injected without weakening the atomic writer used for rollback.
    """
    _replace_bytes(path, payload)


def _commit_migration_removal(path: Path) -> None:
    """Commit one prepared removal at the migration transaction boundary."""
    _remove_migration_target(path)


def _target_matches_preimage(target: Path, *, existed: bool, payload: bytes) -> bool:
    if existed:
        return target.is_file() and not target.is_symlink() and target.read_bytes() == payload
    return not target.exists() and not target.is_symlink()


def _target_matches_desired(target: Path, *, exists: bool, payload: bytes) -> bool:
    return _target_matches_preimage(target, existed=exists, payload=payload)


def _confined_migration_evidence_path(
    root: Path,
    relative: str,
    *,
    expected_parent: Path,
) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise PermissionError("migration evidence path must be workspace-relative")
    path = (root / relative).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise PermissionError("migration evidence path escaped the workspace") from exc
    if path.parent != expected_parent:
        raise PermissionError("migration evidence path left its exact maintenance run")
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise PermissionError("migration evidence target is not a regular file")
    return path


def _remove_migration_target(target: Path) -> None:
    """Remove a file created by a failed migration, with bounded Windows retry."""
    for attempt in range(6):
        try:
            target.unlink(missing_ok=True)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def _rollback_migration_targets(states: list[dict[str, Any]], *, replace_bytes=None) -> dict[str, Any]:
    """Restore every migration target to its exact byte/absence preimage."""
    restoration_errors: list[str] = []
    for state in reversed(states):
        target = state["target"]
        existed = bool(state["existed_before"])
        before = state["before"]
        try:
            if _target_matches_preimage(target, existed=existed, payload=before):
                continue
            if existed:
                (replace_bytes or _replace_bytes)(target, before)
            else:
                if target.is_dir() and not target.is_symlink():
                    raise IsADirectoryError(str(target))
                _remove_migration_target(target)
        except Exception as exc:
            restoration_errors.append(
                f"{state['relative_path']}:{type(exc).__name__}:{exc}"
            )

    target_evidence: list[dict[str, Any]] = []
    for state in states:
        target = state["target"]
        existed = bool(state["existed_before"])
        before = state["before"]
        try:
            restored = _target_matches_preimage(target, existed=existed, payload=before)
            actual_exists = target.is_file() and not target.is_symlink()
            actual_hash = _hash_bytes(target.read_bytes()) if actual_exists else None
        except Exception as exc:
            restored = False
            actual_exists = target.exists() or target.is_symlink()
            actual_hash = None
            restoration_errors.append(
                f"{state['relative_path']}:VERIFY:{type(exc).__name__}:{exc}"
            )
        target_evidence.append(
            {
                "path": state["relative_path"],
                "existed_before": existed,
                "expected_hash": _hash_bytes(before) if existed else None,
                "exists_after_rollback": actual_exists,
                "actual_hash": actual_hash,
                "restored": restored,
            }
        )
    return {
        "attempted": True,
        "verified": not restoration_errors
        and all(item["restored"] for item in target_evidence),
        "targets": target_evidence,
        "errors": restoration_errors,
    }


def _schema(root: Path, name: str) -> dict[str, Any]:
    return _read(root / "schemas" / name)


def validate(root: Path, name: str, value: Any) -> None:
    Draft202012Validator(
        _schema(root, name), format_checker=FormatChecker()
    ).validate(value)


_PROTECTED_DATABASE_VIEW = ContextVar("maintenance_protected_database_view", default=None)


def _readonly_connection(path: Path) -> sqlite3.Connection:
    view = _PROTECTED_DATABASE_VIEW.get()
    if view is not None:
        origin, capture = view
        capture.revalidate()
        resolved = path.resolve()
        if resolved in {origin / QUEUE_PATH, origin / QUOTA_LEDGER_PATH}:
            path = capture.work_root / resolved.relative_to(origin)
        elif resolved not in {capture.work_root / QUEUE_PATH, capture.work_root / QUOTA_LEDGER_PATH}:
            raise PermissionError("PAUSED_APPLICATION_DATABASE_OUTSIDE_CAPTURE")
    # mode=ro plus query_only prevents schema initialization, WAL creation,
    # recovery writes and accidental mutations by this maintenance protocol.
    uri = f"file:{quote(path.resolve().as_posix(), safe='/:')}?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=5, isolation_level=None)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _table_names(connection: sqlite3.Connection) -> set[str]:
    return {
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }


def queue_snapshot(root: Path, *, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    path = root / QUEUE_PATH
    jobs: list[dict[str, Any]] = []
    superseded_job_ids: list[str] = []
    if path.is_file():
        with closing(_readonly_connection(path)) as connection:
            connection.execute("BEGIN")
            if "jobs" not in _table_names(connection):
                raise PermissionError("Phase 6 queue exists without the jobs table")
            rows = connection.execute(
                """SELECT job_id,idempotency_key,operation_id,channel_id,task_type,
                          payload_json,state,attempt_count,max_attempts,available_at,
                          lease_owner,lease_until,checkpoint_json,last_error,created_at,updated_at
                     FROM jobs ORDER BY job_id"""
            ).fetchall()
            for row in rows:
                item = dict(row)
                item["payload"] = json.loads(item.pop("payload_json"))
                item["checkpoint"] = json.loads(item.pop("checkpoint_json"))
                jobs.append(item)
            if "media_job_supersessions" in _table_names(connection):
                superseded_job_ids = sorted(
                    str(row[0])
                    for row in connection.execute(
                        "SELECT superseded_job_id FROM media_job_supersessions "
                        "WHERE state IN ('PREPARED','COMMITTED')"
                    ).fetchall()
                )
            connection.execute("ROLLBACK")
    active_leases = [
        item["job_id"]
        for item in jobs
        if item["state"] == "LEASED" or item["lease_owner"] is not None or item["lease_until"] is not None
    ]
    return {
        "schema_version": "1.0.0",
        "database_path": QUEUE_PATH.as_posix(),
        "database_present": path.is_file(),
        "observed_at": _stamp(observed),
        "job_count": len(jobs),
        "superseded_job_ids": superseded_job_ids,
        "active_lease_job_ids": sorted(active_leases),
        "jobs_hash": canonical_hash(jobs),
        "jobs": jobs,
    }


def _protected_due_jobs(snapshot: dict[str, Any], *, deadline: datetime) -> list[str]:
    result: list[str] = []
    superseded = set(snapshot.get("superseded_job_ids") or [])
    for job in snapshot["jobs"]:
        task_type = str(job["task_type"])
        protected = any(task_type == prefix or task_type.startswith(prefix + ":") for prefix in PROTECTED_TASK_PREFIXES)
        if (
            protected
            and job["job_id"] not in superseded
            and job["state"] in {"PENDING", "RETRY_WAIT"}
            and _parse(str(job["available_at"])) <= deadline
        ):
            result.append(str(job["job_id"]))
    return sorted(result)


def _operational_due_jobs(snapshot: dict[str, Any], *, deadline: datetime) -> list[str]:
    """Return every runnable job whose due time intersects maintenance."""
    superseded = set(snapshot.get("superseded_job_ids") or [])
    return sorted(
        str(job["job_id"])
        for job in snapshot["jobs"]
        if job["job_id"] not in superseded
        and job["state"] in {"PENDING", "RETRY_WAIT"}
        and _parse(str(job["available_at"])) <= deadline
    )


def _inert_current_media_due_jobs(
    root: Path, snapshot: dict[str, Any], due_job_ids: Iterable[str]
) -> list[str]:
    """Identify a *very narrow* non-executable current-media work item.

    A pending job normally blocks maintenance.  The single exception here is
    not a scheduler bypass: it is an exact forward production-input job whose
    independently verified current contract grants neither queue nor render
    authority.  Any unreadable/changed contract, payload variation, attempted
    job, lease, checkpoint, or authority change remains operationally due.
    """
    candidates = set(due_job_ids)
    if not candidates:
        return []
    try:
        from .phase6_current_production_inputs import current_production_input_contract

        contract = current_production_input_contract(root)
    except Exception:
        return []
    authority = contract.get("authority")
    receipt_id = contract.get("receipt_id")
    if not (
        isinstance(receipt_id, str)
        and isinstance(authority, dict)
        and authority == {
            "queue": False,
            "voice": False,
            "render": False,
            "quality": False,
            "publication": False,
        }
    ):
        return []
    inert: list[str] = []
    # The transaction can install an authenticated post-mux reserve hold for an
    # already attempted job. It is not the unattempted forward-input exception
    # below: reopen its strict producer/witness and bind the same queue row.
    # A generic RETRY_WAIT, or the original unheld failure, remains due.
    reserve_evidence = None
    try:
        hold_path = root / MEDIA_EXECUTOR_STATUS_PATH
        hold_hash = file_hash(hold_path)
        hold = _read(hold_path)
        if (hold.get("status") == "WAITING" and hold.get("error") is None
                and hold.get("next_action") == "OWNER_PAUSE_RELEASE_REQUIRED: "
                    + _EXACT_MEDIA_RESERVE_WAIT_ERROR):
            held, evidence = _resource_reserve_media_wait_candidate(
                root, current=hold, source_path=hold_path,
                observed=datetime.now(timezone.utc))
            if (held is not None and evidence is not None
                    and evidence.get("reason") == "EXACT_RESOURCE_RESERVE_RESTART_HOLD"
                    and evidence.get("source_sha256") == hold_hash
                    and file_hash(hold_path) == hold_hash):
                reserve_evidence = evidence
    except Exception:
        # Failure to authenticate a hold never removes an operational blocker.
        pass
    for job in snapshot.get("jobs") or []:
        if not isinstance(job, dict) or str(job.get("job_id")) not in candidates:
            continue
        payload = job.get("payload")
        if not isinstance(payload, dict):
            continue
        if (reserve_evidence is not None
                and reserve_evidence.get("input_receipt_id") == receipt_id
                and reserve_evidence.get("job_sha256") == canonical_hash(job)):
            inert.append(str(job["job_id"]))
            continue
        expected_key = f"{receipt_id}:synthesize-render-standard-v2"
        if (
            job.get("task_type") == "EXECUTE_PHASE6_VIDEO2_MEDIA"
            and job.get("state") in {"PENDING", "RETRY_WAIT"}
            and job.get("attempt_count") == 0
            and job.get("lease_owner") is None
            and job.get("lease_until") is None
            and job.get("last_error") in {None, ""}
            and job.get("checkpoint") == {}
            and job.get("idempotency_key") == expected_key
            and payload == {
                "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
                "input_receipt_id": receipt_id,
            }
        ):
            inert.append(str(job["job_id"]))
    return sorted(inert)


def ledger_state_snapshot(root: Path) -> dict[str, Any]:
    """Hash the complete logical quota ledger, including CONSUMED rows."""
    root = root.resolve()
    path = root / QUOTA_LEDGER_PATH
    tables: list[dict[str, Any]] = []
    if path.is_file():
        with closing(_readonly_connection(path)) as connection:
            connection.execute("BEGIN")
            for table in sorted(_table_names(connection)):
                columns = [
                    str(row["name"])
                    for row in connection.execute(f'PRAGMA table_info("{table}")')
                ]
                rows = [dict(row) for row in connection.execute(f'SELECT * FROM "{table}"')]
                rows.sort(key=lambda item: _canonical_bytes(item))
                tables.append(
                    {
                        "table": table,
                        "columns": columns,
                        "row_count": len(rows),
                        "rows_hash": canonical_hash(rows),
                    }
                )
            connection.execute("ROLLBACK")
    return {
        "ledger_path": QUOTA_LEDGER_PATH.as_posix(),
        "ledger_present": path.is_file(),
        "table_count": len(tables),
        "state_hash": canonical_hash(tables),
        "tables": tables,
    }


def oauth_health_snapshot(
    root: Path,
    *,
    deadline: datetime,
    manager_pid: int,
) -> dict[str, Any]:
    """Prove that the normal manager loop cannot make an OAuth probe."""
    root = root.resolve()
    health_path = root / OAUTH_HEALTH_PATH
    refresh_path = root / OAUTH_REFRESH_PATH
    watcher_path = root / OAUTH_WATCHER_PATH
    mirror_path = root / OAUTH_MIRROR_PATH
    connection_path = root / OAUTH_CONNECTION_PATH
    capability_path = root / CAPABILITY_PATH
    blockers: list[str] = []
    health: dict[str, Any] = {}
    refresh: dict[str, Any] = {}
    watcher: dict[str, Any] = {}
    mirror: dict[str, Any] = {}
    connection: dict[str, Any] = {}
    capability: dict[str, Any] = {}
    try:
        health = _read(health_path)
        validate(root, "oauth_session_health.schema.json", health)
    except Exception:
        blockers.append("OAUTH_HEALTH_PROOF_INVALID")
    try:
        refresh = _read(refresh_path)
        validate(root, "oauth_noninteractive_refresh_receipt.schema.json", refresh)
    except Exception:
        blockers.append("OAUTH_REFRESH_PROOF_INVALID")
    next_check_at: datetime | None = None
    if health:
        try:
            next_check_at = _parse(str(health.get("next_check_at")))
        except Exception:
            blockers.append("OAUTH_NEXT_CHECK_UNAVAILABLE")
        if health.get("status") not in {"HEALTHY", "REFRESHED"}:
            blockers.append("OAUTH_HEALTH_NOT_READY")
        if health.get("refresh_receipt_status") != "PASS" or health.get("identity_verified") is not True:
            blockers.append("OAUTH_IDENTITY_NOT_VERIFIED")
    if refresh and refresh.get("status") != "PASS":
        blockers.append("OAUTH_REFRESH_PROOF_NOT_PASS")
    if refresh and next_check_at is not None:
        try:
            expected_next_check = oauth_refresh_due_at(
                str(refresh["tested_at"]),
                interval_seconds=int(health["refresh_interval_seconds"]),
            )
            if next_check_at != expected_next_check:
                blockers.append("OAUTH_HEALTH_REFRESH_CLOCK_DIVERGED")
        except Exception:
            blockers.append("OAUTH_HEALTH_REFRESH_CLOCK_INVALID")
    try:
        watcher = _read(watcher_path)
        validate(root, "oauth_reconsent_watcher_runtime.schema.json", watcher)
        mirror = _read(mirror_path)
        validate(root, "oauth_token_mirror_receipt.schema.json", mirror)
        connection = _read(connection_path)
        validate(root, "youtube_connection_receipt.schema.json", connection)
    except Exception:
        blockers.append("OAUTH_WATCHER_CHAIN_INVALID")
    try:
        capability = _read(capability_path)
        validate(root, "central_manager_maintenance_capability.schema.json", capability)
        if int(capability["manager_pid"]) != manager_pid:
            blockers.append("OAUTH_CAPABILITY_PID_MISMATCH")
    except Exception:
        blockers.append("OAUTH_MANAGER_CAPABILITY_INVALID")

    token_hash: str | None = None
    token_expiry: datetime | None = None
    source_change_pending = True
    if watcher:
        try:
            destination = Path(str(watcher["destination_path"])).resolve()
            source = Path(str(watcher["source_path"])).resolve()
            destination.relative_to(root)
            raise PermissionError("OAuth destination is inside the workspace")
        except ValueError:
            try:
                raw = destination.read_bytes()
                token = json.loads(raw.decode("utf-8-sig"))
                token_hash = hashlib.sha256(raw).hexdigest()
                token_expiry = _parse_token_expiry(str(token["expiry"]))
                if not (
                    token.get("token")
                    and token.get("refresh_token")
                    and OAUTH_SCOPES.issubset(set(token.get("scopes") or []))
                ):
                    blockers.append("OAUTH_RUNTIME_GRANT_INCOMPLETE")
                if refresh.get("token_sha256") != token_hash:
                    blockers.append("OAUTH_TOKEN_REFRESH_BINDING_MISMATCH")
                if capability and (
                    capability.get("runtime_token_hash") != token_hash
                    or capability.get("runtime_token_path_hash")
                    != _hash_bytes(str(destination).encode("utf-8"))
                    or capability.get("runtime_token_expires_at") != _stamp(token_expiry)
                ):
                    blockers.append("OAUTH_RUNTIME_CAPABILITY_BINDING_MISMATCH")
                try:
                    source_change_pending = oauth_source_change_pending(
                        source,
                        destination,
                        mirrored_source_sha256=mirror.get("source_sha256"),
                    )
                except Exception:
                    source_change_pending = True
                    blockers.append("OAUTH_RECONSENT_SOURCE_INVALID")
                if source_change_pending:
                    blockers.append("OAUTH_RECONSENT_SOURCE_CHANGE_PENDING")
            except Exception:
                blockers.append("OAUTH_RUNTIME_TOKEN_INVALID")
        except Exception:
            blockers.append("OAUTH_RUNTIME_TOKEN_NOT_EXTERNAL")
    if watcher and watcher.get("status") != "MIRRORED_AND_REFRESHED":
        blockers.append("OAUTH_WATCHER_NOT_QUIESCENT")
    if connection and not (
        connection.get("status") == "CONNECTED"
        and connection.get("identity_verified") is True
        and (connection.get("observed_channel") or {}).get("channel_id")
        == "UCuMF6pJQkyMzaVoAxFL86yA"
    ):
        blockers.append("OAUTH_CONNECTION_IDENTITY_INVALID")
    return {
        "health_path": OAUTH_HEALTH_PATH.as_posix(),
        "health_hash": file_hash(health_path) if health_path.is_file() else None,
        "health_status": health.get("status") if health else None,
        "next_check_at": _stamp(next_check_at) if next_check_at is not None else None,
        "refresh_path": OAUTH_REFRESH_PATH.as_posix(),
        "refresh_hash": file_hash(refresh_path) if refresh_path.is_file() else None,
        "refresh_receipt_id": refresh.get("receipt_id") if refresh else None,
        "refresh_tested_at": refresh.get("tested_at") if refresh else None,
        "watcher_path": OAUTH_WATCHER_PATH.as_posix(),
        "watcher_hash": file_hash(watcher_path) if watcher_path.is_file() else None,
        "watcher_status": watcher.get("status") if watcher else None,
        "mirror_path": OAUTH_MIRROR_PATH.as_posix(),
        "mirror_hash": file_hash(mirror_path) if mirror_path.is_file() else None,
        "connection_path": OAUTH_CONNECTION_PATH.as_posix(),
        "connection_hash": file_hash(connection_path) if connection_path.is_file() else None,
        "capability_path": CAPABILITY_PATH.as_posix(),
        "capability_hash": file_hash(capability_path) if capability_path.is_file() else None,
        "runtime_token_hash": token_hash,
        "access_token_expires_at": _stamp(token_expiry) if token_expiry is not None else None,
        "source_change_pending": source_change_pending,
        "manager_refresh_due_at": _stamp(next_check_at) if next_check_at is not None else None,
        "blockers": sorted(set(blockers)),
    }


def _pre_oauth_observer_custody(root: Path, *, database_root: Path,
                                queue: dict[str, Any]) -> dict[str, dict[str, str]]:
    """Authenticate dormant, never-dispatched reads without settling their quota.

    This is local maintenance custody, not successful collection, a quota
    refund or permission to repeat an ambiguous request. Queue and ledger bytes
    remain protected by the existing capture/boundary transaction.
    """
    from .central_manager_phase5 import _quota_debit_checkpoint, _validate_owned_preflight
    from .phase5_youtube_publisher import _verify_completed_publication_receipt

    result: dict[str, dict[str, str]] = {}
    ledger = database_root / QUOTA_LEDGER_PATH
    if not ledger.is_file():
        return result
    with closing(_readonly_connection(ledger)) as connection:
        if "general_quota_debits" not in _table_names(connection):
            return result
        for job in queue["jobs"]:
            try:
                if not (job["state"] == "RETRY_WAIT" and job["attempt_count"] == 1
                        and job["max_attempts"] == 2 and job["lease_owner"] is None
                        and job["lease_until"] is None
                        and job["task_type"] == "OWNED_METRICS_CHECKPOINT"
                        and job["operation_id"] == "heroverse-audio-static-longform-v1"
                        and job["last_error"] == "GoogleOperationDeadlineExceeded:Google operation deadline exhausted at oauth.phase6-pilot:before"):
                    continue
                cp, payload = job["checkpoint"], job["payload"]
                old = cp.get("quota_debit") or {}
                if not (cp.get("collection_started") is True
                        and cp.get("quota_debit_ids") == [old.get("debit_id")]
                        and not cp.get("metrics_snapshot") and not cp.get("metrics_snapshot_hash")):
                    continue
                source = root / "output/operations/phase6/intelligence/external-read-checkpoints" / job["job_id"] / "owned-metrics-source.json"
                if source.exists():
                    continue
                row = connection.execute("SELECT * FROM general_quota_debits WHERE idempotency_key=?",
                                         (old.get("idempotency_key"),)).fetchone()
                if row is None:
                    continue
                debit = dict(row)
                if not (debit.get("state") == "RESERVED" and debit.get("consumed_at") is None
                        and debit.get("job_id") == job["job_id"] and debit.get("attempt_count") == 1
                        and debit.get("operation_id") == "phase6_owned_metrics_checkpoint"
                        and debit.get("channel_id") == job["channel_id"]
                        and debit.get("units") == 2 and debit.get("preventive_floor") == 12
                        and debit.get("idempotency_key") == f'audio-owned-metrics:{job["job_id"]}'
                        and _quota_debit_checkpoint(debit) == old):
                    continue
                _validate_owned_preflight(root, job_id=job["job_id"], checkpoint=cp)
                receipts = []
                for path in (root / "output/production").glob("*/youtube-publication-receipt.json"):
                    if file_hash(path) != payload.get("publication_receipt_hash"):
                        continue
                    value = _read(path)
                    _verify_completed_publication_receipt(root, path.parent, value,
                                                          _read(path.parent / "release_gate.json"))
                    if (value["status"] == "COMPLETE_PUBLIC" and value["video_id"] == payload.get("video_id")
                            and value["channel_id"] == job["channel_id"]
                            and value["privacy_status"] == "public"):
                        receipts.append(path)
                if len(receipts) != 1:
                    continue
                if job["idempotency_key"] != (f'audio-owned-metrics:{payload["video_id"]}:'
                        f'{payload["publication_receipt_hash"]}:{payload["scheduled_window"]}'):
                    continue
                result[job["job_id"]] = {
                    "debit_id": debit["debit_id"], "job_hash": canonical_hash(job),
                    "preflight_hash": cp["quota_preflight_hash"],
                    "publication_hash": payload["publication_receipt_hash"],
                }
            except (OSError, KeyError, TypeError, ValueError, sqlite3.Error, ValidationError, PermissionError):
                # Incomplete provenance never turns a reservation into custody.
                continue
    return result


def quota_snapshot(root: Path, *, now: datetime | None = None) -> dict[str, Any]:
    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    path = root / QUOTA_LEDGER_PATH
    reservations: list[dict[str, Any]] = []
    if path.is_file():
        with closing(_readonly_connection(path)) as connection:
            connection.execute("BEGIN")
            tables = _table_names(connection)
            for table, id_field in (
                ("general_quota_debits", "debit_id"),
                ("upload_quota_debits", "debit_id"),
                ("composed_quota_reservations", "reservation_id"),
            ):
                if table not in tables:
                    continue
                rows = connection.execute(
                    f"SELECT * FROM {table} WHERE state='RESERVED' ORDER BY {id_field}"
                ).fetchall()
                for row in rows:
                    item = dict(row)
                    item["table"] = table
                    reservations.append(item)
            connection.execute("ROLLBACK")
    return {
        "schema_version": "1.0.0",
        "ledger_path": QUOTA_LEDGER_PATH.as_posix(),
        "ledger_present": path.is_file(),
        "observed_at": _stamp(observed),
        "reserved_count": len(reservations),
        "reserved_ids": sorted(
            str(item.get("reservation_id") or item.get("debit_id")) for item in reservations
        ),
        "reservations_hash": canonical_hash(reservations),
    }


def _contained_private_thumbnail(root: Path, path: Path) -> dict[str, Any] | None:
    """Stopped private incident custody, not resolution or retry authority."""
    try:
        from .phase6_publication import PublicationLock
        from .phase5_youtube_publisher import read_contained_thumbnail_checkpoint
        if not (root / RUNTIME / 'PAUSE').is_file():
            request = _read(root / REQUEST_PATH)
            validate(root, 'central_manager_maintenance_request.schema.json', request)
            lock = _read(root / RUNTIME / 'manager-lock.json')
            validate(root, 'central_manager_lock.schema.json', lock)
            manager = int((root / RUNTIME / 'manager.pid').read_text('utf-8-sig').strip())
            if (lock['state'] != 'HELD' or manager != lock['holder_pid']
                    or _parse(lock['lease_expires_at']) <= datetime.now(timezone.utc)
                    or not _windows_process_alive(manager)
                    or not _windows_process_alive(request['requester_pid'])):
                return None
        owner = PublicationLock(root)
        # Do not initialize a marker. The OS handle, not the file, excludes
        # an in-flight publisher; PAUSE or a real live request closes dispatch.
        if not owner.path.is_file() or owner.path.read_bytes() != b'0':
            return None
        with owner:
            return read_contained_thumbnail_checkpoint(root, path)
    except (OSError, ValueError, KeyError, PermissionError, ValidationError, RuntimeError):
        return None  # Failed custody authentication leaves the effect blocked.


def operational_effect_snapshot(root: Path, *, contain_private_thumbnail: bool = False) -> dict[str, Any]:
    """Inspect current publication/package receipts without importing executors."""
    root = root.resolve()
    production = root / "output/production"
    candidates: set[Path] = set()
    if production.is_dir():
        candidates.update(production.rglob("youtube-publication-receipt.json"))
        candidates.update(production.rglob("youtube-package-update-receipt.json"))
    excluded = {"archive", "archives", "history", "source-snapshots", "incidents"}
    receipts: list[dict[str, Any]] = []
    open_paths: list[str] = []
    open_statuses = {
        "IN_PROGRESS",
        "PARTIAL_PRIVATE_VIDEO",
        "STAGED_PRIVATE_AWAITING_PROCESSING",
        "PUBLIC_AWAITING_VERIFICATION",
        "PARTIAL_ROLLBACK_REQUIRED",
        "AMBIGUOUS",
    }
    for path in sorted(candidates):
        relative = path.relative_to(root)
        if any(
            part.lower() in excluded
            or "history" in part.lower()
            or "archive" in part.lower()
            for part in relative.parts[:-1]
        ):
            continue
        reasons: list[str] = []
        try:
            value = _read(path)
        except Exception:
            value = {}
            reasons.append("UNREADABLE_RECEIPT")
        if value:
            schema_name = (
                "youtube_publication_receipt.schema.json"
                if path.name == "youtube-publication-receipt.json"
                else "youtube_package_update_receipt.schema.json"
            )
            try:
                validate(root, schema_name, value)
            except Exception:
                reasons.append("SCHEMA_INVALID_RECEIPT")
        status = str(value.get("status") or "UNAVAILABLE")
        if status in open_statuses:
            reasons.append(status)
        journal = value.get("effect_journal")
        if isinstance(journal, list):
            grouped: dict[tuple[str, int, str], list[dict[str, Any]]] = {}
            for item in journal:
                key = (
                    str(item.get("effect_id") or ""),
                    int(item.get("attempt") or 0),
                    str(item.get("request_fingerprint") or ""),
                )
                grouped.setdefault(key, []).append(item)
            for key, items in grouped.items():
                before = [item for item in items if item.get("checkpoint") == "BEFORE"]
                after = [item for item in items if item.get("checkpoint") == "AFTER"]
                if before and not after:
                    reasons.append(f"OPEN_BEFORE:{key[0]}:{key[1]}")
                    continue
                if after and str(after[-1].get("outcome")) in {"AMBIGUOUS", "PENDING"}:
                    reasons.append(f"UNRESOLVED_AFTER:{key[0]}:{key[1]}")
        # Package treatment predates the generic journal. Its status and
        # mutation timestamp are therefore the fail-closed transaction marker.
        if path.name == "youtube-package-update-receipt.json":
            if value.get("mutation_started_at") is not None and status not in {"COMPLETE_PUBLIC_PACKAGE", "ROLLED_BACK"}:
                reasons.append("PACKAGE_MUTATION_NOT_TERMINAL")
            if status == "ROLLED_BACK" and (value.get("rollback") or {}).get("verified") is not True:
                reasons.append("PACKAGE_ROLLBACK_UNVERIFIED")
        item = {
            "path": relative.as_posix(),
            "content_hash": file_hash(path),
            "status": status,
            "open_reasons": sorted(set(reasons)),
        }
        containment = (_contained_private_thumbnail(root, path)
                       if contain_private_thumbnail and reasons in (
                           ['PARTIAL_PRIVATE_VIDEO'], ['PUBLIC_AWAITING_VERIFICATION']) else None)
        if containment is not None and containment['receipt_sha256'] != item['content_hash']:
            containment = None
        if containment is not None:
            # Retain status/open reasons/bytes and the precise observed scope.
            # Only maintenance treats this stopped checkpoint as inert;
            # default snapshots and every normal effect gate remain strict.
            item['contained_for_maintenance'] = containment
        receipts.append(item)
        if reasons and containment is None:
            open_paths.append(relative.as_posix())
    return {
        "receipt_count": len(receipts),
        "receipts_hash": canonical_hash(receipts),
        "open_receipt_paths": sorted(open_paths),
        "receipts": receipts,
    }


def inspect_quiescence(
    root: Path,
    *,
    manager_pid: int,
    guard_seconds: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    pid_path = root / RUNTIME / "manager.pid"
    lock_path = root / RUNTIME / "manager-lock.json"
    blockers: list[str] = []
    if not pid_path.is_file() or not lock_path.is_file():
        blockers.append("MANAGER_PID_OR_LOCK_MISSING")
        pid_value = None
        lock_value: dict[str, Any] = {}
    else:
        try:
            pid_value = int(pid_path.read_text(encoding="utf-8-sig").strip())
            lock_value = _read(lock_path)
        except (ValueError, OSError, json.JSONDecodeError):
            pid_value = None
            lock_value = {}
            blockers.append("MANAGER_PID_OR_LOCK_INVALID")
    lock_pid = int(lock_value.get("holder_pid") or 0)
    if pid_value != manager_pid or lock_pid != manager_pid:
        blockers.append("MANAGER_PID_LOCK_MISMATCH")

    queue = queue_snapshot(root, now=observed)
    leases = list(queue["active_lease_job_ids"])
    if leases:
        blockers.append("ACTIVE_QUEUE_LEASE")
    custody = _pre_oauth_observer_custody(root, database_root=root, queue=queue)
    protected_due = [job for job in _protected_due_jobs(
        queue, deadline=observed + timedelta(seconds=max(0, guard_seconds))
    ) if job not in custody]
    if protected_due:
        blockers.append("PROTECTED_JOB_DUE_DURING_MAINTENANCE")
    all_operational_due = _operational_due_jobs(
        queue, deadline=observed + timedelta(seconds=max(0, guard_seconds))
    )
    inert_media_due = _inert_current_media_due_jobs(root, queue,
                                                  set(all_operational_due) - set(custody))
    operational_due = sorted(set(all_operational_due) - set(inert_media_due) - set(custody))
    if operational_due:
        blockers.append("OPERATIONAL_JOB_DUE_DURING_MAINTENANCE")

    quota = quota_snapshot(root, now=observed)
    ledger = ledger_state_snapshot(root)
    if set(quota["reserved_ids"]) - {item["debit_id"] for item in custody.values()}:
        blockers.append("INCOMPLETE_QUOTA_OR_EXTERNAL_EFFECT")
    effects = operational_effect_snapshot(root, contain_private_thumbnail=True)
    if effects["open_receipt_paths"]:
        blockers.append("INCOMPLETE_OPERATIONAL_EFFECT_JOURNAL")

    return {
        "observed_at": _stamp(observed),
        "manager_pid": manager_pid,
        "pid_path": (RUNTIME / "manager.pid").as_posix(),
        "pid_content_hash": file_hash(pid_path) if pid_path.is_file() else None,
        "lock_path": (RUNTIME / "manager-lock.json").as_posix(),
        "lock_content_hash": file_hash(lock_path) if lock_path.is_file() else None,
        "queue": queue,
        "quota": quota,
        "quota_ledger": ledger,
        "operational_effects": effects,
        "active_lease_job_ids": leases,
        "protected_due_job_ids": protected_due,
        "operational_due_job_ids": operational_due,
        "inert_current_media_due_job_ids": inert_media_due,
        "blockers": sorted(set(blockers)),
    }


def capture_operational_boundary(
    root: Path,
    *,
    manager_pid: int,
    request_id: str,
    guard_seconds: int,
    role: str,
    require_barrier: bool,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Capture one hash-bound, read-only release/verification boundary."""
    root = root.resolve()
    lock_path = root / RUNTIME / "manager-lock.json"
    # Capture one generation BEFORE its observation clock. The manager renews
    # this file atomically: reading after inspect_quiescence compared a newer
    # heartbeat with an older clock, while a separate hash read could bind a
    # different generation. A read failure remains a closed boundary.
    lock_bytes: bytes | None = None
    try:
        lock_bytes = lock_path.read_bytes()
    except OSError:
        pass
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    deadline = observed + timedelta(seconds=max(0, guard_seconds))
    inspection = inspect_quiescence(
        root,
        manager_pid=manager_pid,
        guard_seconds=guard_seconds,
        now=observed,
    )
    blockers = list(inspection["blockers"])
    runtime_lock_hash: str | None = None
    runtime_pid_alive = False
    runtime_lock_held = False
    runtime_lease_valid = False
    try:
        if lock_bytes is None:
            raise ValueError("Manager lock snapshot unavailable")
        lock_value = json.loads(lock_bytes.decode("utf-8-sig"))
        validate(root, "central_manager_lock.schema.json", lock_value)
        runtime_lock_hash = _hash_bytes(lock_bytes)
        runtime_lock_held = (
            lock_value.get("state") == "HELD"
            and int(lock_value.get("holder_pid") or 0) == manager_pid
        )
        runtime_lease_valid = (
            _parse(str(lock_value["heartbeat_at"])) <= observed
            and _parse(str(lock_value["lease_expires_at"])) > observed
        )
    except Exception:
        pass
    runtime_pid_alive, liveness_blockers = _boundary_process_liveness(manager_pid)
    blockers.extend(liveness_blockers)
    if not runtime_lock_held:
        blockers.append("MANAGER_LOCK_NOT_HELD")
    if not runtime_lease_valid:
        blockers.append("MANAGER_LOCK_LEASE_NOT_VALID")
    if inspection["queue"].get("database_present") is not True:
        blockers.append("PHASE6_QUEUE_STORE_MISSING")
    expected_quota_tables = {
        "general_quota_debits",
        "upload_quota_debits",
        "composed_quota_reservations",
    }
    quota_tables = {
        str(item.get("table")) for item in inspection["quota_ledger"].get("tables", [])
    }
    if inspection["quota_ledger"].get("ledger_present") is not True:
        blockers.append("PHASE6_QUOTA_LEDGER_MISSING")
    elif quota_tables != expected_quota_tables:
        blockers.append("PHASE6_QUOTA_LEDGER_TABLES_INVALID")
    expected_publication = (
        "output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json"
    )
    effect_paths = {
        str(item.get("path")) for item in inspection["operational_effects"].get("receipts", [])
    }
    if expected_publication not in effect_paths:
        blockers.append("AUTHORITATIVE_PUBLICATION_RECEIPT_MISSING")
    surface_items: list[dict[str, Any]] = []
    for path_value, schema_name in (
        (
            Path("output/operations/phase6/package-treatment-executor-status.json"),
            "phase6_package_executor_runtime.schema.json",
        ),
        (
            Path("output/operations/phase6/publication-controller-status.json"),
            "phase6_publication_controller_runtime.schema.json",
        ),
    ):
        path = root / path_value
        try:
            value = _read(path)
            validate(root, schema_name, value)
            surface_items.append(
                {"path": path_value.as_posix(), "value": value}
            )
        except Exception:
            blockers.append("EXTERNAL_EFFECT_SURFACE_INVALID")
    by_path = {item["path"]: item["value"] for item in surface_items}
    package = by_path.get(
        "output/operations/phase6/package-treatment-executor-status.json", {}
    )
    package_safe = package.get("status") == "WAITING_FOR_PREREGISTRATION" or (
        package.get("status") == "NOT_DUE"
        and package.get("scheduled_for") is not None
        and _parse(str(package["scheduled_for"])) > deadline
    ) or package.get("status") in {"COMPLETE_PUBLIC_PACKAGE", "ROLLED_BACK"}
    if not package_safe:
        blockers.append("PACKAGE_EFFECT_MAY_BECOME_DUE_DURING_RECOVERY")
    publication = by_path.get(
        "output/operations/phase6/publication-controller-status.json", {}
    )
    if not (
        publication.get("status") == "WAITING"
        and publication.get("quality_evaluation_id") is None
        and publication.get("release_decision") == "WAIT"
        and publication.get("publication_receipt") is None
    ):
        blockers.append("PUBLICATION_EFFECT_SURFACE_NOT_INERT")
    try:
        canary = _read(root / expected_publication)
        validate(root, "youtube_publication_receipt.schema.json", canary)
        if canary.get("status") != "COMPLETE_PUBLIC":
            blockers.append("PHASE5_PUBLICATION_NOT_TERMINAL")
    except Exception:
        blockers.append("PHASE5_PUBLICATION_RECEIPT_INVALID")
    if (root / RUNTIME / "PAUSE").exists():
        blockers.append("PHASE5_MANAGER_PAUSE_TRIGGER_PRESENT")
    try:
        from .central_manager_phase5 import input_fingerprint

        prior_fingerprint = _read(root / RUNTIME / "fingerprint.json").get("input_fingerprint")
        if prior_fingerprint != input_fingerprint(root):
            blockers.append("PHASE5_INPUT_FINGERPRINT_CHANGED")
    except Exception:
        blockers.append("PHASE5_INPUT_FINGERPRINT_INVALID")
    effect_surfaces_hash = canonical_hash([
        {
            "path": item["path"],
            "identity": {
                key: item["value"].get(key)
                for key in (
                    "status", "protocol_id", "candidate", "quality_evaluation",
                    "release_gate", "publication_receipt", "scheduled_for",
                    "quality_evaluation_id", "package", "release",
                    "release_decision", "youtube_video_id", "privacy_status", "error",
                )
            },
        }
        for item in surface_items
    ])
    request_path = root / REQUEST_PATH
    request_hash: str | None = None
    if require_barrier:
        try:
            request = _read(request_path)
            validate(root, "central_manager_maintenance_request.schema.json", request)
            request_hash = file_hash(request_path)
            if request.get("request_id") != request_id:
                blockers.append("MAINTENANCE_BARRIER_REQUEST_MISMATCH")
        except Exception:
            blockers.append("MAINTENANCE_BARRIER_NOT_VALID")
    elif request_path.is_file():
        blockers.append("MAINTENANCE_BARRIER_STILL_ACTIVE_AFTER_RELEASE")

    oauth = oauth_health_snapshot(root, deadline=deadline, manager_pid=manager_pid)
    blockers.extend(oauth["blockers"])
    semantic = {
        "request_id": request_id,
        "role": role,
        "manager_pid": manager_pid,
        "observed_at": _stamp(observed),
        "queue_jobs_hash": inspection["queue"]["jobs_hash"],
        "quota_ledger_state_hash": inspection["quota_ledger"]["state_hash"],
        "operational_effects_hash": inspection["operational_effects"]["receipts_hash"],
        "effect_surfaces_hash": effect_surfaces_hash,
        "oauth_refresh_hash": oauth["refresh_hash"],
    }
    value = {
        "schema_version": "1.0.0",
        "boundary_id": "maintenance-boundary-" + canonical_hash(semantic).split(":", 1)[1][:24],
        "request_id": request_id,
        "role": role,
        "manager_pid": manager_pid,
        "observed_at": _stamp(observed),
        "guard_seconds": guard_seconds,
        "guard_deadline": _stamp(deadline),
        "barrier_required": require_barrier,
        "barrier_request_hash": request_hash,
        "runtime_lock_hash": runtime_lock_hash,
        "runtime_pid_alive": runtime_pid_alive,
        "runtime_lock_held": runtime_lock_held,
        "runtime_lease_valid": runtime_lease_valid,
        "queue_database_present": inspection["queue"]["database_present"],
        "queue_jobs_hash": inspection["queue"]["jobs_hash"],
        "active_lease_job_ids": inspection["active_lease_job_ids"],
        "operational_due_job_ids": inspection["operational_due_job_ids"],
        "quota_ledger_state_hash": inspection["quota_ledger"]["state_hash"],
        "quota_ledger_present": inspection["quota_ledger"]["ledger_present"],
        "quota_ledger_tables": sorted(quota_tables),
        "active_quota_reservation_ids": inspection["quota"]["reserved_ids"],
        "operational_effects_hash": inspection["operational_effects"]["receipts_hash"],
        "effect_surfaces_hash": effect_surfaces_hash,
        "open_effect_receipt_paths": inspection["operational_effects"]["open_receipt_paths"],
        "oauth": oauth,
        "blockers": sorted(set(blockers)),
        "external_effect_boundary_closed": not blockers,
        "technical_cost_brl": 0,
    }
    validate(root, "central_manager_maintenance_boundary.schema.json", value)
    return value


def create_request(
    root: Path = ROOT,
    *,
    request_id: str,
    requester_pid: int,
    guard_seconds: int = 1800,
    requested_at: datetime | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    value = {
        "schema_version": "1.0.0",
        "request_id": request_id,
        "requested_at": _stamp(requested_at or datetime.now(timezone.utc)),
        "requester_pid": requester_pid,
        "mode": "LOCAL_VALIDATION_ONLY",
        "external_effects_permitted": False,
        "protected_due_guard_seconds": guard_seconds,
        "technical_cost_brl": 0,
    }
    validate(root, "central_manager_maintenance_request.schema.json", value)
    _write(root / REQUEST_PATH, value)
    return value


def arm_recovery_window(
    root: Path = ROOT,
    *,
    request_id: str,
    manager_pid: int,
    duration_seconds: int,
    armed_at: datetime | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    observed = (armed_at or datetime.now(timezone.utc)).astimezone(timezone.utc)
    value = {
        "schema_version": "1.0.0",
        "window_id": "maintenance-recovery-" + uuid.uuid4().hex[:24],
        "request_id": request_id,
        "manager_pid": manager_pid,
        "armed_at": _stamp(observed),
        "expires_at": _stamp(observed + timedelta(seconds=duration_seconds)),
        "suppress_oauth_watcher": True,
        "external_effects_permitted": False,
        "technical_cost_brl": 0,
    }
    validate(root, "central_manager_maintenance_recovery_window.schema.json", value)
    _write(root / RECOVERY_WINDOW_PATH, value)
    return value


def recovery_window_state(
    root: Path = ROOT,
    *,
    manager_pid: int,
    now: datetime | None = None,
) -> dict[str, Any] | None:
    root = root.resolve()
    path = root / RECOVERY_WINDOW_PATH
    if not path.is_file():
        return None
    value = _read(path)
    validate(root, "central_manager_maintenance_recovery_window.schema.json", value)
    request_path = root / REQUEST_PATH
    if not request_path.is_file():
        return None
    try:
        request = _read(request_path)
        validate(root, "central_manager_maintenance_request.schema.json", request)
    except Exception:
        return None
    if (
        request.get("request_id") != value.get("request_id")
        or request.get("external_effects_permitted") is not False
        or value.get("external_effects_permitted") is not False
    ):
        return None
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if observed >= _parse(str(value["expires_at"])):
        return None
    if observed < _parse(str(value["armed_at"])):
        raise PermissionError("maintenance recovery window is not temporally valid")
    if int(value["manager_pid"]) != manager_pid:
        raise PermissionError("maintenance recovery window PID mismatch")
    return value


def recovery_window_active(
    root: Path = ROOT,
    *,
    manager_pid: int,
    now: datetime | None = None,
) -> bool:
    return recovery_window_state(root, manager_pid=manager_pid, now=now) is not None


def publish_capability(
    root: Path = ROOT,
    *,
    manager_pid: int,
    holder_started_at: str,
) -> dict[str, Any]:
    root = root.resolve()
    token_value = os.environ.get("HERO_YT_TOKEN_PATH")
    if not token_value:
        raise PermissionError("manager runtime token path is unavailable")
    token_path = Path(token_value).resolve()
    try:
        token_path.relative_to(root)
    except ValueError:
        pass
    else:
        raise PermissionError("manager runtime token must remain outside the workspace")
    token_raw = token_path.read_bytes()
    token = json.loads(token_raw.decode("utf-8-sig"))
    token_expiry = _parse_token_expiry(str(token["expiry"]))
    value = {
        "schema_version": "1.0.0",
        "capability_id": "central-manager-maintenance-handshake-v1",
        "protocol_version": "1.0.0",
        "manager_pid": manager_pid,
        "holder_started_at": holder_started_at,
        "request_path": REQUEST_PATH.as_posix(),
        "ack_path": ACK_PATH.as_posix(),
        "barrier_before_oauth_and_operational_stages": True,
        "malformed_request_fails_closed": True,
        "manager_source_hash": file_hash(root / "hero_engine/central_manager_phase5.py"),
        "protocol_source_hash": file_hash(root / "hero_engine/maintenance_protocol.py"),
        "runtime_token_path_hash": _hash_bytes(str(token_path).encode("utf-8")),
        "runtime_token_hash": hashlib.sha256(token_raw).hexdigest(),
        "runtime_token_expires_at": _stamp(token_expiry),
        "technical_cost_brl": 0,
        "advertised_at": _stamp(datetime.now(timezone.utc)),
    }
    validate(root, "central_manager_maintenance_capability.schema.json", value)
    _write(root / CAPABILITY_PATH, value)
    return value


def refresh_capability_token_binding(
    root: Path = ROOT,
    *,
    manager_pid: int,
    holder_started_at: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Repin a live manager capability after a legitimate token refresh.

    The manager and protocol source hashes deliberately remain those advertised
    by this process generation at boot.  Re-reading those hashes from disk here
    would let an already-running process claim code that it has not loaded.
    Only the external token binding and advertisement timestamp may change.
    """

    root = root.resolve()
    capability_path = root / CAPABILITY_PATH
    current = _read(capability_path)
    validate(root, "central_manager_maintenance_capability.schema.json", current)
    if int(current["manager_pid"]) != int(manager_pid):
        raise PermissionError("maintenance capability PID does not match the live manager")
    if _parse(str(current["holder_started_at"])) != _parse(str(holder_started_at)):
        raise PermissionError("maintenance capability lock generation does not match the live manager")

    token_value = os.environ.get("HERO_YT_TOKEN_PATH")
    if not token_value:
        raise PermissionError("manager runtime token path is unavailable")
    token_path = Path(token_value).resolve()
    try:
        token_path.relative_to(root)
    except ValueError:
        pass
    else:
        raise PermissionError("manager runtime token must remain outside the workspace")
    token_raw = token_path.read_bytes()
    token = json.loads(token_raw.decode("utf-8-sig"))
    token_expiry = _parse_token_expiry(str(token["expiry"]))
    binding = {
        "runtime_token_path_hash": _hash_bytes(str(token_path).encode("utf-8")),
        "runtime_token_hash": hashlib.sha256(token_raw).hexdigest(),
        "runtime_token_expires_at": _stamp(token_expiry),
    }
    if all(current.get(key) == value for key, value in binding.items()):
        return current

    refreshed = dict(current)
    refreshed.update(binding)
    refreshed["advertised_at"] = _stamp(now or datetime.now(timezone.utc))
    validate(root, "central_manager_maintenance_capability.schema.json", refreshed)
    _write(capability_path, refreshed)
    return refreshed


def acknowledge_request(
    root: Path = ROOT,
    *,
    manager_pid: int,
    now: datetime | None = None,
) -> dict[str, Any] | None:
    root = root.resolve()
    request_path = root / REQUEST_PATH
    if not request_path.is_file():
        return None
    request = _read(request_path)
    validate(root, "central_manager_maintenance_request.schema.json", request)
    inspection = inspect_quiescence(
        root,
        manager_pid=manager_pid,
        guard_seconds=int(request["protected_due_guard_seconds"]),
        now=now,
    )
    status = "READY_TO_STOP" if not inspection["blockers"] else "DEFERRED"
    semantic = {
        "request_id": request["request_id"],
        "manager_pid": manager_pid,
        "observed_at": inspection["observed_at"],
        "queue_hash": inspection["queue"]["jobs_hash"],
        "quota_hash": inspection["quota"]["reservations_hash"],
        "blockers": inspection["blockers"],
    }
    value = {
        "schema_version": "1.0.0",
        "ack_id": "maintenance-ack-" + canonical_hash(semantic).split(":", 1)[1][:24],
        "request_id": request["request_id"],
        "status": status,
        "observed_at": inspection["observed_at"],
        "manager_pid": manager_pid,
        "pid_path": inspection["pid_path"],
        "pid_content_hash": inspection["pid_content_hash"],
        "lock_path": inspection["lock_path"],
        "lock_content_hash": inspection["lock_content_hash"],
        "queue_jobs_hash": inspection["queue"]["jobs_hash"],
        "active_lease_job_ids": inspection["active_lease_job_ids"],
        "protected_due_job_ids": inspection["protected_due_job_ids"],
        "operational_due_job_ids": inspection["operational_due_job_ids"],
        "active_quota_reservation_ids": inspection["quota"]["reserved_ids"],
        "open_effect_receipt_paths": inspection["operational_effects"]["open_receipt_paths"],
        "blockers": inspection["blockers"],
        "external_effect_boundary_closed": status == "READY_TO_STOP",
        "technical_cost_brl": 0,
    }
    validate(root, "central_manager_maintenance_ack.schema.json", value)
    _write(root / ACK_PATH, value)
    return value


def maintenance_barrier(root: Path = ROOT, *, manager_pid: int | None = None) -> bool:
    """Return True while the manager must perform no operational work.

    A malformed request is also a closed barrier: maintenance never turns a
    parse/schema failure into permission to run an API or publication stage.
    """
    root = root.resolve()
    if not (root / REQUEST_PATH).is_file():
        return False
    try:
        acknowledge_request(root, manager_pid=manager_pid or os.getpid())
    except Exception:
        # Do not create an unvalidated synthetic ACK. The requester will time
        # out, and the manager remains inert until the bad request is removed.
        return True
    return True


class ProcessLivenessProbeError(RuntimeError):
    """The operating system could not prove whether one exact PID is alive."""


_WINDOWS_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
_WINDOWS_STILL_ACTIVE = 259
_WINDOWS_ERROR_INVALID_PARAMETER = 87


def _windows_process_api() -> Any:
    """Load a read-only Windows process-query API with explicit signatures."""

    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    return kernel32


def _windows_process_alive(
    process_id: int,
    *,
    api: Any | None = None,
    get_last_error: Any | None = None,
) -> bool:
    """Query one Windows PID without signalling or mutating its process.

    ``False`` is returned only for a definitive missing/terminated process.
    Access denial and API failures remain distinguishable and fail closed.
    """

    import ctypes
    from ctypes import wintypes

    if process_id <= 0:
        return False
    kernel32 = api or _windows_process_api()
    last_error = get_last_error or ctypes.get_last_error
    handle = kernel32.OpenProcess(
        _WINDOWS_PROCESS_QUERY_LIMITED_INFORMATION,
        False,
        process_id,
    )
    if not handle:
        error_code = int(last_error())
        if error_code == _WINDOWS_ERROR_INVALID_PARAMETER:
            return False
        raise ProcessLivenessProbeError(
            f"OpenProcess could not determine PID {process_id} liveness "
            f"(winerror={error_code})"
        )

    exit_code = wintypes.DWORD()
    query_ok = bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)))
    query_error = None if query_ok else int(last_error())
    close_ok = bool(kernel32.CloseHandle(handle))
    close_error = None if close_ok else int(last_error())
    if query_error is not None:
        detail = f"winerror={query_error}"
        if close_error is not None:
            detail += f",close_winerror={close_error}"
        raise ProcessLivenessProbeError(
            f"GetExitCodeProcess could not determine PID {process_id} liveness ({detail})"
        )
    if close_error is not None:
        raise ProcessLivenessProbeError(
            f"CloseHandle failed after probing PID {process_id} "
            f"(winerror={close_error})"
        )
    return int(exit_code.value) == _WINDOWS_STILL_ACTIVE


def _process_alive(process_id: int) -> bool:
    if process_id <= 0:
        return False
    if os.name == "nt":
        return _windows_process_alive(process_id)
    try:
        os.kill(process_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # POSIX EPERM proves that the process exists even though it cannot be
        # signalled. Treating it as alive is the fail-closed migration result.
        return True
    except OSError as exc:
        if exc.errno == errno.ESRCH:
            return False
        if exc.errno == errno.EPERM:
            return True
        raise ProcessLivenessProbeError(
            f"POSIX PID {process_id} liveness probe failed (errno={exc.errno})"
        ) from exc
    return True


def _boundary_process_liveness(process_id: int) -> tuple[bool, list[str]]:
    """Keep a definitive dead result distinct from an unavailable probe."""

    try:
        alive = _process_alive(process_id)
    except ProcessLivenessProbeError:
        return False, ["MANAGER_PROCESS_LIVENESS_PROBE_UNAVAILABLE"]
    if alive:
        return True, []
    return False, ["MANAGER_PROCESS_NOT_ALIVE"]


def _require_process_stopped(process_id: int, *, role: str) -> None:
    """Fail closed unless the OS definitively reports the exact PID stopped."""

    try:
        alive = _process_alive(process_id)
    except ProcessLivenessProbeError as exc:
        raise PermissionError(
            f"local migration cannot prove {role} PID {process_id} is stopped: "
            "liveness probe unavailable"
        ) from exc
    if alive:
        raise PermissionError(
            f"local migration requires {role} PID {process_id} to be stopped"
        )


# Explicit paused cancellation only. The running barrier and daily cleanup keep
# their existing contracts; neither calls this entry point automatically.
_PAUSED_CANCEL_MUTEX_NAME = r"Local\HeroEngine.ModelagemYoutube.DailyMaintenance.v1"
_PAUSED_CANCEL_ARCHIVE = RUNTIME / "maintenance-cancellations"


def _paused_cancel_kernel():
    if os.name != "nt":
        raise PermissionError("CANCEL_EXCLUSIVITY_UNAVAILABLE: Windows required")
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    signatures = {
        "CreateMutexW": ([ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR], wintypes.HANDLE),
        "WaitForSingleObject": ([wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
        "ReleaseMutex": ([wintypes.HANDLE], wintypes.BOOL),
        "CloseHandle": ([wintypes.HANDLE], wintypes.BOOL),
        "CreateFileW": ([wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                         ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
                         wintypes.HANDLE], wintypes.HANDLE),
        "SetFileInformationByHandle": ([wintypes.HANDLE, ctypes.c_int,
                                        ctypes.c_void_p, wintypes.DWORD], wintypes.BOOL),
        "GetFileSizeEx": ([wintypes.HANDLE, ctypes.POINTER(ctypes.c_longlong)], wintypes.BOOL),
        "SetFilePointerEx": ([wintypes.HANDLE, ctypes.c_longlong,
                              ctypes.POINTER(ctypes.c_longlong), wintypes.DWORD], wintypes.BOOL),
        "ReadFile": ([wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
                      ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p], wintypes.BOOL),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(kernel, name)
        function.argtypes, function.restype = arguments, result
    return ctypes, kernel


@contextmanager
def _paused_cancel_exclusive():
    ctypes, kernel = _paused_cancel_kernel()
    handle = kernel.CreateMutexW(None, False, _PAUSED_CANCEL_MUTEX_NAME)
    if not handle:
        raise PermissionError("CANCEL_EXCLUSIVITY_UNAVAILABLE")
    owned = False
    try:
        # WAIT_ABANDONED grants mutex ownership, NOT ownership of any request.
        outcome = kernel.WaitForSingleObject(handle, 0)
        owned = outcome in (0, 0x80)
        if not owned:
            raise PermissionError("CANCEL_EXCLUSIVITY_BUSY_OR_UNKNOWN")
        yield
    finally:
        released = not owned or bool(kernel.ReleaseMutex(handle))
        closed = bool(kernel.CloseHandle(handle))
        if not released or not closed:
            raise PermissionError("CANCEL_EXCLUSIVITY_RELEASE_UNCONFIRMED")


def _paused_cancel_safe_path(root: Path, path: Path) -> None:
    path.relative_to(root)
    for candidate in (path, *path.parents):
        if candidate.exists() or candidate.is_symlink():
            info = candidate.lstat()
            if candidate.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
                raise PermissionError("CANCEL_REPARSE_PATH_BLOCKED")
        if candidate == root:
            break


class _PausedCancelPin:
    """Deny writes/replacement; deletion targets the validated HANDLE, not a path.

    These handles are not a new maintenance mechanism. They close the TOCTOU
    gap between exact-byte authorization and removal inside the existing mutex.
    """

    def __init__(self, path: Path, *, deletable: bool = False, capture: bool = True):
        self.path, self.deletable, self.capture = path, deletable, capture
        self.ctypes, self.kernel = _paused_cancel_kernel()
        access = 0x80000000 | (0x10000 if deletable else 0)  # READ | DELETE
        self.handle = self.kernel.CreateFileW(str(path), access, 1, None, 3, 0x200000, None)
        if self.handle == self.ctypes.c_void_p(-1).value:
            self.handle = None
            raise PermissionError("CANCEL_FILE_EXCLUSIVITY_UNAVAILABLE: " + path.name)
        try:
            info = path.lstat()
            if not path.is_file() or info.st_nlink != 1 or getattr(info, "st_file_attributes", 0) & 0x400:
                raise PermissionError("CANCEL_FILE_IDENTITY_UNSAFE")
            if capture and info.st_size > 8 * 1024 * 1024:
                raise PermissionError("CANCEL_EVIDENCE_SIZE_UNSUPPORTED")
            self.identity = (info.st_dev, info.st_ino)
            self.payload = self._read_handle() if capture else None
        except BaseException:
            self.close()
            raise

    def _read_handle(self):
        size = self.ctypes.c_longlong()
        if not self.kernel.GetFileSizeEx(self.handle, self.ctypes.byref(size)) or not 0 <= size.value <= 8 * 1024 * 1024:
            raise PermissionError("CANCEL_EVIDENCE_SIZE_UNAVAILABLE")
        if not self.kernel.SetFilePointerEx(self.handle, 0, None, 0):
            raise PermissionError("CANCEL_EVIDENCE_READ_UNAVAILABLE")
        buffer = self.ctypes.create_string_buffer(max(1, size.value))
        received = self.ctypes.c_ulong()
        if not self.kernel.ReadFile(self.handle, buffer, size.value, self.ctypes.byref(received), None) or received.value != size.value:
            raise PermissionError("CANCEL_EVIDENCE_READ_INCOMPLETE")
        return buffer.raw[:size.value]

    def revalidate(self):
        if self.handle is None:
            raise PermissionError("CANCEL_FILE_PROTECTION_LOST")
        size = self.ctypes.c_longlong()
        if not self.kernel.GetFileSizeEx(self.handle, self.ctypes.byref(size)):
            raise PermissionError("CANCEL_FILE_PROTECTION_UNCONFIRMED")
        info = self.path.lstat()
        if (info.st_dev, info.st_ino) != self.identity or info.st_nlink != 1:
            raise PermissionError("CANCEL_FILE_OWNERSHIP_CHANGED")
        if self.capture and self._read_handle() != self.payload:
            raise PermissionError("CANCEL_FILE_BYTES_CHANGED")

    def remove(self):
        if not self.deletable or self.handle is None:
            raise PermissionError("CANCEL_FILE_NOT_OWNED_FOR_REMOVAL")
        self.revalidate()
        disposition = self.ctypes.c_ubyte(1)  # FILE_DISPOSITION_INFO.DeleteFile
        if not self.kernel.SetFileInformationByHandle(
            self.handle, 4, self.ctypes.byref(disposition), self.ctypes.sizeof(disposition)
        ):
            raise PermissionError("CANCEL_EXACT_HANDLE_REMOVAL_FAILED")
        self.close()
        # No retry or path-based fallback, including a replacement appearing now.
        if self.path.exists():
            raise PermissionError("CANCEL_REMOVAL_NOT_SETTLED")

    def close(self):
        if self.handle is not None:
            handle, self.handle = self.handle, None
            if not self.kernel.CloseHandle(handle):
                raise PermissionError("CANCEL_FILE_HANDLE_CLOSE_UNCONFIRMED")


def _paused_cancel_absent(process_id: int, role: str) -> dict[str, Any]:
    try:
        absent = _process_alive(process_id) is False
    except Exception as exc:
        raise PermissionError("CANCEL_" + role + "_IDENTITY_UNCERTAIN") from exc
    # A live reused PID is blocked as live. The historic request has no generation
    # and this path must never manufacture one or infer absence from uncertainty.
    if not absent:
        raise PermissionError("CANCEL_" + role + "_NOT_PROVEN_ABSENT")
    return {"pid": process_id, "role": role, "disposition": "ABSENT",
            "observed_at": _stamp(datetime.now(timezone.utc)),
            "scope": "OS_PID_ABSENCE_NO_GENERATION_ASSERTED"}


def _paused_cancel_database_files(root: Path) -> list[Path]:
    """Complete, narrow inventory: legacy no-sidecar or the proven empty-WAL set."""
    files = []
    for relative in (QUEUE_PATH, QUOTA_LEDGER_PATH):
        base = root / relative
        if not base.is_file():
            raise PermissionError("CANCEL_DATABASE_STATE_UNAVAILABLE")
        companions = sorted(base.parent.glob(base.name + "*"))
        suffixes = {path.name[len(base.name):] for path in companions}
        allowed = {"", "-wal", "-shm"} | ({".lock"} if relative == QUOTA_LEDGER_PATH else set())
        if not suffixes.issubset(allowed) or ("-wal" in suffixes) != ("-shm" in suffixes):
            raise PermissionError("CANCEL_DATABASE_SET_UNKNOWN_OR_INCOMPLETE")
        for path in companions:
            _paused_cancel_safe_path(root, path)
            if not path.is_file():
                raise PermissionError("CANCEL_DATABASE_COMPANION_INVALID")
            suffix = path.name[len(base.name):]
            if suffix == "-wal" and path.stat().st_size != 0:
                raise PermissionError("CANCEL_NONEMPTY_WAL_UNSUPPORTED")
            if suffix == "-shm" and path.stat().st_size != 32768:
                raise PermissionError("CANCEL_SHM_STATE_UNSUPPORTED")
            files.append(path.relative_to(root))
    return files


def _paused_cancel_verify_capture(archive, binding, reference, *, stack=None):
    if (not isinstance(reference, dict) or set(reference) != {"path", "sha256"}
            or reference["path"] != "databases/manifest.json"):
        raise PermissionError("CANCEL_CAPTURE_REFERENCE_INVALID")
    path = archive / reference["path"]

    def protect(target):
        _paused_cancel_safe_path(archive, target)
        if stack is not None:
            stack.enter_context(closing(_PausedCancelPin(target)))

    protect(path)
    if file_hash(path) != reference["sha256"]:
        raise PermissionError("CANCEL_CAPTURE_MANIFEST_CHANGED")
    manifest = _read(path)
    source_root = archive.parents[len(_PAUSED_CANCEL_ARCHIVE.parts)]
    if (manifest.get("schema_version") != "1.0.0" or manifest.get("binding") != binding
            or manifest.get("root") != str(source_root)
            or manifest.get("policy") != "CURRENT_EMPTY_WAL_PROTECTED_COPY_V1"
            or manifest.get("original_sqlite_connections") != 0):
        raise PermissionError("CANCEL_CAPTURE_BINDING_INVALID")
    evidence_root = archive / "databases/evidence"
    files = manifest.get("files")
    if not isinstance(files, list) or not 2 <= len(files) <= 7:
        raise PermissionError("CANCEL_CAPTURE_FILE_SET_INVALID")
    relative_paths = [item["relative"] for item in files]
    if (len(set(relative_paths)) != len(relative_paths)
            or set(relative_paths) != {path.as_posix() for path in _paused_cancel_database_files(evidence_root)}):
        raise PermissionError("CANCEL_CAPTURE_FILE_SET_CHANGED")
    for item in files:
        target = evidence_root / item["relative"]
        protect(target)
        if target.stat().st_size != item["size_bytes"] or file_hash(target) != item["sha256"]:
            raise PermissionError("CANCEL_CAPTURE_EVIDENCE_CHANGED")
    return manifest


class _PausedCancelDatabaseCapture:
    """A current cancellation-scoped capture, never a caller-supplied prior PASS.

    Reuses Task 4's simultaneous source pins and separate evidence/work copies.
    The owning cancellation's ExitStack retains source protection through commit.
    SQLite is allowed only on work_root; no checkpoint or mode change is needed.
    """

    def __init__(self, root, archive, binding, stack):
        self.root, self.archive, self.binding = root, archive, binding
        self.paths = _paused_cancel_database_files(root)
        self.source_pins = {}
        self.copy_pins = []
        for relative in self.paths:
            self.source_pins[relative] = stack.enter_context(closing(
                _PausedCancelPin(root / relative, capture=False)))
        if _paused_cancel_database_files(root) != self.paths:
            raise PermissionError("CANCEL_DATABASE_SET_CHANGED_DURING_CAPTURE")
        self.work_root = Path(stack.enter_context(TemporaryDirectory(prefix="hero-paused-cancel-db-")))
        self.manifest_path = archive / "databases/manifest.json"
        self.manifest = {"schema_version": "1.0.0", "binding": binding, "root": str(root),
                         "capture_id": uuid.uuid4().hex, "captured_at": _stamp(datetime.now(timezone.utc)),
                         "policy": "CURRENT_EMPTY_WAL_PROTECTED_COPY_V1", "files": [],
                         "implementation_hash": file_hash(Path(__file__)), "original_sqlite_connections": 0}
        for relative, source_pin in self.source_pins.items():
            source_pin.revalidate()
            raw = source_pin._read_handle()  # Existing bounded native reader, no SQLite on origin.
            digest = _hash_bytes(raw)
            evidence = archive / "databases/evidence" / relative
            work = self.work_root / relative
            _write_immutable_bytes(evidence, raw)
            _write_immutable_bytes(work, raw)
            for target in (evidence, work):
                _paused_cancel_safe_path(archive if target == evidence else self.work_root, target)
                # SHM in work is SQLite's disposable index, not authoritative data.
                if target == evidence or not target.name.endswith("-shm"):
                    self.copy_pins.append(stack.enter_context(closing(_PausedCancelPin(target))))
                if file_hash(target) != digest:
                    raise PermissionError("CANCEL_CAPTURE_COPY_DIVERGED")
            self.manifest["files"].append({"relative": relative.as_posix(), "size_bytes": len(raw),
                                           "sha256": digest, "source_identity": list(source_pin.identity)})
        _write_immutable_bytes(self.manifest_path, _canonical_bytes(self.manifest))
        self.copy_pins.append(stack.enter_context(closing(_PausedCancelPin(self.manifest_path))))
        self.revalidate()
        # Current whole-database integrity, not a historical Task 4 verdict.
        for relative in (QUEUE_PATH, QUOTA_LEDGER_PATH):
            with closing(_readonly_connection(self.work_root / relative)) as connection:
                connection.execute("BEGIN")
                try:
                    if ([row[0] for row in connection.execute("PRAGMA integrity_check")] != ["ok"]
                            or connection.execute("PRAGMA foreign_key_check").fetchall()):
                        raise PermissionError("CANCEL_CAPTURE_DATABASE_INTEGRITY_FAILED")
                    if Path(str(relative) + "-wal") in self.paths and connection.execute("PRAGMA journal_mode").fetchone()[0] != "wal":
                        raise PermissionError("CANCEL_CAPTURE_WAL_MODE_MISMATCH")
                finally:
                    connection.execute("ROLLBACK")
        self.revalidate()

    def reference(self):
        return {"path": "databases/manifest.json", "sha256": _hash_bytes(_canonical_bytes(self.manifest))}

    @staticmethod
    def _is_queue_source(relative: Path) -> bool:
        """Return whether a captured companion belongs to the mutable queue edge."""
        return relative == QUEUE_PATH or str(relative).startswith(str(QUEUE_PATH) + "-")

    def release_queue_sources_for_owned_commit(self) -> None:
        """Release only the queue-origin read handles immediately before its own commit.

        The cancellation capture intentionally opens origins with FILE_SHARE_READ,
        which prevents every writer, including the one reviewed forward queue edge.
        The evidence and work copies remain pinned, as do quota-origin handles.
        This is a narrow, one-way release: callers must already have revalidated
        the complete capture and must authenticate the exact committed edge before
        accepting any post-write state.
        """
        if getattr(self, "_queue_sources_released", False):
            raise PermissionError("CANCEL_QUEUE_WRITE_RELEASE_REPEATED")
        self.revalidate()
        released = []
        for relative, pin in self.source_pins.items():
            if self._is_queue_source(relative):
                pin.close()
                released.append(relative)
        if not released or any(pin.handle is not None for relative, pin in self.source_pins.items()
                               if self._is_queue_source(relative)):
            raise PermissionError("CANCEL_QUEUE_WRITE_RELEASE_UNCONFIRMED")
        self._queue_sources_released = True

    def revalidate_after_owned_queue_commit(self) -> None:
        """Revalidate every still-immutable capture boundary after the queue edge.

        The queue origin may now have its own WAL/SHM representation, so it cannot
        be compared to the pre-commit source bytes.  Its exact allowed mutation is
        checked by the queue receipt reader at the call site.  Quota origins and
        all immutable evidence/work copies remain byte-pinned here.
        """
        if not getattr(self, "_queue_sources_released", False):
            raise PermissionError("CANCEL_QUEUE_WRITE_RELEASE_MISSING")
        for item in self.manifest["files"]:
            relative = Path(item["relative"])
            if self._is_queue_source(relative):
                continue
            source_pin = self.source_pins[relative]
            source_pin.revalidate()
            if _hash_bytes(source_pin._read_handle()) != item["sha256"]:
                raise PermissionError("CANCEL_CAPTURE_SOURCE_CHANGED")
        for pin in self.copy_pins:
            pin.revalidate()
        _paused_cancel_verify_capture(self.archive, self.binding, self.reference())

    def revalidate(self):
        if _paused_cancel_database_files(self.root) != self.paths:
            raise PermissionError("CANCEL_DATABASE_SET_CHANGED")
        for relative in (QUEUE_PATH, QUOTA_LEDGER_PATH):
            base = self.work_root / relative
            # SQLite's read-only WAL open may create its private, disposable
            # ``-wal``/``-shm`` pair in the work copy.  It cannot alter the
            # pinned source or the immutable evidence copy, but it must still
            # be constrained to the exact native empty-WAL representation.
            # Any other companion, a partial pair, or non-empty WAL remains a
            # hard failure rather than being silently tolerated as churn.
            work_files = list(base.parent.glob(base.name + "*"))
            names = {target.name for target in work_files}
            allowed = {base.name, base.name + "-wal", base.name + "-shm"}
            if relative == QUOTA_LEDGER_PATH:
                # This is a captured legacy companion, not SQLite-generated
                # work churn; it remains protected by its own work-copy pin.
                allowed.add(base.name + ".lock")
            if (base.name not in names or not names.issubset(allowed)
                    or (base.name + "-wal" in names) != (base.name + "-shm" in names)):
                raise PermissionError("CANCEL_WORK_DATABASE_SET_CHANGED")
            for target in work_files:
                _paused_cancel_safe_path(self.work_root, target)
                if not target.is_file():
                    raise PermissionError("CANCEL_WORK_DATABASE_SET_CHANGED")
                if target.name == base.name + "-wal" and target.stat().st_size != 0:
                    raise PermissionError("CANCEL_WORK_DATABASE_SET_CHANGED")
                if target.name == base.name + "-shm" and target.stat().st_size != 32768:
                    raise PermissionError("CANCEL_WORK_DATABASE_SET_CHANGED")
        for item in self.manifest["files"]:
            relative = Path(item["relative"])
            source_pin = self.source_pins[relative]
            source_pin.revalidate()
            if _hash_bytes(source_pin._read_handle()) != item["sha256"]:
                raise PermissionError("CANCEL_CAPTURE_SOURCE_CHANGED")
        for pin in self.copy_pins:
            pin.revalidate()
        _paused_cancel_verify_capture(self.archive, self.binding, self.reference())


def _paused_cancel_boundary(root: Path, *, database_root: Path,
                            contain_private_thumbnail: bool = False) -> dict[str, Any]:
    # Only the database queries move to work. External journals remain at root.
    queue = queue_snapshot(database_root)
    if queue["active_lease_job_ids"]:
        raise PermissionError("CANCEL_ACTIVE_LEASE")
    if any(job["state"] not in {"PENDING", "LEASED", "RETRY_WAIT", "SUCCEEDED", "DEAD_LETTER"}
           for job in queue["jobs"]):
        raise PermissionError("CANCEL_UNKNOWN_QUEUE_STATE")
    custody = _pre_oauth_observer_custody(root, database_root=database_root, queue=queue)
    custody_debits = {item["debit_id"] for item in custody.values()}
    with closing(_readonly_connection(database_root / QUOTA_LEDGER_PATH)) as connection:
        for table in ("general_quota_debits", "upload_quota_debits", "composed_quota_reservations"):
            if table not in _table_names(connection):
                raise PermissionError("CANCEL_QUOTA_TABLE_MISSING")
            states = connection.execute(f'SELECT * FROM "{table}"').fetchall()
            if any(row["state"] != "CONSUMED" and not (
                    table == "general_quota_debits" and row["state"] == "RESERVED"
                    and row["debit_id"] in custody_debits) for row in states):
                raise PermissionError("CANCEL_RESERVATION_OR_UNKNOWN_QUOTA_STATE")
    quota = quota_snapshot(database_root)
    if set(quota["reserved_ids"]) - custody_debits:
        raise PermissionError("CANCEL_ACTIVE_RESERVATION")
    effects = operational_effect_snapshot(root, contain_private_thumbnail=contain_private_thumbnail)
    # An absent inventory is not proof that effects are closed. This project has
    # publication receipts; this narrow entry does not support an uninitialized root.
    if not effects["receipt_count"] or effects["open_receipt_paths"]:
        raise PermissionError("CANCEL_OPEN_OR_UNKNOWN_EFFECT")
    for item in effects["receipts"]:
        path = root / item["path"]
        _paused_cancel_safe_path(root, path)
        publication = path.name == "youtube-publication-receipt.json"
        try:
            validate(root, "youtube_publication_receipt.schema.json" if publication
                     else "youtube_package_update_receipt.schema.json", _read(path))
        except ValidationError as exc:
            raise PermissionError("CANCEL_EFFECT_SCHEMA_INVALID") from exc
        terminal = {"COMPLETE_PUBLIC"} if publication else {"COMPLETE_PUBLIC_PACKAGE", "ROLLED_BACK"}
        containment = item.get('contained_for_maintenance')
        contained_scope = (
            item['status'] == 'PARTIAL_PRIVATE_VIDEO'
            and isinstance(containment, dict)
            and containment.get('purpose') == 'CONTAINED_PRIVATE_THUMBNAIL_FOR_LOCAL_MAINTENANCE_ONLY'
            and containment.get('remote_thumbnail_outcome') == 'UNKNOWN') or (
            item['status'] == 'PUBLIC_AWAITING_VERIFICATION'
            and isinstance(containment, dict)
            and containment.get('purpose') == 'CONTAINED_OBSERVED_PUBLIC_FOR_LOCAL_MAINTENANCE_ONLY'
            and containment.get('remote_thumbnail_outcome') == 'OBSERVED')
        contained = (contain_private_thumbnail and contained_scope
            and isinstance(containment, dict)
            and containment.get('receipt_sha256') == item['content_hash']
            and containment.get('remote_recovery_authorized') is False
            and containment.get('upload_authorized') is False
            and containment.get('publication_authorized') is False)
        if item["status"] not in terminal and not contained:
            raise PermissionError("CANCEL_EFFECT_NOT_PROVEN_TERMINAL")
    return {"queue_jobs_hash": queue["jobs_hash"],
            "ledger_state_hash": ledger_state_snapshot(database_root)["state_hash"],
            "quota_reservations_hash": quota["reservations_hash"], "effects": effects}


def _paused_cancel_check_absence(archive: Path, proofs: Any, latest: str) -> None:
    expected = [("REQUESTER", _read(archive / "request.json")["requester_pid"]),
                ("MANAGER", _read(archive / "ack.json")["manager_pid"])]
    if not isinstance(proofs, list) or len(proofs) != 2:
        raise PermissionError("CANCEL_ABSENCE_EVIDENCE_INVALID")
    for proof, (role, pid) in zip(proofs, expected):
        if (not isinstance(proof, dict) or proof.get("pid") != pid or proof.get("role") != role
                or proof.get("disposition") != "ABSENT"
                or proof.get("scope") != "OS_PID_ABSENCE_NO_GENERATION_ASSERTED"
                or not isinstance(proof.get("observed_at"), str)
                or not (_parse(proof["observed_at"]) <= _parse(latest) <= datetime.now(timezone.utc))):
            raise PermissionError("CANCEL_ABSENCE_EVIDENCE_INVALID")


def _paused_cancel_read_archive(archive: Path, binding: dict[str, str]) -> dict[str, Any]:
    prepared = _read(archive / "prepared.json")
    if (prepared.get("binding") != binding or prepared.get("status") != "PREPARED"
            or prepared.get("schema_version") not in {"1.0.0", "1.1.0"}
            or prepared.get("decision") != "EXACT_ORPHAN_CANCEL_UNDER_OWNER_PAUSE"
            or prepared.get("restart_permitted") is not False
            or prepared.get("exclusive_acquired") is not True
            or prepared.get("exclusive_mutex") != _PAUSED_CANCEL_MUTEX_NAME):
        raise PermissionError("CANCEL_ARCHIVE_BINDING_INVALID")
    expected_files = {"request.json", "ack.json", "PAUSE", "manager.pid", "manager-lock.json", "boundary.json"}
    if set(prepared.get("evidence_hashes", {})) != expected_files:
        raise PermissionError("CANCEL_ARCHIVE_MANIFEST_INVALID")
    for name, digest in prepared["evidence_hashes"].items():
        path = archive / name
        _paused_cancel_safe_path(archive, path)
        if file_hash(path) != digest:
            raise PermissionError("CANCEL_ARCHIVE_EVIDENCE_CHANGED")
    if (prepared["evidence_hashes"]["request.json"] != binding["request_hash"]
            or prepared["evidence_hashes"]["ack.json"] != binding["ack_hash"]):
        raise PermissionError("CANCEL_ARCHIVE_REQUEST_OR_ACK_CHANGED")
    _paused_cancel_check_absence(archive, prepared.get("absence_checks"), prepared["prepared_at"])
    if prepared["schema_version"] == "1.1.0":
        _paused_cancel_verify_capture(archive, binding, prepared.get("database_capture"))
    elif "database_capture" in prepared:
        raise PermissionError("CANCEL_LEGACY_CAPTURE_CONTRACT_MISMATCH")
    return prepared


def _paused_cancel_is_capture_only_archive(archive: Path, binding: dict[str, str]) -> bool:
    """Recognize an interrupted capture that removed no request marker.

    The failed capture is immutable evidence, not disposable scratch space.  A
    subsequent cancellation gets a distinct sibling archive only when this
    exact, fully verifiable pre-prepare shape is present.
    """
    if not archive.is_dir() or any((archive / name).exists() for name in (
        "request.json", "ack.json", "PAUSE", "manager.pid", "manager-lock.json",
        "boundary.json", "prepared.json", "committed.json",
    )):
        return False
    manifest = archive / "databases/manifest.json"
    if not manifest.is_file():
        return False
    try:
        top_level = {item.name for item in archive.iterdir()}
        if top_level != {"databases"}:
            return False
        _paused_cancel_verify_capture(
            archive, binding,
            {"path": "databases/manifest.json", "sha256": file_hash(manifest)},
        )
    except (OSError, ValueError, PermissionError, ValidationError):
        return False
    return True


def cancel_orphaned_maintenance_paused(
    root: Path, *, request_id: str, expected_request_hash: str, expected_ack_hash: str,
) -> dict[str, Any]:
    """Explicit cancel, never recover/restart. Incomplete attempts block for review.

    Hashes must come from controlled external inputs, not be discovered here.
    Successful replay requires the complete immutable receipt, never mere absence.
    This entry is intentionally not connected to daily, manager, CLI or scheduler.
    """
    root = Path(os.path.abspath(root))
    binding = {"request_id": request_id, "request_hash": expected_request_hash, "ack_hash": expected_ack_hash}
    for digest in (expected_request_hash, expected_ack_hash):
        if not isinstance(digest, str) or len(digest) != 71 or not digest.startswith("sha256:") or any(c not in "0123456789abcdef" for c in digest[7:]):
            raise ValueError("CANCEL_EXPECTED_HASH_REQUIRED")
    pause_path = root / RUNTIME / "PAUSE"
    _paused_cancel_safe_path(root, pause_path)
    if not pause_path.is_file():
        raise PermissionError("CANCEL_OWNER_PAUSE_REQUIRED")
    archive = root / _PAUSED_CANCEL_ARCHIVE / canonical_hash(binding)[7:31]
    with _paused_cancel_exclusive(), ExitStack() as stack:
        _paused_cancel_safe_path(root, archive)
        pause = stack.enter_context(closing(_PausedCancelPin(pause_path)))
        if archive.exists() and not (archive / "committed.json").is_file():
            if not _paused_cancel_is_capture_only_archive(archive, binding):
                raise PermissionError("CANCEL_INCOMPLETE_PRIOR_ATTEMPT")
            archive = archive.with_name(archive.name + "-recovery")
            _paused_cancel_safe_path(root, archive)
        if archive.exists():
            if not (archive / "committed.json").is_file():
                raise PermissionError("CANCEL_INCOMPLETE_PRIOR_ATTEMPT")
            for name in ("request.json", "ack.json", "PAUSE", "manager.pid", "manager-lock.json",
                         "boundary.json", "prepared.json", "committed.json"):
                path = archive / name
                _paused_cancel_safe_path(root, path)
                stack.enter_context(closing(_PausedCancelPin(path)))
            archived_prepared = _read(archive / "prepared.json")
            if archived_prepared.get("schema_version") == "1.1.0":
                _paused_cancel_verify_capture(archive, binding, archived_prepared.get("database_capture"), stack=stack)
            prepared = _paused_cancel_read_archive(archive, binding)
            _paused_cancel_safe_path(root, archive / "committed.json")
            committed = _read(archive / "committed.json")
            required = {"schema_version", "status", "binding", "prepared_hash", "removed", "completed_at", "restart_permitted", "technical_cost_brl", "final_absence_checks"}
            if (set(committed) != required or committed["schema_version"] != prepared["schema_version"]
                    or committed["binding"] != binding or committed["status"] != "CANCELLED_WHILE_PAUSED"
                    or committed["prepared_hash"] != file_hash(archive / "prepared.json")
                    or committed["removed"] != [ACK_PATH.as_posix(), REQUEST_PATH.as_posix()]
                    or committed["restart_permitted"] is not False or committed["technical_cost_brl"] != 0):
                raise PermissionError("CANCEL_COMMIT_RECEIPT_INVALID")
            _parse(committed["completed_at"])
            _paused_cancel_check_absence(archive, committed["final_absence_checks"], committed["completed_at"])
            if prepared["evidence_hashes"]["PAUSE"] != _hash_bytes(pause.payload):
                raise PermissionError("CANCEL_PAUSE_CHANGED")
            for relative in (REQUEST_PATH, ACK_PATH):
                path = root / relative
                _paused_cancel_safe_path(root, path)
                if path.exists() and _read(path).get("request_id") == request_id:
                    raise PermissionError("CANCEL_COMPLETED_MARKER_REAPPEARED")
            return {"status": "ALREADY_CANCELLED", "archive_path": str(archive),
                    "receipt_hash": file_hash(archive / "committed.json"),
                    "prepared_hash": committed["prepared_hash"]}

        def pin(relative, *, deletable=False, capture=True):
            path = root / relative
            _paused_cancel_safe_path(root, path)
            return stack.enter_context(closing(_PausedCancelPin(path, deletable=deletable, capture=capture)))

        request_pin = pin(REQUEST_PATH, deletable=True)
        ack_pin = pin(ACK_PATH, deletable=True)
        pid_pin, lock_pin = pin(RUNTIME / "manager.pid"), pin(RUNTIME / "manager-lock.json")
        request, ack = json.loads(request_pin.payload), json.loads(ack_pin.payload)
        try:
            validate(root, "central_manager_maintenance_request.schema.json", request)
            validate(root, "central_manager_maintenance_ack.schema.json", ack)
        except ValidationError as exc:
            raise PermissionError("CANCEL_REQUEST_OR_ACK_SCHEMA_INVALID") from exc
        if (request["request_id"] != request_id or ack["request_id"] != request_id
                or _hash_bytes(request_pin.payload) != expected_request_hash
                or _hash_bytes(ack_pin.payload) != expected_ack_hash):
            raise PermissionError("CANCEL_REQUEST_OR_ACK_BINDING_CHANGED")
        deferred_due_only = (
            ack["status"] == "DEFERRED"
            and ack["external_effect_boundary_closed"] is False
            and ack["blockers"] == ["OPERATIONAL_JOB_DUE_DURING_MAINTENANCE"]
            and not ack["active_lease_job_ids"]
            and not ack["protected_due_job_ids"]
            and not ack["active_quota_reservation_ids"]
            and not ack["open_effect_receipt_paths"]
            and bool(ack["operational_due_job_ids"])
        )
        ready_to_stop = (
            ack["status"] == "READY_TO_STOP"
            and ack["external_effect_boundary_closed"] is True
        )
        lock = json.loads(lock_pin.payload)
        try:
            validate(root, "central_manager_lock.schema.json", lock)
        except ValidationError as exc:
            raise PermissionError("CANCEL_LOCK_SCHEMA_INVALID") from exc
        same_lock = ack["lock_content_hash"] == _hash_bytes(lock_pin.payload)
        expired_heartbeat_only = (
            not same_lock
            and lock["holder_pid"] == ack["manager_pid"]
            and lock["state"] == "HELD"
            and lock["released_at"] is None
            and _parse(lock["lease_expires_at"]) < datetime.now(timezone.utc)
        )
        if (not (ready_to_stop or deferred_due_only)
                or not (_parse(request["requested_at"]) <= _parse(ack["observed_at"]) <= datetime.now(timezone.utc))
                or ack["pid_content_hash"] != _hash_bytes(pid_pin.payload)
                or not (same_lock or expired_heartbeat_only)
                or int(pid_pin.payload) != ack["manager_pid"]):
            raise PermissionError("CANCEL_ACK_NOT_VALID_FOR_BOUNDARY")
        if lock["holder_pid"] != ack["manager_pid"]:
            raise PermissionError("CANCEL_MANAGER_IDENTITY_MISMATCH")
        if lock["state"] == "HELD" and _parse(lock["lease_expires_at"]) >= datetime.now(timezone.utc):
            raise PermissionError("CANCEL_MANAGER_LEASE_OPEN")
        stable_pins = [pause, pid_pin, lock_pin]
        _paused_cancel_absent(request["requester_pid"], "REQUESTER")
        _paused_cancel_absent(ack["manager_pid"], "MANAGER")
        if (root / RECOVERY_WINDOW_PATH).exists():
            raise PermissionError("CANCEL_RECOVERY_WINDOW_PRESENT")
        archive.mkdir(parents=True, exist_ok=False)
        database_capture = _PausedCancelDatabaseCapture(root, archive, binding, stack)
        boundary = _paused_cancel_boundary(root, database_root=database_capture.work_root)
        if deferred_due_only:
            captured_queue = queue_snapshot(database_capture.work_root)
            captured_deadline = _parse(str(ack["observed_at"])) + timedelta(
                seconds=int(request["protected_due_guard_seconds"])
            )
            captured_all_due = _operational_due_jobs(
                captured_queue, deadline=captured_deadline
            )
            captured_operational_due = sorted(
                set(captured_all_due)
                - set(_inert_current_media_due_jobs(root, captured_queue, captured_all_due))
            )
            if (captured_queue["jobs_hash"] != ack["queue_jobs_hash"]
                    or captured_operational_due
                    != sorted(ack["operational_due_job_ids"])):
                raise PermissionError("CANCEL_DEFERRED_QUEUE_CHANGED")
        for item in boundary["effects"]["receipts"]:
            stable_pins.append(pin(Path(item["path"])))

        def revalidate(remaining):
            if (root / RECOVERY_WINDOW_PATH).exists():
                raise PermissionError("CANCEL_RECOVERY_WINDOW_PRESENT")
            for item in [*stable_pins, *remaining]:
                _paused_cancel_safe_path(root, item.path)
                item.revalidate()
            absence = [_paused_cancel_absent(request["requester_pid"], "REQUESTER"),
                       _paused_cancel_absent(ack["manager_pid"], "MANAGER")]
            database_capture.revalidate()
            if _paused_cancel_boundary(root, database_root=database_capture.work_root) != boundary:
                raise PermissionError("CANCEL_OPERATIONAL_BOUNDARY_CHANGED")
            database_capture.revalidate()
            return absence

        absence = revalidate([request_pin, ack_pin])
        evidence = {"request.json": request_pin.payload, "ack.json": ack_pin.payload,
                    "PAUSE": pause.payload, "manager.pid": pid_pin.payload,
                    "manager-lock.json": lock_pin.payload, "boundary.json": _canonical_bytes(boundary)}
        prepared = {"schema_version": "1.1.0", "status": "PREPARED", "binding": binding,
                    "prepared_at": _stamp(datetime.now(timezone.utc)), "restart_permitted": False,
                    "decision": "EXACT_ORPHAN_CANCEL_UNDER_OWNER_PAUSE",
                    "absence_checks": absence, "exclusive_mutex": _PAUSED_CANCEL_MUTEX_NAME,
                    "exclusive_acquired": True,
                    "database_capture": database_capture.reference(),
                    "evidence_hashes": {name: _hash_bytes(payload) for name, payload in evidence.items()}}
        for name, payload in evidence.items():
            _write_immutable_bytes(archive / name, payload)
        _write_immutable_bytes(archive / "prepared.json", _canonical_bytes(prepared))
        # Pin the persisted authorization too; archive failure cannot authorize a delete.
        for name in (*evidence, "prepared.json"):
            stable_pins.append(pin((archive / name).relative_to(root)))
        _paused_cancel_read_archive(archive, binding)
        revalidate([request_pin, ack_pin])
        ack_pin.remove()
        revalidate([request_pin])
        if (root / ACK_PATH).exists():
            raise PermissionError("CANCEL_ACK_REPLACED_AFTER_REMOVAL")
        request_pin.remove()
        final_absence = revalidate([])
        if (root / ACK_PATH).exists() or (root / REQUEST_PATH).exists():
            raise PermissionError("CANCEL_MARKERS_NOT_ABSENT_AT_COMMIT")
        committed = {"schema_version": "1.1.0", "status": "CANCELLED_WHILE_PAUSED", "binding": binding,
                     "prepared_hash": file_hash(archive / "prepared.json"),
                     "removed": [ACK_PATH.as_posix(), REQUEST_PATH.as_posix()],
                     "completed_at": _stamp(datetime.now(timezone.utc)),
                     "restart_permitted": False, "technical_cost_brl": 0,
                     "final_absence_checks": final_absence}
        payload = _canonical_bytes(committed)
        _write_immutable_bytes(archive / "committed.json", payload)
        if (archive / "committed.json").read_bytes() != payload:
            raise PermissionError("CANCEL_COMMIT_NOT_VERIFIED")
        return {"status": committed["status"], "archive_path": str(archive),
                "receipt_hash": _hash_bytes(payload), "prepared_hash": committed["prepared_hash"]}


def _control_source_preview(
    root: Path,
    *,
    overrides: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Validate the twelve current stage sources without materializing a cycle."""
    from .phase6_control_cycle import BLOCKING_STATUSES, STAGES, stage_execution_outcome

    overrides = overrides or {}
    blockers: list[str] = []
    stages: list[dict[str, Any]] = []
    for contract in STAGES:
        stage = str(contract["stage"])
        path = root / str(contract["path"])
        try:
            value = overrides.get(stage)
            if value is None:
                value = _read(path)
            validate(root, str(contract["schema"]), value)
            status, error = stage_execution_outcome(stage, value)
            expected_transition_wait = (
                stage == "PHASE_TRANSITION"
                and status == "BLOCKED"
                and error in {None, "PHASE6_ACCEPTANCE_BLOCKED"}
                and bool(value.get("blocking_check_ids"))
            )
            expected_content_wait = False
            if stage == 'QUALITY':
                from .phase6_reporting import authenticated_prequeue_wait
                expected_content_wait = authenticated_prequeue_wait(root, value)
            if (
                (status in BLOCKING_STATUSES and not (expected_transition_wait or expected_content_wait))
                or (error is not None and not expected_transition_wait)
            ):
                blockers.append(f"{stage}:{status}")
            stages.append(
                {
                    "ordinal": len(stages) + 1,
                    "stage": stage,
                    "path": str(contract["path"]),
                    "schema": str(contract["schema"]),
                    "schema_status": "PASS",
                    "status": status,
                }
            )
        except Exception as exc:
            blockers.append(f"{stage}:INVALID:{type(exc).__name__}")
            stages.append(
                {
                    "ordinal": len(stages) + 1,
                    "stage": stage,
                    "path": str(contract["path"]),
                    "schema": str(contract["schema"]),
                    "schema_status": "FAIL",
                    "status": "INVALID",
                }
            )
    return {
        "stage_count": len(stages),
        "stage_order": [item["stage"] for item in stages],
        "all_schemas_valid": all(item["schema_status"] == "PASS" for item in stages),
        "blockers": sorted(set(blockers)),
        "stages": stages,
    }


def _is_exact_visual_contract_blocked(current: dict[str, Any]) -> bool:
    """Recognize only the reviewed v1.2 visual-contract stop source.

    This is deliberately an equality contract, not a broad interpretation of
    ``BLOCKED``.  A different audit, reason set, action, candidate or field
    shape remains an ordinary current failure and cannot enter the terminal
    recovery path.
    """

    expected_keys = {
        "schema_version",
        "executor_id",
        "phase",
        "status",
        "input_receipt_id",
        "action",
        "job_id",
        "job_state",
        "voice_manifest",
        "render_manifest",
        "visual_preflight",
        "capacity_preflight_receipt",
        "capacity_preflight_sha256",
        "capacity_status",
        "capacity_observed_free_bytes",
        "capacity_required_free_bytes",
        "capacity_headroom_bytes",
        "next_action",
        "error",
        "publication_authorized",
        "technical_cost_brl",
        "updated_at",
    }
    exact_values = {
        "schema_version": "1.2.0",
        "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6,
        "status": "BLOCKED",
        "input_receipt_id": "phase6-production-inputs-79b3e183dd5df410fb3a",
        "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
        "job_id": None,
        "job_state": "NOT_CREATED",
        "voice_manifest": None,
        "render_manifest": None,
        "visual_preflight": {
            "audit_id": "visual-preflight-394d5a2f84d56d4a3570519f",
            "path": (
                "output/operations/phase6/visual-preflight/audits/"
                "visual-preflight-394d5a2f84d56d4a3570519f.json"
            ),
            "sha256": (
                "sha256:a35f3479d434e4521dade63739372de1d7e28f2b6327466084d351e5a362c645"
            ),
            "status": "BLOCKED",
        },
        "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None,
        "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None,
        "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None,
        "next_action": EXACT_VISUAL_BLOCKED_NEXT_ACTION,
        "error": EXACT_VISUAL_BLOCKED_ERROR,
        "publication_authorized": False,
        "technical_cost_brl": 0,
    }
    if set(current) != expected_keys:
        return False
    if any(current.get(key) != value for key, value in exact_values.items()):
        return False
    try:
        _parse(str(current["updated_at"]))
    except (TypeError, ValueError):
        return False
    return True


def _cache_rejection_media_wait_candidate(root, *, current, source_path, observed):
    """Hold the exact failed command through restart without erasing its attempt."""
    prefix = "PermissionError: segment cache recovery blocked before render: take-001:"
    hold_prefix = "OWNER_PAUSE_RELEASE_REQUIRED: "
    error = current.get("error")
    held = current.get("status") == "WAITING" and str(current.get("next_action", "")).startswith(hold_prefix + prefix)
    if held:
        error = current["next_action"][len(hold_prefix):]
    if not isinstance(error, str) or not error.startswith(prefix):
        return None, None
    validate(root, "phase6_media_executor_runtime.schema.json", current)
    if not (current.get("schema_version") == "1.2.0"
            and current.get("status") == ("WAITING" if held else "RETRY_WAIT")
            and current.get("job_state") == "RETRY_WAIT"
            and current.get("action") == "SYNTHESIZE_AND_RENDER_VIDEO_2"
            and current.get("render_manifest") is None
            and current.get("remediation_wait") is None
            and (not held or current.get("error") is None)):
        raise PermissionError("cache rejection runtime is not the exact idle retry")
    from .phase6_current_production_inputs import current_production_input_contract
    from .phase6_media import verify_first_segment_cache_rejection
    contract = current_production_input_contract(root)
    if contract.get("receipt_id") != current.get("input_receipt_id") or contract.get("authority") != {
        "queue": False, "voice": False, "render": False, "quality": False, "publication": False}:
        raise PermissionError("cache rejection current input binding diverged")
    snapshot = queue_snapshot(root, now=observed)
    jobs = [job for job in snapshot["jobs"] if job.get("job_id") == current.get("job_id")]
    if len(jobs) != 1:
        raise PermissionError("cache rejection job missing or ambiguous")
    job = jobs[0]
    key = current["input_receipt_id"] + ":synthesize-render-standard-v2"
    if not (job.get("job_id") == "job-" + hashlib.sha256(key.encode()).hexdigest()[:24]
            and job.get("idempotency_key") == key
            and job.get("task_type") == "EXECUTE_PHASE6_VIDEO2_MEDIA"
            and job.get("payload") == {"input_receipt_id": current["input_receipt_id"], "action": current["action"]}
            and job.get("state") == "RETRY_WAIT" and type(job.get("attempt_count")) is int
            and job["attempt_count"] > 0 and job.get("lease_owner") is None
            and job.get("lease_until") is None and job.get("checkpoint") == {}
            and job.get("last_error") == error and not snapshot["active_lease_job_ids"]):
        raise PermissionError("cache rejection queue/attempt binding diverged")
    event = verify_first_segment_cache_rejection(root, error)
    candidate = {**current, "status": "WAITING", "error": None,
                 "next_action": hold_prefix + error, "updated_at": _stamp(observed)}
    validate(root, "phase6_media_executor_runtime.schema.json", candidate)
    return candidate, {
        "reason": "EXACT_CACHE_REJECTION_RESTART_HOLD", "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
        "source_sha256": file_hash(source_path), "source_status": current["status"],
        "candidate_status": "WAITING", "input_receipt_id": contract["receipt_id"],
        "current_contract_sha256": canonical_hash(contract), "job_sha256": canonical_hash(job),
        "cache_event": event, "original_error": error,
        "external_api_calls": 0, "production_effects": 0, "publication_effects": 0,
    }


_EXACT_MEDIA_RESERVE_WAIT_ERROR = (
    "ResourceWait: RESOURCE_WAIT: OUTPUT_DISK_RESERVE, TEMP_DISK_RESERVE"
)


def _resource_reserve_media_wait_candidate(root, *, current, source_path, observed):
    """Preserve one authenticated post-mux reserve failure through owner pause.

    The hold is deliberately narrower than a generic ``RETRY_WAIT`` recovery:
    it accepts only the reviewed reserve error, the exact current-input job,
    and a completed-mux witness for the still-resident output.  It grants no
    media authority; the live executor must admit capacity again after a new
    D-116 before it can finish the post-mux work.
    """
    error = _EXACT_MEDIA_RESERVE_WAIT_ERROR
    hold_prefix = "OWNER_PAUSE_RELEASE_REQUIRED: "
    held = (
        current.get("status") == "WAITING"
        and current.get("error") is None
        and current.get("next_action") == hold_prefix + error
    )
    if not (
        current.get("schema_version") == "1.2.0"
        and current.get("status") == ("WAITING" if held else "RETRY_WAIT")
        and current.get("job_state") == "RETRY_WAIT"
        and current.get("action") == "SYNTHESIZE_AND_RENDER_VIDEO_2"
        and current.get("render_manifest") is None
        and isinstance(current.get("visual_preflight"), dict)
        and current["visual_preflight"].get("status") == "PASS"
        and current.get("capacity_status") == "PASS"
        and isinstance(current.get("capacity_preflight_receipt"), str)
        and isinstance(current.get("capacity_preflight_sha256"), str)
        and all(type(current.get(key)) is int and current[key] >= 0 for key in (
            "capacity_observed_free_bytes", "capacity_required_free_bytes", "capacity_headroom_bytes"))
        and (held or current.get("error") == error)
        and current.get("publication_authorized") is False
        and current.get("technical_cost_brl") == 0
    ):
        return None, None
    validate(root, "phase6_media_executor_runtime.schema.json", current)
    from .phase6_current_production_inputs import current_production_input_contract
    from .phase6_media import _resident_mux_witness, _strict_output_path

    contract = current_production_input_contract(root)
    if (
        contract.get("receipt_id") != current.get("input_receipt_id")
        or contract.get("authority")
        != {"queue": False, "voice": False, "render": False,
            "quality": False, "publication": False}
    ):
        raise PermissionError("resource reserve current input binding diverged")
    key = current["input_receipt_id"] + ":synthesize-render-standard-v2"
    snapshot = queue_snapshot(root, now=observed)
    jobs = [job for job in snapshot["jobs"] if job.get("job_id") == current.get("job_id")]
    if len(jobs) != 1:
        raise PermissionError("resource reserve job missing or ambiguous")
    job = jobs[0]
    if not (
        job.get("job_id") == "job-" + hashlib.sha256(key.encode()).hexdigest()[:24]
        and job.get("idempotency_key") == key
        and job.get("task_type") == "EXECUTE_PHASE6_VIDEO2_MEDIA"
        and job.get("payload") == {"input_receipt_id": current["input_receipt_id"], "action": current["action"]}
        and job.get("state") == "RETRY_WAIT"
        and type(job.get("attempt_count")) is int and job["attempt_count"] > 0
        and job.get("lease_owner") is None and job.get("lease_until") is None
        and job.get("checkpoint") == {} and job.get("last_error") == error
        and not snapshot["active_lease_job_ids"]
    ):
        raise PermissionError("resource reserve queue/attempt binding diverged")
    output = _strict_output_path(root, current["input_receipt_id"])
    witness = _resident_mux_witness(root, output)
    candidate = {
        **current,
        "status": "WAITING",
        "error": None,
        "next_action": "OWNER_PAUSE_RELEASE_REQUIRED: " + error,
        "updated_at": _stamp(observed),
    }
    validate(root, "phase6_media_executor_runtime.schema.json", candidate)
    return candidate, {
        "reason": "EXACT_RESOURCE_RESERVE_RESTART_HOLD",
        "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
        "source_sha256": file_hash(source_path),
        "source_status": current["status"],
        "candidate_status": "WAITING",
        "input_receipt_id": contract["receipt_id"],
        "current_contract_sha256": canonical_hash(contract),
        "job_sha256": canonical_hash(job),
        "resident_mux_witness": {
            "path": witness["path"].resolve().relative_to(root.resolve()).as_posix(),
            "sha256": file_hash(witness["path"]),
        },
        "original_error": error,
        "external_api_calls": 0, "production_effects": 0,
        "publication_effects": 0,
    }


def _exact_owner_pause_media_wait_candidate(
    root: Path,
    *,
    current: dict[str, Any],
    source_path: Path,
    observed: datetime,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Recover only the no-effect media status written because its owner paused."""
    required = {
        "schema_version", "executor_id", "phase", "status", "input_receipt_id",
        "action", "job_id", "job_state", "voice_manifest", "render_manifest",
        "capacity_preflight_receipt", "capacity_preflight_sha256", "capacity_status",
        "capacity_observed_free_bytes", "capacity_required_free_bytes",
        "capacity_headroom_bytes", "next_action", "error", "publication_authorized",
        "technical_cost_brl", "updated_at",
    }
    forward_required = required | {"visual_preflight"}
    forward_reason = (
        "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
        "resume only through the verified control cycle."
    )
    if (
        set(current) == forward_required
        and current.get("schema_version") == "1.2.0"
        and current.get("executor_id") == "heroverse-phase6-media-executor-v1"
        and current.get("phase") == 6
        and current.get("status") == "WAITING"
        and current.get("action") == "SYNTHESIZE_AND_RENDER_VIDEO_2"
        and current.get("job_id") is None
        and current.get("job_state") == "NOT_CREATED"
        and current.get("voice_manifest") is None
        and current.get("render_manifest") is None
        and current.get("visual_preflight") is None
        and current.get("capacity_preflight_receipt") is None
        and current.get("capacity_preflight_sha256") is None
        and current.get("capacity_status") == "UNAVAILABLE"
        and current.get("capacity_observed_free_bytes") is None
        and current.get("capacity_required_free_bytes") is None
        and current.get("capacity_headroom_bytes") is None
        and current.get("next_action") == forward_reason
        and current.get("error") is None
        and current.get("publication_authorized") is False
        and current.get("technical_cost_brl") == 0
    ):
        from .phase6_current_production_inputs import current_production_input_contract

        contract = current_production_input_contract(root)
        if (
            contract.get("receipt_id") != current.get("input_receipt_id")
            or contract.get("authority")
            != {
                "queue": False, "voice": False, "render": False,
                "quality": False, "publication": False,
            }
        ):
            raise PermissionError("forward owner-pause wait differs from current inputs")
        candidate = {**current, "updated_at": _stamp(observed)}
        validate(root, "phase6_media_executor_runtime.schema.json", candidate)
        return candidate, {
            "reason": "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT",
            "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
            "source_sha256": file_hash(source_path),
            "source_status": "WAITING",
            "candidate_status": "WAITING",
            "input_receipt_id": current["input_receipt_id"],
            "current_contract_sha256": canonical_hash(contract),
            "external_api_calls": 0,
            "production_effects": 0,
            "publication_effects": 0,
        }
    prestart_identity_exact = {
        "schema_version": "1.1.0", "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6, "status": "ERROR", "input_receipt_id": None, "action": "WAIT",
        "job_id": None, "job_state": "NOT_CREATED", "voice_manifest": None,
        "render_manifest": None, "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None, "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None, "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None,
        "next_action": "Preserve evidence and retry without relaxing media or release gates.",
        "error": "PermissionError: treatment order compiler/code/recipe/voice identity changed",
        "publication_authorized": False, "technical_cost_brl": 0,
    }
    if set(current) == required and all(
        current.get(key) == value for key, value in prestart_identity_exact.items()
    ):
        try:
            _parse(str(current["updated_at"]))
        except (TypeError, ValueError):
            return None, None
        from .phase6_current_production_inputs import current_production_input_contract

        contract = current_production_input_contract(root)
        if contract.get("authority") != {
            "queue": False, "voice": False, "render": False,
            "quality": False, "publication": False,
        }:
            raise PermissionError("prestart identity recovery unexpectedly grants authority")
        candidate = {
            **current,
            "schema_version": "1.2.0",
            "status": "WAITING",
            "input_receipt_id": contract["receipt_id"],
            "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
            "visual_preflight": None,
            "error": None,
            "next_action": forward_reason,
            "updated_at": _stamp(observed),
        }
        validate(root, "phase6_media_executor_runtime.schema.json", candidate)
        return candidate, {
            "reason": "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT",
            "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
            "source_sha256": file_hash(source_path),
            "source_status": "ERROR", "candidate_status": "WAITING",
            "input_receipt_id": contract["receipt_id"],
            "current_contract_sha256": canonical_hash(contract),
            "external_api_calls": 0, "production_effects": 0,
            "publication_effects": 0,
        }

    exact = {
        "schema_version": "1.1.0", "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6, "status": "ERROR", "input_receipt_id": None, "action": "WAIT",
        "job_id": None, "job_state": "NOT_CREATED", "voice_manifest": None,
        "render_manifest": None, "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None, "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None, "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None,
        "error": "ResourceWait: RESOURCE_WAIT: OWNER_PAUSE",
        "publication_authorized": False, "technical_cost_brl": 0,
    }
    if set(current) != required or any(current.get(key) != value for key, value in exact.items()):
        return None, None
    try:
        _parse(str(current["updated_at"]))
    except (TypeError, ValueError):
        return None, None
    candidate = {
        **current, "status": "WAITING", "error": None,
        "next_action": (
            "OWNER_PAUSE_RELEASE_REQUIRED: no media command, voice, render, or "
            "publication effect occurred; resume only through the verified control cycle."
        ),
        "updated_at": _stamp(observed),
    }
    validate(root, "phase6_media_executor_runtime.schema.json", candidate)
    return candidate, {
        "reason": "EXACT_OWNER_PAUSE_NO_EFFECT",
        "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
        "source_sha256": file_hash(source_path),
        "source_status": "ERROR", "candidate_status": "WAITING",
        "external_api_calls": 0, "production_effects": 0, "publication_effects": 0,
    }


def _post_effect_visual_wait_candidate(
    root: Path,
    *,
    request_id: str,
    observed: datetime,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Build or replay the exact no-effect wait for the reviewed c516 lineage.

    An unrelated media failure is intentionally left untouched so the normal
    twelve-stage migration remains fail-closed.  A prior 1.3 wait is reopened
    in full, allowing later daily maintenance receipts to carry its immutable
    proof forward without manufacturing a new remediation decision.
    """

    from .phase6_media_remediation_wait import (
        WAIT_REASON,
        derive_post_effect_visual_wait,
        verify_post_effect_visual_wait,
    )

    path = root / MEDIA_EXECUTOR_STATUS_PATH
    if not path.is_file() or path.is_symlink():
        return None, None
    current = _read(path)
    if (
        current.get("schema_version") == "1.3.0"
        or current.get("remediation_wait") is not None
    ):
        proof = verify_post_effect_visual_wait(root, current)
        # The historical WAITING receipt remains immutable evidence, but it
        # must not permanently hide a later fully-authenticated input receipt.
        # This transition creates only an inert, owner-paused v1.2 runtime:
        # no capacity probe, queue command, voice, render or publication is
        # permitted here.  The live executor must re-open every current byte
        # after a separately-authorized restart.
        from .phase6_current_production_inputs import current_production_input_contract

        current_inputs = current_production_input_contract(root)
        historical_receipt = current.get("input_receipt_id")
        if current_inputs["receipt_id"] != historical_receipt:
            authority = current_inputs.get("authority")
            if authority != {
                "queue": False, "voice": False, "render": False,
                "quality": False, "publication": False,
            }:
                raise PermissionError("forward current inputs unexpectedly grant authority")
            candidate = {
                "schema_version": "1.2.0",
                "executor_id": "heroverse-phase6-media-executor-v1",
                "phase": 6,
                "status": "WAITING",
                "input_receipt_id": current_inputs["receipt_id"],
                "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
                "job_id": None,
                "job_state": "NOT_CREATED",
                "voice_manifest": None,
                "render_manifest": None,
                "visual_preflight": None,
                "capacity_preflight_receipt": None,
                "capacity_preflight_sha256": None,
                "capacity_status": "UNAVAILABLE",
                "capacity_observed_free_bytes": None,
                "capacity_required_free_bytes": None,
                "capacity_headroom_bytes": None,
                "next_action": (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                ),
                "error": None,
                "publication_authorized": False,
                "technical_cost_brl": 0,
                "updated_at": _stamp(observed),
            }
            validate(root, "phase6_media_executor_runtime.schema.json", candidate)
            return candidate, {
                "proof": proof,
                "proof_path": current["remediation_wait"]["path"],
                "proof_replayed": True,
                "forward_successor": current_inputs,
                "historical_receipt_id": historical_receipt,
            }
        candidate = {**current, "updated_at": _stamp(observed)}
        validate(root, "phase6_media_executor_runtime.schema.json", candidate)
        return candidate, {
            "proof": proof,
            "proof_path": current["remediation_wait"]["path"],
            "proof_replayed": True,
        }

    exact_legacy_error = (
        current.get("schema_version") in {"1.1.0", "1.2.0"}
        and current.get("status") == "ERROR"
        and current.get("input_receipt_id") is None
        and current.get("action") == "WAIT"
        and current.get("job_id") is None
        and current.get("job_state") == "NOT_CREATED"
        and current.get("voice_manifest") is None
        and current.get("render_manifest") is None
        and current.get("capacity_preflight_receipt") is None
        and current.get("capacity_status") == "UNAVAILABLE"
        and current.get("error")
        == "QueueConflict: current media job is not an unfinished executable candidate"
        and current.get("publication_authorized") is False
        and current.get("technical_cost_brl") == 0
    )
    exact_visual_blocked = _is_exact_visual_contract_blocked(current)
    if not exact_legacy_error and not exact_visual_blocked:
        return None, None
    if exact_visual_blocked:
        validate(root, "phase6_media_executor_runtime.schema.json", current)
    candidate, proof, proof_path = derive_post_effect_visual_wait(
        root,
        request_id=request_id,
        observed=observed,
    )
    if candidate["next_action"] != WAIT_REASON:
        raise PermissionError("post-effect visual wait candidate changed its reason")
    return candidate, {
        "proof": proof,
        "proof_path": proof_path,
        "proof_replayed": False,
    }


COMPLETED_MEDIA_CYCLE_ERROR = "QueueConflict: current media job is not an unfinished executable candidate"


def _completed_media_recovery_projection(current, job, capacity, *, observed):
    """Reconstruct only the view lost by the exact completed-job caller error."""
    expected = {
        "schema_version": "1.1.0", "executor_id": "heroverse-phase6-media-executor-v1",
        "phase": 6, "status": "ERROR", "input_receipt_id": None, "action": "WAIT",
        "job_id": None, "job_state": "NOT_CREATED", "voice_manifest": None,
        "render_manifest": None, "capacity_preflight_receipt": None,
        "capacity_preflight_sha256": None, "capacity_status": "UNAVAILABLE",
        "capacity_observed_free_bytes": None, "capacity_required_free_bytes": None,
        "capacity_headroom_bytes": None,
        "next_action": "Preserve evidence and retry without relaxing media or release gates.",
        "error": COMPLETED_MEDIA_CYCLE_ERROR, "publication_authorized": False, "technical_cost_brl": 0,
    }
    if set(current) != set(expected) | {"updated_at"} or any(current[k] != v for k, v in expected.items()):
        raise PermissionError("completed media recovery source differs from exact cycle error")
    _parse(current["updated_at"])
    cp = job.get("checkpoint") or {}
    key = str(cp.get("input_receipt_id")) + ":synthesize-render-standard-v2"
    if not (job.get("state") == "SUCCEEDED" and job.get("job_id") == "job-" + hashlib.sha256(key.encode()).hexdigest()[:24]
            and job.get("idempotency_key") == key and job.get("task_type") == "EXECUTE_PHASE6_VIDEO2_MEDIA"
            and job.get("operation_id") == "heroverse-phase6-controlled-longform-v1"
            and job.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
            and job.get("payload") == {"input_receipt_id": cp.get("input_receipt_id"), "action": "SYNTHESIZE_AND_RENDER_VIDEO_2"}
            and job.get("last_error") is None and job.get("lease_owner") is None and job.get("lease_until") is None
            and type(job.get("attempt_count")) is int and type(job.get("max_attempts")) is int
            and 0 < job["attempt_count"] <= job["max_attempts"]
            and cp.get("voice_manifest") and cp.get("render_manifest") and cp.get("visual_preflight", {}).get("status") == "PASS"
            and cp.get("capacity_receipt_id") == capacity.get("receipt_id") and capacity.get("status") == "PASS"):
        raise PermissionError("completed media recovery job/checkpoint is not exact")
    volumes = [v for v in capacity["volumes"] if v["role"] == "production_output"]
    if len(volumes) != 1:
        raise PermissionError("completed media recovery capacity volume is ambiguous")
    volume = volumes[0]
    return {**current, "schema_version": "1.2.0", "status": "COMPLETED",
        "input_receipt_id": cp["input_receipt_id"], "action": "SYNTHESIZE_AND_RENDER_VIDEO_2",
        "job_id": job["job_id"], "job_state": "SUCCEEDED", "voice_manifest": cp["voice_manifest"],
        "render_manifest": cp["render_manifest"], "visual_preflight": cp["visual_preflight"],
        "capacity_preflight_receipt": cp["capacity_receipt_path"],
        "capacity_preflight_sha256": cp["capacity_receipt_sha256"], "capacity_status": "PASS",
        "capacity_observed_free_bytes": volume["free_bytes"], "capacity_required_free_bytes": capacity["required_free_bytes"],
        "capacity_headroom_bytes": volume["headroom_bytes"], "error": None,
        "next_action": "RUN_PHASE6_VIDEO2_QUALITY_GATES", "updated_at": _stamp(observed)}


def _completed_media_cycle_recovery_candidate(root, *, current, observed):
    if current.get("status") != "ERROR" or current.get("error") != COMPLETED_MEDIA_CYCLE_ERROR:
        return None, None
    from .queue_phase6 import TransactionalQueue
    from .phase6_media_authority import verify_completed_phase6_media_authority
    from .phase6_media import _verified_inputs, _verify_completed_media_checkpoint
    receipt, reason = _verified_inputs(root)
    if receipt is None:
        raise PermissionError("completed media recovery current inputs unavailable: " + str(reason))
    queue = TransactionalQueue(root, read_only=True, immutable=True)
    job = queue.get_by_idempotency_key(receipt["receipt_id"] + ":synthesize-render-standard-v2")
    if job is None or job.get("state") != "SUCCEEDED":
        return None, None  # preserve the older, separately authenticated remediation path
    job = verify_completed_phase6_media_authority(root, authoritative_job_id=job["job_id"], queue=queue, now=observed)
    capacity = _verify_completed_media_checkpoint(root, job["checkpoint"], receipt)
    candidate = _completed_media_recovery_projection(current, job, capacity, observed=observed)
    validate(root, "phase6_media_executor_runtime.schema.json", candidate)
    snapshot = queue_snapshot(root, now=observed)
    if job not in snapshot["jobs"] or snapshot["active_lease_job_ids"]:
        raise PermissionError("completed media recovery queue changed or remains active")
    return candidate, {"reason": "EXACT_COMPLETED_MEDIA_CYCLE_RECOVERY",
        "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(), "source_sha256": file_hash(root / MEDIA_EXECUTOR_STATUS_PATH),
        "job": job, "queue_jobs": snapshot["jobs"], "queue_jobs_hash": snapshot["jobs_hash"], "capacity": capacity}


def _quality_retry_projection(current, jobs, media, manifest, manifest_hash, *, observed, allow_held=False):
    """Pure, exact retry projection, shared by transaction and archive reader.

    This does not repair a quality result or reset a queue job. It separates a
    preserved failed attempt from the next controlled evaluation's WAIT state.
    Any different error/state/identity remains blocked by the ordinary gates.
    """
    if not allow_held and current.get("next_action") == "Media executor is ERROR/NOT_CREATED.":
        exact = {"schema_version": "1.0.0", "executor_id": "heroverse-phase6-quality-executor-v1",
            "phase": 6, "status": "WAITING", "media_render_id": None, "job_id": None,
            "job_state": "NOT_CREATED", "evaluation": None, "decision": "WAIT", "publication_eligible": False,
            "next_action": "Media executor is ERROR/NOT_CREATED.", "error": None, "technical_cost_brl": 0}
        if set(current) != set(exact) | {"updated_at"} or any(current[k] != v for k, v in exact.items()):
            raise PermissionError("quality missing-media wait is not exact")
        key = f"{manifest['render_id']}:{manifest['output']['content_hash']}:independent-quality-v2"
        matches = [j for j in jobs if j.get("idempotency_key") == key]
        if len(matches) != 1:
            raise PermissionError("quality missing-media retry job is ambiguous")
        # Restore only the derived identity; the existing strict checks below
        # still require the exact failed, unleased queue attempt and render.
        current = {**current, "status": "RETRY_WAIT", "job_state": "RETRY_WAIT",
            "decision": "BLOCKED", "error": QUALITY_RECOMPUTATION_ERROR,
            "job_id": matches[0]["job_id"], "media_render_id": manifest["render_id"]}
    failed_source = (
        current.get("status") == "RETRY_WAIT" and current.get("job_state") == "RETRY_WAIT"
        and current.get("error") == QUALITY_RECOMPUTATION_ERROR
        and current.get("decision") == "BLOCKED")
    held_source = (allow_held and current.get("status") == "WAITING"
        and current.get("job_state") == "RETRY_WAIT" and current.get("error") is None
        and current.get("decision") == "WAIT" and current.get("next_action") == QUALITY_RETRY_HOLD)
    if not (
        (held_source if allow_held else failed_source) and current.get("evaluation") is None
        and current.get("publication_eligible") is False
        and media.get("status") == "COMPLETED" and media.get("job_state") == "SUCCEEDED"
        and media.get("error") is None and media.get("publication_authorized") is False
        and current.get("media_render_id") == manifest.get("render_id")
        and manifest.get("render_id")
        and all(j.get("state") != "LEASED" and j.get("lease_owner") is None
                and j.get("lease_until") is None for j in jobs)
    ):
        raise PermissionError("quality retry hold source is not exact and quiescent")
    matches = [j for j in jobs if j.get("job_id") == current.get("job_id")]
    media_jobs = [j for j in jobs if j.get("job_id") == media.get("job_id")]
    if len(matches) != 1 or len(media_jobs) != 1:
        raise PermissionError("quality retry hold job identity is ambiguous")
    job, media_job = matches[0], media_jobs[0]
    render_hash = manifest.get("output", {}).get("content_hash")
    expected_key = f"{manifest['render_id']}:{render_hash}:independent-quality-v2"
    if not (
        isinstance(render_hash, str) and len(render_hash) == 71 and render_hash.startswith("sha256:")
        and job.get("idempotency_key") == expected_key
        and len([j for j in jobs if j.get("idempotency_key") == expected_key]) == 1
        and job.get("operation_id") == "heroverse-phase6-controlled-longform-v1"
        and job.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
        and job.get("task_type") == "EVALUATE_PHASE6_VIDEO2_QUALITY"
        and job.get("state") == "RETRY_WAIT" and job.get("last_error") == QUALITY_RECOMPUTATION_ERROR
        and job.get("checkpoint") == {} and type(job.get("attempt_count")) is int
        and type(job.get("max_attempts")) is int
        and 0 < job["attempt_count"] < job["max_attempts"]
        and job.get("payload") == {"render_id": manifest["render_id"], "render_hash": render_hash}
        and media_job.get("task_type") == "EXECUTE_PHASE6_VIDEO2_MEDIA"
        and media_job.get("state") == "SUCCEEDED"
        and media_job.get("checkpoint", {}).get("render_id") == manifest["render_id"]
        and media_job.get("checkpoint", {}).get("render_manifest") == media.get("render_manifest")
        and media_job.get("checkpoint", {}).get("render_manifest_sha256") == manifest_hash
    ):
        raise PermissionError("quality retry hold queue/render binding diverged")
    return {**current, "status": "WAITING", "decision": "WAIT", "error": None,
            "next_action": QUALITY_RETRY_HOLD, "updated_at": _stamp(observed)}


def _quality_retry_wait_candidate(root, *, observed, allow_held=False, media_override=None):
    path = root / QUALITY_EXECUTOR_STATUS_PATH
    if not path.is_file():
        return None, None
    source = path.read_bytes()
    current = json.loads(source.decode("utf-8-sig"))
    held_marker = str(current.get("next_action", "")).startswith("CONTROLLED_QUALITY_REEVALUATION_PENDING:")
    # Only a recovered COMPLETED render can supply the identity for this retry.
    # A no-effect OWNER_PAUSE override remains WAITING/NOT_CREATED and has no
    # manifest; its ordinary quality WAIT is not a failed evaluation to repair.
    missing_media = (media_override is not None and media_override.get("status") == "COMPLETED"
                     and current.get("next_action") == "Media executor is ERROR/NOT_CREATED.")
    if (current.get("status") != "RETRY_WAIT" or current.get("error") != QUALITY_RECOMPUTATION_ERROR) and not (allow_held and held_marker) and not missing_media:
        return None, None
    validate(root, "phase6_quality_executor_runtime.schema.json", current)
    media = media_override if media_override is not None else _read(root / MEDIA_EXECUTOR_STATUS_PATH)
    manifest_path = root / str(media.get("render_manifest") or "")
    _paused_cancel_safe_path(root, manifest_path)
    render_id = current['media_render_id'] if not missing_media else manifest_path.stem
    expected_path = Path("output/production/phase6/video-002/renders/manifests") / f"{render_id}.json"
    if manifest_path != root / expected_path or not manifest_path.is_file():
        raise PermissionError("quality retry hold requires the immutable render manifest")
    raw = manifest_path.read_bytes()
    manifest = json.loads(raw.decode("utf-8-sig"))
    queue = queue_snapshot(root, now=observed)
    candidate = _quality_retry_projection(current, queue["jobs"], media, manifest,
                                          _hash_bytes(raw), observed=observed, allow_held=allow_held)
    validate(root, "phase6_quality_executor_runtime.schema.json", candidate)
    return candidate, {"kind": "EXACT_QUALITY_RECOMPUTATION_RETRY_HOLD",
        "source_path": QUALITY_EXECUTOR_STATUS_PATH.as_posix(), "source_sha256": _hash_bytes(source),
        "queue_jobs": queue["jobs"], "queue_jobs_hash": queue["jobs_hash"],
        "media": media, "render_manifest": manifest, "render_manifest_sha256": _hash_bytes(raw),
        "quality_authorized": False, "render_authorized": False, "publication_authorized": False}


def _local_runtime_migration_candidates(
    root: Path,
    *,
    observed: datetime,
    request_id: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any], str, dict[str, Any]]:
    """Build deterministic derived views from already-persisted local evidence."""
    runtime_path = root / PREDICTION_RUNTIME_PATH
    runtime_before: dict[str, Any] | None = None
    runtime_valid = False
    if runtime_path.is_file():
        try:
            runtime_before = _read(runtime_path)
            validate(root, "phase6_prediction_runtime.schema.json", runtime_before)
            runtime_valid = True
        except Exception:
            runtime_before = None

    source: dict[str, Any] = {
        "prediction_path": None,
        "prediction_hash": None,
        "prediction_id": None,
        "queue_job_id": None,
        "queue_job_state": None,
    }
    if runtime_valid:
        assert runtime_before is not None
        runtime_candidate = runtime_before
        action = "NO_CHANGE"
    else:
        prediction_path = root / PREDICTIONS_PATH / "latest.json"
        prediction = _read(prediction_path)
        validate(root, "prediction_record.schema.json", prediction)
        horizon = _parse(str((prediction.get("horizon") or {})["ends_at"]))
        if observed >= horizon:
            raise PermissionError(
                "legacy prediction runtime cannot be migrated after its horizon without an operational observer"
            )
        horizon_key = horizon.strftime("%Y%m%dT%H%M%SZ")
        evaluation_path = (
            root
            / PREDICTION_EVALUATIONS_PATH
            / f"evaluation-{prediction['prediction_id']}-{horizon_key}.json"
        )
        if evaluation_path.is_file():
            raise PermissionError("legacy prediction runtime has an evaluation and needs full binding replay")
        expected_key = (
            f"phase6-prediction-outcome:{prediction['prediction_id']}:"
            f"{prediction['horizon']['ends_at']}"
        )
        jobs = [
            item
            for item in queue_snapshot(root, now=observed)["jobs"]
            if item.get("idempotency_key") == expected_key
        ]
        if len(jobs) != 1:
            raise PermissionError("legacy prediction runtime does not have one exact existing queue job")
        job = jobs[0]
        if not (
            job.get("task_type") == "PREDICTION_OUTCOME_CHECKPOINT"
            and job.get("operation_id") == "heroverse-phase6-controlled-longform-v1"
            and job.get("channel_id") == "UCuMF6pJQkyMzaVoAxFL86yA"
            and job.get("state") == "PENDING"
            and job.get("available_at") == prediction["horizon"]["ends_at"]
            and job.get("lease_owner") is None
            and job.get("lease_until") is None
            and (job.get("payload") or {}).get("prediction_id") == prediction["prediction_id"]
            and (job.get("payload") or {}).get("video_id") == prediction["video_id"]
            and (job.get("payload") or {}).get("horizon_ends_at")
            == prediction["horizon"]["ends_at"]
        ):
            raise PermissionError("legacy prediction runtime queue binding is not inert and exact")
        runtime_candidate = {
            "schema_version": "1.1.0",
            "observer_id": "heroverse-phase6-prediction-outcome-v1",
            "phase": 6,
            "channel_id": "UCuMF6pJQkyMzaVoAxFL86yA",
            "status": "WAITING_FOR_HORIZON",
            "prediction_id": prediction["prediction_id"],
            "prediction_status": prediction["status"],
            "horizon_ends_at": prediction["horizon"]["ends_at"],
            "next_observation_at": prediction["horizon"]["ends_at"],
            "job_id": job["job_id"],
            "job_state": job["state"],
            "outcome_snapshot": None,
            "outcome_snapshot_hash": None,
            "outcome_snapshot_schema": None,
            "evaluation": None,
            "error": None,
            "technical_cost_brl": 0,
            "updated_at": _stamp(observed),
        }
        validate(root, "phase6_prediction_runtime.schema.json", runtime_candidate)
        source = {
            "prediction_path": PREDICTIONS_PATH.joinpath("latest.json").as_posix(),
            "prediction_hash": file_hash(prediction_path),
            "prediction_id": prediction["prediction_id"],
            "queue_job_id": job["job_id"],
            "queue_job_state": job["state"],
        }
        action = "MIGRATED_LEGACY_PREDICTION_RUNTIME"

    media_candidate: dict[str, Any] | None = None
    media_evidence: dict[str, Any] | None = None
    media_path = root / MEDIA_EXECUTOR_STATUS_PATH
    if media_path.is_file():
        media_before = _read(media_path)
        owner_pause_candidate, owner_pause_evidence = _exact_owner_pause_media_wait_candidate(
            root, current=media_before, source_path=media_path, observed=observed
        )
        media_candidate, media_evidence = owner_pause_candidate, owner_pause_evidence
        if media_candidate is None:
            media_candidate, media_evidence = _cache_rejection_media_wait_candidate(
                root, current=media_before, source_path=media_path, observed=observed)
        if media_candidate is None:
            media_candidate, media_evidence = _resource_reserve_media_wait_candidate(
                root, current=media_before, source_path=media_path, observed=observed)
        if media_candidate is None:
            media_candidate, media_evidence = _completed_media_cycle_recovery_candidate(
                root, current=media_before, observed=observed)
        needs_request = (
            media_before.get("schema_version") == "1.3.0"
            or media_before.get("remediation_wait") is not None
            or _is_exact_visual_contract_blocked(media_before)
            or (
                media_before.get("status") == "ERROR"
                and media_before.get("error")
                == "QueueConflict: current media job is not an unfinished executable candidate"
            )
        )
        if needs_request and request_id is None and media_candidate is None:
            raise PermissionError(
                "post-effect media wait migration requires an exact maintenance request"
            )
        if needs_request and request_id is not None and media_candidate is None:
            media_candidate, media_evidence = _post_effect_visual_wait_candidate(
                root, request_id=request_id, observed=observed
            )

    # The executive reader deliberately rejects a persisted goal trajectory
    # whose media-evidence identity no longer matches the live media view.
    # During owner-paused maintenance, refresh that derived, no-effect view in
    # the same transaction instead of treating a legitimate historic blocker
    # as a permanent executive failure.
    from .phase6_goal_trajectory import (
        MEDIA_BLOCK_IDENTITY_FIELDS,
        _media_decision_context,
        build_goal_trajectory,
        current_path as current_goal_path,
    )

    goal_candidate: dict[str, Any] | None = None
    goal_evidence: dict[str, Any] | None = None
    goal_path = current_goal_path(root)
    goal_before = _read(goal_path)
    _, current_media_block = _media_decision_context(root, media_override=media_candidate)
    previous_media_block = (goal_before.get("decision") or {}).get("production_block")
    def _block_identity(block: dict[str, Any] | None) -> dict[str, Any] | None:
        return (
            {key: block.get(key) for key in MEDIA_BLOCK_IDENTITY_FIELDS}
            if isinstance(block, dict)
            else None
        )
    daily_path = root / "output/operations/phase6/channel-goal-observer/status.json"
    daily_runtime = _read(daily_path) if daily_path.is_file() else {}
    previous_goal = goal_before.get("measurement") or {}
    observer_changed = (
        previous_goal.get("daily_observer_status", "UNAVAILABLE") != daily_runtime.get("status", "UNAVAILABLE")
        or previous_goal.get("daily_observer_next_at") != daily_runtime.get("next_observation_at")
    )
    if _block_identity(previous_media_block) != _block_identity(current_media_block) or observer_changed:
        goal_candidate = build_goal_trajectory(
            root, evaluated_at=_stamp(observed), media_override=media_candidate
        )
        validate(root, "phase6_goal_trajectory.schema.json", goal_candidate)
        goal_evidence = {
            "source_path": GOAL_TRAJECTORY_PATH.as_posix(),
            "source_sha256": file_hash(goal_path),
            "previous_media_block": _block_identity(previous_media_block),
            "current_media_block": _block_identity(current_media_block),
            "previous_daily_observer": {key: previous_goal.get(key) for key in ("daily_observer_status", "daily_observer_next_at")},
            "current_daily_observer": {"daily_observer_status": daily_runtime.get("status", "UNAVAILABLE"),
                                       "daily_observer_next_at": daily_runtime.get("next_observation_at")},
            "candidate_sha256": canonical_hash(goal_candidate),
            "production_effects": 0,
            "publication_effects": 0,
        }

    from .phase6_reporting import _markdown as render_executive_markdown
    from .phase6_reporting import build_status

    quality_candidate, quality_evidence = _quality_retry_wait_candidate(
        root, observed=observed, media_override=media_candidate)
    executive_candidate = build_status(
        root,
        captured_at=_stamp(observed),
        prediction_runtime_override=runtime_candidate,
        media_executor_override=media_candidate,
        goal_trajectory_override=goal_candidate,
        quality_executor_override=quality_candidate,
    )
    validate(root, "phase6_executive_status.schema.json", executive_candidate)
    executive_markdown = render_executive_markdown(executive_candidate)
    preview = _control_source_preview(
        root,
        overrides={
            **({"MEDIA": media_candidate} if media_candidate is not None else {}),
            **({"QUALITY": quality_candidate} if quality_candidate is not None else {}),
            **({"GOAL_TRAJECTORY": goal_candidate} if goal_candidate is not None else {}),
            "PREDICTION_OUTCOME": runtime_candidate,
            "EXECUTIVE_VIEW": executive_candidate,
        },
    )
    if preview["stage_count"] != 12 or not preview["all_schemas_valid"] or preview["blockers"]:
        raise PermissionError(
            "local runtime migration cannot produce a clean 12-stage source set: "
            + ",".join(preview["blockers"])
        )
    return runtime_candidate, executive_candidate, executive_markdown, {
        "action": action,
        "source": source,
        "control_sources": preview,
        "media_runtime_candidate": media_candidate,
        "media_wait_evidence": media_evidence,
        "quality_runtime_candidate": quality_candidate,
        "quality_retry_evidence": quality_evidence,
        "goal_trajectory_candidate": goal_candidate,
        "goal_trajectory_evidence": goal_evidence,
    }


def preview_local_runtime_migration(
    root: Path = ROOT,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Read-only proof that current local sources can be migrated and revalidated.

    Before a maintenance handshake exists, an in-memory diagnostic request id
    is used only to exercise derivation contracts that bind a request-shaped
    namespace.  The preview never persists that id or any derived proof, and
    the runtime verifier still requires a real COMMITTED migration outcome.
    """
    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    observed_stamp = _stamp(observed)
    request_path = root / REQUEST_PATH
    if request_path.exists() or request_path.is_symlink():
        if request_path.is_symlink() or not request_path.is_file():
            raise PermissionError("maintenance preview request is not a regular file")
        request = _read(request_path)
        validate(root, "central_manager_maintenance_request.schema.json", request)
        derivation_request_id = request["request_id"]
        request_authority = "ACTIVE_MAINTENANCE_REQUEST"
        active_request_id: str | None = derivation_request_id
    else:
        diagnostic_seed = canonical_hash(
            {
                "authority": "PREVIEW_NOT_AN_EXECUTION_REQUEST",
                "root_identity": hashlib.sha256(
                    str(root).lower().encode("utf-8")
                ).hexdigest(),
                "observed_at": observed_stamp,
            }
        ).split(":", 1)[1]
        fractional = f"{observed.microsecond:06d}0"
        derivation_request_id = (
            "maintenance-request-"
            + observed.strftime("%Y%m%dT%H%M%S")
            + fractional
            + "Z-"
            + diagnostic_seed[:8]
        )
        request_authority = "PREVIEW_NOT_AN_EXECUTION_REQUEST"
        active_request_id = None
    runtime_path = root / PREDICTION_RUNTIME_PATH
    legacy_runtime_bytes = runtime_path.read_bytes() if runtime_path.is_file() else b""
    runtime, executive, _markdown, evidence = _local_runtime_migration_candidates(
        root, observed=observed, request_id=derivation_request_id
    )
    cycle_error = _correlated_legacy_control_cycle_error(
        root,
        request_id=derivation_request_id,
        migration_action=evidence["action"],
        legacy_runtime_bytes=legacy_runtime_bytes,
        migration_source=evidence["source"],
        media_candidate=evidence.get("media_runtime_candidate"),
    )
    result = {
        "schema_version": "1.0.0",
        "mode": "READ_ONLY_PREVIEW",
        "request_authority": request_authority,
        "active_request_id": active_request_id,
        "action": evidence["action"],
        "prediction_runtime_status": runtime["status"],
        "prediction_runtime_schema_version": runtime["schema_version"],
        "executive_status": executive["status"],
        "source": evidence["source"],
        "control_sources": evidence["control_sources"],
        "media_runtime_status": (
            evidence["media_runtime_candidate"]["status"]
            if evidence["media_runtime_candidate"] is not None
            else None
        ),
        "media_runtime_reason": (
            evidence["media_runtime_candidate"]["next_action"]
            if evidence["media_runtime_candidate"] is not None
            else None
        ),
        "control_cycle_error": {
            key: value for key, value in cycle_error.items() if key != "payload"
        },
        "external_api_calls": 0,
        "operational_queue_mutations": 0,
        "proofs_persisted": 0,
        "runtime_views_persisted": 0,
        "receipt_committed": False,
        "technical_cost_brl": 0,
        "observed_at": observed_stamp,
    }
    result["diagnostic_id"] = (
        "local-runtime-preview-" + canonical_hash(result).split(":", 1)[1][:24]
    )
    return result


def _correlated_legacy_control_cycle_error(
    root: Path,
    *,
    request_id: str,
    migration_action: str,
    legacy_runtime_bytes: bytes,
    migration_source: dict[str, Any],
    media_candidate: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Prove one byte-pinned historical error before removing its live alias.

    The second branch is intentionally narrower than a generic WinError 5
    waiver: it accepts one already-observed byte sequence, the exact reviewed
    terminal-media wait, the corrected writer identity, and a later coherent
    JSON/Markdown executive pair.  Any future writer error remains current.
    """
    error_path = root / CONTROL_CYCLE_ERROR_PATH
    if not error_path.exists() and not error_path.is_symlink():
        return {
            "action": "NOT_PRESENT",
            "source_path": CONTROL_CYCLE_ERROR_PATH.as_posix(),
            "source_hash": None,
            "archive_path": None,
            "archive_hash": None,
            "payload": None,
            "correlation_checks": [],
        }
    if error_path.is_symlink() or not error_path.is_file():
        raise PermissionError("current control-cycle error is not a regular workspace file")
    payload = error_path.read_bytes()
    digest = _hash_bytes(payload)
    try:
        error_record = json.loads(payload.decode("utf-8-sig"))
    except Exception as exc:
        raise PermissionError("current control-cycle error correlation evidence is unreadable") from exc
    error_text = error_record.get("error")
    result_action: str
    if migration_action == "MIGRATED_LEGACY_PREDICTION_RUNTIME":
        try:
            legacy_runtime = json.loads(legacy_runtime_bytes.decode("utf-8-sig"))
        except Exception as exc:
            raise PermissionError(
                "legacy prediction runtime correlation evidence is unreadable"
            ) from exc
        prediction_id = migration_source.get("prediction_id")
        queue_job_id = migration_source.get("queue_job_id")
        checks = {
            "phase6_error_status": error_record.get("phase") == 6
            and error_record.get("status") == "ERROR",
            "zero_cost_error": error_record.get("technical_cost_brl") == 0,
            "legacy_runtime_v1": legacy_runtime.get("schema_version") == "1.0.0",
            "exact_observer": legacy_runtime.get("observer_id")
            == "heroverse-phase6-prediction-outcome-v1",
            "exact_channel": legacy_runtime.get("channel_id")
            == "UCuMF6pJQkyMzaVoAxFL86yA",
            "prediction_schema_failure": isinstance(error_text, str)
            and "phase6_prediction_runtime.schema.json" in error_text
            and "'outcome_snapshot_hash' is a required property" in error_text,
            "exact_prediction_bound": isinstance(prediction_id, str)
            and isinstance(error_text, str)
            and prediction_id in error_text,
            "exact_queue_job_bound": isinstance(queue_job_id, str)
            and isinstance(error_text, str)
            and queue_job_id in error_text,
        }
        result_action = "ARCHIVED_CORRELATED_LEGACY_RUNTIME"
    elif migration_action == "NO_CHANGE":
        if migration_source != {
            "prediction_path": None,
            "prediction_hash": None,
            "prediction_id": None,
            "queue_job_id": None,
            "queue_job_state": None,
        }:
            raise PermissionError("executive writer error correlation requires an unchanged runtime source")
        if not isinstance(media_candidate, dict):
            raise PermissionError("executive writer error correlation requires the exact media wait candidate")
        validate(root, "phase6_media_executor_runtime.schema.json", media_candidate)
        binding = media_candidate.get("remediation_wait")
        if not isinstance(binding, dict):
            raise PermissionError("executive writer error correlation lacks the media proof binding")
        expected_proof_path = (
            RUNTIME
            / "maintenance-runs"
            / request_id
            / f"{binding.get('proof_id')}.json"
        ).as_posix()
        media_identity = {
            key: value
            for key, value in media_candidate.items()
            if key not in {"updated_at", "remediation_wait"}
        }
        exact_visual = {
            "audit_id": "visual-preflight-394d5a2f84d56d4a3570519f",
            "path": (
                "output/operations/phase6/visual-preflight/audits/"
                "visual-preflight-394d5a2f84d56d4a3570519f.json"
            ),
            "sha256": (
                "sha256:a35f3479d434e4521dade63739372de1d7e28f2b6327466084d351e5a362c645"
            ),
            "status": "BLOCKED",
        }
        exact_media = (
            media_candidate.get("schema_version") == "1.3.0"
            and media_candidate.get("executor_id") == "heroverse-phase6-media-executor-v1"
            and media_candidate.get("phase") == 6
            and media_candidate.get("status") == "WAITING"
            and media_candidate.get("input_receipt_id")
            == "phase6-production-inputs-79b3e183dd5df410fb3a"
            and media_candidate.get("action") == "WAIT"
            and media_candidate.get("job_id") == "job-c516db5685acbbb423199bc1"
            and media_candidate.get("job_state") == "SUCCEEDED"
            and media_candidate.get("voice_manifest") is None
            and media_candidate.get("render_manifest") is None
            and media_candidate.get("visual_preflight") == exact_visual
            and media_candidate.get("capacity_preflight_receipt") is None
            and media_candidate.get("capacity_preflight_sha256") is None
            and media_candidate.get("capacity_status") == "UNAVAILABLE"
            and media_candidate.get("capacity_observed_free_bytes") is None
            and media_candidate.get("capacity_required_free_bytes") is None
            and media_candidate.get("capacity_headroom_bytes") is None
            and media_candidate.get("next_action")
            == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
            and media_candidate.get("error") is None
            and media_candidate.get("publication_authorized") is False
            and media_candidate.get("technical_cost_brl") == 0
        )
        exact_binding = (
            binding.get("status") == "ELIGIBLE_FOR_WAITING_STATE"
            and binding.get("reason") == "POST_EFFECT_VISUAL_REMEDIATION_REQUIRED"
            and binding.get("request_id") == request_id
            and binding.get("authority_root_job_id") == "job-ddc7d6b9605b194c44fd4f78"
            and binding.get("authority_tail_job_id") == "job-c516db5685acbbb423199bc1"
            and binding.get("input_receipt_id")
            == "phase6-production-inputs-79b3e183dd5df410fb3a"
            and binding.get("path") == expected_proof_path
            and canonical_hash(media_identity) == binding.get("runtime_identity_sha256")
        )

        executive_path = root / EXECUTIVE_STATUS_PATH
        markdown_path = root / EXECUTIVE_STATUS_MARKDOWN_PATH
        fixed_tmp_path = Path(str(executive_path) + ".tmp")
        for current_path, label in (
            (executive_path, "executive JSON"),
            (markdown_path, "executive Markdown"),
        ):
            if current_path.is_symlink() or not current_path.is_file():
                raise PermissionError(f"current {label} is not a regular workspace file")
        executive_bytes_before = executive_path.read_bytes()
        markdown_bytes = markdown_path.read_bytes()
        executive_bytes_after = executive_path.read_bytes()
        try:
            executive = json.loads(executive_bytes_before.decode("utf-8-sig"))
            validate(root, "phase6_executive_status.schema.json", executive)
        except Exception as exc:
            raise PermissionError("current executive JSON is not schema-valid") from exc
        from . import phase6_reporting

        expected_target = str(executive_path.resolve()).replace("\\", "\\\\")
        expected_tmp = str(fixed_tmp_path.resolve()).replace("\\", "\\\\")
        expected_error_text = (
            "PermissionError: [WinError 5] Acesso negado: "
            f"'{expected_tmp}' -> '{expected_target}'"
        )
        reflected_media = executive.get("media_execution")
        exact_reflected_media = isinstance(reflected_media, dict) and (
            reflected_media.get("executor_status") == "BLOCKED"
            and reflected_media.get("input_receipt_id")
            == "phase6-production-inputs-79b3e183dd5df410fb3a"
            and reflected_media.get("action") == "SYNTHESIZE_AND_RENDER_VIDEO_2"
            and reflected_media.get("job_state") == "NOT_CREATED"
            and reflected_media.get("voice_manifest") is None
            and reflected_media.get("render_manifest") is None
            and reflected_media.get("capacity_preflight_receipt") is None
            and reflected_media.get("capacity_status") == "UNAVAILABLE"
            and reflected_media.get("next_action") == EXACT_VISUAL_BLOCKED_NEXT_ACTION
            and reflected_media.get("publication_authorized") is False
        )
        try:
            later_capture = _parse(str(executive.get("captured_at"))) > _parse(
                LEGACY_EXECUTIVE_REPLACE_ERROR_UPDATED_AT
            )
        except (TypeError, ValueError):
            later_capture = False
        rendered_markdown = phase6_reporting._markdown(executive).encode("utf-8")
        rendered_markdown_crlf = rendered_markdown.replace(b"\n", b"\r\n")
        checks = {
            "exact_error_bytes": digest == LEGACY_EXECUTIVE_REPLACE_ERROR_SHA256,
            "exact_error_payload_schema": set(error_record)
            == {
                "schema_version",
                "phase",
                "status",
                "error",
                "technical_cost_brl",
                "updated_at",
            }
            and error_record.get("schema_version") == "1.0.0"
            and type(error_record.get("phase")) is int
            and error_record.get("phase") == 6
            and error_record.get("status") == "ERROR"
            and type(error_record.get("technical_cost_brl")) is int
            and error_record.get("technical_cost_brl") == 0,
            "exact_error_timestamp": error_record.get("updated_at")
            == LEGACY_EXECUTIVE_REPLACE_ERROR_UPDATED_AT,
            "exact_error_target_pair": error_text == expected_error_text,
            "exact_terminal_media_wait": exact_media,
            "exact_media_proof_binding": exact_binding,
            "executive_atomic_writer_v2": getattr(
                phase6_reporting, "EXECUTIVE_ATOMIC_WRITER_VERSION", None
            )
            == EXECUTIVE_ATOMIC_WRITER_REQUIRED,
            "executive_json_stable_read": executive_bytes_before == executive_bytes_after,
            "executive_capture_after_error": later_capture,
            "executive_reflects_exact_visual_block": exact_reflected_media,
            "executive_json_markdown_reconciled": markdown_bytes
            in {rendered_markdown, rendered_markdown_crlf},
            "fixed_legacy_tmp_absent": not fixed_tmp_path.exists()
            and not fixed_tmp_path.is_symlink(),
        }
        result_action = "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE"
    else:
        raise PermissionError("current control-cycle error is not attributable to this migration")
    if not all(checks.values()):
        failed = sorted(name for name, passed in checks.items() if not passed)
        raise PermissionError(
            "current control-cycle error is not proven historical for this migration: "
            + ",".join(failed)
        )
    archive = CONTROL_CYCLE_ERROR_ARCHIVE / request_id / (
        "control-cycle-error-" + digest.split(":", 1)[1][:16] + ".json"
    )
    return {
        "action": result_action,
        "source_path": CONTROL_CYCLE_ERROR_PATH.as_posix(),
        "source_hash": digest,
        "archive_path": archive.as_posix(),
        "archive_hash": digest,
        "payload": payload,
        "correlation_checks": sorted(checks),
    }


def migrate_local_runtime_views(
    root: Path = ROOT,
    *,
    request_id: str,
    former_manager_pid: int,
    former_launcher_pid: int,
    evidence_dir: Path,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Repair derived local views only while the verified manager chain is stopped."""
    root = root.resolve()
    observed = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    expected_evidence_dir = (root / RUNTIME / "maintenance-runs" / request_id).resolve()
    destination = (root / evidence_dir).resolve()
    if destination != expected_evidence_dir:
        raise PermissionError("local migration evidence directory is not the exact maintenance run")
    request = _read(root / REQUEST_PATH)
    validate(root, "central_manager_maintenance_request.schema.json", request)
    if request.get("request_id") != request_id or request.get("external_effects_permitted") is not False:
        raise PermissionError("local migration is not bound to the active closed maintenance request")
    _require_process_stopped(former_manager_pid, role="former manager")
    _require_process_stopped(former_launcher_pid, role="former launcher")
    inspection = inspect_quiescence(
        root,
        manager_pid=former_manager_pid,
        guard_seconds=int(request["protected_due_guard_seconds"]),
        now=observed,
    )
    if inspection["blockers"]:
        raise PermissionError(
            "local migration requires quiescent operational state: "
            + ",".join(inspection["blockers"])
        )

    return _migrate_local_runtime_views_transaction(
        root, request_id=request_id, destination=destination, observed=observed
    )


def _migrate_local_runtime_views_transaction(
    root: Path, *, request_id: str, destination: Path, observed: datetime,
    recheck=None, finalize=None, rollback_targets=None, replace_target=None,
) -> dict[str, Any]:
    """Shared transaction; callers establish either live-stop or paused authority.

    The public live entry above retains every previous precondition. The paused
    caller retains its mutex, source pins and copy-only SQLite view throughout.
    No synthetic request, ACK, running process or restart proof is manufactured.
    """
    rollback_targets = rollback_targets or _rollback_migration_targets

    runtime_path = root / PREDICTION_RUNTIME_PATH
    media_runtime_path = root / MEDIA_EXECUTOR_STATUS_PATH
    quality_runtime_path = root / QUALITY_EXECUTOR_STATUS_PATH
    goal_trajectory_path = root / GOAL_TRAJECTORY_PATH
    executive_path = root / EXECUTIVE_STATUS_PATH
    executive_markdown_path = root / EXECUTIVE_STATUS_MARKDOWN_PATH
    for target in (
        runtime_path,
        media_runtime_path,
        quality_runtime_path,
        goal_trajectory_path,
        executive_path,
        executive_markdown_path,
    ):
        try:
            target.resolve(strict=False).relative_to(root)
        except ValueError as exc:
            raise PermissionError("local runtime migration target escaped the workspace") from exc
        if target.is_symlink() or (target.exists() and not target.is_file()):
            raise PermissionError(f"local runtime migration target is not a regular file: {target}")

    queue_before = queue_snapshot(root, now=observed)
    ledger_before = ledger_state_snapshot(root)
    effects_before = operational_effect_snapshot(root)
    legacy_runtime_bytes = runtime_path.read_bytes() if runtime_path.is_file() else b""
    runtime_candidate, executive_candidate, executive_markdown, evidence = (
        _local_runtime_migration_candidates(
            root, observed=observed, request_id=request_id
        )
    )
    media_candidate = evidence.get("media_runtime_candidate")
    media_wait_evidence = evidence.get("media_wait_evidence")
    quality_candidate = evidence.get("quality_runtime_candidate")
    quality_retry_evidence = evidence.get("quality_retry_evidence")
    quality_payload = None
    quality_runtime_migration = None
    if quality_candidate is not None:
        fresh_candidate, fresh_evidence = _quality_retry_wait_candidate(
            root, observed=observed, media_override=media_candidate)
        if (fresh_candidate != quality_candidate or fresh_evidence != quality_retry_evidence
                or fresh_evidence["queue_jobs_hash"] != queue_before["jobs_hash"]):
            raise PermissionError("quality retry hold changed before staging")
        quality_payload = json.dumps(quality_candidate, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
        quality_runtime_migration = {**quality_retry_evidence, "candidate_sha256": _hash_bytes(quality_payload)}
    goal_candidate = evidence.get("goal_trajectory_candidate")
    goal_evidence = evidence.get("goal_trajectory_evidence")

    # Serialize every payload before the first live-path mutation, then parse
    # and schema-validate the exact serialized bytes that will be committed.
    runtime_payload = (
        json.dumps(runtime_candidate, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    )
    executive_payload = (
        json.dumps(executive_candidate, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    )
    media_payload: bytes | None = None
    if media_candidate is not None:
        media_payload = (
            json.dumps(media_candidate, ensure_ascii=False, indent=2).encode("utf-8")
            + b"\n"
        )
    goal_payload: bytes | None = None
    if goal_candidate is not None:
        goal_payload = (
            json.dumps(goal_candidate, ensure_ascii=False, indent=2).encode("utf-8")
            + b"\n"
        )
    runtime_serialized = json.loads(runtime_payload.decode("utf-8-sig"))
    executive_serialized = json.loads(executive_payload.decode("utf-8-sig"))
    if runtime_serialized != runtime_candidate or executive_serialized != executive_candidate:
        raise PermissionError("local runtime migration serialization changed a candidate")
    validate(root, "phase6_prediction_runtime.schema.json", runtime_serialized)
    validate(root, "phase6_executive_status.schema.json", executive_serialized)
    if media_payload is not None:
        media_serialized = json.loads(media_payload.decode("utf-8-sig"))
        if media_serialized != media_candidate:
            raise PermissionError("local runtime migration changed the media wait candidate")
        validate(root, "phase6_media_executor_runtime.schema.json", media_serialized)
    if goal_payload is not None:
        goal_serialized = json.loads(goal_payload.decode("utf-8-sig"))
        if goal_serialized != goal_candidate:
            raise PermissionError("local runtime migration changed the goal trajectory candidate")
        validate(root, "phase6_goal_trajectory.schema.json", goal_serialized)
        if not isinstance(goal_evidence, dict) or any(
            goal_evidence.get(key) is None
            for key in ("source_path", "source_sha256", "candidate_sha256")
        ):
            raise PermissionError("goal trajectory refresh lacks exact evidence")
    executive_markdown_payload = executive_markdown.encode("utf-8")
    if executive_markdown_payload.decode("utf-8") != executive_markdown:
        raise PermissionError("local runtime migration markdown is not UTF-8 stable")

    cycle_error = _correlated_legacy_control_cycle_error(
        root,
        request_id=request_id,
        migration_action=evidence["action"],
        legacy_runtime_bytes=legacy_runtime_bytes,
        migration_source=evidence["source"],
        media_candidate=media_candidate,
    )
    desired: list[tuple[Path, bool, bytes]] = [
        (runtime_path, True, runtime_payload),
    ]
    from .central_manager_phase5 import (build_paused_fingerprint_reconciliation,
                                        paused_fingerprint_source_paths, input_fingerprint)
    fingerprint_reconciliation = None
    fingerprint_sources = {}
    if (root / RUNTIME / "PAUSE").is_file():
        fingerprint_sources = {path: file_hash(path) for path in paused_fingerprint_source_paths(root)}
        pause_hash = file_hash(root / RUNTIME / "PAUSE")
        fingerprint_reconciliation = build_paused_fingerprint_reconciliation(
            root, observed_at=_stamp(observed))
    if fingerprint_reconciliation is not None:
        fingerprint_value, fingerprint_evidence = fingerprint_reconciliation
        desired.append((root / RUNTIME / "fingerprint.json", True, _canonical_bytes(fingerprint_value)))
    if media_payload is not None:
        desired.append((media_runtime_path, True, media_payload))
    if quality_payload is not None:
        desired.append((quality_runtime_path, True, quality_payload))
    if goal_payload is not None:
        desired.append((goal_trajectory_path, True, goal_payload))
    desired.extend(
        [
            (executive_path, True, executive_payload),
            (executive_markdown_path, True, executive_markdown_payload),
        ]
    )
    if cycle_error["action"] in {
        "ARCHIVED_CORRELATED_LEGACY_RUNTIME",
        "ARCHIVED_CORRELATED_LEGACY_EXECUTIVE_REPLACE",
    }:
        archive_path = root / str(cycle_error["archive_path"])
        if archive_path.is_symlink() or (archive_path.exists() and not archive_path.is_file()):
            raise PermissionError("control-cycle error archive target is not a regular file")
        if archive_path.is_file() and archive_path.read_bytes() != cycle_error["payload"]:
            raise PermissionError("immutable control-cycle error archive collision")
        desired.extend(
            [
                (archive_path, True, cycle_error["payload"]),
                (root / CONTROL_CYCLE_ERROR_PATH, False, b""),
            ]
        )

    states: list[dict[str, Any]] = []
    seen_targets: set[str] = set()
    allowed_write_paths: list[str] = []
    media_runtime_migration: dict[str, Any] | None = None
    if media_candidate is not None:
        if not isinstance(media_wait_evidence, dict):
            raise PermissionError("media wait candidate lacks its immutable proof")
        if media_wait_evidence.get("reason") == "EXACT_COMPLETED_MEDIA_CYCLE_RECOVERY":
            fresh_candidate, fresh_evidence = _completed_media_cycle_recovery_candidate(
                root, current=_read(media_runtime_path), observed=observed)
            if (fresh_candidate != media_candidate or fresh_evidence != media_wait_evidence
                    or fresh_evidence["queue_jobs_hash"] != queue_before["jobs_hash"]):
                raise PermissionError("completed media cycle recovery changed before staging")
            media_runtime_migration = {**media_wait_evidence,
                "kind": "EXACT_COMPLETED_MEDIA_CYCLE_RECOVERY", "status": "COMPLETED",
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "production_authorized": False, "publication_authorized": False,
                "external_api_calls": 0, "publication_effects": 0,
                "operational_queue_mutations": 0, "technical_cost_brl": 0}
        elif media_wait_evidence.get("reason") in {
            "EXACT_CACHE_REJECTION_RESTART_HOLD", "EXACT_RESOURCE_RESERVE_RESTART_HOLD"
        }:
            reserve_hold = media_wait_evidence["reason"] == "EXACT_RESOURCE_RESERVE_RESTART_HOLD"
            if reserve_hold:
                fresh_candidate, fresh_evidence = _resource_reserve_media_wait_candidate(
                    root, current=_read(media_runtime_path), source_path=media_runtime_path,
                    observed=observed)
                if fresh_candidate != media_candidate or fresh_evidence != media_wait_evidence:
                    raise PermissionError("resource reserve hold changed before staging")
            # Only this derived view changes. The immutable journal retains the
            # failed view verbatim; its queue attempt/error and all media bytes
            # remain unchanged. This is a restart hold, not a retry or render PASS.
            media_runtime_migration = {
                "kind": media_wait_evidence["reason"], "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                **{key: media_wait_evidence[key] for key in (
                    "source_path", "source_sha256", "source_status", "candidate_status",
                    "input_receipt_id", "current_contract_sha256", "job_sha256", "original_error")},
                **{("resident_mux_witness" if reserve_hold else "cache_event"):
                    media_wait_evidence["resident_mux_witness" if reserve_hold else "cache_event"]},
                "production_authorized": False, "publication_authorized": False,
                "external_api_calls": 0, "publication_effects": 0,
                "operational_queue_mutations": 0, "technical_cost_brl": 0,
            }
        elif media_wait_evidence.get("reason") == "EXACT_OWNER_PAUSE_NO_EFFECT":
            expected_evidence = {
                "reason", "source_path", "source_sha256", "source_status",
                "candidate_status", "external_api_calls", "production_effects",
                "publication_effects",
            }
            if (
                set(media_wait_evidence) != expected_evidence
                or media_wait_evidence["source_path"] != MEDIA_EXECUTOR_STATUS_PATH.as_posix()
                or media_wait_evidence["source_status"] != "ERROR"
                or media_wait_evidence["candidate_status"] != "WAITING"
                or any(media_wait_evidence[key] != 0 for key in (
                    "external_api_calls", "production_effects", "publication_effects"
                ))
            ):
                raise PermissionError("owner-pause media recovery evidence is not exact")
            media_runtime_migration = {
                "kind": "EXACT_OWNER_PAUSE_NO_EFFECT_RECOVERY",
                "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "source_path": media_wait_evidence["source_path"],
                "source_sha256": media_wait_evidence["source_sha256"],
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
        elif media_wait_evidence.get("reason") == "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT":
            expected_evidence = {
                "reason", "source_path", "source_sha256", "source_status",
                "candidate_status", "input_receipt_id", "current_contract_sha256",
                "external_api_calls", "production_effects", "publication_effects",
            }
            if (
                set(media_wait_evidence) != expected_evidence
                or media_wait_evidence["source_path"] != MEDIA_EXECUTOR_STATUS_PATH.as_posix()
                or media_wait_evidence["source_status"] != "ERROR"
                or media_wait_evidence["candidate_status"] != "WAITING"
                or media_wait_evidence["input_receipt_id"]
                != media_candidate.get("input_receipt_id")
                or media_candidate.get("status") != "WAITING"
                or media_candidate.get("remediation_wait") is not None
                or media_candidate.get("next_action")
                != (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                )
                or any(media_wait_evidence[key] != 0 for key in (
                    "external_api_calls", "production_effects", "publication_effects"
                ))
            ):
                raise PermissionError("prestart identity recovery evidence is not exact")
            media_runtime_migration = {
                "kind": "EXACT_PRESTART_IDENTITY_DRIFT_NO_EFFECT_RECOVERY",
                "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "source_path": media_wait_evidence["source_path"],
                "source_sha256": media_wait_evidence["source_sha256"],
                "source_status": "ERROR",
                "candidate_status": "WAITING",
                "input_receipt_id": media_wait_evidence["input_receipt_id"],
                "current_contract_sha256": media_wait_evidence["current_contract_sha256"],
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
        elif media_wait_evidence.get("reason") == "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT":
            expected_evidence = {
                "reason", "source_path", "source_sha256", "source_status",
                "candidate_status", "input_receipt_id", "current_contract_sha256",
                "external_api_calls", "production_effects", "publication_effects",
            }
            if (
                set(media_wait_evidence) != expected_evidence
                or media_wait_evidence["source_path"] != MEDIA_EXECUTOR_STATUS_PATH.as_posix()
                or media_wait_evidence["source_status"] != "WAITING"
                or media_wait_evidence["candidate_status"] != "WAITING"
                or media_wait_evidence["input_receipt_id"]
                != media_candidate.get("input_receipt_id")
                or media_candidate.get("remediation_wait") is not None
                or any(media_wait_evidence[key] != 0 for key in (
                    "external_api_calls", "production_effects", "publication_effects"
                ))
            ):
                raise PermissionError("forward current media heartbeat evidence is not exact")
            media_runtime_migration = {
                "kind": "EXACT_FORWARD_CURRENT_WAIT_HEARTBEAT",
                "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "source_path": media_wait_evidence["source_path"],
                "source_sha256": media_wait_evidence["source_sha256"],
                "source_status": "WAITING",
                "candidate_status": "WAITING",
                "input_receipt_id": media_wait_evidence["input_receipt_id"],
                "current_contract_sha256": media_wait_evidence["current_contract_sha256"],
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
        elif "forward_successor" in media_wait_evidence:
            expected_evidence = {
                "proof", "proof_path", "proof_replayed", "forward_successor",
                "historical_receipt_id",
            }
            forward = media_wait_evidence["forward_successor"]
            proof = media_wait_evidence["proof"]
            proof_relative = str(media_wait_evidence["proof_path"])
            proof_path = _confined_migration_evidence_path(
                root,
                proof_relative,
                expected_parent=(
                    root
                    / RUNTIME
                    / "maintenance-runs"
                    / str(proof["request_id"])
                ).resolve(),
            )
            proof_payload = (
                json.dumps(proof, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
            )
            expected_authority = {
                "queue": False, "voice": False, "render": False,
                "quality": False, "publication": False,
            }
            if (
                set(media_wait_evidence) != expected_evidence
                or media_candidate.get("remediation_wait") is not None
                or not isinstance(forward, dict)
                or forward.get("authority") != expected_authority
                or forward.get("receipt_id") != media_candidate.get("input_receipt_id")
                or media_wait_evidence["historical_receipt_id"] == forward.get("receipt_id")
                or media_candidate.get("status") != "WAITING"
                or media_candidate.get("next_action")
                != (
                    "OWNER_PAUSE_RELEASE_REQUIRED: current production inputs are authenticated; "
                    "resume only through the verified control cycle."
                )
                or not proof_path.is_file()
                or proof_path.read_bytes() != proof_payload
            ):
                raise PermissionError("forward current media wait successor is not exact")
            media_runtime_migration = {
                "kind": "FORWARD_CURRENT_INPUT_WAIT_SUCCESSOR",
                "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "source_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "source_sha256": file_hash(root / MEDIA_EXECUTOR_STATUS_PATH),
                "source_status": "WAITING",
                "candidate_status": "WAITING",
                "historical_proof_path": proof_relative,
                "historical_proof_sha256": _hash_bytes(proof_payload),
                "historical_receipt_id": media_wait_evidence["historical_receipt_id"],
                "current_input_receipt_id": forward["receipt_id"],
                "forward_contract_sha256": canonical_hash(forward),
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
        else:
            proof = media_wait_evidence["proof"]
            proof_relative = str(media_wait_evidence["proof_path"])
            proof_path = _confined_migration_evidence_path(
                root,
                proof_relative,
                expected_parent=(
                    root
                    / RUNTIME
                    / "maintenance-runs"
                    / str(proof["request_id"])
                ).resolve(),
            )
            proof_payload = (
                json.dumps(proof, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
            )
            if _hash_bytes(proof_payload) != media_candidate["remediation_wait"]["sha256"]:
                raise PermissionError("media wait proof serialization changed its runtime binding")
            proof_existed = proof_path.is_file()
            _write_immutable_bytes(proof_path, proof_payload)
            if proof_path.read_bytes() != proof_payload:
                raise PermissionError("media wait proof staging mismatch")
            if not proof_existed:
                allowed_write_paths.append(proof_relative)
            binding = media_candidate["remediation_wait"]
            media_runtime_migration = {
                "status": "WAITING",
                "reason": media_candidate["next_action"],
                "media_runtime_path": MEDIA_EXECUTOR_STATUS_PATH.as_posix(),
                "media_runtime_hash": _hash_bytes(media_payload),
                "runtime_identity_sha256": binding["runtime_identity_sha256"],
                "proof_request_id": binding["request_id"],
                "proof_id": binding["proof_id"],
                "proof_path": proof_relative,
                "proof_sha256": binding["sha256"],
                "authority_root_job_id": binding["authority_root_job_id"],
                "authority_tail_job_id": binding["authority_tail_job_id"],
                "input_receipt_id": binding["input_receipt_id"],
                "chain_sha256": binding["chain_sha256"],
                "checkpoint_sha256": binding["checkpoint_sha256"],
                "historical_renderer": proof["historical_artifacts"]["historical_renderer"],
                "required_renderer": proof["historical_artifacts"]["required_renderer"],
                "visual_preflight": proof["blocked_visual_preflight"],
                "production_authorized": False,
                "publication_authorized": False,
                "external_api_calls": 0,
                "publication_effects": 0,
                "operational_queue_mutations": 0,
                "technical_cost_brl": 0,
            }
    for ordinal, (target, desired_exists, payload) in enumerate(desired, start=1):
        try:
            relative = target.resolve(strict=False).relative_to(root).as_posix()
        except ValueError as exc:
            raise PermissionError("local runtime migration target escaped the workspace") from exc
        if relative in seen_targets:
            raise PermissionError("local runtime migration target is duplicated")
        seen_targets.add(relative)
        if target.is_symlink() or (target.exists() and not target.is_file()):
            raise PermissionError(f"local runtime migration target is not a regular file: {relative}")
        existed_before = target.is_file()
        before = target.read_bytes() if existed_before else b""
        state = {
            "ordinal": ordinal,
            "target": target,
            "relative_path": relative,
            "existed_before": existed_before,
            "before": before,
            "desired_exists": desired_exists,
            "payload": payload,
            "changed": not _target_matches_desired(
                target, exists=desired_exists, payload=payload
            ),
        }
        states.append(state)

    # Freeze byte-exact preimages (including the distinction between absent and
    # an existing empty file) plus staged candidates before committing target 1.
    journal_targets: list[dict[str, Any]] = []
    for state in states:
        slug = f"{state['ordinal']:02d}-{Path(state['relative_path']).name}"
        before_relative: str | None = None
        if state["existed_before"]:
            before_path = destination / f"{slug}.before"
            _write_immutable_bytes(before_path, state["before"])
            if before_path.read_bytes() != state["before"]:
                raise PermissionError("local runtime migration preimage staging mismatch")
            before_relative = before_path.relative_to(root).as_posix()
            allowed_write_paths.append(before_relative)
        candidate_relative: str | None = None
        if state["desired_exists"]:
            candidate_path = destination / f"{slug}.candidate"
            _write_immutable_bytes(candidate_path, state["payload"])
            if candidate_path.read_bytes() != state["payload"]:
                raise PermissionError("local runtime migration candidate staging mismatch")
            candidate_relative = candidate_path.relative_to(root).as_posix()
            allowed_write_paths.append(candidate_relative)
        journal_targets.append(
            {
                "ordinal": state["ordinal"],
                "path": state["relative_path"],
                "existed_before": state["existed_before"],
                "before_size": len(state["before"]) if state["existed_before"] else None,
                "before_hash": _hash_bytes(state["before"])
                if state["existed_before"]
                else None,
                "before_path": before_relative,
                "desired_exists": state["desired_exists"],
                "candidate_size": len(state["payload"])
                if state["desired_exists"]
                else None,
                "candidate_hash": _hash_bytes(state["payload"])
                if state["desired_exists"]
                else None,
                "candidate_path": candidate_relative,
                "changed": state["changed"],
            }
        )
    journal = {
        "schema_version": "1.0.0",
        "record_type": "PREPARED",
        "request_id": request_id,
        "observed_at": _stamp(observed),
        "target_count": len(states),
        "targets": journal_targets,
        "control_cycle_error_action": cycle_error["action"],
        "queue_jobs_hash": queue_before["jobs_hash"],
        "quota_ledger_hash": ledger_before["state_hash"],
        "operational_effects_hash": effects_before["receipts_hash"],
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "technical_cost_brl": 0,
    }
    if media_runtime_migration is not None:
        journal["media_runtime_migration"] = media_runtime_migration
    if quality_runtime_migration is not None:
        journal["quality_runtime_migration"] = quality_runtime_migration
    if fingerprint_reconciliation is not None:
        journal["phase5_fingerprint_reconciliation"] = fingerprint_evidence
    journal_path = destination / "local-runtime-migration-journal.json"
    journal_payload = json.dumps(journal, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    _write_immutable_bytes(journal_path, journal_payload)
    if journal_path.read_bytes() != journal_payload:
        raise PermissionError("local runtime migration journal staging mismatch")
    journal_relative = journal_path.relative_to(root).as_posix()
    allowed_write_paths.append(journal_relative)

    final_sources: dict[str, Any] | None = None
    queue_after: dict[str, Any] | None = None
    ledger_after: dict[str, Any] | None = None
    effects_after: dict[str, Any] | None = None
    try:
        # The complete preimage is rechecked before every sequential commit so
        # no unowned concurrent edit can be silently overwritten.
        for state in states:
            if not state["changed"]:
                continue
            if fingerprint_reconciliation is not None and (
                file_hash(root / RUNTIME / "PAUSE") != pause_hash
                or input_fingerprint(root) != fingerprint_value["input_fingerprint"]
                or any(file_hash(path) != expected for path, expected in fingerprint_sources.items())
            ):
                raise PermissionError("PHASE5_FINGERPRINT_SOURCE_CHANGED_BEFORE_COMMIT")
            if recheck is not None:
                # A target which was absent at preparation time can become an
                # operational JSON file after an earlier *owned* replacement.
                # Pass only those completed, byte-pinned additions to the
                # paused boundary guard.  Existing targets remain part of its
                # immutable population, and callers must reject every path
                # outside their explicitly reviewed forward contract.
                owned_new_targets = tuple(
                    (current["relative_path"], current["payload"])
                    for current in states
                    if current["ordinal"] < state["ordinal"]
                    and current["changed"]
                    and not current["existed_before"]
                    and current["desired_exists"]
                )
                recheck(owned_new_targets)
            for current in states:
                already_committed = current["ordinal"] < state["ordinal"] and current["changed"]
                expected_exists = current["desired_exists"] if already_committed else current["existed_before"]
                expected_payload = current["payload"] if already_committed else current["before"]
                if not _target_matches_desired(
                    current["target"], exists=expected_exists, payload=expected_payload
                ):
                    raise PermissionError(
                        "local runtime migration target changed outside the transaction: "
                        + current["relative_path"]
                    )
            if state["desired_exists"]:
                (replace_target or _commit_migration_replacement)(state["target"], state["payload"])
            else:
                _commit_migration_removal(state["target"])
            if not _target_matches_desired(
                state["target"], exists=state["desired_exists"], payload=state["payload"]
            ):
                raise PermissionError(
                    "local runtime migration commit verification failed: "
                    + state["relative_path"]
                )
            allowed_write_paths.append(state["relative_path"])

        queue_after = queue_snapshot(root, now=observed)
        ledger_after = ledger_state_snapshot(root)
        effects_after = operational_effect_snapshot(root)
        if (
            queue_before["jobs_hash"] != queue_after["jobs_hash"]
            or ledger_before["state_hash"] != ledger_after["state_hash"]
            or effects_before["receipts_hash"] != effects_after["receipts_hash"]
        ):
            raise PermissionError("local derived-view migration changed operational state")
        final_sources = _control_source_preview(root)
        if fingerprint_reconciliation is not None and (
            file_hash(root / RUNTIME / "PAUSE") != pause_hash
            or input_fingerprint(root) != fingerprint_value["input_fingerprint"]
            or any(file_hash(path) != expected for path, expected in fingerprint_sources.items())
        ):
            raise PermissionError("PHASE5_FINGERPRINT_SOURCE_CHANGED_AFTER_COMMIT")
        if (
            final_sources["stage_count"] != 12
            or not final_sources["all_schemas_valid"]
            or final_sources["blockers"]
        ):
            raise PermissionError("migrated local stage sources did not remain clean")
        for state in states:
            if not _target_matches_desired(
                state["target"], exists=state["desired_exists"], payload=state["payload"]
            ):
                raise PermissionError(
                    "local runtime migration final target validation failed: "
                    + state["relative_path"]
                )
    except Exception as exc:
        rollback = rollback_targets(states)
        error_value = {
            "schema_version": "1.0.0",
            "record_type": "ROLLED_BACK" if rollback["verified"] else "ROLLBACK_FAILED",
            "request_id": request_id,
            "observed_at": _stamp(observed),
            "journal_path": journal_relative,
            "journal_hash": file_hash(journal_path),
            "failure_type": type(exc).__name__,
            "failure": str(exc),
            "rollback": rollback,
            "external_api_calls": 0,
            "publication_effects": 0,
            "operational_queue_mutations": 0,
            "technical_cost_brl": 0,
        }
        error_payload = json.dumps(error_value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
        error_path = destination / (
            "local-runtime-migration-error-" + uuid.uuid4().hex[:16] + ".json"
        )
        evidence_error: Exception | None = None
        try:
            _write_immutable_bytes(error_path, error_payload)
        except Exception as write_exc:
            evidence_error = write_exc
        if not rollback["verified"]:
            raise RuntimeError(
                "local runtime migration failed and byte-exact rollback could not be proven; "
                f"original={type(exc).__name__}:{exc}; rollback={rollback['errors']}; "
                f"evidence_error={evidence_error}"
            ) from exc
        if evidence_error is not None:
            raise RuntimeError(
                "local runtime migration rolled back but its error receipt could not be persisted: "
                f"{type(evidence_error).__name__}:{evidence_error}"
            ) from exc
        raise PermissionError(
            "local runtime migration failed and all targets were restored byte-for-byte; "
            f"evidence={error_path.relative_to(root).as_posix()}"
        ) from exc

    assert final_sources is not None
    assert queue_after is not None and ledger_after is not None and effects_after is not None
    outcome = {
        "schema_version": "1.0.0",
        "record_type": "COMMITTED",
        "request_id": request_id,
        "observed_at": _stamp(observed),
        "journal_path": journal_relative,
        "journal_hash": file_hash(journal_path),
        "target_count": len(states),
        "target_hashes": [
            {
                "path": state["relative_path"],
                "exists": state["desired_exists"],
                "content_hash": _hash_bytes(state["payload"])
                if state["desired_exists"]
                else None,
            }
            for state in states
        ],
        "control_cycle_error_action": cycle_error["action"],
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "technical_cost_brl": 0,
    }
    if media_runtime_migration is not None:
        outcome["media_runtime_migration"] = media_runtime_migration
    if quality_runtime_migration is not None:
        outcome["quality_runtime_migration"] = quality_runtime_migration
    outcome_path = destination / "local-runtime-migration-outcome.json"
    outcome_payload = json.dumps(outcome, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    try:
        if recheck is not None:
            # The final source check runs after all sequential replacements.
            # Carry the exact absent-before additions already authenticated by
            # this transaction, rather than asking the paused caller to treat
            # its own committed forward successor as foreign drift.
            recheck(tuple(
                (state["relative_path"], state["payload"])
                for state in states
                if state["changed"] and not state["existed_before"]
                and state["desired_exists"]
                and state["relative_path"]
                == "output/operations/phase6/goal-trajectory/current.json"
            ))
        _write_immutable_bytes(outcome_path, outcome_payload)
        if outcome_path.read_bytes() != outcome_payload:
            raise PermissionError("local runtime migration outcome evidence mismatch")
    except Exception as exc:
        rollback = rollback_targets(states)
        if not rollback["verified"]:
            raise RuntimeError(
                "local runtime migration outcome failed and rollback could not be proven: "
                + ",".join(rollback["errors"])
            ) from exc
        raise PermissionError(
            "local runtime migration outcome evidence failed; all targets were restored byte-for-byte"
        ) from exc
    outcome_relative = outcome_path.relative_to(root).as_posix()
    allowed_write_paths.append(outcome_relative)

    public_cycle_error = {key: value for key, value in cycle_error.items() if key != "payload"}
    result = {
        "status": "PASS",
        "mode": "LOCAL_DERIVED_VIEWS_ONLY",
        "action": evidence["action"],
        "observed_at": _stamp(observed),
        "prediction_runtime_path": PREDICTION_RUNTIME_PATH.as_posix(),
        "prediction_runtime_hash": file_hash(runtime_path),
        "executive_status_path": EXECUTIVE_STATUS_PATH.as_posix(),
        "executive_status_hash": file_hash(executive_path),
        "source": evidence["source"],
        "stage_count": final_sources["stage_count"],
        "all_stage_schemas_valid": final_sources["all_schemas_valid"],
        "stage_blockers": final_sources["blockers"],
        "queue_jobs_hash_before": queue_before["jobs_hash"],
        "queue_jobs_hash_after": queue_after["jobs_hash"],
        "quota_ledger_hash_before": ledger_before["state_hash"],
        "quota_ledger_hash_after": ledger_after["state_hash"],
        "operational_effects_hash_before": effects_before["receipts_hash"],
        "operational_effects_hash_after": effects_after["receipts_hash"],
        "transaction_journal_path": journal_relative,
        "transaction_journal_hash": file_hash(journal_path),
        "transaction_outcome_path": outcome_relative,
        "transaction_outcome_hash": file_hash(outcome_path),
        "control_cycle_error": public_cycle_error,
        "allowed_write_paths": sorted(allowed_write_paths),
        "external_api_calls": 0,
        "publication_effects": 0,
        "operational_queue_mutations": 0,
        "technical_cost_brl": 0,
    }
    if media_runtime_migration is not None:
        result["media_runtime_migration"] = media_runtime_migration
    if quality_runtime_migration is not None:
        result["quality_runtime_migration"] = quality_runtime_migration
    if finalize is not None:
        try:
            # Finalization is still within the same transaction.  Preserve
            # the exact absent-before additions through this last caller
            # boundary as well; otherwise the pre-finalize guard rejects the
            # transaction's own goal successor before ``finalize`` can bind
            # its receipt.
            recheck(tuple(
                (state["relative_path"], state["payload"])
                for state in states
                if state["changed"] and not state["existed_before"]
                and state["desired_exists"]
                and state["relative_path"]
                == "output/operations/phase6/goal-trajectory/current.json"
            ))
            finalize(result)
        except Exception as exc:
            rollback = rollback_targets(states)
            _write_immutable_bytes(destination / "paused-finalization-failure.json", _canonical_bytes({
                "status": "ROLLED_BACK" if rollback["verified"] else "ROLLBACK_FAILED",
                "rollback": rollback, "failure_type": type(exc).__name__,
                "restart_permitted": False,
            }))
            raise PermissionError("PAUSED_APPLICATION_FINALIZATION_FAILED") from exc
    return result


def _test_ids(path: Path, root: Path) -> Iterable[str]:
    yield from _static_test_ids(path.relative_to(root).as_posix(), path.read_bytes())


def _static_test_ids(relative: str, payload: bytes) -> Iterable[str]:
    from .maintenance_unittest_result import verify_static_load_tests

    module = relative[:-3].replace("/", ".")
    tree = ast.parse(payload, filename=relative)
    verify_static_load_tests(relative, payload, tree)
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for member in node.body:
            if isinstance(member, (ast.FunctionDef, ast.AsyncFunctionDef)) and member.name.startswith("test"):
                yield f"{module}.{node.name}.{member.name}"
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
            yield f"{module}.{node.name}"


def build_validation_manifests(root: Path = ROOT, *, output_dir: Path) -> dict[str, Any]:
    from .maintenance_unittest_result import _inventory_ids, declared_load_tests_aliases

    root = root.resolve()
    destination = (root / output_dir).resolve()
    try:
        destination.relative_to(root)
    except ValueError as exc:
        raise PermissionError("maintenance manifests must remain inside the workspace") from exc

    test_files: list[dict[str, Any]] = []
    test_ids: list[str] = []
    for path in sorted((root / "tests").glob("test_*.py")):
        payload = path.read_bytes()
        relative = path.relative_to(root).as_posix()
        ids = sorted(_static_test_ids(relative, payload))
        test_ids.extend(ids)
        test_files.append({
            "path": relative,
            "content_hash": "sha256:" + hashlib.sha256(payload).hexdigest(),
            "test_ids": ids,
        })
    aliases = declared_load_tests_aliases(test_files)
    execution_ids = test_ids + [alias["execution_id"] for alias in aliases]
    test_manifest = {
        "schema_version": "1.1.0",
        "discovery_pattern": "tests/test_*.py",
        "file_count": len(test_files),
        "method_count": len(test_ids),
        "alias_count": len(aliases),
        "test_count": len(execution_ids),
        "tests_hash": canonical_hash(execution_ids),
        "load_tests_aliases": aliases,
        "aliases_hash": canonical_hash(aliases),
        "files": test_files,
    }
    _inventory_ids(test_manifest)

    schemas: list[dict[str, str]] = []
    for path in sorted((root / "schemas").glob("*.schema.json")):
        value = _read(path)
        Draft202012Validator.check_schema(value)
        schemas.append({
            "path": path.relative_to(root).as_posix(),
            "content_hash": file_hash(path),
        })
    schema_manifest = {
        "schema_version": "1.0.0",
        "draft": "2020-12",
        "schema_count": len(schemas),
        "schemas_hash": canonical_hash(schemas),
        "schemas": schemas,
    }
    for item in test_files + schemas:
        if file_hash(root / item["path"]) != item["content_hash"]:
            raise PermissionError("validation source changed while building inventories")
    destination.mkdir(parents=True, exist_ok=True)
    test_path = destination / "test-inventory.json"
    schema_path = destination / "schema-inventory.json"
    _write(test_path, test_manifest)
    _write(schema_path, schema_manifest)
    return {
        "test_inventory_path": test_path.relative_to(root).as_posix(),
        "test_inventory_hash": file_hash(test_path),
        "test_count": test_manifest["test_count"],
        "test_file_count": test_manifest["file_count"],
        "schema_inventory_path": schema_path.relative_to(root).as_posix(),
        "schema_inventory_hash": file_hash(schema_path),
        "schema_count": schema_manifest["schema_count"],
    }


def _cli() -> int:
    parser = argparse.ArgumentParser(description="Fail-closed local maintenance protocol")
    parser.add_argument("--root", type=Path, default=ROOT)
    sub = parser.add_subparsers(dest="command", required=True)

    request = sub.add_parser("request")
    request.add_argument("--request-id", required=True)
    request.add_argument("--requester-pid", type=int, required=True)
    request.add_argument("--guard-seconds", type=int, default=1800)

    recovery = sub.add_parser("arm-recovery")
    recovery.add_argument("--request-id", required=True)
    recovery.add_argument("--manager-pid", type=int, required=True)
    recovery.add_argument("--duration-seconds", type=int, required=True)

    snapshot = sub.add_parser("snapshot")
    snapshot.add_argument("--output", type=Path, required=True)

    inventory = sub.add_parser("inventory")
    inventory.add_argument("--output-dir", type=Path, required=True)

    sub.add_parser("preview-local-runtime")

    paused = sub.add_parser("apply-paused", help="Explicit local application; never restart")
    paused.add_argument("--proof-envelope", type=Path, required=True)
    paused.add_argument("--expected-proof-hash", required=True)
    paused.add_argument("--expected-candidate-hash", required=True)

    migrate_runtime = sub.add_parser("migrate-local-runtime")
    migrate_runtime.add_argument("--request-id", required=True)
    migrate_runtime.add_argument("--former-manager-pid", type=int, required=True)
    migrate_runtime.add_argument("--former-launcher-pid", type=int, required=True)
    migrate_runtime.add_argument("--evidence-dir", type=Path, required=True)

    validate_document = sub.add_parser("validate")
    validate_document.add_argument("--schema", required=True)
    validate_document.add_argument("--document", type=Path, required=True)

    inspect = sub.add_parser("inspect")
    inspect.add_argument("--manager-pid", type=int, required=True)
    inspect.add_argument("--guard-seconds", type=int, default=1800)
    inspect.add_argument("--output", type=Path, required=True)

    boundary = sub.add_parser("boundary")
    boundary.add_argument("--request-id", required=True)
    boundary.add_argument("--manager-pid", type=int, required=True)
    boundary.add_argument("--guard-seconds", type=int, required=True)
    boundary.add_argument("--role", choices=("PRE_RELEASE", "POST_CYCLE"), required=True)
    boundary.add_argument("--require-barrier", choices=("true", "false"), required=True)
    boundary.add_argument("--output", type=Path, required=True)

    args = parser.parse_args()
    root = args.root.resolve()
    if args.command == "request":
        value = create_request(
            root,
            request_id=args.request_id,
            requester_pid=args.requester_pid,
            guard_seconds=args.guard_seconds,
        )
        print(json.dumps(value, ensure_ascii=False))
    elif args.command == "arm-recovery":
        value = arm_recovery_window(
            root,
            request_id=args.request_id,
            manager_pid=args.manager_pid,
            duration_seconds=args.duration_seconds,
        )
        print(json.dumps(value, ensure_ascii=False))
    elif args.command == "snapshot":
        output = (root / args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError as exc:
            raise PermissionError("queue snapshot output must remain inside the workspace") from exc
        value = queue_snapshot(root)
        _write(output, value)
        print(json.dumps({"path": output.relative_to(root).as_posix(), "content_hash": file_hash(output), "jobs_hash": value["jobs_hash"]}))
    elif args.command == "inventory":
        print(json.dumps(build_validation_manifests(root, output_dir=args.output_dir)))
    elif args.command == "preview-local-runtime":
        print(json.dumps(preview_local_runtime_migration(root), ensure_ascii=False))
    elif args.command == "apply-paused":
        from .maintenance_paused_application import apply_paused
        value = apply_paused(
            root, proof_envelope=args.proof_envelope,
            expected_proof_hash=args.expected_proof_hash,
            expected_candidate_hash=args.expected_candidate_hash,
        )
        # Do not print a second JSON representation: the launcher/D-116
        # witness requires stdout to be the committed receipt's exact bytes.
        sys.stdout.buffer.write(committed_application_stdout(root, value))
    elif args.command == "migrate-local-runtime":
        print(json.dumps(migrate_local_runtime_views(
            root,
            request_id=args.request_id,
            former_manager_pid=args.former_manager_pid,
            former_launcher_pid=args.former_launcher_pid,
            evidence_dir=args.evidence_dir,
        ), ensure_ascii=False))
    elif args.command == "validate":
        value = _read((root / args.document).resolve())
        validate(root, args.schema, value)
        print(json.dumps({"status": "PASS", "content_hash": file_hash((root / args.document).resolve())}))
    elif args.command == "inspect":
        output = (root / args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError as exc:
            raise PermissionError("quiescence inspection output must remain inside the workspace") from exc
        value = inspect_quiescence(
            root,
            manager_pid=args.manager_pid,
            guard_seconds=args.guard_seconds,
        )
        _write(output, value)
        print(json.dumps({
            "path": output.relative_to(root).as_posix(),
            "content_hash": file_hash(output),
            "blockers": value["blockers"],
        }))
    elif args.command == "boundary":
        output = (root / args.output).resolve()
        try:
            output.relative_to(root)
        except ValueError as exc:
            raise PermissionError("maintenance boundary output must remain inside the workspace") from exc
        value = capture_operational_boundary(
            root,
            manager_pid=args.manager_pid,
            request_id=args.request_id,
            guard_seconds=args.guard_seconds,
            role=args.role,
            require_barrier=args.require_barrier == "true",
        )
        _write(output, value)
        print(json.dumps({
            "path": output.relative_to(root).as_posix(),
            "content_hash": file_hash(output),
            "blockers": value["blockers"],
        }))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
