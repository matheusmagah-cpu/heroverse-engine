from __future__ import annotations

import fnmatch
import hashlib
from datetime import datetime, timezone
from typing import Any


PROTECTED_ACTIONS = {
    "PUBLISH",
    "UPLOAD",
    "SCHEDULE_PUBLICATION",
    "SPEND",
    "RUN_ADS",
    "ADD_PAID_PROVIDER",
    "CHANGE_CREDENTIALS",
    "RIGHTS_EXCEPTION",
    "CHANGE_CHANNEL_IDENTITY",
    "DELETE_DATA",
}
PROHIBITED_ACTIONS = {
    "EVADE_CONTENT_ID",
    "REMOVE_WATERMARK",
    "MASK_COPY",
    "FABRICATE_RIGHTS_EVIDENCE",
}


def _stable_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:20]
    return f"{prefix}-{digest}"


def _utc_now(created_at: str | None) -> str:
    return created_at or datetime.now(timezone.utc).isoformat()


def _rule_for(action: str, rules: list[dict[str, Any]]) -> dict[str, Any] | None:
    exact = [rule for rule in rules if rule["action_pattern"] == action]
    if exact:
        return exact[0]
    matches = [rule for rule in rules if fnmatch.fnmatchcase(action, rule["action_pattern"])]
    return matches[0] if matches else None


def evaluate_phase5_command(
    command: dict[str, Any],
    envelope: dict[str, Any],
    *,
    created_at: str | None = None,
) -> dict[str, Any]:
    """Evaluate one Phase 5 command without executing or self-approving it.

    The function is fail-closed. Protected actions may only become
    ``AWAITING_APPROVAL``; prohibited actions always remain blocked.
    """

    checks: list[dict[str, str]] = []
    reasons: list[str] = []

    def check(check_id: str, ok: bool, pass_evidence: str, fail_evidence: str) -> None:
        checks.append(
            {
                "check_id": check_id,
                "status": "PASS" if ok else "FAIL",
                "evidence": pass_evidence if ok else fail_evidence,
            }
        )
        if not ok:
            reasons.append(fail_evidence)

    action = str(command.get("action", ""))
    channel_id = command.get("channel_id")
    cost = float(command.get("input", {}).get("external_cost", 0.0))
    publication_requested = bool(command.get("input", {}).get("publication_requested", False))
    approval_id = command.get("approval_id")

    check("envelope-approved", envelope.get("status") == "APPROVED", "envelope APPROVED", "envelope is not APPROVED")
    check("phase-authorized", command.get("phase") == envelope.get("authorized_phase") == 5, "Phase 5 authorized", "command or envelope is outside Phase 5")
    check("channel-authorized", channel_id in envelope.get("channel_ids", []), "channel inside envelope", "channel outside envelope")
    check("budget-envelope", cost <= float(envelope.get("budget", {}).get("maximum_per_action", -1)), "per-action cost inside envelope", "per-action cost exceeds envelope")
    check("no-hidden-publication", not publication_requested, "publication not requested", "publication is a protected action")

    rule = _rule_for(action, envelope.get("action_rules", []))
    if action in PROHIBITED_ACTIONS:
        classification = "PROHIBITED"
    elif action in PROTECTED_ACTIONS or publication_requested:
        classification = "PROTECTED"
    elif rule:
        classification = str(rule["classification"])
    else:
        classification = "SUPERVISED"
        reasons.append("no matching approved action rule")
        checks.append({"check_id": "action-rule", "status": "NEEDS_REVIEW", "evidence": "no matching approved action rule"})

    if classification == "PROHIBITED":
        decision = "BLOCK"
        reasons.append("action is permanently prohibited")
    elif classification == "PROTECTED":
        decision = "AWAITING_APPROVAL" if not approval_id else "BLOCK"
        reasons.append("protected action requires an approval validated outside this evaluator")
    elif any(item["status"] in {"FAIL", "BLOCKED"} for item in checks):
        decision = "BLOCK"
    elif classification == "AUTOMATIC":
        decision = "ALLOW"
    else:
        decision = "AWAITING_APPROVAL"
        reasons.append("supervised action is not automatically executable")

    timestamp = _utc_now(created_at)
    command_id = str(command.get("command_id", "missing-command"))
    envelope_id = str(envelope.get("envelope_id", "missing-envelope"))
    return {
        "schema_version": "1.0.0",
        "policy_decision_id": _stable_id("policy", command_id, envelope_id, action, decision),
        "command_id": command_id,
        "envelope_id": envelope_id,
        "classification": classification,
        "decision": decision,
        "checks": checks,
        "reasons": sorted(set(reasons)),
        "created_at": timestamp,
    }
