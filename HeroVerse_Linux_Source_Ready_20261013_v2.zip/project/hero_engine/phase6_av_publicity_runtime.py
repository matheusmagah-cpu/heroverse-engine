"""Closed local file profile, not worker authentication or detector calibration.

Only standard-library code is imported. Capture is read-only and unapproved;
validation requires an externally pinned profile, not a caller-selected runtime.
The worker must later enforce isolated startup and observe actual import origins.
"""
from __future__ import annotations

import base64
import csv
from datetime import datetime, timezone
from email.parser import BytesParser
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import time

VERSION = "phase6-av-publicity-runtime-files-v1"
PROFILE_KIND = "LOCAL_PUBLICITY_RUNTIME_V1"
CODE_ROOT = Path(__file__).absolute().parents[1]
MODULE_PATH = Path(__file__).absolute()
BASE_PYTHON = Path("C:/Users/mathe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python")
FFMPEG_DIRECTORY = Path("C:/ffmpeg")
DISTRIBUTIONS = {
    "opencv_python-5.0.0.93.dist-info": ("opencv-python", "5.0.0.93", ("cv2",)),
    "numpy-2.5.2.dist-info": ("numpy", "2.5.2", ("numpy", "numpy.libs")),
}
EXECUTABLE_SUFFIXES = frozenset((".py", ".pyc", ".pyd", ".dll", ".zip"))
BASE_FILES = ("python.exe", "python3.dll", "python312.dll", "vcruntime140.dll",
              "vcruntime140_1.dll", "LICENSE.txt")
NUMPY_SCRIPTS = ("f2py.exe", "numpy-config.exe")
AUTHORITY = dict.fromkeys(("worker_authenticated", "detector_calibrated", "source_admitted",
                           "quality_approved", "publicity_approved", "render_authorized",
                           "queue_authorized", "publication_authorized"), False)
LIMITATIONS = [
    "OBSERVED_LOCAL_BYTES_NOT_PUBLISHER_SIGNATURE_OR_SUPPLY_CHAIN_ATTESTATION",
    "NO_WORKER_PROCESS_IMPORT_ORIGIN_OR_LOADED_DLL_OBSERVATION",
    "NO_DECODE_INFERENCE_CALIBRATION_OR_MEDIA_APPROVAL",
    "STDLIB_NONEXECUTABLE_DATA_AND_BASE_SITE_PACKAGES_OUTSIDE_FILE_SCOPE",
    "WINDOWS_KERNEL_SYSTEM_DLLS_AND_IN_MEMORY_CODE_NOT_ATTESTED",
    "LICENSE_FILES_PRESERVED_NOT_A_NEW_LEGAL_OPINION",
    "PYVENV_CONFIGURATION_VERSION_IS_NOT_AN_OBSERVED_INTERPRETER_VERSION",
]
PROFILE_CAP = 8 * 1024**2
METADATA_CAP = 8 * 1024**2
FILE_CAP = 128 * 1024**2
FFMPEG_CAP = 160 * 1024**2
CHUNK_BYTES = 1024**2
BAD_ATTRIBUTES = 0x1000 | 0x40000 | 0x400000


class RuntimeProfileError(ValueError):
    pass


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise RuntimeProfileError("duplicate JSON key")
            result[key] = value
        return result
    value = json.loads(raw, object_pairs_hook=pairs)
    _canonical(value)
    return value


def _same(left, right, reason):
    if _canonical(left) != _canonical(right):
        raise RuntimeProfileError(reason)


def _resident(path):
    path = Path(path).absolute()
    if ".." in path.parts:
        raise RuntimeProfileError("parent traversal forbidden")
    for part in (path, *path.parents):
        info = part.lstat()
        if (stat.S_ISLNK(info.st_mode) or part.is_symlink()
                or getattr(part, "is_junction", lambda: False)()
                or getattr(info, "st_file_attributes", 0) & BAD_ATTRIBUTES):
            raise RuntimeProfileError("linked or nonresident runtime path")
    return path


def _root(root):
    root = _resident(Path(root))
    if root != _resident(CODE_ROOT) or not root.is_dir():
        raise RuntimeProfileError("fixed canonical project root required")
    return root


def _binding(item):
    if (type(item) is not dict or set(item) != {"path", "sha256", "size_bytes"}
            or type(item["path"]) is not str or not item["path"]
            or type(item["sha256"]) is not str
            or re.fullmatch(r"sha256:[0-9a-f]{64}", item["sha256"]) is None
            or type(item["size_bytes"]) is not int or item["size_bytes"] <= 0):
        raise RuntimeProfileError("external positive binding triple required")


class _Files:
    """Hash the actual consumed stream; retain no large binary in memory."""
    def __init__(self):
        self.items = {}
        self.bytes_read = 0

    def read(self, path, *, cap, capture=False, expected=None):
        path = _resident(path)
        before = path.stat()
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or not 0 <= before.st_size <= cap or (capture and cap > METADATA_CAP)
                or (before.st_size == 0 and path.suffix.lower() in {".exe", ".pyd", ".dll", ".pyc", ".zip"})):
            raise RuntimeProfileError("nonregular, hardlinked or oversized runtime file")
        identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns)
        digest, chunks, total = hashlib.sha256(), [], 0
        with path.open("rb") as stream:
            if identity(os.fstat(stream.fileno())) != identity(before):
                raise RuntimeProfileError("file handle identity changed before reading")
            while chunk := stream.read(CHUNK_BYTES):
                total += len(chunk)
                self.bytes_read += len(chunk)
                if total > cap:
                    raise RuntimeProfileError("runtime stream exceeds fixed cap")
                digest.update(chunk)
                if capture:
                    chunks.append(chunk)
            if identity(os.fstat(stream.fileno())) != identity(before):
                raise RuntimeProfileError("runtime file changed during reading")
        if identity(_resident(path).stat()) != identity(before) or total != before.st_size:
            raise RuntimeProfileError("runtime path changed during reading")
        item = {"path": str(path), "sha256": "sha256:" + digest.hexdigest(), "size_bytes": total}
        if expected is not None:
            _same(item, expected, "runtime file bytes differ from external profile")
        prior = self.items.setdefault(str(path), (item, cap))
        _same(prior[0], item, "runtime file drift inside profile operation")
        if prior[1] != cap:
            raise RuntimeProfileError("one file has inconsistent fixed read limits")
        return b"".join(chunks) if capture else item

    def recheck(self):
        for item, cap in tuple(self.items.values()):
            self.read(item["path"], cap=cap, expected=item)


def _population(root):
    site = root / ".venv/Lib/site-packages"
    base = _resident(BASE_PYTHON)
    ffmpeg = _resident(FFMPEG_DIRECTORY)
    found = sorted(p.name for p in site.iterdir()
                   if p.name.endswith(".dist-info") and
                   (p.name.startswith("opencv") or p.name.startswith("numpy-")))
    if found != sorted(DISTRIBUTIONS):
        raise RuntimeProfileError("distribution installation absent or ambiguous")
    paths, directories = {}, set()
    def add(path, cap=FILE_CAP):
        path = _resident(path)
        key = os.path.normcase(str(path))
        if key in paths and paths[key] != (str(path), cap):
            raise RuntimeProfileError("aliased or divergent inventory path")
        paths[key] = (str(path), cap)
    def walk(directory, *, executables_only=False, excluded=None):
        directory = _resident(directory)
        if not directory.is_dir():
            raise RuntimeProfileError("required runtime directory absent")
        for current, names, files in os.walk(directory, followlinks=False):
            current = _resident(current)
            directories.add(str(current))
            for name in tuple(names):
                path = _resident(current / name)
                if excluded is not None and path == excluded:
                    names.remove(name)
            for name in files:
                path = _resident(current / name)
                if not executables_only or path.suffix.lower() in EXECUTABLE_SUFFIXES:
                    add(path, METADATA_CAP if path.name in {"METADATA", "RECORD"} else FILE_CAP)
    for package in ("cv2", "numpy", "numpy.libs"):
        walk(site / package)  # Includes caches, tests, licenses and package data.
    for dist in DISTRIBUTIONS:
        walk(site / dist)
        for name in ("METADATA", "RECORD", "WHEEL", "INSTALLER"):
            add(site / dist / name, METADATA_CAP if name in {"METADATA", "RECORD"} else FILE_CAP)
    walk(base / "Lib", executables_only=True, excluded=base / "Lib/site-packages")
    walk(base / "DLLs", executables_only=True)
    for name in BASE_FILES:
        add(base / name)
    for name in ("ffmpeg.exe", "ffprobe.exe"):
        add(ffmpeg / "bin" / name, FFMPEG_CAP)
    add(ffmpeg / "LICENSE.txt")
    add(root / ".venv/pyvenv.cfg", METADATA_CAP)
    add(root / ".venv/Scripts/python.exe")
    for name in NUMPY_SCRIPTS:
        add(root / ".venv/Scripts" / name)
    add(MODULE_PATH, METADATA_CAP)
    absent = [base / "python312.zip", base / "python._pth", base / "python312._pth",
              root / ".venv/Lib/x64/vc17/bin", site / "numpy/_distributor_init_local.py"]
    for path in absent:
        # Check existing ancestors without following an optional path/link.
        for parent in path.parents:
            if parent.exists():
                _resident(parent)
                break
        if os.path.lexists(path):
            raise RuntimeProfileError("forbidden optional import or DLL path appeared")
    return {"files": sorted(paths.values()), "directories": sorted(directories),
            "required_absent_paths": sorted(map(str, absent))}


def _distribution_records(root, files, bindings):
    site = root / ".venv/Lib/site-packages"
    result = []
    for dist, (name, version, packages) in DISTRIBUTIONS.items():
        directory = site / dist
        metadata = BytesParser().parsebytes(files.read(directory / "METADATA", cap=METADATA_CAP, capture=True), headersonly=True)
        if metadata.get_all("Name") != [name] or metadata.get_all("Version") != [version]:
            raise RuntimeProfileError("distribution metadata identity/version differs")
        license_fields = metadata.get_all("License-File", [])
        if not license_fields:
            raise RuntimeProfileError("distribution license provenance absent")
        licenses = []
        for relative in license_fields:
            suffix = PurePosixPath(relative)
            if suffix.is_absolute() or ".." in suffix.parts or "\\" in relative:
                raise RuntimeProfileError("invalid distribution license path")
            candidates = [directory / suffix, directory / "licenses" / suffix]
            candidates = [path for path in candidates if str(path) in bindings]
            if len(candidates) != 1 or bindings[str(candidates[0])]["size_bytes"] == 0:
                raise RuntimeProfileError("license file absent or ambiguous")
            licenses.append(bindings[str(candidates[0])])
        raw = files.read(directory / "RECORD", cap=METADATA_CAP, capture=True)
        listed, hashed, unhashed = set(), 0, 0
        for row in csv.reader(io.StringIO(raw.decode("utf-8"), newline=""), strict=True):
            if len(row) != 3:
                raise RuntimeProfileError("RECORD row must have exactly three fields")
            relative, encoded, size = row
            if relative in listed or not relative or "\\" in relative:
                raise RuntimeProfileError("duplicate or invalid RECORD row")
            listed.add(relative)
            if relative in ("../../Scripts/f2py.exe", "../../Scripts/numpy-config.exe") and name == "numpy":
                path = root / ".venv/Scripts" / PurePosixPath(relative).name
            else:
                suffix = PurePosixPath(relative)
                if (suffix.is_absolute() or ".." in suffix.parts or suffix.as_posix() != relative
                        or suffix.parts[0] not in (*packages, dist)):
                    raise RuntimeProfileError("RECORD escapes exact distribution roots")
                path = site / suffix
            item = bindings.get(str(path))
            if item is None:
                raise RuntimeProfileError("RECORD file absent from physical inventory")
            if encoded:
                if re.fullmatch(r"sha256=[A-Za-z0-9_-]{43}", encoded) is None or re.fullmatch(r"0|[1-9][0-9]*", size) is None:
                    raise RuntimeProfileError("invalid RECORD hash or size")
                digest = base64.urlsafe_b64decode(encoded[7:] + "=").hex()
                if item["sha256"] != "sha256:" + digest or item["size_bytes"] != int(size):
                    raise RuntimeProfileError("distribution file contradicts RECORD")
                hashed += 1
            elif size or (path != directory / "RECORD" and path.suffix != ".pyc"):
                raise RuntimeProfileError("only RECORD itself and recorded caches may lack wheel hashes")
            else:
                unhashed += 1
        unrecorded_caches = []
        owned_roots = tuple(site / package for package in (*packages, dist))
        for path_text in bindings:
            path = Path(path_text)
            if not any(path.is_relative_to(prefix) for prefix in owned_roots):
                continue
            relative = path.relative_to(site).as_posix()
            if relative not in listed:
                if path.suffix != ".pyc" or "__pycache__" not in path.parts:
                    raise RuntimeProfileError("unrecorded non-cache distribution file")
                unrecorded_caches.append(path_text)
        result.append({"name": name, "metadata_version": version, "record": bindings[str(directory / "RECORD")],
                       "hashed_record_files": hashed, "unhashed_record_rows": unhashed,
                       "locally_observed_unrecorded_caches": sorted(unrecorded_caches), "licenses": licenses})
    return result


def _compose(root, files):
    population = _population(root)
    bindings = {path: files.read(path, cap=cap) for path, cap in population["files"]}
    cfg = files.read(root / ".venv/pyvenv.cfg", cap=METADATA_CAP, capture=True).decode("utf-8-sig")
    settings = {}
    for line in cfg.splitlines():
        if not line.strip():
            continue
        if "=" not in line:
            raise RuntimeProfileError("malformed venv configuration")
        key, value = (part.strip() for part in line.split("=", 1))
        if key in settings:
            raise RuntimeProfileError("duplicate venv configuration key")
        settings[key] = value
    if (settings.get("home") != str(BASE_PYTHON) or settings.get("executable") != str(BASE_PYTHON / "python.exe")
            or settings.get("include-system-site-packages") != "false"):
        raise RuntimeProfileError("venv does not identify the fixed isolated base")
    distributions = _distribution_records(root, files, bindings)
    profile = {"kind": PROFILE_KIND, "version": VERSION, "project_root": str(root),
               "base_python": str(BASE_PYTHON), "site_packages": str(root / ".venv/Lib/site-packages"),
               "ffmpeg_directory": str(FFMPEG_DIRECTORY), "population": population,
               "file_bindings": sorted(bindings.values(), key=lambda item: item["path"]),
               "distribution_records": distributions, "authority": dict(AUTHORITY),
               "technical_cost_brl": 0, "limitations": list(LIMITATIONS),
               "future_worker_constraints": {"required_flags": ["-I", "-S", "-B"],
                   "base_site_packages_allowed": False, "actual_module_origins_observed": False,
                   "bytecode_policy": "EXISTING_CACHES_HASHED_NO_NEW_WRITES_NOT_NO_CACHE_READS"}}
    _same(population, _population(root), "runtime inventory changed while profiling")
    return profile


def _finish(root, files, profile):
    files.recheck()
    _same(profile["population"], _population(root), "runtime inventory changed at final recheck")


def _measurement(start, started_at, files):
    return {"started_at": started_at, "elapsed_seconds": time.perf_counter() - start,
            "unique_file_count": len(files.items), "unique_file_bytes": sum(item[0]["size_bytes"] for item in files.items.values()),
            "streamed_bytes_including_rechecks": files.bytes_read,
            "scope": "LOCAL_READ_ONLY_PROFILING_NOT_WORKER_EXECUTION"}


def build_profile(root):
    """Return deterministic profile + measured capture cost; write nothing."""
    start, started_at = time.perf_counter(), datetime.now(timezone.utc).isoformat()
    root, files = _root(root), _Files()
    profile = _compose(root, files)
    _finish(root, files, profile)
    return {"status": "CAPTURED_LOCAL_FILE_PROFILE_NOT_APPROVED", "profile": profile,
            "measurement": _measurement(start, started_at, files)}


def validate_profile(root, *, profile_binding):
    """Recompose bytes from fixed roots, never from candidate inventory paths."""
    start, started_at = time.perf_counter(), datetime.now(timezone.utc).isoformat()
    root, files = _root(root), _Files()
    _binding(profile_binding)
    path = Path(profile_binding["path"])
    path = _resident(path if path.is_absolute() else root / path)
    if not path.is_relative_to(root):
        raise RuntimeProfileError("profile document must be confined to the project")
    bound = {**profile_binding, "path": str(path)}
    raw = files.read(path, cap=PROFILE_CAP, capture=True, expected=bound)
    candidate = _json(raw)
    keys = {"kind", "version", "project_root", "base_python", "site_packages", "ffmpeg_directory",
            "population", "file_bindings", "distribution_records", "authority", "technical_cost_brl",
            "limitations", "future_worker_constraints"}
    if type(candidate) is not dict or set(candidate) != keys:
        raise RuntimeProfileError("closed runtime profile required")
    for key, value in {"kind": PROFILE_KIND, "version": VERSION, "project_root": str(root),
                       "base_python": str(BASE_PYTHON), "site_packages": str(root / ".venv/Lib/site-packages"),
                       "ffmpeg_directory": str(FFMPEG_DIRECTORY), "authority": AUTHORITY,
                       "technical_cost_brl": 0}.items():
        _same(candidate[key], value, "runtime profile header or authority differs")
    _same(candidate["population"], _population(root), "candidate runtime inventory differs")
    expected = _compose(root, files)
    _same(candidate, expected, "externally pinned profile differs from fixed runtime population or bytes")
    _finish(root, files, expected)
    return {"version": VERSION, "status": "FILE_PROFILE_VALIDATED_NOT_ADMITTED",
            "profile_binding": bound, "profile_sha256": "sha256:" + hashlib.sha256(_canonical(expected)).hexdigest(),
            "file_count": len(expected["file_bindings"]), "measurement": _measurement(start, started_at, files),
            "authority": dict(AUTHORITY), "technical_cost_brl": 0, "limitations": list(LIMITATIONS),
            "decode_calls": 0, "inference_calls": 0, "process_calls": 0, "files_written": 0}
