"""Pure take-003 visual adapter for the Stage-C AV recipe.

This is deliberately not a general filtergraph API.  It reopens the exact
D-154 editorial-hook evidence, recompiles the frozen take-003 recipe, and
returns namespace-relative text artifacts plus an allowlisted filtergraph.
It never writes, renders, queues, admits, or grants authority.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .phase6_editorial_hook_recipe import build_plan, compile_filters, verify_geometry

ADAPTER_VERSION = "phase6-av-take003-editorial-visual-adapter-v2"
TAKE_ID = "take-003"
CHANNEL_ID = "UCuMF6pJQkyMzaVoAxFL86yA"
VIDEO_ID = "phase6-video-002-prepublication"
EXPECTED_NARRATION = "Name the pressure, test its story, then choose the faithful move."
LOCAL_START_FRAME = 0
LOCAL_END_FRAME = 150
GLOBAL_START_FRAME = 90
GLOBAL_END_FRAME = 240

_EXPECTED: dict[str, tuple[str, str]] = {
    "take_plan": (
        "output/production/phase6/video-002/production/take_plan.json",
        "547213577ad9e352efcc35aff0c6918dc3fd49f99d927a3696ceb6f9d770d1e5",
    ),
    "treatment_plan": (
        "output/production/phase6/video-002/production/creative_treatment_plan.json",
        "3ae77eb015cd2364f1741b016a3520b0d51e5c68c41c3a5f5bfea890da1120db",
    ),
    "allocation": (
        "output/production/phase6/video-002/production/asset_allocation.json",
        "9c8fc78db5fe9ea93430e9cfaacb2a497b85ee4e68f161a78974880770b0cbef",
    ),
    "style_bible": (
        "output/production/phase6/video-002/production/channel_style_bible.json",
        "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049",
    ),
    "retained_source": (
        "output/qa/phase6/diagnostics/layered-hook-proof-a1da6f2da24300a0c475f32c/source-full-span.mkv",
        "9b34d8938302b2636a2b858438f05f7303278c68aeec472c58f2f94c98ec9d04",
    ),
    "retained_geometry": (
        "output/qa/phase6/diagnostics/layered-hook-static-geometry-5134aa42820475a5f2f8d433/frame-verification.json",
        "4e28a583c7b0cab4a9c3333fb4e77f7884dea1ef45acaa5c2950061c2c969aa5",
    ),
    "diagnostic_verification": (
        "output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab/editorial-hook-receipt-verification-v1.json",
        "40679c5a60eef49fcd49557aa69909346c25a48a734b75fe568278fc63695f48",
    ),
    "font": (
        "C:/Windows/Fonts/bahnschrift.ttf",
        "eaad201da94cb323401fdb8cc760650803ddf8fd704cb9fa56317e6c69bc6fd6",
    ),
}

_IMPLEMENTATION: dict[str, tuple[str, str]] = {
    "editorial_recipe": (
        "hero_engine/phase6_editorial_hook_recipe.py",
        "610bd1d55e3273c22a1436e928990c34567c2d15d9b2017c87a970f00962d7ab",
    ),
    "layered_recipe": (
        "hero_engine/phase6_layered_hook_recipe.py",
        "2e6058fc2009de9e9ff30d62d900695425f8b8497d3ae8d471e84f01bf7f44d6",
    ),
    "visual_recipe": (
        "hero_engine/phase6_visual_recipe.py",
        "924fb073fb1c8943429dd42a2da0e77b25ed903c41dcc6a76ed521727ee1d28f",
    ),
    "take_plan_schema": (
        "schemas/take_plan.schema.json",
        "8fe58aa812135111918eee49706751496c5e68aed1178cc70b370d38ea7b36f3",
    ),
    "treatment_schema": (
        "schemas/phase6_creative_treatment_plan.schema.json",
        "fa1499754e350ac72ae58cffcd2b3c67ded436d6d33c3f6d332c0ede21985288",
    ),
    "allocation_schema": (
        "schemas/phase6_asset_allocation.schema.json",
        "d36f06dd65ca1aae6d75d379ea32528af5b3da075672aee11e62cce5fb9a18d6",
    ),
    "style_bible_schema": (
        "schemas/visual_continuity_bible.schema.json",
        "5dd8a5ce3963a4c0a99725d1d04469f65ce061e90977e9fcf48dbb87cbfa2f9e",
    ),
    "editorial_plan_schema": (
        "schemas/phase6_editorial_hook_plan.schema.json",
        "5b34bcc749eed786daaa347989999eb5c456e1f06584683da28a7a47e8461cc8",
    ),
}

_SCHEMA_FOR_INPUT = {
    "take_plan": "take_plan_schema",
    "treatment_plan": "treatment_schema",
    "allocation": "allocation_schema",
    "style_bible": "style_bible_schema",
}

_FALSE_AUTHORITY = {
    "production_authorized": False,
    "render_authorized": False,
    "release_authorized": False,
    "publication_authorized": False,
    "human_review_claimed": False,
}


class AVVisualRecipeAdapterError(ValueError):
    pass


def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise AVVisualRecipeAdapterError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json(raw: bytes, name: str) -> Any:
    try:
        return json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_pairs,
            parse_constant=lambda value: (_ for _ in ()).throw(
                AVVisualRecipeAdapterError(f"{name}: non-finite JSON constant {value}")
            ),
        )
    except AVVisualRecipeAdapterError:
        raise
    except Exception as exc:
        raise AVVisualRecipeAdapterError(f"{name}: invalid UTF-8 JSON: {exc}") from exc


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise AVVisualRecipeAdapterError(f"value is not canonical JSON: {exc}") from exc


def _sha(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _canonical_sha(value: Any) -> str:
    return _sha(_canonical(value))


def _workspace_root(root: Path) -> Path:
    resolved = root.resolve(strict=True)
    if not (resolved / "hero_engine").is_dir() or not (resolved / "schemas").is_dir():
        raise AVVisualRecipeAdapterError("root is not the project workspace")
    return resolved


def _normalize_path(root: Path, path: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def _expected_path(root: Path, expected: str) -> Path:
    raw = Path(expected)
    return raw.resolve(strict=True) if raw.is_absolute() else (root / raw).resolve(strict=True)


def _open_external_binding(
    root: Path, role: str, supplied: Any
) -> tuple[dict[str, Any], bytes, Path]:
    if role not in _EXPECTED:
        raise AVVisualRecipeAdapterError(f"unsupported binding role: {role}")
    if not isinstance(supplied, dict) or set(supplied) != {"path", "sha256", "size_bytes"}:
        raise AVVisualRecipeAdapterError(f"{role}: binding fields differ")
    expected_rel, expected_hex = _EXPECTED[role]
    expected = _expected_path(root, expected_rel)
    try:
        actual = _expected_path(root, supplied["path"])
    except (TypeError, OSError) as exc:
        raise AVVisualRecipeAdapterError(f"{role}: invalid binding path") from exc
    if actual != expected:
        raise AVVisualRecipeAdapterError(f"{role}: path differs from allowlisted source")
    if supplied["sha256"] != "sha256:" + expected_hex:
        raise AVVisualRecipeAdapterError(f"{role}: digest differs from allowlisted source")
    if type(supplied["size_bytes"]) is not int or supplied["size_bytes"] < 1:
        raise AVVisualRecipeAdapterError(f"{role}: size is invalid")
    raw = actual.read_bytes()
    if len(raw) != supplied["size_bytes"] or _sha(raw) != supplied["sha256"]:
        raise AVVisualRecipeAdapterError(f"{role}: bound bytes changed")
    pin = {"path": _normalize_path(root, actual), "sha256": supplied["sha256"],
           "size_bytes": len(raw)}
    return pin, raw, actual


def _open_pinned_file(root: Path, role: str, expected: tuple[str, str]) -> tuple[dict[str, Any], bytes, Path]:
    path = _expected_path(root, expected[0])
    raw = path.read_bytes()
    if _sha(raw) != "sha256:" + expected[1]:
        raise AVVisualRecipeAdapterError(f"{role}: implementation pin changed")
    return ({"path": _normalize_path(root, path), "sha256": _sha(raw),
             "size_bytes": len(raw)}, raw, path)


def _embedded_binding(
    root: Path, value: Any, name: str, *, expected_path: str | None = None
) -> tuple[dict[str, Any], bytes, Path]:
    if not isinstance(value, dict) or set(value) != {"path", "sha256", "bytes"}:
        raise AVVisualRecipeAdapterError(f"{name}: embedded binding fields differ")
    if type(value["bytes"]) is not int or value["bytes"] < 1:
        raise AVVisualRecipeAdapterError(f"{name}: embedded size is invalid")
    try:
        path = Path(value["path"]).resolve(strict=True)
    except (TypeError, OSError) as exc:
        raise AVVisualRecipeAdapterError(f"{name}: embedded path is invalid") from exc
    if expected_path is not None and path != _expected_path(root, expected_path):
        raise AVVisualRecipeAdapterError(f"{name}: embedded path differs")
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise AVVisualRecipeAdapterError(f"{name}: embedded path escaped workspace") from exc
    raw = path.read_bytes()
    if len(raw) != value["bytes"] or _sha(raw) != "sha256:" + value["sha256"]:
        raise AVVisualRecipeAdapterError(f"{name}: embedded bytes changed")
    return ({"path": _normalize_path(root, path), "sha256": _sha(raw),
             "size_bytes": len(raw)}, raw, path)


def _validate(schema: Any, value: Any, name: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        first = errors[0]
        where = ".".join(str(part) for part in first.path) or "$"
        raise AVVisualRecipeAdapterError(f"{name}: schema violation at {where}: {first.message}")


def _strict_timeline_context(timeline: Any) -> dict[str, Any]:
    if not isinstance(timeline, dict):
        raise AVVisualRecipeAdapterError("timeline must be an object")
    required = {"timeline_id", "status", "channel_id", "video_id", "clock", "duration",
                "units", "narration_fragment_map", "render_spans", "visual_events", "caption_cues"}
    if not required.issubset(timeline):
        raise AVVisualRecipeAdapterError("timeline context fields are incomplete")
    if timeline["channel_id"] != CHANNEL_ID or timeline["video_id"] != VIDEO_ID:
        raise AVVisualRecipeAdapterError("timeline channel/video identity differs")
    clock = timeline["clock"]
    if not isinstance(clock, dict) or {
        "sample_rate": clock.get("sample_rate"),
        "fps_numerator": clock.get("fps_numerator"),
        "fps_denominator": clock.get("fps_denominator"),
        "samples_per_frame": clock.get("samples_per_frame"),
    } != {"sample_rate": 24000, "fps_numerator": 30, "fps_denominator": 1,
         "samples_per_frame": 800}:
        raise AVVisualRecipeAdapterError("timeline frame/sample clock differs")
    duration = timeline["duration"]
    if (not isinstance(duration, dict)
            or type(duration.get("planned_total_frames")) is not int
            or duration["planned_total_frames"] < GLOBAL_END_FRAME):
        raise AVVisualRecipeAdapterError("timeline does not contain the complete 3-8 second window")
    fragments = [row for row in timeline["narration_fragment_map"]
                 if isinstance(row, dict) and row.get("take_id") == TAKE_ID]
    if len(fragments) != 1 or fragments[0].get("text") != EXPECTED_NARRATION:
        raise AVVisualRecipeAdapterError("timeline take-003 literal text differs")
    unit_id = fragments[0].get("unit_id")
    units = [row for row in timeline["units"]
             if isinstance(row, dict) and row.get("unit_id") == unit_id]
    if len(units) != 1:
        raise AVVisualRecipeAdapterError("timeline take-003 unit is not unique")
    unit = units[0]
    if (unit.get("slot_start_sample") != GLOBAL_START_FRAME * 800
            or unit.get("slot_end_sample_exclusive") != GLOBAL_END_FRAME * 800
            or unit.get("text") != EXPECTED_NARRATION
            or TAKE_ID not in unit.get("take_ids", [])):
        raise AVVisualRecipeAdapterError("timeline no longer preserves the frozen 3-8 second hook")
    for key in ("render_spans", "visual_events", "caption_cues"):
        if not isinstance(timeline[key], list):
            raise AVVisualRecipeAdapterError(f"timeline {key} must be an array")
    return {
        "timeline_id": timeline["timeline_id"],
        "timeline_status": timeline["status"],
        "timeline_sha256": _canonical_sha(timeline),
        "unit_id": unit_id,
        "unit_sha256": _canonical_sha(unit),
        "render_spans_sha256": _canonical_sha(timeline["render_spans"]),
        "visual_events_sha256": _canonical_sha(timeline["visual_events"]),
        "caption_cues_sha256": _canonical_sha(timeline["caption_cues"]),
        "planned_total_frames": duration["planned_total_frames"],
    }


def _diagnostic_chain(
    root: Path,
    receipt: dict[str, Any],
    plan: dict[str, Any],
    geometry: dict[str, Any],
    source_pin: dict[str, Any],
    geometry_pin: dict[str, Any],
    font_path: Path,
) -> tuple[str, list[tuple[str, dict[str, Any]]]]:
    if (receipt.get("schema_version") != "1.0.0"
            or receipt.get("scope") != "EDITORIAL_HOOK_RECEIPT_CHAIN_DIAGNOSTIC_ONLY"
            or receipt.get("status") != "PASS_FROZEN_RECEIPTS_RECOMPUTED_NOT_CREATIVE_APPROVAL"
            or receipt.get("target_run") != "editorial-hook-v1-01bb2c91eeccb03bebab"
            or receipt.get("native_stage_count") != 8):
        raise AVVisualRecipeAdapterError("diagnostic receipt identity/status differs")
    authority = receipt.get("authority")
    if not isinstance(authority, dict) or any(value is not False for value in authority.values()):
        raise AVVisualRecipeAdapterError("diagnostic receipt claims authority")
    chain = receipt.get("geometry_chain")
    if not isinstance(chain, dict) or chain.get("status") != "SOURCE_AND_GEOMETRY_RECEIPT_BOUND":
        raise AVVisualRecipeAdapterError("diagnostic geometry chain differs")
    if ("sha256:" + chain.get("source", {}).get("sha256", "") != source_pin["sha256"]
            or chain.get("source", {}).get("bytes") != source_pin["size_bytes"]
            or "sha256:" + chain.get("geometry", {}).get("sha256", "") != geometry_pin["sha256"]
            or chain.get("geometry", {}).get("bytes") != geometry_pin["size_bytes"]):
        raise AVVisualRecipeAdapterError("diagnostic source/geometry binding differs")

    intent_pin, intent_raw, _ = _embedded_binding(
        root, receipt.get("intent"), "diagnostic intent",
        expected_path="output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab/intent.json",
    )
    intent = _json(intent_raw, "diagnostic intent")
    if not isinstance(intent, dict) or intent.get("plan") != plan or intent.get("geometry") != geometry:
        raise AVVisualRecipeAdapterError("diagnostic intent no longer matches recomputed plan/geometry")

    report_pin, report_raw, _ = _embedded_binding(
        root, receipt.get("report"), "diagnostic report",
        expected_path="output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab/report.json",
    )
    report = _json(report_raw, "diagnostic report")
    if (not isinstance(report, dict)
            or report.get("status") != "VISUAL_PROTOTYPE_RENDERED_NOT_APPROVED"
            or report.get("geometry") != geometry
            or report.get("narration_audio_included") is not False
            or any(value is not False for value in report.get("authority", {}).values()
                   if isinstance(value, bool))):
        raise AVVisualRecipeAdapterError("diagnostic report boundary differs")

    render_stages = [row for row in receipt.get("stages", [])
                     if isinstance(row, dict) and row.get("stage") == "render"]
    if len(render_stages) != 1 or render_stages[0].get("returncode") != 0 or render_stages[0].get("timeout") is not False:
        raise AVVisualRecipeAdapterError("diagnostic render-stage receipt differs")
    terminal_pin, terminal_raw, _ = _embedded_binding(
        root, render_stages[0].get("terminal"), "diagnostic render terminal",
        expected_path="output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab/render-terminal.json",
    )
    terminal = _json(terminal_raw, "diagnostic render terminal")
    if (not isinstance(terminal, dict) or terminal.get("returncode") != 0
            or terminal.get("timeout") is not False or terminal.get("intent") != receipt.get("intent")):
        raise AVVisualRecipeAdapterError("diagnostic render terminal differs")
    dependencies = terminal.get("dependencies")
    if not isinstance(dependencies, list):
        raise AVVisualRecipeAdapterError("diagnostic render dependencies are missing")
    by_path: dict[Path, dict[str, Any]] = {}
    for item in dependencies:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise AVVisualRecipeAdapterError("diagnostic render dependency is malformed")
        path = Path(item["path"]).resolve(strict=False)
        if path in by_path:
            raise AVVisualRecipeAdapterError("diagnostic render dependency path is duplicated")
        by_path[path] = item

    run_rel = "output/qa/phase6/diagnostics/editorial-hook-v1-01bb2c91eeccb03bebab"
    needed = {
        "frozen_filtergraph": f"{run_rel}/filters.txt",
        "frozen_mechanism_text": f"{run_rel}/mechanism.txt",
        "frozen_system_text": f"{run_rel}/system.txt",
    }
    pins: list[tuple[str, dict[str, Any]]] = [
        ("diagnostic_intent", intent_pin), ("diagnostic_report", report_pin),
        ("diagnostic_render_terminal", terminal_pin),
    ]
    opened: dict[str, tuple[dict[str, Any], bytes, Path]] = {}
    for role, expected in needed.items():
        expected_abs = _expected_path(root, expected)
        if expected_abs not in by_path:
            raise AVVisualRecipeAdapterError(f"{role}: absent from frozen render dependencies")
        opened[role] = _embedded_binding(root, by_path[expected_abs], role, expected_path=expected)
        pins.append((role, opened[role][0]))

    text_by_filename = {row["filename"]: row["render_text"] for row in plan["overlays"]}
    if (opened["frozen_mechanism_text"][1] != text_by_filename["mechanism.txt"].encode("utf-8")
            or opened["frozen_system_text"][1] != text_by_filename["system.txt"].encode("utf-8")):
        raise AVVisualRecipeAdapterError("frozen drawtext bytes differ from recomputed plan")

    diagnostic_texts = {
        "mechanism.txt": opened["frozen_mechanism_text"][2],
        "system.txt": opened["frozen_system_text"][2],
    }
    absolute_graph = compile_filters(plan, font=font_path, texts=diagnostic_texts)
    if opened["frozen_filtergraph"][1] != absolute_graph.encode("utf-8"):
        raise AVVisualRecipeAdapterError("frozen filtergraph differs from recomputed recipe")

    relative_graph = absolute_graph
    logical = {
        "mechanism.txt": "meta/visual/take-003/mechanism.txt",
        "system.txt": "meta/visual/take-003/system.txt",
    }
    for filename, old_path in diagnostic_texts.items():
        old = str(old_path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
        new = logical[filename].replace("'", r"\'")
        token = f"textfile='{old}'"
        if relative_graph.count(token) != 1:
            raise AVVisualRecipeAdapterError("drawtext source path replacement is not unique")
        relative_graph = relative_graph.replace(token, f"textfile='{new}'")
    if str(root).replace("\\", "/") in relative_graph:
        raise AVVisualRecipeAdapterError("filtergraph retained a workspace-absolute generated path")
    return relative_graph, pins


def compile_take003_editorial_visual_spec(
    root: Path, *, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Compile the exact take-003 visual spec without performing an effect."""
    root = _workspace_root(root)
    if not isinstance(bindings, dict) or set(bindings) != set(_EXPECTED):
        raise AVVisualRecipeAdapterError("external binding roles differ")
    timeline_contract = _strict_timeline_context(timeline)

    implementation: list[tuple[str, dict[str, Any]]] = []
    implementation_raw: dict[str, Any] = {}
    for role, expected in _IMPLEMENTATION.items():
        pin, raw, _ = _open_pinned_file(root, role, expected)
        implementation.append((role, pin))
        if role.endswith("_schema"):
            implementation_raw[role] = _json(raw, role)

    opened: dict[str, tuple[dict[str, Any], bytes, Path]] = {}
    # Small controls first; the large source is read only after identities pass.
    for role in ("diagnostic_verification", "font", "take_plan", "treatment_plan",
                 "allocation", "style_bible", "retained_geometry", "retained_source"):
        opened[role] = _open_external_binding(root, role, bindings[role])

    documents: dict[str, Any] = {}
    for role in ("take_plan", "treatment_plan", "allocation", "style_bible"):
        documents[role] = _json(opened[role][1], role)
        _validate(implementation_raw[_SCHEMA_FOR_INPUT[role]], documents[role], role)
    geometry_doc = _json(opened["retained_geometry"][1], "retained geometry")
    receipt_doc = _json(opened["diagnostic_verification"][1], "diagnostic verification")

    plan = build_plan(
        documents["take_plan"], documents["treatment_plan"], documents["allocation"],
        documents["style_bible"], font=opened["font"][2],
    )
    _validate(implementation_raw["editorial_plan_schema"], plan, "editorial plan")
    if (plan.get("take_id") != TAKE_ID or plan.get("start_ms") != 3000
            or plan.get("end_ms") != 8000 or plan.get("duration_ms") != 5000
            or plan.get("narration") != EXPECTED_NARRATION):
        raise AVVisualRecipeAdapterError("recomputed plan no longer represents exact take-003")
    geometry = verify_geometry(plan, geometry_doc)
    if geometry != {
        "status": "PASS_GEOMETRIC_SEPARATION_ONLY", "frames": 150, "hulls": 450,
        "minimum_card_to_footer_pixels": 130.39999999999998,
        "semantics_approved": False, "motion_approved": False,
    }:
        raise AVVisualRecipeAdapterError("recomputed diagnostic geometry differs")

    filtergraph, diagnostic_pins = _diagnostic_chain(
        root, receipt_doc, plan, geometry, opened["retained_source"][0],
        opened["retained_geometry"][0], opened["font"][2],
    )
    generated_files = []
    for overlay in plan["overlays"]:
        raw = overlay["render_text"].encode("utf-8")
        generated_files.append({
            "role": overlay["role"],
            "relative_path": f"meta/visual/take-003/{overlay['filename']}",
            "sha256": _sha(raw), "size_bytes": len(raw), "content_utf8": overlay["render_text"],
        })

    dependencies: list[tuple[str, dict[str, Any]]] = [
        (role, opened[role][0]) for role in opened
    ] + implementation + diagnostic_pins
    seen: set[tuple[str, str]] = set()
    dependency_bindings = []
    dependency_roles = []
    for role, pin in dependencies:
        key = (role, pin["path"])
        if key in seen:
            raise AVVisualRecipeAdapterError("dependency role/path is duplicated")
        seen.add(key)
        dependency_bindings.append(copy.deepcopy(pin))
        dependency_roles.append({"role": role, "path": pin["path"], "sha256": pin["sha256"]})
    dependency_bindings.sort(key=lambda row: (row["path"], row["sha256"]))
    dependency_roles.sort(key=lambda row: (row["role"], row["path"]))

    blockers = [
        "STAGE_A_VERIFICATION_AND_ADMISSION_REQUIRED",
        "TAKE003_ONLY_FULL_TIMELINE_COVERAGE_INCOMPLETE",
        "RETAINED_DIAGNOSTIC_SOURCE_REQUIRES_PRODUCTION_RESIDENCY_RIGHTS_AND_PUBLICITY_RECHECK",
        "DIAGNOSTIC_GEOMETRIC_SEPARATION_IS_NOT_CREATIVE_OR_MOTION_APPROVAL",
        "AUDIO_NARRATIVE_AND_FULL_VIDEO_QUALITY_GATES_NOT_EVALUATED",
        "QUEUE_COMMIT_AND_GENERATION_NAMESPACE_REQUIRED_BEFORE_MATERIALIZATION",
    ]
    if timeline_contract["timeline_status"] != "TIMELINE_VALIDATED_NOT_ADMITTED":
        blockers.insert(0, "STAGE_A_TIMELINE_INCOMPLETE")

    spec: dict[str, Any] = {
        "schema_version": "1.0.0",
        "adapter_version": ADAPTER_VERSION,
        "status": "COMPILED_TAKE003_VISUAL_SPEC_NOT_ADMITTED",
        "scope": "TAKE003_EDITORIAL_HOOK_3_TO_8_SECONDS_ONLY",
        "channel_id": CHANNEL_ID,
        "video_id": VIDEO_ID,
        "take_id": TAKE_ID,
        "recipe_id": plan["recipe_id"],
        "plan_id": plan["plan_id"],
        "timeline_contract": timeline_contract,
        "source_binding": copy.deepcopy(opened["retained_source"][0]),
        "filtergraph": filtergraph,
        "generated_files": generated_files,
        "dependency_bindings": dependency_bindings,
        "dependency_roles": dependency_roles,
        "supported_span": {
            "fps": 30,
            "global_start_frame": GLOBAL_START_FRAME,
            "global_end_frame_exclusive": GLOBAL_END_FRAME,
            "local_start_frame": LOCAL_START_FRAME,
            "local_end_frame_exclusive": LOCAL_END_FRAME,
            "source_start_frame": 0,
            "source_end_frame_exclusive": 150,
            "local_event_boundaries": [0, 75, 150],
            "start_ms": 3000,
            "end_ms": 8000,
        },
        "coverage": {
            "covered_take_ids": [TAKE_ID],
            "covered_frame_count": 150,
            "planned_total_frame_count": timeline_contract["planned_total_frames"],
            "full_timeline_covered": False,
            "audio_covered": False,
            "captions_rendered": False,
            "semantics_approved": False,
            "motion_approved": False,
        },
        "geometry_observation": geometry,
        "blockers": blockers,
        "authority": copy.deepcopy(_FALSE_AUTHORITY),
        "technical_cost_brl": 0,
    }
    identity = copy.deepcopy(spec)
    spec["visual_spec_id"] = "phase6-av-visual-spec-" + _canonical_sha(identity)[7:31]
    spec["canonical_sha256"] = _canonical_sha(spec)
    return spec


def verify_take003_editorial_visual_spec(
    root: Path, candidate: dict[str, Any], *, timeline: dict[str, Any],
    bindings: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Recompile the adapter result; caller-supplied labels grant no trust."""
    expected = compile_take003_editorial_visual_spec(root, timeline=timeline, bindings=bindings)
    if _canonical(candidate) != _canonical(expected):
        raise AVVisualRecipeAdapterError("visual spec differs from pure recompilation")
    return copy.deepcopy(expected)
