"""Arithmetic pacing to the observed renewal, not a per-task cost forecast."""
from __future__ import annotations
import copy
import math
from datetime import datetime, timezone


def utc(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None or result.utcoffset().total_seconds() != 0:
        raise ValueError("explicit UTC timestamp required")
    return result.astimezone(timezone.utc)


def percent(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not 0 <= value <= 100:
        raise ValueError("finite percentage in [0,100] required")
    return float(value)


def calculate_runway(plan, *, observed_at, resets_at, used_percent, reserve_percent, known_project_ids):
    expected = {"version", "recorded_at", "basis", "active_project_ids", "paused_project_ids",
        "effective_until", "anchor_observed_at", "anchor_used_percent", "anchor_resets_at",
        "anchor_source", "enforcement"}
    if set(plan) != expected or plan["version"] != "1.0.0":
        raise ValueError("workload plan contract differs")
    active, paused = plan["active_project_ids"], plan["paused_project_ids"]
    if (not isinstance(active, list) or not active or not isinstance(paused, list)
            or len(active) != len(set(active)) or len(paused) != len(set(paused))
            or set(active) & set(paused) or set(active) | set(paused) != set(known_project_ids)):
        raise ValueError("active and paused operations must partition the known projects")
    if (plan["basis"] != "OWNER_DECLARED_OTHER_OPERATION_PAUSED"
            or plan["effective_until"] != "OWNER_RESUMES_OTHER_OPERATION"
            or plan["enforcement"] != "COOPERATIVE_SCHEDULING_NOT_HOST_HARD_CAP"):
        raise ValueError("pause is an owner declaration, not a host capability")
    now, recorded, anchor = utc(observed_at), utc(plan["recorded_at"]), utc(plan["anchor_observed_at"])
    anchor_reset = utc(plan["anchor_resets_at"])
    if now < recorded or anchor != recorded or anchor_reset <= anchor:
        raise ValueError("invalid workload plan timeline")
    used, reserve, anchor_used = percent(used_percent), percent(reserve_percent), percent(plan["anchor_used_percent"])
    remaining = 100-used; spendable = max(0., remaining-reserve)
    result = {"version": "codex-renewal-runway-v1", "observed_at": observed_at,
        "resets_at": resets_at, "remaining_seconds": None, "remaining_days": None,
        "remaining_percent": remaining, "reserve_percent": reserve,
        "spendable_percentage_points": spendable, "percentage_points_per_day": None,
        "percentage_points_per_hour": None, "planned_remaining_percent_now": None,
        "ahead_of_plan_percentage_points": None, "status": "UNAVAILABLE",
        "continuous_codex_guaranteed": False, "per_task_cost_forecast": "UNAVAILABLE",
        "local_runtime_may_continue_under_gates": True,
        "automatic_purchase_or_reset_authorized": False,
        "active_project_ids": copy.deepcopy(active), "paused_project_ids": copy.deepcopy(paused),
        "pause_verification": "OWNER_DECLARATION_NOT_ALL_HOST_ACTIVITY_VERIFIED",
        "credit_balance_converted_to_weekly_percent": False}
    if resets_at is None:
        return result
    reset = utc(resets_at)
    seconds = (reset-now).total_seconds()
    if seconds <= 0 or reset != anchor_reset or used < anchor_used:
        result["status"] = "REBASE_REQUIRED"
        return result
    days = seconds/86400
    anchor_spendable = max(0.,100-anchor_used-reserve)
    elapsed_fraction = (now-anchor).total_seconds()/(anchor_reset-anchor).total_seconds()
    planned_remaining = max(reserve,100-anchor_used-anchor_spendable*elapsed_fraction)
    ahead = max(0.,planned_remaining-remaining)
    result.update(remaining_seconds=seconds, remaining_days=days,
        percentage_points_per_day=spendable/days, percentage_points_per_hour=spendable/(seconds/3600),
        planned_remaining_percent_now=planned_remaining, ahead_of_plan_percentage_points=ahead,
        status="RESERVE_ONLY" if spendable == 0 else "AHEAD_OF_PLAN" if ahead > 1e-6 else "ON_PLAN")
    return result
