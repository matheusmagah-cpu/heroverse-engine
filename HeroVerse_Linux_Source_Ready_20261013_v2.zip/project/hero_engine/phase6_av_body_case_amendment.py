"""Versioned, read-only V5 -> V6 body-case amendment; no media authority.

Recompose the existing V5 chain and the exclusive body-case staging from fixed
documents. The pure compiler is replayed, never its stager/renderer. Caller A
must independently verify units, pin this implementation, and recheck this
same-call evidence after its later work. A serialized result is not an input.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import importlib.util
import math
from pathlib import Path

from . import phase6_av_question_case_amendment as prior
from . import phase6_av_static_sources as source
from .phase6_av_caption_intent import _binding, _resident
from .phase6_av_visual_intent import _state_entries
from .phase6_narration_audio_inventory import _json
from .phase6_narration_units import bytes_sha, canonical_sha

VERSION = "phase6-av-body-case-amendment-v1"
MODULE = "hero_engine/phase6_av_body_case_amendment.py"
TEST = "tests/test_phase6_av_body_case_amendment.py"
HERE = "output/qa/phase6/diagnostics/body-case-v1"
IDENTIFIER = "body-case-amendment-v1-ac645f2d8cb2fae3414b56c7"
DIRECTORY = HERE + "/staged/" + IDENTIFIER
PROJECTION_BINDING = {"path": DIRECTORY + "/staged-visual-v6-ba7dabb1ed63c35a19021648.json",
    "sha256": "sha256:ba7dabb1ed63c35a190216483e28fc2329f279f2125f347320f7d4efb23043c4"}
AMENDMENT_BINDING = {"path": DIRECTORY + "/" + IDENTIFIER + ".json",
    "sha256": "sha256:72c8c8eac653d690fd2afe5f2430d527541fd27d0cbd25e2c39da9753b2dcdcf"}
STAGING_BINDING = {"path": DIRECTORY + "/receipt.json",
    "sha256": "sha256:e56a4135141ded3cbff19bebfb6fb33ed2e6f4526c20e50fa2c67ab98572d3e0"}
CLAIM_BINDING = {"path": DIRECTORY + "/claim.json",
    "sha256": "sha256:18b3f41fb734702e2fd4289c6b1dfa280afeb3580a137093f1ed4803eb476ffd"}
SOURCE_BINDINGS = {
    "v5": {"path": prior.PROJECTION_BINDING["path"], "sha256": "7fd136fe0bc4557433b24e462ab8a91eddc0e4b1edb508c6b7c1b5285e001a92"},
    "bible": {"path": "output/production/phase6/video-002/production/channel_style_bible.json", "sha256": "c53ba3aaca842a57a7033e215359e5209496c7103423f2fa5a5abef4508c5049"},
    "a11": {"path": "output/operations/phase6/av-admission/timelines/phase6-av-timeline-06198f553f7dd8184307c7b8.json", "sha256": "10f31b09b293aac32e3cfc95d02d7cd830b86e22a9df580c37f1bec41011f3cb"},
    "uses": {"path": "output/operations/phase6/av-admission/static-asset-uses-v3/inspection.json", "sha256": "139a68f78c4a8c1ee88d30e8c029744159a4140fba0857bf7083293589f75f30"},
}
COMPILER = HERE + "/case_proposal.py"
STAGING_CODE = {
    HERE + "/stage_case_proposal.py": "2dfb858e8d49157e418c72b0ab81390b8fcf58695a4e6a4d6d8b9f983cb26086",
    HERE + "/test_stage_case_proposal.py": "0dd2d3ea40b7dca1803281b43b2dd9ae52cd649b46bdf60cdff3d3434525c252",
    COMPILER: "eeab6c1135ba9a259ff7f2fd3b0cf05ee07d0b2663c0724ff03ff748dbaa66b8",
    HERE + "/test_case_proposal.py": "88423910a7409b8834f0239091010d56938e08dd68fdb3902f71e1e4f13b89ca",
    "hero_engine/phase6_av_static_sources.py": "a27d5260050d3b23e521c36c5b4ff7dae53ad0a3ff49ea16700fb0fec97b8deb",
    "output/qa/phase6/diagnostics/two-column-compact-v1/register_compact_rights.py": "386e09cb92ca2344fbd16ed963b19864bfd5ab70136d502d21d7c258e6c518f9",
}
FIXED_IMPLEMENTATIONS = {
    **prior.FIXED_IMPLEMENTATIONS,
    "hero_engine/phase6_av_question_case_amendment.py": "2da7b523f2a3ad6b8c70727791649177c77aa4f2dd4434393d98bf62103b1509",
    "schemas/phase6_av_question_case_amendment.schema.json": "2fc8f9aefdcd8d30ddb6e6e0b90919e3199268c67931b791cfd6497dad8f8004",
    "tests/test_phase6_av_question_case_amendment.py": "9915fc1af1716eddd7815b343eb22e4866995902d75d940236b512689a1b8578",
    **STAGING_CODE,
}
EXPECTED_CHANGES = (
    ("visual-u004-s00", 0, "PRESSURE IS NOT THE VERDICT", "Pressure is not the verdict"),
    ("visual-u008-s00", 0, "EVENT", "Event"),
    ("visual-u008-s01", 0, "INTERPRETATION", "Interpretation"),
    ("visual-u009-s00", 0, "UNTESTED STORY", "Untested story"),
    ("visual-u009-s01", 0, "UNTESTED STORY", "Untested story"),
    ("visual-u026-s00", 0, "UNTESTED MEANING", "Untested meaning"),
    ("visual-u026-s01", 0, "CHOOSE THE RESPONSE", "Choose the response"),
    ("visual-u031-s00", 0, "PRESSURE", "Pressure"),
    ("visual-u032-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
    ("visual-u033-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
    ("visual-u035-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
    ("visual-u036-s00", 0, "ACTION", "Action"),
    ("visual-u036-s00", 1, "OBSERVED RESULT", "Observed result"),
    ("visual-u037-s00", 0, "ACTION", "Action"),
    ("visual-u037-s00", 1, "OBSERVED RESULT", "Observed result"),
    ("visual-u039-s00", 0, "WISDOM DOES NOT HIDE DANGER", "Wisdom does not hide danger"),
    ("visual-u041-s00", 0, "GET APPROPRIATE SUPPORT", "Get appropriate support"),
    ("visual-u042-s00", 0, "POSSIBLE RESPONSES", "Possible responses"),
    ("visual-u043-s00", 0, "PRESSURE DOESN'T NAME YOU", "Pressure doesn't name you"),
    ("visual-u046-s00", 0, "EVENT", "Event"),
    ("visual-u046-s00", 1, "FEAR'S INTERPRETATION", "Fear's interpretation"),
    ("visual-u047-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
    ("visual-u048-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
    ("visual-u049-s00", 0, "NAME / TEST / CHOOSE", "Name / Test / Choose"),
)
DECISION_REFERENCE_SCOPE = "HISTORICAL_V2_V3_V5_USE_EXPLICIT_BODY_CASE_AMENDMENT_FOR_V6"
REPLAY_SCOPE = "EXTERNAL_PINNED_BODY_CASE_DOCUMENT_RECOMPOSITION_NO_MEDIA_QA"
AUTHORITY = dict.fromkeys(("timing", "source", "quality", "render", "admission", "publication"), False)
LIMIT = 1024**2


def _same(left, right, message):
    source._same(left, right, message)


def _raw_binding(bound):
    return {"path": bound["path"], "sha256": bound["sha256"][7:]}


def _index(rows):
    if type(rows) is not list or len(rows) != 51:
        raise ValueError("exact 51 visual units required")
    indexed, fragments = {}, []
    for ordinal, row in enumerate(rows, 1):
        _same(row["unit_id"], f"narration-unit-{ordinal:03d}", "visual unit order differs")
        fragments.extend(row["fragment_ids"])
        for index, state in enumerate(row["states"]):
            sid = state["state_id"]
            if sid in indexed or sid != f"visual-u{ordinal:03d}-s{index:02d}":
                raise ValueError("duplicate or unordered visual state")
            indexed[sid] = (row, state)
    _same(fragments, [f"take-{i:03d}" for i in range(1, 91)], "90 literal fragments required")
    if len(indexed) != 100:
        raise ValueError("100 literal visual states required")
    return indexed


def _apply_case(base, projection, amendment):
    """Apply the independent closed map; preserve every other field verbatim."""
    _same([base["source_binding"], base["adapter_version"], base["authority"]],
          [prior.PROJECTION_BINDING, prior.VERSION, AUTHORITY], "exact prior V5 inspection required")
    old = _index(base["rows"])
    effective = copy.deepcopy(base["rows"])
    new = _index(effective)
    preserved = amendment["preserved"]
    protected = preserved["bound_state_ids"]
    if len(protected) != 29 or len(set(protected)) != 29:
        raise ValueError("29 distinct protected literal uses required")
    hooks = [f"visual-u{i:03d}-s00" for i in (1, 2, 3)]
    _same(preserved["hook_state_ids"], hooks, "protected hook population differs")
    expected = []
    for sid, index, before, after in EXPECTED_CHANGES:
        row, state = old[sid]
        if sid in protected or sid in hooks:
            raise ValueError("case map touches protected use or hook")
        _same(state["visual_content"]["literal_copy"][index], before, "before-copy differs")
        if len(before) != len(after) or any(a != b and not (a.isascii() and b.isascii() and a.isalpha() and b.isalpha() and a.lower() == b.lower()) for a, b in zip(before, after, strict=True)):
            raise ValueError("only exact ASCII case may change")
        expected.append(dict(state_id=sid, unit_id=row["unit_id"], literal_copy_index=index,
            before=before, after=after, preserved_entry=copy.deepcopy(state["entry"])))
        new[sid][1]["visual_content"]["literal_copy"][index] = after
    _same(amendment["changes"], expected, "closed 24-position case delta differs")
    selected = sorted({row[0] for row in EXPECTED_CHANGES})
    unchanged = [state for row in base["rows"] for state in row["states"] if state["state_id"] not in selected]
    _same([amendment["changed_state_count"], amendment["changed_string_count"], amendment["unchanged_state_count"],
           amendment["selected_state_ids"], len(selected), len(expected), len(unchanged), amendment["unchanged_states_sha256"]],
          [21, 24, 79, selected, 21, 24, 79, source._sha(source._canonical(unchanged))], "case population or unchanged hash differs")
    _same(projection["effective_rows"], effective, "V6 changes outside the case-only positions")
    _same(preserved["protected_states_sha256"], source._sha(source._canonical([old[sid][1] for sid in sorted(set(protected) | set(hooks))])), "protected states hash differs")
    seen, lexical = set(), []
    for row in effective:
        lexical.extend(_state_entries(row, seen))
    _same(lexical, base["visual_lexical_ranges"], "case amendment changes lexical population")
    _same(preserved["temporal_target_unit_ids"], base["temporal_target_unit_ids"], "case amendment changes 26-target union")
    if len(base["temporal_target_unit_ids"]) != 26:
        raise ValueError("exact temporal union required")
    return effective


def _stage_replay(root, read):
    """Thirteen historical reads reconstructed; dependency lists select nothing."""
    historical = source._Reader(root)
    for path, digest in STAGING_CODE.items():
        raw = read({"path": path, "sha256": "sha256:" + digest})
        if historical.read(path, digest, limit=LIMIT) != raw:
            raise ValueError("staging code changed")
    spec = importlib.util.spec_from_file_location("body_case_consumer_pinned_compiler", root / COMPILER)
    compiler = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(compiler)
    historical.read(COMPILER, STAGING_CODE[COMPILER], limit=LIMIT)
    if compiler.source is not source:
        raise ValueError("case compiler imports another primitive")
    _same(compiler.SOURCE_BINDINGS, SOURCE_BINDINGS, "four document preconditions differ")
    buffers = {}
    for role, binding in SOURCE_BINDINGS.items():
        raw = read({"path": binding["path"], "sha256": "sha256:" + binding["sha256"]})
        if historical.read(binding["path"], binding["sha256"], limit=LIMIT) != raw:
            raise ValueError("historical context changed")
        buffers[role] = raw
    compiled = compiler.compile_case(*(buffers[role] for role in ("v5", "bible", "a11", "uses")), source_bindings=copy.deepcopy(SOURCE_BINDINGS))
    _same(compiler.output_paths(compiled), {"amendment": AMENDMENT_BINDING["path"], "projection": PROJECTION_BINDING["path"]}, "compiled output namespace differs")
    parsed = {}
    for role, bound in (("claim", CLAIM_BINDING), ("amendment", AMENDMENT_BINDING), ("projection", PROJECTION_BINDING)):
        raw = read(bound)
        if historical.read(bound["path"], bound["sha256"][7:], limit=LIMIT) != raw:
            raise ValueError("staged artifact changed")
        parsed[role] = _json(raw)
        if source._canonical(parsed[role]) != raw:
            raise ValueError("canonical staged document required")
    for role in ("amendment", "projection"):
        _same(parsed[role], compiled[role], "staged body/projection does not recompose")
    raw_receipt = read(STAGING_BINDING)
    receipt = _json(raw_receipt)
    if source._canonical(receipt) != raw_receipt:
        raise ValueError("canonical staging receipt required")
    _validate_stage_documents(root, compiler, historical, compiled, parsed["claim"], receipt)
    _inventory(root)
    for item in tuple(historical.bindings.values()):
        if len(historical.read_path(Path(item["path"]), item["sha256"], limit=LIMIT)) != item["size_bytes"]:
            raise ValueError("staging replay dependency size drift")
    return compiled, receipt


def _validate_stage_documents(root, compiler, historical, compiled, claim, receipt):
    authority = compiled["amendment"]["authority"]
    for key in ("started_at", "staged_at"):
        if type(receipt.get(key)) is not str:
            raise ValueError("staging UTC timestamp required")
    started, staged = (datetime.fromisoformat(receipt[key].replace("Z", "+00:00")) for key in ("started_at", "staged_at"))
    elapsed = receipt.get("staging_duration_seconds")
    if (any(t.utcoffset() is None or t.utcoffset().total_seconds() != 0 for t in (started, staged)) or
            not started <= staged <= datetime.now(timezone.utc) or type(elapsed) not in (int, float) or not math.isfinite(elapsed) or elapsed < 0):
        raise ValueError("finite ordered nonfuture UTC staging history required")
    common = dict(version="phase6-body-case-proposal-staging-v1", amendment_id=IDENTIFIER,
        artifacts={"amendment": _raw_binding(AMENDMENT_BINDING), "projection": _raw_binding(PROJECTION_BINDING)},
        changed_state_count=21, changed_string_count=24, unchanged_state_count=79, qa_status="NOT_EVALUATED",
        media_generation_calls=0, image_decode_calls=0, ocr_inference_calls=0, qa_replay_calls=0, pixel_measurement_calls=0,
        active_plan_changed=False, authority=authority, technical_cost_brl=0)
    _same(claim, dict(version=common["version"], status="CLAIMED_NOT_STAGED", amendment_id=IDENTIFIER,
        started_at=receipt["started_at"], source_bindings=SOURCE_BINDINGS, implementation_pins=STAGING_CODE,
        authority=authority, technical_cost_brl=0), "exclusive claim does not recompose")
    dependencies = sorted(historical.bindings.values(), key=lambda item: item["path"])
    if len(dependencies) != 13:
        raise ValueError("thirteen actual historical staging dependencies required")
    expected = dict(kind="PHASE6_BODY_CASE_PROPOSAL_STAGING", status="STAGED_NOT_ACCEPTED_BY_A11", **common,
        source_bindings=SOURCE_BINDINGS, implementation_pins=STAGING_CODE, claim_binding=_raw_binding(CLAIM_BINDING),
        started_at=receipt["started_at"], staged_at=receipt["staged_at"], staging_duration_seconds=elapsed,
        evidence_scope="PINNED_DOCUMENTS_ONLY_NO_MEDIA_QA_REPLAY",
        dependency_scope="FOUR_DOCUMENTS_AND_STAGING_CODE_ONLY_BEFORE_RECEIPT_WRITE", dependency_bindings=dependencies)
    _same(receipt, expected, "exclusive staging receipt does not recompose from actual reads")


def _inventory(root):
    directory = source._resident(root / DIRECTORY)
    names = {Path(bound["path"]).name for bound in (PROJECTION_BINDING, AMENDMENT_BINDING, STAGING_BINDING, CLAIM_BINDING)}
    if {path.name for path in directory.iterdir()} != names:
        raise ValueError("body-case staging inventory differs")
    for path in directory.iterdir():
        source._resident(path)
        if not path.is_file() or path.stat().st_nlink != 1:
            raise ValueError("staging requires resident regular single-link files")


def read_amended_visual_intent(reader, binding, units, caption_proof, *, amendment_binding, staging_binding):
    for actual, expected in ((binding, PROJECTION_BINDING), (amendment_binding, AMENDMENT_BINDING), (staging_binding, STAGING_BINDING)):
        _binding(actual)
        _same(actual, expected, "only exact externally pinned V6/body/staging bindings are supported")
    root = Path(__file__).absolute().parents[1]
    if source._resident(reader.root) != source._resident(root):
        raise ValueError("body-case reader requires canonical resident root")
    guard, implementation = source._Reader(root), []
    for path, digest in FIXED_IMPLEMENTATIONS.items():
        raw = guard.read(path, digest)
        implementation.append(dict(path=path, sha256="sha256:" + digest, size_bytes=len(raw)))
    for path in (MODULE, TEST):
        raw = source._resident(root / path).read_bytes()
        digest = source._sha(raw)
        guard.read(path, digest)
        implementation.append(dict(path=path, sha256="sha256:" + digest, size_bytes=len(raw)))
    dependencies = {}
    def read(bound):
        _binding(bound)
        _resident(reader.root, bound["path"])
        raw = reader.read(bound["path"], bound["sha256"])
        if bytes_sha(raw) != bound["sha256"]:
            raise ValueError("body-case document hash differs")
        item = {**copy.deepcopy(bound), "size_bytes": len(raw)}
        _same(dependencies.setdefault(bound["path"], item), item, "body-case document identity drift")
        return raw
    # V5 independently reopens caption/PCM metadata, V2/V3 and its old QA replay.
    base = prior.read_amended_visual_intent(reader, prior.PROJECTION_BINDING, units, caption_proof)
    for item in base["implementation_dependencies"]:
        _same(item, next(row for row in implementation if row["path"] == item["path"]), "prior implementation drift")
    for item in base["dependency_bindings"]:
        read({key: item[key] for key in ("path", "sha256")})
    compiled, receipt = _stage_replay(root, read)
    effective = _apply_case(base, compiled["projection"], compiled["amendment"])
    result = {**copy.deepcopy(base), "adapter_version": VERSION,
        "status": "LITERAL_BODY_CASE_AMENDMENT_IDENTIFIED_SOURCES_AND_TIMING_PENDING",
        "source_binding": copy.deepcopy(binding), "rows": effective,
        "prior_case_inspection": copy.deepcopy(base), "prior_case_inspection_sha256": canonical_sha(base),
        "body_case_prior_projection_binding": copy.deepcopy(prior.PROJECTION_BINDING),
        "body_case_amendment_binding": copy.deepcopy(AMENDMENT_BINDING),
        "body_case_staging_binding": copy.deepcopy(STAGING_BINDING), "body_case_claim_binding": copy.deepcopy(CLAIM_BINDING),
        "preserved_body_case_constraints": copy.deepcopy(compiled["amendment"]["preserved"]),
        "description_precedence": copy.deepcopy(compiled["projection"]["description_precedence"]),
        "effective_rows_sha256": canonical_sha(effective), "decision_reference_scope": DECISION_REFERENCE_SCOPE,
        "changed_state_count": 21, "changed_string_count": 24, "unmodified_state_count": 79,
        "static_proof_scope": REPLAY_SCOPE, "dependency_bindings": sorted(dependencies.values(), key=lambda item: item["path"]),
        "implementation_dependencies": implementation,
        "limitations": [*base["limitations"],
            "V2, V3 and V5 inspections remain historical; only this closed 24-position body-case amendment supplies V6 copy.",
            "Twenty-one states change case; 79 states, 29 existing asset uses, hooks, narration, entries and the 26-target union remain unchanged.",
            "V6 staged labels remain historical bytes; this reader does not install A, admit sources, run media QA or create lexical onset evidence.",
            "A11 clock, silence, source/use inspections are pinned preservation context, not a live temporal or productive proof."]}
    recheck_body_case_replay(root, result)
    for item in implementation:
        guard.read(item["path"], item["sha256"][7:])
    return result


def recheck_body_case_replay(root, proof):
    """Recheck a same-call result only; not an external/serialized verifier."""
    if type(proof) is not dict or proof.get("adapter_version") != VERSION:
        raise ValueError("same-call body-case inspection required")
    for key, expected in (("source_binding", PROJECTION_BINDING), ("body_case_amendment_binding", AMENDMENT_BINDING),
            ("body_case_staging_binding", STAGING_BINDING), ("body_case_claim_binding", CLAIM_BINDING),
            ("static_proof_scope", REPLAY_SCOPE), ("authority", AUTHORITY)):
        _same(proof.get(key), expected, "body-case recheck scope differs")
    _same([proof.get(key) for key in ("source_ready", "global_schedule_created", "calibrated_timing_available", "technical_cost_brl")],
          [False, False, False, 0], "body-case recheck cannot confer authority")
    _same(proof.get("prior_case_inspection_sha256"), canonical_sha(proof["prior_case_inspection"]), "prior V5 inspection identity differs")
    _same(proof.get("question_replay_dependencies"), proof["prior_case_inspection"]["question_replay_dependencies"], "historical question replay sink differs")
    prior.recheck_question_replay(root, proof["prior_case_inspection"])
    guard = source._Reader(root)
    for item in proof["implementation_dependencies"]:
        if len(guard.read(item["path"], item["sha256"][7:])) != item["size_bytes"]:
            raise ValueError("body-case implementation dependency size changed")
    for item in proof["dependency_bindings"]:
        _binding({key: item[key] for key in ("path", "sha256")})
        _resident(root, item["path"])
        if len(guard.read(item["path"], item["sha256"][7:])) != item["size_bytes"]:
            raise ValueError("body-case document dependency size changed")
    _inventory(root)
