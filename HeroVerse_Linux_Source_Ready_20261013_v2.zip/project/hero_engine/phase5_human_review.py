from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import shutil
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
CREATIVE_ROOT = Path("output/production/phase5/pilot-001/creative-v3")
QUALIFICATION = CREATIVE_ROOT / "standard-qualification/standard_qualification_report.json"
AUTOMATIC_QA = CREATIVE_ROOT / "qa/creative_quality_gate_report.json"
PUBLICATION_PACKAGE = CREATIVE_ROOT / "publication_package.json"
THUMBNAILS = CREATIVE_ROOT / "thumbnail/thumbnail_set_manifest.json"
HUMAN_REVIEW_DIR = CREATIVE_ROOT / "human-review"
PACK_PATH = Path("config/format_packs/fp-broll-cinematic-narration-v1.json")
REGISTRY_PATH = Path("config/visual_style_registry.json")
OAUTH_READINESS = Path("output/integrations/youtube/heroverse/operational-readiness.json")
CHANNEL_READINESS = Path("output/channel-readiness/heroverse/latest.json")


EXPECTED_WINDOWS = [
    ("W00_00_01", 0, 1_000, "contradiction visual and voice are immediately clear"),
    ("W01_01_03", 1_000, 3_000, "consequence is understandable without outside context"),
    ("W02_03_08", 3_000, 8_000, "TRUTH / RESPONSIBILITY / TODAY creates a real reason to continue"),
    ("W03_08_30", 8_000, 30_000, "first payoff delivers the title through concrete action"),
    ("W04_28_900_74_400", 28_900, 74_400, "discernment and biblical basis are coherent and non-deceptive"),
    ("W05_74_400_140_400", 74_400, 140_400, "three tests are distinct, memorable and visually evidenced"),
    ("W06_140_400_183_800", 140_400, 183_800, "boundaries are safe, responsible and make no guaranteed promise"),
    ("W07_183_800_217_400", 183_800, 217_400, "the 24-hour practice is executable and non-repetitive"),
    ("W08_217_400_238_700", 217_400, 238_700, "final payoff is clear, legible and free of unintended freeze"),
]

EXPECTED_GATES = [
    ("HOOK", "0–8 s delivers consequence, mechanism and a reason to stay"),
    ("NARRATIVE", "progression contains no jump, contradiction or undelivered promise"),
    ("SEMANTIC_COHERENCE", "each visual and effect transmits the current statement"),
    ("STYLE", "palette, light, typography, rhythm and grammar form one piece"),
    ("CONTINUITY", "cuts, scale, space, light and direction change only with purpose"),
    ("MOVEMENT", "no flicker, pulsing, ghosting, deformation or impossible physics"),
    ("LEGIBILITY", "text and captions are readable on a small screen and inside safe areas"),
    ("AUDIO", "voice, pronunciation, emotion, pauses, music, ducking and effects work together"),
    ("CAPTIONS", "English, punctuation, synchronization and all 59 cues are correct"),
    ("PUBLICITY", "people, properties and situations are usable under the recorded evidence"),
    ("CHANNEL_IDENTITY", "the result is recognizably HeroVerse and does not imitate another identity"),
    ("THUMBNAIL", "one of A/B/C represents the promise without sensationalism"),
]

ATTESTATION = (
    "I reviewed the exact frozen STANDARD artifact in full, sequentially, at normal speed with audio, "
    "checked captions and small-screen legibility, evaluated all nine windows and twelve human gates, "
    "and recorded defects instead of approving around them."
)

LIMITATION_CONTRACT = {
    "allowed_scope": [
        "HeroVerse channel UCuMF6pJQkyMzaVoAxFL86yA only",
        "English Christian-motivation long-form only",
        "clip-based documentary-cinematic narration using pipeline-clips-longform-v1@1.0.0",
        "STANDARD profile at 1920x1080/30 fps within 207750-286250 ms",
        "external production cost USD 0 unless a later envelope explicitly changes it",
        "faceless construction without a recurring speaking character",
    ],
    "forbidden_scope": [
        "other channels or tenants",
        "Shorts or vertical delivery",
        "news, current-affairs or factual documentary claims without a separate provenance pack",
        "recurring-character, lip-sync, 3D, anime or unrelated macrofamily production",
        "PREMIUM or CINEMATIC claims",
        "paid tools, Ads or spend without a separately approved envelope",
        "publication when channel, OAuth, rights or any critical video gate is not PASS",
    ],
    "expiry_or_review": (
        "Reassess after three published HeroVerse long-form videos, any critical regression, a pipeline/tool "
        "version change, a rights-policy change, or 90 days after transition, whichever occurs first."
    ),
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc)


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _relative(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.05 * (2 ** attempt))
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _validate(root: Path, schema_name: str, value: Any) -> None:
    schema = _read_json(root / "schemas" / schema_name)
    Draft202012Validator(schema).validate(value)


def build_review_draft(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, Any]:
    root = root.resolve()
    qualification = _read_json(root / QUALIFICATION)
    candidate = qualification["candidate"]
    candidate_path = _resolve(root, candidate["path"])
    if not candidate_path.is_file():
        raise FileNotFoundError(candidate_path)
    observed_hash = _file_hash(candidate_path)
    expected_hash = candidate["content_hash"].removeprefix("sha256:")
    if observed_hash != expected_hash:
        raise ValueError("Frozen STANDARD candidate hash no longer matches the qualification report")
    timestamp = created_at or _utc_now()
    draft = {
        "schema_version": "1.0.0",
        "submission_id": f"human-review-{expected_hash[:20]}",
        "submission_status": "DRAFT",
        "artifact": {
            "qualification_id": qualification["qualification_id"],
            "path": _relative(root, candidate_path),
            "sha256": expected_hash,
            "size_bytes": candidate["size_bytes"],
            "duration_ms": candidate["duration_ms"],
        },
        "reviewer": {
            "reviewer_id": None,
            "reviewer_name": None,
            "reviewer_role": None,
            "independent_from_generator": False,
            "conflict_disclosure": None,
            "reviewed_at": None,
        },
        "review_protocol": {
            "full_duration_reviewed": False,
            "sequential_review": False,
            "playback_speed": None,
            "audio_monitoring": False,
            "caption_track_checked": False,
            "small_screen_legibility_checked": False,
            "thumbnail_review_blinded": False,
        },
        "windows": [
            {"window_id": window_id, "start_ms": start, "end_ms": end, "criterion": criterion, "status": "PENDING", "evidence_note": None, "defects": []}
            for window_id, start, end, criterion in EXPECTED_WINDOWS
        ],
        "human_gates": [
            {"gate": gate, "criterion": criterion, "status": "PENDING", "evidence_note": None, "defects": []}
            for gate, criterion in EXPECTED_GATES
        ],
        "thumbnail_selection": None,
        "overall_verdict": "PENDING",
        "attestation": {"attested": False, "statement": ATTESTATION},
        "created_at": timestamp,
        "submitted_at": None,
    }
    _validate(root, "phase5_human_review_submission.schema.json", draft)
    return draft


def prepare_review(root: Path = ROOT, *, created_at: str | None = None) -> dict[str, str]:
    root = root.resolve()
    draft_path = root / HUMAN_REVIEW_DIR / "review_submission.draft.json"
    final_path = root / HUMAN_REVIEW_DIR / "review_submission.json"
    if final_path.exists():
        raise FileExistsError(f"A final submission already exists and was not overwritten: {final_path}")
    draft = build_review_draft(root, created_at=created_at)
    _write_json_atomic(draft_path, draft)
    return {"status": "PREPARED", "draft": _relative(root, draft_path), "expected_final": _relative(root, final_path)}


def _status_counts(items: list[dict[str, Any]]) -> dict[str, int]:
    counts = Counter(item["status"] for item in items)
    return {status: counts.get(status, 0) for status in ("PENDING", "PASS", "FAIL", "NEEDS_REVIEW")}


def evaluate_submission(
    submission: dict[str, Any], root: Path = ROOT, *, created_at: str | None = None
) -> dict[str, Any]:
    root = root.resolve()
    _validate(root, "phase5_human_review_submission.schema.json", submission)
    qualification = _read_json(root / QUALIFICATION)
    automatic_qa = _read_json(root / AUTOMATIC_QA)
    package = _read_json(root / PUBLICATION_PACKAGE)
    thumbnails = _read_json(root / THUMBNAILS)
    pack_path = root / PACK_PATH
    pack = _read_json(pack_path)
    candidate = qualification["candidate"]
    candidate_path = _resolve(root, candidate["path"])
    candidate_hash = _file_hash(candidate_path) if candidate_path.is_file() else ""
    expected_hash = candidate["content_hash"].removeprefix("sha256:")

    artifact_checks = {
        "qualification_id_match": submission["artifact"]["qualification_id"] == qualification["qualification_id"],
        "path_match": _resolve(root, submission["artifact"]["path"]).resolve() == candidate_path.resolve(),
        "content_hash_match": submission["artifact"]["sha256"] == expected_hash == candidate_hash,
        "size_match": submission["artifact"]["size_bytes"] == candidate["size_bytes"] == candidate_path.stat().st_size if candidate_path.is_file() else False,
        "duration_match": submission["artifact"]["duration_ms"] == candidate["duration_ms"],
        "package_hash_match": package["video"]["sha256"] == expected_hash,
        "automatic_standard_pass": (
            qualification["automatic_profile_status"] == "PASS"
            and qualification["replay"]["equivalence_pass"] is True
            and all(check["status"] == "PASS" for check in qualification["technical_checks"])
            and not any(gate["status"] == "FAIL" for gate in automatic_qa["gates"])
        ),
    }
    artifact_checks["all_pass"] = all(artifact_checks.values())

    expected_window_shape = {(window_id, start, end) for window_id, start, end, _ in EXPECTED_WINDOWS}
    observed_window_shape = {(item["window_id"], item["start_ms"], item["end_ms"]) for item in submission["windows"]}
    expected_gate_names = {gate for gate, _ in EXPECTED_GATES}
    observed_gate_names = {item["gate"] for item in submission["human_gates"]}
    role = submission["reviewer"]["reviewer_role"]
    reviewer_id = submission["reviewer"]["reviewer_id"]
    reviewer_name = submission["reviewer"]["reviewer_name"]
    conflict_disclosure = submission["reviewer"]["conflict_disclosure"]
    reviewed_at = _parse_time(submission["reviewer"]["reviewed_at"])
    submitted_at = _parse_time(submission["submitted_at"])
    qualification_at = _parse_time(qualification.get("created_at"))
    forbidden_reviewer_tokens = {"codex", "gpt", "automatic", "generator", "system"}
    protocol = submission["review_protocol"]
    protocol_checks = {
        "exact_windows": observed_window_shape == expected_window_shape and len(submission["windows"]) == len(expected_window_shape),
        "exact_human_gates": observed_gate_names == expected_gate_names and len(submission["human_gates"]) == len(expected_gate_names),
        "full_duration_reviewed": protocol["full_duration_reviewed"] is True,
        "normal_speed": protocol["playback_speed"] == 1.0 and protocol["sequential_review"] is True,
        "audio_monitoring": protocol["audio_monitoring"] is True,
        "captions_checked": protocol["caption_track_checked"] is True,
        "small_screen_checked": protocol["small_screen_legibility_checked"] is True,
        "thumbnail_blinded": protocol["thumbnail_review_blinded"] is True,
        "independent_human": (
            submission["reviewer"]["independent_from_generator"] is True
            and role in {"OWNER_HUMAN", "DESIGNATED_INDEPENDENT_HUMAN"}
            and isinstance(reviewer_id, str)
            and bool(reviewer_id.strip())
            and not any(token in reviewer_id.lower() for token in forbidden_reviewer_tokens)
        ),
        "reviewer_identity_complete": (
            isinstance(reviewer_name, str) and bool(reviewer_name.strip())
            and isinstance(conflict_disclosure, str) and bool(conflict_disclosure.strip())
        ),
        "review_timestamps_valid": (
            reviewed_at is not None
            and submitted_at is not None
            and submitted_at >= reviewed_at
            and (qualification_at is None or reviewed_at >= qualification_at)
        ),
        "evidence_notes_complete": all(
            isinstance(item["evidence_note"], str) and bool(item["evidence_note"].strip())
            for item in submission["windows"] + submission["human_gates"]
        ),
        "attested": submission["attestation"]["attested"] is True and submission["attestation"]["statement"] == ATTESTATION,
    }
    protocol_checks["all_pass"] = all(protocol_checks.values())

    window_counts = _status_counts(submission["windows"])
    gate_counts = _status_counts(submission["human_gates"])
    defect_count = sum(len(item["defects"]) for item in submission["windows"] + submission["human_gates"])
    selected = submission["thumbnail_selection"]
    thumbnail_ids = {item["candidate_id"] for item in thumbnails["candidates"] if item["automated_status"] == "PASS"}
    all_human_pass = window_counts["PASS"] == 9 and gate_counts["PASS"] == 12
    pass_consistent = (
        submission["submission_status"] == "FINAL"
        and submission["overall_verdict"] == "PASS"
        and all_human_pass
        and defect_count == 0
        and selected in thumbnail_ids
        and artifact_checks["all_pass"]
        and protocol_checks["all_pass"]
    )

    if submission["submission_status"] == "DRAFT":
        decision = "PENDING_HUMAN_INPUT"
    elif submission["overall_verdict"] == "FAIL" or window_counts["FAIL"] or gate_counts["FAIL"]:
        decision = "REJECTED_BY_HUMAN_REVIEW"
    elif pass_consistent:
        decision = "READY_FOR_LIMITED_PROMOTION"
    else:
        decision = "NEEDS_REVIEW"

    blockers: list[str] = []
    if decision == "PENDING_HUMAN_INPUT":
        blockers.append("FINAL_INDEPENDENT_HUMAN_REVIEW_SUBMISSION_MISSING")
    elif decision == "REJECTED_BY_HUMAN_REVIEW":
        blockers.append("HUMAN_REVIEW_REJECTED_THE_CANDIDATE")
    elif decision == "NEEDS_REVIEW":
        blockers.append("HUMAN_REVIEW_IS_INCOMPLETE_OR_INTERNALLY_INCONSISTENT")
    if pack["capability_status"] not in {"PRODUCTION_READY", "LIMITED"}:
        blockers.append("FORMAT_PACK_NOT_PRODUCTION_CAPABLE")
    oauth = _read_json(root / OAUTH_READINESS)
    if not oauth["continuous_operation_ready"]:
        blockers.append("OAUTH_NOT_DURABLE_FOR_CONTINUOUS_OPERATION")
    if not blockers:
        blockers.append("CONSOLIDATED_PHASE5_PUBLICATION_RECEIPT_NOT_YET_EVALUATED")

    evaluation = {
        "schema_version": "1.0.0",
        "evaluation_id": "phase5-human-review-eval-" + _canonical_hash({"submission": submission, "pack_sha": _file_hash(pack_path)})[:20],
        "submission_id": submission["submission_id"],
        "submission_status": submission["submission_status"],
        "decision": decision,
        "artifact_verification": artifact_checks,
        "protocol_verification": protocol_checks,
        "review_summary": {
            "window_status_counts": window_counts,
            "gate_status_counts": gate_counts,
            "thumbnail_selection": selected,
            "overall_verdict": submission["overall_verdict"],
            "defect_count": defect_count,
        },
        "format_pack_transition": {
            "format_pack_id": pack["format_pack_id"],
            "format_pack_version": pack["version"],
            "source_status": pack["capability_status"],
            "target_status": "LIMITED" if decision == "READY_FOR_LIMITED_PROMOTION" else None,
            "eligible": decision == "READY_FOR_LIMITED_PROMOTION",
            "applied": pack["capability_status"] == "LIMITED",
            "scope": copy.deepcopy(LIMITATION_CONTRACT["allowed_scope"]) if decision == "READY_FOR_LIMITED_PROMOTION" else [],
            "source_sha256": _file_hash(pack_path),
            "transition_receipt": None,
        },
        "publication_guard": {"upload_permitted": False, "phase6_permitted": False, "blockers": blockers},
        "evidence_refs": [
            _relative(root, root / QUALIFICATION),
            _relative(root, candidate_path),
            _relative(root, root / AUTOMATIC_QA),
            _relative(root, root / PUBLICATION_PACKAGE),
            _relative(root, root / THUMBNAILS),
            _relative(root, pack_path),
            _relative(root, root / OAUTH_READINESS),
        ],
        "created_at": created_at or _utc_now(),
    }
    _validate(root, "phase5_human_review_evaluation.schema.json", evaluation)
    return evaluation


def apply_limited_transition(
    submission: dict[str, Any], root: Path = ROOT, *, created_at: str | None = None
) -> dict[str, Any]:
    root = root.resolve()
    timestamp = created_at or _utc_now()
    evaluation = evaluate_submission(submission, root, created_at=timestamp)
    if evaluation["decision"] != "READY_FOR_LIMITED_PROMOTION":
        raise PermissionError(f"Human review is not eligible for transition: {evaluation['decision']}")
    pack_path = root / PACK_PATH
    registry_path = root / REGISTRY_PATH
    review_path = root / HUMAN_REVIEW_DIR / "review_submission.json"
    if not review_path.is_file():
        raise PermissionError("The canonical final review_submission.json does not exist")
    canonical_submission = _read_json(review_path)
    if canonical_submission != submission:
        raise PermissionError("The supplied review differs from the canonical final review_submission.json")
    review_hash = _file_hash(review_path)
    before_pack_bytes = pack_path.read_bytes()
    before_registry_bytes = registry_path.read_bytes()
    before_hash = hashlib.sha256(before_pack_bytes).hexdigest()
    if before_hash != evaluation["format_pack_transition"]["source_sha256"]:
        raise RuntimeError("FormatPack changed between evaluation and transition")
    pack = json.loads(before_pack_bytes.decode("utf-8"))
    registry = json.loads(before_registry_bytes.decode("utf-8"))
    if pack["capability_status"] != "PROTOTYPED" or pack["production_allowed"] is not False:
        raise PermissionError("Only the current PROTOTYPED/non-production pack can take this transition")

    archive_dir = root / "config/format_packs/history"
    archive_path = archive_dir / f"{pack['format_pack_id']}@{pack['version']}.PROTOTYPED.{before_hash[:12]}.json"
    archive_dir.mkdir(parents=True, exist_ok=True)
    if archive_path.exists() and _file_hash(archive_path) != before_hash:
        raise RuntimeError("Existing rollback archive has a different hash")

    promoted = copy.deepcopy(pack)
    promoted["capability_status"] = "LIMITED"
    promoted["production_allowed"] = True
    promoted["limitation_contract"] = copy.deepcopy(LIMITATION_CONTRACT)
    if submission["submission_id"] not in promoted["evidence"]["human_review_ids"]:
        promoted["evidence"]["human_review_ids"].append(submission["submission_id"])
    promoted["readiness"]["missing_requirements"] = [
        item for item in promoted["readiness"]["missing_requirements"]
        if not any(term in item.lower() for term in ("human", "pronunciation", "publicity", "standard qualification"))
    ]
    promoted["readiness"]["last_assessed_at"] = timestamp
    promoted["readiness"]["assessed_by"] = "phase5-human-review-closure@1.0.0"
    promoted["learning_history"].append({
        "learning_id": f"capability-review-{submission['submission_id']}",
        "status": "CANDIDATE",
        "pack_version": promoted["version"],
        "pipeline_version": "1.0.0",
        "tool_versions": ["phase5-human-review-closure@1.0.0"],
        "video_id": qualification_video_id(root),
        "evidence_refs": [
            _relative(root, root / HUMAN_REVIEW_DIR / "review_submission.json"),
            _relative(root, root / QUALIFICATION),
        ],
        "result": (
            "Independent human quality evidence supports LIMITED capability only for the explicit HeroVerse "
            "long-form scope. This is not audience-performance learning, cross-channel validation or a viral claim."
        ),
        "created_at": timestamp,
    })
    _validate(root, "format_pack.schema.json", promoted)

    overrides = [item for item in registry["format_pack_overrides"] if item["format_pack_id"] == pack["format_pack_id"]]
    if len(overrides) != 1:
        raise RuntimeError("Registry must contain exactly one override for this FormatPack")
    overrides[0]["format_pack_version"] = promoted["version"]
    overrides[0]["capability_status"] = "LIMITED"
    if registry["capability_counts"].get("PROTOTYPED") != 1 or registry["capability_counts"].get("LIMITED") != 0:
        raise RuntimeError("Registry capability counts do not match the expected pre-transition state")
    registry["capability_counts"]["PROTOTYPED"] = 0
    registry["capability_counts"]["LIMITED"] = 1
    if sum(registry["capability_counts"].values()) != registry["total_formats"]:
        raise RuntimeError("Registry capability counts no longer reconcile")

    try:
        if not archive_path.exists():
            archive_path.write_bytes(before_pack_bytes)
        _write_json_atomic(pack_path, promoted)
        _write_json_atomic(registry_path, registry)
        after_hash = _file_hash(pack_path)
        registry_hash = _file_hash(registry_path)
        receipt = {
            "schema_version": "1.0.0",
            "transition_id": "format-pack-transition-" + _canonical_hash({"review": submission["submission_id"], "before": before_hash, "after": after_hash})[:20],
            "format_pack_id": promoted["format_pack_id"],
            "format_pack_version": promoted["version"],
            "from_status": "PROTOTYPED",
            "to_status": "LIMITED",
            "reason": "Exact STANDARD candidate passed automatic qualification and a complete independent human review; scope remains intentionally limited.",
            "human_review_id": submission["submission_id"],
            "human_review": {"path": _relative(root, review_path), "sha256": review_hash},
            "before": {"path": _relative(root, archive_path), "sha256": before_hash},
            "after": {"path": _relative(root, pack_path), "sha256": after_hash},
            "registry": {"path": _relative(root, registry_path), "sha256": registry_hash},
            "limitation_contract": copy.deepcopy(LIMITATION_CONTRACT),
            "rollback": {
                "archive_path": _relative(root, archive_path),
                "archive_sha256": before_hash,
                "instructions": "Restore the archived bytes only after recording a rollback event; never delete this transition receipt or the failed evidence.",
            },
            "created_at": timestamp,
        }
        _validate(root, "format_pack_transition_receipt.schema.json", receipt)
        receipt_path = root / HUMAN_REVIEW_DIR / "format_pack_transition_receipt.json"
        _write_json_atomic(receipt_path, receipt)
    except Exception:
        pack_path.write_bytes(before_pack_bytes)
        registry_path.write_bytes(before_registry_bytes)
        raise

    evaluation["decision"] = "HUMAN_GATE_PASS_FORMAT_PACK_LIMITED"
    evaluation["format_pack_transition"].update({
        "source_status": "PROTOTYPED",
        "target_status": "LIMITED",
        "eligible": True,
        "applied": True,
        "transition_receipt": _relative(root, receipt_path),
    })
    evaluation["publication_guard"]["blockers"] = [
        blocker for blocker in evaluation["publication_guard"]["blockers"]
        if blocker != "FORMAT_PACK_NOT_PRODUCTION_CAPABLE"
    ]
    if not evaluation["publication_guard"]["blockers"]:
        evaluation["publication_guard"]["blockers"].append("CONSOLIDATED_PHASE5_PUBLICATION_RECEIPT_NOT_YET_EVALUATED")
    _validate(root, "phase5_human_review_evaluation.schema.json", evaluation)
    return evaluation


def qualification_video_id(root: Path = ROOT) -> str:
    return _read_json(root.resolve() / QUALIFICATION)["video_id"]


def evaluate_file(
    submission_path: Path, root: Path = ROOT, *, apply: bool = False, created_at: str | None = None
) -> dict[str, Any]:
    root = root.resolve()
    submission_path = _resolve(root, submission_path)
    submission = _read_json(submission_path)
    if apply:
        expected_final = root / HUMAN_REVIEW_DIR / "review_submission.json"
        if submission_path.resolve() != expected_final.resolve():
            raise PermissionError("A capability transition may only consume the canonical final review_submission.json")
        evaluation = apply_limited_transition(submission, root, created_at=created_at)
    else:
        evaluation = evaluate_submission(submission, root, created_at=created_at)
    output_path = root / HUMAN_REVIEW_DIR / "review_evaluation.json"
    _write_json_atomic(output_path, evaluation)
    return evaluation


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Prepare and evaluate the independent Phase 5 human review")
    parser.add_argument("--root", type=Path, default=ROOT)
    subcommands = parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("prepare", help="Create a hash-pinned DRAFT review form without overwriting a final review")
    evaluate = subcommands.add_parser("evaluate", help="Evaluate a DRAFT or FINAL review fail-closed")
    evaluate.add_argument("--submission", type=Path, required=True)
    evaluate.add_argument("--apply-limited-transition", action="store_true")
    return parser


def main() -> None:
    args = _parser().parse_args()
    if args.command == "prepare":
        result: Any = prepare_review(args.root)
    else:
        result = evaluate_file(args.submission, args.root, apply=args.apply_limited_transition)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
