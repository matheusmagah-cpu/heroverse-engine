"""Single recipe identity shared by cache, media and pre-effect inspection."""

PHASE6_SEGMENT_RENDERER = "phase6-standard-v2"

# Explicit forward identity. Never silently reuse a v2 receipt/cache for these
# different encoder bytes. New compiled plans name the profile explicitly;
# historical plans keep v2. Neither profile grants render authority.
PALETTE_QP1_SEGMENT_RENDERER = "phase6-standard-palette-qp1-v1"


def plan_renderer(plan: dict) -> str:
    """The authenticated plan chooses the profile; old plans remain v2.

    No host setting, available resource, caller PASS or retry selects a profile.
    Explicit null/unknown values are rejected rather than treated as legacy.
    """
    renderer = plan.get('render_profile', PHASE6_SEGMENT_RENDERER)
    segment_encoder_arguments(renderer)
    return renderer


def final_video_arguments(renderer: str) -> list[str]:
    """Do not add a second lossy encode to the colour-preserving profile."""
    segment_encoder_arguments(renderer)
    if renderer == PALETTE_QP1_SEGMENT_RENDERER:
        return ['-c:v', 'copy']
    return ['-c:v', 'libx264', '-profile:v', 'high', '-preset', 'slow',
            '-b:v', '10M', '-maxrate', '12M', '-bufsize', '24M', '-pix_fmt',
            'yuv420p', '-g', '60', '-keyint_min', '30', '-sc_threshold', '0']


def segment_encoder_arguments(renderer: str = PHASE6_SEGMENT_RENDERER) -> list[str]:
    """Compile exact encoder arguments; no environment-, resource- or retry fallback.

    v2 remains byte-for-byte compatible. The explicit forward profile uses the
    minimum positive QP for H.264 High/4:2:0. It passed paired synthetic palette
    controls, not a universal error bound: a future output still requires its
    real QA and resource reservation. Selecting an ID is never an approval.
    """
    if type(renderer) is not str:
        raise ValueError('exact segment renderer identity required')
    if renderer == PHASE6_SEGMENT_RENDERER:
        control = ['-crf','18']
    elif renderer == PALETTE_QP1_SEGMENT_RENDERER:
        control = ['-qp','1']
    else:
        raise ValueError('unqualified segment encoder profile')
    return ['-c:v','libx264','-profile:v','high','-preset','medium',*control,
            '-pix_fmt','yuv420p','-g','60','-keyint_min','30','-sc_threshold','0']
