"""Two fixed YuNet operational controls, never domain calibration or admission.

The inputs are the already decoded, externally pinned RGB24 buffers. This
producer neither invokes a decoder nor downloads, renders or selects media.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

VERSION = "phase6-av-publicity-control-worker-v2"
ROOT = Path(__file__).absolute().parents[1]
MODULE = Path(__file__).absolute()
TEST = ROOT / "tests/test_phase6_av_publicity_control_worker.py"
PROBE = ROOT / "hero_engine/phase6_av_publicity_worker_probe.py"
PROBE_SHA = "8de464e94b446e12b6f9ced9492296b842869f5905c5087a1ced2ad48bad601b"
PROBE_TEST = ROOT / "tests/test_phase6_av_publicity_worker_probe.py"
PROBE_TEST_SHA = "1766b2de25512174979ef772491db3f0a351d519142091060cbdcff2e94387e2"
SEMANTICS = ROOT / "hero_engine/phase6_av_detector_semantics.py"
SEMANTICS_SHA = "e0ac1e49873033a52ab4b2e3dba4c6c4811fb2ade28d97fb2a40e3af8a4ac13f"
SEMANTICS_TEST = ROOT / "tests/test_phase6_av_detector_semantics.py"
SEMANTICS_TEST_SHA = "1f70481d02ac177110cff3081c9c03c16ab73bb7b614d3376b12ca464318e6be"
CONTROL_ROOT = ROOT / "output/qa/phase6/diagnostics/phase6-av-publicity-clock-fix-v1/detector-controls-v1"
DECODE_ROOT = CONTROL_ROOT / "decode-v1"
DECODE_TERMINAL = DECODE_ROOT / "terminal.json"
DECODE_TERMINAL_SHA = "b60cbf732f502a2871217225b55880288bf812915c11e7cb5069eaaeed55a692"
MODEL_PINS = {
    "models/yunet/face_detection_yunet_2026may.onnx": "ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0",
    "models/yunet/LICENSE": "2ad92c7a6eb7aebede4e19f5ec4930c8bd9d614dbb8e75be1f740edae346734c",
    "models/yunet/MODEL_CARD.md": "fde76cdb816cf6289b6c51e81424860fb50e592d7055be5201904d51911c1809",
}
MODEL_LOADING = {"api": "cv2.FaceDetectorYN.create.buffer", "framework": "onnx",
                 "model_dtype": "uint8", "configuration_dtype": "uint8", "configuration_size_bytes": 0,
                 "source": "EXACT_PINNED_MODEL_BYTE_BUFFER", "path_copy": False, "path_retry": False}
CONTROLS = (
    {"decode_id": "positive", "control_id": "frontal-astronaut", "source_path": CONTROL_ROOT / "astronaut.png",
     "source_sha256": "88431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5", "width": 512, "height": 512},
    {"decode_id": "negative", "control_id": "project-procedural-no-face",
     "source_path": ROOT / "output/production/phase5/pilot-001/creative-v3/assets/procedural/asset-owned-truth-test-motion-v1.png",
     "source_sha256": "b693ff1684438d5e11e0d7cb3d9a067e03ea57e918a79d3afc08cf2a4ce840a0", "width": 1920, "height": 1080},
)
DECODE_DEPENDENCY_PATHS = (
    CONTROL_ROOT / "acquisition-plan.md", CONTROL_ROOT / "source-observations.md",
    ROOT / "output/production/phase5/pilot-001/creative-v3/assets/procedural/asset-owned-truth-test-motion-v1.svg",
    ROOT / "output/production/phase5/pilot-001/rights_evidence/asset-owned-truth-test-motion-v1.json",
    Path("C:/ffmpeg/bin/ffmpeg.exe"), ROOT / "hero_engine/phase6_av_publicity_v2.py",
    ROOT / "hero_engine/phase6_publicity.py", ROOT / "hero_engine/audio_perception_supervisor.py",
    ROOT / "hero_engine/audio_perception.py", ROOT / "hero_engine/__init__.py",
    CONTROL_ROOT / "decode_controls.py", CONTROL_ROOT / "test_decode_controls.py",
    *(row["source_path"] for row in CONTROLS),
)
DECODE_AUTHORITY = dict.fromkeys(("human_gold_standard", "legal_clearance", "publication_authorized",
                                 "quality_approved", "queue_authorized", "render_authorized", "source_admission"), False)
AUTHORITY = dict.fromkeys(("detector_calibrated", "human_gold", "source_admitted", "quality_approved",
                          "publicity_approved", "legal_clearance", "render_authorized", "queue_authorized",
                          "publication_authorized"), False)
LIMITATIONS = ["TWO_OPERATIONAL_EXAMPLES_NOT_DOMAIN_CALIBRATION", "NO_HUMAN_GOLD_OR_PUBLICITY_CLEARANCE",
               "PYTHON_FILE_ORIGINS_NOT_OS_DLL_OR_MEMORY_ATTESTATION", "NO_DECODE_RENDER_NETWORK_OR_PUBLICATION",
               "RAW_FAILURES_PRESERVED_NO_RETRY_OR_THRESHOLD_REFIT", "NOT_INSTALLED_IN_PRODUCTION_CONSUMERS"]


def _probe():
    # The one bootstrap preceding W's reviewed authenticated-source loader.
    for path in (PROBE, *PROBE.parents):
        info = path.lstat()
        if path.is_symlink() or getattr(path, "is_junction", lambda: False)() or getattr(info, "st_file_attributes", 0) & (0x400 | 0x1000 | 0x40000 | 0x400000):
            raise ValueError("linked/nonresident fixed probe bootstrap")
    before = PROBE.stat()
    if before.st_nlink != 1 or not 0 < before.st_size <= 128 * 1024:
        raise ValueError("invalid fixed probe bootstrap")
    with PROBE.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(128 * 1024 + 1)
        closed = os.fstat(stream.fileno())
    identity = lambda value: (value.st_dev, value.st_ino, value.st_nlink, value.st_size, value.st_mtime_ns)
    if (any(identity(item) != identity(before) for item in (opened, closed, PROBE.stat()))
            or len(raw) != before.st_size or hashlib.sha256(raw).hexdigest() != PROBE_SHA):
        raise ValueError("probe implementation pin differs")
    module = types.ModuleType("_publicity_control_probe")
    module.__file__ = str(PROBE)
    sys.modules[module.__name__] = module
    exec(compile(raw, str(PROBE), "exec"), module.__dict__)
    module._pin(PROBE, PROBE_SHA)
    return module


def _codes(w, worker_sha, test_sha):
    return {"worker": w._binding(PROBE, PROBE_SHA), "test": w._binding(PROBE_TEST, PROBE_TEST_SHA),
            "runtime": w._binding(w.RUNTIME, w.RUNTIME_SHA), "supervisor": w._binding(w.SUPERVISOR, w.SUPERVISOR_SHA),
            "supervisor_support": w._binding(w.AUDIO_SUPPORT, w.AUDIO_SUPPORT_SHA),
            "control_worker": w._binding(MODULE, worker_sha), "control_test": w._binding(TEST, test_sha),
            "semantics": w._binding(SEMANTICS, SEMANTICS_SHA), "semantics_test": w._binding(SEMANTICS_TEST, SEMANTICS_TEST_SHA)}


def _read(files, path, digest, *, size=None, capture=False):
    cap = 160 * 1024**2 if Path(path) == Path("C:/ffmpeg/bin/ffmpeg.exe") else 8 * 1024**2
    expected = None if size is None else {"path": str(path), "sha256": "sha256:" + digest, "size_bytes": size}
    value = files.read(path, cap=cap, capture=capture, expected=expected)
    binding = files.items[str(path)][0]
    if binding["sha256"] != "sha256:" + digest:
        raise ValueError("input differs from external pin")
    return value


def _binding_map(rows, expected_paths):
    if type(rows) is not list or len(rows) != len(expected_paths):
        raise ValueError("exact bound population required")
    result = {}
    for row in rows:
        if (type(row) is not dict or set(row) != {"path", "sha256", "size_bytes"}
                or type(row["path"]) is not str or row["path"] in result
                or type(row["sha256"]) is not str or len(row["sha256"]) != 64
                or any(character not in "0123456789abcdef" for character in row["sha256"])):
            raise ValueError("duplicate or malformed dependency binding")
        if type(row["size_bytes"]) is not int or row["size_bytes"] < 0:
            raise ValueError("exact input byte count required")
        result[row["path"]] = row
    if set(result) != {str(path) for path in expected_paths}:
        raise ValueError("unrecognized dependency/output path")
    return result


def _decode_inventory(runtime):
    expected = {"request.json", "terminal.json", *(f"{kind}/{name}" for kind in ("positive", "negative")
                for name in ("stdout.log", "stderr.log", "process-receipt.json", "decode-report.json"))}
    actual = set()
    for path in runtime._resident(DECODE_ROOT).iterdir():
        runtime._resident(path)
        if path.is_dir():
            if path.name not in ("positive", "negative"):
                raise ValueError("unexpected decode directory")
            for child in path.iterdir():
                runtime._resident(child)
                if not child.is_file():
                    raise ValueError("unexpected nested decode artifact")
                actual.add(path.name + "/" + child.name)
        else:
            actual.add(path.name)
    if actual != expected:
        raise ValueError("decode inventory changed or contains failure artifacts")


def _control_inputs(w, runtime, *, capture_pixels=False):
    """Reopen existing decode evidence; parse PPM bytes, never invoke a codec."""
    files = runtime._Files()
    terminal = runtime._json(_read(files, DECODE_TERMINAL, DECODE_TERMINAL_SHA, capture=True))
    for key, value in {"version": "publicity-two-control-decode-v1", "kind": "PUBLICITY_CONTROL_DECODE_TERMINAL",
                       "status": "CONTROLS_DECODED_NOT_EVALUATED", "error": None, "completed_decode_count": 2,
                       "decode_calls_reserved": ["positive", "negative"], "authority": DECODE_AUTHORITY,
                       "automatic_retries": 0, "cv_calls": 0, "ocr_calls": 0, "inference_calls": 0,
                       "network_calls": 0, "technical_cost_brl": 0}.items():
        w._same(terminal[key], value, "decode terminal is not the fixed completed pair")
    _decode_inventory(runtime)
    deps = _binding_map(terminal["dependency_bindings"], DECODE_DEPENDENCY_PATHS)
    output_paths = [DECODE_ROOT / "request.json", *(DECODE_ROOT / control["decode_id"] / name for control in CONTROLS
                    for name in ("stdout.log", "stderr.log", "process-receipt.json", "decode-report.json"))]
    outputs = _binding_map(terminal["output_bindings"], output_paths)
    documents, pixels, observed = {}, {}, []
    for mapping in (deps, outputs):
        for path, binding in mapping.items():
            capture = Path(path).suffix == ".json" or path.endswith("/stdout.log") or Path(path).name == "stdout.log"
            raw = _read(files, Path(path), binding["sha256"], size=binding["size_bytes"], capture=capture)
            if capture:
                documents[path] = raw
    request = runtime._json(documents[str(DECODE_ROOT / "request.json")])
    w._same(request["dependency_bindings"], terminal["dependency_bindings"], "decode request closure differs")
    if len(terminal["controls"]) != 2 or len(request["controls"]) != 2:
        raise ValueError("two control identities required")
    for control, row, requested in zip(CONTROLS, terminal["controls"], request["controls"]):
        folder = DECODE_ROOT / control["decode_id"]
        source = deps[str(control["source_path"])]
        w._same(source["sha256"], control["source_sha256"], "control source changed")
        w._same(row, runtime._json(documents[str(folder / "decode-report.json")]), "decode row and persisted report differ")
        for key, value in {"control_id": control["decode_id"], "source_binding": source,
                           "ppm_binding": outputs[str(folder / "stdout.log")],
                           "process_receipt_binding": outputs[str(folder / "process-receipt.json")],
                           "status": "DECODED_CONTROL_NOT_DETECTOR_EVALUATED", "authority": DECODE_AUTHORITY}.items():
            w._same(row[key], value, "control decode identity differs")
        w._same(row["command"], requested["command"], "decode command differs from bound request")
        w._same(requested["source_binding"], source, "requested source differs")
        process = runtime._json(documents[str(folder / "process-receipt.json")])
        w._same(process, row["process"], "process receipt differs from terminal")
        for key, value in {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
                           "assigned_before_resume": True, "kill_on_close": True,
                           "committed_memory_limit_bytes": 2 * 1024**3, "timeout_seconds": 30.0,
                           "release_authority": False, "audio_approved": False}.items():
            w._same(process[key], value, "decoded control process did not meet bounds")
        w._same(process["logs"], [{"path": str(folder / name), "sha256": outputs[str(folder / name)]["sha256"],
                                  "size": outputs[str(folder / name)]["size_bytes"]} for name in ("stdout.log", "stderr.log")],
                "process log bytes are not the persisted outputs")
        width, height = control["width"], control["height"]
        raw = documents[str(folder / "stdout.log")]
        header = f"P6\n{width} {height}\n255\n".encode("ascii")
        if not raw.startswith(header) or len(raw) != len(header) + width * height * 3:
            raise ValueError("exact predecoded RGB24 PPM required")
        payload = raw[len(header):]
        w._same(row["ppm"], {"width": width, "height": height, "pixel_order": "RGB24", "pixel_bytes": len(payload),
            "pixel_sha256": hashlib.sha256(payload).hexdigest(), "source_frame_index": 0,
            "resize_performed": False, "detector_called": False}, "PPM bytes and decode measurement differ")
        observed.append({"control_id": control["control_id"], "source_binding": source,
                         "ppm_binding": row["ppm_binding"], "width": width, "height": height})
        if capture_pixels:
            pixels[control["control_id"]] = payload
    model_bytes = None
    model_name = next(iter(MODEL_PINS))
    for relative, digest in MODEL_PINS.items():
        captured = _read(files, ROOT / relative, digest, capture=capture_pixels and relative == model_name)
        if capture_pixels and relative == model_name:
            model_bytes = captured
    files.recheck()
    _decode_inventory(runtime)
    return {"controls": observed, "pixels": pixels, "files": files,
            "decode_terminal_binding": files.items[str(DECODE_TERMINAL)][0],
            "model_bindings": [files.items[str(ROOT / name)][0] for name in MODEL_PINS],
            "model_bytes": model_bytes}


def prepare_controls(root, *, profile_binding, expected_worker_sha, expected_test_sha, run_directory):
    w = _probe()
    prepared = w.prepare_probe(root, profile_binding=profile_binding, expected_worker_sha=PROBE_SHA,
                               expected_test_sha=PROBE_TEST_SHA, run_directory=run_directory)
    runtime = w._runtime()
    code = _codes(w, expected_worker_sha, expected_test_sha)
    semantics = w._load(SEMANTICS, SEMANTICS_SHA, "_publicity_control_semantics")
    context = _control_inputs(w, runtime)
    request = {**prepared["request"], "version": VERSION, "code_bindings": code, "authority": dict(AUTHORITY),
               "controls": context["controls"], "decode_terminal_binding": context["decode_terminal_binding"],
               "model_bindings": context["model_bindings"], "model_loading": dict(MODEL_LOADING),
               "settings": semantics.SETTINGS}
    return {"status": "PREFLIGHT_ONLY_NO_INFERENCE", "request": request, "request_sha256": w._sha(w._canonical(request)),
            "process_calls": 0, "inference_calls": 0, "decode_calls": 0, "files_written": 0}


def _infer_raw(semantics, cv2, numpy, detector, control, pixels):
    width, height = control["width"], control["height"]
    if len(pixels) != width * height * 3:
        raise ValueError("RGB24 buffer length changed")
    image = numpy.frombuffer(pixels, numpy.uint8).reshape(height, width, 3)[:, :, ::-1].copy()
    if width > 1280:
        image = cv2.resize(image, (1280, max(1, round(height * (1280 / width)))), interpolation=cv2.INTER_LINEAR)
    actual_height, actual_width = image.shape[:2]
    detector.setInputSize((actual_width, actual_height))
    retval, detections = detector.detect(image)
    return {"settings": semantics.SETTINGS, "input_size": [actual_width, actual_height], "opencv_version": cv2.__version__,
            "retval": retval, "detections": None if detections is None else detections.tolist()}


def _detector_from_buffer(w, cv2, numpy, context):
    """Use the documented buffer overload; never retry a Unicode path or copy it."""
    model = context["model_bytes"]
    binding = context["model_bindings"][0]
    if type(model) is not bytes or not model:
        raise ValueError("private authenticated model bytes required")
    w._same(len(model), binding["size_bytes"], "captured model byte count differs")
    w._same("sha256:" + w._sha(model), binding["sha256"], "captured model bytes differ from original source")
    model_view = numpy.frombuffer(model, numpy.uint8)
    empty_configuration = numpy.frombuffer(b"", numpy.uint8)
    return cv2.FaceDetectorYN.create("onnx", model_view, empty_configuration, (320, 320), 0.80, 0.30, 5000)


def _measure_controls(w, semantics, cv2, numpy, context, directory, recheck):
    cv2.setNumThreads(1)
    cv2.ocl.setUseOpenCL(False)
    if cv2.getNumThreads() != 1 or cv2.ocl.useOpenCL() is not False:
        raise ValueError("observed thread/OpenCL settings differ")
    recheck()
    detector = _detector_from_buffer(w, cv2, numpy, context)
    observations, output_bindings = [], []
    for control in context["controls"]:
        recheck()
        identity = control["control_id"]
        claim = directory / (identity + "-started.json")
        claim_raw = w._canonical({"version": VERSION, "control": control, "settings": semantics.SETTINGS,
                                  "inference_reserved": True, "authority": AUTHORITY})
        w._exclusive(claim, claim_raw)
        output_bindings.append(w._binding(claim, w._sha(claim_raw)))
        raw = _infer_raw(semantics, cv2, numpy, detector, control, context["pixels"][identity])
        path = directory / (identity + "-raw.json")
        try:
            encoded = w._canonical(raw)
        except (ValueError, TypeError):
            # Non-finite native output must not disappear or become valid JSON.
            # Retain it explicitly as diagnostic text; the run remains rejected.
            diagnostic = json.dumps(raw, sort_keys=True, ensure_ascii=False, allow_nan=True).encode("utf-8")
            if len(diagnostic) > 1024**2:
                raise ValueError("invalid raw detector result exceeds diagnostic cap")
            w._exclusive(directory / (identity + "-invalid-raw.txt"), diagnostic)
            raise
        w._exclusive(path, encoded)
        output_bindings.append(w._binding(path, w._sha(encoded)))
        parsed = semantics.validate_raw(raw, source_width=control["width"], source_height=control["height"],
                                        observed_opencv_version=cv2.__version__)
        if identity == "frontal-astronaut":
            faces = raw["detections"] or []
            if not (parsed["face_count"] == 1 and 170 <= faces[0][0] + faces[0][2] / 2 <= 290
                    and 60 <= faces[0][1] + faces[0][3] / 2 <= 190):
                raise ValueError("pre-registered positive control failed; no second inference")
        recheck()
        for item in output_bindings:
            w._pin(Path(item["path"]), item["sha256"][7:])
        observations.append({"control_id": identity, "source_sha256": "sha256:" + control["source_binding"]["sha256"],
                             "width": control["width"], "height": control["height"], "raw": raw,
                             "observed_opencv_version": cv2.__version__})
    return observations, semantics.evaluate_controls(observations), output_bindings


def _output_paths(directory):
    return [directory / (control["control_id"] + suffix) for control in CONTROLS
            for suffix in ("-started.json", "-raw.json")]


def _success_inventory(runtime, directory, *, terminal=False):
    """A historical successful report never overrides a failure marker or extra file."""
    expected = {"request.json", "controls.json", "process/stdout.log", "process/stderr.log",
                *(path.name for path in _output_paths(directory))}
    if terminal:
        expected.add("terminal.json")
    actual = set()
    for path in runtime._resident(directory).iterdir():
        runtime._resident(path)
        if path.is_dir():
            if path.name != "process":
                raise ValueError("unexpected control-worker output directory")
            for child in path.iterdir():
                runtime._resident(child)
                if not child.is_file():
                    raise ValueError("nested control-worker output")
                actual.add("process/" + child.name)
        elif path.is_file():
            actual.add(path.name)
        else:
            raise ValueError("nonregular control-worker output")
    if actual != expected:
        raise ValueError("control-worker inventory incomplete or contains failure artifacts")


def _reopen_outputs(w, runtime, directory, report, controls):
    paths = _output_paths(directory)
    rows = report["output_bindings"]
    if type(rows) is not list or len(rows) != len(paths):
        raise ValueError("exact four raw/reservation bindings required")
    for index, (path, binding) in enumerate(zip(paths, rows)):
        if (type(binding) is not dict or set(binding) != {"path", "sha256", "size_bytes"}
                or binding["path"] != str(path)):
            raise ValueError("control-worker output order or scope differs")
        runtime._binding(binding)
        raw = w._pin(path, binding["sha256"][7:])
        if len(raw) != binding["size_bytes"]:
            raise ValueError("control-worker output byte count differs")
        observed = runtime._json(raw)
        control = controls[index // 2]
        expected = (report["observations"][index // 2]["raw"] if index % 2 else
                    {"version": VERSION, "control": control, "settings": report["observations"][index // 2]["raw"]["settings"],
                     "inference_reserved": True, "authority": AUTHORITY})
        w._same(observed, expected, "persisted raw/reservation differs from actual observation")


def _reopen_origins(w, runtime, profile, request, origins):
    if type(origins) is not dict or set(origins) != {"modules", "absent_cache_paths"}:
        raise ValueError("closed worker-origin observation required")
    if type(origins["modules"]) is not list or not origins["modules"]:
        raise ValueError("worker origin population absent")
    if type(origins["absent_cache_paths"]) is not list:
        raise ValueError("closed absent-cache population required")
    allowed = {row["path"]: row for row in (*profile["file_bindings"], *request["code_bindings"].values())}
    files, names, checked = runtime._Files(), set(), set()
    for row in origins["modules"]:
        name = row["module"]
        if type(name) is not str or name in names:
            raise ValueError("duplicate or invalid worker origin")
        names.add(name)
        supports = row.get("support_bindings")
        if type(supports) is not list or len(supports) > 1:
            raise ValueError("namespace and pseudo-module support closure absent")
        for item in (row["file_binding"], row["cache_binding"], *supports):
            if item is not None:
                runtime._binding(item)
                w._same(item, allowed.get(item["path"]), "reported origin outside fixed profile")
                if item["path"] not in checked:
                    files.read(item["path"], cap=runtime.FILE_CAP, expected=item)
                    checked.add(item["path"])
        for value in row.get("namespace_paths", []):
            if value not in profile["population"]["directories"] or not runtime._resident(Path(value)).is_dir():
                raise ValueError("reported namespace outside fixed population")
    if not {"cv2", "numpy", "numpy._core._multiarray_umath"}.issubset(names):
        raise ValueError("actual CV/NumPy origins absent")
    for path in origins["absent_cache_paths"]:
        if type(path) is not str or os.path.lexists(path):
            raise ValueError("reported absent cache appeared")
    # _origins also measured these declared DLLs even though they are not Python modules.
    site = Path(profile["site_packages"])
    for item in profile["file_bindings"]:
        path = Path(item["path"])
        if path.suffix.lower() == ".dll" and (path.is_relative_to(site / "cv2") or path.is_relative_to(site / "numpy.libs")):
            if item["path"] not in checked:
                files.read(path, cap=runtime.FILE_CAP, expected=item)
                checked.add(item["path"])
    return files


def _worker(request_path, request_sha, expected_worker_sha, expected_test_sha):
    started = time.perf_counter()
    w = _probe()
    runtime = w._runtime()
    startup = w._startup(runtime)
    raw_request = w._pin(request_path, request_sha)
    request = runtime._json(raw_request)
    expected_code = _codes(w, expected_worker_sha, expected_test_sha)
    expected_keys = {"version", "root", "profile_binding", "code_bindings", "run_directory", "memory_bytes", "timeout_seconds",
                     "authority", "technical_cost_brl", "controls", "decode_terminal_binding", "model_bindings",
                     "model_loading", "settings"}
    if type(request) is not dict or set(request) != expected_keys:
        raise ValueError("closed control-worker request required")
    directory = runtime._resident(Path(request["run_directory"]))
    prefix = ROOT / "output/qa/phase6/diagnostics"
    if directory == prefix or not directory.is_relative_to(prefix) or request_path != directory / "request.json":
        raise ValueError("request outside exclusive control-worker namespace")
    for key, value in {"version": VERSION, "root": str(ROOT), "code_bindings": expected_code, "authority": AUTHORITY,
                       "memory_bytes": w.MEMORY_BYTES, "timeout_seconds": w.TIMEOUT_SECONDS, "technical_cost_brl": 0}.items():
        w._same(request[key], value, "fixed request or process bounds differ")
    containment = w._supervisor()._require_worker_containment(w.MEMORY_BYTES)
    profile = w._profile(runtime, request["profile_binding"])
    semantics = w._load(SEMANTICS, SEMANTICS_SHA, "_publicity_control_semantics")
    context = _control_inputs(w, runtime, capture_pixels=True)
    for key in ("controls", "decode_terminal_binding", "model_bindings"):
        w._same(request[key], context[key], "reopened controls differ from request")
    w._same(request["settings"], semantics.SETTINGS, "pre-registered detector settings differ")
    w._same(request["model_loading"], MODEL_LOADING, "fixed direct-buffer model-loading recipe differs")
    file_validation = runtime.validate_profile(ROOT, profile_binding=request["profile_binding"])
    sys.path.insert(0, str(ROOT / ".venv/Lib/site-packages"))
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    import cv2
    import numpy
    native, exports = w._native_observation(runtime, cv2, numpy)
    origins, origin_files = w._origins(runtime, profile, modules=sys.modules, extra_bindings=list(expected_code.values()), native_exports=exports)
    def recheck():
        context["files"].recheck()
        _decode_inventory(runtime)
        w._recheck(runtime, profile, origin_files, request, request_path, request_sha)
        for path in origins["absent_cache_paths"]:
            if os.path.lexists(path):
                raise ValueError("cache appeared during no-write control worker")
    try:
        observations, evaluation, outputs = _measure_controls(w, semantics, cv2, numpy, context, directory, recheck)
        # Reinspect actual modules after native inference for newly loaded origins.
        final_origins, final_files = w._origins(runtime, profile, modules=sys.modules,
            extra_bindings=list(expected_code.values()), native_exports=w._native_observation(runtime, cv2, numpy)[1])
        w._recheck(runtime, profile, final_files, request, request_path, request_sha)
        recheck()
        report = {"version": VERSION, "status": evaluation["status"], "request_binding": w._binding(request_path, request_sha),
            "profile_binding": request["profile_binding"], "code_bindings": expected_code,
            "decode_terminal_binding": context["decode_terminal_binding"], "model_bindings": context["model_bindings"],
            "model_loading": dict(MODEL_LOADING),
            "startup": startup, "containment": containment, "native_observation": native, "origins": final_origins,
            "file_validation": file_validation, "profile_validation_calls": 1, "observations": observations,
            "evaluation": evaluation, "output_bindings": outputs, "inference_calls": 2,
            "decode_calls": 0, "network_calls": 0, "technical_cost_brl": 0, "authority": dict(AUTHORITY),
            "elapsed_seconds": time.perf_counter() - started, "limitations": list(LIMITATIONS)}
        raw = w._canonical(report)
        w._exclusive(directory / "controls.json", raw)
        recheck()
        w._recheck(runtime, profile, final_files, request, request_path, request_sha)
        for item in outputs:
            w._pin(Path(item["path"]), item["sha256"][7:])
        w._pin(directory / "controls.json", w._sha(raw))
        print(w._canonical({"controls_sha256": w._sha(raw)}).decode("utf-8"), flush=True)
        return report
    except Exception as exc:
        w._exclusive(directory / "failure.json", w._canonical({"version": VERSION, "status": "CONTROL_WORKER_FAILED_NOT_ADMITTED",
            "request_binding": w._binding(request_path, request_sha), "error": {"type": type(exc).__name__, "message": str(exc)},
            "automatic_retries": 0, "technical_cost_brl": 0, "authority": dict(AUTHORITY)}))
        raise


def _completed(w, runtime, request, request_path, request_sha, process):
    directory = request_path.parent
    for key, value in {"status": "SUCCEEDED", "exit_code": 0, "remaining_processes_verified": 0,
                       "assigned_before_resume": True, "kill_on_close": True,
                       "committed_memory_limit_bytes": w.MEMORY_BYTES, "timeout_seconds": float(w.TIMEOUT_SECONDS),
                       "error": None, "release_authority": False, "audio_approved": False}.items():
        w._same(process[key], value, "control worker did not complete inside exact process bounds")
    logs = process["logs"]
    if type(logs) is not list or len(logs) != 2:
        raise ValueError("exact supervised log pair required")
    log_files = runtime._Files()
    for row, name in zip(logs, ("stdout.log", "stderr.log")):
        if (type(row) is not dict or set(row) != {"path", "sha256", "size"}
                or row["path"] != str(directory / "process" / name)
                or type(row["sha256"]) is not str or len(row["sha256"]) != 64
                or type(row["size"]) is not int or row["size"] < 0):
            raise ValueError("supervised log identity differs")
        log_files.read(row["path"], cap=1024**2, expected={"path": row["path"],
            "sha256": "sha256:" + row["sha256"], "size_bytes": row["size"]})
    stdout = w._pin(Path(logs[0]["path"]), logs[0]["sha256"])
    completed = runtime._json(stdout)
    if (type(completed) is not dict or set(completed) != {"controls_sha256"}
            or len(stdout) != logs[0]["size"] or stdout.strip() != w._canonical(completed)):
        raise ValueError("unexpected supervised output")
    report_path = directory / "controls.json"
    report = runtime._json(w._pin(report_path, completed["controls_sha256"]))
    keys = {"version", "status", "request_binding", "profile_binding", "code_bindings", "decode_terminal_binding",
            "model_bindings", "model_loading", "startup", "containment", "native_observation", "origins", "file_validation",
            "profile_validation_calls", "observations", "evaluation", "output_bindings", "inference_calls",
            "decode_calls", "network_calls", "technical_cost_brl", "authority", "elapsed_seconds", "limitations"}
    if type(report) is not dict or set(report) != keys:
        raise ValueError("closed control-worker report required")
    for key in ("profile_binding", "code_bindings", "decode_terminal_binding", "model_bindings", "model_loading"):
        w._same(report[key], request[key], "completed report differs from request")
    w._same(report["model_loading"], MODEL_LOADING, "completed model-loading recipe differs")
    for key, value in {"version": VERSION, "request_binding": w._binding(request_path, request_sha), "authority": AUTHORITY,
                       "profile_validation_calls": 1, "inference_calls": 2, "decode_calls": 0,
                       "network_calls": 0, "technical_cost_brl": 0, "limitations": LIMITATIONS}.items():
        w._same(report[key], value, "completed report scope differs")
    w._same(report["native_observation"]["opencv_native_version"], "5.0.0", "actual OpenCV version differs")
    w._same(report["native_observation"]["numpy_version"], "2.5.2", "actual NumPy version differs")
    w._same(report["file_validation"]["status"], "FILE_PROFILE_VALIDATED_NOT_ADMITTED", "worker validation absent")
    w._same(report["file_validation"]["authority"], runtime.AUTHORITY, "runtime validation authority changed")
    semantics = w._load(SEMANTICS, SEMANTICS_SHA, "_publicity_control_semantics")
    evaluation = semantics.evaluate_controls(report["observations"])
    w._same(report["evaluation"], evaluation, "operational semantics changed")
    w._same(report["status"], evaluation["status"], "operational status differs")
    context = _control_inputs(w, runtime)
    for key in ("controls", "decode_terminal_binding", "model_bindings"):
        w._same(request[key], context[key], "input identity changed before parent completion")
    for row in report["observations"]:
        w._same(row["observed_opencv_version"], report["native_observation"]["opencv_native_version"],
                "raw was measured under a different actual runtime")
    profile = w._profile(runtime, request["profile_binding"])
    origin_files = _reopen_origins(w, runtime, profile, request, report["origins"])
    def close(*, terminal=False):
        context["files"].recheck()
        _decode_inventory(runtime)
        log_files.recheck()
        w._recheck(runtime, profile, origin_files, request, request_path, request_sha)
        _reopen_outputs(w, runtime, directory, report, context["controls"])
        w._pin(report_path, completed["controls_sha256"])
        for path in report["origins"]["absent_cache_paths"]:
            if os.path.lexists(path):
                raise ValueError("cache appeared before parent completion")
        _success_inventory(runtime, directory, terminal=terminal)
    close()
    return report, w._binding(report_path, completed["controls_sha256"]), close


def run_controls(root, *, profile_binding, expected_worker_sha, expected_test_sha, run_directory, commit=False):
    if type(commit) is not bool:
        raise ValueError("explicit boolean commit required")
    prepared = prepare_controls(root, profile_binding=profile_binding, expected_worker_sha=expected_worker_sha,
                                 expected_test_sha=expected_test_sha, run_directory=run_directory)
    if not commit:
        return prepared
    w = _probe()
    runtime, request = w._runtime(), prepared["request"]
    directory = Path(request["run_directory"])
    directory.mkdir(exist_ok=False)
    request_path = directory / "request.json"
    w._exclusive(request_path, w._canonical(request))
    terminal = {"version": VERSION, "status": "CONTROL_WORKER_FAILED_NOT_ADMITTED", "process": None,
                "request_binding": w._binding(request_path, prepared["request_sha256"]), "controls_binding": None,
                "authority": dict(AUTHORITY), "technical_cost_brl": 0, "error": None, "automatic_retries": 0}
    try:
        command = [str(runtime.BASE_PYTHON / "python.exe"), "-I", "-S", "-B", str(MODULE), "--worker",
                   str(request_path), prepared["request_sha256"], expected_worker_sha, expected_test_sha]
        terminal["process"] = w._supervisor().run_bounded(command, cwd=ROOT, logs=directory / "process",
            timeout_seconds=w.TIMEOUT_SECONDS, memory_bytes=w.MEMORY_BYTES)
        report, report_binding, close = _completed(w, runtime, request, request_path,
                                                   prepared["request_sha256"], terminal["process"])
        terminal.update(status=report["status"], controls_binding=report_binding)
        raw_terminal = w._canonical(terminal)
        w._exclusive(directory / "terminal.json", raw_terminal)
        close(terminal=True)
        w._pin(directory / "terminal.json", w._sha(raw_terminal))
        return terminal
    except Exception as exc:
        # A late failure never overwrites the earlier terminal or creates a retry.
        terminal.update(status="CONTROL_WORKER_FAILED_NOT_ADMITTED", error={"type": type(exc).__name__, "message": str(exc)})
        failed = w._canonical(terminal)
        if os.path.lexists(directory / "terminal.json"):
            w._exclusive(directory / "final-problem.json", failed)
        else:
            w._exclusive(directory / "problem.json", failed)
            w._exclusive(directory / "terminal.json", failed)
        return terminal


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", nargs=4, required=True)
    args = parser.parse_args().worker
    _worker(Path(args[0]), args[1], args[2], args[3])
