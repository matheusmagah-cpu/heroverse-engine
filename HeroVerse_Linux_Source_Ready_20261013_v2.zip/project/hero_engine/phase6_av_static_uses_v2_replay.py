"""Exact anchored replay of twenty-five prior untimed uses, no media work.

The external execution receipt, input and inspection pins precede all cached
claims. Reconstructs old inputs, complete source/use rows and dependency set.
Never calls the v2 pixel inspector or any rights evaluator again.
"""
from __future__ import annotations

import copy
from pathlib import Path

from . import phase6_av_static_sources as primitives
from . import phase6_av_static_asset_uses_v2 as previous

VERSION = "phase6-av-static-uses-v2-exact-replay-v1"
BASE = "output/operations/phase6/av-admission/static-asset-uses-v2"
ANCHOR = {"path": BASE + "/receipt.json", "sha256": "9e14abf9d38b3e8c01b621f4fad9f4c9e11c7ddd6df9dd239e4fa0d658842243"}
INPUT = {"path": BASE + "/input.json", "sha256": "65be03122e4ad1c17e74e7bff99324f0177e0a541735ecbdc85a9883fd828376"}
INSPECTION = {"path": BASE + "/inspection.json", "sha256": "14641e1282f3e0fa2b6540ac04abbac6e01629d476c9dffc1101af2165a5330e"}
CODE_PINS = {
    "hero_engine/phase6_av_static_asset_uses_v2.py": "2c2b74a57f42f6e2fe58bf43152ed7f4be623ab257c2594ffed6791991353703",
    "output/qa/phase6/diagnostics/two-column-compact-v1/build_static_asset_uses_v2.py": "ff4ba9b54fe9e6f4559cb822a934f4511cc1a2cf9dab9bf8bfa5817cbbdde12d",
    "schemas/phase6_av_static_asset_uses_v2.schema.json": "698d6bcc1cbc46b249101aa5cb535f5e230fce35c15c1ff2851144823211dd4c",
    "tests/test_phase6_av_static_uses_v2_materialization.py": "b3bfa000fd30e874c325c281142c41270929b4019f1b6f568dcf4b8d0f8aa7f9",
}


def _same(a, b, message):
    primitives._same(a, b, message)


def _validate_anchor(anchor):
    _same([anchor["kind"], anchor["status"], anchor["source_count"], anchor["use_count"],
           anchor["unique_png_content_count"], anchor["lineage_count"], anchor["remaining_unbound_visual_state_count"],
           anchor["authority"], anchor["technical_cost_brl"], anchor["input_binding"], anchor["inspection_binding"], anchor["implementation_pins"]],
          ["phase6-static-asset-uses-v2-materialization-v1", "VERIFIED_PARTIAL_UNTIMED_BINDINGS_NOT_PRODUCTION_READY",
           23, 25, 22, 3, 75, previous.AUTHORITY, 0, INPUT, INSPECTION, CODE_PINS], "historical v2 execution anchor differs")


def _validate_rows(document, inspected, literal, old_proof, rights_proofs, compact_receipt):
    previous._identity(inspected, "inspection_id", "static-asset-uses-v2-")
    _same([inspected["version"], inspected["status"], inspected["channel_id"], inspected["video_id"],
           inspected["input_binding"], inspected["source_bindings"], inspected["source_count"], inspected["use_count"],
           inspected["unique_png_content_count"], inspected["lineage_count"], inspected["source_ready"],
           inspected["global_schedule_created"], inspected["calibrated_timing_available"], inspected["authority"], inspected["technical_cost_brl"]],
          [previous.VERSION, "PARTIAL_LITERAL_ASSET_BINDINGS_NOT_PRODUCTION_READY", primitives.CHANNEL, "video-002",
           INPUT, document["source_bindings"], 23, 25, 22, 3, False, False, False, previous.AUTHORITY, 0], "historical v2 proof scope differs")
    states = {state["state_id"]: (row, state) for row in literal["rows"] for state in row["states"]}
    originals = {row["state_id"]: row for row in compact_receipt["design"]["states"]}
    sources, uses = copy.deepcopy(old_proof["sources"]), copy.deepcopy(old_proof["uses"])
    for item, rights, use in zip(document["sources"][11:], rights_proofs, document["uses"][13:], strict=True):
        sid = item["static_source"]["state_id"]
        _same(sid, rights["state_id"], "historical compact source order differs")
        row, state = states[sid]
        contract = previous.compact._contract(row, state, originals[sid])
        _same([item["source_id"], use["visual_state_id"], use["source_id"], use["literal_copy"]],
              [rights["asset_id"], sid, rights["asset_id"], contract["literal_copy"]], "historical compact use differs")
        sources.append({"source_id": item["source_id"], "asset_binding": copy.deepcopy(rights["artifacts"]["png_binding"]),
            "template_id": rights["template_id"], "state_id": sid, "lineage_id": rights["lineage_id"],
            "original_unit_id": contract["unit_id"], "original_fragment_ids": contract["fragment_ids"],
            "original_lexical_target": contract["lexical_target"], "source_inspection_id": rights["source_proof"]["inspection_id"],
            "source_inspection_sha256": rights["source_proof"]["sha256"], "rights_inspection_id": rights["inspection_id"],
            "rights_inspection_sha256": primitives._sha(primitives._canonical(rights))})
        uses.append({**copy.deepcopy(use), "entry": copy.deepcopy(state["entry"]),
            "source_provenance_unit_id": contract["unit_id"], "status": "LITERAL_ASSET_USE_BOUND_TIMING_AND_ADMISSION_PENDING"})
    _same([inspected["sources"], inspected["uses"]], [sources, uses], "historical v2 source/use rows do not recompose")
    covered = {use["visual_state_id"] for use in uses}
    _same([len(states), len(covered), len({row["asset_binding"]["sha256"] for row in sources}), len({row["lineage_id"] for row in sources})],
          [100, 25, 22, 3], "historical v2 coverage/content/lineage differs")
    _same(inspected["remaining_unbound_visual_state_ids"], sorted(set(states) - covered), "historical unbound states disappeared")
    _same(inspected["visual_amendment_evidence"], {"inspection_sha256": previous.canonical_sha(literal),
        "effective_rows_sha256": previous.canonical_sha(literal["rows"]), "changed_state_count": 12,
        "unmodified_state_count": 88, "source_ready": False, "global_schedule_created": False}, "historical V3 evidence differs")


def recheck(reader):
    previous._recheck(reader)
    config = previous.compact.CONFIG
    names = {sid + suffix for sid in config["state_ids"] for suffix in (".png", ".svg")} | {"receipt.json", "layouts.json"}
    if {path.name for path in reader.path(config["directory"]).iterdir()} != names:
        raise ValueError("historical compact inventory drift")
    if {path.name for path in reader.path(BASE).iterdir()} != {"input.json", "inspection.json", "receipt.json"}:
        raise ValueError("historical v2 transaction inventory drift")


def replay(root):
    guard = primitives._Reader(root)
    path = Path(__file__).absolute()
    if path != guard.root / "hero_engine/phase6_av_static_uses_v2_replay.py":
        raise ValueError("replay implementation from another root")
    guard.read_path(path, primitives._sha(primitives._resident(path).read_bytes()))
    for name, digest in CODE_PINS.items():
        guard.read(name, digest)
    anchor = previous._json(guard, ANCHOR)
    _validate_anchor(anchor)
    inspected = previous._json(guard, INSPECTION)
    reader, literal, old_document, old_proof, registry, rights_proofs = previous._envelope(root)
    document = previous._json(reader, INPUT)
    _same(document, previous._expected(literal, old_document, registry), "historical input does not recompose")
    config = previous.compact.CONFIG
    compact_receipt = previous._json(reader, {"path": config["directory"] + "/receipt.json", "sha256": config["receipt_sha256"]})
    _validate_rows(document, inspected, literal, old_proof, rights_proofs, compact_receipt)
    # The old inspector's same-call source reads were already represented in
    # the externally pinned rights registry. They must be present exactly;
    # a serialized dependency list cannot introduce unobserved authority.
    _same(inspected["dependency_bindings"], sorted(reader.bindings.values(), key=lambda item: item["path"]),
          "historical v2 dependency population does not independently recompose")
    for item in guard.bindings.values():
        reader.read_path(Path(item["path"]), item["sha256"])
    recheck(reader)
    return {"version": VERSION, "mode": "EXACT_CACHE_REPLAY", "anchor_binding": copy.deepcopy(ANCHOR),
        "input_binding": copy.deepcopy(INPUT), "inspection_binding": copy.deepcopy(INSPECTION),
        "input": document, "inspection": inspected, "literal": literal,
        "source_count": 23, "use_count": 25, "unique_png_content_count": 22, "lineage_count": 3,
        "image_decode_calls": 0, "ocr_inference_calls": 0, "rights_evaluation_calls": 0, "render_calls": 0,
        "source_ready": False, "authority": dict(previous.AUTHORITY), "technical_cost_brl": 0,
        "dependency_bindings": sorted(reader.bindings.values(), key=lambda item: item["path"])}
