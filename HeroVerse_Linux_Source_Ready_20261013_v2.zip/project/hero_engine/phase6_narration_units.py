"""Non-authoritative, sentence-aware narration planning for Phase 6.

Visual takes are not prosodic units. This module never synthesizes, edits media,
queues work or authorizes a release. Existing WAV durations describe the old
take-based assembly; they are NOT estimates of the proposed continuous speech.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import io
import json
import math
import re
import wave
from pathlib import Path
from typing import Any

VERSION = "phase6-narration-units-v1"
PLAN_PATH = "output/production/phase6/video-002/production/take_plan.json"
VOICE_PATH = "output/production/phase6/video-002/audio/manifests/voice-phase6-60322e8ee7586d38077e.json"
DIAGNOSTIC_DIR = "output/qa/phase6/diagnostics/narration-units-v1"
SCHEMA_PATH = "schemas/phase6_narration_unit_plan.schema.json"


def canonical_sha(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def bytes_sha(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _required_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label}: non-empty string required")
    return value


def _integer(value: Any, label: str, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{label}: integer >= {minimum} required")
    return value


def classify_ending(text: str) -> str:
    """Conservative punctuation evidence, not an NLP/semantic completion claim."""
    value = _required_string(text, "narration").rstrip().rstrip('"\'”’)]}')
    if value.endswith(("...", "…")):
        return "AMBIGUOUS_PUNCTUATION"
    if value.endswith("."):
        last_word = value.split()[-1].lstrip('"\'“‘([{')
        if re.fullmatch(r"(?:[A-Za-z]\.)+", last_word) or last_word.lower() in {
            "mr.", "mrs.", "ms.", "dr.", "prof.", "sr.", "jr.", "st.", "vs.", "etc.", "no.", "fig.",
        }:
            return "AMBIGUOUS_PUNCTUATION"
    return "EXPLICIT_SENTENCE_END" if value.endswith((".", "!", "?")) else "OPEN_CONTINUATION"


def _validate_sources(plan: dict, voice: dict) -> list[tuple[dict, dict]]:
    if not isinstance(plan, dict) or not isinstance(voice, dict):
        raise ValueError("plan and voice must be objects")
    for key in ("take_plan_id", "channel_id", "video_id"):
        _required_string(plan.get(key), key)
    if voice.get("schema_version") != "1.2.0" or voice.get("status") != "COMPLETE":
        raise ValueError("exact COMPLETE voice manifest 1.2 required")
    if voice.get("video_id") != plan["video_id"] or voice.get("take_plan", {}).get("take_plan_id") != plan["take_plan_id"]:
        raise ValueError("voice/plan identity mismatch")
    for key in ("voice_render_id", "voice_id", "model", "adapter_id", "adapter_implementation"):
        _required_string(voice.get(key), key)
    for key in ("model_hash", "voices_hash"):
        if not isinstance(voice.get(key), str) or not re.fullmatch(r"sha256:[a-f0-9]{64}", voice[key]):
            raise ValueError(f"{key}: exact hash required")
    takes, records = plan.get("takes"), voice.get("takes")
    if not isinstance(takes, list) or not takes or not isinstance(records, list) or len(records) != len(takes):
        raise ValueError("ordered non-empty take/voice arrays must have the same size")
    if type(voice.get("take_count")) is not int or voice["take_count"] != len(takes):
        raise ValueError("voice take_count mismatch")
    ids, cursor, pairs = set(), 0, []
    for take, record in zip(takes, records, strict=True):
        take_id = _required_string(take.get("take_id"), "take_id")
        if take_id in ids or record.get("take_id") != take_id:
            raise ValueError("duplicate or reordered take/voice identity")
        ids.add(take_id)
        start, end = _integer(take.get("start_ms"), "start_ms"), _integer(take.get("end_ms"), "end_ms", 1)
        if start != cursor or end <= start:
            raise ValueError("visual horizon must be contiguous, ordered and begin at zero")
        text = _required_string(take.get("narration"), "narration")
        if text != record.get("text"):
            raise ValueError(f"narration copy mismatch: {take_id}")
        slot, duration = end - start, _integer(record.get("duration_ms"), "duration_ms", 1)
        if type(record.get("timeline_slot_ms")) is not int or record["timeline_slot_ms"] != slot or duration > slot or record.get("fits_timeline_slot") is not True:
            raise ValueError(f"historical voice slot mismatch: {take_id}")
        frames = _integer(record.get("frame_count"), "frame_count", 1)
        sample_rate = _integer(record.get("sample_rate"), "sample_rate", 1)
        if sample_rate != voice.get("sample_rate") or round(frames * 1000 / sample_rate) != duration or frames * 1000 > slot * sample_rate:
            raise ValueError(f"historical WAV frame/duration mismatch: {take_id}")
        speed = record.get("speed")
        if isinstance(speed, bool) or not isinstance(speed, (int, float)) or not math.isfinite(speed) or speed <= 0:
            raise ValueError(f"invalid pinned speed: {take_id}")
        pairs.append((take, record))
        cursor = end
    if _integer(voice.get("timeline_duration_ms"), "timeline_duration_ms", 1) != cursor or _integer(voice.get("total_audio_duration_ms"), "total_audio_duration_ms", 1) != sum(r["duration_ms"] for _, r in pairs):
        raise ValueError("historical duration totals mismatch")
    return pairs


def build_narration_unit_plan(take_plan: dict, voice_manifest: dict) -> dict:
    """Pure deterministic plan; source dicts remain unchanged and no I/O occurs."""
    pairs = _validate_sources(take_plan, voice_manifest)
    units: list[dict] = []
    boundaries: list[dict] = []
    fragments: list[dict] = []
    ambiguous: list[str] = []

    def close_unit() -> None:
        if not fragments:
            return
        text = " ".join(f["text"] for f in fragments)
        speeds = {f["speed"] for f in fragments}
        issues = list(ambiguous)
        ending = classify_ending(fragments[-1]["text"])
        if ending != "EXPLICIT_SENTENCE_END":
            issues.append("NO_EXPLICIT_SENTENCE_END_AT_HORIZON")
        if len(speeds) != 1:
            issues.append("PINNED_SPEED_CHANGE_INSIDE_NARRATION_UNIT")
        start, end = fragments[0]["visual_start_ms"], fragments[-1]["visual_end_ms"]
        units.append({
            "unit_id": f"narration-unit-{len(units)+1:03d}",
            "take_ids": [f["take_id"] for f in fragments], "text": text,
            "text_sha256": bytes_sha(text.encode("utf-8")), "join_separator": " ",
            "source_fragments": copy.deepcopy(fragments),
            "window_start_ms": start, "window_end_ms": end,
            "window_limit_ms": end - start,
            "pinned_speed": next(iter(speeds)) if len(speeds) == 1 else None,
            "historical_audio_duration_ms": sum(f["historical_audio_duration_ms"] for f in fragments),
            "historical_padding_ms": sum(f["historical_padding_ms"] for f in fragments),
            "internal_visual_boundary_count": max(0, len(fragments) - 1),
            "proposed_visual_boundary_prosody_resets": 0,
            "ending_evidence": ending, "review_issues": issues,
            "readiness": "NEEDS_REVIEW" if issues else "NEEDS_SYNTHESIS",
            "synthesis_mode": "ONE_CONTINUOUS_UTTERANCE_WITHIN_WINDOW",
            "synthesized_duration_ms": None, "fits_window": None,
            "word_timestamps": None, "inter_unit_pause_ms": None,
            "synthesis_authorized": False,
        })
        fragments.clear()
        ambiguous.clear()

    for index, (take, record) in enumerate(pairs):
        ending = classify_ending(take["narration"])
        padding = record["timeline_slot_ms"] - record["duration_ms"]
        fragments.append({
            "take_id": take["take_id"], "text": take["narration"],
            "visual_start_ms": take["start_ms"], "visual_end_ms": take["end_ms"],
            "speed": record["speed"], "historical_audio_duration_ms": record["duration_ms"],
            "historical_padding_ms": padding,
        })
        if ending == "AMBIGUOUS_PUNCTUATION":
            ambiguous.append(f"AMBIGUOUS_ENDING:{take['take_id']}")
        if index < len(pairs) - 1:
            following = pairs[index + 1][0]
            boundaries.append({
                "left_take_id": take["take_id"], "right_take_id": following["take_id"],
                "at_ms": take["end_ms"], "left_text": take["narration"],
                "right_text": following["narration"], "ending_evidence": ending,
                "historical_padding_ms": padding,
                "historical_padding_exact_ms": round(record["timeline_slot_ms"] - record["frame_count"] * 1000 / record["sample_rate"], 6),
                "historical_separate_synthesis_calls": True,
                "proposed_relation": "SEPARATE_COMPLETE_UNITS" if ending == "EXPLICIT_SENTENCE_END" else "SAME_CONTINUOUS_UNIT",
                "visual_cut_forces_prosody_reset": False,
                "acoustic_silence_duration_ms": None,
            })
        if ending == "EXPLICIT_SENTENCE_END":
            close_unit()
    close_unit()
    source_copy = [take["narration"] for take, _ in pairs]
    reconstructed = [f["text"] for u in units for f in u["source_fragments"]]
    if source_copy != reconstructed:
        raise AssertionError("ordered source copy was not preserved")
    open_boundaries = [b for b in boundaries if b["ending_evidence"] != "EXPLICIT_SENTENCE_END"]
    result = {
        "schema_version": "1.0.0", "planner_version": VERSION,
        "status": "PLANNED_NOT_SYNTHESIZED", "channel_id": take_plan["channel_id"],
        "video_id": take_plan["video_id"], "take_plan_id": take_plan["take_plan_id"],
        "source_voice_render_id": voice_manifest["voice_render_id"],
        "source_objects": {"take_plan_sha256": canonical_sha(take_plan), "voice_manifest_sha256": canonical_sha(voice_manifest)},
        "voice_contract": {key: copy.deepcopy(voice_manifest[key]) for key in (
            "voice_id", "model", "model_hash", "voices_hash", "adapter_id", "adapter_implementation", "sample_rate",
        )},
        "timeline_start_ms": 0, "timeline_end_ms": pairs[-1][0]["end_ms"],
        "timeline_duration_ms": pairs[-1][0]["end_ms"],
        "source_copy_sha256": canonical_sha(source_copy), "copy_preserved": True,
        "units": units, "boundaries": boundaries,
        "summary": {
            "visual_take_count": len(pairs), "historical_synthesis_unit_count": len(pairs),
            "proposed_narration_unit_count": len(units), "visual_boundary_count": len(boundaries),
            "non_sentence_visual_boundary_count": len(open_boundaries),
            "historical_padding_at_non_sentence_boundaries_ms": sum(b["historical_padding_ms"] for b in open_boundaries),
            "historical_audio_duration_ms": voice_manifest["total_audio_duration_ms"],
            "historical_total_padding_ms": sum(r["timeline_slot_ms"] - r["duration_ms"] for _, r in pairs),
            "review_required_unit_count": sum(bool(u["review_issues"]) for u in units),
            "proposed_audio_duration_ms": None, "proposed_total_padding_ms": None,
            "synthesis_call_reduction_is_performance_proof": False,
        },
        "authority": {"queue_authorized": False, "synthesis_authorized": False, "render_authorized": False, "publication_authorized": False},
        "limitations": [
            "Punctuation is a conservative boundary signal, not a complete semantic or prosody evaluator.",
            "Historical padding is slot minus measured WAV duration, not measured acoustic silence or a perceptual score.",
            "Summed historical clip durations do not predict duration, quality or speed of continuous synthesis.",
            "No word timestamps exist; visual onsets cannot be aligned to individual spoken words yet.",
            "All visual windows and pinned voice settings are preserved; conflict requires review, never speedup or truncation.",
            "Existing per-take WAVs cannot prove or replace a new continuous-utterance synthesis.",
            "No integrated runtime, new capacity receipt, independent audio QA or release authorization is provided.",
        ],
    }
    result["plan_id"] = "phase6-narration-units-" + canonical_sha(result).split(":")[1][:24]
    return result


def verify_narration_unit_plan(candidate: dict, take_plan: dict, voice_manifest: dict) -> None:
    """Recompute all derived fields instead of trusting booleans/counts/hash labels."""
    if candidate != build_narration_unit_plan(take_plan, voice_manifest):
        raise ValueError("narration plan differs from deterministic source recomputation")


def _confined(root: Path, value: str) -> Path:
    candidate = Path(value)
    candidate = (root / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()
    if not candidate.is_relative_to(root):
        raise PermissionError("diagnostic source escapes workspace")
    return candidate


def diagnose_current_voice(root: Path) -> dict:
    """Read schemas/source bytes/WAVs, then write ONE isolated immutable diagnostic.

    No operational latest, schema, TakePlan, audio or queue can be changed here.
    """
    from jsonschema import Draft202012Validator, FormatChecker

    root = root.resolve()
    plan_path, voice_path = _confined(root, PLAN_PATH), _confined(root, VOICE_PATH)
    source_bytes = {"take_plan": plan_path.read_bytes(), "voice_manifest": voice_path.read_bytes()}
    plan, voice = (json.loads(source_bytes[key]) for key in ("take_plan", "voice_manifest"))
    for value, schema_name in ((plan, "take_plan.schema.json"), (voice, "voice_render_manifest.schema.json")):
        schema = json.loads((root / "schemas" / schema_name).read_text(encoding="utf-8"))
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(value)
    if voice["take_plan"]["sha256"] != bytes_sha(source_bytes["take_plan"]) or voice_path.stem != voice["voice_render_id"]:
        raise ValueError("immutable manifest/plan binding mismatch")
    script_path = _confined(root, voice["narrative_script"]["path"])
    script_bytes = script_path.read_bytes()
    if bytes_sha(script_bytes) != voice["narrative_script"]["sha256"]:
        raise ValueError("narrative script binding mismatch")
    result = build_narration_unit_plan(plan, voice)
    schema_bytes = (root / SCHEMA_PATH).read_bytes()
    Draft202012Validator(json.loads(schema_bytes), format_checker=FormatChecker()).validate(result)
    wav_evidence = []
    for record in voice["takes"]:
        wav_path = _confined(root, record["path"])
        if not wav_path.is_relative_to((root / "output/production/phase6/video-002/audio/takes").resolve()):
            raise PermissionError("WAV is outside the source take directory")
        raw = wav_path.read_bytes()
        if bytes_sha(raw) != record["content_hash"]:
            raise ValueError(f"WAV bytes changed: {record['take_id']}")
        with wave.open(io.BytesIO(raw), "rb") as wav:
            frames, rate, channels, width = wav.getnframes(), wav.getframerate(), wav.getnchannels(), wav.getsampwidth()
            decoded = wav.readframes(frames)
        if frames != record["frame_count"] or rate != record["sample_rate"] or channels != 1 or width != 2 or len(decoded) != frames * channels * width:
            raise ValueError(f"WAV header/data changed: {record['take_id']}")
        wav_evidence.append({"take_id": record["take_id"], "path": wav_path.relative_to(root).as_posix(), "sha256": bytes_sha(raw), "frame_count": frames, "sample_rate": rate, "duration_ms": round(frames * 1000 / rate)})
    renderer = root / "hero_engine/phase6_media.py"
    renderer_bytes = renderer.read_bytes()
    if b"apad,atrim=0:{duration:.3f}" not in renderer_bytes:
        raise ValueError("historical take-slot padding implementation no longer matches diagnosis")
    report = {
        "diagnostic_version": VERSION, "evidence_class": "LOCAL_SOURCE_AND_WAV_MEASUREMENTS",
        "status": "PLANNED_NOT_SYNTHESIZED", "plan": result,
        "source_files": [
            {"path": plan_path.relative_to(root).as_posix(), "sha256": bytes_sha(source_bytes["take_plan"])},
            {"path": voice_path.relative_to(root).as_posix(), "sha256": bytes_sha(source_bytes["voice_manifest"])},
            {"path": script_path.relative_to(root).as_posix(), "sha256": bytes_sha(script_bytes)},
            {"path": "hero_engine/phase6_media.py", "sha256": bytes_sha(renderer_bytes)},
            {"path": "hero_engine/phase6_narration_units.py", "sha256": bytes_sha(Path(__file__).read_bytes())},
            {"path": SCHEMA_PATH, "sha256": bytes_sha(schema_bytes)},
        ], "verified_wavs": wav_evidence,
        "old_assembly_rule": "independent synthesis per visual take; apad to each visual slot; concatenate",
        "new_proposed_rule": "one continuous utterance per complete unit; visual cuts do not restart speech; measured fit remains required",
        "queue_authorized": False, "render_authorized": False, "publication_authorized": False,
        "external_cost_brl": 0,
    }
    report["diagnostic_id"] = "narration-continuity-" + canonical_sha(report).split(":")[1][:24]
    for source in report["source_files"]:
        if bytes_sha(_confined(root, source["path"]).read_bytes()) != source["sha256"]:
            raise ValueError("source drift during diagnostic")
    folder = root / DIAGNOSTIC_DIR
    if folder.resolve() != folder:
        raise PermissionError("diagnostic output directory is redirected")
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / (report["diagnostic_id"] + ".json")
    encoded = (json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    if destination.exists():
        if destination.read_bytes() != encoded:
            raise ValueError("immutable diagnostic collision")
    else:
        with destination.open("xb") as output:
            output.write(encoded)
    return {"diagnostic_path": destination.relative_to(root).as_posix(), "sha256": bytes_sha(encoded), "summary": result["summary"], "status": report["status"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Read-only media diagnosis; writes isolated JSON only, never synthesizes.")
    parser.add_argument("--diagnostic", action="store_true", required=True)
    args = parser.parse_args()
    print(json.dumps(diagnose_current_voice(Path.cwd()), indent=2))
