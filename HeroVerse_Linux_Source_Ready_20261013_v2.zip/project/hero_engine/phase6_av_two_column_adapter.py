"""Pure, source-pinned preparation of the twelve FACT/FORECAST states.

The caller (Stage C) must independently recompose A before calling this module.
This adapter verifies its own sources and output, not A's acoustic calibration.
It cannot admit, write or render. A clean-plate receipt can prove the exact
technical source; it never makes a filter specification production-ready.
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from .phase6_av_visual_recipe_adapter import (
    AVVisualRecipeAdapterError, _canonical, _canonical_sha, _json,
    _open_external_binding, _open_pinned_file, _sha, _validate, _workspace_root,
)
from .phase6_two_column_recipe import (
    CHANNEL, VIDEO, build_two_column_plan, inspect_two_column_layout,
)
from .phase6_visual_recipe import _drawtext_filter, _ffmpeg_path, OUTPUT_FILTERS
from .phase6_av_publicity import resolve as _resident_resolve, binding as _resident_binding

ADAPTER_VERSION = "phase6-av-two-column-adapter-v11"
TAKE_IDS = tuple(f"take-{n:03d}" for n in range(12, 24))
UNIT_START_UNITS = {
    "take-012": "narration-unit-010", "take-013": "narration-unit-011",
    "take-015": "narration-unit-012", "take-017": "narration-unit-013",
    "take-018": "narration-unit-014", "take-019": "narration-unit-015",
    "take-020": "narration-unit-016", "take-022": "narration-unit-017",
    "take-023": "narration-unit-018",
}
UNIT_START_TAKES = frozenset(UNIT_START_UNITS)
BINDING_ROLES = frozenset({"take_plan", "style_bible", "font"})
OPTIONAL_BINDING_ROLES = frozenset({"clean_plate_receipt"})
_CLEAN_PLATE_VERIFIER = ("hero_engine/phase6_av_clean_plate.py",
    "6f51a131c11c10f65ef367321729d0d1af4f12507747ee1d1f441eebf45d74a3")
_IMPLEMENTATION = {
    "resident_source_helpers": ("hero_engine/phase6_av_publicity.py",
        "b20ffd38a8f737fffce75e5625c8dbda2f463841665350acf3950874b39fc567"),
    "adapter_helpers": ("hero_engine/phase6_av_visual_recipe_adapter.py",
        "f5b15dce9a46b190783cbcde247f5250d535a825c35a7aaae42b7a7a4ee3e6cb"),
    "two_column_recipe": ("hero_engine/phase6_two_column_recipe.py",
        "bc70f57d347093ba2df38eb90e312913c0ebcf5cab2d3f23312f2ec9906fce73"),
    "visual_recipe": ("hero_engine/phase6_visual_recipe.py",
        "25d5924def60d9e2ad369a8b2b5e417f7cdcea20cfca3eb2fd792041d161355f"),
    "two_column_schema": ("schemas/phase6_two_column_source_plan.schema.json",
        "ede33263b0e3d6ac821789898fd207c1b4563a311213278647de61aa8b2ff086"),
    "take_plan_schema": ("schemas/take_plan.schema.json",
        "8fe58aa812135111918eee49706751496c5e68aed1178cc70b370d38ea7b36f3"),
    "style_bible_schema": ("schemas/visual_continuity_bible.schema.json",
        "5dd8a5ce3963a4c0a99725d1d04469f65ce061e90977e9fcf48dbb87cbfa2f9e"),
    "timeline_implementation": ("hero_engine/phase6_av_timeline.py",
        "a113489a43a26d50f266808fb3bb06d6fa1de6092364c7d7aaedbbcb8bc5f5dd"),
    "timeline_schema": ("schemas/phase6_av_timeline.schema.json",
        "3095b5f5b0daa68341ed565c6457d3eb96fb1cb356459ae3af1ebfaec624decb"),
}
_AUTHORITY = {name: False for name in (
    "production_authorized", "render_authorized", "queue_authorized",
    "release_authorized", "publication_authorized", "human_review_claimed",
)}
_TEMPORAL_BLOCKERS = (
    "TEMPORAL_", "CALIBRATION_", "ALIGNED_", "ACOUSTIC_",
    "SEMANTIC_EVENT_", "VISUAL_EVENTS_", "RENDER_SPAN_", "VISUAL_FRAGMENT_",
)


class AVTwoColumnAdapterError(AVVisualRecipeAdapterError):
    pass


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise AVTwoColumnAdapterError(f"{name}: expected integer >= {minimum}")
    return value


def _index(rows, key):
    if not isinstance(rows, list):
        raise AVTwoColumnAdapterError(f"{key}: expected array")
    result = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get(key), str) or not row[key]:
            raise AVTwoColumnAdapterError(f"{key}: invalid identity")
        if row[key] in result:
            raise AVTwoColumnAdapterError(f"{key}: duplicate identity")
        result[row[key]] = row
    return result


def _load_sources(root, bindings):
    if (not isinstance(bindings, dict) or not BINDING_ROLES <= set(bindings)
            or set(bindings) - BINDING_ROLES - OPTIONAL_BINDING_ROLES):
        raise AVTwoColumnAdapterError("external binding roles differ")
    opened = {role: _open_external_binding(root, role, bindings[role])
              for role in sorted(BINDING_ROLES)}
    dependencies = [(role, opened[role][0]) for role in sorted(opened)]
    schemas = {}
    for role, pin in _IMPLEMENTATION.items():
        binding, raw, _ = _open_pinned_file(root, role, pin)
        dependencies.append((role, binding))
        if role.endswith("_schema"):
            schemas[role] = _json(raw, role)
    implementation_raw = Path(__file__).read_bytes()
    dependencies.append(("two_column_adapter", {
        "path": "hero_engine/phase6_av_two_column_adapter.py",
        "sha256": _sha(implementation_raw), "size_bytes": len(implementation_raw)}))
    take_plan = _json(opened["take_plan"][1], "take plan")
    bible = _json(opened["style_bible"][1], "style bible")
    _validate(schemas["take_plan_schema"], take_plan, "take plan")
    _validate(schemas["style_bible_schema"], bible, "style bible")
    plan = build_two_column_plan(take_plan)
    _validate(schemas["two_column_schema"], plan, "two column plan")
    if bible["style_bible_id"] != plan["style_bible_id"] or bible["channel_id"] != CHANNEL:
        raise AVTwoColumnAdapterError("Style Bible identity differs")
    return plan, opened["font"][2], dependencies


def _timeline_context(timeline, plan):
    if not isinstance(timeline, dict) or timeline.get("channel_id") != CHANNEL or timeline.get("video_id") != VIDEO:
        raise AVTwoColumnAdapterError("timeline channel/video differs")
    clock = timeline.get("clock", {})
    expected_clock = {"sample_rate": 24000, "fps_numerator": 30,
                      "fps_denominator": 1, "samples_per_frame": 800}
    for key, value in expected_clock.items():
        if type(clock.get(key)) is not int or clock[key] != value:
            raise AVTwoColumnAdapterError("timeline frame/sample clock differs")
    total = _integer(timeline.get("duration", {}).get("planned_total_frames"), "duration", 1)
    if timeline.get("status") not in {"BLOCKED_INCOMPLETE", "TIMELINE_VALIDATED_NOT_ADMITTED"}:
        raise AVTwoColumnAdapterError("timeline status differs")
    if not isinstance(timeline.get("timeline_id"), str) or not timeline["timeline_id"]:
        raise AVTwoColumnAdapterError("timeline identity missing")
    units = _index(timeline.get("units"), "unit_id")
    fragments = _index(timeline.get("narration_fragment_map"), "take_id")
    spans = _index(timeline.get("render_spans"), "span_id")
    _index(timeline.get("visual_events"), "event_id")
    if not isinstance(timeline.get("blockers"), list) or any(not isinstance(x, str) for x in timeline["blockers"]):
        raise AVTwoColumnAdapterError("timeline blockers malformed")
    for scene in plan["scenes"]:
        fragment = fragments.get(scene["take_id"], {})
        text = scene["narration"]
        if fragment.get("text") != text or fragment.get("text_sha256") != _sha(text.encode("utf-8")):
            raise AVTwoColumnAdapterError("timeline literal fragment differs")
        unit = units.get(fragment.get("unit_id"), {})
        a = _integer(fragment.get("unit_start_char"), "fragment start")
        b = _integer(fragment.get("unit_end_char"), "fragment end", 1)
        if (a >= b or not isinstance(unit.get("text"), str)
                or unit["text"][a:b] != text or scene["take_id"] not in unit.get("take_ids", [])):
            raise AVTwoColumnAdapterError("timeline fragment/unit binding differs")
        start = _integer(unit.get("pcm_start_sample"), "unit PCM start")
        end = _integer(unit.get("pcm_end_sample_exclusive"), "unit PCM end", 1)
        slot_end = _integer(unit.get("slot_end_sample_exclusive"), "unit slot end", 1)
        if not start < end <= slot_end <= total * 800 or start % 800 or slot_end % 800:
            raise AVTwoColumnAdapterError("timeline unit position is not valid A frame clock")
    context = {"timeline_id": timeline["timeline_id"], "timeline_status": timeline["status"],
        "timeline_sha256": _canonical_sha(timeline), "a_recomposition_performed_here": False,
        "planned_total_frames": total, "clock": expected_clock,
        "render_spans_sha256": _canonical_sha(timeline["render_spans"]),
        "visual_events_sha256": _canonical_sha(timeline["visual_events"])}
    return context, units, fragments, spans


def _event_for_state(state, timeline, units, spans, blockers):
    """Only consume an existing A semantic requirement, never create its time."""
    fragment = state["fragment_binding"]
    take_id = state["take_id"]
    boundaries = [event for event in timeline["visual_events"] if (
        event.get("kind") == "UNIT_BOUNDARY"
        and event.get("unit_id") == fragment["unit_id"]
        and event.get("narrative_function") == state["narrative_rationale"])]
    if boundaries:
        # A unit's sample-zero boundary is not a measured onset of its first word.
        # Only the explicit unit-start states may use it; the two internal reveals
        # retain lexical evidence even if a caller labels them structural.
        if len(boundaries) != 1:
            blockers.append("STATE_UNIT_BOUNDARY_AMBIGUOUS:" + take_id)
            return None
        event = boundaries[0]
        unit = units[fragment["unit_id"]]
        span = spans.get(event.get("span_id"), {})
        if (take_id not in UNIT_START_TAKES or fragment["unit_start_char"] != 0
                or fragment["unit_id"] != UNIT_START_UNITS.get(take_id)
                or unit.get("take_ids", [])[:1] != [take_id]
                or timeline.get("timeline_version") != "phase6-av-timeline-v12"
                or event.get("trigger") != "WHOLE_UNIT_PCM_START"
                or any(event.get(key) is not None for key in (
                    "char_start", "char_end", "alignment_id", "maximum_uncertainty_samples"))
                or type(event.get("frame")) is not int
                or event["frame"] * 800 != unit["pcm_start_sample"]
                or take_id not in span.get("fragment_ids", [])
                or not span.get("start_frame", -1) <= event["frame"] < span.get("end_frame", -1)):
            blockers.append("STATE_UNIT_BOUNDARY_CONTRACT_DIFFERS:" + take_id)
            return None
        # Competing lexical and structural schedules for the same state are
        # ambiguous; do not silently prefer the cheaper evidence class.
        if any(other.get("kind") == "SEMANTIC_CHANGE"
               and other.get("unit_id") == fragment["unit_id"]
               and other.get("narrative_function") == state["narrative_rationale"]
               for other in timeline["visual_events"]):
            blockers.append("STATE_UNIT_BOUNDARY_AMBIGUOUS:" + take_id)
            return None
        return copy.deepcopy(event)
    matches = [event for event in timeline["visual_events"] if (
        event.get("kind") == "SEMANTIC_CHANGE"
        and event.get("narrative_function") == state["narrative_rationale"]
        and event.get("unit_id") == fragment["unit_id"]
        and type(event.get("char_start")) is int
        and type(event.get("char_end")) is int
        and event.get("char_start") == fragment["unit_start_char"]
        and fragment["unit_start_char"] < event["char_end"] <= fragment["unit_end_char"]
        and event.get("trigger") == "NOT_BEFORE_ANCHOR_START")]
    if len(matches) != 1:
        blockers.append("STATE_SEMANTIC_EVENT_MISSING_OR_AMBIGUOUS:" + take_id)
        return None
    event = matches[0]
    frame = _integer(event.get("frame"), "event frame")
    span = spans.get(event.get("span_id"), {})
    unit = units[fragment["unit_id"]]
    if (take_id not in span.get("fragment_ids", [])
            or not span.get("start_frame", -1) <= frame < span.get("end_frame", -1)
            or not unit["pcm_start_sample"] <= frame * 800 < unit["pcm_end_sample_exclusive"]):
        blockers.append("STATE_EVENT_SPAN_OR_PCM_POSITION_DIFFERS:" + take_id)
        return None
    assessment = timeline.get("temporal_evidence_assessment", {})
    alignment = event.get("alignment_id")
    if (not isinstance(alignment, str) or not alignment
            or alignment not in assessment.get("validated_alignment_ids", [])
            or assessment.get("scope_complete") is not True
            or assessment.get("all_required_evidence_live") is not True
            or assessment.get("fixture_evidence_present") is not False
            or assessment.get("evidence_classes") != ["LIVE"]
            or any(x.startswith(_TEMPORAL_BLOCKERS) for x in timeline["blockers"])):
        blockers.append("STATE_TEMPORAL_EVIDENCE_NOT_LIVE_VALIDATED:" + take_id)
        return None
    return copy.deepcopy(event)


def _resolve_intervals(states, timeline, units, spans, blockers):
    for state in states:
        if state["take_id"] != "take-021":
            state["event_binding"] = _event_for_state(state, timeline, units, spans, blockers)
    # The continuation changes no pixels. A must nevertheless record its intent;
    # its observed HOLD frame is not used as a fabricated word boundary.
    hold = states[9]
    holds = [event for event in timeline["visual_events"] if (
        event.get("kind") == "HOLD"
        and event.get("trigger") == "NO_SPEECH_DEPENDENCY"
        and event.get("narrative_function") == hold["narrative_rationale"]
        and {"take-020", "take-021"}.issubset(
            set(spans.get(event.get("span_id"), {}).get("fragment_ids", []))))]
    if len(holds) == 1:
        event = holds[0]
        frame = _integer(event.get("frame"), "continuation frame")
        unit = units[hold["fragment_binding"]["unit_id"]]
        span = spans[event["span_id"]]
        if (unit["pcm_start_sample"] <= frame * 800 < unit["slot_end_sample_exclusive"]
                and span["start_frame"] <= frame < span["end_frame"]
                and event.get("alignment_id") is None
                and all(event.get(k) is None for k in (
                    "unit_id", "char_start", "char_end", "maximum_uncertainty_samples"))):
            hold["event_binding"] = copy.deepcopy(event)
            hold["continuation_of"] = "take-020"
    if hold["event_binding"] is None:
        blockers.append("UNCHANGED_CONTINUATION_INTENT_MISSING:take-021")
    distinct = [state for state in states if state["take_id"] != "take-021"]
    for index, state in enumerate(distinct):
        event = state["event_binding"]
        next_event = distinct[index + 1]["event_binding"] if index + 1 < len(distinct) else None
        if event is None or (index + 1 < len(distinct) and next_event is None):
            continue
        end = (next_event["frame"] if next_event else
               units[state["fragment_binding"]["unit_id"]]["slot_end_sample_exclusive"] // 800)
        if event["frame"] >= end:
            blockers.append("STATE_EVENT_ORDER_INVALID:" + state["take_id"])
            continue
        state["interval"] = {"start_frame": event["frame"], "end_frame": end}
    if hold["continuation_of"] is not None and states[8]["interval"] is not None:
        interval = states[8]["interval"]
        previous_event = states[8]["event_binding"]
        hold_span = spans[hold["event_binding"]["span_id"]]
        if (previous_event["span_id"] != hold["event_binding"]["span_id"]
                or not hold_span["start_frame"] <= interval["start_frame"] < interval["end_frame"] <= hold_span["end_frame"]
                or not interval["start_frame"] <= hold["event_binding"]["frame"] < interval["end_frame"]):
            blockers.append("UNCHANGED_CONTINUATION_SOURCE_NOT_CONTINUOUS:take-021")
            hold["continuation_of"] = None
            hold["event_binding"] = None
        else:
            hold["interval"] = copy.deepcopy(interval)


def _source_pin(root, span):
    binding = span.get("asset_binding")
    if not isinstance(binding, dict) or set(binding) != {"path", "sha256"}:
        raise AVTwoColumnAdapterError("span asset binding differs")
    path = _resident_resolve(root, binding["path"], confined=True)
    measured = _resident_binding(path)
    if measured["size_bytes"] < 1 or measured["sha256"] != binding["sha256"]:
        raise AVTwoColumnAdapterError("span asset bytes changed")
    return {"path": path.relative_to(root).as_posix(), "sha256": measured["sha256"],
            "size_bytes": measured["size_bytes"]}


def _frame_filters(root, state, start, end, font):
    enable = f":enable='gte(n,{start})*lt(n,{end})'"
    filters = [item + enable for item in state["layout"]["decorations"]]
    for overlay in state["layout"]["overlays"]:
        relative = f"meta/visual/two-column/{state['take_id']}/{overlay['filename']}"
        absolute = root / relative
        text_filter = _drawtext_filter(font, absolute, overlay)
        token = f"textfile='{_ffmpeg_path(absolute)}'"
        if text_filter.count(token) != 1:
            raise AVTwoColumnAdapterError("drawtext path substitution is not unique")
        filters.append(text_filter.replace(token, f"textfile='{relative}'") + enable)
    return filters


def _span_specs(root, states, spans, font, blockers, clean_plate=None):
    if any(state["interval"] is None for state in states):
        return []
    distinct = [state for state in states if state["continuation_of"] is None]
    selected = []
    cursor = distinct[0]["interval"]["start_frame"]
    final = distinct[-1]["interval"]["end_frame"]
    for span in sorted(spans.values(), key=lambda item: item["start_frame"]):
        start, end = _integer(span["start_frame"], "span start"), _integer(span["end_frame"], "span end", 1)
        left, right = max(start, cursor), min(end, final)
        if left >= right:
            continue
        if start != cursor or end > final:
            blockers.append("TWO_COLUMN_SPAN_EXTENDS_OUTSIDE_PREPARED_INTERVAL")
            return []
        if left != cursor:
            blockers.append("TWO_COLUMN_RENDER_SPAN_COVERAGE_INCOMPLETE")
            return []
        filters = []
        for state in distinct:
            a, b = max(left, state["interval"]["start_frame"]), min(right, state["interval"]["end_frame"])
            if a < b:
                if state["take_id"] not in span.get("fragment_ids", []):
                    blockers.append("TWO_COLUMN_SPAN_FRAGMENT_MISMATCH:" + state["take_id"])
                    return []
                filters.extend(_frame_filters(root, state, a - start, b - start, font))
        source_start = _integer(span.get("source_start_frame"), "source start")
        source_end = _integer(span.get("source_end_frame"), "source end", 1)
        count = _integer(span.get("source_frame_count"), "source frame count", 1)
        if source_end - source_start != end - start or source_end > count:
            raise AVTwoColumnAdapterError("span source interval differs")
        if not isinstance(span.get("lineage_id"), str) or not span["lineage_id"]:
            raise AVTwoColumnAdapterError("span lineage missing")
        source_binding = _source_pin(root, span)
        if clean_plate is not None and (
                _canonical(source_binding) != _canonical(clean_plate["asset_binding"])
                or span["lineage_id"] != clean_plate["lineage_id"]
                or count != clean_plate["capacity"]["frame_count"]):
            raise AVTwoColumnAdapterError("span differs from verified clean-plate source/lineage/capacity")
        filters.extend(OUTPUT_FILTERS)
        if any(item.split("=", 1)[0] not in {"drawbox", "drawtext", "format", "setparams"} for item in filters):
            raise AVTwoColumnAdapterError("filter outside allowlist")
        selected.append({"span_id": span["span_id"], "asset_binding": source_binding,
            "lineage_id": span["lineage_id"], "source_frame_count": count,
            "source_start_frame": source_start, "source_end_frame": source_end,
            "start_frame": start, "end_frame": end, "frame_clock": "SPAN_LOCAL_ZERO_BASED",
            "filtergraph": ",".join(filters),
            "source_technically_verified": clean_plate is not None,
            "source_evidence_binding": copy.deepcopy(clean_plate["receipt_binding"]) if clean_plate is not None else None,
            "source_ready": False, "render_authorized": False})
        cursor = right
    if cursor != final:
        blockers.append("TWO_COLUMN_RENDER_SPAN_COVERAGE_INCOMPLETE")
        return []
    return selected


def _clean_plate_proof(root, bindings, plan, dependencies):
    if "clean_plate_receipt" not in bindings:
        return None
    verifier_binding, _, _ = _open_pinned_file(root, "clean_plate_verifier", _CLEAN_PLATE_VERIFIER)
    from .phase6_av_clean_plate import verify_clean_plate
    proof = verify_clean_plate(root, bindings["clean_plate_receipt"])
    existing = dict(dependencies)
    if (proof["status"] != "SOURCE_TECHNICALLY_VERIFIED_NOT_ADMITTED"
            or proof["channel_id"] != CHANNEL or proof["style_bible_id"] != plan["style_bible_id"]
            or _canonical(proof["source_take_plan_binding"]) != _canonical(existing["take_plan"])
            or not any(_canonical(pin) == _canonical(existing["style_bible"])
                       for pin in proof["dependency_bindings"])
            or not any(_canonical(pin) == _canonical(verifier_binding)
                       for pin in proof["dependency_bindings"])
            or any(proof["authority"].values()) or proof["technical_cost_brl"] != 0):
        raise AVTwoColumnAdapterError("clean-plate source identity/authority differs from body recipe")
    by_path = {pin["path"]: pin for pin in proof["dependency_bindings"]}
    if len(by_path) != len(proof["dependency_bindings"]):
        raise AVTwoColumnAdapterError("clean-plate dependency path duplicated")
    for role in proof["dependency_roles"]:
        pin = by_path.get(role["path"])
        if pin is None or pin["sha256"] != role["sha256"]:
            raise AVTwoColumnAdapterError("clean-plate dependency role differs")
        dependencies.append(("clean_plate:" + role["role"], copy.deepcopy(pin)))
    return proof


def compile_two_column_av_spec(root: Path, *, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Return measured layouts and, only with compatible A events, filter specs."""
    if (timeline.get("visual_amendment_evidence") is not None
            or timeline.get("question_case_amendment_evidence") is not None
            or timeline.get("body_case_amendment_evidence") is not None):
        raise AVTwoColumnAdapterError("compact, question or body case amendment cannot use the historical two-column renderer")
    root = _workspace_root(root)
    plan, font, dependencies = _load_sources(root, bindings)
    clean_plate = _clean_plate_proof(root, bindings, plan, dependencies)
    context, units, fragments, spans = _timeline_context(timeline, plan)
    blockers = ["STAGE_A_INDEPENDENT_RECOMPOSITION_AND_ADMISSION_REQUIRED",
        "TWELVE_STATES_ONLY_FULL_TIMELINE_COVERAGE_INCOMPLETE",
        "LAYOUT_MEASUREMENT_IS_NOT_RENDERED_LEGIBILITY_OR_NARRATIVE_APPROVAL",
        "QUEUE_COMMIT_AND_GENERATION_NAMESPACE_REQUIRED_BEFORE_MATERIALIZATION"]
    blockers.append("TWO_COLUMN_CLEAN_PLATE_NOT_BOUND" if clean_plate is None
                    else "TWO_COLUMN_CLEAN_PLATE_BOUND_NOT_ADMITTED")
    if timeline["status"] != "TIMELINE_VALIDATED_NOT_ADMITTED":
        blockers.append("STAGE_A_TIMELINE_INCOMPLETE")
    states, files = [], []
    for scene in plan["scenes"]:
        # Historical times serve the frozen layout helper's positive-duration
        # precondition only. They are never serialized or used for an AV event.
        layout = inspect_two_column_layout(scene, font=font)
        state = {key: copy.deepcopy(scene[key]) for key in (
            "take_id", "narration", "focus", "left_text", "right_text", "example", "narrative_rationale")}
        state.update(fragment_binding=copy.deepcopy(fragments[scene["take_id"]]),
                     layout=layout, interval=None, event_binding=None, continuation_of=None)
        states.append(state)
        for overlay in layout["overlays"]:
            raw = overlay["render_text"].encode("utf-8")
            files.append({"role": f"{scene['take_id']}:{overlay['role']}",
                "relative_path": f"meta/visual/two-column/{scene['take_id']}/{overlay['filename']}",
                "sha256": _sha(raw), "size_bytes": len(raw), "content_utf8": overlay["render_text"]})
    _resolve_intervals(states, timeline, units, spans, blockers)
    render_spans = _span_specs(root, states, spans, font, blockers, clean_plate)
    for span in render_spans:
        dependencies.append(("span_asset:" + span["span_id"], span["asset_binding"]))
    distinct = [state for state in states if state["continuation_of"] is None]
    covered = (sum(state["interval"]["end_frame"] - state["interval"]["start_frame"]
                   for state in distinct) if render_spans else 0)
    result = {"schema_version": "1.1.0", "adapter_version": ADAPTER_VERSION,
        "status": "COMPILED_TWO_COLUMN_SPEC_NOT_ADMITTED" if render_spans else "PREPARED_TWO_COLUMN_SPEC_BLOCKED",
        "scope": "TAKES012_023_FACT_FORECAST_ONLY", "channel_id": CHANNEL, "video_id": VIDEO,
        "recipe_id": plan["recipe_id"], "plan_id": plan["plan_id"], "timeline_contract": context,
        "states": states, "generated_files": files, "render_spans": render_spans,
        "clean_plate": copy.deepcopy(clean_plate),
        "coverage": {"state_count": 12, "resolved_state_count": sum(state["interval"] is not None for state in states),
            "compiled_span_count": len(render_spans), "covered_frame_count": covered, "full_timeline_covered": False},
        "dependency_bindings": [copy.deepcopy(pin) for _, pin in sorted(dependencies)],
        "dependency_roles": [{"role": role, "path": pin["path"], "sha256": pin["sha256"]}
                             for role, pin in sorted(dependencies)],
        "blockers": sorted(set(blockers)), "authority": copy.deepcopy(_AUTHORITY), "technical_cost_brl": 0}
    result["visual_spec_id"] = "phase6-av-two-column-spec-" + _canonical_sha(result)[7:31]
    result["canonical_sha256"] = _canonical_sha(result)
    return result


def verify_two_column_av_spec(root: Path, candidate: dict[str, Any], *, timeline: dict[str, Any], bindings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Reopen sources and recompile; candidate flags/hashes are not evidence."""
    expected = compile_two_column_av_spec(root, timeline=timeline, bindings=bindings)
    if _canonical(candidate) != _canonical(expected):
        raise AVTwoColumnAdapterError("two column spec differs from pure recompilation")
    return copy.deepcopy(expected)
