# Estado real do projeto YouTube

Relatório de transferência e retomada — 08/09/2026.

**Cortes:** operação anterior à pausa observada às 14:47:23 UTC; **pausa total reconfirmada às 18:26:40 UTC / 15:26:40 BRT**, em 08/09/2026. Métricas e provas anteriores mantêm seus próprios horários. Não se presume que um snapshot permaneça atual.

Projeto: [Modelagem Youtube](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube>).

## Síntese executiva

Existem **nove fases, numeradas de 0 a 8**. As fases 0–5 têm evidências de conclusão em seus escopos históricos. A **Fase 6 — Canal-piloto está parcial e bloqueada para conclusão**. As fases 7 e 8 não foram iniciadas por transição comprovada.

Há **uma publicação pública comprovada pelo projeto**. O Vídeo 2 foi renderizado, mas rejeitado; não está aprovado nem publicado. Existe coordenação, persistência, testes e observação real, mas ainda não uma cadeia completa de melhoria de audiência aplicada e validada. O produto comercial completo não está concluído.

**Estado operacional atual: PAUSADO por solicitação expressa do proprietário.** O marcador PAUSE existe, a tarefa Windows está Disabled/Enabled=false, a rotina Codex está PAUSED e nenhum processo do Gestor foi encontrado na reconfirmação. Este pedido de relatório não autorizou retomada.

**Bloqueio técnico anterior à pausa:** request de manutenção aparentemente sem solicitante continha o Gestor antes de OAuth e dos estágios. A pausa não corrigiu nem apagou esse incidente. Para a conclusão produtiva, permanece também a admissão audiovisual incompleta do Vídeo 2.

Esta rodada é exclusivamente documental: nenhuma correção, teste, pesquisa de mercado, publicação, síntese, render, instalação ou mudança de instruções/agendamentos foi executada. A única gravação feita nesta rodada é a conclusão deste relatório, aproveitando o rascunho anterior. A pausa foi executada no turno anterior, sob ordem própria; a manutenção das 12:58 começou antes do pedido original de relatório e não foi retomada aqui.

### Convenções de evidência

- PEDIDO não significa PLANEJADO; PLANEJADO não significa IMPLEMENTADO.
- EXECUTADO não significa VALIDADO. Fixture, controle operacional, render e publicação são provas diferentes.
- PASS histórico cobre sua versão e seu escopo, não alterações posteriores.
- D-xxx refere-se a decisões em [DECISIONS.md](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/DECISIONS.md>), não a commits Git.
- Referências S01–S26 são fontes indexadas na seção 8. Horários são UTC, salvo indicação.
- Ausência de registro não prova ausência de erro. Contagens/causas não recuperadas são explicitamente desconhecidas.

## 1. Objetivo e planejamento original

### 1.1 Objetivo aprovado

Analisar o canal existente, minerar referências do mesmo nicho/idioma, modelar estruturas com evidência de desempenho e produzir vídeos editorialmente novos, integrando tema, roteiro, takes, voz, montagem, revisão, publicação, coleta e aprendizagem.

O escopo foi ampliado pelo proprietário para Gestor Central Autônomo, Diretor Criativo subordinado, FormatPacks versionados, consistência audiovisual, gates impeditivos, memória persistente, previsibilidade mensurável, operação supervisionada e futura comercialização multiusuário.

A meta é monetização em 30 dias. **É meta aprovada, não resultado garantido ou probabilidade já demonstrada.** O projeto não possui evidência de que todo cliente futuro consiga monetizar nesse prazo.

O uso inicial de takes públicos recebeu limites permanentes: acesso público não concede licença de reutilização, música, voz, imagem pessoal ou marcas. Benchmark de uma referência não libera seus ativos para produção.

### 1.2 Canal, idioma, formato e frequência

| Campo | Estado aprovado/observado |
|---|---|
| Canal | HeroVerse, @heroverse74; UCuMF6pJQkyMzaVoAxFL86yA. |
| Idioma | Inglês, en-US; fuso operacional America/Sao_Paulo. |
| Nicho efetivamente modelado | Fé/espiritualidade cristã: oração, ação após a oração, chamado, discernimento, proteção, preparação e divine timing. Não é inferido como super-heróis pelo nome HeroVerse. |
| Direção editorial | Segunda pessoa, promessa compreensível, progressão e resolução; identidade própria. Não copiar voz/música/marca/frase distintiva das referências. |
| Formato produtivo comprovado | Longo em inglês, B-roll/recortes licenciados, composição própria e narração local, perfil STANDARD, Pack limitado. |
| Longos | Configuração geral 3,5–4,5 minutos; experimento do Vídeo 2: 207.750–286.250 ms, mínimo operacional de 207.800 ms na grade de 30 fps. |
| Shorts | Configuração 32–48 s e mineração de metadados. Sem Short publicado pelo projeto ou arquétipo profundo equivalente comprovado neste levantamento. |
| Cadência atual | CONTROLLED_SEQUENTIAL_LOT: longos/dia e Shorts/dia nulos, sem horários fixos; até três longos no lote da Fase 6 e zero Shorts pré-comprometidos. |
| Liberação seguinte | Checkpoint próprio anterior, experimento de variável única e todos os gates críticos. |
| Segundo canal | Previsto na Fase 7; não operado de ponta a ponta com prova recuperada. |

Fonte: S06. Pesos temáticos configurados são planejamento, não preferências de audiência medidas. A cadência controlada substituiu a expectativa inicial de alto volume fixo; observação diária não significa postagem diária.

### 1.3 Meta e janela

Primeira publicação: **04/09/2026 18:45:51 UTC / 15:45:51 BRT**. Deadline: **04/10/2026 18:45:51 UTC / 15:45:51 BRT**. O início da construção não é o início do experimento.

Rota configurada: 1.000 inscritos e 4.000 horas públicas qualificadas. Horas qualificadas atuais e RPM próprio permanecem sem fonte válida no projeto. Minutos do Analytics e métricas de campanha não podem substituir progresso YPP.

### 1.4 Custo e autonomia

**CUSTO TÉCNICO OBRIGATÓRIO: R$ 0,00 de custo adicional autorizado.**

Permitidos: ferramentas/bibliotecas gratuitas, local, infraestrutura existente e APIs oficiais gratuitas. Proibidos: cobrança, cartão, servidor/domínio pago, trial com cobrança automática e dependência obrigatória de assinatura futura.

Promote/Ads depende de orçamento expresso futuro, ainda não comprovado. Autonomia histórica inclui execução e publicação dentro do envelope, mas não elimina direitos, autenticação, identidade, calibração ou gates. Revisão administrativa por postagem foi retirada; padrão-ouro humano/amostras/exceções não podem ser fabricados por uma IA.

O pedido mais recente restringe esta rodada ao relatório e prevalece sobre autorizações históricas de implementar.

### 1.5 Ferramentas e alternativas

Python, SQLite, JSON Schema, FFmpeg/FFprobe, yt-dlp, faster-whisper/Whisper local, Kokoro ONNX, RapidOCR, OpenCV, Pillow e ONNX Runtime têm uso técnico registrado. APIs YouTube/Google foram usadas em publicação, identidade e métricas reais. Fontes próprias e bancos com direitos documentados integram o pipeline.

vidIQ é auxiliar gratuito, não prova de receita/RPM de terceiros nem dependência da coleta própria. n8n, Tesseract e outras opções mencionadas não são considerados instalados ou produtivos pela mera menção.

DNSMOS local fornece qualidade auxiliar, não pronúncia/aprovação perceptual. Pesos NISQA com restrição não comercial foram rejeitados para dependência produtiva comercial. Geradores/APIs pagos não são alternativa autorizada.

Foram restringidos ou descartados: receita única para todos os estilos, direito presumido por vídeo público, score tratado como probabilidade viral, campanha tratada como progresso YPP, novo upload para retomar um ID já criado e repetição indiscriminada de mídia íntegra.

### 1.6 As nove fases e critérios originais

Fonte integral de nomes/critérios: S05. Não houve redesenho neste relatório.

| Fase | Nome e critério de conclusão | Estado e evidência |
|---|---|---|
| 0 | Auditoria e incorporação do contrato: inventário, lacunas, conflitos, stack, riscos, preservação, plano/estado. | **Concluída no escopo histórico**, 02/09, D-011/S07; backup e incorporação preservando legado. |
| 1 | Padrão-ouro de mineração: amostra real, anotações, evidências, JSON, fixtures congeladas e aceitas. | **Concluída historicamente**, D-021/S08: quatro vídeos, 256 takes, 25 blocos narrativos, 16 hooks, 21 testes. Identidade pessoal de todos os anotadores não revalidada. |
| 2 | Minerador automático: reprodução do padrão, divergências explícitas, idempotência, custo/tempo/erros. | **Concluída no benchmark após correção**, 0.2/D-025/S09: 38 testes e quatro replays. Generalização continua não demonstrada. |
| 3 | Mineração em lote e observatório: catálogo, snapshots, coortes, cobertura/normalização e erros de aquisição. | **Concluída no lote delimitado**, v2/D-028/S10: sete canais, 123 vídeos, 130 snapshots, 49 testes. Não prova coleta perpétua de mercado. |
| 4 | Modelador: DNA, arquétipos, invariantes/variáveis, evidência/holdout/backtest e geração sem cópia. | **Concluída tecnicamente para piloto condicionado**, D-032/S11; confiança 0,408248, sem validação profunda cruzada ou RPM. |
| 5 | Produtor clip-based: fontes/direitos, narrativa/takes, render, QA, custo e Pack admitido. | **Concluída no escopo limitado do primeiro piloto**, D-077/S12–S13. Não valida o Vídeo 2 ou todos os formatos. |
| 6 | Canal-piloto: lote, publicação, métricas, experimento/aprendizado, custo/capacidade e estabilidade comprovados. | **Parcial e bloqueada para concluir**. Vídeo 2 sem admissão; aceite atual recuperado com GC01/07/20/22; transição sem receipt. |
| 7 | Aprendizado e segundo canal: atualização, aplicação futura/segunda medição, comparação, isolamento e generalização. | **Não iniciada por transição comprovada**. GC13/14/15/17 são requisitos posteriores, não devem ser antecipados artificialmente. |
| 8 | Produto: operação interna validada, onboarding, permissões, isolamento, segurança, suporte, licenças e viabilidade. | **Não iniciada como fase executada**. Contratos preparatórios não equivalem a produto comercial completo. |

Não se calcula percentual global por fases, arquivos ou testes: os esforços e os critérios não são equivalentes.

## 2. Histórico do início até agora

| Data / referência | Implementação, resultado e limite |
|---|---|
| Antes de 02/09; datas exatas não recuperadas | Pedidos de mineração/modelagem, 30 dias, custo zero, autonomia e produto. Protótipo anterior ao kit existente; histórico completo desse período indisponível. |
| 02/09, D-010–011 | Auditoria e incorporação. Backup externo 135.857.485 B, SHA registrado. README antigo preservado, kit separado. Sem Git local, portanto sem cadeia de commits equivalente. |
| 02/09, D-021 | Gold: hkf6nDyUfAM, _sOy7htXJi8, Pkede5acSFw e huvUy3pJSp8; quatro longos em inglês, cerca de 210–284 s. Anotações/testes reais; direitos produtivos das referências não liberados. |
| 02/09, D-023–025 | Minerador inicial executou, mas falhou em OCR/narrativa/packaging. KEEP_CHAMPION, reabertura e 0.2. Melhoria medida no conjunto de desenvolvimento, não generalização. |
| 02/09, D-028–029 | v1 de catálogo perdeu Shorts; v2 corrigiu rotas: 126 COMPLETE e quatro PARTIAL em 130 snapshots. V1 preservado. |
| 02/09, D-032 | Modelo heroverse-channel-model-v1 / A-LONG-DIRECT-SPIRITUAL-STAKES-V1; 24 itens, 16 aberturas, 13 holdouts, quatro narrativas completas, 60 testes. Aprovação condicionada. |
| 02–03/09, D-034–061 | Diretor Criativo/Packs e revisões v2.1/v3. Rejeição por repetição, semântica e freeze; v3.2 corrigiu escopo delimitado. |
| 03–04/09, D-052–076 | Integração Google/YouTube: contas, escopos, permissões, site de conformidade, quota, token e console. Várias correções e regressões próprias; não apenas uma autorização faltante. |
| 04/09 18:45:51, D-077 | Piloto iK_5edYQtx8 público, após staging, thumbnail, captions e processamento. Início dos 30 dias. |
| 04–05/09, D-078–122 | Métricas/Reporting, Windows/OneDrive, lock, UTC, fila, retry, quotas, experimento imutável, ciclo 12 estágios, trajetória e manutenção/recuperação. |
| 05/09, D1/D-096 | Contagem exata <30 permitiu apenas DISTRIBUTION_SAMPLE → TOPIC_ANGLE, LOW. Pré-registro e pré-produção do Vídeo 2; sem atribuir causalidade ao hook. |
| 05–06/09, D-124–149 | Voz/render do Vídeo 2; inspeção encontrou None e incoerência de framework visual. Job concluído, vídeo rejeitado. Correção de um frame não aprovou o conjunto. |
| 06/09, D-142–148 | Manutenções falharam em guard, fixtures, integração de trajetória, parser de skip e PowerShell. Testes aprovados sem fechamento válido não contaram como instalação. |
| 06–07/09, D-150–170 | Reuso contra retrabalho, tracking/OCR/voz, composição por unidades, áudio, supervisão de processos, fallbacks. QR Dolar declarado pausado; uma operação planejada não cria novos créditos. |
| 07–08/09, D-171 | Evolução A–D/A7–A12, captions literais, rasters/direitos próprios. Receipts comprovam cada escopo, não tempo/movimento/publicação. Versões anteriores preservadas. |
| 08/09 01:28 / 04:17 / 07:04 | Instalações A10/A11/A12 com provas próprias. Última integral: 1.780 PASS + um skip, 180 schemas, 554 itens e D116/12 estágios. |
| 08/09 após 07:04 | Contraprova: linhagem four-criteria potencialmente 40,832 s >10%. Mais cartelas dessa linhagem suspensas; Pexels/OpenImages apenas candidatos/triagem. |
| 08/09 09–10:45 | Perfil PUBLICITY, decodes, duas inferências de controle e recuperação do agregador. Reuso sem reinferência; controles não são calibração. |
| 08/09 11:40:58 → 12:38:39 | REFRESH_FAILED; causa original não preservada suficientemente. Mesmo grant recuperado e canal confirmado, uma unidade de quota. Sem novo consentimento. |
| 08/09 12:56–12:57 | Saída cooperativa do watcher antigo; ciclo real PASS_ADVANCED 12/12. Patch não bloqueante com 11 focais, ainda sem instalação/D116 próprios. |
| 08/09 12:58 → corte 14:47 | Manutenção iniciada antes do pedido de relatório. Somente preview encontrado; solicitante ausente, Gestor vivo, ACK renovado. Motivo do término/ausência de cleanup desconhecido. |
| 08/09, origem de processo 15:11:39, observada posteriormente | Antes da pausa, a cadeia passou a PIDs 15104/15244, com ACK da mesma manutenção. Causa dessa troca não determinada; não é evidência de instalação nova aprovada. |
| 08/09, turno anterior / reconfirmação 18:26:40 | Proprietário mandou pausar tudo. Marcador PAUSE, tarefa Windows desabilitada, rotina Codex PAUSED e processos encerrados. Relatório interrompido com apenas seções 1–2 gravadas. Pedido atual autoriza somente terminá-lo. |

### Retrabalho e decisões reabertas

As fases de mineração foram refeitas por insuficiência medida e rota incompleta; a composição criativa foi reaberta depois de aprovação técnica insuficiente. Schemas/contratos evoluíram sem todos os consumidores/fixtures acompanharem, provocando novas integrações. Instrumentos de relógio/OCR/origem também produziram falsos negativos.

O render rejeitado demonstra por que “job SUCCEEDED” não é “vídeo bom”. A sucessão de pequenas emendas produziu custo adicional de integração/manutenção. Há evidência de repetição, mas **não medição agregada de horas ou créditos desperdiçados**, nem prova de uma causa única para toda a demora. O catálogo detalha cada ocorrência recuperada.

## 3. O que existe e funciona hoje

“Funciona” abaixo significa última execução comprovada, **não execução corrente: a operação está pausada**. Código existente não herda automaticamente integração/teste do antecessor.

### 3.1 Mapa real de ponta a ponta

| Etapa / arquivo, função ou rotina | Entrada → saída; dependências | Prova, estado e última execução conhecida | Necessidade humana/externa |
|---|---|---|---|
| Mineração — [mining/pipeline.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/mining/pipeline.py>), adapters/semantics do mesmo pacote; CLI mine-fixtures/mine-video | Vídeos/metadados/fixtures → takes, transcrição, OCR, narrativa/JSON. FFmpeg, modelos locais, fonte acessível e schema. | Benchmark 0.2 de 02/09; quatro replays e 38 testes. Integrado nesse conjunto, generalização não demonstrada; S08–S09. | Anotação/calibração externa ao gerador para comprovar generalização. Não exige escolha manual a cada execução. |
| Observatório — [observatory/phase3.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/observatory/phase3.py>), collectors/store | Rotas públicas → catálogo, snapshots, coortes/SQLite. Rede e fontes públicas. | v2 de 02/09: sete canais, 123 vídeos, 130 snapshots; 49 testes, SQLite íntegro. Não comprovada renovação diária integral até hoje; S10. | Acesso legítimo e tratamento de fontes ausentes. |
| Seleção — [phase6_production.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_production.py>) / phase6_intelligence | Mercado + diagnóstico/protocolo → candidato e TreatmentOrder presos por hashes. | Política score-first, piso 0,65, peso observado ≥0,95, idade ≤168 h; contratos/testes e ordem real. Último ciclo 12:57 de 08/09; não revalidada atualidade de mercado nesta rodada. | Não depende de aprovação administrativa de tema; falta de evidência bloqueia. |
| Modelação — [modeling_phase4.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/modeling_phase4.py>) | Coortes/evidência → ChannelDNA, arquétipo/GenerationSpec. | Modelo v1 aprovado condicionalmente em 02/09; confiança 0,408248; 60 testes. S11. | Ainda precisa de dados novos para generalização/RPM, não de aprovação genérica. |
| Direção/roteiro — [creative_direction.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/creative_direction.py>) e [phase6_creative_compiler.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_creative_compiler.py>) | DNA + Pack + ordem → alternativas/red-team, decisão, roteiro e TakePlan. | Compilador v2 com ≥6 rotas, ≥3 elegíveis, cinco eixos e recomputação independente. Pré-produção real do Vídeo 2; audiovisual ainda rejeitado. S04/D-101–104. | Avaliação independente necessária; score não substitui evidência de audiência. |
| Fontes/direitos — [phase6_assets.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_assets.py>), phase6_asset_residency e phase6_body_asset_rights | Ativos + direitos + intenção → biblioteca residente/vínculos. | Biblioteca real e registros OWNED; A12 de 08/09 parcial. Aquisição e direito de raster não aprovam PUBLICITY/timing/vídeo. S21/S24. | Documento de direito aplicável quando ausente; não basta autorização geral do dono do canal. |
| Voz — [voice_phase5.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/voice_phase5.py>) e phase6_narration_units | Roteiro/unidades + Kokoro → WAVs/master. | Piloto executado; master do Vídeo 2 202,780 s, medido e normalizado. Ainda inferior ao mínimo 207,800 s e sem aprovação AV final. S22. | Calibração/percepção não pode ser declarada humana por IA. Escuta rotineira não foi transferida ao proprietário. |
| Plano AV — [phase6_av_timeline.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_av_timeline.py>), phase6_av_admission / visual_recipe_adapter | Fontes, intenções, captions/clocks/calibração → A e consumidores posteriores. | A12 real, BLOCKED_INCOMPLETE: 100 estados, 51 unidades, 90 fragmentos, 71 captions, união26; zero scheduling. B/C/D não fechados. S21/S23. | Referência temporal aplicável está faltando; não é aprovação administrativa faltante. |
| Montagem — [phase6_media.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_media.py>) / phase6_render_contract | Takes/fontes/áudio + autoridade de fila → MP4/manifesto/receipt. | Piloto aprovado; job c516db5685acbbb423199bc1 SUCCEEDED no renderer, Vídeo 2 rejeitado. Último estado conhecido MEDIA_WAIT/remediação; S23. | Sem montagem manual obrigatória, mas sucessor precisa estar realmente integrado. |
| Revisão — [phase6_quality.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_quality.py>), run_phase6_quality_executor/build_phase6_quality_evaluation; phase6_publicity | Artefato exato + contratos → PASS/FAIL/BLOCKED/NEEDS_REVIEW com evidência. | Gates impediram publicação da mídia rejeitada; vários testes focais. Dois controles YuNet não calibram domínio; S23/S24. | Padrão-ouro humano/amostra/exceções continuam distintos do gate automático por vídeo. |
| Canal/release — [phase6_release.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_release.py>) / [phase6_publication.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_publication.py>) | Readiness/identidade, mídia/direitos/gates → pacote/liberação. | refresh_channel_readiness, build_phase6_publication_package e build_phase6_release_gate existentes/testados. Prontidão exercida no piloto; melhoria contínua de capa/descrição com efeito medido não comprovada. | Acesso ao canal e direitos; sem pedido administrativo repetido para título/thumbnail dentro do escopo. |
| Publicação — [phase5_youtube_publisher.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase5_youtube_publisher.py>) e controlador Fase6 | Pacote aprovado + OAuth/cota → staging privado, processamento, thumbnail/captions, público/verificação. | Uma publicação real em 04/09; S13. Vídeo 2 sem receipt público. | Desafio pessoal de autenticação, se Google efetivamente exigir; não é rotina comprovadamente necessária a cada upload. |
| Métricas — [phase6_reporting.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_reporting.py>) / phase6_channel_goal_observer | APIs próprias + preflight → snapshots/reach/trajetória. | Último snapshot consultado 07/09 20:56:53; leitura real. Reach sem linha correspondente, null preservado. S14. | Rede/grant/quota e maturação dos dados. |
| Aprendizado — [phase6_learning_runtime.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/phase6_learning_runtime.py>) / phase6_prediction_runtime | Baseline/protocolo/aplicação/tratamento → avaliação imutável. | WAITING_FOR_TREATMENT_PUBLICATION; forecast WITHHELD_INSUFFICIENT_CALIBRATION. Memória real, cadeia de melhoria de audiência ainda incompleta. S15. | Depende de tratamento publicado e tempo de observação; sem inventar avaliação. |
| Coordenação — [central_manager_phase5.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/central_manager_phase5.py>), phase6_control_cycle / phase6_transition | Fila/receipts/fontes → 12 estágios, executivo, aceite/transição. | Ciclo integral 08/09 12:57; depois contenção, agora PAUSADO. 6→7 sem receipt. S16–S20. | Retomada depende de nova solicitação, pois o proprietário mandou pausar. |

### 3.2 Publicações comprovadas

| Campo | Piloto |
|---|---|
| Título / URL | [The 24-Hour Test: What To Do After You Pray](https://www.youtube.com/watch?v=iK_5edYQtx8) |
| ID / canal | iK_5edYQtx8 / UCuMF6pJQkyMzaVoAxFL86yA |
| Data pública | 2026-09-04T18:45:51Z |
| Formato | Longo em inglês, 239 s na API / 238,7 s locais, 7.161 frames |
| Composição registrada | 59 takes, 22 fontes; thumbnail B, DO THIS TODAY; 59 cues |
| Estado comprovado | COMPLETE_PUBLIC, processamento confirmado |
| Receipt S13 | youtube-publication-f8f7adb600b32dfbae24; SHA-256 0c0f1faa32e4e67fd208a699b412af378e0cf5d865492cdcdd542f5b5c2c15da |
| Mídia registrada | 305.941.876 bytes; SHA-256 33829cd7cb4df3c968c695dfab8fe1abe7f5265137d7c297a12e42204183260c |

**Nenhuma publicação posterior do projeto foi comprovada** nos registros consultados. Isso não exclui atividade externa do proprietário. O canal já tinha 21 vídeos; o snapshot posterior registra 22. Não atribuir ao sistema os uploads antigos.

### 3.3 Desempenho observado, não estimado

S14: own-performance-iK_5edYQtx8-20260907T205653Z, captura 07/09 20:56:53.

- Público: 22 views, um like, um comentário.
- Analytics privado disponível: 15 views, quatro minutos assistidos, média 24 s, percentual médio 10,07%, retenção aos 30 s aproximadamente 0,3333; inscritos +0/−0.
- Canal: 265 inscritos, 22 vídeos, 2.637 views.
- CTR/impressions nulos; reach EMPTY / NO_MATCHING_OWNED_REACH_ROW_AVAILABLE_YET.
- Fontes Data/Channel/Analytics/Retention PASS; OBSERVED / ELIGIBLE_FOR_COMPARISON.

22 views públicas e 15 de Analytics podem refletir janelas/latência distintas; a diferença sozinha não é defeito. N pequeno não demonstra viralidade, causalidade ou previsibilidade. Quatro minutos não são horas qualificadas YPP automaticamente.

### 3.4 Capacidade criativa real

Último inventário documental recuperado: 291 entradas, 290 CATALOGED e um LIMITED, fp-broll-cinematic-narration@1.1.0. **Não houve nova contagem completa de Packs nesta rodada.** O Pack produtivo comprovado é restrito ao longo HeroVerse/English/STANDARD.

Não há prova de todos os estilos validados, nem amostras finais aprovadas de cada família de anime, 3D, arte tradicional, curtos e conteúdo contínuo. Bibles, Packs, macropipelines e perfis superiores previstos não são equivalentes a capacidade validada.

A12: 39 ativos, 41 usos, 37 conteúdos PNG, três linhagens, **59 estados pendentes**. Metadados completos em algum subcontrato não equivalem a porcentagem de vídeo pronto. Fonte, direito, tempo, movimento, áudio e aprovação final são autoridades separadas.

## 4. Catálogo dos erros encontrados

O **Apêndice A deste arquivo** consolida os erros distintos encontrados no recorte acessível, incluindo tentativas que falharam e recuperações. Não é promessa de histórico integral da máquina.

Padrões recorrentes: temporários/OneDrive; migração incompleta de contratos/fixtures; confusão entre render e aprovação; relógios/serialização; instrumentos OCR/tracking; manutenção cujo teste passa mas fechamento falha. Ausência de FAIL no aceite não é aprovação quando existe MISSING_EVIDENCE.

### Incidente de manutenção preservado, anterior à pausa

Request maintenance-request-20260908T1258124421621Z-0e1dac1f, às 12:58:19.082903Z, requester 18748, LOCAL_VALIDATION_ONLY, efeitos externos false:

- Requester não encontrado às 13:09 e 14:47.
- Às 14:47, Gestor 11852 vivo, lock HELD/lease válido; ACK READY_TO_STOP renovado, sem leases, reservas ou efeitos abertos.
- Diretório da tentativa continha somente local-runtime-migration-preview.json; sem regression/final/recovery próprios encontrados.
- Capability residente apontava watcher antigo, SHA-256 0f8553fd697ff2226f6b839ed500a15eb529fd6c7823e188f9b7a13b37c7ced2.
- Access token anunciado expirava 13:38:39; expiração não demonstra revogação. Não houve novo refresh no levantamento.
- Antes da pausa, o mesmo request tinha ACK do novo PID 15244. Causa de troca de PID e de ausência de cleanup desconhecida.

A pausa posterior encerrou processos e desativou os agendamentos; **não reparou esse estado residual**. Não remover marker/lock indiscriminadamente ao retomar.

## 5. Inteligência viva e automação

### 5.1 Implementado e persistido

Catálogo/snapshots, DNA/arquétipo, seleção, decisões criativas, diagnósticos, predictions, experimento congelado, TreatmentOrder, fila SQLite, checkpoints por leitura externa, quota ledger, receipts, gates, trajetória, histórico de ciclo e aceite possuem materialização real.

O robô roda em Python local no Windows. A tarefa HeroEngine-Phase5-CentralManager tem nome histórico de Fase5, mas o código evoluiu para os 12 estágios da Fase6:

    OWNED_OBSERVER → PREDICTION_OUTCOME → TREATMENT_COMPILER
    → RELEASE_PREPARER → PACKAGE_TREATMENT → MEDIA → QUALITY
    → PUBLICATION → LEARNING → GOAL_TRAJECTORY
    → PHASE_TRANSITION → EXECUTIVE_VIEW

Última iteração integral recuperada: phase6-control-cycle-7be7327da7af8ab82ec37082, 08/09 12:57:13.703218–12:57:48.269333, PASS_ADVANCED/12 estágios/schema válidos/sem blockers de execução. Não prova aceite da fase.

### 5.2 Exemplo real e ponto em que a cadeia para

| Elo | Evidência |
|---|---|
| Informação | D1: contagem própria exata abaixo de 30; insuficiência de dados criativos no contexto do diagnóstico. |
| Decisão | DISTRIBUTION_SAMPLE → TOPIC_ANGLE, LOW; não atribuir resultado a hook/thumbnail/corpo. |
| Memória | heroverse-phase6-single-variable-v1, baseline e diagnóstico nominais presos por hash. |
| Ação | Pré-produção/compilação e mídia do Vídeo 2. |
| Resultado | Mídia rejeitada; remediação, sem publicação do tratamento. |
| Aprendizado de audiência aplicado/medido | **Ausente.** WAITING_FOR_TREATMENT_PUBLICATION; target_video_id, aplicação, snapshot e avaliação nulos; job NOT_CREATED. |

Não há ainda sequência completa de melhoria de audiência validada no experimento ativo.

Existe sequência completa **técnica limitada ao minerador**: divergências 0.1 → KEEP_CHAMPION/correção → implementação 0.2 → benchmark melhor → outcome registrado. OCR 0,151515→0,977273; narrativa 0,287386→0,718333; packaging 0,745455→0,877403. Mesmo conjunto de desenvolvimento: não prova retenção, generalização ou monetização.

### 5.3 Previsibilidade

Prediction vigente consultada: prediction-iK_5edYQtx8-bb77831002cef3f1; horizonte 08/09 18:46:48.372812Z, WAITING_FOR_HORIZON e WITHHELD_INSUFFICIENT_CALIBRATION. Esse é o último estado recuperado antes da pausa; passar o horário não cria avaliação.

Uma avaliação válida de forecast retido prova abstenção correta, não acurácia. Não há probabilidade confiável de monetizar, intervalo calibrado ou taxa de acerto de audiência demonstrados. Configurar 20.000 simulações não cria 20.000 observações.

Trajetória de 08/09 12:57:25: 265 inscritos observados, gap735, ganho0, necessidade aritmética de aproximadamente 28,008582/dia no restante da janela daquele instante. Não é forecast nem contador consultado ao vivo nesta rodada. Horas qualificadas/RPM seguem nulos.

### 5.4 Configurado versus executado

| Rotina | Configuração/prova; estado atual |
|---|---|
| Gestor/autostart | Loop, lock SO, lease/heartbeat; ciclos reais e recuperação histórica. **Agora encerrado, tarefa desabilitada.** |
| Codex horária | hero-engine-rotina-di-ria; despertares não são conclusões nem segundo Gestor. **Agora PAUSED.** |
| Checkpoints criativos | D1/D3/D7/D14/D30; observações D1/D3 recuperadas. Próximo formal conhecido D7 em 11/09 18:45:51. Execução futura suspensa. |
| Canal diário | D1–D30; reutiliza checkpoint ou uma leitura oficial por slot. Agendamento não é leitura executada. |
| Prediction | Job PENDING no último snapshot; outcome atual não verificado. |
| Tratamento | Depende de publicação; ainda não criado. |

### 5.5 Recuperação, duplicação e dependências

Há singleton Windows/código73, fila transacional, leases, retry/defer, preflight antes de chamadas, snapshots nominais/hashes e receipts idempotentes. Upload incompleto retoma o mesmo video_id. Rejeição pós-render não autoriza repetir efeito SUCCEEDED.

Há contrato de **20 rotas de fallback em 17 domínios**; isso não prova execução produtiva de cada fornecedor. Retry do mesmo provedor, replay de cache, recuperação de checkpoint e troca de provedor são classes distintas; nenhuma aprova direitos ou calibração ausentes.

Dependências: computador/conta local, RAM/disco, modelos/ambiente virtual, arquivos OneDrive residentes, rede, grant/cotas e ausência de barreiras. Novas tarefas do agente dependem de Codex; loop local implementado não consome Codex a cada ciclo. Não há garantia de operação com computador desligado ou crédito infinito.

## 6. Custos, testes e pontos de retomada

### 6.1 Recursos e limites medidos ou declarados

| Recurso | Limite/consumo disponível; ressalva |
|---|---|
| Custo técnico | R$0 adicional autorizado e declarado nos receipts. Não é auditoria financeira de toda a conta ou custo total de propriedade. |
| Computador | Infraestrutura existente; energia, depreciação, RAM/CPU atuais e custo de assinatura Codex não medidos nesta rodada. |
| Python/projeto | pyproject: hero-engine 0.1.0, Python≥3.11; runtime observado anteriormente 3.12.14. Versão de pacote não é versão de cada módulo. |
| Requisitos | yt-dlp≥2026.8.1; google-api-python-client≥2.170.0; google-auth-oauthlib≥1.2.2; faster-whisper≥1.2.1; Pillow≥12.3.0; jsonschema[format]≥4.25.1; rapidocr=3.9.2; onnxruntime≥1.29,<2; opencv-python≥5,<6; kokoro-onnx=0.4.9; soundfile=0.14.0. Faixas não provam versão instalada exata. |
| Biblioteca residente | Checkpoint histórico: 29 ativos elegíveis, 783.561.975 B, 1.499.877 ms. Não é espaço livre atual. |
| Preflight de render | Fontes/modelos/FFmpeg locais íntegros, pool elegível e reserva pós-render de 5 GiB. Falha deve bloquear antes de enqueue. |
| Quota YouTube | Observação histórica de console: 10.000 unidades gerais/dia, 100 uploads/dia naquele registro, billing desabilitado. Sem nova consulta. Ledger OAuth de 08/09 registra uma unidade; reserva conservadora geral 2.000 e piso12. |
| vidIQ | Gratuito/ledger/fallback previstos; saldo atual não verificado. |
| Codex | Última observação recuperada: 08/09 12:03:33, 38% usado/62% restante; renovação15/09 01:22:52. Reserva10pp; 52pp acima dela naquele instante, não saldo atual. |
| Governança Codex | Conta compartilhada, QR Dolar declarado pausado; não comprova ausência de uso externo. 2.500 créditos não foram somados à porcentagem. Resets anteriores específicos não autorizam resgate automático remanescente. |
| Ads | Nenhum orçamento expresso ou gasto executado comprovado; não acionado. |

Não há rendimento medido de pontos Codex por tarefa, total confiável de crédito desperdiçado ou garantia de duração até renovação. Nenhum reset/compra/mudança de modelo foi feito nesta rodada.

### 6.2 Última instalação integral comprovada

Manutenção maintenance-request-20260908T0638421312645Z-66aae4cc, final daily-maintenance-20260908T0704082284584Z-edafedef, concluída **08/09 07:04:08.2284584Z**:

- **1.781 casos: 1.780 PASS e um skip permitido**, privilégio symlink Windows/WinError1314; skip não é PASS.
- 180 schemas, 554 itens, 3.080.086.312 bytes inventariados.
- Comando de regressão registrado em aproximadamente1.418 s; não é tempo total do projeto.
- Regression receipt daily-regression-20260908T0703269788806Z-f9326681; SHA-256 20d8aeb40a8309f4d2e462236ec225f233410dd38f963890989b480be9083b75.
- Final SHA-256 2160bab5890c56b578e6cb212096ef802baf9a4277e1e68d2b640803bd01854d.
- D116 phase6-post-maintenance-44444d2223e52e0fa582d0d1; SHA-256 726e233e20dc025d0343e05c71536c33660477706a70dbe0608bd8b6aa1c436f.
- Recuperação23076→11852, novo ciclo12/12 e cinco snapshots imutáveis relacionados.

**Essa é a última base instalada com prova integral recuperada, não prova de projeto inteiro pronto.** Arquivos alterados depois das07:04 não herdam essa instalação.

| Incremento posterior | Resultado conhecido / limite |
|---|---|
| PUBLICITY stage_a | 25 focais, inclusive A12 bloqueada antes de WAV/queue/A.verify; não sucessor completo instalado. |
| PUBLICITY replay | 34 métodos distintos confirmados:23 observados inicialmente+11 recuperados após perda de terminal. Não presumir resultado agregado inicial. |
| Controles/origem | Duas inferências e recuperação de282 origens, sem reinferência/rede. Não calibra domínio. |
| Variedade | 14 focais informados pelo terminal e2232b; sem log persistido e sem instalação/mídia real. |
| OpenImages geometria | 12 focais;54 imagens ambíguas, não padrão-ouro. |
| Watcher não bloqueante | 11 focais PASS9f73f6, ~0,473s; candidato SHA fbc994ea64b5261ebdd3cb5055b20b7e491cc9e8c91dd3defcf9959c710bca9a. Não instalado/D116. |
| Saída cooperativa | Execução5551b9 exit0/~6,16s; request próprio encerrado12:56:40; ciclo residente12/12 subsequente. Não instala patch. |
| Manutenção12:58 | Sem regressão/finalização encontrada. Não classificar PASS ou presumir teste ainda executando. |

Inventário pontual:35 diretórios de manutenção e sete final-receipt.json, esses sete PASS. Não significa28 falhas, somente sete manutenções concluídas ou ausência de outros tipos de receipt. O detalhe conhecido está no apêndice.

### 6.3 Materiais que devem ser reaproveitados

| Material | Identidade / uso e limite |
|---|---|
| Backup Fase0 | 135.857.485B; SHA 6b0e09614554390da20049b604a43c1970e9d4d25fdf69fead042588903d83fd. Registro histórico de cópia externa, não reconstruída. |
| Gold/minerador/observatório/modelo | S08–S11: fixtures, snapshots, replays e aprovação do arquétipo. Não refazer para corrigir manutenção. |
| Piloto | S13/hashes seção3; não duplicar upload nem regenerar mídia aprovada para resolver incidente local. |
| A12 | S21, timeline phase6-av-timeline-cc5a42e083848fe0a7c6e843, SHA c38a12e6e7c5c2b5a131282ba22d674e0f3c789542ec74d9d58e467c574bedf6. Incompleta, mas vínculos registrados reutilizáveis. |
| Master diagnóstico | S22; SHA 8e8909fef9835f92aee8521db9c7e0153216fa5a48a0bd0f2177444fdeac49b6; PCM16/mono24k,4.866.720 samples,9.733.518B,202,780s. |
| Níveis do master | −16,37 LUFS, −1,49dBTP, LRA3; não transferir para render diferente ou pronúncia. |
| Body/direitos | Receipt e2b0beb8…:12 provas/24 documentos; reusar registros exclusivos, rasters/OCR em seus escopos. |
| PUBLICITY | Perfil2.423 arquivos/495.543.494B; dois PPMs; controles positivo1/negativo0; recovery receipt f477c45bc5609bff93da81eb8ed8fe3dd1c2639c3b7974b04501e09a0a0bcd4e. |
| Pexels5190601 | Receipt3abdbcb2cc2216e60d82219da75d8f5a951811b4e5ab074a3caa5b2276b6037d;25.472.389B,42,12s,2732×1440,sem áudio. Quarentena/gesto de escrever, não resultado admitido. |
| OpenImages | Quatro arquivos/51.011.872B/quatroGET; receipt1da6fc76380b5998799d1d093bb83a22a765fe0fe5c7c166ce2dcdb1de53edaa. Join/triagem não são model release/gold. |
| OAuth | Recovery-v2 de12:38 e falha anterior preservados. Grant igual não deve sobrescrever prova como se fosse consentimento novo. |

Não repetir síntese, ASR, OCR, decodes, downloads e regressões intactas para relatório equivalente. Quando nova versão realmente altera dependências, reuso exige hashes e escopo compatíveis; “cache” não pode esconder corrupção.

### 6.4 Comandos existentes — apenas referência, não executados

Na raiz do projeto, a CLI possui mine-video/mine-fixtures. Entradas reais:

    & 'C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/.venv/Scripts/python.exe' -m hero_engine.central_manager_phase5 --loop --interval 60
    & 'C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/.venv/Scripts/python.exe' -B -X utf8 -m unittest discover -s tests -v
    & 'C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/daily.ps1'
    & 'C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/verify_phase5_manager_autostart.ps1'

São comandos existentes, **não instrução para rodar todos ou retomar agora**. O primeiro é fallback manual, não deve duplicar uma tarefa viva. Regressão integral requer snapshot estável/manutenção. O verificador de autostart executa provas, não é simples consulta de arquivo.

Há [run.ps1](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/run.ps1>), [setup.ps1](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/setup.ps1>), [connect_youtube.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/connect_youtube.py>) e [ensure_power_continuity.ps1](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/ensure_power_continuity.ps1>). Setup completo não é pré-requisito para reutilizar ambiente instalado.

Pausa histórica usa o marcador [PAUSE](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/runtime/gestor-central/PAUSE>). **A pausa atual também desabilitou tarefa e automação; remover só o marcador não é plano completo de retomada.** Não confundir PAUSE, lock e request/ACK de manutenção. Nenhum deles foi modificado nesta rodada.

## 7. O que falta para concluir

### A. Indispensável para concluir a Fase6

1. Respeitar a pausa atual. Antes de qualquer retomada autorizada, esclarecer o ciclo de vida da manutenção pendente; desligamento não reparou o request residual.
2. Instalar/recuperar apenas incrementos necessários posteriores ao último lote, com sua própria prova, sem repetição integral por rotina.
3. Fechar intenção/variedade real: exposição potencial de40,832s da linhagem four-criteria equivale a14,2645% até no teto286,25s, contra10%. Realocação condicional mínima12,207s. Candidato com17 estados/83 preservados apresentou redução observada0; não resolveu alocação real.
4. Resolver os59 estados pendentes com fontes, direitos, continuidade e PUBLICITY. Não esconder repetição por IDs ou overlays.
5. Referência temporal aplicável: policy temporal-policy-6587e640dafb2974367e7d15 exige30 unidades distintas/configuração exata, cobertura e erro≤800samples; existem23 candidatas disjuntas aplicáveis depois das exclusões. Não baixar mínimo/inventar timestamps/usar UNIT_ENTRY como onset lexical.
6. Áudio/duração:202,780s contra mínimo de grade207,800s; faltam5,020s. Não completar por silêncio arbitrário, truncar/acelerar ou aprovar percepção por DNSMOS.
7. Fechar produtores/consumidores A–D compatíveis com unidades, captions e estados; metadados/rasters isolados não são vídeo sincronizado.
8. PUBLICITY/calibração/QA independente no domínio aplicável. Dois controles/caixas geométricas não bastam.
9. Render final admitido e verificado em movimento, continuidade, texto, áudio e narrativa do arquivo exato.
10. Release/readiness e publicação do tratamento, private-first→processamento→público verificado, preservando variável única e direitos.
11. Janela/medição do tratamento, comparação com baseline e avaliação causal exata para GC01.
12. Reconciliação de ciclo/aceite/executivo e receipt imutável6→7 somente quando permitido.

Aceite recuperado de12:57:47:9 PASS_LIVE,5 PASS_FIXTURE,1 WAITING_REAL_EVIDENCE,3 MISSING_EVIDENCE,4 NOT_APPLICABLE,0 FAIL. Blockers **GC01/07/20/22**. Transição WAITING_FOR_PHASE6_GATE, receipt nulo. O ciclo posterior não autoriza presumir reconciliação do snapshot anterior. GC11/19 históricos não devem ser recitados como blockers atuais sem reler o aceite exato.

### B. Indispensável nas fases seguintes

- Fase7: Rule Registry, aplicação futura/segunda medição, antes/depois, segundo canal, isolamento e teste de generalização; medir melhora ou rejeição fundamentada.
- Fase8: onboarding, permissões, isolamento, bibliotecas/limites/histórico próprios, segurança, suporte, observabilidade, licenças e sustentabilidade.
- Capacidade ampla: validar progressivamente receitas/macrofamílias/Packs do escopo comercial; catálogo não cumpre capacidade produtiva.
- Alegações comerciais compatíveis com evidência; não vender garantia universal de monetização em30 dias.

### C. Opcional para o piloto, não bloqueador antecipado

Expandir todos os estilos antes de fechar o Pack corrente; novos Shorts/nichos/canais antes do gate; plugins ou arquitetura paralela sem lacuna concreta; variantes fora da variável congelada; Ads para compensar defeito técnico; repetição de mídia/benchmark íntegros. “Opcional agora” não exclui requisito futuro aprovado.

### D. Dependências externas/de tempo

Grant/desafio pessoal/permissões/cotas; referência humana e documentos de direito aplicáveis; latência Reporting/janelas de observação; audiência e aprovação YPP; orçamento futuro de Ads; hardware/rede/crédito Codex finito. Não transformar essas dependências em aprovação administrativa repetitiva nem inventar evidência para removê-las.

### Uma única próxima tarefa proposta

**Teste focal do abandono da manutenção 0e1dac1f e da via segura de recuperação.**

- **Objetivo:** estabelecer onde a saída do solicitante deixou de reconciliar o request. Processo ausente foi observado; motivo de término/cleanup ainda desconhecido, logo não propor patch especulativo.
- **Escopo mínimo:** confrontar request, ACK, geração/PID, preview e logs existentes com caminhos de saída/exception/finally; reproduzir perda do solicitante em fixture isolada. Sem retomada real, OAuth, mídia, publicação ou regressão integral.
- **Componentes:** [daily.ps1](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/daily.ps1>), [central_manager_phase5.py](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/hero_engine/central_manager_phase5.py>), protocolo importado de handshake, S19–S20 e [helper cooperativo](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/scripts/recover-oauth-watcher-boundary.ps1>). O helper é de incidente próprio, não receita genérica para apagar markers.
- **Intocado:** pausa/tarefas desabilitadas, credenciais, fila/ledger reais, piloto, job rejeitado, A12/rasters/gold, direitos/custo, hooks e experimento.
- **Teste necessário:** saída do requester antes do fechamento; requester vivo; PID reutilizado; request trocado; ACK inválido; lease/efeito aberto. Identidade/request/geração devem impedir limpeza indevida.
- **Done when:** causa/transição reproduzível identificada ou perda de evidência delimitada explicitamente; resultado focal persistido e via permitida de recuperação com precondições demonstradas. Se código novo for necessário, sua necessidade deve decorrer do teste. Não é autorização para retomar automaticamente.

**Essa tarefa não foi iniciada nesta rodada.**

## 8. Limites do levantamento

### Fontes e escopo de consulta

| Ref. | Fonte real | Alcance |
|---|---|---|
| S01 | [Pedido original de consolidação](<C:/Users/mathe/.codex/attachments/f47f21a4-84c9-44a1-9110-b6cb1e5384fb/pasted-text.txt>) e pedido atual na conversa | Integrais; relatório apenas, com pausa entre as rodadas. |
| S02 | [AGENTS.md](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/AGENTS.md>) | Contratos/checkpoints acessíveis; cabeçalho não substitui observação posterior da pausa. |
| S03 | [PLANS.md](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/PLANS.md>) / [STATE.md](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/STATE.md>) | Cabeçalhos e trechos críticos/históricos, não releitura integral de todos os blocos repetidos. |
| S04 | [DECISIONS.md](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/DECISIONS.md>) | Decisões acessíveis D-001–172 selecionadas cronologicamente; algumas saídas extensas truncadas. |
| S05 | [Master](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/00_MASTER_SPEC.md>), [Protocolo](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/01_EXECUTION_PROTOCOL.md>), [Fases/gates](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/07_PHASES_AND_GATES.md>) | Integral dos documentos selecionados. |
| S06 | [engine.json](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/config/engine.json>) | Integral; configuração separada de execução. |
| S07 | [PHASE_0_AUDIT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_0_AUDIT.md>) | Preservação/auditoria/aprovação histórica. |
| S08 | [PHASE_1_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_1_REPORT.md>) / [gold_standard](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/data/gold_standard>) | Relatório/IDs/validação; não nova anotação. |
| S09 | [PHASE_2_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_2_REPORT.md>) / [IMPROVEMENT_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_2_IMPROVEMENT_REPORT.md>) | Resultados/divergências/limites históricos. |
| S10 | [PHASE_3_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_3_REPORT.md>) | Lote/contagens/testes, sem mercado novo. |
| S11 | [PHASE_4_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_4_REPORT.md>) | Modelo/aceite condicionado/limitações. |
| S12 | [PHASE_5_CREATIVE_V3_REPORT](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_5_CREATIVE_V3_REPORT.md>) / [MARKET_AND_VIRAL_REVIEW](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE_5_MARKET_AND_VIRAL_REVIEW.md>) | Trechos e decisões de revisão recuperados, não análise nova. |
| S13 | [Publication receipt](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/production/phase5/pilot-001/creative-v3/youtube-publication-receipt.json>) | Publicação/identidade/estado. |
| S14 | [Métricas latest](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/metrics/iK_5edYQtx8/latest.json>) | Snapshot07/09, sem chamada externa nova. |
| S15 | [Learning](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/intelligence/learning-runtime.json>) / [Prediction](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/intelligence/prediction-runtime.json>) | Cadeias/esperas/ausências de avaliação. |
| S16 | [Aceite](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/acceptance-report.json>) / [Transição](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/phase-transition-runtime.json>) | Snapshot12:57/blockers/receipt nulo. |
| S17 | [Ciclo](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/control-cycle/latest.json>) | Última iteração integral recuperada. |
| S18 | [Executivo](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/executive-status.json>) / [Trajetória](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/goal-trajectory/latest.json>) | Visões anteriores à pausa, aritmética datada. |
| S19 | [Manutenções](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/runtime/gestor-central/maintenance-runs>) / [D116](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/post-maintenance-verification/latest.json>) | Inventário e recuperações selecionadas. |
| S20 | [Request](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/runtime/gestor-central/maintenance-request.json>), [ACK](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/runtime/gestor-central/maintenance-ack.json>), [OAuth watcher](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/oauth-watcher-unblock-v1>) | Leituras/identidades e provas de recuperação; não alteração. |
| S21 | [A12](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/phase6/av-admission/timelines/phase6-av-timeline-cc5a42e083848fe0a7c6e843.json>) | Vínculos/literalidade/bloqueios. |
| S22 | [Revisão áudio](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/REVISAO_INICIAL_AUDIO_VIDEO2.md>) / [Master](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics/editorial-narration-master-v1-14c3d700a155554bc006af41/refinement-v1/narration-normalized.wav>) | Relatórios/medições existentes; sem nova escuta/síntese. |
| S23 | [Incidente visual](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE6_RENDER_VISUAL_INCIDENT.md>), [Calibração](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE6_CALIBRATION_SCOPE_AUDIT.md>), [Composição](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE6_CONTINUOUS_COMPOSITION_BOUNDARY.md>), [Retomada07/09](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/RETOMADA_OPERACIONAL_2026-09-07.md>) | Documentos selecionados integrais. |
| S24 | [Diagnósticos](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/qa/phase6/diagnostics>) / [Variedade](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/PHASE6_VARIETY_CONTRACT_VERIFICATION.md>) | Verifications e inventário selecionados; não abertura de todos os binários/logs. |
| S25 | [Fallbacks](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/FALLBACKS_OPERACIONAIS.md>), [Runtime](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/CENTRAL_MANAGER_RUNTIME.md>), [Integração](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/docs/YOUTUBE_INTEGRATION_REPORT.md>) | Histórico; introdução Phase5 não descreve sozinha runtime Phase6 atual. |
| S26 | [Requirements](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/requirements.txt>), [pyproject](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/pyproject.toml>), [Quota Codex](<C:/Users/mathe/OneDrive/Área de Trabalho/Modelagem Youtube/output/operations/codex-usage>) | Requisitos integrais e observações existentes, não nova leitura oficial. |

Também foram consultados inventário/leitura seletiva de código, metadados de processos/tarefa Windows e o estado PAUSED da automação local. Uma conferência independente limitada confirmou23 caminhos existentes, sem reler fontes ou executar testes.

### Ausências e limites explícitos

Não há cadeia Git local completa nem todos os turnos iniciais recuperados. Não foram lidos todos os logs/binários ou cada byte dos documentos extensos/truncados. O catálogo cobre todos os erros distintos encontrados no recorte, não todos os erros possíveis.

PASSs são históricos, não retestados. Nenhuma consulta nova a YouTube/Google Cloud/vidIQ/limites Codex foi feita. Estado público atual de capa/descrição, reprodução do piloto, horas YPP, RPM, receita, cotas e eventual atividade externa posterior permanecem não verificados ao vivo.

Não se comprovou autoria pessoal de toda anotação humana, generalização de todos os formatos, fornecedores alternativos todos exercidos, segunda publicação, tratamento aprendido, segundo canal ou produto final. Não se mediu custo total/tempo de retrabalho/consumo por tarefa. Causa original de REFRESH_FAILED, desaparecimento do requester e troca de PID permanecem desconhecidos.

Leituras não formam snapshot transacional global da máquina. Última observação de manutenção não é estado atual após pausa. A meta de30 dias permanece como meta, sem garantia/probabilidade calibrada.

**Entrega documental; operação permanece pausada. Nenhuma correção ou próxima tarefa foi iniciada.**

## Apêndice A — catálogo detalhado de erros e tentativas

Continuação da seção4. Cada linha contém etapa/ID, intervalo conhecido, manifestação/impacto/causa, tentativas/resultados/testes, regressão conhecida e situação/fonte. “Registro” data a decisão, não necessariamente a ocorrência original. Contagem não indicada é **desconhecida**. Sem regressão atribuída significa ausência de atribuição no recorte, não prova de inexistência. Mensagens resumidas não são citações literais; literais são indicados entre aspas.

Os nomes completos de todos os métodos de teste não foram recuperados; onde só há contagem/escopo, isso é o limite da prova citada. R=regressão atribuída; R—=nenhuma atribuída no registro. “Corrigido” é sempre limitado à versão/prova referenciada.

### A1. Mineração, criatividade e integração inicial

| ID / etapa / primeira→última conhecida | Manifestação, impacto e causa | Tentativas, resultados, teste e regressão | Situação / fonte |
|---|---|---|---|
| E001 Direitos; registro02/09 | Fonte5-zdruoQKlM com classificações verified_cc/not_verified/indeterminate incompatíveis. Direito de produção não demonstrado. | Escolhida classificação restritiva; público não convertido em licença. Teste corretivo específico não recuperado; R—. | Restrição preservada, não direito resolvido. D-010/S04. |
| E002 Minerador;02/09 | OCR0/4, narrativa0/4, packaging3/4 no padrão inicial; execução não entregava o contrato. | 0.1:33 testes, quatro execuções/replays, KEEP_CHAMPION. 0.2:38 testes/48 campos avaliados, melhorias S09. R: reabertura de fase anteriormente insuficiente. | Corrigido no desenvolvimento; generalização inconclusiva. D-023–025. |
| E003 Observatório;02/09 | /videos apenas deixou de incluir20 Shorts próprios. Cobertura de formato falsa/incompleta. | v1 preservado; v2 duas rotas/proveniência,49 testes e novo lote. Quatro abas ausentes tratadas PARTIAL, não inferidas como zero. | Corrigido no lote. D-028/029/S10. |
| E004 Montagem; registro02/09 | Arredondamento por take acumulava quase1s de drift audiovisual. | Timeline frame-locked30fps,7.572frames e drift por take0 no ensaio. Teste de frames/alinhamento, não qualidade de hook. R—. | Corrigido naquele render. D-036. |
| E005 Seleção de ativos; registro02/09 | Fonte licenciada estática/textual inadequada ao tratamento; spans atravessavam cortes internos. Direitos não garantiam adequação. | Gate bloqueou; fontes/spans substituídos,44/44 alocações seguras no lote. Inspeção técnica/semântica; R—. | Corrigido no lote, regra permanece. D-037. |
| E006 Criatividade;02→03/09 | v2.1 abaixo da revisão crítica de qualidade/mercado; motivos completos de cada rejeição não recuperados. | D-039–042 reabriram direção e v3. Testes/relatórios S12; não inventada métrica viral. R: artefato anterior precisou ser reformulado. | Histórico; piloto posterior não valida v2.1. |
| E007 Variedade;03/09 | v3.1 autoaprovada tinha top6≈66,3176%, uma fonte>10%, até7 usos/4 em60s. | Revisão visual retrorejeitou; controles de concentração/rolling window adicionados. v3.2:top6≈44,3653%,maior≈8,2111%,máx4/3 em60s. | Corrigido no piloto; reincidência conceitual E119. D-060/061. |
| E008 Semântica;03/09 | Takes14/19 não expressavam James under pressure como pretendido. | Realinhamento visual; revisão por take. R: aprovação anterior insuficiente; teste nominal não recuperado. | Corrigido no piloto. D-061. |
| E009 Movimento;03/09 | Freeze de1,4s entre236,167–237,567s. Imagem bonita não aprovada em movimento. | Movimento corrigido;22/22 QA, zero freeze/black final. Replay SSIM0,99782, não igualdade de bytes. R—. | Corrigido no escopo. D-061. |
| E010 Regressão;03/09 | Um teste falhou porque PAUSE estava ativo durante rotação de candidato. |125PASS/1FAIL; retomada intencional adequada ao teste,126PASS. Não era defeito visual. | Histórico recuperado. D-063. |
| E011 OAuth/escopos;03→04/09 | “invalid_scope”; três escopos não atendiam captions/alteração pública, faltava force-ssl. | Novo consentimento legítimo para quatro escopos, token anterior preservado; integração posterior funcionou. R: fixtures/manifestos com escopos antigos precisaram migração. | Corrigido para piloto; não licença para contornar Google. D-057/059. |
| E012 Conta/identidade; registrosD-057→D-105 | Conta Google/Studio distinta ou sem acesso Cloud; risco de atuar no canal errado. | Binding ao channel ID bloqueou; seleção/autenticação legítimas. Verificações próprias posteriores; número de trocas desconhecido. R—. | Controle válido; sessão futura pode diferir. |
| E013 Conformidade OAuth;03→04/09 | App Testing, site/identidade/domínio/escopos incompletos; integração não podia ser tratada como comercial pronta. | Site gratuito/conformidade e escopos organizados. Exceção de uso pessoal não validou produto multiusuário. | Parcial/externalidade comercial. D-052–054/071/S25. |
| E014 Token source/runtime;04/09 | Arquivo fonte e cópia consumida divergiam; contexto da tarefa não acessava fonte; risco de refresh/prova errados. | Mirror atômico/caminho canônico/quatro escopos;152/154 testes. R: manifestos mutáveis e escopos afetaram testes. | Corrigido no escopo; falha posterior de watcher E116. D-067/068. |
| E015 Fixtures OAuth;04/09 | Seis expectativas ficaram obsoletas após escopos/quota reais. Não falha nova do grant. | Fixtures ajustadas ao contrato,154 testes posteriores; sem regenerar mídia. | Histórico corrigido. D-069. |
| E016 Domínio;04/09 | URL-prefix no SearchConsole tomado como propriedade DNS raiz. Prova insuficiente de marca/domínio. | Schema1.1 separou site pronto e marca não verificada. Não se fabricou domínio/DNS. | Uso pessoal limitado; comercial aberto. D-071. |
| E017 Mirror;04/09 | “NameError: ROOT” antes do espelhamento; também comparação temporal sem microssegundos causava inversão falsa. | ROOT corrigido e precisão preservada;158 testes. Token antigo permaneceu íntegro. | Corrigido no escopo. D-072. |
| E018 Console;04/09 | “Não foi possível abrir a mídia”; source.src atribuído sem video.load(). | Carregamento explícito, navegador Ready/238,7s e159 testes; encerramento de conexão tratado sem stderr indevido. | Corrigido; console agora parado por solicitação. D-073/S25. |
| E019 Refresh pré-upload;04/09 | Prova diária recente, mas access token expirava antes do upload. | Refresh sob demanda/margem300s e identidade;166/167 testes. Campo de máximo1probe/dia não demonstra limite real com refresh frequente. | Upload resolvido; observabilidade do limite ainda parcial. D-075/076. |
| E020 Publicação;04/09 | a) memória/schema antigo bloqueou antes do upload; b) token expirado; c) estágio privado aguardando processamento sem reconsulta agendada. | Correções específicas e retomada do mesmo ID, sem segundo upload; COMPLETE_PUBLIC S13. Contagem de tentativas além dessas desconhecida. | Corrigido no piloto. D-077. |
| E021 CTR/Analytics;04/09 | HTTP400/query not supported para consulta de alcance pretendida. | Rota Reporting bulk passou a representar atraso/linha ausente; coleta real. Não inventar CTR0. | Integração alternativa existe, dados de reach ainda indisponíveis. D-078/S14. |
| E022 Coletor/token;04/09 | Resolver consumiu fonte errada e refresh alterou receipt/hash compartilhado, quebrando readiness. | Resolver canônico e check de hashes;24 focais/172 integrais. R: ligação de release afetada até correção. | Corrigido no escopo. D-078. |

### A2. Runtime, dados, decisões e governança

| ID / etapa / intervalo conhecido | Manifestação, impacto e causa | Tentativas, testes e regressão | Situação / origem |
|---|---|---|---|
| E023 Runtime/OneDrive;04/09 e recorrências posteriores | PermissionError em manager-lock.json.tmp; processo saiu. Dois artefatos mutáveis causaram drift de manifesto. Ator externo do lock não identificado. | Temporários únicos, escrita atômica/retry limitado e reconciliação; runtime recuperado. R: problemas semelhantes reapareceram em outros writers, E026/E079. | Correção local, não garantia global. D-080. |
| E024 Snapshot/manutenção;04→05/09 | Parada entre escrita e manifesto produzia inconsistência de snapshot. | Reconciliação com runtime parado e fronteira de snapshot; testes históricos. Não atribuir corrupção de mídia sem evidência. | Corrigido no protocolo da época. D-081/085. |
| E025 Relógio;04→05/09 | UTC com Z interpretado como local: lock novo parecia inválido. | Parse UTC explícito, provas posteriores. R: falsos negativos de manutenção, não avanço de vídeo. | Corrigido; outros problemas de relógio E081/E103 separados. D-085. |
| E026 Console/processos;04→05/09 | Temporário fixo OneDrive e stop de processo já ausente falhavam. | Writer com temp único/seis retries; stop idempotente para ausente. Testes do runtime; R—. | Corrigido no escopo. D-083. |
| E027 Calendário;04→05/09 | Geração/cadência antiga e horas YPP ausentes tratadas como zero, produzindo gap4000 indevido. | Workbook/estado ajustados; dois testes específicos. Não confundido com geração/publicação. | Histórico corrigido. D-082. |
| E028 Schema ordem; registroD-086 | Novos campos exigidos em ordem histórica causaram um ciclo de erro. | Rematerialização versionada/migração,209 testes; WAIT preservado. | Corrigido no escopo. |
| E029 Direitos de pessoa/marca; registroD-088 | Copyright tratado como prova suficiente de PUBLICITY/model release. | Camada de triagem/avaliação separada; licença não virou direito pessoal por inferência. | Restrição aberta no Vídeo2; não resolvida por detector. |
| E030 Alerta executivo; registroD-088 | executive-status-error em diretório errado persistia apesar de estado reconstruído válido. | Arquivamento por hash somente após rebuild válido. Teste nominal não recuperado. | Histórico corrigido; não apagar alertas por conveniência. |
| E031 Packaging/aplicação; registroD-089 | Pré-produção existia, executor público e comparação por janelas não fechados. | Payload transacional, rollback/janelas e17 gates em fixture; não havia prova de efeito público desse tratamento. | Implementação parcial, sem uplift validado. |
| E032 Release/OAuth; registroD-090 | “Release artifact changed: scope_requirement”; requisito derivado novo sem reconstruir gate pinado. | Reordenados requisitos/release/manifesto; recovery registrado. R: integração quebrada por evolução de fonte. | Corrigido no escopo. |
| E033 Prediction; registroD-091 | evaluate_prediction só em fixture, sem agenda/outcome real; GC08/10 podiam consumir dependências antigas. | Runtime/horizonte/backoff e evidência imutável; avaliações posteriores, forecast retido. | Fluxo existe; precisão não provada. |
| E034 Gates/fases; registroD-092 | GC14 cobrado na Fase6 apesar de depender da Fase7: ciclo de dependência. | Separação correta de fase,19 focais/255 integrais. Gate não removido da Fase7. | Corrigido no contrato. |
| E035 Bootstrap; registroD-093 | Installer/runner antigo e fallback para token inexistente; token=False/exit1. | Caminho canônico restaurado; energia/tela/sleep/hibernate ajustados ao pedido. Testes/receipt de autostart. | Histórico corrigido; atualmente desabilitado intencionalmente. |
| E036 Capacidade; registroD-094 | Enqueue ocorria antes de provar fontes/modelos/RAM/disco suficientes. | Preflight anterior ao job e reserva5GiB; testes de bloqueio. | Controle implementado, sem promessa de capacidade infinita. |
| E037 Ativos locais; registroD-095 | Catálogo/OneDrive não provava residência, hash, decode e direito. | Validação efetiva da biblioteca,29 elegíveis observados. | Corrigido no checkpoint; arquivo pode mudar depois. |
| E038 Diagnóstico D1;05/09 | Atraso de retenção bloqueava também decisão limitada de distribuição. | Fallback só raw exact count<30→TOPIC_ANGLE/LOW; não diagnostica hook/corpo. Testes e protocolo real. | Funciona no escopo restrito. D-096. |
| E039 Janela parcial; registroD-097 | D1 parcial pulava ao D3; D30 criava próximo instante vencido/loop. | Retry2h/tolerância12h e terminal next=null. Testes temporais; R—. | Corrigido no contrato. |
| E040 Falha de fonte; registroD-098 | FAILED marcado concluído e espera até checkpoint distante. | Tipo próprio SOURCE_FAILURE_RETRY30min/6h/12slots; exaustão observável. | Corrigido em código/testes; espera não garante fonte. |
| E041 Quota própria; registroD-099 | Leituras de métricas sem guard anterior a efeito. | Reserva2/piso12/preflight, testes de zero chamada se bloqueado. | Controle implementado. |
| E042 Busca criativa; D-100→101 | Três rotas eram insuficientes/diversidade pouco comprovada. | Compilador v2:seis rotas/três elegíveis/cinco eixos, red-team/distância/recomputação. R: novo contrato precisa consumidores compatíveis. | Técnica melhorada, audiência não validada. |
| E043 Ranking; D-102 | Profundidade já no score era contada de novo e podia ultrapassar candidato de sinal melhor. | Score-first; classe/contagem/ID só desempates. Testes de ordenação. | Corrigido no contrato; score não causalidade. |
| E044 Mercado imutável; D-103 | ID não impedia alteração do conteúdo/score da candidatura congelada. | Hash raw snapshot + hash canônico integral incluídos na ordem/reabertura. Testes de drift. | Corrigido no contrato. |
| E045 Packaging/render; D-104 | Candidatos não recomputados independentemente e render com tabela A/B/C paralela. | Seis rotas/três finalistas, fonte/hash/render_spec consumido literalmente;31 focais/288 integrais. | Corrigido tecnicamente; efeito de CTR não medido. |
| E046 Ciclo integral; D-106→107 | Estágios válidos isolados não provavam mesma iteração; alteração podia promover aceite no mesmo ciclo com prova anterior. | Receipt de ciclo e reconciliação material/um ciclo adicional. Migração inicial teve dois testes falhos por ordem executiva antiga;22 focais e depois integração,20 focais/293 na reconciliação. | Contrato corrigido; GC07/20/22 atuais ainda sem reconciliação admissível. |
| E047 Trajetória fora do ciclo; D-108→109 | Painel de meta não integrava prova conjunta; ciclo antigo tinha11 estágios. | GOAL_TRAJECTORY incorporado,12 estágios/schema1.1;299/302 testes. | Contrato novo; receipt11 histórico não satisfaz gate12. |
| E048 Contador canal; D-110 | channels.list falhava enquanto métricas do vídeo eram válidas, esperando atéD3. | Erro de trajetória separado, retry30min/6h/12slots;26 focais/306 integrais. | Corrigido no escopo; hidden count permanece null. |
| E049 Observação diária; D-111 | Total ficava desatualizado entre D3/D7. | Observador diário com uma chamada ou reuso exato;317 testes. | Executado historicamente; suspenso agora. |
| E050 Calendário diário; D-112 | Dias intermediários marcados sem checkpoint apesar do observador ativo. |14 folhas atualizadas e dois testes; observação não passou a significar postagem. | Histórico corrigido. |
| E051 Baseline/current; D-113 | Fallback265 apresentava total histórico como atual quando fonte era null. | Campos separados/null propagado;34 focais/319 integrais. Cold start do console recebeu espera limitada30s. | Corrigido no contrato. |
| E052 Ritmo; D-114 | Baseline28,226944h anterior à publicação e reuso duplicado usados como amostras da corrida. | Âncora dentro da janela e origens distintas/deduplicadas;33 focais/321 integrais. | Corrigido no contrato, não forecast calibrado. |
| E053 Integridade trajetória; D-115 | JSON parcial/caminho impróprio/latest sem twin podia alimentar ritmo. | Schema/path/ID/hash/twin e exclusão histórica exata;45 focais/327 integrais. Primeiro residente velho bloqueou; segundo teste live/transição falhou; terceiro estável PASS. | Recuperado no lote; múltiplas tentativas preservadas. |
| E054 Prova pós-manutenção; D-116 | Exigir PASS_LIVE com gestor parado e tomar unit PASS como prova de restart. | D116 separado com cinco snapshots e ciclo posterior;16 focais/334 integrais. | Contrato implementado; nova manutenção deve ter prova própria. |
| E055 Quota prediction; D-117 | Outcome podia ler fonte sem reserva/checkpoint. | Preflight2/piso12 com path/hash;14/29 focais e338 integrais. | Corrigido no contrato. |
| E056 Fila/quota tratamento; D-118 | Receipt dizia+5min, mas fila podia pollar por minuto; coleta do tratamento não tinha guard/reuso completo. | defer persistido sem consumir tentativa; checkpoints por etapa;34/26 focais/344 integrais. | Corrigido no contrato. |
| E057 D1 idempotência; D-119 | Snapshot só persistido após inteligência; falha posterior repetia chamadas externas. | Job/preflight antes de fonte, checkpoint imediato de cada leitura e hash;61 focais/345 integrais. | Corrigido no contrato. |
| E058 Canal diário idempotência; D-120 | Resposta não journaled e quota wait consumia tentativa. | Preflight+resposta nominal, defer_claimed/rollback pré-efeito;18 focais/349 integrais. | Corrigido no contrato. |
| E059 Causalidade/quota; D-121 | a) protocolo podia trocar baseline/variável; b) GC01/19 aceitavam cadeia alheia; c) quota de dia antigo/enum divergente. | active imutável, bindings exatos e diaPacific/reserva2000;356 testes. | Contratos corrigidos; não cria tratamento ainda ausente. |
| E060 Diagnosis indireta; D-122 | Protocolo congelado ainda apontava diagnosis/latest mutável. | Path nominal/hash/schema/identidade revalidados;363 testes. | Corrigido no contrato. |
| E061 Capacidade Codex; D-123/132/152/172 | Reserva compartilhada podia ser planejada duas vezes; promessa de nunca acabar sem medida. | Governança única, leituras oficiais/reserva/âncora; QR pausado. Resets específicos não viraram consumo automático. R: cotas mudaram por eventos cuja causa nem sempre disponível. | Mitigação, não solução para finitude; saldo atual desconhecido. |

### A3. Vídeo2, autoridade de execução e diagnósticos

| ID / etapa / intervalo conhecido | Manifestação, impacto e causa | Tentativas, testes e regressão | Situação / origem |
|---|---|---|---|
| E062 Voz; D-124 | Orçamento de palavras não provava duração real com Kokoro. Risco de falhar só após render. | Medição de unidades/voz pinada/margem; sem truncar/acelerar arbitrariamente. Testes de preflight. | Controle melhorado; áudio atual ainda curto. |
| E063 Autoridade de mídia; D-125 | Job pré-efeito antigo não podia ser reciclado/deletado sem perder proveniência. | Supersession versionada/COMMITTED e preservação do ID anterior. | Corrigido no contrato; não autoriza repetir SUCCEEDED. |
| E064 Voz/QA; D-126 | Producer1.2 e consumer1.1 incompatíveis. | Verificação de binding completo dos90WAVs e compatibilidade; processo antigo impediu adotar silenciosamente. | Evolução controlada; integração seguinte ainda pendente. |
| E065 Processo Windows; D-127 | os.kill(pid,0) retornava WinError87 para PID vivo. Falso diagnóstico de ausência. | OpenProcess/GetExitCodeProcess/CloseHandle somente leitura;69 focais. | Corrigido no probe específico. |
| E066 Prioridade; D-128 | Tarefa below-normal; comparação XML falhou por default ausente. | Normal/7 configurado; falha de comparação preservada. Throughput antes/depois não medido. | Não declarar aceleração comprovada. |
| E067 Texto final;05→06/09/D-129 | Literal “None” na imagem por str(None). | Renderer v2/sanitização; quatro testes novos+um cache e um frame real corrigido. R: necessidade de versão nova, não remendo de vídeo público. | Defeito focal corrigido; vídeo inteiro não aprovado. S23. |
| E068 Framework editorial;05→06/09 | Take003 mostrava TRUTH/RESPONSIBILITY/TODAY, plano requeria NAME/TEST/CHOOSE. | Inspeção/rejeição; sucessor de composição exigido. Não resolvido pelo patch None. | Aberto na cadeia AV; S23/D-137. |
| E069 Lease render; D-130 | Render longo podia ultrapassar lease sem renovação do proprietário exato. | Heartbeat/renovação ligada ao owner;12 focais no lote, instalação não presumida naquele checkpoint. | Contrato testado, prova de adoção depende do lote. |
| E070 OCR efetivo; D-131 | Contar palavras do plano não provava pixels; OCR real bloqueado pelo piso de RAM. | Gate independente fail-closed; sem passar por metadados. | Limitação de capacidade naquele ensaio, não OCR aprovado. |
| E071 Race de autoridade; D-134 | PREPARED permitia risco de concorrência entre predecessor/sucessor. | Ambos bloqueados até COMMITTED;28 testes de fila com duas conexões e cinco de autoridade, sem DB produtivo. | Corrigido no contrato. |
| E072 Reuso de job rejeitado; D-135–142 | SUCCEEDED do renderer interpretado como reutilizável/executável apesar de rejeição visual. | Resolver query-only, cadeia de autoridade, design pós-efeito e WAIT versionado; sem reenfileirar/apagar job. | Contenção implementada; remediação audiovisual incompleta. |
| E073 Preflight visual; D-136 |90 takes/23 tratamentos sem texto/fontes insuficientes e conflito de framework escapavam ao plano. | Guard semântico antes de job caro; falha corretamente explicitada. | Não resolvido só por contrato; S23. |
| E074 “Correção” cosmética; D-137 | Alias de framework não criava quatro critérios nem progressão: INTRO75/TRUTH12/COMPLETE1/HIDDEN2. | Proposta rejeitada. OCR de10 frames:6PASS/4FAIL em276,595104s; não cobertura integral. | Histórico rejeitado, sucessor requerido. |
| E075 Capacidade anunciada; D-138 | DDL/função isolada poderia ser tratada como remediação operacional pronta. | Prova limitada explicitada, sem promoção de readiness. Teste específico não recuperado. | Lacuna de integração, não produto resolvido. |
| E076 Semântica fonte/ação; D-139/169 | Papel genérico do ativo não correspondia à ação: paisagens/oceano/caiaques/Eiffel não provavam instrução/resultado. | Inspeção de fontes/takes e amendas próprias; fontes incompatíveis não aprovadas por licença. | Parcial; A12 mantém pendências. |
| E077 Estrutura de prova; D-140 | Três cartões não equivalem a quatro critérios/cinco categorias de apoio. | Prova visual específica exigida; revisão de fonte preservada. | Parcial; não sanável apenas por renomeação. |
| E078 Continuidade da voz; D-141 |90 unidades por take reiniciavam prosódia no meio da frase. |51 unidades editoriais contínuas; contratos clock/captions. R: produtor antigo por take incompatível com sucessor. | Áudio/sincronização final ainda pendentes. |
| E079 Escrita executiva;06/09 02:49:22 e registrosD-144 | WinError5 em temporário fixo executivo; causa do bloqueio externo não identificada. | Temp exclusivo/fsync/replace/seis retries≤0,75s;28 focais/62,375s. JSON+MD não são transação conjunta. | Corrigido no writer; não prova ausência de todo conflito OneDrive. |
| E080 Parser de regressão;06/09/D-145 | Suíte terminou “OK (skipped=1)” mas parser aceitava apenas “OK”. | Primeiro ajuste não alcançou segundo consumidor; correção posterior manteve skip separado. R: teste aprovado virou manutenção FAIL. | Histórico corrigido; tentativas A4. |
| E081 PowerShell5; D-146 | UTF-8/singleton/null/projeção redigida alteravam JSON operacional. | Contraprovas reais de serialização PS; correções de projeção. | Escopo corrigido; não igualdade presumida. |
| E082 PowerShell7; D-147 | Conversão automática de datas mudava strings/hashes de estado/fila. | Pin raw JSON/parse preservando strings; não aceitar datas “equivalentes” como bytes iguais. | Corrigido no contrato. |
| E083 Identidade teste; D-148 | Nome curto ambíguo gerava GC21 falsamente ausente. | Identidades fully qualified, sem refazer mídia para solucionar relatório. | Histórico corrigido. |
| E084 Retrabalho; D-150 | Repetição de ASR/render/regressão íntegros e muitas integrações; custo agregado desconhecido. | Reuso/pins/preflight/focal antes de lote agrupado. Não há contraprova de que todas as repetições foram necessárias. | Melhoria de processo, eficácia global não medida. |
| E085 Frames/timebase;06→07/09/D-153 |150 overlays:50 frames falhavam (f%3==1); timebase1/1000 versus1/30 transformava33ms em0,99 frame. | Normalização de clock;450PASS/SSIMmin0,998624781; restaram três flickerFAIL. | Erro instrumental corrigido; movimento não automaticamente aprovado. |
| E086 Tracking; D-153 | minAreaRect/projective patch misturava shear/fundo; pares compactados através de lacunas invalidavam aceleração. | Contrafactual SSIM≈0,9915 e pares de frames explícitos;15 testes. R: float32/64 gerou primeiro FAIL64671/77658, preservado. | Medição melhorada, não gold humano. |
| E087 Borda de tracking; D-153→154 | Instrumento:102 falhas de borda+uma numérica/perda de domínio. Hipótese arclength não separava bons/ruins. | Seis pares da hipótese falharam LEFT, inclusive três aceitos no baseline; hipótese rejeitada, sem variantes infinitas. | Hipótese descartada, não todos movimentos reprovados. |
| E088 Replay diagnóstico; D-155 | Binding de geometria incompleto, timestamps não determinísticos e fronteira terminal insuficiente. | Verificador separado reabre inputs sem render; sete focais e replay real. | Corrigido no diagnóstico, não produção AV. |
| E089 Loudness; D-156 | Primeira derivação de níveis FAIL5f922. | Correção medida de offset+0,58; PASS5d7ebc… e oito testes. Sem reinferir pronúncia. | Nível do master corrigido; percepção aberta. |
| E090 Desacordo ASR; D-156 e revisão áudio | write/right homófonos e divergências em unidades006/007/013/014/015/016. ASR não basta para confirmar erro falado. | Preservadas divergências, revisão focal necessária; sem ressíntese por suposição. | Incerteza perceptual, não erro de voz comprovado. |
| E091 AdmissionC; D-157 | C autodeclarava LIVE, prova de source insuficiente e150.0/int150 tratados sem contrato. | Reabrir A/inputs e comparar tipos/canônico; consumidor corrigido. | C continua COMPILED_FIXTURE_NOT_EXECUTABLE no escopo referido. |
| E092 Body adapter; D-158 | Intenção incompatível; HOLD alterava fonte; span fora do escopo; fonte não residente. | Quatro guards pré-render,13 adapter+5 integração+7 C; sem mídia aprovada. | Controle testado; integração AV final pendente. |
| E093 Clean plate; D-160 | Prova parcial de fontes e tratamento de stdout vazio precisavam exceção exata. | Validação delimitada; não aceitar saída vazia genericamente. Contagem específica de testes não recuperada. | Escopo isolado, não aprovação final. |
| E094 DNSMOS/ajudantes; D-164 | Constante esperada em teste e sintaxe do verificador incorretas; não falha comprovada dos pesos. | Corrigidos somente teste/helper;16 focais e14 checks de receipt real.195 janelas/~95s, OVRL2,8111 auxiliar. | Ferramenta auxiliar medida, gate perceptual não aprovado. |
| E095 Windows JobObject; D-168 | nested job/query flags produziram prova inadequada de supervisão. |17 testes de supervisor/processos reais; revisão de flags/exaustão sem vazamento observado. R: fixture de flags participou de falha de manutenção. | Corrigido no escopo de supervisor. |
| E096 Cartelas/intenção; D-169 | Três pontos no telefone pareciam digitação; seis imagens não eram seis fontes/linhagens. | Duas PNG alteradas, quatro reaproveitadas; linhagem única preservada. | Fontes estáticas corrigidas parcialmente; vídeo não aprovado. |

### A4. Tentativas distintas de manutenção e regressões de teste

IDs de manutenção abreviados aqui são sufixos/localizadores em S19; D-142/162/168/171 contêm os detalhes recuperados. Não confundir recuperação do PID com aprovação do lote.

| ID / tentativa / data conhecida | Falha e impacto / causa | Correção, teste e resultado de cada tentativa | Situação |
|---|---|---|---|
| E097.a f3c00b33;06/09 05:34 | Preview passou, commit bloqueou por control-cycle-error antigo; guard não era compartilhado com preview. | Sem regressão nesse intento; recuperação22832. Falha original WinError5 anterior preservada; guard revisto. | FAIL histórico. D-142. |
| E097.b 15127eb1;06/09 06:05 | COMMITTED/WAIT existia, mas regressão815 casos:2FAIL/5ERROR/1skip,416,829s. Dois testes mecânicos não isolavam semântica; cinco fixtures públicas sem OCR novo. | Fixtures corrigidas,85 focais+seis testes PNG; recovery7096. Nenhuma aprovação fictícia de mídia. | FAIL histórico; correção de fixture posterior. |
| E097.c 7f85ce4d;06/09 07:00 |845 casos:3FAIL/3ERROR/1skip,501,312s. Integração GOAL/D116 comum aos failures. | Executivo priorizava render apesar de mídia bloqueada; representação de trajetória/D116 corrigida; recovery18684. | FAIL histórico. D-142/143. |
| E097.d b2e5f613;06/09 07:44 |858 casos OK/1skip,712,355s/exit0, mas parser não aceitou skip (E080). | Testes passaram no escopo; fechamento não. Parser/consumidores corrigidos depois. | Manutenção FAIL, não finalD116 aprovado. |
| E098.a 544baa2e;07/09 02:41 |1.169 casos:9ERROR/1FAIL/1skip,1.067,210s. Referência14000 fora PCM2400; fixture copiou WITHHELD sem snapshot; import TestCase duplicou sete testes. | Só três arquivos de teste corrigidos;29 focais e discovery1.165 canônicos. | FAIL preservado. D-162. |
| E098.b 753a9beb;07/09, prova03:31 | Sucessor após correções E098.a. |1.164PASS/1skip,169 schemas e D116; sem regenerar AV para corrigir fixtures. | PASS desse lote, histórico para código posterior. |
| E099 2f7de15f e sucessor;07/09 | Fixture de política com datas antigas e flags JobObject erradas; regressão não fechou. | Correções focalizadas; sucessor1.292PASS/1skip e20 rotas de fallback. | FAIL e PASS distintos preservados. D-168. |
| E100.a 1b05273b;07/09 | Heartbeat comparado contra relógio de observação anterior; snapshot JSON/hash não era do mesmo buffer. | Guard revisado para leitura única antes do relógio, identidade/lease mantidos. | FAIL histórico. D-171. |
| E100.b 94c3c90d;07/09 |1.418PASS/1skip, mas fechamento final falhou pelo problema de clock/buffer. | Recuperação/D116 intermediário não promovidos a manutenção aprovada. | FAIL histórico apesar de testes PASS. |
| E100.c 636c9615;07/09 | Sucessor do fechamento temporal. |1.444PASS/1skip,172 schemas, D11619b5e05e…/ciclo12. | PASS desse lote. |
| E101 A9/a4f5d1da;07→08/09 | Primeira recomposição FAIL935227/argumentos parciais; não era permitido sobrescrever timeline existente. | Reabertura exata/âncora externa; A9 recomposta; instalação1.469PASS/1skip,173 schemas/D116. | Falha/build/instalação separados. |
| E102 A10/87be8b35;08/09 até01:28 | Migração de enum histórico aninhado e dispatch de bordaPCM causaram FAILa82b3ca1. | Compatibilidade corrigida sem relaxar guard; build real preservado;1.556PASS/1skip,175 schemas/D116. | Lote corrigido/instalado; não áudio aprovado. |
| E103.a A11/4eaf3294;08/09 03:29 |1.671 casos:1ERROR/1skip,1.310,274s. Fixture downgrade1.1 reteve question_case_amendment_evidence, corretamente rejeitada. | Apenas remoção do campo no teste, backup/sucessor;1 focalPASS3,870s. Recovery19872 não aprovou lote. | FAIL preservado f038e1bc…. |
| E103.b A11/e58a92f9;08/09, encerramento≈04:17 | Sucessor após correção isolada. |1.670PASS/1skip,178 schemas/554 itens; final5659fe07…/D1162d56c0be… e novo ciclo12. | PASS do lote A11. |
| E104 A12/66aae4cc;08/09 até07:04 | Integração inicial9PASS/1ERROR de fixture; não erro de todo o build A12. | Só um afetado recuperado;12 focais do builder; manutenção1.780PASS/1skip/180 schemas/D116 conforme seção6. | Último lote integral PASS recuperado. |
| E105 Preflight f1f110;08/09 após12:38 | “local runtime migration cannot produce a clean 12-stage source set”; EXECUTIVE_VIEW ATTENTION_REQUIRED/RELEASE_PREPARER BLOCKED. | Falhou antes de request/regressão; saída cooperativa posterior recuperou ciclo sem instalar candidato. | FAIL pré-efeito, não nova manutenção completa. |
| E106 0e1dac1f;08/09 12:58→antes da pausa | Requester18748 ausente; request/ACK persistentes; somente preview. Processo de execução perdeu handle; causa do término desconhecida. | Nenhuma correção na rodada de relatório. Gestor manteve barrier; desligamento posterior foi pausa ordenada, não reparo. | Aberto/preservado. S20; única próxima tarefa proposta. |

### A5. Fontes, calibração, A–D e incidentes recentes

| ID / etapa / intervalo conhecido | Manifestação, impacto e causa | Tentativas, testes e regressão | Situação / origem |
|---|---|---|---| 
| E107 Escopo temporal; D-169→171/07–08/09 | Quatro alvos declarados em bundle parcial não representavam união global; ausência de intenção não provava ausência de alvo. | A6 separou declaração/exclusão/completude; A7 vinculou71 captions literais; A8 calculou união26. Zero scheduling mantido. | Literalidade corrigida, tempo ainda aberto. S21/S23. |
| E108 Cohort/calibração;07→08/09 | Política30 requer mesma voz/velocidade e disjunção;51−26alvos−2incompatíveis=23 candidatas, insuficientes. | Auditoria delimitou incompatibilidade; sem baixar mínimo/ASR ou timestamps fictícios. | Bloqueio real de referência, não erro que se resolve com autorização. S23. |
| E109 Duração;07→08/09 | Master202,780s abaixo207,800s;5,020s faltantes. Níveis aprovados não solucionam estrutura temporal. | Medidas preservadas; nenhuma aprovação por padding/velocidade artificial. | Aberto no áudio/AV. S22/S23. |
| E110 Cartela compacta;07→08/09 | Teste esperava RGB sólido, ignorando LANCZOS/borda; FAILec708da8. Guard antigo lia só on_screen_text e não avaliava todas as palavras do raster. | Perfil independente6px/582.144pixels internos,11OCR reutilizados; contagem por estado exigida. | Estático reconciliado, vídeo/legibilidade temporal não aprovados. D-171. |
| E111 Sources/readers; D-171 | Mapa visual/emenda novo aceito silenciosamente pelo leitor antigo perderia identidade, HOLD e25 negativas. | Versionamento/amendas,88/98/79 estados preservados conforme lote; C/adapters rejeitam renderer antigo. | Compatibilidade explicitada; não readiness por novo arquivo. |
| E112 A9/argumentos;07→08/09 | Input parcial e referência de padding apontavam hash de inputs anterior. | Recuperação read-only dos argumentos, novos evidence_ref só nos campos mecânicos, pausas editoriais preservadas; backup/FAIL935227 preservados. | Build A9 recuperado, não nova mídia; E101 cobre instalação. |
| E113 Direitos batch;08/09 | Validação tardia podia iniciar efeitos antes de conferir todo documento; private/link exclusivo não podia herdar overwrite tolerante do writer legado. | Pré-validação integral, request registrado antes de efeitos, pin externo e publicação exclusiva de arquivo. Testes transacionais próprios. | Contrato corrigido; direito limitado ao raster, sem PUBLICITY implícita. |
| E114 OCR perguntas;08/09 antes02:07 | FAIL_STATIC_SCOPE eac99752 apesar de copy4/4/pixels/revelação corretos; envelope OCR não era contorno real do glifo. | Preservados quatro scans; contraprova mediu sete contornos/0,453s sem OCR novo. Reconciliation0ac7a3fb PASS_STATIC_SCOPE. | Estático reconciliado por nova evidência, FAIL antigo não reclassificado. |
| E115 Modelo OCR/wrapper;08/09 | Modelo pinado≈21MB excedia limite16MiB; claim pin incompleto. | Exceção32MiB só aos três modelos exatos, leitores legados16MiB/metadados2MB; nove focais56c8d8. | Correção delimitada; nenhum limite global relaxado. |
| E116 A11/schema;08/09 | Const aninhado do adapterv10 incorreto gerou FAIL23aaec. | C14/schema ajustado;24 focaisab6520. Down­grade fixture separada em E103. | Corrigido no lote; não timing admitido. |
| E117 Body/prova;08/09 até05:30 | ID de prova dependia do lote solicitado, contadores confundiam custo por estado; falha parcial podia deixar sink aparente. | Identidade por template/sink privado só após sucesso;17 facade,27 direitos,13 registro, com reuso de oito testes intactos. Registro real12 provas/24 direitos. | Provas estabilizadas; não avaliação audiovisual final. |
| E118 Fixture record-learning;08/09 | Assinatura de chamada errada no teste de drift b9fc15. | Só um teste afetado corrigido/PASS02b4b8;16 intactos reutilizados. | Erro de fixture corrigido, sem refazer rasters/OCR. |
| E119 Variedade/concentração;08/09 após07:04 | Fonte integral por unidade exporia painel40,832s, acima10% até no teto. Multiplicar cartelas da mesma linhagem não criava variedade. | Contraprova16 focais/metadata; candidato17 estados/83 preservados, redução observada0.14 focais de contrato sem log persistido. | Aberto; não produzir mais cartelas equivalentes para “contar fontes”. S24. |
| E120 PUBLICITYv2;08/09 | Expiração de prova corrigida em módulo novo, mas quatro outros achados/integrabilidade não fechados. Suíte perdeu terminal após23PASS. | Recuperados só11 desconhecidos,34 métodos distintos; replay/TOCTOU corrigidos com quatro focais e13 de scope privado. | TESTED_CLOCK_ONLY_NOT_ADOPTED; não runtime calibrado. |
| E121 Admissão precoce;08/09 | A12 incompleta poderia alcançar A.verify/WAV/backend/escrita antes de bloquear. | stage_a contexto/argumentos externos/ordem fail-closed;25 focais, A12real bloqueada cedo. | Testado isolado; sucessor completo não instalado. |
| E122 Pexels download;08/09 | v1 parcial, não aquisição completa; contagem de retry não é fornecedor alternativo. | v2 umaGET/ETag/envelope/terminal;18 focais,25.472.389B. Um probe/12quadros depois,12 focais. | Arquivo candidato íntegro/quarentena; não todos os direitos/uso aprovados. |
| E123 Perfil de origem;08/09 09–10h | Sonda real falhou cv2.Error;18 namespaces _native e typing.io/re não tinham origem tratada corretamente. | Captura única495MB preservada; autenticação exata de objetos/diretórios, não prefixos; sonda62,593s/280origens, zero inferência. FAILb8d400fd preservado. | Sonda corrigida; processo novo precisa própria prova. |
| E124 Fixture de origem;08/09 | FAIL189724 em fixture; não falha nova das fontes. | Recuperação000841; reuso de captura/decodes. Teste afetado referenciado no verification. | Histórico corrigido, sem reinferência. |
| E125 Agregador controles;08/09 10:26→10:45 | Filho8008SUCCEEDED/duas inferências, mas agregadorFAILed4139ac exigiu tamanho>0 de urllib/__init__.py legítimo vazio. | Preservados raw/results; exceção exata/novo consumidor/reabertura282origens; recovery27,965s+consumer24,123s, zero reinferência/rede. Seis focais novos/afetados. | Recuperação aprovada no escopo operacional; não calibração/PASS_LIVE de produção. |
| E126 OpenImages caminho;08/09 | Guard ReparsePoint genérico rejeitou ancestrais OneDrive exatos antes de GET. | Allowlist de sete tags exatas com testes; não liberar symlinks indiscriminadamente. Quatro fontes adquiridas, seis focais do join. | Aquisição/controle corrigidos, não direitos produtivos. |
| E127 OpenImages anotações;08/09 | Primeiro JPEG trazia duas caixas contidas, um rosto discernível. Deduplicação automática poderia fabricar gold. | Join41.620imagens/5.594boxes; geometria3.124 imagens/8.416pares identificou54imagens/77pares ambíguos;12 focais. | Triagem, não adjudicação humana/calibração/model release. |
| E128 OAuth incidente;08/09 11:40:58→12:38:39 | REFRESH_FAILED após sucesso; causa original ausente, revogação não demonstrada. | Diagnóstico revisado antes de live contra quatro riscos de logs/retries/resposta; dois offline+11 testes. Grant recuperado200/identidade correta. | Acesso recuperado historicamente; causa original desconhecida, operação hoje pausada. |
| E129 Recovery grant;08/09 | Primeira execução c44eb5 exit2 bloqueou porque fonte já existia; suposição de “nova credencial” era falsa. | v2 admitiu somente identidade/grant histórico exatos; recuperação real com uma unidade. Nenhum novo consentimento inventado. | Corrigido na recuperação; não repetir refresh íntegro como diagnóstico. |
| E130 Watcher bloqueante;08/09 até12:57 | Espera de30dias por fonte inacessível bloqueava todos os estágios após falha de refresh. | Candidato one-passWAIT, grant igual não sobrescreve prova:11 focaisPASS. Helper cooperativo real encerrou seu request e antigo residente voltou ao ciclo12. | Recuperação executada; patch **não instalado com D116**. S20. |
| E131 Temporização de pausa;08/09 turno anterior | Stop-ScheduledTask desabilitou tarefa, mas dois processos-filho continuaram. Primeira checagem de geração rejeitou diferença de precisão100ns versus CIM1µs. | Identidade/parent/comando/geração mantidos, comparação na precisãoCIM; processo15244 encerrado e15104 já ausente. Sem processos/console; task Disabled e automaçãoPAUSED reconfirmados. | Pausa concluída. Não é correção do código do projeto nem perda de credenciais. |

### A6. Erros do levantamento, separados de falhas do produto

- **R01 — handle de execução desconhecido:** write_stdin para sessão10580 retornou “Unknown process id”. Não prova que a manutenção concluiu nem explica por que o requester desapareceu. Não usado como receipt de teste.
- **R02 — consulta PowerShell:** uma coleta do relatório falhou no parser por tentar pipe direto após foreach; correção apenas da consulta read-only, terminal59162a→e09ceb. Não alterou o projeto nem representa defeito do Gestor.
- **R03 — consulta de caminhos:** rg com glob Windows/alguns caminhos presumidos inexistentes retornou erro; consulta por diretório/inventário resolveu localização. Não classificado como fonte produtiva ausente sem confirmação.
- **R04 — gravação interrompida:** a primeira tentativa extensa do relatório retornou aborted e não criou arquivo; verificado REPORT_NOT_CREATED. Gravação menor criou seções1–2, depois interrompidas pela ordem de pausa. A rodada atual completou somente esse rascunho solicitado; nenhum relatório anterior concluído foi sobrescrito.

### A7. O que o catálogo permite concluir — e o que não permite

Há regressões provocadas por evolução de contratos e fixtures (E011/14/15/28/32/46/47/53/64/78 e A4), aprovações reabertas por qualidade real (E002/006–009/067–077), falhas recorrentes de writer/tempo (E023–026/079–083/085–088/100) e controles corretos que impediram avanço sem evidência (E001/029/070/108/119/127).

Os registros D-150/D-171 mandam não repetir mídia íntegra e mostram reuso efetivo em recuperações de OCR, PUBLICITY e fontes. Não há contabilização suficiente para chamar cada repetição anterior de necessária, nem para atribuir economia total em reais/horas/créditos. Algumas regressões integrais foram exigidas pelo protocolo após mudanças; isso não demonstra que a granularidade das mudanças tenha sido eficiente.

Estados BLOCKED/WAIT por ausência de dados, direito ou calibração não devem ser “corrigidos” reduzindo rigor. Em contrapartida, um FAIL do instrumento/fixture não deve forçar nova geração de mídia que já está íntegra. Essa separação é o principal ponto de retomada sem refazer todo o projeto.

**Fim do relatório. Estado operacional: PAUSADO. Próxima tarefa apenas proposta; nenhuma implementação autorizada por esta entrega.**
