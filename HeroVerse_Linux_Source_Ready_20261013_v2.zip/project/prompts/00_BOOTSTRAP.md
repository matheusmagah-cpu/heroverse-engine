# Prompt — Fase 0: auditoria e incorporação

Leia integralmente o `AGENTS.md`, `PLANS.md`, todos os arquivos de `docs/`, os schemas e os templates deste projeto.

Execute somente a Fase 0 definida em `docs/07_PHASES_AND_GATES.md`.

Primeiro confirme a raiz do repositório e informe quais instruções foram carregadas. Depois, audite o projeto existente sem implementar funcionalidades novas.

Entregue:

1. mapa completo do repositório;
2. objetivo que o código atual realmente atende;
3. componentes, scripts, workflows, integrações e documentos existentes;
4. o que já funciona e como foi verificado;
5. o que está incompleto, superficial, quebrado ou apenas documentado;
6. divergências entre o projeto atual e o kit mestre;
7. riscos de perda de trabalho ou conflito;
8. ferramentas e credenciais esperadas, sem revelar segredos;
9. proposta de incorporação dos contratos e schemas;
10. plano detalhado da Fase 1;
11. critérios de aceitação adaptados ao ambiente real.

Não reescreva o projeto, não instale dependências, não crie o minerador e não avance para a Fase 1.

Atualize apenas a documentação de auditoria, `docs/STATE.md` e `docs/DECISIONS.md` quando necessário. Ao final, marque a Fase 0 como `AWAITING_REVIEW` e pare.

