# Prompt — Fase 2: minerador automático

Leia as instruções e confirme que a Fase 2 está autorizada. Execute somente a Fase 2.

Implemente um minerador reproduzível que processe os vídeos do padrão-ouro e gere saídas válidas conforme `schemas/video_mining.schema.json`.

Use adapters e ferramentas locais sempre que forem suficientes. Implemente:

- inspeção de mídia;
- transcrição temporal;
- candidatos a takes;
- keyframes;
- OCR;
- análise das janelas do hook;
- segmentação narrativa;
- packaging analysis;
- evidências;
- separação de fato e inferência;
- validação do schema;
- idempotência por hash;
- logs e versões;
- relatório de divergência contra o padrão-ouro;
- testes.

Não processe o catálogo completo, não gere ChannelDNA e não produza vídeos.

Apresente execução real nas fixtures, resultados dos testes, divergências e consumo de recursos. Marque `AWAITING_REVIEW` e pare.

