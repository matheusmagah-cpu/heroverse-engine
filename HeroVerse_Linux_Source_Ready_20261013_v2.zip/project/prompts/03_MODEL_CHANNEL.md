# Prompt — Fases 3 e 4: executar separadamente

Este arquivo contém dois comandos. Use apenas o bloco correspondente à fase atualmente autorizada.

## Comando da Fase 3

Leia as instruções e confirme autorização da Fase 3. Processe somente o catálogo aprovado, construa snapshots e organize as minerações em coortes de vencedores, medianos, fracos, períodos e comparações independentes.

Valide cobertura, normalização, qualidade e incerteza. Não gere o modelo final. Apresente o conjunto preparado, marque `AWAITING_REVIEW` e pare.

## Comando da Fase 4

Leia as instruções e confirme autorização da Fase 4. Usando somente minerações aprovadas, gere `ChannelDNA`, `FormatArchetypes`, invariantes, variáveis, proibições, matriz de evidências, scores explicáveis, hipóteses e `GenerationSpec` conforme `docs/03_MODELING_SPEC.md` e `schemas/channel_model.schema.json`.

O modelo deve explicar diferenças entre vencedores, medianos e fracos e não pode depender de um viral isolado. Não produza vídeo. Apresente exemplos e contraexemplos, marque `AWAITING_REVIEW` e pare.

