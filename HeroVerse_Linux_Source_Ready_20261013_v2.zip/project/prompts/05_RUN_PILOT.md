# Prompt — Fase 6: canal-piloto

Leia as instruções e confirme autorização da Fase 6. Execute somente a Fase 6.

Prepare e opere o piloto delimitado no plano aprovado:

- um canal;
- um nicho;
- um arquétipo principal;
- identidade isolada;
- lote e período aprovados;
- aprovação humana das embalagens e renders;
- rastreabilidade completa;
- captura de custos, tempo, falhas e métricas próprias.

Antes de qualquer publicação, apresente o pacote final e solicite autorização específica. Não expanda para outro canal.

Ao final da janela aprovada, produza diagnóstico sem inventar thresholds ou métricas ausentes. Marque `AWAITING_REVIEW` e pare.

