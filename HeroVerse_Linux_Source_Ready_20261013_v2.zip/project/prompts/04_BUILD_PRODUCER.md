# Prompt — Fase 5: produtor clip-based

Leia as instruções e confirme autorização da Fase 5. Execute somente a Fase 5.

Implemente o produtor clip-based para um único arquétipo aprovado. Siga `docs/04_PRODUCTION_SPEC.md`, `docs/08_POLICY_AND_RIGHTS.md` e `schemas/production_blueprint.schema.json`.

O fluxo obrigatório é:

tema → ângulo → promessa → título/thumbnail → hook → beat sheet → narrativa → roteiro → busca de recortes permitidos → manifesto → timeline → montagem → quality gates → render de revisão.

Use os recortes como matéria-prima principal. Não substitua silenciosamente por geração integral. Exija nova narrativa, novo contexto, nova seleção e sequência, nova contribuição editorial e identidade do canal.

Não use ativo `UNKNOWN`, não publique e não gere custos pagos sem autorização.

Entregue blueprint, timeline, manifesto, render, testes, custos e relatório completo dos gates. Marque `AWAITING_REVIEW` e pare.

