# Prompt — Fases 7 e 8: aprendizado, escala e produto

Use somente o bloco da fase autorizada.

## Comando da Fase 7

Relacione cada métrica privada disponível às versões de embalagem, hook, narrativa, recortes e produção. Identifique problemas de embalagem, entrega, tema, distribuição ou amostra. Atualize regras somente quando houver evidência.

Apresente comparação antes/depois, mudanças propostas, confiança e teste do segundo canal/arquétipo. Mantenha isolamento total entre canais. Marque `AWAITING_REVIEW` e pare.

## Comando da Fase 8

Somente após comprovação do uso interno e autorização, proponha produto multiusuário. Inclua onboarding, isolamento, custos, permissões, segurança, revisão de licenças, suporte, observabilidade e promessas comerciais compatíveis com os resultados.

Transforme em skills, MCPs ou plugin apenas os fluxos já estáveis. Não comercialize ou publique sem aprovação específica. Marque `AWAITING_REVIEW` e pare.

