# Prompt — Fase 1: padrão-ouro

Leia as instruções do projeto e confirme que a Fase 1 está autorizada em `docs/STATE.md`. Execute somente a Fase 1.

Utilize os vídeos representativos aprovados pelo usuário para construir o padrão-ouro de mineração conforme `docs/02_MINING_SPEC.md`, `templates/GOLD_STANDARD_ANNOTATION.md` e `schemas/video_mining.schema.json`.

Para cada vídeo:

- preserve arquivo e hash;
- registre origem e status de direitos;
- extraia informações técnicas;
- preserve transcrição bruta e revisada;
- revise manualmente hook em `0–1 s`, `1–3 s`, `3–8 s` e, se aplicável, `8–30 s`;
- anote cada take com keyframes e timecodes;
- extraia OCR;
- segmente a narrativa;
- analise título e thumbnail como unidade;
- vincule cada conclusão a evidências;
- marque fatos, cálculos, inferências e desconhecidos;
- gere JSON válido e relatório humano.

Não automatize o lote, não modele o canal e não produza vídeo novo.

Apresente todos os artefatos, incertezas e critérios. Marque a fase como `AWAITING_REVIEW` e pare.

