# EMENDA V3 — CONTINUIDADE AUTÔNOMA ATÉ O RESULTADO FINAL

## RAIZ ÚNICA VINCULANTE
Toda fonte de verdade — código, configuração, prova, log, checkpoint, mídia
necessária e documentação — permanece em `C:\Users\mathe\OneDrive\Área de Trabalho\Modelagem Youtube` ou em suas subpastas. TEMP e caches externos são transitórios e nunca podem substituir ou duplicar permanentemente a raiz oficial.

Esta ordem complementa e prevalece, em matéria de continuidade, sobre qualquer instrução anterior que permita encerrar um turno apenas porque uma etapa intermediária falhou ou foi bloqueada.

## REGRA CENTRAL
NÃO encerre o trabalho em um marco intermediário, diagnóstico, teste, aplicação bloqueada ou “próxima etapa”. Um bloqueio técnico interno é uma nova tarefa a resolver dentro da mesma missão, não motivo para devolver o controle ao proprietário.

Continue autonomamente, em sequência, até atingir o resultado final definido no COMANDO MESTRE V2. Não peça “continue”, não espere nova autorização genérica e não finalize uma interação apenas relatando o próximo marco.

Só existe parada legítima quando TODAS as frentes úteis estiverem bloqueadas por uma dependência realmente externa e impossível de resolver com os acessos já concedidos, como autenticação pessoal obrigatória, indisponibilidade real do provedor, ausência total de cota utilizável ou decisão irreversível que a plataforma exija do proprietário.

Mesmo diante de um bloqueio externo, continue primeiro todas as frentes independentes que puderem avançar. Pare somente quando não existir trabalho útil e seguro restante.

## ESTADO ATUAL VINCULANTE
T31 foi concluída: 2.214 testes, 2.213 PASS, 1 skip permitido; 12 artefatos capturados corretamente; leitor real aceitou o envelope autenticado. NÃO repita T31 por hábito.

T32 tentou aplicação controlada uma única vez sob PAUSE e não houve commit parcial. A causa atual é `CANCEL_WORK_DATABASE_SET_CHANGED` durante `_PausedCancelDatabaseCapture.revalidate()`.

O próximo trabalho é resolver causalmente essa divergência do conjunto SQLite, sem reaplicação cega e sem enfraquecer a proteção de integridade.

A franquia geral do Codex está renovada e disponível; saldo extra comprado em R$0 não é bloqueio enquanto a franquia geral puder executar o trabalho. Não encerre por causa da premissa antiga de créditos extras.
## COMO RESOLVER A T32
1. Preserve T31, PAUSE, credenciais, bancos, provas e estado atual. Não publique nem retome o Gestor antes do gate correto.
2. Identifique exatamente quais arquivos SQLite compunham o conjunto na primeira captura e quais aparecem, desaparecem ou mudam na revalidação; registre caminho, identidade, timestamps, tamanho/hash quando aplicável e processo/escritor responsável quando puder ser determinado com segurança.
3. Classifique a mudança: churn legítimo de WAL/SHM/temporários, banco persistente criado/removido, escritor ainda ativo, corrida de enumeração, OneDrive/antivírus ou defeito real do protocolo. Não presuma a causa.
4. Reproduza a causa em teste isolado antes de alterar a proteção. O teste deve distinguir mudança legítima coerente de alteração perigosa/adulteração.
5. Corrija no nível causal. Prefira snapshot consistente/quiescência/identidade estável do conjunto relevante. NÃO transforme `CANCEL_WORK_DATABASE_SET_CHANGED` em PASS genérico e não ignore banco novo/removido que possa alterar o estado protegido.
6. Rode primeiro testes focais. Se alterar bytes da candidata, execute a validação necessária e produza prova nova desde antes da integral; não fabrique evidência retroativa. Se os bytes não mudarem, reaproveite somente evidência que o contrato real permite reaproveitar.
7. Faça uma única nova aplicação controlada quando os pré-requisitos estiverem comprovados. Se falhar por causa diferente, diagnostique essa nova causa e continue automaticamente.
8. Quando a aplicação passar, faça retomada controlada, D-116 e demais gates reais. Depois saia da frente de manutenção e avance imediatamente para os marcos seguintes do COMANDO MESTRE V2.

## MOTOR DE CONTINUIDADE
Para CADA falha: observar evidência -> localizar causa -> formular hipótese -> reproduzir -> corrigir -> testar focalmente -> validar integração necessária -> executar o gate real -> registrar -> avançar.

A mesma hipótese/mesma tentativa causal pode ser repetida no máximo duas vezes sem informação nova. Na terceira ocorrência, mude a hipótese, aumente o nível de análise/modelo ou avance outra frente independente. Proibido loop de correções equivalentes.

Não rode regressão integral, render, download ou geração de mídia novamente quando uma prova íntegra e vinculada ao mesmo conteúdo/bytes puder ser reutilizada. Processos longos devem ser aguardados pelo mecanismo local de processo/resultado, evitando polling do modelo e gasto desnecessário.

Não confunda “teste passou”, “código pronto”, “aplicação passou”, “robô operando”, “vídeo publicado” e “resultado de audiência”. Cada gate precisa de sua evidência real.

Ao concluir um gate, avance sozinho para o próximo gate elegível. NÃO produza resposta final do tipo “próximo marco é...”. Execute o próximo marco.
## ROTEAMENTO DE MODELO E CUSTO
Use dinamicamente o menor modelo/esforço capaz de satisfazer o gate com a mesma qualidade: tarefas mecânicas/triagem em opção mais econômica disponível; engenharia normal em Terra; Sol quando integração/arquitetura exigir; Astra somente quando houver dificuldade demonstrada que justifique o custo. Spark somente quando sua cota própria estiver disponível e a tarefa for compatível.

Não aumente modelo por conveniência. Também não permaneça em modelo inferior quando isso estiver provocando retrabalho: custo por resultado concluído prevalece sobre custo por chamada.

## AUTONOMIA OPERACIONAL
Use somente ferramentas gratuitas ou já disponíveis/autorizadas. Não compre créditos, não ative recarga automática e não contrate serviço pago. Preserve Acesso completo já concedido dentro dos limites da plataforma.

Faça higiene de recursos quando necessário: espaço em disco, temporários, artefatos descartáveis já consolidados, RAM/processos concorrentes e mídia intermediária sem consumidor. Nunca remova Windows, segurança, acesso remoto, credenciais, dependências necessárias, dados pessoais/empresariais ou evidência ainda exigida.

Depois do núcleo técnico estável, aplique code freeze: resultado editorial/audiência ruim deve ser investigado primeiro em pesquisa, pauta, packaging, hook, thumbnail, título, retenção, formato, público e distribuição; não reabra Python automaticamente.

A pesquisa pré-publicação e a inteligência viva continuam obrigatórias conforme V2: dados -> hipótese -> decisão -> mudança -> execução -> resultado -> regra/rejeição. A operação deve aprender e alterar parâmetros/Packs sem depender do proprietário para decisões editoriais rotineiras.

## CONDIÇÃO DE FINALIZAÇÃO
Não declare “projeto concluído” porque os testes passaram. Continue até a operação autônoma prevista no V2 estar implementada e demonstrada nos gates possíveis agora: pesquisa, configuração, produção, QA, publicação quando autorizada/elegível, analytics, aprendizado, adaptação, gestão de recursos e expansão progressiva.

Metas que dependem de tempo real de audiência/monetização devem permanecer sendo monitoradas pela operação; não mantenha o código em ciclo infinito esperando audiência. O software termina quando está operacionalmente pronto; a inteligência operacional continua executando e aprendendo.

Ao final de cada grande marco, grave checkpoint local curto e prossiga. Só entregue resposta terminal ao proprietário em `PROJECT_COMPLETE` ou `TRUE_EXTERNAL_BLOCKER_ALL_FRONTS`, explicando evidência objetiva. Qualquer outro estado é INTERMEDIÁRIO e deve gerar continuação automática.

COMECE AGORA pela causa de `CANCEL_WORK_DATABASE_SET_CHANGED` da T32 e prossiga sem nova mensagem do proprietário.
